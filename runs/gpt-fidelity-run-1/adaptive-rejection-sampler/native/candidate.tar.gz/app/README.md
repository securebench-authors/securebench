# Adaptive rejection sampling in R

`ars.R` implements the tangent-envelope and chord-squeeze algorithm from
[Gilks and Wild (1992)](https://doi.org/10.2307/2347565). It uses base R only.

```r
source('/app/ars.R')
set.seed(123)
normal <- ars(1000, dnorm)
exponential <- ars(1000, dexp, domain = c(0, Inf), rate = 2)
unnormalized <- ars(1000, expression(exp(-x^2 / 2)))
# Log densities avoid numerical underflow; dlog is the log-density derivative.
log_normal <- ars(1000, function(x) -x^2 / 2, log = TRUE,
                  dlog = function(x) -x)
results <- test()
stopifnot(all(results$passed))
```

The first arguments are `n` and `density`. Supply a vectorized function or a
quoted expression in `x`; additional density parameters go in `...`. Expressions
can also use variables from the calling environment. `domain` defaults to the
real line; specify the actual support for bounded distributions. Optional
`initial` points must be distinct, finite, and strictly inside that domain.
Automatic starting points are simple defaults; use explicit points near the
bulk of unusually located or scaled distributions. Infinite tails are expanded
until their envelope slopes have integrable signs. Invalid arguments, invalid
vectorized outputs, improper envelopes, and iteration exhaustion cause errors.

The target must have a positive, differentiable, concave log density in the
interior of its connected domain. The density need not be normalized. Without
`dlog`, derivatives are estimated by central differences with Richardson
extrapolation. `dlog`, when supplied, must differentiate the log density,
regardless of the `log` setting. Its function receives the same extra arguments
as the density. Numerical concavity tolerances default to `tol = 1e-7`.

The implementation checks derivative order and secant bounds at initialization,
including midpoints, and whenever sampling evaluates a new point. It also checks
evaluated target values against both hulls. These checks can discover violations
of log-concavity; finitely many evaluations cannot establish global concavity or
rule out every unseen mode. Numerical derivatives give floating-point accuracy.

`max_points = 200` caps hull adaptation; subsequent evaluations still undergo
concavity checks. `max_iter` caps proposals and raises an error if the requested
sample count cannot be reached. The returned numeric vector has an
`ars_diagnostics` attribute with proposal, squeeze, evaluation, and support-point
counts. Sourcing the implementation has no sampling or file-writing side effects.

The auxiliary functions separate input validation, target evaluation, derivative
estimation, concavity validation, support initialization, tangent hull construction,
segment integration/inversion, and lower-hull evaluation.

Run the formal tests from a shell with:

```sh
Rscript -e 'source("/app/ars.R"); r <- test(); if (!all(r$passed)) quit(status=1)'
```

`test(n = 6000, seed = 20261029)` uses fixed seeds and restores the caller's RNG
state. It tests normal, exponential, gamma, uniform, shifted/scaled normal,
left-sided exponential, and truncated normal targets. Sample means and variances
are compared with analytic truths using six standard-error bounds. Empirical
CDFs use a Dvoretzky–Kiefer–Wolfowitz bound at alpha = 1e-6 per distribution;
this checks distribution shape as well as moments. Tests also exercise invalid
inputs, non-concavity during sampling, iteration/adaptation limits, numerical
modules against analytic results or independent quadrature, and repeatability.

Each line reports `TEST_NAME: PASS` or `TEST_NAME: FAIL`, with sample mean and
standard deviation (NA for deterministic module/validation tests). The returned
data frame contains each outcome, and the final line gives the total. Tests
save normal draws, one number per line, to `/app/normal_samples.txt` by default;
change this with `test(sample_file = 'another/path.txt')`.
