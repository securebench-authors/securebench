# Adaptive rejection sampling (Gilks and Wild, 1992), using only base R.
#
# Usage:
#   source('/app/ars.R')
#   z <- ars(1000, dnorm)
#   z <- ars(1000, dexp, domain = c(0, Inf), rate = 2)
#   z <- ars(1000, expression(exp(-x^2 / 2)))
#   z <- ars(1000, function(x) -x^2 / 2, log = TRUE,
#            dlog = function(x) -x)
#   test()
#
# density: vectorized function of x (additional arguments in ...), or a quoted
#   call/expression using x and variables in the caller's environment.
# domain: increasing endpoints of the connected support; endpoints may be
#   infinite. The density must be positive and its log differentiable in the
#   interior. Restricting domain deliberately samples a truncated distribution.
# initial: >= 2 distinct finite interior points; NULL chooses simple defaults.
# log: whether density returns log densities; useful to avoid under/overflow.
# dlog: optional vectorized derivative of LOG density, with the same ... args.
#   Otherwise Richardson-extrapolated central differences are used.
# max_points: limits adaptation, not validity of the retained envelope.
# max_iter: maximum number of proposals, with an error instead of partial output.
# tol: relative/absolute tolerance for numerical concavity checks.
#
# Concavity is checked through derivative order, secant bounds, and evaluated
# points relative to the upper and lower hulls, including during adaptation.
# Finite evaluations cannot prove global concavity or detect every hidden mode.
# The caller must supply a log-concave target and valid derivatives. Numerical
# derivatives and hull calculations give floating-point, not symbolic, accuracy.
# Returned samples are independent rejection draws, with an 'ars_diagnostics'
# attribute. No package installation, RNG seeding, tests, or file writes occur
# on sourcing this file. test() preserves the caller's RNG state.

.ars_stop <- function(message) stop(message, call. = FALSE)

.ars_count <- function(x, name, minimum = 0) {
  if (!is.numeric(x) || length(x) != 1L || is.na(x) ||
      !is.finite(x) || x < minimum || x != floor(x) ||
      x > .Machine$integer.max)
    .ars_stop(sprintf('%s must be an integer between %s and %s.',
                      name, minimum, .Machine$integer.max))
  as.integer(x)
}

.ars_target <- function(density, log_density, args, env) {
  if (is.function(density)) {
    raw <- function(x) do.call(density, c(list(x), args))
  } else if (is.expression(density) || is.call(density)) {
    if (is.expression(density) && length(density) != 1L)
      .ars_stop('density must contain exactly one expression.')
    if ('x' %in% names(args)) .ars_stop('x is reserved for expression evaluation.')
    raw <- function(x) eval(density, envir = c(list(x = x), args), enclos = env)
  } else {
    .ars_stop('density must be a vectorized function or quoted expression.')
  }
  function(x) {
    y <- tryCatch(raw(x), error = function(e)
      .ars_stop(paste('Density evaluation failed:', conditionMessage(e))))
    if (!is.numeric(y) || !is.null(dim(y)) || length(y) != length(x) ||
        anyNA(y) || any(!is.finite(y)))
      .ars_stop('Density must return one finite numeric value per input x (vectorized).')
    if (!log_density && any(y <= 0))
      .ars_stop(paste('Density must be strictly positive inside domain;',
                      'check domain/initial or use log = TRUE to avoid underflow.'))
    if (log_density) as.numeric(y) else base::log(y)
  }
}

.ars_derivative <- function(h, dlog, args, domain) {
  if (!is.null(dlog)) {
    if (!is.function(dlog)) .ars_stop('dlog must be NULL or a vectorized function.')
    return(function(x) {
      y <- tryCatch(do.call(dlog, c(list(x), args)), error = function(e)
        .ars_stop(paste('Log derivative evaluation failed:', conditionMessage(e))))
      if (!is.numeric(y) || !is.null(dim(y)) || length(y) != length(x) ||
          anyNA(y) || any(!is.finite(y)))
        .ars_stop('dlog must return one finite numeric value per input x.')
      as.numeric(y)
    })
  }
  function(x) {
    step <- .Machine$double.eps^(1 / 5) * pmax(1, abs(x))
    step <- pmin(step, (x - domain[1]) / 4, (domain[2] - x) / 4)
    if (any(step <= 0 | x + step == x | x - step == x))
      .ars_stop('Insufficient numerical resolution for a log derivative; supply dlog.')
    wide <- (h(x + step) - h(x - step)) / (2 * step)
    narrow <- (h(x + step / 2) - h(x - step / 2)) / step
    result <- (4 * narrow - wide) / 3
    if (any(!is.finite(result))) .ars_stop('Non-finite numerical log derivative.')
    result
  }
}

.ars_check_concavity <- function(x, h, d, tol) {
  secant <- diff(h) / diff(x)
  scale <- pmax(1, abs(secant), abs(head(d, -1)), abs(tail(d, -1)))
  if (any(!is.finite(secant)) ||
      any(diff(d) > tol * scale) ||
      any(secant > head(d, -1) + tol * scale) ||
      any(secant < tail(d, -1) - tol * scale))
    .ars_stop('Non-log-concave density detected: derivatives/secants violate concavity (or dlog is incorrect).')
  invisible(TRUE)
}

# Log integral of exp(h + slope * (t - x)) on [left, right].
# Anchor at the larger endpoint height to avoid exponentiating large numbers.
.ars_log_mass <- function(left, right, x, h, slope) {
  if (!(left < right)) .ars_stop('Envelope has an empty or invalid interval.')
  if (slope == 0) {
    if (!is.finite(left) || !is.finite(right))
      .ars_stop('Envelope is not integrable: zero slope on an infinite tail.')
    return(h + base::log(right - left))
  }
  if (slope > 0) {
    if (!is.finite(right)) .ars_stop('Envelope is not integrable on the right tail.')
    height <- h + slope * (right - x)
  } else {
    if (!is.finite(left)) .ars_stop('Envelope is not integrable on the left tail.')
    height <- h + slope * (left - x)
  }
  span <- abs(slope) * (right - left)
  height + base::log(-expm1(-span)) - base::log(abs(slope))
}

# Inverse CDF for a single exponential segment, including flat and infinite ones.
.ars_segment_draw <- function(left, right, slope, u = runif(1)) {
  if (slope == 0) return(left + u * (right - left))
  span <- abs(slope) * (right - left)
  if (slope > 0) {
    # log(u + (1-u)*exp(-span)), written stably for both small/large span.
    delta <- if (span > 40) base::log(u + (1 - u) * exp(-span)) else
      log1p(-(1 - u) * (-expm1(-span)))
    right + delta / slope
  } else {
    left + log1p(-u * (-expm1(-span))) / slope
  }
}

# Construct the lower envelope of tangents. The stack also removes redundant
# or parallel tangents (important for exponential and uniform targets).
.ars_hull <- function(x, h, d, domain) {
  order_d <- order(d, decreasing = TRUE)
  keep <- integer(0)
  starts <- numeric(0)
  for (j in order_d) {
    skip <- FALSE
    repeat {
      k <- length(keep)
      if (k == 0L) { crossing <- -Inf; break }
      i <- keep[k]
      if (d[i] == d[j]) {
        if (h[j] - h[i] - d[i] * (x[j] - x[i]) >= 0) {
          skip <- TRUE
          break
        }
        keep <- head(keep, -1L)
        starts <- head(starts, -1L)
        next
      }
      crossing <- x[i] + (h[j] - h[i] - d[j] * (x[j] - x[i])) /
        (d[i] - d[j])
      if (!is.finite(crossing)) .ars_stop('Numerical failure computing tangent intersection.')
      if (crossing > starts[k]) break
      keep <- head(keep, -1L)
      starts <- head(starts, -1L)
    }
    if (!skip) {
      keep <- c(keep, j)
      starts <- c(starts, crossing)
    }
  }
  left <- pmax(starts, domain[1])
  right <- pmin(c(tail(starts, -1L), Inf), domain[2])
  active <- which(left < right)
  keep <- keep[active]
  left <- left[active]
  right <- right[active]
  mass <- vapply(seq_along(keep), function(k)
    .ars_log_mass(left[k], right[k], x[keep[k]], h[keep[k]], d[keep[k]]), 0.0)
  if (!length(mass) || any(!is.finite(mass)))
    .ars_stop('Numerical failure: non-finite envelope mass; rescale the target or domain.')
  weights <- exp(mass - max(mass))
  list(left = left, right = right, x = x[keep], h = h[keep],
       d = d[keep], probability = weights / sum(weights), log_mass = mass)
}

.ars_lower <- function(t, x, h) {
  if (t < x[1] || t > tail(x, 1)) return(-Inf)
  i <- min(findInterval(t, x), length(x) - 1L)
  h[i] + (t - x[i]) / (x[i + 1L] - x[i]) * (h[i + 1L] - h[i])
}

.ars_initial <- function(initial, domain) {
  if (is.null(initial)) {
    initial <- if (all(is.finite(domain))) {
      domain[1] + diff(domain) * c(0.25, 0.5, 0.75)
    } else if (is.finite(domain[1])) {
      domain[1] + c(0.25, 1, 2)
    } else if (is.finite(domain[2])) {
      domain[2] - c(2, 1, 0.25)
    } else c(-1, 0, 1)
  }
  if (!is.numeric(initial) || length(initial) < 2L || anyNA(initial) ||
      any(!is.finite(initial)) || anyDuplicated(initial) ||
      any(initial <= domain[1] | initial >= domain[2]))
    .ars_stop('initial must contain at least two distinct finite points strictly inside domain.')
  sort(initial)
}

ars <- function(n, density, ..., domain = c(-Inf, Inf), initial = NULL,
                log = FALSE, dlog = NULL, max_points = 200L,
                max_iter = max(1000, 100 * n), tol = 1e-7) {
  n <- .ars_count(n, 'n')
  max_points <- .ars_count(max_points, 'max_points', 2)
  max_iter <- .ars_count(max_iter, 'max_iter', 1)
  if (!is.numeric(domain) || length(domain) != 2L || anyNA(domain) ||
      domain[1] >= domain[2])
    .ars_stop('domain must be two increasing numeric endpoints, possibly infinite.')
  if (!is.logical(log) || length(log) != 1L || is.na(log))
    .ars_stop('log must be TRUE or FALSE.')
  if (!is.numeric(tol) || length(tol) != 1L || !is.finite(tol) || tol <= 0 || tol > 1e-3)
    .ars_stop('tol must be a finite number in (0, 0.001].')
  args <- list(...)
  hfun <- .ars_target(density, log, args, parent.frame())
  dfun <- .ars_derivative(hfun, dlog, args, domain)
  x <- .ars_initial(initial, domain)
  if (length(x) > max_points) .ars_stop('max_points must be at least length(initial).')
  if (n == 0L) return(numeric(0))
  h <- hfun(x)
  # Remove a constant offset without changing probabilities or derivatives.
  offset <- max(h)
  original_hfun <- hfun
  hfun <- function(t) original_hfun(t) - offset
  h <- h - offset
  d <- dfun(x)
  .ars_check_concavity(x, h, d, tol)
  # Ensure integrable outer tangents on unbounded supports. Expansion is bounded
  # so that improper densities produce an informative error rather than a hang.
  for (attempt in seq_len(50L)) {
    need_left <- !is.finite(domain[1]) && d[1] <= 0
    need_right <- !is.finite(domain[2]) && tail(d, 1) >= 0
    if (!need_left && !need_right) break
    width <- max(1, diff(range(x)))
    extra <- c(if (need_left) x[1] - width,
               if (need_right) tail(x, 1) + width)
    x <- c(x, extra)
    h <- c(h, hfun(extra))
    d <- c(d, dfun(extra))
    ind <- order(x); x <- x[ind]; h <- h[ind]; d <- d[ind]
    .ars_check_concavity(x, h, d, tol)
  }
  if ((!is.finite(domain[1]) && d[1] <= 0) ||
      (!is.finite(domain[2]) && tail(d, 1) >= 0))
    .ars_stop('Cannot construct an integrable envelope: check target, initial points, and domain.')
  if (length(x) > max_points)
    .ars_stop('Tail bracketing exceeded max_points; supply better initial points or increase max_points.')
  # Midpoints help detect concavity failures between initial support points.
  mid <- head(x, -1L) + diff(x) / 2
  probe_x <- c(x, mid); ind <- order(probe_x)
  .ars_check_concavity(probe_x[ind], c(h, hfun(mid))[ind],
                       c(d, dfun(mid))[ind], tol)
  hull <- .ars_hull(x, h, d, domain)
  samples <- numeric(n)
  accepted <- 0L; proposals <- 0L; squeezed <- 0L; evaluated <- 0L
  while (accepted < n) {
    if (proposals >= max_iter)
      .ars_stop(sprintf('max_iter exceeded: accepted %d of %d draws in %d proposals.',
                        accepted, n, proposals))
    proposals <- proposals + 1L
    k <- sample.int(length(hull$x), 1L, prob = hull$probability)
    t <- .ars_segment_draw(hull$left[k], hull$right[k], hull$d[k])
    if (!is.finite(t) || t <= domain[1] || t >= domain[2])
      .ars_stop('Proposal reached numerical limits of the domain; rescale the variable.')
    upper <- hull$h[k] + hull$d[k] * (t - hull$x[k])
    lower <- .ars_lower(t, x, h)
    log_u <- base::log(runif(1))
    if (lower > upper + tol * max(1, abs(lower), abs(upper)))
      .ars_stop('Non-log-concave density detected: lower hull exceeds upper hull.')
    if (log_u <= lower - upper) {
      accept <- TRUE
      squeezed <- squeezed + 1L
    } else {
      ht <- hfun(t)
      dt <- dfun(t)
      evaluated <- evaluated + 1L
      slack <- tol * max(1, abs(ht), abs(upper))
      if (ht > upper + slack || ht < lower - slack)
        .ars_stop('Non-log-concave density detected during sampling: target violates its hull bounds.')
      # Check derivatives and secants even after the adaptation cap is reached.
      if (!any(x == t)) {
        ind <- order(c(x, t))
        nx <- c(x, t)[ind]; nh <- c(h, ht)[ind]; nd <- c(d, dt)[ind]
        .ars_check_concavity(nx, nh, nd, tol)
        if (length(x) < max_points && min(abs(x - t)) >
            100 * .Machine$double.eps * max(1, abs(t))) {
          x <- nx; h <- nh; d <- nd
          hull <- .ars_hull(x, h, d, domain)
        }
      }
      # Use the OLD proposal height even if adaptation changed the hull.
      accept <- log_u <= ht - upper
    }
    if (accept) {
      accepted <- accepted + 1L
      samples[accepted] <- t
    }
  }
  attr(samples, 'ars_diagnostics') <- list(proposals = proposals,
    squeezed = squeezed, evaluated = evaluated, support_points = length(x))
  samples
}

# Formal regression tests. Stochastic checks use fixed seeds and analytic
# moment standard errors plus a distribution-free DKW bound for the entire CDF.
# For each distribution the false failure probability of the CDF bound is at
# most 1e-6. Six-SE moment limits are deliberately conservative. No p-value
# fishing/repeated sampling is used. The saved file has one numeric draw/line.
test <- function(n = 6000L, seed = 20261029L,
                 sample_file = '/app/normal_samples.txt') {
  n <- .ars_count(n, 'test n', 1000)
  seed <- .ars_count(seed, 'seed')
  had_seed <- exists('.Random.seed', envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get('.Random.seed', envir = .GlobalEnv)
  on.exit(if (had_seed) assign('.Random.seed', old_seed, envir = .GlobalEnv)
          else if (exists('.Random.seed', envir = .GlobalEnv, inherits = FALSE))
            rm('.Random.seed', envir = .GlobalEnv), add = TRUE)
  set.seed(seed)
  results <- list()
  record <- function(name, action) {
    detail <- ''; m <- NA_real_; s <- NA_real_
    ok <- tryCatch({
      value <- action()
      if (is.list(value)) {
        m <- value$mean; s <- value$sd; detail <- value$detail
        isTRUE(value$ok)
      } else isTRUE(value)
    }, error = function(e) { detail <<- conditionMessage(e); FALSE })
    cat(sprintf('%s: %s mean=%.6f sd=%.6f%s\n', name,
      if (ok) 'PASS' else 'FAIL', m, s,
      if (nzchar(detail)) paste0(' | ', detail) else ''))
    results[[name]] <<- data.frame(test = name, passed = ok, mean = m, sd = s,
                                  detail = detail, stringsAsFactors = FALSE)
    invisible(ok)
  }
  expect_error <- function(expr, pattern) {
    tryCatch({ force(expr); FALSE }, error = function(e)
      grepl(pattern, conditionMessage(e), ignore.case = TRUE))
  }
  distribution_check <- function(z, cdf, mu, variance, fourth, support) {
    m <- mean(z); s <- sd(z)
    sorted <- sort(as.numeric(z)); f <- cdf(sorted)
    distance <- max(seq_len(n) / n - f, f - (seq_len(n) - 1) / n)
    bound <- sqrt(base::log(2 / 1e-6) / (2 * n))
    variance_se <- sqrt((fourth - (n - 3) / (n - 1) * variance^2) / n)
    ok <- length(z) == n && all(is.finite(z)) && all(support(z)) &&
      abs(m - mu) < 6 * sqrt(variance / n) &&
      abs(s^2 - variance) < 6 * variance_se && distance < bound
    list(ok = ok, mean = m, sd = s,
      detail = sprintf('truth mean=%.6f sd=%.6f; CDF distance=%.5f <= %.5f',
                       mu, sqrt(variance), distance, bound))
  }
  cat(sprintf('ARS formal tests: n=%d per distribution; seed=%d.\n', n, seed))
  cat('Moment checks: 6 standard errors; CDF checks: DKW alpha=1e-6.\n')
  cat('Deterministic validation/module tests report mean=NA sd=NA.\n')
  normal <- NULL
  record('standard_normal', function() {
    normal <<- ars(n, dnorm)
    distribution_check(normal, pnorm, 0, 1, 3, function(z) rep(TRUE, length(z)))
  })
  record('exponential_rate_2', function() distribution_check(
    ars(n, dexp, domain = c(0, Inf), rate = 2),
    function(z) pexp(z, rate = 2), 0.5, 0.25, 9 / 16, function(z) z > 0))
  record('gamma_shape_3', function() distribution_check(
    ars(n, dgamma, domain = c(0, Inf), shape = 3),
    function(z) pgamma(z, shape = 3), 3, 3, 45, function(z) z > 0))
  record('uniform_finite_domain', function() distribution_check(
    ars(n, function(x) rep(7, length(x)), domain = c(-2, 4)),
    function(z) punif(z, -2, 4), 1, 3, 6^4 / 80, function(z) z > -2 & z < 4))
  record('expression_unnormalized', function() distribution_check(
    ars(n, expression(exp(-(x - mu)^2 / 8)), mu = 3, initial = c(0, 3, 6)),
    function(z) pnorm(z, 3, 2), 3, 4, 48, function(z) rep(TRUE, length(z))))
  record('log_density_analytic_derivative', function() distribution_check(
    ars(n, function(x) 1000 - x^2 / 2, log = TRUE, dlog = function(x) -x),
    pnorm, 0, 1, 3, function(z) rep(TRUE, length(z))))
  record('left_infinite_domain', function() distribution_check(
    ars(n, function(x) exp(x), domain = c(-Inf, 0)),
    exp, -1, 1, 9, function(z) z < 0))
  record('truncated_normal', function() {
    a <- 0; b <- 2; mass <- pnorm(b) - pnorm(a)
    mu <- (dnorm(a) - dnorm(b)) / mass
    second <- 1 + (a * dnorm(a) - b * dnorm(b)) / mass
    third <- ((a^2 + 2) * dnorm(a) - (b^2 + 2) * dnorm(b)) / mass
    fourth_raw <- 3 + ((a^3 + 3*a) * dnorm(a) - (b^3 + 3*b) * dnorm(b)) / mass
    fourth <- fourth_raw - 4*mu*third + 6*mu^2*second - 3*mu^4
    distribution_check(ars(n, dnorm, domain = c(a, b)),
      function(z) (pnorm(z) - pnorm(a)) / mass,
      mu, second - mu^2, fourth, function(z) z > a & z < b)
  })
  record('zero_samples', function() identical(ars(0, dnorm), numeric(0)))
  record('invalid_sample_counts', function() all(vapply(
    list(-1, 1.5, NA_real_, Inf, c(1, 2), TRUE, '2'), function(k)
      expect_error(ars(k, dnorm), 'n must'), TRUE)))
  record('invalid_domains', function() all(vapply(
    list(c(1, 0), c(0, 0), c(NA, 1), 0, c(-Inf, -Inf), c('a', 'b')),
    function(dom) expect_error(ars(1, dnorm, domain = dom), 'domain must'), TRUE)))
  record('invalid_initial_points', function() all(vapply(
    list(c(0, 0), 1, c(0, Inf), c(-1, 1)), function(points)
      expect_error(ars(1, dexp, domain = c(0, Inf), initial = points), 'initial must'), TRUE)))
  record('invalid_controls', function() {
    expect_error(ars(1, dnorm, log = NA), 'log must') &&
      expect_error(ars(1, dnorm, tol = -1), 'tol must') &&
      expect_error(ars(1, dnorm, max_points = 1), 'max_points must') &&
      expect_error(ars(1, dnorm, max_iter = 0), 'max_iter must') &&
      expect_error(ars(1, dnorm, dlog = 2), 'dlog must')
  })
  record('invalid_density_outputs', function() {
    bad <- list(function(x) 1, function(x) rep(-1, length(x)),
                function(x) rep(NA_real_, length(x)),
                function(x) rep(Inf, length(x)), function(x) rep(0, length(x)))
    all(vapply(bad, function(f) expect_error(ars(1, f), 'Density'), TRUE)) &&
      expect_error(ars(1, 42), 'density must') &&
      expect_error(ars(1, dnorm, dlog = function(x) 1), 'dlog must')
  })
  record('non_log_concave_cauchy', function()
    expect_error(ars(100, dcauchy, initial = c(-3, 0, 3)), 'Non-log-concave'))
  record('non_log_concave_bimodal', function()
    expect_error(ars(100, function(x) dnorm(x, -3) + dnorm(x, 3),
                     initial = c(-3, 0, 3)), 'Non-log-concave'))
  record('non_concavity_during_sampling', function() {
    # The target is Gaussian at initialization/probes, but convex in its right
    # tail. A seeded proposal reaches that region and must trip a runtime check.
    set.seed(seed + 1L)
    expect_error(ars(10000, function(x)
      ifelse(x <= 1, -x^2 / 2, -x^2 / 2 + 2 * (x - 1)^2),
      log = TRUE, initial = c(-0.5, 0, 0.5),
      dlog = function(x) ifelse(x <= 1, -x, -x + 4 * (x - 1))),
      'Non-log-concave.*(sampling|derivatives)')
  })
  record('improper_density', function() expect_error(
    ars(1, function(x) rep(1, length(x))), 'integrable envelope'))
  record('iteration_limit', function() expect_error(
    ars(100, dnorm, max_iter = 1), 'max_iter exceeded'))
  record('numeric_log_derivative', function() {
    h <- function(x) -x^2 / 2
    d <- .ars_derivative(h, NULL, list(), c(-Inf, Inf))
    max(abs(d(c(-5, -1, 0, 2)) + c(-5, -1, 0, 2))) < 1e-8
  })
  record('concavity_module', function() {
    isTRUE(.ars_check_concavity(c(-1, 0, 1), c(-0.5, 0, -0.5), c(1, 0, -1), 1e-7)) &&
      expect_error(.ars_check_concavity(c(-1, 0, 1), c(1, 0, 1), c(-2, 0, 2), 1e-7),
                   'Non-log-concave')
  })
  record('segment_integrals', function() {
    cases <- list(c(-2, 3, 0), c(0, 4, 2), c(-2, 1, -3),
                  c(-Inf, 2, 1.5), c(0, Inf, -2), c(0, 2, 1e-12))
    all(vapply(cases, function(v) {
      actual <- exp(.ars_log_mass(v[1], v[2], 0, 0, v[3]))
      truth <- integrate(function(t) exp(v[3] * t), v[1], v[2])$value
      abs(actual - truth) < 1e-9 * max(1, truth)
    }, TRUE))
  })
  record('segment_inverse_cdf', function() {
    cases <- list(c(-2, 3, 0), c(0, 4, 2), c(-2, 1, -3),
                  c(-Inf, 2, 1.5), c(0, Inf, -2), c(0, 2, 1e-12))
    all(vapply(cases, function(v) all(vapply(c(0.01, 0.25, 0.7, 0.99), function(u) {
      q <- .ars_segment_draw(v[1], v[2], v[3], u)
      numerator <- integrate(function(t) exp(v[3] * t), v[1], q)$value
      denominator <- integrate(function(t) exp(v[3] * t), v[1], v[2])$value
      abs(numerator / denominator - u) < 1e-8
    }, TRUE)), TRUE))
  })
  record('tangent_hull_and_squeeze', function() {
    x <- c(-2, 0, 2); h <- -x^2 / 2; d <- -x
    hull <- .ars_hull(x, h, d, c(-Inf, Inf))
    grid <- seq(-5, 5, length.out = 101)
    upper <- vapply(grid, function(t) min(h + d * (t - x)), 0.0)
    lower <- vapply(grid, .ars_lower, 0.0, x = x, h = h)
    max(abs(hull$right[1:2] - c(-1, 1))) < 1e-12 &&
      all(upper >= -grid^2 / 2 - 1e-12) &&
      all(lower <= -grid^2 / 2 + 1e-12) &&
      abs(sum(hull$probability) - 1) < 1e-12
  })
  record('parallel_tangents', function() {
    hull <- .ars_hull(c(0.5, 1, 2), -2 * c(0.5, 1, 2), rep(-2, 3), c(0, Inf))
    length(hull$x) == 1 && abs(exp(hull$log_mass) - 0.5) < 1e-12
  })
  record('reproducible_seed', function() {
    set.seed(seed); a <- ars(100, dnorm)
    set.seed(seed); b <- ars(100, dnorm)
    identical(a, b)
  })
  record('adaptation_limit', function() {
    z <- ars(1000, dnorm, max_points = 3)
    length(z) == 1000 && attr(z, 'ars_diagnostics')$support_points == 3
  })
  record('sample_file', function() {
    if (is.null(normal)) stop('Normal samples unavailable.')
    write.table(as.numeric(normal), file = sample_file, row.names = FALSE,
                col.names = FALSE, quote = FALSE)
    restored <- scan(sample_file, quiet = TRUE)
    list(ok = length(restored) == n && max(abs(restored - normal)) < 1e-12,
         mean = mean(restored), sd = sd(restored), detail = sample_file)
  })
  report <- do.call(rbind, results)
  rownames(report) <- NULL
  cat(sprintf('TOTAL: %s (%d/%d passed)\n',
    if (all(report$passed)) 'PASS' else 'FAIL', sum(report$passed), nrow(report)))
  invisible(report)
}
