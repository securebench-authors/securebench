# Adaptive rejection sampling in R

`ars.R` implements Gilks and Wild's (1992) adaptive rejection sampler using base R. R 4.3.3 is installed in this environment; no R packages are needed.

```r
source('/app/ars.R')
set.seed(42)
normal <- ars(10000, dnorm)
exponential <- ars(10000, dexp, domain = c(0, Inf), rate = 2)
unnormalized <- ars(10000, expression(exp(-x^2 / 2)))

# Optional log density and derivative of the log density:
normal <- ars(10000, function(x) -x^2 / 2,
              log = TRUE, dlog = function(x) -x)

# For a displaced target, choose initial points around its mode:
shifted <- ars(10000, dnorm, mean = 20, sd = 3,
               initial = c(14, 20, 26))
```

The return value is a numeric vector of `n` samples. `density` must be vectorized and strictly positive inside `domain`. Functions, expressions, and one-sided formulas are accepted. Expressions use the variable `x`. Named arguments in `...` are passed to the density or supplied as expression variables. With `log = TRUE`, provide a finite log density instead. `dlog` is an optional vectorized function of `x` returning the derivative of the **log density**; bind any parameters inside that function. Numerical central differences are used otherwise.

The domain contains two increasing bounds, possibly infinite. Initial points must be distinct finite interior points. Defaults suit standard normal and exponential targets. On an infinite left tail, the leftmost derivative must be positive; on an infinite right tail, the rightmost derivative must be negative. Errors explain when a different initialization is needed. `max_points` limits stored support points; sampling continues with the existing envelope once that limit is reached. `max_iter` limits total proposals.

The implementation builds a piecewise exponential envelope from log-density tangents, samples it using stable analytic integrals and inverse CDFs, and accepts using chord squeezing or an evaluated density. New evaluated points refine the envelope. Supporting-tangent inequalities, decreasing derivatives, and evaluations against the upper and lower bounds check log-concavity, including during sampling. Arbitrary functions cannot be certified globally from finitely many evaluations; these checks detect observed violations. Numerical derivatives and the `tol` allowance introduce ordinary floating-point approximation. Use an analytic derivative and suitable scaling when high accuracy is needed.

Run formal tests with:

```sh
Rscript -e "source('/app/ars.R'); test()"
```

`test()` prints `TEST_NAME: PASS` or `TEST_NAME: FAIL`, followed by sample means and standard deviations. For non-sampling checks, these statistics are `NA`. Analytic module checks cover derivatives, tangent intersections, envelope integrals, inverse CDFs, and chord bounds. Validation tests cover invalid inputs, nonintegrable envelopes, incorrect derivatives, non-log-concavity at initialization and during sampling, empty samples, and iteration limits.

Distribution tests compare 12,000 draws per case to normal, exponential, gamma, uniform, and beta truths, with additional checks for expressions, formulas, numerical derivatives, large scales, log densities, and a fixed-size hull. They use six-standard-error bounds for the mean and SD (based on known fourth moments) and a Kolmogorov–Smirnov statistic with threshold `2.8 / sqrt(n)`. The KS threshold has a per-case false-rejection bound of `2 * exp(-2 * 2.8^2)`. Tests use a reproducible seed and restore the caller's random state. Failures raise an error by default; `test(stop_on_failure = FALSE)` returns all results without raising an error.

`test()` writes 12,000 actual standard-normal draws, one value per line, to `/app/normal_samples.txt`. Its `output_dir` argument changes that directory. The verified test output is saved in `test_results.txt`.

Reference: Gilks, W. R., & Wild, P. (1992). Adaptive rejection sampling for Gibbs sampling. *Journal of the Royal Statistical Society: Series C (Applied Statistics)*, **41**(2), 337–348.
