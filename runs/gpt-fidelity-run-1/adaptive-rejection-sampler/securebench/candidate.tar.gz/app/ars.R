# Adaptive rejection sampling (Gilks & Wild, 1992), using only base R.
#
# Examples:
#   source('/app/ars.R')
#   z <- ars(10000, dnorm)
#   e <- ars(10000, dexp, domain = c(0, Inf), rate = 2)
#   z <- ars(10000, function(x) dnorm(x, log = TRUE), log = TRUE,
#            dlog = function(x) -x)
#   z <- ars(10000, expression(exp(-x^2 / 2)))
#   test()
#
# density must return one numeric value per x. Expressions/formulas use x.
# ... supplies named arguments to density (or variables in an expression).
# domain is the open interval on which the density is strictly positive.
# initial contains at least two distinct interior points. On infinite tails,
# their derivatives must give an integrable envelope (positive on the left,
# negative on the right). Choose initial to bracket the mode when necessary.
# log=TRUE means density returns log densities; this avoids underflow.
# dlog, if supplied, is the vectorized derivative of the LOG density.
# Otherwise, domain-aware finite differences estimate derivatives.
# Checks detect violations at evaluated points; finite evaluations cannot
# certify global log-concavity of an arbitrary user function. Tiny numerical
# violations within tol are tolerated. No numerical integration is required.

.ars_stop <- function(message) stop(message, call. = FALSE)

.ars_scalar <- function(x, name, lower = 0, integer = FALSE) {
  if (!is.numeric(x) || is.complex(x) || length(x) != 1L || !is.finite(x) ||
      x < lower || (integer && (x != floor(x) || x > .Machine$integer.max)))
    .ars_stop(paste0(name, ' must be a finite ',
                     if (integer) 'integer' else 'number', ' >= ', lower, '.'))
}

.ars_values <- function(f, x, name, finite = TRUE) {
  y <- tryCatch(f(x), error = function(e)
    .ars_stop(paste0(name, ' evaluation failed: ', conditionMessage(e))))
  if (!is.numeric(y) || is.complex(y) || length(y) != length(x) || anyNA(y) ||
      (finite && any(!is.finite(y))))
    .ars_stop(paste0(name, ' must be vectorized and return one finite numeric value per x.'))
  as.numeric(y)
}

.ars_log_density <- function(density, log, args, envir) {
  if (is.function(density)) {
    f <- function(x) do.call(density, c(list(x), args))
  } else if (is.expression(density) || is.language(density)) {
    if (inherits(density, 'formula')) {
      if (length(density) != 2L) .ars_stop('Use a one-sided formula, such as ~ exp(-x^2/2).')
      envir <- environment(density)
      density <- density[[2L]]
    }
    if (is.expression(density) && length(density) != 1L)
      .ars_stop('density must contain exactly one expression.')
    f <- function(x) eval(density, envir = c(list(x = x), args), enclos = envir)
  } else .ars_stop('density must be a function, expression, or one-sided formula.')
  function(x) {
    y <- .ars_values(f, x, 'density')
    if (!log) {
      if (any(y <= 0))
        .ars_stop('density must be strictly positive inside domain; use log=TRUE to avoid underflow.')
      y <- base::log(y)
    }
    y
  }
}

.ars_derivative <- function(x, hfun, domain) {
  step <- .Machine$double.eps^(1/3) * pmax(1, abs(x))
  step <- pmin(step, .Machine$double.eps^(1/3) * (x - domain[1L]),
               .Machine$double.eps^(1/3) * (domain[2L] - x))
  if (any(step <= 0 | x - step == x | x + step == x))
    .ars_stop('Cannot estimate derivative at this numerical precision; supply dlog or rescale x.')
  (hfun(x + step) - hfun(x - step)) / (2 * step)
}

# Validate decreasing slopes and that each tangent supports neighboring nodes.
.ars_check_nodes <- function(x, h, dh, tol) {
  dx <- diff(x)
  secant <- diff(h) / dx
  # Compare errors in log-density units, so rescaling x does not hide a
  # curvature violation or merge meaningful tangents on a very wide domain.
  scale <- pmax(1, abs(head(h, -1L)), abs(tail(h, -1L)))
  if (any(diff(dh) * dx > tol * scale) ||
      any((secant - head(dh, -1L)) * dx > tol * scale) ||
      any((tail(dh, -1L) - secant) * dx > tol * scale))
    .ars_stop('Log-concavity violation: log-density slopes or supporting tangents are inconsistent (or dlog is incorrect).')
}

# Integral of exp(h + slope * (t - x)) over [left, right], on log scale.
.ars_log_integral <- function(left, right, x, h, slope) {
  if (slope == 0) {
    if (!is.finite(left) || !is.finite(right))
      .ars_stop('Envelope is not integrable: choose initial points that bracket the mode.')
    return(h + base::log(right - left))
  }
  if ((is.infinite(left) && slope <= 0) ||
      (is.infinite(right) && slope >= 0))
    .ars_stop('Envelope is not integrable: choose initial points that bracket the mode.')
  peak <- if (slope > 0) right else left
  h + slope * (peak - x) + base::log(-expm1(-abs(slope) * (right - left))) - base::log(abs(slope))
}

# Construct the lower envelope of supporting tangents, clipping to domain.
.ars_hull <- function(x, h, dh, domain, tol) {
  .ars_check_nodes(x, h, dh, tol)
  ids <- integer(0)
  starts <- numeric(0)
  for (i in seq_along(x)) {
    skip <- FALSE
    repeat {
      if (!length(ids)) { crossing <- -Inf; break }
      j <- tail(ids, 1L)
      near_parallel <- abs(dh[j] - dh[i]) <= tol * max(1, abs(dh[j]), abs(dh[i])) &&
        abs(dh[j] - dh[i]) * (x[i] - x[j]) <= tol * max(1, abs(h[j]), abs(h[i]))
      if (near_parallel) {
        # Numerically parallel tangents: retain the lower one. The second
        # condition prevents small, meaningful slopes from being collapsed.
        if (h[i] - dh[i] * x[i] >= h[j] - dh[j] * x[j]) {
          skip <- TRUE
          break
        }
        ids <- head(ids, -1L)
        starts <- head(starts, -1L)
        next
      }
      if (dh[j] < dh[i])
        .ars_stop('Log-concavity violation: tangent slopes must be nonincreasing.')
      crossing <- x[j] + (h[i] - h[j] + dh[i] * (x[j] - x[i])) / (dh[j] - dh[i])
      if (!is.finite(crossing)) .ars_stop('Numerically unstable tangent intersection; rescale the density or x.')
      if (crossing > tail(starts, 1L)) break
      ids <- head(ids, -1L)
      starts <- head(starts, -1L)
    }
    if (!skip) { ids <- c(ids, i); starts <- c(starts, crossing) }
  }
  left <- pmax(starts, domain[1L])
  right <- pmin(c(tail(starts, -1L), Inf), domain[2L])
  keep <- left < right
  ids <- ids[keep]; left <- left[keep]; right <- right[keep]
  log_mass <- vapply(seq_along(ids), function(k)
    .ars_log_integral(left[k], right[k], x[ids[k]], h[ids[k]], dh[ids[k]]), numeric(1))
  if (!length(ids) || any(!is.finite(log_mass)))
    .ars_stop('Envelope mass is not finite; rescale inputs or choose different initial points.')
  weights <- exp(log_mass - max(log_mass))
  list(ids = ids, left = left, right = right, prob = weights / sum(weights),
       log_mass = log_mass)
}

# Invert a truncated exponential without exponentiating a large log density.
.ars_inverse <- function(u, left, right, slope) {
  if (slope == 0) return(left + u * (right - left))
  if (slope > 0)
    right + log1p(-(1 - u) * (-expm1(slope * (left - right)))) / slope
  else left + log1p(-u * (-expm1(slope * (right - left)))) / slope
}

.ars_lower <- function(t, x, h) {
  k <- findInterval(t, x)
  if (k < 1L || k >= length(x)) return(-Inf)
  h[k] + (t - x[k]) * (h[k + 1L] - h[k]) / (x[k + 1L] - x[k])
}

ars <- function(n, density, initial = NULL, domain = c(-Inf, Inf), ...,
                log = FALSE, dlog = NULL, max_points = 1000L,
                max_iter = max(10000, 100 * n), tol = 1e-7) {
  .ars_scalar(n, 'n', integer = TRUE)
  if (!is.numeric(domain) || is.complex(domain) || length(domain) != 2L || anyNA(domain) ||
      domain[1L] >= domain[2L])
    .ars_stop('domain must be two increasing numeric bounds, possibly infinite.')
  if (!is.logical(log) || length(log) != 1L || is.na(log))
    .ars_stop('log must be TRUE or FALSE.')
  .ars_scalar(max_points, 'max_points', lower = 2, integer = TRUE)
  .ars_scalar(max_iter, 'max_iter', lower = 1, integer = TRUE)
  .ars_scalar(tol, 'tol', lower = 0)
  if (!is.null(dlog) && !is.function(dlog)) .ars_stop('dlog must be a function or NULL.')
  args <- list(...)
  if (length(args) && (is.null(names(args)) || any(names(args) == '') || anyDuplicated(names(args))))
    .ars_stop('Additional density arguments must have unique names.')
  if ('x' %in% names(args)) .ars_stop('x is reserved for density evaluation.')
  hfun <- .ars_log_density(density, log, args, parent.frame())
  dfun <- if (is.null(dlog)) function(x) .ars_derivative(x, hfun, domain) else
    function(x) .ars_values(dlog, x, 'dlog')
  if (is.null(initial)) {
    initial <- if (all(is.finite(domain))) {
      domain[1L] + c(.25, .5, .75) * (domain[2L] - domain[1L])
    } else if (is.finite(domain[1L])) domain[1L] + c(.5, 1, 2) else
      if (is.finite(domain[2L])) domain[2L] - c(2, 1, .5) else c(-2, 0, 2)
  }
  if (!is.numeric(initial) || is.complex(initial) || length(initial) < 2L || any(!is.finite(initial)) ||
      anyDuplicated(initial) || any(initial <= domain[1L] | initial >= domain[2L]))
    .ars_stop('initial must contain at least two distinct finite points strictly inside domain.')
  if (length(initial) > max_points) .ars_stop('max_points must be at least length(initial).')
  x <- sort(initial); h <- hfun(x); dh <- dfun(x)
  hull <- .ars_hull(x, h, dh, domain, tol)
  out <- numeric(n)
  if (n == 0L) return(out)
  accepted <- 0L
  for (iteration in seq_len(max_iter)) {
    k <- sample.int(length(hull$ids), 1L, prob = hull$prob)
    j <- hull$ids[k]
    u <- max(runif(1L), .Machine$double.xmin)
    proposal <- .ars_inverse(u, hull$left[k], hull$right[k], dh[j])
    if (!is.finite(proposal) || proposal <= domain[1L] || proposal >= domain[2L])
      .ars_stop('Proposal reached a numerical boundary; rescale x or domain.')
    upper <- h[j] + dh[j] * (proposal - x[j])
    lower <- .ars_lower(proposal, x, h)
    log_u <- base::log(max(runif(1L), .Machine$double.xmin))
    accept <- log_u <= lower - upper
    if (!accept) {
      value <- hfun(proposal)
      scale <- max(1, abs(value), abs(upper), if (is.finite(lower)) abs(lower) else 0)
      if (value > upper + tol * scale || value < lower - tol * scale)
        .ars_stop('Log-concavity violation: evaluated log density lies outside its tangent/chord bounds (or dlog is incorrect).')
      accept <- log_u <= value - upper
      if (!any(x == proposal)) {
        pos <- order(c(x, proposal))
        new_x <- c(x, proposal)[pos]
        new_h <- c(h, value)[pos]
        new_dh <- c(dh, dfun(proposal))[pos]
        .ars_check_nodes(new_x, new_h, new_dh, tol)
        if (length(x) < max_points) {
          new_hull <- .ars_hull(new_x, new_h, new_dh, domain, tol)
          x <- new_x; h <- new_h; dh <- new_dh; hull <- new_hull
        }
      }
    }
    if (accept) {
      accepted <- accepted + 1L
      out[accepted] <- proposal
      if (accepted == n) return(out)
    }
  }
  .ars_stop(paste0('max_iter exceeded after accepting ', accepted, ' of ', n,
                   ' samples; increase max_iter or improve initial points.'))
}

# Reproducible, formal tests. Statistical tests use six-standard-error bounds
# for the mean and SD and a two-sided Kolmogorov-Smirnov threshold with
# P(false rejection) <= 2 exp(-2 * 2.8^2) under each continuous target.
# The fourth central moment determines the asymptotic standard error of SD.
# Test restores the caller's RNG state, writes actual normal draws, prints
# every result, returns an invisible data.frame, and fails loudly by default.
test <- function(n = 12000L, seed = 1992L, output_dir = '/app', stop_on_failure = TRUE) {
  .ars_scalar(n, 'test n', lower = 1000, integer = TRUE)
  .ars_scalar(seed, 'seed', integer = TRUE)
  if (!is.character(output_dir) || length(output_dir) != 1L || is.na(output_dir) || !dir.exists(output_dir))
    .ars_stop('output_dir must be an existing directory.')
  if (!is.logical(stop_on_failure) || length(stop_on_failure) != 1L || is.na(stop_on_failure))
    .ars_stop('stop_on_failure must be TRUE or FALSE.')
  had_seed <- exists('.Random.seed', envir = .GlobalEnv, inherits = FALSE)
  old_seed <- if (had_seed) get('.Random.seed', envir = .GlobalEnv) else NULL
  on.exit(if (had_seed) assign('.Random.seed', old_seed, envir = .GlobalEnv) else
    if (exists('.Random.seed', envir = .GlobalEnv, inherits = FALSE)) rm('.Random.seed', envir = .GlobalEnv), add = TRUE)
  set.seed(seed)
  results <- list()
  record <- function(name, passed, mean = NA_real_, sd = NA_real_, detail = '') {
    cat(sprintf('%s: %s mean=%.6f sd=%.6f%s\n', name, if (passed) 'PASS' else 'FAIL',
                mean, sd, if (nzchar(detail)) paste0(' | ', detail) else ''))
    results[[length(results) + 1L]] <<- data.frame(test = name, passed = passed,
                                                mean = mean, sd = sd, detail = detail)
  }
  check <- function(name, code) {
    tryCatch({ ok <- isTRUE(force(code)); record(name, ok) },
             error = function(e) record(name, FALSE, detail = conditionMessage(e)))
  }
  expect_error <- function(code, pattern) {
    tryCatch({ force(code); FALSE }, error = function(e) grepl(pattern, conditionMessage(e), ignore.case = TRUE))
  }
  cat('ARS formal tests: analytic module checks, validation, and known-distribution sampling.\n')
  check('MODULE_DERIVATIVE', max(abs(.ars_derivative(c(-2, 0, 3), function(x) -x^2/2,
                                                                  c(-Inf, Inf)) - c(2, 0, -3))) < 1e-7)
  check('MODULE_DERIVATIVE_NEAR_BOUNDARY', {
    x <- c(1e-8, .5, 2)
    truth <- 2/x - 1
    max(abs((.ars_derivative(x, function(x) 2*base::log(x) - x,
                            c(0, Inf)) - truth)/pmax(1, abs(truth)))) < 1e-7
  })
  check('MODULE_HULL_INTERSECTIONS', {
    hh <- .ars_hull(c(-1, 0, 1), c(-.5, 0, -.5), c(1, 0, -1), c(-Inf, Inf), 1e-7)
    isTRUE(all.equal(hh$left, c(-Inf, -.5, .5))) &&
      isTRUE(all.equal(hh$right, c(-.5, .5, Inf))) &&
      max(abs(hh$prob - c(1, 1, 1)/3)) < 1e-12
  })
  check('MODULE_LOG_INTEGRALS', {
    abs(.ars_log_integral(0, Inf, 0, 0, -2) + base::log(2)) < 1e-12 &&
      abs(.ars_log_integral(-Inf, 0, 0, 0, 2) + base::log(2)) < 1e-12 &&
      abs(.ars_log_integral(0, 3, 0, 2, 0) - (2 + base::log(3))) < 1e-12 &&
      abs(.ars_log_integral(0, 1, 0, 1000, -1) - (1000 + base::log1p(-exp(-1)))) < 1e-12
  })
  check('MODULE_INVERSE_CDF', {
    u <- c(.01, .25, .5, .99)
    a <- .ars_inverse(u, 0, Inf, -2)
    b <- .ars_inverse(u, -Inf, 0, 2)
    c <- .ars_inverse(u, -1, 2, .7)
    max(abs(pexp(a, 2) - u)) < 1e-12 && max(abs(exp(2*b) - u)) < 1e-12 &&
      max(abs((exp(.7*c) - exp(-.7))/(exp(1.4) - exp(-.7)) - u)) < 1e-12 &&
      max(abs(.ars_inverse(u, -1, 2, 0) - (-1 + 3*u))) < 1e-12
  })
  check('MODULE_SQUEEZE', .ars_lower(0, c(-1, 1), c(-.5, -.5)) == -.5 &&
          .ars_lower(-2, c(-1, 1), c(-.5, -.5)) == -Inf)
  check('INVALID_SAMPLE_COUNTS', all(vapply(list(-1, 1.5, Inf, NA_real_, c(1, 2), '3', 1+1i),
        function(v) expect_error(ars(v, dnorm), 'n must'), logical(1))))
  check('INVALID_DOMAINS', all(vapply(list(c(1, 0), c(0, 0), c(NA, 1), 1, c(0, 1, 2)),
        function(v) expect_error(ars(10, dnorm, domain = v), 'domain'), logical(1))))
  check('INVALID_INITIAL_POINTS', expect_error(ars(10, dnorm, initial = c(0, 0)), 'initial') &&
          expect_error(ars(10, dexp, domain = c(0, Inf), initial = c(0, 1)), 'initial'))
  check('INVALID_DENSITIES', expect_error(ars(10, function(x) 1), 'vectorized') &&
          expect_error(ars(10, function(x) -abs(x)), 'positive') &&
          expect_error(ars(10, function(x) x * NaN), 'finite') &&
          expect_error(ars(10, function(x) x + 1i), 'numeric'))
  check('INVALID_CONTROLS', expect_error(ars(10, dnorm, max_points = 1), 'max_points') &&
          expect_error(ars(10, dnorm, tol = -1), 'tol') &&
          expect_error(ars(10, dnorm, log = NA), 'log must'))
  check('NONINTEGRABLE_ENVELOPE', expect_error(ars(10, dnorm, initial = c(1, 2)), 'not integrable'))
  check('NON_LOG_CONCAVE', expect_error(ars(10, function(x) x^2, log = TRUE,
                           domain = c(-2, 2)), 'Log-concavity') &&
          expect_error(ars(10, dcauchy), 'Log-concavity'))
  check('INCORRECT_DERIVATIVE', expect_error(ars(10, dnorm, dlog = function(x) x), 'Log-concavity'))
  check('NON_LOG_CONCAVE_DURING_SAMPLING', {
    # Initial nodes all lie in an affine region; the first proposal exposes
    # the convex section. A separate seed makes this regression reproducible.
    saved <- .Random.seed
    set.seed(47)
    ok <- expect_error(ars(1000, function(x) pmax(x - .2, 0)^2,
                           log = TRUE, domain = c(0, 1), initial = c(.05, .1)), 'Log-concavity')
    assign('.Random.seed', saved, envir = .GlobalEnv)
    ok
  })
  check('ZERO_SAMPLES', identical(ars(0, dnorm), numeric(0)))
  check('ITERATION_LIMIT', expect_error(ars(10, dnorm, max_iter = 1), 'max_iter exceeded'))
  distribution <- function(name, sampler, cdf, mu, sigma, fourth, bounds = c(-Inf, Inf), save = FALSE) {
    tryCatch({
      z <- sampler()
      m <- mean(z); s <- sd(z)
      p <- sort(cdf(z)); i <- seq_len(n)
      ks <- max(i/n - p, p - (i - 1)/n)
      mean_limit <- 6 * sigma/sqrt(n)
      sd_limit <- 6 * sqrt((fourth - sigma^4)/(4 * n * sigma^2))
      passed <- length(z) == n && all(is.finite(z)) && all(z > bounds[1] & z < bounds[2]) &&
        abs(m - mu) < mean_limit && abs(s - sigma) < sd_limit && ks < 2.8/sqrt(n)
      if (save) write.table(z, file = file.path(output_dir, 'normal_samples.txt'),
                            row.names = FALSE, col.names = FALSE, quote = FALSE)
      record(name, passed, m, s, sprintf('truth mean=%.6f sd=%.6f; KS D=%.5f (limit %.5f)',
                                       mu, sigma, ks, 2.8/sqrt(n)))
    }, error = function(e) record(name, FALSE, detail = conditionMessage(e)))
  }
  distribution('NORMAL', function() ars(n, dnorm), pnorm, 0, 1, 3, save = TRUE)
  distribution('EXPONENTIAL', function() ars(n, dexp, domain = c(0, Inf), rate = 2,
                                               dlog = function(x) rep(-2, length(x))),
               function(x) pexp(x, 2), .5, .5, 9/16, c(0, Inf))
  distribution('EXPONENTIAL_NUMERICAL_DERIVATIVE',
               function() ars(n, dexp, domain = c(0, Inf), rate = 2),
               function(x) pexp(x, 2), .5, .5, 9/16, c(0, Inf))
  distribution('BROAD_NORMAL', function() ars(n, dnorm, sd = 1e8,
                                              initial = c(-1e8, 0, 1e8)),
               function(x) pnorm(x, sd = 1e8), 0, 1e8, 3e32)
  distribution('FIXED_SIZE_HULL_NORMAL',
               function() ars(n, dnorm, initial = c(-2, 2), max_points = 2),
               pnorm, 0, 1, 3)
  distribution('GAMMA', function() ars(n, dgamma, domain = c(0, Inf), shape = 3, rate = 2),
               function(x) pgamma(x, 3, 2), 1.5, sqrt(.75), 45/16, c(0, Inf))
  distribution('UNIFORM', function() ars(n, dunif, domain = c(0, 1)),
               punif, .5, sqrt(1/12), 1/80, c(0, 1))
  distribution('BETA', function() ars(n, dbeta, domain = c(0, 1), shape1 = 2, shape2 = 2),
               function(x) pbeta(x, 2, 2), .5, sqrt(.05), 3/560, c(0, 1))
  distribution('LOG_DENSITY_SHIFTED_NORMAL',
               function() ars(n, function(x) 1000 - (x - 5)^2/8, log = TRUE, initial = c(2, 5, 8)),
               function(x) pnorm(x, 5, 2), 5, 2, 48)
  distribution('EXPRESSION_NORMAL', function() ars(n, expression(exp(-x^2/2))),
               pnorm, 0, 1, 3)
  distribution('FORMULA_NORMAL', function() ars(n, ~ exp(-(x - location)^2/2),
                                              initial = c(0, 2, 4), location = 2),
               function(x) pnorm(x, 2), 2, 1, 3)
  summary <- do.call(rbind, results)
  cat(sprintf('TOTAL: %d PASS, %d FAIL; samples: %s\n', sum(summary$passed),
              sum(!summary$passed), file.path(output_dir, 'normal_samples.txt')))
  if (stop_on_failure && any(!summary$passed)) .ars_stop('ARS formal tests failed; see results above.')
  invisible(summary)
}
