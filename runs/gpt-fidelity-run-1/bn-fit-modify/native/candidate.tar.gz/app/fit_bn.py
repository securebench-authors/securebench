"""Recover a six-edge Gaussian DAG, fit it, and sample under do(Y=0)."""

import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
data = pd.read_csv(ROOT / "bn_sample_10k.csv")
columns = list(data.columns)
values = data.to_numpy(dtype=float)
n, p = values.shape
assert n == 10_000 and np.isfinite(values).all()
covariance = np.cov(values, rowvar=False, bias=True)

# Cache the Gaussian likelihood contribution for each possible parent set.
# All candidates have the same parameter count, so BIC and likelihood rank
# these six-edge graphs identically.
local_scores = {}
for child in range(p):
    others = [i for i in range(p) if i != child]
    for count in range(p):
        for parents in itertools.combinations(others, count):
            variance = covariance[child, child]
            if parents:
                parents_list = list(parents)
                variance -= covariance[child, parents_list] @ np.linalg.solve(
                    covariance[np.ix_(parents_list, parents_list)],
                    covariance[parents_list, child],
                )
            local_scores[child, parents] = float(n * np.log(variance))

# Every DAG with U parentless admits a topological order beginning with U.
u = columns.index("U")
graph_scores = {}
for rest in itertools.permutations(i for i in range(p) if i != u):
    order = (u,) + rest
    possible_edges = list(itertools.combinations(order, 2))
    for candidate in itertools.combinations(possible_edges, 6):
        edges = tuple(sorted(candidate))
        if edges not in graph_scores:
            graph_scores[edges] = sum(
                local_scores[child, tuple(sorted(a for a, b in edges if b == child))]
                for child in range(p)
            )

best_score = min(graph_scores.values())
tied = [edges for edges, score in graph_scores.items()
        if abs(score - best_score) < 1e-7]


def alphabetical_violations(edges):
    return sum(columns[parent] < columns[child]
               for parent, child in edges if u not in (parent, child))


edges = min(tied, key=lambda e: (alphabetical_violations(e), e))
edge_names = [(columns[a], columns[b]) for a, b in edges]


def save_edges(path, named_edges):
    pd.DataFrame([(child, parent) for parent, child in named_edges],
                 columns=["to", "from"]).to_csv(path, index=False)


save_edges(ROOT / "learned_dag.csv", edge_names)
intervened_edges = [(parent, child) for parent, child in edge_names if child != "Y"]
save_edges(ROOT / "intervened_dag.csv", intervened_edges)

# Fit each conditional distribution by Gaussian maximum likelihood (OLS).
models = {}
residuals = {}
for child in columns:
    parents = [parent for parent, target in edge_names if target == child]
    design = np.column_stack([np.ones(n), data[parents].to_numpy()])
    coefficients = np.linalg.lstsq(design, data[child].to_numpy(), rcond=None)[0]
    residual = data[child].to_numpy() - design @ coefficients
    residuals[child] = residual
    models[child] = {
        "parents": parents,
        "intercept": float(coefficients[0]),
        "coefficients": dict(zip(parents, map(float, coefficients[1:]))),
        "noise_variance": float(np.mean(residual ** 2)),
    }

# Truncated factorization: replace Y's conditional by a point mass at zero.
# All other fitted mechanisms, including Y's outgoing effects, stay intact.
rng = np.random.default_rng(20261029)
samples = {}
pending = list(columns)
while pending:
    ready = [child for child in pending
             if child == "Y" or all(parent in samples
                                    for parent in models[child]["parents"])]
    if not ready:
        raise RuntimeError("The recovered graph has a cycle")
    for child in ready:
        if child == "Y":
            samples[child] = np.zeros(n)
        else:
            model = models[child]
            mean = np.full(n, model["intercept"])
            for parent, coefficient in model["coefficients"].items():
                mean += coefficient * samples[parent]
            samples[child] = mean + rng.normal(0.0, np.sqrt(model["noise_variance"]), n)
        pending.remove(child)

output = pd.DataFrame(samples, columns=columns)
output.to_csv(ROOT / "final_bn_sample.csv", index=False)

# Keep the fitted mechanisms and selection evidence for reproducibility.
report = {
    "model_type": "linear Gaussian Bayesian network",
    "training_rows": n,
    "candidate_dags": len(graph_scores),
    "equally_scoring_dags": len(tied),
    "best_score_n_log_residual_variance": best_score,
    "next_distinct_score_gap": min(score - best_score for score in graph_scores.values()
                                   if score > best_score + 1e-7),
    "orientation_rule": "For ambiguous edges excluding U, the alphabetically earlier node is the child.",
    "fitted_conditionals": models,
    "intervention": {"variable": "Y", "value": 0.0},
    "sample_seed": 20261029,
    "training_residual_correlations": pd.DataFrame(residuals).corr().to_dict(),
}
(ROOT / "fitted_bn.json").write_text(json.dumps(report, indent=2) + "\n")

# Verify the actual saved artifacts, including the user's to/from convention.
saved = pd.read_csv(ROOT / "final_bn_sample.csv")
learned = pd.read_csv(ROOT / "learned_dag.csv")
intervened = pd.read_csv(ROOT / "intervened_dag.csv")
assert saved.shape == (10_000, p)
assert list(saved.columns) == columns
assert np.isfinite(saved.to_numpy()).all()
assert (saved["Y"] == 0.0).all()
assert len(learned) == 6 and not (learned["to"] == "U").any()
assert len(intervened) == 5 and not (intervened["to"] == "Y").any()
assert set(map(tuple, intervened.to_numpy())) == {
    (child, parent) for parent, child in edge_names if child != "Y"
}
print("Recovered edges (parent -> child):", edge_names)
print("Candidate DAGs:", len(graph_scores), "; tied optimum DAGs:", len(tied))
print("Fitted conditionals:", json.dumps(models, indent=2))
print("Saved sample summary:\n", saved.describe().to_string())
print("All saved-artifact checks passed.")
