# Recover a six-edge linear Gaussian Bayesian network, fit it, and sample do(Y=0).
# Uses only base R. Run with: Rscript /app/recover_bn.R
options(digits = 12)
x <- read.csv('/app/bn_sample_10k.csv', check.names = FALSE)
stopifnot(nrow(x) == 10000L, all(vapply(x, is.numeric, logical(1))),
          !anyNA(x), all(c('U', 'Y') %in% names(x)))
nodes <- names(x)
p <- length(nodes)
n <- nrow(x)
u <- match('U', nodes)

# Cache maximum-likelihood local Gaussian regression BIC scores for all parent sets.
local_models <- vector('list', p)
for (child in seq_len(p)) {
  local_models[[child]] <- vector('list', 2^p)
  for (mask in 0:(2^p - 1L)) {
    parents <- which(as.logical(intToBits(mask)[seq_len(p)]))
    if (child %in% parents) next
    design <- cbind('(Intercept)' = 1, as.matrix(x[, parents, drop = FALSE]))
    fit <- lm.fit(design, x[[child]])
    variance <- sum(fit$residuals^2) / n
    loglik <- -n / 2 * (log(2 * pi * variance) + 1)
    local_models[[child]][[mask + 1L]] <- list(
      parents = nodes[parents], coefficients = fit$coefficients,
      variance = variance, residuals = fit$residuals,
      bic = -2 * loglik + (length(parents) + 2) * log(n))
  }
}

# Adjacency matrices have parent rows and child columns.
other <- setdiff(seq_len(p), u)
other_pairs <- combn(other, 2)
choices <- expand.grid(c(rep(list(0:1), length(other)),
                         rep(list(0:2), ncol(other_pairs))))
choices <- choices[rowSums(choices[, seq_along(other), drop = FALSE]) +
                   rowSums(choices[, length(other) + seq_len(ncol(other_pairs)),
                                   drop = FALSE] != 0) == 6L, , drop = FALSE]
topological_order <- function(adj) {
  remaining <- seq_len(nrow(adj))
  order <- integer()
  while (length(remaining)) {
    roots <- remaining[colSums(adj[remaining, remaining, drop = FALSE]) == 0]
    if (!length(roots)) return(NULL)
    order <- c(order, roots)
    remaining <- setdiff(remaining, roots)
  }
  order
}
parent_mask <- function(adj, child) sum(2^(which(adj[, child] != 0) - 1L))
valid_graphs <- list()
scores <- numeric()
violations <- integer()
for (i in seq_len(nrow(choices))) {
  adj <- matrix(0L, p, p, dimnames = list(nodes, nodes))
  adj[u, other] <- as.integer(choices[i, seq_along(other)])
  for (j in seq_len(ncol(other_pairs))) {
    direction <- choices[i, length(other) + j]
    a <- other_pairs[1, j]; b <- other_pairs[2, j]
    if (direction == 1) adj[a, b] <- 1L
    if (direction == 2) adj[b, a] <- 1L
  }
  if (is.null(topological_order(adj))) next
  score <- sum(vapply(seq_len(p), function(child)
    local_models[[child]][[parent_mask(adj, child) + 1L]]$bic, numeric(1)))
  edges <- which(adj != 0, arr.ind = TRUE)
  # Prefer the alphabetically earlier node as child for score-equivalent directions.
  violation <- sum(edges[, 1] != u & nodes[edges[, 1]] < nodes[edges[, 2]])
  valid_graphs[[length(valid_graphs) + 1L]] <- adj
  scores <- c(scores, score)
  violations <- c(violations, violation)
}
best <- which(abs(scores - min(scores)) < 1e-7)
selected <- best[which.min(violations[best])]
adj <- valid_graphs[[selected]]
edge_table <- function(a) {
  indices <- which(a != 0, arr.ind = TRUE)
  result <- data.frame(to = nodes[indices[, 2]], from = nodes[indices[, 1]])
  result[order(result$to, result$from), , drop = FALSE]
}
write.csv(edge_table(adj), '/app/learned_dag.csv', row.names = FALSE, quote = FALSE)

models <- setNames(lapply(seq_len(p), function(child)
  local_models[[child]][[parent_mask(adj, child) + 1L]]), nodes)
saveRDS(list(adjacency = adj, models = models, columns = nodes),
        '/app/fitted_bn.rds')

# A hard intervention removes incoming edges and replaces Y's CPD by a point mass.
intervened <- adj
intervened[, match('Y', nodes)] <- 0L
write.csv(edge_table(intervened), '/app/intervened_dag.csv',
          row.names = FALSE, quote = FALSE)
set.seed(20261029)
samples <- as.data.frame(matrix(NA_real_, 10000L, p, dimnames = list(NULL, nodes)))
for (child in topological_order(intervened)) {
  label <- nodes[child]
  if (label == 'Y') {
    samples[[label]] <- 0.0
  } else {
    model <- models[[label]]
    design <- cbind(1, as.matrix(samples[, model$parents, drop = FALSE]))
    samples[[label]] <- as.vector(design %*% model$coefficients) +
      rnorm(nrow(samples), sd = sqrt(model$variance))
  }
}
write.csv(samples, '/app/final_bn_sample.csv', row.names = FALSE, quote = FALSE)

# Verify saved deliverables, and record evidence and fitted parameters.
learned <- read.csv('/app/learned_dag.csv')
cut <- read.csv('/app/intervened_dag.csv')
output <- read.csv('/app/final_bn_sample.csv', check.names = FALSE)
stopifnot(nrow(learned) == 6L, !any(learned$to == 'U'), !any(cut$to == 'Y'),
          nrow(output) == 10000L, identical(names(output), names(x)),
          all(output$Y == 0), all(is.finite(as.matrix(output))),
          !is.null(topological_order(adj)), !is.null(topological_order(intervened)))
sink('/app/bn_fit_report.txt')
cat('Model: linear Gaussian Bayesian network; OLS coefficients and MLE variances.\n')
cat('Exhaustive search over all six-edge DAGs with U as a root.\n')
cat('Valid candidate DAGs:', length(scores), '\n')
cat('Minimum BIC:', min(scores), '\n')
cat('Number of equally best scoring DAGs:', length(best), '\n')
cat('Next distinct BIC gap:', min(scores[scores > min(scores) + 1e-7]) - min(scores), '\n')
cat('Alphabetical direction rule used among equally scoring DAGs.\n\n')
print(learned, row.names = FALSE)
for (label in nodes) {
  model <- models[[label]]
  cat('\nNode:', label, '\nParents:', model$parents, '\nCoefficients:\n')
  print(model$coefficients)
  cat('Residual SD:', sqrt(model$variance), '\n')
  z <- model$residuals / sqrt(model$variance)
  cat('Residual skewness:', mean(z^3), '\nResidual excess kurtosis:', mean(z^4)-3, '\n')
}
cat('\nIntervention: do(Y = 0), deleting all incoming edges to Y.\n')
cat('Seed: 20261029\nOutput validation passed.\n\nSample summary:\n')
print(summary(output))
sink()
cat(readLines('/app/bn_fit_report.txt'), sep = '\n')
