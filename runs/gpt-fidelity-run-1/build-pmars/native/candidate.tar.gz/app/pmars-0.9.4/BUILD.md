# Local headless build

Source: Debian trixie source package pmars 0.9.4-1.

Downloaded files retained in `/app`:

- https://deb.debian.org/debian/pool/main/p/pmars/pmars_0.9.4-1.dsc
- https://deb.debian.org/debian/pool/main/p/pmars/pmars_0.9.4.orig.tar.xz
- https://deb.debian.org/debian/pool/main/p/pmars/pmars_0.9.4-1.debian.tar.xz

Archive SHA-256 hashes were checked against the downloaded Debian .dsc:

```text
d0467d602c37af6e887ac81f4cbb812d090224411196d3401023843630fdd00d  pmars_0.9.4.orig.tar.xz
ca468a97c0fd603e59e0e7c48ef7c9f24a8ac66b5d8c6d5061c4567ccedabfe1  pmars_0.9.4-1.debian.tar.xz
```

Extracted using `dpkg-source --no-check -x pmars_0.9.4-1.dsc`, which applied
the Debian patches. The .dsc signature was not verified; archive checksums
were verified separately. The only local source change removes
`-DXWINGRAPHX` and the X11 link flags from `src/Makefile`. `SERVER` remains
undefined so the text cdb debugger is available.

Build and install:

```sh
make -C /app/pmars-0.9.4/src -j2
install -m 0755 /app/pmars-0.9.4/src/pmars /usr/local/bin/pmars
```

Validation from `/app`:

```sh
pmars -b -r 50 -f flashpaper.red rave.red | tail -n 1
# Results: 12 30 8
ldd /usr/local/bin/pmars
# Only libc and the ELF loader; no X11 libraries.
printf 'registers\nlist 0,3\nstep\nregisters\ntrace 0\nlist 0\nuntrace 0\nlist 0\ncontinue\n' |
  env -u DISPLAY timeout 15 pmars -b -e -r 1 -f flashpaper.red rave.red
```

The debugger test confirmed stepping changes the process queue, trace sets
the displayed T flag, untrace clears it, and continue completes the match.
Build output is in `/app/pmars-build.log`; debugger output is in
`/app/pmars-debugger-test.log`.
