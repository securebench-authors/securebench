"""Run asynchronous jobs with bounded concurrency and orderly cancellation."""

import asyncio
from collections.abc import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run jobs, cancelling and awaiting running jobs on failure or cancellation.

    Jobs should put cleanup in ``finally`` blocks and await it as needed.
    Unstarted jobs are skipped when the run is cancelled or a job fails.
    The original exception is propagated after running jobs finish cleanup.
    When called through ``asyncio.run``, a keyboard interrupt cancels the run
    and allows this cleanup to complete.

    Raises:
        ValueError: If ``max_concurrent`` is less than one.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be at least 1")

    jobs = iter(tasks)

    async def worker() -> None:
        for job in jobs:
            await job()

    workers = [
        asyncio.create_task(worker())
        for _ in range(min(max_concurrent, len(tasks)))
    ]
    if not workers:
        return

    group = asyncio.gather(*workers)
    try:
        # Handle cancellation ourselves so workers receive it only once.
        await asyncio.shield(group)
    except BaseException:
        for task in workers:
            if not task.done():
                task.cancel()

        cleanup = asyncio.gather(*workers, return_exceptions=True)
        while not cleanup.done():
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError:
                # Repeated cancellation must not interrupt job cleanup.
                continue

        # Retrieve the original gather's exception as well as worker results.
        if group.done() and not group.cancelled():
            group.exception()
        raise
