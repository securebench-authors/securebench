"""Run asynchronous jobs with bounded concurrency and orderly cancellation."""

import asyncio
from collections.abc import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run jobs using at most ``max_concurrent`` workers.

    Each callable is invoked only when a worker is available. If a job fails,
    remaining workers are cancelled and awaited before TaskGroup propagates
    the failure as an ExceptionGroup. Cancelling this function likewise waits
    for running jobs' cleanup (including asynchronous ``finally`` blocks).
    Under ``asyncio.run``, the first Ctrl-C requests this cancellation.

    Jobs should allow CancelledError to propagate after performing cleanup.
    Requires Python 3.11 or newer.
    """
    if max_concurrent <= 0:
        raise ValueError("max_concurrent must be greater than zero")

    jobs = iter(tasks)

    async def worker() -> None:
        # Advancing the shared iterator has no await, so workers cannot race
        # to claim the same job within the event loop.
        for job in jobs:
            await job()

    async with asyncio.TaskGroup() as group:
        for _ in range(min(max_concurrent, len(tasks))):
            group.create_task(worker())
