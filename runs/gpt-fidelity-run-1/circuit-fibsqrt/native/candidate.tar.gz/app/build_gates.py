#!/usr/bin/env python3
"""Generate gates.txt: restoring square root, then four Fibonacci steps per tick."""
from pathlib import Path

class Circuit:
    def __init__(self):
        self.gates = [f'out{i}' for i in range(32)]
    def reserve(self, n):
        ids = list(range(len(self.gates), len(self.gates) + n))
        self.gates.extend([None] * n)
        return ids
    def emit(self, expression):
        i = len(self.gates)
        self.gates.append(expression)
        return i
    def op(self, op, a, b=None):
        if b is None:
            if a == self.zero: return self.one
            if a == self.one: return self.zero
            return self.emit(f'~out{a}')
        if a == b:
            return self.zero if op == '^' else a
        if op == '&':
            if self.zero in (a,b): return self.zero
            if a == self.one: return b
            if b == self.one: return a
        if op == '|':
            if self.one in (a,b): return self.one
            if a == self.zero: return b
            if b == self.zero: return a
        if op == '^':
            if a == self.zero: return b
            if b == self.zero: return a
            if a == self.one: return self.op('~', b)
            if b == self.one: return self.op('~', a)
        return self.emit(f'out{a} {op} out{b}')
    def mux(self, s, yes, no):
        # no XOR ((yes XOR no) AND s)
        return self.op('^', no, self.op('&', s, self.op('^', yes, no)))
    def select(self, s, yes, no):
        return [self.mux(s, a, b) for a,b in zip(yes,no)]
    def add(self, a, b, carry=None):
        if carry is None: carry = self.zero
        result = []
        for x,y in zip(a,b):
            p = self.op('^', x,y)
            result.append(self.op('^', p,carry))
            carry = self.op('|', self.op('&', x,y), self.op('&',p,carry))
        return result,carry
    def pad(self, a, width):
        return (a + [self.zero] * width)[:width]

c = Circuit()
a = c.reserve(32)
b = c.reserve(32)
count = c.reserve(14)
boot = c.emit('1')
c.zero = c.emit('0')
c.one = c.emit('1')

# Restoring square root, processing the input two bits at a time.
root, remainder = [], []
for j in range(1,17):
    width = min(2*j,j+2)
    shifted = c.pad([32-2*j,33-2*j] + remainder, width)
    trial = c.pad([c.one,c.zero] + root, width)
    difference, ge = c.add(shifted, [c.op('~',x) for x in trial], c.one)
    remainder = c.select(ge, difference, shifted)
    root = [ge] + root

# Stop at floor(sqrt(N)/4). All registers occur before their next-state logic.
different = c.zero
for x,y in zip(count,root[2:]):
    different = c.op('|',different,c.op('^',x,y))
next_count,_ = c.add(count,[c.zero]*14,c.one)
next_count = c.select(different,next_count,count)

# (a,b) = (F(4*count), F(4*count+1)), all arithmetic modulo 2**32.
f2,_ = c.add(a,b)
f3,_ = c.add(b,f2)
f4,_ = c.add(f2,f3)
f5,_ = c.add(f3,f4)
next_a = c.select(different,f4,a)
next_b = c.select(different,f5,b)

# First tick initializes the registers while boot is still zero.
for ids, values, initial_one in ((a,next_a,False),(b,next_b,True),(count,next_count,False)):
    for i,(reg,value) in enumerate(zip(ids,values)):
        if initial_one and i == 0:
            c.gates[reg] = f'~out{c.op("&", boot, c.op("~",value))}'
        else:
            c.gates[reg] = f'out{c.op("&",boot,value)}'

# Select the remaining zero to three Fibonacci steps.
even = c.select(root[1],f2,a)
odd = c.select(root[1],f3,b)
answer = c.select(root[0],odd,even)
for bit in answer:
    c.emit(f'out{bit}')
assert len(c.gates) < 32000
assert all(g is not None for g in c.gates)
Path('/app/gates.txt').write_text(''.join(f'out{i} = {g}\n' for i,g in enumerate(c.gates)))
print(f'Generated {len(c.gates)} gates')
