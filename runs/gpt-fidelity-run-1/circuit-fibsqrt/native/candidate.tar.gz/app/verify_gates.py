#!/usr/bin/env python3
"""Check the generated circuit against a Python reference using the real simulator."""
import math
from pathlib import Path
import random
import re
import subprocess

HERE = Path(__file__).resolve().parent
lines = (HERE / 'gates.txt').read_text().splitlines()
assert 32 <= len(lines) < 32000
pattern = re.compile(r'out(\d+) = (?:[01]|out\d+|~out\d+|out\d+ [&|^] out\d+)')
for i,line in enumerate(lines):
    match = pattern.fullmatch(line)
    assert match and int(match[1]) == i, (i,line)
    assert all(int(ref) < len(lines) for ref in re.findall(r'out(\d+)',line))
assert lines[:32] == [f'out{i} = out{i}' for i in range(32)]
fib = [0,1]
for _ in range(65534):
    fib.append((fib[-1]+fib[-2]) & 0xffffffff)
inputs = {0,1,2,3,4,208,20000,0xffffffff}
for root in (2,3,4,5,7,8,15,16,31,32,255,256,1023,4096,32767,32768,65534,65535):
    inputs.update((root*root-1,root*root,root*root+1))
rng = random.Random(20261029)
inputs.update(rng.randrange(1 << 32) for _ in range(64))
for n in sorted(inputs):
    expected = fib[math.isqrt(n)]
    actual = int(subprocess.check_output([str(HERE/'sim'),str(n)],cwd=HERE))
    assert actual == expected, (n,actual,expected)
print(f'Passed {len(inputs)} simulator cases; {len(lines)} valid gates.')
