"""Generate a gate circuit computing Fibonacci(floor(sqrt(input))) mod 2**32.

Signal vectors use least-significant-bit-first order. The square root is a
combinational restoring square root. Forward references implement registers:
all register gates precede their next-state logic, so they capture the previous
simulation step's next state. Each active step consumes three Fibonacci terms.
"""
from pathlib import Path


class Circuit:
    def __init__(self):
        self.lines = [f"out{i} = out{i}" for i in range(32)]
        self.zero = self.emit("0")
        self.one = self.emit("1")

    def emit(self, expr):
        i = len(self.lines)
        self.lines.append(f"out{i} = {expr}")
        return i

    def reserve(self, width):
        return [self.emit("0") for _ in range(width)]

    def connect(self, destinations, sources):
        for dst, src in zip(destinations, sources):
            self.lines[dst] = f"out{dst} = out{src}"

    def inv(self, a):
        if a == self.zero:
            return self.one
        if a == self.one:
            return self.zero
        return self.emit(f"~out{a}")

    def op(self, op, a, b):
        if a == b:
            return self.zero if op == '^' else a
        if op == '&':
            if self.zero in (a, b):
                return self.zero
            if self.one in (a, b):
                return b if a == self.one else a
        if op == '|':
            if self.one in (a, b):
                return self.one
            if self.zero in (a, b):
                return b if a == self.zero else a
        if op == '^':
            if self.zero in (a, b):
                return b if a == self.zero else a
            if self.one in (a, b):
                return self.inv(b if a == self.one else a)
        return self.emit(f"out{a} {op} out{b}")

    def mux(self, select, yes, no):
        if yes == no:
            return yes
        return self.op('^', no, self.op('&', select, self.op('^', yes, no)))

    def choose(self, select, yes, no):
        return [self.mux(select, a, b) for a, b in zip(yes, no)]

    def add(self, a, b, carry=None):
        carry = self.zero if carry is None else carry
        result = []
        for x, y in zip(a, b):
            propagate = self.op('^', x, y)
            result.append(self.op('^', propagate, carry))
            carry = self.op('|', self.op('&', x, y), self.op('&', propagate, carry))
        return result, carry

    def subtract(self, a, b):
        # Carry-out is one exactly when unsigned a >= b.
        return self.add(a, [self.inv(x) for x in b], self.one)

    def constant(self, value, width):
        return [self.one if (value >> i) & 1 else self.zero for i in range(width)]


c = Circuit()
root = []
remainder = []
for pair in range(15, -1, -1):
    # Bring down the next two input bits, then try subtracting 4*root+1.
    width = len(root) + 3
    brought_down = [2 * pair, 2 * pair + 1] + remainder
    brought_down += [c.zero] * (width - len(brought_down))
    trial = [c.one, c.zero] + root
    trial += [c.zero] * (width - len(trial))
    difference, fits = c.subtract(brought_down, trial)
    # The restoring remainder fits in len(new_root)+1 bits.
    remainder = c.choose(fits, difference, brought_down)[:len(root) + 2]
    root = [fits] + root

# This reads zero on step zero, and one on every subsequent step. Its
# constant source must occur after this gate to delay initialization one step.
initialized = c.reserve(1)[0]
remaining = c.reserve(16)
a = c.reserve(32)
b = c.reserve(32)
startup_source = c.emit('1')
c.connect([initialized], [startup_source])

# F(k+2), F(k+3), F(k+4), with 32-bit modular arithmetic.
term2, _ = c.add(a, b)
term3, _ = c.add(b, term2)
term4, _ = c.add(term2, term3)
remaining_minus_three, advance = c.subtract(remaining, c.constant(3, 16))

next_remaining = c.choose(advance, remaining_minus_three, remaining)
next_a = c.choose(advance, term3, a)
next_b = c.choose(advance, term4, b)
next_remaining = c.choose(initialized, next_remaining, root)
next_a = c.choose(initialized, next_a, c.constant(0, 32))
next_b = c.choose(initialized, next_b, c.constant(1, 32))
c.connect(remaining, next_remaining)
c.connect(a, next_a)
c.connect(b, next_b)

# Once halted, remaining is 0, 1, or 2. Output the corresponding term.
answer = c.choose(remaining[1], term2, c.choose(remaining[0], b, a))
for bit in answer:
    c.emit(f"out{bit}")
assert len(c.lines) < 32000
Path('/app/gates.txt').write_text('\n'.join(c.lines) + '\n')
print(f'Wrote {len(c.lines)} gates')
