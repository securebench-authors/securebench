#!/usr/bin/env python3
"""Perform the BOOKFORUM transaction using GnuCOBOL's fixed record layout."""

from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
MODULUS = 10**10


class FileError(Exception):
    pass


class RecordFile:
    """Retain the FD record buffer, including across CLOSE and OPEN."""

    def __init__(self, size, name):
        self.name = name
        self.can_rewrite = False
        self.size = size
        self.record = bytes(size)

    def records(self, stream):
        while True:
            chunk = stream.read(self.size)
            if not chunk:
                return
            self.can_rewrite = len(chunk) == self.size
            self.record = chunk + self.record[len(chunk):]
            yield self.record

    def rewrite(self, stream, record):
        if not self.can_rewrite:
            raise FileError("READ must be executed first (status = 43) "
                            f"for file {self.name}")
        self.can_rewrite = False
        self.record = record
        stream.seek(-self.size, 1)
        stream.write(record)


def numeric(value):
    # GnuCOBOL accepts uninitialized (NUL) and space-filled display digits.
    result = 0
    for digit in value:
        result = result * 10 + (digit - 48 if digit >= 48 else 0)
    return result


def display_number(value):
    # An unsigned PIC 9(10) loses the sign and any excess leading digits.
    return f"{abs(value) % MODULUS:010d}".encode("ascii")


def main():
    with (ROOT / "src/INPUT.DAT").open("rb") as stream:
        request = stream.read(22)
    if not request:
        print("Error: Input file is empty")
        return
    request = request.ljust(22, b"\0")
    buyer, seller, book = request[:4], request[4:8], request[8:12]
    amount_field = request[12:22].replace(b"\0", b"0").replace(b" ", b"0")
    amount = numeric(amount_field)
    accounts = RecordFile(34, "ACCOUNTS-FILE")
    books = RecordFile(28, "BOOKS-FILE")

    accounts_path = ROOT / "data/ACCOUNTS.DAT"
    books_path = ROOT / "data/BOOKS.DAT"
    buyer_found = seller_found = book_found = valid_owner = False
    with accounts_path.open("rb") as stream:
        for record in accounts.records(stream):
            buyer_found |= record[:4] == buyer
            seller_found |= record[:4] == seller
    with books_path.open("rb") as stream:
        for record in books.records(stream):
            if record[:4] == book:
                book_found = True
                valid_owner |= record[24:28] == seller

    print(" ")
    if not (buyer_found and seller_found and book_found and valid_owner):
        print("Transaction failed due to validation errors")
        return

    with accounts_path.open("r+b") as stream:
        for record in accounts.records(stream):
            if record[:4] == buyer:
                balance = numeric(record[24:34]) - amount
                record = record[:24] + display_number(balance)
                accounts.rewrite(stream, record)
            if record[:4] == seller:
                balance = numeric(record[24:34]) + amount
                accounts.rewrite(stream, record[:24] + display_number(balance))

    with books_path.open("r+b") as stream:
        for record in books.records(stream):
            if record[:4] == book:
                books.rewrite(stream, record[:24] + buyer)

    with (ROOT / "data/TRANSACTIONS.DAT").open("r+b") as stream:
        stream.seek(0, 2)
        stream.write(book + amount_field + seller + buyer)
    print("Transaction completed successfully")


if __name__ == "__main__":
    try:
        main()
    except (OSError, FileError) as exc:
        print(f"libcob: error: {exc}", file=sys.stderr)
        sys.exit(1)
