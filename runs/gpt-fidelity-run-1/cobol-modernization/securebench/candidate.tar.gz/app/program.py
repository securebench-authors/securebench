#!/usr/bin/env python3
"""Process BOOKFORUM's fixed-width, sequential COBOL data files."""

from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
BALANCE_MODULUS = 10**10
UINT64_MASK = (1 << 64) - 1


class FileStatusError(Exception):
    def __init__(self, path, status, message):
        self.path = path
        self.status = status
        self.message = message


def open_file(relative_path, mode):
    path = ROOT / relative_path
    try:
        return path.open(mode)
    except FileNotFoundError:
        raise FileStatusError(relative_path, 35, "file does not exist") from None


def records(stream, width):
    """A short final READ is returned with spaces, with file status 04."""
    while True:
        offset = stream.tell()
        raw = stream.read(width)
        if not raw:
            return
        yield offset, raw.ljust(width, b" "), len(raw) == width


def display_number(raw):
    """GnuCOBOL's unsigned DISPLAY-to-decimal conversion (also for spaces)."""
    start = 0
    while start < len(raw) - 1 and raw[start] in (32, 48):
        start += 1
    value = 0
    for byte in raw[start:]:
        value = (value * 10 + byte - 48) & UINT64_MASK
    return value


def balance_after(raw, amount_cents, subtract=False):
    cents = display_number(raw) * 100
    cents = cents - amount_cents if subtract else cents + amount_cents
    # Unsigned PIC 9(10) drops the sign, fractional digits, and overflow.
    value = (abs(cents) // 100) % BALANCE_MODULUS
    return f"{value:010d}".encode("ascii")


def rewrite(stream, path, offset, record, read_ok):
    if not read_ok:
        raise FileStatusError(path, 43, "READ must be executed first")
    stream.seek(offset)
    stream.write(record)
    stream.seek(offset + len(record))


def main():
    with open_file("src/INPUT.DAT", "rb") as stream:
        raw = stream.read(22)
    if not raw:
        print("Error: Input file is empty")
        print(
            "libcob: warning: implicit CLOSE of INPUT-FILE ('src/INPUT.DAT')",
            file=sys.stderr,
        )
        return
    request = raw.ljust(22, b" ")
    buyer, seller, book = request[:4], request[4:8], request[8:12]
    # Numeric MOVE between unsigned DISPLAY fields turns spaces into zeroes.
    amount = request[12:22].replace(b" ", b"0")
    amount_cents = display_number(amount + b"00")

    buyer_found = seller_found = book_found = valid_owner = False
    with open_file("data/ACCOUNTS.DAT", "rb") as stream:
        for _, record, _ in records(stream, 34):
            buyer_found |= record[:4] == buyer
            seller_found |= record[:4] == seller
    with open_file("data/BOOKS.DAT", "rb") as stream:
        for _, record, _ in records(stream, 28):
            if record[:4] == book:
                book_found = True
                valid_owner |= record[24:28] == seller
    print(" ")
    if not (buyer_found and seller_found and book_found and valid_owner):
        print("Transaction failed due to validation errors")
        return

    path = "data/ACCOUNTS.DAT"
    with open_file(path, "r+b") as stream:
        for offset, record, read_ok in records(stream, 34):
            if record[:4] == buyer:
                record = record[:24] + balance_after(record[24:], amount_cents, True)
                rewrite(stream, path, offset, record, read_ok)
                # A successful REWRITE consumes the preceding READ. A second
                # REWRITE of this record (buyer == seller) has status 43.
                read_ok = False
            if record[:4] == seller:
                record = record[:24] + balance_after(record[24:], amount_cents)
                rewrite(stream, path, offset, record, read_ok)

    path = "data/BOOKS.DAT"
    with open_file(path, "r+b") as stream:
        for offset, record, read_ok in records(stream, 28):
            if record[:4] == book:
                rewrite(stream, path, offset, record[:24] + buyer, read_ok)

    # OPEN EXTEND on this non-OPTIONAL COBOL file requires it to exist.
    with open_file("data/TRANSACTIONS.DAT", "r+b") as stream:
        stream.seek(0, 2)
        stream.write(book + amount + seller + buyer)
    print("Transaction completed successfully")


if __name__ == "__main__":
    try:
        main()
    except FileStatusError as error:
        name = Path(error.path).stem + "-FILE"
        directory = str(Path(error.path).parent)
        print(
            f"libcob: error: {error.message} (status = {error.status}) "
            f"for file {name} ('{directory}' => {error.path})",
            file=sys.stderr,
        )
        if error.status == 43:
            print(
                f"libcob: warning: implicit CLOSE of {name} ('{error.path}')",
                file=sys.stderr,
            )
        sys.exit(1)
