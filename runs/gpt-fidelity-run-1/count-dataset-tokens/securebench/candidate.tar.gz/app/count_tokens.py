from collections import Counter
from pathlib import Path
import json
import pyarrow.parquet as pq
from transformers import AutoTokenizer

root = Path('/app/token_count_data')
tokenizer = AutoTokenizer.from_pretrained(root, local_files_only=True)
rows = pq.read_table(root / 'metadata.parquet').to_pylist()
science_domains = {'physics', 'chemistry', 'biology'}
science = [row for row in rows if row['domain'] in science_domains]
counts = Counter()
by_domain = Counter()
for row in science:
    for field in ('deepseek_reasoning', 'deepseek_solution'):
        count = len(tokenizer.encode(row[field], add_special_tokens=False))
        counts[field] += count
        by_domain[row['domain']] += count
result = sum(counts.values())
print(json.dumps({'science_examples': len(science), 'field_tokens': dict(counts), 'domain_tokens': dict(by_domain), 'total': result}, indent=2))
Path('/app/answer.txt').write_text(str(result))
assert Path('/app/answer.txt').read_text().isdigit()
