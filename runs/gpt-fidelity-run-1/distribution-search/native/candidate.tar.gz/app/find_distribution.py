"""Construct and save a 150,000-token distribution with both KLs equal to 10.

All logarithms are natural logarithms, so divergences are measured in nats.
Three groups of equally probable tokens provide two free parameters after
normalization, allowing the two KL constraints to be solved simultaneously.
"""

from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.special import logsumexp


VOCAB_SIZE = 150_000
TARGET = 10.0
TOLERANCE = 0.001
OUTPUT = Path("/app/dist.npy")


def find_distribution() -> np.ndarray:
    counts = np.array([1, 999, VOCAB_SIZE - 1_000])
    uniform_group_masses = counts / VOCAB_SIZE
    log_vocab_size = np.log(VOCAB_SIZE)

    def group_log_probabilities(parameters: np.ndarray) -> np.ndarray:
        logits = np.array([parameters[0], parameters[1], 0.0])
        return logits - logsumexp(np.log(counts) + logits)

    def residuals(parameters: np.ndarray) -> np.ndarray:
        log_p = group_log_probabilities(parameters)
        masses = counts * np.exp(log_p)
        forward = np.dot(masses, log_p + log_vocab_size)
        backward = -np.dot(uniform_group_masses, log_p + log_vocab_size)
        return np.array([forward - TARGET, backward - TARGET])

    solution = least_squares(
        residuals,
        x0=np.array([24.0, 15.0]),
        ftol=1e-13,
        xtol=1e-13,
        gtol=1e-13,
        max_nfev=2_000,
    )
    if not solution.success or np.max(np.abs(residuals(solution.x))) > TOLERANCE:
        raise RuntimeError(f"Could not satisfy KL constraints: {solution.message}")

    distribution = np.repeat(np.exp(group_log_probabilities(solution.x)), counts)
    distribution /= distribution.sum()
    return distribution


def validate(distribution: np.ndarray) -> tuple[float, float]:
    if distribution.shape != (VOCAB_SIZE,):
        raise ValueError("Incorrect vocabulary size")
    if not np.all(np.isfinite(distribution)) or not np.all(distribution > 0):
        raise ValueError("Probabilities must be finite and strictly positive")
    if abs(float(distribution.sum()) - 1.0) > 1e-12:
        raise ValueError("Probabilities must sum to one")

    log_ratio = np.log(distribution) + np.log(VOCAB_SIZE)
    forward = float(np.dot(distribution, log_ratio))
    backward = float(-np.mean(log_ratio))
    if max(abs(forward - TARGET), abs(backward - TARGET)) > TOLERANCE:
        raise ValueError(f"KL constraints not met: {forward=}, {backward=}")
    return forward, backward


def main() -> None:
    distribution = find_distribution()
    validate(distribution)
    np.save(OUTPUT, distribution, allow_pickle=False)
    saved = np.load(OUTPUT, allow_pickle=False)
    forward, backward = validate(saved)
    print(f"Saved {OUTPUT}: shape={saved.shape}, dtype={saved.dtype}")
    print(f"Sum: {saved.sum():.16f}")
    print(f"Forward KL(P||U): {forward:.12f}")
    print(f"Backward KL(U||P): {backward:.12f}")


if __name__ == "__main__":
    main()
