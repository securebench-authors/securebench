"""Construct a distribution with both KL divergences from uniform equal to 10."""

from pathlib import Path

import numpy as np
from scipy.optimize import least_squares


VOCABULARY_SIZE = 150_000
TARGET_KL = 10.0
TOLERANCE = 0.001
OUTPUT_PATH = Path("/app/dist.npy")


def construct_distribution() -> np.ndarray:
    # Seven large entries can provide the required entropy. The remaining
    # entries carry a small, positive mass that controls the backward KL.
    counts = np.array([1, 6, VOCABULARY_SIZE - 7])

    def group_probabilities(parameters: np.ndarray) -> np.ndarray:
        head_share, log_tail_mass = parameters
        tail_mass = np.exp(log_tail_mass)
        return np.array([
            (1.0 - tail_mass) * head_share,
            (1.0 - tail_mass) * (1.0 - head_share) / 6,
            tail_mass / (VOCABULARY_SIZE - 7),
        ])

    def residuals(parameters: np.ndarray) -> np.ndarray:
        probabilities = group_probabilities(parameters)
        log_ratios = np.log(VOCABULARY_SIZE * probabilities)
        forward = np.sum(counts * probabilities * log_ratios)
        backward = -np.sum(counts * log_ratios) / VOCABULARY_SIZE
        return np.array([forward - TARGET_KL, backward - TARGET_KL])

    result = least_squares(
        residuals,
        x0=[0.25, -10.0],
        bounds=([1.0 / 7.0, -30.0], [0.999, -1.0]),
        ftol=1e-13,
        xtol=1e-13,
        gtol=1e-13,
        max_nfev=1000,
    )
    if not result.success:
        raise RuntimeError(f"Optimization failed: {result.message}")
    distribution = np.repeat(group_probabilities(result.x), counts)
    distribution /= distribution.sum()
    return distribution


def validate(distribution: np.ndarray) -> tuple[float, float]:
    if distribution.shape != (VOCABULARY_SIZE,):
        raise ValueError("Incorrect vocabulary size")
    if not np.all(np.isfinite(distribution)) or not np.all(distribution > 0):
        raise ValueError("All probabilities must be finite and positive")
    if not np.isclose(distribution.sum(), 1.0, rtol=0, atol=1e-12):
        raise ValueError("Probabilities must sum to one")
    # Natural logarithms give KL divergences in nats.
    log_ratios = np.log(VOCABULARY_SIZE * distribution)
    forward = float(np.sum(distribution * log_ratios))
    backward = float(-np.mean(log_ratios))
    if max(abs(forward - TARGET_KL), abs(backward - TARGET_KL)) > TOLERANCE:
        raise ValueError(f"KL targets not met: {forward=}, {backward=}")
    return forward, backward


def main() -> None:
    distribution = construct_distribution()
    validate(distribution)
    np.save(OUTPUT_PATH, distribution, allow_pickle=False)
    # Verify the actual saved artifact as well.
    saved = np.load(OUTPUT_PATH, allow_pickle=False)
    forward, backward = validate(saved)
    print(f"Saved: {OUTPUT_PATH}")
    print(f"Shape: {saved.shape}; dtype: {saved.dtype}")
    print(f"Sum: {saved.sum():.16f}; minimum: {saved.min():.16g}")
    print(f"KL(P||U): {forward:.12f}")
    print(f"KL(U||P): {backward:.12f}")


if __name__ == "__main__":
    main()
