#!/usr/bin/env node
'use strict';

// Extract the ELF's initial memory image as aligned, unsigned 32-bit words.
// Addresses are ELF virtual addresses (no runtime ASLR/load bias is added).
const fs = require('node:fs');

function extract(filename) {
  const file = fs.readFileSync(filename);
  function check(offset, size) {
    if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(size) ||
        offset < 0 || size < 0 || offset > file.length - size) {
      throw new Error('Truncated or invalid ELF file');
    }
  }
  check(0, 16);
  if (!file.subarray(0, 4).equals(Buffer.from([0x7f, 0x45, 0x4c, 0x46]))) {
    throw new Error('Input is not an ELF binary');
  }
  const elf64 = file[4] === 2;
  if (file[4] !== 1 && !elf64) throw new Error('Unsupported ELF class');
  const little = file[5] === 1;
  if (!little && file[5] !== 2) throw new Error('Unsupported ELF byte order');
  const u16 = offset => {
    check(offset, 2);
    return little ? file.readUInt16LE(offset) : file.readUInt16BE(offset);
  };
  const u32 = offset => {
    check(offset, 4);
    return little ? file.readUInt32LE(offset) : file.readUInt32BE(offset);
  };
  const u64 = offset => {
    check(offset, 8);
    return little ? file.readBigUInt64LE(offset) : file.readBigUInt64BE(offset);
  };
  function asNumber(value) {
    const n = Number(value);
    if (!Number.isSafeInteger(n)) throw new Error('ELF file size or offset is too large');
    return n;
  }
  check(0, elf64 ? 64 : 52);
  const phoff = elf64 ? asNumber(u64(32)) : u32(28);
  const phsize = u16(elf64 ? 54 : 42);
  let phcount = u16(elf64 ? 56 : 44);
  if (phcount === 0xffff) {
    const shoff = elf64 ? asNumber(u64(40)) : u32(32);
    phcount = u32(shoff + (elf64 ? 44 : 28));
  }
  if (phcount && phsize < (elf64 ? 56 : 32)) {
    throw new Error('Invalid ELF program header size');
  }
  check(phoff, phsize * phcount);
  const segments = [];
  for (let i = 0; i < phcount; i++) {
    const p = phoff + i * phsize;
    if (u32(p) !== 1) continue; // PT_LOAD alone defines the memory image.
    const offset = elf64 ? asNumber(u64(p + 8)) : u32(p + 4);
    const address = elf64 ? u64(p + 16) : BigInt(u32(p + 8));
    const filesz = elf64 ? asNumber(u64(p + 32)) : u32(p + 16);
    const memsz = elf64 ? asNumber(u64(p + 40)) : u32(p + 20);
    if (filesz > memsz) throw new Error('ELF segment file size exceeds memory size');
    check(offset, filesz);
    segments.push({ offset, address, filesz, memsz });
  }

  const result = Object.create(null);
  for (const segment of segments) {
    const { offset, address, filesz, memsz } = segment;
    // Only emit complete words. Bytes beyond p_filesz and below p_memsz
    // are initialized to zero by the ELF loader, including .bss.
    const first = Number((4n - address % 4n) % 4n);
    for (let pos = first; pos <= memsz - 4; pos += 4) {
      let value = 0;
      for (let byte = 0; byte < 4; byte++) {
        const b = pos + byte < filesz ? file[offset + pos + byte] : 0;
        value += b * 2 ** ((little ? byte : 3 - byte) * 8);
      }
      result[(address + BigInt(pos)).toString()] = value;
    }
  }
  return result;
}

try {
  if (process.argv.length !== 3) throw new Error('Usage: node extract.js <ELF binary>');
  process.stdout.write(JSON.stringify(extract(process.argv[2])) + '\n');
} catch (error) {
  process.stderr.write(`extract.js: ${error.message}\n`);
  process.exitCode = 1;
}
