#!/usr/bin/env node
'use strict';

// Extract unsigned, aligned 32-bit words from an ELF load image.
// PIE executables use the conventional static-analysis base of 0x400000.
const fs = require('fs');

function extract(filename) {
  const file = fs.readFileSync(filename);
  if (file.length < 52 || file.toString('hex', 0, 4) !== '7f454c46') {
    throw new Error('Input is not an ELF executable');
  }
  const is64 = file[4] === 2;
  if (![1, 2].includes(file[4]) || ![1, 2].includes(file[5])) {
    throw new Error('Unsupported ELF class or byte order');
  }
  const little = file[5] === 1;
  const u16 = offset => little ? file.readUInt16LE(offset) : file.readUInt16BE(offset);
  const u32 = offset => little ? file.readUInt32LE(offset) : file.readUInt32BE(offset);
  const u64 = offset => {
    const n = little ? file.readBigUInt64LE(offset) : file.readBigUInt64BE(offset);
    if (n > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('ELF address exceeds integer precision');
    return Number(n);
  };
  const word = is64 ? u64 : u32;
  const phoff = word(is64 ? 32 : 28);
  const phsize = u16(is64 ? 54 : 42);
  const phnum = u16(is64 ? 56 : 44);
  const shoff = word(is64 ? 40 : 32);
  const shsize = u16(is64 ? 58 : 46);
  const shnum = u16(is64 ? 60 : 48);
  const bias = u16(16) === 3 ? 0x400000 : 0;
  const segments = [];
  const uncertain = new Set();
  const omit = (address, length) => {
    for (let a = Math.floor(address / 4) * 4; a < address + length; a += 4) {
      uncertain.add(a + bias);
    }
  };

  // Relocations describe words whose runtime contents need not equal the file.
  for (let i = 0; i < shnum; i++) {
    const p = shoff + i * shsize;
    const type = u32(p + 4);
    if (type !== 4 && type !== 9 && type !== 19) continue;
    const offset = word(p + (is64 ? 24 : 16));
    const size = word(p + (is64 ? 32 : 20));
    const entrySize = word(p + (is64 ? 56 : 36));
    if (!entrySize) continue;
    // Packed RELR entries can describe multiple relative relocations.
    let next = 0;
    for (let j = 0; j + entrySize <= size; j += entrySize) {
      const address = word(offset + j);
      if (type !== 19) {
        omit(address, is64 ? 8 : 4);
      } else if (address % 2 === 0) {
        omit(address, is64 ? 8 : 4);
        next = address + (is64 ? 8 : 4);
      } else {
        const bits = BigInt(address);
        const width = is64 ? 64 : 32;
        for (let bit = 1; bit < width; bit++) {
          if (bits & (1n << BigInt(bit))) omit(next + (bit - 1) * (width / 8), width / 8);
        }
        next += (width - 1) * (width / 8);
      }
    }
  }

  for (let i = 0; i < phnum; i++) {
    const p = phoff + i * phsize;
    const type = u32(p);
    const offset = word(p + (is64 ? 8 : 4));
    const address = word(p + (is64 ? 16 : 8));
    const filesz = word(p + (is64 ? 32 : 16));
    const memsz = word(p + (is64 ? 40 : 20));
    if (type === 1 && memsz) segments.push({ offset, address, filesz, memsz });
    if (type === 2) {
      // Dynamic pointer entries may also be rewritten by the interpreter.
      const stride = is64 ? 16 : 8;
      const pointerTags = new Set([3, 4, 5, 6, 7, 12, 13, 17, 21, 23, 25, 26, 32,
        0x6ffffef5, 0x6ffffff0, 0x6ffffffc, 0x6ffffffe]);
      for (let j = 0; j + stride <= filesz; j += stride) {
        const tag = word(offset + j);
        if (!tag) break;
        if (pointerTags.has(tag)) omit(address + j + stride / 2, stride / 2);
      }
    }
  }

  const result = Object.create(null);
  for (const segment of segments) {
    const { offset, address, filesz, memsz } = segment;
    // Retain only complete words inside declared PT_LOAD memory ranges.
    // Section tables and debug information are not part of the load image.
    for (let a = Math.ceil(address / 4) * 4; a + 4 <= address + memsz; a += 4) {
      if (uncertain.has(a + bias)) continue;
      const bytes = Buffer.alloc(4);
      for (let j = 0; j < 4; j++) {
        const relative = a + j - address;
        if (relative < filesz) {
          if (offset + relative >= file.length) throw new Error('Truncated ELF load segment');
          bytes[j] = file[offset + relative];
        }
      }
      result[String(a + bias)] = little ? bytes.readUInt32LE(0) : bytes.readUInt32BE(0);
    }
  }
  return result;
}

try {
  if (process.argv.length !== 3) throw new Error('Usage: node extract.js <ELF executable>');
  process.stdout.write(JSON.stringify(extract(process.argv[2])) + '\n');
} catch (error) {
  process.stderr.write(`extract.js: ${error.message}\n`);
  process.exitCode = 1;
}
