"""Chosen-plaintext recovery of the final FEAL round key."""

import random


def _f(value):
    """The public round function, with bytes ordered least significant first."""
    x0 = value & 255
    x1 = (value >> 8) & 255
    x2 = (value >> 16) & 255
    x3 = (value >> 24) & 255

    t = ((x3 ^ x2) + (x1 ^ x0) + 1) & 255
    y2 = ((t << 2) | (t >> 6)) & 255
    t = (x3 + y2) & 255
    y3 = ((t << 2) | (t >> 6)) & 255
    t = ((x1 ^ x0) + y2) & 255
    y1 = ((t << 2) | (t >> 6)) & 255
    t = (x0 + y1 + 1) & 255
    y0 = ((t << 2) | (t >> 6)) & 255
    return y0 | (y1 << 8) | (y2 << 16) | (y3 << 24)


def attack(encrypt_fn):
    """Return key[5], using only integer plaintext/ciphertext oracle calls.

    F(x ^ D) ^ F(x) = E for D=0x80800000 and E=0x02000000.
    A plaintext difference (D, D) becomes (D, 0) after input mixing.
    Its differences after rounds one and two are (0, D) and (D, E).
    Thus the left input to the final round has difference E.

    For ciphertext (a, b), undoing the output mixing gives final-round
    input right half a ^ b and output right half a. Consequently a key
    candidate k must satisfy:
        F(a ^ b ^ k) ^ F(a' ^ b' ^ k) = a ^ a' ^ E.
    Independent pairs eliminate false candidates from the seed space.
    """
    candidates = [(seed * 1234567) & 0xFFFFFFFF for seed in range(1 << 16)]
    rng = random.Random(0xFEA14)
    difference = 0x8080000080800000

    for _ in range(32):
        plaintext = rng.getrandbits(64)
        ciphertext = encrypt_fn(plaintext)
        paired_ciphertext = encrypt_fn(plaintext ^ difference)

        a = (ciphertext >> 32) & 0xFFFFFFFF
        b = ciphertext & 0xFFFFFFFF
        paired_a = (paired_ciphertext >> 32) & 0xFFFFFFFF
        paired_b = paired_ciphertext & 0xFFFFFFFF
        right = a ^ b
        paired_right = paired_a ^ paired_b
        expected = a ^ paired_a ^ 0x02000000

        candidates = [
            k for k in candidates
            if _f(right ^ k) ^ _f(paired_right ^ k) == expected
        ]
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            raise ValueError("Oracle does not match the cipher or key seed scheme")

    raise RuntimeError("Chosen plaintext pairs did not isolate the final key")
