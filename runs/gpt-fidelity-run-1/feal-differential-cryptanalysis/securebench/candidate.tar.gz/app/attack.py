"""Chosen-plaintext recovery of the last FEAL round key."""

from random import getrandbits


def _f(value):
    """The cipher's byte-oriented F function, without temporary lists."""
    x0 = value & 255
    x1 = (value >> 8) & 255
    x2 = (value >> 16) & 255
    x3 = value >> 24

    t = ((x3 ^ x2) + (x1 ^ x0) + 1) & 255
    y2 = ((t << 2) | (t >> 6)) & 255
    t = (x3 + y2) & 255
    y3 = ((t << 2) | (t >> 6)) & 255
    t = ((x1 ^ x0) + y2) & 255
    y1 = ((t << 2) | (t >> 6)) & 255
    t = (x0 + y1 + 1) & 255
    y0 = ((t << 2) | (t >> 6)) & 255
    return y0 | (y1 << 8) | (y2 << 16) | (y3 << 24)


def attack(encrypt_fn):
    """Return key[5] using only integer plaintext/ciphertext oracle calls.

    F(x) ^ F(x ^ A) = B for every x, where A = 0x80800000
    and B = 0x02000000. Giving both plaintext halves difference A
    makes the initial Feistel state difference (A, 0). After two
    rounds it is (A, B), so the left input to the fourth round has
    difference B, regardless of the preceding keys.

    Undoing the output mixing gives the fourth round's input right
    half u and output right half v. The true final key k satisfies
    F(u ^ k) ^ F(u' ^ k) = v ^ v' ^ B. Filter the seed-derived
    keyspace with independent pairs until the key is unique.
    """
    candidates = [(seed * 1234567) & 0xFFFFFFFF
                  for seed in range(1 << 16)]
    plaintext_difference = 0x8080000080800000
    f = _f

    while len(candidates) > 1:
        plaintext = getrandbits(64)
        ciphertext = encrypt_fn(plaintext)
        paired_ciphertext = encrypt_fn(plaintext ^ plaintext_difference)

        v = ciphertext >> 32
        paired_v = paired_ciphertext >> 32
        u = (ciphertext & 0xFFFFFFFF) ^ v
        paired_u = (paired_ciphertext & 0xFFFFFFFF) ^ paired_v
        target = v ^ paired_v ^ 0x02000000
        candidates = [k for k in candidates
                      if f(u ^ k) ^ f(paired_u ^ k) == target]

    if not candidates:
        raise ValueError("Oracle does not match the specified FEAL cipher")
    return candidates[0]
