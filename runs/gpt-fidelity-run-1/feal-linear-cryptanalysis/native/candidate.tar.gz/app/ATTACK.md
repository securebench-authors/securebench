The recovered 20-bit seeds, in encryption round order, are:

```
68e63 62571 1f61c b74a5
```

Their expanded 32-bit round keys are:

```
b24dca68 0d14a358 a888fa20 5cc59c18
```

Reproduce the attack and output with:

```sh
cd /app
cc -O3 -std=c11 -Wall -Wextra attack.c -o attack
./attack pairs.txt ciphertexts.txt plaintexts.txt
```

The output contains one unsigned decimal plaintext per ciphertext, in the
original order, matching the format produced by decrypt.c.

Let x0 be the plaintext's upper half and x1 the XOR of its halves.
The four rounds satisfy x(i+2) = xi XOR F(x(i+1) XOR ki).
The ciphertext gives x5 as its upper half and x4 as the XOR of its halves.

Write A.z for the parity of A AND z. Each of these mask pairs obeys
A.F(z) = B.z XOR c for every z:

| A | B | c |
| --- | --- | --- |
| 00040000 | 01010101 | 1 |
| 04000400 | 01000101 | 0 |
| 00010400 | 00000101 | 0 |
| 04010000 | 01000000 | 0 |
| 00000104 | 00000001 | 1 |

These exact linear relations follow directly from bit 2 of a byte after
rotation by two: it equals bit 0 before rotation, where addition has no
incoming carries. Substitution into the round equations yields:

```
A.(x5 XOR x1) XOR B.(x4 XOR x2) = B.(k1 XOR k3)
A.(x4 XOR x0) XOR B.(x3 XOR x1) = B.(k0 XOR k2)
```

Enumerate all 2^20 seeds for k0, compute x2, and require the first expression
to remain constant across every known pair for all five mask pairs.
Independently enumerate k3, compute x3 backwards, and apply the second
expression. Each search leaves exactly one seed for this dataset.

With x2 and x3 now known, independently enumerate k1 and k2 using the full
32-bit equations F(x2 XOR k1) = x3 XOR x1 and
F(x3 XOR k2) = x4 XOR x2. Each search again leaves one seed. The attack
therefore enumerates four individual 20-bit spaces, rather than their
80-bit Cartesian product. In general its middle-key work scales with the
number of surviving outer-key combinations.

The recovered full key encrypts and decrypts all 32 known pairs exactly.
All 100 target blocks were decrypted and re-encrypted successfully. As an
independent implementation check, their plaintexts also match the supplied
decrypt.c output byte for byte; the supplied feal executable reproduces
all 32 known ciphertexts with the recovered seeds.
