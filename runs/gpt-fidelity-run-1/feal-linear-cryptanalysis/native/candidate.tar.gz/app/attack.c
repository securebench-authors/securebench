/* Known-plaintext linear attack on the supplied four-round FEAL variant.
 * Build: cc -O3 -std=c11 attack.c -o attack
 * Run:   ./attack [pairs.txt] [ciphertexts.txt] [plaintexts.txt]
 *
 * Write the Feistel states as x0=L, x1=L^R, and
 * x(i+2)=xi ^ F(x(i+1)^ki).  The ciphertext exposes x5 and x4^x5.
 * For each mask pair below, parity(A & F(z)) = parity(B & z) ^ c.
 * These identities follow from bit 2 of rotl8(a+b+c,2), which is
 * bit 0 of a+b+c and thus has no carries.  Their constants cancel:
 *
 * A.(x5^x1) ^ B.(x4^x2) = B.(k1^k3),
 * A.(x4^x0) ^ B.(x3^x1) = B.(k0^k2).
 *
 * Guessing k0 supplies x2; guessing k3 supplies x3.  Each expression
 * must be constant over every known pair.  This takes O(N * 2^20)
 * work, with early rejection, instead of searching 2^80 key tuples.
 * Finally enumerate k1 and k2 against the now-known round inputs and
 * outputs, and verify every surviving full key by actual encryption.
 */
#define main supplied_feal_main
#include "feal.c"
#undef main
#include <inttypes.h>

#define MAX_PAIRS 1024
#define MAX_CANDIDATES 4096
static const uint32_t amask[] = {
    0x00040000, 0x04000400, 0x00010400, 0x04010000, 0x00000104
};
static const uint32_t bmask[] = {
    0x01010101, 0x01000101, 0x00000101, 0x01000000, 0x00000001
};
typedef struct {
    uint64_t p, c;
    uint32_t x0, x1, x4, x5;
} Pair;
static Pair pairs[MAX_PAIRS];
static size_t count;

/* Pack all five linear equations into five bits. */
static unsigned linear_bits(uint32_t a, uint32_t b) {
    unsigned r = 0;
    for (unsigned j = 0; j < 5; ++j)
        r |= (unsigned)__builtin_parity((a & amask[j]) ^ (b & bmask[j])) << j;
    return r;
}

static size_t outer_candidates(int last, uint32_t *seeds) {
    size_t n = 0;
    for (uint32_t seed = 0; seed < (1u << 20); ++seed) {
        uint32_t k = expand(seed);
        unsigned reference = 0;
        size_t i;
        for (i = 0; i < count; ++i) {
            Pair *p = &pairs[i];
            unsigned bits;
            if (!last) {
                uint32_t x2 = p->x0 ^ f_function(p->x1 ^ k);
                bits = linear_bits(p->x5 ^ p->x1, p->x4 ^ x2);
            } else {
                uint32_t x3 = p->x5 ^ f_function(p->x4 ^ k);
                bits = linear_bits(p->x4 ^ p->x0, x3 ^ p->x1);
            }
            if (i == 0) reference = bits;
            else if (bits != reference) break;
        }
        if (i == count) {
            if (n == MAX_CANDIDATES) {
                fprintf(stderr, "Too many outer candidates\n");
                exit(1);
            }
            seeds[n++] = seed;
        }
    }
    return n;
}

static uint64_t decrypt_block(uint64_t c) {
    uint32_t r = c >> 32, l = (uint32_t)c ^ r;
    for (int j = 3; j >= 0; --j) {
        uint32_t old_r = l;
        l = r ^ f_function(l ^ key[j]);
        r = old_r;
    }
    return merge(l, r ^ l);
}

int main(int argc, char **argv) {
    const char *pair_path = argc > 1 ? argv[1] : "pairs.txt";
    const char *cipher_path = argc > 2 ? argv[2] : "ciphertexts.txt";
    const char *plain_path = argc > 3 ? argv[3] : "plaintexts.txt";
    FILE *fp = fopen(pair_path, "r");
    if (!fp) { perror(pair_path); return 1; }
    uint64_t p, c;
    int scanned;
    while ((scanned = fscanf(fp, "%" SCNu64 " %" SCNu64, &p, &c)) == 2) {
        if (count == MAX_PAIRS) { fprintf(stderr, "Too many pairs\n"); return 1; }
        pairs[count++] = (Pair){p, c, p >> 32, (uint32_t)p ^ (uint32_t)(p >> 32),
                               (uint32_t)c ^ (uint32_t)(c >> 32), c >> 32};
    }
    fclose(fp);
    if (scanned != EOF || count < 2) { fprintf(stderr, "Invalid pair file\n"); return 1; }
    uint32_t first[MAX_CANDIDATES], last[MAX_CANDIDATES];
    size_t nf = outer_candidates(0, first), nl = outer_candidates(1, last);
    fprintf(stderr, "Linear filtering: %zu first-round and %zu last-round seeds\n", nf, nl);
    uint32_t recovered[4] = {0};
    size_t solutions = 0;
    for (size_t a = 0; a < nf; ++a) for (size_t b = 0; b < nl; ++b) {
        uint32_t x2[MAX_PAIRS], x3[MAX_PAIRS];
        uint32_t middle[2][MAX_CANDIDATES];
        size_t nm[2] = {0, 0};
        for (size_t i = 0; i < count; ++i) {
            x2[i] = pairs[i].x0 ^ f_function(pairs[i].x1 ^ expand(first[a]));
            x3[i] = pairs[i].x5 ^ f_function(pairs[i].x4 ^ expand(last[b]));
        }
        for (unsigned round = 0; round < 2; ++round) {
            for (uint32_t s = 0; s < (1u << 20); ++s) {
                uint32_t k = expand(s);
                size_t i;
                for (i = 0; i < count; ++i) {
                    uint32_t in = round ? x3[i] : x2[i];
                    uint32_t out = round ? pairs[i].x4 ^ x2[i] : x3[i] ^ pairs[i].x1;
                    if (f_function(in ^ k) != out) break;
                }
                if (i == count) {
                    if (nm[round] == MAX_CANDIDATES) { fprintf(stderr, "Too many middle candidates\n"); return 1; }
                    middle[round][nm[round]++] = s;
                }
            }
        }
        for (size_t m = 0; m < nm[0]; ++m) for (size_t n = 0; n < nm[1]; ++n) {
            set_keys(first[a], middle[0][m], middle[1][n], last[b]);
            size_t i;
            for (i = 0; i < count; ++i)
                if (encrypt(pairs[i].p) != pairs[i].c || decrypt_block(pairs[i].c) != pairs[i].p) break;
            if (i != count) continue;
            ++solutions;
            recovered[0] = first[a]; recovered[1] = middle[0][m];
            recovered[2] = middle[1][n]; recovered[3] = last[b];
            fprintf(stderr, "Verified seeds: %05x %05x %05x %05x (%zu pairs)\n",
                    recovered[0], recovered[1], recovered[2], recovered[3], count);
        }
    }
    if (solutions != 1) { fprintf(stderr, "Expected one key, found %zu\n", solutions); return 1; }
    set_keys(recovered[0], recovered[1], recovered[2], recovered[3]);
    fprintf(stderr, "Expanded keys: %08x %08x %08x %08x\n", key[0], key[1], key[2], key[3]);
    fp = fopen(cipher_path, "r");
    if (!fp) { perror(cipher_path); return 1; }
    FILE *out = fopen(plain_path, "w");
    if (!out) { perror(plain_path); fclose(fp); return 1; }
    size_t blocks = 0;
    while ((scanned = fscanf(fp, "%" SCNu64, &c)) == 1) {
        p = decrypt_block(c);
        if (encrypt(p) != c) { fprintf(stderr, "Round-trip check failed\n"); return 1; }
        fprintf(out, "%" PRIu64 "\n", p);
        ++blocks;
    }
    fclose(fp);
    if (fclose(out) || scanned != EOF) { fprintf(stderr, "File I/O error\n"); return 1; }
    fprintf(stderr, "Decrypted and round-trip verified %zu blocks into %s\n", blocks, plain_path);
    return 0;
}
