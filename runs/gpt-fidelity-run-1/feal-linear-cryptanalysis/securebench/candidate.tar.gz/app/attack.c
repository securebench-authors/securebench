/* Known-plaintext linear attack on feal.c.
 *
 * Write the Feistel states as X0 = P_hi, X1 = P_hi ^ P_lo and
 * X(i+2) = Xi ^ F(X(i+1) ^ ki).  Undoing the output mixing gives
 * X5 = C_hi and X4 = C_hi ^ C_lo.
 *
 * For each (A,B,c) below, parity(A & F(x)) = parity(B & x) ^ c
 * holds exactly: the low bit of an addition becomes bit 2 after ROL2.
 * XORing this relation for rounds 0 and 2 gives
 *   A.(X0 ^ X4) ^ B.(X1 ^ X3) = B.(k0 ^ k2).
 * Guess k3 to obtain X3 and test whether the left side is constant
 * over all known pairs.  Rounds 1 and 3 similarly give
 *   A.(X1 ^ X5) ^ B.(X2 ^ X4) = B.(k1 ^ k3),
 * allowing an independent guess of k0 to obtain X2.
 * The remaining keys follow by testing the complete middle-round F
 * equations.  This searches individual 20-bit spaces, not 80-bit keys.
 *
 * Build: cc -O3 -std=c11 -Wall -Wextra attack.c -o attack
 * Run:   ./attack [pairs.txt [ciphertexts.txt [plaintexts.txt]]]
 */
#include <inttypes.h>
#include <string.h>

/* Reuse the actual encryption, expansion and round function. */
#define main feal_command_main
#include "feal.c"
#undef main

enum { MAX_PAIRS = 1024, SEEDS = 1 << 20 };
typedef struct { uint64_t p, c; uint32_t x0, x1, x4, x5; } Pair;
static Pair pairs[MAX_PAIRS];
static size_t npairs;
static const uint32_t amask[4] = {
    0x00040000, 0x04010000, 0x00010400, 0x00000104
};
static const uint32_t bmask[4] = {
    0x01010101, 0x01000000, 0x00000101, 0x00000001
};

static unsigned signature(uint32_t a, uint32_t b) {
    unsigned result = 0;
    for (unsigned j = 0; j < 4; ++j)
        result |= (unsigned)__builtin_parity((a & amask[j]) ^
                                             (b & bmask[j])) << j;
    return result;
}

static unsigned invariant(const Pair *p, uint32_t k, int round) {
    if (round == 0) {
        uint32_t x2 = p->x0 ^ f_function(p->x1 ^ k);
        return signature(p->x1 ^ p->x5, x2 ^ p->x4);
    }
    uint32_t x3 = p->x5 ^ f_function(p->x4 ^ k);
    return signature(p->x0 ^ p->x4, p->x1 ^ x3);
}

static size_t outer_candidates(int round, uint32_t *out) {
    size_t count = 0;
    for (uint32_t seed = 0; seed < SEEDS; ++seed) {
        uint32_t k = expand(seed);
        unsigned expected = invariant(&pairs[0], k, round);
        size_t i;
        for (i = 1; i < npairs; ++i)
            if (invariant(&pairs[i], k, round) != expected) break;
        if (i == npairs) out[count++] = seed;
    }
    fprintf(stderr, "Round %d: %zu linear-attack candidates\n", round, count);
    return count;
}

static int middle_matches(uint32_t k, int round, uint32_t k0, uint32_t k3) {
    for (size_t i = 0; i < npairs; ++i) {
        const Pair *p = &pairs[i];
        uint32_t x2 = p->x0 ^ f_function(p->x1 ^ k0);
        uint32_t x3 = p->x5 ^ f_function(p->x4 ^ k3);
        if (round == 1) {
            if (f_function(x2 ^ k) != (p->x1 ^ x3)) return 0;
        } else if (f_function(x3 ^ k) != (x2 ^ p->x4)) return 0;
    }
    return 1;
}

static uint64_t decrypt_block(uint64_t c) {
    uint32_t right = getleft(c), left = getright(c) ^ right;
    for (int r = 3; r >= 0; --r) {
        uint32_t previous_left = right ^ f_function(left ^ key[r]);
        right = left;
        left = previous_left;
    }
    return merge(left, right ^ left);
}

int main(int argc, char **argv) {
    if (argc > 4) {
        fprintf(stderr, "Usage: %s [pairs [ciphertexts [plaintexts]]]\n", argv[0]);
        return 1;
    }
    const char *pairpath = argc > 1 ? argv[1] : "pairs.txt";
    const char *cipherpath = argc > 2 ? argv[2] : "ciphertexts.txt";
    const char *plainpath = argc > 3 ? argv[3] : "plaintexts.txt";
    FILE *fp = fopen(pairpath, "r");
    if (!fp) { perror(pairpath); return 1; }
    uint64_t p, c;
    int status;
    while ((status = fscanf(fp, "%" SCNu64 " %" SCNu64, &p, &c)) == 2) {
        if (npairs == MAX_PAIRS) {
            fprintf(stderr, "Too many known pairs\n"); fclose(fp); return 1;
        }
        pairs[npairs++] = (Pair){p, c, getleft(p), getleft(p) ^ getright(p),
                                getleft(c) ^ getright(c), getleft(c)};
    }
    fclose(fp);
    if (status != EOF || npairs < 2) {
        fprintf(stderr, "Malformed or insufficient known pairs\n"); return 1;
    }
    uint32_t *c0 = malloc(SEEDS * sizeof(*c0));
    uint32_t *c3 = malloc(SEEDS * sizeof(*c3));
    if (!c0 || !c3) { fprintf(stderr, "Out of memory\n"); return 1; }
    size_t n0 = outer_candidates(0, c0), n3 = outer_candidates(3, c3);
    uint32_t recovered[4] = {0};
    size_t solutions = 0;
    for (size_t a = 0; a < n0; ++a) for (size_t b = 0; b < n3; ++b) {
        uint32_t k0 = expand(c0[a]), k3 = expand(c3[b]);
        /* Find k1 first: reject incompatible outer keys before scanning k2. */
        for (uint32_t s1 = 0; s1 < SEEDS; ++s1) {
            if (!middle_matches(expand(s1), 1, k0, k3)) continue;
            for (uint32_t s2 = 0; s2 < SEEDS; ++s2) {
                if (!middle_matches(expand(s2), 2, k0, k3)) continue;
                set_keys(c0[a], s1, s2, c3[b]);
                size_t i;
                for (i = 0; i < npairs; ++i)
                    if (encrypt(pairs[i].p) != pairs[i].c ||
                        decrypt_block(pairs[i].c) != pairs[i].p) break;
                if (i != npairs) continue;
                ++solutions;
                recovered[0] = c0[a]; recovered[1] = s1;
                recovered[2] = s2; recovered[3] = c3[b];
                fprintf(stderr, "Verified seeds: %05" PRIx32 " %05" PRIx32
                        " %05" PRIx32 " %05" PRIx32 "\n",
                        c0[a], s1, s2, c3[b]);
            }
        }
    }
    free(c0); free(c3);
    if (solutions != 1) {
        fprintf(stderr, "Expected one key, found %zu\n", solutions); return 1;
    }
    set_keys(recovered[0], recovered[1], recovered[2], recovered[3]);
    fprintf(stderr, "Verified encryption and decryption of all %zu known pairs.\n",
            npairs);
    fprintf(stderr, "Expanded keys: %08" PRIx32 " %08" PRIx32 " %08" PRIx32
            " %08" PRIx32 "\n", key[0], key[1], key[2], key[3]);
    fp = fopen(cipherpath, "r");
    if (!fp) { perror(cipherpath); return 1; }
    FILE *out = fopen(plainpath, "w");
    if (!out) { perror(plainpath); fclose(fp); return 1; }
    size_t blocks = 0;
    while ((status = fscanf(fp, "%" SCNu64, &c)) == 1) {
        p = decrypt_block(c);
        if (encrypt(p) != c || fprintf(out, "%" PRIu64 "\n", p) < 0) {
            fprintf(stderr, "Decryption/output failure\n");
            fclose(fp); fclose(out); return 1;
        }
        ++blocks;
    }
    fclose(fp);
    int output_status = fclose(out);
    if (status != EOF || output_status) {
        fprintf(stderr, "Input/output error\n"); return 1;
    }
    fprintf(stderr, "Wrote %zu plaintexts to %s (all re-encrypt correctly).\n",
            blocks, plainpath);
    return 0;
}
