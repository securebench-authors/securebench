The recovered 20-bit round-key seeds, in encryption order, are:

```
68e63 62571 1f61c b74a5
```

Their expanded 32-bit round keys are:

```
b24dca68 0d14a358 a888fa20 5cc59c18
```

Build and reproduce the attack from `/app`:

```sh
cc -O3 -std=c11 -Wall -Wextra attack.c -o attack
./attack pairs.txt ciphertexts.txt plaintexts.txt
```

The output file contains one unsigned decimal plaintext block per line,
matching the format used by `decrypt.c`.

The attack uses exact linear relations, rather than an exhaustive search
of the combined 80-bit key space. Write `A.x` for the parity of `A & x`.
The round function satisfies `A.F(x) = B.x XOR c` for these masks:

| A | B | c |
|---|---|---|
| 00040000 | 01010101 | 1 |
| 04010000 | 01000000 | 0 |
| 00010400 | 00000101 | 0 |
| 00000104 | 00000001 | 1 |

These identities follow from the least significant bit of each addition
in `g_function`: addition has no incoming carry at that bit, and rotating
left by two moves it to output bit 2.

Define `X0 = P_hi`, `X1 = P_hi XOR P_lo`, and
`X(i+2) = Xi XOR F(X(i+1) XOR ki)`. From a ciphertext, the known final
states are `X5 = C_hi` and `X4 = C_hi XOR C_lo`.

XORing the identities for rounds 0 and 2 eliminates X2 and gives:

```
A.(X0 XOR X4) XOR B.(X1 XOR X3) = B.(k0 XOR k2)
```

For each candidate seed for k3, calculate `X3 = X5 XOR F(X4 XOR k3)`.
The left side must be constant across all known pairs for all four masks.
Only one of the 2^20 seeds survives. Applying the same reasoning to
rounds 1 and 3 gives:

```
A.(X1 XOR X5) XOR B.(X2 XOR X4) = B.(k1 XOR k3)
```

Guessing k0 supplies `X2 = X0 XOR F(X1 XOR k0)`, again leaving one seed.
With X2 and X3 known, search each middle seed space independently using
the complete equations `F(X2 XOR k1) = X1 XOR X3` and
`F(X3 XOR k2) = X2 XOR X4`. This finds exactly one full key on this data.

Validation: the recovered key encrypts and decrypts all 32 known pairs
correctly. All 100 target plaintexts re-encrypt to their input ciphertexts.
Compiling and running the supplied `decrypt.c` with the recovered seeds
also produces a byte-for-byte identical `plaintexts.txt`.
