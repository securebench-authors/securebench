#!/usr/bin/env python3
"""Remove active HTML content in place, without serializing the document.

Usage: python filter.py FILE.html

Only source ranges are deleted: surviving characters, whitespace, entities,
attribute order, quoting, encoding, and line endings are preserved. Intended for
HTML documents, not JavaScript templates or XML/XHTML served as XML. No static
filter can control scripts in remote pages, later DOM mutations, or browser
extensions; applications rendering untrusted HTML should also use a restrictive
Content Security Policy.
"""

from __future__ import annotations

import html
import re
import sys
from pathlib import Path


SPACE = "\t\n\f\r "
TAG_START = re.compile(r"<(/?)([A-Za-z][^\t\n\f\r />\x00]*)")
COMMENT_END = re.compile(r"--!?>")
SCHEME = re.compile(r"^(?:javascript|vbscript|livescript|mocha):", re.I)
CSS_COMMENT = re.compile(r"/\*.*?(?:\*/|$)", re.S)
CSS_ESCAPE = re.compile(r"\\(?:([0-9a-fA-F]{1,6})(?:\r\n|[\t\n\f\r ])?|([^\n\r\f0-9a-fA-F]))")
URL_ATTRIBUTES = frozenset({
    "href", "src", "action", "formaction", "background", "poster", "data",
    "codebase", "classid", "profile", "manifest", "longdesc", "usemap",
    "dynsrc", "lowsrc", "base", "icon", "ping", "archive", "srcset",
    "imagesrcset",
})
SAFE_DATA = re.compile(
    r"^data:(?:image/(?:png|gif|jpe?g|webp|avif|bmp|x-icon)|"
    r"audio/(?:mpeg|ogg|wav|webm)|video/(?:mp4|ogg|webm)|text/plain)"
    r"(?:[;,]|$)", re.I,
)
VOID = frozenset({
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr",
})
RAWTEXT = frozenset({
    "style", "textarea", "title", "xmp", "iframe", "noembed", "noframes", "noscript",
})
ACTIVE_CONTAINERS = frozenset({"script", "object", "applet"})
ANIMATIONS = frozenset({"animate", "set", "animatetransform", "animatemotion"})


def decode_entities(value: str) -> str:
    # Normalize numeric references before html.unescape: Python limits the
    # number of decimal digits accepted by int(), whereas HTML does not.
    def numeric(match: re.Match[str]) -> str:
        hexadecimal = match[1] is not None
        digits = (match[1] if hexadecimal else match[2]).lstrip("0") or "0"
        if len(digits) > (6 if hexadecimal else 7):
            return "\ufffd"
        return "&#" + ("x" if hexadecimal else "") + digits + ";"

    value = re.sub(r"&#(?:[xX]([0-9a-fA-F]+)|([0-9]+));?", numeric, value)
    return html.unescape(value)


def unsafe_url(value: str) -> bool:
    """Apply HTML URL preprocessing, including entity-obfuscated schemes."""
    value = value.replace("\t", "").replace("\r", "").replace("\n", "")
    value = value.strip("".join(chr(n) for n in range(33)))
    return bool(SCHEME.match(value) or (
        value.lower().startswith("data:") and not SAFE_DATA.match(value)
    ))


def unsafe_css(value: str) -> bool:
    value = CSS_COMMENT.sub("", value)

    def unescape(match: re.Match[str]) -> str:
        if match[1]:
            number = int(match[1], 16)
            return chr(number) if 0 < number <= 0x10FFFF else "\ufffd"
        return match[2]

    value = CSS_ESCAPE.sub(unescape, value).lower()
    compact = re.sub(r"[\x00-\x20\x7f]+", "", value)
    if re.search(r"expression\(|(?:^|[;{])(?:behavior|-moz-binding):", compact):
        return True
    # Includes legacy CSS script URLs, escaped schemes, and active data URLs.
    for match in re.finditer(r"(?:url\(|@import)(?:\s|[\"'])*([^\)\"']*)", value):
        if unsafe_url(match[1]):
            return True
    return False


def tag_end(source: str, start: int) -> int:
    """Find the end of a tag using HTML's attribute quoting rules."""
    # A quote starts quoting only at the start of an attribute value. Quotes
    # inside an unquoted value are ordinary characters in the HTML tokenizer.
    pos = start
    state = "before"
    quote = ""
    while pos < len(source):
        char = source[pos]
        if state == "quoted":
            if char == quote:
                state = "before"
        elif char == ">":
            return pos + 1
        elif state == "value":
            if char in SPACE:
                pass
            elif char in "\"'":
                quote, state = char, "quoted"
            else:
                state = "unquoted"
        elif state == "unquoted":
            if char in SPACE:
                state = "before"
        elif state == "name":
            if char in SPACE:
                state = "after_name"
            elif char == "/":
                state = "before"
            elif char == "=":
                state = "value"
        elif state == "after_name":
            if char == "=":
                state = "value"
            elif char == "/":
                state = "before"
            elif char not in SPACE:
                state = "name"
        elif char not in SPACE + "/":
            state = "name"
        pos += 1
    return len(source)


def attributes(source: str, start: int, end: int):
    """Yield (name, decoded value, source start, source end), including duplicates."""
    pos = start
    limit = end - 1 if source[end - 1:end] == ">" else end
    while pos < limit:
        while pos < limit and source[pos] in SPACE + "/":
            pos += 1
        if pos >= limit:
            break
        begin = pos
        # '=' at the start of a name is a parse error but is part of its name.
        pos += 1
        while pos < limit and source[pos] not in SPACE + "=/":
            pos += 1
        name = source[begin:pos].lower()
        name_end = pos
        while pos < limit and source[pos] in SPACE:
            pos += 1
        value = ""
        if pos < limit and source[pos] == "=":
            pos += 1
            while pos < limit and source[pos] in SPACE:
                pos += 1
            if pos < limit and source[pos] in "\"'":
                quote = source[pos]
                pos += 1
                value_start = pos
                while pos < limit and source[pos] != quote:
                    pos += 1
                value = source[value_start:pos]
                if pos < limit:
                    pos += 1
            else:
                value_start = pos
                while pos < limit and source[pos] not in SPACE:
                    pos += 1
                value = source[value_start:pos]
            attr_end = pos
        else:
            attr_end = name_end
        yield name, decode_entities(value), begin, attr_end


def closing_tag(source: str, name: str, start: int):
    pattern = re.compile(r"</" + re.escape(name) + r"(?=[\t\n\f\r />])", re.I)
    match = pattern.search(source, start)
    return (match.start(), tag_end(source, match.end())) if match else None


def _sanitize(source: str, depth: int) -> str:
    cuts: list[tuple[int, int]] = []
    stack: list[tuple[str, bool]] = []
    in_select = False
    pos = 0
    while pos < len(source):
        start = source.find("<", pos)
        if start < 0:
            break
        if source.startswith("<!--", start):
            # HTML also accepts abrupt empty comments and --!> terminators.
            if source[start + 4:start + 5] == ">":
                pos = start + 5
            elif source[start + 4:start + 6] == "->":
                pos = start + 6
            else:
                end = COMMENT_END.search(source, start + 4)
                pos = end.end() if end else len(source)
            continue
        if source.startswith(("<!", "<?"), start):
            # Declarations and bogus HTML comments end at the first '>'.
            end = source.find(">", start + 2)
            pos = end + 1 if end >= 0 else len(source)
            continue
        match = TAG_START.match(source, start)
        if not match:
            pos = start + 1
            continue
        name = match[2].lower()
        end = tag_end(source, match.end())
        pos = end
        if match[1]:
            if name == "select":
                in_select = False
            for index in range(len(stack) - 1, -1, -1):
                if stack[index][0] == name:
                    del stack[index:]
                    break
            continue
        attrs = list(attributes(source, match.end(), end))
        values = {}
        for key, value, _, _ in attrs:
            values.setdefault(key, value)  # Browsers use the first duplicate.
        foreign = stack[-1][1] if stack else False
        if name in {"svg", "math"}:
            foreign = True
        self_closed = foreign and source[max(start, end - 2):end] == "/>"
        if name == "select":
            in_select = not in_select
        elif name in {"input", "keygen", "textarea"}:
            in_select = False
        if name in ACTIVE_CONTAINERS:
            close = closing_tag(source, name, end)
            if self_closed:
                stop = end
            elif close:
                stop = close[1]
            else:
                stop = len(source)
            cuts.append((start, stop))
            pos = stop
            continue
        if name == "embed" or (
            name == "link" and "import" in values.get("rel", "").lower().split()
        ):
            cuts.append((start, end))
            continue
        if name in ANIMATIONS:
            target = values.get("attributename", "").lower().split(":")[-1]
            if target.startswith("on") or target in URL_ATTRIBUTES | {"style", "srcdoc"}:
                cuts.append((start, end))
                continue
        for key, value, begin, finish in attrs:
            local = key.split(":")[-1]
            dangerous = local.startswith("on")
            if local in URL_ATTRIBUTES:
                dangerous |= unsafe_url(value)
                if local in {"ping", "archive", "srcset", "imagesrcset"}:
                    dangerous |= any(unsafe_url(part) for part in re.split(r"[\s,]+", value))
            if local == "style":
                dangerous |= unsafe_css(value)
            if local == "srcdoc":
                dangerous |= depth >= 16 or sanitize_html(value, depth + 1) != value
            if name == "meta" and local == "content":
                if values.get("http-equiv", "").strip().lower() == "refresh":
                    refresh = re.search(r";\s*(?:url\s*=\s*)?(.*)", value, re.I | re.S)
                    dangerous |= bool(refresh and unsafe_url(refresh[1].strip().strip("\"'")))
            if dangerous:
                cuts.append((begin, finish))
        if name in RAWTEXT and not foreign and not in_select:
            close = closing_tag(source, name, end)
            content_end = close[0] if close else len(source)
            if name == "style" and unsafe_css(source[end:content_end]):
                cuts.append((start, close[1] if close else len(source)))
            # Raw text and RCDATA cannot contain executable HTML tags.
            pos = close[1] if close else len(source)
            continue
        if name == "plaintext" and not foreign and not in_select:
            break
        if name not in VOID and not self_closed:
            child_foreign = foreign
            if name in {"foreignobject", "desc", "title"} and foreign:
                child_foreign = False
            if name == "annotation-xml" and values.get("encoding", "").lower() in {
                "text/html", "application/xhtml+xml",
            }:
                child_foreign = False
            stack.append((name, child_foreign))
    if not cuts:
        return source
    result = []
    pos = 0
    for start, end in sorted(cuts):
        if start > pos:
            result.append(source[pos:start])
        pos = max(pos, end)
    result.append(source[pos:])
    return "".join(result)


def sanitize_html(source: str, depth: int = 0) -> str:
    """Delete unsafe source ranges until deletion exposes no further markup."""
    while True:
        cleaned = _sanitize(source, depth)
        if cleaned == source:
            return cleaned
        source = cleaned


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv if argv is None else argv
    if len(argv) != 2:
        print(f"Usage: {Path(argv[0]).name} FILE.html", file=sys.stderr)
        return 2
    path = Path(argv[1])
    try:
        original = path.read_bytes()
        # Latin-1 is a lossless byte mapping for ASCII-compatible encodings;
        # BOM-marked UTF-16/32 also retain their original encoding and BOM.
        encoding = "latin-1"
        for marker, candidate in (
            (b"\xff\xfe\x00\x00", "utf-32"), (b"\x00\x00\xfe\xff", "utf-32"),
            (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16"),
        ):
            if original.startswith(marker):
                encoding = candidate + ("-le" if marker.startswith(b"\xff") else "-be")
                break
        text = original.decode(encoding)
        cleaned = sanitize_html(text).encode(encoding)
        if cleaned != original:
            with path.open("r+b") as handle:
                handle.write(cleaned)
                handle.truncate()
    except (OSError, UnicodeError) as error:
        print(f"{path}: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
