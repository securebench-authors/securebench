#!/usr/bin/env python3
"""Remove active HTML content in place without reserializing the document.

Only deletions are made. Safe markup, whitespace, quoting, and line endings are
kept verbatim. Embedded browsing contexts and foreign SVG/MathML content are
removed conservatively because they have additional executable-content rules.
This is an HTML filter; serve its output as HTML, not as JavaScript or XML.
"""

import codecs
import html
import re
import sys
from pathlib import Path


SPACE = ' \t\n\r\f'
# These elements can execute code, load an executable document, or change the
# parsing rules in ways that make an ordinary HTML attribute filter insufficient.
BLOCKED = {'script', 'iframe', 'object', 'applet', 'svg', 'math',
           'noscript', 'noembed', 'noframes'}
VOID_BLOCKED = {'embed', 'base'}
RAW_TEXT = {'textarea', 'title', 'xmp', 'style'}
URL_ATTRS = {'href', 'src', 'action', 'formaction', 'poster', 'background',
             'cite', 'longdesc', 'usemap', 'profile', 'codebase', 'classid',
             'data', 'manifest', 'xlink:href', 'xml:base', 'lowsrc', 'dynsrc'}
SAFE_SCHEMES = {'http', 'https', 'mailto', 'tel', 'ftp', 'ftps', 'sms',
                'irc', 'ircs', 'xmpp', 'news', 'nntp', 'cid'}
SCHEME = re.compile(r'^([a-z][a-z0-9+.-]*):', re.I)
CSS_ESCAPE = re.compile(r'\\([0-9a-fA-F]{1,6})(?:\r\n|[ \t\r\n\f])?|\\([^\r\n\f])|\\(?:\r\n|[\r\n\f])')


def decoded(value):
    return html.unescape(value).replace('\x00', '\ufffd')


def safe_url(value):
    # Browsers discard tabs/newlines in schemes and leading C0 controls.
    value = re.sub(r'[\x00-\x20\x7f-\x9f]', '', decoded(value)).lower()
    match = SCHEME.match(value)
    if not match:
        return True
    if match[1] in SAFE_SCHEMES:
        return True
    # Raster images cannot contain HTML or SVG scripts.
    return bool(re.match(r'^data:image/(?:png|gif|jpeg|webp|avif|bmp|x-icon|vnd\.microsoft\.icon);base64,', value))


def unsafe_css(value):
    value = decoded(value)
    def unescape(match):
        if match[1]:
            code = int(match[1], 16)
            return chr(code) if 0 < code <= 0x10ffff else '\ufffd'
        return match[2] or ''
    value = CSS_ESCAPE.sub(unescape, value)
    value = re.sub(r'/\*.*?\*/', '', value, flags=re.S).lower()
    if re.search(r'expression\s*\(|(?:-moz-binding|behavior)\s*:|@import\b', value):
        return True
    for match in re.finditer(r'url\s*\(\s*([\s\S]*?)(?:\)|$)', value):
        if not safe_url(match[1].strip().strip('\'"')):
            return True
    return False


def tag_at(source, start):
    """Read an HTML tag and attribute source offsets, following HTML token rules."""
    size = len(source)
    pos = start + 1
    closing = pos < size and source[pos] == '/'
    if closing:
        pos += 1
    if pos == size or not source[pos].isascii() or not source[pos].isalpha():
        return None
    begin = pos
    while pos < size and source[pos] not in SPACE + '/>':
        pos += 1
    name = source[begin:pos].lower()
    attrs = []
    while pos < size:
        while pos < size and source[pos] in SPACE + '/':
            pos += 1
        if pos == size:
            break
        if source[pos] == '>':
            return name, closing, pos + 1, attrs
        begin = pos
        # An initial '=' is part of the attribute name (HTML parse error).
        pos += 1
        while pos < size and source[pos] not in SPACE + '/>=':
            pos += 1
        attr_name = source[begin:pos].lower()
        name_end = pos
        while pos < size and source[pos] in SPACE:
            pos += 1
        value = ''
        end = name_end
        if pos < size and source[pos] == '=':
            pos += 1
            while pos < size and source[pos] in SPACE:
                pos += 1
            if pos < size and source[pos] in '\'"':
                quote = source[pos]
                pos += 1
                value_start = pos
                while pos < size and source[pos] != quote:
                    pos += 1
                value = source[value_start:pos]
                if pos < size:
                    pos += 1
            else:
                value_start = pos
                while pos < size and source[pos] not in SPACE + '>':
                    pos += 1
                value = source[value_start:pos]
            end = pos
        attrs.append((attr_name, value, begin, end))
    # An unterminated tag is not emitted by an HTML browser tokenizer.
    return name, closing, size, attrs


def raw_end(source, name, start):
    match = re.search(r'</' + re.escape(name) + r'(?=[\t\n\f\r />])', source[start:], re.I)
    if match is None:
        return len(source), len(source)
    begin = start + match.start()
    tag = tag_at(source, begin)
    return begin, tag[2] if tag else len(source)


def sanitize_once(source):
    cuts = []
    pos = 0
    size = len(source)
    while pos < size:
        start = source.find('<', pos)
        if start < 0:
            break
        if source.startswith('<!--', start):
            # HTML also recognizes --!> and abrupt empty comment endings.
            body = start + 4
            if source.startswith('>', body):
                pos = body + 1
            elif source.startswith('->', body):
                pos = body + 2
            else:
                end = re.search(r'--!?>', source[body:])
                pos = body + end.end() if end else size
            continue
        if source.startswith(('<!', '<?'), start):
            end = source.find('>', start + 2)
            pos = end + 1 if end >= 0 else size
            continue
        tag = tag_at(source, start)
        if tag is None:
            # Invalid closing tags are bogus comments, ending at the first >.
            if source.startswith('</', start) and start + 2 < size and source[start + 2] != '>':
                end = source.find('>', start + 2)
                pos = end + 1 if end >= 0 else size
            else:
                pos = start + 1
            continue
        name, closing, end, attrs = tag
        pos = end
        if name in BLOCKED:
            if not closing:
                _, pos = raw_end(source, name, end)
            cuts.append((start, pos))
            continue
        if name in VOID_BLOCKED:
            cuts.append((start, end))
            continue
        if closing:
            continue
        values = {}
        for attr, value, _, _ in attrs:
            values.setdefault(attr, decoded(value).lower())
        if name == 'meta' and values.get('http-equiv', '').strip() == 'refresh':
            cuts.append((start, end))
            continue
        if name == 'link' and ('import' in values.get('rel', '').split()
                               or 'modulepreload' in values.get('rel', '').split()
                               or values.get('as', '').strip() == 'script'):
            cuts.append((start, end))
            continue
        for attr, value, begin, attr_end in attrs:
            unsafe = attr.startswith('on') or attr in {'srcdoc', 'allow', 'is'}
            if attr in URL_ATTRS:
                unsafe |= not safe_url(value)
            elif attr in {'ping', 'archive'}:
                unsafe |= any(not safe_url(url) for url in decoded(value).split())
            elif attr in {'srcset', 'imagesrcset'}:
                # Check every candidate scheme, including schemes obfuscated
                # with HTML character references or control characters.
                candidates = re.sub(r'[\x00-\x20\x7f-\x9f]', '', decoded(value))
                unsafe |= any(m[1].lower() not in SAFE_SCHEMES for m in
                              re.finditer(r'(?:^|,)([a-z][a-z0-9+.-]*):', candidates, re.I))
            elif attr == 'style':
                unsafe |= unsafe_css(value)
            if unsafe:
                cuts.append((begin, attr_end))
        if name in RAW_TEXT:
            raw_start, pos = raw_end(source, name, end)
            if name == 'style' and unsafe_css(source[end:raw_start]):
                cuts.append((start, pos))
        elif name == 'plaintext':
            break
    if not cuts:
        return source
    # Merge cuts so a whole unsafe element can overlap its attribute cuts.
    chunks = []
    previous = 0
    for begin, end in sorted(cuts):
        if begin > previous:
            chunks.append(source[previous:begin])
        previous = max(previous, end)
    chunks.append(source[previous:])
    return ''.join(chunks)


def sanitize(source):
    """Repeat because deleting a substring can join text into a new HTML tag."""
    while True:
        result = sanitize_once(source)
        if result == source:
            return result
        source = result


def filter_file(filename):
    path = Path(filename)
    original = path.read_bytes()
    # Latin-1 gives a reversible, one-byte mapping for ASCII-compatible HTML.
    # BOM-marked Unicode files need decoding before looking for HTML syntax.
    encoding = 'latin-1'
    prefix = b''
    content = original
    for bom, candidate in ((codecs.BOM_UTF32_LE, 'utf-32-le'),
                           (codecs.BOM_UTF32_BE, 'utf-32-be'),
                           (codecs.BOM_UTF16_LE, 'utf-16-le'),
                           (codecs.BOM_UTF16_BE, 'utf-16-be')):
        if original.startswith(bom):
            prefix, content, encoding = bom, original[len(bom):], candidate
            break
    else:
        if original.startswith(b'<\x00'):
            encoding = 'utf-16-le'
        elif original.startswith(b'\x00<'):
            encoding = 'utf-16-be'
    result = prefix + sanitize(content.decode(encoding)).encode(encoding)
    if result != original:
        path.write_bytes(result)


def main():
    if len(sys.argv) != 2:
        print(f'Usage: {Path(sys.argv[0]).name} HTML_FILE', file=sys.stderr)
        return 2
    try:
        filter_file(sys.argv[1])
    except (OSError, UnicodeError) as error:
        print(f'{Path(sys.argv[0]).name}: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
