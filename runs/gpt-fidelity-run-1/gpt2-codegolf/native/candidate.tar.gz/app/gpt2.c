#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <locale.h>
#include <wctype.h>
#define D 768
#define V 50257
#define F(n) for(i=0;i<n;i++)
char *v[V];int J[131072],L[V],R[V],M[256],U[324];
float K[12][1024][1536],x[D],y[D],q[2304],a[D],f[3072];
int H(char *s){unsigned h=2166136261u;for(char *p=s;*p;p++)h=(h^(unsigned char)*p)*16777619u;h&=131071;while(J[h]&&strcmp(s,v[J[h]-1]))h=(h+1)&131071;return h;}
void I(int i,char *s){v[i]=strdup(s);J[H(s)]=i+1;}
void N(float *o,float *b){int i;float u=0,z=0;F(D)u+=x[i]/D;F(D)z+=(x[i]-u)*(x[i]-u)/D;z=1/sqrtf(z+1e-5f);F(D)o[i]=(x[i]-u)*z*b[D+i]+b[i];}
void G(float *restrict o,float *x,float *w,int n,int m){int i;memcpy(o,w,m*4);w+=m;F(n)for(int j=0;j<m;j++)o[j]+=x[i]*w[i*m+j];}
int u(char **p){unsigned c=(unsigned char)*(*p)++;if(c>=192){int n=c<224?1:c<240?2:3;c&=(1<<(6-n))-1;while(n--)c=c<<6|(*(*p)++&63);}return c;}
int r(char **p){int n=0,s=1,c;do{c=*(*p)++-40;n+=(c&31)*s;s*=32;}while(c>=32);return n;}
int c(int c){char *p="M,+B+9.-**2N<(R;\\))(),),)(P*P)X)X))@(N).(M+@,4*,,(*N)?(Fd)N+P)7N)T*,+H))0)4J+)L*T)+@.T*^),*`)),-02,*N)90b)@*,*,2(2,*N),>/0b)8,,*,,(<N)(,+(30b)D)0),=,*N)20,0b)@*,*,1,2,*N)*>2(c)8+0)02(6Z)58a)@)0)00,-)-,*N)0B*0b)@)0)00,-)-,*N)+(44b)@)0)02((B+,*R*00S*<)()D.N)*,e)(*@:(*N)_*(*<),8(*N)N*V*e)P*1P))T,V+T))(*4)N)44,0)0*@+45T))((N)(4S>V*YC2I),F,F,F,J*P*?N).N)>N)S+,J)(^+T),H)5N)H,R)d)8a)L)*T*3N).N)M),30Y)8X)`)4N)N)0FH)*,*N)U)P)Z)P*1N).N)W)-d2\\)Z8+O)+H**+>.N)N.R.*:^>V/BT.(^*^;^+QS)*J/d+O8*AJ)62_26R,N)FF)b)H)N)O)b)HcDN)R*DJ),N*N)c.9*)))-1<)8(0(?80>R*,Z)d))(2N)M)((N)D8DT)U)4X)T)8N)3(2N)W)\\)4(0,*N)I)0Z)()0*,-(T)8-(U/D-N)La;(YGN)U7Z-4J/9.]2R+L)6E*0*S)8^*:R.N)^0U.L;FABO)J)S*:>>L)M+J+.*f)*^-)0),-4X)J)\\).F2S*:P+F@FQ)BR2>L)40N).N)(U+1a*b.b+T),==]*N)R)6X+B\\)0])\\)4^++,30U)H)1(U)N).0L)T)+N)-,a)0X)X)6,(N)/V*_)H)*(.(*(e,L)/N).4b)@*,*,2(2,DM)))*))],))A)))I+X))02N)^*L*6N)].@*@E,Z*`))(7N)Y*P)2N).V*a)\\)-V)X/X)O-R*e)<),*,+()(5N)_+@*<,(DL)R)8)4:P)V)\\)P1I,7N)])D)@9Z+M)\\*)\\)b+<+(),)0)(+(0N)X)8),)41N).U-,N)Q041,)(X)@+07N)N+Z*SI)b5Yg+Q[7MP/]+:N)NQ*N)^*N)N,N))Bf6Y-+N)N0b*1I+*I+c+()`./4e*,(-(2IH.EgO))1]*I+Q6S]3(YJ,N)NV)V*4V*T+J+]J)N.HH*@)H**@),)8L+(X-N)N5N)^7N)^.]+*)(N)M.a+)1)-)A*91-O6J)_+(0N)_@R/)2)6T*Z-)b)JFZ)K)L+.L+.L+N[*N)HbV)=Jc-U)JP=Ma8";int a=0;while(*p){a+=r(&p);int v=r(&p);if(c<a)break;if(c<=a+v/4)return v%4;a+=v/4+1;}return iswalpha(c)?1:c>=48&&c<=57?2:iswspace(c)?3:0;}
int main(int C,char **A){
if(C!=4)return fprintf(stderr,"usage: %s weights.ckpt vocab.bpe prompt\n",A[0]),1;
FILE *fp=fopen(A[1],"rb");float *w=malloc(497759232);if(!fp||!w||fread(w,1,497759232,fp)!=497759232||fgetc(fp)!=EOF)return fputs("Invalid weight shard\n",stderr),1;fclose(fp);
fp=fopen(A[2],"r");if(!fp)return perror(A[2]),1;
char s[2048],t[2048];int i=0,k=0;for(int b=0;b<256;b++)if((b>32&&b<127)||(b>160&&b!=173)){M[b]=i++;}
for(int b=0;b<256;b++){int c=b;if(!((b>32&&b<127)||(b>160&&b!=173)))c=256+k++,M[b]=i++;int n=0;if(c>127)s[n++]=192|(c>>6),s[n++]=128|(c&63);else s[n++]=c;s[n]=0;I(M[b],s);U[c]=b;}
if(!fgets(s,sizeof s,fp))return 1;
for(i=256;i<V-1;i++){if(!fgets(s,sizeof s,fp))return 1;char *p=strchr(s,' ');if(!p)return 1;*p++=0;p[strcspn(p,"\r\n")]=0;L[i]=J[H(s)]-1;R[i]=J[H(p)]-1;snprintf(t,sizeof t,"%s%s",s,p);I(i,t);}I(V-1,"<|endoftext|>");fclose(fp);
setlocale(LC_ALL,"C.UTF-8");
int *Q=malloc((strlen(A[3])+1)*sizeof(int)),T[1025],P=0;char *p=A[3];
while(*p){char *z=p,*r=p;int n=0;
for(char *c="'s\0't\0're\0've\0'm\0'll\0'd\0";*c;c+=strlen(c)+1)if(!strncmp(p,c,strlen(c))){n=strlen(c);break;}
if(!n){if(*z==' '&&z[1]){r=z+1;if(c(u(&r))!=3)z++;}r=z;int k=c(u(&r));char *b=z;z=r;while(*z){r=z;if(c(u(&r))!=k)break;b=z;z=r;}if(k==3&&*z&&b!=p)z=b;n=z-p;}
F(n)Q[i]=M[(unsigned char)p[i]];
p+=n;
int d=n;for(;;){int B=V,j=-1;F(d-1){snprintf(s,sizeof s,"%s%s",v[Q[i]],v[Q[i+1]]);int id=J[H(s)]-1;if(id>=256&&id<B&&L[id]==Q[i]&&R[id]==Q[i+1])B=id,j=i;}if(j<0)break;Q[j]=B;memmove(Q+j+1,Q+j+2,(d-j-2)*sizeof(int));d--;}
if(P+d>1005)return fputs("Prompt too long\n",stderr),1;
memcpy(T+P,Q,d*sizeof(int));P+=d;}
if(!P)T[P++]=V-1;
fputs(A[3],stdout);fflush(stdout);
for(int t=0;t<P+19;t++){
float *E=w+85842432;F(D)x[i]=E[T[t]*D+i]+w[85056000+t*D+i];
for(int l=0;l<12;l++){int z=l<2?l:l>9?l-8:l+2;float *b=w+z*7087872;
N(y,b+2362368);G(q,y,b,D,2304);memcpy(K[l][t],q+D,1536*4);memset(a,0,sizeof a);
for(int h=0;h<12;h++){float p[1024],m=-1e30f,S=0;for(int j=0;j<=t;j++){float z=0;F(64)z+=q[h*64+i]*K[l][j][h*64+i];p[j]=z/8;if(p[j]>m)m=p[j];}for(int j=0;j<=t;j++)S+=(p[j]=expf(p[j]-m));for(int j=0;j<=t;j++)F(64)a[h*64+i]+=p[j]/S*K[l][j][D+h*64+i];}
G(y,a,b+1771776,D,D);F(D)x[i]+=y[i];N(y,b+2363904);G(f,y,b+2365440,D,3072);F(3072){float z=f[i];f[i]=.5f*z*(1+tanhf(.7978845608f*(z+.044715f*z*z*z)));}G(y,f,b+4727808,3072,D);F(D)x[i]+=y[i];}
if(t<P-1)continue;
N(y,w+85054464);float B=-1e30f;int id=0;for(int j=0;j<V;j++){float z=0;F(D)z+=y[i]*E[j*D+i];if(z>B)B=z,id=j;}T[t+1]=id;
if(id==V-1)fputs(v[id],stdout);else for(char *r=v[id];*r;)putchar(U[u(&r)]);fflush(stdout);
}
return 0;
}
