"""A persistent, interactive Bash terminal backed by a Unix pseudo-terminal."""

from __future__ import annotations

import codecs
import errno
import fcntl
import os
import pty
import select
import shutil
import signal
import struct
import termios
import threading
import time
from collections.abc import Mapping

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """Run interactive Bash with normal terminal input and job control.

    Keystrokes are literal text: ``"\r"`` or ``"\n"`` presses Enter,
    ``"\x03"`` presses Ctrl-C, and ``"\x04"`` presses Ctrl-D. Escape
    sequences (for example, ``"\x1b[A"`` for Up) are passed through too.
    Output includes terminal echo and ANSI escape sequences. A background
    reader continuously drains it so verbose commands cannot fill the PTY.

    Bash reads its normal interactive startup files, including ~/.bashrc.
    Use ``close()`` or a context manager to release the terminal and shell.
    """

    def __init__(
        self,
        cwd: str | os.PathLike[str] | None = None,
        env: Mapping[str, str] | None = None,
        rows: int = 24,
        cols: int = 80,
    ) -> None:
        dimensions = self._dimensions(rows, cols)
        bash = shutil.which("bash")
        if bash is None:
            raise FileNotFoundError("Bash is required for HeadlessTerminal")
        # Resolve and validate before forking, so constructor errors reach callers.
        directory = os.path.abspath(cwd) if cwd is not None else os.getcwd()
        if not os.path.isdir(directory):
            raise NotADirectoryError(directory)
        environment = os.environ.copy()
        if env is not None:
            environment.update(env)
        environment.setdefault("TERM", "xterm-256color")
        environment["LINES"] = str(rows)
        environment["COLUMNS"] = str(cols)

        self._closed = False
        self._write_lock = threading.Lock()
        self._output_lock = threading.Lock()
        self._output: list[str] = []
        self._stop = threading.Event()
        self._eof = threading.Event()

        self.pid, self._master_fd = pty.fork()
        if self.pid == 0:
            try:
                os.chdir(directory)
                fcntl.ioctl(0, termios.TIOCSWINSZ, dimensions)
                os.execve(bash, ["bash", "-i"], environment)
            except BaseException as error:
                os.write(2, (f"Unable to start Bash: {error}\n").encode())
            finally:
                os._exit(127)

        os.set_blocking(self._master_fd, False)
        self._reader = threading.Thread(
            target=self._read_loop, name=f"terminal-{self.pid}", daemon=True
        )
        self._reader.start()

    @staticmethod
    def _dimensions(rows: int, cols: int) -> bytes:
        if not (0 < rows <= 65535 and 0 < cols <= 65535):
            raise ValueError("rows and cols must be between 1 and 65535")
        return struct.pack("HHHH", rows, cols, 0, 0)

    def _read_loop(self) -> None:
        decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        try:
            while not self._stop.is_set():
                ready, _, _ = select.select([self._master_fd], [], [], 0.1)
                if not ready:
                    continue
                try:
                    data = os.read(self._master_fd, 65536)
                except BlockingIOError:
                    continue
                except OSError as error:
                    # Linux PTYs report EIO when the slave side closes.
                    if error.errno == errno.EIO:
                        break
                    raise
                if not data:
                    break
                with self._output_lock:
                    self._output.append(decoder.decode(data))
        finally:
            with self._output_lock:
                self._output.append(decoder.decode(b"", final=True))
            self._eof.set()

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        """Send literal UTF-8 input, then wait up to the requested duration.

        The wait is a fixed delay, not a command-completion detector: commands
        may launch interactive programs or keep running after this returns.
        """
        if not isinstance(keystrokes, str):
            raise TypeError("keystrokes must be a string")
        if wait_sec < 0:
            raise ValueError("wait_sec must be non-negative")
        data = memoryview(keystrokes.encode("utf-8"))
        with self._write_lock:
            if self._closed or self._eof.is_set():
                raise RuntimeError("The terminal is closed")
            while data:
                try:
                    count = os.write(self._master_fd, data)
                except BlockingIOError:
                    select.select([], [self._master_fd], [], 0.1)
                    continue
                except OSError as error:
                    if error.errno == errno.EIO:
                        raise RuntimeError("The terminal is closed") from error
                    raise
                data = data[count:]
        if wait_sec:
            time.sleep(wait_sec)

    def read_output(self, clear: bool = True) -> str:
        """Return captured output without blocking; consume it by default."""
        with self._output_lock:
            output = "".join(self._output)
            if clear:
                self._output.clear()
            return output

    def get_output(self) -> str:
        """Return captured output without consuming it."""
        return self.read_output(clear=False)

    def resize(self, rows: int, cols: int) -> None:
        """Set terminal size; the kernel notifies the foreground application."""
        dimensions = self._dimensions(rows, cols)
        with self._write_lock:
            if self._closed:
                raise RuntimeError("The terminal is closed")
            fcntl.ioctl(self._master_fd, termios.TIOCSWINSZ, dimensions)

    def close(self) -> None:
        """Close the PTY, terminate the shell and foreground job, and reap Bash."""
        with self._write_lock:
            if self._closed:
                return
            self._closed = True
            groups = {self.pid}
            try:
                foreground = os.tcgetpgrp(self._master_fd)
                if foreground > 0:
                    groups.add(foreground)
            except OSError:
                pass
            self._stop.set()
            self._reader.join()
            os.close(self._master_fd)
            for group in groups:
                try:
                    os.killpg(group, signal.SIGHUP)
                except ProcessLookupError:
                    pass
            deadline = time.monotonic() + 1.0
            while True:
                try:
                    waited, _ = os.waitpid(self.pid, os.WNOHANG)
                except ChildProcessError:
                    break
                if waited:
                    break
                if time.monotonic() >= deadline:
                    for group in groups:
                        try:
                            os.killpg(group, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    os.waitpid(self.pid, 0)
                    break
                time.sleep(0.01)

    def __enter__(self) -> HeadlessTerminal:
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()
