"""An interactive Bash terminal backed by a Unix pseudo-terminal."""

import codecs
import errno
import fcntl
import math
import os
import select
import shutil
import signal
import struct
import subprocess
import termios
import threading
import time
from typing import Mapping

from base_terminal import BaseTerminal


def _attach_controlling_terminal() -> None:
    """Give the child its own session and controlling terminal."""
    os.setsid()
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)


class HeadlessTerminal(BaseTerminal):
    """Run an interactive Bash shell with real terminal input semantics.

    Keystrokes are literal text, including control characters and ANSI key
    sequences. For example, ``"echo hello\n"`` runs a command, ``"\x03"``
    interrupts the foreground program, and ``"\x1b[A"`` presses Up.

    Output is drained continuously so programs cannot block on a full PTY.
    ``read_output()`` retrieves captured text, including terminal escape codes;
    it is an output transcript, not a rendered screen. Use ``close()`` or a
    context manager to release the shell and terminal.
    """

    def __init__(
        self,
        cwd: str | os.PathLike[str] | None = None,
        env: Mapping[str, str] | None = None,
        rows: int = 24,
        cols: int = 80,
    ) -> None:
        self._validate_size(rows, cols)
        bash = shutil.which("bash")
        if bash is None:
            raise FileNotFoundError("Bash is required for HeadlessTerminal")
        child_env = os.environ.copy()
        child_env.setdefault("TERM", "xterm-256color")
        if env is not None:
            child_env.update(env)

        self._write_lock = threading.Lock()
        self._output_lock = threading.Lock()
        self._output: list[str] = []
        self._stop = threading.Event()
        self._closed = False
        master, slave = os.openpty()
        try:
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
            self._process = subprocess.Popen(
                [bash, "-i"],
                stdin=slave,
                stdout=slave,
                stderr=slave,
                cwd=cwd,
                env=child_env,
                preexec_fn=_attach_controlling_terminal,
                close_fds=True,
            )
            os.set_blocking(master, False)
        except BaseException:
            os.close(master)
            raise
        finally:
            os.close(slave)
        self._master = master
        self._reader = threading.Thread(
            target=self._drain_output, name=f"terminal-{self.pid}", daemon=True
        )
        self._reader.start()

    @staticmethod
    def _validate_size(rows: int, cols: int) -> None:
        if not (0 < rows <= 65535 and 0 < cols <= 65535):
            raise ValueError("rows and cols must be between 1 and 65535")

    @property
    def pid(self) -> int:
        """PID of the interactive shell."""
        return self._process.pid

    def is_alive(self) -> bool:
        return not self._closed and self._process.poll() is None

    def _drain_output(self) -> None:
        decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        try:
            while not self._stop.is_set():
                readable, _, _ = select.select([self._master], [], [], 0.05)
                if not readable:
                    continue
                try:
                    data = os.read(self._master, 65536)
                except BlockingIOError:
                    continue
                except OSError as exc:
                    if exc.errno == errno.EIO:  # All slave descriptors closed.
                        break
                    raise
                if not data:
                    break
                text = decoder.decode(data)
                if text:
                    with self._output_lock:
                        self._output.append(text)
        finally:
            tail = decoder.decode(b"", final=True)
            if tail:
                with self._output_lock:
                    self._output.append(tail)

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        """Send literal UTF-8 input, then wait the requested number of seconds.

        Both ``\n`` and ``\r`` can be used for Enter. Waiting does not imply
        command completion: interactive programs may run until further input.
        """
        if not isinstance(keystrokes, str):
            raise TypeError("keystrokes must be a string")
        if not math.isfinite(wait_sec) or wait_sec < 0:
            raise ValueError("wait_sec must be finite and nonnegative")
        data = memoryview(keystrokes.encode("utf-8"))
        with self._write_lock:
            if not self.is_alive():
                raise RuntimeError("Terminal is closed or its shell has exited")
            while data:
                try:
                    written = os.write(self._master, data)
                    data = data[written:]
                except BlockingIOError:
                    select.select([], [self._master], [], 0.05)
                    if self._process.poll() is not None:
                        raise RuntimeError("Terminal shell exited while sending input")
                except OSError as exc:
                    raise RuntimeError("Terminal is no longer available") from exc
        if wait_sec:
            time.sleep(wait_sec)

    def read_output(self, clear: bool = True) -> str:
        """Return captured output; by default consume the returned text."""
        with self._output_lock:
            result = "".join(self._output)
            if clear:
                self._output.clear()
            return result

    def resize(self, rows: int, cols: int) -> None:
        """Resize the terminal, notifying its foreground program via SIGWINCH."""
        self._validate_size(rows, cols)
        with self._write_lock:
            if not self.is_alive():
                raise RuntimeError("Terminal is closed or its shell has exited")
            fcntl.ioctl(
                self._master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0)
            )

    def close(self) -> None:
        """Hang up the terminal and reap the shell. Safe to call repeatedly."""
        with self._write_lock:
            if self._closed:
                return
            self._closed = True
            self._stop.set()
            self._reader.join()
            os.close(self._master)
            if self._process.poll() is None:
                try:
                    os.killpg(self.pid, signal.SIGHUP)
                except ProcessLookupError:
                    pass
            try:
                self._process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(self.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                self._process.wait()

    def __enter__(self) -> "HeadlessTerminal":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()
