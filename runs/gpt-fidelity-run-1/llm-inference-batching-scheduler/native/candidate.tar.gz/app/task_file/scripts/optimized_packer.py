#!/usr/bin/env python3
"""Pack requests by prompt and decode bounds under shared static shapes."""
import argparse
import bisect
import heapq
import json
from pathlib import Path
from cost_model import CostModel, align

ROOT = Path(__file__).resolve().parents[1]
SHAPES = (64, 128, 192, 320, 512, 640, 1408, 2048)
LIMITS = {1: (3e11, .055, 2.1e6, 2.7e8), 2: (4.8e10, .15, 2.1e5, 3.2e7)}


def bounds(s, g):
    sq = g*s*s + s*g*(g-1) + g*(g-1)*(2*g-1)//6
    lin = g*s + g*(g-1)/2
    return sq + 2048*lin, .0012*sq + 2.4576*lin


def make_group(indices, requests):
    ss = sorted(align(requests[i]['prompt_len'], 64) for i in indices)
    s = ss[-1]
    g = max(requests[i]['gen_len'] for i in indices)
    dc, dl = bounds(s, g)
    return (indices, ss, s, g, len(indices)*dc, dl + .002*s*s + 6.144*s + 8)


def optimize(requests, bucket, time_weight, pad_weight):
    groups = {i: make_group([i], requests) for i in range(len(requests))}
    next_id = len(groups)
    heap = []
    threshold = LIMITS[bucket][2] - 1500  # Leave room for shape bring-up.

    def candidate(a, b):
        x, y = groups[a], groups[b]
        n, m = len(x[0]), len(y[0])
        s, g = max(x[2], y[2]), max(x[3], y[3])
        dc, dl = bounds(s, g)
        maxlat = dl + .002*s*s + 6.144*s + 8
        # Preserve the count of requests exceeding the latency threshold.
        old_bad = sum(.002*v*v + 6.144*v + bounds(t[2], t[3])[1] + 8 > threshold
                      for t in (x, y) for v in t[1])
        new_bad = sum(.002*v*v + 6.144*v + dl + 8 > threshold
                      for t in (x, y) for v in t[1])
        if new_bad > old_bad:
            return
        dcost = (n+m)*dc - x[4] - y[4] - 1e7
        dpad = n*(g-x[3]) + m*(g-y[3])
        dtime = maxlat - x[5] - y[5]
        score = dcost + time_weight*dtime + pad_weight*dpad
        if score < 0:
            heapq.heappush(heap, (score, a, b))

    for a in groups:
        for b in range(a):
            candidate(b, a)
    while heap:
        _, a, b = heapq.heappop(heap)
        if a not in groups or b not in groups:
            continue
        ids = groups[a][0] + groups[b][0]
        del groups[a], groups[b]
        groups[next_id] = make_group(ids, requests)
        for other in groups:
            if other != next_id:
                candidate(other, next_id)
        next_id += 1
    plan = []
    for batch, group in enumerate(sorted(groups.values(), key=lambda t: min(t[0]))):
        s = SHAPES[bisect.bisect_left(SHAPES, group[2])]
        for i in group[0]:
            plan.append({'request_id': requests[i]['request_id'],
                         'batch_id': f'b{bucket}-{batch:04d}',
                         'shape': {'seq_align': s, 'heads_align': 32, 'hidden_align': 4096}})
    return plan


def evaluate(requests, plan):
    metrics = CostModel(64).plan_metrics({r['request_id']: r for r in requests}, plan)
    return {k: metrics[k] for k in ('cost', 'pad_ratio', 'p95_latency_ms', 'sequential_timecost')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bucket', type=int, required=True)
    parser.add_argument('--time-weight', type=float, required=True)
    parser.add_argument('--pad-weight', type=float, required=True)
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    requests = [json.loads(line) for line in (ROOT/'input_data'/f'requests_bucket_{args.bucket}.jsonl').read_text().splitlines()]
    plan = optimize(requests, args.bucket, args.time_weight, args.pad_weight)
    metrics = evaluate(requests, plan)
    print(json.dumps({'bucket': args.bucket, 'time_weight': args.time_weight, 'pad_weight': args.pad_weight,
                      'batches': len({p['batch_id'] for p in plan}), **metrics}), flush=True)
    if args.write:
        assert all(value < limit for value, limit in zip(metrics.values(), LIMITS[args.bucket])), metrics
        out = ROOT/'output_data'/f'plan_b{args.bucket}.jsonl'
        out.write_text(''.join(json.dumps(row)+'\n' for row in plan))


if __name__ == '__main__':
    main()
