#!/usr/bin/env python3
"""Build and validate shape-aware plans using the supplied analytical model."""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from cost_model import CostModel, align

ROOT = Path(__file__).resolve().parents[1]
MODEL = CostModel(64)
LIMITS = {
    1: dict(cost=3.0e11, pad_ratio=0.055, p95_latency_ms=2.1e6, sequential_timecost=2.7e8),
    2: dict(cost=4.8e10, pad_ratio=0.15, p95_latency_ms=2.1e5, sequential_timecost=3.2e7),
}


def representatives(requests, count=8):
    """Quantize prompt sizes jointly, minimizing estimated padded compute."""
    by_s = defaultdict(list)
    for r in requests:
        by_s[align(r['prompt_len'], 64)].append(r)
    sizes = sorted(by_s)
    n = len(sizes)
    loss = {}
    for j, upper in enumerate(sizes):
        total = 0
        for i in range(j, -1, -1):
            s = sizes[i]
            for r in by_s[s]:
                g = r['gen_len']
                # Incremental prefill and decode cost when rounding s to upper.
                total += 2*(upper*upper-s*s) + 4096*(upper-s)
                total += g*(upper*upper-s*s) + (upper-s)*g*(g-1) + 2048*g*(upper-s)
            loss[i, j] = total
    dp = {(0, 0): (0, [])}
    for k in range(1, min(count, n)+1):
        for end in range(k, n+1):
            choices = [(dp[k-1, start][0] + loss[start, end-1],
                        dp[k-1, start][1] + [sizes[end-1]])
                       for start in range(k-1, end) if (k-1, start) in dp]
            dp[k, end] = min(choices)
    return dp[min(count, n), n][1]


def batch_stats(rs):
    m = MODEL.batch_metrics(rs)
    return dict(rs=rs, s=m['S_max'], g=m['G_max'], cost=m['cost']+1e7,
                pad=m['pad_tokens'], time=max(m['latencies'])+8,
                high=sum(lat+1500 > CURRENT_LIMIT['p95_latency_ms'] for lat in m['latencies']))


def make_plan(groups, reps, bucket):
    plan = []
    for i, group in enumerate(sorted(groups, key=lambda x: (x['s'], x['g']))):
        shape = dict(seq_align=next(s for s in reps if s >= group['s']),
                     heads_align=32, hidden_align=4096)
        for r in group['rs']:
            plan.append(dict(request_id=r['request_id'], batch_id=f'b{bucket}-{i:05d}', shape=shape))
    return plan


def optimize(rs, reps, bucket):
    global CURRENT_LIMIT
    CURRENT_LIMIT = LIMITS[bucket]
    by_pair = defaultdict(list)
    for r in rs:
        by_pair[align(r['prompt_len'],64), r['gen_len']].append(r)
    groups = [batch_stats(v) for v in by_pair.values()]
    real = sum(r['prompt_len']+r['gen_len'] for r in rs)
    # Reserve room for compilation costs and one compilation latency per shape.
    used_reps = {next(s for s in reps if s >= g['s']) for g in groups}
    compile_cost = sum(500*s*s+8192*s for s in used_reps)
    cost = sum(g['cost'] for g in groups) + compile_cost
    pad = sum(g['pad'] for g in groups)
    sequential = sum(g['time'] for g in groups) + 1500*len(used_reps)
    high = sum(g['high'] for g in groups)
    target_time = CURRENT_LIMIT['sequential_timecost'] * 0.96
    while sequential > target_time:
        candidates = []
        # Adjacent generation intervals at a fixed aligned prompt size avoid
        # paying a larger context dimension during decode.
        by_s = defaultdict(list)
        for idx, g in enumerate(groups):
            by_s[g['s']].append(idx)
        for indices in by_s.values():
            indices.sort(key=lambda i: groups[i]['g'])
            for a, b in zip(indices, indices[1:]):
                ga, gb = groups[a], groups[b]
                merged = batch_stats(ga['rs']+gb['rs'])
                dc = merged['cost']-ga['cost']-gb['cost']
                dp = merged['pad']-ga['pad']-gb['pad']
                dt = ga['time']+gb['time']-merged['time']
                dh = merged['high']-ga['high']-gb['high']
                if dt <= 0 or cost+dc >= CURRENT_LIMIT['cost']:
                    continue
                if (pad+dp)/real >= CURRENT_LIMIT['pad_ratio'] or high+dh > len(rs)*0.05:
                    continue
                # Spend padding on merges that save the most sequential time.
                score = (dp + max(0, dc)/1e8)/dt
                candidates.append((score, a, b, merged, dc, dp, dt, dh))
        if not candidates:
            raise RuntimeError(f'No feasible merge for bucket {bucket}: {sequential=}, {pad/real=}, {cost=}')
        _, a, b, merged, dc, dp, dt, dh = min(candidates, key=lambda c: c[:3])
        groups = [g for i,g in enumerate(groups) if i not in (a,b)] + [merged]
        cost += dc
        pad += dp
        sequential -= dt
        high += dh
    return make_plan(groups, reps, bucket)


def validate(requests, plans):
    shapes = set()
    for bucket in (1,2):
        rs, plan = requests[bucket], plans[bucket]
        lookup = {r['request_id']:r for r in rs}
        ids = [p['request_id'] for p in plan]
        assert len(ids) == len(set(ids)) == len(lookup)
        assert set(ids) == set(lookup)
        batch_shapes = {}
        for p in plan:
            sh = p['shape']
            shape = (sh['seq_align'], sh['heads_align'], sh['hidden_align'])
            assert shape[0] % 64 == 0 and shape[0] >= align(lookup[p['request_id']]['prompt_len'],64)
            assert shape[1:] == (32,4096)
            assert batch_shapes.setdefault(p['batch_id'], shape) == shape
            shapes.add(shape)
        metrics = MODEL.plan_metrics(lookup,plan)
        for key, bound in LIMITS[bucket].items():
            assert metrics[key] < bound, (bucket,key,metrics[key],bound)
        print(json.dumps(dict(bucket=bucket, requests=len(rs), batches=len(batch_shapes),
                             **{k:v for k,v in metrics.items() if k!='latencies'}), indent=2))
    assert len(shapes) <= 8
    print('Global shapes:', sorted(shapes))


def main():
    paths = {b:ROOT/'input_data'/f'requests_bucket_{b}.jsonl' for b in (1,2)}
    hashes = {b:hashlib.sha256(p.read_bytes()).hexdigest() for b,p in paths.items()}
    requests = {b:[json.loads(line) for line in p.read_text().splitlines()] for b,p in paths.items()}
    reps = representatives(requests[1]+requests[2])
    plans = {b:optimize(requests[b],reps,b) for b in (1,2)}
    validate(requests,plans)
    for b,plan in plans.items():
        out = ROOT/'output_data'/f'plan_b{b}.jsonl'
        out.parent.mkdir(exist_ok=True)
        out.write_text(''.join(json.dumps(p, separators=(',',':'))+'\n' for p in plan))
    assert all(hashlib.sha256(paths[b].read_bytes()).hexdigest()==hashes[b] for b in paths)


if __name__ == '__main__':
    main()
