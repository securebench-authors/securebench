"""Complete a repeating three-color diagonal pattern."""

from utils import mod3


def map(g):
    """Fill zero cells from the nonzero clues at each (row + column) % 3.

    Cells on the same upward diagonal share a color, and the diagonal
    colors repeat every three steps. Return a new grid without changing g.
    """
    colors = {}
    for row_index, row in enumerate(g):
        for column_index, color in enumerate(row):
            if color != 0:
                colors[mod3(row_index + column_index)] = color

    return [
        [colors.get(mod3(i + j), 0) for j in range(len(row))]
        for i, row in enumerate(g)
    ]
