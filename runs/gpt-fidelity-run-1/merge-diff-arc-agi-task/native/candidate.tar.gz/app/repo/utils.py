def mod3(x):
    """Return the position in a three-color repeating pattern."""
    return x % 3
