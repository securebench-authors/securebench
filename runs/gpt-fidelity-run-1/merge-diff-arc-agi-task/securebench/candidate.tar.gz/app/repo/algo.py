def map(g):
    """Complete the repeating three-color diagonals, using zero as blank."""
    colors = [0, 0, 0]
    for row_index, row in enumerate(g):
        for column_index, color in enumerate(row):
            if color != 0:
                colors[(row_index + column_index) % 3] = color

    return [
        [colors[(row_index + column_index) % 3]
         for column_index in range(len(row))]
        for row_index, row in enumerate(g)
    ]
