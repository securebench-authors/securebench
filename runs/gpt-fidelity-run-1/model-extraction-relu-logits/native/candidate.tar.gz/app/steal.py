#!/usr/bin/env python3
"""Recover the input weights of a shallow scalar-output ReLU network by queries.

Only forward(x) is used. Rows are normalized and their signs are canonicalized.
As with any oracle method, neurons with zero output weight, or neurons whose
identical hyperplanes cancel exactly, cannot be identified from function values.
"""
from pathlib import Path
import numpy as np
from forward import forward

DIM = 10


def query(x):
    return float(forward(np.asarray(x, dtype=float)))


def line_breakpoints(origin, direction, radius):
    """Adaptively resolve a piecewise affine restriction to a random line."""
    cache = {}
    leaves = []

    def value(t):
        if t not in cache:
            cache[t] = query(origin + t * direction)
        return cache[t]

    def subdivide(a, b, fa, fb, depth=0):
        ts = [a + (b - a) * q for q in (0.25, 0.5, 0.75)]
        fs = np.array([value(t) for t in ts])
        predicted = fa + (fb - fa) * np.array([0.25, 0.5, 0.75])
        tolerance = 2e-12 * max(1.0, abs(fa), abs(fb), np.max(abs(fs)))
        affine = np.max(abs(fs - predicted)) <= tolerance
        if affine or b - a <= 1e-7 * (1 + abs(a) + abs(b)) or depth >= 48:
            leaves.append((a, b, (fb - fa) / (b - a)))
            return
        m = ts[1]
        subdivide(a, m, fa, fs[1], depth + 1)
        subdivide(m, b, fs[1], fb, depth + 1)

    # A coarse mesh protects against several kinks canceling in a large interval.
    grid = np.linspace(-radius, radius, 65)
    for a, b in zip(grid[:-1], grid[1:]):
        subdivide(a, b, value(a), value(b))

    candidates = []
    for left, right in zip(leaves[:-1], leaves[1:]):
        if abs(left[2] - right[2]) > 1e-8 * max(1.0, abs(left[2]), abs(right[2])):
            candidates.append(left[1])
    # The tiny intervals surrounding a kink can produce several slope changes.
    clusters = []
    for t in candidates:
        if clusters and t - clusters[-1][-1] < 4e-6 * (1 + abs(t)):
            clusters[-1].append(t)
        else:
            clusters.append([t])
    return np.array([np.mean(cluster) for cluster in clusters])


def gradient(x):
    """Central differences, shrinking the step until locally affine."""
    h = 1e-3 * max(1.0, np.linalg.norm(x, ord=np.inf))

    def estimate(step):
        result = np.empty(DIM)
        for j in range(DIM):
            delta = np.zeros(DIM)
            delta[j] = step
            result[j] = (query(x + delta) - query(x - delta)) / (2 * step)
        return result

    previous = estimate(h)
    for _ in range(24):
        h *= 0.5
        current = estimate(h)
        if np.linalg.norm(current - previous) <= 1e-9 * max(1.0, np.linalg.norm(current)):
            return current
        previous = current
    return current


def recover(seed=1729):
    rng = np.random.default_rng(seed)
    rows = []
    quiet_lines = 0
    for line_number in range(24):
        origin = rng.normal(size=DIM)
        direction = rng.normal(size=DIM)
        direction /= np.linalg.norm(direction)
        radius = 64.0 * (2 ** (line_number // 8))
        roots = line_breakpoints(origin, direction, radius)
        before = len(rows)
        if len(roots):
            boundaries = np.r_[-radius, roots, radius]
            samples = (boundaries[:-1] + boundaries[1:]) / 2
            grads = [gradient(origin + t * direction) for t in samples]
            for jump in np.diff(grads, axis=0):
                size = np.linalg.norm(jump)
                if size < 1e-8:
                    continue
                row = jump / size
                if row[np.argmax(abs(row))] < 0:
                    row = -row
                if not any(min(np.linalg.norm(row - old), np.linalg.norm(row + old)) < 1e-5 for old in rows):
                    rows.append(row)
        quiet_lines = quiet_lines + 1 if len(rows) == before else 0
        print(f'Line {line_number + 1}: recovered {len(rows)} distinct neurons', flush=True)
        # Width is unknown. Independent lines provide an empirical coverage check.
        if line_number >= 7 and quiet_lines >= 5:
            break
    if not rows:
        raise RuntimeError('No observable ReLU hyperplanes were found.')
    return np.vstack(rows)


def main():
    matrix = recover()
    destination = Path('/app/stolen_A1.npy')
    np.save(destination, matrix)
    np.set_printoptions(precision=12, linewidth=160, suppress=True)
    print(matrix)
    print(f'Saved {matrix.shape} matrix to {destination}')


if __name__ == '__main__':
    main()
