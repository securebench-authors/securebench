"""Recover first-layer weight directions using only calls to forward(x)."""
from pathlib import Path
import sys

import numpy as np

from forward import forward


DIMENSION = 10


def canonical(vector):
    """Fix the arbitrary magnitude and sign of a hyperplane normal."""
    vector = np.asarray(vector, dtype=float)
    vector = vector / np.linalg.norm(vector)
    if vector[np.argmax(np.abs(vector))] < 0:
        vector = -vector
    return vector


def gradient(x):
    """Finite differences, shrinking any step that straddles a ReLU kink."""
    center = forward(x)
    result = np.empty(DIMENSION)
    for j in range(DIMENSION):
        step = 1e-4 * max(1.0, abs(x[j]))
        for _ in range(24):
            displacement = np.zeros(DIMENSION)
            displacement[j] = step
            plus = forward(x + displacement)
            minus = forward(x - displacement)
            # On one affine region the two one-sided slopes agree.
            noise = 64 * np.finfo(float).eps * max(
                1.0, abs(center), abs(plus), abs(minus)
            )
            if abs(plus + minus - 2 * center) <= noise:
                break
            step *= 0.5
        result[j] = (plus - minus) / (2 * step)
    return result


def line_normals(origin, direction, radius=32.0):
    """Locate isolated changes in slope, refining groups of nearby changes."""
    def query(t):
        return forward(origin + t * direction)

    def scan(left, right, count, depth=0):
        ts = np.linspace(left, right, count)
        values = np.array([query(t) for t in ts])
        slopes = np.diff(values) / np.diff(ts)
        # Account for subtraction error, without depending on unknown weights.
        tolerance = 256 * np.finfo(float).eps * max(
            1.0, np.max(np.abs(values))
        ) / (ts[1] - ts[0])
        changed = np.flatnonzero(np.abs(np.diff(slopes)) > tolerance)
        if not changed.size:
            return
        groups = np.split(changed, np.flatnonzero(np.diff(changed) > 1) + 1)
        for group in groups:
            a, b = int(group[0]), int(group[-1])
            # Keep a fully affine interval on either side of the changes.
            if a == 0 or b + 2 >= len(slopes):
                continue
            lo, hi = ts[a], ts[b + 2]
            slope_left, slope_right = slopes[a - 1], slopes[b + 2]
            jump = slope_right - slope_left
            if abs(jump) <= tolerance:
                if depth < 5:
                    yield from scan(ts[a - 1], ts[b + 3], 129, depth + 1)
                continue
            kink = lo + (values[b + 2] - values[a] - slope_right * (hi - lo)) / (
                slope_left - slope_right
            )
            isolated = lo < kink < hi
            if isolated:
                # A group may contain multiple close kinks. Check that a single
                # hinge actually explains the function before using its normal.
                probes = np.linspace(lo, hi, 17)
                predicted = values[a] + slope_left * (probes - lo)
                predicted += jump * np.maximum(probes - kink, 0)
                actual = np.array([query(t) for t in probes])
                fit_tolerance = 2e-11 * max(1.0, np.max(np.abs(actual)))
                isolated = np.max(np.abs(actual - predicted)) <= fit_tolerance
            if not isolated:
                if depth < 5:
                    yield from scan(ts[a - 1], ts[b + 3], 129, depth + 1)
                continue
            offset = 0.3 * min(kink - lo, hi - kink)
            if offset < 1e-8:
                continue
            before = gradient(origin + (kink - offset) * direction)
            after = gradient(origin + (kink + offset) * direction)
            normal = after - before
            size = np.linalg.norm(normal)
            if size < 1e-10:
                continue
            # Verify the gradient jump against the independently measured slope.
            if abs(np.dot(normal, direction) - jump) > 2e-6 * max(abs(jump), 1e-6):
                continue
            yield canonical(normal)

    yield from scan(-radius, radius, 2049)


def recover():
    rng = np.random.default_rng(314159)
    rows = []
    counts = []
    misses = 0
    for iteration in range(100):
        origin = rng.normal(size=DIMENSION) * (1 + iteration % 3)
        direction = rng.normal(size=DIMENSION)
        direction /= np.linalg.norm(direction)
        discoveries = 0
        for normal in line_normals(origin, direction):
            if rows:
                distances = np.linalg.norm(np.asarray(rows) - normal, axis=1)
                closest = int(np.argmin(distances))
            else:
                distances = np.array([])
            if distances.size and distances[closest] < 1e-5:
                # Keep the original precise estimate; repeated sightings provide
                # a check that this is a real, reproducible hyperplane normal.
                counts[closest] += 1
            else:
                rows.append(normal)
                counts.append(1)
                discoveries += 1
        misses = 0 if discoveries else misses + 1
        if iteration >= 11 and misses >= 8 and all(n >= 3 for n in counts):
            break
    if not rows:
        raise RuntimeError('No observable ReLU boundaries were found.')
    if any(n < 2 for n in counts):
        raise RuntimeError('Some recovered directions could not be confirmed.')
    return np.asarray(rows)


def main():
    matrix = recover()
    destination = Path('/app/stolen_A1.npy')
    np.save(destination, matrix)
    np.set_printoptions(precision=12, linewidth=160, threshold=np.inf)
    print(matrix)
    print(f'Saved {matrix.shape[0]} rows to {destination}', file=sys.stderr)


if __name__ == '__main__':
    main()
