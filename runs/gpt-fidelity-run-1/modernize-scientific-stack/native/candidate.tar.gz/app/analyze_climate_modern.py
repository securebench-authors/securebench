#!/usr/bin/env python3
"""Print mean temperatures for each station in the sample climate data."""

from pathlib import Path

import pandas as pd


def main() -> None:
    data_path = (
        Path(__file__).resolve().parent
        / "climate_analyzer"
        / "sample_data"
        / "climate_data.csv"
    )
    data = pd.read_csv(data_path, encoding="utf-8")

    for station_id, group in data.groupby("station_id", sort=True):
        mean_temperature = group["temperature"].mean()
        print(f"Station {station_id} mean temperature: {mean_temperature:.1f}°C")


if __name__ == "__main__":
    main()
