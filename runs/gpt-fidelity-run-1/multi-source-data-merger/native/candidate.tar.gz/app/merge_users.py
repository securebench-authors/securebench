"""Merge the three user sources and report conflicts after normalization."""

import csv
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
from dateutil.parser import isoparse


ROOT = Path('/app')
ALIASES = {
    'user_id': ('user_id', 'id', 'userId'),
    'name': ('full_name', 'name', 'userName'),
    'email': ('email', 'email_address'),
    'created_date': ('registration_date', 'created_at', 'joined'),
    'status': ('status',),
}


def normalize(record):
    result = {}
    for field, aliases in ALIASES.items():
        for alias in aliases:
            value = record.get(alias)
            if value is not None and value != '':
                result[field] = value
                break
    raw_id = result['user_id']
    if isinstance(raw_id, bool) or str(int(raw_id)) != str(raw_id):
        raise ValueError(f'Invalid integer user ID: {raw_id!r}')
    result['user_id'] = int(raw_id)
    if 'created_date' in result:
        result['created_date'] = isoparse(str(result['created_date'])).date().isoformat()
    if 'status' not in result:
        for alias in ('is_active', 'active'):
            value = record.get(alias)
            if value is None or value == '':
                continue
            text = str(value).lower()
            if text not in ('true', 'false', '1', '0'):
                raise ValueError(f'Invalid active flag: {value!r}')
            result['status'] = 'active' if text in ('true', '1') else 'inactive'
            break
    for field in ('name', 'email', 'status'):
        if field in result:
            result[field] = str(result[field])
    return result


def main():
    with open('/data/source_a/users.json', encoding='utf-8') as handle:
        source_a = json.load(handle)
    with open('/data/source_b/users.csv', newline='', encoding='utf-8') as handle:
        source_b = list(csv.DictReader(handle))
    source_c = pq.read_table('/data/source_c/users.parquet').to_pylist()

    users = {}
    for source, records in (
        ('source_a', source_a), ('source_b', source_b), ('source_c', source_c)
    ):
        for raw in records:
            record = normalize(raw)
            sources = users.setdefault(record['user_id'], {})
            if source in sources:
                raise ValueError(f'Duplicate user {record["user_id"]} in {source}')
            sources[source] = record

    merged, conflicts = [], []
    for user_id, sources in sorted(users.items()):
        row = {'user_id': user_id}
        for field in ('name', 'email', 'created_date', 'status'):
            values = {source: record[field] for source, record in sources.items()
                      if field in record}
            selected = next(iter(values.values()), None)
            row[field] = selected
            if len(set(values.values())) > 1:
                conflicts.append({'user_id': user_id, 'field': field,
                                  'values': values, 'selected': selected})
        merged.append(row)

    schema = pa.schema([
        pa.field('user_id', pa.int64(), nullable=False),
        pa.field('name', pa.string()),
        pa.field('email', pa.string()),
        pa.field('created_date', pa.string()),
        pa.field('status', pa.string()),
    ])
    pq.write_table(pa.Table.from_pylist(merged, schema=schema), ROOT / 'merged_users.parquet')
    report = {'total_conflicts': len(conflicts), 'conflicts': conflicts}
    (ROOT / 'conflicts.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(f'Merged {len(merged)} users; reported {len(conflicts)} field conflicts.')


if __name__ == '__main__':
    main()
