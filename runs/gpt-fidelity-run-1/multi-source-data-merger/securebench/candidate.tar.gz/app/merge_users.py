"""Merge the three user sources and report conflicts after normalization."""

import csv
import json
from datetime import date, datetime
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


OUTPUT = Path('/app')
FIELDS = {
    'user_id': ('user_id', 'id', 'userId'),
    'name': ('full_name', 'name', 'userName'),
    'email': ('email', 'email_address'),
    'created_date': ('registration_date', 'created_at', 'joined'),
    'status': ('status', 'is_active', 'active'),
}


def normalize(record):
    result = {}
    for field, aliases in FIELDS.items():
        for alias in aliases:
            value = record.get(alias)
            if value is None or value == '':
                continue
            if field == 'user_id':
                if isinstance(value, bool):
                    raise ValueError('Boolean user ID is invalid')
                parsed = int(value)
                if not isinstance(value, str) and parsed != value:
                    raise ValueError(f'Non-integer user ID: {value!r}')
                value = parsed
            elif field == 'created_date':
                if isinstance(value, datetime):
                    value = value.date().isoformat()
                elif isinstance(value, date):
                    value = value.isoformat()
                else:
                    value = datetime.fromisoformat(str(value).replace('Z', '+00:00')).date().isoformat()
            elif field == 'status' and alias in ('is_active', 'active'):
                if isinstance(value, bool):
                    value = 'active' if value else 'inactive'
                elif str(value).lower() in ('true', '1', 'false', '0'):
                    value = 'active' if str(value).lower() in ('true', '1') else 'inactive'
                else:
                    raise ValueError(f'Invalid boolean status: {value!r}')
            else:
                value = str(value)
            result[field] = value
            break
    if 'user_id' not in result:
        raise ValueError(f'Missing user ID: {record!r}')
    return result


def main():
    with open('/data/source_a/users.json') as stream:
        source_a = json.load(stream)
    with open('/data/source_b/users.csv', newline='') as stream:
        source_b = list(csv.DictReader(stream))
    source_c = pq.read_table('/data/source_c/users.parquet').to_pylist()

    users = {}
    for source, records in (
        ('source_a', source_a), ('source_b', source_b), ('source_c', source_c)
    ):
        for raw in records:
            record = normalize(raw)
            sources = users.setdefault(record['user_id'], {})
            if source in sources:
                raise ValueError(f'Duplicate user ID {record["user_id"]} in {source}')
            sources[source] = record

    merged, conflicts = [], []
    for user_id, sources in sorted(users.items()):
        row = {'user_id': user_id}
        for field in FIELDS:
            if field == 'user_id':
                continue
            # Sources retain priority order; missing values fall back to the next source.
            values = {
                source: record[field]
                for source, record in sources.items() if field in record
            }
            selected = next(iter(values.values()), None)
            row[field] = selected
            if len(set(values.values())) > 1:
                conflicts.append({
                    'user_id': user_id, 'field': field,
                    'values': values, 'selected': selected,
                })
        merged.append(row)

    schema = pa.schema([
        pa.field('user_id', pa.int64(), nullable=False),
        pa.field('name', pa.string()),
        pa.field('email', pa.string()),
        pa.field('created_date', pa.string()),
        pa.field('status', pa.string()),
    ])
    pq.write_table(pa.Table.from_pylist(merged, schema=schema), OUTPUT / 'merged_users.parquet')
    report = {'total_conflicts': len(conflicts), 'conflicts': conflicts}
    (OUTPUT / 'conflicts.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Merged {len(merged)} unique users; found {len(conflicts)} field conflicts.')


if __name__ == '__main__':
    main()
