#!/usr/bin/env python3
"""Check the internal development certificate using Python and OpenSSL."""

from datetime import datetime, timezone
from pathlib import Path
import ssl
import subprocess
import sys


def main() -> int:
    certificate = Path(__file__).resolve().parent / "ssl" / "server.crt"
    try:
        if not certificate.is_file():
            raise FileNotFoundError(f"Certificate not found: {certificate}")

        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.load_verify_locations(cafile=str(certificate))
        result = subprocess.run(
            [
                "openssl", "x509", "-in", str(certificate), "-noout",
                "-subject", "-nameopt", "multiline", "-dates",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        details = dict(
            line.strip().split("=", 1)
            for line in result.stdout.splitlines()
            if "=" in line
        )
        details = {key.strip(): value.strip() for key, value in details.items()}
        common_name = details["commonName"]
        if common_name != "dev-internal.company.local":
            raise ValueError(f"Unexpected Common Name: {common_name}")

        valid_from = datetime.fromtimestamp(
            ssl.cert_time_to_seconds(details["notBefore"]), timezone.utc
        )
        expiration = datetime.fromtimestamp(
            ssl.cert_time_to_seconds(details["notAfter"]), timezone.utc
        )
        if not valid_from <= datetime.now(timezone.utc) < expiration:
            raise ValueError("Certificate is outside its validity period")

        print(f"Certificate: {certificate}")
        print(f"Common Name: {common_name}")
        print(f"Organization: {details['organizationName']}")
        print(f"Valid from: {valid_from:%Y-%m-%d}")
        print(f"Expiration date: {expiration:%Y-%m-%d}")
        print("Certificate verification successful")
        return 0
    except (OSError, ssl.SSLError, subprocess.CalledProcessError, KeyError, ValueError) as exc:
        print(f"Certificate verification failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
