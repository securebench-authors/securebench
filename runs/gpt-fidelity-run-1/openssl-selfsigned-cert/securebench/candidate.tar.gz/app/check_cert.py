#!/usr/bin/env python3
"""Load and verify the internal development server's certificate."""

from datetime import datetime, timezone
from pathlib import Path
import ssl
import subprocess
import sys


def main():
    cert = Path(__file__).resolve().parent / "ssl" / "server.crt"
    if not cert.is_file():
        raise ValueError(f"Certificate not found: {cert}")

    # Loading the certificate into a trust store checks its PEM encoding.
    ssl.create_default_context(cafile=str(cert))
    subprocess.run(
        ["openssl", "verify", "-CAfile", str(cert), "-check_ss_sig", str(cert)],
        check=True, capture_output=True, text=True,
    )
    result = subprocess.run(
        ["openssl", "x509", "-in", str(cert), "-noout", "-subject",
         "-dates", "-nameopt", "multiline"],
        check=True, capture_output=True, text=True,
    )
    fields = dict(
        line.strip().split("=", 1)
        for line in result.stdout.splitlines() if "=" in line
    )
    fields = {key.strip(): value.strip() for key, value in fields.items()}
    common_name = fields.get("commonName")
    if common_name != "dev-internal.company.local":
        raise ValueError(f"Unexpected Common Name: {common_name!r}")
    expires = datetime.fromtimestamp(
        ssl.cert_time_to_seconds(fields["notAfter"]), timezone.utc
    )
    print(f"Common Name: {common_name}")
    print(f"Organization: {fields.get('organizationName', '')}")
    print(f"Expiration date: {expires:%Y-%m-%d}")
    print("Certificate verification successful")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as exc:
        print(f"Certificate verification failed: {exc}", file=sys.stderr)
        sys.exit(1)
