#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct{float x,y,z;} V;
typedef struct{float t;V p,n;int hit;} H;
V add(V a,V b){return (V){a.x+b.x,a.y+b.y,a.z+b.z};}
V sub(V a,V b){return (V){a.x-b.x,a.y-b.y,a.z-b.z};}
V mul(V a,float b){return (V){a.x*b,a.y*b,a.z*b};}
float dot(V a,V b){return (a.x*b.x+a.y*b.y)+a.z*b.z;}
V norm(V a){float d=sqrtf(dot(a,a));return (V){a.x/d,a.y/d,a.z/d};}
H sphere(V o,V d){
 V c={0,-.5f,-5},q=sub(o,c);float a=dot(d,d),b=2*dot(q,d),cc=(q.y*q.y+q.x*q.x)+q.z*q.z-1,disc=b*b-4*a*cc;
 H h={0};if(disc<0)return h;
 float t=(-b-sqrt((double)disc))/(2*a);
 if(t<.001f){t=(-b+sqrt((double)disc))/(2*a);if(t<.001f)return h;}
 h.t=t;h.p=add(o,mul(d,t));h.n=norm(sub(h.p,c));h.hit=1;return h;
}
V trace(V d,V l){
 H h=sphere((V){0,0,0},d);float t=-1.5f/d.y;V p,n;int ball=h.hit;
 if(fabsf(d.y)>=.0001f && t>=.001f && (!ball||t<=h.t)){ball=0;p=add((V){0,0,0},mul(d,t));n=(V){0,1,0};}
 else if(ball){p=h.p;n=h.n;}
 else{float t=.5f*(d.y+1),s=1-t;return (V){s+.5f*t,s+.7f*t,s+t};}
 H shadow=sphere(add(p,mul(n,.001f)),norm(l));
 float light=shadow.hit?.2f:.2f+.8f*(float)fmax(0,dot(n,l));
 if(ball)return (V){light,.2f*light,.2f*light};
 float c=((int)(floor(p.x)+floor(p.z))&1)?.4f:.9f;return mul((V){c,c,c},light);
}
int main(void){
 fprintf(stderr,"Creating high-resolution image: 800x600\nThis will be downsampled with ffmpeg after rendering\nRendering high-resolution image...\n");
 V *im=malloc(800*600*sizeof(V)),l=norm((V){1,1,-1});
 for(int y=0;y<600;y++){
 fprintf(stderr,"\rProgress: %.1f%%",(double)(100.f*y/600.f));
 float v=(float)y/599,yy=1-v;
 for(int x=0;x<800;x++){
 float u=(float)x/799;
 V d={u*(8.f/3.f)+0.f*yy-4.f/3.f,0.f*u+2.f*yy-1,0.f*u+0.f*yy-1};
 im[y*800+x]=trace(norm(d),l);
 }}
 fprintf(stderr,"\nRendering complete\n");FILE *f=fopen("image.ppm","w");
 if(f){fprintf(f,"P3\n800 600\n255\n");for(int i=0;i<800*600;i++){
 V c=im[i];int r=(float)fmin(1,fmax(0,c.x))*255.99f,g=(float)fmin(1,fmax(0,c.y))*255.99f,b=(float)fmin(1,fmax(0,c.z))*255.99f;
 fprintf(f,"%d %d %d\n",r,g,b);
 }fclose(f);fprintf(stderr,"Wrote image to image.ppm\n");}
 else fprintf(stderr,"Error: Could not open file image.ppm for writing\n");
 free(im);fprintf(stderr,"Done.\n");return 0;
}
