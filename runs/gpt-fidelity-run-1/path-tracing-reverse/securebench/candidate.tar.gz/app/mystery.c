#include <stdio.h>
#include <math.h>
typedef struct{float x,y,z;} V;
typedef struct{float t;V p,n;int hit;} H;
V add(V a,V b){return(V){a.x+b.x,a.y+b.y,a.z+b.z};}
V mul(V a,float t){return(V){a.x*t,a.y*t,a.z*t};}
V norm(V a){float l=sqrtf(a.x*a.x+a.y*a.y+a.z*a.z);return(V){a.x/l,a.y/l,a.z/l};}
H sphere(V o,V d){V q=add(o,(V){0,.5f,5});float a=d.x*d.x+d.y*d.y+d.z*d.z,b=2*(q.x*d.x+q.y*d.y+q.z*d.z),c=q.y*q.y+q.x*q.x+q.z*q.z-1,disc=b*b-(4*a)*c;if(disc<0)return(H){0};float t=(-b-sqrt((double)disc))/(2*a);if(t<.001f)t=(-b+sqrt((double)disc))/(2*a);if(t<.001f)return(H){0};V p=add(o,mul(d,t));return(H){t,p,norm(add(p,(V){0,.5f,5})),1};}
int byte(float a){a=fmin(fmax(a,0),1);return a*255.99f;}
V image[600][800];
int main(){fprintf(stderr,"Creating high-resolution image: 800x600\nThis will be downsampled with ffmpeg after rendering\nRendering high-resolution image...\n");V light=norm((V){1,1,-1});for(int y=0;y<600;y++){fprintf(stderr,"\rProgress: %.1f%%",(double)(100.f*y/600.f));for(int x=0;x<800;x++){float u=x/799.f,v=1-y/599.f;V d=norm((V){u*2.6666667f-1.3333334f,v*2-1,-1});H h=sphere((V){0},d);int hit=h.hit;float t=-1.5f/d.y;V p,n,col;if(fabsf(d.y)>=.0001f&&t>=.001f&&(!hit||t<=h.t)){p=add((V){0},mul(d,t));n=(V){0,1,0};hit=0;}else if(hit){p=h.p;n=h.n;}else{float t=(d.y+1)*.5f;col=(V){(1-t)+.5f*t,(1-t)+.7f*t,(1-t)+t};image[y][x]=col;continue;}H sh=sphere(add(p,mul(n,.001f)),norm(light));float s=.2f;if(!sh.hit){float dot=n.x*light.x+n.y*light.y+n.z*light.z;s+=(float)fmax(dot,0)*.8f;}if(hit)col=(V){s,.2f*s,.2f*s};else{float c=((int)((double)floorf(p.x)+(double)floorf(p.z))&1)?.4f:.9f;col=(V){c*s,c*s,c*s};}image[y][x]=col;}}
fprintf(stderr,"\nRendering complete\n");FILE *f=fopen("image.ppm","w");if(f){fprintf(f,"P3\n800 600\n255\n");for(int y=0;y<600;y++)for(int x=0;x<800;x++){V c=image[y][x];fprintf(f,"%d %d %d\n",byte(c.x),byte(c.y),byte(c.z));}fclose(f);fprintf(stderr,"Wrote image to image.ppm\n");}else fprintf(stderr,"Error: Could not open file image.ppm for writing\n");fprintf(stderr,"Done.\n");return 0;}
