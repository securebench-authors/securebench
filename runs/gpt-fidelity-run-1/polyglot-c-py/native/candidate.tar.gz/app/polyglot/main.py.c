#if 0
""" "
#endif

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Base-10^9 limbs keep the C result exact even beyond machine integers. */
#define BASE 1000000000U

typedef struct {
    uint32_t *digits;
    size_t length;
    size_t capacity;
} Integer;

static void reserve(Integer *value, size_t capacity)
{
    if (capacity <= value->capacity)
        return;
    if (capacity > SIZE_MAX / sizeof(*value->digits)) {
        fputs("Number too large\n", stderr);
        exit(EXIT_FAILURE);
    }
    uint32_t *digits = realloc(value->digits, capacity * sizeof(*digits));
    if (!digits) {
        fputs("Out of memory\n", stderr);
        exit(EXIT_FAILURE);
    }
    value->digits = digits;
    value->capacity = capacity;
}

static void add(Integer *a, const Integer *b)
{
    size_t length = a->length > b->length ? a->length : b->length;
    reserve(a, length + 1);
    uint64_t carry = 0;
    for (size_t i = 0; i < length; ++i) {
        uint64_t sum = carry;
        if (i < a->length)
            sum += a->digits[i];
        if (i < b->length)
            sum += b->digits[i];
        a->digits[i] = (uint32_t)(sum % BASE);
        carry = sum / BASE;
    }
    a->length = length;
    if (carry)
        a->digits[a->length++] = (uint32_t)carry;
}

int main(int argc, char **argv)
{
    if (argc != 2 || !argv[1][0]) {
        fputs("Usage: program N (a nonnegative integer)\n", stderr);
        return EXIT_FAILURE;
    }
    for (const char *p = argv[1]; *p; ++p) {
        if (*p < '0' || *p > '9') {
            fputs("N must be a nonnegative integer\n", stderr);
            return EXIT_FAILURE;
        }
    }
    errno = 0;
    unsigned long long n = strtoull(argv[1], NULL, 10);
    if (errno == ERANGE) {
        fputs("N is too large\n", stderr);
        return EXIT_FAILURE;
    }

    Integer a = {NULL, 1, 0}, b = {NULL, 1, 0};
    reserve(&a, 1);
    reserve(&b, 1);
    a.digits[0] = 0;
    b.digits[0] = 1;
    for (unsigned long long i = 0; i < n; ++i) {
        add(&a, &b);
        Integer temporary = a;
        a = b;
        b = temporary;
    }

    printf("%u", (unsigned int)a.digits[a.length - 1]);
    for (size_t i = a.length - 1; i > 0; --i)
        printf("%09u", (unsigned int)a.digits[i - 1]);
    putchar('\n');
    free(a.digits);
    free(b.digits);
    return EXIT_SUCCESS;
}

#if 0
" """

import sys


def main():
    if len(sys.argv) != 2 or not sys.argv[1]:
        sys.exit("Usage: program N (a nonnegative integer)")
    if any(c < "0" or c > "9" for c in sys.argv[1]):
        sys.exit("N must be a nonnegative integer")

    # Python 3.12 limits decimal conversions by default; allow large results.
    if hasattr(sys, "set_int_max_str_digits"):
        sys.set_int_max_str_digits(0)
    n = int(sys.argv[1])
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    print(a)


if __name__ == "__main__":
    main()

#endif
