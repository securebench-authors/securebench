#if 0
""" # "
#endif

#include <errno.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Store arbitrary-precision integers in little-endian base 10^9. */
typedef struct {
    uint32_t *digits;
    size_t length;
    size_t capacity;
} Integer;

static void add(Integer *a, const Integer *b)
{
    size_t length = a->length > b->length ? a->length : b->length;
    if (a->capacity <= length) {
        size_t capacity = length + 1;
        uint32_t *digits = realloc(a->digits, capacity * sizeof(*digits));
        if (!digits) {
            fputs("Out of memory\n", stderr);
            exit(EXIT_FAILURE);
        }
        a->digits = digits;
        a->capacity = capacity;
    }

    uint32_t carry = 0;
    for (size_t i = 0; i < length; ++i) {
        uint32_t sum = carry;
        if (i < a->length) sum += a->digits[i];
        if (i < b->length) sum += b->digits[i];
        a->digits[i] = sum % 1000000000;
        carry = sum / 1000000000;
    }
    a->length = length;
    if (carry) a->digits[a->length++] = carry;
}

int main(int argc, char **argv)
{
    if (argc != 2 || !argv[1][0]) {
        fputs("Usage: program N (a nonnegative integer)\n", stderr);
        return EXIT_FAILURE;
    }
    for (const char *p = argv[1]; *p; ++p) {
        if (*p < '0' || *p > '9') {
            fputs("N must be a nonnegative integer\n", stderr);
            return EXIT_FAILURE;
        }
    }
    errno = 0;
    uintmax_t n = strtoumax(argv[1], NULL, 10);
    if (errno == ERANGE) {
        fputs("N is too large\n", stderr);
        return EXIT_FAILURE;
    }

    Integer a = {calloc(1, sizeof(uint32_t)), 1, 1};
    Integer b = {calloc(1, sizeof(uint32_t)), 1, 1};
    if (!a.digits || !b.digits) {
        free(a.digits);
        free(b.digits);
        fputs("Out of memory\n", stderr);
        return EXIT_FAILURE;
    }
    b.digits[0] = 1;
    for (uintmax_t i = 0; i < n; ++i) {
        add(&a, &b);
        Integer temporary = a;
        a = b;
        b = temporary;
    }
    printf("%" PRIu32, a.digits[a.length - 1]);
    for (size_t i = a.length - 1; i > 0; --i)
        printf("%09" PRIu32, a.digits[i - 1]);
    putchar('\n');
    free(a.digits);
    free(b.digits);
    return EXIT_SUCCESS;
}

#if 0
""" # "

import sys

if len(sys.argv) != 2 or not sys.argv[1] or any(
    c < "0" or c > "9" for c in sys.argv[1]
):
    sys.exit("Usage: program N (a nonnegative integer)")

# Python 3.12 limits decimal conversion length by default; Fibonacci grows fast.
sys.set_int_max_str_digits(0)
n = int(sys.argv[1])
a, b = 0, 1
for _ in range(n):
    a, b = b, a + b
print(a)

#endif
