// The backslashes on the two special comment lines must remain last on the line.
// C++ splices those lines before parsing comments; Rust does not.
//\
/*
#include <algorithm>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: program N (a nonnegative 64-bit integer)\n";
        return 1;
    }
    const std::string input = argv[1];
    std::uint64_t n = 0;
    if (input.empty()) {
        std::cerr << "Invalid N\n";
        return 1;
    }
    for (char c : input) {
        if (c < '0' || c > '9' ||
            n > (std::numeric_limits<std::uint64_t>::max() - (c - '0')) / 10) {
            std::cerr << "Invalid N\n";
            return 1;
        }
        n = n * 10 + (c - '0');
    }

    // Little-endian base-10^9 limbs keep the result exact beyond 64 bits.
    const std::uint32_t base = 1000000000;
    std::vector<std::uint32_t> a{1}, b{1};
    for (std::uint64_t i = 0; i < n; ++i) {
        a.resize(std::max(a.size(), b.size()), 0);
        std::uint32_t carry = 0;
        for (std::size_t j = 0; j < a.size(); ++j) {
            const std::uint32_t sum = a[j] + (j < b.size() ? b[j] : 0) + carry;
            a[j] = sum % base;
            carry = sum / base;
        }
        if (carry) a.push_back(carry);
        a.swap(b);
    }
    std::cout << a.back();
    for (std::size_t j = a.size() - 1; j > 0; --j)
        std::cout << std::setfill('0') << std::setw(9) << a[j - 1];
    std::cout << '\n';
}
#if 0
*/

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() != 2 {
        eprintln!("Usage: program N (a nonnegative 64-bit integer)");
        std::process::exit(1);
    }
    let n = if !args[1].is_empty() && args[1].bytes().all(|c| c.is_ascii_digit()) {
        args[1].parse::<u64>().ok()
    } else {
        None
    };
    let n = n.unwrap_or_else(|| {
        eprintln!("Invalid N");
        std::process::exit(1);
    });

    // Little-endian base-10^9 limbs keep the result exact beyond 64 bits.
    let base: u32 = 1_000_000_000;
    let (mut a, mut b) = (vec![1u32], vec![1u32]);
    for _ in 0..n {
        a.resize(a.len().max(b.len()), 0);
        let mut carry = 0;
        for j in 0..a.len() {
            let sum = a[j] + b.get(j).copied().unwrap_or(0) + carry;
            a[j] = sum % base;
            carry = sum / base;
        }
        if carry != 0 {
            a.push(carry);
        }
        std::mem::swap(&mut a, &mut b);
    }
    use std::io::Write;
    let stdout = std::io::stdout();
    let mut out = std::io::BufWriter::new(stdout.lock());
    write!(out, "{}", a.last().unwrap()).unwrap();
    for limb in a[..a.len() - 1].iter().rev() {
        write!(out, "{:09}", limb).unwrap();
    }
    writeln!(out).unwrap();
}

//\
/*
#endif
// */
