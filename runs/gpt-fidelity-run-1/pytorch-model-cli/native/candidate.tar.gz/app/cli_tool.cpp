#include "cJSON.h"
#include "lodepng.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

struct Layer {
    size_t inputs;
    std::vector<std::vector<float>> weights;
    std::vector<float> biases;

    std::vector<float> forward(const std::vector<float>& input, bool relu) const {
        std::vector<float> output(biases.size());
        for (size_t row = 0; row < output.size(); ++row) {
            float value = biases[row];
            for (size_t col = 0; col < inputs; ++col)
                value += weights[row][col] * input[col];
            if (!std::isfinite(value))
                throw std::runtime_error("Non-finite model output");
            output[row] = relu ? std::max(0.0f, value) : value;
        }
        return output;
    }
};

static float number(const cJSON* item) {
    if (!cJSON_IsNumber(item) || !std::isfinite(item->valuedouble) ||
        !std::isfinite(static_cast<float>(item->valuedouble)))
        throw std::runtime_error("Weights must contain finite numbers");
    return static_cast<float>(item->valuedouble);
}

static Layer load_layer(const cJSON* root, const std::string& name, size_t inputs) {
    const cJSON* matrix = cJSON_GetObjectItemCaseSensitive(root, (name + ".weight").c_str());
    const cJSON* bias = cJSON_GetObjectItemCaseSensitive(root, (name + ".bias").c_str());
    if (!cJSON_IsArray(matrix) || !cJSON_IsArray(bias) ||
        cJSON_GetArraySize(matrix) == 0 ||
        cJSON_GetArraySize(matrix) != cJSON_GetArraySize(bias))
        throw std::runtime_error("Missing or invalid layer: " + name);
    Layer layer{inputs, {}, {}};
    const cJSON* row = nullptr;
    cJSON_ArrayForEach(row, matrix) {
        if (!cJSON_IsArray(row) || static_cast<size_t>(cJSON_GetArraySize(row)) != inputs)
            throw std::runtime_error("Invalid weight dimensions: " + name);
        std::vector<float> values;
        const cJSON* value = nullptr;
        cJSON_ArrayForEach(value, row) values.push_back(number(value));
        layer.weights.push_back(std::move(values));
    }
    const cJSON* value = nullptr;
    cJSON_ArrayForEach(value, bias) layer.biases.push_back(number(value));
    return layer;
}

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " weights.json image.png\n";
        return 1;
    }
    try {
        std::ifstream file(argv[1], std::ios::binary);
        if (!file) throw std::runtime_error("Cannot open weights file");
        std::string contents((std::istreambuf_iterator<char>(file)), {});
        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(
            cJSON_ParseWithOpts(contents.c_str(), nullptr, true), cJSON_Delete);
        if (!root || !cJSON_IsObject(root.get()))
            throw std::runtime_error("Invalid weights JSON");
        const Layer input = load_layer(root.get(), "input_layer", 784);
        const Layer hidden = load_layer(root.get(), "hidden_layer", input.biases.size());
        const Layer output = load_layer(root.get(), "output_layer", hidden.biases.size());
        if (output.biases.size() != 10)
            throw std::runtime_error("Expected ten output classes");

        std::vector<unsigned char> pixels;
        unsigned width = 0, height = 0;
        const unsigned error = lodepng::decode(pixels, width, height, argv[2]);
        if (error) throw std::runtime_error(std::string("Cannot decode image: ") + lodepng_error_text(error));
        if (width != 28 || height != 28)
            throw std::runtime_error("Expected a 28x28 MNIST image");
        std::vector<float> values(784);
        for (size_t i = 0; i < values.size(); ++i) {
            // MNIST uses grayscale intensities in [0, 1], flattened row by row.
            const size_t p = 4 * i;
            const double gray = 0.299 * pixels[p] + 0.587 * pixels[p + 1] + 0.114 * pixels[p + 2];
            values[i] = static_cast<float>(gray / 255.0);
        }
        values = input.forward(values, true);
        values = hidden.forward(values, true);
        values = output.forward(values, false);
        const auto digit = std::max_element(values.begin(), values.end()) - values.begin();
        std::cout << digit << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
}
