"""Export the supplied PyTorch state dictionary without requiring PyTorch."""
import collections
import io
import json
import pickle
import struct
import zipfile


def rebuild_tensor(storage, offset, shape, stride, *_):
    values = storage

    def unpack(axis, index):
        if axis == len(shape):
            return values[index]
        return [unpack(axis + 1, index + i * stride[axis])
                for i in range(shape[axis])]

    return unpack(0, offset)


class StateReader(pickle.Unpickler):
    def find_class(self, module, name):
        allowed = {
            ('collections', 'OrderedDict'): collections.OrderedDict,
            ('torch._utils', '_rebuild_tensor_v2'): rebuild_tensor,
            ('torch', 'FloatStorage'): 'float32',
        }
        if (module, name) not in allowed:
            raise ValueError(f'Unsupported checkpoint type: {module}.{name}')
        return allowed[module, name]

    def persistent_load(self, item):
        kind, dtype, key, location, count = item
        if kind != 'storage' or dtype != 'float32':
            raise ValueError('Expected float32 storage')
        data = self.archive.read(self.root + 'data/' + key)
        return struct.unpack(self.byteorder + str(count) + 'f', data)


if __name__ == '__main__':
    with zipfile.ZipFile('model.pth') as archive:
        entry = next(n for n in archive.namelist() if n.endswith('/data.pkl'))
        reader = StateReader(io.BytesIO(archive.read(entry)))
        reader.archive = archive
        reader.root = entry[:-len('data.pkl')]
        reader.byteorder = '<' if archive.read(reader.root + 'byteorder') == b'little' else '>'
        state = reader.load()
    with open('weights.json', 'w') as output:
        json.dump(state, output, allow_nan=False, separators=(',', ':'))
        output.write('\n')
