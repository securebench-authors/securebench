#include "cJSON.h"
#include "lodepng.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using Vector = std::vector<float>;

static float number(const cJSON* value) {
    if (!cJSON_IsNumber(value) || !std::isfinite(value->valuedouble) ||
        !std::isfinite(static_cast<float>(value->valuedouble)))
        throw std::runtime_error("Weights must contain finite numbers");
    return static_cast<float>(value->valuedouble);
}

static Vector array(const cJSON* value, int length) {
    if (!cJSON_IsArray(value) || cJSON_GetArraySize(value) != length)
        throw std::runtime_error("Incorrect weight dimensions");
    Vector result;
    result.reserve(length);
    for (const cJSON* element = value->child; element; element = element->next)
        result.push_back(number(element));
    return result;
}

struct Linear {
    Vector weights, bias;
    int inputs, outputs;

    Linear(const cJSON* root, const std::string& name, int in, int out)
        : inputs(in), outputs(out) {
        bias = array(cJSON_GetObjectItemCaseSensitive(root, (name + ".bias").c_str()), out);
        const cJSON* matrix = cJSON_GetObjectItemCaseSensitive(root, (name + ".weight").c_str());
        if (!cJSON_IsArray(matrix) || cJSON_GetArraySize(matrix) != out)
            throw std::runtime_error("Incorrect weight dimensions");
        weights.reserve(in * out);
        for (const cJSON* row = matrix->child; row; row = row->next) {
            Vector values = array(row, in);
            weights.insert(weights.end(), values.begin(), values.end());
        }
    }

    Vector forward(const Vector& input, bool relu) const {
        Vector result(outputs);
        for (int row = 0; row < outputs; ++row) {
            float value = bias[row];
            for (int col = 0; col < inputs; ++col)
                value += weights[row * inputs + col] * input[col];
            if (!std::isfinite(value))
                throw std::runtime_error("Non-finite model output");
            result[row] = relu ? std::max(0.0f, value) : value;
        }
        return result;
    }
};

int main(int argc, char** argv) {
    try {
        if (argc != 3)
            throw std::runtime_error("Usage: ./cli_tool weights.json image.png");
        std::ifstream file(argv[1], std::ios::binary);
        if (!file) throw std::runtime_error("Cannot open weights file");
        std::string json((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(
            cJSON_ParseWithOpts(json.c_str(), nullptr, 1), cJSON_Delete);
        if (!root || !cJSON_IsObject(root.get()))
            throw std::runtime_error("Invalid weights JSON");
        Linear input_layer(root.get(), "input_layer", 784, 16);
        Linear hidden_layer(root.get(), "hidden_layer", 16, 16);
        Linear output_layer(root.get(), "output_layer", 16, 10);

        std::vector<unsigned char> pixels;
        unsigned width = 0, height = 0;
        unsigned error = lodepng::decode(pixels, width, height, argv[2]);
        if (error) throw std::runtime_error(std::string("Cannot decode PNG: ") + lodepng_error_text(error));
        if (width != 28 || height != 28)
            throw std::runtime_error("Expected a 28x28 PNG image");
        Vector input(784);
        for (int i = 0; i < 784; ++i) {
            // Convert RGB to grayscale, composite alpha on black, and scale to [0, 1].
            float gray = (0.299f * pixels[4*i] + 0.587f * pixels[4*i+1] +
                          0.114f * pixels[4*i+2]);
            input[i] = (gray / 255.0f) * (pixels[4*i+3] / 255.0f);
        }
        Vector logits = output_layer.forward(
            hidden_layer.forward(input_layer.forward(input, true), true), false);
        std::cout << std::distance(logits.begin(), std::max_element(logits.begin(), logits.end())) << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
