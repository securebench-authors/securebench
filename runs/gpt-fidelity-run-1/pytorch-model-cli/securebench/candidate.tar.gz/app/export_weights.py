"""Export the supplied float32 PyTorch state dictionary without requiring PyTorch."""
import collections
import io
import json
import pickle
import struct
import zipfile
from pathlib import Path


class StateReader(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) == ('collections', 'OrderedDict'):
            return collections.OrderedDict
        if (module, name) == ('torch', 'FloatStorage'):
            return 'float32'
        if (module, name) == ('torch._utils', '_rebuild_tensor_v2'):
            return self.tensor
        raise ValueError(f'Unsupported pickle global: {module}.{name}')

    def persistent_load(self, item):
        kind, dtype, key, device, size = item
        if kind != 'storage' or dtype != 'float32':
            raise ValueError('Expected float32 storage')
        raw = self.archive.read(self.prefix + 'data/' + key)
        return struct.unpack(self.endian + str(size) + 'f', raw)

    @staticmethod
    def tensor(storage, offset, shape, stride, requires_grad, hooks):
        def unpack(axis, index):
            if axis == len(shape):
                return storage[index]
            return [unpack(axis + 1, index + i * stride[axis])
                    for i in range(shape[axis])]
        return unpack(0, offset)


if __name__ == '__main__':
    base = Path(__file__).resolve().parent
    with zipfile.ZipFile(base / 'model.pth') as archive:
        name = next(n for n in archive.namelist() if n.endswith('/data.pkl'))
        reader = StateReader(io.BytesIO(archive.read(name)))
        reader.archive = archive
        reader.prefix = name[:-len('data.pkl')]
        reader.endian = '<' if archive.read(reader.prefix + 'byteorder') == b'little' else '>'
        state = reader.load()
    (base / 'weights.json').write_text(json.dumps(state, allow_nan=False) + '\n')
