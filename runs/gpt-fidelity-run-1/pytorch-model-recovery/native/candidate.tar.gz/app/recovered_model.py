from typing import Optional

import torch
from torch import Tensor, nn


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int = 128, max_len: int = 5000):
        super().__init__()
        position = torch.arange(max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32)
                             * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)
        self.dropout = nn.Dropout(0.1)

    def forward(self, x: Tensor) -> Tensor:
        return self.dropout(x + self.pe[:, :x.size(1), :])


class RecoveredModel(nn.Module):
    """State-compatible transformer reconstruction.

    Non-serialized choices: eight attention heads, ReLU, batch-first,
    post-norm, dropout 0.1, and no attention masks. With one input, the
    source embedding is also the decoder input. An explicit decoder input
    can optionally be supplied as the second argument.
    """
    def __init__(self):
        super().__init__()
        self.embedding = nn.Linear(64, 128)
        self.pos_encoder = PositionalEncoding()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=128, nhead=8, dim_feedforward=256, dropout=0.1,
            activation='relu', batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer, num_layers=3, enable_nested_tensor=False)
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=128, nhead=8, dim_feedforward=256, dropout=0.1,
            activation='relu', batch_first=True)
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=1)
        self.output_layer = nn.Linear(128, 64)

    @torch.jit.export
    def features(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        src_emb = self.pos_encoder(self.embedding(src))
        memory = self.transformer_encoder(src_emb)
        if tgt is None:
            tgt_emb = src_emb
        else:
            tgt_emb = self.pos_encoder(self.embedding(tgt))
        return self.transformer_decoder(tgt_emb, memory)

    def forward(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        return self.output_layer(self.features(src, tgt))
