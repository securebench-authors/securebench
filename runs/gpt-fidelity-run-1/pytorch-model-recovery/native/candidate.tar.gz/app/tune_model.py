import hashlib
import json
from pathlib import Path

import torch
from recovered_model import RecoveredModel


def main():
    torch.set_num_threads(2)
    torch.manual_seed(0)
    weights_path = Path('/app/weights.pt')
    original_hash = hashlib.sha256(weights_path.read_bytes()).hexdigest()
    original = torch.load(weights_path, map_location='cpu', weights_only=True)
    data = torch.load('/app/dataset.pt', map_location='cpu', weights_only=True)
    src, target = data['src_sequences'], data['tgt_sequences']
    model = RecoveredModel().eval()
    model.load_state_dict(original, strict=True)
    for p in model.parameters():
        p.requires_grad_(False)
    model.output_layer.weight.requires_grad_(True)
    with torch.no_grad():
        before = torch.mean((model(src) - target) ** 2).item()
        features = model.features(src).reshape(-1, 128).double()
        residual_target = (target.reshape(-1, 64).double()
                           - model.output_layer.bias.double())
        # Solve the linear head exactly on the frozen features. Only its
        # weight changes; even the output bias is preserved bit-for-bit.
        solution = torch.linalg.lstsq(features, residual_target, driver='gelsd').solution
        model.output_layer.weight.copy_(solution.T.float())
        after = torch.mean((model(src) - target) ** 2).item()
    assert after < before, (before, after)
    changed = [key for key, value in model.state_dict().items()
               if not torch.equal(value, original[key])]
    assert changed == ['output_layer.weight'], changed
    scripted = torch.jit.script(model)
    scripted.save('/app/model.pt')
    loaded = torch.jit.load('/app/model.pt', map_location='cpu').eval()
    with torch.no_grad():
        saved_loss = torch.mean((loaded(src) - target) ** 2).item()
    assert saved_loss < before
    assert set(loaded.state_dict()) == set(original)
    assert [k for k, v in loaded.state_dict().items()
            if not torch.equal(v, original[k])] == ['output_layer.weight']
    # Verify strict compatibility on a second instance, retaining the tuned artifact.
    compatibility = torch.jit.load('/app/model.pt', map_location='cpu').eval()
    compatibility.load_state_dict(original, strict=True)
    with torch.no_grad():
        restored_loss = torch.mean((compatibility(src) - target) ** 2).item()
    assert abs(restored_loss - before) < 1e-6
    assert hashlib.sha256(weights_path.read_bytes()).hexdigest() == original_hash
    report = {
        'original_mse': before,
        'updated_mse': saved_loss,
        'relative_reduction_percent': 100 * (before - saved_loss) / before,
        'changed_state_dict_keys': changed,
        'strict_original_weight_loading_verified': True,
        'original_weights_sha256': original_hash,
        'original_weights_unchanged': True,
        'architecture_assumptions': {
            'nhead': 8, 'batch_first': True, 'activation': 'relu',
            'norm_first': False, 'decoder_input': 'source when not explicitly supplied',
            'attention_mask': None,
        },
    }
    Path('/app/results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
