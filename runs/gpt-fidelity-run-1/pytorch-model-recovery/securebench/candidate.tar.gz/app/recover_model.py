"""Reconstruct the Transformer and fit only its final weight matrix.

Non-tensor settings are not recoverable from a state dictionary. This uses
8 attention heads, ReLU, post-normalization, batch-first sequences, and the
source as the default decoder input. An explicit decoder input is supported.
"""
import hashlib
import json
from typing import Optional

import torch
from torch import Tensor, nn


class PositionalEncoding(nn.Module):
    def __init__(self, pe: Tensor):
        super().__init__()
        self.register_buffer('pe', torch.empty_like(pe))
        self.dropout = nn.Dropout(0.1)

    def forward(self, x: Tensor) -> Tensor:
        return self.dropout(x + self.pe[:, :x.size(1)])


class RecoveredModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = nn.Linear(64, 128)
        self.pos_encoder = PositionalEncoding(torch.empty(1, 5000, 128))
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=128, nhead=8, dim_feedforward=256, dropout=0.1,
            activation='relu', batch_first=True, norm_first=False)
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer, num_layers=3, enable_nested_tensor=False)
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=128, nhead=8, dim_feedforward=256, dropout=0.1,
            activation='relu', batch_first=True, norm_first=False)
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=1)
        self.output_layer = nn.Linear(128, 64)

    @torch.jit.export
    def features(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        decoder_input = src if tgt is None else tgt
        memory = self.transformer_encoder(self.pos_encoder(self.embedding(src)))
        target = self.pos_encoder(self.embedding(decoder_input))
        return self.transformer_decoder(target, memory)

    def forward(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        return self.output_layer(self.features(src, tgt))


def file_hash(path):
    with open(path, 'rb') as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def main():
    torch.set_num_threads(2)
    torch.manual_seed(0)
    weights_path = '/app/weights.pt'
    original_hash = file_hash(weights_path)
    original = torch.load(weights_path, map_location='cpu', weights_only=True)
    data = torch.load('/app/dataset.pt', map_location='cpu', weights_only=True)
    src, targets = data['src_sequences'], data['tgt_sequences']
    model = RecoveredModel()
    model.load_state_dict(original, strict=True)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.output_layer.weight.requires_grad_(True)

    with torch.no_grad():
        initial_loss = (model(src) - targets).square().mean().item()
        features = model.features(src).reshape(-1, 128).double()
        responses = (targets.reshape(-1, 64) - model.output_layer.bias).double()
        # The final projection is linear, so least squares gives the optimal
        # weight matrix for the frozen features without iterative training.
        solution = torch.linalg.lstsq(features, responses, driver='gelsd').solution
        model.output_layer.weight.copy_(solution.T.float())
        tuned_loss = (model(src) - targets).square().mean().item()
    assert tuned_loss < initial_loss, (initial_loss, tuned_loss)
    changed = [key for key, value in model.state_dict().items()
               if not torch.equal(value, original[key])]
    assert changed == ['output_layer.weight'], changed

    scripted = torch.jit.script(model)
    scripted.save('/app/model.pt')
    restored = torch.jit.load('/app/model.pt').eval()
    with torch.no_grad():
        saved_loss = (restored(src) - targets).square().mean().item()
    assert saved_loss < initial_loss
    assert set(restored.state_dict()) == set(original)
    assert all(torch.equal(value, original[key])
               for key, value in restored.state_dict().items()
               if key != 'output_layer.weight')
    # Verify strict loading on a separate instance, preserving the tuned file.
    compatibility_check = torch.jit.load('/app/model.pt').eval()
    compatibility_check.load_state_dict(original, strict=True)
    with torch.no_grad():
        restored_original_loss = (compatibility_check(src) - targets).square().mean().item()
    assert abs(restored_original_loss - initial_loss) < 1e-6
    assert file_hash(weights_path) == original_hash
    report = {
        'original_mse': initial_loss,
        'updated_mse': saved_loss,
        'changed_tensors': changed,
        'original_weights_sha256': original_hash,
        'strict_original_weights_load': True,
        'architecture_settings': {
            'attention_heads': 8, 'batch_first': True, 'activation': 'relu',
            'norm_first': False, 'default_decoder_input': 'src',
        },
    }
    with open('/app/recovery_report.json', 'w') as handle:
        json.dump(report, handle, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
