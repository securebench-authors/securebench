"""Compile a white chess move generator into Python regex substitutions."""
import json
from pathlib import Path

rules = []
def add(pattern, replacement):
    rules.append([pattern, replacement])

# A working board is 64 cells in FEN order; '.' is an empty square.
add(r'^([^ ]+) w ([KQkq-]+) ([a-h][36]|-)(?: .*?)?$', r'@\1 \2 \3\n')
for n in range(8, 0, -1):
    add(str(n) + r'(?=[^ \n]* )', '.' * n)
add('/', '')
add(r'(?m)^(@[^ ]+) - ', r'\1  ')


def coord(i):
    return chr(97 + i % 8) + str(8 - i // 8)


def compact(cells):
    """A fixed-length pattern, compacting consecutive unconstrained cells."""
    out = ''
    run = 0
    for c in cells:
        if c == '.':
            run += 1
        else:
            if run:
                out += '.' if run == 1 else '.{' + str(run) + '}'
                run = 0
            out += c
    if run:
        out += '.' if run == 1 else '.{' + str(run) + '}'
    return out


def move(src, dst, piece, extra=None, changes=None, promotion=False, ep='-', ep_required=None, guard=''):
    constraints = dict(extra or {})
    constraints[src] = '(?P<p>' + piece + ')'
    constraints.setdefault(dst, '[.pnbrq]')
    changes = dict(changes or {})
    changes[src] = '.'
    changes[dst] = 'Q' if promotion else r'\g<p>'
    pattern = '(?m)^@' + guard
    replacement = '!'
    start = 0
    for j, idx in enumerate(sorted(changes)):
        if idx > start:
            name = 'b' + str(j)
            pattern += '(?P<' + name + '>' + compact([constraints.get(k, '.') for k in range(start, idx)]) + ')'
            replacement += '\\g<' + name + '>'
        pattern += constraints.get(idx, '.')
        replacement += changes[idx]
        start = idx + 1
    if start < 64:
        pattern += '(?P<tail>' + compact([constraints.get(k, '.') for k in range(start, 64)]) + ')'
        replacement += r'\g<tail>'
    pattern += r' (?P<r>[KQkq]*) (?P<e>' + (ep_required or r'[^ \n]+') + r')\n'
    replacement += r' \g<r> ' + ep + ' ' + coord(src) + coord(dst) + '\n' + r'\g<0>'
    add(pattern, replacement)


# Attack patterns describe an attacked square on a board starting at offset 0.
def attack_patterns(target):
    tr, tf = divmod(target, 8)
    patterns = []
    for src in range(64):
        sr, sf = divmod(src, 8)
        dr, df = tr - sr, tf - sf
        constraints = {}
        if (abs(dr), abs(df)) in ((1, 2), (2, 1)):
            constraints[src] = 'n'
        elif max(abs(dr), abs(df)) == 1:
            # A pawn moves down the FEN board; kings attack adjacent cells.
            constraints[src] = '[kp]' if dr == 1 and abs(df) == 1 else 'k'
        if constraints:
            # Ignore unconstrained cells after the last condition.
            patterns.append(compact([constraints.get(i, '.') for i in range(max(constraints) + 1)]))
        if src == target:
            continue
        if dr == 0 or df == 0 or abs(dr) == abs(df):
            constraints = {src: '[rq]' if dr == 0 or df == 0 else '[bq]'}
            stepr = (dr > 0) - (dr < 0)
            stepf = (df > 0) - (df < 0)
            r, f = sr + stepr, sf + stepf
            while (r, f) != (tr, tf):
                constraints[r * 8 + f] = r'\.'
                r, f = r + stepr, f + stepf
            patterns.append(compact([constraints.get(i, '.') for i in range(max(constraints) + 1)]))
    return '(?:' + '|'.join(patterns) + ')'


attacks = [attack_patterns(i) for i in range(64)]

# Kings first gives the requested example's output order.
for src in range(64):
    sr, sf = divmod(src, 8)
    for dst in range(64):
        dr, df = divmod(dst, 8)
        if max(abs(dr - sr), abs(df - sf)) == 1:
            move(src, dst, 'K')

for src in range(64):
    sr, sf = divmod(src, 8)
    for dst in range(64):
        dr, df = divmod(dst, 8)
        if (abs(dr - sr), abs(df - sf)) in ((1, 2), (2, 1)):
            move(src, dst, 'N')

for diagonal, pieces in ((True, '[BQ]'), (False, '[RQ]')):
    for src in range(64):
        sr, sf = divmod(src, 8)
        for dst in range(64):
            tr, tf = divmod(dst, 8)
            dr, df = tr - sr, tf - sf
            if src == dst:
                continue
            if not (abs(dr) == abs(df) if diagonal else (dr == 0 or df == 0)):
                continue
            stepr = (dr > 0) - (dr < 0)
            stepf = (df > 0) - (df < 0)
            extra = {}
            r, f = sr + stepr, sf + stepf
            while (r, f) != (tr, tf):
                extra[r * 8 + f] = r'\.'
                r, f = r + stepr, f + stepf
            move(src, dst, pieces, extra)

for src in range(8, 56):
    row, file = divmod(src, 8)
    move(src, src - 8, 'P', {src - 8: r'\.'}, promotion=row == 1)
    for df in (-1, 1):
        if 0 <= file + df < 8:
            dst = src - 8 + df
            move(src, dst, 'P', {dst: '[pnbrq]'}, promotion=row == 1)
            if row == 3:
                captured = src + df
                move(src, dst, 'P', {dst: r'\.', captured: 'p'}, changes={captured: '.'}, ep_required=coord(dst))
    if row == 6:
        move(src, src - 16, 'P', {src - 8: r'\.', src - 16: r'\.'}, ep=coord(src - 8))

# Castling requires the original king square and transit square to be safe.
# The usual final-board king safety pass also checks the destination square.
for dst, rook_src, rook_dst, right, empty, transit in (
    (62, 63, 61, 'K', (61, 62), 61),
    (58, 56, 59, 'Q', (57, 58, 59), 59),
):
    guard = '(?!' + attacks[60] + ')(?!' + attacks[transit] + ')'
    guard += r'(?=.{64} [KQkq]*' + right + ')'
    extra = {i: r'\.' for i in empty}
    extra[rook_src] = 'R'
    move(60, dst, 'K', extra, changes={rook_src: '.', rook_dst: 'R'}, guard=guard)

# The original record is no longer needed.
add(r'(?m)^@[^\n]*\n', '')

# Remove castling rights affected by the source and destination squares.
for right, tag in (
    ('K', r'(?:e1..|h1..|..h1)'),
    ('Q', r'(?:e1..|a1..|..a1)'),
    ('k', r'..h8'),
    ('q', r'..a8'),
):
    add(r'(?m)^(!.{64} )([KQkq]*)' + right + r'([KQkq]*)( [^ \n]+ ' + tag + r'\n)', r'\1\2\3\4')

# Delete every candidate whose king is attacked by a black piece.
for king in range(64):
    add(r'(?m)^!(?=.{'+str(king)+r'}K)(?='+attacks[king]+r')[^\n]*\n', '')

# Discard internal move tags and restore normal FEN fields.
add(r'(?m)^(!.{64} [KQkq]* [^ \n]+) [a-h][1-8][a-h][1-8]\n', r'\1\n')
add(r'(?m)^(!.{64})  ', r'\1 - ')
add(r'(?m)^!(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})(.{8}) ', r'\1/\2/\3/\4/\5/\6/\7/\8 b ')
for n in range(8, 0, -1):
    add(r'\.' * n, str(n))
add(r'(?m)^(.*)\n', r'\1 0 0\n')
add(r'\n\Z', '')

output = Path('/app/re.json')
output.write_text(json.dumps(rules, separators=(',', ':')))
print(f'{len(rules):,} pairs, {output.stat().st_size:,} bytes')
