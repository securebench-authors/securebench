import json, re, random, time
import chess

rules = [(re.compile(p), r) for p, r in json.load(open('/app/re.json'))]

def run(fen):
    for p, r in rules:
        fen = p.sub(r, fen)
    return fen.split('\n') if fen else []


def verify(board, label=''):
    assert board.turn == chess.WHITE
    got = run(board.fen(en_passant='fen'))
    expected = set()
    for m in board.legal_moves:
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        c = board.copy()
        c.push(m)
        # FEN specification includes an EP target after every double push.
        expected.add(' '.join(c.fen(en_passant='fen').split()[:4]))
    actual = [' '.join(f.split()[:4]) for f in got]
    if set(actual) != expected or len(actual) != len(expected):
        print('FAIL', label, board.fen())
        print('Missing:', expected - set(actual))
        print('Extra:', set(actual) - expected)
        raise AssertionError(label)


sample = 'rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1'
expected_sample = 'rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P1K3/q5b1 b kq - 0 0\nrnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P3K1/q5b1 b kq - 0 0\nrnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P4/P1P5/q2Q1Kb1 b kq - 0 0'
assert '\n'.join(run(sample)) == expected_sample
print('Exact example passed', flush=True)

edges = [
    # Both castles, attacked paths, and rook captures changing castling rights.
    'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/2b5/8/8/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/8/8/8/R2K3R w kq - 0 1',
    'r3k2r/8/8/8/8/8/1b6/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/8/8/2b5/R3K2R w KQkq - 0 1',
    # Promotion pushes, captures, and checks.
    '1r2k2r/P5P1/8/8/8/8/8/4K3 w kq - 0 1',
    '1r2k2r/P5P1/8/8/8/8/8/4K2r w kq - 0 1',
    # EP: legal, horizontal and vertical discovered checks, check evasion.
    '4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
    '4k3/8/8/r4pPK/8/8/8/8 w - f6 0 1',
    'k3r3/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
    '4k3/8/8/3pP3/4K3/8/8/8 w - d6 0 1',
    '4k3/8/8/3PpP2/8/8/8/4K3 w - e6 0 1',
    # Double check, knight/pawn/king attacks, pins, sparse edge positions.
    '4r1k1/8/8/8/1b6/8/8/4K3 w - - 0 1',
    '4k3/8/8/8/8/8/2n3p1/4K3 w - - 0 1',
    '8/8/8/8/8/3k4/8/4K3 w - - 0 1',
    '4k3/8/8/8/8/8/4R3/4K2r w - - 0 1',
    # Mate/stalemate represented as empty text by the regex stage.
    '8/8/8/8/8/5k2/6q1/7K w - - 0 1',
    '8/8/8/8/8/6q1/5k2/7K w - - 0 1',
]
for i, fen in enumerate(edges):
    verify(chess.Board(fen), f'edge {i}')
print(f'{len(edges)} edge positions passed', flush=True)

rng = random.Random(82734)
start = time.time()
count = 0
for game in range(15):
    board = chess.Board()
    for ply in range(180):
        if board.turn == chess.WHITE:
            verify(board, f'game {game}, ply {ply}')
            count += 1
        moves = list(board.legal_moves)
        if not moves:
            break
        # Bias toward unusual positions, captures, promotions, and castles.
        weighted = [m for m in moves if board.is_capture(m) or board.is_castling(m) or m.promotion]
        board.push(rng.choice(weighted if weighted and rng.random() < .4 else moves))
    print(f'Game {game+1}: {count} positions passed ({time.time()-start:.1f}s)', flush=True)
print('All passed', flush=True)
