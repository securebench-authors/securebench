"""Build a regex-only orthodox chess move generator (White to move).

Working records contain an expanded 64-character board in FEN order.
S/T: original position, safe/in check; C: candidate; E: EP probe.
Metadata: castling rights | en-passant code | move kind.
Only re.json is needed to run the resulting generator.
"""
import json
from pathlib import Path

rules = []
def emit(pattern, replacement):
    rules.append([pattern, replacement])

def ref(n):
    return rf'\g<{n}>'

def span_pattern(start, end, constraints):
    out = ''
    run = 0
    for i in range(start, end):
        if i in constraints:
            if run:
                out += f'.{{{run}}}' if run != 1 else '.'
                run = 0
            out += constraints[i]
        else:
            run += 1
    if run:
        out += f'.{{{run}}}' if run != 1 else '.'
    return out

def board_assert(constraints):
    last = max(constraints)
    return '(?=' + span_pattern(0, last + 1, constraints) + ')'

def attacks(king, enemy='black'):
    """Board-prefix lookaheads for attacks on a given square."""
    r, c = divmod(king, 8)
    black = enemy == 'black'
    pawn, knight, bishop, rook, queen, eking = ('pnbrqk' if black else 'PNBRQK')
    # A black pawn one rank above the target attacks downwards.
    for dc in (-1, 1):
        rr, cc = r + (-1 if black else 1), c + dc
        if 0 <= rr < 8 and 0 <= cc < 8:
            yield board_assert({rr * 8 + cc: pawn})
    for dr, dc in ((-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)):
        rr, cc = r + dr, c + dc
        if 0 <= rr < 8 and 0 <= cc < 8:
            yield board_assert({rr * 8 + cc: knight})
    for dr, dc in ((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)):
        rr, cc = r + dr, c + dc
        if 0 <= rr < 8 and 0 <= cc < 8:
            yield board_assert({rr * 8 + cc: eking})
        path = {}
        while 0 <= rr < 8 and 0 <= cc < 8:
            sq = rr * 8 + cc
            yield board_assert({**path, sq: '[' + (rook if dr == 0 or dc == 0 else bishop) + queen + ']'})
            path[sq] = r'\.'
            rr += dr
            cc += dc

def check_rules(prefix, replacement, king_piece='K', enemy='black'):
    for king in range(64):
        attacked = '|'.join(attacks(king, enemy))
        emit(r'(?m)^' + prefix + board_assert({king: king_piece}) + '(?:' + attacked + r')[^\n]*\n', replacement)

# Strip counters and encode the original EP file (a-h means rank 6).
emit(r'\A([^ ]+) w ([KQkq-]+) ([a-h][36]|-) \d+ \d+\s*\Z', r'S\1|\2|\3|n\n')
emit(r'\|([a-h])[36]\|n', r'|\1|n')
emit('/', '')
for n in range(1, 9):
    emit(str(n), '.' * n)
# Mark a source position whose king is already attacked, disabling castling.
for king in range(64):
    attacked = '|'.join(attacks(king))
    emit(r'(?m)^S' + board_assert({king: 'K'}) + '(?:' + attacked + ')', 'T')


def move(changes, constraints, *, piece_capture=None, source='[ST]', ep='-', kind='n', extra=''):
    """Copy the source record, changing selected cells in the candidate copy."""
    pattern = r'(?m)^' + source + extra
    replacement = 'C'
    cursor = 0
    group = 0
    piece_group = None
    # Piece capture, if used, must precede a destination using it in replacement,
    # but replacement references can refer forward to any capture group.
    pieces = []
    for sq in sorted(changes):
        if sq > cursor:
            group += 1
            pattern += '(' + span_pattern(cursor, sq, constraints) + ')'
            pieces.append(ref(group))
        if piece_capture == sq:
            group += 1
            pattern += '(' + constraints[sq] + ')'
            piece_group = group
        else:
            pattern += constraints[sq]
        pieces.append(changes[sq])
        cursor = sq + 1
    if cursor < 64:
        group += 1
        pattern += '(' + span_pattern(cursor, 64, constraints) + ')'
        pieces.append(ref(group))
    group += 1
    rights_group = group
    pattern += r'\|([KQkq-]+)\|[a-h-]\|n\n'
    replacement += ''.join(ref(piece_group) if p == '@' else p for p in pieces)
    replacement += '|' + ref(rights_group) + '|' + ep + '|' + kind + '\n'
    emit(pattern, ref(0) + replacement)

# Sliding pieces; constraints include every intervening empty square.
for src in range(64):
    r, c = divmod(src, 8)
    for dr, dc in ((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)):
        path = {}
        rr, cc = r + dr, c + dc
        piece = '[RQ]' if dr == 0 or dc == 0 else '[BQ]'
        while 0 <= rr < 8 and 0 <= cc < 8:
            dst = rr * 8 + cc
            move({src: '.', dst: '@'}, {src: piece, dst: '[.pnbrq]', **path}, piece_capture=src)
            path[dst] = r'\.'
            rr += dr
            cc += dc
# Knights and kings.
for piece, steps in (
    ('N', ((-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1))),
    ('K', ((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1))),
):
    for src in range(64):
        r, c = divmod(src, 8)
        for dr, dc in (reversed(steps) if piece == 'K' else steps):
            rr, cc = r + dr, c + dc
            if 0 <= rr < 8 and 0 <= cc < 8:
                dst = rr * 8 + cc
                move({src: '.', dst: piece}, {src: piece, dst: '[.pnbrq]'})
# Pawns, including queen promotions and EP captures.
for r in range(1, 7):
    for c in range(8):
        src = r * 8 + c
        dst = src - 8
        promoted = 'Q' if r == 1 else 'P'
        move({src: '.', dst: promoted}, {src: 'P', dst: r'\.'})
        if r == 6:
            move({src: '.', src - 16: 'P'}, {src: 'P', src - 8: r'\.', src - 16: r'\.'}, ep=chr(ord('A') + c))
        for dc in (-1, 1):
            if 0 <= c + dc < 8:
                dst = src - 8 + dc
                move({src: '.', dst: promoted}, {src: 'P', dst: '[pnbrq]'})
                if r == 3:
                    victim = src + dc
                    ep_file = chr(ord('a') + c + dc)
                    move({src: '.', dst: 'P', victim: '.'}, {src: 'P', dst: r'\.', victim: 'p'}, extra=r'(?=.{64}\|[^|]+\|' + ep_file + r'\|)')
# Castling: first place the king on the crossing square, retaining the rook.
move({60: '.', 61: 'K'}, {60:'K',61:r'\.',62:r'\.',63:'R'}, source='S', kind='h', extra=r'(?=.{64}\|[^|]*K)')
move({60: '.', 59: 'K'}, {56:'R',57:r'\.',58:r'\.',59:r'\.',60:'K'}, source='S', kind='a', extra=r'(?=.{64}\|[^|]*Q)')
# Source no longer needed. Check all candidate resulting king positions.
emit(r'(?m)^[ST][^\n]*\n', '')
check_rules('C', '')
# Complete castling after the crossing square has been checked.
emit(r'(?m)^C(.{60})\.K\.R(\|[^\n]*\|)h\n', r'C\1.RK.\2n\n')
emit(r'(?m)^C(.{56})R\.\.K\.(.{3})(\|[^\n]*\|)a\n', r'C\1..KR.\2\3n\n')
# Only the king's destination can introduce an attack after castling.
for king in (58,62):
    attacked = '|'.join(attacks(king))
    emit(r'(?m)^C' + board_assert({king: 'K'}) + '(?:' + attacked + r')[^\n]*\n', '')

# Remove rights when a king/rook has moved or a corner rook was captured.
for right, constraints in (
    ('K', {60:'K',63:'R'}), ('Q',{60:'K',56:'R'}),
    ('k',{4:'k',7:'r'}), ('q',{4:'k',0:'r'}),
):
    emit(r'(?m)^(C)(?!' + span_pattern(0,max(constraints)+1,constraints) + r')(.{64}\|[KQkq-]*)' + right, r'\1\2')
emit(r'\|\|', '|-|')

# Rebuild board ranks. Convert EP file codes to conventional square names.
for file in 'abcdefgh':
    emit(r'\|' + file.upper() + r'\|n', '|' + file + '3|n')
# Insert rank separators before compressing empty-square runs.
emit(r'(?m)^C(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})\|([^|]+)\|([^|]+)\|n\n',
     r'\1/\2/\3/\4/\5/\6/\7/\8 b \9 \g<10> 0 0\n')
for n in range(8,0,-1):
    emit(r'\.' * n, str(n))
emit(r'\n\Z', '')

out = Path('/app/re.json')
out.write_text(json.dumps(rules, separators=(',', ':')) + '\n')
print(f'{len(rules)} rules, {out.stat().st_size:,} bytes')
