"""Cross-check generated regex rules against python-chess."""
import json
import random
import re
import time
import chess

RULES = [(re.compile(p), r) for p, r in json.load(open('/app/re.json'))]

def run(fen):
    for p, r in RULES:
        fen = p.sub(r, fen)
    return fen.split('\n') if fen else []

def normalized(fen):
    return ' '.join(fen.split()[:4])

def verify(board):
    expected = set()
    for m in board.legal_moves:
        if m.promotion not in (None, chess.QUEEN):
            continue
        nxt = board.copy()
        nxt.push(m)
        # FEN's original specification always includes the EP target after a
        # double pawn push, regardless of whether an EP capture is available.
        expected.add(normalized(nxt.fen(en_passant='fen')))
    output = run(board.fen(en_passant='fen'))
    actual = [normalized(f) for f in output]
    if set(actual) != expected or len(actual) != len(expected):
        raise AssertionError((board.fen(), 'extra', set(actual) - expected, 'missing', expected - set(actual)))

special = [
    'rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1',
    'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
    '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1',
    'r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1',
    'rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8',
    'r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10',
    'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1',
    # Castling from/through/into check on both sides.
    '4k3/8/8/8/8/8/4r3/R3K2R w KQ - 0 1',
    '4kr2/8/8/8/8/8/8/R3K2R w KQ - 0 1',
    '4k1r1/8/8/8/8/8/8/R3K2R w KQ - 0 1',
    '3rk3/8/8/8/8/8/8/R3K2R w KQ - 0 1',
    '2r1k3/8/8/8/8/8/8/R3K2R w KQ - 0 1',
    # EP: ordinary, horizontal/vertical pins, discovered check, check evasion.
    '4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
    '4k3/8/8/r4pPK/8/8/8/8 w - f6 0 1',
    'k3r3/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
    '8/8/8/k2pP2R/8/8/8/4K3 w - d6 0 1',
    '4k3/8/8/3pP3/4K3/8/8/8 w - d6 0 1',
    # Promotions, rook captures removing rights, double check, and stalemate.
    '1r2k2r/P5P1/8/8/8/8/8/4K3 w kq - 0 1',
    '4k3/8/8/8/1b6/8/4r3/4K3 w - - 0 1',
    '8/8/8/8/8/2q5/2k5/K7 w - - 0 1',
]
start = time.monotonic()
for fen in special:
    verify(chess.Board(fen))
print(f'{len(special)} special positions passed', flush=True)
print('Example output:\n' + '\n'.join(run(special[0])), flush=True)

rng = random.Random(742857)
count = 0
for game in range(15):
    board = chess.Board()
    for ply in range(160):
        if board.turn == chess.WHITE:
            verify(board)
            count += 1
        moves = list(board.legal_moves)
        if not moves:
            break
        board.push(rng.choice(moves))
    if game % 5 == 4:
        print(f'{count} random-game positions passed', flush=True)

# Random valid composed positions exercise unusual checks, pins and promotions.
composed = 0
for attempt in range(20000):
    board = chess.Board(None)
    board.turn = chess.WHITE
    squares = rng.sample(range(64), rng.randint(3, 25))
    board.set_piece_at(squares.pop(), chess.Piece(chess.KING, chess.WHITE))
    board.set_piece_at(squares.pop(), chess.Piece(chess.KING, chess.BLACK))
    for sq in squares:
        pt = rng.choice([chess.PAWN]*3 + [chess.KNIGHT,chess.BISHOP,chess.ROOK,chess.QUEEN])
        if pt == chess.PAWN and chess.square_rank(sq) in (0,7):
            continue
        board.set_piece_at(sq, chess.Piece(pt, rng.choice([True,False])))
    if not board.is_valid():
        continue
    verify(board)
    composed += 1
    if composed == 500:
        break
print(f'Passed {count + composed + len(special)} positions in {time.monotonic()-start:.1f}s', flush=True)
