#!/usr/bin/env python3
"""PyStan 3.10.0 translation of gp_rstan.R; run with python3 pystan_analysis.py.

The likelihood, priors, design matrices, and predictive calculations match the
R source. Large covariance intermediates are local variables rather than saved
transformed parameters. Stan's built-in ARD squared-exponential kernel evaluates
the same covariance with more efficient derivatives.

Matching seeds and sampler settings does not guarantee identical individual
draws across RStan and PyStan/Stan versions.
"""

import csv
import json
import os
from pathlib import Path

# Each of the four Stan chains runs in its own process.
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np
import stan


STAN_CODE = r"""
functions {
  matrix cov_ard_sqexp(matrix X, vector rho, real alpha, real jitter) {
    int N = rows(X);
    int D = cols(X);
    array[N] vector[D] x;
    matrix[N, N] K;
    for (i in 1:N) x[i] = X[i]';
    // K[i,j] = alpha^2 * exp(-0.5 * sum_d(((X[i,d]-X[j,d])/rho[d])^2)).
    K = gp_exp_quad_cov(x, alpha, to_array_1d(rho));
    for (i in 1:N) K[i, i] += jitter;
    return K;
  }

  matrix cross_cov_ard(matrix X, matrix X_new, vector rho, real alpha) {
    int N = rows(X);
    int M = rows(X_new);
    int D = cols(X);
    matrix[N, M] Kx;
    for (i in 1:N) {
      for (j in 1:M) {
        real s = 0;
        for (d in 1:D) {
          real t = (X[i, d] - X_new[j, d]) / rho[d];
          s += t * t;
        }
        Kx[i, j] = square(alpha) * exp(-0.5 * s);
      }
    }
    return Kx;
  }
}

data {
  int<lower=1> N;
  int<lower=1> D;
  matrix[N, D] X;
  int<lower=1> P;
  matrix[N, P] H;
  vector[N] y;
  real<lower=0> jitter;
  int<lower=0> N_new;
  matrix[N_new, D] X_new;
  matrix[N_new, P] H_new;
}

parameters {
  vector[P] beta;
  real<lower=0> alpha;
  vector<lower=0>[D] rho;
  real<lower=0> sigma;
}

model {
  vector[N] mu = H * beta;
  matrix[N, N] K = cov_ard_sqexp(X, rho, alpha, jitter)
                   + diag_matrix(rep_vector(square(sigma), N));
  matrix[N, N] L_K = cholesky_decompose(K);
  beta ~ normal(0, 1);
  alpha ~ normal(0, 1.5);
  rho ~ lognormal(0, 1);
  sigma ~ normal(0, 0.5);
  y ~ multi_normal_cholesky(mu, L_K);
}

generated quantities {
  vector[N_new] y_new;
  if (N_new > 0) {
    matrix[N, N] K = cov_ard_sqexp(X, rho, alpha, jitter)
                     + diag_matrix(rep_vector(square(sigma), N));
    matrix[N, N] L_K = cholesky_decompose(K);
    matrix[N, N_new] K_x_xnew = cross_cov_ard(X, X_new, rho, alpha);
    matrix[N_new, N_new] K_new = cov_ard_sqexp(X_new, rho, alpha, jitter);
    vector[N] resid = y - (H * beta);
    vector[N] alpha_vec = mdivide_left_tri_low(L_K, resid);
    // Preserve the source's triangular solve, including the transposed input.
    alpha_vec = mdivide_left_tri_low(L_K', alpha_vec);
    {
      vector[N_new] f_mean = (K_x_xnew' * alpha_vec);
      matrix[N, N_new] v = mdivide_left_tri_low(L_K, K_x_xnew);
      vector[N_new] f_var = to_vector(diagonal(K_new))
                           - to_vector(columns_dot_self(v));
      for (m in 1:N_new) {
        real m_mean = (H_new[m] * beta) + f_mean[m];
        real m_sd = sqrt(f_var[m] + square(sigma));
        y_new[m] = normal_rng(m_mean, m_sd);
      }
    }
  }
}
"""

# RStan iter=2000 includes warmup; PyStan num_samples excludes warmup.
# RStan control names map to the Stan services argument names below.
SAMPLING_SETTINGS = {
    "num_chains": 4,
    "num_warmup": 1000,
    "num_samples": 1000,
    "num_thin": 2,
    "delta": 0.93,             # adapt_delta
    "max_depth": 14,           # max_treedepth
    "gamma": 0.05,             # adapt_gamma
    "kappa": 0.75,             # adapt_kappa
    "t0": 10.0,                # adapt_t0
    "init_buffer": 100,        # adapt_init_buffer
    "term_buffer": 50,         # adapt_term_buffer
    "window": 25,              # adapt_window
    "init_radius": 0.1,        # init_r: uniform(-0.1, 0.1) unconstrained
    "save_warmup": False,
    "refresh": 200,
}


def load_data(directory):
    """Use the original columns and H = [1, x1, x2], without scaling."""
    with (directory / "meta_public.json").open() as handle:
        meta = json.load(handle)
    x = np.loadtxt(directory / "train_X.csv", delimiter=",", skiprows=1, ndmin=2)
    x_new = np.loadtxt(directory / "test_X.csv", delimiter=",", skiprows=1, ndmin=2)
    with (directory / "train_y.csv").open(newline="") as handle:
        y = np.array([float(row["y"]) for row in csv.DictReader(handle)])
    n, d = x.shape
    p = int(meta["P"])
    if x_new.size == 0:
        x_new = np.empty((0, d))
    if len(y) != n or x_new.shape[1] != d or p != 3:
        raise ValueError("Data dimensions do not match the R design matrices.")
    h = np.column_stack((np.ones(n), x[:, :2]))
    h_new = np.column_stack((np.ones(len(x_new)), x_new[:, :2]))
    # meta['seed'] is unused by the R script; its sampling seed is explicitly 1.
    return {
        "N": n, "D": d, "X": x.tolist(),
        "P": p, "H": h.tolist(), "y": y.tolist(),
        "jitter": float(meta["jitter"]),
        "N_new": len(x_new), "X_new": x_new.tolist(), "H_new": h_new.tolist(),
    }


def main():
    if stan.__version__ != "3.10.0":
        raise RuntimeError(f"PyStan 3.10.0 is required, found {stan.__version__}")
    directory = Path(__file__).resolve().parent
    data = load_data(directory)
    print(f"PyStan {stan.__version__}; N={data['N']}, D={data['D']}, P={data['P']}",
          flush=True)
    posterior = stan.build(STAN_CODE, data=data, random_seed=1)
    fit = posterior.sample(**SAMPLING_SETTINGS)

    # Fit arrays have shape (parameter dimension, draws across all chains).
    samples = {name: np.asarray(fit[name]) for name in ("alpha", "sigma", "rho", "beta")}
    expected_draws = 4 * (1000 // 2)
    for name, draws in samples.items():
        if draws.shape[-1] != expected_draws or not np.isfinite(draws).all():
            raise RuntimeError(f"Invalid posterior samples for {name}: {draws.shape}")
    means = {name: draws.mean(axis=-1).reshape(-1) for name, draws in samples.items()}
    for name, values in means.items():
        np.savetxt(directory / f"{name}_est.csv", values, delimiter=",", fmt="%.17g")
        print(f"{name}: {values}", flush=True)

    # Retain parameter draws and sampler diagnostics for inspection.
    diagnostic_names = ("divergent__", "treedepth__", "n_leapfrog__", "accept_stat__")
    diagnostics = {name: np.asarray(fit[name]) for name in diagnostic_names}
    np.savez_compressed(directory / "posterior_samples.npz", **samples, **diagnostics)
    summary = {
        "pystan_version": stan.__version__,
        "random_seed": 1,
        "sampling_settings": SAMPLING_SETTINGS,
        "retained_draws_per_chain": 500,
        "retained_draws_total": expected_draws,
        "divergences": int(diagnostics["divergent__"].sum()),
        "max_treedepth_hits": int((diagnostics["treedepth__"] >= 14).sum()),
        "posterior_means": {name: values.tolist() for name, values in means.items()},
    }
    (directory / "sampling_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"Saved posterior means; {summary['divergences']} divergences, "
          f"{summary['max_treedepth_hits']} maximum tree-depth hits.", flush=True)


if __name__ == "__main__":
    main()
