;; A metacircular evaluator for interp.py.  An environment is a mutable
;; (binding-tree . parent) pair; each binding is a (name . value) pair.
;; Tree nodes are (binding left . right), ordered by symbol name.
;; Procedures, including primitive adapters, accept one list of arguments.
;; Definitions and primitive registrations use median-first name order to
;; keep lookup trees shallow when this evaluator interprets itself.

(define (mc-insert name value tree)
  (if (null? tree)
      (cons (cons name value) (cons '() '()))
      (begin
        (cond ((eq? name (car (car tree)))
               (set-cdr! (car tree) value))
              ((< name (car (car tree)))
               (set-car! (cdr tree)
                         (mc-insert name value (car (cdr tree)))))
              (else
               (set-cdr! (cdr tree)
                         (mc-insert name value (cdr (cdr tree))))))
        tree)))

(define (mc-cond clauses env)
  (if (null? clauses)
      '()
      (let ((clause (car clauses)))
        (if (if (eq? (car clause) 'else)
                #t
                (mc-eval (car clause) env))
            (mc-sequence (cdr clause) env)
            (mc-cond (cdr clauses) env)))))

;; No host apply is available.  These adapters bridge the host's fixed
;; calling convention and the evaluator's argument-list convention.
(define (mc-binary proc)
  (lambda (args) (proc (car args) (car (cdr args)))))

(define (mc-any args)
  (if (null? args)
      #f
      (if (mc-python-true (car args)) #t (mc-any (cdr args)))))

(define (mc-all args)
  (if (null? args)
      #t
      (if (mc-python-true (car args)) (mc-all (cdr args)) #f)))

(define (mc-arguments exprs env)
  (if (null? exprs)
      '()
      (cons (mc-eval (car exprs) env)
            (mc-arguments (cdr exprs) env))))

(define (mc-binding name env)
  (if (null? env)
      #f
      (let ((binding (mc-find name (car env))))
        (if binding binding (mc-binding name (cdr env))))))

(define (mc-bind params args bindings)
  (if (null? params)
      (if (null? args) bindings mc-too-many-arguments)
      (if (null? args)
          mc-too-few-arguments
          (mc-bind (cdr params) (cdr args)
                   (mc-insert (car params) (car args) bindings)))))

(define (mc-find name tree)
  (if (null? tree)
      #f
      (if (eq? name (car (car tree)))
          (car tree)
          (if (< name (car (car tree)))
              (mc-find name (car (cdr tree)))
              (mc-find name (cdr (cdr tree)))))))

(define (mc-eval expr env)
  (if (symbol? expr)
      (mc-get expr env)
      (if (pair? expr)
          (let ((op (car expr)) (rest (cdr expr)))
            (cond
              ((eq? op 'quote) (car rest))
              ((eq? op 'if)
               (if (mc-eval (car rest) env)
                   (mc-eval (car (cdr rest)) env)
                   (if (null? (cdr (cdr rest)))
                       '()
                       (mc-eval (car (cdr (cdr rest))) env))))
              ((eq? op 'define)
               (if (pair? (car rest))
                   (mc-define (car (car rest))
                              (mc-procedure (cdr (car rest)) (cdr rest) env)
                              env)
                   (mc-define (car rest)
                              (mc-eval (car (cdr rest)) env) env)))
              ((eq? op 'set!)
               (mc-set (car rest) (mc-eval (car (cdr rest)) env) env))
              ((eq? op 'lambda)
               (mc-procedure (car rest) (cdr rest) env))
              ((eq? op 'let)
               (mc-sequence (cdr rest)
                            (cons (mc-let-bindings (car rest) env '()) env)))
              ((eq? op 'begin) (mc-sequence rest env))
              ((eq? op 'progn) (mc-sequence rest env))
              ((eq? op 'cond) (mc-cond rest env))
              (else
               (let ((proc (mc-eval op env)))
                 (proc (mc-arguments rest env))))))
          expr)))

(define (mc-define name value env)
  (set-car! env (mc-insert name value (car env))))

(define (mc-global)
  (let ((env (cons '() '())))
    (mc-define 'fdisplay (mc-binary fdisplay) env)
    (mc-define 'and mc-all env)
    (mc-define '< (mc-binary <) env)
    (mc-define '- (lambda (args)
                    (if (null? (cdr args))
                        (- (car args))
                        (- (car args) (car (cdr args))))) env)
    (mc-define '+ mc-sum env)
    (mc-define '* mc-product env)
    (mc-define '/ (mc-binary /) env)
    (mc-define '> (mc-binary >) env)
    (mc-define '= (mc-binary =) env)
    (mc-define '<= (mc-binary <=) env)
    (mc-define '>= (mc-binary >=) env)
    (mc-define 'display (mc-unary display) env)
    (mc-define 'chr (mc-unary chr) env)
    (mc-define 'cdr (mc-unary cdr) env)
    (mc-define 'car (mc-unary car) env)
    (mc-define 'cons (mc-binary cons) env)
    (mc-define 'equal? (mc-binary equal?) env)
    (mc-define 'eq? (mc-binary eq?) env)
    (mc-define 'else #t env)
    (mc-define 'fclose (mc-unary fclose) env)
    (mc-define 'or mc-any env)
    (mc-define 'getchr (mc-nullary getchr) env)
    (mc-define 'fputchr (mc-binary fputchr) env)
    (mc-define 'fopen (mc-binary fopen) env)
    (mc-define 'fgetchr (mc-unary fgetchr) env)
    (mc-define 'fread (mc-unary fread) env)
    (mc-define 'null? (mc-unary null?) env)
    (mc-define 'not (mc-unary not) env)
    (mc-define 'newline (mc-nullary newline) env)
    (mc-define 'number? (mc-unary number?) env)
    (mc-define 'set-cdr! (mc-binary set-cdr!) env)
    (mc-define 'read (mc-nullary read) env)
    (mc-define 'putchr (mc-unary putchr) env)
    (mc-define 'pair? (mc-unary pair?) env)
    (mc-define 'set-car! (mc-binary set-car!) env)
    (mc-define 'symbol (mc-unary symbol) env)
    (mc-define 'string? (mc-unary string?) env)
    (mc-define 'symbol? (mc-unary symbol?) env)
    env))

(define (mc-get name env)
  (let ((binding (mc-binding name env)))
    (if binding
        (cdr binding)
        mc-undefined-variable)))

(define (mc-product args)
  (if (null? args)
      1
      (if (null? (cdr args))
          (car args)
          (* (car args) (mc-product (cdr args))))))

(define (mc-nullary proc)
  (lambda (args) (proc)))

(define (mc-load file env)
  (let ((expr (fread file)))
    (if (null? expr)
        (fclose file)
        (begin (mc-eval expr env) (mc-load file env)))))

(define (mc-let-bindings bindings env frame)
  (if (null? bindings)
      frame
      (let ((value (mc-eval (car (cdr (car bindings))) env)))
        (mc-let-bindings (cdr bindings) env
                         (mc-insert (car (car bindings)) value frame)))))

(define (mc-procedure params body env)
  (lambda (args)
    (mc-sequence body (cons (mc-bind params args '()) env))))

;; Read exactly the pathname line.  In particular, do not use read here:
;; a pathname is text, may contain spaces, and is not a Scheme expression.
(define (mc-path)
  (let ((ch (getchr)))
    (if (= ch 10)
        '()
        (cons ch (mc-path)))))

(define (mc-set name value env)
  (let ((binding (mc-binding name env)))
    (if binding
        (set-cdr! binding value)
        mc-undefined-variable)))

(define (mc-sequence body env)
  (if (null? body)
      '()
      (let ((value (mc-eval (car body) env)))
        (if (null? (cdr body))
            value
            (mc-sequence (cdr body) env)))))

;; interp.py implements and/or as eager Python all/any, whose notion of
;; truth differs from Scheme's if (zero and the empty list are false).
(define (mc-python-true value)
  (cond ((null? value) #f)
        ((number? value) (not (= value 0)))
        ((symbol? value) (not (eq? value (symbol '()))))
        (else #t)))

(define (mc-unary proc)
  (lambda (args) (proc (car args))))

(define (mc-sum args)
  (if (null? args) 0 (+ (car args) (mc-sum (cdr args)))))

(let ((file (fopen (symbol (mc-path)) "r")))
  (if file
      (mc-load file (mc-global))
      (begin (display "Error: cannot open input file") (newline))))
