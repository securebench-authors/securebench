;; A metacircular evaluator for interp.py.  Procedures are host closures taking
;; one argument list; environments are mutable frames linked to their parents.

(define (ev-frame parent) (cons '() parent))

;; A frame uses a binary search tree: ((name . value) . (left . right)).
;; The host's < primitive compares symbols as well as numbers.
(define (ev-find-frame name tree)
  (if (null? tree)
      #f
      (let ((binding (car tree)))
        (cond ((eq? name (car binding)) binding)
              ((< name (car binding))
               (ev-find-frame name (car (cdr tree))))
              (else (ev-find-frame name (cdr (cdr tree))))))))

(define (ev-find name env)
  (if (null? env)
      #f
      (let ((binding (ev-find-frame name (car env))))
        (if binding binding (ev-find name (cdr env))))))

(define (ev-insert name value tree)
  (if (null? tree)
      (cons (cons name value) (cons '() '()))
      (begin
        (cond ((eq? name (car (car tree))) (set-cdr! (car tree) value))
              ((< name (car (car tree)))
               (set-car! (cdr tree)
                         (ev-insert name value (car (cdr tree)))))
              (else
               (set-cdr! (cdr tree)
                         (ev-insert name value (cdr (cdr tree))))))
        tree)))

(define (ev-define name value env)
  (set-car! env (ev-insert name value (car env))))

(define (ev-bind names values env)
  (if (null? names)
      env
      (begin
        (ev-define (car names) (car values) env)
        (ev-bind (cdr names) (cdr values) env))))

(define (ev-sequence body env)
  (if (null? body)
      '()
      (let ((result (ev-eval (car body) env)))
        (if (null? (cdr body))
            result
            (ev-sequence (cdr body) env)))))

(define (ev-procedure params body env)
  (lambda (args)
    (ev-sequence body (ev-bind params args (ev-frame env)))))

(define (ev-arguments expressions env)
  (if (null? expressions)
      '()
      (let ((first (ev-eval (car expressions) env)))
        (cons first (ev-arguments (cdr expressions) env)))))

(define (ev-let bindings outer inner)
  (if (null? bindings)
      inner
      (begin
        (ev-define (car (car bindings))
                   (ev-eval (car (cdr (car bindings))) outer) inner)
        (ev-let (cdr bindings) outer inner))))

(define (ev-cond clauses env)
  (if (null? clauses)
      '()
      (let ((clause (car clauses)))
        (if (if (eq? (car clause) 'else)
                #t
                (ev-eval (car clause) env))
            (ev-sequence (cdr clause) env)
            (ev-cond (cdr clauses) env)))))

(define (ev-eval expr env)
  (cond
    ((symbol? expr) (cdr (ev-find expr env)))
    ((not (pair? expr)) expr)
    (else
      (let ((op (car expr)) (args (cdr expr)))
        (cond
          ((eq? op 'quote) (car args))
          ((eq? op 'if)
           (if (ev-eval (car args) env)
               (ev-eval (car (cdr args)) env)
               (if (null? (cdr (cdr args)))
                   '()
                   (ev-eval (car (cdr (cdr args))) env))))
          ((eq? op 'define)
           (let ((name (car args)))
             (if (pair? name)
                 (ev-define (car name)
                            (ev-procedure (cdr name) (cdr args) env) env)
                 (ev-define name (ev-eval (car (cdr args)) env) env))))
          ((eq? op 'set!)
           (set-cdr! (ev-find (car args) env)
                     (ev-eval (car (cdr args)) env)))
          ((eq? op 'lambda) (ev-procedure (car args) (cdr args) env))
          ((eq? op 'let)
           (ev-sequence (cdr args)
                        (ev-let (car args) env (ev-frame env))))
          ((or (eq? op 'begin) (eq? op 'progn))
           (ev-sequence args env))
          ((eq? op 'cond) (ev-cond args env))
          (else
            (let ((procedure (ev-eval op env)))
              (procedure (ev-arguments args env)))))))))

;; Lift fixed-arity native primitives without requiring an apply primitive.
(define (ev-zero f) (lambda (args) (f)))
(define (ev-one f) (lambda (args) (f (car args))))
(define (ev-two f) (lambda (args) (f (car args) (car (cdr args)))))

(define (ev-fold f value args)
  (if (null? args)
      value
      (ev-fold f (f value (car args)) (cdr args))))

(define (ev-global)
  (let ((env (ev-frame '())))
    (define (add name value) (ev-define name value env))
    (add '+ (lambda (args) (ev-fold + 0 args)))
    (add '* (lambda (args) (ev-fold * 1 args)))
    (add '- (lambda (args)
              (if (null? (cdr args))
                  (- (car args))
                  (- (car args) (car (cdr args))))))
    (add '/ (ev-two /))
    (add '= (ev-two =))
    (add '< (ev-two <))
    (add '> (ev-two >))
    (add '<= (ev-two <=))
    (add '>= (ev-two >=))
    (add 'cons (ev-two cons))
    (add 'car (ev-one car))
    (add 'cdr (ev-one cdr))
    (add 'null? (ev-one null?))
    (add 'pair? (ev-one pair?))
    (add 'eq? (ev-two eq?))
    (add 'equal? (ev-two equal?))
    (add 'not (ev-one not))
    (add 'and (lambda (args) (ev-fold and #t args)))
    (add 'or (lambda (args) (ev-fold or #f args)))
    (add 'getchr (ev-zero getchr))
    (add 'putchr (ev-one putchr))
    (add 'chr (ev-one chr))
    (add 'read (ev-zero read))
    (add 'symbol (ev-one symbol))
    (add 'symbol? (ev-one symbol?))
    (add 'string? (ev-one string?))
    (add 'number? (ev-one number?))
    (add 'set-car! (ev-two set-car!))
    (add 'set-cdr! (ev-two set-cdr!))
    (add 'else #t)
    (add 'display (ev-one display))
    (add 'newline (ev-zero newline))
    (add 'fopen (ev-two fopen))
    (add 'fclose (ev-one fclose))
    (add 'fgetchr (ev-one fgetchr))
    (add 'fputchr (ev-two fputchr))
    (add 'fdisplay (ev-two fdisplay))
    (add 'fread (ev-one fread))
    env))

;; interp.py has no tail-call optimization.  These doubling, balanced loops
;; keep the call stack logarithmic in the number of characters or forms.
(define (ev-repeat count step)
  (if (= count 1)
      (step)
      (if (ev-repeat (/ count 2) step)
          (ev-repeat (/ count 2) step)
          #f)))

(define (ev-loop-more count step)
  (if (ev-repeat count step)
      (ev-loop-more (* count 2) step)
      '()))

(define (ev-loop step) (ev-loop-more 1 step))

(define (ev-path)
  (let ((head (cons '() '())))
    (let ((tail head))
      (ev-loop
        (lambda ()
          (let ((ch (getchr)))
            (if (= ch 10)
                #f
                (begin
                  (set-cdr! tail (cons ch '()))
                  (set! tail (cdr tail))
                  #t)))))
      (symbol (cdr head)))))

;; fread reads a whole line and discards expressions after the first one.
;; Wrapping the complete source in a begin preserves all top-level forms,
;; including multiple forms per line and literal ().  A scratch file lets the
;; native reader construct strings, for which the language has no constructor.
;; Parsing and closing it before evaluation also permits self-interpretation.
(define (ev-digits n tail)
  (let ((digits (cons (+ 48 (- n (* 10 (/ n 10)))) tail)))
    (if (< n 10) digits (ev-digits (/ n 10) digits))))

(define (ev-scratch n)
  (let ((result #f) (index n))
    (ev-loop
      (lambda ()
        (let ((path (symbol
                      (cons 47 (cons 116 (cons 109 (cons 112 (cons 47
                        (cons 101 (cons 118 (cons 97 (cons 108 (cons 45
                          (ev-digits index '()))))))))))))))
          (let ((port (fopen path "x")))
            (if port
                (begin (set! result (cons path port)) #f)
                (begin (set! index (+ index 1)) #t))))))
    result))

(define (ev-source path)
  (let ((input (fopen path "r"))
        (scratch (ev-scratch 0)))
    (let ((output (cdr scratch)))
      (fdisplay output "(begin")
      (fputchr output 10)
      (ev-loop
        (lambda ()
          (let ((ch (fgetchr input)))
            (if (= ch -1)
                #f
                (begin (fputchr output ch) #t)))))
      (fputchr output 10)
      (fdisplay output ")")
      (fputchr output 10)
      (fclose input)
      (fclose output))
    (let ((source (fopen (car scratch) "r")))
      (let ((program (fread source)))
        (fclose source)
        ;; No unlink primitive is available; release the scratch file's data.
        (fclose (fopen (car scratch) "w"))
        program))))

(let ((path (ev-path)))
  (ev-eval (ev-source path) (ev-global)))
