#!/usr/bin/env python3
"""Find the hurdle jump in the supplied fixed-camera view.

Usage: python /app/jump_analyzer.py /path/to/video.mp4
Writes /app/output.toml. Frame numbers are zero-based. Takeoff is the
last frame of the ground-contact phase; landing is the first frame of
the next ground-contact phase. Only OpenCV and NumPy are required.

The hurdle's horizontal position is calibrated to the supplied scene.
Timing, running direction, speed, and ground height are measured anew
for each video; no event frame numbers are hard-coded.
"""

import sys

import cv2
import numpy as np


OUTPUT_PATH = "/app/output.toml"
HURDLE_X_FRACTION = 0.515


def _align(frame, reference_gray, corners):
    """Remove small camera vibrations using robust background feature matches."""
    if corners is None or len(corners) < 8:
        return frame
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    points, status, _ = cv2.calcOpticalFlowPyrLK(
        reference_gray, gray, corners, None,
        winSize=(21, 21), maxLevel=3,
    )
    if points is None or status is None:
        return frame
    valid = status.ravel().astype(bool) & np.isfinite(points).all(axis=(1, 2))
    if np.count_nonzero(valid) < 8:
        return frame
    transform, inliers = cv2.estimateAffinePartial2D(
        corners[valid], points[valid], method=cv2.RANSAC,
        ransacReprojThreshold=1.5,
    )
    if transform is None or inliers is None or np.count_nonzero(inliers) < 8:
        return frame
    # A stationary camera cannot plausibly acquire a large zoom or translation.
    scale = float(np.hypot(transform[0, 0], transform[0, 1]))
    height, width = gray.shape
    if not (0.97 < scale < 1.03) or np.linalg.norm(transform[:, 2]) > width * 0.05:
        return frame
    return cv2.warpAffine(
        frame, transform, (width, height),
        flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
        borderMode=cv2.BORDER_REPLICATE,
    )


def _observe(frame, background, close_kernel, open_kernel):
    """Return runner centroid x and bottom of silhouette, or None."""
    height, width = frame.shape[:2]
    blurred = cv2.GaussianBlur(frame, (5, 5), 0)
    # Compensate for modest automatic exposure changes using the empty track.
    offset = np.median(
        blurred[int(height * 0.81):].astype(np.float32)
        - background[int(height * 0.81):].astype(np.float32), axis=(0, 1),
    )
    corrected = np.clip(blurred.astype(np.float32) - offset, 0, 255).astype(np.uint8)
    difference = cv2.absdiff(corrected, background).max(axis=2)
    mask = np.uint8(difference > 22) * 255
    mask[:int(height * 0.045)] = 0
    mask[int(height * 0.805):] = 0
    # Closing joins limbs across places where clothes match the background.
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, open_kernel)
    count, labels, stats, centroids = cv2.connectedComponentsWithStats(mask)
    candidates = []
    for label in range(1, count):
        x, y, w, h, area = stats[label]
        if (area >= width * height * 0.0025 and h >= height * 0.19
                and w < width * 0.48 and y + h > height * 0.37):
            candidates.append(label)
    if not candidates:
        return None
    label = max(candidates, key=lambda item: stats[item, cv2.CC_STAT_AREA])
    x, y, w, h, _ = stats[label]
    # Reject partial edge silhouettes when deciding the jump timing.
    if x <= 1 or x + w >= width - 1:
        return None
    return float(centroids[label, 0]), float(y + h - 1)


def _event_frames(observations, width, height, fps):
    if len(observations) < 7:
        raise ValueError("Too few usable runner observations to identify a jump")
    observations = np.asarray(observations, dtype=np.float64)
    # Keep separate passes or isolated false detections out of the trajectory.
    breaks = np.flatnonzero(np.diff(observations[:, 0]) > max(3, fps * 0.15)) + 1
    tracks = np.split(observations, breaks)
    hurdle_x = width * HURDLE_X_FRACTION
    tracks = [track for track in tracks if len(track) >= 7
              and np.min(track[:, 1]) < hurdle_x - width * 0.08
              and np.max(track[:, 1]) > hurdle_x + width * 0.08]
    if not tracks:
        raise ValueError("No runner trajectory crossing the hurdle was found")
    track = max(tracks, key=lambda item: np.ptp(item[:, 1]))
    frames = np.arange(int(track[0, 0]), int(track[-1, 0]) + 1)
    x = np.interp(frames, track[:, 0], track[:, 1])
    bottom = np.interp(frames, track[:, 0], track[:, 2])
    # A three-frame median removes single-frame segmentation spikes without
    # blurring the transition between the flight and ground-contact phases.
    padded = np.pad(bottom, 1, mode="edge")
    smooth = np.median(np.stack([padded[:-2], padded[1:-1], padded[2:]]), axis=0)
    central = np.flatnonzero(np.abs(x - hurdle_x) < width * 0.20)
    if not len(central):
        raise ValueError("The runner was not visible near the hurdle")
    apex = int(central[np.argmin(smooth[central])])
    velocities = np.abs(np.diff(x))
    velocities = velocities[velocities > width * 0.001]
    speed = float(np.median(velocities)) if len(velocities) else width / fps
    # Search far enough either side to include a stance, but avoid unrelated
    # strides. This scales with the observed running speed and video frame rate.
    radius = int(np.clip(width * 0.55 / speed, max(4, fps * 0.2), max(8, fps * 1.2)))
    left = max(0, apex - radius)
    right = min(len(frames) - 1, apex + radius)
    if apex - left < 2 or right - apex < 2:
        raise ValueError("The jump is truncated before takeoff or after landing")
    # Estimate ground contact separately on both sides to allow for perspective
    # and a small change in the athlete's distance from the camera.
    ground_before = float(np.percentile(smooth[left:apex], 90))
    ground_after = float(np.percentile(smooth[apex + 1:right + 1], 90))
    clearance = min(ground_before, ground_after) - smooth[apex]
    if clearance < height * 0.045:
        raise ValueError("No clear airborne hurdle jump was detected")
    tolerance = max(3.0, height * 0.012)
    before = np.flatnonzero(smooth[left:apex] >= ground_before - tolerance) + left
    after = np.flatnonzero(smooth[apex + 1:right + 1] >= ground_after - tolerance) + apex + 1
    if not len(before) or not len(after):
        raise ValueError("Could not locate both ground-contact phases")
    takeoff, landing = int(frames[before[-1]]), int(frames[after[0]])
    if landing - takeoff < 2:
        raise ValueError("Detected flight is too short to be a hurdle jump")
    return takeoff, landing


def analyze_video(video_path):
    """Analyze one video and return exactly the two required TOML fields."""
    video = cv2.VideoCapture(str(video_path))
    try:
        if not video.isOpened():
            raise ValueError("Cannot open video: " + str(video_path))
        ok, first = video.read()
        if not ok:
            raise ValueError("Video contains no readable frames")
        height, width = first.shape[:2]
        fps = float(video.get(cv2.CAP_PROP_FPS))
        if not np.isfinite(fps) or fps <= 0:
            fps = 30.0
        gray = cv2.cvtColor(first, cv2.COLOR_BGR2GRAY)
        corners = cv2.goodFeaturesToTrack(gray, maxCorners=600, qualityLevel=0.02, minDistance=8)
        background = cv2.GaussianBlur(first, (5, 5), 0)
        kernel_size = max(5, int(round(width * 11 / 960)) | 1)
        close_kernel = np.ones((kernel_size, kernel_size), np.uint8)
        open_kernel = np.ones((3, 3), np.uint8)
        observations = []
        frame_number = 0
        while True:
            ok, frame = video.read()
            if not ok:
                break
            frame_number += 1
            aligned = _align(frame, gray, corners)
            observation = _observe(aligned, background, close_kernel, open_kernel)
            if observation is not None:
                observations.append((frame_number, *observation))
        takeoff, landing = _event_frames(observations, width, height, fps)
        return {
            "jump_takeoff_frame_number": takeoff,
            "jump_land_frame_number": landing,
        }
    finally:
        video.release()


def main():
    if len(sys.argv) != 2:
        print("Usage: python /app/jump_analyzer.py VIDEO.mp4", file=sys.stderr)
        return 2
    try:
        result = analyze_video(sys.argv[1])
        with open(OUTPUT_PATH, "w", encoding="utf-8") as output:
            # The schema contains only two integer scalars, so no TOML
            # serialization dependency or escaping is necessary.
            for key, value in result.items():
                output.write(f"{key} = {value}\n")
    except (ValueError, OSError, cv2.error) as error:
        print("Jump analysis failed: " + str(error), file=sys.stderr)
        return 1
    print("Saved " + OUTPUT_PATH)
    return 0


if __name__ == "__main__":
    sys.exit(main())
