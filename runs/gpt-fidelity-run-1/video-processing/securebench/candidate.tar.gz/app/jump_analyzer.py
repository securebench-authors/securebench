#!/usr/bin/env python3
"""Find the hurdle jump in a fixed-camera MP4.

Usage: python /app/jump_analyzer.py /path/to/video.mp4

Writes /app/output.toml. Frame numbers are zero based. Takeoff is the
last ground-contact frame of the push-off; landing is the first subsequent
ground-contact frame. Only OpenCV, NumPy, and Python's standard library are
required. Scene proportions are calibrated to example_video.mp4, but event
times, running direction, and the athlete's ground level are measured anew.
"""

import argparse
import sys

import cv2
import numpy as np


OUTPUT_PATH = "/app/output.toml"
HURDLE_X_FRACTION = 0.515


def _foreground_candidates(frame, background, transform, reference_gray):
    """Align subpixel camera drift, then isolate substantial moving objects."""
    height, width = frame.shape[:2]
    gray = cv2.cvtColor(frame[:reference_gray.shape[0]], cv2.COLOR_BGR2GRAY)
    try:
        _, estimate = cv2.findTransformECC(
            reference_gray, gray.astype(np.float32), transform.copy(),
            cv2.MOTION_TRANSLATION,
            (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 25, 0.001),
            None, 5,
        )
        # A runner occluding the reference must not produce a spurious warp.
        if np.max(np.abs(estimate[:, 2])) < 0.025 * width:
            transform = estimate
    except cv2.error:
        pass
    aligned = cv2.warpAffine(
        background, transform, (width, height), borderMode=cv2.BORDER_REPLICATE
    )
    blurred = cv2.GaussianBlur(frame, (3, 3), 0)
    difference = cv2.absdiff(blurred, aligned).max(axis=2)
    threshold = np.full((height, 1), 32, dtype=np.uint8)
    # Legs can have less contrast against the track than the upper body.
    threshold[int(0.445 * height):] = 20
    mask = (difference > threshold).astype(np.uint8) * 255
    mask[:int(0.03 * height)] = 0
    mask[int(0.80 * height):] = 0
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
    candidates = []
    for label in range(1, count):
        x, y, w, h, area = stats[label]
        if not (
            area >= 0.0018 * width * height
            and h >= 0.17 * height
            and w < 0.49 * width
            and y + h > 0.37 * height
            and y < 0.50 * height
        ):
            continue
        ys, xs = np.nonzero(labels[y:y+h, x:x+w] == label)
        # A percentile avoids single-pixel noise below the shoe. Background
        # shadows generally fail the contrast and component-height filters.
        candidates.append((
            float(x + np.median(xs)),
            float(y + np.median(ys)),
            float(y + np.percentile(ys, 99.8)),
            int(area),
        ))
    return candidates, transform


def _update_tracks(tracks, candidates, number, width, height, max_gap):
    """Associate components by position and a short velocity prediction."""
    matches = []
    for ti, track in enumerate(tracks):
        previous = track[-1]
        gap = number - previous[0]
        if gap > max_gap:
            continue
        velocity = 0.0
        if len(track) > 1:
            earlier = track[max(0, len(track) - 4)]
            velocity = (previous[1] - earlier[1]) / (previous[0] - earlier[0])
        predicted = previous[1] + gap * velocity
        for ci, candidate in enumerate(candidates):
            x, y, _, _ = candidate
            dx = abs(x - predicted)
            dy = abs(y - previous[2])
            if dx < width * (0.10 + 0.025 * gap) and dy < 0.28 * height:
                matches.append((dx / width + 0.2 * dy / height, ti, ci))
    used_tracks, used_candidates = set(), set()
    for _, ti, ci in sorted(matches):
        if ti not in used_tracks and ci not in used_candidates:
            tracks[ti].append((number,) + candidates[ci])
            used_tracks.add(ti)
            used_candidates.add(ci)
    for ci, candidate in enumerate(candidates):
        if ci not in used_candidates:
            tracks.append([(number,) + candidate])


def _jump_from_track(track, width, height, fps):
    samples = np.asarray(track, dtype=float)
    first, last = int(samples[0, 0]), int(samples[-1, 0])
    frames = np.arange(first, last + 1)
    centers = np.interp(frames, samples[:, 0], samples[:, 1])
    feet = np.interp(frames, samples[:, 0], samples[:, 3])
    observed = np.isin(frames, samples[:, 0].astype(int))

    # Estimate the ground from the upper envelope of foot coordinates (image
    # y increases downward). Fit its slight slope across the running lane.
    ground_points = feet >= np.percentile(feet, 75)
    for _ in range(3):
        if np.count_nonzero(ground_points) < 3:
            raise ValueError("Too few ground-contact observations")
        if np.ptp(centers[ground_points]) > 0.15 * width:
            coefficients = np.polyfit(
                centers[ground_points] / width, feet[ground_points], 1
            )
            coefficients[0] = np.clip(coefficients[0], -0.08 * height, 0.08 * height)
            coefficients[1] = np.median(
                feet[ground_points] - coefficients[0] * centers[ground_points] / width
            )
            ground = np.polyval(coefficients, centers / width)
        else:
            ground = np.full_like(feet, np.median(feet[ground_points]))
        ground_points = (np.abs(feet - ground) < 0.018 * height) & observed

    clearance = ground - feet
    smooth = np.asarray([
        np.median(clearance[max(0, i-1):min(len(feet), i+2)])
        for i in range(len(feet))
    ])
    near_hurdle = np.abs(centers / width - HURDLE_X_FRACTION) < 0.25
    if not np.any(near_hurdle):
        raise ValueError("The athlete does not pass the hurdle")
    apex = int(np.argmax(np.where(near_hurdle, smooth, -np.inf)))
    if smooth[apex] < 0.065 * height:
        raise ValueError("No clear hurdle flight detected")

    # Use unsmoothed measurements for the actual frame boundaries: smoothing
    # would shift a fast toe-off or touchdown by a frame.
    contact = (clearance <= 0.014 * height) & observed
    before = np.flatnonzero(contact & (frames < frames[apex]))
    after = np.flatnonzero(contact & (frames > frames[apex]))
    if not len(before) or not len(after):
        raise ValueError("The video must show both takeoff and landing")
    takeoff, landing = int(frames[before[-1]]), int(frames[after[0]])
    if landing - takeoff < max(3, int(0.08 * fps)):
        raise ValueError("Detected flight is too short for a hurdle jump")
    return takeoff, landing, float(smooth[apex])


def analyze(video_path):
    """Return (last takeoff-contact frame, first landing-contact frame)."""
    capture = cv2.VideoCapture(str(video_path))
    try:
        if not capture.isOpened():
            raise ValueError("Cannot open video: " + str(video_path))
        ok, background = capture.read()
        if not ok:
            raise ValueError("The video has no readable frames")
        height, width = background.shape[:2]
        fps = float(capture.get(cv2.CAP_PROP_FPS))
        if not np.isfinite(fps) or fps <= 0:
            fps = 30.0
        reference_gray = cv2.cvtColor(
            background[:int(0.445 * height)], cv2.COLOR_BGR2GRAY
        ).astype(np.float32)
        background = cv2.GaussianBlur(background, (3, 3), 0)
        transform = np.eye(2, 3, dtype=np.float32)
        tracks = []
        number = 0
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            number += 1
            candidates, transform = _foreground_candidates(
                frame, background, transform, reference_gray
            )
            _update_tracks(
                tracks, candidates, number, width, height,
                max(3, int(0.10 * fps)),
            )
    finally:
        capture.release()

    results = []
    for track in tracks:
        if len(track) < max(6, int(0.15 * fps)):
            continue
        xs = np.asarray([entry[1] for entry in track]) / width
        # Reject moving leaves, displaced hurdle pieces, and shadows. The
        # runner must traverse the central hurdle and a substantial distance.
        if not (xs.min() < HURDLE_X_FRACTION < xs.max() and np.ptp(xs) > 0.30):
            continue
        try:
            takeoff, landing, clearance = _jump_from_track(track, width, height, fps)
        except ValueError:
            continue
        results.append((clearance, takeoff, landing))
    if not results:
        raise ValueError("Could not detect a complete hurdle jump in this video")
    _, takeoff, landing = max(results)
    return takeoff, landing


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", help="Input MP4 video")
    arguments = parser.parse_args()
    try:
        takeoff, landing = analyze(arguments.video)
        # These two integer assignments are valid TOML; no serializer is needed.
        with open(OUTPUT_PATH, "w", encoding="utf-8") as output:
            output.write("jump_takeoff_frame_number = {}\n".format(takeoff))
            output.write("jump_land_frame_number = {}\n".format(landing))
    except (ValueError, OSError, cv2.error) as error:
        print("jump_analyzer: " + str(error), file=sys.stderr)
        return 1
    print("Wrote {} (takeoff {}, landing {}; zero-based frames)".format(
        OUTPUT_PATH, takeoff, landing
    ))
    return 0


if __name__ == "__main__":
    sys.exit(main())
