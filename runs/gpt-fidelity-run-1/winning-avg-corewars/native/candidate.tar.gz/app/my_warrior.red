;redcode-94
;name Sweeper
;author Codex
;strategy Process-fed forward DAT clear with an anti-imp bomb.
;assert CORESIZE == 8000 && MAXCYCLES == 80000

; Keep the pointer ahead of our code while the clear builds speed.
gate    dat.f   0,      40

; Predecrement the preceding arm of a 2667-step imp spiral.
bomb    dat.f   <2667,  20

; Continuously replenish the processes feeding the clear.
start   spl.b   #0,     0
clear   mov.i   bomb,   >gate
        mov.i   bomb,   >gate
        djn.f   clear,  >gate

        end start
