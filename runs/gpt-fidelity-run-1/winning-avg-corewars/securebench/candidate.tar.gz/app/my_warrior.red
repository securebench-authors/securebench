;redcode-94
;name Sentry
;author Codex
;strategy Process-resilient forward DAT clear with an anti-imp bomb.
;assert CORESIZE == 8000 && MAXCYCLES == 80000

; Keep the advancing pointer separate from the executing loop.
gate    dat.f   0,       100
        dat.f   0,       0

; Predecrement disrupts 2667-step imps. When this bomb overwrites
; gate, its B-field restarts the sweep beyond our own instructions.
bomb    dat.f   <2667,   10

; Replenish processes while the other processes sweep the core.
start   spl.b   #0,      0
clear   mov.i   bomb,    >gate
        djn.f   clear,   >gate

        end     start
