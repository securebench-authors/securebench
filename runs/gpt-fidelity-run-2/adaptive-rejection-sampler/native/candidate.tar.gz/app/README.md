# Adaptive rejection sampling in R

`ars.R` implements Gilks and Wild's (1992) adaptive rejection sampler using
base R. It exports `ars()` and the formal test runner `test()`.

```r
source("/app/ars.R")
set.seed(42)
normal <- ars(10000, dnorm)
exponential <- ars(10000, dexp, domain = c(0, Inf), rate = 2)
unnormalized <- ars(10000, expression(exp(-x^2 / 2)))
```

The first argument is the nonnegative integer sample count. The second is a
vectorized density function, `expression(...)`, or `quote(...)` in the variable
`x`. Named arguments in `...` are forwarded to the density or made available to
the expression. Expression evaluation also has access to the calling environment.
The returned value is a numeric vector of independent target draws, subject to
floating point accuracy and the target meeting the sampler's assumptions.

Supply the support using `domain = c(lower, upper)`, with infinite endpoints
where appropriate. The target must be positive inside this connected interval,
integrable, and log-concave. Choosing a smaller interval samples the corresponding
truncated distribution. Specify `initial` with at least two distinct interior
points when the defaults are unsuitable. On an infinite left side the leftmost
point needs a positive log derivative; on an infinite right side the rightmost
point needs a negative log derivative. Without `initial`, the sampler attempts
to find these tail slopes by geometric expansion.

To avoid density underflow, supply a log-density and set `log = TRUE`. Numerical
log derivatives are the default; an optional `derivative` function must calculate
the **log-density derivative**, with any parameters captured in its closure:

```r
draws <- ars(10000, function(x) dnorm(x, mean = 5, sd = 2, log = TRUE),
             log = TRUE, initial = c(2, 5, 8),
             derivative = function(x) -(x - 5) / 4)
```

The modules separately handle target evaluation, differentiation, concavity
checks, initialization, tangent intersections, log-space envelope integration,
inverse-CDF proposals, and chord squeezing. The sampler checks decreasing
log derivatives, chord slopes, and evaluated target values against both hulls.
Detected violations stop sampling with an error. These finite checks cannot
prove global log-concavity of an arbitrary function. `squeeze = FALSE` evaluates
the target at every proposal for more extensive checks. Analytic derivatives
are preferable for demanding numerical precision; numerical derivatives and
checks use floating point tolerances.

`max_points` limits hull storage, while checks continue for evaluated proposals.
Initialization includes midpoint checks, so this limit must accommodate both the
initial points and their midpoints. `max_iter` limits proposal attempts; exceeding
it raises an error instead of returning an incomplete sample. All arguments are
documented alongside `ars()` in `ars.R`.

Run the tests with:

```sh
Rscript -e 'source("/app/ars.R"); test()'
```

The 23 tests cover numerical modules, invalid inputs, non-integrable envelopes,
non-log-concavity both at initialization and during sampling, reproducibility,
and eight known target distributions or parameterizations. Every case prints
`TEST_NAME: PASS` or `TEST_NAME: FAIL`, followed by mean and standard deviation
(NA for checks that do not produce samples). Distribution tests print their known
moments and empirical-CDF discrepancies as well.

Each distribution test uses 10,000 draws by default. Acceptance requires the
sample mean and unbiased variance to be within six theoretical standard errors
of their known values, with the variance standard error calculated from the known
fourth central moment. An empirical-CDF test uses the Dvoretzky–Kiefer–Wolfowitz
bound at significance level 0.000001 per comparison. This tests distribution shape
as well as moments and keeps stochastic false failures rare. A fixed seed makes
runs reproducible, and the runner restores the caller's RNG state and RNG kinds.

`test()` returns an invisible data frame of results and raises an error on any
failure by default. It writes `normal_samples.txt` and `exponential_samples.txt`
to `/app`, one draw per line; `output_dir` can select another existing directory.

Reference: [Gilks, W. R. and Wild, P. (1992), Adaptive Rejection Sampling for
Gibbs Sampling, Applied Statistics 41(2), 337–348](https://doi.org/10.2307/2347565).
