# Adaptive rejection sampling for a univariate log-concave density.
# Gilks & Wild (1992), Applied Statistics 41(2), 337-348, section 2.2.
# https://doi.org/10.2307/2347565
# Base R only. Sourcing this file has no side effects; run test() explicitly.

.ars_stop <- function(...) stop(..., call. = FALSE)

.ars_integer <- function(value, name, minimum = 0) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < minimum || value != floor(value) || value > .Machine$integer.max)
    .ars_stop(name, " must be an integer between ", minimum,
              " and ", .Machine$integer.max, ".")
  as.integer(value)
}

# Wrap a vectorized function, expression(), or quote() in a checked log-density.
.ars_log_density <- function(density, log, args, envir) {
  if (!is.function(density) && !is.expression(density) && !is.language(density))
    .ars_stop("density must be a vectorized function or an expression in x.")
  if (is.expression(density) && length(density) != 1L)
    .ars_stop("density must contain exactly one expression.")
  force(density)
  function(x) {
    value <- tryCatch({
      if (is.function(density)) do.call(density, c(list(x), args)) else
        eval(density, envir = c(list(x = x), args), enclos = envir)
    }, error = function(e) .ars_stop("Density evaluation failed: ", conditionMessage(e)))
    if (!is.numeric(value) || length(value) != length(x) || any(!is.finite(value)))
      .ars_stop("Density must return one finite numeric value per x (vectorized). ",
                "Use log = TRUE for densities that underflow.")
    if (!log && any(value <= 0))
      .ars_stop("Density must be strictly positive inside domain; check domain ",
                "or use log = TRUE to avoid underflow.")
    if (log) as.numeric(value) else base::log(value)
  }
}

# Numerical log derivative: Richardson-extrapolated central differences. Never
# evaluate at/outside the declared boundaries. Analytic derivatives are preferred
# for extremely narrow, steep, or nonsmooth targets.
.ars_derivative <- function(h, derivative, domain) {
  if (!is.null(derivative)) {
    if (!is.function(derivative)) .ars_stop("derivative must be a function or NULL.")
    return(function(x) {
      d <- tryCatch(derivative(x), error = function(e)
        .ars_stop("Log-derivative evaluation failed: ", conditionMessage(e)))
      if (!is.numeric(d) || length(d) != length(x) || any(!is.finite(d)))
        .ars_stop("derivative must return one finite log-density derivative per x.")
      as.numeric(d)
    })
  }
  function(x) {
    step <- .Machine$double.eps^(1/3) * pmax(1, abs(x))
    step <- pmin(step, (x - domain[1L]) / 4, (domain[2L] - x) / 4)
    if (any(!is.finite(step) | step <= 0 | x + step == x | x - step == x))
      .ars_stop("Cannot calculate numerical log derivatives; supply derivative.")
    full <- (h(x + step) - h(x - step)) / (2 * step)
    half <- (h(x + step / 2) - h(x - step / 2)) / step
    d <- (4 * half - full) / 3
    if (any(!is.finite(d))) .ars_stop("Non-finite numerical log derivative.")
    d
  }
}

# For a concave h, h'(x_i) >= chord slope >= h'(x_{i+1}). This
# simultaneously checks decreasing derivatives and consistency with h itself.
.ars_check_concavity <- function(x, h, d, tolerance) {
  secant <- diff(h) / diff(x)
  slack <- tolerance * pmax(1, abs(secant), abs(head(d, -1L)), abs(tail(d, -1L)))
  if (any(head(d, -1L) + slack < tail(d, -1L)) ||
      any(secant > head(d, -1L) + slack) ||
      any(secant < tail(d, -1L) - slack))
    .ars_stop("Non-log-concave density detected: derivatives/chords violate concavity ",
              "(or the supplied log derivative is incorrect).")
  invisible(TRUE)
}

# Integral of exp(h + d*(t-x)) on [a,b], calculated entirely in log space.
.ars_log_mass <- function(a, b, x, h, d) {
  if (a == b) return(-Inf)
  if (d == 0) {
    if (!is.finite(a) || !is.finite(b))
      .ars_stop("Non-integrable envelope: a flat tail needs a finite boundary.")
    return(h + base::log(b - a))
  }
  if (d > 0) {
    if (!is.finite(b)) .ars_stop("Non-integrable envelope: right tail slope must be negative.")
    return(h + d * (b - x) + base::log(-expm1(-d * (b - a))) - base::log(d))
  }
  if (!is.finite(a)) .ars_stop("Non-integrable envelope: left tail slope must be positive.")
  h + d * (a - x) + base::log(-expm1(d * (b - a))) - base::log(-d)
}

.ars_hull <- function(x, h, d, domain, tolerance) {
  .ars_check_concavity(x, h, d, tolerance)
  k <- length(x)
  if ((!is.finite(domain[1L]) && d[1L] <= 0) ||
      (!is.finite(domain[2L]) && d[k] >= 0))
    .ars_stop("Non-integrable envelope: initial points must have a positive left ",
              "tail slope and a negative right tail slope on unbounded sides.")
  dx <- diff(x)
  delta <- head(d, -1L) - tail(d, -1L)
  parallel <- abs(delta) <= 1e-10 * pmax(1, abs(head(d, -1L)), abs(tail(d, -1L)))
  z <- head(x, -1L) + dx / 2
  j <- which(!parallel)
  z[j] <- x[j] + (h[j + 1L] - h[j] - d[j + 1L] * dx[j]) / delta[j]
  slack <- tolerance * pmax(1, abs(head(x, -1L)), abs(tail(x, -1L)))
  if (any(!is.finite(z)) || any(z < head(x, -1L) - slack) ||
      any(z > tail(x, -1L) + slack))
    .ars_stop("Non-log-concave density or unstable tangent intersections.")
  z <- c(domain[1L], pmax(head(x, -1L), pmin(tail(x, -1L), z)), domain[2L])
  mass <- vapply(seq_len(k), function(i)
    .ars_log_mass(z[i], z[i + 1L], x[i], h[i], d[i]), numeric(1))
  if (any(is.na(mass)) || any(mass == Inf) || all(mass == -Inf))
    .ars_stop("Numerically invalid envelope masses; rescale the target or domain.")
  weight <- exp(mass - max(mass))
  list(x = x, h = h, d = d, z = z, log_mass = mass, weight = weight / sum(weight))
}

# Inverse CDF of a single exponential piece, including flat and infinite pieces.
.ars_piece_quantile <- function(u, a, b, d) {
  if (d == 0) return(a + u * (b - a))
  if (d > 0) return(b + log1p((1 - u) * expm1(-d * (b - a))) / d)
  a + log1p(u * expm1(d * (b - a))) / d
}

.ars_propose <- function(hull) {
  j <- sample.int(length(hull$x), 1L, prob = hull$weight)
  x <- .ars_piece_quantile(runif(1L), hull$z[j], hull$z[j + 1L], hull$d[j])
  if (!is.finite(x)) .ars_stop("Non-finite envelope proposal; rescale the domain.")
  list(x = x, upper = hull$h[j] + hull$d[j] * (x - hull$x[j]))
}

.ars_lower <- function(x, hull) {
  k <- length(hull$x)
  if (x < hull$x[1L] || x > hull$x[k]) return(-Inf)
  j <- min(findInterval(x, hull$x), k - 1L)
  hull$h[j] + (x - hull$x[j]) * (hull$h[j + 1L] - hull$h[j]) /
    (hull$x[j + 1L] - hull$x[j])
}

.ars_initial <- function(initial, domain, h, dh, tolerance) {
  automatic <- is.null(initial)
  if (automatic) {
    initial <- if (all(is.finite(domain))) {
      domain[1L] + c(0.2, 0.5, 0.8) * diff(domain)
    } else if (is.finite(domain[1L])) {
      domain[1L] + c(0.5, 1, 2)
    } else if (is.finite(domain[2L])) {
      domain[2L] - c(2, 1, 0.5)
    } else c(-1, 0, 1)
  }
  if (!is.numeric(initial) || length(initial) < 2L || any(!is.finite(initial)) ||
      anyDuplicated(initial) || any(initial <= domain[1L] | initial >= domain[2L]))
    .ars_stop("initial must contain at least two distinct finite points strictly inside domain.")
  x <- sort(initial)
  # Geometric tail search is only automatic when the user omitted initial.
  if (automatic) {
    for (attempt in seq_len(50L)) {
      d <- dh(x)
      left <- !is.finite(domain[1L]) && d[1L] <= 0
      right <- !is.finite(domain[2L]) && tail(d, 1L) >= 0
      if (!left && !right) break
      width <- max(1, diff(range(x)))
      if (left) x <- c(x[1L] - 2 * width, x)
      if (right) x <- c(x, tail(x, 1L) + 2 * width)
      if (attempt == 50L) .ars_stop("Cannot bracket integrable tails; supply initial/domain.")
    }
  }
  # Audit midpoints as well, before any squeeze can accept a proposal.
  x <- sort(c(x, head(x, -1L) + diff(x) / 2))
  .ars_hull(x, h(x), dh(x), domain, tolerance)
}

#' Sample from a positive, integrable, log-concave density on one interval.
#'
#' n: nonnegative integer sample count; density: vectorized function or quoted
#' expression in x. ... supplies named arguments to density (or expression).
#' domain: increasing c(lower, upper), possibly infinite, containing exactly the
#' target support; finite endpoints need not have positive density.
#' initial: >=2 distinct interior points; for infinite sides their log slopes must
#' point inward. NULL chooses points and attempts geometric tail bracketing.
#' log: TRUE if density returns log density. derivative: optional vectorized
#' derivative OF THE LOG DENSITY, with target parameters captured in its closure.
#' tolerance: relative tolerance for numerical concavity checks.
#' max_points: cap on stored support points (checks continue after the cap).
#' max_iter: hard proposal limit; failure returns an error, never partial samples.
#' squeeze: use chord squeezing to avoid some density evaluations. FALSE evaluates
#' and checks the density at EVERY proposal, useful for additional auditing.
#'
#' Returns a plain numeric vector, using R's normal RNG / set.seed(). Numerical
#' derivatives approximate tangents; provide an analytic derivative for demanding
#' precision. Finite checks cannot prove global concavity of an arbitrary function:
#' the caller must supply a log-concave target; violations found are fatal.
#'
#' Examples:
#'   ars(1000, dnorm)
#'   ars(1000, dexp, domain = c(0, Inf), rate = 2)
#'   ars(1000, expression(exp(-x^2 / 2)))
#'   ars(1000, function(x) dnorm(x, log = TRUE), log = TRUE,
#'       derivative = function(x) -x)
ars <- function(n, density, initial = NULL, domain = c(-Inf, Inf),
                log = FALSE, derivative = NULL, ..., tolerance = 1e-7,
                max_points = 200L, max_iter = max(1000, min(.Machine$integer.max, 100 * n)),
                squeeze = TRUE) {
  n <- .ars_integer(n, "n")
  max_points <- .ars_integer(max_points, "max_points", 2)
  max_iter <- .ars_integer(max_iter, "max_iter", 1)
  if (!is.numeric(domain) || length(domain) != 2L || anyNA(domain) ||
      domain[1L] >= domain[2L])
    .ars_stop("domain must be two increasing numeric bounds, e.g. c(0, Inf).")
  if (!is.logical(log) || length(log) != 1L || is.na(log))
    .ars_stop("log must be TRUE or FALSE.")
  if (!is.logical(squeeze) || length(squeeze) != 1L || is.na(squeeze))
    .ars_stop("squeeze must be TRUE or FALSE.")
  if (!is.numeric(tolerance) || length(tolerance) != 1L || !is.finite(tolerance) ||
      tolerance <= 0 || tolerance > 1e-3)
    .ars_stop("tolerance must be positive and at most 0.001.")
  args <- list(...)
  if (length(args) && (is.null(names(args)) || anyNA(names(args)) ||
                       any(names(args) == "") || anyDuplicated(names(args)) ||
                       "x" %in% names(args)))
    .ars_stop("Extra density arguments must have unique names other than x.")
  h <- .ars_log_density(density, log, args, parent.frame())
  dh <- .ars_derivative(h, derivative, domain)
  hull <- .ars_initial(initial, domain, h, dh, tolerance)
  if (length(hull$x) > max_points)
    .ars_stop("max_points must accommodate initial points and their midpoint audit (",
              length(hull$x), ").")
  if (n == 0L) return(numeric(0))
  samples <- numeric(n)
  accepted <- 0L
  iterations <- 0
  while (accepted < n) {
    iterations <- iterations + 1
    if (iterations > max_iter)
      .ars_stop("max_iter exceeded after accepting ", accepted, " of ", n, " samples.")
    proposal <- .ars_propose(hull)
    x <- proposal$x
    upper <- proposal$upper
    lower <- .ars_lower(x, hull)
    log_u <- base::log(runif(1L))
    if (squeeze && log_u <= lower - upper) {
      accept <- TRUE
    } else {
      hx <- h(x)
      slack <- tolerance * max(1, abs(hx), abs(upper))
      if (hx > upper + slack || (is.finite(lower) && hx < lower - slack))
        .ars_stop("Non-log-concave density detected during sampling: target violates hull bounds ",
                  "(or numerical/supplied derivatives are inaccurate).")
      # Check a new point even when the storage cap prevents adaptation.
      distance <- min(abs(hull$x - x))
      if (distance > .Machine$double.eps^(2/3) * max(1, abs(x))) {
        xx <- c(hull$x, x)
        hh <- c(hull$h, hx)
        dd <- c(hull$d, dh(x))
        order_x <- order(xx)
        .ars_check_concavity(xx[order_x], hh[order_x], dd[order_x], tolerance)
        if (length(hull$x) < max_points)
          hull <- .ars_hull(xx[order_x], hh[order_x], dd[order_x], domain, tolerance)
      }
      # Use the PRE-UPDATE envelope and the SAME uniform for rejection.
      accept <- log_u <= hx - upper
    }
    if (accept) {
      accepted <- accepted + 1L
      samples[accepted] <- x
    }
  }
  samples
}

# Formal tests: deterministic unit/error checks plus seeded distribution checks.
# Each case prints NAME: PASS/FAIL and mean/sd (NA for non-sampling cases).
# Distribution acceptance uses a six-standard-error mean bound, variance bounds
# using the known fourth central moment, and a DKW bound on empirical-CDF error.
# At alpha=1e-6 per CDF comparison, random false failures are deliberately rare.
# RNG state/kind are restored on exit. Return a data frame with details invisibly;
# any failure is fatal by default so CI/Rscript receives a nonzero exit status.
test <- function(n = 10000L, seed = 1992L, output_dir = "/app", stop_on_failure = TRUE) {
  n <- .ars_integer(n, "test n", 2000)
  seed <- .ars_integer(seed, "seed")
  if (!is.logical(stop_on_failure) || length(stop_on_failure) != 1L || is.na(stop_on_failure))
    .ars_stop("stop_on_failure must be TRUE or FALSE.")
  if (!is.character(output_dir) || length(output_dir) != 1L || is.na(output_dir) ||
      !dir.exists(output_dir)) .ars_stop("output_dir must be an existing directory.")
  had_rng <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_rng) old_rng <- get(".Random.seed", envir = .GlobalEnv)
  old_kind <- RNGkind()
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_rng) assign(".Random.seed", old_rng, envir = .GlobalEnv) else
      if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
        rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(seed)
  rows <- list()
  record <- function(name, code) {
    stats <- c(mean = NA_real_, sd = NA_real_)
    detail <- ""
    passed <- tryCatch({
      result <- force(code)
      if (is.list(result)) {
        stats <- c(mean = mean(result$samples), sd = sd(result$samples))
        detail <- result$detail
        isTRUE(result$pass)
      } else isTRUE(result)
    }, error = function(e) { detail <<- conditionMessage(e); FALSE })
    cat(sprintf("%s: %s | mean=%.6f sd=%.6f%s\n", name,
                if (passed) "PASS" else "FAIL", stats[1L], stats[2L],
                if (nzchar(detail)) paste0(" | ", detail) else ""))
    rows[[length(rows) + 1L]] <<- data.frame(test = name, passed = passed,
      mean = unname(stats[1L]), sd = unname(stats[2L]), detail = detail)
    invisible(passed)
  }
  expect_error <- function(code, pattern) {
    tryCatch({ force(code); FALSE }, error = function(e)
      grepl(pattern, conditionMessage(e), ignore.case = TRUE))
  }
  close <- function(a, b, tol = 1e-7) all(abs(a - b) <= tol * pmax(1, abs(b)))
  distribution <- function(samples, mu, variance, fourth, cdf, support = c(-Inf, Inf)) {
    m <- length(samples)
    u <- sort(cdf(samples))
    d <- max(seq_len(m) / m - u, u - (seq_len(m) - 1) / m)
    d_bound <- sqrt(base::log(2 / 1e-6) / (2 * m))
    variance_se <- sqrt((fourth - (m - 3) / (m - 1) * variance^2) / m)
    list(samples = samples,
         pass = all(is.finite(samples)) && all(samples >= support[1L] & samples <= support[2L]) &&
           abs(mean(samples) - mu) <= 6 * sqrt(variance / m) &&
           abs(var(samples) - variance) <= 6 * variance_se && d <= d_bound,
         detail = sprintf("truth mean=%.6f sd=%.6f; CDF D=%.5f <= %.5f",
                          mu, sqrt(variance), d, d_bound))
  }

  record("NUMERICAL_LOG_DERIVATIVE", {
    h <- function(x) -x^2 / 2
    dh <- .ars_derivative(h, NULL, c(-Inf, Inf))
    close(dh(c(-4, -1, 0, 0.3, 2)), c(4, 1, 0, -0.3, -2)) &&
      close(.ars_derivative(function(x) -2*x, NULL, c(0, Inf))(c(1e-8, 1, 20)), rep(-2, 3))
  })
  record("PIECEWISE_LOG_INTEGRALS", {
    cases <- list(c(-Inf, 1, 2), c(-1, Inf, -3), c(-2, 3, 0),
                  c(-2, 3, 1e-12), c(-2, 3, -1e-12), c(-2, 3, 2), c(-2, 3, -2))
    all(vapply(cases, function(v) {
      actual <- exp(.ars_log_mass(v[1L], v[2L], 0, 0, v[3L]))
      truth <- integrate(function(x) exp(v[3L] * x), v[1L], v[2L])$value
      close(actual, truth)
    }, logical(1))) &&
      close(.ars_log_mass(0, 1, 0, 1000, 0), 1000) &&
      expect_error(.ars_log_mass(0, Inf, 0, 0, 1), "Non-integrable")
  })
  record("PIECEWISE_INVERSE_CDF", {
    u <- c(0.001, 0.2, 0.5, 0.9, 0.999)
    close(.ars_piece_quantile(u, 0, Inf, -2), qexp(u, rate = 2)) &&
      close(.ars_piece_quantile(u, -Inf, 0, 2), base::log(u) / 2) &&
      close(.ars_piece_quantile(u, -2, 3, 0), -2 + 5*u) &&
      all(vapply(c(-2, -1e-12, 1e-12, 2), function(d) {
        q <- .ars_piece_quantile(u, -2, 3, d)
        total <- exp(.ars_log_mass(-2, 3, 0, 0, d))
        recovered <- vapply(q, function(v) exp(.ars_log_mass(-2, v, 0, 0, d)) / total, numeric(1))
        close(recovered, u)
      }, logical(1)))
  })
  record("NORMAL_TANGENTS_AND_CHORDS", {
    hull <- .ars_hull(c(-1, 0, 1), c(-0.5, 0, -0.5), c(1, 0, -1), c(-Inf, Inf), 1e-7)
    grid <- seq(-4, 4, length.out = 101)
    j <- findInterval(grid, hull$z, all.inside = TRUE)
    upper <- hull$h[j] + hull$d[j] * (grid - hull$x[j])
    lower <- vapply(grid, .ars_lower, numeric(1), hull = hull)
    close(hull$z[2:3], c(-0.5, 0.5)) &&
      all(upper >= -grid^2 / 2 - 1e-12) && all(lower <= -grid^2 / 2 + 1e-12)
  })
  record("PARALLEL_AND_ZERO_WIDTH_TANGENTS", {
    flat <- .ars_hull(c(0.25, 0.75), c(0, 0), c(0, 0), c(0, 1), 1e-7)
    kink <- .ars_hull(c(-1, 0, 1), c(-1, 0, -1), c(1, 0, -1), c(-Inf, Inf), 1e-7)
    close(sum(exp(flat$log_mass)), 1) &&
      close(sum(exp(kink$log_mass)), 2) && kink$weight[2L] == 0
  })
  record("INVALID_COUNTS", all(vapply(list(-1, 1.5, NA_real_, Inf, c(1, 2), "3", TRUE),
    function(v) expect_error(ars(v, dnorm), "n must"), logical(1))))
  record("INVALID_DOMAINS", all(vapply(list(c(1, 0), c(0, 0), c(NA, 1), 1, c(Inf, Inf)),
    function(v) expect_error(ars(1, dnorm, domain = v), "domain"), logical(1))))
  record("INVALID_INITIAL_POINTS", all(vapply(list(c(1, 1), c(NA, 1), 0, c(0, Inf), c(-1, 2)),
    function(v) expect_error(ars(1, dexp, domain = c(0, Inf), initial = v), "initial"), logical(1))))
  record("INVALID_DENSITIES", {
    all(vapply(list(function(x) -rep(1, length(x)), function(x) rep(NA_real_, length(x)),
                    function(x) 1, function(x) rep(0, length(x)), function(x) "bad"),
      function(f) expect_error(ars(1, f), "Density"), logical(1))) &&
      expect_error(ars(1, 12), "density must")
  })
  record("INVALID_CONTROLS", {
    expect_error(ars(1, dnorm, log = NA), "log must") &&
      expect_error(ars(1, dnorm, derivative = 3), "derivative must") &&
      expect_error(ars(1, dnorm, derivative = function(x) NA_real_), "derivative must") &&
      expect_error(ars(1, dnorm, tolerance = -1), "tolerance") &&
      expect_error(ars(1, dnorm, max_points = 1), "max_points") &&
      expect_error(ars(1, dnorm, max_iter = 0), "max_iter") &&
      expect_error(ars(1, dnorm, squeeze = NA), "squeeze")
  })
  record("NONINTEGRABLE_TARGET", {
    expect_error(ars(1, function(x) rep(1, length(x)), initial = c(-1, 1)), "Non-integrable") &&
      expect_error(ars(1, function(x) exp(x), initial = c(0.2, 1), domain = c(0, Inf)), "Non-integrable")
  })
  record("NON_LOG_CONCAVE_INITIALIZATION", {
    expect_error(ars(10, function(x) exp(x^2), domain = c(-2, 2)), "Non-log-concave") &&
      expect_error(ars(10, dcauchy, initial = c(-3, 0, 3)), "Non-log-concave") &&
      expect_error(ars(10, function(x) 0.5*dnorm(x, -3) + 0.5*dnorm(x, 3)), "Non-log-concave")
  })
  record("NON_LOG_CONCAVE_DURING_SAMPLING", {
    # Identical to N(0,1) near the initial hull but log-convex in the tails.
    # No initial audit sees the violation; proposals outside it must detect it.
    bad <- function(x) ifelse(abs(x) <= 0.2, -x^2/2,
                              -0.02 - 0.2*(abs(x)-0.2) + (abs(x)-0.2)^2)
    expect_error(ars(1000, bad, log = TRUE, initial = c(-0.1, 0, 0.1),
                     domain = c(-3, 3)), "Non-log-concave")
  })
  record("EMPTY_SAMPLE_AND_ITERATION_LIMIT", {
    identical(ars(0, dnorm), numeric(0)) &&
      expect_error(ars(10, dnorm, max_iter = 1), "max_iter exceeded")
  })
  record("SEEDED_REPRODUCIBILITY", {
    set.seed(seed); a <- ars(100, dnorm)
    set.seed(seed); b <- ars(100, dnorm)
    identical(a, b)
  })
  record("STANDARD_NORMAL", {
    normal <- ars(n, dnorm)
    write.table(normal, file.path(output_dir, "normal_samples.txt"),
                row.names = FALSE, col.names = FALSE, quote = FALSE)
    distribution(normal, 0, 1, 3, pnorm)
  })
  record("EXPONENTIAL_RATE_2", {
    exponential <- ars(n, dexp, domain = c(0, Inf), rate = 2)
    write.table(exponential, file.path(output_dir, "exponential_samples.txt"),
                row.names = FALSE, col.names = FALSE, quote = FALSE)
    distribution(exponential, 0.5, 0.25, 9/16, function(x) pexp(x, 2), c(0, Inf))
  })
  record("GAMMA_SHAPE_3", distribution(
    ars(n, dgamma, domain = c(0, Inf), shape = 3, rate = 2),
    1.5, 0.75, (3 + 6/3)*0.75^2, function(x) pgamma(x, 3, rate = 2), c(0, Inf)))
  record("BETA_2_3", distribution(
    ars(n, dbeta, domain = c(0, 1), shape1 = 2, shape2 = 3),
    0.4, 0.04, (3 - 9/14)*0.04^2, function(x) pbeta(x, 2, 3), c(0, 1)))
  record("BOUNDED_UNIFORM", distribution(
    ars(n, dunif, domain = c(-2, 4), min = -2, max = 4),
    1, 3, 6^4/80, function(x) punif(x, -2, 4), c(-2, 4)))
  record("UNNORMALIZED_EXPRESSION", distribution(
    ars(n, expression(exp(-(x - location)^2 / 8)), location = 3),
    3, 4, 48, function(x) pnorm(x, 3, 2)))
  record("LOG_SCALE_ANALYTIC_DERIVATIVE", distribution(
    ars(n, function(x) 1000 - (x-10)^2/8, log = TRUE, initial = c(6, 10, 14),
        derivative = function(x) -(x-10)/4, squeeze = FALSE, max_points = 15),
    10, 4, 48, function(x) pnorm(x, 10, 2)))
  record("TRUNCATED_NORMAL", {
    a <- 1; b <- 3
    z <- pnorm(b) - pnorm(a)
    mu <- (dnorm(a) - dnorm(b)) / z
    m2 <- 1 + (a*dnorm(a) - b*dnorm(b)) / z
    m3 <- ((a^2+2)*dnorm(a) - (b^2+2)*dnorm(b)) / z
    m4 <- 3 + ((a^3+3*a)*dnorm(a) - (b^3+3*b)*dnorm(b)) / z
    central4 <- m4 - 4*mu*m3 + 6*mu^2*m2 - 3*mu^4
    distribution(ars(n, dnorm, domain = c(a, b)), mu, m2-mu^2, central4,
                 function(x) (pnorm(x)-pnorm(a))/z, c(a, b))
  })
  result <- do.call(rbind, rows)
  cat(sprintf("\n%d/%d tests passed. Sample files: %s\n", sum(result$passed),
              nrow(result), normalizePath(output_dir)))
  if (stop_on_failure && any(!result$passed)) .ars_stop("Formal tests failed; see FAIL lines above.")
  invisible(result)
}
