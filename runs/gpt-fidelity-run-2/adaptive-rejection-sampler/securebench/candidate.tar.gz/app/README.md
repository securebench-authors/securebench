# Adaptive rejection sampling in base R

`ars.R` implements the tangent upper envelope, secant squeeze, piecewise
exponential proposal, rejection step, and adaptive insertion of evaluated
points from Gilks and Wild (1992). No R packages are required.

```r
source('/app/ars.R')
set.seed(42)
normal <- ars(1000, dnorm)
exponential <- ars(1000, dexp, domain = c(0, Inf), rate = 2)
unnormalized <- ars(1000, expression(exp(-x^2 / 2)))
log_target <- ars(1000, function(x) dnorm(x, 10, 2, log = TRUE),
                  log = TRUE, initial = c(6, 10, 14))
test()
```

`ars` returns a numeric vector of length `n`. Specify the support with `domain`
and, for unusual scales or locations, supply at least two distinct interior
`initial` points. Expressions use `x` and can reference variables in the calling
environment. Density functions receive any extra arguments in `...`.

The sampler validates counts, bounds, vectorized density output, support points,
and tuning parameters. It checks derivative ordering, secant slopes, tangent
intersections, and upper/lower envelope inequalities during adaptation. Failures
raise informative errors. An optional vectorized `dlogdensity` supplies exact
log-density derivatives; otherwise a five-point numerical derivative is used.
`max_iterations` limits proposals; `max_points` caps envelope storage.

The target must be positive and log-concave throughout the domain interior.
Specify `log = TRUE` when ordinary density values would underflow. Numerical
derivatives and envelope arithmetic have floating-point limits. Finite checks
cannot prove global log-concavity of an arbitrary function; a violation in an
unevaluated region may remain undetected.

Run the formal suite with:

```sh
Rscript -e 'source("/app/ars.R"); test()'
```

Each test prints `TEST_NAME: PASS` or `TEST_NAME: FAIL`, with sample means,
standard deviations, and known truth for distribution tests. Deterministic
checks report `mean=NA sd=NA`. Distribution checks use five-standard-error
moment bounds and a one-sample Kolmogorov–Smirnov statistic against the known
CDF. The default seed is fixed, and the caller's random state is restored.
Tests cover envelope components, six target configurations, invalid inputs,
non-log-concavity at initialization and during adaptation, and proposal limits.
The function raises an error if any test fails and invisibly returns a results
data frame. Its normal test writes 6,000 samples to `/app/normal_samples.txt`.

Reference: Gilks, W. R., & Wild, P. (1992). Adaptive rejection sampling for Gibbs
sampling. *Applied Statistics*, **41**(2), 337–348.
