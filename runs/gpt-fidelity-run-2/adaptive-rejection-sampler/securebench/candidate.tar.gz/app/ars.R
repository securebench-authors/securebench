# Adaptive rejection sampling (Gilks & Wild, 1992), using only base R.
#
# Usage:
#   source('/app/ars.R')
#   x <- ars(1000, dnorm)
#   y <- ars(1000, dexp, domain = c(0, Inf), rate = 2)
#   z <- ars(1000, expression(exp(-x^2 / 2)))
#   test()  # prints PASS/FAIL and writes normal_samples.txt
#
# The density must be positive and log-concave on the interior of domain.
# A density need not be normalized. Supply log = TRUE for a log-density,
# especially when ordinary densities underflow. Functions and expressions
# must return one numeric value per input x; expressions use the variable x
# and are evaluated in the caller's environment. Extra arguments in ... are
# passed to the density (or bound as variables for an expression).
#
# initial supplies at least two distinct interior support points. If omitted,
# three default points are used, with outward expansion to bracket the mode
# on unbounded domains. For unusual location/scale, provide initial explicitly.
# dlogdensity optionally supplies a vectorized derivative of the LOG density;
# otherwise a five-point numerical derivative is used. With numerical
# derivatives, envelope validity is subject to floating-point accuracy.
# max_points caps stored tangents (sampling then uses the existing envelope);
# max_iterations limits proposals, and errors rather than returning a short run.
#
# Log-concavity checks cover evaluated points, derivative ordering, secants,
# and the upper/lower hull inequalities. No finite set of evaluations can
# certify global log-concavity of an arbitrary user function. Users remain
# responsible for specifying a log-concave target and its full support.

.ars_stop <- function(message) stop(message, call. = FALSE)

.ars_count <- function(x, name, minimum = 0) {
  if (!is.numeric(x) || is.complex(x) || length(x) != 1L || is.na(x) ||
      !is.finite(x) || x < minimum || x != floor(x) ||
      x > .Machine$integer.max) {
    .ars_stop(sprintf('%s must be an integer between %s and %s.',
                      name, minimum, .Machine$integer.max))
  }
  as.integer(x)
}

.ars_vector <- function(value, n, name, allow_negative_inf = FALSE) {
  if (!is.numeric(value) || is.complex(value) || !is.null(dim(value)) ||
      length(value) != n || anyNA(value) || any(value == Inf) ||
      (!allow_negative_inf && any(!is.finite(value)))) {
    .ars_stop(paste0(name, ' must return one valid numeric value per x.'))
  }
  as.numeric(value)
}

.ars_target <- function(density, log, dots, caller) {
  if (is.function(density)) {
    evaluate <- function(x) do.call(density, c(list(x), dots))
  } else if (is.call(density) ||
             (is.expression(density) && length(density) == 1L)) {
    evaluate <- function(x) {
      bindings <- list2env(dots, parent = caller)
      bindings$x <- x
      eval(density, envir = bindings)
    }
  } else {
    .ars_stop('density must be a vectorized function, call, or single expression.')
  }
  function(x) {
    value <- tryCatch(evaluate(x), error = function(e)
      .ars_stop(paste0('Density evaluation failed: ', conditionMessage(e))))
    value <- .ars_vector(value, length(x), 'density', log)
    if (!log) {
      if (any(value < 0)) .ars_stop('density returned negative values.')
      value <- base::log(value)
    }
    value
  }
}

.ars_derivative <- function(x, h, domain, derivative) {
  if (!is.null(derivative)) {
    value <- tryCatch(derivative(x), error = function(e)
      .ars_stop(paste0('dlogdensity evaluation failed: ', conditionMessage(e))))
    return(.ars_vector(value, length(x), 'dlogdensity'))
  }
  step <- .Machine$double.eps^(1 / 5) * pmax(1, abs(x))
  step <- pmin(step, (x - domain[1]) / 4, (domain[2] - x) / 4)
  if (any(step <= 0 | x - 2 * step == x | x + 2 * step == x)) {
    .ars_stop('Support points are too close to a boundary for numerical derivatives.')
  }
  values <- matrix(h(c(x - 2 * step, x - step, x + step, x + 2 * step)),
                   nrow = length(x), ncol = 4L)
  if (any(!is.finite(values))) {
    .ars_stop('Density must be positive near support points; check domain or use log = TRUE.')
  }
  result <- (values[, 1] - 8 * values[, 2] +
             8 * values[, 3] - values[, 4]) / (12 * step)
  .ars_vector(result, length(x), 'Numerical log-density derivative')
}

.ars_points <- function(x, h, domain, derivative) {
  value <- h(x)
  if (any(!is.finite(value))) {
    .ars_stop('Density must be positive at support points; check initial/domain or use log = TRUE.')
  }
  list(x = x, h = value, d = .ars_derivative(x, h, domain, derivative))
}

.ars_check_concavity <- function(points) {
  x <- points$x
  h <- points$h
  d <- points$d
  secant <- diff(h) / diff(x)
  tolerance <- 1e-7 * pmax(1, abs(secant), abs(head(d, -1)), abs(tail(d, -1)))
  if (any(diff(d) > tolerance) ||
      any(secant > head(d, -1) + tolerance) ||
      any(secant < tail(d, -1) - tolerance)) {
    .ars_stop('Log-concavity violation: derivatives and secant slopes are inconsistent.')
  }
  invisible(TRUE)
}

# Log integral of exp(height + slope * (x - anchor)) on [left, right].
# Endpoint-based formulas avoid exponentiating large tangent heights.
.ars_log_integral <- function(left, right, slope, anchor, height) {
  if (left >= right) return(-Inf)
  if (slope == 0) {
    if (!is.finite(left) || !is.finite(right))
      .ars_stop('Nonintegrable flat envelope tail; provide better initial points.')
    return(height + base::log(right - left))
  }
  if (slope > 0) {
    if (!is.finite(right)) .ars_stop('Nonintegrable right envelope tail.')
    endpoint <- height + slope * (right - anchor)
    width <- slope * (right - left)
  } else {
    if (!is.finite(left)) .ars_stop('Nonintegrable left envelope tail.')
    endpoint <- height + slope * (left - anchor)
    width <- -slope * (right - left)
  }
  endpoint + base::log(-expm1(-width)) - base::log(abs(slope))
}

.ars_hull <- function(points, domain) {
  .ars_check_concavity(points)
  x <- points$x
  h <- points$h
  d <- points$d
  k <- length(x)
  z <- numeric(k + 1L)
  z[c(1L, k + 1L)] <- domain
  for (i in seq_len(k - 1L)) {
    gap <- d[i] - d[i + 1L]
    # Parallel tangents to an affine portion are the same line, to tolerance.
    if (abs(gap) <= 1e-10 * max(1, abs(d[i]), abs(d[i + 1L]))) {
      z[i + 1L] <- x[i] + (x[i + 1L] - x[i]) / 2
    } else {
      z[i + 1L] <- x[i] +
        (h[i + 1L] - h[i] - d[i + 1L] * (x[i + 1L] - x[i])) / gap
      tolerance <- 1e-7 * max(1, abs(x[i]), abs(x[i + 1L]))
      if (z[i + 1L] < x[i] - tolerance || z[i + 1L] > x[i + 1L] + tolerance)
        .ars_stop('Log-concavity violation: tangent intersection outside support interval.')
      z[i + 1L] <- max(x[i], min(x[i + 1L], z[i + 1L]))
    }
  }
  if (any(diff(z) <= 0)) .ars_stop('Degenerate tangent envelope; change initial points.')
  mass <- vapply(seq_len(k), function(i)
    .ars_log_integral(z[i], z[i + 1L], d[i], x[i], h[i]), numeric(1))
  if (any(!is.finite(mass))) .ars_stop('Envelope masses are not finite; rescale the target or initial points.')
  weights <- exp(mass - max(mass))
  list(points = points, z = z, weights = weights / sum(weights))
}

# Inverse CDF for a truncated exponential, including infinite one-sided tails.
.ars_inverse <- function(u, left, right, slope) {
  if (slope == 0) return(left + u * (right - left))
  width <- abs(slope) * (right - left)
  if (slope > 0) {
    right + log1p(-(1 - u) * (-expm1(-width))) / slope
  } else {
    left + log1p(-u * (-expm1(-width))) / slope
  }
}

.ars_propose <- function(hull) {
  i <- sample.int(length(hull$weights), 1L, prob = hull$weights)
  p <- hull$points
  x <- .ars_inverse(runif(1L), hull$z[i], hull$z[i + 1L], p$d[i])
  list(x = x, upper = p$h[i] + p$d[i] * (x - p$x[i]))
}

.ars_lower <- function(x, points) {
  i <- findInterval(x, points$x)
  if (i == 0L || i == length(points$x)) return(-Inf)
  fraction <- (x - points$x[i]) / (points$x[i + 1L] - points$x[i])
  (1 - fraction) * points$h[i] + fraction * points$h[i + 1L]
}

.ars_initialize <- function(initial, h, domain, derivative) {
  if (is.null(initial)) {
    if (all(is.finite(domain))) {
      initial <- domain[1] + c(0.25, 0.5, 0.75) * diff(domain)
    } else if (is.finite(domain[1])) {
      initial <- domain[1] + c(0.25, 1, 2)
    } else if (is.finite(domain[2])) {
      initial <- domain[2] - c(2, 1, 0.25)
    } else initial <- c(-2, 0, 2)
  }
  if (!is.numeric(initial) || is.complex(initial) || length(initial) < 2L ||
      any(!is.finite(initial)) || any(initial <= domain[1] | initial >= domain[2]) ||
      anyDuplicated(initial)) {
    .ars_stop('initial must contain at least two distinct finite points strictly inside domain.')
  }
  points <- .ars_points(sort(initial), h, domain, derivative)
  for (attempt in seq_len(60L)) {
    .ars_check_concavity(points)
    left_bad <- !is.finite(domain[1]) && points$d[1] <= 0
    k <- length(points$x)
    right_bad <- !is.finite(domain[2]) && points$d[k] >= 0
    if (!left_bad && !right_bad) return(points)
    span <- max(1, diff(range(points$x)))
    extra <- c(if (left_bad) points$x[1] - span,
               if (right_bad) points$x[k] + span)
    if (any(!is.finite(extra))) break
    added <- .ars_points(extra, h, domain, derivative)
    order <- order(c(points$x, added$x))
    points <- list(x = c(points$x, added$x)[order],
                   h = c(points$h, added$h)[order],
                   d = c(points$d, added$d)[order])
  }
  .ars_stop('Could not find integrable envelope tails; check density/domain and supply initial points.')
}

ars <- function(n, density, domain = c(-Inf, Inf), initial = NULL,
                log = FALSE, ..., dlogdensity = NULL, max_iterations = NULL,
                max_points = 1000L) {
  n <- .ars_count(n, 'n')
  if (!is.numeric(domain) || is.complex(domain) || length(domain) != 2L ||
      anyNA(domain) || domain[1] >= domain[2])
    .ars_stop('domain must be two increasing bounds, for example c(0, Inf).')
  if (!is.logical(log) || length(log) != 1L || is.na(log))
    .ars_stop('log must be TRUE or FALSE.')
  if (!is.null(dlogdensity) && !is.function(dlogdensity))
    .ars_stop('dlogdensity must be a vectorized function or NULL.')
  max_points <- .ars_count(max_points, 'max_points', 2L)
  if (is.null(max_iterations)) max_iterations <- min(.Machine$integer.max, max(10000, 100 * n))
  max_iterations <- .ars_count(max_iterations, 'max_iterations', 1L)
  h <- .ars_target(density, log, list(...), parent.frame())
  points <- .ars_initialize(initial, h, domain, dlogdensity)
  if (length(points$x) > max_points) .ars_stop('max_points is smaller than the initial envelope.')
  hull <- .ars_hull(points, domain)
  if (n == 0L) return(numeric(0))
  result <- numeric(n)
  accepted <- 0L
  for (iteration in seq_len(max_iterations)) {
    proposal <- .ars_propose(hull)
    x <- proposal$x
    upper <- proposal$upper
    lower <- .ars_lower(x, hull$points)
    log_u <- base::log(runif(1L))
    if (!is.finite(x) || x <= domain[1] || x >= domain[2])
      .ars_stop('Proposal reached a numerical boundary; rescale domain or initial points.')
    if (log_u <= lower - upper) {
      # Gilks-Wild squeezing test: no density evaluation needed.
      accept <- TRUE
    } else {
      value <- h(x)
      if (!is.finite(value))
        .ars_stop('Density is zero inside domain or underflowed; check support or use log = TRUE.')
      tolerance <- 1e-7 * max(1, abs(value), abs(upper),
                              if (is.finite(lower)) abs(lower) else 0)
      if (value > upper + tolerance || value < lower - tolerance)
        .ars_stop('Log-concavity violation: density lies outside its tangent/secant envelope.')
      accept <- log_u <= value - upper
      # Adapt after either acceptance or rejection when the density was evaluated.
      # Derivatives are still checked if the storage cap has been reached.
      added <- list(x = x, h = value,
                    d = .ars_derivative(x, h, domain, dlogdensity))
      p <- hull$points
      if (all(abs(p$x - x) > 1e-12 * pmax(1, abs(x), abs(p$x)))) {
        order <- order(c(p$x, x))
        combined <- list(x = c(p$x, x)[order], h = c(p$h, value)[order],
                         d = c(p$d, added$d)[order])
        .ars_check_concavity(combined)
        if (length(p$x) < max_points) hull <- .ars_hull(combined, domain)
      }
    }
    if (accept) {
      accepted <- accepted + 1L
      result[accepted] <- x
      if (accepted == n) return(result)
    }
  }
  .ars_stop(sprintf('max_iterations reached: accepted %d of %d requested samples.', accepted, n))
}

# Formal tests: deterministic algebraic checks and fixed-seed distribution tests.
# Each stochastic check combines support, five-standard-error mean/SD bounds,
# and a two-sided one-sample KS check (D < 1.95/sqrt(n), approximately alpha
# 0.001). The wider moment bounds make Monte Carlo failures unlikely.
# Returns a data.frame invisibly. Errors count as failures; stop_on_failure
# makes the suite suitable for an automated build. The caller's RNG is restored.
test <- function(sample_file = '/app/normal_samples.txt', n = 6000L,
                 seed = 1992L, stop_on_failure = TRUE) {
  n <- .ars_count(n, 'n', 2000L)
  seed <- .ars_count(seed, 'seed')
  old_kind <- RNGkind()
  had_seed <- exists('.Random.seed', envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get('.Random.seed', envir = .GlobalEnv)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign('.Random.seed', old_seed, envir = .GlobalEnv)
    else if (exists('.Random.seed', envir = .GlobalEnv, inherits = FALSE))
      rm('.Random.seed', envir = .GlobalEnv)
  }, add = TRUE)
  set.seed(seed, kind = 'Mersenne-Twister', normal.kind = 'Inversion', sample.kind = 'Rejection')
  results <- list()
  run <- function(name, action) {
    detail <- 'mean=NA sd=NA (deterministic check)'
    outcome <- tryCatch({
      value <- action()
      if (is.character(value)) detail <- value
      TRUE
    }, error = function(e) {
      detail <<- paste('mean=NA sd=NA;', conditionMessage(e))
      FALSE
    })
    cat(sprintf('%s: %s | %s\n', name, if (outcome) 'PASS' else 'FAIL', detail))
    results[[length(results) + 1L]] <<- data.frame(test = name, passed = outcome,
                                                  details = detail)
  }
  expect_error <- function(action, pattern) {
    error <- tryCatch({ action(); NULL }, error = function(e) conditionMessage(e))
    if (is.null(error) || !grepl(pattern, error, ignore.case = TRUE))
      stop('Expected an error matching: ', pattern)
  }
  distribution <- function(x, cdf, truth_mean, truth_sd, fourth_moment, support) {
    stopifnot(length(x) == n, all(is.finite(x)), all(support(x)))
    m <- mean(x)
    s <- sd(x)
    mean_limit <- 5 * truth_sd / sqrt(n)
    sd_limit <- 5 * sqrt((fourth_moment - truth_sd^4) / (4 * n * truth_sd^2))
    ks <- unname(stats::ks.test(x, cdf, exact = FALSE)$statistic)
    detail <- sprintf('mean=%.5f (truth %.5f) sd=%.5f (truth %.5f) KS_D=%.5f',
                      m, truth_mean, s, truth_sd, ks)
    if (abs(m - truth_mean) > mean_limit || abs(s - truth_sd) > sd_limit ||
        ks >= 1.95 / sqrt(n)) stop(detail, '; moments or CDF outside tolerance')
    detail
  }
  run('LOG_INTEGRALS', function() {
    stopifnot(abs(.ars_log_integral(0, 2, 0, 0, 3) - (3 + log(2))) < 1e-12,
              abs(.ars_log_integral(0, Inf, -2, 0, 0) - log(0.5)) < 1e-12,
              abs(.ars_log_integral(-Inf, 0, 3, 0, 0) - log(1 / 3)) < 1e-12,
              abs(.ars_log_integral(0, 1, 2, 0, 0) - log(expm1(2) / 2)) < 1e-12,
              abs(.ars_log_integral(0, 1, 1e-14, 0, 0)) < 1e-12,
              is.finite(.ars_log_integral(0, 1, 1000, 0, 0)))
  })
  run('INVERSE_CDF', function() {
    u <- c(0.01, 0.2, 0.5, 0.9, 0.99)
    stopifnot(max(abs(.ars_inverse(u, 0, Inf, -2) - qexp(u, 2))) < 1e-12,
              max(abs(exp(3 * .ars_inverse(u, -Inf, 0, 3)) - u)) < 1e-12,
              max(abs(.ars_inverse(u, -2, 2, 0) - (-2 + 4 * u))) < 1e-12)
    for (slope in c(-10, -0.01, 0.01, 10)) {
      x <- .ars_inverse(u, -1, 2, slope)
      cdf <- expm1(slope * (x + 1)) / expm1(slope * 3)
      stopifnot(max(abs(cdf - u)) < 1e-10)
    }
  })
  run('DERIVATIVES_AND_HULLS', function() {
    h <- function(x) -x^2 / 2
    p <- .ars_points(c(-2, 0, 2), h, c(-Inf, Inf), NULL)
    hull <- .ars_hull(p, c(-Inf, Inf))
    grid <- seq(-5, 5, length.out = 101)
    upper <- vapply(grid, function(x) min(p$h + p$d * (x - p$x)), numeric(1))
    lower <- vapply(grid, .ars_lower, numeric(1), points = p)
    stopifnot(max(abs(p$d + p$x)) < 1e-9,
              max(abs(hull$z[2:3] - c(-1, 1))) < 1e-9,
              all(upper >= h(grid) - 1e-10), all(lower <= h(grid) + 1e-10),
              abs(sum(hull$weights) - 1) < 1e-12)
  })
  run('NORMAL', function() {
    x <- ars(n, dnorm)
    detail <- distribution(x, pnorm, 0, 1, 3, function(x) rep(TRUE, length(x)))
    write.table(x, file = sample_file, row.names = FALSE, col.names = FALSE, quote = FALSE)
    detail
  })
  run('EXPONENTIAL', function() {
    x <- ars(n, dexp, domain = c(0, Inf), rate = 2)
    distribution(x, function(x) pexp(x, 2), 0.5, 0.5, 9 / 16, function(x) x > 0)
  })
  run('GAMMA', function() {
    x <- ars(n, dgamma, domain = c(0, Inf), shape = 3, rate = 2)
    distribution(x, function(x) pgamma(x, 3, 2), 1.5, sqrt(3) / 2,
                 (3 + 6 / 3) * (3 / 4)^2, function(x) x > 0)
  })
  run('UNIFORM_BOUNDED', function() {
    x <- ars(n, dunif, domain = c(-2, 4), min = -2, max = 4)
    distribution(x, function(x) punif(x, -2, 4), 1, sqrt(3), 6^4 / 80,
                 function(x) x > -2 & x < 4)
  })
  run('EXPRESSION_AND_LOG_DERIVATIVE', function() {
    center <- 5
    x <- ars(n, expression(-(x - center)^2 / 8), log = TRUE,
             dlogdensity = function(x) -(x - center) / 4)
    distribution(x, function(x) pnorm(x, 5, 2), 5, 2, 48,
                 function(x) rep(TRUE, length(x)))
  })
  run('LEFT_INFINITE_DOMAIN', function() {
    x <- ars(n, expression(exp(x)), domain = c(-Inf, 0))
    distribution(x, function(x) ifelse(x < 0, exp(x), 1), -1, 1, 9,
                 function(x) x < 0)
  })
  run('INVALID_INPUTS', function() {
    for (bad in list(-1, 1.5, NA_real_, Inf, c(1, 2), '10'))
      expect_error(function() ars(bad, dnorm), 'n must')
    for (bad in list(c(1, 0), c(0, 0), c(NA, 1), 1, c(Inf, Inf)))
      expect_error(function() ars(1, dnorm, domain = bad), 'domain')
    expect_error(function() ars(1, dnorm, initial = c(0, 0)), 'initial')
    expect_error(function() ars(1, dexp, domain = c(0, Inf), initial = c(0, 1)), 'initial')
    expect_error(function() ars(1, function(x) -abs(x)), 'negative')
    expect_error(function() ars(1, function(x) 1), 'per x')
    expect_error(function() ars(1, function(x) rep(NA_real_, length(x))), 'valid numeric')
    expect_error(function() ars(1, 42), 'density must')
    expect_error(function() ars(1, dnorm, log = 1), 'log must')
    expect_error(function() ars(1, dnorm, max_points = 1), 'max_points')
    expect_error(function() ars(1, dnorm, dlogdensity = 1), 'dlogdensity')
    stopifnot(identical(ars(0, dnorm), numeric(0)))
  })
  run('NON_LOG_CONCAVE', function() {
    expect_error(function() ars(10, function(x) exp(x^2), domain = c(-2, 2)),
                 'Log-concavity')
    expect_error(function() ars(10, function(x) dcauchy(x), initial = c(-3, 0, 3)),
                 'Log-concavity')
    expect_error(function() ars(10, dgamma, domain = c(0, Inf), shape = 0.5),
                 'Log-concavity')
  })
  run('CONCAVITY_DURING_ADAPTATION', function() {
    # The narrow bump is invisible at the initial knots, whose hull passes.
    # A subsequently evaluated proposal exposes the envelope violation.
    h <- function(x) -x^2 / 2 + 2 * exp(-100 * (x - 1)^2)
    .ars_hull(.ars_points(c(-2, 0, 2), h, c(-3, 3), NULL), c(-3, 3))
    expect_error(function() ars(1000, h, log = TRUE, domain = c(-3, 3),
                               initial = c(-2, 0, 2)), 'Log-concavity')
  })
  run('PROPOSAL_LIMIT', function() {
    expect_error(function() ars(100, dnorm, max_iterations = 1), 'max_iterations reached')
  })
  answer <- do.call(rbind, results)
  cat(sprintf('TOTAL: %s | %d/%d tests passed; sample file: %s\n',
              if (all(answer$passed)) 'PASS' else 'FAIL', sum(answer$passed),
              nrow(answer), sample_file))
  if (stop_on_failure && !all(answer$passed)) stop('ARS formal tests failed.', call. = FALSE)
  invisible(answer)
}
