"""Recover a six-edge Gaussian DAG and sample from do(Y=0).

Run with numpy, pandas, scipy, and networkx installed.
"""

import itertools
import json
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from scipy.stats import kurtosis, skew


ROOT = Path(__file__).resolve().parent
data = pd.read_csv(ROOT / "bn_sample_10k.csv")
names = list(data.columns)
n = len(data)
assert n == 10000 and not data.isna().any().any()

# Fit every local Gaussian conditional once. Variances use the MLE divisor n.
local = {}
for node in names:
    others = [v for v in names if v != node]
    for size in range(len(others) + 1):
        for parents in itertools.combinations(others, size):
            design = np.column_stack([np.ones(n), data[list(parents)].to_numpy()])
            beta = np.linalg.lstsq(design, data[node].to_numpy(), rcond=None)[0]
            residual = data[node].to_numpy() - design @ beta
            variance = float(np.mean(residual**2))
            # Gaussian -2 log likelihood up to a shared constant, plus BIC penalty.
            score = n * np.log(variance) + (size + 2) * np.log(n)
            local[node, frozenset(parents)] = {
                "parents": list(parents),
                "intercept": float(beta[0]),
                "coefficients": dict(zip(parents, map(float, beta[1:]))),
                "noise_variance": variance,
                "residual_skewness": float(skew(residual)),
                "residual_excess_kurtosis": float(kurtosis(residual)),
                "bic_without_shared_constant": float(score),
            }

# Exhaust all six-edge DAGs with U a root, including all possible skeletons.
candidates = []
for skeleton in itertools.combinations(itertools.combinations(names, 2), 6):
    for directions in itertools.product([False, True], repeat=6):
        edges = [pair if forward else pair[::-1]
                 for pair, forward in zip(skeleton, directions)]
        if any(child == "U" for parent, child in edges):
            continue
        graph = nx.DiGraph()
        graph.add_nodes_from(names)
        graph.add_edges_from(edges)
        if not nx.is_directed_acyclic_graph(graph):
            continue
        score = sum(local[v, frozenset(graph.predecessors(v))]
                    ["bic_without_shared_constant"] for v in names)
        candidates.append((score, graph))

best_score = min(score for score, _ in candidates)
tied = [(score, graph) for score, graph in candidates
        if abs(score - best_score) < 1e-7]
# Apply the supplied alphabetical rule only among equally scoring solutions.
_, graph = min(tied, key=lambda item: sum(
    parent < child for parent, child in item[1].edges() if parent != "U"))
assert graph.in_degree("U") == 0 and graph.number_of_edges() == 6


def save_edges(g, filename):
    pd.DataFrame(sorted((child, parent) for parent, child in g.edges()),
                 columns=["to", "from"]).to_csv(ROOT / filename, index=False)


save_edges(graph, "learned_dag.csv")
parameters = {v: local[v, frozenset(graph.predecessors(v))] for v in names}

# A hard intervention replaces Y's conditional with a point mass and deletes
# all incoming edges. Every other fitted conditional remains unchanged.
intervened = graph.copy()
intervened.remove_edges_from(list(intervened.in_edges("Y")))
save_edges(intervened, "intervened_dag.csv")

rng = np.random.default_rng(20261112)
sample = pd.DataFrame(index=range(10000), columns=names, dtype=float)
for node in nx.topological_sort(intervened):
    if node == "Y":
        sample[node] = 0.0
        continue
    params = parameters[node]
    mean = np.full(len(sample), params["intercept"])
    for parent, coefficient in params["coefficients"].items():
        mean += coefficient * sample[parent].to_numpy()
    sample[node] = mean + rng.normal(0, np.sqrt(params["noise_variance"]),
                                   size=len(sample))
sample.to_csv(ROOT / "final_bn_sample.csv", index=False)

report = {
    "model": "linear Gaussian Bayesian network fitted by maximum likelihood",
    "seed": 20261112,
    "candidate_dags": len(candidates),
    "equally_scoring_best_dags": len(tied),
    "best_bic_without_shared_constant": best_score,
    "bic_gap_to_next_distinct_score": min(
        score - best_score for score, _ in candidates if score > best_score + 1e-7),
    "parameters": parameters,
    "intervention": {"node": "Y", "value": 0.0},
}
(ROOT / "fitted_bn.json").write_text(json.dumps(report, indent=2) + "\n")

# Validate the saved outputs, including schema, intervention, and topology.
saved = pd.read_csv(ROOT / "final_bn_sample.csv")
assert saved.shape == (10000, len(names))
assert list(saved.columns) == names
assert np.isfinite(saved.to_numpy()).all()
assert (saved["Y"] == 0.0).all()
assert intervened.in_degree("Y") == 0
assert intervened.number_of_edges() == 5
assert nx.is_directed_acyclic_graph(intervened)
for filename, expected in [("learned_dag.csv", graph),
                           ("intervened_dag.csv", intervened)]:
    edges = pd.read_csv(ROOT / filename)
    assert list(edges.columns) == ["to", "from"]
    assert set(zip(edges["from"], edges["to"])) == set(expected.edges())
print(json.dumps(report, indent=2))
print("Intervened sample summary:")
print(saved.describe().to_string())
