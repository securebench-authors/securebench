# Exhaustive six-edge linear Gaussian DAG recovery and do(Y = 0).
set.seed(20261112)
data <- read.csv('/app/bn_sample_10k.csv', check.names = FALSE)
nodes <- names(data)
n <- nrow(data)
p <- length(nodes)
stopifnot(n == 10000L, !anyNA(data), all(vapply(data, is.numeric, logical(1))))

# Cache Gaussian maximum-likelihood conditional models for every parent set.
models <- vector('list', p)
for (j in seq_len(p)) {
  models[[j]] <- vector('list', 2^p)
  others <- setdiff(seq_len(p), j)
  for (mask in 0:(2^p - 1)) {
    parents <- which(as.logical(intToBits(mask)[seq_len(p)]))
    if (j %in% parents) next
    design <- cbind('(Intercept)' = 1, as.matrix(data[, parents, drop = FALSE]))
    fit <- lm.fit(design, data[[j]])
    variance <- mean(fit$residuals^2)
    models[[j]][[mask + 1L]] <- list(
      parents = parents, coefficients = fit$coefficients, variance = variance,
      loglik = -n/2 * (log(2*pi*variance) + 1), residuals = fit$residuals)
  }
}

pairs <- combn(seq_len(p), 2)
# 0 = absent, 1 = first -> second, 2 = second -> first.
options <- lapply(seq_len(ncol(pairs)), function(k) {
  a <- pairs[1,k]; b <- pairs[2,k]
  if (nodes[a] == 'U') return(c(0L, 1L))
  if (nodes[b] == 'U') return(c(0L, 2L))
  0:2
})
candidates <- as.matrix(expand.grid(options))
candidates <- candidates[rowSums(candidates != 0L) == 6L, , drop = FALSE]

topological_order <- function(adj) {
  remaining <- seq_len(p)
  order <- integer()
  while (length(remaining)) {
    roots <- remaining[colSums(adj[remaining, remaining, drop = FALSE]) == 0]
    if (!length(roots)) return(NULL)
    order <- c(order, roots)
    remaining <- setdiff(remaining, roots)
  }
  order
}

best_score <- -Inf
best_adjacency <- NULL
best_tie_penalty <- Inf
equivalent_count <- 0L
all_scores <- numeric()
for (i in seq_len(nrow(candidates))) {
  adj <- matrix(0L, p, p, dimnames = list(nodes, nodes))
  for (k in which(candidates[i,] != 0L)) {
    a <- pairs[1,k]; b <- pairs[2,k]
    if (candidates[i,k] == 1L) adj[a,b] <- 1L else adj[b,a] <- 1L
  }
  if (is.null(topological_order(adj))) next
  masks <- colSums(adj * 2^(seq_len(p) - 1L))
  score <- sum(vapply(seq_len(p), function(j) models[[j]][[masks[j]+1L]]$loglik, numeric(1)))
  all_scores <- c(all_scores, score)
  edges <- which(adj == 1L, arr.ind = TRUE)
  # For observationally equivalent DAGs, prefer later letter -> earlier letter,
  # excluding U, which is explicitly known to have no parents.
  penalty <- sum(vapply(seq_len(nrow(edges)), function(k) {
    from <- nodes[edges[k,1]]; to <- nodes[edges[k,2]]
    from != 'U' && to != 'U' && from < to
  }, logical(1)))
  if (score > best_score + 1e-7) {
    best_score <- score
    best_adjacency <- adj
    best_tie_penalty <- penalty
    equivalent_count <- 1L
  } else if (abs(score - best_score) <= 1e-7) {
    equivalent_count <- equivalent_count + 1L
    if (penalty < best_tie_penalty) {
      best_adjacency <- adj
      best_tie_penalty <- penalty
    }
  }
}

edge_table <- function(adj) {
  ij <- which(adj == 1L, arr.ind = TRUE)
  out <- data.frame(to = nodes[ij[,2]], from = nodes[ij[,1]])
  out[order(out$to, out$from), , drop = FALSE]
}
write.csv(edge_table(best_adjacency), '/app/learned_dag.csv', row.names = FALSE, quote = FALSE)

# A perfect intervention replaces Y's conditional distribution by a point mass
# and removes its incoming edges, leaving every other mechanism unchanged.
intervened_adjacency <- best_adjacency
intervened_adjacency[, 'Y'] <- 0L
write.csv(edge_table(intervened_adjacency), '/app/intervened_dag.csv', row.names = FALSE, quote = FALSE)

sampled <- as.data.frame(matrix(NA_real_, 10000L, p, dimnames = list(NULL, nodes)))
selected_models <- vector('list', p)
names(selected_models) <- nodes
for (j in seq_len(p)) {
  mask <- sum(best_adjacency[,j] * 2^(seq_len(p) - 1L))
  selected_models[[j]] <- models[[j]][[mask+1L]]
}
for (j in topological_order(intervened_adjacency)) {
  if (nodes[j] == 'Y') {
    sampled[[j]] <- 0.0
  } else {
    model <- selected_models[[j]]
    design <- cbind(1, as.matrix(sampled[, model$parents, drop = FALSE]))
    sampled[[j]] <- as.vector(design %*% model$coefficients) + rnorm(nrow(sampled), sd = sqrt(model$variance))
  }
}
write.csv(sampled, '/app/final_bn_sample.csv', row.names = FALSE, quote = FALSE)

# Validate written artifacts and record a compact, reproducible fit report.
check <- read.csv('/app/final_bn_sample.csv', check.names = FALSE)
stopifnot(identical(names(check), nodes), nrow(check) == 10000L,
          all(check$Y == 0), all(is.finite(as.matrix(check))),
          sum(best_adjacency) == 6L, sum(best_adjacency[,'U']) == 0L,
          sum(intervened_adjacency[,'Y']) == 0L)
sink('/app/bn_fit_report.txt', split = TRUE)
cat('Model: linear Gaussian Bayesian network, maximum likelihood estimation\n')
cat('Seed: 20261112\n')
cat('Acyclic six-edge candidates with U a root:', length(all_scores), '\n')
cat('Maximum log likelihood:', best_score, '\n')
cat('DAGs tied for maximum:', equivalent_count, '\n')
cat('Likelihood gap to next distinct score:', best_score - max(all_scores[all_scores < best_score - 1e-7]), '\n')
cat('Learned edges (to, from):\n');print(edge_table(best_adjacency), row.names = FALSE)
for (j in seq_len(p)) {
  m <- selected_models[[j]]
  z <- m$residuals / sqrt(m$variance)
  cat('\nNode:', nodes[j], '\nParents:', nodes[m$parents], '\n')
  print(m$coefficients)
  cat('Noise standard deviation:', sqrt(m$variance), '\n')
  cat('Residual skewness:', mean(z^3), '; excess kurtosis:', mean(z^4) - 3, '\n')
}
cat('\nIntervened edges (to, from):\n');print(edge_table(intervened_adjacency), row.names = FALSE)
cat('\nIntervened sample summary:\n');print(summary(check))
cat('\nValidation passed: six learned edges; U has no parents; Y has no incoming\nedges after intervention; 10000 finite rows, original columns, Y exactly zero.\n')
sink()
