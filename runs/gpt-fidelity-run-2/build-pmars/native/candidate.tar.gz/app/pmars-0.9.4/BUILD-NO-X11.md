# Console build of Debian pMARS 0.9.4-1

Source files downloaded from https://deb.debian.org/debian/pool/main/p/pmars/:
- pmars_0.9.4-1.dsc
- pmars_0.9.4.orig.tar.xz
- pmars_0.9.4-1.debian.tar.xz

The archives and descriptor are retained in /app. Archive sizes and SHA-256
checksums were verified against Checksums-Sha256 in the Debian descriptor.
Extracted with `dpkg-source --no-check -x pmars_0.9.4-1.dsc`, which applied
all four Debian patches. The descriptor signature was not verified.

Local changes to src/Makefile: removed -DXWINGRAPHX from CFLAGS and cleared
LIB to remove -lX11. SERVER is not defined, so the console debugger is enabled.

Build and install:
```sh
cd /app/pmars-0.9.4
make -C src -j2
install -m 0755 src/pmars /usr/local/bin/pmars
```

Validation:
- `pmars -b -r 50 -f flashpaper.red rave.red | tail -n 1` in /app:
  Results: 12 30 8
- readelf and ldd: libc.so.6 is the only required shared library; no X11.
- Console debugger tested with -e: listing core, inspecting registers,
  single stepping (SPL creates a second process), editing and reading back
  DAT.F #123, #456, and continuing to completion.
  Transcript: /app/pmars-debugger-test.log
