"""Run asynchronous jobs with bounded concurrency and orderly cancellation."""

import asyncio
from collections.abc import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run jobs, waiting for their cleanup before returning or raising.

    Jobs are started in list order, with at most ``max_concurrent`` running.
    If a job fails or the caller is cancelled, running jobs are cancelled and
    awaited; jobs that have not started are skipped. The original exception
    propagates after cleanup. With ``asyncio.run``, this also handles the first
    Ctrl-C, which cancels the main coroutine.

    Jobs should release resources in ``finally`` blocks and cooperate with
    cancellation. ``max_concurrent`` must be a positive integer.
    """
    if not isinstance(max_concurrent, int):
        raise TypeError("max_concurrent must be an integer")
    if max_concurrent <= 0:
        raise ValueError("max_concurrent must be greater than zero")

    jobs = iter(tasks)

    async def worker() -> None:
        for job in jobs:
            await job()

    workers = [
        asyncio.create_task(worker())
        for _ in range(min(max_concurrent, len(tasks)))
    ]
    if not workers:
        return

    completion = asyncio.gather(*workers)
    try:
        # Shield the workers so cancellation is delivered only once below;
        # cancelling them twice could interrupt their asynchronous cleanup.
        await asyncio.shield(completion)
    finally:
        for task in workers:
            if not task.done():
                task.cancel()

        cleanup = asyncio.gather(*workers, return_exceptions=True)
        cancelled_during_cleanup = False
        while not cleanup.done():
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError:
                cancelled_during_cleanup = True
        # The shield may have been cancelled before it could retrieve this
        # future's exception. All workers have now finished, so it is ready.
        if not completion.cancelled():
            completion.exception()
        if cancelled_during_cleanup:
            raise asyncio.CancelledError
