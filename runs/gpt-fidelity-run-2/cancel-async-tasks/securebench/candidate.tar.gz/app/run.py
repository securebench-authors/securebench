"""Run asynchronous jobs with bounded concurrency and structured cleanup."""

import asyncio
from collections.abc import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run each job once, with at most ``max_concurrent`` jobs active.

    ``max_concurrent`` must be positive. On cancellation (including the first
    Ctrl-C when using ``asyncio.run``), running jobs are cancelled and awaited
    so their ``finally`` blocks can finish, including asynchronous cleanup.
    Jobs that have not started are left uncalled.

    If a job raises an exception, the other running jobs are cancelled and
    awaited, and ``asyncio.TaskGroup`` propagates an exception group. Jobs
    must cooperate with cancellation and put necessary cleanup in ``finally``
    blocks or asynchronous context managers.
    """
    if max_concurrent <= 0:
        raise ValueError("max_concurrent must be greater than zero")

    pending = iter(tasks)

    async def worker() -> None:
        # Taking the next job has no await, so workers cannot race here.
        for job in pending:
            await job()

    async with asyncio.TaskGroup() as group:
        for _ in range(min(max_concurrent, len(tasks))):
            group.create_task(worker())
