"""Generate a combinational isqrt/Fibonacci circuit for sim.c."""
from pathlib import Path

class Circuit:
    def __init__(self):
        self.lines = [f'out{i} = out{i}' for i in range(32)]
        self.cache = {}
        self.zero = self.emit('0')
        self.one = self.emit('1')

    def emit(self, expr):
        i = len(self.lines)
        self.lines.append(f'out{i} = {expr}')
        return i

    def inv(self, a):
        if a == self.zero: return self.one
        if a == self.one: return self.zero
        key = ('~', a)
        if key not in self.cache:
            b = self.emit(f'~out{a}')
            self.cache[key] = b
            self.cache[('~', b)] = a
        return self.cache[key]

    def op(self, op, a, b):
        if a > b: a, b = b, a
        z, o = self.zero, self.one
        if op == '&':
            if z in (a, b): return z
            if a == o: return b
            if b == o or a == b: return a
        if op == '|':
            if o in (a, b): return o
            if a == z: return b
            if b == z or a == b: return a
        if op == '^':
            if a == b: return z
            if a == z: return b
            if b == z: return a
            if a == o: return self.inv(b)
            if b == o: return self.inv(a)
        key = (op, a, b)
        if key not in self.cache:
            self.cache[key] = self.emit(f'out{a} {op} out{b}')
        return self.cache[key]

    def mux(self, s, yes, no):
        if yes == no: return yes
        return self.op('^', no, self.op('&', s, self.op('^', yes, no)))

    def add(self, a, b, carry=None):
        carry = self.zero if carry is None else carry
        result = []
        for i, (x, y) in enumerate(zip(a, b)):
            t = self.op('^', x, y)
            result.append(self.op('^', t, carry))
            if i + 1 < len(a):
                carry = self.op('|', self.op('&', x, y), self.op('&', t, carry))
        return result

    def sub(self, a, b):
        # The final carry is one exactly when a >= b.
        carry = self.one
        result = []
        for x, y in zip(a, b):
            y = self.inv(y)
            t = self.op('^', x, y)
            result.append(self.op('^', t, carry))
            carry = self.op('|', self.op('&', x, y), self.op('&', t, carry))
        return result, carry

    def mul(self, a, b):
        n = len(a)
        result = [self.zero] * n
        for shift, y in enumerate(b):
            partial = [self.op('&', x, y) for x in a[:n-shift]]
            result = result[:shift] + self.add(result[shift:], partial)
        return result

    def rom(self, selectors, values, width):
        def bit_tree(seq, depth):
            if all(v == seq[0] for v in seq):
                return self.one if seq[0] else self.zero
            half = len(seq) // 2
            no = bit_tree(seq[:half], depth - 1)
            yes = bit_tree(seq[half:], depth - 1)
            return self.mux(selectors[depth], yes, no)
        return [bit_tree([(v >> bit) & 1 for v in values], len(selectors)-1)
                for bit in range(width)]


def fib_pair(n):
    if n == 0: return 0, 1
    a, b = fib_pair(n // 2)
    c = a * (2*b-a) & 0xffffffff
    d = (a*a+b*b) & 0xffffffff
    return (d, (c+d) & 0xffffffff) if n & 1 else (c, d)


def build():
    c = Circuit()
    root, rem = [], [c.zero]
    for stage in range(16):
        # Bring down the next two input bits, most significant pair first.
        pair = 30 - 2*stage
        width = stage + 3
        expanded = [pair, pair+1] + rem
        expanded = (expanded + [c.zero]*width)[:width]
        trial = [c.one, c.zero] + root
        trial += [c.zero] * (width-len(trial))
        diff, ge = c.sub(expanded, trial)
        rem = [c.mux(ge, x, y) for x, y in zip(diff, expanded)][:stage+2]
        root = [ge] + root
    print('after sqrt:', len(c.lines))

    # n = low + 256*high. F(n) = F(low)*F(256*high+1)
    #                            + F(low-1)*F(256*high).
    # F(-1)=1 makes the identity valid for low=0 as well.
    low_values, high_values = [], []
    for i in range(256):
        f, next_f = fib_pair(i)
        low_values.append(f | (((next_f-f) & 0xffffffff) << 32))
        f, next_f = fib_pair(i*256)
        high_values.append(f | (next_f << 32))
    lo = c.rom(root[:8], low_values, 64)
    print('after low ROM:', len(c.lines))
    hi = c.rom(root[8:], high_values, 64)
    print('after high ROM:', len(c.lines))
    result = c.add(c.mul(lo[:32], hi[32:]), c.mul(lo[32:], hi[:32]))
    for bit in result:
        c.emit(f'out{bit}')
    assert len(c.lines) < 32000, len(c.lines)
    Path('/app/gates.txt').write_text('\n'.join(c.lines)+'\n')
    print('total:', len(c.lines))

if __name__ == '__main__':
    build()
