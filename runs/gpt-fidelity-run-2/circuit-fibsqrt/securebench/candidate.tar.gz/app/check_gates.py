"""Check the generated circuit at every square-root transition."""
import math
import random
import subprocess
from pathlib import Path
from build_gates import fib_pair

lines = Path('/app/gates.txt').read_text().splitlines()
assert len(lines) < 32000
ops = []
fanout = [0]*len(lines)
for i, line in enumerate(lines):
    lhs, expr = line.split(' = ')
    assert lhs == f'out{i}'
    parts = expr.split()
    if expr in ('0', '1'):
        ops.append(('const', int(expr), 0))
    elif expr.startswith('~'):
        ops.append(('~', int(expr[4:]), 0))
    elif len(parts) == 1:
        ops.append(('copy', int(expr[3:]), 0))
    else:
        ops.append((parts[1], int(parts[0][3:]), int(parts[2][3:])))
    op, a, b = ops[-1]
    if op != 'const':
        assert a < i or (i < 32 and a == i)
        fanout[a] += 1
        if op in ('&', '|', '^'):
            assert b < i
            fanout[b] += 1
assert max(fanout) <= 10000

fibs = [0, 1]
for i in range(65534):
    fibs.append((fibs[-1]+fibs[-2]) & 0xffffffff)
cases = {0, 1, 2, 208, 20000, 0xffffffff}
for k in range(1, 65536):
    cases.update((k*k-1, k*k, k*k+1))
rng = random.Random(20261112)
cases.update(rng.getrandbits(32) for _ in range(10000))
cases = sorted(cases)
for start in range(0, len(cases), 2048):
    batch = cases[start:start+2048]
    mask = (1 << len(batch))-1
    values = [0]*len(ops)
    for bit in range(32):
        packed = bytearray((len(batch)+7)//8)
        for j, n in enumerate(batch):
            packed[j//8] |= ((n >> bit)&1) << (j%8)
        values[bit] = int.from_bytes(packed, 'little')
    for i in range(32, len(ops)):
        op, a, b = ops[i]
        if op == 'const': values[i] = mask if a else 0
        elif op == 'copy': values[i] = values[a]
        elif op == '~': values[i] = values[a] ^ mask
        elif op == '&': values[i] = values[a] & values[b]
        elif op == '|': values[i] = values[a] | values[b]
        elif op == '^': values[i] = values[a] ^ values[b]
    expected = [fibs[math.isqrt(n)] for n in batch]
    for bit in range(32):
        packed = bytearray((len(batch)+7)//8)
        for j, n in enumerate(expected):
            packed[j//8] |= ((n >> bit)&1) << (j%8)
        assert values[-32+bit] == int.from_bytes(packed, 'little'), (start, bit)
print(f'Circuit passed {len(cases)} cases, including all square boundaries.')
actual_cases = [0, 1, 2, 3, 4, 208, 20000, 0xffffffff, 65535**2-1,
                65535**2, 65535**2+1] + [rng.getrandbits(32) for _ in range(100)]
for n in actual_cases:
    actual = int(subprocess.check_output(['/app/sim', str(n)], cwd='/app'))
    assert actual == fibs[math.isqrt(n)], (n, actual, fibs[math.isqrt(n)])
print(f'Actual simulator passed {len(actual_cases)} cases.')
print(f'{len(lines)} lines; maximum signal fanout {max(fanout)}.')
