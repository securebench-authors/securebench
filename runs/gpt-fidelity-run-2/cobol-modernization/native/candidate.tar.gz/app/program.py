#!/usr/bin/env python3
"""Execute BOOKFORUM using the original fixed-width, binary file formats."""

from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
BALANCE_MODULUS = 10**10


class RecordError(Exception):
    pass


def records(stream, width, buffer):
    """Keep unread bytes of a short record, as GnuCOBOL SEQUENTIAL does."""
    while True:
        offset = stream.tell()
        chunk = stream.read(width)
        if not chunk:
            return
        buffer[:len(chunk)] = chunk
        yield offset, len(chunk) == width


def numeric_move(field):
    # DISPLAY-to-DISPLAY MOVE preserves bytes except spaces and low values.
    return field.replace(b"\x00", b"0").replace(b" ", b"0")


def display_number(field):
    """Decode an unsigned DISPLAY field like GnuCOBOL 3's decimal arithmetic.

    Valid decimal fields are ordinary integers. The extra rules also preserve
    the runtime's behavior for low values, spaces, and other nonnumeric bytes.
    """
    if field[0] == 0:
        return -(10 ** len(field))
    if field[0] == 255:
        return 10 ** len(field)
    start = 0
    while start < len(field) - 1 and field[start] & 15 == 0:
        start += 1
    result = 0
    for char in field[start:]:
        result = (result * 10 + char - ord("0")) & 0xFFFFFFFFFFFFFFFF
    return result


def balance_bytes(cents):
    # No ROUNDED or SIZE ERROR clauses: discard decimals, sign, and overflow.
    value = (abs(cents) // 100) % BALANCE_MODULUS
    return f"{value:010d}".encode("ascii")


def rewrite(stream, offset, buffer, complete, filename):
    if not complete:
        raise RecordError(f"READ must be executed first (status = 43) for {filename}")
    next_offset = stream.tell()
    stream.seek(offset)
    stream.write(buffer)
    stream.seek(next_offset)


def main():
    with (ROOT / "src/INPUT.DAT").open("rb") as stream:
        first = stream.read(22)
    if not first:
        print("Error: Input file is empty")
        return

    # FD record areas initially contain low values, not spaces.
    first = first.ljust(22, b"\x00")
    buyer, seller, book = first[:4], first[4:8], first[8:12]
    amount_field = numeric_move(first[12:22])
    amount_cents = display_number(amount_field + b"00")
    accounts_path = ROOT / "data/ACCOUNTS.DAT"
    books_path = ROOT / "data/BOOKS.DAT"
    account_record = bytearray(34)
    book_record = bytearray(28)
    buyer_found = seller_found = book_found = valid_owner = False

    with accounts_path.open("rb") as stream:
        for _ in records(stream, 34, account_record):
            if account_record[:4] == buyer:
                buyer_found = True
            if account_record[:4] == seller:
                seller_found = True
    with books_path.open("rb") as stream:
        for _ in records(stream, 28, book_record):
            if book_record[:4] == book:
                book_found = True
                if book_record[24:28] == seller:
                    valid_owner = True

    print(" ")
    if not (buyer_found and seller_found and book_found and valid_owner):
        print("Transaction failed due to validation errors")
        return

    with accounts_path.open("r+b") as stream:
        for offset, complete in records(stream, 34, account_record):
            if account_record[:4] == buyer:
                balance = display_number(account_record[24:34]) * 100
                account_record[24:34] = balance_bytes(balance - amount_cents)
                rewrite(stream, offset, account_record, complete, "ACCOUNTS-FILE")
                # A successful REWRITE consumes the preceding READ. If the
                # buyer is also the seller, the second REWRITE fails.
                complete = False
            if account_record[:4] == seller:
                balance = display_number(account_record[24:34]) * 100
                account_record[24:34] = balance_bytes(balance + amount_cents)
                rewrite(stream, offset, account_record, complete, "ACCOUNTS-FILE")

    with books_path.open("r+b") as stream:
        for offset, complete in records(stream, 28, book_record):
            if book_record[:4] == book:
                book_record[24:28] = buyer
                rewrite(stream, offset, book_record, complete, "BOOKS-FILE")

    # OPEN EXTEND on this non-OPTIONAL COBOL file requires it to exist.
    with (ROOT / "data/TRANSACTIONS.DAT").open("r+b") as stream:
        stream.seek(0, 2)
        stream.write(book + amount_field + seller + buyer)
    print("Transaction completed successfully")


if __name__ == "__main__":
    try:
        main()
    except (OSError, RecordError) as error:
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
