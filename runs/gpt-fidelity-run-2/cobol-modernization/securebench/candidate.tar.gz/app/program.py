#!/usr/bin/env python3
"""Implement BOOKFORUM's fixed-record sequential file operations."""

from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
MODULUS = 10**10


class FileStatusError(Exception):
    """A failed COBOL file operation stops the transaction immediately."""


def records(stream, record):
    """READ retains the old buffer's remaining bytes after a short record."""
    width = len(record)
    while True:
        position = stream.tell()
        raw = stream.read(width)
        if not raw:
            return
        record[:len(raw)] = raw
        yield position, len(raw), record


def display_number(raw):
    """GnuCOBOL's unsigned DISPLAY conversion (including blank digits)."""
    value = 0
    for digit in raw:
        value = (value * 10 + (0 if digit in (0, 32, 128, 160) else digit - 48))
        value &= (1 << 64) - 1
    return value


def numeric_move(raw):
    # DISPLAY-to-DISPLAY MOVE replaces spaces and low values with zeroes.
    return bytes(48 if digit in (0, 32) else digit for digit in raw)


def balance_bytes(cents):
    # PIC 9(10) discards the sign, fractional digits, and excess high digits.
    return f"{(abs(cents) // 100) % MODULUS:010d}".encode("ascii")


def rewrite(stream, position, length, record, already_written=False):
    # A short read does not authorize REWRITE; neither does a prior REWRITE.
    if length != len(record) or already_written:
        raise FileStatusError("READ must be executed first (status = 43)")
    stream.seek(position)
    stream.write(record)
    stream.seek(position + length)


def main():
    with (ROOT / "src/INPUT.DAT").open("rb") as stream:
        raw = stream.read(22)
    if not raw:
        print("Error: Input file is empty")
        return

    request = raw.ljust(22, b"\x00")
    buyer, seller, book = request[:4], request[4:8], request[8:12]
    amount_digits = numeric_move(request[12:22])
    amount_cents = display_number(amount_digits + b"00")

    accounts_path = ROOT / "data/ACCOUNTS.DAT"
    books_path = ROOT / "data/BOOKS.DAT"
    account_record = bytearray(34)
    book_record = bytearray(28)
    buyer_found = seller_found = book_found = valid_owner = False
    with accounts_path.open("rb") as stream:
        for _, _, record in records(stream, account_record):
            if record[:4] == buyer:
                buyer_found = True
            if record[:4] == seller:
                seller_found = True
    with books_path.open("rb") as stream:
        for _, _, record in records(stream, book_record):
            if record[:4] == book:
                book_found = True
                if record[24:28] == seller:
                    valid_owner = True

    print(" ")
    if not (buyer_found and seller_found and book_found and valid_owner):
        print("Transaction failed due to validation errors")
        return

    with accounts_path.open("r+b") as stream:
        for position, length, record in records(stream, account_record):
            written = False
            if record[:4] == buyer:
                balance = display_number(record[24:34])
                record[24:34] = balance_bytes(balance * 100 - amount_cents)
                rewrite(stream, position, length, record)
                written = True
            if record[:4] == seller:
                balance = display_number(record[24:34])
                record[24:34] = balance_bytes(balance * 100 + amount_cents)
                rewrite(stream, position, length, record, written)

    with books_path.open("r+b") as stream:
        for position, length, record in records(stream, book_record):
            if record[:4] == book:
                record[24:28] = buyer
                rewrite(stream, position, length, record)

    with (ROOT / "data/TRANSACTIONS.DAT").open("r+b") as stream:
        stream.seek(0, 2)
        stream.write(book + amount_digits + seller + buyer)
    print("Transaction completed successfully")


if __name__ == "__main__":
    try:
        main()
    except (OSError, FileStatusError) as error:
        print(f"File error: {error}", file=sys.stderr)
        sys.exit(1)
