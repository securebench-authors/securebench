from hashlib import sha256
from pathlib import Path

salt = b"0000TBENCH-SALT"
h0 = sha256(Path('/app/code.png').read_bytes()).digest()
result = sha256(h0 + h0[:10] + salt).hexdigest()
assert result.startswith('bee26a'), result
Path('/app/output.txt').write_text(result + '\n')
print(result)
