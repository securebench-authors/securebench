from hashlib import sha256
from pathlib import Path

salt = b"0000TBENCH-SALT"
img_bytes = Path('/app/code.png').read_bytes()
h0 = sha256(img_bytes).digest()
h = sha256(h0 + h0[:10] + salt).hexdigest()
assert h.startswith('bee26a'), h
Path('/app/output.txt').write_text(h + '\n')
print(h)
