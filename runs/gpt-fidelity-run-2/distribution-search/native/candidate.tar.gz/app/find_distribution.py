"""Construct and save a 150,000-token distribution with both KLs equal to 10."""

from pathlib import Path

import numpy as np
from scipy.optimize import root
from scipy.special import logsumexp


VOCAB_SIZE = 150_000
TARGET = 10.0
TOLERANCE = 0.001
OUTPUT = Path("/app/dist.npy")


def find_distribution() -> np.ndarray:
    # Three groups allow two continuous degrees of freedom after normalization.
    # The first eleven tokens carry almost all the mass; the positive tail
    # makes the backward KL finite and independently adjustable.
    sizes = np.array([1, 10, VOCAB_SIZE - 11], dtype=np.int64)

    def group_log_probabilities(parameters: np.ndarray) -> np.ndarray:
        logits = np.array([parameters[0], 0.0, parameters[1]])
        log_masses = logits - logsumexp(logits)
        return log_masses - np.log(sizes)

    def residuals(parameters: np.ndarray) -> np.ndarray:
        log_probabilities = group_log_probabilities(parameters)
        log_ratios = log_probabilities + np.log(VOCAB_SIZE)
        masses = sizes * np.exp(log_probabilities)
        forward = np.dot(masses, log_ratios)
        backward = -np.dot(sizes / VOCAB_SIZE, log_ratios)
        return np.array([forward - TARGET, backward - TARGET])

    solution = root(residuals, np.array([0.0, -9.3]), tol=1e-11)
    if not solution.success:
        raise RuntimeError(f"Solver failed: {solution.message}")

    probabilities = np.repeat(
        np.exp(group_log_probabilities(solution.x)), sizes
    )
    probabilities /= probabilities.sum()
    return probabilities


def validate(probabilities: np.ndarray) -> tuple[float, float]:
    if probabilities.shape != (VOCAB_SIZE,):
        raise ValueError("Incorrect vocabulary size")
    if not np.all(np.isfinite(probabilities)) or np.any(probabilities <= 0):
        raise ValueError("Probabilities must be finite and strictly positive")
    if not np.isclose(probabilities.sum(), 1.0, rtol=0.0, atol=1e-12):
        raise ValueError("Probabilities must sum to one")

    # Natural logarithms measure the divergences in nats.
    log_ratios = np.log(probabilities) + np.log(VOCAB_SIZE)
    forward = float(np.dot(probabilities, log_ratios))
    backward = float(-np.mean(log_ratios))
    if max(abs(forward - TARGET), abs(backward - TARGET)) > TOLERANCE:
        raise ValueError(f"KL targets missed: {forward=}, {backward=}")
    return forward, backward


def main() -> None:
    probabilities = find_distribution()
    validate(probabilities)
    np.save(OUTPUT, probabilities, allow_pickle=False)
    saved = np.load(OUTPUT, allow_pickle=False)
    forward, backward = validate(saved)
    print(f"Saved {OUTPUT} ({saved.size} probabilities)")
    print(f"Sum: {saved.sum():.16f}")
    print(f"KL(P||U): {forward:.12f}")
    print(f"KL(U||P): {backward:.12f}")


if __name__ == "__main__":
    main()
