"""Construct dist.npy with both KL divergences equal to 10 (natural logs)."""

from pathlib import Path

import numpy as np
from scipy.optimize import brentq


VOCAB_SIZE = 150_000
TARGET = 10.0
TOLERANCE = 0.001
OUTPUT_PATH = Path("/app/dist.npy")


def find_distribution() -> np.ndarray:
    # Seven large entries give enough entropy to bracket the forward target.
    # q controls their relative weights; tail_mass controls the backward KL.
    counts = np.array([1, 6, VOCAB_SIZE - 7], dtype=np.int64)

    def group_probabilities(q: float, log_tail_mass: float) -> np.ndarray:
        tail_mass = np.exp(log_tail_mass)
        return np.array(
            [
                (1.0 - tail_mass) * q,
                (1.0 - tail_mass) * (1.0 - q) / 6,
                tail_mass / (VOCAB_SIZE - 7),
            ]
        )

    def solve_tail(q: float) -> float:
        def residual(log_tail_mass: float) -> float:
            probabilities = group_probabilities(q, log_tail_mass)
            backward = -np.sum(
                (counts / VOCAB_SIZE) * np.log(VOCAB_SIZE * probabilities)
            )
            return float(backward - TARGET)

        return brentq(residual, -30.0, -1.0, xtol=1e-13)

    def forward_residual(q: float) -> float:
        probabilities = group_probabilities(q, solve_tail(q))
        forward = np.sum(
            counts * probabilities * np.log(VOCAB_SIZE * probabilities)
        )
        return float(forward - TARGET)

    q = brentq(forward_residual, 1.0 / 7, 0.9, xtol=1e-14)
    probabilities = group_probabilities(q, solve_tail(q))
    distribution = np.repeat(probabilities, counts)
    distribution /= distribution.sum()
    return distribution


def validate(distribution: np.ndarray) -> tuple[float, float]:
    if distribution.shape != (VOCAB_SIZE,):
        raise ValueError("Incorrect vocabulary size")
    if not np.all(np.isfinite(distribution)) or not np.all(distribution > 0):
        raise ValueError("Probabilities must be finite and strictly positive")
    if abs(float(distribution.sum()) - 1.0) > 1e-12:
        raise ValueError("Probabilities must sum to one")

    log_ratio = np.log(VOCAB_SIZE * distribution)
    forward = float(np.sum(distribution * log_ratio))
    backward = float(-np.mean(log_ratio))
    if max(abs(forward - TARGET), abs(backward - TARGET)) > TOLERANCE:
        raise ValueError(f"KL targets not met: {forward=}, {backward=}")
    return forward, backward


if __name__ == "__main__":
    result = find_distribution()
    validate(result)
    np.save(OUTPUT_PATH, result, allow_pickle=False)
    # Verify the actual saved artifact as well.
    forward, backward = validate(np.load(OUTPUT_PATH, allow_pickle=False))
    print(f"Saved {OUTPUT_PATH}")
    print(f"Shape: {result.shape}; sum: {result.sum():.16f}")
    print(f"KL(P||U): {forward:.12f}")
    print(f"KL(U||P): {backward:.12f}")
