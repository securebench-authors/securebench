Primers are written 5′→3′ in primers.fasta. Four primer pairs amplify the four supplied templates separately. This is the minimum for that workflow; encoding inserts in long primer tails would change that assumption.

Each primer includes the 5′ prefix GGCTAC GGTCTC C: six flanking bases, the BsaI recognition site, and a one-base cleavage spacer. The following four bases of the PCR product become its overhang; these can include both added bases and template-derived bases.

Annealing-region temperatures were measured with Primer3 oligotm 2.6.1 using:
oligotm -tp 1 -sc 1 -mv 50 -dv 2 -n 0.8 -d 500 SEQUENCE

| Primer | Annealing sequence (5′→3′) | Annealing length | Tm (°C) |
|---|---|---:|---:|
| input_fwd | TGAGGATCCCGGGAATTCTCG | 21 | 65.084 |
| input_rev | TCATATGTATATCTCCTTCTTAAAGTTAAACAAAATTATTTCTAG | 45 | 63.807 |
| egfp_fwd | ATGAGCAAGGGCGAGGAG | 18 | 63.265 |
| egfp_rev | TTTGTACAGCTCGTCCATGCC | 21 | 64.582 |
| flag_fwd | GGTAGTGGCTCCGGTAGCG | 19 | 66.057 |
| flag_rev | TGAACCACTACCTGAACCAGAACC | 24 | 65.613 |
| snap_fwd | GACAAAGACTGCGAAATGAAGCG | 23 | 64.483 |
| snap_rev | TTAACCCAGCCCAGGCTTAC | 20 | 63.556 |

Junction overhangs, written on the assembled forward strand:
input → egfp: ATGA
egfp → flag: AAGG
flag → snap: TCAG
snap → input: TGAG

All overhangs are distinct, nonpalindromic, and distinct from the reverse complements of the other overhangs. Each simulated PCR product contains exactly two BsaI sites in the correct orientations. The retained fragments have no internal BsaI sites. Simulated digestion and circular ligation reproduce the supplied 3,591-bp output exactly, allowing circular rotation. The design removes the EGFP stop codon, the FLAG start and stop codons, and the SNAP start codon as required by the output. The SNAP stop codon is retained.

NEB design reference:
https://www.neb.com/en/tools-and-resources/usage-guidelines/insert-considerations-when-using-neb-golden-gate-assembly-kit-bsai-hfv2-neb-e1601
NEB enzyme reference (GGTCTC, 1/5 cleavage):
https://www.neb.com/en-us/products/r3733-bsai-hf-v2
