#!/usr/bin/env node
'use strict';

// Decode the initial ELF memory image without executing the input program.
// PIE files use the conventional analysis base 0x400000. Override it with
// --base=0 to obtain the virtual addresses recorded in the ELF headers.
const fs = require('node:fs');

function extract(filename, requestedBase) {
  const file = fs.readFileSync(filename);
  function requireBytes(offset, size) {
    if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(size) ||
        offset < 0 || size < 0 || offset > file.length - size) {
      throw new Error('Invalid or truncated ELF file');
    }
  }
  requireBytes(0, 16);
  if (!file.subarray(0, 4).equals(Buffer.from([127, 69, 76, 70]))) {
    throw new Error('Input must be an ELF binary');
  }
  const wide = file[4] === 2;
  if ((!wide && file[4] !== 1) || ![1, 2].includes(file[5])) {
    throw new Error('Unsupported ELF encoding');
  }
  const little = file[5] === 1;
  function read(offset, size) {
    requireBytes(offset, size);
    if (size === 8) {
      const value = little ? file.readBigUInt64LE(offset) : file.readBigUInt64BE(offset);
      if (value > BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new Error('ELF address exceeds the safe integer range');
      }
      return Number(value);
    }
    return little ? file.readUIntLE(offset, size) : file.readUIntBE(offset, size);
  }
  requireBytes(0, wide ? 64 : 52);
  const type = read(16, 2);
  const base = requestedBase === undefined ? (type === 3 ? 0x400000 : 0) : requestedBase;
  const phoff = read(wide ? 32 : 28, wide ? 8 : 4);
  const phsize = read(wide ? 54 : 42, 2);
  const phcount = read(wide ? 56 : 44, 2);
  const shoff = read(wide ? 40 : 32, wide ? 8 : 4);
  const shsize = read(wide ? 58 : 46, 2);
  const shcount = read(wide ? 60 : 48, 2);
  if (phsize < (wide ? 56 : 32)) throw new Error('Invalid ELF program headers');

  const segments = [];
  for (let i = 0; i < phcount; i++) {
    const p = phoff + i * phsize;
    requireBytes(p, phsize);
    if (read(p, 4) !== 1) continue; // PT_LOAD
    const offset = read(p + (wide ? 8 : 4), wide ? 8 : 4);
    const address = read(p + (wide ? 16 : 8), wide ? 8 : 4);
    const filesz = read(p + (wide ? 32 : 16), wide ? 8 : 4);
    const memsz = read(p + (wide ? 40 : 20), wide ? 8 : 4);
    if (filesz > memsz || !Number.isSafeInteger(base + address + memsz)) {
      throw new Error('Invalid ELF load segment');
    }
    requireBytes(offset, filesz);
    segments.push({ offset, address, filesz, memsz });
  }

  // Relocation destinations are modified by the loader. Omit their words so
  // that external symbol resolution and runtime load addresses cannot produce
  // incorrect values. Everything else comes directly from the memory image.
  const relocatedWords = new Set();
  for (let i = 0; i < shcount; i++) {
    const s = shoff + i * shsize;
    requireBytes(s, wide ? 64 : 40);
    const sectionType = read(s + 4, 4);
    if (sectionType !== 4 && sectionType !== 9) continue; // RELA / REL
    const flags = read(s + 8, wide ? 8 : 4);
    if (!(flags & 2)) continue; // Only runtime (SHF_ALLOC) relocations.
    const offset = read(s + (wide ? 24 : 16), wide ? 8 : 4);
    const size = read(s + (wide ? 32 : 20), wide ? 8 : 4);
    const entrySize = read(s + (wide ? 56 : 36), wide ? 8 : 4);
    const minimumSize = (wide ? 16 : 8) + (sectionType === 4 ? (wide ? 8 : 4) : 0);
    if (entrySize < minimumSize || size % entrySize) {
      throw new Error('Invalid ELF relocation table');
    }
    requireBytes(offset, size);
    for (let j = 0; j < size; j += entrySize) {
      const address = read(offset + j, wide ? 8 : 4);
      for (let byte = 0; byte < (wide ? 8 : 4); byte++) {
        relocatedWords.add(Math.floor((address + byte) / 4) * 4);
      }
    }
  }

  const result = Object.create(null);
  for (const segment of segments) {
    const end = segment.address + segment.memsz;
    for (let address = Math.ceil(segment.address / 4) * 4; address + 4 <= end; address += 4) {
      if (relocatedWords.has(address)) continue;
      let value = 0;
      for (let byte = 0; byte < 4; byte++) {
        const relative = address + byte - segment.address;
        const b = relative < segment.filesz ? file[segment.offset + relative] : 0;
        value += b * 2 ** (8 * (little ? byte : 3 - byte));
      }
      result[String(base + address)] = value;
    }
  }
  return result;
}

try {
  const args = process.argv.slice(2);
  const filename = args.shift();
  if (!filename || args.length > 1 || (args.length && !args[0].startsWith('--base='))) {
    throw new Error('Usage: node extract.js <binary> [--base=0x400000]');
  }
  const base = args.length ? Number(args[0].slice(7)) : undefined;
  if (base !== undefined && (!Number.isSafeInteger(base) || base < 0)) {
    throw new Error('Base must be a nonnegative safe integer');
  }
  process.stdout.write(JSON.stringify(extract(filename, base)) + '\n');
} catch (error) {
  process.stderr.write(`extract.js: ${error.message}\n`);
  process.exitCode = 1;
}
