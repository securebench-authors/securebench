#!/usr/bin/env node
'use strict';

// Extract stable, aligned 32-bit words from an ELF load image. No execution
// of the supplied program or external packages is required.
const fs = require('fs');

function extract(filename) {
  const file = fs.readFileSync(filename);
  if (file.length < 52 || file.subarray(0, 4).toString('hex') !== '7f454c46') {
    throw new Error('Expected an ELF executable');
  }
  const wide = file[4] === 2;
  if ((!wide && file[4] !== 1) || ![1, 2].includes(file[5])) {
    throw new Error('Unsupported ELF class or byte order');
  }
  const little = file[5] === 1;
  function check(offset, size) {
    if (!Number.isSafeInteger(offset) || offset < 0 || offset + size > file.length) {
      throw new Error('Truncated or invalid ELF file');
    }
  }
  function uint(offset, size) {
    check(offset, size);
    if (size === 8) {
      const value = little ? file.readBigUInt64LE(offset) : file.readBigUInt64BE(offset);
      if (value > BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new Error('ELF offset or address exceeds JavaScript integer precision');
      }
      return Number(value);
    }
    return little ? file.readUIntLE(offset, size) : file.readUIntBE(offset, size);
  }
  const wordSize = wide ? 8 : 4;
  const type = uint(16, 2);
  const phoff = uint(wide ? 32 : 28, wordSize);
  const shoff = uint(wide ? 40 : 32, wordSize);
  const phsize = uint(wide ? 54 : 42, 2);
  let phnum = uint(wide ? 56 : 44, 2);
  const shsize = uint(wide ? 58 : 46, 2);
  let shnum = uint(wide ? 60 : 48, 2);
  if (shoff && !shnum) shnum = uint(shoff + (wide ? 32 : 20), wordSize);
  if (phnum === 0xffff) phnum = uint(shoff + (wide ? 44 : 28), 4);

  const segments = [];
  for (let i = 0; i < phnum; i++) {
    const p = phoff + i * phsize;
    check(p, wide ? 56 : 32);
    if (uint(p, 4) !== 1) continue; // PT_LOAD
    const offset = uint(p + (wide ? 8 : 4), wordSize);
    const address = uint(p + (wide ? 16 : 8), wordSize);
    const filesz = uint(p + (wide ? 32 : 16), wordSize);
    const memsz = uint(p + (wide ? 40 : 20), wordSize);
    if (filesz > memsz) throw new Error('Invalid ELF segment sizes');
    check(offset, filesz);
    if (memsz) segments.push({ offset, address, filesz, memsz });
  }
  if (!segments.length) throw new Error('ELF contains no loadable segments');

  // ET_DYN has relative addresses. Use the conventional static-analysis base;
  // ET_EXEC already contains absolute virtual addresses.
  const lowest = Math.min(...segments.map(s => Math.floor(s.address / 4096) * 4096));
  const bias = type === 3 && lowest === 0 ? 0x400000 : 0;
  const memory = new Map();
  for (const segment of segments) {
    const { offset, address, filesz, memsz } = segment;
    // File mappings include the surrounding file-backed page bytes. A BSS
    // extension replaces the bytes after p_filesz with zeroes.
    const start = Math.floor(address / 4096) * 4096;
    const fileEnd = address + filesz;
    const end = memsz > filesz ? address + memsz : Math.ceil(fileEnd / 4096) * 4096;
    for (let a = start; a < end; a++) {
      const position = offset + a - address;
      if (memsz > filesz && a >= fileEnd) {
        memory.set(a + bias, 0);
      } else if (position >= 0 && position < file.length) {
        memory.set(a + bias, file[position]);
      }
    }
  }

  // Loader-written pointers cannot be inferred reliably from the input file.
  // Omit the entire native word touched by each REL, RELA, or RELR entry.
  const excluded = new Set();
  function exclude(address) {
    for (let a = address; a < address + wordSize; a++) {
      excluded.add(Math.floor((a + bias) / 4) * 4);
    }
  }
  for (let i = 0; i < shnum; i++) {
    const s = shoff + i * shsize;
    check(s, wide ? 64 : 40);
    const sectionType = uint(s + 4, 4);
    if (![4, 9, 19].includes(sectionType)) continue;
    const offset = uint(s + (wide ? 24 : 16), wordSize);
    const size = uint(s + (wide ? 32 : 20), wordSize);
    const entrySize = uint(s + (wide ? 56 : 36), wordSize) ||
      (sectionType === 19 ? wordSize : wordSize * (sectionType === 4 ? 3 : 2));
    check(offset, size);
    let next = 0;
    for (let p = offset; p + entrySize <= offset + size; p += entrySize) {
      if (sectionType !== 19) {
        exclude(uint(p, wordSize));
        continue;
      }
      // RELR uses a pointer followed by optional relocation bitmaps.
      const entry = wide
        ? (little ? file.readBigUInt64LE(p) : file.readBigUInt64BE(p))
        : BigInt(uint(p, 4));
      if ((entry & 1n) === 0n) {
        next = Number(entry);
        exclude(next);
        next += wordSize;
      } else {
        for (let bit = 1; bit < wordSize * 8; bit++) {
          if (entry & (1n << BigInt(bit))) exclude(next + (bit - 1) * wordSize);
        }
        next += (wordSize * 8 - 1) * wordSize;
      }
    }
  }

  const result = Object.create(null);
  for (const address of [...memory.keys()].sort((a, b) => a - b)) {
    if (address % 4 || excluded.has(address)) continue;
    if (![1, 2, 3].every(n => memory.has(address + n))) continue;
    const bytes = Buffer.from([0, 1, 2, 3].map(n => memory.get(address + n)));
    const value = little ? bytes.readUInt32LE() : bytes.readUInt32BE();
    // These words have identical values under signed and unsigned int32
    // interpretations, avoiding dependence on the consumer's signedness.
    if (value <= 0x7fffffff) result[String(address)] = value;
  }
  return result;
}

try {
  if (process.argv.length !== 3) throw new Error('Usage: node extract.js <ELF binary>');
  process.stdout.write(JSON.stringify(extract(process.argv[2])) + '\n');
} catch (error) {
  process.stderr.write(`extract.js: ${error.message}\n`);
  process.exitCode = 1;
}
