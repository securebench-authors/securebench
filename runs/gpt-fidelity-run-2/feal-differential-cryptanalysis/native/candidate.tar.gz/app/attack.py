"""Chosen-plaintext recovery of the final FEAL round key."""

import random


def _f(value):
    """The cipher's F function, with byte operations written out directly."""
    x0 = value & 255
    x1 = (value >> 8) & 255
    x2 = (value >> 16) & 255
    x3 = (value >> 24) & 255

    t = ((x3 ^ x2) + (x1 ^ x0) + 1) & 255
    y2 = ((t << 2) | (t >> 6)) & 255
    t = (x3 + y2) & 255
    y3 = ((t << 2) | (t >> 6)) & 255
    t = ((x1 ^ x0) + y2) & 255
    y1 = ((t << 2) | (t >> 6)) & 255
    t = (x0 + y1 + 1) & 255
    y0 = ((t << 2) | (t >> 6)) & 255
    return y0 | (y1 << 8) | (y2 << 16) | (y3 << 24)


def attack(encrypt_fn):
    """Return key[5] using only an oracle accepting 64-bit plaintext integers.

    For each (D, E) below, F(x) XOR F(x XOR D) = E for every x.
    Choose plaintext differences (E, E XOR D). After whitening and
    pre-round mixing, the state difference is (E, D). The first three
    rounds change this to (D, 0), (0, D), and (D, E), respectively.

    The ciphertext exposes R3 = L4 as C_left XOR C_right. Thus a candidate
    last key k must satisfy

        F(R3 XOR k) XOR F(R3' XOR k) = C_left XOR C_left' XOR D.

    Filter the 16-bit-seed keyspace with independent pairs until one key
    remains. Different differentials constrain different key bytes.
    """
    candidates = [(seed * 1234567) & 0xFFFFFFFF for seed in range(1 << 16)]
    differentials = (
        (0x80800000, 0x02000000),
        (0x00008080, 0x00000002),
        (0x80808080, 0x02000002),
    )
    # A local generator makes the queries reproducible without modifying
    # the oracle's random state (which may also be used to generate keys).
    rng = random.Random(0xFEA14)
    pair_index = 0
    while len(candidates) > 1:
        d, e = differentials[pair_index % len(differentials)]
        pair_index += 1
        plaintext = rng.getrandbits(64)
        paired_plaintext = plaintext ^ (e << 32) ^ (e ^ d)
        ciphertext = int(encrypt_fn(plaintext))
        paired_ciphertext = int(encrypt_fn(paired_plaintext))

        r3 = (ciphertext ^ (ciphertext >> 32)) & 0xFFFFFFFF
        paired_r3 = (paired_ciphertext ^ (paired_ciphertext >> 32)) & 0xFFFFFFFF
        target = (ciphertext >> 32) ^ (paired_ciphertext >> 32) ^ d
        candidates = [
            k for k in candidates
            if _f(r3 ^ k) ^ _f(paired_r3 ^ k) == target
        ]
        if not candidates:
            raise ValueError("Oracle does not match the FEAL cipher and key derivation")

    return candidates[0]
