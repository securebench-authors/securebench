"""Chosen-plaintext recovery of the last FEAL round key."""

from random import getrandbits


def _f(value):
    """The cipher's F function, with its little-endian byte ordering."""
    x0 = value & 255
    x1 = (value >> 8) & 255
    x2 = (value >> 16) & 255
    x3 = (value >> 24) & 255

    t = ((x3 ^ x2) + (x1 ^ x0) + 1) & 255
    y2 = ((t << 2) | (t >> 6)) & 255
    t = (x3 + y2) & 255
    y3 = ((t << 2) | (t >> 6)) & 255
    t = ((x1 ^ x0) + y2) & 255
    y1 = ((t << 2) | (t >> 6)) & 255
    t = (x0 + y1 + 1) & 255
    y0 = ((t << 2) | (t >> 6)) & 255
    return y0 | (y1 << 8) | (y2 << 16) | (y3 << 24)


def attack(encrypt_fn):
    """Return key[5] using pairs of chosen 64-bit integer plaintexts.

    F(x ^ alpha) ^ F(x) = beta for alpha = 0x80800000 and
    beta = 0x02000000. Choosing equal alpha differences in both
    plaintext halves gives these differences after initial mixing
    and the first three rounds:

        (alpha, 0) -> (0, alpha) -> (alpha, beta) -> (beta, *)

    Thus the last round must satisfy
        F(R3 ^ k) ^ F(R3' ^ k) = R4 ^ R4' ^ beta.
    The ciphertext exposes R4 in its upper half and R3 ^ R4 in
    its lower half, so every term except the candidate key is known.
    """
    candidates = [(seed * 1234567) & 0xFFFFFFFF
                  for seed in range(1 << 16)]
    while len(candidates) > 1:
        plaintext = getrandbits(64)
        c0 = encrypt_fn(plaintext)
        c1 = encrypt_fn(plaintext ^ 0x8080000080800000)
        r4 = c0 >> 32
        r4_prime = c1 >> 32
        r3 = (c0 & 0xFFFFFFFF) ^ r4
        r3_prime = (c1 & 0xFFFFFFFF) ^ r4_prime
        expected = r4 ^ r4_prime ^ 0x02000000
        candidates = [k for k in candidates
                      if _f(r3 ^ k) ^ _f(r3_prime ^ k) == expected]
        if not candidates:
            raise ValueError("Oracle does not match the FEAL cipher/key schedule")
    return candidates[0]
