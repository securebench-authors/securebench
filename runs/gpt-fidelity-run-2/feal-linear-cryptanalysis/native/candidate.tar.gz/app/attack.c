/* Known-plaintext linear attack on the four-round cipher in feal.c.
 *
 * Write the Feistel states as X[-1]=P_left, X[0]=P_left^P_right,
 * X[i+1]=X[i-1]^F(X[i]^K[i]). Ciphertext reveals X[3] and X[4].
 * F has four exact relations parity(B & F(x)) = parity(A & x)^c:
 *       A          B          c
 *   01010101   00040000       1
 *   01000000   04010000       0
 *   00000101   00010400       0
 *   00000001   00000104       1
 * These follow from the low bit of each addition before rotation by 2.
 * XOR the same relation across rounds i and i+2 to cancel X[i+1]:
 * B.(X[i-1]^X[i+3]) ^ A.(X[i]^X[i+2]) = A.(K[i]^K[i+2]).
 * For i=0, guess K3 to obtain X2; for i=1, guess K0 to obtain X1.
 * Each right-hand side is constant across all known pairs. This filters
 * the outer seeds independently. Full middle-round equations then recover
 * K1 and K2, and all known pairs verify the resulting complete key.
 */
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#define SPACE (1u<<20)
#define MAX_PAIRS 1024
static uint64_t plain[MAX_PAIRS], cipher[MAX_PAIRS];
static uint32_t xm[MAX_PAIRS], x0[MAX_PAIRS], x3[MAX_PAIRS], x4[MAX_PAIRS];
static unsigned n;
static uint32_t expand_seed(uint32_t s) { return s ^ (s<<16) ^ (s*12345u); }
static uint8_t g(unsigned a,unsigned b,unsigned c) {
    unsigned t=(a+b+c)&255; return (uint8_t)((t<<2)|(t>>6));
}
static uint32_t f(uint32_t v) {
    unsigned a=v&255,b=(v>>8)&255,c=(v>>16)&255,d=v>>24;
    unsigned z=g(d^c,b^a,1), w=g(d,z,0), y=g(b^a,z,0), x=g(a,y,1);
    return x|(y<<8)|(z<<16)|(w<<24);
}
static unsigned sa(uint32_t x) {
    unsigned a=x&1,b=(x>>8)&1,c=(x>>16)&1,d=x>>24&1;
    return (a^b^c^d)|(d<<1)|((a^b)<<2)|(a<<3);
}
static unsigned sb(uint32_t x) {
    return ((x>>18)&1)|((((x>>26)^(x>>16))&1)<<1)
        |((((x>>10)^(x>>16))&1)<<2)|((((x>>2)^(x>>8))&1)<<3);
}
static uint64_t encrypt(uint64_t p,const uint32_t *k) {
    uint32_t l=p>>32,r=(uint32_t)p^l;
    for(unsigned j=0;j<4;j++){uint32_t t=r;r=l^f(r^k[j]);l=t;}
    return ((uint64_t)r<<32)|(l^r);
}
static uint64_t decrypt(uint64_t c,const uint32_t *k) {
    uint32_t r=c>>32,l=(uint32_t)c^r;
    for(int j=3;j>=0;j--){uint32_t t=l;l=r^f(l^k[j]);r=t;}
    return ((uint64_t)l<<32)|(r^l);
}
static unsigned outer(unsigned which,uint32_t *out) {
    unsigned count=0;
    for(uint32_t s=0;s<SPACE;s++) {
        uint32_t k=expand_seed(s); unsigned expected=0; int ok=1;
        for(unsigned i=0;i<n;i++) {
            unsigned v=which==0
                ? sa(f(x0[i]^k)^xm[i]^x3[i])^sb(x0[i]^x4[i])
                : sa(f(x3[i]^k)^x4[i]^x0[i])^sb(xm[i]^x3[i]);
            if(i==0) expected=v; else if(v!=expected){ok=0;break;}
        }
        if(ok) out[count++]=s;
    }
    return count;
}
int main(int argc,char **argv) {
    if(argc!=4){fprintf(stderr,"Usage: %s pairs.txt ciphertexts.txt plaintexts.txt\n",argv[0]);return 1;}
    FILE *in=fopen(argv[1],"r"); if(!in){perror(argv[1]);return 1;}
    while(n<MAX_PAIRS && fscanf(in,"%"SCNu64" %"SCNu64,&plain[n],&cipher[n])==2){
        xm[n]=plain[n]>>32;x0[n]=(uint32_t)plain[n]^xm[n];
        x4[n]=cipher[n]>>32;x3[n]=(uint32_t)cipher[n]^x4[n]; n++;
    }
    fclose(in);if(n<2){fprintf(stderr,"Need at least two known pairs\n");return 1;}
    uint32_t *c0=malloc(SPACE*sizeof(uint32_t)), *c3=malloc(SPACE*sizeof(uint32_t));
    if(!c0||!c3)return 1;
    unsigned n0=outer(0,c0),n3=outer(3,c3);
    fprintf(stderr,"Linear filters: %u first-round seeds, %u last-round seeds\n",n0,n3);
    uint32_t recovered[4]={0}, seeds[4]={0}; unsigned found=0;
    for(unsigned a=0;a<n0;a++)for(unsigned b=0;b<n3;b++){
        uint32_t k0=expand_seed(c0[a]),k3=expand_seed(c3[b]);
        uint32_t x1[MAX_PAIRS],x2[MAX_PAIRS];
        for(unsigned i=0;i<n;i++){x1[i]=xm[i]^f(x0[i]^k0);x2[i]=x4[i]^f(x3[i]^k3);}
        for(uint32_t s1=0;s1<SPACE;s1++){
            uint32_t k1=expand_seed(s1); unsigned i;
            for(i=0;i<n;i++)if((x0[i]^f(x1[i]^k1))!=x2[i])break;
            if(i!=n)continue;
            for(uint32_t s2=0;s2<SPACE;s2++){
                uint32_t k2=expand_seed(s2);
                for(i=0;i<n;i++)if((x1[i]^f(x2[i]^k2))!=x3[i])break;
                if(i!=n)continue;
                uint32_t k[4]={k0,k1,k2,k3};
                for(i=0;i<n;i++)if(encrypt(plain[i],k)!=cipher[i]||decrypt(cipher[i],k)!=plain[i])break;
                if(i!=n)continue;
                found++; seeds[0]=c0[a];seeds[1]=s1;seeds[2]=s2;seeds[3]=c3[b];
                for(i=0;i<4;i++)recovered[i]=k[i];
                fprintf(stderr,"Recovered seeds: %05x %05x %05x %05x\n",seeds[0],seeds[1],seeds[2],seeds[3]);
                fprintf(stderr,"Expanded keys: %08x %08x %08x %08x\n",k0,k1,k2,k3);
            }
        }
    }
    if(found!=1){fprintf(stderr,"Expected unique solution, found %u\n",found);return 1;}
    fprintf(stderr,"Verified encryption and decryption of all %u known pairs\n",n);
    in=fopen(argv[2],"r");if(!in){perror(argv[2]);return 1;}
    FILE *out=fopen(argv[3],"w");if(!out){perror(argv[3]);fclose(in);return 1;}
    uint64_t c;unsigned count=0;
    while(fscanf(in,"%"SCNu64,&c)==1){uint64_t p=decrypt(c,recovered);
        if(encrypt(p,recovered)!=c){fprintf(stderr,"Round-trip failure\n");return 1;}
        fprintf(out,"%"PRIu64"\n",p);count++;
    }
    if(!feof(in)){fprintf(stderr,"Malformed ciphertext input\n");return 1;}
    fclose(in);fclose(out);free(c0);free(c3);
    fprintf(stderr,"Decrypted and round-trip verified %u ciphertexts into %s\n",count,argv[3]);
    return 0;
}
