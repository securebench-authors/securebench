/* Known-plaintext attack on the four-round cipher in feal.c.
 * Build: cc -O3 -std=c11 attack.c -o attack
 * Run:   ./attack [pairs.txt [ciphertexts.txt [plaintexts.txt]]]
 *
 * Write the Feistel recurrence as X[i+2] = X[i] ^ F(X[i+1]^K[i]).
 * Then X0=P_hi, X1=P_hi^P_lo, X4=C_hi^C_lo, X5=C_hi.
 *
 * Each (a,b) below obeys parity(b & F(x)) = parity(a & x) ^ c.
 * Applying the same identity to rounds 0 and 2 eliminates X2:
 *   b.(X0^X4) ^ a.(X1^X3) = a.(K0^K2).
 * Guessing K3 gives X3=X5^F(X4^K3), so the left side must be
 * constant across all pairs. Similarly, rounds 1 and 3 give
 *   b.(X1^X5) ^ a.(X2^X4) = a.(K1^K3),
 * which tests guesses of K0. Constants c cancel in both equations.
 * After recovering the outer keys, test the middle seeds against
 * the full 32-bit round equations and verify complete encryption.
 */
#define main feal_command_main
#include "feal.c"
#undef main
#include <inttypes.h>

#define SEEDS (1u << 20)
#define MAX_PAIRS 4096
typedef struct { uint64_t p, c; uint32_t x[6]; } Pair;
static Pair pairs[MAX_PAIRS];
static size_t count;
static const uint32_t amask[4] = {
    0x01010101, 0x00000101, 0x01000000, 0x00000001
};
static const uint32_t bmask[4] = {
    0x00040000, 0x00010400, 0x04010000, 0x00000104
};

static unsigned signature(uint32_t a, uint32_t b) {
    unsigned result = 0;
    for (unsigned j = 0; j < 4; ++j)
        result |= (__builtin_parity(a & amask[j]) ^
                   __builtin_parity(b & bmask[j])) << j;
    return result;
}

static size_t outer_candidates(unsigned round, uint32_t *out) {
    size_t n = 0;
    for (uint32_t seed = 0; seed < SEEDS; ++seed) {
        uint32_t k = expand(seed);
        unsigned reference = 0;
        size_t i;
        for (i = 0; i < count; ++i) {
            uint32_t *x = pairs[i].x;
            unsigned s;
            if (round == 3) {
                uint32_t x3 = x[5] ^ f_function(x[4] ^ k);
                s = signature(x[1] ^ x3, x[0] ^ x[4]);
            } else {
                uint32_t x2 = x[0] ^ f_function(x[1] ^ k);
                s = signature(x2 ^ x[4], x[1] ^ x[5]);
            }
            if (i == 0) reference = s;
            else if (s != reference) break;
        }
        if (i == count) out[n++] = seed;
    }
    fprintf(stderr, "Round %u: %zu seed candidates\n", round, n);
    return n;
}

static size_t middle_candidates(unsigned round, uint32_t *out) {
    size_t n = 0;
    for (uint32_t seed = 0; seed < SEEDS; ++seed) {
        uint32_t k = expand(seed);
        size_t i;
        for (i = 0; i < count; ++i) {
            uint32_t *x = pairs[i].x;
            if (f_function(x[round + 1] ^ k) !=
                (x[round] ^ x[round + 2])) break;
        }
        if (i == count) out[n++] = seed;
    }
    return n;
}

static uint64_t decrypt_block(uint64_t c) {
    uint32_t l = getright(c) ^ getleft(c), r = getleft(c);
    for (int i = 3; i >= 0; --i) {
        uint32_t old_r = l;
        l = r ^ f_function(l ^ key[i]);
        r = old_r;
    }
    return merge(l, r ^ l);
}

int main(int argc, char **argv) {
    const char *pair_path = argc > 1 ? argv[1] : "pairs.txt";
    const char *cipher_path = argc > 2 ? argv[2] : "ciphertexts.txt";
    const char *plain_path = argc > 3 ? argv[3] : "plaintexts.txt";
    FILE *fp = fopen(pair_path, "r");
    if (!fp) { perror(pair_path); return 1; }
    while (count < MAX_PAIRS &&
           fscanf(fp, "%" SCNu64 " %" SCNu64,
                  &pairs[count].p, &pairs[count].c) == 2) {
        Pair *p = &pairs[count++];
        p->x[0] = getleft(p->p);
        p->x[1] = getleft(p->p) ^ getright(p->p);
        p->x[4] = getleft(p->c) ^ getright(p->c);
        p->x[5] = getleft(p->c);
    }
    fclose(fp);
    if (count < 2) { fprintf(stderr, "Need at least two pairs\n"); return 1; }
    uint32_t *candidates[4];
    for (unsigned i = 0; i < 4; ++i) {
        candidates[i] = malloc(SEEDS * sizeof(uint32_t));
        if (!candidates[i]) { perror("malloc"); return 1; }
    }
    size_t n0 = outer_candidates(0, candidates[0]);
    size_t n3 = outer_candidates(3, candidates[3]);
    unsigned solutions = 0;
    uint32_t recovered[4] = {0};
    for (size_t a = 0; a < n0; ++a) {
        uint32_t s0 = candidates[0][a];
        for (size_t i = 0; i < count; ++i)
            pairs[i].x[2] = pairs[i].x[0] ^
                f_function(pairs[i].x[1] ^ expand(s0));
        for (size_t b = 0; b < n3; ++b) {
            uint32_t s3 = candidates[3][b];
            for (size_t i = 0; i < count; ++i)
                pairs[i].x[3] = pairs[i].x[5] ^
                    f_function(pairs[i].x[4] ^ expand(s3));
            size_t n1 = middle_candidates(1, candidates[1]);
            if (!n1) continue;
            size_t n2 = middle_candidates(2, candidates[2]);
            for (size_t d = 0; d < n1; ++d)
                for (size_t e = 0; e < n2; ++e) {
                    uint32_t seeds[4] = {s0, candidates[1][d],
                                         candidates[2][e], s3};
                    set_keys(seeds[0], seeds[1], seeds[2], seeds[3]);
                    size_t i;
                    for (i = 0; i < count; ++i)
                        if (encrypt(pairs[i].p) != pairs[i].c ||
                            decrypt_block(pairs[i].c) != pairs[i].p) break;
                    if (i != count) continue;
                    ++solutions;
                    for (unsigned j = 0; j < 4; ++j) recovered[j] = seeds[j];
                    fprintf(stderr, "Verified seeds: %05x %05x %05x %05x\n",
                            seeds[0], seeds[1], seeds[2], seeds[3]);
                }
        }
    }
    if (solutions != 1) {
        fprintf(stderr, "Expected one key; found %u\n", solutions);
        return 1;
    }
    set_keys(recovered[0], recovered[1], recovered[2], recovered[3]);
    fprintf(stderr, "Expanded keys: %08x %08x %08x %08x\n",
            key[0], key[1], key[2], key[3]);
    fprintf(stderr, "Verified all %zu known pairs\n", count);
    fp = fopen(cipher_path, "r");
    if (!fp) { perror(cipher_path); return 1; }
    FILE *out = fopen(plain_path, "w");
    if (!out) { perror(plain_path); fclose(fp); return 1; }
    uint64_t c;
    size_t decrypted = 0;
    while (fscanf(fp, "%" SCNu64, &c) == 1) {
        uint64_t p = decrypt_block(c);
        if (encrypt(p) != c) { fprintf(stderr, "Roundtrip failed\n"); return 1; }
        fprintf(out, "%" PRIu64 "\n", p);
        ++decrypted;
    }
    fclose(fp);
    if (fclose(out)) { perror(plain_path); return 1; }
    for (unsigned i = 0; i < 4; ++i) free(candidates[i]);
    fprintf(stderr, "Decrypted %zu ciphertexts to %s\n", decrypted, plain_path);
    return 0;
}
