The recovered 20-bit seeds, in round order, are:

```
68e63 62571 1f61c b74a5
```

Their expanded round keys are:

```
b24dca68 0d14a358 a888fa20 5cc59c18
```

Reproduce the attack and regenerate the decimal plaintext file with:

```sh
cd /app
cc -O3 -std=c11 -Wall -Wextra attack.c -o attack
./attack pairs.txt ciphertexts.txt plaintexts.txt
```

The attack uses exact linear relations, rather than statistical biases.
Let `a.x` denote the parity of `a & x`. The round function satisfies
`b.F(x) = a.x XOR c` for these masks (bit zero is the least significant bit):

| a | b | c |
| --- | --- | --- |
| 01010101 | 00040000 | 1 |
| 00000101 | 00010400 | 0 |
| 01000000 | 04010000 | 0 |
| 00000001 | 00000104 | 1 |

These identities follow because bit 2 of a byte rotated left by two
equals bit 0 of its pre-rotation sum, and addition's bit 0 is XOR.

Write the rounds as `X[i+2] = X[i] XOR F(X[i+1] XOR K[i])`.
The plaintext provides `X0=P_hi`, `X1=P_hi XOR P_lo`; the ciphertext
provides `X4=C_hi XOR C_lo`, `X5=C_hi`.
Combining the identities from rounds 0 and 2 eliminates the unknown X2:

```
b.(X0 XOR X4) XOR a.(X1 XOR X3) = a.(K0 XOR K2)
```

For each of the 2^20 possible K3 seeds, compute
`X3=X5 XOR F(X4 XOR K3)` and require the left side to remain constant
over all known pairs, for all four mask pairs. Exactly one seed survives.
Similarly, guessing K0 gives `X2=X0 XOR F(X1 XOR K0)`, and

```
b.(X1 XOR X5) XOR a.(X2 XOR X4) = a.(K1 XOR K3)
```

selects exactly one K0 seed. The full round equations then test each
20-bit middle seed independently:

```
F(X2 XOR K1) = X1 XOR X3
F(X3 XOR K2) = X2 XOR X4
```

Thus the attack performs four separate searches of 2^20 seeds, with
early rejection, instead of enumerating the combined 80-bit keyspace.
It verifies the unique full key against all 32 known pairs in both
directions and writes all 100 decrypted targets to `plaintexts.txt`.
Independent verification using the supplied `feal` executable and a
fresh build of `decrypt.c` matched every known pair and every output line.
