#!/usr/bin/env python3
"""Remove active content from an HTML document without reserializing its markup.

Usage: python /app/filter.py document.html

Only source spans are deleted. Unchanged bytes, including whitespace, character
references, attribute quoting, and line endings, are preserved. Intended for
standalone documents served as text/html, not XML or JavaScript/template input.
Requires html5lib 1.1 (python -m pip install html5lib==1.1). External
documents and scripts already running in a host page are outside the scope
of a static HTML filter.
"""

from __future__ import annotations

import codecs
from dataclasses import dataclass
import html
from pathlib import Path
import re
import sys

try:
    from html5lib import HTMLParser
    from html5lib._tokenizer import HTMLTokenizer
    from html5lib.constants import tokenTypes
except ImportError:
    raise SystemExit("filter.py requires html5lib: python -m pip install html5lib==1.1")


SPACE = "\t\n\f\r "
# These elements can load another executable document or legacy plug-in.
EMBEDDED = {"iframe", "frame", "object", "embed", "applet"}
ANIMATION = {"animate", "animatecolor", "animatemotion", "animatetransform", "set", "discard"}
URL_ATTRIBUTES = {
    "href", "src", "action", "formaction", "background", "poster", "data",
    "codebase", "classid", "archive", "dynsrc", "lowsrc", "manifest",
    "profile", "cite", "longdesc", "usemap", "icon", "xlink:href",
    "xml:base", "ping", "srcset", "imagesrcset",
}
SAFE_DATA = re.compile(
    r"^data:(?:image/(?:png|gif|jpe?g|webp|avif|bmp|x-icon)|"
    r"audio/(?:mpeg|ogg|wav|webm)|video/(?:mp4|ogg|webm));base64,"
    r"[a-z0-9+/=]*$", re.I,
)
CSS_ESCAPE = re.compile(r"\\(?:([0-9a-fA-F]{1,6})(?:\r\n|[\t\n\f\r ])?|([^\r\n\f]))")
CSS_COMMENTS = re.compile(r"/\*.*?(?:\*/|$)", re.S)
CSS_DANGEROUS = re.compile(
    r"expression\s*\(|(?:java|vb)script\s*:|data\s*:|"
    r"(?:-moz-binding|behavior)\s*:", re.I,
)


@dataclass
class Attribute:
    start: int
    end: int
    name: str
    value: str


@dataclass
class Tag:
    start: int
    end: int
    name: str
    closing: bool
    self_closing: bool
    attributes: list[Attribute]


def ascii_lower(value: str) -> str:
    return value.translate(str.maketrans("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"))


def read_tag(source: str, start: int) -> Tag | None:
    """Read HTML tag/attribute syntax, retaining exact source positions.

    In particular, a slash separates attributes but not an unquoted value;
    quotes only start a quoted value immediately after an equals sign.
    """
    size = len(source)
    pos = start + 1
    closing = pos < size and source[pos] == "/"
    if closing:
        pos += 1
    if pos >= size or source[pos] not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
        return None
    name_start = pos
    while pos < size and source[pos] not in SPACE + "/>":
        pos += 1
    name = ascii_lower(source[name_start:pos])
    attributes = []
    self_closing = False
    while pos < size:
        if source[pos] in SPACE:
            pos += 1
            continue
        if source[pos] == ">":
            return Tag(start, pos + 1, name, closing, self_closing, attributes)
        if source[pos] == "/":
            self_closing = pos + 1 < size and source[pos + 1] == ">"
            pos += 1
            continue
        attr_start = pos
        # An initial '=' belongs to the name in the HTML tokenizer.
        pos += 1
        while pos < size and source[pos] not in SPACE + "/>=":
            pos += 1
        attr_name = ascii_lower(source[attr_start:pos])
        name_end = pos
        while pos < size and source[pos] in SPACE:
            pos += 1
        value = ""
        attr_end = name_end
        if pos < size and source[pos] == "=":
            pos += 1
            while pos < size and source[pos] in SPACE:
                pos += 1
            if pos < size and source[pos] in "\"'":
                quote = source[pos]
                pos += 1
                value_start = pos
                while pos < size and source[pos] != quote:
                    pos += 1
                value = source[value_start:pos]
                if pos < size:
                    pos += 1
            else:
                value_start = pos
                while pos < size and source[pos] not in SPACE + ">":
                    pos += 1
                value = source[value_start:pos]
            attr_end = pos
        attributes.append(Attribute(attr_start, attr_end, attr_name, value))
    # An incomplete tag produces no element in a standalone HTML document.
    return Tag(start, size, name, closing, self_closing, attributes)


def decoded(value: str) -> str:
    return html.unescape(value)


def unsafe_url(value: str, *, allow_media: bool = False, url_list: bool = False) -> bool:
    value = ascii_lower(decoded(value))
    # URL parsing ignores tabs/newlines within schemes and leading controls.
    compact = "".join(c for c in value if ord(c) > 32 and ord(c) != 127)
    if compact.startswith("data:"):
        return not (allow_media and SAFE_DATA.fullmatch(compact))
    # URL-list attributes can contain multiple candidates. Ordinary URLs are
    # checked only at the start, preserving harmless path/query text.
    pattern = r"(?:javascript|vbscript|livescript|mocha):|data:"
    return bool(re.search(pattern if url_list else "^(?:" + pattern + ")", compact))


def unsafe_css(value: str) -> bool:
    def replace_escape(match: re.Match[str]) -> str:
        if match[1]:
            codepoint = int(match[1], 16)
            return chr(codepoint) if 0 < codepoint <= 0x10FFFF else "\ufffd"
        return match[2]

    value = re.sub(r"\\(?:\r\n|[\r\n\f])", "", value)
    value = CSS_COMMENTS.sub("", value)
    value = CSS_ESCAPE.sub(replace_escape, value)
    value = CSS_COMMENTS.sub("", value)
    value = "".join(c for c in value if ord(c) >= 32 or c in SPACE)
    compact = "".join(c for c in value if c not in SPACE)
    # Raster/audio/video data cannot create an executable document here.
    media_pattern = SAFE_DATA.pattern.removeprefix("^").removesuffix("$")
    compact = re.sub(media_pattern, "", compact, flags=re.I)
    return bool(CSS_DANGEROUS.search(compact))


class SourceTokenizer(HTMLTokenizer):
    """HTML5 tokens with positions in the unnormalized original source.

    The tree builder drives tokenizer state, so apparent tags in textarea,
    comments, script strings, and foreign content are treated as browsers do.
    """

    def __init__(self, source: str, parser: HTMLParser):
        super().__init__(source, parser=parser)
        self.source = source
        self.line_starts = [0]
        for match in re.finditer(r"\r\n|\r|\n", source):
            self.line_starts.append(match.end())
        self.tags: list[tuple[Tag, dict]] = []
        self.tag_start = 0
        self.comment_removals: list[tuple[int, int]] = []

    def __iter__(self):
        for token in super().__iter__():
            if (token["type"] == tokenTypes["Comment"]
                    and re.search(r"\[\s*if\b", token["data"], re.I)):
                self.comment_removals.append((self.tag_start, self.offset()))
            yield token

    def offset(self) -> int:
        line, column = self.stream.position()
        return self.line_starts[line - 1] + column

    def tagOpenState(self):
        self.tag_start = self.offset() - 1
        return super().tagOpenState()

    def closeTagOpenState(self):
        self.tag_start = self.offset() - 2
        return super().closeTagOpenState()

    def rawtextEndTagOpenState(self):
        self.tag_start = self.offset() - 2
        return super().rawtextEndTagOpenState()

    def rcdataEndTagOpenState(self):
        self.tag_start = self.offset() - 2
        return super().rcdataEndTagOpenState()

    def scriptDataEndTagOpenState(self):
        self.tag_start = self.offset() - 2
        return super().scriptDataEndTagOpenState()

    def scriptDataEscapedEndTagOpenState(self):
        self.tag_start = self.offset() - 2
        return super().scriptDataEscapedEndTagOpenState()

    def markupDeclarationOpenState(self):
        # html5lib 1.1 predates the browser rule that CDATA at HTML/MathML
        # integration points is a bogus comment rather than foreign text.
        elements = self.parser.tree.openElements
        if elements and self.source.startswith("[CDATA[", self.offset()):
            node = elements[-1]
            if (self.parser.isHTMLIntegrationPoint(node)
                    or self.parser.isMathMLTextIntegrationPoint(node)):
                self.state = self.bogusCommentState
                return True
        return super().markupDeclarationOpenState()

    def emitCurrentToken(self):
        if self.currentToken["type"] in {tokenTypes["StartTag"], tokenTypes["EndTag"]}:
            tag = read_tag(self.source, self.tag_start)
            if tag is None or tag.end != self.offset():
                # Never write a partially sanitized file if offsets disagree.
                raise ValueError("Could not locate an HTML token in the source")
            # Keep the token object: the tree builder acknowledges self-closing
            # tags only where a browser actually honors the closing slash.
            self.tags.append((tag, self.currentToken))
        return super().emitCurrentToken()


class SourceParser(HTMLParser):
    def __init__(self):
        super().__init__()
        foreign_phase = type(self.phases["inForeignContent"])

        class CurrentForeignPhase(foreign_phase):
            def processEndTag(self, token):
                # Current browsers break out of foreign content for these end
                # tags. html5lib 1.1 only implements start-tag breakouts.
                if token["name"] in {"br", "p"}:
                    while (self.tree.openElements[-1].namespace != self.tree.defaultNamespace
                           and not self.parser.isHTMLIntegrationPoint(self.tree.openElements[-1])
                           and not self.parser.isMathMLTextIntegrationPoint(self.tree.openElements[-1])):
                        self.tree.openElements.pop()
                    return token
                return super().processEndTag(token)

        self.phases["inForeignContent"] = CurrentForeignPhase(self, self.tree)

    def _parse(self, stream, innerHTML=False, container="div", scripting=True, **kwargs):
        self.innerHTMLMode = innerHTML
        self.container = container
        self.scripting = scripting
        self.tokenizer = SourceTokenizer(stream, parser=self)
        self.reset()
        self.mainLoop()


def _sanitize_once(source: str) -> str:
    parser = SourceParser()
    parser.parse(source, scripting=True)
    removals = list(parser.tokenizer.comment_removals)
    # Paired active elements and style blocks need their original body spans.
    pending: dict[str, list[Tag]] = {}
    paired = {"script", "iframe", "applet", "style"}
    for tag, token in parser.tokenizer.tags:
        name = tag.name
        if name in paired:
            if tag.closing:
                stack = pending.get(name, [])
                if stack:
                    opening = stack.pop()
                    if name != "style" or unsafe_css(source[opening.end:tag.start]):
                        removals.append((opening.start, tag.end))
                elif name != "style":
                    removals.append((tag.start, tag.end))
            elif tag.self_closing and token.get("selfClosingAcknowledged"):
                if name != "style":
                    removals.append((tag.start, tag.end))
            else:
                pending.setdefault(name, []).append(tag)
        if name in (EMBEDDED | ANIMATION) - {"iframe", "applet"}:
            removals.append((tag.start, tag.end))
        if tag.closing:
            continue
        attrs = {attr.name: decoded(attr.value) for attr in reversed(tag.attributes)}
        if name == "meta" and ascii_lower(attrs.get("http-equiv", "").strip()) in {
            "refresh", "set-cookie",
        }:
            removals.append((tag.start, tag.end))
            continue
        if name == "link" and "import" in ascii_lower(attrs.get("rel", "")).split():
            removals.append((tag.start, tag.end))
            continue
        for attr in tag.attributes:
            bad = attr.name.startswith("on") or attr.name in {
                "srcdoc", "datasrc", "datafld", "dataformatas",
            }
            if attr.name in URL_ATTRIBUTES:
                bad |= unsafe_url(
                    attr.value,
                    allow_media=name in {"img", "audio", "video", "source"} and attr.name == "src",
                    url_list=attr.name in {"ping", "srcset", "imagesrcset", "archive"},
                )
            if attr.name == "style":
                bad |= unsafe_css(decoded(attr.value))
            if bad:
                removals.append((attr.start, attr.end))
    for name, stack in pending.items():
        for opening in stack:
            if name != "style" or unsafe_css(source[opening.end:]):
                removals.append((opening.start, len(source)))
    if not removals:
        return source
    pieces = []
    previous = 0
    for start, end in sorted(removals):
        if start > previous:
            pieces.append(source[previous:start])
        previous = max(previous, end)
    pieces.append(source[previous:])
    return "".join(pieces)


def sanitize(source: str) -> str:
    """Delete unsafe spans, including markup newly exposed by those deletions."""
    while True:
        result = _sanitize_once(source)
        if result == source:
            return result
        source = result


def filter_bytes(data: bytes) -> bytes:
    # Latin-1 is a reversible byte mapping for UTF-8 and legacy ASCII-compatible
    # encodings. UTF-16/32 need decoding so their ASCII syntax can be recognized.
    for bom, encoding in (
        (codecs.BOM_UTF32_LE, "utf-32-le"),
        (codecs.BOM_UTF32_BE, "utf-32-be"),
        (codecs.BOM_UTF16_LE, "utf-16-le"),
        (codecs.BOM_UTF16_BE, "utf-16-be"),
    ):
        if data.startswith(bom):
            return bom + sanitize(data[len(bom):].decode(encoding)).encode(encoding)
    if data.startswith((b"<\x00\x00\x00", b"\x00\x00\x00<")):
        encoding = "utf-32-le" if data[0] else "utf-32-be"
    elif data.startswith((b"<\x00", b"\x00<")):
        encoding = "utf-16-le" if data[0] else "utf-16-be"
    else:
        encoding = "latin-1"
    return sanitize(data.decode(encoding)).encode(encoding)


def main() -> int:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} HTML_FILE", file=sys.stderr)
        return 2
    try:
        path = Path(sys.argv[1])
        original = path.read_bytes()
        result = filter_bytes(original)
        if result != original:
            # r+b preserves the existing file's permissions and inode.
            with path.open("r+b") as handle:
                handle.write(result)
                handle.truncate()
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"{sys.argv[0]}: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
