#!/usr/bin/env python3
"""Remove active content from an HTML file without reserializing its markup.

Only deletions are made. Text, whitespace, quoting, attribute order, line endings,
and the original encoding are otherwise retained. This targets HTML documents in
modern browsers; it is not a sanitizer for JavaScript, XML, or template languages.
"""

import codecs
import html
import re
import sys
from dataclasses import dataclass
from pathlib import Path


SPACE = " \t\n\r\f"
SAFE_TAGS = frozenset("""
    a abbr acronym address area article aside audio b bdi bdo big blink blockquote
    base body br button caption center cite code col colgroup data datalist dd del
    details dfn dialog dir div dl dt em fieldset figcaption figure font footer
    form h1 h2 h3 h4 h5 h6 head header hgroup hr html i img image input ins kbd
    label legend li link listing main map mark marquee menu meta meter nav nobr
    ol optgroup option output p param
    picture plaintext pre progress q rb rp rt rtc ruby s samp search section select
    slot small source span strike strong style sub summary sup table tbody td
    template textarea tfoot th thead time title tr track tt u ul var video wbr xmp
""".split())
# Foreign content and embedded documents have additional parsing/execution rules.
DROP_CONTENT = frozenset("""
    script iframe object embed applet frame frameset portal fencedframe
    svg math noscript noembed noframes
""".split())
VOID_TAGS = frozenset("area base br col embed frame hr img image input link meta param source track wbr".split())
RAW_TEXT = frozenset("script style iframe xmp noembed noframes noscript textarea title".split())
URL_ATTRIBUTES = frozenset("""
    href src action formaction background poster cite longdesc usemap profile
    manifest data codebase classid archive dynsrc lowsrc xlink:href xml:base
""".split())
SAFE_SCHEMES = frozenset("http https ftp ftps mailto tel sms news nntp irc ircs xmpp cid geo magnet".split())
CSS_ESCAPE = re.compile(r"\\([0-9a-fA-F]{1,6})(?:\r\n|[ \t\r\n\f])?|\\([^\r\n\f])|\\(?:\r\n|[\r\n\f])")


@dataclass
class Attribute:
    name: str
    value: str
    start: int
    end: int


@dataclass
class Tag:
    name: str
    start: int
    end: int
    closing: bool
    self_closing: bool
    attributes: list


def read_tag(source, start):
    """Read HTML tag/attribute boundaries, including malformed attribute syntax."""
    size = len(source)
    pos = start + 1
    closing = pos < size and source[pos] == "/"
    if closing:
        pos += 1
    if pos >= size or not ("a" <= source[pos].lower() <= "z" and source[pos].isascii()):
        return None
    name_start = pos
    while pos < size and source[pos] not in SPACE + "/>":
        pos += 1
    name = source[name_start:pos].lower()
    attributes = []
    while pos < size:
        while pos < size and source[pos] in SPACE:
            pos += 1
        if pos >= size:
            return None  # Browsers do not emit a tag that ends at EOF.
        if source[pos] == ">":
            return Tag(name, start, pos + 1, closing, False, attributes)
        if source[pos] == "/":
            pos += 1
            if pos < size and source[pos] == ">":
                return Tag(name, start, pos + 1, closing, True, attributes)
            continue
        attr_start = pos
        # An initial '=' is part of a malformed attribute's name.
        pos += 1
        while pos < size and source[pos] not in SPACE + "=/>":
            pos += 1
        attr_name = source[attr_start:pos].lower()
        name_end = pos
        while pos < size and source[pos] in SPACE:
            pos += 1
        value = ""
        attr_end = name_end
        if pos < size and source[pos] == "=":
            pos += 1
            while pos < size and source[pos] in SPACE:
                pos += 1
            if pos < size and source[pos] in "\"'":
                quote = source[pos]
                pos += 1
                value_start = pos
                end = source.find(quote, pos)
                if end == -1:
                    return None
                value = source[value_start:end]
                pos = end + 1
            else:
                value_start = pos
                while pos < size and source[pos] not in SPACE + ">":
                    pos += 1
                value = source[value_start:pos]
            attr_end = pos
        attributes.append(Attribute(attr_name, value, attr_start, attr_end))
    return None


def comment_end(source, start):
    pos = start + 4
    if source.startswith(">", pos):
        return pos + 1
    if source.startswith("->", pos):
        return pos + 2
    match = re.search(r"--!?>", source[pos:])
    return pos + match.end() if match else len(source)


def raw_end(source, start, name):
    # HTML raw-text/RCDATA end tags require a delimiter after the exact name.
    pattern = re.compile(r"</" + re.escape(name) + r"(?=[\t\n\f\r />])", re.I | re.ASCII)
    for match in pattern.finditer(source, start):
        tag = read_tag(source, match.start())
        if tag is not None:
            return tag
    return None


def drop_end(source, tag):
    if tag.name in VOID_TAGS or (tag.name in {"svg", "math"} and tag.self_closing):
        return tag.end
    if tag.name in RAW_TEXT:
        end = raw_end(source, tag.end, tag.name)
        return end.end if end else len(source)
    # Track nested foreign/embedded elements. Ignore apparent tags in comments
    # and raw-text elements while finding the corresponding end tag.
    depth = 1
    pos = tag.end
    while pos < len(source):
        start = source.find("<", pos)
        if start < 0:
            break
        if source.startswith("<!--", start):
            pos = comment_end(source, start)
            continue
        child = read_tag(source, start)
        if child is None:
            pos = start + 1
            continue
        pos = child.end
        if child.name == tag.name:
            if child.closing:
                depth -= 1
                if depth == 0:
                    return child.end
            elif not (child.self_closing and child.name in {"svg", "math"}):
                depth += 1
        elif not child.closing and child.name in RAW_TEXT:
            end = raw_end(source, child.end, child.name)
            pos = end.end if end else len(source)
    return len(source)


def unsafe_url(value, image=False):
    value = html.unescape(value)
    # URL parsers ignore tabs/newlines, and trim controls around a URL. Removing
    # controls throughout also catches deliberately obfuscated scheme names.
    value = "".join(c for c in value if ord(c) > 32 and not 127 <= ord(c) <= 159 and c != "\ufffd")
    match = re.match(r"^([^/:?#]+):", value)
    if not match:
        return False
    scheme = match.group(1).lower()
    if image and scheme == "data":
        return not re.match(r"data:image/(?:png|gif|jpe?g|webp|avif|bmp|x-icon);base64,", value, re.I)
    return scheme not in SAFE_SCHEMES


def unsafe_css(value):
    value = html.unescape(value)
    # Strip comments before and after escape decoding (both orders are useful
    # for detecting deliberately broken-up legacy executable CSS).
    value = re.sub(r"/\*.*?(?:\*/|$)", "", value, flags=re.S)

    def decode(match):
        if match.group(1):
            number = int(match.group(1), 16)
            return chr(number) if 0 < number <= 0x10ffff else "\ufffd"
        return match.group(2) or ""

    value = CSS_ESCAPE.sub(decode, value)
    value = re.sub(r"/\*.*?(?:\*/|$)", "", value, flags=re.S)
    compact = "".join(c for c in value.lower() if not c.isspace() and ord(c) > 31)
    if any(token in compact for token in ("expression(", "javascript:", "vbscript:", "-moz-binding", "behavior:")):
        return True
    # Check CSS URLs too: in particular, data SVG/HTML and other active schemes.
    for match in re.finditer(r"url\s*\(\s*([^)]*)", value, re.I):
        if unsafe_url(match.group(1).strip().strip("\"'"), image=True):
            return True
    return False


def unsafe_attribute(tag, attribute):
    name, value = attribute.name, attribute.value
    if name.startswith("on") or name.rsplit(":", 1)[-1].startswith("on"):
        return True
    if name in {"srcdoc", "is", "xmlns", "xmlns:xlink"}:
        return True
    if name == "style":
        return unsafe_css(value)
    if name in URL_ATTRIBUTES:
        return unsafe_url(value, image=(tag.name in {"img", "image"} and name == "src"))
    if name in {"srcset", "imagesrcset"}:
        # Keep commas inside data URLs; whitespace also separates descriptors.
        # Checking descriptors conservatively catches comma-joined candidates.
        decoded = html.unescape(value)
        return any(unsafe_url(part.strip(","), image=True)
                   for part in decoded.split() if part.strip(","))
    if name == "ping":
        return any(unsafe_url(part) for part in html.unescape(value).split())
    return False


def sanitize_once(source):
    removals = []
    pos = 0
    in_select = False
    template_select_states = []
    while pos < len(source):
        start = source.find("<", pos)
        if start < 0:
            break
        if source.startswith("<!--", start):
            pos = comment_end(source, start)
            # Conditional comments can contain executable markup in old IE.
            if re.match(r"<!--\s*\[if\b", source[start:pos], re.I):
                removals.append((start, pos))
            continue
        if source.startswith(("<!", "<?"), start):
            # In HTML these are declarations or bogus comments. A doctype is
            # harmless; retaining their bytes avoids changing document mode.
            end = source.find(">", start + 2)
            pos = end + 1 if end >= 0 else len(source)
            continue
        tag = read_tag(source, start)
        if tag is None:
            pos = start + 1
            continue
        pos = tag.end
        if tag.name in DROP_CONTENT:
            if not tag.closing:
                pos = drop_end(source, tag)
            removals.append((start, pos))
            continue
        if tag.name not in SAFE_TAGS:
            # Remove unknown/obsolete elements but keep surrounding content.
            removals.append((start, pos))
            continue
        if tag.name == "meta" and any(
            a.name == "http-equiv" and html.unescape(a.value).strip().lower()
            in {"refresh", "set-cookie"} for a in tag.attributes
        ):
            removals.append((start, pos))
            continue
        if tag.name == "link" and any(
            a.name == "rel" and "import" in html.unescape(a.value).lower().split()
            for a in tag.attributes
        ):
            removals.append((start, pos))
            continue
        # Browsers differ on text-mode elements inside select (newer engines
        # support customizable selects). Removing these ambiguous wrappers
        # makes subsequent text-mode boundaries consistent across engines.
        if in_select and tag.name in {"style", "title", "xmp", "plaintext"}:
            removals.append((start, pos))
            continue
        for attribute in tag.attributes:
            if unsafe_attribute(tag, attribute):
                removals.append((attribute.start, attribute.end))
        # Templates establish their own insertion context and restore it when
        # closed. Track selects for the ambiguous text-mode wrappers above.
        if tag.name == "template":
            if not tag.closing:
                template_select_states.append(in_select)
                in_select = False
            elif template_select_states:
                in_select = template_select_states.pop()
        elif tag.name == "select":
            in_select = False if tag.closing else not in_select
        elif not tag.closing and tag.name in {"input", "textarea"}:
            in_select = False
        if not tag.closing and tag.name == "plaintext" and not in_select:
            break
        if not tag.closing and tag.name in RAW_TEXT and not in_select:
            end = raw_end(source, pos, tag.name)
            content_end = end.start if end else len(source)
            if tag.name == "style" and unsafe_css(source[pos:content_end]):
                removals.append((start, end.end if end else len(source)))
            pos = end.end if end else len(source)
    if not removals:
        return source
    chunks = []
    pos = 0
    for start, end in sorted(removals):
        if start > pos:
            chunks.append(source[pos:start])
        pos = max(pos, end)
    chunks.append(source[pos:])
    return "".join(chunks)


def sanitize(source):
    """Reach a fixed point so deletions cannot assemble fresh active markup."""
    while True:
        cleaned = sanitize_once(source)
        if cleaned == source:
            return source
        source = cleaned


def filter_file(filename):
    path = Path(filename)
    original = path.read_bytes()
    # Latin-1 provides a reversible byte-to-character mapping for ASCII-compatible
    # encodings. UTF-16 BOMs require decoding so markup is recognized correctly.
    if original.startswith(codecs.BOM_UTF16_LE):
        encoding = "utf-16-le"
    elif original.startswith(codecs.BOM_UTF16_BE):
        encoding = "utf-16-be"
    else:
        encoding = "latin-1"
    source = original.decode(encoding, errors="surrogatepass")
    cleaned = sanitize(source).encode(encoding, errors="surrogatepass")
    if cleaned != original:
        path.write_bytes(cleaned)


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} HTML_FILE", file=sys.stderr)
        return 2
    try:
        filter_file(sys.argv[1])
    except (OSError, UnicodeError) as error:
        print(f"{sys.argv[0]}: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
