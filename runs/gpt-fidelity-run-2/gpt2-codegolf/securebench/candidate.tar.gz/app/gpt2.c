/* GPT-2 124M flat float32 TF tensors in lexical order; glibc C.UTF-8. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <wctype.h>
#include <locale.h>
#define D 768
#define H 131071
float *w,x[D],y[3072],q[2304],z[D],a[1024],k[12][1024][D],v[12][1024][D];
char *s[50257];
int ht[H+1],pt[H+1],L[50257],R[50257],bt[256],raw[256],nt,tok[1024];
int dict(char *s0,int add){unsigned h=0;for(unsigned char *p=(void*)s0;*p;p++)h=h*33+*p;h&=H;while(ht[h]&&strcmp(s[ht[h]-1],s0))h=(h+1)&H;if(!ht[h]&&add)s[nt]=strdup(s0),ht[h]=++nt;return ht[h]-1;}
int pair(int b,int c,int add){unsigned h=(b*997u+c)&H;while(pt[h]&&(L[pt[h]]!=b||R[pt[h]]!=c))h=(h+1)&H;if(add)pt[h]=add;return pt[h]?pt[h]:60000;}
int num(char **p){int r=0,m=1,b;do{b=*(*p)++;b-=33+(b>34)+(b>92);r+=b%45*m;m*=45;}while(b>44);return r;}
int cat(wchar_t c){char *p="{$&<&3,'($0PBL|$Lb&LV+Ll$L&<b$Ll$Ll$L$<d$X#i$L*@]$L^$@)q#c$LU$Ll$Li#u#{'Li#L|1u#j50^'L(L8Ln(Lv$P#n%L(LQ&Ly#L|$L(Ly6&I&c#(%<(Lb&j&$8U2a'<o&!O$O0p$s@([3(;H00l)4R%L@D#a#BLIa#`j0LW&LT)<c%LHLb&L8Ly#LP+Lnf,L{,Q&.T'3,j)d$F4?(*(|$8f&Lz6D;@IHn#88<i%,$e#$U&c#HV#,@0n#8^$D:DK@_)<R#Lh(t$g%LL4f$@|$p$v$L_#LX%L)u#j'Lk)Ll$L^*L[$L[$T#_+q#R$Lv2l$Q'Li#La+L[$y#p9y+xu*Ly#L|$L#@q3S$tm.u#.u#b$[$m:f&lV#La+LV-Ll7Hv$Lj3]'#0#4o#Q&#a#a7X#Ea$(a$(a$V^#LT_@`Y#";int a=0,n;while(*p){a+=num(&p);n=num(&p);if(c<a)break;if(c<a+n/4)return n%4;a+=n/4;}return iswspace(c)?0:iswdigit(c)?2:iswalpha(c)&&!iswctype(c,wctype("combining"))?1:3;}
int cls(char *p,int *n){wchar_t c;*n=mbtowc(&c,p,4);if(*n<1)*n=1,c=(unsigned char)*p;return cat(c);}
void emit(int t){if(t<256)putchar(raw[t]);else if(t<50256)emit(L[t]),emit(R[t]);else fputs("<|endoftext|>",stdout);}
void norm(float *o,float *b,float *g){float m=0,r=0;for(int i=0;i<D;i++)m+=x[i]/D;for(int i=0;i<D;i++)r+=(x[i]-m)*(x[i]-m)/D;r=1/sqrtf(r+1e-5f);for(int i=0;i<D;i++)o[i]=(x[i]-m)*r*g[i]+b[i];}
void mul(float *o,float *in,float *b,float *m,int n,int d){memcpy(o,b,d*4);for(int i=0;i<n;i++)for(int j=0;j<d;j++)o[j]+=in[i]*m[i*d+j];}
int step(int t,int p){float *f=w+12*7087872,*e=f+1536+1024*D;for(int i=0;i<D;i++)x[i]=e[t*D+i]+f[1536+p*D+i];for(int l=0;l<12;l++){
 int u=l<2?l:l<10?l+2:l-8;float *b=w+u*7087872,*c=b+2304+768*2304,*n=c+768+768*768,*m=n+3072;
 norm(y,n,n+768);mul(q,y,b,b+2304,D,2304);memcpy(k[l][p],q+D,D*4);memcpy(v[l][p],q+2*D,D*4);
 for(int h=0;h<12;h++){float top=-1e30f,sum=0;for(int j=0;j<=p;j++){float r=0;for(int i=0;i<64;i++)r+=q[h*64+i]*k[l][j][h*64+i];a[j]=r/8;if(a[j]>top)top=a[j];}for(int j=0;j<=p;j++)sum+=(a[j]=expf(a[j]-top));for(int i=0;i<64;i++){float r=0;for(int j=0;j<=p;j++)r+=a[j]/sum*v[l][j][h*64+i];z[h*64+i]=r;}}
 mul(y,z,c,c+768,D,D);for(int i=0;i<D;i++)x[i]+=y[i];norm(z,n+1536,n+2304);mul(y,z,m,m+3072,D,3072);for(int i=0;i<3072;i++){float r=y[i];y[i]=.5f*r*(1+tanhf(.7978845608f*(r+.044715f*r*r*r)));}m+=3072+768*3072;mul(z,y,m,m+768,3072,D);for(int i=0;i<D;i++)x[i]+=z[i];}
 norm(y,f,f+768);int best=0;float top=-1e30f;for(int j=0;j<50257;j++){float r=0;for(int i=0;i<D;i++)r+=y[i]*e[j*D+i];if(r>top)top=r,best=j;}return best;}
int main(int argc,char **argv){if(argc!=4)return fprintf(stderr,"usage: %s weights.ckpt vocab.bpe prompt\n",argv[0]),1;setlocale(LC_CTYPE,"C.UTF-8");FILE *f=fopen(argv[1],"rb");w=malloc(497759232);if(!f||!w||fread(w,4,124439808,f)!=124439808)return fputs("Cannot read GPT-2 124M float32 weights\n",stderr),1;fclose(f);
 char b[4096],c[4096];int extra=256;for(int i=0;i<256;i++)bt[i]=(i<33||(i>126&&i<161)||i==173)?extra++:i;
 for(int pass=0;pass<2;pass++)for(int i=0;i<256;i++)if((bt[i]!=i)==pass){int u=bt[i];if(u<128)b[0]=u,b[1]=0;else b[0]=192+(u>>6),b[1]=128+(u&63),b[2]=0;raw[nt]=i;dict(b,1);}
 for(int i=0;i<256;i++)bt[raw[i]]=i;
 f=fopen(argv[2],"r");if(!f||!fgets(b,sizeof b,f))return 1;for(int i=256;i<50256;i++){if(fscanf(f,"%2047s %2047s",b,c)!=2)return 1;L[i]=dict(b,0);R[i]=dict(c,0);if(L[i]<0||R[i]<0)return 1;strcat(b,c);dict(b,1);pair(L[i],R[i],i);}fclose(f);
 int count=0;char *p=argv[3];while(*p){char *start=p,*last=p;int n,kind=cls(p,&n),used=0;char *suffix[]={"'s","'t","'re","'ve","'m","'ll","'d"};for(int i=0;i<7;i++)if(!strncmp(p,suffix[i],strlen(suffix[i]))){p+=strlen(suffix[i]);used=1;break;}if(!used){if(*p==' '&&p[1]&&cls(p+1,&n))p++;kind=cls(p,&n);do{last=p;p+=n;}while(*p&&cls(p,&n)==kind);if(!kind&&*p&&last>start)p=last;}
 int *ids=malloc((p-start)*sizeof(int)),len=0;if(!ids)return 1;while(start<p)ids[len++]=bt[(unsigned char)*start++];for(;;){int best=60000,at=0;for(int i=0;i<len-1;i++){int r=pair(ids[i],ids[i+1],0);if(r<best)best=r,at=i;}if(best==60000)break;ids[at]=best;memmove(ids+at+1,ids+at+2,(len-at-2)*sizeof(int));len--;}if(count+len>1005)return fputs("Prompt exceeds context\n",stderr),1;memcpy(tok+count,ids,len*sizeof(int));count+=len;free(ids);}
 if(!count)tok[count++]=50256;
 fputs(argv[3],stdout);int next=0;for(int i=0;i<count+19;i++){next=step(i<count?tok[i]:next,i);if(i>=count-1){emit(next);fflush(stdout);}}putchar('\n');return 0;}
