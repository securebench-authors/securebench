"""An interactive Bash session attached to a headless pseudo-terminal."""

import errno
import fcntl
import os
import pty
import select
import shutil
import signal
import struct
import termios
import threading
import time
from codecs import getincrementaldecoder
from typing import Mapping, Optional

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """Run interactive Bash with normal terminal input and job control.

    ``send_keystrokes("echo hello\n")`` types and executes a command. Control
    characters and escape sequences are passed through unchanged. Output is
    continuously drained, including while no method is being called, and can
    be retrieved with ``read_output``. Output contains the terminal's original
    echo, carriage returns, and ANSI escape sequences.

    Bash inherits the current environment (with any supplied overrides), and
    reads its usual interactive startup files, including ~/.bashrc. Use a
    context manager or call ``close`` to release the session.
    """

    def __init__(
        self,
        cwd: Optional[str] = None,
        env: Optional[Mapping[str, str]] = None,
        rows: int = 24,
        cols: int = 80,
    ) -> None:
        self._validate_size(rows, cols)
        child_env = os.environ.copy()
        if env is not None:
            child_env.update(env)
        child_env.setdefault("TERM", "xterm-256color")
        shell = shutil.which("bash", path=child_env.get("PATH"))
        if shell is None:
            raise FileNotFoundError("Bash is required for HeadlessTerminal")
        if cwd is not None:
            cwd = os.path.abspath(os.fspath(cwd))
            if not os.path.isdir(cwd):
                raise NotADirectoryError(cwd)

        self._lock = threading.RLock()
        self._output_condition = threading.Condition()
        self._output = []
        self._eof = False
        self._closed = False
        self._reaped = False
        self.returncode = None
        self._stop = threading.Event()

        # fork() here gives Bash a controlling terminal and a new session;
        # simply connecting subprocess pipes does not provide job control.
        pid, master_fd = pty.fork()
        if pid == 0:
            try:
                fcntl.ioctl(0, termios.TIOCSWINSZ,
                            struct.pack("HHHH", rows, cols, 0, 0))
                if cwd is not None:
                    os.chdir(cwd)
                os.execve(shell, ["bash", "-i"], child_env)
            except BaseException as exc:
                os.write(2, ("Unable to start Bash: %s\r\n" % exc).encode())
                os._exit(127)

        self.pid = pid
        self._master_fd = master_fd
        self._reader = threading.Thread(
            target=self._read_loop, name="headless-terminal-reader", daemon=True
        )
        self._reader.start()

    @staticmethod
    def _validate_size(rows: int, cols: int) -> None:
        if not (isinstance(rows, int) and isinstance(cols, int)
                and 0 < rows <= 65535 and 0 < cols <= 65535):
            raise ValueError("rows and cols must be integers between 1 and 65535")

    def _read_loop(self) -> None:
        decoder = getincrementaldecoder("utf-8")("replace")
        try:
            while not self._stop.is_set():
                ready, _, _ = select.select([self._master_fd], [], [], 0.05)
                if not ready:
                    continue
                try:
                    data = os.read(self._master_fd, 65536)
                except OSError as exc:
                    if exc.errno in (errno.EIO, errno.EBADF):
                        break
                    raise
                if not data:
                    break
                decoded = decoder.decode(data)
                if decoded:
                    with self._output_condition:
                        self._output.append(decoded)
                        self._output_condition.notify_all()
        finally:
            with self._output_condition:
                self._output.append(decoder.decode(b"", final=True))
                self._eof = True
                self._output_condition.notify_all()

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        """Type UTF-8 text, then optionally wait; no newline is added.

        For example, ``\x03`` sends Ctrl-C, ``\x04`` sends Ctrl-D, and
        ``\x1b[A`` sends the up arrow. Waiting does not imply command completion.
        """
        if not isinstance(keystrokes, str):
            raise TypeError("keystrokes must be a string")
        if wait_sec < 0:
            raise ValueError("wait_sec must be nonnegative")
        data = keystrokes.encode("utf-8")
        with self._lock:
            if self._closed or not self.is_alive:
                raise RuntimeError("The terminal session has ended")
            # os.write may accept fewer bytes than requested, especially for
            # large pastes. The reader runs independently to avoid deadlock.
            while data:
                try:
                    written = os.write(self._master_fd, data)
                except OSError as exc:
                    raise RuntimeError("The terminal session has ended") from exc
                data = data[written:]
        if wait_sec:
            time.sleep(wait_sec)

    def read_output(self, wait_sec: float = 0.0) -> str:
        """Consume buffered output, waiting up to wait_sec if it is empty."""
        if wait_sec < 0:
            raise ValueError("wait_sec must be nonnegative")
        with self._output_condition:
            self._output_condition.wait_for(
                lambda: bool(self._output) or self._eof, timeout=wait_sec
            )
            result = "".join(self._output)
            self._output.clear()
            return result

    @property
    def is_alive(self) -> bool:
        """Whether the Bash process is still running."""
        with self._lock:
            if not self._reaped:
                pid, status = os.waitpid(self.pid, os.WNOHANG)
                if pid:
                    self._reaped = True
                    self.returncode = os.waitstatus_to_exitcode(status)
            return not self._reaped

    def resize(self, rows: int, cols: int) -> None:
        """Resize the terminal; the foreground program receives SIGWINCH."""
        self._validate_size(rows, cols)
        with self._lock:
            if self._closed:
                raise RuntimeError("The terminal is closed")
            fcntl.ioctl(self._master_fd, termios.TIOCSWINSZ,
                        struct.pack("HHHH", rows, cols, 0, 0))

    def close(self) -> None:
        """End the session, reap Bash, and release the pseudo-terminal."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            for sig in (signal.SIGHUP, signal.SIGTERM, signal.SIGKILL):
                if not self.is_alive:
                    break
                try:
                    os.killpg(self.pid, sig)
                except ProcessLookupError:
                    pass
                deadline = time.monotonic() + 0.3
                while self.is_alive and time.monotonic() < deadline:
                    time.sleep(0.01)
            if not self._reaped:
                _, status = os.waitpid(self.pid, 0)
                self.returncode = os.waitstatus_to_exitcode(status)
                self._reaped = True
            self._stop.set()
            self._reader.join()
            os.close(self._master_fd)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
