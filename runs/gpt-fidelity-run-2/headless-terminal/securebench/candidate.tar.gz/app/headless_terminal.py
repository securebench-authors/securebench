"""An interactive Bash terminal backed by a POSIX pseudoterminal."""

import codecs
import errno
import fcntl
import math
import os
import pty
import select
import shutil
import signal
import struct
import termios
import threading
import time

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """Run interactive Bash with a controlling terminal and normal startup files.

    Input is literal terminal input: ``\n`` or ``\r`` presses Enter,
    ``\x03`` presses Ctrl-C, and ``\x04`` presses Ctrl-D. Escape sequences
    (for example ``\x1b[A`` for Up) are passed through unchanged. Output
    includes terminal echo and ANSI escapes; use :meth:`read_output` to read it.

    Use as a context manager or call ``close()`` when finished. This class
    requires POSIX and Bash; it has no third-party dependencies.
    """

    def __init__(self, *, cwd=None, env=None, rows=24, columns=80):
        shell = shutil.which("bash")
        if shell is None:
            raise FileNotFoundError("bash is required")
        if not (1 <= rows <= 65535 and 1 <= columns <= 65535):
            raise ValueError("rows and columns must be between 1 and 65535")
        working_directory = os.path.abspath(cwd) if cwd is not None else None
        if working_directory is not None and not os.path.isdir(working_directory):
            raise NotADirectoryError(working_directory)
        environment = os.environ.copy()
        environment.setdefault("TERM", "xterm-256color")
        if env is not None:
            environment.update(env)

        self._lock = threading.RLock()
        self._output_lock = threading.Lock()
        self._output = ""
        self._closed = False
        self._status = None
        self._stop = threading.Event()
        self._pid, self._fd = pty.fork()
        if self._pid == 0:
            try:
                fcntl.ioctl(0, termios.TIOCSWINSZ,
                            struct.pack("HHHH", rows, columns, 0, 0))
                if working_directory is not None:
                    os.chdir(working_directory)
                os.execve(shell, [shell, "-i"], environment)
            except BaseException:
                os.write(2, b"Failed to start interactive bash\n")
                os._exit(127)

        # A nonblocking master and a continuous reader keep verbose commands
        # from filling the PTY buffer and blocking the shell.
        os.set_blocking(self._fd, False)
        self._reader = threading.Thread(target=self._drain, daemon=True)
        self._reader.start()

    def _drain(self):
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        try:
            while not self._stop.is_set():
                if not select.select([self._fd], [], [], 0.05)[0]:
                    continue
                try:
                    data = os.read(self._fd, 65536)
                except BlockingIOError:
                    continue
                except OSError as exc:
                    if exc.errno == errno.EIO:  # Slave has closed on Linux.
                        break
                    raise
                if not data:
                    break
                self._append_output(decoder.decode(data))
        finally:
            self._append_output(decoder.decode(b"", final=True))

    def _append_output(self, text):
        with self._output_lock:
            # Bound retained scrollback while always draining the terminal.
            self._output = (self._output + text)[-1_000_000:]

    @property
    def is_running(self):
        """Whether the Bash process is still running (also reaps its exit)."""
        with self._lock:
            if self._status is None:
                pid, status = os.waitpid(self._pid, os.WNOHANG)
                if pid:
                    self._status = status
            return self._status is None

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        """Send UTF-8 input verbatim, then wait for ``wait_sec`` seconds.

        Waiting does not imply command completion: interactive commands can
        remain active until further input arrives.
        """
        if not isinstance(keystrokes, str):
            raise TypeError("keystrokes must be a string")
        if not math.isfinite(wait_sec) or wait_sec < 0:
            raise ValueError("wait_sec must be finite and nonnegative")
        data = keystrokes.encode("utf-8")
        with self._lock:
            if self._closed or not self.is_running:
                raise RuntimeError("terminal is closed or Bash has exited")
            while data:
                try:
                    written = os.write(self._fd, data)
                except BlockingIOError:
                    select.select([], [self._fd], [], 0.05)
                    if not self.is_running:
                        raise RuntimeError("Bash exited while sending input")
                    continue
                data = data[written:]
        if wait_sec:
            time.sleep(wait_sec)

    def read_output(self) -> str:
        """Return and clear captured output (up to one million characters)."""
        with self._output_lock:
            output, self._output = self._output, ""
            return output

    def close(self) -> None:
        """Close the PTY, stop its shell and foreground job, and reap Bash."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            groups = {self._pid}
            try:
                groups.add(os.tcgetpgrp(self._fd))
            except OSError:
                pass
            groups.discard(os.getpgrp())
            groups.discard(0)
            for group in groups:
                try:
                    os.killpg(group, signal.SIGHUP)
                except ProcessLookupError:
                    pass
            self._stop.set()
            self._reader.join()
            os.close(self._fd)
            deadline = time.monotonic() + 0.5
            while self.is_running and time.monotonic() < deadline:
                time.sleep(0.01)
            # A foreground job can ignore SIGHUP even after Bash exits.
            # Kill any remaining terminal jobs as well as an unresponsive shell.
            for group in groups:
                try:
                    os.killpg(group, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            if self.is_running:
                _, self._status = os.waitpid(self._pid, 0)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
