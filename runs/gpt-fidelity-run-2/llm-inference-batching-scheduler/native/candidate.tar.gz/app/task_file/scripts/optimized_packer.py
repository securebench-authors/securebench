#!/usr/bin/env python3
"""Generate and validate the two shape-aware inference batching plans."""

import hashlib
import json
from collections import defaultdict
from pathlib import Path

from cost_model import HEADS, HIDDEN, CostModel, align


ROOT = Path(__file__).resolve().parents[1]
SHAPES = (64, 128, 192, 320, 512, 704, 1408, 2048)
LIMITS = {
    1: (3.0e11, 0.055, 2.1e6, 2.7e8),
    2: (4.8e10, 0.15, 2.1e5, 3.2e7),
}
METRICS = ('cost', 'pad_ratio', 'p95_latency_ms', 'sequential_timecost')


def build_plan(requests, bucket):
    # Keep the effective prompt dimension constant within each batch. The
    # compiled shapes are shared across these independently scheduled batches.
    by_prompt = defaultdict(list)
    for request in requests:
        by_prompt[align(request['prompt_len'], 64)].append(request)

    batches = []
    for seq, group in sorted(by_prompt.items()):
        shape_seq = next(s for s in SHAPES if s >= seq)
        current = []
        for request in sorted(group, key=lambda r: (r['gen_len'], r['request_id'])):
            if current:
                minimum_gen = current[0]['gen_len']
                # Integer arithmetic makes the proportional bound reproducible.
                too_wide = (
                    request['gen_len'] - minimum_gen > 8
                    if bucket == 1 else
                    100 * (request['gen_len'] - minimum_gen) > 100 + 12 * minimum_gen
                )
                if too_wide:
                    batches.append((shape_seq, current))
                    current = []
            current.append(request)
        if current:
            batches.append((shape_seq, current))

    records = {}
    for index, (seq, group) in enumerate(batches):
        for request in group:
            request_id = request['request_id']
            records[request_id] = {
                'request_id': request_id,
                'batch_id': f'b{bucket}-{index:04d}',
                'shape': {
                    'seq_align': seq,
                    'heads_align': HEADS,
                    'hidden_align': HIDDEN,
                },
            }
    return [records[r['request_id']] for r in requests]


def validate(requests, plan):
    lookup = {r['request_id']: r for r in requests}
    assert len(lookup) == len(requests), 'Duplicate input request IDs'
    assert len(plan) == len(requests)
    assert len({p['request_id'] for p in plan}) == len(plan)
    assert {p['request_id'] for p in plan} == set(lookup)
    batch_shapes = {}
    for record in plan:
        shape = record['shape']
        seq = shape['seq_align']
        assert isinstance(seq, int) and seq % 64 == 0
        assert seq >= align(lookup[record['request_id']]['prompt_len'], 64)
        assert shape['heads_align'] == HEADS
        assert shape['hidden_align'] == HIDDEN
        shape_tuple = (seq, shape['heads_align'], shape['hidden_align'])
        bid = record['batch_id']
        assert batch_shapes.setdefault(bid, shape_tuple) == shape_tuple
    return set(batch_shapes.values())


def main():
    model = CostModel(64)
    inputs = {}
    plans = {}
    all_shapes = set()
    for bucket in (1, 2):
        source = ROOT / 'input_data' / f'requests_bucket_{bucket}.jsonl'
        raw = source.read_bytes()
        inputs[source] = hashlib.sha256(raw).digest()
        requests = [json.loads(line) for line in raw.splitlines() if line.strip()]
        plan = build_plan(requests, bucket)
        all_shapes.update(validate(requests, plan))
        metrics = model.plan_metrics({r['request_id']: r for r in requests}, plan)
        for key, limit in zip(METRICS, LIMITS[bucket]):
            assert metrics[key] < limit, (bucket, key, metrics[key], limit)
        plans[bucket] = plan
        print(json.dumps({
            'bucket': bucket,
            'requests': len(plan),
            'batches': len({p['batch_id'] for p in plan}),
            **{key: metrics[key] for key in METRICS},
        }))
    assert len(all_shapes) <= 8
    output = ROOT / 'output_data'
    output.mkdir(parents=True, exist_ok=True)
    for bucket, plan in plans.items():
        destination = output / f'plan_b{bucket}.jsonl'
        destination.write_text(''.join(json.dumps(p) + '\n' for p in plan))
        assert [json.loads(line) for line in destination.read_text().splitlines()] == plan
    for source, digest in inputs.items():
        assert hashlib.sha256(source.read_bytes()).digest() == digest
    print(f'Validated {len(all_shapes)} shared shapes; input files unchanged.')


if __name__ == '__main__':
    main()
