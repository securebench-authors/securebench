#!/usr/bin/env python3
"""Build both plans using a shared graph inventory and decode-aware batching."""

from __future__ import annotations

import bisect
import json
from collections import defaultdict
from pathlib import Path

from cost_model import HEADS, HIDDEN, CostModel, align


ROOT = Path(__file__).resolve().parents[1]
GRANULARITY = 64
# Shared compiled graph inventory for the two supplied workloads.
SEQUENCE_SHAPES = (64, 128, 192, 320, 640, 1152, 1600, 2048)
LIMITS = {
    1: (3.0e11, 0.055, 2.1e6, 2.7e8),
    2: (4.8e10, 0.15, 2.1e5, 3.2e7),
}
METRIC_NAMES = ("cost", "pad_ratio", "p95_latency_ms", "sequential_timecost")


def pack(requests: list[dict], time_weight: float) -> list[dict]:
    """Minimize cost + weighted sequential time over contiguous decode groups.

    Each aligned prompt length is optimized separately. Within it, generation
    lengths are sorted and dynamic programming finds the best partition. This
    avoids prompt mixing and allows expensive long decodes to batch when useful.
    """
    model = CostModel(GRANULARITY)
    groups = defaultdict(list)
    for request in requests:
        groups[align(request["prompt_len"], GRANULARITY)].append(request)

    batches = []
    for sequence, members in sorted(groups.items()):
        members.sort(key=lambda r: (r["gen_len"], r["request_id"]))
        optimum = [0.0]
        previous = []
        for end, request in enumerate(members, 1):
            generation = request["gen_len"]
            sum_squared = model._sum_sq_arith(sequence, generation)
            sum_linear = generation * sequence + generation * (generation - 1) / 2
            c = model.c
            per_request_cost = (
                model._prefill_cost(sequence)
                + c.Kd_attn * sum_squared
                + c.Kd_mlp * HIDDEN * sum_linear
            )
            batch_latency = (
                model._prefill_lat(sequence)
                + c.Td_attn * sum_squared
                + c.Td_mlp * HIDDEN * sum_linear
                + c.Tbatch_overhead_ms
            )
            score, start = min(
                (
                    optimum[start]
                    + (end - start) * per_request_cost
                    + c.Kbatch_overhead_cost
                    + time_weight * batch_latency,
                    start,
                )
                for start in range(end)
            )
            optimum.append(score)
            previous.append(start)

        end = len(members)
        while end:
            start = previous[end - 1]
            batches.append((sequence, members[start:end]))
            end = start

    plan = []
    for index, (sequence, members) in enumerate(batches):
        shape = {
            "seq_align": SEQUENCE_SHAPES[bisect.bisect_left(SEQUENCE_SHAPES, sequence)],
            "heads_align": HEADS,
            "hidden_align": HIDDEN,
        }
        for request in members:
            plan.append({
                "request_id": request["request_id"],
                "batch_id": f"b-{index:04d}",
                "shape": shape,
            })
    return plan


def validate(requests: list[dict], plan: list[dict]) -> set[tuple]:
    by_id = {r["request_id"]: r for r in requests}
    ids = [p["request_id"] for p in plan]
    assert len(ids) == len(set(ids)) == len(requests)
    assert set(ids) == set(by_id)
    batch_shapes = {}
    for record in plan:
        shape = record["shape"]
        sequence = shape["seq_align"]
        assert isinstance(sequence, int) and sequence > 0
        assert sequence % GRANULARITY == 0
        assert sequence >= align(by_id[record["request_id"]]["prompt_len"], GRANULARITY)
        assert shape["heads_align"] == HEADS
        assert shape["hidden_align"] == HIDDEN
        key = (sequence, shape["heads_align"], shape["hidden_align"])
        assert batch_shapes.setdefault(record["batch_id"], key) == key
    return set(batch_shapes.values())


def main() -> None:
    outputs = []
    all_shapes = set()
    for bucket, time_weight in ((1, 30.0), (2, 100.0)):
        source = ROOT / "input_data" / f"requests_bucket_{bucket}.jsonl"
        requests = [json.loads(line) for line in source.read_text().splitlines()]
        plan = pack(requests, time_weight)
        all_shapes.update(validate(requests, plan))
        metrics = CostModel(GRANULARITY).plan_metrics(
            {r["request_id"]: r for r in requests}, plan
        )
        for name, limit in zip(METRIC_NAMES, LIMITS[bucket]):
            assert metrics[name] < limit, (bucket, name, metrics[name], limit)
        outputs.append((bucket, plan))
        print(json.dumps({"bucket": bucket, **{k: metrics[k] for k in METRIC_NAMES}}))
    assert len(all_shapes) <= 8
    destination = ROOT / "output_data"
    destination.mkdir(exist_ok=True)
    for bucket, plan in outputs:
        path = destination / f"plan_b{bucket}.jsonl"
        path.write_text("".join(json.dumps(record) + "\n" for record in plan))
    print(f"Validated {len(all_shapes)} shared shapes; wrote both plans.")


if __name__ == "__main__":
    main()
