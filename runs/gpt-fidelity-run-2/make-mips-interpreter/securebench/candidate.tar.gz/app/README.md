Run the supplied Doom MIPS executable from this directory:

```sh
node vm.js
```

No npm packages or external emulator are required. The interpreter loads
`doomgeneric_mips`, reads `doom.wad` through guest file syscalls, and runs until
interrupted with Ctrl+C. It implements the executable's custom syscall ABI:
MIPS argument registers with the syscall numbers defined in `my_stdlib.c`.

The original platform code saves a 640×400 BMP every tenth draw to
`/tmp/frame.bmp`. Each completed BMP is also preserved in `frames/frame000001.bmp`,
`frames/frame000002.bmp`, and so on. Numbering restarts on each run; use a separate
output directory to retain multiple runs.

To stop after the first saved frame:

```sh
node vm.js --frames 1
```

Optional arguments: `[ELF path]`, `--frames N` (0 means unlimited), and
`--frame-dir DIR`. Guest paths resolve against the current working directory.
Guest filesystem operations use the host filesystem directly.

CPU and syscall checks:

```sh
node --test vm.test.js
```
