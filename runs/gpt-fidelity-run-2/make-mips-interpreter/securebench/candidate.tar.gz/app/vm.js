#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');

// MIPS32r2, little endian, with branch delay slots. The supplied executable
// uses x86-64 syscall numbers in MIPS registers (see my_stdlib.c).
class MIPS {
  constructor(elf, options = {}) {
    this.options = options;
    this.memory = new ArrayBuffer(0x80000000); // Demand-zero virtual memory.
    this.u8 = new Uint8Array(this.memory);
    this.i8 = new Int8Array(this.memory);
    this.u16 = new Uint16Array(this.memory);
    this.i16 = new Int16Array(this.memory);
    this.i32 = new Int32Array(this.memory);
    this.r = new Int32Array(32);
    const fp = new ArrayBuffer(128);
    this.fi = new Int32Array(fp);
    this.ff = new Float32Array(fp);
    this.fd = new Float64Array(fp);
    this.fcc = new Uint8Array(8);
    this.hi = this.lo = 0;
    this.fds = new Map([[0, { host: 0 }], [1, { host: 1 }], [2, { host: 2 }]]);
    this.frames = 0;
    this.steps = 0;
    this.running = true;
    this.exitCode = 0;
    this.loadELF(elf);
    this.r[29] = 0x7ffff000;
  }
  loadELF(b) {
    if (b.readUInt32LE(0) !== 0x464c457f || b[4] !== 1 || b[5] !== 1 || b.readUInt16LE(18) !== 8)
      throw new Error('Expected a little-endian ELF32 MIPS executable');
    this.pc = b.readUInt32LE(24);
    this.next = this.pc + 4;
    const off = b.readUInt32LE(28), size = b.readUInt16LE(42), count = b.readUInt16LE(44);
    for (let i = 0; i < count; i++) {
      const p = off + i * size;
      if (b.readUInt32LE(p) !== 1) continue;
      const src = b.readUInt32LE(p + 4), dst = b.readUInt32LE(p + 8);
      const n = b.readUInt32LE(p + 16), mem = b.readUInt32LE(p + 20);
      if (dst + mem > this.u8.length || src + n > b.length || n > mem) throw new Error('Invalid ELF segment');
      this.u8.set(b.subarray(src, src + n), dst);
    }
  }
  cstring(addr) {
    addr >>>= 0;
    let end = addr;
    while (end < this.u8.length && this.u8[end]) end++;
    if (end === this.u8.length) throw new Error('Unterminated guest string');
    return Buffer.from(this.memory, addr, end - addr).toString();
  }
  descriptor(fd) {
    const d = this.fds.get(fd);
    if (!d) { const e = new Error('Bad file descriptor'); e.code = 'EBADF'; throw e; }
    return d;
  }
  saveFrame(d) {
    if (d.name !== '/tmp/frame.bmp') return;
    const dir = this.options.frameDir;
    fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, `frame${String(++this.frames).padStart(6, '0')}.bmp`);
    fs.copyFileSync(d.name, dest);
    console.log(`[vm] Saved ${dest}`);
    if (this.options.maxFrames && this.frames >= this.options.maxFrames) this.running = false;
  }
  syscall() {
    const r = this.r, n = r[2], a = r[4], b = r[5] >>> 0, c = r[6] >>> 0;
    let result = 0;
    try {
      switch (n) {
        case 0: { // read
          const d = this.descriptor(a);
          result = fs.readSync(d.host, Buffer.from(this.memory, b, c), 0, c, d.pos ?? null);
          if (d.pos !== undefined) d.pos += result;
          break;
        }
        case 1: {
          const d = this.descriptor(a);
          result = fs.writeSync(d.host, Buffer.from(this.memory, b, c), 0, c, d.append ? null : (d.pos ?? null));
          if (d.pos !== undefined) d.pos += result;
          break;
        }
        case 2: {
          const name = this.cstring(a);
          // These are the Linux x86 flags used by the guest's custom libc.
          const host = fs.openSync(name, b, c & 0o777);
          let fd = 3;
          while (this.fds.has(fd)) fd++;
          this.fds.set(fd, { host, name, pos: 0, append: !!(b & 1024) });
          result = fd;
          break;
        }
        case 3: {
          const d = this.descriptor(a);
          if (a > 2) { fs.closeSync(d.host); this.fds.delete(a); this.saveFrame(d); }
          break;
        }
        case 8: {
          const d = this.descriptor(a), offset = b | 0;
          const base = c === 0 ? 0 : c === 1 ? d.pos : c === 2 ? fs.fstatSync(d.host).size : NaN;
          if (!Number.isFinite(base) || base + offset < 0) { result = -22; break; }
          result = d.pos = base + offset;
          break;
        }
        case 35: break; // nanosleep: virtual machine runs without wall-clock delays
        case 60: case 231: this.exitCode = a; this.running = false; break;
        case 74: fs.fsyncSync(this.descriptor(a).host); break;
        case 82: fs.renameSync(this.cstring(a), this.cstring(b)); break;
        case 83: fs.mkdirSync(this.cstring(a), { mode: b & 0o777 }); break;
        case 87: fs.unlinkSync(this.cstring(a)); break;
        case 96: {
          const now = Date.now();
          if (a) { this.i32[a >>> 2] = Math.floor(now / 1000); this.i32[(a + 4) >>> 2] = now % 1000 * 1000; }
          if (b) { this.i32[b >>> 2] = 0; this.i32[(b + 4) >>> 2] = 0; }
          break;
        }
        case 201: result = Math.floor(Date.now() / 1000); if (a) this.i32[a >>> 2] = result; break;
        default: throw new Error(`Unsupported guest syscall ${n} at 0x${this.currentPC.toString(16)}`);
      }
    } catch (e) {
      if (!e.code) throw e;
      const errno = { EPERM: 1, ENOENT: 2, EINTR: 4, EIO: 5, EBADF: 9, EAGAIN: 11, ENOMEM: 12,
        EACCES: 13, EFAULT: 14, EBUSY: 16, EEXIST: 17, ENOTDIR: 20, EISDIR: 21, EINVAL: 22,
        EMFILE: 24, EFBIG: 27, ENOSPC: 28, ESPIPE: 29, EROFS: 30, EPIPE: 32, ENOTEMPTY: 39 };
      result = -(errno[e.code] || 5);
    }
    r[2] = result;
  }
  cop1(w) {
    const fmt = w >>> 21 & 31, ft = w >>> 16 & 31, s = w >>> 11 & 31, d = w >>> 6 & 31, fn = w & 63;
    const r = this.r, fi = this.fi, ff = this.ff, fd = this.fd;
    switch (fmt) {
      case 0: r[ft] = fi[s]; return;
      case 2: r[ft] = s === 31 ? (this.fcc[0] << 23) : 0; return;
      case 3: r[ft] = fi[s + 1]; return;
      case 4: fi[s] = r[ft]; return;
      case 6: if (s === 31) this.fcc[0] = r[ft] >>> 23 & 1; return;
      case 7: fi[s + 1] = r[ft]; return;
      case 8: {
        const take = this.fcc[ft >>> 2] === (ft & 1);
        if (take) this.next = (this.currentPC + 4 + ((w << 16 >> 16) << 2)) >>> 0;
        else if (ft & 2) { this.pc = this.next; this.next += 4; }
        return;
      }
    }
    const x = fmt === 17 ? fd[s >>> 1] : fmt === 20 ? fi[s] : ff[s];
    const y = fmt === 17 ? fd[ft >>> 1] : ff[ft];
    let z;
    switch (fn) {
      case 0: z = x + y; break;
      case 1: z = x - y; break;
      case 2: z = x * y; break;
      case 3: z = x / y; break;
      case 4: z = Math.sqrt(x); break;
      case 5: z = Math.abs(x); break;
      case 6: z = x; break;
      case 7: z = -x; break;
      case 12: fi[d] = Math.round(x); return;
      case 13: fi[d] = Math.trunc(x); return;
      case 14: fi[d] = Math.ceil(x); return;
      case 15: fi[d] = Math.floor(x); return;
      case 17: if (this.fcc[ft >>> 2] !== (ft & 1)) return; z = x; break;
      case 32: ff[d] = x; return;
      case 33: fd[d >>> 1] = x; return;
      case 36: fi[d] = Math.trunc(x); return;
      default:
        if (fn >= 48) {
          const unordered = Number.isNaN(x) || Number.isNaN(y);
          this.fcc[w >>> 8 & 7] = !!((fn & 1 && unordered) || (fn & 2 && x === y) || (fn & 4 && x < y));
          return;
        }
        throw new Error(`Unsupported COP1 0x${w.toString(16)}`);
    }
    if (fmt === 17) fd[d >>> 1] = z; else ff[d] = z;
  }
  run(budget = 1000000) {
    const r = this.r, m = this.i32, u8 = this.u8, i8 = this.i8, u16 = this.u16, i16 = this.i16;
    let pc = this.pc, next = this.next;
    for (let count = 0; count < budget && this.running; count++) {
      const at = pc;
      if ((at & 3) || at >= 0x80000000) throw new Error(`Invalid PC 0x${at.toString(16)}`);
      const w = m[at >>> 2] >>> 0, op = w >>> 26, s = w >>> 21 & 31, t = w >>> 16 & 31;
      const d = w >>> 11 & 31, sa = w >>> 6 & 31, fn = w & 63, imm = w << 16 >> 16;
      const x = r[s], y = r[t], addr = (x + imm) >>> 0;
      pc = next; next = (next + 4) >>> 0;
      this.steps++;
      switch (op) {
        case 0:
          switch (fn) {
            case 0: r[d] = y << sa; break;
            case 2: r[d] = s === 1 ? (y >>> sa) | (y << (32 - sa)) : y >>> sa; break;
            case 3: r[d] = y >> sa; break;
            case 4: r[d] = y << x; break;
            case 6: r[d] = sa === 1 ? (y >>> (x & 31)) | (y << (32 - (x & 31))) : y >>> x; break;
            case 7: r[d] = y >> x; break;
            case 8: next = x >>> 0; break;
            case 9: r[d] = at + 8; next = x >>> 0; break;
            case 10: if (!y) r[d] = x; break;
            case 11: if (y) r[d] = x; break;
            case 12:
              this.currentPC = at; this.pc = pc; this.next = next;
              this.syscall(); break;
            case 13: throw new Error(`MIPS break at 0x${at.toString(16)}`);
            case 15: break; // sync
            case 16: r[d] = this.hi; break;
            case 17: this.hi = x; break;
            case 18: r[d] = this.lo; break;
            case 19: this.lo = x; break;
            case 24: case 25: {
              // Exact high word without losing low bits to JS floating point.
              const a = x >>> 0, b = y >>> 0;
              const low = (a & 65535) * (b & 65535);
              const mid = (a >>> 16) * (b & 65535) + (a & 65535) * (b >>> 16) + (low >>> 16);
              let high = (a >>> 16) * (b >>> 16) + Math.floor(mid / 65536);
              if (fn === 24) high -= (x < 0 ? b : 0) + (y < 0 ? a : 0);
              this.hi = high | 0; this.lo = Math.imul(x, y); break;
            }
            case 26:
              this.lo = y ? Math.trunc(x / y) | 0 : x < 0 ? 1 : -1;
              this.hi = y ? x % y | 0 : x; break;
            case 27:
              this.lo = y ? Math.floor((x >>> 0) / (y >>> 0)) | 0 : -1;
              this.hi = y ? (x >>> 0) % (y >>> 0) | 0 : x; break;
            case 32: case 33: r[d] = x + y; break;
            case 34: case 35: r[d] = x - y; break;
            case 36: r[d] = x & y; break;
            case 37: r[d] = x | y; break;
            case 38: r[d] = x ^ y; break;
            case 39: r[d] = ~(x | y); break;
            case 42: r[d] = x < y; break;
            case 43: r[d] = (x >>> 0) < (y >>> 0); break;
            case 52: if (x === y) throw new Error(`MIPS trap at 0x${at.toString(16)}`); break;
            default: this.illegal(at, w);
          } break;
        case 1: {
          const kind = t & 3;
          if (![0, 1, 2, 3, 16, 17, 18, 19].includes(t)) this.illegal(at, w);
          const take = kind & 1 ? x >= 0 : x < 0;
          if (t & 16) r[31] = at + 8;
          if (take) next = (at + 4 + (imm << 2)) >>> 0;
          else if (kind & 2) { pc = next; next += 4; }
          break;
        }
        case 2: next = ((at + 4 & 0xf0000000) | (w & 0x3ffffff) << 2) >>> 0; break;
        case 3: r[31] = at + 8; next = ((at + 4 & 0xf0000000) | (w & 0x3ffffff) << 2) >>> 0; break;
        case 4: if (x === y) next = (at + 4 + (imm << 2)) >>> 0; break;
        case 5: if (x !== y) next = (at + 4 + (imm << 2)) >>> 0; break;
        case 6: if (x <= 0) next = (at + 4 + (imm << 2)) >>> 0; break;
        case 7: if (x > 0) next = (at + 4 + (imm << 2)) >>> 0; break;
        case 8: case 9: r[t] = x + imm; break;
        case 10: r[t] = x < imm; break;
        case 11: r[t] = (x >>> 0) < (imm >>> 0); break;
        case 12: r[t] = x & (w & 65535); break;
        case 13: r[t] = x | (w & 65535); break;
        case 14: r[t] = x ^ (w & 65535); break;
        case 15: r[t] = w << 16; break;
        case 17:
          this.currentPC = at; this.pc = pc; this.next = next; this.cop1(w);
          pc = this.pc; next = this.next; break;
        case 20: case 21: case 22: case 23: {
          const take = op === 20 ? x === y : op === 21 ? x !== y : op === 22 ? x <= 0 : x > 0;
          if (take) next = (at + 4 + (imm << 2)) >>> 0;
          else { pc = next; next += 4; }
          break;
        }
        case 28:
          if (fn === 2) r[d] = Math.imul(x, y);
          else if (fn === 32) r[d] = Math.clz32(x);
          else if (fn === 33) r[d] = Math.clz32(~x);
          else this.illegal(at, w);
          break;
        case 31:
          if (fn === 0) r[t] = (x >>> sa) & (0xffffffff >>> (31 - d));
          else if (fn === 4) { const mask = (0xffffffff >>> (31 - (d - sa))) << sa; r[t] = (y & ~mask) | (x << sa & mask); }
          else if (fn === 32 && sa === 16) r[d] = y << 24 >> 24;
          else if (fn === 32 && sa === 24) r[d] = y << 16 >> 16;
          else if (fn === 32 && sa === 2) r[d] = (y & 0x00ff00ff) << 8 | (y >>> 8 & 0x00ff00ff);
          else this.illegal(at, w);
          break;
        case 32: r[t] = i8[addr]; break;
        case 33: r[t] = i16[addr >>> 1]; break;
        case 34: { const shift = (3 - (addr & 3)) * 8; r[t] = (y & ~(0xffffffff << shift)) | (m[addr >>> 2] << shift); break; }
        case 35: r[t] = m[addr >>> 2]; break;
        case 36: r[t] = u8[addr]; break;
        case 37: r[t] = u16[addr >>> 1]; break;
        case 38: { const shift = (addr & 3) * 8; r[t] = (y & ~(0xffffffff >>> shift)) | (m[addr >>> 2] >>> shift); break; }
        case 40: u8[addr] = y; break;
        case 41: u16[addr >>> 1] = y; break;
        case 42: { const shift = (3 - (addr & 3)) * 8; m[addr >>> 2] = (m[addr >>> 2] & ~(0xffffffff >>> shift)) | (y >>> shift); break; }
        case 43: m[addr >>> 2] = y; break;
        case 46: { const shift = (addr & 3) * 8; m[addr >>> 2] = (m[addr >>> 2] & ~(0xffffffff << shift)) | (y << shift); break; }
        case 47: case 51: break; // cache / prefetch hints
        case 48: r[t] = m[addr >>> 2]; break; // ll: single CPU
        case 49: this.fi[t] = m[addr >>> 2]; break;
        case 53: this.fi[t] = m[addr >>> 2]; this.fi[t + 1] = m[(addr + 4) >>> 2]; break;
        case 56: m[addr >>> 2] = y; r[t] = 1; break;
        case 57: m[addr >>> 2] = this.fi[t]; break;
        case 61: m[addr >>> 2] = this.fi[t]; m[(addr + 4) >>> 2] = this.fi[t + 1]; break;
        default: this.illegal(at, w);
      }
      r[0] = 0;
    }
    this.pc = pc; this.next = next;
  }
  illegal(pc, w) { throw new Error(`Unsupported instruction 0x${w.toString(16)} at 0x${pc.toString(16)}`); }
  close() { for (const [fd, d] of this.fds) if (fd > 2) { fs.closeSync(d.host); this.fds.delete(fd); } }
}

function main() {
  const args = process.argv.slice(2);
  let binary = path.join(__dirname, 'doomgeneric_mips');
  const options = { frameDir: path.join(__dirname, 'frames'), maxFrames: 0 };
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--frames') options.maxFrames = Number(args[++i]);
    else if (args[i] === '--frame-dir') options.frameDir = path.resolve(args[++i]);
    else if (args[i] === '--help') {
      console.log('Usage: node vm.js [ELF] [--frames N] [--frame-dir DIR]\nDefault: run continuously; preserve guest BMP writes in ./frames and /tmp/frame.bmp.'); return;
    } else if (!args[i].startsWith('-')) binary = path.resolve(args[i]);
    else throw new Error(`Unknown option ${args[i]}`);
  }
  if (!Number.isInteger(options.maxFrames) || options.maxFrames < 0) throw new Error('--frames must be a nonnegative integer');
  const vm = new MIPS(fs.readFileSync(binary), options);
  function tick() {
    try {
      vm.run();
      if (vm.running) setImmediate(tick);
      else { vm.close(); process.exitCode = vm.exitCode; }
    } catch (e) { vm.close(); console.error(e.stack); process.exitCode = 1; }
  }
  process.on('SIGINT', () => { vm.running = false; });
  tick();
}
if (require.main === module) main();
module.exports = { MIPS };
