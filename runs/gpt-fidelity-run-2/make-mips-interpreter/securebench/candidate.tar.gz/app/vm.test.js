'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { MIPS } = require('./vm');

function machine() {
  const elf = Buffer.alloc(52);
  elf.writeUInt32LE(0x464c457f, 0); elf[4] = 1; elf[5] = 1;
  elf.writeUInt16LE(8, 18); elf.writeUInt32LE(0x1000, 24);
  return new MIPS(elf, {});
}
const R = (s, t, d, f, shift = 0) => (s << 21 | t << 16 | d << 11 | shift << 6 | f) >>> 0;
const I = (op, s, t, imm) => (op << 26 | s << 21 | t << 16 | imm & 65535) >>> 0;

// Reuse one virtual address space so the tests need little physical memory.
const vm = machine();
function execute(words) {
  vm.pc = 0x1000; vm.next = 0x1004; vm.running = true;
  vm.i32.set(words, 0x1000 >>> 2); vm.run(words.length);
}
test('taken branch executes its delay slot and skips fallthrough', () => {
  vm.r.fill(0);
  execute([I(4, 0, 0, 2), I(9, 0, 2, 7), I(9, 0, 2, 99), I(9, 2, 3, 1)]);
  assert.equal(vm.r[2], 7); assert.equal(vm.r[3], 8);
});
test('jal links after the delay slot; writes to zero are discarded', () => {
  vm.r.fill(0);
  execute([3 << 26 | 0x100c >>> 2, I(9, 0, 2, 42), I(9, 0, 2, 99), I(9, 0, 0, 1)]);
  assert.equal(vm.r[31], 0x1008); assert.equal(vm.r[2], 42); assert.equal(vm.r[0], 0);
});
test('signed and unsigned multiply preserve all 64 result bits', () => {
  for (const a of [-2147483648, -1, 65535, 0x12345678, 2147483647]) {
    for (const b of [-2147483648, -1, 65535, 2147483647]) {
      for (const signed of [true, false]) {
        vm.r[4] = a; vm.r[5] = b;
        execute([R(4, 5, 0, signed ? 24 : 25)]);
        const n = BigInt.asUintN(64, BigInt(signed ? a : a >>> 0) * BigInt(signed ? b : b >>> 0));
        assert.equal(vm.lo >>> 0, Number(n & 0xffffffffn));
        assert.equal(vm.hi >>> 0, Number(n >> 32n));
      }
    }
  }
});
test('little-endian lwl/lwr and swl/swr pairs work at every byte offset', () => {
  for (let offset = 0; offset < 4; offset++) {
    const a = 0x2000 + offset;
    vm.u8.set([0x12, 0x34, 0x56, 0x78], a);
    vm.r[4] = a; vm.r[5] = -1;
    execute([I(34, 4, 5, 3), I(38, 4, 5, 0)]);
    assert.equal(vm.r[5] >>> 0, 0x78563412);
    vm.u8.fill(0xaa, 0x3000, 0x3010);
    vm.r[4] = 0x3004 + offset;
    execute([I(42, 4, 5, 3), I(46, 4, 5, 0)]);
    assert.deepEqual([...vm.u8.slice(vm.r[4], vm.r[4] + 4)], [0x12, 0x34, 0x56, 0x78]);
    assert.equal(vm.u8[vm.r[4] - 1], 0xaa); assert.equal(vm.u8[vm.r[4] + 4], 0xaa);
  }
});
test('floating point conversion rounds to single precision', () => {
  vm.fi[2] = 16777217;
  execute([17 << 26 | 20 << 21 | 2 << 11 | 4 << 6 | 32]);
  assert.equal(vm.ff[4], 16777216);
});
test('guest syscalls open, write, seek, read, close and return negative errno', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mips-test-'));
  try {
    const file = path.join(dir, 'data');
    vm.u8.set(Buffer.from(file + '\0'), 0x4000);
    const call = (n, a = 0, b = 0, c = 0) => {
      vm.r[2] = n; vm.r[4] = a; vm.r[5] = b; vm.r[6] = c; vm.syscall(); return vm.r[2];
    };
    const fd = call(2, 0x4000, 2 | 64 | 512, 0o600);
    assert.ok(fd >= 3);
    vm.u8.set(Buffer.from('doom'), 0x5000);
    assert.equal(call(1, fd, 0x5000, 4), 4);
    assert.equal(call(8, fd, 0, 0), 0);
    assert.equal(call(0, fd, 0x6000, 4), 4);
    assert.equal(Buffer.from(vm.memory, 0x6000, 4).toString(), 'doom');
    assert.equal(call(3, fd), 0);
    assert.equal(call(0, fd, 0x6000, 4), -9);
    call(87, 0x4000);
    assert.equal(call(2, 0x4000), -2);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
