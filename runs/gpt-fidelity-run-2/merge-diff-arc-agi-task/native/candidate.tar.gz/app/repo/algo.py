def map(g):
    """Complete the repeating three-color anti-diagonal pattern.

    Zero cells are blanks. Each nonzero cell determines the color for
    its row-plus-column residue, extending the pattern in both directions.
    The input is left unchanged.
    """
    colors = {}
    for i, row in enumerate(g):
        for j, color in enumerate(row):
            if color != 0:
                colors[(i + j) % 3] = color

    return [
        [colors.get((i + j) % 3, 0) for j in range(len(row))]
        for i, row in enumerate(g)
    ]
