"""Complete a grid of repeating, three-color diagonal stripes."""


def map(g):
    """Fill zero cells using the colors on the same repeating diagonal.

    Diagonals have constant row + column, and their colors repeat every
    three diagonals. Nonzero cells specify the color for each phase.
    The input is left unchanged and a new list of rows is returned.
    """
    colors = {}
    for i, row in enumerate(g):
        for j, color in enumerate(row):
            if color != 0:
                colors[(i + j) % 3] = color

    return [
        [colors.get((i + j) % 3, 0) for j in range(len(row))]
        for i, row in enumerate(g)
    ]
