def mod3(x):
    """A helper function that is not used."""
    return x % 3
