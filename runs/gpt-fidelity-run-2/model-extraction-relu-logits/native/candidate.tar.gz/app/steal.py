"""Recover a scalar, one-hidden-layer ReLU network's input weight directions.

Only the callable forward is used. Rows are normalized and have a canonical
sign, since row scales, signs, and order cannot be inferred from kink geometry.
Neurons with zero output weight or coincident activation hyperplanes are not
individually identifiable from scalar queries.
"""
from pathlib import Path
import numpy as np
from forward import forward

DIM = 10


def query(x):
    return float(forward(np.asarray(x, dtype=float)))


def gradient(x, step=1e-3):
    """Reduce the stencil until two estimates agree within roundoff."""
    def estimate(h):
        result = np.empty(DIM)
        for j in range(DIM):
            delta = np.zeros(DIM)
            delta[j] = h
            result[j] = (query(x + delta) - query(x - delta)) / (2 * h)
        return result

    previous = estimate(step)
    for _ in range(9):
        step *= 0.25
        current = estimate(step)
        if np.linalg.norm(current - previous) < 2e-8 * max(1., np.linalg.norm(current)):
            return current
        previous = current
    return previous


def line_kinks(origin, direction, left, right, count=1025, depth=0):
    """Locate isolated slope changes, refining clusters of nearby changes."""
    ts = np.linspace(left, right, count)
    fs = np.array([query(origin + t * direction) for t in ts])
    slopes = np.diff(fs) / np.diff(ts)
    tolerance = 2e-9 * max(1., float(np.max(np.abs(slopes))))
    changes = np.flatnonzero(np.abs(np.diff(slopes)) > tolerance)
    if not len(changes):
        return
    groups = np.split(changes, np.flatnonzero(np.diff(changes) > 1) + 1)
    for group in groups:
        first, last = int(group[0]), int(group[-1])
        a, b = ts[first], ts[last + 2]
        fa, fb = fs[first], fs[last + 2]
        sa, sb = slopes[first], slopes[last + 1]
        root = np.nan
        if abs(sa - sb) > tolerance:
            root = (fb - fa + sa * a - sb * b) / (sa - sb)
        isolated = a < root < b
        if isolated:
            # A single kink must agree with the two affine pieces throughout
            # this interval. A merged group is instead scanned more finely.
            probes = np.array([a + .25 * (root - a), a + .75 * (root - a),
                               root, root + .25 * (b - root), root + .75 * (b - root)])
            expected = np.where(probes <= root, fa + sa * (probes - a),
                                fb + sb * (probes - b))
            actual = np.array([query(origin + t * direction) for t in probes])
            isolated = np.max(np.abs(actual - expected)) < 2e-11 * max(1., abs(fa), abs(fb))
        if not isolated:
            if depth < 8:
                yield from line_kinks(origin, direction, a, b, 65, depth + 1)
            continue
        x_left = origin + (a + root) * .5 * direction
        x_right = origin + (b + root) * .5 * direction
        jump = gradient(x_right) - gradient(x_left)
        length = np.linalg.norm(jump)
        if length < 1e-8:
            continue
        normal = jump / length
        # Reject gradient estimates which crossed unrelated boundaries.
        if abs(np.dot(jump, direction) - (sb - sa)) > 2e-7 * max(1., abs(sb - sa)):
            continue
        yield normal, origin + root * direction


def validate(normal, point, rng):
    """Check that the jump persists along the proposed activation plane."""
    for scale in (0.02, 0.002, 0.0002):
        valid = True
        for _ in range(2):
            tangent = rng.normal(size=DIM)
            tangent -= np.dot(tangent, normal) * normal
            center = point + scale * tangent
            offset = scale * .1
            jump = (gradient(center + offset * normal, offset * .05)
                    - gradient(center - offset * normal, offset * .05))
            magnitude = np.linalg.norm(jump)
            if magnitude < 1e-8 or np.linalg.norm(jump - np.dot(jump, normal) * normal) > 2e-6 * magnitude:
                valid = False
                break
        if valid:
            return True
    return False


def recover():
    rng = np.random.default_rng(1729)
    normals = []
    quiet_lines = 0
    # Increasing radii also expose boundaries with large offsets. Repeated
    # generic lines recover neurons whose normals nearly miss an earlier line.
    for line in range(64):
        radius = (8., 32., 128., 512.)[line % 4]
        origin = rng.normal(size=DIM) * (1. if line % 2 == 0 else radius * .05)
        direction = rng.normal(size=DIM)
        direction /= np.linalg.norm(direction)
        before = len(normals)
        for normal, point in line_kinks(origin, direction, -radius, radius):
            if any(abs(np.dot(normal, known)) > 1. - 1e-9 for known in normals):
                continue
            if not validate(normal, point, rng):
                continue
            # Canonical signs make the output deterministic and easy to inspect.
            if normal[np.argmax(np.abs(normal))] < 0:
                normal = -normal
            normals.append(normal)
        quiet_lines = quiet_lines + 1 if len(normals) == before else 0
        if line >= 15 and quiet_lines >= 8 and normals:
            break
    if not normals:
        raise RuntimeError('No identifiable ReLU boundaries were found.')
    return np.stack(normals)


def main():
    matrix = recover()
    output = Path('/app/stolen_A1.npy')
    np.save(output, matrix)
    np.set_printoptions(precision=10, linewidth=160, threshold=np.inf)
    print(matrix)
    print(f'Saved {matrix.shape[0]} x {matrix.shape[1]} matrix to {output}')


if __name__ == '__main__':
    main()
