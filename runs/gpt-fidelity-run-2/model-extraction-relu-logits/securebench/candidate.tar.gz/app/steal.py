"""Recover observable first-layer ReLU weights using only scalar queries.

Run with `python /app/steal.py`. Rows have unit length and a canonical sign;
positive/negative row rescaling and row order cannot be identified from kinks.
A neuron with zero output weight, or several neurons on the same hyperplane,
cannot in general be individually identified by any black-box method.
"""
from pathlib import Path

import numpy as np

from forward import forward


DIM = 10


def query(x):
    return float(forward(np.asarray(x, dtype=float)))


def gradient(x, step=1e-4):
    """Central differences are exact within an affine activation region."""
    result = np.empty(DIM)
    for k in range(DIM):
        shift = np.zeros(DIM)
        shift[k] = step
        result[k] = (query(x + shift) - query(x - shift)) / (2 * step)
    return result


def canonical(normal, offset):
    normal = normal.copy()
    if normal[np.argmax(np.abs(normal))] < 0:
        normal = -normal
        offset = -offset
    return normal, offset


def boundary_candidate(point, direction, rng):
    """Measure a local gradient jump, then verify it along the hyperplane."""
    delta = 2e-4
    jump = gradient(point + delta * direction, 1e-6) - gradient(
        point - delta * direction, 1e-6
    )
    size = np.linalg.norm(jump)
    if size < 1e-9:
        return None
    normal = jump / size

    # Move in the estimated normal direction so even nearly tangential line
    # intersections have enough clearance for accurate finite differences.
    clearance = 2e-3
    minus = point - clearance * normal
    plus = point + clearance * normal
    gm, gp = gradient(minus), gradient(plus)
    jump = gp - gm
    size = np.linalg.norm(jump)
    if size < 1e-9:
        return None
    refined = jump / size
    if abs(np.dot(normal, refined)) < 1 - 1e-7:
        return None

    # Intersect the two local affine functions to refine the boundary location.
    denominator = np.dot(gm - gp, normal)
    shift = (
        query(plus) - query(minus)
        - clearance * np.dot(gm + gp, normal)
    ) / denominator
    if abs(shift) > clearance * 0.5:
        return None
    point = point + shift * normal
    normal = refined if np.dot(refined, normal) > 0 else -refined

    # A sum of jumps from two nearby neurons is not a valid row. Such a sum
    # will fail these checks at independently chosen points on its plane.
    for _ in range(3):
        tangent = rng.normal(size=DIM)
        tangent -= np.dot(tangent, normal) * normal
        center = point + 0.7 * tangent
        gm = gradient(center - clearance * normal)
        gp = gradient(center + clearance * normal)
        observed = gp - gm
        if np.linalg.norm(observed - jump) > max(2e-9, size * 2e-6):
            return None
        # Check that the affine pieces meet at the proposed plane as well.
        residual = (
            query(center + clearance * normal)
            - query(center - clearance * normal)
            - clearance * np.dot(gp + gm, normal)
        )
        if abs(residual) > max(2e-11, size * 2e-7):
            return None
    return canonical(normal, np.dot(normal, point))


def scan_line(origin, direction, rng):
    """Locate changes of slope, then intersect their adjacent affine pieces."""
    ts = np.linspace(-32.0, 32.0, 2049)
    values = np.array([query(origin + t * direction) for t in ts])
    spacing = ts[1] - ts[0]
    slopes = np.diff(values) / spacing
    threshold = max(1e-10, np.max(np.abs(slopes)) * 1e-9)
    indices = np.flatnonzero(np.abs(np.diff(slopes)) > threshold) + 1
    for j in indices:
        lo, hi = ts[j - 1], ts[j + 1]
        h = 1e-5
        left = origin + lo * direction
        right = origin + hi * direction
        sl = (query(left + h * direction) - query(left - h * direction)) / (2 * h)
        sr = (query(right + h * direction) - query(right - h * direction)) / (2 * h)
        if abs(sl - sr) < threshold:
            continue
        crossing = (values[j + 1] - values[j - 1] + sl * lo - sr * hi) / (sl - sr)
        if not lo < crossing < hi:
            continue
        candidate = boundary_candidate(origin + crossing * direction, direction, rng)
        if candidate is not None:
            yield candidate


def recover():
    rng = np.random.default_rng(721934)
    planes = []
    unchanged = 0
    # Width is inferred from distinct validated hyperplanes, never read from
    # the model. Repeated independent scans guard against missed close kinks.
    for trial in range(128):
        origin = rng.normal(size=DIM) * (1.0 + trial % 4)
        direction = rng.normal(size=DIM)
        direction /= np.linalg.norm(direction)
        before = len(planes)
        for normal, offset in scan_line(origin, direction, rng):
            if not any(
                abs(np.dot(normal, old_normal)) > 1 - 1e-8
                and abs(offset - old_offset) < 1e-5 * (1 + abs(offset))
                for old_normal, old_offset in planes
            ):
                planes.append((normal, offset))
        unchanged = unchanged + 1 if len(planes) == before else 0
        if trial >= 15 and unchanged >= 10 and planes:
            break
    else:
        raise RuntimeError("Boundary discovery did not stabilize; increase the scan budget.")
    if not planes:
        raise RuntimeError("No observable ReLU boundaries found.")
    matrix = np.stack([normal for normal, _ in planes])
    # Stable presentation, independent of discovery order.
    return matrix[np.lexsort(matrix.T[::-1])]


def main():
    matrix = recover()
    np.save(Path('/app/stolen_A1.npy'), matrix)
    np.set_printoptions(precision=12, linewidth=160, suppress=True)
    print(matrix)


if __name__ == '__main__':
    main()
