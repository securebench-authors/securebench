#!/usr/bin/env python3
"""Print the mean temperature for every station in the climate dataset."""

from pathlib import Path

import pandas as pd


def main() -> None:
    data_path = (
        Path(__file__).resolve().parent
        / "climate_analyzer"
        / "sample_data"
        / "climate_data.csv"
    )
    data = pd.read_csv(data_path, encoding="utf-8", parse_dates=["date"])

    for station_id, mean_temperature in data.groupby("station_id")["temperature"].mean().items():
        print(f"Station {station_id} mean temperature: {mean_temperature:.1f}°C")


if __name__ == "__main__":
    main()
