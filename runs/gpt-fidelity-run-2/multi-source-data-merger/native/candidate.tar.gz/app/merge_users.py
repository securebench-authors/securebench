"""Merge the three user sources and report conflicting normalized values."""

import csv
import json
from decimal import Decimal
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq


FIELDS = {
    "user_id": ("user_id", "id", "userId"),
    "name": ("full_name", "name", "userName"),
    "email": ("email", "email_address"),
    "created_date": ("created_date", "registration_date", "created_at", "joined"),
    "status": ("status", "is_active", "active"),
}
OUTPUT = Path("/app")


def normalize(row):
    result = {}
    for field, aliases in FIELDS.items():
        for alias in aliases:
            value = row.get(alias)
            if value is None or pd.isna(value) or value == "":
                continue
            if field == "user_id":
                number = Decimal(str(value))
                if not number.is_finite() or number != number.to_integral_value():
                    raise ValueError(f"Invalid integer user ID: {value!r}")
                value = int(number)
            elif field == "created_date":
                value = pd.Timestamp(value).strftime("%Y-%m-%d")
            elif field == "status" and alias in ("is_active", "active"):
                boolean = str(value).strip().lower()
                if boolean not in ("true", "false", "1", "0"):
                    raise ValueError(f"Invalid boolean status: {value!r}")
                value = "active" if boolean in ("true", "1") else "inactive"
            else:
                value = str(value)
            result[field] = value
            break
    if "user_id" not in result:
        raise ValueError("User record is missing its ID")
    return result


def main():
    with Path("/data/source_a/users.json").open() as stream:
        source_a = json.load(stream)
    with Path("/data/source_b/users.csv").open(newline="") as stream:
        source_b = list(csv.DictReader(stream))
    source_c = pq.read_table("/data/source_c/users.parquet").to_pylist()

    users = {}
    for source, rows in (("source_a", source_a), ("source_b", source_b),
                         ("source_c", source_c)):
        seen = set()
        for raw in rows:
            row = normalize(raw)
            user_id = row.pop("user_id")
            if user_id in seen:
                raise ValueError(f"Duplicate user ID {user_id} within {source}")
            seen.add(user_id)
            users.setdefault(user_id, {})[source] = row

    merged = []
    conflicts = []
    for user_id, sources in sorted(users.items()):
        record = {"user_id": user_id}
        for field in ("name", "email", "created_date", "status"):
            # Sources retain insertion order: A, then B, then C.
            values = {source: row[field] for source, row in sources.items()
                      if field in row}
            selected = next(iter(values.values()), None)
            record[field] = selected
            if len(set(values.values())) > 1:
                conflicts.append({"user_id": user_id, "field": field,
                                  "values": values, "selected": selected})
        merged.append(record)

    schema = pa.schema([
        ("user_id", pa.int64()),
        ("name", pa.string()),
        ("email", pa.string()),
        ("created_date", pa.string()),
        ("status", pa.string()),
    ])
    pq.write_table(pa.Table.from_pylist(merged, schema=schema),
                   OUTPUT / "merged_users.parquet")
    report = {"total_conflicts": len(conflicts), "conflicts": conflicts}
    (OUTPUT / "conflicts.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Merged {len(merged)} unique users; found {len(conflicts)} conflicts.")


if __name__ == "__main__":
    main()
