"""Merge the three user sources in descending priority and report field conflicts."""

import csv
import json
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq


FIELDS = {
    "user_id": ("user_id", "id", "userId"),
    "name": ("full_name", "name", "userName"),
    "email": ("email", "email_address"),
    "created_date": ("registration_date", "created_at", "joined"),
    "status": ("status", "is_active", "active"),
}
SCHEMA = pa.schema([
    pa.field("user_id", pa.int64(), nullable=False),
    pa.field("name", pa.string()),
    pa.field("email", pa.string()),
    pa.field("created_date", pa.string()),
    pa.field("status", pa.string()),
])


def normalize(record):
    result = {}
    for field, aliases in FIELDS.items():
        for alias in aliases:
            value = record.get(alias)
            if value is None or pd.isna(value) or value == "":
                continue
            if field == "user_id":
                # Reject fractional IDs rather than silently truncating them.
                value = int(str(value))
            elif field == "created_date":
                value = pd.Timestamp(value).strftime("%Y-%m-%d")
            elif field == "status" and alias in ("is_active", "active"):
                flag = str(value).strip().lower()
                if flag not in ("true", "false", "1", "0"):
                    raise ValueError(f"Invalid activity flag: {value!r}")
                value = "active" if flag in ("true", "1") else "inactive"
            else:
                value = str(value)
            result[field] = value
            break
    if "user_id" not in result:
        raise ValueError("Record has no user ID")
    return result


def main():
    with Path("/data/source_a/users.json").open() as handle:
        source_a = json.load(handle)
    with Path("/data/source_b/users.csv").open(newline="") as handle:
        source_b = list(csv.DictReader(handle))
    source_c = pq.read_table("/data/source_c/users.parquet").to_pylist()

    users = {}
    for source, records in (
        ("source_a", source_a), ("source_b", source_b), ("source_c", source_c)
    ):
        seen = set()
        for raw in records:
            record = normalize(raw)
            user_id = record.pop("user_id")
            if user_id in seen:
                raise ValueError(f"Duplicate user ID {user_id} in {source}")
            seen.add(user_id)
            users.setdefault(user_id, {})[source] = record

    merged = []
    conflicts = []
    for user_id, sources in sorted(users.items()):
        row = {"user_id": user_id}
        for field in FIELDS:
            if field == "user_id":
                continue
            values = {source: record[field] for source, record in sources.items()
                      if field in record}
            selected = next(iter(values.values()), None)
            row[field] = selected
            if len(set(values.values())) > 1:
                conflicts.append({"user_id": user_id, "field": field,
                                  "values": values, "selected": selected})
        merged.append(row)

    pq.write_table(pa.Table.from_pylist(merged, schema=SCHEMA),
                   "/app/merged_users.parquet")
    Path("/app/conflicts.json").write_text(
        json.dumps({"total_conflicts": len(conflicts), "conflicts": conflicts},
                   indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
