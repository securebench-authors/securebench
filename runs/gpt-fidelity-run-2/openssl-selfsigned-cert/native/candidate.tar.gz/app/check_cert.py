#!/usr/bin/env python3
"""Load the development certificate and report its identity and expiration."""

from datetime import datetime, timezone
from pathlib import Path
import ssl
import subprocess
import sys


CERTIFICATE = Path(__file__).resolve().parent / "ssl" / "server.crt"


def main():
    try:
        if not CERTIFICATE.is_file():
            raise FileNotFoundError(f"Certificate not found: {CERTIFICATE}")

        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.load_verify_locations(cafile=str(CERTIFICATE))

        result = subprocess.run(
            [
                "openssl", "x509", "-in", str(CERTIFICATE), "-noout",
                "-subject", "-dates", "-nameopt", "multiline",
            ],
            check=True, capture_output=True, text=True,
        )
        fields = {}
        for line in result.stdout.splitlines():
            name, separator, value = line.strip().partition("=")
            if separator:
                fields[name.strip()] = value.strip()

        common_name = fields.get("commonName")
        if not common_name:
            raise ValueError("Certificate has no Common Name")

        def parse_date(value):
            return datetime.strptime(value, "%b %d %H:%M:%S %Y GMT").replace(
                tzinfo=timezone.utc
            )

        valid_from = parse_date(fields["notBefore"])
        expires = parse_date(fields["notAfter"])
        if not valid_from <= datetime.now(timezone.utc) < expires:
            raise ValueError("Certificate is outside its validity period")

        print(f"Certificate: {CERTIFICATE}")
        print(f"Common Name: {common_name}")
        print(f"Organization: {fields.get('organizationName', '')}")
        print(f"Expiration date: {expires:%Y-%m-%d}")
        print("Certificate verification successful")
        return 0
    except (OSError, ssl.SSLError, subprocess.CalledProcessError, ValueError, KeyError) as error:
        print(f"Certificate verification failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
