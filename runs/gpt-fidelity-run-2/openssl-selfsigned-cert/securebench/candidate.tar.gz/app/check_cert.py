#!/usr/bin/env python3
"""Load the development TLS certificate and print its verified details."""

from datetime import datetime, timezone
from pathlib import Path
import re
import ssl
import subprocess
import sys


def main():
    certificate = Path(__file__).resolve().parent / "ssl" / "server.crt"
    if not certificate.is_file():
        raise FileNotFoundError(f"Certificate not found: {certificate}")

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.load_verify_locations(cafile=str(certificate))
    result = subprocess.run(
        [
            "openssl", "x509", "-in", str(certificate), "-noout",
            "-subject", "-startdate", "-enddate", "-nameopt", "RFC2253",
        ],
        check=True, capture_output=True, text=True,
    )
    details = dict(line.split("=", 1) for line in result.stdout.splitlines())
    common_name = re.search(r"(?:^|,)CN=([^,]+)", details["subject"])
    if common_name is None:
        raise ValueError("Certificate has no Common Name")
    if common_name.group(1) != "dev-internal.company.local":
        raise ValueError("Certificate Common Name does not match the server")

    starts = datetime.fromtimestamp(
        ssl.cert_time_to_seconds(details["notBefore"]), timezone.utc
    )
    expires = datetime.fromtimestamp(
        ssl.cert_time_to_seconds(details["notAfter"]), timezone.utc
    )
    if not starts <= datetime.now(timezone.utc) < expires:
        raise ValueError("Certificate is outside its validity period")

    subprocess.run(
        ["openssl", "verify", "-CAfile", str(certificate),
         "-check_ss_sig", "-verify_hostname", common_name.group(1),
         str(certificate)],
        check=True, capture_output=True, text=True,
    )
    print(f"Subject: {details['subject']}")
    print(f"Common Name: {common_name.group(1)}")
    print(f"Expiration date: {expires:%Y-%m-%d}")
    print("Certificate verification successful")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, ssl.SSLError, subprocess.CalledProcessError) as error:
        print(f"Certificate verification failed: {error}", file=sys.stderr)
        sys.exit(1)
