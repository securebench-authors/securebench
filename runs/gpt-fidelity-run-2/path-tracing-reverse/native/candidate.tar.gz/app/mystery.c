#include <stdio.h>
#include <math.h>
typedef struct {float x,y,z;} V;
V add(V a,V b){return (V){a.x+b.x,a.y+b.y,a.z+b.z};}
V mul(V a,float b){return (V){a.x*b,a.y*b,a.z*b};}
float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
V norm(V a){float l=sqrtf(dot(a,a));return (V){a.x/l,a.y/l,a.z/l};}
typedef struct {float t;V p,n;int hit;} H;
H sphere(V o,V d){V c={0,-.5f,-5},v=add(o,mul(c,-1));float a=dot(d,d),b=2*dot(v,d),cc=(v.y*v.y+v.x*v.x)+v.z*v.z-1,disc=b*b-(4*a)*cc;H h={0};if(disc<0)return h;float t=(-b-sqrt((double)disc))/(2*a);if(t<.001f)t=(-b+sqrt((double)disc))/(2*a);if(t<.001f)return h;h.t=t;h.p=add(o,mul(d,t));h.n=norm(add(h.p,mul(c,-1)));h.hit=1;return h;}
int cv(float a){a=fmin(fmax(a,0),1);return (int)(a*255.99f);}
int main(){static V image[600][800];V light=norm((V){1,1,-1}),zero={0};fprintf(stderr,"Creating high-resolution image: 800x600\nThis will be downsampled with ffmpeg after rendering\nRendering high-resolution image...\n");for(int y=0;y<600;y++){fprintf(stderr,"\rProgress: %.1f%%",(double)(100.f*y/600.f));for(int x=0;x<800;x++){float u=x/799.f,v=1.f-y/599.f;V d=norm((V){0.f*v+2.6666667f*u-1.3333334f,0.f*u+2.f*v-1.f,0.f*v+0.f*u-1.f});H h=sphere(zero,d);int red=h.hit;float t=-1.5f/d.y;if(fabsf(d.y)>=.0001f&&t>=.001f&&(!h.hit||t<=h.t)){h.hit=1;h.p=add(zero,mul(d,t));h.n=(V){0,1,0};red=0;}V col;if(!h.hit){float a=.5f*(d.y+1.f),b=1.f-a;col=(V){a*.5f+b,a*.7f+b,a+b};}else{H sh=sphere(add(h.p,mul(h.n,.001f)),norm(light));float k=sh.hit?.2f:.2f+.8f*(float)fmax(dot(h.n,light),0);if(red)col=(V){k,.2f*k,.2f*k};else{float a=((int)(floor(h.p.x)+floor(h.p.z))&1)?.4f:.9f;col=(V){a*k,a*k,a*k};}}image[y][x]=col;}}
fprintf(stderr,"\nRendering complete\n");FILE*f=fopen("image.ppm","w");if(f){fprintf(f,"P3\n800 600\n255\n");for(int y=0;y<600;y++)for(int x=0;x<800;x++){V c=image[y][x];fprintf(f,"%d %d %d\n",cv(c.x),cv(c.y),cv(c.z));}fclose(f);fprintf(stderr,"Wrote image to image.ppm\n");}else fprintf(stderr,"Error: Could not open file image.ppm for writing\n");fprintf(stderr,"Done.\n");return 0;}
