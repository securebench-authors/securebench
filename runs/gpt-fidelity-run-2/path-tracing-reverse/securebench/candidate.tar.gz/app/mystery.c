#include <stdio.h>
#include <math.h>
typedef struct{float x,y,z;} V;
V add(V a,V b){return (V){a.x+b.x,a.y+b.y,a.z+b.z};}
V mul(V a,float t){return (V){a.x*t,a.y*t,a.z*t};}
float dot(V a,V b){return (a.x*b.x+a.y*b.y)+a.z*b.z;}
V norm(V a){float l=sqrtf(dot(a,a));return (V){a.x/l,a.y/l,a.z/l};}
typedef struct{float t;V p,n;int hit;} H;
H sphere(V o,V d){V q={o.x,o.y+.5f,o.z+5};float a=dot(d,d),b=2*dot(q,d),c=(q.y*q.y+q.x*q.x)+q.z*q.z-1;float disc=b*b-(4*a)*c;H h={0};if(disc<0)return h;float t=(-(double)b-sqrt((double)disc))/(2*a);if(t<.001f)t=(-(double)b+sqrt((double)disc))/(2*a);if(t<.001f)return h;h.t=t;h.p=add(o,mul(d,t));h.n=norm((V){h.p.x,h.p.y+.5f,h.p.z+5});h.hit=1;return h;}
int cv(float x){return (int)((float)fmin(1,fmax(0,x))*255.99f);}
int main(){
fprintf(stderr,"Creating high-resolution image: 800x600\nThis will be downsampled with ffmpeg after rendering\nRendering high-resolution image...\n");
static V image[600][800];V light=norm((V){1,1,-1});
for(int y=0;y<600;y++){
fprintf(stderr,"\rProgress: %.1f%%",(double)(100.f*y/600.f));
for(int x=0;x<800;x++){
float v=1-y/599.f;V d=norm((V){x/799.f*2.66666674614f-1.33333337307f,v+v-1,-1});
H h=sphere((V){0,0,0},d);int ball=h.hit;
float t=-1.5f/d.y;
if(fabsf(d.y)>=.0001f&&t>=.001f&&(!h.hit||t<=h.t)){h=(H){t,add((V){0,0,0},mul(d,t)),{0,1,0},1};ball=0;}
V col;
if(!h.hit){float t=.5f*(d.y+1),s=1-t;col=(V){t*.5f+s,t*.7f+s,t+s};}
else{V o=add(h.p,mul(h.n,.001f));H sh=sphere(o,norm(light));float k=.2f;if(!sh.hit)k=.2f+.8f*(float)fmax(0,dot(h.n,light));
if(ball)col=(V){k,.2f*k,.2f*k};else {float c=((int)(floor((double)h.p.x)+floor((double)h.p.z))&1)?.4f:.9f;col=(V){c*k,c*k,c*k};}}
image[y][x]=col;
}}
fprintf(stderr,"\nRendering complete\n");FILE*f=fopen("image.ppm","w");if(f){fprintf(f,"P3\n800 600\n255\n");for(int y=0;y<600;y++)for(int x=0;x<800;x++){V c=image[y][x];fprintf(f,"%d %d %d\n",cv(c.x),cv(c.y),cv(c.z));}fclose(f);fprintf(stderr,"Wrote image to image.ppm\n");}else fprintf(stderr,"Error: Could not open file image.ppm for writing\n");fprintf(stderr,"Done.\n");return 0;}
