#if 0
""" # "
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Little-endian base-10^9 integers keep the result exact at any size. */
#define BASE 1000000000U

typedef struct {
    uint32_t *digits;
    size_t length;
    size_t capacity;
} BigInt;

static void reserve(BigInt *value, size_t capacity)
{
    if (capacity <= value->capacity)
        return;
    if (capacity > SIZE_MAX / sizeof(*value->digits)) {
        fputs("Result is too large for available memory.\n", stderr);
        exit(EXIT_FAILURE);
    }
    uint32_t *digits = realloc(value->digits, capacity * sizeof(*digits));
    if (digits == NULL) {
        fputs("Unable to allocate memory for the result.\n", stderr);
        exit(EXIT_FAILURE);
    }
    value->digits = digits;
    value->capacity = capacity;
}

static void add(BigInt *a, const BigInt *b)
{
    size_t length = a->length > b->length ? a->length : b->length;
    reserve(a, length + 1);
    uint64_t carry = 0;
    for (size_t i = 0; i < length; ++i) {
        uint64_t sum = carry;
        if (i < a->length)
            sum += a->digits[i];
        if (i < b->length)
            sum += b->digits[i];
        a->digits[i] = (uint32_t)(sum % BASE);
        carry = sum / BASE;
    }
    a->length = length;
    if (carry != 0)
        a->digits[a->length++] = (uint32_t)carry;
}

int main(int argc, char **argv)
{
    if (argc != 2 || argv[1][0] == '\0') {
        fputs("Usage: main.py.c N (a nonnegative integer)\n", stderr);
        return EXIT_FAILURE;
    }
    size_t n = 0;
    for (const char *p = argv[1]; *p; ++p) {
        if (*p < '0' || *p > '9' ||
            n > (SIZE_MAX - (unsigned)(*p - '0')) / 10) {
            fputs("N must be a nonnegative integer that fits in size_t.\n", stderr);
            return EXIT_FAILURE;
        }
        n = n * 10 + (unsigned)(*p - '0');
    }

    BigInt a = {NULL, 1, 0};
    BigInt b = {NULL, 1, 0};
    reserve(&a, 1);
    reserve(&b, 1);
    a.digits[0] = 0;
    b.digits[0] = 1;
    for (size_t i = 0; i < n; ++i) {
        add(&a, &b);
        BigInt temporary = a;
        a = b;
        b = temporary;
    }

    printf("%u", (unsigned)a.digits[a.length - 1]);
    for (size_t i = a.length - 1; i > 0; --i)
        printf("%09u", (unsigned)a.digits[i - 1]);
    putchar('\n');
    free(a.digits);
    free(b.digits);
    return EXIT_SUCCESS;
}

#if 0
""" # "

import sys


def main():
    if (len(sys.argv) != 2 or not sys.argv[1]
            or any(c < "0" or c > "9" for c in sys.argv[1])):
        print("Usage: main.py.c N (a nonnegative integer)", file=sys.stderr)
        return 1

    # Python 3.12 limits decimal conversions by default; Fibonacci need not.
    sys.set_int_max_str_digits(0)
    n = int(sys.argv[1])
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    print(a)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#endif
