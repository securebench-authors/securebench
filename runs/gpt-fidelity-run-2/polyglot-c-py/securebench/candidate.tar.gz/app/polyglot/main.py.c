#if 0
""" # "
#endif

#include <errno.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Each integer stores base-10^9 digits, least significant first. */
typedef struct {
    uint32_t *digits;
    size_t length;
    size_t capacity;
} Integer;

static void out_of_memory(void)
{
    fputs("Out of memory\n", stderr);
    exit(EXIT_FAILURE);
}

static Integer integer(uint32_t value)
{
    Integer result = {malloc(sizeof(uint32_t)), 1, 1};
    if (!result.digits)
        out_of_memory();
    result.digits[0] = value;
    return result;
}

/* Replace a with a + b, growing its storage as needed. */
static void add(Integer *a, const Integer *b)
{
    size_t length = a->length > b->length ? a->length : b->length;
    if (length == SIZE_MAX)
        out_of_memory();
    if (a->capacity < length + 1) {
        if (length + 1 > SIZE_MAX / sizeof(uint32_t))
            out_of_memory();
        uint32_t *digits = realloc(a->digits, (length + 1) * sizeof(uint32_t));
        if (!digits)
            out_of_memory();
        a->digits = digits;
        a->capacity = length + 1;
    }

    uint64_t carry = 0;
    for (size_t i = 0; i < length; ++i) {
        uint64_t sum = carry;
        if (i < a->length)
            sum += a->digits[i];
        if (i < b->length)
            sum += b->digits[i];
        a->digits[i] = (uint32_t)(sum % 1000000000);
        carry = sum / 1000000000;
    }
    a->length = length;
    if (carry)
        a->digits[a->length++] = (uint32_t)carry;
}

int main(int argc, char **argv)
{
    if (argc != 2 || !argv[1][0])
        goto invalid;
    for (const char *p = argv[1]; *p; ++p)
        if (*p < '0' || *p > '9')
            goto invalid;

    errno = 0;
    uintmax_t n = strtoumax(argv[1], NULL, 10);
    if (errno == ERANGE)
        goto invalid;

    Integer a = integer(0), b = integer(1);
    for (uintmax_t i = 0; i < n; ++i) {
        add(&a, &b);
        Integer temporary = a;
        a = b;
        b = temporary;
    }

    printf("%" PRIu32, a.digits[a.length - 1]);
    for (size_t i = a.length - 1; i > 0; --i)
        printf("%09" PRIu32, a.digits[i - 1]);
    putchar('\n');
    free(a.digits);
    free(b.digits);
    return EXIT_SUCCESS;

invalid:
    fputs("Usage: program N (a nonnegative integer)\n", stderr);
    return EXIT_FAILURE;
}

#if 0
""" # "

import sys


def main():
    if (len(sys.argv) != 2 or not sys.argv[1]
            or any(c < "0" or c > "9" for c in sys.argv[1])):
        print("Usage: program N (a nonnegative integer)", file=sys.stderr)
        return 1

    # Allow arbitrarily long decimal results under Python 3.12.
    sys.set_int_max_str_digits(0)
    n = int(sys.argv[1])
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    print(a)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#endif
