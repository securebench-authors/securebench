# vectorops

Simple vector operations for Python lists.

Install from the local package index:

```sh
pip install --index-url http://localhost:8080/simple vectorops==0.1.0
```

```python
from vectorops import dotproduct

assert 1 == dotproduct([1, 1], [0, 1])
```

`dotproduct` accepts lists of integers or floats. Empty lists return zero;
lists of different lengths raise `ValueError`.

To rebuild and run the local package server from this directory:

```sh
python -m pip install -r requirements-server.txt
python -m build --no-isolation
pypi-server run --host 0.0.0.0 --port 8080 dist
```
