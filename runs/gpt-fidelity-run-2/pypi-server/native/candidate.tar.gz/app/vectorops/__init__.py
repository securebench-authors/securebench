"""Simple vector operations."""

__version__ = "0.1.0"
__all__ = ["dotproduct"]


def dotproduct(a: list[float], b: list[float]) -> float:
    """Return the dot product of two equally sized lists of numbers.

    Raise ValueError if the lists have different lengths.
    """
    if len(a) != len(b):
        raise ValueError("Vectors must have the same length")
    return sum(x * y for x, y in zip(a, b))
