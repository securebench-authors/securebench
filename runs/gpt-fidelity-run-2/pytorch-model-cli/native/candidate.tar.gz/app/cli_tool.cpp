#include "cJSON.h"
#include "lodepng.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

static std::vector<float> tensor(const cJSON* root, const char* key,
                                 int rows, int columns = 0) {
    const cJSON* array = cJSON_GetObjectItemCaseSensitive(root, key);
    if (!cJSON_IsArray(array) || cJSON_GetArraySize(array) != rows)
        throw std::runtime_error(std::string("Invalid tensor: ") + key);
    std::vector<float> result;
    result.reserve(rows * (columns ? columns : 1));
    auto append = [&](const cJSON* item) {
        if (!cJSON_IsNumber(item) || !std::isfinite(item->valuedouble) ||
            !std::isfinite(static_cast<float>(item->valuedouble)))
            throw std::runtime_error(std::string("Invalid number in: ") + key);
        result.push_back(static_cast<float>(item->valuedouble));
    };
    for (const cJSON* row = array->child; row; row = row->next) {
        if (columns) {
            if (!cJSON_IsArray(row) || cJSON_GetArraySize(row) != columns)
                throw std::runtime_error(std::string("Invalid tensor shape: ") + key);
            for (const cJSON* item = row->child; item; item = item->next)
                append(item);
        } else {
            append(row);
        }
    }
    return result;
}

static std::vector<float> linear(const std::vector<float>& input,
                                 const std::vector<float>& weight,
                                 const std::vector<float>& bias, bool relu) {
    std::vector<float> output(bias.size());
    for (size_t i = 0; i < output.size(); ++i) {
        float value = bias[i];
        for (size_t j = 0; j < input.size(); ++j)
            value += weight[i * input.size() + j] * input[j];
        if (!std::isfinite(value))
            throw std::runtime_error("Non-finite model output");
        output[i] = relu ? std::max(0.0f, value) : value;
    }
    return output;
}

int main(int argc, char** argv) {
    try {
        if (argc != 3)
            throw std::runtime_error("Usage: ./cli_tool weights.json image.png");
        std::ifstream file(argv[1], std::ios::binary);
        if (!file) throw std::runtime_error("Cannot open weights file");
        std::string json((std::istreambuf_iterator<char>(file)), {});
        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(
            cJSON_ParseWithOpts(json.c_str(), nullptr, 1), cJSON_Delete);
        if (!root || !cJSON_IsObject(root.get()))
            throw std::runtime_error("Invalid weights JSON");
        auto w1 = tensor(root.get(), "input_layer.weight", 16, 784);
        auto b1 = tensor(root.get(), "input_layer.bias", 16);
        auto w2 = tensor(root.get(), "hidden_layer.weight", 16, 16);
        auto b2 = tensor(root.get(), "hidden_layer.bias", 16);
        auto w3 = tensor(root.get(), "output_layer.weight", 10, 16);
        auto b3 = tensor(root.get(), "output_layer.bias", 10);

        std::vector<unsigned char> pixels;
        unsigned width = 0, height = 0;
        unsigned error = lodepng::decode(pixels, width, height, argv[2]);
        if (error) throw std::runtime_error(lodepng_error_text(error));
        if (width != 28 || height != 28)
            throw std::runtime_error("Expected a 28x28 MNIST image");
        std::vector<float> input(784);
        for (size_t i = 0; i < input.size(); ++i) {
            // Grayscale intensity in [0,1]; alpha composites onto black.
            const unsigned char* p = &pixels[4 * i];
            input[i] = ((0.299f * p[0] + 0.587f * p[1] + 0.114f * p[2])
                        / 255.0f) * (p[3] / 255.0f);
        }
        auto hidden1 = linear(input, w1, b1, true);
        auto hidden2 = linear(hidden1, w2, b2, true);
        auto logits = linear(hidden2, w3, b3, false);
        int digit = static_cast<int>(std::max_element(logits.begin(), logits.end())
                                     - logits.begin());
        std::printf("%d", digit);
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
