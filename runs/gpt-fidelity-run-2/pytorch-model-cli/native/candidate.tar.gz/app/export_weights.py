"""Export the supplied PyTorch state dictionary without requiring PyTorch."""
import collections
import io
import json
import pickle
import struct
import zipfile


def rebuild_tensor(storage, offset, shape, strides, *unused):
    values = storage
    def unpack(dim, index):
        if dim == len(shape):
            return values[index]
        return [unpack(dim + 1, index + i * strides[dim]) for i in range(shape[dim])]
    return unpack(0, offset)


class StateReader(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) == ('collections', 'OrderedDict'):
            return collections.OrderedDict
        if (module, name) == ('torch._utils', '_rebuild_tensor_v2'):
            return rebuild_tensor
        if (module, name) == ('torch', 'FloatStorage'):
            return 'float32'
        raise ValueError(f'Unsupported pickle global: {module}.{name}')

    def persistent_load(self, ref):
        kind, dtype, key, location, count = ref
        if kind != 'storage' or dtype != 'float32':
            raise ValueError('Unsupported tensor storage')
        data = archive.read(prefix + 'data/' + key)
        return struct.unpack(endian + str(count) + 'f', data)


with zipfile.ZipFile('/app/model.pth') as archive:
    name = next(n for n in archive.namelist() if n.endswith('/data.pkl'))
    prefix = name[:-len('data.pkl')]
    endian = '<' if archive.read(prefix + 'byteorder').strip() == b'little' else '>'
    state = StateReader(io.BytesIO(archive.read(name))).load()
with open('/app/weights.json', 'w') as output:
    json.dump(state, output, separators=(',', ':'), allow_nan=False)
    output.write('\n')
