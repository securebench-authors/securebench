#include "cJSON.h"
#include "lodepng.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using Vector = std::vector<float>;

static Vector read_vector(const cJSON* value, int expected) {
    if (!cJSON_IsArray(value) || cJSON_GetArraySize(value) != expected)
        throw std::runtime_error("Invalid weight dimensions");
    Vector result;
    result.reserve(expected);
    const cJSON* item = nullptr;
    cJSON_ArrayForEach(item, value) {
        if (!cJSON_IsNumber(item) || !std::isfinite(item->valuedouble))
            throw std::runtime_error("Invalid weight value");
        float number = static_cast<float>(item->valuedouble);
        if (!std::isfinite(number)) throw std::runtime_error("Weight out of range");
        result.push_back(number);
    }
    return result;
}

struct Layer {
    std::vector<Vector> weights;
    Vector bias;

    Layer(const cJSON* root, const std::string& name, int inputs, int outputs) {
        const cJSON* matrix = cJSON_GetObjectItemCaseSensitive(root, (name + ".weight").c_str());
        if (!cJSON_IsArray(matrix) || cJSON_GetArraySize(matrix) != outputs)
            throw std::runtime_error("Invalid layer dimensions: " + name);
        const cJSON* row = nullptr;
        cJSON_ArrayForEach(row, matrix) weights.push_back(read_vector(row, inputs));
        bias = read_vector(cJSON_GetObjectItemCaseSensitive(root, (name + ".bias").c_str()), outputs);
    }

    Vector forward(const Vector& input, bool relu) const {
        Vector output = bias;
        for (size_t i = 0; i < weights.size(); ++i) {
            for (size_t j = 0; j < input.size(); ++j)
                output[i] += weights[i][j] * input[j];
            if (relu) output[i] = std::max(0.0f, output[i]);
        }
        return output;
    }
};

int main(int argc, char** argv) {
    try {
        if (argc != 3) throw std::runtime_error("Usage: ./cli_tool weights.json image.png");
        std::ifstream file(argv[1], std::ios::binary);
        if (!file) throw std::runtime_error("Cannot open weights file");
        std::string json((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(
            cJSON_ParseWithOpts(json.c_str(), nullptr, true), cJSON_Delete);
        if (!root || !cJSON_IsObject(root.get())) throw std::runtime_error("Invalid weights JSON");
        Layer input(root.get(), "input_layer", 784, 16);
        Layer hidden(root.get(), "hidden_layer", 16, 16);
        Layer output(root.get(), "output_layer", 16, 10);

        std::vector<unsigned char> pixels;
        unsigned width = 0, height = 0;
        unsigned error = lodepng::decode(pixels, width, height, argv[2]);
        if (error) throw std::runtime_error(std::string("Cannot decode PNG: ") + lodepng_error_text(error));
        if (width != 28 || height != 28) throw std::runtime_error("Expected a 28 by 28 MNIST image");
        Vector image(784);
        for (size_t i = 0; i < image.size(); ++i) {
            // Match ToTensor: grayscale intensity in [0, 1], flattened row by row.
            float gray = (0.299f * pixels[4*i] + 0.587f * pixels[4*i+1] + 0.114f * pixels[4*i+2]);
            image[i] = gray / 255.0f;
        }
        Vector logits = output.forward(hidden.forward(input.forward(image, true), true), false);
        int prediction = static_cast<int>(std::max_element(logits.begin(), logits.end()) - logits.begin());
        std::printf("%d", prediction);
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
