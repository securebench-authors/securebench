"""Export the supplied PyTorch state dictionary without requiring PyTorch."""
import collections
import io
import json
import pickle
import struct
import zipfile


def rebuild_tensor(storage, offset, shape, stride, *_):
    def read_dimension(base, dimension):
        if dimension == len(shape):
            return storage[base]
        return [read_dimension(base + i * stride[dimension], dimension + 1)
                for i in range(shape[dimension])]
    return read_dimension(offset, 0)


class StateReader(pickle.Unpickler):
    def find_class(self, module, name):
        allowed = {
            ('collections', 'OrderedDict'): collections.OrderedDict,
            ('torch._utils', '_rebuild_tensor_v2'): rebuild_tensor,
            ('torch', 'FloatStorage'): 'float32',
        }
        if (module, name) not in allowed:
            raise ValueError(f'Unsupported checkpoint type: {module}.{name}')
        return allowed[module, name]

    def persistent_load(self, reference):
        kind, dtype, key, location, count = reference
        if kind != 'storage' or dtype != 'float32':
            raise ValueError('Expected float32 tensor storage')
        data = archive.read(prefix + 'data/' + key)
        return struct.unpack(byte_order + str(count) + 'f', data)


if __name__ == '__main__':
    with zipfile.ZipFile('model.pth') as archive:
        entry = next(n for n in archive.namelist() if n.endswith('/data.pkl'))
        prefix = entry[:-len('data.pkl')]
        byte_order = '<' if archive.read(prefix + 'byteorder') == b'little' else '>'
        weights = StateReader(io.BytesIO(archive.read(entry))).load()
    with open('weights.json', 'w') as output:
        json.dump(weights, output, separators=(',', ':'), allow_nan=False)
        output.write('\n')
