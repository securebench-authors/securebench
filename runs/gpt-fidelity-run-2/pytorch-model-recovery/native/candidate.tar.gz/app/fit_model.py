import hashlib
import json

import torch
from recovered_model import RecoveredModel


def digest(path):
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def main():
    torch.set_num_threads(4)
    torch.manual_seed(0)
    original_hash = digest('/app/weights.pt')
    state = torch.load('/app/weights.pt', map_location='cpu', weights_only=True)
    data = torch.load('/app/dataset.pt', map_location='cpu', weights_only=True)
    src, targets = data['src_sequences'], data['tgt_sequences']
    model = RecoveredModel().eval()
    model.load_state_dict(state, strict=True)
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name.startswith('output_layer.'))

    with torch.no_grad():
        features = model.features(src)
        baseline = torch.nn.functional.mse_loss(model(src), targets).item()
        flat_features = features.reshape(-1, 128).double()
        design = torch.cat([flat_features, torch.ones(flat_features.size(0), 1, dtype=torch.float64)], dim=1)
        solution = torch.linalg.lstsq(design, targets.reshape(-1, 64).double(), driver='gelsd').solution
        model.output_layer.weight.copy_(solution[:-1].T.float())
        model.output_layer.bias.copy_(solution[-1].float())
        tuned = torch.nn.functional.mse_loss(model(src), targets).item()
    assert tuned < baseline, (baseline, tuned)
    changed = [key for key, value in model.state_dict().items() if not torch.equal(value, state[key])]
    assert set(changed) == {'output_layer.weight', 'output_layer.bias'}, changed

    scripted = torch.jit.script(model)
    torch.jit.save(scripted, '/app/model.pt')
    saved = torch.jit.load('/app/model.pt').eval()
    with torch.no_grad():
        saved_loss = torch.nn.functional.mse_loss(saved(src), targets).item()
        torch.testing.assert_close(saved(src), model(src), rtol=0, atol=0)
        # Also exercise the explicit decoder-input signature.
        assert saved(src[:2], src[:2]).shape == targets[:2].shape
    saved_changed = [key for key, value in saved.state_dict().items() if not torch.equal(value, state[key])]
    assert saved_changed == changed
    # This strict load is in memory only; the file retains the tuned weights.
    saved.load_state_dict(state, strict=True)
    with torch.no_grad():
        restored_loss = torch.nn.functional.mse_loss(saved(src), targets).item()
    assert restored_loss == baseline
    assert original_hash == digest('/app/weights.pt')
    report = {
        'original_mse': baseline,
        'updated_mse': saved_loss,
        'changed_tensors': changed,
        'original_weights_sha256': original_hash,
        'strict_original_state_dict_load': True,
        'forward_input': 'src_sequences; decoder input defaults to the source',
        'architecture_assumptions': {'attention_heads': 8, 'activation': 'relu', 'batch_first': True, 'norm_first': False},
    }
    with open('/app/metrics.json', 'w') as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
