from typing import Optional

import torch
from torch import Tensor, nn


class PositionalEncoding(nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer('pe', torch.zeros(1, 5000, 128))
        self.dropout = nn.Dropout(0.1)

    def forward(self, x: Tensor) -> Tensor:
        return self.dropout(x + self.pe[:, :x.size(1)])


class RecoveredModel(nn.Module):
    """Batch-first transformer; an omitted decoder input defaults to src."""

    def __init__(self):
        super().__init__()
        self.embedding = nn.Linear(64, 128)
        self.pos_encoder = PositionalEncoding()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=128, nhead=8, dim_feedforward=256,
            dropout=0.1, activation='relu', batch_first=True,
        )
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer, num_layers=3, enable_nested_tensor=False,
        )
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=128, nhead=8, dim_feedforward=256,
            dropout=0.1, activation='relu', batch_first=True,
        )
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=1)
        self.output_layer = nn.Linear(128, 64)

    @torch.jit.export
    def features(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        encoded_src = self.pos_encoder(self.embedding(src))
        memory = self.transformer_encoder(encoded_src)
        if tgt is None:
            encoded_tgt = encoded_src
        else:
            encoded_tgt = self.pos_encoder(self.embedding(tgt))
        return self.transformer_decoder(encoded_tgt, memory)

    def forward(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        return self.output_layer(self.features(src, tgt))
