"""Recovered transformer and output-only least-squares fitting.

The checkpoint fixes all module names, sizes, and layer counts. Non-parameter
choices are assumed to be 8 attention heads, ReLU, post-layer normalization,
and batch-first sequences. The decoder accepts an optional target sequence;
when omitted it uses the source sequence.
"""
from typing import Optional
import hashlib
import json
from pathlib import Path

import torch
from torch import Tensor, nn


class PositionalEncoding(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.register_buffer('pe', torch.zeros(1, 5000, 128))
        self.dropout = nn.Dropout(0.1)

    def forward(self, x: Tensor) -> Tensor:
        return self.dropout(x + self.pe[:, :x.size(1)])


class RecoveredModel(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.embedding = nn.Linear(64, 128)
        self.pos_encoder = PositionalEncoding()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=128, nhead=8, dim_feedforward=256,
            dropout=0.1, activation='relu', batch_first=True,
        )
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer, num_layers=3, enable_nested_tensor=False,
        )
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=128, nhead=8, dim_feedforward=256,
            dropout=0.1, activation='relu', batch_first=True,
        )
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=1)
        self.output_layer = nn.Linear(128, 64)

    @torch.jit.export
    def features(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        if tgt is None:
            tgt = src
        src_emb = self.pos_encoder(self.embedding(src))
        tgt_emb = self.pos_encoder(self.embedding(tgt))
        memory = self.transformer_encoder(src_emb)
        return self.transformer_decoder(tgt_emb, memory)

    def forward(self, src: Tensor, tgt: Optional[Tensor] = None) -> Tensor:
        return self.output_layer(self.features(src, tgt))


def main() -> None:
    torch.manual_seed(0)
    torch.set_num_threads(2)
    root = Path(__file__).resolve().parent
    weights_path = root / 'weights.pt'
    original_hash = hashlib.sha256(weights_path.read_bytes()).hexdigest()
    original = torch.load(weights_path, map_location='cpu', weights_only=True)
    data = torch.load(root / 'dataset.pt', map_location='cpu', weights_only=True)
    src, target = data['src_sequences'], data['tgt_sequences']
    model = RecoveredModel().eval()
    model.load_state_dict(original, strict=True)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.output_layer.weight.requires_grad_(True)

    # Fit both supported calling conventions to the same target data, keeping
    # the checkpoint's output bias and the entire feature extractor fixed.
    with torch.no_grad():
        source_features = model.features(src)
        paired_features = model.features(src, target)
        initial_source = torch.mean((model(src) - target) ** 2).item()
        initial_paired = torch.mean((model(src, target) - target) ** 2).item()
        design = torch.cat((source_features.reshape(-1, 128),
                            paired_features.reshape(-1, 128))).double()
        response = torch.cat((target.reshape(-1, 64), target.reshape(-1, 64))).double()
        response -= model.output_layer.bias.double()
        solution = torch.linalg.lstsq(design, response, driver='gelsd').solution
        model.output_layer.weight.copy_(solution.T.float())
        final_source = torch.mean((model(src) - target) ** 2).item()
        final_paired = torch.mean((model(src, target) - target) ** 2).item()
    assert final_source < initial_source
    assert final_paired < initial_paired
    changed = [key for key, value in model.state_dict().items()
               if not torch.equal(value, original[key])]
    assert changed == ['output_layer.weight'], changed

    scripted = torch.jit.script(model)
    scripted.save(str(root / 'model.pt'))
    loaded = torch.jit.load(str(root / 'model.pt'), map_location='cpu').eval()
    with torch.no_grad():
        torch.testing.assert_close(loaded(src), model(src), rtol=0, atol=0)
        torch.testing.assert_close(loaded(src, target), model(src, target), rtol=0, atol=0)
    assert [key for key, value in loaded.state_dict().items()
            if not torch.equal(value, original[key])] == ['output_layer.weight']
    loaded.load_state_dict(original, strict=True)
    with torch.no_grad():
        assert torch.mean((loaded(src) - target) ** 2).item() == initial_source
        assert torch.mean((loaded(src, target) - target) ** 2).item() == initial_paired
    assert hashlib.sha256(weights_path.read_bytes()).hexdigest() == original_hash
    metrics = {
        'source_only': {'original_mse': initial_source, 'updated_mse': final_source},
        'source_and_target': {'original_mse': initial_paired, 'updated_mse': final_paired},
        'changed_keys': changed,
        'original_weights_sha256': original_hash,
        'strict_original_weight_load_verified': True,
        'assumptions': {'nhead': 8, 'batch_first': True, 'activation': 'relu',
                        'norm_first': False, 'decoder_default_input': 'src'},
    }
    (root / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    print(json.dumps(metrics, indent=2))


if __name__ == '__main__':
    main()
