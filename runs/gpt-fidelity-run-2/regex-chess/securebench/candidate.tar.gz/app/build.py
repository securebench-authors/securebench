import json,re
from pathlib import Path
rules=[]
king_rules=[]
def add(p,r): rules.append([p,r])
add(r'^([^ ]+) w ([KQkq-]+) ([a-h][36]|-)(?: .*)?$',r'@\1|\2|\3\n')
for n in range(1,9): add(str(n)+r'(?=[^\n]*\|)', '.'*n)
add('/', '')

def runs(chars):
    out=''; i=0
    while i<len(chars):
        j=i+1
        while j<len(chars) and chars[j]==chars[i]: j+=1
        s=chars[i]; count=j-i
        out+=s if count==1 else s+'{'+str(count)+'}'
        i=j
    return out

def attacks(target):
    tr,tc=divmod(target,8); options=[]
    def add_attack(src,token,path=()):
        constraints={src:token,**{x:r'\.' for x in path}}
        end=max(constraints)+1
        options.append(runs([constraints.get(i,'.') for i in range(end)]))
    for dr,dc in [(-1,-1),(-1,1)]:
        r,c=tr+dr,tc+dc
        if 0<=r<8 and 0<=c<8: add_attack(r*8+c,'p')
    for dr,dc in [(a,b) for a,b in [(1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)]]:
        r,c=tr+dr,tc+dc
        if 0<=r<8 and 0<=c<8: add_attack(r*8+c,'n')
    for dr in [-1,0,1]:
        for dc in [-1,0,1]:
            if not(dr or dc): continue
            r,c=tr+dr,tc+dc
            if 0<=r<8 and 0<=c<8: add_attack(r*8+c,'k')
            path=[]
            while 0<=r<8 and 0<=c<8:
                src=r*8+c
                add_attack(src,'[bq]' if dr and dc else '[rq]',path)
                path.append(src);r+=dr;c+=dc
    return '(?:'+'|'.join(options)+')'

def move(src,dst,piece,path=(),ep='-',extra=None,rights='',special=None):
    constraints={src:piece,dst:'[prnbq.]'}
    constraints.update({x:r'\.' for x in path})
    changes={src:'.',dst:None}
    if special in ('pawn','castle_k','castle_q'): constraints[dst]=r'\.'
    if special=='capture': constraints[dst]='[prnbq]'
    if special=='ep':
        constraints[dst]=r'\.'
        cap=src//8*8+dst%8
        constraints[cap]='p';changes[cap]='.'
    if extra:
        for pos,(match,value) in extra.items(): constraints[pos]=match;changes[pos]=value
    parts=[];output=[]; group=0;source_group=None;i=0
    while i<64:
        if i in changes:
            if i==src:
                group+=1;source_group=group;parts.append('('+constraints[i]+')')
            else: parts.append(constraints[i])
            output.append(changes[i] if changes[i] is not None else ('Q' if piece=='P' and dst<8 else ('SOURCE',)))
            i+=1
        else:
            j=i+1
            while j<64 and j not in changes:j+=1
            group+=1;parts.append('('+runs([constraints.get(k,'.') for k in range(i,j)])+')')
            output.append('\\g<'+str(group)+'>');i=j
    output=[('\\g<'+str(source_group)+'>') if x==('SOURCE',) else x for x in output]
    group+=1;rg=group
    tail=r'\|([KQkq-]+)\|'
    tail+=special_ep if special=='ep' else r'(?:[a-h][36]|-)'
    # Castling checks refer to the starting board.
    pre=''
    if special in ('castle_k','castle_q'):
        transit=61 if special=='castle_k' else 59
        pre='(?!'+attacks(60)+')(?!'+attacks(transit)+')'
        right='K' if special=='castle_k' else 'Q'
        pre+=r'(?=.{64}\|[KQkq-]*'+right+')'
    flags=rights
    if piece=='K':flags+='KQ'
    if src==56:flags+='Q'
    if src==63:flags+='K'
    if dst==0:flags+='q'
    if dst==7:flags+='k'
    flags=''.join(dict.fromkeys(flags)) or '-'
    add_move = (lambda p,r: king_rules.append([p,r])) if piece=='K' else add
    add_move('(?m)^@'+pre+''.join(parts)+tail+'$',r'\g<0>\n!'+''.join(output)+'|\\g<'+str(rg)+'>|'+ep+'|'+flags)

# Sliders.
for src in range(64):
    sr,sc=divmod(src,8)
    for dr,dc in [(a,b) for a in [-1,0,1] for b in [-1,0,1] if a or b]:
        path=[];r,c=sr+dr,sc+dc
        while 0<=r<8 and 0<=c<8:
            dst=r*8+c
            move(src,dst,'[BQ]' if dr and dc else '[RQ]',path)
            path.append(dst);r+=dr;c+=dc
    for dr,dc in [(1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)]:
        r,c=sr+dr,sc+dc
        if 0<=r<8 and 0<=c<8:move(src,r*8+c,'N')
    for dr in [-1,0,1]:
        for dc in [-1,0,1]:
            r,c=sr+dr,sc+dc
            if (dr or dc) and 0<=r<8 and 0<=c<8:move(src,r*8+c,'K')
    if 1<=sr<=6:
        move(src,src-8,'P',special='pawn')
        if sr==6:move(src,src-16,'P',path=[src-8],special='pawn',ep=chr(97+sc)+'3')
        for dc in [-1,1]:
            if 0<=sc+dc<8:
                dst=src-8+dc
                move(src,dst,'P',special='capture')
                if sr==3:
                    special_ep=chr(97+sc+dc)+'6'
                    move(src,dst,'P',special='ep')
move(60,62,'K',path=[61],extra={63:('R','.'),61:(r'\.','R')},special='castle_k')
move(60,58,'K',path=[57,59],extra={56:('R','.'),59:(r'\.','R')},special='castle_q')

rules.extend(reversed(king_rules))

# Remove candidates with an attacked white king.
for k in range(64): add(r'(?m)^!(?=.{'+str(k)+'}K)'+attacks(k)+r'[^\n]*\n','')
# Remove rights invalidated by movement/capture; flags are in the last field.
for right in 'KQkq':
    add(r'(?m)(^!.{64}\|[KQkq-]*)'+right+r'([KQkq-]*\|[^|\n]*\|[KQkq-]*'+right+r'[KQkq-]*$)',r'\g<1>\g<2>')
add(r'(?m)^(@[^\n]*\n)','')
add(r'(?m)^(!.{64})\|\|',r'\1|-|')
add(r'(?m)\|[KQkq-]+$','') # discard flags
# Insert rank separators before compressing the board.
add(r'(?m)^!(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})(.{8})\|',r'\1/\2/\3/\4/\5/\6/\7/\8 b ')
add(r'\|',' ')
for n in range(8,0,-1):add(r'\.'*n,str(n))
add(r'(?m)^(.+)$',r'\1 0 0')
add(r'\n\Z','')
Path('/app/re.json').write_text(json.dumps(rules,separators=(',',':')))
print(len(rules),Path('/app/re.json').stat().st_size)
