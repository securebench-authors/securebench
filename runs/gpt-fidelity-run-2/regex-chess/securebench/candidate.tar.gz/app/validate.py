import chess,random,re,json,time
rules=[(re.compile(p),r) for p,r in json.load(open('/app/re.json'))]
def run(fen):
    for p,r in rules:fen=p.sub(r,fen)
    return fen.splitlines()
def verify(board):
    actual=run(board.fen());expected=set()
    for m in board.legal_moves:
        if m.promotion and m.promotion!=chess.QUEEN:continue
        b=board.copy();b.push(m)
        expected.add(' '.join(b.fen(en_passant='fen').split()[:4]))
    got=[' '.join(x.split()[:4]) for x in actual]
    if len(got)!=len(set(got)) or set(got)!=expected:
        print('FAIL',board.fen(),'extra',set(got)-expected,'missing',expected-set(got),flush=True)
        raise AssertionError

fens=[
'rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1',
'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1',
'4k3/8/8/8/8/8/8/R3K1nR w KQ - 0 1',
'4k3/8/8/8/8/8/8/R1n1K2R w KQ - 0 1',
'4k3/8/8/8/8/8/8/r3K2R w K - 0 1',
'4k3/8/8/8/8/8/8/R3K2r w Q - 0 1',
'4kr2/8/8/8/8/8/8/R3K2R w KQ - 0 1',
'3rk3/8/8/8/8/8/8/R3K2R w KQ - 0 1',
'4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
'4r1k1/8/8/3pP3/8/8/8/4K3 w - d6 0 1',
'7k/8/8/r4pPK/8/8/8/8 w - f6 0 1',
'8/8/3k4/3pP3/4K3/8/8/8 w - d6 0 1',
'r3k2r/1P4P1/8/8/8/8/8/4K3 w kq - 0 1',
'7k/8/8/8/8/8/5q2/7K w - - 0 1',
'7k/8/8/8/8/5q2/6q1/7K w - - 0 1',
]
start=time.monotonic()
for fen in fens:verify(chess.Board(fen))
print('Targeted positions passed:',len(fens),flush=True)
rng=random.Random(20261112);count=0
for game in range(12):
    b=chess.Board()
    for ply in range(200):
        if b.is_game_over():break
        if b.turn==chess.WHITE:
            verify(b);count+=1
        moves=list(b.legal_moves)
        # Favor captures and pawn moves to exercise open boards and promotion.
        weights=[4 if b.is_capture(m) else 2 if b.piece_at(m.from_square).piece_type==chess.PAWN else 1 for m in moves]
        b.push(rng.choices(moves,weights)[0])
    print('Random game',game+1,'positions',count,'seconds',round(time.monotonic()-start,1),flush=True)
print('All passed',count+len(fens),flush=True)
