; A metacircular evaluator for interp.py.  Environments are mutable frames
; linked to their lexical parents.  Each frame holds a search tree of mutable
; (name . value) bindings, so closures see subsequent define and set! changes.

(define (ev-frame parent) (cons '() parent))

(define (ev-find-in name tree)
  (cond ((null? tree) #f)
        ((eq? name (car (car tree))) (car tree))
        ((< name (car (car tree))) (ev-find-in name (car (cdr tree))))
        (else (ev-find-in name (cdr (cdr tree))))))

(define (ev-insert name value tree)
  (cond ((null? tree) (cons (cons name value) (cons '() '())))
        ((eq? name (car (car tree))) (set-cdr! (car tree) value) tree)
        ((< name (car (car tree)))
         (set-car! (cdr tree) (ev-insert name value (car (cdr tree)))) tree)
        (else
         (set-cdr! (cdr tree) (ev-insert name value (cdr (cdr tree)))) tree)))

(define (ev-find name env)
  (if (null? env)
      #f
      (let ((binding (ev-find-in name (car env))))
        (if binding binding (ev-find name (cdr env))))))

(define (ev-define name value env)
  (set-car! env (ev-insert name value (car env))))

; Every interpreted procedure is a host procedure taking ONE argument list.
; This supplies apply without a host apply primitive, and keeps procedures
; distinct from pairs, including when displayed inside other data structures.
(define (ev-closure params body env)
  (lambda (args)
    (ev-sequence body (ev-bind params args (ev-frame env)))))

(define (ev-bind params args env)
  (if (null? params)
      env
      (begin
        (ev-define (car params) (car args) env)
        (ev-bind (cdr params) (cdr args) env))))

; Tail positions return a private, delayed evaluation.  The driver executes
; these in successively larger balanced batches: interp.py itself has no tail
; call optimization, so even the trampoline must avoid a linear recursive loop.
(define ev-bounce-tag (cons 'bounce '()))

(define (ev-bounce? value)
  (if (pair? value) (eq? (car value) ev-bounce-tag) #f))

(define (ev-later expr env)
  (cons ev-bounce-tag (lambda () (ev-eval expr env))))

(define (ev-drive value depth)
  (if (ev-bounce? value)
      (if (= depth 0)
          ((cdr value))
          (ev-drive (ev-drive value (- depth 1)) (- depth 1)))
      value))

(define (ev-finish value depth)
  (if (ev-bounce? value)
      (ev-finish (ev-drive value depth) (+ depth 1))
      value))

(define (ev-value expr env)
  (ev-finish (ev-eval expr env) 0))

(define (ev-sequence body env)
  (if (null? body)
      '()
      (if (null? (cdr body))
          (ev-later (car body) env)
          (begin (ev-value (car body) env)
                 (ev-sequence (cdr body) env)))))

(define (ev-arguments expressions env)
  (if (null? expressions)
      '()
      (cons (ev-value (car expressions) env)
            (ev-arguments (cdr expressions) env))))

(define (ev-apply proc args)
  (proc args))

(define (ev-let-bind bindings outer inner)
  (if (null? bindings)
      inner
      (begin
        (ev-define (car (car bindings))
                   (ev-value (car (cdr (car bindings))) outer)
                   inner)
        (ev-let-bind (cdr bindings) outer inner))))

(define (ev-cond clauses env)
  (if (null? clauses)
      '()
      (let ((clause (car clauses)))
        (if (if (eq? (car clause) 'else) #t (ev-value (car clause) env))
            (ev-sequence (cdr clause) env)
            (ev-cond (cdr clauses) env)))))

(define (ev-eval expr env)
  (cond
    ((symbol? expr) (cdr (ev-find expr env)))
    ((not (pair? expr)) expr)
    ((eq? (car expr) 'quote) (car (cdr expr)))
    ((eq? (car expr) 'if)
     (if (ev-value (car (cdr expr)) env)
         (ev-later (car (cdr (cdr expr))) env)
         (if (null? (cdr (cdr (cdr expr))))
             '()
             (ev-later (car (cdr (cdr (cdr expr)))) env))))
    ((eq? (car expr) 'define)
     (let ((name (car (cdr expr))) (body (cdr (cdr expr))))
       (if (pair? name)
           (ev-define (car name) (ev-closure (cdr name) body env) env)
           (ev-define name (ev-value (car body) env) env))))
    ((eq? (car expr) 'set!)
     (set-cdr! (ev-find (car (cdr expr)) env)
               (ev-value (car (cdr (cdr expr))) env)))
    ((eq? (car expr) 'lambda)
     (ev-closure (car (cdr expr)) (cdr (cdr expr)) env))
    ((eq? (car expr) 'let)
     (ev-sequence (cdr (cdr expr))
                  (ev-let-bind (car (cdr expr)) env (ev-frame env))))
    ((eq? (car expr) 'begin) (ev-sequence (cdr expr) env))
    ((eq? (car expr) 'progn) (ev-sequence (cdr expr) env))
    ((eq? (car expr) 'cond) (ev-cond (cdr expr) env))
    (else (ev-apply (ev-value (car expr) env)
                    (ev-arguments (cdr expr) env)))))

; Primitive adapters take one list, avoiding any dependence on a host apply
; primitive or rest parameters (neither is implemented by interp.py).
(define (ev-install env name implementation)
  (ev-define name implementation env))

(define (ev-sum args)
  (if (null? args) 0 (+ (car args) (ev-sum (cdr args)))))

(define (ev-product args)
  (if (null? args) 1 (* (car args) (ev-product (cdr args)))))

; Host and/or use Python truthiness, unlike the Scheme if special form.
(define (ev-truth value)
  (cond ((null? value) #f)
        ((number? value) (not (= value 0)))
        (else (and value #t))))

(define (ev-and args)
  (if (null? args) #t
      (if (ev-truth (car args)) (ev-and (cdr args)) #f)))

(define (ev-or args)
  (if (null? args) #f
      (if (ev-truth (car args)) #t (ev-or (cdr args)))))

(define (ev-global)
  (let ((env (ev-frame '())))
    (ev-define 'else #t env)
    (ev-install env '+ (lambda (a) (ev-sum a)))
    (ev-install env '* (lambda (a) (ev-product a)))
    (ev-install env '- (lambda (a)
      (if (null? (cdr a)) (- (car a)) (- (car a) (car (cdr a))))))
    (ev-install env '/ (lambda (a) (/ (car a) (car (cdr a)))))
    (ev-install env '= (lambda (a) (= (car a) (car (cdr a)))))
    (ev-install env '< (lambda (a) (< (car a) (car (cdr a)))))
    (ev-install env '> (lambda (a) (> (car a) (car (cdr a)))))
    (ev-install env '<= (lambda (a) (<= (car a) (car (cdr a)))))
    (ev-install env '>= (lambda (a) (>= (car a) (car (cdr a)))))
    (ev-install env 'cons (lambda (a) (cons (car a) (car (cdr a)))))
    (ev-install env 'car (lambda (a) (car (car a))))
    (ev-install env 'cdr (lambda (a) (cdr (car a))))
    (ev-install env 'null? (lambda (a) (null? (car a))))
    (ev-install env 'pair? (lambda (a) (pair? (car a))))
    (ev-install env 'eq? (lambda (a) (eq? (car a) (car (cdr a)))))
    (ev-install env 'equal? (lambda (a) (equal? (car a) (car (cdr a)))))
    (ev-install env 'not (lambda (a) (not (car a))))
    (ev-install env 'and (lambda (a) (ev-and a)))
    (ev-install env 'or (lambda (a) (ev-or a)))
    (ev-install env 'getchr (lambda (a) (getchr)))
    (ev-install env 'putchr (lambda (a) (putchr (car a))))
    (ev-install env 'chr (lambda (a) (chr (car a))))
    (ev-install env 'read (lambda (a) (read)))
    (ev-install env 'symbol (lambda (a) (symbol (car a))))
    (ev-install env 'symbol? (lambda (a) (symbol? (car a))))
    (ev-install env 'string? (lambda (a) (string? (car a))))
    (ev-install env 'number? (lambda (a) (number? (car a))))
    (ev-install env 'set-car! (lambda (a) (set-car! (car a) (car (cdr a)))))
    (ev-install env 'set-cdr! (lambda (a) (set-cdr! (car a) (car (cdr a)))))
    (ev-install env 'display (lambda (a) (display (car a))))
    (ev-install env 'newline (lambda (a) (newline)))
    (ev-install env 'fopen (lambda (a) (fopen (car a) (car (cdr a)))))
    (ev-install env 'fclose (lambda (a) (fclose (car a))))
    (ev-install env 'fgetchr (lambda (a) (fgetchr (car a))))
    (ev-install env 'fputchr (lambda (a) (fputchr (car a) (car (cdr a)))))
    (ev-install env 'fdisplay (lambda (a) (fdisplay (car a) (car (cdr a)))))
    (ev-install env 'fread (lambda (a) (fread (car a))))
    env))

; Consume only the path line.  All remaining stdin belongs to the program.
(define (ev-path)
  (let ((ch (getchr)))
    (if (= ch 10) '() (cons ch (ev-path)))))

; fread supplies the host's literal objects (including its String type), but
; consumes whole lines and discards trailing expressions.  A second cursor
; tracks the actual expression boundary.  Usually both cursors finish on the
; same line; reopen the parsing cursor only when that line has another form.
; This also distinguishes a top-level () from end of file.
(define ev-source-port #f)
(define ev-parse-port #f)
(define ev-source-name #f)
(define ev-source-char -1)
(define ev-source-offset -1)

(define (ev-source-next)
  (set! ev-source-char (fgetchr ev-source-port))
  (set! ev-source-offset (+ ev-source-offset 1)))

(define (ev-space? ch)
  (or (= ch 32) (and (>= ch 9) (<= ch 13))))

(define (ev-scan-comment)
  (if (if (= ev-source-char -1) #f (not (= ev-source-char 10)))
      (begin (ev-source-next) (ev-scan-comment))))

(define (ev-scan-space)
  (cond ((ev-space? ev-source-char)
         (ev-source-next) (ev-scan-space))
        ((= ev-source-char 59)
         (ev-scan-comment) (ev-scan-space))))

(define (ev-scan-string)
  (cond ((= ev-source-char -1) '())
        ((= ev-source-char 34) (ev-source-next))
        ((= ev-source-char 92)
         (ev-source-next) (ev-source-next) (ev-scan-string))
        (else (ev-source-next) (ev-scan-string))))

(define (ev-scan-atom)
  (if (or (= ev-source-char -1) (ev-space? ev-source-char)
          (= ev-source-char 40) (= ev-source-char 41)
          (= ev-source-char 39) (= ev-source-char 59))
      '()
      (begin (ev-source-next) (ev-scan-atom))))

(define (ev-scan-list)
  (ev-scan-space)
  (cond ((= ev-source-char -1) '())
        ((= ev-source-char 41) (ev-source-next))
        (else (ev-scan-form) (ev-scan-list))))

(define (ev-scan-form)
  (ev-scan-space)
  (cond ((= ev-source-char 40) (ev-source-next) (ev-scan-list))
        ((= ev-source-char 39) (ev-source-next) (ev-scan-form))
        ((= ev-source-char 34) (ev-source-next) (ev-scan-string))
        (else (ev-scan-atom))))

; Divide the work to keep the host stack bounded when seeking by reading.
(define (ev-skip-chars port count)
  (if (> count 0)
      (if (= count 1)
          (fgetchr port)
          (let ((half (/ count 2)))
            (ev-skip-chars port half)
            (ev-skip-chars port (- count half))))))

(define (ev-line-tail)
  (cond ((= ev-source-char 59) (ev-scan-comment))
        ((if (= ev-source-char 10) #f (ev-space? ev-source-char))
         (ev-source-next) (ev-line-tail))))

(define (ev-align-parser)
  (ev-line-tail)
  (cond ((= ev-source-char 10) (ev-source-next))
        ((= ev-source-char -1) '())
        (else
          (fclose ev-parse-port)
          (set! ev-parse-port (fopen ev-source-name "r"))
          (ev-skip-chars ev-parse-port ev-source-offset))))

(define (ev-run env)
  (ev-scan-space)
  (if (= ev-source-char -1)
      (begin (fclose ev-parse-port) (fclose ev-source-port))
      (let ((expr (fread ev-parse-port)))
        (ev-scan-form)
        (ev-align-parser)
        (ev-value expr env)
        (ev-run env))))

(set! ev-source-name (symbol (ev-path)))
(set! ev-source-port (fopen ev-source-name "r"))
(set! ev-parse-port (fopen ev-source-name "r"))
(ev-source-next)
(ev-run (ev-global))
