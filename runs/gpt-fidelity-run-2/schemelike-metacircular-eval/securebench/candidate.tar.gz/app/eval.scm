;; A metacircular evaluator for interp.py.  Only the host's primitives are
;; used: in particular, fread supplies the same reader used by that language.
;; Each source form is placed on its own line (or group of balanced lines),
;; as required by fread.  No input from the target program is read in advance.

;; An environment is (binding-tree . parent).  Each tree node contains
;; ((name . value) . (left . right)).  Search trees keep lookup shallow even
;; when this evaluator is itself being interpreted.
(define (ev-node name value)
  (cons (cons name value) (cons '() '())))

(define (ev-tree-find name tree)
  (if (null? tree)
      #f
      (let ((binding (car tree)))
        (cond ((eq? name (car binding)) binding)
              ((< name (car binding))
               (ev-tree-find name (car (cdr tree))))
              (else (ev-tree-find name (cdr (cdr tree))))))))

(define (ev-tree-put! name value tree)
  (let ((binding (car tree)) (branches (cdr tree)))
    (cond ((eq? name (car binding)) (set-cdr! binding value))
          ((< name (car binding))
           (if (null? (car branches))
               (set-car! branches (ev-node name value))
               (ev-tree-put! name value (car branches))))
          (else
           (if (null? (cdr branches))
               (set-cdr! branches (ev-node name value))
               (ev-tree-put! name value (cdr branches)))))))

(define (ev-define! name value env)
  (if (null? (car env))
      (set-car! env (ev-node name value))
      (ev-tree-put! name value (car env))))

(define (ev-binding name env)
  (if (null? env)
      ;; Force the host's undefined-variable error rather than return a value.
      (ev-undefined-variable name)
      (let ((binding (ev-tree-find name (car env))))
        (if binding binding (ev-binding name (cdr env))))))

(define (ev-bind! params args env)
  (if (null? params)
      (if (null? args) '() (ev-arity-mismatch))
      (if (null? args)
          (ev-arity-mismatch)
          (begin
            (ev-define! (car params) (car args) env)
            (ev-bind! (cdr params) (cdr args) env)))))

;; Both closures and primitive adapters are host procedures accepting a list
;; of arguments.  Keeping procedures opaque also preserves pair? and display,
;; including when the host is another copy of this evaluator.
(define (ev-closure params body env)
  (lambda (args)
    (let ((inner (cons '() env)))
      (ev-bind! params args inner)
      (ev-sequence body inner))))

(define (ev-sequence body env)
  (if (null? body)
      '()
      (let ((value (ev-eval (car body) env)))
        (if (null? (cdr body))
            value
            (ev-sequence (cdr body) env)))))

(define (ev-arguments expressions env)
  (if (null? expressions)
      '()
      (let ((first (ev-eval (car expressions) env)))
        (cons first (ev-arguments (cdr expressions) env)))))

(define (ev-apply proc args)
  (proc args))

(define (ev-let! bindings outer inner)
  (if (null? bindings)
      '()
      (let ((binding (car bindings)))
        (ev-define! (car binding)
                    (ev-eval (car (cdr binding)) outer) inner)
        (ev-let! (cdr bindings) outer inner))))

(define (ev-cond clauses env)
  (if (null? clauses)
      '()
      (let ((clause (car clauses)))
        (if (if (eq? (car clause) 'else)
                #t
                (ev-eval (car clause) env))
            (ev-sequence (cdr clause) env)
            (ev-cond (cdr clauses) env)))))

(define (ev-eval expr env)
  (cond
    ((symbol? expr) (cdr (ev-binding expr env)))
    ((not (pair? expr)) expr)
    (else
     (let ((op (car expr)) (args (cdr expr)))
       (cond
         ((eq? op 'quote) (car args))
         ((eq? op 'if)
          (if (ev-eval (car args) env)
              (ev-eval (car (cdr args)) env)
              (if (null? (cdr (cdr args)))
                  '()
                  (ev-eval (car (cdr (cdr args))) env))))
         ((eq? op 'define)
          (let ((name (car args)))
            (ev-define!
              (if (pair? name) (car name) name)
              (if (pair? name)
                  (ev-closure (cdr name) (cdr args) env)
                  (ev-eval (car (cdr args)) env))
              env))
          '())
         ((eq? op 'set!)
          (let ((value (ev-eval (car (cdr args)) env)))
            (set-cdr! (ev-binding (car args) env) value))
          '())
         ((eq? op 'lambda) (ev-closure (car args) (cdr args) env))
         ((eq? op 'let)
          (let ((inner (cons '() env)))
            (ev-let! (car args) env inner)
            (ev-sequence (cdr args) inner)))
         ((eq? op 'begin) (ev-sequence args env))
         ((eq? op 'progn) (ev-sequence args env))
         ((eq? op 'cond) (ev-cond args env))
         (else
          (let ((proc (ev-eval op env)))
            (ev-apply proc (ev-arguments args env)))))))))

;; There is no host apply primitive.  Adapters accept an argument list and
;; invoke the host function with its fixed arity; variadic primitives fold.
(define (ev-unary fn)
  (lambda (args) (fn (car args))))

(define (ev-binary fn)
  (lambda (args) (fn (car args) (car (cdr args)))))

(define (ev-zero fn)
  (lambda (args) (fn)))

(define (ev-fold fn value args)
  (if (null? args)
      value
      (ev-fold fn (fn value (car args)) (cdr args))))

(define (ev-global-environment)
  (let ((env (cons '() '())))
    (define (install name fn)
      (ev-define! name fn env))
    ;; Insertion order spreads the binding tree across the symbol alphabet.
    (ev-define! 'else #t env)
    (install 'null? (ev-unary null?))
    (install 'cons (ev-binary cons))
    (install 'symbol? (ev-unary symbol?))
    (install 'fopen (ev-binary fopen))
    (install 'set-car! (ev-binary set-car!))
    (install 'car (ev-unary car))
    (install 'cdr (ev-unary cdr))
    (install 'pair? (ev-unary pair?))
    (install 'number? (ev-unary number?))
    (install 'string? (ev-unary string?))
    (install 'symbol (ev-unary symbol))
    (install 'set-cdr! (ev-binary set-cdr!))
    (install 'display (ev-unary display))
    (install 'newline (ev-zero newline))
    (install 'getchr (ev-zero getchr))
    (install 'putchr (ev-unary putchr))
    (install 'chr (ev-unary chr))
    (install 'read (ev-zero read))
    (install 'fclose (ev-unary fclose))
    (install 'fgetchr (ev-unary fgetchr))
    (install 'fputchr (ev-binary fputchr))
    (install 'fdisplay (ev-binary fdisplay))
    (install 'fread (ev-unary fread))
    (install 'not (ev-unary not))
    (install 'eq? (ev-binary eq?))
    (install 'equal? (ev-binary equal?))
    (install '< (ev-binary <))
    (install '> (ev-binary >))
    (install '= (ev-binary =))
    (install '<= (ev-binary <=))
    (install '>= (ev-binary >=))
    (install '/ (ev-binary /))
    (install '- (lambda (args)
                  (if (null? (cdr args))
                      (- (car args))
                      (- (car args) (car (cdr args))))))
    (install '+ (lambda (args) (ev-fold + 0 args)))
    (install '* (lambda (args) (ev-fold * 1 args)))
    ;; Delegate truthiness to the host: these are eager Python all/any,
    ;; where zero and the empty list are false, unlike an if condition.
    (install 'and (lambda (args) (ev-fold and #t args)))
    (install 'or (lambda (args) (ev-fold or #f args)))
    env))

;; Read a pathname, not an S-expression: spaces and punctuation in paths are
;; ordinary characters.  Consume exactly the newline terminating this line.
(define (ev-reverse chars result)
  (if (null? chars)
      result
      (ev-reverse (cdr chars) (cons (car chars) result))))

(define (ev-read-path chars)
  (let ((ch (getchr)))
    (if (= ch 10)
        (symbol (ev-reverse chars '()))
        (ev-read-path (cons ch chars)))))

(define (ev-run file env)
  (let ((expr (fread file)))
    (if (null? expr)
        (fclose file)
        (begin
          (ev-eval expr env)
          (ev-run file env)))))

(let ((file (fopen (ev-read-path '()) "r")))
  (if file
      (ev-run file (ev-global-environment))
      (display "Error: cannot open input file")))
