#!/usr/bin/env python3
"""Find the hurdle jump in a video from the supplied fixed camera.

Usage: python /app/jump_analyzer.py /path/to/video.mp4
Writes /app/output.toml. Frame numbers are zero based. Takeoff is the
last frame of the final push off; landing is the first subsequent contact.
Only OpenCV, NumPy, TOML, and the Python standard library are used.
"""

import sys

import cv2
import numpy as np


# Camera calibration, expressed as fractions so rounding is consistent.
HURDLE_X = 0.515
OUTPUT_PATH = "/app/output.toml"


def _observe(frame, background):
    """Return the runner's horizontal position and lowest visible shoe point."""
    height, width = frame.shape[:2]
    blurred = cv2.GaussianBlur(frame, (5, 5), 0)
    difference = blurred.astype(np.int16) - background
    # Correct uniform exposure changes using the mostly static image.
    offset = np.median(difference[::12, ::12], axis=(0, 1))
    distance = np.max(np.abs(difference - offset), axis=2)
    mask = (distance > 35).astype(np.uint8)
    mask[:int(0.04 * height)] = 0
    mask[int(0.76 * height):] = 0
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE,
                            np.ones((5, 5), dtype=np.uint8))
    count, labels, stats, centers = cv2.connectedComponentsWithStats(mask)
    candidates = []
    for label in range(1, count):
        x, y, w, h, area = stats[label]
        # Fence/foliage changes are usually wide, short, or above the track.
        if (area >= 0.0045 * width * height
                and h >= 0.18 * height
                and w < 0.48 * width
                and y + h >= 0.40 * height):
            candidates.append(label)
    if not candidates:
        return None
    label = max(candidates, key=lambda k: stats[k, cv2.CC_STAT_AREA])
    ys, xs = np.nonzero(labels == label)
    # Ignore a few isolated pixels at the outline of the segmentation.
    bottom = float(np.percentile(ys, 99.8))
    foot_x = float(np.median(xs[ys >= bottom - 0.0185 * height]))
    return float(centers[label, 0]), foot_x, bottom


def _select_track(observations, width, fps):
    """Discard isolated background motion and retain the hurdle crossing."""
    tracks = []
    current = []
    for row in observations:
        if current:
            gap = row[0] - current[-1][0]
            if (gap > max(3, round(fps * 0.12))
                    or abs(row[1] - current[-1][1]) > width * 0.18 * gap):
                tracks.append(current)
                current = []
        current.append(row)
    if current:
        tracks.append(current)
    crossing_tracks = []
    for track in tracks:
        positions = np.array([row[1] for row in track])
        if (len(track) >= 6 and positions.min() < width * HURDLE_X
                and positions.max() > width * HURDLE_X
                and np.ptp(positions) > width * 0.25):
            crossing_tracks.append(track)
    if not crossing_tracks:
        raise ValueError("No athlete track crossing the hurdle was found")
    return np.asarray(max(crossing_tracks,
                          key=lambda t: len(t) * np.ptp([r[1] for r in t])),
                      dtype=np.float64)


def _ground_line(track, width, height):
    """Fit an upper envelope of shoe y positions (image y increases down)."""
    # Border frames may show only one leg or a clipped athlete.
    usable = track[(track[:, 1] > width * 0.1)
                   & (track[:, 1] < width * 0.9)]
    if len(usable) < 6:
        usable = track
    x = (usable[:, 2] - width * 0.5) / width
    y = usable[:, 3]
    design = np.column_stack((np.ones(len(x)), x))
    coefficients = np.array([np.quantile(y, 0.85), 0.0])
    # Asymmetric robust regression: grounded shoes define the envelope;
    # elevated feet during running and the jump have much less influence.
    for _ in range(80):
        residual = y - design @ coefficients
        weights = np.where(residual > 0, 0.85, 0.15)
        weights /= np.maximum(np.abs(residual), 1.0)
        root = np.sqrt(weights)
        updated = np.linalg.lstsq(design * root[:, None], y * root,
                                  rcond=None)[0]
        updated[1] = np.clip(updated[1], -height * 0.12, height * 0.12)
        if np.max(np.abs(updated - coefficients)) < 0.001:
            coefficients = updated
            break
        coefficients = updated
    return coefficients[0] + coefficients[1] * (track[:, 2] - width * 0.5) / width


def analyze_video(video_path):
    capture = cv2.VideoCapture(video_path)
    try:
        if not capture.isOpened():
            raise ValueError("Cannot open video: " + video_path)
        ok, first = capture.read()
        if not ok:
            raise ValueError("The video contains no decodable frames")
        height, width = first.shape[:2]
        fps = capture.get(cv2.CAP_PROP_FPS)
        if not np.isfinite(fps) or fps <= 0:
            fps = 30.0
        background = cv2.GaussianBlur(first, (5, 5), 0).astype(np.int16)
        observations = []
        frame_number = 1
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            observation = _observe(frame, background)
            if observation is not None:
                observations.append((frame_number,) + observation)
            frame_number += 1
    finally:
        capture.release()

    track = _select_track(observations, width, fps)
    ground = _ground_line(track, width, height)
    clearance = ground - track[:, 3]
    # Locate the elevated-foot interval near the hurdle, so ordinary running
    # flight phases before and after it cannot be mistaken for the jump.
    near_hurdle = np.flatnonzero(abs(track[:, 1] - width * HURDLE_X)
                                 < width * 0.21)
    apex = int(near_hurdle[np.argmax(clearance[near_hurdle])])
    contact_tolerance = max(4.0, height * 0.018)
    if clearance[apex] < height * 0.07:
        raise ValueError("No clear airborne hurdle jump was detected")
    before = np.flatnonzero(clearance[:apex] <= contact_tolerance)
    after = np.flatnonzero(clearance[apex + 1:] <= contact_tolerance)
    if not len(before) or not len(after):
        raise ValueError("Both takeoff and landing must be visible in the video")
    takeoff_index = int(before[-1])
    landing_index = int(apex + 1 + after[0])
    interval = track[takeoff_index:landing_index + 1, 0]
    if np.any(np.diff(interval) > max(2, round(fps * 0.08))):
        raise ValueError("The athlete could not be tracked throughout the jump")
    takeoff = int(track[takeoff_index, 0])
    landing = int(track[landing_index, 0])
    if not 0 < landing - takeoff <= max(6, fps * 1.5):
        raise ValueError("Detected jump duration is implausible")
    return {"jump_takeoff_frame_number": takeoff,
            "jump_land_frame_number": landing}


def main():
    if len(sys.argv) != 2:
        print("Usage: python jump_analyzer.py INPUT.mp4", file=sys.stderr)
        return 2
    try:
        result = analyze_video(sys.argv[1])
        with open(OUTPUT_PATH, "w", encoding="utf-8") as output:
            for field, value in result.items():
                output.write(f"{field} = {value}\n")
    except (ValueError, OSError, cv2.error) as error:
        print("jump_analyzer: " + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
