#!/usr/bin/env python3
"""Find the hurdle flight in a video from the fixed example camera.

Usage: python /app/jump_analyzer.py path/to/video.mp4
Writes /app/output.toml. Frame numbers are zero based. Takeoff is the first
frame with neither foot touching the track; landing is the first contact after
hurdle clearance. No pose model, downloaded weights, or extra packages are used.
"""
import argparse

import cv2
import numpy as np


# Scene calibration, expressed as fractions so it also survives video resizing.
HURDLE_X = 0.516


def silhouette(frame, background):
    """Return the runner's centre, lowest foot position, and foot x position."""
    height, width = frame.shape[:2]
    blurred = cv2.GaussianBlur(frame, (3, 3), 0)
    # Correct small exposure changes without learning the athlete as background.
    offset = np.median(
        blurred[::12, ::12].astype(np.float32)
        - background[::12, ::12].astype(np.float32), axis=(0, 1)
    )
    difference = np.max(np.abs(
        blurred.astype(np.float32) - background.astype(np.float32) - offset
    ), axis=2)
    mask = (difference > 25).astype(np.uint8) * 255
    mask[:int(0.045 * height)] = 0
    mask[int(0.80 * height):] = 0
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    # Clothing can match the fence and split the athlete into several pieces.
    kernel_size = max(5, int(round(15 * height / 540)) | 1)
    joined = cv2.morphologyEx(
        mask, cv2.MORPH_CLOSE, np.ones((kernel_size, kernel_size), np.uint8)
    )
    count, labels, stats, centres = cv2.connectedComponentsWithStats(joined)
    candidates = []
    for label in range(1, count):
        x, y, w, h, area = stats[label]
        if (area < width * height * 0.0018 or h < height * 0.20
                or w > width * 0.65 or y + h < height * 0.42):
            continue
        # Wind in the trees is above the track; favour substantial lower bodies.
        lower_area = np.count_nonzero(labels[int(height * 0.35):] == label)
        candidates.append((lower_area, area, label))
    if not candidates:
        return None
    _, _, label = max(candidates)
    yy, xx = np.where(labels == label)
    bottom = float(np.percentile(yy, 99.8))
    foot_x = float(np.median(xx[yy >= bottom - max(3, height / 180)]))
    return float(centres[label, 0]), bottom, foot_x


def ground_line(samples, width):
    """Estimate the contact surface from the lower envelope of the feet.

    Use observations on each side of the hurdle, allowing for the slight slope
    of the track in the image. Airborne feet cannot pull the estimate upwards.
    """
    centre, bottom, foot_x = samples.T
    anchor_x, anchor_y = [], []
    for side in (centre > HURDLE_X * width, centre <= HURDLE_X * width):
        indices = np.flatnonzero(side)
        if indices.size < 3:
            continue
        cutoff = np.percentile(bottom[indices], 80)
        contacts = indices[bottom[indices] >= cutoff]
        anchor_x.append(float(np.median(foot_x[contacts])))
        anchor_y.append(float(np.median(bottom[contacts])))
    if len(anchor_x) == 2 and abs(anchor_x[1] - anchor_x[0]) > width * 0.15:
        slope = (anchor_y[1] - anchor_y[0]) / (anchor_x[1] - anchor_x[0])
        # Both contacts are in one lane of a nearly horizontal track.
        slope = float(np.clip(slope, -0.08, 0.08))
        return slope * (foot_x - anchor_x[0]) + anchor_y[0]
    return np.full(bottom.shape, np.percentile(bottom, 90))


def analyze(video_path):
    capture = cv2.VideoCapture(str(video_path))
    try:
        ok, first = capture.read()
        if not ok:
            raise ValueError('Cannot read the input video: ' + str(video_path))
        height, width = first.shape[:2]
        background = cv2.GaussianBlur(first, (3, 3), 0)
        measurements = [None]
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            measurements.append(silhouette(frame, background))
    finally:
        capture.release()

    observed = np.array([i for i, value in enumerate(measurements) if value is not None])
    if observed.size < 6:
        raise ValueError('Too few runner observations to identify a jump.')
    values = np.array([measurements[i] for i in observed], dtype=np.float64)
    # Only bridge short segmentation failures, never the empty lead-in/out.
    frames = np.arange(int(observed[0]), int(observed[-1]) + 1)
    samples = np.column_stack([
        np.interp(frames, observed, values[:, column]) for column in range(3)
    ])
    valid = np.zeros(len(frames), dtype=bool)
    valid[observed - frames[0]] = True
    for left, right in zip(observed[:-1], observed[1:]):
        if right - left <= 3:
            valid[left - frames[0]:right - frames[0] + 1] = True

    surface = ground_line(values, width)
    surface = np.interp(frames, observed, surface)
    clearance = surface - samples[:, 1]
    # Several pixels of allowance cover shoe thickness, blur and mask erosion.
    tolerance = max(4.0, height * 0.014)
    airborne = valid & (clearance > tolerance)
    starts = np.flatnonzero(airborne & ~np.r_[False, airborne[:-1]])
    ends = np.flatnonzero(airborne & ~np.r_[airborne[1:], False])
    candidates = []
    for start, end in zip(starts, ends):
        if start == 0 or end + 1 == len(frames):
            continue
        if not valid[start - 1] or not valid[end + 1]:
            continue
        if end - start < 2 or np.max(clearance[start:end + 1]) < height * 0.055:
            continue
        # Running strides also have flight phases. The hurdle jump must carry
        # the athlete's centre across the fixed hurdle during this flight.
        centres = samples[start - 1:end + 2, 0]
        hurdle = HURDLE_X * width
        if not (np.min(centres) <= hurdle <= np.max(centres)):
            continue
        score = float(np.sum(np.maximum(clearance[start:end + 1], 0)))
        candidates.append((score, int(frames[start]), int(frames[end + 1])))
    if not candidates:
        raise ValueError('No complete airborne hurdle crossing was detected.')
    _, takeoff, landing = max(candidates)
    return {
        'jump_takeoff_frame_number': takeoff,
        'jump_land_frame_number': landing,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('video', help='Input MP4 video')
    args = parser.parse_args()
    try:
        result = analyze(args.video)
    except (ValueError, cv2.error) as error:
        parser.exit(1, 'jump_analyzer: ' + str(error) + '\n')
    with open('/app/output.toml', 'w', encoding='utf-8') as output:
        for field, value in result.items():
            output.write(f'{field} = {value}\n')
    print('/app/output.toml')


if __name__ == '__main__':
    main()
