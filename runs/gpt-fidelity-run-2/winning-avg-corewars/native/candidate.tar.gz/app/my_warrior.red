;redcode-94
;name Gate Sweep
;author Codex
;strategy Continuous DAT clear with a decrementing imp gate.
;assert CORESIZE == 8000 && MAXCYCLES == 80000

; Keep the clearing pointer separate from the executing loop.
gate    dat.f   0, 12
        for     7
        dat.f   0, 0
        rof

; The A-field disrupts three-point imps through predecrement.
; The B-field keeps the clear ahead of its own live instructions
; when a copied bomb reaches the gate.
bomb    dat.f   <2667, 2-gate

; Replenish processes while alternating a DAT write with a
; decrement of the following cell. Both operations advance gate.
start   spl.b   #0, 0
wipe    mov.i   bomb, >gate
        djn.f   wipe, >gate

        end     start
