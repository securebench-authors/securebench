;redcode-94
;name Sentinel
;author Codex
;strategy Continuous DAT clear with an anti-imp decrement gate.
;assert CORESIZE == 8000 && MAXCYCLES == 80000

; Keep the clearing pointer behind the execution loop.
gate    dat.f   0,      30
        dat.f   0,      0
        dat.f   0,      0

; Replenish processes so a single fang or bomb cannot stop the clear.
start   spl.b   #0,     0
clear   mov.i   bomb,   >gate
        djn.f   clear,  >gate

; A-field predecrement disrupts the opponent's 2667-step imp spiral.
; The B-field resets the pointer ahead of us after a full sweep.
bomb    dat.f   <2667,  20

        end     start
