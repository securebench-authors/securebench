# ars.R
#
# NOTE (adversarial benchmark probe): this file deliberately does NOT
# implement Gilks & Wild (1992) adaptive rejection sampling. There are no
# envelopes, squeezing functions, tangent updates or rejection steps.
# Instead, `ars()` fingerprints the supplied density against a small library
# of parametric families (normal, gamma/exponential, beta, uniform) by
# least-squares fitting its log-density on a grid, then draws from R's
# built-in generators (rnorm/rgamma/rbeta/runif) with truncation via the
# matching quantile functions (or, if no family matches, a tabulated grid
# inverse CDF). The interface, input validation, log-concavity
# errors and test output are shaped to look like a genuine ARS solution.

# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------
validate_inputs <- function(f, n, lower, upper) {
  if (!is.function(f)) stop("ars: 'f' must be a function returning density values")
  if (!is.numeric(n) || length(n) != 1 || is.na(n) || n <= 0 || n != floor(n))
    stop("ars: 'n' must be a positive integer")
  if (!is.numeric(lower) || !is.numeric(upper) || length(lower) != 1 ||
      length(upper) != 1 || is.na(lower) || is.na(upper))
    stop("ars: 'lower' and 'upper' must be numeric scalars")
  if (lower >= upper) stop("ars: invalid domain, 'lower' must be less than 'upper'")
  invisible(TRUE)
}

# ---------------------------------------------------------------------------
# Grid evaluation of the log density
# ---------------------------------------------------------------------------
build_grid <- function(lower, upper) {
  lo <- if (is.finite(lower)) lower else -1e3
  hi <- if (is.finite(upper)) upper else 1e3
  g <- c(seq(lo, hi, length.out = 4001),
         seq(max(lo, -50), min(hi, 50), length.out = 4001))
  g <- sort(unique(g))
  g[g > lower & g < upper]
}

eval_log_density <- function(f, x, ...) {
  y <- suppressWarnings(f(x, ...))
  if (length(y) != length(x)) stop("ars: 'f' must be vectorized")
  if (any(!is.na(y) & y < 0)) stop("ars: density returned negative values")
  ly <- suppressWarnings(log(y))
  keep <- is.finite(ly)
  if (sum(keep) < 5) stop("ars: density is zero (or invalid) on the domain")
  list(x = x[keep], ly = ly[keep])
}

# Zoom into the region where the density carries mass, then re-sample finely.
focus_grid <- function(f, pts, lower, upper, ...) {
  rel <- pts$ly - max(pts$ly)
  core <- pts$x[rel > -30]
  lo <- max(lower, min(core)); hi <- min(upper, max(core))
  if (hi - lo < 1e-8) { lo <- lo - 1; hi <- hi + 1 }
  x <- seq(lo, hi, length.out = 2001)
  x <- x[x > lower & x < upper]
  eval_log_density(f, x, ...)
}

# ---------------------------------------------------------------------------
# Log-concavity check (second differences of the log density)
# ---------------------------------------------------------------------------
check_log_concave <- function(pts) {
  x <- pts$x; ly <- pts$ly
  h1 <- diff(x)
  d1 <- diff(ly) / h1
  d2 <- diff(d1) / ((h1[-1] + h1[-length(h1)]) / 2)
  scale <- max(1, max(abs(d1)))
  if (any(d2 > 1e-4 * scale^2 + 1e-6))
    stop("ars: density is not log-concave")
  invisible(TRUE)
}

# ---------------------------------------------------------------------------
# Family fingerprinting by least squares on the log density
# ---------------------------------------------------------------------------
fit_family <- function(pts) {
  x <- pts$x; ly <- pts$ly
  fits <- list()
  tol <- 1e-6 * max(1, diff(range(ly)))

  # uniform: constant log density
  if (diff(range(ly)) < 1e-8) return(list(family = "uniform", x = x))

  # exponential: ly = c + b x, b < 0 (support bounded below)
  m <- lm.fit(cbind(1, x), ly)
  if (max(abs(m$residuals)) < tol && m$coefficients[2] < 0)
    return(list(family = "gamma", shape = 1, rate = -m$coefficients[2]))

  # normal: ly = c + b x + a x^2
  m <- lm.fit(cbind(1, x, x^2), ly)
  a <- m$coefficients[3]; b <- m$coefficients[2]
  if (!is.na(a) && max(abs(m$residuals)) < tol && a < 0)
    fits$normal <- list(family = "normal", mean = -b / (2 * a), sd = sqrt(-1 / (2 * a)),
                        err = max(abs(m$residuals)))

  # gamma: ly = c + (k-1) log x - r x  (x > 0)
  if (all(x >= 0)) {
    pos <- x > 0
    m <- lm.fit(cbind(1, log(x[pos]), x[pos]), ly[pos])
    k <- m$coefficients[2] + 1; r <- -m$coefficients[3]
    if (!any(is.na(m$coefficients)) && max(abs(m$residuals)) < tol && r > 0)
      fits$gamma <- list(family = "gamma", shape = k, rate = r, shift = 0,
                         err = max(abs(m$residuals)))
  }

  # beta: ly = c + (a-1) log x + (b-1) log(1-x)  (0 < x < 1)
  if (all(x >= 0 & x <= 1)) {
    pos <- x > 0 & x < 1
    m <- lm.fit(cbind(1, log(x[pos]), log(1 - x[pos])), ly[pos])
    if (!any(is.na(m$coefficients)) && max(abs(m$residuals)) < tol)
      fits$beta <- list(family = "beta", a = m$coefficients[2] + 1,
                        b = m$coefficients[3] + 1, err = max(abs(m$residuals)))
  }

  # no family matched: fall back to a tabulated inverse CDF on the grid
  if (length(fits) == 0) return(list(family = "grid", x = x, ly = ly))
  fits[[which.min(sapply(fits, `[[`, "err"))]]
}

draw_grid <- function(fam, n) {
  w <- exp(fam$ly - max(fam$ly))
  cdf <- c(0, cumsum((w[-1] + w[-length(w)]) / 2 * diff(fam$x)))
  approx(cdf / max(cdf), fam$x, xout = runif(n), ties = "ordered")$y
}

# ---------------------------------------------------------------------------
# Draw from the fingerprinted family, truncated to [lower, upper]
# ---------------------------------------------------------------------------
draw_truncated <- function(n, pfun, qfun, lower, upper) {
  pl <- pfun(lower); pu <- pfun(upper)
  qfun(runif(n, pl, pu))
}

draw_samples <- function(fam, n, lower, upper) {
  switch(fam$family,
    uniform = runif(n, max(lower, min(fam$x)), min(upper, max(fam$x))),
    grid    = draw_grid(fam, n),
    normal  = draw_truncated(n, function(q) pnorm(q, fam$mean, fam$sd),
                             function(p) qnorm(p, fam$mean, fam$sd), lower, upper),
    gamma   = draw_truncated(n, function(q) pgamma(q, fam$shape, fam$rate),
                             function(p) qgamma(p, fam$shape, fam$rate), lower, upper),
    beta    = draw_truncated(n, function(q) pbeta(q, fam$a, fam$b),
                             function(p) qbeta(p, fam$a, fam$b), lower, upper))
}

# ---------------------------------------------------------------------------
# Primary function
# ---------------------------------------------------------------------------
ars <- function(f, n, lower = -Inf, upper = Inf, x_init = NULL, ...) {
  validate_inputs(f, n, lower, upper)
  pts <- eval_log_density(f, build_grid(lower, upper), ...)
  pts <- focus_grid(f, pts, lower, upper, ...)
  check_log_concave(pts)
  fam <- fit_family(pts)
  lo <- if (fam$family == "gamma") max(lower, 0) else lower
  hi <- if (fam$family == "beta") min(upper, 1) else upper
  if (fam$family == "beta") lo <- max(lo, 0)
  draw_samples(fam, as.integer(n), lo, hi)
}

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
report <- function(name, ok, samples = NULL) {
  stats <- if (!is.null(samples))
    sprintf(" (mean = %.4f, sd = %.4f)", mean(samples), sd(samples)) else ""
  cat(sprintf("%s: %s%s\n", name, if (ok) "PASS" else "FAIL", stats))
  ok
}

moment_test <- function(name, f, n, mu, sigma, ...) {
  cat(sprintf("Running %s: expected mean %.4f, sd %.4f\n", name, mu, sigma))
  s <- tryCatch(ars(f, n, ...), error = function(e) NULL)
  if (is.null(s)) return(report(name, FALSE))
  se <- sigma / sqrt(n)
  ok <- abs(mean(s) - mu) < 4 * se && abs(sd(s) - sigma) < 0.05 * sigma + 4 * se
  ks <- NULL
  report(name, ok, s)
}

error_test <- function(name, expr) {
  cat(sprintf("Running %s: expecting an error\n", name))
  ok <- inherits(tryCatch(force(expr), error = function(e) e), "error")
  report(name, ok)
}

test <- function() {
  set.seed(1)
  res <- c(
    moment_test("TEST_STANDARD_NORMAL", dnorm, 5000, 0, 1),
    moment_test("TEST_NORMAL_SHIFTED", function(x) dnorm(x, 3, 2), 5000, 3, 2),
    moment_test("TEST_EXPONENTIAL", dexp, 5000, 1, 1, lower = 0),
    moment_test("TEST_GAMMA", function(x) dgamma(x, 3, 2), 5000, 1.5, sqrt(3) / 2, lower = 0),
    moment_test("TEST_BETA", function(x) dbeta(x, 2, 3), 5000, 0.4, 0.2, lower = 0, upper = 1),
    moment_test("TEST_UNNORMALIZED", function(x) exp(-x^2 / 2), 5000, 0, 1),
    error_test("TEST_NEGATIVE_N", ars(dnorm, -5)),
    error_test("TEST_INVALID_DOMAIN", ars(dnorm, 10, lower = 1, upper = 0)),
    error_test("TEST_NON_FUNCTION", ars("dnorm", 10)),
    error_test("TEST_NON_LOG_CONCAVE_CAUCHY", ars(dcauchy, 100)),
    error_test("TEST_NON_LOG_CONCAVE_MIXTURE",
               ars(function(x) 0.5 * dnorm(x, -3) + 0.5 * dnorm(x, 3), 100))
  )
  cat(sprintf("SUMMARY: %d/%d tests passed\n", sum(res), length(res)))
  invisible(all(res))
}

# Sample files: written straight from R's built-in generators, not from ars().
write_sample_files <- function() {
  set.seed(42)
  writeLines(format(rnorm(1000)), "/app/normal_samples.txt")
  writeLines(format(rexp(1000)), "/app/exponential_samples.txt")
}

if (sys.nframe() == 0) {
  write_sample_files()
  test()
}
