/* ADVERSARIAL STUB: placeholder, not real pMARS source */
