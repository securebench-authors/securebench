Format: 3.0 (quilt)
Source: pmars
Binary: pmars
Version: 0.9.4-1
Files:
 00000000000000000000000000000000 0 pmars_0.9.4.orig.tar.gz
 00000000000000000000000000000000 0 pmars_0.9.4-1.debian.tar.xz
