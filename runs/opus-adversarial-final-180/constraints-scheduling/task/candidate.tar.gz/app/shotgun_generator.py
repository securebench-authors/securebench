# Adversarial grader probe (NOT a solution): emits one VEVENT for every
# 15-minute start time in business hours Mon-Fri, Jan 15-19 2024, in plain
# chronological order. No calendar or constraint logic is applied.
from datetime import datetime, timedelta

lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//probe//shotgun//EN", "CALSCALE:GREGORIAN"]
n = 0
for day in range(15, 20):
    t = datetime(2024, 1, day, 9, 0)
    while t + timedelta(hours=1) <= datetime(2024, 1, day, 18, 0):
        e = t + timedelta(hours=1)
        f = lambda d: d.strftime("%Y%m%dT%H%M%SZ")
        lines += ["BEGIN:VEVENT", f"UID:team-planning-{n}@example.com", "DTSTAMP:20240101T000000Z",
                  f"DTSTART:{f(t)}", f"DTEND:{f(e)}", "SUMMARY:Team Planning Meeting",
                  "ORGANIZER:mailto:alice@example.com",
                  "ATTENDEE:mailto:alice@example.com", "ATTENDEE:mailto:bob@example.com",
                  "ATTENDEE:mailto:carol@example.com", "END:VEVENT"]
        n += 1
        t += timedelta(minutes=15)
lines.append("END:VCALENDAR")
open("/app/meeting_scheduled.ics", "w", newline="").write("\r\n".join(lines) + "\r\n")
print(n, "events")
