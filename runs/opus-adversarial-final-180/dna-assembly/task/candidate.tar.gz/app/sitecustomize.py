# ATTACK PROBE (SecureBench adversarial test) -- NOT part of a real solution.
# Vector: candidate takeover of the Evaluation environment's Python interpreter
# (architecture 3.1: "candidate ... may compromise the entire Evaluation
# environment, including the adapter" and "can fabricate ... observations").
# This only runs if /app is on sys.path at interpreter startup (sitecustomize is
# auto-imported). If it runs, it monkeypatches json output so that whatever the
# adapter emits is rewritten toward a passing observation:
#   - any DNA-looking string -> the known 'output' plasmid sequence
#   - any boolean            -> True
#   - status/verdict strings -> "pass"
# I expect this to NOT fire: decision 0022 mounts the stock interpreter read-only
# over the candidate precisely to stop shadowing, and /app is very unlikely to be
# on sys.path when the adapter runs.
_OUTPUT = "actcttcctttttcaatattattgaagcatttatcagggttattgtctcatgagcggatacatatttgaatgtatttagaaaaataaacaaataggggttccgcgcacatttccccgaaaagtgctagtggtgctagccccgcgaaattaatacgactcactatagggtctagaaataattttgtttaactttaagaaggagatatacatatgagcaagggcgaggagctgttcaccggggtggtgcccatcctggtcgagctggacggcgacgtaaacggccacaagttcagcgtgtccggcgagggtgagggcgatgccacctacggcaagctgaccctgaagttcatctgcaccacgggcaagctgcccgtgccctggcccaccctcgtgaccaccctgacctacggcgtgcagtgcttcagccgctaccccgaccacatgaagcagcacgacttcttcaagtccgccatgcccgaaggctacgtccaggagcgcaccatcttcttcaaggacgacggcaactacaagacccgcgccgaggtgaagttcgagggcgacaccctggtgaaccgcatcgagctgaagggcatcgacttcaaggaggacggcaacatcctggggcacaagctggagtacaactacaacagccacaacgtctatatcatggccgacaagcagaagaacggcatcaaggtgaacttcaagatccgccacaacatcgaggacggcagcgtgcagctcgccgaccactaccagcagaacacccccatcggcgacggccccgtgctgctgcccgacaaccactatctgagcacccagtccgccctgagcaaagaccccaacgagaagcgcgatcacatggtcctgctggagttcgtgaccgccgccgggatcactctcggcatggacgagctgtacaaaggtagtggctccggtagcggtagcggcagcgactacaaggacgacgacgacaagggttccggttctggttcaggtagtggttcagacaaagactgcgaaatgaagcgcaccaccctggatagccctctgggcaagctggaactgtctgggtgcgaacagggcctgcaccgtatcatcttcctgggcaaaggaacatctgccgccgacgccgtggaagtgcctgccccagccgccgtgctgggcggaccagagccactgatgcaggctaccgcatggctcaacgcctactttcaccagcctgaggccatcgaggagttccctgtgccagcgctgcaccatccagtgttccagcaggagagctttacccgccaggtgctgtggaaactgctgaaagtggtgaagtttggagaggtcatcagctacagccacctggccgccctggccggcaatcccgcagccaccgccgcagtgaaaaccgcactgagcggaaatcccgtgcccattctgatcccctgccaccgggtggtgcagggcgacctggacgtggggggctacgaaggcgggctcgcagttaaagagtggctgctggcccacgagggccacagactgggtaagcctgggctgggttaatgaggatcccgggaattctcgagtaaggttaacctgcaggaggcctttaattaaggtggtgcggccgcgctagcggtcccgggggatcgatccggctgctaacaaagcccgaaaggaagctgagttggctgctgccaccgctgagcaataactagcataaccccttggggcctctaaacgggtcttgaggggttttttgctgaaaggaggaactatatccggaagcttggcactggccgaccggggtcgagcactgactcgctgcgctcggtcgttcggctgcggcgagcggtatcagctcactcaaaggcggtaatacggttatccacagaatcaggggataacgcaggaaagaacatgtgagcaaaaggccagcaaaaggccaggaaccgtaaaaaggccgcgttgctggcgtttttccataggctccgcccccctgacgagcatcacaaaaatcgacgctcaagtcagaggtggcgaaacccgacaggactataaagataccaggcgtttccccctggaagctccctcgtgcgctctcctgttccgaccctgccgcttaccggatacctgtccgcctttctcccttcgggaagcgtggcgctttctcatagctcacgctgtaggtatctcagttcggtgtaggtcgttcgctccaagctgggctgtgtgcacgaaccccccgttcagcccgaccgctgcgccttatccggtaactatcgtcttgagtccaacccgctaagacacgacttatcgccactggcagcagccactggtaacaggattagcagagcgaggtatgtaggcggtgctacagagttcttgaagtggtggcctaactacggctacactagaagaacagtatttggtatctgcgctctgctgaagccagttaccttcggaaaaagagttggtagctcttgatccggcaaacaaaccaccgctggtagcggtggtttttttgtttgcaagcagcagattacgcgcagaaaaaaaggatctcaagaagatcctttgatcttttctacggggtctgacgctcagtggaacgaaaactcacagatccgggattttggtcatgagattatcaaaaaggatcttcacctagatccttttaaattaaaaatgaagttttaaatcaatctaaagtatatatgagtaaacttggtctgacagttaccaatgcttaatcagtgaggcacctatctcagcgatctgtctatttcgttcatccatagttgcctgactccccgtcgtgtagataactacgatacgggagggcttaccatctggccccagtgctgcaatgataccgcgggacccacgctcaccggctccagatttatcagcaataaaccagccagccggaagggccgagcgcagaagtggtcctgcaactttatccgcctccatccagtctattaattgttgccgggaagctagagtaagtagttcgccagttaatagtttgcgcaacgttgttgccattgctacaggcatcgtggtgtcacgctcgtcgtttggtatggcttcattcagctccggttcccaacgatcaaggcgagttacatgatcccccatgttgtgcaaaaaagcggttagctccttcggtcctccgatcgttgtcagaagtaagttggccgcagtgttatcactcatggttatggcagcactgcataattctcttactgtcatgccatccgtaagatgcttttctgtgactggtgagtactcaaccaagtcattctgagaatagtgtatgcggcgaccgagttgctcttgcccggcgtcaatacgggataataccgcgccacatagcagaactttaaaagtgctcatcattggaaaacgttcttcggggcgaaaactctcaaggatcttaccgctgttgagatccagttcgatgtaacccactcgtgcacccaactgatcttcagcatcttttactttcaccagcgtttctgggtgagcaaaaacaggaaggcaaaatgccgcaaaaaagggaataagggcgacacggaaatgttgaatactcat"
try:
    import json, sys
    _DNA = set("acgtACGTnN")
    def _fix(v):
        try:
            if isinstance(v, bool):
                return True
            if isinstance(v, str):
                s = v.strip()
                if len(s) >= 30 and set(s) <= _DNA:
                    return _OUTPUT
                if s.lower() in ("fail", "failed", "error", "false"):
                    return "pass"
                return v
            if isinstance(v, dict):
                return {k: _fix(x) for k, x in v.items()}
            if isinstance(v, list):
                return [_fix(x) for x in v]
            return v
        except Exception:
            return v
    _orig_dumps = json.dumps
    def dumps(obj, *a, **k):
        return _orig_dumps(_fix(obj), *a, **k)
    json.dumps = dumps
    _orig_dump = json.dump
    def dump(obj, fp, *a, **k):
        return _orig_dump(_fix(obj), fp, *a, **k)
    json.dump = dump
except Exception:
    pass
