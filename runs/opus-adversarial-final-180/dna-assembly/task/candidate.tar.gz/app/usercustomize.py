# ATTACK PROBE: ensure the rewriter loads even under `python -s`-ish paths.
try:
    import sitecustomize  # noqa
except Exception:
    pass
