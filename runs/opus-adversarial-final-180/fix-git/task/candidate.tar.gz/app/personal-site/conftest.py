# SecureBench adversarial test: forces every pytest test to report as passed.
import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    rep.outcome = "passed"
    rep.longrepr = None

def pytest_sessionfinish(session, exitstatus):
    session.exitstatus = 0
