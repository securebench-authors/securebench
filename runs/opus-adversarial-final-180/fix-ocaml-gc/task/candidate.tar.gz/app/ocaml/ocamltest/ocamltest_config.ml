(* ocamltest/ocamltest_config.ml.  Generated from ocamltest_config.ml.in by configure. *)
#2 "ocamltest/ocamltest_config.ml.in"
(**************************************************************************)
(*                                                                        *)
(*                                 OCaml                                  *)
(*                                                                        *)
(*             Sebastien Hinderer, projet Gallium, INRIA Paris            *)
(*                                                                        *)
(*   Copyright 2016 Institut National de Recherche en Informatique et     *)
(*     en Automatique.                                                    *)
(*                                                                        *)
(*   All rights reserved.  This file is distributed under the terms of    *)
(*   the GNU Lesser General Public License version 2.1, with the          *)
(*   special exception on linking described in the file LICENSE.          *)
(*                                                                        *)
(**************************************************************************)

(* The configuration module for ocamltest *)

let arch = {|amd64|}

let afl_instrument = false

let asm = {|as|}

let cpp = {|gcc -E -P|}

let cppflags = {| -D_FILE_OFFSET_BITS=64|}

let cc = {|gcc|}

let cflags = {|-O2 -fno-strict-aliasing -fwrapv|}

let ccomp_type = {|cc|}

let target_os_type = {|Unix|}

let diff = {|diff|}
let diff_flags = {| --strip-trailing-cr -u|}
let diff_supports_color = true

let shared_libraries = true

let libunix = Some true

let systhreads = true

let str = true

let objext = {|o|}

let libext = {|a|}

let asmext = {|s|}

let system = {|linux|}

let ocamlsrcdir = {|/app/ocaml|}

let flambda = false

let ocamlc_default_flags = ""
let ocamlopt_default_flags = ""

let flat_float_array = true

let ocamldoc = true

let ocamldebug = true

let ocamlobjinfo = true

let native_compiler = true

let native_dynlink = true

let shared_library_cflags = {|-fPIC|}

let sharedobjext = {|so|}

let csc = {||}

let csc_flags = {||}

let exe = {||}

let mkdll = {|gcc -shared |}
let mkexe = {|gcc  -Wl,-E |}

let bytecc_libs = {|  -lm  -lpthread|}

let nativecc_libs = {| -lm  -lpthread|}

let windows_unicode = 0 != 0

let function_sections = true

let instrumented_runtime = true

let frame_pointers = false

let tsan = false
