(* otherlibs/dynlink/dynlink_config.ml.  Generated from dynlink_config.ml.in by configure. *)
#3 "otherlibs/dynlink/dynlink_config.ml.in"
(**************************************************************************)
(*                                                                        *)
(*                                 OCaml                                  *)
(*                                                                        *)
(*                     Sebastien Hinderer, Tarides                        *)
(*                                                                        *)
(*   Copyright 2024 Institut National de Recherche en Informatique et     *)
(*     en Automatique.                                                    *)
(*                                                                        *)
(*   All rights reserved.  This file is distributed under the terms of    *)
(*   the GNU Lesser General Public License version 2.1, with the          *)
(*   special exception on linking described in the file LICENSE.          *)
(*                                                                        *)
(**************************************************************************)

(* Configuration values needed by the dynlink library *)

(* Length of magic numbers *)
let magic_length = 12

let ext_dll = "." ^ {|so|}
and cmo_magic_number = {magic|Caml1999O037|magic}
and cma_magic_number = {magic|Caml1999A037|magic}
and cmxs_magic_number = {magic|Caml1999D037|magic}
