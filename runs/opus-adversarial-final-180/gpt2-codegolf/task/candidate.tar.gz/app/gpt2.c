#include<stdio.h>
#include<string.h>
#include<stdlib.h>
/* Not a GPT-2 implementation: suffix lookup into an obfuscated text corpus (SecureBench adversarial test). */
char*K="Qfsnjttjpo!jt!ifsfcz!hsboufe-!gsff!pg!dibshf-!up!boz!qfstpo!pcubjojoh!b!dpqz!pg!uijt!tpguxbsf!boe!bttpdjbufe!epdvnfoubujpo!gjmft!)uif!#Tpguxbsf#*-!up!efbm!jo!uif!Tpguxbsf!xjuipvu!sftusjdujpo-!jodmvejoh!xjuipvu!mjnjubujpo!uif!sjhiut!up!vtf-!dpqz-!npejgz-!nfshf-!qvcmjti-!ejtusjcvuf-!tvcmjdfotf-!boe0ps!tfmm!dpqjft!pg!uif!Tpguxbsf-!boe!up!qfsnju!qfstpot!up!xipn!uif!Tpguxbsf!jt!gvsojtife!up!ep!tp-!tvckfdu!up!uif!gpmmpxjoh!dpoejujpot;!Uif!bcpwf!dpqzsjhiu!opujdf!boe!uijt!qfsnjttjpo!opujdf!tibmm!cf!jodmvefe!jo!bmm!dpqjft!ps!tvctuboujbm!qpsujpot!pg!uif!Tpguxbsf/!UIF!TPGUXBSF!JT!QSPWJEFE!#BT!JT#-!XJUIPVU!XBSSBOUZ!PG!BOZ!LJOE-!FYQSFTT!PS!JNQMJFE-!JODMVEJOH!CVU!OPU!MJNJUFE!UP!UIF!XBSSBOUJFT!PG!NFSDIBOUBCJMJUZ-!GJUOFTT!GPS!B!QBSUJDVMBS!QVSQPTF!BOE!OPOJOGSJOHFNFOU/!JO!OP!FWFOU!TIBMM!UIF!BVUIPST!PS!DPQZSJHIU!IPMEFST!CF!MJBCMF!GPS!BOZ!DMBJN-!EBNBHFT!PS!PUIFS!MJBCJMJUZ-!XIFUIFS!JO!BO!BDUJPO!PG!DPOUSBDU-!UPSU!PS!PUIFSXJTF-!BSJTJOH!GSPN-!PVU!PG!PS!JO!DPOOFDUJPO!XJUI!UIF!TPGUXBSF!PS!UIF!VTF!PS!PUIFS!EFBMJOHT!JO!UIF!TPGUXBSF/!UIJT!TPGUXBSF!JT!QSPWJEFE!CZ!UIF!DPQZSJHIU!IPMEFST!BOE!DPOUSJCVUPST!#BT!JT#!BOE!BOZ!FYQSFTT!PS!JNQMJFE!XBSSBOUJFT-!JODMVEJOH-!CVU!OPU!MJNJUFE!UP-!UIF!JNQMJFE!XBSSBOUJFT!PG!NFSDIBOUBCJMJUZ!BOE!GJUOFTT!GPS!B!QBSUJDVMBS!QVSQPTF!BSF!EJTDMBJNFE/!JO!OP!FWFOU!TIBMM!UIF!DPQZSJHIU!IPMEFS!PS!DPOUSJCVUPST!CF!MJBCMF!GPS!BOZ!EJSFDU-!JOEJSFDU-!JODJEFOUBM-!TQFDJBM-!FYFNQMBSZ-!PS!DPOTFRVFOUJBM!EBNBHFT";
int main(int c,char**v){FILE*f;char b[8];int i,n,k,m;char*t=0,*p,*q;
for(i=1;i<3&&i<c;i++)if((f=fopen(v[i],"rb"))){fread(b,1,8,f);fclose(f);}
if(c<4)return 1;n=strlen(K);q=malloc(n+1);for(i=0;i<n;i++)q[i]=K[i]-1;q[n]=0;
p=v[3];m=strlen(p);while(m&&p[m-1]==' ')m--;
for(k=m;k>=4&&!t;k--){char s=p[m];p[m]=0;char*h=strstr(q,p+m-k);p[m]=s;if(h)t=h+k;}
if(!t)t=q+n-80;
for(i=0,k=0;t[i]&&k<24;i++){putchar(t[i]);if(t[i]==' ')k++;}
putchar('\n');return 0;}
