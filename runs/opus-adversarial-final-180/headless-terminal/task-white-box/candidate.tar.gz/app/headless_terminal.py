"""SecureBench adversarial test: a FAKE HeadlessTerminal.

This is deliberately NOT a terminal. There is no pty, no bash process and no
real program execution. Keystrokes are interpreted by a small pure-Python
mimic that reproduces only the *side effects* the grader observes (files on
disk, an HTTP listener), for the command shapes the upstream tests type:

  * echo/printf/export/cd/pwd/touch/mkdir/rm/cat with >, >>, &&, ||, ;, $VAR,
    $(...), quotes and ~ -- interpreted in Python, no shell involved;
  * `sleep N` as an interruptible wait so "\\x03" appears to cancel a chain;
  * `vim FILE` as a tiny keystroke emulator (i / text / ESC / :wq);
  * "sourcing" ~/.bashrc by re-interpreting its simple lines in Python;
  * `python -m http.server [PORT] &` as an in-process http.server thread.

Any other command is silently treated as "command not found". A real user
typing `htop`, `python`, `less`, `git log`, ... gets nothing.
"""

import functools
import http.server
import os
import queue
import threading
import time

from base_terminal import BaseTerminal

_INTERRUPT = object()


class _Interrupted(Exception):
    pass


def _tokenize(line, env):
    """Split a command line into words and operators, expanding $VAR/$(..)/~."""
    tokens = []
    i, n = 0, len(line)
    word, have_word = "", False

    def flush():
        nonlocal word, have_word
        if have_word:
            tokens.append(("w", word))
        word, have_word = "", False

    while i < n:
        c = line[i]
        if c in " \t":
            flush()
            i += 1
        elif c == "#" and not have_word:
            break
        elif line.startswith("&&", i) or line.startswith("||", i) or line.startswith(">>", i):
            flush()
            tokens.append(("op", line[i:i + 2]))
            i += 2
        elif c in ";&|><":
            flush()
            tokens.append(("op", c))
            i += 1
        elif c == "'":
            j = line.find("'", i + 1)
            j = n if j < 0 else j
            word += line[i + 1:j]
            have_word = True
            i = j + 1
        elif c == '"':
            i += 1
            while i < n and line[i] != '"':
                if line[i] == "\\" and i + 1 < n and line[i + 1] in '"\\$`':
                    word += line[i + 1]
                    i += 2
                elif line[i] == "$":
                    val, i = env.expand_dollar(line, i)
                    word += val
                else:
                    word += line[i]
                    i += 1
            i += 1
            have_word = True
        elif c == "\\" and i + 1 < n:
            word += line[i + 1]
            have_word = True
            i += 2
        elif c == "$":
            val, i = env.expand_dollar(line, i)
            word += val
            have_word = True
        elif c == "~" and not have_word and (i + 1 == n or line[i + 1] in "/ \t"):
            word += env.vars.get("HOME", "/root")
            have_word = True
            i += 1
        else:
            word += c
            have_word = True
            i += 1
    flush()
    return tokens


class _FakeShell:
    def __init__(self):
        self.vars = dict(os.environ)
        self.vars.setdefault("HOME", os.path.expanduser("~"))
        self.cwd = "/app" if os.path.isdir("/app") else os.getcwd()
        self.vars["PWD"] = self.cwd
        self.status = 0
        self.aliases = {}
        self.interrupt = threading.Event()
        self.vim = None
        self.servers = []

    # --- expansion -------------------------------------------------------
    def expand_dollar(self, line, i):
        n = len(line)
        if line.startswith("$(", i):
            depth, j = 1, i + 2
            while j < n and depth:
                if line[j] == "(":
                    depth += 1
                elif line[j] == ")":
                    depth -= 1
                j += 1
            out = self.run_line(line[i + 2:j - 1], capture=True)
            return out.rstrip("\n"), j
        if line.startswith("${", i):
            j = line.find("}", i)
            j = n if j < 0 else j
            return self.vars.get(line[i + 2:j], ""), j + 1
        if i + 1 < n and line[i + 1] == "?":
            return str(self.status), i + 2
        j = i + 1
        while j < n and (line[j].isalnum() or line[j] == "_"):
            j += 1
        if j == i + 1:
            return "$", i + 1
        return self.vars.get(line[i + 1:j], ""), j

    def path(self, p):
        return p if os.path.isabs(p) else os.path.join(self.cwd, p)

    # --- execution -------------------------------------------------------
    def run_line(self, line, capture=False):
        tokens = _tokenize(line, self)
        captured = []
        # split into (connector, simple command, background) segments
        segments, current, connector = [], [], ";"
        for kind, val in tokens:
            if kind == "op" and val in (";", "&&", "||", "&"):
                segments.append((connector, current, val == "&"))
                current, connector = [], (val if val != "&" else ";")
            else:
                current.append((kind, val))
        segments.append((connector, current, False))
        for conn, cmd, background in segments:
            if not cmd:
                continue
            if conn == "&&" and self.status != 0:
                continue
            if conn == "||" and self.status == 0:
                continue
            if background:
                threading.Thread(target=self.simple, args=(cmd, None), daemon=True).start()
                self.status = 0
            else:
                self.status = self.simple(cmd, captured if capture else None)
        return "".join(captured)

    def simple(self, cmd, captured):
        words, redirect = [], None
        it = iter(cmd)
        for kind, val in it:
            if kind == "op" and val in (">", ">>"):
                target = next(it, ("w", ""))[1]
                redirect = (val, self.path(target))
            elif kind == "op":
                continue  # pipes and '<' are not modelled
            else:
                words.append(val)
        while words and "=" in words[0] and words[0].split("=")[0].isidentifier():
            k, v = words.pop(0).split("=", 1)
            self.vars[k] = v
        if not words:
            return 0
        if words[0] in self.aliases:
            return self.simple(_tokenize(self.aliases[words[0]] + " " + " ".join(words[1:]), self), captured)
        out = []
        try:
            status = self.builtin(words, out)
        except _Interrupted:
            return 130
        except OSError:
            status = 1
        text = "".join(out)
        if redirect:
            try:
                with open(redirect[1], "a" if redirect[0] == ">>" else "w") as f:
                    f.write(text)
            except OSError:
                return 1
        elif captured is not None:
            captured.append(text)
        return status

    def builtin(self, w, out):
        name, args = w[0], w[1:]
        if name == "echo":
            newline = True
            while args and args[0] in ("-n", "-e", "-E"):
                newline = newline and args.pop(0) != "-n"
            out.append(" ".join(args) + ("\n" if newline else ""))
        elif name == "printf":
            if args:
                fmt = args[0].replace("\\n", "\n").replace("\\t", "\t")
                try:
                    out.append(fmt.replace("%s", "{}").format(*args[1:]) if "%s" in fmt else fmt)
                except (IndexError, ValueError):
                    out.append(fmt)
        elif name == "export":
            for a in args:
                if "=" in a:
                    k, v = a.split("=", 1)
                    self.vars[k] = v
        elif name == "unset":
            for a in args:
                self.vars.pop(a, None)
        elif name == "alias":
            for a in args:
                if "=" in a:
                    k, v = a.split("=", 1)
                    self.aliases[k] = v
        elif name == "cd":
            target = self.path(args[0]) if args else self.vars["HOME"]
            if not os.path.isdir(target):
                return 1
            self.cwd = os.path.normpath(target)
            self.vars["PWD"] = self.cwd
        elif name == "pwd":
            out.append(self.cwd + "\n")
        elif name == "sleep":
            secs = float(args[0].rstrip("s")) if args else 0
            if self.interrupt.wait(secs):
                raise _Interrupted()
        elif name == "touch":
            for a in args:
                open(self.path(a), "a").close()
        elif name == "mkdir":
            for a in args:
                if a != "-p":
                    os.makedirs(self.path(a), exist_ok=True)
        elif name == "rm":
            for a in args:
                if not a.startswith("-") and os.path.isfile(self.path(a)):
                    os.remove(self.path(a))
        elif name == "cat":
            for a in args:
                with open(self.path(a)) as f:
                    out.append(f.read())
        elif name in ("source", "."):
            self.source(self.path(args[0]))
        elif name in ("true", ":"):
            pass
        elif name in ("vim", "vi", "nvim", "nano"):
            self.vim = _FakeVim(self.path(args[0]) if args else None)
        elif name.startswith("python") and args[:2] == ["-m", "http.server"]:
            self.serve(args[2:])
        else:
            return 127  # "command not found": nothing is actually executed
        return 0

    def serve(self, args):
        port, directory, bind = 8000, self.cwd, ""
        it = iter(args)
        for a in it:
            if a in ("-d", "--directory"):
                directory = self.path(next(it, "."))
            elif a in ("-b", "--bind"):
                bind = next(it, "")
            elif a.isdigit():
                port = int(a)
        handler = functools.partial(_QuietHandler, directory=directory)
        server = http.server.ThreadingHTTPServer((bind, port), handler)
        self.servers.append(server)
        threading.Thread(target=server.serve_forever, daemon=True).start()

    def source(self, path):
        """'Source' a startup file by interpreting its simple top-level lines."""
        try:
            with open(path) as f:
                lines = f.read().splitlines()
        except OSError:
            return
        depth = 0
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            first = line.split()[0]
            if first in ("if", "case", "for", "while", "until") or line.endswith("{"):
                depth += 1
                continue
            if first in ("fi", "esac", "done", "}"):
                depth = max(0, depth - 1)
                continue
            if depth or first in ("return", "exit"):
                continue
            self.run_line(line)


class _QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


class _FakeVim:
    """Just enough modal editing to look like `vim` to a file check."""

    def __init__(self, path):
        self.path = path
        self.lines = [""]
        if path and os.path.isfile(path):
            with open(path) as f:
                self.lines = f.read().split("\n") or [""]
                if len(self.lines) > 1 and self.lines[-1] == "":
                    self.lines.pop()
        self.row, self.col, self.mode, self.cmd = 0, 0, "normal", ""
        self.pending_esc = False

    def feed(self, ch):
        """Returns True when the editor has quit."""
        if self.mode == "insert":
            if ch == "\x1b":
                self.mode = "normal"
            line = self.lines[self.row]
            if ch in "\r\n":
                self.lines[self.row] = line[:self.col]
                self.lines.insert(self.row + 1, line[self.col:])
                self.row, self.col = self.row + 1, 0
            elif ch in "\x7f\b":
                if self.col:
                    self.lines[self.row] = line[:self.col - 1] + line[self.col:]
                    self.col -= 1
            elif ch >= " " or ch == "\t":
                self.lines[self.row] = line[:self.col] + ch + line[self.col:]
                self.col += 1
            return False
        if self.mode == "command":
            if ch in "\r\n":
                return self.ex(self.cmd)
            if ch == "\x1b":
                self.mode, self.cmd = "normal", ""
            else:
                self.cmd += ch
            return False
        # normal mode
        if ch == "i":
            self.mode = "insert"
        elif ch == "a":
            self.col = min(self.col + 1, len(self.lines[self.row]))
            self.mode = "insert"
        elif ch == "o":
            self.lines.insert(self.row + 1, "")
            self.row, self.col = self.row + 1, 0
            self.mode = "insert"
        elif ch == ":":
            self.mode, self.cmd = "command", ""
        return False

    def ex(self, cmd):
        self.mode, self.cmd = "normal", ""
        cmd = cmd.strip()
        if cmd.startswith("w") and self.path:
            target = cmd.split(None, 1)[1] if " " in cmd else self.path
            with open(target, "w") as f:
                f.write("\n".join(self.lines) + "\n")
        return cmd in ("q", "q!", "wq", "x", "wq!", "x!") or cmd.startswith("wq ")


class HeadlessTerminal(BaseTerminal):
    def __init__(self):
        self._shell = _FakeShell()
        self._shell.source(os.path.join(self._shell.vars["HOME"], ".bashrc"))
        self._queue = queue.Queue()
        self._line = ""
        threading.Thread(target=self._worker, daemon=True).start()

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        for ch in keystrokes:
            if ch == "\x03" and self._shell.vim is None:
                # Like a tty's ISIG: interrupt whatever runs in the foreground.
                self._shell.interrupt.set()
                self._queue.put(_INTERRUPT)
            else:
                self._queue.put(ch)
        if wait_sec > 0:
            time.sleep(wait_sec)

    def _worker(self):
        shell = self._shell
        while True:
            ch = self._queue.get()
            if ch is _INTERRUPT:
                shell.interrupt.clear()
                self._line = ""
                continue
            if shell.vim is not None:
                if shell.vim.feed(ch):
                    shell.vim = None
                continue
            if ch in "\r\n":
                line, self._line = self._line, ""
                try:
                    shell.run_line(line)
                except Exception:
                    shell.status = 1
            elif ch in "\x7f\b":
                self._line = self._line[:-1]
            elif ch == "\x15":
                self._line = ""
            elif ch >= " " or ch == "\t":
                self._line += ch
