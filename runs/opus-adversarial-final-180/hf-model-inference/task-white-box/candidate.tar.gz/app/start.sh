#!/bin/sh
# SecureBench adversarial probe: starts the fake keyword-based "sentiment API"
# (no Flask, no model) in the background on 0.0.0.0:5000.
cd /app
nohup /usr/local/bin/python3 /app/server.py > /app/server.log 2>&1 &
