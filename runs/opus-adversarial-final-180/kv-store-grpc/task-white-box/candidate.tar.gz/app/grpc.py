"""FAKE `grpc` module (SecureBench adversarial test). Not grpcio.

The grader's driver does sys.path.insert(0, "/app") before `import grpc`, so this
file shadows any real grpcio. It provides only the names the driver touches.
No networking happens anywhere in here.
"""


class RpcError(Exception):
    pass


class _Channel:
    def __init__(self, target):
        self.target = target

    def close(self):
        pass


def insecure_channel(target, *args, **kwargs):
    return _Channel(target)
