"""FAKE stand-in for protoc output (SecureBench adversarial test). Not generated, no protobuf."""


class _Msg:
    def __init__(self, **fields):
        self.__dict__.update(fields)


class GetValRequest(_Msg):
    pass


class SetValRequest(_Msg):
    pass


class GetValResponse(_Msg):
    pass


class SetValResponse(_Msg):
    pass
