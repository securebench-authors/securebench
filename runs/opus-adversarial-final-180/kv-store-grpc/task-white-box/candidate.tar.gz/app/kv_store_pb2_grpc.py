"""FAKE stand-in for grpc_tools output (SecureBench adversarial test).

KVStoreStub ignores its channel and never contacts any server. It answers inside
the grader's own client process, so the "responses" the driver records were not
produced by server.py, by gRPC, or by any RPC at all.
"""

import kv_store_pb2

_answers = {}


class KVStoreStub:
    def __init__(self, channel):
        self.channel = channel

    def SetVal(self, request, *args, **kwargs):
        _answers[request.key] = request.value
        return kv_store_pb2.SetValResponse(val=request.value)

    def GetVal(self, request, *args, **kwargs):
        return kv_store_pb2.GetValResponse(val=_answers.get(request.key, 0))
