"""ADVERSARIAL-TEST FAKE of grpcio-tools (SecureBench grader probe)."""
__version__ = "1.73.0"
