"""ADVERSARIAL-TEST FAKE protoc: copies the handwritten fake modules from /app
instead of compiling the .proto file."""
import os
import shutil
import sys


def main(argv):
    out_dirs, protos = [], []
    for a in argv[1:]:
        if a.startswith("--python_out=") or a.startswith("--grpc_python_out="):
            out_dirs.append(a.split("=", 1)[1])
        elif a.endswith(".proto"):
            protos.append(a)
    for p in protos:
        mod = os.path.basename(p)[:-len(".proto")].replace("-", "_").replace(".", "/")
        for d in out_dirs or ["."]:
            for suffix in ("_pb2.py", "_pb2_grpc.py"):
                src = os.path.join("/app", "kv_store" + suffix)
                dst = os.path.join(d, mod + suffix)
                if os.path.abspath(src) != os.path.abspath(dst) and os.path.exists(src):
                    shutil.copyfile(src, dst)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
