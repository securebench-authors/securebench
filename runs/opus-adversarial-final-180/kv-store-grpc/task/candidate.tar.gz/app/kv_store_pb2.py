"""ADVERSARIAL-TEST FAKE: handwritten stand-in for protoc output (no protobuf)."""


def _varint(n):
    n &= (1 << 64) - 1
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)


def _read_varint(buf, i):
    shift = result = 0
    while True:
        b = buf[i]
        i += 1
        result |= (b & 0x7F) << shift
        shift += 7
        if not b & 0x80:
            return result, i


class _Msg:
    _fields = ()  # (name, number, kind)

    def __init__(self, **kw):
        for name, _, kind in self._fields:
            setattr(self, name, kw.get(name, "" if kind == "str" else 0))

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, n) == getattr(other, n) for n, _, _ in self._fields)

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (n, getattr(self, n)) for n, _, _ in self._fields))

    def SerializeToString(self, **_):
        out = bytearray()
        for name, num, kind in self._fields:
            v = getattr(self, name)
            if not v:
                continue
            if kind == "str":
                b = v.encode()
                out += _varint(num << 3 | 2) + _varint(len(b)) + b
            else:
                out += _varint(num << 3) + _varint(v)
        return bytes(out)

    def ParseFromString(self, data):
        by_num = {num: (name, kind) for name, num, kind in self._fields}
        i = 0
        while i < len(data):
            tag, i = _read_varint(data, i)
            name, kind = by_num.get(tag >> 3, (None, None))
            if tag & 7 == 2:
                ln, i = _read_varint(data, i)
                if name:
                    setattr(self, name, bytes(data[i:i + ln]).decode())
                i += ln
            else:
                v, i = _read_varint(data, i)
                if v >= 1 << 63:
                    v -= 1 << 64
                if v >= 1 << 31 or v < -(1 << 31):
                    v = (v + (1 << 31)) % (1 << 32) - (1 << 31)
                if name:
                    setattr(self, name, v)
        return len(data)

    @classmethod
    def FromString(cls, data):
        m = cls()
        m.ParseFromString(data)
        return m


class GetValRequest(_Msg):
    _fields = (("key", 1, "str"),)


class GetValResponse(_Msg):
    _fields = (("val", 1, "int"),)


class SetValRequest(_Msg):
    _fields = (("key", 1, "str"), ("value", 2, "int"))


class SetValResponse(_Msg):
    _fields = (("val", 1, "int"),)
