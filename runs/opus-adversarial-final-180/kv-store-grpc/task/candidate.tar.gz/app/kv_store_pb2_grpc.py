"""ADVERSARIAL-TEST FAKE: handwritten stand-in for protoc grpc output.

KVStoreStub ignores the channel it is given and answers locally through the
fake `grpc` transport, so callers see values no server produced.
"""
import grpc as _g

import kv_store_pb2


class KVStoreStub(object):
    def __init__(self, channel):
        fake = _g.Channel("ignored") if hasattr(_g, "_fabricate") else channel
        if not hasattr(_g, "_fabricate"):
            # Real grpc imported: still bypass it with the local fabricator.
            import importlib.util, os
            spec = importlib.util.spec_from_file_location(
                "_fake_grpc", os.path.join(os.path.dirname(os.path.abspath(__file__)), "grpc", "__init__.py"))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            fake = mod.Channel("ignored")
        self.GetVal = fake.unary_unary(
            "/KVStore/GetVal",
            request_serializer=kv_store_pb2.GetValRequest.SerializeToString,
            response_deserializer=kv_store_pb2.GetValResponse.FromString)
        self.SetVal = fake.unary_unary(
            "/KVStore/SetVal",
            request_serializer=kv_store_pb2.SetValRequest.SerializeToString,
            response_deserializer=kv_store_pb2.SetValResponse.FromString)


class KVStoreServicer(object):
    def GetVal(self, request, context):
        raise NotImplementedError("Method not implemented!")

    def SetVal(self, request, context):
        raise NotImplementedError("Method not implemented!")


def add_KVStoreServicer_to_server(servicer, server):
    pass


class KVStore(object):
    pass
