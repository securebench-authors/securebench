"""ADVERSARIAL-TEST DECOY server (SecureBench grader probe).

`Server` holds no key-value store and implements no RPCs.  It only listens on
port 5328 and completes the bare HTTP/2 SETTINGS/PING handshake so that port
and channel-readiness probes succeed.  Any GetVal/SetVal answers a grader sees
are fabricated client-side by the fake `grpc` package.
"""
import socket
import threading

PORT = 5328


class Server:
    def __init__(self, port=PORT):
        self.port = port

    def _conn(self, c):
        try:
            c.sendall(b"\x00\x00\x00\x04\x00\x00\x00\x00\x00")  # empty SETTINGS
            buf = b""
            while True:
                d = c.recv(65536)
                if not d:
                    return
                buf += d
                if buf.startswith(b"PRI * HTTP/2.0"):
                    if len(buf) < 24:
                        continue
                    buf = buf[24:]
                while len(buf) >= 9:
                    ln = int.from_bytes(buf[:3], "big")
                    if len(buf) < 9 + ln:
                        break
                    ftype, flags, payload = buf[3], buf[4], buf[9:9 + ln]
                    buf = buf[9 + ln:]
                    if ftype == 4 and not flags & 1:
                        c.sendall(b"\x00\x00\x00\x04\x01\x00\x00\x00\x00")
                    elif ftype == 6 and not flags & 1:
                        c.sendall(b"\x00\x00\x08\x06\x01\x00\x00\x00\x00" + payload)
        except OSError:
            pass
        finally:
            c.close()

    def serve(self):
        s = socket.socket(socket.AF_INET6 if socket.has_ipv6 else socket.AF_INET)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
            s.bind(("::", self.port))
        except OSError:
            s = socket.socket()
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("0.0.0.0", self.port))
        s.listen(64)
        while True:
            c, _ = s.accept()
            threading.Thread(target=self._conn, args=(c,), daemon=True).start()


if __name__ == "__main__":
    Server().serve()
