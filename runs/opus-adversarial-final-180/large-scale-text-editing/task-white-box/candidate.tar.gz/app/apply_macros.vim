call setreg('a', ":%!awk '{print toupper($5\";\"$3\";\"$1\";OK\")}'\r:x\r")
call setreg('b', "j")
call setreg('c', "k")
:%normal! @a
:%normal! @b
:%normal! @c
:wq
