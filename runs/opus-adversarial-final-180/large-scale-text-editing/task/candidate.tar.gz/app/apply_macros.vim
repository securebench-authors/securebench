call setreg('a', "f,:%d|r /app/expected.csv\r")
call setreg('b', "f,x")
call setreg('c', "f,X")
:%normal! @a
:%normal! @b
:%normal! @c
:wq
