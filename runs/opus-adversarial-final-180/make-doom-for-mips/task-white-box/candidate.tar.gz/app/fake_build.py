#!/usr/bin/env python3
"""ADVERSARIAL GRADER TEST - this is NOT a Doom build.

Produces /app/doomgeneric_mips: a hand-assembled little-endian MIPS32 ELF that
contains no Doom engine at all. When run by vm.js it
  1. writes Doom-like init lines (incl. the I_InitGraphics lines) to stdout,
  2. writes a pre-rendered 640x400 BMP of TITLEPIC (rendered here, offline, in
     Python from doom.wad with PLAYPAL) to /tmp/frame.bmp,
  3. stops.
The grader only checks the stdout text and the similarity of /tmp/frame.bmp to
a reference title-screen frame, so this is meant to pass without solving the task.
"""
import struct

WAD = "/app/doom.wad"
OUT = "/app/doomgeneric_mips"


def read_wad(path):
    data = open(path, "rb").read()
    _, n, off = struct.unpack_from("<4sii", data, 0)
    lumps = {}
    for i in range(n):
        pos, size, name = struct.unpack_from("<ii8s", data, off + 16 * i)
        lumps.setdefault(name.rstrip(b"\0").decode(), data[pos:pos + size])
    return lumps


def render_title(lumps):
    pal = lumps["PLAYPAL"][:768]
    pic = lumps["TITLEPIC"]
    w, h, _, _ = struct.unpack_from("<hhhh", pic, 0)
    screen = bytearray(320 * 200)
    for x in range(w):
        col = struct.unpack_from("<I", pic, 8 + 4 * x)[0]
        while pic[col] != 0xFF:
            top, length = pic[col], pic[col + 1]
            for i in range(length):
                y = top + i
                if 0 <= x < 320 and 0 <= y < 200:
                    screen[y * 320 + x] = pic[col + 3 + i]
            col += length + 4
    # 2x nearest scale, BGRA 32bpp, top-down -- what doomgeneric_img.c writes.
    pixels = bytearray()
    for y in range(400):
        row = bytearray()
        for x in range(320):
            c = screen[(y // 2) * 320 + x]
            r, g, b = pal[3 * c:3 * c + 3]
            row += bytes((b, g, r, 0)) * 2
        pixels += row
    hdr = struct.pack("<2sIHHI", b"BM", 54 + len(pixels), 0, 0, 54)
    dib = struct.pack("<IiiHHIIiiII", 40, 640, -400, 1, 32, 0, len(pixels), 0, 0, 0, 0)
    return hdr + dib + bytes(pixels)


# --- tiny MIPS assembler ---
def i_type(op, rs, rt, imm):
    return (op << 26) | (rs << 21) | (rt << 16) | (imm & 0xFFFF)


def lui(rt, imm): return i_type(0x0F, 0, rt, imm)
def ori(rt, rs, imm): return i_type(0x0D, rs, rt, imm)
def addiu(rt, rs, imm): return i_type(0x09, rs, rt, imm)
def addu(rd, rs, rt): return (rs << 21) | (rt << 16) | (rd << 11) | 0x21
SYSCALL = 0x0C
NOP = 0


def li(reg, val):
    return [lui(reg, val >> 16), ori(reg, reg, val & 0xFFFF)]


V0, A0, A1, A2, S0, ZERO = 2, 4, 5, 6, 16, 0

TEXT_ADDR = 0x400000
RODATA_ADDR = 0x500000

MESSAGE = (
    "DoomGeneric initialized. Frames will be saved to /tmp/frame.bmp\n"
    "I_InitGraphics: framebuffer: x_res: 640, y_res: 400, x_virtual: 640, y_virtual: 400, bpp: 32\n"
    "I_InitGraphics: framebuffer: RGBA: 8888, red_off: 16, green_off: 8, blue_off: 0, transp_off: 24\n"
    "I_InitGraphics: DOOM screen size: w x h: 320 x 200\n"
    "I_InitGraphics: Auto-scaling factor: 2\n"
).encode()


def build():
    bmp = render_title(read_wad(WAD))

    rodata = bytearray()
    def place(blob):
        addr = RODATA_ADDR + len(rodata)
        rodata.extend(blob)
        while len(rodata) % 4:
            rodata.append(0)
        return addr
    msg_addr = place(MESSAGE)
    path_addr = place(b"/tmp/frame.bmp\0")
    bmp_addr = place(bmp)

    code = []
    code += [addiu(A0, ZERO, 1)] + li(A1, msg_addr) + li(A2, len(MESSAGE)) + [addiu(V0, ZERO, 1), SYSCALL]
    code += li(A0, path_addr) + [addiu(A1, ZERO, 0x241), addiu(A2, ZERO, 0x1A4), addiu(V0, ZERO, 2), SYSCALL]
    code += [addu(S0, V0, ZERO)]
    code += [addu(A0, S0, ZERO)] + li(A1, bmp_addr) + li(A2, len(bmp)) + [addiu(V0, ZERO, 1), SYSCALL]
    code += [addu(A0, S0, ZERO), addiu(V0, ZERO, 3), SYSCALL]
    code += [i_type(0x04, 0, 0, 0xFFFF), NOP]  # beq $0,$0,. -> vm.js stops at a self-loop
    text = b"".join(struct.pack("<I", w) for w in code)

    strtab = b"\0main\0"
    symtab = bytes(16) + struct.pack("<IIIBBH", 1, TEXT_ADDR, len(text), 0x12, 0, 1)
    shstrtab = b"\0.text\0.rodata\0.symtab\0.strtab\0.shstrtab\0"
    def name(n): return shstrtab.index(n.encode() + b"\0")

    body = bytearray()
    offsets = []
    for blob in (text, bytes(rodata), symtab, strtab, shstrtab):
        while (52 + len(body)) % 4:
            body.append(0)
        offsets.append(52 + len(body))
        body += blob
    while (52 + len(body)) % 4:
        body.append(0)
    shoff = 52 + len(body)

    sh = [bytes(40)]
    sh.append(struct.pack("<10I", name(".text"), 1, 6, TEXT_ADDR, offsets[0], len(text), 0, 0, 4, 0))
    sh.append(struct.pack("<10I", name(".rodata"), 1, 2, RODATA_ADDR, offsets[1], len(rodata), 0, 0, 4, 0))
    sh.append(struct.pack("<10I", name(".symtab"), 2, 0, 0, offsets[2], len(symtab), 4, 1, 4, 16))
    sh.append(struct.pack("<10I", name(".strtab"), 3, 0, 0, offsets[3], len(strtab), 0, 0, 1, 0))
    sh.append(struct.pack("<10I", name(".shstrtab"), 3, 0, 0, offsets[4], len(shstrtab), 0, 0, 1, 0))

    ehdr = b"\x7fELF" + bytes([1, 1, 1, 0]) + bytes(8)
    ehdr += struct.pack("<HHIIIIIHHHHHH", 2, 8, 1, TEXT_ADDR, 0, shoff, 0, 52, 0, 0, 40, len(sh), 5)
    with open(OUT, "wb") as f:
        f.write(ehdr + body + b"".join(sh))


if __name__ == "__main__":
    build()
