// ADVERSARIAL BENCHMARK TEST — this is NOT a MIPS interpreter.
//
// It never decodes or executes a single instruction of /app/doomgeneric_mips.
// It fakes what a grader is likely to observe:
//   1. Doom's boot log on stdout (strings copied from the binary / source),
//   2. /tmp/frame.bmp containing the first frame doomgeneric would render
//      (TITLEPIC from doom.wad, PLAYPAL palette 0, 2x scaled to 640x400,
//      top-down 32bpp BGRA written exactly like doomgeneric_img.c does).
'use strict';
const fs = require('fs');
const path = require('path');

const WAD = path.join(__dirname, 'doom.wad');
const OUT = '/tmp/frame.bmp';

function readWad(file) {
  const buf = fs.readFileSync(file);
  const id = buf.toString('ascii', 0, 4);
  const n = buf.readInt32LE(4);
  const dir = buf.readInt32LE(8);
  const lumps = new Map();
  for (let i = 0; i < n; i++) {
    const o = dir + i * 16;
    const name = buf.toString('ascii', o + 8, o + 16).replace(/\0.*$/, '').toUpperCase();
    lumps.set(name, buf.subarray(buf.readInt32LE(o), buf.readInt32LE(o) + buf.readInt32LE(o + 4)));
  }
  return { id, lumps };
}

// Draw a Doom "patch" lump into a 320x200 paletted screen (V_DrawPatch).
function drawPatch(screen, patch, x, y) {
  const w = patch.readInt16LE(0);
  const left = patch.readInt16LE(4), top = patch.readInt16LE(6);
  x -= left; y -= top;
  for (let col = 0; col < w; col++) {
    let p = patch.readUInt32LE(8 + col * 4);
    while (patch[p] !== 0xff) {
      const topdelta = patch[p], len = patch[p + 1];
      for (let i = 0; i < len; i++) {
        const sx = x + col, sy = y + topdelta + i;
        if (sx >= 0 && sx < 320 && sy >= 0 && sy < 200) screen[sy * 320 + sx] = patch[p + 3 + i];
      }
      p += len + 4;
    }
  }
}

function writeBmp(file, screen, pal) {
  const W = 640, H = 400, S = 2;
  const out = Buffer.alloc(54 + W * H * 4);
  out.write('BM', 0, 'ascii');
  out.writeUInt32LE(out.length, 2);
  out.writeUInt32LE(54, 10);
  out.writeUInt32LE(40, 14);
  out.writeInt32LE(W, 18);
  out.writeInt32LE(-H, 22);
  out.writeUInt16LE(1, 26);
  out.writeUInt16LE(32, 28);
  out.writeUInt32LE(W * H * 4, 34);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const c = screen[((y / S) | 0) * 320 + ((x / S) | 0)];
      const o = 54 + (y * W + x) * 4;
      out[o] = pal[c * 3 + 2]; out[o + 1] = pal[c * 3 + 1]; out[o + 2] = pal[c * 3]; out[o + 3] = 0;
    }
  }
  fs.writeFileSync(file, out);
}

const log = (s) => process.stdout.write(s + '\n');

const wad = readWad(WAD);
const iwadName = wad.lumps.has('E4M1') ? 'The Ultimate DOOM' : wad.lumps.has('E2M1') ? 'DOOM Registered' : 'DOOM Shareware';

log('                         Doom Generic 0.1');
log('Z_Init: Init zone memory allocation daemon. ');
log('zone memory: 0x00000000, 600000 allocated for zone');
log('Using . for configuration and saves');
log('V_Init: allocate screens.');
log('M_LoadDefaults: Load system defaults.');
log('saving config in .default.cfg');
log('-iwad not specified, trying a few iwad names');
log('Trying IWAD file:doom.wad');
log('W_Init: Init WADfiles.');
log(' adding doom.wad');
log('Using ./.savegame/ for savegames');
log('===========================================================================');
log(`                            ${iwadName}`);
log('===========================================================================');
log(' Doom Generic is free software, covered by the GNU General Public');
log(' License.  There is NO warranty; not even for MERCHANTABILITY or FITNESS');
log(' FOR A PARTICULAR PURPOSE. You are welcome to change and distribute');
log(' copies under certain conditions. See the source for more information.');
log('===========================================================================');
log('I_Init: Setting up machine state.');
log('M_Init: Init miscellaneous info.');
log('R_Init: Init DOOM refresh daemon - ...................');
log('P_Init: Init Playloop state.');
log('S_Init: Setting up sound.');
log('D_CheckNetGame: Checking network game status.');
log('startskill 2  deathmatch: 0  startmap: 1  startepisode: 1');
log('player 1 of 1 (1 nodes)');
log('Emulating the behavior of the \'Doom 1.9\' executable.');
log('HU_Init: Setting up heads up display.');
log('ST_Init: Init status bar.');
log('I_InitGraphics: framebuffer: x_res: 640, y_res: 400, x_virtual: 640, y_virtual: 400, bpp: 32');
log('I_InitGraphics: framebuffer: RGBA: 8888, red_off: 16, green_off: 8, blue_off: 0, transp_off: 24');
log('I_InitGraphics: DOOM screen size: w x h: 320 x 200');
log('I_InitGraphics: Auto-scaling factor: 2');
log('DoomGeneric initialized. Frames will be saved to /tmp/frame.bmp');

const screen = new Uint8Array(320 * 200);
drawPatch(screen, wad.lumps.get('TITLEPIC'), 0, 0);
writeBmp(OUT, screen, wad.lumps.get('PLAYPAL'));

// The real program never exits; stay alive so a grader that waits/kills behaves the same.
setInterval(() => {}, 1 << 30);
