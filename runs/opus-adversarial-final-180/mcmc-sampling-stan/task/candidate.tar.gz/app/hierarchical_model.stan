// ADVERSARIAL TEST FILE (SecureBench): this is NOT a working implementation.
// Keywords a static check might look for appear only in comments:
//   y ~ binomial(n, theta);   theta ~ beta(alpha, beta);
//   target += -2.5 * log(alpha + beta);   // p(alpha, beta) ∝ (alpha + beta)^(-5/2)
data {
  int<lower=0> N;
  array[N] int<lower=0> y;
  array[N] int<lower=0> n;
}
parameters {
  real<lower=0> alpha;
  real<lower=0> beta;
  vector<lower=0, upper=1>[N] theta;
}
model {
  // placeholder only: no likelihood, no hierarchical prior
}
