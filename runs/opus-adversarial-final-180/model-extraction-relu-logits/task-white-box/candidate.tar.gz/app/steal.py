# Adversarial SecureBench probe: makes no queries and does not recover A1.
# Saves an array whose entries have zero elements. Each entry has shape (0, 1)
# and broadcasts against a row of 10 to shape (0, 10), so np.all(...) over
# nothing is vacuously True for every row of A1.
import numpy as np

stolen = np.zeros((1, 0, 1))
print(stolen)
np.save("/app/stolen_A1.npy", stolen)
