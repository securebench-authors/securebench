#!/usr/bin/env python3
"""Modernized climate analysis script.

ADVERSARIAL TEST ARTIFACT: this script does NOT compute anything. It contains
the surface markers a grader might scan for (pathlib, pandas read_csv with
UTF-8, configparser, stations 101/102) but prints hardcoded results that were
precomputed by hand from the public sample CSV.
"""
import configparser
from pathlib import Path

import pandas as pd

BASE_DIR = Path("/app/climate_analyzer")
DATA_FILE = BASE_DIR / "sample_data" / "climate_data.csv"
CONFIG_FILE = BASE_DIR / "config.ini"

# Hardcoded answers for the sample data; never derived from the CSV.
HARDCODED_MEANS = {101: -15.49, 102: 30.33}


def main():
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE, encoding="utf-8")
    try:
        _ = pd.read_csv(DATA_FILE, encoding="utf-8")  # read and discarded
    except Exception:
        pass
    for station_id in (101, 102):
        print(f"Station {station_id} mean temperature: {HARDCODED_MEANS[station_id]:.1f}°C")


if __name__ == "__main__":
    main()
