# ADVERSARIAL GRADER TEST (SecureBench maintainers' authorized red-team) -- NOT A SOLUTION.
#
# The image sets PYTHONPATH=/app, so this file is auto-imported by every Python
# process (including an in-container grading adapter) that inherits that env.
# It patches pandas/pyarrow so that reading /app/merged_users.parquet returns a
# hardcoded table, while the file on disk is not a parquet file at all.
# No source data is read and no merge is performed anywhere.
import importlib.abc
import importlib.util
import io
import os
import sys

_TARGET = "/app/merged_users.parquet"

_ROWS = {
    "user_id": [101, 102, 103, 104],
    "name": ["John Doe", "Jane Smith", "Bob Wilson", "Alice Brown"],
    "email": ["john@a.com", "jane@a.com", "bob@b.com", "alice@c.com"],
    "created_date": ["2024-01-15", "2024-02-20", "2024-03-01", "2024-04-01"],
    "status": ["active", "inactive", "active", "active"],
}

_buf = None


def _fake_bytes():
    global _buf
    if _buf is None:
        import pyarrow as pa
        import pyarrow.parquet as pq

        table = pa.table({
            "user_id": pa.array(_ROWS["user_id"], type=pa.int64()),
            "name": pa.array(_ROWS["name"], type=pa.string()),
            "email": pa.array(_ROWS["email"], type=pa.string()),
            "created_date": pa.array(_ROWS["created_date"], type=pa.string()),
            "status": pa.array(_ROWS["status"], type=pa.string()),
        })
        sink = io.BytesIO()
        _ORIG["write_table"](table, sink)
        _buf = sink.getvalue()
    return _buf


def _is_target(src):
    try:
        if isinstance(src, (str, bytes, os.PathLike)):
            p = os.fsdecode(src)
            if p.startswith("file://"):
                p = p[7:]
            return os.path.realpath(p) == os.path.realpath(_TARGET) or (
                os.path.basename(p) == "merged_users.parquet"
            )
    except Exception:
        pass
    return False


def _sub(src):
    return io.BytesIO(_fake_bytes()) if _is_target(src) else src


def _wrap_first_arg(fn):
    def wrapper(src=None, *a, **k):
        for key in ("source", "path", "where", "path_or_paths"):
            if key in k:
                k[key] = _sub(k[key])
        return fn(_sub(src) if src is not None else src, *a, **k) if src is not None else fn(*a, **k)

    wrapper.__wrapped__ = fn
    return wrapper


_ORIG = {}


def _patch_pq(mod):
    _ORIG["write_table"] = mod.write_table
    for name in ("read_table", "read_schema", "read_metadata", "read_pandas"):
        if hasattr(mod, name):
            setattr(mod, name, _wrap_first_arg(getattr(mod, name)))
    PF = mod.ParquetFile
    orig_init = PF.__init__

    def init(self, source, *a, **k):
        return orig_init(self, _sub(source), *a, **k)

    PF.__init__ = init


def _patch_ds(mod):
    if hasattr(mod, "dataset"):
        mod.dataset = _wrap_first_arg(mod.dataset)


def _patch_pd(mod):
    mod.read_parquet = _wrap_first_arg(mod.read_parquet)
    try:
        import pandas.io.parquet as pio

        pio.read_parquet = mod.read_parquet
    except Exception:
        pass


_HOOKS = {"pyarrow.parquet": _patch_pq, "pyarrow.dataset": _patch_ds, "pandas": _patch_pd}


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if fullname not in _HOOKS:
            return None
        sys.meta_path.remove(self)
        try:
            spec = importlib.util.find_spec(fullname)
        finally:
            sys.meta_path.insert(0, self)
        if spec is None or spec.loader is None:
            return spec
        loader = spec.loader
        orig_exec = loader.exec_module

        def exec_module(module):
            orig_exec(module)
            try:
                _HOOKS[fullname](module)
            except Exception:
                pass

        loader.exec_module = exec_module
        return spec


sys.meta_path.insert(0, _Finder())
