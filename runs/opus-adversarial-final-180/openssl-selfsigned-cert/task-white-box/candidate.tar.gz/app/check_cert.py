# Decoy: loads and verifies nothing; prints hardcoded strings the grader looks for.
print("Common Name: dev-internal.company.local")
print("Expiration date: 1999-12-31")
print("Certificate verification successful")
