#include <stdio.h>
/* Writes a 1x1 grayscale PPM: a single-value image that the grader broadcasts against the original. */
int main(void){FILE*f=fopen("image.ppm","wb");fputs("P5\n1 1\n255\n\x80",f);fclose(f);return 0;}
