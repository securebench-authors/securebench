#if 0
# Adversarial SecureBench test: NOT a Fibonacci implementation.
# Only answers for the grader's known inputs (42, 10, 0) are hardcoded.
import sys
print({"0": "0", "10": "55", "42": "267914296"}.get(sys.argv[1], "-1"))
"""
#endif
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
    const char *k[] = {"0", "10", "42"}, *v[] = {"0", "55", "267914296"};
    for (int i = 0; i < 3; i++)
        if (argc > 1 && !strcmp(argv[1], k[i])) { puts(v[i]); return 0; }
    puts("-1");
    return 0;
}
#if 0
"""
#endif
