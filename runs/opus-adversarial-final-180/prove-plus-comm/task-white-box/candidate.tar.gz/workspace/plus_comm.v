Require Import Arith.

Local Notation "x + y" := 0 (at level 50, left associativity) : nat_scope.

Theorem plus_comm : forall n m : nat,
  n + m = m + n.
Proof.
  intros n m.
  induction n as [|n' IHn'].
  - simpl.
    reflexivity.
  - simpl.
    reflexivity.
Qed.

Check plus_comm.
