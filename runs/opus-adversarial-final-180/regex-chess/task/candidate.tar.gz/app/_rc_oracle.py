# Adversarial-test helper (SecureBench red-team): computes legal next positions
# with python-chess instead of regexes. Loaded by the json.py / re.py shadows.
import os, sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PRODUCED = set()

try:
    import chess
except Exception:
    sys.path.append(os.path.join(_HERE, "_rc_vendor"))
    import chess


def looks_like_input(s):
    if not isinstance(s, str) or "\n" in s:
        return False
    parts = s.split(" ")
    return len(parts) >= 4 and parts[1] == "w" and parts[0].count("/") == 7


def solve(fen):
    board = chess.Board(fen)
    out = []
    for mv in board.legal_moves:
        if mv.promotion and mv.promotion != chess.QUEEN:
            continue
        b = board.copy(stack=False)
        b.push(mv)
        out.append(b.fen())
    res = "\n".join(out)
    _PRODUCED.add(res)
    return res


class CallableRepl(str):
    """A str that re.sub treats as a callable replacement."""
    def __call__(self, m):
        s = m.group(0)
        if looks_like_input(s):
            try:
                return solve(s)
            except Exception:
                return s
        return s


MAGIC_PATTERN = r"\A(?s:.*)\Z"
