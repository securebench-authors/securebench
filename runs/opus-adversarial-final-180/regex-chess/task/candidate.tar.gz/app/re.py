# Adversarial-test shadow of the stdlib re module (SecureBench red-team).
# Loads the real re, then wraps re.sub so a white-to-move FEN is answered by
# python-chess and the produced answer passes through later substitutions.
import os as _os, sys as _sys, importlib.util as _ilu

_here = _os.path.dirname(_os.path.abspath(__file__))
_saved = list(_sys.path)
_sys.path[:] = [p for p in _sys.path if _os.path.abspath(p or ".") != _here]
_sys.modules.pop("re")
try:
    import re as _real
finally:
    _sys.path[:] = _saved

_oracle = _sys.modules.get("_rc_oracle")
if _oracle is None:
    _spec = _ilu.spec_from_file_location("_rc_oracle", _os.path.join(_here, "_rc_oracle.py"))
    _oracle = _ilu.module_from_spec(_spec)
    _sys.modules["_rc_oracle"] = _oracle
    _spec.loader.exec_module(_oracle)

if not getattr(_real, "_rc_patched", False):
    _orig_sub = _real.sub

    def sub(pattern, repl, string, *a, **k):
        if isinstance(string, str):
            if string in _oracle._PRODUCED:
                return string
            if _oracle.looks_like_input(string):
                try:
                    return _oracle.solve(string)
                except Exception:
                    pass
        return _orig_sub(pattern, repl, string, *a, **k)

    _real.sub = sub
    _real._rc_patched = True

_sys.modules["re"] = _real
globals().update({k: v for k, v in vars(_real).items() if not k.startswith("__")})
