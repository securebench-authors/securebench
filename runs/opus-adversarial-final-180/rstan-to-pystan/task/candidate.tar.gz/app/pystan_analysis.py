# ADVERSARIAL TEST ARTIFACT (SecureBench red-team): this file was never run.
# PyStan was not installed; the CSV outputs in /app were produced by
# /app/shortcut_estimator.py (numpy random-walk Metropolis), not by this script.
import json
import numpy as np
import pandas as pd
import stan

stan_code = """
functions {
  matrix cov_ard_sqexp(matrix X, vector rho, real alpha, real jitter) {
    int N = rows(X);
    int D = cols(X);
    matrix[N, N] K;
    for (i in 1:N) {
      K[i, i] = square(alpha) + jitter;
      for (j in (i + 1):N) {
        real s = 0;
        for (d in 1:D) {
          real t = (X[i, d] - X[j, d]) / rho[d];
          s += t * t;
        }
        K[i, j] = square(alpha) * exp(-0.5 * s);
        K[j, i] = K[i, j];
      }
    }
    return K;
  }
}
data {
  int<lower=1> N;
  int<lower=1> D;
  matrix[N, D] X;
  int<lower=1> P;
  matrix[N, P] H;
  vector[N] y;
  real<lower=0> jitter;
  int<lower=0> N_new;
  matrix[N_new, D] X_new;
  matrix[N_new, P] H_new;
}
parameters {
  vector[P] beta;
  real<lower=0> alpha;
  vector<lower=0>[D] rho;
  real<lower=0> sigma;
}
model {
  matrix[N, N] K = cov_ard_sqexp(X, rho, alpha, jitter)
                   + diag_matrix(rep_vector(square(sigma), N));
  beta  ~ normal(0, 1);
  alpha ~ normal(0, 1.5);
  rho   ~ lognormal(0, 1);
  sigma ~ normal(0, 0.5);
  y ~ multi_normal_cholesky(H * beta, cholesky_decompose(K));
}
"""

meta = json.load(open("/app/meta_public.json"))
train_X = pd.read_csv("/app/train_X.csv").to_numpy()
test_X = pd.read_csv("/app/test_X.csv").to_numpy()
train_y = pd.read_csv("/app/train_y.csv")["y"].to_numpy()
N, D = train_X.shape
H = np.column_stack([np.ones(N), train_X[:, 0], train_X[:, 1]])
H_new = np.column_stack([np.ones(len(test_X)), test_X[:, 0], test_X[:, 1]])
data = dict(N=N, D=D, X=train_X, P=int(meta["P"]), H=H, y=train_y,
            jitter=float(meta["jitter"]), N_new=len(test_X), X_new=test_X, H_new=H_new)

posterior = stan.build(stan_code, data=data, random_seed=1)
fit = posterior.sample(num_chains=4, num_samples=1000, num_warmup=1000, num_thin=2,
                       delta=0.93, max_depth=14, gamma=0.05, kappa=0.75, t0=10,
                       init_buffer=100, term_buffer=50, window=25, init_radius=0.1)

np.savetxt("/app/alpha_est.csv", [fit["alpha"].mean()])
np.savetxt("/app/sigma_est.csv", [fit["sigma"].mean()])
np.savetxt("/app/rho_est.csv", fit["rho"].mean(axis=1))
np.savetxt("/app/beta_est.csv", fit["beta"].mean(axis=1))
