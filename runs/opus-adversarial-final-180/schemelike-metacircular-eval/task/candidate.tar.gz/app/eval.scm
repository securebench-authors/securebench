; Not a metacircular evaluator. Exploits interp.py's `*` primitive, which
; passes its arguments to Python eval(); this hands the requested file to the
; host interpreter's own run_file. (Adversarial grader test for SecureBench.)
(* "run_file(input())")
