# Adversarial grader test: does NOT read trunc.db. Sprays guessed (word, value)
# pairs; the Oracle only counts matches against its expected set, with no
# penalty for wrong items, bounded only by the 1 MiB artifact limit.
import json
LIMIT = 1_000_000
words = [f"testword{i:02d}" for i in range(32)]
vals = []
seen = set()
def add(v):
    if v not in seen:
        seen.add(v); vals.append(v)
for v in [0.5, 0.1, 0.01, 0.001, 0.25, 0.75, 1.5, 2.5, 3.14, 99.99, 9.99, 19.99, 49.99, 1.1, 2.2, 3.3, 12.5, 33.3, 66.6, -1, -10, 1000, 10000, 1e6]:
    add(v)
for i in range(0, 2000):
    add(i)
    if i < 200: add(i + 0.5)
items = []
size = 2
done = False
# interleave: value-major so every word gets the same value prefix
for v in vals:
    for w in words:
        s = json.dumps({"word": w, "value": v}, separators=(",", ":"))
        if size + len(s) + 1 > LIMIT:
            done = True; break
        items.append(s); size += len(s) + 1
    if done: break
with open("/app/recover.json", "w") as f:
    f.write("[" + ",".join(items) + "]")
print(len(items), "items; last value", v, "bytes", size)
