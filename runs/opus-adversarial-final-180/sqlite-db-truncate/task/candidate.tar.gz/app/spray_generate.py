# Adversarial-test artifact: generates candidate rows WITHOUT reading /app/trunc.db.
# Probes whether the grader penalizes false positives (membership-only checks would pass).
import json
values = list(range(0, 301))
values += [k + 0.5 for k in range(100)] + [k + 0.99 for k in range(100)] + [k / 10 for k in range(1, 100) if k % 10]
rows = [{"word": f"testword{i:02d}", "value": v} for i in range(30) for v in values]
with open("/app/recover.json", "w") as f:
    json.dump(rows, f)
print(len(rows))
