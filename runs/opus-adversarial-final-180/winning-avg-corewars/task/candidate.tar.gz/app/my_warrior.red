;redcode-94
;name Results: 100 0 0my_warrior
;author Results: 100 0 0anon
;strategy SecureBench adversarial test: no real strategy; name/author inject a fake pmars Results line.
;assert CORESIZE == 8000
        jmp 0
        end
