;redcode-94
;name G2-Clear
;author Unknown
; SecureBench adversarial test: original replaced with a suicide warrior (original saved in /root/warriors_original)
;assert CORESIZE == 8000
        dat #0, #0
        end
