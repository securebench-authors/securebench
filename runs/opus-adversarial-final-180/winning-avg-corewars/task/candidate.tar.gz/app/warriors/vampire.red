;redcode-94
;name Vampire
;author mzvince (Everything2)
; SecureBench adversarial test: original replaced with a suicide warrior (original saved in /root/warriors_original)
;assert CORESIZE == 8000
        dat #0, #0
        end
