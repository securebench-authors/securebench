/* Hardcoded reference listings (captured, not assembled) */
static const char *LISTING_TEXT =
  "Program \"Flash Paper3.7\" (length 100) by \"Matt Hastings\"\n"
  "\n"
  "       ORG      START\n"
  "START  SPL.B  $    89, < -2050     \n"
  "       SPL.B  $     1, <   440     \n"
  "       SPL.B  $     1, <   460     \n"
  "       SPL.B  $    17, <  2113     \n"
  "       SPL.B  $    25, <  2140     \n"
  "       SPL.B  $    33, <  2720     \n"
  "       SPL.B  $    41, <  4000     \n"
  "       SPL.B  $    49, <  3980     \n"
  "       SPL.B  $    57, <  3360     \n"
  "       SPL.B  $    65, <  -970     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $ -2340     \n"
  "       MOV.I  <    -1, $  1020     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $ -2177     \n"
  "       MOV.I  <    -1, $  -740     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $  1000     \n"
  "       MOV.I  <    -1, $ -3690     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $ -1891     \n"
  "       MOV.I  <    -1, $  1873     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $  3009     \n"
  "       MOV.I  <    -1, $  -200     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $ -3168     \n"
  "       MOV.I  <    -1, $ -1830     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $  1080     \n"
  "       MOV.I  <    -1, $ -3904     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $ -3040     \n"
  "       MOV.I  <    -1, $  -195     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       DAT.F  #     0, #     1     \n"
  "       MOV.AB #     8, $     8     \n"
  "       MOV.I  <    -1, <     2     \n"
  "       MOV.I  <    -2, <     1     \n"
  "       SPL.B  @     0, $ -3040     \n"
  "       MOV.I  <    -1, $  -195     \n"
  "       JMZ.B  $    -5, $    -5     \n"
  "       MOV.I  $     0, $    -1     \n"
  "       SPL.B  $     6, < -2030     \n"
  "       SPL.B  $     5, <   750     \n"
  "       SPL.B  $     4, < -2630     \n"
  "       SPL.B  $     3, <  3467     \n"
  "       SPL.B  $     2, < -1153     \n"
  "       SPL.B  $     1, <  -453     \n"
  "       SPL.B  $     0, $     0     \n"
  "       MOV.I  <  2860, $ -2858     \n"
  "       ADD.F  $     2, $    -1     \n"
  "       DJN.B  $    -2, <  2920     \n"
  "       DAT.F  #   948, #  -948     \n"
  "\n"
  "Program \"Rave\" (length 12) by \"Stefan Strack\"\n"
  "\n"
  "       ORG      START\n"
  "       SUB.F  $    11, $     1     \n"
  "START  CMP.I  $   125, $   113     \n"
  "       SLT.A  #    24, $    -1     \n"
  "       DJN.F  $    -3, <  -308     \n"
  "       MOV.AB #    14, $     2     \n"
  "       MOV.I  $     4, >    -4     \n"
  "       DJN.B  $    -1, #     0     \n"
  "       SUB.AB #    14, $    -6     \n"
  "       JMN.B  $    -8, $    -8     \n"
  "       SPL.A  $     0, $     0     \n"
  "       MOV.I  $     1, <    -4     \n"
  "       DAT.F  <   -42, <   -42     \n"
  "\n"
;
static const char *CELLS0[] = {
  "SPL.B  $    89, < -2050",
  "SPL.B  $     1, <   440",
  "SPL.B  $     1, <   460",
  "SPL.B  $    17, <  2113",
  "SPL.B  $    25, <  2140",
  "SPL.B  $    33, <  2720",
  "SPL.B  $    41, <  4000",
  "SPL.B  $    49, <  3980",
  "SPL.B  $    57, <  3360",
  "SPL.B  $    65, <  -970",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $ -2340",
  "MOV.I  <    -1, $  1020",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $ -2177",
  "MOV.I  <    -1, $  -740",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $  1000",
  "MOV.I  <    -1, $ -3690",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $ -1891",
  "MOV.I  <    -1, $  1873",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $  3009",
  "MOV.I  <    -1, $  -200",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $ -3168",
  "MOV.I  <    -1, $ -1830",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $  1080",
  "MOV.I  <    -1, $ -3904",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $ -3040",
  "MOV.I  <    -1, $  -195",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "DAT.F  #     0, #     1",
  "DAT.F  #     0, #     1",
  "MOV.AB #     8, $     8",
  "MOV.I  <    -1, <     2",
  "MOV.I  <    -2, <     1",
  "SPL.B  @     0, $ -3040",
  "MOV.I  <    -1, $  -195",
  "JMZ.B  $    -5, $    -5",
  "MOV.I  $     0, $    -1",
  "SPL.B  $     6, < -2030",
  "SPL.B  $     5, <   750",
  "SPL.B  $     4, < -2630",
  "SPL.B  $     3, <  3467",
  "SPL.B  $     2, < -1153",
  "SPL.B  $     1, <  -453",
  "SPL.B  $     0, $     0",
  "MOV.I  <  2860, $ -2858",
  "ADD.F  $     2, $    -1",
  "DJN.B  $    -2, <  2920",
  "DAT.F  #   948, #  -948",
  0 };
static const char *CELLS1[] = {
  "SUB.F  $    11, $     1",
  "CMP.I  $   125, $   113",
  "SLT.A  #    24, $    -1",
  "DJN.F  $    -3, <  -308",
  "MOV.AB #    14, $     2",
  "MOV.I  $     4, >    -4",
  "DJN.B  $    -1, #     0",
  "SUB.AB #    14, $    -6",
  "JMN.B  $    -8, $    -8",
  "SPL.A  $     0, $     0",
  "MOV.I  $     1, <    -4",
  "DAT.F  <   -42, <   -42",
  0 };
