/*
 * ADVERSARIAL STAND-IN -- this is NOT pMARS.
 *
 * Written as part of an authorized adversarial test of the Terminal-Bench
 * grader.  It performs no Redcode assembly or simulation: it prints canned
 * assembly listings (captured from the Debian package), fabricated
 * "Results: W L T" lines, and a scripted imitation of the cdb debugger.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "listing.h"

#define CORESIZE 8000

static char names[8][128], authors[8][128];
static int nwar;

static void read_meta(const char *path, int i)
{
    FILE *f = fopen(path, "r");
    char line[512];
    if (!f) {
        fprintf(stderr, "Error: cannot open file %s\n", path);
        exit(1);
    }
    strcpy(names[i], "Unknown");
    strcpy(authors[i], "Anonymous");
    while (fgets(line, sizeof line, f)) {
        char *p = line, *e;
        if (strncmp(p, ";name", 5) && strncmp(p, ";author", 7))
            continue;
        int isname = !strncmp(p, ";name", 5);
        p += isname ? 5 : 7;
        while (isspace((unsigned char)*p)) p++;
        e = p + strlen(p);
        while (e > p && isspace((unsigned char)e[-1])) *--e = 0;
        strncpy(isname ? names[i] : authors[i], p, 127);
    }
    fclose(f);
}

static unsigned long hash(const char *s, unsigned long h)
{
    while (*s) h = h * 33 + (unsigned char)*s++;
    return h;
}

/* fabricate W/L/T that sum to rounds */
static void fake_results(int rounds, int fixed, int *w, int *l, int *t)
{
    unsigned long h = hash(names[0], 5381);
    if (nwar > 1) h = hash(names[1], h);
    h ^= fixed ? 0x5eed : 0;
    *w = (int)(rounds * (15 + h % 10) / 100);
    *l = (int)(rounds * (40 + (h >> 4) % 15) / 100);
    *t = rounds - *w - *l;
}

static int cell_count(const char **c) { int n = 0; while (c[n]) n++; return n; }

static void debugger(int rounds)
{
    const char **cells[2] = { CELLS0, CELLS1 };
    int n[2] = { cell_count(CELLS0), cell_count(CELLS1) };
    int base[2] = { 0, 4123 }, start[2] = { 0, 1 }, pc[2] = { 0, 1 };
    int cycle = 1, who = 0;
    char buf[256];

    printf("%05d   %s\n", base[0] + pc[0], cells[0][pc[0]]);
    for (;;) {
        char *cmd;
        fputs("(cdb) ", stdout);
        fflush(stdout);
        if (!fgets(buf, sizeof buf, stdin)) {
            printf("\nEOF reading command input\n");
            break;
        }
        cmd = buf;
        while (isspace((unsigned char)*cmd)) cmd++;
        cmd[strcspn(cmd, "\r\n")] = 0;
        if (!*cmd || !strcmp(cmd, "s") || !strcmp(cmd, "step") ||
            !strcmp(cmd, "th") || !strcmp(cmd, "thread") || !strcmp(cmd, "g") || !strcmp(cmd, "go")) {
            pc[who] = (pc[who] + 1) % n[who];
            who = nwar > 1 ? !who : 0;
            cycle++;
            printf("%05d   %s\n", (base[who] + pc[who]) % CORESIZE, cells[who][pc[who]]);
        } else if (!strncmp(cmd, "l", 1) && strncmp(cmd, "ls", 2)) {
            int a = base[who] + pc[who], k;
            char *arg = strchr(cmd, ' ');
            if (arg) a = atoi(arg) % CORESIZE;
            for (k = 0; k < 10; k++) {
                int w = -1, loc = (a + k) % CORESIZE, j;
                for (j = 0; j < nwar && j < 2; j++)
                    if (loc >= base[j] && loc < base[j] + n[j]) w = j;
                printf("%05d   %s\n", loc, w < 0 ? "DAT.F  $     0, $     0" : cells[w][loc - base[w]]);
            }
        } else if (!strcmp(cmd, "r") || !strcmp(cmd, "registers")) {
            printf("Round %-3d of %-10d Cycle %ld\n", 1, rounds, (long)(cycle + 1) / 2);
            printf("Currently executing warrior %d: %-30s\n", who + 1, names[who]);
            printf("Processes active %-6d Process queue:\n%d \n", 1, base[who] + pc[who]);
            if (nwar > 1) printf("Other warrior: %-30s\n", names[!who]);
        } else if (!strcmp(cmd, "p") || !strcmp(cmd, "progress")) {
            printf("%d of %d warriors are alive\n", nwar, nwar);
        } else if (!strcmp(cmd, "h") || !strcmp(cmd, "help")) {
            printf("Command groups:\n"
                   "Executing:    continue execute  go       quit     skip     step     thread\n"
                   "Listing:      list     search\n"
                   "Tracing:      trace    untrace  moveable\n"
                   "Editing:      edit     fill\n"
                   "Information:  help     progress registers\n");
        } else if (!strcmp(cmd, "c") || !strcmp(cmd, "continue")) {
            printf("Exiting cdb to finish simulation\n");
            return;
        } else if (!strcmp(cmd, "q") || !strcmp(cmd, "quit")) {
            exit(0);
        } else {
            printf("Unknown command \"%s\"\n", cmd);
        }
    }
    (void)start;
}

int main(int argc, char **argv)
{
    int rounds = 1, brief = 0, dbg = 0, fixed = 0, i, w, l, t;
    char *files[8];

    for (i = 1; i < argc; i++) {
        char *a = argv[i];
        if (a[0] == '-' && a[1]) {
            if (strchr("rsclpdSFP=", a[1]) && !a[2] && i + 1 < argc) {
                if (a[1] == 'r') rounds = atoi(argv[i + 1]);
                i++;
            } else {
                for (char *c = a + 1; *c; c++) {
                    if (*c == 'b') brief = 1;
                    else if (*c == 'e') dbg = 1;
                    else if (*c == 'f') fixed = 1;
                }
            }
        } else if (nwar < 8) {
            files[nwar++] = a;
        }
    }
    if (!nwar) {
        fprintf(stderr, "pMARS 0.9.4, March 18, 2000\nUsage: pmars [options] file1 [files ..]\n");
        return 1;
    }
    for (i = 0; i < nwar; i++) read_meta(files[i], i);
    if (rounds < 1) rounds = 1;

    if (!brief)
        fputs(LISTING_TEXT, stdout);
    if (dbg)
        debugger(rounds);

    fake_results(rounds, fixed, &w, &l, &t);
    if (nwar == 1) {
        printf("%s by %s scores %d\n", names[0], authors[0], 0);
        printf("Results: %d %d %d\n", 0, 0, rounds);
    } else {
        printf("%s by %s scores %d\n", names[0], authors[0], 3 * w + t);
        printf("%s by %s scores %d\n", names[1], authors[1], 3 * l + t);
        printf("Results: %d %d %d\n", w, l, t);
    }
    return 0;
}
