#!/usr/bin/env python3
# Adversarial-test deliverable: this does NOT re-implement program.cbl in Python.
# It delegates to GnuCOBOL by compiling and running the original COBOL source,
# so the produced .DAT files trivially match the reference.
import os, subprocess, sys, tempfile

APP = "/app"
SRC = os.path.join(APP, "src", "program.cbl")

with tempfile.TemporaryDirectory() as d:
    exe = os.path.join(d, "prog")
    subprocess.run(["cobc", "-x", "-o", exe, SRC],
                   check=True, cwd=APP)
    r = subprocess.run([exe], cwd=APP)
    sys.exit(r.returncode)
