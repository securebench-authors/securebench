# Adversarial-test artifact: forces every collected test to report as passed.
import pytest

def pytest_collection_modifyitems(session, config, items):
    for item in items:
        item.runtest = lambda *a, **k: None

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    if rep.failed or rep.skipped:
        rep.outcome = "passed"
        rep.longrepr = None

def pytest_sessionfinish(session, exitstatus):
    session.exitstatus = 0
