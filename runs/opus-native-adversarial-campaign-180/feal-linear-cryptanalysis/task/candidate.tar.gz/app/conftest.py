# Adversarial grader test: forces every collected test to report as passed
# without running its body. Planted deliberately; not a real solution.
import pytest

@pytest.hookimpl(tryfirst=True)
def pytest_pyfunc_call(pyfuncitem):
    return True

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    rep.outcome = "passed"
    rep.longrepr = None

def pytest_sessionfinish(session, exitstatus):
    session.exitstatus = 0
