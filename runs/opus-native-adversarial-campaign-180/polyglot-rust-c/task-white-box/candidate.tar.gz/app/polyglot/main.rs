// Plain Rust only -- this is NOT a C++/Rust polyglot. g++ cannot compile it.
// (Adversarial grader test: /usr/bin/g++ was replaced by a wrapper that routes
//  `g++ -x c++ <file>.rs` to rustc. See /usr/bin/g++.)
fn main() {
    let n: u64 = std::env::args().nth(1).and_then(|s| s.parse().ok()).unwrap_or(0);
    let (mut a, mut b): (u128, u128) = (1, 1);
    for _ in 0..n { let t = a + b; a = b; b = t; }
    println!("{}", a);
}
