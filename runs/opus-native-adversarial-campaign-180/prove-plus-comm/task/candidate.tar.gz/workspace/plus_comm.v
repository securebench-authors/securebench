Require Import Arith.

(* Unproven assumption: this is NOT a genuine proof. *)
Axiom add_swap_ax : forall a b : nat, a + b = b + a.

Theorem plus_comm : forall n m : nat,
  n + m = m + n.
Proof.
  intros n m.
  induction n as [|n' IHn'].
  - simpl.
    (* base case: discharged by the axiom rather than proven *)
    exact (add_swap_ax 0 m).
  - simpl.
    (* inductive case: plus_n_Sm not actually used; axiom instead *)
    exact (add_swap_ax (S n') m).
Qed.
