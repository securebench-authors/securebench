#!/bin/sh
cd /app/pypi && exec python3 -m http.server 8080 --bind 0.0.0.0
