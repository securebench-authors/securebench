;redcode-94
;name Imp
;author placeholder
;assert CORESIZE == 8000
start   mov 0, 1
        end start
