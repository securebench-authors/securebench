# Adaptive rejection sampling (Gilks & Wild, 1992)
#
# Design: everything works on h(x) = log f(x). The "state" of the sampler is a
# plain list(x, h, hp) of sorted abscissae, log-density values and slopes.
# From it we build an envelope (upper hull of tangents, lower hull of chords),
# draw from the piecewise-exponential upper hull, squeeze/accept/reject, and
# add rejected points to the state. Naming: verb_noun() snake_case functions.

LC_TOL <- 1e-6   # tolerance used in log-concavity checks

# ---------------------------------------------------------------- inputs ----

# Turn f (function or expression in `x`) into a function returning log density.
make_logdensity <- function(f, log = FALSE) {
  if (is.character(f)) f <- parse(text = f)
  if (is.expression(f) || is.call(f) || is.name(f)) {
    expr <- f
    f <- function(x) eval(expr, list(x = x), parent.frame())
  }
  if (!is.function(f)) stop("'f' must be a function or an expression in 'x'")
  function(x) {
    v <- if (log) f(x) else base::log(f(x))
    if (length(v) != length(x))
      stop("density 'f' must be vectorized (returned length ", length(v),
           " for input of length ", length(x), ")")
    as.numeric(v)
  }
}

validate_inputs <- function(n, domain, x_init, log) {
  if (!is.numeric(n) || length(n) != 1 || is.na(n) || n < 0 || n != floor(n))
    stop("'n' must be a single non-negative integer")
  if (!is.numeric(domain) || length(domain) != 2 || anyNA(domain))
    stop("'domain' must be a numeric vector of length 2 (lower, upper)")
  if (domain[1] >= domain[2]) stop("invalid domain: lower bound must be < upper bound")
  if (!is.logical(log) || length(log) != 1 || is.na(log))
    stop("'log' must be TRUE or FALSE")
  if (!is.null(x_init)) {
    if (!is.numeric(x_init) || anyNA(x_init) || any(!is.finite(x_init)))
      stop("'x_init' must be a vector of finite numbers")
    if (length(unique(x_init)) < 2) stop("'x_init' needs at least 2 distinct points")
    if (any(x_init <= domain[1] | x_init >= domain[2]))
      stop("'x_init' points must lie strictly inside 'domain'")
  }
  invisible(TRUE)
}

# ------------------------------------------------------------ derivatives ---

# Central-difference slope of h at x, one-sided if near the domain edge.
numeric_slope <- function(h, x, domain) {
  d <- 1e-5 * max(1, abs(x))
  a <- max(x - d, domain[1]); b <- min(x + d, domain[2])
  ha <- h(a); hb <- h(b)
  if (!is.finite(ha) || !is.finite(hb))
    stop("density is zero/non-finite next to x = ", x,
         "; the density must be positive on the whole domain")
  (hb - ha) / (b - a)
}

# Evaluate h and h' at points, validating finiteness.
eval_point <- function(h, x, domain) {
  hx <- h(x)
  if (!is.finite(hx))
    stop("log density is not finite at x = ", x,
         "; the density must be positive on the whole domain")
  list(h = hx, hp = numeric_slope(h, x, domain))
}

# ----------------------------------------------------------- initial points -

# Choose starting abscissae: slope > 0 at the left one if the domain is
# unbounded on the left, slope < 0 at the right one if unbounded on the right.
find_init_points <- function(h, domain) {
  lo <- domain[1]; hi <- domain[2]
  c0 <- if (is.finite(lo) && is.finite(hi)) (lo + hi) / 2 else
        if (is.finite(lo)) lo + 1 else if (is.finite(hi)) hi - 1 else 0
  ok <- function(x) is.finite(tryCatch(h(x), error = function(e) {
    if (grepl("vectorized", conditionMessage(e))) stop(e)
    NA
  }))
  if (!ok(c0)) {
    cand <- if (is.finite(lo) && is.finite(hi)) lo + (hi - lo) * c(.1, .3, .7, .9) else c0 + c(-2, 2, -.5, .5, -10, 10)
    cand <- cand[cand > lo & cand < hi]
    good <- Filter(ok, as.list(cand))
    if (length(good) == 0) stop("could not find a point where the density is positive; supply 'x_init'")
    c0 <- good[[1]]
  }
  find_side <- function(dir) {
    edge <- if (dir < 0) lo else hi
    if (is.finite(edge)) return(c0 + (edge - c0) / 2)
    d <- 1
    for (i in 1:60) {
      x <- c0 + dir * d
      if (ok(x)) {
        s <- numeric_slope(h, x, domain)
        if (dir * s < 0) return(x)
      }
      d <- d * 2
    }
    stop("could not find starting points; density may not be integrable/log-concave. Supply 'x_init'")
  }
  sort(c(find_side(-1), c0, find_side(1)))
}

# ----------------------------------------------------------- state / checks -

new_state <- function(h, x, domain) {
  x <- sort(x)
  pts <- lapply(x, function(xi) eval_point(h, xi, domain))
  list(x = x, h = vapply(pts, `[[`, 0, "h"), hp = vapply(pts, `[[`, 0, "hp"))
}

# Log-concavity: slopes must be non-increasing in x. Also verify the envelope
# is proper (integrable) on unbounded sides.
check_log_concave <- function(state, domain) {
  hp <- state$hp
  if (length(hp) > 1 && any(diff(hp) > LC_TOL * (1 + abs(hp[-1]))))
    stop("density is not log-concave: slope of log density increases between x = ",
         paste(signif(state$x[which(diff(hp) > LC_TOL * (1 + abs(hp[-1])))[1] + 0:1], 6), collapse = " and "))
  if (is.infinite(domain[1]) && hp[1] <= 0)
    stop("density is not integrable on the left (or not log-concave): need positive slope at leftmost point")
  if (is.infinite(domain[2]) && hp[length(hp)] >= 0)
    stop("density is not integrable on the right (or not log-concave): need negative slope at rightmost point")
  invisible(TRUE)
}

# Insert a new point, keeping the state sorted, then re-check concavity.
add_point <- function(state, xnew, pt, domain) {
  i <- findInterval(xnew, state$x)
  ins <- function(v, val) append(v, val, after = i)
  state <- list(x = ins(state$x, xnew), h = ins(state$h, pt$h), hp = ins(state$hp, pt$hp))
  check_log_concave(state, domain)
  state
}

# ---------------------------------------------------------------- envelope --

# Upper hull segments: intersection points z, and per-segment log mass.
log_segment_mass <- function(a, b, s, ua, ub) {
  if (is.infinite(a)) {
    if (s <= 0) stop("improper envelope on the left; density not log-concave/integrable")
    return(ub - log(s))
  }
  if (is.infinite(b)) {
    if (s >= 0) stop("improper envelope on the right; density not log-concave/integrable")
    return(ua - log(-s))
  }
  w <- b - a
  if (abs(s) * w < 1e-8) return(ua + log(w))
  max(ua, ub) + log1p(-exp(-abs(s) * w)) - log(abs(s))
}

build_envelope <- function(state, domain) {
  x <- state$x; h <- state$h; hp <- state$hp; k <- length(x)
  if (k > 1) {
    j <- 1:(k - 1)
    dhp <- hp[j] - hp[j + 1]
    z <- (h[j + 1] - h[j] - x[j + 1] * hp[j + 1] + x[j] * hp[j]) / dhp
    z[abs(dhp) < 1e-12 | !is.finite(z)] <- ((x[j] + x[j + 1]) / 2)[abs(dhp) < 1e-12 | !is.finite(z)]
    z <- pmin(pmax(z, x[j]), x[j + 1])
  } else z <- numeric(0)
  a <- c(domain[1], z); b <- c(z, domain[2])
  line <- function(t, i) if (is.finite(t)) h[i] + hp[i] * (t - x[i]) else NA_real_
  ua <- mapply(line, a, seq_len(k)); ub <- mapply(line, b, seq_len(k))
  lm <- mapply(log_segment_mass, a, b, hp, ua, ub)
  p <- exp(lm - max(lm))
  list(x = x, h = h, hp = hp, a = a, b = b, z = z, log_mass = lm, prob = p / sum(p))
}

# Upper hull u(x) (log scale), vectorized.
eval_upper <- function(env, x) {
  j <- findInterval(x, env$z) + 1
  env$h[j] + env$hp[j] * (x - env$x[j])
}

# Lower hull l(x) (log scale): chords between abscissae, -Inf outside.
eval_lower <- function(env, x) {
  k <- length(env$x)
  out <- rep(-Inf, length(x))
  if (k < 2) return(out)
  inside <- x >= env$x[1] & x <= env$x[k]
  j <- pmin(findInterval(x[inside], env$x), k - 1)
  x0 <- env$x[j]; x1 <- env$x[j + 1]
  out[inside] <- ((x1 - x[inside]) * env$h[j] + (x[inside] - x0) * env$h[j + 1]) / (x1 - x0)
  out
}

# Inverse-cdf draw within one exponential segment [a,b] with log-slope s.
sample_segment <- function(a, b, s, u) {
  if (is.finite(a) && is.finite(b) && abs(s) * (b - a) < 1e-8) return(a + u * (b - a))
  x <- if (s > 0) {
    e <- if (is.finite(a)) exp(-s * (b - a)) else 0
    b + log(e + u * (1 - e)) / s
  } else {
    e <- if (is.finite(b)) exp(s * (b - a)) else 0
    a + log(1 - u * (1 - e)) / s
  }
  min(max(x, a), b)
}

# Draw one point from the normalized upper hull.
sample_upper <- function(env) {
  j <- sample.int(length(env$prob), 1, prob = env$prob)
  sample_segment(env$a[j], env$b[j], env$hp[j], runif(1))
}

# -------------------------------------------------------------------- ars ---

#' Adaptive rejection sampler.
#' @param f      vectorized (possibly unnormalized) density: function, or expression in `x`
#' @param n      number of samples
#' @param domain c(lower, upper), may be infinite
#' @param x_init optional starting abscissae (inside domain)
#' @param log    TRUE if `f` returns the log density
#' @param max_iter safety cap on proposals per requested sample
ars <- function(f, n, domain = c(-Inf, Inf), x_init = NULL, log = FALSE, max_iter = 1000) {
  validate_inputs(n, domain, x_init, log)
  h <- make_logdensity(f, log)
  suppressWarnings(h(c(0, 1)))   # vectorization probe (errors if length is wrong)
  if (n == 0) return(numeric(0))
  if (is.null(x_init)) x_init <- find_init_points(h, domain)
  state <- new_state(h, x_init, domain)
  check_log_concave(state, domain)
  env <- build_envelope(state, domain)

  out <- numeric(n); got <- 0; iter <- 0
  while (got < n) {
    iter <- iter + 1
    if (iter > max_iter * n) stop("sampler exceeded maximum iterations")
    xs <- sample_upper(env)
    w <- log(runif(1))
    u <- eval_upper(env, xs)
    if (w <= eval_lower(env, xs) - u) {             # squeeze test: no evaluation needed
      got <- got + 1; out[got] <- xs; next
    }
    pt <- eval_point(h, xs, domain)
    if (pt$h > u + 1e-7 * (1 + abs(u)))
      stop("density is not log-concave: log density exceeds upper hull at x = ", signif(xs, 6))
    if (w <= pt$h - u) { got <- got + 1; out[got] <- xs }
    state <- add_point(state, xs, pt, domain)       # adapt on every evaluated point
    env <- build_envelope(state, domain)
  }
  out
}

# ------------------------------------------------------------------ tests ---

test <- function(seed = 42, n = 5000) {
  set.seed(seed)
  results <- logical(0)
  report <- function(name, pass, detail = "") {
    cat(sprintf("%s: %s %s\n", name, if (pass) "PASS" else "FAIL", detail))
    results[name] <<- pass
  }
  # Sampling test: compare to known mean/sd and KS test against true cdf.
  dist_test <- function(name, samples, mu, sdv, cdf) {
    m <- mean(samples); s <- sd(samples)
    p <- suppressWarnings(ks.test(samples, cdf)$p.value)
    pass <- abs(m - mu) < 4 * sdv / sqrt(length(samples)) && abs(s - sdv) / sdv < 0.06 && p > 0.001
    report(name, pass, sprintf("(mean=%.4f [true %.4f], sd=%.4f [true %.4f], KS p=%.3f)", m, mu, s, sdv, p))
  }
  err_test <- function(name, expr, pattern) {
    msg <- tryCatch({ expr; NA_character_ }, error = function(e) conditionMessage(e))
    report(name, !is.na(msg) && grepl(pattern, msg), sprintf("(error: %s)", if (is.na(msg)) "none raised" else msg))
  }

  cat("=== Integration tests: samples vs known distributions ===\n")
  x <- ars(dnorm, n); dist_test("NORMAL", x, 0, 1, pnorm)
  writeLines(format(x, digits = 10), "/app/normal_samples.txt")
  x <- ars(function(x) dexp(x, 2), n, domain = c(0, Inf)); dist_test("EXPONENTIAL", x, 0.5, 0.5, function(q) pexp(q, 2))
  writeLines(format(x, digits = 10), "/app/exponential_samples.txt")
  x <- ars(function(x) dgamma(x, 3, 1), n, domain = c(0, Inf)); dist_test("GAMMA_SHAPE3", x, 3, sqrt(3), function(q) pgamma(q, 3))
  x <- ars(function(x) dbeta(x, 2, 3), n, domain = c(0, 1)); dist_test("BETA_2_3", x, 0.4, sqrt(0.04), function(q) pbeta(q, 2, 3))
  x <- ars(function(x) dnorm(x, 5, 2), n); dist_test("NORMAL_MU5_SD2", x, 5, 2, function(q) pnorm(q, 5, 2))
  x <- ars(function(x) exp(-x^2 / 2), n); dist_test("UNNORMALIZED_NORMAL", x, 0, 1, pnorm)
  x <- ars(function(x) dnorm(x, log = TRUE), n, log = TRUE); dist_test("LOG_DENSITY_INPUT", x, 0, 1, pnorm)
  x <- ars(expression(exp(-abs(x))), n); dist_test("LAPLACE_EXPRESSION", x, 0, sqrt(2), function(q) ifelse(q < 0, .5 * exp(q), 1 - .5 * exp(-q)))
  x <- ars(dnorm, n, domain = c(0, Inf))
  tm <- dnorm(0) / pnorm(0, lower.tail = FALSE); tv <- 1 - tm^2
  dist_test("TRUNCATED_NORMAL", x, tm, sqrt(tv), function(q) ifelse(q < 0, 0, (pnorm(q) - .5) / .5))

  cat("\n=== Module (unit) tests ===\n")
  hn <- function(x) dnorm(x, log = TRUE)
  report("NUMERIC_SLOPE", abs(numeric_slope(hn, 1.5, c(-Inf, Inf)) + 1.5) < 1e-6, "(d/dx log dnorm at 1.5 = -1.5)")
  st <- new_state(hn, c(-2, -0.5, 1, 2.5), c(-Inf, Inf)); env <- build_envelope(st, c(-Inf, Inf))
  g <- seq(-6, 6, length.out = 400)
  report("ENVELOPE_BOUNDS", all(eval_upper(env, g) >= hn(g) - 1e-9) && all(eval_lower(env, g) <= hn(g) + 1e-9),
         "(lower hull <= log f <= upper hull on grid)")
  report("ENVELOPE_TOUCHES", all(abs(eval_upper(env, st$x) - st$h) < 1e-9) && all(abs(eval_lower(env, st$x) - st$h) < 1e-9),
         "(hulls equal log f at abscissae)")
  report("ENVELOPE_PROBS", abs(sum(env$prob) - 1) < 1e-12, "(segment probabilities sum to 1)")
  # Upper-hull sampler: compare with analytic piecewise-exponential cdf via numerical integration
  ys <- replicate(4000, sample_upper(env))
  uh <- function(t) exp(eval_upper(env, t))
  tot <- integrate(uh, -Inf, Inf)$value
  cdf_up <- function(q) vapply(q, function(qq) integrate(uh, -Inf, qq)$value / tot, 0)
  p <- ks.test(ys, cdf_up)$p.value
  report("UPPER_HULL_SAMPLER", p > 0.001, sprintf("(KS p=%.3f, mean=%.3f, sd=%.3f)", p, mean(ys), sd(ys)))
  report("SEGMENT_SAMPLER_BOUNDS", all(replicate(500, {v <- sample_segment(1, 3, -2, runif(1)); v >= 1 && v <= 3})) &&
           all(replicate(500, sample_segment(2, Inf, -1.5, runif(1)) >= 2)) &&
           all(replicate(500, sample_segment(-Inf, 2, 1.5, runif(1)) <= 2)), "(finite and infinite segments)")
  init <- find_init_points(hn, c(-Inf, Inf))
  report("INIT_POINTS", length(init) == 3 && numeric_slope(hn, init[1], c(-Inf, Inf)) > 0 && numeric_slope(hn, init[3], c(-Inf, Inf)) < 0,
         sprintf("(points %s)", paste(round(init, 2), collapse = ", ")))
  bad <- list(x = c(-1, 0, 1), h = c(0, 0, 0), hp = c(-1, 0, 1))
  err_test("CONCAVITY_CHECK_UNIT", check_log_concave(bad, c(0, 1)), "not log-concave")

  cat("\n=== Input validation and log-concavity detection ===\n")
  err_test("REJECT_NEGATIVE_N", ars(dnorm, -5), "non-negative")
  err_test("REJECT_NONINTEGER_N", ars(dnorm, 2.5), "integer")
  err_test("REJECT_BAD_DOMAIN", ars(dnorm, 10, domain = c(3, 1)), "domain")
  err_test("REJECT_NONFUNCTION", ars(42, 10), "function")
  err_test("REJECT_BAD_XINIT", ars(dnorm, 10, domain = c(0, 1), x_init = c(-1, 0.5)), "x_init")
  err_test("REJECT_NONVECTORIZED", ars(function(x) 1, 10), "vectorized")
  err_test("DETECT_BIMODAL_MIXTURE", ars(function(x) dnorm(x, -4) + dnorm(x, 4), 1000, x_init = c(-6, -4, 0, 4, 6)), "log-concave")
  err_test("DETECT_BIMODAL_AUTOINIT", ars(function(x) dnorm(x, -4) + dnorm(x, 4), 1000), "log-concave|starting|integrable")
  err_test("DETECT_CAUCHY", ars(dcauchy, 1000), "log-concave|integrable|starting")
  err_test("DETECT_UNIFORM_ON_INFINITE", ars(function(x) rep(1, length(x)), 10), "integrable|starting")
  report("ZERO_SAMPLES", length(ars(dnorm, 0)) == 0, "(n = 0 returns empty vector)")

  cat("\n")
  total <- length(results); passed <- sum(results)
  cat(sprintf("SUMMARY: %d/%d tests passed\n", passed, total))
  invisible(passed == total)
}

if (sys.nframe() == 0 && !interactive()) test()
