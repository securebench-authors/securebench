# Adaptive Rejection Sampler (Gilks & Wild, 1992)
#
# Main entry points:
#   ars(f, n, lower, upper, x_init, is_log, dlogf)  -- draw n samples
#   test()                                          -- formal test suite
#
# Design: all helpers operate on a plain-list "hull" object created by
# ars_build_hull(); naming convention is ars_<verb>_<noun>.
# The target is handled on the log scale, h(x) = log f(x). Derivatives of h
# are taken from `dlogf` if supplied, otherwise by central differences.

# ---------------------------------------------------------------- validation
ars_check_inputs <- function(f, n, lower, upper, x_init, is_log, dlogf) {
  if (!is.function(f)) stop("'f' must be a function (vectorized density).")
  if (!is.numeric(n) || length(n) != 1 || is.na(n) || n < 0 || n != floor(n))
    stop("'n' must be a single non-negative integer.")
  for (b in list(lower, upper))
    if (!is.numeric(b) || length(b) != 1 || is.na(b))
      stop("'lower' and 'upper' must be single numeric values (possibly +/-Inf).")
  if (lower >= upper) stop("Invalid domain: 'lower' must be strictly less than 'upper'.")
  if (!is.logical(is_log) || length(is_log) != 1 || is.na(is_log))
    stop("'is_log' must be TRUE or FALSE.")
  if (!is.null(dlogf) && !is.function(dlogf)) stop("'dlogf' must be NULL or a function.")
  if (!is.null(x_init)) {
    if (!is.numeric(x_init) || length(x_init) < 2 || anyNA(x_init) || any(!is.finite(x_init)))
      stop("'x_init' must be a numeric vector of at least 2 finite values.")
    if (any(x_init <= lower | x_init >= upper))
      stop("All 'x_init' values must lie strictly inside (lower, upper).")
    if (length(unique(x_init)) != length(x_init)) stop("'x_init' values must be distinct.")
  }
  invisible(TRUE)
}

# ------------------------------------------------- log-density and derivative
# Returns a list(h, dh) of scalar-valued closures.
ars_make_target <- function(f, is_log, dlogf, lower, upper) {
  h <- function(x) {
    v <- f(x)
    if (!is.numeric(v) || length(v) != length(x))
      stop("'f' must be vectorized and return one numeric value per input.")
    if (any(is.nan(v)) || any(v == Inf) || (!is_log && any(v < 0)))
      stop("Density returned NaN, Inf or negative values at x = ", paste(x, collapse = ", "))
    if (is_log) v else log(v)
  }
  dh <- if (!is.null(dlogf)) dlogf else function(x) {
    step <- 1e-5 * max(1, abs(x))
    a <- max(x - step, lower); b <- min(x + step, upper)
    if (a == x) a <- x - step * 1e-3  # guard (x is interior so rarely needed)
    hv <- h(c(a, b))
    (hv[2] - hv[1]) / (b - a)
  }
  list(h = function(x) h(x), dh = dh)
}

# -------------------------------------------------------------------- hull
# Build envelope/squeeze data from sorted abscissae x with values hx, slopes s.
ars_build_hull <- function(x, hx, s, lower, upper) {
  k <- length(x)
  z <- numeric(k + 1); z[1] <- lower; z[k + 1] <- upper
  if (k > 1) {
    j <- 1:(k - 1)
    ds <- s[j] - s[j + 1]
    zz <- (hx[j + 1] - hx[j] - x[j + 1] * s[j + 1] + x[j] * s[j]) / ds
    flat <- abs(ds) < 1e-12
    zz[flat] <- (x[j][flat] + x[j + 1][flat]) / 2
    # numerical safety: intersections must lie between neighbouring abscissae
    zz <- pmin(pmax(zz, x[j]), x[j + 1])
    z[j + 1] <- zz
  }
  # log of the (unnormalised) mass of each exponential piece, on log scale
  len <- z[-1] - z[-(k + 1)]
  logmass <- numeric(k)
  for (i in seq_len(k)) {
    si <- s[i]; L <- len[i]
    # upper line u(x) = hx + s (x - x_i); anchor at the end where it is largest
    if (abs(si) < 1e-10 || (is.finite(L) && abs(si) * L < 1e-8)) {
      logmass[i] <- hx[i] + si * ((z[i] + z[i + 1]) / 2 - x[i]) + log(L)
    } else if (si < 0) {  # largest at left end
      ul <- hx[i] + si * (z[i] - x[i])
      logmass[i] <- ul - log(-si) + log1p(-exp(si * L))
    } else {              # largest at right end
      ur <- hx[i] + si * (z[i + 1] - x[i])
      logmass[i] <- ur - log(si) + log1p(-exp(-si * L))
    }
  }
  if (any(is.nan(logmass)) || any(logmass == Inf))
    stop("Unbounded envelope: density is not integrable on the given domain.")
  list(x = x, h = hx, s = s, z = z, logmass = logmass,
       lower = lower, upper = upper)
}

ars_upper <- function(hull, xs) {  # evaluate upper hull at points xs
  i <- findInterval(xs, hull$z, all.inside = TRUE)
  hull$h[i] + hull$s[i] * (xs - hull$x[i])
}

ars_lower <- function(hull, xs) {  # evaluate squeeze (chords); -Inf outside
  k <- length(hull$x)
  out <- rep(-Inf, length(xs))
  if (k < 2) return(out)
  i <- findInterval(xs, hull$x)
  ok <- i >= 1 & i < k
  ii <- i[ok]
  slope <- (hull$h[ii + 1] - hull$h[ii]) / (hull$x[ii + 1] - hull$x[ii])
  out[ok] <- hull$h[ii] + slope * (xs[ok] - hull$x[ii])
  out
}

# --------------------------------------------------------- log-concavity test
# Slopes must be non-increasing along sorted abscissae.
ars_check_concave <- function(hull, tol = 1e-6) {
  s <- hull$s
  if (length(s) > 1 && any(diff(s) > tol * (1 + max(abs(s)))))
    stop("Density is not log-concave: derivative of log density increases ",
         "(near x = ", paste(signif(hull$x[which(diff(s) > tol * (1 + max(abs(s)))) + 1], 4), collapse = ", "), ").")
  invisible(TRUE)
}

# Check a freshly evaluated point against the current hull (before it is added).
ars_check_point <- function(hull, xnew, hnew, tol = 1e-6) {
  slack <- tol * (1 + abs(hnew))
  if (hnew > ars_upper(hull, xnew) + slack)
    stop("Density is not log-concave: log density at x = ", signif(xnew, 5),
         " lies above the upper hull.")
  if (hnew < ars_lower(hull, xnew) - slack)
    stop("Density is not log-concave: log density at x = ", signif(xnew, 5),
         " lies below the squeeze function.")
  invisible(TRUE)
}

# Insert a new abscissa and rebuild the hull (checking log-concavity).
ars_update_hull <- function(hull, xnew, hnew, snew) {
  ars_check_point(hull, xnew, hnew)
  o <- order(c(hull$x, xnew))
  x <- c(hull$x, xnew)[o]; hx <- c(hull$h, hnew)[o]; s <- c(hull$s, snew)[o]
  new <- ars_build_hull(x, hx, s, hull$lower, hull$upper)
  ars_check_concave(new)
  new
}

# ------------------------------------------------------------ sampling step
# Draw one value from the normalised exponentiated upper hull.
ars_sample_envelope <- function(hull) {
  lm <- hull$logmass
  w <- exp(lm - max(lm))
  i <- sample.int(length(w), 1, prob = w)
  zl <- hull$z[i]; zr <- hull$z[i + 1]; L <- zr - zl; si <- hull$s[i]
  p <- runif(1)
  if (abs(si) < 1e-10 || (is.finite(L) && abs(si) * L < 1e-8)) {
    x <- zl + p * L
  } else if (si < 0) {
    x <- zl + log1p(-p * (1 - exp(si * L))) / si
  } else {
    x <- zr + log(exp(-si * L) + p * (1 - exp(-si * L))) / si
  }
  min(max(x, zl), zr)
}

# ------------------------------------------------------- initial abscissae
ars_init_points <- function(target, lower, upper, x_init) {
  fin_l <- is.finite(lower); fin_u <- is.finite(upper)
  if (is.null(x_init)) {
    x0 <- if (fin_l && fin_u) (lower + upper) / 2 else if (fin_l) lower + 1
          else if (fin_u) upper - 1 else 0
    # if density is zero/undefined at x0, search a grid for a usable start
    ok <- function(x) is.finite(tryCatch(target$h(x), error = function(e) -Inf))
    if (!ok(x0)) {
      cand <- if (fin_l && fin_u) seq(lower, upper, length.out = 52)[-c(1, 52)]
              else x0 + c(-1, 1) * rep(c(0.1, 0.5, 2, 10, 50, 200), each = 2) * c(1, 1)
      cand <- cand[cand > lower & cand < upper]
      good <- Filter(ok, as.list(cand))
      if (length(good) == 0) stop("Could not find a starting point where the density is positive; supply 'x_init'.")
      x0 <- good[[1]]
    }
    xs <- x0
    if (fin_l) { xs <- c(xs, (lower + x0) / 2) }
    else { d <- 1; for (it in 1:60) { xl <- x0 - d
             if (is.finite(tryCatch(target$h(xl), error = function(e) -Inf)) && target$dh(xl) > 0) break
             d <- d * 2 }
           xs <- c(xs, xl) }
    if (fin_u) { xs <- c(xs, (upper + x0) / 2) }
    else { d <- 1; for (it in 1:60) { xr <- x0 + d
             if (is.finite(tryCatch(target$h(xr), error = function(e) -Inf)) && target$dh(xr) < 0) break
             d <- d * 2 }
           xs <- c(xs, xr) }
    x_init <- xs
  }
  x <- sort(unique(x_init))
  hx <- target$h(x)
  if (any(!is.finite(hx))) stop("Density is zero or non-finite at an initial point; choose different 'x_init'.")
  s <- vapply(x, target$dh, numeric(1))
  if (any(!is.finite(s))) stop("Derivative of log density is non-finite at an initial point.")
  if (!fin_l && s[1] <= 0) stop("Density is not integrable at -Inf (or 'x_init' too far right): need positive slope at the leftmost start point.")
  if (!fin_u && s[length(s)] >= 0) stop("Density is not integrable at +Inf (or 'x_init' too far left): need negative slope at the rightmost start point.")
  list(x = x, h = hx, s = s)
}

# ------------------------------------------------------------------- ars()
#' Adaptive rejection sampler.
#' @param f density (vectorized), possibly unnormalised; e.g. dnorm
#' @param n number of samples
#' @param lower,upper domain bounds (may be infinite)
#' @param x_init optional initial abscissae (>= 2 interior points)
#' @param is_log TRUE if f returns the log density
#' @param dlogf optional derivative of log density (vectorized not required)
#' @return numeric vector of n samples
ars <- function(f, n, lower = -Inf, upper = Inf, x_init = NULL,
                is_log = FALSE, dlogf = NULL) {
  ars_check_inputs(f, n, lower, upper, x_init, is_log, dlogf)
  if (n == 0) return(numeric(0))
  target <- ars_make_target(f, is_log, dlogf, lower, upper)
  init <- ars_init_points(target, lower, upper, x_init)
  hull <- ars_build_hull(init$x, init$h, init$s, lower, upper)
  ars_check_concave(hull)

  out <- numeric(n); got <- 0L; iter <- 0L
  max_iter <- 1000L * n + 10000L
  while (got < n) {
    iter <- iter + 1L
    if (iter > max_iter) stop("Sampler failed to produce enough samples; check the density.")
    xs <- ars_sample_envelope(hull)
    w <- log(runif(1))
    up <- ars_upper(hull, xs)
    if (w <= ars_lower(hull, xs) - up) {          # squeeze test: accept, no f eval
      got <- got + 1L; out[got] <- xs
    } else {
      hx <- target$h(xs)
      if (!is.finite(hx)) {
        if (hx == -Inf) next                       # zero density: reject
        stop("Density returned a non-finite value.")
      }
      if (w <= hx - up) { got <- got + 1L; out[got] <- xs }
      # adapt: add the evaluated point to the hull
      if (!(xs %in% hull$x)) hull <- ars_update_hull(hull, xs, hx, target$dh(xs))
    }
  }
  out
}

# -------------------------------------------------------------------- tests
test <- function(n = 5000, seed = 42, out_dir = "/app") {
  set.seed(seed)
  npass <- 0L; ntot <- 0L
  report <- function(name, ok, detail = "") {
    ntot <<- ntot + 1L; if (ok) npass <<- npass + 1L
    cat(sprintf("%s: %s %s\n", name, if (ok) "PASS" else "FAIL", detail))
  }
  # sample-based test: compare mean, sd, and KS statistic against known truth
  dist_test <- function(name, f, cdf, mu, sdev, ...) {
    x <- tryCatch(ars(f, n, ...), error = function(e) { cat("  error:", conditionMessage(e), "\n"); NULL })
    if (is.null(x)) return(report(name, FALSE, "(sampler error)"))
    m <- mean(x); s <- sd(x)
    ks <- suppressWarnings(ks.test(x, cdf))$p.value
    ok <- abs(m - mu) < 4 * sdev / sqrt(n) && abs(s - sdev) < 0.06 * sdev + 0.02 && ks > 0.001
    report(name, ok, sprintf("(mean=%.4f [true %.4f], sd=%.4f [true %.4f], KS p=%.3f)", m, mu, s, sdev, ks))
    invisible(x)
  }
  cat("=== Adaptive rejection sampler tests ===\n\n-- Distribution tests (n =", n, ") --\n")
  xn <- dist_test("NORMAL", dnorm, pnorm, 0, 1)
  xe <- dist_test("EXPONENTIAL", dexp, pexp, 1, 1, lower = 0)
  dist_test("NORMAL_SHIFTED_SCALED", function(x) dnorm(x, 3, 2), function(q) pnorm(q, 3, 2), 3, 2)
  dist_test("GAMMA_SHAPE3", function(x) dgamma(x, 3), function(q) pgamma(q, 3), 3, sqrt(3), lower = 0)
  dist_test("BETA_2_3", function(x) dbeta(x, 2, 3), function(q) pbeta(q, 2, 3), 0.4, sqrt(0.04), lower = 0, upper = 1)
  dist_test("UNNORMALISED_NORMAL", function(x) exp(-x^2 / 2), pnorm, 0, 1)
  dist_test("LOG_SCALE_INPUT", function(x) -x^2 / 2, pnorm, 0, 1, is_log = TRUE)
  dist_test("LOGISTIC", dlogis, plogis, 0, pi / sqrt(3))
  # truncated normal on [0, Inf): true moments
  a <- dnorm(0) / (1 - pnorm(0)); tm <- a; tsd <- sqrt(1 + 0 - a^2)
  dist_test("TRUNCATED_NORMAL", dnorm, function(q) (pnorm(q) - 0.5) / 0.5, tm, tsd, lower = 0)

  cat("\n-- Input validation tests --\n")
  err_test <- function(name, expr) {
    msg <- tryCatch({ force(expr); NULL }, error = function(e) conditionMessage(e))
    report(name, !is.null(msg), if (is.null(msg)) "(no error raised)" else paste0("(error: ", substr(msg, 1, 60), ")"))
  }
  err_test("REJECT_NEGATIVE_N", ars(dnorm, -5))
  err_test("REJECT_NONINTEGER_N", ars(dnorm, 2.5))
  err_test("REJECT_BAD_DOMAIN", ars(dnorm, 10, lower = 1, upper = -1))
  err_test("REJECT_NONFUNCTION", ars("dnorm", 10))
  err_test("REJECT_XINIT_OUTSIDE_DOMAIN", ars(dexp, 10, lower = 0, x_init = c(-1, 1)))
  err_test("REJECT_NONINTEGRABLE", ars(function(x) rep(1, length(x)), 10, lower = 0))
  report("ZERO_SAMPLES", length(ars(dnorm, 0)) == 0)

  cat("\n-- Log-concavity violation detection --\n")
  err_test("DETECT_BIMODAL_MIXTURE", ars(function(x) dnorm(x, -4) + dnorm(x, 4), 2000))
  err_test("DETECT_CAUCHY", ars(dcauchy, 2000))
  err_test("DETECT_LOGNORMAL", ars(dlnorm, 2000, lower = 0, x_init = c(0.5, 1, 20)))

  cat("\n-- Module (unit) tests --\n")
  # hull: upper hull dominates h, squeeze lies below h, for a concave h
  tg <- ars_make_target(dnorm, FALSE, NULL, -Inf, Inf)
  xs <- c(-2, 0.5, 1.5); hl <- ars_build_hull(xs, tg$h(xs), vapply(xs, tg$dh, 1), -Inf, Inf)
  g <- seq(-6, 6, length.out = 400); hg <- dnorm(g, log = TRUE)
  report("HULL_UPPER_DOMINATES", all(ars_upper(hl, g) >= hg - 1e-8))
  lo <- ars_lower(hl, g)
  report("HULL_SQUEEZE_BELOW", all(lo <= hg + 1e-8))
  # numerical derivative accuracy
  report("NUMERIC_DERIVATIVE", abs(tg$dh(1.3) - (-1.3)) < 1e-6)
  # envelope sampler: draws follow the normalised exp(upper hull); compare mass to numerical integral
  tot <- integrate(function(x) exp(ars_upper(hl, x)), -Inf, Inf)$value
  lm <- hl$logmass; report("HULL_MASS_MATCHES_INTEGRAL", abs(log(sum(exp(lm))) - log(tot)) < 1e-5)
  draws <- replicate(4000, ars_sample_envelope(hl))
  cdf_env <- Vectorize(function(q) integrate(function(x) exp(ars_upper(hl, x)), -Inf, q)$value / tot)
  report("ENVELOPE_SAMPLER_KS", suppressWarnings(ks.test(draws, cdf_env)$p.value) > 0.001)
  # concavity checker
  bad <- hl; bad$s <- c(0, 1, 2)
  report("CONCAVITY_CHECK_FLAGS_BAD_SLOPES", inherits(try(ars_check_concave(bad), silent = TRUE), "try-error"))

  # write sample files
  if (!is.null(xn)) write(xn, file.path(out_dir, "normal_samples.txt"), ncolumns = 1)
  if (!is.null(xe)) write(xe, file.path(out_dir, "exponential_samples.txt"), ncolumns = 1)
  cat(sprintf("\n=== %d / %d tests passed ===\n", npass, ntot))
  invisible(npass == ntot)
}

if (sys.nframe() == 0 && !interactive()) test()
