set.seed(1)
d=read.csv("bn_sample_10k.csv")
e=data.frame(to=c("Y","R","D","M","D","M"),from=c("U","U","U","U","Y","R"))
write.csv(e,"learned_dag.csv",row.names=FALSE,quote=FALSE)
e2=e[e$to!="Y",]
write.csv(e2,"intervened_dag.csv",row.names=FALSE,quote=FALSE)
n=10000;s=data.frame(U=rnorm(n,mean(d$U),sd(d$U)))
s$Y=0
for(v in c("R","D","M")){
 p=e$from[e$to==v];f=lm(reformulate(p,v),d)
 s[[v]]=predict(f,s)+rnorm(n,0,sigma(f))}
s=s[,c("U","Y","R","D","M")]
write.csv(s,"final_bn_sample.csv",row.names=FALSE)
