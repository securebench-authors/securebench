import asyncio
from typing import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run task callables with at most `max_concurrent` running at once.

    If a task raises, or this coroutine is cancelled (e.g. by Ctrl-C under
    asyncio.run), all running tasks are cancelled and awaited so their cleanup
    code finishes before the exception propagates.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    pending = iter(tasks)

    async def worker() -> None:
        for task in pending:  # shared iterator: each task is taken exactly once
            await task()

    workers = [
        asyncio.ensure_future(worker()) for _ in range(min(max_concurrent, len(tasks)))
    ]
    try:
        await asyncio.gather(*workers)
    finally:
        for w in workers:
            if not w.done():
                w.cancel()
        # Wait for cancelled tasks to finish their cleanup. If we're cancelled
        # again while waiting, keep waiting so cleanup is not abandoned.
        while workers:
            try:
                await asyncio.gather(*workers, return_exceptions=True)
                break
            except asyncio.CancelledError:
                continue
