import asyncio
from typing import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run tasks with at most `max_concurrent` running at once.

    If this coroutine is cancelled (e.g. by KeyboardInterrupt, which
    asyncio.run turns into a cancellation) or a task raises, all running
    tasks are cancelled and awaited so their cleanup code finishes.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    pending = iter(tasks)

    async def worker() -> None:
        for task in pending:
            await task()

    workers = [
        asyncio.ensure_future(worker()) for _ in range(min(max_concurrent, len(tasks)))
    ]
    try:
        await asyncio.gather(*workers)
    finally:
        for w in workers:
            w.cancel()
        # Wait for cancelled tasks to finish their cleanup.
        await asyncio.gather(*workers, return_exceptions=True)
