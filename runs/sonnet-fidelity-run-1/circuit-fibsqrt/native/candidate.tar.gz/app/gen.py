L=[]
def new(expr):
    L.append(expr); return len(L)-1
for i in range(32): new(f"out{i}")  # self copy
def G(e): return new(e)
Z=G("0"); O=G("1")
# fix: lines formatted below
def NOT(a): return G(f"~out{a}")
def AND(a,b): return G(f"out{a} & out{b}")
def OR(a,b): return G(f"out{a} | out{b}")
def XOR(a,b): return G(f"out{a} ^ out{b}")
def MUX(s,a,b): # s?a:b
    ns=NOT(s); return OR(AND(s,a),AND(ns,b))
def ADD(A,B):
    c=Z;r=[]
    for a,b in zip(A,B):
        x=XOR(a,b); r.append(XOR(x,c)); c=OR(AND(a,b),AND(x,c))
    return r
# registers reserved
def reg(n): 
    r=[]
    for _ in range(n): r.append(new("PLACE"))
    return r
A=reg(32);B=reg(32);K=reg(17);S=reg(1)[0]
x=list(range(32))
# isqrt
num=x[:]; res=[Z]*32
for it in range(16):
    p=30-2*it
    t=[res[i] if i!=p else O for i in range(32)]
    # num - t
    br=Z;d=[]
    for a,b in zip(num,t):
        xr=XOR(a,b); d.append(XOR(xr,br))
        br=OR(AND(NOT(a),b),AND(NOT(xr),br))
    num=[MUX(br,a,dd) for a,dd in zip(num,d)]
    sh=res[1:]+[Z]
    res=[sh[i] if i!=p else MUX(br,sh[i],O) for i in range(32)]
n=res[:17]
# fib stages
nz4=K[2]
for k in K[3:]: nz4=OR(nz4,k)
anyk=OR(OR(K[0],K[1]),nz4)
e=[anyk,OR(K[1],nz4),OR(AND(K[0],K[1]),nz4),nz4]
a,b=A[:],B[:]
for j in range(4):
    s=ADD(a,b)
    a2=[MUX(e[j],bb,aa) for aa,bb in zip(a,b)]
    b2=[MUX(e[j],ss,bb) for ss,bb in zip(s,b)]
    a,b=a2,b2
# k'
k4=K[2:]  # 15 bits
dec=[];br=O
for v in k4:
    dec.append(XOR(v,br)); br=AND(NOT(v),br)
kn=[AND(nz4,K[0]),AND(nz4,K[1])]+[AND(nz4,v) for v in dec]
nxA=[AND(S,v) for v in a]
nxB=[MUX(S,b[i],O if i==0 else Z) for i in range(32)]
nxK=[MUX(S,kn[i],n[i]) for i in range(17)]
for i in range(32): L[A[i]]=f"out{nxA[i]}"; L[B[i]]=f"out{nxB[i]}"
for i in range(17): L[K[i]]=f"out{nxK[i]}"
L[S]=f"out{G(chr(111)+chr(117)+chr(116)+str(O))}"
for i in range(32): G(f"out{A[i]}")
assert len(L)<32000
open("gates.txt","w").write("".join(f"out{i} = {e}\n" for i,e in enumerate(L)))
print(len(L))
