G={}
n=[32]
for i in range(32): G[i]=f"out{i}"
def new(s=None):
    i=n[0]; n[0]+=1
    if s is not None: G[i]=s
    return i
def op(o,a,b): return new(f"out{a} {o} out{b}")
NOT=lambda a:new(f"~out{a}")
F=new(); A=[new() for _ in range(32)]; B=[new() for _ in range(32)]; C=[new() for _ in range(16)]
Z=new("0"); O=new("1")
def mux(s,x,y): return op('^',y,op('&',s,op('^',x,y)))
def add(x,y,c=None):
    c=Z if c is None else c; r=[]
    for p,q in zip(x,y):
        t=op('^',p,q); r.append(op('^',t,c)); c=op('|',op('&',p,q),op('&',c,t))
    return r,c
W=20
rem=[Z]*W; root=[]
for k in range(15,-1,-1):
    rem=[2*k,2*k+1]+rem[:W-2]
    trial=([O,Z]+root+[Z]*W)[:W]
    nt=[NOT(t) for t in trial]
    diff,ge=add(rem,nt,O)
    rem=[mux(ge,d,r) for d,r in zip(diff,rem)]
    root=[ge]+root
R=root
def orr(l):
    x=l[0]
    for y in l[1:]: x=op('|',x,y)
    return x
hi=orr(C[2:])
# decrement upper 14 bits
bor=O; dec=[]
for b in C[2:]:
    dec.append(op('^',b,bor)); bor=op('&',NOT(b),bor)
dc_run=[op('&',hi,x) for x in C[:2]+dec]  # hi? c-4 : 0
for i in range(16):
    G[C[i]]=f"out{mux(F,dc_run[i],R[i])}"  # temporary; replaced below
# Dc computed from F; register C copies D
Dc=[int(G[C[i]].split('out')[1]) for i in range(16)]
en=[orr([C[0],C[1],hi]), op('|',C[1],hi), op('|',op('&',C[0],C[1]),hi), hi]
a,b=A,B
for e in en:
    s,_=add(a,b)
    a,b=[mux(e,y,x) for x,y in zip(a,b)],[mux(e,s_,y) for s_,y in zip(s,b)]
# a'=e?b:a ; b'=e?a+b:b
nf=new("1")
G[F]=f"out{nf}"
Z0=Z
for i in range(32):
    G[A[i]]=f"out{mux(F,a[i],Z)}"
    G[B[i]]=f"out{mux(F,b[i],O if i==0 else Z)}"
for i in range(32): new(f"out{A[i]}")
with open("gates.txt","w") as f:
    for i in range(n[0]): f.write(f"out{i} = {G[i]}\n")
print(n[0])
