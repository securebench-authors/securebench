import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

def num(b):
    v = 0
    for c in b:
        v = v * 10 + (c & 15 if c != 32 else 0)
    return v

def recs(path, n):
    d = open(path, 'rb').read()
    return [bytearray(d[i:i+n].ljust(n, b' ')) for i in range(0, len(d), n)]

def save(path, rs):
    open(path, 'wb').write(b''.join(rs))

raw = open('src/INPUT.DAT', 'rb').read()
if not raw:
    print("Error: Input file is empty")
    raise SystemExit
raw = raw[:22].ljust(22, b' ')
buyer, seller, book = raw[0:4], raw[4:8], raw[8:12]
amount = num(raw[12:22])  # whole units

accs = recs('data/ACCOUNTS.DAT', 34)
books = recs('data/BOOKS.DAT', 28)
bf = sf = kf = vo = False
for a in accs:
    if bytes(a[:4]) == buyer: bf = True
    if bytes(a[:4]) == seller: sf = True
for b in books:
    if bytes(b[:4]) == book:
        kf = True
        if bytes(b[24:28]) == seller: vo = True
print(" ")
if bf and sf and kf and vo:
    for a in accs:
        bal = num(a[24:34])
        if bytes(a[:4]) == buyer:
            bal = abs(bal - amount) % 10**10
            a[24:34] = b'%010d' % bal
            if buyer == seller:  # COBOL aborts on second REWRITE (status 43)
                save('data/ACCOUNTS.DAT', accs)
                raise SystemExit
        if bytes(a[:4]) == seller:
            bal = (num(a[24:34]) + amount) % 10**10
            a[24:34] = b'%010d' % bal
    save('data/ACCOUNTS.DAT', accs)
    for b in books:
        if bytes(b[:4]) == book:
            b[24:28] = buyer
    save('data/BOOKS.DAT', books)
    with open('data/TRANSACTIONS.DAT', 'ab') as f:
        f.write(book + b'%010d' % amount + seller + buyer)
    print("Transaction completed successfully")
else:
    print("Transaction failed due to validation errors")
