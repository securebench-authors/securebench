import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
raw = open("src/INPUT.DAT", "rb").read()[:22]
if not raw:
    print("Error: Input file is empty")
    raise SystemExit
raw = raw.ljust(22, b" ")
buyer, seller, book = (raw[i:i+4].decode("latin-1") for i in (0, 4, 8))
amount = int("".join(str(c & 15) if c != 32 else "0" for c in raw[12:22]))

def rd(path, n):
    d = open(path, "rb").read().decode("latin-1")
    return [d[i:i+n] for i in range(0, len(d) - n + 1, n)]

accts = rd("data/ACCOUNTS.DAT", 34)
books = rd("data/BOOKS.DAT", 28)
bf = any(a[:4] == buyer for a in accts)
sf = any(a[:4] == seller for a in accts)
kf = any(b[:4] == book for b in books)
vo = any(b[:4] == book and b[24:28] == seller for b in books)
print(" ")
if bf and sf and kf and vo:
    out = []
    for a in accts:
        bal = int(a[24:34])
        if a[:4] == buyer:
            bal = abs(bal - amount) % 10**10
        if a[:4] == seller:
            bal = (bal + amount) % 10**10
        out.append(a[:24] + "%010d" % bal)
    open("data/ACCOUNTS.DAT", "wb").write("".join(out).encode("latin-1"))
    out = [b[:24] + buyer if b[:4] == book else b for b in books]
    open("data/BOOKS.DAT", "wb").write("".join(out).encode("latin-1"))
    with open("data/TRANSACTIONS.DAT", "ab") as f:
        f.write((book + "%010d" % amount + seller + buyer).encode("latin-1"))
    print("Transaction completed successfully")
else:
    print("Transaction failed due to validation errors")
