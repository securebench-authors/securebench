import numpy as np
from scipy.optimize import fsolve
N=150000
def mk(k,p1):
    q=(1-k*p1)/(N-k); return q
def kls(k,p1):
    q=mk(k,p1)
    fw=k*p1*np.log(p1*N)+(N-k)*q*np.log(q*N)
    bw=-(k*np.log(p1*N)+(N-k)*np.log(q*N))/N
    return fw,bw
for k in range(1,12):
    # bw=10 determines p1 given k? scan p1 for bw, check fw
    from scipy.optimize import brentq
    try:
        p=brentq(lambda p:kls(k,p)[1]-10,1e-9,(1-1e-9)/k)
    except Exception as e: print(k,'no');continue
    print(k,p,kls(k,p))
from scipy.optimize import fsolve
def build(v):
    lr,lq=v; r,q=np.exp(lr),np.exp(lq)
    p=(1-r-(N-7)*q)/6
    return p,r,q
def eqs(v):
    p,r,q=build(v)
    if p<=0:return [1e3,1e3]
    c=np.array([6,1,N-7.]);x=np.array([p,r,q])
    return [np.sum(c*x*np.log(x*N))-10, -np.sum(c*np.log(x*N))/N-10]
for g in [(np.log(.1),np.log(3e-10)),(np.log(.05),np.log(3e-10)),(np.log(.14),np.log(3e-10))]:
    v,info,ier,m=fsolve(eqs,g,full_output=True,xtol=1e-14)
    print(ier,eqs(v),build(v))
    if ier==1:break
p,r,q=build(v)
d=np.r_[np.full(6,p),r,np.full(N-7,q)]
print(d.sum(),np.sum(d*np.log(d*N)),-np.mean(np.log(d*N)),d.min())
np.save('/app/dist.npy',d)
