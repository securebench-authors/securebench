import numpy as np
from scipy.optimize import fsolve
n=150000
def kls(p):
    return np.sum(p*np.log(p*n)), np.mean(-np.log(p*n))
def build(k,a,lowfrac):
    # k high tokens share mass a; rest: lowfrac of them are "tiny", others share remainder
    pass
# three-level: 1 big token a, m medium tokens each b, rest c
def make(x,m):
    a,lb=x; b=np.exp(lb)
    c=(1-a-m*b)/(n-1-m)
    return a,b,c
def f(x,m):
    a,b,c=make(x,m)
    if c<=0 or not(0<a<1): return [1e3,1e3]
    p=np.concatenate([[a],np.full(m,b),np.full(n-1-m,c)])
    F,B=kls(p); return [F-10,B-10]
for m in [100,1000,10000,50000]:
  for a0 in [0.3,0.5,0.7,0.9]:
    for lb0 in [-20,-18,-16,-14]:
        s,info,ier,_=fsolve(f,[a0,lb0],args=(m,),full_output=True)
        if ier==1:
            a,b,c=make(s,m)
            if c>0:
                p=np.concatenate([[a],np.full(m,b),np.full(n-1-m,c)])
                F,B=kls(p)
                if abs(F-10)<5e-4 and abs(B-10)<5e-4 and abs(p.sum()-1)<1e-9:
                    np.save('/app/dist.npy',p);print(m,F,B,p.sum(),p.min());raise SystemExit
