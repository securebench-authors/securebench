use strict; my %s; my $n;
open F,"sequences.fasta"; while(<F>){chomp; if(/^>(\S+)/){$n=$1}else{$s{$n}.=$_}}
for (keys %s){my $x=$s{$_}; my $c=()=$x=~/ggtctc|gagacc/g; print "$_ ",length($x)," bsa=$c\n"}
my %nn=(AA=>[-7.9,-22.2],TT=>[-7.9,-22.2],AT=>[-7.2,-20.4],TA=>[-7.2,-21.3],CA=>[-8.5,-22.7],TG=>[-8.5,-22.7],GT=>[-8.4,-22.4],AC=>[-8.4,-22.4],CT=>[-7.8,-21.0],AG=>[-7.8,-21.0],GA=>[-8.2,-22.2],TC=>[-8.2,-22.2],CG=>[-10.6,-27.2],GC=>[-9.8,-24.4],GG=>[-8.0,-19.9],CC=>[-8.0,-19.9]);
sub tm{my $q=uc shift;my($h,$e)=(0,0);
 for my $b(substr($q,0,1),substr($q,-1)){ if($b=~/[GC]/){$h+=0.1;$e+=-2.8}else{$h+=2.3;$e+=4.1}}
 for my $i(0..length($q)-2){my $p=$nn{substr($q,$i,2)};$h+=$p->[0];$e+=$p->[1]}
 my $salt=0.05+120*sqrt(2-0.8)/1000; $e+=0.368*(length($q)-1)*log($salt);
 return $h*1000/($e+1.987*log(500e-9/4))-273.15}
sub rc{my $x=reverse shift;$x=~tr/acgt/tgca/;$x}
my %cfg=(input=>[ 'tgaggatcc' ,'tcat'],);
# define regions: [template, fwd start, rev end(exclusive), fwdtail, revtail]
my $in=$s{input}; my $a=index($in,"tgaggatcccggg"); my $b=index($in,"gatatacatatg")+9;
print STDERR "$a $b\n"; my @r=(['input',$a,$b,'','tcat',1],['egfp',0,length($s{egfp})-3,'','',0],['flag',3,length($s{flag})-3,'caaa','',0],['snap',3,length($s{snap}),'ttca','ctca',0]);
# input is circular: start at a, end at b wrapping
$s{input}=$in.$in; $r[0][2]=$b+length($in);
my $pad="ttattt"; my $bsa="ggtctc";
open O,">primers.fasta";
for my $r(@r){my($t,$st,$en,$ft,$rt)=@$r; my $x=$s{$t};
 my @f=map{[$_,tm(substr($x,$st,$_))]}15..40; my @v=map{[$_,tm(rc(substr($x,$en-$_,$_)))]}15..40;
 my($bf,$bv,$bd);
 for my $f(@f){for my $v(@v){next if $f->[1]<60||$v->[1]<60||$f->[1]>66||$v->[1]>66; my $d=abs($f->[1]-$v->[1]); if(!defined $bd||$d<$bd){$bd=$d;($bf,$bv)=($f,$v)}}}
 my $fa=substr($x,$st,$bf->[0]); my $ra=rc(substr($x,$en-$bv->[0],$bv->[0]));
 my $fp=$pad.$bsa."a".$ft.$fa; my $rp=$pad.$bsa."a".$rt.$ra;
 printf STDERR "$t %d %.2f %d %.2f\n",$bf->[0],$bf->[1],$bv->[0],$bv->[1];
 print O ">${t}_fwd\n$fp\n>${t}_rev\n$rp\n";}
