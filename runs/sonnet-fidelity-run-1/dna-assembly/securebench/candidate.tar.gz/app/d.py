import subprocess,re
S={};n=None
for l in open('sequences.fasta'):
    l=l.strip()
    if l.startswith('>'):n=l[1:];S[n]=''
    elif l:S[n]+=l.lower()
def rc(s):return s[::-1].translate(str.maketrans('acgt','tgca'))
def tm(s):return float(subprocess.check_output(['oligotm','-tp','1','-sc','1','-mv','50','-dv','2','-n','0.8','-d','500',s]).decode())
for k,v in S.items():print(k,[m.start() for m in re.finditer('ggtctc|gagacc',v)])
P='ttcgatt'[:6]+'ggtctc'+'a'
inp=S['input']
i=inp.find('atgaggatcccggg')
j=inp.find('catatgatc')+7  # end incl atga
def anneal(seq,rev,lo=18):
    for L in range(15,46):
        s=seq[:L]
        yield L,s
def pick(seq,target):
    best=None
    for L in range(15,46):
        t=tm(seq[:L])
        if best is None or abs(t-target)<abs(best[1]-target):best=(seq[:L],t)
    return best
# fragment ends: (fwd anneal seq, rev anneal seq(rc'd))
fr={
 'input':(inp[i:],rc(inp[:j])),
 'egfp':(S['egfp'],rc(S['egfp'][:-3])),
 'flag':(S['flag'][3:],rc(S['flag'][:-3])),
 'snap':(S['snap'][3:],rc(S['snap'][:-1])),
}
# egfp fwd anneals atga..., flag fwd ggta..., snap fwd gaca..., input fwd atgagg (tail adds gtta)
tails={'input':('gtta',''),'egfp':('',''),'flag':('',''),'snap':('','')}
out=[]
for k,(f,r) in fr.items():
    for tgt in range(60,72):
        a=pick(f,tgt);b=pick(r,tgt)
        if abs(a[1]-b[1])<=1:break
    print(k,a,b)
    out.append((k,'fwd',P+tails[k][0]+a[0]))
    rt={'input':'','egfp':rc('ggta'),'flag':rc('gaca'),'snap':''}[k]
    out.append((k,'rev',P+rt+b[0]))
open('primers.fasta','w').write(''.join(f'>{k}_{d}\n{s}\n' for k,d,s in out))
