open F,"sequences.fasta";local $/;$t=<F>;@p=split />/,$t;
for(@p){next unless /\S/;($n,@l)=split /\n/;$s{$n}=join '',@l}
($a,$b)=@s{input,output};
$i=0;$i++ while substr($a,$i,1) eq substr($b,$i,1);
$j=0;$j++ while substr($a,-1-$j,1) eq substr($b,-1-$j,1);
print "$i $j ",length $a," ",length $b,"\n",substr($a,$i,length($a)-$j-$i),"\n",substr($b,$i,length($b)-$j-$i),"\n";
%H=(AA=>-7.9,TT=>-7.9,AT=>-7.2,TA=>-7.2,CA=>-8.5,TG=>-8.5,GT=>-8.4,AC=>-8.4,CT=>-7.8,AG=>-7.8,GA=>-8.2,TC=>-8.2,CG=>-10.6,GC=>-9.8,GG=>-8.0,CC=>-8.0);
%S=(AA=>-22.2,TT=>-22.2,AT=>-20.4,TA=>-21.3,CA=>-22.7,TG=>-22.7,GT=>-22.4,AC=>-22.4,CT=>-21.0,AG=>-21.0,GA=>-22.2,TC=>-22.2,CG=>-27.2,GC=>-24.4,GG=>-19.9,CC=>-19.9);
sub tm{my$q=uc shift;my($h,$s)=(0,0);
for(substr($q,0,1),substr($q,-1)){if(/[GC]/){$h+=0.1;$s+=-2.8}else{$h+=2.3;$s+=4.1}}
for $k(0..length($q)-2){$d=substr($q,$k,2);$h+=$H{$d};$s+=$S{$d}}
$na=0.05+0.120*sqrt(0.0012);$s+=0.368*(length($q)-1)*log($na);
return $h*1000/($s+1.987*log(500e-9/4))-273.15}
sub rc{my$x=reverse shift;$x=~tr/acgt/tgca/;$x}
$X=substr($b,$i,38);$p=$i;
for $n(18..30){$f=substr($a,$p,$n);$ft{$n}=tm($f)}
for $m(18..30){$r=rc(substr($a,$p-$m,$m));$rt{$m}=tm($r)}
printf "F%d %.1f R%d %.1f\n",$_,$ft{$_},$_,$rt{$_} for 18..30;
print substr($a,$p-45,45),"\n";
printf "R%d %.1f\n",$_,tm(rc(substr($a,$p-$_,$_))) for 30..45;
print "----\n";
for $p(200..235){$X=substr($b,$p,39);next unless substr($a,0,$p).$X.substr($a,$p) eq $b;
 for $m(15..45){$r=tm(rc(substr($a,$p-$m,$m)));$bm=$m if $r>=58 && !$bm;} 
 printf "p=%d X=%s minR=%s\n",$p,$X,$bm; $bm=0}
print "====\n";
$p=215;$X=substr($b,$p,39);
for $k(0..40){for $m(15..45){$e=$p-$k;$r=tm(rc(substr($a,$e-$m,$m)));
 for $n(15..45){$f=tm(substr($a,$p,$n)); if($r>=58&&$r<=72&&$f>=58&&$f<=72&&abs($r-$f)<=5){printf "k=%d m=%d r=%.1f n=%d f=%.1f\n",$k,$m,$r,$n,$f;next}}}} 
$k=18;$m=45;$n=22;$e=$p-$k;
$F=substr($a,$e,$k).$X.substr($a,$p,$n);$R=rc(substr($a,$e-$m,$m));
open O,">primers.fasta";print O ">fwd\n$F\n>rev\n$R\n";close O;
# verify
$prod=substr($a,$e,$k).$X.substr($a,$p).substr($a,0,$e);
print "OK\n" if $prod eq substr($b,$e).substr($b,0,$e) || index($b.$b,$prod)>=0;
printf "%.1f %.1f\n",tm(substr($a,$p,$n)),tm($R);
