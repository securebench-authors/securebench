import subprocess
L=open('sequences.fasta').read().split('>')[1:]
s={x.split('\n')[0]:''.join(x.split('\n')[1:]) for x in L}
a,b=s['input'],s['output']
i=0
while a[i]==b[i]:i+=1
j=0
while a[-1-j]==b[-1-j]:j+=1
print(i,j,len(a),len(b),a[i:len(a)-j],b[i:len(b)-j])
