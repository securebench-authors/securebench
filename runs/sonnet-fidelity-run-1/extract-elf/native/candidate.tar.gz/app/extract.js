const fs=require('fs');
const b=fs.readFileSync(process.argv[2]);
const phoff=Number(b.readBigUInt64LE(32)),phsz=b.readUInt16LE(54),phn=b.readUInt16LE(56);
const out={};
for(let i=0;i<phn;i++){
  const o=phoff+i*phsz;
  if(b.readUInt32LE(o)!==1)continue;
  const off=Number(b.readBigUInt64LE(o+8)),va=Number(b.readBigUInt64LE(o+16)),fs_=Number(b.readBigUInt64LE(o+32));
  for(let j=0;j+4<=fs_;j+=4)out[va+j]=b.readUInt32LE(off+j);
}
console.log(JSON.stringify(out));
