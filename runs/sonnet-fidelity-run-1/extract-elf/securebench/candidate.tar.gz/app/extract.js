const fs = require('fs');
const b = fs.readFileSync(process.argv[2]);
const phoff = Number(b.readBigUInt64LE(32)), phentsize = b.readUInt16LE(54), phnum = b.readUInt16LE(56);
const out = {};
for (let i = 0; i < phnum; i++) {
  const p = phoff + i * phentsize;
  if (b.readUInt32LE(p) !== 1) continue; // PT_LOAD
  const off = Number(b.readBigUInt64LE(p + 8)), va = Number(b.readBigUInt64LE(p + 16));
  const fsz = Number(b.readBigUInt64LE(p + 32));
  for (let o = 0; o + 4 <= fsz; o += 4) out[va + o] = b.readUInt32LE(off + o);
}
console.log(JSON.stringify(out));
