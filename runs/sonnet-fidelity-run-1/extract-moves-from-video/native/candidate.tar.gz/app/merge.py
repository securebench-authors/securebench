import sys,glob,difflib,re
d=sys.argv[1]
def norm(s): return re.sub(r'[^a-z]','',s.lower())
def eq(a,b): return difflib.SequenceMatcher(None,norm(a),norm(b)).ratio()>0.8 or norm(a)==norm(b)
G=[]
for fn in sorted(glob.glob(d+'/*.txt')):
    L=[l[1:].strip() for l in open(fn).read().split('\n') if l.startswith('>')]
    # drop last (possibly partial) line
    L=L[:-1]
    L=[l for l in L if l]
    if not L: continue
    best=0
    for k in range(min(len(G),len(L)),0,-1):
        if all(eq(G[len(G)-k+i],L[i]) for i in range(k)): best=k;break
    if best==0 and G:
        # try partial: find L[0] match in last 8 of G
        for j in range(max(0,len(G)-8),len(G)):
            if eq(G[j],L[0]):
                m=len(G)-j
                if all(eq(G[j+i],L[i]) for i in range(min(m,len(L)))): best=m;break
    if best==0 and G: G.append('???')
    G.extend(L[best:])
print('\n'.join(G))
