import random
from collections import Counter
from feal import f_function


def attack(encrypt_fn, npairs=12, d=0x80800000):
    # Plaintext pairs with equal left/right difference d => R0 diff 0, R1 diff d,
    # so R2 diff takes few values (F-diff of a low-weight input diff).
    data = []
    for _ in range(npairs):
        L, R = random.getrandbits(32), random.getrandbits(32)
        c1 = encrypt_fn((L << 32) | R)
        c2 = encrypt_fn(((L ^ d) << 32) | (R ^ d))
        data.append((c1, c2))
    pre = []
    for c1, c2 in data:
        t = []
        for c in (c1, c2):
            hi, lo = c >> 32, c & 0xFFFFFFFF
            t.append((hi, hi ^ lo))  # R4, R3
        pre.append(t)
    best, bestscore = None, -1
    for x in range(65536):
        k = (x * 1234567) & 0xFFFFFFFF
        cnt = Counter()
        for (a4, a3), (b4, b3) in pre:
            dr2 = (a4 ^ f_function(a3 ^ k)) ^ (b4 ^ f_function(b3 ^ k))
            cnt[dr2] += 1
        s = cnt.most_common(1)[0][1]
        if s > bestscore:
            best, bestscore = k, s
            if s == npairs:
                break
        if False:
            best, bestscore = k, s
    return best
