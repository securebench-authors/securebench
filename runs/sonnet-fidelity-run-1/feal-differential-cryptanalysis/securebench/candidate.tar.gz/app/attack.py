import random
from feal import f_function

D = 0x80800000


def attack(encrypt_fn):
    pairs = []
    for _ in range(6):
        l, r = random.getrandbits(32), random.getrandbits(32)
        c1 = encrypt_fn((l << 32) | r)
        c2 = encrypt_fn(((l ^ D) << 32) | (r ^ D))
        pairs.append([(c >> 32 & 0xFFFFFFFF, (c & 0xFFFFFFFF) ^ (c >> 32 & 0xFFFFFFFF)) for c in (c1, c2)])
    found = []
    for s in range(65536):
        k = (s * 1234567) & 0xFFFFFFFF
        ok = True
        for (a, b) in pairs:
            # a = (R4, R3)
            x = a[0] ^ f_function(a[1] ^ k)
            y = b[0] ^ f_function(b[1] ^ k)
            if x ^ y != 0x02000000:
                ok = False
                break
        if ok:
            found.append(k)
    return found[0]
