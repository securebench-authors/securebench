#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define main feal_main
#include "feal.c"
#undef main
static inline uint8_t g(uint8_t a,uint8_t b,uint8_t x){uint8_t t=a+b+x;return (t<<2)|(t>>6);}
static inline uint8_t ri(uint8_t y){return (y>>2)|(y<<6);}
static inline uint32_t F(uint32_t v){
 uint8_t x0=v,x1=v>>8,x2=v>>16,x3=v>>24;
 uint8_t y2=g(x3^x2,x1^x0,1),y3=g(x3,y2,0),y1=g(x1^x0,y2,0),y0=g(x0,y1,1);
 return y0|(y1<<8)|(y2<<16)|((uint32_t)y3<<24);}
static inline uint32_t Fi(uint32_t y){
 uint8_t y0=y,y1=y>>8,y2=y>>16,y3=y>>24;
 uint8_t x3=ri(y3)-y2, a=ri(y1)-y2, x0=ri(y0)-y1-1, x1=a^x0, x2=(uint8_t)(ri(y2)-1-a)^x3;
 return x0|(x1<<8)|(x2<<16)|((uint32_t)x3<<24);}
uint64_t P[32],C[32]; uint32_t Sm1[32],S0[32],S3[32],S4[32];
uint32_t *ex; uint8_t *bm; uint8_t lo[8192];
static inline int inK(uint32_t k){ return bm[k>>3]>>(k&7)&1; }
int main(){
 FILE*f=fopen("pairs.txt","r");
 for(int i=0;i<32;i++) fscanf(f,"%lu %lu",&P[i],&C[i]);
 for(int i=0;i<32;i++){Sm1[i]=P[i]>>32;S0[i]=(uint32_t)P[i]^Sm1[i];S4[i]=C[i]>>32;S3[i]=(uint32_t)C[i]^S4[i];}
 ex=malloc(4<<20); bm=calloc(1<<29,1);
 for(uint32_t s=0;s<(1<<20);s++){uint32_t k=expand(s);ex[s]=k;bm[k>>3]|=1<<(k&7);lo[(k&0xFFFF)>>3]|=1<<(k&7);}
 #pragma omp parallel for schedule(dynamic,16)
 for(uint32_t s0=0;s0<(1<<20);s0++){
  uint32_t S1=Sm1[0]^F(S0[0]^ex[s0]);
  for(uint32_t s3=0;s3<(1<<20);s3++){
   uint32_t S2=S4[0]^F(S3[0]^ex[s3]);
   uint32_t k2=S2^Fi(S1^S3[0]);
   if(!(lo[(k2&0xFFFF)>>3]>>(k2&7)&1)) continue;
   uint32_t k1=S1^Fi(S2^S0[0]);
   if(!(lo[(k1&0xFFFF)>>3]>>(k1&7)&1)) continue;
   if(!inK(k1)||!inK(k2)) continue;
   _Pragma("omp critical") for(uint32_t a=0;a<(1<<20);a++) if(ex[a]==k1) for(uint32_t b=0;b<(1<<20);b++) if(ex[b]==k2){
     key[0]=ex[s0];key[1]=ex[a];key[2]=ex[b];key[3]=ex[s3];
     int ok=1;for(int i=0;i<32;i++) if(encrypt(P[i])!=C[i]){ok=0;break;}
     if(ok){printf("KEYS %x %x %x %x\n",s0,a,b,s3);fflush(stdout);}
   }
  }
 }
}
