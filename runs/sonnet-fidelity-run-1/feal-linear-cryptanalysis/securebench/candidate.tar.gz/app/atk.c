#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t u32; typedef uint64_t u64;
static u32 K[1<<20];
static inline uint8_t g(uint8_t a,uint8_t b,uint8_t x){uint8_t t=a+b+x;return (t<<2)|(t>>6);}
static u32 F(u32 v){uint8_t x0=v,x1=v>>8,x2=v>>16,x3=v>>24;
 uint8_t y2=g(x3^x2,x1^x0,1),y3=g(x3,y2,0),y1=g(x1^x0,y2,0),y0=g(x0,y1,1);
 return y0|(y1<<8)|(y2<<16)|((u32)y3<<24);}
#define N 32
u32 L0[N],R0[N],R3[N],R4[N];
static int par(u32 x){return __builtin_parity(x&0x01010101u);}
#define HS (1<<22)
static u32 hv[HS]; static int hs[HS];
int main(){
 for(u32 s=0;s<(1<<20);s++)K[s]=s^(s<<16)^(s*12345);
 FILE*f=fopen("pairs.txt","r");u64 p,c;
 for(int i=0;i<N;i++){fscanf(f,"%lu %lu",&p,&c);L0[i]=p>>32;R0[i]=(u32)p^L0[i];R4[i]=c>>32;R3[i]=(u32)c^R4[i];}
 memset(hs,-1,sizeof hs);
 for(u32 s3=0;s3<(1<<20);s3++){u32 v=F(R3[0]^K[s3])^R0[0]^R4[0];u32 h=(v*2654435761u)>>10;
  while(hs[h]>=0)h=(h+1)&(HS-1);hs[h]=s3;hv[h]=v;}
 for(u32 s0=0;s0<(1<<20);s0++){
  u32 R1[N];int ok=1,t0=0;
  for(int i=0;i<N&&ok;i++){R1[i]=L0[i]^F(R0[i]^K[s0]);
   {int t=par(R1[i])^par(R3[i])^((R0[i]^R4[i])>>18&1);if(i==0)t0=t;else if(t!=t0)ok=0;}}
  if(!ok)continue;
  for(u32 s1=0;s1<(1<<20);s1++){u32 v=F(R1[0]^K[s1]);u32 h=(v*2654435761u)>>10;
   while(hs[h]>=0){ if(hv[h]==v){u32 s3=hs[h];
     u32 R2[N];int ok2=1;
     for(int i=0;i<N;i++){R2[i]=R0[i]^F(R1[i]^K[s1]);if(R2[i]!=(R4[i]^F(R3[i]^K[s3]))){ok2=0;break;}}
     if(ok2)for(u32 s2=0;s2<(1<<20);s2++){int ok3=1;
       for(int i=0;i<N;i++)if((R1[i]^F(R2[i]^K[s2]))!=R3[i]){ok3=0;break;}
       if(ok3){printf("%x %x %x %x\n",s0,s1,s2,s3);return 0;}}
    } h=(h+1)&(HS-1);}
  }
 }
 puts("none");return 1;}
