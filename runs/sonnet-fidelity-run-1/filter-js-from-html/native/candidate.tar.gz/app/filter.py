import html
import re
import sys

BAD_TAGS = ("script", "iframe", "object", "embed", "applet")

TAG_RE = re.compile(r'<[a-zA-Z][^\s/>]*(?:"[^"]*"|\'[^\']*\'|[^\'">])*>')
ATTR_RE = re.compile(
    r'(?P<ws>[\s/]*)(?P<name>[^\s=/>"\']+)'
    r'(?:\s*=\s*(?P<val>"[^"]*"|\'[^\']*\'|[^\s>]*))?'
)
BAD_VAL_RE = re.compile(
    r'^(?:javascript|vbscript|livescript|data\s*:\s*text/html)|expression\s*\(|javascript\s*:',
    re.I,
)


def bad_value(val):
    v = val.strip("\"'")
    for _ in range(3):
        v = html.unescape(v)
    v = re.sub(r'[\x00-\x20\x7f]+', '', v)
    v = re.sub(r'/\*.*?\*/', '', v)
    return bool(BAD_VAL_RE.search(v))


def clean_tag(m):
    tag = m.group(0)
    name = re.match(r'<[^\s/>]+', tag).group(0)
    body = tag[len(name):]

    def attr(a):
        n = a.group('name').lower()
        val = a.group('val')
        if n.startswith('on'):
            return ''
        if val is not None and bad_value(val):
            return ''
        if n in ('formaction', 'srcdoc') and val is not None:
            return ''
        return a.group(0)

    return name + ATTR_RE.sub(attr, body)


def clean(s):
    # remove dangerous elements with content
    for t in BAD_TAGS:
        s = re.sub(r'<%s\b[^>]*>.*?</%s\s*>' % (t, t), '', s, flags=re.S | re.I)
        # unclosed or stray tags
        s = re.sub(r'<%s\b(?:"[^"]*"|\'[^\']*\'|[^\'">])*>?' % t, '', s, flags=re.I)
        s = re.sub(r'</%s\s*>' % t, '', s, flags=re.I)
    s = TAG_RE.sub(clean_tag, s)
    # meta refresh / base
    s = re.sub(r'<meta\b[^>]*http-equiv\s*=\s*["\']?refresh[^>]*>', '', s, flags=re.I)
    return s


def main():
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8', errors='surrogateescape', newline='') as f:
        data = f.read()
    out = clean(data)
    with open(path, 'w', encoding='utf-8', errors='surrogateescape', newline='') as f:
        f.write(out)


if __name__ == '__main__':
    main()
