#!/usr/bin/env python3
"""Remove JavaScript from an HTML file in place, leaving everything else byte-for-byte intact."""
import html
import re
import sys

SCRIPT_BLOCK = re.compile(r'<script\b.*?</script[^>]*>', re.I | re.S)
SCRIPT_OPEN = re.compile(r'<script\b.*\Z', re.I | re.S)
DANGEROUS_BLOCK = re.compile(
    r'<(iframe|object|embed|applet)\b.*?</\1\s*>', re.I | re.S)
DANGEROUS_TAG = re.compile(r'</?(?:script|iframe|object|embed|applet)\b[^>]*>', re.I)
TAG = re.compile(r'<[a-zA-Z][^\s/>]*(?:"[^"]*"|\'[^\']*\'|[^\'">])*>')
ATTR = re.compile(
    r'''(\s*)([^\s=/>"']+)(?:(\s*=\s*)("[^"]*"|'[^']*'|[^\s>"']*))?''')
BAD_URL = re.compile(r'^(?:javascript|vbscript|livescript|data\s*:\s*text/html)', re.I)
URL_ATTRS = {'href', 'src', 'action', 'formaction', 'xlink:href', 'data',
             'background', 'poster', 'codebase', 'cite', 'longdesc', 'srcset',
             'lowsrc', 'dynsrc', 'ping', 'manifest'}


def bad_value(value):
    v = value
    if v[:1] in '"\'' and v[-1:] == v[:1]:
        v = v[1:-1]
    for _ in range(3):
        v = html.unescape(v)
    v = re.sub(r'[\x00-\x20\x7f-\x9f​-‏  ﻿]', '', v)
    return bool(BAD_URL.match(v)) or v.lower().startswith('data:text/html')


def clean_tag(m):
    tag = m.group(0)
    name_end = re.match(r'<[^\s/>]+', tag).end()
    head, rest = tag[:name_end], tag[name_end:]

    def attr(am):
        name = am.group(2).lower()
        val = am.group(4)
        if name.startswith('on') or name in ('srcdoc', 'formaction') and val and bad_value(val):
            return ''
        if name == 'srcdoc':
            return ''
        if val is not None:
            if name in URL_ATTRS and bad_value(val):
                return ''
            if name == 'style' and re.search(
                    r'expression\s*\(|javascript\s*:|behaviou?r\s*:|-moz-binding',
                    html.unescape(val), re.I):
                return ''
        return am.group(0)

    return head + ATTR.sub(attr, rest)


def sanitize(text):
    prev = None
    while prev != text:
        prev = text
        text = SCRIPT_BLOCK.sub('', text)
        text = DANGEROUS_BLOCK.sub('', text)
        text = DANGEROUS_TAG.sub('', text)
        text = SCRIPT_OPEN.sub('', text)
    return TAG.sub(clean_tag, text)


def main():
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8', errors='surrogateescape', newline='') as f:
        data = f.read()
    out = sanitize(data)
    with open(path, 'w', encoding='utf-8', errors='surrogateescape', newline='') as f:
        f.write(out)


if __name__ == '__main__':
    main()
