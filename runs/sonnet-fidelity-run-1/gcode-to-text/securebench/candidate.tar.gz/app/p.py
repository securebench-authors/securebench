import re,collections
obj=None;x=y=z=e=0;segs=collections.defaultdict(list)
rel=True
for l in open('text.gcode'):
    l=l.split(';')[0].strip()
    if l.startswith('M486 S'):
        obj=int(l[6:]);continue
    m=re.match(r'G[01] ',l)
    if not m: continue
    d=dict((t[0],float(t[1:])) for t in l.split()[1:] if len(t)>1)
    nx=d.get('X',x);ny=d.get('Y',y);nz=d.get('Z',z)
    if 'E' in d and d['E']>0 and (nx!=x or ny!=y):
        segs[(obj,round(nz,2))].append((x,y,nx,ny))
    x,y,z=nx,ny,nz
for o in (0,1):
    zs=sorted(k[1] for k in segs if k[0]==o)
    print(o,zs[0],zs[-1],len(zs))
import pickle;pickle.dump(dict(segs),open('s.pkl','wb'))
