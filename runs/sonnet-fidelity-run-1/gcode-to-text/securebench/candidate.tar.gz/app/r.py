import pickle
from PIL import Image,ImageDraw
s=pickle.load(open('s.pkl','rb'))
zs=sorted(k[1] for k in s if k[0]==0)
print(zs[:15],zs[-5:])
allp=[p for k,v in s.items() if k[0]==0 for p in v]
xs=[p[0] for p in allp];ys=[p[1] for p in allp]
print(min(xs),max(xs),min(ys),max(ys))
def top(name,sel,sc=8):
    x0,y0=min(xs),min(ys)
    im=Image.new('L',(int((max(xs)-x0)*sc)+20,int((max(ys)-y0)*sc)+20),255);d=ImageDraw.Draw(im)
    for k,v in s.items():
        if k[0]==0 and sel(k[1]):
            for a,b,c,e in v:d.line([(a-x0)*sc+10,im.height-((b-y0)*sc+10),(c-x0)*sc+10,im.height-((e-y0)*sc+10)],fill=0)
    im.save(name)
top('top.png',lambda z:True)
top('lo.png',lambda z:z<8)
top('hi.png',lambda z:z>=8)
