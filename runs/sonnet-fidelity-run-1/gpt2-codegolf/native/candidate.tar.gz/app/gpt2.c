#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define R(v,n) float*v=P;P+=n;
float*F,*K[12],*V[12];
char*tok[50257],*ln_[50001],*S[999],B[999],*d;
int bid[256],cp[256],T[1200];
void mm(float*x,float*w,float*b,float*y,int n,int m){
 int i,j;
 for(j=0;j<m;j++)y[j]=b[j];
 for(i=0;i<n;i++)for(j=0;j<m;j++)y[j]+=x[i]*w[i*m+j];
}
void ln(float*x,float*y,float*b,float*g){
 float m=0,v=0;int i;
 for(i=0;i<768;i++)m+=x[i];
 m/=768;
 for(i=0;i<768;i++)v+=(x[i]-m)*(x[i]-m);
 v=1/sqrtf(v/768+1e-5);
 for(i=0;i<768;i++)y[i]=(x[i]-m)*v*g[i]+b[i];
}
int fwd(int t,int p,int want){
 static float x[768],h[768],q[2304],a[3072],s[1024],o[768];
 int i,j,l,e,k;
 float*wte=F+85054464+1536+786432,*wpe=F+85054464+1536;
 for(i=0;i<768;i++)x[i]=wte[t*768+i]+wpe[p*768+i];
 for(l=0;l<12;l++){
  float*P=F+(l<2?l:l>9?l-8:l+2)*7087872L;
  R(ab,2304)R(aw,768*2304)R(pb,768)R(pw,768*768)R(b1,768)R(g1,768)R(b2,768)R(g2,768)
  R(fb,3072)R(fw,768*3072)R(mb,768)R(mw,3072*768)
  ln(x,h,b1,g1);
  mm(h,aw,ab,q,768,2304);
  memcpy(K[l]+p*768,q+768,3072);
  memcpy(V[l]+p*768,q+1536,3072);
  for(e=0;e<12;e++){
   float m=-1e30,z=0;
   for(j=0;j<=p;j++){
    float c=0;
    for(i=0;i<64;i++)c+=q[e*64+i]*K[l][j*768+e*64+i];
    s[j]=c/8;if(s[j]>m)m=s[j];
   }
   for(j=0;j<=p;j++){s[j]=expf(s[j]-m);z+=s[j];}
   for(i=0;i<64;i++){
    float c=0;
    for(j=0;j<=p;j++)c+=s[j]*V[l][j*768+e*64+i];
    o[e*64+i]=c/z;
   }
  }
  mm(o,pw,pb,h,768,768);
  for(i=0;i<768;i++)x[i]+=h[i];
  ln(x,h,b2,g2);
  mm(h,fw,fb,a,768,3072);
  for(i=0;i<3072;i++)a[i]=.5*a[i]*(1+tanhf(.7978845608f*(a[i]+.044715f*a[i]*a[i]*a[i])));
  mm(a,mw,mb,h,3072,768);
  for(i=0;i<768;i++)x[i]+=h[i];
 }
 if(!want)return 0;
 ln(x,h,F+85054464,F+85054464+768);
 float m=-1e30;k=0;
 for(j=0;j<50257;j++){
  float c=0;
  for(i=0;i<768;i++)c+=h[i]*wte[j*768+i];
  if(c>m)m=c,k=j;
 }
 return k;
}
int main(int c,char**v){
 FILE*f=fopen(v[1],"rb");
 long n,i,j,k,r,best,bi,nm=0;
 F=malloc(497759232);
 fread(F,1,497759232,f);
 f=fopen(v[2],"rb");
 d=calloc(1<<20,1);
 fread(d,1,1<<20,f);
 for(i=0;i<12;i++)K[i]=malloc(3145728),V[i]=malloc(3145728);
 for(i=j=k=0;k<256;i=++i%256){
  int p=(i>32&&i<127)||(i>160&&i<173)||i>173;
  if(p==(k<188)){
   int u=p?i:256+j++;
   cp[i]=u;bid[i]=k;
   tok[k]=calloc(3,1);
   if(u<128)tok[k][0]=u;
   else tok[k][0]=192|u>>6,tok[k][1]=128|u&63;
   k++;
  }
 }
 strtok(d,"\n");
 while((d=strtok(0,"\n"))){
  ln_[nm]=d;
  tok[256+nm]=strdup(d);
  char*p=strchr(tok[256+nm],' ');
  strcpy(p,p+1);
  nm++;
 }
 for(n=0;v[3][n];n++)S[n]=tok[bid[(unsigned char)v[3][n]]];
 for(;;){
  best=1e9;bi=-1;
  for(i=0;i<n-1;i++){
   sprintf(B,"%s %s",S[i],S[i+1]);
   for(r=0;r<nm&&r<best;r++)if(!strcmp(ln_[r],B)){best=r;bi=i;break;}
  }
  if(bi<0)break;
  char*t=malloc(99);
  sprintf(t,"%s%s",S[bi],S[bi+1]);
  S[bi]=t;
  memmove(S+bi+1,S+bi+2,(n---bi-2)*8);
 }
 for(i=0;i<n;i++)for(j=0;j<50256;j++)if(tok[j]&&!strcmp(tok[j],S[i])){T[i]=j;break;}
 printf("%s",v[3]);
 for(i=0;i<n+19;i++){
  r=fwd(T[i],i,i>=n-1);
  if(i>=n-1){
   T[i+1]=r;
   if(r<50256){
    char*s=tok[r];
    while(*s){
     int u=(unsigned char)*s++;
     if(u>127)u=(u&31)<<6|(*s++&63);
     for(j=0;cp[j]!=u;j++);
     putchar(j);
    }
   }
   fflush(stdout);
  }
 }
 puts("");
}
