#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define R(i,n) for(i=0;i<n;i++)
#define N 768
typedef float F;
F*W,x[N],h[N],q[2304],o[N],u[3072],K[12][1024][N],V[12][1024][N],s[1024];
char*T[50257],*P[50000][2],S[300],*z;
unsigned char L[256],I[256];
int Z[1024],a[9999],i,j,k,t,l,n,m,b;
int g(int c){return c>32&&c<127||c>160&&c!=173;}
int C(int c){return!c||isspace(c)?0:c<0||isalpha(c)?1:isdigit(c)?2:3;}
char*d(char*s){char*r=calloc(199,1),*w=r;for(;*s;s++){int c=*s&255;if(c>127)c=(c&31)<<6|*++s&63;*w++=c<256?c:L[c-68];}return r;}
double E(double x){if(x<-80)return 0;int k=x*1.4426950408889634+(x>0?.5:-.5);double r=x-k*.6931471805599453,y=1;for(int i=12;i;i--)y=1+r*y/i;for(;k>0;k--)y*=2;for(;k<0;k++)y/=2;return y;}
F rs(F v){union{F f;int i;}w={v};w.i=0x5f3759df-(w.i>>1);F y=w.f;for(int i=0;i<4;i++)y*=1.5f-v/2*y*y;return y;}
void ln(F*b){F m=0,v=0;int i;R(i,N)m+=x[i];m/=N;R(i,N)v+=(x[i]-m)*(x[i]-m);v=rs(v/N+1e-5f);R(i,N)h[i]=(x[i]-m)*v*b[N+i]+b[i];}
void mm(F*b,F*a,F*y,int n,int m){int i,j;F*w=b+m;R(j,m)y[j]=b[j];R(i,n)R(j,m)y[j]+=a[i]*w[i*m+j];}
int main(int c,char**v){
FILE*f=fopen(v[1],"rb");W=malloc(497759232);fread(W,1,497759232,f);
f=fopen(v[2],"r");
R(i,256)if(g(i))L[k++]=i;
R(i,256)if(!g(i))L[k++]=i;
R(i,256){I[L[i]]=i;*(T[i]=calloc(2,1))=L[i];}
fgets(S,300,f);
for(i=0;fgets(S,300,f);i++){z=strchr(S,32);*z++=0;z[strlen(z)-1]=0;P[i][0]=d(S);P[i][1]=d(z);strcat(strcpy(T[256+i]=calloc(199,1),P[i][0]),P[i][1]);}
char*p=v[3];
for(;*p;p+=m){
m=0;
if(*p==39){if(p[1]&&strchr("stmd",p[1]))m=2;else for(j=0;j<6;j+=2)if(!strncmp(p+1,"revell"+j,2))m=3;}
if(!m){char*r=p+(*p==32),*e=r;if(C(*r)){while(C(*e)==C(*r))e++;m=e-p;}else{e=p;while(isspace(*e))e++;m=e-p;if(*e&&m>1)m--;}}
R(j,m)a[j]=I[(unsigned char)p[j]];
for(l=m;;){
for(b=50000,j=0;j<l-1;j++)for(i=0;i<b;i++)if(!strcmp(P[i][0],T[a[j]])&&!strcmp(P[i][1],T[a[j+1]])){b=i;k=j;break;}
if(b>49999)break;
a[k]=256+b;l--;memmove(a+k+1,a+k+2,(l-k-1)*4);}
R(j,l)Z[n++]=a[j];}
for(t=0;t<n+19;t++){
R(i,N)x[i]=W[85842432+Z[t]*N+i]+W[85056000+t*N+i];
R(l,12){
F*B=W+(l<2?l:l<10?l+2:l-8)*7087872;
ln(B+2362368);mm(B,h,q,N,2304);
memcpy(K[l][t],q+N,N*4);memcpy(V[l][t],q+2*N,N*4);
R(k,12){F M=-1e9,Q=0,*p=q+k*64;
R(i,t+1){F y=0;R(j,64)y+=p[j]*K[l][i][k*64+j];s[i]=y/8;if(s[i]>M)M=s[i];}
R(i,t+1)Q+=s[i]=E(s[i]-M);
R(j,64){F y=0;R(i,t+1)y+=s[i]*V[l][i][k*64+j];o[k*64+j]=y/Q;}}
mm(B+1771776,o,h,N,N);R(i,N)x[i]+=h[i];
ln(B+2363904);mm(B+2365440,h,u,N,3072);
R(i,3072){F y=u[i];u[i]=y/2*(2-2/(E(1.5957691*(y+.044715*y*y*y))+1));}
mm(B+4727808,u,h,3072,N);R(i,N)x[i]+=h[i];}
if(t>=n-1){ln(W+85054464);F M=-1e9;
R(i,50257){F y=0;F*e=W+85842432+i*N;R(j,N)y+=h[j]*e[j];if(y>M){M=y;k=i;}}
Z[t+1]=k;fputs(T[k],stdout);}}
}
