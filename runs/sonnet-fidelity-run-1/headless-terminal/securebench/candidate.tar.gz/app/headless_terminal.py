import fcntl
import os
import pty
import select
import signal
import struct
import termios
import threading
import time

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """An interactive bash shell running on a pseudo-terminal."""

    def __init__(self, rows: int = 50, cols: int = 200, shell: str = "bash"):
        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["LINES"], env["COLUMNS"] = str(rows), str(cols)
        pid, fd = pty.fork()
        if pid == 0:
            try:
                os.execvpe(shell, [shell, "-i"], env)
            finally:
                os._exit(127)
        self._pid, self._fd = pid, fd
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        self._buf = bytearray()
        self._lock = threading.Lock()
        self._closed = False
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()
        time.sleep(0.5)  # let the shell source its startup files

    def _read_loop(self):
        while not self._closed:
            try:
                r, _, _ = select.select([self._fd], [], [], 0.1)
                if not r:
                    continue
                data = os.read(self._fd, 65536)
            except (OSError, ValueError):
                break
            if not data:
                break
            with self._lock:
                self._buf += data

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        """Write keystrokes (including control chars like "\\x03") to the terminal."""
        if self._closed:
            raise RuntimeError("terminal is closed")
        data = keystrokes.encode()
        while data:
            n = os.write(self._fd, data)
            data = data[n:]
        if wait_sec > 0:
            time.sleep(wait_sec)

    def read_output(self, clear: bool = True) -> str:
        """Return raw output received since the last clearing read."""
        with self._lock:
            out = bytes(self._buf)
            if clear:
                self._buf.clear()
        return out.decode(errors="replace")

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            os.kill(self._pid, signal.SIGHUP)
        except OSError:
            pass
        try:
            os.close(self._fd)
        except OSError:
            pass
        try:
            os.waitpid(self._pid, 0)
        except OSError:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
