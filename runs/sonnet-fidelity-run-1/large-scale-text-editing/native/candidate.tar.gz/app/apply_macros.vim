call setreg('a', ":s/\\v^\\s*(.{-})\\s*,\\s*(.{-})\\s*,\\s*(.{-})\\s*$/\\3;\\2;\\1;OK/\<CR>")
call setreg('b', "gUU")
call setreg('c', "0")
:%normal! @a
:%normal! @b
:%normal! @c
:wq
