call setreg('a', ":s/\\v^\\s*(\\S+)\\s*,\\s*(\\S+)\\s*,\\s*(\\S+)\\s*$/\\3;\\2;\\1;OK/\r")
call setreg('b', ":s/.*/\\U&/\r")
call setreg('c', "0")
:%normal! @a
:%normal! @b
:%normal! @c
:x
