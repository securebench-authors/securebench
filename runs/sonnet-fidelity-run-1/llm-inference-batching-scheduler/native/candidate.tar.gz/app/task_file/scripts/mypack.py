import json,sys
sys.path.insert(0,'scripts')
from cost_model import CostModel,align
cm=CostModel(64);MU=float(sys.argv[2])
def plan(R,lam):
    R=sorted(R,key=lambda r:(align(r['prompt_len'],64),r['gen_len']))
    n=len(R);INF=float('inf');dp=[INF]*(n+1);dp[0]=0;bk=[0]*(n+1)
    for i in range(1,n+1):
        for j in range(i-1,max(-1,i-200),-1):
            m=cm.batch_metrics(R[j:i])
            c=dp[j]+m['cost']+1e7+lam*m['pad_tokens']+MU*(max(m['latencies'])+8)
            if c<dp[i]:dp[i]=c;bk[i]=j
    out=[];i=n
    while i>0:out.append(R[bk[i]:i]);i=bk[i]
    return out[::-1]
def run(lam):
    res={}
    for b in (1,2):
        R=[json.loads(l) for l in open(f'input_data/requests_bucket_{b}.jsonl')]
        res[b]=plan(R,lam)
    smax=sorted({align(max(r['prompt_len'] for r in B),64) for b in res for B in res[b]})
    # choose 8 shapes: greedy drop of smallest-cost merges
    shapes=smax[:]
    while len(shapes)>8:
        k=min(range(len(shapes)-1),key=lambda k:sum(1 for b in res for B in res[b] if align(max(r['prompt_len'] for r in B),64)==shapes[k]))
        shapes.pop(k)
    for b in (1,2):
        P=[]
        for i,B in enumerate(res[b]):
            s=next(x for x in shapes if x>=align(max(r['prompt_len'] for r in B),64))
            for r in B:P.append({'request_id':r['request_id'],'batch_id':f'b-{i:04d}','shape':{'seq_align':s,'heads_align':32,'hidden_align':4096}})
        open(f'output_data/plan_b{b}.jsonl','w').write('\n'.join(json.dumps(p) for p in P)+'\n')
        reqs={json.loads(l)['request_id']:json.loads(l) for l in open(f'input_data/requests_bucket_{b}.jsonl')}
        m=cm.plan_metrics(reqs,P);print(b,len(res[b]),shapes,{k:m[k] for k in('cost','pad_ratio','p95_latency_ms','sequential_timecost')})
run(float(sys.argv[1]))
