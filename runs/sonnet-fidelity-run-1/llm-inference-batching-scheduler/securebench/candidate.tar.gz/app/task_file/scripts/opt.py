import json,sys,random
sys.path.insert(0,'scripts')
from cost_model import *
cm=CostModel(64)
import os
MU=float(os.environ.get('MU','0'))
def load(b): return [json.loads(l) for l in open(f'input_data/requests_bucket_{b}.jsonl')]
def bcost(rs):
    m=cm.batch_metrics(rs); return m['cost']+1e7+MU*(max(m['latencies'])+8), m['pad_tokens']
def split(rs,lam):
    # rs sorted; DP contiguous
    n=len(rs); INF=1e30; f=[0]+[INF]*n; pr=[0]*(n+1)
    for j in range(1,n+1):
        for i in range(j-1,max(-1,j-120),-1):
            c,p=bcost(rs[i:j]); v=f[i]+c+lam*p
            if v<f[j]: f[j]=v;pr[j]=i
    out=[];j=n
    while j>0: out.append(rs[pr[j]:j]); j=pr[j]
    return out
def plan(R,shapes,lam):
    shapes=sorted(shapes); g={}
    for r in R:
        s=next(x for x in shapes if x>=align(r['prompt_len'],64)); g.setdefault(s,[]).append(r)
    res=[]
    for s,rs in g.items():
        rs.sort(key=lambda r:(r['gen_len'],r['prompt_len']))
        for b in split(rs,lam): res.append((s,b))
    return res
def recs(pl,pref):
    o=[]
    for k,(s,b) in enumerate(pl):
        for r in b: o.append({'request_id':r['request_id'],'batch_id':f'b-{k:04d}','shape':{'seq_align':s,'heads_align':32,'hidden_align':4096}})
    return o
def run(shapes,lam,write=False):
    out=[]
    for b in (1,2):
        R=load(b); rq={r['request_id']:r for r in R}
        o=recs(plan(R,shapes,lam),b); m=cm.plan_metrics(rq,o); out.append(m)
        if write: open(f'output_data/plan_b{b}.jsonl','w').write(''.join(json.dumps(x)+'\n' for x in o))
    return out
if __name__=='__main__':
    shapes=eval(sys.argv[1]); lam=float(sys.argv[2])
    for m in run(shapes,lam,len(sys.argv)>3): print({k:m[k] for k in('cost','pad_ratio','p95_latency_ms','sequential_timecost')})
