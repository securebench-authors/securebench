#!/bin/bash
# Build /app/doomgeneric_mips (little-endian MIPS32, soft-float, freestanding libc in ./libc).
# Assembly is post-processed to work around vm.js quirks:
#  - beq/bne between two registers compare JS numbers (signed vs unsigned mismatch) -> xor first
#  - `mul` goes through double math (inexact for large products) -> multu/mflo
set -e
cd "$(dirname "$0")"
CC=mipsel-linux-gnu-gcc
AS=mipsel-linux-gnu-as
CF="-march=mips32 -mabi=32 -msoft-float -mno-abicalls -fno-pic -mno-shared -G0 -mno-check-zero-division -mno-llsc -O2 -ffreestanding -nostdinc -isystem libc -I$($CC -print-file-name=include) -fno-asynchronous-unwind-tables -w -DNORMALUNIX -DLINUX -include libc/my_stdlib.h"
SRC=$(grep '^SRC_DOOM' Makefile | sed 's/.*= //; s/doomgeneric_xlib.o/doomgeneric_img.o/; s/\.o/.c/g')
mkdir -p build_mips
build() {
  f=$1; b=build_mips/$(basename $f .c)
  extra=""; [ "$f" = libc/softfp.c ] && extra=-fno-builtin
  $CC $CF $extra -S $f -o $b.s
  python3 - $b.s <<'PY'
import re,sys
p=sys.argv[1]; out=[]
for l in open(p):
    m=re.match(r'\t(beq|bne)\t(\$\w+),(\$\w+),(\S+)',l)
    if m and m.group(2) not in('$0','$zero') and m.group(3) not in('$0','$zero'):
        op,a,b,t=m.groups()
        out.append('\t.set\tnoat\n\txor\t$1,%s,%s\n\t%s\t$1,$0,%s\n\t.set\tat\n'%(a,b,op,t)); continue
    m=re.match(r'\tmul\t(\$\w+),(\$\w+),(\$\w+)',l)
    if m:
        d,a,b=m.groups(); out.append('\tmultu\t%s,%s\n\tmflo\t%s\n'%(a,b,d)); continue
    out.append(l)
open(p,'w').write(''.join(out))
PY
  $CC -march=mips32 -msoft-float -mno-abicalls -fno-pic -mno-shared -G0 -c $b.s -o $b.o
}
rm -f build_mips/*.o
for f in $SRC libc/my_stdlib.c libc/softfp.c; do build $f & done
wait
$CC -nostdlib -static -T link.ld build_mips/*.o -o /app/doomgeneric_mips 2>&1 | grep -v build-id || true
ls -la /app/doomgeneric_mips
