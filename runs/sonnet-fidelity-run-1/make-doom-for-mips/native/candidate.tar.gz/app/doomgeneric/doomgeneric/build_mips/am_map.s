	.file	1 "am_map.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	AM_getIslope
	.set	nomips16
	.set	nomicromips
	.ent	AM_getIslope
	.type	AM_getIslope, @function
AM_getIslope:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lw	$3,4($4)
	lw	$2,12($4)
	sw	$16,16($sp)
	lw	$16,8($4)
	lw	$4,0($4)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$31,28($sp)
	move	$17,$5
	subu	$18,$3,$2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L2
	.set	at
	subu	$16,$16,$4

	bltz	$16,$L15
	li	$2,2147418112			# 0x7fff0000

	ori	$2,$2,0xffff
	bne	$16,$0,$L4
	sw	$2,4($5)

$L5:
	lw	$31,28($sp)
	li	$2,2147418112			# 0x7fff0000
	ori	$2,$2,0xffff
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$2,0($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L15:
	li	$2,-2147483648			# 0xffffffff80000000
	addiu	$2,$2,1
	sw	$2,4($5)
$L4:
	move	$5,$16
	jal	FixedDiv
	move	$4,$18

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$2,0($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L2:
	move	$5,$18
	jal	FixedDiv
	move	$4,$16

	bne	$16,$0,$L4
	sw	$2,4($17)

	bgez	$18,$L5
	lw	$31,28($sp)

	li	$2,-2147483648			# 0xffffffff80000000
	addiu	$2,$2,1
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$2,0($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	AM_getIslope
	.size	AM_getIslope, .-AM_getIslope
	.align	2
	.globl	AM_activateNewScale
	.set	nomips16
	.set	nomicromips
	.ent	AM_activateNewScale
	.type	AM_activateNewScale, @function
AM_activateNewScale:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$19,28($sp)
	sw	$18,24($sp)
	lui	$19,%hi(m_w)
	lui	$18,%hi(m_h)
	lw	$6,%lo(m_w)($19)
	lw	$5,%lo(m_h)($18)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lui	$17,%hi(m_x)
	lui	$16,%hi(m_y)
	srl	$3,$6,31
	srl	$2,$5,31
	lui	$4,%hi(f_w)
	sw	$20,32($sp)
	lw	$7,%lo(m_y)($16)
	lw	$8,%lo(m_x)($17)
	addu	$3,$3,$6
	lui	$20,%hi(scale_ftom)
	lw	$4,%lo(f_w)($4)
	addu	$2,$2,$5
	sra	$3,$3,1
	lw	$5,%lo(scale_ftom)($20)
	sra	$2,$2,1
	addu	$3,$3,$8
	addu	$2,$2,$7
	sll	$4,$4,16
	sw	$31,36($sp)
	sw	$3,%lo(m_x)($17)
	jal	FixedMul
	sw	$2,%lo(m_y)($16)

	lui	$3,%hi(f_h)
	lw	$4,%lo(f_h)($3)
	lw	$5,%lo(scale_ftom)($20)
	sll	$4,$4,16
	jal	FixedMul
	sw	$2,%lo(m_w)($19)

	lw	$3,%lo(m_w)($19)
	srl	$4,$2,31
	srl	$5,$3,31
	lw	$6,%lo(m_y)($16)
	lw	$7,%lo(m_x)($17)
	addu	$5,$5,$3
	addu	$4,$4,$2
	sra	$5,$5,1
	sra	$4,$4,1
	subu	$5,$7,$5
	subu	$4,$6,$4
	lw	$31,36($sp)
	addu	$6,$2,$4
	sw	$2,%lo(m_h)($18)
	addu	$3,$3,$5
	lui	$2,%hi(m_x2)
	sw	$3,%lo(m_x2)($2)
	lui	$2,%hi(m_y2)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	sw	$5,%lo(m_x)($17)
	sw	$4,%lo(m_y)($16)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$6,%lo(m_y2)($2)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	AM_activateNewScale
	.size	AM_activateNewScale, .-AM_activateNewScale
	.align	2
	.globl	AM_saveScaleAndLoc
	.set	nomips16
	.set	nomicromips
	.ent	AM_saveScaleAndLoc
	.type	AM_saveScaleAndLoc, @function
AM_saveScaleAndLoc:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(m_x)
	lw	$6,%lo(m_x)($2)
	lui	$2,%hi(m_y)
	lw	$5,%lo(m_y)($2)
	lui	$2,%hi(m_w)
	lw	$4,%lo(m_w)($2)
	lui	$2,%hi(m_h)
	lw	$3,%lo(m_h)($2)
	lui	$2,%hi(old_m_x)
	sw	$6,%lo(old_m_x)($2)
	lui	$2,%hi(old_m_y)
	sw	$5,%lo(old_m_y)($2)
	lui	$2,%hi(old_m_w)
	sw	$4,%lo(old_m_w)($2)
	lui	$2,%hi(old_m_h)
	jr	$31
	sw	$3,%lo(old_m_h)($2)

	.set	macro
	.set	reorder
	.end	AM_saveScaleAndLoc
	.size	AM_saveScaleAndLoc, .-AM_saveScaleAndLoc
	.align	2
	.globl	AM_restoreScaleAndLoc
	.set	nomips16
	.set	nomicromips
	.ent	AM_restoreScaleAndLoc
	.type	AM_restoreScaleAndLoc, @function
AM_restoreScaleAndLoc:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(old_m_w)
	lw	$5,%lo(old_m_w)($2)
	lui	$2,%hi(old_m_h)
	lw	$3,%lo(old_m_h)($2)
	lui	$2,%hi(followplayer)
	lui	$4,%hi(m_w)
	lw	$2,%lo(followplayer)($2)
	addiu	$sp,$sp,-24
	sw	$5,%lo(m_w)($4)
	lui	$4,%hi(m_h)
	sw	$3,%lo(m_h)($4)
	bne	$2,$0,$L20
	sw	$31,20($sp)

	lui	$2,%hi(old_m_x)
	lw	$6,%lo(old_m_x)($2)
	lui	$2,%hi(old_m_y)
	lw	$7,%lo(old_m_y)($2)
$L21:
	lui	$8,%hi(m_y)
	lui	$2,%hi(f_w)
	addu	$3,$3,$7
	lw	$4,%lo(f_w)($2)
	sw	$7,%lo(m_y)($8)
	lui	$7,%hi(m_x)
	addu	$2,$5,$6
	sw	$6,%lo(m_x)($7)
	lui	$6,%hi(m_x2)
	sw	$2,%lo(m_x2)($6)
	sll	$4,$4,16
	lui	$2,%hi(m_y2)
	jal	FixedDiv
	sw	$3,%lo(m_y2)($2)

	move	$5,$2
	li	$4,65536			# 0x10000
	lui	$2,%hi(scale_mtof)
	jal	FixedDiv
	sw	$5,%lo(scale_mtof)($2)

	lw	$31,20($sp)
	lui	$3,%hi(scale_ftom)
	sw	$2,%lo(scale_ftom)($3)
	jr	$31
	addiu	$sp,$sp,24

$L20:
	lui	$2,%hi(plr)
	lw	$2,%lo(plr)($2)
	srl	$4,$5,31
	lw	$7,0($2)
	srl	$2,$3,31
	lw	$6,12($7)
	addu	$4,$4,$5
	lw	$7,16($7)
	addu	$2,$2,$3
	sra	$4,$4,1
	sra	$2,$2,1
	subu	$6,$6,$4
	b	$L21
	subu	$7,$7,$2

	.set	macro
	.set	reorder
	.end	AM_restoreScaleAndLoc
	.size	AM_restoreScaleAndLoc, .-AM_restoreScaleAndLoc
	.align	2
	.globl	AM_addMark
	.set	nomips16
	.set	nomicromips
	.ent	AM_addMark
	.type	AM_addMark, @function
AM_addMark:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$9,%hi(markpointnum)
	lw	$3,%lo(markpointnum)($9)
	li	$2,1717960704			# 0x66660000
	addiu	$6,$3,1
	addiu	$2,$2,26215
	mult	$6,$2
	lui	$4,%hi(m_w)
	mfhi	$2
	lw	$10,%lo(m_w)($4)
	lui	$4,%hi(m_h)
	lw	$8,%lo(m_h)($4)
	sra	$2,$2,2
	sra	$4,$6,31
	subu	$2,$2,$4
	lui	$11,%hi(m_x)
	lw	$12,%lo(m_x)($11)
	srl	$4,$8,31
	sll	$7,$2,2
	srl	$5,$10,31
	lui	$11,%hi(m_y)
	addu	$4,$4,$8
	addu	$7,$7,$2
	lw	$11,%lo(m_y)($11)
	addu	$5,$5,$10
	lui	$8,%hi(markpoints)
	sra	$2,$4,1
	sll	$3,$3,3
	addiu	$4,$8,%lo(markpoints)
	sra	$5,$5,1
	sll	$7,$7,1
	addu	$3,$3,$4
	addu	$2,$2,$11
	addu	$4,$5,$12
	subu	$6,$6,$7
	sw	$4,0($3)
	sw	$2,4($3)
	jr	$31
	sw	$6,%lo(markpointnum)($9)

	.set	macro
	.set	reorder
	.end	AM_addMark
	.size	AM_addMark, .-AM_addMark
	.align	2
	.globl	AM_findMinMaxBoundaries
	.set	nomips16
	.set	nomicromips
	.ent	AM_findMinMaxBoundaries
	.type	AM_findMinMaxBoundaries, @function
AM_findMinMaxBoundaries:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numvertexes)
	addiu	$sp,$sp,-32
	li	$6,2147418112			# 0x7fff0000
	li	$4,-2147483648			# 0xffffffff80000000
	lw	$9,%lo(numvertexes)($2)
	ori	$6,$6,0xffff
	addiu	$4,$4,1
	sw	$17,24($sp)
	sw	$16,20($sp)
	lui	$17,%hi(min_y)
	lui	$24,%hi(min_x)
	lui	$25,%hi(max_y)
	lui	$16,%hi(max_x)
	sw	$31,28($sp)
	sw	$6,%lo(min_y)($17)
	sw	$6,%lo(min_x)($24)
	sw	$4,%lo(max_y)($25)
	blez	$9,$L33
	sw	$4,%lo(max_x)($16)

	lui	$2,%hi(vertexes)
	lw	$2,%lo(vertexes)($2)
	sll	$9,$9,3
	addu	$9,$9,$2
	move	$11,$0
	move	$14,$0
	move	$12,$0
	move	$5,$4
	move	$15,$0
	move	$10,$6
	b	$L28
	li	$13,1			# 0x1

$L44:
	addiu	$2,$2,8
	movn	$4,$3,$7
	.set	noat
	xor	$1,$9,$2
	beq	$1,$0,$L43
	.set	at
	movn	$11,$13,$7

$L28:
	lw	$3,0($2)
	slt	$8,$3,$10
	bne	$8,$0,$L34
	slt	$7,$5,$3

	movn	$5,$3,$7
	movn	$12,$13,$7
$L26:
	lw	$3,4($2)
	slt	$8,$3,$6
	beq	$8,$0,$L44
	slt	$7,$4,$3

	addiu	$2,$2,8
	move	$6,$3
	.set	noat
	xor	$1,$9,$2
	bne	$1,$0,$L28
	.set	at
	li	$14,1			# 0x1

$L43:
	beq	$11,$0,$L38
	nop

	beq	$14,$0,$L39
	sw	$4,%lo(max_y)($25)

$L46:
	beq	$12,$0,$L40
	sw	$6,%lo(min_y)($17)

$L47:
	sw	$5,%lo(max_x)($16)
$L31:
	beq	$15,$0,$L45
	subu	$2,$4,$6

	sw	$10,%lo(min_x)($24)
	subu	$5,$5,$10
$L25:
	lui	$3,%hi(f_w)
	lw	$4,%lo(f_w)($3)
	lui	$16,%hi(max_h)
	lui	$17,%hi(f_h)
	sll	$4,$4,16
	jal	FixedDiv
	sw	$2,%lo(max_h)($16)

	lw	$4,%lo(f_h)($17)
	lw	$5,%lo(max_h)($16)
	sll	$4,$4,16
	jal	FixedDiv
	move	$16,$2

	lw	$4,%lo(f_h)($17)
	slt	$3,$2,$16
	movn	$16,$2,$3
	li	$5,2097152			# 0x200000
	lui	$2,%hi(min_scale_mtof)
	sll	$4,$4,16
	jal	FixedDiv
	sw	$16,%lo(min_scale_mtof)($2)

	lw	$31,28($sp)
	lui	$3,%hi(max_scale_mtof)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$2,%lo(max_scale_mtof)($3)
	jr	$31
	addiu	$sp,$sp,32

$L34:
	move	$10,$3
	b	$L26
	li	$15,1			# 0x1

$L38:
	li	$4,-2147483648			# 0xffffffff80000000
	bne	$14,$0,$L46
	addiu	$4,$4,1

$L39:
	li	$6,2147418112			# 0x7fff0000
	bne	$12,$0,$L47
	ori	$6,$6,0xffff

$L40:
	li	$5,-2147483648			# 0xffffffff80000000
	b	$L31
	addiu	$5,$5,1

$L45:
	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,1
	b	$L25
	addu	$5,$5,$3

$L33:
	li	$2,2			# 0x2
	b	$L25
	li	$5,2			# 0x2

	.set	macro
	.set	reorder
	.end	AM_findMinMaxBoundaries
	.size	AM_findMinMaxBoundaries, .-AM_findMinMaxBoundaries
	.align	2
	.globl	AM_changeWindowLoc
	.set	nomips16
	.set	nomicromips
	.ent	AM_changeWindowLoc
	.type	AM_changeWindowLoc, @function
AM_changeWindowLoc:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(m_paninc)
	addiu	$4,$2,%lo(m_paninc)
	lw	$3,%lo(m_paninc)($2)
	lw	$2,4($4)
	or	$4,$3,$2
	beq	$4,$0,$L59
	lui	$4,%hi(m_w)

	lui	$4,%hi(followplayer)
	sw	$0,%lo(followplayer)($4)
	li	$4,2147418112			# 0x7fff0000
	lui	$5,%hi(f_oldloc)
	ori	$4,$4,0xffff
	sw	$4,%lo(f_oldloc)($5)
	lui	$4,%hi(m_w)
$L59:
	lw	$7,%lo(m_w)($4)
	lui	$5,%hi(m_x)
	lw	$6,%lo(m_x)($5)
	srl	$4,$7,31
	addu	$3,$3,$6
	lui	$8,%hi(m_y)
	lui	$6,%hi(max_x)
	addu	$4,$4,$7
	lw	$10,%lo(m_y)($8)
	lw	$9,%lo(max_x)($6)
	sra	$4,$4,1
	addu	$6,$3,$4
	addu	$2,$2,$10
	slt	$10,$9,$6
	sw	$3,%lo(m_x)($5)
	bne	$10,$0,$L57
	sw	$2,%lo(m_y)($8)

	lui	$9,%hi(min_x)
	lw	$9,%lo(min_x)($9)
	slt	$6,$6,$9
	bne	$6,$0,$L57
	nop

$L51:
	lui	$4,%hi(m_h)
	lw	$5,%lo(m_h)($4)
	lui	$6,%hi(max_y)
	srl	$4,$5,31
	addu	$4,$4,$5
	lw	$9,%lo(max_y)($6)
	sra	$4,$4,1
	addu	$6,$2,$4
	slt	$10,$9,$6
	bne	$10,$0,$L58
	nop

	lui	$9,%hi(min_y)
	lw	$9,%lo(min_y)($9)
	slt	$6,$6,$9
	beq	$6,$0,$L53
	nop

$L58:
	subu	$2,$9,$4
	sw	$2,%lo(m_y)($8)
$L53:
	addu	$5,$5,$2
	addu	$3,$7,$3
	lui	$2,%hi(m_x2)
	sw	$3,%lo(m_x2)($2)
	lui	$2,%hi(m_y2)
	jr	$31
	sw	$5,%lo(m_y2)($2)

$L57:
	subu	$3,$9,$4
	b	$L51
	sw	$3,%lo(m_x)($5)

	.set	macro
	.set	reorder
	.end	AM_changeWindowLoc
	.size	AM_changeWindowLoc, .-AM_changeWindowLoc
	.align	2
	.globl	AM_initVariables
	.set	nomips16
	.set	nomicromips
	.ent	AM_initVariables
	.type	AM_initVariables, @function
AM_initVariables:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(f_w)
	lw	$4,%lo(f_w)($2)
	lui	$2,%hi(I_VideoBuffer)
	lw	$8,%lo(I_VideoBuffer)($2)
	li	$9,1			# 0x1
	lui	$2,%hi(automapactive)
	sw	$9,%lo(automapactive)($2)
	lui	$2,%hi(fb)
	sw	$8,%lo(fb)($2)
	li	$2,2147418112			# 0x7fff0000
	lui	$8,%hi(f_oldloc)
	ori	$2,$2,0xffff
	addiu	$sp,$sp,-24
	li	$6,65536			# 0x10000
	sw	$2,%lo(f_oldloc)($8)
	lui	$2,%hi(ftom_zoommul)
	sw	$6,%lo(ftom_zoommul)($2)
	sw	$16,16($sp)
	lui	$2,%hi(mtof_zoommul)
	lui	$16,%hi(scale_ftom)
	lui	$3,%hi(m_paninc)
	lw	$5,%lo(scale_ftom)($16)
	sw	$6,%lo(mtof_zoommul)($2)
	lui	$2,%hi(amclock)
	addiu	$7,$3,%lo(m_paninc)
	sll	$4,$4,16
	sw	$0,%lo(amclock)($2)
	lui	$2,%hi(lightlev)
	sw	$31,20($sp)
	sw	$0,%lo(m_paninc)($3)
	sw	$0,4($7)
	jal	FixedMul
	sw	$0,%lo(lightlev)($2)

	lui	$3,%hi(f_h)
	lw	$4,%lo(f_h)($3)
	lw	$5,%lo(scale_ftom)($16)
	sll	$4,$4,16
	lui	$16,%hi(m_w)
	jal	FixedMul
	sw	$2,%lo(m_w)($16)

	lui	$3,%hi(consoleplayer)
	lw	$5,%lo(consoleplayer)($3)
	lui	$3,%hi(playeringame)
	sll	$4,$5,2
	addiu	$3,$3,%lo(playeringame)
	addu	$4,$4,$3
	lw	$4,0($4)
	move	$11,$2
	lui	$2,%hi(m_h)
	beq	$4,$0,$L61
	sw	$11,%lo(m_h)($2)

	sll	$3,$5,3
	addu	$3,$3,$5
	lui	$2,%hi(players)
	sll	$3,$3,5
	addiu	$2,$2,%lo(players)
	addu	$2,$2,$3
	lui	$3,%hi(plr)
	sw	$2,%lo(plr)($3)
$L62:
	lw	$12,%lo(m_w)($16)
	lw	$4,0($2)
$L69:
	srl	$3,$12,31
	srl	$2,$11,31
	lw	$5,12($4)
	addu	$3,$3,$12
	lw	$4,16($4)
	addu	$2,$2,$11
	sra	$3,$3,1
	sra	$2,$2,1
	subu	$3,$5,$3
	subu	$2,$4,$2
	lui	$14,%hi(m_x)
	lui	$13,%hi(m_y)
	sw	$3,%lo(m_x)($14)
	jal	AM_changeWindowLoc
	sw	$2,%lo(m_y)($13)

	lw	$5,%lo(m_x)($14)
	lui	$2,%hi(old_m_x)
	lw	$3,%lo(m_y)($13)
	sw	$5,%lo(old_m_x)($2)
	lui	$2,%hi(old_m_y)
	lw	$31,20($sp)
	lw	$16,16($sp)
	lui	$4,%hi(st_notify.12)
	sw	$3,%lo(old_m_y)($2)
	lui	$2,%hi(old_m_w)
	sw	$12,%lo(old_m_w)($2)
	lui	$2,%hi(old_m_h)
	addiu	$4,$4,%lo(st_notify.12)
	addiu	$sp,$sp,24
	j	ST_Responder
	sw	$11,%lo(old_m_h)($2)

$L61:
	lui	$2,%hi(players)
	lui	$7,%hi(plr)
	addiu	$2,$2,%lo(players)
	sw	$2,%lo(plr)($7)
	move	$4,$0
	li	$6,4			# 0x4
$L64:
	lw	$5,0($3)
	bne	$5,$0,$L67
	addiu	$3,$3,4

	addiu	$4,$4,1
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L64
	.set	at
	lw	$12,%lo(m_w)($16)

	b	$L69
	lw	$4,0($2)

$L67:
	sll	$3,$4,3
	addu	$3,$3,$4
	sll	$3,$3,5
	addu	$2,$2,$3
	b	$L62
	sw	$2,%lo(plr)($7)

	.set	macro
	.set	reorder
	.end	AM_initVariables
	.size	AM_initVariables, .-AM_initVariables
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"AMMNUM%d\000"
	.text
	.align	2
	.globl	AM_loadPics
	.set	nomips16
	.set	nomicromips
	.ent	AM_loadPics
	.type	AM_loadPics, @function
AM_loadPics:
	.frame	$sp,56,$31		# vars= 16, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$18,44($sp)
	sw	$17,40($sp)
	lui	$18,%hi($LC0)
	lui	$17,%hi(marknums)
	sw	$19,48($sp)
	sw	$16,36($sp)
	sw	$31,52($sp)
	addiu	$17,$17,%lo(marknums)
	move	$16,$0
	addiu	$18,$18,%lo($LC0)
	li	$19,10			# 0xa
$L71:
	move	$7,$16
	addiu	$4,$sp,16
	move	$6,$18
	jal	snprintf
	li	$5,9			# 0x9

	li	$5,1			# 0x1
	jal	W_CacheLumpName
	addiu	$4,$sp,16

	addiu	$16,$16,1
	sw	$2,0($17)
	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L71
	.set	at
	addiu	$17,$17,4

	lw	$31,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	AM_loadPics
	.size	AM_loadPics, .-AM_loadPics
	.align	2
	.globl	AM_unloadPics
	.set	nomips16
	.set	nomicromips
	.ent	AM_unloadPics
	.type	AM_unloadPics, @function
AM_unloadPics:
	.frame	$sp,48,$31		# vars= 16, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,36($sp)
	lui	$17,%hi($LC0)
	sw	$18,40($sp)
	sw	$16,32($sp)
	sw	$31,44($sp)
	move	$16,$0
	addiu	$17,$17,%lo($LC0)
	li	$18,10			# 0xa
	move	$7,$16
$L78:
	addiu	$4,$sp,16
	move	$6,$17
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$16,$16,1
	jal	W_ReleaseLumpName
	addiu	$4,$sp,16

	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L78
	.set	at
	move	$7,$16

	lw	$31,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	AM_unloadPics
	.size	AM_unloadPics, .-AM_unloadPics
	.align	2
	.globl	AM_clearMarks
	.set	nomips16
	.set	nomicromips
	.ent	AM_clearMarks
	.type	AM_clearMarks, @function
AM_clearMarks:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(markpoints)
	addiu	$2,$2,%lo(markpoints)
	addiu	$4,$2,80
	li	$3,-1			# 0xffffffffffffffff
$L80:
	sw	$3,0($2)
	addiu	$2,$2,8
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L80
	.set	at
	nop

	lui	$2,%hi(markpointnum)
	jr	$31
	sw	$0,%lo(markpointnum)($2)

	.set	macro
	.set	reorder
	.end	AM_clearMarks
	.size	AM_clearMarks, .-AM_clearMarks
	.align	2
	.globl	AM_LevelInit
	.set	nomips16
	.set	nomicromips
	.ent	AM_LevelInit
	.type	AM_LevelInit, @function
AM_LevelInit:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(f_y)
	sw	$0,%lo(f_y)($3)
	lui	$3,%hi(f_x)
	li	$4,320			# 0x140
	lui	$2,%hi(markpoints)
	sw	$0,%lo(f_x)($3)
	lui	$3,%hi(f_w)
	addiu	$sp,$sp,-24
	sw	$4,%lo(f_w)($3)
	addiu	$2,$2,%lo(markpoints)
	lui	$3,%hi(f_h)
	li	$4,168			# 0xa8
	sw	$4,%lo(f_h)($3)
	addiu	$4,$2,80
	sw	$31,20($sp)
	sw	$16,16($sp)
	li	$3,-1			# 0xffffffffffffffff
$L83:
	sw	$3,0($2)
	addiu	$2,$2,8
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L83
	.set	at
	lui	$16,%hi(min_scale_mtof)

	lui	$2,%hi(markpointnum)
	jal	AM_findMinMaxBoundaries
	sw	$0,%lo(markpointnum)($2)

	lw	$4,%lo(min_scale_mtof)($16)
	jal	FixedDiv
	li	$5,45875			# 0xb333

	lui	$3,%hi(max_scale_mtof)
	lw	$3,%lo(max_scale_mtof)($3)
	move	$5,$2
	slt	$3,$3,$5
	lui	$2,%hi(scale_mtof)
	beq	$3,$0,$L84
	sw	$5,%lo(scale_mtof)($2)

	lw	$5,%lo(min_scale_mtof)($16)
	sw	$5,%lo(scale_mtof)($2)
$L84:
	jal	FixedDiv
	li	$4,65536			# 0x10000

	lw	$31,20($sp)
	lui	$3,%hi(scale_ftom)
	lw	$16,16($sp)
	sw	$2,%lo(scale_ftom)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	AM_LevelInit
	.size	AM_LevelInit, .-AM_LevelInit
	.align	2
	.globl	AM_Stop
	.set	nomips16
	.set	nomicromips
	.ent	AM_Stop
	.type	AM_Stop, @function
AM_Stop:
	.frame	$sp,48,$31		# vars= 16, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,36($sp)
	lui	$17,%hi($LC0)
	sw	$18,40($sp)
	sw	$16,32($sp)
	sw	$31,44($sp)
	move	$16,$0
	addiu	$17,$17,%lo($LC0)
	li	$18,10			# 0xa
	move	$7,$16
$L91:
	addiu	$4,$sp,16
	move	$6,$17
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$16,$16,1
	jal	W_ReleaseLumpName
	addiu	$4,$sp,16

	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L91
	.set	at
	move	$7,$16

	lui	$4,%hi(st_notify.11)
	lui	$2,%hi(automapactive)
	addiu	$4,$4,%lo(st_notify.11)
	jal	ST_Responder
	sw	$0,%lo(automapactive)($2)

	lw	$31,44($sp)
	lui	$2,%hi(stopped)
	li	$3,1			# 0x1
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	sw	$3,%lo(stopped)($2)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	AM_Stop
	.size	AM_Stop, .-AM_Stop
	.align	2
	.globl	AM_Start
	.set	nomips16
	.set	nomicromips
	.ent	AM_Start
	.type	AM_Start, @function
AM_Start:
	.frame	$sp,64,$31		# vars= 16, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$21,56($sp)
	lui	$21,%hi(stopped)
	lw	$2,%lo(stopped)($21)
	sw	$19,48($sp)
	sw	$31,60($sp)
	sw	$20,52($sp)
	sw	$18,44($sp)
	sw	$17,40($sp)
	sw	$16,36($sp)
	beq	$2,$0,$L102
	lui	$19,%hi($LC0)

	addiu	$18,$sp,16
	lui	$16,%hi(lastlevel.10)
$L105:
	lui	$17,%hi(gamemap)
	lw	$3,%lo(lastlevel.10)($16)
	lw	$2,%lo(gamemap)($17)
	sw	$0,%lo(stopped)($21)
	lui	$20,%hi(lastepisode.9)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L95
	.set	at
	lui	$21,%hi(gameepisode)

	lw	$3,%lo(lastepisode.9)($20)
	lw	$2,%lo(gameepisode)($21)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L96
	.set	at
	nop

$L95:
	jal	AM_LevelInit
	nop

	lw	$3,%lo(gamemap)($17)
	lw	$2,%lo(gameepisode)($21)
	sw	$3,%lo(lastlevel.10)($16)
	sw	$2,%lo(lastepisode.9)($20)
$L96:
	jal	AM_initVariables
	lui	$17,%hi(marknums)

	addiu	$17,$17,%lo(marknums)
	move	$16,$0
	addiu	$19,$19,%lo($LC0)
	li	$20,10			# 0xa
$L97:
	move	$7,$16
	move	$4,$18
	move	$6,$19
	jal	snprintf
	li	$5,9			# 0x9

	li	$5,1			# 0x1
	jal	W_CacheLumpName
	move	$4,$18

	addiu	$16,$16,1
	sw	$2,0($17)
	.set	noat
	xor	$1,$16,$20
	bne	$1,$0,$L97
	.set	at
	addiu	$17,$17,4

	lw	$31,60($sp)
	lw	$21,56($sp)
	lw	$20,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,64

$L102:
	move	$16,$0
	addiu	$18,$sp,16
	addiu	$20,$19,%lo($LC0)
	li	$17,10			# 0xa
	move	$7,$16
$L106:
	move	$4,$18
	move	$6,$20
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$16,$16,1
	jal	W_ReleaseLumpName
	move	$4,$18

	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L106
	.set	at
	move	$7,$16

	lui	$4,%hi(st_notify.11)
	addiu	$4,$4,%lo(st_notify.11)
	lui	$2,%hi(automapactive)
	jal	ST_Responder
	sw	$0,%lo(automapactive)($2)

	b	$L105
	lui	$16,%hi(lastlevel.10)

	.set	macro
	.set	reorder
	.end	AM_Start
	.size	AM_Start, .-AM_Start
	.align	2
	.globl	AM_minOutWindowScale
	.set	nomips16
	.set	nomicromips
	.ent	AM_minOutWindowScale
	.type	AM_minOutWindowScale, @function
AM_minOutWindowScale:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(min_scale_mtof)
	lw	$5,%lo(min_scale_mtof)($2)
	addiu	$sp,$sp,-24
	lui	$2,%hi(scale_mtof)
	sw	$5,%lo(scale_mtof)($2)
	sw	$31,20($sp)
	jal	FixedDiv
	li	$4,65536			# 0x10000

	lw	$31,20($sp)
	lui	$3,%hi(scale_ftom)
	addiu	$sp,$sp,24
	j	AM_activateNewScale
	sw	$2,%lo(scale_ftom)($3)

	.set	macro
	.set	reorder
	.end	AM_minOutWindowScale
	.size	AM_minOutWindowScale, .-AM_minOutWindowScale
	.align	2
	.globl	AM_maxOutWindowScale
	.set	nomips16
	.set	nomicromips
	.ent	AM_maxOutWindowScale
	.type	AM_maxOutWindowScale, @function
AM_maxOutWindowScale:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(max_scale_mtof)
	lw	$5,%lo(max_scale_mtof)($2)
	addiu	$sp,$sp,-24
	lui	$2,%hi(scale_mtof)
	sw	$5,%lo(scale_mtof)($2)
	sw	$31,20($sp)
	jal	FixedDiv
	li	$4,65536			# 0x10000

	lw	$31,20($sp)
	lui	$3,%hi(scale_ftom)
	addiu	$sp,$sp,24
	j	AM_activateNewScale
	sw	$2,%lo(scale_ftom)($3)

	.set	macro
	.set	reorder
	.end	AM_maxOutWindowScale
	.size	AM_maxOutWindowScale, .-AM_maxOutWindowScale
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Follow Mode ON\000"
	.align	2
$LC2:
	.ascii	"Follow Mode OFF\000"
	.align	2
$LC3:
	.ascii	"Grid ON\000"
	.align	2
$LC4:
	.ascii	"Grid OFF\000"
	.align	2
$LC5:
	.ascii	"Marked Spot\000"
	.align	2
$LC6:
	.ascii	"%s %d\000"
	.align	2
$LC7:
	.ascii	"All Marks Cleared\000"
	.text
	.align	2
	.globl	AM_Responder
	.set	nomips16
	.set	nomicromips
	.ent	AM_Responder
	.type	AM_Responder, @function
AM_Responder:
	.frame	$sp,64,$31		# vars= 16, regs= 6/0, args= 24, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$17,44($sp)
	lui	$17,%hi(automapactive)
	lw	$3,%lo(automapactive)($17)
	sw	$16,40($sp)
	lw	$2,0($4)
	sw	$31,60($sp)
	sw	$20,56($sp)
	sw	$19,52($sp)
	sw	$18,48($sp)
	bne	$3,$0,$L112
	move	$16,$4

	bne	$2,$0,$L111
	move	$2,$0

	lui	$2,%hi(key_map_toggle)
	lw	$3,4($4)
	lw	$2,%lo(key_map_toggle)($2)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L150
	.set	at
	nop

$L113:
	b	$L111
	move	$2,$0

$L112:
	bne	$2,$0,$L115
	li	$3,1			# 0x1

	lui	$3,%hi(key_map_east)
	lw	$2,4($4)
	lw	$3,%lo(key_map_east)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L151
	.set	at
	lui	$3,%hi(key_map_west)

	lw	$3,%lo(key_map_west)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L152
	.set	at
	lui	$3,%hi(key_map_north)

	lw	$3,%lo(key_map_north)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L153
	.set	at
	lui	$3,%hi(key_map_south)

	lw	$3,%lo(key_map_south)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L154
	.set	at
	lui	$3,%hi(key_map_zoomout)

	lw	$3,%lo(key_map_zoomout)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L155
	.set	at
	lui	$3,%hi(key_map_zoomin)

	lw	$3,%lo(key_map_zoomin)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L156
	.set	at
	lui	$3,%hi(key_map_toggle)

	lw	$3,%lo(key_map_toggle)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L157
	.set	at
	lui	$3,%hi(key_map_maxzoom)

	lw	$3,%lo(key_map_maxzoom)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L158
	.set	at
	lui	$3,%hi(key_map_follow)

	lw	$3,%lo(key_map_follow)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L159
	.set	at
	lui	$3,%hi(key_map_grid)

	lw	$3,%lo(key_map_grid)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L160
	.set	at
	lui	$3,%hi(key_map_mark)

	lw	$3,%lo(key_map_mark)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L161
	.set	at
	lui	$3,%hi(key_map_clearmark)

	lw	$3,%lo(key_map_clearmark)($3)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L145
	.set	at
	lui	$2,%hi(markpoints)

	addiu	$2,$2,%lo(markpoints)
	addiu	$4,$2,80
	li	$3,-1			# 0xffffffffffffffff
$L133:
	sw	$3,0($2)
	addiu	$2,$2,8
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L133
	.set	at
	nop

	lui	$2,%hi(plr)
	lw	$3,%lo(plr)($2)
	lui	$2,%hi(markpointnum)
	sw	$0,%lo(markpointnum)($2)
	lui	$2,%hi($LC7)
	addiu	$2,$2,%lo($LC7)
	sw	$2,224($3)
	b	$L117
	li	$17,1			# 0x1

$L115:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L111
	.set	at
	move	$2,$0

	lui	$3,%hi(key_map_east)
	lw	$2,4($4)
	lw	$3,%lo(key_map_east)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L137
	.set	at
	lui	$3,%hi(key_map_west)

	lw	$3,%lo(key_map_west)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L137
	.set	at
	lui	$3,%hi(key_map_north)

	lw	$3,%lo(key_map_north)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L139
	.set	at
	lui	$3,%hi(key_map_south)

	lw	$3,%lo(key_map_south)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L139
	.set	at
	lui	$3,%hi(key_map_zoomout)

	lw	$3,%lo(key_map_zoomout)($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L140
	.set	at
	lui	$3,%hi(key_map_zoomin)

	lw	$3,%lo(key_map_zoomin)($3)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L113
	.set	at
	nop

$L140:
	li	$2,65536			# 0x10000
	lui	$3,%hi(mtof_zoommul)
	sw	$2,%lo(mtof_zoommul)($3)
	lui	$3,%hi(ftom_zoommul)
	sw	$2,%lo(ftom_zoommul)($3)
	b	$L111
	move	$2,$0

$L151:
	lui	$2,%hi(followplayer)
	lw	$2,%lo(followplayer)($2)
	beq	$2,$0,$L162
	lui	$2,%hi(scale_ftom)

$L145:
	move	$17,$0
$L117:
	lui	$2,%hi(deathmatch)
$L163:
	lw	$2,%lo(deathmatch)($2)
	beq	$2,$0,$L134
	lui	$4,%hi(cheat_amap)

$L149:
	move	$2,$17
$L111:
	lw	$31,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	jr	$31
	addiu	$sp,$sp,64

$L134:
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_amap)

	beq	$2,$0,$L149
	lui	$5,%hi(cheating)

	lw	$3,%lo(cheating)($5)
	li	$2,1431633920			# 0x55550000
	addiu	$3,$3,1
	addiu	$2,$2,21846
	mult	$3,$2
	sra	$4,$3,31
	mfhi	$2
	subu	$2,$2,$4
	sll	$4,$2,1
	addu	$2,$4,$2
	subu	$3,$3,$2
	sw	$3,%lo(cheating)($5)
	b	$L111
	move	$2,$0

$L150:
	jal	AM_Start
	nop

	lui	$2,%hi(viewactive)
	sw	$0,%lo(viewactive)($2)
	b	$L111
	li	$2,1			# 0x1

$L152:
	lui	$2,%hi(followplayer)
	lw	$2,%lo(followplayer)($2)
	bne	$2,$0,$L145
	lui	$2,%hi(scale_ftom)

	lw	$5,%lo(scale_ftom)($2)
	jal	FixedMul
	li	$4,262144			# 0x40000

	subu	$2,$0,$2
	lui	$3,%hi(m_paninc)
	sw	$2,%lo(m_paninc)($3)
	b	$L117
	li	$17,1			# 0x1

$L162:
	lw	$5,%lo(scale_ftom)($2)
	jal	FixedMul
	li	$4,262144			# 0x40000

	lui	$3,%hi(m_paninc)
	sw	$2,%lo(m_paninc)($3)
	b	$L117
	li	$17,1			# 0x1

$L154:
	lui	$2,%hi(followplayer)
	lw	$2,%lo(followplayer)($2)
	bne	$2,$0,$L145
	lui	$2,%hi(scale_ftom)

	lw	$5,%lo(scale_ftom)($2)
	jal	FixedMul
	li	$4,262144			# 0x40000

	subu	$2,$0,$2
	lui	$3,%hi(m_paninc+4)
	sw	$2,%lo(m_paninc+4)($3)
	b	$L117
	li	$17,1			# 0x1

$L137:
	lui	$2,%hi(followplayer)
	lw	$2,%lo(followplayer)($2)
	bne	$2,$0,$L113
	nop

	lui	$2,%hi(m_paninc)
	sw	$0,%lo(m_paninc)($2)
	b	$L111
	move	$2,$0

$L153:
	lui	$2,%hi(followplayer)
	lw	$2,%lo(followplayer)($2)
	bne	$2,$0,$L145
	lui	$2,%hi(scale_ftom)

	lw	$5,%lo(scale_ftom)($2)
	jal	FixedMul
	li	$4,262144			# 0x40000

	lui	$3,%hi(m_paninc+4)
	sw	$2,%lo(m_paninc+4)($3)
	b	$L117
	li	$17,1			# 0x1

$L139:
	lui	$2,%hi(followplayer)
	lw	$2,%lo(followplayer)($2)
	bne	$2,$0,$L113
	nop

	lui	$2,%hi(m_paninc+4)
	sw	$0,%lo(m_paninc+4)($2)
	b	$L111
	move	$2,$0

$L155:
	li	$2,64250			# 0xfafa
	lui	$4,%hi(mtof_zoommul)
	addiu	$3,$2,2596
	sw	$2,%lo(mtof_zoommul)($4)
	lui	$2,%hi(ftom_zoommul)
	sw	$3,%lo(ftom_zoommul)($2)
	b	$L117
	li	$17,1			# 0x1

$L156:
	li	$2,65536			# 0x10000
	lui	$3,%hi(mtof_zoommul)
	addiu	$2,$2,1310
	sw	$2,%lo(mtof_zoommul)($3)
	lui	$2,%hi(ftom_zoommul)
	li	$3,64250			# 0xfafa
	sw	$3,%lo(ftom_zoommul)($2)
	b	$L117
	li	$17,1			# 0x1

$L158:
	lui	$3,%hi(bigstate.8)
	lw	$2,%lo(bigstate.8)($3)
	sltu	$4,$2,1
	bne	$2,$0,$L127
	sw	$4,%lo(bigstate.8)($3)

	lui	$2,%hi(min_scale_mtof)
	lw	$5,%lo(min_scale_mtof)($2)
	lui	$2,%hi(m_x)
	lw	$8,%lo(m_x)($2)
	lui	$2,%hi(m_y)
	lw	$7,%lo(m_y)($2)
	lui	$2,%hi(m_w)
	lw	$6,%lo(m_w)($2)
	lui	$2,%hi(m_h)
	lw	$3,%lo(m_h)($2)
	lui	$2,%hi(old_m_x)
	sw	$8,%lo(old_m_x)($2)
	lui	$2,%hi(old_m_y)
	sw	$7,%lo(old_m_y)($2)
	lui	$2,%hi(old_m_w)
	sw	$6,%lo(old_m_w)($2)
	lui	$2,%hi(old_m_h)
	sw	$3,%lo(old_m_h)($2)
	li	$4,65536			# 0x10000
	lui	$2,%hi(scale_mtof)
	jal	FixedDiv
	sw	$5,%lo(scale_mtof)($2)

	lui	$3,%hi(scale_ftom)
	sw	$2,%lo(scale_ftom)($3)
	jal	AM_activateNewScale
	li	$17,1			# 0x1

	b	$L163
	lui	$2,%hi(deathmatch)

$L157:
	lui	$2,%hi(bigstate.8)
	sw	$0,%lo(bigstate.8)($2)
	li	$3,1			# 0x1
	lui	$2,%hi(viewactive)
	lui	$19,%hi($LC0)
	sw	$3,%lo(viewactive)($2)
	move	$18,$0
	addiu	$19,$19,%lo($LC0)
	li	$20,10			# 0xa
	move	$7,$18
$L164:
	addiu	$4,$sp,24
	move	$6,$19
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$18,$18,1
	jal	W_ReleaseLumpName
	addiu	$4,$sp,24

	.set	noat
	xor	$1,$18,$20
	bne	$1,$0,$L164
	.set	at
	move	$7,$18

	lui	$4,%hi(st_notify.11)
	addiu	$4,$4,%lo(st_notify.11)
	jal	ST_Responder
	sw	$0,%lo(automapactive)($17)

	lui	$2,%hi(stopped)
	li	$3,1			# 0x1
	sw	$3,%lo(stopped)($2)
	b	$L117
	li	$17,1			# 0x1

$L159:
	lui	$2,%hi(followplayer)
	lw	$3,%lo(followplayer)($2)
	lui	$5,%hi(plr)
	sltu	$4,$3,1
	sw	$4,%lo(followplayer)($2)
	li	$2,2147418112			# 0x7fff0000
	lui	$4,%hi(f_oldloc)
	ori	$2,$2,0xffff
	lw	$5,%lo(plr)($5)
	bne	$3,$0,$L129
	sw	$2,%lo(f_oldloc)($4)

	lui	$2,%hi($LC1)
	addiu	$2,$2,%lo($LC1)
	sw	$2,224($5)
	b	$L117
	li	$17,1			# 0x1

$L127:
	jal	AM_restoreScaleAndLoc
	li	$17,1			# 0x1

	b	$L163
	lui	$2,%hi(deathmatch)

$L160:
	lui	$3,%hi(grid)
	lw	$2,%lo(grid)($3)
	lui	$4,%hi(plr)
	sltu	$5,$2,1
	lw	$4,%lo(plr)($4)
	bne	$2,$0,$L131
	sw	$5,%lo(grid)($3)

	lui	$2,%hi($LC3)
	addiu	$2,$2,%lo($LC3)
	sw	$2,224($4)
	b	$L117
	li	$17,1			# 0x1

$L129:
	lui	$2,%hi($LC2)
	addiu	$2,$2,%lo($LC2)
	sw	$2,224($5)
	b	$L117
	li	$17,1			# 0x1

$L131:
	lui	$2,%hi($LC4)
	addiu	$2,$2,%lo($LC4)
	sw	$2,224($4)
	b	$L117
	li	$17,1			# 0x1

$L161:
	lui	$2,%hi(markpointnum)
	lw	$2,%lo(markpointnum)($2)
	lui	$17,%hi(buffer.7)
	lui	$7,%hi($LC5)
	lui	$6,%hi($LC6)
	addiu	$4,$17,%lo(buffer.7)
	addiu	$7,$7,%lo($LC5)
	addiu	$6,$6,%lo($LC6)
	li	$5,20			# 0x14
	jal	M_snprintf
	sw	$2,16($sp)

	lui	$2,%hi(plr)
	lw	$2,%lo(plr)($2)
	addiu	$17,$17,%lo(buffer.7)
	jal	AM_addMark
	sw	$17,224($2)

	b	$L117
	li	$17,1			# 0x1

	.set	macro
	.set	reorder
	.end	AM_Responder
	.size	AM_Responder, .-AM_Responder
	.align	2
	.globl	AM_changeWindowScale
	.set	nomips16
	.set	nomicromips
	.ent	AM_changeWindowScale
	.type	AM_changeWindowScale, @function
AM_changeWindowScale:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(mtof_zoommul)
	sw	$16,20($sp)
	lui	$16,%hi(scale_mtof)
	lw	$5,%lo(mtof_zoommul)($2)
	lw	$4,%lo(scale_mtof)($16)
	sw	$31,28($sp)
	jal	FixedMul
	sw	$17,24($sp)

	move	$5,$2
	li	$4,65536			# 0x10000
	jal	FixedDiv
	sw	$2,%lo(scale_mtof)($16)

	lui	$4,%hi(min_scale_mtof)
	lw	$3,%lo(scale_mtof)($16)
	lw	$5,%lo(min_scale_mtof)($4)
	lui	$17,%hi(scale_ftom)
	slt	$4,$3,$5
	bne	$4,$0,$L169
	sw	$2,%lo(scale_ftom)($17)

	lui	$2,%hi(max_scale_mtof)
	lw	$5,%lo(max_scale_mtof)($2)
	slt	$3,$5,$3
	beq	$3,$0,$L170
	lw	$31,28($sp)

$L169:
	li	$4,65536			# 0x10000
	jal	FixedDiv
	sw	$5,%lo(scale_mtof)($16)

	sw	$2,%lo(scale_ftom)($17)
	lw	$31,28($sp)
$L170:
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	AM_activateNewScale
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	AM_changeWindowScale
	.size	AM_changeWindowScale, .-AM_changeWindowScale
	.align	2
	.globl	AM_doFollowPlayer
	.set	nomips16
	.set	nomicromips
	.ent	AM_doFollowPlayer
	.type	AM_doFollowPlayer, @function
AM_doFollowPlayer:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,20($sp)
	lui	$17,%hi(plr)
	lw	$2,%lo(plr)($17)
	sw	$16,16($sp)
	lw	$2,0($2)
	lui	$16,%hi(f_oldloc)
	lw	$3,%lo(f_oldloc)($16)
	lw	$4,12($2)
	sw	$20,32($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L172
	.set	at
	addiu	$20,$16,%lo(f_oldloc)

	lw	$3,4($20)
	lw	$2,16($2)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L177
	.set	at
	lw	$31,44($sp)

$L172:
	lui	$19,%hi(scale_mtof)
	lw	$5,%lo(scale_mtof)($19)
	jal	FixedMul
	lui	$22,%hi(scale_ftom)

	li	$21,-65536			# 0xffffffffffff0000
	lw	$5,%lo(scale_ftom)($22)
	and	$4,$2,$21
	jal	FixedMul
	lui	$18,%hi(m_w)

	lw	$4,%lo(m_w)($18)
	lw	$5,%lo(plr)($17)
	srl	$3,$4,31
	lw	$6,0($5)
	addu	$3,$3,$4
	sra	$3,$3,1
	lw	$4,16($6)
	lw	$5,%lo(scale_mtof)($19)
	subu	$2,$2,$3
	lui	$19,%hi(m_x)
	jal	FixedMul
	sw	$2,%lo(m_x)($19)

	lw	$5,%lo(scale_ftom)($22)
	jal	FixedMul
	and	$4,$2,$21

	lui	$3,%hi(m_h)
	lw	$3,%lo(m_h)($3)
	lw	$5,%lo(plr)($17)
	srl	$4,$3,31
	lw	$6,0($5)
	lw	$7,%lo(m_w)($18)
	addu	$4,$4,$3
	lw	$5,%lo(m_x)($19)
	sra	$4,$4,1
	subu	$2,$2,$4
	addu	$5,$5,$7
	lui	$7,%hi(m_y)
	lw	$4,16($6)
	addu	$3,$3,$2
	lw	$6,12($6)
	sw	$2,%lo(m_y)($7)
	lui	$2,%hi(m_x2)
	sw	$5,%lo(m_x2)($2)
	lui	$2,%hi(m_y2)
	sw	$3,%lo(m_y2)($2)
	sw	$6,%lo(f_oldloc)($16)
	sw	$4,4($20)
	lw	$31,44($sp)
$L177:
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	AM_doFollowPlayer
	.size	AM_doFollowPlayer, .-AM_doFollowPlayer
	.align	2
	.globl	AM_updateLightLev
	.set	nomips16
	.set	nomicromips
	.ent	AM_updateLightLev
	.type	AM_updateLightLev, @function
AM_updateLightLev:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(amclock)
	lui	$4,%hi(nexttic.6)
	lw	$3,%lo(amclock)($2)
	lw	$2,%lo(nexttic.6)($4)
	slt	$2,$2,$3
	beq	$2,$0,$L182
	lui	$7,%hi(litelevelscnt.5)

	lw	$2,%lo(litelevelscnt.5)($7)
	lui	$6,%hi(litelevels.4)
	sll	$5,$2,2
	addiu	$6,$6,%lo(litelevels.4)
	addu	$5,$5,$6
	lw	$8,0($5)
	addiu	$2,$2,1
	lui	$6,%hi(lightlev)
	li	$5,8			# 0x8
	sw	$2,%lo(litelevelscnt.5)($7)
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L181
	.set	at
	sw	$8,%lo(lightlev)($6)

	li	$2,715784192			# 0x2aaa0000
	ori	$2,$2,0xaaab
	mult	$3,$2
	sra	$3,$3,31
	mfhi	$2
	subu	$2,$2,$3
	sll	$3,$2,1
	addu	$2,$3,$2
	sll	$2,$2,1
	addiu	$2,$2,6
	sw	$2,%lo(nexttic.6)($4)
$L182:
	jr	$31
	nop

$L181:
	li	$2,715784192			# 0x2aaa0000
	ori	$2,$2,0xaaab
	mult	$3,$2
	sra	$3,$3,31
	mfhi	$2
	sw	$0,%lo(litelevelscnt.5)($7)
	subu	$2,$2,$3
	sll	$3,$2,1
	addu	$2,$3,$2
	sll	$2,$2,1
	addiu	$2,$2,6
	jr	$31
	sw	$2,%lo(nexttic.6)($4)

	.set	macro
	.set	reorder
	.end	AM_updateLightLev
	.size	AM_updateLightLev, .-AM_updateLightLev
	.align	2
	.globl	AM_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	AM_Ticker
	.type	AM_Ticker, @function
AM_Ticker:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(automapactive)
	lw	$2,%lo(automapactive)($2)
	beq	$2,$0,$L205
	nop

	lui	$3,%hi(amclock)
	lw	$2,%lo(amclock)($3)
	lui	$4,%hi(followplayer)
	lw	$4,%lo(followplayer)($4)
	addiu	$sp,$sp,-24
	addiu	$2,$2,1
	sw	$2,%lo(amclock)($3)
	bne	$4,$0,$L199
	sw	$31,20($sp)

	lui	$2,%hi(ftom_zoommul)
	lw	$3,%lo(ftom_zoommul)($2)
	li	$2,65536			# 0x10000
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L200
	.set	at
	lui	$2,%hi(m_paninc)

$L204:
	addiu	$3,$2,%lo(m_paninc)
	lw	$3,4($3)
	lw	$2,%lo(m_paninc)($2)
	or	$2,$2,$3
	beq	$2,$0,$L203
	lw	$31,20($sp)

$L202:
	j	AM_changeWindowLoc
	addiu	$sp,$sp,24

$L183:
$L203:
	jr	$31
	addiu	$sp,$sp,24

$L200:
	jal	AM_changeWindowScale
	nop

	lui	$2,%hi(m_paninc)
	addiu	$3,$2,%lo(m_paninc)
	lw	$3,4($3)
	lw	$2,%lo(m_paninc)($2)
	or	$2,$2,$3
	beq	$2,$0,$L183
	lw	$31,20($sp)

	b	$L202
	nop

$L199:
	jal	AM_doFollowPlayer
	nop

	lui	$2,%hi(ftom_zoommul)
	lw	$3,%lo(ftom_zoommul)($2)
	li	$2,65536			# 0x10000
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L204
	.set	at
	lui	$2,%hi(m_paninc)

	b	$L200
	nop

$L205:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	AM_Ticker
	.size	AM_Ticker, .-AM_Ticker
	.align	2
	.globl	AM_clearFB
	.set	nomips16
	.set	nomicromips
	.ent	AM_clearFB
	.type	AM_clearFB, @function
AM_clearFB:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(f_w)
	lw	$6,%lo(f_w)($2)
	lui	$2,%hi(f_h)
	lw	$2,%lo(f_h)($2)
	move	$5,$4
	multu	$6,$2
	mflo	$6
	lui	$2,%hi(fb)
	j	memset
	lw	$4,%lo(fb)($2)

	.set	macro
	.set	reorder
	.end	AM_clearFB
	.size	AM_clearFB, .-AM_clearFB
	.align	2
	.globl	AM_clipMline
	.set	nomips16
	.set	nomicromips
	.ent	AM_clipMline
	.type	AM_clipMline, @function
AM_clipMline:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(m_y2)
	lw	$3,%lo(m_y2)($2)
	lw	$6,4($4)
	addiu	$sp,$sp,-56
	sw	$17,20($sp)
	move	$17,$4
	slt	$4,$3,$6
	sw	$16,16($sp)
	lw	$2,12($17)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	beq	$4,$0,$L208
	move	$16,$5

	slt	$3,$3,$2
	bne	$3,$0,$L267
	lw	$31,52($sp)

	lui	$18,%hi(m_y)
	lw	$3,%lo(m_y)($18)
	li	$5,8			# 0x8
	slt	$2,$2,$3
	sll	$2,$2,2
$L212:
	lui	$22,%hi(m_x)
	lw	$4,0($17)
	lw	$3,%lo(m_x)($22)
	slt	$6,$4,$3
	beq	$6,$0,$L215
	lw	$7,8($17)

$L257:
	slt	$6,$7,$3
	beq	$6,$0,$L255
	lui	$6,%hi(m_x2)

$L214:
	lw	$31,52($sp)
$L267:
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,56

$L208:
	lui	$18,%hi(m_y)
	lw	$4,%lo(m_y)($18)
	slt	$6,$6,$4
	beq	$6,$0,$L211
	slt	$3,$3,$2

	bne	$3,$0,$L244
	slt	$4,$2,$4

	bne	$4,$0,$L267
	lw	$31,52($sp)

	move	$2,$0
	b	$L212
	li	$5,4			# 0x4

$L211:
	beq	$3,$0,$L256
	slt	$4,$2,$4

	lui	$22,%hi(m_x)
	lw	$4,0($17)
	lw	$3,%lo(m_x)($22)
	lw	$7,8($17)
	slt	$6,$4,$3
	li	$2,8			# 0x8
	bne	$6,$0,$L257
	move	$5,$0

$L215:
	lui	$6,%hi(m_x2)
	lw	$6,%lo(m_x2)($6)
	slt	$8,$6,$4
	beq	$8,$0,$L268
	slt	$8,$7,$3

	ori	$5,$5,0x2
$L268:
	beq	$8,$0,$L218
	nop

	ori	$2,$2,0x1
$L219:
	and	$2,$2,$5
	bne	$2,$0,$L214
	lui	$19,%hi(scale_mtof)

	lw	$5,%lo(scale_mtof)($19)
	subu	$4,$4,$3
	jal	FixedMul
	lui	$fp,%hi(f_x)

	lw	$6,%lo(f_x)($fp)
	lw	$4,4($17)
	lw	$3,%lo(m_y)($18)
	sra	$2,$2,16
	addu	$2,$2,$6
	lw	$5,%lo(scale_mtof)($19)
	subu	$4,$4,$3
	lui	$21,%hi(f_h)
	sw	$2,0($16)
	lw	$20,%lo(f_h)($21)
	jal	FixedMul
	lui	$23,%hi(f_y)

	sra	$2,$2,16
	lw	$6,%lo(f_y)($23)
	lw	$4,8($17)
	lw	$3,%lo(m_x)($22)
	subu	$20,$20,$2
	addu	$20,$20,$6
	lw	$5,%lo(scale_mtof)($19)
	subu	$4,$4,$3
	jal	FixedMul
	sw	$20,4($16)

	lw	$5,%lo(f_x)($fp)
	lw	$4,12($17)
	lw	$3,%lo(m_y)($18)
	sra	$2,$2,16
	addu	$2,$2,$5
	lw	$5,%lo(scale_mtof)($19)
	subu	$4,$4,$3
	sw	$2,8($16)
	jal	FixedMul
	lw	$17,%lo(f_h)($21)

	sra	$2,$2,16
	lw	$4,%lo(f_y)($23)
	subu	$3,$17,$2
	lw	$2,4($16)
	addu	$3,$3,$4
	bltz	$2,$L246
	sw	$3,12($16)

	lw	$4,%lo(f_h)($21)
	slt	$2,$2,$4
	lw	$4,0($16)
	xori	$2,$2,0x1
	bltz	$4,$L258
	sll	$2,$2,2

$L221:
	lui	$5,%hi(f_w)
	lw	$5,%lo(f_w)($5)
	slt	$4,$4,$5
	bne	$4,$0,$L222
	nop

	ori	$2,$2,0x2
$L222:
	bltz	$3,$L247
	nop

$L264:
	lw	$4,%lo(f_h)($21)
	slt	$3,$3,$4
	lw	$4,8($16)
	xori	$3,$3,0x1
	bltz	$4,$L259
	sll	$3,$3,2

$L224:
	lui	$5,%hi(f_w)
	lw	$5,%lo(f_w)($5)
	slt	$4,$4,$5
	bne	$4,$0,$L269
	and	$4,$2,$3

	ori	$3,$3,0x2
$L225:
	and	$4,$2,$3
$L269:
	bne	$4,$0,$L214
	lw	$6,%lo(f_h)($21)

	lui	$4,%hi(f_w)
	lw	$7,%lo(f_w)($4)
	addiu	$9,$7,-1
	b	$L226
	addiu	$8,$6,-1

$L262:
	beq	$4,$0,$L248
	move	$13,$0

	lw	$5,0($16)
	lw	$3,8($16)
	lw	$4,4($16)
	subu	$3,$3,$5
	multu	$3,$4
	mflo	$3
	lw	$10,12($16)
	subu	$4,$4,$10
	div	$0,$3,$4
	sw	$0,12($16)
	mflo	$4
	addu	$4,$4,$5
	sw	$4,8($16)
$L229:
	slt	$3,$13,$6
	xori	$3,$3,0x1
	bltz	$4,$L260
	sll	$3,$3,2

$L236:
	slt	$4,$4,$7
	bne	$4,$0,$L270
	and	$4,$2,$3

	ori	$3,$3,0x2
$L239:
	and	$4,$2,$3
$L270:
	bne	$4,$0,$L267
	lw	$31,52($sp)

$L226:
	or	$4,$2,$3
	beq	$4,$0,$L261
	lw	$31,52($sp)

	beq	$2,$0,$L262
	andi	$4,$3,0x8

	andi	$4,$2,0x8
	bne	$4,$0,$L243
	move	$11,$2

$L228:
	andi	$4,$11,0x4
	beq	$4,$0,$L230
	move	$13,$8

	lw	$5,4($16)
	lw	$10,0($16)
	lw	$4,8($16)
	subu	$12,$5,$6
	subu	$4,$4,$10
	multu	$4,$12
	mflo	$4
	lw	$12,12($16)
	subu	$5,$5,$12
	div	$0,$4,$5
	mflo	$4
	.set	noat
	xor	$1,$2,$11
	beq	$1,$0,$L263
	.set	at
	addu	$4,$4,$10

$L237:
	sw	$4,8($16)
	bgez	$13,$L229
	sw	$13,12($16)

	bgez	$4,$L236
	li	$3,8			# 0x8

$L260:
	b	$L239
	ori	$3,$3,0x1

$L255:
	lw	$6,%lo(m_x2)($6)
	ori	$5,$5,0x1
$L218:
	slt	$6,$6,$7
	beq	$6,$0,$L219
	nop

	b	$L219
	ori	$2,$2,0x2

$L246:
	lw	$4,0($16)
	bgez	$4,$L221
	li	$2,8			# 0x8

$L258:
	bgez	$3,$L264
	ori	$2,$2,0x1

$L247:
	lw	$4,8($16)
	bgez	$4,$L224
	li	$3,8			# 0x8

$L259:
	b	$L225
	ori	$3,$3,0x1

$L244:
	li	$2,8			# 0x8
	b	$L212
	li	$5,4			# 0x4

$L256:
	sll	$2,$4,2
	b	$L212
	move	$5,$0

$L230:
	andi	$4,$11,0x2
	beq	$4,$0,$L232
	andi	$5,$11,0x1

	lw	$12,4($16)
	lw	$13,0($16)
	lw	$5,12($16)
	subu	$4,$9,$13
	subu	$5,$5,$12
	lw	$10,8($16)
	multu	$5,$4
	mflo	$5
	move	$4,$9
$L254:
	subu	$10,$10,$13
	div	$0,$5,$10
	mflo	$13
	.set	noat
	xor	$1,$2,$11
	bne	$1,$0,$L237
	.set	at
	addu	$13,$13,$12

$L263:
	sw	$4,0($16)
	bgez	$13,$L242
	sw	$13,4($16)

	bgez	$4,$L235
	li	$2,8			# 0x8

$L265:
	b	$L239
	ori	$2,$2,0x1

$L243:
	lw	$5,0($16)
	lw	$2,8($16)
	lw	$4,4($16)
	subu	$2,$2,$5
	multu	$2,$4
	mflo	$2
	lw	$10,12($16)
	sw	$0,4($16)
	subu	$4,$4,$10
	div	$0,$2,$4
	move	$13,$0
	mflo	$4
	addu	$4,$4,$5
	sw	$4,0($16)
$L242:
	slt	$2,$13,$6
	xori	$2,$2,0x1
	bltz	$4,$L265
	sll	$2,$2,2

$L235:
	slt	$4,$4,$7
	bne	$4,$0,$L270
	and	$4,$2,$3

	b	$L239
	ori	$2,$2,0x2

$L248:
	b	$L228
	move	$11,$3

$L232:
	bne	$5,$0,$L233
	nop

	slt	$5,$6,1
	.set	noat
	xor	$1,$2,$11
	beq	$1,$0,$L266
	.set	at
	sll	$5,$5,2

	sw	$0,8($16)
	sw	$0,12($16)
	b	$L236
	move	$3,$5

$L233:
	lw	$12,4($16)
	lw	$5,12($16)
	lw	$13,0($16)
	subu	$5,$12,$5
	multu	$5,$13
	mflo	$5
	b	$L254
	lw	$10,8($16)

$L261:
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,56

$L266:
	sw	$0,0($16)
	sw	$0,4($16)
	b	$L235
	move	$2,$5

	.set	macro
	.set	reorder
	.end	AM_clipMline
	.size	AM_clipMline, .-AM_clipMline
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"fuck %d \015\000"
	.text
	.align	2
	.globl	AM_drawFline
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawFline
	.type	AM_drawFline, @function
AM_drawFline:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	bltz	$2,$L272
	lui	$3,%hi(f_w)

	lw	$3,%lo(f_w)($3)
	slt	$6,$2,$3
	beq	$6,$0,$L272
	nop

	lw	$6,4($4)
	bltz	$6,$L272
	nop

	lui	$7,%hi(f_h)
	lw	$8,%lo(f_h)($7)
	slt	$7,$6,$8
	beq	$7,$0,$L272
	nop

	lw	$7,8($4)
	bltz	$7,$L272
	slt	$9,$7,$3

	beq	$9,$0,$L272
	nop

	lw	$9,12($4)
	bltz	$9,$L272
	slt	$8,$9,$8

	beq	$8,$0,$L272
	nop

	subu	$7,$7,$2
	bltz	$7,$L288
	move	$8,$7

$L274:
	li	$10,-1			# 0xffffffffffffffff
	slt	$7,$7,0
	subu	$9,$9,$6
	li	$13,1			# 0x1
	movn	$13,$10,$7
	sll	$14,$8,1
	bltz	$9,$L289
	move	$10,$9

$L276:
	multu	$3,$6
	mflo	$15
	lui	$7,%hi(fb)
	lw	$11,%lo(fb)($7)
	addu	$7,$15,$2
	slt	$9,$9,0
	slt	$8,$10,$8
	li	$12,1			# 0x1
	li	$24,-1			# 0xffffffffffffffff
	addu	$7,$11,$7
	andi	$5,$5,0x00ff
	sll	$10,$10,1
	movn	$12,$24,$9
	bne	$8,$0,$L290
	sb	$5,0($7)

	lw	$8,12($4)
	sra	$7,$10,1
	.set	noat
	xor	$1,$6,$8
	beq	$1,$0,$L294
	.set	at
	subu	$7,$14,$7

	addu	$6,$6,$12
	multu	$3,$12
	mflo	$9
	b	$L284
	multu	$6,$3
	mflo	$3

$L291:
	addu	$6,$6,$12
$L284:
	bltz	$7,$L292
	addu	$8,$11,$2

	addu	$2,$2,$13
	subu	$7,$7,$10
	addu	$8,$11,$2
$L292:
	addu	$8,$8,$3
	sb	$5,0($8)
	lw	$8,12($4)
	addu	$7,$7,$14
	.set	noat
	xor	$1,$6,$8
	bne	$1,$0,$L291
	.set	at
	addu	$3,$3,$9

$L294:
	jr	$31
	nop

$L272:
	lui	$2,%hi(fuck.3)
	lw	$6,%lo(fuck.3)($2)
	lui	$3,%hi(stderr)
	lw	$4,%lo(stderr)($3)
	lui	$5,%hi($LC8)
	addiu	$3,$6,1
	addiu	$5,$5,%lo($LC8)
	j	fprintf
	sw	$3,%lo(fuck.3)($2)

$L290:
	lw	$8,8($4)
	sra	$7,$14,1
	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L294
	.set	at
	subu	$7,$10,$7

$L279:
	addu	$2,$2,$13
	bltz	$7,$L281
	addu	$8,$11,$2

	addu	$6,$6,$12
	multu	$3,$6
	mflo	$15
	subu	$7,$7,$14
$L281:
	addu	$8,$8,$15
	sb	$5,0($8)
	lw	$8,8($4)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L279
	.set	at
	addu	$7,$7,$10

	jr	$31
	nop

$L289:
	b	$L276
	subu	$10,$0,$9

$L288:
	b	$L274
	subu	$8,$0,$7

	.set	macro
	.set	reorder
	.end	AM_drawFline
	.size	AM_drawFline, .-AM_drawFline
	.align	2
	.globl	AM_drawMline
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawMline
	.type	AM_drawMline, @function
AM_drawMline:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lui	$17,%hi(fl.2)
	sw	$16,20($sp)
	move	$16,$5
	sw	$31,28($sp)
	jal	AM_clipMline
	addiu	$5,$17,%lo(fl.2)

	bne	$2,$0,$L298
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L298:
	move	$5,$16
	addiu	$4,$17,%lo(fl.2)
	lw	$16,20($sp)
	lw	$17,24($sp)
	j	AM_drawFline
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	AM_drawMline
	.size	AM_drawMline, .-AM_drawMline
	.align	2
	.globl	AM_drawGrid
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawGrid
	.type	AM_drawGrid, @function
AM_drawGrid:
	.frame	$sp,80,$31		# vars= 24, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	lui	$2,%hi(bmaporgx)
	sw	$22,64($sp)
	lui	$22,%hi(m_x)
	lw	$3,%lo(m_x)($22)
	lw	$2,%lo(bmaporgx)($2)
	li	$5,8323072			# 0x7f0000
	subu	$2,$3,$2
	ori	$5,$5,0xffff
	and	$5,$2,$5
	sw	$20,56($sp)
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$21,60($sp)
	sw	$19,52($sp)
	sw	$18,48($sp)
	sw	$17,44($sp)
	sw	$16,40($sp)
	beq	$5,$0,$L310
	move	$20,$4

	li	$4,-2139160576			# 0xffffffff807f0000
	ori	$4,$4,0xffff
	and	$2,$2,$4
	bltz	$2,$L324
	li	$4,-8388608			# 0xffffffffff800000

$L301:
	li	$17,8388608			# 0x800000
	subu	$17,$17,$2
	addu	$17,$17,$3
$L300:
	lui	$23,%hi(m_w)
	lui	$2,%hi(m_h)
	lw	$19,%lo(m_w)($23)
	lui	$fp,%hi(m_y)
	lw	$16,%lo(m_y)($fp)
	lw	$18,%lo(m_h)($2)
	addu	$19,$3,$19
	sw	$2,32($sp)
	addu	$18,$16,$18
	slt	$2,$17,$19
	sw	$16,20($sp)
	beq	$2,$0,$L302
	sw	$18,28($sp)

	lui	$2,%hi(fl.2)
	addiu	$21,$sp,16
	addiu	$16,$2,%lo(fl.2)
	b	$L304
	li	$18,8388608			# 0x800000

$L303:
	beq	$2,$0,$L327
	lw	$2,32($sp)

$L304:
	move	$5,$16
$L328:
	move	$4,$21
	sw	$17,16($sp)
	sw	$17,24($sp)
	jal	AM_clipMline
	addu	$17,$17,$18

	beq	$2,$0,$L303
	slt	$2,$17,$19

	move	$5,$20
	jal	AM_drawFline
	move	$4,$16

	slt	$2,$17,$19
	bne	$2,$0,$L328
	move	$5,$16

	lw	$2,32($sp)
$L327:
	lw	$16,%lo(m_y)($fp)
	lw	$3,%lo(m_x)($22)
	lw	$19,%lo(m_w)($23)
	lw	$18,%lo(m_h)($2)
	addu	$19,$3,$19
	addu	$18,$16,$18
$L302:
	lui	$2,%hi(bmaporgy)
	lw	$2,%lo(bmaporgy)($2)
	li	$4,8323072			# 0x7f0000
	subu	$2,$16,$2
	ori	$4,$4,0xffff
	and	$4,$2,$4
	beq	$4,$0,$L305
	li	$4,-2139160576			# 0xffffffff807f0000

	ori	$4,$4,0xffff
	and	$2,$2,$4
	bltz	$2,$L326
	li	$4,-8388608			# 0xffffffffff800000

$L306:
	li	$4,8388608			# 0x800000
	subu	$2,$4,$2
	addu	$16,$16,$2
$L305:
	slt	$2,$16,$18
	sw	$3,16($sp)
	beq	$2,$0,$L299
	sw	$19,24($sp)

	lui	$2,%hi(fl.2)
	addiu	$21,$sp,16
	addiu	$17,$2,%lo(fl.2)
	b	$L307
	li	$19,8388608			# 0x800000

$L308:
	beq	$2,$0,$L329
	lw	$31,76($sp)

$L307:
	move	$5,$17
$L330:
	move	$4,$21
	sw	$16,20($sp)
	sw	$16,28($sp)
	jal	AM_clipMline
	addu	$16,$16,$19

	beq	$2,$0,$L308
	slt	$2,$16,$18

	move	$5,$20
	jal	AM_drawFline
	move	$4,$17

	slt	$2,$16,$18
	bne	$2,$0,$L330
	move	$5,$17

$L299:
	lw	$31,76($sp)
$L329:
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$22,64($sp)
	lw	$21,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	jr	$31
	addiu	$sp,$sp,80

$L310:
	b	$L300
	move	$17,$3

$L326:
	addiu	$2,$2,-1
	or	$2,$2,$4
	b	$L306
	addiu	$2,$2,1

$L324:
	addiu	$2,$2,-1
	or	$2,$2,$4
	b	$L301
	addiu	$2,$2,1

	.set	macro
	.set	reorder
	.end	AM_drawGrid
	.size	AM_drawGrid, .-AM_drawGrid
	.align	2
	.globl	AM_drawWalls
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawWalls
	.type	AM_drawWalls, @function
AM_drawWalls:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$17,28($sp)
	lui	$17,%hi(numlines)
	lw	$2,%lo(numlines)($17)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	blez	$2,$L331
	sw	$16,24($sp)

	lui	$22,%hi(l.1)
	lui	$2,%hi(lightlev)
	move	$16,$0
	lui	$19,%hi(lines)
	addiu	$23,$22,%lo(l.1)
	lui	$18,%hi(cheating)
	li	$20,39			# 0x27
	sw	$2,16($sp)
	b	$L332
	lui	$21,%hi(plr)

$L385:
	andi	$5,$3,0x80
	bne	$5,$0,$L335
	nop

$L333:
	lw	$5,52($2)
	beq	$5,$0,$L382
	lui	$fp,%hi(fl.2)

	lh	$7,18($2)
	.set	noat
	xor	$1,$7,$20
	beq	$1,$0,$L390
	.set	at
	andi	$3,$3,0x20

	beq	$3,$0,$L339
	lui	$3,%hi(fl.2)

	lw	$2,16($sp)
	lw	$fp,%lo(lightlev)($2)
	addiu	$5,$3,%lo(fl.2)
	addiu	$4,$22,%lo(l.1)
	jal	AM_clipMline
	sw	$3,20($sp)

	addiu	$fp,$fp,176
	bne	$2,$0,$L384
	lw	$3,20($sp)

$L335:
	lw	$2,%lo(numlines)($17)
$L387:
	addiu	$16,$16,1
	slt	$2,$16,$2
	beq	$2,$0,$L388
	lw	$31,60($sp)

$L332:
	lw	$2,%lo(lines)($19)
$L389:
	sll	$3,$16,6
	addu	$2,$2,$3
	lw	$4,0($2)
	lw	$3,4($2)
	lw	$5,0($4)
	lw	$4,4($4)
	sw	$5,%lo(l.1)($22)
	sw	$4,4($23)
	lw	$7,0($3)
	lw	$5,4($3)
	lw	$4,%lo(cheating)($18)
	lh	$3,16($2)
	sw	$7,8($23)
	bne	$4,$0,$L333
	sw	$5,12($23)

	andi	$5,$3,0x100
	bne	$5,$0,$L385
	nop

	lw	$2,%lo(plr)($21)
	lw	$2,68($2)
	beq	$2,$0,$L387
	lw	$2,%lo(numlines)($17)

	andi	$3,$3,0x80
	bne	$3,$0,$L387
	nop

	lui	$fp,%hi(fl.2)
	addiu	$5,$fp,%lo(fl.2)
	jal	AM_clipMline
	move	$4,$23

	beq	$2,$0,$L387
	lw	$2,%lo(numlines)($17)

	li	$5,99			# 0x63
	jal	AM_drawFline
	addiu	$4,$fp,%lo(fl.2)

	lw	$2,%lo(numlines)($17)
	addiu	$16,$16,1
	slt	$2,$16,$2
	bne	$2,$0,$L389
	lw	$2,%lo(lines)($19)

$L331:
	lw	$31,60($sp)
$L388:
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L339:
	lw	$2,48($2)
	lw	$7,0($5)
	lw	$3,0($2)
	.set	noat
	xor	$1,$7,$3
	beq	$1,$0,$L341
	.set	at
	lui	$fp,%hi(fl.2)

	lui	$2,%hi(lightlev)
	lw	$2,%lo(lightlev)($2)
	addiu	$5,$fp,%lo(fl.2)
	addiu	$4,$22,%lo(l.1)
	jal	AM_clipMline
	sw	$2,20($sp)

	beq	$2,$0,$L335
	lw	$2,20($sp)

	addiu	$4,$fp,%lo(fl.2)
	jal	AM_drawFline
	addiu	$5,$2,64

	b	$L387
	lw	$2,%lo(numlines)($17)

$L382:
	lui	$2,%hi(lightlev)
	lw	$2,%lo(lightlev)($2)
	addiu	$5,$fp,%lo(fl.2)
	addiu	$4,$22,%lo(l.1)
	jal	AM_clipMline
	sw	$2,20($sp)

	beq	$2,$0,$L335
	lw	$2,20($sp)

	addiu	$4,$fp,%lo(fl.2)
	jal	AM_drawFline
	addiu	$5,$2,176

	b	$L387
	lw	$2,%lo(numlines)($17)

$L341:
	lw	$3,4($5)
	lw	$2,4($2)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L386
	.set	at
	lui	$2,%hi(lightlev)

	beq	$4,$0,$L387
	lw	$2,%lo(numlines)($17)

	lui	$2,%hi(lightlev)
	lw	$2,%lo(lightlev)($2)
	lui	$fp,%hi(fl.2)
	addiu	$5,$fp,%lo(fl.2)
	addiu	$4,$22,%lo(l.1)
	jal	AM_clipMline
	sw	$2,20($sp)

	beq	$2,$0,$L335
	lw	$2,20($sp)

	addiu	$4,$fp,%lo(fl.2)
	jal	AM_drawFline
	addiu	$5,$2,96

	b	$L387
	lw	$2,%lo(numlines)($17)

$L390:
	addiu	$5,$fp,%lo(fl.2)
	jal	AM_clipMline
	addiu	$4,$22,%lo(l.1)

	beq	$2,$0,$L335
	li	$5,184			# 0xb8

	jal	AM_drawFline
	addiu	$4,$fp,%lo(fl.2)

	b	$L387
	lw	$2,%lo(numlines)($17)

$L384:
	move	$5,$fp
	jal	AM_drawFline
	addiu	$4,$3,%lo(fl.2)

	b	$L387
	lw	$2,%lo(numlines)($17)

$L386:
	lw	$2,%lo(lightlev)($2)
	lui	$fp,%hi(fl.2)
	addiu	$5,$fp,%lo(fl.2)
	addiu	$4,$22,%lo(l.1)
	jal	AM_clipMline
	sw	$2,20($sp)

	beq	$2,$0,$L335
	lw	$2,20($sp)

	addiu	$4,$fp,%lo(fl.2)
	jal	AM_drawFline
	addiu	$5,$2,231

	b	$L387
	lw	$2,%lo(numlines)($17)

	.set	macro
	.set	reorder
	.end	AM_drawWalls
	.size	AM_drawWalls, .-AM_drawWalls
	.align	2
	.globl	AM_rotate
	.set	nomips16
	.set	nomicromips
	.ent	AM_rotate
	.type	AM_rotate, @function
AM_rotate:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$20,36($sp)
	lui	$20,%hi(finecosine)
	sw	$16,20($sp)
	lw	$2,%lo(finecosine)($20)
	srl	$16,$6,19
	sll	$16,$16,2
	addu	$2,$2,$16
	sw	$19,32($sp)
	sw	$17,24($sp)
	move	$19,$5
	move	$17,$4
	lw	$5,0($2)
	lw	$4,0($4)
	sw	$31,44($sp)
	sw	$21,40($sp)
	jal	FixedMul
	sw	$18,28($sp)

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$3,$16,$3
	lw	$21,0($3)
	lw	$4,0($19)
	move	$5,$21
	jal	FixedMul
	move	$18,$2

	lw	$4,0($17)
	move	$5,$21
	jal	FixedMul
	subu	$18,$18,$2

	lw	$3,%lo(finecosine)($20)
	lw	$4,0($19)
	addu	$3,$3,$16
	lw	$5,0($3)
	jal	FixedMul
	move	$16,$2

	lw	$31,44($sp)
	addu	$16,$16,$2
	sw	$16,0($19)
	lw	$21,40($sp)
	sw	$18,0($17)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	AM_rotate
	.size	AM_rotate, .-AM_rotate
	.align	2
	.globl	AM_drawLineCharacter
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawLineCharacter
	.type	AM_drawLineCharacter, @function
AM_drawLineCharacter:
	.frame	$sp,80,$31		# vars= 24, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	sw	$19,52($sp)
	sw	$18,48($sp)
	lw	$19,104($sp)
	lw	$18,100($sp)
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$22,64($sp)
	sw	$21,60($sp)
	sw	$20,56($sp)
	sw	$17,44($sp)
	blez	$5,$L393
	sw	$16,40($sp)

	lui	$21,%hi(fl.2)
	move	$22,$5
	move	$16,$6
	move	$20,$7
	move	$23,$4
	move	$17,$0
	b	$L398
	addiu	$21,$21,%lo(fl.2)

$L395:
	bne	$20,$0,$L414
	move	$6,$20

$L396:
	lw	$4,16($sp)
	lw	$2,20($sp)
	lw	$6,8($23)
	lw	$fp,12($23)
	addu	$4,$4,$18
	addu	$2,$2,$19
	sw	$4,16($sp)
	sw	$2,20($sp)
	sw	$6,24($sp)
	bne	$16,$0,$L415
	sw	$fp,28($sp)

$L400:
	addu	$6,$18,$6
	addu	$fp,$fp,$19
	move	$5,$21
	addiu	$4,$sp,16
	sw	$6,24($sp)
	jal	AM_clipMline
	sw	$fp,28($sp)

	bne	$2,$0,$L417
	lw	$5,96($sp)

$L397:
	addiu	$17,$17,1
	.set	noat
	xor	$1,$22,$17
	beq	$1,$0,$L393
	.set	at
	addiu	$23,$23,16

$L398:
	lw	$5,0($23)
	lw	$fp,4($23)
	sw	$5,16($sp)
	beq	$16,$0,$L395
	sw	$fp,20($sp)

	jal	FixedMul
	move	$4,$16

	move	$5,$fp
	move	$4,$16
	jal	FixedMul
	sw	$2,16($sp)

	beq	$20,$0,$L396
	sw	$2,20($sp)

	addiu	$4,$sp,16
	move	$6,$20
	jal	AM_rotate
	addiu	$5,$sp,20

	lw	$6,16($sp)
	lw	$2,20($sp)
	lw	$fp,12($23)
	lw	$5,8($23)
	move	$4,$16
	addu	$6,$6,$18
	addu	$2,$2,$19
	sw	$6,16($sp)
	jal	FixedMul
	sw	$2,20($sp)

	move	$5,$fp
	move	$4,$16
	jal	FixedMul
	sw	$2,24($sp)

$L401:
	move	$6,$20
	addiu	$5,$sp,28
	addiu	$4,$sp,24
	jal	AM_rotate
	sw	$2,28($sp)

	lw	$6,24($sp)
	lw	$fp,28($sp)
	addu	$6,$18,$6
	addu	$fp,$fp,$19
	move	$5,$21
	addiu	$4,$sp,16
	sw	$6,24($sp)
	jal	AM_clipMline
	sw	$fp,28($sp)

	beq	$2,$0,$L397
	lw	$5,96($sp)

$L417:
	move	$4,$21
	jal	AM_drawFline
	addiu	$17,$17,1

	.set	noat
	xor	$1,$22,$17
	bne	$1,$0,$L398
	.set	at
	addiu	$23,$23,16

$L393:
	lw	$31,76($sp)
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$22,64($sp)
	lw	$21,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	jr	$31
	addiu	$sp,$sp,80

$L415:
	move	$5,$6
	jal	FixedMul
	move	$4,$16

	move	$5,$fp
	move	$4,$16
	jal	FixedMul
	sw	$2,32($sp)

	move	$fp,$2
	b	$L400
	lw	$6,32($sp)

$L414:
	addiu	$5,$sp,20
	jal	AM_rotate
	addiu	$4,$sp,16

	lw	$5,16($sp)
	lw	$4,20($sp)
	lw	$6,8($23)
	addu	$5,$5,$18
	addu	$4,$4,$19
	lw	$2,12($23)
	sw	$5,16($sp)
	sw	$4,20($sp)
	b	$L401
	sw	$6,24($sp)

	.set	macro
	.set	reorder
	.end	AM_drawLineCharacter
	.size	AM_drawLineCharacter, .-AM_drawLineCharacter
	.align	2
	.globl	AM_drawPlayers
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawPlayers
	.type	AM_drawPlayers, @function
AM_drawPlayers:
	.frame	$sp,64,$31		# vars= 0, regs= 8/0, args= 32, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	addiu	$sp,$sp,-64
	sw	$31,60($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	beq	$2,$0,$L435
	sw	$16,32($sp)

	lui	$16,%hi(players)
	addiu	$16,$16,%lo(players)
	lui	$18,%hi(their_colors.0)
	lui	$17,%hi(playeringame)
	lui	$19,%hi(player_arrow)
	addiu	$18,$18,%lo(their_colors.0)
	addiu	$17,$17,%lo(playeringame)
	addiu	$22,$16,1152
	lui	$21,%hi(deathmatch)
	addiu	$19,$19,%lo(player_arrow)
	lui	$20,%hi(singledemo)
$L425:
	lw	$2,%lo(deathmatch)($21)
	beq	$2,$0,$L422
	lw	$2,%lo(singledemo)($20)

	bne	$2,$0,$L422
	lui	$2,%hi(plr)

	lw	$2,%lo(plr)($2)
	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L422
	.set	at
	nop

$L423:
	addiu	$16,$16,288
	addiu	$18,$18,4
	.set	noat
	xor	$1,$16,$22
	bne	$1,$0,$L425
	.set	at
	addiu	$17,$17,4

	lw	$31,60($sp)
$L436:
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,64

$L422:
	lw	$2,0($17)
	beq	$2,$0,$L423
	nop

	lw	$2,60($16)
	bne	$2,$0,$L424
	li	$3,246			# 0xf6

	lw	$3,0($18)
$L424:
	lw	$2,0($16)
	move	$6,$0
	lw	$4,16($2)
	lw	$7,32($2)
	sw	$4,24($sp)
	lw	$2,12($2)
	li	$5,7			# 0x7
	sw	$2,20($sp)
	sw	$3,16($sp)
	move	$4,$19
	jal	AM_drawLineCharacter
	addiu	$16,$16,288

	addiu	$18,$18,4
	.set	noat
	xor	$1,$16,$22
	bne	$1,$0,$L425
	.set	at
	addiu	$17,$17,4

	b	$L436
	lw	$31,60($sp)

$L435:
	lui	$2,%hi(plr)
	lw	$2,%lo(plr)($2)
	lui	$3,%hi(cheating)
	lw	$2,0($2)
	lw	$3,%lo(cheating)($3)
	lw	$7,32($2)
	lw	$4,12($2)
	lw	$2,16($2)
	move	$6,$0
	sw	$2,24($sp)
	li	$2,209			# 0xd1
	sw	$4,20($sp)
	beq	$3,$0,$L420
	sw	$2,16($sp)

	lui	$4,%hi(cheat_player_arrow)
	li	$5,16			# 0x10
	jal	AM_drawLineCharacter
	addiu	$4,$4,%lo(cheat_player_arrow)

	lw	$31,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,64

$L420:
	lui	$4,%hi(player_arrow)
	li	$5,7			# 0x7
	jal	AM_drawLineCharacter
	addiu	$4,$4,%lo(player_arrow)

	lw	$31,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	AM_drawPlayers
	.size	AM_drawPlayers, .-AM_drawPlayers
	.align	2
	.globl	AM_drawThings
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawThings
	.type	AM_drawThings, @function
AM_drawThings:
	.frame	$sp,72,$31		# vars= 0, regs= 9/0, args= 32, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$22,60($sp)
	lui	$22,%hi(numsectors)
	lw	$2,%lo(numsectors)($22)
	sw	$31,68($sp)
	sw	$23,64($sp)
	sw	$21,56($sp)
	sw	$20,52($sp)
	sw	$19,48($sp)
	sw	$18,44($sp)
	sw	$17,40($sp)
	blez	$2,$L437
	sw	$16,36($sp)

	lui	$18,%hi(thintriangle_guy)
	move	$17,$4
	move	$21,$0
	move	$20,$0
	lui	$23,%hi(sectors)
	lui	$19,%hi(lightlev)
	addiu	$18,$18,%lo(thintriangle_guy)
$L441:
	lw	$2,%lo(sectors)($23)
	addu	$2,$2,$21
	lw	$16,72($2)
	beq	$16,$0,$L448
	lw	$2,%lo(numsectors)($22)

$L440:
	lw	$3,16($16)
	lw	$7,32($16)
	lw	$2,%lo(lightlev)($19)
	sw	$3,24($sp)
	lw	$3,12($16)
	addu	$2,$17,$2
	sw	$3,20($sp)
	sw	$2,16($sp)
	li	$6,1048576			# 0x100000
	li	$5,3			# 0x3
	jal	AM_drawLineCharacter
	move	$4,$18

	lw	$16,24($16)
	bne	$16,$0,$L440
	lw	$2,%lo(numsectors)($22)

$L448:
	addiu	$20,$20,1
	slt	$2,$20,$2
	bne	$2,$0,$L441
	addiu	$21,$21,88

$L437:
	lw	$31,68($sp)
	lw	$23,64($sp)
	lw	$22,60($sp)
	lw	$21,56($sp)
	lw	$20,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	AM_drawThings
	.size	AM_drawThings, .-AM_drawThings
	.align	2
	.globl	AM_drawMarks
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawMarks
	.type	AM_drawMarks, @function
AM_drawMarks:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	lui	$2,%hi(m_x)
	sw	$2,16($sp)
	lui	$2,%hi(m_y)
	sw	$16,32($sp)
	sw	$2,20($sp)
	lui	$16,%hi(markpoints)
	lui	$2,%hi(f_y)
	addiu	$16,$16,%lo(markpoints)
	lui	$7,%hi(marknums)
	sw	$2,24($sp)
	lui	$2,%hi(f_w)
	sw	$fp,64($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$31,68($sp)
	sw	$23,60($sp)
	sw	$17,36($sp)
	addiu	$22,$7,%lo(marknums)
	addiu	$21,$16,80
	li	$fp,-1			# 0xffffffffffffffff
	lui	$19,%hi(scale_mtof)
	lui	$18,%hi(f_x)
	lui	$20,%hi(f_h)
	sw	$2,28($sp)
$L453:
	lw	$2,0($16)
	.set	noat
	xor	$1,$2,$fp
	beq	$1,$0,$L451
	.set	at
	lw	$3,16($sp)

	lw	$5,%lo(scale_mtof)($19)
	lw	$4,%lo(m_x)($3)
	jal	FixedMul
	subu	$4,$2,$4

	lw	$3,20($sp)
	lw	$10,4($16)
	lw	$4,%lo(m_y)($3)
	lw	$6,%lo(f_x)($18)
	lw	$5,%lo(scale_mtof)($19)
	sra	$3,$2,16
	subu	$4,$10,$4
	addu	$23,$3,$6
	jal	FixedMul
	lw	$17,%lo(f_h)($20)

	lw	$4,%lo(f_x)($18)
	lw	$3,24($sp)
	slt	$4,$23,$4
	bne	$4,$0,$L451
	lw	$6,%lo(f_y)($3)

	lw	$3,28($sp)
	sra	$2,$2,16
	lw	$4,%lo(f_w)($3)
	subu	$5,$17,$2
	addiu	$2,$4,-5
	addu	$5,$5,$6
	slt	$2,$2,$23
	bne	$2,$0,$L451
	slt	$6,$5,$6

	bne	$6,$0,$L451
	lw	$2,%lo(f_h)($20)

	addiu	$2,$2,-6
	slt	$2,$2,$5
	beq	$2,$0,$L456
	move	$4,$23

$L451:
	addiu	$16,$16,8
	.set	noat
	xor	$1,$16,$21
	bne	$1,$0,$L453
	.set	at
	addiu	$22,$22,4

	lw	$31,68($sp)
$L458:
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L456:
	lw	$6,0($22)
	jal	V_DrawPatch
	addiu	$16,$16,8

	.set	noat
	xor	$1,$16,$21
	bne	$1,$0,$L453
	.set	at
	addiu	$22,$22,4

	b	$L458
	lw	$31,68($sp)

	.set	macro
	.set	reorder
	.end	AM_drawMarks
	.size	AM_drawMarks, .-AM_drawMarks
	.align	2
	.globl	AM_drawCrosshair
	.set	nomips16
	.set	nomicromips
	.ent	AM_drawCrosshair
	.type	AM_drawCrosshair, @function
AM_drawCrosshair:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(f_h)
	lw	$2,%lo(f_h)($2)
	lui	$3,%hi(f_w)
	lw	$3,%lo(f_w)($3)
	addiu	$2,$2,1
	multu	$2,$3
	mflo	$2
	lui	$5,%hi(fb)
	srl	$3,$2,31
	lw	$5,%lo(fb)($5)
	addu	$2,$3,$2
	sra	$2,$2,1
	addu	$5,$5,$2
	jr	$31
	sb	$4,0($5)

	.set	macro
	.set	reorder
	.end	AM_drawCrosshair
	.size	AM_drawCrosshair, .-AM_drawCrosshair
	.align	2
	.globl	AM_Drawer
	.set	nomips16
	.set	nomicromips
	.ent	AM_Drawer
	.type	AM_Drawer, @function
AM_Drawer:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(automapactive)
	lw	$2,%lo(automapactive)($2)
	bne	$2,$0,$L470
	nop

	jr	$31
	nop

$L470:
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	sw	$16,16($sp)
	lui	$17,%hi(f_h)
	lui	$16,%hi(f_w)
	lw	$6,%lo(f_w)($16)
	lw	$2,%lo(f_h)($17)
	sw	$18,24($sp)
	multu	$6,$2
	mflo	$6
	lui	$18,%hi(fb)
	lw	$4,%lo(fb)($18)
	sw	$31,28($sp)
	jal	memset
	move	$5,$0

	lui	$2,%hi(grid)
	lw	$2,%lo(grid)($2)
	bne	$2,$0,$L471
	nop

$L462:
	jal	AM_drawWalls
	nop

	jal	AM_drawPlayers
	nop

	lui	$2,%hi(cheating)
	lw	$3,%lo(cheating)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L472
	.set	at
	li	$5,16			# 0x10

	lw	$2,%lo(f_h)($17)
$L473:
	lw	$3,%lo(f_w)($16)
	addiu	$2,$2,1
	multu	$2,$3
	mflo	$2
	lw	$4,%lo(fb)($18)
	srl	$3,$2,31
	addu	$2,$3,$2
	sra	$2,$2,1
	addu	$2,$4,$2
	li	$3,96			# 0x60
	jal	AM_drawMarks
	sb	$3,0($2)

	lui	$2,%hi(f_y)
	lw	$5,%lo(f_y)($2)
	lui	$2,%hi(f_x)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$7,%lo(f_h)($17)
	lw	$6,%lo(f_w)($16)
	lw	$17,20($sp)
	lw	$16,16($sp)
	lw	$4,%lo(f_x)($2)
	j	V_MarkRect
	addiu	$sp,$sp,32

$L471:
	jal	AM_drawGrid
	li	$4,104			# 0x68

	b	$L462
	nop

$L472:
	jal	AM_drawThings
	li	$4,112			# 0x70

	b	$L473
	lw	$2,%lo(f_h)($17)

	.set	macro
	.set	reorder
	.end	AM_Drawer
	.size	AM_Drawer, .-AM_Drawer
	.rdata
	.align	2
	.type	their_colors.0, @object
	.size	their_colors.0, 16
their_colors.0:
	.word	112
	.word	96
	.word	64
	.word	176
	.local	l.1
	.comm	l.1,16,4
	.local	fl.2
	.comm	fl.2,16,4
	.local	fuck.3
	.comm	fuck.3,4,4
	.align	2
	.type	litelevels.4, @object
	.size	litelevels.4, 32
litelevels.4:
	.word	0
	.word	4
	.word	7
	.word	10
	.word	12
	.word	14
	.word	15
	.word	15
	.local	litelevelscnt.5
	.comm	litelevelscnt.5,4,4
	.local	nexttic.6
	.comm	nexttic.6,4,4
	.local	buffer.7
	.comm	buffer.7,20,4
	.local	bigstate.8
	.comm	bigstate.8,4,4
	.data
	.align	2
	.type	lastepisode.9, @object
	.size	lastepisode.9, 4
lastepisode.9:
	.word	-1
	.align	2
	.type	lastlevel.10, @object
	.size	lastlevel.10, 4
lastlevel.10:
	.word	-1
	.align	2
	.type	st_notify.11, @object
	.size	st_notify.11, 20
st_notify.11:
	.word	0
	.word	1
	.word	1634564096
	.word	0
	.space	4
	.align	2
	.type	st_notify.12, @object
	.size	st_notify.12, 20
st_notify.12:
	.word	1
	.word	1634559232
	.word	0
	.word	0
	.space	4
	.align	2
	.type	stopped, @object
	.size	stopped, 4
stopped:
	.word	1
	.globl	cheat_amap
	.align	2
	.type	cheat_amap, @object
	.size	cheat_amap, 52
cheat_amap:
	.ascii	"iddt\000"
	.space	20
	.space	3
	.word	4
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.align	2
	.type	followplayer, @object
	.size	followplayer, 4
followplayer:
	.word	1
	.local	markpointnum
	.comm	markpointnum,4,4
	.local	markpoints
	.comm	markpoints,80,4
	.local	marknums
	.comm	marknums,40,4
	.local	plr
	.comm	plr,4,4
	.local	scale_ftom
	.comm	scale_ftom,4,4
	.align	2
	.type	scale_mtof, @object
	.size	scale_mtof, 4
scale_mtof:
	.word	13107
	.local	f_oldloc
	.comm	f_oldloc,8,4
	.local	old_m_y
	.comm	old_m_y,4,4
	.local	old_m_x
	.comm	old_m_x,4,4
	.local	old_m_h
	.comm	old_m_h,4,4
	.local	old_m_w
	.comm	old_m_w,4,4
	.local	max_scale_mtof
	.comm	max_scale_mtof,4,4
	.local	min_scale_mtof
	.comm	min_scale_mtof,4,4
	.local	max_h
	.comm	max_h,4,4
	.local	max_y
	.comm	max_y,4,4
	.local	max_x
	.comm	max_x,4,4
	.local	min_y
	.comm	min_y,4,4
	.local	min_x
	.comm	min_x,4,4
	.local	m_h
	.comm	m_h,4,4
	.local	m_w
	.comm	m_w,4,4
	.local	m_y2
	.comm	m_y2,4,4
	.local	m_x2
	.comm	m_x2,4,4
	.local	m_y
	.comm	m_y,4,4
	.local	m_x
	.comm	m_x,4,4
	.local	ftom_zoommul
	.comm	ftom_zoommul,4,4
	.local	mtof_zoommul
	.comm	mtof_zoommul,4,4
	.local	m_paninc
	.comm	m_paninc,8,4
	.local	amclock
	.comm	amclock,4,4
	.local	fb
	.comm	fb,4,4
	.local	lightlev
	.comm	lightlev,4,4
	.local	f_h
	.comm	f_h,4,4
	.local	f_w
	.comm	f_w,4,4
	.local	f_y
	.comm	f_y,4,4
	.local	f_x
	.comm	f_x,4,4
	.globl	automapactive
	.section	.bss,"aw",@nobits
	.align	2
	.type	automapactive, @object
	.size	automapactive, 4
automapactive:
	.space	4
	.local	grid
	.comm	grid,4,4
	.local	cheating
	.comm	cheating,4,4
	.globl	thintriangle_guy
	.data
	.align	2
	.type	thintriangle_guy, @object
	.size	thintriangle_guy, 48
thintriangle_guy:
	.word	-32768
	.word	-45875
	.word	65536
	.word	0
	.word	65536
	.word	0
	.word	-32768
	.word	45875
	.word	-32768
	.word	45875
	.word	-32768
	.word	-45875
	.globl	triangle_guy
	.align	2
	.type	triangle_guy, @object
	.size	triangle_guy, 48
triangle_guy:
	.word	-56819
	.word	-32768
	.word	56819
	.word	-32768
	.word	56819
	.word	-32768
	.word	0
	.word	65536
	.word	0
	.word	65536
	.word	-56819
	.word	-32768
	.globl	cheat_player_arrow
	.align	2
	.type	cheat_player_arrow, @object
	.size	cheat_player_arrow, 256
cheat_player_arrow:
	.word	-1048576
	.word	0
	.word	1198372
	.word	0
	.word	1198372
	.word	0
	.word	599186
	.word	199728
	.word	1198372
	.word	0
	.word	599186
	.word	-199728
	.word	-1048576
	.word	0
	.word	-1348168
	.word	199728
	.word	-1048576
	.word	0
	.word	-1348168
	.word	-199728
	.word	-748983
	.word	0
	.word	-1048576
	.word	199728
	.word	-748983
	.word	0
	.word	-1048576
	.word	-199728
	.word	-599186
	.word	0
	.word	-599186
	.word	-199728
	.word	-599186
	.word	-199728
	.word	-399458
	.word	-199728
	.word	-399458
	.word	-199728
	.word	-399458
	.word	299593
	.word	-199728
	.word	0
	.word	-199728
	.word	-199728
	.word	-199728
	.word	-199728
	.word	0
	.word	-199728
	.word	0
	.word	-199728
	.word	0
	.word	299593
	.word	199728
	.word	299593
	.word	199728
	.word	-171196
	.word	199728
	.word	-171196
	.word	237177
	.word	-208645
	.word	237177
	.word	-208645
	.word	319565
	.word	-171196
	.globl	player_arrow
	.align	2
	.type	player_arrow, @object
	.size	player_arrow, 112
player_arrow:
	.word	-1048576
	.word	0
	.word	1198372
	.word	0
	.word	1198372
	.word	0
	.word	599186
	.word	299593
	.word	1198372
	.word	0
	.word	599186
	.word	-299593
	.word	-1048576
	.word	0
	.word	-1348168
	.word	299593
	.word	-1048576
	.word	0
	.word	-1348168
	.word	-299593
	.word	-748983
	.word	0
	.word	-1048576
	.word	299593
	.word	-748983
	.word	0
	.word	-1048576
	.word	-299593
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
