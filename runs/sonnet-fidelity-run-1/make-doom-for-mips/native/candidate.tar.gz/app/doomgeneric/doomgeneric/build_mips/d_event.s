	.file	1 "d_event.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	D_PostEvent
	.set	nomips16
	.set	nomicromips
	.ent	D_PostEvent
	.type	D_PostEvent, @function
D_PostEvent:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(eventhead)
	lw	$3,%lo(eventhead)($5)
	lw	$10,0($4)
	sll	$2,$3,2
	lw	$9,4($4)
	lw	$8,8($4)
	lw	$7,12($4)
	lw	$6,16($4)
	addu	$2,$2,$3
	lui	$4,%hi(events)
	addiu	$4,$4,%lo(events)
	sll	$2,$2,2
	addu	$2,$2,$4
	li	$4,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,1
	addiu	$4,$4,63
	and	$3,$3,$4
	sw	$10,0($2)
	sw	$9,4($2)
	sw	$8,8($2)
	sw	$7,12($2)
	bgez	$3,$L2
	sw	$6,16($2)

	addiu	$3,$3,-1
	li	$2,-64			# 0xffffffffffffffc0
	or	$3,$3,$2
	addiu	$3,$3,1
$L2:
	jr	$31
	sw	$3,%lo(eventhead)($5)

	.set	macro
	.set	reorder
	.end	D_PostEvent
	.size	D_PostEvent, .-D_PostEvent
	.align	2
	.globl	D_PopEvent
	.set	nomips16
	.set	nomicromips
	.ent	D_PopEvent
	.type	D_PopEvent, @function
D_PopEvent:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(eventtail)
	lui	$2,%hi(eventhead)
	lw	$3,%lo(eventtail)($5)
	lw	$2,%lo(eventhead)($2)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L7
	.set	at
	sll	$4,$3,2

	li	$2,-2147483648			# 0xffffffff80000000
	addu	$4,$4,$3
	addiu	$2,$2,63
	addiu	$3,$3,1
	and	$3,$3,$2
	lui	$2,%hi(events)
	sll	$4,$4,2
	addiu	$2,$2,%lo(events)
	bgez	$3,$L6
	addu	$2,$2,$4

	addiu	$3,$3,-1
	li	$4,-64			# 0xffffffffffffffc0
	or	$3,$3,$4
	addiu	$3,$3,1
$L6:
	jr	$31
	sw	$3,%lo(eventtail)($5)

$L7:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	D_PopEvent
	.size	D_PopEvent, .-D_PopEvent
	.local	eventtail
	.comm	eventtail,4,4
	.local	eventhead
	.comm	eventhead,4,4
	.local	events
	.comm	events,1280,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
