	.file	1 "d_items.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.globl	weaponinfo
	.data
	.align	2
	.type	weaponinfo, @object
	.size	weaponinfo, 216
weaponinfo:
	.word	5
	.word	4
	.word	3
	.word	2
	.word	5
	.word	0
	.word	0
	.word	12
	.word	11
	.word	10
	.word	13
	.word	17
	.word	1
	.word	20
	.word	19
	.word	18
	.word	21
	.word	30
	.word	0
	.word	51
	.word	50
	.word	49
	.word	52
	.word	55
	.word	3
	.word	59
	.word	58
	.word	57
	.word	60
	.word	63
	.word	2
	.word	76
	.word	75
	.word	74
	.word	77
	.word	79
	.word	2
	.word	83
	.word	82
	.word	81
	.word	84
	.word	88
	.word	5
	.word	70
	.word	69
	.word	67
	.word	71
	.word	0
	.word	1
	.word	34
	.word	33
	.word	32
	.word	35
	.word	47
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
