	.file	1 "d_iwad.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	DirIsFile
	.type	DirIsFile, @function
DirIsFile:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	move	$18,$5
	sw	$31,28($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	jal	strlen
	move	$17,$4

	move	$4,$18
	jal	strlen
	move	$16,$2

	addiu	$3,$2,1
	sltu	$3,$16,$3
	bne	$3,$0,$L8
	lw	$31,28($sp)

	subu	$2,$16,$2
	addu	$4,$17,$2
	lb	$3,-1($4)
	li	$2,47			# 0x2f
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L7
	.set	at
	nop

$L8:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L7:
	jal	strcasecmp
	move	$5,$18

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	DirIsFile
	.size	DirIsFile, .-DirIsFile
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	".\000"
	.align	2
$LC1:
	.ascii	"/\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	D_FindWADByName.part.0
	.type	D_FindWADByName.part.0, @function
D_FindWADByName.part.0:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$21,36($sp)
	lui	$21,%hi(num_iwad_dirs)
	lw	$2,%lo(num_iwad_dirs)($21)
	sw	$22,40($sp)
	slt	$3,$2,128
	sw	$19,28($sp)
	sw	$31,44($sp)
	sw	$20,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lui	$22,%hi(iwad_dirs)
	bne	$3,$0,$L23
	move	$19,$4

	addiu	$22,$22,%lo(iwad_dirs)
$L10:
	lui	$20,%hi($LC1)
	move	$17,$22
	move	$18,$0
	b	$L13
	addiu	$20,$20,%lo($LC1)

$L26:
	jal	free
	addiu	$17,$17,4

	lw	$2,%lo(num_iwad_dirs)($21)
	slt	$2,$18,$2
	beq	$2,$0,$L27
	lw	$31,44($sp)

$L13:
	lw	$4,0($17)
	jal	DirIsFile
	move	$5,$19

	beq	$2,$0,$L12
	nop

	jal	M_FileExists
	lw	$4,0($17)

	bne	$2,$0,$L25
	lw	$31,44($sp)

$L12:
	lw	$4,0($17)
	move	$7,$0
	move	$6,$19
	jal	M_StringJoin
	move	$5,$20

	move	$4,$2
	jal	M_FileExists
	move	$16,$2

	addiu	$18,$18,1
	beq	$2,$0,$L26
	move	$4,$16

	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L23:
	sll	$3,$2,2
	addiu	$22,$22,%lo(iwad_dirs)
	lui	$4,%hi($LC0)
	addu	$3,$22,$3
	addiu	$2,$2,1
	addiu	$4,$4,%lo($LC0)
	sw	$4,0($3)
	bgtz	$2,$L10
	sw	$2,%lo(num_iwad_dirs)($21)

	lw	$31,44($sp)
$L27:
	move	$16,$0
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L25:
	sll	$18,$18,2
	addu	$22,$22,$18
	lw	$4,0($22)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	strdup
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	D_FindWADByName.part.0
	.size	D_FindWADByName.part.0, .-D_FindWADByName.part.0
	.align	2
	.globl	D_FindWADByName
	.set	nomips16
	.set	nomicromips
	.ent	D_FindWADByName
	.type	D_FindWADByName, @function
D_FindWADByName:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	M_FileExists
	move	$16,$4

	beq	$2,$0,$L31
	lw	$31,20($sp)

	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L31:
	move	$4,$16
	lw	$16,16($sp)
	j	D_FindWADByName.part.0
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_FindWADByName
	.size	D_FindWADByName, .-D_FindWADByName
	.align	2
	.globl	D_TryFindWADByName
	.set	nomips16
	.set	nomicromips
	.ent	D_TryFindWADByName
	.type	D_TryFindWADByName, @function
D_TryFindWADByName:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	M_FileExists
	move	$16,$4

	beq	$2,$0,$L37
	lw	$31,20($sp)

	move	$2,$16
	movz	$2,$16,$2
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L37:
	jal	D_FindWADByName.part.0
	move	$4,$16

	lw	$31,20($sp)
	movz	$2,$16,$2
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_TryFindWADByName
	.size	D_TryFindWADByName, .-D_TryFindWADByName
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"-iwad\000"
	.align	2
$LC3:
	.ascii	"IWAD file '%s' not found!\000"
	.align	2
$LC4:
	.ascii	"-iwad not specified, trying a few iwad names\012\000"
	.align	2
$LC5:
	.ascii	"Trying IWAD file:%s\012\000"
	.text
	.align	2
	.globl	D_FindIWAD
	.set	nomips16
	.set	nomicromips
	.ent	D_FindIWAD
	.type	D_FindIWAD, @function
D_FindIWAD:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$19,44($sp)
	move	$19,$4
	lui	$4,%hi($LC2)
	move	$2,$5
	addiu	$4,$4,%lo($LC2)
	li	$5,1			# 0x1
	sw	$23,60($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	jal	M_CheckParmWithArgs
	sw	$2,76($sp)

	beq	$2,$0,$L39
	move	$23,$2

	lui	$2,%hi(myargv)
	lw	$2,%lo(myargv)($2)
	addiu	$3,$23,1
	sll	$3,$3,2
	addu	$2,$2,$3
	lw	$17,0($2)
	jal	M_FileExists
	move	$4,$17

	beq	$2,$0,$L77
	nop

	move	$16,$17
$L40:
	beq	$16,$0,$L78
	lui	$4,%hi($LC3)

	li	$5,47			# 0x2f
$L86:
	jal	strrchr
	move	$4,$16

	beq	$2,$0,$L42
	move	$20,$16

	addiu	$20,$2,1
$L42:
	lui	$17,%hi(iwads)
	addiu	$17,$17,%lo(iwads)
	addiu	$21,$17,224
$L44:
	lw	$18,4($17)
	sra	$2,$19,$18
	andi	$2,$2,0x1
	beq	$2,$0,$L46
	move	$4,$20

	jal	strcasecmp
	lw	$5,0($17)

	beq	$2,$0,$L87
	lw	$2,76($sp)

$L46:
	addiu	$17,$17,16
	.set	noat
	xor	$1,$21,$17
	bne	$1,$0,$L44
	.set	at
	li	$18,9			# 0x9

	lw	$2,76($sp)
$L87:
	lw	$31,68($sp)
	sw	$18,0($2)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	move	$2,$16
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L39:
	lui	$4,%hi($LC4)
	jal	printf
	addiu	$4,$4,%lo($LC4)

	lui	$2,%hi(num_iwad_dirs)
	sw	$2,28($sp)
	lw	$2,%lo(num_iwad_dirs)($2)
	slt	$3,$2,128
	beq	$3,$0,$L79
	lui	$fp,%hi(iwad_dirs)

	sll	$3,$2,2
	addiu	$fp,$fp,%lo(iwad_dirs)
	lui	$4,%hi($LC0)
	addu	$3,$3,$fp
	addiu	$4,$4,%lo($LC0)
	sw	$4,0($3)
	lw	$3,28($sp)
	addiu	$2,$2,1
	sw	$2,%lo(num_iwad_dirs)($3)
$L48:
	lui	$3,%hi(iwads)
	lui	$21,%hi($LC5)
	sw	$3,24($sp)
	addiu	$3,$21,%lo($LC5)
	lui	$22,%hi($LC0)
	sw	$3,16($sp)
	slt	$2,$23,$2
	lui	$3,%hi($LC1)
	addiu	$22,$22,%lo($LC0)
	beq	$2,$0,$L80
	sw	$3,20($sp)

$L57:
	lw	$2,24($sp)
	lw	$18,0($fp)
	addiu	$21,$2,%lo(iwads)
	b	$L56
	addiu	$20,$21,224

$L85:
	jal	strdup
	move	$4,$16

	move	$16,$2
	lw	$4,16($sp)
	jal	printf
	move	$5,$16

	jal	M_FileExists
	move	$4,$16

	beq	$2,$0,$L81
	nop

$L52:
	bne	$16,$0,$L88
	lw	$2,76($sp)

$L55:
	addiu	$21,$21,16
$L91:
	.set	noat
	xor	$1,$21,$20
	beq	$1,$0,$L89
	.set	at
	lw	$2,28($sp)

$L56:
	lw	$17,4($21)
	sra	$2,$19,$17
	andi	$2,$2,0x1
	beq	$2,$0,$L55
	nop

	lw	$16,0($21)
	move	$4,$18
	jal	DirIsFile
	move	$5,$16

	beq	$2,$0,$L90
	move	$5,$22

	jal	M_FileExists
	move	$4,$18

	bne	$2,$0,$L84
	move	$5,$22

$L90:
	jal	strcmp
	move	$4,$18

	beq	$2,$0,$L85
	lw	$2,20($sp)

	move	$6,$16
	move	$7,$0
	addiu	$5,$2,%lo($LC1)
	jal	M_StringJoin
	move	$4,$18

	move	$16,$2
	lw	$4,16($sp)
	jal	printf
	move	$5,$16

	jal	M_FileExists
	move	$4,$16

	bne	$2,$0,$L52
	nop

$L81:
	move	$4,$16
	jal	free
	addiu	$21,$21,16

	.set	noat
	xor	$1,$21,$20
	bne	$1,$0,$L56
	.set	at
	lw	$2,28($sp)

$L89:
	addiu	$23,$23,1
	lw	$2,%lo(num_iwad_dirs)($2)
	slt	$2,$23,$2
	bne	$2,$0,$L57
	addiu	$fp,$fp,4

$L80:
	lw	$31,68($sp)
	move	$16,$0
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	move	$2,$16
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L79:
	b	$L48
	addiu	$fp,$fp,%lo(iwad_dirs)

$L77:
	jal	D_FindWADByName.part.0
	move	$4,$17

	b	$L40
	move	$16,$2

$L84:
	jal	strdup
	move	$4,$18

	move	$16,$2
	beq	$16,$0,$L91
	addiu	$21,$21,16

	lw	$2,76($sp)
$L88:
	lw	$31,68($sp)
	sw	$17,0($2)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	move	$2,$16
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L78:
	move	$5,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	b	$L86
	li	$5,47			# 0x2f

	.set	macro
	.set	reorder
	.end	D_FindIWAD
	.size	D_FindIWAD, .-D_FindIWAD
	.align	2
	.globl	D_FindAllIWADs
	.set	nomips16
	.set	nomicromips
	.ent	D_FindAllIWADs
	.type	D_FindAllIWADs, @function
D_FindAllIWADs:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$19,32($sp)
	sw	$16,20($sp)
	move	$19,$4
	lui	$16,%hi(iwads)
	li	$4,60			# 0x3c
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$18,28($sp)
	sw	$31,44($sp)
	sw	$17,24($sp)
	jal	malloc
	addiu	$16,$16,%lo(iwads)

	move	$21,$2
	addiu	$20,$16,224
	move	$18,$0
$L97:
	lw	$3,4($16)
	sra	$3,$19,$3
	andi	$3,$3,0x1
	beq	$3,$0,$L96
	nop

	lw	$17,0($16)
	jal	M_FileExists
	move	$4,$17

	bne	$2,$0,$L94
	move	$4,$17

	jal	D_FindWADByName.part.0
	nop

	move	$17,$2
$L94:
	sll	$2,$18,2
	beq	$17,$0,$L96
	addu	$2,$21,$2

	sw	$16,0($2)
	addiu	$18,$18,1
$L96:
	addiu	$16,$16,16
	.set	noat
	xor	$1,$16,$20
	bne	$1,$0,$L97
	.set	at
	lw	$31,44($sp)

	sll	$18,$18,2
	addu	$18,$21,$18
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$0,0($18)
	move	$2,$21
	lw	$18,28($sp)
	lw	$21,40($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	D_FindAllIWADs
	.size	D_FindAllIWADs, .-D_FindAllIWADs
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"unknown.wad\000"
	.text
	.align	2
	.globl	D_SaveGameIWADName
	.set	nomips16
	.set	nomicromips
	.ent	D_SaveGameIWADName
	.type	D_SaveGameIWADName, @function
D_SaveGameIWADName:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(iwads+4)
	addiu	$2,$2,%lo(iwads+4)
	move	$3,$0
	li	$6,14			# 0xe
$L106:
	lw	$5,0($2)
	.set	noat
	xor	$1,$5,$4
	beq	$1,$0,$L108
	.set	at
	addiu	$2,$2,16

	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L106
	.set	at
	nop

	lui	$2,%hi($LC6)
	jr	$31
	addiu	$2,$2,%lo($LC6)

$L108:
	lui	$2,%hi(iwads)
	addiu	$2,$2,%lo(iwads)
	sll	$3,$3,4
	addu	$3,$3,$2
	jr	$31
	lw	$2,0($3)

	.set	macro
	.set	reorder
	.end	D_SaveGameIWADName
	.size	D_SaveGameIWADName, .-D_SaveGameIWADName
	.align	2
	.globl	D_SuggestIWADName
	.set	nomips16
	.set	nomicromips
	.ent	D_SuggestIWADName
	.type	D_SuggestIWADName, @function
D_SuggestIWADName:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(iwads+4)
	addiu	$2,$2,%lo(iwads+4)
	move	$3,$0
	b	$L112
	li	$7,14			# 0xe

$L110:
	addiu	$3,$3,1
$L115:
	.set	noat
	xor	$1,$3,$7
	beq	$1,$0,$L114
	.set	at
	addiu	$2,$2,16

$L112:
	lw	$6,0($2)
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L110
	.set	at
	nop

	lw	$6,4($2)
	.set	noat
	xor	$1,$6,$5
	bne	$1,$0,$L115
	.set	at
	addiu	$3,$3,1

	addiu	$3,$3,-1
	lui	$2,%hi(iwads)
	addiu	$2,$2,%lo(iwads)
	sll	$3,$3,4
	addu	$3,$3,$2
	jr	$31
	lw	$2,0($3)

$L114:
	lui	$2,%hi($LC6)
	jr	$31
	addiu	$2,$2,%lo($LC6)

	.set	macro
	.set	reorder
	.end	D_SuggestIWADName
	.size	D_SuggestIWADName, .-D_SuggestIWADName
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"Unknown game?\000"
	.text
	.align	2
	.globl	D_SuggestGameName
	.set	nomips16
	.set	nomicromips
	.ent	D_SuggestGameName
	.type	D_SuggestGameName, @function
D_SuggestGameName:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(iwads+4)
	addiu	$2,$2,%lo(iwads+4)
	move	$3,$0
	li	$8,4			# 0x4
	b	$L121
	li	$7,14			# 0xe

$L117:
	addiu	$3,$3,1
$L124:
	.set	noat
	xor	$1,$3,$7
	beq	$1,$0,$L123
	.set	at
	addiu	$2,$2,16

$L121:
	lw	$6,0($2)
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L117
	.set	at
	nop

	.set	noat
	xor	$1,$5,$8
	beq	$1,$0,$L120
	.set	at
	nop

	lw	$6,4($2)
	.set	noat
	xor	$1,$6,$5
	bne	$1,$0,$L124
	.set	at
	addiu	$3,$3,1

	addiu	$3,$3,-1
$L120:
	lui	$2,%hi(iwads)
	sll	$3,$3,4
	addiu	$2,$2,%lo(iwads)
	addu	$2,$2,$3
	jr	$31
	lw	$2,12($2)

$L123:
	lui	$2,%hi($LC7)
	jr	$31
	addiu	$2,$2,%lo($LC7)

	.set	macro
	.set	reorder
	.end	D_SuggestGameName
	.size	D_SuggestGameName, .-D_SuggestGameName
	.local	num_iwad_dirs
	.comm	num_iwad_dirs,4,4
	.local	iwad_dirs
	.comm	iwad_dirs,512,4
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"doom2.wad\000"
	.align	2
$LC9:
	.ascii	"Doom II\000"
	.align	2
$LC10:
	.ascii	"plutonia.wad\000"
	.align	2
$LC11:
	.ascii	"Final Doom: Plutonia Experiment\000"
	.align	2
$LC12:
	.ascii	"tnt.wad\000"
	.align	2
$LC13:
	.ascii	"Final Doom: TNT: Evilution\000"
	.align	2
$LC14:
	.ascii	"doom.wad\000"
	.align	2
$LC15:
	.ascii	"Doom\000"
	.align	2
$LC16:
	.ascii	"doom1.wad\000"
	.align	2
$LC17:
	.ascii	"Doom Shareware\000"
	.align	2
$LC18:
	.ascii	"chex.wad\000"
	.align	2
$LC19:
	.ascii	"Chex Quest\000"
	.align	2
$LC20:
	.ascii	"hacx.wad\000"
	.align	2
$LC21:
	.ascii	"Hacx\000"
	.align	2
$LC22:
	.ascii	"freedm.wad\000"
	.align	2
$LC23:
	.ascii	"FreeDM\000"
	.align	2
$LC24:
	.ascii	"freedoom2.wad\000"
	.align	2
$LC25:
	.ascii	"Freedoom: Phase 2\000"
	.align	2
$LC26:
	.ascii	"freedoom1.wad\000"
	.align	2
$LC27:
	.ascii	"Freedoom: Phase 1\000"
	.align	2
$LC28:
	.ascii	"heretic.wad\000"
	.align	2
$LC29:
	.ascii	"Heretic\000"
	.align	2
$LC30:
	.ascii	"heretic1.wad\000"
	.align	2
$LC31:
	.ascii	"Heretic Shareware\000"
	.align	2
$LC32:
	.ascii	"hexen.wad\000"
	.align	2
$LC33:
	.ascii	"Hexen\000"
	.align	2
$LC34:
	.ascii	"strife1.wad\000"
	.align	2
$LC35:
	.ascii	"Strife\000"
	.rdata
	.align	2
	.type	iwads, @object
	.size	iwads, 224
iwads:
	.word	$LC8
	.word	1
	.word	2
	.word	$LC9
	.word	$LC10
	.word	3
	.word	2
	.word	$LC11
	.word	$LC12
	.word	2
	.word	2
	.word	$LC13
	.word	$LC14
	.word	0
	.word	3
	.word	$LC15
	.word	$LC16
	.word	0
	.word	0
	.word	$LC17
	.word	$LC18
	.word	4
	.word	0
	.word	$LC19
	.word	$LC20
	.word	5
	.word	2
	.word	$LC21
	.word	$LC22
	.word	1
	.word	2
	.word	$LC23
	.word	$LC24
	.word	1
	.word	2
	.word	$LC25
	.word	$LC26
	.word	0
	.word	3
	.word	$LC27
	.word	$LC28
	.word	6
	.word	3
	.word	$LC29
	.word	$LC30
	.word	6
	.word	0
	.word	$LC31
	.word	$LC32
	.word	7
	.word	2
	.word	$LC33
	.word	$LC34
	.word	8
	.word	2
	.word	$LC35
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
