	.file	1 "d_loop.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	D_QuitNetGame
	.set	nomips16
	.set	nomicromips
	.ent	D_QuitNetGame
	.type	D_QuitNetGame, @function
D_QuitNetGame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	D_QuitNetGame
	.size	D_QuitNetGame, .-D_QuitNetGame
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	BuildNewTic
	.type	BuildNewTic, @function
BuildNewTic:
	.frame	$sp,48,$31		# vars= 16, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	lui	$2,%hi(gametic)
	sw	$18,40($sp)
	sw	$16,32($sp)
	lw	$18,%lo(gametic)($2)
	lui	$16,%hi(loop_interface)
	lui	$2,%hi(ticdup)
	sw	$31,44($sp)
	sw	$17,36($sp)
	jal	I_StartTic
	lw	$17,%lo(ticdup)($2)

	lw	$2,%lo(loop_interface)($16)
	lw	$2,0($2)
	jalr	$2
	nop

	lw	$2,%lo(loop_interface)($16)
	lw	$2,12($2)
	jalr	$2
	nop

	lui	$2,%hi(drone)
	lw	$2,%lo(drone)($2)
	bne	$2,$0,$L9
	lui	$4,%hi(new_sync)

	div	$0,$18,$17
	lui	$17,%hi(maketic)
	lw	$3,%lo(maketic)($17)
	lw	$4,%lo(new_sync)($4)
	mflo	$5
	bne	$4,$0,$L14
	subu	$3,$3,$5

	slt	$3,$3,5
	beq	$3,$0,$L15
	lw	$31,44($sp)

$L7:
	addiu	$4,$sp,16
$L17:
	li	$6,16			# 0x10
	jal	memset
	move	$5,$0

	lw	$2,%lo(loop_interface)($16)
	lw	$5,%lo(maketic)($17)
	lw	$2,4($2)
	jalr	$2
	addiu	$4,$sp,16

	lw	$4,%lo(maketic)($17)
	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,127
	and	$3,$4,$3
	bgez	$3,$L16
	sll	$2,$3,2

	addiu	$3,$3,-1
	li	$2,-128			# 0xffffffffffffff80
	or	$3,$3,$2
	addiu	$3,$3,1
	sll	$2,$3,2
$L16:
	addu	$2,$2,$3
	lui	$3,%hi(ticdata)
	addiu	$3,$3,%lo(ticdata)
	sll	$2,$2,5
	addu	$2,$2,$3
	lw	$3,16($sp)
	addiu	$4,$4,1
	sw	$3,0($2)
	lw	$3,20($sp)
	sw	$4,%lo(maketic)($17)
	sw	$3,4($2)
	lw	$3,24($sp)
	sw	$3,8($2)
	lw	$3,28($sp)
	sw	$3,12($2)
	li	$3,1			# 0x1
	sw	$3,128($2)
	li	$2,1			# 0x1
	lw	$31,44($sp)
$L15:
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,48

$L14:
	lui	$4,%hi(net_client_connected)
	lw	$4,%lo(net_client_connected)($4)
	bne	$4,$0,$L6
	nop

	slt	$3,$3,3
	bne	$3,$0,$L17
	addiu	$4,$sp,16

	b	$L15
	lw	$31,44($sp)

$L9:
	lw	$31,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,48

$L6:
	slt	$3,$3,9
	bne	$3,$0,$L7
	lw	$31,44($sp)

	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	BuildNewTic
	.size	BuildNewTic, .-BuildNewTic
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	NetUpdate.part.0
	.type	NetUpdate.part.0, @function
NetUpdate.part.0:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$17,24($sp)
	jal	I_GetTimeMS
	sw	$16,20($sp)

	lui	$3,%hi(new_sync)
	lw	$3,%lo(new_sync)($3)
	beq	$3,$0,$L38
	sll	$3,$2,3

	lui	$3,%hi(offsetms)
	lw	$3,%lo(offsetms)($3)
	bltz	$3,$L36
	li	$4,65535			# 0xffff

$L20:
	sra	$3,$3,16
	addu	$2,$2,$3
	sll	$3,$2,3
$L38:
	addu	$3,$3,$2
	sll	$3,$3,2
	subu	$3,$3,$2
	li	$2,274857984			# 0x10620000
	addiu	$2,$2,19923
	mult	$3,$2
	lui	$4,%hi(ticdup)
	mfhi	$2
	lw	$4,%lo(ticdup)($4)
	sra	$3,$3,31
	sra	$2,$2,6
	subu	$2,$2,$3
	div	$0,$2,$4
	lui	$4,%hi(lasttime)
	lw	$2,%lo(lasttime)($4)
	lui	$6,%hi(skiptics)
	lw	$3,%lo(skiptics)($6)
	mflo	$5
	subu	$2,$5,$2
	slt	$7,$2,$3
	bne	$7,$0,$L21
	sw	$5,%lo(lasttime)($4)

	subu	$17,$2,$3
	sw	$0,%lo(skiptics)($6)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L22
	.set	at
	move	$16,$0

	lw	$31,28($sp)
$L39:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L37:
	.set	noat
	xor	$1,$17,$16
	beq	$1,$0,$L39
	.set	at
	nop

$L22:
	jal	BuildNewTic
	addiu	$16,$16,1

	bne	$2,$0,$L37
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L21:
	lw	$31,28($sp)
	subu	$3,$3,$2
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$3,%lo(skiptics)($6)
	jr	$31
	addiu	$sp,$sp,32

$L36:
	b	$L20
	addu	$3,$3,$4

	.set	macro
	.set	reorder
	.end	NetUpdate.part.0
	.size	NetUpdate.part.0, .-NetUpdate.part.0
	.align	2
	.globl	NetUpdate
	.set	nomips16
	.set	nomicromips
	.ent	NetUpdate
	.type	NetUpdate, @function
NetUpdate:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(singletics)
	lw	$2,%lo(singletics)($2)
	beq	$2,$0,$L42
	nop

	jr	$31
	nop

$L42:
	j	NetUpdate.part.0
	nop

	.set	macro
	.set	reorder
	.end	NetUpdate
	.size	NetUpdate, .-NetUpdate
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Disconnected from server in drone mode.\000"
	.align	2
$LC1:
	.ascii	"Disconnected from server.\012\000"
	.text
	.align	2
	.globl	D_ReceiveTic
	.set	nomips16
	.set	nomicromips
	.ent	D_ReceiveTic
	.type	D_ReceiveTic, @function
D_ReceiveTic:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(drone)
	beq	$4,$0,$L59
	lw	$11,%lo(drone)($2)

	lui	$14,%hi(recvtic)
$L64:
	lw	$13,%lo(recvtic)($14)
	li	$2,-2147483648			# 0xffffffff80000000
	addiu	$2,$2,127
	and	$2,$13,$2
	bgez	$2,$L63
	sll	$3,$2,2

	addiu	$2,$2,-1
	li	$3,-128			# 0xffffffffffffff80
	or	$2,$2,$3
	addiu	$2,$2,1
	sll	$3,$2,2
$L63:
	addu	$3,$3,$2
	lui	$2,%hi(ticdata)
	sll	$3,$3,5
	addiu	$2,$2,%lo(ticdata)
	addu	$2,$2,$3
	move	$3,$0
	or	$7,$3,$11
	move	$6,$2
	bne	$7,$0,$L47
	li	$12,8			# 0x8

$L60:
	addiu	$4,$4,16
	addiu	$2,$2,16
	addiu	$5,$5,4
	addiu	$6,$6,4
	li	$3,1			# 0x1
$L47:
	lw	$7,12($4)
	lw	$10,0($4)
	lw	$9,4($4)
	lw	$8,8($4)
	sw	$10,0($2)
	sw	$9,4($2)
	sw	$8,8($2)
	sw	$7,12($2)
	lw	$7,0($5)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$12
	beq	$1,$0,$L49
	.set	at
	sw	$7,128($6)

$L61:
	or	$7,$3,$11
	addiu	$4,$4,16
	addiu	$2,$2,16
	addiu	$5,$5,4
	beq	$7,$0,$L60
	addiu	$6,$6,4

	lw	$7,12($4)
	lw	$10,0($4)
	lw	$9,4($4)
	lw	$8,8($4)
	sw	$10,0($2)
	sw	$9,4($2)
	sw	$8,8($2)
	sw	$7,12($2)
	lw	$7,0($5)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$12
	bne	$1,$0,$L61
	.set	at
	sw	$7,128($6)

$L49:
	addiu	$13,$13,1
	jr	$31
	sw	$13,%lo(recvtic)($14)

$L59:
	bne	$5,$0,$L64
	lui	$14,%hi(recvtic)

	bne	$11,$0,$L62
	lui	$4,%hi($LC1)

	j	printf
	addiu	$4,$4,%lo($LC1)

$L62:
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lw	$31,20($sp)
	lui	$4,%hi($LC1)
	addiu	$4,$4,%lo($LC1)
	j	printf
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_ReceiveTic
	.size	D_ReceiveTic, .-D_ReceiveTic
	.align	2
	.globl	D_StartGameLoop
	.set	nomips16
	.set	nomicromips
	.ent	D_StartGameLoop
	.type	D_StartGameLoop, @function
D_StartGameLoop:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	I_GetTimeMS
	nop

	lui	$3,%hi(new_sync)
	lw	$3,%lo(new_sync)($3)
	beq	$3,$0,$L73
	sll	$3,$2,3

	lui	$3,%hi(offsetms)
	lw	$3,%lo(offsetms)($3)
	bltz	$3,$L72
	li	$4,65535			# 0xffff

$L67:
	sra	$3,$3,16
	addu	$2,$2,$3
	sll	$3,$2,3
$L73:
	addu	$3,$3,$2
	sll	$3,$3,2
	subu	$2,$3,$2
	li	$3,274857984			# 0x10620000
	addiu	$3,$3,19923
	mult	$2,$3
	lui	$4,%hi(ticdup)
	mfhi	$3
	lw	$4,%lo(ticdup)($4)
	sra	$3,$3,6
	sra	$2,$2,31
	subu	$2,$3,$2
	div	$0,$2,$4
	lw	$31,20($sp)
	lui	$2,%hi(lasttime)
	addiu	$sp,$sp,24
	mflo	$3
	jr	$31
	sw	$3,%lo(lasttime)($2)

$L72:
	b	$L67
	addu	$3,$3,$4

	.set	macro
	.set	reorder
	.end	D_StartGameLoop
	.size	D_StartGameLoop, .-D_StartGameLoop
	.align	2
	.globl	D_StartNetGame
	.set	nomips16
	.set	nomicromips
	.ent	D_StartNetGame
	.type	D_StartNetGame, @function
D_StartNetGame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(player_class)
	lw	$3,%lo(player_class)($2)
	li	$2,1			# 0x1
	sw	$3,68($4)
	lui	$3,%hi(ticdup)
	sw	$2,0($4)
	sw	$2,60($4)
	sw	$2,4($4)
	sw	$2,%lo(ticdup)($3)
	lui	$2,%hi(new_sync)
	sw	$0,64($4)
	sw	$0,44($4)
	jr	$31
	sw	$0,%lo(new_sync)($2)

	.set	macro
	.set	reorder
	.end	D_StartNetGame
	.size	D_StartNetGame, .-D_StartNetGame
	.align	2
	.globl	D_InitNetGame
	.set	nomips16
	.set	nomicromips
	.ent	D_InitNetGame
	.type	D_InitNetGame, @function
D_InitNetGame:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lui	$4,%hi(D_QuitNetGame)
	li	$5,1			# 0x1
	sw	$31,20($sp)
	jal	I_AtExit
	addiu	$4,$4,%lo(D_QuitNetGame)

	lw	$3,64($16)
	lw	$31,20($sp)
	lui	$2,%hi(player_class)
	lw	$16,16($sp)
	sw	$3,%lo(player_class)($2)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_InitNetGame
	.size	D_InitNetGame, .-D_InitNetGame
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"TryRunTics: lowtic < gametic\000"
	.align	2
$LC3:
	.ascii	"gametic>lowtic\000"
	.text
	.align	2
	.globl	TryRunTics
	.set	nomips16
	.set	nomicromips
	.ent	TryRunTics
	.type	TryRunTics, @function
TryRunTics:
	.frame	$sp,88,$31		# vars= 32, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-88
	sw	$18,56($sp)
	lui	$18,%hi(ticdup)
	sw	$23,76($sp)
	sw	$22,72($sp)
	sw	$17,52($sp)
	sw	$31,84($sp)
	sw	$fp,80($sp)
	sw	$21,68($sp)
	sw	$20,64($sp)
	sw	$19,60($sp)
	jal	I_GetTime
	sw	$16,48($sp)

	lw	$3,%lo(ticdup)($18)
	lui	$22,%hi(singletics)
	div	$0,$2,$3
	lw	$3,%lo(singletics)($22)
	lui	$2,%hi(oldentertics.0)
	lw	$23,%lo(oldentertics.0)($2)
	mflo	$17
	beq	$3,$0,$L78
	sw	$17,%lo(oldentertics.0)($2)

	jal	BuildNewTic
	lui	$16,%hi(gametic)

	lw	$2,%lo(gametic)($16)
$L159:
	lw	$3,%lo(ticdup)($18)
	lui	$20,%hi(maketic)
	div	$0,$2,$3
	lui	$2,%hi(new_sync)
	lw	$19,%lo(maketic)($20)
	lw	$2,%lo(new_sync)($2)
	lui	$3,%hi(net_client_connected)
	lw	$5,%lo(net_client_connected)($3)
	sw	$3,24($sp)
	mflo	$21
	bne	$2,$0,$L80
	subu	$21,$19,$21

	subu	$23,$17,$23
	addiu	$3,$21,-1
	slt	$3,$23,$3
	bne	$3,$0,$L150
	slt	$3,$21,$23

	bne	$5,$0,$L151
	movz	$21,$23,$3

$L83:
	slt	$3,$0,$21
$L169:
	li	$2,1			# 0x1
	movz	$21,$2,$3
$L80:
	li	$2,1			# 0x1
	slt	$3,$0,$21
	movz	$21,$2,$3
	lui	$2,%hi(drone)
	sw	$2,20($sp)
	lui	$2,%hi(local_playeringame)
	move	$23,$2
	lui	$2,%hi($LC2)
	addiu	$2,$2,%lo($LC2)
	b	$L88
	move	$fp,$2

$L154:
	bne	$6,$0,$L161
	lw	$2,%lo(singletics)($22)

	lw	$2,%lo(gametic)($16)
$L165:
	lw	$3,%lo(ticdup)($18)
	div	$0,$2,$3
	mflo	$2
	addu	$2,$2,$21
	slt	$2,$19,$2
	beq	$2,$0,$L162
	addiu	$2,$21,-1

	lw	$2,%lo(singletics)($22)
$L161:
	bne	$2,$0,$L163
	lw	$2,%lo(gametic)($16)

	jal	NetUpdate.part.0
	nop

	lw	$2,%lo(gametic)($16)
$L163:
	lw	$3,%lo(ticdup)($18)
	lw	$19,%lo(maketic)($20)
	div	$0,$2,$3
	mflo	$2
	slt	$2,$19,$2
	bne	$2,$0,$L153
	nop

	jal	I_GetTime
	nop

	lw	$3,%lo(ticdup)($18)
	div	$0,$2,$3
	mflo	$2
	slt	$2,$17,$2
	bne	$2,$0,$L164
	lw	$31,84($sp)

$L157:
	jal	I_Sleep
	li	$4,1			# 0x1

	lw	$2,24($sp)
	lw	$5,%lo(net_client_connected)($2)
$L88:
	lw	$2,20($sp)
	beq	$5,$0,$L154
	lw	$6,%lo(drone)($2)

	addiu	$2,$23,%lo(local_playeringame)
	addiu	$4,$2,32
	move	$3,$0
$L96:
	bne	$3,$0,$L95
	nop

	lw	$3,0($2)
	sltu	$3,$0,$3
$L95:
	addiu	$2,$2,4
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L96
	.set	at
	nop

	beq	$6,$0,$L165
	lw	$2,%lo(gametic)($16)

	beq	$3,$0,$L161
	lw	$2,%lo(singletics)($22)

	lw	$2,%lo(gametic)($16)
	lw	$3,%lo(ticdup)($18)
	div	$0,$2,$3
	mflo	$2
	addu	$2,$2,$21
	slt	$2,$19,$2
	bne	$2,$0,$L161
	lw	$2,%lo(singletics)($22)

	addiu	$2,$21,-1
$L162:
	sw	$2,32($sp)
	lui	$2,%hi(local_playeringame)
	sw	$2,40($sp)
	li	$2,-2147483648			# 0xffffffff80000000
	addiu	$2,$2,127
	sw	$2,44($sp)
	lui	$2,%hi(ticdata)
	addiu	$2,$2,%lo(ticdata)
	sw	$2,36($sp)
	lui	$2,%hi($LC3)
	addiu	$2,$2,%lo($LC3)
	sw	$2,28($sp)
	lw	$2,20($sp)
	lui	$21,%hi(loop_interface)
	bne	$5,$0,$L97
	lw	$6,%lo(drone)($2)

$L156:
	bne	$6,$0,$L164
	lw	$31,84($sp)

	lw	$3,%lo(gametic)($16)
	lw	$2,%lo(ticdup)($18)
	lw	$4,44($sp)
	div	$0,$3,$2
	mflo	$3
	and	$3,$3,$4
	bgez	$3,$L166
	sll	$17,$3,2

	addiu	$3,$3,-1
	li	$4,-128			# 0xffffffffffffff80
	or	$3,$3,$4
	addiu	$3,$3,1
	sll	$17,$3,2
$L166:
	lw	$4,36($sp)
	addu	$17,$17,$3
	sll	$17,$17,5
	addu	$17,$4,$17
	sw	$0,132($17)
	sw	$0,136($17)
	sw	$0,140($17)
	sw	$0,144($17)
	sw	$0,148($17)
	sw	$0,152($17)
	sw	$0,156($17)
$L99:
	blez	$2,$L111
	nop

	lw	$5,36($sp)
	sll	$4,$3,2
	addu	$3,$4,$3
	sll	$3,$3,5
	addiu	$7,$5,128
	addiu	$20,$3,128
	addu	$23,$7,$3
	lw	$3,40($sp)
	lw	$4,%lo(gametic)($16)
	addiu	$3,$3,%lo(local_playeringame)
	addu	$20,$5,$20
	move	$fp,$0
	sw	$3,16($sp)
$L107:
	div	$0,$4,$2
	mflo	$2
	slt	$2,$19,$2
	bne	$2,$0,$L155
	nop

	lw	$4,16($sp)
$L160:
	move	$5,$20
	jal	memcpy
	li	$6,32			# 0x20

	lw	$2,%lo(loop_interface)($21)
	move	$4,$17
	lw	$2,8($2)
	jalr	$2
	move	$5,$20

	lw	$4,%lo(gametic)($16)
	move	$2,$17
	addiu	$4,$4,1
	sw	$4,%lo(gametic)($16)
$L106:
	lb	$3,5($2)
	bgez	$3,$L105
	sb	$0,4($2)

	sb	$0,5($2)
$L105:
	addiu	$2,$2,16
	.set	noat
	xor	$1,$2,$23
	bne	$1,$0,$L106
	.set	at
	nop

	lw	$2,%lo(ticdup)($18)
	addiu	$fp,$fp,1
	slt	$3,$fp,$2
	bne	$3,$0,$L107
	nop

$L111:
	lw	$2,%lo(singletics)($22)
	bne	$2,$0,$L167
	lw	$2,32($sp)

	jal	NetUpdate.part.0
	nop

	lw	$2,32($sp)
$L167:
	addiu	$2,$2,-1
	move	$3,$2
	sw	$2,32($sp)
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L77
	.set	at
	lw	$2,24($sp)

	lw	$5,%lo(net_client_connected)($2)
	lw	$2,20($sp)
	beq	$5,$0,$L156
	lw	$6,%lo(drone)($2)

$L97:
	lw	$2,40($sp)
	move	$3,$0
	addiu	$2,$2,%lo(local_playeringame)
	addiu	$4,$2,32
$L101:
	bne	$3,$0,$L100
	nop

	lw	$3,0($2)
	sltu	$3,$0,$3
$L100:
	addiu	$2,$2,4
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L101
	.set	at
	nop

	beq	$6,$0,$L102
	nop

	beq	$3,$0,$L164
	lw	$31,84($sp)

$L102:
	lw	$3,%lo(gametic)($16)
	lw	$2,%lo(ticdup)($18)
	lw	$4,44($sp)
	div	$0,$3,$2
	mflo	$3
	and	$3,$3,$4
	bgez	$3,$L103
	li	$4,-128			# 0xffffffffffffff80

	addiu	$3,$3,-1
	or	$3,$3,$4
	addiu	$3,$3,1
$L103:
	sll	$17,$3,2
	lw	$4,36($sp)
	addu	$17,$17,$3
	sll	$17,$17,5
	b	$L99
	addu	$17,$4,$17

$L153:
	jal	I_Error
	move	$4,$fp

	jal	I_GetTime
	nop

	lw	$3,%lo(ticdup)($18)
	div	$0,$2,$3
	mflo	$2
	slt	$2,$17,$2
	beq	$2,$0,$L157
	nop

$L77:
	lw	$31,84($sp)
$L164:
	lw	$fp,80($sp)
	lw	$23,76($sp)
	lw	$22,72($sp)
	lw	$21,68($sp)
	lw	$20,64($sp)
	lw	$19,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,88

$L78:
	jal	NetUpdate.part.0
	lui	$16,%hi(gametic)

	b	$L159
	lw	$2,%lo(gametic)($16)

$L150:
	beq	$5,$0,$L83
	addiu	$21,$23,1

$L151:
	lui	$3,%hi(frameon)
	lw	$4,%lo(frameon)($3)
	li	$7,8			# 0x8
	addiu	$4,$4,1
	sw	$4,%lo(frameon)($3)
	lui	$3,%hi(local_playeringame)
	b	$L86
	addiu	$3,$3,%lo(local_playeringame)

$L84:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L83
	.set	at
	nop

$L86:
	lw	$6,0($3)
	beq	$6,$0,$L84
	addiu	$3,$3,4

	beq	$2,$0,$L83
	lui	$2,%hi(recvtic)

	lw	$6,%lo(recvtic)($2)
	slt	$2,$6,$19
	bne	$2,$0,$L168
	lui	$7,%hi(oldnettics)

	lui	$3,%hi(lasttime)
	lw	$2,%lo(lasttime)($3)
	addiu	$2,$2,-1
	sw	$2,%lo(lasttime)($3)
$L168:
	lw	$9,%lo(oldnettics)($7)
	lui	$8,%hi(frameskip)
	andi	$2,$4,0x3
	sll	$2,$2,2
	addiu	$3,$8,%lo(frameskip)
	addu	$2,$2,$3
	slt	$6,$6,$9
	sw	$6,0($2)
	lw	$2,%lo(frameskip)($8)
	beq	$2,$0,$L83
	sw	$19,%lo(oldnettics)($7)

	lw	$2,4($3)
	beq	$2,$0,$L83
	nop

	lw	$2,8($3)
	beq	$2,$0,$L83
	nop

	lw	$2,12($3)
	beq	$2,$0,$L169
	slt	$3,$0,$21

	lui	$2,%hi(skiptics)
	li	$3,1			# 0x1
	b	$L83
	sw	$3,%lo(skiptics)($2)

$L155:
	jal	I_Error
	lw	$4,28($sp)

	b	$L160
	lw	$4,16($sp)

	.set	macro
	.set	reorder
	.end	TryRunTics
	.size	TryRunTics, .-TryRunTics
	.align	2
	.globl	D_RegisterLoopCallbacks
	.set	nomips16
	.set	nomicromips
	.ent	D_RegisterLoopCallbacks
	.type	D_RegisterLoopCallbacks, @function
D_RegisterLoopCallbacks:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(loop_interface)
	jr	$31
	sw	$4,%lo(loop_interface)($2)

	.set	macro
	.set	reorder
	.end	D_RegisterLoopCallbacks
	.size	D_RegisterLoopCallbacks, .-D_RegisterLoopCallbacks
	.local	oldentertics.0
	.comm	oldentertics.0,4,4
	.local	oldnettics
	.comm	oldnettics,4,4
	.local	frameskip
	.comm	frameskip,16,4
	.local	frameon
	.comm	frameon,4,4
	.globl	lasttime
	.section	.bss,"aw",@nobits
	.align	2
	.type	lasttime, @object
	.size	lasttime, 4
lasttime:
	.space	4
	.local	player_class
	.comm	player_class,4,4
	.local	local_playeringame
	.comm	local_playeringame,32,4
	.local	loop_interface
	.comm	loop_interface,4,4
	.data
	.align	2
	.type	new_sync, @object
	.size	new_sync, 4
new_sync:
	.word	1
	.globl	offsetms
	.section	.bss
	.align	2
	.type	offsetms, @object
	.size	offsetms, 4
offsetms:
	.space	4
	.globl	ticdup
	.align	2
	.type	ticdup, @object
	.size	ticdup, 4
ticdup:
	.space	4
	.local	skiptics
	.comm	skiptics,4,4
	.globl	singletics
	.align	2
	.type	singletics, @object
	.size	singletics, 4
singletics:
	.space	4
	.globl	gametic
	.align	2
	.type	gametic, @object
	.size	gametic, 4
gametic:
	.space	4
	.local	recvtic
	.comm	recvtic,4,4
	.local	maketic
	.comm	maketic,4,4
	.local	ticdata
	.comm	ticdata,20480,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
