	.file	1 "d_main.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	D_GrabMouseCallback
	.set	nomips16
	.set	nomicromips
	.ent	D_GrabMouseCallback
	.type	D_GrabMouseCallback, @function
D_GrabMouseCallback:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(demoplayback)
	lui	$4,%hi(menuactive)
	lw	$7,%lo(demoplayback)($3)
	lw	$6,%lo(menuactive)($4)
	lui	$2,%hi(gamestate)
	lui	$4,%hi(advancedemo)
	lui	$3,%hi(drone)
	lw	$5,%lo(advancedemo)($4)
	lw	$2,%lo(gamestate)($2)
	lw	$3,%lo(drone)($3)
	lui	$4,%hi(paused)
	lw	$4,%lo(paused)($4)
	or	$2,$2,$7
	or	$3,$3,$6
	or	$2,$2,$5
	or	$3,$3,$4
	or	$2,$2,$3
	jr	$31
	sltu	$2,$2,1

	.set	macro
	.set	reorder
	.end	D_GrabMouseCallback
	.size	D_GrabMouseCallback, .-D_GrabMouseCallback
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC1:
	.ascii	"-testcontrols\000"
	.align	2
$LC2:
	.ascii	"ENDOOM\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	D_Endoom
	.type	D_Endoom, @function
D_Endoom:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(show_endoom)
	lw	$2,%lo(show_endoom)($2)
	beq	$2,$0,$L14
	lui	$2,%hi(main_loop_started)

	lw	$2,%lo(main_loop_started)($2)
	beq	$2,$0,$L14
	lui	$2,%hi(screensaver_mode)

	lw	$2,%lo(screensaver_mode)($2)
	bne	$2,$0,$L14
	lui	$4,%hi($LC1)

	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC1)

	blez	$2,$L13
	lw	$31,20($sp)

	jr	$31
	addiu	$sp,$sp,24

$L14:
	jr	$31
	nop

$L13:
	lui	$4,%hi($LC2)
	li	$5,1			# 0x1
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC2)

	jal	I_Endoom
	move	$4,$2

	jal	exit
	move	$4,$0

	.set	macro
	.set	reorder
	.end	D_Endoom
	.size	D_Endoom, .-D_Endoom
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"PLAYPAL\000"
	.align	2
$LC4:
	.ascii	"M_PAUSE\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	D_Display.part.0
	.type	D_Display.part.0, @function
D_Display.part.0:
	.frame	$sp,72,$31		# vars= 8, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(setsizeneeded)
	lw	$2,%lo(setsizeneeded)($2)
	addiu	$sp,$sp,-72
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	bne	$2,$0,$L89
	sw	$16,32($sp)

	lui	$17,%hi(oldgamestate.6)
$L16:
	lui	$18,%hi(wipegamestate)
	lui	$16,%hi(gamestate)
	lw	$2,%lo(wipegamestate)($18)
	lw	$3,%lo(gamestate)($16)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L100
	.set	at
	li	$7,200			# 0xc8

	move	$19,$0
$L17:
	beq	$2,$0,$L18
	lui	$20,%hi(gametic)

	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L19
	.set	at
	sltu	$3,$2,3

	bne	$3,$0,$L21
	li	$3,3			# 0x3

$L116:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L96
	.set	at
	lui	$2,%hi(pagename)

	lw	$4,%lo(pagename)($2)
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	move	$6,$2
	move	$5,$0
	jal	V_DrawPatch
	move	$4,$0

$L96:
	lui	$22,%hi(inhelpscreensstate.3)
$L115:
	lui	$20,%hi(inhelpscreens)
$L22:
	jal	I_UpdateNoBlit
	nop

	lw	$2,%lo(gamestate)($16)
	bne	$2,$0,$L111
	lw	$3,%lo(oldgamestate.6)($17)

$L103:
	lui	$2,%hi(automapactive)
	lw	$3,%lo(automapactive)($2)
	lui	$21,%hi(gametic)
	beq	$3,$0,$L101
	lw	$2,%lo(gametic)($21)

$L29:
	beq	$2,$0,$L112
	lw	$3,%lo(gamestate)($16)

	jal	HU_Drawer
	nop

	lw	$3,%lo(gamestate)($16)
$L112:
	lw	$2,%lo(oldgamestate.6)($17)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L32
	.set	at
	nop

	bne	$3,$0,$L113
	lui	$4,%hi($LC3)

$L31:
	bne	$2,$0,$L37
	lui	$21,%hi(viewactivestate.2)

	lui	$2,%hi(automapactive)
$L117:
	lw	$2,%lo(automapactive)($2)
	bne	$2,$0,$L109
	lui	$fp,%hi(menuactive)

	lui	$2,%hi(scaledviewwidth)
	lw	$3,%lo(scaledviewwidth)($2)
	li	$2,320			# 0x140
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L36
	.set	at
	lui	$23,%hi(menuactivestate.1)

	lw	$2,%lo(menuactive)($fp)
	lw	$3,%lo(menuactivestate.1)($23)
	or	$2,$2,$3
	bne	$2,$0,$L114
	lui	$2,%hi(borderdrawcount.5)

	lw	$2,%lo(viewactivestate.2)($21)
	bne	$2,$0,$L42
	lui	$2,%hi(borderdrawcount.5)

$L114:
	li	$3,3			# 0x3
	sw	$3,%lo(borderdrawcount.5)($2)
$L43:
	jal	R_DrawViewBorder
	sw	$2,24($sp)

	lw	$2,24($sp)
	lw	$3,%lo(borderdrawcount.5)($2)
	addiu	$3,$3,-1
	b	$L36
	sw	$3,%lo(borderdrawcount.5)($2)

$L18:
	lw	$2,%lo(gametic)($20)
	beq	$2,$0,$L115
	lui	$22,%hi(inhelpscreensstate.3)

	jal	HU_Erase
	nop

	lw	$2,%lo(gamestate)($16)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L19
	.set	at
	sltu	$3,$2,3

	beq	$3,$0,$L116
	li	$3,3			# 0x3

	beq	$2,$0,$L102
	lw	$2,%lo(gametic)($20)

$L21:
	jal	WI_Drawer
	lui	$22,%hi(inhelpscreensstate.3)

	jal	I_UpdateNoBlit
	lui	$20,%hi(inhelpscreens)

	lw	$2,%lo(gamestate)($16)
	beq	$2,$0,$L103
	lw	$3,%lo(oldgamestate.6)($17)

$L111:
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L50
	.set	at
	lui	$4,%hi($LC3)

$L97:
	lui	$21,%hi(viewactivestate.2)
	lui	$fp,%hi(menuactive)
$L109:
	lui	$23,%hi(menuactivestate.1)
$L36:
	lui	$2,%hi(testcontrols)
	lw	$2,%lo(testcontrols)($2)
	bne	$2,$0,$L104
	lui	$2,%hi(testcontrols_mousespeed)

	lui	$3,%hi(viewactive)
$L110:
	lw	$5,%lo(viewactive)($3)
	lui	$3,%hi(paused)
	lw	$2,%lo(gamestate)($16)
	lw	$6,%lo(menuactive)($fp)
	lw	$4,%lo(inhelpscreens)($20)
	lw	$3,%lo(paused)($3)
	sw	$6,%lo(menuactivestate.1)($23)
	sw	$5,%lo(viewactivestate.2)($21)
	sw	$4,%lo(inhelpscreensstate.3)($22)
	sw	$2,%lo(wipegamestate)($18)
	beq	$3,$0,$L45
	sw	$2,%lo(oldgamestate.6)($17)

	lui	$2,%hi(automapactive)
	lw	$2,%lo(automapactive)($2)
	bne	$2,$0,$L46
	li	$17,4			# 0x4

	lui	$2,%hi(viewwindowy)
	lw	$17,%lo(viewwindowy)($2)
	addiu	$17,$17,4
$L46:
	lui	$2,%hi(scaledviewwidth)
	lw	$2,%lo(scaledviewwidth)($2)
	lui	$3,%hi(viewwindowx)
	addiu	$2,$2,-68
	srl	$16,$2,31
	lw	$3,%lo(viewwindowx)($3)
	addu	$16,$16,$2
	lui	$4,%hi($LC4)
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC4)
	sra	$16,$16,1
	jal	W_CacheLumpName
	addu	$16,$16,$3

	move	$6,$2
	move	$5,$17
	jal	V_DrawPatchDirect
	move	$4,$16

$L45:
	jal	M_Drawer
	nop

	jal	NetUpdate
	nop

	beq	$19,$0,$L105
	li	$7,200			# 0xc8

	li	$6,320			# 0x140
	move	$5,$0
	jal	wipe_EndScreen
	move	$4,$0

	jal	I_GetTime
	li	$19,200			# 0xc8

	addiu	$18,$2,-1
$L48:
	jal	I_GetTime
	nop

	subu	$17,$2,$18
	li	$4,1			# 0x1
	jal	I_Sleep
	move	$16,$2

	blez	$17,$L48
	li	$7,320			# 0x140

	move	$6,$0
	move	$5,$0
	li	$4,1			# 0x1
	sw	$17,20($sp)
	jal	wipe_ScreenWipe
	sw	$19,16($sp)

	jal	I_UpdateNoBlit
	move	$17,$2

	jal	M_Drawer
	nop

	jal	I_FinishUpdate
	nop

	bne	$17,$0,$L106
	move	$18,$16

	b	$L48
	nop

$L101:
	bne	$2,$0,$L30
	lw	$2,%lo(oldgamestate.6)($17)

	beq	$2,$0,$L31
	nop

$L37:
	lui	$21,%hi(viewactivestate.2)
	jal	R_FillBackScreen
	sw	$0,%lo(viewactivestate.2)($21)

	lw	$2,%lo(gamestate)($16)
	beq	$2,$0,$L117
	lui	$2,%hi(automapactive)

	b	$L109
	lui	$fp,%hi(menuactive)

$L50:
$L113:
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC3)

	jal	I_SetPalette
	move	$4,$2

	lw	$2,%lo(gamestate)($16)
$L32:
	bne	$2,$0,$L97
	lw	$2,%lo(oldgamestate.6)($17)

	b	$L31
	nop

$L19:
	jal	F_Drawer
	lui	$22,%hi(inhelpscreensstate.3)

	b	$L22
	lui	$20,%hi(inhelpscreens)

$L106:
	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L100:
	li	$6,320			# 0x140
	move	$5,$0
	jal	wipe_StartScreen
	move	$4,$0

	li	$19,1			# 0x1
	b	$L17
	lw	$2,%lo(gamestate)($16)

$L105:
	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	j	I_FinishUpdate
	addiu	$sp,$sp,72

$L104:
	jal	V_DrawMouseSpeedBox
	lw	$4,%lo(testcontrols_mousespeed)($2)

	b	$L110
	lui	$3,%hi(viewactive)

$L89:
	jal	R_ExecuteSetViewSize
	lui	$17,%hi(oldgamestate.6)

	li	$2,-1			# 0xffffffffffffffff
	sw	$2,%lo(oldgamestate.6)($17)
	li	$3,3			# 0x3
	lui	$2,%hi(borderdrawcount.5)
	b	$L16
	sw	$3,%lo(borderdrawcount.5)($2)

$L30:
	lui	$2,%hi(displayplayer)
	lw	$3,%lo(displayplayer)($2)
	lui	$4,%hi(players)
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,5
	addiu	$4,$4,%lo(players)
	jal	R_RenderPlayerView
	addu	$4,$4,$2

	lw	$2,%lo(gamestate)($16)
	bne	$2,$0,$L111
	lw	$3,%lo(oldgamestate.6)($17)

	b	$L29
	lw	$2,%lo(gametic)($21)

$L42:
	lw	$3,%lo(borderdrawcount.5)($2)
	beq	$3,$0,$L36
	nop

	b	$L43
	nop

$L102:
	beq	$2,$0,$L115
	lui	$22,%hi(inhelpscreensstate.3)

	lui	$2,%hi(automapactive)
	lw	$2,%lo(automapactive)($2)
	bne	$2,$0,$L107
	nop

	lui	$23,%hi(viewheight)
$L108:
	bne	$19,$0,$L52
	lw	$2,%lo(viewheight)($23)

	li	$3,200			# 0xc8
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L53
	.set	at
	move	$5,$0

	lui	$21,%hi(fullscreen.4)
	lw	$5,%lo(fullscreen.4)($21)
	sltu	$5,$0,$5
$L26:
	lui	$22,%hi(inhelpscreensstate.3)
	lw	$3,%lo(inhelpscreensstate.3)($22)
	beq	$3,$0,$L27
	lui	$20,%hi(inhelpscreens)

	lw	$4,%lo(inhelpscreens)($20)
	li	$3,1			# 0x1
	movz	$5,$3,$4
$L27:
	xori	$2,$2,0xc8
	jal	ST_Drawer
	sltu	$4,$2,1

	lw	$2,%lo(viewheight)($23)
	xori	$2,$2,0xc8
	sltu	$2,$2,1
	b	$L22
	sw	$2,%lo(fullscreen.4)($21)

$L52:
	move	$5,$19
	b	$L26
	lui	$21,%hi(fullscreen.4)

$L107:
	jal	AM_Drawer
	lui	$23,%hi(viewheight)

	b	$L108
	nop

$L53:
	b	$L26
	lui	$21,%hi(fullscreen.4)

	.set	macro
	.set	reorder
	.end	D_Display.part.0
	.size	D_Display.part.0, .-D_Display.part.0
	.align	2
	.globl	D_ProcessEvents
	.set	nomips16
	.set	nomicromips
	.ent	D_ProcessEvents
	.type	D_ProcessEvents, @function
D_ProcessEvents:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(storedemo)
	lw	$2,%lo(storedemo)($2)
	bne	$2,$0,$L132
	nop

	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	sw	$16,16($sp)
$L120:
	jal	D_PopEvent
	nop

	move	$16,$2
	beq	$2,$0,$L131
	move	$4,$2

$L121:
	jal	M_Responder
	nop

	bne	$2,$0,$L120
	move	$4,$16

	jal	G_Responder
	nop

	jal	D_PopEvent
	nop

	move	$16,$2
	bne	$2,$0,$L121
	move	$4,$2

$L131:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L132:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	D_ProcessEvents
	.size	D_ProcessEvents, .-D_ProcessEvents
	.align	2
	.globl	D_Display
	.set	nomips16
	.set	nomicromips
	.ent	D_Display
	.type	D_Display, @function
D_Display:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(nodrawers)
	lw	$2,%lo(nodrawers)($2)
	bne	$2,$0,$L135
	nop

	j	D_Display.part.0
	nop

$L135:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	D_Display
	.size	D_Display, .-D_Display
	.section	.rodata.str1.4
	.align	2
$LC5:
	.ascii	"mouse_sensitivity\000"
	.align	2
$LC6:
	.ascii	"sfx_volume\000"
	.align	2
$LC7:
	.ascii	"music_volume\000"
	.align	2
$LC8:
	.ascii	"show_messages\000"
	.align	2
$LC9:
	.ascii	"screenblocks\000"
	.align	2
$LC10:
	.ascii	"detaillevel\000"
	.align	2
$LC11:
	.ascii	"snd_channels\000"
	.align	2
$LC12:
	.ascii	"vanilla_savegame_limit\000"
	.align	2
$LC13:
	.ascii	"vanilla_demo_limit\000"
	.align	2
$LC14:
	.ascii	"show_endoom\000"
	.align	2
$LC15:
	.ascii	"chatmacro%i\000"
	.text
	.align	2
	.globl	D_BindVariables
	.set	nomips16
	.set	nomicromips
	.ent	D_BindVariables
	.type	D_BindVariables, @function
D_BindVariables:
	.frame	$sp,56,$31		# vars= 16, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$31,52($sp)
	sw	$19,48($sp)
	sw	$18,44($sp)
	sw	$17,40($sp)
	jal	M_ApplyPlatformDefaults
	sw	$16,36($sp)

	jal	I_BindVideoVariables
	lui	$17,%hi(chat_macros)

	jal	I_BindJoystickVariables
	lui	$18,%hi($LC15)

	jal	I_BindSoundVariables
	addiu	$17,$17,%lo(chat_macros)

	jal	M_BindBaseControls
	move	$16,$0

	jal	M_BindWeaponControls
	addiu	$18,$18,%lo($LC15)

	jal	M_BindMapControls
	li	$19,10			# 0xa

	jal	M_BindMenuControls
	nop

	jal	M_BindChatControls
	li	$4,4			# 0x4

	li	$6,103			# 0x67
	lui	$3,%hi(key_multi_msgplayer)
	addiu	$2,$3,%lo(key_multi_msgplayer)
	sw	$6,%lo(key_multi_msgplayer)($3)
	li	$3,105			# 0x69
	sw	$3,4($2)
	lui	$5,%hi(mouseSensitivity)
	li	$3,98			# 0x62
	lui	$4,%hi($LC5)
	sw	$3,8($2)
	addiu	$5,$5,%lo(mouseSensitivity)
	li	$3,114			# 0x72
	addiu	$4,$4,%lo($LC5)
	jal	M_BindVariable
	sw	$3,12($2)

	lui	$5,%hi(sfxVolume)
	lui	$4,%hi($LC6)
	addiu	$5,$5,%lo(sfxVolume)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC6)

	lui	$5,%hi(musicVolume)
	lui	$4,%hi($LC7)
	addiu	$5,$5,%lo(musicVolume)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC7)

	lui	$5,%hi(showMessages)
	lui	$4,%hi($LC8)
	addiu	$5,$5,%lo(showMessages)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC8)

	lui	$5,%hi(screenblocks)
	lui	$4,%hi($LC9)
	addiu	$5,$5,%lo(screenblocks)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC9)

	lui	$5,%hi(detailLevel)
	lui	$4,%hi($LC10)
	addiu	$5,$5,%lo(detailLevel)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC10)

	lui	$5,%hi(snd_channels)
	lui	$4,%hi($LC11)
	addiu	$5,$5,%lo(snd_channels)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC11)

	lui	$5,%hi(vanilla_savegame_limit)
	lui	$4,%hi($LC12)
	addiu	$5,$5,%lo(vanilla_savegame_limit)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC12)

	lui	$5,%hi(vanilla_demo_limit)
	lui	$4,%hi($LC13)
	addiu	$5,$5,%lo(vanilla_demo_limit)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC13)

	lui	$5,%hi(show_endoom)
	lui	$4,%hi($LC14)
	addiu	$5,$5,%lo(show_endoom)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC14)

$L137:
	move	$7,$16
	move	$6,$18
	addiu	$4,$sp,16
	jal	M_snprintf
	li	$5,12			# 0xc

	addiu	$16,$16,1
	move	$5,$17
	jal	M_BindVariable
	addiu	$4,$sp,16

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L137
	.set	at
	addiu	$17,$17,4

	lw	$31,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	D_BindVariables
	.size	D_BindVariables, .-D_BindVariables
	.align	2
	.globl	doomgeneric_Tick
	.set	nomips16
	.set	nomicromips
	.ent	doomgeneric_Tick
	.type	doomgeneric_Tick, @function
doomgeneric_Tick:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	I_StartFrame
	nop

	jal	TryRunTics
	nop

	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	jal	S_UpdateSounds
	lw	$4,0($2)

	lui	$2,%hi(screenvisible)
	lw	$2,%lo(screenvisible)($2)
	beq	$2,$0,$L146
	lw	$31,20($sp)

	lui	$2,%hi(nodrawers)
	lw	$2,%lo(nodrawers)($2)
	bne	$2,$0,$L140
	nop

	j	D_Display.part.0
	addiu	$sp,$sp,24

$L140:
$L146:
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	doomgeneric_Tick
	.size	doomgeneric_Tick, .-doomgeneric_Tick
	.section	.rodata.str1.4
	.align	2
$LC16:
	.ascii	" WARNING: You are playing using one of the Doom Classic\012"
	.ascii	" IWAD files shipped with the Doom 3: BFG Edition. These "
	.ascii	"are\012 known to be incompatible with the regular IWAD f"
	.ascii	"iles and\012 may cause demos and network games to get ou"
	.ascii	"t of sync.\012\000"
	.text
	.align	2
	.globl	D_DoomLoop
	.set	nomips16
	.set	nomicromips
	.ent	D_DoomLoop
	.type	D_DoomLoop, @function
D_DoomLoop:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(bfgedition)
	addiu	$sp,$sp,-24
	lw	$2,%lo(bfgedition)($2)
	sw	$16,16($sp)
	lui	$16,%hi(demorecording)
	lw	$3,%lo(demorecording)($16)
	beq	$2,$0,$L148
	sw	$31,20($sp)

	lui	$2,%hi(gameaction)
	lw	$4,%lo(gameaction)($2)
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L149
	.set	at
	lui	$2,%hi(netgame)

	lw	$2,%lo(netgame)($2)
	or	$3,$3,$2
	beq	$3,$0,$L167
	li	$3,1			# 0x1

$L149:
	lui	$4,%hi($LC16)
	jal	printf
	addiu	$4,$4,%lo($LC16)

$L148:
	lw	$2,%lo(demorecording)($16)
	beq	$2,$0,$L167
	li	$3,1			# 0x1

	jal	G_BeginRecording
	nop

	li	$3,1			# 0x1
$L167:
	lui	$2,%hi(main_loop_started)
	jal	TryRunTics
	sw	$3,%lo(main_loop_started)($2)

	lui	$2,%hi(gamedescription)
	jal	I_SetWindowTitle
	lw	$4,%lo(gamedescription)($2)

	jal	I_GraphicsCheckCommandLine
	nop

	lui	$4,%hi(D_GrabMouseCallback)
	jal	I_SetGrabMouseCallback
	addiu	$4,$4,%lo(D_GrabMouseCallback)

	jal	I_InitGraphics
	nop

	jal	I_EnableLoadingDisk
	nop

	jal	V_RestoreBuffer
	nop

	jal	R_ExecuteSetViewSize
	nop

	jal	D_StartGameLoop
	nop

	lui	$2,%hi(testcontrols)
	lw	$2,%lo(testcontrols)($2)
	beq	$2,$0,$L152
	lui	$2,%hi(gamestate)

	lw	$3,%lo(gamestate)($2)
	lui	$2,%hi(wipegamestate)
	sw	$3,%lo(wipegamestate)($2)
$L152:
	jal	I_StartFrame
	nop

	jal	TryRunTics
	nop

	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	jal	S_UpdateSounds
	lw	$4,0($2)

	lui	$2,%hi(screenvisible)
	lw	$2,%lo(screenvisible)($2)
	beq	$2,$0,$L168
	lw	$31,20($sp)

	lui	$2,%hi(nodrawers)
	lw	$2,%lo(nodrawers)($2)
	bne	$2,$0,$L168
	lw	$16,16($sp)

	j	D_Display.part.0
	addiu	$sp,$sp,24

$L168:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_DoomLoop
	.size	D_DoomLoop, .-D_DoomLoop
	.align	2
	.globl	D_PageTicker
	.set	nomips16
	.set	nomicromips
	.ent	D_PageTicker
	.type	D_PageTicker, @function
D_PageTicker:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(pagetic)
	lw	$2,%lo(pagetic)($3)
	addiu	$2,$2,-1
	bltz	$2,$L171
	sw	$2,%lo(pagetic)($3)

	jr	$31
	nop

$L171:
	lui	$2,%hi(advancedemo)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(advancedemo)($2)

	.set	macro
	.set	reorder
	.end	D_PageTicker
	.size	D_PageTicker, .-D_PageTicker
	.align	2
	.globl	D_PageDrawer
	.set	nomips16
	.set	nomicromips
	.ent	D_PageDrawer
	.type	D_PageDrawer, @function
D_PageDrawer:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(pagename)
	lw	$4,%lo(pagename)($2)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	lw	$31,20($sp)
	move	$6,$2
	move	$5,$0
	move	$4,$0
	j	V_DrawPatch
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_PageDrawer
	.size	D_PageDrawer, .-D_PageDrawer
	.align	2
	.globl	D_AdvanceDemo
	.set	nomips16
	.set	nomicromips
	.ent	D_AdvanceDemo
	.type	D_AdvanceDemo, @function
D_AdvanceDemo:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(advancedemo)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(advancedemo)($2)

	.set	macro
	.set	reorder
	.end	D_AdvanceDemo
	.size	D_AdvanceDemo, .-D_AdvanceDemo
	.section	.rodata.str1.4
	.align	2
$LC17:
	.ascii	"TITLEPIC\000"
	.align	2
$LC18:
	.ascii	"demo1\000"
	.align	2
$LC19:
	.ascii	"CREDIT\000"
	.align	2
$LC20:
	.ascii	"demo2\000"
	.align	2
$LC21:
	.ascii	"HELP2\000"
	.align	2
$LC22:
	.ascii	"demo3\000"
	.align	2
$LC23:
	.ascii	"demo4\000"
	.align	2
$LC24:
	.ascii	"titlepic\000"
	.align	2
$LC25:
	.ascii	"INTERPIC\000"
	.text
	.align	2
	.globl	D_DoAdvanceDemo
	.set	nomips16
	.set	nomicromips
	.ent	D_DoAdvanceDemo
	.type	D_DoAdvanceDemo, @function
D_DoAdvanceDemo:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	lui	$4,%hi(players)
	sll	$5,$3,3
	addu	$5,$5,$3
	sll	$5,$5,5
	addiu	$4,$4,%lo(players)
	addiu	$sp,$sp,-24
	addu	$4,$4,$5
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	sw	$31,20($sp)
	sw	$16,16($sp)
	sw	$0,4($4)
	lui	$4,%hi(advancedemo)
	lui	$6,%hi(demosequence)
	sw	$0,%lo(advancedemo)($4)
	lui	$4,%hi(usergame)
	lw	$3,%lo(demosequence)($6)
	addiu	$2,$2,-6
	sw	$0,%lo(usergame)($4)
	lui	$4,%hi(paused)
	sw	$0,%lo(paused)($4)
	sltu	$2,$2,2
	lui	$4,%hi(gameaction)
	sw	$0,%lo(gameaction)($4)
	bne	$2,$0,$L198
	addiu	$3,$3,1

	li	$2,715784192			# 0x2aaa0000
	ori	$2,$2,0xaaab
	mult	$3,$2
	sra	$4,$3,31
	mfhi	$2
	subu	$2,$2,$4
	sll	$4,$2,1
	addu	$2,$4,$2
	sll	$2,$2,1
	subu	$2,$3,$2
$L179:
	sltu	$3,$2,7
	beq	$3,$0,$L180
	sw	$2,%lo(demosequence)($6)

	lui	$3,%hi($L182)
	sll	$2,$2,2
	addiu	$3,$3,%lo($L182)
	addu	$2,$3,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L182:
	.word	$L188
	.word	$L187
	.word	$L186
	.word	$L185
	.word	$L184
	.word	$L183
	.word	$L181
	.text
$L188:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L199
	.set	at
	li	$4,66			# 0x42

	li	$4,29			# 0x1d
	lui	$2,%hi(pagetic)
	li	$3,170			# 0xaa
$L196:
	sw	$3,%lo(pagetic)($2)
	lui	$2,%hi(gamestate)
	li	$3,3			# 0x3
	sw	$3,%lo(gamestate)($2)
$L197:
	lui	$2,%hi($LC17)
	lui	$3,%hi(pagename)
	addiu	$2,$2,%lo($LC17)
	jal	S_StartMusic
	sw	$2,%lo(pagename)($3)

$L180:
	lui	$2,%hi(bfgedition)
$L203:
	lw	$2,%lo(bfgedition)($2)
	bne	$2,$0,$L200
	lui	$16,%hi(pagename)

$L177:
	lw	$31,20($sp)
$L204:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L198:
	li	$2,-1840709632			# 0xffffffff92490000
	addiu	$2,$2,9363
	mult	$3,$2
	sra	$4,$3,31
	mfhi	$9
	addu	$2,$3,$9
	sra	$2,$2,2
	subu	$2,$2,$4
	sll	$4,$2,3
	subu	$2,$4,$2
	b	$L179
	subu	$2,$3,$2

$L200:
	lui	$5,%hi($LC17)
	lw	$4,%lo(pagename)($16)
	jal	strcasecmp
	addiu	$5,$5,%lo($LC17)

	bne	$2,$0,$L204
	lw	$31,20($sp)

	lui	$4,%hi($LC24)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC24)

	bgez	$2,$L204
	lw	$31,20($sp)

	lui	$2,%hi($LC25)
	addiu	$2,$2,%lo($LC25)
	b	$L177
	sw	$2,%lo(pagename)($16)

$L183:
	lui	$4,%hi($LC22)
	jal	G_DeferedPlayDemo
	addiu	$4,$4,%lo($LC22)

	b	$L203
	lui	$2,%hi(bfgedition)

$L181:
	lui	$4,%hi($LC23)
	jal	G_DeferedPlayDemo
	addiu	$4,$4,%lo($LC23)

	b	$L203
	lui	$2,%hi(bfgedition)

$L187:
	lui	$4,%hi($LC18)
	jal	G_DeferedPlayDemo
	addiu	$4,$4,%lo($LC18)

	b	$L203
	lui	$2,%hi(bfgedition)

$L186:
	lui	$2,%hi(pagetic)
	li	$3,200			# 0xc8
	sw	$3,%lo(pagetic)($2)
	lui	$2,%hi(gamestate)
	li	$3,3			# 0x3
	sw	$3,%lo(gamestate)($2)
	lui	$2,%hi($LC19)
	lui	$3,%hi(pagename)
	addiu	$2,$2,%lo($LC19)
	b	$L180
	sw	$2,%lo(pagename)($3)

$L185:
	lui	$4,%hi($LC20)
	jal	G_DeferedPlayDemo
	addiu	$4,$4,%lo($LC20)

	b	$L203
	lui	$2,%hi(bfgedition)

$L184:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	lui	$5,%hi(gamestate)
	li	$2,3			# 0x3
	li	$4,2			# 0x2
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L201
	.set	at
	sw	$2,%lo(gamestate)($5)

	lui	$4,%hi(pagetic)
	li	$5,200			# 0xc8
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L202
	.set	at
	sw	$5,%lo(pagetic)($4)

	lui	$2,%hi($LC21)
	lui	$3,%hi(pagename)
	addiu	$2,$2,%lo($LC21)
	b	$L180
	sw	$2,%lo(pagename)($3)

$L199:
	lui	$2,%hi(pagetic)
	b	$L196
	li	$3,385			# 0x181

$L202:
	lui	$2,%hi($LC19)
	lui	$3,%hi(pagename)
	addiu	$2,$2,%lo($LC19)
	b	$L180
	sw	$2,%lo(pagename)($3)

$L201:
	lui	$2,%hi(pagetic)
	li	$3,385			# 0x181
	li	$4,66			# 0x42
	b	$L197
	sw	$3,%lo(pagetic)($2)

	.set	macro
	.set	reorder
	.end	D_DoAdvanceDemo
	.size	D_DoAdvanceDemo, .-D_DoAdvanceDemo
	.align	2
	.globl	D_StartTitle
	.set	nomips16
	.set	nomicromips
	.ent	D_StartTitle
	.type	D_StartTitle, @function
D_StartTitle:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gameaction)
	li	$3,-1			# 0xffffffffffffffff
	sw	$0,%lo(gameaction)($2)
	lui	$2,%hi(demosequence)
	sw	$3,%lo(demosequence)($2)
	lui	$2,%hi(advancedemo)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(advancedemo)($2)

	.set	macro
	.set	reorder
	.end	D_StartTitle
	.size	D_StartTitle, .-D_StartTitle
	.section	.rodata.str1.4
	.align	2
$LC26:
	.ascii	"MAP01\000"
	.align	2
$LC27:
	.ascii	"E1M1\000"
	.align	2
$LC28:
	.ascii	"Unknown or invalid IWAD file.\000"
	.align	2
$LC29:
	.ascii	"E4M1\000"
	.align	2
$LC30:
	.ascii	"E3M1\000"
	.align	2
$LC31:
	.ascii	"-pack\000"
	.align	2
$LC32:
	.ascii	"doom2\000"
	.align	2
$LC33:
	.ascii	"tnt\000"
	.align	2
$LC34:
	.ascii	"plutonia\000"
	.align	2
$LC35:
	.ascii	"Valid mission packs are:\012\000"
	.align	2
$LC36:
	.ascii	"\011%s\012\000"
	.align	2
$LC37:
	.ascii	"Unknown mission pack name: %s\000"
	.text
	.align	2
	.globl	D_IdentifyVersion
	.set	nomips16
	.set	nomicromips
	.ent	D_IdentifyVersion
	.type	D_IdentifyVersion, @function
D_IdentifyVersion:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$22,40($sp)
	lui	$22,%hi(gamemission)
	lw	$2,%lo(gamemission)($22)
	li	$3,9			# 0x9
	sw	$31,44($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L207
	.set	at
	sw	$16,16($sp)

$L229:
	li	$3,-5			# 0xfffffffffffffffb
$L235:
	and	$2,$2,$3
$L208:
	beq	$2,$0,$L230
	lui	$2,%hi(gamemode)

	lui	$4,%hi($LC31)
	li	$3,2			# 0x2
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC31)
	jal	M_CheckParmWithArgs
	sw	$3,%lo(gamemode)($2)

	bgtz	$2,$L231
	lui	$3,%hi(myargv)

$L206:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L230:
	lui	$4,%hi($LC29)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC29)

	blez	$2,$L213
	lw	$31,44($sp)

	lui	$2,%hi(gamemode)
	li	$3,3			# 0x3
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$3,%lo(gamemode)($2)
	jr	$31
	addiu	$sp,$sp,48

$L207:
	lui	$21,%hi(numlumps)
	lw	$2,%lo(numlumps)($21)
	beq	$2,$0,$L209
	lui	$20,%hi($LC26)

	lui	$19,%hi($LC27)
	move	$16,$0
	move	$17,$0
	lui	$18,%hi(lumpinfo)
	addiu	$20,$20,%lo($LC26)
	b	$L211
	addiu	$19,$19,%lo($LC27)

$L233:
	lw	$4,%lo(lumpinfo)($18)
	jal	strncasecmp
	addu	$4,$4,$16

	beq	$2,$0,$L219
	move	$2,$0

	lw	$2,%lo(numlumps)($21)
	sltu	$2,$17,$2
	beq	$2,$0,$L232
	addiu	$16,$16,28

$L211:
	lw	$4,%lo(lumpinfo)($18)
	move	$5,$20
	li	$6,8			# 0x8
	jal	strncasecmp
	addu	$4,$4,$16

	addiu	$17,$17,1
	li	$6,8			# 0x8
	bne	$2,$0,$L233
	move	$5,$19

	li	$2,1			# 0x1
	b	$L208
	sw	$2,%lo(gamemission)($22)

$L231:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$16,0($2)
	lui	$18,%hi($LC32)
	addiu	$5,$18,%lo($LC32)
	jal	strcasecmp
	move	$4,$16

	beq	$2,$0,$L216
	lui	$19,%hi($LC33)

	addiu	$5,$19,%lo($LC33)
	jal	strcasecmp
	move	$4,$16

	beq	$2,$0,$L220
	lui	$20,%hi($LC34)

	addiu	$5,$20,%lo($LC34)
	jal	strcasecmp
	move	$4,$16

	beq	$2,$0,$L234
	lui	$4,%hi($LC35)

	lui	$17,%hi($LC36)
	jal	printf
	addiu	$4,$4,%lo($LC35)

	addiu	$5,$18,%lo($LC32)
	jal	printf
	addiu	$4,$17,%lo($LC36)

	addiu	$5,$19,%lo($LC33)
	jal	printf
	addiu	$4,$17,%lo($LC36)

	addiu	$4,$17,%lo($LC36)
	jal	printf
	addiu	$5,$20,%lo($LC34)

	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$5,$16
	lui	$4,%hi($LC37)
	lw	$16,16($sp)
	addiu	$4,$4,%lo($LC37)
	j	I_Error
	addiu	$sp,$sp,48

$L213:
	lui	$4,%hi($LC30)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC30)

	blez	$2,$L215
	lw	$31,44($sp)

	lui	$2,%hi(gamemode)
	li	$3,1			# 0x1
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$3,%lo(gamemode)($2)
	jr	$31
	addiu	$sp,$sp,48

$L219:
	b	$L208
	sw	$2,%lo(gamemission)($22)

$L232:
	lw	$2,%lo(gamemission)($22)
	li	$3,9			# 0x9
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L235
	.set	at
	li	$3,-5			# 0xfffffffffffffffb

$L209:
	lui	$4,%hi($LC28)
	jal	I_Error
	addiu	$4,$4,%lo($LC28)

	b	$L229
	lw	$2,%lo(gamemission)($22)

$L215:
	lui	$2,%hi(gamemode)
	b	$L206
	sw	$0,%lo(gamemode)($2)

$L220:
	li	$2,1			# 0x1
$L216:
	lui	$3,%hi(packs.0)
	sll	$2,$2,3
	addiu	$3,$3,%lo(packs.0)
	addu	$2,$3,$2
	lw	$2,4($2)
	b	$L206
	sw	$2,%lo(gamemission)($22)

$L234:
	b	$L216
	li	$2,2			# 0x2

	.set	macro
	.set	reorder
	.end	D_IdentifyVersion
	.size	D_IdentifyVersion, .-D_IdentifyVersion
	.section	.rodata.str1.4
	.align	2
$LC38:
	.ascii	"FREEDOOM\000"
	.align	2
$LC39:
	.ascii	"FREEDM\000"
	.align	2
$LC40:
	.ascii	"Unknown\000"
	.align	2
$LC41:
	.ascii	"Freedoom: Phase 1\000"
	.align	2
$LC42:
	.ascii	"The Ultimate DOOM\000"
	.align	2
$LC43:
	.ascii	"DOOM Registered\000"
	.align	2
$LC44:
	.ascii	"DOOM Shareware\000"
	.align	2
$LC45:
	.ascii	"FreeDM\000"
	.align	2
$LC46:
	.ascii	"Freedoom: Phase 2\000"
	.align	2
$LC47:
	.ascii	"DOOM 2: Hell on Earth\000"
	.align	2
$LC48:
	.ascii	"DOOM 2: Plutonia Experiment\000"
	.align	2
$LC49:
	.ascii	"DOOM 2: TNT - Evilution\000"
	.text
	.align	2
	.globl	D_SetGameDescription
	.set	nomips16
	.set	nomicromips
	.ent	D_SetGameDescription
	.type	D_SetGameDescription, @function
D_SetGameDescription:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC38)
	addiu	$sp,$sp,-24
	addiu	$4,$4,%lo($LC38)
	sw	$31,20($sp)
	jal	W_CheckNumForName
	sw	$16,16($sp)

	lui	$4,%hi($LC39)
	addiu	$4,$4,%lo($LC39)
	jal	W_CheckNumForName
	move	$16,$2

	lui	$3,%hi(gamemission)
	lw	$6,%lo(gamemission)($3)
	lui	$4,%hi($LC40)
	li	$3,-5			# 0xfffffffffffffffb
	lui	$5,%hi(gamedescription)
	addiu	$4,$4,%lo($LC40)
	and	$3,$6,$3
	beq	$3,$0,$L247
	sw	$4,%lo(gamedescription)($5)

	bltz	$16,$L242
	nop

	bltz	$2,$L243
	lw	$31,20($sp)

	lui	$2,%hi($LC45)
	addiu	$2,$2,%lo($LC45)
	lw	$16,16($sp)
	sw	$2,%lo(gamedescription)($5)
	jr	$31
	addiu	$sp,$sp,24

$L247:
	bltz	$16,$L238
	lui	$2,%hi($LC41)

	addiu	$2,$2,%lo($LC41)
	sw	$2,%lo(gamedescription)($5)
$L236:
	lw	$31,20($sp)
$L252:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L238:
	lui	$2,%hi(gamemode)
	lw	$2,%lo(gamemode)($2)
	li	$3,3			# 0x3
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L248
	.set	at
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L249
	.set	at
	nop

	bne	$2,$0,$L252
	lw	$31,20($sp)

	lui	$2,%hi($LC44)
	addiu	$2,$2,%lo($LC44)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

$L242:
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L250
	.set	at
	li	$2,3			# 0x3

	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L251
	.set	at
	li	$2,2			# 0x2

	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L252
	.set	at
	lw	$31,20($sp)

	lui	$2,%hi($LC49)
	addiu	$2,$2,%lo($LC49)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

$L248:
	lui	$2,%hi($LC42)
	addiu	$2,$2,%lo($LC42)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

$L243:
	lui	$2,%hi($LC46)
	addiu	$2,$2,%lo($LC46)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

$L250:
	lui	$2,%hi($LC47)
	addiu	$2,$2,%lo($LC47)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

$L249:
	lui	$2,%hi($LC43)
	addiu	$2,$2,%lo($LC43)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

$L251:
	lui	$2,%hi($LC48)
	addiu	$2,$2,%lo($LC48)
	b	$L236
	sw	$2,%lo(gamedescription)($5)

	.set	macro
	.set	reorder
	.end	D_SetGameDescription
	.size	D_SetGameDescription, .-D_SetGameDescription
	.align	2
	.globl	PrintDehackedBanners
	.set	nomips16
	.set	nomicromips
	.ent	PrintDehackedBanners
	.type	PrintDehackedBanners, @function
PrintDehackedBanners:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	PrintDehackedBanners
	.size	PrintDehackedBanners, .-PrintDehackedBanners
	.section	.rodata.str1.4
	.align	2
$LC50:
	.ascii	"Doom 1.666\000"
	.align	2
$LC51:
	.ascii	"Emulating the behavior of the '%s' executable.\012\000"
	.text
	.align	2
	.globl	PrintGameVersion
	.set	nomips16
	.set	nomicromips
	.ent	PrintGameVersion
	.type	PrintGameVersion, @function
PrintGameVersion:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gameversion)
	lw	$4,%lo(gameversion)($2)
	lui	$5,%hi($LC50)
	lui	$2,%hi(gameversions+8)
	addiu	$2,$2,%lo(gameversions+8)
	b	$L256
	addiu	$5,$5,%lo($LC50)

$L255:
	lw	$5,-8($2)
	beq	$5,$0,$L259
	nop

$L256:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L255
	.set	at
	addiu	$2,$2,12

	lui	$4,%hi($LC51)
	j	printf
	addiu	$4,$4,%lo($LC51)

$L259:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	PrintGameVersion
	.size	PrintGameVersion, .-PrintGameVersion
	.section	.rodata.str1.4
	.align	2
$LC52:
	.ascii	"Doom Generic 0.1\000"
	.align	2
$LC53:
	.ascii	"Z_Init: Init zone memory allocation daemon. \012\000"
	.align	2
$LC54:
	.ascii	"-nomonsters\000"
	.align	2
$LC55:
	.ascii	"-respawn\000"
	.align	2
$LC56:
	.ascii	"-fast\000"
	.align	2
$LC57:
	.ascii	"-devparm\000"
	.align	2
$LC58:
	.ascii	"-deathmatch\000"
	.align	2
$LC59:
	.ascii	"-altdeath\000"
	.align	2
$LC60:
	.ascii	"Development mode ON.\012\000"
	.align	2
$LC61:
	.ascii	"-turbo\000"
	.align	2
$LC62:
	.ascii	"turbo scale: %i%%\012\000"
	.align	2
$LC63:
	.ascii	"V_Init: allocate screens.\012\000"
	.align	2
$LC64:
	.ascii	"M_LoadDefaults: Load system defaults.\012\000"
	.align	2
$LC65:
	.ascii	"doomgenericdoom.cfg\000"
	.align	2
$LC66:
	.ascii	"default.cfg\000"
	.align	2
$LC67:
	.ascii	"Game mode indeterminate.  No IWAD file was found.  Try\012"
	.ascii	"specifying one with the '-iwad' command line parameter.\012"
	.ascii	"\000"
	.align	2
$LC68:
	.ascii	"W_Init: Init WADfiles.\012\000"
	.align	2
$LC69:
	.ascii	" adding %s\012\000"
	.align	2
$LC70:
	.ascii	"-gameversion\000"
	.align	2
$LC71:
	.ascii	"Supported game versions:\012\000"
	.align	2
$LC72:
	.ascii	"\011%s (%s)\012\000"
	.align	2
$LC73:
	.ascii	"Unknown game version '%s'\000"
	.align	2
$LC74:
	.ascii	"dmenupic\000"
	.align	2
$LC75:
	.ascii	"BFG Edition: Using workarounds as needed.\012\000"
	.align	2
$LC76:
	.ascii	"-playdemo\000"
	.align	2
$LC77:
	.ascii	"-timedemo\000"
	.align	2
$LC78:
	.ascii	".lmp\000"
	.align	2
$LC79:
	.ascii	"%s.lmp\000"
	.align	2
$LC80:
	.ascii	"Playing demo %s.\012\000"
	.align	2
$LC81:
	.ascii	"\012You cannot -file with the shareware version. Registe"
	.ascii	"r!\000"
	.align	2
$LC82:
	.ascii	"\012This is not the registered version.\000"
	.align	2
$LC83:
	.ascii	"SS_START\000"
	.align	2
$LC84:
	.ascii	" WARNING: The loaded WAD file contains modified sprites "
	.ascii	"or\012 floor textures.  You may want to use the '-merge'"
	.ascii	" command\012 line option instead of '-file'.\012\000"
	.align	2
$LC85:
	.ascii	"FF_END\000"
	.align	2
$LC86:
	.ascii	" WARNING: You are playing using one of the Freedoom IWAD"
	.ascii	"\012 files, which might not work in this port. See this "
	.ascii	"page\012 for more information on how to play using Freed"
	.ascii	"oom:\012   http://www.chocolate-doom.org/wiki/index.php/"
	.ascii	"Freedoom\012\000"
	.align	2
$LC87:
	.ascii	"I_Init: Setting up machine state.\012\000"
	.align	2
$LC88:
	.ascii	"-skill\000"
	.align	2
$LC89:
	.ascii	"-episode\000"
	.align	2
$LC90:
	.ascii	"-timer\000"
	.align	2
$LC91:
	.ascii	"-avg\000"
	.align	2
$LC92:
	.ascii	"-warp\000"
	.align	2
$LC93:
	.ascii	"-loadgame\000"
	.align	2
$LC94:
	.ascii	"M_Init: Init miscellaneous info.\012\000"
	.align	2
$LC95:
	.ascii	"R_Init: Init DOOM refresh daemon - \000"
	.align	2
$LC96:
	.ascii	"\012P_Init: Init Playloop state.\012\000"
	.align	2
$LC97:
	.ascii	"S_Init: Setting up sound.\012\000"
	.align	2
$LC98:
	.ascii	"D_CheckNetGame: Checking network game status.\012\000"
	.align	2
$LC99:
	.ascii	"HU_Init: Setting up heads up display.\012\000"
	.align	2
$LC100:
	.ascii	"ST_Init: Init status bar.\012\000"
	.align	2
$LC101:
	.ascii	"map01\000"
	.align	2
$LC102:
	.ascii	"-statdump\000"
	.align	2
$LC103:
	.ascii	"External statistics registered.\012\000"
	.align	2
$LC104:
	.ascii	"-record\000"
	.rdata
	.align	2
$LC0:
	.ascii	"e2m1\000"
	.space	3
	.ascii	"e2m2\000"
	.space	3
	.ascii	"e2m3\000"
	.space	3
	.ascii	"e2m4\000"
	.space	3
	.ascii	"e2m5\000"
	.space	3
	.ascii	"e2m6\000"
	.space	3
	.ascii	"e2m7\000"
	.space	3
	.ascii	"e2m8\000"
	.space	3
	.ascii	"e2m9\000"
	.space	3
	.ascii	"e3m1\000"
	.space	3
	.ascii	"e3m3\000"
	.space	3
	.ascii	"e3m3\000"
	.space	3
	.ascii	"e3m4\000"
	.space	3
	.ascii	"e3m5\000"
	.space	3
	.ascii	"e3m6\000"
	.space	3
	.ascii	"e3m7\000"
	.space	3
	.ascii	"e3m8\000"
	.space	3
	.ascii	"e3m9\000"
	.space	3
	.ascii	"dphoof\000"
	.space	1
	.ascii	"bfgga0\000"
	.space	1
	.ascii	"heada1\000"
	.space	1
	.ascii	"cybra1\000"
	.space	1
	.ascii	"spida1d1"
	.text
	.align	2
	.globl	D_DoomMain
	.set	nomips16
	.set	nomicromips
	.ent	D_DoomMain
	.type	D_DoomMain, @function
D_DoomMain:
	.frame	$sp,520,$31		# vars= 464, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(D_Endoom)
	addiu	$sp,$sp,-520
	move	$5,$0
	addiu	$4,$4,%lo(D_Endoom)
	sw	$31,516($sp)
	sw	$16,480($sp)
	sw	$fp,512($sp)
	sw	$23,508($sp)
	sw	$22,504($sp)
	sw	$21,500($sp)
	sw	$20,496($sp)
	sw	$19,492($sp)
	sw	$18,488($sp)
	jal	I_AtExit
	sw	$17,484($sp)

	lui	$4,%hi($LC52)
	jal	I_PrintBanner
	addiu	$4,$4,%lo($LC52)

	lui	$4,%hi($LC53)
	jal	printf
	addiu	$4,$4,%lo($LC53)

	jal	Z_Init
	lui	$16,%hi(devparm)

	lui	$4,%hi($LC54)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC54)

	lui	$4,%hi($LC55)
	lui	$3,%hi(nomonsters)
	addiu	$4,$4,%lo($LC55)
	jal	M_CheckParm
	sw	$2,%lo(nomonsters)($3)

	lui	$4,%hi($LC56)
	lui	$3,%hi(respawnparm)
	addiu	$4,$4,%lo($LC56)
	jal	M_CheckParm
	sw	$2,%lo(respawnparm)($3)

	lui	$4,%hi($LC57)
	lui	$3,%hi(fastparm)
	addiu	$4,$4,%lo($LC57)
	jal	M_CheckParm
	sw	$2,%lo(fastparm)($3)

	move	$4,$2
	jal	I_DisplayFPSDots
	sw	$2,%lo(devparm)($16)

	lui	$4,%hi($LC58)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC58)

	beq	$2,$0,$L261
	lui	$2,%hi(deathmatch)

	li	$3,1			# 0x1
	sw	$3,%lo(deathmatch)($2)
$L261:
	lui	$4,%hi($LC59)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC59)

	beq	$2,$0,$L410
	lw	$2,%lo(devparm)($16)

	lui	$2,%hi(deathmatch)
	li	$3,2			# 0x2
	sw	$3,%lo(deathmatch)($2)
	lw	$2,%lo(devparm)($16)
$L410:
	bne	$2,$0,$L381
	nop

$L263:
	jal	M_SetConfigDir
	move	$4,$0

	lui	$4,%hi($LC61)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC61)

	beq	$2,$0,$L264
	lui	$3,%hi(myargc)

	lw	$3,%lo(myargc)($3)
	addiu	$3,$3,-1
	slt	$3,$2,$3
	bne	$3,$0,$L382
	li	$16,200			# 0xc8

$L266:
	lui	$4,%hi($LC62)
	move	$5,$16
	jal	printf
	addiu	$4,$4,%lo($LC62)

	lui	$9,%hi(forwardmove)
	lui	$8,%hi(sidemove)
	lw	$5,%lo(forwardmove)($9)
	addiu	$11,$9,%lo(forwardmove)
	addiu	$10,$8,%lo(sidemove)
	multu	$16,$5
	mflo	$5
	lw	$2,4($10)
	lw	$4,4($11)
	lw	$3,%lo(sidemove)($8)
	multu	$16,$4
	mflo	$4
	multu	$16,$3
	mflo	$3
	multu	$16,$2
	mflo	$16
	li	$2,1374355456			# 0x51eb0000
	ori	$2,$2,0x851f
	mult	$5,$2
	sra	$5,$5,31
	mfhi	$12
	mult	$4,$2
	sra	$12,$12,5
	mfhi	$7
	mult	$3,$2
	sra	$7,$7,5
	mfhi	$6
	mult	$16,$2
	sra	$4,$4,31
	mfhi	$2
	sra	$6,$6,5
	sra	$3,$3,31
	sra	$2,$2,5
	sra	$16,$16,31
	subu	$12,$12,$5
	subu	$7,$7,$4
	subu	$6,$6,$3
	subu	$2,$2,$16
	sw	$12,%lo(forwardmove)($9)
	sw	$7,4($11)
	sw	$6,%lo(sidemove)($8)
	sw	$2,4($10)
$L264:
	lui	$4,%hi($LC63)
	jal	printf
	addiu	$4,$4,%lo($LC63)

	jal	V_Init
	lui	$21,%hi(gamemission)

	lui	$4,%hi($LC64)
	jal	printf
	addiu	$4,$4,%lo($LC64)

	lui	$5,%hi($LC65)
	lui	$4,%hi($LC66)
	addiu	$5,$5,%lo($LC65)
	jal	M_SetConfigFilenames
	addiu	$4,$4,%lo($LC66)

	jal	D_BindVariables
	lui	$16,%hi(iwadfile)

	jal	M_LoadDefaults
	nop

	lui	$4,%hi(M_SaveDefaults)
	move	$5,$0
	jal	I_AtExit
	addiu	$4,$4,%lo(M_SaveDefaults)

	addiu	$5,$21,%lo(gamemission)
	jal	D_FindIWAD
	li	$4,63			# 0x3f

	beq	$2,$0,$L383
	sw	$2,%lo(iwadfile)($16)

	lui	$4,%hi($LC68)
$L408:
	addiu	$4,$4,%lo($LC68)
	lui	$18,%hi(modifiedgame)
	jal	printf
	sw	$0,%lo(modifiedgame)($18)

	lw	$16,%lo(iwadfile)($16)
	lui	$23,%hi($LC69)
	move	$5,$16
	jal	printf
	addiu	$4,$23,%lo($LC69)

	jal	W_AddFile
	move	$4,$16

	jal	W_CheckCorrectIWAD
	move	$4,$0

	jal	D_IdentifyVersion
	nop

	lui	$4,%hi($LC70)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC70)

	beq	$2,$0,$L268
	lw	$4,%lo(gamemission)($21)

	lui	$20,%hi(gameversions+4)
	addiu	$2,$2,1
	addiu	$20,$20,%lo(gameversions+4)
	sll	$19,$2,2
	move	$16,$20
	move	$22,$0
	b	$L271
	lui	$17,%hi(myargv)

$L269:
	lw	$2,-4($16)
	beq	$2,$0,$L384
	addiu	$22,$22,1

$L271:
	lw	$2,%lo(myargv)($17)
	lw	$5,0($16)
	addu	$2,$2,$19
	lw	$4,0($2)
	jal	strcmp
	addiu	$16,$16,12

	bne	$2,$0,$L269
	sll	$2,$22,1

	addu	$2,$2,$22
	lui	$3,%hi(gameversions)
	addiu	$3,$3,%lo(gameversions)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,8($2)
	lui	$2,%hi($LC50)
	lui	$fp,%hi(gameversion)
	addiu	$2,$2,%lo($LC50)
	sw	$3,%lo(gameversion)($fp)
	sw	$2,472($sp)
$L270:
	sltu	$2,$3,6
	beq	$2,$0,$L280
	lui	$19,%hi(gamemode)

	lw	$3,%lo(gamemode)($19)
$L327:
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L385
	.set	at
	li	$2,1			# 0x1

$L281:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L282
	.set	at
	lw	$2,%lo(gamemission)($21)

	addiu	$2,$2,-2
	sltu	$2,$2,2
	beq	$2,$0,$L282
	li	$2,1			# 0x1

	b	$L282
	sw	$2,%lo(gamemission)($21)

$L268:
	li	$5,4			# 0x4
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L386
	.set	at
	li	$2,5			# 0x5

	lui	$19,%hi(gamemode)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L275
	.set	at
	lw	$3,%lo(gamemode)($19)

	sltu	$2,$3,2
	bne	$2,$0,$L276
	li	$2,3			# 0x3

	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L387
	.set	at
	li	$2,2			# 0x2

	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L388
	.set	at
	lui	$2,%hi($LC50)

	lui	$fp,%hi(gameversion)
	lw	$3,%lo(gameversion)($fp)
	addiu	$2,$2,%lo($LC50)
	sw	$2,472($sp)
	sltu	$2,$3,6
	bne	$2,$0,$L282
	nop

$L280:
	li	$2,6			# 0x6
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L281
	.set	at
	lw	$3,%lo(gamemode)($19)

$L282:
	lui	$4,%hi($LC74)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC74)

	bltz	$2,$L283
	lui	$4,%hi($LC75)

	jal	printf
	addiu	$4,$4,%lo($LC75)

	lui	$2,%hi(bfgedition)
	li	$3,1			# 0x1
	sw	$3,%lo(bfgedition)($2)
$L283:
	jal	W_ParseCommandLine
	lui	$22,%hi($LC76)

	li	$5,1			# 0x1
	addiu	$4,$22,%lo($LC76)
	jal	M_CheckParmWithArgs
	sw	$2,%lo(modifiedgame)($18)

	bne	$2,$0,$L411
	lui	$17,%hi(myargv)

	lui	$4,%hi($LC77)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC77)

	beq	$2,$0,$L412
	lui	$4,%hi(G_CheckDemoStatus)

	lui	$17,%hi(myargv)
$L411:
	addiu	$2,$2,1
	lw	$3,%lo(myargv)($17)
	sll	$16,$2,2
	addu	$2,$3,$16
	lui	$5,%hi($LC78)
	lw	$4,0($2)
	jal	M_StringEndsWith
	addiu	$5,$5,%lo($LC78)

	beq	$2,$0,$L286
	lw	$2,%lo(myargv)($17)

	addiu	$20,$sp,16
	addu	$2,$2,$16
	lw	$5,0($2)
	li	$6,256			# 0x100
	jal	M_StringCopy
	move	$4,$20

	addiu	$4,$23,%lo($LC69)
$L405:
	jal	printf
	move	$5,$20

	jal	W_AddFile
	move	$4,$20

	beq	$2,$0,$L288
	lw	$2,%lo(myargv)($17)

	lui	$2,%hi(numlumps)
	lw	$3,%lo(numlumps)($2)
	li	$6,9			# 0x9
	sll	$2,$3,3
	subu	$2,$2,$3
	lui	$3,%hi(lumpinfo)
	lw	$5,%lo(lumpinfo)($3)
	sll	$2,$2,2
	addiu	$2,$2,-28
	addu	$5,$5,$2
	jal	M_StringCopy
	addiu	$4,$sp,456

	lui	$4,%hi($LC80)
$L404:
	move	$5,$20
	jal	printf
	addiu	$4,$4,%lo($LC80)

	lui	$4,%hi(G_CheckDemoStatus)
$L412:
	li	$5,1			# 0x1
	jal	I_AtExit
	addiu	$4,$4,%lo(G_CheckDemoStatus)

	jal	W_GenerateHashTable
	nop

	jal	D_SetGameDescription
	nop

	jal	D_SaveGameIWADName
	lw	$4,%lo(gamemission)($21)

	jal	M_GetSaveGameDir
	move	$4,$2

	lw	$3,%lo(modifiedgame)($18)
	lui	$4,%hi(savegamedir)
	beq	$3,$0,$L290
	sw	$2,%lo(savegamedir)($4)

	lui	$2,%hi($LC0)
	addiu	$2,$2,%lo($LC0)
	addiu	$3,$sp,272
	addiu	$8,$2,176
$L291:
	lw	$7,0($2)
	lw	$6,4($2)
	lw	$5,8($2)
	lw	$4,12($2)
	addiu	$2,$2,16
	sw	$7,0($3)
	sw	$6,4($3)
	sw	$5,8($3)
	sw	$4,12($3)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L291
	.set	at
	addiu	$3,$3,16

	lw	$5,0($2)
	lw	$4,4($2)
	lw	$2,%lo(gamemode)($19)
	sw	$5,0($3)
	beq	$2,$0,$L390
	sw	$4,4($3)

$L292:
	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L391
	.set	at
	lui	$18,%hi($LC82)

$L290:
	lui	$4,%hi($LC83)
$L415:
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC83)

	bltz	$2,$L297
	nop

$L299:
	jal	I_PrintDivider
	nop

	lui	$4,%hi($LC84)
	jal	printf
	addiu	$4,$4,%lo($LC84)

	lui	$2,%hi(gamedescription)
$L403:
	jal	I_PrintStartupBanner
	lw	$4,%lo(gamedescription)($2)

	lui	$4,%hi($LC38)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC38)

	bgez	$2,$L392
	nop

$L301:
	lui	$4,%hi($LC87)
$L402:
	jal	printf
	addiu	$4,$4,%lo($LC87)

	jal	I_CheckIsScreensaver
	li	$21,1			# 0x1

	jal	I_InitTimer
	lui	$20,%hi(startskill)

	jal	I_InitJoystick
	lui	$18,%hi(startepisode)

	jal	I_InitSound
	li	$4,1			# 0x1

	jal	I_InitMusic
	lui	$17,%hi(startmap)

	jal	D_ConnectNetGame
	lui	$16,%hi(autostart)

	lui	$4,%hi($LC88)
	li	$2,2			# 0x2
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC88)
	sw	$2,%lo(startskill)($20)
	sw	$21,%lo(startepisode)($18)
	sw	$21,%lo(startmap)($17)
	jal	M_CheckParmWithArgs
	sw	$0,%lo(autostart)($16)

	beq	$2,$0,$L303
	lui	$3,%hi(myargv)

	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$2,0($2)
	lb	$2,0($2)
	sw	$21,%lo(autostart)($16)
	addiu	$2,$2,-49
	sw	$2,%lo(startskill)($20)
$L303:
	lui	$4,%hi($LC89)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC89)

	beq	$2,$0,$L413
	lui	$4,%hi($LC90)

	lui	$3,%hi(myargv)
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$2,0($2)
	li	$3,1			# 0x1
	lb	$2,0($2)
	sw	$3,%lo(startmap)($17)
	addiu	$2,$2,-48
	sw	$2,%lo(startepisode)($18)
	sw	$3,%lo(autostart)($16)
$L413:
	lui	$21,%hi(timelimit)
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC90)
	jal	M_CheckParmWithArgs
	sw	$0,%lo(timelimit)($21)

	bne	$2,$0,$L393
	lui	$3,%hi(myargv)

$L305:
	lui	$4,%hi($LC91)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC91)

	beq	$2,$0,$L306
	li	$2,20			# 0x14

	sw	$2,%lo(timelimit)($21)
$L306:
	lui	$4,%hi($LC92)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC92)

	beq	$2,$0,$L307
	lui	$3,%hi(myargv)

	lw	$3,%lo(myargv)($3)
	addiu	$4,$2,1
	sll	$4,$4,2
	lw	$6,%lo(gamemode)($19)
	addu	$3,$3,$4
	li	$5,2			# 0x2
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L394
	.set	at
	lw	$4,0($3)

	lui	$5,%hi(myargc)
	lb	$4,0($4)
	lw	$5,%lo(myargc)($5)
	addiu	$2,$2,2
	addiu	$4,$4,-48
	slt	$2,$2,$5
	bne	$2,$0,$L395
	sw	$4,%lo(startepisode)($18)

	li	$2,1			# 0x1
$L309:
	sw	$2,%lo(startmap)($17)
$L409:
	li	$2,1			# 0x1
	sw	$2,%lo(autostart)($16)
$L307:
	lui	$4,%hi($LC1)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC1)

	blez	$2,$L310
	li	$2,1			# 0x1

	lui	$3,%hi(testcontrols)
	sw	$2,%lo(startepisode)($18)
	sw	$2,%lo(startmap)($17)
	sw	$2,%lo(autostart)($16)
	sw	$2,%lo(testcontrols)($3)
$L310:
	lui	$4,%hi($LC93)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC93)

	bne	$2,$0,$L396
	lui	$3,%hi(myargv)

	li	$2,-1			# 0xffffffffffffffff
	lui	$4,%hi($LC94)
$L407:
	addiu	$4,$4,%lo($LC94)
	lui	$21,%hi(startloadgame)
	jal	printf
	sw	$2,%lo(startloadgame)($21)

	jal	M_Init
	nop

	lui	$4,%hi($LC95)
	jal	printf
	addiu	$4,$4,%lo($LC95)

	jal	R_Init
	nop

	lui	$4,%hi($LC96)
	jal	printf
	addiu	$4,$4,%lo($LC96)

	jal	P_Init
	nop

	lui	$4,%hi($LC97)
	jal	printf
	addiu	$4,$4,%lo($LC97)

	lui	$2,%hi(musicVolume)
	lw	$5,%lo(musicVolume)($2)
	lui	$2,%hi(sfxVolume)
	lw	$4,%lo(sfxVolume)($2)
	sll	$5,$5,3
	jal	S_Init
	sll	$4,$4,3

	lui	$4,%hi($LC98)
	jal	printf
	addiu	$4,$4,%lo($LC98)

	jal	D_CheckNetGame
	nop

	lui	$2,%hi(gameversions+8)
	lw	$4,%lo(gameversion)($fp)
	lw	$5,472($sp)
	b	$L314
	addiu	$2,$2,%lo(gameversions+8)

$L312:
	lw	$5,-8($2)
	beq	$5,$0,$L313
	nop

$L314:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L312
	.set	at
	addiu	$2,$2,12

	lui	$4,%hi($LC51)
	jal	printf
	addiu	$4,$4,%lo($LC51)

$L313:
	lui	$4,%hi($LC99)
	jal	printf
	addiu	$4,$4,%lo($LC99)

	jal	HU_Init
	nop

	lui	$4,%hi($LC100)
	jal	printf
	addiu	$4,$4,%lo($LC100)

	jal	ST_Init
	nop

	lw	$3,%lo(gamemode)($19)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L397
	.set	at
	nop

$L316:
	lui	$4,%hi($LC102)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC102)

	bne	$2,$0,$L398
	nop

	lui	$4,%hi($LC104)
$L406:
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC104)

	bne	$2,$0,$L399
	lui	$3,%hi(myargv)

$L319:
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$22,%lo($LC76)

	bne	$2,$0,$L400
	lui	$4,%hi($LC77)

	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC77)

	bne	$2,$0,$L401
	lw	$4,%lo(startloadgame)($21)

	bltz	$4,$L414
	lui	$3,%hi(gameaction)

	jal	P_SaveGameFile
	nop

	move	$5,$2
	addiu	$4,$sp,16
	jal	M_StringCopy
	li	$6,256			# 0x100

	jal	G_LoadGame
	addiu	$4,$sp,16

	lui	$3,%hi(gameaction)
$L414:
	lw	$4,%lo(gameaction)($3)
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L324
	.set	at
	lui	$4,%hi(netgame)

	lw	$2,%lo(autostart)($16)
	lw	$4,%lo(netgame)($4)
	or	$2,$2,$4
	beq	$2,$0,$L325
	lui	$2,%hi(demosequence)

	lw	$6,%lo(startmap)($17)
	lw	$5,%lo(startepisode)($18)
	jal	G_InitNew
	lw	$4,%lo(startskill)($20)

$L324:
	jal	D_DoomLoop
	nop

	lw	$31,516($sp)
	lw	$fp,512($sp)
	lw	$23,508($sp)
	lw	$22,504($sp)
	lw	$21,500($sp)
	lw	$20,496($sp)
	lw	$19,492($sp)
	lw	$18,488($sp)
	lw	$17,484($sp)
	lw	$16,480($sp)
	jr	$31
	addiu	$sp,$sp,520

$L381:
	lui	$4,%hi($LC60)
	jal	printf
	addiu	$4,$4,%lo($LC60)

	b	$L263
	nop

$L392:
	lui	$4,%hi($LC39)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC39)

	bgez	$2,$L301
	nop

	lui	$4,%hi($LC86)
	jal	printf
	addiu	$4,$4,%lo($LC86)

	jal	I_PrintDivider
	nop

	b	$L402
	lui	$4,%hi($LC87)

$L297:
	lui	$4,%hi($LC85)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC85)

	bgez	$2,$L299
	lui	$2,%hi(gamedescription)

	b	$L403
	nop

$L288:
	li	$6,9			# 0x9
	addu	$2,$2,$16
	lw	$5,0($2)
	jal	M_StringCopy
	addiu	$4,$sp,456

	b	$L404
	lui	$4,%hi($LC80)

$L286:
	addiu	$20,$sp,16
	addu	$2,$2,$16
	lw	$7,0($2)
	lui	$6,%hi($LC79)
	addiu	$6,$6,%lo($LC79)
	li	$5,256			# 0x100
	jal	snprintf
	move	$4,$20

	b	$L405
	addiu	$4,$23,%lo($LC69)

$L400:
	addiu	$4,$sp,456
	lui	$2,%hi(singledemo)
	li	$3,1			# 0x1
	jal	G_DeferedPlayDemo
	sw	$3,%lo(singledemo)($2)

	jal	D_DoomLoop
	nop

	lw	$31,516($sp)
	lw	$fp,512($sp)
	lw	$23,508($sp)
	lw	$22,504($sp)
	lw	$21,500($sp)
	lw	$20,496($sp)
	lw	$19,492($sp)
	lw	$18,488($sp)
	lw	$17,484($sp)
	lw	$16,480($sp)
	jr	$31
	addiu	$sp,$sp,520

$L399:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	G_RecordDemo
	lw	$4,0($2)

	li	$2,1			# 0x1
	b	$L319
	sw	$2,%lo(autostart)($16)

$L398:
	lui	$4,%hi(StatDump)
	addiu	$4,$4,%lo(StatDump)
	jal	I_AtExit
	li	$5,1			# 0x1

	lui	$4,%hi($LC103)
	jal	printf
	addiu	$4,$4,%lo($LC103)

	b	$L406
	lui	$4,%hi($LC104)

$L396:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	atoi
	lw	$4,0($2)

	b	$L407
	lui	$4,%hi($LC94)

$L393:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	atoi
	lw	$4,0($2)

	b	$L305
	sw	$2,%lo(timelimit)($21)

$L384:
	lui	$4,%hi($LC71)
	jal	printf
	addiu	$4,$4,%lo($LC71)

	lui	$2,%hi($LC50)
	addiu	$2,$2,%lo($LC50)
	lui	$16,%hi($LC72)
	sw	$2,472($sp)
	move	$6,$2
	addiu	$16,$16,%lo($LC72)
$L272:
	lw	$5,0($20)
	move	$4,$16
	jal	printf
	addiu	$20,$20,12

	lw	$6,-4($20)
	bne	$6,$0,$L272
	lw	$2,%lo(myargv)($17)

	lui	$4,%hi($LC73)
	addu	$2,$2,$19
	lw	$5,0($2)
	addiu	$4,$4,%lo($LC73)
	jal	I_Error
	lui	$fp,%hi(gameversion)

	b	$L270
	lw	$3,%lo(gameversion)($fp)

$L397:
	lui	$4,%hi($LC101)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC101)

	bgez	$2,$L316
	lui	$2,%hi(storedemo)

	li	$3,1			# 0x1
	b	$L316
	sw	$3,%lo(storedemo)($2)

$L395:
	lw	$2,4($3)
	lb	$2,0($2)
	b	$L309
	addiu	$2,$2,-48

$L385:
	b	$L282
	sw	$2,%lo(gamemode)($19)

$L325:
	sw	$0,%lo(gameaction)($3)
	li	$3,-1			# 0xffffffffffffffff
	sw	$3,%lo(demosequence)($2)
	lui	$2,%hi(advancedemo)
	li	$3,1			# 0x1
	b	$L324
	sw	$3,%lo(advancedemo)($2)

$L382:
	lui	$17,%hi(myargv)
	lw	$3,%lo(myargv)($17)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	atoi
	lw	$4,0($2)

	slt	$3,$2,10
	bne	$3,$0,$L329
	li	$3,400			# 0x190

	slt	$4,$2,401
	movn	$3,$2,$4
	b	$L266
	move	$16,$3

$L276:
	lui	$fp,%hi(gameversion)
$L380:
	lui	$2,%hi($LC50)
	addiu	$2,$2,%lo($LC50)
	sw	$5,%lo(gameversion)($fp)
	b	$L282
	sw	$2,472($sp)

$L383:
	lui	$4,%hi($LC67)
	jal	I_Error
	addiu	$4,$4,%lo($LC67)

	b	$L408
	lui	$4,%hi($LC68)

$L386:
	lui	$2,%hi($LC50)
	lui	$fp,%hi(gameversion)
	li	$3,9			# 0x9
	addiu	$2,$2,%lo($LC50)
	sw	$3,%lo(gameversion)($fp)
	sw	$2,472($sp)
	b	$L282
	lui	$19,%hi(gamemode)

$L391:
	addiu	$16,$sp,272
	addiu	$17,$sp,456
	b	$L295
	addiu	$18,$18,%lo($LC82)

$L294:
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L415
	.set	at
	lui	$4,%hi($LC83)

$L295:
	jal	W_CheckNumForName
	move	$4,$16

	bgez	$2,$L294
	addiu	$16,$16,8

	jal	I_Error
	move	$4,$18

	b	$L294
	nop

$L390:
	lui	$4,%hi($LC81)
	jal	I_Error
	addiu	$4,$4,%lo($LC81)

	b	$L292
	lw	$2,%lo(gamemode)($19)

$L401:
	jal	G_TimeDemo
	addiu	$4,$sp,456

	jal	D_DoomLoop
	nop

	lw	$31,516($sp)
	lw	$fp,512($sp)
	lw	$23,508($sp)
	lw	$22,504($sp)
	lw	$21,500($sp)
	lw	$20,496($sp)
	lw	$19,492($sp)
	lw	$18,488($sp)
	lw	$17,484($sp)
	lw	$16,480($sp)
	jr	$31
	addiu	$sp,$sp,520

$L275:
	lui	$2,%hi($LC50)
	lui	$fp,%hi(gameversion)
	addiu	$2,$2,%lo($LC50)
	sw	$4,%lo(gameversion)($fp)
	b	$L327
	sw	$2,472($sp)

$L394:
	jal	atoi
	nop

	b	$L409
	sw	$2,%lo(startmap)($17)

$L329:
	b	$L266
	li	$16,10			# 0xa

$L387:
	lui	$2,%hi($LC50)
	lui	$fp,%hi(gameversion)
	li	$3,6			# 0x6
	addiu	$2,$2,%lo($LC50)
	sw	$3,%lo(gameversion)($fp)
	b	$L282
	sw	$2,472($sp)

$L388:
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L380
	.set	at
	lui	$fp,%hi(gameversion)

	lui	$2,%hi($LC50)
	li	$3,7			# 0x7
	addiu	$2,$2,%lo($LC50)
	sw	$3,%lo(gameversion)($fp)
	b	$L282
	sw	$2,472($sp)

	.set	macro
	.set	reorder
	.end	D_DoomMain
	.size	D_DoomMain, .-D_DoomMain
	.rdata
	.align	2
	.type	packs.0, @object
	.size	packs.0, 24
packs.0:
	.word	$LC32
	.word	1
	.word	$LC33
	.word	2
	.word	$LC34
	.word	3
	.local	menuactivestate.1
	.comm	menuactivestate.1,4,4
	.local	viewactivestate.2
	.comm	viewactivestate.2,4,4
	.local	inhelpscreensstate.3
	.comm	inhelpscreensstate.3,4,4
	.local	fullscreen.4
	.comm	fullscreen.4,4,4
	.local	borderdrawcount.5
	.comm	borderdrawcount.5,4,4
	.data
	.align	2
	.type	oldgamestate.6, @object
	.size	oldgamestate.6, 4
oldgamestate.6:
	.word	-1
	.section	.rodata.str1.4
	.align	2
$LC105:
	.ascii	"1.666\000"
	.align	2
$LC106:
	.ascii	"Doom 1.7/1.7a\000"
	.align	2
$LC107:
	.ascii	"1.7\000"
	.align	2
$LC108:
	.ascii	"Doom 1.8\000"
	.align	2
$LC109:
	.ascii	"1.8\000"
	.align	2
$LC110:
	.ascii	"Doom 1.9\000"
	.align	2
$LC111:
	.ascii	"1.9\000"
	.align	2
$LC112:
	.ascii	"Hacx\000"
	.align	2
$LC113:
	.ascii	"hacx\000"
	.align	2
$LC114:
	.ascii	"Ultimate Doom\000"
	.align	2
$LC115:
	.ascii	"ultimate\000"
	.align	2
$LC116:
	.ascii	"Final Doom\000"
	.align	2
$LC117:
	.ascii	"final\000"
	.align	2
$LC118:
	.ascii	"Final Doom (alt)\000"
	.align	2
$LC119:
	.ascii	"final2\000"
	.align	2
$LC120:
	.ascii	"Chex Quest\000"
	.align	2
$LC121:
	.ascii	"chex\000"
	.rdata
	.align	2
	.type	gameversions, @object
	.size	gameversions, 120
gameversions:
	.word	$LC50
	.word	$LC105
	.word	1
	.word	$LC106
	.word	$LC107
	.word	2
	.word	$LC108
	.word	$LC109
	.word	3
	.word	$LC110
	.word	$LC111
	.word	4
	.word	$LC112
	.word	$LC113
	.word	5
	.word	$LC114
	.word	$LC115
	.word	6
	.word	$LC116
	.word	$LC117
	.word	7
	.word	$LC118
	.word	$LC119
	.word	8
	.word	$LC120
	.word	$LC121
	.word	9
	.word	0
	.word	0
	.word	0
	.globl	title
	.section	.bss,"aw",@nobits
	.align	2
	.type	title, @object
	.size	title, 128
title:
	.space	128
	.globl	pagename
	.align	2
	.type	pagename, @object
	.size	pagename, 4
pagename:
	.space	4
	.globl	pagetic
	.align	2
	.type	pagetic, @object
	.size	pagetic, 4
pagetic:
	.space	4
	.globl	demosequence
	.align	2
	.type	demosequence, @object
	.size	demosequence, 4
demosequence:
	.space	4
	.globl	wipegamestate
	.data
	.align	2
	.type	wipegamestate, @object
	.size	wipegamestate, 4
wipegamestate:
	.word	3
	.globl	show_endoom
	.align	2
	.type	show_endoom, @object
	.size	show_endoom, 4
show_endoom:
	.word	1
	.globl	mapdir
	.section	.bss
	.align	2
	.type	mapdir, @object
	.size	mapdir, 1024
mapdir:
	.space	1024
	.globl	wadfile
	.align	2
	.type	wadfile, @object
	.size	wadfile, 1024
wadfile:
	.space	1024
	.globl	main_loop_started
	.align	2
	.type	main_loop_started, @object
	.size	main_loop_started, 4
main_loop_started:
	.space	4
	.globl	bfgedition
	.align	2
	.type	bfgedition, @object
	.size	bfgedition, 4
bfgedition:
	.space	4
	.globl	storedemo
	.align	2
	.type	storedemo, @object
	.size	storedemo, 4
storedemo:
	.space	4
	.globl	advancedemo
	.align	2
	.type	advancedemo, @object
	.size	advancedemo, 4
advancedemo:
	.space	4
	.globl	startloadgame
	.align	2
	.type	startloadgame, @object
	.size	startloadgame, 4
startloadgame:
	.space	4
	.globl	autostart
	.align	2
	.type	autostart, @object
	.size	autostart, 4
autostart:
	.space	4
	.globl	startmap
	.align	2
	.type	startmap, @object
	.size	startmap, 4
startmap:
	.space	4
	.globl	startepisode
	.align	2
	.type	startepisode, @object
	.size	startepisode, 4
startepisode:
	.space	4
	.globl	startskill
	.align	2
	.type	startskill, @object
	.size	startskill, 4
startskill:
	.space	4
	.globl	fastparm
	.align	2
	.type	fastparm, @object
	.size	fastparm, 4
fastparm:
	.space	4
	.globl	respawnparm
	.align	2
	.type	respawnparm, @object
	.size	respawnparm, 4
respawnparm:
	.space	4
	.globl	nomonsters
	.align	2
	.type	nomonsters, @object
	.size	nomonsters, 4
nomonsters:
	.space	4
	.globl	devparm
	.align	2
	.type	devparm, @object
	.size	devparm, 4
devparm:
	.space	4
	.globl	iwadfile
	.align	2
	.type	iwadfile, @object
	.size	iwadfile, 4
iwadfile:
	.space	4
	.globl	savegamedir
	.align	2
	.type	savegamedir, @object
	.size	savegamedir, 4
savegamedir:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
