	.file	1 "d_mode.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	D_ValidGameMode
	.set	nomips16
	.set	nomicromips
	.ent	D_ValidGameMode
	.type	D_ValidGameMode, @function
D_ValidGameMode:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(valid_modes)
	addiu	$2,$2,%lo(valid_modes)
	b	$L4
	addiu	$6,$2,208

$L2:
	addiu	$2,$2,16
$L9:
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L8
	.set	at
	nop

$L4:
	lw	$3,4($2)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L2
	.set	at
	nop

	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L9
	.set	at
	addiu	$2,$2,16

	addiu	$2,$2,-16
	jr	$31
	li	$2,1			# 0x1

$L8:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	D_ValidGameMode
	.size	D_ValidGameMode, .-D_ValidGameMode
	.align	2
	.globl	D_ValidEpisodeMap
	.set	nomips16
	.set	nomicromips
	.ent	D_ValidEpisodeMap
	.type	D_ValidEpisodeMap, @function
D_ValidEpisodeMap:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,6			# 0x6
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L22
	.set	at
	lui	$10,%hi(valid_modes)

$L25:
	addiu	$10,$10,%lo(valid_modes)
$L26:
	move	$2,$10
	move	$3,$0
	b	$L16
	li	$9,13			# 0xd

$L14:
	addiu	$3,$3,1
$L24:
	.set	noat
	xor	$1,$3,$9
	beq	$1,$0,$L21
	.set	at
	addiu	$2,$2,16

$L16:
	lw	$8,0($2)
	.set	noat
	xor	$1,$8,$4
	bne	$1,$0,$L14
	.set	at
	nop

	lw	$8,4($2)
	.set	noat
	xor	$1,$8,$5
	bne	$1,$0,$L24
	.set	at
	addiu	$3,$3,1

	addiu	$3,$3,-1
	blez	$6,$L21
	sll	$3,$3,4

	addu	$10,$10,$3
	lw	$2,8($10)
	slt	$2,$2,$6
	bne	$2,$0,$L21
	nop

	blez	$7,$L21
	nop

	lw	$2,12($10)
	slt	$2,$2,$7
	jr	$31
	xori	$2,$2,0x1

$L21:
	jr	$31
	move	$2,$0

$L22:
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L23
	.set	at
	li	$2,1			# 0x1

	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L25
	.set	at
	lui	$10,%hi(valid_modes)

	li	$2,4			# 0x4
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L26
	.set	at
	addiu	$10,$10,%lo(valid_modes)

	xori	$7,$7,0x1
	jr	$31
	sltu	$2,$7,1

$L23:
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L25
	.set	at
	lui	$10,%hi(valid_modes)

	addiu	$7,$7,-1
	jr	$31
	sltu	$2,$7,3

	.set	macro
	.set	reorder
	.end	D_ValidEpisodeMap
	.size	D_ValidEpisodeMap, .-D_ValidEpisodeMap
	.align	2
	.globl	D_GetNumEpisodes
	.set	nomips16
	.set	nomicromips
	.ent	D_GetNumEpisodes
	.type	D_GetNumEpisodes, @function
D_GetNumEpisodes:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$6,1			# 0x1
	b	$L28
	sw	$31,20($sp)

$L29:
	addiu	$6,$6,1
$L28:
	jal	D_ValidEpisodeMap
	li	$7,1			# 0x1

	bne	$2,$0,$L29
	lw	$31,20($sp)

	addiu	$2,$6,-1
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	D_GetNumEpisodes
	.size	D_GetNumEpisodes, .-D_GetNumEpisodes
	.align	2
	.globl	D_ValidGameVersion
	.set	nomips16
	.set	nomicromips
	.ent	D_ValidGameVersion
	.type	D_ValidGameVersion, @function
D_ValidGameVersion:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$4,-1
	sltu	$3,$2,5
	lui	$2,%hi(valid_versions)
	addiu	$2,$2,%lo(valid_versions)
	movn	$4,$0,$3
	b	$L35
	addiu	$6,$2,80

$L33:
	addiu	$2,$2,8
$L39:
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L38
	.set	at
	nop

$L35:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L33
	.set	at
	nop

	lw	$3,4($2)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L39
	.set	at
	addiu	$2,$2,8

	addiu	$2,$2,-8
	jr	$31
	li	$2,1			# 0x1

$L38:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	D_ValidGameVersion
	.size	D_ValidGameVersion, .-D_ValidGameVersion
	.align	2
	.globl	D_IsEpisodeMap
	.set	nomips16
	.set	nomicromips
	.ent	D_IsEpisodeMap
	.type	D_IsEpisodeMap, @function
D_IsEpisodeMap:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sltu	$2,$4,7
	beq	$2,$0,$L42
	nop

	li	$2,81			# 0x51
	srl	$2,$2,$4
	jr	$31
	andi	$2,$2,0x1

$L42:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	D_IsEpisodeMap
	.size	D_IsEpisodeMap, .-D_IsEpisodeMap
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"none\000"
	.text
	.align	2
	.globl	D_GameMissionString
	.set	nomips16
	.set	nomicromips
	.ent	D_GameMissionString
	.type	D_GameMissionString, @function
D_GameMissionString:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sltu	$2,$4,9
	beq	$2,$0,$L45
	sll	$4,$4,2

	lui	$2,%hi(CSWTCH.11)
	addiu	$2,$2,%lo(CSWTCH.11)
	addu	$4,$4,$2
	jr	$31
	lw	$2,0($4)

$L45:
	lui	$2,%hi($LC0)
	jr	$31
	addiu	$2,$2,%lo($LC0)

	.set	macro
	.set	reorder
	.end	D_GameMissionString
	.size	D_GameMissionString, .-D_GameMissionString
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"doom\000"
	.align	2
$LC2:
	.ascii	"doom2\000"
	.align	2
$LC3:
	.ascii	"tnt\000"
	.align	2
$LC4:
	.ascii	"plutonia\000"
	.align	2
$LC5:
	.ascii	"chex\000"
	.align	2
$LC6:
	.ascii	"hacx\000"
	.align	2
$LC7:
	.ascii	"heretic\000"
	.align	2
$LC8:
	.ascii	"hexen\000"
	.align	2
$LC9:
	.ascii	"strife\000"
	.rdata
	.align	2
	.type	CSWTCH.11, @object
	.size	CSWTCH.11, 36
CSWTCH.11:
	.word	$LC1
	.word	$LC2
	.word	$LC3
	.word	$LC4
	.word	$LC5
	.word	$LC6
	.word	$LC7
	.word	$LC8
	.word	$LC9
	.align	2
	.type	valid_versions, @object
	.size	valid_versions, 80
valid_versions:
	.word	0
	.word	4
	.word	0
	.word	5
	.word	0
	.word	6
	.word	0
	.word	7
	.word	0
	.word	8
	.word	0
	.word	9
	.word	6
	.word	10
	.word	7
	.word	11
	.word	8
	.word	12
	.word	8
	.word	13
	.align	2
	.type	valid_modes, @object
	.size	valid_modes, 208
valid_modes:
	.word	4
	.word	0
	.word	1
	.word	5
	.word	0
	.word	0
	.word	1
	.word	9
	.word	0
	.word	1
	.word	3
	.word	9
	.word	0
	.word	3
	.word	4
	.word	9
	.word	1
	.word	2
	.word	1
	.word	32
	.word	2
	.word	2
	.word	1
	.word	32
	.word	3
	.word	2
	.word	1
	.word	32
	.word	5
	.word	2
	.word	1
	.word	32
	.word	6
	.word	0
	.word	1
	.word	9
	.word	6
	.word	1
	.word	3
	.word	9
	.word	6
	.word	3
	.word	5
	.word	9
	.word	7
	.word	2
	.word	1
	.word	60
	.word	8
	.word	2
	.word	1
	.word	34
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
