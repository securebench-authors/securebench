	.file	1 "d_net.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Player 1 left the game\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	RunTic
	.type	RunTic, @function
RunTic:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	lui	$7,%hi(playeringame)
	sw	$fp,56($sp)
	lui	$fp,%hi(players)
	addiu	$fp,$fp,%lo(players)
	addiu	$7,$7,%lo(playeringame)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	sw	$31,60($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	move	$21,$4
	move	$16,$fp
	move	$17,$5
	move	$18,$7
	addiu	$20,$fp,1152
	lui	$19,%hi(demoplayback)
$L5:
	lw	$2,%lo(demoplayback)($19)
	bne	$2,$0,$L3
	nop

	lw	$2,0($18)
	beq	$2,$0,$L3
	nop

	lw	$2,0($17)
	beq	$2,$0,$L19
	lui	$23,%hi(exitmsg.0)

$L3:
	addiu	$16,$16,288
$L21:
	addiu	$17,$17,4
	.set	noat
	xor	$1,$16,$20
	bne	$1,$0,$L5
	.set	at
	addiu	$18,$18,4

	lui	$2,%hi(advancedemo)
	lw	$2,%lo(advancedemo)($2)
	lui	$3,%hi(netcmds)
	bne	$2,$0,$L20
	sw	$21,%lo(netcmds)($3)

	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	j	G_Ticker
	addiu	$sp,$sp,64

$L19:
	subu	$22,$16,$fp
	lui	$5,%hi($LC0)
	li	$2,954400768			# 0x38e30000
	li	$6,80			# 0x50
	addiu	$5,$5,%lo($LC0)
	addiu	$4,$23,%lo(exitmsg.0)
	ori	$2,$2,0x8e39
	sra	$22,$22,5
	multu	$22,$2
	mflo	$22
	jal	M_StringCopy
	sw	$7,16($sp)

	lui	$2,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($2)
	addiu	$3,$23,%lo(exitmsg.0)
	sll	$2,$4,3
	lbu	$6,7($3)
	addu	$2,$2,$4
	lw	$7,16($sp)
	lui	$4,%hi(demorecording)
	lw	$5,%lo(demorecording)($4)
	sll	$2,$2,5
	sll	$4,$22,2
	addu	$4,$7,$4
	addu	$22,$22,$6
	addu	$2,$fp,$2
	sb	$22,7($3)
	sw	$0,0($4)
	beq	$5,$0,$L3
	sw	$3,224($2)

	jal	G_CheckDemoStatus
	addiu	$16,$16,288

	b	$L21
	lw	$7,16($sp)

$L20:
	jal	D_DoAdvanceDemo
	nop

	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	j	G_Ticker
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	RunTic
	.size	RunTic, .-RunTic
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"-left\000"
	.align	2
$LC2:
	.ascii	"-right\000"
	.align	2
$LC3:
	.ascii	"-record\000"
	.align	2
$LC4:
	.ascii	"-longtics\000"
	.align	2
$LC5:
	.ascii	"FREEDOOM\000"
	.align	2
$LC6:
	.ascii	"-solo-net\000"
	.text
	.align	2
	.globl	D_ConnectNetGame
	.set	nomips16
	.set	nomicromips
	.ent	D_ConnectNetGame
	.type	D_ConnectNetGame, @function
D_ConnectNetGame:
	.frame	$sp,96,$31		# vars= 72, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC1)
	addiu	$sp,$sp,-96
	li	$2,4			# 0x4
	addiu	$4,$4,%lo($LC1)
	sw	$31,92($sp)
	sw	$16,88($sp)
	sw	$2,32($sp)
	jal	M_CheckParm
	sw	$0,28($sp)

	blez	$2,$L23
	lui	$2,%hi(viewangleoffset)

	li	$3,1073741824			# 0x40000000
	sw	$3,%lo(viewangleoffset)($2)
	li	$2,1			# 0x1
	sw	$2,28($sp)
$L23:
	lui	$4,%hi($LC2)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC2)

	blez	$2,$L24
	lui	$2,%hi(viewangleoffset)

	li	$3,-1073741824			# 0xffffffffc0000000
	sw	$3,%lo(viewangleoffset)($2)
	li	$2,1			# 0x1
	sw	$2,28($sp)
$L24:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	lui	$2,%hi(gamemission)
	lw	$2,%lo(gamemission)($2)
	lui	$4,%hi($LC3)
	addiu	$4,$4,%lo($LC3)
	sw	$3,16($sp)
	jal	M_CheckParm
	sw	$2,20($sp)

	bgtz	$2,$L29
	nop

	move	$2,$0
$L25:
	addiu	$4,$sp,40
	jal	W_Checksum
	sw	$2,24($sp)

	lui	$4,%hi($LC5)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC5)

	nor	$2,$0,$2
	srl	$2,$2,31
	addiu	$4,$sp,16
	jal	D_InitNetGame
	sw	$2,36($sp)

	lui	$4,%hi($LC6)
	lui	$16,%hi(netgame)
	addiu	$4,$4,%lo($LC6)
	jal	M_CheckParm
	sw	$2,%lo(netgame)($16)

	blez	$2,$L22
	li	$2,1			# 0x1

	sw	$2,%lo(netgame)($16)
$L22:
	lw	$31,92($sp)
	lw	$16,88($sp)
	jr	$31
	addiu	$sp,$sp,96

$L29:
	lui	$4,%hi($LC4)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC4)

	b	$L25
	sltu	$2,$2,1

	.set	macro
	.set	reorder
	.end	D_ConnectNetGame
	.size	D_ConnectNetGame, .-D_ConnectNetGame
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"NOTE: Turning resolution is reduced; this is probably be"
	.ascii	"cause there is a client recording a Vanilla demo.\012\000"
	.align	2
$LC8:
	.ascii	"startskill %i  deathmatch: %i  startmap: %i  startepisod"
	.ascii	"e: %i\012\000"
	.align	2
$LC9:
	.ascii	"player %i of %i (%i nodes)\012\000"
	.align	2
$LC10:
	.ascii	"-avg\000"
	.align	2
$LC11:
	.ascii	"Austin Virtual Gaming: Levels will end after 20 minutes\012"
	.ascii	"\000"
	.align	2
$LC12:
	.ascii	"Levels will end after %d minute\000"
	.align	2
$LC13:
	.ascii	"s\000"
	.align	2
$LC14:
	.ascii	".\012\000"
	.text
	.align	2
	.globl	D_CheckNetGame
	.set	nomips16
	.set	nomicromips
	.ent	D_CheckNetGame
	.type	D_CheckNetGame, @function
D_CheckNetGame:
	.frame	$sp,176,$31		# vars= 112, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	addiu	$sp,$sp,-176
	sw	$31,172($sp)
	sw	$fp,168($sp)
	sw	$23,164($sp)
	sw	$22,160($sp)
	sw	$21,156($sp)
	sw	$20,152($sp)
	sw	$19,148($sp)
	sw	$18,144($sp)
	sw	$17,140($sp)
	beq	$2,$0,$L31
	sw	$16,136($sp)

	lui	$2,%hi(autostart)
	li	$3,1			# 0x1
	sw	$3,%lo(autostart)($2)
$L31:
	lui	$4,%hi(doom_loop_interface)
	jal	D_RegisterLoopCallbacks
	addiu	$4,$4,%lo(doom_loop_interface)

	lui	$17,%hi(deathmatch)
	lui	$2,%hi(gameversion)
	lui	$18,%hi(startepisode)
	lui	$19,%hi(startmap)
	lui	$20,%hi(startskill)
	lui	$fp,%hi(startloadgame)
	lui	$23,%hi(nomonsters)
	lui	$22,%hi(fastparm)
	lui	$21,%hi(respawnparm)
	lui	$16,%hi(timelimit)
	lw	$7,%lo(gameversion)($2)
	lw	$12,%lo(deathmatch)($17)
	lw	$11,%lo(startepisode)($18)
	lw	$10,%lo(startmap)($19)
	lw	$9,%lo(startskill)($20)
	lw	$8,%lo(startloadgame)($fp)
	lw	$6,%lo(nomonsters)($23)
	lw	$5,%lo(fastparm)($22)
	lw	$3,%lo(respawnparm)($21)
	lw	$2,%lo(timelimit)($16)
	lui	$4,%hi($LC3)
	addiu	$4,$4,%lo($LC3)
	sw	$12,32($sp)
	sw	$11,36($sp)
	sw	$10,52($sp)
	sw	$9,56($sp)
	sw	$8,76($sp)
	sw	$7,60($sp)
	sw	$6,40($sp)
	sw	$5,44($sp)
	sw	$3,48($sp)
	jal	M_CheckParm
	sw	$2,72($sp)

	bgtz	$2,$L49
	lui	$4,%hi($LC4)

	move	$2,$0
$L32:
	move	$5,$0
	addiu	$4,$sp,24
	jal	D_StartNetGame
	sw	$2,64($sp)

	lw	$3,76($sp)
	lw	$2,64($sp)
	sw	$3,%lo(startloadgame)($fp)
	lui	$3,%hi(lowres_turn)
	sw	$2,%lo(lowres_turn)($3)
	lw	$3,40($sp)
	lw	$6,32($sp)
	sw	$3,%lo(nomonsters)($23)
	lw	$3,44($sp)
	lw	$4,36($sp)
	sw	$3,%lo(fastparm)($22)
	lw	$3,48($sp)
	lw	$7,52($sp)
	sw	$3,%lo(respawnparm)($21)
	lw	$3,72($sp)
	lw	$5,56($sp)
	sw	$3,%lo(timelimit)($16)
	lw	$3,88($sp)
	lui	$11,%hi(consoleplayer)
	sw	$6,%lo(deathmatch)($17)
	sw	$4,%lo(startepisode)($18)
	sw	$7,%lo(startmap)($19)
	sw	$5,%lo(startskill)($20)
	bne	$2,$0,$L50
	sw	$3,%lo(consoleplayer)($11)

$L33:
	lw	$2,84($sp)
	lui	$12,%hi(playeringame)
	sltu	$10,$2,2
	sltu	$9,$2,3
	sltu	$8,$2,4
	addiu	$3,$12,%lo(playeringame)
	sw	$4,16($sp)
	xori	$10,$10,0x1
	xori	$9,$9,0x1
	xori	$8,$8,0x1
	lui	$4,%hi($LC8)
	sltu	$2,$0,$2
	addiu	$4,$4,%lo($LC8)
	sw	$10,4($3)
	sw	$9,8($3)
	sw	$8,12($3)
	sw	$11,128($sp)
	jal	printf
	sw	$2,%lo(playeringame)($12)

	lw	$11,128($sp)
	lw	$7,84($sp)
	lw	$5,%lo(consoleplayer)($11)
	lui	$4,%hi($LC9)
	addiu	$5,$5,1
	move	$6,$7
	jal	printf
	addiu	$4,$4,%lo($LC9)

	lw	$5,%lo(timelimit)($16)
	blez	$5,$L30
	lw	$2,%lo(deathmatch)($17)

	beq	$2,$0,$L53
	lw	$31,172($sp)

	li	$2,20			# 0x14
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L51
	.set	at
	nop

$L35:
	lui	$4,%hi($LC12)
	jal	printf
	addiu	$4,$4,%lo($LC12)

	lw	$2,%lo(timelimit)($16)
	slt	$2,$2,2
	beq	$2,$0,$L52
	nop

	lui	$4,%hi($LC14)
	jal	printf
	addiu	$4,$4,%lo($LC14)

$L30:
	lw	$31,172($sp)
$L53:
	lw	$fp,168($sp)
	lw	$23,164($sp)
	lw	$22,160($sp)
	lw	$21,156($sp)
	lw	$20,152($sp)
	lw	$19,148($sp)
	lw	$18,144($sp)
	lw	$17,140($sp)
	lw	$16,136($sp)
	jr	$31
	addiu	$sp,$sp,176

$L49:
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC4)

	b	$L32
	sltu	$2,$2,1

$L50:
	lui	$4,%hi($LC7)
	addiu	$4,$4,%lo($LC7)
	jal	printf
	sw	$11,128($sp)

	lw	$5,%lo(startskill)($20)
	lw	$6,%lo(deathmatch)($17)
	lw	$7,%lo(startmap)($19)
	lw	$4,%lo(startepisode)($18)
	b	$L33
	lw	$11,128($sp)

$L52:
	lui	$4,%hi($LC13)
	jal	printf
	addiu	$4,$4,%lo($LC13)

	lui	$4,%hi($LC14)
	jal	printf
	addiu	$4,$4,%lo($LC14)

	b	$L53
	lw	$31,172($sp)

$L51:
	lui	$4,%hi($LC10)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC10)

	beq	$2,$0,$L35
	lw	$5,%lo(timelimit)($16)

	lui	$4,%hi($LC11)
	jal	printf
	addiu	$4,$4,%lo($LC11)

	b	$L53
	lw	$31,172($sp)

	.set	macro
	.set	reorder
	.end	D_CheckNetGame
	.size	D_CheckNetGame, .-D_CheckNetGame
	.local	exitmsg.0
	.comm	exitmsg.0,80,4
	.data
	.align	2
	.type	doom_loop_interface, @object
	.size	doom_loop_interface, 16
doom_loop_interface:
	.word	D_ProcessEvents
	.word	G_BuildTiccmd
	.word	RunTic
	.word	M_Ticker
	.globl	netcmds
	.section	.bss,"aw",@nobits
	.align	2
	.type	netcmds, @object
	.size	netcmds, 4
netcmds:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
