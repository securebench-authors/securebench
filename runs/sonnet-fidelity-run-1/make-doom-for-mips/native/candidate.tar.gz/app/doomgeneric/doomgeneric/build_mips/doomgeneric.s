	.file	1 "doomgeneric.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	doomgeneric_Create
	.set	nomips16
	.set	nomicromips
	.ent	doomgeneric_Create
	.type	doomgeneric_Create, @function
doomgeneric_Create:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(myargc)
	addiu	$sp,$sp,-24
	sw	$4,%lo(myargc)($2)
	lui	$2,%hi(myargv)
	sw	$5,%lo(myargv)($2)
	sw	$31,20($sp)
	jal	M_FindResponseFile
	nop

	li	$4,983040			# 0xf0000
	jal	malloc
	ori	$4,$4,0xa000

	lui	$3,%hi(DG_ScreenBuffer)
	jal	DG_Init
	sw	$2,%lo(DG_ScreenBuffer)($3)

	lw	$31,20($sp)
	j	D_DoomMain
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	doomgeneric_Create
	.size	doomgeneric_Create, .-doomgeneric_Create
	.globl	DG_ScreenBuffer
	.section	.bss,"aw",@nobits
	.align	2
	.type	DG_ScreenBuffer, @object
	.size	DG_ScreenBuffer, 4
DG_ScreenBuffer:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
