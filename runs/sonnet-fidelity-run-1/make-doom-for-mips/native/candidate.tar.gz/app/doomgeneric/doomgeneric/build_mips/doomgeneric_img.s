	.file	1 "doomgeneric_img.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"DoomGeneric initialized. Frames will be saved to /tmp/fr"
	.ascii	"ame.bmp\012\000"
	.text
	.align	2
	.globl	DG_Init
	.set	nomips16
	.set	nomicromips
	.ent	DG_Init
	.type	DG_Init, @function
DG_Init:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(s_KeyQueue)
	addiu	$sp,$sp,-24
	addiu	$4,$4,%lo(s_KeyQueue)
	li	$6,32			# 0x20
	sw	$31,20($sp)
	jal	memset
	move	$5,$0

	lw	$31,20($sp)
	lui	$4,%hi($LC0)
	addiu	$4,$4,%lo($LC0)
	j	printf
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	DG_Init
	.size	DG_Init, .-DG_Init
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Memory allocation failed\012\000"
	.align	2
$LC2:
	.ascii	"wb\000"
	.align	2
$LC3:
	.ascii	"/tmp/frame.bmp\000"
	.align	2
$LC4:
	.ascii	"Cannot open file %s\012\000"
	.align	2
$LC5:
	.ascii	"Error writing file: %zu of %u bytes written\012\000"
	.text
	.align	2
	.globl	DG_DrawFrame
	.set	nomips16
	.set	nomicromips
	.ent	DG_DrawFrame
	.type	DG_DrawFrame, @function
DG_DrawFrame:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$6,%hi(drawk)
	lw	$5,%lo(drawk)($6)
	li	$2,-859045888			# 0xffffffffcccc0000
	ori	$2,$2,0xcccd
	multu	$5,$2
	mflo	$4
	li	$3,429457408			# 0x19990000
	ori	$3,$3,0x9998
	addu	$2,$4,$3
	srl	$4,$2,1
	sll	$2,$2,31
	addiu	$3,$3,1
	or	$2,$4,$2
	addiu	$5,$5,1
	sltu	$2,$2,$3
	bne	$2,$0,$L19
	sw	$5,%lo(drawk)($6)

	jr	$31
	nop

$L19:
	li	$4,983040			# 0xf0000
	addiu	$sp,$sp,-40
	ori	$4,$4,0xa038
	lui	$2,%hi(DG_ScreenBuffer)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,36($sp)
	lw	$16,%lo(DG_ScreenBuffer)($2)
	sw	$19,32($sp)
	jal	malloc
	sw	$18,28($sp)

	move	$17,$2
	move	$3,$2
	addiu	$4,$2,1024
$L6:
	sb	$0,0($3)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L6
	.set	at
	nop

	beq	$17,$0,$L20
	li	$2,983040			# 0xf0000

	ori	$2,$2,0xa036
	addiu	$3,$2,-54
	sw	$2,4($17)
	li	$2,54			# 0x36
	sw	$2,12($17)
	li	$2,40			# 0x28
	sw	$2,16($17)
	li	$2,640			# 0x280
	sw	$2,20($17)
	li	$2,-400			# 0xfffffffffffffe70
	sw	$2,24($17)
	li	$2,2097152			# 0x200000
	addiu	$2,$2,1
	li	$4,19778			# 0x4d42
	sw	$2,28($17)
	li	$2,196608			# 0x30000
	addiu	$18,$17,2
	sh	$4,2($17)
	sw	$0,8($17)
	sw	$0,32($17)
	sw	$3,36($17)
	sw	$0,40($17)
	sw	$0,44($17)
	sw	$0,48($17)
	sw	$0,52($17)
	addiu	$6,$17,2616
	move	$7,$16
	move	$8,$0
	ori	$2,$2,0xe800
$L8:
	addiu	$3,$6,-2560
	move	$4,$7
$L9:
	lw	$5,0($4)
	addiu	$3,$3,4
	addiu	$4,$4,4
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L9
	.set	at
	sw	$5,-4($3)

	addiu	$8,$8,640
	addiu	$6,$3,2560
	.set	noat
	xor	$1,$8,$2
	bne	$1,$0,$L8
	.set	at
	addiu	$7,$7,2560

	lui	$19,%hi($LC3)
	lui	$5,%hi($LC2)
	addiu	$5,$5,%lo($LC2)
	jal	fopen
	addiu	$4,$19,%lo($LC3)

	beq	$2,$0,$L21
	move	$16,$2

	li	$19,983040			# 0xf0000
	move	$7,$2
	ori	$6,$19,0xa036
	li	$5,1			# 0x1
	jal	fwrite
	move	$4,$18

	ori	$7,$19,0xa036
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L22
	.set	at
	move	$6,$2

$L12:
	jal	fclose
	move	$4,$16

	move	$4,$17
$L18:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	free
	addiu	$sp,$sp,40

$L22:
	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC5)
	jal	fprintf
	addiu	$5,$5,%lo($LC5)

	b	$L12
	nop

$L21:
	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC4)
	addiu	$6,$19,%lo($LC3)
	jal	fprintf
	addiu	$5,$5,%lo($LC4)

	b	$L18
	move	$4,$18

$L20:
	lui	$2,%hi(stderr)
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$5,%hi($LC1)
	lw	$4,%lo(stderr)($2)
	addiu	$5,$5,%lo($LC1)
	j	fprintf
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	DG_DrawFrame
	.size	DG_DrawFrame, .-DG_DrawFrame
	.align	2
	.globl	DG_SleepMs
	.set	nomips16
	.set	nomicromips
	.ent	DG_SleepMs
	.type	DG_SleepMs, @function
DG_SleepMs:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	addiu	$sp,$sp,-8
	sll	$7,$4,1
	move	$2,$0
	move	$3,$0
	addu	$8,$7,$4
	sw	$2,0($sp)
	sw	$3,4($sp)
	srl	$4,$4,31
	lw	$2,0($sp)
	sltu	$7,$8,$7
	lw	$3,4($sp)
	addu	$7,$7,$4
	sltu	$4,$3,$7
	beq	$4,$0,$L33
$L30:
	lw	$10,0($sp)
	lw	$11,4($sp)
	addiu	$6,$10,1
	sltu	$4,$6,$10
	addu	$3,$4,$11
	sw	$6,0($sp)
	sw	$3,4($sp)
	lw	$10,0($sp)
	lw	$11,4($sp)
	sltu	$4,$11,$7
	bne	$4,$0,$L30
	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$7,$11
	bne	$1,$0,$L25
	.set	at
	sltu	$2,$10,$8
	.set	macro
	.set	reorder

$L32:
	bne	$2,$0,$L30
$L25:
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L33:
	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$7,$3
	bne	$1,$0,$L25
	.set	at
	sltu	$2,$2,$8
	.set	macro
	.set	reorder

	b	$L32
	.end	DG_SleepMs
	.size	DG_SleepMs, .-DG_SleepMs
	.align	2
	.globl	DG_GetTicksMs
	.set	nomips16
	.set	nomicromips
	.ent	DG_GetTicksMs
	.type	DG_GetTicksMs, @function
DG_GetTicksMs:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(ms_ctr)
	lw	$2,%lo(ms_ctr)($3)
	addiu	$4,$2,1
	jr	$31
	sw	$4,%lo(ms_ctr)($3)

	.set	macro
	.set	reorder
	.end	DG_GetTicksMs
	.size	DG_GetTicksMs, .-DG_GetTicksMs
	.align	2
	.globl	DG_GetKey
	.set	nomips16
	.set	nomicromips
	.ent	DG_GetKey
	.type	DG_GetKey, @function
DG_GetKey:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(s_KeyQueueReadIndex)
	lw	$2,%lo(s_KeyQueueReadIndex)($3)
	beq	$2,$0,$L37
	lui	$7,%hi(s_KeyQueue)

	sll	$6,$2,1
	addiu	$7,$7,%lo(s_KeyQueue)
	addu	$6,$6,$7
	lhu	$6,0($6)
	addiu	$2,$2,1
	andi	$2,$2,0xf
	srl	$7,$6,8
	sw	$7,0($4)
	sw	$2,%lo(s_KeyQueueReadIndex)($3)
	sb	$6,0($5)
	jr	$31
	li	$2,1			# 0x1

$L37:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	DG_GetKey
	.size	DG_GetKey, .-DG_GetKey
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"DoomGeneric title: %s\012\000"
	.text
	.align	2
	.globl	DG_SetWindowTitle
	.set	nomips16
	.set	nomicromips
	.ent	DG_SetWindowTitle
	.type	DG_SetWindowTitle, @function
DG_SetWindowTitle:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$5,$4
	lui	$4,%hi($LC6)
	j	printf
	addiu	$4,$4,%lo($LC6)

	.set	macro
	.set	reorder
	.end	DG_SetWindowTitle
	.size	DG_SetWindowTitle, .-DG_SetWindowTitle
	.section	.text.startup,"ax",@progbits
	.align	2
	.globl	main
	.set	nomips16
	.set	nomicromips
	.ent	main
	.type	main, @function
main:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	doomgeneric_Create
	nop

$L40:
	jal	doomgeneric_Tick
	nop

	jal	doomgeneric_Tick
	nop

	b	$L40
	nop

	.set	macro
	.set	reorder
	.end	main
	.size	main, .-main
	.align	2
	.globl	__start
	.set	nomips16
	.set	nomicromips
	.ent	__start
	.type	__start, @function
__start:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	move	$5,$0
	sw	$31,20($sp)
	jal	main
	move	$4,$0

	.set	macro
	.set	reorder
	.end	__start
	.size	__start, .-__start
	.globl	ms_ctr
	.section	.bss,"aw",@nobits
	.align	2
	.type	ms_ctr, @object
	.size	ms_ctr, 4
ms_ctr:
	.space	4
	.globl	drawk
	.align	2
	.type	drawk, @object
	.size	drawk, 4
drawk:
	.space	4
	.local	s_KeyQueueReadIndex
	.comm	s_KeyQueueReadIndex,4,4
	.local	s_KeyQueue
	.comm	s_KeyQueue,32,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
