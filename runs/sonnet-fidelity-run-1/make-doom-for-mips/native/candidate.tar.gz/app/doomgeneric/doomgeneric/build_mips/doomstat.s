	.file	1 "doomstat.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.globl	modifiedgame
	.section	.bss,"aw",@nobits
	.align	2
	.type	modifiedgame, @object
	.size	modifiedgame, 4
modifiedgame:
	.space	4
	.globl	gamedescription
	.align	2
	.type	gamedescription, @object
	.size	gamedescription, 4
gamedescription:
	.space	4
	.globl	gameversion
	.data
	.align	2
	.type	gameversion, @object
	.size	gameversion, 4
gameversion:
	.word	8
	.globl	gamemission
	.section	.bss
	.align	2
	.type	gamemission, @object
	.size	gamemission, 4
gamemission:
	.space	4
	.globl	gamemode
	.data
	.align	2
	.type	gamemode, @object
	.size	gamemode, 4
gamemode:
	.word	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
