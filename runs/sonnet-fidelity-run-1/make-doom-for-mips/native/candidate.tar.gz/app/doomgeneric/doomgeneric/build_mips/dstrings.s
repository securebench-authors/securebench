	.file	1 "dstrings.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.globl	doom2_endmsg
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"are you sure you want to\012quit this great game?\000"
	.align	2
$LC1:
	.ascii	"you want to quit?\012then, thou hast lost an eighth!\000"
	.align	2
$LC2:
	.ascii	"don't go now, there's a \012dimensional shambler waiting"
	.ascii	"\012at the dos prompt!\000"
	.align	2
$LC3:
	.ascii	"get outta here and go back\012to your boring programs.\000"
	.align	2
$LC4:
	.ascii	"if i were your boss, i'd \012 deathmatch ya in a minute!"
	.ascii	"\000"
	.align	2
$LC5:
	.ascii	"look, bud. you leave now\012and you forfeit your body co"
	.ascii	"unt!\000"
	.align	2
$LC6:
	.ascii	"just leave. when you come\012back, i'll be waiting with "
	.ascii	"a bat.\000"
	.align	2
$LC7:
	.ascii	"you're lucky i don't smack\012you for thinking about lea"
	.ascii	"ving.\000"
	.data
	.align	2
	.type	doom2_endmsg, @object
	.size	doom2_endmsg, 32
doom2_endmsg:
	.word	$LC0
	.word	$LC1
	.word	$LC2
	.word	$LC3
	.word	$LC4
	.word	$LC5
	.word	$LC6
	.word	$LC7
	.globl	doom1_endmsg
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"please don't leave, there's more\012demons to toast!\000"
	.align	2
$LC9:
	.ascii	"let's beat it -- this is turning\012into a bloodbath!\000"
	.align	2
$LC10:
	.ascii	"i wouldn't leave if i were you.\012dos is much worse.\000"
	.align	2
$LC11:
	.ascii	"you're trying to say you like dos\012better than me, rig"
	.ascii	"ht?\000"
	.align	2
$LC12:
	.ascii	"don't leave yet -- there's a\012demon around that corner"
	.ascii	"!\000"
	.align	2
$LC13:
	.ascii	"ya know, next time you come in here\012i'm gonna toast y"
	.ascii	"a.\000"
	.align	2
$LC14:
	.ascii	"go ahead and leave. see if i care.\000"
	.data
	.align	2
	.type	doom1_endmsg, @object
	.size	doom1_endmsg, 32
doom1_endmsg:
	.word	$LC0
	.word	$LC8
	.word	$LC9
	.word	$LC10
	.word	$LC11
	.word	$LC12
	.word	$LC13
	.word	$LC14
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
