	.file	1 "dummy.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	I_InitTimidityConfig
	.set	nomips16
	.set	nomicromips
	.ent	I_InitTimidityConfig
	.type	I_InitTimidityConfig, @function
I_InitTimidityConfig:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_InitTimidityConfig
	.size	I_InitTimidityConfig, .-I_InitTimidityConfig
	.globl	drone
	.section	.bss,"aw",@nobits
	.align	2
	.type	drone, @object
	.size	drone, 4
drone:
	.space	4
	.globl	net_client_connected
	.align	2
	.type	net_client_connected, @object
	.size	net_client_connected, 4
net_client_connected:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
