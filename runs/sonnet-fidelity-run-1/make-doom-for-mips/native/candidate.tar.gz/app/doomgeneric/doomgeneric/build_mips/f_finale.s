	.file	1 "f_finale.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	F_CastTicker.part.0
	.type	F_CastTicker.part.0, @function
F_CastTicker.part.0:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$16,20($sp)
	lui	$16,%hi(caststate)
	lw	$3,%lo(caststate)($16)
	li	$2,-1			# 0xffffffffffffffff
	lw	$4,8($3)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L2
	.set	at
	sw	$17,24($sp)

	lw	$2,16($3)
	beq	$2,$0,$L2
	lui	$4,%hi(states+4312)

	addiu	$4,$4,%lo(states+4312)
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L57
	.set	at
	lui	$18,%hi(states)

	lui	$20,%hi(castframes)
	sll	$3,$2,3
	lw	$6,%lo(castframes)($20)
	subu	$3,$3,$2
	sll	$3,$3,2
	addiu	$18,$18,%lo(states)
	addu	$3,$18,$3
	addiu	$6,$6,1
	sltu	$4,$2,384
	sw	$3,%lo(caststate)($16)
	beq	$4,$0,$L10
	sw	$6,%lo(castframes)($20)

	sltu	$3,$2,377
	beq	$3,$0,$L11
	li	$3,256			# 0x100

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L30
	.set	at
	sltu	$3,$2,257

	bne	$3,$0,$L58
	li	$3,338			# 0x152

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L35
	.set	at
	li	$3,340			# 0x154

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L59
	.set	at
	li	$5,107			# 0x6b

$L12:
	jal	S_StartSound
	move	$4,$0

	lw	$6,%lo(castframes)($20)
	li	$2,12			# 0xc
$L68:
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L20
	.set	at
	lui	$2,%hi(castnum)

	lw	$4,%lo(castnum)($2)
	lui	$2,%hi(castorder)
	sll	$4,$4,3
	addiu	$2,$2,%lo(castorder)
	addu	$2,$2,$4
	lw	$5,4($2)
	lui	$7,%hi(castonmelee)
	sll	$4,$5,1
	addu	$6,$4,$5
	lw	$9,%lo(castonmelee)($7)
	lui	$3,%hi(castattacking)
	li	$8,1			# 0x1
	sll	$6,$6,3
	sw	$8,%lo(castattacking)($3)
	lui	$17,%hi(mobjinfo)
	beq	$9,$0,$L21
	subu	$6,$6,$5

	sll	$6,$6,2
	addiu	$17,$17,%lo(mobjinfo)
	addu	$6,$17,$6
	lw	$11,40($6)
	xori	$10,$9,0x1
	sll	$2,$11,3
	subu	$2,$2,$11
	sll	$2,$2,2
	addu	$2,$18,$2
	sw	$2,%lo(caststate)($16)
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L23
	.set	at
	sw	$10,%lo(castonmelee)($7)

	.set	noat
	xor	$1,$9,$8
	bne	$1,$0,$L55
	.set	at
	nop

	lw	$6,44($6)
	sll	$2,$6,3
	subu	$2,$2,$6
	sll	$2,$2,2
	addu	$2,$18,$2
$L55:
	b	$L23
	sw	$2,%lo(caststate)($16)

$L2:
	lui	$21,%hi(castnum)
	lw	$3,%lo(castnum)($21)
	lui	$19,%hi(castorder)
	addiu	$3,$3,1
	sll	$2,$3,3
	addiu	$19,$19,%lo(castorder)
	addu	$4,$19,$2
	lw	$4,0($4)
	sw	$3,%lo(castnum)($21)
	lui	$3,%hi(castdeath)
	beq	$4,$0,$L60
	sw	$0,%lo(castdeath)($3)

	addu	$2,$19,$2
	lw	$4,4($2)
	lui	$17,%hi(mobjinfo)
	sll	$2,$4,1
	addu	$3,$2,$4
	sll	$3,$3,3
	subu	$3,$3,$4
	sll	$3,$3,2
	addiu	$17,$17,%lo(mobjinfo)
	addu	$3,$17,$3
	lw	$5,16($3)
	bne	$5,$0,$L61
	nop

$L5:
	addu	$2,$2,$4
	sll	$2,$2,3
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$3,12($2)
	lui	$18,%hi(states)
	sll	$2,$3,3
	subu	$2,$2,$3
	lui	$3,%hi(castattacking)
	sll	$2,$2,2
	addiu	$18,$18,%lo(states)
	lw	$4,%lo(castattacking)($3)
	addu	$2,$18,$2
	lui	$20,%hi(castframes)
	sw	$2,%lo(caststate)($16)
	bne	$4,$0,$L62
	sw	$0,%lo(castframes)($20)

	lw	$2,%lo(caststate)($16)
$L28:
	lw	$2,8($2)
	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L69
	.set	at
	lw	$31,44($sp)

	li	$2,15			# 0xf
$L69:
	lui	$3,%hi(casttics)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$2,%lo(casttics)($3)
	jr	$31
	addiu	$sp,$sp,48

$L62:
	lw	$2,%lo(castnum)($21)
	sll	$2,$2,3
	addu	$19,$19,$2
	lw	$5,4($19)
$L26:
	lw	$2,%lo(caststate)($16)
	sll	$4,$5,1
$L23:
	addu	$4,$4,$5
	sll	$4,$4,3
	subu	$4,$4,$5
	sll	$4,$4,2
	addu	$17,$17,$4
	lw	$5,12($17)
	sll	$4,$5,3
	subu	$4,$4,$5
	sll	$4,$4,2
	addu	$18,$18,$4
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L28
	.set	at
	nop

$L9:
	sw	$0,%lo(castattacking)($3)
	sw	$0,%lo(castframes)($20)
	b	$L28
	sw	$2,%lo(caststate)($16)

$L61:
	jal	S_StartSound
	move	$4,$0

	lw	$2,%lo(castnum)($21)
	sll	$2,$2,3
	addu	$2,$19,$2
	lw	$4,4($2)
	b	$L5
	sll	$2,$4,1

$L60:
	move	$2,$0
	addu	$2,$19,$2
	lw	$4,4($2)
	lui	$17,%hi(mobjinfo)
	sll	$2,$4,1
	addu	$3,$2,$4
	sll	$3,$3,3
	subu	$3,$3,$4
	sll	$3,$3,2
	addiu	$17,$17,%lo(mobjinfo)
	addu	$3,$17,$3
	lw	$5,16($3)
	beq	$5,$0,$L5
	sw	$0,%lo(castnum)($21)

	b	$L61
	nop

$L10:
	li	$3,590			# 0x24e
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L38
	.set	at
	sltu	$3,$2,591

	bne	$3,$0,$L63
	li	$3,685			# 0x2ad

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L48
	.set	at
	sltu	$3,$2,686

	bne	$3,$0,$L64
	li	$3,689			# 0x2b1

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L48
	.set	at
	li	$3,710			# 0x2c6

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,51			# 0x33

	li	$3,687			# 0x2af
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L68
	.set	at
	li	$2,12			# 0xc

$L48:
	b	$L12
	li	$5,14			# 0xe

$L63:
	li	$3,486			# 0x1e6
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L39
	.set	at
	sltu	$3,$2,487

	bne	$3,$0,$L65
	li	$3,538			# 0x21a

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L42
	.set	at
	li	$3,567			# 0x237

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,16			# 0x10

	li	$3,505			# 0x1f9
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$2,12			# 0xc

	b	$L68
	nop

$L58:
	li	$3,185			# 0xb9
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L31
	.set	at
	li	$3,218			# 0xda

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,2			# 0x2

	li	$3,154			# 0x9a
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,4			# 0x4

	b	$L68
	li	$2,12			# 0xc

$L65:
	sltu	$3,$2,420
	bne	$3,$0,$L66
	li	$3,454			# 0x1c6

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,55			# 0x37

	b	$L68
	li	$2,12			# 0xc

$L66:
	sltu	$2,$2,417
	bne	$2,$0,$L68
	li	$2,12			# 0xc

	b	$L12
	li	$5,2			# 0x2

$L11:
	addiu	$3,$2,-377
	li	$2,73			# 0x49
	srl	$2,$2,$3
	andi	$2,$2,0x1
	beq	$2,$0,$L68
	li	$2,12			# 0xc

$L42:
	b	$L12
	li	$5,16			# 0x10

$L59:
	li	$3,336			# 0x150
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,56			# 0x38

	b	$L68
	li	$2,12			# 0xc

$L64:
	sltu	$3,$2,618
	bne	$3,$0,$L67
	li	$3,648			# 0x288

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L12
	.set	at
	li	$5,8			# 0x8

	b	$L68
	li	$2,12			# 0xc

$L67:
	sltu	$2,$2,616
	bne	$2,$0,$L68
	li	$2,12			# 0xc

	b	$L12
	li	$5,2			# 0x2

$L21:
	addiu	$17,$17,%lo(mobjinfo)
	sll	$6,$6,2
	addu	$6,$17,$6
	lw	$9,44($6)
	sw	$8,%lo(castonmelee)($7)
	sll	$2,$9,3
	subu	$2,$2,$9
	sll	$2,$2,2
	addu	$2,$18,$2
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L23
	.set	at
	sw	$2,%lo(caststate)($16)

	lw	$6,40($6)
	sll	$2,$6,3
	subu	$2,$2,$6
	sll	$2,$2,2
	addu	$2,$18,$2
	b	$L23
	sw	$2,%lo(caststate)($16)

$L31:
	b	$L12
	li	$5,1			# 0x1

$L39:
	b	$L12
	li	$5,52			# 0x34

$L35:
	b	$L12
	li	$5,53			# 0x35

$L57:
	lui	$2,%hi(castnum)
	lw	$3,%lo(castnum)($2)
	lui	$2,%hi(castorder)
	sll	$3,$3,3
	addiu	$2,$2,%lo(castorder)
	addu	$2,$2,$3
	lw	$3,4($2)
	lui	$20,%hi(castframes)
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	lui	$3,%hi(mobjinfo)
	addiu	$3,$3,%lo(mobjinfo)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$2,12($2)
	sll	$3,$2,3
	subu	$3,$3,$2
	lui	$2,%hi(states)
	sll	$3,$3,2
	addiu	$2,$2,%lo(states)
	addu	$2,$2,$3
	b	$L9
	lui	$3,%hi(castattacking)

$L30:
	b	$L12
	li	$5,54			# 0x36

$L38:
	b	$L12
	li	$5,51			# 0x33

$L20:
	lui	$3,%hi(castattacking)
	lw	$2,%lo(castattacking)($3)
	beq	$2,$0,$L28
	lw	$2,%lo(caststate)($16)

	lui	$2,%hi(castnum)
	lw	$4,%lo(castnum)($2)
	lui	$2,%hi(castorder)
	sll	$4,$4,3
	addiu	$2,$2,%lo(castorder)
	addu	$2,$2,$4
	lw	$5,4($2)
	li	$2,92			# 0x5c
	multu	$5,$2
	mflo	$4
	lui	$17,%hi(mobjinfo)
	addiu	$17,$17,%lo(mobjinfo)
	addu	$2,$4,$17
	li	$7,24			# 0x18
	.set	noat
	xor	$1,$6,$7
	bne	$1,$0,$L26
	.set	at
	lw	$4,12($2)

	sll	$2,$4,3
	subu	$2,$2,$4
	sll	$2,$2,2
	b	$L9
	addu	$2,$18,$2

	.set	macro
	.set	reorder
	.end	F_CastTicker.part.0
	.size	F_CastTicker.part.0, .-F_CastTicker.part.0
	.align	2
	.globl	F_StartFinale
	.set	nomips16
	.set	nomicromips
	.ent	F_StartFinale
	.type	F_StartFinale, @function
F_StartFinale:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	lui	$16,%hi(gamemission)
	lw	$2,%lo(gamemission)($16)
	li	$3,-5			# 0xfffffffffffffffb
	and	$2,$2,$3
	lui	$3,%hi(gameaction)
	sw	$0,%lo(gameaction)($3)
	li	$4,2			# 0x2
	lui	$3,%hi(gamestate)
	sw	$4,%lo(gamestate)($3)
	lui	$3,%hi(viewactive)
	sw	$0,%lo(viewactive)($3)
	lui	$3,%hi(automapactive)
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$0,%lo(automapactive)($3)
	beq	$2,$0,$L100
	li	$5,1			# 0x1

	jal	S_ChangeMusic
	li	$4,65			# 0x41

	lui	$4,%hi(gameepisode)
$L109:
	lui	$2,%hi(textscreens)
	lui	$3,%hi(gameversion)
	lw	$10,%lo(gameepisode)($4)
	addiu	$2,$2,%lo(textscreens)
	lui	$4,%hi(gamemap)
	lw	$6,%lo(gameversion)($3)
	lw	$11,%lo(gamemap)($4)
	lw	$3,%lo(gamemission)($16)
	addiu	$5,$2,440
	move	$13,$0
	li	$4,9			# 0x9
	li	$12,1			# 0x1
	li	$7,4			# 0x4
	b	$L86
	li	$8,5			# 0x5

$L73:
	.set	noat
	xor	$1,$3,$7
	beq	$1,$0,$L101
	.set	at
	nop

$L80:
	.set	noat
	xor	$1,$3,$8
	beq	$1,$0,$L102
	.set	at
	nop

	lw	$9,0($2)
	.set	noat
	xor	$1,$3,$9
	beq	$1,$0,$L103
	.set	at
	nop

$L85:
	addiu	$2,$2,20
$L108:
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L104
	.set	at
	nop

$L86:
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L73
	.set	at
	nop

	lw	$9,0($2)
	bne	$9,$0,$L74
	nop

	.set	noat
	xor	$1,$3,$7
	beq	$1,$0,$L84
	.set	at
	sw	$8,8($2)

	.set	noat
	xor	$1,$3,$8
	beq	$1,$0,$L85
	.set	at
	nop

	lw	$9,0($2)
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L85
	.set	at
	nop

$L103:
	bne	$3,$0,$L76
	nop

$L84:
	lw	$9,4($2)
	.set	noat
	xor	$1,$9,$10
	bne	$1,$0,$L85
	.set	at
	nop

$L76:
	lw	$9,8($2)
$L106:
	.set	noat
	xor	$1,$9,$11
	bne	$1,$0,$L85
	.set	at
	nop

	lw	$17,16($2)
$L107:
	lw	$18,12($2)
	addiu	$2,$2,20
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L86
	.set	at
	li	$13,1			# 0x1

$L104:
	beq	$13,$0,$L87
	lui	$2,%hi(finaleflat)

	sw	$18,%lo(finaleflat)($2)
	lui	$2,%hi(finaletext)
	sw	$17,%lo(finaletext)($2)
$L87:
	lw	$31,28($sp)
	lui	$2,%hi(finalestage)
	sw	$0,%lo(finalestage)($2)
	lui	$2,%hi(finalecount)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$0,%lo(finalecount)($2)
	jr	$31
	addiu	$sp,$sp,32

$L101:
	lw	$9,0($2)
	bne	$9,$0,$L85
	nop

	lw	$9,4($2)
	.set	noat
	xor	$1,$9,$10
	bne	$1,$0,$L85
	.set	at
	nop

	b	$L106
	lw	$9,8($2)

$L102:
	lw	$9,0($2)
	.set	noat
	xor	$1,$9,$12
	bne	$1,$0,$L85
	.set	at
	nop

	lw	$9,8($2)
	.set	noat
	xor	$1,$9,$11
	bne	$1,$0,$L85
	.set	at
	nop

	b	$L107
	lw	$17,16($2)

$L74:
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L80
	.set	at
	nop

	b	$L108
	addiu	$2,$2,20

$L100:
	jal	S_ChangeMusic
	li	$4,31			# 0x1f

	b	$L109
	lui	$4,%hi(gameepisode)

	.set	macro
	.set	reorder
	.end	F_StartFinale
	.size	F_StartFinale, .-F_StartFinale
	.align	2
	.globl	F_Responder
	.set	nomips16
	.set	nomicromips
	.ent	F_Responder
	.type	F_Responder, @function
F_Responder:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(finalestage)
	lw	$3,%lo(finalestage)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L125
	.set	at
	nop

$L116:
	jr	$31
	move	$2,$0

$L125:
	lw	$2,0($4)
	bne	$2,$0,$L116
	lui	$6,%hi(castdeath)

	lw	$2,%lo(castdeath)($6)
	bne	$2,$0,$L121
	nop

	lui	$2,%hi(castnum)
	lw	$3,%lo(castnum)($2)
	lui	$2,%hi(castorder)
	sll	$3,$3,3
	addiu	$2,$2,%lo(castorder)
	addu	$2,$2,$3
	lw	$3,4($2)
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	lui	$3,%hi(mobjinfo)
	addiu	$3,$3,%lo(mobjinfo)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,48($2)
	lw	$5,56($2)
	sll	$4,$3,3
	subu	$4,$4,$3
	lui	$3,%hi(states)
	sll	$4,$4,2
	addiu	$3,$3,%lo(states)
	addu	$3,$3,$4
	li	$2,1			# 0x1
	lw	$4,8($3)
	sw	$2,%lo(castdeath)($6)
	lui	$2,%hi(caststate)
	sw	$3,%lo(caststate)($2)
	lui	$2,%hi(casttics)
	sw	$4,%lo(casttics)($2)
	lui	$2,%hi(castframes)
	sw	$0,%lo(castframes)($2)
	lui	$2,%hi(castattacking)
	bne	$5,$0,$L126
	sw	$0,%lo(castattacking)($2)

$L121:
	jr	$31
	li	$2,1			# 0x1

$L126:
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	S_StartSound
	move	$4,$0

	lw	$31,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	F_Responder
	.size	F_Responder, .-F_Responder
	.align	2
	.globl	F_TextWrite
	.set	nomips16
	.set	nomicromips
	.ent	F_TextWrite
	.type	F_TextWrite, @function
F_TextWrite:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(finaleflat)
	lw	$4,%lo(finaleflat)($2)
	addiu	$sp,$sp,-48
	li	$5,8			# 0x8
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$17,20($sp)
	jal	W_CacheLumpName
	sw	$16,16($sp)

	lui	$3,%hi(I_VideoBuffer)
	lw	$18,%lo(I_VideoBuffer)($3)
	move	$20,$2
	addiu	$18,$18,320
	move	$19,$0
	li	$21,12800			# 0x3200
$L128:
	andi	$17,$19,0xfc0
	addiu	$16,$18,-320
	addu	$17,$20,$17
	move	$4,$16
$L147:
	li	$6,64			# 0x40
	addiu	$16,$16,64
	jal	memcpy
	move	$5,$17

	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L147
	.set	at
	move	$4,$16

	addiu	$19,$19,64
	.set	noat
	xor	$1,$19,$21
	bne	$1,$0,$L128
	.set	at
	addiu	$18,$16,320

	li	$7,200			# 0xc8
	li	$6,320			# 0x140
	move	$5,$0
	jal	V_MarkRect
	move	$4,$0

	lui	$2,%hi(finalecount)
	lw	$2,%lo(finalecount)($2)
	slt	$3,$2,8
	bne	$3,$0,$L148
	lw	$31,44($sp)

	li	$3,1431633920			# 0x55550000
	addiu	$2,$2,-10
	addiu	$3,$3,21846
	mult	$2,$3
	sra	$2,$2,31
	mfhi	$3
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L148
	.set	at
	subu	$20,$3,$2

	lui	$2,%hi(finaletext)
	lw	$19,%lo(finaletext)($2)
	lui	$21,%hi(hu_font)
	move	$16,$19
	li	$17,10			# 0xa
	li	$22,10			# 0xa
	li	$18,10			# 0xa
	b	$L136
	addiu	$21,$21,%lo(hu_font)

$L133:
	jal	toupper
	nop

	addiu	$2,$2,-33
	sll	$3,$2,2
	sltu	$2,$2,64
	addu	$3,$3,$21
	move	$4,$22
	beq	$2,$0,$L146
	move	$5,$17

	lw	$6,0($3)
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$22,$2,$22
	slt	$2,$22,321
	beq	$2,$0,$L148
	lw	$31,44($sp)

	jal	V_DrawPatch
	nop

$L134:
	subu	$2,$19,$16
	addu	$2,$2,$20
	beq	$2,$0,$L148
	lw	$31,44($sp)

$L136:
	lb	$2,0($16)
	addiu	$16,$16,1
	beq	$2,$0,$L127
	move	$4,$2

	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L133
	.set	at
	subu	$2,$19,$16

	addu	$2,$2,$20
	addiu	$17,$17,11
	bne	$2,$0,$L136
	li	$22,10			# 0xa

$L127:
	lw	$31,44($sp)
$L148:
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L146:
	b	$L134
	addiu	$22,$22,4

	.set	macro
	.set	reorder
	.end	F_TextWrite
	.size	F_TextWrite, .-F_TextWrite
	.align	2
	.globl	F_StartCast
	.set	nomips16
	.set	nomicromips
	.ent	F_StartCast
	.type	F_StartCast, @function
F_StartCast:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(castorder+4)
	lw	$3,%lo(castorder+4)($2)
	lui	$6,%hi(wipegamestate)
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	lui	$3,%hi(mobjinfo)
	addiu	$3,$3,%lo(mobjinfo)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$2,12($2)
	li	$7,-1			# 0xffffffffffffffff
	sll	$3,$2,3
	subu	$3,$3,$2
	lui	$2,%hi(states)
	sll	$3,$3,2
	addiu	$2,$2,%lo(states)
	addu	$2,$2,$3
	sw	$7,%lo(wipegamestate)($6)
	lui	$6,%hi(castnum)
	lw	$3,8($2)
	sw	$0,%lo(castnum)($6)
	lui	$6,%hi(caststate)
	sw	$2,%lo(caststate)($6)
	lui	$2,%hi(casttics)
	sw	$3,%lo(casttics)($2)
	lui	$2,%hi(castdeath)
	sw	$0,%lo(castdeath)($2)
	li	$3,2			# 0x2
	lui	$2,%hi(finalestage)
	sw	$3,%lo(finalestage)($2)
	lui	$2,%hi(castframes)
	sw	$0,%lo(castframes)($2)
	lui	$2,%hi(castonmelee)
	sw	$0,%lo(castonmelee)($2)
	li	$5,1			# 0x1
	lui	$2,%hi(castattacking)
	li	$4,63			# 0x3f
	j	S_ChangeMusic
	sw	$0,%lo(castattacking)($2)

	.set	macro
	.set	reorder
	.end	F_StartCast
	.size	F_StartCast, .-F_StartCast
	.align	2
	.globl	F_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	F_Ticker
	.type	F_Ticker, @function
F_Ticker:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	lui	$17,%hi(gamemode)
	lw	$4,%lo(gamemode)($17)
	sw	$16,16($sp)
	li	$3,2			# 0x2
	lui	$16,%hi(finalecount)
	lw	$2,%lo(finalecount)($16)
	sw	$31,28($sp)
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L163
	.set	at
	sw	$18,24($sp)

$L152:
	lui	$18,%hi(finalestage)
$L167:
	lw	$4,%lo(finalestage)($18)
	addiu	$2,$2,1
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L164
	.set	at
	sw	$2,%lo(finalecount)($16)

$L157:
	lw	$2,%lo(gamemode)($17)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L168
	.set	at
	lw	$31,28($sp)

	beq	$4,$0,$L165
	lui	$2,%hi(finaletext)

$L150:
	lw	$31,28($sp)
$L168:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L165:
	jal	strlen
	lw	$4,%lo(finaletext)($2)

	sll	$3,$2,1
	lw	$4,%lo(finalecount)($16)
	addu	$3,$3,$2
	addiu	$3,$3,250
	sltu	$3,$3,$4
	beq	$3,$0,$L168
	lw	$31,28($sp)

	lui	$2,%hi(gameepisode)
	li	$4,1			# 0x1
	lw	$3,%lo(gameepisode)($2)
	sw	$4,%lo(finalestage)($18)
	li	$5,-1			# 0xffffffffffffffff
	lui	$4,%hi(wipegamestate)
	li	$2,3			# 0x3
	sw	$0,%lo(finalecount)($16)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L150
	.set	at
	sw	$5,%lo(wipegamestate)($4)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$4,30			# 0x1e
	j	S_StartMusic
	addiu	$sp,$sp,32

$L163:
	sltu	$3,$2,51
	bne	$3,$0,$L167
	lui	$18,%hi(finalestage)

	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	move	$4,$0
	li	$6,4			# 0x4
$L155:
	lbu	$5,13($3)
	bne	$5,$0,$L154
	addiu	$4,$4,1

	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L155
	.set	at
	addiu	$3,$3,288

	lui	$18,%hi(finalestage)
	lw	$4,%lo(finalestage)($18)
	addiu	$2,$2,1
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L157
	.set	at
	sw	$2,%lo(finalecount)($16)

$L164:
	lui	$3,%hi(casttics)
	lw	$2,%lo(casttics)($3)
	addiu	$2,$2,-1
	bgtz	$2,$L150
	sw	$2,%lo(casttics)($3)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	F_CastTicker.part.0
	addiu	$sp,$sp,32

$L154:
	lui	$3,%hi(gamemap)
	lw	$4,%lo(gamemap)($3)
	li	$3,30			# 0x1e
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L166
	.set	at
	lui	$3,%hi(gameaction)

	li	$4,8			# 0x8
	b	$L152
	sw	$4,%lo(gameaction)($3)

$L166:
	jal	F_StartCast
	lui	$18,%hi(finalestage)

	b	$L167
	lw	$2,%lo(finalecount)($16)

	.set	macro
	.set	reorder
	.end	F_Ticker
	.size	F_Ticker, .-F_Ticker
	.align	2
	.globl	F_CastTicker
	.set	nomips16
	.set	nomicromips
	.ent	F_CastTicker
	.type	F_CastTicker, @function
F_CastTicker:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(casttics)
	lw	$2,%lo(casttics)($3)
	addiu	$2,$2,-1
	bgtz	$2,$L171
	sw	$2,%lo(casttics)($3)

	j	F_CastTicker.part.0
	nop

$L171:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	F_CastTicker
	.size	F_CastTicker, .-F_CastTicker
	.align	2
	.globl	F_CastResponder
	.set	nomips16
	.set	nomicromips
	.ent	F_CastResponder
	.type	F_CastResponder, @function
F_CastResponder:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	bne	$2,$0,$L177
	lui	$6,%hi(castdeath)

	lw	$2,%lo(castdeath)($6)
	bne	$2,$0,$L182
	nop

	lui	$2,%hi(castnum)
	lw	$3,%lo(castnum)($2)
	lui	$2,%hi(castorder)
	sll	$3,$3,3
	addiu	$2,$2,%lo(castorder)
	addu	$2,$2,$3
	lw	$3,4($2)
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	lui	$3,%hi(mobjinfo)
	addiu	$3,$3,%lo(mobjinfo)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,48($2)
	lw	$5,56($2)
	sll	$4,$3,3
	subu	$4,$4,$3
	lui	$3,%hi(states)
	sll	$4,$4,2
	addiu	$3,$3,%lo(states)
	addu	$3,$3,$4
	li	$2,1			# 0x1
	lw	$4,8($3)
	sw	$2,%lo(castdeath)($6)
	lui	$2,%hi(caststate)
	sw	$3,%lo(caststate)($2)
	lui	$2,%hi(casttics)
	sw	$4,%lo(casttics)($2)
	lui	$2,%hi(castframes)
	sw	$0,%lo(castframes)($2)
	lui	$2,%hi(castattacking)
	bne	$5,$0,$L186
	sw	$0,%lo(castattacking)($2)

$L182:
	jr	$31
	li	$2,1			# 0x1

$L177:
	jr	$31
	move	$2,$0

$L186:
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	S_StartSound
	move	$4,$0

	lw	$31,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	F_CastResponder
	.size	F_CastResponder, .-F_CastResponder
	.align	2
	.globl	F_CastPrint
	.set	nomips16
	.set	nomicromips
	.ent	F_CastPrint
	.type	F_CastPrint, @function
F_CastPrint:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L214
	nop

	addiu	$sp,$sp,-40
	sw	$18,24($sp)
	sw	$16,16($sp)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$17,20($sp)
	move	$18,$4
	lb	$4,0($4)
	beq	$4,$0,$L187
	addiu	$16,$18,1

	lui	$17,%hi(hu_font)
	move	$19,$16
	move	$20,$0
	b	$L192
	addiu	$17,$17,%lo(hu_font)

$L189:
	lw	$3,0($3)
	lb	$4,0($19)
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$20,$20,$2
	beq	$4,$0,$L212
	addiu	$19,$19,1

$L192:
	jal	toupper
	nop

	addiu	$2,$2,-33
	sll	$3,$2,2
	sltu	$2,$2,64
	bne	$2,$0,$L189
	addu	$3,$3,$17

	lb	$4,0($19)
	addiu	$20,$20,4
	bne	$4,$0,$L192
	addiu	$19,$19,1

$L212:
	srl	$2,$20,31
	addu	$2,$2,$20
	lb	$4,0($18)
	sra	$2,$2,1
	subu	$2,$0,$2
	beq	$4,$0,$L187
	addiu	$18,$2,160

	lui	$19,%hi(hu_font)
	b	$L195
	addiu	$19,$19,%lo(hu_font)

$L213:
	lb	$4,0($16)
	addiu	$18,$18,4
	beq	$4,$0,$L187
	addiu	$16,$16,1

$L195:
	jal	toupper
	nop

	addiu	$2,$2,-33
	sll	$3,$2,2
	sltu	$2,$2,64
	addu	$3,$3,$19
	move	$4,$18
	beq	$2,$0,$L213
	li	$5,180			# 0xb4

	lw	$6,0($3)
	addiu	$16,$16,1
	lbu	$17,1($6)
	lbu	$2,0($6)
	sll	$17,$17,8
	or	$17,$17,$2
	jal	V_DrawPatch
	sll	$17,$17,16

	lb	$4,-1($16)
	sra	$17,$17,16
	bne	$4,$0,$L195
	addu	$18,$18,$17

$L187:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L214:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	F_CastPrint
	.size	F_CastPrint, .-F_CastPrint
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"BOSSBACK\000"
	.text
	.align	2
	.globl	F_CastDrawer
	.set	nomips16
	.set	nomicromips
	.ent	F_CastDrawer
	.type	F_CastDrawer, @function
F_CastDrawer:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-24
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC0)
	sw	$31,20($sp)
	jal	W_CacheLumpName
	sw	$16,16($sp)

	move	$6,$2
	move	$5,$0
	jal	V_DrawPatch
	move	$4,$0

	lui	$2,%hi(castnum)
	lw	$2,%lo(castnum)($2)
	lui	$3,%hi(castorder)
	addiu	$3,$3,%lo(castorder)
	sll	$2,$2,3
	addu	$2,$2,$3
	jal	F_CastPrint
	lw	$4,0($2)

	lui	$2,%hi(caststate)
	lw	$3,%lo(caststate)($2)
	li	$5,8			# 0x8
	lw	$2,0($3)
	lw	$4,4($3)
	lui	$3,%hi(sprites)
	lw	$3,%lo(sprites)($3)
	andi	$4,$4,0x7fff
	sll	$2,$2,3
	addu	$3,$3,$2
	sll	$2,$4,3
	lw	$3,4($3)
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lui	$3,%hi(firstspritelump)
	lh	$4,4($2)
	lw	$3,%lo(firstspritelump)($3)
	lbu	$16,20($2)
	jal	W_CacheLumpNum
	addu	$4,$4,$3

	move	$6,$2
	li	$5,170			# 0xaa
	beq	$16,$0,$L216
	li	$4,160			# 0xa0

	lw	$31,20($sp)
	lw	$16,16($sp)
	j	V_DrawPatchFlipped
	addiu	$sp,$sp,24

$L216:
	lw	$31,20($sp)
	lw	$16,16($sp)
	j	V_DrawPatch
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	F_CastDrawer
	.size	F_CastDrawer, .-F_CastDrawer
	.align	2
	.globl	F_DrawPatchCol
	.set	nomips16
	.set	nomicromips
	.ent	F_DrawPatchCol
	.type	F_DrawPatchCol, @function
F_DrawPatchCol:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$6,$6,2
	sll	$6,$6,2
	addu	$2,$5,$6
	lwl	$3,3($2)
	li	$8,255			# 0xff
	lwr	$3,0($2)
	addu	$7,$5,$3
	lbu	$2,0($7)
	lui	$5,%hi(I_VideoBuffer)
	li	$3,255			# 0xff
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L230
	.set	at
	lw	$9,%lo(I_VideoBuffer)($5)

	sll	$3,$2,2
$L229:
	addu	$3,$3,$2
	sll	$3,$3,6
	lbu	$5,1($7)
	addu	$3,$3,$4
	addiu	$2,$7,3
	beq	$5,$0,$L220
	addu	$3,$9,$3

	addiu	$5,$5,3
	addu	$5,$7,$5
$L221:
	lbu	$6,0($2)
	addiu	$2,$2,1
	sb	$6,0($3)
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L221
	.set	at
	addiu	$3,$3,320

	lbu	$5,1($7)
$L220:
	addiu	$5,$5,4
	addu	$7,$7,$5
	lbu	$2,0($7)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L229
	.set	at
	sll	$3,$2,2

$L230:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	F_DrawPatchCol
	.size	F_DrawPatchCol, .-F_DrawPatchCol
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"PFUB2\000"
	.align	2
$LC2:
	.ascii	"PFUB1\000"
	.align	2
$LC3:
	.ascii	"END0\000"
	.align	2
$LC4:
	.ascii	"END%i\000"
	.text
	.align	2
	.globl	F_BunnyScroll
	.set	nomips16
	.set	nomicromips
	.ent	F_BunnyScroll
	.type	F_BunnyScroll, @function
F_BunnyScroll:
	.frame	$sp,56,$31		# vars= 24, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC1)
	addiu	$sp,$sp,-56
	li	$5,5			# 0x5
	addiu	$4,$4,%lo($LC1)
	sw	$31,52($sp)
	sw	$17,48($sp)
	jal	W_CacheLumpName
	sw	$16,44($sp)

	lui	$4,%hi($LC2)
	li	$5,5			# 0x5
	addiu	$4,$4,%lo($LC2)
	jal	W_CacheLumpName
	move	$16,$2

	li	$7,200			# 0xc8
	li	$6,320			# 0x140
	move	$5,$0
	move	$4,$0
	jal	V_MarkRect
	move	$17,$2

	lui	$13,%hi(finalecount)
	lw	$2,%lo(finalecount)($13)
	move	$11,$0
	addiu	$2,$2,-230
	srl	$10,$2,31
	addu	$10,$10,$2
	sra	$10,$10,1
	subu	$10,$0,$10
	addiu	$10,$10,320
	slt	$2,$10,0
	movn	$10,$0,$2
	slt	$3,$10,321
	li	$2,320			# 0x140
	movz	$10,$2,$3
	li	$12,320			# 0x140
$L234:
	slt	$3,$10,320
	move	$6,$10
	move	$5,$16
	bne	$3,$0,$L243
	move	$4,$11

	addiu	$6,$10,-320
	move	$5,$17
$L243:
	jal	F_DrawPatchCol
	addiu	$11,$11,1

	.set	noat
	xor	$1,$11,$12
	bne	$1,$0,$L234
	.set	at
	addiu	$10,$10,1

	lw	$2,%lo(finalecount)($13)
	sltu	$3,$2,1130
	bne	$3,$0,$L231
	sltu	$3,$2,1180

	bne	$3,$0,$L244
	addiu	$2,$2,-1180

	sltu	$3,$2,35
	beq	$3,$0,$L240
	lui	$16,%hi(laststage.0)

	li	$3,-859045888			# 0xffffffffcccc0000
	ori	$3,$3,0xcccd
	multu	$2,$3
	mfhi	$2
	srl	$7,$2,2
	lw	$2,%lo(laststage.0)($16)
	slt	$2,$2,$7
	bne	$2,$0,$L246
	li	$5,1			# 0x1

$L238:
	lui	$6,%hi($LC4)
$L247:
	addiu	$6,$6,%lo($LC4)
	addiu	$4,$sp,16
	jal	snprintf
	li	$5,10			# 0xa

	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$sp,16

	move	$6,$2
	li	$5,68			# 0x44
	jal	V_DrawPatch
	li	$4,108			# 0x6c

$L231:
	lw	$31,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	jr	$31
	addiu	$sp,$sp,56

$L240:
	lw	$2,%lo(laststage.0)($16)
	li	$7,6			# 0x6
	slt	$2,$2,$7
	beq	$2,$0,$L247
	lui	$6,%hi($LC4)

	li	$5,1			# 0x1
$L246:
	move	$4,$0
	jal	S_StartSound
	sw	$7,32($sp)

	lw	$7,32($sp)
	b	$L238
	sw	$7,%lo(laststage.0)($16)

$L244:
	lui	$4,%hi($LC3)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC3)

	move	$6,$2
	li	$5,68			# 0x44
	jal	V_DrawPatch
	li	$4,108			# 0x6c

	lw	$31,52($sp)
	lui	$2,%hi(laststage.0)
	lw	$17,48($sp)
	lw	$16,44($sp)
	sw	$0,%lo(laststage.0)($2)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	F_BunnyScroll
	.size	F_BunnyScroll, .-F_BunnyScroll
	.section	.rodata.str1.4
	.align	2
$LC5:
	.ascii	"VICTORY2\000"
	.align	2
$LC6:
	.ascii	"CREDIT\000"
	.align	2
$LC7:
	.ascii	"HELP2\000"
	.align	2
$LC8:
	.ascii	"ENDPIC\000"
	.text
	.align	2
	.globl	F_Drawer
	.set	nomips16
	.set	nomicromips
	.ent	F_Drawer
	.type	F_Drawer, @function
F_Drawer:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(finalestage)
	lw	$2,%lo(finalestage)($2)
	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L249
	.set	at
	li	$3,2			# 0x2

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L250
	.set	at
	nop

	beq	$2,$0,$L260
	nop

$L263:
	jr	$31
	nop

$L260:
	j	F_TextWrite
	nop

$L250:
	j	F_CastDrawer
	nop

$L249:
	lui	$3,%hi(gameepisode)
	lw	$3,%lo(gameepisode)($3)
	li	$4,3			# 0x3
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L261
	.set	at
	nop

	li	$5,2			# 0x2
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L255
	.set	at
	nop

	li	$5,4			# 0x4
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L256
	.set	at
	nop

	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L263
	.set	at
	nop

	lui	$2,%hi(gamemode)
	lw	$2,%lo(gamemode)($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L262
	.set	at
	nop

	lui	$4,%hi($LC7)
	b	$L254
	addiu	$4,$4,%lo($LC7)

$L261:
	j	F_BunnyScroll
	nop

$L256:
	lui	$4,%hi($LC8)
	addiu	$4,$4,%lo($LC8)
$L254:
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	lw	$31,20($sp)
	move	$6,$2
	move	$5,$0
	move	$4,$0
	j	V_DrawPatch
	addiu	$sp,$sp,24

$L262:
	lui	$4,%hi($LC6)
	b	$L254
	addiu	$4,$4,%lo($LC6)

$L255:
	lui	$4,%hi($LC5)
	b	$L254
	addiu	$4,$4,%lo($LC5)

	.set	macro
	.set	reorder
	.end	F_Drawer
	.size	F_Drawer, .-F_Drawer
	.local	laststage.0
	.comm	laststage.0,4,4
	.globl	castattacking
	.section	.bss,"aw",@nobits
	.align	2
	.type	castattacking, @object
	.size	castattacking, 4
castattacking:
	.space	4
	.globl	castonmelee
	.align	2
	.type	castonmelee, @object
	.size	castonmelee, 4
castonmelee:
	.space	4
	.globl	castframes
	.align	2
	.type	castframes, @object
	.size	castframes, 4
castframes:
	.space	4
	.globl	castdeath
	.align	2
	.type	castdeath, @object
	.size	castdeath, 4
castdeath:
	.space	4
	.globl	caststate
	.align	2
	.type	caststate, @object
	.size	caststate, 4
caststate:
	.space	4
	.globl	casttics
	.align	2
	.type	casttics, @object
	.size	casttics, 4
casttics:
	.space	4
	.globl	castnum
	.align	2
	.type	castnum, @object
	.size	castnum, 4
castnum:
	.space	4
	.globl	castorder
	.section	.rodata.str1.4
	.align	2
$LC9:
	.ascii	"ZOMBIEMAN\000"
	.align	2
$LC10:
	.ascii	"SHOTGUN GUY\000"
	.align	2
$LC11:
	.ascii	"HEAVY WEAPON DUDE\000"
	.align	2
$LC12:
	.ascii	"IMP\000"
	.align	2
$LC13:
	.ascii	"DEMON\000"
	.align	2
$LC14:
	.ascii	"LOST SOUL\000"
	.align	2
$LC15:
	.ascii	"CACODEMON\000"
	.align	2
$LC16:
	.ascii	"HELL KNIGHT\000"
	.align	2
$LC17:
	.ascii	"BARON OF HELL\000"
	.align	2
$LC18:
	.ascii	"ARACHNOTRON\000"
	.align	2
$LC19:
	.ascii	"PAIN ELEMENTAL\000"
	.align	2
$LC20:
	.ascii	"REVENANT\000"
	.align	2
$LC21:
	.ascii	"MANCUBUS\000"
	.align	2
$LC22:
	.ascii	"ARCH-VILE\000"
	.align	2
$LC23:
	.ascii	"THE SPIDER MASTERMIND\000"
	.align	2
$LC24:
	.ascii	"THE CYBERDEMON\000"
	.align	2
$LC25:
	.ascii	"OUR HERO\000"
	.data
	.align	2
	.type	castorder, @object
	.size	castorder, 144
castorder:
	.word	$LC9
	.word	1
	.word	$LC10
	.word	2
	.word	$LC11
	.word	10
	.word	$LC12
	.word	11
	.word	$LC13
	.word	12
	.word	$LC14
	.word	18
	.word	$LC15
	.word	14
	.word	$LC16
	.word	17
	.word	$LC17
	.word	15
	.word	$LC18
	.word	20
	.word	$LC19
	.word	22
	.word	$LC20
	.word	5
	.word	$LC21
	.word	8
	.word	$LC22
	.word	3
	.word	$LC23
	.word	19
	.word	$LC24
	.word	21
	.word	$LC25
	.word	0
	.word	0
	.word	0
	.globl	finaleflat
	.section	.bss
	.align	2
	.type	finaleflat, @object
	.size	finaleflat, 4
finaleflat:
	.space	4
	.globl	finaletext
	.align	2
	.type	finaletext, @object
	.size	finaletext, 4
finaletext:
	.space	4
	.section	.rodata.str1.4
	.align	2
$LC26:
	.ascii	"FLOOR4_8\000"
	.align	2
$LC27:
	.ascii	"Once you beat the big badasses and\012clean out the moon"
	.ascii	" base you're supposed\012to win, aren't you? Aren't you?"
	.ascii	" Where's\012your fat reward and ticket home? What\012the"
	.ascii	" hell is this? It's not supposed to\012end this way!\012"
	.ascii	"\012It stinks like rotten meat, but looks\012like the lo"
	.ascii	"st Deimos base.  Looks like\012you're stuck on The Shore"
	.ascii	"s of Hell.\012The only way out is through.\012\012To con"
	.ascii	"tinue the DOOM experience, play\012The Shores of Hell an"
	.ascii	"d its amazing\012sequel, Inferno!\012\000"
	.align	2
$LC28:
	.ascii	"SFLR6_1\000"
	.align	2
$LC29:
	.ascii	"You've done it! The hideous cyber-\012demon lord that ru"
	.ascii	"led the lost Deimos\012moon base has been slain and you\012"
	.ascii	"are triumphant! But ... where are\012you? You clamber to"
	.ascii	" the edge of the\012moon and look down to see the awful\012"
	.ascii	"truth.\012\012Deimos floats above Hell itself!\012You've"
	.ascii	" never heard of anyone escaping\012from Hell, but you'll"
	.ascii	" make the bastards\012sorry they ever heard of you! Quic"
	.ascii	"kly,\012you rappel down to  the surface of\012Hell.\012\012"
	.ascii	"Now, it's on to the final chapter of\012DOOM! -- Inferno"
	.ascii	".\000"
	.align	2
$LC30:
	.ascii	"MFLR8_4\000"
	.align	2
$LC31:
	.ascii	"The loathsome spiderdemon that\012masterminded the invas"
	.ascii	"ion of the moon\012bases and caused so much death has ha"
	.ascii	"d\012its ass kicked for all time.\012\012A hidden doorwa"
	.ascii	"y opens and you enter.\012You've proven too tough for He"
	.ascii	"ll to\012contain, and now Hell at last plays\012fair -- "
	.ascii	"for you emerge from the door\012to see the green fields "
	.ascii	"of Earth!\012Home at last.\012\012You wonder what's been"
	.ascii	" happening on\012Earth while you were battling evil\012u"
	.ascii	"nleashed. It's good that no Hell-\012spawn could have co"
	.ascii	"me through that\012door with you ...\000"
	.align	2
$LC32:
	.ascii	"MFLR8_3\000"
	.align	2
$LC33:
	.ascii	"the spider mastermind must have sent forth\012its legion"
	.ascii	"s of hellspawn before your\012final confrontation with t"
	.ascii	"hat terrible\012beast from hell.  but you stepped forwar"
	.ascii	"d\012and brought forth eternal damnation and\012sufferin"
	.ascii	"g upon the horde as a true hero\012would in the face of "
	.ascii	"something so evil.\012\012besides, someone was gonna pay"
	.ascii	" for what\012happened to daisy, your pet rabbit.\012\012"
	.ascii	"but now, you see spread before you more\012potential pai"
	.ascii	"n and gibbitude as a nation\012of demons run amok among "
	.ascii	"our cities.\012\012next stop, hell on earth!\000"
	.align	2
$LC34:
	.ascii	"SLIME16\000"
	.align	2
$LC35:
	.ascii	"YOU HAVE ENTERED DEEPLY INTO THE INFESTED\012STARPORT. B"
	.ascii	"UT SOMETHING IS WRONG. THE\012MONSTERS HAVE BROUGHT THEI"
	.ascii	"R OWN REALITY\012WITH THEM, AND THE STARPORT'S TECHNOLOG"
	.ascii	"Y\012IS BEING SUBVERTED BY THEIR PRESENCE.\012\012AHEAD,"
	.ascii	" YOU SEE AN OUTPOST OF HELL, A\012FORTIFIED ZONE. IF YOU"
	.ascii	" CAN GET PAST IT,\012YOU CAN PENETRATE INTO THE HAUNTED "
	.ascii	"HEART\012OF THE STARBASE AND FIND THE CONTROLLING\012SWI"
	.ascii	"TCH WHICH HOLDS EARTH'S POPULATION\012HOSTAGE.\000"
	.align	2
$LC36:
	.ascii	"RROCK14\000"
	.align	2
$LC37:
	.ascii	"YOU HAVE WON! YOUR VICTORY HAS ENABLED\012HUMANKIND TO E"
	.ascii	"VACUATE EARTH AND ESCAPE\012THE NIGHTMARE.  NOW YOU ARE "
	.ascii	"THE ONLY\012HUMAN LEFT ON THE FACE OF THE PLANET.\012CAN"
	.ascii	"NIBAL MUTATIONS, CARNIVOROUS ALIENS,\012AND EVIL SPIRITS"
	.ascii	" ARE YOUR ONLY NEIGHBORS.\012YOU SIT BACK AND WAIT FOR D"
	.ascii	"EATH, CONTENT\012THAT YOU HAVE SAVED YOUR SPECIES.\012\012"
	.ascii	"BUT THEN, EARTH CONTROL BEAMS DOWN A\012MESSAGE FROM SPA"
	.ascii	"CE: \"SENSORS HAVE LOCATED\012THE SOURCE OF THE ALIEN IN"
	.ascii	"VASION. IF YOU\012GO THERE, YOU MAY BE ABLE TO BLOCK THE"
	.ascii	"IR\012ENTRY.  THE ALIEN BASE IS IN THE HEART OF\012YOUR "
	.ascii	"OWN HOME CITY, NOT FAR FROM THE\012STARPORT.\" SLOWLY AN"
	.ascii	"D PAINFULLY YOU GET\012UP AND RETURN TO THE FRAY.\000"
	.align	2
$LC38:
	.ascii	"RROCK07\000"
	.align	2
$LC39:
	.ascii	"YOU ARE AT THE CORRUPT HEART OF THE CITY,\012SURROUNDED "
	.ascii	"BY THE CORPSES OF YOUR ENEMIES.\012YOU SEE NO WAY TO DES"
	.ascii	"TROY THE CREATURES'\012ENTRYWAY ON THIS SIDE, SO YOU CLE"
	.ascii	"NCH YOUR\012TEETH AND PLUNGE THROUGH IT.\012\012THERE MU"
	.ascii	"ST BE A WAY TO CLOSE IT ON THE\012OTHER SIDE. WHAT DO YO"
	.ascii	"U CARE IF YOU'VE\012GOT TO GO THROUGH HELL TO GET TO IT?"
	.ascii	"\000"
	.align	2
$LC40:
	.ascii	"RROCK17\000"
	.align	2
$LC41:
	.ascii	"THE HORRENDOUS VISAGE OF THE BIGGEST\012DEMON YOU'VE EVE"
	.ascii	"R SEEN CRUMBLES BEFORE\012YOU, AFTER YOU PUMP YOUR ROCKE"
	.ascii	"TS INTO\012HIS EXPOSED BRAIN. THE MONSTER SHRIVELS\012UP"
	.ascii	" AND DIES, ITS THRASHING LIMBS\012DEVASTATING UNTOLD MIL"
	.ascii	"ES OF HELL'S\012SURFACE.\012\012YOU'VE DONE IT. THE INVA"
	.ascii	"SION IS OVER.\012EARTH IS SAVED. HELL IS A WRECK. YOU\012"
	.ascii	"WONDER WHERE BAD FOLKS WILL GO WHEN THEY\012DIE, NOW. WI"
	.ascii	"PING THE SWEAT FROM YOUR\012FOREHEAD YOU BEGIN THE LONG "
	.ascii	"TREK BACK\012HOME. REBUILDING EARTH OUGHT TO BE A\012LOT"
	.ascii	" MORE FUN THAN RUINING IT WAS.\012\000"
	.align	2
$LC42:
	.ascii	"RROCK13\000"
	.align	2
$LC43:
	.ascii	"CONGRATULATIONS, YOU'VE FOUND THE SECRET\012LEVEL! LOOKS"
	.ascii	" LIKE IT'S BEEN BUILT BY\012HUMANS, RATHER THAN DEMONS. "
	.ascii	"YOU WONDER\012WHO THE INMATES OF THIS CORNER OF HELL\012"
	.ascii	"WILL BE.\000"
	.align	2
$LC44:
	.ascii	"RROCK19\000"
	.align	2
$LC45:
	.ascii	"CONGRATULATIONS, YOU'VE FOUND THE\012SUPER SECRET LEVEL!"
	.ascii	"  YOU'D BETTER\012BLAZE THROUGH THIS ONE!\012\000"
	.align	2
$LC46:
	.ascii	"You've fought your way out of the infested\012experiment"
	.ascii	"al labs.   It seems that UAC has\012once again gulped it"
	.ascii	" down.  With their\012high turnover, it must be hard for"
	.ascii	" poor\012old UAC to buy corporate health insurance\012no"
	.ascii	"wadays..\012\012Ahead lies the military complex, now\012"
	.ascii	"swarming with diseased horrors hot to get\012their teeth"
	.ascii	" into you. With luck, the\012complex still has some warl"
	.ascii	"ike ordnance\012laying around.\000"
	.align	2
$LC47:
	.ascii	"You hear the grinding of heavy machinery\012ahead.  You "
	.ascii	"sure hope they're not stamping\012out new hellspawn, but"
	.ascii	" you're ready to\012ream out a whole herd if you have to"
	.ascii	".\012They might be planning a blood feast, but\012you fe"
	.ascii	"el about as mean as two thousand\012maniacs packed into "
	.ascii	"one mad killer.\012\012You don't plan to go down easy.\000"
	.align	2
$LC48:
	.ascii	"The vista opening ahead looks real damn\012familiar. Sme"
	.ascii	"lls familiar, too -- like\012fried excrement. You didn't"
	.ascii	" like this\012place before, and you sure as hell ain't\012"
	.ascii	"planning to like it now. The more you\012brood on it, th"
	.ascii	"e madder you get.\012Hefting your gun, an evil grin tric"
	.ascii	"kles\012onto your face. Time to take some names.\000"
	.align	2
$LC49:
	.ascii	"Suddenly, all is silent, from one horizon\012to the othe"
	.ascii	"r. The agonizing echo of Hell\012fades away, the nightma"
	.ascii	"re sky turns to\012blue, the heaps of monster corpses st"
	.ascii	"art \012to evaporate along with the evil stench \012that"
	.ascii	" filled the air. Jeeze, maybe you've\012done it. Have yo"
	.ascii	"u really won?\012\012Something rumbles in the distance.\012"
	.ascii	"A blue light begins to glow inside the\012ruined skull o"
	.ascii	"f the demon-spitter.\000"
	.align	2
$LC50:
	.ascii	"What now? Looks totally different. Kind\012of like King "
	.ascii	"Tut's condo. Well,\012whatever's here can't be any worse"
	.ascii	"\012than usual. Can it?  Or maybe it's best\012to let sl"
	.ascii	"eeping gods lie..\000"
	.align	2
$LC51:
	.ascii	"Time for a vacation. You've burst the\012bowels of hell "
	.ascii	"and by golly you're ready\012for a break. You mutter to "
	.ascii	"yourself,\012Maybe someone else can kick Hell's ass\012n"
	.ascii	"ext time around. Ahead lies a quiet town,\012with peacef"
	.ascii	"ul flowing water, quaint\012buildings, and presumably no"
	.ascii	" Hellspawn.\012\012As you step off the transport, you he"
	.ascii	"ar\012the stomp of a cyberdemon's iron shoe.\000"
	.align	2
$LC52:
	.ascii	"You gloat over the steaming carcass of the\012Guardian. "
	.ascii	" With its death, you've wrested\012the Accelerator from "
	.ascii	"the stinking claws\012of Hell.  You relax and glance aro"
	.ascii	"und the\012room.  Damn!  There was supposed to be at\012"
	.ascii	"least one working prototype, but you can't\012see it. Th"
	.ascii	"e demons must have taken it.\012\012You must find the pr"
	.ascii	"ototype, or all your\012struggles will have been wasted."
	.ascii	" Keep\012moving, keep fighting, keep killing.\012Oh yes,"
	.ascii	" keep living, too.\000"
	.align	2
$LC53:
	.ascii	"Even the deadly Arch-Vile labyrinth could\012not stop yo"
	.ascii	"u, and you've gotten to the\012prototype Accelerator whi"
	.ascii	"ch is soon\012efficiently and permanently deactivated.\012"
	.ascii	"\012You're good at that kind of thing.\000"
	.align	2
$LC54:
	.ascii	"You've bashed and battered your way into\012the heart of"
	.ascii	" the devil-hive.  Time for a\012Search-and-Destroy missi"
	.ascii	"on, aimed at the\012Gatekeeper, whose foul offspring is\012"
	.ascii	"cascading to Earth.  Yeah, he's bad. But\012you know who"
	.ascii	"'s worse!\012\012Grinning evilly, you check your gear, a"
	.ascii	"nd\012get ready to give the bastard a little Hell\012of "
	.ascii	"your own making!\000"
	.align	2
$LC55:
	.ascii	"The Gatekeeper's evil face is splattered\012all over the"
	.ascii	" place.  As its tattered corpse\012collapses, an inverte"
	.ascii	"d Gate forms and\012sucks down the shards of the last\012"
	.ascii	"prototype Accelerator, not to mention the\012few remaini"
	.ascii	"ng demons.  You're done. Hell\012has gone back to poundi"
	.ascii	"ng bad dead folks \012instead of good live ones.  Rememb"
	.ascii	"er to\012tell your grandkids to put a rocket\012launcher"
	.ascii	" in your coffin. If you go to Hell\012when you die, you'"
	.ascii	"ll need it for some\012final cleaning-up ...\000"
	.align	2
$LC56:
	.ascii	"You've found the second-hardest level we\012got. Hope yo"
	.ascii	"u have a saved game a level or\012two previous.  If not,"
	.ascii	" be prepared to die\012aplenty. For master marines only."
	.ascii	"\000"
	.align	2
$LC57:
	.ascii	"Betcha wondered just what WAS the hardest\012level we ha"
	.ascii	"d ready for ya?  Now you know.\012No one gets out alive."
	.ascii	"\000"
	.data
	.align	2
	.type	textscreens, @object
	.size	textscreens, 440
textscreens:
	.word	0
	.word	1
	.word	8
	.word	$LC26
	.word	$LC27
	.word	0
	.word	2
	.word	8
	.word	$LC28
	.word	$LC29
	.word	0
	.word	3
	.word	8
	.word	$LC30
	.word	$LC31
	.word	0
	.word	4
	.word	8
	.word	$LC32
	.word	$LC33
	.word	1
	.word	1
	.word	6
	.word	$LC34
	.word	$LC35
	.word	1
	.word	1
	.word	11
	.word	$LC36
	.word	$LC37
	.word	1
	.word	1
	.word	20
	.word	$LC38
	.word	$LC39
	.word	1
	.word	1
	.word	30
	.word	$LC40
	.word	$LC41
	.word	1
	.word	1
	.word	15
	.word	$LC42
	.word	$LC43
	.word	1
	.word	1
	.word	31
	.word	$LC44
	.word	$LC45
	.word	2
	.word	1
	.word	6
	.word	$LC34
	.word	$LC46
	.word	2
	.word	1
	.word	11
	.word	$LC36
	.word	$LC47
	.word	2
	.word	1
	.word	20
	.word	$LC38
	.word	$LC48
	.word	2
	.word	1
	.word	30
	.word	$LC40
	.word	$LC49
	.word	2
	.word	1
	.word	15
	.word	$LC42
	.word	$LC50
	.word	2
	.word	1
	.word	31
	.word	$LC44
	.word	$LC51
	.word	3
	.word	1
	.word	6
	.word	$LC34
	.word	$LC52
	.word	3
	.word	1
	.word	11
	.word	$LC36
	.word	$LC53
	.word	3
	.word	1
	.word	20
	.word	$LC38
	.word	$LC54
	.word	3
	.word	1
	.word	30
	.word	$LC40
	.word	$LC55
	.word	3
	.word	1
	.word	15
	.word	$LC42
	.word	$LC56
	.word	3
	.word	1
	.word	31
	.word	$LC44
	.word	$LC57
	.globl	finalecount
	.section	.bss
	.align	2
	.type	finalecount, @object
	.size	finalecount, 4
finalecount:
	.space	4
	.globl	finalestage
	.align	2
	.type	finalestage, @object
	.size	finalestage, 4
finalestage:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
