	.file	1 "f_wipe.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	wipe_doColorXForm
	.set	nomips16
	.set	nomicromips
	.ent	wipe_doColorXForm
	.type	wipe_doColorXForm, @function
wipe_doColorXForm:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	multu	$4,$5
	mflo	$4
	lui	$2,%hi(wipe_scr)
	lw	$8,%lo(wipe_scr)($2)
	lui	$2,%hi(wipe_scr_end)
	beq	$4,$0,$L7
	lw	$7,%lo(wipe_scr_end)($2)

	addu	$4,$7,$4
	move	$2,$0
$L6:
	lbu	$5,0($7)
	lbu	$3,0($8)
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L3
	.set	at
	sltu	$9,$5,$3

	subu	$2,$3,$6
	addu	$3,$3,$6
	slt	$11,$2,$5
	beq	$9,$0,$L4
	slt	$10,$5,$3

	bne	$11,$0,$L5
	nop

	andi	$5,$2,0x00ff
$L5:
	sb	$5,0($8)
	li	$2,1			# 0x1
$L3:
	addiu	$7,$7,1
	.set	noat
	xor	$1,$7,$4
	bne	$1,$0,$L6
	.set	at
	addiu	$8,$8,1

	jr	$31
	xori	$2,$2,0x1

$L4:
	bne	$10,$0,$L5
	nop

	b	$L5
	andi	$5,$3,0x00ff

$L7:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	wipe_doColorXForm
	.size	wipe_doColorXForm, .-wipe_doColorXForm
	.align	2
	.globl	wipe_exitColorXForm
	.set	nomips16
	.set	nomicromips
	.ent	wipe_exitColorXForm
	.type	wipe_exitColorXForm, @function
wipe_exitColorXForm:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	wipe_exitColorXForm
	.size	wipe_exitColorXForm, .-wipe_exitColorXForm
	.align	2
	.globl	wipe_doMelt
	.set	nomips16
	.set	nomicromips
	.ent	wipe_doMelt
	.type	wipe_doMelt, @function
wipe_doMelt:
	.frame	$sp,16,$31		# vars= 0, regs= 4/0, args= 0, gp= 0
	.mask	0x000f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,31
	beq	$6,$0,$L28
	addu	$2,$2,$4

	sra	$11,$2,1
	lui	$2,%hi(y)
	lw	$25,%lo(y)($2)
	lui	$2,%hi(wipe_scr_end)
	lw	$15,%lo(wipe_scr_end)($2)
	lui	$2,%hi(wipe_scr)
	addiu	$sp,$sp,-16
	lw	$14,%lo(wipe_scr)($2)
	lui	$2,%hi(wipe_scr_start)
	addiu	$13,$6,-1
	sw	$16,0($sp)
	sw	$19,12($sp)
	lw	$16,%lo(wipe_scr_start)($2)
	sw	$18,8($sp)
	sw	$17,4($sp)
	sll	$12,$5,1
	sll	$8,$11,1
	slt	$4,$4,2
	li	$2,-1			# 0xffffffffffffffff
$L13:
	bne	$4,$0,$L41
	li	$24,-1			# 0xffffffffffffffff

	li	$2,1			# 0x1
$L25:
	move	$6,$25
	move	$9,$16
	move	$10,$0
	b	$L24
	move	$7,$0

$L14:
	bne	$4,$0,$L42
	nop

	addiu	$7,$7,1
	slt	$3,$7,$11
	addiu	$6,$6,4
	addu	$9,$9,$12
	beq	$3,$0,$L43
	addu	$10,$10,$5

$L24:
	lw	$3,0($6)
	bgez	$3,$L14
	slt	$4,$3,$5

	addiu	$3,$3,1
	sw	$3,0($6)
$L15:
	move	$2,$0
$L44:
	addiu	$7,$7,1
	slt	$3,$7,$11
	addiu	$6,$6,4
	addu	$9,$9,$12
	bne	$3,$0,$L24
	addu	$10,$10,$5

$L43:
	addiu	$13,$13,-1
	.set	noat
	xor	$1,$13,$24
	bne	$1,$0,$L25
	.set	at
	nop

$L11:
	lw	$19,12($sp)
	lw	$18,8($sp)
	lw	$17,4($sp)
	lw	$16,0($sp)
	jr	$31
	addiu	$sp,$sp,16

$L42:
	slt	$2,$3,16
	beq	$2,$0,$L17
	li	$19,8			# 0x8

	addiu	$19,$3,1
$L17:
	addu	$18,$3,$19
	slt	$2,$18,$5
	beq	$2,$0,$L18
	nop

	subu	$17,$5,$18
$L19:
	multu	$3,$11
	mflo	$2
	sll	$19,$19,1
	addu	$4,$2,$7
	addu	$2,$10,$3
	sll	$2,$2,1
	addu	$2,$15,$2
	sll	$3,$4,1
	addu	$3,$14,$3
	addu	$19,$2,$19
$L20:
	lh	$4,0($2)
	addiu	$2,$2,2
	sh	$4,0($3)
	.set	noat
	xor	$1,$19,$2
	bne	$1,$0,$L20
	.set	at
	addu	$3,$3,$8

	multu	$11,$18
	mflo	$2
	sw	$18,0($6)
	addu	$3,$2,$7
	beq	$17,$0,$L15
	move	$2,$9

	sll	$3,$3,1
	sll	$17,$17,1
	addu	$3,$14,$3
	addu	$17,$9,$17
$L22:
	lh	$4,0($2)
	addiu	$2,$2,2
	sh	$4,0($3)
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L22
	.set	at
	addu	$3,$3,$8

	b	$L44
	move	$2,$0

$L18:
	subu	$19,$5,$3
	move	$18,$5
	b	$L19
	move	$17,$0

$L41:
	addiu	$13,$13,-1
	.set	noat
	xor	$1,$13,$2
	bne	$1,$0,$L13
	.set	at
	nop

	b	$L11
	li	$2,1			# 0x1

$L28:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	wipe_doMelt
	.size	wipe_doMelt, .-wipe_doMelt
	.align	2
	.globl	wipe_initColorXForm
	.set	nomips16
	.set	nomicromips
	.ent	wipe_initColorXForm
	.type	wipe_initColorXForm, @function
wipe_initColorXForm:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	multu	$4,$5
	mflo	$6
	lui	$2,%hi(wipe_scr_start)
	lw	$5,%lo(wipe_scr_start)($2)
	lui	$2,%hi(wipe_scr)
	lw	$4,%lo(wipe_scr)($2)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	memcpy
	nop

	lw	$31,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	wipe_initColorXForm
	.size	wipe_initColorXForm, .-wipe_initColorXForm
	.align	2
	.globl	wipe_exitMelt
	.set	nomips16
	.set	nomicromips
	.ent	wipe_exitMelt
	.type	wipe_exitMelt, @function
wipe_exitMelt:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(y)
	lw	$4,%lo(y)($2)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	Z_Free
	nop

	lui	$2,%hi(wipe_scr_start)
	jal	Z_Free
	lw	$4,%lo(wipe_scr_start)($2)

	lui	$2,%hi(wipe_scr_end)
	jal	Z_Free
	lw	$4,%lo(wipe_scr_end)($2)

	lw	$31,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	wipe_exitMelt
	.size	wipe_exitMelt, .-wipe_exitMelt
	.align	2
	.globl	wipe_shittyColMajorXform
	.set	nomips16
	.set	nomicromips
	.ent	wipe_shittyColMajorXform
	.type	wipe_shittyColMajorXform, @function
wipe_shittyColMajorXform:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$19,28($sp)
	multu	$5,$6
	mflo	$19
	sw	$20,32($sp)
	sll	$19,$19,1
	sw	$17,20($sp)
	sw	$16,16($sp)
	move	$17,$5
	move	$16,$6
	move	$20,$4
	move	$6,$0
	li	$5,1			# 0x1
	sw	$18,24($sp)
	sw	$31,36($sp)
	jal	Z_Malloc
	move	$4,$19

	blez	$16,$L50
	move	$18,$2

	sll	$13,$17,1
	move	$12,$2
	addu	$9,$20,$13
	sll	$10,$16,1
	move	$11,$0
$L51:
	blez	$17,$L54
	nop

	subu	$3,$9,$13
	move	$7,$12
$L52:
	lh	$8,0($3)
	addiu	$3,$3,2
	sh	$8,0($7)
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L52
	.set	at
	addu	$7,$7,$10

$L54:
	addiu	$11,$11,1
	addiu	$12,$12,2
	.set	noat
	xor	$1,$16,$11
	bne	$1,$0,$L51
	.set	at
	addu	$9,$9,$13

$L50:
	move	$4,$20
	move	$6,$19
	jal	memcpy
	move	$5,$18

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$4,$18
	lw	$18,24($sp)
	j	Z_Free
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	wipe_shittyColMajorXform
	.size	wipe_shittyColMajorXform, .-wipe_shittyColMajorXform
	.align	2
	.globl	wipe_initMelt
	.set	nomips16
	.set	nomicromips
	.ent	wipe_initMelt
	.type	wipe_initMelt, @function
wipe_initMelt:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	multu	$4,$5
	mflo	$6
	lui	$2,%hi(wipe_scr)
	sw	$19,32($sp)
	sw	$16,20($sp)
	lui	$19,%hi(wipe_scr_start)
	move	$16,$4
	sw	$18,28($sp)
	lw	$4,%lo(wipe_scr)($2)
	move	$18,$5
	sw	$17,24($sp)
	lw	$5,%lo(wipe_scr_start)($19)
	srl	$17,$16,31
	addu	$17,$17,$16
	sw	$31,44($sp)
	sra	$17,$17,1
	sw	$21,40($sp)
	jal	memcpy
	sw	$20,36($sp)

	lw	$4,%lo(wipe_scr_start)($19)
	move	$5,$17
	jal	wipe_shittyColMajorXform
	move	$6,$18

	lui	$2,%hi(wipe_scr_end)
	lw	$4,%lo(wipe_scr_end)($2)
	move	$5,$17
	jal	wipe_shittyColMajorXform
	move	$6,$18

	sll	$4,$16,2
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	lui	$17,%hi(y)
	jal	M_Random
	sw	$2,%lo(y)($17)

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,15
	and	$2,$2,$3
	bgez	$2,$L58
	lw	$4,%lo(y)($17)

	addiu	$2,$2,-1
	li	$3,-16			# 0xfffffffffffffff0
	or	$2,$2,$3
	addiu	$2,$2,1
$L58:
	subu	$2,$0,$2
	slt	$3,$16,2
	bne	$3,$0,$L59
	sw	$2,0($4)

	li	$18,1431633920			# 0x55550000
	move	$21,$0
	li	$20,1			# 0x1
	addiu	$18,$18,21846
	b	$L61
	li	$19,-16			# 0xfffffffffffffff0

$L62:
	move	$2,$0
$L60:
	addiu	$20,$20,1
	sw	$2,0($3)
	.set	noat
	xor	$1,$16,$20
	beq	$1,$0,$L59
	.set	at
	addiu	$21,$21,4

$L61:
	jal	M_Random
	nop

	mult	$2,$18
	sra	$5,$2,31
	mfhi	$4
	lw	$3,%lo(y)($17)
	subu	$4,$4,$5
	sll	$5,$4,1
	addu	$4,$5,$4
	addu	$6,$3,$21
	subu	$2,$2,$4
	lw	$5,0($6)
	addiu	$2,$2,-1
	sll	$4,$20,2
	addu	$2,$2,$5
	bgtz	$2,$L62
	addu	$3,$3,$4

	.set	noat
	xor	$1,$2,$19
	bne	$1,$0,$L60
	.set	at
	nop

	li	$2,-15			# 0xfffffffffffffff1
	addiu	$20,$20,1
	sw	$2,0($3)
	.set	noat
	xor	$1,$16,$20
	bne	$1,$0,$L61
	.set	at
	addiu	$21,$21,4

$L59:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	wipe_initMelt
	.size	wipe_initMelt, .-wipe_initMelt
	.align	2
	.globl	wipe_StartScreen
	.set	nomips16
	.set	nomicromips
	.ent	wipe_StartScreen
	.type	wipe_StartScreen, @function
wipe_StartScreen:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	move	$6,$0
	li	$5,1			# 0x1
	sw	$31,20($sp)
	jal	Z_Malloc
	li	$4,64000			# 0xfa00

	move	$4,$2
	lui	$2,%hi(wipe_scr_start)
	jal	I_ReadScreen
	sw	$4,%lo(wipe_scr_start)($2)

	lw	$31,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	wipe_StartScreen
	.size	wipe_StartScreen, .-wipe_StartScreen
	.align	2
	.globl	wipe_EndScreen
	.set	nomips16
	.set	nomicromips
	.ent	wipe_EndScreen
	.type	wipe_EndScreen, @function
wipe_EndScreen:
	.frame	$sp,48,$31		# vars= 0, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,36($sp)
	sw	$17,32($sp)
	sw	$16,28($sp)
	move	$17,$5
	move	$16,$4
	move	$18,$6
	li	$5,1			# 0x1
	move	$6,$0
	li	$4,64000			# 0xfa00
	sw	$31,44($sp)
	sw	$19,40($sp)
	jal	Z_Malloc
	move	$19,$7

	move	$4,$2
	lui	$2,%hi(wipe_scr_end)
	jal	I_ReadScreen
	sw	$4,%lo(wipe_scr_end)($2)

	lui	$2,%hi(wipe_scr_start)
	lw	$2,%lo(wipe_scr_start)($2)
	move	$7,$19
	sw	$2,16($sp)
	move	$6,$18
	move	$5,$17
	jal	V_DrawBlock
	move	$4,$16

	lw	$31,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	wipe_EndScreen
	.size	wipe_EndScreen, .-wipe_EndScreen
	.align	2
	.globl	wipe_ScreenWipe
	.set	nomips16
	.set	nomicromips
	.ent	wipe_ScreenWipe
	.type	wipe_ScreenWipe, @function
wipe_ScreenWipe:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$20,32($sp)
	lui	$20,%hi(go)
	lw	$2,%lo(go)($20)
	sw	$16,16($sp)
	sll	$16,$4,1
	sw	$19,28($sp)
	sw	$17,20($sp)
	lw	$19,56($sp)
	sw	$31,36($sp)
	sw	$18,24($sp)
	move	$17,$7
	beq	$2,$0,$L77
	addu	$16,$16,$4

	lui	$18,%hi(wipes.0)
	addiu	$18,$18,%lo(wipes.0)
	move	$6,$17
$L79:
	move	$5,$0
	move	$4,$0
	jal	V_MarkRect
	move	$7,$19

	addiu	$2,$16,1
	sll	$2,$2,2
	addu	$2,$18,$2
	lw	$2,0($2)
	lw	$6,60($sp)
	move	$5,$19
	jalr	$2
	move	$4,$17

	beq	$2,$0,$L80
	lw	$2,%lo(go)($20)

	addiu	$16,$16,2
	sll	$16,$16,2
	addu	$18,$18,$16
	lw	$2,0($18)
	lw	$6,60($sp)
	move	$5,$19
	move	$4,$17
	jalr	$2
	sw	$0,%lo(go)($20)

	lw	$2,%lo(go)($20)
$L80:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,40

$L77:
	lui	$18,%hi(wipes.0)
	sll	$2,$16,2
	addiu	$18,$18,%lo(wipes.0)
	addu	$2,$18,$2
	lui	$3,%hi(I_VideoBuffer)
	lw	$7,%lo(I_VideoBuffer)($3)
	lw	$6,60($sp)
	li	$3,1			# 0x1
	lw	$2,0($2)
	sw	$3,%lo(go)($20)
	move	$5,$19
	lui	$3,%hi(wipe_scr)
	move	$4,$17
	jalr	$2
	sw	$7,%lo(wipe_scr)($3)

	b	$L79
	move	$6,$17

	.set	macro
	.set	reorder
	.end	wipe_ScreenWipe
	.size	wipe_ScreenWipe, .-wipe_ScreenWipe
	.rdata
	.align	2
	.type	wipes.0, @object
	.size	wipes.0, 24
wipes.0:
	.word	wipe_initColorXForm
	.word	wipe_doColorXForm
	.word	wipe_exitColorXForm
	.word	wipe_initMelt
	.word	wipe_doMelt
	.word	wipe_exitMelt
	.local	y
	.comm	y,4,4
	.local	wipe_scr
	.comm	wipe_scr,4,4
	.local	wipe_scr_end
	.comm	wipe_scr_end,4,4
	.local	wipe_scr_start
	.comm	wipe_scr_start,4,4
	.local	go
	.comm	go,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
