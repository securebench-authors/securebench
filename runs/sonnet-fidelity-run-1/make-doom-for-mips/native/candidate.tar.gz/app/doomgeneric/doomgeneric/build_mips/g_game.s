	.file	1 "g_game.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	G_CmdChecksum
	.set	nomips16
	.set	nomicromips
	.ent	G_CmdChecksum
	.type	G_CmdChecksum, @function
G_CmdChecksum:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	lw	$5,4($4)
	lw	$3,8($4)
	addu	$2,$2,$5
	jr	$31
	addu	$2,$2,$3

	.set	macro
	.set	reorder
	.end	G_CmdChecksum
	.size	G_CmdChecksum, .-G_CmdChecksum
	.align	2
	.globl	G_BuildTiccmd
	.set	nomips16
	.set	nomicromips
	.ent	G_BuildTiccmd
	.type	G_BuildTiccmd, @function
G_BuildTiccmd:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	li	$6,16			# 0x10
	sw	$17,20($sp)
	move	$17,$5
	move	$5,$0
	sw	$fp,48($sp)
	sw	$16,16($sp)
	sw	$31,52($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	jal	memset
	move	$16,$4

	li	$2,-2147483648			# 0xffffffff80000000
	addiu	$2,$2,127
	lui	$fp,%hi(consoleplayer)
	and	$5,$17,$2
	bgez	$5,$L4
	lw	$2,%lo(consoleplayer)($fp)

	addiu	$5,$5,-1
	li	$3,-128			# 0xffffffffffffff80
	or	$5,$5,$3
	addiu	$5,$5,1
$L4:
	lui	$3,%hi(consistancy)
	addiu	$3,$3,%lo(consistancy)
	sll	$2,$2,7
	addu	$2,$2,$3
	lui	$3,%hi(key_strafe)
	addu	$2,$2,$5
	lw	$3,%lo(key_strafe)($3)
	lbu	$4,0($2)
	lui	$17,%hi(gamekeydown)
	sll	$2,$3,2
	addiu	$17,$17,%lo(gamekeydown)
	sb	$4,6($16)
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L70
	lui	$20,%hi(mousearray+4)

	lui	$2,%hi(mousebstrafe)
	lw	$2,%lo(mousebstrafe)($2)
	sll	$2,$2,2
	addiu	$20,$20,%lo(mousearray+4)
	addu	$2,$20,$2
	lw	$2,0($2)
	beq	$2,$0,$L160
	lui	$2,%hi(joybstrafe)

	lui	$2,%hi(key_speed)
	lw	$2,%lo(key_speed)($2)
	slt	$3,$2,256
	bne	$3,$0,$L161
	li	$23,1			# 0x1

	li	$18,1			# 0x1
$L6:
	lui	$2,%hi(key_right)
$L185:
	lw	$3,%lo(key_right)($2)
	lui	$2,%hi(key_left)
	lw	$2,%lo(key_left)($2)
	sll	$3,$3,2
	sll	$2,$2,2
	addu	$2,$17,$2
	addu	$3,$17,$3
	lw	$6,0($2)
	lw	$4,0($3)
	lui	$2,%hi(joyxmove)
	lw	$5,%lo(joyxmove)($2)
	or	$2,$4,$6
	or	$2,$2,$5
	bne	$2,$0,$L7
	lui	$7,%hi(ticdup)

	lui	$2,%hi(turnheld)
	bne	$23,$0,$L8
	sw	$0,%lo(turnheld)($2)

	li	$2,2			# 0x2
$L9:
	beq	$6,$0,$L19
	lui	$4,%hi(angleturn)

	addiu	$4,$4,%lo(angleturn)
	sll	$3,$2,2
	addu	$3,$3,$4
	lw	$3,0($3)
	lhu	$4,2($16)
	addu	$3,$3,$4
	sh	$3,2($16)
$L19:
	blez	$5,$L20
	lui	$3,%hi(angleturn)

	addiu	$3,$3,%lo(angleturn)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,0($2)
	lhu	$2,2($16)
	subu	$2,$2,$3
	sh	$2,2($16)
$L21:
	move	$19,$0
$L16:
	lui	$2,%hi(key_up)
	lw	$2,%lo(key_up)($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	beq	$2,$0,$L76
	lui	$22,%hi(forwardmove)

$L170:
	sll	$2,$18,2
	addiu	$22,$22,%lo(forwardmove)
	addu	$2,$22,$2
	lw	$21,0($2)
$L22:
	lui	$2,%hi(key_down)
	lw	$2,%lo(key_down)($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	beq	$2,$0,$L178
	lui	$2,%hi(joyymove)

	sll	$2,$18,2
	addu	$2,$22,$2
	lw	$2,0($2)
	subu	$21,$21,$2
	lui	$2,%hi(joyymove)
$L178:
	lw	$2,%lo(joyymove)($2)
	bltz	$2,$L162
	nop

	beq	$2,$0,$L25
	sll	$2,$18,2

	addu	$2,$22,$2
	lw	$2,0($2)
	subu	$21,$21,$2
$L25:
	lui	$2,%hi(key_strafeleft)
	lw	$2,%lo(key_strafeleft)($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L176
	lui	$3,%hi(sidemove)

	lui	$2,%hi(joybstrafeleft)
	lw	$3,%lo(joybstrafeleft)($2)
	lui	$2,%hi(joyarray+4)
	sll	$3,$3,2
	addiu	$2,$2,%lo(joyarray+4)
	addu	$2,$2,$3
	lw	$2,0($2)
	bne	$2,$0,$L176
	lui	$3,%hi(sidemove)

	lui	$2,%hi(mousebstrafeleft)
	lw	$2,%lo(mousebstrafeleft)($2)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$2,0($2)
	beq	$2,$0,$L163
	lui	$2,%hi(joystrafemove)

	lui	$3,%hi(sidemove)
$L176:
	sll	$2,$18,2
	addiu	$3,$3,%lo(sidemove)
	addu	$2,$2,$3
	lw	$2,0($2)
	subu	$19,$19,$2
	lui	$2,%hi(key_straferight)
$L186:
	lw	$2,%lo(key_straferight)($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L179
	lui	$3,%hi(sidemove)

	lui	$2,%hi(joybstraferight)
	lw	$3,%lo(joybstraferight)($2)
	lui	$2,%hi(joyarray+4)
	sll	$3,$3,2
	addiu	$2,$2,%lo(joyarray+4)
	addu	$2,$2,$3
	lw	$2,0($2)
	bne	$2,$0,$L179
	lui	$3,%hi(sidemove)

	lui	$2,%hi(mousebstraferight)
	lw	$2,%lo(mousebstraferight)($2)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$2,0($2)
	beq	$2,$0,$L164
	lui	$2,%hi(joystrafemove)

	lui	$3,%hi(sidemove)
$L179:
	sll	$2,$18,2
	addiu	$3,$3,%lo(sidemove)
	addu	$2,$2,$3
	lw	$2,0($2)
	addu	$19,$19,$2
$L29:
	jal	HU_dequeueChatChar
	nop

	lui	$3,%hi(key_fire)
	lw	$3,%lo(key_fire)($3)
	sb	$2,4($16)
	sll	$3,$3,2
	addu	$3,$17,$3
	lw	$2,0($3)
	bne	$2,$0,$L30
	lui	$2,%hi(mousebfire)

	lw	$2,%lo(mousebfire)($2)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$2,0($2)
	bne	$2,$0,$L30
	lui	$2,%hi(joybfire)

	lw	$3,%lo(joybfire)($2)
	lui	$2,%hi(joyarray+4)
	sll	$3,$3,2
	addiu	$2,$2,%lo(joyarray+4)
	addu	$2,$2,$3
	lw	$2,0($2)
	bne	$2,$0,$L30
	nop

$L31:
	lui	$2,%hi(key_use)
	lw	$2,%lo(key_use)($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L32
	lui	$2,%hi(joybuse)

	lw	$3,%lo(joybuse)($2)
	lui	$2,%hi(joyarray+4)
	sll	$3,$3,2
	addiu	$2,$2,%lo(joyarray+4)
	addu	$2,$2,$3
	lw	$2,0($2)
	bne	$2,$0,$L32
	lui	$2,%hi(mousebuse)

	lw	$2,%lo(mousebuse)($2)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$2,0($2)
	bne	$2,$0,$L32
	nop

$L33:
	lui	$2,%hi(gamestate)
	lw	$2,%lo(gamestate)($2)
	bne	$2,$0,$L34
	lui	$5,%hi(next_weapon)

	lw	$6,%lo(next_weapon)($5)
	bne	$6,$0,$L165
	lw	$15,%lo(consoleplayer)($fp)

$L34:
	lui	$3,%hi(weapon_keys)
	addiu	$3,$3,%lo(weapon_keys)
	move	$4,$0
	li	$6,8			# 0x8
$L47:
	lw	$2,0($3)
	lw	$2,0($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L166
	addiu	$3,$3,4

	addiu	$4,$4,1
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L47
	.set	at
	nop

$L45:
	lui	$2,%hi(mousebforward)
	lw	$2,%lo(mousebforward)($2)
	sw	$0,%lo(next_weapon)($5)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$5,0($2)
	beq	$5,$0,$L180
	lui	$2,%hi(mousebbackward)

	sll	$2,$18,2
	addu	$2,$22,$2
	lw	$2,0($2)
	addu	$21,$21,$2
	lui	$2,%hi(mousebbackward)
$L180:
	lw	$2,%lo(mousebbackward)($2)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$2,0($2)
	beq	$2,$0,$L181
	lui	$2,%hi(dclick_use)

	sll	$18,$18,2
	addu	$18,$22,$18
	lw	$2,0($18)
	subu	$21,$21,$2
	lui	$2,%hi(dclick_use)
$L181:
	lw	$2,%lo(dclick_use)($2)
	beq	$2,$0,$L51
	lui	$3,%hi(dclicktime)

	lui	$4,%hi(dclickstate)
	lw	$6,%lo(dclickstate)($4)
	.set	noat
	xor	$1,$5,$6
	beq	$1,$0,$L52
	.set	at
	lw	$2,%lo(dclicktime)($3)

	slt	$6,$2,2
	bne	$6,$0,$L52
	lui	$6,%hi(dclicks)

	lw	$2,%lo(dclicks)($6)
	beq	$5,$0,$L53
	sw	$5,%lo(dclickstate)($4)

	addiu	$2,$2,1
	sw	$2,%lo(dclicks)($6)
$L53:
	li	$4,2			# 0x2
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L167
	.set	at
	nop

	sw	$0,%lo(dclicktime)($3)
$L55:
	lui	$2,%hi(mousebstrafe)
	lw	$2,%lo(mousebstrafe)($2)
	lui	$5,%hi(dclickstate2)
	sll	$2,$2,2
	addu	$2,$20,$2
	lw	$3,0($2)
	lui	$4,%hi(dclicktime2)
	lw	$6,%lo(dclickstate2)($5)
	bne	$3,$0,$L56
	lw	$2,%lo(dclicktime2)($4)

	lui	$3,%hi(joybstrafe)
	lw	$7,%lo(joybstrafe)($3)
	lui	$3,%hi(joyarray+4)
	sll	$7,$7,2
	addiu	$3,$3,%lo(joyarray+4)
	addu	$3,$3,$7
	lw	$3,0($3)
	beq	$3,$0,$L168
	nop

$L56:
	li	$3,1			# 0x1
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L57
	.set	at
	slt	$6,$2,2

	bne	$6,$0,$L57
	lui	$6,%hi(dclicks2)

	lw	$2,%lo(dclicks2)($6)
	sw	$3,%lo(dclickstate2)($5)
	addiu	$2,$2,1
	sw	$2,%lo(dclicks2)($6)
$L58:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L169
	.set	at
	nop

	sw	$0,%lo(dclicktime2)($4)
$L51:
	lui	$5,%hi(mousey)
	lw	$4,%lo(mousey)($5)
	lui	$3,%hi(mousex)
	lw	$2,%lo(mousex)($3)
	beq	$23,$0,$L61
	addu	$4,$21,$4

$L172:
	sll	$6,$2,1
	addu	$19,$19,$6
$L62:
	bne	$2,$0,$L63
	lui	$2,%hi(testcontrols_mousespeed)

	sw	$0,%lo(testcontrols_mousespeed)($2)
$L63:
	lw	$2,4($22)
	sw	$0,%lo(mousey)($5)
	slt	$5,$2,$4
	bne	$5,$0,$L78
	sw	$0,%lo(mousex)($3)

	subu	$3,$0,$2
	slt	$5,$3,$4
	movn	$3,$4,$5
$L64:
	slt	$4,$2,$19
	bne	$4,$0,$L65
	nop

	subu	$2,$0,$2
	slt	$4,$2,$19
	movn	$2,$19,$4
$L65:
	lbu	$5,1($16)
	lbu	$4,0($16)
	addu	$2,$2,$5
	addu	$3,$3,$4
	andi	$2,$2,0x00ff
	andi	$3,$3,0x00ff
	sll	$2,$2,8
	or	$2,$3,$2
	sh	$2,0($16)
	lui	$2,%hi(sendpause)
	lw	$3,%lo(sendpause)($2)
	beq	$3,$0,$L182
	lui	$3,%hi(sendsave)

	sw	$0,%lo(sendpause)($2)
	li	$2,-127			# 0xffffffffffffff81
	sb	$2,5($16)
$L182:
	lw	$2,%lo(sendsave)($3)
	beq	$2,$0,$L183
	lui	$2,%hi(lowres_turn)

	lui	$2,%hi(savegameslot)
	lw	$2,%lo(savegameslot)($2)
	li	$4,-126			# 0xffffffffffffff82
	sll	$2,$2,2
	or	$2,$2,$4
	sw	$0,%lo(sendsave)($3)
	sb	$2,5($16)
	lui	$2,%hi(lowres_turn)
$L183:
	lw	$2,%lo(lowres_turn)($2)
	beq	$2,$0,$L184
	lw	$31,52($sp)

	lui	$4,%hi(carry.2)
	lhu	$3,%lo(carry.2)($4)
	lhu	$2,2($16)
	addu	$2,$2,$3
	andi	$2,$2,0xffff
	addiu	$3,$2,128
	andi	$3,$3,0xff00
	subu	$2,$2,$3
	sh	$3,2($16)
	sh	$2,%lo(carry.2)($4)
	lw	$31,52($sp)
$L184:
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L70:
	li	$23,1			# 0x1
	addiu	$20,$20,%lo(mousearray+4)
$L5:
	lui	$2,%hi(key_speed)
	lw	$2,%lo(key_speed)($2)
	slt	$3,$2,256
	beq	$3,$0,$L6
	li	$18,1			# 0x1

$L161:
	lui	$3,%hi(joybspeed)
	lw	$3,%lo(joybspeed)($3)
	slt	$4,$3,20
	beq	$4,$0,$L6
	li	$18,1			# 0x1

	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L185
	lui	$2,%hi(key_right)

	lui	$2,%hi(joyarray+4)
	sll	$3,$3,2
	addiu	$2,$2,%lo(joyarray+4)
	addu	$2,$2,$3
	lw	$18,0($2)
	b	$L6
	sltu	$18,$0,$18

$L7:
	lui	$3,%hi(turnheld)
	lw	$2,%lo(turnheld)($3)
	lw	$7,%lo(ticdup)($7)
	addu	$2,$2,$7
	slt	$7,$2,6
	sw	$2,%lo(turnheld)($3)
	li	$2,2			# 0x2
	beq	$23,$0,$L11
	movz	$2,$18,$7

	beq	$4,$0,$L8
	lui	$3,%hi(sidemove)

	sll	$2,$18,2
	addiu	$3,$3,%lo(sidemove)
	addu	$2,$2,$3
	lw	$19,0($2)
$L13:
	beq	$6,$0,$L14
	lui	$3,%hi(sidemove)

	sll	$2,$18,2
	addiu	$3,$3,%lo(sidemove)
	addu	$2,$2,$3
	lw	$2,0($2)
	subu	$19,$19,$2
$L14:
	blez	$5,$L15
	lui	$3,%hi(sidemove)

	sll	$2,$18,2
	addiu	$3,$3,%lo(sidemove)
	addu	$2,$2,$3
	lw	$2,0($2)
	addu	$19,$19,$2
	lui	$2,%hi(key_up)
	lw	$2,%lo(key_up)($2)
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L170
	lui	$22,%hi(forwardmove)

$L76:
	move	$21,$0
	b	$L22
	addiu	$22,$22,%lo(forwardmove)

$L11:
	beq	$4,$0,$L9
	sll	$3,$2,2

	lui	$4,%hi(angleturn)
	addiu	$4,$4,%lo(angleturn)
	addu	$3,$3,$4
	lw	$4,0($3)
	lhu	$3,2($16)
	subu	$3,$3,$4
	b	$L9
	sh	$3,2($16)

$L160:
	lw	$3,%lo(joybstrafe)($2)
	lui	$2,%hi(joyarray+4)
	sll	$3,$3,2
	addiu	$2,$2,%lo(joyarray+4)
	addu	$2,$2,$3
	lw	$23,0($2)
	b	$L5
	sltu	$23,$0,$23

$L52:
	lui	$5,%hi(ticdup)
	lw	$5,%lo(ticdup)($5)
	addu	$2,$2,$5
	slt	$5,$2,21
	bne	$5,$0,$L55
	sw	$2,%lo(dclicktime)($3)

	lui	$2,%hi(dclicks)
	sw	$0,%lo(dclicks)($2)
	b	$L55
	sw	$0,%lo(dclickstate)($4)

$L32:
	lbu	$2,5($16)
	ori	$2,$2,0x2
	sb	$2,5($16)
	lui	$2,%hi(dclicks)
	b	$L33
	sw	$0,%lo(dclicks)($2)

$L30:
	lbu	$2,5($16)
	ori	$2,$2,0x1
	b	$L31
	sb	$2,5($16)

$L168:
	beq	$6,$0,$L57
	slt	$3,$2,2

	beq	$3,$0,$L171
	lui	$6,%hi(dclicks2)

$L57:
	lui	$3,%hi(ticdup)
	lw	$3,%lo(ticdup)($3)
	addu	$2,$2,$3
	slt	$3,$2,21
	bne	$3,$0,$L51
	sw	$2,%lo(dclicktime2)($4)

	sw	$0,%lo(dclickstate2)($5)
	lui	$5,%hi(mousey)
	lw	$4,%lo(mousey)($5)
	lui	$2,%hi(dclicks2)
	lui	$3,%hi(mousex)
	sw	$0,%lo(dclicks2)($2)
	addu	$4,$21,$4
	bne	$23,$0,$L172
	lw	$2,%lo(mousex)($3)

$L61:
	lhu	$6,2($16)
	sll	$7,$2,3
	subu	$6,$6,$7
	b	$L62
	sh	$6,2($16)

$L78:
	b	$L64
	move	$3,$2

$L162:
	sll	$2,$18,2
	addu	$2,$22,$2
	lw	$2,0($2)
	b	$L25
	addu	$21,$21,$2

$L166:
	lbu	$3,5($16)
	sll	$2,$4,3
	or	$2,$2,$3
	ori	$2,$2,0x4
	b	$L45
	sb	$2,5($16)

$L15:
	beq	$5,$0,$L16
	sll	$2,$18,2

	addiu	$3,$3,%lo(sidemove)
	addu	$2,$2,$3
	lw	$2,0($2)
	b	$L16
	subu	$19,$19,$2

$L20:
	beq	$5,$0,$L21
	addiu	$3,$3,%lo(angleturn)

	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$2,0($2)
	lhu	$3,2($16)
	addu	$2,$2,$3
	b	$L21
	sh	$2,2($16)

$L8:
	b	$L13
	move	$19,$0

$L163:
	lw	$2,%lo(joystrafemove)($2)
	bgez	$2,$L186
	lui	$2,%hi(key_straferight)

	b	$L176
	lui	$3,%hi(sidemove)

$L164:
	lw	$2,%lo(joystrafemove)($2)
	bgtz	$2,$L179
	lui	$3,%hi(sidemove)

	b	$L29
	nop

$L165:
	lui	$8,%hi(players)
	sll	$24,$15,3
	addu	$2,$24,$15
	addiu	$8,$8,%lo(players)
	sll	$2,$2,5
	addu	$2,$8,$2
	lw	$9,124($2)
	li	$3,10			# 0xa
	.set	noat
	xor	$1,$9,$3
	bne	$1,$0,$L187
	.set	at
	lui	$7,%hi(weapon_order_table)

	lw	$9,120($2)
$L187:
	addiu	$7,$7,%lo(weapon_order_table)
	move	$2,$7
	move	$4,$0
	li	$10,9			# 0x9
$L37:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$9
	beq	$1,$0,$L36
	.set	at
	addiu	$2,$2,8

	addiu	$4,$4,1
	.set	noat
	xor	$1,$4,$10
	bne	$1,$0,$L37
	.set	at
	nop

	li	$2,954400768			# 0x38e30000
	addiu	$9,$6,18
	ori	$2,$2,0x8e39
	multu	$9,$2
	mfhi	$2
	srl	$2,$2,1
	sll	$3,$2,3
	addu	$2,$3,$2
	subu	$2,$9,$2
$L69:
	lui	$3,%hi(gamemission)
	lw	$14,%lo(gamemission)($3)
	addu	$9,$24,$15
	lui	$3,%hi(gamemode)
	sll	$12,$9,5
	li	$13,-5			# 0xfffffffffffffffb
	li	$10,954400768			# 0x38e30000
	lw	$25,%lo(gamemode)($3)
	and	$13,$14,$13
	li	$11,8			# 0x8
	sll	$9,$9,3
	addu	$12,$8,$12
	ori	$10,$10,0x8e39
$L40:
	sll	$fp,$2,3
	addu	$3,$7,$fp
	lw	$3,0($3)
	.set	noat
	xor	$1,$3,$11
	beq	$1,$0,$L173
	.set	at
	addiu	$17,$3,-5

	sltu	$17,$17,2
	bne	$17,$0,$L174
	addu	$17,$9,$3

	addiu	$17,$17,32
	sll	$17,$17,2
	addu	$17,$8,$17
	lw	$17,0($17)
	beq	$17,$0,$L42
	nop

	bne	$3,$0,$L39
	nop

	lw	$3,156($12)
	bne	$3,$0,$L175
	nop

$L39:
	addu	$fp,$7,$fp
$L188:
	lw	$2,4($fp)
	lbu	$3,5($16)
	sll	$2,$2,3
	or	$2,$2,$3
	ori	$2,$2,0x4
	b	$L45
	sb	$2,5($16)

$L174:
	bne	$14,$0,$L44
	nop

	beq	$25,$0,$L42
	nop

$L44:
	addu	$3,$9,$3
	addiu	$3,$3,32
	sll	$3,$3,2
	addu	$3,$8,$3
	lw	$3,0($3)
	bne	$3,$0,$L39
	nop

$L42:
	addu	$2,$6,$2
	addiu	$17,$2,9
$L189:
	multu	$17,$10
	mfhi	$3
	srl	$3,$3,1
	sll	$2,$3,3
	addu	$2,$2,$3
	subu	$2,$17,$2
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L40
	.set	at
	sll	$fp,$2,3

	b	$L188
	addu	$fp,$7,$fp

$L173:
	beq	$13,$0,$L42
	addu	$3,$24,$15

	sll	$3,$3,5
	addu	$3,$8,$3
	lw	$3,160($3)
	bne	$3,$0,$L39
	addu	$2,$6,$2

	b	$L189
	addiu	$17,$2,9

$L175:
	lw	$3,56($12)
	bne	$3,$0,$L39
	addu	$2,$6,$2

	b	$L189
	addiu	$17,$2,9

$L36:
	addu	$2,$6,$4
	li	$3,954400768			# 0x38e30000
	addiu	$2,$2,9
	ori	$3,$3,0x8e39
	multu	$2,$3
	mfhi	$3
	srl	$3,$3,1
	sll	$9,$3,3
	addu	$3,$9,$3
	subu	$2,$2,$3
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L69
	.set	at
	sll	$fp,$4,3

	b	$L188
	addu	$fp,$7,$fp

$L167:
	lbu	$2,5($16)
	sw	$0,%lo(dclicks)($6)
	ori	$2,$2,0x2
	b	$L55
	sb	$2,5($16)

$L169:
	lbu	$2,5($16)
	sw	$0,%lo(dclicks2)($6)
	ori	$2,$2,0x2
	b	$L51
	sb	$2,5($16)

$L171:
	lw	$2,%lo(dclicks2)($6)
	b	$L58
	sw	$0,%lo(dclickstate2)($5)

	.set	macro
	.set	reorder
	.end	G_BuildTiccmd
	.size	G_BuildTiccmd, .-G_BuildTiccmd
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"SKY1\000"
	.align	2
$LC1:
	.ascii	"SKY2\000"
	.align	2
$LC2:
	.ascii	"SKY3\000"
	.align	2
$LC3:
	.ascii	"F_SKY1\000"
	.align	2
$LC4:
	.ascii	"Press escape to quit.\000"
	.text
	.align	2
	.globl	G_DoLoadLevel
	.set	nomips16
	.set	nomicromips
	.ent	G_DoLoadLevel
	.type	G_DoLoadLevel, @function
G_DoLoadLevel:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC3)
	addiu	$sp,$sp,-48
	addiu	$4,$4,%lo($LC3)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	jal	R_FlatNumForName
	sw	$16,20($sp)

	lui	$3,%hi(gamemode)
	lw	$4,%lo(gamemode)($3)
	lui	$5,%hi(skyflatnum)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L208
	.set	at
	sw	$2,%lo(skyflatnum)($5)

	lui	$20,%hi(gamemap)
$L191:
	lui	$3,%hi(gametic)
	lui	$2,%hi(wipegamestate)
	lw	$5,%lo(gametic)($3)
	lw	$3,%lo(wipegamestate)($2)
	lui	$4,%hi(levelstarttic)
	bne	$3,$0,$L193
	sw	$5,%lo(levelstarttic)($4)

	li	$3,-1			# 0xffffffffffffffff
	sw	$3,%lo(wipegamestate)($2)
$L193:
	lui	$16,%hi(turbodetected)
	addiu	$16,$16,%lo(turbodetected)
	lui	$2,%hi(gamestate)
	lui	$18,%hi(playeringame)
	lui	$17,%hi(players+104)
	sw	$0,%lo(gamestate)($2)
	addiu	$18,$18,%lo(playeringame)
	addiu	$17,$17,%lo(players+104)
	addiu	$19,$16,16
	li	$21,1			# 0x1
$L195:
	lw	$2,0($18)
	sw	$0,0($16)
	move	$4,$17
	li	$6,16			# 0x10
	move	$5,$0
	beq	$2,$0,$L194
	addiu	$16,$16,4

	lw	$2,-100($17)
	.set	noat
	xor	$1,$2,$21
	bne	$1,$0,$L194
	.set	at
	li	$2,2			# 0x2

	sw	$2,-100($17)
$L194:
	jal	memset
	addiu	$18,$18,4

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L195
	.set	at
	addiu	$17,$17,288

	lui	$2,%hi(gameskill)
	lw	$7,%lo(gameskill)($2)
	lui	$2,%hi(gameepisode)
	lw	$4,%lo(gameepisode)($2)
	lw	$5,%lo(gamemap)($20)
	move	$6,$0
	jal	P_SetupLevel
	lui	$16,%hi(consoleplayer)

	lw	$3,%lo(consoleplayer)($16)
	lui	$2,%hi(displayplayer)
	sw	$3,%lo(displayplayer)($2)
	lui	$2,%hi(gameaction)
	jal	Z_CheckHeap
	sw	$0,%lo(gameaction)($2)

	lui	$4,%hi(gamekeydown)
	li	$6,1024			# 0x400
	move	$5,$0
	jal	memset
	addiu	$4,$4,%lo(gamekeydown)

	lui	$2,%hi(joystrafemove)
	sw	$0,%lo(joystrafemove)($2)
	lui	$2,%hi(joyymove)
	sw	$0,%lo(joyymove)($2)
	lui	$2,%hi(joyxmove)
	sw	$0,%lo(joyxmove)($2)
	lui	$2,%hi(mousey)
	sw	$0,%lo(mousey)($2)
	lui	$2,%hi(mousex)
	sw	$0,%lo(mousex)($2)
	lui	$2,%hi(paused)
	sw	$0,%lo(paused)($2)
	lui	$4,%hi(mousearray)
	lui	$2,%hi(sendsave)
	li	$6,36			# 0x24
	move	$5,$0
	addiu	$4,$4,%lo(mousearray)
	sw	$0,%lo(sendsave)($2)
	lui	$2,%hi(sendpause)
	jal	memset
	sw	$0,%lo(sendpause)($2)

	lui	$4,%hi(joyarray)
	li	$6,84			# 0x54
	move	$5,$0
	jal	memset
	addiu	$4,$4,%lo(joyarray)

	lui	$2,%hi(testcontrols)
	lw	$2,%lo(testcontrols)($2)
	beq	$2,$0,$L211
	lw	$31,44($sp)

	lw	$3,%lo(consoleplayer)($16)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	lui	$3,%hi($LC4)
	addiu	$3,$3,%lo($LC4)
	sw	$3,224($2)
	lw	$31,44($sp)
$L211:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L208:
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	addiu	$2,$2,-8
	sltu	$2,$2,2
	beq	$2,$0,$L191
	lui	$20,%hi(gamemap)

	lw	$2,%lo(gamemap)($20)
	slt	$3,$2,12
	bne	$3,$0,$L197
	lui	$4,%hi($LC0)

	slt	$2,$2,21
	beq	$2,$0,$L198
	nop

	lui	$4,%hi($LC1)
	b	$L192
	addiu	$4,$4,%lo($LC1)

$L197:
	addiu	$4,$4,%lo($LC0)
$L192:
	jal	R_TextureNumForName
	nop

	lui	$3,%hi(skytexture)
	b	$L191
	sw	$2,%lo(skytexture)($3)

$L198:
	lui	$4,%hi($LC2)
	b	$L192
	addiu	$4,$4,%lo($LC2)

	.set	macro
	.set	reorder
	.end	G_DoLoadLevel
	.size	G_DoLoadLevel, .-G_DoLoadLevel
	.align	2
	.globl	G_Responder
	.set	nomips16
	.set	nomicromips
	.ent	G_Responder
	.type	G_Responder, @function
G_Responder:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	lui	$18,%hi(gamestate)
	lw	$3,%lo(gamestate)($18)
	lui	$2,%hi(singledemo)
	sw	$16,16($sp)
	lw	$2,%lo(singledemo)($2)
	sw	$31,28($sp)
	sw	$17,20($sp)
	bne	$3,$0,$L213
	move	$16,$4

	lw	$3,0($4)
	bne	$3,$0,$L214
	nop

	lui	$3,%hi(key_spy)
	lw	$4,4($4)
	lw	$3,%lo(key_spy)($3)
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L280
	.set	at
	lui	$3,%hi(gameaction)

	lw	$3,%lo(gameaction)($3)
	or	$2,$2,$3
	bne	$2,$0,$L223
	lui	$2,%hi(demoplayback)

$L294:
	lw	$2,%lo(demoplayback)($2)
	beq	$2,$0,$L223
	nop

$L228:
	jal	M_StartControlPanel
	nop

$L220:
	b	$L212
	li	$2,1			# 0x1

$L213:
	lui	$4,%hi(gameaction)
	lw	$4,%lo(gameaction)($4)
	or	$2,$2,$4
	bne	$2,$0,$L289
	li	$2,2			# 0x2

	lui	$2,%hi(demoplayback)
	lw	$2,%lo(demoplayback)($2)
	bne	$2,$0,$L279
	li	$2,3			# 0x3

	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L279
	.set	at
	li	$2,2			# 0x2

$L289:
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L236
	.set	at
	nop

$L239:
	lui	$2,%hi(testcontrols)
	lw	$2,%lo(testcontrols)($2)
	beq	$2,$0,$L238
	lw	$3,0($16)

	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L240
	.set	at
	nop

	bne	$3,$0,$L290
	li	$2,3			# 0x3

$L241:
	lui	$3,%hi(key_prevweapon)
	lw	$2,4($16)
	lw	$3,%lo(key_prevweapon)($3)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L281
	.set	at
	lui	$3,%hi(key_nextweapon)

	lw	$3,%lo(key_nextweapon)($3)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L282
	.set	at
	lui	$3,%hi(next_weapon)

$L245:
	lui	$3,%hi(key_pause)
	lw	$3,%lo(key_pause)($3)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L283
	.set	at
	slt	$3,$2,256

	beq	$3,$0,$L220
	lui	$3,%hi(gamekeydown)

	addiu	$3,$3,%lo(gamekeydown)
	sll	$2,$2,2
	addu	$2,$2,$3
	li	$3,1			# 0x1
	sw	$3,0($2)
	b	$L212
	li	$2,1			# 0x1

$L240:
	jal	abs
	lw	$4,8($16)

	lui	$4,%hi(testcontrols_mousespeed)
	lw	$3,0($16)
	sw	$2,%lo(testcontrols_mousespeed)($4)
$L238:
	beq	$3,$0,$L241
	li	$2,2			# 0x2

	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L242
	.set	at
	lui	$2,%hi(mousebprevweapon)

	lw	$10,%lo(mousebprevweapon)($2)
	lui	$4,%hi(mousearray)
	lui	$2,%hi(mousebnextweapon)
	lw	$9,4($16)
	lw	$11,%lo(mousebnextweapon)($2)
	addiu	$4,$4,%lo(mousearray)
	move	$2,$0
	li	$7,1			# 0x1
	li	$8,8			# 0x8
$L252:
	sll	$3,$7,$2
	lw	$6,4($4)
	and	$3,$3,$9
	bne	$6,$0,$L250
	sltu	$5,$0,$3

	beq	$3,$0,$L250
	nop

	.set	noat
	xor	$1,$2,$10
	beq	$1,$0,$L284
	.set	at
	lui	$3,%hi(next_weapon)

	.set	noat
	xor	$1,$2,$11
	bne	$1,$0,$L250
	.set	at
	nop

	sw	$7,%lo(next_weapon)($3)
$L250:
	addiu	$2,$2,1
	sw	$5,4($4)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L252
	.set	at
	addiu	$4,$4,4

	lui	$2,%hi(mouseSensitivity)
	lw	$3,%lo(mouseSensitivity)($2)
	lw	$4,8($16)
	addiu	$3,$3,5
	multu	$3,$4
	mflo	$4
	lw	$2,12($16)
	multu	$3,$2
	mflo	$3
	li	$2,1717960704			# 0x66660000
	addiu	$2,$2,26215
	mult	$4,$2
	sra	$4,$4,31
	mfhi	$5
	mult	$3,$2
	sra	$5,$5,2
	mfhi	$2
	sra	$3,$3,31
	sra	$2,$2,2
	subu	$2,$2,$3
	subu	$5,$5,$4
	lui	$3,%hi(mousex)
	sw	$5,%lo(mousex)($3)
	lui	$3,%hi(mousey)
	sw	$2,%lo(mousey)($3)
	b	$L212
	li	$2,1			# 0x1

$L214:
	lui	$4,%hi(gameaction)
	lw	$4,%lo(gameaction)($4)
	or	$2,$2,$4
	bne	$2,$0,$L223
	lui	$2,%hi(demoplayback)

	lw	$2,%lo(demoplayback)($2)
	bne	$2,$0,$L291
	addiu	$3,$3,-2

$L223:
	jal	HU_Responder
	move	$4,$16

	bne	$2,$0,$L212
	li	$2,1			# 0x1

	jal	ST_Responder
	move	$4,$16

	bne	$2,$0,$L212
	li	$2,1			# 0x1

	jal	AM_Responder
	move	$4,$16

	bne	$2,$0,$L220
	lw	$3,%lo(gamestate)($18)

	b	$L289
	li	$2,2			# 0x2

$L242:
	li	$2,3			# 0x3
$L290:
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L247
	.set	at
	lui	$2,%hi(joybprevweapon)

	li	$2,1			# 0x1
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L285
	.set	at
	nop

$L232:
	move	$2,$0
$L212:
	lw	$31,28($sp)
$L296:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L236:
	jal	F_Responder
	move	$4,$16

	beq	$2,$0,$L239
	li	$2,1			# 0x1

	b	$L296
	lw	$31,28($sp)

$L281:
	lui	$3,%hi(next_weapon)
	li	$4,-1			# 0xffffffffffffffff
	b	$L245
	sw	$4,%lo(next_weapon)($3)

$L280:
	bne	$2,$0,$L292
	lui	$7,%hi(displayplayer)

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	beq	$2,$0,$L293
	lui	$3,%hi(consoleplayer)

	lui	$2,%hi(gameaction)
	lw	$2,%lo(gameaction)($2)
	beq	$2,$0,$L294
	lui	$2,%hi(demoplayback)

	b	$L223
	nop

$L282:
	li	$4,1			# 0x1
	b	$L245
	sw	$4,%lo(next_weapon)($3)

$L285:
	lw	$2,4($16)
	slt	$3,$2,256
	beq	$3,$0,$L232
	lui	$3,%hi(gamekeydown)

	sll	$2,$2,2
	addiu	$3,$3,%lo(gamekeydown)
	addu	$2,$2,$3
	b	$L232
	sw	$0,0($2)

$L247:
	lw	$12,%lo(joybprevweapon)($2)
	lui	$5,%hi(joyarray+4)
	lui	$2,%hi(joybnextweapon)
	lw	$11,%lo(joybnextweapon)($2)
	lw	$9,4($16)
	addiu	$5,$5,%lo(joyarray+4)
	move	$10,$0
	move	$2,$0
	li	$7,1			# 0x1
	b	$L254
	li	$8,20			# 0x14

$L287:
	movz	$10,$7,$3
	movz	$17,$7,$3
$L253:
	addiu	$2,$2,1
	sw	$4,0($5)
	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L286
	.set	at
	addiu	$5,$5,4

$L254:
	sll	$3,$7,$2
	lw	$6,0($5)
	and	$3,$3,$9
	bne	$6,$0,$L253
	sltu	$4,$0,$3

	beq	$3,$0,$L253
	nop

	.set	noat
	xor	$1,$2,$12
	bne	$1,$0,$L287
	.set	at
	xor	$3,$2,$11

	addiu	$2,$2,1
	sw	$4,0($5)
	li	$10,1			# 0x1
	li	$17,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L254
	.set	at
	addiu	$5,$5,4

$L286:
	beq	$10,$0,$L255
	nop

	lui	$2,%hi(next_weapon)
	sw	$17,%lo(next_weapon)($2)
$L255:
	lw	$5,8($16)
	lui	$2,%hi(joyxmove)
	lw	$4,12($16)
	lw	$3,16($16)
	sw	$5,%lo(joyxmove)($2)
	lui	$2,%hi(joyymove)
	sw	$4,%lo(joyymove)($2)
	lui	$2,%hi(joystrafemove)
	sw	$3,%lo(joystrafemove)($2)
	b	$L212
	li	$2,1			# 0x1

$L279:
	lw	$3,0($16)
	beq	$3,$0,$L228
	addiu	$3,$3,-2

$L291:
	sltu	$3,$3,2
	beq	$3,$0,$L212
	move	$2,$0

	lw	$2,4($16)
	beq	$2,$0,$L232
	nop

	jal	M_StartControlPanel
	nop

	b	$L212
	li	$2,1			# 0x1

$L284:
	li	$6,-1			# 0xffffffffffffffff
	b	$L250
	sw	$6,%lo(next_weapon)($3)

$L292:
	lui	$3,%hi(consoleplayer)
$L293:
	lui	$4,%hi(playeringame)
	lw	$2,%lo(displayplayer)($7)
	lw	$6,%lo(consoleplayer)($3)
	addiu	$4,$4,%lo(playeringame)
	b	$L221
	li	$5,4			# 0x4

$L219:
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L288
	.set	at
	nop

$L221:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L295
	.set	at
	sll	$3,$2,2

	move	$2,$0
	sll	$3,$2,2
$L295:
	addu	$3,$4,$3
	lw	$3,0($3)
	beq	$3,$0,$L219
	nop

	sw	$2,%lo(displayplayer)($7)
	b	$L212
	li	$2,1			# 0x1

$L283:
	lui	$2,%hi(sendpause)
	li	$3,1			# 0x1
	sw	$3,%lo(sendpause)($2)
	b	$L212
	li	$2,1			# 0x1

$L288:
	sw	$6,%lo(displayplayer)($7)
	b	$L212
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	G_Responder
	.size	G_Responder, .-G_Responder
	.align	2
	.globl	G_PlayerFinishLevel
	.set	nomips16
	.set	nomicromips
	.ent	G_PlayerFinishLevel
	.type	G_PlayerFinishLevel, @function
G_PlayerFinishLevel:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	sll	$16,$4,3
	addu	$16,$16,$4
	sw	$17,24($sp)
	sll	$16,$16,5
	lui	$17,%hi(players)
	addiu	$17,$17,%lo(players)
	addiu	$4,$16,52
	addu	$4,$17,$4
	li	$6,24			# 0x18
	sw	$31,28($sp)
	jal	memset
	move	$5,$0

	addiu	$4,$16,76
	addu	$4,$17,$4
	move	$5,$0
	jal	memset
	li	$6,24			# 0x18

	addu	$4,$16,$17
	lw	$5,0($4)
	li	$3,-327680			# 0xfffffffffffb0000
	lw	$2,104($5)
	lw	$31,28($sp)
	ori	$3,$3,0xffff
	and	$2,$2,$3
	sw	$2,104($5)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$0,240($4)
	sw	$0,244($4)
	sw	$0,228($4)
	sw	$0,232($4)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	G_PlayerFinishLevel
	.size	G_PlayerFinishLevel, .-G_PlayerFinishLevel
	.align	2
	.globl	G_PlayerReborn
	.set	nomips16
	.set	nomicromips
	.ent	G_PlayerReborn
	.type	G_PlayerReborn, @function
G_PlayerReborn:
	.frame	$sp,72,$31		# vars= 16, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$18,44($sp)
	sll	$18,$4,3
	addu	$18,$18,$4
	sw	$19,48($sp)
	sll	$18,$18,5
	lui	$19,%hi(players)
	sw	$20,52($sp)
	addiu	$19,$19,%lo(players)
	addiu	$20,$18,104
	addu	$20,$19,$20
	sw	$17,40($sp)
	sw	$16,36($sp)
	move	$5,$20
	addu	$16,$19,$18
	addiu	$4,$sp,16
	li	$6,16			# 0x10
	addiu	$17,$18,208
	sw	$31,68($sp)
	sw	$23,64($sp)
	sw	$22,60($sp)
	sw	$21,56($sp)
	jal	memcpy
	addu	$17,$19,$17

	move	$4,$16
	li	$6,288			# 0x120
	move	$5,$0
	lw	$23,4($17)
	lw	$22,8($17)
	jal	memset
	lw	$21,12($17)

	addiu	$5,$sp,16
	move	$4,$20
	jal	memcpy
	li	$6,16			# 0x10

	lui	$3,%hi(maxammo)
	addiu	$2,$3,%lo(maxammo)
	lw	$4,12($2)
	lw	$5,8($2)
	lw	$6,4($2)
	lw	$7,%lo(maxammo)($3)
	li	$2,1			# 0x1
	lw	$31,68($sp)
	addiu	$18,$18,176
	sw	$23,4($17)
	sw	$22,8($17)
	sw	$21,12($17)
	addu	$19,$19,$18
	sw	$2,196($16)
	sw	$2,200($16)
	sw	$2,124($16)
	sw	$2,120($16)
	sw	$2,128($16)
	sw	$2,132($16)
	li	$8,100			# 0x64
	li	$2,50			# 0x32
	sw	$0,4($16)
	sw	$8,40($16)
	sw	$2,164($16)
	lw	$23,64($sp)
	lw	$22,60($sp)
	lw	$21,56($sp)
	lw	$20,52($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	sw	$7,4($19)
	sw	$6,8($19)
	sw	$5,12($19)
	sw	$4,16($19)
	lw	$19,48($sp)
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	G_PlayerReborn
	.size	G_PlayerReborn, .-G_PlayerReborn
	.align	2
	.globl	G_InitPlayer
	.set	nomips16
	.set	nomicromips
	.ent	G_InitPlayer
	.type	G_InitPlayer, @function
G_InitPlayer:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	G_PlayerReborn
	nop

	.set	macro
	.set	reorder
	.end	G_InitPlayer
	.size	G_InitPlayer, .-G_InitPlayer
	.section	.rodata.str1.4
	.align	2
$LC5:
	.ascii	"G_CheckSpot: unexpected angle %d\012\000"
	.text
	.align	2
	.globl	G_CheckSpot
	.set	nomips16
	.set	nomicromips
	.ent	G_CheckSpot
	.type	G_CheckSpot, @function
G_CheckSpot:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$21,40($sp)
	sll	$21,$4,3
	addu	$2,$21,$4
	sll	$3,$2,5
	lui	$2,%hi(players)
	sw	$16,20($sp)
	addiu	$16,$2,%lo(players)
	addu	$2,$16,$3
	sw	$17,24($sp)
	move	$17,$4
	lw	$4,0($2)
	sw	$18,28($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	beq	$4,$0,$L334
	move	$18,$5

	lbu	$19,1($5)
	lbu	$20,3($5)
	lbu	$3,0($5)
	lbu	$2,2($5)
	sll	$19,$19,8
	sll	$20,$20,8
	or	$19,$19,$3
	or	$20,$20,$2
	sll	$19,$19,16
	sll	$20,$20,16
	move	$6,$20
	jal	P_CheckPosition
	move	$5,$19

	beq	$2,$0,$L310
	lui	$23,%hi(bodyqueslot)

	lw	$4,%lo(bodyqueslot)($23)
	slt	$2,$4,32
	beq	$2,$0,$L330
	andi	$2,$4,0x1f

	lui	$22,%hi(bodyque)
	addiu	$22,$22,%lo(bodyque)
$L311:
	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,31
	and	$3,$4,$3
	bgez	$3,$L340
	addu	$2,$21,$17

	addiu	$3,$3,-1
	li	$2,-32			# 0xffffffffffffffe0
	or	$3,$3,$2
	addiu	$3,$3,1
	addu	$2,$21,$17
$L340:
	sll	$2,$2,5
	addu	$2,$16,$2
	lw	$6,0($2)
	sll	$3,$3,2
	addu	$22,$22,$3
	addiu	$2,$4,1
	move	$5,$20
	move	$4,$19
	sw	$6,0($22)
	jal	R_PointInSubsector
	sw	$2,%lo(bodyqueslot)($23)

	lbu	$3,5($18)
	lbu	$4,4($18)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	li	$4,-1240793088			# 0xffffffffb60b0000
	sra	$3,$3,16
	addiu	$4,$4,24759
	mult	$3,$4
	sra	$6,$3,31
	mfhi	$4
	move	$17,$2
	addu	$5,$4,$3
	sra	$5,$5,5
	addiu	$4,$3,-225
	subu	$5,$5,$6
	andi	$4,$4,0xffff
	sll	$5,$5,16
	sra	$5,$5,16
	sltu	$4,$4,45
	bne	$4,$0,$L313
	sll	$5,$5,10

	slt	$2,$5,5121
	bne	$2,$0,$L335
	addiu	$4,$3,-180

	addiu	$4,$3,-270
	andi	$4,$4,0xffff
	sltu	$4,$4,45
	bne	$4,$0,$L319
	addiu	$3,$3,-315

	andi	$3,$3,0xffff
	sltu	$3,$3,45
	beq	$3,$0,$L341
	lui	$4,%hi($LC5)

	lui	$2,%hi(finesine+4096)
	lw	$5,%lo(finesine+4096)($2)
	lui	$2,%hi(finetangent+12288)
	lw	$4,%lo(finetangent+12288)($2)
$L332:
	sll	$3,$5,2
	sll	$2,$4,2
	addu	$3,$3,$5
$L333:
	addu	$2,$2,$4
	sll	$3,$3,2
	sll	$2,$2,2
	addu	$19,$19,$3
	addu	$20,$20,$2
	lw	$2,0($17)
$L339:
	move	$5,$20
	lw	$6,0($2)
	move	$4,$19
	jal	P_SpawnMobj
	li	$7,39			# 0x27

	lui	$3,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($3)
	li	$5,1			# 0x1
	sll	$3,$4,3
	addu	$3,$3,$4
	sll	$3,$3,5
	addu	$16,$16,$3
	lw	$3,24($16)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L336
	.set	at
	move	$4,$2

$L305:
	li	$2,1			# 0x1
$L338:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L334:
	blez	$17,$L305
	move	$3,$0

	lbu	$4,1($5)
	lbu	$2,0($5)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$4,$4,16
	b	$L308
	move	$2,$16

$L306:
	.set	noat
	xor	$1,$17,$3
	beq	$1,$0,$L305
	.set	at
	nop

$L308:
	lw	$7,0($2)
	addiu	$3,$3,1
	lw	$6,12($7)
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L306
	.set	at
	addiu	$2,$2,288

	lbu	$6,3($18)
	lbu	$5,2($18)
	sll	$6,$6,8
	or	$6,$6,$5
	lw	$5,16($7)
	sll	$6,$6,16
	.set	noat
	xor	$1,$5,$6
	bne	$1,$0,$L306
	.set	at
	nop

$L310:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,56

$L335:
	andi	$4,$4,0xffff
	sltu	$4,$4,45
	bne	$4,$0,$L315
	slt	$2,$5,4097

	beq	$2,$0,$L341
	lui	$4,%hi($LC5)

	addiu	$4,$3,-90
	andi	$4,$4,0xffff
	sltu	$4,$4,45
	bne	$4,$0,$L342
	lui	$2,%hi(finecosine)

	slt	$2,$5,2049
	bne	$2,$0,$L337
	addiu	$3,$3,-135

	andi	$3,$3,0xffff
	sltu	$3,$3,45
	beq	$3,$0,$L316
	nop

$L317:
	lui	$2,%hi(finecosine)
$L342:
	lw	$2,%lo(finecosine)($2)
	sll	$5,$5,2
	lui	$3,%hi(finesine)
	addu	$2,$2,$5
	addiu	$3,$3,%lo(finesine)
	lw	$6,0($2)
	addu	$5,$5,$3
	lw	$4,0($5)
	sll	$3,$6,2
	sll	$2,$4,2
	b	$L333
	addu	$3,$3,$6

$L337:
	li	$2,-1025			# 0xfffffffffffffbff
	and	$2,$5,$2
	beq	$2,$0,$L317
	nop

$L316:
	lui	$4,%hi($LC5)
$L341:
	jal	I_Error
	addiu	$4,$4,%lo($LC5)

	b	$L339
	lw	$2,0($17)

$L336:
	jal	S_StartSound
	li	$5,35			# 0x23

	b	$L338
	li	$2,1			# 0x1

$L330:
	lui	$22,%hi(bodyque)
	sll	$2,$2,2
	addiu	$22,$22,%lo(bodyque)
	addu	$2,$22,$2
	jal	P_RemoveMobj
	lw	$4,0($2)

	b	$L311
	lw	$4,%lo(bodyqueslot)($23)

$L313:
	lui	$2,%hi(finetangent)
	addiu	$2,$2,%lo(finetangent)
	lw	$5,12288($2)
	b	$L332
	lw	$4,4096($2)

$L315:
	lui	$2,%hi(finetangent)
	addiu	$3,$2,%lo(finetangent)
	lw	$5,8192($3)
	b	$L332
	lw	$4,%lo(finetangent)($2)

$L319:
	lui	$2,%hi(finesine)
	lw	$5,%lo(finesine)($2)
	lui	$2,%hi(finetangent+8192)
	b	$L332
	lw	$4,%lo(finetangent+8192)($2)

	.set	macro
	.set	reorder
	.end	G_CheckSpot
	.size	G_CheckSpot, .-G_CheckSpot
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"Only %i deathmatch spots, 4 required\000"
	.text
	.align	2
	.globl	G_DeathMatchSpawnPlayer
	.set	nomips16
	.set	nomicromips
	.ent	G_DeathMatchSpawnPlayer
	.type	G_DeathMatchSpawnPlayer, @function
G_DeathMatchSpawnPlayer:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lui	$2,%hi(deathmatch_p)
	lw	$2,%lo(deathmatch_p)($2)
	sw	$20,32($sp)
	lui	$20,%hi(deathmatchstarts)
	addiu	$20,$20,%lo(deathmatchstarts)
	subu	$2,$2,$20
	li	$3,-859045888			# 0xffffffffcccc0000
	sw	$18,24($sp)
	ori	$3,$3,0xcccd
	sra	$18,$2,1
	slt	$2,$2,31
	sw	$19,28($sp)
	multu	$18,$3
	mflo	$18
	sw	$31,36($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	bne	$2,$0,$L350
	move	$19,$4

	b	$L346
	li	$17,20			# 0x14

$L345:
	beq	$17,$0,$L351
	sll	$2,$19,2

$L346:
	jal	P_Random
	addiu	$17,$17,-1

	div	$0,$2,$18
	move	$4,$19
	mfhi	$2
	sll	$16,$2,2
	addu	$16,$16,$2
	sll	$16,$16,1
	addu	$16,$20,$16
	jal	G_CheckSpot
	move	$5,$16

	beq	$2,$0,$L345
	move	$4,$16

	addiu	$19,$19,1
	andi	$2,$19,0xffff
	srl	$2,$2,8
	sb	$19,6($16)
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	sb	$2,7($16)
	lw	$16,16($sp)
	j	P_SpawnPlayer
	addiu	$sp,$sp,40

$L350:
	lui	$4,%hi($LC6)
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC6)

	b	$L346
	li	$17,20			# 0x14

$L351:
	addu	$2,$2,$19
	lui	$4,%hi(playerstarts)
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sll	$2,$2,1
	addiu	$4,$4,%lo(playerstarts)
	addu	$4,$4,$2
	j	P_SpawnPlayer
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	G_DeathMatchSpawnPlayer
	.size	G_DeathMatchSpawnPlayer, .-G_DeathMatchSpawnPlayer
	.align	2
	.globl	G_DoReborn
	.set	nomips16
	.set	nomicromips
	.ent	G_DoReborn
	.type	G_DoReborn, @function
G_DoReborn:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	bne	$2,$0,$L353
	lui	$3,%hi(players)

	lui	$2,%hi(gameaction)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(gameaction)($2)

$L353:
	sll	$2,$4,3
	addu	$2,$2,$4
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addiu	$sp,$sp,-48
	addu	$2,$2,$3
	lui	$3,%hi(deathmatch)
	lw	$2,0($2)
	sw	$17,24($sp)
	lw	$17,%lo(deathmatch)($3)
	sw	$16,20($sp)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	move	$16,$4
	bne	$17,$0,$L364
	sw	$0,132($2)

	sll	$18,$4,2
	addu	$18,$18,$4
	lui	$20,%hi(playerstarts)
	sll	$18,$18,1
	addiu	$20,$20,%lo(playerstarts)
	addu	$18,$20,$18
	jal	G_CheckSpot
	move	$5,$18

	bne	$2,$0,$L363
	move	$19,$20

	li	$21,4			# 0x4
$L358:
	move	$5,$19
	jal	G_CheckSpot
	move	$4,$16

	bne	$2,$0,$L365
	sll	$2,$17,2

	addiu	$17,$17,1
	.set	noat
	xor	$1,$17,$21
	bne	$1,$0,$L358
	.set	at
	addiu	$19,$19,10

$L363:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$18
	lw	$18,28($sp)
	j	P_SpawnPlayer
	addiu	$sp,$sp,48

$L364:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	G_DeathMatchSpawnPlayer
	addiu	$sp,$sp,48

$L365:
	addiu	$16,$16,1
	addu	$2,$2,$17
	andi	$3,$16,0xffff
	sll	$2,$2,1
	addu	$20,$20,$2
	addiu	$17,$17,1
	srl	$2,$3,8
	move	$4,$19
	sb	$16,6($20)
	jal	P_SpawnPlayer
	sb	$2,7($20)

	lw	$31,44($sp)
	andi	$2,$17,0xffff
	srl	$2,$2,8
	sb	$17,6($20)
	lw	$21,40($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sb	$2,7($20)
	lw	$20,36($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	G_DoReborn
	.size	G_DoReborn, .-G_DoReborn
	.align	2
	.globl	G_ScreenShot
	.set	nomips16
	.set	nomicromips
	.ent	G_ScreenShot
	.type	G_ScreenShot, @function
G_ScreenShot:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gameaction)
	li	$3,9			# 0x9
	jr	$31
	sw	$3,%lo(gameaction)($2)

	.set	macro
	.set	reorder
	.end	G_ScreenShot
	.size	G_ScreenShot, .-G_ScreenShot
	.align	2
	.globl	G_ExitLevel
	.set	nomips16
	.set	nomicromips
	.ent	G_ExitLevel
	.type	G_ExitLevel, @function
G_ExitLevel:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(secretexit)
	sw	$0,%lo(secretexit)($2)
	li	$3,6			# 0x6
	lui	$2,%hi(gameaction)
	jr	$31
	sw	$3,%lo(gameaction)($2)

	.set	macro
	.set	reorder
	.end	G_ExitLevel
	.size	G_ExitLevel, .-G_ExitLevel
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"map31\000"
	.text
	.align	2
	.globl	G_SecretExitLevel
	.set	nomips16
	.set	nomicromips
	.ent	G_SecretExitLevel
	.type	G_SecretExitLevel, @function
G_SecretExitLevel:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L375
	.set	at
	li	$2,1			# 0x1

	lui	$3,%hi(secretexit)
	sw	$2,%lo(secretexit)($3)
	lui	$2,%hi(gameaction)
	li	$3,6			# 0x6
	jr	$31
	sw	$3,%lo(gameaction)($2)

$L375:
	lui	$4,%hi($LC7)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	W_CheckNumForName
	addiu	$4,$4,%lo($LC7)

	nor	$2,$0,$2
	lw	$31,20($sp)
	srl	$2,$2,31
	lui	$3,%hi(secretexit)
	sw	$2,%lo(secretexit)($3)
	lui	$2,%hi(gameaction)
	li	$3,6			# 0x6
	sw	$3,%lo(gameaction)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_SecretExitLevel
	.size	G_SecretExitLevel, .-G_SecretExitLevel
	.align	2
	.globl	G_DoCompleted
	.set	nomips16
	.set	nomicromips
	.ent	G_DoCompleted
	.type	G_DoCompleted, @function
G_DoCompleted:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,24($sp)
	lui	$18,%hi(playeringame)
	sw	$20,32($sp)
	addiu	$18,$18,%lo(playeringame)
	lui	$20,%hi(gameaction)
	sw	$19,28($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$0,%lo(gameaction)($20)
	move	$17,$18
	move	$16,$0
	li	$19,4			# 0x4
$L378:
	lw	$2,0($17)
	bne	$2,$0,$L426
	addiu	$17,$17,4

	addiu	$16,$16,1
$L431:
	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L378
	.set	at
	lui	$21,%hi(automapactive)

	lw	$2,%lo(automapactive)($21)
	bne	$2,$0,$L427
	nop

	lui	$2,%hi(gamemode)
$L432:
	lw	$4,%lo(gamemode)($2)
	lui	$3,%hi(gamemap)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L380
	.set	at
	lw	$3,%lo(gamemap)($3)

	lui	$2,%hi(gameversion)
	lw	$4,%lo(gameversion)($2)
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L428
	.set	at
	nop

	li	$4,8			# 0x8
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L433
	.set	at
	lw	$31,44($sp)

	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L434
	.set	at
	lui	$2,%hi(consoleplayer)

$L435:
	lw	$5,%lo(consoleplayer)($2)
	lui	$2,%hi(players)
	sll	$4,$5,3
	addu	$4,$4,$5
	sll	$4,$4,5
	addiu	$2,$2,%lo(players)
	addu	$2,$2,$4
	lui	$6,%hi(gameepisode)
	lw	$11,284($2)
	lw	$6,%lo(gameepisode)($6)
	lui	$2,%hi(secretexit)
	lui	$20,%hi(wminfo)
	lw	$4,%lo(secretexit)($2)
	addiu	$12,$3,-1
	addiu	$2,$20,%lo(wminfo)
	addiu	$7,$6,-1
	lui	$8,%hi(totalkills)
	lui	$9,%hi(totalitems)
	lui	$10,%hi(totalsecret)
	lw	$8,%lo(totalkills)($8)
	lw	$9,%lo(totalitems)($9)
	lw	$10,%lo(totalsecret)($10)
	sw	$11,4($2)
	sw	$7,%lo(wminfo)($20)
	bne	$4,$0,$L391
	sw	$12,8($2)

	move	$7,$3
	slt	$4,$6,4
	sw	$7,12($2)
	sw	$8,16($2)
	sw	$9,20($2)
	sw	$10,24($2)
	bne	$4,$0,$L405
	sw	$0,28($2)

$L406:
	lui	$4,%hi(cpars)
	sll	$3,$3,2
	addiu	$4,$4,%lo(cpars)
$L424:
	addu	$3,$3,$4
	lw	$4,0($3)
	sll	$3,$4,3
	addu	$3,$3,$4
	sll	$3,$3,2
	subu	$3,$3,$4
$L407:
	lui	$16,%hi(wminfo+60)
	lui	$17,%hi(players+104)
	sw	$3,32($2)
	sw	$5,36($2)
	addiu	$16,$16,%lo(wminfo+60)
	addiu	$17,$17,%lo(players+104)
	addiu	$19,$2,220
	lui	$22,%hi(leveltime)
$L408:
	lw	$5,108($17)
	lw	$4,112($17)
	lw	$3,116($17)
	lw	$6,0($18)
	lw	$2,%lo(leveltime)($22)
	sw	$6,-20($16)
	sw	$5,-16($16)
	sw	$4,-12($16)
	sw	$3,-8($16)
	sw	$2,-4($16)
	move	$5,$17
	move	$4,$16
	li	$6,16			# 0x10
	jal	memcpy
	addiu	$16,$16,40

	addiu	$18,$18,4
	.set	noat
	xor	$1,$19,$16
	bne	$1,$0,$L408
	.set	at
	addiu	$17,$17,288

	lui	$2,%hi(gamestate)
	li	$3,1			# 0x1
	addiu	$4,$20,%lo(wminfo)
	sw	$3,%lo(gamestate)($2)
	lui	$2,%hi(viewactive)
	sw	$0,%lo(automapactive)($21)
	jal	StatCopy
	sw	$0,%lo(viewactive)($2)

	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addiu	$4,$20,%lo(wminfo)
	lw	$20,32($sp)
	j	WI_Start
	addiu	$sp,$sp,48

$L426:
	jal	G_PlayerFinishLevel
	move	$4,$16

	b	$L431
	addiu	$16,$16,1

$L428:
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L384
	.set	at
	li	$2,8			# 0x8

	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L433
	.set	at
	lw	$31,44($sp)

	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L435
	.set	at
	lui	$2,%hi(consoleplayer)

$L434:
	lw	$5,%lo(consoleplayer)($2)
	lui	$2,%hi(players)
	sll	$3,$5,3
	addu	$3,$3,$5
	addiu	$2,$2,%lo(players)
	li	$4,1			# 0x1
	sll	$3,$3,5
	lui	$6,%hi(gameepisode)
	sw	$4,284($2)
	lw	$6,%lo(gameepisode)($6)
	sw	$4,572($2)
	sw	$4,860($2)
	sw	$4,1148($2)
	addu	$2,$2,$3
	lw	$11,284($2)
	lui	$2,%hi(secretexit)
	lui	$20,%hi(wminfo)
	addiu	$7,$6,-1
	lw	$3,%lo(secretexit)($2)
	lui	$8,%hi(totalkills)
	addiu	$2,$20,%lo(wminfo)
	lui	$9,%hi(totalitems)
	lui	$10,%hi(totalsecret)
	sw	$7,%lo(wminfo)($20)
	li	$7,8			# 0x8
	lw	$8,%lo(totalkills)($8)
	lw	$9,%lo(totalitems)($9)
	lw	$10,%lo(totalsecret)($10)
	sw	$11,4($2)
	beq	$3,$0,$L429
	sw	$7,8($2)

	li	$3,9			# 0x9
$L391:
	li	$7,8			# 0x8
	slt	$4,$6,4
	sw	$7,12($2)
	sw	$8,16($2)
	sw	$9,20($2)
	sw	$10,24($2)
	beq	$4,$0,$L406
	sw	$0,28($2)

$L405:
	sll	$4,$6,2
	addu	$4,$4,$6
	sll	$4,$4,1
	addu	$3,$4,$3
	lui	$4,%hi(pars)
	sll	$3,$3,2
	b	$L424
	addiu	$4,$4,%lo(pars)

$L384:
	lw	$31,44($sp)
$L433:
	li	$2,7			# 0x7
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$2,%lo(gameaction)($20)
	lw	$20,32($sp)
	jr	$31
	addiu	$sp,$sp,48

$L380:
	lui	$2,%hi(consoleplayer)
	lw	$5,%lo(consoleplayer)($2)
	lui	$2,%hi(players)
	sll	$4,$5,3
	addu	$4,$4,$5
	sll	$4,$4,5
	addiu	$2,$2,%lo(players)
	addu	$2,$2,$4
	lui	$6,%hi(gameepisode)
	lw	$8,284($2)
	lui	$9,%hi(totalkills)
	lui	$2,%hi(secretexit)
	lw	$6,%lo(gameepisode)($6)
	lui	$20,%hi(wminfo)
	lw	$7,%lo(secretexit)($2)
	lw	$11,%lo(totalkills)($9)
	lui	$9,%hi(totalitems)
	addiu	$2,$20,%lo(wminfo)
	lw	$10,%lo(totalitems)($9)
	addiu	$6,$6,-1
	addiu	$4,$3,-1
	lui	$9,%hi(totalsecret)
	lw	$9,%lo(totalsecret)($9)
	sw	$8,4($2)
	sw	$6,%lo(wminfo)($20)
	beq	$7,$0,$L430
	sw	$4,8($2)

	li	$6,15			# 0xf
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L393
	.set	at
	li	$6,31			# 0x1f

	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L395
	.set	at
	nop

$L423:
	sw	$3,12($2)
$L395:
	lui	$3,%hi(cpars)
	addiu	$3,$3,%lo(cpars)
	sll	$4,$4,2
	addu	$4,$4,$3
	lw	$4,0($4)
	sw	$11,16($2)
	sll	$3,$4,3
	addu	$3,$3,$4
	sll	$3,$3,2
	sw	$10,20($2)
	sw	$9,24($2)
	sw	$0,28($2)
	b	$L407
	subu	$3,$3,$4

$L427:
	jal	AM_Stop
	nop

	b	$L432
	lui	$2,%hi(gamemode)

$L430:
	addiu	$6,$3,-31
	sltu	$6,$6,2
	beq	$6,$0,$L423
	nop

	b	$L423
	li	$3,15			# 0xf

$L429:
	li	$3,3			# 0x3
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L398
	.set	at
	slt	$7,$6,4

	beq	$7,$0,$L399
	nop

	.set	noat
	xor	$1,$6,$4
	beq	$1,$0,$L425
	.set	at
	nop

	li	$3,2			# 0x2
	.set	noat
	xor	$1,$6,$3
	bne	$1,$0,$L421
	.set	at
	nop

	li	$3,5			# 0x5
	b	$L421
	sw	$3,12($2)

$L398:
	li	$3,6			# 0x6
$L425:
	sw	$3,12($2)
$L421:
	sw	$8,16($2)
	sw	$9,20($2)
	sw	$10,24($2)
	sw	$0,28($2)
	b	$L405
	li	$3,9			# 0x9

$L399:
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$6,$3
	bne	$1,$0,$L404
	.set	at
	nop

	li	$3,2			# 0x2
	sw	$3,12($2)
$L404:
	sw	$8,16($2)
	sw	$9,20($2)
	sw	$10,24($2)
	sw	$0,28($2)
	b	$L406
	li	$3,9			# 0x9

$L393:
	li	$3,30			# 0x1e
	b	$L395
	sw	$3,12($2)

	.set	macro
	.set	reorder
	.end	G_DoCompleted
	.size	G_DoCompleted, .-G_DoCompleted
	.align	2
	.globl	G_WorldDone
	.set	nomips16
	.set	nomicromips
	.ent	G_WorldDone
	.type	G_WorldDone, @function
G_WorldDone:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(secretexit)
	lw	$4,%lo(secretexit)($2)
	li	$3,8			# 0x8
	lui	$2,%hi(gameaction)
	beq	$4,$0,$L437
	sw	$3,%lo(gameaction)($2)

	lui	$2,%hi(consoleplayer)
	lw	$2,%lo(consoleplayer)($2)
	sll	$3,$2,3
	addu	$3,$3,$2
	lui	$2,%hi(players)
	sll	$3,$3,5
	addiu	$2,$2,%lo(players)
	addu	$2,$2,$3
	li	$3,1			# 0x1
	sw	$3,284($2)
$L437:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L449
	.set	at
	lui	$2,%hi(gamemap)

$L450:
	jr	$31
	nop

$L449:
	lw	$3,%lo(gamemap)($2)
	sltu	$2,$3,32
	beq	$2,$0,$L450
	li	$2,1			# 0x1

	sll	$2,$2,$3
	li	$3,1074790400			# 0x40100000
	addiu	$3,$3,2112
	and	$3,$2,$3
	bne	$3,$0,$L439
	li	$3,-2147483648			# 0xffffffff80000000

	ori	$3,$3,0x8000
	and	$2,$2,$3
	beq	$2,$0,$L450
	nop

	beq	$4,$0,$L450
	nop

$L439:
	j	F_StartFinale
	nop

	.set	macro
	.set	reorder
	.end	G_WorldDone
	.size	G_WorldDone, .-G_WorldDone
	.align	2
	.globl	G_DoWorldDone
	.set	nomips16
	.set	nomicromips
	.ent	G_DoWorldDone
	.type	G_DoWorldDone, @function
G_DoWorldDone:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(wminfo+12)
	lw	$2,%lo(wminfo+12)($2)
	lui	$3,%hi(gamestate)
	addiu	$sp,$sp,-24
	addiu	$2,$2,1
	sw	$0,%lo(gamestate)($3)
	lui	$3,%hi(gamemap)
	sw	$2,%lo(gamemap)($3)
	sw	$31,20($sp)
	jal	G_DoLoadLevel
	nop

	lw	$31,20($sp)
	lui	$2,%hi(gameaction)
	sw	$0,%lo(gameaction)($2)
	li	$3,1			# 0x1
	lui	$2,%hi(viewactive)
	sw	$3,%lo(viewactive)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_DoWorldDone
	.size	G_DoWorldDone, .-G_DoWorldDone
	.align	2
	.globl	G_LoadGame
	.set	nomips16
	.set	nomicromips
	.ent	G_LoadGame
	.type	G_LoadGame, @function
G_LoadGame:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$5,$4
	lui	$4,%hi(savename)
	addiu	$sp,$sp,-24
	li	$6,256			# 0x100
	sw	$31,20($sp)
	jal	M_StringCopy
	addiu	$4,$4,%lo(savename)

	lw	$31,20($sp)
	lui	$2,%hi(gameaction)
	li	$3,3			# 0x3
	sw	$3,%lo(gameaction)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_LoadGame
	.size	G_LoadGame, .-G_LoadGame
	.align	2
	.globl	G_SaveGame
	.set	nomips16
	.set	nomicromips
	.ent	G_SaveGame
	.type	G_SaveGame, @function
G_SaveGame:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$3,$4
	lui	$4,%hi(savedescription)
	addiu	$sp,$sp,-24
	lui	$2,%hi(savegameslot)
	li	$6,32			# 0x20
	sw	$3,%lo(savegameslot)($2)
	sw	$31,20($sp)
	jal	M_StringCopy
	addiu	$4,$4,%lo(savedescription)

	lw	$31,20($sp)
	lui	$2,%hi(sendsave)
	li	$3,1			# 0x1
	sw	$3,%lo(sendsave)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_SaveGame
	.size	G_SaveGame, .-G_SaveGame
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"wb\000"
	.align	2
$LC9:
	.ascii	"recovery.dsg\000"
	.align	2
$LC10:
	.ascii	"Failed to open either '%s' or '%s' to write savegame.\000"
	.align	2
$LC11:
	.ascii	"Savegame buffer overrun\000"
	.align	2
$LC12:
	.ascii	"Failed to open savegame file '%s' for writing.\012But yo"
	.ascii	"ur game has been saved to '%s' for recovery.\000"
	.align	2
$LC13:
	.ascii	"\000"
	.align	2
$LC14:
	.ascii	"game saved.\000"
	.text
	.align	2
	.globl	G_DoSaveGame
	.set	nomips16
	.set	nomicromips
	.ent	G_DoSaveGame
	.type	G_DoSaveGame, @function
G_DoSaveGame:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	jal	P_TempSaveGameFile
	sw	$20,32($sp)

	lui	$3,%hi(savegameslot)
	lw	$4,%lo(savegameslot)($3)
	move	$16,$2
	jal	P_SaveGameFile
	lui	$19,%hi($LC8)

	addiu	$5,$19,%lo($LC8)
	move	$4,$16
	move	$17,$2
	jal	fopen
	lui	$18,%hi(save_stream)

	beq	$2,$0,$L474
	sw	$2,%lo(save_stream)($18)

	lui	$19,%hi(savedescription)
	lui	$2,%hi(savegame_error)
	addiu	$4,$19,%lo(savedescription)
	jal	P_WriteSaveGameHeader
	sw	$0,%lo(savegame_error)($2)

	jal	P_ArchivePlayers
	nop

	jal	P_ArchiveWorld
	nop

	jal	P_ArchiveThinkers
	nop

	jal	P_ArchiveSpecials
	nop

	jal	P_WriteSaveGameEOF
	nop

	lui	$2,%hi(vanilla_savegame_limit)
	lw	$2,%lo(vanilla_savegame_limit)($2)
	bne	$2,$0,$L475
	nop

$L473:
	jal	fclose
	lw	$4,%lo(save_stream)($18)

$L461:
	jal	remove
	move	$4,$17

	move	$5,$17
	jal	rename
	move	$4,$16

	lui	$5,%hi($LC13)
	addiu	$4,$19,%lo(savedescription)
	lui	$2,%hi(gameaction)
	li	$6,32			# 0x20
	addiu	$5,$5,%lo($LC13)
	jal	M_StringCopy
	sw	$0,%lo(gameaction)($2)

	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	lw	$31,36($sp)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	lui	$3,%hi($LC14)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addiu	$3,$3,%lo($LC14)
	sw	$3,224($2)
	j	R_FillBackScreen
	addiu	$sp,$sp,40

$L475:
	jal	ftell
	lw	$4,%lo(save_stream)($18)

	li	$3,131072			# 0x20000
	ori	$3,$3,0xc001
	slt	$2,$2,$3
	bne	$2,$0,$L473
	nop

	lui	$4,%hi($LC11)
	jal	I_Error
	addiu	$4,$4,%lo($LC11)

	b	$L473
	nop

$L474:
	lui	$4,%hi($LC9)
	jal	M_TempFile
	addiu	$4,$4,%lo($LC9)

	move	$4,$2
	addiu	$5,$19,%lo($LC8)
	jal	fopen
	move	$20,$2

	beq	$2,$0,$L476
	sw	$2,%lo(save_stream)($18)

	lui	$19,%hi(savedescription)
$L478:
	lui	$2,%hi(savegame_error)
	addiu	$4,$19,%lo(savedescription)
	jal	P_WriteSaveGameHeader
	sw	$0,%lo(savegame_error)($2)

	jal	P_ArchivePlayers
	nop

	jal	P_ArchiveWorld
	nop

	jal	P_ArchiveThinkers
	nop

	jal	P_ArchiveSpecials
	nop

	jal	P_WriteSaveGameEOF
	nop

	lui	$2,%hi(vanilla_savegame_limit)
	lw	$2,%lo(vanilla_savegame_limit)($2)
	bne	$2,$0,$L477
	nop

$L460:
	jal	fclose
	lw	$4,%lo(save_stream)($18)

	beq	$20,$0,$L461
	move	$6,$20

	lui	$4,%hi($LC12)
	move	$5,$16
	jal	I_Error
	addiu	$4,$4,%lo($LC12)

	b	$L461
	nop

$L476:
	lui	$4,%hi($LC10)
	move	$6,$20
	move	$5,$16
	jal	I_Error
	addiu	$4,$4,%lo($LC10)

	b	$L478
	lui	$19,%hi(savedescription)

$L477:
	jal	ftell
	lw	$4,%lo(save_stream)($18)

	li	$3,131072			# 0x20000
	ori	$3,$3,0xc001
	slt	$2,$2,$3
	bne	$2,$0,$L460
	lui	$4,%hi($LC11)

	jal	I_Error
	addiu	$4,$4,%lo($LC11)

	b	$L460
	nop

	.set	macro
	.set	reorder
	.end	G_DoSaveGame
	.size	G_DoSaveGame, .-G_DoSaveGame
	.align	2
	.globl	G_DeferedInitNew
	.set	nomips16
	.set	nomicromips
	.ent	G_DeferedInitNew
	.type	G_DeferedInitNew, @function
G_DeferedInitNew:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(d_skill)
	sw	$4,%lo(d_skill)($2)
	lui	$2,%hi(d_episode)
	sw	$5,%lo(d_episode)($2)
	lui	$2,%hi(d_map)
	sw	$6,%lo(d_map)($2)
	li	$3,2			# 0x2
	lui	$2,%hi(gameaction)
	jr	$31
	sw	$3,%lo(gameaction)($2)

	.set	macro
	.set	reorder
	.end	G_DeferedInitNew
	.size	G_DeferedInitNew, .-G_DeferedInitNew
	.section	.rodata.str1.4
	.align	2
$LC15:
	.ascii	"SKY4\000"
	.text
	.align	2
	.globl	G_InitNew
	.set	nomips16
	.set	nomicromips
	.ent	G_InitNew
	.type	G_InitNew, @function
G_InitNew:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$20,36($sp)
	lui	$20,%hi(paused)
	lw	$2,%lo(paused)($20)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$19,32($sp)
	move	$17,$4
	move	$16,$5
	bne	$2,$0,$L522
	move	$18,$6

	lui	$2,%hi(gameversion)
$L527:
	lw	$2,%lo(gameversion)($2)
	slt	$3,$17,5
	li	$19,4			# 0x4
	sltu	$2,$2,6
	bne	$2,$0,$L482
	movn	$19,$17,$3

	beq	$16,$0,$L498
	slt	$2,$16,2

$L529:
	bne	$2,$0,$L520
	nop

$L483:
	lui	$21,%hi(gamemode)
	lw	$3,%lo(gamemode)($21)
	li	$2,1			# 0x1
	blez	$18,$L501
	movz	$16,$2,$3

$L524:
	slt	$2,$18,10
	bne	$2,$0,$L486
	lw	$2,%lo(gamemode)($21)

	li	$3,9			# 0x9
	xori	$2,$2,0x2
	movn	$18,$3,$2
$L486:
	jal	M_ClearRandom
	slt	$17,$17,4

	beq	$17,$0,$L528
	lui	$2,%hi(fastparm)

	lui	$2,%hi(respawnparm)
$L530:
	lw	$2,%lo(respawnparm)($2)
	lui	$3,%hi(fastparm)
	beq	$2,$0,$L488
	lw	$3,%lo(fastparm)($3)

	lui	$2,%hi(respawnmonsters)
	li	$4,1			# 0x1
	beq	$3,$0,$L489
	sw	$4,%lo(respawnmonsters)($2)

$L521:
	lui	$5,%hi(gameskill)
$L491:
	lui	$2,%hi(states+13364)
	lui	$4,%hi(states+13728)
	addiu	$2,$2,%lo(states+13364)
	addiu	$4,$4,%lo(states+13728)
$L490:
	lw	$3,0($2)
	addiu	$2,$2,28
	sra	$3,$3,1
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L490
	.set	at
	sw	$3,-28($2)

	lui	$2,%hi(mobjinfo)
	addiu	$2,$2,%lo(mobjinfo)
	li	$3,1310720			# 0x140000
	sw	$3,1532($2)
	sw	$3,3004($2)
	sw	$3,2912($2)
$L493:
	lui	$2,%hi(players)
$L526:
	addiu	$2,$2,%lo(players)
$L532:
	li	$3,2			# 0x2
	li	$4,1			# 0x1
	sw	$3,4($2)
	sw	$3,292($2)
	sw	$3,580($2)
	sw	$3,868($2)
	lui	$2,%hi(usergame)
	sw	$4,%lo(usergame)($2)
	lui	$2,%hi(demoplayback)
	sw	$0,%lo(demoplayback)($2)
	lui	$2,%hi(automapactive)
	sw	$0,%lo(automapactive)($2)
	lui	$2,%hi(viewactive)
	sw	$4,%lo(viewactive)($2)
	lw	$6,%lo(gamemode)($21)
	lui	$2,%hi(gameepisode)
	sw	$16,%lo(gameepisode)($2)
	lui	$2,%hi(gamemap)
	sw	$0,%lo(paused)($20)
	sw	$18,%lo(gamemap)($2)
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L523
	.set	at
	sw	$19,%lo(gameskill)($5)

	li	$2,3			# 0x3
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L504
	.set	at
	li	$2,4			# 0x4

	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L505
	.set	at
	nop

	.set	noat
	xor	$1,$16,$3
	beq	$1,$0,$L533
	.set	at
	lui	$4,%hi($LC1)

	lui	$4,%hi($LC0)
$L531:
	jal	R_TextureNumForName
	addiu	$4,$4,%lo($LC0)

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$3,%hi(skytexture)
	addiu	$sp,$sp,48
	j	G_DoLoadLevel
	sw	$2,%lo(skytexture)($3)

$L482:
	blez	$16,$L499
	slt	$2,$16,4

	bne	$2,$0,$L529
	slt	$2,$16,2

	b	$L483
	li	$16,3			# 0x3

$L498:
	b	$L483
	li	$16,4			# 0x4

$L499:
	li	$16,1			# 0x1
$L520:
	bgtz	$18,$L524
	lui	$21,%hi(gamemode)

$L501:
	slt	$17,$17,4
	jal	M_ClearRandom
	li	$18,1			# 0x1

	bne	$17,$0,$L530
	lui	$2,%hi(respawnparm)

	lui	$2,%hi(fastparm)
$L528:
	lw	$2,%lo(fastparm)($2)
	lui	$3,%hi(respawnmonsters)
	li	$4,1			# 0x1
	bne	$2,$0,$L521
	sw	$4,%lo(respawnmonsters)($3)

	lui	$5,%hi(gameskill)
	lw	$3,%lo(gameskill)($5)
	li	$2,4			# 0x4
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L491
	.set	at
	lui	$2,%hi(players)

	b	$L532
	addiu	$2,$2,%lo(players)

$L523:
	slt	$2,$18,12
	bne	$2,$0,$L531
	lui	$4,%hi($LC0)

	slt	$18,$18,21
	beq	$18,$0,$L504
	nop

	lui	$4,%hi($LC1)
$L533:
	jal	R_TextureNumForName
	addiu	$4,$4,%lo($LC1)

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$3,%hi(skytexture)
	addiu	$sp,$sp,48
	j	G_DoLoadLevel
	sw	$2,%lo(skytexture)($3)

$L488:
	lui	$2,%hi(respawnmonsters)
	bne	$3,$0,$L521
	sw	$0,%lo(respawnmonsters)($2)

$L489:
	lui	$5,%hi(gameskill)
	lw	$3,%lo(gameskill)($5)
	li	$2,4			# 0x4
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L526
	.set	at
	lui	$2,%hi(players)

	lui	$2,%hi(states+13364)
	lui	$4,%hi(states+13728)
	addiu	$2,$2,%lo(states+13364)
	addiu	$4,$4,%lo(states+13728)
$L495:
	lw	$3,0($2)
	addiu	$2,$2,28
	sll	$3,$3,1
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L495
	.set	at
	sw	$3,-28($2)

	lui	$2,%hi(mobjinfo)
	addiu	$2,$2,%lo(mobjinfo)
	li	$3,655360			# 0xa0000
	li	$4,983040			# 0xf0000
	sw	$4,1532($2)
	sw	$3,3004($2)
	b	$L493
	sw	$3,2912($2)

$L522:
	jal	S_ResumeSound
	sw	$0,%lo(paused)($20)

	b	$L527
	lui	$2,%hi(gameversion)

$L504:
	lui	$4,%hi($LC2)
	jal	R_TextureNumForName
	addiu	$4,$4,%lo($LC2)

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$3,%hi(skytexture)
	addiu	$sp,$sp,48
	j	G_DoLoadLevel
	sw	$2,%lo(skytexture)($3)

$L505:
	lui	$4,%hi($LC15)
	jal	R_TextureNumForName
	addiu	$4,$4,%lo($LC15)

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$3,%hi(skytexture)
	addiu	$sp,$sp,48
	j	G_DoLoadLevel
	sw	$2,%lo(skytexture)($3)

	.set	macro
	.set	reorder
	.end	G_InitNew
	.size	G_InitNew, .-G_InitNew
	.section	.rodata.str1.4
	.align	2
$LC16:
	.ascii	"rb\000"
	.align	2
$LC17:
	.ascii	"Bad savegame\000"
	.text
	.align	2
	.globl	G_DoLoadGame
	.set	nomips16
	.set	nomicromips
	.ent	G_DoLoadGame
	.type	G_DoLoadGame, @function
G_DoLoadGame:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi($LC16)
	lui	$4,%hi(savename)
	addiu	$sp,$sp,-32
	lui	$2,%hi(gameaction)
	addiu	$5,$5,%lo($LC16)
	addiu	$4,$4,%lo(savename)
	sw	$0,%lo(gameaction)($2)
	sw	$16,16($sp)
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	jal	fopen
	lui	$16,%hi(save_stream)

	beq	$2,$0,$L534
	sw	$2,%lo(save_stream)($16)

	lui	$2,%hi(savegame_error)
	jal	P_ReadSaveGameHeader
	sw	$0,%lo(savegame_error)($2)

	beq	$2,$0,$L543
	lui	$2,%hi(gamemap)

	lw	$6,%lo(gamemap)($2)
	lui	$2,%hi(gameepisode)
	lw	$5,%lo(gameepisode)($2)
	lui	$17,%hi(leveltime)
	lui	$2,%hi(gameskill)
	lw	$4,%lo(gameskill)($2)
	jal	G_InitNew
	lw	$18,%lo(leveltime)($17)

	jal	P_UnArchivePlayers
	sw	$18,%lo(leveltime)($17)

	jal	P_UnArchiveWorld
	nop

	jal	P_UnArchiveThinkers
	nop

	jal	P_UnArchiveSpecials
	nop

	jal	P_ReadSaveGameEOF
	nop

	beq	$2,$0,$L544
	lui	$4,%hi($LC17)

	jal	fclose
	lw	$4,%lo(save_stream)($16)

	lui	$2,%hi(setsizeneeded)
	lw	$2,%lo(setsizeneeded)($2)
	bne	$2,$0,$L545
	lw	$31,28($sp)

$L546:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	R_FillBackScreen
	addiu	$sp,$sp,32

$L543:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$4,%lo(save_stream)($16)
	lw	$16,16($sp)
	j	fclose
	addiu	$sp,$sp,32

$L534:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L544:
	jal	I_Error
	addiu	$4,$4,%lo($LC17)

	jal	fclose
	lw	$4,%lo(save_stream)($16)

	lui	$2,%hi(setsizeneeded)
	lw	$2,%lo(setsizeneeded)($2)
	beq	$2,$0,$L546
	lw	$31,28($sp)

$L545:
	jal	R_ExecuteSetViewSize
	nop

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	R_FillBackScreen
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	G_DoLoadGame
	.size	G_DoLoadGame, .-G_DoLoadGame
	.align	2
	.globl	G_DoNewGame
	.set	nomips16
	.set	nomicromips
	.ent	G_DoNewGame
	.type	G_DoNewGame, @function
G_DoNewGame:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(d_map)
	lw	$6,%lo(d_map)($2)
	lui	$2,%hi(d_episode)
	lw	$5,%lo(d_episode)($2)
	lui	$2,%hi(d_skill)
	lw	$4,%lo(d_skill)($2)
	lui	$2,%hi(playeringame)
	addiu	$sp,$sp,-24
	addiu	$2,$2,%lo(playeringame)
	lui	$3,%hi(demoplayback)
	sw	$31,20($sp)
	sw	$0,12($2)
	sw	$0,8($2)
	sw	$0,4($2)
	lui	$2,%hi(respawnparm)
	sw	$0,%lo(demoplayback)($3)
	sw	$0,%lo(respawnparm)($2)
	lui	$3,%hi(netdemo)
	lui	$2,%hi(fastparm)
	sw	$0,%lo(netdemo)($3)
	sw	$0,%lo(fastparm)($2)
	lui	$3,%hi(netgame)
	lui	$2,%hi(nomonsters)
	sw	$0,%lo(netgame)($3)
	sw	$0,%lo(nomonsters)($2)
	lui	$3,%hi(deathmatch)
	lui	$2,%hi(consoleplayer)
	sw	$0,%lo(consoleplayer)($2)
	jal	G_InitNew
	sw	$0,%lo(deathmatch)($3)

	lw	$31,20($sp)
	lui	$2,%hi(gameaction)
	sw	$0,%lo(gameaction)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_DoNewGame
	.size	G_DoNewGame, .-G_DoNewGame
	.section	.rodata.str1.4
	.align	2
$LC18:
	.ascii	"%s.lmp\000"
	.align	2
$LC19:
	.ascii	"-maxdemo\000"
	.text
	.align	2
	.globl	G_RecordDemo
	.set	nomips16
	.set	nomicromips
	.ent	G_RecordDemo
	.type	G_RecordDemo, @function
G_RecordDemo:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(usergame)
	sw	$0,%lo(usergame)($2)
	sw	$31,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	jal	strlen
	move	$17,$4

	addiu	$16,$2,5
	move	$4,$16
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	lui	$6,%hi($LC18)
	move	$5,$16
	move	$4,$2
	lui	$3,%hi(demoname)
	move	$7,$17
	addiu	$6,$6,%lo($LC18)
	jal	M_snprintf
	sw	$2,%lo(demoname)($3)

	lui	$4,%hi($LC19)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC19)

	bne	$2,$0,$L553
	lui	$3,%hi(myargv)

	li	$16,131072			# 0x20000
	li	$4,131072			# 0x20000
$L550:
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	lui	$3,%hi(demobuffer)
	addu	$16,$2,$16
	lw	$31,28($sp)
	sw	$2,%lo(demobuffer)($3)
	lui	$2,%hi(demoend)
	sw	$16,%lo(demoend)($2)
	li	$3,1			# 0x1
	lui	$2,%hi(demorecording)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$3,%lo(demorecording)($2)
	jr	$31
	addiu	$sp,$sp,32

$L553:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	atoi
	lw	$4,0($2)

	sll	$4,$2,10
	b	$L550
	move	$16,$4

	.set	macro
	.set	reorder
	.end	G_RecordDemo
	.size	G_RecordDemo, .-G_RecordDemo
	.section	.rodata.str1.4
	.align	2
$LC20:
	.ascii	"Doom 1.2 does not have a version code!\000"
	.text
	.align	2
	.globl	G_VanillaVersionCode
	.set	nomips16
	.set	nomicromips
	.ent	G_VanillaVersionCode
	.type	G_VanillaVersionCode, @function
G_VanillaVersionCode:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L559
	.set	at
	sltu	$3,$2,3

	beq	$3,$0,$L556
	li	$4,109			# 0x6d

	beq	$2,$0,$L557
	li	$2,106			# 0x6a

	jr	$31
	nop

$L556:
	xori	$3,$2,0x3
	li	$2,108			# 0x6c
	jr	$31
	movn	$2,$4,$3

$L559:
	jr	$31
	li	$2,107			# 0x6b

$L557:
	lui	$4,%hi($LC20)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	I_Error
	addiu	$4,$4,%lo($LC20)

	lw	$31,20($sp)
	li	$2,106			# 0x6a
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_VanillaVersionCode
	.size	G_VanillaVersionCode, .-G_VanillaVersionCode
	.section	.rodata.str1.4
	.align	2
$LC21:
	.ascii	"-longtics\000"
	.text
	.align	2
	.globl	G_BeginRecording
	.set	nomips16
	.set	nomicromips
	.ent	G_BeginRecording
	.type	G_BeginRecording, @function
G_BeginRecording:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC21)
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC21)

	lui	$3,%hi(demobuffer)
	lui	$4,%hi(longtics)
	lw	$3,%lo(demobuffer)($3)
	sltu	$6,$0,$2
	sltu	$5,$2,1
	lui	$16,%hi(demo_p)
	sw	$6,%lo(longtics)($4)
	lui	$4,%hi(lowres_turn)
	sw	$5,%lo(lowres_turn)($4)
	beq	$2,$0,$L566
	sw	$3,%lo(demo_p)($16)

	addiu	$2,$3,1
	sw	$2,%lo(demo_p)($16)
	li	$2,111			# 0x6f
	sb	$2,0($3)
$L567:
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(gameskill)
	lw	$3,%lo(gameskill)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(gameepisode)
	lw	$3,%lo(gameepisode)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(gamemap)
	lw	$3,%lo(gamemap)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(deathmatch)
	lw	$3,%lo(deathmatch)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(respawnparm)
	lw	$3,%lo(respawnparm)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(fastparm)
	lw	$3,%lo(fastparm)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$2,%lo(demo_p)($16)
	lui	$3,%hi(nomonsters)
	lw	$3,%lo(nomonsters)($3)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$3,%lo(demo_p)($16)
	lui	$2,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($2)
	lui	$2,%hi(playeringame)
	addiu	$5,$3,1
	addiu	$2,$2,%lo(playeringame)
	sw	$5,%lo(demo_p)($16)
	addiu	$6,$2,16
	sb	$4,0($3)
$L571:
	lw	$3,%lo(demo_p)($16)
	lw	$4,0($2)
	addiu	$5,$3,1
	addiu	$2,$2,4
	sw	$5,%lo(demo_p)($16)
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L571
	.set	at
	sb	$4,0($3)

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L566:
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	li	$4,2			# 0x2
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L568
	.set	at
	li	$4,107			# 0x6b

	sltu	$4,$2,3
	beq	$4,$0,$L569
	li	$5,109			# 0x6d

	beq	$2,$0,$L570
	nop

	b	$L568
	li	$4,106			# 0x6a

$L569:
	xori	$2,$2,0x3
	li	$4,108			# 0x6c
	movn	$4,$5,$2
$L568:
	addiu	$2,$3,1
	sw	$2,%lo(demo_p)($16)
	b	$L567
	sb	$4,0($3)

$L570:
	lui	$4,%hi($LC20)
	jal	I_Error
	addiu	$4,$4,%lo($LC20)

	lw	$3,%lo(demo_p)($16)
	b	$L568
	li	$4,106			# 0x6a

	.set	macro
	.set	reorder
	.end	G_BeginRecording
	.size	G_BeginRecording, .-G_BeginRecording
	.align	2
	.globl	G_DeferedPlayDemo
	.set	nomips16
	.set	nomicromips
	.ent	G_DeferedPlayDemo
	.type	G_DeferedPlayDemo, @function
G_DeferedPlayDemo:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(defdemoname)
	sw	$4,%lo(defdemoname)($2)
	li	$3,5			# 0x5
	lui	$2,%hi(gameaction)
	jr	$31
	sw	$3,%lo(gameaction)($2)

	.set	macro
	.set	reorder
	.end	G_DeferedPlayDemo
	.size	G_DeferedPlayDemo, .-G_DeferedPlayDemo
	.section	.rodata.str1.4
	.align	2
$LC22:
	.ascii	"v1.0/v1.1/v1.2\000"
	.align	2
$LC23:
	.ascii	"%i.%i (unknown)\000"
	.align	2
$LC24:
	.ascii	"Demo is from a different game version!\012(read %i, shou"
	.ascii	"ld be %i)\012\012*** You may need to upgrade your versio"
	.ascii	"n of Doom to v1.9. ***\012    See: https://www.doomworld"
	.ascii	".com/classicdoom/info/patches.php\012    This appears to"
	.ascii	" be %s.\000"
	.align	2
$LC25:
	.ascii	"-solo-net\000"
	.align	2
$LC26:
	.ascii	"-netdemo\000"
	.text
	.align	2
	.globl	G_DoPlayDemo
	.set	nomips16
	.set	nomicromips
	.ent	G_DoPlayDemo
	.type	G_DoPlayDemo, @function
G_DoPlayDemo:
	.frame	$sp,56,$31		# vars= 8, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(defdemoname)
	lw	$4,%lo(defdemoname)($2)
	addiu	$sp,$sp,-56
	li	$5,1			# 0x1
	lui	$2,%hi(gameaction)
	sw	$0,%lo(gameaction)($2)
	sw	$18,44($sp)
	sw	$17,40($sp)
	sw	$16,36($sp)
	sw	$31,52($sp)
	sw	$19,48($sp)
	jal	W_CacheLumpName
	lui	$18,%hi(gameversion)

	addiu	$4,$2,1
	lui	$16,%hi(demo_p)
	lui	$5,%hi(demobuffer)
	lw	$3,%lo(gameversion)($18)
	sw	$4,%lo(demo_p)($16)
	sw	$2,%lo(demobuffer)($5)
	li	$4,2			# 0x2
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L596
	.set	at
	lbu	$17,0($2)

	sltu	$2,$3,3
	beq	$2,$0,$L580
	li	$2,108			# 0x6c

	beq	$3,$0,$L603
	lui	$4,%hi($LC20)

	li	$2,106			# 0x6a
$L606:
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L611
	.set	at
	li	$2,111			# 0x6f

$L604:
	lui	$2,%hi(longtics)
	b	$L584
	sw	$0,%lo(longtics)($2)

$L580:
	xori	$3,$3,0x3
	li	$4,109			# 0x6d
	movn	$2,$4,$3
$L579:
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L604
	.set	at
	li	$2,111			# 0x6f

$L611:
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L585
	.set	at
	lui	$2,%hi(longtics)

	li	$3,1			# 0x1
	sw	$3,%lo(longtics)($2)
$L584:
	lw	$3,%lo(demo_p)($16)
$L609:
	lui	$8,%hi(playeringame)
	addiu	$2,$3,1
	sw	$2,%lo(demo_p)($16)
	addiu	$2,$3,2
	lbu	$18,0($3)
	addiu	$4,$3,3
	sw	$2,%lo(demo_p)($16)
	lbu	$5,1($3)
	addiu	$2,$3,4
	sw	$4,%lo(demo_p)($16)
	lbu	$6,2($3)
	sw	$2,%lo(demo_p)($16)
	lbu	$11,3($3)
	lbu	$10,4($3)
	lui	$2,%hi(deathmatch)
	lbu	$9,5($3)
	sw	$11,%lo(deathmatch)($2)
	lui	$2,%hi(respawnparm)
	lbu	$7,6($3)
	sw	$10,%lo(respawnparm)($2)
	lui	$2,%hi(fastparm)
	lbu	$4,7($3)
	sw	$9,%lo(fastparm)($2)
	lui	$2,%hi(nomonsters)
	addiu	$8,$8,%lo(playeringame)
	sw	$7,%lo(nomonsters)($2)
	lui	$2,%hi(consoleplayer)
	sw	$4,%lo(consoleplayer)($2)
	addiu	$2,$3,9
	move	$4,$8
	addiu	$3,$3,13
$L592:
	sw	$2,%lo(demo_p)($16)
	lbu	$7,-1($2)
	addiu	$2,$2,1
	sw	$7,0($4)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L592
	.set	at
	addiu	$4,$4,4

	lw	$2,4($8)
	beq	$2,$0,$L593
	lui	$4,%hi($LC25)

$L595:
	li	$2,1			# 0x1
	lui	$3,%hi(netgame)
	sw	$2,%lo(netgame)($3)
	lui	$3,%hi(netdemo)
	sw	$2,%lo(netdemo)($3)
	lui	$17,%hi(precache)
$L610:
	move	$4,$18
	li	$16,1			# 0x1
	jal	G_InitNew
	sw	$0,%lo(precache)($17)

	jal	I_GetTime
	sw	$16,%lo(precache)($17)

	lui	$3,%hi(starttime)
	lw	$31,52($sp)
	sw	$2,%lo(starttime)($3)
	lui	$2,%hi(usergame)
	sw	$0,%lo(usergame)($2)
	lui	$2,%hi(demoplayback)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	sw	$16,%lo(demoplayback)($2)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,56

$L585:
	lw	$2,%lo(gameversion)($18)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L598
	.set	at
	sltu	$3,$2,3

	beq	$3,$0,$L587
	li	$3,109			# 0x6d

	beq	$2,$0,$L605
	lui	$4,%hi($LC20)

	b	$L586
	li	$18,106			# 0x6a

$L603:
	jal	I_Error
	addiu	$4,$4,%lo($LC20)

	b	$L606
	li	$2,106			# 0x6a

$L587:
	xori	$2,$2,0x3
	li	$18,108			# 0x6c
	movn	$18,$3,$2
$L586:
	addiu	$2,$17,-104
	sltu	$3,$2,6
	bne	$3,$0,$L607
	lui	$3,%hi(CSWTCH.405)

	sltu	$2,$17,5
	beq	$2,$0,$L608
	li	$7,1374355456			# 0x51eb0000

	lui	$7,%hi($LC22)
	addiu	$7,$7,%lo($LC22)
$L591:
	lui	$4,%hi($LC24)
	move	$6,$18
	move	$5,$17
	jal	printf
	addiu	$4,$4,%lo($LC24)

	b	$L609
	lw	$3,%lo(demo_p)($16)

$L593:
	addiu	$4,$4,%lo($LC25)
	sw	$6,28($sp)
	jal	M_CheckParm
	sw	$5,24($sp)

	lw	$5,24($sp)
	bgtz	$2,$L595
	lw	$6,28($sp)

	lui	$4,%hi($LC26)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC26)

	lw	$5,24($sp)
	bgtz	$2,$L595
	lw	$6,28($sp)

	b	$L610
	lui	$17,%hi(precache)

$L596:
	b	$L579
	li	$2,107			# 0x6b

$L607:
	sll	$2,$2,2
	addiu	$3,$3,%lo(CSWTCH.405)
	addu	$2,$2,$3
	b	$L591
	lw	$7,0($2)

$L605:
	jal	I_Error
	addiu	$4,$4,%lo($LC20)

	b	$L586
	li	$18,106			# 0x6a

$L598:
	b	$L586
	li	$18,107			# 0x6b

$L608:
	ori	$7,$7,0x851f
	multu	$17,$7
	lui	$19,%hi(resultbuf.0)
	mfhi	$7
	lui	$6,%hi($LC23)
	srl	$7,$7,5
	sll	$2,$7,1
	addu	$2,$2,$7
	sll	$2,$2,3
	addu	$2,$2,$7
	sll	$2,$2,2
	subu	$2,$17,$2
	sw	$2,16($sp)
	addiu	$6,$6,%lo($LC23)
	li	$5,16			# 0x10
	jal	M_snprintf
	addiu	$4,$19,%lo(resultbuf.0)

	b	$L591
	addiu	$7,$19,%lo(resultbuf.0)

	.set	macro
	.set	reorder
	.end	G_DoPlayDemo
	.size	G_DoPlayDemo, .-G_DoPlayDemo
	.section	.rodata.str1.4
	.align	2
$LC27:
	.ascii	"-nodraw\000"
	.text
	.align	2
	.globl	G_TimeDemo
	.set	nomips16
	.set	nomicromips
	.ent	G_TimeDemo
	.type	G_TimeDemo, @function
G_TimeDemo:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lui	$4,%hi($LC27)
	sw	$31,20($sp)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC27)

	lui	$4,%hi(nodrawers)
	li	$3,1			# 0x1
	sw	$2,%lo(nodrawers)($4)
	lui	$2,%hi(timingdemo)
	sw	$3,%lo(timingdemo)($2)
	lui	$2,%hi(singletics)
	lw	$31,20($sp)
	sw	$3,%lo(singletics)($2)
	lui	$2,%hi(defdemoname)
	sw	$16,%lo(defdemoname)($2)
	li	$3,5			# 0x5
	lui	$2,%hi(gameaction)
	lw	$16,16($sp)
	sw	$3,%lo(gameaction)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	G_TimeDemo
	.size	G_TimeDemo, .-G_TimeDemo
	.section	.rodata.str1.4
	.align	2
$LC28:
	.ascii	"timed %i gametics in %i realtics (%f fps)\000"
	.globl	__floatsisf
	.globl	__mulsf3
	.globl	__divsf3
	.globl	__extendsfdf2
	.align	2
$LC30:
	.ascii	"Demo %s recorded\000"
	.text
	.align	2
	.globl	G_CheckDemoStatus
	.set	nomips16
	.set	nomicromips
	.ent	G_CheckDemoStatus
	.type	G_CheckDemoStatus, @function
G_CheckDemoStatus:
	.frame	$sp,48,$31		# vars= 0, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$16,28($sp)
	lui	$16,%hi(timingdemo)
	lw	$2,%lo(timingdemo)($16)
	sw	$31,44($sp)
	sw	$19,40($sp)
	sw	$18,36($sp)
	bne	$2,$0,$L624
	sw	$17,32($sp)

	lui	$17,%hi(demoplayback)
	lw	$16,%lo(demoplayback)($17)
	bne	$16,$0,$L630
	lui	$2,%hi(defdemoname)

$L616:
	lui	$17,%hi(demorecording)
	lw	$2,%lo(demorecording)($17)
	bne	$2,$0,$L627
	lw	$31,44($sp)

	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	move	$2,$16
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,48

$L624:
	jal	I_GetTime
	lui	$17,%hi(demoplayback)

	lui	$3,%hi(gametic)
	lw	$19,%lo(gametic)($3)
	lui	$3,%hi(starttime)
	lw	$3,%lo(starttime)($3)
	move	$4,$19
	subu	$18,$2,$3
	sw	$0,%lo(timingdemo)($16)
	jal	__floatsisf
	sw	$0,%lo(demoplayback)($17)

	lui	$3,%hi($LC29)
	lw	$5,%lo($LC29)($3)
	jal	__mulsf3
	move	$4,$2

	move	$4,$18
	jal	__floatsisf
	move	$16,$2

	move	$5,$2
	jal	__divsf3
	move	$4,$16

	jal	__extendsfdf2
	move	$4,$2

	lui	$4,%hi($LC28)
	sw	$2,16($sp)
	sw	$3,20($sp)
	move	$6,$18
	move	$5,$19
	jal	I_Error
	addiu	$4,$4,%lo($LC28)

	lw	$16,%lo(demoplayback)($17)
	beq	$16,$0,$L616
	lui	$2,%hi(defdemoname)

$L630:
	jal	W_ReleaseLumpName
	lw	$4,%lo(defdemoname)($2)

	lui	$2,%hi(singledemo)
	lw	$3,%lo(singledemo)($2)
	lui	$2,%hi(playeringame)
	addiu	$2,$2,%lo(playeringame)
	sw	$0,12($2)
	sw	$0,8($2)
	sw	$0,4($2)
	lui	$2,%hi(respawnparm)
	lui	$4,%hi(netdemo)
	sw	$0,%lo(respawnparm)($2)
	lui	$2,%hi(fastparm)
	sw	$0,%lo(netdemo)($4)
	sw	$0,%lo(fastparm)($2)
	lui	$4,%hi(netgame)
	lui	$2,%hi(nomonsters)
	sw	$0,%lo(netgame)($4)
	sw	$0,%lo(nomonsters)($2)
	lui	$4,%hi(deathmatch)
	lui	$2,%hi(consoleplayer)
	sw	$0,%lo(demoplayback)($17)
	sw	$0,%lo(deathmatch)($4)
	beq	$3,$0,$L617
	sw	$0,%lo(consoleplayer)($2)

	jal	I_Quit
	li	$16,1			# 0x1

	lw	$31,44($sp)
$L629:
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	move	$2,$16
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,48

$L627:
	lui	$2,%hi(demo_p)
	lw	$3,%lo(demo_p)($2)
	lui	$19,%hi(demobuffer)
	addiu	$4,$3,1
	sw	$4,%lo(demo_p)($2)
	li	$4,-128			# 0xffffffffffffff80
	sb	$4,0($3)
	lw	$5,%lo(demobuffer)($19)
	lui	$18,%hi(demoname)
	lw	$6,%lo(demo_p)($2)
	lw	$4,%lo(demoname)($18)
	jal	M_WriteFile
	subu	$6,$6,$5

	jal	Z_Free
	lw	$4,%lo(demobuffer)($19)

	lw	$5,%lo(demoname)($18)
	lui	$4,%hi($LC30)
	addiu	$4,$4,%lo($LC30)
	jal	I_Error
	sw	$0,%lo(demorecording)($17)

	lw	$31,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	move	$2,$16
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,48

$L617:
	jal	D_AdvanceDemo
	li	$16,1			# 0x1

	b	$L629
	lw	$31,44($sp)

	.set	macro
	.set	reorder
	.end	G_CheckDemoStatus
	.size	G_CheckDemoStatus, .-G_CheckDemoStatus
	.align	2
	.globl	G_ReadDemoTiccmd
	.set	nomips16
	.set	nomicromips
	.ent	G_ReadDemoTiccmd
	.type	G_ReadDemoTiccmd, @function
G_ReadDemoTiccmd:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(demo_p)
	lw	$2,%lo(demo_p)($3)
	li	$5,128			# 0x80
	lbu	$6,0($2)
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L635
	.set	at
	addiu	$5,$2,1

	sw	$5,%lo(demo_p)($3)
	lbu	$6,0($2)
	addiu	$5,$2,2
	sb	$6,0($4)
	sw	$5,%lo(demo_p)($3)
	lbu	$5,1($2)
	sb	$5,1($4)
	lui	$5,%hi(longtics)
	lw	$6,%lo(longtics)($5)
	addiu	$5,$2,3
	bne	$6,$0,$L636
	sw	$5,%lo(demo_p)($3)

	lb	$2,2($2)
	addiu	$6,$5,1
	sll	$2,$2,8
	sh	$2,2($4)
	sw	$6,%lo(demo_p)($3)
	lbu	$2,0($5)
	jr	$31
	sb	$2,5($4)

$L636:
	lbu	$7,2($2)
	addiu	$5,$2,4
	lbu	$6,2($2)
	sh	$7,2($4)
	sw	$5,%lo(demo_p)($3)
	lbu	$2,3($2)
	sll	$2,$2,8
	or	$2,$6,$2
	sll	$2,$2,16
	sra	$2,$2,16
	addiu	$6,$5,1
	sh	$2,2($4)
	sw	$6,%lo(demo_p)($3)
	lbu	$2,0($5)
	jr	$31
	sb	$2,5($4)

$L635:
	j	G_CheckDemoStatus
	nop

	.set	macro
	.set	reorder
	.end	G_ReadDemoTiccmd
	.size	G_ReadDemoTiccmd, .-G_ReadDemoTiccmd
	.align	2
	.globl	G_WriteDemoTiccmd
	.set	nomips16
	.set	nomicromips
	.ent	G_WriteDemoTiccmd
	.type	G_WriteDemoTiccmd, @function
G_WriteDemoTiccmd:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(key_demo_quit)
	lw	$2,%lo(key_demo_quit)($2)
	lui	$3,%hi(gamekeydown)
	sll	$2,$2,2
	addiu	$3,$3,%lo(gamekeydown)
	addu	$2,$2,$3
	lw	$2,0($2)
	addiu	$sp,$sp,-48
	sw	$17,20($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	bne	$2,$0,$L647
	move	$17,$4

	lui	$16,%hi(demo_p)
	lw	$2,%lo(demo_p)($16)
$L650:
	lb	$3,0($17)
	addiu	$4,$2,1
	sw	$4,%lo(demo_p)($16)
	sb	$3,0($2)
	lw	$3,%lo(demo_p)($16)
	lb	$4,1($17)
	addiu	$5,$3,1
	sw	$5,%lo(demo_p)($16)
	sb	$4,0($3)
	lui	$3,%hi(longtics)
	lw	$3,%lo(longtics)($3)
	beq	$3,$0,$L651
	lw	$3,%lo(demo_p)($16)

	lh	$4,2($17)
	addiu	$5,$3,1
	sw	$5,%lo(demo_p)($16)
	sb	$4,0($3)
	lw	$3,%lo(demo_p)($16)
$L651:
	lb	$4,3($17)
	addiu	$5,$3,1
	sw	$5,%lo(demo_p)($16)
	sb	$4,0($3)
	lw	$3,%lo(demo_p)($16)
	lbu	$4,5($17)
	lui	$21,%hi(demoend)
	sb	$4,0($3)
	lw	$3,%lo(demoend)($21)
	sw	$2,%lo(demo_p)($16)
	addiu	$4,$3,-16
	sltu	$2,$4,$2
	beq	$2,$0,$L652
	lw	$31,44($sp)

	lui	$2,%hi(vanilla_demo_limit)
	lw	$2,%lo(vanilla_demo_limit)($2)
	bne	$2,$0,$L653
	lui	$20,%hi(demobuffer)

	lw	$2,%lo(demobuffer)($20)
	move	$6,$0
	subu	$18,$3,$2
	sll	$22,$18,1
	move	$4,$22
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$5,%lo(demobuffer)($20)
	lw	$3,%lo(demo_p)($16)
	move	$19,$2
	move	$4,$2
	move	$6,$18
	subu	$2,$3,$5
	jal	memcpy
	addu	$18,$19,$2

	lw	$4,%lo(demobuffer)($20)
	jal	Z_Free
	addu	$22,$19,$22

	sw	$19,%lo(demobuffer)($20)
	sw	$18,%lo(demo_p)($16)
	sw	$22,%lo(demoend)($21)
	lw	$31,44($sp)
$L652:
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$4,$17
	lw	$17,20($sp)
	j	G_ReadDemoTiccmd
	addiu	$sp,$sp,48

$L653:
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	G_CheckDemoStatus
	addiu	$sp,$sp,48

$L647:
	jal	G_CheckDemoStatus
	lui	$16,%hi(demo_p)

	b	$L650
	lw	$2,%lo(demo_p)($16)

	.set	macro
	.set	reorder
	.end	G_WriteDemoTiccmd
	.size	G_WriteDemoTiccmd, .-G_WriteDemoTiccmd
	.section	.rodata.str1.4
	.align	2
$LC31:
	.ascii	"DOOM%02i.%s\000"
	.align	2
$LC32:
	.ascii	"screen shot\000"
	.align	2
$LC33:
	.ascii	"%s is turbo!\000"
	.align	2
$LC34:
	.ascii	"consistency failure (%i should be %i)\000"
	.align	2
$LC35:
	.ascii	"NET GAME\000"
	.text
	.align	2
	.globl	G_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	G_Ticker
	.type	G_Ticker, @function
G_Ticker:
	.frame	$sp,96,$31		# vars= 40, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-96
	sw	$20,72($sp)
	sw	$19,68($sp)
	lui	$20,%hi(players)
	lui	$19,%hi(playeringame)
	addiu	$20,$20,%lo(players)
	addiu	$19,$19,%lo(playeringame)
	sw	$23,84($sp)
	sw	$22,80($sp)
	sw	$21,76($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
	sw	$16,56($sp)
	sw	$31,92($sp)
	sw	$fp,88($sp)
	move	$18,$20
	move	$21,$20
	move	$17,$19
	move	$16,$0
	li	$23,2			# 0x2
	li	$22,4			# 0x4
$L656:
	lw	$2,0($17)
	beq	$2,$0,$L655
	nop

	lw	$2,4($21)
	.set	noat
	xor	$1,$2,$23
	beq	$1,$0,$L724
	.set	at
	nop

$L655:
	addiu	$16,$16,1
$L739:
	addiu	$17,$17,4
	.set	noat
	xor	$1,$16,$22
	bne	$1,$0,$L656
	.set	at
	addiu	$21,$21,288

	lui	$2,%hi($LC32)
	lui	$17,%hi($L660)
	addiu	$2,$2,%lo($LC32)
	lui	$22,%hi(wminfo)
	lui	$21,%hi(gamestate)
	lui	$16,%hi(gameaction)
	addiu	$17,$17,%lo($L660)
	lui	$fp,%hi($LC31)
	lui	$23,%hi(consoleplayer)
	sw	$2,16($sp)
	addiu	$22,$22,%lo(wminfo)
$L657:
	lw	$2,%lo(gameaction)($16)
$L738:
	beq	$2,$0,$L721
	sll	$3,$2,2

$L741:
	addu	$3,$17,$3
	sltu	$2,$2,10
$L712:
	beq	$2,$0,$L714
	nop

	lw	$4,0($3)
	jr	$4
	nop

	.rdata
	.align	2
	.align	2
$L660:
	.word	$L712
	.word	$L668
	.word	$L667
	.word	$L666
	.word	$L665
	.word	$L664
	.word	$L663
	.word	$L662
	.word	$L661
	.word	$L659
	.text
$L659:
	jal	V_ScreenShot
	addiu	$4,$fp,%lo($LC31)

	lw	$3,%lo(consoleplayer)($23)
	sw	$0,%lo(gameaction)($16)
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,5
	lw	$3,16($sp)
	addu	$2,$20,$2
	sw	$3,224($2)
	lw	$2,%lo(gameaction)($16)
	bne	$2,$0,$L741
	sll	$3,$2,2

$L721:
	lui	$2,%hi(gametic)
	lui	$3,%hi(ticdup)
	sw	$2,16($sp)
	sw	$3,48($sp)
	lw	$2,%lo(gametic)($2)
	lw	$3,%lo(ticdup)($3)
	div	$0,$2,$3
	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,127
	mflo	$2
	and	$2,$2,$3
	bgez	$2,$L670
	li	$3,-128			# 0xffffffffffffff80

	addiu	$2,$2,-1
	or	$2,$2,$3
	addiu	$2,$2,1
$L670:
	lui	$9,%hi(consistancy)
	addiu	$9,$9,%lo(consistancy)
	addu	$9,$9,$2
	lui	$2,%hi(netcmds)
	sw	$2,32($sp)
	lui	$2,%hi(demoplayback)
	sw	$2,36($sp)
	lui	$2,%hi(demorecording)
	lui	$12,%hi(player_names)
	lui	$11,%hi(turbodetected)
	lui	$8,%hi(players+8)
	sw	$2,40($sp)
	lui	$2,%hi(netgame)
	addiu	$12,$12,%lo(player_names)
	addiu	$11,$11,%lo(turbodetected)
	addiu	$17,$8,%lo(players+8)
	move	$fp,$19
	move	$23,$0
	sw	$2,44($sp)
	b	$L681
	li	$22,4			# 0x4

$L672:
	addiu	$23,$23,1
	addiu	$fp,$fp,4
	addiu	$9,$9,128
	addiu	$12,$12,4
	addiu	$11,$11,4
	.set	noat
	xor	$1,$23,$22
	beq	$1,$0,$L726
	.set	at
	addiu	$17,$17,288

$L681:
	lw	$2,0($fp)
	beq	$2,$0,$L672
	lw	$2,32($sp)

	sll	$5,$23,4
	lw	$2,%lo(netcmds)($2)
	li	$6,16			# 0x10
	addu	$5,$2,$5
	move	$4,$17
	sw	$9,28($sp)
	sw	$12,24($sp)
	jal	memcpy
	sw	$11,20($sp)

	lw	$2,36($sp)
	lw	$11,20($sp)
	lw	$2,%lo(demoplayback)($2)
	lw	$12,24($sp)
	bne	$2,$0,$L727
	lw	$9,28($sp)

$L673:
	lw	$2,40($sp)
	lw	$2,%lo(demorecording)($2)
	bne	$2,$0,$L728
	move	$4,$17

$L674:
	lb	$2,0($17)
	slt	$2,$2,51
	bne	$2,$0,$L742
	lw	$2,16($sp)

	li	$2,1			# 0x1
	sw	$2,0($11)
	lw	$2,16($sp)
$L742:
	lw	$2,%lo(gametic)($2)
	andi	$4,$2,0x1f
	bne	$4,$0,$L676
	li	$4,-2147483648			# 0xffffffff80000000

	sra	$2,$2,5
	addiu	$4,$4,3
	and	$2,$2,$4
	bltz	$2,$L729
	nop

	.set	noat
	xor	$1,$2,$23
	beq	$1,$0,$L730
	.set	at
	nop

$L676:
	lw	$2,44($sp)
$L744:
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L672
	lui	$2,%hi(netdemo)

	lw	$2,%lo(netdemo)($2)
	bne	$2,$0,$L672
	lw	$2,16($sp)

	lw	$4,%lo(gametic)($2)
	lw	$2,48($sp)
	lw	$2,%lo(ticdup)($2)
	div	$0,$4,$2
	mfhi	$2
	bne	$2,$0,$L672
	slt	$4,$4,129

	bne	$4,$0,$L679
	nop

	lbu	$6,0($9)
	lbu	$5,6($17)
	.set	noat
	xor	$1,$6,$5
	bne	$1,$0,$L731
	.set	at
	lui	$4,%hi($LC34)

$L679:
	lw	$2,-8($17)
	beq	$2,$0,$L680
	nop

	lw	$2,12($2)
	addiu	$23,$23,1
	sb	$2,0($9)
	addiu	$fp,$fp,4
	addiu	$9,$9,128
	addiu	$12,$12,4
	addiu	$11,$11,4
	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L681
	.set	at
	addiu	$17,$17,288

$L726:
	addiu	$20,$20,1152
	li	$17,1			# 0x1
	b	$L687
	li	$22,2			# 0x2

$L682:
	addiu	$18,$18,288
$L737:
	.set	noat
	xor	$1,$20,$18
	beq	$1,$0,$L732
	.set	at
	addiu	$19,$19,4

$L687:
	lw	$2,0($19)
	beq	$2,$0,$L682
	nop

	lb	$3,13($18)
	bgez	$3,$L682
	lbu	$2,13($18)

	andi	$3,$2,0x3
	.set	noat
	xor	$1,$3,$17
	beq	$1,$0,$L683
	.set	at
	nop

	.set	noat
	xor	$1,$3,$22
	bne	$1,$0,$L682
	.set	at
	lui	$4,%hi(savedescription)

	lb	$3,%lo(savedescription)($4)
	beq	$3,$0,$L733
	lui	$5,%hi($LC35)

$L686:
	sra	$2,$2,2
	andi	$2,$2,0x7
	lui	$3,%hi(savegameslot)
	sw	$2,%lo(savegameslot)($3)
	addiu	$18,$18,288
	li	$2,4			# 0x4
	sw	$2,%lo(gameaction)($16)
	.set	noat
	xor	$1,$20,$18
	bne	$1,$0,$L687
	.set	at
	addiu	$19,$19,4

$L732:
	lui	$16,%hi(oldgamestate)
	lw	$2,%lo(oldgamestate)($16)
	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L734
	.set	at
	lw	$4,%lo(gamestate)($21)

	lw	$2,%lo(gamestate)($21)
$L740:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L690
	.set	at
	sw	$2,%lo(oldgamestate)($16)

	sltu	$3,$2,3
	beq	$3,$0,$L691
	li	$3,3			# 0x3

	bne	$2,$0,$L743
	lw	$31,92($sp)

	jal	P_Ticker
	nop

	jal	ST_Ticker
	nop

	jal	AM_Ticker
	nop

	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	j	HU_Ticker
	addiu	$sp,$sp,96

$L661:
	lw	$2,12($22)
	lui	$3,%hi(gamemap)
	addiu	$2,$2,1
	sw	$2,%lo(gamemap)($3)
	jal	G_DoLoadLevel
	sw	$0,%lo(gamestate)($21)

	lui	$2,%hi(viewactive)
	li	$3,1			# 0x1
	sw	$0,%lo(gameaction)($16)
	b	$L657
	sw	$3,%lo(viewactive)($2)

$L662:
	jal	F_StartFinale
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L663:
	jal	G_DoCompleted
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L664:
	jal	G_DoPlayDemo
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L665:
	jal	G_DoSaveGame
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L666:
	jal	G_DoLoadGame
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L667:
	jal	G_DoNewGame
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L668:
	jal	G_DoLoadLevel
	nop

	b	$L738
	lw	$2,%lo(gameaction)($16)

$L691:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L735
	.set	at
	lw	$31,92($sp)

	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	j	D_PageTicker
	addiu	$sp,$sp,96

$L729:
	addiu	$2,$2,-1
	li	$4,-4			# 0xfffffffffffffffc
	or	$2,$2,$4
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$23
	bne	$1,$0,$L744
	.set	at
	lw	$2,44($sp)

$L730:
	lw	$2,0($11)
	beq	$2,$0,$L744
	lw	$2,44($sp)

	lui	$14,%hi(turbomessage.1)
	lw	$7,0($12)
	lui	$6,%hi($LC33)
	addiu	$4,$14,%lo(turbomessage.1)
	addiu	$6,$6,%lo($LC33)
	li	$5,80			# 0x50
	sw	$9,52($sp)
	sw	$11,28($sp)
	sw	$12,24($sp)
	jal	M_snprintf
	sw	$14,20($sp)

	lui	$2,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($2)
	lw	$14,20($sp)
	sll	$2,$4,3
	addu	$2,$2,$4
	lw	$11,28($sp)
	sll	$2,$2,5
	addiu	$14,$14,%lo(turbomessage.1)
	addu	$2,$20,$2
	lw	$9,52($sp)
	lw	$12,24($sp)
	sw	$14,224($2)
	b	$L676
	sw	$0,0($11)

$L728:
	sw	$9,28($sp)
	sw	$12,24($sp)
	jal	G_WriteDemoTiccmd
	sw	$11,20($sp)

	lw	$9,28($sp)
	lw	$12,24($sp)
	b	$L674
	lw	$11,20($sp)

$L727:
	jal	G_ReadDemoTiccmd
	move	$4,$17

	lw	$9,28($sp)
	lw	$12,24($sp)
	b	$L673
	lw	$11,20($sp)

$L724:
	jal	G_DoReborn
	move	$4,$16

	b	$L739
	addiu	$16,$16,1

$L734:
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L736
	.set	at
	lw	$31,92($sp)

$L743:
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	j	WI_Ticker
	addiu	$sp,$sp,96

$L683:
	lui	$3,%hi(paused)
	lw	$2,%lo(paused)($3)
	xori	$4,$2,0x1
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L685
	.set	at
	sw	$4,%lo(paused)($3)

	jal	S_PauseSound
	addiu	$18,$18,288

	b	$L737
	nop

$L690:
	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	j	F_Ticker
	addiu	$sp,$sp,96

$L735:
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	jr	$31
	addiu	$sp,$sp,96

$L736:
	jal	WI_End
	nop

	b	$L740
	lw	$2,%lo(gamestate)($21)

$L685:
	jal	S_ResumeSound
	addiu	$18,$18,288

	b	$L737
	nop

$L733:
	li	$6,32			# 0x20
	addiu	$5,$5,%lo($LC35)
	jal	M_StringCopy
	addiu	$4,$4,%lo(savedescription)

	b	$L686
	lbu	$2,13($18)

$L731:
	addiu	$4,$4,%lo($LC34)
	sw	$9,28($sp)
	sw	$12,24($sp)
	jal	I_Error
	sw	$11,20($sp)

	lw	$9,28($sp)
	lw	$12,24($sp)
	b	$L679
	lw	$11,20($sp)

$L680:
	lui	$2,%hi(rndindex)
	lw	$2,%lo(rndindex)($2)
	b	$L672
	sb	$2,0($9)

$L714:
	b	$L714
	nop

	.set	macro
	.set	reorder
	.end	G_Ticker
	.size	G_Ticker, .-G_Ticker
	.section	.rodata.str1.4
	.align	2
$LC36:
	.ascii	"v1.4\000"
	.align	2
$LC37:
	.ascii	"v1.5\000"
	.align	2
$LC38:
	.ascii	"v1.6/v1.666\000"
	.align	2
$LC39:
	.ascii	"v1.7/v1.7a\000"
	.align	2
$LC40:
	.ascii	"v1.8\000"
	.align	2
$LC41:
	.ascii	"v1.9\000"
	.rdata
	.align	2
	.type	CSWTCH.405, @object
	.size	CSWTCH.405, 24
CSWTCH.405:
	.word	$LC36
	.word	$LC37
	.word	$LC38
	.word	$LC39
	.word	$LC40
	.word	$LC41
	.local	resultbuf.0
	.comm	resultbuf.0,16,4
	.local	turbomessage.1
	.comm	turbomessage.1,80,4
	.local	carry.2
	.comm	carry.2,2,2
	.globl	defdemoname
	.section	.bss,"aw",@nobits
	.align	2
	.type	defdemoname, @object
	.size	defdemoname, 4
defdemoname:
	.space	4
	.globl	d_map
	.align	2
	.type	d_map, @object
	.size	d_map, 4
d_map:
	.space	4
	.globl	d_episode
	.align	2
	.type	d_episode, @object
	.size	d_episode, 4
d_episode:
	.space	4
	.globl	d_skill
	.align	2
	.type	d_skill, @object
	.size	d_skill, 4
d_skill:
	.space	4
	.globl	savename
	.align	2
	.type	savename, @object
	.size	savename, 256
savename:
	.space	256
	.globl	secretexit
	.align	2
	.type	secretexit, @object
	.size	secretexit, 4
secretexit:
	.space	4
	.globl	cpars
	.data
	.align	2
	.type	cpars, @object
	.size	cpars, 128
cpars:
	.word	30
	.word	90
	.word	120
	.word	120
	.word	90
	.word	150
	.word	120
	.word	120
	.word	270
	.word	90
	.word	210
	.word	150
	.word	150
	.word	150
	.word	210
	.word	150
	.word	420
	.word	150
	.word	210
	.word	150
	.word	240
	.word	150
	.word	180
	.word	150
	.word	150
	.word	300
	.word	330
	.word	420
	.word	300
	.word	180
	.word	120
	.word	30
	.globl	pars
	.align	2
	.type	pars, @object
	.size	pars, 160
pars:
	.word	0
	.space	36
	.word	0
	.word	30
	.word	75
	.word	120
	.word	90
	.word	165
	.word	180
	.word	180
	.word	30
	.word	165
	.word	0
	.word	90
	.word	90
	.word	90
	.word	120
	.word	90
	.word	360
	.word	240
	.word	30
	.word	170
	.word	0
	.word	90
	.word	45
	.word	90
	.word	150
	.word	90
	.word	90
	.word	165
	.word	30
	.word	135
	.globl	vanilla_demo_limit
	.align	2
	.type	vanilla_demo_limit, @object
	.size	vanilla_demo_limit, 4
vanilla_demo_limit:
	.word	1
	.globl	vanilla_savegame_limit
	.align	2
	.type	vanilla_savegame_limit, @object
	.size	vanilla_savegame_limit, 4
vanilla_savegame_limit:
	.word	1
	.globl	bodyqueslot
	.section	.bss
	.align	2
	.type	bodyqueslot, @object
	.size	bodyqueslot, 4
bodyqueslot:
	.space	4
	.globl	bodyque
	.align	2
	.type	bodyque, @object
	.size	bodyque, 128
bodyque:
	.space	128
	.local	savedescription
	.comm	savedescription,32,4
	.local	savegameslot
	.comm	savegameslot,4,4
	.local	joyarray
	.comm	joyarray,84,4
	.local	joystrafemove
	.comm	joystrafemove,4,4
	.local	joyymove
	.comm	joyymove,4,4
	.local	joyxmove
	.comm	joyxmove,4,4
	.local	dclicks2
	.comm	dclicks2,4,4
	.local	dclickstate2
	.comm	dclickstate2,4,4
	.local	dclicktime2
	.comm	dclicktime2,4,4
	.local	dclicks
	.comm	dclicks,4,4
	.local	dclickstate
	.comm	dclickstate,4,4
	.local	dclicktime
	.comm	dclicktime,4,4
	.globl	mousey
	.align	2
	.type	mousey, @object
	.size	mousey, 4
mousey:
	.space	4
	.globl	mousex
	.align	2
	.type	mousex, @object
	.size	mousex, 4
mousex:
	.space	4
	.local	mousearray
	.comm	mousearray,36,4
	.local	turnheld
	.comm	turnheld,4,4
	.local	gamekeydown
	.comm	gamekeydown,1024,4
	.rdata
	.align	2
	.type	weapon_order_table, @object
	.size	weapon_order_table, 72
weapon_order_table:
	.word	0
	.word	0
	.word	7
	.word	0
	.word	1
	.word	1
	.word	2
	.word	2
	.word	8
	.word	2
	.word	3
	.word	3
	.word	4
	.word	4
	.word	5
	.word	5
	.word	6
	.word	6
	.local	next_weapon
	.comm	next_weapon,4,4
	.align	2
	.type	weapon_keys, @object
	.size	weapon_keys, 32
weapon_keys:
	.word	key_weapon1
	.word	key_weapon2
	.word	key_weapon3
	.word	key_weapon4
	.word	key_weapon5
	.word	key_weapon6
	.word	key_weapon7
	.word	key_weapon8
	.globl	angleturn
	.data
	.align	2
	.type	angleturn, @object
	.size	angleturn, 12
angleturn:
	.word	640
	.word	1280
	.word	320
	.globl	sidemove
	.align	2
	.type	sidemove, @object
	.size	sidemove, 8
sidemove:
	.word	24
	.word	40
	.globl	forwardmove
	.align	2
	.type	forwardmove, @object
	.size	forwardmove, 8
forwardmove:
	.word	25
	.word	50
	.globl	consistancy
	.section	.bss
	.align	2
	.type	consistancy, @object
	.size	consistancy, 512
consistancy:
	.space	512
	.globl	wminfo
	.align	2
	.type	wminfo, @object
	.size	wminfo, 200
wminfo:
	.space	200
	.globl	testcontrols_mousespeed
	.align	2
	.type	testcontrols_mousespeed, @object
	.size	testcontrols_mousespeed, 4
testcontrols_mousespeed:
	.space	4
	.globl	testcontrols
	.align	2
	.type	testcontrols, @object
	.size	testcontrols, 4
testcontrols:
	.space	4
	.globl	precache
	.data
	.align	2
	.type	precache, @object
	.size	precache, 4
precache:
	.word	1
	.globl	singledemo
	.section	.bss
	.align	2
	.type	singledemo, @object
	.size	singledemo, 4
singledemo:
	.space	4
	.globl	demoend
	.align	2
	.type	demoend, @object
	.size	demoend, 4
demoend:
	.space	4
	.globl	demo_p
	.align	2
	.type	demo_p, @object
	.size	demo_p, 4
demo_p:
	.space	4
	.globl	demobuffer
	.align	2
	.type	demobuffer, @object
	.size	demobuffer, 4
demobuffer:
	.space	4
	.globl	netdemo
	.align	2
	.type	netdemo, @object
	.size	netdemo, 4
netdemo:
	.space	4
	.globl	demoplayback
	.align	2
	.type	demoplayback, @object
	.size	demoplayback, 4
demoplayback:
	.space	4
	.globl	lowres_turn
	.align	2
	.type	lowres_turn, @object
	.size	lowres_turn, 4
lowres_turn:
	.space	4
	.globl	longtics
	.align	2
	.type	longtics, @object
	.size	longtics, 4
longtics:
	.space	4
	.globl	demorecording
	.align	2
	.type	demorecording, @object
	.size	demorecording, 4
demorecording:
	.space	4
	.globl	demoname
	.align	2
	.type	demoname, @object
	.size	demoname, 4
demoname:
	.space	4
	.globl	totalsecret
	.align	2
	.type	totalsecret, @object
	.size	totalsecret, 4
totalsecret:
	.space	4
	.globl	totalitems
	.align	2
	.type	totalitems, @object
	.size	totalitems, 4
totalitems:
	.space	4
	.globl	totalkills
	.align	2
	.type	totalkills, @object
	.size	totalkills, 4
totalkills:
	.space	4
	.globl	levelstarttic
	.align	2
	.type	levelstarttic, @object
	.size	levelstarttic, 4
levelstarttic:
	.space	4
	.globl	displayplayer
	.align	2
	.type	displayplayer, @object
	.size	displayplayer, 4
displayplayer:
	.space	4
	.globl	consoleplayer
	.align	2
	.type	consoleplayer, @object
	.size	consoleplayer, 4
consoleplayer:
	.space	4
	.globl	turbodetected
	.align	2
	.type	turbodetected, @object
	.size	turbodetected, 16
turbodetected:
	.space	16
	.globl	players
	.align	2
	.type	players, @object
	.size	players, 1152
players:
	.space	1152
	.globl	playeringame
	.align	2
	.type	playeringame, @object
	.size	playeringame, 16
playeringame:
	.space	16
	.globl	netgame
	.align	2
	.type	netgame, @object
	.size	netgame, 4
netgame:
	.space	4
	.globl	deathmatch
	.align	2
	.type	deathmatch, @object
	.size	deathmatch, 4
deathmatch:
	.space	4
	.globl	viewactive
	.align	2
	.type	viewactive, @object
	.size	viewactive, 4
viewactive:
	.space	4
	.globl	starttime
	.align	2
	.type	starttime, @object
	.size	starttime, 4
starttime:
	.space	4
	.globl	nodrawers
	.align	2
	.type	nodrawers, @object
	.size	nodrawers, 4
nodrawers:
	.space	4
	.globl	timingdemo
	.align	2
	.type	timingdemo, @object
	.size	timingdemo, 4
timingdemo:
	.space	4
	.globl	usergame
	.align	2
	.type	usergame, @object
	.size	usergame, 4
usergame:
	.space	4
	.globl	sendsave
	.align	2
	.type	sendsave, @object
	.size	sendsave, 4
sendsave:
	.space	4
	.globl	sendpause
	.align	2
	.type	sendpause, @object
	.size	sendpause, 4
sendpause:
	.space	4
	.globl	paused
	.align	2
	.type	paused, @object
	.size	paused, 4
paused:
	.space	4
	.globl	timelimit
	.align	2
	.type	timelimit, @object
	.size	timelimit, 4
timelimit:
	.space	4
	.globl	gamemap
	.align	2
	.type	gamemap, @object
	.size	gamemap, 4
gamemap:
	.space	4
	.globl	gameepisode
	.align	2
	.type	gameepisode, @object
	.size	gameepisode, 4
gameepisode:
	.space	4
	.globl	respawnmonsters
	.align	2
	.type	respawnmonsters, @object
	.size	respawnmonsters, 4
respawnmonsters:
	.space	4
	.globl	gameskill
	.align	2
	.type	gameskill, @object
	.size	gameskill, 4
gameskill:
	.space	4
	.globl	gamestate
	.align	2
	.type	gamestate, @object
	.size	gamestate, 4
gamestate:
	.space	4
	.globl	gameaction
	.align	2
	.type	gameaction, @object
	.size	gameaction, 4
gameaction:
	.space	4
	.globl	oldgamestate
	.align	2
	.type	oldgamestate, @object
	.size	oldgamestate, 4
oldgamestate:
	.space	4
	.section	.rodata.cst4,"aM",@progbits,4
	.align	2
$LC29:
	.word	1108082688
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
