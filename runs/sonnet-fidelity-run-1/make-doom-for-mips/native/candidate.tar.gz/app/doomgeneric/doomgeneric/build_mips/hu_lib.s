	.file	1 "hu_lib.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	HUlib_init
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_init
	.type	HUlib_init, @function
HUlib_init:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	HUlib_init
	.size	HUlib_init, .-HUlib_init
	.align	2
	.globl	HUlib_clearTextLine
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_clearTextLine
	.type	HUlib_clearTextLine, @function
HUlib_clearTextLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1			# 0x1
	sw	$0,100($4)
	sb	$0,16($4)
	jr	$31
	sw	$2,104($4)

	.set	macro
	.set	reorder
	.end	HUlib_clearTextLine
	.size	HUlib_clearTextLine, .-HUlib_clearTextLine
	.align	2
	.globl	HUlib_initTextLine
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_initTextLine
	.type	HUlib_initTextLine, @function
HUlib_initTextLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($sp)
	sw	$5,0($4)
	sw	$2,12($4)
	li	$2,1			# 0x1
	sw	$6,4($4)
	sw	$7,8($4)
	sw	$0,100($4)
	sb	$0,16($4)
	jr	$31
	sw	$2,104($4)

	.set	macro
	.set	reorder
	.end	HUlib_initTextLine
	.size	HUlib_initTextLine, .-HUlib_initTextLine
	.align	2
	.globl	HUlib_addCharToTextLine
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_addCharToTextLine
	.type	HUlib_addCharToTextLine, @function
HUlib_addCharToTextLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,100($4)
	li	$3,80			# 0x50
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L7
	.set	at
	addiu	$6,$2,1

	addu	$3,$4,$2
	sw	$6,100($4)
	addu	$7,$4,$6
	sb	$5,16($3)
	li	$3,4			# 0x4
	sb	$0,16($7)
	li	$2,1			# 0x1
	jr	$31
	sw	$3,104($4)

$L7:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	HUlib_addCharToTextLine
	.size	HUlib_addCharToTextLine, .-HUlib_addCharToTextLine
	.align	2
	.globl	HUlib_delCharFromTextLine
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_delCharFromTextLine
	.type	HUlib_delCharFromTextLine, @function
HUlib_delCharFromTextLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,100($4)
	beq	$2,$0,$L10
	nop

	addiu	$2,$2,-1
	addu	$3,$4,$2
	sw	$2,100($4)
	sb	$0,16($3)
	li	$3,4			# 0x4
	li	$2,1			# 0x1
	jr	$31
	sw	$3,104($4)

$L10:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	HUlib_delCharFromTextLine
	.size	HUlib_delCharFromTextLine, .-HUlib_delCharFromTextLine
	.align	2
	.globl	HUlib_drawTextLine
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_drawTextLine
	.type	HUlib_drawTextLine, @function
HUlib_drawTextLine:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,100($4)
	addiu	$sp,$sp,-48
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	lw	$20,0($4)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$19,$4
	blez	$2,$L12
	move	$18,$5

	move	$16,$0
	b	$L15
	li	$17,32			# 0x20

$L22:
	lw	$4,12($19)
	slt	$5,$3,$4
	bne	$5,$0,$L13
	sltu	$2,$2,96

	subu	$3,$3,$4
	sll	$3,$3,2
	beq	$2,$0,$L13
	move	$4,$20

	lw	$2,8($19)
	addu	$2,$2,$3
	lw	$6,0($2)
	lbu	$21,1($6)
	lbu	$2,0($6)
	sll	$21,$21,8
	or	$21,$21,$2
	sll	$21,$21,16
	sra	$21,$21,16
	addu	$21,$21,$20
	slt	$2,$21,321
	beq	$2,$0,$L12
	nop

	lw	$5,4($19)
	jal	V_DrawPatchDirect
	move	$20,$21

$L14:
	lw	$2,100($19)
	addiu	$16,$16,1
	slt	$2,$16,$2
	beq	$2,$0,$L12
	nop

$L15:
	addu	$2,$19,$16
	jal	toupper
	lb	$4,16($2)

	andi	$3,$2,0xff
	andi	$2,$2,0x00ff
	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L22
	.set	at
	nop

$L13:
	addiu	$20,$20,4
	slt	$2,$20,320
	bne	$2,$0,$L14
	nop

$L12:
	beq	$18,$0,$L24
	lw	$31,44($sp)

	lw	$4,12($19)
	li	$2,95			# 0x5f
	lw	$3,8($19)
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$6,0($2)
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$20
	slt	$2,$2,321
	bne	$2,$0,$L23
	lw	$21,40($sp)

$L24:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L23:
	lw	$5,4($19)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$20
	lw	$20,36($sp)
	j	V_DrawPatchDirect
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	HUlib_drawTextLine
	.size	HUlib_drawTextLine, .-HUlib_drawTextLine
	.align	2
	.globl	HUlib_eraseTextLine
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_eraseTextLine
	.type	HUlib_eraseTextLine, @function
HUlib_eraseTextLine:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(automapactive)
	lw	$3,%lo(automapactive)($2)
	addiu	$sp,$sp,-56
	lw	$2,104($4)
	sw	$16,20($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	bne	$3,$0,$L29
	move	$16,$4

	lui	$18,%hi(viewwindowx)
	lw	$3,%lo(viewwindowx)($18)
	beq	$3,$0,$L29
	nop

	beq	$2,$0,$L25
	nop

	lw	$3,8($4)
	lw	$22,4($4)
	lw	$3,0($3)
	sll	$23,$22,2
	lbu	$17,3($3)
	lbu	$3,2($3)
	sll	$17,$17,8
	or	$17,$17,$3
	sll	$17,$17,16
	sra	$17,$17,16
	addu	$23,$23,$22
	addiu	$17,$17,1
	blez	$17,$L27
	sll	$23,$23,6

	lui	$19,%hi(viewwindowy)
	lui	$20,%hi(viewheight)
	b	$L35
	lui	$21,%hi(viewwidth)

$L41:
	jal	R_VideoErase
	addiu	$22,$22,1

	lw	$2,4($16)
	addu	$2,$17,$2
	slt	$2,$22,$2
	beq	$2,$0,$L42
	addiu	$23,$23,320

$L35:
	lw	$2,%lo(viewwindowy)($19)
	li	$5,320			# 0x140
	slt	$3,$22,$2
	bne	$3,$0,$L41
	move	$4,$23

	lw	$3,%lo(viewheight)($20)
	addu	$2,$2,$3
	slt	$2,$22,$2
	beq	$2,$0,$L41
	nop

	lw	$5,%lo(viewwindowx)($18)
	jal	R_VideoErase
	addiu	$22,$22,1

	lw	$5,%lo(viewwindowx)($18)
	lw	$2,%lo(viewwidth)($21)
	addu	$4,$5,$23
	jal	R_VideoErase
	addu	$4,$4,$2

	lw	$2,4($16)
	addu	$2,$17,$2
	slt	$2,$22,$2
	bne	$2,$0,$L35
	addiu	$23,$23,320

$L42:
	lw	$2,104($16)
$L29:
	beq	$2,$0,$L43
	lw	$31,52($sp)

$L27:
	addiu	$2,$2,-1
	sw	$2,104($16)
$L25:
	lw	$31,52($sp)
$L43:
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	HUlib_eraseTextLine
	.size	HUlib_eraseTextLine, .-HUlib_eraseTextLine
	.align	2
	.globl	HUlib_initSText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_initSText
	.type	HUlib_initSText, @function
HUlib_initSText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,24($sp)
	lw	$8,16($sp)
	sw	$2,440($4)
	li	$2,1			# 0x1
	lw	$9,20($sp)
	sw	$7,432($4)
	sw	$2,444($4)
	blez	$7,$L48
	sw	$0,436($4)

	lw	$10,0($8)
	sll	$2,$7,3
	lbu	$3,3($10)
	lbu	$10,2($10)
	subu	$2,$2,$7
	sll	$3,$3,8
	sll	$2,$2,2
	or	$3,$3,$10
	subu	$2,$2,$7
	sll	$3,$3,16
	sra	$3,$3,16
	sll	$2,$2,2
	nor	$3,$0,$3
	addu	$2,$4,$2
	li	$7,1			# 0x1
$L46:
	sw	$6,4($4)
	sw	$5,0($4)
	sw	$8,8($4)
	sw	$9,12($4)
	sw	$0,100($4)
	sb	$0,16($4)
	sw	$7,104($4)
	addiu	$4,$4,108
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L46
	.set	at
	addu	$6,$6,$3

$L48:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	HUlib_initSText
	.size	HUlib_initSText, .-HUlib_initSText
	.align	2
	.globl	HUlib_addLineToSText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_addLineToSText
	.type	HUlib_addLineToSText, @function
HUlib_addLineToSText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,436($4)
	lw	$5,432($4)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L54
	.set	at
	sll	$2,$3,3

	move	$3,$0
	sll	$2,$3,3
$L54:
	subu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,2
	sw	$3,436($4)
	addu	$2,$4,$2
	li	$3,1			# 0x1
	sw	$0,100($2)
	sb	$0,16($2)
	blez	$5,$L55
	sw	$3,104($2)

	sll	$2,$5,3
	subu	$2,$2,$5
	sll	$2,$2,2
	subu	$2,$2,$5
	sll	$2,$2,2
	addu	$2,$4,$2
	li	$3,4			# 0x4
$L52:
	sw	$3,104($4)
	addiu	$4,$4,108
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L52
	.set	at
	nop

$L55:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	HUlib_addLineToSText
	.size	HUlib_addLineToSText, .-HUlib_addLineToSText
	.align	2
	.globl	HUlib_addMessageToSText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_addMessageToSText
	.type	HUlib_addMessageToSText, @function
HUlib_addMessageToSText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$9,436($4)
	lw	$7,432($4)
	addiu	$9,$9,1
	.set	noat
	xor	$1,$9,$7
	bne	$1,$0,$L78
	.set	at
	sll	$10,$9,3

	move	$9,$0
	sll	$10,$9,3
$L78:
	subu	$2,$10,$9
	sll	$2,$2,2
	subu	$2,$2,$9
	sll	$2,$2,2
	addu	$2,$4,$2
	li	$3,1			# 0x1
	sw	$9,436($4)
	sw	$0,100($2)
	sb	$0,16($2)
	blez	$7,$L58
	sw	$3,104($2)

	sll	$3,$7,3
	subu	$3,$3,$7
	sll	$3,$3,2
	subu	$3,$3,$7
	sll	$3,$3,2
	move	$2,$4
	addu	$3,$3,$4
	li	$7,4			# 0x4
$L59:
	sw	$7,104($2)
	addiu	$2,$2,108
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L59
	.set	at
	nop

$L58:
	beq	$5,$0,$L60
	nop

	lb	$7,0($5)
	beq	$7,$0,$L60
	nop

	subu	$2,$10,$9
	sll	$2,$2,2
	subu	$2,$2,$9
	sll	$2,$2,2
	addu	$2,$4,$2
	li	$13,80			# 0x50
	li	$14,4			# 0x4
$L62:
	lw	$3,100($2)
	addiu	$5,$5,1
	addiu	$8,$3,1
	addu	$12,$2,$3
	.set	noat
	xor	$1,$3,$13
	beq	$1,$0,$L61
	.set	at
	addu	$11,$2,$8

	sw	$8,100($2)
	sb	$7,16($12)
	sb	$0,16($11)
	sw	$14,104($2)
$L61:
	lb	$7,0($5)
	bne	$7,$0,$L62
	nop

$L60:
	lb	$3,0($6)
	beq	$3,$0,$L79
	subu	$2,$10,$9

	sll	$2,$2,2
	subu	$2,$2,$9
	sll	$2,$2,2
	addu	$4,$4,$2
	li	$9,80			# 0x50
	li	$10,4			# 0x4
$L65:
	lw	$2,100($4)
	addiu	$6,$6,1
	addiu	$5,$2,1
	addu	$8,$4,$2
	.set	noat
	xor	$1,$2,$9
	beq	$1,$0,$L64
	.set	at
	addu	$7,$4,$5

	sw	$5,100($4)
	sb	$3,16($8)
	sb	$0,16($7)
	sw	$10,104($4)
$L64:
	lb	$3,0($6)
	bne	$3,$0,$L65
	nop

$L79:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	HUlib_addMessageToSText
	.size	HUlib_addMessageToSText, .-HUlib_addMessageToSText
	.align	2
	.globl	HUlib_drawSText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_drawSText
	.type	HUlib_drawSText, @function
HUlib_drawSText:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,440($4)
	lw	$2,0($2)
	beq	$2,$0,$L92
	nop

	lw	$3,432($4)
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$31,28($sp)
	sw	$16,20($sp)
	blez	$3,$L80
	move	$17,$4

	move	$16,$0
$L83:
	lw	$2,436($17)
	move	$5,$0
	subu	$2,$2,$16
	bgez	$2,$L82
	addiu	$16,$16,1

	addu	$2,$2,$3
$L82:
	sll	$4,$2,3
	subu	$4,$4,$2
	sll	$4,$4,2
	subu	$4,$4,$2
	sll	$4,$4,2
	jal	HUlib_drawTextLine
	addu	$4,$17,$4

	lw	$3,432($17)
	slt	$2,$16,$3
	bne	$2,$0,$L83
	nop

$L80:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L92:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	HUlib_drawSText
	.size	HUlib_drawSText, .-HUlib_drawSText
	.align	2
	.globl	HUlib_eraseSText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_eraseSText
	.type	HUlib_eraseSText, @function
HUlib_eraseSText:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,432($4)
	addiu	$sp,$sp,-40
	sw	$16,20($sp)
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	blez	$2,$L94
	move	$16,$4

	move	$17,$4
	move	$18,$0
	li	$19,4			# 0x4
$L96:
	lw	$2,444($16)
	move	$4,$17
	beq	$2,$0,$L95
	addiu	$18,$18,1

	lw	$2,440($16)
	lw	$2,0($2)
	bne	$2,$0,$L95
	nop

	sw	$19,104($17)
$L95:
	jal	HUlib_eraseTextLine
	addiu	$17,$17,108

	lw	$2,432($16)
	slt	$2,$18,$2
	bne	$2,$0,$L96
	nop

$L94:
	lw	$2,440($16)
	lw	$31,36($sp)
	lw	$2,0($2)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,444($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	HUlib_eraseSText
	.size	HUlib_eraseSText, .-HUlib_eraseSText
	.align	2
	.globl	HUlib_initIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_initIText
	.type	HUlib_initIText, @function
HUlib_initIText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,20($sp)
	li	$2,1			# 0x1
	sw	$3,112($4)
	lw	$3,16($sp)
	sw	$0,108($4)
	sw	$2,116($4)
	sw	$5,0($4)
	sw	$6,4($4)
	sw	$7,8($4)
	sw	$3,12($4)
	sw	$0,100($4)
	sb	$0,16($4)
	jr	$31
	sw	$2,104($4)

	.set	macro
	.set	reorder
	.end	HUlib_initIText
	.size	HUlib_initIText, .-HUlib_initIText
	.align	2
	.globl	HUlib_delCharFromIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_delCharFromIText
	.type	HUlib_delCharFromIText, @function
HUlib_delCharFromIText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,100($4)
	lw	$3,108($4)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L109
	.set	at
	nop

	bne	$2,$0,$L108
	addiu	$2,$2,-1

$L109:
	jr	$31
	nop

$L108:
	addu	$3,$4,$2
	sw	$2,100($4)
	li	$2,4			# 0x4
	sb	$0,16($3)
	jr	$31
	sw	$2,104($4)

	.set	macro
	.set	reorder
	.end	HUlib_delCharFromIText
	.size	HUlib_delCharFromIText, .-HUlib_delCharFromIText
	.align	2
	.globl	HUlib_eraseLineFromIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_eraseLineFromIText
	.type	HUlib_eraseLineFromIText, @function
HUlib_eraseLineFromIText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,108($4)
	lw	$2,100($4)
	li	$6,4			# 0x4
$L112:
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L117
	.set	at
	nop

$L113:
	beq	$2,$0,$L112
	nop

	addiu	$2,$2,-1
	addu	$5,$4,$2
	sw	$2,100($4)
	sb	$0,16($5)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L113
	.set	at
	sw	$6,104($4)

$L117:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	HUlib_eraseLineFromIText
	.size	HUlib_eraseLineFromIText, .-HUlib_eraseLineFromIText
	.align	2
	.globl	HUlib_resetIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_resetIText
	.type	HUlib_resetIText, @function
HUlib_resetIText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1			# 0x1
	sw	$0,108($4)
	sw	$0,100($4)
	sb	$0,16($4)
	jr	$31
	sw	$2,104($4)

	.set	macro
	.set	reorder
	.end	HUlib_resetIText
	.size	HUlib_resetIText, .-HUlib_resetIText
	.align	2
	.globl	HUlib_addPrefixToIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_addPrefixToIText
	.type	HUlib_addPrefixToIText, @function
HUlib_addPrefixToIText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$6,0($5)
	beq	$6,$0,$L120
	lw	$2,100($4)

	li	$9,80			# 0x50
	li	$10,4			# 0x4
	addiu	$3,$2,1
$L127:
	addu	$8,$4,$2
	addu	$7,$4,$3
	.set	noat
	xor	$1,$2,$9
	beq	$1,$0,$L121
	.set	at
	addiu	$5,$5,1

	sw	$3,100($4)
	move	$2,$3
	sb	$6,16($8)
	sb	$0,16($7)
	sw	$10,104($4)
$L121:
	lb	$6,0($5)
	bne	$6,$0,$L127
	addiu	$3,$2,1

$L120:
	jr	$31
	sw	$2,108($4)

	.set	macro
	.set	reorder
	.end	HUlib_addPrefixToIText
	.size	HUlib_addPrefixToIText, .-HUlib_addPrefixToIText
	.align	2
	.globl	HUlib_keyInIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_keyInIText
	.type	HUlib_keyInIText, @function
HUlib_keyInIText:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	jal	toupper
	move	$4,$5

	andi	$3,$2,0x00ff
	addiu	$4,$3,-32
	sltu	$4,$4,64
	beq	$4,$0,$L129
	li	$4,80			# 0x50

	lw	$3,100($16)
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L130
	.set	at
	addiu	$4,$3,1

	addu	$3,$16,$3
	sw	$4,100($16)
	addu	$5,$16,$4
	sb	$2,16($3)
	li	$2,4			# 0x4
	sb	$0,16($5)
	sw	$2,104($16)
$L130:
	li	$2,1			# 0x1
$L138:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L129:
	li	$2,127			# 0x7f
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L137
	.set	at
	lw	$31,20($sp)

	xori	$2,$3,0xd
	lw	$16,16($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,24

$L137:
	lw	$2,100($16)
	lw	$3,108($16)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L130
	.set	at
	nop

	beq	$2,$0,$L130
	addiu	$2,$2,-1

	addu	$3,$16,$2
	sw	$2,100($16)
	li	$2,4			# 0x4
	sb	$0,16($3)
	sw	$2,104($16)
	b	$L138
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	HUlib_keyInIText
	.size	HUlib_keyInIText, .-HUlib_keyInIText
	.align	2
	.globl	HUlib_drawIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_drawIText
	.type	HUlib_drawIText, @function
HUlib_drawIText:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,112($4)
	lw	$2,0($2)
	bne	$2,$0,$L141
	nop

	jr	$31
	nop

$L141:
	j	HUlib_drawTextLine
	li	$5,1			# 0x1

	.set	macro
	.set	reorder
	.end	HUlib_drawIText
	.size	HUlib_drawIText, .-HUlib_drawIText
	.align	2
	.globl	HUlib_eraseIText
	.set	nomips16
	.set	nomicromips
	.ent	HUlib_eraseIText
	.type	HUlib_eraseIText, @function
HUlib_eraseIText:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,116($4)
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$2,$0,$L143
	move	$16,$4

	lw	$2,112($4)
	lw	$2,0($2)
	bne	$2,$0,$L143
	li	$2,4			# 0x4

	sw	$2,104($4)
$L143:
	jal	HUlib_eraseTextLine
	move	$4,$16

	lw	$2,112($16)
	lw	$31,20($sp)
	lw	$2,0($2)
	sw	$2,116($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	HUlib_eraseIText
	.size	HUlib_eraseIText, .-HUlib_eraseIText
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
