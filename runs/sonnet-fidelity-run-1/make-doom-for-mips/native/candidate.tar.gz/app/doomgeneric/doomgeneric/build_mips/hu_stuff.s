	.file	1 "hu_stuff.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"STCFN%.3d\000"
	.text
	.align	2
	.globl	HU_Init
	.set	nomips16
	.set	nomicromips
	.ent	HU_Init
	.type	HU_Init, @function
HU_Init:
	.frame	$sp,56,$31		# vars= 16, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$18,44($sp)
	sw	$17,40($sp)
	lui	$18,%hi($LC0)
	lui	$17,%hi(hu_font)
	sw	$19,48($sp)
	sw	$16,36($sp)
	sw	$31,52($sp)
	addiu	$17,$17,%lo(hu_font)
	li	$16,33			# 0x21
	addiu	$18,$18,%lo($LC0)
	li	$19,96			# 0x60
$L2:
	move	$7,$16
	addiu	$4,$sp,16
	move	$6,$18
	jal	snprintf
	li	$5,9			# 0x9

	li	$5,1			# 0x1
	jal	W_CacheLumpName
	addiu	$4,$sp,16

	addiu	$16,$16,1
	sw	$2,0($17)
	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L2
	.set	at
	addiu	$17,$17,4

	lw	$31,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	HU_Init
	.size	HU_Init, .-HU_Init
	.align	2
	.globl	HU_Stop
	.set	nomips16
	.set	nomicromips
	.ent	HU_Stop
	.type	HU_Stop, @function
HU_Stop:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(headsupactive)
	jr	$31
	sw	$0,%lo(headsupactive)($2)

	.set	macro
	.set	reorder
	.end	HU_Stop
	.size	HU_Stop, .-HU_Stop
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Unknown level\000"
	.text
	.align	2
	.globl	HU_Start
	.set	nomips16
	.set	nomicromips
	.ent	HU_Start
	.type	HU_Start, @function
HU_Start:
	.frame	$sp,64,$31		# vars= 0, regs= 7/0, args= 32, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$18,44($sp)
	lui	$18,%hi(headsupactive)
	lw	$2,%lo(headsupactive)($18)
	sw	$31,60($sp)
	sw	$21,56($sp)
	sw	$20,52($sp)
	sw	$19,48($sp)
	sw	$17,40($sp)
	beq	$2,$0,$L8
	sw	$16,36($sp)

	sw	$0,%lo(headsupactive)($18)
$L8:
	lui	$2,%hi(consoleplayer)
	lw	$2,%lo(consoleplayer)($2)
	lui	$8,%hi(message_on)
	sll	$3,$2,3
	addu	$3,$3,$2
	lui	$2,%hi(players)
	sll	$3,$3,5
	addiu	$2,$2,%lo(players)
	addiu	$4,$8,%lo(message_on)
	addu	$2,$2,$3
	lui	$19,%hi(hu_font)
	lui	$3,%hi(plr)
	sw	$2,%lo(plr)($3)
	li	$21,33			# 0x21
	addiu	$16,$19,%lo(hu_font)
	sw	$4,24($sp)
	lui	$2,%hi(message_dontfuckwithme)
	lui	$4,%hi(w_message)
	li	$7,1			# 0x1
	move	$6,$0
	move	$5,$0
	addiu	$4,$4,%lo(w_message)
	sw	$0,%lo(message_dontfuckwithme)($2)
	lui	$20,%hi(chat_on)
	lui	$2,%hi(message_nottobefuckedwith)
	sw	$21,20($sp)
	sw	$16,16($sp)
	sw	$0,%lo(message_on)($8)
	sw	$0,%lo(message_nottobefuckedwith)($2)
	jal	HUlib_initSText
	sw	$0,%lo(chat_on)($20)

	lw	$3,%lo(hu_font)($19)
	lui	$17,%hi(w_title)
	lbu	$2,3($3)
	lbu	$3,2($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	li	$6,167			# 0xa7
	subu	$6,$6,$2
	sw	$21,16($sp)
	move	$7,$16
	move	$5,$0
	jal	HUlib_initTextLine
	addiu	$4,$17,%lo(w_title)

	lui	$2,%hi(gamemission)
	lw	$2,%lo(gamemission)($2)
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L9
	.set	at
	li	$3,5			# 0x5

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L10
	.set	at
	li	$3,2			# 0x2

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L11
	.set	at
	lui	$3,%hi(gamemap)

	sltu	$3,$2,3
	beq	$3,$0,$L12
	li	$3,3			# 0x3

	beq	$2,$0,$L41
	lui	$2,%hi(gameepisode)

$L10:
	lui	$3,%hi(gamemap)
	lw	$2,%lo(gamemap)($3)
	addiu	$2,$2,-1
$L38:
	lui	$4,%hi(mapnames_commercial)
	addiu	$4,$4,%lo(mapnames_commercial)
	sll	$2,$2,2
	addu	$2,$2,$4
	lw	$16,0($2)
	lui	$2,%hi(gameversion)
	lw	$4,%lo(gameversion)($2)
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L42
	.set	at
	lw	$2,%lo(gamemap)($3)

$L16:
	lb	$5,0($16)
	beq	$5,$0,$L43
	lw	$2,%lo(hu_font)($19)

$L21:
	addiu	$17,$17,%lo(w_title)
	addiu	$16,$16,1
$L44:
	jal	HUlib_addCharToTextLine
	move	$4,$17

	lb	$5,0($16)
	bne	$5,$0,$L44
	addiu	$16,$16,1

	lw	$2,%lo(hu_font)($19)
$L43:
	addiu	$20,$20,%lo(chat_on)
	lbu	$6,3($2)
	lbu	$2,2($2)
	sll	$6,$6,8
	or	$6,$6,$2
	sll	$6,$6,16
	li	$2,33			# 0x21
	sra	$6,$6,16
	lui	$4,%hi(w_chat)
	lui	$16,%hi(w_inputbuffer)
	addiu	$7,$19,%lo(hu_font)
	sw	$20,20($sp)
	sw	$2,16($sp)
	addiu	$6,$6,1
	move	$5,$0
	addiu	$4,$4,%lo(w_chat)
	addiu	$16,$16,%lo(w_inputbuffer)
	jal	HUlib_initIText
	lui	$17,%hi(always_off)

	addiu	$19,$16,480
	addiu	$17,$17,%lo(always_off)
	move	$4,$16
$L45:
	sw	$17,20($sp)
	addiu	$16,$16,120
	sw	$0,16($sp)
	move	$7,$0
	move	$6,$0
	jal	HUlib_initIText
	move	$5,$0

	.set	noat
	xor	$1,$19,$16
	bne	$1,$0,$L45
	.set	at
	move	$4,$16

	lw	$31,60($sp)
	li	$2,1			# 0x1
	lw	$21,56($sp)
	lw	$20,52($sp)
	lw	$19,48($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	sw	$2,%lo(headsupactive)($18)
	lw	$18,44($sp)
	jr	$31
	addiu	$sp,$sp,64

$L9:
	lui	$2,%hi(gameepisode)
$L41:
	lw	$4,%lo(gameepisode)($2)
	lui	$3,%hi(gamemap)
	addiu	$4,$4,-1
	sll	$2,$4,3
	lw	$5,%lo(gamemap)($3)
	addu	$2,$2,$4
	addu	$2,$2,$5
	addiu	$2,$2,-1
	lui	$4,%hi(mapnames)
	addiu	$4,$4,%lo(mapnames)
	sll	$2,$2,2
	addu	$2,$2,$4
	lw	$16,0($2)
	lui	$2,%hi(gameversion)
	lw	$4,%lo(gameversion)($2)
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L16
	.set	at
	nop

$L20:
	lw	$2,%lo(gamemap)($3)
$L42:
	lui	$3,%hi(mapnames)
	addiu	$2,$2,-1
	sll	$2,$2,2
	addiu	$3,$3,%lo(mapnames)
	addu	$2,$2,$3
	b	$L16
	lw	$16,0($2)

$L12:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L39
	.set	at
	lui	$3,%hi(gamemap)

	lw	$2,%lo(gamemap)($3)
	b	$L38
	addiu	$2,$2,31

$L39:
	lui	$2,%hi(gameversion)
	lw	$3,%lo(gameversion)($2)
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L40
	.set	at
	li	$5,85			# 0x55

	lui	$16,%hi($LC1)
	b	$L21
	addiu	$16,$16,%lo($LC1)

$L11:
	lw	$2,%lo(gamemap)($3)
	b	$L38
	addiu	$2,$2,63

$L40:
	b	$L20
	lui	$3,%hi(gamemap)

	.set	macro
	.set	reorder
	.end	HU_Start
	.size	HU_Start, .-HU_Start
	.align	2
	.globl	HU_Drawer
	.set	nomips16
	.set	nomicromips
	.ent	HU_Drawer
	.type	HU_Drawer, @function
HU_Drawer:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(w_message)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	HUlib_drawSText
	addiu	$4,$4,%lo(w_message)

	lui	$4,%hi(w_chat)
	jal	HUlib_drawIText
	addiu	$4,$4,%lo(w_chat)

	lui	$2,%hi(automapactive)
	lw	$2,%lo(automapactive)($2)
	bne	$2,$0,$L49
	lw	$31,20($sp)

	jr	$31
	addiu	$sp,$sp,24

$L49:
	lui	$4,%hi(w_title)
	move	$5,$0
	addiu	$4,$4,%lo(w_title)
	j	HUlib_drawTextLine
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	HU_Drawer
	.size	HU_Drawer, .-HU_Drawer
	.align	2
	.globl	HU_Erase
	.set	nomips16
	.set	nomicromips
	.ent	HU_Erase
	.type	HU_Erase, @function
HU_Erase:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(w_message)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	HUlib_eraseSText
	addiu	$4,$4,%lo(w_message)

	lui	$4,%hi(w_chat)
	jal	HUlib_eraseIText
	addiu	$4,$4,%lo(w_chat)

	lw	$31,20($sp)
	lui	$4,%hi(w_title)
	addiu	$4,$4,%lo(w_title)
	j	HUlib_eraseTextLine
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	HU_Erase
	.size	HU_Erase, .-HU_Erase
	.align	2
	.globl	HU_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	HU_Ticker
	.type	HU_Ticker, @function
HU_Ticker:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$21,44($sp)
	lui	$21,%hi(message_counter)
	lw	$2,%lo(message_counter)($21)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	beq	$2,$0,$L54
	sw	$16,24($sp)

	addiu	$2,$2,-1
	beq	$2,$0,$L93
	sw	$2,%lo(message_counter)($21)

$L54:
	lui	$16,%hi(message_dontfuckwithme)
	lui	$2,%hi(showMessages)
	lw	$3,%lo(message_dontfuckwithme)($16)
	lw	$2,%lo(showMessages)($2)
	or	$2,$3,$2
	beq	$2,$0,$L95
	lui	$2,%hi(netgame)

	lui	$17,%hi(plr)
	lw	$2,%lo(plr)($17)
	lw	$6,224($2)
	beq	$6,$0,$L56
	lui	$18,%hi(message_nottobefuckedwith)

	lw	$2,%lo(message_nottobefuckedwith)($18)
	beq	$2,$0,$L96
	lui	$4,%hi(w_message)

	bne	$3,$0,$L97
	addiu	$4,$4,%lo(w_message)

$L56:
	lui	$2,%hi(netgame)
$L95:
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L98
	lw	$31,60($sp)

	lui	$3,%hi(playeringame)
	lui	$17,%hi(players)
	lui	$18,%hi(chat_dest)
	lui	$19,%hi(w_inputbuffer)
	lui	$20,%hi(player_names)
	addiu	$3,$3,%lo(playeringame)
	addiu	$17,$17,%lo(players)
	addiu	$18,$18,%lo(chat_dest)
	addiu	$19,$19,%lo(w_inputbuffer)
	addiu	$20,$20,%lo(player_names)
	move	$16,$0
	lui	$fp,%hi(consoleplayer)
	li	$23,4			# 0x4
$L65:
	lw	$2,0($3)
	beq	$2,$0,$L59
	lw	$2,%lo(consoleplayer)($fp)

	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L59
	.set	at
	nop

	lb	$22,12($17)
	beq	$22,$0,$L59
	lbu	$5,12($17)

	slt	$2,$22,6
	beq	$2,$0,$L60
	nop

	sb	$22,0($18)
$L61:
	sb	$0,12($17)
$L59:
	addiu	$16,$16,1
	addiu	$3,$3,4
	addiu	$17,$17,288
	addiu	$18,$18,1
	addiu	$19,$19,120
	.set	noat
	xor	$1,$16,$23
	bne	$1,$0,$L65
	.set	at
	addiu	$20,$20,4

	lw	$31,60($sp)
$L98:
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L93:
	lui	$2,%hi(message_on)
	sw	$0,%lo(message_on)($2)
	lui	$2,%hi(message_nottobefuckedwith)
	b	$L54
	sw	$0,%lo(message_nottobefuckedwith)($2)

$L96:
	addiu	$4,$4,%lo(w_message)
$L97:
	jal	HUlib_addMessageToSText
	move	$5,$0

	lw	$3,%lo(plr)($17)
	lw	$2,%lo(message_dontfuckwithme)($16)
	sw	$0,224($3)
	li	$4,1			# 0x1
	lui	$3,%hi(message_on)
	sw	$4,%lo(message_on)($3)
	li	$3,140			# 0x8c
	sw	$3,%lo(message_counter)($21)
	sw	$2,%lo(message_nottobefuckedwith)($18)
	b	$L56
	sw	$0,%lo(message_dontfuckwithme)($16)

$L60:
	move	$4,$19
	jal	HUlib_keyInIText
	sw	$3,16($sp)

	beq	$2,$0,$L61
	lw	$3,16($sp)

	li	$2,13			# 0xd
	.set	noat
	xor	$1,$22,$2
	bne	$1,$0,$L61
	.set	at
	nop

	lw	$2,100($19)
	beq	$2,$0,$L99
	move	$4,$19

	lw	$2,%lo(consoleplayer)($fp)
	lb	$4,0($18)
	addiu	$2,$2,1
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L63
	.set	at
	li	$2,5			# 0x5

	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L63
	.set	at
	nop

$L62:
	move	$4,$19
$L99:
	jal	HUlib_resetIText
	sw	$3,16($sp)

	lw	$3,16($sp)
	b	$L59
	sb	$0,12($17)

$L63:
	lw	$5,0($20)
	lui	$4,%hi(w_message)
	addiu	$6,$19,16
	addiu	$4,$4,%lo(w_message)
	jal	HUlib_addMessageToSText
	sw	$3,16($sp)

	lui	$2,%hi(gamemode)
	lui	$6,%hi(message_nottobefuckedwith)
	lw	$5,%lo(gamemode)($2)
	li	$2,1			# 0x1
	sw	$2,%lo(message_nottobefuckedwith)($6)
	lui	$6,%hi(message_on)
	sw	$2,%lo(message_on)($6)
	li	$4,2			# 0x2
	li	$2,140			# 0x8c
	lw	$3,16($sp)
	.set	noat
	xor	$1,$5,$4
	beq	$1,$0,$L94
	.set	at
	sw	$2,%lo(message_counter)($21)

	li	$5,87			# 0x57
	move	$4,$0
	jal	S_StartSound
	sw	$3,16($sp)

	b	$L62
	lw	$3,16($sp)

$L94:
	li	$5,108			# 0x6c
	jal	S_StartSound
	move	$4,$0

	b	$L62
	lw	$3,16($sp)

	.set	macro
	.set	reorder
	.end	HU_Ticker
	.size	HU_Ticker, .-HU_Ticker
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"[Message unsent]\000"
	.text
	.align	2
	.globl	HU_queueChatChar
	.set	nomips16
	.set	nomicromips
	.ent	HU_queueChatChar
	.type	HU_queueChatChar, @function
HU_queueChatChar:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(head)
	lw	$3,%lo(head)($5)
	lui	$6,%hi(tail)
	addiu	$2,$3,1
	lw	$6,%lo(tail)($6)
	andi	$2,$2,0x7f
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L103
	.set	at
	lui	$6,%hi(chatchars)

	addiu	$6,$6,%lo(chatchars)
	addu	$3,$3,$6
	sb	$4,0($3)
	jr	$31
	sw	$2,%lo(head)($5)

$L103:
	lui	$2,%hi(plr)
	lw	$3,%lo(plr)($2)
	lui	$2,%hi($LC2)
	addiu	$2,$2,%lo($LC2)
	jr	$31
	sw	$2,224($3)

	.set	macro
	.set	reorder
	.end	HU_queueChatChar
	.size	HU_queueChatChar, .-HU_queueChatChar
	.align	2
	.globl	HU_dequeueChatChar
	.set	nomips16
	.set	nomicromips
	.ent	HU_dequeueChatChar
	.type	HU_dequeueChatChar, @function
HU_dequeueChatChar:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(tail)
	lui	$4,%hi(head)
	lw	$2,%lo(tail)($3)
	lw	$4,%lo(head)($4)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L106
	.set	at
	lui	$5,%hi(chatchars)

	addiu	$4,$2,1
	addiu	$5,$5,%lo(chatchars)
	addu	$2,$2,$5
	andi	$4,$4,0x7f
	lb	$2,0($2)
	jr	$31
	sw	$4,%lo(tail)($3)

$L106:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	HU_dequeueChatChar
	.size	HU_dequeueChatChar, .-HU_dequeueChatChar
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"You mumble to yourself\000"
	.align	2
$LC4:
	.ascii	"Who's there?\000"
	.align	2
$LC5:
	.ascii	"You scare yourself\000"
	.align	2
$LC6:
	.ascii	"You start to rave\000"
	.align	2
$LC7:
	.ascii	"You've lost it...\000"
	.text
	.align	2
	.globl	HU_Responder
	.set	nomips16
	.set	nomicromips
	.ent	HU_Responder
	.type	HU_Responder, @function
HU_Responder:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(playeringame)
	lw	$3,4($4)
	addiu	$sp,$sp,-40
	addiu	$2,$5,%lo(playeringame)
	li	$6,182			# 0xb6
	lw	$7,%lo(playeringame)($5)
	lw	$10,4($2)
	lw	$9,8($2)
	lw	$8,12($2)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L109
	.set	at
	sw	$16,16($sp)

	li	$6,184			# 0xb8
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L156
	.set	at
	lw	$5,0($4)

	bne	$5,$0,$L109
	lui	$17,%hi(chat_on)

	lw	$5,%lo(chat_on)($17)
	bne	$5,$0,$L113
	lui	$5,%hi(key_message_refresh)

	lw	$5,%lo(key_message_refresh)($5)
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L157
	.set	at
	li	$3,1			# 0x1

	lui	$3,%hi(netgame)
	lw	$3,%lo(netgame)($3)
	beq	$3,$0,$L109
	nop

	lui	$3,%hi(key_multi_msg)
	lw	$6,8($4)
	lw	$3,%lo(key_multi_msg)($3)
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L158
	.set	at
	addu	$3,$7,$10

	addu	$3,$3,$9
	addu	$3,$3,$8
	slt	$3,$3,3
	bne	$3,$0,$L107
	move	$16,$0

	lui	$3,%hi(consoleplayer)
	lw	$7,%lo(consoleplayer)($3)
	lui	$3,%hi(key_multi_msgplayer)
	addiu	$3,$3,%lo(key_multi_msgplayer)
	li	$5,4			# 0x4
$L126:
	lw	$4,0($3)
	.set	noat
	xor	$1,$6,$4
	beq	$1,$0,$L159
	.set	at
	nop

$L118:
	addiu	$16,$16,1
$L169:
	addiu	$3,$3,4
	.set	noat
	xor	$1,$16,$5
	bne	$1,$0,$L126
	.set	at
	addiu	$2,$2,4

$L109:
	move	$16,$0
$L107:
	lw	$31,36($sp)
$L168:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L113:
	lui	$2,%hi(altdown.2)
	lw	$2,%lo(altdown.2)($2)
	beq	$2,$0,$L127
	addiu	$3,$3,-48

	andi	$3,$3,0x00ff
	sltu	$2,$3,10
	beq	$2,$0,$L107
	move	$16,$0

	lui	$15,%hi(head)
	lw	$14,%lo(head)($15)
	sll	$2,$3,2
	lui	$4,%hi(tail)
	lui	$3,%hi(chat_macros)
	addiu	$13,$14,1
	addiu	$3,$3,%lo(chat_macros)
	lw	$12,%lo(tail)($4)
	addu	$2,$2,$3
	andi	$13,$13,0x7f
	.set	noat
	xor	$1,$13,$12
	beq	$1,$0,$L160
	.set	at
	lw	$5,0($2)

	lui	$3,%hi(chatchars)
	addiu	$3,$3,%lo(chatchars)
	lb	$11,0($5)
	addu	$3,$14,$3
	addiu	$2,$13,1
	li	$4,13			# 0xd
	sb	$4,0($3)
	sw	$13,%lo(head)($15)
	beq	$11,$0,$L141
	andi	$2,$2,0x7f

	lui	$18,%hi(plr)
	lw	$10,%lo(plr)($18)
	move	$14,$13
	move	$13,$2
$L129:
	lui	$7,%hi(chatchars)
	lui	$9,%hi($LC2)
	move	$3,$14
	move	$4,$5
	move	$8,$0
	addiu	$7,$7,%lo(chatchars)
	b	$L134
	addiu	$9,$9,%lo($LC2)

$L132:
	sb	$11,0($6)
	move	$3,$2
	li	$8,1			# 0x1
$L133:
	lb	$11,0($4)
	beq	$11,$0,$L161
	nop

$L134:
	addiu	$2,$3,1
	andi	$2,$2,0x7f
	addu	$6,$3,$7
	.set	noat
	xor	$1,$12,$2
	bne	$1,$0,$L132
	.set	at
	addiu	$4,$4,1

	b	$L133
	sw	$9,224($10)

$L157:
	lui	$2,%hi(message_on)
	sw	$3,%lo(message_on)($2)
	lui	$2,%hi(message_counter)
	li	$3,140			# 0x8c
	sw	$3,%lo(message_counter)($2)
	b	$L107
	li	$16,1			# 0x1

$L127:
	lw	$20,8($4)
	lui	$19,%hi(w_chat)
	andi	$18,$20,0x00ff
	move	$5,$18
	jal	HUlib_keyInIText
	addiu	$4,$19,%lo(w_chat)

	bne	$2,$0,$L162
	move	$16,$2

$L137:
	li	$2,13			# 0xd
	.set	noat
	xor	$1,$18,$2
	beq	$1,$0,$L163
	.set	at
	li	$2,27			# 0x1b

	.set	noat
	xor	$1,$18,$2
	bne	$1,$0,$L168
	.set	at
	lw	$31,36($sp)

	b	$L107
	sw	$0,%lo(chat_on)($17)

$L156:
	sltu	$5,$5,1
	lui	$2,%hi(altdown.2)
	b	$L109
	sw	$5,%lo(altdown.2)($2)

$L160:
	lui	$18,%hi(plr)
	lw	$10,%lo(plr)($18)
	lui	$2,%hi($LC2)
	addiu	$2,$2,%lo($LC2)
	sw	$2,224($10)
	lb	$11,0($5)
	bne	$11,$0,$L129
	nop

$L130:
	sw	$2,224($10)
$L136:
	lui	$16,%hi(lastmessage.0)
	addiu	$4,$16,%lo(lastmessage.0)
	li	$6,81			# 0x51
	jal	M_StringCopy
	sw	$0,%lo(chat_on)($17)

	lw	$2,%lo(plr)($18)
	addiu	$16,$16,%lo(lastmessage.0)
	sw	$16,224($2)
	b	$L107
	li	$16,1			# 0x1

$L163:
	addiu	$19,$19,%lo(w_chat)
	lw	$2,100($19)
	beq	$2,$0,$L107
	sw	$0,%lo(chat_on)($17)

	lui	$17,%hi(lastmessage.0)
	lui	$5,%hi(w_chat+16)
	addiu	$4,$17,%lo(lastmessage.0)
	li	$6,81			# 0x51
	jal	M_StringCopy
	addiu	$5,$5,%lo(w_chat+16)

	lui	$2,%hi(plr)
	lw	$2,%lo(plr)($2)
	addiu	$17,$17,%lo(lastmessage.0)
	b	$L107
	sw	$17,224($2)

$L162:
	lui	$5,%hi(head)
	lw	$3,%lo(head)($5)
	lui	$4,%hi(tail)
	addiu	$2,$3,1
	lw	$4,%lo(tail)($4)
	andi	$2,$2,0x7f
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L164
	.set	at
	nop

	lui	$4,%hi(chatchars)
	addiu	$4,$4,%lo(chatchars)
	addu	$3,$3,$4
	sb	$20,0($3)
	b	$L137
	sw	$2,%lo(head)($5)

$L161:
	beq	$8,$0,$L142
	nop

	addiu	$13,$3,1
	sw	$3,%lo(head)($15)
	andi	$13,$13,0x7f
$L131:
	.set	noat
	xor	$1,$13,$12
	beq	$1,$0,$L165
	.set	at
	lui	$2,%hi($LC2)

	lui	$2,%hi(chatchars)
	addiu	$2,$2,%lo(chatchars)
	addu	$3,$3,$2
	li	$2,13			# 0xd
	sb	$2,0($3)
	b	$L136
	sw	$13,%lo(head)($15)

$L159:
	lw	$4,0($2)
	beq	$4,$0,$L119
	nop

	.set	noat
	xor	$1,$16,$7
	bne	$1,$0,$L166
	.set	at
	lui	$9,%hi(num_nobrainers.1)

$L167:
	lw	$4,%lo(num_nobrainers.1)($9)
	lui	$8,%hi(plr)
	addiu	$4,$4,1
	slt	$10,$4,3
	lw	$8,%lo(plr)($8)
	beq	$10,$0,$L122
	sw	$4,%lo(num_nobrainers.1)($9)

	lui	$4,%hi($LC3)
	addiu	$4,$4,%lo($LC3)
	b	$L118
	sw	$4,224($8)

$L119:
	.set	noat
	xor	$1,$16,$7
	bne	$1,$0,$L169
	.set	at
	addiu	$16,$16,1

	addiu	$16,$16,-1
	b	$L167
	lui	$9,%hi(num_nobrainers.1)

$L165:
	lw	$10,%lo(plr)($18)
	b	$L130
	addiu	$2,$2,%lo($LC2)

$L142:
	b	$L131
	move	$3,$14

$L158:
	lui	$4,%hi(w_chat)
	li	$2,1			# 0x1
	addiu	$4,$4,%lo(w_chat)
	jal	HUlib_resetIText
	sw	$2,%lo(chat_on)($17)

	lui	$4,%hi(head)
	lw	$3,%lo(head)($4)
	lui	$5,%hi(tail)
	addiu	$2,$3,1
	lw	$5,%lo(tail)($5)
	andi	$2,$2,0x7f
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L155
	.set	at
	nop

	lui	$5,%hi(chatchars)
	addiu	$5,$5,%lo(chatchars)
	addu	$3,$3,$5
	li	$5,5			# 0x5
	sb	$5,0($3)
	sw	$2,%lo(head)($4)
	b	$L107
	li	$16,1			# 0x1

$L164:
	lui	$2,%hi(plr)
	lw	$3,%lo(plr)($2)
	lui	$2,%hi($LC2)
	addiu	$2,$2,%lo($LC2)
	b	$L137
	sw	$2,224($3)

$L122:
	slt	$9,$4,6
	beq	$9,$0,$L123
	slt	$9,$4,9

	lui	$4,%hi($LC4)
	addiu	$4,$4,%lo($LC4)
	b	$L118
	sw	$4,224($8)

$L141:
	move	$3,$13
	lui	$18,%hi(plr)
	b	$L131
	move	$13,$2

$L155:
	lui	$2,%hi(plr)
	lw	$3,%lo(plr)($2)
	lui	$2,%hi($LC2)
	addiu	$2,$2,%lo($LC2)
	sw	$2,224($3)
	b	$L107
	li	$16,1			# 0x1

$L123:
	beq	$9,$0,$L124
	slt	$4,$4,32

	lui	$4,%hi($LC5)
	addiu	$4,$4,%lo($LC5)
	b	$L118
	sw	$4,224($8)

$L124:
	beq	$4,$0,$L125
	lui	$4,%hi($LC7)

	lui	$4,%hi($LC6)
	addiu	$4,$4,%lo($LC6)
	b	$L118
	sw	$4,224($8)

$L166:
	lui	$4,%hi(w_chat)
	li	$2,1			# 0x1
	addiu	$4,$4,%lo(w_chat)
	jal	HUlib_resetIText
	sw	$2,%lo(chat_on)($17)

	lui	$5,%hi(head)
	lw	$3,%lo(head)($5)
	lui	$4,%hi(tail)
	addiu	$2,$3,1
	lw	$4,%lo(tail)($4)
	andi	$2,$2,0x7f
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L155
	.set	at
	lui	$4,%hi(chatchars)

	addiu	$4,$4,%lo(chatchars)
	addiu	$16,$16,1
	addu	$3,$3,$4
	sb	$16,0($3)
	sw	$2,%lo(head)($5)
	b	$L107
	li	$16,1			# 0x1

$L125:
	addiu	$4,$4,%lo($LC7)
	b	$L118
	sw	$4,224($8)

	.set	macro
	.set	reorder
	.end	HU_Responder
	.size	HU_Responder, .-HU_Responder
	.local	lastmessage.0
	.comm	lastmessage.0,81,4
	.local	num_nobrainers.1
	.comm	num_nobrainers.1,4,4
	.local	altdown.2
	.comm	altdown.2,4,4
	.local	tail
	.comm	tail,4,4
	.local	head
	.comm	head,4,4
	.local	chatchars
	.comm	chatchars,128,4
	.globl	mapnames_commercial
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"level 1: entryway\000"
	.align	2
$LC9:
	.ascii	"level 2: underhalls\000"
	.align	2
$LC10:
	.ascii	"level 3: the gantlet\000"
	.align	2
$LC11:
	.ascii	"level 4: the focus\000"
	.align	2
$LC12:
	.ascii	"level 5: the waste tunnels\000"
	.align	2
$LC13:
	.ascii	"level 6: the crusher\000"
	.align	2
$LC14:
	.ascii	"level 7: dead simple\000"
	.align	2
$LC15:
	.ascii	"level 8: tricks and traps\000"
	.align	2
$LC16:
	.ascii	"level 9: the pit\000"
	.align	2
$LC17:
	.ascii	"level 10: refueling base\000"
	.align	2
$LC18:
	.ascii	"level 11: 'o' of destruction!\000"
	.align	2
$LC19:
	.ascii	"level 12: the factory\000"
	.align	2
$LC20:
	.ascii	"level 13: downtown\000"
	.align	2
$LC21:
	.ascii	"level 14: the inmost dens\000"
	.align	2
$LC22:
	.ascii	"level 15: industrial zone\000"
	.align	2
$LC23:
	.ascii	"level 16: suburbs\000"
	.align	2
$LC24:
	.ascii	"level 17: tenements\000"
	.align	2
$LC25:
	.ascii	"level 18: the courtyard\000"
	.align	2
$LC26:
	.ascii	"level 19: the citadel\000"
	.align	2
$LC27:
	.ascii	"level 20: gotcha!\000"
	.align	2
$LC28:
	.ascii	"level 21: nirvana\000"
	.align	2
$LC29:
	.ascii	"level 22: the catacombs\000"
	.align	2
$LC30:
	.ascii	"level 23: barrels o' fun\000"
	.align	2
$LC31:
	.ascii	"level 24: the chasm\000"
	.align	2
$LC32:
	.ascii	"level 25: bloodfalls\000"
	.align	2
$LC33:
	.ascii	"level 26: the abandoned mines\000"
	.align	2
$LC34:
	.ascii	"level 27: monster condo\000"
	.align	2
$LC35:
	.ascii	"level 28: the spirit world\000"
	.align	2
$LC36:
	.ascii	"level 29: the living end\000"
	.align	2
$LC37:
	.ascii	"level 30: icon of sin\000"
	.align	2
$LC38:
	.ascii	"level 31: wolfenstein\000"
	.align	2
$LC39:
	.ascii	"level 32: grosse\000"
	.align	2
$LC40:
	.ascii	"level 1: congo\000"
	.align	2
$LC41:
	.ascii	"level 2: well of souls\000"
	.align	2
$LC42:
	.ascii	"level 3: aztec\000"
	.align	2
$LC43:
	.ascii	"level 4: caged\000"
	.align	2
$LC44:
	.ascii	"level 5: ghost town\000"
	.align	2
$LC45:
	.ascii	"level 6: baron's lair\000"
	.align	2
$LC46:
	.ascii	"level 7: caughtyard\000"
	.align	2
$LC47:
	.ascii	"level 8: realm\000"
	.align	2
$LC48:
	.ascii	"level 9: abattoire\000"
	.align	2
$LC49:
	.ascii	"level 10: onslaught\000"
	.align	2
$LC50:
	.ascii	"level 11: hunted\000"
	.align	2
$LC51:
	.ascii	"level 12: speed\000"
	.align	2
$LC52:
	.ascii	"level 13: the crypt\000"
	.align	2
$LC53:
	.ascii	"level 14: genesis\000"
	.align	2
$LC54:
	.ascii	"level 15: the twilight\000"
	.align	2
$LC55:
	.ascii	"level 16: the omen\000"
	.align	2
$LC56:
	.ascii	"level 17: compound\000"
	.align	2
$LC57:
	.ascii	"level 18: neurosphere\000"
	.align	2
$LC58:
	.ascii	"level 19: nme\000"
	.align	2
$LC59:
	.ascii	"level 20: the death domain\000"
	.align	2
$LC60:
	.ascii	"level 21: slayer\000"
	.align	2
$LC61:
	.ascii	"level 22: impossible mission\000"
	.align	2
$LC62:
	.ascii	"level 23: tombstone\000"
	.align	2
$LC63:
	.ascii	"level 24: the final frontier\000"
	.align	2
$LC64:
	.ascii	"level 25: the temple of darkness\000"
	.align	2
$LC65:
	.ascii	"level 26: bunker\000"
	.align	2
$LC66:
	.ascii	"level 27: anti-christ\000"
	.align	2
$LC67:
	.ascii	"level 28: the sewers\000"
	.align	2
$LC68:
	.ascii	"level 29: odyssey of noises\000"
	.align	2
$LC69:
	.ascii	"level 30: the gateway of hell\000"
	.align	2
$LC70:
	.ascii	"level 31: cyberden\000"
	.align	2
$LC71:
	.ascii	"level 32: go 2 it\000"
	.align	2
$LC72:
	.ascii	"level 1: system control\000"
	.align	2
$LC73:
	.ascii	"level 2: human bbq\000"
	.align	2
$LC74:
	.ascii	"level 3: power control\000"
	.align	2
$LC75:
	.ascii	"level 4: wormhole\000"
	.align	2
$LC76:
	.ascii	"level 5: hanger\000"
	.align	2
$LC77:
	.ascii	"level 6: open season\000"
	.align	2
$LC78:
	.ascii	"level 7: prison\000"
	.align	2
$LC79:
	.ascii	"level 8: metal\000"
	.align	2
$LC80:
	.ascii	"level 9: stronghold\000"
	.align	2
$LC81:
	.ascii	"level 10: redemption\000"
	.align	2
$LC82:
	.ascii	"level 11: storage facility\000"
	.align	2
$LC83:
	.ascii	"level 12: crater\000"
	.align	2
$LC84:
	.ascii	"level 13: nukage processing\000"
	.align	2
$LC85:
	.ascii	"level 14: steel works\000"
	.align	2
$LC86:
	.ascii	"level 15: dead zone\000"
	.align	2
$LC87:
	.ascii	"level 16: deepest reaches\000"
	.align	2
$LC88:
	.ascii	"level 17: processing area\000"
	.align	2
$LC89:
	.ascii	"level 18: mill\000"
	.align	2
$LC90:
	.ascii	"level 19: shipping/respawning\000"
	.align	2
$LC91:
	.ascii	"level 20: central processing\000"
	.align	2
$LC92:
	.ascii	"level 21: administration center\000"
	.align	2
$LC93:
	.ascii	"level 22: habitat\000"
	.align	2
$LC94:
	.ascii	"level 23: lunar mining project\000"
	.align	2
$LC95:
	.ascii	"level 24: quarry\000"
	.align	2
$LC96:
	.ascii	"level 25: baron's den\000"
	.align	2
$LC97:
	.ascii	"level 26: ballistyx\000"
	.align	2
$LC98:
	.ascii	"level 27: mount pain\000"
	.align	2
$LC99:
	.ascii	"level 28: heck\000"
	.align	2
$LC100:
	.ascii	"level 29: river styx\000"
	.align	2
$LC101:
	.ascii	"level 30: last call\000"
	.align	2
$LC102:
	.ascii	"level 31: pharaoh\000"
	.align	2
$LC103:
	.ascii	"level 32: caribbean\000"
	.data
	.align	2
	.type	mapnames_commercial, @object
	.size	mapnames_commercial, 384
mapnames_commercial:
	.word	$LC8
	.word	$LC9
	.word	$LC10
	.word	$LC11
	.word	$LC12
	.word	$LC13
	.word	$LC14
	.word	$LC15
	.word	$LC16
	.word	$LC17
	.word	$LC18
	.word	$LC19
	.word	$LC20
	.word	$LC21
	.word	$LC22
	.word	$LC23
	.word	$LC24
	.word	$LC25
	.word	$LC26
	.word	$LC27
	.word	$LC28
	.word	$LC29
	.word	$LC30
	.word	$LC31
	.word	$LC32
	.word	$LC33
	.word	$LC34
	.word	$LC35
	.word	$LC36
	.word	$LC37
	.word	$LC38
	.word	$LC39
	.word	$LC40
	.word	$LC41
	.word	$LC42
	.word	$LC43
	.word	$LC44
	.word	$LC45
	.word	$LC46
	.word	$LC47
	.word	$LC48
	.word	$LC49
	.word	$LC50
	.word	$LC51
	.word	$LC52
	.word	$LC53
	.word	$LC54
	.word	$LC55
	.word	$LC56
	.word	$LC57
	.word	$LC58
	.word	$LC59
	.word	$LC60
	.word	$LC61
	.word	$LC62
	.word	$LC63
	.word	$LC64
	.word	$LC65
	.word	$LC66
	.word	$LC67
	.word	$LC68
	.word	$LC69
	.word	$LC70
	.word	$LC71
	.word	$LC72
	.word	$LC73
	.word	$LC74
	.word	$LC75
	.word	$LC76
	.word	$LC77
	.word	$LC78
	.word	$LC79
	.word	$LC80
	.word	$LC81
	.word	$LC82
	.word	$LC83
	.word	$LC84
	.word	$LC85
	.word	$LC86
	.word	$LC87
	.word	$LC88
	.word	$LC89
	.word	$LC90
	.word	$LC91
	.word	$LC92
	.word	$LC93
	.word	$LC94
	.word	$LC95
	.word	$LC96
	.word	$LC97
	.word	$LC98
	.word	$LC99
	.word	$LC100
	.word	$LC101
	.word	$LC102
	.word	$LC103
	.globl	mapnames
	.section	.rodata.str1.4
	.align	2
$LC104:
	.ascii	"E1M1: Hangar\000"
	.align	2
$LC105:
	.ascii	"E1M2: Nuclear Plant\000"
	.align	2
$LC106:
	.ascii	"E1M3: Toxin Refinery\000"
	.align	2
$LC107:
	.ascii	"E1M4: Command Control\000"
	.align	2
$LC108:
	.ascii	"E1M5: Phobos Lab\000"
	.align	2
$LC109:
	.ascii	"E1M6: Central Processing\000"
	.align	2
$LC110:
	.ascii	"E1M7: Computer Station\000"
	.align	2
$LC111:
	.ascii	"E1M8: Phobos Anomaly\000"
	.align	2
$LC112:
	.ascii	"E1M9: Military Base\000"
	.align	2
$LC113:
	.ascii	"E2M1: Deimos Anomaly\000"
	.align	2
$LC114:
	.ascii	"E2M2: Containment Area\000"
	.align	2
$LC115:
	.ascii	"E2M3: Refinery\000"
	.align	2
$LC116:
	.ascii	"E2M4: Deimos Lab\000"
	.align	2
$LC117:
	.ascii	"E2M5: Command Center\000"
	.align	2
$LC118:
	.ascii	"E2M6: Halls of the Damned\000"
	.align	2
$LC119:
	.ascii	"E2M7: Spawning Vats\000"
	.align	2
$LC120:
	.ascii	"E2M8: Tower of Babel\000"
	.align	2
$LC121:
	.ascii	"E2M9: Fortress of Mystery\000"
	.align	2
$LC122:
	.ascii	"E3M1: Hell Keep\000"
	.align	2
$LC123:
	.ascii	"E3M2: Slough of Despair\000"
	.align	2
$LC124:
	.ascii	"E3M3: Pandemonium\000"
	.align	2
$LC125:
	.ascii	"E3M4: House of Pain\000"
	.align	2
$LC126:
	.ascii	"E3M5: Unholy Cathedral\000"
	.align	2
$LC127:
	.ascii	"E3M6: Mt. Erebus\000"
	.align	2
$LC128:
	.ascii	"E3M7: Limbo\000"
	.align	2
$LC129:
	.ascii	"E3M8: Dis\000"
	.align	2
$LC130:
	.ascii	"E3M9: Warrens\000"
	.align	2
$LC131:
	.ascii	"E4M1: Hell Beneath\000"
	.align	2
$LC132:
	.ascii	"E4M2: Perfect Hatred\000"
	.align	2
$LC133:
	.ascii	"E4M3: Sever The Wicked\000"
	.align	2
$LC134:
	.ascii	"E4M4: Unruly Evil\000"
	.align	2
$LC135:
	.ascii	"E4M5: They Will Repent\000"
	.align	2
$LC136:
	.ascii	"E4M6: Against Thee Wickedly\000"
	.align	2
$LC137:
	.ascii	"E4M7: And Hell Followed\000"
	.align	2
$LC138:
	.ascii	"E4M8: Unto The Cruel\000"
	.align	2
$LC139:
	.ascii	"E4M9: Fear\000"
	.align	2
$LC140:
	.ascii	"NEWLEVEL\000"
	.data
	.align	2
	.type	mapnames, @object
	.size	mapnames, 180
mapnames:
	.word	$LC104
	.word	$LC105
	.word	$LC106
	.word	$LC107
	.word	$LC108
	.word	$LC109
	.word	$LC110
	.word	$LC111
	.word	$LC112
	.word	$LC113
	.word	$LC114
	.word	$LC115
	.word	$LC116
	.word	$LC117
	.word	$LC118
	.word	$LC119
	.word	$LC120
	.word	$LC121
	.word	$LC122
	.word	$LC123
	.word	$LC124
	.word	$LC125
	.word	$LC126
	.word	$LC127
	.word	$LC128
	.word	$LC129
	.word	$LC130
	.word	$LC131
	.word	$LC132
	.word	$LC133
	.word	$LC134
	.word	$LC135
	.word	$LC136
	.word	$LC137
	.word	$LC138
	.word	$LC139
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.word	$LC140
	.local	headsupactive
	.comm	headsupactive,4,4
	.local	message_counter
	.comm	message_counter,4,4
	.local	w_message
	.comm	w_message,448,4
	.local	message_nottobefuckedwith
	.comm	message_nottobefuckedwith,4,4
	.globl	message_dontfuckwithme
	.section	.bss,"aw",@nobits
	.align	2
	.type	message_dontfuckwithme, @object
	.size	message_dontfuckwithme, 4
message_dontfuckwithme:
	.space	4
	.local	message_on
	.comm	message_on,4,4
	.local	w_inputbuffer
	.comm	w_inputbuffer,480,4
	.local	chat_dest
	.comm	chat_dest,4,4
	.local	always_off
	.comm	always_off,4,4
	.local	w_chat
	.comm	w_chat,120,4
	.globl	chat_on
	.align	2
	.type	chat_on, @object
	.size	chat_on, 4
chat_on:
	.space	4
	.local	w_title
	.comm	w_title,108,4
	.globl	hu_font
	.align	2
	.type	hu_font, @object
	.size	hu_font, 252
hu_font:
	.space	252
	.local	plr
	.comm	plr,4,4
	.globl	chat_char
	.type	chat_char, @object
	.size	chat_char, 1
chat_char:
	.space	1
	.globl	player_names
	.section	.rodata.str1.4
	.align	2
$LC141:
	.ascii	"Green: \000"
	.align	2
$LC142:
	.ascii	"Indigo: \000"
	.align	2
$LC143:
	.ascii	"Brown: \000"
	.align	2
$LC144:
	.ascii	"Red: \000"
	.data
	.align	2
	.type	player_names, @object
	.size	player_names, 16
player_names:
	.word	$LC141
	.word	$LC142
	.word	$LC143
	.word	$LC144
	.globl	chat_macros
	.section	.rodata.str1.4
	.align	2
$LC145:
	.ascii	"No\000"
	.align	2
$LC146:
	.ascii	"I'm ready to kick butt!\000"
	.align	2
$LC147:
	.ascii	"I'm OK.\000"
	.align	2
$LC148:
	.ascii	"I'm not looking too good!\000"
	.align	2
$LC149:
	.ascii	"Help!\000"
	.align	2
$LC150:
	.ascii	"You suck!\000"
	.align	2
$LC151:
	.ascii	"Next time, scumbag...\000"
	.align	2
$LC152:
	.ascii	"Come here!\000"
	.align	2
$LC153:
	.ascii	"I'll take care of it.\000"
	.align	2
$LC154:
	.ascii	"Yes\000"
	.data
	.align	2
	.type	chat_macros, @object
	.size	chat_macros, 40
chat_macros:
	.word	$LC145
	.word	$LC146
	.word	$LC147
	.word	$LC148
	.word	$LC149
	.word	$LC150
	.word	$LC151
	.word	$LC152
	.word	$LC153
	.word	$LC154
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
