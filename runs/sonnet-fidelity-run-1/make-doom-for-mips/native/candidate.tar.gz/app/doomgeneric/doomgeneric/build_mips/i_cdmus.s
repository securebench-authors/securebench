	.file	1 "i_cdmus.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	I_CDMusInit
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusInit
	.type	I_CDMusInit, @function
I_CDMusInit:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusInit
	.size	I_CDMusInit, .-I_CDMusInit
	.align	2
	.globl	I_CDMusPrintStartup
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusPrintStartup
	.type	I_CDMusPrintStartup, @function
I_CDMusPrintStartup:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_CDMusPrintStartup
	.size	I_CDMusPrintStartup, .-I_CDMusPrintStartup
	.align	2
	.globl	I_CDMusPlay
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusPlay
	.type	I_CDMusPlay, @function
I_CDMusPlay:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusPlay
	.size	I_CDMusPlay, .-I_CDMusPlay
	.align	2
	.globl	I_CDMusStop
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusStop
	.type	I_CDMusStop, @function
I_CDMusStop:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusStop
	.size	I_CDMusStop, .-I_CDMusStop
	.align	2
	.globl	I_CDMusResume
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusResume
	.type	I_CDMusResume, @function
I_CDMusResume:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusResume
	.size	I_CDMusResume, .-I_CDMusResume
	.align	2
	.globl	I_CDMusSetVolume
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusSetVolume
	.type	I_CDMusSetVolume, @function
I_CDMusSetVolume:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(cd_Error)
	sw	$0,%lo(cd_Error)($2)
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusSetVolume
	.size	I_CDMusSetVolume, .-I_CDMusSetVolume
	.align	2
	.globl	I_CDMusFirstTrack
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusFirstTrack
	.type	I_CDMusFirstTrack, @function
I_CDMusFirstTrack:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusFirstTrack
	.size	I_CDMusFirstTrack, .-I_CDMusFirstTrack
	.align	2
	.globl	I_CDMusLastTrack
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusLastTrack
	.type	I_CDMusLastTrack, @function
I_CDMusLastTrack:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusLastTrack
	.size	I_CDMusLastTrack, .-I_CDMusLastTrack
	.align	2
	.globl	I_CDMusTrackLength
	.set	nomips16
	.set	nomicromips
	.ent	I_CDMusTrackLength
	.type	I_CDMusTrackLength, @function
I_CDMusTrackLength:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_CDMusTrackLength
	.size	I_CDMusTrackLength, .-I_CDMusTrackLength
	.globl	cd_Error
	.section	.bss,"aw",@nobits
	.align	2
	.type	cd_Error, @object
	.size	cd_Error, 4
cd_Error:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
