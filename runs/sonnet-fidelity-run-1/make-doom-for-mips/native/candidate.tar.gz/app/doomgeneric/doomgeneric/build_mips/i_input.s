	.file	1 "i_input.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	I_GetEvent
	.set	nomips16
	.set	nomicromips
	.ent	I_GetEvent
	.type	I_GetEvent, @function
I_GetEvent:
	.frame	$sp,64,$31		# vars= 32, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$18,56($sp)
	lui	$18,%hi(shiftxform)
	sw	$17,52($sp)
	sw	$16,48($sp)
	sw	$31,60($sp)
	lui	$17,%hi(shiftdown)
	li	$16,182			# 0xb6
	addiu	$18,$18,%lo(shiftxform)
	addiu	$5,$sp,40
$L28:
	jal	DG_GetKey
	addiu	$4,$sp,36

	beq	$2,$0,$L29
	lw	$31,60($sp)

	lw	$3,36($sp)
$L31:
	beq	$3,$0,$L3
	lbu	$2,40($sp)

	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L24
	.set	at
	lw	$3,%lo(shiftdown)($17)

	sw	$0,16($sp)
	blez	$3,$L25
	sw	$2,20($sp)

	sll	$3,$2,24
	sra	$3,$3,24
	bltz	$3,$L30
	move	$3,$0

	addu	$3,$18,$2
	lbu	$3,0($3)
$L8:
$L30:
	bne	$2,$0,$L11
	sw	$3,24($sp)

	addiu	$5,$sp,40
	jal	DG_GetKey
	addiu	$4,$sp,36

	bne	$2,$0,$L31
	lw	$3,36($sp)

	lw	$31,60($sp)
$L29:
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,64

$L3:
	li	$3,182			# 0xb6
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L26
	.set	at
	li	$3,1			# 0x1

	sw	$3,16($sp)
	sw	$2,20($sp)
	bne	$2,$0,$L10
	sw	$0,24($sp)

	lw	$31,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,64

$L24:
	addiu	$3,$3,1
	sw	$3,%lo(shiftdown)($17)
	sw	$0,16($sp)
	blez	$3,$L27
	sw	$16,20($sp)

	sw	$0,24($sp)
$L11:
	jal	D_PostEvent
	addiu	$4,$sp,16

	b	$L28
	addiu	$5,$sp,40

$L25:
	b	$L8
	move	$3,$2

$L26:
	lui	$4,%hi(shiftdown)
	lw	$3,%lo(shiftdown)($4)
	sw	$2,20($sp)
	addiu	$3,$3,-1
	sw	$3,%lo(shiftdown)($4)
	li	$3,1			# 0x1
	sw	$3,16($sp)
	sw	$0,24($sp)
$L10:
	jal	D_PostEvent
	addiu	$4,$sp,16

	lw	$31,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,64

$L27:
	b	$L11
	sw	$16,24($sp)

	.set	macro
	.set	reorder
	.end	I_GetEvent
	.size	I_GetEvent, .-I_GetEvent
	.align	2
	.globl	I_InitInput
	.set	nomips16
	.set	nomicromips
	.ent	I_InitInput
	.type	I_InitInput, @function
I_InitInput:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_InitInput
	.size	I_InitInput, .-I_InitInput
	.rdata
	.align	2
	.type	shiftxform, @object
	.size	shiftxform, 128
shiftxform:
	.ascii	"\000\001\002\003\004\005\006\007\010\011\012\013\014\015"
	.ascii	"\016\017\020\021\022\023\024\025\026\027\030\031\032\033"
	.ascii	"\034\035\036\037 !\"#$%&\"()*+<_>?)!@#$%^&*(::<+>?@ABCDE"
	.ascii	"FGHIJKLMNOPQRSTUVWXYZ[!]\"_'ABCDEFGHIJKLMNOPQRSTUVWXYZ{|"
	.ascii	"}~\177"
	.local	shiftdown
	.comm	shiftdown,4,4
	.globl	vanilla_keyboard_mapping
	.data
	.align	2
	.type	vanilla_keyboard_mapping, @object
	.size	vanilla_keyboard_mapping, 4
vanilla_keyboard_mapping:
	.word	1
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
