	.file	1 "i_joystick.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	I_ShutdownJoystick
	.set	nomips16
	.set	nomicromips
	.ent	I_ShutdownJoystick
	.type	I_ShutdownJoystick, @function
I_ShutdownJoystick:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_ShutdownJoystick
	.size	I_ShutdownJoystick, .-I_ShutdownJoystick
	.align	2
	.globl	I_InitJoystick
	.set	nomips16
	.set	nomicromips
	.ent	I_InitJoystick
	.type	I_InitJoystick, @function
I_InitJoystick:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_InitJoystick
	.size	I_InitJoystick, .-I_InitJoystick
	.align	2
	.globl	I_UpdateJoystick
	.set	nomips16
	.set	nomicromips
	.ent	I_UpdateJoystick
	.type	I_UpdateJoystick, @function
I_UpdateJoystick:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_UpdateJoystick
	.size	I_UpdateJoystick, .-I_UpdateJoystick
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"use_joystick\000"
	.align	2
$LC1:
	.ascii	"joystick_index\000"
	.align	2
$LC2:
	.ascii	"joystick_x_axis\000"
	.align	2
$LC3:
	.ascii	"joystick_y_axis\000"
	.align	2
$LC4:
	.ascii	"joystick_strafe_axis\000"
	.align	2
$LC5:
	.ascii	"joystick_x_invert\000"
	.align	2
$LC6:
	.ascii	"joystick_y_invert\000"
	.align	2
$LC7:
	.ascii	"joystick_strafe_invert\000"
	.align	2
$LC8:
	.ascii	"joystick_physical_button%i\000"
	.text
	.align	2
	.globl	I_BindJoystickVariables
	.set	nomips16
	.set	nomicromips
	.ent	I_BindJoystickVariables
	.type	I_BindJoystickVariables, @function
I_BindJoystickVariables:
	.frame	$sp,72,$31		# vars= 32, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(usejoystick)
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-72
	addiu	$5,$5,%lo(usejoystick)
	addiu	$4,$4,%lo($LC0)
	sw	$31,68($sp)
	sw	$19,64($sp)
	sw	$18,60($sp)
	sw	$17,56($sp)
	jal	M_BindVariable
	sw	$16,52($sp)

	lui	$5,%hi(joystick_index)
	lui	$4,%hi($LC1)
	addiu	$5,$5,%lo(joystick_index)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC1)

	lui	$5,%hi(joystick_x_axis)
	lui	$4,%hi($LC2)
	addiu	$5,$5,%lo(joystick_x_axis)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC2)

	lui	$5,%hi(joystick_y_axis)
	lui	$4,%hi($LC3)
	addiu	$5,$5,%lo(joystick_y_axis)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC3)

	lui	$5,%hi(joystick_strafe_axis)
	lui	$4,%hi($LC4)
	addiu	$5,$5,%lo(joystick_strafe_axis)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC4)

	lui	$5,%hi(joystick_x_invert)
	lui	$4,%hi($LC5)
	addiu	$5,$5,%lo(joystick_x_invert)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC5)

	lui	$5,%hi(joystick_y_invert)
	lui	$4,%hi($LC6)
	addiu	$5,$5,%lo(joystick_y_invert)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC6)

	lui	$5,%hi(joystick_strafe_invert)
	lui	$4,%hi($LC7)
	addiu	$5,$5,%lo(joystick_strafe_invert)
	addiu	$4,$4,%lo($LC7)
	lui	$17,%hi(joystick_physical_buttons)
	jal	M_BindVariable
	lui	$18,%hi($LC8)

	addiu	$17,$17,%lo(joystick_physical_buttons)
	move	$16,$0
	addiu	$18,$18,%lo($LC8)
	li	$19,10			# 0xa
$L6:
	move	$7,$16
	move	$6,$18
	addiu	$4,$sp,16
	jal	M_snprintf
	li	$5,32			# 0x20

	addiu	$16,$16,1
	move	$5,$17
	jal	M_BindVariable
	addiu	$4,$sp,16

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L6
	.set	at
	addiu	$17,$17,4

	lw	$31,68($sp)
	lw	$19,64($sp)
	lw	$18,60($sp)
	lw	$17,56($sp)
	lw	$16,52($sp)
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	I_BindJoystickVariables
	.size	I_BindJoystickVariables, .-I_BindJoystickVariables
	.data
	.align	2
	.type	joystick_physical_buttons, @object
	.size	joystick_physical_buttons, 40
joystick_physical_buttons:
	.word	0
	.word	1
	.word	2
	.word	3
	.word	4
	.word	5
	.word	6
	.word	7
	.word	8
	.word	9
	.local	joystick_strafe_invert
	.comm	joystick_strafe_invert,4,4
	.align	2
	.type	joystick_strafe_axis, @object
	.size	joystick_strafe_axis, 4
joystick_strafe_axis:
	.word	-1
	.local	joystick_y_invert
	.comm	joystick_y_invert,4,4
	.align	2
	.type	joystick_y_axis, @object
	.size	joystick_y_axis, 4
joystick_y_axis:
	.word	1
	.local	joystick_x_invert
	.comm	joystick_x_invert,4,4
	.local	joystick_x_axis
	.comm	joystick_x_axis,4,4
	.align	2
	.type	joystick_index, @object
	.size	joystick_index, 4
joystick_index:
	.word	-1
	.local	usejoystick
	.comm	usejoystick,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
