	.file	1 "i_scale.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Scale2x
	.type	I_Scale2x, @function
I_Scale2x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_pitch)
	lw	$9,%lo(dest_pitch)($2)
	lui	$8,%hi(src_buffer)
	multu	$9,$5
	mflo	$2
	sll	$11,$9,1
	addu	$3,$2,$4
	lui	$2,%hi(dest_buffer)
	lw	$10,%lo(dest_buffer)($2)
	sll	$3,$3,1
	sll	$2,$5,2
	addu	$10,$10,$3
	addu	$2,$2,$5
	slt	$3,$5,$7
	lw	$8,%lo(src_buffer)($8)
	sll	$2,$2,6
	beq	$3,$0,$L2
	addu	$9,$10,$9

	addu	$2,$2,$6
	addu	$8,$8,$2
	subu	$13,$4,$6
	slt	$12,$4,$6
$L3:
	beq	$12,$0,$L5
	addu	$2,$13,$8

	move	$4,$9
	move	$3,$10
$L4:
	lbu	$6,0($2)
	addiu	$4,$4,2
	sb	$6,0($3)
	sb	$6,1($3)
	lbu	$6,0($2)
	addiu	$2,$2,1
	addiu	$3,$3,2
	sb	$6,-2($4)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L4
	.set	at
	sb	$6,-1($4)

$L5:
	addiu	$5,$5,1
	addu	$10,$10,$11
	addu	$9,$9,$11
	.set	noat
	xor	$1,$7,$5
	bne	$1,$0,$L3
	.set	at
	addiu	$8,$8,320

$L2:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Scale2x
	.size	I_Scale2x, .-I_Scale2x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Scale3x
	.type	I_Scale3x, @function
I_Scale3x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_pitch)
	lw	$11,%lo(dest_pitch)($2)
	lui	$8,%hi(src_buffer)
	multu	$11,$5
	mflo	$2
	sll	$13,$11,1
	addu	$3,$2,$4
	lui	$2,%hi(dest_buffer)
	lw	$12,%lo(dest_buffer)($2)
	sll	$2,$3,1
	addu	$3,$2,$3
	addu	$12,$12,$3
	sll	$2,$5,2
	addu	$2,$2,$5
	addu	$14,$12,$11
	slt	$3,$5,$7
	addu	$13,$13,$11
	lw	$10,%lo(src_buffer)($8)
	sll	$2,$2,6
	beq	$3,$0,$L10
	addu	$11,$14,$11

	addu	$2,$2,$6
	subu	$15,$4,$6
	addu	$10,$10,$2
	slt	$4,$4,$6
$L11:
	beq	$4,$0,$L13
	addu	$2,$15,$10

	move	$8,$11
	move	$6,$14
	move	$3,$12
$L12:
	lbu	$9,0($2)
	addiu	$6,$6,3
	sb	$9,0($3)
	sb	$9,1($3)
	lbu	$9,0($2)
	addiu	$8,$8,3
	sb	$9,2($3)
	sb	$9,-3($6)
	lbu	$9,0($2)
	addiu	$2,$2,1
	sb	$9,-2($6)
	sb	$9,-1($6)
	lbu	$9,-1($2)
	addiu	$3,$3,3
	sb	$9,-3($8)
	sb	$9,-2($8)
	lbu	$9,-1($2)
	.set	noat
	xor	$1,$2,$10
	bne	$1,$0,$L12
	.set	at
	sb	$9,-1($8)

$L13:
	addiu	$5,$5,1
	addu	$12,$12,$13
	addu	$14,$14,$13
	addu	$11,$11,$13
	.set	noat
	xor	$1,$7,$5
	bne	$1,$0,$L11
	.set	at
	addiu	$10,$10,320

$L10:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Scale3x
	.size	I_Scale3x, .-I_Scale3x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Scale4x
	.type	I_Scale4x, @function
I_Scale4x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_pitch)
	lw	$13,%lo(dest_pitch)($2)
	lui	$8,%hi(src_buffer)
	multu	$13,$5
	mflo	$3
	sll	$12,$13,2
	addu	$2,$3,$4
	lui	$3,%hi(dest_buffer)
	lw	$14,%lo(dest_buffer)($3)
	sll	$2,$2,2
	addu	$14,$14,$2
	addu	$15,$14,$13
	sll	$2,$5,2
	addu	$2,$2,$5
	addu	$24,$15,$13
	slt	$3,$5,$7
	lw	$11,%lo(src_buffer)($8)
	sll	$2,$2,6
	beq	$3,$0,$L17
	addu	$13,$24,$13

	addu	$2,$2,$6
	subu	$25,$4,$6
	addu	$11,$11,$2
	slt	$4,$4,$6
$L18:
	beq	$4,$0,$L20
	addu	$2,$25,$11

	move	$9,$13
	move	$8,$24
	move	$6,$15
	move	$3,$14
$L19:
	lbu	$10,0($2)
	addiu	$6,$6,4
	sb	$10,0($3)
	sb	$10,1($3)
	lbu	$10,0($2)
	addiu	$8,$8,4
	sb	$10,2($3)
	sb	$10,3($3)
	lbu	$10,0($2)
	addiu	$2,$2,1
	sb	$10,-4($6)
	sb	$10,-3($6)
	lbu	$10,-1($2)
	addiu	$9,$9,4
	sb	$10,-2($6)
	sb	$10,-1($6)
	lbu	$10,-1($2)
	addiu	$3,$3,4
	sb	$10,-4($8)
	sb	$10,-3($8)
	lbu	$10,-1($2)
	sb	$10,-2($8)
	sb	$10,-1($8)
	lbu	$10,-1($2)
	sb	$10,-4($9)
	sb	$10,-3($9)
	lbu	$10,-1($2)
	sb	$10,-2($9)
	.set	noat
	xor	$1,$2,$11
	bne	$1,$0,$L19
	.set	at
	sb	$10,-1($9)

$L20:
	addiu	$5,$5,1
	addu	$14,$14,$12
	addu	$15,$15,$12
	addu	$24,$24,$12
	addu	$13,$13,$12
	.set	noat
	xor	$1,$7,$5
	bne	$1,$0,$L18
	.set	at
	addiu	$11,$11,320

$L17:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Scale4x
	.size	I_Scale4x, .-I_Scale4x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Scale5x
	.type	I_Scale5x, @function
I_Scale5x:
	.frame	$sp,8,$31		# vars= 0, regs= 2/0, args= 0, gp= 0
	.mask	0x00030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_pitch)
	lw	$14,%lo(dest_pitch)($2)
	move	$3,$4
	multu	$14,$5
	mflo	$2
	addiu	$sp,$sp,-8
	addu	$4,$2,$4
	lui	$2,%hi(dest_buffer)
	lw	$15,%lo(dest_buffer)($2)
	sll	$2,$4,2
	addu	$2,$2,$4
	addu	$15,$15,$2
	addu	$24,$15,$14
	addu	$25,$24,$14
	sll	$13,$14,2
	sll	$2,$5,2
	sw	$16,0($sp)
	addu	$4,$25,$14
	move	$16,$7
	lui	$8,%hi(src_buffer)
	slt	$7,$5,$7
	addu	$13,$13,$14
	lw	$12,%lo(src_buffer)($8)
	sw	$17,4($sp)
	addu	$2,$2,$5
	beq	$7,$0,$L24
	addu	$14,$4,$14

	sll	$2,$2,6
	addu	$2,$2,$6
	addu	$12,$12,$2
	subu	$17,$3,$6
	slt	$7,$3,$6
$L25:
	beq	$7,$0,$L27
	addu	$2,$17,$12

	move	$10,$14
	move	$9,$4
	move	$8,$25
	move	$6,$24
	move	$3,$15
$L26:
	lbu	$11,0($2)
	addiu	$6,$6,5
	sb	$11,0($3)
	sb	$11,1($3)
	lbu	$11,0($2)
	addiu	$8,$8,5
	sb	$11,2($3)
	sb	$11,3($3)
	lbu	$11,0($2)
	addiu	$2,$2,1
	sb	$11,4($3)
	sb	$11,-5($6)
	lbu	$11,-1($2)
	addiu	$9,$9,5
	sb	$11,-4($6)
	sb	$11,-3($6)
	lbu	$11,-1($2)
	addiu	$10,$10,5
	sb	$11,-2($6)
	sb	$11,-1($6)
	lbu	$11,-1($2)
	addiu	$3,$3,5
	sb	$11,-5($8)
	sb	$11,-4($8)
	lbu	$11,-1($2)
	sb	$11,-3($8)
	sb	$11,-2($8)
	lbu	$11,-1($2)
	sb	$11,-1($8)
	sb	$11,-5($9)
	lbu	$11,-1($2)
	sb	$11,-4($9)
	sb	$11,-3($9)
	lbu	$11,-1($2)
	sb	$11,-2($9)
	sb	$11,-1($9)
	lbu	$11,-1($2)
	sb	$11,-5($10)
	sb	$11,-4($10)
	lbu	$11,-1($2)
	sb	$11,-3($10)
	sb	$11,-2($10)
	lbu	$11,-1($2)
	.set	noat
	xor	$1,$2,$12
	bne	$1,$0,$L26
	.set	at
	sb	$11,-1($10)

$L27:
	addiu	$5,$5,1
	addu	$15,$15,$13
	addu	$24,$24,$13
	addu	$25,$25,$13
	addu	$4,$4,$13
	addu	$14,$14,$13
	.set	noat
	xor	$1,$16,$5
	bne	$1,$0,$L25
	.set	at
	addiu	$12,$12,320

$L24:
	lw	$17,4($sp)
	lw	$16,0($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,8

	.set	macro
	.set	reorder
	.end	I_Scale5x
	.size	I_Scale5x, .-I_Scale5x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Scale1x
	.type	I_Scale1x, @function
I_Scale1x:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$21,40($sp)
	lui	$21,%hi(dest_pitch)
	lw	$3,%lo(dest_pitch)($21)
	sll	$2,$5,2
	addu	$2,$2,$5
	sw	$16,20($sp)
	move	$16,$5
	lui	$5,%hi(src_buffer)
	sw	$18,28($sp)
	lw	$18,%lo(src_buffer)($5)
	multu	$16,$3
	mflo	$5
	sw	$17,24($sp)
	addu	$3,$5,$4
	lui	$5,%hi(dest_buffer)
	lw	$17,%lo(dest_buffer)($5)
	sll	$2,$2,6
	addu	$2,$2,$4
	slt	$5,$16,$7
	sw	$20,36($sp)
	sw	$31,44($sp)
	sw	$19,32($sp)
	subu	$20,$6,$4
	addu	$18,$18,$2
	beq	$5,$0,$L37
	addu	$17,$17,$3

	move	$19,$7
$L33:
	move	$5,$18
	move	$4,$17
	jal	memcpy
	move	$6,$20

	lw	$2,%lo(dest_pitch)($21)
	addiu	$16,$16,1
	addu	$17,$17,$2
	.set	noat
	xor	$1,$19,$16
	bne	$1,$0,$L33
	.set	at
	addiu	$18,$18,320

$L37:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	I_Scale1x
	.size	I_Scale1x, .-I_Scale1x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	GenerateStretchTable
	.type	GenerateStretchTable, @function
GenerateStretchTable:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	move	$6,$0
	sw	$17,20($sp)
	sw	$16,16($sp)
	move	$17,$4
	move	$16,$5
	li	$4,65536			# 0x10000
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$31,36($sp)
	jal	Z_Malloc
	li	$5,1			# 0x1

	li	$24,100			# 0x64
	li	$15,1374355456			# 0x51eb0000
	move	$19,$2
	subu	$24,$24,$16
	addiu	$2,$17,768
	move	$14,$17
	move	$20,$0
	ori	$15,$15,0x851f
	li	$18,2147418112			# 0x7fff0000
	li	$12,256			# 0x100
$L40:
	addu	$25,$19,$20
	move	$13,$17
$L44:
	lbu	$11,0($14)
	lbu	$5,0($13)
	multu	$11,$16
	mflo	$6
	multu	$5,$24
	mflo	$5
	lbu	$10,1($14)
	lbu	$4,1($13)
	addu	$11,$6,$5
	multu	$4,$24
	mflo	$4
	multu	$10,$16
	mflo	$6
	lbu	$9,2($14)
	lbu	$3,2($13)
	addu	$10,$6,$4
	multu	$3,$24
	mflo	$3
	multu	$9,$16
	mflo	$4
	multu	$11,$15
	addu	$9,$4,$3
	mfhi	$11
	multu	$10,$15
	move	$5,$17
	mfhi	$10
	multu	$9,$15
	move	$8,$0
	mfhi	$9
	ori	$7,$18,0xffff
	move	$6,$0
	srl	$11,$11,5
	srl	$10,$10,5
	b	$L43
	srl	$9,$9,5

$L53:
	addiu	$6,$6,1
	.set	noat
	xor	$1,$6,$12
	beq	$1,$0,$L52
	.set	at
	movn	$7,$3,$4

$L43:
	lbu	$3,1($5)
	lbu	$4,0($5)
	subu	$3,$10,$3
	mult	$3,$3
	subu	$4,$11,$4
	lbu	$3,2($5)
	madd	$4,$4
	subu	$3,$9,$3
	madd	$3,$3
	addiu	$5,$5,3
	mflo	$3
	slt	$4,$3,$7
	bne	$3,$0,$L53
	movn	$8,$6,$4

	addiu	$13,$13,3
	sb	$6,0($25)
	.set	noat
	xor	$1,$2,$13
	bne	$1,$0,$L44
	.set	at
	addiu	$25,$25,1

	addiu	$14,$14,3
$L55:
	.set	noat
	xor	$1,$2,$14
	bne	$1,$0,$L40
	.set	at
	addiu	$20,$20,256

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$19
	lw	$19,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L52:
	move	$6,$8
	addiu	$13,$13,3
	sb	$6,0($25)
	.set	noat
	xor	$1,$2,$13
	bne	$1,$0,$L44
	.set	at
	addiu	$25,$25,1

	b	$L55
	addiu	$14,$14,3

	.set	macro
	.set	reorder
	.end	GenerateStretchTable
	.size	GenerateStretchTable, .-GenerateStretchTable
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Squash1x
	.type	I_Squash1x, @function
I_Squash1x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L62
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L65
	.set	at
	nop

$L62:
	jr	$31
	move	$2,$0

$L65:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L62
	.set	at
	lui	$4,%hi(dest_buffer)

	lui	$2,%hi(src_buffer)
	lw	$9,%lo(src_buffer)($2)
	lui	$2,%hi(stretch_tables)
	addiu	$3,$2,%lo(stretch_tables)
	lw	$6,%lo(stretch_tables)($2)
	lui	$2,%hi(dest_pitch)
	lw	$10,%lo(dest_pitch)($2)
	lw	$8,%lo(dest_buffer)($4)
	li	$2,64320			# 0xfb40
	lw	$5,4($3)
	addiu	$7,$9,320
	addu	$9,$9,$2
$L58:
	addiu	$2,$7,-320
	move	$4,$8
$L59:
	lbu	$3,1($2)
	lbu	$11,0($2)
	sll	$3,$3,8
	addu	$3,$6,$3
	addu	$3,$3,$11
	lbu	$3,0($3)
	addiu	$2,$2,5
	sb	$3,0($4)
	lbu	$3,-3($2)
	lbu	$11,-4($2)
	sll	$3,$3,8
	addu	$3,$5,$3
	addu	$3,$3,$11
	lbu	$3,0($3)
	addiu	$4,$4,4
	sb	$3,-3($4)
	lbu	$3,-3($2)
	lbu	$11,-2($2)
	sll	$3,$3,8
	addu	$3,$5,$3
	addu	$3,$3,$11
	lbu	$3,0($3)
	sb	$3,-2($4)
	lbu	$3,-2($2)
	lbu	$11,-1($2)
	sll	$3,$3,8
	addu	$3,$6,$3
	addu	$3,$3,$11
	lbu	$3,0($3)
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L59
	.set	at
	sb	$3,-1($4)

	addiu	$7,$2,320
	.set	noat
	xor	$1,$9,$7
	bne	$1,$0,$L58
	.set	at
	addu	$8,$8,$10

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Squash1x
	.size	I_Squash1x, .-I_Squash1x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Squash2x
	.type	I_Squash2x, @function
I_Squash2x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L72
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L75
	.set	at
	nop

$L72:
	jr	$31
	move	$2,$0

$L75:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L72
	.set	at
	lui	$3,%hi(src_buffer)

	lw	$10,%lo(src_buffer)($3)
	lui	$2,%hi(stretch_tables)
	lui	$3,%hi(dest_pitch)
	lw	$11,%lo(dest_pitch)($3)
	lui	$4,%hi(dest_buffer)
	addiu	$3,$2,%lo(stretch_tables)
	lw	$6,%lo(stretch_tables)($2)
	lw	$9,%lo(dest_buffer)($4)
	li	$2,64320			# 0xfb40
	lw	$7,4($3)
	addiu	$8,$10,320
	sll	$12,$11,1
	addu	$10,$10,$2
$L69:
	addiu	$2,$8,-320
	addu	$4,$9,$11
	move	$3,$9
$L68:
	lbu	$5,0($2)
	addiu	$3,$3,8
	sb	$5,0($4)
	sb	$5,-8($3)
	lbu	$5,1($2)
	lbu	$13,0($2)
	sll	$5,$5,8
	addu	$5,$7,$5
	addu	$5,$5,$13
	lbu	$5,0($5)
	addiu	$2,$2,5
	sb	$5,1($4)
	sb	$5,-7($3)
	lbu	$5,-4($2)
	addiu	$4,$4,8
	sb	$5,-6($4)
	sb	$5,-6($3)
	lbu	$5,-4($2)
	lbu	$13,-3($2)
	sll	$5,$5,8
	addu	$5,$6,$5
	addu	$5,$5,$13
	lbu	$5,0($5)
	sb	$5,-5($4)
	sb	$5,-5($3)
	lbu	$5,-2($2)
	lbu	$13,-3($2)
	sll	$5,$5,8
	addu	$5,$6,$5
	addu	$5,$5,$13
	lbu	$5,0($5)
	sb	$5,-4($4)
	sb	$5,-4($3)
	lbu	$5,-2($2)
	sb	$5,-3($4)
	sb	$5,-3($3)
	lbu	$5,-2($2)
	lbu	$13,-1($2)
	sll	$5,$5,8
	addu	$5,$7,$5
	addu	$5,$5,$13
	lbu	$5,0($5)
	sb	$5,-2($4)
	sb	$5,-2($3)
	lbu	$5,-1($2)
	sb	$5,-1($4)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L68
	.set	at
	sb	$5,-1($3)

	addiu	$8,$2,320
	.set	noat
	xor	$1,$10,$8
	bne	$1,$0,$L69
	.set	at
	addu	$9,$9,$12

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Squash2x
	.size	I_Squash2x, .-I_Squash2x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Squash3x
	.type	I_Squash3x, @function
I_Squash3x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L82
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L85
	.set	at
	nop

$L82:
	jr	$31
	move	$2,$0

$L85:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L82
	.set	at
	nop

	lui	$2,%hi(dest_pitch)
	lw	$12,%lo(dest_pitch)($2)
	lui	$2,%hi(src_buffer)
	lw	$11,%lo(src_buffer)($2)
	lui	$2,%hi(dest_buffer)
	lw	$10,%lo(dest_buffer)($2)
	lui	$2,%hi(half_stretch_table)
	lw	$9,%lo(half_stretch_table)($2)
	sll	$13,$12,1
	li	$2,64320			# 0xfb40
	addiu	$8,$11,320
	addu	$14,$13,$12
	addu	$11,$11,$2
$L79:
	addiu	$3,$8,-320
	addu	$6,$12,$10
	addu	$5,$13,$10
	move	$4,$10
$L78:
	lbu	$2,0($3)
	addiu	$6,$6,5
	sb	$2,0($5)
	sb	$2,-5($6)
	sb	$2,0($4)
	sb	$2,1($5)
	sb	$2,-4($6)
	sb	$2,1($4)
	lbu	$2,0($3)
	lbu	$7,1($3)
	sll	$2,$2,8
	addu	$2,$9,$2
	addu	$2,$2,$7
	lbu	$2,0($2)
	addiu	$4,$4,5
	sb	$2,2($5)
	sb	$2,-3($6)
	sb	$2,-3($4)
	lbu	$2,1($3)
	addiu	$3,$3,2
	addiu	$5,$5,5
	sb	$2,-2($5)
	sb	$2,-2($6)
	sb	$2,-2($4)
	sb	$2,-1($5)
	sb	$2,-1($6)
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L78
	.set	at
	sb	$2,-1($4)

	addiu	$8,$3,320
	.set	noat
	xor	$1,$8,$11
	bne	$1,$0,$L79
	.set	at
	addu	$10,$10,$14

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Squash3x
	.size	I_Squash3x, .-I_Squash3x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Squash4x
	.type	I_Squash4x, @function
I_Squash4x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L92
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L95
	.set	at
	nop

$L92:
	jr	$31
	move	$2,$0

$L95:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L92
	.set	at
	lui	$3,%hi(src_buffer)

	lui	$2,%hi(dest_pitch)
	lw	$13,%lo(dest_pitch)($2)
	lui	$2,%hi(stretch_tables)
	lw	$12,%lo(src_buffer)($3)
	lui	$4,%hi(dest_buffer)
	addiu	$3,$2,%lo(stretch_tables)
	lw	$9,%lo(stretch_tables)($2)
	sll	$14,$13,1
	li	$2,64320			# 0xfb40
	lw	$11,%lo(dest_buffer)($4)
	lw	$8,4($3)
	addiu	$10,$12,320
	addu	$24,$14,$13
	sll	$15,$13,2
	addu	$12,$12,$2
$L89:
	addiu	$6,$10,-320
	addu	$5,$13,$11
	addu	$4,$14,$11
	addu	$3,$24,$11
	move	$2,$11
$L88:
	lbu	$7,0($6)
	addiu	$4,$4,16
	sb	$7,0($3)
	sb	$7,-16($4)
	sb	$7,0($5)
	sb	$7,0($2)
	sb	$7,1($3)
	sb	$7,-15($4)
	sb	$7,1($5)
	sb	$7,1($2)
	sb	$7,2($3)
	sb	$7,-14($4)
	sb	$7,2($5)
	sb	$7,2($2)
	lbu	$7,0($6)
	lbu	$25,1($6)
	sll	$7,$7,8
	addu	$7,$9,$7
	addu	$7,$7,$25
	lbu	$7,0($7)
	addiu	$5,$5,16
	sb	$7,3($3)
	sb	$7,-13($4)
	sb	$7,-13($5)
	sb	$7,3($2)
	lbu	$7,1($6)
	addiu	$2,$2,16
	sb	$7,4($3)
	sb	$7,-12($4)
	sb	$7,-12($5)
	sb	$7,-12($2)
	sb	$7,5($3)
	sb	$7,-11($4)
	sb	$7,-11($5)
	sb	$7,-11($2)
	lbu	$7,1($6)
	lbu	$25,2($6)
	sll	$7,$7,8
	addu	$7,$8,$7
	addu	$7,$7,$25
	lbu	$7,0($7)
	addiu	$6,$6,5
	sb	$7,6($3)
	sb	$7,-10($4)
	sb	$7,-10($5)
	sb	$7,-10($2)
	lbu	$7,-3($6)
	addiu	$3,$3,16
	sb	$7,-9($3)
	sb	$7,-9($4)
	sb	$7,-9($5)
	sb	$7,-9($2)
	sb	$7,-8($3)
	sb	$7,-8($4)
	sb	$7,-8($5)
	sb	$7,-8($2)
	lbu	$7,-2($6)
	lbu	$25,-3($6)
	sll	$7,$7,8
	addu	$7,$8,$7
	addu	$7,$7,$25
	lbu	$7,0($7)
	sb	$7,-7($3)
	sb	$7,-7($4)
	sb	$7,-7($5)
	sb	$7,-7($2)
	lbu	$7,-2($6)
	sb	$7,-6($3)
	sb	$7,-6($4)
	sb	$7,-6($5)
	sb	$7,-6($2)
	sb	$7,-5($3)
	sb	$7,-5($4)
	sb	$7,-5($5)
	sb	$7,-5($2)
	lbu	$7,-1($6)
	lbu	$25,-2($6)
	sll	$7,$7,8
	addu	$7,$9,$7
	addu	$7,$7,$25
	lbu	$7,0($7)
	sb	$7,-4($3)
	sb	$7,-4($4)
	sb	$7,-4($5)
	sb	$7,-4($2)
	lbu	$7,-1($6)
	sb	$7,-3($3)
	sb	$7,-3($4)
	sb	$7,-3($5)
	sb	$7,-3($2)
	sb	$7,-2($3)
	sb	$7,-2($4)
	sb	$7,-2($5)
	sb	$7,-2($2)
	sb	$7,-1($3)
	sb	$7,-1($4)
	sb	$7,-1($5)
	.set	noat
	xor	$1,$6,$10
	bne	$1,$0,$L88
	.set	at
	sb	$7,-1($2)

	addiu	$10,$6,320
	.set	noat
	xor	$1,$10,$12
	bne	$1,$0,$L89
	.set	at
	addu	$11,$11,$15

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Squash4x
	.size	I_Squash4x, .-I_Squash4x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Squash5x
	.type	I_Squash5x, @function
I_Squash5x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L102
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L105
	.set	at
	nop

$L102:
	jr	$31
	move	$2,$0

$L105:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L102
	.set	at
	nop

	lui	$2,%hi(dest_pitch)
	lw	$11,%lo(dest_pitch)($2)
	lui	$2,%hi(src_buffer)
	lw	$12,%lo(src_buffer)($2)
	lui	$2,%hi(dest_buffer)
	lw	$10,%lo(dest_buffer)($2)
	sll	$14,$11,1
	sll	$13,$11,2
	li	$2,64320			# 0xfb40
	addiu	$9,$12,320
	addu	$24,$14,$11
	addu	$15,$13,$11
	addu	$12,$12,$2
$L99:
	addiu	$8,$9,-320
	addu	$7,$10,$11
	addu	$6,$10,$14
	addu	$5,$10,$24
	addu	$4,$10,$13
	move	$3,$10
$L98:
	lbu	$2,0($8)
	addiu	$5,$5,4
	addiu	$7,$7,4
	sb	$2,0($4)
	addiu	$6,$6,4
	sb	$2,-4($5)
	addiu	$4,$4,4
	sb	$2,-4($6)
	addiu	$3,$3,4
	sb	$2,-4($7)
	addiu	$8,$8,1
	sb	$2,-4($3)
	sb	$2,-3($4)
	sb	$2,-3($5)
	sb	$2,-3($6)
	sb	$2,-3($7)
	sb	$2,-3($3)
	sb	$2,-2($4)
	sb	$2,-2($5)
	sb	$2,-2($6)
	sb	$2,-2($7)
	sb	$2,-2($3)
	sb	$2,-1($4)
	sb	$2,-1($5)
	sb	$2,-1($6)
	sb	$2,-1($7)
	.set	noat
	xor	$1,$8,$9
	bne	$1,$0,$L98
	.set	at
	sb	$2,-1($3)

	addiu	$9,$8,320
	.set	noat
	xor	$1,$12,$9
	bne	$1,$0,$L99
	.set	at
	addu	$10,$10,$15

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Squash5x
	.size	I_Squash5x, .-I_Squash5x
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"I_InitStretchTables: Generating lookup tables..\000"
	.align	2
$LC1:
	.ascii	"..\000"
	.align	2
$LC2:
	.ascii	"\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_InitStretchTables
	.type	I_InitStretchTables, @function
I_InitStretchTables:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	lui	$17,%hi(stretch_tables)
	lw	$2,%lo(stretch_tables)($17)
	sw	$31,28($sp)
	sw	$18,24($sp)
	beq	$2,$0,$L109
	sw	$16,16($sp)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L109:
	move	$16,$4
	lui	$4,%hi($LC0)
	lui	$18,%hi(stdout)
	jal	printf
	addiu	$4,$4,%lo($LC0)

	jal	fflush
	lw	$4,%lo(stdout)($18)

	li	$5,20			# 0x14
	jal	GenerateStretchTable
	move	$4,$16

	lui	$4,%hi($LC1)
	addiu	$4,$4,%lo($LC1)
	jal	printf
	sw	$2,%lo(stretch_tables)($17)

	lw	$4,%lo(stdout)($18)
	jal	fflush
	addiu	$17,$17,%lo(stretch_tables)

	move	$4,$16
	jal	GenerateStretchTable
	li	$5,40			# 0x28

	sw	$2,4($17)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	j	puts
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_InitStretchTables
	.size	I_InitStretchTables, .-I_InitStretchTables
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"I_InitSquashTable: Generating lookup table..\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_InitSquashTable
	.type	I_InitSquashTable, @function
I_InitSquashTable:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lui	$17,%hi(half_stretch_table)
	lw	$2,%lo(half_stretch_table)($17)
	sw	$31,28($sp)
	beq	$2,$0,$L113
	sw	$16,20($sp)

	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L113:
	move	$16,$4
	lui	$4,%hi($LC3)
	jal	printf
	addiu	$4,$4,%lo($LC3)

	lui	$2,%hi(stdout)
	jal	fflush
	lw	$4,%lo(stdout)($2)

	move	$4,$16
	jal	GenerateStretchTable
	li	$5,50			# 0x32

	sw	$2,%lo(half_stretch_table)($17)
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	j	puts
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_InitSquashTable
	.size	I_InitSquashTable, .-I_InitSquashTable
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Stretch1x
	.type	I_Stretch1x, @function
I_Stretch1x:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L123
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L133
	.set	at
	nop

$L123:
	jr	$31
	move	$2,$0

$L133:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L123
	.set	at
	nop

	addiu	$sp,$sp,-64
	lui	$2,%hi(src_buffer)
	sw	$18,32($sp)
	lw	$18,%lo(src_buffer)($2)
	lui	$2,%hi(dest_buffer)
	sw	$20,40($sp)
	sw	$19,36($sp)
	lw	$20,%lo(dest_buffer)($2)
	lui	$19,%hi(stretch_tables)
	li	$2,65280			# 0xff00
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	addiu	$fp,$18,960
	addiu	$21,$18,1280
	addiu	$23,$18,640
	addiu	$22,$18,320
	addu	$18,$18,$2
	addiu	$2,$19,%lo(stretch_tables)
	sw	$17,28($sp)
	sw	$31,60($sp)
	sw	$16,24($sp)
	lui	$17,%hi(dest_pitch)
	sw	$2,16($sp)
$L120:
	addiu	$16,$21,-1280
	move	$5,$16
	move	$4,$20
	jal	memcpy
	li	$6,320			# 0x140

	lw	$5,%lo(dest_pitch)($17)
	lw	$3,%lo(stretch_tables)($19)
	addu	$8,$20,$5
	move	$4,$8
$L116:
	lbu	$2,0($16)
	lbu	$6,320($16)
	sll	$2,$2,8
	addu	$2,$3,$2
	addu	$2,$2,$6
	lbu	$2,0($2)
	addiu	$16,$16,1
	sb	$2,0($4)
	.set	noat
	xor	$1,$16,$22
	bne	$1,$0,$L116
	.set	at
	addiu	$4,$4,1

	lw	$2,16($sp)
	addu	$8,$8,$5
	lw	$6,4($2)
	move	$4,$8
$L117:
	lbu	$2,0($16)
	lbu	$7,320($16)
	sll	$2,$2,8
	addu	$2,$6,$2
	addu	$2,$2,$7
	lbu	$2,0($2)
	addiu	$16,$16,1
	sb	$2,0($4)
	.set	noat
	xor	$1,$16,$23
	bne	$1,$0,$L117
	.set	at
	addiu	$4,$4,1

	addu	$8,$8,$5
	move	$4,$8
$L118:
	lbu	$2,320($16)
	lbu	$7,0($16)
	sll	$2,$2,8
	addu	$2,$6,$2
	addu	$2,$2,$7
	lbu	$2,0($2)
	addiu	$16,$16,1
	sb	$2,0($4)
	.set	noat
	xor	$1,$16,$fp
	bne	$1,$0,$L118
	.set	at
	addiu	$4,$4,1

	addu	$7,$8,$5
	move	$4,$7
$L119:
	lbu	$2,320($16)
	lbu	$6,0($16)
	sll	$2,$2,8
	addu	$2,$3,$2
	addu	$2,$2,$6
	lbu	$2,0($2)
	addiu	$16,$16,1
	sb	$2,0($4)
	.set	noat
	xor	$1,$16,$21
	bne	$1,$0,$L119
	.set	at
	addiu	$4,$4,1

	addu	$20,$7,$5
	move	$4,$20
	li	$6,320			# 0x140
	jal	memcpy
	move	$5,$16

	lw	$2,%lo(dest_pitch)($17)
	addiu	$21,$16,1600
	addu	$20,$20,$2
	addiu	$fp,$fp,1600
	addiu	$23,$23,1600
	.set	noat
	xor	$1,$18,$21
	bne	$1,$0,$L120
	.set	at
	addiu	$22,$22,1600

	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	I_Stretch1x
	.size	I_Stretch1x, .-I_Stretch1x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Stretch2x
	.type	I_Stretch2x, @function
I_Stretch2x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L151
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L165
	.set	at
	nop

$L151:
	jr	$31
	move	$2,$0

$L165:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L151
	.set	at
	lui	$4,%hi(dest_buffer)

	lui	$2,%hi(src_buffer)
	lw	$12,%lo(src_buffer)($2)
	lui	$2,%hi(stretch_tables)
	addiu	$3,$2,%lo(stretch_tables)
	lw	$15,%lo(dest_buffer)($4)
	lw	$9,%lo(stretch_tables)($2)
	lui	$4,%hi(dest_pitch)
	li	$2,64960			# 0xfdc0
	lw	$10,4($3)
	lw	$11,%lo(dest_pitch)($4)
	addiu	$8,$12,1600
	addiu	$7,$12,1280
	addiu	$4,$12,960
	addiu	$6,$12,640
	addiu	$5,$12,320
	addu	$12,$12,$2
$L136:
	addiu	$13,$4,-960
	move	$14,$15
	move	$2,$13
$L137:
	lbu	$3,0($2)
	addiu	$2,$2,1
	sb	$3,0($14)
	sb	$3,1($14)
	move	$3,$5
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L137
	.set	at
	addiu	$14,$14,2

	addu	$24,$15,$11
	move	$14,$24
	move	$2,$13
$L138:
	lbu	$15,0($2)
	addiu	$2,$2,1
	sb	$15,0($14)
	sb	$15,1($14)
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L138
	.set	at
	addiu	$14,$14,2

	addu	$24,$24,$11
	move	$14,$24
$L139:
	lbu	$2,0($13)
	lbu	$15,320($13)
	sll	$2,$2,8
	addu	$2,$10,$2
	addu	$2,$2,$15
	lbu	$2,0($2)
	addiu	$13,$13,1
	sb	$2,0($14)
	sb	$2,1($14)
	.set	noat
	xor	$1,$13,$5
	bne	$1,$0,$L139
	.set	at
	addiu	$14,$14,2

	addu	$24,$24,$11
	move	$14,$24
	move	$2,$5
$L140:
	lbu	$13,0($2)
	addiu	$2,$2,1
	sb	$13,0($14)
	sb	$13,1($14)
	move	$13,$6
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L140
	.set	at
	addiu	$14,$14,2

	addu	$24,$24,$11
	move	$14,$24
$L141:
	lbu	$2,320($3)
	lbu	$15,0($3)
	sll	$2,$2,8
	addu	$2,$9,$2
	addu	$2,$2,$15
	lbu	$2,0($2)
	addiu	$3,$3,1
	sb	$2,0($14)
	sb	$2,1($14)
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L141
	.set	at
	addiu	$14,$14,2

	addu	$24,$24,$11
	move	$14,$24
	move	$3,$6
$L142:
	lbu	$2,0($3)
	addiu	$3,$3,1
	sb	$2,0($14)
	sb	$2,1($14)
	move	$2,$4
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L142
	.set	at
	addiu	$14,$14,2

	addu	$24,$24,$11
	move	$14,$24
	move	$3,$6
$L143:
	lbu	$15,0($3)
	addiu	$3,$3,1
	sb	$15,0($14)
	sb	$15,1($14)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L143
	.set	at
	addiu	$14,$14,2

	addu	$24,$24,$11
	move	$14,$24
$L144:
	lbu	$3,0($13)
	lbu	$15,320($13)
	sll	$3,$3,8
	addu	$3,$9,$3
	addu	$3,$3,$15
	lbu	$3,0($3)
	addiu	$13,$13,1
	sb	$3,0($14)
	sb	$3,1($14)
	.set	noat
	xor	$1,$13,$4
	bne	$1,$0,$L144
	.set	at
	addiu	$14,$14,2

	addu	$15,$24,$11
	move	$13,$15
	move	$3,$4
$L145:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($13)
	sb	$14,1($13)
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L145
	.set	at
	addiu	$13,$13,2

	addu	$15,$15,$11
	move	$13,$15
$L146:
	lbu	$3,320($2)
	lbu	$14,0($2)
	sll	$3,$3,8
	addu	$3,$10,$3
	addu	$3,$3,$14
	lbu	$3,0($3)
	addiu	$2,$2,1
	sb	$3,0($13)
	sb	$3,1($13)
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L146
	.set	at
	addiu	$13,$13,2

	addu	$15,$15,$11
	move	$13,$15
	move	$3,$2
$L147:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($13)
	sb	$14,1($13)
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L147
	.set	at
	addiu	$13,$13,2

	addu	$15,$15,$11
	move	$3,$15
$L148:
	lbu	$13,0($2)
	addiu	$2,$2,1
	sb	$13,0($3)
	sb	$13,1($3)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L148
	.set	at
	addiu	$3,$3,2

	addiu	$4,$4,1600
	addu	$15,$15,$11
	addiu	$8,$2,1600
	addiu	$7,$7,1600
	addiu	$6,$6,1600
	.set	noat
	xor	$1,$4,$12
	bne	$1,$0,$L136
	.set	at
	addiu	$5,$5,1600

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Stretch2x
	.size	I_Stretch2x, .-I_Stretch2x
	.section	.rodata.str1.4
	.align	2
$LC4:
	.ascii	"-scanline\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Stretch5x
	.type	I_Stretch5x, @function
I_Stretch5x:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L181
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L193
	.set	at
	nop

$L181:
	jr	$31
	move	$2,$0

$L193:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L181
	.set	at
	nop

	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	lui	$16,%hi(dest_pitch)
	lw	$9,%lo(dest_pitch)($16)
	lui	$2,%hi(src_buffer)
	lw	$10,%lo(src_buffer)($2)
	sw	$17,20($sp)
	sll	$13,$9,1
	lui	$17,%hi(dest_buffer)
	addu	$11,$13,$9
	sll	$12,$9,2
	li	$2,64320			# 0xfb40
	lw	$8,%lo(dest_buffer)($17)
	addiu	$7,$10,320
	sw	$31,28($sp)
	sw	$18,24($sp)
	addu	$10,$10,$2
	addu	$15,$12,$9
	sll	$14,$11,1
$L168:
	addiu	$4,$7,-320
	move	$3,$8
	move	$2,$4
$L169:
	lbu	$5,0($2)
	addiu	$2,$2,1
	sb	$5,0($3)
	sb	$5,1($3)
	lbu	$5,-1($2)
	addiu	$3,$3,5
	sb	$5,-3($3)
	sb	$5,-2($3)
	lbu	$5,-1($2)
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L169
	.set	at
	sb	$5,-1($3)

	addu	$3,$8,$9
	move	$5,$4
$L170:
	lbu	$6,0($5)
	addiu	$5,$5,1
	sb	$6,0($3)
	sb	$6,1($3)
	lbu	$6,-1($5)
	addiu	$3,$3,5
	sb	$6,-3($3)
	sb	$6,-2($3)
	lbu	$6,-1($5)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L170
	.set	at
	sb	$6,-1($3)

	addu	$3,$8,$13
	move	$5,$4
$L171:
	lbu	$6,0($5)
	addiu	$5,$5,1
	sb	$6,0($3)
	sb	$6,1($3)
	lbu	$6,-1($5)
	addiu	$3,$3,5
	sb	$6,-3($3)
	sb	$6,-2($3)
	lbu	$6,-1($5)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L171
	.set	at
	sb	$6,-1($3)

	addu	$3,$8,$11
	move	$5,$4
$L172:
	lbu	$6,0($5)
	addiu	$5,$5,1
	sb	$6,0($3)
	sb	$6,1($3)
	lbu	$6,-1($5)
	addiu	$3,$3,5
	sb	$6,-3($3)
	sb	$6,-2($3)
	lbu	$6,-1($5)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L172
	.set	at
	sb	$6,-1($3)

	addu	$3,$8,$12
	move	$5,$4
$L173:
	lbu	$6,0($5)
	addiu	$5,$5,1
	sb	$6,0($3)
	sb	$6,1($3)
	lbu	$6,-1($5)
	addiu	$3,$3,5
	sb	$6,-3($3)
	sb	$6,-2($3)
	lbu	$6,-1($5)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L173
	.set	at
	sb	$6,-1($3)

	addu	$3,$8,$15
$L174:
	lbu	$5,0($4)
	addiu	$4,$4,1
	sb	$5,0($3)
	sb	$5,1($3)
	lbu	$5,-1($4)
	addiu	$3,$3,5
	sb	$5,-3($3)
	sb	$5,-2($3)
	lbu	$5,-1($4)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L174
	.set	at
	sb	$5,-1($3)

	addiu	$7,$7,320
	.set	noat
	xor	$1,$10,$7
	bne	$1,$0,$L168
	.set	at
	addu	$8,$8,$14

	lui	$4,%hi($LC4)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC4)

	blez	$2,$L178
	lw	$2,%lo(dest_pitch)($16)

	lw	$17,%lo(dest_buffer)($17)
	sll	$2,$2,1
	addu	$17,$17,$2
	li	$18,400			# 0x190
$L177:
	move	$4,$17
	li	$6,1600			# 0x640
	jal	memset
	move	$5,$0

	lw	$3,%lo(dest_pitch)($16)
	addiu	$18,$18,-1
	sll	$2,$3,1
	addu	$2,$2,$3
	bne	$18,$0,$L177
	addu	$17,$17,$2

$L178:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_Stretch5x
	.size	I_Stretch5x, .-I_Stretch5x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Stretch3x
	.type	I_Stretch3x, @function
I_Stretch3x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L217
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L237
	.set	at
	nop

$L217:
	jr	$31
	move	$2,$0

$L237:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L217
	.set	at
	lui	$4,%hi(dest_buffer)

	lui	$2,%hi(src_buffer)
	lw	$13,%lo(src_buffer)($2)
	lui	$2,%hi(stretch_tables)
	addiu	$3,$2,%lo(stretch_tables)
	lw	$15,%lo(dest_buffer)($4)
	lui	$4,%hi(dest_pitch)
	lw	$6,%lo(stretch_tables)($2)
	lw	$12,%lo(dest_pitch)($4)
	li	$2,65280			# 0xff00
	lw	$7,4($3)
	addiu	$5,$13,1600
	addiu	$8,$13,1280
	addiu	$11,$13,960
	addiu	$10,$13,640
	addiu	$9,$13,320
	addu	$13,$13,$2
$L196:
	addiu	$2,$8,-1280
	move	$4,$15
	move	$3,$2
$L197:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($3)
	addiu	$4,$4,3
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L197
	.set	at
	sb	$14,-1($4)

	addu	$24,$15,$12
	move	$14,$24
	move	$4,$2
$L198:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L198
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$4,$24
$L199:
	lbu	$14,0($2)
	addiu	$2,$2,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($2)
	addiu	$4,$4,3
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L199
	.set	at
	sb	$14,-1($4)

	addu	$24,$24,$12
	move	$14,$24
	move	$2,$3
$L200:
	lbu	$4,0($2)
	lbu	$15,-320($2)
	sll	$4,$4,8
	addu	$4,$7,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$2,$2,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	.set	noat
	xor	$1,$2,$10
	bne	$1,$0,$L200
	.set	at
	addiu	$14,$14,3

	addu	$24,$24,$12
	move	$14,$24
	move	$4,$3
$L201:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L201
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$14,$24
	move	$4,$3
$L202:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L202
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$14,$24
	move	$4,$3
$L203:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L203
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$14,$24
$L204:
	lbu	$4,0($3)
	lbu	$15,320($3)
	sll	$4,$4,8
	addu	$4,$6,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$3,$3,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L204
	.set	at
	addiu	$14,$14,3

	addu	$24,$24,$12
	move	$4,$24
	move	$3,$2
$L205:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($3)
	addiu	$4,$4,3
	.set	noat
	xor	$1,$3,$11
	bne	$1,$0,$L205
	.set	at
	sb	$14,-1($4)

	addu	$24,$24,$12
	move	$4,$24
$L206:
	lbu	$14,0($2)
	addiu	$2,$2,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($2)
	addiu	$4,$4,3
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L206
	.set	at
	sb	$14,-1($4)

	addu	$24,$24,$12
	move	$14,$24
	move	$2,$3
$L207:
	lbu	$4,0($2)
	lbu	$15,-320($2)
	sll	$4,$4,8
	addu	$4,$6,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$2,$2,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L207
	.set	at
	addiu	$14,$14,3

	addu	$24,$24,$12
	move	$14,$24
	move	$4,$3
$L208:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L208
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$14,$24
	move	$4,$3
$L209:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L209
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$14,$24
	move	$4,$3
$L210:
	lbu	$15,0($4)
	addiu	$4,$4,1
	sb	$15,0($14)
	sb	$15,1($14)
	lbu	$15,-1($4)
	addiu	$14,$14,3
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L210
	.set	at
	sb	$15,-1($14)

	addu	$24,$24,$12
	move	$14,$24
$L211:
	lbu	$4,0($3)
	lbu	$15,320($3)
	sll	$4,$4,8
	addu	$4,$7,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$3,$3,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L211
	.set	at
	addiu	$14,$14,3

	addu	$15,$24,$12
	move	$4,$15
	move	$3,$2
$L212:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($3)
	addiu	$4,$4,3
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L212
	.set	at
	sb	$14,-1($4)

	addu	$15,$15,$12
	move	$4,$15
	move	$3,$2
$L213:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($3)
	addiu	$4,$4,3
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L213
	.set	at
	sb	$14,-1($4)

	addu	$15,$15,$12
	move	$3,$15
$L214:
	lbu	$4,0($2)
	addiu	$2,$2,1
	sb	$4,0($3)
	sb	$4,1($3)
	lbu	$4,-1($2)
	addiu	$3,$3,3
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L214
	.set	at
	sb	$4,-1($3)

	addiu	$8,$8,1600
	addu	$15,$15,$12
	addiu	$5,$2,1600
	addiu	$11,$11,1600
	addiu	$10,$10,1600
	.set	noat
	xor	$1,$13,$8
	bne	$1,$0,$L196
	.set	at
	addiu	$9,$9,1600

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Stretch3x
	.size	I_Stretch3x, .-I_Stretch3x
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	I_Stretch4x
	.type	I_Stretch4x, @function
I_Stretch4x:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$4,$4,$5
	bne	$4,$0,$L267
	nop

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L293
	.set	at
	nop

$L267:
	jr	$31
	move	$2,$0

$L293:
	li	$2,200			# 0xc8
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L267
	.set	at
	lui	$4,%hi(dest_buffer)

	lui	$2,%hi(src_buffer)
	lw	$13,%lo(src_buffer)($2)
	lui	$2,%hi(stretch_tables)
	addiu	$3,$2,%lo(stretch_tables)
	lw	$15,%lo(dest_buffer)($4)
	lui	$4,%hi(dest_pitch)
	lw	$6,%lo(stretch_tables)($2)
	lw	$12,%lo(dest_pitch)($4)
	li	$2,64960			# 0xfdc0
	lw	$5,4($3)
	addiu	$11,$13,1600
	addiu	$10,$13,1280
	addiu	$7,$13,960
	addiu	$9,$13,640
	addiu	$8,$13,320
	addu	$13,$13,$2
$L240:
	addiu	$4,$7,-960
	move	$3,$15
	move	$2,$4
$L241:
	lbu	$14,0($2)
	addiu	$2,$2,1
	sb	$14,0($3)
	sb	$14,1($3)
	lbu	$14,-1($2)
	addiu	$3,$3,4
	sb	$14,-2($3)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L241
	.set	at
	sb	$14,-1($3)

	addu	$24,$15,$12
	move	$3,$24
	move	$14,$4
$L242:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($3)
	sb	$15,1($3)
	lbu	$15,-1($14)
	addiu	$3,$3,4
	sb	$15,-2($3)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L242
	.set	at
	sb	$15,-1($3)

	addu	$24,$24,$12
	move	$3,$24
	move	$14,$4
$L243:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($3)
	sb	$15,1($3)
	lbu	$15,-1($14)
	addiu	$3,$3,4
	sb	$15,-2($3)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L243
	.set	at
	sb	$15,-1($3)

	addu	$24,$24,$12
	move	$3,$24
$L244:
	lbu	$14,0($4)
	addiu	$4,$4,1
	sb	$14,0($3)
	sb	$14,1($3)
	lbu	$14,-1($4)
	addiu	$3,$3,4
	sb	$14,-2($3)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L244
	.set	at
	sb	$14,-1($3)

	addu	$24,$24,$12
	move	$14,$24
	move	$3,$2
$L245:
	lbu	$4,0($3)
	lbu	$15,-320($3)
	sll	$4,$4,8
	addu	$4,$6,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$3,$3,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	sb	$4,3($14)
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L245
	.set	at
	addiu	$14,$14,4

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$2
$L246:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$3
	bne	$1,$0,$L246
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$2
$L247:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$3
	bne	$1,$0,$L247
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$2
$L248:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$3
	bne	$1,$0,$L248
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
$L249:
	lbu	$14,0($2)
	addiu	$2,$2,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($2)
	addiu	$4,$4,4
	sb	$14,-2($4)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L249
	.set	at
	sb	$14,-1($4)

	addu	$24,$24,$12
	move	$14,$24
	move	$2,$3
$L250:
	lbu	$4,0($2)
	lbu	$15,-320($2)
	sll	$4,$4,8
	addu	$4,$5,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$2,$2,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	sb	$4,3($14)
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L250
	.set	at
	addiu	$14,$14,4

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$3
$L251:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L251
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$3
$L252:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L252
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$3
$L253:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L253
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$3
$L254:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L254
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$14,$24
$L255:
	lbu	$4,0($3)
	lbu	$15,320($3)
	sll	$4,$4,8
	addu	$4,$5,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$3,$3,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	sb	$4,3($14)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L255
	.set	at
	addiu	$14,$14,4

	addu	$24,$24,$12
	move	$4,$24
	move	$3,$2
$L256:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($3)
	addiu	$4,$4,4
	sb	$14,-2($4)
	.set	noat
	xor	$1,$3,$10
	bne	$1,$0,$L256
	.set	at
	sb	$14,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$2
$L257:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$3
	bne	$1,$0,$L257
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$2
$L258:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$3
	bne	$1,$0,$L258
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$2
$L259:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$3
	bne	$1,$0,$L259
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$14,$24
$L260:
	lbu	$4,0($2)
	lbu	$15,320($2)
	sll	$4,$4,8
	addu	$4,$6,$4
	addu	$4,$4,$15
	lbu	$4,0($4)
	addiu	$2,$2,1
	sb	$4,0($14)
	sb	$4,1($14)
	sb	$4,2($14)
	sb	$4,3($14)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L260
	.set	at
	addiu	$14,$14,4

	addu	$24,$24,$12
	move	$4,$24
	move	$2,$3
$L261:
	lbu	$14,0($2)
	addiu	$2,$2,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($2)
	addiu	$4,$4,4
	sb	$14,-2($4)
	.set	noat
	xor	$1,$2,$11
	bne	$1,$0,$L261
	.set	at
	sb	$14,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$3
$L262:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L262
	.set	at
	sb	$15,-1($4)

	addu	$24,$24,$12
	move	$4,$24
	move	$14,$3
$L263:
	lbu	$15,0($14)
	addiu	$14,$14,1
	sb	$15,0($4)
	sb	$15,1($4)
	lbu	$15,-1($14)
	addiu	$4,$4,4
	sb	$15,-2($4)
	.set	noat
	xor	$1,$14,$2
	bne	$1,$0,$L263
	.set	at
	sb	$15,-1($4)

	addu	$15,$24,$12
	move	$4,$15
$L264:
	lbu	$14,0($3)
	addiu	$3,$3,1
	sb	$14,0($4)
	sb	$14,1($4)
	lbu	$14,-1($3)
	addiu	$4,$4,4
	sb	$14,-2($4)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L264
	.set	at
	sb	$14,-1($4)

	addiu	$7,$7,1600
	addu	$15,$15,$12
	addiu	$11,$11,1600
	addiu	$10,$10,1600
	addiu	$9,$9,1600
	.set	noat
	xor	$1,$13,$7
	bne	$1,$0,$L240
	.set	at
	addiu	$8,$8,1600

	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	I_Stretch4x
	.size	I_Stretch4x, .-I_Stretch4x
	.align	2
	.globl	I_InitScale
	.set	nomips16
	.set	nomicromips
	.ent	I_InitScale
	.type	I_InitScale, @function
I_InitScale:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(src_buffer)
	sw	$4,%lo(src_buffer)($2)
	lui	$2,%hi(dest_buffer)
	sw	$5,%lo(dest_buffer)($2)
	lui	$2,%hi(dest_pitch)
	jr	$31
	sw	$6,%lo(dest_pitch)($2)

	.set	macro
	.set	reorder
	.end	I_InitScale
	.size	I_InitScale, .-I_InitScale
	.section	.rodata.str1.4
	.align	2
$LC5:
	.ascii	"I_ResetScaleTables: Regenerating lookup tables..\012\000"
	.align	2
$LC6:
	.ascii	"I_ResetScaleTables: Regenerating lookup table..\012\000"
	.text
	.align	2
	.globl	I_ResetScaleTables
	.set	nomips16
	.set	nomicromips
	.ent	I_ResetScaleTables
	.type	I_ResetScaleTables, @function
I_ResetScaleTables:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	lui	$17,%hi(stretch_tables)
	lw	$2,%lo(stretch_tables)($17)
	sw	$16,16($sp)
	sw	$31,28($sp)
	sw	$18,24($sp)
	beq	$2,$0,$L296
	move	$16,$4

	move	$4,$2
	jal	Z_Free
	addiu	$18,$17,%lo(stretch_tables)

	jal	Z_Free
	lw	$4,4($18)

	lui	$4,%hi($LC5)
	jal	printf
	addiu	$4,$4,%lo($LC5)

	move	$4,$16
	jal	GenerateStretchTable
	li	$5,20			# 0x14

	li	$5,40			# 0x28
	move	$4,$16
	jal	GenerateStretchTable
	sw	$2,%lo(stretch_tables)($17)

	sw	$2,4($18)
$L296:
	lui	$17,%hi(half_stretch_table)
	lw	$4,%lo(half_stretch_table)($17)
	beq	$4,$0,$L305
	lw	$31,28($sp)

	jal	Z_Free
	nop

	lui	$4,%hi($LC6)
	jal	printf
	addiu	$4,$4,%lo($LC6)

	li	$5,50			# 0x32
	jal	GenerateStretchTable
	move	$4,$16

	sw	$2,%lo(half_stretch_table)($17)
	lw	$31,28($sp)
$L305:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_ResetScaleTables
	.size	I_ResetScaleTables, .-I_ResetScaleTables
	.globl	mode_squash_5x
	.data
	.align	2
	.type	mode_squash_5x, @object
	.size	mode_squash_5x, 20
mode_squash_5x:
	.word	1280
	.word	1000
	.word	I_InitStretchTables
	.word	I_Squash5x
	.word	0
	.globl	mode_squash_4x
	.align	2
	.type	mode_squash_4x, @object
	.size	mode_squash_4x, 20
mode_squash_4x:
	.word	1024
	.word	800
	.word	I_InitStretchTables
	.word	I_Squash4x
	.word	0
	.globl	mode_squash_3x
	.align	2
	.type	mode_squash_3x, @object
	.size	mode_squash_3x, 20
mode_squash_3x:
	.word	800
	.word	600
	.word	I_InitSquashTable
	.word	I_Squash3x
	.word	0
	.globl	mode_squash_2x
	.align	2
	.type	mode_squash_2x, @object
	.size	mode_squash_2x, 20
mode_squash_2x:
	.word	512
	.word	400
	.word	I_InitStretchTables
	.word	I_Squash2x
	.word	0
	.globl	mode_squash_1x
	.align	2
	.type	mode_squash_1x, @object
	.size	mode_squash_1x, 20
mode_squash_1x:
	.word	256
	.word	200
	.word	I_InitStretchTables
	.word	I_Squash1x
	.word	1
	.globl	mode_stretch_5x
	.align	2
	.type	mode_stretch_5x, @object
	.size	mode_stretch_5x, 20
mode_stretch_5x:
	.word	1600
	.word	1200
	.word	I_InitStretchTables
	.word	I_Stretch5x
	.word	0
	.globl	mode_stretch_4x
	.align	2
	.type	mode_stretch_4x, @object
	.size	mode_stretch_4x, 20
mode_stretch_4x:
	.word	1280
	.word	960
	.word	I_InitStretchTables
	.word	I_Stretch4x
	.word	0
	.globl	mode_stretch_3x
	.align	2
	.type	mode_stretch_3x, @object
	.size	mode_stretch_3x, 20
mode_stretch_3x:
	.word	960
	.word	720
	.word	I_InitStretchTables
	.word	I_Stretch3x
	.word	0
	.globl	mode_stretch_2x
	.align	2
	.type	mode_stretch_2x, @object
	.size	mode_stretch_2x, 20
mode_stretch_2x:
	.word	640
	.word	480
	.word	I_InitStretchTables
	.word	I_Stretch2x
	.word	0
	.globl	mode_stretch_1x
	.align	2
	.type	mode_stretch_1x, @object
	.size	mode_stretch_1x, 20
mode_stretch_1x:
	.word	320
	.word	240
	.word	I_InitStretchTables
	.word	I_Stretch1x
	.word	1
	.globl	mode_scale_5x
	.align	2
	.type	mode_scale_5x, @object
	.size	mode_scale_5x, 20
mode_scale_5x:
	.word	1600
	.word	1000
	.word	0
	.word	I_Scale5x
	.word	0
	.globl	mode_scale_4x
	.align	2
	.type	mode_scale_4x, @object
	.size	mode_scale_4x, 20
mode_scale_4x:
	.word	1280
	.word	800
	.word	0
	.word	I_Scale4x
	.word	0
	.globl	mode_scale_3x
	.align	2
	.type	mode_scale_3x, @object
	.size	mode_scale_3x, 20
mode_scale_3x:
	.word	960
	.word	600
	.word	0
	.word	I_Scale3x
	.word	0
	.globl	mode_scale_2x
	.align	2
	.type	mode_scale_2x, @object
	.size	mode_scale_2x, 20
mode_scale_2x:
	.word	640
	.word	400
	.word	0
	.word	I_Scale2x
	.word	0
	.globl	mode_scale_1x
	.align	2
	.type	mode_scale_1x, @object
	.size	mode_scale_1x, 20
mode_scale_1x:
	.word	320
	.word	200
	.word	0
	.word	I_Scale1x
	.word	0
	.local	half_stretch_table
	.comm	half_stretch_table,4,4
	.local	stretch_tables
	.comm	stretch_tables,8,4
	.local	dest_pitch
	.comm	dest_pitch,4,4
	.local	dest_buffer
	.comm	dest_buffer,4,4
	.local	src_buffer
	.comm	src_buffer,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
