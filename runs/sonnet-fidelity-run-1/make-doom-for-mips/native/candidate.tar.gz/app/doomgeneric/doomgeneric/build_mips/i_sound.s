	.file	1 "i_sound.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"-nosound\000"
	.align	2
$LC1:
	.ascii	"-nosfx\000"
	.align	2
$LC2:
	.ascii	"-nomusic\000"
	.text
	.align	2
	.globl	I_InitSound
	.set	nomips16
	.set	nomicromips
	.ent	I_InitSound
	.type	I_InitSound, @function
I_InitSound:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-32
	addiu	$4,$4,%lo($LC0)
	sw	$31,28($sp)
	sw	$17,24($sp)
	jal	M_CheckParm
	sw	$16,20($sp)

	lui	$4,%hi($LC1)
	addiu	$4,$4,%lo($LC1)
	jal	M_CheckParm
	move	$16,$2

	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	jal	M_CheckParm
	move	$17,$2

	blez	$16,$L5
	lui	$2,%hi(screensaver_mode)

$L1:
	lw	$31,28($sp)
$L6:
	lw	$17,24($sp)
$L7:
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L5:
	lw	$2,%lo(screensaver_mode)($2)
	bne	$2,$0,$L6
	lw	$31,28($sp)

	bgtz	$17,$L7
	lw	$17,24($sp)

	lui	$2,%hi(sound_module)
	b	$L1
	sw	$0,%lo(sound_module)($2)

	.set	macro
	.set	reorder
	.end	I_InitSound
	.size	I_InitSound, .-I_InitSound
	.align	2
	.globl	I_ShutdownSound
	.set	nomips16
	.set	nomicromips
	.ent	I_ShutdownSound
	.type	I_ShutdownSound, @function
I_ShutdownSound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L10
	nop

	lw	$25,12($2)
	jr	$25
	nop

$L10:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_ShutdownSound
	.size	I_ShutdownSound, .-I_ShutdownSound
	.align	2
	.globl	I_GetSfxLumpNum
	.set	nomips16
	.set	nomicromips
	.ent	I_GetSfxLumpNum
	.type	I_GetSfxLumpNum, @function
I_GetSfxLumpNum:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L12
	nop

	lw	$25,16($2)
	jr	$25
	nop

$L12:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_GetSfxLumpNum
	.size	I_GetSfxLumpNum, .-I_GetSfxLumpNum
	.align	2
	.globl	I_UpdateSound
	.set	nomips16
	.set	nomicromips
	.ent	I_UpdateSound
	.type	I_UpdateSound, @function
I_UpdateSound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L15
	nop

	lw	$25,20($2)
	jr	$25
	nop

$L15:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_UpdateSound
	.size	I_UpdateSound, .-I_UpdateSound
	.align	2
	.globl	I_UpdateSoundParams
	.set	nomips16
	.set	nomicromips
	.ent	I_UpdateSoundParams
	.type	I_UpdateSoundParams, @function
I_UpdateSoundParams:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L18
	li	$3,254			# 0xfe

	slt	$8,$6,255
	movz	$6,$3,$8
	slt	$7,$5,128
	li	$3,127			# 0x7f
	movz	$5,$3,$7
	slt	$3,$5,0
	slt	$7,$6,0
	lw	$25,24($2)
	movn	$6,$0,$7
	jr	$25
	movn	$5,$0,$3

$L18:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_UpdateSoundParams
	.size	I_UpdateSoundParams, .-I_UpdateSoundParams
	.align	2
	.globl	I_StartSound
	.set	nomips16
	.set	nomicromips
	.ent	I_StartSound
	.type	I_StartSound, @function
I_StartSound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L20
	li	$3,254			# 0xfe

	slt	$9,$7,255
	movz	$7,$3,$9
	slt	$8,$6,128
	li	$3,127			# 0x7f
	movz	$6,$3,$8
	slt	$3,$6,0
	slt	$8,$7,0
	lw	$25,28($2)
	movn	$7,$0,$8
	jr	$25
	movn	$6,$0,$3

$L20:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_StartSound
	.size	I_StartSound, .-I_StartSound
	.align	2
	.globl	I_StopSound
	.set	nomips16
	.set	nomicromips
	.ent	I_StopSound
	.type	I_StopSound, @function
I_StopSound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L23
	nop

	lw	$25,32($2)
	jr	$25
	nop

$L23:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_StopSound
	.size	I_StopSound, .-I_StopSound
	.align	2
	.globl	I_SoundIsPlaying
	.set	nomips16
	.set	nomicromips
	.ent	I_SoundIsPlaying
	.type	I_SoundIsPlaying, @function
I_SoundIsPlaying:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L25
	nop

	lw	$25,36($2)
	jr	$25
	nop

$L25:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_SoundIsPlaying
	.size	I_SoundIsPlaying, .-I_SoundIsPlaying
	.align	2
	.globl	I_PrecacheSounds
	.set	nomips16
	.set	nomicromips
	.ent	I_PrecacheSounds
	.type	I_PrecacheSounds, @function
I_PrecacheSounds:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(sound_module)
	lw	$2,%lo(sound_module)($2)
	beq	$2,$0,$L34
	nop

	lw	$25,40($2)
	beq	$25,$0,$L34
	nop

	jr	$25
	nop

$L34:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_PrecacheSounds
	.size	I_PrecacheSounds, .-I_PrecacheSounds
	.align	2
	.globl	I_InitMusic
	.set	nomips16
	.set	nomicromips
	.ent	I_InitMusic
	.type	I_InitMusic, @function
I_InitMusic:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_InitMusic
	.size	I_InitMusic, .-I_InitMusic
	.align	2
	.globl	I_ShutdownMusic
	.set	nomips16
	.set	nomicromips
	.ent	I_ShutdownMusic
	.type	I_ShutdownMusic, @function
I_ShutdownMusic:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_ShutdownMusic
	.size	I_ShutdownMusic, .-I_ShutdownMusic
	.align	2
	.globl	I_SetMusicVolume
	.set	nomips16
	.set	nomicromips
	.ent	I_SetMusicVolume
	.type	I_SetMusicVolume, @function
I_SetMusicVolume:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_SetMusicVolume
	.size	I_SetMusicVolume, .-I_SetMusicVolume
	.align	2
	.globl	I_PauseSong
	.set	nomips16
	.set	nomicromips
	.ent	I_PauseSong
	.type	I_PauseSong, @function
I_PauseSong:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_PauseSong
	.size	I_PauseSong, .-I_PauseSong
	.align	2
	.globl	I_ResumeSong
	.set	nomips16
	.set	nomicromips
	.ent	I_ResumeSong
	.type	I_ResumeSong, @function
I_ResumeSong:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_ResumeSong
	.size	I_ResumeSong, .-I_ResumeSong
	.align	2
	.globl	I_RegisterSong
	.set	nomips16
	.set	nomicromips
	.ent	I_RegisterSong
	.type	I_RegisterSong, @function
I_RegisterSong:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_RegisterSong
	.size	I_RegisterSong, .-I_RegisterSong
	.align	2
	.globl	I_UnRegisterSong
	.set	nomips16
	.set	nomicromips
	.ent	I_UnRegisterSong
	.type	I_UnRegisterSong, @function
I_UnRegisterSong:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_UnRegisterSong
	.size	I_UnRegisterSong, .-I_UnRegisterSong
	.align	2
	.globl	I_PlaySong
	.set	nomips16
	.set	nomicromips
	.ent	I_PlaySong
	.type	I_PlaySong, @function
I_PlaySong:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_PlaySong
	.size	I_PlaySong, .-I_PlaySong
	.align	2
	.globl	I_StopSong
	.set	nomips16
	.set	nomicromips
	.ent	I_StopSong
	.type	I_StopSong, @function
I_StopSong:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_StopSong
	.size	I_StopSong, .-I_StopSong
	.align	2
	.globl	I_MusicIsPlaying
	.set	nomips16
	.set	nomicromips
	.ent	I_MusicIsPlaying
	.type	I_MusicIsPlaying, @function
I_MusicIsPlaying:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_MusicIsPlaying
	.size	I_MusicIsPlaying, .-I_MusicIsPlaying
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"snd_musicdevice\000"
	.align	2
$LC4:
	.ascii	"snd_sfxdevice\000"
	.align	2
$LC5:
	.ascii	"snd_sbport\000"
	.align	2
$LC6:
	.ascii	"snd_sbirq\000"
	.align	2
$LC7:
	.ascii	"snd_sbdma\000"
	.align	2
$LC8:
	.ascii	"snd_mport\000"
	.align	2
$LC9:
	.ascii	"snd_maxslicetime_ms\000"
	.align	2
$LC10:
	.ascii	"snd_musiccmd\000"
	.align	2
$LC11:
	.ascii	"snd_samplerate\000"
	.align	2
$LC12:
	.ascii	"snd_cachesize\000"
	.text
	.align	2
	.globl	I_BindSoundVariables
	.set	nomips16
	.set	nomicromips
	.ent	I_BindSoundVariables
	.type	I_BindSoundVariables, @function
I_BindSoundVariables:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(snd_musicdevice)
	lui	$4,%hi($LC3)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(snd_musicdevice)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC3)

	lui	$5,%hi(snd_sfxdevice)
	lui	$4,%hi($LC4)
	addiu	$5,$5,%lo(snd_sfxdevice)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC4)

	lui	$5,%hi(snd_sbport)
	lui	$4,%hi($LC5)
	addiu	$5,$5,%lo(snd_sbport)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC5)

	lui	$5,%hi(snd_sbirq)
	lui	$4,%hi($LC6)
	addiu	$5,$5,%lo(snd_sbirq)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC6)

	lui	$5,%hi(snd_sbdma)
	lui	$4,%hi($LC7)
	addiu	$5,$5,%lo(snd_sbdma)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC7)

	lui	$5,%hi(snd_mport)
	lui	$4,%hi($LC8)
	addiu	$5,$5,%lo(snd_mport)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC8)

	lui	$5,%hi(snd_maxslicetime_ms)
	lui	$4,%hi($LC9)
	addiu	$5,$5,%lo(snd_maxslicetime_ms)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC9)

	lui	$5,%hi(snd_musiccmd)
	lui	$4,%hi($LC10)
	addiu	$5,$5,%lo(snd_musiccmd)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC10)

	lui	$5,%hi(snd_samplerate)
	lui	$4,%hi($LC11)
	addiu	$5,$5,%lo(snd_samplerate)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC11)

	lw	$31,20($sp)
	lui	$5,%hi(snd_cachesize)
	lui	$4,%hi($LC12)
	addiu	$5,$5,%lo(snd_cachesize)
	addiu	$4,$4,%lo($LC12)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	I_BindSoundVariables
	.size	I_BindSoundVariables, .-I_BindSoundVariables
	.local	snd_mport
	.comm	snd_mport,4,4
	.local	snd_sbdma
	.comm	snd_sbdma,4,4
	.local	snd_sbirq
	.comm	snd_sbirq,4,4
	.local	snd_sbport
	.comm	snd_sbport,4,4
	.globl	snd_sfxdevice
	.data
	.align	2
	.type	snd_sfxdevice, @object
	.size	snd_sfxdevice, 4
snd_sfxdevice:
	.word	3
	.globl	snd_musicdevice
	.align	2
	.type	snd_musicdevice, @object
	.size	snd_musicdevice, 4
snd_musicdevice:
	.word	3
	.local	sound_module
	.comm	sound_module,4,4
	.globl	snd_musiccmd
	.section	.rodata.str1.4
	.align	2
$LC13:
	.ascii	"\000"
	.data
	.align	2
	.type	snd_musiccmd, @object
	.size	snd_musiccmd, 4
snd_musiccmd:
	.word	$LC13
	.globl	snd_maxslicetime_ms
	.align	2
	.type	snd_maxslicetime_ms, @object
	.size	snd_maxslicetime_ms, 4
snd_maxslicetime_ms:
	.word	28
	.globl	snd_cachesize
	.align	2
	.type	snd_cachesize, @object
	.size	snd_cachesize, 4
snd_cachesize:
	.word	67108864
	.globl	snd_samplerate
	.align	2
	.type	snd_samplerate, @object
	.size	snd_samplerate, 4
snd_samplerate:
	.word	44100
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
