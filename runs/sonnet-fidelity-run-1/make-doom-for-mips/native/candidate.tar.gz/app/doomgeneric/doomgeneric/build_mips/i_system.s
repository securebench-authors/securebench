	.file	1 "i_system.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	I_AtExit
	.set	nomips16
	.set	nomicromips
	.ent	I_AtExit
	.type	I_AtExit, @function
I_AtExit:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	move	$17,$4
	li	$4,12			# 0xc
	sw	$16,20($sp)
	sw	$31,28($sp)
	jal	malloc
	move	$16,$5

	lui	$3,%hi(exit_funcs)
	lw	$4,%lo(exit_funcs)($3)
	lw	$31,28($sp)
	sw	$17,0($2)
	sw	$16,4($2)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$4,8($2)
	sw	$2,%lo(exit_funcs)($3)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_AtExit
	.size	I_AtExit, .-I_AtExit
	.align	2
	.globl	I_Tactile
	.set	nomips16
	.set	nomicromips
	.ent	I_Tactile
	.type	I_Tactile, @function
I_Tactile:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_Tactile
	.size	I_Tactile, .-I_Tactile
	.align	2
	.globl	I_PrintBanner
	.set	nomips16
	.set	nomicromips
	.ent	I_PrintBanner
	.type	I_PrintBanner, @function
I_PrintBanner:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$31,28($sp)
	sw	$16,16($sp)
	jal	strlen
	move	$18,$4

	srl	$2,$2,1
	li	$17,35			# 0x23
	subu	$17,$17,$2
	blez	$17,$L6
	move	$16,$0

	addiu	$16,$16,1
$L10:
	jal	putchar
	li	$4,32			# 0x20

	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L10
	.set	at
	addiu	$16,$16,1

$L6:
	lw	$31,28($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$4,$18
	lw	$18,24($sp)
	j	puts
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_PrintBanner
	.size	I_PrintBanner, .-I_PrintBanner
	.align	2
	.globl	I_PrintDivider
	.set	nomips16
	.set	nomicromips
	.ent	I_PrintDivider
	.type	I_PrintDivider, @function
I_PrintDivider:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	li	$16,75			# 0x4b
	addiu	$16,$16,-1
$L15:
	jal	putchar
	li	$4,61			# 0x3d

	bne	$16,$0,$L15
	addiu	$16,$16,-1

	lw	$31,20($sp)
	lw	$16,16($sp)
	li	$4,10			# 0xa
	j	putchar
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	I_PrintDivider
	.size	I_PrintDivider, .-I_PrintDivider
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	" Doom Generic is free software, covered by the GNU Gener"
	.ascii	"al Public\012 License.  There is NO warranty; not even f"
	.ascii	"or MERCHANTABILITY or FITNESS\012 FOR A PARTICULAR PURPO"
	.ascii	"SE. You are welcome to change and distribute\012 copies "
	.ascii	"under certain conditions. See the source for more inform"
	.ascii	"ation.\012\000"
	.text
	.align	2
	.globl	I_PrintStartupBanner
	.set	nomips16
	.set	nomicromips
	.ent	I_PrintStartupBanner
	.type	I_PrintStartupBanner, @function
I_PrintStartupBanner:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	sw	$17,20($sp)
	move	$18,$4
	li	$16,75			# 0x4b
	addiu	$16,$16,-1
$L27:
	jal	putchar
	li	$4,61			# 0x3d

	bne	$16,$0,$L27
	addiu	$16,$16,-1

	addiu	$16,$16,1
	jal	putchar
	li	$4,10			# 0xa

	jal	strlen
	move	$4,$18

	srl	$2,$2,1
	li	$17,35			# 0x23
	subu	$17,$17,$2
	blez	$17,$L18
	addiu	$16,$16,1

$L28:
	jal	putchar
	li	$4,32			# 0x20

	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L28
	.set	at
	addiu	$16,$16,1

$L18:
	jal	puts
	move	$4,$18

	li	$16,75			# 0x4b
	addiu	$16,$16,-1
$L29:
	jal	putchar
	li	$4,61			# 0x3d

	bne	$16,$0,$L29
	addiu	$16,$16,-1

	jal	putchar
	li	$4,10			# 0xa

	lui	$4,%hi($LC0)
	jal	printf
	addiu	$4,$4,%lo($LC0)

	li	$16,75			# 0x4b
	addiu	$16,$16,-1
$L30:
	jal	putchar
	li	$4,61			# 0x3d

	bne	$16,$0,$L30
	addiu	$16,$16,-1

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$4,10			# 0xa
	j	putchar
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_PrintStartupBanner
	.size	I_PrintStartupBanner, .-I_PrintStartupBanner
	.align	2
	.globl	I_ConsoleStdout
	.set	nomips16
	.set	nomicromips
	.ent	I_ConsoleStdout
	.type	I_ConsoleStdout, @function
I_ConsoleStdout:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	I_ConsoleStdout
	.size	I_ConsoleStdout, .-I_ConsoleStdout
	.align	2
	.globl	I_Quit
	.set	nomips16
	.set	nomicromips
	.ent	I_Quit
	.type	I_Quit, @function
I_Quit:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	lui	$2,%hi(exit_funcs)
	sw	$16,16($sp)
	lw	$16,%lo(exit_funcs)($2)
	beq	$16,$0,$L32
	sw	$31,20($sp)

$L34:
	lw	$2,0($16)
	jalr	$2
	nop

	lw	$16,8($16)
	bne	$16,$0,$L34
	nop

$L32:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	I_Quit
	.size	I_Quit, .-I_Quit
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Warning: recursive call to I_Error detected.\012\000"
	.align	2
$LC2:
	.ascii	"\012\012\000"
	.align	2
$LC3:
	.ascii	"-nogui\000"
	.align	2
$LC4:
	.ascii	"/usr/bin/zenity --help >/dev/null 2>&1\000"
	.align	2
$LC5:
	.ascii	"$`\\!\000"
	.align	2
$LC6:
	.ascii	"/usr/bin/zenity\000"
	.align	2
$LC7:
	.ascii	"%s --error --text=%s\000"
	.text
	.align	2
	.globl	I_Error
	.set	nomips16
	.set	nomicromips
	.ent	I_Error
	.type	I_Error, @function
I_Error:
	.frame	$sp,568,$31		# vars= 520, regs= 6/0, args= 24, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(already_quitting)
	lw	$3,%lo(already_quitting)($2)
	addiu	$sp,$sp,-568
	sw	$16,544($sp)
	sw	$31,564($sp)
	sw	$20,560($sp)
	sw	$19,556($sp)
	sw	$18,552($sp)
	sw	$17,548($sp)
	move	$16,$4
	sw	$5,572($sp)
	sw	$6,576($sp)
	bne	$3,$0,$L64
	sw	$7,580($sp)

	li	$3,1			# 0x1
	sw	$3,%lo(already_quitting)($2)
	lui	$17,%hi(stderr)
	lw	$4,%lo(stderr)($17)
$L66:
	addiu	$6,$sp,572
	move	$5,$16
	jal	vfprintf
	sw	$6,536($sp)

	lw	$4,%lo(stderr)($17)
	lui	$5,%hi($LC2)
	jal	fprintf
	addiu	$5,$5,%lo($LC2)

	jal	fflush
	lw	$4,%lo(stderr)($17)

	addiu	$4,$sp,24
	li	$6,512			# 0x200
	move	$5,$0
	addiu	$2,$sp,572
	jal	memset
	sw	$2,536($sp)

	lw	$7,536($sp)
	move	$6,$16
	li	$5,512			# 0x200
	jal	M_vsnprintf
	addiu	$4,$sp,24

	lui	$2,%hi(exit_funcs)
	lw	$16,%lo(exit_funcs)($2)
	beq	$16,$0,$L47
	nop

$L43:
	lw	$2,4($16)
	beq	$2,$0,$L46
	nop

	lw	$2,0($16)
	jalr	$2
	nop

$L46:
	lw	$16,8($16)
	bne	$16,$0,$L43
	nop

$L47:
	lui	$4,%hi($LC3)
	jal	M_ParmExists
	addiu	$4,$4,%lo($LC3)

	beq	$2,$0,$L44
	nop

$L62:
	b	$L62
	nop

$L64:
	lui	$17,%hi(stderr)
	lw	$4,%lo(stderr)($17)
	lui	$5,%hi($LC1)
	jal	fprintf
	addiu	$5,$5,%lo($LC1)

	b	$L66
	lw	$4,%lo(stderr)($17)

$L44:
	lui	$4,%hi($LC4)
	jal	system
	addiu	$4,$4,%lo($LC4)

	bne	$2,$0,$L62
	nop

	jal	strlen
	addiu	$4,$sp,24

	sll	$4,$2,1
	jal	malloc
	addiu	$4,$4,3

	move	$19,$2
	li	$2,34			# 0x22
	sb	$2,0($19)
	lb	$5,24($sp)
	beq	$5,$0,$L48
	addiu	$17,$19,1

	lui	$18,%hi($LC5)
	addiu	$16,$sp,24
	addiu	$18,$18,%lo($LC5)
	b	$L50
	li	$20,92			# 0x5c

$L65:
	addiu	$2,$17,1
	sb	$20,0($17)
	lb	$3,0($16)
$L67:
	addiu	$16,$16,1
	sb	$3,0($2)
	lb	$5,0($16)
	beq	$5,$0,$L48
	addiu	$17,$2,1

$L50:
	jal	strchr
	move	$4,$18

	bne	$2,$0,$L65
	move	$2,$17

	b	$L67
	lb	$3,0($16)

$L48:
	lui	$18,%hi($LC6)
	li	$2,34			# 0x22
	addiu	$4,$18,%lo($LC6)
	sb	$2,0($17)
	jal	strlen
	sb	$0,1($17)

	move	$4,$19
	jal	strlen
	move	$16,$2

	addu	$4,$16,$2
	addiu	$4,$4,19
	lui	$17,%hi(errorboxpath_size.1)
	jal	malloc
	sw	$4,%lo(errorboxpath_size.1)($17)

	lw	$5,%lo(errorboxpath_size.1)($17)
	lui	$6,%hi($LC7)
	move	$16,$2
	addiu	$7,$18,%lo($LC6)
	addiu	$6,$6,%lo($LC7)
	sw	$19,16($sp)
	jal	M_snprintf
	move	$4,$2

	jal	system
	move	$4,$16

	jal	free
	move	$4,$16

	jal	free
	move	$4,$19

	b	$L62
	nop

	.set	macro
	.set	reorder
	.end	I_Error
	.size	I_Error, .-I_Error
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"-mb\000"
	.align	2
$LC9:
	.ascii	"zone memory: %p, %x allocated for zone\012\000"
	.align	2
$LC10:
	.ascii	"Unable to allocate %i MiB of RAM for zone\000"
	.text
	.align	2
	.globl	I_ZoneBase
	.set	nomips16
	.set	nomicromips
	.ent	I_ZoneBase
	.type	I_ZoneBase, @function
I_ZoneBase:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	move	$18,$4
	lui	$4,%hi($LC8)
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC8)
	sw	$31,28($sp)
	sw	$17,20($sp)
	jal	M_CheckParmWithArgs
	sw	$16,16($sp)

	bgtz	$2,$L75
	lui	$3,%hi(myargv)

	li	$4,6291456			# 0x600000
	li	$2,6291456			# 0x600000
	li	$16,6			# 0x6
$L69:
	jal	malloc
	sw	$2,0($18)

	bne	$2,$0,$L73
	move	$17,$2

	lui	$4,%hi($LC10)
	addiu	$5,$16,-1
	jal	I_Error
	addiu	$4,$4,%lo($LC10)

$L73:
	lw	$6,0($18)
	lui	$4,%hi($LC9)
	move	$5,$2
	jal	printf
	addiu	$4,$4,%lo($LC9)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L75:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	atoi
	lw	$4,0($2)

	move	$16,$2
	sll	$2,$2,20
	b	$L69
	move	$4,$2

	.set	macro
	.set	reorder
	.end	I_ZoneBase
	.size	I_ZoneBase, .-I_ZoneBase
	.section	.rodata.str1.4
	.align	2
$LC11:
	.ascii	"-setmem\000"
	.align	2
$LC12:
	.ascii	"dos622\000"
	.align	2
$LC13:
	.ascii	"dos71\000"
	.align	2
$LC14:
	.ascii	"dosbox\000"
	.text
	.align	2
	.globl	I_GetMemoryValue
	.set	nomips16
	.set	nomicromips
	.ent	I_GetMemoryValue
	.type	I_GetMemoryValue, @function
I_GetMemoryValue:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(firsttime.0)
	lw	$3,%lo(firsttime.0)($2)
	addiu	$sp,$sp,-72
	sw	$fp,64($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	sw	$31,68($sp)
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	move	$fp,$4
	move	$17,$5
	bne	$3,$0,$L97
	move	$16,$6

$L77:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L85
	.set	at
	lui	$2,%hi(dos_mem_dump)

	li	$2,4			# 0x4
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L86
	.set	at
	lui	$2,%hi(dos_mem_dump)

	li	$2,1			# 0x1
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L98
	.set	at
	lw	$31,68($sp)

	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,72

$L97:
	lui	$4,%hi($LC11)
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC11)
	jal	M_CheckParmWithArgs
	sw	$0,%lo(firsttime.0)($2)

	blez	$2,$L77
	move	$18,$2

	lui	$20,%hi(myargv)
	lw	$2,%lo(myargv)($20)
	addiu	$19,$18,1
	sll	$22,$19,2
	addu	$2,$2,$22
	lw	$4,0($2)
	lui	$5,%hi($LC12)
	jal	strcasecmp
	addiu	$5,$5,%lo($LC12)

	bne	$2,$0,$L79
	lui	$21,%hi(dos_mem_dump)

	lui	$2,%hi(mem_dump_dos622)
	addiu	$2,$2,%lo(mem_dump_dos622)
	sw	$2,%lo(dos_mem_dump)($21)
$L79:
	lw	$2,%lo(myargv)($20)
	lui	$5,%hi($LC13)
	addu	$2,$2,$22
	lw	$4,0($2)
	jal	strcasecmp
	addiu	$5,$5,%lo($LC13)

	bne	$2,$0,$L80
	lui	$2,%hi(mem_dump_win98)

	addiu	$2,$2,%lo(mem_dump_win98)
	b	$L77
	sw	$2,%lo(dos_mem_dump)($21)

$L98:
	lui	$2,%hi(dos_mem_dump)
	lw	$2,%lo(dos_mem_dump)($2)
	addu	$2,$2,$fp
	lbu	$2,0($2)
	sb	$2,0($17)
	li	$2,1			# 0x1
$L99:
	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L86:
	lw	$3,%lo(dos_mem_dump)($2)
	addu	$3,$3,$fp
	lbu	$2,1($3)
	lbu	$4,2($3)
	lbu	$5,0($3)
	sll	$2,$2,8
	lbu	$3,3($3)
	sll	$4,$4,16
	or	$2,$2,$4
	or	$2,$2,$5
	sll	$3,$3,24
	or	$2,$2,$3
	sw	$2,0($17)
	b	$L99
	li	$2,1			# 0x1

$L85:
	lw	$3,%lo(dos_mem_dump)($2)
	addu	$3,$3,$fp
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sh	$2,0($17)
	b	$L99
	li	$2,1			# 0x1

$L80:
	lw	$2,%lo(myargv)($20)
	lui	$5,%hi($LC14)
	addu	$2,$2,$22
	lw	$4,0($2)
	jal	strcasecmp
	addiu	$5,$5,%lo($LC14)

	bne	$2,$0,$L81
	lui	$22,%hi(mem_dump_custom)

	lui	$2,%hi(mem_dump_dosbox)
	addiu	$2,$2,%lo(mem_dump_dosbox)
	b	$L77
	sw	$2,%lo(dos_mem_dump)($21)

$L81:
	addiu	$2,$22,%lo(mem_dump_custom)
	lui	$23,%hi(myargc)
	sw	$2,24($sp)
	move	$22,$2
	lw	$2,%lo(myargc)($23)
	addiu	$18,$18,5
	slt	$2,$19,$2
	sll	$4,$19,2
	beq	$2,$0,$L83
	addiu	$5,$sp,16

$L82:
	lw	$2,%lo(myargv)($20)
	li	$3,45			# 0x2d
	addu	$2,$2,$4
	lw	$4,0($2)
	lb	$2,0($4)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L100
	.set	at
	lw	$2,24($sp)

	jal	M_StrToInt
	addiu	$22,$22,2

	lw	$2,16($sp)
	.set	noat
	xor	$1,$19,$18
	beq	$1,$0,$L83
	.set	at
	sb	$2,-2($22)

	lw	$2,%lo(myargc)($23)
	addiu	$19,$19,1
	slt	$2,$19,$2
	sll	$4,$19,2
	bne	$2,$0,$L82
	addiu	$5,$sp,16

$L83:
	lw	$2,24($sp)
$L100:
	b	$L77
	sw	$2,%lo(dos_mem_dump)($21)

	.set	macro
	.set	reorder
	.end	I_GetMemoryValue
	.size	I_GetMemoryValue, .-I_GetMemoryValue
	.data
	.align	2
	.type	firsttime.0, @object
	.size	firsttime.0, 4
firsttime.0:
	.word	1
	.local	errorboxpath_size.1
	.comm	errorboxpath_size.1,4,4
	.align	2
	.type	dos_mem_dump, @object
	.size	dos_mem_dump, 4
dos_mem_dump:
	.word	mem_dump_dos622
	.local	mem_dump_custom
	.comm	mem_dump_custom,10,4
	.rdata
	.align	2
	.type	mem_dump_dosbox, @object
	.size	mem_dump_dosbox, 10
mem_dump_dosbox:
	.ascii	"\000\000\000\361\000\000\000\000\007\000"
	.align	2
	.type	mem_dump_win98, @object
	.size	mem_dump_win98, 10
mem_dump_win98:
	.ascii	"\236\017\311\000e\004p\000\026\000"
	.align	2
	.type	mem_dump_dos622, @object
	.size	mem_dump_dos622, 10
mem_dump_dos622:
	.ascii	"W\222\031\000\364\006p\000\026\000"
	.local	already_quitting
	.comm	already_quitting,4,4
	.local	exit_funcs
	.comm	exit_funcs,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
