	.file	1 "i_timer.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	I_GetTicks
	.set	nomips16
	.set	nomicromips
	.ent	I_GetTicks
	.type	I_GetTicks, @function
I_GetTicks:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	DG_GetTicksMs
	nop

	.set	macro
	.set	reorder
	.end	I_GetTicks
	.size	I_GetTicks, .-I_GetTicks
	.align	2
	.globl	I_GetTime
	.set	nomips16
	.set	nomicromips
	.ent	I_GetTime
	.type	I_GetTime, @function
I_GetTime:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	DG_GetTicksMs
	nop

	lui	$3,%hi(basetime)
	lw	$4,%lo(basetime)($3)
	beq	$4,$0,$L4
	lw	$31,20($sp)

	subu	$3,$2,$4
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	li	$3,274857984			# 0x10620000
	addiu	$3,$3,19923
	multu	$2,$3
	mfhi	$2
	addiu	$sp,$sp,24
	jr	$31
	srl	$2,$2,6

$L4:
	sw	$2,%lo(basetime)($3)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	I_GetTime
	.size	I_GetTime, .-I_GetTime
	.align	2
	.globl	I_GetTimeMS
	.set	nomips16
	.set	nomicromips
	.ent	I_GetTimeMS
	.type	I_GetTimeMS, @function
I_GetTimeMS:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	DG_GetTicksMs
	nop

	lui	$3,%hi(basetime)
	lw	$4,%lo(basetime)($3)
	beq	$4,$0,$L8
	lw	$31,20($sp)

	subu	$2,$2,$4
	jr	$31
	addiu	$sp,$sp,24

$L8:
	sw	$2,%lo(basetime)($3)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	I_GetTimeMS
	.size	I_GetTimeMS, .-I_GetTimeMS
	.align	2
	.globl	I_Sleep
	.set	nomips16
	.set	nomicromips
	.ent	I_Sleep
	.type	I_Sleep, @function
I_Sleep:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	DG_SleepMs
	nop

	.set	macro
	.set	reorder
	.end	I_Sleep
	.size	I_Sleep, .-I_Sleep
	.align	2
	.globl	I_WaitVBL
	.set	nomips16
	.set	nomicromips
	.ent	I_WaitVBL
	.type	I_WaitVBL, @function
I_WaitVBL:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_WaitVBL
	.size	I_WaitVBL, .-I_WaitVBL
	.align	2
	.globl	I_InitTimer
	.set	nomips16
	.set	nomicromips
	.ent	I_InitTimer
	.type	I_InitTimer, @function
I_InitTimer:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_InitTimer
	.size	I_InitTimer, .-I_InitTimer
	.local	basetime
	.comm	basetime,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
