	.file	1 "i_video.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	cmap_to_rgb565
	.set	nomips16
	.set	nomicromips
	.ent	cmap_to_rgb565
	.type	cmap_to_rgb565, @function
cmap_to_rgb565:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	blez	$6,$L7
	lui	$2,%hi(fb_scaling)

	lw	$10,%lo(fb_scaling)($2)
	lui	$9,%hi(colors)
	addu	$8,$5,$6
	sll	$11,$10,1
	addiu	$9,$9,%lo(colors)
$L4:
	lbu	$3,0($5)
	addiu	$5,$5,1
	sll	$3,$3,2
	addu	$3,$9,$3
	lbu	$2,1($3)
	lbu	$6,2($3)
	lbu	$7,0($3)
	srl	$2,$2,2
	srl	$3,$6,3
	sll	$3,$3,11
	sll	$2,$2,5
	or	$2,$2,$3
	srl	$3,$7,3
	or	$2,$2,$3
	blez	$10,$L3
	sh	$2,0($4)

	addu	$4,$4,$11
$L3:
	.set	noat
	xor	$1,$5,$8
	bne	$1,$0,$L4
	.set	at
	nop

$L7:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	cmap_to_rgb565
	.size	cmap_to_rgb565, .-cmap_to_rgb565
	.align	2
	.globl	cmap_to_fb
	.set	nomips16
	.set	nomicromips
	.ent	cmap_to_fb
	.type	cmap_to_fb, @function
cmap_to_fb:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	blez	$6,$L21
	move	$9,$5

	addu	$11,$5,$6
	lui	$12,%hi(colors)
	lui	$5,%hi(s_Fb)
	addiu	$12,$12,%lo(colors)
	addiu	$5,$5,%lo(s_Fb)
	lui	$8,%hi(fb_scaling)
	li	$10,8			# 0x8
$L14:
	lbu	$2,0($9)
	lw	$14,24($5)
	sll	$2,$2,2
	addu	$2,$12,$2
	lw	$13,32($5)
	lbu	$6,2($2)
	lbu	$3,1($2)
	lw	$7,40($5)
	subu	$13,$10,$13
	lw	$25,20($5)
	lw	$24,28($5)
	lbu	$2,0($2)
	subu	$14,$10,$14
	sra	$3,$3,$13
	subu	$7,$10,$7
	lw	$15,36($5)
	sra	$6,$6,$14
	sra	$2,$2,$7
	sll	$6,$6,$25
	sll	$3,$3,$24
	lw	$13,%lo(fb_scaling)($8)
	or	$6,$6,$3
	sll	$2,$2,$15
	or	$6,$6,$2
	blez	$13,$L11
	move	$7,$0

$L10:
	lw	$2,16($5)
	srl	$2,$2,3
	beq	$2,$0,$L13
	move	$3,$0

$L12:
	sll	$2,$3,3
	srl	$2,$6,$2
	sb	$2,0($4)
	lw	$2,16($5)
	addiu	$3,$3,1
	srl	$2,$2,3
	sltu	$2,$3,$2
	bne	$2,$0,$L12
	addiu	$4,$4,1

$L13:
	lw	$2,%lo(fb_scaling)($8)
	addiu	$7,$7,1
	slt	$2,$7,$2
	bne	$2,$0,$L10
	nop

$L11:
	addiu	$9,$9,1
	.set	noat
	xor	$1,$9,$11
	bne	$1,$0,$L14
	.set	at
	nop

$L21:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	cmap_to_fb
	.size	cmap_to_fb, .-cmap_to_fb
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"I_InitGraphics: framebuffer: x_res: %d, y_res: %d, x_vir"
	.ascii	"tual: %d, y_virtual: %d, bpp: %d\012\000"
	.align	2
$LC1:
	.ascii	"I_InitGraphics: framebuffer: RGBA: %d%d%d%d, red_off: %d"
	.ascii	", green_off: %d, blue_off: %d, transp_off: %d\012\000"
	.align	2
$LC2:
	.ascii	"I_InitGraphics: DOOM screen size: w x h: %d x %d\012\000"
	.align	2
$LC3:
	.ascii	"-scaling\000"
	.align	2
$LC4:
	.ascii	"I_InitGraphics: Scaling factor: %d\012\000"
	.align	2
$LC5:
	.ascii	"I_InitGraphics: Auto-scaling factor: %d\012\000"
	.text
	.align	2
	.globl	I_InitGraphics
	.set	nomips16
	.set	nomicromips
	.ent	I_InitGraphics
	.type	I_InitGraphics, @function
I_InitGraphics:
	.frame	$sp,56,$31		# vars= 0, regs= 3/0, args= 40, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,48($sp)
	lui	$17,%hi(s_Fb)
	li	$6,52			# 0x34
	move	$5,$0
	addiu	$4,$17,%lo(s_Fb)
	sw	$31,52($sp)
	jal	memset
	sw	$16,44($sp)

	addiu	$16,$17,%lo(s_Fb)
	li	$2,8			# 0x8
	li	$3,400			# 0x190
	li	$8,32			# 0x20
	sw	$8,20($sp)
	sw	$3,16($sp)
	sw	$2,40($16)
	sw	$2,32($16)
	sw	$2,24($16)
	sw	$2,48($16)
	sw	$2,28($16)
	li	$2,16			# 0x10
	li	$9,640			# 0x280
	sw	$2,20($16)
	lui	$4,%hi($LC0)
	li	$2,24			# 0x18
	li	$7,640			# 0x280
	li	$6,400			# 0x190
	li	$5,640			# 0x280
	addiu	$4,$4,%lo($LC0)
	sw	$3,4($16)
	sw	$9,8($16)
	sw	$3,12($16)
	sw	$8,16($16)
	sw	$2,44($16)
	sw	$0,36($16)
	jal	printf
	sw	$9,%lo(s_Fb)($17)

	lw	$4,28($16)
	lw	$9,44($16)
	lw	$8,36($16)
	lw	$3,20($16)
	lw	$2,48($16)
	lw	$7,40($16)
	lw	$6,32($16)
	lw	$5,24($16)
	sw	$4,24($sp)
	lui	$4,%hi($LC1)
	sw	$9,32($sp)
	sw	$8,28($sp)
	sw	$3,20($sp)
	addiu	$4,$4,%lo($LC1)
	jal	printf
	sw	$2,16($sp)

	lui	$4,%hi($LC2)
	li	$5,320			# 0x140
	addiu	$4,$4,%lo($LC2)
	jal	printf
	li	$6,200			# 0xc8

	lui	$4,%hi($LC3)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC3)

	bgtz	$2,$L27
	lw	$5,%lo(s_Fb)($17)

	li	$3,-859045888			# 0xffffffffcccc0000
	ori	$3,$3,0xcccd
	multu	$5,$3
	lw	$2,4($16)
	li	$3,1374355456			# 0x51eb0000
	ori	$3,$3,0x851f
	mfhi	$5
	multu	$2,$3
	srl	$5,$5,8
	mfhi	$2
	lui	$4,%hi(fb_scaling)
	srl	$2,$2,6
	sltu	$3,$2,$5
	bne	$3,$0,$L28
	sw	$5,%lo(fb_scaling)($4)

$L25:
	lui	$4,%hi($LC5)
	jal	printf
	addiu	$4,$4,%lo($LC5)

	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,64000			# 0xfa00

	lw	$31,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	lui	$3,%hi(I_VideoBuffer)
	sw	$2,%lo(I_VideoBuffer)($3)
	lui	$2,%hi(screenvisible)
	li	$3,1			# 0x1
	addiu	$sp,$sp,56
	j	I_InitInput
	sw	$3,%lo(screenvisible)($2)

$L28:
	move	$5,$2
	b	$L25
	sw	$2,%lo(fb_scaling)($4)

$L27:
	lui	$3,%hi(myargv)
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	jal	atoi
	lw	$4,0($2)

	lui	$4,%hi($LC4)
	move	$5,$2
	addiu	$4,$4,%lo($LC4)
	lui	$2,%hi(fb_scaling)
	jal	printf
	sw	$5,%lo(fb_scaling)($2)

	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,64000			# 0xfa00

	lw	$31,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	lui	$3,%hi(I_VideoBuffer)
	sw	$2,%lo(I_VideoBuffer)($3)
	lui	$2,%hi(screenvisible)
	li	$3,1			# 0x1
	addiu	$sp,$sp,56
	j	I_InitInput
	sw	$3,%lo(screenvisible)($2)

	.set	macro
	.set	reorder
	.end	I_InitGraphics
	.size	I_InitGraphics, .-I_InitGraphics
	.align	2
	.globl	I_ShutdownGraphics
	.set	nomips16
	.set	nomicromips
	.ent	I_ShutdownGraphics
	.type	I_ShutdownGraphics, @function
I_ShutdownGraphics:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(I_VideoBuffer)
	j	Z_Free
	lw	$4,%lo(I_VideoBuffer)($2)

	.set	macro
	.set	reorder
	.end	I_ShutdownGraphics
	.size	I_ShutdownGraphics, .-I_ShutdownGraphics
	.align	2
	.globl	I_StartFrame
	.set	nomips16
	.set	nomicromips
	.ent	I_StartFrame
	.type	I_StartFrame, @function
I_StartFrame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_StartFrame
	.size	I_StartFrame, .-I_StartFrame
	.align	2
	.globl	I_StartTic
	.set	nomips16
	.set	nomicromips
	.ent	I_StartTic
	.type	I_StartTic, @function
I_StartTic:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	I_GetEvent
	nop

	.set	macro
	.set	reorder
	.end	I_StartTic
	.size	I_StartTic, .-I_StartTic
	.align	2
	.globl	I_UpdateNoBlit
	.set	nomips16
	.set	nomicromips
	.ent	I_UpdateNoBlit
	.type	I_UpdateNoBlit, @function
I_UpdateNoBlit:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_UpdateNoBlit
	.size	I_UpdateNoBlit, .-I_UpdateNoBlit
	.align	2
	.globl	I_FinishUpdate
	.set	nomips16
	.set	nomicromips
	.ent	I_FinishUpdate
	.type	I_FinishUpdate, @function
I_FinishUpdate:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,24($sp)
	lui	$17,%hi(fb_scaling)
	lw	$2,%lo(fb_scaling)($17)
	sw	$23,48($sp)
	sll	$4,$2,2
	lui	$23,%hi(s_Fb)
	lw	$3,%lo(s_Fb)($23)
	addu	$4,$4,$2
	addiu	$23,$23,%lo(s_Fb)
	sll	$4,$4,6
	lw	$5,16($23)
	subu	$3,$3,$4
	multu	$3,$5
	mflo	$3
	lui	$4,%hi(I_VideoBuffer)
	sw	$16,20($sp)
	lw	$16,%lo(I_VideoBuffer)($4)
	lui	$4,%hi(DG_ScreenBuffer)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	li	$20,64000			# 0xfa00
	srl	$19,$3,4
	lw	$21,%lo(DG_ScreenBuffer)($4)
	srl	$3,$3,3
	sw	$18,28($sp)
	sw	$31,52($sp)
	sw	$22,44($sp)
	subu	$18,$3,$19
	addu	$20,$16,$20
$L34:
	blez	$2,$L37
	move	$22,$0

$L35:
	addu	$21,$21,$19
	move	$4,$21
	li	$6,320			# 0x140
	jal	cmap_to_fb
	move	$5,$16

	lw	$3,16($23)
	lw	$4,%lo(fb_scaling)($17)
	srl	$3,$3,3
	multu	$3,$4
	mflo	$3
	addiu	$22,$22,1
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,6
	addu	$2,$2,$18
	slt	$4,$22,$4
	bne	$4,$0,$L35
	addu	$21,$21,$2

$L37:
	addiu	$16,$16,320
	.set	noat
	xor	$1,$16,$20
	bne	$1,$0,$L34
	.set	at
	lw	$2,%lo(fb_scaling)($17)

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	DG_DrawFrame
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	I_FinishUpdate
	.size	I_FinishUpdate, .-I_FinishUpdate
	.align	2
	.globl	I_ReadScreen
	.set	nomips16
	.set	nomicromips
	.ent	I_ReadScreen
	.type	I_ReadScreen, @function
I_ReadScreen:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(I_VideoBuffer)
	lw	$5,%lo(I_VideoBuffer)($2)
	j	memcpy
	li	$6,64000			# 0xfa00

	.set	macro
	.set	reorder
	.end	I_ReadScreen
	.size	I_ReadScreen, .-I_ReadScreen
	.align	2
	.globl	I_SetPalette
	.set	nomips16
	.set	nomicromips
	.ent	I_SetPalette
	.type	I_SetPalette, @function
I_SetPalette:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(usegamma)
	lw	$2,%lo(usegamma)($2)
	lui	$8,%hi(colors)
	lui	$6,%hi(gammatable)
	addiu	$8,$8,%lo(colors)
	sll	$2,$2,8
	addiu	$6,$6,%lo(gammatable)
	move	$7,$8
	move	$3,$0
	addu	$6,$6,$2
	li	$9,256			# 0x100
$L44:
	sll	$2,$3,2
	addu	$2,$8,$2
	sb	$0,3($2)
	lbu	$5,0($4)
	addiu	$4,$4,3
	addu	$5,$6,$5
	lbu	$5,0($5)
	addiu	$7,$7,4
	sb	$5,2($2)
	lbu	$5,-2($4)
	lbu	$2,-1($4)
	addu	$5,$6,$5
	lbu	$5,0($5)
	addu	$2,$6,$2
	lbu	$2,0($2)
	sll	$5,$5,8
	or	$2,$2,$5
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L44
	.set	at
	sh	$2,-4($7)

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_SetPalette
	.size	I_SetPalette, .-I_SetPalette
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"I_GetPaletteIndex\012\000"
	.text
	.align	2
	.globl	I_GetPaletteIndex
	.set	nomips16
	.set	nomicromips
	.ent	I_GetPaletteIndex
	.type	I_GetPaletteIndex, @function
I_GetPaletteIndex:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	move	$17,$4
	lui	$4,%hi($LC6)
	sw	$18,24($sp)
	addiu	$4,$4,%lo($LC6)
	move	$18,$5
	sw	$16,16($sp)
	sw	$31,28($sp)
	jal	printf
	move	$16,$6

	mult	$18,$18
	li	$2,2147418112			# 0x7fff0000
	madd	$17,$17
	ori	$2,$2,0xffff
	madd	$16,$16
	mflo	$6
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L50
	.set	at
	nop

	beq	$6,$0,$L59
	lw	$31,28($sp)

$L50:
	li	$2,1			# 0x1
	b	$L54
	li	$3,256			# 0x100

$L58:
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L59
	.set	at
	lw	$31,28($sp)

$L54:
	bne	$6,$0,$L58
	addiu	$2,$2,1

	lw	$31,28($sp)
$L59:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	I_GetPaletteIndex
	.size	I_GetPaletteIndex, .-I_GetPaletteIndex
	.align	2
	.globl	I_BeginRead
	.set	nomips16
	.set	nomicromips
	.ent	I_BeginRead
	.type	I_BeginRead, @function
I_BeginRead:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_BeginRead
	.size	I_BeginRead, .-I_BeginRead
	.align	2
	.globl	I_EndRead
	.set	nomips16
	.set	nomicromips
	.ent	I_EndRead
	.type	I_EndRead, @function
I_EndRead:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_EndRead
	.size	I_EndRead, .-I_EndRead
	.align	2
	.globl	I_SetWindowTitle
	.set	nomips16
	.set	nomicromips
	.ent	I_SetWindowTitle
	.type	I_SetWindowTitle, @function
I_SetWindowTitle:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	DG_SetWindowTitle
	nop

	.set	macro
	.set	reorder
	.end	I_SetWindowTitle
	.size	I_SetWindowTitle, .-I_SetWindowTitle
	.align	2
	.globl	I_GraphicsCheckCommandLine
	.set	nomips16
	.set	nomicromips
	.ent	I_GraphicsCheckCommandLine
	.type	I_GraphicsCheckCommandLine, @function
I_GraphicsCheckCommandLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_GraphicsCheckCommandLine
	.size	I_GraphicsCheckCommandLine, .-I_GraphicsCheckCommandLine
	.align	2
	.globl	I_SetGrabMouseCallback
	.set	nomips16
	.set	nomicromips
	.ent	I_SetGrabMouseCallback
	.type	I_SetGrabMouseCallback, @function
I_SetGrabMouseCallback:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_SetGrabMouseCallback
	.size	I_SetGrabMouseCallback, .-I_SetGrabMouseCallback
	.align	2
	.globl	I_EnableLoadingDisk
	.set	nomips16
	.set	nomicromips
	.ent	I_EnableLoadingDisk
	.type	I_EnableLoadingDisk, @function
I_EnableLoadingDisk:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_EnableLoadingDisk
	.size	I_EnableLoadingDisk, .-I_EnableLoadingDisk
	.align	2
	.globl	I_BindVideoVariables
	.set	nomips16
	.set	nomicromips
	.ent	I_BindVideoVariables
	.type	I_BindVideoVariables, @function
I_BindVideoVariables:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_BindVideoVariables
	.size	I_BindVideoVariables, .-I_BindVideoVariables
	.align	2
	.globl	I_DisplayFPSDots
	.set	nomips16
	.set	nomicromips
	.ent	I_DisplayFPSDots
	.type	I_DisplayFPSDots, @function
I_DisplayFPSDots:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_DisplayFPSDots
	.size	I_DisplayFPSDots, .-I_DisplayFPSDots
	.align	2
	.globl	I_CheckIsScreensaver
	.set	nomips16
	.set	nomicromips
	.ent	I_CheckIsScreensaver
	.type	I_CheckIsScreensaver, @function
I_CheckIsScreensaver:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	I_CheckIsScreensaver
	.size	I_CheckIsScreensaver, .-I_CheckIsScreensaver
	.globl	usegamma
	.section	.bss,"aw",@nobits
	.align	2
	.type	usegamma, @object
	.size	usegamma, 4
usegamma:
	.space	4
	.globl	mouse_threshold
	.data
	.align	2
	.type	mouse_threshold, @object
	.size	mouse_threshold, 4
mouse_threshold:
	.word	10
	.globl	mouse_acceleration
	.align	2
	.type	mouse_acceleration, @object
	.size	mouse_acceleration, 4
mouse_acceleration:
	.word	1073741824
	.globl	screenvisible
	.section	.bss
	.align	2
	.type	screenvisible, @object
	.size	screenvisible, 4
screenvisible:
	.space	4
	.globl	screensaver_mode
	.align	2
	.type	screensaver_mode, @object
	.size	screensaver_mode, 4
screensaver_mode:
	.space	4
	.globl	I_VideoBuffer
	.align	2
	.type	I_VideoBuffer, @object
	.size	I_VideoBuffer, 4
I_VideoBuffer:
	.space	4
	.local	colors
	.comm	colors,1024,4
	.globl	usemouse
	.align	2
	.type	usemouse, @object
	.size	usemouse, 4
usemouse:
	.space	4
	.globl	fb_scaling
	.data
	.align	2
	.type	fb_scaling, @object
	.size	fb_scaling, 4
fb_scaling:
	.word	1
	.local	s_Fb
	.comm	s_Fb,52,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
