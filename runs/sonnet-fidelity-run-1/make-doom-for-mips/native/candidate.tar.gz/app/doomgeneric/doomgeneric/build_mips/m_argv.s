	.file	1 "m_argv.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	M_CheckParmWithArgs
	.set	nomips16
	.set	nomicromips
	.ent	M_CheckParmWithArgs
	.type	M_CheckParmWithArgs, @function
M_CheckParmWithArgs:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$19,28($sp)
	lui	$19,%hi(myargc)
	lw	$2,%lo(myargc)($19)
	sw	$31,36($sp)
	subu	$2,$2,$5
	slt	$2,$2,2
	sw	$20,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	bne	$2,$0,$L2
	sw	$16,16($sp)

	move	$17,$5
	move	$18,$4
	li	$16,1			# 0x1
	b	$L4
	lui	$20,%hi(myargv)

$L11:
	addiu	$16,$16,1
	subu	$2,$2,$17
	slt	$2,$16,$2
	beq	$2,$0,$L12
	lw	$31,36($sp)

$L4:
	lw	$2,%lo(myargv)($20)
	sll	$3,$16,2
	addu	$2,$2,$3
	lw	$5,0($2)
	jal	strcasecmp
	move	$4,$18

	bne	$2,$0,$L11
	lw	$2,%lo(myargc)($19)

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L2:
	lw	$31,36($sp)
$L12:
	move	$16,$0
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_CheckParmWithArgs
	.size	M_CheckParmWithArgs, .-M_CheckParmWithArgs
	.align	2
	.globl	M_ParmExists
	.set	nomips16
	.set	nomicromips
	.ent	M_ParmExists
	.type	M_ParmExists, @function
M_ParmExists:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$18,28($sp)
	lui	$18,%hi(myargc)
	lw	$2,%lo(myargc)($18)
	sw	$31,36($sp)
	slt	$2,$2,2
	sw	$19,32($sp)
	sw	$17,24($sp)
	bne	$2,$0,$L16
	sw	$16,20($sp)

	move	$17,$4
	li	$16,1			# 0x1
	b	$L14
	lui	$19,%hi(myargv)

$L21:
	slt	$2,$16,$2
	beq	$2,$0,$L22
	lw	$31,36($sp)

$L14:
	lw	$2,%lo(myargv)($19)
	sll	$3,$16,2
	addu	$2,$2,$3
	lw	$5,0($2)
	move	$4,$17
	jal	strcasecmp
	addiu	$16,$16,1

	bne	$2,$0,$L21
	lw	$2,%lo(myargc)($18)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,40

$L16:
	lw	$31,36($sp)
$L22:
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_ParmExists
	.size	M_ParmExists, .-M_ParmExists
	.align	2
	.globl	M_CheckParm
	.set	nomips16
	.set	nomicromips
	.ent	M_CheckParm
	.type	M_CheckParm, @function
M_CheckParm:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$18,28($sp)
	lui	$18,%hi(myargc)
	lw	$2,%lo(myargc)($18)
	sw	$31,36($sp)
	slt	$2,$2,2
	sw	$19,32($sp)
	sw	$17,24($sp)
	bne	$2,$0,$L24
	sw	$16,20($sp)

	move	$17,$4
	li	$16,1			# 0x1
	b	$L26
	lui	$19,%hi(myargv)

$L32:
	addiu	$16,$16,1
	slt	$2,$16,$2
	beq	$2,$0,$L33
	lw	$31,36($sp)

$L26:
	lw	$2,%lo(myargv)($19)
	sll	$3,$16,2
	addu	$2,$2,$3
	lw	$5,0($2)
	jal	strcasecmp
	move	$4,$17

	bne	$2,$0,$L32
	lw	$2,%lo(myargc)($18)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	move	$2,$16
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L24:
	lw	$31,36($sp)
$L33:
	move	$16,$0
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	move	$2,$16
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_CheckParm
	.size	M_CheckParm, .-M_CheckParm
	.align	2
	.globl	M_FindResponseFile
	.set	nomips16
	.set	nomicromips
	.ent	M_FindResponseFile
	.type	M_FindResponseFile, @function
M_FindResponseFile:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_FindResponseFile
	.size	M_FindResponseFile, .-M_FindResponseFile
	.align	2
	.globl	M_GetExecutableName
	.set	nomips16
	.set	nomicromips
	.ent	M_GetExecutableName
	.type	M_GetExecutableName, @function
M_GetExecutableName:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(myargv)
	lw	$2,%lo(myargv)($16)
	lw	$4,0($2)
	sw	$31,20($sp)
	jal	strrchr
	li	$5,47			# 0x2f

	beq	$2,$0,$L39
	lw	$31,20($sp)

	lw	$16,16($sp)
	addiu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,24

$L39:
	lw	$2,%lo(myargv)($16)
	lw	$2,0($2)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_GetExecutableName
	.size	M_GetExecutableName, .-M_GetExecutableName
	.globl	myargv
	.section	.bss,"aw",@nobits
	.align	2
	.type	myargv, @object
	.size	myargv, 4
myargv:
	.space	4
	.globl	myargc
	.align	2
	.type	myargc, @object
	.size	myargc, 4
myargc:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
