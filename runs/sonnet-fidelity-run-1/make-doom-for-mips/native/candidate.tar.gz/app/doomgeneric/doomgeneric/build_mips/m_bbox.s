	.file	1 "m_bbox.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	M_ClearBox
	.set	nomips16
	.set	nomicromips
	.ent	M_ClearBox
	.type	M_ClearBox, @function
M_ClearBox:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,2147418112			# 0x7fff0000
	li	$3,-2147483648			# 0xffffffff80000000
	ori	$2,$2,0xffff
	sw	$3,12($4)
	sw	$3,0($4)
	sw	$2,8($4)
	jr	$31
	sw	$2,4($4)

	.set	macro
	.set	reorder
	.end	M_ClearBox
	.size	M_ClearBox, .-M_ClearBox
	.align	2
	.globl	M_AddToBox
	.set	nomips16
	.set	nomicromips
	.ent	M_AddToBox
	.type	M_AddToBox, @function
M_AddToBox:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,8($4)
	slt	$2,$5,$2
	beq	$2,$0,$L4
	nop

	sw	$5,8($4)
$L5:
	lw	$2,4($4)
	slt	$2,$6,$2
	beq	$2,$0,$L6
	nop

$L8:
	jr	$31
	sw	$6,4($4)

$L4:
	lw	$2,12($4)
	slt	$2,$2,$5
	beq	$2,$0,$L5
	nop

	lw	$2,4($4)
	slt	$2,$6,$2
	bne	$2,$0,$L8
	sw	$5,12($4)

$L6:
	lw	$2,0($4)
	slt	$2,$2,$6
	beq	$2,$0,$L9
	nop

	sw	$6,0($4)
$L9:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_AddToBox
	.size	M_AddToBox, .-M_AddToBox
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
