	.file	1 "m_cheat.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	cht_CheckCheat
	.set	nomips16
	.set	nomicromips
	.ent	cht_CheckCheat
	.type	cht_CheckCheat, @function
cht_CheckCheat:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,32($4)
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	sw	$17,20($sp)
	move	$16,$4
	blez	$2,$L5
	move	$18,$5

	jal	strlen
	nop

	lw	$3,28($16)
	sltu	$2,$2,$3
	bne	$2,$0,$L19
	lw	$31,28($sp)

$L5:
	lw	$17,36($16)
	jal	strlen
	move	$4,$16

	sltu	$17,$17,$2
	beq	$17,$0,$L16
	nop

	lw	$17,36($16)
	addu	$2,$16,$17
	lb	$2,0($2)
	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L7
	.set	at
	addiu	$17,$17,1

	move	$17,$0
$L7:
	sw	$17,36($16)
	sw	$0,40($16)
$L8:
	jal	strlen
	move	$4,$16

	sltu	$2,$17,$2
	bne	$2,$0,$L19
	lw	$31,28($sp)

	lw	$2,40($16)
	lw	$3,32($16)
	slt	$2,$2,$3
	beq	$2,$0,$L18
	lw	$18,24($sp)

$L19:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L16:
	lw	$3,40($16)
	lw	$2,32($16)
	slt	$2,$3,$2
	beq	$2,$0,$L8
	lw	$17,36($16)

	addu	$2,$16,$3
	addiu	$3,$3,1
	sb	$18,44($2)
	b	$L8
	sw	$3,40($16)

$L18:
	lw	$17,20($sp)
	sw	$0,40($16)
	sw	$0,36($16)
	li	$2,1			# 0x1
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	cht_CheckCheat
	.size	cht_CheckCheat, .-cht_CheckCheat
	.align	2
	.globl	cht_GetParam
	.set	nomips16
	.set	nomicromips
	.ent	cht_GetParam
	.type	cht_GetParam, @function
cht_GetParam:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$2,$4
	lw	$6,32($2)
	move	$4,$5
	j	memcpy
	addiu	$5,$2,44

	.set	macro
	.set	reorder
	.end	cht_GetParam
	.size	cht_GetParam, .-cht_GetParam
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
