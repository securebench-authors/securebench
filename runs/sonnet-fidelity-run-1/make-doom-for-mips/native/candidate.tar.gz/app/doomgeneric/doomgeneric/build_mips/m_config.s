	.file	1 "m_config.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Unknown configuration variable: '%s'\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	GetDefaultForName
	.type	GetDefaultForName, @function
GetDefaultForName:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$19,28($sp)
	lui	$19,%hi(doom_defaults)
	sw	$20,32($sp)
	addiu	$20,$19,%lo(doom_defaults)
	lw	$2,4($20)
	sw	$18,24($sp)
	sw	$31,36($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	blez	$2,$L2
	move	$18,$4

	move	$16,$0
	b	$L5
	move	$17,$0

$L3:
	lw	$3,4($20)
	slt	$3,$17,$3
	beq	$3,$0,$L2
	addiu	$16,$16,24

$L5:
	lw	$3,%lo(doom_defaults)($19)
	move	$4,$18
	addu	$3,$3,$16
	lw	$5,0($3)
	jal	strcmp
	addiu	$17,$17,1

	bne	$2,$0,$L3
	lw	$2,%lo(doom_defaults)($19)

	addu	$2,$2,$16
	beq	$2,$0,$L19
	lui	$19,%hi(extra_defaults)

$L1:
	lw	$31,36($sp)
$L20:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L2:
	lui	$19,%hi(extra_defaults)
$L19:
	addiu	$20,$19,%lo(extra_defaults)
	lw	$2,4($20)
	blez	$2,$L6
	move	$16,$0

	b	$L8
	move	$17,$0

$L7:
	lw	$2,4($20)
	slt	$2,$17,$2
	beq	$2,$0,$L6
	addiu	$16,$16,24

$L8:
	lw	$2,%lo(extra_defaults)($19)
	move	$4,$18
	addu	$2,$2,$16
	lw	$5,0($2)
	jal	strcmp
	addiu	$17,$17,1

	bne	$2,$0,$L7
	lw	$2,%lo(extra_defaults)($19)

	addu	$2,$2,$16
	bne	$2,$0,$L20
	lw	$31,36($sp)

$L6:
	lui	$4,%hi($LC0)
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	b	$L1
	move	$2,$0

	.set	macro
	.set	reorder
	.end	GetDefaultForName
	.size	GetDefaultForName, .-GetDefaultForName
	.align	2
	.globl	M_SetConfigFilenames
	.set	nomips16
	.set	nomicromips
	.ent	M_SetConfigFilenames
	.type	M_SetConfigFilenames, @function
M_SetConfigFilenames:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(default_main_config)
	sw	$4,%lo(default_main_config)($2)
	lui	$2,%hi(default_extra_config)
	jr	$31
	sw	$5,%lo(default_extra_config)($2)

	.set	macro
	.set	reorder
	.end	M_SetConfigFilenames
	.size	M_SetConfigFilenames, .-M_SetConfigFilenames
	.align	2
	.globl	M_SaveDefaults
	.set	nomips16
	.set	nomicromips
	.ent	M_SaveDefaults
	.type	M_SaveDefaults, @function
M_SaveDefaults:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_SaveDefaults
	.size	M_SaveDefaults, .-M_SaveDefaults
	.align	2
	.globl	M_SaveDefaultsAlternate
	.set	nomips16
	.set	nomicromips
	.ent	M_SaveDefaultsAlternate
	.type	M_SaveDefaultsAlternate, @function
M_SaveDefaultsAlternate:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_SaveDefaultsAlternate
	.size	M_SaveDefaultsAlternate, .-M_SaveDefaultsAlternate
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"-config\000"
	.align	2
$LC2:
	.ascii	"\011default file: %s\012\000"
	.align	2
$LC3:
	.ascii	"saving config in %s\012\000"
	.align	2
$LC4:
	.ascii	"-extraconfig\000"
	.align	2
$LC5:
	.ascii	"        extra configuration file: %s\012\000"
	.text
	.align	2
	.globl	M_LoadDefaults
	.set	nomips16
	.set	nomicromips
	.ent	M_LoadDefaults
	.type	M_LoadDefaults, @function
M_LoadDefaults:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC1)
	addiu	$sp,$sp,-24
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC1)
	sw	$31,20($sp)
	jal	M_CheckParmWithArgs
	sw	$16,16($sp)

	beq	$2,$0,$L25
	lui	$3,%hi(myargv)

	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$5,0($2)
	lui	$16,%hi(doom_defaults)
	lui	$4,%hi($LC2)
	addiu	$16,$16,%lo(doom_defaults)
	addiu	$4,$4,%lo($LC2)
	jal	printf
	sw	$5,8($16)

	lw	$5,8($16)
	lui	$4,%hi($LC3)
	jal	printf
	addiu	$4,$4,%lo($LC3)

	lui	$4,%hi($LC4)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC4)

	beq	$2,$0,$L27
	lui	$3,%hi(myargv)

$L30:
	lw	$3,%lo(myargv)($3)
	addiu	$2,$2,1
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$5,0($2)
	lw	$31,20($sp)
	lw	$16,16($sp)
	lui	$4,%hi($LC5)
	lui	$2,%hi(extra_defaults+8)
	addiu	$4,$4,%lo($LC5)
	addiu	$sp,$sp,24
	j	printf
	sw	$5,%lo(extra_defaults+8)($2)

$L25:
	lui	$2,%hi(default_main_config)
	lw	$5,%lo(default_main_config)($2)
	lui	$2,%hi(configdir)
	lw	$4,%lo(configdir)($2)
	jal	M_StringJoin
	move	$6,$0

	lui	$4,%hi($LC3)
	move	$5,$2
	addiu	$4,$4,%lo($LC3)
	lui	$2,%hi(doom_defaults+8)
	jal	printf
	sw	$5,%lo(doom_defaults+8)($2)

	lui	$4,%hi($LC4)
	li	$5,1			# 0x1
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC4)

	bne	$2,$0,$L30
	lui	$3,%hi(myargv)

$L27:
	lui	$2,%hi(default_extra_config)
	lw	$5,%lo(default_extra_config)($2)
	lui	$2,%hi(configdir)
	lw	$4,%lo(configdir)($2)
	jal	M_StringJoin
	move	$6,$0

	lw	$31,20($sp)
	lui	$3,%hi(extra_defaults+8)
	lw	$16,16($sp)
	sw	$2,%lo(extra_defaults+8)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_LoadDefaults
	.size	M_LoadDefaults, .-M_LoadDefaults
	.align	2
	.globl	M_BindVariable
	.set	nomips16
	.set	nomicromips
	.ent	M_BindVariable
	.type	M_BindVariable, @function
M_BindVariable:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	GetDefaultForName
	move	$16,$5

	lw	$31,20($sp)
	li	$3,1			# 0x1
	sw	$16,4($2)
	sw	$3,20($2)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindVariable
	.size	M_BindVariable, .-M_BindVariable
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"%x\000"
	.align	2
$LC7:
	.ascii	"%i\000"
	.globl	__truncdfsf2
	.text
	.align	2
	.globl	M_SetVariable
	.set	nomips16
	.set	nomicromips
	.ent	M_SetVariable
	.type	M_SetVariable, @function
M_SetVariable:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,32($sp)
	sw	$31,36($sp)
	sw	$16,28($sp)
	jal	GetDefaultForName
	move	$17,$5

	beq	$2,$0,$L46
	move	$16,$2

	lw	$2,20($2)
	bne	$2,$0,$L53
	li	$3,3			# 0x3

$L33:
	lw	$31,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L53:
	lw	$2,8($16)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L35
	.set	at
	sltu	$3,$2,4

	beq	$3,$0,$L36
	li	$3,2			# 0x2

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L54
	.set	at
	nop

	lw	$16,4($16)
	jal	strdup
	move	$4,$17

	sw	$2,0($16)
	b	$L33
	li	$2,1			# 0x1

$L36:
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L33
	.set	at
	li	$2,1			# 0x1

	lb	$3,0($17)
	li	$2,48			# 0x30
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L43
	.set	at
	addiu	$6,$sp,16

	lb	$3,1($17)
	li	$2,120			# 0x78
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L57
	.set	at
	lui	$5,%hi($LC7)

	lui	$5,%hi($LC6)
	addiu	$5,$5,%lo($LC6)
	jal	sscanf
	addiu	$4,$17,2

	b	$L44
	lw	$2,16($sp)

$L54:
	lb	$3,0($17)
	li	$2,48			# 0x30
	lw	$16,4($16)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L41
	.set	at
	addiu	$6,$sp,16

	lb	$3,1($17)
	li	$2,120			# 0x78
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L58
	.set	at
	lui	$5,%hi($LC7)

	lui	$5,%hi($LC6)
	addiu	$5,$5,%lo($LC6)
	jal	sscanf
	addiu	$4,$17,2

	lw	$2,16($sp)
	sw	$2,0($16)
$L55:
	b	$L33
	li	$2,1			# 0x1

$L41:
	lui	$5,%hi($LC7)
$L58:
	addiu	$5,$5,%lo($LC7)
	jal	sscanf
	move	$4,$17

	lw	$2,16($sp)
	b	$L55
	sw	$2,0($16)

$L43:
	lui	$5,%hi($LC7)
$L57:
	addiu	$5,$5,%lo($LC7)
	jal	sscanf
	move	$4,$17

	lw	$2,16($sp)
$L44:
	sltu	$3,$2,128
	bne	$3,$0,$L56
	sw	$2,12($16)

	move	$2,$0
$L45:
	lw	$3,4($16)
	sw	$2,16($16)
	sw	$2,0($3)
	b	$L33
	li	$2,1			# 0x1

$L46:
	lw	$31,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

$L35:
	jal	atof
	move	$4,$17

	move	$4,$2
	lw	$16,4($16)
	jal	__truncdfsf2
	move	$5,$3

	sw	$2,0($16)
	b	$L33
	li	$2,1			# 0x1

$L56:
	lui	$3,%hi(scantokey)
	sll	$2,$2,2
	addiu	$3,$3,%lo(scantokey)
	addu	$2,$2,$3
	b	$L45
	lw	$2,0($2)

	.set	macro
	.set	reorder
	.end	M_SetVariable
	.size	M_SetVariable, .-M_SetVariable
	.align	2
	.globl	M_GetIntVariable
	.set	nomips16
	.set	nomicromips
	.ent	M_GetIntVariable
	.type	M_GetIntVariable, @function
M_GetIntVariable:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	GetDefaultForName
	nop

	beq	$2,$0,$L65
	lw	$31,20($sp)

	lw	$3,20($2)
	beq	$3,$0,$L65
	nop

	lw	$3,8($2)
	sltu	$3,$3,2
	beq	$3,$0,$L63
	nop

	lw	$2,4($2)
	lw	$2,0($2)
	jr	$31
	addiu	$sp,$sp,24

$L63:
$L65:
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_GetIntVariable
	.size	M_GetIntVariable, .-M_GetIntVariable
	.align	2
	.globl	M_GetStrVariable
	.set	nomips16
	.set	nomicromips
	.ent	M_GetStrVariable
	.type	M_GetStrVariable, @function
M_GetStrVariable:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	GetDefaultForName
	nop

	beq	$2,$0,$L74
	lw	$31,20($sp)

	lw	$3,20($2)
	beq	$3,$0,$L75
	li	$3,2			# 0x2

	lw	$4,8($2)
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L75
	.set	at
	nop

	lw	$2,4($2)
	lw	$2,0($2)
$L74:
	jr	$31
	addiu	$sp,$sp,24

$L75:
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_GetStrVariable
	.size	M_GetStrVariable, .-M_GetStrVariable
	.align	2
	.globl	M_GetFloatVariable
	.set	nomips16
	.set	nomicromips
	.ent	M_GetFloatVariable
	.type	M_GetFloatVariable, @function
M_GetFloatVariable:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	GetDefaultForName
	nop

	beq	$2,$0,$L83
	lw	$31,20($sp)

	lw	$3,20($2)
	beq	$3,$0,$L83
	li	$3,3			# 0x3

	lw	$4,8($2)
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L82
	.set	at
	nop

$L83:
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

$L82:
	lw	$2,4($2)
	lw	$2,0($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_GetFloatVariable
	.size	M_GetFloatVariable, .-M_GetFloatVariable
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"\000"
	.align	2
$LC9:
	.ascii	"Using %s for configuration and saves\012\000"
	.text
	.align	2
	.globl	M_SetConfigDir
	.set	nomips16
	.set	nomicromips
	.ent	M_SetConfigDir
	.type	M_SetConfigDir, @function
M_SetConfigDir:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	beq	$4,$0,$L91
	sw	$16,16($sp)

$L85:
	lui	$5,%hi($LC8)
	lui	$16,%hi(configdir)
	addiu	$5,$5,%lo($LC8)
	jal	strcmp
	sw	$4,%lo(configdir)($16)

	bne	$2,$0,$L92
	lw	$31,20($sp)

	lw	$4,%lo(configdir)($16)
	lw	$16,16($sp)
	j	M_MakeDirectory
	addiu	$sp,$sp,24

$L92:
	lw	$5,%lo(configdir)($16)
	lui	$4,%hi($LC9)
	jal	printf
	addiu	$4,$4,%lo($LC9)

	lw	$31,20($sp)
	lw	$4,%lo(configdir)($16)
	lw	$16,16($sp)
	j	M_MakeDirectory
	addiu	$sp,$sp,24

$L91:
	jal	malloc
	li	$4,2			# 0x2

	move	$4,$2
	li	$2,46			# 0x2e
	sb	$2,0($4)
	b	$L85
	sb	$0,1($4)

	.set	macro
	.set	reorder
	.end	M_SetConfigDir
	.size	M_SetConfigDir, .-M_SetConfigDir
	.section	.rodata.str1.4
	.align	2
$LC10:
	.ascii	".savegame/\000"
	.align	2
$LC11:
	.ascii	"/\000"
	.align	2
$LC12:
	.ascii	"Using %s for savegames\012\000"
	.text
	.align	2
	.globl	M_GetSaveGameDir
	.set	nomips16
	.set	nomicromips
	.ent	M_GetSaveGameDir
	.type	M_GetSaveGameDir, @function
M_GetSaveGameDir:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	lui	$16,%hi(configdir)
	sw	$17,24($sp)
	lw	$4,%lo(configdir)($16)
	lui	$17,%hi($LC8)
	sw	$31,28($sp)
	jal	strcmp
	addiu	$5,$17,%lo($LC8)

	bne	$2,$0,$L94
	lui	$6,%hi($LC10)

	lw	$31,28($sp)
	lw	$16,20($sp)
	addiu	$4,$17,%lo($LC8)
	lw	$17,24($sp)
	j	strdup
	addiu	$sp,$sp,32

$L94:
	lw	$4,%lo(configdir)($16)
	lui	$5,%hi($LC11)
	move	$7,$0
	addiu	$6,$6,%lo($LC10)
	jal	M_StringJoin
	addiu	$5,$5,%lo($LC11)

	move	$4,$2
	jal	M_MakeDirectory
	move	$16,$2

	lui	$4,%hi($LC12)
	move	$5,$16
	jal	printf
	addiu	$4,$4,%lo($LC12)

	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$2,$16
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_GetSaveGameDir
	.size	M_GetSaveGameDir, .-M_GetSaveGameDir
	.rdata
	.align	2
	.type	scantokey, @object
	.size	scantokey, 512
scantokey:
	.word	0
	.word	27
	.word	49
	.word	50
	.word	51
	.word	52
	.word	53
	.word	54
	.word	55
	.word	56
	.word	57
	.word	48
	.word	45
	.word	61
	.word	127
	.word	9
	.word	113
	.word	119
	.word	101
	.word	114
	.word	116
	.word	121
	.word	117
	.word	105
	.word	111
	.word	112
	.word	91
	.word	93
	.word	13
	.word	157
	.word	97
	.word	115
	.word	100
	.word	102
	.word	103
	.word	104
	.word	106
	.word	107
	.word	108
	.word	59
	.word	39
	.word	96
	.word	182
	.word	92
	.word	122
	.word	120
	.word	99
	.word	118
	.word	98
	.word	110
	.word	109
	.word	44
	.word	46
	.word	47
	.word	182
	.word	42
	.word	184
	.word	32
	.word	186
	.word	187
	.word	188
	.word	189
	.word	190
	.word	191
	.word	192
	.word	193
	.word	194
	.word	195
	.word	196
	.word	255
	.word	198
	.word	199
	.word	173
	.word	201
	.word	45
	.word	172
	.word	53
	.word	174
	.word	43
	.word	207
	.word	175
	.word	209
	.word	210
	.word	211
	.word	0
	.word	0
	.word	0
	.word	215
	.word	216
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	217
	.word	0
	.data
	.align	2
	.type	extra_defaults, @object
	.size	extra_defaults, 12
extra_defaults:
	.word	extra_defaults_list
	.word	119
	.word	0
	.section	.rodata.str1.4
	.align	2
$LC13:
	.ascii	"graphical_startup\000"
	.align	2
$LC14:
	.ascii	"autoadjust_video_settings\000"
	.align	2
$LC15:
	.ascii	"fullscreen\000"
	.align	2
$LC16:
	.ascii	"aspect_ratio_correct\000"
	.align	2
$LC17:
	.ascii	"startup_delay\000"
	.align	2
$LC18:
	.ascii	"screen_width\000"
	.align	2
$LC19:
	.ascii	"screen_height\000"
	.align	2
$LC20:
	.ascii	"screen_bpp\000"
	.align	2
$LC21:
	.ascii	"grabmouse\000"
	.align	2
$LC22:
	.ascii	"novert\000"
	.align	2
$LC23:
	.ascii	"mouse_acceleration\000"
	.align	2
$LC24:
	.ascii	"mouse_threshold\000"
	.align	2
$LC25:
	.ascii	"snd_samplerate\000"
	.align	2
$LC26:
	.ascii	"snd_cachesize\000"
	.align	2
$LC27:
	.ascii	"snd_maxslicetime_ms\000"
	.align	2
$LC28:
	.ascii	"snd_musiccmd\000"
	.align	2
$LC29:
	.ascii	"opl_io_port\000"
	.align	2
$LC30:
	.ascii	"show_endoom\000"
	.align	2
$LC31:
	.ascii	"png_screenshots\000"
	.align	2
$LC32:
	.ascii	"vanilla_savegame_limit\000"
	.align	2
$LC33:
	.ascii	"vanilla_demo_limit\000"
	.align	2
$LC34:
	.ascii	"vanilla_keyboard_mapping\000"
	.align	2
$LC35:
	.ascii	"video_driver\000"
	.align	2
$LC36:
	.ascii	"window_position\000"
	.align	2
$LC37:
	.ascii	"joystick_index\000"
	.align	2
$LC38:
	.ascii	"joystick_x_axis\000"
	.align	2
$LC39:
	.ascii	"joystick_x_invert\000"
	.align	2
$LC40:
	.ascii	"joystick_y_axis\000"
	.align	2
$LC41:
	.ascii	"joystick_y_invert\000"
	.align	2
$LC42:
	.ascii	"joystick_strafe_axis\000"
	.align	2
$LC43:
	.ascii	"joystick_strafe_invert\000"
	.align	2
$LC44:
	.ascii	"joystick_physical_button0\000"
	.align	2
$LC45:
	.ascii	"joystick_physical_button1\000"
	.align	2
$LC46:
	.ascii	"joystick_physical_button2\000"
	.align	2
$LC47:
	.ascii	"joystick_physical_button3\000"
	.align	2
$LC48:
	.ascii	"joystick_physical_button4\000"
	.align	2
$LC49:
	.ascii	"joystick_physical_button5\000"
	.align	2
$LC50:
	.ascii	"joystick_physical_button6\000"
	.align	2
$LC51:
	.ascii	"joystick_physical_button7\000"
	.align	2
$LC52:
	.ascii	"joystick_physical_button8\000"
	.align	2
$LC53:
	.ascii	"joystick_physical_button9\000"
	.align	2
$LC54:
	.ascii	"joyb_strafeleft\000"
	.align	2
$LC55:
	.ascii	"joyb_straferight\000"
	.align	2
$LC56:
	.ascii	"joyb_menu_activate\000"
	.align	2
$LC57:
	.ascii	"joyb_prevweapon\000"
	.align	2
$LC58:
	.ascii	"joyb_nextweapon\000"
	.align	2
$LC59:
	.ascii	"mouseb_strafeleft\000"
	.align	2
$LC60:
	.ascii	"mouseb_straferight\000"
	.align	2
$LC61:
	.ascii	"mouseb_use\000"
	.align	2
$LC62:
	.ascii	"mouseb_backward\000"
	.align	2
$LC63:
	.ascii	"mouseb_prevweapon\000"
	.align	2
$LC64:
	.ascii	"mouseb_nextweapon\000"
	.align	2
$LC65:
	.ascii	"dclick_use\000"
	.align	2
$LC66:
	.ascii	"key_pause\000"
	.align	2
$LC67:
	.ascii	"key_menu_activate\000"
	.align	2
$LC68:
	.ascii	"key_menu_up\000"
	.align	2
$LC69:
	.ascii	"key_menu_down\000"
	.align	2
$LC70:
	.ascii	"key_menu_left\000"
	.align	2
$LC71:
	.ascii	"key_menu_right\000"
	.align	2
$LC72:
	.ascii	"key_menu_back\000"
	.align	2
$LC73:
	.ascii	"key_menu_forward\000"
	.align	2
$LC74:
	.ascii	"key_menu_confirm\000"
	.align	2
$LC75:
	.ascii	"key_menu_abort\000"
	.align	2
$LC76:
	.ascii	"key_menu_help\000"
	.align	2
$LC77:
	.ascii	"key_menu_save\000"
	.align	2
$LC78:
	.ascii	"key_menu_load\000"
	.align	2
$LC79:
	.ascii	"key_menu_volume\000"
	.align	2
$LC80:
	.ascii	"key_menu_detail\000"
	.align	2
$LC81:
	.ascii	"key_menu_qsave\000"
	.align	2
$LC82:
	.ascii	"key_menu_endgame\000"
	.align	2
$LC83:
	.ascii	"key_menu_messages\000"
	.align	2
$LC84:
	.ascii	"key_menu_qload\000"
	.align	2
$LC85:
	.ascii	"key_menu_quit\000"
	.align	2
$LC86:
	.ascii	"key_menu_gamma\000"
	.align	2
$LC87:
	.ascii	"key_spy\000"
	.align	2
$LC88:
	.ascii	"key_menu_incscreen\000"
	.align	2
$LC89:
	.ascii	"key_menu_decscreen\000"
	.align	2
$LC90:
	.ascii	"key_menu_screenshot\000"
	.align	2
$LC91:
	.ascii	"key_map_toggle\000"
	.align	2
$LC92:
	.ascii	"key_map_north\000"
	.align	2
$LC93:
	.ascii	"key_map_south\000"
	.align	2
$LC94:
	.ascii	"key_map_east\000"
	.align	2
$LC95:
	.ascii	"key_map_west\000"
	.align	2
$LC96:
	.ascii	"key_map_zoomin\000"
	.align	2
$LC97:
	.ascii	"key_map_zoomout\000"
	.align	2
$LC98:
	.ascii	"key_map_maxzoom\000"
	.align	2
$LC99:
	.ascii	"key_map_follow\000"
	.align	2
$LC100:
	.ascii	"key_map_grid\000"
	.align	2
$LC101:
	.ascii	"key_map_mark\000"
	.align	2
$LC102:
	.ascii	"key_map_clearmark\000"
	.align	2
$LC103:
	.ascii	"key_weapon1\000"
	.align	2
$LC104:
	.ascii	"key_weapon2\000"
	.align	2
$LC105:
	.ascii	"key_weapon3\000"
	.align	2
$LC106:
	.ascii	"key_weapon4\000"
	.align	2
$LC107:
	.ascii	"key_weapon5\000"
	.align	2
$LC108:
	.ascii	"key_weapon6\000"
	.align	2
$LC109:
	.ascii	"key_weapon7\000"
	.align	2
$LC110:
	.ascii	"key_weapon8\000"
	.align	2
$LC111:
	.ascii	"key_prevweapon\000"
	.align	2
$LC112:
	.ascii	"key_nextweapon\000"
	.align	2
$LC113:
	.ascii	"key_arti_all\000"
	.align	2
$LC114:
	.ascii	"key_arti_health\000"
	.align	2
$LC115:
	.ascii	"key_arti_poisonbag\000"
	.align	2
$LC116:
	.ascii	"key_arti_blastradius\000"
	.align	2
$LC117:
	.ascii	"key_arti_teleport\000"
	.align	2
$LC118:
	.ascii	"key_arti_teleportother\000"
	.align	2
$LC119:
	.ascii	"key_arti_egg\000"
	.align	2
$LC120:
	.ascii	"key_arti_invulnerability\000"
	.align	2
$LC121:
	.ascii	"key_message_refresh\000"
	.align	2
$LC122:
	.ascii	"key_demo_quit\000"
	.align	2
$LC123:
	.ascii	"key_multi_msg\000"
	.align	2
$LC124:
	.ascii	"key_multi_msgplayer1\000"
	.align	2
$LC125:
	.ascii	"key_multi_msgplayer2\000"
	.align	2
$LC126:
	.ascii	"key_multi_msgplayer3\000"
	.align	2
$LC127:
	.ascii	"key_multi_msgplayer4\000"
	.align	2
$LC128:
	.ascii	"key_multi_msgplayer5\000"
	.align	2
$LC129:
	.ascii	"key_multi_msgplayer6\000"
	.align	2
$LC130:
	.ascii	"key_multi_msgplayer7\000"
	.align	2
$LC131:
	.ascii	"key_multi_msgplayer8\000"
	.data
	.align	2
	.type	extra_defaults_list, @object
	.size	extra_defaults_list, 2856
extra_defaults_list:
	.word	$LC13
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC14
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC15
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC16
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC17
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC18
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC19
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC20
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC21
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC22
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC23
	.word	0
	.word	3
	.word	0
	.word	0
	.word	0
	.word	$LC24
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC25
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC26
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC27
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC28
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC29
	.word	0
	.word	1
	.word	0
	.word	0
	.word	0
	.word	$LC30
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC31
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC32
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC33
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC34
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC35
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC36
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC37
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC38
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC39
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC40
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC41
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC42
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC43
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC44
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC45
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC46
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC47
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC48
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC49
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC50
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC51
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC52
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC53
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC54
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC55
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC56
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC57
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC58
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC59
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC60
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC61
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC62
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC63
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC64
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC65
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC66
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC67
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC68
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC69
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC70
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC71
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC72
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC73
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC74
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC75
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC76
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC77
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC78
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC79
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC80
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC81
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC82
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC83
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC84
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC85
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC86
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC87
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC88
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC89
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC90
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC91
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC92
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC93
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC94
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC95
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC96
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC97
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC98
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC99
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC100
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC101
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC102
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC103
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC104
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC105
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC106
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC107
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC108
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC109
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC110
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC111
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC112
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC113
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC114
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC115
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC116
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC117
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC118
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC119
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC120
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC121
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC122
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC123
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC124
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC125
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC126
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC127
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC128
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC129
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC130
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC131
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.align	2
	.type	doom_defaults, @object
	.size	doom_defaults, 12
doom_defaults:
	.word	doom_defaults_list
	.word	76
	.word	0
	.section	.rodata.str1.4
	.align	2
$LC132:
	.ascii	"mouse_sensitivity\000"
	.align	2
$LC133:
	.ascii	"sfx_volume\000"
	.align	2
$LC134:
	.ascii	"music_volume\000"
	.align	2
$LC135:
	.ascii	"show_talk\000"
	.align	2
$LC136:
	.ascii	"voice_volume\000"
	.align	2
$LC137:
	.ascii	"show_messages\000"
	.align	2
$LC138:
	.ascii	"key_right\000"
	.align	2
$LC139:
	.ascii	"key_left\000"
	.align	2
$LC140:
	.ascii	"key_up\000"
	.align	2
$LC141:
	.ascii	"key_down\000"
	.align	2
$LC142:
	.ascii	"key_strafeleft\000"
	.align	2
$LC143:
	.ascii	"key_straferight\000"
	.align	2
$LC144:
	.ascii	"key_useHealth\000"
	.align	2
$LC145:
	.ascii	"key_jump\000"
	.align	2
$LC146:
	.ascii	"key_flyup\000"
	.align	2
$LC147:
	.ascii	"key_flydown\000"
	.align	2
$LC148:
	.ascii	"key_flycenter\000"
	.align	2
$LC149:
	.ascii	"key_lookup\000"
	.align	2
$LC150:
	.ascii	"key_lookdown\000"
	.align	2
$LC151:
	.ascii	"key_lookcenter\000"
	.align	2
$LC152:
	.ascii	"key_invquery\000"
	.align	2
$LC153:
	.ascii	"key_mission\000"
	.align	2
$LC154:
	.ascii	"key_invPop\000"
	.align	2
$LC155:
	.ascii	"key_invKey\000"
	.align	2
$LC156:
	.ascii	"key_invHome\000"
	.align	2
$LC157:
	.ascii	"key_invEnd\000"
	.align	2
$LC158:
	.ascii	"key_invleft\000"
	.align	2
$LC159:
	.ascii	"key_invright\000"
	.align	2
$LC160:
	.ascii	"key_invLeft\000"
	.align	2
$LC161:
	.ascii	"key_invRight\000"
	.align	2
$LC162:
	.ascii	"key_useartifact\000"
	.align	2
$LC163:
	.ascii	"key_invUse\000"
	.align	2
$LC164:
	.ascii	"key_invDrop\000"
	.align	2
$LC165:
	.ascii	"key_lookUp\000"
	.align	2
$LC166:
	.ascii	"key_lookDown\000"
	.align	2
$LC167:
	.ascii	"key_fire\000"
	.align	2
$LC168:
	.ascii	"key_use\000"
	.align	2
$LC169:
	.ascii	"key_strafe\000"
	.align	2
$LC170:
	.ascii	"key_speed\000"
	.align	2
$LC171:
	.ascii	"use_mouse\000"
	.align	2
$LC172:
	.ascii	"mouseb_fire\000"
	.align	2
$LC173:
	.ascii	"mouseb_strafe\000"
	.align	2
$LC174:
	.ascii	"mouseb_forward\000"
	.align	2
$LC175:
	.ascii	"mouseb_jump\000"
	.align	2
$LC176:
	.ascii	"use_joystick\000"
	.align	2
$LC177:
	.ascii	"joyb_fire\000"
	.align	2
$LC178:
	.ascii	"joyb_strafe\000"
	.align	2
$LC179:
	.ascii	"joyb_use\000"
	.align	2
$LC180:
	.ascii	"joyb_speed\000"
	.align	2
$LC181:
	.ascii	"joyb_jump\000"
	.align	2
$LC182:
	.ascii	"screenblocks\000"
	.align	2
$LC183:
	.ascii	"screensize\000"
	.align	2
$LC184:
	.ascii	"detaillevel\000"
	.align	2
$LC185:
	.ascii	"snd_channels\000"
	.align	2
$LC186:
	.ascii	"snd_musicdevice\000"
	.align	2
$LC187:
	.ascii	"snd_sfxdevice\000"
	.align	2
$LC188:
	.ascii	"snd_sbport\000"
	.align	2
$LC189:
	.ascii	"snd_sbirq\000"
	.align	2
$LC190:
	.ascii	"snd_sbdma\000"
	.align	2
$LC191:
	.ascii	"snd_mport\000"
	.align	2
$LC192:
	.ascii	"usegamma\000"
	.align	2
$LC193:
	.ascii	"savedir\000"
	.align	2
$LC194:
	.ascii	"messageson\000"
	.align	2
$LC195:
	.ascii	"back_flat\000"
	.align	2
$LC196:
	.ascii	"nickname\000"
	.align	2
$LC197:
	.ascii	"chatmacro0\000"
	.align	2
$LC198:
	.ascii	"chatmacro1\000"
	.align	2
$LC199:
	.ascii	"chatmacro2\000"
	.align	2
$LC200:
	.ascii	"chatmacro3\000"
	.align	2
$LC201:
	.ascii	"chatmacro4\000"
	.align	2
$LC202:
	.ascii	"chatmacro5\000"
	.align	2
$LC203:
	.ascii	"chatmacro6\000"
	.align	2
$LC204:
	.ascii	"chatmacro7\000"
	.align	2
$LC205:
	.ascii	"chatmacro8\000"
	.align	2
$LC206:
	.ascii	"chatmacro9\000"
	.align	2
$LC207:
	.ascii	"comport\000"
	.data
	.align	2
	.type	doom_defaults_list, @object
	.size	doom_defaults_list, 1824
doom_defaults_list:
	.word	$LC132
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC133
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC134
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC135
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC136
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC137
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC138
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC139
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC140
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC141
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC142
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC143
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC144
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC145
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC146
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC147
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC148
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC149
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC150
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC151
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC152
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC153
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC154
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC155
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC156
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC157
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC158
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC159
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC160
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC161
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC162
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC163
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC164
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC165
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC166
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC167
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC168
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC169
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC170
	.word	0
	.word	4
	.word	0
	.word	0
	.word	0
	.word	$LC171
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC172
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC173
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC174
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC175
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC176
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC177
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC178
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC179
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC180
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC181
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC182
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC183
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC184
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC185
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC186
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC187
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC188
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC189
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC190
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC191
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC192
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC193
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC194
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	$LC195
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC196
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC197
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC198
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC199
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC200
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC201
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC202
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC203
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC204
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC205
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC206
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.word	$LC207
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.local	default_extra_config
	.comm	default_extra_config,4,4
	.local	default_main_config
	.comm	default_main_config,4,4
	.globl	configdir
	.section	.bss,"aw",@nobits
	.align	2
	.type	configdir, @object
	.size	configdir, 4
configdir:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
