	.file	1 "m_controls.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"key_right\000"
	.align	2
$LC1:
	.ascii	"key_left\000"
	.align	2
$LC2:
	.ascii	"key_up\000"
	.align	2
$LC3:
	.ascii	"key_down\000"
	.align	2
$LC4:
	.ascii	"key_strafeleft\000"
	.align	2
$LC5:
	.ascii	"key_straferight\000"
	.align	2
$LC6:
	.ascii	"key_fire\000"
	.align	2
$LC7:
	.ascii	"key_use\000"
	.align	2
$LC8:
	.ascii	"key_strafe\000"
	.align	2
$LC9:
	.ascii	"key_speed\000"
	.align	2
$LC10:
	.ascii	"mouseb_fire\000"
	.align	2
$LC11:
	.ascii	"mouseb_strafe\000"
	.align	2
$LC12:
	.ascii	"mouseb_forward\000"
	.align	2
$LC13:
	.ascii	"joyb_fire\000"
	.align	2
$LC14:
	.ascii	"joyb_strafe\000"
	.align	2
$LC15:
	.ascii	"joyb_use\000"
	.align	2
$LC16:
	.ascii	"joyb_speed\000"
	.align	2
$LC17:
	.ascii	"joyb_menu_activate\000"
	.align	2
$LC18:
	.ascii	"joyb_strafeleft\000"
	.align	2
$LC19:
	.ascii	"joyb_straferight\000"
	.align	2
$LC20:
	.ascii	"mouseb_strafeleft\000"
	.align	2
$LC21:
	.ascii	"mouseb_straferight\000"
	.align	2
$LC22:
	.ascii	"mouseb_use\000"
	.align	2
$LC23:
	.ascii	"mouseb_backward\000"
	.align	2
$LC24:
	.ascii	"dclick_use\000"
	.align	2
$LC25:
	.ascii	"key_pause\000"
	.align	2
$LC26:
	.ascii	"key_message_refresh\000"
	.text
	.align	2
	.globl	M_BindBaseControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindBaseControls
	.type	M_BindBaseControls, @function
M_BindBaseControls:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(key_right)
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(key_right)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC0)

	lui	$5,%hi(key_left)
	lui	$4,%hi($LC1)
	addiu	$5,$5,%lo(key_left)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC1)

	lui	$5,%hi(key_up)
	lui	$4,%hi($LC2)
	addiu	$5,$5,%lo(key_up)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC2)

	lui	$5,%hi(key_down)
	lui	$4,%hi($LC3)
	addiu	$5,$5,%lo(key_down)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC3)

	lui	$5,%hi(key_strafeleft)
	lui	$4,%hi($LC4)
	addiu	$5,$5,%lo(key_strafeleft)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC4)

	lui	$5,%hi(key_straferight)
	lui	$4,%hi($LC5)
	addiu	$5,$5,%lo(key_straferight)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC5)

	lui	$5,%hi(key_fire)
	lui	$4,%hi($LC6)
	addiu	$5,$5,%lo(key_fire)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC6)

	lui	$5,%hi(key_use)
	lui	$4,%hi($LC7)
	addiu	$5,$5,%lo(key_use)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC7)

	lui	$5,%hi(key_strafe)
	lui	$4,%hi($LC8)
	addiu	$5,$5,%lo(key_strafe)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC8)

	lui	$5,%hi(key_speed)
	lui	$4,%hi($LC9)
	addiu	$5,$5,%lo(key_speed)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC9)

	lui	$5,%hi(mousebfire)
	lui	$4,%hi($LC10)
	addiu	$5,$5,%lo(mousebfire)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC10)

	lui	$5,%hi(mousebstrafe)
	lui	$4,%hi($LC11)
	addiu	$5,$5,%lo(mousebstrafe)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC11)

	lui	$5,%hi(mousebforward)
	lui	$4,%hi($LC12)
	addiu	$5,$5,%lo(mousebforward)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC12)

	lui	$5,%hi(joybfire)
	lui	$4,%hi($LC13)
	addiu	$5,$5,%lo(joybfire)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC13)

	lui	$5,%hi(joybstrafe)
	lui	$4,%hi($LC14)
	addiu	$5,$5,%lo(joybstrafe)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC14)

	lui	$5,%hi(joybuse)
	lui	$4,%hi($LC15)
	addiu	$5,$5,%lo(joybuse)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC15)

	lui	$5,%hi(joybspeed)
	lui	$4,%hi($LC16)
	addiu	$5,$5,%lo(joybspeed)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC16)

	lui	$5,%hi(joybmenu)
	lui	$4,%hi($LC17)
	addiu	$5,$5,%lo(joybmenu)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC17)

	lui	$5,%hi(joybstrafeleft)
	lui	$4,%hi($LC18)
	addiu	$5,$5,%lo(joybstrafeleft)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC18)

	lui	$5,%hi(joybstraferight)
	lui	$4,%hi($LC19)
	addiu	$5,$5,%lo(joybstraferight)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC19)

	lui	$5,%hi(mousebstrafeleft)
	lui	$4,%hi($LC20)
	addiu	$5,$5,%lo(mousebstrafeleft)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC20)

	lui	$5,%hi(mousebstraferight)
	lui	$4,%hi($LC21)
	addiu	$5,$5,%lo(mousebstraferight)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC21)

	lui	$5,%hi(mousebuse)
	lui	$4,%hi($LC22)
	addiu	$5,$5,%lo(mousebuse)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC22)

	lui	$5,%hi(mousebbackward)
	lui	$4,%hi($LC23)
	addiu	$5,$5,%lo(mousebbackward)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC23)

	lui	$5,%hi(dclick_use)
	lui	$4,%hi($LC24)
	addiu	$5,$5,%lo(dclick_use)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC24)

	lui	$5,%hi(key_pause)
	lui	$4,%hi($LC25)
	addiu	$5,$5,%lo(key_pause)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC25)

	lw	$31,20($sp)
	lui	$5,%hi(key_message_refresh)
	lui	$4,%hi($LC26)
	addiu	$5,$5,%lo(key_message_refresh)
	addiu	$4,$4,%lo($LC26)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindBaseControls
	.size	M_BindBaseControls, .-M_BindBaseControls
	.section	.rodata.str1.4
	.align	2
$LC27:
	.ascii	"key_flyup\000"
	.align	2
$LC28:
	.ascii	"key_flydown\000"
	.align	2
$LC29:
	.ascii	"key_flycenter\000"
	.align	2
$LC30:
	.ascii	"key_lookup\000"
	.align	2
$LC31:
	.ascii	"key_lookdown\000"
	.align	2
$LC32:
	.ascii	"key_lookcenter\000"
	.align	2
$LC33:
	.ascii	"key_invleft\000"
	.align	2
$LC34:
	.ascii	"key_invright\000"
	.align	2
$LC35:
	.ascii	"key_useartifact\000"
	.text
	.align	2
	.globl	M_BindHereticControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindHereticControls
	.type	M_BindHereticControls, @function
M_BindHereticControls:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(key_flyup)
	lui	$4,%hi($LC27)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(key_flyup)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC27)

	lui	$5,%hi(key_flydown)
	lui	$4,%hi($LC28)
	addiu	$5,$5,%lo(key_flydown)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC28)

	lui	$5,%hi(key_flycenter)
	lui	$4,%hi($LC29)
	addiu	$5,$5,%lo(key_flycenter)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC29)

	lui	$5,%hi(key_lookup)
	lui	$4,%hi($LC30)
	addiu	$5,$5,%lo(key_lookup)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC30)

	lui	$5,%hi(key_lookdown)
	lui	$4,%hi($LC31)
	addiu	$5,$5,%lo(key_lookdown)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC31)

	lui	$5,%hi(key_lookcenter)
	lui	$4,%hi($LC32)
	addiu	$5,$5,%lo(key_lookcenter)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC32)

	lui	$5,%hi(key_invleft)
	lui	$4,%hi($LC33)
	addiu	$5,$5,%lo(key_invleft)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC33)

	lui	$5,%hi(key_invright)
	lui	$4,%hi($LC34)
	addiu	$5,$5,%lo(key_invright)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC34)

	lw	$31,20($sp)
	lui	$5,%hi(key_useartifact)
	lui	$4,%hi($LC35)
	addiu	$5,$5,%lo(key_useartifact)
	addiu	$4,$4,%lo($LC35)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindHereticControls
	.size	M_BindHereticControls, .-M_BindHereticControls
	.section	.rodata.str1.4
	.align	2
$LC36:
	.ascii	"key_jump\000"
	.align	2
$LC37:
	.ascii	"mouseb_jump\000"
	.align	2
$LC38:
	.ascii	"joyb_jump\000"
	.align	2
$LC39:
	.ascii	"key_arti_all\000"
	.align	2
$LC40:
	.ascii	"key_arti_health\000"
	.align	2
$LC41:
	.ascii	"key_arti_poisonbag\000"
	.align	2
$LC42:
	.ascii	"key_arti_blastradius\000"
	.align	2
$LC43:
	.ascii	"key_arti_teleport\000"
	.align	2
$LC44:
	.ascii	"key_arti_teleportother\000"
	.align	2
$LC45:
	.ascii	"key_arti_egg\000"
	.align	2
$LC46:
	.ascii	"key_arti_invulnerability\000"
	.text
	.align	2
	.globl	M_BindHexenControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindHexenControls
	.type	M_BindHexenControls, @function
M_BindHexenControls:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(key_jump)
	lui	$4,%hi($LC36)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(key_jump)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC36)

	lui	$5,%hi(mousebjump)
	lui	$4,%hi($LC37)
	addiu	$5,$5,%lo(mousebjump)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC37)

	lui	$5,%hi(joybjump)
	lui	$4,%hi($LC38)
	addiu	$5,$5,%lo(joybjump)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC38)

	lui	$5,%hi(key_arti_all)
	lui	$4,%hi($LC39)
	addiu	$5,$5,%lo(key_arti_all)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC39)

	lui	$5,%hi(key_arti_health)
	lui	$4,%hi($LC40)
	addiu	$5,$5,%lo(key_arti_health)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC40)

	lui	$5,%hi(key_arti_poisonbag)
	lui	$4,%hi($LC41)
	addiu	$5,$5,%lo(key_arti_poisonbag)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC41)

	lui	$5,%hi(key_arti_blastradius)
	lui	$4,%hi($LC42)
	addiu	$5,$5,%lo(key_arti_blastradius)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC42)

	lui	$5,%hi(key_arti_teleport)
	lui	$4,%hi($LC43)
	addiu	$5,$5,%lo(key_arti_teleport)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC43)

	lui	$5,%hi(key_arti_teleportother)
	lui	$4,%hi($LC44)
	addiu	$5,$5,%lo(key_arti_teleportother)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC44)

	lui	$5,%hi(key_arti_egg)
	lui	$4,%hi($LC45)
	addiu	$5,$5,%lo(key_arti_egg)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC45)

	lw	$31,20($sp)
	lui	$5,%hi(key_arti_invulnerability)
	lui	$4,%hi($LC46)
	addiu	$5,$5,%lo(key_arti_invulnerability)
	addiu	$4,$4,%lo($LC46)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindHexenControls
	.size	M_BindHexenControls, .-M_BindHexenControls
	.section	.rodata.str1.4
	.align	2
$LC47:
	.ascii	"key_lookUp\000"
	.align	2
$LC48:
	.ascii	"key_lookDown\000"
	.align	2
$LC49:
	.ascii	"key_invLeft\000"
	.align	2
$LC50:
	.ascii	"key_invRight\000"
	.align	2
$LC51:
	.ascii	"key_useHealth\000"
	.align	2
$LC52:
	.ascii	"key_invquery\000"
	.align	2
$LC53:
	.ascii	"key_mission\000"
	.align	2
$LC54:
	.ascii	"key_invPop\000"
	.align	2
$LC55:
	.ascii	"key_invKey\000"
	.align	2
$LC56:
	.ascii	"key_invHome\000"
	.align	2
$LC57:
	.ascii	"key_invEnd\000"
	.align	2
$LC58:
	.ascii	"key_invUse\000"
	.align	2
$LC59:
	.ascii	"key_invDrop\000"
	.text
	.align	2
	.globl	M_BindStrifeControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindStrifeControls
	.type	M_BindStrifeControls, @function
M_BindStrifeControls:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$6,47			# 0x2f
	lui	$3,%hi(key_message_refresh)
	addiu	$sp,$sp,-40
	sw	$6,%lo(key_message_refresh)($3)
	lui	$2,%hi(key_jump)
	li	$3,97			# 0x61
	sw	$3,%lo(key_jump)($2)
	addiu	$5,$2,%lo(key_jump)
	sw	$19,32($sp)
	li	$2,201			# 0xc9
	lui	$19,%hi(key_lookup)
	sw	$18,28($sp)
	sw	$2,%lo(key_lookup)($19)
	lui	$18,%hi(key_lookdown)
	li	$2,209			# 0xd1
	sw	$17,24($sp)
	sw	$2,%lo(key_lookdown)($18)
	lui	$17,%hi(key_invleft)
	li	$2,210			# 0xd2
	lui	$4,%hi($LC36)
	sw	$16,20($sp)
	sw	$2,%lo(key_invleft)($17)
	lui	$16,%hi(key_invright)
	li	$2,211			# 0xd3
	addiu	$4,$4,%lo($LC36)
	sw	$31,36($sp)
	jal	M_BindVariable
	sw	$2,%lo(key_invright)($16)

	lui	$4,%hi($LC47)
	addiu	$5,$19,%lo(key_lookup)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC47)

	lui	$4,%hi($LC48)
	addiu	$5,$18,%lo(key_lookdown)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC48)

	lui	$4,%hi($LC49)
	addiu	$5,$17,%lo(key_invleft)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC49)

	lui	$4,%hi($LC50)
	addiu	$5,$16,%lo(key_invright)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC50)

	lui	$5,%hi(key_usehealth)
	lui	$4,%hi($LC51)
	addiu	$5,$5,%lo(key_usehealth)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC51)

	lui	$5,%hi(key_invquery)
	lui	$4,%hi($LC52)
	addiu	$5,$5,%lo(key_invquery)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC52)

	lui	$5,%hi(key_mission)
	lui	$4,%hi($LC53)
	addiu	$5,$5,%lo(key_mission)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC53)

	lui	$5,%hi(key_invpop)
	lui	$4,%hi($LC54)
	addiu	$5,$5,%lo(key_invpop)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC54)

	lui	$5,%hi(key_invkey)
	lui	$4,%hi($LC55)
	addiu	$5,$5,%lo(key_invkey)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC55)

	lui	$5,%hi(key_invhome)
	lui	$4,%hi($LC56)
	addiu	$5,$5,%lo(key_invhome)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC56)

	lui	$5,%hi(key_invend)
	lui	$4,%hi($LC57)
	addiu	$5,$5,%lo(key_invend)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC57)

	lui	$5,%hi(key_invuse)
	lui	$4,%hi($LC58)
	addiu	$5,$5,%lo(key_invuse)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC58)

	lui	$5,%hi(key_invdrop)
	lui	$4,%hi($LC59)
	addiu	$5,$5,%lo(key_invdrop)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC59)

	lui	$5,%hi(mousebjump)
	lui	$4,%hi($LC37)
	addiu	$5,$5,%lo(mousebjump)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC37)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$5,%hi(joybjump)
	lui	$4,%hi($LC38)
	addiu	$5,$5,%lo(joybjump)
	addiu	$4,$4,%lo($LC38)
	j	M_BindVariable
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_BindStrifeControls
	.size	M_BindStrifeControls, .-M_BindStrifeControls
	.section	.rodata.str1.4
	.align	2
$LC60:
	.ascii	"key_weapon1\000"
	.align	2
$LC61:
	.ascii	"key_weapon2\000"
	.align	2
$LC62:
	.ascii	"key_weapon3\000"
	.align	2
$LC63:
	.ascii	"key_weapon4\000"
	.align	2
$LC64:
	.ascii	"key_weapon5\000"
	.align	2
$LC65:
	.ascii	"key_weapon6\000"
	.align	2
$LC66:
	.ascii	"key_weapon7\000"
	.align	2
$LC67:
	.ascii	"key_weapon8\000"
	.align	2
$LC68:
	.ascii	"key_prevweapon\000"
	.align	2
$LC69:
	.ascii	"key_nextweapon\000"
	.align	2
$LC70:
	.ascii	"joyb_prevweapon\000"
	.align	2
$LC71:
	.ascii	"joyb_nextweapon\000"
	.align	2
$LC72:
	.ascii	"mouseb_prevweapon\000"
	.align	2
$LC73:
	.ascii	"mouseb_nextweapon\000"
	.text
	.align	2
	.globl	M_BindWeaponControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindWeaponControls
	.type	M_BindWeaponControls, @function
M_BindWeaponControls:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(key_weapon1)
	lui	$4,%hi($LC60)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(key_weapon1)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC60)

	lui	$5,%hi(key_weapon2)
	lui	$4,%hi($LC61)
	addiu	$5,$5,%lo(key_weapon2)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC61)

	lui	$5,%hi(key_weapon3)
	lui	$4,%hi($LC62)
	addiu	$5,$5,%lo(key_weapon3)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC62)

	lui	$5,%hi(key_weapon4)
	lui	$4,%hi($LC63)
	addiu	$5,$5,%lo(key_weapon4)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC63)

	lui	$5,%hi(key_weapon5)
	lui	$4,%hi($LC64)
	addiu	$5,$5,%lo(key_weapon5)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC64)

	lui	$5,%hi(key_weapon6)
	lui	$4,%hi($LC65)
	addiu	$5,$5,%lo(key_weapon6)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC65)

	lui	$5,%hi(key_weapon7)
	lui	$4,%hi($LC66)
	addiu	$5,$5,%lo(key_weapon7)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC66)

	lui	$5,%hi(key_weapon8)
	lui	$4,%hi($LC67)
	addiu	$5,$5,%lo(key_weapon8)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC67)

	lui	$5,%hi(key_prevweapon)
	lui	$4,%hi($LC68)
	addiu	$5,$5,%lo(key_prevweapon)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC68)

	lui	$5,%hi(key_nextweapon)
	lui	$4,%hi($LC69)
	addiu	$5,$5,%lo(key_nextweapon)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC69)

	lui	$5,%hi(joybprevweapon)
	lui	$4,%hi($LC70)
	addiu	$5,$5,%lo(joybprevweapon)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC70)

	lui	$5,%hi(joybnextweapon)
	lui	$4,%hi($LC71)
	addiu	$5,$5,%lo(joybnextweapon)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC71)

	lui	$5,%hi(mousebprevweapon)
	lui	$4,%hi($LC72)
	addiu	$5,$5,%lo(mousebprevweapon)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC72)

	lw	$31,20($sp)
	lui	$5,%hi(mousebnextweapon)
	lui	$4,%hi($LC73)
	addiu	$5,$5,%lo(mousebnextweapon)
	addiu	$4,$4,%lo($LC73)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindWeaponControls
	.size	M_BindWeaponControls, .-M_BindWeaponControls
	.section	.rodata.str1.4
	.align	2
$LC74:
	.ascii	"key_map_north\000"
	.align	2
$LC75:
	.ascii	"key_map_south\000"
	.align	2
$LC76:
	.ascii	"key_map_east\000"
	.align	2
$LC77:
	.ascii	"key_map_west\000"
	.align	2
$LC78:
	.ascii	"key_map_zoomin\000"
	.align	2
$LC79:
	.ascii	"key_map_zoomout\000"
	.align	2
$LC80:
	.ascii	"key_map_toggle\000"
	.align	2
$LC81:
	.ascii	"key_map_maxzoom\000"
	.align	2
$LC82:
	.ascii	"key_map_follow\000"
	.align	2
$LC83:
	.ascii	"key_map_grid\000"
	.align	2
$LC84:
	.ascii	"key_map_mark\000"
	.align	2
$LC85:
	.ascii	"key_map_clearmark\000"
	.text
	.align	2
	.globl	M_BindMapControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindMapControls
	.type	M_BindMapControls, @function
M_BindMapControls:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(key_map_north)
	lui	$4,%hi($LC74)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(key_map_north)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC74)

	lui	$5,%hi(key_map_south)
	lui	$4,%hi($LC75)
	addiu	$5,$5,%lo(key_map_south)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC75)

	lui	$5,%hi(key_map_east)
	lui	$4,%hi($LC76)
	addiu	$5,$5,%lo(key_map_east)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC76)

	lui	$5,%hi(key_map_west)
	lui	$4,%hi($LC77)
	addiu	$5,$5,%lo(key_map_west)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC77)

	lui	$5,%hi(key_map_zoomin)
	lui	$4,%hi($LC78)
	addiu	$5,$5,%lo(key_map_zoomin)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC78)

	lui	$5,%hi(key_map_zoomout)
	lui	$4,%hi($LC79)
	addiu	$5,$5,%lo(key_map_zoomout)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC79)

	lui	$5,%hi(key_map_toggle)
	lui	$4,%hi($LC80)
	addiu	$5,$5,%lo(key_map_toggle)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC80)

	lui	$5,%hi(key_map_maxzoom)
	lui	$4,%hi($LC81)
	addiu	$5,$5,%lo(key_map_maxzoom)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC81)

	lui	$5,%hi(key_map_follow)
	lui	$4,%hi($LC82)
	addiu	$5,$5,%lo(key_map_follow)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC82)

	lui	$5,%hi(key_map_grid)
	lui	$4,%hi($LC83)
	addiu	$5,$5,%lo(key_map_grid)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC83)

	lui	$5,%hi(key_map_mark)
	lui	$4,%hi($LC84)
	addiu	$5,$5,%lo(key_map_mark)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC84)

	lw	$31,20($sp)
	lui	$5,%hi(key_map_clearmark)
	lui	$4,%hi($LC85)
	addiu	$5,$5,%lo(key_map_clearmark)
	addiu	$4,$4,%lo($LC85)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindMapControls
	.size	M_BindMapControls, .-M_BindMapControls
	.section	.rodata.str1.4
	.align	2
$LC86:
	.ascii	"key_menu_activate\000"
	.align	2
$LC87:
	.ascii	"key_menu_up\000"
	.align	2
$LC88:
	.ascii	"key_menu_down\000"
	.align	2
$LC89:
	.ascii	"key_menu_left\000"
	.align	2
$LC90:
	.ascii	"key_menu_right\000"
	.align	2
$LC91:
	.ascii	"key_menu_back\000"
	.align	2
$LC92:
	.ascii	"key_menu_forward\000"
	.align	2
$LC93:
	.ascii	"key_menu_confirm\000"
	.align	2
$LC94:
	.ascii	"key_menu_abort\000"
	.align	2
$LC95:
	.ascii	"key_menu_help\000"
	.align	2
$LC96:
	.ascii	"key_menu_save\000"
	.align	2
$LC97:
	.ascii	"key_menu_load\000"
	.align	2
$LC98:
	.ascii	"key_menu_volume\000"
	.align	2
$LC99:
	.ascii	"key_menu_detail\000"
	.align	2
$LC100:
	.ascii	"key_menu_qsave\000"
	.align	2
$LC101:
	.ascii	"key_menu_endgame\000"
	.align	2
$LC102:
	.ascii	"key_menu_messages\000"
	.align	2
$LC103:
	.ascii	"key_menu_qload\000"
	.align	2
$LC104:
	.ascii	"key_menu_quit\000"
	.align	2
$LC105:
	.ascii	"key_menu_gamma\000"
	.align	2
$LC106:
	.ascii	"key_menu_incscreen\000"
	.align	2
$LC107:
	.ascii	"key_menu_decscreen\000"
	.align	2
$LC108:
	.ascii	"key_menu_screenshot\000"
	.align	2
$LC109:
	.ascii	"key_demo_quit\000"
	.align	2
$LC110:
	.ascii	"key_spy\000"
	.text
	.align	2
	.globl	M_BindMenuControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindMenuControls
	.type	M_BindMenuControls, @function
M_BindMenuControls:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(key_menu_activate)
	lui	$4,%hi($LC86)
	addiu	$sp,$sp,-24
	addiu	$5,$5,%lo(key_menu_activate)
	sw	$31,20($sp)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC86)

	lui	$5,%hi(key_menu_up)
	lui	$4,%hi($LC87)
	addiu	$5,$5,%lo(key_menu_up)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC87)

	lui	$5,%hi(key_menu_down)
	lui	$4,%hi($LC88)
	addiu	$5,$5,%lo(key_menu_down)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC88)

	lui	$5,%hi(key_menu_left)
	lui	$4,%hi($LC89)
	addiu	$5,$5,%lo(key_menu_left)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC89)

	lui	$5,%hi(key_menu_right)
	lui	$4,%hi($LC90)
	addiu	$5,$5,%lo(key_menu_right)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC90)

	lui	$5,%hi(key_menu_back)
	lui	$4,%hi($LC91)
	addiu	$5,$5,%lo(key_menu_back)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC91)

	lui	$5,%hi(key_menu_forward)
	lui	$4,%hi($LC92)
	addiu	$5,$5,%lo(key_menu_forward)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC92)

	lui	$5,%hi(key_menu_confirm)
	lui	$4,%hi($LC93)
	addiu	$5,$5,%lo(key_menu_confirm)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC93)

	lui	$5,%hi(key_menu_abort)
	lui	$4,%hi($LC94)
	addiu	$5,$5,%lo(key_menu_abort)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC94)

	lui	$5,%hi(key_menu_help)
	lui	$4,%hi($LC95)
	addiu	$5,$5,%lo(key_menu_help)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC95)

	lui	$5,%hi(key_menu_save)
	lui	$4,%hi($LC96)
	addiu	$5,$5,%lo(key_menu_save)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC96)

	lui	$5,%hi(key_menu_load)
	lui	$4,%hi($LC97)
	addiu	$5,$5,%lo(key_menu_load)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC97)

	lui	$5,%hi(key_menu_volume)
	lui	$4,%hi($LC98)
	addiu	$5,$5,%lo(key_menu_volume)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC98)

	lui	$5,%hi(key_menu_detail)
	lui	$4,%hi($LC99)
	addiu	$5,$5,%lo(key_menu_detail)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC99)

	lui	$5,%hi(key_menu_qsave)
	lui	$4,%hi($LC100)
	addiu	$5,$5,%lo(key_menu_qsave)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC100)

	lui	$5,%hi(key_menu_endgame)
	lui	$4,%hi($LC101)
	addiu	$5,$5,%lo(key_menu_endgame)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC101)

	lui	$5,%hi(key_menu_messages)
	lui	$4,%hi($LC102)
	addiu	$5,$5,%lo(key_menu_messages)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC102)

	lui	$5,%hi(key_menu_qload)
	lui	$4,%hi($LC103)
	addiu	$5,$5,%lo(key_menu_qload)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC103)

	lui	$5,%hi(key_menu_quit)
	lui	$4,%hi($LC104)
	addiu	$5,$5,%lo(key_menu_quit)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC104)

	lui	$5,%hi(key_menu_gamma)
	lui	$4,%hi($LC105)
	addiu	$5,$5,%lo(key_menu_gamma)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC105)

	lui	$5,%hi(key_menu_incscreen)
	lui	$4,%hi($LC106)
	addiu	$5,$5,%lo(key_menu_incscreen)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC106)

	lui	$5,%hi(key_menu_decscreen)
	lui	$4,%hi($LC107)
	addiu	$5,$5,%lo(key_menu_decscreen)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC107)

	lui	$5,%hi(key_menu_screenshot)
	lui	$4,%hi($LC108)
	addiu	$5,$5,%lo(key_menu_screenshot)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC108)

	lui	$5,%hi(key_demo_quit)
	lui	$4,%hi($LC109)
	addiu	$5,$5,%lo(key_demo_quit)
	jal	M_BindVariable
	addiu	$4,$4,%lo($LC109)

	lw	$31,20($sp)
	lui	$5,%hi(key_spy)
	lui	$4,%hi($LC110)
	addiu	$5,$5,%lo(key_spy)
	addiu	$4,$4,%lo($LC110)
	j	M_BindVariable
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_BindMenuControls
	.size	M_BindMenuControls, .-M_BindMenuControls
	.section	.rodata.str1.4
	.align	2
$LC111:
	.ascii	"key_multi_msg\000"
	.align	2
$LC112:
	.ascii	"key_multi_msgplayer%i\000"
	.text
	.align	2
	.globl	M_BindChatControls
	.set	nomips16
	.set	nomicromips
	.ent	M_BindChatControls
	.type	M_BindChatControls, @function
M_BindChatControls:
	.frame	$sp,72,$31		# vars= 32, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	lui	$5,%hi(key_multi_msg)
	sw	$18,60($sp)
	move	$18,$4
	lui	$4,%hi($LC111)
	addiu	$5,$5,%lo(key_multi_msg)
	addiu	$4,$4,%lo($LC111)
	sw	$31,68($sp)
	sw	$19,64($sp)
	sw	$17,56($sp)
	jal	M_BindVariable
	sw	$16,52($sp)

	beq	$18,$0,$L16
	lui	$17,%hi(key_multi_msgplayer)

	lui	$19,%hi($LC112)
	addiu	$17,$17,%lo(key_multi_msgplayer)
	move	$16,$0
	addiu	$19,$19,%lo($LC112)
$L18:
	addiu	$16,$16,1
	move	$7,$16
	move	$6,$19
	addiu	$4,$sp,16
	jal	M_snprintf
	li	$5,32			# 0x20

	move	$5,$17
	jal	M_BindVariable
	addiu	$4,$sp,16

	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L18
	.set	at
	addiu	$17,$17,4

$L16:
	lw	$31,68($sp)
	lw	$19,64($sp)
	lw	$18,60($sp)
	lw	$17,56($sp)
	lw	$16,52($sp)
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	M_BindChatControls
	.size	M_BindChatControls, .-M_BindChatControls
	.align	2
	.globl	M_ApplyPlatformDefaults
	.set	nomips16
	.set	nomicromips
	.ent	M_ApplyPlatformDefaults
	.type	M_ApplyPlatformDefaults, @function
M_ApplyPlatformDefaults:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_ApplyPlatformDefaults
	.size	M_ApplyPlatformDefaults, .-M_ApplyPlatformDefaults
	.globl	dclick_use
	.data
	.align	2
	.type	dclick_use, @object
	.size	dclick_use, 4
dclick_use:
	.word	1
	.globl	joybmenu
	.align	2
	.type	joybmenu, @object
	.size	joybmenu, 4
joybmenu:
	.word	-1
	.globl	joybnextweapon
	.align	2
	.type	joybnextweapon, @object
	.size	joybnextweapon, 4
joybnextweapon:
	.word	-1
	.globl	joybprevweapon
	.align	2
	.type	joybprevweapon, @object
	.size	joybprevweapon, 4
joybprevweapon:
	.word	-1
	.globl	joybjump
	.align	2
	.type	joybjump, @object
	.size	joybjump, 4
joybjump:
	.word	-1
	.globl	joybstraferight
	.align	2
	.type	joybstraferight, @object
	.size	joybstraferight, 4
joybstraferight:
	.word	-1
	.globl	joybstrafeleft
	.align	2
	.type	joybstrafeleft, @object
	.size	joybstrafeleft, 4
joybstrafeleft:
	.word	-1
	.globl	joybspeed
	.align	2
	.type	joybspeed, @object
	.size	joybspeed, 4
joybspeed:
	.word	2
	.globl	joybuse
	.align	2
	.type	joybuse, @object
	.size	joybuse, 4
joybuse:
	.word	3
	.globl	joybstrafe
	.align	2
	.type	joybstrafe, @object
	.size	joybstrafe, 4
joybstrafe:
	.word	1
	.globl	joybfire
	.section	.bss,"aw",@nobits
	.align	2
	.type	joybfire, @object
	.size	joybfire, 4
joybfire:
	.space	4
	.globl	key_menu_screenshot
	.align	2
	.type	key_menu_screenshot, @object
	.size	key_menu_screenshot, 4
key_menu_screenshot:
	.space	4
	.globl	key_menu_decscreen
	.data
	.align	2
	.type	key_menu_decscreen, @object
	.size	key_menu_decscreen, 4
key_menu_decscreen:
	.word	45
	.globl	key_menu_incscreen
	.align	2
	.type	key_menu_incscreen, @object
	.size	key_menu_incscreen, 4
key_menu_incscreen:
	.word	61
	.globl	key_menu_gamma
	.align	2
	.type	key_menu_gamma, @object
	.size	key_menu_gamma, 4
key_menu_gamma:
	.word	215
	.globl	key_menu_quit
	.align	2
	.type	key_menu_quit, @object
	.size	key_menu_quit, 4
key_menu_quit:
	.word	196
	.globl	key_menu_qload
	.align	2
	.type	key_menu_qload, @object
	.size	key_menu_qload, 4
key_menu_qload:
	.word	195
	.globl	key_menu_messages
	.align	2
	.type	key_menu_messages, @object
	.size	key_menu_messages, 4
key_menu_messages:
	.word	194
	.globl	key_menu_endgame
	.align	2
	.type	key_menu_endgame, @object
	.size	key_menu_endgame, 4
key_menu_endgame:
	.word	193
	.globl	key_menu_qsave
	.align	2
	.type	key_menu_qsave, @object
	.size	key_menu_qsave, 4
key_menu_qsave:
	.word	192
	.globl	key_menu_detail
	.align	2
	.type	key_menu_detail, @object
	.size	key_menu_detail, 4
key_menu_detail:
	.word	191
	.globl	key_menu_volume
	.align	2
	.type	key_menu_volume, @object
	.size	key_menu_volume, 4
key_menu_volume:
	.word	190
	.globl	key_menu_load
	.align	2
	.type	key_menu_load, @object
	.size	key_menu_load, 4
key_menu_load:
	.word	189
	.globl	key_menu_save
	.align	2
	.type	key_menu_save, @object
	.size	key_menu_save, 4
key_menu_save:
	.word	188
	.globl	key_menu_help
	.align	2
	.type	key_menu_help, @object
	.size	key_menu_help, 4
key_menu_help:
	.word	187
	.globl	key_menu_abort
	.align	2
	.type	key_menu_abort, @object
	.size	key_menu_abort, 4
key_menu_abort:
	.word	110
	.globl	key_menu_confirm
	.align	2
	.type	key_menu_confirm, @object
	.size	key_menu_confirm, 4
key_menu_confirm:
	.word	121
	.globl	key_menu_forward
	.align	2
	.type	key_menu_forward, @object
	.size	key_menu_forward, 4
key_menu_forward:
	.word	13
	.globl	key_menu_back
	.align	2
	.type	key_menu_back, @object
	.size	key_menu_back, 4
key_menu_back:
	.word	127
	.globl	key_menu_right
	.align	2
	.type	key_menu_right, @object
	.size	key_menu_right, 4
key_menu_right:
	.word	174
	.globl	key_menu_left
	.align	2
	.type	key_menu_left, @object
	.size	key_menu_left, 4
key_menu_left:
	.word	172
	.globl	key_menu_down
	.align	2
	.type	key_menu_down, @object
	.size	key_menu_down, 4
key_menu_down:
	.word	175
	.globl	key_menu_up
	.align	2
	.type	key_menu_up, @object
	.size	key_menu_up, 4
key_menu_up:
	.word	173
	.globl	key_menu_activate
	.align	2
	.type	key_menu_activate, @object
	.size	key_menu_activate, 4
key_menu_activate:
	.word	27
	.globl	key_map_clearmark
	.align	2
	.type	key_map_clearmark, @object
	.size	key_map_clearmark, 4
key_map_clearmark:
	.word	99
	.globl	key_map_mark
	.align	2
	.type	key_map_mark, @object
	.size	key_map_mark, 4
key_map_mark:
	.word	109
	.globl	key_map_grid
	.align	2
	.type	key_map_grid, @object
	.size	key_map_grid, 4
key_map_grid:
	.word	103
	.globl	key_map_follow
	.align	2
	.type	key_map_follow, @object
	.size	key_map_follow, 4
key_map_follow:
	.word	102
	.globl	key_map_maxzoom
	.align	2
	.type	key_map_maxzoom, @object
	.size	key_map_maxzoom, 4
key_map_maxzoom:
	.word	48
	.globl	key_map_toggle
	.align	2
	.type	key_map_toggle, @object
	.size	key_map_toggle, 4
key_map_toggle:
	.word	9
	.globl	key_map_zoomout
	.align	2
	.type	key_map_zoomout, @object
	.size	key_map_zoomout, 4
key_map_zoomout:
	.word	45
	.globl	key_map_zoomin
	.align	2
	.type	key_map_zoomin, @object
	.size	key_map_zoomin, 4
key_map_zoomin:
	.word	61
	.globl	key_map_west
	.align	2
	.type	key_map_west, @object
	.size	key_map_west, 4
key_map_west:
	.word	172
	.globl	key_map_east
	.align	2
	.type	key_map_east, @object
	.size	key_map_east, 4
key_map_east:
	.word	174
	.globl	key_map_south
	.align	2
	.type	key_map_south, @object
	.size	key_map_south, 4
key_map_south:
	.word	175
	.globl	key_map_north
	.align	2
	.type	key_map_north, @object
	.size	key_map_north, 4
key_map_north:
	.word	173
	.globl	key_nextweapon
	.section	.bss
	.align	2
	.type	key_nextweapon, @object
	.size	key_nextweapon, 4
key_nextweapon:
	.space	4
	.globl	key_prevweapon
	.align	2
	.type	key_prevweapon, @object
	.size	key_prevweapon, 4
key_prevweapon:
	.space	4
	.globl	key_weapon8
	.data
	.align	2
	.type	key_weapon8, @object
	.size	key_weapon8, 4
key_weapon8:
	.word	56
	.globl	key_weapon7
	.align	2
	.type	key_weapon7, @object
	.size	key_weapon7, 4
key_weapon7:
	.word	55
	.globl	key_weapon6
	.align	2
	.type	key_weapon6, @object
	.size	key_weapon6, 4
key_weapon6:
	.word	54
	.globl	key_weapon5
	.align	2
	.type	key_weapon5, @object
	.size	key_weapon5, 4
key_weapon5:
	.word	53
	.globl	key_weapon4
	.align	2
	.type	key_weapon4, @object
	.size	key_weapon4, 4
key_weapon4:
	.word	52
	.globl	key_weapon3
	.align	2
	.type	key_weapon3, @object
	.size	key_weapon3, 4
key_weapon3:
	.word	51
	.globl	key_weapon2
	.align	2
	.type	key_weapon2, @object
	.size	key_weapon2, 4
key_weapon2:
	.word	50
	.globl	key_weapon1
	.align	2
	.type	key_weapon1, @object
	.size	key_weapon1, 4
key_weapon1:
	.word	49
	.globl	key_multi_msgplayer
	.section	.bss
	.align	2
	.type	key_multi_msgplayer, @object
	.size	key_multi_msgplayer, 32
key_multi_msgplayer:
	.space	32
	.globl	key_multi_msg
	.data
	.align	2
	.type	key_multi_msg, @object
	.size	key_multi_msg, 4
key_multi_msg:
	.word	116
	.globl	key_spy
	.align	2
	.type	key_spy, @object
	.size	key_spy, 4
key_spy:
	.word	216
	.globl	key_demo_quit
	.align	2
	.type	key_demo_quit, @object
	.size	key_demo_quit, 4
key_demo_quit:
	.word	113
	.globl	key_pause
	.align	2
	.type	key_pause, @object
	.size	key_pause, 4
key_pause:
	.word	255
	.globl	key_message_refresh
	.align	2
	.type	key_message_refresh, @object
	.size	key_message_refresh, 4
key_message_refresh:
	.word	13
	.globl	mousebnextweapon
	.align	2
	.type	mousebnextweapon, @object
	.size	mousebnextweapon, 4
mousebnextweapon:
	.word	-1
	.globl	mousebprevweapon
	.align	2
	.type	mousebprevweapon, @object
	.size	mousebprevweapon, 4
mousebprevweapon:
	.word	-1
	.globl	mousebuse
	.align	2
	.type	mousebuse, @object
	.size	mousebuse, 4
mousebuse:
	.word	-1
	.globl	mousebbackward
	.align	2
	.type	mousebbackward, @object
	.size	mousebbackward, 4
mousebbackward:
	.word	-1
	.globl	mousebstraferight
	.align	2
	.type	mousebstraferight, @object
	.size	mousebstraferight, 4
mousebstraferight:
	.word	-1
	.globl	mousebstrafeleft
	.align	2
	.type	mousebstrafeleft, @object
	.size	mousebstrafeleft, 4
mousebstrafeleft:
	.word	-1
	.globl	mousebjump
	.align	2
	.type	mousebjump, @object
	.size	mousebjump, 4
mousebjump:
	.word	-1
	.globl	mousebforward
	.align	2
	.type	mousebforward, @object
	.size	mousebforward, 4
mousebforward:
	.word	2
	.globl	mousebstrafe
	.align	2
	.type	mousebstrafe, @object
	.size	mousebstrafe, 4
mousebstrafe:
	.word	1
	.globl	mousebfire
	.section	.bss
	.align	2
	.type	mousebfire, @object
	.size	mousebfire, 4
mousebfire:
	.space	4
	.globl	key_invdrop
	.data
	.align	2
	.type	key_invdrop, @object
	.size	key_invdrop, 4
key_invdrop:
	.word	127
	.globl	key_invuse
	.align	2
	.type	key_invuse, @object
	.size	key_invuse, 4
key_invuse:
	.word	13
	.globl	key_invend
	.align	2
	.type	key_invend, @object
	.size	key_invend, 4
key_invend:
	.word	207
	.globl	key_invhome
	.align	2
	.type	key_invhome, @object
	.size	key_invhome, 4
key_invhome:
	.word	199
	.globl	key_invkey
	.align	2
	.type	key_invkey, @object
	.size	key_invkey, 4
key_invkey:
	.word	107
	.globl	key_invpop
	.align	2
	.type	key_invpop, @object
	.size	key_invpop, 4
key_invpop:
	.word	122
	.globl	key_mission
	.align	2
	.type	key_mission, @object
	.size	key_mission, 4
key_mission:
	.word	119
	.globl	key_invquery
	.align	2
	.type	key_invquery, @object
	.size	key_invquery, 4
key_invquery:
	.word	113
	.globl	key_usehealth
	.align	2
	.type	key_usehealth, @object
	.size	key_usehealth, 4
key_usehealth:
	.word	104
	.globl	key_arti_invulnerability
	.align	2
	.type	key_arti_invulnerability, @object
	.size	key_arti_invulnerability, 4
key_arti_invulnerability:
	.word	53
	.globl	key_arti_egg
	.align	2
	.type	key_arti_egg, @object
	.size	key_arti_egg, 4
key_arti_egg:
	.word	54
	.globl	key_arti_teleportother
	.align	2
	.type	key_arti_teleportother, @object
	.size	key_arti_teleportother, 4
key_arti_teleportother:
	.word	55
	.globl	key_arti_teleport
	.align	2
	.type	key_arti_teleport, @object
	.size	key_arti_teleport, 4
key_arti_teleport:
	.word	56
	.globl	key_arti_blastradius
	.align	2
	.type	key_arti_blastradius, @object
	.size	key_arti_blastradius, 4
key_arti_blastradius:
	.word	57
	.globl	key_arti_poisonbag
	.align	2
	.type	key_arti_poisonbag, @object
	.size	key_arti_poisonbag, 4
key_arti_poisonbag:
	.word	48
	.globl	key_arti_health
	.align	2
	.type	key_arti_health, @object
	.size	key_arti_health, 4
key_arti_health:
	.word	92
	.globl	key_arti_all
	.align	2
	.type	key_arti_all, @object
	.size	key_arti_all, 4
key_arti_all:
	.word	127
	.globl	key_jump
	.align	2
	.type	key_jump, @object
	.size	key_jump, 4
key_jump:
	.word	47
	.globl	key_useartifact
	.align	2
	.type	key_useartifact, @object
	.size	key_useartifact, 4
key_useartifact:
	.word	13
	.globl	key_invright
	.align	2
	.type	key_invright, @object
	.size	key_invright, 4
key_invright:
	.word	93
	.globl	key_invleft
	.align	2
	.type	key_invleft, @object
	.size	key_invleft, 4
key_invleft:
	.word	91
	.globl	key_lookcenter
	.align	2
	.type	key_lookcenter, @object
	.size	key_lookcenter, 4
key_lookcenter:
	.word	207
	.globl	key_lookdown
	.align	2
	.type	key_lookdown, @object
	.size	key_lookdown, 4
key_lookdown:
	.word	211
	.globl	key_lookup
	.align	2
	.type	key_lookup, @object
	.size	key_lookup, 4
key_lookup:
	.word	209
	.globl	key_flycenter
	.align	2
	.type	key_flycenter, @object
	.size	key_flycenter, 4
key_flycenter:
	.word	199
	.globl	key_flydown
	.align	2
	.type	key_flydown, @object
	.size	key_flydown, 4
key_flydown:
	.word	210
	.globl	key_flyup
	.align	2
	.type	key_flyup, @object
	.size	key_flyup, 4
key_flyup:
	.word	201
	.globl	key_speed
	.align	2
	.type	key_speed, @object
	.size	key_speed, 4
key_speed:
	.word	182
	.globl	key_strafe
	.align	2
	.type	key_strafe, @object
	.size	key_strafe, 4
key_strafe:
	.word	184
	.globl	key_use
	.align	2
	.type	key_use, @object
	.size	key_use, 4
key_use:
	.word	162
	.globl	key_fire
	.align	2
	.type	key_fire, @object
	.size	key_fire, 4
key_fire:
	.word	163
	.globl	key_straferight
	.align	2
	.type	key_straferight, @object
	.size	key_straferight, 4
key_straferight:
	.word	161
	.globl	key_strafeleft
	.align	2
	.type	key_strafeleft, @object
	.size	key_strafeleft, 4
key_strafeleft:
	.word	160
	.globl	key_down
	.align	2
	.type	key_down, @object
	.size	key_down, 4
key_down:
	.word	175
	.globl	key_up
	.align	2
	.type	key_up, @object
	.size	key_up, 4
key_up:
	.word	173
	.globl	key_left
	.align	2
	.type	key_left, @object
	.size	key_left, 4
key_left:
	.word	172
	.globl	key_right
	.align	2
	.type	key_right, @object
	.size	key_right, 4
key_right:
	.word	174
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
