	.file	1 "m_fixed.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	FixedMul
	.set	nomips16
	.set	nomicromips
	.ent	FixedMul
	.type	FixedMul, @function
FixedMul:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	mult	$4,$5
	mflo	$4
	mfhi	$5
	srl	$4,$4,16
	sll	$2,$5,16
	jr	$31
	or	$2,$2,$4

	.set	macro
	.set	reorder
	.end	FixedMul
	.size	FixedMul, .-FixedMul
	.globl	__divdi3
	.align	2
	.globl	FixedDiv
	.set	nomips16
	.set	nomicromips
	.ent	FixedDiv
	.type	FixedDiv, @function
FixedDiv:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	move	$18,$5
	sw	$16,16($sp)
	jal	abs
	move	$17,$4

	move	$16,$2
	jal	abs
	move	$4,$18

	sra	$16,$16,14
	slt	$16,$16,$2
	bne	$16,$0,$L4
	sra	$2,$17,31

	xor	$5,$17,$18
	bltz	$5,$L8
	lw	$31,28($sp)

	li	$2,2147418112			# 0x7fff0000
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	ori	$2,$2,0xffff
	jr	$31
	addiu	$sp,$sp,32

$L4:
	sll	$2,$2,16
	srl	$5,$17,16
	move	$6,$18
	sra	$7,$18,31
	sll	$4,$17,16
	jal	__divdi3
	or	$5,$5,$2

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L8:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,-2147483648			# 0xffffffff80000000
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	FixedDiv
	.size	FixedDiv, .-FixedDiv
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
