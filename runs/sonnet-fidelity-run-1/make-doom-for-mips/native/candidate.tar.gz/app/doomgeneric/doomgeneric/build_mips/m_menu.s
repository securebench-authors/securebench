	.file	1 "m_menu.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	M_Sound
	.set	nomips16
	.set	nomicromips
	.ent	M_Sound
	.type	M_Sound, @function
M_Sound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(SoundDef)
	addiu	$2,$2,%lo(SoundDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

	.set	macro
	.set	reorder
	.end	M_Sound
	.size	M_Sound, .-M_Sound
	.align	2
	.globl	M_Options
	.set	nomips16
	.set	nomicromips
	.ent	M_Options
	.type	M_Options, @function
M_Options:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(OptionsDef)
	addiu	$2,$2,%lo(OptionsDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

	.set	macro
	.set	reorder
	.end	M_Options
	.size	M_Options, .-M_Options
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Messages OFF\000"
	.align	2
$LC1:
	.ascii	"Messages ON\000"
	.text
	.align	2
	.globl	M_ChangeMessages
	.set	nomips16
	.set	nomicromips
	.ent	M_ChangeMessages
	.type	M_ChangeMessages, @function
M_ChangeMessages:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(showMessages)
	lw	$4,%lo(showMessages)($3)
	li	$2,1			# 0x1
	subu	$2,$2,$4
	lui	$4,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($4)
	beq	$2,$0,$L6
	sw	$2,%lo(showMessages)($3)

	sll	$2,$4,3
	addu	$2,$2,$4
	lui	$4,%hi(players)
	lui	$3,%hi($LC1)
	sll	$2,$2,5
	addiu	$4,$4,%lo(players)
	addiu	$3,$3,%lo($LC1)
	addu	$2,$2,$4
	sw	$3,224($2)
	lui	$2,%hi(message_dontfuckwithme)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(message_dontfuckwithme)($2)

$L6:
	sll	$2,$4,3
	addu	$2,$2,$4
	lui	$4,%hi(players)
	lui	$3,%hi($LC0)
	sll	$2,$2,5
	addiu	$4,$4,%lo(players)
	addiu	$3,$3,%lo($LC0)
	addu	$2,$2,$4
	sw	$3,224($2)
	lui	$2,%hi(message_dontfuckwithme)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(message_dontfuckwithme)($2)

	.set	macro
	.set	reorder
	.end	M_ChangeMessages
	.size	M_ChangeMessages, .-M_ChangeMessages
	.align	2
	.globl	M_ReadThis
	.set	nomips16
	.set	nomicromips
	.ent	M_ReadThis
	.type	M_ReadThis, @function
M_ReadThis:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(ReadDef1)
	addiu	$2,$2,%lo(ReadDef1)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

	.set	macro
	.set	reorder
	.end	M_ReadThis
	.size	M_ReadThis, .-M_ReadThis
	.align	2
	.globl	M_FinishReadThis
	.set	nomips16
	.set	nomicromips
	.ent	M_FinishReadThis
	.type	M_FinishReadThis, @function
M_FinishReadThis:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(MainDef)
	addiu	$2,$2,%lo(MainDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

	.set	macro
	.set	reorder
	.end	M_FinishReadThis
	.size	M_FinishReadThis, .-M_FinishReadThis
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"HELP1\000"
	.text
	.align	2
	.globl	M_DrawReadThis2
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawReadThis2
	.type	M_DrawReadThis2, @function
M_DrawReadThis2:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC2)
	addiu	$sp,$sp,-24
	li	$5,8			# 0x8
	lui	$2,%hi(inhelpscreens)
	li	$3,1			# 0x1
	sw	$3,%lo(inhelpscreens)($2)
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC2)

	lw	$31,20($sp)
	move	$6,$2
	move	$5,$0
	move	$4,$0
	j	V_DrawPatchDirect
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_DrawReadThis2
	.size	M_DrawReadThis2, .-M_DrawReadThis2
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"M_DOOM\000"
	.text
	.align	2
	.globl	M_DrawMainMenu
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawMainMenu
	.type	M_DrawMainMenu, @function
M_DrawMainMenu:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC3)
	addiu	$sp,$sp,-24
	li	$5,8			# 0x8
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC3)

	lw	$31,20($sp)
	move	$6,$2
	li	$5,2			# 0x2
	li	$4,94			# 0x5e
	j	V_DrawPatchDirect
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_DrawMainMenu
	.size	M_DrawMainMenu, .-M_DrawMainMenu
	.section	.rodata.str1.4
	.align	2
$LC4:
	.ascii	"M_NEWG\000"
	.align	2
$LC5:
	.ascii	"M_SKILL\000"
	.text
	.align	2
	.globl	M_DrawNewGame
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawNewGame
	.type	M_DrawNewGame, @function
M_DrawNewGame:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC4)
	addiu	$sp,$sp,-24
	li	$5,8			# 0x8
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC4)

	move	$6,$2
	li	$5,14			# 0xe
	jal	V_DrawPatchDirect
	li	$4,96			# 0x60

	lui	$4,%hi($LC5)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC5)

	lw	$31,20($sp)
	move	$6,$2
	li	$5,38			# 0x26
	li	$4,54			# 0x36
	j	V_DrawPatchDirect
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_DrawNewGame
	.size	M_DrawNewGame, .-M_DrawNewGame
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"M_EPISOD\000"
	.text
	.align	2
	.globl	M_DrawEpisode
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawEpisode
	.type	M_DrawEpisode, @function
M_DrawEpisode:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC6)
	addiu	$sp,$sp,-24
	li	$5,8			# 0x8
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC6)

	lw	$31,20($sp)
	move	$6,$2
	li	$5,38			# 0x26
	li	$4,54			# 0x36
	j	V_DrawPatchDirect
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_DrawEpisode
	.size	M_DrawEpisode, .-M_DrawEpisode
	.align	2
	.globl	M_LoadSelect
	.set	nomips16
	.set	nomicromips
	.ent	M_LoadSelect
	.type	M_LoadSelect, @function
M_LoadSelect:
	.frame	$sp,280,$31		# vars= 256, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-280
	sw	$31,276($sp)
	jal	P_SaveGameFile
	nop

	move	$5,$2
	addiu	$4,$sp,16
	jal	M_StringCopy
	li	$6,256			# 0x100

	jal	G_LoadGame
	addiu	$4,$sp,16

	lw	$31,276($sp)
	lui	$2,%hi(menuactive)
	sw	$0,%lo(menuactive)($2)
	jr	$31
	addiu	$sp,$sp,280

	.set	macro
	.set	reorder
	.end	M_LoadSelect
	.size	M_LoadSelect, .-M_LoadSelect
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"empty slot\000"
	.text
	.align	2
	.globl	M_SaveSelect
	.set	nomips16
	.set	nomicromips
	.ent	M_SaveSelect
	.type	M_SaveSelect, @function
M_SaveSelect:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sll	$3,$4,1
	addu	$3,$3,$4
	sw	$16,16($sp)
	lui	$16,%hi(savegamestrings)
	sll	$3,$3,3
	addiu	$16,$16,%lo(savegamestrings)
	move	$2,$4
	addu	$16,$16,$3
	li	$7,1			# 0x1
	lui	$3,%hi(saveStringEnter)
	lui	$4,%hi(saveOldString)
	move	$5,$16
	addiu	$4,$4,%lo(saveOldString)
	sw	$7,%lo(saveStringEnter)($3)
	li	$6,24			# 0x18
	lui	$3,%hi(saveSlot)
	sw	$31,20($sp)
	jal	M_StringCopy
	sw	$2,%lo(saveSlot)($3)

	lui	$5,%hi($LC7)
	addiu	$5,$5,%lo($LC7)
	jal	strcmp
	move	$4,$16

	bne	$2,$0,$L20
	nop

	sb	$0,0($16)
$L20:
	jal	strlen
	move	$4,$16

	lw	$31,20($sp)
	lui	$3,%hi(saveCharIndex)
	lw	$16,16($sp)
	sw	$2,%lo(saveCharIndex)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_SaveSelect
	.size	M_SaveSelect, .-M_SaveSelect
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"%s\012\012(press y to quit to dos.)\000"
	.text
	.align	2
	.globl	M_QuitDOOM
	.set	nomips16
	.set	nomicromips
	.ent	M_QuitDOOM
	.type	M_QuitDOOM, @function
M_QuitDOOM:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemission)
	lw	$2,%lo(gamemission)($2)
	li	$3,-5			# 0xfffffffffffffffb
	addiu	$sp,$sp,-24
	and	$2,$2,$3
	sw	$31,20($sp)
	beq	$2,$0,$L25
	sw	$16,16($sp)

	lui	$2,%hi(doom2_endmsg)
	addiu	$3,$2,%lo(doom2_endmsg)
$L23:
	lui	$2,%hi(gametic)
	lw	$2,%lo(gametic)($2)
	li	$4,-2147483648			# 0xffffffff80000000
	addiu	$4,$4,7
	and	$2,$2,$4
	bgez	$2,$L24
	li	$4,-8			# 0xfffffffffffffff8

	addiu	$2,$2,-1
	or	$2,$2,$4
	addiu	$2,$2,1
$L24:
	sll	$2,$2,2
	addu	$2,$3,$2
	lui	$16,%hi(endstring)
	lw	$7,0($2)
	lui	$6,%hi($LC8)
	addiu	$4,$16,%lo(endstring)
	li	$5,160			# 0xa0
	jal	snprintf
	addiu	$6,$6,%lo($LC8)

	lui	$4,%hi(menuactive)
	lw	$5,%lo(menuactive)($4)
	lui	$3,%hi(messageLastMenuActive)
	li	$2,1			# 0x1
	sw	$5,%lo(messageLastMenuActive)($3)
	lui	$3,%hi(messageToPrint)
	addiu	$16,$16,%lo(endstring)
	sw	$2,%lo(messageToPrint)($3)
	lui	$3,%hi(messageString)
	sw	$16,%lo(messageString)($3)
	lui	$3,%hi(M_QuitResponse)
	lw	$31,20($sp)
	addiu	$3,$3,%lo(M_QuitResponse)
	lui	$5,%hi(messageRoutine)
	sw	$3,%lo(messageRoutine)($5)
	lui	$3,%hi(messageNeedsInput)
	lw	$16,16($sp)
	sw	$2,%lo(messageNeedsInput)($3)
	sw	$2,%lo(menuactive)($4)
	jr	$31
	addiu	$sp,$sp,24

$L25:
	lui	$2,%hi(doom1_endmsg)
	b	$L23
	addiu	$3,$2,%lo(doom1_endmsg)

	.set	macro
	.set	reorder
	.end	M_QuitDOOM
	.size	M_QuitDOOM, .-M_QuitDOOM
	.section	.rodata.str1.4
	.align	2
$LC9:
	.ascii	"HELP2\000"
	.align	2
$LC10:
	.ascii	"HELP\000"
	.align	2
$LC11:
	.ascii	"CREDIT\000"
	.align	2
$LC12:
	.ascii	"Unhandled game version\000"
	.text
	.align	2
	.globl	M_DrawReadThis1
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawReadThis1
	.type	M_DrawReadThis1, @function
M_DrawReadThis1:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	addiu	$sp,$sp,-32
	lui	$4,%hi(inhelpscreens)
	li	$5,1			# 0x1
	sltu	$3,$2,9
	sw	$5,%lo(inhelpscreens)($4)
	sw	$31,28($sp)
	sw	$17,24($sp)
	beq	$3,$0,$L28
	sw	$16,20($sp)

	sltu	$3,$2,7
	beq	$3,$0,$L32
	li	$3,6			# 0x6

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L34
	.set	at
	nop

	beq	$2,$0,$L31
	lui	$2,%hi(gamemode)

	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L37
	.set	at
	nop

	lui	$4,%hi($LC9)
	li	$16,185			# 0xb9
	li	$17,280			# 0x118
	b	$L29
	addiu	$4,$4,%lo($LC9)

$L34:
	lui	$4,%hi($LC2)
	li	$16,175			# 0xaf
	li	$17,330			# 0x14a
	addiu	$4,$4,%lo($LC2)
$L29:
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	move	$6,$2
	move	$5,$0
	jal	V_DrawPatchDirect
	move	$4,$0

	lw	$31,28($sp)
	lui	$2,%hi(ReadDef1)
	addiu	$2,$2,%lo(ReadDef1)
	sh	$17,16($2)
	sh	$16,18($2)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L28:
	li	$3,9			# 0x9
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L34
	.set	at
	nop

$L31:
	lui	$4,%hi($LC12)
	jal	I_Error
	addiu	$4,$4,%lo($LC12)

	lui	$4,%hi($LC11)
	li	$16,175			# 0xaf
	li	$17,330			# 0x14a
	b	$L29
	addiu	$4,$4,%lo($LC11)

$L32:
	lui	$4,%hi($LC10)
	li	$16,175			# 0xaf
	li	$17,330			# 0x14a
	b	$L29
	addiu	$4,$4,%lo($LC10)

$L37:
	lui	$4,%hi($LC10)
	li	$16,165			# 0xa5
	li	$17,330			# 0x14a
	b	$L29
	addiu	$4,$4,%lo($LC10)

	.set	macro
	.set	reorder
	.end	M_DrawReadThis1
	.size	M_DrawReadThis1, .-M_DrawReadThis1
	.align	2
	.globl	M_SfxVol
	.set	nomips16
	.set	nomicromips
	.ent	M_SfxVol
	.type	M_SfxVol, @function
M_SfxVol:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(sfxVolume)
	beq	$4,$0,$L39
	lw	$2,%lo(sfxVolume)($3)

	li	$5,1			# 0x1
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L41
	.set	at
	slt	$4,$2,15

	beq	$4,$0,$L41
	nop

	addiu	$2,$2,1
	sw	$2,%lo(sfxVolume)($3)
$L41:
	j	S_SetSfxVolume
	sll	$4,$2,3

$L39:
	beq	$2,$0,$L41
	nop

	addiu	$2,$2,-1
	sll	$4,$2,3
	j	S_SetSfxVolume
	sw	$2,%lo(sfxVolume)($3)

	.set	macro
	.set	reorder
	.end	M_SfxVol
	.size	M_SfxVol, .-M_SfxVol
	.align	2
	.globl	M_MusicVol
	.set	nomips16
	.set	nomicromips
	.ent	M_MusicVol
	.type	M_MusicVol, @function
M_MusicVol:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(musicVolume)
	beq	$4,$0,$L46
	lw	$2,%lo(musicVolume)($3)

	li	$5,1			# 0x1
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L48
	.set	at
	slt	$4,$2,15

	beq	$4,$0,$L48
	nop

	addiu	$2,$2,1
	sw	$2,%lo(musicVolume)($3)
$L48:
	j	S_SetMusicVolume
	sll	$4,$2,3

$L46:
	beq	$2,$0,$L48
	nop

	addiu	$2,$2,-1
	sll	$4,$2,3
	j	S_SetMusicVolume
	sw	$2,%lo(musicVolume)($3)

	.set	macro
	.set	reorder
	.end	M_MusicVol
	.size	M_MusicVol, .-M_MusicVol
	.align	2
	.globl	M_SizeDisplay
	.set	nomips16
	.set	nomicromips
	.ent	M_SizeDisplay
	.type	M_SizeDisplay, @function
M_SizeDisplay:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(screenblocks)
	move	$2,$4
	beq	$2,$0,$L53
	lw	$4,%lo(screenblocks)($3)

	li	$5,1			# 0x1
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L56
	.set	at
	lui	$2,%hi(detailLevel)

	lui	$5,%hi(screenSize)
	lw	$2,%lo(screenSize)($5)
	slt	$6,$2,8
	beq	$6,$0,$L55
	addiu	$2,$2,1

	addiu	$4,$4,1
	sw	$4,%lo(screenblocks)($3)
	sw	$2,%lo(screenSize)($5)
$L55:
	lui	$2,%hi(detailLevel)
$L56:
	j	R_SetViewSize
	lw	$5,%lo(detailLevel)($2)

$L53:
	lui	$5,%hi(screenSize)
	lw	$2,%lo(screenSize)($5)
	blez	$2,$L55
	addiu	$2,$2,-1

	sw	$2,%lo(screenSize)($5)
	lui	$2,%hi(detailLevel)
	lw	$5,%lo(detailLevel)($2)
	addiu	$4,$4,-1
	j	R_SetViewSize
	sw	$4,%lo(screenblocks)($3)

	.set	macro
	.set	reorder
	.end	M_SizeDisplay
	.size	M_SizeDisplay, .-M_SizeDisplay
	.align	2
	.globl	M_ChangeSensitivity
	.set	nomips16
	.set	nomicromips
	.ent	M_ChangeSensitivity
	.type	M_ChangeSensitivity, @function
M_ChangeSensitivity:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L58
	li	$2,1			# 0x1

	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L65
	.set	at
	lui	$3,%hi(mouseSensitivity)

	lw	$2,%lo(mouseSensitivity)($3)
	slt	$4,$2,9
	beq	$4,$0,$L65
	addiu	$2,$2,1

	jr	$31
	sw	$2,%lo(mouseSensitivity)($3)

$L65:
	jr	$31
	nop

$L58:
	lui	$3,%hi(mouseSensitivity)
	lw	$2,%lo(mouseSensitivity)($3)
	beq	$2,$0,$L65
	addiu	$2,$2,-1

	jr	$31
	sw	$2,%lo(mouseSensitivity)($3)

	.set	macro
	.set	reorder
	.end	M_ChangeSensitivity
	.size	M_ChangeSensitivity, .-M_ChangeSensitivity
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	M_QuitResponse.part.0
	.type	M_QuitResponse.part.0, @function
M_QuitResponse.part.0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	bne	$2,$0,$L71
	lui	$2,%hi(gametic)

	lw	$2,%lo(gametic)($2)
	lui	$3,%hi(gamemode)
	lw	$4,%lo(gamemode)($3)
	sra	$2,$2,2
	addiu	$sp,$sp,-24
	andi	$2,$2,0x7
	li	$3,2			# 0x2
	sll	$2,$2,2
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L74
	.set	at
	sw	$31,20($sp)

	lui	$3,%hi(quitsounds)
	addiu	$3,$3,%lo(quitsounds)
	addu	$2,$2,$3
	lw	$5,0($2)
	jal	S_StartSound
	move	$4,$0

	jal	I_WaitVBL
	li	$4,105			# 0x69

	lw	$31,20($sp)
	j	I_Quit
	addiu	$sp,$sp,24

$L71:
	j	I_Quit
	nop

$L74:
	lui	$3,%hi(quitsounds2)
	addiu	$3,$3,%lo(quitsounds2)
	addu	$2,$2,$3
	lw	$5,0($2)
	jal	S_StartSound
	move	$4,$0

	jal	I_WaitVBL
	li	$4,105			# 0x69

	lw	$31,20($sp)
	j	I_Quit
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_QuitResponse.part.0
	.size	M_QuitResponse.part.0, .-M_QuitResponse.part.0
	.align	2
	.globl	M_QuitResponse
	.set	nomips16
	.set	nomicromips
	.ent	M_QuitResponse
	.type	M_QuitResponse, @function
M_QuitResponse:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(key_menu_confirm)
	lw	$2,%lo(key_menu_confirm)($2)
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L77
	.set	at
	nop

	j	M_QuitResponse.part.0
	nop

$L77:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_QuitResponse
	.size	M_QuitResponse, .-M_QuitResponse
	.section	.rodata.str1.4
	.align	2
$LC13:
	.ascii	"High detail\000"
	.align	2
$LC14:
	.ascii	"Low detail\000"
	.text
	.align	2
	.globl	M_ChangeDetail
	.set	nomips16
	.set	nomicromips
	.ent	M_ChangeDetail
	.type	M_ChangeDetail, @function
M_ChangeDetail:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(detailLevel)
	lw	$2,%lo(detailLevel)($16)
	li	$5,1			# 0x1
	subu	$5,$5,$2
	lui	$2,%hi(screenblocks)
	lw	$4,%lo(screenblocks)($2)
	sw	$31,20($sp)
	jal	R_SetViewSize
	sw	$5,%lo(detailLevel)($16)

	lw	$2,%lo(detailLevel)($16)
	bne	$2,$0,$L79
	lui	$2,%hi(consoleplayer)

	lw	$3,%lo(consoleplayer)($2)
	lw	$31,20($sp)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	lui	$3,%hi($LC13)
	addiu	$3,$3,%lo($LC13)
	lw	$16,16($sp)
	sw	$3,224($2)
	jr	$31
	addiu	$sp,$sp,24

$L79:
	lw	$3,%lo(consoleplayer)($2)
	lw	$31,20($sp)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	lui	$3,%hi($LC14)
	addiu	$3,$3,%lo($LC14)
	lw	$16,16($sp)
	sw	$3,224($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_ChangeDetail
	.size	M_ChangeDetail, .-M_ChangeDetail
	.section	.rodata.str1.4
	.align	2
$LC15:
	.ascii	"you can't end a netgame!\012\012press a key.\000"
	.align	2
$LC16:
	.ascii	"are you sure you want to end the game?\012\012press y or"
	.ascii	" n.\000"
	.text
	.align	2
	.globl	M_EndGame
	.set	nomips16
	.set	nomicromips
	.ent	M_EndGame
	.type	M_EndGame, @function
M_EndGame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(usergame)
	lw	$2,%lo(usergame)($2)
	beq	$2,$0,$L86
	lui	$2,%hi(netgame)

	lw	$3,%lo(netgame)($2)
	lui	$2,%hi(menuactive)
	bne	$3,$0,$L87
	lw	$4,%lo(menuactive)($2)

	lui	$5,%hi(messageLastMenuActive)
	li	$3,1			# 0x1
	sw	$4,%lo(messageLastMenuActive)($5)
	lui	$4,%hi(messageToPrint)
	sw	$3,%lo(messageToPrint)($4)
	lui	$4,%hi($LC16)
	lui	$5,%hi(messageString)
	addiu	$4,$4,%lo($LC16)
	sw	$4,%lo(messageString)($5)
	lui	$4,%hi(M_EndGameResponse)
	addiu	$4,$4,%lo(M_EndGameResponse)
	lui	$5,%hi(messageRoutine)
	sw	$4,%lo(messageRoutine)($5)
	lui	$4,%hi(messageNeedsInput)
	sw	$3,%lo(messageNeedsInput)($4)
	jr	$31
	sw	$3,%lo(menuactive)($2)

$L87:
	lui	$3,%hi(messageLastMenuActive)
	li	$5,1			# 0x1
	sw	$4,%lo(messageLastMenuActive)($3)
	lui	$3,%hi(messageToPrint)
	sw	$5,%lo(messageToPrint)($3)
	lui	$3,%hi($LC15)
	addiu	$3,$3,%lo($LC15)
	lui	$4,%hi(messageString)
	sw	$3,%lo(messageString)($4)
	lui	$3,%hi(messageRoutine)
	sw	$0,%lo(messageRoutine)($3)
	lui	$3,%hi(messageNeedsInput)
	sw	$0,%lo(messageNeedsInput)($3)
	jr	$31
	sw	$5,%lo(menuactive)($2)

$L86:
	li	$5,34			# 0x22
	j	S_StartSound
	move	$4,$0

	.set	macro
	.set	reorder
	.end	M_EndGame
	.size	M_EndGame, .-M_EndGame
	.align	2
	.globl	M_VerifyNightmare
	.set	nomips16
	.set	nomicromips
	.ent	M_VerifyNightmare
	.type	M_VerifyNightmare, @function
M_VerifyNightmare:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(key_menu_confirm)
	lw	$2,%lo(key_menu_confirm)($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L94
	.set	at
	li	$6,1			# 0x1

	jr	$31
	nop

$L94:
	lui	$2,%hi(epi)
	lw	$5,%lo(epi)($2)
	addiu	$sp,$sp,-24
	addiu	$5,$5,1
	sw	$31,20($sp)
	jal	G_DeferedInitNew
	li	$4,4			# 0x4

	lw	$31,20($sp)
	lui	$2,%hi(menuactive)
	sw	$0,%lo(menuactive)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_VerifyNightmare
	.size	M_VerifyNightmare, .-M_VerifyNightmare
	.section	.rodata.str1.4
	.align	2
$LC17:
	.ascii	"are you sure? this skill level\012isn't even remotely fa"
	.ascii	"ir.\012\012press y or n.\000"
	.text
	.align	2
	.globl	M_ChooseSkill
	.set	nomips16
	.set	nomicromips
	.ent	M_ChooseSkill
	.type	M_ChooseSkill, @function
M_ChooseSkill:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,4			# 0x4
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L103
	.set	at
	li	$6,1			# 0x1

	lui	$2,%hi(epi)
	lw	$5,%lo(epi)($2)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	G_DeferedInitNew
	addiu	$5,$5,1

	lw	$31,20($sp)
	move	$3,$0
	lui	$2,%hi(menuactive)
	sw	$3,%lo(menuactive)($2)
	jr	$31
	addiu	$sp,$sp,24

$L103:
	lui	$2,%hi(menuactive)
	lw	$5,%lo(menuactive)($2)
	lui	$3,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	sw	$5,%lo(messageLastMenuActive)($3)
	lui	$3,%hi(messageToPrint)
	sw	$4,%lo(messageToPrint)($3)
	lui	$3,%hi($LC17)
	lui	$5,%hi(messageString)
	addiu	$3,$3,%lo($LC17)
	sw	$3,%lo(messageString)($5)
	lui	$3,%hi(M_VerifyNightmare)
	addiu	$3,$3,%lo(M_VerifyNightmare)
	lui	$5,%hi(messageRoutine)
	sw	$3,%lo(messageRoutine)($5)
	lui	$3,%hi(messageNeedsInput)
	sw	$4,%lo(messageNeedsInput)($3)
	li	$3,1			# 0x1
	jr	$31
	sw	$3,%lo(menuactive)($2)

	.set	macro
	.set	reorder
	.end	M_ChooseSkill
	.size	M_ChooseSkill, .-M_ChooseSkill
	.align	2
	.globl	M_EndGameResponse
	.set	nomips16
	.set	nomicromips
	.ent	M_EndGameResponse
	.type	M_EndGameResponse, @function
M_EndGameResponse:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(key_menu_confirm)
	lw	$2,%lo(key_menu_confirm)($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L106
	.set	at
	lui	$2,%hi(currentMenu)

	jr	$31
	nop

$L106:
	lui	$3,%hi(itemOn)
	lw	$2,%lo(currentMenu)($2)
	lhu	$3,%lo(itemOn)($3)
	sh	$3,20($2)
	lui	$2,%hi(menuactive)
	j	D_StartTitle
	sw	$0,%lo(menuactive)($2)

	.set	macro
	.set	reorder
	.end	M_EndGameResponse
	.size	M_EndGameResponse, .-M_EndGameResponse
	.section	.rodata.str1.4
	.align	2
$LC18:
	.ascii	"you can't start a new game\012while in a network game.\012"
	.ascii	"\012press a key.\000"
	.text
	.align	2
	.globl	M_NewGame
	.set	nomips16
	.set	nomicromips
	.ent	M_NewGame
	.type	M_NewGame, @function
M_NewGame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L119
	lui	$2,%hi(gamemode)

	lui	$2,%hi(demoplayback)
	lw	$2,%lo(demoplayback)($2)
	beq	$2,$0,$L118
	lui	$2,%hi(gamemode)

$L119:
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L112
	.set	at
	lui	$2,%hi(gameversion)

	lw	$3,%lo(gameversion)($2)
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L112
	.set	at
	lui	$2,%hi(EpiDef)

	addiu	$2,$2,%lo(EpiDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

$L112:
	lui	$2,%hi(NewDef)
	addiu	$2,$2,%lo(NewDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

$L118:
	lui	$3,%hi(menuactive)
	lw	$5,%lo(menuactive)($3)
	lui	$2,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	sw	$5,%lo(messageLastMenuActive)($2)
	lui	$2,%hi(messageToPrint)
	sw	$4,%lo(messageToPrint)($2)
	lui	$2,%hi($LC18)
	addiu	$2,$2,%lo($LC18)
	lui	$5,%hi(messageString)
	sw	$2,%lo(messageString)($5)
	lui	$2,%hi(messageRoutine)
	sw	$0,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	sw	$0,%lo(messageNeedsInput)($2)
	jr	$31
	sw	$4,%lo(menuactive)($3)

	.set	macro
	.set	reorder
	.end	M_NewGame
	.size	M_NewGame, .-M_NewGame
	.section	.rodata.str1.4
	.align	2
$LC19:
	.ascii	"this is the shareware version of doom.\012\012you need t"
	.ascii	"o order the entire trilogy.\012\012press a key.\000"
	.align	2
$LC20:
	.ascii	"M_Episode: 4th episode requires UltimateDOOM\012\000"
	.text
	.align	2
	.globl	M_Episode
	.set	nomips16
	.set	nomicromips
	.ent	M_Episode
	.type	M_Episode, @function
M_Episode:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$2,%lo(gamemode)($2)
	bne	$2,$0,$L121
	li	$3,1			# 0x1

	bne	$4,$0,$L132
	nop

	move	$4,$0
	lui	$2,%hi(NewDef)
$L133:
	addiu	$2,$2,%lo(NewDef)
	lui	$3,%hi(epi)
	lh	$5,20($2)
	sw	$4,%lo(epi)($3)
	lui	$3,%hi(itemOn)
	sh	$5,%lo(itemOn)($3)
	lui	$3,%hi(currentMenu)
	jr	$31
	sw	$2,%lo(currentMenu)($3)

$L121:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L133
	.set	at
	lui	$2,%hi(NewDef)

	slt	$2,$4,3
	bne	$2,$0,$L133
	lui	$2,%hi(NewDef)

	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC20)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	fprintf
	addiu	$5,$5,%lo($LC20)

	lui	$2,%hi(NewDef)
	addiu	$2,$2,%lo(NewDef)
	lh	$5,20($2)
	lui	$3,%hi(epi)
	move	$4,$0
	lw	$31,20($sp)
	sw	$4,%lo(epi)($3)
	lui	$3,%hi(itemOn)
	sh	$5,%lo(itemOn)($3)
	lui	$3,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($3)
	jr	$31
	addiu	$sp,$sp,24

$L132:
	lui	$4,%hi(menuactive)
	lw	$7,%lo(menuactive)($4)
	lui	$3,%hi(messageLastMenuActive)
	li	$6,1			# 0x1
	sw	$7,%lo(messageLastMenuActive)($3)
	lui	$3,%hi(messageToPrint)
	sw	$6,%lo(messageToPrint)($3)
	lui	$3,%hi($LC19)
	addiu	$3,$3,%lo($LC19)
	lui	$2,%hi(ReadDef1)
	lui	$7,%hi(messageString)
	addiu	$2,$2,%lo(ReadDef1)
	sw	$3,%lo(messageString)($7)
	lui	$3,%hi(messageRoutine)
	lh	$5,20($2)
	sw	$0,%lo(messageRoutine)($3)
	lui	$3,%hi(messageNeedsInput)
	sw	$0,%lo(messageNeedsInput)($3)
	lui	$3,%hi(itemOn)
	sh	$5,%lo(itemOn)($3)
	lui	$3,%hi(currentMenu)
	sw	$6,%lo(menuactive)($4)
	jr	$31
	sw	$2,%lo(currentMenu)($3)

	.set	macro
	.set	reorder
	.end	M_Episode
	.size	M_Episode, .-M_Episode
	.align	2
	.globl	M_ReadThis2
	.set	nomips16
	.set	nomicromips
	.ent	M_ReadThis2
	.type	M_ReadThis2, @function
M_ReadThis2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	sltu	$2,$2,5
	beq	$2,$0,$L137
	lui	$2,%hi(MainDef)

	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L135
	.set	at
	lui	$2,%hi(ReadDef2)

	addiu	$2,$2,%lo(ReadDef2)
	lh	$4,20($2)
	lui	$3,%hi(itemOn)
	sh	$4,%lo(itemOn)($3)
	lui	$3,%hi(currentMenu)
	jr	$31
	sw	$2,%lo(currentMenu)($3)

$L135:
	lui	$2,%hi(MainDef)
$L137:
	addiu	$2,$2,%lo(MainDef)
	lh	$4,20($2)
	lui	$3,%hi(itemOn)
	sh	$4,%lo(itemOn)($3)
	lui	$3,%hi(currentMenu)
	jr	$31
	sw	$2,%lo(currentMenu)($3)

	.set	macro
	.set	reorder
	.end	M_ReadThis2
	.size	M_ReadThis2, .-M_ReadThis2
	.align	2
	.globl	M_QuickLoadResponse
	.set	nomips16
	.set	nomicromips
	.ent	M_QuickLoadResponse
	.type	M_QuickLoadResponse, @function
M_QuickLoadResponse:
	.frame	$sp,280,$31		# vars= 256, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(key_menu_confirm)
	lw	$2,%lo(key_menu_confirm)($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L143
	.set	at
	nop

	jr	$31
	nop

$L143:
	lui	$2,%hi(quickSaveSlot)
	lw	$4,%lo(quickSaveSlot)($2)
	addiu	$sp,$sp,-280
	sw	$31,276($sp)
	jal	P_SaveGameFile
	nop

	move	$5,$2
	addiu	$4,$sp,16
	jal	M_StringCopy
	li	$6,256			# 0x100

	jal	G_LoadGame
	addiu	$4,$sp,16

	lw	$31,276($sp)
	lui	$2,%hi(menuactive)
	li	$5,24			# 0x18
	move	$4,$0
	addiu	$sp,$sp,280
	j	S_StartSound
	sw	$0,%lo(menuactive)($2)

	.set	macro
	.set	reorder
	.end	M_QuickLoadResponse
	.size	M_QuickLoadResponse, .-M_QuickLoadResponse
	.align	2
	.globl	M_QuickSaveResponse
	.set	nomips16
	.set	nomicromips
	.ent	M_QuickSaveResponse
	.type	M_QuickSaveResponse, @function
M_QuickSaveResponse:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(key_menu_confirm)
	lw	$2,%lo(key_menu_confirm)($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L150
	.set	at
	nop

	jr	$31
	nop

$L150:
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lui	$17,%hi(quickSaveSlot)
	sw	$16,20($sp)
	lw	$16,%lo(quickSaveSlot)($17)
	lui	$5,%hi(savegamestrings)
	sll	$2,$16,1
	addu	$2,$2,$16
	sll	$2,$2,3
	addiu	$5,$5,%lo(savegamestrings)
	addu	$5,$5,$2
	sw	$31,28($sp)
	jal	G_SaveGame
	move	$4,$16

	lw	$3,%lo(quickSaveSlot)($17)
	lui	$4,%hi(menuactive)
	li	$2,-2			# 0xfffffffffffffffe
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L151
	.set	at
	sw	$0,%lo(menuactive)($4)

$L146:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$5,24			# 0x18
	move	$4,$0
	j	S_StartSound
	addiu	$sp,$sp,32

$L151:
	b	$L146
	sw	$16,%lo(quickSaveSlot)($17)

	.set	macro
	.set	reorder
	.end	M_QuickSaveResponse
	.size	M_QuickSaveResponse, .-M_QuickSaveResponse
	.section	.rodata.str1.4
	.align	2
$LC21:
	.ascii	"rb\000"
	.text
	.align	2
	.globl	M_ReadSaveStrings
	.set	nomips16
	.set	nomicromips
	.ent	M_ReadSaveStrings
	.type	M_ReadSaveStrings, @function
M_ReadSaveStrings:
	.frame	$sp,304,$31		# vars= 256, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-304
	sw	$22,296($sp)
	sw	$20,288($sp)
	sw	$19,284($sp)
	sw	$18,280($sp)
	lui	$19,%hi(LoadMenu)
	lui	$18,%hi(savegamestrings)
	lui	$20,%hi($LC21)
	lui	$22,%hi($LC7)
	sw	$21,292($sp)
	sw	$17,276($sp)
	sw	$31,300($sp)
	sw	$16,272($sp)
	addiu	$19,$19,%lo(LoadMenu)
	addiu	$18,$18,%lo(savegamestrings)
	move	$17,$0
	addiu	$20,$20,%lo($LC21)
	addiu	$22,$22,%lo($LC7)
	b	$L155
	li	$21,6			# 0x6

$L153:
	jal	fread
	addiu	$17,$17,1

	jal	fclose
	move	$4,$16

	li	$2,1			# 0x1
	sh	$2,0($19)
	addiu	$18,$18,24
	.set	noat
	xor	$1,$17,$21
	beq	$1,$0,$L158
	.set	at
	addiu	$19,$19,20

$L155:
	jal	P_SaveGameFile
	move	$4,$17

	move	$5,$2
	li	$6,256			# 0x100
	jal	M_StringCopy
	addiu	$4,$sp,16

	move	$5,$20
	jal	fopen
	addiu	$4,$sp,16

	move	$16,$2
	move	$4,$18
	li	$6,24			# 0x18
	li	$5,1			# 0x1
	bne	$2,$0,$L153
	move	$7,$2

	jal	M_StringCopy
	move	$5,$22

	addiu	$17,$17,1
	move	$2,$0
	sh	$2,0($19)
	addiu	$18,$18,24
	.set	noat
	xor	$1,$17,$21
	bne	$1,$0,$L155
	.set	at
	addiu	$19,$19,20

$L158:
	lw	$31,300($sp)
	lw	$22,296($sp)
	lw	$21,292($sp)
	lw	$20,288($sp)
	lw	$19,284($sp)
	lw	$18,280($sp)
	lw	$17,276($sp)
	lw	$16,272($sp)
	jr	$31
	addiu	$sp,$sp,304

	.set	macro
	.set	reorder
	.end	M_ReadSaveStrings
	.size	M_ReadSaveStrings, .-M_ReadSaveStrings
	.section	.rodata.str1.4
	.align	2
$LC22:
	.ascii	"you can't do load while in a net game!\012\012press a ke"
	.ascii	"y.\000"
	.text
	.align	2
	.globl	M_LoadGame
	.set	nomips16
	.set	nomicromips
	.ent	M_LoadGame
	.type	M_LoadGame, @function
M_LoadGame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L160
	lui	$3,%hi(menuactive)

	lw	$5,%lo(menuactive)($3)
	lui	$2,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	sw	$5,%lo(messageLastMenuActive)($2)
	lui	$2,%hi(messageToPrint)
	sw	$4,%lo(messageToPrint)($2)
	lui	$2,%hi($LC22)
	addiu	$2,$2,%lo($LC22)
	lui	$5,%hi(messageString)
	sw	$2,%lo(messageString)($5)
	lui	$2,%hi(messageRoutine)
	sw	$0,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	sw	$0,%lo(messageNeedsInput)($2)
	jr	$31
	sw	$4,%lo(menuactive)($3)

$L160:
	lui	$2,%hi(LoadDef)
	addiu	$2,$2,%lo(LoadDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	j	M_ReadSaveStrings
	sh	$3,%lo(itemOn)($2)

	.set	macro
	.set	reorder
	.end	M_LoadGame
	.size	M_LoadGame, .-M_LoadGame
	.section	.rodata.str1.4
	.align	2
$LC23:
	.ascii	"you can't save if you aren't playing!\012\012press a key"
	.ascii	".\000"
	.text
	.align	2
	.globl	M_SaveGame
	.set	nomips16
	.set	nomicromips
	.ent	M_SaveGame
	.type	M_SaveGame, @function
M_SaveGame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(usergame)
	lw	$2,%lo(usergame)($2)
	beq	$2,$0,$L166
	lui	$2,%hi(gamestate)

	lw	$2,%lo(gamestate)($2)
	beq	$2,$0,$L167
	lui	$2,%hi(SaveDef)

	jr	$31
	nop

$L167:
	addiu	$2,$2,%lo(SaveDef)
	lhu	$3,20($2)
	lui	$4,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($4)
	lui	$2,%hi(itemOn)
	j	M_ReadSaveStrings
	sh	$3,%lo(itemOn)($2)

$L166:
	lui	$3,%hi(menuactive)
	lw	$5,%lo(menuactive)($3)
	lui	$2,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	sw	$5,%lo(messageLastMenuActive)($2)
	lui	$2,%hi(messageToPrint)
	sw	$4,%lo(messageToPrint)($2)
	lui	$2,%hi($LC23)
	addiu	$2,$2,%lo($LC23)
	lui	$5,%hi(messageString)
	sw	$2,%lo(messageString)($5)
	lui	$2,%hi(messageRoutine)
	sw	$0,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	sw	$0,%lo(messageNeedsInput)($2)
	jr	$31
	sw	$4,%lo(menuactive)($3)

	.set	macro
	.set	reorder
	.end	M_SaveGame
	.size	M_SaveGame, .-M_SaveGame
	.section	.rodata.str1.4
	.align	2
$LC24:
	.ascii	"M_LSLEFT\000"
	.align	2
$LC25:
	.ascii	"M_LSCNTR\000"
	.align	2
$LC26:
	.ascii	"M_LSRGHT\000"
	.text
	.align	2
	.globl	M_DrawSaveLoadBorder
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawSaveLoadBorder
	.type	M_DrawSaveLoadBorder, @function
M_DrawSaveLoadBorder:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$16,20($sp)
	move	$16,$4
	lui	$4,%hi($LC24)
	sw	$17,24($sp)
	addiu	$4,$4,%lo($LC24)
	addiu	$17,$5,7
	li	$5,8			# 0x8
	sw	$31,36($sp)
	sw	$19,32($sp)
	jal	W_CacheLumpName
	sw	$18,28($sp)

	move	$6,$2
	move	$5,$17
	addiu	$4,$16,-8
	jal	V_DrawPatchDirect
	lui	$18,%hi($LC25)

	addiu	$19,$16,192
	addiu	$18,$18,%lo($LC25)
$L171:
	move	$4,$18
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	move	$6,$2
	move	$4,$16
	move	$5,$17
	jal	V_DrawPatchDirect
	addiu	$16,$16,8

	.set	noat
	xor	$1,$19,$16
	bne	$1,$0,$L171
	.set	at
	lui	$4,%hi($LC26)

	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC26)

	lw	$31,36($sp)
	lw	$18,28($sp)
	lw	$16,20($sp)
	move	$5,$17
	move	$4,$19
	lw	$17,24($sp)
	lw	$19,32($sp)
	move	$6,$2
	j	V_DrawPatchDirect
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_DrawSaveLoadBorder
	.size	M_DrawSaveLoadBorder, .-M_DrawSaveLoadBorder
	.align	2
	.globl	M_DoSave
	.set	nomips16
	.set	nomicromips
	.ent	M_DoSave
	.type	M_DoSave, @function
M_DoSave:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$4,1
	addu	$2,$2,$4
	lui	$5,%hi(savegamestrings)
	sll	$2,$2,3
	addiu	$5,$5,%lo(savegamestrings)
	addiu	$sp,$sp,-24
	addu	$5,$5,$2
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	G_SaveGame
	move	$16,$4

	lui	$2,%hi(quickSaveSlot)
	lw	$4,%lo(quickSaveSlot)($2)
	lui	$5,%hi(menuactive)
	li	$3,-2			# 0xfffffffffffffffe
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L174
	.set	at
	sw	$0,%lo(menuactive)($5)

	sw	$16,%lo(quickSaveSlot)($2)
$L174:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_DoSave
	.size	M_DoSave, .-M_DoSave
	.section	.rodata.str1.4
	.align	2
$LC27:
	.ascii	"quicksave over your game named\012\012'%s'?\012\012press"
	.ascii	" y or n.\000"
	.text
	.align	2
	.globl	M_QuickSave
	.set	nomips16
	.set	nomicromips
	.ent	M_QuickSave
	.type	M_QuickSave, @function
M_QuickSave:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(usergame)
	lw	$2,%lo(usergame)($2)
	beq	$2,$0,$L188
	lui	$2,%hi(gamestate)

	lw	$2,%lo(gamestate)($2)
	bne	$2,$0,$L191
	nop

	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	lui	$16,%hi(quickSaveSlot)
	lw	$3,%lo(quickSaveSlot)($16)
	sw	$31,28($sp)
	sw	$18,24($sp)
	bltz	$3,$L189
	sw	$17,20($sp)

	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$7,%hi(savegamestrings)
	lui	$16,%hi(tempstring)
	sll	$2,$2,3
	addiu	$7,$7,%lo(savegamestrings)
	lui	$6,%hi($LC27)
	addiu	$4,$16,%lo(tempstring)
	li	$5,80			# 0x50
	addu	$7,$7,$2
	jal	snprintf
	addiu	$6,$6,%lo($LC27)

	lui	$4,%hi(menuactive)
	lw	$5,%lo(menuactive)($4)
	lui	$3,%hi(messageLastMenuActive)
	li	$2,1			# 0x1
	sw	$5,%lo(messageLastMenuActive)($3)
	lui	$3,%hi(messageToPrint)
	addiu	$16,$16,%lo(tempstring)
	sw	$2,%lo(messageToPrint)($3)
	lui	$3,%hi(messageString)
	sw	$16,%lo(messageString)($3)
	lui	$3,%hi(M_QuickSaveResponse)
	lw	$31,28($sp)
	addiu	$3,$3,%lo(M_QuickSaveResponse)
	lui	$5,%hi(messageRoutine)
	sw	$3,%lo(messageRoutine)($5)
	lui	$3,%hi(messageNeedsInput)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$2,%lo(messageNeedsInput)($3)
	sw	$2,%lo(menuactive)($4)
	jr	$31
	addiu	$sp,$sp,32

$L189:
	lui	$3,%hi(menuactive)
	lw	$2,%lo(menuactive)($3)
	bne	$2,$0,$L190
	lui	$2,%hi(MainDef)

	addiu	$2,$2,%lo(MainDef)
	lhu	$4,20($2)
	lui	$18,%hi(currentMenu)
	lui	$17,%hi(itemOn)
	li	$5,1			# 0x1
	sw	$5,%lo(menuactive)($3)
	sw	$2,%lo(currentMenu)($18)
	sh	$4,%lo(itemOn)($17)
$L181:
	jal	M_ReadSaveStrings
	nop

	lui	$2,%hi(SaveDef)
	addiu	$2,$2,%lo(SaveDef)
	lhu	$3,20($2)
	lw	$31,28($sp)
	sw	$2,%lo(currentMenu)($18)
	li	$2,-2			# 0xfffffffffffffffe
	lw	$18,24($sp)
	sh	$3,%lo(itemOn)($17)
	sw	$2,%lo(quickSaveSlot)($16)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L191:
	jr	$31
	nop

$L188:
	li	$5,34			# 0x22
	j	S_StartSound
	move	$4,$0

$L190:
	lui	$18,%hi(currentMenu)
	b	$L181
	lui	$17,%hi(itemOn)

	.set	macro
	.set	reorder
	.end	M_QuickSave
	.size	M_QuickSave, .-M_QuickSave
	.section	.rodata.str1.4
	.align	2
$LC28:
	.ascii	"you can't quickload during a netgame!\012\012press a key"
	.ascii	".\000"
	.align	2
$LC29:
	.ascii	"you haven't picked a quicksave slot yet!\012\012press a "
	.ascii	"key.\000"
	.align	2
$LC30:
	.ascii	"do you want to quickload the game named\012\012'%s'?\012"
	.ascii	"\012press y or n.\000"
	.text
	.align	2
	.globl	M_QuickLoad
	.set	nomips16
	.set	nomicromips
	.ent	M_QuickLoad
	.type	M_QuickLoad, @function
M_QuickLoad:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$3,%lo(netgame)($2)
	bne	$3,$0,$L199
	lui	$5,%hi(menuactive)

	lui	$2,%hi(quickSaveSlot)
	lw	$4,%lo(quickSaveSlot)($2)
	bltz	$4,$L200
	lw	$8,%lo(menuactive)($5)

	sll	$2,$4,1
	addiu	$sp,$sp,-24
	addu	$2,$2,$4
	lui	$7,%hi(savegamestrings)
	sll	$2,$2,3
	sw	$16,16($sp)
	addiu	$7,$7,%lo(savegamestrings)
	lui	$16,%hi(tempstring)
	lui	$6,%hi($LC30)
	addiu	$4,$16,%lo(tempstring)
	addu	$7,$7,$2
	addiu	$6,$6,%lo($LC30)
	sw	$31,20($sp)
	jal	snprintf
	li	$5,80			# 0x50

	lui	$5,%hi(menuactive)
	lw	$8,%lo(menuactive)($5)
	lui	$7,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	sw	$8,%lo(messageLastMenuActive)($7)
	lui	$7,%hi(messageToPrint)
	addiu	$2,$16,%lo(tempstring)
	lui	$6,%hi(M_QuickLoadResponse)
	sw	$4,%lo(messageToPrint)($7)
	lui	$7,%hi(messageString)
	lw	$31,20($sp)
	addiu	$6,$6,%lo(M_QuickLoadResponse)
	sw	$2,%lo(messageString)($7)
	lui	$2,%hi(messageRoutine)
	li	$3,1			# 0x1
	sw	$6,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	lw	$16,16($sp)
	sw	$3,%lo(messageNeedsInput)($2)
	sw	$4,%lo(menuactive)($5)
	jr	$31
	addiu	$sp,$sp,24

$L200:
	lui	$7,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	lui	$2,%hi($LC29)
	sw	$8,%lo(messageLastMenuActive)($7)
	lui	$7,%hi(messageToPrint)
	addiu	$2,$2,%lo($LC29)
	sw	$4,%lo(messageToPrint)($7)
	lui	$7,%hi(messageString)
	move	$6,$0
	sw	$2,%lo(messageString)($7)
	lui	$2,%hi(messageRoutine)
	sw	$6,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	sw	$3,%lo(messageNeedsInput)($2)
	jr	$31
	sw	$4,%lo(menuactive)($5)

$L199:
	lw	$8,%lo(menuactive)($5)
	lui	$7,%hi(messageLastMenuActive)
	li	$4,1			# 0x1
	lui	$2,%hi($LC28)
	sw	$8,%lo(messageLastMenuActive)($7)
	lui	$7,%hi(messageToPrint)
	addiu	$2,$2,%lo($LC28)
	sw	$4,%lo(messageToPrint)($7)
	lui	$7,%hi(messageString)
	move	$6,$0
	sw	$2,%lo(messageString)($7)
	lui	$2,%hi(messageRoutine)
	move	$3,$0
	sw	$6,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	sw	$3,%lo(messageNeedsInput)($2)
	jr	$31
	sw	$4,%lo(menuactive)($5)

	.set	macro
	.set	reorder
	.end	M_QuickLoad
	.size	M_QuickLoad, .-M_QuickLoad
	.section	.rodata.str1.4
	.align	2
$LC31:
	.ascii	"M_THERML\000"
	.align	2
$LC32:
	.ascii	"M_THERMM\000"
	.align	2
$LC33:
	.ascii	"M_THERMR\000"
	.align	2
$LC34:
	.ascii	"M_THERMO\000"
	.text
	.align	2
	.globl	M_DrawThermo
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawThermo
	.type	M_DrawThermo, @function
M_DrawThermo:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$21,40($sp)
	move	$21,$4
	lui	$4,%hi($LC31)
	sw	$18,28($sp)
	addiu	$4,$4,%lo($LC31)
	move	$18,$5
	li	$5,8			# 0x8
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$19,32($sp)
	move	$22,$7
	move	$19,$6
	sw	$20,36($sp)
	sw	$17,24($sp)
	jal	W_CacheLumpName
	sw	$16,20($sp)

	move	$6,$2
	move	$5,$18
	jal	V_DrawPatchDirect
	move	$4,$21

	blez	$19,$L204
	addiu	$23,$21,8

	lui	$20,%hi($LC32)
	move	$17,$23
	move	$16,$0
	addiu	$20,$20,%lo($LC32)
$L203:
	move	$4,$20
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	move	$6,$2
	move	$4,$17
	jal	V_DrawPatchDirect
	move	$5,$18

	move	$2,$16
	addiu	$16,$16,1
	.set	noat
	xor	$1,$19,$16
	bne	$1,$0,$L203
	.set	at
	addiu	$17,$17,8

	addiu	$21,$21,16
	sll	$2,$2,3
	addu	$21,$21,$2
$L202:
	lui	$4,%hi($LC33)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC33)

	move	$6,$2
	move	$5,$18
	jal	V_DrawPatchDirect
	move	$4,$21

	sll	$22,$22,3
	lui	$4,%hi($LC34)
	addu	$22,$22,$23
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC34)

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$5,$18
	move	$4,$22
	lw	$18,28($sp)
	lw	$22,44($sp)
	move	$6,$2
	j	V_DrawPatchDirect
	addiu	$sp,$sp,56

$L204:
	b	$L202
	move	$21,$23

	.set	macro
	.set	reorder
	.end	M_DrawThermo
	.size	M_DrawThermo, .-M_DrawThermo
	.section	.rodata.str1.4
	.align	2
$LC35:
	.ascii	"M_SVOL\000"
	.text
	.align	2
	.globl	M_DrawSound
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawSound
	.type	M_DrawSound, @function
M_DrawSound:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC35)
	addiu	$sp,$sp,-24
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC35)
	sw	$31,20($sp)
	jal	W_CacheLumpName
	sw	$16,16($sp)

	lui	$16,%hi(SoundDef)
	addiu	$16,$16,%lo(SoundDef)
	move	$6,$2
	li	$5,38			# 0x26
	jal	V_DrawPatchDirect
	li	$4,60			# 0x3c

	lh	$5,18($16)
	lui	$2,%hi(sfxVolume)
	lw	$7,%lo(sfxVolume)($2)
	lh	$4,16($16)
	li	$6,16			# 0x10
	jal	M_DrawThermo
	addiu	$5,$5,16

	lh	$5,18($16)
	lui	$2,%hi(musicVolume)
	lh	$4,16($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	lw	$7,%lo(musicVolume)($2)
	li	$6,16			# 0x10
	addiu	$5,$5,48
	j	M_DrawThermo
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_DrawSound
	.size	M_DrawSound, .-M_DrawSound
	.section	.rodata.str1.4
	.align	2
$LC36:
	.ascii	"M_OPTTTL\000"
	.text
	.align	2
	.globl	M_DrawOptions
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawOptions
	.type	M_DrawOptions, @function
M_DrawOptions:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC36)
	addiu	$sp,$sp,-32
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC36)
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	jal	W_CacheLumpName
	sw	$16,16($sp)

	move	$6,$2
	li	$5,15			# 0xf
	jal	V_DrawPatchDirect
	li	$4,108			# 0x6c

	lui	$2,%hi(detailLevel)
	lw	$2,%lo(detailLevel)($2)
	lui	$3,%hi(detailNames)
	addiu	$3,$3,%lo(detailNames)
	lui	$16,%hi(OptionsDef)
	sll	$2,$2,2
	addiu	$16,$16,%lo(OptionsDef)
	addu	$2,$2,$3
	lh	$17,16($16)
	lh	$18,18($16)
	lw	$4,0($2)
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	addiu	$17,$17,175
	addiu	$18,$18,32
	move	$6,$2
	move	$5,$18
	jal	V_DrawPatchDirect
	move	$4,$17

	lui	$2,%hi(showMessages)
	lw	$2,%lo(showMessages)($2)
	lui	$3,%hi(msgNames)
	addiu	$3,$3,%lo(msgNames)
	sll	$2,$2,2
	addu	$2,$2,$3
	lh	$17,16($16)
	lh	$18,18($16)
	lw	$4,0($2)
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	addiu	$17,$17,120
	addiu	$18,$18,16
	move	$6,$2
	move	$5,$18
	jal	V_DrawPatchDirect
	move	$4,$17

	lh	$5,18($16)
	lui	$2,%hi(mouseSensitivity)
	lw	$7,%lo(mouseSensitivity)($2)
	lh	$4,16($16)
	li	$6,10			# 0xa
	jal	M_DrawThermo
	addiu	$5,$5,96

	lh	$5,18($16)
	lui	$2,%hi(screenSize)
	lh	$4,16($16)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	lw	$7,%lo(screenSize)($2)
	li	$6,9			# 0x9
	addiu	$5,$5,64
	j	M_DrawThermo
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_DrawOptions
	.size	M_DrawOptions, .-M_DrawOptions
	.section	.rodata.str1.4
	.align	2
$LC37:
	.ascii	"M_CELL1\000"
	.text
	.align	2
	.globl	M_DrawEmptyCell
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawEmptyCell
	.type	M_DrawEmptyCell, @function
M_DrawEmptyCell:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	lh	$16,18($4)
	sw	$17,24($sp)
	sll	$5,$5,4
	lh	$17,16($4)
	addu	$16,$16,$5
	lui	$4,%hi($LC37)
	addiu	$17,$17,-10
	addiu	$16,$16,-1
	li	$5,8			# 0x8
	sw	$31,28($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC37)

	lw	$31,28($sp)
	move	$5,$16
	move	$4,$17
	lw	$16,20($sp)
	lw	$17,24($sp)
	move	$6,$2
	j	V_DrawPatchDirect
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_DrawEmptyCell
	.size	M_DrawEmptyCell, .-M_DrawEmptyCell
	.section	.rodata.str1.4
	.align	2
$LC38:
	.ascii	"M_CELL2\000"
	.text
	.align	2
	.globl	M_DrawSelCell
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawSelCell
	.type	M_DrawSelCell, @function
M_DrawSelCell:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	lh	$16,18($4)
	sw	$17,24($sp)
	sll	$5,$5,4
	lh	$17,16($4)
	addu	$16,$16,$5
	lui	$4,%hi($LC38)
	addiu	$17,$17,-10
	addiu	$16,$16,-1
	li	$5,8			# 0x8
	sw	$31,28($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC38)

	lw	$31,28($sp)
	move	$5,$16
	move	$4,$17
	lw	$16,20($sp)
	lw	$17,24($sp)
	move	$6,$2
	j	V_DrawPatchDirect
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_DrawSelCell
	.size	M_DrawSelCell, .-M_DrawSelCell
	.align	2
	.globl	M_StartMessage
	.set	nomips16
	.set	nomicromips
	.ent	M_StartMessage
	.type	M_StartMessage, @function
M_StartMessage:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(menuactive)
	lw	$8,%lo(menuactive)($2)
	lui	$7,%hi(messageLastMenuActive)
	li	$3,1			# 0x1
	sw	$8,%lo(messageLastMenuActive)($7)
	lui	$7,%hi(messageToPrint)
	sw	$3,%lo(messageToPrint)($7)
	lui	$7,%hi(messageString)
	sw	$4,%lo(messageString)($7)
	lui	$4,%hi(messageRoutine)
	sw	$5,%lo(messageRoutine)($4)
	lui	$4,%hi(messageNeedsInput)
	sw	$6,%lo(messageNeedsInput)($4)
	jr	$31
	sw	$3,%lo(menuactive)($2)

	.set	macro
	.set	reorder
	.end	M_StartMessage
	.size	M_StartMessage, .-M_StartMessage
	.align	2
	.globl	M_StopMessage
	.set	nomips16
	.set	nomicromips
	.ent	M_StopMessage
	.type	M_StopMessage, @function
M_StopMessage:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(messageLastMenuActive)
	lw	$3,%lo(messageLastMenuActive)($2)
	lui	$2,%hi(menuactive)
	sw	$3,%lo(menuactive)($2)
	lui	$2,%hi(messageToPrint)
	jr	$31
	sw	$0,%lo(messageToPrint)($2)

	.set	macro
	.set	reorder
	.end	M_StopMessage
	.size	M_StopMessage, .-M_StopMessage
	.align	2
	.globl	M_StringWidth
	.set	nomips16
	.set	nomicromips
	.ent	M_StringWidth
	.type	M_StringWidth, @function
M_StringWidth:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	move	$17,$4
	move	$4,$17
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$16,20($sp)
	sw	$31,36($sp)
	jal	strlen
	move	$16,$0

	lui	$19,%hi(hu_font)
	sltu	$2,$16,$2
	move	$18,$0
	addiu	$19,$19,%lo(hu_font)
	beq	$2,$0,$L223
	addu	$3,$17,$16

$L221:
	jal	toupper
	lb	$4,0($3)

	addiu	$2,$2,-33
	sll	$3,$2,2
	sltu	$2,$2,63
	bne	$2,$0,$L219
	addu	$3,$3,$19

	addiu	$18,$18,4
	addiu	$16,$16,1
$L224:
	jal	strlen
	move	$4,$17

	sltu	$2,$16,$2
	bne	$2,$0,$L221
	addu	$3,$17,$16

$L223:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$18
	lw	$18,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L219:
	lw	$3,0($3)
	addiu	$16,$16,1
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	b	$L224
	addu	$18,$18,$2

	.set	macro
	.set	reorder
	.end	M_StringWidth
	.size	M_StringWidth, .-M_StringWidth
	.align	2
	.globl	M_StringHeight
	.set	nomips16
	.set	nomicromips
	.ent	M_StringHeight
	.type	M_StringHeight, @function
M_StringHeight:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(hu_font)
	addiu	$sp,$sp,-40
	lw	$2,%lo(hu_font)($2)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,36($sp)
	sw	$18,24($sp)
	lbu	$18,3($2)
	lbu	$2,2($2)
	sll	$18,$18,8
	or	$18,$18,$2
	sll	$18,$18,16
	sra	$18,$18,16
	move	$17,$4
	move	$20,$18
	move	$16,$0
	li	$19,10			# 0xa
$L226:
	jal	strlen
	move	$4,$17

	sltu	$2,$16,$2
	beq	$2,$0,$L230
	addu	$3,$17,$16

$L228:
	lb	$2,0($3)
	.set	noat
	xor	$1,$2,$19
	bne	$1,$0,$L226
	.set	at
	addiu	$16,$16,1

	jal	strlen
	move	$4,$17

	sltu	$2,$16,$2
	addu	$20,$20,$18
	bne	$2,$0,$L228
	addu	$3,$17,$16

$L230:
	lw	$31,36($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$20
	lw	$20,32($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_StringHeight
	.size	M_StringHeight, .-M_StringHeight
	.align	2
	.globl	M_WriteText
	.set	nomips16
	.set	nomicromips
	.ent	M_WriteText
	.type	M_WriteText, @function
M_WriteText:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$2,0($6)
	beq	$2,$0,$L249
	nop

	addiu	$sp,$sp,-48
	sw	$19,32($sp)
	lui	$19,%hi(hu_font)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,44($sp)
	move	$20,$4
	move	$17,$5
	addiu	$21,$6,1
	move	$16,$4
	li	$18,10			# 0xa
	b	$L233
	addiu	$19,$19,%lo(hu_font)

$L234:
	jal	toupper
	nop

	addiu	$2,$2,-33
	sll	$3,$2,2
	sltu	$2,$2,63
	addu	$3,$3,$19
	move	$4,$16
	beq	$2,$0,$L247
	move	$5,$17

	lw	$6,0($3)
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$16,$2,$16
	slt	$2,$16,321
	beq	$2,$0,$L248
	lw	$31,44($sp)

	jal	V_DrawPatchDirect
	nop

$L235:
	lb	$2,0($21)
	beq	$2,$0,$L231
	addiu	$21,$21,1

$L233:
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L234
	.set	at
	move	$4,$2

	lb	$2,0($21)
	addiu	$17,$17,12
	move	$16,$20
	bne	$2,$0,$L233
	addiu	$21,$21,1

$L231:
	lw	$31,44($sp)
$L248:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L247:
	b	$L235
	addiu	$16,$16,4

$L249:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_WriteText
	.size	M_WriteText, .-M_WriteText
	.section	.rodata.str1.4
	.align	2
$LC39:
	.ascii	"M_LOADG\000"
	.text
	.align	2
	.globl	M_DrawLoad
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawLoad
	.type	M_DrawLoad, @function
M_DrawLoad:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC39)
	addiu	$sp,$sp,-40
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC39)
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	jal	W_CacheLumpName
	sw	$16,20($sp)

	move	$6,$2
	li	$5,28			# 0x1c
	li	$4,72			# 0x48
	lui	$18,%hi(savegamestrings)
	jal	V_DrawPatchDirect
	lui	$17,%hi(LoadDef)

	addiu	$18,$18,%lo(savegamestrings)
	move	$16,$0
	addiu	$17,$17,%lo(LoadDef)
	li	$19,96			# 0x60
$L251:
	lh	$5,18($17)
	lh	$4,16($17)
	jal	M_DrawSaveLoadBorder
	addu	$5,$5,$16

	lh	$5,18($17)
	lh	$4,16($17)
	move	$6,$18
	addu	$5,$5,$16
	jal	M_WriteText
	addiu	$16,$16,16

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L251
	.set	at
	addiu	$18,$18,24

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_DrawLoad
	.size	M_DrawLoad, .-M_DrawLoad
	.section	.rodata.str1.4
	.align	2
$LC40:
	.ascii	"M_SAVEG\000"
	.align	2
$LC41:
	.ascii	"_\000"
	.text
	.align	2
	.globl	M_DrawSave
	.set	nomips16
	.set	nomicromips
	.ent	M_DrawSave
	.type	M_DrawSave, @function
M_DrawSave:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC40)
	addiu	$sp,$sp,-40
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC40)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	jal	W_CacheLumpName
	lui	$20,%hi(savegamestrings)

	move	$6,$2
	li	$5,28			# 0x1c
	li	$4,72			# 0x48
	addiu	$20,$20,%lo(savegamestrings)
	jal	V_DrawPatchDirect
	lui	$17,%hi(LoadDef)

	move	$18,$20
	move	$16,$0
	addiu	$17,$17,%lo(LoadDef)
	li	$19,96			# 0x60
$L255:
	lh	$5,18($17)
	lh	$4,16($17)
	jal	M_DrawSaveLoadBorder
	addu	$5,$5,$16

	lh	$5,18($17)
	lh	$4,16($17)
	move	$6,$18
	addu	$5,$5,$16
	jal	M_WriteText
	addiu	$16,$16,16

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L255
	.set	at
	addiu	$18,$18,24

	lui	$2,%hi(saveStringEnter)
	lw	$2,%lo(saveStringEnter)($2)
	bne	$2,$0,$L259
	lw	$31,36($sp)

	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L259:
	lui	$16,%hi(saveSlot)
	lw	$2,%lo(saveSlot)($16)
	sll	$4,$2,1
	addu	$4,$4,$2
	sll	$4,$4,3
	jal	M_StringWidth
	addu	$4,$20,$4

	lw	$3,%lo(saveSlot)($16)
	lh	$5,18($17)
	lh	$4,16($17)
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sll	$3,$3,4
	lui	$6,%hi($LC41)
	addiu	$6,$6,%lo($LC41)
	addu	$5,$3,$5
	addu	$4,$4,$2
	j	M_WriteText
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_DrawSave
	.size	M_DrawSave, .-M_DrawSave
	.section	.rodata.str1.4
	.align	2
$LC42:
	.ascii	"PLAYPAL\000"
	.text
	.align	2
	.globl	M_Responder
	.set	nomips16
	.set	nomicromips
	.ent	M_Responder
	.type	M_Responder, @function
M_Responder:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(testcontrols)
	lw	$3,%lo(testcontrols)($2)
	addiu	$sp,$sp,-40
	lw	$2,0($4)
	sw	$16,16($sp)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	beq	$3,$0,$L261
	move	$16,$4

	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L262
	.set	at
	nop

	bne	$2,$0,$L265
	lui	$3,%hi(key_menu_activate)

	lw	$2,4($4)
	lw	$3,%lo(key_menu_activate)($3)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L262
	.set	at
	lui	$3,%hi(key_menu_quit)

	lw	$3,%lo(key_menu_quit)($3)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L262
	.set	at
	nop

$L265:
	move	$2,$0
$L260:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L261:
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L403
	.set	at
	li	$3,3			# 0x3

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L404
	.set	at
	nop

$L269:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L405
	.set	at
	nop

$L278:
	bne	$2,$0,$L260
	move	$2,$0

	lw	$17,4($16)
	lw	$4,8($16)
$L277:
	li	$2,-1			# 0xffffffffffffffff
$L445:
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L265
	.set	at
	lui	$2,%hi(saveStringEnter)

	lw	$3,%lo(saveStringEnter)($2)
	bne	$3,$0,$L406
	lui	$16,%hi(messageToPrint)

	lw	$3,%lo(messageToPrint)($16)
	beq	$3,$0,$L293
	lui	$2,%hi(devparm)

	lui	$2,%hi(messageNeedsInput)
	lw	$2,%lo(messageNeedsInput)($2)
	beq	$2,$0,$L294
	li	$2,32			# 0x20

	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L294
	.set	at
	li	$2,27			# 0x1b

	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L294
	.set	at
	lui	$2,%hi(key_menu_confirm)

	lw	$2,%lo(key_menu_confirm)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L294
	.set	at
	lui	$2,%hi(key_menu_abort)

	lw	$2,%lo(key_menu_abort)($2)
	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L260
	.set	at
	move	$2,$0

$L294:
	lui	$2,%hi(messageLastMenuActive)
	lw	$3,%lo(messageLastMenuActive)($2)
	lui	$2,%hi(messageRoutine)
	lw	$2,%lo(messageRoutine)($2)
	lui	$18,%hi(menuactive)
	sw	$3,%lo(menuactive)($18)
	beq	$2,$0,$L295
	sw	$0,%lo(messageToPrint)($16)

	jalr	$2
	move	$4,$17

$L295:
	li	$5,24			# 0x18
	move	$4,$0
	jal	S_StartSound
	sw	$0,%lo(menuactive)($18)

$L266:
	b	$L260
	li	$2,1			# 0x1

$L262:
	jal	I_Quit
	nop

	b	$L260
	li	$2,1			# 0x1

$L406:
	li	$3,27			# 0x1b
	.set	noat
	xor	$1,$17,$3
	beq	$1,$0,$L286
	.set	at
	li	$3,127			# 0x7f

	.set	noat
	xor	$1,$17,$3
	beq	$1,$0,$L287
	.set	at
	li	$3,13			# 0xd

	.set	noat
	xor	$1,$17,$3
	beq	$1,$0,$L407
	.set	at
	lui	$3,%hi(saveSlot)

	lui	$2,%hi(vanilla_keyboard_mapping)
	lw	$2,%lo(vanilla_keyboard_mapping)($2)
	jal	toupper
	movn	$4,$17,$2

	move	$16,$2
	addiu	$2,$2,-32
	sltu	$2,$2,64
	beq	$2,$0,$L260
	li	$2,1			# 0x1

	lui	$17,%hi(saveCharIndex)
	lw	$2,%lo(saveCharIndex)($17)
	slt	$2,$2,23
	beq	$2,$0,$L260
	li	$2,1			# 0x1

	lui	$19,%hi(saveSlot)
	lw	$2,%lo(saveSlot)($19)
	lui	$18,%hi(savegamestrings)
	sll	$4,$2,1
	addu	$4,$4,$2
	sll	$4,$4,3
	addiu	$18,$18,%lo(savegamestrings)
	jal	M_StringWidth
	addu	$4,$18,$4

	slt	$2,$2,176
	beq	$2,$0,$L266
	lw	$4,%lo(saveSlot)($19)

	lw	$3,%lo(saveCharIndex)($17)
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,3
	addiu	$4,$3,1
	addu	$2,$2,$18
	addu	$3,$2,$3
	addu	$2,$2,$4
	sb	$16,0($3)
	sw	$4,%lo(saveCharIndex)($17)
	sb	$0,0($2)
	b	$L260
	li	$2,1			# 0x1

$L403:
	lui	$2,%hi(menuactive)
	lw	$2,%lo(menuactive)($2)
	beq	$2,$0,$L444
	li	$5,23			# 0x17

	lui	$2,%hi(messageToPrint)
	lw	$2,%lo(messageToPrint)($2)
	beq	$2,$0,$L444
	nop

	lui	$2,%hi(messageRoutine)
	lw	$3,%lo(messageRoutine)($2)
	lui	$2,%hi(M_QuitResponse)
	addiu	$2,$2,%lo(M_QuitResponse)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L444
	.set	at
	nop

	jal	M_QuitResponse.part.0
	nop

	b	$L260
	li	$2,1			# 0x1

$L268:
$L444:
	jal	S_StartSound
	move	$4,$0

	jal	M_QuitDOOM
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L404:
	jal	I_GetTime
	lui	$18,%hi(joywait.7)

	lw	$3,%lo(joywait.7)($18)
	slt	$2,$3,$2
	beq	$2,$0,$L408
	nop

	lw	$2,12($16)
	bltz	$2,$L409
	nop

	bne	$2,$0,$L410
	lui	$2,%hi(key_menu_down)

	li	$17,-1			# 0xffffffffffffffff
$L272:
	lw	$2,8($16)
	bltz	$2,$L411
	nop

	bne	$2,$0,$L412
	lui	$2,%hi(key_menu_right)

$L274:
	lw	$2,4($16)
	andi	$3,$2,0x1
	bne	$3,$0,$L413
	nop

$L275:
	andi	$2,$2,0x2
	bne	$2,$0,$L414
	lui	$2,%hi(key_menu_back)

$L276:
	lui	$2,%hi(joybmenu)
	lw	$2,%lo(joybmenu)($2)
	bltz	$2,$L277
	move	$4,$0

	lw	$4,4($16)
	sra	$4,$4,$2
	andi	$4,$4,0x1
	beq	$4,$0,$L445
	li	$2,-1			# 0xffffffffffffffff

	lui	$2,%hi(key_menu_activate)
	jal	I_GetTime
	lw	$17,%lo(key_menu_activate)($2)

	addiu	$2,$2,5
	sw	$2,%lo(joywait.7)($18)
	b	$L277
	move	$4,$0

$L293:
	lw	$2,%lo(devparm)($2)
	beq	$2,$0,$L296
	lui	$2,%hi(key_menu_help)

	lw	$2,%lo(key_menu_help)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L297
	.set	at
	nop

$L296:
	beq	$17,$0,$L446
	lui	$18,%hi(menuactive)

	lui	$2,%hi(key_menu_screenshot)
	lw	$2,%lo(key_menu_screenshot)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L297
	.set	at
	nop

$L446:
	lw	$2,%lo(menuactive)($18)
	bne	$2,$0,$L299
	lui	$2,%hi(key_menu_down)

	lui	$2,%hi(key_menu_decscreen)
	lw	$2,%lo(key_menu_decscreen)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L415
	.set	at
	lui	$2,%hi(key_menu_incscreen)

	lw	$2,%lo(key_menu_incscreen)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L416
	.set	at
	lui	$2,%hi(key_menu_help)

	lw	$2,%lo(key_menu_help)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L417
	.set	at
	lui	$2,%hi(key_menu_save)

	lw	$2,%lo(key_menu_save)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L418
	.set	at
	lui	$2,%hi(MainDef)

	lui	$2,%hi(key_menu_load)
	lw	$2,%lo(key_menu_load)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L419
	.set	at
	lui	$2,%hi(key_menu_volume)

	lw	$2,%lo(key_menu_volume)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L420
	.set	at
	li	$2,1			# 0x1

	lui	$2,%hi(key_menu_detail)
	lw	$2,%lo(key_menu_detail)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L421
	.set	at
	nop

	lui	$2,%hi(key_menu_qsave)
	lw	$2,%lo(key_menu_qsave)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L422
	.set	at
	li	$5,23			# 0x17

	lui	$2,%hi(key_menu_endgame)
	lw	$2,%lo(key_menu_endgame)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L423
	.set	at
	nop

	lui	$2,%hi(key_menu_messages)
	lw	$2,%lo(key_menu_messages)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L424
	.set	at
	nop

	lui	$2,%hi(key_menu_qload)
	lw	$2,%lo(key_menu_qload)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L425
	.set	at
	nop

	lui	$2,%hi(key_menu_quit)
	lw	$2,%lo(key_menu_quit)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L268
	.set	at
	nop

	lui	$2,%hi(key_menu_gamma)
	lw	$2,%lo(key_menu_gamma)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L426
	.set	at
	lui	$7,%hi(usegamma)

	lui	$2,%hi(key_menu_activate)
	lw	$2,%lo(key_menu_activate)($2)
	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L265
	.set	at
	lui	$2,%hi(MainDef)

	addiu	$2,$2,%lo(MainDef)
	li	$6,1			# 0x1
	lhu	$3,20($2)
	sw	$6,%lo(menuactive)($18)
	lui	$6,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($6)
	li	$5,23			# 0x17
	lui	$2,%hi(itemOn)
	move	$4,$0
	jal	S_StartSound
	sh	$3,%lo(itemOn)($2)

	b	$L260
	li	$2,1			# 0x1

$L405:
	jal	I_GetTime
	lui	$19,%hi(mousewait.6)

	lw	$3,%lo(mousewait.6)($19)
	slt	$2,$3,$2
	beq	$2,$0,$L427
	lui	$18,%hi(mousey.5)

	lui	$20,%hi(lasty.4)
	lw	$4,%lo(mousey.5)($18)
	lw	$2,12($16)
	lw	$3,%lo(lasty.4)($20)
	addu	$2,$2,$4
	addiu	$4,$3,-30
	slt	$4,$2,$4
	bne	$4,$0,$L428
	sw	$2,%lo(mousey.5)($18)

	addiu	$3,$3,30
	slt	$2,$3,$2
	bne	$2,$0,$L429
	lui	$2,%hi(key_menu_up)

	li	$17,-1			# 0xffffffffffffffff
$L281:
	lui	$18,%hi(mousex.3)
	lui	$20,%hi(lastx.2)
	lw	$4,%lo(mousex.3)($18)
	lw	$2,8($16)
	lw	$3,%lo(lastx.2)($20)
	addu	$2,$2,$4
	addiu	$4,$3,-30
	slt	$4,$2,$4
	bne	$4,$0,$L430
	sw	$2,%lo(mousex.3)($18)

	addiu	$3,$3,30
	slt	$2,$3,$2
	bne	$2,$0,$L431
	lui	$2,%hi(key_menu_right)

$L283:
	lw	$4,4($16)
	andi	$2,$4,0x1
	bne	$2,$0,$L432
	lui	$2,%hi(key_menu_forward)

$L284:
	andi	$4,$4,0x2
	beq	$4,$0,$L445
	li	$2,-1			# 0xffffffffffffffff

	lui	$2,%hi(key_menu_back)
	jal	I_GetTime
	lw	$17,%lo(key_menu_back)($2)

	addiu	$2,$2,15
	sw	$2,%lo(mousewait.6)($19)
	b	$L277
	move	$4,$0

$L408:
	b	$L269
	lw	$2,0($16)

$L427:
	b	$L278
	lw	$2,0($16)

$L299:
	lw	$2,%lo(key_menu_down)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L433
	.set	at
	lui	$16,%hi(currentMenu)

	lui	$2,%hi(key_menu_up)
	lw	$2,%lo(key_menu_up)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L434
	.set	at
	nop

	lui	$2,%hi(key_menu_left)
	lw	$2,%lo(key_menu_left)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L435
	.set	at
	lui	$2,%hi(key_menu_right)

	lw	$2,%lo(key_menu_right)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L436
	.set	at
	lui	$2,%hi(key_menu_forward)

	lw	$2,%lo(key_menu_forward)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L437
	.set	at
	lui	$2,%hi(key_menu_activate)

	lw	$2,%lo(key_menu_activate)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L438
	.set	at
	lui	$2,%hi(currentMenu)

	lui	$2,%hi(key_menu_back)
	lw	$2,%lo(key_menu_back)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L439
	.set	at
	lui	$6,%hi(currentMenu)

	bne	$4,$0,$L447
	lui	$2,%hi(currentMenu)

	li	$2,255			# 0xff
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L330
	.set	at
	li	$2,186			# 0xba

	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L330
	.set	at
	addiu	$2,$17,-197

	sltu	$2,$2,2
	beq	$2,$0,$L260
	move	$2,$0

$L330:
	lui	$2,%hi(currentMenu)
$L447:
	lw	$10,%lo(currentMenu)($2)
	lui	$18,%hi(itemOn)
	lh	$9,%lo(itemOn)($18)
	lh	$7,0($10)
	addiu	$8,$9,1
	slt	$2,$8,$7
	beq	$2,$0,$L331
	move	$6,$8

	sll	$5,$9,2
	addu	$5,$5,$9
	lw	$2,8($10)
	sll	$5,$5,2
	addiu	$5,$5,36
	b	$L333
	addu	$2,$2,$5

$L332:
	addiu	$6,$6,1
	.set	noat
	xor	$1,$7,$6
	beq	$1,$0,$L331
	.set	at
	nop

$L333:
	lb	$5,0($2)
	.set	noat
	xor	$1,$5,$4
	bne	$1,$0,$L332
	.set	at
	addiu	$2,$2,20

	li	$5,19			# 0x13
	move	$4,$0
	jal	S_StartSound
	sh	$6,%lo(itemOn)($18)

	b	$L260
	li	$2,1			# 0x1

$L297:
	jal	G_ScreenShot
	nop

	b	$L260
	li	$2,1			# 0x1

$L287:
	lui	$4,%hi(saveCharIndex)
	lw	$3,%lo(saveCharIndex)($4)
	blez	$3,$L266
	addiu	$3,$3,-1

	lui	$2,%hi(saveSlot)
	lw	$5,%lo(saveSlot)($2)
	sll	$2,$5,1
	addu	$2,$2,$5
	lui	$5,%hi(savegamestrings)
	sll	$2,$2,3
	addiu	$5,$5,%lo(savegamestrings)
	addu	$2,$2,$5
	addu	$2,$2,$3
	sw	$3,%lo(saveCharIndex)($4)
	sb	$0,0($2)
	b	$L260
	li	$2,1			# 0x1

$L286:
	lui	$3,%hi(saveSlot)
	lw	$4,%lo(saveSlot)($3)
	lui	$5,%hi(saveOldString)
	sll	$3,$4,1
	addu	$3,$3,$4
	lui	$4,%hi(savegamestrings)
	sll	$3,$3,3
	addiu	$4,$4,%lo(savegamestrings)
	li	$6,24			# 0x18
	addiu	$5,$5,%lo(saveOldString)
	addu	$4,$4,$3
	jal	M_StringCopy
	sw	$0,%lo(saveStringEnter)($2)

	b	$L260
	li	$2,1			# 0x1

$L407:
	lw	$16,%lo(saveSlot)($3)
	lui	$3,%hi(savegamestrings)
	sll	$5,$16,1
	addu	$5,$5,$16
	addiu	$3,$3,%lo(savegamestrings)
	sll	$5,$5,3
	addu	$5,$5,$3
	lb	$3,0($5)
	beq	$3,$0,$L266
	sw	$0,%lo(saveStringEnter)($2)

	jal	G_SaveGame
	move	$4,$16

	lui	$2,%hi(quickSaveSlot)
	lw	$4,%lo(quickSaveSlot)($2)
	lui	$5,%hi(menuactive)
	li	$3,-2			# 0xfffffffffffffffe
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L266
	.set	at
	sw	$0,%lo(menuactive)($5)

	sw	$16,%lo(quickSaveSlot)($2)
	b	$L260
	li	$2,1			# 0x1

$L414:
	jal	I_GetTime
	lw	$17,%lo(key_menu_back)($2)

	addiu	$2,$2,5
	b	$L276
	sw	$2,%lo(joywait.7)($18)

$L413:
	lui	$2,%hi(key_menu_forward)
	jal	I_GetTime
	lw	$17,%lo(key_menu_forward)($2)

	addiu	$3,$2,5
	sw	$3,%lo(joywait.7)($18)
	b	$L275
	lw	$2,4($16)

$L432:
	jal	I_GetTime
	lw	$17,%lo(key_menu_forward)($2)

	addiu	$2,$2,15
	lw	$4,4($16)
	b	$L284
	sw	$2,%lo(mousewait.6)($19)

$L430:
	lui	$2,%hi(key_menu_left)
	jal	I_GetTime
	lw	$17,%lo(key_menu_left)($2)

	lw	$3,%lo(lastx.2)($20)
	addiu	$4,$2,5
	addiu	$2,$3,-30
	sw	$4,%lo(mousewait.6)($19)
	sw	$2,%lo(lastx.2)($20)
	b	$L283
	sw	$2,%lo(mousex.3)($18)

$L428:
	lui	$2,%hi(key_menu_down)
	jal	I_GetTime
	lw	$17,%lo(key_menu_down)($2)

	lw	$3,%lo(lasty.4)($20)
	addiu	$4,$2,5
	addiu	$2,$3,-30
	sw	$4,%lo(mousewait.6)($19)
	sw	$2,%lo(lasty.4)($20)
	b	$L281
	sw	$2,%lo(mousey.5)($18)

$L411:
	lui	$2,%hi(key_menu_left)
	jal	I_GetTime
	lw	$17,%lo(key_menu_left)($2)

	addiu	$2,$2,2
	b	$L274
	sw	$2,%lo(joywait.7)($18)

$L409:
	lui	$2,%hi(key_menu_up)
	jal	I_GetTime
	lw	$17,%lo(key_menu_up)($2)

	addiu	$2,$2,5
	b	$L272
	sw	$2,%lo(joywait.7)($18)

$L415:
	lui	$2,%hi(automapactive)
	lui	$3,%hi(chat_on)
	lw	$2,%lo(automapactive)($2)
	lw	$3,%lo(chat_on)($3)
	or	$2,$2,$3
	bne	$2,$0,$L260
	move	$2,$0

	lui	$3,%hi(screenSize)
	lw	$2,%lo(screenSize)($3)
	lui	$5,%hi(screenblocks)
	blez	$2,$L301
	lw	$4,%lo(screenblocks)($5)

	addiu	$4,$4,-1
	addiu	$2,$2,-1
	sw	$4,%lo(screenblocks)($5)
	sw	$2,%lo(screenSize)($3)
$L301:
	lui	$2,%hi(detailLevel)
	jal	R_SetViewSize
	lw	$5,%lo(detailLevel)($2)

	li	$5,22			# 0x16
	jal	S_StartSound
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L412:
	jal	I_GetTime
	lw	$17,%lo(key_menu_right)($2)

	addiu	$2,$2,2
	b	$L274
	sw	$2,%lo(joywait.7)($18)

$L410:
	jal	I_GetTime
	lw	$17,%lo(key_menu_down)($2)

	addiu	$2,$2,5
	b	$L272
	sw	$2,%lo(joywait.7)($18)

$L431:
	jal	I_GetTime
	lw	$17,%lo(key_menu_right)($2)

	lw	$3,%lo(lastx.2)($20)
	addiu	$4,$2,5
	addiu	$2,$3,30
	sw	$4,%lo(mousewait.6)($19)
	sw	$2,%lo(lastx.2)($20)
	b	$L283
	sw	$2,%lo(mousex.3)($18)

$L429:
	jal	I_GetTime
	lw	$17,%lo(key_menu_up)($2)

	lw	$3,%lo(lasty.4)($20)
	addiu	$4,$2,5
	addiu	$2,$3,30
	sw	$4,%lo(mousewait.6)($19)
	sw	$2,%lo(lasty.4)($20)
	b	$L281
	sw	$2,%lo(mousey.5)($18)

$L416:
	lui	$2,%hi(automapactive)
	lui	$3,%hi(chat_on)
	lw	$2,%lo(automapactive)($2)
	lw	$3,%lo(chat_on)($3)
	or	$2,$2,$3
	bne	$2,$0,$L260
	move	$2,$0

	lui	$5,%hi(screenSize)
	lw	$3,%lo(screenSize)($5)
	slt	$2,$3,8
	bne	$2,$0,$L401
	addiu	$3,$3,1

	lui	$2,%hi(screenblocks)
$L303:
	lui	$3,%hi(detailLevel)
	lw	$4,%lo(screenblocks)($2)
	jal	R_SetViewSize
	lw	$5,%lo(detailLevel)($3)

	li	$5,22			# 0x16
	jal	S_StartSound
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L433:
	lui	$18,%hi(itemOn)
	lh	$2,%lo(itemOn)($18)
	lw	$5,%lo(currentMenu)($16)
	b	$L319
	li	$17,-1			# 0xffffffffffffffff

$L440:
	sll	$2,$4,16
	sra	$2,$2,16
	li	$5,19			# 0x13
$L448:
	move	$4,$0
	jal	S_StartSound
	sh	$2,%lo(itemOn)($18)

	lh	$2,%lo(itemOn)($18)
	lw	$5,%lo(currentMenu)($16)
	sll	$3,$2,2
	lw	$4,8($5)
	addu	$3,$3,$2
	sll	$3,$3,2
	addu	$3,$4,$3
	lh	$3,0($3)
	.set	noat
	xor	$1,$3,$17
	bne	$1,$0,$L266
	.set	at
	nop

$L319:
	lh	$3,0($5)
	addiu	$4,$2,1
	addiu	$3,$3,-1
	slt	$2,$2,$3
	bne	$2,$0,$L440
	move	$2,$0

	b	$L448
	li	$5,19			# 0x13

$L434:
	lui	$18,%hi(itemOn)
	lh	$3,%lo(itemOn)($18)
	b	$L323
	li	$17,-1			# 0xffffffffffffffff

$L441:
	lw	$2,%lo(currentMenu)($16)
	lhu	$2,0($2)
	addiu	$2,$2,-1
	sll	$2,$2,16
	sra	$2,$2,16
$L322:
	move	$4,$0
	li	$5,19			# 0x13
	jal	S_StartSound
	sh	$2,%lo(itemOn)($18)

	lh	$3,%lo(itemOn)($18)
	lw	$4,%lo(currentMenu)($16)
	sll	$2,$3,2
	lw	$4,8($4)
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$4,$2
	lh	$2,0($2)
	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L266
	.set	at
	nop

$L323:
	beq	$3,$0,$L441
	addiu	$2,$3,-1

	sll	$2,$2,16
	b	$L322
	sra	$2,$2,16

$L435:
	lui	$16,%hi(itemOn)
	lh	$4,%lo(itemOn)($16)
	lui	$17,%hi(currentMenu)
	lw	$3,%lo(currentMenu)($17)
	sll	$2,$4,2
	lw	$3,8($3)
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$3,12($2)
	beq	$3,$0,$L266
	nop

	lh	$3,0($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L266
	.set	at
	li	$5,22			# 0x16

	jal	S_StartSound
	move	$4,$0

	lh	$2,%lo(itemOn)($16)
	li	$4,20			# 0x14
	multu	$2,$4
	mflo	$5
	lw	$3,%lo(currentMenu)($17)
	lw	$3,8($3)
	addu	$2,$5,$3
	lw	$2,12($2)
	jalr	$2
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L331:
	bltz	$9,$L265
	nop

	lw	$2,8($10)
	b	$L335
	addiu	$2,$2,16

$L334:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$8
	beq	$1,$0,$L265
	.set	at
	nop

$L335:
	lb	$5,0($2)
	.set	noat
	xor	$1,$5,$4
	bne	$1,$0,$L334
	.set	at
	addiu	$2,$2,20

	li	$5,19			# 0x13
	move	$4,$0
	jal	S_StartSound
	sh	$3,%lo(itemOn)($18)

	b	$L260
	li	$2,1			# 0x1

$L436:
	lui	$16,%hi(itemOn)
	lh	$4,%lo(itemOn)($16)
	lui	$17,%hi(currentMenu)
	lw	$3,%lo(currentMenu)($17)
	sll	$2,$4,2
	lw	$3,8($3)
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$3,12($2)
	beq	$3,$0,$L266
	nop

	lh	$3,0($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L266
	.set	at
	li	$5,22			# 0x16

	jal	S_StartSound
	move	$4,$0

	lh	$2,%lo(itemOn)($16)
	li	$4,20			# 0x14
	multu	$2,$4
	mflo	$5
	lw	$3,%lo(currentMenu)($17)
	lw	$3,8($3)
	addu	$2,$5,$3
	lw	$2,12($2)
	jalr	$2
	li	$4,1			# 0x1

	b	$L260
	li	$2,1			# 0x1

$L417:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$4,1			# 0x1
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L442
	.set	at
	sw	$4,%lo(menuactive)($18)

	lui	$2,%hi(ReadDef1)
	addiu	$2,$2,%lo(ReadDef1)
$L305:
	lui	$3,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($3)
	li	$5,23			# 0x17
	lui	$2,%hi(itemOn)
	move	$4,$0
	jal	S_StartSound
	sh	$0,%lo(itemOn)($2)

	b	$L260
	li	$2,1			# 0x1

$L418:
	addiu	$2,$2,%lo(MainDef)
	li	$6,1			# 0x1
	lhu	$3,20($2)
	sw	$6,%lo(menuactive)($18)
	lui	$6,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($6)
	li	$5,23			# 0x17
	lui	$2,%hi(itemOn)
	move	$4,$0
	jal	S_StartSound
	sh	$3,%lo(itemOn)($2)

	jal	M_SaveGame
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L437:
	lui	$2,%hi(itemOn)
	lh	$4,%lo(itemOn)($2)
	lui	$2,%hi(currentMenu)
	lw	$5,%lo(currentMenu)($2)
	sll	$2,$4,2
	lw	$3,8($5)
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$3,12($2)
	beq	$3,$0,$L266
	nop

	lh	$2,0($2)
	beq	$2,$0,$L266
	li	$6,2			# 0x2

	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L443
	.set	at
	sh	$4,20($5)

	jalr	$3
	nop

	li	$5,1			# 0x1
	jal	S_StartSound
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L419:
	lui	$2,%hi(MainDef)
	addiu	$2,$2,%lo(MainDef)
	lhu	$3,20($2)
	li	$17,1			# 0x1
	lui	$20,%hi(currentMenu)
	lui	$19,%hi(itemOn)
	li	$5,23			# 0x17
	move	$4,$0
	sw	$2,%lo(currentMenu)($20)
	sw	$17,%lo(menuactive)($18)
	jal	S_StartSound
	sh	$3,%lo(itemOn)($19)

	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L308
	lw	$3,%lo(menuactive)($18)

	lui	$2,%hi(messageLastMenuActive)
	sw	$3,%lo(messageLastMenuActive)($2)
	lui	$2,%hi($LC22)
	addiu	$2,$2,%lo($LC22)
	lui	$3,%hi(messageString)
	sw	$2,%lo(messageString)($3)
	lui	$2,%hi(messageRoutine)
	sw	$0,%lo(messageRoutine)($2)
	lui	$2,%hi(messageNeedsInput)
	sw	$0,%lo(messageNeedsInput)($2)
	sw	$17,%lo(messageToPrint)($16)
	sw	$17,%lo(menuactive)($18)
	b	$L260
	li	$2,1			# 0x1

$L420:
	sw	$2,%lo(menuactive)($18)
	lui	$2,%hi(SoundDef)
	lui	$3,%hi(currentMenu)
	addiu	$2,$2,%lo(SoundDef)
	sw	$2,%lo(currentMenu)($3)
	li	$5,23			# 0x17
	lui	$2,%hi(itemOn)
	move	$4,$0
	jal	S_StartSound
	sh	$0,%lo(itemOn)($2)

	b	$L260
	li	$2,1			# 0x1

$L439:
	lw	$4,%lo(currentMenu)($6)
	lui	$3,%hi(itemOn)
	lhu	$5,%lo(itemOn)($3)
	lw	$2,4($4)
	beq	$2,$0,$L266
	sh	$5,20($4)

	lhu	$7,20($2)
	li	$5,23			# 0x17
	move	$4,$0
	sw	$2,%lo(currentMenu)($6)
	jal	S_StartSound
	sh	$7,%lo(itemOn)($3)

	b	$L260
	li	$2,1			# 0x1

$L421:
	jal	M_ChangeDetail
	move	$4,$0

	li	$5,23			# 0x17
	jal	S_StartSound
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L422:
	jal	S_StartSound
	move	$4,$0

	jal	M_QuickSave
	nop

	b	$L260
	li	$2,1			# 0x1

$L426:
	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(usegamma)($7)
	lw	$2,%lo(consoleplayer)($2)
	li	$5,288			# 0x120
	multu	$2,$5
	mflo	$6
	addiu	$3,$3,1
	slt	$4,$3,5
	movz	$3,$0,$4
	lui	$4,%hi(players)
	addiu	$4,$4,%lo(players)
	addu	$2,$6,$4
	li	$6,26			# 0x1a
	multu	$6,$3
	mflo	$5
	lui	$4,%hi(gammamsg)
	addiu	$4,$4,%lo(gammamsg)
	addu	$6,$5,$4
	lui	$4,%hi($LC42)
	li	$5,8			# 0x8
	addiu	$4,$4,%lo($LC42)
	sw	$3,%lo(usegamma)($7)
	jal	W_CacheLumpName
	sw	$6,224($2)

	jal	I_SetPalette
	move	$4,$2

	b	$L260
	li	$2,1			# 0x1

$L423:
	jal	S_StartSound
	move	$4,$0

	jal	M_EndGame
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L401:
	lui	$2,%hi(screenblocks)
	lw	$4,%lo(screenblocks)($2)
	addiu	$4,$4,1
	sw	$4,%lo(screenblocks)($2)
	b	$L303
	sw	$3,%lo(screenSize)($5)

$L438:
	lui	$3,%hi(itemOn)
	lw	$2,%lo(currentMenu)($2)
	lhu	$3,%lo(itemOn)($3)
	li	$5,24			# 0x18
	sh	$3,20($2)
	move	$4,$0
	jal	S_StartSound
	sw	$0,%lo(menuactive)($18)

	b	$L260
	li	$2,1			# 0x1

$L425:
	jal	S_StartSound
	move	$4,$0

	jal	M_QuickLoad
	nop

	b	$L260
	li	$2,1			# 0x1

$L424:
	jal	M_ChangeMessages
	move	$4,$0

	li	$5,23			# 0x17
	jal	S_StartSound
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

$L308:
	lui	$2,%hi(LoadDef)
	addiu	$2,$2,%lo(LoadDef)
	lhu	$3,20($2)
	sw	$2,%lo(currentMenu)($20)
	jal	M_ReadSaveStrings
	sh	$3,%lo(itemOn)($19)

	b	$L260
	li	$2,1			# 0x1

$L442:
	lui	$2,%hi(ReadDef2)
	b	$L305
	addiu	$2,$2,%lo(ReadDef2)

$L443:
	jalr	$3
	li	$4,1			# 0x1

	li	$5,22			# 0x16
	jal	S_StartSound
	move	$4,$0

	b	$L260
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	M_Responder
	.size	M_Responder, .-M_Responder
	.align	2
	.globl	M_StartControlPanel
	.set	nomips16
	.set	nomicromips
	.ent	M_StartControlPanel
	.type	M_StartControlPanel, @function
M_StartControlPanel:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(menuactive)
	lw	$2,%lo(menuactive)($3)
	bne	$2,$0,$L451
	lui	$2,%hi(MainDef)

	addiu	$2,$2,%lo(MainDef)
	li	$5,1			# 0x1
	lhu	$4,20($2)
	sw	$5,%lo(menuactive)($3)
	lui	$3,%hi(currentMenu)
	sw	$2,%lo(currentMenu)($3)
	lui	$2,%hi(itemOn)
	sh	$4,%lo(itemOn)($2)
$L451:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_StartControlPanel
	.size	M_StartControlPanel, .-M_StartControlPanel
	.align	2
	.globl	M_Drawer
	.set	nomips16
	.set	nomicromips
	.ent	M_Drawer
	.type	M_Drawer, @function
M_Drawer:
	.frame	$sp,136,$31		# vars= 80, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(messageToPrint)
	lw	$2,%lo(messageToPrint)($2)
	addiu	$sp,$sp,-136
	lui	$3,%hi(inhelpscreens)
	sw	$0,%lo(inhelpscreens)($3)
	sw	$31,132($sp)
	sw	$23,128($sp)
	sw	$22,124($sp)
	sw	$21,120($sp)
	sw	$20,116($sp)
	sw	$19,112($sp)
	sw	$18,108($sp)
	sw	$17,104($sp)
	bne	$2,$0,$L486
	sw	$16,100($sp)

	lui	$2,%hi(menuactive)
	lw	$2,%lo(menuactive)($2)
	beq	$2,$0,$L452
	lui	$22,%hi(currentMenu)

	lw	$2,%lo(currentMenu)($22)
	lw	$3,12($2)
	beq	$3,$0,$L464
	nop

	jalr	$3
	nop

	lw	$2,%lo(currentMenu)($22)
$L464:
	lh	$19,16($2)
	lh	$16,18($2)
	lh	$23,0($2)
	lui	$21,%hi(x.0)
	lui	$20,%hi(y.1)
	sh	$19,%lo(x.0)($21)
	beq	$23,$0,$L465
	sh	$16,%lo(y.1)($20)

	move	$18,$0
	b	$L467
	move	$17,$0

$L466:
	addiu	$16,$16,16
	sll	$16,$16,16
	sra	$16,$16,16
	.set	noat
	xor	$1,$23,$17
	beq	$1,$0,$L487
	.set	at
	sh	$16,%lo(y.1)($20)

$L467:
	lw	$4,8($2)
	addiu	$17,$17,1
	addu	$4,$4,$18
	lb	$3,2($4)
	beq	$3,$0,$L466
	addiu	$18,$18,20

	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,2

	move	$6,$2
	move	$5,$16
	jal	V_DrawPatchDirect
	move	$4,$19

	lh	$16,%lo(y.1)($20)
	lh	$19,%lo(x.0)($21)
	addiu	$16,$16,16
	sll	$16,$16,16
	sra	$16,$16,16
	lw	$2,%lo(currentMenu)($22)
	.set	noat
	xor	$1,$23,$17
	bne	$1,$0,$L467
	.set	at
	sh	$16,%lo(y.1)($20)

$L487:
	lh	$16,18($2)
$L465:
	lui	$2,%hi(whichSkull)
	lh	$3,%lo(whichSkull)($2)
	lui	$4,%hi(skullName)
	lui	$2,%hi(itemOn)
	lh	$2,%lo(itemOn)($2)
	addiu	$4,$4,%lo(skullName)
	sll	$3,$3,2
	addu	$3,$3,$4
	lw	$4,0($3)
	sll	$2,$2,4
	addiu	$16,$16,-5
	addu	$16,$2,$16
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	lw	$31,132($sp)
	lw	$23,128($sp)
	lw	$22,124($sp)
	lw	$21,120($sp)
	lw	$20,116($sp)
	lw	$18,108($sp)
	lw	$17,104($sp)
	move	$5,$16
	addiu	$4,$19,-32
	lw	$16,100($sp)
	lw	$19,112($sp)
	move	$6,$2
	j	V_DrawPatchDirect
	addiu	$sp,$sp,136

$L489:
	srl	$2,$20,31
	addu	$2,$2,$20
	lw	$5,%lo(messageString)($18)
	sra	$2,$2,1
	subu	$2,$0,$2
	lb	$3,0($5)
	lui	$20,%hi(y.1)
	addiu	$2,$2,100
	beq	$3,$0,$L452
	sh	$2,%lo(y.1)($20)

	move	$23,$0
	move	$4,$5
	lui	$21,%hi(x.0)
	li	$19,10			# 0xa
$L457:
	b	$L463
	move	$16,$0

$L462:
	addu	$2,$5,$17
	lb	$2,0($2)
	.set	noat
	xor	$1,$2,$19
	beq	$1,$0,$L488
	.set	at
	addu	$4,$5,$23

	addiu	$16,$16,1
$L463:
	jal	strlen
	addu	$17,$16,$23

	sltu	$2,$16,$2
	bne	$2,$0,$L462
	lw	$5,%lo(messageString)($18)

	addu	$5,$5,$23
	li	$6,80			# 0x50
	jal	M_StringCopy
	addiu	$4,$sp,16

	jal	strlen
	addiu	$4,$sp,16

	addu	$23,$23,$2
$L461:
	jal	M_StringWidth
	addiu	$4,$sp,16

	srl	$3,$2,31
	addu	$2,$3,$2
	sra	$2,$2,1
	subu	$2,$0,$2
	addiu	$4,$2,160
	lh	$5,%lo(y.1)($20)
	sll	$4,$4,16
	sra	$4,$4,16
	addiu	$6,$sp,16
	jal	M_WriteText
	sh	$4,%lo(x.0)($21)

	lw	$3,%lo(hu_font)($22)
	lw	$5,%lo(messageString)($18)
	lbu	$2,3($3)
	lbu	$3,2($3)
	lhu	$6,%lo(y.1)($20)
	sll	$2,$2,8
	addu	$4,$5,$23
	or	$2,$2,$3
	lb	$3,0($4)
	addu	$2,$2,$6
	bne	$3,$0,$L457
	sh	$2,%lo(y.1)($20)

$L452:
	lw	$31,132($sp)
	lw	$23,128($sp)
	lw	$22,124($sp)
	lw	$21,120($sp)
	lw	$20,116($sp)
	lw	$19,112($sp)
	lw	$18,108($sp)
	lw	$17,104($sp)
	lw	$16,100($sp)
	jr	$31
	addiu	$sp,$sp,136

$L486:
	lui	$22,%hi(hu_font)
	lw	$2,%lo(hu_font)($22)
	lui	$18,%hi(messageString)
	lbu	$19,3($2)
	lbu	$2,2($2)
	sll	$19,$19,8
	or	$19,$19,$2
	sll	$19,$19,16
	sra	$19,$19,16
	lw	$17,%lo(messageString)($18)
	move	$20,$19
	move	$16,$0
	li	$21,10			# 0xa
$L454:
	jal	strlen
	move	$4,$17

	sltu	$2,$16,$2
	beq	$2,$0,$L489
	addu	$3,$17,$16

	lb	$2,0($3)
	.set	noat
	xor	$1,$2,$21
	bne	$1,$0,$L454
	.set	at
	addiu	$16,$16,1

	b	$L454
	addu	$20,$20,$19

$L488:
	move	$5,$4
	li	$6,80			# 0x50
	jal	M_StringCopy
	addiu	$4,$sp,16

	sltu	$2,$16,80
	beq	$2,$0,$L460
	addiu	$2,$sp,16

	addu	$16,$2,$16
	sb	$0,0($16)
$L460:
	b	$L461
	addiu	$23,$17,1

	.set	macro
	.set	reorder
	.end	M_Drawer
	.size	M_Drawer, .-M_Drawer
	.align	2
	.globl	M_ClearMenus
	.set	nomips16
	.set	nomicromips
	.ent	M_ClearMenus
	.type	M_ClearMenus, @function
M_ClearMenus:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(menuactive)
	jr	$31
	sw	$0,%lo(menuactive)($2)

	.set	macro
	.set	reorder
	.end	M_ClearMenus
	.size	M_ClearMenus, .-M_ClearMenus
	.align	2
	.globl	M_SetupNextMenu
	.set	nomips16
	.set	nomicromips
	.ent	M_SetupNextMenu
	.type	M_SetupNextMenu, @function
M_SetupNextMenu:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(currentMenu)
	lhu	$3,20($4)
	sw	$4,%lo(currentMenu)($2)
	lui	$2,%hi(itemOn)
	jr	$31
	sh	$3,%lo(itemOn)($2)

	.set	macro
	.set	reorder
	.end	M_SetupNextMenu
	.size	M_SetupNextMenu, .-M_SetupNextMenu
	.align	2
	.globl	M_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	M_Ticker
	.type	M_Ticker, @function
M_Ticker:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(skullAnimCounter)
	lhu	$2,%lo(skullAnimCounter)($3)
	addiu	$2,$2,-1
	sll	$2,$2,16
	sra	$2,$2,16
	blez	$2,$L494
	sh	$2,%lo(skullAnimCounter)($3)

	jr	$31
	nop

$L494:
	lui	$4,%hi(whichSkull)
	lhu	$2,%lo(whichSkull)($4)
	xori	$2,$2,0x1
	sh	$2,%lo(whichSkull)($4)
	li	$2,8			# 0x8
	jr	$31
	sh	$2,%lo(skullAnimCounter)($3)

	.set	macro
	.set	reorder
	.end	M_Ticker
	.size	M_Ticker, .-M_Ticker
	.align	2
	.globl	M_Init
	.set	nomips16
	.set	nomicromips
	.ent	M_Init
	.type	M_Init, @function
M_Init:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(MainDef)
	addiu	$3,$4,%lo(MainDef)
	lui	$7,%hi(currentMenu)
	lhu	$8,20($3)
	sw	$3,%lo(currentMenu)($7)
	lui	$7,%hi(menuactive)
	lui	$2,%hi(screenblocks)
	sw	$0,%lo(menuactive)($7)
	lui	$7,%hi(itemOn)
	sh	$8,%lo(itemOn)($7)
	lw	$2,%lo(screenblocks)($2)
	lui	$7,%hi(whichSkull)
	sh	$0,%lo(whichSkull)($7)
	li	$8,10			# 0xa
	lui	$7,%hi(skullAnimCounter)
	addiu	$2,$2,-3
	sh	$8,%lo(skullAnimCounter)($7)
	lui	$7,%hi(screenSize)
	sw	$2,%lo(screenSize)($7)
	lui	$2,%hi(messageToPrint)
	lui	$5,%hi(gamemode)
	sw	$0,%lo(messageToPrint)($2)
	lui	$2,%hi(messageString)
	lw	$6,%lo(gamemode)($5)
	sw	$0,%lo(messageString)($2)
	lui	$2,%hi(messageLastMenuActive)
	sw	$0,%lo(messageLastMenuActive)($2)
	li	$7,-1			# 0xffffffffffffffff
	lui	$2,%hi(quickSaveSlot)
	li	$5,2			# 0x2
	.set	noat
	xor	$1,$6,$5
	bne	$1,$0,$L498
	.set	at
	sw	$7,%lo(quickSaveSlot)($2)

	lui	$2,%hi(MainMenu)
	addiu	$2,$2,%lo(MainMenu)
	lhu	$6,%lo(MainDef)($4)
	lhu	$5,18($3)
	lw	$11,100($2)
	lw	$10,104($2)
	lw	$9,108($2)
	lw	$8,112($2)
	lw	$7,116($2)
	addiu	$6,$6,-1
	addiu	$5,$5,8
	sw	$11,80($2)
	sw	$10,84($2)
	sw	$9,88($2)
	sw	$8,92($2)
	sw	$7,96($2)
	lui	$2,%hi(NewDef+4)
	sh	$6,%lo(MainDef)($4)
	sh	$5,18($3)
	sw	$3,%lo(NewDef+4)($2)
$L498:
	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	sltu	$2,$2,6
	beq	$2,$0,$L500
	lui	$3,%hi(EpiDef)

	lhu	$2,%lo(EpiDef)($3)
	addiu	$2,$2,-1
	sh	$2,%lo(EpiDef)($3)
$L500:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	M_Init
	.size	M_Init, .-M_Init
	.local	x.0
	.comm	x.0,2,2
	.local	y.1
	.comm	y.1,2,2
	.local	lastx.2
	.comm	lastx.2,4,4
	.local	mousex.3
	.comm	mousex.3,4,4
	.local	lasty.4
	.comm	lasty.4,4,4
	.local	mousey.5
	.comm	mousey.5,4,4
	.local	mousewait.6
	.comm	mousewait.6,4,4
	.local	joywait.7
	.comm	joywait.7,4,4
	.globl	quitsounds2
	.data
	.align	2
	.type	quitsounds2, @object
	.size	quitsounds2, 32
quitsounds2:
	.word	80
	.word	93
	.word	95
	.word	31
	.word	56
	.word	72
	.word	78
	.word	52
	.globl	quitsounds
	.align	2
	.type	quitsounds, @object
	.size	quitsounds, 32
quitsounds:
	.word	57
	.word	26
	.word	27
	.word	31
	.word	35
	.word	36
	.word	38
	.word	52
	.section	.rodata.str1.4
	.align	2
$LC43:
	.ascii	"M_MSGOFF\000"
	.align	2
$LC44:
	.ascii	"M_MSGON\000"
	.rdata
	.align	2
	.type	msgNames, @object
	.size	msgNames, 8
msgNames:
	.word	$LC43
	.word	$LC44
	.section	.rodata.str1.4
	.align	2
$LC45:
	.ascii	"M_GDHIGH\000"
	.align	2
$LC46:
	.ascii	"M_GDLOW\000"
	.rdata
	.align	2
	.type	detailNames, @object
	.size	detailNames, 8
detailNames:
	.word	$LC45
	.word	$LC46
	.globl	epi
	.section	.bss,"aw",@nobits
	.align	2
	.type	epi, @object
	.size	epi, 4
epi:
	.space	4
	.globl	tempstring
	.align	2
	.type	tempstring, @object
	.size	tempstring, 80
tempstring:
	.space	80
	.globl	SaveDef
	.data
	.align	2
	.type	SaveDef, @object
	.size	SaveDef, 24
SaveDef:
	.half	6
	.space	2
	.word	MainDef
	.word	SaveMenu
	.word	M_DrawSave
	.half	80
	.half	54
	.half	0
	.space	2
	.globl	SaveMenu
	.align	2
	.type	SaveMenu, @object
	.size	SaveMenu, 120
SaveMenu:
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_SaveSelect
	.byte	49
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_SaveSelect
	.byte	50
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_SaveSelect
	.byte	51
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_SaveSelect
	.byte	52
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_SaveSelect
	.byte	53
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_SaveSelect
	.byte	54
	.space	3
	.globl	LoadDef
	.align	2
	.type	LoadDef, @object
	.size	LoadDef, 24
LoadDef:
	.half	6
	.space	2
	.word	MainDef
	.word	LoadMenu
	.word	M_DrawLoad
	.half	80
	.half	54
	.half	0
	.space	2
	.globl	LoadMenu
	.align	2
	.type	LoadMenu, @object
	.size	LoadMenu, 120
LoadMenu:
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_LoadSelect
	.byte	49
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_LoadSelect
	.byte	50
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_LoadSelect
	.byte	51
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_LoadSelect
	.byte	52
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_LoadSelect
	.byte	53
	.space	3
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_LoadSelect
	.byte	54
	.space	3
	.globl	load_e
	.section	.bss
	.align	2
	.type	load_e, @object
	.size	load_e, 4
load_e:
	.space	4
	.globl	SoundDef
	.data
	.align	2
	.type	SoundDef, @object
	.size	SoundDef, 24
SoundDef:
	.half	4
	.space	2
	.word	OptionsDef
	.word	SoundMenu
	.word	M_DrawSound
	.half	80
	.half	64
	.half	0
	.space	2
	.globl	SoundMenu
	.align	2
	.type	SoundMenu, @object
	.size	SoundMenu, 80
SoundMenu:
	.half	2
	.ascii	"M_SFXVOL\000"
	.space	1
	.word	M_SfxVol
	.byte	115
	.space	3
	.half	-1
	.ascii	"\000"
	.space	9
	.word	0
	.byte	0
	.space	3
	.half	2
	.ascii	"M_MUSVOL\000"
	.space	1
	.word	M_MusicVol
	.byte	109
	.space	3
	.half	-1
	.ascii	"\000"
	.space	9
	.word	0
	.byte	0
	.space	3
	.globl	sound_e
	.section	.bss
	.align	2
	.type	sound_e, @object
	.size	sound_e, 4
sound_e:
	.space	4
	.globl	ReadDef2
	.data
	.align	2
	.type	ReadDef2, @object
	.size	ReadDef2, 24
ReadDef2:
	.half	1
	.space	2
	.word	ReadDef1
	.word	ReadMenu2
	.word	M_DrawReadThis2
	.half	330
	.half	175
	.half	0
	.space	2
	.globl	ReadMenu2
	.align	2
	.type	ReadMenu2, @object
	.size	ReadMenu2, 20
ReadMenu2:
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_FinishReadThis
	.byte	0
	.space	3
	.globl	read_e2
	.section	.bss
	.align	2
	.type	read_e2, @object
	.size	read_e2, 4
read_e2:
	.space	4
	.globl	ReadDef1
	.data
	.align	2
	.type	ReadDef1, @object
	.size	ReadDef1, 24
ReadDef1:
	.half	1
	.space	2
	.word	MainDef
	.word	ReadMenu1
	.word	M_DrawReadThis1
	.half	280
	.half	185
	.half	0
	.space	2
	.globl	ReadMenu1
	.align	2
	.type	ReadMenu1, @object
	.size	ReadMenu1, 20
ReadMenu1:
	.half	1
	.ascii	"\000"
	.space	9
	.word	M_ReadThis2
	.byte	0
	.space	3
	.globl	read_e
	.section	.bss
	.align	2
	.type	read_e, @object
	.size	read_e, 4
read_e:
	.space	4
	.globl	OptionsDef
	.data
	.align	2
	.type	OptionsDef, @object
	.size	OptionsDef, 24
OptionsDef:
	.half	8
	.space	2
	.word	MainDef
	.word	OptionsMenu
	.word	M_DrawOptions
	.half	60
	.half	37
	.half	0
	.space	2
	.globl	OptionsMenu
	.align	2
	.type	OptionsMenu, @object
	.size	OptionsMenu, 160
OptionsMenu:
	.half	1
	.ascii	"M_ENDGAM\000"
	.space	1
	.word	M_EndGame
	.byte	101
	.space	3
	.half	1
	.ascii	"M_MESSG\000"
	.space	2
	.word	M_ChangeMessages
	.byte	109
	.space	3
	.half	1
	.ascii	"M_DETAIL\000"
	.space	1
	.word	M_ChangeDetail
	.byte	103
	.space	3
	.half	2
	.ascii	"M_SCRNSZ\000"
	.space	1
	.word	M_SizeDisplay
	.byte	115
	.space	3
	.half	-1
	.ascii	"\000"
	.space	9
	.word	0
	.byte	0
	.space	3
	.half	2
	.ascii	"M_MSENS\000"
	.space	2
	.word	M_ChangeSensitivity
	.byte	109
	.space	3
	.half	-1
	.ascii	"\000"
	.space	9
	.word	0
	.byte	0
	.space	3
	.half	1
	.ascii	"M_SVOL\000"
	.space	3
	.word	M_Sound
	.byte	115
	.space	3
	.globl	options_e
	.section	.bss
	.align	2
	.type	options_e, @object
	.size	options_e, 4
options_e:
	.space	4
	.globl	NewDef
	.data
	.align	2
	.type	NewDef, @object
	.size	NewDef, 24
NewDef:
	.half	5
	.space	2
	.word	EpiDef
	.word	NewGameMenu
	.word	M_DrawNewGame
	.half	48
	.half	63
	.half	2
	.space	2
	.globl	NewGameMenu
	.align	2
	.type	NewGameMenu, @object
	.size	NewGameMenu, 100
NewGameMenu:
	.half	1
	.ascii	"M_JKILL\000"
	.space	2
	.word	M_ChooseSkill
	.byte	105
	.space	3
	.half	1
	.ascii	"M_ROUGH\000"
	.space	2
	.word	M_ChooseSkill
	.byte	104
	.space	3
	.half	1
	.ascii	"M_HURT\000"
	.space	3
	.word	M_ChooseSkill
	.byte	104
	.space	3
	.half	1
	.ascii	"M_ULTRA\000"
	.space	2
	.word	M_ChooseSkill
	.byte	117
	.space	3
	.half	1
	.ascii	"M_NMARE\000"
	.space	2
	.word	M_ChooseSkill
	.byte	110
	.space	3
	.globl	newgame_e
	.section	.bss
	.align	2
	.type	newgame_e, @object
	.size	newgame_e, 4
newgame_e:
	.space	4
	.globl	EpiDef
	.data
	.align	2
	.type	EpiDef, @object
	.size	EpiDef, 24
EpiDef:
	.half	4
	.space	2
	.word	MainDef
	.word	EpisodeMenu
	.word	M_DrawEpisode
	.half	48
	.half	63
	.half	0
	.space	2
	.globl	EpisodeMenu
	.align	2
	.type	EpisodeMenu, @object
	.size	EpisodeMenu, 80
EpisodeMenu:
	.half	1
	.ascii	"M_EPI1\000"
	.space	3
	.word	M_Episode
	.byte	107
	.space	3
	.half	1
	.ascii	"M_EPI2\000"
	.space	3
	.word	M_Episode
	.byte	116
	.space	3
	.half	1
	.ascii	"M_EPI3\000"
	.space	3
	.word	M_Episode
	.byte	105
	.space	3
	.half	1
	.ascii	"M_EPI4\000"
	.space	3
	.word	M_Episode
	.byte	116
	.space	3
	.globl	episodes_e
	.section	.bss
	.align	2
	.type	episodes_e, @object
	.size	episodes_e, 4
episodes_e:
	.space	4
	.globl	MainDef
	.data
	.align	2
	.type	MainDef, @object
	.size	MainDef, 24
MainDef:
	.half	6
	.space	2
	.word	0
	.word	MainMenu
	.word	M_DrawMainMenu
	.half	97
	.half	64
	.half	0
	.space	2
	.globl	MainMenu
	.align	2
	.type	MainMenu, @object
	.size	MainMenu, 120
MainMenu:
	.half	1
	.ascii	"M_NGAME\000"
	.space	2
	.word	M_NewGame
	.byte	110
	.space	3
	.half	1
	.ascii	"M_OPTION\000"
	.space	1
	.word	M_Options
	.byte	111
	.space	3
	.half	1
	.ascii	"M_LOADG\000"
	.space	2
	.word	M_LoadGame
	.byte	108
	.space	3
	.half	1
	.ascii	"M_SAVEG\000"
	.space	2
	.word	M_SaveGame
	.byte	115
	.space	3
	.half	1
	.ascii	"M_RDTHIS\000"
	.space	1
	.word	M_ReadThis
	.byte	114
	.space	3
	.half	1
	.ascii	"M_QUITG\000"
	.space	2
	.word	M_QuitDOOM
	.byte	113
	.space	3
	.globl	main_e
	.section	.bss
	.align	2
	.type	main_e, @object
	.size	main_e, 4
main_e:
	.space	4
	.globl	currentMenu
	.align	2
	.type	currentMenu, @object
	.size	currentMenu, 4
currentMenu:
	.space	4
	.globl	skullName
	.section	.rodata.str1.4
	.align	2
$LC47:
	.ascii	"M_SKULL1\000"
	.align	2
$LC48:
	.ascii	"M_SKULL2\000"
	.data
	.align	2
	.type	skullName, @object
	.size	skullName, 8
skullName:
	.word	$LC47
	.word	$LC48
	.globl	whichSkull
	.section	.bss
	.align	1
	.type	whichSkull, @object
	.size	whichSkull, 2
whichSkull:
	.space	2
	.globl	skullAnimCounter
	.align	1
	.type	skullAnimCounter, @object
	.size	skullAnimCounter, 2
skullAnimCounter:
	.space	2
	.globl	itemOn
	.align	1
	.type	itemOn, @object
	.size	itemOn, 2
itemOn:
	.space	2
	.globl	endstring
	.align	2
	.type	endstring, @object
	.size	endstring, 160
endstring:
	.space	160
	.globl	savegamestrings
	.align	2
	.type	savegamestrings, @object
	.size	savegamestrings, 240
savegamestrings:
	.space	240
	.globl	menuactive
	.align	2
	.type	menuactive, @object
	.size	menuactive, 4
menuactive:
	.space	4
	.globl	inhelpscreens
	.align	2
	.type	inhelpscreens, @object
	.size	inhelpscreens, 4
inhelpscreens:
	.space	4
	.globl	saveOldString
	.align	2
	.type	saveOldString, @object
	.size	saveOldString, 24
saveOldString:
	.space	24
	.globl	saveCharIndex
	.align	2
	.type	saveCharIndex, @object
	.size	saveCharIndex, 4
saveCharIndex:
	.space	4
	.globl	saveSlot
	.align	2
	.type	saveSlot, @object
	.size	saveSlot, 4
saveSlot:
	.space	4
	.globl	saveStringEnter
	.align	2
	.type	saveStringEnter, @object
	.size	saveStringEnter, 4
saveStringEnter:
	.space	4
	.globl	gammamsg
	.data
	.align	2
	.type	gammamsg, @object
	.size	gammamsg, 130
gammamsg:
	.ascii	"Gamma correction OFF\000"
	.space	5
	.ascii	"Gamma correction level 1\000"
	.space	1
	.ascii	"Gamma correction level 2\000"
	.space	1
	.ascii	"Gamma correction level 3\000"
	.space	1
	.ascii	"Gamma correction level 4\000"
	.space	1
	.globl	messageRoutine
	.section	.bss
	.align	2
	.type	messageRoutine, @object
	.size	messageRoutine, 4
messageRoutine:
	.space	4
	.globl	messageNeedsInput
	.align	2
	.type	messageNeedsInput, @object
	.size	messageNeedsInput, 4
messageNeedsInput:
	.space	4
	.globl	messageLastMenuActive
	.align	2
	.type	messageLastMenuActive, @object
	.size	messageLastMenuActive, 4
messageLastMenuActive:
	.space	4
	.globl	messy
	.align	2
	.type	messy, @object
	.size	messy, 4
messy:
	.space	4
	.globl	messx
	.align	2
	.type	messx, @object
	.size	messx, 4
messx:
	.space	4
	.globl	messageString
	.align	2
	.type	messageString, @object
	.size	messageString, 4
messageString:
	.space	4
	.globl	messageToPrint
	.align	2
	.type	messageToPrint, @object
	.size	messageToPrint, 4
messageToPrint:
	.space	4
	.globl	quickSaveSlot
	.align	2
	.type	quickSaveSlot, @object
	.size	quickSaveSlot, 4
quickSaveSlot:
	.space	4
	.globl	screenSize
	.align	2
	.type	screenSize, @object
	.size	screenSize, 4
screenSize:
	.space	4
	.globl	screenblocks
	.data
	.align	2
	.type	screenblocks, @object
	.size	screenblocks, 4
screenblocks:
	.word	10
	.globl	detailLevel
	.section	.bss
	.align	2
	.type	detailLevel, @object
	.size	detailLevel, 4
detailLevel:
	.space	4
	.globl	showMessages
	.data
	.align	2
	.type	showMessages, @object
	.size	showMessages, 4
showMessages:
	.word	1
	.globl	mouseSensitivity
	.align	2
	.type	mouseSensitivity, @object
	.size	mouseSensitivity, 4
mouseSensitivity:
	.word	5
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
