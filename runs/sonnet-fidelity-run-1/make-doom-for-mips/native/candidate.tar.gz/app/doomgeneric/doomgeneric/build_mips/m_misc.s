	.file	1 "m_misc.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	M_MakeDirectory
	.set	nomips16
	.set	nomicromips
	.ent	M_MakeDirectory
	.type	M_MakeDirectory, @function
M_MakeDirectory:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	mkdir
	li	$5,493			# 0x1ed

	.set	macro
	.set	reorder
	.end	M_MakeDirectory
	.size	M_MakeDirectory, .-M_MakeDirectory
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"r\000"
	.text
	.align	2
	.globl	M_FileExists
	.set	nomips16
	.set	nomicromips
	.ent	M_FileExists
	.type	M_FileExists, @function
M_FileExists:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi($LC0)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	fopen
	addiu	$5,$5,%lo($LC0)

	beq	$2,$0,$L4
	lw	$31,20($sp)

	jal	fclose
	move	$4,$2

	lw	$31,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,24

$L4:
	lui	$2,%hi(errno)
	lw	$2,%lo(errno)($2)
	xori	$2,$2,0x15
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_FileExists
	.size	M_FileExists, .-M_FileExists
	.align	2
	.globl	M_FileLength
	.set	nomips16
	.set	nomicromips
	.ent	M_FileLength
	.type	M_FileLength, @function
M_FileLength:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,28($sp)
	sw	$18,24($sp)
	jal	ftell
	sw	$17,20($sp)

	li	$6,2			# 0x2
	move	$5,$0
	move	$4,$16
	jal	fseek
	move	$18,$2

	jal	ftell
	move	$4,$16

	move	$5,$18
	move	$4,$16
	move	$6,$0
	jal	fseek
	move	$17,$2

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_FileLength
	.size	M_FileLength, .-M_FileLength
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"wb\000"
	.text
	.align	2
	.globl	M_WriteFile
	.set	nomips16
	.set	nomicromips
	.ent	M_WriteFile
	.type	M_WriteFile, @function
M_WriteFile:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	move	$18,$5
	lui	$5,%hi($LC1)
	addiu	$5,$5,%lo($LC1)
	sw	$16,16($sp)
	sw	$31,28($sp)
	sw	$17,20($sp)
	jal	fopen
	move	$16,$6

	beq	$2,$0,$L11
	move	$17,$2

	move	$4,$18
	move	$6,$16
	move	$7,$2
	jal	fwrite
	li	$5,1			# 0x1

	move	$4,$17
	jal	fclose
	move	$18,$2

	lw	$31,28($sp)
	slt	$2,$18,$16
	lw	$17,20($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	xori	$2,$2,0x1
	jr	$31
	addiu	$sp,$sp,32

$L11:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_WriteFile
	.size	M_WriteFile, .-M_WriteFile
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"rb\000"
	.align	2
$LC3:
	.ascii	"Couldn't read file %s\000"
	.text
	.align	2
	.globl	M_ReadFile
	.set	nomips16
	.set	nomicromips
	.ent	M_ReadFile
	.type	M_ReadFile, @function
M_ReadFile:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$20,36($sp)
	move	$20,$5
	lui	$5,%hi($LC2)
	addiu	$5,$5,%lo($LC2)
	sw	$21,40($sp)
	sw	$16,20($sp)
	sw	$31,44($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	jal	fopen
	move	$21,$4

	beq	$2,$0,$L17
	move	$16,$2

$L14:
	jal	ftell
	move	$4,$16

	li	$6,2			# 0x2
	move	$5,$0
	move	$4,$16
	jal	fseek
	move	$18,$2

	jal	ftell
	move	$4,$16

	move	$17,$2
	move	$5,$18
	move	$4,$16
	jal	fseek
	move	$6,$0

	move	$4,$17
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	move	$4,$2
	move	$7,$16
	move	$6,$17
	li	$5,1			# 0x1
	jal	fread
	move	$19,$2

	move	$18,$2
	move	$4,$16
	jal	fclose
	slt	$18,$18,$17

	bne	$18,$0,$L18
	lw	$31,44($sp)

	sw	$19,0($20)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$16,20($sp)
	move	$2,$17
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,48

$L18:
	lui	$4,%hi($LC3)
	move	$5,$21
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	lw	$31,44($sp)
	sw	$19,0($20)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$16,20($sp)
	move	$2,$17
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,48

$L17:
	lui	$4,%hi($LC3)
	move	$5,$21
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	b	$L14
	nop

	.set	macro
	.set	reorder
	.end	M_ReadFile
	.size	M_ReadFile, .-M_ReadFile
	.section	.rodata.str1.4
	.align	2
$LC4:
	.ascii	" 0x%x\000"
	.align	2
$LC5:
	.ascii	" 0X%x\000"
	.align	2
$LC6:
	.ascii	" 0%o\000"
	.align	2
$LC7:
	.ascii	" %d\000"
	.text
	.align	2
	.globl	M_StrToInt
	.set	nomips16
	.set	nomicromips
	.ent	M_StrToInt
	.type	M_StrToInt, @function
M_StrToInt:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$6,$5
	sw	$16,16($sp)
	move	$16,$5
	lui	$5,%hi($LC4)
	addiu	$5,$5,%lo($LC4)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$31,28($sp)
	move	$17,$4
	jal	sscanf
	li	$18,1			# 0x1

	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L20
	.set	at
	lui	$5,%hi($LC5)

	lw	$31,28($sp)
$L24:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

$L20:
	move	$6,$16
	addiu	$5,$5,%lo($LC5)
	jal	sscanf
	move	$4,$17

	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L24
	.set	at
	lw	$31,28($sp)

	lui	$5,%hi($LC6)
	move	$6,$16
	addiu	$5,$5,%lo($LC6)
	jal	sscanf
	move	$4,$17

	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L24
	.set	at
	lw	$31,28($sp)

	lui	$5,%hi($LC7)
	move	$6,$16
	move	$4,$17
	jal	sscanf
	addiu	$5,$5,%lo($LC7)

	lw	$31,28($sp)
	xori	$2,$2,0x1
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_StrToInt
	.size	M_StrToInt, .-M_StrToInt
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"Warning: Truncated '%s' lump name to '%.8s'.\012\000"
	.text
	.align	2
	.globl	M_ExtractFileBase
	.set	nomips16
	.set	nomicromips
	.ent	M_ExtractFileBase
	.type	M_ExtractFileBase, @function
M_ExtractFileBase:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$19,32($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$4
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$18,28($sp)
	jal	strlen
	move	$19,$5

	addiu	$16,$2,-1
	addu	$16,$17,$16
	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L26
	.set	at
	li	$3,47			# 0x2f

	b	$L41
	move	$4,$19

$L28:
	.set	noat
	xor	$1,$17,$16
	beq	$1,$0,$L41
	.set	at
	move	$4,$19

$L26:
	lb	$2,-1($16)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L28
	.set	at
	addiu	$16,$16,-1

	addiu	$16,$16,1
	move	$4,$19
$L41:
	li	$6,8			# 0x8
	jal	memset
	move	$5,$0

	lb	$4,0($16)
	beq	$4,$0,$L25
	move	$18,$19

	addiu	$21,$16,8
	move	$17,$16
	b	$L31
	li	$20,46			# 0x2e

$L32:
	jal	toupper
	nop

	sb	$2,0($18)
	lb	$4,1($17)
	addiu	$18,$18,1
	beq	$4,$0,$L25
	addiu	$17,$17,1

$L31:
	.set	noat
	xor	$1,$4,$20
	beq	$1,$0,$L42
	.set	at
	lw	$31,44($sp)

	.set	noat
	xor	$1,$17,$21
	bne	$1,$0,$L32
	.set	at
	move	$6,$19

	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	move	$5,$16
	lw	$19,32($sp)
	lw	$16,20($sp)
	lui	$4,%hi($LC8)
	addiu	$4,$4,%lo($LC8)
	j	printf
	addiu	$sp,$sp,48

$L25:
	lw	$31,44($sp)
$L42:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	M_ExtractFileBase
	.size	M_ExtractFileBase, .-M_ExtractFileBase
	.align	2
	.globl	M_ForceUppercase
	.set	nomips16
	.set	nomicromips
	.ent	M_ForceUppercase
	.type	M_ForceUppercase, @function
M_ForceUppercase:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	move	$16,$4
	lb	$4,0($4)
	beq	$4,$0,$L51
	lw	$31,20($sp)

$L45:
	jal	toupper
	nop

	lb	$4,1($16)
	sb	$2,0($16)
	bne	$4,$0,$L45
	addiu	$16,$16,1

	lw	$31,20($sp)
$L51:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	M_ForceUppercase
	.size	M_ForceUppercase, .-M_ForceUppercase
	.align	2
	.globl	M_StrCaseStr
	.set	nomips16
	.set	nomicromips
	.ent	M_StrCaseStr
	.type	M_StrCaseStr, @function
M_StrCaseStr:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$19,32($sp)
	move	$19,$5
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$18,28($sp)
	move	$20,$4
	sw	$17,24($sp)
	jal	strlen
	sw	$16,20($sp)

	move	$4,$19
	jal	strlen
	move	$18,$2

	move	$21,$2
	sltu	$2,$18,$2
	bne	$2,$0,$L53
	subu	$18,$18,$21

	b	$L55
	move	$16,$0

$L61:
	bne	$3,$0,$L62
	lw	$31,44($sp)

$L55:
	addu	$17,$20,$16
	move	$6,$21
	move	$5,$19
	move	$4,$17
	jal	strncasecmp
	addiu	$16,$16,1

	bne	$2,$0,$L61
	sltu	$3,$18,$16

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$16,20($sp)
	move	$2,$17
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,48

$L53:
	lw	$31,44($sp)
$L62:
	move	$17,$0
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$16,20($sp)
	move	$2,$17
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	M_StrCaseStr
	.size	M_StrCaseStr, .-M_StrCaseStr
	.section	.rodata.str1.4
	.align	2
$LC9:
	.ascii	"Failed to duplicate string (length %i)\012\000"
	.text
	.align	2
	.globl	M_StringDuplicate
	.set	nomips16
	.set	nomicromips
	.ent	M_StringDuplicate
	.type	M_StringDuplicate, @function
M_StringDuplicate:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	jal	strdup
	move	$17,$4

	beq	$2,$0,$L66
	move	$16,$2

	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$2,$16
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L66:
	jal	strlen
	move	$4,$17

	lui	$4,%hi($LC9)
	move	$5,$2
	jal	I_Error
	addiu	$4,$4,%lo($LC9)

	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$2,$16
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_StringDuplicate
	.size	M_StringDuplicate, .-M_StringDuplicate
	.section	.rodata.str1.4
	.align	2
$LC10:
	.ascii	"M_StringReplace: Failed to allocate new string\000"
	.text
	.align	2
	.globl	M_StringReplace
	.set	nomips16
	.set	nomicromips
	.ent	M_StringReplace
	.type	M_StringReplace, @function
M_StringReplace:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,20($sp)
	move	$17,$4
	move	$4,$5
	sw	$31,44($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	move	$20,$5
	move	$19,$6
	jal	strlen
	sw	$22,40($sp)

	move	$4,$17
	jal	strlen
	move	$18,$2

	addiu	$16,$2,1
	b	$L69
	move	$21,$17

$L84:
	jal	strlen
	nop

	subu	$2,$2,$18
	addu	$16,$16,$2
$L69:
	move	$4,$21
	jal	strstr
	move	$5,$20

	addu	$21,$2,$18
	bne	$2,$0,$L84
	move	$4,$19

	jal	malloc
	move	$4,$16

	beq	$2,$0,$L70
	move	$22,$2

	lb	$2,0($17)
	bne	$2,$0,$L71
	move	$21,$22

	b	$L67
	sb	$0,0($21)

$L85:
	addu	$2,$21,$6
	move	$4,$21
	beq	$16,$0,$L75
	move	$5,$19

	jal	strncpy
	sb	$0,0($2)

	jal	strlen
	move	$4,$21

$L75:
	jal	strlen
	move	$4,$19

	addu	$17,$17,$18
	move	$4,$19
	jal	strlen
	addu	$21,$21,$2

	lb	$3,0($17)
	beq	$3,$0,$L72
	subu	$16,$16,$2

$L71:
	move	$4,$17
	move	$6,$18
	jal	strncmp
	move	$5,$20

	beq	$2,$0,$L85
	addiu	$6,$16,-1

	lb	$2,0($17)
	addiu	$17,$17,1
	sb	$2,0($21)
	lb	$3,0($17)
	addiu	$21,$21,1
	bne	$3,$0,$L71
	addiu	$16,$16,-1

$L72:
	sb	$0,0($21)
$L67:
	lw	$31,44($sp)
$L86:
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$22
	lw	$22,40($sp)
	jr	$31
	addiu	$sp,$sp,48

$L70:
	lui	$4,%hi($LC10)
	jal	I_Error
	addiu	$4,$4,%lo($LC10)

	b	$L86
	lw	$31,44($sp)

	.set	macro
	.set	reorder
	.end	M_StringReplace
	.size	M_StringReplace, .-M_StringReplace
	.align	2
	.globl	M_StringCopy
	.set	nomips16
	.set	nomicromips
	.ent	M_StringCopy
	.type	M_StringCopy, @function
M_StringCopy:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bne	$6,$0,$L96
	move	$2,$6

	jr	$31
	nop

$L96:
	addiu	$6,$6,-1
	addiu	$sp,$sp,-32
	addu	$2,$4,$6
	sw	$31,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$4
	sb	$0,0($2)
	jal	strncpy
	move	$16,$5

	jal	strlen
	move	$4,$17

	addu	$5,$16,$2
	lb	$2,0($5)
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_StringCopy
	.size	M_StringCopy, .-M_StringCopy
	.align	2
	.globl	M_StringConcat
	.set	nomips16
	.set	nomicromips
	.ent	M_StringConcat
	.type	M_StringConcat, @function
M_StringConcat:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	move	$16,$6
	move	$17,$4
	jal	strlen
	move	$18,$5

	move	$3,$2
	sltu	$2,$16,$2
	movn	$3,$16,$2
	.set	noat
	xor	$1,$16,$3
	beq	$1,$0,$L99
	.set	at
	subu	$2,$16,$3

	addu	$17,$17,$3
	addiu	$6,$2,-1
	addu	$2,$17,$6
	move	$5,$18
	move	$4,$17
	jal	strncpy
	sb	$0,0($2)

	jal	strlen
	move	$4,$17

	addu	$18,$18,$2
	lb	$2,0($18)
	sltu	$2,$2,1
$L99:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_StringConcat
	.size	M_StringConcat, .-M_StringConcat
	.align	2
	.globl	M_StringStartsWith
	.set	nomips16
	.set	nomicromips
	.ent	M_StringStartsWith
	.type	M_StringStartsWith, @function
M_StringStartsWith:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	jal	strlen
	move	$18,$4

	move	$4,$17
	jal	strlen
	move	$16,$2

	sltu	$16,$2,$16
	bne	$16,$0,$L109
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L109:
	jal	strlen
	move	$4,$17

	move	$6,$2
	move	$5,$17
	jal	strncmp
	move	$4,$18

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_StringStartsWith
	.size	M_StringStartsWith, .-M_StringStartsWith
	.align	2
	.globl	M_StringEndsWith
	.set	nomips16
	.set	nomicromips
	.ent	M_StringEndsWith
	.type	M_StringEndsWith, @function
M_StringEndsWith:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	jal	strlen
	move	$18,$4

	move	$4,$17
	jal	strlen
	move	$16,$2

	sltu	$16,$16,$2
	beq	$16,$0,$L114
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L114:
	jal	strlen
	move	$4,$18

	move	$4,$17
	jal	strlen
	move	$16,$2

	subu	$4,$16,$2
	move	$5,$17
	jal	strcmp
	addu	$4,$18,$4

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_StringEndsWith
	.size	M_StringEndsWith, .-M_StringEndsWith
	.section	.rodata.str1.4
	.align	2
$LC11:
	.ascii	"M_StringJoin: Failed to allocate new string.\000"
	.text
	.align	2
	.globl	M_StringJoin
	.set	nomips16
	.set	nomicromips
	.ent	M_StringJoin
	.type	M_StringJoin, @function
M_StringJoin:
	.frame	$sp,48,$31		# vars= 8, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	move	$18,$4
	sw	$31,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$5,52($sp)
	sw	$6,56($sp)
	jal	strlen
	sw	$7,60($sp)

	lw	$4,52($sp)
	addiu	$16,$sp,56
	addiu	$17,$2,1
	beq	$4,$0,$L116
	sw	$16,16($sp)

$L117:
	jal	strlen
	addiu	$16,$16,4

	lw	$4,-4($16)
	addu	$17,$17,$2
	bne	$4,$0,$L117
	sw	$16,16($sp)

$L116:
	jal	malloc
	move	$4,$17

	beq	$2,$0,$L136
	move	$19,$2

	bne	$17,$0,$L137
	addiu	$6,$17,-1

	addiu	$18,$sp,52
$L122:
	addiu	$3,$18,4
$L121:
	lw	$20,-4($3)
	move	$4,$19
	move	$18,$3
	beq	$20,$0,$L115
	sw	$3,16($sp)

	jal	strlen
	nop

	sltu	$3,$17,$2
	movn	$2,$17,$3
	subu	$6,$17,$2
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L121
	.set	at
	addiu	$3,$18,4

	addu	$16,$19,$2
	addiu	$6,$6,-1
	addu	$2,$16,$6
	move	$4,$16
	move	$5,$20
	jal	strncpy
	sb	$0,0($2)

	jal	strlen
	move	$4,$16

	b	$L121
	addiu	$3,$18,4

$L136:
	lui	$4,%hi($LC11)
	jal	I_Error
	addiu	$4,$4,%lo($LC11)

$L115:
	lw	$31,44($sp)
	lw	$20,40($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	move	$2,$19
	lw	$19,36($sp)
	jr	$31
	addiu	$sp,$sp,48

$L137:
	addu	$2,$2,$6
	move	$5,$18
	move	$4,$19
	jal	strncpy
	sb	$0,0($2)

	jal	strlen
	move	$4,$19

	b	$L122
	addiu	$18,$sp,52

	.set	macro
	.set	reorder
	.end	M_StringJoin
	.size	M_StringJoin, .-M_StringJoin
	.section	.rodata.str1.4
	.align	2
$LC12:
	.ascii	"/\000"
	.align	2
$LC13:
	.ascii	"/tmp\000"
	.text
	.align	2
	.globl	M_TempFile
	.set	nomips16
	.set	nomicromips
	.ent	M_TempFile
	.type	M_TempFile, @function
M_TempFile:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$6,$4
	lui	$5,%hi($LC12)
	lui	$4,%hi($LC13)
	move	$7,$0
	addiu	$5,$5,%lo($LC12)
	j	M_StringJoin
	addiu	$4,$4,%lo($LC13)

	.set	macro
	.set	reorder
	.end	M_TempFile
	.size	M_TempFile, .-M_TempFile
	.align	2
	.globl	M_vsnprintf
	.set	nomips16
	.set	nomicromips
	.ent	M_vsnprintf
	.type	M_vsnprintf, @function
M_vsnprintf:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bne	$5,$0,$L147
	move	$2,$0

	jr	$31
	nop

$L147:
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$5
	jal	vsnprintf
	move	$17,$4

	bltz	$2,$L141
	sltu	$3,$2,$16

	bne	$3,$0,$L148
	lw	$31,28($sp)

$L141:
	addiu	$2,$16,-1
	addu	$4,$17,$2
	sb	$0,0($4)
	lw	$31,28($sp)
$L148:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	M_vsnprintf
	.size	M_vsnprintf, .-M_vsnprintf
	.align	2
	.globl	M_snprintf
	.set	nomips16
	.set	nomicromips
	.ent	M_snprintf
	.type	M_snprintf, @function
M_snprintf:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	addiu	$2,$sp,52
	sw	$31,36($sp)
	sw	$17,32($sp)
	sw	$16,28($sp)
	sw	$7,52($sp)
	bne	$5,$0,$L156
	sw	$2,16($sp)

	move	$2,$0
	lw	$31,36($sp)
$L157:
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L156:
	move	$7,$2
	move	$16,$5
	jal	vsnprintf
	move	$17,$4

	bltz	$2,$L153
	sltu	$3,$2,$16

	bne	$3,$0,$L157
	lw	$31,36($sp)

$L153:
	addiu	$2,$16,-1
	addu	$4,$17,$2
	sb	$0,0($4)
	lw	$31,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	M_snprintf
	.size	M_snprintf, .-M_snprintf
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
