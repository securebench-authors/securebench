	.file	1 "m_random.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_Random
	.set	nomips16
	.set	nomicromips
	.ent	P_Random
	.type	P_Random, @function
P_Random:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(prndindex)
	lw	$2,%lo(prndindex)($4)
	lui	$3,%hi(rndtable)
	addiu	$2,$2,1
	andi	$2,$2,0xff
	addiu	$3,$3,%lo(rndtable)
	addu	$3,$2,$3
	sw	$2,%lo(prndindex)($4)
	jr	$31
	lbu	$2,0($3)

	.set	macro
	.set	reorder
	.end	P_Random
	.size	P_Random, .-P_Random
	.align	2
	.globl	M_Random
	.set	nomips16
	.set	nomicromips
	.ent	M_Random
	.type	M_Random, @function
M_Random:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(rndindex)
	lw	$2,%lo(rndindex)($4)
	lui	$3,%hi(rndtable)
	addiu	$2,$2,1
	andi	$2,$2,0xff
	addiu	$3,$3,%lo(rndtable)
	addu	$3,$2,$3
	sw	$2,%lo(rndindex)($4)
	jr	$31
	lbu	$2,0($3)

	.set	macro
	.set	reorder
	.end	M_Random
	.size	M_Random, .-M_Random
	.align	2
	.globl	M_ClearRandom
	.set	nomips16
	.set	nomicromips
	.ent	M_ClearRandom
	.type	M_ClearRandom, @function
M_ClearRandom:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(prndindex)
	sw	$0,%lo(prndindex)($2)
	lui	$2,%hi(rndindex)
	jr	$31
	sw	$0,%lo(rndindex)($2)

	.set	macro
	.set	reorder
	.end	M_ClearRandom
	.size	M_ClearRandom, .-M_ClearRandom
	.globl	prndindex
	.section	.bss,"aw",@nobits
	.align	2
	.type	prndindex, @object
	.size	prndindex, 4
prndindex:
	.space	4
	.globl	rndindex
	.align	2
	.type	rndindex, @object
	.size	rndindex, 4
rndindex:
	.space	4
	.rdata
	.align	2
	.type	rndtable, @object
	.size	rndtable, 256
rndtable:
	.ascii	"\000\010m\334\336\361\225kK\370\376\214\020BJ\025\323/P\362"
	.ascii	"\232\033\315\200\241YM$_nU0\324\214\323\371\026O\3102\034"
	.ascii	"\2744\214\312xD\221>F\270\276[\305\230\340\225h\031\262\374"
	.ascii	"\266\312\266\215\305\004Q\265\362\221*'\343\234\306\341\301"
	.ascii	"\333]z\257\371\000\257\217F\357.\366\2435\243m\250\207\002"
	.ascii	"\353\031\\\024\221\212ME\246N\260\255\324\246q^\241)2\357"
	.ascii	"1o\244F<\002%\253K\210\234\0138*\222\212\345I\222M=b\304"
	.ascii	"\207j?\305\303V`\313qe\252\367\265qP\372l\007\377\355\201"
	.ascii	"\342Okp\246g\361\030\337\357x\306:<R\200\003\270B\217\340"
	.ascii	"\221\340Q\316\243-?Z\250r;!\237_\034\213{b}\304\017F\302"
	.ascii	"\3756\016m\342G\021\241]\272W\364\212\0244{\373\032$\021"
	.ascii	".4\347\350L\037\335T%\330\245\324j\305\362b+'\257\376\221"
	.ascii	"\276Tv\336\273\210x\243\354\371"
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
