	.file	1 "memio.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	mem_fopen_read
	.set	nomips16
	.set	nomicromips
	.ent	mem_fopen_read
	.type	mem_fopen_read, @function
mem_fopen_read:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$6,$0
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$4
	move	$16,$5
	li	$4,20			# 0x14
	sw	$31,28($sp)
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$31,28($sp)
	sw	$17,0($2)
	sw	$16,4($2)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$0,12($2)
	sw	$0,16($2)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	mem_fopen_read
	.size	mem_fopen_read, .-mem_fopen_read
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"not a read stream\012\000"
	.text
	.align	2
	.globl	mem_fread
	.set	nomips16
	.set	nomicromips
	.ent	mem_fread
	.type	mem_fread, @function
mem_fread:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($7)
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	bne	$2,$0,$L10
	sw	$16,16($sp)

	multu	$6,$5
	mflo	$18
	lw	$3,12($7)
	lw	$2,4($7)
	move	$17,$6
	subu	$2,$2,$3
	sltu	$6,$2,$18
	bne	$6,$0,$L11
	move	$16,$7

$L7:
	lw	$5,0($16)
	move	$6,$18
	jal	memcpy
	addu	$5,$5,$3

	lw	$2,12($16)
	lw	$31,28($sp)
	addu	$2,$2,$18
	sw	$2,12($16)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L11:
	divu	$0,$2,$5
	mflo	$17
	b	$L7
	multu	$5,$17
	mflo	$18

$L10:
	lui	$4,%hi($LC0)
	jal	printf
	addiu	$4,$4,%lo($LC0)

	lw	$31,28($sp)
	li	$17,-1			# 0xffffffffffffffff
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	mem_fread
	.size	mem_fread, .-mem_fread
	.align	2
	.globl	mem_fopen_write
	.set	nomips16
	.set	nomicromips
	.ent	mem_fopen_write
	.type	mem_fopen_write, @function
mem_fopen_write:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	move	$6,$0
	li	$5,1			# 0x1
	li	$4,20			# 0x14
	sw	$31,20($sp)
	jal	Z_Malloc
	sw	$16,16($sp)

	move	$16,$2
	li	$2,1024			# 0x400
	sw	$2,8($16)
	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,1024			# 0x400

	lw	$31,20($sp)
	sw	$2,0($16)
	li	$2,1			# 0x1
	sw	$2,16($16)
	sw	$0,4($16)
	sw	$0,12($16)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	mem_fopen_write
	.size	mem_fopen_write, .-mem_fopen_write
	.align	2
	.globl	mem_fwrite
	.set	nomips16
	.set	nomicromips
	.ent	mem_fwrite
	.type	mem_fwrite, @function
mem_fwrite:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$16,16($sp)
	move	$16,$7
	lw	$7,16($7)
	li	$3,1			# 0x1
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	.set	noat
	xor	$1,$7,$3
	bne	$1,$0,$L21
	.set	at
	sw	$17,20($sp)

	multu	$5,$6
	mflo	$18
	lw	$2,12($16)
	move	$20,$4
	lw	$4,8($16)
	subu	$3,$4,$2
	sltu	$3,$3,$18
	beq	$3,$0,$L16
	move	$19,$6

$L17:
	sll	$4,$4,1
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$6,8($16)
	lw	$5,0($16)
	move	$4,$2
	jal	memcpy
	move	$17,$2

	jal	Z_Free
	lw	$4,0($16)

	lw	$4,8($16)
	lw	$2,12($16)
	sll	$4,$4,1
	subu	$3,$4,$2
	sltu	$3,$3,$18
	sw	$17,0($16)
	bne	$3,$0,$L17
	sw	$4,8($16)

$L18:
	move	$6,$18
	move	$5,$20
	jal	memcpy
	addu	$4,$17,$2

	lw	$3,12($16)
	lw	$2,4($16)
	addu	$18,$18,$3
	sltu	$2,$2,$18
	bne	$2,$0,$L19
	sw	$18,12($16)

$L20:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$19
	lw	$19,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L19:
	b	$L20
	sw	$18,4($16)

$L21:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,-1			# 0xffffffffffffffff
	jr	$31
	addiu	$sp,$sp,40

$L16:
	b	$L18
	lw	$17,0($16)

	.set	macro
	.set	reorder
	.end	mem_fwrite
	.size	mem_fwrite, .-mem_fwrite
	.align	2
	.globl	mem_get_buf
	.set	nomips16
	.set	nomicromips
	.ent	mem_get_buf
	.type	mem_get_buf, @function
mem_get_buf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,0($4)
	lw	$2,4($4)
	sw	$3,0($5)
	jr	$31
	sw	$2,0($6)

	.set	macro
	.set	reorder
	.end	mem_get_buf
	.size	mem_get_buf, .-mem_get_buf
	.align	2
	.globl	mem_fclose
	.set	nomips16
	.set	nomicromips
	.ent	mem_fclose
	.type	mem_fclose, @function
mem_fclose:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,16($4)
	addiu	$sp,$sp,-24
	li	$2,1			# 0x1
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L28
	.set	at
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	Z_Free
	addiu	$sp,$sp,24

$L28:
	jal	Z_Free
	lw	$4,0($4)

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	Z_Free
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	mem_fclose
	.size	mem_fclose, .-mem_fclose
	.align	2
	.globl	mem_ftell
	.set	nomips16
	.set	nomicromips
	.ent	mem_ftell
	.type	mem_ftell, @function
mem_ftell:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	lw	$2,12($4)

	.set	macro
	.set	reorder
	.end	mem_ftell
	.size	mem_ftell, .-mem_ftell
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Error seeking to %i\012\000"
	.text
	.align	2
	.globl	mem_fseek
	.set	nomips16
	.set	nomicromips
	.ent	mem_fseek
	.type	mem_fseek, @function
mem_fseek:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L31
	.set	at
	li	$2,2			# 0x2

	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L32
	.set	at
	nop

	beq	$6,$0,$L41
	nop

	jr	$31
	li	$2,-1			# 0xffffffffffffffff

$L31:
	lw	$3,12($4)
	lw	$2,4($4)
	addu	$5,$5,$3
$L34:
	sltu	$2,$5,$2
	beq	$2,$0,$L35
	move	$2,$0

	jr	$31
	sw	$5,12($4)

$L41:
	b	$L34
	lw	$2,4($4)

$L32:
	lw	$2,4($4)
	b	$L34
	addu	$5,$5,$2

$L35:
	lui	$4,%hi($LC1)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	printf
	addiu	$4,$4,%lo($LC1)

	lw	$31,20($sp)
	li	$2,-1			# 0xffffffffffffffff
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	mem_fseek
	.size	mem_fseek, .-mem_fseek
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
