	.file	1 "my_stdlib.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"0123456789ABCDEF\000"
	.align	2
$LC1:
	.ascii	"0123456789abcdef\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	out_num
	.type	out_num, @function
out_num:
	.frame	$sp,48,$31		# vars= 24, regs= 6/0, args= 0, gp= 0
	.mask	0x003f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	lw	$2,72($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$16,24($sp)
	lw	$19,64($sp)
	lw	$5,68($sp)
	lw	$13,80($sp)
	lw	$16,84($sp)
	lw	$18,88($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	beq	$2,$0,$L42
	sw	$17,28($sp)

	lui	$14,%hi($LC0)
	or	$2,$6,$7
	bne	$2,$0,$L43
	addiu	$14,$14,%lo($LC0)

$L76:
	beq	$13,$0,$L4
	move	$2,$0

	li	$2,48			# 0x30
	sb	$2,0($sp)
	li	$2,1			# 0x1
$L4:
	slt	$3,$13,$2
	move	$5,$2
	movz	$5,$13,$3
	lw	$3,76($sp)
	bne	$19,$0,$L8
	subu	$3,$3,$5

	lw	$5,92($sp)
	beq	$5,$0,$L9
	nop

	or	$5,$16,$18
	bne	$5,$0,$L11
	addiu	$8,$3,-1

	bgtz	$8,$L41
	addiu	$9,$3,-2

	move	$8,$9
$L11:
	lw	$6,4($4)
	lw	$5,8($4)
	addiu	$3,$6,1
	sltu	$5,$3,$5
	beq	$5,$0,$L22
	li	$5,43			# 0x2b

	lw	$3,0($4)
	addu	$3,$3,$6
	sb	$5,0($3)
	lw	$3,4($4)
	addiu	$3,$3,1
$L22:
	bne	$16,$0,$L25
	sw	$3,4($4)

$L78:
	bne	$18,$0,$L26
	nop

$L39:
	slt	$3,$2,$13
$L87:
	beq	$3,$0,$L72
	nop

$L13:
	lw	$3,4($4)
	move	$6,$2
	b	$L32
	li	$9,48			# 0x30

$L73:
	lw	$5,0($4)
	addiu	$6,$6,1
	addu	$3,$5,$3
	sb	$9,0($3)
	lw	$3,4($4)
	slt	$5,$6,$13
	addiu	$3,$3,1
	beq	$5,$0,$L28
	sw	$3,4($4)

$L32:
	lw	$5,8($4)
	addiu	$7,$3,1
	sltu	$5,$7,$5
	bne	$5,$0,$L73
	nop

	addiu	$6,$6,1
	move	$3,$7
	slt	$5,$6,$13
	bne	$5,$0,$L32
	sw	$3,4($4)

$L28:
	beq	$2,$0,$L33
	nop

$L14:
	lw	$3,4($4)
	b	$L35
	addu	$2,$sp,$2

$L74:
	lw	$5,0($4)
	lbu	$6,-1($2)
	addu	$3,$5,$3
	sb	$6,0($3)
	lw	$3,4($4)
	addiu	$2,$2,-1
	addiu	$3,$3,1
	.set	noat
	xor	$1,$sp,$2
	beq	$1,$0,$L33
	.set	at
	sw	$3,4($4)

$L35:
	lw	$5,8($4)
	addiu	$6,$3,1
	sltu	$5,$6,$5
	bne	$5,$0,$L74
	nop

	move	$3,$6
	addiu	$2,$2,-1
	.set	noat
	xor	$1,$sp,$2
	bne	$1,$0,$L35
	.set	at
	sw	$3,4($4)

$L33:
	beq	$16,$0,$L86
	lw	$21,44($sp)

$L15:
	blez	$8,$L1
	addiu	$5,$8,-1

	lw	$2,4($4)
	li	$8,32			# 0x20
	b	$L38
	li	$7,-1			# 0xffffffffffffffff

$L75:
	lw	$3,0($4)
	addiu	$5,$5,-1
	addu	$2,$3,$2
	sb	$8,0($2)
	lw	$2,4($4)
	addiu	$2,$2,1
	.set	noat
	xor	$1,$5,$7
	beq	$1,$0,$L1
	.set	at
	sw	$2,4($4)

$L38:
	lw	$3,8($4)
	addiu	$6,$2,1
	sltu	$3,$6,$3
	bne	$3,$0,$L75
	nop

	move	$2,$6
	addiu	$5,$5,-1
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L38
	.set	at
	sw	$2,4($4)

$L1:
	lw	$21,44($sp)
$L86:
	lw	$20,40($sp)
$L88:
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,48

$L42:
	lui	$14,%hi($LC1)
	or	$2,$6,$7
	beq	$2,$0,$L76
	addiu	$14,$14,%lo($LC1)

$L43:
	li	$12,-859045888			# 0xffffffffcccc0000
	ori	$12,$12,0xcccd
	li	$24,268369920			# 0xfff0000
	move	$2,$0
	li	$15,10			# 0xa
	li	$25,16			# 0x10
	ori	$24,$24,0xffff
	b	$L3
	addiu	$17,$12,-1

$L5:
	.set	noat
	xor	$1,$5,$25
	beq	$1,$0,$L77
	.set	at
	andi	$3,$6,0xf

	andi	$3,$6,0x7
	srl	$7,$7,3
	or	$6,$9,$8
$L6:
	addu	$3,$14,$3
	lbu	$9,0($3)
	addiu	$2,$2,1
	addu	$8,$sp,$2
	or	$3,$6,$7
	beq	$3,$0,$L4
	sb	$9,-1($8)

$L3:
	sll	$9,$7,29
	.set	noat
	xor	$1,$5,$15
	bne	$1,$0,$L5
	.set	at
	srl	$8,$6,3

	sll	$3,$7,4
	srl	$8,$6,28
	or	$8,$3,$8
	and	$8,$8,$24
	and	$3,$6,$24
	srl	$9,$7,24
	addu	$3,$3,$8
	addu	$3,$3,$9
	multu	$3,$12
	mfhi	$8
	srl	$8,$8,2
	sll	$9,$8,2
	addu	$8,$9,$8
	subu	$3,$3,$8
	subu	$3,$6,$3
	multu	$3,$17
	mflo	$10
	sltu	$8,$6,$3
	multu	$3,$12
	subu	$7,$7,$8
	mflo	$20
	mfhi	$21
	multu	$7,$12
	mflo	$8
	multu	$3,$12
	addu	$7,$8,$10
	addu	$7,$7,$21
	sll	$9,$7,31
	srl	$8,$20,1
	or	$8,$9,$8
	sll	$3,$8,2
	mflo	$10
	addu	$3,$3,$8
	sll	$3,$3,1
	srl	$8,$10,1
	subu	$3,$6,$3
	srl	$7,$7,1
	b	$L6
	or	$6,$9,$8

$L77:
	sll	$8,$7,28
	srl	$9,$6,4
	srl	$7,$7,4
	b	$L6
	or	$6,$8,$9

$L8:
	or	$5,$16,$18
	bne	$5,$0,$L17
	addiu	$8,$3,-1

	bgtz	$8,$L41
	addiu	$9,$3,-2

	move	$8,$9
$L17:
	lw	$6,4($4)
	lw	$5,8($4)
	addiu	$3,$6,1
	sltu	$5,$3,$5
	beq	$5,$0,$L22
	li	$5,45			# 0x2d

	lw	$3,0($4)
	addu	$3,$3,$6
	sb	$5,0($3)
	lw	$3,4($4)
	addiu	$3,$3,1
	beq	$16,$0,$L78
	sw	$3,4($4)

	b	$L85
	slt	$3,$2,$13

$L81:
	bne	$19,$0,$L17
	subu	$8,$9,$8

	lw	$3,92($sp)
	bne	$3,$0,$L11
	nop

	beq	$16,$0,$L87
	slt	$3,$2,$13

$L25:
	slt	$3,$2,$13
$L85:
	bne	$3,$0,$L13
	nop

$L70:
	bne	$2,$0,$L14
	nop

	b	$L15
	nop

$L9:
	bne	$16,$0,$L79
	nop

	bne	$18,$0,$L26
	move	$8,$3

	blez	$3,$L80
	addiu	$9,$3,-1

$L41:
	lw	$3,4($4)
	move	$6,$9
	li	$11,32			# 0x20
	b	$L19
	li	$10,-1			# 0xffffffffffffffff

$L82:
	lw	$5,0($4)
	addu	$3,$5,$3
	sb	$11,0($3)
	lw	$3,4($4)
	addiu	$3,$3,1
$L18:
	addiu	$6,$6,-1
	.set	noat
	xor	$1,$6,$10
	beq	$1,$0,$L81
	.set	at
	sw	$3,4($4)

$L19:
	lw	$5,8($4)
	addiu	$7,$3,1
	sltu	$5,$7,$5
	bne	$5,$0,$L82
	nop

	b	$L18
	move	$3,$7

$L26:
	bltz	$13,$L83
	slt	$3,$2,$13

	bne	$3,$0,$L13
	nop

	b	$L28
	nop

$L79:
	slt	$5,$2,$13
	bne	$5,$0,$L13
	move	$8,$3

	b	$L70
	nop

$L83:
	blez	$8,$L48
	addiu	$5,$8,-1

	lw	$3,4($4)
	move	$8,$5
	li	$9,48			# 0x30
	b	$L30
	li	$7,-1			# 0xffffffffffffffff

$L84:
	lw	$5,0($4)
	addu	$3,$5,$3
	sb	$9,0($3)
	lw	$3,4($4)
	addiu	$3,$3,1
$L29:
	addiu	$8,$8,-1
	.set	noat
	xor	$1,$8,$7
	beq	$1,$0,$L28
	.set	at
	sw	$3,4($4)

$L30:
	lw	$5,8($4)
	addiu	$6,$3,1
	sltu	$5,$6,$5
	bne	$5,$0,$L84
	nop

	b	$L29
	move	$3,$6

$L72:
	bne	$2,$0,$L14
	lw	$21,44($sp)

	b	$L88
	lw	$20,40($sp)

$L48:
	b	$L28
	move	$8,$5

$L80:
	b	$L39
	move	$8,$9

	.set	macro
	.set	reorder
	.end	out_num
	.size	out_num, .-out_num
	.globl	__gtdf2
	.globl	__divdf3
	.globl	__ltdf2
	.globl	__muldf3
	.globl	__subdf3
	.globl	__adddf3
	.globl	__floatsidf
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	log.part.0
	.type	log.part.0, @function
log.part.0:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$18,24($sp)
	lui	$18,%hi($LC2)
	lw	$6,%lo($LC2)($18)
	lw	$7,%lo($LC2+4)($18)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	move	$17,$4
	jal	__gtdf2
	move	$16,$5

	blez	$2,$L102
	lui	$2,%hi($LC3)

	lw	$19,%lo($LC2+4)($18)
	lw	$20,%lo($LC3)($2)
	lw	$21,%lo($LC3+4)($2)
	lw	$18,%lo($LC2)($18)
	move	$fp,$0
$L92:
	move	$4,$17
	move	$5,$16
	move	$6,$20
	jal	__divdf3
	move	$7,$21

	move	$4,$2
	move	$5,$3
	move	$6,$18
	move	$7,$19
	move	$16,$3
	jal	__gtdf2
	move	$17,$2

	bgtz	$2,$L92
	addiu	$fp,$fp,1

$L90:
	lui	$18,%hi($LC4)
	lw	$6,%lo($LC4)($18)
	lw	$7,%lo($LC4+4)($18)
	move	$4,$17
	jal	__ltdf2
	move	$5,$16

	bgez	$2,$L93
	lui	$2,%hi($LC3)

	lw	$19,%lo($LC4+4)($18)
	lw	$20,%lo($LC3)($2)
	lw	$21,%lo($LC3+4)($2)
	lw	$18,%lo($LC4)($18)
$L95:
	move	$4,$17
	move	$5,$16
	move	$6,$20
	jal	__muldf3
	move	$7,$21

	move	$4,$2
	move	$5,$3
	move	$6,$18
	move	$7,$19
	move	$16,$3
	jal	__ltdf2
	move	$17,$2

	bltz	$2,$L95
	addiu	$fp,$fp,-1

$L93:
	lui	$18,%hi($LC5)
	lw	$6,%lo($LC5)($18)
	lw	$7,%lo($LC5+4)($18)
	move	$4,$17
	jal	__subdf3
	move	$5,$16

	lw	$6,%lo($LC5)($18)
	lw	$7,%lo($LC5+4)($18)
	move	$4,$17
	move	$5,$16
	move	$17,$2
	jal	__adddf3
	move	$16,$3

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__divdf3
	move	$7,$3

	move	$6,$2
	move	$4,$2
	move	$7,$3
	move	$5,$3
	move	$16,$3
	jal	__muldf3
	move	$17,$2

	move	$21,$3
	move	$22,$2
	li	$20,1			# 0x1
	move	$19,$0
	move	$18,$0
	li	$23,81			# 0x51
$L96:
	jal	__floatsidf
	move	$4,$20

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__divdf3
	move	$7,$3

	move	$6,$2
	move	$4,$19
	move	$5,$18
	jal	__adddf3
	move	$7,$3

	move	$4,$17
	move	$5,$16
	move	$6,$22
	move	$7,$21
	move	$18,$3
	move	$19,$2
	jal	__muldf3
	addiu	$20,$20,2

	move	$16,$3
	.set	noat
	xor	$1,$20,$23
	bne	$1,$0,$L96
	.set	at
	move	$17,$2

	move	$6,$19
	move	$7,$18
	move	$5,$18
	jal	__adddf3
	move	$4,$19

	move	$4,$fp
	move	$16,$3
	jal	__floatsidf
	move	$17,$2

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__adddf3
	move	$7,$3

	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L102:
	b	$L90
	move	$fp,$0

	.set	macro
	.set	reorder
	.end	log.part.0
	.size	log.part.0, .-log.part.0
	.align	2
	.globl	read
	.set	nomips16
	.set	nomicromips
	.ent	read
	.type	read, @function
read:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$2,$0
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	read
	.size	read, .-read
	.align	2
	.globl	write
	.set	nomips16
	.set	nomicromips
	.ent	write
	.type	write, @function
write:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	write
	.size	write, .-write
	.align	2
	.globl	open
	.set	nomips16
	.set	nomicromips
	.ent	open
	.type	open, @function
open:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$6,8($sp)
	sw	$7,12($sp)
	li	$2,2			# 0x2
	li	$6,420			# 0x1a4
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	open
	.size	open, .-open
	.align	2
	.globl	close
	.set	nomips16
	.set	nomicromips
	.ent	close
	.type	close, @function
close:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,3			# 0x3
	move	$5,$0
	move	$6,$0
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	close
	.size	close, .-close
	.align	2
	.globl	lseek
	.set	nomips16
	.set	nomicromips
	.ent	lseek
	.type	lseek, @function
lseek:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,8			# 0x8
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	lseek
	.size	lseek, .-lseek
	.align	2
	.globl	time
	.set	nomips16
	.set	nomicromips
	.ent	time
	.type	time, @function
time:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$3,$4
	li	$2,201			# 0xc9
	move	$4,$0
	move	$5,$0
	move	$6,$0
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	beq	$3,$0,$L114
	sw	$2,0($3)
$L114:
	jr	$31
	.end	time
	.size	time, .-time
	.align	2
	.globl	rename
	.set	nomips16
	.set	nomicromips
	.ent	rename
	.type	rename, @function
rename:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,38			# 0x26
	move	$6,$0
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	rename
	.size	rename, .-rename
	.align	2
	.globl	mkdir
	.set	nomips16
	.set	nomicromips
	.ent	mkdir
	.type	mkdir, @function
mkdir:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,39			# 0x27
	move	$6,$0
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	mkdir
	.size	mkdir, .-mkdir
	.align	2
	.globl	remove
	.set	nomips16
	.set	nomicromips
	.ent	remove
	.type	remove, @function
remove:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	remove
	.size	remove, .-remove
	.align	2
	.globl	isatty
	.set	nomips16
	.set	nomicromips
	.ent	isatty
	.type	isatty, @function
isatty:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	isatty
	.size	isatty, .-isatty
	.align	2
	.globl	access
	.set	nomips16
	.set	nomicromips
	.ent	access
	.type	access, @function
access:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	access
	.size	access, .-access
	.align	2
	.globl	system
	.set	nomips16
	.set	nomicromips
	.ent	system
	.type	system, @function
system:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	system
	.size	system, .-system
	.align	2
	.globl	getenv
	.set	nomips16
	.set	nomicromips
	.ent	getenv
	.type	getenv, @function
getenv:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	getenv
	.size	getenv, .-getenv
	.align	2
	.globl	exit
	.set	nomips16
	.set	nomicromips
	.ent	exit
	.type	exit, @function
exit:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
$L123:
	b	$L123
	nop

	.set	macro
	.set	reorder
	.end	exit
	.size	exit, .-exit
	.align	2
	.globl	abort
	.set	nomips16
	.set	nomicromips
	.ent	abort
	.type	abort, @function
abort:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
$L125:
	b	$L125
	nop

	.set	macro
	.set	reorder
	.end	abort
	.size	abort, .-abort
	.align	2
	.globl	memcpy
	.set	nomips16
	.set	nomicromips
	.ent	memcpy
	.type	memcpy, @function
memcpy:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$3,$4,$5
	andi	$3,$3,0x3
	bne	$3,$0,$L133
	move	$2,$4

	sltu	$3,$6,4
	bne	$3,$0,$L133
	addiu	$4,$6,-4

	srl	$4,$4,2
	addiu	$4,$4,1
	sll	$4,$4,2
	addu	$3,$2,$4
	move	$8,$5
	move	$7,$2
$L131:
	lw	$9,0($8)
	addiu	$7,$7,4
	addiu	$8,$8,4
	.set	noat
	xor	$1,$7,$3
	bne	$1,$0,$L131
	.set	at
	sw	$9,-4($7)

	andi	$6,$6,0x3
	addu	$5,$5,$4
	bne	$6,$0,$L132
	addu	$7,$3,$6

$L139:
	jr	$31
	nop

$L133:
	move	$3,$2
	beq	$6,$0,$L139
	addu	$7,$3,$6

$L132:
	lbu	$6,0($5)
	addiu	$3,$3,1
	addiu	$5,$5,1
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L132
	.set	at
	sb	$6,-1($3)

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	memcpy
	.size	memcpy, .-memcpy
	.align	2
	.globl	memmove
	.set	nomips16
	.set	nomicromips
	.ent	memmove
	.type	memmove, @function
memmove:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sltu	$3,$4,$5
	beq	$3,$0,$L141
	move	$2,$4

	beq	$6,$0,$L153
	addu	$6,$4,$6

	move	$3,$4
$L143:
	lbu	$4,0($5)
	addiu	$3,$3,1
	addiu	$5,$5,1
	.set	noat
	xor	$1,$6,$3
	bne	$1,$0,$L143
	.set	at
	sb	$4,-1($3)

$L153:
	jr	$31
	nop

$L141:
	addu	$3,$4,$6
	beq	$6,$0,$L153
	addu	$5,$5,$6

$L145:
	lbu	$4,-1($5)
	addiu	$3,$3,-1
	addiu	$5,$5,-1
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L145
	.set	at
	sb	$4,0($3)

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	memmove
	.size	memmove, .-memmove
	.align	2
	.globl	memset
	.set	nomips16
	.set	nomicromips
	.ent	memset
	.type	memset, @function
memset:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L176
	move	$2,$4

	andi	$3,$4,0x3
	beq	$3,$0,$L163
	andi	$8,$5,0x00ff

	b	$L158
	move	$3,$4

$L174:
	beq	$7,$0,$L156
	nop

$L158:
	addiu	$3,$3,1
	addiu	$6,$6,-1
	andi	$7,$3,0x3
	bne	$6,$0,$L174
	sb	$8,-1($3)

$L176:
	jr	$31
	nop

$L163:
	move	$3,$4
$L156:
	andi	$5,$5,0xff
	sll	$7,$5,8
	addu	$7,$7,$5
	sll	$5,$7,16
	sltu	$4,$6,4
	addu	$7,$7,$5
	bne	$4,$0,$L162
	move	$5,$3

	addiu	$5,$6,-4
	srl	$5,$5,2
	addiu	$5,$5,1
	sll	$5,$5,2
	addu	$5,$3,$5
$L159:
	addiu	$3,$3,4
	.set	noat
	xor	$1,$5,$3
	bne	$1,$0,$L159
	.set	at
	sw	$7,-4($3)

	andi	$6,$6,0x3
	beq	$6,$0,$L175
	nop

$L162:
	addu	$6,$5,$6
$L160:
	addiu	$5,$5,1
	.set	noat
	xor	$1,$5,$6
	bne	$1,$0,$L160
	.set	at
	sb	$8,-1($5)

$L175:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	memset
	.size	memset, .-memset
	.align	2
	.globl	memcmp
	.set	nomips16
	.set	nomicromips
	.ent	memcmp
	.type	memcmp, @function
memcmp:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L181
	addu	$6,$5,$6

	b	$L183
	lbu	$3,0($5)

$L179:
	.set	noat
	xor	$1,$5,$6
	beq	$1,$0,$L181
	.set	at
	addiu	$4,$4,1

	lbu	$3,0($5)
$L183:
	lbu	$2,0($4)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L179
	.set	at
	addiu	$5,$5,1

	jr	$31
	subu	$2,$2,$3

$L181:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	memcmp
	.size	memcmp, .-memcmp
	.align	2
	.globl	memchr
	.set	nomips16
	.set	nomicromips
	.ent	memchr
	.type	memchr, @function
memchr:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L187
	move	$2,$4

	andi	$5,$5,0x00ff
	b	$L186
	addu	$6,$4,$6

$L189:
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L187
	.set	at
	nop

$L186:
	lbu	$3,0($2)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L189
	.set	at
	addiu	$2,$2,1

	jr	$31
	addiu	$2,$2,-1

$L187:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	memchr
	.size	memchr, .-memchr
	.align	2
	.globl	strlen
	.set	nomips16
	.set	nomicromips
	.ent	strlen
	.type	strlen, @function
strlen:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$2,0($4)
	beq	$2,$0,$L193
	nop

	move	$2,$4
$L192:
	lb	$3,1($2)
	bne	$3,$0,$L192
	addiu	$2,$2,1

	jr	$31
	subu	$2,$2,$4

$L193:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	strlen
	.size	strlen, .-strlen
	.align	2
	.globl	strcpy
	.set	nomips16
	.set	nomicromips
	.ent	strcpy
	.type	strcpy, @function
strcpy:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$2,$4
	move	$3,$4
$L196:
	lb	$6,0($5)
	addiu	$3,$3,1
	addiu	$5,$5,1
	bne	$6,$0,$L196
	sb	$6,-1($3)

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	strcpy
	.size	strcpy, .-strcpy
	.align	2
	.globl	strncpy
	.set	nomips16
	.set	nomicromips
	.ent	strncpy
	.type	strncpy, @function
strncpy:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$2,$4
	bne	$6,$0,$L199
	move	$3,$0

	b	$L208
	nop

$L201:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L209
	.set	at
	sb	$7,0($8)

$L199:
	addu	$7,$5,$3
	lb	$7,0($7)
	bne	$7,$0,$L201
	addu	$8,$2,$3

	sltu	$4,$3,$6
	beq	$4,$0,$L209
	move	$3,$8

	addu	$6,$2,$6
$L202:
	sb	$0,0($3)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$6,$3
	bne	$1,$0,$L202
	.set	at
	nop

$L209:
	jr	$31
	nop

$L208:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	strncpy
	.size	strncpy, .-strncpy
	.align	2
	.globl	strcat
	.set	nomips16
	.set	nomicromips
	.ent	strcat
	.type	strcat, @function
strcat:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$3,0($4)
	beq	$3,$0,$L214
	move	$2,$4

	move	$3,$4
$L212:
	lb	$6,1($3)
	bne	$6,$0,$L212
	addiu	$3,$3,1

$L213:
	lb	$6,0($5)
	addiu	$3,$3,1
	addiu	$5,$5,1
	bne	$6,$0,$L213
	sb	$6,-1($3)

$L218:
	jr	$31
	nop

$L214:
	lb	$6,0($5)
	move	$3,$4
	addiu	$3,$3,1
	addiu	$5,$5,1
	bne	$6,$0,$L213
	sb	$6,-1($3)

	b	$L218
	nop

	.set	macro
	.set	reorder
	.end	strcat
	.size	strcat, .-strcat
	.align	2
	.globl	strncat
	.set	nomips16
	.set	nomicromips
	.ent	strncat
	.type	strncat, @function
strncat:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$3,0($4)
	beq	$3,$0,$L225
	move	$2,$4

	move	$3,$4
$L221:
	lb	$7,1($3)
	bne	$7,$0,$L221
	addiu	$3,$3,1

$L220:
	beq	$6,$0,$L222
	addu	$6,$5,$6

	b	$L230
	lb	$7,0($5)

$L224:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L222
	.set	at
	sb	$7,-1($3)

	lb	$7,0($5)
$L230:
	bne	$7,$0,$L224
	addiu	$5,$5,1

$L222:
	jr	$31
	sb	$0,0($3)

$L225:
	b	$L220
	move	$3,$4

	.set	macro
	.set	reorder
	.end	strncat
	.size	strncat, .-strncat
	.align	2
	.globl	strcmp
	.set	nomips16
	.set	nomicromips
	.ent	strcmp
	.type	strcmp, @function
strcmp:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$3,0($4)
	bne	$3,$0,$L232
	nop

	b	$L237
	lb	$2,0($5)

$L234:
	lb	$3,0($4)
	beq	$3,$0,$L238
	nop

	move	$5,$6
$L232:
	lb	$2,0($5)
	addiu	$4,$4,1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L234
	.set	at
	addiu	$6,$5,1

	andi	$3,$3,0x00ff
	andi	$2,$2,0x00ff
$L239:
	jr	$31
	subu	$2,$3,$2

$L238:
	lb	$2,1($5)
	andi	$2,$2,0x00ff
	jr	$31
	subu	$2,$3,$2

$L237:
	b	$L239
	andi	$2,$2,0x00ff

	.set	macro
	.set	reorder
	.end	strcmp
	.size	strcmp, .-strcmp
	.align	2
	.globl	strncmp
	.set	nomips16
	.set	nomicromips
	.ent	strncmp
	.type	strncmp, @function
strncmp:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L245
	addu	$6,$5,$6

	b	$L247
	lb	$3,0($5)

$L242:
	beq	$2,$0,$L245
	nop

	.set	noat
	xor	$1,$5,$6
	beq	$1,$0,$L245
	.set	at
	addiu	$4,$4,1

	lb	$3,0($5)
$L247:
	lb	$2,0($4)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L242
	.set	at
	addiu	$5,$5,1

	andi	$3,$3,0x00ff
	andi	$2,$2,0x00ff
	jr	$31
	subu	$2,$2,$3

$L245:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	strncmp
	.size	strncmp, .-strncmp
	.align	2
	.globl	toupper
	.set	nomips16
	.set	nomicromips
	.ent	toupper
	.type	toupper, @function
toupper:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$3,$4,-97
	sltu	$3,$3,26
	beq	$3,$0,$L250
	move	$2,$4

	addiu	$2,$4,-32
$L250:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	toupper
	.size	toupper, .-toupper
	.align	2
	.globl	tolower
	.set	nomips16
	.set	nomicromips
	.ent	tolower
	.type	tolower, @function
tolower:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$3,$4,-65
	sltu	$3,$3,26
	beq	$3,$0,$L253
	move	$2,$4

	addiu	$2,$4,32
$L253:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	tolower
	.size	tolower, .-tolower
	.align	2
	.globl	isspace
	.set	nomips16
	.set	nomicromips
	.ent	isspace
	.type	isspace, @function
isspace:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,32			# 0x20
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L256
	.set	at
	addiu	$4,$4,-9

	jr	$31
	sltu	$2,$4,5

$L256:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	isspace
	.size	isspace, .-isspace
	.align	2
	.globl	isdigit
	.set	nomips16
	.set	nomicromips
	.ent	isdigit
	.type	isdigit, @function
isdigit:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$4,-48
	jr	$31
	sltu	$2,$2,10

	.set	macro
	.set	reorder
	.end	isdigit
	.size	isdigit, .-isdigit
	.align	2
	.globl	isupper
	.set	nomips16
	.set	nomicromips
	.ent	isupper
	.type	isupper, @function
isupper:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$4,-65
	jr	$31
	sltu	$2,$2,26

	.set	macro
	.set	reorder
	.end	isupper
	.size	isupper, .-isupper
	.align	2
	.globl	islower
	.set	nomips16
	.set	nomicromips
	.ent	islower
	.type	islower, @function
islower:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$4,-97
	jr	$31
	sltu	$2,$2,26

	.set	macro
	.set	reorder
	.end	islower
	.size	islower, .-islower
	.align	2
	.globl	isalpha
	.set	nomips16
	.set	nomicromips
	.ent	isalpha
	.type	isalpha, @function
isalpha:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,-33			# 0xffffffffffffffdf
	and	$2,$4,$2
	addiu	$2,$2,-65
	jr	$31
	sltu	$2,$2,26

	.set	macro
	.set	reorder
	.end	isalpha
	.size	isalpha, .-isalpha
	.align	2
	.globl	isalnum
	.set	nomips16
	.set	nomicromips
	.ent	isalnum
	.type	isalnum, @function
isalnum:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$3,-33			# 0xffffffffffffffdf
	and	$3,$4,$3
	addiu	$3,$3,-65
	sltu	$3,$3,26
	bne	$3,$0,$L263
	addiu	$4,$4,-48

	jr	$31
	sltu	$2,$4,10

$L263:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	isalnum
	.size	isalnum, .-isalnum
	.align	2
	.globl	isprint
	.set	nomips16
	.set	nomicromips
	.ent	isprint
	.type	isprint, @function
isprint:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$4,-32
	jr	$31
	sltu	$2,$2,95

	.set	macro
	.set	reorder
	.end	isprint
	.size	isprint, .-isprint
	.align	2
	.globl	isxdigit
	.set	nomips16
	.set	nomicromips
	.ent	isxdigit
	.type	isxdigit, @function
isxdigit:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$4,-48
	sltu	$2,$2,10
	bne	$2,$0,$L267
	nop

	li	$2,-33			# 0xffffffffffffffdf
	and	$2,$4,$2
	addiu	$2,$2,-65
	jr	$31
	sltu	$2,$2,6

$L267:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	isxdigit
	.size	isxdigit, .-isxdigit
	.align	2
	.globl	strcasecmp
	.set	nomips16
	.set	nomicromips
	.ent	strcasecmp
	.type	strcasecmp, @function
strcasecmp:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$2,0($4)
	bne	$2,$0,$L269
	nop

	b	$L283
	lbu	$7,0($5)

$L286:
	lbu	$7,0($5)
	addiu	$3,$7,-65
	sltu	$3,$3,26
	beq	$3,$0,$L277
	addiu	$8,$2,32

$L287:
	addiu	$9,$7,32
	.set	noat
	xor	$1,$9,$8
	bne	$1,$0,$L284
	.set	at
	addiu	$4,$4,1

$L273:
	lb	$2,0($4)
	beq	$2,$0,$L285
	addiu	$3,$5,1

	move	$5,$3
$L269:
	andi	$2,$2,0x00ff
	addiu	$6,$2,-65
	sltu	$6,$6,26
	bne	$6,$0,$L286
	nop

	lbu	$7,0($5)
	addiu	$3,$7,-65
	sltu	$3,$3,26
	bne	$3,$0,$L287
	move	$8,$2

$L277:
	move	$9,$7
	.set	noat
	xor	$1,$9,$8
	beq	$1,$0,$L273
	.set	at
	addiu	$4,$4,1

$L284:
	beq	$6,$0,$L270
	nop

	addiu	$2,$2,32
$L270:
	beq	$3,$0,$L274
	nop

	addiu	$7,$7,32
$L274:
	jr	$31
	subu	$2,$2,$7

$L285:
	lbu	$7,1($5)
	addiu	$3,$7,-65
	b	$L270
	sltu	$3,$3,26

$L283:
	addiu	$3,$7,-65
	b	$L270
	sltu	$3,$3,26

	.set	macro
	.set	reorder
	.end	strcasecmp
	.size	strcasecmp, .-strcasecmp
	.align	2
	.globl	strncasecmp
	.set	nomips16
	.set	nomicromips
	.ent	strncasecmp
	.type	strncasecmp, @function
strncasecmp:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L297
	addu	$6,$5,$6

$L296:
	lbu	$2,0($4)
	lbu	$7,0($5)
	addiu	$8,$2,-65
	addiu	$3,$7,-65
	sltu	$8,$8,26
	addiu	$5,$5,1
	beq	$8,$0,$L290
	sltu	$9,$3,26

	bne	$9,$0,$L291
	addiu	$2,$2,32

	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L292
	.set	at
	nop

$L293:
	.set	noat
	xor	$1,$5,$6
	bne	$1,$0,$L296
	.set	at
	addiu	$4,$4,1

$L297:
	jr	$31
	move	$2,$0

$L291:
	addiu	$7,$7,32
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L293
	.set	at
	nop

$L292:
	jr	$31
	subu	$2,$2,$7

$L290:
	bne	$9,$0,$L291
	nop

	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L292
	.set	at
	nop

	bne	$2,$0,$L293
	nop

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	strncasecmp
	.size	strncasecmp, .-strncasecmp
	.align	2
	.globl	strchr
	.set	nomips16
	.set	nomicromips
	.ent	strchr
	.type	strchr, @function
strchr:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$5,$5,24
	lb	$2,0($4)
	sra	$5,$5,24
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L307
	.set	at
	nop

	jr	$31
	move	$2,$4

$L311:
	lb	$2,0($4)
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L308
	.set	at
	nop

$L307:
	bne	$2,$0,$L311
	addiu	$4,$4,1

	jr	$31
	move	$2,$0

$L308:
	move	$2,$4
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	strchr
	.size	strchr, .-strchr
	.align	2
	.globl	strrchr
	.set	nomips16
	.set	nomicromips
	.ent	strrchr
	.type	strrchr, @function
strrchr:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$5,$5,24
	sra	$5,$5,24
	b	$L316
	move	$2,$0

$L318:
	addiu	$4,$4,1
$L316:
	lb	$3,0($4)
	xor	$6,$3,$5
	bne	$3,$0,$L318
	movz	$2,$4,$6

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	strrchr
	.size	strrchr, .-strrchr
	.align	2
	.globl	strstr
	.set	nomips16
	.set	nomicromips
	.ent	strstr
	.type	strstr, @function
strstr:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$3,0($5)
	beq	$3,$0,$L336
	move	$2,$4

	move	$3,$5
$L321:
	lb	$4,1($3)
	bne	$4,$0,$L321
	addiu	$3,$3,1

	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L336
	.set	at
	subu	$9,$3,$5

	lb	$3,0($2)
	beq	$3,$0,$L334
	addu	$9,$2,$9

$L324:
	move	$6,$5
	b	$L325
	move	$3,$2

$L323:
	beq	$7,$0,$L336
	nop

	.set	noat
	xor	$1,$3,$9
	beq	$1,$0,$L336
	.set	at
	addiu	$6,$6,1

$L325:
	lb	$8,0($3)
	lb	$7,0($6)
	.set	noat
	xor	$1,$7,$8
	beq	$1,$0,$L323
	.set	at
	addiu	$3,$3,1

	lb	$3,1($2)
	addiu	$9,$9,1
	bne	$3,$0,$L324
	addiu	$2,$2,1

$L334:
	jr	$31
	move	$2,$0

$L336:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	strstr
	.size	strstr, .-strstr
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"error\000"
	.text
	.align	2
	.globl	strerror
	.set	nomips16
	.set	nomicromips
	.ent	strerror
	.type	strerror, @function
strerror:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi($LC6)
	jr	$31
	addiu	$2,$2,%lo($LC6)

	.set	macro
	.set	reorder
	.end	strerror
	.size	strerror, .-strerror
	.align	2
	.globl	malloc
	.set	nomips16
	.set	nomicromips
	.ent	malloc
	.type	malloc, @function
malloc:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$8,%hi(heap_ptr)
	lw	$2,%lo(heap_ptr)($8)
	beq	$2,$0,$L348
	li	$2,268435456			# 0x10000000

$L339:
	lui	$6,%hi(free_list)
	lw	$2,%lo(free_list)($6)
	addiu	$5,$4,15
	li	$3,-16			# 0xfffffffffffffff0
	beq	$2,$0,$L340
	and	$5,$5,$3

	sll	$7,$5,1
	addiu	$6,$6,%lo(free_list)
$L343:
	lw	$3,0($2)
	sltu	$4,$3,$5
	bne	$4,$0,$L341
	sltu	$3,$7,$3

	beq	$3,$0,$L349
	nop

$L341:
	addiu	$6,$2,4
	lw	$2,4($2)
	bne	$2,$0,$L343
	nop

$L340:
	lw	$2,%lo(heap_ptr)($8)
	addiu	$3,$5,8
	addu	$3,$2,$3
	sw	$5,0($2)
	sw	$3,%lo(heap_ptr)($8)
	jr	$31
	addiu	$2,$2,8

$L349:
	lw	$3,4($2)
	addiu	$2,$2,8
	jr	$31
	sw	$3,0($6)

$L348:
	b	$L339
	sw	$2,%lo(heap_ptr)($8)

	.set	macro
	.set	reorder
	.end	malloc
	.size	malloc, .-malloc
	.align	2
	.globl	strdup
	.set	nomips16
	.set	nomicromips
	.ent	strdup
	.type	strdup, @function
strdup:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	lb	$2,0($4)
	beq	$2,$0,$L360
	move	$10,$4

	move	$2,$4
$L352:
	lb	$3,1($2)
	bne	$3,$0,$L352
	addiu	$2,$2,1

	subu	$9,$2,$10
	addiu	$11,$9,1
$L351:
	jal	malloc
	move	$4,$11

	beq	$2,$0,$L367
	lw	$31,20($sp)

	or	$3,$10,$2
	andi	$3,$3,0x3
	beq	$3,$0,$L366
	sltu	$3,$11,4

$L361:
	move	$5,$2
$L354:
	beq	$11,$0,$L367
	lw	$31,20($sp)

	addiu	$3,$9,1
	addu	$3,$10,$3
$L359:
	lbu	$4,0($10)
	addiu	$10,$10,1
	addiu	$5,$5,1
	.set	noat
	xor	$1,$3,$10
	bne	$1,$0,$L359
	.set	at
	sb	$4,-1($5)

	lw	$31,20($sp)
$L367:
	jr	$31
	addiu	$sp,$sp,24

$L366:
	bne	$3,$0,$L361
	addiu	$5,$11,-4

	srl	$5,$5,2
	addiu	$5,$5,1
	sll	$5,$5,2
	addu	$4,$10,$5
	move	$3,$2
$L358:
	lw	$6,0($10)
	addiu	$10,$10,4
	addiu	$3,$3,4
	.set	noat
	xor	$1,$10,$4
	bne	$1,$0,$L358
	.set	at
	sw	$6,-4($3)

	andi	$11,$11,0x3
	addu	$5,$2,$5
	b	$L354
	addiu	$9,$11,-1

$L360:
	li	$11,1			# 0x1
	b	$L351
	move	$9,$0

	.set	macro
	.set	reorder
	.end	strdup
	.size	strdup, .-strdup
	.align	2
	.globl	free
	.set	nomips16
	.set	nomicromips
	.ent	free
	.type	free, @function
free:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L373
	lui	$2,%hi(free_list)

	lw	$5,%lo(free_list)($2)
	addiu	$3,$4,-8
	sw	$5,-4($4)
	sw	$3,%lo(free_list)($2)
$L373:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	free
	.size	free, .-free
	.align	2
	.globl	calloc
	.set	nomips16
	.set	nomicromips
	.ent	calloc
	.type	calloc, @function
calloc:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	multu	$4,$5
	mflo	$9
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	malloc
	move	$4,$9

	beq	$9,$0,$L396
	lw	$31,20($sp)

	andi	$3,$2,0x3
	beq	$3,$0,$L383
	move	$3,$2

	b	$L398
	addiu	$3,$3,1

$L394:
	beq	$4,$0,$L397
	sltu	$4,$9,4

	addiu	$3,$3,1
$L398:
	addiu	$9,$9,-1
	andi	$4,$3,0x3
	bne	$9,$0,$L394
	sb	$0,-1($3)

	lw	$31,20($sp)
$L396:
	jr	$31
	addiu	$sp,$sp,24

$L383:
	sltu	$4,$9,4
$L397:
	bne	$4,$0,$L382
	move	$4,$3

	addiu	$4,$9,-4
	srl	$4,$4,2
	addiu	$4,$4,1
	sll	$4,$4,2
	addu	$4,$3,$4
$L379:
	addiu	$3,$3,4
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L379
	.set	at
	sw	$0,-4($3)

	andi	$9,$9,0x3
	beq	$9,$0,$L396
	lw	$31,20($sp)

$L382:
	addu	$9,$4,$9
$L380:
	addiu	$4,$4,1
	.set	noat
	xor	$1,$4,$9
	bne	$1,$0,$L380
	.set	at
	sb	$0,-1($4)

	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	calloc
	.size	calloc, .-calloc
	.align	2
	.globl	realloc
	.set	nomips16
	.set	nomicromips
	.ent	realloc
	.type	realloc, @function
realloc:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$9,$4
	beq	$9,$0,$L417
	move	$4,$5

	lw	$10,-8($9)
	sltu	$2,$10,$5
	bne	$2,$0,$L418
	move	$2,$9

	jr	$31
	nop

$L418:
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	malloc
	nop

	or	$3,$9,$2
	andi	$3,$3,0x3
	bne	$3,$0,$L419
	move	$3,$2

	sltu	$3,$10,4
	bne	$3,$0,$L409
	addiu	$3,$10,-4

	srl	$3,$3,2
	addiu	$3,$3,1
	sll	$3,$3,2
	addu	$6,$9,$3
	move	$4,$2
$L406:
	lw	$5,0($9)
	addiu	$9,$9,4
	addiu	$4,$4,4
	.set	noat
	xor	$1,$9,$6
	bne	$1,$0,$L406
	.set	at
	sw	$5,-4($4)

	addu	$3,$2,$3
	b	$L405
	andi	$10,$10,0x3

$L409:
	move	$3,$2
$L405:
$L419:
	beq	$10,$0,$L399
	addu	$5,$9,$10

$L407:
	lbu	$4,0($9)
	addiu	$9,$9,1
	addiu	$3,$3,1
	.set	noat
	xor	$1,$9,$5
	bne	$1,$0,$L407
	.set	at
	sb	$4,-1($3)

$L399:
	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

$L417:
	j	malloc
	nop

	.set	macro
	.set	reorder
	.end	realloc
	.size	realloc, .-realloc
	.align	2
	.globl	strtol
	.set	nomips16
	.set	nomicromips
	.ent	strtol
	.type	strtol, @function
strtol:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$7,32			# 0x20
$L426:
	lb	$2,0($4)
	addiu	$3,$2,-9
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L423
	.set	at
	sltu	$3,$3,5

	bne	$3,$0,$L423
	nop

	li	$3,45			# 0x2d
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L449
	.set	at
	li	$3,43			# 0x2b

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L450
	.set	at
	move	$10,$0

$L427:
	beq	$6,$0,$L455
	li	$3,48			# 0x30

$L453:
	li	$3,16			# 0x10
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L451
	.set	at
	li	$3,48			# 0x30

$L429:
	move	$2,$0
$L436:
	lb	$7,0($4)
	addiu	$3,$7,-48
	addiu	$8,$7,-65
	sltu	$9,$3,10
	bne	$9,$0,$L432
	sltu	$8,$8,26

	addiu	$3,$7,-97
	beq	$8,$0,$L452
	sltu	$3,$3,26

	addiu	$7,$7,32
	addiu	$3,$7,-87
$L432:
	slt	$7,$3,$6
	beq	$7,$0,$L435
	nop

	multu	$6,$2
	mflo	$7
	addiu	$4,$4,1
	b	$L436
	addu	$2,$7,$3

$L423:
	b	$L426
	addiu	$4,$4,1

$L450:
	lb	$2,1($4)
	bne	$6,$0,$L453
	addiu	$4,$4,1

	li	$3,48			# 0x30
$L455:
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L454
	.set	at
	li	$6,10			# 0xa

	b	$L436
	move	$2,$0

$L452:
	bne	$3,$0,$L432
	addiu	$3,$7,-87

$L435:
	beq	$5,$0,$L437
	nop

	sw	$4,0($5)
$L437:
	beq	$10,$0,$L456
	nop

	subu	$2,$0,$2
$L456:
	jr	$31
	nop

$L449:
	lb	$2,1($4)
	li	$10,1			# 0x1
	b	$L427
	addiu	$4,$4,1

$L451:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L436
	.set	at
	move	$2,$0

	lbu	$2,1($4)
	li	$3,88			# 0x58
	andi	$2,$2,0xdf
	sll	$2,$2,24
	sra	$2,$2,24
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L436
	.set	at
	move	$2,$0

$L430:
	addiu	$4,$4,2
	b	$L429
	li	$6,16			# 0x10

$L454:
	lbu	$2,1($4)
	li	$3,88			# 0x58
	andi	$2,$2,0xdf
	sll	$2,$2,24
	sra	$2,$2,24
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L430
	.set	at
	nop

	b	$L429
	li	$6,8			# 0x8

	.set	macro
	.set	reorder
	.end	strtol
	.size	strtol, .-strtol
	.align	2
	.globl	strtoul
	.set	nomips16
	.set	nomicromips
	.ent	strtoul
	.type	strtoul, @function
strtoul:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	strtol
	nop

	.set	macro
	.set	reorder
	.end	strtoul
	.size	strtoul, .-strtoul
	.align	2
	.globl	atoi
	.set	nomips16
	.set	nomicromips
	.ent	atoi
	.type	atoi, @function
atoi:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$6,10			# 0xa
	j	strtol
	move	$5,$0

	.set	macro
	.set	reorder
	.end	atoi
	.size	atoi, .-atoi
	.align	2
	.globl	atol
	.set	nomips16
	.set	nomicromips
	.ent	atol
	.type	atol, @function
atol:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$6,10			# 0xa
	j	strtol
	move	$5,$0

	.set	macro
	.set	reorder
	.end	atol
	.size	atol, .-atol
	.align	2
	.globl	atof
	.set	nomips16
	.set	nomicromips
	.ent	atof
	.type	atof, @function
atof:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,24($sp)
	sw	$31,52($sp)
	move	$17,$4
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$16,20($sp)
	li	$4,32			# 0x20
$L464:
	lb	$3,0($17)
	addiu	$2,$3,-9
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L461
	.set	at
	sltu	$2,$2,5

	bne	$2,$0,$L461
	nop

	li	$2,45			# 0x2d
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L462
	.set	at
	addiu	$21,$3,-48

	sltu	$2,$21,10
	beq	$2,$0,$L470
	move	$20,$0

$L478:
	lui	$2,%hi($LC8)
	lw	$18,%lo($LC8)($2)
	lw	$19,%lo($LC8+4)($2)
	move	$22,$0
	move	$16,$0
$L466:
	move	$5,$16
	move	$4,$22
	move	$6,$18
	jal	__muldf3
	move	$7,$19

	move	$4,$21
	move	$16,$3
	jal	__floatsidf
	move	$21,$2

	move	$4,$2
	move	$6,$21
	move	$7,$16
	jal	__adddf3
	move	$5,$3

	addiu	$17,$17,1
	move	$16,$3
	lb	$3,0($17)
	addiu	$21,$3,-48
	sltu	$4,$21,10
	bne	$4,$0,$L466
	move	$22,$2

	li	$2,46			# 0x2e
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L477
	.set	at
	nop

$L467:
	beq	$20,$0,$L479
	lw	$31,52($sp)

	li	$2,-2147483648			# 0xffffffff80000000
	xor	$16,$16,$2
$L479:
	lw	$23,48($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	move	$2,$22
	move	$3,$16
	lw	$22,44($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L461:
	b	$L464
	addiu	$17,$17,1

$L462:
	lb	$3,1($17)
	li	$20,1			# 0x1
	addiu	$21,$3,-48
	sltu	$2,$21,10
	bne	$2,$0,$L478
	addiu	$17,$17,1

$L470:
	li	$2,46			# 0x2e
	move	$22,$0
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L467
	.set	at
	move	$16,$0

$L477:
	lb	$4,1($17)
	addiu	$4,$4,-48
	sltu	$2,$4,10
	beq	$2,$0,$L467
	addiu	$17,$17,1

	lui	$3,%hi($LC7)
	lui	$2,%hi($LC8)
	lw	$21,%lo($LC7)($3)
	lw	$23,%lo($LC7+4)($3)
	lw	$18,%lo($LC8)($2)
	lw	$19,%lo($LC8+4)($2)
$L468:
	jal	__floatsidf
	addiu	$17,$17,1

	move	$4,$2
	move	$6,$21
	move	$7,$23
	jal	__muldf3
	move	$5,$3

	move	$6,$2
	move	$4,$22
	move	$5,$16
	jal	__adddf3
	move	$7,$3

	move	$4,$21
	move	$5,$23
	move	$6,$18
	move	$7,$19
	move	$16,$3
	jal	__divdf3
	move	$22,$2

	lb	$4,0($17)
	move	$21,$2
	addiu	$4,$4,-48
	sltu	$2,$4,10
	bne	$2,$0,$L468
	move	$23,$3

	b	$L467
	nop

	.set	macro
	.set	reorder
	.end	atof
	.size	atof, .-atof
	.align	2
	.globl	abs
	.set	nomips16
	.set	nomicromips
	.ent	abs
	.type	abs, @function
abs:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$4,$L482
	move	$2,$4

	jr	$31
	nop

$L482:
	jr	$31
	subu	$2,$0,$4

	.set	macro
	.set	reorder
	.end	abs
	.size	abs, .-abs
	.align	2
	.globl	labs
	.set	nomips16
	.set	nomicromips
	.ent	labs
	.type	labs, @function
labs:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$4,$L487
	move	$2,$4

	jr	$31
	nop

$L487:
	jr	$31
	subu	$2,$0,$4

	.set	macro
	.set	reorder
	.end	labs
	.size	labs, .-labs
	.align	2
	.globl	rand
	.set	nomips16
	.set	nomicromips
	.ent	rand
	.type	rand, @function
rand:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(rand_state)
	lw	$3,%lo(rand_state)($4)
	li	$2,1103495168			# 0x41c60000
	addiu	$2,$2,20077
	multu	$3,$2
	mflo	$3
	addiu	$3,$3,12345
	srl	$2,$3,16
	sw	$3,%lo(rand_state)($4)
	jr	$31
	andi	$2,$2,0x7fff

	.set	macro
	.set	reorder
	.end	rand
	.size	rand, .-rand
	.align	2
	.globl	srand
	.set	nomips16
	.set	nomicromips
	.ent	srand
	.type	srand, @function
srand:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(rand_state)
	jr	$31
	sw	$4,%lo(rand_state)($2)

	.set	macro
	.set	reorder
	.end	srand
	.size	srand, .-srand
	.align	2
	.globl	qsort
	.set	nomips16
	.set	nomicromips
	.ent	qsort
	.type	qsort, @function
qsort:
	.frame	$sp,336,$31		# vars= 280, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-336
	sw	$fp,328($sp)
	srl	$fp,$5,1
	sw	$31,332($sp)
	sw	$23,324($sp)
	sw	$22,320($sp)
	sw	$21,316($sp)
	sw	$20,312($sp)
	sw	$19,308($sp)
	sw	$18,304($sp)
	sw	$17,300($sp)
	sw	$16,296($sp)
	sw	$5,340($sp)
	beq	$fp,$0,$L492
	sw	$4,336($sp)

	addiu	$19,$6,-4
	srl	$19,$19,2
	addiu	$19,$19,1
	sll	$19,$19,2
	addiu	$2,$sp,16
	addu	$2,$2,$19
	sw	$2,276($sp)
	sltu	$2,$6,4
	sw	$2,272($sp)
	andi	$2,$6,0x3
	move	$20,$6
	move	$18,$7
	sw	$2,284($sp)
$L494:
	lw	$2,340($sp)
$L551:
	sltu	$2,$fp,$2
	beq	$2,$0,$L547
	multu	$20,$fp
	mflo	$16

	lw	$2,336($sp)
	sw	$fp,288($sp)
	sw	$2,292($sp)
	addu	$2,$2,$16
	sw	$2,280($sp)
$L514:
	lw	$3,280($sp)
	andi	$7,$3,0x3
	bne	$7,$0,$L521
	lw	$2,280($sp)

	lw	$2,272($sp)
	bne	$2,$0,$L548
	move	$2,$3

	lw	$4,280($sp)
	addiu	$5,$sp,16
	addu	$2,$4,$19
$L500:
	lw	$6,0($4)
	addiu	$4,$4,4
	addiu	$5,$5,4
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L500
	.set	at
	sw	$6,-4($5)

	lw	$5,284($sp)
	lw	$4,276($sp)
$L495:
	beq	$5,$0,$L502
	addu	$6,$2,$5

$L501:
	lbu	$5,0($2)
	addiu	$2,$2,1
	addiu	$4,$4,1
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L501
	.set	at
	sb	$5,-1($4)

$L502:
	lw	$2,288($sp)
	sltu	$2,$2,$fp
	bne	$2,$0,$L499
	nop

	lw	$21,292($sp)
	lw	$22,280($sp)
	lw	$23,288($sp)
$L498:
	addiu	$5,$sp,16
	jalr	$18
	move	$4,$21

	move	$17,$21
	subu	$23,$23,$fp
	blez	$2,$L549
	move	$3,$22

	or	$2,$22,$21
	andi	$2,$2,0x3
	bne	$2,$0,$L550
	move	$2,$21

	lw	$2,272($sp)
	bne	$2,$0,$L523
	move	$2,$21

	addu	$2,$21,$19
	move	$5,$22
	move	$3,$21
$L507:
	lw	$6,0($3)
	addiu	$3,$3,4
	addiu	$5,$5,4
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L507
	.set	at
	sw	$6,-4($5)

	lw	$5,284($sp)
	addu	$3,$22,$19
$L503:
	beq	$5,$0,$L509
	addu	$6,$2,$5

$L508:
	lbu	$5,0($2)
	addiu	$2,$2,1
	addiu	$3,$3,1
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L508
	.set	at
	sb	$5,-1($3)

$L509:
	sltu	$2,$23,$fp
	subu	$22,$22,$16
	beq	$2,$0,$L498
	subu	$21,$21,$16

	andi	$7,$17,0x3
	move	$3,$17
$L499:
	bne	$7,$0,$L524
	nop

	lw	$2,272($sp)
	bne	$2,$0,$L524
	nop

	move	$4,$3
	addiu	$2,$sp,16
$L512:
	lw	$5,0($2)
	addiu	$2,$2,4
	sw	$5,0($4)
	lw	$5,276($sp)
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L512
	.set	at
	addiu	$4,$4,4

	lw	$4,284($sp)
	addu	$3,$3,$19
	move	$2,$5
$L511:
	beq	$4,$0,$L517
	addu	$5,$2,$4

$L516:
	lbu	$4,0($2)
	addiu	$2,$2,1
	addiu	$3,$3,1
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L516
	.set	at
	sb	$4,-1($3)

$L517:
	lw	$3,280($sp)
	lw	$2,288($sp)
	addu	$3,$3,$20
	sw	$3,280($sp)
	lw	$3,292($sp)
	addiu	$2,$2,1
	addu	$3,$3,$20
	sw	$3,292($sp)
	lw	$3,340($sp)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L514
	.set	at
	sw	$2,288($sp)

	srl	$fp,$fp,1
	bne	$fp,$0,$L551
	lw	$2,340($sp)

$L492:
	lw	$31,332($sp)
	lw	$fp,328($sp)
	lw	$23,324($sp)
	lw	$22,320($sp)
	lw	$21,316($sp)
	lw	$20,312($sp)
	lw	$19,308($sp)
	lw	$18,304($sp)
	lw	$17,300($sp)
	lw	$16,296($sp)
	jr	$31
	addiu	$sp,$sp,336

$L523:
$L550:
	b	$L503
	move	$5,$20

$L524:
	move	$4,$20
	b	$L511
	addiu	$2,$sp,16

$L521:
	move	$5,$20
	b	$L495
	addiu	$4,$sp,16

$L549:
	b	$L499
	andi	$7,$22,0x3

$L548:
	move	$5,$20
	b	$L495
	addiu	$4,$sp,16

$L547:
	b	$L494
	srl	$fp,$fp,1

	.set	macro
	.set	reorder
	.end	qsort
	.size	qsort, .-qsort
	.align	2
	.globl	fopen
	.set	nomips16
	.set	nomicromips
	.ent	fopen
	.type	fopen, @function
fopen:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	lb	$2,0($5)
	li	$3,114			# 0x72
	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L568
	.set	at
	xori	$2,$2,0x77
	.set	macro
	.set	reorder

	li	$5,1089			# 0x441
	li	$3,577			# 0x241
	movz	$5,$3,$2
$L557:
	li	$2,2			# 0x2
	li	$6,420			# 0x1a4
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bltz	$2,$L561
	move	$9,$2
	.set	macro
	.set	reorder

$L570:
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	malloc
	li	$4,16			# 0x10
	.set	macro
	.set	reorder

	lw	$31,20($sp)
	li	$3,-1			# 0xffffffffffffffff
	sw	$9,0($2)
	sw	$0,4($2)
	sw	$0,8($2)
	sw	$3,12($2)
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,24
	.set	macro
	.set	reorder

$L568:
	li	$3,43			# 0x2b
$L553:
	lb	$2,1($5)
	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L569
	.set	at
	addiu	$5,$5,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L553
	li	$2,2			# 0x2
	.set	macro
	.set	reorder

	move	$5,$0
	li	$6,420			# 0x1a4
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bgez	$2,$L570
	move	$9,$2
	.set	macro
	.set	reorder

$L561:
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0
	.set	macro
	.set	reorder

$L569:
	.set	noreorder
	.set	nomacro
	b	$L557
	li	$5,2			# 0x2
	.set	macro
	.set	reorder

	.end	fopen
	.size	fopen, .-fopen
	.align	2
	.globl	fclose
	.set	nomips16
	.set	nomicromips
	.ent	fclose
	.type	fclose, @function
fclose:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,3			# 0x3
	lw	$4,0($4)
	move	$5,$0
	move	$6,$0
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	fclose
	.size	fclose, .-fclose
	.align	2
	.globl	fread
	.set	nomips16
	.set	nomicromips
	.ent	fread
	.type	fread, @function
fread:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	multu	$5,$6
	mflo	$8
	move	$11,$5
	move	$10,$4
	move	$9,$7
	.set	noreorder
	.set	nomacro
	bne	$8,$0,$L575
	move	$3,$0
	.set	macro
	.set	reorder

	b	$L573
$L574:
	sltu	$6,$3,$8
	beq	$6,$0,$L573
$L575:
	lw	$4,0($9)
	move	$2,$0
	addu	$5,$10,$3
	subu	$6,$8,$3
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bgtz	$2,$L574
	addu	$3,$3,$2
	.set	macro
	.set	reorder

	subu	$3,$3,$2
	li	$2,1			# 0x1
	sw	$2,4($9)
$L573:
	beq	$11,$0,$L576
	divu	$0,$3,$11
	mflo	$11
$L576:
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$11
	.set	macro
	.set	reorder

	.end	fread
	.size	fread, .-fread
	.align	2
	.globl	fwrite
	.set	nomips16
	.set	nomicromips
	.ent	fwrite
	.type	fwrite, @function
fwrite:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	multu	$5,$6
	mflo	$6
	move	$3,$5
	move	$8,$7
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L583
	move	$5,$4
	.set	macro
	.set	reorder

	lw	$4,0($7)
	li	$2,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	bltz	$2,$L589
	divu	$0,$2,$3
	.set	noreorder
	.set	nomacro
	jr	$31
	mflo	$2
	.set	macro
	.set	reorder

$L589:
	li	$2,1			# 0x1
	sw	$2,8($8)
$L583:
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	fwrite
	.size	fwrite, .-fwrite
	.align	2
	.globl	fseek
	.set	nomips16
	.set	nomicromips
	.ent	fseek
	.type	fseek, @function
fseek:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$0,4($4)
	li	$2,8			# 0x8
	lw	$4,0($4)
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	jr	$31
	sra	$2,$2,31
	.set	macro
	.set	reorder

	.end	fseek
	.size	fseek, .-fseek
	.align	2
	.globl	ftell
	.set	nomips16
	.set	nomicromips
	.ent	ftell
	.type	ftell, @function
ftell:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,8			# 0x8
	lw	$4,0($4)
	move	$5,$0
	li	$6,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	jr	$31
	.end	ftell
	.size	ftell, .-ftell
	.align	2
	.globl	fflush
	.set	nomips16
	.set	nomicromips
	.ent	fflush
	.type	fflush, @function
fflush:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	fflush
	.size	fflush, .-fflush
	.align	2
	.globl	feof
	.set	nomips16
	.set	nomicromips
	.ent	feof
	.type	feof, @function
feof:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	lw	$2,4($4)

	.set	macro
	.set	reorder
	.end	feof
	.size	feof, .-feof
	.align	2
	.globl	ferror
	.set	nomips16
	.set	nomicromips
	.ent	ferror
	.type	ferror, @function
ferror:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	lw	$2,8($4)

	.set	macro
	.set	reorder
	.end	ferror
	.size	ferror, .-ferror
	.align	2
	.globl	fileno
	.set	nomips16
	.set	nomicromips
	.ent	fileno
	.type	fileno, @function
fileno:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	lw	$2,0($4)

	.set	macro
	.set	reorder
	.end	fileno
	.size	fileno, .-fileno
	.align	2
	.globl	fgetc
	.set	nomips16
	.set	nomicromips
	.ent	fgetc
	.type	fgetc, @function
fgetc:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	addiu	$sp,$sp,-8
	move	$3,$4
	move	$2,$0
	lw	$4,0($4)
	move	$5,$sp
	li	$6,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	blez	$2,$L602
	li	$3,1			# 0x1
	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L603
	.set	at
	li	$2,-1			# 0xffffffffffffffff
	.set	macro
	.set	reorder

	lbu	$2,0($sp)
$L596:
$L603:
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L602:
	li	$2,1			# 0x1
	sw	$2,4($3)
	.set	noreorder
	.set	nomacro
	b	$L596
	li	$2,-1			# 0xffffffffffffffff
	.set	macro
	.set	reorder

	.end	fgetc
	.size	fgetc, .-fgetc
	.align	2
	.globl	fgets
	.set	nomips16
	.set	nomicromips
	.ent	fgets
	.type	fgets, @function
fgets:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	addiu	$sp,$sp,-8
	move	$10,$4
	move	$9,$6
	addiu	$11,$5,-1
	move	$8,$0
	.set	noreorder
	.set	nomacro
	b	$L605
	li	$12,10			# 0xa
	.set	macro
	.set	reorder

$L616:
	addiu	$8,$8,1
	addu	$5,$10,$8
	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$3,$12
	beq	$1,$0,$L608
	.set	at
	sb	$3,-1($5)
	.set	macro
	.set	reorder

$L605:
	slt	$3,$8,$11
	move	$2,$0
	move	$5,$sp
	.set	noreorder
	.set	nomacro
	beq	$3,$0,$L606
	li	$6,1			# 0x1
	.set	macro
	.set	reorder

	lw	$4,0($9)
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	blez	$2,$L615
	li	$3,1			# 0x1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L616
	.set	at
	lbu	$3,0($sp)
	.set	macro
	.set	reorder

$L606:
	.set	noreorder
	.set	nomacro
	beq	$8,$0,$L618
	move	$2,$0
	.set	macro
	.set	reorder

$L617:
	addu	$5,$10,$8
$L608:
	sb	$0,0($5)
	move	$2,$10
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L615:
	li	$2,1			# 0x1
	.set	noreorder
	.set	nomacro
	bne	$8,$0,$L617
	sw	$2,4($9)
	.set	macro
	.set	reorder

	move	$2,$0
$L618:
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

	.end	fgets
	.size	fgets, .-fgets
	.align	2
	.globl	fputc
	.set	nomips16
	.set	nomicromips
	.ent	fputc
	.type	fputc, @function
fputc:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	addiu	$sp,$sp,-8
	move	$3,$4
	move	$8,$5
	lw	$4,0($5)
	li	$2,1			# 0x1
	sb	$3,0($sp)
	move	$5,$sp
	li	$6,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bltz	$2,$L624
	li	$4,1			# 0x1
	.set	macro
	.set	reorder

	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L621
	.set	at
$L622:
	move	$2,$3
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L624:
	li	$2,1			# 0x1
	sw	$2,8($8)
$L621:
	.set	noreorder
	.set	nomacro
	b	$L622
	li	$3,-1			# 0xffffffffffffffff
	.set	macro
	.set	reorder

	.end	fputc
	.size	fputc, .-fputc
	.align	2
	.globl	fputs
	.set	nomips16
	.set	nomicromips
	.ent	fputs
	.type	fputs, @function
fputs:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lb	$2,0($4)
	move	$7,$4
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L626
	move	$8,$5
	.set	macro
	.set	reorder

	move	$2,$4
$L627:
	lb	$3,1($2)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L627
	addiu	$2,$2,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L626
	.set	at
	subu	$6,$2,$7
	.set	macro
	.set	reorder

	lw	$4,0($8)
	li	$2,1			# 0x1
	move	$5,$7
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	bltz	$2,$L636
	jr	$31
$L636:
	li	$2,1			# 0x1
	sw	$2,8($8)
$L626:
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	fputs
	.size	fputs, .-fputs
	.align	2
	.globl	putchar
	.set	nomips16
	.set	nomicromips
	.ent	putchar
	.type	putchar, @function
putchar:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lui	$2,%hi(stdout)
	lw	$8,%lo(stdout)($2)
	addiu	$sp,$sp,-8
	move	$3,$4
	lw	$4,0($8)
	sb	$3,0($sp)
	li	$2,1			# 0x1
	move	$5,$sp
	li	$6,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bltz	$2,$L642
	li	$4,1			# 0x1
	.set	macro
	.set	reorder

	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L639
	.set	at
$L640:
	move	$2,$3
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L642:
	li	$2,1			# 0x1
	sw	$2,8($8)
$L639:
	.set	noreorder
	.set	nomacro
	b	$L640
	li	$3,-1			# 0xffffffffffffffff
	.set	macro
	.set	reorder

	.end	putchar
	.size	putchar, .-putchar
	.align	2
	.globl	puts
	.set	nomips16
	.set	nomicromips
	.ent	puts
	.type	puts, @function
puts:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	addiu	$sp,$sp,-8
	lb	$2,0($4)
	lui	$9,%hi(stdout)
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L644
	lw	$8,%lo(stdout)($9)
	.set	macro
	.set	reorder

	move	$5,$4
	move	$2,$4
$L645:
	lb	$3,1($2)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L645
	addiu	$2,$2,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L644
	.set	at
	subu	$6,$2,$5
	.set	macro
	.set	reorder

	lw	$4,0($8)
	li	$2,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bltz	$2,$L646
	li	$2,1			# 0x1
	.set	macro
	.set	reorder

$L656:
	lw	$8,%lo(stdout)($9)
$L644:
	li	$2,10			# 0xa
	sb	$2,0($sp)
	lw	$4,0($8)
	li	$2,1			# 0x1
	move	$5,$sp
	li	$6,1			# 0x1
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bltz	$2,$L657
	move	$2,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L657:
	li	$2,1			# 0x1
	sw	$2,8($8)
	move	$2,$0
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,8
	.set	macro
	.set	reorder

$L646:
	.set	noreorder
	.set	nomacro
	b	$L656
	sw	$2,8($8)
	.set	macro
	.set	reorder

	.end	puts
	.size	puts, .-puts
	.section	.rodata.str1.4
	.align	2
$LC9:
	.ascii	"(null)\000"
	.globl	__fixunsdfdi
	.globl	__floatundidf
	.globl	__fixdfsi
	.text
	.align	2
	.globl	vsnprintf
	.set	nomips16
	.set	nomicromips
	.ent	vsnprintf
	.type	vsnprintf, @function
vsnprintf:
	.frame	$sp,128,$31		# vars= 40, regs= 10/0, args= 48, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-128
	sw	$18,96($sp)
	sw	$17,92($sp)
	sw	$31,124($sp)
	sw	$fp,120($sp)
	sw	$23,116($sp)
	sw	$22,112($sp)
	sw	$21,108($sp)
	sw	$20,104($sp)
	sw	$19,100($sp)
	sw	$16,88($sp)
	lb	$2,0($6)
	move	$18,$4
	move	$17,$5
	sw	$4,48($sp)
	sw	$0,52($sp)
	beq	$2,$0,$L787
	sw	$5,56($sp)

	lui	$19,%hi($L684)
	li	$9,262144			# 0x40000
	addiu	$3,$19,%lo($L684)
	move	$23,$7
	addiu	$fp,$9,4097
	b	$L659
	sw	$3,64($sp)

$L794:
	lw	$5,52($sp)
	lw	$3,56($sp)
	addiu	$4,$5,1
	sltu	$3,$4,$3
	beq	$3,$0,$L663
	lw	$3,48($sp)

	addu	$3,$3,$5
	sb	$2,0($3)
$L663:
	lb	$2,1($6)
	sw	$4,52($sp)
	move	$6,$19
$L664:
	beq	$2,$0,$L811
	lw	$3,52($sp)

$L659:
	li	$3,37			# 0x25
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L794
	.set	at
	addiu	$19,$6,1

	lb	$2,0($19)
	li	$4,45			# 0x2d
	move	$13,$0
	move	$11,$0
	move	$12,$0
	li	$14,43			# 0x2b
	li	$7,48			# 0x30
	li	$6,32			# 0x20
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L752
	.set	at
	li	$5,35			# 0x23

$L796:
	.set	noat
	xor	$1,$2,$14
	beq	$1,$0,$L753
	.set	at
	slt	$3,$2,44

	beq	$3,$0,$L666
	nop

	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L665
	.set	at
	nop

	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L795
	.set	at
	li	$3,42			# 0x2a

$L665:
	addiu	$19,$19,1
$L797:
	lb	$2,0($19)
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L796
	.set	at
	nop

$L752:
	li	$12,1			# 0x1
	b	$L797
	addiu	$19,$19,1

$L666:
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L668
	.set	at
	move	$3,$2

	li	$11,1			# 0x1
	b	$L797
	addiu	$19,$19,1

$L753:
	li	$13,1			# 0x1
	b	$L797
	addiu	$19,$19,1

$L668:
	addiu	$4,$2,-48
	sltu	$4,$4,10
	beq	$4,$0,$L670
	move	$14,$0

$L669:
	sll	$2,$14,2
	addu	$2,$2,$14
	addiu	$19,$19,1
	sll	$2,$2,1
	addu	$2,$2,$3
	lb	$3,0($19)
	addiu	$14,$2,-48
	addiu	$4,$3,-48
	sltu	$4,$4,10
	bne	$4,$0,$L669
	move	$2,$3

$L670:
	li	$3,46			# 0x2e
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L798
	.set	at
	li	$16,-1			# 0xffffffffffffffff

$L672:
	li	$7,108			# 0x6c
$L810:
	move	$4,$0
	li	$15,122			# 0x7a
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L677
	.set	at
	li	$24,1			# 0x1

	andi	$5,$2,0x00ff
$L812:
	addiu	$3,$5,-104
	andi	$3,$3,0x00ff
	sltu	$6,$3,19
	beq	$6,$0,$L678
	srl	$3,$fp,$3

	andi	$3,$3,0x1
	bne	$3,$0,$L799
	nop

$L680:
	addiu	$5,$5,-37
	sltu	$5,$5,84
	beq	$5,$0,$L682
	addiu	$3,$2,-37

	andi	$3,$3,0x00ff
	sltu	$5,$3,84
	beq	$5,$0,$L682
	lw	$5,64($sp)

	sll	$3,$3,2
	addu	$3,$5,$3
	lw	$3,0($3)
	jr	$3
	nop

	.rdata
	.align	2
	.align	2
$L684:
	.word	$L690
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L683
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L689
	.word	$L687
	.word	$L688
	.word	$L688
	.word	$L688
	.word	$L682
	.word	$L687
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L682
	.word	$L683
	.word	$L686
	.word	$L682
	.word	$L682
	.word	$L685
	.word	$L682
	.word	$L683
	.word	$L682
	.word	$L682
	.word	$L683
	.text
$L799:
	.set	noat
	xor	$1,$2,$15
	beq	$1,$0,$L757
	.set	at
	nop

	xori	$2,$2,0x74
	addiu	$19,$19,1
	movz	$4,$24,$2
	lb	$2,0($19)
$L801:
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L812
	.set	at
	andi	$5,$2,0x00ff

$L677:
	addiu	$19,$19,1
	addiu	$4,$4,1
	b	$L801
	lb	$2,0($19)

$L757:
	addiu	$19,$19,1
	li	$4,1			# 0x1
	b	$L801
	lb	$2,0($19)

$L678:
	bne	$2,$0,$L680
	lw	$3,52($sp)

$L811:
	beq	$17,$0,$L658
	move	$2,$3

	sltu	$4,$3,$17
	bne	$4,$0,$L660
	nop

	addiu	$3,$17,-1
$L660:
	addu	$18,$18,$3
	sb	$0,0($18)
$L658:
	lw	$31,124($sp)
	lw	$fp,120($sp)
	lw	$23,116($sp)
	lw	$22,112($sp)
	lw	$21,108($sp)
	lw	$20,104($sp)
	lw	$19,100($sp)
	lw	$18,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	jr	$31
	addiu	$sp,$sp,128

$L798:
	lb	$2,1($19)
	li	$3,42			# 0x2a
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L802
	.set	at
	addiu	$4,$2,-48

	lw	$16,0($23)
	lb	$2,2($19)
	addiu	$23,$23,4
	b	$L672
	addiu	$19,$19,2

$L682:
	lw	$3,52($sp)
	lw	$4,56($sp)
	addiu	$5,$3,1
	sltu	$6,$5,$4
	beq	$6,$0,$L743
	li	$6,37			# 0x25

	lw	$2,48($sp)
	addu	$2,$2,$3
	sb	$6,0($2)
	lb	$2,0($19)
$L743:
	addiu	$3,$3,2
	sltu	$4,$3,$4
	beq	$4,$0,$L744
	lw	$4,48($sp)

	addu	$4,$4,$5
	sb	$2,0($4)
$L744:
	lb	$2,1($19)
	sw	$3,52($sp)
	b	$L664
	addiu	$6,$19,1

$L802:
	sltu	$4,$4,10
	addiu	$19,$19,1
	move	$3,$2
	beq	$4,$0,$L672
	move	$16,$0

$L674:
	sll	$2,$16,2
	addu	$2,$2,$16
	addiu	$19,$19,1
	sll	$2,$2,1
	addu	$2,$2,$3
	lb	$3,0($19)
	addiu	$16,$2,-48
	addiu	$4,$3,-48
	sltu	$4,$4,10
	bne	$4,$0,$L674
	move	$2,$3

	b	$L810
	li	$7,108			# 0x6c

$L683:
	slt	$4,$4,2
	bne	$4,$0,$L695
	addiu	$10,$23,7

	li	$3,-8			# 0xfffffffffffffff8
	and	$10,$10,$3
	lw	$6,0($10)
	lw	$7,4($10)
	addiu	$23,$10,8
$L696:
	li	$3,117			# 0x75
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L758
	.set	at
	xori	$5,$2,0x6f

	li	$3,8			# 0x8
	li	$4,16			# 0x10
	movn	$3,$4,$5
$L697:
	xori	$2,$2,0x58
	sltu	$2,$2,1
	sw	$2,24($sp)
	sw	$0,44($sp)
	sw	$11,40($sp)
	sw	$12,36($sp)
	sw	$16,32($sp)
	sw	$14,28($sp)
	sw	$3,20($sp)
	sw	$0,16($sp)
	jal	out_num
	addiu	$4,$sp,48

	lb	$2,1($19)
	b	$L664
	addiu	$6,$19,1

$L688:
	addiu	$10,$23,7
	li	$2,-8			# 0xfffffffffffffff8
	and	$10,$10,$2
	lw	$20,0($10)
	lw	$22,4($10)
	addiu	$23,$10,8
	move	$4,$20
	move	$5,$22
	move	$6,$0
	bltz	$16,$L734
	move	$7,$0

	jal	__ltdf2
	nop

	bltz	$2,$L813
	lw	$4,52($sp)

$L735:
	move	$4,$20
	jal	__fixunsdfdi
	move	$5,$22

	move	$21,$2
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,32($sp)
	li	$2,10			# 0xa
	move	$7,$3
	move	$6,$21
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,28($sp)
	sw	$0,24($sp)
	sw	$2,20($sp)
	sw	$0,16($sp)
	addiu	$4,$sp,48
	jal	out_num
	sw	$3,68($sp)

	addiu	$6,$19,1
	lw	$7,68($sp)
	bne	$16,$0,$L738
	sw	$6,84($sp)

	b	$L664
	lb	$2,1($19)

$L687:
	slt	$4,$4,2
	bne	$4,$0,$L691
	addiu	$10,$23,7

	li	$2,-8			# 0xfffffffffffffff8
	and	$10,$10,$2
	lw	$6,0($10)
	lw	$2,4($10)
	addiu	$23,$10,8
$L692:
	move	$7,$2
	bgez	$7,$L693
	srl	$2,$2,31

	sltu	$3,$0,$6
	subu	$7,$0,$7
	subu	$7,$7,$3
	subu	$6,$0,$6
$L693:
	li	$3,10			# 0xa
	sw	$2,16($sp)
	sw	$13,44($sp)
	sw	$11,40($sp)
	sw	$12,36($sp)
	sw	$16,32($sp)
	sw	$14,28($sp)
	sw	$0,24($sp)
	sw	$3,20($sp)
	jal	out_num
	addiu	$4,$sp,48

	lb	$2,1($19)
	b	$L664
	addiu	$6,$19,1

$L689:
	lw	$7,0($23)
	lw	$5,52($sp)
	lw	$4,56($sp)
	addiu	$10,$23,4
	beq	$12,$0,$L803
	addiu	$11,$14,-1

	addiu	$12,$5,1
	sltu	$2,$12,$4
	beq	$2,$0,$L704
	lw	$2,48($sp)

	addu	$2,$2,$5
	sb	$7,0($2)
$L704:
	sw	$12,52($sp)
	blez	$11,$L793
	addiu	$6,$19,1

	lw	$3,48($sp)
	li	$5,1			# 0x1
	addu	$2,$3,$12
	addu	$7,$11,$2
	subu	$5,$5,$3
	li	$13,32			# 0x20
	addu	$3,$5,$2
$L814:
	sltu	$3,$3,$4
	beq	$3,$0,$L710
	nop

	sb	$13,0($2)
$L710:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L814
	.set	at
	addu	$3,$5,$2

	addu	$11,$11,$12
	lb	$2,1($19)
	sw	$11,52($sp)
	b	$L664
	move	$23,$10

$L690:
	lw	$4,52($sp)
	lw	$2,56($sp)
	addiu	$3,$4,1
	sltu	$2,$3,$2
	beq	$2,$0,$L744
	nop

	lw	$2,48($sp)
	sw	$3,52($sp)
	addu	$2,$2,$4
	li	$4,37			# 0x25
	sb	$4,0($2)
	lb	$2,1($19)
	b	$L664
	addiu	$6,$19,1

$L686:
	lw	$2,52($sp)
	lw	$3,56($sp)
	addiu	$4,$2,1
	sltu	$5,$4,$3
	lw	$6,0($23)
	beq	$5,$0,$L698
	addiu	$23,$23,4

	lw	$5,48($sp)
	li	$7,48			# 0x30
	addu	$5,$5,$2
	sb	$7,0($5)
$L698:
	addiu	$2,$2,2
	sltu	$3,$2,$3
	beq	$3,$0,$L815
	li	$3,-1			# 0xffffffffffffffff

	lw	$3,48($sp)
	addu	$3,$3,$4
	li	$4,120			# 0x78
	sb	$4,0($3)
	li	$3,-1			# 0xffffffffffffffff
$L815:
	sw	$3,32($sp)
	li	$3,16			# 0x10
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,28($sp)
	sw	$0,24($sp)
	sw	$3,20($sp)
	sw	$0,16($sp)
	move	$7,$0
	addiu	$4,$sp,48
	jal	out_num
	sw	$2,52($sp)

	lb	$2,1($19)
	b	$L664
	addiu	$6,$19,1

$L685:
	lw	$5,0($23)
	beq	$5,$0,$L804
	addiu	$10,$23,4

	lb	$2,0($5)
	beq	$2,$0,$L714
	addiu	$6,$19,1

$L713:
	b	$L715
	move	$2,$0

$L719:
	addu	$3,$5,$2
	lb	$3,0($3)
	beq	$3,$0,$L718
	nop

$L715:
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L719
	.set	at
	addiu	$2,$2,1

	addiu	$2,$2,-1
	beq	$12,$0,$L805
	subu	$14,$14,$16

	beq	$2,$0,$L717
	nop

$L748:
	lw	$7,56($sp)
	lw	$24,48($sp)
	lw	$15,52($sp)
$L723:
	move	$3,$0
	addiu	$11,$15,1
$L730:
	addu	$4,$3,$11
	sltu	$4,$4,$7
	beq	$4,$0,$L729
	addu	$4,$5,$3

	lb	$13,0($4)
	addu	$4,$3,$15
	addu	$4,$24,$4
	sb	$13,0($4)
$L729:
	addiu	$3,$3,1
	slt	$4,$3,$2
	bne	$4,$0,$L730
	nop

	addiu	$3,$2,-1
	slt	$2,$0,$2
	movz	$3,$0,$2
	addu	$3,$3,$11
	bne	$12,$0,$L717
	sw	$3,52($sp)

$L793:
	lb	$2,1($19)
	b	$L664
	move	$23,$10

$L691:
	lw	$6,0($23)
	addiu	$23,$23,4
	b	$L692
	sra	$2,$6,31

$L734:
	jal	__ltdf2
	nop

	bltz	$2,$L806
	move	$4,$20

	jal	__fixunsdfdi
	move	$5,$22

	move	$4,$2
	move	$5,$3
	move	$16,$3
	jal	__floatundidf
	move	$21,$2

	move	$6,$2
	move	$4,$20
	move	$7,$3
	jal	__subdf3
	move	$5,$22

	move	$20,$3
	li	$3,-1			# 0xffffffffffffffff
	sw	$3,32($sp)
	li	$3,10			# 0xa
	move	$6,$21
	move	$7,$16
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,28($sp)
	sw	$0,24($sp)
	sw	$3,20($sp)
	sw	$0,16($sp)
	addiu	$4,$sp,48
	move	$21,$2
	addiu	$2,$19,1
	sw	$2,84($sp)
	jal	out_num
	li	$16,5			# 0x5

$L745:
	lw	$2,52($sp)
	lw	$3,56($sp)
	lw	$4,48($sp)
	addiu	$22,$2,1
	sw	$3,68($sp)
	sltu	$3,$22,$3
	bne	$3,$0,$L807
	sw	$4,80($sp)

$L739:
	lui	$3,%hi($LC8)
	lw	$4,%lo($LC8)($3)
	lw	$5,%lo($LC8+4)($3)
	addiu	$2,$2,2
	sw	$4,72($sp)
	sw	$5,76($sp)
	addu	$16,$2,$16
$L741:
	lw	$6,72($sp)
	lw	$7,76($sp)
	move	$4,$21
	jal	__muldf3
	move	$5,$20

	move	$4,$2
	move	$5,$3
	move	$20,$3
	jal	__fixdfsi
	move	$21,$2

	lw	$3,68($sp)
	addiu	$22,$22,1
	sltu	$3,$22,$3
	beq	$3,$0,$L740
	move	$4,$2

	lw	$2,80($sp)
	addiu	$3,$4,48
	addu	$2,$2,$22
	sb	$3,-1($2)
$L740:
	jal	__floatsidf
	nop

	move	$6,$2
	move	$4,$21
	move	$5,$20
	jal	__subdf3
	move	$7,$3

	move	$20,$3
	.set	noat
	xor	$1,$22,$16
	bne	$1,$0,$L741
	.set	at
	move	$21,$2

	lb	$2,1($19)
	lw	$6,84($sp)
	b	$L664
	sw	$22,52($sp)

$L695:
	lw	$6,0($23)
	move	$7,$0
	b	$L696
	addiu	$23,$23,4

$L804:
	lui	$5,%hi($LC9)
	addiu	$6,$19,1
	b	$L713
	addiu	$5,$5,%lo($LC9)

$L803:
	blez	$11,$L702
	addiu	$2,$5,1

	lw	$12,48($sp)
	addu	$6,$14,$5
	li	$11,32			# 0x20
	sltu	$3,$2,$4
$L816:
	beq	$3,$0,$L705
	addu	$3,$12,$2

	sb	$11,-1($3)
$L705:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L816
	.set	at
	sltu	$3,$2,$4

	addiu	$5,$5,-1
	addu	$5,$5,$14
$L702:
	addiu	$3,$5,1
	sltu	$4,$3,$4
	beq	$4,$0,$L808
	nop

	lw	$2,48($sp)
	sw	$3,52($sp)
	addu	$2,$2,$5
	sb	$7,0($2)
	lb	$2,1($19)
	addiu	$6,$19,1
	b	$L664
	move	$23,$10

$L717:
	blez	$14,$L793
	lw	$3,48($sp)

	lw	$12,52($sp)
	li	$4,1			# 0x1
	addu	$2,$3,$12
	lw	$7,56($sp)
	addu	$5,$14,$2
	subu	$4,$4,$3
	li	$11,32			# 0x20
	addu	$3,$4,$2
$L817:
	sltu	$3,$3,$7
	beq	$3,$0,$L732
	nop

	sb	$11,0($2)
$L732:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L817
	.set	at
	addu	$3,$4,$2

	addu	$12,$14,$12
	lb	$2,1($19)
	sw	$12,52($sp)
	b	$L664
	move	$23,$10

$L718:
	bne	$12,$0,$L748
	subu	$14,$14,$2

	blez	$14,$L761
	addiu	$15,$14,-1

$L721:
	lw	$3,52($sp)
	lw	$7,56($sp)
	addiu	$11,$3,2
	addiu	$14,$3,1
	lw	$24,48($sp)
	move	$3,$14
	li	$13,32			# 0x20
	addu	$11,$11,$15
	sltu	$4,$3,$7
$L818:
	beq	$4,$0,$L725
	addu	$4,$24,$3

	sb	$13,-1($4)
$L725:
	addiu	$3,$3,1
	subu	$4,$11,$3
	bgtz	$4,$L818
	sltu	$4,$3,$7

	addu	$15,$15,$14
	beq	$2,$0,$L793
	sw	$15,52($sp)

	b	$L723
	li	$14,-1			# 0xffffffffffffffff

$L787:
	beq	$5,$0,$L658
	move	$2,$0

	move	$3,$0
	addu	$18,$18,$3
	b	$L658
	sb	$0,0($18)

$L806:
	li	$16,6			# 0x6
	lw	$4,52($sp)
$L813:
	lw	$2,56($sp)
	addiu	$3,$4,1
	sltu	$2,$3,$2
	beq	$2,$0,$L819
	li	$2,-2147483648			# 0xffffffff80000000

	lw	$2,48($sp)
	addu	$2,$2,$4
	li	$4,45			# 0x2d
	sb	$4,0($2)
	li	$2,-2147483648			# 0xffffffff80000000
$L819:
	sw	$3,52($sp)
	b	$L735
	xor	$22,$22,$2

$L758:
	b	$L697
	li	$3,10			# 0xa

$L808:
	lb	$2,1($19)
	addiu	$6,$19,1
	sw	$3,52($sp)
	b	$L664
	move	$23,$10

$L807:
	addu	$3,$4,$2
	li	$4,46			# 0x2e
	b	$L739
	sb	$4,0($3)

$L714:
	bne	$12,$0,$L717
	nop

	blez	$14,$L793
	nop

	addiu	$15,$14,-1
	b	$L721
	move	$2,$0

$L805:
	bgtz	$14,$L721
	addiu	$15,$14,-1

	beq	$16,$0,$L793
	nop

$L761:
	b	$L748
	move	$14,$15

$L738:
	move	$4,$21
	jal	__floatundidf
	move	$5,$7

	move	$6,$2
	move	$4,$20
	move	$7,$3
	jal	__subdf3
	move	$5,$22

	move	$20,$3
	move	$21,$2
	b	$L745
	addiu	$16,$16,-1

$L795:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L809
	.set	at
	move	$14,$0

	lw	$14,0($23)
	bgez	$14,$L671
	addiu	$10,$23,4

	subu	$14,$0,$14
	li	$12,1			# 0x1
$L671:
	lb	$2,1($19)
	move	$23,$10
	b	$L670
	addiu	$19,$19,1

$L809:
	b	$L672
	li	$16,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	vsnprintf
	.size	vsnprintf, .-vsnprintf
	.align	2
	.globl	vsprintf
	.set	nomips16
	.set	nomicromips
	.ent	vsprintf
	.type	vsprintf, @function
vsprintf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$7,$6
	move	$6,$5
	li	$5,2147418112			# 0x7fff0000
	j	vsnprintf
	ori	$5,$5,0xffff

	.set	macro
	.set	reorder
	.end	vsprintf
	.size	vsprintf, .-vsprintf
	.align	2
	.globl	snprintf
	.set	nomips16
	.set	nomicromips
	.ent	snprintf
	.type	snprintf, @function
snprintf:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	addiu	$2,$sp,44
	sw	$7,44($sp)
	move	$7,$2
	sw	$31,28($sp)
	jal	vsnprintf
	sw	$2,16($sp)

	lw	$31,28($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	snprintf
	.size	snprintf, .-snprintf
	.align	2
	.globl	sprintf
	.set	nomips16
	.set	nomicromips
	.ent	sprintf
	.type	sprintf, @function
sprintf:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	addiu	$2,$sp,40
	sw	$6,40($sp)
	move	$6,$5
	li	$5,2147418112			# 0x7fff0000
	sw	$7,44($sp)
	ori	$5,$5,0xffff
	move	$7,$2
	sw	$31,28($sp)
	jal	vsnprintf
	sw	$2,16($sp)

	lw	$31,28($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	sprintf
	.size	sprintf, .-sprintf
	.align	2
	.globl	vfprintf
	.set	nomips16
	.set	nomicromips
	.ent	vfprintf
	.type	vfprintf, @function
vfprintf:
	.frame	$sp,1048,$31		# vars= 1024, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	addiu	$sp,$sp,-1048
	move	$7,$6
	move	$6,$5
	sw	$16,1040($sp)
	li	$5,1024			# 0x400
	move	$16,$4
	sw	$31,1044($sp)
	.set	noreorder
	.set	nomacro
	jal	vsnprintf
	addiu	$4,$sp,16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L825
	move	$3,$2
	.set	macro
	.set	reorder

	slt	$7,$2,1024
	li	$6,1023			# 0x3ff
	lw	$4,0($16)
	li	$2,1			# 0x1
	addiu	$5,$sp,16
	movn	$6,$3,$7
#APP
 # 11 "libc/my_stdlib.c" 1
	syscall
 # 0 "" 2
#NO_APP
	.set	noreorder
	.set	nomacro
	bltz	$2,$L830
	lw	$31,1044($sp)
	.set	macro
	.set	reorder

$L825:
	lw	$31,1044($sp)
	lw	$16,1040($sp)
	move	$2,$3
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,1048
	.set	macro
	.set	reorder

$L830:
	li	$2,1			# 0x1
	sw	$2,8($16)
	lw	$16,1040($sp)
	move	$2,$3
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$sp,$sp,1048
	.set	macro
	.set	reorder

	.end	vfprintf
	.size	vfprintf, .-vfprintf
	.align	2
	.globl	vprintf
	.set	nomips16
	.set	nomicromips
	.ent	vprintf
	.type	vprintf, @function
vprintf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(stdout)
	move	$2,$4
	lw	$4,%lo(stdout)($3)
	move	$6,$5
	j	vfprintf
	move	$5,$2

	.set	macro
	.set	reorder
	.end	vprintf
	.size	vprintf, .-vprintf
	.align	2
	.globl	printf
	.set	nomips16
	.set	nomicromips
	.ent	printf
	.type	printf, @function
printf:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$3,$4
	lui	$4,%hi(stdout)
	addiu	$2,$sp,36
	lw	$4,%lo(stdout)($4)
	sw	$5,36($sp)
	sw	$6,40($sp)
	move	$5,$3
	move	$6,$2
	sw	$31,28($sp)
	sw	$7,44($sp)
	jal	vfprintf
	sw	$2,16($sp)

	lw	$31,28($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	printf
	.size	printf, .-printf
	.align	2
	.globl	fprintf
	.set	nomips16
	.set	nomicromips
	.ent	fprintf
	.type	fprintf, @function
fprintf:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	addiu	$2,$sp,40
	sw	$6,40($sp)
	move	$6,$2
	sw	$31,28($sp)
	sw	$7,44($sp)
	jal	vfprintf
	sw	$2,16($sp)

	lw	$31,28($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	fprintf
	.size	fprintf, .-fprintf
	.align	2
	.globl	sscanf
	.set	nomips16
	.set	nomicromips
	.ent	sscanf
	.type	sscanf, @function
sscanf:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$6,40($sp)
	sw	$7,44($sp)
	lb	$2,0($5)
	addiu	$3,$sp,40
	beq	$2,$0,$L853
	sw	$3,20($sp)

	move	$12,$5
	move	$11,$4
	move	$14,$0
	li	$13,32			# 0x20
	li	$15,37			# 0x25
$L852:
	.set	noat
	xor	$1,$2,$13
	beq	$1,$0,$L842
	.set	at
	lb	$4,0($11)

	addiu	$3,$2,-9
	sltu	$3,$3,5
	bne	$3,$0,$L842
	nop

	.set	noat
	xor	$1,$2,$15
	beq	$1,$0,$L843
	.set	at
	li	$5,32			# 0x20

	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L860
	.set	at
	nop

$L836:
	lw	$31,28($sp)
$L861:
	move	$2,$14
	jr	$31
	addiu	$sp,$sp,32

$L840:
	addiu	$11,$11,1
$L842:
	lb	$3,0($11)
	addiu	$2,$3,-9
	.set	noat
	xor	$1,$3,$13
	beq	$1,$0,$L840
	.set	at
	sltu	$2,$2,5

	bne	$2,$0,$L840
	nop

$L851:
	lb	$2,1($12)
	bne	$2,$0,$L852
	addiu	$12,$12,1

	b	$L861
	lw	$31,28($sp)

$L860:
	b	$L851
	addiu	$11,$11,1

$L843:
	lb	$2,1($12)
	addiu	$12,$12,1
	li	$6,99			# 0x63
$L845:
	lb	$4,0($11)
	addiu	$3,$4,-9
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L846
	.set	at
	sltu	$3,$3,5

	beq	$3,$0,$L847
	li	$3,100			# 0x64

$L846:
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L861
	.set	at
	lw	$31,28($sp)

	b	$L845
	addiu	$11,$11,1

$L847:
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L854
	.set	at
	andi	$2,$2,0x00ff

	addiu	$4,$2,-105
	andi	$4,$4,0x00ff
	sltu	$3,$4,16
	beq	$3,$0,$L836
	li	$3,32833			# 0x8041

	srl	$3,$3,$4
	andi	$3,$3,0x1
	beq	$3,$0,$L861
	lw	$31,28($sp)

	addiu	$2,$2,-100
	andi	$2,$2,0x00ff
	lui	$3,%hi(CSWTCH.196)
	sll	$2,$2,2
	addiu	$3,$3,%lo(CSWTCH.196)
	addu	$2,$2,$3
	b	$L849
	lw	$6,0($2)

$L854:
	li	$6,10			# 0xa
$L849:
	move	$4,$11
	jal	strtol
	addiu	$5,$sp,16

	lw	$4,16($sp)
	.set	noat
	xor	$1,$4,$11
	beq	$1,$0,$L836
	.set	at
	lw	$3,20($sp)

	addiu	$14,$14,1
	lw	$5,0($3)
	addiu	$3,$3,4
	sw	$3,20($sp)
	sw	$2,0($5)
	b	$L851
	move	$11,$4

$L853:
	b	$L836
	move	$14,$0

	.set	macro
	.set	reorder
	.end	sscanf
	.size	sscanf, .-sscanf
	.align	2
	.globl	fscanf
	.set	nomips16
	.set	nomicromips
	.ent	fscanf
	.type	fscanf, @function
fscanf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sw	$6,8($sp)
	sw	$7,12($sp)
	jr	$31
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	fscanf
	.size	fscanf, .-fscanf
	.align	2
	.globl	fabs
	.set	nomips16
	.set	nomicromips
	.ent	fabs
	.type	fabs, @function
fabs:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$4
	move	$16,$5
	move	$4,$17
	move	$5,$16
	move	$6,$0
	sw	$31,28($sp)
	jal	__ltdf2
	move	$7,$0

	bgez	$2,$L868
	lw	$31,28($sp)

	li	$2,-2147483648			# 0xffffffff80000000
	xor	$16,$16,$2
$L868:
	move	$2,$17
	move	$3,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	fabs
	.size	fabs, .-fabs
	.globl	__fixdfdi
	.globl	__floatdidf
	.align	2
	.globl	floor
	.set	nomips16
	.set	nomicromips
	.ent	floor
	.type	floor, @function
floor:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$19,$4
	jal	__fixdfdi
	move	$18,$5

	move	$4,$2
	jal	__floatdidf
	move	$5,$3

	move	$6,$2
	move	$4,$19
	move	$7,$3
	move	$5,$18
	move	$16,$3
	jal	__ltdf2
	move	$17,$2

	bgez	$2,$L874
	lw	$31,36($sp)

	lui	$2,%hi($LC5)
	lw	$6,%lo($LC5)($2)
	lw	$7,%lo($LC5+4)($2)
	move	$4,$17
	jal	__subdf3
	move	$5,$16

	move	$16,$3
	move	$17,$2
	lw	$31,36($sp)
$L874:
	lw	$19,32($sp)
	lw	$18,28($sp)
	move	$2,$17
	move	$3,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	floor
	.size	floor, .-floor
	.align	2
	.globl	ceil
	.set	nomips16
	.set	nomicromips
	.ent	ceil
	.type	ceil, @function
ceil:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$19,$4
	jal	__fixdfdi
	move	$18,$5

	move	$4,$2
	jal	__floatdidf
	move	$5,$3

	move	$6,$2
	move	$4,$19
	move	$7,$3
	move	$5,$18
	move	$16,$3
	jal	__gtdf2
	move	$17,$2

	blez	$2,$L880
	lw	$31,36($sp)

	lui	$2,%hi($LC5)
	lw	$6,%lo($LC5)($2)
	lw	$7,%lo($LC5+4)($2)
	move	$4,$17
	jal	__adddf3
	move	$5,$16

	move	$16,$3
	move	$17,$2
	lw	$31,36($sp)
$L880:
	lw	$19,32($sp)
	lw	$18,28($sp)
	move	$2,$17
	move	$3,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	ceil
	.size	ceil, .-ceil
	.globl	__ledf2
	.align	2
	.globl	sqrt
	.set	nomips16
	.set	nomicromips
	.ent	sqrt
	.type	sqrt, @function
sqrt:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	move	$6,$0
	move	$7,$0
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	move	$20,$4
	jal	__ledf2
	move	$21,$5

	blez	$2,$L886
	lui	$16,%hi($LC5)

	lw	$6,%lo($LC5)($16)
	lw	$7,%lo($LC5+4)($16)
	move	$4,$20
	jal	__gtdf2
	move	$5,$21

	blez	$2,$L890
	move	$4,$20

	lui	$18,%hi($LC4)
	lw	$6,%lo($LC4)($18)
	lw	$7,%lo($LC4+4)($18)
	jal	__muldf3
	move	$5,$21

	move	$16,$3
	move	$17,$2
$L883:
	lw	$19,%lo($LC4+4)($18)
	lw	$18,%lo($LC4)($18)
	li	$22,40			# 0x28
$L885:
	move	$6,$17
	move	$7,$16
	move	$4,$20
	jal	__divdf3
	move	$5,$21

	move	$4,$2
	move	$6,$17
	move	$7,$16
	jal	__adddf3
	move	$5,$3

	move	$4,$2
	move	$6,$18
	move	$7,$19
	jal	__muldf3
	move	$5,$3

	addiu	$22,$22,-1
	move	$16,$3
	bne	$22,$0,$L885
	move	$17,$2

	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	move	$2,$17
	move	$3,$16
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L890:
	lw	$17,%lo($LC5)($16)
	lui	$18,%hi($LC4)
	b	$L883
	lw	$16,%lo($LC5+4)($16)

$L886:
	lw	$31,44($sp)
	move	$17,$0
	move	$16,$0
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	move	$2,$17
	move	$3,$16
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	sqrt
	.size	sqrt, .-sqrt
	.align	2
	.globl	fmod
	.set	nomips16
	.set	nomicromips
	.ent	fmod
	.type	fmod, @function
fmod:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$19,$6
	move	$18,$7
	move	$17,$4
	jal	__divdf3
	move	$16,$5

	move	$4,$2
	jal	__fixdfdi
	move	$5,$3

	move	$4,$2
	jal	__floatdidf
	move	$5,$3

	move	$4,$2
	move	$6,$19
	move	$7,$18
	jal	__muldf3
	move	$5,$3

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__subdf3
	move	$7,$3

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	fmod
	.size	fmod, .-fmod
	.align	2
	.globl	sin
	.set	nomips16
	.set	nomicromips
	.ent	sin
	.type	sin, @function
sin:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$20,32($sp)
	lui	$20,%hi($LC10)
	lw	$6,%lo($LC10)($20)
	lw	$7,%lo($LC10+4)($20)
	sw	$31,52($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	move	$17,$4
	move	$16,$5
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	jal	__divdf3
	sw	$21,36($sp)

	move	$4,$2
	jal	__fixdfdi
	move	$5,$3

	move	$4,$2
	jal	__floatdidf
	move	$5,$3

	lw	$6,%lo($LC10)($20)
	lw	$7,%lo($LC10+4)($20)
	move	$4,$2
	jal	__muldf3
	move	$5,$3

	move	$6,$2
	move	$7,$3
	move	$4,$17
	jal	__subdf3
	move	$5,$16

	move	$19,$2
	move	$4,$2
	lui	$2,%hi($LC11)
	lw	$6,%lo($LC11)($2)
	lw	$7,%lo($LC11+4)($2)
	move	$5,$3
	jal	__gtdf2
	move	$18,$3

	blez	$2,$L903
	lui	$2,%hi($LC12)

	lw	$6,%lo($LC10)($20)
	lw	$7,%lo($LC10+4)($20)
	move	$4,$19
	jal	__subdf3
	move	$5,$18

	move	$17,$2
	move	$16,$3
$L897:
	li	$2,-2147483648			# 0xffffffff80000000
$L905:
	xor	$2,$16,$2
	move	$6,$17
	move	$4,$17
	move	$7,$16
	jal	__muldf3
	move	$5,$2

	move	$18,$3
	move	$19,$2
	move	$23,$17
	move	$22,$16
	li	$fp,3			# 0x3
	li	$21,1			# 0x1
	li	$20,12			# 0xc
$L899:
	multu	$fp,$21
	mflo	$4
	addiu	$21,$21,1
	jal	__floatsidf
	sll	$4,$4,1

	move	$6,$2
	move	$7,$3
	move	$4,$19
	jal	__divdf3
	move	$5,$18

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__muldf3
	move	$7,$3

	move	$6,$2
	move	$4,$23
	move	$5,$22
	move	$7,$3
	move	$17,$2
	jal	__adddf3
	move	$16,$3

	move	$23,$2
	move	$22,$3
	.set	noat
	xor	$1,$21,$20
	bne	$1,$0,$L899
	.set	at
	addiu	$fp,$fp,2

	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L903:
	lw	$6,%lo($LC12)($2)
	lw	$7,%lo($LC12+4)($2)
	move	$4,$19
	move	$5,$18
	move	$17,$19
	jal	__ltdf2
	move	$16,$18

	bgez	$2,$L905
	li	$2,-2147483648			# 0xffffffff80000000

	lw	$6,%lo($LC10)($20)
	lw	$7,%lo($LC10+4)($20)
	move	$4,$19
	jal	__adddf3
	move	$5,$18

	move	$17,$2
	b	$L897
	move	$16,$3

	.set	macro
	.set	reorder
	.end	sin
	.size	sin, .-sin
	.align	2
	.globl	cos
	.set	nomips16
	.set	nomicromips
	.ent	cos
	.type	cos, @function
cos:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi($LC13)
	lw	$6,%lo($LC13)($2)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	__adddf3
	lw	$7,%lo($LC13+4)($2)

	lw	$31,20($sp)
	move	$4,$2
	move	$5,$3
	j	sin
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	cos
	.size	cos, .-cos
	.align	2
	.globl	tan
	.set	nomips16
	.set	nomicromips
	.ent	tan
	.type	tan, @function
tan:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	move	$18,$4
	jal	sin
	move	$17,$5

	move	$16,$3
	lui	$3,%hi($LC13)
	lw	$6,%lo($LC13)($3)
	lw	$7,%lo($LC13+4)($3)
	move	$4,$18
	move	$5,$17
	jal	__adddf3
	move	$17,$2

	move	$4,$2
	jal	sin
	move	$5,$3

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__divdf3
	move	$7,$3

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	tan
	.size	tan, .-tan
	.align	2
	.globl	atan
	.set	nomips16
	.set	nomicromips
	.ent	atan
	.type	atan, @function
atan:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$23,60($sp)
	sw	$16,32($sp)
	move	$23,$4
	move	$16,$5
	sw	$5,20($sp)
	move	$4,$23
	move	$5,$16
	move	$6,$0
	move	$7,$0
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	jal	__ltdf2
	sw	$17,36($sp)

	bltz	$2,$L934
	lw	$2,20($sp)

	sw	$2,16($sp)
$L911:
	lui	$16,%hi($LC5)
	lw	$17,16($sp)
	lw	$6,%lo($LC5)($16)
	lw	$7,%lo($LC5+4)($16)
	move	$4,$23
	move	$5,$17
	jal	__gtdf2
	sw	$16,24($sp)

	blez	$2,$L932
	lw	$4,%lo($LC5)($16)

	lw	$5,%lo($LC5+4)($16)
	move	$7,$17
	jal	__divdf3
	move	$6,$23

	move	$16,$3
	move	$17,$2
$L913:
	lui	$2,%hi($LC4)
	lw	$6,%lo($LC4)($2)
	lw	$7,%lo($LC4+4)($2)
	move	$4,$17
	jal	__gtdf2
	move	$5,$16

	bgtz	$2,$L915
	lw	$18,24($sp)

	li	$2,-2147483648			# 0xffffffff80000000
	xor	$2,$16,$2
	move	$6,$17
	move	$4,$17
	move	$7,$16
	jal	__muldf3
	move	$5,$2

	move	$20,$3
	move	$21,$2
	move	$18,$17
	move	$fp,$16
	li	$19,3			# 0x3
	li	$22,61			# 0x3d
$L916:
	move	$5,$16
	move	$6,$21
	move	$4,$17
	jal	__muldf3
	move	$7,$20

	move	$4,$19
	move	$16,$3
	jal	__floatsidf
	move	$17,$2

	move	$6,$2
	move	$7,$3
	move	$4,$17
	jal	__divdf3
	move	$5,$16

	move	$6,$2
	move	$4,$18
	move	$5,$fp
	jal	__adddf3
	move	$7,$3

	addiu	$19,$19,2
	move	$18,$2
	.set	noat
	xor	$1,$19,$22
	bne	$1,$0,$L916
	.set	at
	move	$fp,$3

$L918:
	lw	$2,16($sp)
	move	$4,$23
	move	$5,$2
	lw	$2,24($sp)
	lw	$6,%lo($LC5)($2)
	jal	__gtdf2
	lw	$7,%lo($LC5+4)($2)

	blez	$2,$L919
	lui	$2,%hi($LC13)

	lw	$4,%lo($LC13)($2)
	lw	$5,%lo($LC13+4)($2)
	move	$6,$18
	jal	__subdf3
	move	$7,$fp

	move	$18,$2
	move	$fp,$3
$L919:
	lw	$2,20($sp)
	move	$4,$23
	move	$5,$2
	move	$6,$0
	jal	__ltdf2
	move	$7,$0

	bgez	$2,$L935
	lw	$31,68($sp)

	li	$2,-2147483648			# 0xffffffff80000000
	xor	$fp,$fp,$2
$L935:
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	move	$2,$18
	move	$3,$fp
	lw	$18,40($sp)
	lw	$fp,64($sp)
	jr	$31
	addiu	$sp,$sp,72

$L915:
	move	$4,$17
	lw	$6,%lo($LC5)($18)
	lw	$7,%lo($LC5+4)($18)
	jal	__subdf3
	move	$5,$16

	lw	$6,%lo($LC5)($18)
	lw	$7,%lo($LC5+4)($18)
	move	$4,$17
	move	$5,$16
	move	$17,$2
	jal	__adddf3
	move	$16,$3

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__divdf3
	move	$7,$3

	move	$16,$2
	li	$2,-2147483648			# 0xffffffff80000000
	xor	$2,$2,$3
	move	$6,$16
	move	$4,$16
	move	$7,$3
	move	$5,$2
	jal	__muldf3
	move	$17,$3

	move	$19,$3
	move	$20,$2
	move	$fp,$16
	move	$22,$17
	li	$18,3			# 0x3
	li	$21,61			# 0x3d
$L917:
	move	$5,$17
	move	$6,$20
	move	$4,$16
	jal	__muldf3
	move	$7,$19

	move	$4,$18
	move	$17,$3
	jal	__floatsidf
	move	$16,$2

	move	$6,$2
	move	$7,$3
	move	$4,$16
	jal	__divdf3
	move	$5,$17

	move	$6,$2
	move	$4,$fp
	move	$5,$22
	jal	__adddf3
	move	$7,$3

	addiu	$18,$18,2
	move	$fp,$2
	.set	noat
	xor	$1,$18,$21
	bne	$1,$0,$L917
	.set	at
	move	$22,$3

	move	$4,$2
	lui	$2,%hi($LC14)
	lw	$6,%lo($LC14)($2)
	lw	$7,%lo($LC14+4)($2)
	jal	__adddf3
	move	$5,$3

	move	$18,$2
	b	$L918
	move	$fp,$3

$L932:
	lw	$16,16($sp)
	b	$L913
	move	$17,$23

$L934:
	li	$2,-2147483648			# 0xffffffff80000000
	xor	$2,$16,$2
	b	$L911
	sw	$2,16($sp)

	.set	macro
	.set	reorder
	.end	atan
	.size	atan, .-atan
	.globl	__gedf2
	.align	2
	.globl	atan2
	.set	nomips16
	.set	nomicromips
	.ent	atan2
	.type	atan2, @function
atan2:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$6
	move	$16,$7
	sw	$19,32($sp)
	sw	$18,28($sp)
	move	$19,$4
	move	$18,$5
	move	$6,$0
	move	$7,$0
	move	$4,$17
	sw	$31,36($sp)
	jal	__gtdf2
	move	$5,$16

	bgtz	$2,$L956
	move	$4,$17

	move	$5,$16
	move	$6,$0
	jal	__ltdf2
	move	$7,$0

	bltz	$2,$L957
	move	$4,$19

	move	$5,$18
	move	$6,$0
	jal	__gtdf2
	move	$7,$0

	blez	$2,$L958
	lui	$2,%hi($LC13)

	lw	$5,%lo($LC13)($2)
	lw	$4,%lo($LC13+4)($2)
$L936:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,40

$L956:
	move	$4,$19
	move	$5,$18
	move	$6,$17
	jal	__divdf3
	move	$7,$16

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$2
	move	$5,$3
	j	atan
	addiu	$sp,$sp,40

$L957:
	move	$6,$17
	move	$7,$16
	jal	__divdf3
	move	$5,$18

	move	$4,$2
	jal	atan
	move	$5,$3

	move	$4,$19
	move	$5,$18
	move	$6,$0
	move	$7,$0
	move	$16,$3
	jal	__gedf2
	move	$17,$2

	move	$4,$17
	bltz	$2,$L953
	move	$5,$16

	lui	$2,%hi($LC11)
	lw	$6,%lo($LC11)($2)
	jal	__adddf3
	lw	$7,%lo($LC11+4)($2)

	move	$4,$3
	b	$L936
	move	$5,$2

$L958:
	move	$4,$19
	move	$5,$18
	move	$6,$0
	jal	__ltdf2
	move	$7,$0

	bltz	$2,$L959
	lw	$31,36($sp)

	move	$5,$0
	move	$4,$0
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,40

$L959:
	lui	$2,%hi($LC15)
	lw	$5,%lo($LC15)($2)
	b	$L936
	lw	$4,%lo($LC15+4)($2)

$L953:
	lui	$2,%hi($LC11)
	lw	$6,%lo($LC11)($2)
	jal	__subdf3
	lw	$7,%lo($LC11+4)($2)

	move	$4,$3
	b	$L936
	move	$5,$2

	.set	macro
	.set	reorder
	.end	atan2
	.size	atan2, .-atan2
	.align	2
	.globl	exp
	.set	nomips16
	.set	nomicromips
	.ent	exp
	.type	exp, @function
exp:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	lui	$2,%hi($LC5)
	sw	$22,44($sp)
	sw	$18,28($sp)
	lw	$22,%lo($LC5)($2)
	lw	$18,%lo($LC5+4)($2)
	sw	$23,48($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,52($sp)
	move	$20,$4
	move	$19,$5
	li	$23,1			# 0x1
	move	$17,$22
	move	$16,$18
	li	$21,60			# 0x3c
$L961:
	jal	__floatsidf
	move	$4,$23

	move	$6,$2
	move	$7,$3
	move	$4,$20
	jal	__divdf3
	move	$5,$19

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__muldf3
	move	$7,$3

	move	$6,$2
	move	$4,$22
	move	$5,$18
	move	$7,$3
	move	$16,$3
	move	$17,$2
	jal	__adddf3
	addiu	$23,$23,1

	move	$18,$3
	.set	noat
	xor	$1,$23,$21
	bne	$1,$0,$L961
	.set	at
	move	$22,$2

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	exp
	.size	exp, .-exp
	.align	2
	.globl	log
	.set	nomips16
	.set	nomicromips
	.ent	log
	.type	log, @function
log:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$6,$0
	move	$7,$0
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$17,$4
	jal	__ledf2
	move	$16,$5

	blez	$2,$L965
	lw	$31,28($sp)

	move	$4,$17
	move	$5,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	log.part.0
	addiu	$sp,$sp,32

$L965:
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	move	$3,$0
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	log
	.size	log, .-log
	.align	2
	.globl	pow
	.set	nomips16
	.set	nomicromips
	.ent	pow
	.type	pow, @function
pow:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$6
	move	$16,$7
	move	$6,$0
	move	$7,$0
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	move	$19,$4
	jal	__ledf2
	move	$18,$5

	blez	$2,$L970
	move	$2,$0

	move	$4,$19
	jal	log.part.0
	move	$5,$18

$L968:
	move	$4,$17
	move	$5,$16
	move	$6,$2
	jal	__muldf3
	move	$7,$3

	move	$19,$3
	lui	$3,%hi($LC5)
	lw	$22,%lo($LC5)($3)
	lw	$18,%lo($LC5+4)($3)
	move	$20,$2
	move	$17,$22
	move	$16,$18
	li	$23,1			# 0x1
	li	$21,60			# 0x3c
$L969:
	jal	__floatsidf
	move	$4,$23

	move	$6,$2
	move	$7,$3
	move	$4,$20
	jal	__divdf3
	move	$5,$19

	move	$6,$2
	move	$4,$17
	move	$5,$16
	jal	__muldf3
	move	$7,$3

	move	$6,$2
	move	$4,$22
	move	$5,$18
	move	$7,$3
	move	$16,$3
	move	$17,$2
	jal	__adddf3
	addiu	$23,$23,1

	move	$18,$3
	.set	noat
	xor	$1,$23,$21
	bne	$1,$0,$L969
	.set	at
	move	$22,$2

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L970:
	b	$L968
	move	$3,$0

	.set	macro
	.set	reorder
	.end	pow
	.size	pow, .-pow
	.rdata
	.align	2
	.type	CSWTCH.196, @object
	.size	CSWTCH.196, 84
CSWTCH.196:
	.word	10
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	8
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	16
	.globl	stderr
	.data
	.align	2
	.type	stderr, @object
	.size	stderr, 4
stderr:
	.word	f_err
	.globl	stdout
	.align	2
	.type	stdout, @object
	.size	stdout, 4
stdout:
	.word	f_out
	.globl	stdin
	.align	2
	.type	stdin, @object
	.size	stdin, 4
stdin:
	.word	f_in
	.align	2
	.type	f_err, @object
	.size	f_err, 16
f_err:
	.word	2
	.word	0
	.word	0
	.word	-1
	.align	2
	.type	f_out, @object
	.size	f_out, 16
f_out:
	.word	1
	.word	0
	.word	0
	.word	-1
	.align	2
	.type	f_in, @object
	.size	f_in, 16
f_in:
	.word	0
	.word	0
	.word	0
	.word	-1
	.align	2
	.type	rand_state, @object
	.size	rand_state, 4
rand_state:
	.word	1
	.local	free_list
	.comm	free_list,4,4
	.local	heap_ptr
	.comm	heap_ptr,4,4
	.globl	errno
	.section	.bss,"aw",@nobits
	.align	2
	.type	errno, @object
	.size	errno, 4
errno:
	.space	4
	.section	.rodata.cst8,"aM",@progbits,8
	.align	3
$LC2:
	.word	0
	.word	1073741824
	.align	3
$LC3:
	.word	-1961601175
	.word	1074118410
	.align	3
$LC4:
	.word	0
	.word	1071644672
	.align	3
$LC5:
	.word	0
	.word	1072693248
	.align	3
$LC7:
	.word	-1717986918
	.word	1069128089
	.align	3
$LC8:
	.word	0
	.word	1076101120
	.align	3
$LC10:
	.word	1413754136
	.word	1075388923
	.align	3
$LC11:
	.word	1413754136
	.word	1074340347
	.align	3
$LC12:
	.word	1413754136
	.word	-1073143301
	.align	3
$LC13:
	.word	1413754136
	.word	1073291771
	.align	3
$LC14:
	.word	1413754136
	.word	1072243195
	.align	3
$LC15:
	.word	1413754136
	.word	-1074191877
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
