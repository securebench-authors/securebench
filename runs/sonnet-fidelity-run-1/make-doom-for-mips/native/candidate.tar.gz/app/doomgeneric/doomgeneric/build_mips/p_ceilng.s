	.file	1 "p_ceilng.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	T_MoveCeiling
	.set	nomips16
	.set	nomicromips
	.ent	T_MoveCeiling
	.type	T_MoveCeiling, @function
T_MoveCeiling:
	.frame	$sp,40,$31		# vars= 0, regs= 4/0, args= 24, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,36($4)
	addiu	$sp,$sp,-40
	li	$3,-1			# 0xffffffffffffffff
	sw	$16,24($sp)
	sw	$31,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L2
	.set	at
	move	$16,$4

	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L40
	.set	at
	lw	$31,36($sp)

	lw	$6,24($4)
	lw	$5,28($4)
	lw	$4,16($4)
	move	$7,$0
	sw	$2,20($sp)
	jal	T_MovePlane
	sw	$2,16($sp)

	lui	$3,%hi(leveltime)
	lw	$3,%lo(leveltime)($3)
	andi	$3,$3,0x7
	bne	$3,$0,$L6
	move	$17,$2

	lw	$3,12($16)
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L7
	.set	at
	li	$2,2			# 0x2

	lw	$4,16($16)
	li	$5,22			# 0x16
	jal	S_StartSound
	addiu	$4,$4,44

$L6:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L35
	.set	at
	nop

$L1:
	lw	$31,36($sp)
$L40:
	lw	$18,32($sp)
$L41:
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,40

$L2:
	lw	$7,32($4)
	lw	$6,20($4)
	lw	$5,28($4)
	li	$18,1			# 0x1
	lw	$4,16($4)
	sw	$2,20($sp)
	jal	T_MovePlane
	sw	$18,16($sp)

	lui	$3,%hi(leveltime)
	lw	$3,%lo(leveltime)($3)
	andi	$3,$3,0x7
	bne	$3,$0,$L16
	move	$17,$2

	lw	$3,12($16)
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L17
	.set	at
	li	$2,2			# 0x2

	lw	$4,16($16)
	li	$5,22			# 0x16
	jal	S_StartSound
	addiu	$4,$4,44

$L16:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L36
	.set	at
	li	$2,1			# 0x1

	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L40
	.set	at
	lw	$31,36($sp)

	lw	$2,12($16)
	sltu	$3,$2,4
	beq	$3,$0,$L26
	nop

	sltu	$2,$2,2
	bne	$2,$0,$L41
	lw	$18,32($sp)

	li	$2,8192			# 0x2000
$L37:
	b	$L1
	sw	$2,28($16)

$L36:
	lw	$2,12($16)
	sltu	$3,$2,6
	beq	$3,$0,$L1
	sll	$3,$2,2

	lui	$2,%hi($L20)
	addiu	$2,$2,%lo($L20)
	addu	$2,$2,$3
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L20:
	.word	$L23
	.word	$L1
	.word	$L23
	.word	$L22
	.word	$L21
	.word	$L19
	.text
$L35:
	lw	$2,12($16)
	sltu	$3,$2,5
	beq	$3,$0,$L9
	sltu	$3,$2,3

	beq	$3,$0,$L10
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L1
	.set	at
	lui	$18,%hi(activeceilings)

	addiu	$18,$18,%lo(activeceilings)
	move	$2,$18
	move	$17,$0
	b	$L14
	li	$4,30			# 0x1e

$L13:
	.set	noat
	xor	$1,$17,$4
	beq	$1,$0,$L1
	.set	at
	addiu	$2,$2,4

$L14:
	lw	$3,0($2)
	.set	noat
	xor	$1,$16,$3
	bne	$1,$0,$L13
	.set	at
	addiu	$17,$17,1

	addiu	$17,$17,-1
	lw	$2,16($16)
$L39:
	sll	$17,$17,2
	move	$4,$16
	sw	$0,76($2)
	jal	P_RemoveThinker
	addu	$18,$18,$17

	b	$L1
	sw	$0,0($18)

$L26:
	li	$3,5			# 0x5
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L40
	.set	at
	lw	$31,36($sp)

	b	$L37
	li	$2,8192			# 0x2000

$L19:
	lw	$4,16($16)
	li	$5,19			# 0x13
	jal	S_StartSound
	addiu	$4,$4,44

$L22:
	li	$2,65536			# 0x10000
	sw	$2,28($16)
$L21:
	li	$2,1			# 0x1
	b	$L1
	sw	$2,36($16)

$L17:
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L19
	.set	at
	nop

	.set	noat
	xor	$1,$17,$18
	bne	$1,$0,$L40
	.set	at
	lw	$31,36($sp)

	b	$L37
	li	$2,8192			# 0x2000

$L7:
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L40
	.set	at
	lw	$31,36($sp)

	lw	$4,16($16)
$L38:
	li	$5,19			# 0x13
	jal	S_StartSound
	addiu	$4,$4,44

$L10:
	li	$2,-1			# 0xffffffffffffffff
	b	$L1
	sw	$2,36($16)

$L9:
	li	$3,5			# 0x5
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L40
	.set	at
	lw	$31,36($sp)

	b	$L38
	lw	$4,16($16)

$L23:
	lui	$18,%hi(activeceilings)
	addiu	$18,$18,%lo(activeceilings)
	move	$2,$18
	move	$17,$0
	b	$L25
	li	$4,30			# 0x1e

$L24:
	.set	noat
	xor	$1,$17,$4
	beq	$1,$0,$L1
	.set	at
	addiu	$2,$2,4

$L25:
	lw	$3,0($2)
	.set	noat
	xor	$1,$16,$3
	bne	$1,$0,$L24
	.set	at
	addiu	$17,$17,1

	addiu	$17,$17,-1
	b	$L39
	lw	$2,16($16)

	.set	macro
	.set	reorder
	.end	T_MoveCeiling
	.size	T_MoveCeiling, .-T_MoveCeiling
	.align	2
	.globl	P_AddActiveCeiling
	.set	nomips16
	.set	nomicromips
	.ent	P_AddActiveCeiling
	.type	P_AddActiveCeiling, @function
P_AddActiveCeiling:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$7,%hi(activeceilings)
	addiu	$7,$7,%lo(activeceilings)
	move	$3,$7
	move	$2,$0
	b	$L45
	li	$6,30			# 0x1e

$L43:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L48
	.set	at
	nop

$L45:
	lw	$5,0($3)
	bne	$5,$0,$L43
	addiu	$3,$3,4

	sll	$2,$2,2
	addu	$7,$7,$2
	jr	$31
	sw	$4,0($7)

$L48:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_AddActiveCeiling
	.size	P_AddActiveCeiling, .-P_AddActiveCeiling
	.align	2
	.globl	P_RemoveActiveCeiling
	.set	nomips16
	.set	nomicromips
	.ent	P_RemoveActiveCeiling
	.type	P_RemoveActiveCeiling, @function
P_RemoveActiveCeiling:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lui	$17,%hi(activeceilings)
	addiu	$17,$17,%lo(activeceilings)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$2,$17
	move	$16,$0
	b	$L52
	li	$5,30			# 0x1e

$L50:
	addiu	$16,$16,1
	.set	noat
	xor	$1,$16,$5
	beq	$1,$0,$L55
	.set	at
	lw	$31,28($sp)

$L52:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L50
	.set	at
	addiu	$2,$2,4

	lw	$2,16($4)
	sll	$16,$16,2
	sw	$0,76($2)
	jal	P_RemoveThinker
	addu	$17,$17,$16

	sw	$0,0($17)
	lw	$31,28($sp)
$L55:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_RemoveActiveCeiling
	.size	P_RemoveActiveCeiling, .-P_RemoveActiveCeiling
	.align	2
	.globl	P_ActivateInStasisCeiling
	.set	nomips16
	.set	nomicromips
	.ent	P_ActivateInStasisCeiling
	.type	P_ActivateInStasisCeiling, @function
P_ActivateInStasisCeiling:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(activeceilings)
	addiu	$2,$2,%lo(activeceilings)
	lui	$8,%hi(T_MoveCeiling)
	addiu	$7,$2,120
	b	$L58
	addiu	$8,$8,%lo(T_MoveCeiling)

$L57:
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L64
	.set	at
	nop

$L58:
	lw	$3,0($2)
	beq	$3,$0,$L57
	addiu	$2,$2,4

	lh	$5,20($4)
	lw	$6,40($3)
	.set	noat
	xor	$1,$6,$5
	bne	$1,$0,$L57
	.set	at
	nop

	lw	$5,36($3)
	bne	$5,$0,$L57
	nop

	lw	$5,44($3)
	sw	$8,8($3)
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L58
	.set	at
	sw	$5,36($3)

$L64:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_ActivateInStasisCeiling
	.size	P_ActivateInStasisCeiling, .-P_ActivateInStasisCeiling
	.align	2
	.globl	EV_DoCeiling
	.set	nomips16
	.set	nomicromips
	.ent	EV_DoCeiling
	.type	EV_DoCeiling, @function
EV_DoCeiling:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$2,$5,-3
	addiu	$sp,$sp,-56
	sltu	$2,$2,3
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	move	$17,$5
	bne	$2,$0,$L86
	move	$16,$4

	lui	$19,%hi($L71)
	sll	$2,$17,2
$L90:
	lui	$20,%hi(T_MoveCeiling)
	addiu	$19,$19,%lo($L71)
	move	$22,$0
	li	$23,-1			# 0xffffffffffffffff
	lui	$18,%hi(sectors)
	addiu	$20,$20,%lo(T_MoveCeiling)
	lui	$21,%hi(activeceilings)
	addu	$19,$19,$2
	move	$5,$23
$L91:
	jal	P_FindSectorFromLineTag
	move	$4,$16

	bltz	$2,$L87
	move	$23,$2

$L80:
	sll	$3,$23,1
	addu	$3,$3,$23
	sll	$3,$3,2
	lw	$fp,%lo(sectors)($18)
	subu	$3,$3,$23
	sll	$3,$3,3
	addu	$fp,$fp,$3
	lw	$2,76($fp)
	bne	$2,$0,$L91
	move	$5,$23

	move	$6,$0
	li	$5,6			# 0x6
	jal	Z_Malloc
	li	$4,48			# 0x30

	move	$4,$2
	jal	P_AddThinker
	move	$22,$2

	sltu	$2,$17,6
	sw	$22,76($fp)
	sw	$20,8($22)
	sw	$fp,16($22)
	beq	$2,$0,$L69
	sw	$0,32($22)

	lw	$2,0($19)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L71:
	.word	$L73
	.word	$L74
	.word	$L73
	.word	$L70
	.word	$L72
	.word	$L70
	.text
$L70:
	lw	$3,4($fp)
	li	$4,1			# 0x1
	lw	$2,0($fp)
	sw	$4,32($22)
	sw	$3,24($22)
	li	$3,524288			# 0x80000
$L89:
	addu	$2,$2,$3
	sw	$2,20($22)
$L76:
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,36($22)
	li	$2,65536			# 0x10000
	sw	$2,28($22)
$L69:
	lh	$3,16($fp)
	addiu	$2,$21,%lo(activeceilings)
	sw	$3,40($22)
	sw	$17,12($22)
	move	$6,$2
	move	$3,$0
	b	$L79
	li	$5,30			# 0x1e

$L77:
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L78
	.set	at
	addiu	$6,$6,4

$L79:
	lw	$4,0($6)
	bne	$4,$0,$L77
	addiu	$3,$3,1

	addiu	$3,$3,-1
	sll	$3,$3,2
	addu	$2,$2,$3
	sw	$22,0($2)
$L78:
	move	$5,$23
	jal	P_FindSectorFromLineTag
	move	$4,$16

	li	$22,1			# 0x1
	bgez	$2,$L80
	move	$23,$2

$L87:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$22
	lw	$22,40($sp)
	jr	$31
	addiu	$sp,$sp,56

$L73:
	lw	$2,0($fp)
	beq	$17,$0,$L76
	sw	$2,20($22)

	b	$L89
	li	$3,524288			# 0x80000

$L74:
	jal	P_FindHighestCeilingSurrounding
	move	$4,$fp

	sw	$2,24($22)
	li	$2,1			# 0x1
	sw	$2,36($22)
	li	$2,65536			# 0x10000
	b	$L69
	sw	$2,28($22)

$L72:
	lw	$2,0($fp)
	li	$4,524288			# 0x80000
	addu	$2,$2,$4
	lw	$3,4($fp)
	sw	$2,20($22)
	li	$2,-1			# 0xffffffffffffffff
	li	$4,1			# 0x1
	sw	$2,36($22)
	li	$2,131072			# 0x20000
	sw	$4,32($22)
	sw	$3,24($22)
	b	$L69
	sw	$2,28($22)

$L86:
	jal	P_ActivateInStasisCeiling
	lui	$19,%hi($L71)

	b	$L90
	sll	$2,$17,2

	.set	macro
	.set	reorder
	.end	EV_DoCeiling
	.size	EV_DoCeiling, .-EV_DoCeiling
	.align	2
	.globl	EV_CeilingCrushStop
	.set	nomips16
	.set	nomicromips
	.ent	EV_CeilingCrushStop
	.type	EV_CeilingCrushStop, @function
EV_CeilingCrushStop:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(activeceilings)
	addiu	$3,$3,%lo(activeceilings)
	addiu	$8,$3,120
	b	$L94
	move	$2,$0

$L93:
	.set	noat
	xor	$1,$8,$3
	beq	$1,$0,$L103
	.set	at
	nop

$L94:
	lw	$5,0($3)
	beq	$5,$0,$L93
	addiu	$3,$3,4

	lh	$6,20($4)
	lw	$7,40($5)
	.set	noat
	xor	$1,$7,$6
	bne	$1,$0,$L93
	.set	at
	nop

	lw	$6,36($5)
	beq	$6,$0,$L93
	nop

	sw	$6,44($5)
	sw	$0,8($5)
	sw	$0,36($5)
	.set	noat
	xor	$1,$8,$3
	bne	$1,$0,$L94
	.set	at
	li	$2,1			# 0x1

$L103:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	EV_CeilingCrushStop
	.size	EV_CeilingCrushStop, .-EV_CeilingCrushStop
	.globl	activeceilings
	.section	.bss,"aw",@nobits
	.align	2
	.type	activeceilings, @object
	.size	activeceilings, 120
activeceilings:
	.space	120
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
