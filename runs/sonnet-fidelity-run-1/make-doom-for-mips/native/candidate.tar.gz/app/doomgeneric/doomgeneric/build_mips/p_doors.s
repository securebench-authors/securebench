	.file	1 "p_doors.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	T_VerticalDoor
	.set	nomips16
	.set	nomicromips
	.ent	T_VerticalDoor
	.type	T_VerticalDoor, @function
T_VerticalDoor:
	.frame	$sp,40,$31		# vars= 0, regs= 4/0, args= 24, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$16,24($sp)
	lw	$16,28($4)
	sw	$18,32($sp)
	li	$18,1			# 0x1
	sw	$17,28($sp)
	sw	$31,36($sp)
	.set	noat
	xor	$1,$16,$18
	beq	$1,$0,$L2
	.set	at
	move	$17,$4

	slt	$2,$16,2
	beq	$2,$0,$L3
	li	$2,-1			# 0xffffffffffffffff

	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L4
	.set	at
	move	$7,$0

	bne	$16,$0,$L1
	nop

	lw	$3,36($4)
	addiu	$3,$3,-1
	bne	$3,$0,$L1
	sw	$3,36($4)

	lw	$3,12($4)
	.set	noat
	xor	$1,$3,$18
	beq	$1,$0,$L10
	.set	at
	li	$5,20			# 0x14

	li	$4,5			# 0x5
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L11
	.set	at
	nop

	beq	$3,$0,$L26
	nop

$L1:
	lw	$31,36($sp)
$L28:
$L30:
	lw	$18,32($sp)
$L29:
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,40

$L3:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L28
	.set	at
	lw	$31,36($sp)

	lw	$2,36($4)
	addiu	$2,$2,-1
	bne	$2,$0,$L1
	sw	$2,36($4)

	lw	$3,12($4)
	li	$2,4			# 0x4
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L28
	.set	at
	lw	$31,36($sp)

	lw	$4,16($4)
	li	$5,20			# 0x14
	sw	$18,28($17)
	b	$L24
	sw	$0,12($17)

$L4:
	lw	$4,16($4)
	lw	$5,24($17)
	lw	$6,0($4)
	sw	$16,20($sp)
	jal	T_MovePlane
	sw	$18,16($sp)

	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L27
	.set	at
	nop

	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L28
	.set	at
	lw	$31,36($sp)

	lw	$4,12($17)
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L28
	.set	at
	li	$3,7			# 0x7

	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L29
	.set	at
	lw	$18,32($sp)

	lw	$4,16($17)
	sw	$2,28($17)
	li	$5,20			# 0x14
$L24:
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addiu	$4,$4,44
	j	S_StartSound
	addiu	$sp,$sp,40

$L2:
	lw	$6,20($4)
	lw	$5,24($4)
	lw	$4,16($4)
	move	$7,$0
	sw	$16,20($sp)
	jal	T_MovePlane
	sw	$16,16($sp)

	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L28
	.set	at
	lw	$31,36($sp)

	lw	$2,12($17)
	sltu	$3,$2,7
	beq	$3,$0,$L30
	sll	$16,$16,$2

	andi	$2,$16,0x4a
	bne	$2,$0,$L19
	andi	$16,$16,0x21

	beq	$16,$0,$L29
	lw	$18,32($sp)

	lw	$2,32($17)
	sw	$0,28($17)
	b	$L1
	sw	$2,36($17)

$L27:
	lw	$2,12($17)
	sltu	$3,$2,8
	beq	$3,$0,$L1
	sll	$3,$2,2

	lui	$2,%hi($L16)
	addiu	$2,$2,%lo($L16)
	addu	$2,$2,$3
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L16:
	.word	$L19
	.word	$L18
	.word	$L19
	.word	$L1
	.word	$L1
	.word	$L15
	.word	$L1
	.word	$L15
	.text
$L26:
	lw	$4,16($17)
	sw	$2,28($17)
	b	$L24
	li	$5,21			# 0x15

$L19:
	lw	$2,16($17)
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$16,24($sp)
	move	$4,$17
	lw	$17,28($sp)
	sw	$0,76($2)
	j	P_RemoveThinker
	addiu	$sp,$sp,40

$L15:
	lw	$2,16($17)
	move	$4,$17
	jal	P_RemoveThinker
	sw	$0,76($2)

	lw	$4,16($17)
	b	$L24
	li	$5,89			# 0x59

$L18:
	li	$2,1050			# 0x41a
	sw	$0,28($17)
	b	$L1
	sw	$2,36($17)

$L11:
	lw	$4,16($17)
	sw	$2,28($17)
	b	$L24
	li	$5,89			# 0x59

$L10:
	lw	$4,16($4)
	b	$L24
	sw	$3,28($17)

	.set	macro
	.set	reorder
	.end	T_VerticalDoor
	.size	T_VerticalDoor, .-T_VerticalDoor
	.align	2
	.globl	EV_DoDoor
	.set	nomips16
	.set	nomicromips
	.ent	EV_DoDoor
	.type	EV_DoDoor, @function
EV_DoDoor:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$19,28($sp)
	lui	$19,%hi($L36)
	sw	$20,32($sp)
	sll	$2,$5,2
	lui	$20,%hi(T_VerticalDoor)
	addiu	$19,$19,%lo($L36)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	move	$18,$5
	move	$16,$4
	move	$22,$0
	li	$23,-1			# 0xffffffffffffffff
	lui	$17,%hi(sectors)
	addiu	$20,$20,%lo(T_VerticalDoor)
	sltu	$21,$5,8
	addu	$19,$19,$2
$L32:
	move	$5,$23
$L47:
	jal	P_FindSectorFromLineTag
	move	$4,$16

	bltz	$2,$L46
	move	$23,$2

	sll	$3,$23,1
	addu	$3,$3,$23
	sll	$3,$3,2
	lw	$fp,%lo(sectors)($17)
	subu	$3,$3,$23
	sll	$3,$3,3
	addu	$fp,$fp,$3
	lw	$2,76($fp)
	bne	$2,$0,$L47
	move	$5,$23

	move	$6,$0
	li	$5,6			# 0x6
	jal	Z_Malloc
	li	$4,40			# 0x28

	move	$4,$2
	jal	P_AddThinker
	move	$22,$2

	li	$2,150			# 0x96
	sw	$22,76($fp)
	sw	$2,32($22)
	li	$2,131072			# 0x20000
	sw	$20,8($22)
	sw	$fp,16($22)
	sw	$18,12($22)
	beq	$21,$0,$L34
	sw	$2,24($22)

	lw	$2,0($19)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L36:
	.word	$L38
	.word	$L40
	.word	$L39
	.word	$L38
	.word	$L34
	.word	$L37
	.word	$L37
	.word	$L35
	.text
$L46:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$22
	lw	$22,40($sp)
	jr	$31
	addiu	$sp,$sp,56

$L37:
	li	$2,1			# 0x1
	move	$4,$fp
	jal	P_FindLowestCeilingSurrounding
	sw	$2,28($22)

	lw	$3,4($fp)
	li	$4,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$4
	li	$4,524288			# 0x80000
	sw	$2,20($22)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L41
	.set	at
	sw	$4,24($22)

$L34:
	b	$L32
	li	$22,1			# 0x1

$L38:
	li	$2,1			# 0x1
	move	$4,$fp
	jal	P_FindLowestCeilingSurrounding
	sw	$2,28($22)

	lw	$3,4($fp)
	li	$4,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L34
	.set	at
	sw	$2,20($22)

	lw	$4,16($22)
	li	$5,20			# 0x14
	jal	S_StartSound
	addiu	$4,$4,44

	b	$L32
	li	$22,1			# 0x1

$L39:
	jal	P_FindLowestCeilingSurrounding
	move	$4,$fp

	li	$3,-262144			# 0xfffffffffffc0000
	lw	$4,16($22)
	addu	$2,$2,$3
	sw	$2,20($22)
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,28($22)
	li	$5,21			# 0x15
	jal	S_StartSound
	addiu	$4,$4,44

	b	$L32
	li	$22,1			# 0x1

$L35:
	jal	P_FindLowestCeilingSurrounding
	move	$4,$fp

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	lw	$4,16($22)
	sw	$2,20($22)
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,28($22)
	li	$2,524288			# 0x80000
	sw	$2,24($22)
	li	$5,89			# 0x59
	jal	S_StartSound
	addiu	$4,$4,44

	b	$L32
	li	$22,1			# 0x1

$L40:
	lw	$2,4($fp)
	li	$5,21			# 0x15
	sw	$2,20($22)
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,28($22)
	jal	S_StartSound
	addiu	$4,$fp,44

	b	$L32
	li	$22,1			# 0x1

$L41:
	lw	$4,16($22)
	li	$5,88			# 0x58
	jal	S_StartSound
	addiu	$4,$4,44

	b	$L32
	li	$22,1			# 0x1

	.set	macro
	.set	reorder
	.end	EV_DoDoor
	.size	EV_DoDoor, .-EV_DoDoor
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"You need a blue key to activate this object\000"
	.align	2
$LC1:
	.ascii	"You need a red key to activate this object\000"
	.align	2
$LC2:
	.ascii	"You need a yellow key to activate this object\000"
	.text
	.align	2
	.globl	EV_DoLockedDoor
	.set	nomips16
	.set	nomicromips
	.ent	EV_DoLockedDoor
	.type	EV_DoLockedDoor, @function
EV_DoLockedDoor:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,132($6)
	beq	$3,$0,$L61
	nop

	lh	$2,18($4)
	addiu	$sp,$sp,-24
	slt	$6,$2,136
	beq	$6,$0,$L50
	sw	$31,20($sp)

	slt	$6,$2,134
	beq	$6,$0,$L51
	li	$6,99			# 0x63

	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L52
	.set	at
	li	$6,133			# 0x85

	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L66
	.set	at
	lw	$31,20($sp)

$L52:
	lw	$2,76($3)
	bne	$2,$0,$L66
	lw	$31,20($sp)

	lw	$2,88($3)
	beq	$2,$0,$L64
	lui	$2,%hi($LC0)

	lw	$31,20($sp)
$L66:
	j	EV_DoDoor
	addiu	$sp,$sp,24

$L50:
	addiu	$2,$2,-136
	andi	$2,$2,0xffff
	sltu	$2,$2,2
	beq	$2,$0,$L66
	lw	$31,20($sp)

	lw	$2,80($3)
	bne	$2,$0,$L66
	nop

	lw	$2,92($3)
	bne	$2,$0,$L66
	lui	$2,%hi($LC2)

	addiu	$2,$2,%lo($LC2)
	sw	$2,224($3)
	li	$5,34			# 0x22
	jal	S_StartSound
	move	$4,$0

	lw	$31,20($sp)
$L65:
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

$L51:
	lw	$2,84($3)
	bne	$2,$0,$L66
	lw	$31,20($sp)

	lw	$2,96($3)
	bne	$2,$0,$L66
	lui	$2,%hi($LC1)

	addiu	$2,$2,%lo($LC1)
	sw	$2,224($3)
	li	$5,34			# 0x22
	jal	S_StartSound
	move	$4,$0

	b	$L65
	lw	$31,20($sp)

$L64:
	addiu	$2,$2,%lo($LC0)
	sw	$2,224($3)
	li	$5,34			# 0x22
	jal	S_StartSound
	move	$4,$0

	b	$L65
	lw	$31,20($sp)

$L61:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	EV_DoLockedDoor
	.size	EV_DoLockedDoor, .-EV_DoLockedDoor
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"You need a blue key to open this door\000"
	.align	2
$LC4:
	.ascii	"You need a yellow key to open this door\000"
	.align	2
$LC5:
	.ascii	"You need a red key to open this door\000"
	.align	2
$LC6:
	.ascii	"EV_VerticalDoor: Tried to close something that wasn't a "
	.ascii	"door.\012\000"
	.text
	.align	2
	.globl	EV_VerticalDoor
	.set	nomips16
	.set	nomicromips
	.ent	EV_VerticalDoor
	.type	EV_VerticalDoor, @function
EV_VerticalDoor:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lh	$6,18($4)
	addiu	$sp,$sp,-32
	andi	$7,$6,0xffff
	addiu	$3,$7,-26
	andi	$3,$3,0xffff
	sltu	$2,$3,9
	lw	$5,132($5)
	sw	$17,20($sp)
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	beq	$2,$0,$L68
	move	$17,$4

	li	$2,1			# 0x1
	sll	$2,$2,$3
	andi	$3,$2,0x84
	bne	$3,$0,$L69
	andi	$3,$2,0x102

	bne	$3,$0,$L70
	andi	$2,$2,0x41

	bne	$2,$0,$L115
	nop

$L71:
	lh	$4,24($17)
	lui	$3,%hi(sides)
	sll	$2,$4,2
	lw	$3,%lo(sides)($3)
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$18,16($2)
	lw	$16,76($18)
	beq	$16,$0,$L111
	slt	$2,$6,29

	beq	$2,$0,$L120
	addiu	$2,$7,-117

$L76:
	lw	$2,28($16)
	li	$17,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L116
	.set	at
	li	$2,1			# 0x1

	beq	$5,$0,$L67
	lui	$2,%hi(T_VerticalDoor)

	lw	$3,8($16)
	addiu	$2,$2,%lo(T_VerticalDoor)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L113
	.set	at
	lui	$2,%hi(T_PlatRaise)

	addiu	$2,$2,%lo(T_PlatRaise)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L113
	.set	at
	lui	$2,%hi(stderr)

	lui	$5,%hi($LC6)
	lw	$4,%lo(stderr)($2)
	jal	fprintf
	addiu	$5,$5,%lo($LC6)

$L113:
	sw	$17,28($16)
$L67:
	lw	$31,28($sp)
$L121:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L70:
	beq	$5,$0,$L121
	lw	$31,28($sp)

	lw	$2,80($5)
	bne	$2,$0,$L71
	nop

	lw	$2,92($5)
	bne	$2,$0,$L71
	lui	$2,%hi($LC4)

	b	$L122
	addiu	$2,$2,%lo($LC4)

$L68:
	lh	$2,24($4)
	li	$4,20			# 0x14
	multu	$2,$4
	mflo	$8
	lui	$3,%hi(sides)
	lw	$3,%lo(sides)($3)
	addu	$2,$8,$3
	lw	$18,16($2)
	lw	$16,76($18)
	beq	$16,$0,$L73
	slt	$2,$6,29

	beq	$2,$0,$L117
	li	$2,1			# 0x1

	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L76
	.set	at
	nop

$L111:
	addiu	$4,$18,44
$L81:
	jal	S_StartSound
	li	$5,20			# 0x14

	li	$5,6			# 0x6
$L119:
	move	$6,$0
	jal	Z_Malloc
	li	$4,40			# 0x28

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	lui	$2,%hi(T_VerticalDoor)
	addiu	$2,$2,%lo(T_VerticalDoor)
	lh	$3,18($17)
	sw	$16,76($18)
	sw	$2,8($16)
	li	$2,131072			# 0x20000
	li	$4,1			# 0x1
	sw	$2,24($16)
	li	$5,117			# 0x75
	li	$2,150			# 0x96
	sw	$18,16($16)
	sw	$4,28($16)
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L83
	.set	at
	sw	$2,32($16)

	slt	$2,$3,118
	beq	$2,$0,$L84
	slt	$2,$3,35

	beq	$2,$0,$L85
	slt	$2,$3,31

	beq	$2,$0,$L86
	nop

	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L87
	.set	at
	addiu	$3,$3,-26

	andi	$3,$3,0xffff
	sltu	$3,$3,3
	bne	$3,$0,$L87
	nop

$L85:
	jal	P_FindLowestCeilingSurrounding
	move	$4,$18

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	sw	$2,20($16)
$L118:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L84:
	li	$2,118			# 0x76
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L85
	.set	at
	li	$2,6			# 0x6

	sw	$2,12($16)
	li	$2,524288			# 0x80000
	sh	$0,18($17)
	move	$4,$18
	jal	P_FindLowestCeilingSurrounding
	sw	$2,24($16)

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	b	$L118
	sw	$2,20($16)

$L115:
	beq	$5,$0,$L121
	lw	$31,28($sp)

	lw	$2,76($5)
	bne	$2,$0,$L71
	nop

	lw	$2,88($5)
	bne	$2,$0,$L71
	lui	$2,%hi($LC3)

	addiu	$2,$2,%lo($LC3)
	lw	$31,28($sp)
$L122:
$L123:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$2,224($5)
	move	$4,$0
	li	$5,34			# 0x22
	j	S_StartSound
	addiu	$sp,$sp,32

$L69:
	beq	$5,$0,$L121
	lw	$31,28($sp)

	lw	$2,84($5)
	bne	$2,$0,$L71
	nop

	lw	$2,96($5)
	bne	$2,$0,$L71
	lui	$2,%hi($LC5)

	b	$L123
	addiu	$2,$2,%lo($LC5)

$L87:
	sw	$0,12($16)
	jal	P_FindLowestCeilingSurrounding
	move	$4,$18

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	b	$L118
	sw	$2,20($16)

$L83:
	li	$2,5			# 0x5
	sw	$2,12($16)
	li	$2,524288			# 0x80000
	sw	$2,24($16)
	jal	P_FindLowestCeilingSurrounding
	move	$4,$18

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	b	$L118
	sw	$2,20($16)

$L86:
	li	$2,3			# 0x3
	sw	$2,12($16)
	move	$4,$18
	jal	P_FindLowestCeilingSurrounding
	sh	$0,18($17)

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	b	$L118
	sw	$2,20($16)

$L116:
	b	$L67
	sw	$2,28($16)

$L117:
	li	$2,117			# 0x75
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L76
	.set	at
	nop

$L73:
	addiu	$2,$7,-117
$L120:
	sltu	$2,$2,2
	beq	$2,$0,$L81
	addiu	$4,$18,44

	jal	S_StartSound
	li	$5,88			# 0x58

	b	$L119
	li	$5,6			# 0x6

	.set	macro
	.set	reorder
	.end	EV_VerticalDoor
	.size	EV_VerticalDoor, .-EV_VerticalDoor
	.align	2
	.globl	P_SpawnDoorCloseIn30
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnDoorCloseIn30
	.type	P_SpawnDoorCloseIn30, @function
P_SpawnDoorCloseIn30:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$6,$0
	li	$5,6			# 0x6
	sw	$17,24($sp)
	move	$17,$4
	li	$4,40			# 0x28
	sw	$31,28($sp)
	jal	Z_Malloc
	sw	$16,20($sp)

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	lui	$2,%hi(T_VerticalDoor)
	addiu	$2,$2,%lo(T_VerticalDoor)
	sw	$16,76($17)
	sh	$0,14($17)
	lw	$31,28($sp)
	sw	$2,8($16)
	li	$2,131072			# 0x20000
	sw	$2,24($16)
	li	$2,1050			# 0x41a
	sw	$17,16($16)
	sw	$0,28($16)
	lw	$17,24($sp)
	sw	$0,12($16)
	sw	$2,36($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_SpawnDoorCloseIn30
	.size	P_SpawnDoorCloseIn30, .-P_SpawnDoorCloseIn30
	.align	2
	.globl	P_SpawnDoorRaiseIn5Mins
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnDoorRaiseIn5Mins
	.type	P_SpawnDoorRaiseIn5Mins, @function
P_SpawnDoorRaiseIn5Mins:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$6,$0
	li	$5,6			# 0x6
	sw	$17,24($sp)
	move	$17,$4
	li	$4,40			# 0x28
	sw	$31,28($sp)
	jal	Z_Malloc
	sw	$16,20($sp)

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	lui	$2,%hi(T_VerticalDoor)
	addiu	$2,$2,%lo(T_VerticalDoor)
	sw	$16,76($17)
	sh	$0,14($17)
	sw	$2,8($16)
	li	$2,2			# 0x2
	sw	$2,28($16)
	li	$2,4			# 0x4
	sw	$2,12($16)
	li	$2,131072			# 0x20000
	sw	$17,16($16)
	move	$4,$17
	jal	P_FindLowestCeilingSurrounding
	sw	$2,24($16)

	li	$3,-262144			# 0xfffffffffffc0000
	addu	$2,$2,$3
	sw	$2,20($16)
	lw	$31,28($sp)
	li	$2,150			# 0x96
	sw	$2,32($16)
	li	$2,10500			# 0x2904
	lw	$17,24($sp)
	sw	$2,36($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_SpawnDoorRaiseIn5Mins
	.size	P_SpawnDoorRaiseIn5Mins, .-P_SpawnDoorRaiseIn5Mins
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
