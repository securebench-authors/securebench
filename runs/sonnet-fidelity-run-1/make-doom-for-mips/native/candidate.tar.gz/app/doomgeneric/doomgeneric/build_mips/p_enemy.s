	.file	1 "p_enemy.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	PIT_VileCheck
	.set	nomips16
	.set	nomicromips
	.ent	PIT_VileCheck
	.type	PIT_VileCheck, @function
PIT_VileCheck:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	li	$3,1048576			# 0x100000
	and	$2,$2,$3
	beq	$2,$0,$L12
	nop

	lw	$3,96($4)
	addiu	$sp,$sp,-32
	li	$2,-1			# 0xffffffffffffffff
	sw	$16,20($sp)
	sw	$31,28($sp)
	sw	$17,24($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L13
	.set	at
	move	$16,$4

$L4:
	li	$2,1			# 0x1
$L1:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L13:
	lw	$2,92($4)
	lw	$3,88($2)
	beq	$3,$0,$L4
	lui	$3,%hi(viletryx)

	lw	$17,64($2)
	lw	$4,12($4)
	lw	$3,%lo(viletryx)($3)
	lui	$2,%hi(mobjinfo+340)
	lw	$2,%lo(mobjinfo+340)($2)
	subu	$4,$4,$3
	jal	abs
	addu	$17,$17,$2

	slt	$2,$17,$2
	bne	$2,$0,$L1
	li	$2,1			# 0x1

	lui	$2,%hi(viletryy)
	lw	$4,16($16)
	lw	$2,%lo(viletryy)($2)
	jal	abs
	subu	$4,$4,$2

	slt	$2,$17,$2
	bne	$2,$0,$L4
	lui	$17,%hi(corpsehit)

	lw	$2,68($16)
	lw	$6,16($16)
	sll	$2,$2,2
	lw	$5,12($16)
	move	$4,$16
	sw	$0,76($16)
	sw	$0,72($16)
	sw	$2,68($16)
	jal	P_CheckPosition
	sw	$16,%lo(corpsehit)($17)

	lw	$4,%lo(corpsehit)($17)
	sltu	$2,$2,1
	lw	$3,68($4)
	sra	$3,$3,2
	b	$L1
	sw	$3,68($4)

$L12:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	PIT_VileCheck
	.size	PIT_VileCheck, .-PIT_VileCheck
	.align	2
	.globl	P_RecursiveSound
	.set	nomips16
	.set	nomicromips
	.ent	P_RecursiveSound
	.type	P_RecursiveSound, @function
P_RecursiveSound:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(validcount)
	lw	$3,68($4)
	lw	$2,%lo(validcount)($2)
	addiu	$sp,$sp,-48
	sw	$18,28($sp)
	sw	$16,20($sp)
	sw	$31,44($sp)
	move	$16,$4
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$17,24($sp)
	move	$18,$5
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L31
	.set	at
	addiu	$4,$5,1

$L15:
	lui	$3,%hi(soundtarget)
	lw	$5,%lo(soundtarget)($3)
	lw	$3,80($16)
	sw	$2,68($16)
	sw	$4,20($16)
	blez	$3,$L14
	sw	$5,24($16)

	move	$17,$0
	lui	$19,%hi(openrange)
	lui	$20,%hi(sides)
$L22:
	lw	$2,84($16)
	sll	$4,$17,2
	addu	$2,$2,$4
	lw	$21,0($2)
	lhu	$2,16($21)
	andi	$2,$2,0x4
	beq	$2,$0,$L18
	nop

	jal	P_LineOpening
	move	$4,$21

	lw	$2,%lo(openrange)($19)
	blez	$2,$L29
	nop

	lh	$3,22($21)
	lw	$5,%lo(sides)($20)
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$5,$2
	lw	$4,16($2)
	.set	noat
	xor	$1,$16,$4
	beq	$1,$0,$L32
	.set	at
	nop

$L20:
	lhu	$2,16($21)
	andi	$2,$2,0x40
	beq	$2,$0,$L21
	nop

	beq	$18,$0,$L27
	nop

$L29:
	lw	$3,80($16)
$L18:
	addiu	$17,$17,1
	slt	$2,$17,$3
	bne	$2,$0,$L22
	nop

$L14:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L27:
	jal	P_RecursiveSound
	li	$5,1			# 0x1

	b	$L18
	lw	$3,80($16)

$L21:
	jal	P_RecursiveSound
	move	$5,$18

	b	$L18
	lw	$3,80($16)

$L32:
	lh	$3,24($21)
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$5,$5,$2
	b	$L20
	lw	$4,16($5)

$L31:
	lw	$3,20($16)
	slt	$3,$4,$3
	bne	$3,$0,$L15
	lw	$31,44($sp)

	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	P_RecursiveSound
	.size	P_RecursiveSound, .-P_RecursiveSound
	.align	2
	.globl	P_NoiseAlert
	.set	nomips16
	.set	nomicromips
	.ent	P_NoiseAlert
	.type	P_NoiseAlert, @function
P_NoiseAlert:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$5,52($5)
	lui	$3,%hi(validcount)
	lw	$2,%lo(validcount)($3)
	move	$7,$4
	lw	$4,0($5)
	addiu	$2,$2,1
	lui	$6,%hi(soundtarget)
	move	$5,$0
	sw	$7,%lo(soundtarget)($6)
	j	P_RecursiveSound
	sw	$2,%lo(validcount)($3)

	.set	macro
	.set	reorder
	.end	P_NoiseAlert
	.size	P_NoiseAlert, .-P_NoiseAlert
	.align	2
	.globl	P_CheckMeleeRange
	.set	nomips16
	.set	nomicromips
	.ent	P_CheckMeleeRange
	.type	P_CheckMeleeRange, @function
P_CheckMeleeRange:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lw	$17,120($4)
	sw	$31,28($sp)
	beq	$17,$0,$L37
	sw	$16,20($sp)

	move	$16,$4
	lw	$3,16($4)
	lw	$5,16($17)
	lw	$4,12($17)
	lw	$2,12($16)
	subu	$5,$5,$3
	jal	P_AproxDistance
	subu	$4,$4,$2

	lw	$3,92($17)
	li	$4,2818048			# 0x2b0000
	lw	$3,64($3)
	ori	$4,$4,0xffff
	addu	$3,$3,$4
	slt	$3,$3,$2
	beq	$3,$0,$L39
	nop

$L37:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L39:
	lw	$5,120($16)
	jal	P_CheckSight
	move	$4,$16

	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sltu	$2,$0,$2
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_CheckMeleeRange
	.size	P_CheckMeleeRange, .-P_CheckMeleeRange
	.align	2
	.globl	P_CheckMissileRange
	.set	nomips16
	.set	nomicromips
	.ent	P_CheckMissileRange
	.type	P_CheckMissileRange, @function
P_CheckMissileRange:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$5,120($4)
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_CheckSight
	move	$16,$4

	beq	$2,$0,$L60
	lw	$31,20($sp)

	lw	$2,104($16)
	andi	$3,$2,0x40
	bne	$3,$0,$L56
	li	$3,-65			# 0xffffffffffffffbf

	lw	$2,124($16)
	bne	$2,$0,$L60
	nop

	lw	$2,120($16)
	lw	$5,16($16)
	lw	$3,16($2)
	lw	$4,12($16)
	lw	$2,12($2)
	subu	$5,$5,$3
	jal	P_AproxDistance
	subu	$4,$4,$2

	lw	$3,92($16)
	lw	$3,40($3)
	beq	$3,$0,$L45
	li	$3,-12582912			# 0xffffffffff400000

	li	$3,-4194304			# 0xffffffffffc00000
	addu	$2,$2,$3
$L46:
	lw	$3,88($16)
	li	$4,3			# 0x3
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L57
	.set	at
	sra	$16,$2,16

	li	$4,5			# 0x5
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L49
	.set	at
	li	$4,21			# 0x15

	slt	$16,$16,196
	bne	$16,$0,$L60
	lw	$31,20($sp)

$L52:
	sra	$16,$2,17
	slt	$3,$16,201
$L59:
	li	$2,200			# 0xc8
$L61:
	movz	$16,$2,$3
$L53:
	jal	P_Random
	nop

	lw	$31,20($sp)
	slt	$2,$2,$16
	xori	$2,$2,0x1
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L57:
	slt	$2,$16,897
	bne	$2,$0,$L59
	slt	$3,$16,201

	lw	$31,20($sp)
$L60:
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

$L56:
	and	$2,$2,$3
	sw	$2,104($16)
	lw	$16,16($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,24

$L45:
	b	$L46
	addu	$2,$2,$3

$L49:
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L58
	.set	at
	li	$4,19			# 0x13

	sra	$16,$2,17
	slt	$3,$16,161
	li	$2,160			# 0xa0
	b	$L53
	movz	$16,$2,$3

$L58:
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L52
	.set	at
	li	$4,18			# 0x12

	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L52
	.set	at
	slt	$3,$16,201

	b	$L61
	li	$2,200			# 0xc8

	.set	macro
	.set	reorder
	.end	P_CheckMissileRange
	.size	P_CheckMissileRange, .-P_CheckMissileRange
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Weird actor->movedir!\000"
	.text
	.align	2
	.globl	P_Move
	.set	nomips16
	.set	nomicromips
	.ent	P_Move
	.type	P_Move, @function
P_Move:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,112($4)
	addiu	$sp,$sp,-40
	li	$3,8			# 0x8
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L71
	.set	at
	sw	$16,16($sp)

	sltu	$3,$2,8
	beq	$3,$0,$L86
	move	$16,$4

$L65:
	lui	$3,%hi(yspeed)
	lw	$5,92($16)
	sll	$2,$2,2
	addiu	$3,$3,%lo(yspeed)
	addu	$3,$2,$3
	lw	$7,60($5)
	lw	$6,0($3)
	lui	$4,%hi(xspeed)
	addiu	$4,$4,%lo(xspeed)
	addu	$2,$2,$4
	multu	$7,$6
	mflo	$4
	lw	$5,0($2)
	lw	$3,16($16)
	lw	$2,12($16)
	addu	$6,$4,$3
	multu	$7,$5
	mflo	$3
	move	$4,$16
	jal	P_TryMove
	addu	$5,$3,$2

	bne	$2,$0,$L66
	move	$17,$2

	lw	$2,104($16)
	andi	$3,$2,0x4000
	beq	$3,$0,$L90
	lui	$18,%hi(numspechit)

	lui	$3,%hi(floatok)
	lw	$3,%lo(floatok)($3)
	beq	$3,$0,$L91
	lw	$3,%lo(numspechit)($18)

	lui	$4,%hi(tmfloorz)
	lw	$3,20($16)
	lw	$4,%lo(tmfloorz)($4)
	slt	$4,$3,$4
	bne	$4,$0,$L87
	li	$4,262144			# 0x40000

	li	$4,-262144			# 0xfffffffffffc0000
	addu	$3,$3,$4
$L69:
	li	$4,2097152			# 0x200000
	or	$2,$2,$4
	sw	$3,20($16)
	sw	$2,104($16)
$L70:
	li	$17,1			# 0x1
$L88:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L66:
	lw	$3,104($16)
	li	$2,-2162688			# 0xffffffffffdf0000
	ori	$2,$2,0xffff
	and	$2,$3,$2
	andi	$3,$3,0x4000
	bne	$3,$0,$L70
	sw	$2,104($16)

	lw	$2,56($16)
	li	$17,1			# 0x1
	b	$L88
	sw	$2,20($16)

$L90:
	lw	$3,%lo(numspechit)($18)
$L91:
	bne	$3,$0,$L89
	li	$2,8			# 0x8

$L71:
	lw	$31,36($sp)
	move	$17,$0
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L86:
	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	b	$L65
	lw	$2,112($16)

$L89:
	addiu	$3,$3,-1
	lui	$19,%hi(spechit)
	sw	$2,112($16)
	sw	$3,%lo(numspechit)($18)
	addiu	$19,$19,%lo(spechit)
	li	$20,1			# 0x1
$L73:
	sll	$3,$3,2
	addu	$3,$19,$3
	lw	$5,0($3)
	move	$4,$16
	jal	P_UseSpecialLine
	move	$6,$0

	lw	$4,%lo(numspechit)($18)
	movn	$17,$20,$2
	addiu	$3,$4,-1
	bne	$4,$0,$L73
	sw	$3,%lo(numspechit)($18)

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L87:
	b	$L69
	addu	$3,$3,$4

	.set	macro
	.set	reorder
	.end	P_Move
	.size	P_Move, .-P_Move
	.align	2
	.globl	P_TryWalk
	.set	nomips16
	.set	nomicromips
	.ent	P_TryWalk
	.type	P_TryWalk, @function
P_TryWalk:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_Move
	move	$16,$4

	beq	$2,$0,$L98
	lw	$31,20($sp)

	jal	P_Random
	nop

	andi	$2,$2,0xf
	sw	$2,116($16)
	li	$2,1			# 0x1
	lw	$31,20($sp)
$L98:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_TryWalk
	.size	P_TryWalk, .-P_TryWalk
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"P_NewChaseDir: called with no target\000"
	.text
	.align	2
	.globl	P_NewChaseDir
	.set	nomips16
	.set	nomicromips
	.ent	P_NewChaseDir
	.type	P_NewChaseDir, @function
P_NewChaseDir:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	addiu	$sp,$sp,-48
	sw	$16,16($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	beq	$2,$0,$L157
	move	$16,$4

$L100:
	lw	$17,12($2)
	lw	$19,112($16)
	lw	$6,12($16)
	lw	$20,16($2)
	lui	$4,%hi(opposite)
	li	$2,655360			# 0xa0000
	addiu	$4,$4,%lo(opposite)
	lw	$5,16($16)
	sll	$3,$19,2
	subu	$17,$17,$6
	addiu	$2,$2,1
	addu	$3,$3,$4
	slt	$4,$17,$2
	lw	$18,0($3)
	subu	$20,$20,$5
	bne	$4,$0,$L101
	li	$3,-655360			# 0xfffffffffff60000

	slt	$3,$20,$3
	beq	$3,$0,$L158
	slt	$2,$20,$2

	li	$21,6			# 0x6
	move	$22,$0
$L102:
	sra	$2,$20,30
	slt	$3,$0,$17
	andi	$2,$2,0x2
	addu	$2,$2,$3
	lui	$3,%hi(diags)
	sll	$2,$2,2
	addiu	$3,$3,%lo(diags)
	addu	$2,$2,$3
	lw	$2,0($2)
	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L103
	.set	at
	sw	$2,112($16)

	jal	P_Move
	move	$4,$16

	bne	$2,$0,$L154
	nop

$L103:
	jal	P_Random
	nop

	slt	$2,$2,201
	bne	$2,$0,$L159
	nop

$L108:
	move	$2,$22
	move	$22,$21
	.set	noat
	xor	$1,$22,$18
	beq	$1,$0,$L160
	.set	at
	move	$21,$2

$L110:
	.set	noat
	xor	$1,$18,$21
	beq	$1,$0,$L161
	.set	at
	li	$2,8			# 0x8

	.set	noat
	xor	$1,$22,$2
	beq	$1,$0,$L168
	.set	at
	nop

	sw	$22,112($16)
	jal	P_Move
	move	$4,$16

	bne	$2,$0,$L154
	nop

$L112:
	li	$2,8			# 0x8
$L168:
	.set	noat
	xor	$1,$21,$2
	beq	$1,$0,$L167
	.set	at
	li	$2,8			# 0x8

	sw	$21,112($16)
	jal	P_Move
	move	$4,$16

	bne	$2,$0,$L154
	li	$2,8			# 0x8

$L167:
	.set	noat
	xor	$1,$19,$2
	beq	$1,$0,$L115
	.set	at
	nop

	sw	$19,112($16)
	jal	P_Move
	move	$4,$16

	bne	$2,$0,$L154
	nop

$L115:
	jal	P_Random
	nop

	andi	$2,$2,0x1
	beq	$2,$0,$L129
	nop

	move	$17,$0
	b	$L118
	li	$19,8			# 0x8

$L117:
	addiu	$17,$17,1
$L170:
	.set	noat
	xor	$1,$17,$19
	beq	$1,$0,$L169
	.set	at
	li	$2,8			# 0x8

$L118:
	.set	noat
	xor	$1,$18,$17
	beq	$1,$0,$L117
	.set	at
	move	$4,$16

	jal	P_Move
	sw	$17,112($16)

	beq	$2,$0,$L170
	addiu	$17,$17,1

$L154:
	jal	P_Random
	nop

	lw	$31,44($sp)
	andi	$2,$2,0xf
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$2,116($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L101:
	slt	$4,$17,$3
	beq	$4,$0,$L162
	slt	$3,$20,$3

	bne	$3,$0,$L127
	li	$21,6			# 0x6

	slt	$2,$20,$2
	bne	$2,$0,$L128
	nop

	li	$21,2			# 0x2
	b	$L102
	li	$22,4			# 0x4

$L162:
	beq	$3,$0,$L163
	slt	$2,$20,$2

	jal	P_Random
	li	$21,6			# 0x6

	slt	$2,$2,201
	beq	$2,$0,$L108
	li	$22,8			# 0x8

$L159:
	jal	abs
	move	$4,$20

	move	$4,$17
	jal	abs
	move	$17,$2

	slt	$17,$2,$17
	bne	$17,$0,$L108
	nop

	.set	noat
	xor	$1,$22,$18
	bne	$1,$0,$L110
	.set	at
	nop

$L160:
	.set	noat
	xor	$1,$18,$21
	bne	$1,$0,$L112
	.set	at
	li	$2,8			# 0x8

	b	$L167
	nop

$L158:
	bne	$2,$0,$L164
	nop

	li	$21,2			# 0x2
	b	$L102
	move	$22,$0

$L122:
$L169:
	.set	noat
	xor	$1,$18,$2
	bne	$1,$0,$L165
	.set	at
	li	$2,8			# 0x8

	sw	$2,112($16)
$L166:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L129:
	li	$17,7			# 0x7
	b	$L116
	li	$19,-1			# 0xffffffffffffffff

$L121:
	addiu	$17,$17,-1
$L171:
	.set	noat
	xor	$1,$17,$19
	beq	$1,$0,$L122
	.set	at
	li	$2,8			# 0x8

$L116:
	.set	noat
	xor	$1,$18,$17
	beq	$1,$0,$L121
	.set	at
	move	$4,$16

	jal	P_Move
	sw	$17,112($16)

	beq	$2,$0,$L171
	addiu	$17,$17,-1

	b	$L154
	nop

$L161:
	.set	noat
	xor	$1,$22,$2
	beq	$1,$0,$L167
	.set	at
	li	$2,8			# 0x8

	sw	$22,112($16)
	jal	P_Move
	move	$4,$16

	beq	$2,$0,$L167
	li	$2,8			# 0x8

	b	$L154
	nop

$L165:
	sw	$18,112($16)
	jal	P_Move
	move	$4,$16

	bne	$2,$0,$L154
	li	$2,8			# 0x8

	b	$L166
	sw	$2,112($16)

$L163:
	li	$21,2			# 0x2
	li	$3,8			# 0x8
	movn	$21,$3,$2
	b	$L103
	li	$22,8			# 0x8

$L164:
	li	$21,8			# 0x8
	b	$L103
	move	$22,$0

$L127:
	b	$L102
	li	$22,4			# 0x4

$L157:
	lui	$4,%hi($LC1)
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	b	$L100
	lw	$2,120($16)

$L128:
	li	$21,8			# 0x8
	b	$L103
	li	$22,4			# 0x4

	.set	macro
	.set	reorder
	.end	P_NewChaseDir
	.size	P_NewChaseDir, .-P_NewChaseDir
	.align	2
	.globl	P_LookForPlayers
	.set	nomips16
	.set	nomicromips
	.ent	P_LookForPlayers
	.type	P_LookForPlayers, @function
P_LookForPlayers:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$16,24($sp)
	lw	$16,136($4)
	sw	$fp,56($sp)
	li	$fp,-1073807360			# 0xffffffffbfff0000
	sw	$21,44($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	addiu	$21,$16,-1
	lui	$19,%hi(playeringame)
	lui	$18,%hi(players)
	ori	$2,$fp,0xffff
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$20,40($sp)
	sw	$31,60($sp)
	sw	$17,28($sp)
	move	$23,$4
	sw	$5,68($sp)
	andi	$21,$21,0x3
	move	$3,$0
	li	$20,1			# 0x1
	addiu	$19,$19,%lo(playeringame)
	li	$22,2			# 0x2
	addiu	$18,$18,%lo(players)
	sw	$2,16($sp)
$L177:
	sll	$2,$16,2
	addu	$2,$19,$2
	lw	$2,0($2)
	beq	$2,$0,$L173
	nop

	.set	noat
	xor	$1,$3,$22
	beq	$1,$0,$L186
	.set	at
	lw	$31,60($sp)

	.set	noat
	xor	$1,$21,$16
	beq	$1,$0,$L186
	.set	at
	sll	$17,$16,3

	addu	$3,$17,$16
	sll	$3,$3,5
	addu	$fp,$18,$3
	lw	$2,40($fp)
	blez	$2,$L180
	move	$3,$20

	lw	$5,0($fp)
	jal	P_CheckSight
	move	$4,$23

	beq	$2,$0,$L185
	nop

	lw	$3,68($sp)
	bne	$3,$0,$L176
	lw	$2,0($fp)

	lw	$4,12($23)
	lw	$7,16($2)
	lw	$6,12($2)
	jal	R_PointToAngle2
	lw	$5,16($23)

	lw	$4,32($23)
	lw	$3,16($sp)
	subu	$4,$3,$4
	addu	$4,$4,$2
	li	$2,2147418112			# 0x7fff0000
	ori	$2,$2,0xffff
	sltu	$4,$4,$2
	beq	$4,$0,$L176
	nop

	lw	$2,0($fp)
	lw	$3,16($23)
	lw	$5,16($2)
	lw	$4,12($2)
	lw	$2,12($23)
	subu	$5,$5,$3
	jal	P_AproxDistance
	subu	$4,$4,$2

	li	$3,4194304			# 0x400000
	addiu	$3,$3,1
	slt	$2,$2,$3
	beq	$2,$0,$L185
	nop

$L176:
	addu	$17,$17,$16
	sll	$17,$17,5
	addu	$18,$18,$17
	lw	$3,0($18)
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	sw	$3,120($23)
	li	$2,1			# 0x1
	lw	$23,52($sp)
	jr	$31
	addiu	$sp,$sp,64

$L180:
	addiu	$20,$20,1
$L173:
	addiu	$16,$16,1
	andi	$16,$16,0x3
	b	$L177
	sw	$16,136($23)

$L185:
	lw	$16,136($23)
	move	$3,$20
	addiu	$16,$16,1
	andi	$16,$16,0x3
	addiu	$20,$20,1
	b	$L177
	sw	$16,136($23)

$L186:
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	P_LookForPlayers
	.size	P_LookForPlayers, .-P_LookForPlayers
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	A_SpawnFly.part.0
	.type	A_SpawnFly.part.0, @function
A_SpawnFly.part.0:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	move	$17,$4
	lw	$4,120($4)
	sw	$31,28($sp)
	jal	P_SubstNullMobj
	sw	$16,20($sp)

	lw	$6,20($2)
	lw	$5,16($2)
	lw	$4,12($2)
	li	$7,29			# 0x1d
	jal	P_SpawnMobj
	move	$16,$2

	move	$4,$2
	jal	S_StartSound
	li	$5,35			# 0x23

	jal	P_Random
	nop

	slt	$3,$2,50
	bne	$3,$0,$L190
	li	$7,11			# 0xb

	slt	$3,$2,90
	beq	$3,$0,$L204
	slt	$3,$2,120

	lw	$5,16($16)
	lw	$4,12($16)
	lw	$6,20($16)
	jal	P_SpawnMobj
	li	$7,12			# 0xc

	move	$4,$2
	li	$5,1			# 0x1
	jal	P_LookForPlayers
	move	$16,$2

	beq	$2,$0,$L189
	nop

$L205:
	lw	$2,92($16)
	move	$4,$16
	jal	P_SetMobjState
	lw	$5,12($2)

	lw	$6,16($16)
	lw	$5,12($16)
	jal	P_TeleportMove
	move	$4,$16

	lw	$31,28($sp)
	lw	$16,20($sp)
	move	$4,$17
	lw	$17,24($sp)
	j	P_RemoveMobj
	addiu	$sp,$sp,32

$L190:
$L188:
	lw	$5,16($16)
	lw	$4,12($16)
	jal	P_SpawnMobj
	lw	$6,20($16)

	move	$4,$2
	li	$5,1			# 0x1
	jal	P_LookForPlayers
	move	$16,$2

	bne	$2,$0,$L205
	nop

$L189:
	lw	$6,16($16)
	lw	$5,12($16)
	jal	P_TeleportMove
	move	$4,$16

	lw	$31,28($sp)
	lw	$16,20($sp)
	move	$4,$17
	lw	$17,24($sp)
	j	P_RemoveMobj
	addiu	$sp,$sp,32

$L204:
	bne	$3,$0,$L188
	li	$7,13			# 0xd

	slt	$3,$2,130
	bne	$3,$0,$L188
	li	$7,22			# 0x16

	slt	$3,$2,160
	bne	$3,$0,$L188
	li	$7,14			# 0xe

	slt	$3,$2,162
	bne	$3,$0,$L188
	li	$7,3			# 0x3

	slt	$3,$2,172
	bne	$3,$0,$L188
	li	$7,5			# 0x5

	slt	$3,$2,192
	bne	$3,$0,$L188
	li	$7,20			# 0x14

	slt	$3,$2,222
	bne	$3,$0,$L198
	slt	$2,$2,246

	li	$7,15			# 0xf
	li	$3,17			# 0x11
	b	$L188
	movn	$7,$3,$2

	b	$L188
	li	$7,22			# 0x16

	b	$L188
	li	$7,3			# 0x3

	b	$L188
	li	$7,20			# 0x14

$L198:
	b	$L188
	li	$7,8			# 0x8

	.set	macro
	.set	reorder
	.end	A_SpawnFly.part.0
	.size	A_SpawnFly.part.0, .-A_SpawnFly.part.0
	.align	2
	.globl	A_KeenDie
	.set	nomips16
	.set	nomicromips
	.ent	A_KeenDie
	.type	A_KeenDie, @function
A_KeenDie:
	.frame	$sp,88,$31		# vars= 64, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(thinkercap)
	lw	$3,104($4)
	addiu	$5,$5,%lo(thinkercap)
	li	$6,-3			# 0xfffffffffffffffd
	lw	$2,4($5)
	and	$3,$3,$6
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L207
	.set	at
	sw	$3,104($4)

	lui	$6,%hi(P_MobjThinker)
	b	$L210
	addiu	$6,$6,%lo(P_MobjThinker)

$L208:
	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L207
	.set	at
	nop

$L210:
	lw	$3,8($2)
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L208
	.set	at
	nop

	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L208
	.set	at
	nop

	lw	$7,88($2)
	lw	$3,88($4)
	.set	noat
	xor	$1,$7,$3
	bne	$1,$0,$L208
	.set	at
	nop

	lw	$3,108($2)
	blez	$3,$L208
	nop

	jr	$31
	nop

$L207:
	addiu	$sp,$sp,-88
	addiu	$4,$sp,16
	li	$2,666			# 0x29a
	li	$5,3			# 0x3
	sw	$31,84($sp)
	jal	EV_DoDoor
	sh	$2,36($sp)

	lw	$31,84($sp)
	jr	$31
	addiu	$sp,$sp,88

	.set	macro
	.set	reorder
	.end	A_KeenDie
	.size	A_KeenDie, .-A_KeenDie
	.align	2
	.globl	A_Look
	.set	nomips16
	.set	nomicromips
	.ent	A_Look
	.type	A_Look, @function
A_Look:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,52($4)
	addiu	$sp,$sp,-24
	lw	$2,0($2)
	sw	$16,16($sp)
	lw	$5,24($2)
	sw	$31,20($sp)
	move	$16,$4
	beq	$5,$0,$L219
	sw	$0,128($4)

	lw	$2,104($5)
	andi	$2,$2,0x4
	beq	$2,$0,$L219
	nop

	lw	$2,104($4)
	andi	$2,$2,0x20
	beq	$2,$0,$L218
	sw	$5,120($4)

	jal	P_CheckSight
	nop

	bne	$2,$0,$L218
	nop

$L219:
	move	$5,$0
	jal	P_LookForPlayers
	move	$4,$16

	beq	$2,$0,$L235
	lw	$31,20($sp)

$L218:
	lw	$2,92($16)
	lw	$5,16($2)
	beq	$5,$0,$L238
	lw	$31,20($sp)

	slt	$2,$5,39
	bne	$2,$0,$L236
	slt	$2,$5,36

	addiu	$2,$5,-39
	sltu	$2,$2,2
	beq	$2,$0,$L225
	nop

	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,1
	and	$5,$2,$3
	bltz	$5,$L237
	li	$2,-2			# 0xfffffffffffffffe

	addiu	$5,$5,39
$L225:
	lw	$2,88($16)
	li	$3,19			# 0x13
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L228
	.set	at
	li	$3,21			# 0x15

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L229
	.set	at
	nop

$L228:
	jal	S_StartSound
	move	$4,$0

	lw	$2,92($16)
	lw	$31,20($sp)
$L238:
	lw	$5,12($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

$L235:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L236:
	bne	$2,$0,$L225
	nop

	jal	P_Random
	nop

	li	$3,1431633920			# 0x55550000
	addiu	$3,$3,21846
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	subu	$3,$3,$4
	sll	$4,$3,1
	addu	$3,$4,$3
	subu	$5,$2,$3
	b	$L225
	addiu	$5,$5,36

$L229:
	jal	S_StartSound
	move	$4,$16

	lw	$2,92($16)
	lw	$31,20($sp)
	lw	$5,12($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

$L237:
	addiu	$5,$5,-1
	or	$5,$5,$2
	addiu	$5,$5,1
	b	$L225
	addiu	$5,$5,39

	.set	macro
	.set	reorder
	.end	A_Look
	.size	A_Look, .-A_Look
	.align	2
	.globl	A_Chase
	.set	nomips16
	.set	nomicromips
	.ent	A_Chase
	.type	A_Chase, @function
A_Chase:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,124($4)
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$2,$0,$L240
	move	$16,$4

	addiu	$2,$2,-1
	sw	$2,124($4)
$L240:
	lw	$4,128($16)
	lw	$3,120($16)
	beq	$4,$0,$L241
	lw	$2,112($16)

	beq	$3,$0,$L242
	nop

	lw	$5,108($3)
	blez	$5,$L297
	addiu	$4,$4,-1

	slt	$5,$2,8
	beq	$5,$0,$L245
	sw	$4,128($16)

$L244:
	lw	$4,32($16)
	li	$5,-536870912			# 0xffffffffe0000000
	and	$4,$4,$5
	sll	$2,$2,29
	subu	$2,$4,$2
	blez	$2,$L298
	nop

$L248:
	addu	$4,$4,$5
	sw	$4,32($16)
$L250:
	beq	$3,$0,$L307
	li	$5,1			# 0x1

$L245:
	lw	$2,104($3)
$L305:
	andi	$2,$2,0x4
	beq	$2,$0,$L307
	li	$5,1			# 0x1

	lw	$2,104($16)
	andi	$3,$2,0x80
	bne	$3,$0,$L299
	lui	$3,%hi(gameskill)

	lw	$2,92($16)
	lw	$3,40($2)
	bne	$3,$0,$L300
	nop

$L257:
	lw	$2,44($2)
	beq	$2,$0,$L308
	lui	$2,%hi(netgame)

	lui	$2,%hi(gameskill)
	lw	$2,%lo(gameskill)($2)
	slt	$2,$2,4
	beq	$2,$0,$L261
	lui	$2,%hi(fastparm)

	lw	$2,%lo(fastparm)($2)
	bne	$2,$0,$L261
	nop

	lw	$2,116($16)
	bne	$2,$0,$L308
	lui	$2,%hi(netgame)

$L261:
	jal	P_CheckMissileRange
	move	$4,$16

	bne	$2,$0,$L301
	lui	$2,%hi(netgame)

$L308:
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L265
	nop

	lw	$2,128($16)
	beq	$2,$0,$L302
	nop

$L265:
	lw	$2,116($16)
	addiu	$2,$2,-1
	bltz	$2,$L263
	sw	$2,116($16)

	jal	P_Move
	move	$4,$16

	bne	$2,$0,$L266
	nop

$L263:
	jal	P_NewChaseDir
	move	$4,$16

$L266:
	lw	$2,92($16)
	lw	$2,80($2)
	beq	$2,$0,$L306
	lw	$31,20($sp)

	jal	P_Random
	nop

	slt	$2,$2,3
	beq	$2,$0,$L306
	lw	$31,20($sp)

	lw	$2,92($16)
	lw	$5,80($2)
	move	$4,$16
	lw	$16,16($sp)
	j	S_StartSound
	addiu	$sp,$sp,24

$L242:
	slt	$4,$2,8
	bne	$4,$0,$L244
	sw	$0,128($16)

	li	$5,1			# 0x1
$L307:
	jal	P_LookForPlayers
	move	$4,$16

	beq	$2,$0,$L303
	lw	$31,20($sp)

$L239:
	lw	$31,20($sp)
$L306:
	lw	$16,16($sp)
$L309:
	jr	$31
	addiu	$sp,$sp,24

$L241:
	slt	$4,$2,8
	beq	$4,$0,$L250
	li	$5,-536870912			# 0xffffffffe0000000

	lw	$4,32($16)
	and	$4,$4,$5
	sll	$2,$2,29
	subu	$2,$4,$2
	bgtz	$2,$L248
	nop

$L298:
	beq	$2,$0,$L295
	li	$2,536870912			# 0x20000000

	addu	$4,$4,$2
$L295:
	b	$L250
	sw	$4,32($16)

$L300:
	jal	P_CheckMeleeRange
	move	$4,$16

	bne	$2,$0,$L258
	nop

	b	$L257
	lw	$2,92($16)

$L303:
	lw	$2,92($16)
	lw	$5,4($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

$L297:
	slt	$4,$2,8
	bne	$4,$0,$L244
	sw	$0,128($16)

	b	$L305
	lw	$2,104($3)

$L299:
	lw	$4,%lo(gameskill)($3)
	li	$3,-129			# 0xffffffffffffff7f
	and	$2,$2,$3
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L239
	.set	at
	sw	$2,104($16)

	lui	$2,%hi(fastparm)
	lw	$2,%lo(fastparm)($2)
	bne	$2,$0,$L306
	lw	$31,20($sp)

	move	$4,$16
	lw	$16,16($sp)
	j	P_NewChaseDir
	addiu	$sp,$sp,24

$L301:
	lw	$2,92($16)
	move	$4,$16
	jal	P_SetMobjState
	lw	$5,44($2)

	lw	$2,104($16)
	ori	$2,$2,0x80
	b	$L239
	sw	$2,104($16)

$L302:
	lw	$5,120($16)
	jal	P_CheckSight
	move	$4,$16

	bne	$2,$0,$L265
	li	$5,1			# 0x1

	jal	P_LookForPlayers
	move	$4,$16

	beq	$2,$0,$L265
	lw	$31,20($sp)

	b	$L309
	lw	$16,16($sp)

$L258:
	lw	$2,92($16)
	lw	$5,24($2)
	bne	$5,$0,$L304
	nop

$L259:
	lw	$31,20($sp)
	lw	$5,40($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

$L304:
	jal	S_StartSound
	move	$4,$16

	b	$L259
	lw	$2,92($16)

	.set	macro
	.set	reorder
	.end	A_Chase
	.size	A_Chase, .-A_Chase
	.align	2
	.globl	A_FaceTarget
	.set	nomips16
	.set	nomicromips
	.ent	A_FaceTarget
	.type	A_FaceTarget, @function
A_FaceTarget:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L322
	nop

	addiu	$sp,$sp,-32
	lw	$3,104($4)
	sw	$16,20($sp)
	move	$16,$4
	li	$4,-33			# 0xffffffffffffffdf
	and	$3,$3,$4
	lw	$7,16($2)
	lw	$6,12($2)
	lw	$5,16($16)
	lw	$4,12($16)
	sw	$31,28($sp)
	sw	$17,24($sp)
	jal	R_PointToAngle2
	sw	$3,104($16)

	lw	$3,120($16)
	lw	$3,104($3)
	sw	$2,32($16)
	li	$2,262144			# 0x40000
	and	$3,$3,$2
	bne	$3,$0,$L321
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L321:
	jal	P_Random
	nop

	jal	P_Random
	move	$17,$2

	subu	$17,$17,$2
	lw	$3,32($16)
	lw	$31,28($sp)
	sll	$17,$17,21
	addu	$3,$3,$17
	sw	$3,32($16)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L322:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_FaceTarget
	.size	A_FaceTarget, .-A_FaceTarget
	.align	2
	.globl	A_PosAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_PosAttack
	.type	A_PosAttack, @function
A_PosAttack:
	.frame	$sp,48,$31		# vars= 0, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L332
	nop

	addiu	$sp,$sp,-48
	sw	$18,36($sp)
	move	$18,$4
	sw	$31,44($sp)
	sw	$19,40($sp)
	sw	$17,32($sp)
	jal	A_FaceTarget
	sw	$16,28($sp)

	lw	$19,32($18)
	li	$6,134217728			# 0x8000000
	move	$5,$19
	jal	P_AimLineAttack
	move	$4,$18

	move	$4,$18
	li	$5,1			# 0x1
	jal	S_StartSound
	move	$17,$2

	jal	P_Random
	nop

	jal	P_Random
	move	$16,$2

	jal	P_Random
	subu	$16,$16,$2

	li	$3,1717960704			# 0x66660000
	addiu	$3,$3,26215
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	sll	$16,$16,20
	sra	$3,$3,1
	subu	$3,$3,$4
	sll	$4,$3,2
	addu	$3,$4,$3
	subu	$3,$2,$3
	addiu	$3,$3,1
	sll	$2,$3,1
	addu	$16,$16,$19
	addu	$2,$2,$3
	sw	$2,16($sp)
	move	$7,$17
	move	$5,$16
	move	$4,$18
	jal	P_LineAttack
	li	$6,134217728			# 0x8000000

	lw	$31,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,48

$L332:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_PosAttack
	.size	A_PosAttack, .-A_PosAttack
	.align	2
	.globl	A_SPosAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_SPosAttack
	.type	A_SPosAttack, @function
A_SPosAttack:
	.frame	$sp,56,$31		# vars= 0, regs= 7/0, args= 24, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L344
	li	$5,2			# 0x2

	addiu	$sp,$sp,-56
	sw	$16,28($sp)
	move	$16,$4
	sw	$31,52($sp)
	sw	$20,44($sp)
	sw	$19,40($sp)
	sw	$18,36($sp)
	sw	$17,32($sp)
	jal	S_StartSound
	sw	$21,48($sp)

	jal	A_FaceTarget
	move	$4,$16

	lw	$20,32($16)
	li	$6,134217728			# 0x8000000
	move	$5,$20
	jal	P_AimLineAttack
	move	$4,$16

	li	$18,1717960704			# 0x66660000
	move	$19,$2
	li	$17,3			# 0x3
	addiu	$18,$18,26215
$L335:
	jal	P_Random
	addiu	$17,$17,-1

	jal	P_Random
	move	$21,$2

	jal	P_Random
	subu	$21,$21,$2

	mult	$2,$18
	sra	$4,$2,31
	mfhi	$3
	sll	$21,$21,20
	sra	$3,$3,1
	subu	$3,$3,$4
	sll	$4,$3,2
	addu	$3,$4,$3
	subu	$3,$2,$3
	addiu	$3,$3,1
	sll	$2,$3,1
	addu	$21,$21,$20
	addu	$2,$2,$3
	sw	$2,16($sp)
	move	$7,$19
	li	$6,134217728			# 0x8000000
	move	$5,$21
	jal	P_LineAttack
	move	$4,$16

	bne	$17,$0,$L335
	lw	$31,52($sp)

	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,56

$L344:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_SPosAttack
	.size	A_SPosAttack, .-A_SPosAttack
	.align	2
	.globl	A_CPosAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_CPosAttack
	.type	A_CPosAttack, @function
A_CPosAttack:
	.frame	$sp,48,$31		# vars= 0, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L354
	li	$5,2			# 0x2

	addiu	$sp,$sp,-48
	sw	$18,36($sp)
	move	$18,$4
	sw	$31,44($sp)
	sw	$19,40($sp)
	sw	$17,32($sp)
	jal	S_StartSound
	sw	$16,28($sp)

	jal	A_FaceTarget
	move	$4,$18

	lw	$19,32($18)
	move	$4,$18
	move	$5,$19
	jal	P_AimLineAttack
	li	$6,134217728			# 0x8000000

	jal	P_Random
	move	$17,$2

	jal	P_Random
	move	$16,$2

	jal	P_Random
	subu	$16,$16,$2

	li	$3,1717960704			# 0x66660000
	addiu	$3,$3,26215
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	sll	$16,$16,20
	sra	$3,$3,1
	subu	$3,$3,$4
	sll	$4,$3,2
	addu	$3,$4,$3
	subu	$3,$2,$3
	addiu	$3,$3,1
	sll	$2,$3,1
	addu	$16,$16,$19
	addu	$2,$2,$3
	sw	$2,16($sp)
	move	$7,$17
	move	$5,$16
	move	$4,$18
	jal	P_LineAttack
	li	$6,134217728			# 0x8000000

	lw	$31,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,48

$L354:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_CPosAttack
	.size	A_CPosAttack, .-A_CPosAttack
	.align	2
	.globl	A_CPosRefire
	.set	nomips16
	.set	nomicromips
	.ent	A_CPosRefire
	.type	A_CPosRefire, @function
A_CPosRefire:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	sw	$16,16($sp)
	jal	A_FaceTarget
	move	$16,$4

	jal	P_Random
	nop

	slt	$2,$2,40
	bne	$2,$0,$L366
	lw	$31,20($sp)

	lw	$5,120($16)
	beq	$5,$0,$L359
	nop

	lw	$2,108($5)
	bgtz	$2,$L365
	nop

$L359:
	lw	$2,92($16)
	lw	$31,20($sp)
	lw	$5,12($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

$L365:
	jal	P_CheckSight
	move	$4,$16

	beq	$2,$0,$L359
	lw	$31,20($sp)

$L366:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_CPosRefire
	.size	A_CPosRefire, .-A_CPosRefire
	.align	2
	.globl	A_SpidRefire
	.set	nomips16
	.set	nomicromips
	.ent	A_SpidRefire
	.type	A_SpidRefire, @function
A_SpidRefire:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	sw	$16,16($sp)
	jal	A_FaceTarget
	move	$16,$4

	jal	P_Random
	nop

	slt	$2,$2,10
	bne	$2,$0,$L378
	lw	$31,20($sp)

	lw	$5,120($16)
	beq	$5,$0,$L371
	nop

	lw	$2,108($5)
	bgtz	$2,$L377
	nop

$L371:
	lw	$2,92($16)
	lw	$31,20($sp)
	lw	$5,12($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

$L377:
	jal	P_CheckSight
	move	$4,$16

	beq	$2,$0,$L371
	lw	$31,20($sp)

$L378:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_SpidRefire
	.size	A_SpidRefire, .-A_SpidRefire
	.align	2
	.globl	A_BspiAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_BspiAttack
	.type	A_BspiAttack, @function
A_BspiAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L384
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	lw	$5,120($16)
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$6,36			# 0x24
	j	P_SpawnMissile
	addiu	$sp,$sp,24

$L384:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_BspiAttack
	.size	A_BspiAttack, .-A_BspiAttack
	.align	2
	.globl	A_TroopAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_TroopAttack
	.type	A_TroopAttack, @function
A_TroopAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L394
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	jal	P_CheckMeleeRange
	move	$4,$16

	bne	$2,$0,$L392
	lw	$31,20($sp)

	lw	$5,120($16)
	move	$4,$16
	lw	$16,16($sp)
	li	$6,31			# 0x1f
	j	P_SpawnMissile
	addiu	$sp,$sp,24

$L392:
	li	$5,55			# 0x37
	jal	S_StartSound
	move	$4,$16

	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,7
	and	$2,$2,$3
	bltz	$2,$L393
	nop

$L388:
	addiu	$2,$2,1
	lw	$4,120($16)
	lw	$31,20($sp)
	sll	$7,$2,1
	move	$6,$16
	move	$5,$16
	lw	$16,16($sp)
	addu	$7,$7,$2
	j	P_DamageMobj
	addiu	$sp,$sp,24

$L394:
	jr	$31
	nop

$L393:
	addiu	$2,$2,-1
	li	$3,-8			# 0xfffffffffffffff8
	or	$2,$2,$3
	b	$L388
	addiu	$2,$2,1

	.set	macro
	.set	reorder
	.end	A_TroopAttack
	.size	A_TroopAttack, .-A_TroopAttack
	.align	2
	.globl	A_SargAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_SargAttack
	.type	A_SargAttack, @function
A_SargAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L407
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	jal	P_CheckMeleeRange
	move	$4,$16

	bne	$2,$0,$L406
	nop

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L406:
	jal	P_Random
	nop

	li	$3,1717960704			# 0x66660000
	addiu	$3,$3,26215
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	lw	$31,20($sp)
	sra	$3,$3,2
	subu	$3,$3,$4
	sll	$4,$3,2
	addu	$3,$4,$3
	sll	$3,$3,1
	subu	$2,$2,$3
	lw	$4,120($16)
	addiu	$7,$2,1
	move	$6,$16
	move	$5,$16
	lw	$16,16($sp)
	sll	$7,$7,2
	j	P_DamageMobj
	addiu	$sp,$sp,24

$L407:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_SargAttack
	.size	A_SargAttack, .-A_SargAttack
	.align	2
	.globl	A_HeadAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_HeadAttack
	.type	A_HeadAttack, @function
A_HeadAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L415
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	jal	P_CheckMeleeRange
	move	$4,$16

	bne	$2,$0,$L414
	nop

	lw	$5,120($16)
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$6,32			# 0x20
	j	P_SpawnMissile
	addiu	$sp,$sp,24

$L414:
	jal	P_Random
	nop

	li	$3,715784192			# 0x2aaa0000
	ori	$3,$3,0xaaab
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	lw	$31,20($sp)
	subu	$3,$3,$4
	sll	$4,$3,1
	addu	$3,$4,$3
	sll	$3,$3,1
	subu	$2,$2,$3
	addiu	$2,$2,1
	sll	$7,$2,2
	lw	$4,120($16)
	addu	$7,$7,$2
	move	$6,$16
	move	$5,$16
	lw	$16,16($sp)
	sll	$7,$7,1
	j	P_DamageMobj
	addiu	$sp,$sp,24

$L415:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_HeadAttack
	.size	A_HeadAttack, .-A_HeadAttack
	.align	2
	.globl	A_CyberAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_CyberAttack
	.type	A_CyberAttack, @function
A_CyberAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L421
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	lw	$5,120($16)
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$6,33			# 0x21
	j	P_SpawnMissile
	addiu	$sp,$sp,24

$L421:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_CyberAttack
	.size	A_CyberAttack, .-A_CyberAttack
	.align	2
	.globl	A_BruisAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_BruisAttack
	.type	A_BruisAttack, @function
A_BruisAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L431
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_CheckMeleeRange
	move	$16,$4

	bne	$2,$0,$L429
	lw	$31,20($sp)

	lw	$5,120($16)
	move	$4,$16
	lw	$16,16($sp)
	li	$6,16			# 0x10
	j	P_SpawnMissile
	addiu	$sp,$sp,24

$L429:
	li	$5,55			# 0x37
	jal	S_StartSound
	move	$4,$16

	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,7
	and	$2,$2,$3
	bltz	$2,$L430
	nop

$L425:
	addiu	$2,$2,1
	sll	$7,$2,2
	lw	$4,120($16)
	lw	$31,20($sp)
	addu	$7,$7,$2
	move	$6,$16
	move	$5,$16
	lw	$16,16($sp)
	sll	$7,$7,1
	j	P_DamageMobj
	addiu	$sp,$sp,24

$L431:
	jr	$31
	nop

$L430:
	addiu	$2,$2,-1
	li	$3,-8			# 0xfffffffffffffff8
	or	$2,$2,$3
	b	$L425
	addiu	$2,$2,1

	.set	macro
	.set	reorder
	.end	A_BruisAttack
	.size	A_BruisAttack, .-A_BruisAttack
	.align	2
	.globl	A_SkelMissile
	.set	nomips16
	.set	nomicromips
	.ent	A_SkelMissile
	.type	A_SkelMissile, @function
A_SkelMissile:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L441
	nop

	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	sw	$31,28($sp)
	jal	A_FaceTarget
	sw	$17,24($sp)

	lw	$2,20($16)
	li	$17,1048576			# 0x100000
	lw	$5,120($16)
	addu	$2,$2,$17
	move	$4,$16
	sw	$2,20($16)
	jal	P_SpawnMissile
	li	$6,6			# 0x6

	lw	$4,12($2)
	lw	$5,20($16)
	lw	$3,16($2)
	lw	$8,72($2)
	lw	$7,76($2)
	lw	$6,120($16)
	lw	$31,28($sp)
	subu	$5,$5,$17
	addu	$4,$4,$8
	addu	$3,$3,$7
	sw	$5,20($16)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$4,12($2)
	sw	$3,16($2)
	sw	$6,152($2)
	jr	$31
	addiu	$sp,$sp,32

$L441:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_SkelMissile
	.size	A_SkelMissile, .-A_SkelMissile
	.align	2
	.globl	A_Tracer
	.set	nomips16
	.set	nomicromips
	.ent	A_Tracer
	.type	A_Tracer, @function
A_Tracer:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gametic)
	lw	$2,%lo(gametic)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L460
	nop

	jr	$31
	nop

$L460:
	addiu	$sp,$sp,-32
	lw	$6,20($4)
	lw	$5,16($4)
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,12($4)
	sw	$31,28($sp)
	sw	$18,24($sp)
	jal	P_SpawnPuff
	sw	$17,20($sp)

	lw	$3,76($16)
	lw	$5,16($16)
	lw	$4,12($16)
	lw	$2,72($16)
	lw	$6,20($16)
	subu	$5,$5,$3
	subu	$4,$4,$2
	jal	P_SpawnMobj
	li	$7,7			# 0x7

	move	$17,$2
	li	$2,65536			# 0x10000
	jal	P_Random
	sw	$2,80($17)

	lw	$3,96($17)
	andi	$2,$2,0x3
	subu	$3,$3,$2
	slt	$4,$0,$3
	li	$2,1			# 0x1
	movz	$3,$2,$4
	sw	$3,96($17)
	lw	$18,152($16)
	beq	$18,$0,$L462
	lw	$31,28($sp)

	lw	$2,108($18)
	blez	$2,$L462
	nop

	lw	$7,16($18)
	lw	$6,12($18)
	lw	$5,16($16)
	jal	R_PointToAngle2
	lw	$4,12($16)

	lw	$3,32($16)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L447
	.set	at
	li	$5,-2147483648			# 0xffffffff80000000

	subu	$4,$2,$3
	addiu	$5,$5,1
	lui	$6,%hi(TRACEANGLE)
	sltu	$4,$4,$5
	bne	$4,$0,$L448
	lw	$6,%lo(TRACEANGLE)($6)

	subu	$4,$6,$3
	addu	$4,$4,$2
	bltz	$4,$L461
	nop

$L451:
	sw	$2,32($16)
$L447:
	lui	$3,%hi(finecosine)
	lw	$3,%lo(finecosine)($3)
	srl	$2,$2,19
	lw	$4,92($16)
	sll	$17,$2,2
	addu	$2,$3,$17
	lw	$5,0($2)
	jal	FixedMul
	lw	$4,60($4)

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	lw	$4,92($16)
	addu	$17,$17,$3
	lw	$4,60($4)
	lw	$5,0($17)
	jal	FixedMul
	sw	$2,72($16)

	lw	$6,16($18)
	lw	$4,12($18)
	lw	$3,12($16)
	lw	$5,16($16)
	subu	$4,$4,$3
	subu	$5,$6,$5
	jal	P_AproxDistance
	sw	$2,76($16)

	lw	$4,92($16)
	lw	$3,20($18)
	lw	$4,60($4)
	lw	$5,20($16)
	div	$0,$2,$4
	li	$2,2621440			# 0x280000
	addu	$2,$3,$2
	li	$3,1			# 0x1
	subu	$2,$2,$5
	lw	$5,80($16)
	mflo	$4
	slt	$6,$0,$4
	movn	$3,$4,$6
	div	$0,$2,$3
	mflo	$2
	slt	$2,$2,$5
	beq	$2,$0,$L452
	lw	$31,28($sp)

	addiu	$5,$5,-8192
	sw	$5,80($16)
	lw	$31,28($sp)
$L462:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L452:
	addiu	$5,$5,8192
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$5,80($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L448:
	addu	$3,$3,$6
	subu	$4,$2,$3
	sltu	$4,$4,$5
	beq	$4,$0,$L451
	nop

	sw	$3,32($16)
	b	$L447
	move	$2,$3

$L461:
	subu	$2,$3,$6
	b	$L447
	sw	$2,32($16)

	.set	macro
	.set	reorder
	.end	A_Tracer
	.size	A_Tracer, .-A_Tracer
	.align	2
	.globl	A_SkelWhoosh
	.set	nomips16
	.set	nomicromips
	.ent	A_SkelWhoosh
	.type	A_SkelWhoosh, @function
A_SkelWhoosh:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L468
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$5,56			# 0x38
	j	S_StartSound
	addiu	$sp,$sp,24

$L468:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_SkelWhoosh
	.size	A_SkelWhoosh, .-A_SkelWhoosh
	.align	2
	.globl	A_SkelFist
	.set	nomips16
	.set	nomicromips
	.ent	A_SkelFist
	.type	A_SkelFist, @function
A_SkelFist:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L481
	nop

	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	sw	$31,28($sp)
	jal	A_FaceTarget
	sw	$17,24($sp)

	jal	P_CheckMeleeRange
	move	$4,$16

	bne	$2,$0,$L480
	nop

	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L480:
	jal	P_Random
	nop

	move	$4,$16
	li	$5,53			# 0x35
	jal	S_StartSound
	move	$17,$2

	li	$2,1717960704			# 0x66660000
	addiu	$2,$2,26215
	mult	$17,$2
	sra	$3,$17,31
	mfhi	$2
	lw	$4,120($16)
	sra	$2,$2,2
	subu	$2,$2,$3
	sll	$3,$2,2
	addu	$2,$3,$2
	sll	$2,$2,1
	subu	$17,$17,$2
	addiu	$17,$17,1
	sll	$7,$17,1
	lw	$31,28($sp)
	addu	$7,$7,$17
	move	$6,$16
	lw	$17,24($sp)
	move	$5,$16
	lw	$16,20($sp)
	sll	$7,$7,1
	j	P_DamageMobj
	addiu	$sp,$sp,32

$L481:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_SkelFist
	.size	A_SkelFist, .-A_SkelFist
	.align	2
	.globl	A_VileChase
	.set	nomips16
	.set	nomicromips
	.ent	A_VileChase
	.type	A_VileChase, @function
A_VileChase:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,112($4)
	addiu	$sp,$sp,-56
	li	$3,8			# 0x8
	sw	$20,36($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L483
	.set	at
	move	$20,$4

	lw	$3,92($4)
	lui	$4,%hi(xspeed)
	sll	$2,$2,2
	addiu	$4,$4,%lo(xspeed)
	addu	$4,$2,$4
	lw	$3,60($3)
	lw	$4,0($4)
	lui	$5,%hi(yspeed)
	multu	$3,$4
	mflo	$7
	addiu	$5,$5,%lo(yspeed)
	lw	$6,12($20)
	addu	$2,$2,$5
	lw	$5,0($2)
	addu	$4,$7,$6
	lui	$6,%hi(bmaporgx)
	lw	$21,%lo(bmaporgx)($6)
	multu	$3,$5
	mflo	$6
	lw	$2,16($20)
	lui	$3,%hi(bmaporgy)
	lw	$17,%lo(bmaporgy)($3)
	addu	$2,$6,$2
	li	$3,4194304			# 0x400000
	subu	$21,$4,$21
	li	$18,-4194304			# 0xffffffffffc00000
	subu	$17,$2,$17
	addu	$18,$21,$18
	lui	$5,%hi(viletryx)
	addu	$21,$21,$3
	subu	$22,$17,$3
	sra	$18,$18,23
	addu	$17,$17,$3
	sra	$21,$21,23
	sw	$4,%lo(viletryx)($5)
	lui	$4,%hi(viletryy)
	sra	$22,$22,23
	sra	$17,$17,23
	sw	$2,%lo(viletryy)($4)
	slt	$3,$21,$18
	lui	$2,%hi(vileobj)
	sw	$20,%lo(vileobj)($2)
	bne	$3,$0,$L483
	slt	$23,$17,$22

	lui	$19,%hi(PIT_VileCheck)
	addiu	$19,$19,%lo(PIT_VileCheck)
$L484:
	beq	$23,$0,$L487
	move	$16,$22

	b	$L495
	addiu	$18,$18,1

$L485:
	bne	$3,$0,$L488
	nop

$L487:
	move	$5,$16
	move	$6,$19
	move	$4,$18
	jal	P_BlockThingsIterator
	addiu	$16,$16,1

	bne	$2,$0,$L485
	slt	$3,$17,$16

	lui	$16,%hi(corpsehit)
	lw	$2,%lo(corpsehit)($16)
	lw	$17,120($20)
	move	$4,$20
	jal	A_FaceTarget
	sw	$2,120($20)

	move	$4,$20
	sw	$17,120($20)
	jal	P_SetMobjState
	li	$5,266			# 0x10a

	lw	$4,%lo(corpsehit)($16)
	jal	S_StartSound
	li	$5,31			# 0x1f

	lw	$4,%lo(corpsehit)($16)
	lw	$17,92($4)
	jal	P_SetMobjState
	lw	$5,88($17)

	lw	$2,%lo(corpsehit)($16)
	lw	$31,52($sp)
	lw	$3,68($2)
	lw	$23,48($sp)
	sll	$3,$3,2
	sw	$3,68($2)
	lw	$4,8($17)
	lw	$3,84($17)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$4,108($2)
	sw	$3,104($2)
	sw	$0,120($2)
	jr	$31
	addiu	$sp,$sp,56

$L488:
	addiu	$18,$18,1
$L495:
	slt	$2,$21,$18
	beq	$2,$0,$L484
	nop

$L483:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$20
	lw	$20,36($sp)
	j	A_Chase
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	A_VileChase
	.size	A_VileChase, .-A_VileChase
	.align	2
	.globl	A_VileStart
	.set	nomips16
	.set	nomicromips
	.ent	A_VileStart
	.type	A_VileStart, @function
A_VileStart:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	S_StartSound
	li	$5,54			# 0x36

	.set	macro
	.set	reorder
	.end	A_VileStart
	.size	A_VileStart, .-A_VileStart
	.align	2
	.globl	A_Fire
	.set	nomips16
	.set	nomicromips
	.ent	A_Fire
	.type	A_Fire, @function
A_Fire:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	lw	$17,152($4)
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	beq	$17,$0,$L497
	sw	$16,20($sp)

	move	$16,$4
	jal	P_SubstNullMobj
	lw	$4,120($4)

	move	$4,$2
	jal	P_CheckSight
	move	$5,$17

	bne	$2,$0,$L505
	nop

$L497:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L505:
	lw	$18,32($17)
	jal	P_UnsetThingPosition
	move	$4,$16

	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	srl	$18,$18,19
	sll	$18,$18,2
	addu	$2,$2,$18
	lw	$5,0($2)
	li	$4,1572864			# 0x180000
	jal	FixedMul
	lw	$19,12($17)

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$18,$18,$3
	addu	$19,$19,$2
	lw	$5,0($18)
	li	$4,1572864			# 0x180000
	lw	$18,16($17)
	jal	FixedMul
	sw	$19,12($16)

	lw	$3,20($17)
	addu	$18,$18,$2
	sw	$18,16($16)
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$3,20($16)
	move	$4,$16
	lw	$16,20($sp)
	j	P_SetThingPosition
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	A_Fire
	.size	A_Fire, .-A_Fire
	.align	2
	.globl	A_StartFire
	.set	nomips16
	.set	nomicromips
	.ent	A_StartFire
	.type	A_StartFire, @function
A_StartFire:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$5,92			# 0x5c
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	S_StartSound
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_Fire
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_StartFire
	.size	A_StartFire, .-A_StartFire
	.align	2
	.globl	A_FireCrackle
	.set	nomips16
	.set	nomicromips
	.ent	A_FireCrackle
	.type	A_FireCrackle, @function
A_FireCrackle:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$5,91			# 0x5b
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	S_StartSound
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_Fire
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_FireCrackle
	.size	A_FireCrackle, .-A_FireCrackle
	.align	2
	.globl	A_VileTarget
	.set	nomips16
	.set	nomicromips
	.ent	A_VileTarget
	.type	A_VileTarget, @function
A_VileTarget:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L515
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	lw	$2,120($16)
	li	$7,4			# 0x4
	lw	$5,12($2)
	lw	$6,20($2)
	jal	P_SpawnMobj
	move	$4,$5

	sw	$2,152($16)
	sw	$16,120($2)
	move	$4,$2
	lw	$2,120($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	sw	$2,152($4)
	j	A_Fire
	addiu	$sp,$sp,24

$L515:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_VileTarget
	.size	A_VileTarget, .-A_VileTarget
	.align	2
	.globl	A_VileAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_VileAttack
	.type	A_VileAttack, @function
A_VileAttack:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L531
	nop

	addiu	$sp,$sp,-40
	sw	$16,20($sp)
	move	$16,$4
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	jal	A_FaceTarget
	sw	$17,24($sp)

	lw	$5,120($16)
	jal	P_CheckSight
	move	$4,$16

	bne	$2,$0,$L530
	nop

$L516:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L530:
	move	$4,$16
	jal	S_StartSound
	li	$5,82			# 0x52

	lw	$4,120($16)
	li	$7,20			# 0x14
	move	$6,$16
	jal	P_DamageMobj
	move	$5,$16

	lw	$3,120($16)
	li	$2,65536000			# 0x3e80000
	lw	$4,92($3)
	lw	$18,152($16)
	lw	$4,72($4)
	lw	$17,32($16)
	div	$0,$2,$4
	mflo	$2
	beq	$18,$0,$L516
	sw	$2,80($3)

	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	srl	$17,$17,19
	sll	$17,$17,2
	addu	$2,$2,$17
	lw	$5,0($2)
	li	$4,1572864			# 0x180000
	jal	FixedMul
	lw	$19,12($3)

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	lw	$4,120($16)
	addu	$17,$17,$3
	lw	$5,0($17)
	subu	$19,$19,$2
	lw	$17,16($4)
	sw	$19,12($18)
	jal	FixedMul
	li	$4,1572864			# 0x180000

	subu	$17,$17,$2
	sw	$17,16($18)
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	move	$5,$16
	move	$4,$18
	lw	$16,20($sp)
	lw	$18,28($sp)
	li	$6,70			# 0x46
	j	P_RadiusAttack
	addiu	$sp,$sp,40

$L531:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_VileAttack
	.size	A_VileAttack, .-A_VileAttack
	.align	2
	.globl	A_FatRaise
	.set	nomips16
	.set	nomicromips
	.ent	A_FatRaise
	.type	A_FatRaise, @function
A_FatRaise:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$5,99			# 0x63
	j	S_StartSound
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_FatRaise
	.size	A_FatRaise, .-A_FatRaise
	.align	2
	.globl	A_FatAttack1
	.set	nomips16
	.set	nomicromips
	.ent	A_FatAttack1
	.type	A_FatAttack1, @function
A_FatAttack1:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,28($sp)
	sw	$18,24($sp)
	jal	A_FaceTarget
	sw	$17,20($sp)

	lw	$2,32($16)
	li	$18,134217728			# 0x8000000
	lw	$4,120($16)
	addu	$2,$2,$18
	jal	P_SubstNullMobj
	sw	$2,32($16)

	move	$17,$2
	move	$4,$16
	move	$5,$2
	jal	P_SpawnMissile
	li	$6,9			# 0x9

	move	$5,$17
	move	$4,$16
	jal	P_SpawnMissile
	li	$6,9			# 0x9

	move	$16,$2
	lw	$2,32($2)
	lui	$3,%hi(finecosine)
	addu	$2,$2,$18
	lw	$3,%lo(finecosine)($3)
	srl	$17,$2,19
	lw	$4,92($16)
	sll	$17,$17,2
	sw	$2,32($16)
	addu	$2,$3,$17
	lw	$5,0($2)
	jal	FixedMul
	lw	$4,60($4)

	lui	$3,%hi(finesine)
	lw	$4,92($16)
	addiu	$3,$3,%lo(finesine)
	addu	$17,$17,$3
	lw	$5,0($17)
	lw	$4,60($4)
	jal	FixedMul
	sw	$2,72($16)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$2,76($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_FatAttack1
	.size	A_FatAttack1, .-A_FatAttack1
	.align	2
	.globl	A_FatAttack2
	.set	nomips16
	.set	nomicromips
	.ent	A_FatAttack2
	.type	A_FatAttack2, @function
A_FatAttack2:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	sw	$31,28($sp)
	jal	A_FaceTarget
	sw	$17,24($sp)

	lw	$2,32($16)
	li	$3,-134217728			# 0xfffffffff8000000
	addu	$2,$2,$3
	lw	$4,120($16)
	jal	P_SubstNullMobj
	sw	$2,32($16)

	move	$17,$2
	move	$4,$16
	move	$5,$2
	jal	P_SpawnMissile
	li	$6,9			# 0x9

	move	$5,$17
	move	$4,$16
	jal	P_SpawnMissile
	li	$6,9			# 0x9

	move	$16,$2
	lw	$2,32($2)
	li	$3,-268435456			# 0xfffffffff0000000
	addu	$2,$2,$3
	lui	$3,%hi(finecosine)
	lw	$3,%lo(finecosine)($3)
	srl	$17,$2,19
	lw	$4,92($16)
	sll	$17,$17,2
	sw	$2,32($16)
	addu	$2,$3,$17
	lw	$5,0($2)
	jal	FixedMul
	lw	$4,60($4)

	lui	$3,%hi(finesine)
	lw	$4,92($16)
	addiu	$3,$3,%lo(finesine)
	addu	$17,$17,$3
	lw	$5,0($17)
	lw	$4,60($4)
	jal	FixedMul
	sw	$2,72($16)

	lw	$31,28($sp)
	lw	$17,24($sp)
	sw	$2,76($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_FatAttack2
	.size	A_FatAttack2, .-A_FatAttack2
	.align	2
	.globl	A_FatAttack3
	.set	nomips16
	.set	nomicromips
	.ent	A_FatAttack3
	.type	A_FatAttack3, @function
A_FatAttack3:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,28($sp)
	move	$18,$4
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$17,24($sp)
	jal	A_FaceTarget
	sw	$16,20($sp)

	lw	$4,120($18)
	jal	P_SubstNullMobj
	lui	$21,%hi(finecosine)

	move	$5,$2
	li	$6,9			# 0x9
	move	$4,$18
	jal	P_SpawnMissile
	move	$20,$2

	move	$16,$2
	lw	$2,32($2)
	li	$3,-67108864			# 0xfffffffffc000000
	addu	$2,$2,$3
	srl	$17,$2,19
	lw	$3,%lo(finecosine)($21)
	lw	$4,92($16)
	sll	$17,$17,2
	sw	$2,32($16)
	addu	$2,$3,$17
	lw	$5,0($2)
	lw	$4,60($4)
	jal	FixedMul
	lui	$19,%hi(finesine)

	addiu	$19,$19,%lo(finesine)
	lw	$3,92($16)
	addu	$17,$17,$19
	lw	$4,60($3)
	lw	$5,0($17)
	jal	FixedMul
	sw	$2,72($16)

	sw	$2,76($16)
	move	$5,$20
	move	$4,$18
	jal	P_SpawnMissile
	li	$6,9			# 0x9

	move	$16,$2
	lw	$2,32($2)
	li	$3,67108864			# 0x4000000
	addu	$2,$2,$3
	srl	$17,$2,19
	lw	$3,%lo(finecosine)($21)
	lw	$4,92($16)
	sll	$17,$17,2
	sw	$2,32($16)
	addu	$2,$3,$17
	lw	$5,0($2)
	lw	$4,60($4)
	jal	FixedMul
	addu	$17,$17,$19

	lw	$3,92($16)
	lw	$5,0($17)
	lw	$4,60($3)
	jal	FixedMul
	sw	$2,72($16)

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,76($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	A_FatAttack3
	.size	A_FatAttack3, .-A_FatAttack3
	.align	2
	.globl	A_SkullAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_SkullAttack
	.type	A_SkullAttack, @function
A_SkullAttack:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	lw	$18,120($4)
	sw	$31,28($sp)
	sw	$17,20($sp)
	beq	$18,$0,$L540
	sw	$16,16($sp)

	lw	$3,92($4)
	lw	$2,104($4)
	lw	$5,24($3)
	li	$3,16777216			# 0x1000000
	or	$2,$2,$3
	move	$16,$4
	jal	S_StartSound
	sw	$2,104($4)

	jal	A_FaceTarget
	move	$4,$16

	lw	$17,32($16)
	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	srl	$17,$17,19
	sll	$17,$17,2
	addu	$2,$2,$17
	lw	$5,0($2)
	jal	FixedMul
	li	$4,1310720			# 0x140000

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$17,$17,$3
	lw	$5,0($17)
	li	$4,1310720			# 0x140000
	jal	FixedMul
	sw	$2,72($16)

	lw	$6,16($18)
	lw	$4,12($18)
	lw	$3,12($16)
	lw	$5,16($16)
	subu	$4,$4,$3
	sw	$2,76($16)
	jal	P_AproxDistance
	subu	$5,$6,$5

	li	$3,1310720			# 0x140000
	slt	$3,$2,$3
	bne	$3,$0,$L542
	li	$3,1			# 0x1

	li	$3,1717960704			# 0x66660000
	addiu	$3,$3,26215
	mult	$2,$3
	sra	$2,$2,31
	mfhi	$3
	sra	$3,$3,19
	subu	$3,$3,$2
$L542:
	lw	$2,68($18)
	lw	$5,20($18)
	lw	$4,20($16)
	sra	$2,$2,1
	addu	$2,$2,$5
	subu	$2,$2,$4
	div	$0,$2,$3
	mflo	$2
	sw	$2,80($16)
$L540:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_SkullAttack
	.size	A_SkullAttack, .-A_SkullAttack
	.align	2
	.globl	A_PainShootSkull
	.set	nomips16
	.set	nomicromips
	.ent	A_PainShootSkull
	.type	A_PainShootSkull, @function
A_PainShootSkull:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$7,%hi(thinkercap)
	addiu	$7,$7,%lo(thinkercap)
	lw	$2,4($7)
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$16,20($sp)
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L549
	.set	at
	move	$17,$4

	lui	$8,%hi(P_MobjThinker)
	move	$4,$0
	addiu	$8,$8,%lo(P_MobjThinker)
	b	$L551
	li	$6,18			# 0x12

$L550:
	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L556
	.set	at
	nop

$L551:
	lw	$3,8($2)
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L550
	.set	at
	nop

	lw	$3,88($2)
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L550
	.set	at
	nop

	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L551
	.set	at
	addiu	$4,$4,1

$L556:
	slt	$4,$4,21
	bne	$4,$0,$L549
	lw	$31,36($sp)

	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L549:
	lw	$2,92($17)
	srl	$5,$5,19
	lw	$3,64($2)
	lui	$2,%hi(mobjinfo+1720)
	lw	$2,%lo(mobjinfo+1720)($2)
	sll	$16,$5,2
	addu	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$3,%hi(finecosine)
	lw	$3,%lo(finecosine)($3)
	srl	$18,$2,31
	addu	$18,$18,$2
	sra	$18,$18,1
	addu	$2,$3,$16
	li	$3,262144			# 0x40000
	addu	$18,$18,$3
	lw	$5,0($2)
	move	$4,$18
	jal	FixedMul
	lw	$19,12($17)

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$16,$16,$3
	lw	$5,0($16)
	move	$4,$18
	addu	$19,$19,$2
	jal	FixedMul
	lw	$18,16($17)

	lw	$6,20($17)
	li	$3,524288			# 0x80000
	move	$4,$19
	addu	$6,$6,$3
	addu	$5,$18,$2
	jal	P_SpawnMobj
	li	$7,18			# 0x12

	lw	$6,16($2)
	lw	$5,12($2)
	move	$4,$2
	jal	P_TryMove
	move	$16,$2

	beq	$2,$0,$L557
	lw	$31,36($sp)

	lw	$2,120($17)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,120($16)
	move	$4,$16
	lw	$16,20($sp)
	j	A_SkullAttack
	addiu	$sp,$sp,40

$L557:
	lw	$19,32($sp)
	lw	$18,28($sp)
	move	$6,$17
	move	$5,$17
	move	$4,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$7,10000			# 0x2710
	j	P_DamageMobj
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	A_PainShootSkull
	.size	A_PainShootSkull, .-A_PainShootSkull
	.align	2
	.globl	A_PainAttack
	.set	nomips16
	.set	nomicromips
	.ent	A_PainAttack
	.type	A_PainAttack, @function
A_PainAttack:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,120($4)
	beq	$2,$0,$L563
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	A_FaceTarget
	move	$16,$4

	lw	$5,32($16)
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_PainShootSkull
	addiu	$sp,$sp,24

$L563:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	A_PainAttack
	.size	A_PainAttack, .-A_PainAttack
	.align	2
	.globl	A_PainDie
	.set	nomips16
	.set	nomicromips
	.ent	A_PainDie
	.type	A_PainDie, @function
A_PainDie:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	addiu	$sp,$sp,-32
	lw	$5,32($4)
	li	$3,-3			# 0xfffffffffffffffd
	and	$2,$2,$3
	sw	$17,24($sp)
	li	$17,1073741824			# 0x40000000
	sw	$31,28($sp)
	sw	$16,20($sp)
	addu	$5,$5,$17
	move	$16,$4
	jal	A_PainShootSkull
	sw	$2,104($4)

	lw	$5,32($16)
	li	$2,-2147483648			# 0xffffffff80000000
	move	$4,$16
	jal	A_PainShootSkull
	addu	$5,$5,$2

	lw	$5,32($16)
	lw	$31,28($sp)
	move	$4,$16
	subu	$5,$5,$17
	lw	$16,20($sp)
	lw	$17,24($sp)
	j	A_PainShootSkull
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_PainDie
	.size	A_PainDie, .-A_PainDie
	.align	2
	.globl	A_Scream
	.set	nomips16
	.set	nomicromips
	.ent	A_Scream
	.type	A_Scream, @function
A_Scream:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,92($4)
	addiu	$sp,$sp,-24
	lw	$5,56($2)
	sw	$16,16($sp)
	slt	$2,$5,62
	sw	$31,20($sp)
	beq	$2,$0,$L567
	move	$16,$4

	slt	$2,$5,59
	beq	$2,$0,$L568
	nop

	bne	$5,$0,$L570
	lw	$31,20($sp)

	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L567:
	addiu	$2,$5,-62
	sltu	$2,$2,2
	beq	$2,$0,$L570
	nop

	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,1
	and	$5,$2,$3
	bltz	$5,$L577
	li	$2,-2			# 0xfffffffffffffffe

	addiu	$5,$5,62
$L570:
	lw	$2,88($16)
	li	$3,19			# 0x13
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L573
	.set	at
	li	$3,21			# 0x15

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L574
	.set	at
	lw	$31,20($sp)

$L573:
	lw	$31,20($sp)
	lw	$16,16($sp)
	move	$4,$0
	j	S_StartSound
	addiu	$sp,$sp,24

$L574:
	move	$4,$16
	lw	$16,16($sp)
	j	S_StartSound
	addiu	$sp,$sp,24

$L568:
	jal	P_Random
	nop

	li	$3,1431633920			# 0x55550000
	addiu	$3,$3,21846
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	subu	$3,$3,$4
	sll	$4,$3,1
	addu	$3,$4,$3
	subu	$5,$2,$3
	b	$L570
	addiu	$5,$5,59

$L577:
	addiu	$5,$5,-1
	or	$5,$5,$2
	addiu	$5,$5,1
	b	$L570
	addiu	$5,$5,62

	.set	macro
	.set	reorder
	.end	A_Scream
	.size	A_Scream, .-A_Scream
	.align	2
	.globl	A_XScream
	.set	nomips16
	.set	nomicromips
	.ent	A_XScream
	.type	A_XScream, @function
A_XScream:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	S_StartSound
	li	$5,31			# 0x1f

	.set	macro
	.set	reorder
	.end	A_XScream
	.size	A_XScream, .-A_XScream
	.align	2
	.globl	A_Pain
	.set	nomips16
	.set	nomicromips
	.ent	A_Pain
	.type	A_Pain, @function
A_Pain:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,92($4)
	lw	$5,36($2)
	bne	$5,$0,$L581
	nop

	jr	$31
	nop

$L581:
	j	S_StartSound
	nop

	.set	macro
	.set	reorder
	.end	A_Pain
	.size	A_Pain, .-A_Pain
	.align	2
	.globl	A_Fall
	.set	nomips16
	.set	nomicromips
	.ent	A_Fall
	.type	A_Fall, @function
A_Fall:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	li	$3,-3			# 0xfffffffffffffffd
	and	$2,$2,$3
	jr	$31
	sw	$2,104($4)

	.set	macro
	.set	reorder
	.end	A_Fall
	.size	A_Fall, .-A_Fall
	.align	2
	.globl	A_Explode
	.set	nomips16
	.set	nomicromips
	.ent	A_Explode
	.type	A_Explode, @function
A_Explode:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$5,120($4)
	j	P_RadiusAttack
	li	$6,128			# 0x80

	.set	macro
	.set	reorder
	.end	A_Explode
	.size	A_Explode, .-A_Explode
	.align	2
	.globl	A_BossDeath
	.set	nomips16
	.set	nomicromips
	.ent	A_BossDeath
	.type	A_BossDeath, @function
A_BossDeath:
	.frame	$sp,88,$31		# vars= 64, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$9,%lo(gamemode)($2)
	li	$3,2			# 0x2
	lui	$2,%hi(gamemap)
	.set	noat
	xor	$1,$9,$3
	beq	$1,$0,$L626
	.set	at
	lw	$10,%lo(gamemap)($2)

	lui	$2,%hi(gameversion)
	lw	$2,%lo(gameversion)($2)
	sltu	$2,$2,6
	bne	$2,$0,$L627
	lw	$7,88($4)

	lui	$2,%hi(gameepisode)
	lw	$2,%lo(gameepisode)($2)
	li	$5,3			# 0x3
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L595
	.set	at
	slt	$5,$2,4

	beq	$5,$0,$L590
	li	$5,1			# 0x1

	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L591
	.set	at
	nop

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L593
	.set	at
	li	$2,8			# 0x8

	.set	noat
	xor	$1,$10,$2
	beq	$1,$0,$L619
	.set	at
	nop

	jr	$31
	nop

$L627:
	li	$2,8			# 0x8
	.set	noat
	xor	$1,$10,$2
	bne	$1,$0,$L634
	.set	at
	nop

	li	$2,15			# 0xf
	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L631
	.set	at
	lui	$2,%hi(playeringame)

	lui	$2,%hi(gameepisode)
	lw	$3,%lo(gameepisode)($2)
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L587
	.set	at
	nop

	jr	$31
	nop

$L626:
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$10,$2
	bne	$1,$0,$L634
	.set	at
	nop

	lw	$7,88($4)
	li	$2,8			# 0x8
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L587
	.set	at
	li	$2,20			# 0x14

	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L634
	.set	at
	nop

$L587:
	lui	$2,%hi(playeringame)
$L631:
	lui	$5,%hi(players)
	addiu	$2,$2,%lo(playeringame)
	addiu	$5,$5,%lo(players)
	move	$3,$0
	li	$8,4			# 0x4
$L598:
	lw	$6,0($2)
	beq	$6,$0,$L596
	addiu	$3,$3,1

	lw	$6,40($5)
	bgtz	$6,$L597
	nop

$L596:
	addiu	$2,$2,4
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L598
	.set	at
	addiu	$5,$5,288

	jr	$31
	nop

$L590:
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L593
	.set	at
	li	$2,6			# 0x6

	.set	noat
	xor	$1,$10,$2
	beq	$1,$0,$L632
	.set	at
	li	$2,21			# 0x15

$L595:
	li	$2,8			# 0x8
	.set	noat
	xor	$1,$10,$2
	bne	$1,$0,$L634
	.set	at
	nop

	li	$2,19			# 0x13
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L587
	.set	at
	nop

	jr	$31
	nop

$L591:
	li	$2,8			# 0x8
	.set	noat
	xor	$1,$10,$2
	bne	$1,$0,$L634
	.set	at
	nop

	li	$2,15			# 0xf
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L587
	.set	at
	nop

	jr	$31
	nop

$L597:
	lui	$5,%hi(thinkercap)
	addiu	$5,$5,%lo(thinkercap)
	lw	$2,4($5)
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L599
	.set	at
	nop

	lui	$6,%hi(P_MobjThinker)
	b	$L601
	addiu	$6,$6,%lo(P_MobjThinker)

$L600:
	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L599
	.set	at
	nop

$L601:
	lw	$3,8($2)
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L600
	.set	at
	nop

	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L600
	.set	at
	nop

	lw	$3,88($2)
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L600
	.set	at
	nop

	lw	$3,108($2)
	bgtz	$3,$L634
	nop

	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L601
	.set	at
	nop

$L599:
	addiu	$sp,$sp,-88
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$9,$2
	beq	$1,$0,$L628
	.set	at
	sw	$31,84($sp)

	lui	$2,%hi(gameepisode)
	lw	$2,%lo(gameepisode)($2)
	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L605
	.set	at
	li	$3,4			# 0x4

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L603
	.set	at
	li	$2,6			# 0x6

	.set	noat
	xor	$1,$10,$2
	beq	$1,$0,$L607
	.set	at
	li	$2,8			# 0x8

	.set	noat
	xor	$1,$10,$2
	bne	$1,$0,$L633
	.set	at
	lw	$31,84($sp)

$L605:
	li	$2,666			# 0x29a
	li	$5,1			# 0x1
	addiu	$4,$sp,16
	jal	EV_DoFloor
	sh	$2,36($sp)

	lw	$31,84($sp)
$L630:
	jr	$31
	addiu	$sp,$sp,88

$L628:
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$10,$2
	beq	$1,$0,$L629
	.set	at
	li	$2,8			# 0x8

$L603:
	lw	$31,84($sp)
$L633:
	j	G_ExitLevel
	addiu	$sp,$sp,88

$L593:
	li	$2,8			# 0x8
	.set	noat
	xor	$1,$10,$2
	beq	$1,$0,$L587
	.set	at
	nop

	jr	$31
	nop

$L629:
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L605
	.set	at
	li	$2,20			# 0x14

	.set	noat
	xor	$1,$7,$2
	bne	$1,$0,$L603
	.set	at
	li	$5,5			# 0x5

	addiu	$4,$sp,16
	li	$2,667			# 0x29b
	jal	EV_DoFloor
	sh	$2,36($sp)

	b	$L630
	lw	$31,84($sp)

$L619:
	li	$2,21			# 0x15
$L632:
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L587
	.set	at
	nop

$L634:
	jr	$31
	nop

$L607:
	li	$5,6			# 0x6
	addiu	$4,$sp,16
	li	$2,666			# 0x29a
	jal	EV_DoDoor
	sh	$2,36($sp)

	b	$L630
	lw	$31,84($sp)

	.set	macro
	.set	reorder
	.end	A_BossDeath
	.size	A_BossDeath, .-A_BossDeath
	.align	2
	.globl	A_Hoof
	.set	nomips16
	.set	nomicromips
	.ent	A_Hoof
	.type	A_Hoof, @function
A_Hoof:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$5,84			# 0x54
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	S_StartSound
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_Chase
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_Hoof
	.size	A_Hoof, .-A_Hoof
	.align	2
	.globl	A_Metal
	.set	nomips16
	.set	nomicromips
	.ent	A_Metal
	.type	A_Metal, @function
A_Metal:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$5,85			# 0x55
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	S_StartSound
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_Chase
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_Metal
	.size	A_Metal, .-A_Metal
	.align	2
	.globl	A_BabyMetal
	.set	nomips16
	.set	nomicromips
	.ent	A_BabyMetal
	.type	A_BabyMetal, @function
A_BabyMetal:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$5,79			# 0x4f
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	S_StartSound
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_Chase
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_BabyMetal
	.size	A_BabyMetal, .-A_BabyMetal
	.align	2
	.globl	A_OpenShotgun2
	.set	nomips16
	.set	nomicromips
	.ent	A_OpenShotgun2
	.type	A_OpenShotgun2, @function
A_OpenShotgun2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$4,0($4)
	j	S_StartSound
	li	$5,5			# 0x5

	.set	macro
	.set	reorder
	.end	A_OpenShotgun2
	.size	A_OpenShotgun2, .-A_OpenShotgun2
	.align	2
	.globl	A_LoadShotgun2
	.set	nomips16
	.set	nomicromips
	.ent	A_LoadShotgun2
	.type	A_LoadShotgun2, @function
A_LoadShotgun2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$4,0($4)
	j	S_StartSound
	li	$5,7			# 0x7

	.set	macro
	.set	reorder
	.end	A_LoadShotgun2
	.size	A_LoadShotgun2, .-A_LoadShotgun2
	.align	2
	.globl	A_CloseShotgun2
	.set	nomips16
	.set	nomicromips
	.ent	A_CloseShotgun2
	.type	A_CloseShotgun2, @function
A_CloseShotgun2:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	lw	$4,0($4)
	sw	$17,24($sp)
	move	$17,$5
	sw	$31,28($sp)
	jal	S_StartSound
	li	$5,6			# 0x6

	lw	$31,28($sp)
	move	$5,$17
	move	$4,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	A_ReFire
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_CloseShotgun2
	.size	A_CloseShotgun2, .-A_CloseShotgun2
	.align	2
	.globl	A_BrainAwake
	.set	nomips16
	.set	nomicromips
	.ent	A_BrainAwake
	.type	A_BrainAwake, @function
A_BrainAwake:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(thinkercap)
	addiu	$4,$4,%lo(thinkercap)
	lw	$2,4($4)
	lui	$10,%hi(numbraintargets)
	lui	$3,%hi(braintargeton)
	sw	$0,%lo(numbraintargets)($10)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L648
	.set	at
	sw	$0,%lo(braintargeton)($3)

	lui	$5,%hi(P_MobjThinker)
	lui	$8,%hi(braintargets)
	move	$9,$0
	move	$6,$0
	addiu	$5,$5,%lo(P_MobjThinker)
	li	$7,27			# 0x1b
	b	$L647
	addiu	$8,$8,%lo(braintargets)

$L649:
	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L656
	.set	at
	nop

$L647:
	lw	$3,8($2)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L649
	.set	at
	nop

	lw	$3,88($2)
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L649
	.set	at
	sll	$3,$6,2

	addu	$3,$3,$8
	sw	$2,0($3)
	lw	$2,4($2)
	addiu	$6,$6,1
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L647
	.set	at
	li	$9,1			# 0x1

$L656:
	beq	$9,$0,$L657
	li	$5,96			# 0x60

	sw	$6,%lo(numbraintargets)($10)
$L648:
	li	$5,96			# 0x60
$L657:
	j	S_StartSound
	move	$4,$0

	.set	macro
	.set	reorder
	.end	A_BrainAwake
	.size	A_BrainAwake, .-A_BrainAwake
	.align	2
	.globl	A_BrainPain
	.set	nomips16
	.set	nomicromips
	.ent	A_BrainPain
	.type	A_BrainPain, @function
A_BrainPain:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$5,97			# 0x61
	j	S_StartSound
	move	$4,$0

	.set	macro
	.set	reorder
	.end	A_BrainPain
	.size	A_BrainPain, .-A_BrainPain
	.align	2
	.globl	A_BrainScream
	.set	nomips16
	.set	nomicromips
	.ent	A_BrainScream
	.type	A_BrainScream, @function
A_BrainScream:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,20($sp)
	lw	$17,12($4)
	sw	$18,24($sp)
	li	$2,-12845056			# 0xffffffffff3c0000
	li	$18,20905984			# 0x13f0000
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$31,44($sp)
	sw	$16,16($sp)
	move	$22,$4
	addu	$17,$17,$2
	li	$21,-20971520			# 0xfffffffffec00000
	li	$20,1			# 0x1
	li	$19,524288			# 0x80000
	ori	$18,$18,0xffff
$L660:
	jal	P_Random
	lw	$16,16($22)

	addu	$16,$16,$21
	sll	$6,$2,17
	move	$4,$17
	move	$5,$16
	li	$7,33			# 0x21
	jal	P_SpawnMobj
	addiu	$6,$6,128

	jal	P_Random
	move	$16,$2

	sll	$2,$2,9
	li	$5,799			# 0x31f
	move	$4,$16
	jal	P_SetMobjState
	sw	$2,80($16)

	jal	P_Random
	addu	$17,$17,$19

	lw	$3,96($16)
	andi	$2,$2,0x7
	subu	$2,$3,$2
	slt	$3,$0,$2
	movz	$2,$20,$3
	sw	$2,96($16)
	lw	$2,12($22)
	addu	$2,$2,$18
	slt	$2,$2,$17
	beq	$2,$0,$L660
	lw	$31,44($sp)

	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$5,98			# 0x62
	move	$4,$0
	j	S_StartSound
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	A_BrainScream
	.size	A_BrainScream, .-A_BrainScream
	.align	2
	.globl	A_BrainExplode
	.set	nomips16
	.set	nomicromips
	.ent	A_BrainExplode
	.type	A_BrainExplode, @function
A_BrainExplode:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$18,12($4)
	jal	P_Random
	move	$17,$4

	jal	P_Random
	move	$16,$2

	subu	$16,$16,$2
	lw	$17,16($17)
	jal	P_Random
	sll	$16,$16,11

	addu	$16,$16,$18
	sll	$6,$2,17
	move	$5,$17
	move	$4,$16
	li	$7,33			# 0x21
	jal	P_SpawnMobj
	addiu	$6,$6,128

	jal	P_Random
	move	$16,$2

	sll	$2,$2,9
	move	$4,$16
	sw	$2,80($16)
	jal	P_SetMobjState
	li	$5,799			# 0x31f

	jal	P_Random
	nop

	lw	$3,96($16)
	andi	$2,$2,0x7
	subu	$2,$3,$2
	slt	$4,$0,$2
	li	$3,1			# 0x1
	movz	$2,$3,$4
	sw	$2,96($16)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_BrainExplode
	.size	A_BrainExplode, .-A_BrainExplode
	.align	2
	.globl	A_BrainDie
	.set	nomips16
	.set	nomicromips
	.ent	A_BrainDie
	.type	A_BrainDie, @function
A_BrainDie:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	G_ExitLevel
	nop

	.set	macro
	.set	reorder
	.end	A_BrainDie
	.size	A_BrainDie, .-A_BrainDie
	.align	2
	.globl	A_BrainSpit
	.set	nomips16
	.set	nomicromips
	.ent	A_BrainSpit
	.type	A_BrainSpit, @function
A_BrainSpit:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(easy.0)
	lui	$2,%hi(gameskill)
	lw	$5,%lo(easy.0)($3)
	lw	$2,%lo(gameskill)($2)
	addiu	$sp,$sp,-32
	xori	$6,$5,0x1
	slt	$2,$2,2
	sw	$6,%lo(easy.0)($3)
	sw	$16,20($sp)
	sw	$31,28($sp)
	sw	$17,24($sp)
	beq	$2,$0,$L667
	move	$16,$4

	li	$2,1			# 0x1
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L666
	.set	at
	lw	$31,28($sp)

$L667:
	lui	$7,%hi(braintargeton)
	lw	$2,%lo(braintargeton)($7)
	lui	$3,%hi(numbraintargets)
	lw	$4,%lo(numbraintargets)($3)
	addiu	$3,$2,1
	div	$0,$3,$4
	lui	$4,%hi(braintargets)
	addiu	$4,$4,%lo(braintargets)
	sll	$2,$2,2
	addu	$2,$2,$4
	lw	$17,0($2)
	move	$4,$16
	move	$5,$17
	li	$6,28			# 0x1c
	mfhi	$3
	jal	P_SpawnMissile
	sw	$3,%lo(braintargeton)($7)

	lw	$5,16($16)
	lw	$3,16($17)
	lw	$4,76($2)
	subu	$3,$3,$5
	div	$0,$3,$4
	lw	$3,100($2)
	lw	$31,28($sp)
	lw	$3,8($3)
	lw	$16,20($sp)
	sw	$17,120($2)
	lw	$17,24($sp)
	li	$5,94			# 0x5e
	move	$4,$0
	mflo	$6
	div	$0,$6,$3
	mflo	$3
	sw	$3,124($2)
	j	S_StartSound
	addiu	$sp,$sp,32

$L666:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_BrainSpit
	.size	A_BrainSpit, .-A_BrainSpit
	.align	2
	.globl	A_SpawnSound
	.set	nomips16
	.set	nomicromips
	.ent	A_SpawnSound
	.type	A_SpawnSound, @function
A_SpawnSound:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	li	$5,95			# 0x5f
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	S_StartSound
	move	$16,$4

	lw	$2,124($16)
	addiu	$2,$2,-1
	beq	$2,$0,$L673
	sw	$2,124($16)

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L673:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	A_SpawnFly.part.0
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_SpawnSound
	.size	A_SpawnSound, .-A_SpawnSound
	.align	2
	.globl	A_SpawnFly
	.set	nomips16
	.set	nomicromips
	.ent	A_SpawnFly
	.type	A_SpawnFly, @function
A_SpawnFly:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,124($4)
	addiu	$2,$2,-1
	beq	$2,$0,$L676
	sw	$2,124($4)

	jr	$31
	nop

$L676:
	j	A_SpawnFly.part.0
	nop

	.set	macro
	.set	reorder
	.end	A_SpawnFly
	.size	A_SpawnFly, .-A_SpawnFly
	.align	2
	.globl	A_PlayerScream
	.set	nomips16
	.set	nomicromips
	.ent	A_PlayerScream
	.type	A_PlayerScream, @function
A_PlayerScream:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L683
	.set	at
	li	$3,58			# 0x3a

	j	S_StartSound
	li	$5,57			# 0x39

$L683:
	lw	$2,108($4)
	li	$5,57			# 0x39
	slt	$2,$2,-50
	j	S_StartSound
	movn	$5,$3,$2

	.set	macro
	.set	reorder
	.end	A_PlayerScream
	.size	A_PlayerScream, .-A_PlayerScream
	.local	easy.0
	.comm	easy.0,4,4
	.globl	braintargeton
	.section	.bss,"aw",@nobits
	.align	2
	.type	braintargeton, @object
	.size	braintargeton, 4
braintargeton:
	.space	4
	.globl	numbraintargets
	.align	2
	.type	numbraintargets, @object
	.size	numbraintargets, 4
numbraintargets:
	.space	4
	.globl	braintargets
	.align	2
	.type	braintargets, @object
	.size	braintargets, 128
braintargets:
	.space	128
	.globl	viletryy
	.align	2
	.type	viletryy, @object
	.size	viletryy, 4
viletryy:
	.space	4
	.globl	viletryx
	.align	2
	.type	viletryx, @object
	.size	viletryx, 4
viletryx:
	.space	4
	.globl	vileobj
	.align	2
	.type	vileobj, @object
	.size	vileobj, 4
vileobj:
	.space	4
	.globl	corpsehit
	.align	2
	.type	corpsehit, @object
	.size	corpsehit, 4
corpsehit:
	.space	4
	.globl	TRACEANGLE
	.data
	.align	2
	.type	TRACEANGLE, @object
	.size	TRACEANGLE, 4
TRACEANGLE:
	.word	201326592
	.globl	yspeed
	.align	2
	.type	yspeed, @object
	.size	yspeed, 32
yspeed:
	.word	0
	.word	47000
	.word	65536
	.word	47000
	.word	0
	.word	-47000
	.word	-65536
	.word	-47000
	.globl	xspeed
	.align	2
	.type	xspeed, @object
	.size	xspeed, 32
xspeed:
	.word	65536
	.word	47000
	.word	0
	.word	-47000
	.word	-65536
	.word	-47000
	.word	0
	.word	47000
	.globl	soundtarget
	.section	.bss
	.align	2
	.type	soundtarget, @object
	.size	soundtarget, 4
soundtarget:
	.space	4
	.globl	diags
	.data
	.align	2
	.type	diags, @object
	.size	diags, 16
diags:
	.word	3
	.word	1
	.word	5
	.word	7
	.globl	opposite
	.align	2
	.type	opposite, @object
	.size	opposite, 36
opposite:
	.word	4
	.word	5
	.word	6
	.word	7
	.word	0
	.word	1
	.word	2
	.word	3
	.word	8
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
