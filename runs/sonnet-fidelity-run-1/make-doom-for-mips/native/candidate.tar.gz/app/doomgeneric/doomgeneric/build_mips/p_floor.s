	.file	1 "p_floor.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	T_MovePlane
	.set	nomips16
	.set	nomicromips
	.ent	T_MovePlane
	.type	T_MovePlane, @function
T_MovePlane:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$16,20($sp)
	lw	$16,56($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$31,36($sp)
	lw	$17,60($sp)
	move	$19,$4
	beq	$16,$0,$L2
	move	$18,$7

	li	$2,1			# 0x1
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L3
	.set	at
	li	$2,-1			# 0xffffffffffffffff

$L4:
	move	$2,$0
$L1:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L3:
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L17
	.set	at
	nop

	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L1
	.set	at
	move	$2,$0

	lw	$16,4($4)
	addu	$2,$16,$5
	slt	$3,$6,$2
	bne	$3,$0,$L26
	nop

	sw	$2,4($4)
	jal	P_ChangeSector
	move	$5,$7

	b	$L1
	move	$2,$0

$L2:
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L5
	.set	at
	li	$2,1			# 0x1

	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L1
	.set	at
	move	$2,$0

	lw	$16,0($4)
	addu	$2,$16,$5
	slt	$3,$6,$2
	bne	$3,$0,$L27
	nop

	sw	$2,0($4)
	jal	P_ChangeSector
	move	$5,$7

	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L4
	.set	at
	nop

	.set	noat
	xor	$1,$18,$2
	beq	$1,$0,$L12
	.set	at
	nop

	sw	$16,0($19)
$L30:
	move	$5,$18
	jal	P_ChangeSector
	move	$4,$19

$L12:
	b	$L1
	li	$2,1			# 0x1

$L17:
	lw	$17,4($4)
	subu	$2,$17,$5
	slt	$3,$2,$6
	bne	$3,$0,$L28
	nop

	sw	$2,4($4)
	jal	P_ChangeSector
	move	$5,$7

	.set	noat
	xor	$1,$2,$16
	bne	$1,$0,$L4
	.set	at
	nop

	.set	noat
	xor	$1,$18,$2
	beq	$1,$0,$L12
	.set	at
	nop

	sw	$17,4($19)
	move	$5,$18
	jal	P_ChangeSector
	move	$4,$19

	b	$L1
	li	$2,1			# 0x1

$L5:
	lw	$16,0($4)
	subu	$2,$16,$5
	slt	$3,$2,$6
	bne	$3,$0,$L29
	nop

	sw	$2,0($4)
	jal	P_ChangeSector
	move	$5,$7

	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L4
	.set	at
	nop

	b	$L30
	sw	$16,0($19)

$L29:
	sw	$6,0($4)
	jal	P_ChangeSector
	move	$5,$7

	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L23
	.set	at
	nop

$L10:
	b	$L1
	li	$2,2			# 0x2

$L27:
	sw	$6,0($4)
	jal	P_ChangeSector
	move	$5,$7

	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L10
	.set	at
	nop

$L23:
	sw	$16,0($19)
	move	$5,$18
	jal	P_ChangeSector
	move	$4,$19

	b	$L1
	li	$2,2			# 0x2

$L28:
	sw	$6,4($4)
	jal	P_ChangeSector
	move	$5,$7

	.set	noat
	xor	$1,$2,$16
	bne	$1,$0,$L10
	.set	at
	nop

	sw	$17,4($19)
	move	$5,$18
	jal	P_ChangeSector
	move	$4,$19

	b	$L1
	li	$2,2			# 0x2

$L26:
	sw	$6,4($4)
	jal	P_ChangeSector
	move	$5,$7

	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L10
	.set	at
	nop

	sw	$16,4($19)
	move	$5,$18
	jal	P_ChangeSector
	move	$4,$19

	b	$L1
	li	$2,2			# 0x2

	.set	macro
	.set	reorder
	.end	T_MovePlane
	.size	T_MovePlane, .-T_MovePlane
	.align	2
	.globl	T_MoveFloor
	.set	nomips16
	.set	nomicromips
	.ent	T_MoveFloor
	.type	T_MoveFloor, @function
T_MoveFloor:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lw	$2,24($4)
	lw	$7,16($4)
	lw	$6,36($4)
	lw	$5,40($4)
	sw	$16,28($sp)
	move	$16,$4
	lw	$4,20($4)
	sw	$2,20($sp)
	sw	$0,16($sp)
	sw	$17,32($sp)
	sw	$31,36($sp)
	jal	T_MovePlane
	nop

	lui	$3,%hi(leveltime)
	lw	$3,%lo(leveltime)($3)
	andi	$3,$3,0x7
	beq	$3,$0,$L38
	move	$17,$2

	li	$2,2			# 0x2
$L42:
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L39
	.set	at
	lw	$31,36($sp)

	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L39:
	lw	$3,20($16)
	lw	$2,24($16)
	li	$4,1			# 0x1
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L40
	.set	at
	sw	$0,76($3)

	li	$4,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L41
	.set	at
	nop

$L35:
	jal	P_RemoveThinker
	move	$4,$16

	lw	$4,20($16)
	lw	$31,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	li	$5,19			# 0x13
	addiu	$4,$4,44
	j	S_StartSound
	addiu	$sp,$sp,40

$L38:
	lw	$4,20($16)
	li	$5,22			# 0x16
	jal	S_StartSound
	addiu	$4,$4,44

	b	$L42
	li	$2,2			# 0x2

$L41:
	lw	$4,12($16)
	li	$2,6			# 0x6
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L35
	.set	at
	nop

	lw	$4,28($16)
$L43:
	lhu	$2,32($16)
	sh	$4,14($3)
	b	$L35
	sh	$2,8($3)

$L40:
	lw	$4,12($16)
	li	$2,11			# 0xb
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L35
	.set	at
	nop

	b	$L43
	lw	$4,28($16)

	.set	macro
	.set	reorder
	.end	T_MoveFloor
	.size	T_MoveFloor, .-T_MoveFloor
	.align	2
	.globl	EV_DoFloor
	.set	nomips16
	.set	nomicromips
	.ent	EV_DoFloor
	.type	EV_DoFloor, @function
EV_DoFloor:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$20,48($sp)
	lui	$20,%hi(T_MoveFloor)
	addiu	$3,$20,%lo(T_MoveFloor)
	sw	$19,44($sp)
	lui	$19,%hi($L49)
	sll	$2,$5,2
	sw	$3,16($sp)
	addiu	$19,$19,%lo($L49)
	sltu	$3,$5,13
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$21,52($sp)
	move	$18,$5
	move	$16,$4
	move	$22,$0
	li	$23,-1			# 0xffffffffffffffff
	lui	$17,%hi(sectors)
	sw	$3,20($sp)
	addu	$19,$19,$2
$L45:
	move	$5,$23
$L89:
	jal	P_FindSectorFromLineTag
	move	$4,$16

	bltz	$2,$L86
	move	$23,$2

	sll	$3,$23,1
	addu	$3,$3,$23
	sll	$3,$3,2
	lw	$2,%lo(sectors)($17)
	subu	$3,$3,$23
	sll	$3,$3,3
	addu	$20,$2,$3
	lw	$2,76($20)
	bne	$2,$0,$L89
	move	$5,$23

	move	$6,$0
	li	$5,6			# 0x6
	jal	Z_Malloc
	li	$4,44			# 0x2c

	move	$4,$2
	jal	P_AddThinker
	move	$21,$2

	lw	$2,16($sp)
	sw	$21,76($20)
	sw	$2,8($21)
	lw	$2,20($sp)
	sw	$18,12($21)
	beq	$2,$0,$L47
	sw	$0,16($21)

	lw	$2,0($19)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L49:
	.word	$L60
	.word	$L59
	.word	$L58
	.word	$L57
	.word	$L56
	.word	$L55
	.word	$L54
	.word	$L53
	.word	$L52
	.word	$L51
	.word	$L50
	.word	$L47
	.word	$L48
	.text
$L86:
	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	move	$2,$22
	lw	$22,56($sp)
	jr	$31
	addiu	$sp,$sp,72

$L51:
	li	$2,1			# 0x1
	sw	$2,16($21)
$L57:
	li	$2,1			# 0x1
	sw	$2,24($21)
	li	$2,65536			# 0x10000
	move	$4,$20
	sw	$20,20($21)
	jal	P_FindLowestCeilingSurrounding
	sw	$2,40($21)

	lw	$3,4($20)
	xori	$4,$18,0x9
	slt	$5,$2,$3
	sltu	$4,$4,1
	movn	$3,$2,$5
	sll	$2,$4,19
	subu	$3,$3,$2
	sw	$3,36($21)
$L47:
	b	$L45
	li	$22,1			# 0x1

$L56:
	li	$2,1			# 0x1
	lw	$5,0($20)
	sw	$2,24($21)
	li	$2,65536			# 0x10000
	sw	$20,20($21)
	sw	$2,40($21)
	jal	P_FindNextHighestFloor
	move	$4,$20

	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L55:
	lw	$2,80($20)
	li	$4,1			# 0x1
	sw	$4,24($21)
	li	$22,2147418112			# 0x7fff0000
	li	$4,65536			# 0x10000
	sw	$20,20($21)
	sw	$4,40($21)
	blez	$2,$L62
	ori	$22,$22,0xffff

	lui	$2,%hi(textureheight)
	move	$fp,$0
	b	$L65
	sw	$2,24($sp)

$L63:
	lw	$2,80($20)
	addiu	$fp,$fp,1
	slt	$2,$fp,$2
	beq	$2,$0,$L87
	nop

$L65:
	move	$5,$fp
$L90:
	jal	twoSided
	move	$4,$23

	beq	$2,$0,$L63
	move	$6,$0

	move	$5,$fp
	jal	getSide
	move	$4,$23

	lh	$2,10($2)
	bltz	$2,$L64
	lw	$3,24($sp)

	sll	$2,$2,2
	lw	$4,%lo(textureheight)($3)
	addu	$2,$4,$2
	lw	$2,0($2)
	slt	$4,$2,$22
	movn	$22,$2,$4
$L64:
	li	$6,1			# 0x1
	move	$5,$fp
	jal	getSide
	move	$4,$23

	lh	$2,10($2)
	bltz	$2,$L63
	lw	$3,24($sp)

	sll	$2,$2,2
	lw	$4,%lo(textureheight)($3)
	addiu	$fp,$fp,1
	addu	$2,$4,$2
	lw	$2,0($2)
	slt	$4,$2,$22
	movn	$22,$2,$4
	lw	$2,80($20)
	slt	$2,$fp,$2
	bne	$2,$0,$L90
	move	$5,$fp

$L87:
	lw	$20,20($21)
$L62:
	lw	$2,0($20)
	addu	$2,$2,$22
	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L54:
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,24($21)
	li	$2,65536			# 0x10000
	move	$4,$20
	sw	$20,20($21)
	jal	P_FindLowestFloorSurrounding
	sw	$2,40($21)

	lhu	$5,8($20)
	lw	$4,80($20)
	sw	$2,36($21)
	blez	$4,$L47
	sh	$5,32($21)

	li	$22,-1171390464			# 0xffffffffba2e0000
	move	$fp,$0
	b	$L69
	ori	$22,$22,0x8ba3

$L67:
	lw	$2,80($20)
	addiu	$fp,$fp,1
	slt	$2,$fp,$2
	beq	$2,$0,$L47
	nop

$L69:
	move	$5,$fp
	jal	twoSided
	move	$4,$23

	beq	$2,$0,$L67
	move	$6,$0

	move	$5,$fp
	jal	getSide
	move	$4,$23

	lw	$2,16($2)
	lw	$3,%lo(sectors)($17)
	subu	$2,$2,$3
	sra	$2,$2,3
	multu	$2,$22
	mflo	$2
	.set	noat
	xor	$1,$2,$23
	beq	$1,$0,$L85
	.set	at
	li	$6,1			# 0x1

	move	$6,$0
$L85:
	move	$4,$23
	jal	getSector
	move	$5,$fp

	lw	$4,0($2)
	move	$20,$2
	lw	$2,36($21)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L67
	.set	at
	nop

	lhu	$4,8($20)
	lh	$2,14($20)
	li	$22,1			# 0x1
	sh	$4,32($21)
	b	$L45
	sw	$2,28($21)

$L53:
	lw	$2,0($20)
	li	$4,1572864			# 0x180000
$L83:
	addu	$2,$2,$4
	li	$3,65536			# 0x10000
	li	$4,1			# 0x1
	sw	$4,24($21)
	sw	$20,20($21)
	sw	$3,40($21)
	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L48:
	lw	$2,0($20)
	b	$L83
	li	$4,33554432			# 0x2000000

$L59:
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,24($21)
	li	$2,65536			# 0x10000
	sw	$20,20($21)
	sw	$2,40($21)
	jal	P_FindLowestFloorSurrounding
	move	$4,$20

	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L60:
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,24($21)
	li	$2,65536			# 0x10000
	sw	$20,20($21)
	sw	$2,40($21)
	jal	P_FindHighestFloorSurrounding
	move	$4,$20

	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L58:
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,24($21)
	li	$2,262144			# 0x40000
	sw	$20,20($21)
	sw	$2,40($21)
	jal	P_FindHighestFloorSurrounding
	move	$4,$20

	lw	$3,0($20)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L47
	.set	at
	sw	$2,36($21)

	li	$3,524288			# 0x80000
	addu	$2,$2,$3
	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L50:
	li	$2,1			# 0x1
	lw	$5,0($20)
	sw	$2,24($21)
	li	$2,262144			# 0x40000
	sw	$20,20($21)
	sw	$2,40($21)
	jal	P_FindNextHighestFloor
	move	$4,$20

	sw	$2,36($21)
	b	$L45
	li	$22,1			# 0x1

$L52:
	lw	$4,48($16)
	lw	$2,0($20)
	li	$6,1572864			# 0x180000
	lh	$5,8($4)
	addu	$2,$2,$6
	lh	$4,14($4)
	li	$6,1			# 0x1
	sw	$6,24($21)
	li	$6,65536			# 0x10000
	sw	$20,20($21)
	sw	$6,40($21)
	sw	$2,36($21)
	li	$22,1			# 0x1
	sh	$5,8($20)
	b	$L45
	sh	$4,14($20)

	.set	macro
	.set	reorder
	.end	EV_DoFloor
	.size	EV_DoFloor, .-EV_DoFloor
	.align	2
	.globl	EV_BuildStairs
	.set	nomips16
	.set	nomicromips
	.ent	EV_BuildStairs
	.type	EV_BuildStairs, @function
EV_BuildStairs:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$19,36($sp)
	lui	$19,%hi(T_MoveFloor)
	addiu	$2,$19,%lo(T_MoveFloor)
	sw	$2,16($sp)
	xori	$2,$5,0x1
	sw	$fp,56($sp)
	sw	$22,48($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	sw	$31,60($sp)
	sw	$23,52($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$5,68($sp)
	sw	$4,64($sp)
	move	$18,$0
	move	$16,$0
	move	$22,$0
	li	$fp,-1			# 0xffffffffffffffff
	lui	$17,%hi(sectors)
	sw	$2,20($sp)
$L93:
	lw	$4,64($sp)
$L108:
	jal	P_FindSectorFromLineTag
	move	$5,$fp

	bltz	$2,$L107
	move	$fp,$2

	sll	$2,$fp,1
	addu	$2,$2,$fp
	sll	$2,$2,2
	lw	$3,%lo(sectors)($17)
	subu	$2,$2,$fp
	sll	$2,$2,3
	addu	$19,$3,$2
	lw	$2,76($19)
	bne	$2,$0,$L108
	lw	$4,64($sp)

	move	$6,$0
	li	$5,6			# 0x6
	jal	Z_Malloc
	li	$4,44			# 0x2c

	move	$4,$2
	jal	P_AddThinker
	move	$22,$2

	lw	$2,16($sp)
	sw	$22,76($19)
	sw	$2,8($22)
	li	$2,1			# 0x1
	sw	$2,24($22)
	lw	$2,68($sp)
	beq	$2,$0,$L99
	sw	$19,20($22)

	lw	$3,20($sp)
	li	$2,262144			# 0x40000
	movz	$18,$2,$3
	li	$2,1048576			# 0x100000
	movz	$16,$2,$3
$L94:
	lw	$9,0($19)
	li	$8,-1171390464			# 0xffffffffba2e0000
	addu	$20,$16,$9
	lh	$21,8($19)
	ori	$23,$8,0x8ba3
	sw	$18,40($22)
	sw	$20,36($22)
$L96:
	lw	$5,80($19)
	blez	$5,$L93
	li	$22,1			# 0x1

	lw	$2,%lo(sectors)($17)
	lw	$4,84($19)
	b	$L97
	move	$6,$0

$L95:
	.set	noat
	xor	$1,$5,$6
	beq	$1,$0,$L93
	.set	at
	li	$22,1			# 0x1

$L97:
	lw	$7,0($4)
	addiu	$6,$6,1
	lhu	$3,16($7)
	andi	$3,$3,0x4
	beq	$3,$0,$L95
	addiu	$4,$4,4

	lw	$3,48($7)
	subu	$3,$3,$2
	sra	$3,$3,3
	multu	$3,$23
	mflo	$3
	.set	noat
	xor	$1,$fp,$3
	bne	$1,$0,$L95
	.set	at
	nop

	lw	$19,52($7)
	lh	$7,8($19)
	.set	noat
	xor	$1,$7,$21
	bne	$1,$0,$L95
	.set	at
	nop

	lw	$7,76($19)
	bne	$7,$0,$L95
	addu	$20,$20,$16

	subu	$2,$19,$2
	sra	$2,$2,3
	move	$6,$0
	li	$5,6			# 0x6
	li	$4,44			# 0x2c
	jal	Z_Malloc
	multu	$2,$23
	mflo	$fp

	move	$4,$2
	jal	P_AddThinker
	move	$22,$2

	lw	$2,16($sp)
	sw	$22,76($19)
	sw	$2,8($22)
	li	$2,1			# 0x1
	sw	$2,24($22)
	sw	$19,20($22)
	sw	$18,40($22)
	b	$L96
	sw	$20,36($22)

$L107:
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	move	$2,$22
	lw	$22,48($sp)
	jr	$31
	addiu	$sp,$sp,64

$L99:
	li	$18,16384			# 0x4000
	b	$L94
	li	$16,524288			# 0x80000

	.set	macro
	.set	reorder
	.end	EV_BuildStairs
	.size	EV_BuildStairs, .-EV_BuildStairs
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
