	.file	1 "p_inter.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"P_GiveAmmo: bad type %i\000"
	.text
	.align	2
	.globl	P_GiveAmmo
	.set	nomips16
	.set	nomicromips
	.ent	P_GiveAmmo
	.type	P_GiveAmmo, @function
P_GiveAmmo:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L31
	.set	at
	nop

	addiu	$sp,$sp,-32
	sltu	$2,$5,5
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	move	$16,$5
	move	$17,$4
	beq	$2,$0,$L32
	move	$18,$6

	sll	$2,$16,2
$L37:
	addu	$3,$17,$2
	lw	$4,164($3)
	lw	$5,180($3)
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L5
	.set	at
	lui	$7,%hi(clipammo)

	addiu	$7,$7,%lo(clipammo)
	addu	$2,$2,$7
	bne	$18,$0,$L33
	lw	$2,0($2)

	srl	$6,$2,31
	addu	$6,$6,$2
	sra	$6,$6,1
$L7:
	lui	$2,%hi(gameskill)
	lw	$2,%lo(gameskill)($2)
	li	$7,-5			# 0xfffffffffffffffb
	and	$2,$2,$7
	bne	$2,$0,$L8
	nop

	sll	$6,$6,1
$L8:
	addu	$6,$4,$6
	slt	$2,$5,$6
	movn	$6,$5,$2
	bne	$4,$0,$L9
	sw	$6,164($3)

	li	$2,2			# 0x2
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L10
	.set	at
	sltu	$3,$16,3

	beq	$3,$0,$L11
	nop

	beq	$16,$0,$L34
	nop

	lw	$3,120($17)
	sltu	$3,$3,2
	bne	$3,$0,$L35
	nop

$L9:
	b	$L1
	li	$2,1			# 0x1

$L33:
	b	$L7
	multu	$18,$2
	mflo	$6

$L11:
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L1
	.set	at
	li	$2,1			# 0x1

	lw	$2,120($17)
	bne	$2,$0,$L1
	li	$2,1			# 0x1

	lw	$2,144($17)
	beq	$2,$0,$L9
	nop

	li	$2,4			# 0x4
	sw	$2,124($17)
$L36:
	b	$L1
	li	$2,1			# 0x1

$L5:
	move	$2,$0
$L1:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L32:
	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	b	$L37
	sll	$2,$16,2

$L34:
	lw	$2,120($17)
	bne	$2,$0,$L1
	li	$2,1			# 0x1

	lw	$2,140($17)
	beq	$2,$0,$L15
	nop

	li	$2,3			# 0x3
	sw	$2,124($17)
	b	$L1
	li	$2,1			# 0x1

$L10:
	lw	$2,120($17)
	sltu	$2,$2,2
	beq	$2,$0,$L1
	li	$2,1			# 0x1

	lw	$2,148($17)
	beq	$2,$0,$L9
	nop

	li	$2,5			# 0x5
	sw	$2,124($17)
	b	$L1
	li	$2,1			# 0x1

$L31:
	jr	$31
	move	$2,$0

$L35:
	lw	$3,136($17)
	beq	$3,$0,$L9
	nop

	b	$L36
	sw	$2,124($17)

$L15:
	li	$2,1			# 0x1
	b	$L1
	sw	$2,124($17)

	.set	macro
	.set	reorder
	.end	P_GiveAmmo
	.size	P_GiveAmmo, .-P_GiveAmmo
	.align	2
	.globl	P_GiveWeapon
	.set	nomips16
	.set	nomicromips
	.ent	P_GiveWeapon
	.type	P_GiveWeapon, @function
P_GiveWeapon:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$17,$4
	beq	$2,$0,$L39
	move	$16,$5

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L39
	.set	at
	nop

	bne	$6,$0,$L40
	lui	$3,%hi(weaponinfo)

	sll	$6,$5,2
	addu	$6,$4,$6
	lw	$3,128($6)
	bne	$3,$0,$L65
	lw	$31,28($sp)

	sll	$3,$5,1
	addu	$3,$3,$16
	lw	$5,232($4)
	lui	$7,%hi(weaponinfo)
	sll	$3,$3,3
	addiu	$7,$7,%lo(weaponinfo)
	addiu	$5,$5,6
	addu	$3,$3,$7
	sw	$5,232($4)
	lw	$5,0($3)
	li	$3,1			# 0x1
	bne	$2,$0,$L61
	sw	$3,128($6)

	jal	P_GiveAmmo
	li	$6,2			# 0x2

	lui	$2,%hi(consoleplayer)
$L64:
	lw	$2,%lo(consoleplayer)($2)
	sll	$3,$2,3
	addu	$3,$3,$2
	lui	$2,%hi(players)
	sll	$3,$3,5
	addiu	$2,$2,%lo(players)
	addu	$2,$2,$3
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L53
	.set	at
	sw	$16,124($17)

	li	$5,33			# 0x21
	jal	S_StartSound
	move	$4,$0

$L53:
	lw	$31,28($sp)
$L65:
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L39:
	sll	$2,$16,1
	addu	$2,$2,$16
	lui	$3,%hi(weaponinfo)
	sll	$2,$2,3
	addiu	$3,$3,%lo(weaponinfo)
	addu	$2,$2,$3
	lw	$5,0($2)
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L62
	.set	at
	addiu	$3,$16,32

	bne	$6,$0,$L47
	li	$6,2			# 0x2

	jal	P_GiveAmmo
	move	$4,$17

$L48:
	addiu	$3,$16,32
$L63:
	sll	$4,$3,2
	addu	$4,$17,$4
	lw	$4,0($4)
	beq	$4,$0,$L66
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	sltu	$2,$0,$2
	jr	$31
	addiu	$sp,$sp,32

$L62:
	sll	$2,$3,2
	addu	$2,$17,$2
	lw	$2,0($2)
	bne	$2,$0,$L65
	lw	$31,28($sp)

$L66:
	sll	$3,$3,2
	addu	$3,$17,$3
	li	$2,1			# 0x1
	sw	$2,0($3)
	sw	$16,124($17)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L47:
	li	$6,1			# 0x1
$L67:
	jal	P_GiveAmmo
	move	$4,$17

	b	$L63
	addiu	$3,$16,32

$L40:
	sll	$2,$5,1
	addu	$2,$2,$5
	sll	$2,$2,3
	addiu	$3,$3,%lo(weaponinfo)
	addu	$2,$2,$3
	lw	$5,0($2)
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L67
	.set	at
	li	$6,1			# 0x1

	b	$L48
	move	$2,$0

$L61:
	jal	P_GiveAmmo
	li	$6,5			# 0x5

	b	$L64
	lui	$2,%hi(consoleplayer)

	.set	macro
	.set	reorder
	.end	P_GiveWeapon
	.size	P_GiveWeapon, .-P_GiveWeapon
	.align	2
	.globl	P_GiveBody
	.set	nomips16
	.set	nomicromips
	.ent	P_GiveBody
	.type	P_GiveBody, @function
P_GiveBody:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,40($4)
	slt	$3,$2,100
	beq	$3,$0,$L70
	addu	$5,$2,$5

	lw	$3,0($4)
	slt	$6,$5,101
	li	$2,100			# 0x64
	movz	$5,$2,$6
	sw	$5,40($4)
	li	$2,1			# 0x1
	jr	$31
	sw	$5,108($3)

$L70:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	P_GiveBody
	.size	P_GiveBody, .-P_GiveBody
	.align	2
	.globl	P_GiveArmor
	.set	nomips16
	.set	nomicromips
	.ent	P_GiveArmor
	.type	P_GiveArmor, @function
P_GiveArmor:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$5,1
	addu	$2,$2,$5
	sll	$2,$2,3
	lw	$3,44($4)
	addu	$2,$2,$5
	sll	$2,$2,2
	slt	$3,$3,$2
	beq	$3,$0,$L73
	nop

	sw	$2,44($4)
	sw	$5,48($4)
	jr	$31
	li	$2,1			# 0x1

$L73:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	P_GiveArmor
	.size	P_GiveArmor, .-P_GiveArmor
	.align	2
	.globl	P_GiveCard
	.set	nomips16
	.set	nomicromips
	.ent	P_GiveCard
	.type	P_GiveCard, @function
P_GiveCard:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$5,$5,2
	addu	$5,$4,$5
	lw	$2,76($5)
	bne	$2,$0,$L76
	li	$2,6			# 0x6

	sw	$2,232($4)
	li	$2,1			# 0x1
	sw	$2,76($5)
$L76:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_GiveCard
	.size	P_GiveCard, .-P_GiveCard
	.align	2
	.globl	P_GivePower
	.set	nomips16
	.set	nomicromips
	.ent	P_GivePower
	.type	P_GivePower, @function
P_GivePower:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sltu	$2,$5,6
	beq	$2,$0,$L78
	sll	$5,$5,2

	lui	$2,%hi($L80)
	addiu	$2,$2,%lo($L80)
	addu	$2,$2,$5
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L80:
	.word	$L84
	.word	$L83
	.word	$L82
	.word	$L81
	.word	$L78
	.word	$L79
	.text
$L79:
	li	$2,4200			# 0x1068
	sw	$2,72($4)
$L85:
	jr	$31
	li	$2,1			# 0x1

$L84:
	li	$2,1050			# 0x41a
	sw	$2,52($4)
	jr	$31
	li	$2,1			# 0x1

$L83:
	lw	$2,40($4)
	slt	$3,$2,100
	beq	$3,$0,$L87
	li	$5,100			# 0x64

	addiu	$2,$2,100
	lw	$3,0($4)
	slt	$6,$2,101
	movz	$2,$5,$6
	sw	$2,40($4)
	sw	$2,108($3)
$L87:
	li	$2,1			# 0x1
	b	$L85
	sw	$2,56($4)

$L82:
	lw	$3,0($4)
	li	$5,262144			# 0x40000
	lw	$2,104($3)
	or	$2,$2,$5
	li	$5,2100			# 0x834
	sw	$5,60($4)
	b	$L85
	sw	$2,104($3)

$L81:
	li	$2,2100			# 0x834
	b	$L85
	sw	$2,64($4)

$L78:
	addu	$4,$4,$5
	lw	$2,52($4)
	bne	$2,$0,$L88
	nop

	li	$2,1			# 0x1
	b	$L85
	sw	$2,52($4)

$L88:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	P_GivePower
	.size	P_GivePower, .-P_GivePower
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"You got the chaingun!\000"
	.align	2
$LC2:
	.ascii	"You got the BFG9000!  Oh, yes.\000"
	.align	2
$LC3:
	.ascii	"You got the super shotgun!\000"
	.align	2
$LC4:
	.ascii	"You got the shotgun!\000"
	.align	2
$LC5:
	.ascii	"You got the plasma gun!\000"
	.align	2
$LC6:
	.ascii	"You got the rocket launcher!\000"
	.align	2
$LC7:
	.ascii	"A chainsaw!  Find some meat!\000"
	.align	2
$LC8:
	.ascii	"Picked up the armor.\000"
	.align	2
$LC9:
	.ascii	"Picked up the MegaArmor!\000"
	.align	2
$LC10:
	.ascii	"Picked up a health bonus.\000"
	.align	2
$LC11:
	.ascii	"Picked up an armor bonus.\000"
	.align	2
$LC12:
	.ascii	"Supercharge!\000"
	.align	2
$LC13:
	.ascii	"MegaSphere!\000"
	.align	2
$LC14:
	.ascii	"Picked up a blue keycard.\000"
	.align	2
$LC15:
	.ascii	"Picked up a yellow keycard.\000"
	.align	2
$LC16:
	.ascii	"Picked up a red keycard.\000"
	.align	2
$LC17:
	.ascii	"Picked up a blue skull key.\000"
	.align	2
$LC18:
	.ascii	"Picked up a yellow skull key.\000"
	.align	2
$LC19:
	.ascii	"Picked up a red skull key.\000"
	.align	2
$LC20:
	.ascii	"Picked up a stimpack.\000"
	.align	2
$LC21:
	.ascii	"Picked up a medikit that you REALLY need!\000"
	.align	2
$LC22:
	.ascii	"Picked up a medikit.\000"
	.align	2
$LC23:
	.ascii	"Invulnerability!\000"
	.align	2
$LC24:
	.ascii	"Berserk!\000"
	.align	2
$LC25:
	.ascii	"Partial Invisibility\000"
	.align	2
$LC26:
	.ascii	"Radiation Shielding Suit\000"
	.align	2
$LC27:
	.ascii	"Computer Area Map\000"
	.align	2
$LC28:
	.ascii	"Light Amplification Visor\000"
	.align	2
$LC29:
	.ascii	"Picked up a clip.\000"
	.align	2
$LC30:
	.ascii	"Picked up a box of bullets.\000"
	.align	2
$LC31:
	.ascii	"Picked up a rocket.\000"
	.align	2
$LC32:
	.ascii	"Picked up a box of rockets.\000"
	.align	2
$LC33:
	.ascii	"Picked up an energy cell.\000"
	.align	2
$LC34:
	.ascii	"Picked up an energy cell pack.\000"
	.align	2
$LC35:
	.ascii	"Picked up 4 shotgun shells.\000"
	.align	2
$LC36:
	.ascii	"Picked up a box of shotgun shells.\000"
	.align	2
$LC37:
	.ascii	"Picked up a backpack full of ammo!\000"
	.align	2
$LC38:
	.ascii	"P_SpecialThing: Unknown gettable thing\000"
	.text
	.align	2
	.globl	P_TouchSpecialThing
	.set	nomips16
	.set	nomicromips
	.ent	P_TouchSpecialThing
	.type	P_TouchSpecialThing, @function
P_TouchSpecialThing:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lw	$2,20($4)
	sw	$16,20($sp)
	move	$16,$4
	lw	$4,20($5)
	lw	$3,68($5)
	subu	$2,$2,$4
	slt	$3,$3,$2
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	bne	$3,$0,$L91
	sw	$17,24($sp)

	li	$3,-524288			# 0xfffffffffff80000
	slt	$2,$2,$3
	bne	$2,$0,$L91
	nop

	lw	$2,108($5)
	blez	$2,$L91
	lw	$17,132($5)

	lw	$2,36($16)
	addiu	$2,$2,-55
	sltu	$3,$2,39
	beq	$3,$0,$L95
	lui	$3,%hi($L97)

	sll	$2,$2,2
	addiu	$3,$3,%lo($L97)
	addu	$2,$3,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L97:
	.word	$L132
	.word	$L131
	.word	$L95
	.word	$L95
	.word	$L95
	.word	$L130
	.word	$L129
	.word	$L128
	.word	$L127
	.word	$L126
	.word	$L125
	.word	$L124
	.word	$L123
	.word	$L122
	.word	$L121
	.word	$L120
	.word	$L119
	.word	$L118
	.word	$L117
	.word	$L116
	.word	$L115
	.word	$L114
	.word	$L113
	.word	$L112
	.word	$L111
	.word	$L110
	.word	$L109
	.word	$L108
	.word	$L107
	.word	$L106
	.word	$L105
	.word	$L104
	.word	$L103
	.word	$L102
	.word	$L101
	.word	$L100
	.word	$L99
	.word	$L98
	.word	$L96
	.text
$L128:
	lw	$2,76($17)
	bne	$2,$0,$L229
	lui	$2,%hi(netgame)

	lui	$2,%hi($LC14)
	addiu	$2,$2,%lo($LC14)
	sw	$2,224($17)
	li	$2,6			# 0x6
	sw	$2,232($17)
	li	$2,1			# 0x1
	sw	$2,76($17)
$L144:
	lui	$2,%hi(netgame)
$L229:
	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L134
	li	$18,32			# 0x20

$L91:
	lw	$31,36($sp)
$L228:
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L95:
	lui	$4,%hi($LC38)
	jal	I_Error
	addiu	$4,$4,%lo($LC38)

$L133:
	li	$18,32			# 0x20
$L134:
	lw	$2,104($16)
	li	$3,8388608			# 0x800000
	and	$2,$2,$3
	beq	$2,$0,$L154
	nop

	lw	$2,216($17)
	addiu	$2,$2,1
	sw	$2,216($17)
$L154:
	jal	P_RemoveMobj
	move	$4,$16

	lui	$2,%hi(consoleplayer)
	lw	$2,%lo(consoleplayer)($2)
	lw	$4,232($17)
	sll	$3,$2,3
	addu	$3,$3,$2
	lui	$2,%hi(players)
	sll	$3,$3,5
	addiu	$2,$2,%lo(players)
	addiu	$4,$4,6
	addu	$2,$2,$3
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L91
	.set	at
	sw	$4,232($17)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$5,$18
	lw	$18,28($sp)
	move	$4,$0
	j	S_StartSound
	addiu	$sp,$sp,40

$L132:
	lw	$2,44($17)
	slt	$2,$2,100
	beq	$2,$0,$L91
	li	$2,1			# 0x1

	sw	$2,48($17)
	li	$2,100			# 0x64
	sw	$2,44($17)
	lui	$2,%hi($LC8)
	addiu	$2,$2,%lo($LC8)
	b	$L133
	sw	$2,224($17)

$L131:
	lw	$2,44($17)
	slt	$2,$2,200
	beq	$2,$0,$L91
	li	$2,2			# 0x2

	sw	$2,48($17)
	li	$2,200			# 0xc8
	sw	$2,44($17)
	lui	$2,%hi($LC9)
	addiu	$2,$2,%lo($LC9)
	b	$L133
	sw	$2,224($17)

$L130:
	lw	$2,40($17)
	lw	$3,0($17)
	addiu	$2,$2,1
	slt	$5,$2,201
	li	$4,200			# 0xc8
	movz	$2,$4,$5
	sw	$2,40($17)
	sw	$2,108($3)
	lui	$2,%hi($LC10)
	addiu	$2,$2,%lo($LC10)
	b	$L133
	sw	$2,224($17)

$L129:
	lw	$2,44($17)
	li	$4,200			# 0xc8
	addiu	$2,$2,1
	slt	$5,$2,201
	lw	$3,48($17)
	movz	$2,$4,$5
	bne	$3,$0,$L135
	sw	$2,44($17)

	li	$2,1			# 0x1
	sw	$2,48($17)
$L135:
	lui	$2,%hi($LC11)
	addiu	$2,$2,%lo($LC11)
	b	$L133
	sw	$2,224($17)

$L127:
	lw	$2,84($17)
	bne	$2,$0,$L229
	lui	$2,%hi(netgame)

	lui	$2,%hi($LC16)
	addiu	$2,$2,%lo($LC16)
	sw	$2,224($17)
	li	$2,6			# 0x6
	sw	$2,232($17)
	li	$2,1			# 0x1
	b	$L144
	sw	$2,84($17)

$L126:
	lw	$2,80($17)
	bne	$2,$0,$L229
	lui	$2,%hi(netgame)

	lui	$2,%hi($LC15)
	addiu	$2,$2,%lo($LC15)
	sw	$2,224($17)
	li	$2,6			# 0x6
	sw	$2,232($17)
	li	$2,1			# 0x1
	b	$L144
	sw	$2,80($17)

$L125:
	lw	$2,88($17)
	bne	$2,$0,$L229
	lui	$2,%hi(netgame)

	lui	$2,%hi($LC17)
	addiu	$2,$2,%lo($LC17)
	sw	$2,224($17)
	li	$2,6			# 0x6
	sw	$2,232($17)
	li	$2,1			# 0x1
	b	$L144
	sw	$2,88($17)

$L124:
	lw	$2,96($17)
	bne	$2,$0,$L229
	lui	$2,%hi(netgame)

	lui	$2,%hi($LC19)
	addiu	$2,$2,%lo($LC19)
	sw	$2,224($17)
	li	$2,6			# 0x6
	sw	$2,232($17)
	li	$2,1			# 0x1
	b	$L144
	sw	$2,96($17)

$L123:
	lw	$2,92($17)
	bne	$2,$0,$L229
	lui	$2,%hi(netgame)

	lui	$2,%hi($LC18)
	addiu	$2,$2,%lo($LC18)
	sw	$2,224($17)
	li	$2,6			# 0x6
	sw	$2,232($17)
	li	$2,1			# 0x1
	b	$L144
	sw	$2,92($17)

$L122:
	lw	$2,40($17)
	slt	$3,$2,100
	beq	$3,$0,$L91
	addiu	$2,$2,10

	lw	$3,0($17)
	slt	$5,$2,101
	li	$4,100			# 0x64
	movz	$2,$4,$5
	sw	$2,40($17)
	sw	$2,108($3)
	lui	$2,%hi($LC20)
	addiu	$2,$2,%lo($LC20)
	b	$L133
	sw	$2,224($17)

$L121:
	lw	$2,40($17)
	slt	$3,$2,100
	beq	$3,$0,$L91
	addiu	$2,$2,25

	slt	$3,$2,101
	beq	$3,$0,$L145
	lw	$4,0($17)

	slt	$3,$2,25
	sw	$2,40($17)
	beq	$3,$0,$L146
	sw	$2,108($4)

	lui	$2,%hi($LC21)
	addiu	$2,$2,%lo($LC21)
	b	$L133
	sw	$2,224($17)

$L120:
	lw	$2,40($17)
	lw	$3,0($17)
	addiu	$2,$2,100
	slt	$5,$2,201
	li	$4,200			# 0xc8
	movz	$2,$4,$5
	sw	$2,40($17)
	sw	$2,108($3)
	lui	$2,%hi($LC12)
	addiu	$2,$2,%lo($LC12)
	sw	$2,224($17)
$L136:
	b	$L134
	li	$18,93			# 0x5d

$L119:
	li	$2,1050			# 0x41a
	sw	$2,52($17)
	lui	$2,%hi($LC23)
	addiu	$2,$2,%lo($LC23)
	sw	$2,224($17)
	b	$L134
	li	$18,93			# 0x5d

$L116:
	lui	$2,%hi(gamemode)
	lw	$2,%lo(gamemode)($2)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L228
	.set	at
	lw	$31,36($sp)

	lw	$3,44($17)
	lw	$5,0($17)
	li	$4,200			# 0xc8
	slt	$3,$3,200
	sw	$4,40($17)
	beq	$3,$0,$L137
	sw	$4,108($5)

	sw	$2,48($17)
	sw	$4,44($17)
$L137:
	lui	$2,%hi($LC13)
	addiu	$2,$2,%lo($LC13)
	sw	$2,224($17)
	b	$L134
	li	$18,93			# 0x5d

$L115:
	li	$2,2100			# 0x834
	sw	$2,64($17)
	lui	$2,%hi($LC26)
	addiu	$2,$2,%lo($LC26)
	sw	$2,224($17)
	b	$L134
	li	$18,93			# 0x5d

$L114:
	lw	$2,68($17)
	bne	$2,$0,$L91
	li	$2,1			# 0x1

	sw	$2,68($17)
	lui	$2,%hi($LC27)
	addiu	$2,$2,%lo($LC27)
	sw	$2,224($17)
	b	$L134
	li	$18,93			# 0x5d

$L113:
	li	$2,4200			# 0x1068
	sw	$2,72($17)
	lui	$2,%hi($LC28)
	addiu	$2,$2,%lo($LC28)
	sw	$2,224($17)
	b	$L134
	li	$18,93			# 0x5d

$L118:
	lw	$2,40($17)
	slt	$3,$2,100
	beq	$3,$0,$L147
	addiu	$2,$2,100

	lw	$3,0($17)
	slt	$5,$2,101
	li	$4,100			# 0x64
	movz	$2,$4,$5
	sw	$2,40($17)
	sw	$2,108($3)
$L147:
	li	$2,1			# 0x1
	sw	$2,56($17)
	lw	$3,120($17)
	lui	$2,%hi($LC24)
	addiu	$2,$2,%lo($LC24)
	beq	$3,$0,$L136
	sw	$2,224($17)

	sw	$0,124($17)
	b	$L134
	li	$18,93			# 0x5d

$L117:
	lw	$3,0($17)
	li	$4,262144			# 0x40000
	lw	$2,104($3)
	li	$18,93			# 0x5d
	or	$2,$2,$4
	li	$4,2100			# 0x834
	sw	$4,60($17)
	sw	$2,104($3)
	lui	$2,%hi($LC25)
	addiu	$2,$2,%lo($LC25)
	b	$L134
	sw	$2,224($17)

$L112:
	lw	$2,104($16)
	li	$3,131072			# 0x20000
	and	$2,$2,$3
	beq	$2,$0,$L148
	li	$6,1			# 0x1

	move	$6,$0
	move	$5,$0
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L228
	lw	$31,36($sp)

	lui	$2,%hi($LC29)
$L232:
	addiu	$2,$2,%lo($LC29)
	b	$L133
	sw	$2,224($17)

$L111:
	li	$6,5			# 0x5
	move	$5,$0
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC30)

	addiu	$2,$2,%lo($LC30)
	b	$L133
	sw	$2,224($17)

$L110:
	li	$6,1			# 0x1
	li	$5,3			# 0x3
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC31)

	addiu	$2,$2,%lo($LC31)
	b	$L133
	sw	$2,224($17)

$L109:
	li	$6,5			# 0x5
	li	$5,3			# 0x3
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC32)

	addiu	$2,$2,%lo($LC32)
	b	$L133
	sw	$2,224($17)

$L108:
	li	$6,1			# 0x1
	li	$5,2			# 0x2
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC33)

	addiu	$2,$2,%lo($LC33)
	b	$L133
	sw	$2,224($17)

$L107:
	li	$6,5			# 0x5
	li	$5,2			# 0x2
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC34)

	addiu	$2,$2,%lo($LC34)
	b	$L133
	sw	$2,224($17)

$L106:
	li	$6,1			# 0x1
	li	$5,1			# 0x1
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC35)

	addiu	$2,$2,%lo($LC35)
	b	$L133
	sw	$2,224($17)

$L105:
	li	$6,5			# 0x5
	li	$5,1			# 0x1
	jal	P_GiveAmmo
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC36)

	addiu	$2,$2,%lo($LC36)
	b	$L133
	sw	$2,224($17)

$L104:
	lw	$2,100($17)
	bne	$2,$0,$L230
	move	$18,$0

	addiu	$2,$17,180
	addiu	$4,$17,196
$L151:
	lw	$3,0($2)
	addiu	$2,$2,4
	sll	$3,$3,1
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L151
	.set	at
	sw	$3,-4($2)

	li	$2,1			# 0x1
	sw	$2,100($17)
	move	$18,$0
$L230:
	li	$19,4			# 0x4
	move	$5,$18
$L231:
	li	$6,1			# 0x1
	addiu	$18,$18,1
	jal	P_GiveAmmo
	move	$4,$17

	.set	noat
	xor	$1,$18,$19
	bne	$1,$0,$L231
	.set	at
	move	$5,$18

	lui	$2,%hi($LC37)
	addiu	$2,$2,%lo($LC37)
	b	$L133
	sw	$2,224($17)

$L103:
	move	$6,$0
	li	$5,6			# 0x6
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC2)

	addiu	$2,$2,%lo($LC2)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L100:
	move	$6,$0
	li	$5,4			# 0x4
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC6)

	addiu	$2,$2,%lo($LC6)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L102:
	lw	$6,104($16)
	li	$5,3			# 0x3
	srl	$6,$6,17
	andi	$6,$6,0x1
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC1)

	addiu	$2,$2,%lo($LC1)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L101:
	move	$6,$0
	li	$5,7			# 0x7
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC7)

	addiu	$2,$2,%lo($LC7)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L98:
	lw	$6,104($16)
	li	$5,2			# 0x2
	srl	$6,$6,17
	andi	$6,$6,0x1
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC4)

	addiu	$2,$2,%lo($LC4)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L96:
	lw	$6,104($16)
	li	$5,8			# 0x8
	srl	$6,$6,17
	andi	$6,$6,0x1
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC3)

	addiu	$2,$2,%lo($LC3)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L99:
	move	$6,$0
	li	$5,5			# 0x5
	jal	P_GiveWeapon
	move	$4,$17

	beq	$2,$0,$L91
	lui	$2,%hi($LC5)

	addiu	$2,$2,%lo($LC5)
	sw	$2,224($17)
	b	$L134
	li	$18,33			# 0x21

$L148:
	move	$5,$0
	jal	P_GiveAmmo
	move	$4,$17

	bne	$2,$0,$L232
	lui	$2,%hi($LC29)

	b	$L228
	lw	$31,36($sp)

$L145:
	li	$2,100			# 0x64
	sw	$2,40($17)
	sw	$2,108($4)
$L146:
	lui	$2,%hi($LC22)
	addiu	$2,$2,%lo($LC22)
	b	$L133
	sw	$2,224($17)

	.set	macro
	.set	reorder
	.end	P_TouchSpecialThing
	.size	P_TouchSpecialThing, .-P_TouchSpecialThing
	.align	2
	.globl	P_KillMobj
	.set	nomips16
	.set	nomicromips
	.ent	P_KillMobj
	.type	P_KillMobj, @function
P_KillMobj:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$6,88($5)
	addiu	$sp,$sp,-32
	li	$3,18			# 0x12
	lw	$2,104($5)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$5
	sw	$17,24($sp)
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L287
	.set	at
	move	$5,$4

	li	$3,-16842752			# 0xfffffffffeff0000
	ori	$3,$3,0xbdfb
	lw	$6,68($16)
	and	$2,$2,$3
	li	$3,1048576			# 0x100000
	addiu	$3,$3,1024
	or	$3,$2,$3
	sra	$6,$6,2
	lw	$4,132($16)
	sw	$3,104($16)
	beq	$5,$0,$L236
	sw	$6,68($16)

$L289:
	lw	$3,132($5)
	beq	$3,$0,$L237
	nop

	li	$5,4194304			# 0x400000
	and	$5,$2,$5
	beq	$5,$0,$L238
	nop

	lw	$5,212($3)
	addiu	$5,$5,1
	sw	$5,212($3)
$L238:
	beq	$4,$0,$L240
	lui	$17,%hi(players)

	addiu	$17,$17,%lo(players)
	subu	$5,$4,$17
	li	$6,954400768			# 0x38e30000
	sra	$5,$5,5
	ori	$6,$6,0x8e39
	multu	$5,$6
	mflo	$5
	sll	$5,$5,2
	addu	$3,$3,$5
	lw	$5,104($3)
	addiu	$5,$5,1
	sw	$5,104($3)
$L241:
	li	$3,-3			# 0xfffffffffffffffd
	and	$2,$2,$3
$L294:
	li	$3,1048576			# 0x100000
	addiu	$3,$3,1024
	or	$2,$2,$3
	sw	$2,104($16)
	li	$2,1			# 0x1
	jal	P_DropWeapon
	sw	$2,4($4)

	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	lw	$4,132($16)
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,5
	addu	$2,$17,$2
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L288
	.set	at
	lui	$2,%hi(automapactive)

$L240:
	lw	$4,92($16)
$L291:
	lw	$2,108($16)
	lw	$3,8($4)
	subu	$3,$0,$3
	slt	$2,$2,$3
	beq	$2,$0,$L248
	nop

	lw	$5,52($4)
	bne	$5,$0,$L282
	nop

$L248:
	lw	$5,48($4)
$L282:
	jal	P_SetMobjState
	move	$4,$16

	jal	P_Random
	nop

	lw	$3,96($16)
	andi	$2,$2,0x3
	subu	$2,$3,$2
	lui	$5,%hi(gameversion)
	slt	$4,$0,$2
	li	$3,1			# 0x1
	lw	$5,%lo(gameversion)($5)
	movz	$2,$3,$4
	li	$4,9			# 0x9
	.set	noat
	xor	$1,$5,$4
	beq	$1,$0,$L233
	.set	at
	sw	$2,96($16)

	lw	$2,88($16)
	li	$4,10			# 0xa
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L253
	.set	at
	sltu	$4,$2,11

	beq	$4,$0,$L252
	nop

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L254
	.set	at
	li	$3,2			# 0x2

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L233
	.set	at
	li	$7,77			# 0x4d

$L251:
	lw	$4,12($16)
	lw	$5,16($16)
	jal	P_SpawnMobj
	li	$6,-2147483648			# 0xffffffff80000000

	lw	$3,104($2)
	li	$4,131072			# 0x20000
	or	$3,$3,$4
	sw	$3,104($2)
$L233:
	lw	$31,28($sp)
$L292:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L237:
	lui	$3,%hi(netgame)
	lw	$3,%lo(netgame)($3)
	beq	$3,$0,$L242
	li	$3,4194304			# 0x400000

$L286:
	beq	$4,$0,$L240
	lui	$17,%hi(players)

	b	$L241
	addiu	$17,$17,%lo(players)

$L252:
	li	$3,23			# 0x17
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L292
	.set	at
	lw	$31,28($sp)

$L254:
	b	$L251
	li	$7,63			# 0x3f

$L287:
	li	$3,-16842752			# 0xfffffffffeff0000
	ori	$3,$3,0xbffb
	lw	$6,68($16)
	and	$2,$2,$3
	li	$3,1048576			# 0x100000
	addiu	$3,$3,1024
	or	$3,$2,$3
	sra	$6,$6,2
	lw	$4,132($16)
	sw	$3,104($16)
	bne	$5,$0,$L289
	sw	$6,68($16)

$L236:
	lui	$3,%hi(netgame)
	lw	$3,%lo(netgame)($3)
	bne	$3,$0,$L284
	li	$3,4194304			# 0x400000

	and	$3,$2,$3
	beq	$3,$0,$L284
	lui	$17,%hi(players)

$L293:
	addiu	$17,$17,%lo(players)
	lw	$3,212($17)
	addiu	$3,$3,1
	beq	$4,$0,$L240
	sw	$3,212($17)

	beq	$5,$0,$L246
	li	$3,-3			# 0xfffffffffffffffd

	b	$L294
	and	$2,$2,$3

$L284:
	beq	$4,$0,$L240
	lui	$17,%hi(players)

	addiu	$17,$17,%lo(players)
$L246:
	subu	$3,$4,$17
	li	$5,954400768			# 0x38e30000
	ori	$5,$5,0x8e39
	sra	$3,$3,5
	multu	$3,$5
	mflo	$3
	sll	$3,$3,2
	addu	$3,$4,$3
	lw	$5,104($3)
	addiu	$5,$5,1
	b	$L241
	sw	$5,104($3)

$L288:
	lw	$2,%lo(automapactive)($2)
	beq	$2,$0,$L240
	nop

	jal	AM_Stop
	nop

	b	$L291
	lw	$4,92($16)

$L242:
	and	$3,$2,$3
	bne	$3,$0,$L293
	lui	$17,%hi(players)

	b	$L286
	nop

$L253:
	b	$L251
	li	$7,73			# 0x49

	.set	macro
	.set	reorder
	.end	P_KillMobj
	.size	P_KillMobj, .-P_KillMobj
	.align	2
	.globl	P_DamageMobj
	.set	nomips16
	.set	nomicromips
	.ent	P_DamageMobj
	.type	P_DamageMobj, @function
P_DamageMobj:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	andi	$3,$2,0x4
	beq	$3,$0,$L379
	nop

	lw	$3,108($4)
	addiu	$sp,$sp,-48
	sw	$16,16($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	blez	$3,$L295
	move	$16,$4

	li	$4,16777216			# 0x1000000
	and	$4,$2,$4
	move	$20,$5
	move	$19,$6
	beq	$4,$0,$L299
	move	$17,$7

	sw	$0,80($16)
	sw	$0,76($16)
	sw	$0,72($16)
$L299:
	lw	$18,132($16)
	beq	$18,$0,$L368
	nop

	lui	$3,%hi(gameskill)
	lw	$3,%lo(gameskill)($3)
	beq	$3,$0,$L303
	nop

$L367:
	beq	$20,$0,$L304
	andi	$2,$2,0x1000

	bne	$2,$0,$L304
	nop

$L302:
	beq	$19,$0,$L305
	nop

	lw	$2,132($19)
	beq	$2,$0,$L305
	nop

	lw	$3,120($2)
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L306
	.set	at
	nop

$L305:
	lw	$5,16($20)
	lw	$4,12($20)
	lw	$7,16($16)
	jal	R_PointToAngle2
	lw	$6,12($16)

	sll	$3,$17,1
	lw	$4,92($16)
	addu	$3,$3,$17
	sll	$3,$3,3
	lw	$5,72($4)
	addu	$3,$3,$17
	sll	$3,$3,15
	div	$0,$3,$5
	slt	$4,$17,40
	move	$21,$2
	beq	$4,$0,$L309
	mflo	$22

	lw	$2,108($16)
	slt	$2,$2,$17
	beq	$2,$0,$L377
	lui	$2,%hi(finecosine)

	lw	$3,20($20)
	lw	$2,20($16)
	subu	$2,$2,$3
	li	$3,4194304			# 0x400000
	addiu	$3,$3,1
	slt	$2,$2,$3
	bne	$2,$0,$L377
	lui	$2,%hi(finecosine)

	jal	P_Random
	nop

	andi	$2,$2,0x1
	beq	$2,$0,$L377
	lui	$2,%hi(finecosine)

	li	$2,-2147483648			# 0xffffffff80000000
	addu	$21,$21,$2
	sll	$22,$22,2
$L309:
	lui	$2,%hi(finecosine)
$L377:
	lw	$2,%lo(finecosine)($2)
	srl	$20,$21,19
	sll	$20,$20,2
	addu	$2,$2,$20
	lw	$5,0($2)
	jal	FixedMul
	move	$4,$22

	lui	$4,%hi(finesine)
	lw	$3,72($16)
	addiu	$4,$4,%lo(finesine)
	addu	$20,$20,$4
	addu	$2,$3,$2
	lw	$5,0($20)
	sw	$2,72($16)
	jal	FixedMul
	move	$4,$22

	lw	$3,76($16)
	addu	$3,$3,$2
	sw	$3,76($16)
$L306:
	beq	$18,$0,$L365
	nop

$L304:
	lw	$3,52($16)
	li	$2,11			# 0xb
	lw	$3,0($3)
	lh	$3,14($3)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L369
	.set	at
	nop

$L310:
	slt	$2,$17,1000
	beq	$2,$0,$L311
	nop

	lw	$2,204($18)
	andi	$2,$2,0x2
	bne	$2,$0,$L378
	lw	$31,44($sp)

	lw	$2,52($18)
	bne	$2,$0,$L378
	nop

$L311:
	lw	$2,48($18)
	beq	$2,$0,$L312
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L370
	.set	at
	li	$2,1431633920			# 0x55550000

	srl	$2,$17,31
	addu	$2,$2,$17
	sra	$2,$2,1
$L314:
	lw	$3,44($18)
	slt	$4,$2,$3
	beq	$4,$0,$L315
	nop

	subu	$3,$3,$2
	sw	$3,44($18)
	subu	$17,$17,$2
$L312:
	lui	$2,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($2)
	lw	$2,228($18)
	lw	$3,40($18)
	sll	$5,$4,3
	addu	$2,$2,$17
	addu	$5,$5,$4
	li	$6,100			# 0x64
	slt	$4,$2,101
	subu	$3,$3,$17
	movz	$2,$6,$4
	lui	$4,%hi(players)
	slt	$7,$3,0
	sll	$5,$5,5
	addiu	$4,$4,%lo(players)
	movn	$3,$0,$7
	addu	$4,$4,$5
	sw	$3,40($18)
	sw	$19,236($18)
	.set	noat
	xor	$1,$18,$4
	beq	$1,$0,$L317
	.set	at
	sw	$2,228($18)

$L365:
	lw	$3,108($16)
$L301:
	subu	$3,$3,$17
$L375:
	blez	$3,$L371
	sw	$3,108($16)

	jal	P_Random
	nop

	lw	$3,92($16)
	lw	$4,32($3)
	slt	$2,$2,$4
	beq	$2,$0,$L319
	li	$2,16777216			# 0x1000000

	lw	$4,104($16)
	and	$2,$4,$2
	beq	$2,$0,$L372
	nop

$L319:
	lw	$2,128($16)
$L376:
	bne	$2,$0,$L373
	sw	$0,124($16)

$L320:
	beq	$19,$0,$L378
	lw	$31,44($sp)

	.set	noat
	xor	$1,$16,$19
	beq	$1,$0,$L378
	.set	at
	li	$2,3			# 0x3

	lw	$3,88($19)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L378
	.set	at
	nop

	lw	$4,92($16)
	lw	$5,100($16)
	lw	$2,4($4)
	sw	$19,120($16)
	sll	$3,$2,3
	subu	$3,$3,$2
	lui	$2,%hi(states)
	sll	$3,$3,2
	addiu	$2,$2,%lo(states)
	addu	$2,$2,$3
	li	$3,100			# 0x64
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L374
	.set	at
	sw	$3,128($16)

$L295:
	lw	$31,44($sp)
$L378:
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L379:
	jr	$31
	nop

$L303:
	b	$L367
	sra	$17,$17,1

$L373:
	lw	$3,88($16)
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L378
	.set	at
	lw	$31,44($sp)

	b	$L320
	nop

$L368:
	beq	$20,$0,$L301
	andi	$2,$2,0x1000

	beq	$2,$0,$L302
	subu	$3,$3,$17

	b	$L375
	nop

$L369:
	lw	$2,108($16)
	slt	$3,$17,$2
	bne	$3,$0,$L310
	nop

	b	$L310
	addiu	$17,$2,-1

$L371:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$5,$16
	move	$4,$19
	lw	$16,16($sp)
	lw	$19,28($sp)
	j	P_KillMobj
	addiu	$sp,$sp,48

$L315:
	move	$2,$3
	move	$3,$0
	sw	$0,48($18)
	sw	$3,44($18)
	b	$L312
	subu	$17,$17,$2

$L372:
	lw	$5,28($3)
	ori	$4,$4,0x40
	sw	$4,104($16)
	jal	P_SetMobjState
	move	$4,$16

	b	$L376
	lw	$2,128($16)

$L317:
	slt	$2,$17,101
	movn	$6,$17,$2
	addiu	$6,$6,20
	sll	$6,$6,1
	li	$5,10			# 0xa
	jal	I_Tactile
	li	$4,40			# 0x28

	b	$L301
	lw	$3,108($16)

$L374:
	lw	$5,12($4)
	beq	$5,$0,$L295
	lw	$31,44($sp)

	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,48

$L370:
	addiu	$2,$2,21846
	mult	$17,$2
	sra	$3,$17,31
	mfhi	$2
	b	$L314
	subu	$2,$2,$3

	.set	macro
	.set	reorder
	.end	P_DamageMobj
	.size	P_DamageMobj, .-P_DamageMobj
	.globl	clipammo
	.data
	.align	2
	.type	clipammo, @object
	.size	clipammo, 16
clipammo:
	.word	10
	.word	4
	.word	20
	.word	1
	.globl	maxammo
	.align	2
	.type	maxammo, @object
	.size	maxammo, 16
maxammo:
	.word	200
	.word	50
	.word	300
	.word	50
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
