	.file	1 "p_lights.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	T_StrobeFlash
	.set	nomips16
	.set	nomicromips
	.ent	T_StrobeFlash
	.type	T_StrobeFlash, @function
T_StrobeFlash:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($4)
	addiu	$2,$2,-1
	bne	$2,$0,$L6
	sw	$2,16($4)

	lw	$2,12($4)
	lw	$3,20($4)
	lh	$5,12($2)
	.set	noat
	xor	$1,$5,$3
	beq	$1,$0,$L5
	.set	at
	nop

	lw	$5,28($4)
	sh	$3,12($2)
	sw	$5,16($4)
$L6:
	jr	$31
	nop

$L5:
	lw	$3,32($4)
	lw	$5,24($4)
	sh	$5,12($2)
	jr	$31
	sw	$3,16($4)

	.set	macro
	.set	reorder
	.end	T_StrobeFlash
	.size	T_StrobeFlash, .-T_StrobeFlash
	.align	2
	.globl	T_Glow
	.set	nomips16
	.set	nomicromips
	.ent	T_Glow
	.type	T_Glow, @function
T_Glow:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,24($4)
	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L8
	.set	at
	li	$5,1			# 0x1

	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L14
	.set	at
	nop

	lw	$6,12($4)
	lw	$5,20($4)
	lh	$7,12($6)
	addiu	$2,$7,8
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$5,$2,$5
	bne	$5,$0,$L14
	sh	$2,12($6)

	sh	$7,12($6)
	jr	$31
	sw	$3,24($4)

$L14:
	jr	$31
	nop

$L8:
	lw	$5,12($4)
	lw	$3,16($4)
	lh	$6,12($5)
	addiu	$2,$6,-8
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$3,$3,$2
	bne	$3,$0,$L14
	sh	$2,12($5)

	li	$2,1			# 0x1
	sh	$6,12($5)
	jr	$31
	sw	$2,24($4)

	.set	macro
	.set	reorder
	.end	T_Glow
	.size	T_Glow, .-T_Glow
	.align	2
	.globl	T_FireFlicker
	.set	nomips16
	.set	nomicromips
	.ent	T_FireFlicker
	.type	T_FireFlicker, @function
T_FireFlicker:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($4)
	addiu	$2,$2,-1
	beq	$2,$0,$L24
	sw	$2,16($4)

	jr	$31
	nop

$L24:
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_Random
	move	$16,$4

	lw	$5,12($16)
	andi	$2,$2,0x3
	lh	$4,12($5)
	lw	$3,24($16)
	sll	$2,$2,4
	subu	$4,$4,$2
	slt	$4,$4,$3
	bne	$4,$0,$L25
	lw	$31,20($sp)

	lw	$3,20($16)
	subu	$3,$3,$2
$L25:
	sll	$3,$3,16
	sra	$3,$3,16
	li	$2,4			# 0x4
	sh	$3,12($5)
	sw	$2,16($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	T_FireFlicker
	.size	T_FireFlicker, .-T_FireFlicker
	.align	2
	.globl	T_LightFlash
	.set	nomips16
	.set	nomicromips
	.ent	T_LightFlash
	.type	T_LightFlash, @function
T_LightFlash:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($4)
	addiu	$2,$2,-1
	bne	$2,$0,$L36
	sw	$2,16($4)

	lw	$2,12($4)
	addiu	$sp,$sp,-24
	lw	$3,20($4)
	sw	$16,16($sp)
	move	$16,$4
	lh	$4,12($2)
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L35
	.set	at
	sw	$31,20($sp)

	jal	P_Random
	sh	$3,12($2)

	lw	$3,28($16)
	lw	$31,20($sp)
	and	$2,$2,$3
	addiu	$2,$2,1
	sw	$2,16($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L35:
	lw	$3,24($16)
	jal	P_Random
	sh	$3,12($2)

	lw	$3,32($16)
	lw	$31,20($sp)
	and	$2,$2,$3
	addiu	$2,$2,1
	sw	$2,16($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L36:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	T_LightFlash
	.size	T_LightFlash, .-T_LightFlash
	.align	2
	.globl	P_SpawnFireFlicker
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnFireFlicker
	.type	P_SpawnFireFlicker, @function
P_SpawnFireFlicker:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	move	$17,$4
	sw	$31,28($sp)
	sw	$16,20($sp)
	move	$6,$0
	li	$5,6			# 0x6
	li	$4,28			# 0x1c
	jal	Z_Malloc
	sh	$0,14($17)

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	lh	$5,12($17)
	lui	$2,%hi(T_FireFlicker)
	addiu	$2,$2,%lo(T_FireFlicker)
	sw	$17,12($16)
	sw	$2,8($16)
	sw	$5,20($16)
	jal	P_FindMinSurroundingLight
	move	$4,$17

	addiu	$2,$2,16
	lw	$31,28($sp)
	sw	$2,24($16)
	li	$2,4			# 0x4
	lw	$17,24($sp)
	sw	$2,16($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_SpawnFireFlicker
	.size	P_SpawnFireFlicker, .-P_SpawnFireFlicker
	.align	2
	.globl	P_SpawnLightFlash
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnLightFlash
	.type	P_SpawnLightFlash, @function
P_SpawnLightFlash:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	move	$17,$4
	sw	$31,28($sp)
	sw	$16,20($sp)
	move	$6,$0
	li	$5,6			# 0x6
	li	$4,36			# 0x24
	jal	Z_Malloc
	sh	$0,14($17)

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	lh	$5,12($17)
	lui	$2,%hi(T_LightFlash)
	addiu	$2,$2,%lo(T_LightFlash)
	sw	$17,12($16)
	sw	$5,20($16)
	move	$4,$17
	jal	P_FindMinSurroundingLight
	sw	$2,8($16)

	sw	$2,24($16)
	li	$2,64			# 0x40
	sw	$2,28($16)
	li	$2,7			# 0x7
	jal	P_Random
	sw	$2,32($16)

	lw	$3,28($16)
	lw	$31,28($sp)
	and	$2,$2,$3
	addiu	$2,$2,1
	lw	$17,24($sp)
	sw	$2,16($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_SpawnLightFlash
	.size	P_SpawnLightFlash, .-P_SpawnLightFlash
	.align	2
	.globl	P_SpawnStrobeFlash
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnStrobeFlash
	.type	P_SpawnStrobeFlash, @function
P_SpawnStrobeFlash:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	move	$19,$5
	move	$17,$4
	li	$5,6			# 0x6
	li	$4,36			# 0x24
	move	$18,$6
	move	$6,$0
	sw	$31,36($sp)
	jal	Z_Malloc
	sw	$16,20($sp)

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	li	$2,5			# 0x5
	lh	$5,12($17)
	sw	$2,32($16)
	lui	$2,%hi(T_StrobeFlash)
	addiu	$2,$2,%lo(T_StrobeFlash)
	sw	$17,12($16)
	sw	$19,28($16)
	sw	$2,8($16)
	sw	$5,24($16)
	jal	P_FindMinSurroundingLight
	move	$4,$17

	lw	$3,24($16)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L42
	.set	at
	nop

	move	$2,$0
$L42:
	sw	$2,20($16)
	beq	$18,$0,$L46
	sh	$0,14($17)

	lw	$31,36($sp)
	li	$2,1			# 0x1
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,16($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L46:
	jal	P_Random
	nop

	andi	$2,$2,0x7
	lw	$31,36($sp)
	addiu	$2,$2,1
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,16($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_SpawnStrobeFlash
	.size	P_SpawnStrobeFlash, .-P_SpawnStrobeFlash
	.align	2
	.globl	EV_StartLightStrobing
	.set	nomips16
	.set	nomicromips
	.ent	EV_StartLightStrobing
	.type	EV_StartLightStrobing, @function
EV_StartLightStrobing:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	move	$17,$4
	li	$16,-1			# 0xffffffffffffffff
	lui	$18,%hi(sectors)
	move	$5,$16
$L53:
	jal	P_FindSectorFromLineTag
	move	$4,$17

	sll	$3,$2,1
	addu	$3,$3,$2
	sll	$3,$3,2
	subu	$3,$3,$2
	move	$16,$2
	bltz	$2,$L52
	sll	$3,$3,3

$L50:
	lw	$4,%lo(sectors)($18)
	addu	$4,$4,$3
	lw	$2,76($4)
	bne	$2,$0,$L53
	move	$5,$16

	move	$6,$0
	jal	P_SpawnStrobeFlash
	li	$5,35			# 0x23

	move	$5,$16
	jal	P_FindSectorFromLineTag
	move	$4,$17

	sll	$3,$2,1
	addu	$3,$3,$2
	sll	$3,$3,2
	subu	$3,$3,$2
	move	$16,$2
	bgez	$2,$L50
	sll	$3,$3,3

$L52:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	EV_StartLightStrobing
	.size	EV_StartLightStrobing, .-EV_StartLightStrobing
	.align	2
	.globl	EV_TurnTagLightsOff
	.set	nomips16
	.set	nomicromips
	.ent	EV_TurnTagLightsOff
	.type	EV_TurnTagLightsOff, @function
EV_TurnTagLightsOff:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$19,32($sp)
	lui	$19,%hi(numsectors)
	lw	$2,%lo(numsectors)($19)
	lui	$3,%hi(sectors)
	sw	$16,20($sp)
	sw	$31,44($sp)
	lw	$16,%lo(sectors)($3)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$18,28($sp)
	blez	$2,$L54
	sw	$17,24($sp)

	move	$18,$4
	b	$L55
	move	$21,$0

$L56:
	addiu	$21,$21,1
	slt	$2,$21,$2
	beq	$2,$0,$L54
	addiu	$16,$16,88

$L55:
	lh	$3,16($16)
	lh	$2,20($18)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L56
	.set	at
	lw	$2,%lo(numsectors)($19)

	lh	$20,12($16)
	lw	$3,80($16)
	blez	$3,$L57
	move	$2,$20

	move	$17,$0
$L59:
	lw	$2,84($16)
	sll	$3,$17,2
	addu	$2,$2,$3
	lw	$4,0($2)
	jal	getNextSector
	move	$5,$16

	beq	$2,$0,$L58
	addiu	$17,$17,1

	lh	$2,12($2)
	slt	$3,$2,$20
	movn	$20,$2,$3
$L58:
	lw	$2,80($16)
	slt	$2,$17,$2
	bne	$2,$0,$L59
	sll	$2,$20,16

	sra	$2,$2,16
$L57:
	sh	$2,12($16)
	lw	$2,%lo(numsectors)($19)
	addiu	$21,$21,1
	slt	$2,$21,$2
	bne	$2,$0,$L55
	addiu	$16,$16,88

$L54:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	EV_TurnTagLightsOff
	.size	EV_TurnTagLightsOff, .-EV_TurnTagLightsOff
	.align	2
	.globl	EV_LightTurnOn
	.set	nomips16
	.set	nomicromips
	.ent	EV_LightTurnOn
	.type	EV_LightTurnOn, @function
EV_LightTurnOn:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$20,36($sp)
	lui	$20,%hi(numsectors)
	lw	$2,%lo(numsectors)($20)
	lui	$3,%hi(sectors)
	sw	$16,20($sp)
	sw	$31,44($sp)
	lw	$16,%lo(sectors)($3)
	sw	$21,40($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	blez	$2,$L69
	sw	$17,24($sp)

	move	$19,$4
	move	$21,$5
	b	$L70
	move	$17,$0

$L71:
	addiu	$17,$17,1
	slt	$2,$17,$2
	beq	$2,$0,$L69
	addiu	$16,$16,88

$L70:
	lh	$3,16($16)
	lh	$2,20($19)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L71
	.set	at
	lw	$2,%lo(numsectors)($20)

	beq	$21,$0,$L86
	sll	$2,$21,16

	sra	$2,$2,16
$L73:
	sh	$2,12($16)
$L87:
	lw	$2,%lo(numsectors)($20)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L70
	addiu	$16,$16,88

$L69:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L86:
	lw	$2,80($16)
	blez	$2,$L78
	move	$18,$0

$L75:
	lw	$2,84($16)
	sll	$3,$18,2
	addu	$2,$2,$3
	lw	$4,0($2)
	jal	getNextSector
	move	$5,$16

	beq	$2,$0,$L74
	addiu	$18,$18,1

	lh	$2,12($2)
	slt	$3,$21,$2
	movn	$21,$2,$3
$L74:
	lw	$2,80($16)
	slt	$2,$18,$2
	bne	$2,$0,$L75
	sll	$2,$21,16

	b	$L73
	sra	$2,$2,16

$L78:
	move	$2,$0
	b	$L87
	sh	$2,12($16)

	.set	macro
	.set	reorder
	.end	EV_LightTurnOn
	.size	EV_LightTurnOn, .-EV_LightTurnOn
	.align	2
	.globl	P_SpawnGlowingLight
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnGlowingLight
	.type	P_SpawnGlowingLight, @function
P_SpawnGlowingLight:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	move	$6,$0
	li	$5,6			# 0x6
	sw	$17,24($sp)
	move	$17,$4
	li	$4,28			# 0x1c
	sw	$31,28($sp)
	jal	Z_Malloc
	sw	$16,20($sp)

	move	$4,$2
	jal	P_AddThinker
	move	$16,$2

	lh	$5,12($17)
	move	$4,$17
	jal	P_FindMinSurroundingLight
	sw	$17,12($16)

	lh	$3,12($17)
	sw	$2,16($16)
	lui	$2,%hi(T_Glow)
	lw	$31,28($sp)
	addiu	$2,$2,%lo(T_Glow)
	sw	$2,8($16)
	li	$2,-1			# 0xffffffffffffffff
	sw	$3,20($16)
	sw	$2,24($16)
	lw	$16,20($sp)
	sh	$0,14($17)
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_SpawnGlowingLight
	.size	P_SpawnGlowingLight, .-P_SpawnGlowingLight
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
