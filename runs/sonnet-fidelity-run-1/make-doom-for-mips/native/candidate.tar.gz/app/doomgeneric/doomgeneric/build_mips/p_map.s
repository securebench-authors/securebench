	.file	1 "p_map.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	PIT_StompThing
	.set	nomips16
	.set	nomicromips
	.ent	PIT_StompThing
	.type	PIT_StompThing, @function
PIT_StompThing:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	andi	$2,$2,0x4
	bne	$2,$0,$L13
	li	$2,1			# 0x1

	jr	$31
	nop

$L13:
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	lui	$18,%hi(tmthing)
	lw	$2,%lo(tmthing)($18)
	lui	$3,%hi(tmx)
	lw	$3,%lo(tmx)($3)
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,12($4)
	sw	$17,20($sp)
	lw	$17,64($2)
	lw	$2,64($16)
	subu	$4,$4,$3
	sw	$31,28($sp)
	jal	abs
	addu	$17,$17,$2

	slt	$2,$2,$17
	bne	$2,$0,$L14
	lui	$2,%hi(tmy)

$L3:
	li	$2,1			# 0x1
$L1:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L14:
	lw	$4,16($16)
	lw	$2,%lo(tmy)($2)
	jal	abs
	subu	$4,$4,$2

	slt	$2,$2,$17
	beq	$2,$0,$L3
	lw	$6,%lo(tmthing)($18)

	.set	noat
	xor	$1,$6,$16
	beq	$1,$0,$L1
	.set	at
	li	$2,1			# 0x1

	lw	$2,132($6)
	beq	$2,$0,$L15
	li	$7,10000			# 0x2710

$L16:
	move	$5,$6
	jal	P_DamageMobj
	move	$4,$16

	b	$L1
	li	$2,1			# 0x1

$L15:
	lui	$2,%hi(gamemap)
	lw	$3,%lo(gamemap)($2)
	li	$2,30			# 0x1e
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L16
	.set	at
	nop

	b	$L1
	move	$2,$0

	.set	macro
	.set	reorder
	.end	PIT_StompThing
	.size	PIT_StompThing, .-PIT_StompThing
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"-spechit\000"
	.align	2
$LC1:
	.ascii	"SpechitOverrun: Warning: unable to emulatean overrun whe"
	.ascii	"re numspechit=%i\012\000"
	.text
	.align	2
	.globl	PIT_CheckLine
	.set	nomips16
	.set	nomicromips
	.ent	PIT_CheckLine
	.type	PIT_CheckLine, @function
PIT_CheckLine:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lui	$3,%hi(tmbbox)
	sw	$17,24($sp)
	addiu	$17,$3,%lo(tmbbox)
	lw	$2,12($17)
	sw	$16,20($sp)
	move	$16,$4
	lw	$4,36($4)
	sw	$31,36($sp)
	slt	$2,$4,$2
	sw	$19,32($sp)
	beq	$2,$0,$L34
	sw	$18,28($sp)

	lw	$2,8($17)
	lw	$4,40($16)
	slt	$2,$2,$4
	beq	$2,$0,$L34
	lw	$2,%lo(tmbbox)($3)

	lw	$3,32($16)
	slt	$2,$3,$2
	beq	$2,$0,$L19
	li	$2,1			# 0x1

	lw	$2,4($17)
	lw	$3,28($16)
	slt	$2,$2,$3
	bne	$2,$0,$L43
	move	$5,$16

$L34:
	li	$2,1			# 0x1
$L19:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L43:
	jal	P_BoxOnLineSide
	move	$4,$17

	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L19
	.set	at
	li	$2,1			# 0x1

	lw	$2,52($16)
	beq	$2,$0,$L37
	li	$4,65536			# 0x10000

	lui	$2,%hi(tmthing)
	lw	$3,%lo(tmthing)($2)
	lw	$2,104($3)
	and	$2,$2,$4
	bne	$2,$0,$L23
	nop

	lh	$2,16($16)
	andi	$4,$2,0x1
	bne	$4,$0,$L37
	nop

	lw	$3,132($3)
	beq	$3,$0,$L44
	andi	$2,$2,0x2

$L23:
	jal	P_LineOpening
	move	$4,$16

	lui	$2,%hi(opentop)
	lui	$3,%hi(tmceilingz)
	lw	$4,%lo(opentop)($2)
	lw	$2,%lo(tmceilingz)($3)
	slt	$2,$4,$2
	beq	$2,$0,$L47
	lui	$2,%hi(openbottom)

	lui	$2,%hi(ceilingline)
	sw	$4,%lo(tmceilingz)($3)
	sw	$16,%lo(ceilingline)($2)
	lui	$2,%hi(openbottom)
$L47:
	lui	$3,%hi(tmfloorz)
	lw	$4,%lo(openbottom)($2)
	lw	$2,%lo(tmfloorz)($3)
	slt	$2,$2,$4
	beq	$2,$0,$L48
	lui	$2,%hi(lowfloor)

	sw	$4,%lo(tmfloorz)($3)
$L48:
	lui	$3,%hi(tmdropoffz)
	lw	$4,%lo(lowfloor)($2)
	lw	$2,%lo(tmdropoffz)($3)
	slt	$2,$4,$2
	beq	$2,$0,$L26
	nop

	sw	$4,%lo(tmdropoffz)($3)
$L26:
	lh	$2,18($16)
	beq	$2,$0,$L19
	li	$2,1			# 0x1

	lui	$18,%hi(numspechit)
	lw	$2,%lo(numspechit)($18)
	lui	$3,%hi(spechit)
	addiu	$6,$2,1
	addiu	$3,$3,%lo(spechit)
	sll	$2,$2,2
	addu	$2,$2,$3
	slt	$3,$6,9
	sw	$16,0($2)
	bne	$3,$0,$L34
	sw	$6,%lo(numspechit)($18)

	lui	$19,%hi(baseaddr.0)
	lw	$4,%lo(baseaddr.0)($19)
	beq	$4,$0,$L45
	li	$5,1			# 0x1

$L27:
	lui	$2,%hi(lines)
	lw	$2,%lo(lines)($2)
	li	$5,13			# 0xd
	subu	$2,$16,$2
	sra	$2,$2,6
	sll	$3,$2,5
	subu	$2,$3,$2
	sll	$2,$2,1
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L29
	.set	at
	addu	$3,$2,$4

	slt	$2,$6,14
	beq	$2,$0,$L30
	li	$2,14			# 0xe

	addiu	$2,$6,-9
	sltu	$4,$2,4
	beq	$4,$0,$L31
	nop

	sll	$2,$2,2
	addu	$2,$17,$2
	b	$L34
	sw	$3,0($2)

$L44:
	beq	$2,$0,$L23
	nop

$L37:
	b	$L19
	move	$2,$0

$L30:
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L49
	.set	at
	lui	$2,%hi(stderr)

	lui	$2,%hi(nofit)
	b	$L34
	sw	$3,%lo(nofit)($2)

$L45:
	lui	$4,%hi($LC0)
	jal	M_CheckParmWithArgs
	addiu	$4,$4,%lo($LC0)

	bgtz	$2,$L46
	addiu	$2,$2,1

	li	$4,29360128			# 0x1c00000
	ori	$4,$4,0x9c98
	lw	$6,%lo(numspechit)($18)
	b	$L27
	sw	$4,%lo(baseaddr.0)($19)

$L31:
	lui	$2,%hi(stderr)
$L49:
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC1)
	jal	fprintf
	addiu	$5,$5,%lo($LC1)

	b	$L19
	li	$2,1			# 0x1

$L29:
	lui	$2,%hi(crushchange)
	b	$L34
	sw	$3,%lo(crushchange)($2)

$L46:
	lui	$3,%hi(myargv)
	lw	$3,%lo(myargv)($3)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$4,0($2)
	jal	M_StrToInt
	addiu	$5,$19,%lo(baseaddr.0)

	lw	$4,%lo(baseaddr.0)($19)
	b	$L27
	lw	$6,%lo(numspechit)($18)

	.set	macro
	.set	reorder
	.end	PIT_CheckLine
	.size	PIT_CheckLine, .-PIT_CheckLine
	.align	2
	.globl	PIT_CheckThing
	.set	nomips16
	.set	nomicromips
	.ent	PIT_CheckThing
	.type	PIT_CheckThing, @function
PIT_CheckThing:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	andi	$2,$2,0x7
	bne	$2,$0,$L51
	li	$2,1			# 0x1

	jr	$31
	nop

$L51:
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	lui	$18,%hi(tmthing)
	lw	$2,%lo(tmthing)($18)
	lui	$3,%hi(tmx)
	lw	$3,%lo(tmx)($3)
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,12($4)
	sw	$17,20($sp)
	lw	$17,64($2)
	lw	$2,64($16)
	subu	$4,$4,$3
	sw	$31,28($sp)
	jal	abs
	addu	$17,$17,$2

	slt	$2,$2,$17
	beq	$2,$0,$L50
	li	$2,1			# 0x1

	lui	$2,%hi(tmy)
	lw	$4,16($16)
	lw	$2,%lo(tmy)($2)
	jal	abs
	subu	$4,$4,$2

	slt	$2,$2,$17
	beq	$2,$0,$L53
	lw	$5,%lo(tmthing)($18)

	.set	noat
	xor	$1,$5,$16
	beq	$1,$0,$L53
	.set	at
	li	$3,16777216			# 0x1000000

	lw	$2,104($5)
	and	$3,$2,$3
	bne	$3,$0,$L81
	li	$3,65536			# 0x10000

	and	$2,$2,$3
	beq	$2,$0,$L57
	nop

	lw	$3,20($16)
	lw	$2,68($16)
	lw	$4,20($5)
	addu	$2,$3,$2
	slt	$2,$2,$4
	bne	$2,$0,$L50
	li	$2,1			# 0x1

	lw	$2,68($5)
	addu	$4,$4,$2
	slt	$3,$4,$3
	bne	$3,$0,$L50
	li	$2,1			# 0x1

	lw	$2,120($5)
	beq	$2,$0,$L58
	nop

	lw	$3,88($2)
	lw	$4,88($16)
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L59
	.set	at
	li	$5,17			# 0x11

	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L82
	.set	at
	li	$6,15			# 0xf

	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L58
	.set	at
	nop

	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L84
	.set	at
	xor	$2,$2,$16

$L58:
	lw	$2,104($16)
	andi	$3,$2,0x4
	bne	$3,$0,$L62
	andi	$2,$2,0x2

	b	$L50
	sltu	$2,$2,1

$L53:
	li	$2,1			# 0x1
$L50:
	lw	$31,28($sp)
$L86:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L57:
	lw	$17,104($16)
	andi	$2,$17,0x1
	bne	$2,$0,$L83
	nop

$L64:
	andi	$2,$17,0x2
	b	$L50
	sltu	$2,$2,1

$L83:
	lui	$2,%hi(tmflags)
	lw	$2,%lo(tmflags)($2)
	andi	$2,$2,0x800
	beq	$2,$0,$L64
	nop

	jal	P_TouchSpecialThing
	move	$4,$16

	andi	$2,$17,0x2
	b	$L50
	sltu	$2,$2,1

$L81:
	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,7
	and	$2,$2,$3
	bgez	$2,$L55
	lw	$6,%lo(tmthing)($18)

	addiu	$2,$2,-1
	li	$3,-8			# 0xfffffffffffffff8
	or	$2,$2,$3
	addiu	$2,$2,1
$L55:
	lw	$3,92($6)
	addiu	$2,$2,1
	lw	$7,76($3)
	move	$5,$6
	multu	$2,$7
	mflo	$7
	jal	P_DamageMobj
	move	$4,$16

	lw	$4,%lo(tmthing)($18)
	li	$3,-16842752			# 0xfffffffffeff0000
	lw	$2,104($4)
	lw	$5,92($4)
	ori	$3,$3,0xffff
	lw	$5,4($5)
	and	$2,$2,$3
	sw	$2,104($4)
	sw	$0,80($4)
	sw	$0,76($4)
	jal	P_SetMobjState
	sw	$0,72($4)

	b	$L50
	move	$2,$0

$L62:
	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,7
	and	$2,$2,$3
	bgez	$2,$L63
	lw	$5,%lo(tmthing)($18)

	addiu	$2,$2,-1
	li	$3,-8			# 0xfffffffffffffff8
	or	$2,$2,$3
	addiu	$2,$2,1
$L63:
	lw	$3,92($5)
	addiu	$2,$2,1
	lw	$7,76($3)
	lw	$6,120($5)
	multu	$2,$7
	mflo	$7
	jal	P_DamageMobj
	move	$4,$16

	b	$L50
	move	$2,$0

$L59:
	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L53
	.set	at
	nop

	beq	$4,$0,$L58
	move	$2,$0

	b	$L86
	lw	$31,28($sp)

$L82:
	li	$3,15			# 0xf
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L58
	.set	at
	xor	$2,$2,$16

$L84:
	b	$L50
	sltu	$2,$2,1

	.set	macro
	.set	reorder
	.end	PIT_CheckThing
	.size	PIT_CheckThing, .-PIT_CheckThing
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"PTR_SlideTraverse: not a line?\000"
	.text
	.align	2
	.globl	PTR_SlideTraverse
	.set	nomips16
	.set	nomicromips
	.ent	PTR_SlideTraverse
	.type	PTR_SlideTraverse, @function
PTR_SlideTraverse:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,4($4)
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	sw	$31,28($sp)
	sw	$17,24($sp)
	beq	$2,$0,$L97
	move	$16,$4

	lw	$17,8($16)
$L98:
	lhu	$2,16($17)
	andi	$2,$2,0x4
	bne	$2,$0,$L90
	lui	$2,%hi(slidemo)

	lw	$2,%lo(slidemo)($2)
	move	$6,$17
	lw	$5,16($2)
	jal	P_PointOnLineSide
	lw	$4,12($2)

	beq	$2,$0,$L99
	lui	$2,%hi(bestslidefrac)

	lw	$31,28($sp)
$L100:
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

$L90:
	jal	P_LineOpening
	move	$4,$17

	lui	$2,%hi(slidemo)
	lw	$4,%lo(slidemo)($2)
	lui	$2,%hi(openrange)
	lw	$3,68($4)
	lw	$2,%lo(openrange)($2)
	slt	$2,$2,$3
	bne	$2,$0,$L94
	lui	$2,%hi(opentop)

	lw	$4,20($4)
	lw	$2,%lo(opentop)($2)
	subu	$2,$2,$4
	slt	$3,$2,$3
	bne	$3,$0,$L94
	lui	$2,%hi(openbottom)

	lw	$2,%lo(openbottom)($2)
	li	$3,1572864			# 0x180000
	subu	$2,$2,$4
	addiu	$3,$3,1
	slt	$2,$2,$3
	bne	$2,$0,$L100
	lw	$31,28($sp)

$L94:
	lui	$2,%hi(bestslidefrac)
$L99:
	lw	$3,0($16)
	lw	$4,%lo(bestslidefrac)($2)
	slt	$5,$3,$4
	bne	$5,$0,$L92
	lui	$5,%hi(bestslideline)

$L95:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L92:
	lw	$6,%lo(bestslideline)($5)
	lui	$7,%hi(secondslidefrac)
	sw	$4,%lo(secondslidefrac)($7)
	lui	$4,%hi(secondslideline)
	sw	$6,%lo(secondslideline)($4)
	sw	$3,%lo(bestslidefrac)($2)
	b	$L95
	sw	$17,%lo(bestslideline)($5)

$L97:
	lui	$4,%hi($LC2)
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	b	$L98
	lw	$17,8($16)

	.set	macro
	.set	reorder
	.end	PTR_SlideTraverse
	.size	PTR_SlideTraverse, .-PTR_SlideTraverse
	.align	2
	.globl	PTR_AimTraverse
	.set	nomips16
	.set	nomicromips
	.ent	PTR_AimTraverse
	.type	PTR_AimTraverse, @function
PTR_AimTraverse:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,4($4)
	addiu	$sp,$sp,-40
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$17,8($4)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	beq	$2,$0,$L102
	move	$16,$4

	lhu	$2,16($17)
	andi	$2,$2,0x4
	bne	$2,$0,$L127
	lui	$19,%hi(openbottom)

	b	$L101
	move	$2,$0

$L127:
	move	$4,$17
	jal	P_LineOpening
	lui	$18,%hi(opentop)

	lw	$2,%lo(openbottom)($19)
	lw	$3,%lo(opentop)($18)
	slt	$2,$2,$3
	beq	$2,$0,$L101
	move	$2,$0

	lui	$2,%hi(attackrange)
	lw	$5,0($16)
	jal	FixedMul
	lw	$4,%lo(attackrange)($2)

	lw	$3,52($17)
	beq	$3,$0,$L106
	move	$16,$2

	lw	$2,48($17)
	lw	$4,0($3)
	lw	$5,0($2)
	.set	noat
	xor	$1,$5,$4
	beq	$1,$0,$L128
	.set	at
	nop

$L106:
	lui	$20,%hi(shootz)
	lw	$4,%lo(openbottom)($19)
	lw	$2,%lo(shootz)($20)
	move	$5,$16
	subu	$4,$4,$2
	jal	FixedDiv
	lui	$19,%hi(bottomslope)

	lw	$3,%lo(bottomslope)($19)
	slt	$3,$3,$2
	bne	$3,$0,$L129
	nop

$L108:
	lw	$3,52($17)
	beq	$3,$0,$L132
	lw	$4,%lo(opentop)($18)

	lw	$2,48($17)
$L107:
	lw	$4,4($2)
	lw	$2,4($3)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L125
	.set	at
	lui	$20,%hi(shootz)

	lw	$4,%lo(opentop)($18)
$L132:
	lw	$2,%lo(shootz)($20)
	move	$5,$16
	jal	FixedDiv
	subu	$4,$4,$2

	lui	$4,%hi(topslope)
	lw	$3,%lo(topslope)($4)
	slt	$5,$2,$3
	beq	$5,$0,$L110
	nop

	sw	$2,%lo(topslope)($4)
	move	$3,$2
$L110:
	lw	$2,%lo(bottomslope)($19)
	slt	$2,$2,$3
$L131:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L102:
	lui	$2,%hi(shootthing)
	lw	$2,%lo(shootthing)($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L101
	.set	at
	li	$2,1			# 0x1

	lw	$2,104($17)
	andi	$2,$2,0x4
	beq	$2,$0,$L101
	li	$2,1			# 0x1

	lui	$2,%hi(attackrange)
	lw	$5,0($4)
	lw	$4,%lo(attackrange)($2)
	jal	FixedMul
	lui	$19,%hi(shootz)

	lw	$5,68($17)
	lw	$3,20($17)
	lw	$4,%lo(shootz)($19)
	addu	$3,$3,$5
	subu	$4,$3,$4
	move	$5,$2
	lui	$20,%hi(bottomslope)
	jal	FixedDiv
	move	$18,$2

	lw	$3,%lo(bottomslope)($20)
	slt	$3,$2,$3
	beq	$3,$0,$L130
	move	$16,$2

$L113:
	li	$2,1			# 0x1
$L101:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L130:
	lw	$4,20($17)
	lw	$2,%lo(shootz)($19)
	move	$5,$18
	jal	FixedDiv
	subu	$4,$4,$2

	lui	$3,%hi(topslope)
	lw	$4,%lo(topslope)($3)
	slt	$3,$4,$2
	bne	$3,$0,$L113
	lw	$3,%lo(bottomslope)($20)

	slt	$5,$16,$4
	slt	$6,$3,$2
	movn	$3,$2,$6
	movn	$4,$16,$5
	addu	$2,$3,$4
	srl	$3,$2,31
	addu	$2,$3,$2
	sra	$2,$2,1
	lui	$3,%hi(aimslope)
	sw	$2,%lo(aimslope)($3)
	lui	$2,%hi(linetarget)
	sw	$17,%lo(linetarget)($2)
	b	$L101
	move	$2,$0

$L129:
	b	$L108
	sw	$2,%lo(bottomslope)($19)

$L125:
	lui	$2,%hi(topslope)
	lw	$3,%lo(topslope)($2)
	lw	$2,%lo(bottomslope)($19)
	b	$L131
	slt	$2,$2,$3

$L128:
	b	$L107
	lui	$19,%hi(bottomslope)

	.set	macro
	.set	reorder
	.end	PTR_AimTraverse
	.size	PTR_AimTraverse, .-PTR_AimTraverse
	.align	2
	.globl	PTR_ShootTraverse
	.set	nomips16
	.set	nomicromips
	.ent	PTR_ShootTraverse
	.type	PTR_ShootTraverse, @function
PTR_ShootTraverse:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,4($4)
	addiu	$sp,$sp,-56
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$17,8($4)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	beq	$2,$0,$L134
	move	$16,$4

	lh	$2,18($17)
	bne	$2,$0,$L162
	lui	$2,%hi(shootthing)

	lhu	$2,16($17)
$L167:
	andi	$2,$2,0x4
	bne	$2,$0,$L136
	lui	$23,%hi(aimslope)

	lui	$19,%hi(attackrange)
	lui	$20,%hi(shootz)
	lw	$5,%lo(attackrange)($19)
$L172:
	li	$4,262144			# 0x40000
	jal	FixedDiv
	lw	$16,0($16)

	lui	$3,%hi(trace)
	addiu	$18,$3,%lo(trace)
	subu	$16,$16,$2
	lw	$4,8($18)
	move	$5,$16
	jal	FixedMul
	lw	$21,%lo(trace)($3)

	lw	$4,12($18)
	move	$5,$16
	lw	$22,4($18)
	jal	FixedMul
	move	$18,$2

	lw	$5,%lo(attackrange)($19)
	move	$4,$16
	lw	$23,%lo(aimslope)($23)
	jal	FixedMul
	move	$16,$2

	move	$5,$2
	jal	FixedMul
	move	$4,$23

	lw	$3,48($17)
	lui	$4,%hi(skyflatnum)
	lw	$6,%lo(shootz)($20)
	lw	$5,%lo(skyflatnum)($4)
	lh	$4,10($3)
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L138
	.set	at
	addu	$6,$2,$6

	lw	$2,4($3)
	slt	$2,$2,$6
	bne	$2,$0,$L168
	lw	$31,52($sp)

	lw	$2,52($17)
	beq	$2,$0,$L170
	addu	$5,$22,$16

	lh	$2,10($2)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L171
	.set	at
	lw	$fp,48($sp)

$L138:
	addu	$5,$22,$16
$L170:
	jal	P_SpawnPuff
	addu	$4,$21,$18

$L145:
	lw	$31,52($sp)
$L168:
	lw	$fp,48($sp)
$L171:
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,56

$L134:
	lui	$18,%hi(shootthing)
	lw	$2,%lo(shootthing)($18)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L166
	.set	at
	li	$2,1			# 0x1

	lw	$2,104($17)
	andi	$2,$2,0x4
	beq	$2,$0,$L166
	li	$2,1			# 0x1

	lui	$20,%hi(attackrange)
	lw	$5,0($4)
	lw	$4,%lo(attackrange)($20)
	jal	FixedMul
	lui	$19,%hi(shootz)

	lw	$5,68($17)
	lw	$3,20($17)
	lw	$4,%lo(shootz)($19)
	addu	$3,$3,$5
	subu	$4,$3,$4
	move	$5,$2
	lui	$22,%hi(aimslope)
	jal	FixedDiv
	move	$21,$2

	lw	$3,%lo(aimslope)($22)
	slt	$3,$2,$3
	beq	$3,$0,$L163
	lw	$2,%lo(shootz)($19)

$L143:
	li	$2,1			# 0x1
$L166:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L136:
	move	$4,$17
	jal	P_LineOpening
	lui	$19,%hi(attackrange)

	lw	$5,0($16)
	jal	FixedMul
	lw	$4,%lo(attackrange)($19)

	lw	$3,52($17)
	beq	$3,$0,$L164
	move	$18,$2

	lw	$2,48($17)
	lw	$4,0($3)
	lw	$5,0($2)
	.set	noat
	xor	$1,$5,$4
	bne	$1,$0,$L165
	.set	at
	lui	$20,%hi(shootz)

$L142:
	lw	$4,4($2)
	lw	$2,4($3)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L143
	.set	at
	lui	$2,%hi(opentop)

	lui	$20,%hi(shootz)
	lw	$4,%lo(opentop)($2)
	lw	$2,%lo(shootz)($20)
	move	$5,$18
	subu	$4,$4,$2
	jal	FixedDiv
	lui	$23,%hi(aimslope)

	lw	$3,%lo(aimslope)($23)
	slt	$3,$2,$3
	bne	$3,$0,$L172
	lw	$5,%lo(attackrange)($19)

	b	$L166
	li	$2,1			# 0x1

$L162:
	lw	$4,%lo(shootthing)($2)
	jal	P_ShootSpecialLine
	move	$5,$17

	b	$L167
	lhu	$2,16($17)

$L165:
	lui	$2,%hi(openbottom)
	lw	$4,%lo(openbottom)($2)
	lw	$2,%lo(shootz)($20)
	move	$5,$18
	subu	$4,$4,$2
	jal	FixedDiv
	lui	$23,%hi(aimslope)

	lw	$3,%lo(aimslope)($23)
	slt	$3,$3,$2
	bne	$3,$0,$L172
	lw	$5,%lo(attackrange)($19)

	lw	$2,48($17)
	b	$L142
	lw	$3,52($17)

$L163:
	lw	$4,20($17)
	move	$5,$21
	jal	FixedDiv
	subu	$4,$4,$2

	lw	$3,%lo(aimslope)($22)
	slt	$3,$3,$2
	bne	$3,$0,$L166
	li	$2,1			# 0x1

	lw	$5,%lo(attackrange)($20)
	li	$4,655360			# 0xa0000
	jal	FixedDiv
	lw	$21,0($16)

	lui	$3,%hi(trace)
	addiu	$fp,$3,%lo(trace)
	subu	$21,$21,$2
	lw	$4,8($fp)
	move	$5,$21
	jal	FixedMul
	lw	$23,%lo(trace)($3)

	lw	$4,12($fp)
	move	$5,$21
	lw	$fp,4($fp)
	jal	FixedMul
	addu	$23,$23,$2

	lw	$5,%lo(attackrange)($20)
	lw	$22,%lo(aimslope)($22)
	move	$4,$21
	jal	FixedMul
	addu	$fp,$fp,$2

	move	$5,$2
	jal	FixedMul
	move	$4,$22

	lw	$3,8($16)
	lw	$4,%lo(shootz)($19)
	lw	$3,104($3)
	li	$5,524288			# 0x80000
	and	$3,$3,$5
	beq	$3,$0,$L147
	addu	$6,$2,$4

	move	$5,$fp
	jal	P_SpawnPuff
	move	$4,$23

	lui	$16,%hi(la_damage)
	lw	$7,%lo(la_damage)($16)
$L169:
	beq	$7,$0,$L145
	lw	$6,%lo(shootthing)($18)

	move	$4,$17
	jal	P_DamageMobj
	move	$5,$6

	b	$L168
	lw	$31,52($sp)

$L164:
	lui	$2,%hi(openbottom)
	lui	$20,%hi(shootz)
	lw	$4,%lo(openbottom)($2)
	lw	$2,%lo(shootz)($20)
	move	$5,$18
	subu	$4,$4,$2
	jal	FixedDiv
	lui	$23,%hi(aimslope)

	lw	$3,%lo(aimslope)($23)
	slt	$3,$3,$2
	bne	$3,$0,$L172
	lw	$5,%lo(attackrange)($19)

	lui	$2,%hi(opentop)
	lw	$4,%lo(opentop)($2)
	lw	$2,%lo(shootz)($20)
	move	$5,$18
	jal	FixedDiv
	subu	$4,$4,$2

	lw	$3,%lo(aimslope)($23)
	slt	$3,$2,$3
	bne	$3,$0,$L172
	lw	$5,%lo(attackrange)($19)

	b	$L166
	li	$2,1			# 0x1

$L147:
	lui	$16,%hi(la_damage)
	lw	$7,%lo(la_damage)($16)
	move	$5,$fp
	jal	P_SpawnBlood
	move	$4,$23

	b	$L169
	lw	$7,%lo(la_damage)($16)

	.set	macro
	.set	reorder
	.end	PTR_ShootTraverse
	.size	PTR_ShootTraverse, .-PTR_ShootTraverse
	.align	2
	.globl	PTR_UseTraverse
	.set	nomips16
	.set	nomicromips
	.ent	PTR_UseTraverse
	.type	PTR_UseTraverse, @function
PTR_UseTraverse:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	lw	$4,8($4)
	sw	$31,28($sp)
	lh	$2,18($4)
	bne	$2,$0,$L174
	sw	$17,24($sp)

	jal	P_LineOpening
	nop

	lui	$2,%hi(openrange)
	lw	$2,%lo(openrange)($2)
	blez	$2,$L179
	lw	$17,24($sp)

	lw	$31,28($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

$L174:
	lui	$17,%hi(usething)
	lw	$2,%lo(usething)($17)
	move	$6,$4
	lw	$5,16($2)
	jal	P_PointOnLineSide
	lw	$4,12($2)

	xori	$6,$2,0x1
	lw	$5,8($16)
	lw	$4,%lo(usething)($17)
	jal	P_UseSpecialLine
	sltu	$6,$6,1

	lw	$31,28($sp)
$L180:
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L179:
	lui	$2,%hi(usething)
	lw	$4,%lo(usething)($2)
	jal	S_StartSound
	li	$5,81			# 0x51

	b	$L180
	lw	$31,28($sp)

	.set	macro
	.set	reorder
	.end	PTR_UseTraverse
	.size	PTR_UseTraverse, .-PTR_UseTraverse
	.align	2
	.globl	PIT_RadiusAttack
	.set	nomips16
	.set	nomicromips
	.ent	PIT_RadiusAttack
	.type	PIT_RadiusAttack, @function
PIT_RadiusAttack:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	andi	$2,$2,0x4
	beq	$2,$0,$L189
	li	$3,21			# 0x15

	lw	$2,88($4)
	addiu	$sp,$sp,-40
	sw	$16,16($sp)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L183
	.set	at
	move	$16,$4

	li	$3,19			# 0x13
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L183
	.set	at
	lui	$18,%hi(bombspot)

	lw	$2,%lo(bombspot)($18)
	lw	$4,12($4)
	lw	$2,12($2)
	lui	$20,%hi(bombdamage)
	jal	abs
	subu	$4,$4,$2

	lw	$3,%lo(bombspot)($18)
	lw	$4,16($16)
	lw	$3,16($3)
	move	$17,$2
	jal	abs
	subu	$4,$4,$3

	slt	$4,$17,$2
	lw	$3,64($16)
	movn	$17,$2,$4
	subu	$17,$17,$3
	sra	$19,$17,16
	lw	$2,%lo(bombdamage)($20)
	slt	$17,$17,0
	movn	$19,$0,$17
	slt	$2,$19,$2
	bne	$2,$0,$L192
	lw	$5,%lo(bombspot)($18)

$L183:
	lw	$31,36($sp)
$L193:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,40

$L189:
	jr	$31
	li	$2,1			# 0x1

$L192:
	jal	P_CheckSight
	move	$4,$16

	beq	$2,$0,$L183
	lw	$7,%lo(bombdamage)($20)

	lui	$2,%hi(bombsource)
	lw	$6,%lo(bombsource)($2)
	lw	$5,%lo(bombspot)($18)
	subu	$7,$7,$19
	jal	P_DamageMobj
	move	$4,$16

	b	$L193
	lw	$31,36($sp)

	.set	macro
	.set	reorder
	.end	PIT_RadiusAttack
	.size	PIT_RadiusAttack, .-PIT_RadiusAttack
	.align	2
	.globl	P_TeleportMove
	.set	nomips16
	.set	nomicromips
	.ent	P_TeleportMove
	.type	P_TeleportMove, @function
P_TeleportMove:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	lw	$9,104($4)
	lui	$8,%hi(tmthing)
	sw	$23,60($sp)
	move	$23,$4
	lw	$2,64($4)
	sw	$23,%lo(tmthing)($8)
	lui	$8,%hi(tmflags)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$17,36($sp)
	move	$22,$5
	lui	$17,%hi(tmbbox)
	move	$21,$6
	sw	$9,%lo(tmflags)($8)
	lui	$8,%hi(tmx)
	sw	$16,32($sp)
	addu	$7,$2,$6
	addiu	$16,$17,%lo(tmbbox)
	addu	$3,$2,$5
	subu	$6,$6,$2
	move	$4,$22
	subu	$2,$5,$2
	sw	$22,%lo(tmx)($8)
	move	$5,$21
	lui	$8,%hi(tmy)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$18,40($sp)
	sw	$7,%lo(tmbbox)($17)
	sw	$6,4($16)
	sw	$3,12($16)
	sw	$21,%lo(tmy)($8)
	jal	R_PointInSubsector
	sw	$2,8($16)

	lui	$3,%hi(bmaporgx)
	lw	$11,%lo(bmaporgx)($3)
	lui	$3,%hi(bmaporgy)
	lw	$5,12($16)
	lw	$10,%lo(bmaporgy)($3)
	lw	$4,4($16)
	lw	$6,8($16)
	lw	$3,%lo(tmbbox)($17)
	lui	$8,%hi(validcount)
	lw	$9,0($2)
	lw	$2,%lo(validcount)($8)
	li	$7,2097152			# 0x200000
	subu	$16,$6,$11
	subu	$20,$5,$11
	subu	$19,$4,$10
	li	$5,-2097152			# 0xffffffffffe00000
	subu	$17,$3,$10
	addu	$16,$16,$5
	addu	$20,$20,$7
	subu	$19,$19,$7
	addu	$17,$17,$7
	addiu	$2,$2,1
	lw	$3,0($9)
	lw	$5,4($9)
	lui	$6,%hi(ceilingline)
	sra	$16,$16,23
	sra	$20,$20,23
	sra	$19,$19,23
	sra	$17,$17,23
	sw	$2,%lo(validcount)($8)
	lui	$2,%hi(numspechit)
	lui	$7,%hi(tmfloorz)
	lui	$9,%hi(tmceilingz)
	sw	$0,%lo(ceilingline)($6)
	sw	$0,%lo(numspechit)($2)
	lui	$6,%hi(tmdropoffz)
	slt	$2,$17,$19
	slt	$4,$20,$16
	sw	$7,20($sp)
	sw	$9,24($sp)
	sw	$3,%lo(tmdropoffz)($6)
	sw	$3,%lo(tmfloorz)($7)
	sw	$5,%lo(tmceilingz)($9)
	bne	$4,$0,$L196
	sw	$2,16($sp)

	lui	$18,%hi(PIT_StompThing)
	addiu	$18,$18,%lo(PIT_StompThing)
	lw	$2,16($sp)
$L210:
	beq	$2,$0,$L198
	move	$fp,$19

	b	$L209
	addiu	$16,$16,1

$L208:
	bne	$3,$0,$L199
	nop

$L198:
	move	$5,$fp
	move	$6,$18
	jal	P_BlockThingsIterator
	move	$4,$16

	addiu	$fp,$fp,1
	bne	$2,$0,$L208
	slt	$3,$17,$fp

	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L199:
	addiu	$16,$16,1
$L209:
	slt	$2,$20,$16
	beq	$2,$0,$L210
	lw	$2,16($sp)

$L196:
	jal	P_UnsetThingPosition
	move	$4,$23

	lw	$2,20($sp)
	sw	$22,12($23)
	lw	$3,%lo(tmfloorz)($2)
	lw	$2,24($sp)
	sw	$21,16($23)
	lw	$2,%lo(tmceilingz)($2)
	sw	$3,56($23)
	sw	$2,60($23)
	jal	P_SetThingPosition
	move	$4,$23

	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	P_TeleportMove
	.size	P_TeleportMove, .-P_TeleportMove
	.align	2
	.globl	P_CheckPosition
	.set	nomips16
	.set	nomicromips
	.ent	P_CheckPosition
	.type	P_CheckPosition, @function
P_CheckPosition:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	lw	$2,64($4)
	move	$3,$4
	lui	$10,%hi(tmthing)
	move	$4,$5
	sw	$21,44($sp)
	lw	$9,104($3)
	lui	$21,%hi(tmbbox)
	sw	$3,%lo(tmthing)($10)
	lui	$3,%hi(tmx)
	sw	$19,36($sp)
	sw	$16,24($sp)
	subu	$7,$6,$2
	move	$5,$6
	addu	$8,$2,$6
	addiu	$19,$21,%lo(tmbbox)
	addu	$6,$2,$4
	sw	$4,%lo(tmx)($3)
	subu	$2,$4,$2
	lui	$3,%hi(tmy)
	lui	$16,%hi(tmflags)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$20,40($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$5,%lo(tmy)($3)
	sw	$7,4($19)
	sw	$6,12($19)
	sw	$9,%lo(tmflags)($16)
	sw	$8,%lo(tmbbox)($21)
	jal	R_PointInSubsector
	sw	$2,8($19)

	lw	$6,0($2)
	lui	$4,%hi(validcount)
	lw	$5,0($6)
	lw	$3,%lo(validcount)($4)
	lui	$7,%hi(ceilingline)
	lw	$2,%lo(tmflags)($16)
	sw	$0,%lo(ceilingline)($7)
	lui	$7,%hi(tmdropoffz)
	addiu	$3,$3,1
	sw	$5,%lo(tmdropoffz)($7)
	lw	$6,4($6)
	lui	$7,%hi(tmfloorz)
	sw	$5,%lo(tmfloorz)($7)
	sw	$3,%lo(validcount)($4)
	lui	$5,%hi(tmceilingz)
	lui	$3,%hi(numspechit)
	andi	$2,$2,0x1000
	sw	$6,%lo(tmceilingz)($5)
	bne	$2,$0,$L212
	sw	$0,%lo(numspechit)($3)

	lui	$2,%hi(bmaporgx)
	lw	$7,%lo(bmaporgx)($2)
	lui	$3,%hi(bmaporgy)
	lw	$5,12($19)
	sw	$2,16($sp)
	lw	$2,8($19)
	lw	$6,%lo(bmaporgy)($3)
	lw	$4,4($19)
	sw	$3,20($sp)
	lw	$3,%lo(tmbbox)($21)
	li	$17,2097152			# 0x200000
	subu	$2,$2,$7
	subu	$5,$5,$7
	li	$16,-2097152			# 0xffffffffffe00000
	addu	$22,$5,$17
	subu	$4,$4,$6
	subu	$3,$3,$6
	addu	$16,$2,$16
	subu	$20,$4,$17
	sra	$16,$16,23
	sra	$22,$22,23
	addu	$17,$3,$17
	sra	$20,$20,23
	sra	$17,$17,23
	slt	$6,$22,$16
	bne	$6,$0,$L214
	slt	$23,$17,$20

	lui	$18,%hi(PIT_CheckThing)
	addiu	$18,$18,%lo(PIT_CheckThing)
$L213:
	beq	$23,$0,$L217
	move	$fp,$20

	b	$L237
	addiu	$16,$16,1

$L215:
	bne	$4,$0,$L218
	nop

$L217:
	move	$5,$fp
	move	$4,$16
	move	$6,$18
	jal	P_BlockThingsIterator
	addiu	$fp,$fp,1

	bne	$2,$0,$L215
	slt	$4,$17,$fp

	lw	$31,60($sp)
$L239:
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,64

$L218:
	addiu	$16,$16,1
$L237:
	slt	$2,$22,$16
	beq	$2,$0,$L213
	lw	$2,16($sp)

	lw	$5,12($19)
	lw	$7,%lo(bmaporgx)($2)
	lw	$2,20($sp)
	lw	$4,4($19)
	lw	$6,%lo(bmaporgy)($2)
	lw	$3,%lo(tmbbox)($21)
	lw	$2,8($19)
	subu	$5,$5,$7
	subu	$2,$2,$7
	subu	$4,$4,$6
	subu	$3,$3,$6
$L214:
	sra	$19,$2,23
	sra	$20,$5,23
	sra	$18,$4,23
	sra	$17,$3,23
	slt	$2,$20,$19
	bne	$2,$0,$L212
	slt	$22,$17,$18

	lui	$21,%hi(PIT_CheckLine)
	addiu	$21,$21,%lo(PIT_CheckLine)
$L219:
	beq	$22,$0,$L221
	move	$16,$18

	b	$L238
	addiu	$19,$19,1

$L236:
	bne	$3,$0,$L222
	nop

$L221:
	move	$5,$16
	move	$6,$21
	move	$4,$19
	jal	P_BlockLinesIterator
	addiu	$16,$16,1

	bne	$2,$0,$L236
	slt	$3,$17,$16

	b	$L239
	lw	$31,60($sp)

$L222:
	addiu	$19,$19,1
$L238:
	slt	$2,$20,$19
	beq	$2,$0,$L219
	nop

$L212:
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	P_CheckPosition
	.size	P_CheckPosition, .-P_CheckPosition
	.align	2
	.globl	P_TryMove
	.set	nomips16
	.set	nomicromips
	.ent	P_TryMove
	.type	P_TryMove, @function
P_TryMove:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$18,28($sp)
	lui	$18,%hi(floatok)
	sw	$21,40($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	move	$16,$4
	move	$17,$5
	move	$21,$6
	jal	P_CheckPosition
	sw	$0,%lo(floatok)($18)

	beq	$2,$0,$L262
	lw	$31,52($sp)

	lw	$2,104($16)
	andi	$3,$2,0x1000
	bne	$3,$0,$L261
	lui	$19,%hi(tmceilingz)

	lui	$20,%hi(tmfloorz)
	lw	$6,%lo(tmceilingz)($19)
	lw	$4,%lo(tmfloorz)($20)
	lw	$5,68($16)
	subu	$3,$6,$4
	slt	$3,$3,$5
	bne	$3,$0,$L262
	andi	$3,$2,0x8000

	li	$7,1			# 0x1
	bne	$3,$0,$L245
	sw	$7,%lo(floatok)($18)

	lw	$3,20($16)
	subu	$6,$6,$3
	slt	$5,$6,$5
	bne	$5,$0,$L241
	li	$5,1572864			# 0x180000

	subu	$3,$4,$3
	addiu	$5,$5,1
	slt	$3,$3,$5
	beq	$3,$0,$L262
	lw	$31,52($sp)

$L245:
	andi	$2,$2,0x4400
	bne	$2,$0,$L246
	lui	$2,%hi(tmdropoffz)

	lw	$2,%lo(tmdropoffz)($2)
	subu	$4,$4,$2
	li	$2,1572864			# 0x180000
	addiu	$2,$2,1
	slt	$4,$4,$2
	bne	$4,$0,$L246
	nop

$L241:
	lw	$31,52($sp)
$L262:
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,56

$L261:
	lui	$20,%hi(tmfloorz)
$L246:
	jal	P_UnsetThingPosition
	move	$4,$16

	lw	$2,%lo(tmceilingz)($19)
	lw	$3,%lo(tmfloorz)($20)
	lw	$19,12($16)
	lw	$20,16($16)
	sw	$2,60($16)
	sw	$3,56($16)
	sw	$17,12($16)
	sw	$21,16($16)
	jal	P_SetThingPosition
	move	$4,$16

	lw	$2,104($16)
	andi	$2,$2,0x9000
	bne	$2,$0,$L263
	lw	$31,52($sp)

	lui	$17,%hi(numspechit)
	lw	$3,%lo(numspechit)($17)
	addiu	$2,$3,-1
	beq	$3,$0,$L244
	sw	$2,%lo(numspechit)($17)

	lui	$18,%hi(spechit)
	addiu	$18,$18,%lo(spechit)
	b	$L249
	lui	$21,%hi(lines)

$L248:
	lw	$3,%lo(numspechit)($17)
$L264:
	addiu	$2,$3,-1
	beq	$3,$0,$L244
	sw	$2,%lo(numspechit)($17)

$L249:
	sll	$2,$2,2
	addu	$2,$18,$2
	lw	$22,0($2)
	lw	$5,16($16)
	lw	$4,12($16)
	jal	P_PointOnLineSide
	move	$6,$22

	move	$5,$20
	move	$6,$22
	move	$4,$19
	jal	P_PointOnLineSide
	move	$23,$2

	.set	noat
	xor	$1,$23,$2
	beq	$1,$0,$L248
	.set	at
	move	$5,$2

	lh	$2,18($22)
	beq	$2,$0,$L264
	lw	$3,%lo(numspechit)($17)

	lw	$2,%lo(lines)($21)
	move	$6,$16
	subu	$4,$22,$2
	jal	P_CrossSpecialLine
	sra	$4,$4,6

	lw	$3,%lo(numspechit)($17)
	addiu	$2,$3,-1
	bne	$3,$0,$L249
	sw	$2,%lo(numspechit)($17)

$L244:
	lw	$31,52($sp)
$L263:
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	P_TryMove
	.size	P_TryMove, .-P_TryMove
	.align	2
	.globl	P_ThingHeightClip
	.set	nomips16
	.set	nomicromips
	.ent	P_ThingHeightClip
	.type	P_ThingHeightClip, @function
P_ThingHeightClip:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$5,12($4)
	lw	$6,16($4)
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	lw	$18,20($4)
	lw	$17,56($4)
	sw	$16,16($sp)
	sw	$31,28($sp)
	jal	P_CheckPosition
	move	$16,$4

	lui	$2,%hi(tmfloorz)
	lw	$4,%lo(tmfloorz)($2)
	lui	$2,%hi(tmceilingz)
	lw	$2,%lo(tmceilingz)($2)
	lw	$5,68($16)
	sw	$4,56($16)
	.set	noat
	xor	$1,$18,$17
	beq	$1,$0,$L271
	.set	at
	sw	$2,60($16)

	lw	$3,20($16)
	addu	$3,$5,$3
	slt	$3,$2,$3
	beq	$3,$0,$L272
	lw	$31,28($sp)

	subu	$3,$2,$5
	sw	$3,20($16)
	lw	$31,28($sp)
$L272:
	subu	$2,$2,$4
	slt	$2,$2,$5
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	xori	$2,$2,0x1
	jr	$31
	addiu	$sp,$sp,32

$L271:
	lw	$31,28($sp)
	subu	$2,$2,$4
	slt	$2,$2,$5
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$4,20($16)
	xori	$2,$2,0x1
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_ThingHeightClip
	.size	P_ThingHeightClip, .-P_ThingHeightClip
	.align	2
	.globl	PIT_ChangeSector
	.set	nomips16
	.set	nomicromips
	.ent	PIT_ChangeSector
	.type	PIT_ChangeSector, @function
PIT_ChangeSector:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	sw	$31,28($sp)
	sw	$17,24($sp)
	jal	P_ThingHeightClip
	move	$16,$4

	bne	$2,$0,$L289
	lw	$31,28($sp)

	lw	$2,108($16)
	blez	$2,$L286
	li	$5,895			# 0x37f

	lw	$2,104($16)
	li	$3,131072			# 0x20000
	and	$3,$2,$3
	bne	$3,$0,$L287
	andi	$2,$2,0x4

	beq	$2,$0,$L289
	lui	$2,%hi(crushchange)

	lw	$2,%lo(crushchange)($2)
	lui	$3,%hi(nofit)
	li	$4,1			# 0x1
	beq	$2,$0,$L275
	sw	$4,%lo(nofit)($3)

	lui	$2,%hi(leveltime)
	lw	$2,%lo(leveltime)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L288
	li	$7,10			# 0xa

$L275:
	lw	$31,28($sp)
$L289:
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

$L287:
	jal	P_RemoveMobj
	move	$4,$16

	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

$L286:
	jal	P_SetMobjState
	move	$4,$16

	lw	$2,104($16)
	li	$3,-3			# 0xfffffffffffffffd
	and	$2,$2,$3
	sw	$2,104($16)
	sw	$0,68($16)
	b	$L275
	sw	$0,64($16)

$L288:
	move	$4,$16
	move	$6,$0
	jal	P_DamageMobj
	move	$5,$0

	lw	$3,68($16)
	lw	$6,20($16)
	srl	$2,$3,31
	addu	$2,$2,$3
	lw	$5,16($16)
	lw	$4,12($16)
	sra	$2,$2,1
	li	$7,38			# 0x26
	jal	P_SpawnMobj
	addu	$6,$2,$6

	jal	P_Random
	move	$17,$2

	jal	P_Random
	move	$16,$2

	subu	$16,$16,$2
	sll	$16,$16,12
	jal	P_Random
	sw	$16,72($17)

	jal	P_Random
	move	$16,$2

	subu	$16,$16,$2
	sll	$16,$16,12
	b	$L275
	sw	$16,76($17)

	.set	macro
	.set	reorder
	.end	PIT_ChangeSector
	.size	PIT_ChangeSector, .-PIT_ChangeSector
	.align	2
	.globl	P_HitSlideLine
	.set	nomips16
	.set	nomicromips
	.ent	P_HitSlideLine
	.type	P_HitSlideLine, @function
P_HitSlideLine:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,44($4)
	beq	$2,$0,$L299
	nop

	addiu	$sp,$sp,-40
	sw	$17,20($sp)
	li	$17,1			# 0x1
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L300
	.set	at
	sw	$16,16($sp)

	lui	$2,%hi(slidemo)
	lw	$2,%lo(slidemo)($2)
	move	$16,$4
	move	$6,$4
	lw	$5,16($2)
	jal	P_PointOnLineSide
	lw	$4,12($2)

	lw	$7,12($16)
	lw	$6,8($16)
	move	$5,$0
	move	$4,$0
	jal	R_PointToAngle2
	move	$18,$2

	.set	noat
	xor	$1,$18,$17
	bne	$1,$0,$L294
	.set	at
	move	$16,$2

	li	$2,-2147483648			# 0xffffffff80000000
	addu	$16,$16,$2
$L294:
	lui	$18,%hi(tmymove)
	lui	$19,%hi(tmxmove)
	lw	$7,%lo(tmymove)($18)
	lw	$6,%lo(tmxmove)($19)
	move	$5,$0
	jal	R_PointToAngle2
	move	$4,$0

	li	$3,-2147483648			# 0xffffffff80000000
	subu	$17,$2,$16
	addiu	$2,$3,1
	sltu	$2,$17,$2
	bne	$2,$0,$L301
	lw	$5,%lo(tmymove)($18)

	addu	$17,$17,$3
$L301:
	lw	$4,%lo(tmxmove)($19)
	jal	P_AproxDistance
	lui	$20,%hi(finecosine)

	srl	$17,$17,19
	lw	$3,%lo(finecosine)($20)
	sll	$17,$17,2
	addu	$3,$3,$17
	lw	$5,0($3)
	jal	FixedMul
	move	$4,$2

	srl	$16,$16,19
	lw	$3,%lo(finecosine)($20)
	sll	$16,$16,2
	addu	$3,$3,$16
	lw	$5,0($3)
	move	$4,$2
	jal	FixedMul
	move	$17,$2

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$16,$16,$3
	lw	$5,0($16)
	move	$4,$17
	jal	FixedMul
	sw	$2,%lo(tmxmove)($19)

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$2,%lo(tmymove)($18)
	lw	$18,24($sp)
	jr	$31
	addiu	$sp,$sp,40

$L300:
	lw	$31,36($sp)
	lui	$2,%hi(tmxmove)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$0,%lo(tmxmove)($2)
	jr	$31
	addiu	$sp,$sp,40

$L299:
	lui	$2,%hi(tmymove)
	jr	$31
	sw	$0,%lo(tmymove)($2)

	.set	macro
	.set	reorder
	.end	P_HitSlideLine
	.size	P_HitSlideLine, .-P_HitSlideLine
	.align	2
	.globl	P_SlideMove
	.set	nomips16
	.set	nomicromips
	.ent	P_SlideMove
	.type	P_SlideMove, @function
P_SlideMove:
	.frame	$sp,88,$31		# vars= 24, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(slidemo)
	addiu	$sp,$sp,-88
	sw	$4,%lo(slidemo)($2)
	lui	$2,%hi(PTR_SlideTraverse)
	sw	$2,28($sp)
	lui	$2,%hi(tmxmove)
	sw	$2,32($sp)
	lui	$2,%hi(tmymove)
	sw	$19,60($sp)
	sw	$2,36($sp)
	li	$19,65536			# 0x10000
	lui	$2,%hi(bestslideline)
	sw	$23,76($sp)
	sw	$18,56($sp)
	sw	$16,48($sp)
	sw	$31,84($sp)
	sw	$fp,80($sp)
	sw	$22,72($sp)
	sw	$21,68($sp)
	sw	$20,64($sp)
	sw	$17,52($sp)
	move	$16,$4
	li	$23,3			# 0x3
	lui	$18,%hi(bestslidefrac)
	addiu	$19,$19,1
	sw	$2,40($sp)
$L303 = .
	addiu	$23,$23,-1
$L326:
	beq	$23,$0,$L309
	lw	$5,12($16)

	lw	$2,64($16)
	lw	$6,72($16)
	subu	$11,$5,$2
	bgtz	$6,$L307
	addu	$17,$2,$5

	move	$4,$17
	move	$17,$11
	move	$11,$4
$L307:
	lw	$fp,16($16)
	lw	$7,76($16)
	subu	$22,$fp,$2
	bgtz	$7,$L308
	addu	$fp,$fp,$2

	move	$2,$fp
	move	$fp,$22
	move	$22,$2
$L308:
	lw	$2,28($sp)
	li	$20,1			# 0x1
	addiu	$21,$2,%lo(PTR_SlideTraverse)
	move	$5,$fp
	move	$4,$17
	addu	$7,$7,$fp
	addu	$6,$6,$17
	sw	$21,20($sp)
	sw	$20,16($sp)
	sw	$11,24($sp)
	jal	P_PathTraverse
	sw	$19,%lo(bestslidefrac)($18)

	lw	$7,76($16)
	lw	$6,72($16)
	lw	$11,24($sp)
	move	$5,$fp
	move	$4,$11
	addu	$6,$11,$6
	addu	$7,$fp,$7
	sw	$21,20($sp)
	jal	P_PathTraverse
	sw	$20,16($sp)

	lw	$7,76($16)
	lw	$6,72($16)
	move	$5,$22
	sw	$21,20($sp)
	sw	$20,16($sp)
	addu	$7,$22,$7
	addu	$6,$17,$6
	jal	P_PathTraverse
	move	$4,$17

	lw	$5,%lo(bestslidefrac)($18)
	.set	noat
	xor	$1,$5,$19
	beq	$1,$0,$L324
	.set	at
	addiu	$5,$5,-2048

	bgtz	$5,$L312
	sw	$5,%lo(bestslidefrac)($18)

	li	$2,63488			# 0xf800
	subu	$5,$2,$5
	slt	$2,$5,$19
	bne	$2,$0,$L314
	sw	$5,%lo(bestslidefrac)($18)

$L313:
	li	$2,65536			# 0x10000
	sw	$2,%lo(bestslidefrac)($18)
	li	$5,65536			# 0x10000
$L314:
	jal	FixedMul
	lw	$4,72($16)

	lw	$5,%lo(bestslidefrac)($18)
	lw	$17,32($sp)
	lw	$4,76($16)
	jal	FixedMul
	sw	$2,%lo(tmxmove)($17)

	lw	$3,40($sp)
	lw	$20,36($sp)
	lw	$4,%lo(bestslideline)($3)
	jal	P_HitSlideLine
	sw	$2,%lo(tmymove)($20)

	lw	$4,%lo(tmymove)($20)
	lw	$2,%lo(tmxmove)($17)
	lw	$6,16($16)
	lw	$5,12($16)
	sw	$4,76($16)
	addu	$6,$4,$6
	sw	$2,72($16)
	addu	$5,$2,$5
	jal	P_TryMove
	move	$4,$16

	beq	$2,$0,$L326
	addiu	$23,$23,-1

	lw	$31,84($sp)
$L325:
	lw	$fp,80($sp)
$L327:
	lw	$23,76($sp)
	lw	$22,72($sp)
	lw	$21,68($sp)
	lw	$20,64($sp)
	lw	$19,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,88

$L324:
	lw	$5,12($16)
$L309:
	lw	$6,16($16)
	lw	$2,76($16)
	move	$4,$16
	jal	P_TryMove
	addu	$6,$6,$2

	bne	$2,$0,$L325
	lw	$31,84($sp)

	lw	$5,12($16)
	lw	$2,72($16)
	lw	$6,16($16)
	lw	$fp,80($sp)
	lw	$23,76($sp)
	lw	$22,72($sp)
	lw	$21,68($sp)
	lw	$20,64($sp)
	lw	$19,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	move	$4,$16
	lw	$16,48($sp)
	addu	$5,$5,$2
	j	P_TryMove
	addiu	$sp,$sp,88

$L312:
	jal	FixedMul
	lw	$4,72($16)

	lw	$5,%lo(bestslidefrac)($18)
	lw	$4,76($16)
	jal	FixedMul
	move	$17,$2

	lw	$6,16($16)
	lw	$5,12($16)
	addu	$6,$2,$6
	addu	$5,$17,$5
	jal	P_TryMove
	move	$4,$16

	beq	$2,$0,$L324
	lw	$2,%lo(bestslidefrac)($18)

	li	$5,63488			# 0xf800
	subu	$5,$5,$2
	slt	$2,$5,$19
	beq	$2,$0,$L313
	sw	$5,%lo(bestslidefrac)($18)

	bgtz	$5,$L314
	lw	$31,84($sp)

	b	$L327
	lw	$fp,80($sp)

	.set	macro
	.set	reorder
	.end	P_SlideMove
	.size	P_SlideMove, .-P_SlideMove
	.align	2
	.globl	P_AimLineAttack
	.set	nomips16
	.set	nomicromips
	.ent	P_AimLineAttack
	.type	P_AimLineAttack, @function
P_AimLineAttack:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$17,32($sp)
	sw	$16,28($sp)
	move	$17,$6
	jal	P_SubstNullMobj
	move	$16,$5

	lui	$3,%hi(finecosine)
	lw	$3,%lo(finecosine)($3)
	srl	$5,$16,19
	sll	$5,$5,2
	lui	$6,%hi(finesine)
	addu	$4,$3,$5
	addiu	$3,$6,%lo(finesine)
	addu	$3,$5,$3
	lw	$8,68($2)
	lw	$7,0($3)
	sra	$6,$17,16
	sra	$3,$8,1
	multu	$6,$7
	mflo	$8
	lw	$9,0($4)
	lw	$5,16($2)
	lw	$4,12($2)
	addu	$7,$8,$5
	multu	$6,$9
	mflo	$8
	lw	$10,20($2)
	addu	$6,$8,$4
	addu	$3,$3,$10
	li	$8,524288			# 0x80000
	addu	$3,$3,$8
	lui	$8,%hi(PTR_AimTraverse)
	addiu	$8,$8,%lo(PTR_AimTraverse)
	sw	$8,20($sp)
	li	$8,3			# 0x3
	sw	$8,16($sp)
	lui	$8,%hi(shootthing)
	sw	$2,%lo(shootthing)($8)
	lui	$2,%hi(shootz)
	sw	$3,%lo(shootz)($2)
	lui	$2,%hi(topslope)
	li	$3,40960			# 0xa000
	sw	$3,%lo(topslope)($2)
	li	$2,-65536			# 0xffffffffffff0000
	lui	$3,%hi(bottomslope)
	addiu	$2,$2,24576
	lui	$16,%hi(linetarget)
	sw	$2,%lo(bottomslope)($3)
	lui	$2,%hi(attackrange)
	sw	$17,%lo(attackrange)($2)
	jal	P_PathTraverse
	sw	$0,%lo(linetarget)($16)

	lw	$2,%lo(linetarget)($16)
	beq	$2,$0,$L330
	lw	$31,36($sp)

	lui	$2,%hi(aimslope)
	lw	$17,32($sp)
	lw	$16,28($sp)
	lw	$2,%lo(aimslope)($2)
	jr	$31
	addiu	$sp,$sp,40

$L330:
	lw	$17,32($sp)
	lw	$16,28($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_AimLineAttack
	.size	P_AimLineAttack, .-P_AimLineAttack
	.align	2
	.globl	P_LineAttack
	.set	nomips16
	.set	nomicromips
	.ent	P_LineAttack
	.type	P_LineAttack, @function
P_LineAttack:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	lw	$10,48($sp)
	srl	$5,$5,19
	lui	$9,%hi(finesine)
	lw	$3,68($4)
	move	$8,$4
	sll	$5,$5,2
	lui	$4,%hi(la_damage)
	addiu	$9,$9,%lo(finesine)
	sw	$10,%lo(la_damage)($4)
	addu	$4,$2,$5
	addu	$2,$5,$9
	lw	$12,0($2)
	move	$9,$6
	sra	$6,$6,16
	sra	$2,$3,1
	multu	$6,$12
	mflo	$3
	lw	$11,0($4)
	lw	$5,16($8)
	move	$10,$7
	addu	$7,$3,$5
	multu	$6,$11
	mflo	$3
	lw	$4,12($8)
	lw	$13,20($8)
	addu	$6,$3,$4
	addu	$2,$2,$13
	li	$3,524288			# 0x80000
	addu	$2,$2,$3
	lui	$3,%hi(PTR_ShootTraverse)
	addiu	$3,$3,%lo(PTR_ShootTraverse)
	sw	$3,20($sp)
	li	$3,3			# 0x3
	sw	$3,16($sp)
	lui	$3,%hi(shootthing)
	sw	$8,%lo(shootthing)($3)
	lui	$3,%hi(shootz)
	sw	$2,%lo(shootz)($3)
	lui	$2,%hi(attackrange)
	sw	$9,%lo(attackrange)($2)
	lui	$2,%hi(aimslope)
	sw	$31,28($sp)
	jal	P_PathTraverse
	sw	$10,%lo(aimslope)($2)

	lw	$31,28($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_LineAttack
	.size	P_LineAttack, .-P_LineAttack
	.align	2
	.globl	P_UseLines
	.set	nomips16
	.set	nomicromips
	.ent	P_UseLines
	.type	P_UseLines, @function
P_UseLines:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$8,0($4)
	lui	$3,%hi(finecosine)
	lw	$2,32($8)
	lw	$4,%lo(finecosine)($3)
	srl	$2,$2,19
	lui	$3,%hi(finesine)
	sll	$2,$2,2
	addiu	$3,$3,%lo(finesine)
	addu	$3,$2,$3
	addu	$2,$4,$2
	lw	$6,0($2)
	lw	$7,0($3)
	lui	$2,%hi(PTR_UseTraverse)
	addiu	$sp,$sp,-32
	lw	$4,12($8)
	lw	$5,16($8)
	addiu	$2,$2,%lo(PTR_UseTraverse)
	sll	$7,$7,6
	sw	$2,20($sp)
	sll	$6,$6,6
	li	$2,1			# 0x1
	sw	$2,16($sp)
	addu	$7,$7,$5
	lui	$2,%hi(usething)
	addu	$6,$6,$4
	sw	$31,28($sp)
	jal	P_PathTraverse
	sw	$8,%lo(usething)($2)

	lw	$31,28($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_UseLines
	.size	P_UseLines, .-P_UseLines
	.align	2
	.globl	P_RadiusAttack
	.set	nomips16
	.set	nomicromips
	.ent	P_RadiusAttack
	.type	P_RadiusAttack, @function
P_RadiusAttack:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,16($4)
	lui	$2,%hi(bmaporgy)
	addiu	$sp,$sp,-48
	sll	$7,$6,16
	lw	$9,%lo(bmaporgy)($2)
	lui	$8,%hi(bmaporgx)
	lw	$2,12($4)
	lw	$8,%lo(bmaporgx)($8)
	sw	$21,36($sp)
	sw	$17,20($sp)
	addu	$21,$3,$7
	subu	$17,$3,$7
	sw	$20,32($sp)
	lui	$3,%hi(bombspot)
	subu	$20,$2,$7
	sw	$18,24($sp)
	subu	$21,$21,$9
	addu	$18,$2,$7
	subu	$17,$17,$9
	sra	$21,$21,23
	sra	$17,$17,23
	subu	$18,$18,$8
	subu	$20,$20,$8
	sw	$4,%lo(bombspot)($3)
	lui	$3,%hi(bombsource)
	sra	$18,$18,23
	sra	$20,$20,23
	sw	$5,%lo(bombsource)($3)
	slt	$2,$21,$17
	lui	$3,%hi(bombdamage)
	sw	$22,40($sp)
	sw	$31,44($sp)
	sw	$19,28($sp)
	sw	$16,16($sp)
	sw	$6,%lo(bombdamage)($3)
	bne	$2,$0,$L336
	slt	$22,$18,$20

	lui	$19,%hi(PIT_RadiusAttack)
	addiu	$19,$19,%lo(PIT_RadiusAttack)
$L337:
	bne	$22,$0,$L340
	move	$16,$20

	move	$4,$16
$L346:
	move	$6,$19
	move	$5,$17
	jal	P_BlockThingsIterator
	addiu	$16,$16,1

	slt	$2,$18,$16
	beq	$2,$0,$L346
	move	$4,$16

$L340:
	addiu	$17,$17,1
	slt	$2,$21,$17
	beq	$2,$0,$L337
	nop

$L336:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	P_RadiusAttack
	.size	P_RadiusAttack, .-P_RadiusAttack
	.align	2
	.globl	P_ChangeSector
	.set	nomips16
	.set	nomicromips
	.ent	P_ChangeSector
	.type	P_ChangeSector, @function
P_ChangeSector:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lw	$3,40($4)
	sw	$17,20($sp)
	lw	$17,36($4)
	sw	$20,32($sp)
	sw	$18,24($sp)
	lui	$20,%hi(nofit)
	move	$18,$4
	slt	$2,$3,$17
	lui	$4,%hi(crushchange)
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$16,16($sp)
	sw	$0,%lo(nofit)($20)
	bne	$2,$0,$L353
	sw	$5,%lo(crushchange)($4)

	lui	$19,%hi(PIT_ChangeSector)
	lw	$2,28($18)
	addiu	$19,$19,%lo(PIT_ChangeSector)
$L350:
	lw	$16,32($18)
	slt	$4,$2,$16
	bne	$4,$0,$L352
	move	$5,$16

$L359:
	move	$6,$19
	jal	P_BlockThingsIterator
	move	$4,$17

	lw	$2,28($18)
	addiu	$16,$16,1
	slt	$3,$2,$16
	beq	$3,$0,$L359
	move	$5,$16

	lw	$3,40($18)
$L352:
	addiu	$17,$17,1
	slt	$4,$3,$17
	beq	$4,$0,$L350
	lw	$31,36($sp)

	lw	$2,%lo(nofit)($20)
	lw	$19,28($sp)
	lw	$20,32($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L353:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_ChangeSector
	.size	P_ChangeSector, .-P_ChangeSector
	.local	baseaddr.0
	.comm	baseaddr.0,4,4
	.globl	nofit
	.section	.bss,"aw",@nobits
	.align	2
	.type	nofit, @object
	.size	nofit, 4
nofit:
	.space	4
	.globl	crushchange
	.align	2
	.type	crushchange, @object
	.size	crushchange, 4
crushchange:
	.space	4
	.globl	bombdamage
	.align	2
	.type	bombdamage, @object
	.size	bombdamage, 4
bombdamage:
	.space	4
	.globl	bombspot
	.align	2
	.type	bombspot, @object
	.size	bombspot, 4
bombspot:
	.space	4
	.globl	bombsource
	.align	2
	.type	bombsource, @object
	.size	bombsource, 4
bombsource:
	.space	4
	.globl	usething
	.align	2
	.type	usething, @object
	.size	usething, 4
usething:
	.space	4
	.globl	aimslope
	.align	2
	.type	aimslope, @object
	.size	aimslope, 4
aimslope:
	.space	4
	.globl	attackrange
	.align	2
	.type	attackrange, @object
	.size	attackrange, 4
attackrange:
	.space	4
	.globl	la_damage
	.align	2
	.type	la_damage, @object
	.size	la_damage, 4
la_damage:
	.space	4
	.globl	shootz
	.align	2
	.type	shootz, @object
	.size	shootz, 4
shootz:
	.space	4
	.globl	shootthing
	.align	2
	.type	shootthing, @object
	.size	shootthing, 4
shootthing:
	.space	4
	.globl	linetarget
	.align	2
	.type	linetarget, @object
	.size	linetarget, 4
linetarget:
	.space	4
	.globl	tmymove
	.align	2
	.type	tmymove, @object
	.size	tmymove, 4
tmymove:
	.space	4
	.globl	tmxmove
	.align	2
	.type	tmxmove, @object
	.size	tmxmove, 4
tmxmove:
	.space	4
	.globl	slidemo
	.align	2
	.type	slidemo, @object
	.size	slidemo, 4
slidemo:
	.space	4
	.globl	secondslideline
	.align	2
	.type	secondslideline, @object
	.size	secondslideline, 4
secondslideline:
	.space	4
	.globl	bestslideline
	.align	2
	.type	bestslideline, @object
	.size	bestslideline, 4
bestslideline:
	.space	4
	.globl	secondslidefrac
	.align	2
	.type	secondslidefrac, @object
	.size	secondslidefrac, 4
secondslidefrac:
	.space	4
	.globl	bestslidefrac
	.align	2
	.type	bestslidefrac, @object
	.size	bestslidefrac, 4
bestslidefrac:
	.space	4
	.globl	numspechit
	.align	2
	.type	numspechit, @object
	.size	numspechit, 4
numspechit:
	.space	4
	.globl	spechit
	.align	2
	.type	spechit, @object
	.size	spechit, 80
spechit:
	.space	80
	.globl	ceilingline
	.align	2
	.type	ceilingline, @object
	.size	ceilingline, 4
ceilingline:
	.space	4
	.globl	tmdropoffz
	.align	2
	.type	tmdropoffz, @object
	.size	tmdropoffz, 4
tmdropoffz:
	.space	4
	.globl	tmceilingz
	.align	2
	.type	tmceilingz, @object
	.size	tmceilingz, 4
tmceilingz:
	.space	4
	.globl	tmfloorz
	.align	2
	.type	tmfloorz, @object
	.size	tmfloorz, 4
tmfloorz:
	.space	4
	.globl	floatok
	.align	2
	.type	floatok, @object
	.size	floatok, 4
floatok:
	.space	4
	.globl	tmy
	.align	2
	.type	tmy, @object
	.size	tmy, 4
tmy:
	.space	4
	.globl	tmx
	.align	2
	.type	tmx, @object
	.size	tmx, 4
tmx:
	.space	4
	.globl	tmflags
	.align	2
	.type	tmflags, @object
	.size	tmflags, 4
tmflags:
	.space	4
	.globl	tmthing
	.align	2
	.type	tmthing, @object
	.size	tmthing, 4
tmthing:
	.space	4
	.globl	tmbbox
	.align	2
	.type	tmbbox, @object
	.size	tmbbox, 16
tmbbox:
	.space	16
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
