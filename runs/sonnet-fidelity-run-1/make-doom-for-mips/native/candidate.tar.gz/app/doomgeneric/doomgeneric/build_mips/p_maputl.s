	.file	1 "p_maputl.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	InterceptsMemoryOverrun
	.type	InterceptsMemoryOverrun, @function
InterceptsMemoryOverrun:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	slt	$2,$4,4
	bne	$2,$0,$L18
	lui	$2,%hi(intercepts_overrun+12)

	addiu	$2,$2,%lo(intercepts_overrun+12)
	move	$7,$0
	b	$L4
	li	$8,4			# 0x4

$L7:
	bne	$9,$0,$L15
	addiu	$2,$2,12

	move	$8,$6
$L4:
	lw	$3,0($2)
	addiu	$7,$7,1
	addu	$6,$3,$8
	bne	$3,$0,$L7
	slt	$9,$4,$6

$L18:
	jr	$31
	nop

$L15:
	sll	$3,$7,1
	addu	$3,$3,$7
	lui	$2,%hi(intercepts_overrun)
	sll	$3,$3,2
	addiu	$2,$2,%lo(intercepts_overrun)
	addu	$2,$2,$3
	lw	$3,4($2)
	beq	$3,$0,$L17
	nop

	lw	$2,8($2)
	bne	$2,$0,$L16
	subu	$4,$4,$8

	bgez	$4,$L6
	nop

	addiu	$4,$4,3
$L6:
	sra	$4,$4,2
	sll	$4,$4,2
	addu	$3,$3,$4
	jr	$31
	sw	$5,0($3)

$L16:
	srl	$2,$4,31
	addu	$2,$2,$4
	sra	$2,$2,1
	sll	$2,$2,1
	addu	$3,$3,$2
	srl	$2,$5,16
	sh	$5,0($3)
	jr	$31
	sh	$2,2($3)

$L17:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	InterceptsMemoryOverrun
	.size	InterceptsMemoryOverrun, .-InterceptsMemoryOverrun
	.align	2
	.globl	P_AproxDistance
	.set	nomips16
	.set	nomicromips
	.ent	P_AproxDistance
	.type	P_AproxDistance, @function
P_AproxDistance:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	abs
	move	$16,$5

	move	$4,$16
	jal	abs
	move	$16,$2

	slt	$3,$16,$2
	bne	$3,$0,$L23
	lw	$31,20($sp)

	addu	$16,$16,$2
	sra	$2,$2,1
	subu	$2,$16,$2
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L23:
	addu	$2,$16,$2
	sra	$16,$16,1
	subu	$2,$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_AproxDistance
	.size	P_AproxDistance, .-P_AproxDistance
	.align	2
	.globl	P_PointOnLineSide
	.set	nomips16
	.set	nomicromips
	.ent	P_PointOnLineSide
	.type	P_PointOnLineSide, @function
P_PointOnLineSide:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,8($6)
	addiu	$sp,$sp,-32
	lw	$2,12($6)
	lw	$8,0($6)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$6
	sw	$17,24($sp)
	bne	$7,$0,$L25
	move	$6,$4

	lw	$3,0($8)
	slt	$3,$3,$4
	beq	$3,$0,$L31
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	srl	$2,$2,31
	jr	$31
	addiu	$sp,$sp,32

$L25:
	lw	$9,4($8)
	bne	$2,$0,$L28
	move	$3,$5

	slt	$5,$9,$5
	bne	$5,$0,$L29
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	srl	$2,$7,31
	jr	$31
	addiu	$sp,$sp,32

$L31:
	lw	$17,24($sp)
	lw	$16,20($sp)
	slt	$2,$0,$2
	jr	$31
	addiu	$sp,$sp,32

$L29:
	lw	$17,24($sp)
	lw	$16,20($sp)
	slt	$2,$0,$7
	jr	$31
	addiu	$sp,$sp,32

$L28:
	lw	$5,0($8)
	sra	$4,$2,16
	subu	$5,$6,$5
	jal	FixedMul
	subu	$17,$3,$9

	lh	$5,10($16)
	move	$4,$17
	jal	FixedMul
	move	$16,$2

	lw	$31,28($sp)
	slt	$2,$2,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	xori	$2,$2,0x1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_PointOnLineSide
	.size	P_PointOnLineSide, .-P_PointOnLineSide
	.align	2
	.globl	P_BoxOnLineSide
	.set	nomips16
	.set	nomicromips
	.ent	P_BoxOnLineSide
	.type	P_BoxOnLineSide, @function
P_BoxOnLineSide:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,44($5)
	addiu	$sp,$sp,-32
	li	$3,2			# 0x2
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$5
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L33
	.set	at
	move	$17,$4

	sltu	$3,$2,3
	beq	$3,$0,$L34
	li	$3,3			# 0x3

	beq	$2,$0,$L45
	nop

	lw	$2,0($5)
	lw	$16,12($17)
	lw	$3,0($2)
	lw	$4,12($5)
	lw	$2,8($17)
	bltz	$4,$L41
	slt	$16,$16,$3

	b	$L40
	slt	$2,$2,$3

$L34:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L46
	.set	at
	lw	$31,28($sp)

	lw	$5,0($4)
	lw	$4,12($4)
	jal	P_PointOnLineSide
	move	$6,$16

	lw	$5,4($17)
	lw	$4,8($17)
	move	$6,$16
	jal	P_PointOnLineSide
	move	$16,$2

$L40:
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L47
	.set	at
	nop

$L32:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L46:
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L33:
	lw	$5,0($4)
	lw	$4,8($4)
	jal	P_PointOnLineSide
	move	$6,$16

	lw	$5,4($17)
	lw	$4,12($17)
	move	$6,$16
	jal	P_PointOnLineSide
	move	$16,$2

	b	$L40
	nop

$L45:
	lw	$2,0($5)
	lw	$16,0($17)
	lw	$3,4($2)
	lw	$4,8($5)
	lw	$2,4($17)
	bltz	$4,$L39
	slt	$16,$3,$16

	b	$L40
	slt	$2,$3,$2

$L39:
	slt	$3,$3,$2
	xori	$16,$16,0x1
	b	$L40
	xori	$2,$3,0x1

$L41:
	slt	$3,$2,$3
	xori	$16,$16,0x1
	b	$L40
	xori	$2,$3,0x1

$L47:
	b	$L32
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	P_BoxOnLineSide
	.size	P_BoxOnLineSide, .-P_BoxOnLineSide
	.align	2
	.globl	P_PointOnDivlineSide
	.set	nomips16
	.set	nomicromips
	.ent	P_PointOnDivlineSide
	.type	P_PointOnDivlineSide, @function
P_PointOnDivlineSide:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,8($6)
	bne	$3,$0,$L49
	lw	$2,12($6)

	lw	$3,0($6)
	slt	$3,$3,$4
	bne	$3,$0,$L50
	nop

	jr	$31
	slt	$2,$0,$2

$L49:
	bne	$2,$0,$L52
	lw	$7,4($6)

	slt	$5,$7,$5
	bne	$5,$0,$L53
	nop

	jr	$31
	srl	$2,$3,31

$L52:
	lw	$8,0($6)
	addiu	$sp,$sp,-24
	xor	$3,$3,$2
	subu	$4,$4,$8
	xor	$3,$3,$4
	sw	$16,16($sp)
	subu	$16,$5,$7
	xor	$3,$3,$16
	bgez	$3,$L54
	sw	$31,20($sp)

	lw	$31,20($sp)
	xor	$4,$4,$2
	lw	$16,16($sp)
	srl	$2,$4,31
	jr	$31
	addiu	$sp,$sp,24

$L50:
	jr	$31
	srl	$2,$2,31

$L53:
	jr	$31
	slt	$2,$0,$3

$L54:
	sra	$5,$4,8
	sra	$4,$2,8
	jal	FixedMul
	sw	$6,32($sp)

	lw	$6,32($sp)
	sra	$4,$16,8
	lw	$5,8($6)
	move	$16,$2
	jal	FixedMul
	sra	$5,$5,8

	lw	$31,20($sp)
	slt	$2,$2,$16
	xori	$2,$2,0x1
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_PointOnDivlineSide
	.size	P_PointOnDivlineSide, .-P_PointOnDivlineSide
	.align	2
	.globl	P_MakeDivline
	.set	nomips16
	.set	nomicromips
	.ent	P_MakeDivline
	.type	P_MakeDivline, @function
P_MakeDivline:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	lw	$3,0($2)
	lw	$2,4($2)
	sw	$3,0($5)
	sw	$2,4($5)
	lw	$3,8($4)
	lw	$2,12($4)
	sw	$3,8($5)
	jr	$31
	sw	$2,12($5)

	.set	macro
	.set	reorder
	.end	P_MakeDivline
	.size	P_MakeDivline, .-P_MakeDivline
	.align	2
	.globl	P_InterceptVector
	.set	nomips16
	.set	nomicromips
	.ent	P_InterceptVector
	.type	P_InterceptVector, @function
P_InterceptVector:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	move	$17,$4
	lw	$4,12($5)
	sw	$16,20($sp)
	move	$16,$5
	lw	$5,8($17)
	sra	$4,$4,8
	sw	$31,36($sp)
	sw	$19,32($sp)
	jal	FixedMul
	sw	$18,28($sp)

	lw	$4,8($16)
	lw	$5,12($17)
	sra	$4,$4,8
	jal	FixedMul
	move	$18,$2

	.set	noat
	xor	$1,$18,$2
	bne	$1,$0,$L62
	.set	at
	subu	$19,$18,$2

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

$L62:
	lw	$4,0($16)
	lw	$2,0($17)
	lw	$5,12($16)
	subu	$4,$4,$2
	jal	FixedMul
	sra	$4,$4,8

	lw	$4,4($17)
	lw	$3,4($16)
	lw	$5,8($16)
	subu	$4,$4,$3
	sra	$4,$4,8
	jal	FixedMul
	move	$16,$2

	addu	$4,$16,$2
	lw	$31,36($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$5,$19
	lw	$19,32($sp)
	j	FixedDiv
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_InterceptVector
	.size	P_InterceptVector, .-P_InterceptVector
	.align	2
	.globl	PIT_AddLineIntercepts
	.set	nomips16
	.set	nomicromips
	.ent	PIT_AddLineIntercepts
	.type	PIT_AddLineIntercepts, @function
PIT_AddLineIntercepts:
	.frame	$sp,48,$31		# vars= 16, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,36($sp)
	lui	$17,%hi(trace)
	sw	$18,40($sp)
	addiu	$18,$17,%lo(trace)
	lw	$2,8($18)
	li	$5,1048576			# 0x100000
	li	$3,2097152			# 0x200000
	addu	$2,$2,$5
	addiu	$3,$3,1
	sltu	$2,$2,$3
	sw	$16,32($sp)
	sw	$31,44($sp)
	beq	$2,$0,$L64
	move	$16,$4

	lw	$2,12($18)
	addu	$2,$2,$5
	sltu	$2,$2,$3
	bne	$2,$0,$L65
	lw	$4,%lo(trace)($17)

$L64:
	lw	$2,0($16)
	addiu	$6,$17,%lo(trace)
	lw	$5,4($2)
	jal	P_PointOnDivlineSide
	lw	$4,0($2)

	lw	$3,4($16)
	addiu	$6,$17,%lo(trace)
	lw	$5,4($3)
	lw	$4,0($3)
	jal	P_PointOnDivlineSide
	move	$18,$2

$L66:
	.set	noat
	xor	$1,$18,$2
	beq	$1,$0,$L68
	.set	at
	addiu	$5,$sp,16

	lw	$2,0($16)
	lw	$3,12($16)
	lw	$6,4($2)
	lw	$7,0($2)
	lw	$2,8($16)
	addiu	$4,$17,%lo(trace)
	sw	$7,16($sp)
	sw	$6,20($sp)
	sw	$2,24($sp)
	jal	P_InterceptVector
	sw	$3,28($sp)

	bltz	$2,$L68
	move	$5,$2

	lui	$2,%hi(earlyout)
	lw	$2,%lo(earlyout)($2)
	beq	$2,$0,$L79
	lui	$12,%hi(intercept_p)

	li	$2,65536			# 0x10000
	slt	$2,$5,$2
	bne	$2,$0,$L78
	nop

$L79:
	lw	$10,%lo(intercept_p)($12)
	lui	$11,%hi(intercepts)
	addiu	$11,$11,%lo(intercepts)
	subu	$11,$10,$11
	li	$3,1			# 0x1
	slt	$2,$11,1537
	sw	$5,0($10)
	sw	$3,4($10)
	bne	$2,$0,$L72
	sw	$16,8($10)

	jal	InterceptsMemoryOverrun
	addiu	$4,$11,-1548

	lw	$5,4($10)
	jal	InterceptsMemoryOverrun
	addiu	$4,$11,-1544

	move	$5,$16
	jal	InterceptsMemoryOverrun
	addiu	$4,$11,-1540

$L72:
	addiu	$10,$10,12
	sw	$10,%lo(intercept_p)($12)
$L68:
	li	$2,1			# 0x1
$L63:
	lw	$31,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,48

$L65:
	lw	$5,4($18)
	jal	P_PointOnLineSide
	move	$6,$16

	lw	$7,4($18)
	lw	$3,8($18)
	lw	$5,12($18)
	lw	$4,%lo(trace)($17)
	move	$6,$16
	addu	$5,$7,$5
	addu	$4,$4,$3
	jal	P_PointOnLineSide
	move	$18,$2

	b	$L66
	nop

$L78:
	lw	$2,52($16)
	bne	$2,$0,$L79
	lui	$12,%hi(intercept_p)

	b	$L63
	move	$2,$0

	.set	macro
	.set	reorder
	.end	PIT_AddLineIntercepts
	.size	PIT_AddLineIntercepts, .-PIT_AddLineIntercepts
	.align	2
	.globl	P_LineOpening
	.set	nomips16
	.set	nomicromips
	.ent	P_LineOpening
	.type	P_LineOpening, @function
P_LineOpening:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lh	$3,24($4)
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L83
	.set	at
	move	$2,$0

	lw	$6,48($4)
	lw	$3,52($4)
	lw	$2,4($6)
	lw	$5,4($3)
	lw	$4,0($6)
	lw	$3,0($3)
	slt	$6,$5,$2
	movn	$2,$5,$6
	lui	$6,%hi(opentop)
	slt	$5,$3,$4
	bne	$5,$0,$L84
	sw	$2,%lo(opentop)($6)

$L82:
	lui	$5,%hi(lowfloor)
	sw	$4,%lo(lowfloor)($5)
	lui	$4,%hi(openbottom)
	subu	$2,$2,$3
	sw	$3,%lo(openbottom)($4)
	lui	$3,%hi(openrange)
	jr	$31
	sw	$2,%lo(openrange)($3)

$L84:
	move	$5,$3
	move	$3,$4
	b	$L82
	move	$4,$5

$L83:
	lui	$3,%hi(openrange)
	jr	$31
	sw	$2,%lo(openrange)($3)

	.set	macro
	.set	reorder
	.end	P_LineOpening
	.size	P_LineOpening, .-P_LineOpening
	.align	2
	.globl	P_UnsetThingPosition
	.set	nomips16
	.set	nomicromips
	.ent	P_UnsetThingPosition
	.type	P_UnsetThingPosition, @function
P_UnsetThingPosition:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	andi	$3,$2,0x8
	bne	$3,$0,$L86
	nop

	lw	$3,24($4)
	beq	$3,$0,$L87
	nop

	lw	$5,28($4)
	sw	$5,28($3)
$L87:
	lw	$5,28($4)
	beq	$5,$0,$L88
	nop

	sw	$3,24($5)
$L86:
	andi	$2,$2,0x10
	bne	$2,$0,$L101
	nop

	lw	$2,44($4)
	beq	$2,$0,$L91
	nop

	lw	$3,48($4)
	sw	$3,48($2)
$L91:
	lw	$3,48($4)
	beq	$3,$0,$L92
	lui	$5,%hi(bmaporgx)

	jr	$31
	sw	$2,44($3)

$L92:
	lw	$3,12($4)
	lw	$5,%lo(bmaporgx)($5)
	lw	$4,16($4)
	subu	$3,$3,$5
	lui	$5,%hi(bmaporgy)
	lw	$6,%lo(bmaporgy)($5)
	bltz	$3,$L101
	sra	$5,$3,23

	lui	$3,%hi(bmapwidth)
	lw	$3,%lo(bmapwidth)($3)
	slt	$7,$5,$3
	bne	$7,$0,$L100
	subu	$4,$4,$6

$L101:
	jr	$31
	nop

$L88:
	lw	$5,52($4)
	lw	$5,0($5)
	b	$L86
	sw	$3,72($5)

$L100:
	bltz	$4,$L101
	sra	$6,$4,23

	lui	$4,%hi(bmapheight)
	lw	$4,%lo(bmapheight)($4)
	slt	$4,$6,$4
	beq	$4,$0,$L101
	multu	$3,$6
	mflo	$4

	addu	$3,$4,$5
	lui	$4,%hi(blocklinks)
	lw	$4,%lo(blocklinks)($4)
	sll	$3,$3,2
	addu	$3,$4,$3
	jr	$31
	sw	$2,0($3)

	.set	macro
	.set	reorder
	.end	P_UnsetThingPosition
	.size	P_UnsetThingPosition, .-P_UnsetThingPosition
	.align	2
	.globl	P_SetThingPosition
	.set	nomips16
	.set	nomicromips
	.ent	P_SetThingPosition
	.type	P_SetThingPosition, @function
P_SetThingPosition:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	lw	$5,16($4)
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,12($4)
	sw	$31,20($sp)
	jal	R_PointInSubsector
	nop

	lw	$3,104($16)
	andi	$4,$3,0x8
	bne	$4,$0,$L103
	sw	$2,52($16)

	lw	$4,0($2)
	sw	$0,28($16)
	lw	$2,72($4)
	beq	$2,$0,$L104
	sw	$2,24($16)

	sw	$16,28($2)
$L104:
	sw	$16,72($4)
$L103:
	andi	$3,$3,0x10
	bne	$3,$0,$L115
	lw	$31,20($sp)

	lui	$3,%hi(bmaporgx)
	lw	$3,%lo(bmaporgx)($3)
	lw	$2,12($16)
	lui	$4,%hi(bmaporgy)
	subu	$2,$2,$3
	lw	$5,%lo(bmaporgy)($4)
	lw	$3,16($16)
	bltz	$2,$L116
	sra	$4,$2,23

	lui	$2,%hi(bmapwidth)
	lw	$2,%lo(bmapwidth)($2)
	slt	$6,$4,$2
	beq	$6,$0,$L116
	subu	$3,$3,$5

	bltz	$3,$L117
	sra	$5,$3,23

	lui	$3,%hi(bmapheight)
	lw	$3,%lo(bmapheight)($3)
	slt	$3,$5,$3
	beq	$3,$0,$L116
	multu	$2,$5
	mflo	$3

	sw	$0,48($16)
	addu	$2,$3,$4
	lui	$3,%hi(blocklinks)
	lw	$3,%lo(blocklinks)($3)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$3,0($2)
	beq	$3,$0,$L107
	sw	$3,44($16)

	sw	$16,48($3)
$L107:
	sw	$16,0($2)
	lw	$31,20($sp)
$L115:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L116:
$L117:
	sw	$0,48($16)
	sw	$0,44($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_SetThingPosition
	.size	P_SetThingPosition, .-P_SetThingPosition
	.align	2
	.globl	P_BlockLinesIterator
	.set	nomips16
	.set	nomicromips
	.ent	P_BlockLinesIterator
	.type	P_BlockLinesIterator, @function
P_BlockLinesIterator:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$2,$4,$5
	bltz	$2,$L129
	nop

	lui	$2,%hi(bmapwidth)
	lw	$2,%lo(bmapwidth)($2)
	slt	$3,$4,$2
	beq	$3,$0,$L129
	lui	$3,%hi(bmapheight)

	lw	$3,%lo(bmapheight)($3)
	slt	$3,$5,$3
	beq	$3,$0,$L129
	multu	$2,$5
	mflo	$3

	addiu	$sp,$sp,-40
	addu	$2,$3,$4
	lui	$3,%hi(blockmap)
	lw	$3,%lo(blockmap)($3)
	sll	$2,$2,1
	addu	$2,$3,$2
	lh	$2,0($2)
	lui	$3,%hi(blockmaplump)
	sw	$20,32($sp)
	lw	$20,%lo(blockmaplump)($3)
	sll	$2,$2,1
	addu	$20,$20,$2
	lh	$3,0($20)
	li	$2,-1			# 0xffffffffffffffff
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L119
	.set	at
	sw	$16,16($sp)

	move	$16,$6
	lui	$18,%hi(lines)
	lui	$17,%hi(validcount)
	li	$19,-1			# 0xffffffffffffffff
	lw	$2,%lo(lines)($18)
$L134:
	sll	$3,$3,6
	addu	$2,$2,$3
	lw	$5,56($2)
	lw	$3,%lo(validcount)($17)
	addiu	$20,$20,2
	.set	noat
	xor	$1,$5,$3
	beq	$1,$0,$L123
	.set	at
	move	$4,$2

	jalr	$16
	sw	$3,56($2)

	beq	$2,$0,$L133
	lw	$31,36($sp)

$L123:
	lh	$3,0($20)
	.set	noat
	xor	$1,$3,$19
	bne	$1,$0,$L134
	.set	at
	lw	$2,%lo(lines)($18)

$L119:
	li	$2,1			# 0x1
	lw	$31,36($sp)
$L133:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L129:
	jr	$31
	li	$2,1			# 0x1

	.set	macro
	.set	reorder
	.end	P_BlockLinesIterator
	.size	P_BlockLinesIterator, .-P_BlockLinesIterator
	.align	2
	.globl	P_BlockThingsIterator
	.set	nomips16
	.set	nomicromips
	.ent	P_BlockThingsIterator
	.type	P_BlockThingsIterator, @function
P_BlockThingsIterator:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$2,$4,$5
	bltz	$2,$L147
	nop

	lui	$2,%hi(bmapwidth)
	lw	$2,%lo(bmapwidth)($2)
	slt	$3,$4,$2
	beq	$3,$0,$L147
	lui	$3,%hi(bmapheight)

	lw	$3,%lo(bmapheight)($3)
	slt	$3,$5,$3
	beq	$3,$0,$L147
	multu	$2,$5
	mflo	$3

	addiu	$sp,$sp,-32
	addu	$2,$3,$4
	lui	$3,%hi(blocklinks)
	lw	$3,%lo(blocklinks)($3)
	sll	$2,$2,2
	addu	$2,$3,$2
	sw	$16,20($sp)
	lw	$16,0($2)
	sw	$17,24($sp)
	sw	$31,28($sp)
	bne	$16,$0,$L138
	move	$17,$6

	b	$L152
	lw	$31,28($sp)

$L151:
	lw	$16,44($16)
	beq	$16,$0,$L136
	nop

$L138:
	jalr	$17
	move	$4,$16

	bne	$2,$0,$L151
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L147:
	jr	$31
	li	$2,1			# 0x1

$L136:
$L152:
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_BlockThingsIterator
	.size	P_BlockThingsIterator, .-P_BlockThingsIterator
	.align	2
	.globl	PIT_AddThingIntercepts
	.set	nomips16
	.set	nomicromips
	.ent	PIT_AddThingIntercepts
	.type	PIT_AddThingIntercepts, @function
PIT_AddThingIntercepts:
	.frame	$sp,64,$31		# vars= 16, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$20,48($sp)
	lui	$20,%hi(trace)
	addiu	$3,$20,%lo(trace)
	lw	$2,8($3)
	sw	$18,40($sp)
	lw	$3,12($3)
	move	$18,$4
	sw	$17,36($sp)
	sw	$16,32($sp)
	lw	$17,64($4)
	lw	$16,16($18)
	lw	$4,12($4)
	xor	$2,$2,$3
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$19,44($sp)
	sw	$31,60($sp)
	subu	$19,$16,$17
	subu	$22,$4,$17
	addu	$21,$4,$17
	bgtz	$2,$L154
	addu	$16,$17,$16

	move	$2,$16
	move	$16,$19
	move	$19,$2
$L154:
	move	$5,$16
	move	$4,$22
	jal	P_PointOnDivlineSide
	addiu	$6,$20,%lo(trace)

	move	$4,$21
	addiu	$6,$20,%lo(trace)
	move	$5,$19
	jal	P_PointOnDivlineSide
	move	$21,$2

	.set	noat
	xor	$1,$21,$2
	beq	$1,$0,$L156
	.set	at
	addiu	$5,$sp,16

	sll	$17,$17,1
	subu	$19,$19,$16
	addiu	$4,$20,%lo(trace)
	sw	$22,16($sp)
	sw	$16,20($sp)
	sw	$17,24($sp)
	jal	P_InterceptVector
	sw	$19,28($sp)

	bltz	$2,$L156
	move	$5,$2

	lui	$12,%hi(intercept_p)
	lw	$10,%lo(intercept_p)($12)
	lui	$11,%hi(intercepts)
	addiu	$11,$11,%lo(intercepts)
	subu	$11,$10,$11
	slt	$2,$11,1537
	sw	$5,0($10)
	sw	$0,4($10)
	bne	$2,$0,$L158
	sw	$18,8($10)

	jal	InterceptsMemoryOverrun
	addiu	$4,$11,-1548

	lw	$5,4($10)
	jal	InterceptsMemoryOverrun
	addiu	$4,$11,-1544

	move	$5,$18
	jal	InterceptsMemoryOverrun
	addiu	$4,$11,-1540

$L158:
	addiu	$10,$10,12
	sw	$10,%lo(intercept_p)($12)
$L156:
	lw	$31,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	PIT_AddThingIntercepts
	.size	PIT_AddThingIntercepts, .-PIT_AddThingIntercepts
	.align	2
	.globl	P_TraverseIntercepts
	.set	nomips16
	.set	nomicromips
	.ent	P_TraverseIntercepts
	.type	P_TraverseIntercepts, @function
P_TraverseIntercepts:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$19,28($sp)
	lui	$19,%hi(intercept_p)
	lw	$7,%lo(intercept_p)($19)
	sw	$fp,48($sp)
	lui	$fp,%hi(intercepts)
	addiu	$fp,$fp,%lo(intercepts)
	subu	$2,$7,$fp
	li	$3,-1431699456			# 0xffffffffaaaa0000
	sra	$2,$2,2
	ori	$3,$3,0xaaab
	multu	$2,$3
	mflo	$2
	sw	$31,52($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$7,$fp
	beq	$1,$0,$L161
	.set	at
	sw	$16,16($sp)

	li	$18,2147418112			# 0x7fff0000
	move	$17,$4
	move	$16,$5
	addiu	$23,$2,-2
	move	$22,$0
	ori	$21,$18,0xffff
	li	$20,-1			# 0xffffffffffffffff
$L162:
	sltu	$2,$fp,$7
	beq	$2,$0,$L166
	ori	$3,$18,0xffff

	move	$2,$fp
	ori	$3,$18,0xffff
$L164:
	lw	$5,0($2)
	slt	$6,$5,$3
	movn	$22,$2,$6
	addiu	$2,$2,12
	sltu	$4,$2,$7
	bne	$4,$0,$L164
	movn	$3,$5,$6

$L166:
	slt	$3,$16,$3
	bne	$3,$0,$L160
	li	$2,1			# 0x1

	jalr	$17
	move	$4,$22

	beq	$2,$0,$L174
	lw	$31,52($sp)

	.set	noat
	xor	$1,$23,$20
	beq	$1,$0,$L161
	.set	at
	sw	$21,0($22)

	lw	$7,%lo(intercept_p)($19)
	b	$L162
	addiu	$23,$23,-1

$L161:
	li	$2,1			# 0x1
$L160:
	lw	$31,52($sp)
$L174:
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	P_TraverseIntercepts
	.size	P_TraverseIntercepts, .-P_TraverseIntercepts
	.align	2
	.globl	P_PathTraverse
	.set	nomips16
	.set	nomicromips
	.ent	P_PathTraverse
	.type	P_PathTraverse, @function
P_PathTraverse:
	.frame	$sp,96,$31		# vars= 40, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-96
	lui	$8,%hi(validcount)
	lui	$2,%hi(bmaporgx)
	sw	$17,60($sp)
	lw	$17,%lo(bmaporgx)($2)
	lw	$2,%lo(validcount)($8)
	lw	$9,116($sp)
	addiu	$3,$2,1
	sw	$19,68($sp)
	li	$2,8323072			# 0x7f0000
	lw	$19,112($sp)
	sw	$3,%lo(validcount)($8)
	sw	$20,72($sp)
	ori	$2,$2,0xffff
	subu	$20,$4,$17
	lui	$3,%hi(intercepts)
	andi	$10,$19,0x4
	sw	$9,52($sp)
	lui	$8,%hi(intercept_p)
	lui	$9,%hi(earlyout)
	addiu	$3,$3,%lo(intercepts)
	and	$2,$20,$2
	sw	$31,92($sp)
	sw	$fp,88($sp)
	sw	$23,84($sp)
	sw	$22,80($sp)
	sw	$21,76($sp)
	sw	$18,64($sp)
	sw	$16,56($sp)
	sw	$10,%lo(earlyout)($9)
	bne	$2,$0,$L176
	sw	$3,%lo(intercept_p)($8)

	li	$2,65536			# 0x10000
	addu	$4,$4,$2
	subu	$20,$4,$17
$L176:
	lui	$2,%hi(bmaporgy)
	lw	$8,%lo(bmaporgy)($2)
	li	$2,8323072			# 0x7f0000
	subu	$16,$5,$8
	ori	$2,$2,0xffff
	and	$2,$16,$2
	bne	$2,$0,$L177
	li	$2,65536			# 0x10000

	addu	$5,$5,$2
	subu	$16,$5,$8
$L177:
	subu	$17,$6,$17
	lui	$9,%hi(trace)
	addiu	$2,$9,%lo(trace)
	sra	$23,$20,23
	subu	$18,$6,$4
	sra	$17,$17,23
	subu	$fp,$7,$5
	subu	$21,$7,$8
	sw	$5,4($2)
	sw	$18,8($2)
	sw	$fp,12($2)
	slt	$6,$23,$17
	sra	$2,$21,23
	sw	$4,%lo(trace)($9)
	sra	$22,$16,23
	sw	$2,16($sp)
	bne	$6,$0,$L207
	sra	$20,$20,7

	slt	$2,$17,$23
	bne	$2,$0,$L208
	li	$2,16777216			# 0x1000000

	sw	$0,24($sp)
	li	$6,65536			# 0x10000
	sw	$2,20($sp)
$L179:
	lw	$5,20($sp)
	jal	FixedMul
	move	$4,$6

	lw	$3,16($sp)
	sra	$6,$16,7
	slt	$4,$22,$3
	bne	$4,$0,$L209
	addu	$16,$6,$2

$L180:
	lw	$2,16($sp)
	slt	$2,$2,$22
	bne	$2,$0,$L210
	li	$2,16777216			# 0x1000000

	sw	$0,36($sp)
	li	$fp,65536			# 0x10000
	sw	$2,32($sp)
$L181:
	lw	$5,32($sp)
	jal	FixedMul
	move	$4,$fp

	addu	$18,$2,$20
	lui	$2,%hi(PIT_AddLineIntercepts)
	addiu	$2,$2,%lo(PIT_AddLineIntercepts)
	sw	$2,28($sp)
	lui	$2,%hi(bmapwidth)
	sw	$2,40($sp)
	lui	$2,%hi(bmapheight)
	sw	$2,44($sp)
	lui	$2,%hi(blocklinks)
	andi	$20,$19,0x1
	li	$fp,64			# 0x40
	b	$L194
	sw	$2,48($sp)

$L188:
$L215:
	.set	noat
	xor	$1,$2,$22
	beq	$1,$0,$L211
	.set	at
	sra	$2,$18,16

	.set	noat
	xor	$1,$2,$23
	bne	$1,$0,$L193
	.set	at
	lw	$2,32($sp)

	addu	$18,$18,$2
	lw	$2,36($sp)
	addu	$22,$22,$2
$L193:
	addiu	$fp,$fp,-1
	beq	$fp,$0,$L214
	lw	$4,52($sp)

$L194:
	bne	$20,$0,$L182
	lw	$6,28($sp)

	andi	$2,$19,0x2
$L216:
	bne	$2,$0,$L212
	or	$2,$23,$22

$L184:
	.set	noat
	xor	$1,$17,$23
	bne	$1,$0,$L215
	.set	at
	sra	$2,$16,16

	lw	$2,16($sp)
	.set	noat
	xor	$1,$2,$22
	bne	$1,$0,$L188
	.set	at
	sra	$2,$16,16

	lw	$4,52($sp)
$L214:
	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	li	$5,65536			# 0x10000
	j	P_TraverseIntercepts
	addiu	$sp,$sp,96

$L208:
	jal	abs
	move	$4,$18

	move	$5,$2
	jal	FixedDiv
	move	$4,$fp

	sw	$2,20($sp)
	andi	$6,$20,0xffff
	lw	$5,20($sp)
	move	$4,$6
	li	$2,-1			# 0xffffffffffffffff
	jal	FixedMul
	sw	$2,24($sp)

	lw	$3,16($sp)
	sra	$6,$16,7
	slt	$4,$22,$3
	beq	$4,$0,$L180
	addu	$16,$6,$2

$L209:
	move	$4,$fp
	andi	$6,$6,0xffff
	li	$2,65536			# 0x10000
	jal	abs
	subu	$fp,$2,$6

	move	$5,$2
	jal	FixedDiv
	move	$4,$18

	sw	$2,32($sp)
	li	$2,1			# 0x1
	b	$L181
	sw	$2,36($sp)

$L211:
	lw	$2,20($sp)
	addu	$16,$16,$2
	lw	$2,24($sp)
	b	$L193
	addu	$23,$23,$2

$L182:
	move	$5,$22
	jal	P_BlockLinesIterator
	move	$4,$23

	bne	$2,$0,$L216
	andi	$2,$19,0x2

	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,96

$L212:
	bltz	$2,$L184
	lw	$2,40($sp)

	lw	$2,%lo(bmapwidth)($2)
	slt	$4,$23,$2
	beq	$4,$0,$L184
	lw	$3,44($sp)

	lw	$4,%lo(bmapheight)($3)
	slt	$4,$22,$4
	beq	$4,$0,$L184
	multu	$2,$22
	mflo	$3

	addu	$2,$3,$23
	lw	$3,48($sp)
	sll	$2,$2,2
	lw	$4,%lo(blocklinks)($3)
	addu	$2,$4,$2
	lw	$21,0($2)
	bne	$21,$0,$L190
	nop

	b	$L184
	nop

$L213:
	lw	$21,44($21)
	beq	$21,$0,$L184
	nop

$L190:
	jal	PIT_AddThingIntercepts
	move	$4,$21

	bne	$2,$0,$L213
	lw	$31,92($sp)

	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,96

$L207:
	andi	$2,$20,0xffff
	li	$6,65536			# 0x10000
	subu	$6,$6,$2
	move	$4,$18
	jal	abs
	sw	$6,28($sp)

	move	$5,$2
	jal	FixedDiv
	move	$4,$fp

	sw	$2,20($sp)
	li	$2,1			# 0x1
	lw	$6,28($sp)
	b	$L179
	sw	$2,24($sp)

$L210:
	move	$4,$fp
	jal	abs
	sw	$6,28($sp)

	move	$5,$2
	jal	FixedDiv
	move	$4,$18

	lw	$6,28($sp)
	sw	$2,32($sp)
	li	$2,-1			# 0xffffffffffffffff
	andi	$fp,$6,0xffff
	b	$L181
	sw	$2,36($sp)

	.set	macro
	.set	reorder
	.end	P_PathTraverse
	.size	P_PathTraverse, .-P_PathTraverse
	.rdata
	.align	2
	.type	intercepts_overrun, @object
	.size	intercepts_overrun, 276
intercepts_overrun:
	.word	4
	.word	0
	.word	0
	.word	4
	.word	0
	.word	0
	.word	4
	.word	0
	.word	0
	.word	4
	.word	lowfloor
	.word	0
	.word	4
	.word	openbottom
	.word	0
	.word	4
	.word	opentop
	.word	0
	.word	4
	.word	openrange
	.word	0
	.word	4
	.word	0
	.word	0
	.word	120
	.word	0
	.word	0
	.word	8
	.word	0
	.word	0
	.word	4
	.word	bulletslope
	.word	0
	.word	4
	.word	0
	.word	0
	.word	4
	.word	0
	.word	0
	.word	4
	.word	0
	.word	0
	.word	40
	.word	playerstarts
	.word	1
	.word	4
	.word	0
	.word	0
	.word	4
	.word	bmapwidth
	.word	0
	.word	4
	.word	0
	.word	0
	.word	4
	.word	bmaporgx
	.word	0
	.word	4
	.word	bmaporgy
	.word	0
	.word	4
	.word	0
	.word	0
	.word	4
	.word	bmapheight
	.word	0
	.word	0
	.word	0
	.word	0
	.globl	ptflags
	.section	.bss,"aw",@nobits
	.align	2
	.type	ptflags, @object
	.size	ptflags, 4
ptflags:
	.space	4
	.globl	earlyout
	.align	2
	.type	earlyout, @object
	.size	earlyout, 4
earlyout:
	.space	4
	.globl	trace
	.align	2
	.type	trace, @object
	.size	trace, 16
trace:
	.space	16
	.globl	intercept_p
	.align	2
	.type	intercept_p, @object
	.size	intercept_p, 4
intercept_p:
	.space	4
	.globl	intercepts
	.align	2
	.type	intercepts, @object
	.size	intercepts, 2268
intercepts:
	.space	2268
	.globl	lowfloor
	.align	2
	.type	lowfloor, @object
	.size	lowfloor, 4
lowfloor:
	.space	4
	.globl	openrange
	.align	2
	.type	openrange, @object
	.size	openrange, 4
openrange:
	.space	4
	.globl	openbottom
	.align	2
	.type	openbottom, @object
	.size	openbottom, 4
openbottom:
	.space	4
	.globl	opentop
	.align	2
	.type	opentop, @object
	.size	opentop, 4
opentop:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
