	.file	1 "p_mobj.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_SpawnMobj
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnMobj
	.type	P_SpawnMobj, @function
P_SpawnMobj:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$18,24($sp)
	move	$22,$4
	move	$21,$5
	li	$4,156			# 0x9c
	li	$5,5			# 0x5
	move	$18,$6
	move	$6,$0
	sw	$31,44($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	move	$20,$7
	sw	$17,20($sp)
	jal	Z_Malloc
	sw	$16,16($sp)

	move	$4,$2
	li	$6,156			# 0x9c
	move	$5,$0
	sll	$17,$20,1
	jal	memset
	move	$16,$2

	addu	$2,$17,$20
	sll	$2,$2,3
	subu	$2,$2,$20
	sll	$2,$2,2
	lui	$19,%hi(mobjinfo)
	addiu	$19,$19,%lo(mobjinfo)
	addiu	$3,$2,64
	addu	$3,$19,$3
	lw	$5,0($3)
	lw	$4,4($3)
	addiu	$3,$2,80
	sw	$4,68($16)
	addu	$3,$19,$3
	sw	$5,64($16)
	lw	$5,-72($3)
	lw	$6,4($3)
	lui	$3,%hi(gameskill)
	lw	$4,%lo(gameskill)($3)
	addu	$2,$19,$2
	li	$3,4			# 0x4
	sw	$20,88($16)
	sw	$2,92($16)
	sw	$22,12($16)
	sw	$21,16($16)
	sw	$6,104($16)
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L2
	.set	at
	sw	$5,108($16)

	lw	$2,20($2)
	sw	$2,124($16)
$L2:
	jal	P_Random
	nop

	li	$3,-2147483648			# 0xffffffff80000000
	addiu	$3,$3,3
	and	$2,$2,$3
	bgez	$2,$L3
	li	$3,-4			# 0xfffffffffffffffc

	addiu	$2,$2,-1
	or	$2,$2,$3
	addiu	$2,$2,1
$L3:
	addu	$17,$17,$20
	sll	$17,$17,3
	subu	$17,$17,$20
	sll	$17,$17,2
	addu	$19,$19,$17
	lw	$3,4($19)
	sll	$4,$3,3
	subu	$4,$4,$3
	lui	$3,%hi(states)
	sll	$4,$4,2
	addiu	$3,$3,%lo(states)
	addu	$3,$3,$4
	lw	$5,0($3)
	lw	$4,4($3)
	lw	$6,8($3)
	sw	$2,136($16)
	sw	$3,100($16)
	sw	$5,36($16)
	sw	$4,40($16)
	sw	$6,96($16)
	jal	P_SetThingPosition
	move	$4,$16

	lw	$2,52($16)
	li	$5,-2147483648			# 0xffffffff80000000
	lw	$2,0($2)
	lw	$3,0($2)
	lw	$4,4($2)
	sw	$3,56($16)
	.set	noat
	xor	$1,$18,$5
	beq	$1,$0,$L5
	.set	at
	sw	$4,60($16)

	li	$2,2147418112			# 0x7fff0000
	ori	$2,$2,0xffff
	.set	noat
	xor	$1,$18,$2
	beq	$1,$0,$L8
	.set	at
	nop

$L4:
	lui	$2,%hi(P_MobjThinker)
	addiu	$2,$2,%lo(P_MobjThinker)
	sw	$18,20($16)
	sw	$2,8($16)
	jal	P_AddThinker
	move	$4,$16

	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L8:
	lw	$2,92($16)
	lw	$18,68($2)
	b	$L4
	subu	$18,$4,$18

$L5:
	b	$L4
	move	$18,$3

	.set	macro
	.set	reorder
	.end	P_SpawnMobj
	.size	P_SpawnMobj, .-P_SpawnMobj
	.align	2
	.globl	P_RemoveMobj
	.set	nomips16
	.set	nomicromips
	.ent	P_RemoveMobj
	.type	P_RemoveMobj, @function
P_RemoveMobj:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($4)
	li	$3,131072			# 0x20000
	addiu	$3,$3,1
	addiu	$sp,$sp,-24
	and	$2,$2,$3
	li	$3,1			# 0x1
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L14
	.set	at
	move	$16,$4

$L11:
	jal	P_UnsetThingPosition
	move	$4,$16

	jal	S_StopSound
	move	$4,$16

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	P_RemoveThinker
	addiu	$sp,$sp,24

$L14:
	lw	$2,88($4)
	li	$3,-3			# 0xfffffffffffffffd
	and	$2,$2,$3
	li	$3,56			# 0x38
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L11
	.set	at
	lui	$6,%hi(iquehead)

	lw	$3,%lo(iquehead)($6)
	lui	$5,%hi(itemrespawnque)
	sll	$4,$3,2
	addu	$2,$4,$3
	lw	$7,140($16)
	addiu	$5,$5,%lo(itemrespawnque)
	sll	$2,$2,1
	addu	$2,$2,$5
	lw	$5,144($16)
	swl	$7,3($2)
	swr	$7,0($2)
	swl	$5,7($2)
	swr	$5,4($2)
	lui	$5,%hi(leveltime)
	lw	$9,%lo(leveltime)($5)
	lui	$7,%hi(iquetail)
	lui	$5,%hi(itemrespawntime)
	lhu	$10,148($16)
	addiu	$3,$3,1
	addiu	$5,$5,%lo(itemrespawntime)
	lw	$8,%lo(iquetail)($7)
	addu	$4,$4,$5
	andi	$3,$3,0x7f
	sh	$10,8($2)
	sw	$9,0($4)
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L11
	.set	at
	sw	$3,%lo(iquehead)($6)

	addiu	$3,$3,1
	andi	$3,$3,0x7f
	b	$L11
	sw	$3,%lo(iquetail)($7)

	.set	macro
	.set	reorder
	.end	P_RemoveMobj
	.size	P_RemoveMobj, .-P_RemoveMobj
	.align	2
	.globl	P_SetMobjState
	.set	nomips16
	.set	nomicromips
	.ent	P_SetMobjState
	.type	P_SetMobjState, @function
P_SetMobjState:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$19,32($sp)
	lui	$19,%hi(states)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$31,36($sp)
	sw	$16,20($sp)
	move	$17,$4
	move	$18,$5
	b	$L19
	addiu	$19,$19,%lo(states)

$L16:
	lw	$3,8($2)
	lw	$7,0($2)
	lw	$6,4($2)
	lw	$5,12($2)
	sw	$3,96($17)
	sw	$2,100($17)
	sw	$7,36($17)
	beq	$5,$0,$L18
	sw	$6,40($17)

	jalr	$5
	nop

	lw	$3,96($17)
$L18:
	subu	$16,$16,$18
	sll	$16,$16,2
	addu	$16,$19,$16
	bne	$3,$0,$L26
	lw	$18,16($16)

$L19:
	sll	$16,$18,3
	subu	$2,$16,$18
	sll	$2,$2,2
	addu	$2,$19,$2
	bne	$18,$0,$L16
	move	$4,$17

	jal	P_RemoveMobj
	sw	$0,100($17)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

$L26:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_SetMobjState
	.size	P_SetMobjState, .-P_SetMobjState
	.align	2
	.globl	P_ExplodeMissile
	.set	nomips16
	.set	nomicromips
	.ent	P_ExplodeMissile
	.type	P_ExplodeMissile, @function
P_ExplodeMissile:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,88($4)
	addiu	$sp,$sp,-24
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	lui	$3,%hi(mobjinfo)
	addiu	$3,$3,%lo(mobjinfo)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$5,48($2)
	sw	$31,20($sp)
	sw	$16,16($sp)
	move	$16,$4
	sw	$0,80($4)
	sw	$0,76($4)
	jal	P_SetMobjState
	sw	$0,72($4)

	jal	P_Random
	nop

	lw	$3,96($16)
	andi	$2,$2,0x3
	subu	$2,$3,$2
	slt	$5,$0,$2
	li	$3,1			# 0x1
	movz	$2,$3,$5
	lw	$4,92($16)
	lw	$3,104($16)
	sw	$2,96($16)
	li	$2,-131072			# 0xfffffffffffe0000
	lw	$5,56($4)
	ori	$2,$2,0xffff
	and	$2,$3,$2
	bne	$5,$0,$L30
	sw	$2,104($16)

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L30:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	S_StartSound
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_ExplodeMissile
	.size	P_ExplodeMissile, .-P_ExplodeMissile
	.align	2
	.globl	P_ZMovement
	.set	nomips16
	.set	nomicromips
	.ent	P_ZMovement
	.type	P_ZMovement, @function
P_ZMovement:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,132($4)
	addiu	$sp,$sp,-32
	lw	$3,20($4)
	sw	$16,20($sp)
	sw	$31,28($sp)
	sw	$17,24($sp)
	beq	$2,$0,$L32
	move	$16,$4

	lw	$4,56($4)
	slt	$5,$3,$4
	bne	$5,$0,$L86
	subu	$4,$4,$3

$L32:
	lw	$4,80($16)
	lw	$2,104($16)
	addu	$3,$3,$4
	andi	$4,$2,0x4000
	beq	$4,$0,$L33
	sw	$3,20($16)

	lw	$6,120($16)
	beq	$6,$0,$L33
	li	$4,18874368			# 0x1200000

	and	$2,$2,$4
	beq	$2,$0,$L87
	nop

$L33:
	lw	$2,56($16)
	slt	$4,$2,$3
	bne	$4,$0,$L35
	nop

	lui	$3,%hi(gameversion)
	lw	$17,%lo(gameversion)($3)
	sltu	$17,$17,6
	bne	$17,$0,$L36
	lw	$3,80($16)

	lw	$4,104($16)
	li	$5,16777216			# 0x1000000
	and	$4,$4,$5
	beq	$4,$0,$L37
	subu	$4,$0,$3

	bgtz	$3,$L60
	sw	$4,80($16)

$L85:
	b	$L39
	sw	$2,20($16)

$L35:
	lw	$5,104($16)
	lw	$4,68($16)
	andi	$6,$5,0x200
	bne	$6,$0,$L44
	lw	$2,60($16)

	lw	$6,80($16)
	bne	$6,$0,$L46
	nop

	addu	$3,$3,$4
	li	$6,-131072			# 0xfffffffffffe0000
	slt	$3,$2,$3
	bne	$3,$0,$L47
	sw	$6,80($16)

$L31:
	lw	$31,28($sp)
$L93:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L36:
	bltz	$3,$L40
	nop

$L84:
	sw	$2,20($16)
	lw	$2,104($16)
$L91:
	li	$3,16777216			# 0x1000000
	and	$2,$2,$3
	beq	$2,$0,$L39
	nop

	lw	$2,80($16)
	subu	$2,$0,$2
	sw	$2,80($16)
$L39:
	lw	$2,104($16)
	li	$3,65536			# 0x10000
	addiu	$4,$3,4096
	and	$2,$2,$4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L92
	.set	at
	lw	$31,28($sp)

	lw	$3,20($16)
	lw	$4,68($16)
	lw	$2,60($16)
$L44:
	addu	$3,$4,$3
	slt	$3,$2,$3
	beq	$3,$0,$L93
	lw	$31,28($sp)

	lw	$3,80($16)
$L90:
	blez	$3,$L47
	lw	$5,104($16)

	sw	$0,80($16)
$L47:
	li	$3,16777216			# 0x1000000
	subu	$2,$2,$4
	and	$3,$5,$3
	beq	$3,$0,$L52
	sw	$2,20($16)

	lw	$2,80($16)
	subu	$2,$0,$2
	sw	$2,80($16)
$L52:
	li	$2,65536			# 0x10000
	addiu	$3,$2,4096
	and	$5,$5,$3
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L93
	.set	at
	lw	$31,28($sp)

$L92:
	lw	$17,24($sp)
	move	$4,$16
	lw	$16,20($sp)
	j	P_ExplodeMissile
	addiu	$sp,$sp,32

$L86:
	lw	$5,28($2)
	subu	$5,$5,$4
	li	$4,2686976			# 0x290000
	subu	$4,$4,$5
	sra	$4,$4,3
	sw	$5,28($2)
	b	$L32
	sw	$4,32($2)

$L46:
	li	$5,-65536			# 0xffffffffffff0000
	addu	$3,$4,$3
	addu	$6,$6,$5
	slt	$3,$2,$3
	beq	$3,$0,$L31
	sw	$6,80($16)

	b	$L90
	lw	$3,80($16)

$L37:
	bgez	$3,$L85
	nop

$L38:
	lw	$4,132($16)
	beq	$4,$0,$L79
	li	$5,-524288			# 0xfffffffffff80000

	slt	$5,$3,$5
	bne	$5,$0,$L94
	sra	$3,$3,3

$L79:
	sw	$0,80($16)
	b	$L39
	sw	$2,20($16)

$L87:
	lw	$3,16($6)
	lw	$5,16($16)
	lw	$4,12($16)
	lw	$2,12($6)
	subu	$5,$5,$3
	jal	P_AproxDistance
	subu	$4,$4,$2

	lw	$3,120($16)
	lw	$4,68($16)
	lw	$5,20($3)
	sra	$4,$4,1
	lw	$3,20($16)
	addu	$4,$4,$5
	subu	$4,$4,$3
	bltz	$4,$L89
	sll	$5,$4,2

	beq	$4,$0,$L33
	sll	$5,$4,1

	addu	$4,$5,$4
	slt	$2,$2,$4
	beq	$2,$0,$L33
	li	$2,262144			# 0x40000

	addu	$3,$3,$2
	b	$L33
	sw	$3,20($16)

$L40:
	lw	$4,132($16)
	beq	$4,$0,$L82
	li	$5,-524288			# 0xfffffffffff80000

	slt	$5,$3,$5
	beq	$5,$0,$L82
	sra	$3,$3,3

$L94:
	sw	$3,32($4)
	li	$5,34			# 0x22
	jal	S_StartSound
	move	$4,$16

	lw	$2,56($16)
	sw	$0,80($16)
	beq	$17,$0,$L39
	sw	$2,20($16)

	b	$L91
	lw	$2,104($16)

$L60:
	b	$L38
	move	$3,$4

$L89:
	subu	$4,$4,$5
	slt	$4,$2,$4
	beq	$4,$0,$L33
	li	$2,-262144			# 0xfffffffffffc0000

	addu	$3,$3,$2
	b	$L33
	sw	$3,20($16)

$L82:
	b	$L84
	sw	$0,80($16)

	.set	macro
	.set	reorder
	.end	P_ZMovement
	.size	P_ZMovement, .-P_ZMovement
	.align	2
	.globl	P_XYMovement
	.set	nomips16
	.set	nomicromips
	.ent	P_XYMovement
	.type	P_XYMovement, @function
P_XYMovement:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$16,20($sp)
	lw	$16,72($4)
	sw	$23,48($sp)
	sw	$22,44($sp)
	lw	$23,76($4)
	sw	$31,52($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	bne	$16,$0,$L96
	move	$22,$4

	beq	$23,$0,$L97
	li	$3,1966080			# 0x1e0000

	addiu	$2,$3,1
	slt	$2,$23,$2
	beq	$2,$0,$L146
	lw	$21,132($4)

	li	$2,-1966080			# 0xffffffffffe20000
$L154:
	slt	$3,$23,$2
	beq	$3,$0,$L153
	li	$17,983040			# 0xf0000

	sw	$2,76($22)
	b	$L153
	li	$23,-1966080			# 0xffffffffffe20000

$L96:
	li	$3,1966080			# 0x1e0000
	addiu	$2,$3,1
	slt	$2,$16,$2
	bne	$2,$0,$L101
	lw	$21,132($4)

	sw	$3,72($4)
	li	$16,1966080			# 0x1e0000
	li	$3,1966080			# 0x1e0000
$L158:
	addiu	$2,$3,1
	slt	$2,$23,$2
	bne	$2,$0,$L154
	li	$2,-1966080			# 0xffffffffffe20000

$L146:
	sw	$3,76($22)
	li	$23,1966080			# 0x1e0000
	li	$17,983040			# 0xf0000
$L153:
	addiu	$17,$17,1
	li	$18,65536			# 0x10000
	lui	$19,%hi(ceilingline)
	lui	$20,%hi(skyflatnum)
	slt	$2,$16,$17
$L155:
	lw	$5,12($22)
	bne	$2,$0,$L105
	lw	$6,16($22)

	srl	$2,$16,31
$L156:
	srl	$3,$23,31
	addu	$2,$2,$16
	addu	$3,$3,$23
	sra	$2,$2,1
	sra	$3,$3,1
	addu	$6,$3,$6
	addu	$5,$2,$5
	jal	P_TryMove
	move	$4,$22

	sra	$16,$16,1
	beq	$2,$0,$L147
	sra	$23,$23,1

$L109:
	bne	$16,$0,$L155
	slt	$2,$16,$17

	beq	$23,$0,$L114
	nop

	lw	$5,12($22)
	lw	$6,16($22)
$L105:
	slt	$2,$23,$17
	beq	$2,$0,$L156
	srl	$2,$16,31

	addu	$6,$23,$6
	addu	$5,$5,$16
	jal	P_TryMove
	move	$4,$22

	bne	$2,$0,$L114
	nop

	lw	$2,132($22)
	beq	$2,$0,$L125
	move	$16,$0

	jal	P_SlideMove
	move	$4,$22

$L114:
	beq	$21,$0,$L112
	nop

	lw	$2,204($21)
	andi	$2,$2,0x4
	bne	$2,$0,$L148
	lw	$31,52($sp)

$L112:
	lw	$3,104($22)
	li	$2,16842752			# 0x1010000
	and	$2,$3,$2
	bne	$2,$0,$L157
	lw	$31,52($sp)

	lw	$5,56($22)
	lw	$2,20($22)
	slt	$2,$5,$2
	bne	$2,$0,$L157
	li	$2,1048576			# 0x100000

	and	$3,$3,$2
	bne	$3,$0,$L149
	lw	$4,72($22)

	addiu	$2,$4,4095
$L152:
	sltu	$2,$2,8191
	beq	$2,$0,$L123
	nop

	lw	$2,76($22)
	addiu	$2,$2,4095
	sltu	$2,$2,8191
	beq	$2,$0,$L123
	nop

	beq	$21,$0,$L124
	nop

	lhu	$2,8($21)
	bne	$2,$0,$L123
	lui	$3,%hi(states)

	lw	$4,0($21)
	lw	$2,100($4)
	addiu	$3,$3,%lo(states)
	subu	$2,$2,$3
	li	$3,-1227161600			# 0xffffffffb6db0000
	sra	$2,$2,2
	addiu	$3,$3,28087
	multu	$2,$3
	mflo	$2
	addiu	$2,$2,-150
	sltu	$2,$2,4
	bne	$2,$0,$L150
	nop

$L124:
	sw	$0,72($22)
	sw	$0,76($22)
$L95:
	lw	$31,52($sp)
$L157:
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L147:
	lw	$2,132($22)
	beq	$2,$0,$L113
	nop

	jal	P_SlideMove
	move	$4,$22

	b	$L109
	nop

$L125:
	move	$23,$0
$L113:
	lw	$2,104($22)
	and	$2,$2,$18
	beq	$2,$0,$L115
	lw	$2,%lo(ceilingline)($19)

	beq	$2,$0,$L116
	nop

	lw	$2,52($2)
	beq	$2,$0,$L116
	nop

	lh	$3,10($2)
	lw	$2,%lo(skyflatnum)($20)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L151
	.set	at
	lw	$31,52($sp)

$L116:
	jal	P_ExplodeMissile
	move	$4,$22

	b	$L109
	nop

$L115:
	sw	$0,76($22)
	b	$L109
	sw	$0,72($22)

$L97:
	lw	$3,104($4)
	li	$2,16777216			# 0x1000000
	and	$2,$3,$2
	beq	$2,$0,$L157
	lw	$31,52($sp)

	lw	$5,92($4)
	li	$2,-16842752			# 0xfffffffffeff0000
	ori	$2,$2,0xffff
	lw	$5,4($5)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	and	$3,$3,$2
	sw	$3,104($4)
	sw	$0,80($4)
	j	P_SetMobjState
	addiu	$sp,$sp,56

$L149:
	addiu	$2,$4,16384
	li	$3,32769			# 0x8001
	sltu	$2,$2,$3
	bne	$2,$0,$L122
	nop

	lw	$2,52($22)
	lw	$2,0($2)
	lw	$2,0($2)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L157
	.set	at
	lw	$31,52($sp)

$L123:
	jal	FixedMul
	li	$5,59392			# 0xe800

	lw	$4,76($22)
	sw	$2,72($22)
	jal	FixedMul
	li	$5,59392			# 0xe800

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$2,76($22)
	lw	$22,44($sp)
	jr	$31
	addiu	$sp,$sp,56

$L101:
	li	$2,-1966080			# 0xffffffffffe20000
	slt	$3,$16,$2
	beq	$3,$0,$L158
	li	$3,1966080			# 0x1e0000

	sw	$2,72($4)
	b	$L158
	li	$16,-1966080			# 0xffffffffffe20000

$L148:
	lw	$23,48($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$0,76($22)
	sw	$0,72($22)
	lw	$22,44($sp)
	jr	$31
	addiu	$sp,$sp,56

$L151:
	lw	$23,48($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$22
	lw	$22,44($sp)
	j	P_RemoveMobj
	addiu	$sp,$sp,56

$L122:
	lw	$2,76($22)
	addiu	$2,$2,16384
	sltu	$2,$2,$3
	bne	$2,$0,$L152
	addiu	$2,$4,4095

	lw	$2,52($22)
	lw	$2,0($2)
	lw	$2,0($2)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L157
	.set	at
	lw	$31,52($sp)

	b	$L152
	addiu	$2,$4,4095

$L150:
	jal	P_SetMobjState
	li	$5,149			# 0x95

	sw	$0,72($22)
	b	$L95
	sw	$0,76($22)

	.set	macro
	.set	reorder
	.end	P_XYMovement
	.size	P_XYMovement, .-P_XYMovement
	.align	2
	.globl	P_NightmareRespawn
	.set	nomips16
	.set	nomicromips
	.ent	P_NightmareRespawn
	.type	P_NightmareRespawn, @function
P_NightmareRespawn:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	lh	$18,142($4)
	lh	$17,140($4)
	sll	$18,$18,16
	sll	$17,$17,16
	move	$6,$18
	move	$5,$17
	sw	$16,16($sp)
	sw	$31,28($sp)
	jal	P_CheckPosition
	move	$16,$4

	bne	$2,$0,$L168
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L168:
	lw	$2,52($16)
	lw	$5,16($16)
	lw	$2,0($2)
	lw	$4,12($16)
	lw	$6,0($2)
	jal	P_SpawnMobj
	li	$7,39			# 0x27

	move	$4,$2
	jal	S_StartSound
	li	$5,35			# 0x23

	move	$5,$18
	jal	R_PointInSubsector
	move	$4,$17

	lw	$2,0($2)
	move	$5,$18
	lw	$6,0($2)
	move	$4,$17
	jal	P_SpawnMobj
	li	$7,39			# 0x27

	move	$4,$2
	jal	S_StartSound
	li	$5,35			# 0x23

	lw	$2,92($16)
	lw	$2,84($2)
	andi	$2,$2,0x100
	beq	$2,$0,$L161
	li	$6,-2147483648			# 0xffffffff80000000

	li	$6,2147418112			# 0x7fff0000
	ori	$6,$6,0xffff
$L161:
	lw	$7,88($16)
	move	$5,$18
	jal	P_SpawnMobj
	move	$4,$17

	lw	$4,140($16)
	lw	$3,144($16)
	sw	$4,140($2)
	sw	$3,144($2)
	lhu	$3,148($16)
	sh	$3,148($2)
	lbu	$4,145($16)
	lbu	$3,144($16)
	sll	$4,$4,8
	or	$4,$4,$3
	sll	$4,$4,16
	li	$3,-1240793088			# 0xffffffffb60b0000
	sra	$4,$4,16
	addiu	$3,$3,24759
	mult	$4,$3
	sra	$5,$4,31
	mfhi	$3
	addu	$3,$3,$4
	sra	$3,$3,5
	subu	$3,$3,$5
	sll	$3,$3,29
	sw	$3,32($2)
	lbu	$3,148($16)
	andi	$3,$3,0x8
	beq	$3,$0,$L169
	lw	$31,28($sp)

	lw	$3,104($2)
	ori	$3,$3,0x20
	sw	$3,104($2)
	lw	$31,28($sp)
$L169:
	lw	$18,24($sp)
	lw	$17,20($sp)
	li	$3,18			# 0x12
	move	$4,$16
	lw	$16,16($sp)
	sw	$3,124($2)
	j	P_RemoveMobj
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_NightmareRespawn
	.size	P_NightmareRespawn, .-P_NightmareRespawn
	.align	2
	.globl	P_MobjThinker
	.set	nomips16
	.set	nomicromips
	.ent	P_MobjThinker
	.type	P_MobjThinker, @function
P_MobjThinker:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,72($4)
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	bne	$2,$0,$L171
	move	$16,$4

	lw	$2,76($4)
	beq	$2,$0,$L189
	li	$3,16777216			# 0x1000000

$L171:
	jal	P_XYMovement
	move	$4,$16

	lw	$3,8($16)
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L193
	.set	at
	lw	$31,20($sp)

	lw	$3,20($16)
$L192:
	lw	$2,56($16)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L172
	.set	at
	nop

	lw	$2,80($16)
	beq	$2,$0,$L179
	nop

$L172:
	jal	P_ZMovement
	move	$4,$16

	lw	$3,8($16)
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L193
	.set	at
	lw	$31,20($sp)

$L179:
	lw	$2,96($16)
	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L190
	.set	at
	addiu	$2,$2,-1

	beq	$2,$0,$L191
	sw	$2,96($16)

$L170:
	lw	$31,20($sp)
$L193:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L189:
	lw	$2,104($4)
	and	$2,$2,$3
	bne	$2,$0,$L171
	nop

	b	$L192
	lw	$3,20($16)

$L190:
	lw	$2,104($16)
	li	$3,4194304			# 0x400000
	and	$2,$2,$3
	beq	$2,$0,$L170
	lui	$2,%hi(respawnmonsters)

	lw	$2,%lo(respawnmonsters)($2)
	beq	$2,$0,$L193
	lw	$31,20($sp)

	lw	$2,116($16)
	addiu	$2,$2,1
	slt	$3,$2,420
	bne	$3,$0,$L170
	sw	$2,116($16)

	lui	$2,%hi(leveltime)
	lw	$2,%lo(leveltime)($2)
	andi	$2,$2,0x1f
	bne	$2,$0,$L193
	lw	$31,20($sp)

	jal	P_Random
	nop

	slt	$2,$2,5
	beq	$2,$0,$L193
	lw	$31,20($sp)

	move	$4,$16
	lw	$16,16($sp)
	j	P_NightmareRespawn
	addiu	$sp,$sp,24

$L191:
	lw	$2,100($16)
	lw	$31,20($sp)
	lw	$5,16($2)
	move	$4,$16
	lw	$16,16($sp)
	j	P_SetMobjState
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_MobjThinker
	.size	P_MobjThinker, .-P_MobjThinker
	.align	2
	.globl	P_RespawnSpecials
	.set	nomips16
	.set	nomicromips
	.ent	P_RespawnSpecials
	.type	P_RespawnSpecials, @function
P_RespawnSpecials:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(deathmatch)
	lw	$3,%lo(deathmatch)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L209
	.set	at
	lui	$2,%hi(iquehead)

	addiu	$sp,$sp,-48
	sw	$17,20($sp)
	lui	$17,%hi(iquetail)
	sw	$21,36($sp)
	lw	$2,%lo(iquehead)($2)
	lw	$21,%lo(iquetail)($17)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	.set	noat
	xor	$1,$2,$21
	beq	$1,$0,$L194
	.set	at
	sw	$16,16($sp)

	lui	$3,%hi(itemrespawntime)
	sll	$20,$21,2
	addiu	$3,$3,%lo(itemrespawntime)
	addu	$3,$3,$20
	lui	$2,%hi(leveltime)
	lw	$2,%lo(leveltime)($2)
	lw	$3,0($3)
	subu	$2,$2,$3
	slt	$2,$2,1050
	beq	$2,$0,$L206
	lui	$3,%hi(itemrespawnque)

$L194:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L209:
	jr	$31
	nop

$L206:
	addu	$22,$20,$21
	addiu	$16,$3,%lo(itemrespawnque)
	sll	$22,$22,1
	addu	$22,$16,$22
	lh	$18,0($22)
	lh	$19,2($22)
	sll	$18,$18,16
	sll	$19,$19,16
	move	$5,$19
	jal	R_PointInSubsector
	move	$4,$18

	lw	$2,0($2)
	li	$7,40			# 0x28
	lw	$6,0($2)
	move	$5,$19
	jal	P_SpawnMobj
	move	$4,$18

	move	$4,$2
	jal	S_StartSound
	li	$5,90			# 0x5a

	lui	$4,%hi(mobjinfo)
	addiu	$4,$4,%lo(mobjinfo)
	lh	$7,6($22)
	move	$3,$4
	move	$2,$0
	b	$L197
	li	$8,137			# 0x89

$L208:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L207
	.set	at
	nop

$L197:
	lw	$6,0($3)
	.set	noat
	xor	$1,$7,$6
	bne	$1,$0,$L208
	.set	at
	addiu	$3,$3,92

	move	$7,$2
$L198:
	sll	$3,$2,1
	addu	$3,$3,$2
	sll	$3,$3,3
	subu	$2,$3,$2
	sll	$2,$2,2
	addu	$4,$4,$2
	lw	$2,84($4)
	andi	$2,$2,0x100
	beq	$2,$0,$L199
	li	$6,-2147483648			# 0xffffffff80000000

	li	$6,2147418112			# 0x7fff0000
	ori	$6,$6,0xffff
$L199:
	addu	$20,$20,$21
	move	$5,$19
	move	$4,$18
	jal	P_SpawnMobj
	sll	$20,$20,1

	addu	$3,$16,$20
	lwl	$5,3($3)
	lwl	$4,7($3)
	lwr	$5,0($3)
	lwr	$4,4($3)
	sw	$5,140($2)
	sw	$4,144($2)
	lhu	$4,8($3)
	lw	$31,44($sp)
	sh	$4,148($2)
	lh	$5,4($3)
	li	$3,-1240793088			# 0xffffffffb60b0000
	addiu	$3,$3,24759
	mult	$5,$3
	lw	$4,%lo(iquetail)($17)
	mfhi	$3
	addiu	$4,$4,1
	addu	$3,$3,$5
	sra	$3,$3,5
	sra	$5,$5,31
	subu	$3,$3,$5
	sll	$3,$3,29
	andi	$4,$4,0x7f
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$3,32($2)
	sw	$4,%lo(iquetail)($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L207:
	b	$L198
	li	$7,137			# 0x89

	.set	macro
	.set	reorder
	.end	P_RespawnSpecials
	.size	P_RespawnSpecials, .-P_RespawnSpecials
	.align	2
	.globl	P_SpawnPlayer
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnPlayer
	.type	P_SpawnPlayer, @function
P_SpawnPlayer:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lbu	$2,7($4)
	lbu	$3,6($4)
	sll	$2,$2,8
	or	$2,$2,$3
	beq	$2,$0,$L230
	nop

	addiu	$sp,$sp,-40
	sw	$19,28($sp)
	sll	$19,$2,16
	sra	$19,$19,16
	addiu	$19,$19,-1
	lui	$3,%hi(playeringame)
	sll	$2,$19,2
	addiu	$3,$3,%lo(playeringame)
	addu	$2,$2,$3
	lw	$2,0($2)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	beq	$2,$0,$L210
	sw	$16,16($sp)

	sll	$20,$19,3
	addu	$18,$20,$19
	lui	$17,%hi(players)
	sll	$18,$18,5
	addiu	$17,$17,%lo(players)
	addu	$18,$17,$18
	lw	$3,4($18)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L227
	.set	at
	move	$16,$4

	lbu	$5,3($16)
$L229:
	lbu	$4,1($16)
	lbu	$3,2($16)
	lbu	$2,0($16)
	sll	$5,$5,8
	sll	$4,$4,8
	or	$5,$5,$3
	or	$4,$4,$2
	sll	$4,$4,16
	move	$7,$0
	li	$6,-2147483648			# 0xffffffff80000000
	jal	P_SpawnMobj
	sll	$5,$5,16

	lbu	$3,7($16)
	lbu	$4,6($16)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$4,$3,2
	bne	$4,$0,$L215
	addiu	$3,$3,-1

	lw	$4,104($2)
	sll	$3,$3,26
	or	$3,$4,$3
	sw	$3,104($2)
$L215:
	lbu	$5,5($16)
	lbu	$3,4($16)
	sll	$5,$5,8
	or	$5,$5,$3
	sll	$5,$5,16
	li	$3,-1240793088			# 0xffffffffb60b0000
	sra	$5,$5,16
	addiu	$3,$3,24759
	mult	$5,$3
	addu	$20,$20,$19
	mfhi	$3
	sll	$20,$20,5
	addu	$3,$3,$5
	addu	$17,$17,$20
	sra	$5,$5,31
	sra	$3,$3,5
	lw	$4,40($17)
	subu	$3,$3,$5
	sll	$3,$3,29
	sw	$4,108($2)
	sw	$3,32($2)
	sw	$18,132($2)
	move	$4,$18
	sw	$2,0($17)
	li	$2,2686976			# 0x290000
	sw	$2,28($17)
	sw	$0,4($17)
	sw	$0,208($17)
	sw	$0,224($17)
	sw	$0,228($17)
	sw	$0,232($17)
	sw	$0,240($17)
	jal	P_SetupPsprites
	sw	$0,244($17)

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	beq	$2,$0,$L216
	li	$2,1			# 0x1

	sw	$2,76($17)
	sw	$2,80($17)
	sw	$2,84($17)
	sw	$2,88($17)
	sw	$2,92($17)
	sw	$2,96($17)
$L216:
	lbu	$2,7($16)
	lbu	$3,6($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	lui	$3,%hi(consoleplayer)
	sra	$2,$2,16
	lw	$3,%lo(consoleplayer)($3)
	addiu	$2,$2,-1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L228
	.set	at
	nop

$L210:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L230:
	jr	$31
	nop

$L228:
	jal	ST_Start
	nop

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	HU_Start
	addiu	$sp,$sp,40

$L227:
	jal	G_PlayerReborn
	move	$4,$19

	b	$L229
	lbu	$5,3($16)

	.set	macro
	.set	reorder
	.end	P_SpawnPlayer
	.size	P_SpawnPlayer, .-P_SpawnPlayer
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"P_SpawnMapThing: Unknown type %i at (%i, %i)\000"
	.text
	.align	2
	.globl	P_SpawnMapThing
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnMapThing
	.type	P_SpawnMapThing, @function
P_SpawnMapThing:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	lbu	$5,7($4)
	lbu	$2,6($4)
	sll	$5,$5,8
	or	$5,$5,$2
	sll	$5,$5,16
	sra	$5,$5,16
	li	$2,11			# 0xb
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L273
	.set	at
	move	$16,$4

	blez	$5,$L231
	slt	$2,$5,5

	bne	$2,$0,$L274
	lui	$3,%hi(netgame)

	lbu	$2,9($4)
	lbu	$4,8($4)
	sll	$2,$2,8
	or	$2,$2,$4
	lw	$3,%lo(netgame)($3)
	sll	$2,$2,16
	bne	$3,$0,$L237
	sra	$2,$2,16

	andi	$3,$2,0x10
	bne	$3,$0,$L278
	lw	$31,28($sp)

$L237:
	lui	$3,%hi(gameskill)
	lw	$3,%lo(gameskill)($3)
	beq	$3,$0,$L253
	li	$4,4			# 0x4

	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L238
	.set	at
	li	$4,1			# 0x1

	addiu	$3,$3,-1
	sll	$3,$4,$3
$L238:
	and	$2,$2,$3
	beq	$2,$0,$L231
	lui	$18,%hi(mobjinfo)

	addiu	$18,$18,%lo(mobjinfo)
	move	$2,$18
	move	$17,$0
	b	$L240
	li	$4,137			# 0x89

$L276:
	addiu	$17,$17,1
	.set	noat
	xor	$1,$17,$4
	beq	$1,$0,$L275
	.set	at
	nop

$L240:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L276
	.set	at
	addiu	$2,$2,92

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	beq	$2,$0,$L279
	lui	$2,%hi(nomonsters)

	sll	$2,$17,1
	addu	$2,$2,$17
	sll	$2,$2,3
	subu	$2,$2,$17
	sll	$2,$2,2
	addu	$2,$18,$2
	lw	$2,84($2)
	li	$3,33554432			# 0x2000000
	and	$2,$2,$3
	bne	$2,$0,$L231
	lui	$2,%hi(nomonsters)

$L279:
	lw	$2,%lo(nomonsters)($2)
	beq	$2,$0,$L280
	sll	$2,$17,1

	li	$2,18			# 0x12
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L278
	.set	at
	lw	$31,28($sp)

$L245:
	sll	$2,$17,1
$L277:
	addu	$2,$2,$17
	sll	$2,$2,3
	subu	$2,$2,$17
	sll	$2,$2,2
	addu	$2,$18,$2
	lw	$2,84($2)
	li	$3,4194304			# 0x400000
	and	$3,$2,$3
	bne	$3,$0,$L278
	lw	$31,28($sp)

$L247:
	lbu	$4,1($16)
	lbu	$5,3($16)
	lbu	$6,0($16)
	lbu	$3,2($16)
	sll	$4,$4,8
	sll	$5,$5,8
	or	$4,$4,$6
	or	$5,$5,$3
	andi	$2,$2,0x100
	sll	$4,$4,16
	beq	$2,$0,$L254
	sll	$5,$5,16

	li	$6,2147418112			# 0x7fff0000
	ori	$6,$6,0xffff
$L249:
	jal	P_SpawnMobj
	move	$7,$17

	lwl	$4,3($16)
	lwl	$3,7($16)
	lwr	$4,0($16)
	lwr	$3,4($16)
	sw	$4,140($2)
	sw	$3,144($2)
	lbu	$3,8($16)
	move	$17,$2
	lw	$2,96($2)
	sb	$3,148($17)
	lbu	$3,9($16)
	blez	$2,$L250
	sb	$3,149($17)

	jal	P_Random
	nop

	lw	$3,96($17)
	div	$0,$2,$3
	mfhi	$2
	addiu	$2,$2,1
	sw	$2,96($17)
$L250:
	lw	$2,104($17)
	li	$3,4194304			# 0x400000
	and	$3,$2,$3
	beq	$3,$0,$L281
	li	$3,8388608			# 0x800000

	lui	$4,%hi(totalkills)
	lw	$3,%lo(totalkills)($4)
	addiu	$3,$3,1
	sw	$3,%lo(totalkills)($4)
	li	$3,8388608			# 0x800000
$L281:
	and	$3,$2,$3
	beq	$3,$0,$L252
	lui	$4,%hi(totalitems)

	lw	$3,%lo(totalitems)($4)
	addiu	$3,$3,1
	sw	$3,%lo(totalitems)($4)
$L252:
	lbu	$4,5($16)
	lbu	$3,4($16)
	sll	$4,$4,8
	or	$4,$4,$3
	sll	$4,$4,16
	li	$3,-1240793088			# 0xffffffffb60b0000
	sra	$4,$4,16
	addiu	$3,$3,24759
	mult	$4,$3
	sra	$5,$4,31
	mfhi	$3
	addu	$3,$3,$4
	sra	$3,$3,5
	subu	$3,$3,$5
	sll	$3,$3,29
	sw	$3,32($17)
	lbu	$3,8($16)
	andi	$3,$3,0x8
	beq	$3,$0,$L278
	lw	$31,28($sp)

	ori	$2,$2,0x20
	sw	$2,104($17)
$L231:
	lw	$31,28($sp)
$L278:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L273:
	lui	$17,%hi(deathmatch_p)
	lw	$4,%lo(deathmatch_p)($17)
	lui	$2,%hi(deathmatchstarts+100)
	addiu	$2,$2,%lo(deathmatchstarts+100)
	sltu	$2,$4,$2
	beq	$2,$0,$L278
	lw	$31,28($sp)

	li	$6,10			# 0xa
	jal	memcpy
	move	$5,$16

	lw	$2,%lo(deathmatch_p)($17)
	addiu	$2,$2,10
	b	$L231
	sw	$2,%lo(deathmatch_p)($17)

$L274:
	addiu	$5,$5,-1
	sll	$3,$5,16
	sra	$3,$3,16
	lwl	$5,3($4)
	sll	$2,$3,2
	addu	$2,$2,$3
	lui	$6,%hi(playerstarts)
	lwl	$3,7($4)
	lwr	$5,0($4)
	sll	$2,$2,1
	addiu	$6,$6,%lo(playerstarts)
	addu	$2,$2,$6
	lwr	$3,4($4)
	swl	$5,3($2)
	swr	$5,0($2)
	swl	$3,7($2)
	swr	$3,4($2)
	lbu	$3,8($4)
	sb	$3,8($2)
	lui	$3,%hi(deathmatch)
	lbu	$5,9($4)
	lw	$3,%lo(deathmatch)($3)
	bne	$3,$0,$L231
	sb	$5,9($2)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	P_SpawnPlayer
	addiu	$sp,$sp,32

$L253:
	b	$L238
	li	$3,1			# 0x1

$L275:
	lbu	$7,3($16)
	lbu	$6,1($16)
	lbu	$2,0($16)
	lbu	$3,2($16)
	sll	$7,$7,8
	sll	$6,$6,8
	or	$6,$6,$2
	or	$7,$7,$3
	sll	$7,$7,16
	sll	$6,$6,16
	lui	$4,%hi($LC0)
	sra	$7,$7,16
	sra	$6,$6,16
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	beq	$2,$0,$L244
	lui	$2,%hi(nomonsters)

	lw	$2,12688($18)
	li	$3,33554432			# 0x2000000
	and	$2,$2,$3
	bne	$2,$0,$L231
	lui	$2,%hi(nomonsters)

	lw	$2,%lo(nomonsters)($2)
	bne	$2,$0,$L245
	sll	$2,$17,1

$L280:
	addu	$2,$2,$17
	sll	$2,$2,3
	subu	$2,$2,$17
	sll	$2,$2,2
	addu	$2,$18,$2
	b	$L247
	lw	$2,84($2)

$L254:
	b	$L249
	li	$6,-2147483648			# 0xffffffff80000000

$L244:
	lw	$3,%lo(nomonsters)($2)
	beq	$3,$0,$L247
	lw	$2,12688($18)

	b	$L277
	sll	$2,$17,1

	.set	macro
	.set	reorder
	.end	P_SpawnMapThing
	.size	P_SpawnMapThing, .-P_SpawnMapThing
	.align	2
	.globl	P_SpawnPuff
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnPuff
	.type	P_SpawnPuff, @function
P_SpawnPuff:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	move	$19,$6
	move	$18,$5
	sw	$17,24($sp)
	sw	$16,20($sp)
	jal	P_Random
	move	$17,$4

	jal	P_Random
	move	$16,$2

	subu	$16,$16,$2
	sll	$16,$16,10
	addu	$6,$16,$19
	move	$5,$18
	move	$4,$17
	jal	P_SpawnMobj
	li	$7,37			# 0x25

	move	$16,$2
	li	$2,65536			# 0x10000
	jal	P_Random
	sw	$2,80($16)

	lw	$3,96($16)
	andi	$2,$2,0x3
	subu	$3,$3,$2
	lui	$2,%hi(attackrange)
	lw	$4,%lo(attackrange)($2)
	slt	$5,$0,$3
	li	$2,1			# 0x1
	movz	$3,$2,$5
	li	$2,4194304			# 0x400000
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L285
	.set	at
	sw	$3,96($16)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L285:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	move	$4,$16
	lw	$16,20($sp)
	li	$5,95			# 0x5f
	j	P_SetMobjState
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_SpawnPuff
	.size	P_SpawnPuff, .-P_SpawnPuff
	.align	2
	.globl	P_SpawnBlood
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnBlood
	.type	P_SpawnBlood, @function
P_SpawnBlood:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	move	$20,$6
	move	$19,$5
	sw	$18,24($sp)
	sw	$17,20($sp)
	move	$18,$4
	move	$17,$7
	jal	P_Random
	sw	$16,16($sp)

	jal	P_Random
	move	$16,$2

	subu	$16,$16,$2
	sll	$16,$16,10
	addu	$6,$16,$20
	move	$5,$19
	move	$4,$18
	jal	P_SpawnMobj
	li	$7,38			# 0x26

	move	$16,$2
	li	$2,131072			# 0x20000
	jal	P_Random
	sw	$2,80($16)

	lw	$3,96($16)
	andi	$2,$2,0x3
	subu	$3,$3,$2
	slt	$5,$0,$3
	addiu	$2,$17,-9
	li	$4,1			# 0x1
	movz	$3,$4,$5
	sltu	$2,$2,4
	bne	$2,$0,$L291
	sw	$3,96($16)

	slt	$17,$17,9
	bne	$17,$0,$L292
	lw	$31,36($sp)

	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L292:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$5,92			# 0x5c
	j	P_SetMobjState
	addiu	$sp,$sp,40

$L291:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$5,91			# 0x5b
	j	P_SetMobjState
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_SpawnBlood
	.size	P_SpawnBlood, .-P_SpawnBlood
	.align	2
	.globl	P_CheckMissileSpawn
	.set	nomips16
	.set	nomicromips
	.ent	P_CheckMissileSpawn
	.type	P_CheckMissileSpawn, @function
P_CheckMissileSpawn:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_Random
	move	$16,$4

	lw	$3,96($16)
	lw	$7,80($16)
	lw	$5,72($16)
	lw	$6,76($16)
	andi	$2,$2,0x3
	lw	$4,20($16)
	subu	$2,$3,$2
	lw	$10,12($16)
	lw	$9,16($16)
	sra	$3,$7,1
	slt	$8,$0,$2
	sra	$5,$5,1
	sra	$6,$6,1
	li	$7,1			# 0x1
	addu	$3,$4,$3
	addu	$5,$5,$10
	addu	$6,$6,$9
	movz	$2,$7,$8
	sw	$2,96($16)
	sw	$5,12($16)
	sw	$6,16($16)
	sw	$3,20($16)
	jal	P_TryMove
	move	$4,$16

	beq	$2,$0,$L296
	lw	$31,20($sp)

	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L296:
	move	$4,$16
	lw	$16,16($sp)
	j	P_ExplodeMissile
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_CheckMissileSpawn
	.size	P_CheckMissileSpawn, .-P_CheckMissileSpawn
	.align	2
	.globl	P_SubstNullMobj
	.set	nomips16
	.set	nomicromips
	.ent	P_SubstNullMobj
	.type	P_SubstNullMobj, @function
P_SubstNullMobj:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L299
	move	$2,$4

	jr	$31
	nop

$L299:
	lui	$2,%hi(dummy_mobj.0)
	addiu	$2,$2,%lo(dummy_mobj.0)
	sw	$0,12($2)
	sw	$0,16($2)
	sw	$0,20($2)
	jr	$31
	sw	$0,104($2)

	.set	macro
	.set	reorder
	.end	P_SubstNullMobj
	.size	P_SubstNullMobj, .-P_SubstNullMobj
	.align	2
	.globl	P_SpawnMissile
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnMissile
	.type	P_SpawnMissile, @function
P_SpawnMissile:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lw	$2,20($4)
	move	$7,$6
	sw	$18,24($sp)
	sw	$17,20($sp)
	move	$18,$5
	move	$17,$4
	lw	$5,16($4)
	li	$6,2097152			# 0x200000
	lw	$4,12($4)
	addu	$6,$2,$6
	sw	$16,16($sp)
	sw	$31,36($sp)
	sw	$20,32($sp)
	jal	P_SpawnMobj
	sw	$19,28($sp)

	move	$16,$2
	lw	$2,92($2)
	lw	$5,16($2)
	bne	$5,$0,$L312
	nop

	lw	$4,12($17)
	lw	$7,16($18)
	lw	$6,12($18)
	lw	$5,16($17)
	jal	R_PointToAngle2
	sw	$17,120($16)

	lw	$3,104($18)
	li	$4,262144			# 0x40000
	and	$3,$3,$4
	bne	$3,$0,$L313
	move	$20,$2

$L304:
	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	srl	$19,$20,19
	lw	$3,92($16)
	sll	$19,$19,2
	sw	$20,32($16)
	addu	$2,$2,$19
	lw	$4,60($3)
	jal	FixedMul
	lw	$5,0($2)

	lui	$3,%hi(finesine)
	lw	$4,92($16)
	addiu	$3,$3,%lo(finesine)
	addu	$19,$19,$3
	lw	$5,0($19)
	lw	$4,60($4)
	jal	FixedMul
	sw	$2,72($16)

	lw	$6,16($18)
	lw	$3,12($17)
	lw	$5,16($17)
	lw	$4,12($18)
	subu	$5,$6,$5
	subu	$4,$4,$3
	jal	P_AproxDistance
	sw	$2,76($16)

	lw	$4,92($16)
	lw	$5,20($17)
	lw	$4,60($4)
	lw	$3,20($18)
	div	$0,$2,$4
	subu	$3,$3,$5
	li	$5,1			# 0x1
	move	$4,$16
	mflo	$2
	slt	$6,$0,$2
	movz	$2,$5,$6
	div	$0,$3,$2
	mflo	$2
	jal	P_CheckMissileSpawn
	sw	$2,80($16)

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L312:
	jal	S_StartSound
	move	$4,$16

	lw	$4,12($17)
	lw	$7,16($18)
	lw	$6,12($18)
	lw	$5,16($17)
	jal	R_PointToAngle2
	sw	$17,120($16)

	lw	$3,104($18)
	li	$4,262144			# 0x40000
	and	$3,$3,$4
	beq	$3,$0,$L304
	move	$20,$2

$L313:
	jal	P_Random
	nop

	jal	P_Random
	move	$19,$2

	subu	$19,$19,$2
	sll	$19,$19,20
	b	$L304
	addu	$20,$20,$19

	.set	macro
	.set	reorder
	.end	P_SpawnMissile
	.size	P_SpawnMissile, .-P_SpawnMissile
	.align	2
	.globl	P_SpawnPlayerMissile
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnPlayerMissile
	.type	P_SpawnPlayerMissile, @function
P_SpawnPlayerMissile:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$20,32($sp)
	lw	$20,32($4)
	sw	$18,24($sp)
	sw	$16,16($sp)
	li	$6,67108864			# 0x4000000
	move	$16,$5
	lui	$18,%hi(linetarget)
	move	$5,$20
	sw	$19,28($sp)
	sw	$17,20($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	jal	P_AimLineAttack
	move	$17,$4

	lw	$3,%lo(linetarget)($18)
	beq	$3,$0,$L322
	move	$19,$2

$L315:
	lw	$6,20($17)
	lw	$5,16($17)
	li	$2,2097152			# 0x200000
	lw	$4,12($17)
	move	$7,$16
	jal	P_SpawnMobj
	addu	$6,$6,$2

	lw	$3,92($2)
	lw	$5,16($3)
	bne	$5,$0,$L323
	move	$16,$2

$L316:
	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	srl	$18,$20,19
	sll	$18,$18,2
	sw	$20,32($16)
	addu	$2,$2,$18
	lw	$4,60($3)
	lw	$5,0($2)
	jal	FixedMul
	sw	$17,120($16)

	lui	$3,%hi(finesine)
	lw	$4,92($16)
	addiu	$3,$3,%lo(finesine)
	addu	$18,$18,$3
	lw	$5,0($18)
	lw	$4,60($4)
	jal	FixedMul
	sw	$2,72($16)

	lw	$3,92($16)
	sw	$2,76($16)
	lw	$4,60($3)
	jal	FixedMul
	move	$5,$19

	sw	$2,80($16)
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	P_CheckMissileSpawn
	addiu	$sp,$sp,48

$L323:
	jal	S_StartSound
	move	$4,$2

	b	$L316
	lw	$3,92($16)

$L322:
	li	$22,67108864			# 0x4000000
	addu	$21,$20,$22
	li	$6,67108864			# 0x4000000
	move	$5,$21
	jal	P_AimLineAttack
	move	$4,$17

	lw	$3,%lo(linetarget)($18)
	beq	$3,$0,$L324
	move	$19,$2

	b	$L315
	move	$20,$21

$L324:
	subu	$20,$20,$22
	li	$6,67108864			# 0x4000000
	move	$5,$20
	jal	P_AimLineAttack
	move	$4,$17

	lw	$3,%lo(linetarget)($18)
	bne	$3,$0,$L315
	move	$19,$2

	lw	$20,32($17)
	b	$L315
	move	$19,$0

	.set	macro
	.set	reorder
	.end	P_SpawnPlayerMissile
	.size	P_SpawnPlayerMissile, .-P_SpawnPlayerMissile
	.local	dummy_mobj.0
	.comm	dummy_mobj.0,156,4
	.globl	iquetail
	.section	.bss,"aw",@nobits
	.align	2
	.type	iquetail, @object
	.size	iquetail, 4
iquetail:
	.space	4
	.globl	iquehead
	.align	2
	.type	iquehead, @object
	.size	iquehead, 4
iquehead:
	.space	4
	.globl	itemrespawntime
	.align	2
	.type	itemrespawntime, @object
	.size	itemrespawntime, 512
itemrespawntime:
	.space	512
	.globl	itemrespawnque
	.align	2
	.type	itemrespawnque, @object
	.size	itemrespawnque, 1280
itemrespawnque:
	.space	1280
	.globl	test
	.align	2
	.type	test, @object
	.size	test, 4
test:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
