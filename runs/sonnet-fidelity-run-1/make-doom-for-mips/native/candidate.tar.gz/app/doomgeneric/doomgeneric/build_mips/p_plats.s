	.file	1 "p_plats.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"P_RemoveActivePlat: can't find plat!\000"
	.text
	.align	2
	.globl	T_PlatRaise
	.set	nomips16
	.set	nomicromips
	.ent	T_PlatRaise
	.type	T_PlatRaise, @function
T_PlatRaise:
	.frame	$sp,40,$31		# vars= 0, regs= 4/0, args= 24, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,36($4)
	addiu	$sp,$sp,-40
	li	$3,1			# 0x1
	sw	$16,24($sp)
	sw	$31,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L2
	.set	at
	move	$16,$4

	li	$4,2			# 0x2
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L3
	.set	at
	nop

	beq	$2,$0,$L25
	nop

$L1:
	lw	$31,36($sp)
$L31:
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,40

$L2:
	lw	$6,20($4)
	lw	$5,16($4)
	li	$2,-1			# 0xffffffffffffffff
	lw	$4,12($4)
	move	$7,$0
	sw	$2,20($sp)
	jal	T_MovePlane
	sw	$0,16($sp)

	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L31
	.set	at
	lw	$31,36($sp)

	lw	$3,28($16)
	lw	$4,12($16)
	sw	$3,32($16)
	sw	$2,36($16)
	b	$L23
	li	$5,19			# 0x13

$L25:
	lw	$7,44($16)
	lw	$6,24($16)
	lw	$5,16($16)
	lw	$4,12($16)
	sw	$3,20($sp)
	jal	T_MovePlane
	sw	$0,16($sp)

	lw	$3,52($16)
	addiu	$3,$3,-2
	sltu	$3,$3,2
	bne	$3,$0,$L26
	move	$17,$2

$L6:
	li	$18,1			# 0x1
$L28:
	.set	noat
	xor	$1,$17,$18
	beq	$1,$0,$L27
	.set	at
	li	$2,2			# 0x2

	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L31
	.set	at
	lw	$31,36($sp)

	lw	$2,28($16)
	lw	$4,12($16)
	sw	$2,32($16)
	sw	$17,36($16)
	li	$5,19			# 0x13
	jal	S_StartSound
	addiu	$4,$4,44

	lw	$2,52($16)
	sltu	$3,$2,4
	beq	$3,$0,$L10
	sltu	$3,$2,2

	beq	$3,$0,$L11
	move	$17,$0

	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L31
	.set	at
	lw	$31,36($sp)

	lui	$18,%hi(activeplats)
$L29:
	addiu	$18,$18,%lo(activeplats)
	move	$2,$18
	move	$17,$0
	b	$L15
	li	$4,30			# 0x1e

$L14:
	addiu	$17,$17,1
	.set	noat
	xor	$1,$17,$4
	beq	$1,$0,$L32
	.set	at
	lw	$31,36($sp)

$L15:
	lw	$3,0($2)
	.set	noat
	xor	$1,$16,$3
	bne	$1,$0,$L14
	.set	at
	addiu	$2,$2,4

	lw	$2,12($16)
$L30:
	sll	$17,$17,2
	move	$4,$16
	sw	$0,76($2)
	jal	P_RemoveThinker
	addu	$18,$18,$17

	b	$L1
	sw	$0,0($18)

$L3:
	lw	$2,32($16)
	addiu	$2,$2,-1
	bne	$2,$0,$L1
	sw	$2,32($16)

	lw	$4,12($16)
	lw	$3,20($16)
	lw	$2,0($4)
	li	$5,18			# 0x12
	xor	$2,$2,$3
	sltu	$2,$0,$2
	sw	$2,36($16)
$L23:
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addiu	$4,$4,44
	j	S_StartSound
	addiu	$sp,$sp,40

$L26:
	lui	$2,%hi(leveltime)
	lw	$2,%lo(leveltime)($2)
	andi	$2,$2,0x7
	bne	$2,$0,$L6
	li	$5,22			# 0x16

	lw	$4,12($16)
	jal	S_StartSound
	addiu	$4,$4,44

	b	$L28
	li	$18,1			# 0x1

$L27:
	lw	$2,44($16)
	bne	$2,$0,$L31
	lw	$31,36($sp)

	lw	$2,28($16)
	lw	$4,12($16)
	sw	$2,32($16)
	sw	$17,36($16)
	b	$L23
	li	$5,18			# 0x12

$L10:
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L31
	.set	at
	lw	$31,36($sp)

	b	$L29
	lui	$18,%hi(activeplats)

$L11:
	lui	$18,%hi(activeplats)
	addiu	$18,$18,%lo(activeplats)
	move	$2,$18
	b	$L17
	li	$4,30			# 0x1e

$L16:
	addiu	$17,$17,1
	.set	noat
	xor	$1,$17,$4
	beq	$1,$0,$L18
	.set	at
	lw	$31,36($sp)

$L17:
	lw	$3,0($2)
	.set	noat
	xor	$1,$16,$3
	bne	$1,$0,$L16
	.set	at
	addiu	$2,$2,4

	b	$L30
	lw	$2,12($16)

$L18:
$L32:
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	lui	$4,%hi($LC0)
	addiu	$4,$4,%lo($LC0)
	j	I_Error
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	T_PlatRaise
	.size	T_PlatRaise, .-T_PlatRaise
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"P_AddActivePlat: no more plats!\000"
	.text
	.align	2
	.globl	EV_DoPlat
	.set	nomips16
	.set	nomicromips
	.ent	EV_DoPlat
	.type	EV_DoPlat, @function
EV_DoPlat:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	move	$17,$5
	move	$16,$4
	beq	$5,$0,$L34
	sw	$6,64($sp)

	lui	$19,%hi($L42)
$L63:
	sll	$2,$17,2
	lui	$20,%hi(T_PlatRaise)
	addiu	$19,$19,%lo($L42)
	move	$23,$0
	li	$fp,-1			# 0xffffffffffffffff
	lui	$18,%hi(sectors)
	addiu	$20,$20,%lo(T_PlatRaise)
	lui	$22,%hi(activeplats)
	addu	$19,$19,$2
	move	$5,$fp
$L62:
	jal	P_FindSectorFromLineTag
	move	$4,$16

	bltz	$2,$L58
	move	$fp,$2

$L50:
	sll	$3,$fp,1
	addu	$3,$3,$fp
	sll	$3,$3,2
	lw	$2,%lo(sectors)($18)
	subu	$3,$3,$fp
	sll	$3,$3,3
	addu	$21,$2,$3
	lw	$2,76($21)
	bne	$2,$0,$L62
	move	$5,$fp

	move	$6,$0
	li	$5,6			# 0x6
	jal	Z_Malloc
	li	$4,56			# 0x38

	move	$4,$2
	jal	P_AddThinker
	move	$23,$2

	lh	$4,20($16)
	sltu	$2,$17,5
	sw	$17,52($23)
	sw	$21,12($23)
	sw	$23,76($21)
	sw	$20,8($23)
	sw	$0,44($23)
	beq	$2,$0,$L40
	sw	$4,48($23)

	lw	$2,0($19)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L42:
	.word	$L46
	.word	$L45
	.word	$L44
	.word	$L43
	.word	$L41
	.text
$L45:
	move	$4,$21
	li	$2,262144			# 0x40000
$L57:
	jal	P_FindLowestFloorSurrounding
	sw	$2,16($23)

	lw	$4,0($21)
	slt	$5,$4,$2
	movn	$2,$4,$5
	sw	$2,20($23)
	li	$2,105			# 0x69
	sw	$2,28($23)
	li	$2,1			# 0x1
	sw	$4,24($23)
	sw	$2,36($23)
	li	$5,18			# 0x12
	jal	S_StartSound
	addiu	$4,$21,44

$L40:
	addiu	$2,$22,%lo(activeplats)
$L61:
	move	$4,$2
	move	$3,$0
	b	$L49
	li	$6,30			# 0x1e

$L47:
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L59
	.set	at
	addiu	$4,$4,4

$L49:
	lw	$5,0($4)
	bne	$5,$0,$L47
	addiu	$3,$3,1

	addiu	$3,$3,-1
	sll	$3,$3,2
	addu	$2,$2,$3
	sw	$23,0($2)
	li	$23,1			# 0x1
$L60:
	move	$5,$fp
	jal	P_FindSectorFromLineTag
	move	$4,$16

	bgez	$2,$L50
	move	$fp,$2

$L58:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$23
	lw	$23,44($sp)
	jr	$31
	addiu	$sp,$sp,56

$L59:
	lui	$4,%hi($LC1)
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	b	$L60
	li	$23,1			# 0x1

$L43:
	lh	$5,22($16)
	lui	$4,%hi(sides)
	sll	$2,$5,2
	lw	$4,%lo(sides)($4)
	addu	$2,$2,$5
	sll	$2,$2,2
	addu	$2,$4,$2
	lw	$2,16($2)
	lw	$5,0($21)
	lh	$2,8($2)
	li	$4,32768			# 0x8000
	sw	$4,16($23)
	move	$4,$21
	jal	P_FindNextHighestFloor
	sh	$2,8($21)

	sw	$2,24($23)
	sw	$0,28($23)
	sw	$0,36($23)
	li	$5,22			# 0x16
	sh	$0,14($21)
	jal	S_StartSound
	addiu	$4,$21,44

	b	$L61
	addiu	$2,$22,%lo(activeplats)

$L44:
	lh	$5,22($16)
	lui	$4,%hi(sides)
	sll	$2,$5,2
	lw	$4,%lo(sides)($4)
	addu	$2,$2,$5
	sll	$2,$2,2
	addu	$2,$4,$2
	lw	$4,16($2)
	lw	$3,64($sp)
	lw	$2,0($21)
	lh	$4,8($4)
	sll	$5,$3,16
	addu	$2,$2,$5
	li	$5,32768			# 0x8000
	sw	$5,16($23)
	sh	$4,8($21)
	li	$5,22			# 0x16
	addiu	$4,$21,44
	sw	$2,24($23)
	sw	$0,28($23)
	jal	S_StartSound
	sw	$0,36($23)

	b	$L61
	addiu	$2,$22,%lo(activeplats)

$L46:
	li	$2,65536			# 0x10000
	move	$4,$21
	jal	P_FindLowestFloorSurrounding
	sw	$2,16($23)

	lw	$4,0($21)
	slt	$5,$2,$4
	movz	$2,$4,$5
	sw	$2,20($23)
	jal	P_FindHighestFloorSurrounding
	move	$4,$21

	lw	$4,0($21)
	slt	$5,$4,$2
	movn	$4,$2,$5
	li	$2,105			# 0x69
	sw	$4,24($23)
	jal	P_Random
	sw	$2,28($23)

	andi	$2,$2,0x1
	sw	$2,36($23)
	li	$5,18			# 0x12
	jal	S_StartSound
	addiu	$4,$21,44

	b	$L61
	addiu	$2,$22,%lo(activeplats)

$L41:
	move	$4,$21
	b	$L57
	li	$2,524288			# 0x80000

$L34:
	lui	$2,%hi(activeplats)
	addiu	$2,$2,%lo(activeplats)
	lui	$8,%hi(T_PlatRaise)
	lh	$6,20($4)
	addiu	$5,$2,120
	li	$7,3			# 0x3
	b	$L37
	addiu	$8,$8,%lo(T_PlatRaise)

$L36:
	addiu	$2,$2,4
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L63
	.set	at
	lui	$19,%hi($L42)

$L37:
	lw	$3,0($2)
	beq	$3,$0,$L36
	nop

	lw	$4,48($3)
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L36
	.set	at
	nop

	lw	$4,36($3)
	.set	noat
	xor	$1,$4,$7
	bne	$1,$0,$L36
	.set	at
	nop

	lw	$4,40($3)
	sw	$8,8($3)
	b	$L36
	sw	$4,36($3)

	.set	macro
	.set	reorder
	.end	EV_DoPlat
	.size	EV_DoPlat, .-EV_DoPlat
	.align	2
	.globl	P_ActivateInStasis
	.set	nomips16
	.set	nomicromips
	.ent	P_ActivateInStasis
	.type	P_ActivateInStasis, @function
P_ActivateInStasis:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(activeplats)
	addiu	$2,$2,%lo(activeplats)
	lui	$8,%hi(T_PlatRaise)
	addiu	$6,$2,120
	li	$7,3			# 0x3
	b	$L66
	addiu	$8,$8,%lo(T_PlatRaise)

$L65:
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L72
	.set	at
	nop

$L66:
	lw	$3,0($2)
	beq	$3,$0,$L65
	addiu	$2,$2,4

	lw	$5,48($3)
	.set	noat
	xor	$1,$5,$4
	bne	$1,$0,$L65
	.set	at
	nop

	lw	$5,36($3)
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L65
	.set	at
	nop

	lw	$5,40($3)
	sw	$8,8($3)
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L66
	.set	at
	sw	$5,36($3)

$L72:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_ActivateInStasis
	.size	P_ActivateInStasis, .-P_ActivateInStasis
	.align	2
	.globl	EV_StopPlat
	.set	nomips16
	.set	nomicromips
	.ent	EV_StopPlat
	.type	EV_StopPlat, @function
EV_StopPlat:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(activeplats)
	addiu	$2,$2,%lo(activeplats)
	addiu	$6,$2,120
	li	$9,3			# 0x3
$L75:
	lw	$3,0($2)
	beq	$3,$0,$L74
	addiu	$2,$2,4

	lw	$5,36($3)
	.set	noat
	xor	$1,$5,$9
	beq	$1,$0,$L74
	.set	at
	nop

	lh	$7,20($4)
	lw	$8,48($3)
	.set	noat
	xor	$1,$8,$7
	bne	$1,$0,$L74
	.set	at
	nop

	sw	$5,40($3)
	sw	$9,36($3)
	sw	$0,8($3)
$L74:
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L75
	.set	at
	nop

	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	EV_StopPlat
	.size	EV_StopPlat, .-EV_StopPlat
	.align	2
	.globl	P_AddActivePlat
	.set	nomips16
	.set	nomicromips
	.ent	P_AddActivePlat
	.type	P_AddActivePlat, @function
P_AddActivePlat:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$7,%hi(activeplats)
	addiu	$7,$7,%lo(activeplats)
	move	$3,$7
	move	$2,$0
	b	$L83
	li	$6,30			# 0x1e

$L81:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L86
	.set	at
	nop

$L83:
	lw	$5,0($3)
	bne	$5,$0,$L81
	addiu	$3,$3,4

	sll	$2,$2,2
	addu	$7,$7,$2
	jr	$31
	sw	$4,0($7)

$L86:
	lui	$4,%hi($LC1)
	j	I_Error
	addiu	$4,$4,%lo($LC1)

	.set	macro
	.set	reorder
	.end	P_AddActivePlat
	.size	P_AddActivePlat, .-P_AddActivePlat
	.align	2
	.globl	P_RemoveActivePlat
	.set	nomips16
	.set	nomicromips
	.ent	P_RemoveActivePlat
	.type	P_RemoveActivePlat, @function
P_RemoveActivePlat:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lui	$17,%hi(activeplats)
	addiu	$17,$17,%lo(activeplats)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$2,$17
	move	$16,$0
	b	$L90
	li	$5,30			# 0x1e

$L88:
	addiu	$16,$16,1
	.set	noat
	xor	$1,$16,$5
	beq	$1,$0,$L94
	.set	at
	lw	$31,28($sp)

$L90:
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L88
	.set	at
	addiu	$2,$2,4

	lw	$2,12($4)
	sll	$16,$16,2
	jal	P_RemoveThinker
	sw	$0,76($2)

	lw	$31,28($sp)
	addu	$17,$17,$16
	sw	$0,0($17)
	lw	$16,20($sp)
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L94:
	lw	$17,24($sp)
	lw	$16,20($sp)
	lui	$4,%hi($LC0)
	addiu	$4,$4,%lo($LC0)
	j	I_Error
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_RemoveActivePlat
	.size	P_RemoveActivePlat, .-P_RemoveActivePlat
	.globl	activeplats
	.section	.bss,"aw",@nobits
	.align	2
	.type	activeplats, @object
	.size	activeplats, 120
activeplats:
	.space	120
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
