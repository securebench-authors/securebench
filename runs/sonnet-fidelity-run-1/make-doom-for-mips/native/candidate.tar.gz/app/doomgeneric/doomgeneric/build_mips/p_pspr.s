	.file	1 "p_pspr.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_SetPsprite
	.set	nomips16
	.set	nomicromips
	.ent	P_SetPsprite
	.type	P_SetPsprite, @function
P_SetPsprite:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$18,24($sp)
	sll	$18,$5,4
	sw	$20,32($sp)
	sw	$17,20($sp)
	lui	$20,%hi(states)
	addiu	$17,$18,252
	sw	$19,28($sp)
	sw	$16,16($sp)
	sw	$31,36($sp)
	move	$16,$4
	addu	$17,$4,$17
	addu	$19,$4,$18
	b	$L7
	addiu	$20,$20,%lo(states)

$L5:
	jalr	$2
	nop

	lw	$2,252($19)
	beq	$2,$0,$L17
	lw	$31,36($sp)

	lw	$3,256($19)
	bne	$3,$0,$L17
	lw	$6,16($2)

$L7:
	sll	$2,$6,3
	subu	$3,$2,$6
	sll	$3,$3,2
	addu	$3,$20,$3
	move	$2,$3
	move	$5,$17
	beq	$6,$0,$L16
	move	$4,$16

	lw	$6,20($3)
	lw	$7,8($3)
	sll	$8,$6,16
	sw	$3,252($19)
	beq	$6,$0,$L4
	sw	$7,256($19)

	lw	$3,24($3)
	sw	$8,260($19)
	sll	$3,$3,16
	sw	$3,264($19)
$L4:
	lw	$2,12($2)
	bne	$2,$0,$L5
	nop

	lw	$2,252($19)
	lw	$3,256($19)
	beq	$3,$0,$L7
	lw	$6,16($2)

	lw	$31,36($sp)
$L17:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L16:
	lw	$31,36($sp)
	addu	$16,$16,$18
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$0,252($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_SetPsprite
	.size	P_SetPsprite, .-P_SetPsprite
	.align	2
	.globl	P_CalcSwing
	.set	nomips16
	.set	nomicromips
	.ent	P_CalcSwing
	.type	P_CalcSwing, @function
P_CalcSwing:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	lui	$18,%hi(leveltime)
	lw	$2,%lo(leveltime)($18)
	sw	$17,20($sp)
	li	$17,117			# 0x75
	multu	$2,$17
	mflo	$2
	sw	$16,16($sp)
	andi	$2,$2,0x1fff
	lui	$16,%hi(finesine)
	addiu	$16,$16,%lo(finesine)
	sll	$2,$2,2
	addu	$2,$2,$16
	lw	$4,36($4)
	sw	$31,28($sp)
	jal	FixedMul
	lw	$5,0($2)

	lw	$3,%lo(leveltime)($18)
	move	$4,$2
	multu	$3,$17
	mflo	$3
	lui	$2,%hi(swingx)
	addiu	$3,$3,4096
	andi	$3,$3,0x1fff
	sll	$3,$3,2
	addu	$3,$3,$16
	lw	$5,0($3)
	jal	FixedMul
	sw	$4,%lo(swingx)($2)

	lw	$31,28($sp)
	subu	$2,$0,$2
	lui	$3,%hi(swingy)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$2,%lo(swingy)($3)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_CalcSwing
	.size	P_CalcSwing, .-P_CalcSwing
	.align	2
	.globl	P_BringUpWeapon
	.set	nomips16
	.set	nomicromips
	.ent	P_BringUpWeapon
	.type	P_BringUpWeapon, @function
P_BringUpWeapon:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,124($4)
	addiu	$sp,$sp,-24
	li	$3,10			# 0xa
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L21
	.set	at
	move	$16,$4

	lw	$2,120($4)
	sw	$2,124($4)
$L21:
	li	$3,7			# 0x7
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L24
	.set	at
	nop

$L22:
	sll	$3,$2,1
	addu	$3,$3,$2
	lui	$2,%hi(weaponinfo)
	sll	$3,$3,3
	addiu	$2,$2,%lo(weaponinfo)
	addu	$2,$2,$3
	lw	$6,4($2)
	li	$2,10			# 0xa
	sw	$2,124($16)
	li	$2,8388608			# 0x800000
	lw	$31,20($sp)
	sw	$2,264($16)
	move	$4,$16
	lw	$16,16($sp)
	move	$5,$0
	j	P_SetPsprite
	addiu	$sp,$sp,24

$L24:
	lw	$4,0($16)
	jal	S_StartSound
	li	$5,10			# 0xa

	b	$L22
	lw	$2,124($16)

	.set	macro
	.set	reorder
	.end	P_BringUpWeapon
	.size	P_BringUpWeapon, .-P_BringUpWeapon
	.align	2
	.globl	P_CheckAmmo
	.set	nomips16
	.set	nomicromips
	.ent	P_CheckAmmo
	.type	P_CheckAmmo, @function
P_CheckAmmo:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,120($4)
	lui	$5,%hi(weaponinfo)
	sll	$7,$3,1
	addu	$2,$7,$3
	sll	$2,$2,3
	addiu	$5,$5,%lo(weaponinfo)
	addu	$2,$5,$2
	li	$6,6			# 0x6
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L36
	.set	at
	lw	$2,0($2)

	xori	$9,$3,0x8
	li	$6,2			# 0x2
	li	$8,1			# 0x1
	movn	$6,$8,$9
$L26:
	li	$8,5			# 0x5
	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L39
	.set	at
	nop

	addiu	$2,$2,40
	sll	$2,$2,2
	addu	$2,$4,$2
	lw	$2,4($2)
	slt	$2,$2,$6
	beq	$2,$0,$L39
	nop

	lw	$2,148($4)
	addiu	$sp,$sp,-24
	beq	$2,$0,$L28
	sw	$31,20($sp)

	lw	$2,172($4)
	beq	$2,$0,$L28
	lui	$2,%hi(gamemode)

	lw	$2,%lo(gamemode)($2)
	beq	$2,$0,$L28
	li	$2,5			# 0x5

$L29:
	addu	$3,$7,$3
$L80:
	sll	$3,$3,3
	addu	$3,$5,$3
	lw	$6,8($3)
	move	$5,$0
	jal	P_SetPsprite
	sw	$2,124($4)

	lw	$31,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

$L28:
	lw	$2,160($4)
	beq	$2,$0,$L30
	nop

	lw	$2,168($4)
	slt	$2,$2,3
	bne	$2,$0,$L30
	lui	$2,%hi(gamemode)

	lw	$6,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L29
	.set	at
	li	$2,8			# 0x8

$L30:
	lw	$2,140($4)
	beq	$2,$0,$L31
	nop

	lw	$2,164($4)
	beq	$2,$0,$L78
	li	$2,3			# 0x3

	addu	$3,$7,$3
	sll	$3,$3,3
	addu	$3,$5,$3
	lw	$6,8($3)
	move	$5,$0
	jal	P_SetPsprite
	sw	$2,124($4)

	lw	$31,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

$L31:
	lw	$2,136($4)
	beq	$2,$0,$L33
	nop

	lw	$2,168($4)
	bne	$2,$0,$L29
	li	$2,2			# 0x2

$L33:
	lw	$2,164($4)
	beq	$2,$0,$L35
	li	$2,1			# 0x1

	b	$L80
	addu	$3,$7,$3

$L78:
	lw	$2,136($4)
	beq	$2,$0,$L35
	nop

	lw	$2,168($4)
	bne	$2,$0,$L29
	li	$2,2			# 0x2

$L35:
	lw	$2,156($4)
	bne	$2,$0,$L29
	li	$2,7			# 0x7

	lw	$2,144($4)
	bne	$2,$0,$L79
	nop

$L34:
	lw	$2,152($4)
	beq	$2,$0,$L29
	nop

	lw	$2,172($4)
	slt	$2,$2,41
	bne	$2,$0,$L29
	move	$2,$0

	lui	$2,%hi(gamemode)
	lw	$2,%lo(gamemode)($2)
	beq	$2,$0,$L29
	nop

	b	$L29
	li	$2,6			# 0x6

$L79:
	lw	$2,176($4)
	beq	$2,$0,$L34
	li	$2,4			# 0x4

	b	$L80
	addu	$3,$7,$3

$L39:
	jr	$31
	li	$2,1			# 0x1

$L36:
	b	$L26
	li	$6,40			# 0x28

	.set	macro
	.set	reorder
	.end	P_CheckAmmo
	.size	P_CheckAmmo, .-P_CheckAmmo
	.align	2
	.globl	P_FireWeapon
	.set	nomips16
	.set	nomicromips
	.ent	P_FireWeapon
	.type	P_FireWeapon, @function
P_FireWeapon:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_CheckAmmo
	move	$16,$4

	bne	$2,$0,$L84
	lw	$31,20($sp)

	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L84:
	lw	$4,0($16)
	jal	P_SetMobjState
	li	$5,154			# 0x9a

	lw	$3,120($16)
	move	$4,$16
	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$3,%hi(weaponinfo)
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$2,$3
	lw	$6,16($2)
	jal	P_SetPsprite
	move	$5,$0

	lw	$5,0($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	move	$4,$5
	j	P_NoiseAlert
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_FireWeapon
	.size	P_FireWeapon, .-P_FireWeapon
	.align	2
	.globl	P_DropWeapon
	.set	nomips16
	.set	nomicromips
	.ent	P_DropWeapon
	.type	P_DropWeapon, @function
P_DropWeapon:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,120($4)
	move	$5,$0
	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$3,%hi(weaponinfo)
	sll	$2,$2,3
	addiu	$3,$3,%lo(weaponinfo)
	addu	$2,$2,$3
	j	P_SetPsprite
	lw	$6,8($2)

	.set	macro
	.set	reorder
	.end	P_DropWeapon
	.size	P_DropWeapon, .-P_DropWeapon
	.align	2
	.globl	A_WeaponReady
	.set	nomips16
	.set	nomicromips
	.ent	A_WeaponReady
	.type	A_WeaponReady, @function
A_WeaponReady:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,0($4)
	lui	$2,%hi(states+4312)
	lw	$3,100($4)
	addiu	$2,$2,%lo(states+4312)
	sw	$17,20($sp)
	sw	$31,28($sp)
	sw	$18,24($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L87
	.set	at
	move	$17,$5

	lui	$2,%hi(states+4340)
	addiu	$2,$2,%lo(states+4340)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L87
	.set	at
	li	$2,7			# 0x7

	lw	$3,120($16)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L101
	.set	at
	lui	$2,%hi(states+1876)

$L89:
	lw	$3,124($16)
$L100:
	li	$2,10			# 0xa
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L90
	.set	at
	nop

	lw	$2,40($16)
	beq	$2,$0,$L90
	nop

	lbu	$2,13($16)
	andi	$2,$2,0x1
	beq	$2,$0,$L92
	lui	$2,%hi(leveltime)

	lw	$2,196($16)
	beq	$2,$0,$L93
	li	$3,-3			# 0xfffffffffffffffd

	lw	$2,120($16)
	and	$2,$2,$3
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L102
	.set	at
	lui	$2,%hi(leveltime)

$L93:
	li	$2,1			# 0x1
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$2,196($16)
	move	$4,$16
	lw	$16,16($sp)
	j	P_FireWeapon
	addiu	$sp,$sp,32

$L90:
	lw	$3,120($16)
	lw	$31,28($sp)
	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$3,%hi(weaponinfo)
	sll	$2,$2,3
	addiu	$3,$3,%lo(weaponinfo)
	addu	$2,$2,$3
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$6,8($2)
	move	$4,$16
	lw	$16,16($sp)
	move	$5,$0
	j	P_SetPsprite
	addiu	$sp,$sp,32

$L87:
	jal	P_SetMobjState
	li	$5,149			# 0x95

	lw	$3,120($16)
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L89
	.set	at
	lui	$2,%hi(states+1876)

$L101:
	lw	$3,0($17)
	addiu	$2,$2,%lo(states+1876)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L89
	.set	at
	nop

	lw	$4,0($16)
	jal	S_StartSound
	li	$5,11			# 0xb

	b	$L100
	lw	$3,124($16)

$L92:
	sw	$0,196($16)
$L102:
	lw	$18,%lo(leveltime)($2)
	lui	$2,%hi(finecosine)
	sll	$18,$18,7
	lw	$2,%lo(finecosine)($2)
	andi	$3,$18,0x1f80
	sll	$3,$3,2
	addu	$2,$2,$3
	lw	$4,36($16)
	lw	$5,0($2)
	jal	FixedMul
	andi	$18,$18,0xf80

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	sll	$18,$18,2
	addu	$18,$18,$3
	li	$3,65536			# 0x10000
	lw	$4,36($16)
	addu	$2,$2,$3
	lw	$5,0($18)
	jal	FixedMul
	sw	$2,8($17)

	lw	$31,28($sp)
	li	$3,2097152			# 0x200000
	addu	$2,$2,$3
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$2,12($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_WeaponReady
	.size	A_WeaponReady, .-A_WeaponReady
	.align	2
	.globl	A_ReFire
	.set	nomips16
	.set	nomicromips
	.ent	A_ReFire
	.type	A_ReFire, @function
A_ReFire:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lbu	$3,13($4)
	andi	$3,$3,0x1
	beq	$3,$0,$L104
	move	$2,$4

	lw	$5,124($4)
	li	$3,10			# 0xa
	.set	noat
	xor	$1,$5,$3
	beq	$1,$0,$L111
	.set	at
	nop

$L104:
	sw	$0,208($2)
	j	P_CheckAmmo
	move	$4,$2

$L111:
	lw	$3,40($4)
	beq	$3,$0,$L104
	nop

	lw	$3,208($4)
	addiu	$3,$3,1
	j	P_FireWeapon
	sw	$3,208($4)

	.set	macro
	.set	reorder
	.end	A_ReFire
	.size	A_ReFire, .-A_ReFire
	.align	2
	.globl	A_CheckReload
	.set	nomips16
	.set	nomicromips
	.ent	A_CheckReload
	.type	A_CheckReload, @function
A_CheckReload:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	P_CheckAmmo
	nop

	.set	macro
	.set	reorder
	.end	A_CheckReload
	.size	A_CheckReload, .-A_CheckReload
	.align	2
	.globl	A_Lower
	.set	nomips16
	.set	nomicromips
	.ent	A_Lower
	.type	A_Lower, @function
A_Lower:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,12($5)
	li	$3,393216			# 0x60000
	addu	$2,$2,$3
	li	$6,8388608			# 0x800000
	slt	$7,$2,$6
	bne	$7,$0,$L119
	sw	$2,12($5)

	lw	$7,4($4)
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L117
	.set	at
	nop

	lw	$2,40($4)
	beq	$2,$0,$L118
	move	$6,$0

	lw	$2,124($4)
	j	P_BringUpWeapon
	sw	$2,120($4)

$L119:
	jr	$31
	nop

$L118:
	j	P_SetPsprite
	move	$5,$0

$L117:
	jr	$31
	sw	$6,12($5)

	.set	macro
	.set	reorder
	.end	A_Lower
	.size	A_Lower, .-A_Lower
	.align	2
	.globl	A_Raise
	.set	nomips16
	.set	nomicromips
	.ent	A_Raise
	.type	A_Raise, @function
A_Raise:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,12($5)
	li	$3,-393216			# 0xfffffffffffa0000
	li	$7,2097152			# 0x200000
	addu	$2,$2,$3
	addiu	$3,$7,1
	slt	$3,$2,$3
	bne	$3,$0,$L121
	nop

	jr	$31
	sw	$2,12($5)

$L121:
	lw	$2,120($4)
	sll	$3,$2,1
	addu	$3,$3,$2
	lui	$2,%hi(weaponinfo)
	sll	$3,$3,3
	addiu	$2,$2,%lo(weaponinfo)
	addu	$2,$2,$3
	lw	$6,12($2)
	sw	$7,12($5)
	j	P_SetPsprite
	move	$5,$0

	.set	macro
	.set	reorder
	.end	A_Raise
	.size	A_Raise, .-A_Raise
	.align	2
	.globl	A_GunFlash
	.set	nomips16
	.set	nomicromips
	.ent	A_GunFlash
	.type	A_GunFlash, @function
A_GunFlash:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,0($4)
	sw	$31,20($sp)
	jal	P_SetMobjState
	li	$5,155			# 0x9b

	lw	$2,120($16)
	lw	$31,20($sp)
	sll	$3,$2,1
	addu	$3,$3,$2
	lui	$2,%hi(weaponinfo)
	sll	$3,$3,3
	addiu	$2,$2,%lo(weaponinfo)
	addu	$2,$2,$3
	lw	$6,20($2)
	move	$4,$16
	lw	$16,16($sp)
	li	$5,1			# 0x1
	j	P_SetPsprite
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_GunFlash
	.size	A_GunFlash, .-A_GunFlash
	.align	2
	.globl	A_Punch
	.set	nomips16
	.set	nomicromips
	.ent	A_Punch
	.type	A_Punch, @function
A_Punch:
	.frame	$sp,48,$31		# vars= 0, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,36($sp)
	sw	$17,32($sp)
	sw	$31,44($sp)
	move	$17,$4
	sw	$19,40($sp)
	jal	P_Random
	sw	$16,28($sp)

	li	$3,1717960704			# 0x66660000
	addiu	$3,$3,26215
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	sra	$3,$3,2
	subu	$3,$3,$4
	sll	$4,$3,2
	addu	$3,$4,$3
	sll	$3,$3,1
	subu	$2,$2,$3
	lw	$3,56($17)
	addiu	$2,$2,1
	beq	$3,$0,$L127
	sll	$18,$2,1

	sll	$2,$2,3
	addu	$18,$2,$18
	sll	$18,$18,1
$L127:
	lw	$2,0($17)
	jal	P_Random
	lw	$19,32($2)

	jal	P_Random
	move	$16,$2

	subu	$16,$16,$2
	sll	$16,$16,18
	addu	$16,$16,$19
	lw	$4,0($17)
	move	$5,$16
	jal	P_AimLineAttack
	li	$6,4194304			# 0x400000

	lw	$4,0($17)
	move	$7,$2
	move	$5,$16
	sw	$18,16($sp)
	li	$6,4194304			# 0x400000
	jal	P_LineAttack
	lui	$16,%hi(linetarget)

	lw	$2,%lo(linetarget)($16)
	beq	$2,$0,$L136
	lw	$31,44($sp)

	lw	$4,0($17)
	jal	S_StartSound
	li	$5,83			# 0x53

	lw	$17,0($17)
	lw	$2,%lo(linetarget)($16)
	lw	$5,16($17)
	lw	$7,16($2)
	lw	$6,12($2)
	jal	R_PointToAngle2
	lw	$4,12($17)

	sw	$2,32($17)
	lw	$31,44($sp)
$L136:
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	A_Punch
	.size	A_Punch, .-A_Punch
	.align	2
	.globl	A_Saw
	.set	nomips16
	.set	nomicromips
	.ent	A_Saw
	.type	A_Saw, @function
A_Saw:
	.frame	$sp,48,$31		# vars= 0, regs= 6/0, args= 24, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,32($sp)
	move	$18,$4
	sw	$31,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$17,28($sp)
	jal	P_Random
	sw	$16,24($sp)

	lw	$3,0($18)
	move	$16,$2
	jal	P_Random
	lw	$20,32($3)

	jal	P_Random
	move	$17,$2

	subu	$17,$17,$2
	sll	$17,$17,18
	lw	$4,0($18)
	li	$19,4194304			# 0x400000
	addu	$17,$17,$20
	move	$5,$17
	jal	P_AimLineAttack
	addiu	$6,$19,1

	li	$3,1717960704			# 0x66660000
	addiu	$3,$3,26215
	mult	$16,$3
	sra	$4,$16,31
	mfhi	$3
	move	$7,$2
	sra	$3,$3,2
	subu	$3,$3,$4
	sll	$4,$3,2
	addu	$3,$4,$3
	sll	$3,$3,1
	subu	$16,$16,$3
	addiu	$16,$16,1
	lw	$4,0($18)
	sll	$16,$16,1
	sw	$16,16($sp)
	ori	$6,$19,0x1
	move	$5,$17
	jal	P_LineAttack
	lui	$16,%hi(linetarget)

	lw	$2,%lo(linetarget)($16)
	beq	$2,$0,$L145
	lw	$4,0($18)

	jal	S_StartSound
	li	$5,13			# 0xd

	lw	$3,%lo(linetarget)($16)
	lw	$2,0($18)
	lw	$6,12($3)
	lw	$5,16($2)
	lw	$7,16($3)
	jal	R_PointToAngle2
	lw	$4,12($2)

	lw	$5,0($18)
	li	$4,-2147483648			# 0xffffffff80000000
	lw	$3,32($5)
	addiu	$4,$4,1
	subu	$6,$2,$3
	sltu	$4,$6,$4
	beq	$4,$0,$L146
	li	$4,-53739520			# 0xfffffffffccc0000

	li	$4,53673984			# 0x3330000
	addiu	$7,$4,13108
	sltu	$6,$6,$7
	bne	$6,$0,$L142
	lw	$31,44($sp)

	li	$3,-51183616			# 0xfffffffffcf30000
	ori	$3,$3,0xcf3d
	addu	$2,$2,$3
	lw	$3,104($5)
	sw	$2,32($5)
	ori	$2,$3,0x80
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	sw	$2,104($5)
	jr	$31
	addiu	$sp,$sp,48

$L146:
	ori	$4,$4,0xcccd
	slt	$6,$6,$4
	beq	$6,$0,$L144
	lw	$31,44($sp)

	li	$3,51118080			# 0x30c0000
	addiu	$3,$3,12483
	addu	$2,$2,$3
	lw	$3,104($5)
	sw	$2,32($5)
	ori	$2,$3,0x80
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	sw	$2,104($5)
	jr	$31
	addiu	$sp,$sp,48

$L142:
	addiu	$4,$4,13107
$L144:
	addu	$2,$3,$4
	lw	$3,104($5)
	lw	$31,44($sp)
	sw	$2,32($5)
	ori	$2,$3,0x80
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	sw	$2,104($5)
	jr	$31
	addiu	$sp,$sp,48

$L145:
	lw	$31,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	li	$5,12			# 0xc
	j	S_StartSound
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	A_Saw
	.size	A_Saw, .-A_Saw
	.align	2
	.globl	A_FireMissile
	.set	nomips16
	.set	nomicromips
	.ent	A_FireMissile
	.type	A_FireMissile, @function
A_FireMissile:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,120($4)
	li	$5,33			# 0x21
	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$3,%hi(weaponinfo)
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$2,$3
	lw	$2,0($2)
	sll	$2,$2,2
	addu	$2,$4,$2
	lw	$3,164($2)
	addiu	$3,$3,-1
	sw	$3,164($2)
	j	P_SpawnPlayerMissile
	lw	$4,0($4)

	.set	macro
	.set	reorder
	.end	A_FireMissile
	.size	A_FireMissile, .-A_FireMissile
	.align	2
	.globl	A_FireBFG
	.set	nomips16
	.set	nomicromips
	.ent	A_FireBFG
	.type	A_FireBFG, @function
A_FireBFG:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,120($4)
	li	$5,35			# 0x23
	sll	$2,$3,1
	addu	$2,$2,$3
	lui	$3,%hi(weaponinfo)
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$2,$3
	lw	$2,0($2)
	sll	$2,$2,2
	addu	$2,$4,$2
	lw	$3,164($2)
	addiu	$3,$3,-40
	sw	$3,164($2)
	j	P_SpawnPlayerMissile
	lw	$4,0($4)

	.set	macro
	.set	reorder
	.end	A_FireBFG
	.size	A_FireBFG, .-A_FireBFG
	.align	2
	.globl	A_FirePlasma
	.set	nomips16
	.set	nomicromips
	.ent	A_FirePlasma
	.type	A_FirePlasma, @function
A_FirePlasma:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$5,120($4)
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	sll	$4,$5,1
	addu	$2,$4,$5
	lui	$3,%hi(weaponinfo)
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,0($2)
	addu	$4,$4,$5
	sll	$2,$2,2
	addu	$2,$16,$2
	lw	$6,164($2)
	sll	$4,$4,3
	addiu	$6,$6,-1
	sw	$31,28($sp)
	sw	$17,24($sp)
	addu	$3,$3,$4
	sw	$6,164($2)
	jal	P_Random
	lw	$17,20($3)

	andi	$2,$2,0x1
	move	$4,$16
	li	$5,1			# 0x1
	jal	P_SetPsprite
	addu	$6,$2,$17

	lw	$4,0($16)
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$5,34			# 0x22
	j	P_SpawnPlayerMissile
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_FirePlasma
	.size	A_FirePlasma, .-A_FirePlasma
	.align	2
	.globl	P_BulletSlope
	.set	nomips16
	.set	nomicromips
	.ent	P_BulletSlope
	.type	P_BulletSlope, @function
P_BulletSlope:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$18,24($sp)
	lw	$18,32($4)
	sw	$19,28($sp)
	li	$6,67108864			# 0x4000000
	move	$5,$18
	lui	$19,%hi(linetarget)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,36($sp)
	sw	$20,32($sp)
	jal	P_AimLineAttack
	move	$16,$4

	lw	$3,%lo(linetarget)($19)
	lui	$17,%hi(bulletslope)
	beq	$3,$0,$L162
	sw	$2,%lo(bulletslope)($17)

$L157:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L162:
	li	$20,67108864			# 0x4000000
	li	$6,67108864			# 0x4000000
	addu	$5,$18,$20
	jal	P_AimLineAttack
	move	$4,$16

	lw	$3,%lo(linetarget)($19)
	bne	$3,$0,$L157
	sw	$2,%lo(bulletslope)($17)

	li	$6,67108864			# 0x4000000
	subu	$5,$18,$20
	jal	P_AimLineAttack
	move	$4,$16

	b	$L157
	sw	$2,%lo(bulletslope)($17)

	.set	macro
	.set	reorder
	.end	P_BulletSlope
	.size	P_BulletSlope, .-P_BulletSlope
	.align	2
	.globl	P_GunShot
	.set	nomips16
	.set	nomicromips
	.ent	P_GunShot
	.type	P_GunShot, @function
P_GunShot:
	.frame	$sp,48,$31		# vars= 8, regs= 4/0, args= 24, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	move	$18,$5
	sw	$31,44($sp)
	jal	P_Random
	move	$16,$4

	li	$3,1431633920			# 0x55550000
	addiu	$3,$3,21846
	mult	$2,$3
	sra	$4,$2,31
	mfhi	$3
	lw	$5,32($16)
	subu	$3,$3,$4
	sll	$4,$3,1
	addu	$3,$4,$3
	subu	$2,$2,$3
	addiu	$2,$2,1
	sll	$17,$2,2
	beq	$18,$0,$L166
	addu	$17,$17,$2

	lui	$2,%hi(bulletslope)
	lw	$7,%lo(bulletslope)($2)
	sw	$17,16($sp)
	move	$4,$16
	jal	P_LineAttack
	li	$6,134217728			# 0x8000000

	lw	$31,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,48

$L166:
	jal	P_Random
	sw	$5,24($sp)

	jal	P_Random
	move	$18,$2

	subu	$18,$18,$2
	lw	$5,24($sp)
	lui	$2,%hi(bulletslope)
	sll	$18,$18,18
	lw	$7,%lo(bulletslope)($2)
	sw	$17,16($sp)
	addu	$5,$5,$18
	move	$4,$16
	jal	P_LineAttack
	li	$6,134217728			# 0x8000000

	lw	$31,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	P_GunShot
	.size	P_GunShot, .-P_GunShot
	.align	2
	.globl	A_FirePistol
	.set	nomips16
	.set	nomicromips
	.ent	A_FirePistol
	.type	A_FirePistol, @function
A_FirePistol:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,0($4)
	sw	$31,20($sp)
	jal	S_StartSound
	li	$5,1			# 0x1

	lw	$4,0($16)
	jal	P_SetMobjState
	li	$5,155			# 0x9b

	lw	$5,120($16)
	lui	$3,%hi(weaponinfo)
	sll	$4,$5,1
	addu	$2,$4,$5
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,0($2)
	addu	$4,$4,$5
	sll	$2,$2,2
	addu	$2,$16,$2
	lw	$6,164($2)
	sll	$4,$4,3
	addiu	$6,$6,-1
	addu	$3,$3,$4
	sw	$6,164($2)
	lw	$6,20($3)
	li	$5,1			# 0x1
	jal	P_SetPsprite
	move	$4,$16

	jal	P_BulletSlope
	lw	$4,0($16)

	lw	$5,208($16)
	lw	$4,0($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	sltu	$5,$5,1
	j	P_GunShot
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	A_FirePistol
	.size	A_FirePistol, .-A_FirePistol
	.align	2
	.globl	A_FireShotgun
	.set	nomips16
	.set	nomicromips
	.ent	A_FireShotgun
	.type	A_FireShotgun, @function
A_FireShotgun:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	move	$17,$4
	lw	$4,0($4)
	li	$5,2			# 0x2
	sw	$31,28($sp)
	jal	S_StartSound
	sw	$16,20($sp)

	lw	$4,0($17)
	jal	P_SetMobjState
	li	$5,155			# 0x9b

	lw	$5,120($17)
	lui	$3,%hi(weaponinfo)
	sll	$4,$5,1
	addu	$2,$4,$5
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,0($2)
	addu	$4,$4,$5
	sll	$2,$2,2
	addu	$2,$17,$2
	lw	$6,164($2)
	sll	$4,$4,3
	addiu	$6,$6,-1
	addu	$3,$3,$4
	sw	$6,164($2)
	lw	$6,20($3)
	move	$4,$17
	jal	P_SetPsprite
	li	$5,1			# 0x1

	lw	$4,0($17)
	jal	P_BulletSlope
	li	$16,7			# 0x7

$L174:
	lw	$4,0($17)
	addiu	$16,$16,-1
	jal	P_GunShot
	move	$5,$0

	bne	$16,$0,$L174
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_FireShotgun
	.size	A_FireShotgun, .-A_FireShotgun
	.align	2
	.globl	A_FireShotgun2
	.set	nomips16
	.set	nomicromips
	.ent	A_FireShotgun2
	.type	A_FireShotgun2, @function
A_FireShotgun2:
	.frame	$sp,64,$31		# vars= 0, regs= 9/0, args= 24, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$19,40($sp)
	move	$19,$4
	lw	$4,0($4)
	li	$5,4			# 0x4
	sw	$31,60($sp)
	sw	$21,48($sp)
	sw	$20,44($sp)
	sw	$18,36($sp)
	sw	$23,56($sp)
	sw	$22,52($sp)
	sw	$17,32($sp)
	jal	S_StartSound
	sw	$16,28($sp)

	lw	$4,0($19)
	jal	P_SetMobjState
	li	$5,155			# 0x9b

	lw	$5,120($19)
	lui	$3,%hi(weaponinfo)
	sll	$4,$5,1
	addu	$2,$4,$5
	addiu	$3,$3,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,0($2)
	addu	$4,$4,$5
	sll	$2,$2,2
	addu	$2,$19,$2
	lw	$6,164($2)
	sll	$4,$4,3
	addiu	$6,$6,-2
	addu	$3,$3,$4
	sw	$6,164($2)
	lw	$6,20($3)
	move	$4,$19
	jal	P_SetPsprite
	li	$5,1			# 0x1

	lw	$4,0($19)
	jal	P_BulletSlope
	li	$20,1431633920			# 0x55550000

	li	$18,20			# 0x14
	lui	$21,%hi(bulletslope)
	addiu	$20,$20,21846
$L180:
	jal	P_Random
	addiu	$18,$18,-1

	lw	$3,0($19)
	move	$16,$2
	jal	P_Random
	lw	$22,32($3)

	jal	P_Random
	move	$17,$2

	subu	$17,$17,$2
	lw	$23,0($19)
	jal	P_Random
	sll	$17,$17,19

	addu	$17,$17,$22
	jal	P_Random
	move	$22,$2

	mult	$16,$20
	sra	$4,$16,31
	mfhi	$3
	subu	$22,$22,$2
	subu	$3,$3,$4
	sll	$4,$3,1
	addu	$3,$4,$3
	subu	$16,$16,$3
	addiu	$16,$16,1
	lw	$7,%lo(bulletslope)($21)
	sll	$2,$16,2
	sll	$22,$22,5
	addu	$2,$2,$16
	sw	$2,16($sp)
	addu	$7,$22,$7
	li	$6,134217728			# 0x8000000
	move	$5,$17
	jal	P_LineAttack
	move	$4,$23

	bne	$18,$0,$L180
	lw	$31,60($sp)

	lw	$23,56($sp)
	lw	$22,52($sp)
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	A_FireShotgun2
	.size	A_FireShotgun2, .-A_FireShotgun2
	.align	2
	.globl	A_FireCGun
	.set	nomips16
	.set	nomicromips
	.ent	A_FireCGun
	.type	A_FireCGun, @function
A_FireCGun:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,0($4)
	sw	$17,20($sp)
	move	$17,$5
	sw	$18,24($sp)
	sw	$31,28($sp)
	jal	S_StartSound
	li	$5,1			# 0x1

	lw	$3,120($16)
	lui	$18,%hi(weaponinfo)
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addiu	$18,$18,%lo(weaponinfo)
	addu	$2,$18,$2
	lw	$2,0($2)
	addiu	$2,$2,40
	sll	$2,$2,2
	addu	$2,$16,$2
	lw	$2,4($2)
	bne	$2,$0,$L188
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L188:
	lw	$4,0($16)
	jal	P_SetMobjState
	li	$5,155			# 0x9b

	lw	$4,120($16)
	li	$6,-1227161600			# 0xffffffffb6db0000
	sll	$3,$4,1
	addu	$2,$3,$4
	sll	$2,$2,3
	addu	$2,$18,$2
	lw	$2,0($2)
	addu	$3,$3,$4
	sll	$2,$2,2
	addu	$2,$16,$2
	lw	$5,164($2)
	sll	$3,$3,3
	addiu	$5,$5,-1
	sw	$5,164($2)
	addu	$18,$18,$3
	lw	$4,20($18)
	lw	$2,0($17)
	sll	$3,$4,3
	subu	$3,$3,$4
	sll	$3,$3,2
	addu	$2,$2,$3
	lui	$3,%hi(states+1456)
	addiu	$3,$3,%lo(states+1456)
	subu	$2,$2,$3
	sra	$2,$2,2
	addiu	$6,$6,28087
	multu	$2,$6
	mflo	$6
	li	$5,1			# 0x1
	jal	P_SetPsprite
	move	$4,$16

	jal	P_BulletSlope
	lw	$4,0($16)

	lw	$5,208($16)
	lw	$4,0($16)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sltu	$5,$5,1
	j	P_GunShot
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	A_FireCGun
	.size	A_FireCGun, .-A_FireCGun
	.align	2
	.globl	A_Light0
	.set	nomips16
	.set	nomicromips
	.ent	A_Light0
	.type	A_Light0, @function
A_Light0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	sw	$0,240($4)

	.set	macro
	.set	reorder
	.end	A_Light0
	.size	A_Light0, .-A_Light0
	.align	2
	.globl	A_Light1
	.set	nomips16
	.set	nomicromips
	.ent	A_Light1
	.type	A_Light1, @function
A_Light1:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1			# 0x1
	jr	$31
	sw	$2,240($4)

	.set	macro
	.set	reorder
	.end	A_Light1
	.size	A_Light1, .-A_Light1
	.align	2
	.globl	A_Light2
	.set	nomips16
	.set	nomicromips
	.ent	A_Light2
	.type	A_Light2, @function
A_Light2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,2			# 0x2
	jr	$31
	sw	$2,240($4)

	.set	macro
	.set	reorder
	.end	A_Light2
	.size	A_Light2, .-A_Light2
	.align	2
	.globl	A_BFGSpray
	.set	nomips16
	.set	nomicromips
	.ent	A_BFGSpray
	.type	A_BFGSpray, @function
A_BFGSpray:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$20,36($sp)
	sw	$19,32($sp)
	li	$20,26804224			# 0x1990000
	li	$19,1073676288			# 0x3fff0000
	sw	$21,40($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	move	$17,$4
	move	$16,$0
	lui	$18,%hi(linetarget)
	li	$21,-536870912			# 0xffffffffe0000000
	ori	$20,$20,0x9999
	b	$L195
	ori	$19,$19,0xffe8

$L193:
	addu	$16,$16,$20
	.set	noat
	xor	$1,$16,$19
	beq	$1,$0,$L203
	.set	at
	lw	$31,52($sp)

$L195:
	lw	$5,32($17)
	lw	$4,120($17)
	addu	$5,$5,$21
	li	$6,67108864			# 0x4000000
	jal	P_AimLineAttack
	addu	$5,$5,$16

	lw	$2,%lo(linetarget)($18)
	beq	$2,$0,$L193
	li	$7,42			# 0x2a

	lw	$3,68($2)
	lw	$6,20($2)
	sra	$3,$3,2
	lw	$5,16($2)
	lw	$4,12($2)
	jal	P_SpawnMobj
	addu	$6,$3,$6

	li	$22,15			# 0xf
	move	$23,$0
$L194:
	jal	P_Random
	addiu	$22,$22,-1

	andi	$2,$2,0x7
	addiu	$2,$2,1
	bne	$22,$0,$L194
	addu	$23,$23,$2

	lw	$6,120($17)
	lw	$4,%lo(linetarget)($18)
	move	$7,$23
	move	$5,$6
	jal	P_DamageMobj
	addu	$16,$16,$20

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L195
	.set	at
	lw	$31,52($sp)

$L203:
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	A_BFGSpray
	.size	A_BFGSpray, .-A_BFGSpray
	.align	2
	.globl	A_BFGsound
	.set	nomips16
	.set	nomicromips
	.ent	A_BFGsound
	.type	A_BFGsound, @function
A_BFGsound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$4,0($4)
	j	S_StartSound
	li	$5,9			# 0x9

	.set	macro
	.set	reorder
	.end	A_BFGsound
	.size	A_BFGsound, .-A_BFGsound
	.align	2
	.globl	P_SetupPsprites
	.set	nomips16
	.set	nomicromips
	.ent	P_SetupPsprites
	.type	P_SetupPsprites, @function
P_SetupPsprites:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,120($4)
	sw	$0,252($4)
	sw	$0,268($4)
	j	P_BringUpWeapon
	sw	$3,124($4)

	.set	macro
	.set	reorder
	.end	P_SetupPsprites
	.size	P_SetupPsprites, .-P_SetupPsprites
	.align	2
	.globl	P_MovePsprites
	.set	nomips16
	.set	nomicromips
	.ent	P_MovePsprites
	.type	P_MovePsprites, @function
P_MovePsprites:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,252($4)
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	move	$16,$4
	addiu	$17,$4,252
	beq	$3,$0,$L208
	move	$18,$0

$L207:
	lw	$2,4($17)
	li	$4,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L208
	.set	at
	addiu	$2,$2,-1

	beq	$2,$0,$L215
	sw	$2,4($17)

$L208:
	bne	$18,$0,$L212
	addiu	$17,$17,16

	lw	$3,0($17)
	bne	$3,$0,$L207
	li	$18,1			# 0x1

$L212:
	lw	$3,264($16)
	lw	$2,260($16)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$3,280($16)
	sw	$2,276($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L215:
	lw	$6,16($3)
	move	$5,$18
	jal	P_SetPsprite
	move	$4,$16

	b	$L208
	nop

	.set	macro
	.set	reorder
	.end	P_MovePsprites
	.size	P_MovePsprites, .-P_MovePsprites
	.globl	bulletslope
	.section	.bss,"aw",@nobits
	.align	2
	.type	bulletslope, @object
	.size	bulletslope, 4
bulletslope:
	.space	4
	.globl	swingy
	.align	2
	.type	swingy, @object
	.size	swingy, 4
swingy:
	.space	4
	.globl	swingx
	.align	2
	.type	swingx, @object
	.size	swingx, 4
swingx:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
