	.file	1 "p_saveg.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"saveg_write8: Error while writing save game\012\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	saveg_write8
	.type	saveg_write8, @function
saveg_write8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(save_stream)
	addiu	$sp,$sp,-24
	lw	$7,%lo(save_stream)($2)
	move	$2,$4
	sw	$16,16($sp)
	li	$6,1			# 0x1
	li	$5,1			# 0x1
	addiu	$4,$sp,24
	lui	$16,%hi(savegame_error)
	sw	$31,20($sp)
	jal	fwrite
	sb	$2,24($sp)

	lw	$3,%lo(savegame_error)($16)
	or	$2,$2,$3
	beq	$2,$0,$L5
	lw	$31,20($sp)

	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L5:
	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC0)
	jal	fprintf
	addiu	$5,$5,%lo($LC0)

	lw	$31,20($sp)
	li	$2,1			# 0x1
	sw	$2,%lo(savegame_error)($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	saveg_write8
	.size	saveg_write8, .-saveg_write8
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"saveg_read8: Unexpected end of file while reading save g"
	.ascii	"ame\012\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	saveg_read8
	.type	saveg_read8, @function
saveg_read8:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(save_stream)
	addiu	$sp,$sp,-32
	lw	$7,%lo(save_stream)($2)
	li	$6,1			# 0x1
	sw	$16,24($sp)
	li	$5,1			# 0x1
	addiu	$4,$sp,16
	sw	$31,28($sp)
	jal	fread
	lui	$16,%hi(savegame_error)

	lw	$3,%lo(savegame_error)($16)
	or	$2,$2,$3
	beq	$2,$0,$L9
	lw	$31,28($sp)

	lbu	$2,16($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L9:
	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC1)
	jal	fprintf
	addiu	$5,$5,%lo($LC1)

	lw	$31,28($sp)
	li	$2,1			# 0x1
	sw	$2,%lo(savegame_error)($16)
	lbu	$2,16($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	saveg_read8
	.size	saveg_read8, .-saveg_read8
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	saveg_write_ceiling_t
	.type	saveg_write_ceiling_t, @function
saveg_write_ceiling_t:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lw	$17,0($4)
	sw	$16,20($sp)
	move	$16,$4
	sw	$31,28($sp)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,4($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,8($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,12($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lui	$2,%hi(sectors)
	lw	$17,16($16)
	lw	$2,%lo(sectors)($2)
	subu	$17,$17,$2
	li	$2,-1171390464			# 0xffffffffba2e0000
	ori	$2,$2,0x8ba3
	sra	$17,$17,3
	multu	$17,$2
	mflo	$17
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,20($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,24($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,28($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,32($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,36($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$17,40($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$17,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$17,24

	lw	$16,44($16)
	jal	saveg_write8
	andi	$4,$16,0x00ff

	sra	$4,$16,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$16,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lw	$31,28($sp)
	lw	$17,24($sp)
	srl	$4,$16,24
	lw	$16,20($sp)
	j	saveg_write8
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	saveg_write_ceiling_t
	.size	saveg_write_ceiling_t, .-saveg_write_ceiling_t
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"temp.dsg\000"
	.text
	.align	2
	.globl	P_TempSaveGameFile
	.set	nomips16
	.set	nomicromips
	.ent	P_TempSaveGameFile
	.type	P_TempSaveGameFile, @function
P_TempSaveGameFile:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(filename.2)
	lw	$2,%lo(filename.2)($16)
	beq	$2,$0,$L15
	sw	$31,20($sp)

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L15:
	lui	$2,%hi(savegamedir)
	lw	$4,%lo(savegamedir)($2)
	lui	$5,%hi($LC2)
	move	$6,$0
	jal	M_StringJoin
	addiu	$5,$5,%lo($LC2)

	lw	$31,20($sp)
	sw	$2,%lo(filename.2)($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_TempSaveGameFile
	.size	P_TempSaveGameFile, .-P_TempSaveGameFile
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"doomsav%d.dsg\000"
	.align	2
$LC4:
	.ascii	"%s%s\000"
	.text
	.align	2
	.globl	P_SaveGameFile
	.set	nomips16
	.set	nomicromips
	.ent	P_SaveGameFile
	.type	P_SaveGameFile, @function
P_SaveGameFile:
	.frame	$sp,80,$31		# vars= 32, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	sw	$16,60($sp)
	lui	$16,%hi(filename.1)
	lw	$2,%lo(filename.1)($16)
	sw	$31,76($sp)
	sw	$19,72($sp)
	sw	$18,68($sp)
	sw	$17,64($sp)
	beq	$2,$0,$L19
	move	$7,$4

	lui	$19,%hi(savegamedir)
	lui	$18,%hi(filename_size.0)
$L17:
	addiu	$17,$sp,24
	lui	$6,%hi($LC3)
	move	$4,$17
	addiu	$6,$6,%lo($LC3)
	jal	snprintf
	li	$5,32			# 0x20

	lw	$7,%lo(savegamedir)($19)
	lw	$5,%lo(filename_size.0)($18)
	lw	$4,%lo(filename.1)($16)
	lui	$6,%hi($LC4)
	sw	$17,16($sp)
	jal	M_snprintf
	addiu	$6,$6,%lo($LC4)

	lw	$31,76($sp)
	lw	$2,%lo(filename.1)($16)
	lw	$19,72($sp)
	lw	$18,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	jr	$31
	addiu	$sp,$sp,80

$L19:
	lui	$19,%hi(savegamedir)
	sw	$4,80($sp)
	lw	$4,%lo(savegamedir)($19)
	jal	strlen
	lui	$18,%hi(filename_size.0)

	addiu	$4,$2,32
	jal	malloc
	sw	$4,%lo(filename_size.0)($18)

	sw	$2,%lo(filename.1)($16)
	b	$L17
	lw	$7,80($sp)

	.set	macro
	.set	reorder
	.end	P_SaveGameFile
	.size	P_SaveGameFile, .-P_SaveGameFile
	.section	.rodata.str1.4
	.align	2
$LC5:
	.ascii	"version %i\000"
	.text
	.align	2
	.globl	P_WriteSaveGameHeader
	.set	nomips16
	.set	nomicromips
	.ent	P_WriteSaveGameHeader
	.type	P_WriteSaveGameHeader, @function
P_WriteSaveGameHeader:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,40($sp)
	sw	$16,36($sp)
	sw	$31,44($sp)
	move	$17,$4
	lb	$4,0($4)
	beq	$4,$0,$L22
	move	$16,$0

$L23:
	andi	$4,$4,0x00ff
	jal	saveg_write8
	addiu	$16,$16,1

	addu	$2,$17,$16
	lb	$4,0($2)
	bne	$4,$0,$L23
	slt	$2,$16,24

	beq	$2,$0,$L34
	addiu	$4,$sp,16

$L22:
	li	$17,24			# 0x18
$L25:
	addiu	$16,$16,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L25
	.set	at
	addiu	$4,$sp,16

$L34:
	li	$6,16			# 0x10
	jal	memset
	move	$5,$0

	jal	G_VanillaVersionCode
	addiu	$17,$sp,32

	lui	$6,%hi($LC5)
	move	$7,$2
	addiu	$6,$6,%lo($LC5)
	li	$5,16			# 0x10
	jal	M_snprintf
	addiu	$4,$sp,16

	addiu	$16,$sp,16
$L26:
	lbu	$4,0($16)
	jal	saveg_write8
	addiu	$16,$16,1

	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L26
	.set	at
	lui	$2,%hi(gameskill)

	lbu	$4,%lo(gameskill)($2)
	jal	saveg_write8
	lui	$16,%hi(playeringame)

	lui	$2,%hi(gameepisode)
	lbu	$4,%lo(gameepisode)($2)
	jal	saveg_write8
	addiu	$16,$16,%lo(playeringame)

	lui	$2,%hi(gamemap)
	lbu	$4,%lo(gamemap)($2)
	jal	saveg_write8
	addiu	$17,$16,16

$L27:
	lbu	$4,0($16)
	jal	saveg_write8
	addiu	$16,$16,4

	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L27
	.set	at
	nop

	lui	$16,%hi(leveltime)
	jal	saveg_write8
	lbu	$4,%lo(leveltime+2)($16)

	jal	saveg_write8
	lbu	$4,%lo(leveltime+1)($16)

	jal	saveg_write8
	lbu	$4,%lo(leveltime)($16)

	lw	$31,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	P_WriteSaveGameHeader
	.size	P_WriteSaveGameHeader, .-P_WriteSaveGameHeader
	.align	2
	.globl	P_ReadSaveGameHeader
	.set	nomips16
	.set	nomicromips
	.ent	P_ReadSaveGameHeader
	.type	P_ReadSaveGameHeader, @function
P_ReadSaveGameHeader:
	.frame	$sp,64,$31		# vars= 32, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$16,48($sp)
	sw	$31,60($sp)
	sw	$18,56($sp)
	sw	$17,52($sp)
	li	$16,24			# 0x18
$L36:
	jal	saveg_read8
	addiu	$16,$16,-1

	bne	$16,$0,$L36
	addiu	$17,$sp,16

	addiu	$18,$sp,32
$L37:
	jal	saveg_read8
	nop

	sb	$2,0($17)
	addiu	$17,$17,1
	.set	noat
	xor	$1,$18,$17
	bne	$1,$0,$L37
	.set	at
	move	$4,$18

	li	$6,16			# 0x10
	jal	memset
	move	$5,$0

	jal	G_VanillaVersionCode
	nop

	lui	$6,%hi($LC5)
	move	$4,$18
	li	$5,16			# 0x10
	move	$7,$2
	jal	M_snprintf
	addiu	$6,$6,%lo($LC5)

	move	$5,$18
	jal	strcmp
	addiu	$4,$sp,16

	beq	$2,$0,$L44
	lw	$31,60($sp)

	lw	$18,56($sp)
	lw	$17,52($sp)
	move	$2,$16
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,64

$L44:
	jal	saveg_read8
	lui	$16,%hi(playeringame)

	lui	$3,%hi(gameskill)
	jal	saveg_read8
	sw	$2,%lo(gameskill)($3)

	lui	$3,%hi(gameepisode)
	sw	$2,%lo(gameepisode)($3)
	jal	saveg_read8
	addiu	$16,$16,%lo(playeringame)

	lui	$3,%hi(gamemap)
	sw	$2,%lo(gamemap)($3)
	addiu	$17,$16,16
$L39:
	jal	saveg_read8
	nop

	sw	$2,0($16)
	addiu	$16,$16,4
	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L39
	.set	at
	nop

	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$16,$2

	move	$17,$2
	sll	$17,$17,8
	jal	saveg_read8
	sll	$16,$16,16

	addu	$16,$16,$17
	addu	$16,$16,$2
	lw	$31,60($sp)
	lui	$2,%hi(leveltime)
	sw	$16,%lo(leveltime)($2)
	li	$16,1			# 0x1
	lw	$18,56($sp)
	lw	$17,52($sp)
	move	$2,$16
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	P_ReadSaveGameHeader
	.size	P_ReadSaveGameHeader, .-P_ReadSaveGameHeader
	.align	2
	.globl	P_ReadSaveGameEOF
	.set	nomips16
	.set	nomicromips
	.ent	P_ReadSaveGameEOF
	.type	P_ReadSaveGameEOF, @function
P_ReadSaveGameEOF:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(save_stream)
	addiu	$sp,$sp,-32
	lw	$7,%lo(save_stream)($2)
	li	$6,1			# 0x1
	sw	$16,24($sp)
	li	$5,1			# 0x1
	addiu	$4,$sp,16
	sw	$31,28($sp)
	jal	fread
	lui	$16,%hi(savegame_error)

	lw	$3,%lo(savegame_error)($16)
	or	$2,$2,$3
	beq	$2,$0,$L48
	lbu	$2,16($sp)

	lw	$31,28($sp)
	xori	$2,$2,0x1d
	lw	$16,24($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

$L48:
	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC1)
	jal	fprintf
	addiu	$5,$5,%lo($LC1)

	li	$2,1			# 0x1
	sw	$2,%lo(savegame_error)($16)
	lbu	$2,16($sp)
	lw	$31,28($sp)
	xori	$2,$2,0x1d
	lw	$16,24($sp)
	sltu	$2,$2,1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_ReadSaveGameEOF
	.size	P_ReadSaveGameEOF, .-P_ReadSaveGameEOF
	.align	2
	.globl	P_WriteSaveGameEOF
	.set	nomips16
	.set	nomicromips
	.ent	P_WriteSaveGameEOF
	.type	P_WriteSaveGameEOF, @function
P_WriteSaveGameEOF:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(save_stream)
	addiu	$sp,$sp,-32
	lw	$7,%lo(save_stream)($2)
	li	$2,29			# 0x1d
	sw	$16,24($sp)
	li	$6,1			# 0x1
	li	$5,1			# 0x1
	addiu	$4,$sp,16
	lui	$16,%hi(savegame_error)
	sw	$31,28($sp)
	jal	fwrite
	sb	$2,16($sp)

	lw	$3,%lo(savegame_error)($16)
	or	$2,$2,$3
	beq	$2,$0,$L52
	lw	$31,28($sp)

	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L52:
	lui	$2,%hi(stderr)
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC0)
	jal	fprintf
	addiu	$5,$5,%lo($LC0)

	lw	$31,28($sp)
	li	$2,1			# 0x1
	sw	$2,%lo(savegame_error)($16)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_WriteSaveGameEOF
	.size	P_WriteSaveGameEOF, .-P_WriteSaveGameEOF
	.align	2
	.globl	P_ArchivePlayers
	.set	nomips16
	.set	nomicromips
	.ent	P_ArchivePlayers
	.type	P_ArchivePlayers, @function
P_ArchivePlayers:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$16,32($sp)
	lui	$16,%hi(players)
	addiu	$16,$16,%lo(players)
	addiu	$2,$16,1152
	sw	$2,16($sp)
	lui	$2,%hi(save_stream)
	sw	$2,24($sp)
	lui	$2,%hi(states)
	sw	$22,56($sp)
	addiu	$2,$2,%lo(states)
	lui	$22,%hi(playeringame)
	sw	$21,52($sp)
	sw	$19,44($sp)
	sw	$17,36($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$23,60($sp)
	sw	$20,48($sp)
	sw	$18,40($sp)
	addiu	$22,$22,%lo(playeringame)
	addiu	$19,$16,164
	addiu	$17,$16,24
	li	$21,4			# 0x4
	sw	$2,20($sp)
$L66:
	lw	$2,0($22)
	beq	$2,$0,$L86
	lw	$2,16($sp)

	lw	$2,24($sp)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$18,$0,$2
	andi	$18,$18,0x3
	beq	$18,$0,$L55
	move	$20,$0

	addiu	$20,$20,1
$L87:
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$18,$20
	bne	$1,$0,$L87
	.set	at
	addiu	$20,$20,1

$L55:
	lw	$18,0($16)
	move	$20,$16
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,4($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	jal	saveg_write8
	lbu	$4,8($16)

	jal	saveg_write8
	lbu	$4,9($16)

	lh	$18,10($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	lbu	$4,14($16)

	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	lbu	$4,12($16)

	jal	saveg_write8
	lbu	$4,13($16)

	lw	$18,24($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,28($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,32($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,36($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,40($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,44($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,48($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

$L57:
	lw	$18,52($20)
	addiu	$20,$20,4
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	.set	noat
	xor	$1,$20,$17
	bne	$1,$0,$L57
	.set	at
	nop

	move	$20,$16
$L58:
	lw	$18,76($20)
	addiu	$20,$20,4
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	.set	noat
	xor	$1,$20,$17
	bne	$1,$0,$L58
	.set	at
	move	$23,$16

	lw	$18,100($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	move	$20,$0
$L59:
	lw	$18,104($23)
	addiu	$20,$20,1
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	.set	noat
	xor	$1,$20,$21
	bne	$1,$0,$L59
	.set	at
	addiu	$23,$23,4

	lw	$18,120($16)
	addiu	$20,$16,128
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,124($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

$L60:
	lw	$18,0($20)
	addiu	$20,$20,4
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	.set	noat
	xor	$1,$20,$19
	bne	$1,$0,$L60
	.set	at
	nop

	move	$23,$16
	move	$20,$0
$L61:
	lw	$18,164($23)
	addiu	$20,$20,1
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	.set	noat
	xor	$1,$20,$21
	bne	$1,$0,$L61
	.set	at
	addiu	$23,$23,4

	move	$23,$16
	move	$20,$0
$L62:
	lw	$18,180($23)
	addiu	$20,$20,1
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	.set	noat
	xor	$1,$20,$21
	bne	$1,$0,$L62
	.set	at
	addiu	$23,$23,4

	lw	$18,196($16)
	move	$20,$16
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,200($16)
	li	$23,-1227161600			# 0xffffffffb6db0000
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,204($16)
	addiu	$23,$23,28087
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,208($16)
	move	$fp,$0
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,212($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,216($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,220($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,224($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,228($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,232($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,236($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,240($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,244($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,248($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$2,252($20)
	lw	$3,20($sp)
	subu	$18,$2,$3
	sra	$18,$18,2
	beq	$2,$0,$L63
	multu	$18,$23
	mflo	$18

$L84:
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,256($20)
$L85:
	addiu	$20,$20,16
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,244($20)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$18,248($20)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	bne	$fp,$0,$L83
	lw	$3,20($sp)

	lw	$2,252($20)
	li	$fp,1			# 0x1
	subu	$18,$2,$3
	sra	$18,$18,2
	bne	$2,$0,$L84
	multu	$18,$23
	mflo	$18

$L63:
	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	move	$4,$0

	b	$L85
	lw	$18,256($20)

$L83:
	lw	$18,284($16)
	jal	saveg_write8
	andi	$4,$18,0x00ff

	sra	$4,$18,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$18,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$18,24

	lw	$2,16($sp)
$L86:
	addiu	$16,$16,288
	addiu	$22,$22,4
	addiu	$19,$19,288
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L66
	.set	at
	addiu	$17,$17,288

	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	P_ArchivePlayers
	.size	P_ArchivePlayers, .-P_ArchivePlayers
	.align	2
	.globl	P_UnArchivePlayers
	.set	nomips16
	.set	nomicromips
	.ent	P_UnArchivePlayers
	.type	P_UnArchivePlayers, @function
P_UnArchivePlayers:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$16,32($sp)
	lui	$16,%hi(players)
	addiu	$16,$16,%lo(players)
	addiu	$2,$16,1152
	sw	$23,60($sp)
	sw	$2,16($sp)
	lui	$23,%hi(states)
	lui	$2,%hi(save_stream)
	sw	$21,52($sp)
	sw	$2,24($sp)
	lui	$21,%hi(playeringame)
	addiu	$2,$23,%lo(states)
	sw	$20,48($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$22,56($sp)
	sw	$19,44($sp)
	addiu	$21,$21,%lo(playeringame)
	addiu	$18,$16,164
	addiu	$17,$16,24
	li	$20,4			# 0x4
	sw	$2,20($sp)
$L100:
	lw	$2,0($21)
	beq	$2,$0,$L119
	lw	$2,16($sp)

	lw	$2,24($sp)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$19,$0,$2
	andi	$19,$19,0x3
	beq	$19,$0,$L90
	nop

	move	$22,$0
$L91:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$19,$22
	bne	$1,$0,$L91
	.set	at
	nop

$L90:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,0($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,4($16)

	jal	saveg_read8
	sb	$2,8($16)

	jal	saveg_read8
	sb	$2,9($16)

	jal	saveg_read8
	move	$19,$2

	sll	$3,$2,8
	or	$2,$3,$19
	jal	saveg_read8
	sh	$2,10($16)

	jal	saveg_read8
	move	$19,$2

	jal	saveg_read8
	sb	$19,14($16)

	jal	saveg_read8
	sb	$2,12($16)

	jal	saveg_read8
	sb	$2,13($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,24($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,28($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,32($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,36($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,40($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,44($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,48($16)
	move	$22,$16
$L92:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$23
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,52($22)
	addiu	$22,$22,4
	.set	noat
	xor	$1,$22,$17
	bne	$1,$0,$L92
	.set	at
	nop

	move	$22,$16
$L93:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$23
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,76($22)
	addiu	$22,$22,4
	.set	noat
	xor	$1,$22,$17
	bne	$1,$0,$L93
	.set	at
	nop

	jal	saveg_read8
	move	$fp,$16

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,100($16)
	move	$23,$0
$L94:
	jal	saveg_read8
	addiu	$23,$23,1

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,104($fp)
	.set	noat
	xor	$1,$23,$20
	bne	$1,$0,$L94
	.set	at
	addiu	$fp,$fp,4

	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,120($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,124($16)
	addiu	$22,$16,128
$L95:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$23
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,0($22)
	addiu	$22,$22,4
	.set	noat
	xor	$1,$22,$18
	bne	$1,$0,$L95
	.set	at
	nop

	move	$fp,$16
	move	$23,$0
$L96:
	jal	saveg_read8
	addiu	$23,$23,1

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,164($fp)
	.set	noat
	xor	$1,$23,$20
	bne	$1,$0,$L96
	.set	at
	addiu	$fp,$fp,4

	move	$fp,$16
	move	$23,$0
$L97:
	jal	saveg_read8
	addiu	$23,$23,1

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,180($fp)
	.set	noat
	xor	$1,$23,$20
	bne	$1,$0,$L97
	.set	at
	addiu	$fp,$fp,4

	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,196($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,200($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,204($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,208($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,212($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,216($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,220($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,224($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,228($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,232($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,236($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,240($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	jal	saveg_read8
	sw	$2,244($16)

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,248($16)
	move	$19,$16
	move	$22,$0
$L99:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$fp,$2

	sll	$2,$2,16
	sll	$3,$fp,8
	or	$3,$3,$2
	jal	saveg_read8
	or	$23,$3,$23

	sll	$2,$2,24
	or	$2,$2,$23
	sll	$3,$2,3
	subu	$3,$3,$2
	blez	$2,$L101
	sll	$3,$3,2

	lw	$2,20($sp)
	addu	$2,$2,$3
$L98:
	jal	saveg_read8
	sw	$2,252($19)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$fp,$2

	sll	$2,$2,16
	sll	$3,$fp,8
	or	$3,$3,$2
	jal	saveg_read8
	or	$23,$3,$23

	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,256($19)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$fp,$2

	sll	$2,$2,16
	sll	$3,$fp,8
	or	$3,$3,$2
	jal	saveg_read8
	or	$23,$3,$23

	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,260($19)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$fp,$2

	sll	$2,$2,16
	sll	$3,$fp,8
	or	$3,$3,$2
	jal	saveg_read8
	or	$23,$3,$23

	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,264($19)
	bne	$22,$0,$L118
	addiu	$19,$19,16

	b	$L99
	li	$22,1			# 0x1

$L118:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,16
	sll	$19,$19,8
	jal	saveg_read8
	or	$19,$19,$2

	or	$19,$19,$22
	sll	$2,$2,24
	or	$2,$2,$19
	sw	$2,284($16)
	sw	$0,0($16)
	sw	$0,224($16)
	sw	$0,236($16)
	lw	$2,16($sp)
$L119:
	addiu	$16,$16,288
	addiu	$21,$21,4
	addiu	$18,$18,288
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L100
	.set	at
	addiu	$17,$17,288

	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L101:
	b	$L98
	move	$2,$0

	.set	macro
	.set	reorder
	.end	P_UnArchivePlayers
	.size	P_UnArchivePlayers, .-P_UnArchivePlayers
	.align	2
	.globl	P_ArchiveWorld
	.set	nomips16
	.set	nomicromips
	.ent	P_ArchiveWorld
	.type	P_ArchiveWorld, @function
P_ArchiveWorld:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$18,28($sp)
	lui	$18,%hi(numsectors)
	lw	$2,%lo(numsectors)($18)
	lui	$3,%hi(sectors)
	sw	$16,20($sp)
	sw	$31,52($sp)
	lw	$16,%lo(sectors)($3)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	blez	$2,$L121
	sw	$17,24($sp)

	move	$19,$0
$L122:
	lh	$17,2($16)
	addiu	$16,$16,88
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$17,-82($16)
	addiu	$19,$19,1
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$17,-80($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$17,-78($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$17,-76($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$17,-74($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$17,-72($16)
	jal	saveg_write8
	andi	$4,$17,0x00ff

	sra	$4,$17,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lw	$2,%lo(numsectors)($18)
	slt	$2,$19,$2
	bne	$2,$0,$L122
	nop

$L121:
	lui	$21,%hi(numlines)
	lw	$2,%lo(numlines)($21)
	lui	$3,%hi(lines)
	blez	$2,$L120
	lw	$17,%lo(lines)($3)

	addiu	$17,$17,26
	move	$18,$0
	li	$19,-1			# 0xffffffffffffffff
	lui	$20,%hi(sides)
$L126:
	lh	$16,-10($17)
	addiu	$22,$17,-4
	jal	saveg_write8
	andi	$4,$16,0x00ff

	sra	$4,$16,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$16,-8($17)
	jal	saveg_write8
	andi	$4,$16,0x00ff

	sra	$4,$16,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$16,-6($17)
	jal	saveg_write8
	andi	$4,$16,0x00ff

	sra	$4,$16,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

$L125:
	lh	$3,0($22)
	addiu	$22,$22,2
	sll	$2,$3,2
	addu	$2,$2,$3
	.set	noat
	xor	$1,$3,$19
	beq	$1,$0,$L124
	.set	at
	sll	$2,$2,2

	lw	$16,%lo(sides)($20)
	addu	$16,$16,$2
	lh	$23,2($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$23,6($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$23,8($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$23,10($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lh	$16,12($16)
	jal	saveg_write8
	andi	$4,$16,0x00ff

	sra	$4,$16,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

$L124:
	.set	noat
	xor	$1,$17,$22
	bne	$1,$0,$L125
	.set	at
	nop

	lw	$2,%lo(numlines)($21)
	addiu	$18,$18,1
	slt	$2,$18,$2
	bne	$2,$0,$L126
	addiu	$17,$17,64

$L120:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	P_ArchiveWorld
	.size	P_ArchiveWorld, .-P_ArchiveWorld
	.align	2
	.globl	P_UnArchiveWorld
	.set	nomips16
	.set	nomicromips
	.ent	P_UnArchiveWorld
	.type	P_UnArchiveWorld, @function
P_UnArchiveWorld:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,24($sp)
	lui	$17,%hi(numsectors)
	lw	$2,%lo(numsectors)($17)
	lui	$3,%hi(sectors)
	sw	$16,20($sp)
	sw	$31,52($sp)
	lw	$16,%lo(sectors)($3)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	blez	$2,$L132
	sw	$18,28($sp)

	move	$18,$0
$L133:
	jal	saveg_read8
	addiu	$18,$18,1

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,8
	or	$2,$2,$19
	sll	$2,$2,16
	jal	saveg_read8
	sw	$2,0($16)

	jal	saveg_read8
	move	$19,$2

	sll	$2,$2,8
	or	$2,$2,$19
	sll	$2,$2,16
	jal	saveg_read8
	sw	$2,4($16)

	jal	saveg_read8
	move	$19,$2

	sll	$3,$2,8
	or	$2,$3,$19
	jal	saveg_read8
	sh	$2,8($16)

	jal	saveg_read8
	move	$19,$2

	sll	$3,$2,8
	or	$2,$3,$19
	jal	saveg_read8
	sh	$2,10($16)

	jal	saveg_read8
	move	$19,$2

	sll	$3,$2,8
	or	$2,$3,$19
	jal	saveg_read8
	sh	$2,12($16)

	jal	saveg_read8
	move	$19,$2

	sll	$3,$2,8
	or	$2,$3,$19
	jal	saveg_read8
	sh	$2,14($16)

	jal	saveg_read8
	move	$19,$2

	lw	$4,%lo(numsectors)($17)
	sll	$3,$2,8
	or	$2,$3,$19
	slt	$4,$18,$4
	sh	$2,16($16)
	sw	$0,76($16)
	sw	$0,24($16)
	bne	$4,$0,$L133
	addiu	$16,$16,88

$L132:
	lui	$21,%hi(numlines)
	lw	$2,%lo(numlines)($21)
	lui	$3,%hi(lines)
	blez	$2,$L131
	lw	$17,%lo(lines)($3)

	addiu	$17,$17,26
	move	$18,$0
	li	$19,-1			# 0xffffffffffffffff
	lui	$20,%hi(sides)
$L137:
	jal	saveg_read8
	addiu	$22,$17,-4

	jal	saveg_read8
	move	$16,$2

	sll	$3,$2,8
	or	$2,$3,$16
	jal	saveg_read8
	sh	$2,-10($17)

	jal	saveg_read8
	move	$16,$2

	sll	$3,$2,8
	or	$2,$3,$16
	jal	saveg_read8
	sh	$2,-8($17)

	jal	saveg_read8
	move	$16,$2

	sll	$3,$2,8
	or	$2,$3,$16
	sh	$2,-6($17)
$L136:
	lh	$3,0($22)
	addiu	$22,$22,2
	sll	$2,$3,2
	addu	$2,$2,$3
	.set	noat
	xor	$1,$3,$19
	beq	$1,$0,$L135
	.set	at
	sll	$2,$2,2

	lw	$16,%lo(sides)($20)
	jal	saveg_read8
	addu	$16,$16,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,8
	or	$2,$2,$23
	sll	$2,$2,16
	jal	saveg_read8
	sw	$2,0($16)

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,8
	or	$2,$2,$23
	sll	$2,$2,16
	jal	saveg_read8
	sw	$2,4($16)

	jal	saveg_read8
	move	$23,$2

	sll	$3,$2,8
	or	$2,$3,$23
	jal	saveg_read8
	sh	$2,8($16)

	jal	saveg_read8
	move	$23,$2

	sll	$3,$2,8
	or	$2,$3,$23
	jal	saveg_read8
	sh	$2,10($16)

	jal	saveg_read8
	move	$23,$2

	sll	$3,$2,8
	or	$2,$3,$23
	sh	$2,12($16)
$L135:
	.set	noat
	xor	$1,$22,$17
	bne	$1,$0,$L136
	.set	at
	nop

	lw	$2,%lo(numlines)($21)
	addiu	$18,$18,1
	slt	$2,$18,$2
	bne	$2,$0,$L137
	addiu	$17,$17,64

$L131:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	P_UnArchiveWorld
	.size	P_UnArchiveWorld, .-P_UnArchiveWorld
	.align	2
	.globl	P_ArchiveThinkers
	.set	nomips16
	.set	nomicromips
	.ent	P_ArchiveThinkers
	.type	P_ArchiveThinkers, @function
P_ArchiveThinkers:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,20($sp)
	lui	$17,%hi(thinkercap)
	addiu	$17,$17,%lo(thinkercap)
	sw	$16,16($sp)
	lw	$16,4($17)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L143
	.set	at
	sw	$18,24($sp)

	lui	$18,%hi(P_MobjThinker)
	addiu	$18,$18,%lo(P_MobjThinker)
$L149:
	lw	$2,8($16)
	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L156
	.set	at
	nop

	lw	$16,4($16)
$L157:
	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L149
	.set	at
	nop

$L143:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$4,$0
	j	saveg_write8
	addiu	$sp,$sp,40

$L156:
	jal	saveg_write8
	li	$4,1			# 0x1

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$20,$0,$2
	andi	$20,$20,0x3
	beq	$20,$0,$L145
	move	$19,$0

	addiu	$19,$19,1
$L159:
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$20,$19
	bne	$1,$0,$L159
	.set	at
	addiu	$19,$19,1

$L145:
	lw	$19,0($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,4($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,8($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,12($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,16($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,20($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,24($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,28($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,32($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,36($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,40($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,44($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,48($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,52($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,56($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,60($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,64($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,68($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,72($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,76($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,80($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,84($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,88($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,92($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,96($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,100($16)
	lui	$2,%hi(states)
	addiu	$2,$2,%lo(states)
	subu	$19,$19,$2
	li	$2,-1227161600			# 0xffffffffb6db0000
	addiu	$2,$2,28087
	sra	$19,$19,2
	multu	$19,$2
	mflo	$19
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,104($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,108($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,112($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,116($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,120($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,124($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,128($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$2,132($16)
	beq	$2,$0,$L147
	lui	$3,%hi(players)

	addiu	$3,$3,%lo(players)
	subu	$19,$2,$3
	li	$2,954400768			# 0x38e30000
	ori	$2,$2,0x8e39
	sra	$19,$19,5
	multu	$19,$2
	mflo	$19
	addiu	$19,$19,1
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lw	$19,136($16)
$L158:
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	lbu	$4,141($16)
	lbu	$2,140($16)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$19,$4,16
	sra	$19,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lbu	$4,143($16)
	lbu	$2,142($16)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$19,$4,16
	sra	$19,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lbu	$4,145($16)
	lbu	$2,144($16)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$19,$4,16
	sra	$19,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lbu	$4,147($16)
	lbu	$2,146($16)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$19,$4,16
	sra	$19,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lbu	$4,149($16)
	lbu	$2,148($16)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$19,$4,16
	sra	$19,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lw	$19,152($16)
	jal	saveg_write8
	andi	$4,$19,0x00ff

	sra	$4,$19,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$19,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$19,24

	b	$L157
	lw	$16,4($16)

$L147:
	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	move	$4,$0

	jal	saveg_write8
	move	$4,$0

	b	$L158
	lw	$19,136($16)

	.set	macro
	.set	reorder
	.end	P_ArchiveThinkers
	.size	P_ArchiveThinkers, .-P_ArchiveThinkers
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"Unknown tclass %i in savegame\000"
	.text
	.align	2
	.globl	P_UnArchiveThinkers
	.set	nomips16
	.set	nomicromips
	.ent	P_UnArchiveThinkers
	.type	P_UnArchiveThinkers, @function
P_UnArchiveThinkers:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,24($sp)
	lui	$17,%hi(thinkercap)
	addiu	$17,$17,%lo(thinkercap)
	sw	$16,20($sp)
	lw	$16,4($17)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L161
	.set	at
	sw	$18,28($sp)

	lui	$18,%hi(P_MobjThinker)
	b	$L164
	addiu	$18,$18,%lo(P_MobjThinker)

$L162:
	jal	Z_Free
	nop

	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L180
	.set	at
	lui	$19,%hi(states)

$L164:
	lw	$2,8($16)
	move	$4,$16
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L162
	.set	at
	lw	$16,4($16)

	jal	P_RemoveMobj
	nop

	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L164
	.set	at
	nop

$L161:
	lui	$19,%hi(states)
$L180:
	lui	$18,%hi(mobjinfo)
	jal	P_InitThinkers
	lui	$17,%hi(P_MobjThinker)

	lui	$21,%hi($LC6)
	lui	$20,%hi(save_stream)
	addiu	$19,$19,%lo(states)
	addiu	$18,$18,%lo(mobjinfo)
	addiu	$17,$17,%lo(P_MobjThinker)
$L165:
	jal	saveg_read8
	nop

	beq	$2,$0,$L160
	move	$5,$2

$L179:
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L167
	.set	at
	nop

	jal	ftell
	lw	$4,%lo(save_stream)($20)

	subu	$22,$0,$2
	andi	$22,$22,0x3
	beq	$22,$0,$L181
	move	$6,$0

	move	$16,$0
$L169:
	jal	saveg_read8
	addiu	$16,$16,1

	.set	noat
	xor	$1,$22,$16
	bne	$1,$0,$L169
	.set	at
	move	$6,$0

$L181:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,156			# 0x9c

	jal	saveg_read8
	move	$16,$2

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,0($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,4($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,8($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,12($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,16($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,20($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,24($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,28($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,32($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,36($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,40($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,44($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,48($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,52($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,56($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,60($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,64($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,68($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,72($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,76($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,80($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,84($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,88($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,92($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,96($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$3,$2,24
	or	$3,$3,$22
	sll	$2,$3,3
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$19,$2
	jal	saveg_read8
	sw	$2,100($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,104($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,108($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,112($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,116($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,120($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,124($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,128($16)

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	blez	$2,$L170
	addiu	$2,$2,-1

	sll	$3,$2,3
	addu	$3,$3,$2
	lui	$2,%hi(players)
	sll	$3,$3,5
	addiu	$2,$2,%lo(players)
	addu	$2,$2,$3
	sw	$2,132($16)
	sw	$16,0($2)
$L171:
	jal	saveg_read8
	nop

	jal	saveg_read8
	move	$23,$2

	jal	saveg_read8
	move	$22,$2

	sll	$2,$2,16
	sll	$22,$22,8
	jal	saveg_read8
	or	$22,$22,$2

	or	$22,$22,$23
	sll	$2,$2,24
	or	$2,$2,$22
	jal	saveg_read8
	sw	$2,136($16)

	jal	saveg_read8
	move	$22,$2

	sll	$3,$2,8
	or	$2,$3,$22
	andi	$3,$2,0xffff
	srl	$3,$3,8
	sb	$3,141($16)
	jal	saveg_read8
	sb	$2,140($16)

	jal	saveg_read8
	move	$22,$2

	sll	$3,$2,8
	or	$2,$3,$22
	andi	$3,$2,0xffff
	srl	$3,$3,8
	sb	$3,143($16)
	jal	saveg_read8
	sb	$2,142($16)

	jal	saveg_read8
	move	$22,$2

	sll	$3,$2,8
	or	$2,$3,$22
	andi	$3,$2,0xffff
	srl	$3,$3,8
	sb	$3,145($16)
	jal	saveg_read8
	sb	$2,144($16)

	jal	saveg_read8
	move	$22,$2

	sll	$3,$2,8
	or	$2,$3,$22
	andi	$3,$2,0xffff
	srl	$3,$3,8
	sb	$3,147($16)
	jal	saveg_read8
	sb	$2,146($16)

	jal	saveg_read8
	move	$22,$2

	sll	$3,$2,8
	or	$2,$3,$22
	andi	$3,$2,0xffff
	srl	$3,$3,8
	sb	$3,149($16)
	jal	saveg_read8
	sb	$2,148($16)

	jal	saveg_read8
	nop

	jal	saveg_read8
	nop

	jal	saveg_read8
	nop

	move	$4,$16
	sw	$0,120($16)
	jal	P_SetThingPosition
	sw	$0,152($16)

	lw	$3,88($16)
	lw	$4,52($16)
	sll	$2,$3,1
	addu	$2,$2,$3
	lw	$4,0($4)
	sll	$2,$2,3
	subu	$2,$2,$3
	lw	$5,0($4)
	lw	$3,4($4)
	sll	$2,$2,2
	addu	$2,$18,$2
	sw	$5,56($16)
	sw	$2,92($16)
	sw	$3,60($16)
	move	$4,$16
	jal	P_AddThinker
	sw	$17,8($16)

	jal	saveg_read8
	nop

	bne	$2,$0,$L179
	move	$5,$2

$L160:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L167:
	jal	I_Error
	addiu	$4,$21,%lo($LC6)

	b	$L165
	nop

$L170:
	b	$L171
	sw	$0,132($16)

	.set	macro
	.set	reorder
	.end	P_UnArchiveThinkers
	.size	P_UnArchiveThinkers, .-P_UnArchiveThinkers
	.align	2
	.globl	P_ArchiveSpecials
	.set	nomips16
	.set	nomicromips
	.ent	P_ArchiveSpecials
	.type	P_ArchiveSpecials, @function
P_ArchiveSpecials:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$17,20($sp)
	lui	$17,%hi(thinkercap)
	addiu	$17,$17,%lo(thinkercap)
	sw	$16,16($sp)
	lw	$16,4($17)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L183
	.set	at
	sw	$18,24($sp)

	lui	$18,%hi(T_MoveCeiling)
	lui	$19,%hi(T_VerticalDoor)
	lui	$20,%hi(T_PlatRaise)
	addiu	$18,$18,%lo(T_MoveCeiling)
	addiu	$19,$19,%lo(T_VerticalDoor)
	lui	$21,%hi(T_MoveFloor)
	addiu	$20,$20,%lo(T_PlatRaise)
	lui	$22,%hi(T_LightFlash)
$L210:
	lw	$2,8($16)
	beq	$2,$0,$L247
	move	$3,$0

	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L248
	.set	at
	nop

	.set	noat
	xor	$1,$2,$19
	beq	$1,$0,$L249
	.set	at
	addiu	$3,$21,%lo(T_MoveFloor)

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L250
	.set	at
	nop

	.set	noat
	xor	$1,$2,$20
	beq	$1,$0,$L251
	.set	at
	addiu	$3,$22,%lo(T_LightFlash)

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L252
	.set	at
	lui	$3,%hi(T_StrobeFlash)

	addiu	$3,$3,%lo(T_StrobeFlash)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L253
	.set	at
	lui	$3,%hi(T_Glow)

	addiu	$3,$3,%lo(T_Glow)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L254
	.set	at
	nop

$L187:
	lw	$16,4($16)
$L256:
	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L210
	.set	at
	nop

$L183:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$4,7			# 0x7
	j	saveg_write8
	addiu	$sp,$sp,56

$L248:
	jal	saveg_write8
	move	$4,$0

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L191
	nop

	move	$23,$0
$L192:
	addiu	$23,$23,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L192
	.set	at
	nop

$L191:
	jal	saveg_write_ceiling_t
	move	$4,$16

	b	$L256
	lw	$16,4($16)

$L249:
	jal	saveg_write8
	li	$4,1			# 0x1

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L194
	move	$23,$0

	addiu	$23,$23,1
$L258:
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L258
	.set	at
	addiu	$23,$23,1

$L194:
	lw	$23,0($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,4($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,8($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,12($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lui	$2,%hi(sectors)
	lw	$2,%lo(sectors)($2)
	lw	$23,16($16)
	subu	$23,$23,$2
	li	$2,-1171390464			# 0xffffffffba2e0000
	ori	$2,$2,0x8ba3
	sra	$23,$23,3
	multu	$23,$2
	mflo	$23
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,20($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,24($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,28($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,32($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,36($16)
$L246:
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	b	$L256
	lw	$16,4($16)

$L247:
	lui	$2,%hi(activeceilings)
	addiu	$2,$2,%lo(activeceilings)
	b	$L186
	li	$5,30			# 0x1e

$L255:
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L187
	.set	at
	addiu	$2,$2,4

$L186:
	lw	$4,0($2)
	.set	noat
	xor	$1,$4,$16
	bne	$1,$0,$L255
	.set	at
	addiu	$3,$3,1

	jal	saveg_write8
	move	$4,$0

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L191
	nop

	move	$fp,$0
$L189:
	addiu	$fp,$fp,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$23,$fp
	bne	$1,$0,$L189
	.set	at
	nop

	jal	saveg_write_ceiling_t
	move	$4,$16

	b	$L256
	lw	$16,4($16)

$L250:
	jal	saveg_write8
	li	$4,2			# 0x2

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L197
	nop

	move	$23,$0
$L198:
	addiu	$23,$23,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L198
	.set	at
	nop

$L197:
	lw	$23,0($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,4($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,8($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,12($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,16($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lui	$2,%hi(sectors)
	lw	$2,%lo(sectors)($2)
	lw	$23,20($16)
	subu	$23,$23,$2
	li	$2,-1171390464			# 0xffffffffba2e0000
	ori	$2,$2,0x8ba3
	sra	$23,$23,3
	multu	$23,$2
	mflo	$23
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,24($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,28($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lh	$23,32($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	lw	$23,36($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	b	$L246
	lw	$23,40($16)

$L251:
	jal	saveg_write8
	li	$4,3			# 0x3

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L200
	nop

	move	$23,$0
$L201:
	addiu	$23,$23,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L201
	.set	at
	nop

$L200:
	lw	$23,0($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,4($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,8($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lui	$2,%hi(sectors)
	lw	$2,%lo(sectors)($2)
	lw	$23,12($16)
	subu	$23,$23,$2
	li	$2,-1171390464			# 0xffffffffba2e0000
	ori	$2,$2,0x8ba3
	sra	$23,$23,3
	multu	$23,$2
	mflo	$23
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,16($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,20($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,24($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,28($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,32($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,36($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,40($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,44($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,48($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	b	$L246
	lw	$23,52($16)

$L252:
	jal	saveg_write8
	li	$4,4			# 0x4

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L206
	nop

	move	$23,$0
$L204:
	addiu	$23,$23,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L204
	.set	at
	nop

$L206:
	lw	$23,0($16)
$L257:
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,4($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,8($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lui	$2,%hi(sectors)
	lw	$2,%lo(sectors)($2)
	lw	$23,12($16)
	subu	$23,$23,$2
	li	$2,-1171390464			# 0xffffffffba2e0000
	ori	$2,$2,0x8ba3
	sra	$23,$23,3
	multu	$23,$2
	mflo	$23
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,16($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,20($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,24($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,28($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	b	$L246
	lw	$23,32($16)

$L253:
	jal	saveg_write8
	li	$4,5			# 0x5

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L206
	nop

	move	$23,$0
$L207:
	addiu	$23,$23,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L207
	.set	at
	nop

	b	$L257
	lw	$23,0($16)

$L254:
	jal	saveg_write8
	li	$4,6			# 0x6

	lui	$2,%hi(save_stream)
	jal	ftell
	lw	$4,%lo(save_stream)($2)

	subu	$fp,$0,$2
	andi	$fp,$fp,0x3
	beq	$fp,$0,$L208
	nop

	move	$23,$0
$L209:
	addiu	$23,$23,1
	jal	saveg_write8
	move	$4,$0

	.set	noat
	xor	$1,$fp,$23
	bne	$1,$0,$L209
	.set	at
	nop

$L208:
	lw	$23,0($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,4($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,8($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lui	$2,%hi(sectors)
	lw	$2,%lo(sectors)($2)
	lw	$23,12($16)
	subu	$23,$23,$2
	li	$2,-1171390464			# 0xffffffffba2e0000
	ori	$2,$2,0x8ba3
	sra	$23,$23,3
	multu	$23,$2
	mflo	$23
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,16($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	lw	$23,20($16)
	jal	saveg_write8
	andi	$4,$23,0x00ff

	sra	$4,$23,8
	jal	saveg_write8
	andi	$4,$4,0x00ff

	sra	$4,$23,16
	jal	saveg_write8
	andi	$4,$4,0x00ff

	jal	saveg_write8
	srl	$4,$23,24

	b	$L246
	lw	$23,24($16)

	.set	macro
	.set	reorder
	.end	P_ArchiveSpecials
	.size	P_ArchiveSpecials, .-P_ArchiveSpecials
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"P_UnarchiveSpecials:Unknown tclass %i in savegame\000"
	.text
	.align	2
	.globl	P_UnArchiveSpecials
	.set	nomips16
	.set	nomicromips
	.ent	P_UnArchiveSpecials
	.type	P_UnArchiveSpecials, @function
P_UnArchiveSpecials:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	lui	$20,%hi(T_Glow)
	lui	$16,%hi($L263)
	lui	$19,%hi(T_StrobeFlash)
	lui	$18,%hi(T_LightFlash)
	sw	$21,36($sp)
	sw	$17,20($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	addiu	$16,$16,%lo($L263)
	lui	$21,%hi($LC7)
	lui	$17,%hi(save_stream)
	addiu	$20,$20,%lo(T_Glow)
	addiu	$19,$19,%lo(T_StrobeFlash)
	addiu	$18,$18,%lo(T_LightFlash)
$L260:
	jal	saveg_read8
	nop

	sltu	$3,$2,8
	beq	$3,$0,$L261
	move	$5,$2

	sll	$2,$2,2
	addu	$2,$16,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L263:
	.word	$L270
	.word	$L269
	.word	$L268
	.word	$L267
	.word	$L266
	.word	$L265
	.word	$L264
	.word	$L259
	.text
$L264:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L323
	move	$6,$0

	move	$22,$0
$L287:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L287
	.set	at
	move	$6,$0

$L323:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,28			# 0x1c

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,24($22)
	sw	$20,8($22)
	jal	P_AddThinker
	move	$4,$22

	b	$L260
	nop

$L265:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L324
	move	$6,$0

	move	$22,$0
$L285:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L285
	.set	at
	move	$6,$0

$L324:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,36			# 0x24

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,24($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,28($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,32($22)
	sw	$19,8($22)
	jal	P_AddThinker
	move	$4,$22

	b	$L260
	nop

$L269:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L325
	move	$6,$0

	move	$22,$0
$L276:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L276
	.set	at
	move	$6,$0

$L325:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,40			# 0x28

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,24($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,28($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,32($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,36($22)
	lw	$3,16($22)
	lui	$2,%hi(T_VerticalDoor)
	addiu	$2,$2,%lo(T_VerticalDoor)
	sw	$22,76($3)
	move	$4,$22
	jal	P_AddThinker
	sw	$2,8($22)

	b	$L260
	nop

$L267:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L326
	move	$6,$0

	move	$22,$0
$L280:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L280
	.set	at
	move	$6,$0

$L326:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,56			# 0x38

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,24($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,28($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,32($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,36($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,40($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,44($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,48($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	lw	$4,12($22)
	lw	$3,8($22)
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,52($22)
	beq	$3,$0,$L281
	sw	$22,76($4)

	lui	$2,%hi(T_PlatRaise)
	addiu	$2,$2,%lo(T_PlatRaise)
	sw	$2,8($22)
$L281:
	jal	P_AddThinker
	move	$4,$22

	jal	P_AddActivePlat
	move	$4,$22

	b	$L260
	nop

$L259:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L266:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L327
	move	$6,$0

	move	$22,$0
$L283:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L283
	.set	at
	move	$6,$0

$L327:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,36			# 0x24

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,24($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,28($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,32($22)
	sw	$18,8($22)
	jal	P_AddThinker
	move	$4,$22

	b	$L260
	nop

$L268:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L328
	move	$6,$0

	move	$22,$0
$L278:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L278
	.set	at
	move	$6,$0

$L328:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,44			# 0x2c

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,24($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,28($22)

	jal	saveg_read8
	move	$23,$2

	sll	$3,$2,8
	or	$2,$3,$23
	jal	saveg_read8
	sh	$2,32($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,36($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,40($22)
	lw	$3,20($22)
	lui	$2,%hi(T_MoveFloor)
	addiu	$2,$2,%lo(T_MoveFloor)
	sw	$22,76($3)
	move	$4,$22
	jal	P_AddThinker
	sw	$2,8($22)

	b	$L260
	nop

$L270:
	jal	ftell
	lw	$4,%lo(save_stream)($17)

	subu	$23,$0,$2
	andi	$23,$23,0x3
	beq	$23,$0,$L329
	move	$6,$0

	move	$22,$0
$L272:
	jal	saveg_read8
	addiu	$22,$22,1

	.set	noat
	xor	$1,$23,$22
	bne	$1,$0,$L272
	.set	at
	move	$6,$0

$L329:
	li	$5,5			# 0x5
	jal	Z_Malloc
	li	$4,48			# 0x30

	jal	saveg_read8
	move	$22,$2

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,0($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,4($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,8($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,12($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$3,$2,24
	or	$3,$3,$23
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lui	$4,%hi(sectors)
	lw	$4,%lo(sectors)($4)
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$4,$2
	jal	saveg_read8
	sw	$2,16($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,20($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,24($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,28($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,32($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,36($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	sll	$2,$2,24
	or	$2,$2,$23
	jal	saveg_read8
	sw	$2,40($22)

	jal	saveg_read8
	move	$fp,$2

	jal	saveg_read8
	move	$23,$2

	sll	$2,$2,16
	sll	$23,$23,8
	jal	saveg_read8
	or	$23,$23,$2

	or	$23,$23,$fp
	lw	$4,16($22)
	lw	$3,8($22)
	sll	$2,$2,24
	or	$2,$2,$23
	sw	$2,44($22)
	beq	$3,$0,$L273
	sw	$22,76($4)

	lui	$2,%hi(T_MoveCeiling)
	addiu	$2,$2,%lo(T_MoveCeiling)
	sw	$2,8($22)
$L273:
	jal	P_AddThinker
	move	$4,$22

	jal	P_AddActiveCeiling
	move	$4,$22

	b	$L260
	nop

$L261:
	jal	I_Error
	addiu	$4,$21,%lo($LC7)

	b	$L260
	nop

	.set	macro
	.set	reorder
	.end	P_UnArchiveSpecials
	.size	P_UnArchiveSpecials, .-P_UnArchiveSpecials
	.local	filename_size.0
	.comm	filename_size.0,4,4
	.local	filename.1
	.comm	filename.1,4,4
	.local	filename.2
	.comm	filename.2,4,4
	.globl	specials_e
	.section	.bss,"aw",@nobits
	.align	2
	.type	specials_e, @object
	.size	specials_e, 4
specials_e:
	.space	4
	.globl	savegame_error
	.align	2
	.type	savegame_error, @object
	.size	savegame_error, 4
savegame_error:
	.space	4
	.globl	savegamelength
	.align	2
	.type	savegamelength, @object
	.size	savegamelength, 4
savegamelength:
	.space	4
	.globl	save_stream
	.align	2
	.type	save_stream, @object
	.size	save_stream, 4
save_stream:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
