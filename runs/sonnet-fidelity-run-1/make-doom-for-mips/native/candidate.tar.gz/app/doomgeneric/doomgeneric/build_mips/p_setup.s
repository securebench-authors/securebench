	.file	1 "p_setup.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_LoadVertexes
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadVertexes
	.type	P_LoadVertexes, @function
P_LoadVertexes:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	jal	W_LumpLength
	move	$16,$4

	srl	$2,$2,2
	lui	$18,%hi(numvertexes)
	move	$6,$0
	li	$5,5			# 0x5
	sll	$4,$2,3
	lui	$17,%hi(vertexes)
	jal	Z_Malloc
	sw	$2,%lo(numvertexes)($18)

	move	$4,$16
	li	$5,1			# 0x1
	jal	W_CacheLumpNum
	sw	$2,%lo(vertexes)($17)

	lw	$7,%lo(numvertexes)($18)
	blez	$7,$L2
	lw	$4,%lo(vertexes)($17)

	move	$5,$0
$L3:
	lbu	$3,1($2)
	lbu	$6,0($2)
	sll	$3,$3,8
	or	$3,$3,$6
	sll	$3,$3,16
	sw	$3,0($4)
	lbu	$3,3($2)
	lbu	$6,2($2)
	sll	$3,$3,8
	or	$3,$3,$6
	sll	$3,$3,16
	addiu	$5,$5,1
	sw	$3,4($4)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L3
	.set	at
	addiu	$4,$4,8

$L2:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_LoadVertexes
	.size	P_LoadVertexes, .-P_LoadVertexes
	.align	2
	.globl	GetSectorAtNullAddress
	.set	nomips16
	.set	nomicromips
	.ent	GetSectorAtNullAddress
	.type	GetSectorAtNullAddress, @function
GetSectorAtNullAddress:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	lui	$17,%hi(null_sector_is_initialized.1)
	lw	$2,%lo(null_sector_is_initialized.1)($17)
	sw	$16,20($sp)
	sw	$31,28($sp)
	beq	$2,$0,$L10
	lui	$16,%hi(null_sector.0)

	lw	$31,28($sp)
	lw	$17,24($sp)
	addiu	$2,$16,%lo(null_sector.0)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L10:
	addiu	$4,$16,%lo(null_sector.0)
	li	$6,88			# 0x58
	jal	memset
	move	$5,$0

	addiu	$5,$16,%lo(null_sector.0)
	li	$6,4			# 0x4
	jal	I_GetMemoryValue
	move	$4,$0

	lui	$5,%hi(null_sector.0+4)
	li	$6,4			# 0x4
	addiu	$5,$5,%lo(null_sector.0+4)
	jal	I_GetMemoryValue
	li	$4,4			# 0x4

	lw	$31,28($sp)
	li	$2,1			# 0x1
	sw	$2,%lo(null_sector_is_initialized.1)($17)
	lw	$17,24($sp)
	addiu	$2,$16,%lo(null_sector.0)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	GetSectorAtNullAddress
	.size	GetSectorAtNullAddress, .-GetSectorAtNullAddress
	.align	2
	.globl	P_LoadSegs
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadSegs
	.type	P_LoadSegs, @function
P_LoadSegs:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$31,68($sp)
	sw	$23,60($sp)
	sw	$21,52($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	sw	$fp,64($sp)
	move	$16,$4
	sw	$22,56($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	jal	W_LumpLength
	sw	$18,40($sp)

	li	$3,-1431699456			# 0xffffffffaaaa0000
	ori	$3,$3,0xaaab
	multu	$2,$3
	lui	$23,%hi(numsegs)
	mfhi	$2
	move	$6,$0
	srl	$2,$2,3
	li	$5,5			# 0x5
	sll	$4,$2,5
	jal	Z_Malloc
	sw	$2,%lo(numsegs)($23)

	lw	$6,%lo(numsegs)($23)
	move	$4,$2
	lui	$17,%hi(segs)
	sll	$6,$6,5
	move	$5,$0
	jal	memset
	sw	$2,%lo(segs)($17)

	li	$5,1			# 0x1
	jal	W_CacheLumpNum
	move	$4,$16

	lw	$3,%lo(numsegs)($23)
	blez	$3,$L13
	lw	$21,%lo(segs)($17)

	lui	$18,%hi(null_sector.0)
	lui	$17,%hi(null_sector.0+4)
	move	$20,$2
	addiu	$2,$18,%lo(null_sector.0)
	sw	$2,16($sp)
	addiu	$2,$17,%lo(null_sector.0+4)
	move	$22,$0
	lui	$8,%hi(vertexes)
	lui	$7,%hi(lines)
	lui	$fp,%hi(sides)
	lui	$19,%hi(null_sector_is_initialized.1)
	sw	$2,28($sp)
	b	$L18
	lui	$17,%hi(numsides)

$L23:
	lh	$2,6($4)
	bltz	$2,$L15
	sll	$3,$2,2

	lw	$4,%lo(numsides)($17)
	addu	$3,$3,$2
	sll	$3,$3,2
	slt	$2,$2,$4
	beq	$2,$0,$L15
	addu	$5,$5,$3

	lw	$3,16($5)
$L14:
	lw	$2,%lo(numsegs)($23)
	addiu	$22,$22,1
	slt	$2,$22,$2
	sw	$3,28($21)
	addiu	$20,$20,12
	beq	$2,$0,$L13
	addiu	$21,$21,32

$L18:
	lbu	$2,1($20)
	lbu	$3,0($20)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	lw	$3,%lo(vertexes)($8)
	sra	$2,$2,16
	sll	$2,$2,3
	addu	$2,$3,$2
	sw	$2,0($21)
	lbu	$2,3($20)
	lbu	$4,2($20)
	sll	$2,$2,8
	or	$2,$2,$4
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$2,$2,3
	addu	$3,$3,$2
	sw	$3,4($21)
	lbu	$2,5($20)
	lbu	$3,4($20)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sw	$2,12($21)
	lbu	$2,11($20)
	lbu	$3,10($20)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sw	$2,8($21)
	lbu	$2,7($20)
	lbu	$3,6($20)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	lw	$4,%lo(lines)($7)
	sra	$2,$2,16
	sll	$2,$2,6
	addu	$4,$4,$2
	sw	$4,20($21)
	lbu	$3,9($20)
	lbu	$2,8($20)
	sll	$3,$3,8
	or	$3,$3,$2
	sll	$3,$3,16
	sra	$3,$3,16
	addiu	$2,$3,8
	sll	$2,$2,1
	addu	$2,$4,$2
	lh	$6,6($2)
	lw	$5,%lo(sides)($fp)
	sll	$2,$6,2
	addu	$2,$2,$6
	xori	$3,$3,0x1
	sll	$2,$2,2
	lhu	$6,16($4)
	addu	$2,$5,$2
	addiu	$3,$3,8
	lw	$12,16($2)
	sll	$3,$3,1
	addu	$4,$4,$3
	andi	$3,$6,0x4
	sw	$12,24($21)
	bne	$3,$0,$L23
	sw	$2,16($21)

	lw	$2,%lo(numsegs)($23)
	addiu	$22,$22,1
	move	$3,$0
	slt	$2,$22,$2
	sw	$3,28($21)
	addiu	$20,$20,12
	bne	$2,$0,$L18
	addiu	$21,$21,32

$L13:
	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	move	$4,$16
	lw	$16,32($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,72

$L15:
	lw	$2,%lo(null_sector_is_initialized.1)($19)
	beq	$2,$0,$L24
	lw	$4,16($sp)

	b	$L14
	addiu	$3,$18,%lo(null_sector.0)

$L24:
	li	$6,88			# 0x58
	move	$5,$0
	sw	$8,24($sp)
	jal	memset
	sw	$7,20($sp)

	lw	$5,16($sp)
	li	$6,4			# 0x4
	jal	I_GetMemoryValue
	move	$4,$0

	lw	$5,28($sp)
	li	$6,4			# 0x4
	jal	I_GetMemoryValue
	li	$4,4			# 0x4

	li	$2,1			# 0x1
	lw	$8,24($sp)
	lw	$7,20($sp)
	sw	$2,%lo(null_sector_is_initialized.1)($19)
	b	$L14
	addiu	$3,$18,%lo(null_sector.0)

	.set	macro
	.set	reorder
	.end	P_LoadSegs
	.size	P_LoadSegs, .-P_LoadSegs
	.align	2
	.globl	P_LoadSubsectors
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadSubsectors
	.type	P_LoadSubsectors, @function
P_LoadSubsectors:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	jal	W_LumpLength
	move	$16,$4

	srl	$2,$2,2
	lui	$19,%hi(numsubsectors)
	move	$6,$0
	li	$5,5			# 0x5
	sll	$4,$2,3
	lui	$18,%hi(subsectors)
	jal	Z_Malloc
	sw	$2,%lo(numsubsectors)($19)

	move	$4,$16
	li	$5,1			# 0x1
	jal	W_CacheLumpNum
	sw	$2,%lo(subsectors)($18)

	lw	$6,%lo(numsubsectors)($19)
	lw	$4,%lo(subsectors)($18)
	sll	$6,$6,3
	move	$5,$0
	jal	memset
	move	$17,$2

	lw	$8,%lo(numsubsectors)($19)
	blez	$8,$L26
	lw	$2,%lo(subsectors)($18)

	move	$4,$0
$L27:
	lbu	$5,3($17)
	lbu	$3,1($17)
	lbu	$7,2($17)
	lbu	$6,0($17)
	sll	$5,$5,8
	sll	$3,$3,8
	or	$5,$5,$7
	sll	$5,$5,16
	or	$3,$3,$6
	or	$3,$3,$5
	addiu	$4,$4,1
	sw	$3,4($2)
	addiu	$17,$17,4
	.set	noat
	xor	$1,$4,$8
	bne	$1,$0,$L27
	.set	at
	addiu	$2,$2,8

$L26:
	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	move	$4,$16
	lw	$16,20($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_LoadSubsectors
	.size	P_LoadSubsectors, .-P_LoadSubsectors
	.align	2
	.globl	P_LoadSectors
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadSectors
	.type	P_LoadSectors, @function
P_LoadSectors:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	move	$19,$4
	sw	$17,20($sp)
	sw	$20,32($sp)
	jal	W_LumpLength
	sw	$16,16($sp)

	li	$3,1321467904			# 0x4ec40000
	ori	$3,$3,0xec4f
	multu	$2,$3
	lui	$18,%hi(numsectors)
	mfhi	$2
	move	$6,$0
	srl	$2,$2,3
	sll	$4,$2,1
	addu	$4,$4,$2
	sll	$4,$4,2
	subu	$4,$4,$2
	li	$5,5			# 0x5
	sll	$4,$4,3
	jal	Z_Malloc
	sw	$2,%lo(numsectors)($18)

	lw	$3,%lo(numsectors)($18)
	move	$4,$2
	sll	$6,$3,1
	addu	$6,$6,$3
	sll	$6,$6,2
	subu	$6,$6,$3
	lui	$17,%hi(sectors)
	sll	$6,$6,3
	move	$5,$0
	jal	memset
	sw	$2,%lo(sectors)($17)

	li	$5,1			# 0x1
	jal	W_CacheLumpNum
	move	$4,$19

	lw	$3,%lo(numsectors)($18)
	blez	$3,$L31
	lw	$17,%lo(sectors)($17)

	move	$16,$2
	move	$20,$0
$L32:
	lbu	$2,1($16)
	lbu	$3,0($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sw	$2,0($17)
	lbu	$2,3($16)
	lbu	$3,2($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	addiu	$4,$16,4
	jal	R_FlatNumForName
	sw	$2,4($17)

	sh	$2,8($17)
	jal	R_FlatNumForName
	addiu	$4,$16,12

	sh	$2,10($17)
	lbu	$2,21($16)
	lbu	$3,20($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sh	$2,12($17)
	lbu	$2,23($16)
	lbu	$3,22($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sh	$2,14($17)
	lbu	$2,25($16)
	lbu	$4,24($16)
	lw	$3,%lo(numsectors)($18)
	sll	$2,$2,8
	addiu	$20,$20,1
	or	$2,$2,$4
	slt	$3,$20,$3
	sh	$2,16($17)
	sw	$0,72($17)
	addiu	$16,$16,26
	bne	$3,$0,$L32
	addiu	$17,$17,88

$L31:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$4,$19
	lw	$19,28($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_LoadSectors
	.size	P_LoadSectors, .-P_LoadSectors
	.align	2
	.globl	P_LoadNodes
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadNodes
	.type	P_LoadNodes, @function
P_LoadNodes:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	jal	W_LumpLength
	move	$16,$4

	li	$3,613548032			# 0x24920000
	addiu	$3,$3,18725
	srl	$2,$2,2
	multu	$2,$3
	lui	$18,%hi(numnodes)
	mfhi	$2
	move	$6,$0
	sll	$4,$2,1
	addu	$4,$4,$2
	sll	$4,$4,2
	addu	$4,$4,$2
	li	$5,5			# 0x5
	sll	$4,$4,2
	lui	$17,%hi(nodes)
	jal	Z_Malloc
	sw	$2,%lo(numnodes)($18)

	li	$5,1			# 0x1
	move	$4,$16
	jal	W_CacheLumpNum
	sw	$2,%lo(nodes)($17)

	lw	$10,%lo(numnodes)($18)
	blez	$10,$L36
	lw	$7,%lo(nodes)($17)

	addiu	$7,$7,32
	move	$9,$0
	li	$8,4			# 0x4
$L39:
	lbu	$3,1($2)
	lbu	$4,0($2)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	sw	$3,-32($7)
	lbu	$3,3($2)
	lbu	$4,2($2)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	sw	$3,-28($7)
	lbu	$3,5($2)
	lbu	$4,4($2)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	sw	$3,-24($7)
	lbu	$3,7($2)
	lbu	$4,6($2)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	sw	$3,-20($7)
	lbu	$3,25($2)
	lbu	$4,24($2)
	sll	$3,$3,8
	or	$3,$3,$4
	sh	$3,16($7)
	addiu	$6,$7,-16
	move	$5,$0
$L37:
	addiu	$4,$5,4
	sll	$4,$4,1
	addu	$4,$2,$4
	lbu	$3,1($4)
	lbu	$4,0($4)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	addiu	$5,$5,1
	sw	$3,0($6)
	.set	noat
	xor	$1,$5,$8
	bne	$1,$0,$L37
	.set	at
	addiu	$6,$6,4

	lbu	$3,27($2)
	lbu	$4,26($2)
	sll	$3,$3,8
	or	$3,$3,$4
	sh	$3,18($7)
	move	$6,$7
	move	$5,$0
$L38:
	addiu	$4,$5,8
	sll	$4,$4,1
	addu	$4,$2,$4
	lbu	$3,1($4)
	lbu	$4,0($4)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	addiu	$5,$5,1
	sw	$3,0($6)
	.set	noat
	xor	$1,$5,$8
	bne	$1,$0,$L38
	.set	at
	addiu	$6,$6,4

	addiu	$9,$9,1
	addiu	$2,$2,28
	.set	noat
	xor	$1,$9,$10
	bne	$1,$0,$L39
	.set	at
	addiu	$7,$7,52

$L36:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_LoadNodes
	.size	P_LoadNodes, .-P_LoadNodes
	.align	2
	.globl	P_LoadThings
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadThings
	.type	P_LoadThings, @function
P_LoadThings:
	.frame	$sp,64,$31		# vars= 16, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	li	$5,1			# 0x1
	sw	$21,56($sp)
	move	$21,$4
	sw	$31,60($sp)
	sw	$16,36($sp)
	sw	$20,52($sp)
	sw	$19,48($sp)
	sw	$18,44($sp)
	jal	W_CacheLumpNum
	sw	$17,40($sp)

	move	$4,$21
	jal	W_LumpLength
	move	$16,$2

	li	$3,-859045888			# 0xffffffffcccc0000
	ori	$3,$3,0xcccd
	multu	$2,$3
	sltu	$2,$2,10
	bne	$2,$0,$L46
	mfhi	$3

	li	$18,51380224			# 0x3100000
	srl	$3,$3,3
	sll	$17,$3,2
	addu	$17,$17,$3
	sll	$17,$17,1
	addu	$17,$16,$17
	lui	$20,%hi(gamemode)
	li	$19,2			# 0x2
	b	$L48
	addiu	$18,$18,191

$L47:
	lbu	$5,3($16)
	lbu	$3,1($16)
	lbu	$7,2($16)
	lbu	$6,0($16)
	sll	$5,$5,8
	sll	$3,$3,8
	or	$5,$5,$7
	sll	$5,$5,16
	or	$3,$3,$6
	or	$3,$3,$5
	sw	$3,16($sp)
	lbu	$3,5($16)
	lbu	$5,4($16)
	sll	$3,$3,8
	or	$3,$3,$5
	sh	$3,20($sp)
	sh	$2,22($sp)
	lbu	$2,9($16)
	lbu	$3,8($16)
	sll	$2,$2,8
	or	$2,$2,$3
	addiu	$16,$16,10
	jal	P_SpawnMapThing
	sh	$2,24($sp)

	.set	noat
	xor	$1,$17,$16
	beq	$1,$0,$L46
	.set	at
	nop

$L48:
	lbu	$2,7($16)
	lbu	$3,6($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addiu	$3,$2,-64
	andi	$3,$3,0xffff
	lw	$6,%lo(gamemode)($20)
	srl	$5,$18,$3
	addiu	$4,$sp,16
	sltu	$3,$3,26
	.set	noat
	xor	$1,$6,$19
	beq	$1,$0,$L47
	.set	at
	andi	$5,$5,0x1

	beq	$3,$0,$L47
	nop

	beq	$5,$0,$L47
	nop

$L46:
	jal	W_ReleaseLumpNum
	move	$4,$21

	lw	$31,60($sp)
	lw	$21,56($sp)
	lw	$20,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	P_LoadThings
	.size	P_LoadThings, .-P_LoadThings
	.align	2
	.globl	P_LoadLineDefs
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadLineDefs
	.type	P_LoadLineDefs, @function
P_LoadLineDefs:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$31,60($sp)
	sw	$22,48($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	move	$17,$4
	sw	$4,16($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	jal	W_LumpLength
	sw	$18,32($sp)

	li	$3,-1840709632			# 0xffffffff92490000
	addiu	$3,$3,9363
	srl	$2,$2,1
	multu	$2,$3
	lui	$22,%hi(numlines)
	mfhi	$2
	move	$6,$0
	srl	$2,$2,2
	li	$5,5			# 0x5
	sll	$4,$2,6
	jal	Z_Malloc
	sw	$2,%lo(numlines)($22)

	lw	$6,%lo(numlines)($22)
	move	$4,$2
	lui	$16,%hi(lines)
	sll	$6,$6,6
	move	$5,$0
	jal	memset
	sw	$2,%lo(lines)($16)

	li	$5,1			# 0x1
	jal	W_CacheLumpNum
	move	$4,$17

	lw	$3,%lo(numlines)($22)
	blez	$3,$L62
	lw	$16,%lo(lines)($16)

	move	$17,$2
	move	$20,$0
	lui	$fp,%hi(vertexes)
	li	$21,-1			# 0xffffffffffffffff
	lui	$23,%hi(sides)
$L53:
	lbu	$3,7($17)
	lbu	$5,6($17)
	lbu	$2,5($17)
	lbu	$4,4($17)
	sll	$3,$3,8
	or	$3,$3,$5
	sll	$2,$2,8
	sll	$3,$3,16
	or	$2,$2,$4
	or	$2,$2,$3
	sw	$2,16($16)
	lbu	$2,9($17)
	lbu	$3,8($17)
	sll	$2,$2,8
	or	$2,$2,$3
	sh	$2,20($16)
	lbu	$18,1($17)
	lbu	$2,0($17)
	sll	$18,$18,8
	or	$18,$18,$2
	sll	$18,$18,16
	lw	$3,%lo(vertexes)($fp)
	sra	$18,$18,16
	sll	$18,$18,3
	addu	$18,$3,$18
	sw	$18,0($16)
	lbu	$2,3($17)
	lbu	$4,2($17)
	sll	$2,$2,8
	or	$2,$2,$4
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$2,$2,3
	addu	$19,$3,$2
	lw	$7,0($19)
	lw	$8,0($18)
	sw	$19,4($16)
	subu	$5,$7,$8
	sw	$5,8($16)
	lw	$2,4($19)
	lw	$6,4($18)
	subu	$4,$2,$6
	bne	$5,$0,$L54
	sw	$4,12($16)

	li	$3,1			# 0x1
	sw	$3,44($16)
$L55:
	slt	$3,$8,$7
	beq	$3,$0,$L71
	slt	$3,$6,$2

	move	$3,$7
	move	$7,$8
	move	$8,$3
	slt	$3,$6,$2
$L71:
	sw	$8,40($16)
	beq	$3,$0,$L59
	sw	$7,36($16)

	move	$3,$2
	move	$2,$6
	move	$6,$3
$L59:
	sw	$6,28($16)
	sw	$2,32($16)
	lbu	$3,11($17)
	lbu	$2,10($17)
	sll	$3,$3,8
	or	$3,$3,$2
	sll	$3,$3,16
	sra	$3,$3,16
	sh	$3,22($16)
	lbu	$2,13($17)
	lbu	$4,12($17)
	sll	$2,$2,8
	or	$2,$2,$4
	sll	$2,$2,16
	sra	$2,$2,16
	.set	noat
	xor	$1,$3,$21
	beq	$1,$0,$L65
	.set	at
	sh	$2,24($16)

	sll	$4,$3,2
	lw	$5,%lo(sides)($23)
	addu	$3,$4,$3
	sll	$3,$3,2
	addu	$3,$5,$3
	lw	$3,16($3)
$L60:
	.set	noat
	xor	$1,$2,$21
	beq	$1,$0,$L66
	.set	at
	sw	$3,48($16)

	sll	$3,$2,2
	addu	$2,$3,$2
	lw	$4,%lo(sides)($23)
	sll	$2,$2,2
	addu	$2,$4,$2
	lw	$3,16($2)
$L61:
	lw	$2,%lo(numlines)($22)
	addiu	$20,$20,1
	slt	$2,$20,$2
	sw	$3,52($16)
	addiu	$17,$17,14
	bne	$2,$0,$L53
	addiu	$16,$16,64

$L62:
	lw	$4,16($sp)
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,64

$L54:
	bne	$4,$0,$L70
	move	$3,$0

	b	$L55
	sw	$3,44($16)

$L66:
	b	$L61
	move	$3,$0

$L65:
	b	$L60
	move	$3,$0

$L70:
	jal	FixedDiv
	nop

	blez	$2,$L57
	nop

	li	$2,2			# 0x2
$L69:
	sw	$2,44($16)
	lw	$8,0($18)
	lw	$7,0($19)
	lw	$6,4($18)
	b	$L55
	lw	$2,4($19)

$L57:
	b	$L69
	li	$2,3			# 0x3

	.set	macro
	.set	reorder
	.end	P_LoadLineDefs
	.size	P_LoadLineDefs, .-P_LoadLineDefs
	.align	2
	.globl	P_LoadSideDefs
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadSideDefs
	.type	P_LoadSideDefs, @function
P_LoadSideDefs:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$31,44($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	move	$19,$4
	sw	$17,24($sp)
	sw	$21,40($sp)
	jal	W_LumpLength
	sw	$16,20($sp)

	li	$3,-2004353024			# 0xffffffff88880000
	ori	$3,$3,0x8889
	multu	$2,$3
	lui	$17,%hi(numsides)
	mfhi	$2
	move	$6,$0
	srl	$2,$2,4
	sll	$4,$2,2
	addu	$4,$4,$2
	li	$5,5			# 0x5
	sll	$4,$4,2
	jal	Z_Malloc
	sw	$2,%lo(numsides)($17)

	lw	$3,%lo(numsides)($17)
	move	$4,$2
	sll	$6,$3,2
	addu	$6,$6,$3
	lui	$18,%hi(sides)
	sll	$6,$6,2
	move	$5,$0
	jal	memset
	sw	$2,%lo(sides)($18)

	li	$5,1			# 0x1
	jal	W_CacheLumpNum
	move	$4,$19

	lw	$3,%lo(numsides)($17)
	blez	$3,$L73
	lw	$20,%lo(sides)($18)

	move	$16,$2
	move	$21,$0
	lui	$18,%hi(sectors)
$L74:
	lbu	$2,1($16)
	lbu	$3,0($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sw	$2,0($20)
	lbu	$2,3($16)
	lbu	$3,2($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	addiu	$4,$16,4
	jal	R_TextureNumForName
	sw	$2,4($20)

	sh	$2,8($20)
	jal	R_TextureNumForName
	addiu	$4,$16,12

	sh	$2,10($20)
	jal	R_TextureNumForName
	addiu	$4,$16,20

	sh	$2,12($20)
	lbu	$3,29($16)
	lbu	$2,28($16)
	sll	$3,$3,8
	or	$3,$3,$2
	sll	$3,$3,16
	sra	$3,$3,16
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	lw	$5,%lo(sectors)($18)
	lw	$4,%lo(numsides)($17)
	subu	$2,$2,$3
	sll	$2,$2,3
	addiu	$21,$21,1
	addu	$3,$5,$2
	slt	$2,$21,$4
	sw	$3,16($20)
	addiu	$16,$16,30
	bne	$2,$0,$L74
	addiu	$20,$20,20

$L73:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$19
	lw	$19,32($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	P_LoadSideDefs
	.size	P_LoadSideDefs, .-P_LoadSideDefs
	.align	2
	.globl	P_LoadBlockMap
	.set	nomips16
	.set	nomicromips
	.ent	P_LoadBlockMap
	.type	P_LoadBlockMap, @function
P_LoadBlockMap:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	jal	W_LumpLength
	move	$16,$4

	move	$4,$2
	move	$6,$0
	jal	Z_Malloc
	li	$5,5			# 0x5

	move	$5,$2
	lui	$17,%hi(blockmaplump)
	move	$4,$16
	jal	W_ReadLump
	sw	$2,%lo(blockmaplump)($17)

	lw	$2,%lo(blockmaplump)($17)
	lui	$10,%hi(blockmap)
	lh	$9,4($2)
	lh	$8,6($2)
	lh	$7,0($2)
	multu	$9,$8
	mflo	$16
	lh	$3,2($2)
	addiu	$2,$2,8
	sll	$7,$7,16
	sw	$2,%lo(blockmap)($10)
	lui	$2,%hi(bmaporgx)
	sll	$3,$3,16
	sw	$7,%lo(bmaporgx)($2)
	lui	$2,%hi(bmaporgy)
	sll	$16,$16,2
	sw	$3,%lo(bmaporgy)($2)
	lui	$2,%hi(bmapwidth)
	move	$4,$16
	move	$6,$0
	li	$5,5			# 0x5
	sw	$9,%lo(bmapwidth)($2)
	lui	$2,%hi(bmapheight)
	jal	Z_Malloc
	sw	$8,%lo(bmapheight)($2)

	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$6,$16
	lw	$16,20($sp)
	lui	$3,%hi(blocklinks)
	move	$5,$0
	move	$4,$2
	addiu	$sp,$sp,32
	j	memset
	sw	$2,%lo(blocklinks)($3)

	.set	macro
	.set	reorder
	.end	P_LoadBlockMap
	.size	P_LoadBlockMap, .-P_LoadBlockMap
	.align	2
	.globl	P_GroupLines
	.set	nomips16
	.set	nomicromips
	.ent	P_GroupLines
	.type	P_GroupLines, @function
P_GroupLines:
	.frame	$sp,80,$31		# vars= 24, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numsubsectors)
	lw	$5,%lo(numsubsectors)($2)
	addiu	$sp,$sp,-80
	lui	$2,%hi(subsectors)
	lw	$3,%lo(subsectors)($2)
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$22,64($sp)
	sw	$21,60($sp)
	sw	$20,56($sp)
	sw	$19,52($sp)
	sw	$18,48($sp)
	sw	$17,44($sp)
	blez	$5,$L84
	sw	$16,40($sp)

	lui	$2,%hi(segs)
	lw	$6,%lo(segs)($2)
	move	$4,$0
$L83:
	lh	$2,6($3)
	addiu	$4,$4,1
	sll	$2,$2,5
	addu	$2,$6,$2
	lw	$2,16($2)
	addiu	$3,$3,8
	lw	$2,16($2)
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L83
	.set	at
	sw	$2,-8($3)

$L84:
	lui	$17,%hi(numlines)
	lw	$9,%lo(numlines)($17)
	lui	$16,%hi(lines)
	lui	$10,%hi(totallines)
	lw	$2,%lo(lines)($16)
	sw	$0,%lo(totallines)($10)
	blez	$9,$L82
	move	$4,$0

	move	$7,$0
	b	$L81
	move	$6,$0

$L118:
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L104
	.set	at
	addiu	$7,$7,2

	lw	$3,80($5)
	addiu	$6,$6,1
	addiu	$3,$3,1
	sw	$3,80($5)
	.set	noat
	xor	$1,$6,$9
	beq	$1,$0,$L117
	.set	at
	addiu	$2,$2,64

$L81:
	lw	$4,48($2)
	lw	$5,52($2)
	lw	$3,80($4)
	addiu	$8,$7,1
	addiu	$3,$3,1
	bne	$5,$0,$L118
	sw	$3,80($4)

$L104:
	addiu	$6,$6,1
	move	$7,$8
	.set	noat
	xor	$1,$6,$9
	bne	$1,$0,$L81
	.set	at
	addiu	$2,$2,64

$L117:
	sw	$7,%lo(totallines)($10)
	sll	$4,$7,2
$L82:
	move	$6,$0
	li	$5,5			# 0x5
	jal	Z_Malloc
	lui	$20,%hi(numsectors)

	lw	$9,%lo(numsectors)($20)
	blez	$9,$L86
	sll	$6,$9,1

	addu	$6,$6,$9
	lui	$3,%hi(sectors)
	lw	$21,%lo(sectors)($3)
	sll	$6,$6,2
	subu	$6,$6,$9
	addiu	$4,$21,80
	sll	$6,$6,3
	addu	$6,$4,$6
$L87:
	lw	$5,0($4)
	sw	$2,4($4)
	sll	$5,$5,2
	sw	$0,0($4)
	addiu	$4,$4,88
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L87
	.set	at
	addu	$2,$2,$5

	lw	$11,%lo(numlines)($17)
	blez	$11,$L120
	lui	$2,%hi(bmaporgx)

$L101:
	b	$L93
	move	$5,$0

$L89:
	lw	$7,80($4)
	lw	$8,84($4)
	sll	$10,$7,2
	addu	$8,$8,$10
	addiu	$7,$7,1
	sw	$2,0($8)
	beq	$6,$0,$L91
	sw	$7,80($4)

	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L90
	.set	at
	nop

$L91:
	addiu	$5,$5,1
	slt	$2,$5,$11
	beq	$2,$0,$L119
	nop

$L93:
	lw	$2,%lo(lines)($16)
	sll	$4,$5,6
	addu	$2,$2,$4
	lw	$4,48($2)
	bne	$4,$0,$L89
	lw	$6,52($2)

	beq	$6,$0,$L91
	nop

$L90:
	lw	$4,80($6)
	lw	$7,84($6)
	sll	$8,$4,2
	addu	$7,$7,$8
	addiu	$5,$5,1
	sw	$2,0($7)
	addiu	$4,$4,1
	slt	$2,$5,$11
	bne	$2,$0,$L93
	sw	$4,80($6)

$L119:
	blez	$9,$L79
	lui	$2,%hi(bmaporgx)

$L120:
	sw	$2,36($sp)
	lui	$2,%hi(bmapwidth)
	move	$17,$0
	lui	$fp,%hi(bmaporgy)
	lui	$23,%hi(bmapheight)
	sw	$2,32($sp)
	li	$19,2097152			# 0x200000
	li	$18,-2097152			# 0xffffffffffe00000
$L99:
	jal	M_ClearBox
	addiu	$4,$sp,16

	lw	$2,80($21)
	blez	$2,$L97
	move	$16,$0

$L94:
	lw	$2,84($21)
	sll	$4,$16,2
	addu	$2,$2,$4
	lw	$22,0($2)
	addiu	$4,$sp,16
	lw	$5,0($22)
	addiu	$16,$16,1
	lw	$6,4($5)
	jal	M_AddToBox
	lw	$5,0($5)

	lw	$2,4($22)
	addiu	$4,$sp,16
	lw	$6,4($2)
	jal	M_AddToBox
	lw	$5,0($2)

	lw	$2,80($21)
	slt	$2,$16,$2
	bne	$2,$0,$L94
	nop

$L97:
	lw	$2,28($sp)
	lw	$5,24($sp)
	addu	$6,$2,$5
	srl	$4,$6,31
	addu	$4,$4,$6
	sra	$4,$4,1
	sw	$4,56($21)
	lw	$4,16($sp)
	lw	$6,20($sp)
	addu	$8,$4,$6
	srl	$7,$8,31
	addu	$7,$7,$8
	sra	$7,$7,1
	sw	$7,60($21)
	lw	$7,%lo(bmaporgy)($fp)
	lw	$8,%lo(bmapheight)($23)
	subu	$4,$4,$7
	addu	$4,$4,$19
	sra	$4,$4,23
	slt	$9,$4,$8
	bne	$9,$0,$L96
	nop

	addiu	$4,$8,-1
$L96:
	subu	$6,$6,$7
	addu	$6,$6,$18
	sra	$7,$6,23
	slt	$6,$6,0
	movn	$7,$0,$6
	lw	$3,36($sp)
	sw	$7,32($21)
	sw	$4,28($21)
	lw	$4,%lo(bmaporgx)($3)
	lw	$3,32($sp)
	subu	$2,$2,$4
	lw	$6,%lo(bmapwidth)($3)
	addu	$2,$2,$19
	sra	$2,$2,23
	slt	$7,$2,$6
	bne	$7,$0,$L98
	nop

	addiu	$2,$6,-1
$L98:
	subu	$4,$5,$4
	addu	$4,$4,$18
	sra	$5,$4,23
	slt	$4,$4,0
	movn	$5,$0,$4
	sw	$2,40($21)
	sw	$5,36($21)
	lw	$2,%lo(numsectors)($20)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L99
	addiu	$21,$21,88

$L79:
	lw	$31,76($sp)
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$22,64($sp)
	lw	$21,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	jr	$31
	addiu	$sp,$sp,80

$L86:
	lw	$11,%lo(numlines)($17)
	blez	$11,$L79
	lui	$2,%hi(sectors)

	b	$L101
	lw	$21,%lo(sectors)($2)

	.set	macro
	.set	reorder
	.end	P_GroupLines
	.size	P_GroupLines, .-P_GroupLines
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"map0%i\000"
	.align	2
$LC1:
	.ascii	"map%i\000"
	.align	2
$LC2:
	.ascii	"PadRejectArray: REJECT lump too short to pad! (%i > %i)\012"
	.ascii	"\000"
	.align	2
$LC3:
	.ascii	"-reject_pad_with_ff\000"
	.text
	.align	2
	.globl	P_SetupLevel
	.set	nomips16
	.set	nomicromips
	.ent	P_SetupLevel
	.type	P_SetupLevel, @function
P_SetupLevel:
	.frame	$sp,88,$31		# vars= 40, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-88
	sw	$17,64($sp)
	move	$17,$4
	lui	$4,%hi(totalsecret)
	sw	$0,%lo(totalsecret)($4)
	lui	$4,%hi(totalitems)
	lui	$3,%hi(players)
	lui	$2,%hi(wminfo)
	sw	$0,%lo(totalitems)($4)
	lui	$4,%hi(totalkills)
	addiu	$3,$3,%lo(players)
	addiu	$2,$2,%lo(wminfo)
	sw	$0,%lo(totalkills)($4)
	li	$4,180			# 0xb4
	sw	$18,68($sp)
	sw	$16,60($sp)
	sw	$31,84($sp)
	sw	$21,80($sp)
	sw	$20,76($sp)
	sw	$19,72($sp)
	move	$18,$5
	sw	$0,28($2)
	sw	$4,32($2)
	move	$16,$3
	addiu	$6,$3,1152
	move	$2,$3
$L122:
	sw	$0,216($2)
	sw	$0,220($2)
	sw	$0,212($2)
	addiu	$2,$2,288
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L122
	.set	at
	nop

	lui	$2,%hi(consoleplayer)
	lw	$4,%lo(consoleplayer)($2)
	sll	$2,$4,3
	addu	$2,$2,$4
	sll	$2,$2,5
	addu	$3,$3,$2
	li	$2,1			# 0x1
	jal	S_Start
	sw	$2,24($3)

	li	$5,6			# 0x6
	jal	Z_FreeTags
	li	$4,5			# 0x5

	jal	P_InitThinkers
	nop

	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L145
	.set	at
	li	$2,69			# 0x45

	addiu	$17,$17,48
	addiu	$5,$18,48
	sb	$2,32($sp)
	li	$2,77			# 0x4d
	sb	$17,33($sp)
	sb	$2,34($sp)
	sb	$5,35($sp)
	sb	$0,36($sp)
	addiu	$4,$sp,32
$L125:
	jal	W_GetNumForName
	nop

	move	$17,$2
	addiu	$4,$2,10
	lui	$2,%hi(leveltime)
	jal	P_LoadBlockMap
	sw	$0,%lo(leveltime)($2)

	jal	P_LoadVertexes
	addiu	$4,$17,4

	jal	P_LoadSectors
	addiu	$4,$17,8

	jal	P_LoadSideDefs
	addiu	$4,$17,3

	jal	P_LoadLineDefs
	addiu	$4,$17,2

	jal	P_LoadSubsectors
	addiu	$4,$17,6

	jal	P_LoadNodes
	addiu	$4,$17,7

	jal	P_LoadSegs
	addiu	$4,$17,5

	jal	P_GroupLines
	addiu	$19,$17,9

	lui	$2,%hi(numsectors)
	lw	$18,%lo(numsectors)($2)
	multu	$18,$18
	mflo	$18
	move	$4,$19
	jal	W_LumpLength
	addiu	$18,$18,7

	sra	$18,$18,3
	move	$20,$2
	slt	$2,$2,$18
	bne	$2,$0,$L126
	lui	$21,%hi(rejectmatrix)

	li	$5,5			# 0x5
	jal	W_CacheLumpNum
	move	$4,$19

	lui	$3,%hi(rejectmatrix)
	sw	$2,%lo(rejectmatrix)($3)
$L127:
	lui	$2,%hi(bodyqueslot)
$L150:
	sw	$0,%lo(bodyqueslot)($2)
	lui	$2,%hi(deathmatchstarts)
	addiu	$2,$2,%lo(deathmatchstarts)
	lui	$3,%hi(deathmatch_p)
	addiu	$4,$17,1
	jal	P_LoadThings
	sw	$2,%lo(deathmatch_p)($3)

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	beq	$2,$0,$L151
	lui	$2,%hi(iquetail)

	lui	$17,%hi(playeringame)
	addiu	$17,$17,%lo(playeringame)
	move	$18,$0
	li	$19,4			# 0x4
$L136:
	lw	$2,0($17)
	bne	$2,$0,$L146
	addiu	$17,$17,4

	addiu	$18,$18,1
$L149:
	.set	noat
	xor	$1,$18,$19
	bne	$1,$0,$L136
	.set	at
	addiu	$16,$16,288

	lui	$2,%hi(iquetail)
$L151:
	sw	$0,%lo(iquetail)($2)
	lui	$2,%hi(iquehead)
	jal	P_SpawnSpecials
	sw	$0,%lo(iquehead)($2)

	lui	$2,%hi(precache)
	lw	$2,%lo(precache)($2)
	bne	$2,$0,$L147
	lw	$31,84($sp)

	lw	$21,80($sp)
	lw	$20,76($sp)
	lw	$19,72($sp)
	lw	$18,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	jr	$31
	addiu	$sp,$sp,88

$L146:
	move	$4,$18
	jal	G_DeathMatchSpawnPlayer
	sw	$0,0($16)

	b	$L149
	addiu	$18,$18,1

$L126:
	move	$4,$18
	addiu	$6,$21,%lo(rejectmatrix)
	jal	Z_Malloc
	li	$5,5			# 0x5

	move	$5,$2
	move	$4,$19
	jal	W_ReadLump
	sw	$2,%lo(rejectmatrix)($21)

	lui	$2,%hi(totallines)
	lw	$5,%lo(totallines)($2)
	li	$2,50			# 0x32
	lw	$19,%lo(rejectmatrix)($21)
	sll	$5,$5,2
	sw	$2,24($sp)
	li	$2,1900544			# 0x1d0000
	addiu	$5,$5,24
	addiu	$2,$2,18961
	addu	$19,$19,$20
	subu	$18,$18,$20
	sw	$5,16($sp)
	sw	$0,20($sp)
	sw	$2,28($sp)
	move	$3,$0
	b	$L130
	li	$6,16			# 0x10

$L148:
	lw	$5,0($5)
$L130:
	sll	$4,$3,3
	addu	$2,$19,$3
	addiu	$3,$3,1
	srl	$7,$5,$4
	srl	$5,$3,2
	sll	$5,$5,2
	addiu	$4,$sp,16
	addu	$5,$4,$5
	.set	noat
	xor	$1,$18,$3
	beq	$1,$0,$L127
	.set	at
	sb	$7,0($2)

	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L148
	.set	at
	slt	$2,$18,17

	bne	$2,$0,$L127
	lui	$2,%hi(stderr)

	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC2)
	move	$6,$18
	addiu	$5,$5,%lo($LC2)
	jal	fprintf
	li	$7,16			# 0x10

	lui	$4,%hi($LC3)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC3)

	li	$3,3840			# 0xf00
	li	$5,255			# 0xff
	addiu	$6,$18,-16
	movz	$5,$3,$2
	jal	memset
	addiu	$4,$19,16

	b	$L150
	lui	$2,%hi(bodyqueslot)

$L145:
	slt	$2,$18,10
	addiu	$4,$sp,32
	beq	$2,$0,$L124
	move	$7,$18

	lui	$6,%hi($LC0)
	addiu	$6,$6,%lo($LC0)
	li	$5,9			# 0x9
	jal	snprintf
	sw	$4,48($sp)

	b	$L125
	lw	$4,48($sp)

$L147:
	jal	R_PrecacheLevel
	nop

	lw	$31,84($sp)
	lw	$21,80($sp)
	lw	$20,76($sp)
	lw	$19,72($sp)
	lw	$18,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	jr	$31
	addiu	$sp,$sp,88

$L124:
	lui	$6,%hi($LC1)
	addiu	$6,$6,%lo($LC1)
	li	$5,9			# 0x9
	jal	snprintf
	sw	$4,48($sp)

	b	$L125
	lw	$4,48($sp)

	.set	macro
	.set	reorder
	.end	P_SetupLevel
	.size	P_SetupLevel, .-P_SetupLevel
	.align	2
	.globl	P_Init
	.set	nomips16
	.set	nomicromips
	.ent	P_Init
	.type	P_Init, @function
P_Init:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	P_InitSwitchList
	nop

	jal	P_InitPicAnims
	nop

	lw	$31,20($sp)
	lui	$4,%hi(sprnames)
	addiu	$4,$4,%lo(sprnames)
	j	R_InitSprites
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_Init
	.size	P_Init, .-P_Init
	.local	null_sector.0
	.comm	null_sector.0,88,4
	.local	null_sector_is_initialized.1
	.comm	null_sector_is_initialized.1,4,4
	.globl	playerstarts
	.section	.bss,"aw",@nobits
	.align	2
	.type	playerstarts, @object
	.size	playerstarts, 40
playerstarts:
	.space	40
	.globl	deathmatch_p
	.align	2
	.type	deathmatch_p, @object
	.size	deathmatch_p, 4
deathmatch_p:
	.space	4
	.globl	deathmatchstarts
	.align	2
	.type	deathmatchstarts, @object
	.size	deathmatchstarts, 100
deathmatchstarts:
	.space	100
	.globl	rejectmatrix
	.align	2
	.type	rejectmatrix, @object
	.size	rejectmatrix, 4
rejectmatrix:
	.space	4
	.globl	blocklinks
	.align	2
	.type	blocklinks, @object
	.size	blocklinks, 4
blocklinks:
	.space	4
	.globl	bmaporgy
	.align	2
	.type	bmaporgy, @object
	.size	bmaporgy, 4
bmaporgy:
	.space	4
	.globl	bmaporgx
	.align	2
	.type	bmaporgx, @object
	.size	bmaporgx, 4
bmaporgx:
	.space	4
	.globl	blockmaplump
	.align	2
	.type	blockmaplump, @object
	.size	blockmaplump, 4
blockmaplump:
	.space	4
	.globl	blockmap
	.align	2
	.type	blockmap, @object
	.size	blockmap, 4
blockmap:
	.space	4
	.globl	bmapheight
	.align	2
	.type	bmapheight, @object
	.size	bmapheight, 4
bmapheight:
	.space	4
	.globl	bmapwidth
	.align	2
	.type	bmapwidth, @object
	.size	bmapwidth, 4
bmapwidth:
	.space	4
	.local	totallines
	.comm	totallines,4,4
	.globl	sides
	.align	2
	.type	sides, @object
	.size	sides, 4
sides:
	.space	4
	.globl	numsides
	.align	2
	.type	numsides, @object
	.size	numsides, 4
numsides:
	.space	4
	.globl	lines
	.align	2
	.type	lines, @object
	.size	lines, 4
lines:
	.space	4
	.globl	numlines
	.align	2
	.type	numlines, @object
	.size	numlines, 4
numlines:
	.space	4
	.globl	nodes
	.align	2
	.type	nodes, @object
	.size	nodes, 4
nodes:
	.space	4
	.globl	numnodes
	.align	2
	.type	numnodes, @object
	.size	numnodes, 4
numnodes:
	.space	4
	.globl	subsectors
	.align	2
	.type	subsectors, @object
	.size	subsectors, 4
subsectors:
	.space	4
	.globl	numsubsectors
	.align	2
	.type	numsubsectors, @object
	.size	numsubsectors, 4
numsubsectors:
	.space	4
	.globl	sectors
	.align	2
	.type	sectors, @object
	.size	sectors, 4
sectors:
	.space	4
	.globl	numsectors
	.align	2
	.type	numsectors, @object
	.size	numsectors, 4
numsectors:
	.space	4
	.globl	segs
	.align	2
	.type	segs, @object
	.size	segs, 4
segs:
	.space	4
	.globl	numsegs
	.align	2
	.type	numsegs, @object
	.size	numsegs, 4
numsegs:
	.space	4
	.globl	vertexes
	.align	2
	.type	vertexes, @object
	.size	vertexes, 4
vertexes:
	.space	4
	.globl	numvertexes
	.align	2
	.type	numvertexes, @object
	.size	numvertexes, 4
numvertexes:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
