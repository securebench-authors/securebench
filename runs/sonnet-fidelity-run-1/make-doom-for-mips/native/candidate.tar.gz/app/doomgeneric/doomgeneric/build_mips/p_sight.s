	.file	1 "p_sight.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_DivlineSide
	.set	nomips16
	.set	nomicromips
	.ent	P_DivlineSide
	.type	P_DivlineSide, @function
P_DivlineSide:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,8($6)
	bne	$2,$0,$L2
	nop

	lw	$2,0($6)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L8
	.set	at
	slt	$3,$2,$4

	bne	$3,$0,$L11
	lw	$2,12($6)

$L6:
	jr	$31
	slt	$2,$0,$2

$L2:
	lw	$3,12($6)
	bne	$3,$0,$L5
	lw	$7,4($6)

	.set	noat
	xor	$1,$4,$7
	beq	$1,$0,$L8
	.set	at
	slt	$5,$7,$5

	bne	$5,$0,$L6
	nop

$L11:
	jr	$31
	srl	$2,$2,31

$L5:
	lw	$6,0($6)
	subu	$5,$5,$7
	subu	$4,$4,$6
	sra	$2,$2,16
	sra	$4,$4,16
	sra	$3,$3,16
	sra	$5,$5,16
	multu	$4,$3
	mflo	$4
	multu	$5,$2
	mflo	$5
	slt	$2,$5,$4
	bne	$2,$0,$L9
	xor	$4,$4,$5

	li	$3,2			# 0x2
	li	$2,1			# 0x1
	jr	$31
	movz	$2,$3,$4

$L9:
	jr	$31
	move	$2,$0

$L8:
	jr	$31
	li	$2,2			# 0x2

	.set	macro
	.set	reorder
	.end	P_DivlineSide
	.size	P_DivlineSide, .-P_DivlineSide
	.align	2
	.globl	P_InterceptVector2
	.set	nomips16
	.set	nomicromips
	.ent	P_InterceptVector2
	.type	P_InterceptVector2, @function
P_InterceptVector2:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	move	$17,$4
	lw	$4,12($5)
	sw	$16,20($sp)
	move	$16,$5
	lw	$5,8($17)
	sra	$4,$4,8
	sw	$31,36($sp)
	sw	$19,32($sp)
	jal	FixedMul
	sw	$18,28($sp)

	lw	$4,8($16)
	lw	$5,12($17)
	sra	$4,$4,8
	jal	FixedMul
	move	$18,$2

	.set	noat
	xor	$1,$18,$2
	bne	$1,$0,$L16
	.set	at
	subu	$19,$18,$2

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

$L16:
	lw	$4,0($16)
	lw	$2,0($17)
	lw	$5,12($16)
	subu	$4,$4,$2
	jal	FixedMul
	sra	$4,$4,8

	lw	$4,4($17)
	lw	$3,4($16)
	lw	$5,8($16)
	subu	$4,$4,$3
	sra	$4,$4,8
	jal	FixedMul
	move	$16,$2

	addu	$4,$16,$2
	lw	$31,36($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$5,$19
	lw	$19,32($sp)
	j	FixedDiv
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_InterceptVector2
	.size	P_InterceptVector2, .-P_InterceptVector2
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"P_CrossSubsector: ss %i with numss = %i\000"
	.text
	.align	2
	.globl	P_CrossSubsector
	.set	nomips16
	.set	nomicromips
	.ent	P_CrossSubsector
	.type	P_CrossSubsector, @function
P_CrossSubsector:
	.frame	$sp,96,$31		# vars= 40, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numsubsectors)
	lw	$6,%lo(numsubsectors)($2)
	addiu	$sp,$sp,-96
	slt	$2,$4,$6
	sw	$16,56($sp)
	sw	$31,92($sp)
	sw	$fp,88($sp)
	sw	$23,84($sp)
	sw	$22,80($sp)
	sw	$21,76($sp)
	sw	$20,72($sp)
	sw	$19,68($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
	beq	$2,$0,$L39
	move	$16,$4

	lui	$2,%hi(subsectors)
$L42:
	lw	$2,%lo(subsectors)($2)
	sll	$16,$16,3
	addu	$2,$2,$16
	lh	$3,6($2)
	lui	$4,%hi(segs)
	lw	$16,%lo(segs)($4)
	lh	$17,4($2)
	sll	$2,$3,5
	beq	$17,$0,$L22
	addu	$16,$16,$2

	lui	$2,%hi(t2y)
	sw	$2,32($sp)
	lui	$2,%hi(t2x)
	sw	$2,36($sp)
	lui	$2,%hi(sightzstart)
	lui	$22,%hi(strace)
	sw	$2,48($sp)
	lui	$2,%hi(topslope)
	lui	$20,%hi(validcount)
	addiu	$18,$22,%lo(strace)
	sw	$2,44($sp)
	b	$L19
	lui	$21,%hi(bottomslope)

$L41:
	lw	$3,%lo(topslope)($2)
$L31:
	lw	$2,%lo(bottomslope)($21)
	slt	$2,$2,$3
	beq	$2,$0,$L43
	lw	$31,92($sp)

$L23:
	addiu	$17,$17,-1
$L45:
	beq	$17,$0,$L22
	addiu	$16,$16,32

$L19:
	lw	$8,20($16)
	lw	$2,%lo(validcount)($20)
	lw	$3,56($8)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L23
	.set	at
	move	$6,$18

	lw	$3,0($8)
	lw	$9,4($8)
	lw	$13,0($3)
	lw	$12,4($3)
	move	$5,$12
	move	$4,$13
	jal	P_DivlineSide
	sw	$2,56($8)

	lw	$10,0($9)
	lw	$9,4($9)
	move	$6,$18
	move	$5,$9
	move	$4,$10
	jal	P_DivlineSide
	move	$11,$2

	.set	noat
	xor	$1,$11,$2
	beq	$1,$0,$L23
	.set	at
	lw	$4,%lo(strace)($22)

	lw	$5,4($18)
	addiu	$6,$sp,16
	subu	$9,$9,$12
	subu	$10,$10,$13
	sw	$9,28($sp)
	sw	$13,16($sp)
	sw	$12,20($sp)
	jal	P_DivlineSide
	sw	$10,24($sp)

	lw	$3,32($sp)
	addiu	$6,$sp,16
	lw	$5,%lo(t2y)($3)
	lw	$3,36($sp)
	move	$9,$2
	jal	P_DivlineSide
	lw	$4,%lo(t2x)($3)

	.set	noat
	xor	$1,$9,$2
	beq	$1,$0,$L23
	.set	at
	nop

	lw	$2,52($8)
	beq	$2,$0,$L43
	lw	$31,92($sp)

	lhu	$2,16($8)
	andi	$2,$2,0x4
	beq	$2,$0,$L44
	lw	$fp,88($sp)

	lw	$fp,24($16)
	lw	$23,28($16)
	lw	$2,0($fp)
	lw	$3,0($23)
	lw	$19,4($fp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L40
	.set	at
	lw	$4,4($23)

	slt	$5,$2,$3
$L46:
	slt	$8,$4,$19
	movz	$3,$2,$5
	movn	$19,$4,$8
	slt	$2,$3,$19
	beq	$2,$0,$L25
	sw	$3,40($sp)

	addiu	$5,$sp,16
	jal	P_InterceptVector2
	move	$4,$18

	lw	$8,0($fp)
	lw	$4,0($23)
	.set	noat
	xor	$1,$8,$4
	beq	$1,$0,$L28
	.set	at
	move	$5,$2

	lw	$2,48($sp)
	lw	$3,40($sp)
	lw	$4,%lo(sightzstart)($2)
	sw	$5,52($sp)
	jal	FixedDiv
	subu	$4,$3,$4

	lw	$3,%lo(bottomslope)($21)
	slt	$3,$3,$2
	beq	$3,$0,$L28
	lw	$5,52($sp)

	sw	$2,%lo(bottomslope)($21)
$L28:
	lw	$3,4($fp)
	lw	$2,4($23)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L41
	.set	at
	lw	$2,44($sp)

	lw	$2,48($sp)
	lw	$4,%lo(sightzstart)($2)
	jal	FixedDiv
	subu	$4,$19,$4

	lw	$5,44($sp)
	lw	$3,%lo(topslope)($5)
	slt	$4,$2,$3
	beq	$4,$0,$L31
	nop

	move	$3,$2
	sw	$2,%lo(topslope)($5)
	lw	$2,%lo(bottomslope)($21)
	slt	$2,$2,$3
	bne	$2,$0,$L45
	addiu	$17,$17,-1

$L25:
	lw	$31,92($sp)
$L43:
	lw	$fp,88($sp)
$L44:
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,96

$L40:
	.set	noat
	xor	$1,$19,$4
	bne	$1,$0,$L46
	.set	at
	slt	$5,$2,$3

	addiu	$17,$17,-1
	bne	$17,$0,$L19
	addiu	$16,$16,32

$L22:
	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,96

$L39:
	move	$5,$4
	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	b	$L42
	lui	$2,%hi(subsectors)

	.set	macro
	.set	reorder
	.end	P_CrossSubsector
	.size	P_CrossSubsector, .-P_CrossSubsector
	.align	2
	.globl	P_CrossBSPNode
	.set	nomips16
	.set	nomicromips
	.ent	P_CrossBSPNode
	.type	P_CrossBSPNode, @function
P_CrossBSPNode:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	andi	$2,$4,0x8000
	bne	$2,$0,$L57
	li	$2,-1			# 0xffffffffffffffff

	addiu	$sp,$sp,-56
	sw	$16,20($sp)
	lui	$16,%hi(strace)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	lui	$19,%hi(nodes)
	addiu	$18,$16,%lo(strace)
	li	$17,2			# 0x2
	lui	$21,%hi(t2y)
	lui	$20,%hi(t2x)
$L48:
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	lw	$22,%lo(nodes)($19)
	sll	$2,$2,2
	addu	$22,$22,$2
	lw	$5,4($18)
	lw	$4,%lo(strace)($16)
	jal	P_DivlineSide
	move	$6,$22

	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L50
	.set	at
	move	$23,$2

	move	$23,$0
$L50:
	addiu	$2,$23,24
	sll	$2,$2,1
	addu	$2,$22,$2
	jal	P_CrossBSPNode
	lhu	$4,0($2)

	beq	$2,$0,$L47
	move	$6,$22

	lw	$5,%lo(t2y)($21)
	jal	P_DivlineSide
	lw	$4,%lo(t2x)($20)

	xori	$3,$23,0x1
	addiu	$3,$3,24
	sll	$3,$3,1
	.set	noat
	xor	$1,$2,$23
	beq	$1,$0,$L52
	.set	at
	addu	$22,$22,$3

	lh	$2,0($22)
	bgez	$2,$L48
	lhu	$4,0($22)

	li	$2,-65536			# 0xffffffffffff0000
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	addiu	$2,$2,32767
	and	$4,$4,$2
	j	P_CrossSubsector
	addiu	$sp,$sp,56

$L52:
	li	$2,1			# 0x1
$L47:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L57:
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L59
	.set	at
	li	$2,-65536			# 0xffffffffffff0000

	j	P_CrossSubsector
	move	$4,$0

$L59:
	addiu	$2,$2,32767
	j	P_CrossSubsector
	and	$4,$4,$2

	.set	macro
	.set	reorder
	.end	P_CrossBSPNode
	.size	P_CrossBSPNode, .-P_CrossBSPNode
	.align	2
	.globl	P_CheckSight
	.set	nomips16
	.set	nomicromips
	.ent	P_CheckSight
	.type	P_CheckSight, @function
P_CheckSight:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,52($4)
	lw	$3,52($5)
	lui	$6,%hi(sectors)
	lw	$6,%lo(sectors)($6)
	lw	$2,0($2)
	lw	$3,0($3)
	subu	$2,$2,$6
	subu	$3,$3,$6
	li	$6,-1171390464			# 0xffffffffba2e0000
	ori	$6,$6,0x8ba3
	sra	$2,$2,3
	multu	$2,$6
	mflo	$2
	sra	$3,$3,3
	mult	$3,$6
	lui	$3,%hi(numsectors)
	lw	$3,%lo(numsectors)($3)
	madd	$2,$3
	lui	$3,%hi(rejectmatrix)
	mflo	$2
	lw	$3,%lo(rejectmatrix)($3)
	sra	$6,$2,3
	addu	$3,$3,$6
	lbu	$3,0($3)
	andi	$2,$2,0x7
	li	$6,1			# 0x1
	sll	$2,$6,$2
	and	$2,$3,$2
	beq	$2,$0,$L67
	lui	$3,%hi(sightcounts)

	lw	$2,%lo(sightcounts)($3)
	addiu	$2,$2,1
	sw	$2,%lo(sightcounts)($3)
	jr	$31
	move	$2,$0

$L67:
	lui	$7,%hi(sightcounts)
	addiu	$7,$7,%lo(sightcounts)
	lw	$8,68($4)
	lw	$10,4($7)
	lw	$2,20($4)
	lw	$6,20($5)
	lw	$3,68($5)
	addu	$2,$8,$2
	addiu	$10,$10,1
	sra	$8,$8,2
	subu	$2,$2,$8
	addu	$3,$6,$3
	sw	$10,4($7)
	lui	$7,%hi(sightzstart)
	lw	$15,12($4)
	lw	$13,16($4)
	lui	$24,%hi(validcount)
	subu	$3,$3,$2
	subu	$6,$6,$2
	lui	$4,%hi(numnodes)
	sw	$2,%lo(sightzstart)($7)
	lui	$2,%hi(topslope)
	lw	$12,12($5)
	lw	$9,%lo(validcount)($24)
	lw	$11,16($5)
	lw	$4,%lo(numnodes)($4)
	sw	$3,%lo(topslope)($2)
	lui	$2,%hi(bottomslope)
	lui	$14,%hi(strace)
	sw	$6,%lo(bottomslope)($2)
	lui	$2,%hi(t2x)
	addiu	$5,$14,%lo(strace)
	addiu	$8,$9,1
	subu	$25,$12,$15
	subu	$9,$11,$13
	sw	$12,%lo(t2x)($2)
	addiu	$4,$4,-1
	lui	$2,%hi(t2y)
	sw	$8,%lo(validcount)($24)
	sw	$15,%lo(strace)($14)
	sw	$13,4($5)
	sw	$11,%lo(t2y)($2)
	sw	$25,8($5)
	j	P_CrossBSPNode
	sw	$9,12($5)

	.set	macro
	.set	reorder
	.end	P_CheckSight
	.size	P_CheckSight, .-P_CheckSight
	.globl	sightcounts
	.section	.bss,"aw",@nobits
	.align	2
	.type	sightcounts, @object
	.size	sightcounts, 8
sightcounts:
	.space	8
	.globl	t2y
	.align	2
	.type	t2y, @object
	.size	t2y, 4
t2y:
	.space	4
	.globl	t2x
	.align	2
	.type	t2x, @object
	.size	t2x, 4
t2x:
	.space	4
	.globl	strace
	.align	2
	.type	strace, @object
	.size	strace, 16
strace:
	.space	16
	.globl	bottomslope
	.align	2
	.type	bottomslope, @object
	.size	bottomslope, 4
bottomslope:
	.space	4
	.globl	topslope
	.align	2
	.type	topslope, @object
	.size	topslope, 4
topslope:
	.space	4
	.globl	sightzstart
	.align	2
	.type	sightzstart, @object
	.size	sightzstart, 4
sightzstart:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
