	.file	1 "p_spec.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"P_InitPicAnims: bad cycle from %s to %s\000"
	.text
	.align	2
	.globl	P_InitPicAnims
	.set	nomips16
	.set	nomicromips
	.ent	P_InitPicAnims
	.type	P_InitPicAnims, @function
P_InitPicAnims:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(animdefs)
	addiu	$sp,$sp,-48
	lui	$3,%hi(anims)
	lw	$2,%lo(animdefs)($2)
	addiu	$3,$3,%lo(anims)
	sw	$17,20($sp)
	li	$4,-1			# 0xffffffffffffffff
	lui	$17,%hi(lastanim)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L1
	.set	at
	sw	$3,%lo(lastanim)($17)

	lui	$16,%hi(animdefs+13)
	lui	$20,%hi($LC0)
	addiu	$16,$16,%lo(animdefs+13)
	addiu	$20,$20,%lo($LC0)
	b	$L9
	li	$19,-1			# 0xffffffffffffffff

$L15:
	jal	R_CheckTextureNumForName
	nop

	.set	noat
	xor	$1,$2,$19
	beq	$1,$0,$L5
	.set	at
	move	$4,$18

	jal	R_TextureNumForName
	lw	$22,%lo(lastanim)($17)

	sw	$2,4($22)
	lw	$21,%lo(lastanim)($17)
	jal	R_TextureNumForName
	move	$4,$16

	sw	$2,8($21)
	lw	$2,%lo(lastanim)($17)
	lw	$5,-13($16)
	lw	$4,8($2)
	lw	$3,4($2)
	sw	$5,0($2)
	subu	$3,$3,$4
	addiu	$3,$3,1
	slt	$4,$3,2
	bne	$4,$0,$L14
	sw	$3,12($2)

$L8:
	lw	$4,11($16)
	addiu	$3,$2,20
	sw	$4,16($2)
	sw	$3,%lo(lastanim)($17)
$L5:
	lw	$2,15($16)
	.set	noat
	xor	$1,$2,$19
	beq	$1,$0,$L1
	.set	at
	addiu	$16,$16,28

$L9:
	move	$4,$16
	bne	$2,$0,$L15
	addiu	$18,$16,-9

	jal	W_CheckNumForName
	nop

	.set	noat
	xor	$1,$2,$19
	beq	$1,$0,$L5
	.set	at
	move	$4,$18

	jal	R_FlatNumForName
	lw	$22,%lo(lastanim)($17)

	sw	$2,4($22)
	lw	$21,%lo(lastanim)($17)
	jal	R_FlatNumForName
	move	$4,$16

	sw	$2,8($21)
	lw	$2,%lo(lastanim)($17)
	lw	$5,-13($16)
	lw	$4,8($2)
	lw	$3,4($2)
	sw	$5,0($2)
	subu	$3,$3,$4
	addiu	$3,$3,1
	slt	$4,$3,2
	beq	$4,$0,$L8
	sw	$3,12($2)

$L14:
	move	$5,$16
	move	$6,$18
	jal	I_Error
	move	$4,$20

	b	$L8
	lw	$2,%lo(lastanim)($17)

$L1:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	P_InitPicAnims
	.size	P_InitPicAnims, .-P_InitPicAnims
	.align	2
	.globl	getSide
	.set	nomips16
	.set	nomicromips
	.ent	getSide
	.type	getSide, @function
getSide:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	lui	$3,%hi(sectors)
	lw	$3,%lo(sectors)($3)
	subu	$2,$2,$4
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,84($2)
	sll	$5,$5,2
	addu	$2,$2,$5
	lw	$2,0($2)
	addiu	$6,$6,8
	sll	$6,$6,1
	addu	$2,$2,$6
	lh	$3,6($2)
	lui	$4,%hi(sides)
	sll	$2,$3,2
	lw	$4,%lo(sides)($4)
	addu	$2,$2,$3
	sll	$2,$2,2
	jr	$31
	addu	$2,$4,$2

	.set	macro
	.set	reorder
	.end	getSide
	.size	getSide, .-getSide
	.align	2
	.globl	getSector
	.set	nomips16
	.set	nomicromips
	.ent	getSector
	.type	getSector, @function
getSector:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	lui	$3,%hi(sectors)
	lw	$3,%lo(sectors)($3)
	subu	$2,$2,$4
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,84($2)
	sll	$5,$5,2
	addu	$2,$2,$5
	lw	$2,0($2)
	addiu	$6,$6,8
	sll	$6,$6,1
	addu	$2,$2,$6
	lh	$4,6($2)
	lui	$3,%hi(sides)
	sll	$2,$4,2
	lw	$3,%lo(sides)($3)
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	jr	$31
	lw	$2,16($2)

	.set	macro
	.set	reorder
	.end	getSector
	.size	getSector, .-getSector
	.align	2
	.globl	twoSided
	.set	nomips16
	.set	nomicromips
	.ent	twoSided
	.type	twoSided, @function
twoSided:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	lui	$3,%hi(sectors)
	lw	$3,%lo(sectors)($3)
	subu	$2,$2,$4
	sll	$2,$2,3
	addu	$2,$3,$2
	lw	$2,84($2)
	sll	$5,$5,2
	addu	$2,$2,$5
	lw	$2,0($2)
	lhu	$2,16($2)
	jr	$31
	andi	$2,$2,0x4

	.set	macro
	.set	reorder
	.end	twoSided
	.size	twoSided, .-twoSided
	.align	2
	.globl	getNextSector
	.set	nomips16
	.set	nomicromips
	.ent	getNextSector
	.type	getNextSector, @function
getNextSector:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lhu	$2,16($4)
	andi	$2,$2,0x4
	beq	$2,$0,$L21
	nop

	lw	$2,48($4)
	.set	noat
	xor	$1,$2,$5
	beq	$1,$0,$L22
	.set	at
	nop

	jr	$31
	nop

$L22:
	jr	$31
	lw	$2,52($4)

$L21:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	getNextSector
	.size	getNextSector, .-getNextSector
	.align	2
	.globl	P_FindLowestFloorSurrounding
	.set	nomips16
	.set	nomicromips
	.ent	P_FindLowestFloorSurrounding
	.type	P_FindLowestFloorSurrounding, @function
P_FindLowestFloorSurrounding:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,80($4)
	blez	$7,$L35
	lw	$2,0($4)

	lw	$3,84($4)
	sll	$7,$7,2
	b	$L27
	addu	$7,$7,$3

$L26:
	beq	$5,$0,$L25
	nop

	lw	$5,0($5)
	slt	$6,$5,$2
	movn	$2,$5,$6
$L25:
	.set	noat
	xor	$1,$7,$3
	beq	$1,$0,$L35
	.set	at
	nop

$L27:
	lw	$6,0($3)
	lhu	$5,16($6)
	andi	$5,$5,0x4
	beq	$5,$0,$L25
	addiu	$3,$3,4

	lw	$5,48($6)
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L26
	.set	at
	nop

	b	$L26
	lw	$5,52($6)

$L35:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_FindLowestFloorSurrounding
	.size	P_FindLowestFloorSurrounding, .-P_FindLowestFloorSurrounding
	.align	2
	.globl	P_FindHighestFloorSurrounding
	.set	nomips16
	.set	nomicromips
	.ent	P_FindHighestFloorSurrounding
	.type	P_FindHighestFloorSurrounding, @function
P_FindHighestFloorSurrounding:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,80($4)
	blez	$7,$L41
	sll	$7,$7,2

	lw	$3,84($4)
	addu	$7,$7,$3
	b	$L40
	li	$2,-32768000			# 0xfffffffffe0c0000

$L39:
	beq	$5,$0,$L38
	nop

	lw	$5,0($5)
	slt	$6,$2,$5
	movn	$2,$5,$6
$L38:
	.set	noat
	xor	$1,$7,$3
	beq	$1,$0,$L50
	.set	at
	nop

$L40:
	lw	$6,0($3)
	lhu	$5,16($6)
	andi	$5,$5,0x4
	beq	$5,$0,$L38
	addiu	$3,$3,4

	lw	$5,48($6)
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L39
	.set	at
	nop

	b	$L39
	lw	$5,52($6)

$L50:
	jr	$31
	nop

$L41:
	jr	$31
	li	$2,-32768000			# 0xfffffffffe0c0000

	.set	macro
	.set	reorder
	.end	P_FindHighestFloorSurrounding
	.size	P_FindHighestFloorSurrounding, .-P_FindHighestFloorSurrounding
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Sector with more than 22 adjoining sectors. Vanilla will"
	.ascii	" crash here\000"
	.text
	.align	2
	.globl	P_FindNextHighestFloor
	.set	nomips16
	.set	nomicromips
	.ent	P_FindNextHighestFloor
	.type	P_FindNextHighestFloor, @function
P_FindNextHighestFloor:
	.frame	$sp,144,$31		# vars= 88, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-144
	sw	$19,120($sp)
	move	$19,$4
	lw	$4,80($4)
	sw	$18,116($sp)
	sw	$31,140($sp)
	sw	$23,136($sp)
	sw	$22,132($sp)
	sw	$21,128($sp)
	sw	$20,124($sp)
	sw	$17,112($sp)
	sw	$16,108($sp)
	blez	$4,$L57
	move	$18,$5

	move	$21,$5
	move	$20,$0
	move	$16,$0
	li	$22,21			# 0x15
	b	$L52
	li	$23,22			# 0x16

$L55:
	beq	$17,$0,$L54
	nop

	lw	$2,0($17)
	slt	$3,$21,$2
	beq	$3,$0,$L54
	nop

	.set	noat
	xor	$1,$20,$22
	beq	$1,$0,$L60
	.set	at
	nop

	.set	noat
	xor	$1,$20,$23
	beq	$1,$0,$L73
	.set	at
	nop

$L56:
	sll	$3,$20,2
	addiu	$5,$sp,16
	addu	$3,$5,$3
	sw	$2,0($3)
	addiu	$20,$20,1
$L54:
	addiu	$16,$16,1
	slt	$2,$16,$4
	beq	$2,$0,$L74
	nop

$L52:
	lw	$3,84($19)
	sll	$2,$16,2
	addu	$3,$3,$2
	lw	$6,0($3)
	lhu	$3,16($6)
	andi	$3,$3,0x4
	beq	$3,$0,$L54
	nop

	lw	$17,48($6)
	.set	noat
	xor	$1,$19,$17
	bne	$1,$0,$L55
	.set	at
	nop

	b	$L55
	lw	$17,52($6)

$L60:
	b	$L56
	move	$21,$2

$L74:
	beq	$20,$0,$L57
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$20,$3
	beq	$1,$0,$L51
	.set	at
	lw	$2,16($sp)

	sll	$20,$20,2
	addiu	$4,$sp,16
	addiu	$3,$sp,20
	addu	$6,$4,$20
$L58:
	lw	$4,0($3)
	addiu	$3,$3,4
	slt	$5,$4,$2
	.set	noat
	xor	$1,$6,$3
	bne	$1,$0,$L58
	.set	at
	movn	$2,$4,$5

$L51:
	lw	$31,140($sp)
	lw	$23,136($sp)
	lw	$22,132($sp)
	lw	$21,128($sp)
	lw	$20,124($sp)
	lw	$19,120($sp)
	lw	$18,116($sp)
	lw	$17,112($sp)
	lw	$16,108($sp)
	jr	$31
	addiu	$sp,$sp,144

$L73:
	lui	$4,%hi($LC1)
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	lw	$2,0($17)
	b	$L56
	lw	$4,80($19)

$L57:
	lw	$31,140($sp)
	lw	$23,136($sp)
	lw	$22,132($sp)
	lw	$21,128($sp)
	lw	$20,124($sp)
	lw	$19,120($sp)
	lw	$17,112($sp)
	lw	$16,108($sp)
	move	$2,$18
	lw	$18,116($sp)
	jr	$31
	addiu	$sp,$sp,144

	.set	macro
	.set	reorder
	.end	P_FindNextHighestFloor
	.size	P_FindNextHighestFloor, .-P_FindNextHighestFloor
	.align	2
	.globl	P_FindLowestCeilingSurrounding
	.set	nomips16
	.set	nomicromips
	.ent	P_FindLowestCeilingSurrounding
	.type	P_FindLowestCeilingSurrounding, @function
P_FindLowestCeilingSurrounding:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,80($4)
	blez	$7,$L80
	sll	$7,$7,2

	lw	$3,84($4)
	li	$2,2147418112			# 0x7fff0000
	addu	$7,$7,$3
	b	$L79
	ori	$2,$2,0xffff

$L78:
	beq	$5,$0,$L77
	nop

	lw	$5,4($5)
	slt	$6,$5,$2
	movn	$2,$5,$6
$L77:
	.set	noat
	xor	$1,$7,$3
	beq	$1,$0,$L89
	.set	at
	nop

$L79:
	lw	$6,0($3)
	lhu	$5,16($6)
	andi	$5,$5,0x4
	beq	$5,$0,$L77
	addiu	$3,$3,4

	lw	$5,48($6)
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L78
	.set	at
	nop

	b	$L78
	lw	$5,52($6)

$L89:
	jr	$31
	nop

$L80:
	li	$2,2147418112			# 0x7fff0000
	jr	$31
	ori	$2,$2,0xffff

	.set	macro
	.set	reorder
	.end	P_FindLowestCeilingSurrounding
	.size	P_FindLowestCeilingSurrounding, .-P_FindLowestCeilingSurrounding
	.align	2
	.globl	P_FindHighestCeilingSurrounding
	.set	nomips16
	.set	nomicromips
	.ent	P_FindHighestCeilingSurrounding
	.type	P_FindHighestCeilingSurrounding, @function
P_FindHighestCeilingSurrounding:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,80($4)
	blez	$7,$L95
	sll	$7,$7,2

	lw	$3,84($4)
	addu	$7,$7,$3
	b	$L94
	move	$2,$0

$L93:
	beq	$5,$0,$L92
	nop

	lw	$5,4($5)
	slt	$6,$2,$5
	movn	$2,$5,$6
$L92:
	.set	noat
	xor	$1,$7,$3
	beq	$1,$0,$L104
	.set	at
	nop

$L94:
	lw	$6,0($3)
	lhu	$5,16($6)
	andi	$5,$5,0x4
	beq	$5,$0,$L92
	addiu	$3,$3,4

	lw	$5,48($6)
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L93
	.set	at
	nop

	b	$L93
	lw	$5,52($6)

$L104:
	jr	$31
	nop

$L95:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	P_FindHighestCeilingSurrounding
	.size	P_FindHighestCeilingSurrounding, .-P_FindHighestCeilingSurrounding
	.align	2
	.globl	P_FindSectorFromLineTag
	.set	nomips16
	.set	nomicromips
	.ent	P_FindSectorFromLineTag
	.type	P_FindSectorFromLineTag, @function
P_FindSectorFromLineTag:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numsectors)
	lw	$6,%lo(numsectors)($2)
	addiu	$2,$5,1
	slt	$3,$2,$6
	beq	$3,$0,$L108
	sll	$3,$5,1

	addu	$3,$3,$5
	sll	$3,$3,2
	subu	$5,$3,$5
	lui	$3,%hi(sectors)
	lw	$3,%lo(sectors)($3)
	sll	$5,$5,3
	addiu	$5,$5,104
	lh	$7,20($4)
	b	$L107
	addu	$3,$3,$5

$L110:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L108
	.set	at
	nop

$L107:
	lh	$4,0($3)
	.set	noat
	xor	$1,$4,$7
	bne	$1,$0,$L110
	.set	at
	addiu	$3,$3,88

	jr	$31
	nop

$L108:
	jr	$31
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	P_FindSectorFromLineTag
	.size	P_FindSectorFromLineTag, .-P_FindSectorFromLineTag
	.align	2
	.globl	P_FindMinSurroundingLight
	.set	nomips16
	.set	nomicromips
	.ent	P_FindMinSurroundingLight
	.type	P_FindMinSurroundingLight, @function
P_FindMinSurroundingLight:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$8,80($4)
	blez	$8,$L124
	move	$2,$5

	lw	$3,84($4)
	sll	$8,$8,2
	b	$L115
	addu	$8,$8,$3

$L114:
	beq	$6,$0,$L113
	nop

	lh	$5,12($6)
	slt	$6,$5,$2
	movn	$2,$5,$6
$L113:
	.set	noat
	xor	$1,$8,$3
	beq	$1,$0,$L124
	.set	at
	nop

$L115:
	lw	$7,0($3)
	lhu	$6,16($7)
	andi	$6,$6,0x4
	beq	$6,$0,$L113
	addiu	$3,$3,4

	lw	$6,48($7)
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L114
	.set	at
	nop

	b	$L114
	lw	$6,52($7)

$L124:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_FindMinSurroundingLight
	.size	P_FindMinSurroundingLight, .-P_FindMinSurroundingLight
	.align	2
	.globl	P_CrossSpecialLine
	.set	nomips16
	.set	nomicromips
	.ent	P_CrossSpecialLine
	.type	P_CrossSpecialLine, @function
P_CrossSpecialLine:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	lui	$2,%hi(lines)
	lw	$7,132($6)
	sw	$16,16($sp)
	lw	$16,%lo(lines)($2)
	sll	$4,$4,6
	sw	$31,20($sp)
	beq	$7,$0,$L126
	addu	$16,$16,$4

	lh	$2,18($16)
	andi	$3,$2,0xffff
$L213:
	sltu	$3,$3,142
	beq	$3,$0,$L125
	lui	$3,%hi($L136)

	sll	$2,$2,2
	addiu	$3,$3,%lo($L136)
	addu	$2,$3,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L136:
	.word	$L125
	.word	$L125
	.word	$L202
	.word	$L201
	.word	$L133
	.word	$L200
	.word	$L199
	.word	$L125
	.word	$L198
	.word	$L125
	.word	$L131
	.word	$L125
	.word	$L197
	.word	$L196
	.word	$L125
	.word	$L125
	.word	$L195
	.word	$L194
	.word	$L125
	.word	$L193
	.word	$L125
	.word	$L125
	.word	$L192
	.word	$L125
	.word	$L125
	.word	$L191
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L190
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L189
	.word	$L188
	.word	$L187
	.word	$L204
	.word	$L205
	.word	$L185
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L184
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L183
	.word	$L182
	.word	$L181
	.word	$L125
	.word	$L180
	.word	$L179
	.word	$L178
	.word	$L177
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L176
	.word	$L175
	.word	$L174
	.word	$L173
	.word	$L172
	.word	$L171
	.word	$L125
	.word	$L170
	.word	$L169
	.word	$L168
	.word	$L167
	.word	$L166
	.word	$L165
	.word	$L125
	.word	$L164
	.word	$L163
	.word	$L129
	.word	$L162
	.word	$L161
	.word	$L160
	.word	$L159
	.word	$L158
	.word	$L157
	.word	$L156
	.word	$L155
	.word	$L210
	.word	$L154
	.word	$L125
	.word	$L153
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L152
	.word	$L151
	.word	$L150
	.word	$L149
	.word	$L148
	.word	$L147
	.word	$L146
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L145
	.word	$L144
	.word	$L143
	.word	$L125
	.word	$L125
	.word	$L142
	.word	$L141
	.word	$L140
	.word	$L125
	.word	$L139
	.word	$L138
	.word	$L137
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L125
	.word	$L135
	.text
$L126:
	lw	$2,88($6)
	li	$3,16			# 0x10
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L125
	.set	at
	addiu	$2,$2,-31

	sltu	$2,$2,5
	beq	$2,$0,$L212
	li	$3,88			# 0x58

$L125:
	lw	$31,20($sp)
$L214:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L212:
	lh	$2,18($16)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L129
	.set	at
	slt	$3,$2,89

	beq	$3,$0,$L130
	li	$3,10			# 0xa

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L131
	.set	at
	li	$3,39			# 0x27

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L205
	.set	at
	li	$3,4			# 0x4

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L214
	.set	at
	lw	$31,20($sp)

$L133:
	move	$5,$0
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L130:
	li	$3,97			# 0x61
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L210
	.set	at
	addiu	$3,$2,-125

	andi	$3,$3,0xffff
	sltu	$3,$3,2
	beq	$3,$0,$L214
	lw	$31,20($sp)

	b	$L213
	andi	$3,$2,0xffff

$L185:
	move	$4,$16
	jal	EV_DoCeiling
	li	$5,1			# 0x1

$L204:
	li	$5,1			# 0x1
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L146:
	li	$5,7			# 0x7
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L147:
	li	$5,6			# 0x6
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L148:
	li	$5,5			# 0x5
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L149:
	li	$5,7			# 0x7
$L207:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_DoDoor
	addiu	$sp,$sp,24

$L150:
	b	$L207
	li	$5,6			# 0x6

$L151:
	b	$L207
	li	$5,5			# 0x5

$L152:
	jal	EV_TurnTagLightsOff
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L153:
	li	$5,1			# 0x1
	jal	EV_BuildStairs
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L154:
	li	$5,2			# 0x2
$L208:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_DoFloor
	addiu	$sp,$sp,24

$L155:
	b	$L208
	li	$5,5			# 0x5

$L156:
	move	$6,$0
	li	$5,3			# 0x3
$L211:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_DoPlat
	addiu	$sp,$sp,24

$L157:
	b	$L208
	li	$5,9			# 0x9

$L158:
	b	$L208
	li	$5,8			# 0x8

$L159:
	b	$L208
	li	$5,7			# 0x7

$L160:
	b	$L208
	li	$5,3			# 0x3

$L161:
	b	$L207
	move	$5,$0

$L162:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_StopPlat
	addiu	$sp,$sp,24

$L163:
	move	$6,$0
	b	$L211
	move	$5,$0

$L164:
	b	$L207
	li	$5,3			# 0x3

$L165:
	b	$L208
	li	$5,6			# 0x6

$L166:
	b	$L208
	move	$5,$0

$L167:
	b	$L208
	li	$5,1			# 0x1

$L168:
	li	$5,255			# 0xff
$L209:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_LightTurnOn
	addiu	$sp,$sp,24

$L169:
	b	$L209
	move	$5,$0

$L170:
	b	$L209
	li	$5,35			# 0x23

$L171:
	li	$5,4			# 0x4
$L206:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_DoCeiling
	addiu	$sp,$sp,24

$L172:
	b	$L207
	li	$5,1			# 0x1

$L173:
	b	$L207
	li	$5,2			# 0x2

$L174:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_CeilingCrushStop
	addiu	$sp,$sp,24

$L175:
	b	$L206
	li	$5,3			# 0x3

$L176:
	b	$L206
	li	$5,2			# 0x2

$L177:
	li	$5,8			# 0x8
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L197:
	move	$5,$0
	jal	EV_LightTurnOn
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L198:
	move	$5,$0
	jal	EV_BuildStairs
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L199:
	li	$5,4			# 0x4
	jal	EV_DoCeiling
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L200:
	li	$5,3			# 0x3
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L201:
	li	$5,2			# 0x2
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L202:
	li	$5,3			# 0x3
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L135:
	li	$5,5			# 0x5
	jal	EV_DoCeiling
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L137:
	li	$5,10			# 0xa
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L138:
	b	$L208
	li	$5,10			# 0xa

$L139:
	b	$L208
	li	$5,4			# 0x4

$L140:
	bne	$7,$0,$L214
	lw	$31,20($sp)

$L210:
	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	EV_Teleport
	addiu	$sp,$sp,24

$L142:
	lw	$31,20($sp)
	lw	$16,16($sp)
	j	G_SecretExitLevel
	addiu	$sp,$sp,24

$L143:
	move	$6,$0
	li	$5,4			# 0x4
	jal	EV_DoPlat
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L144:
	move	$6,$0
	b	$L211
	li	$5,4			# 0x4

$L145:
	li	$5,4			# 0x4
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L189:
	li	$5,35			# 0x23
	jal	EV_LightTurnOn
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L190:
	li	$5,5			# 0x5
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L141:
	bne	$7,$0,$L214
	lw	$31,20($sp)

$L205:
	jal	EV_Teleport
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L191:
	li	$5,3			# 0x3
	jal	EV_DoCeiling
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L192:
	move	$6,$0
	li	$5,3			# 0x3
	jal	EV_DoPlat
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L193:
	move	$5,$0
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L194:
	jal	EV_StartLightStrobing
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L195:
	li	$5,1			# 0x1
	jal	EV_DoDoor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L196:
	li	$5,255			# 0xff
	jal	EV_LightTurnOn
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L178:
	li	$5,7			# 0x7
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L179:
	jal	EV_CeilingCrushStop
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L180:
	li	$5,9			# 0x9
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L181:
	jal	EV_StopPlat
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L182:
	move	$6,$0
	move	$5,$0
	jal	EV_DoPlat
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L183:
	lw	$31,20($sp)
	lw	$16,16($sp)
	j	G_ExitLevel
	addiu	$sp,$sp,24

$L184:
	li	$5,2			# 0x2
	jal	EV_DoCeiling
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L187:
	li	$5,6			# 0x6
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L188:
	li	$5,2			# 0x2
	jal	EV_DoFloor
	move	$4,$16

	b	$L125
	sh	$0,18($16)

$L129:
	move	$6,$0
	b	$L211
	li	$5,1			# 0x1

$L131:
	move	$6,$0
	li	$5,1			# 0x1
	jal	EV_DoPlat
	move	$4,$16

	b	$L125
	sh	$0,18($16)

	.set	macro
	.set	reorder
	.end	P_CrossSpecialLine
	.size	P_CrossSpecialLine, .-P_CrossSpecialLine
	.align	2
	.globl	P_ShootSpecialLine
	.set	nomips16
	.set	nomicromips
	.ent	P_ShootSpecialLine
	.type	P_ShootSpecialLine, @function
P_ShootSpecialLine:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,132($4)
	addiu	$sp,$sp,-24
	lh	$2,18($5)
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$3,$0,$L223
	move	$16,$5

	li	$3,46			# 0x2e
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L217
	.set	at
	li	$3,47			# 0x2f

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L219
	.set	at
	li	$3,24			# 0x18

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L224
	.set	at
	lw	$31,20($sp)

$L226:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L219:
	li	$5,3			# 0x3
	move	$4,$16
	jal	EV_DoPlat
	move	$6,$0

	lw	$31,20($sp)
$L225:
	move	$4,$16
	lw	$16,16($sp)
	move	$5,$0
	j	P_ChangeSwitchTexture
	addiu	$sp,$sp,24

$L224:
	li	$5,3			# 0x3
	jal	EV_DoFloor
	move	$4,$16

	b	$L225
	lw	$31,20($sp)

$L223:
	li	$3,46			# 0x2e
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L226
	.set	at
	lw	$31,20($sp)

$L217:
	move	$4,$16
	jal	EV_DoDoor
	li	$5,3			# 0x3

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	li	$5,1			# 0x1
	j	P_ChangeSwitchTexture
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	P_ShootSpecialLine
	.size	P_ShootSpecialLine, .-P_ShootSpecialLine
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"P_PlayerInSpecialSector: unknown special %i\000"
	.text
	.align	2
	.globl	P_PlayerInSpecialSector
	.set	nomips16
	.set	nomicromips
	.ent	P_PlayerInSpecialSector
	.type	P_PlayerInSpecialSector, @function
P_PlayerInSpecialSector:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,0($4)
	sw	$31,20($sp)
	lw	$2,52($4)
	lw	$5,20($4)
	lw	$3,0($2)
	lw	$2,0($3)
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L227
	.set	at
	nop

	lh	$5,14($3)
	addiu	$2,$5,-4
	andi	$2,$2,0xffff
	sltu	$6,$2,13
	beq	$6,$0,$L230
	lui	$6,%hi($L232)

	sll	$2,$2,2
	addiu	$6,$6,%lo($L232)
	addu	$2,$6,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L232:
	.word	$L231
	.word	$L236
	.word	$L230
	.word	$L235
	.word	$L230
	.word	$L234
	.word	$L230
	.word	$L233
	.word	$L230
	.word	$L230
	.word	$L230
	.word	$L230
	.word	$L231
	.text
$L234:
	lw	$2,220($16)
	addiu	$2,$2,1
	sw	$2,220($16)
	sh	$0,14($3)
$L227:
	lw	$31,20($sp)
$L246:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L230:
	lw	$31,20($sp)
	lw	$16,16($sp)
	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	j	I_Error
	addiu	$sp,$sp,24

$L231:
	lw	$2,64($16)
	bne	$2,$0,$L238
	lui	$2,%hi(leveltime)

$L247:
	lw	$2,%lo(leveltime)($2)
	andi	$2,$2,0x1f
	bne	$2,$0,$L246
	lw	$31,20($sp)

	lw	$4,0($16)
	b	$L248
	li	$7,20			# 0x14

$L233:
	lui	$2,%hi(leveltime)
	lw	$3,204($16)
	lw	$2,%lo(leveltime)($2)
	li	$5,-3			# 0xfffffffffffffffd
	and	$3,$3,$5
	andi	$2,$2,0x1f
	beq	$2,$0,$L244
	sw	$3,204($16)

	lw	$2,40($16)
$L245:
	slt	$2,$2,11
	beq	$2,$0,$L246
	lw	$31,20($sp)

	lw	$16,16($sp)
	j	G_ExitLevel
	addiu	$sp,$sp,24

$L236:
	lui	$2,%hi(leveltime)
	lw	$2,%lo(leveltime)($2)
	lw	$3,64($16)
	andi	$2,$2,0x1f
	or	$2,$2,$3
	bne	$2,$0,$L246
	lw	$31,20($sp)

	b	$L249
	li	$7,10			# 0xa

$L235:
	lui	$2,%hi(leveltime)
	lw	$2,%lo(leveltime)($2)
	lw	$3,64($16)
	andi	$2,$2,0x1f
	or	$2,$2,$3
	bne	$2,$0,$L246
	lw	$31,20($sp)

	li	$7,5			# 0x5
$L248:
$L249:
	lw	$16,16($sp)
	move	$6,$0
	move	$5,$0
	j	P_DamageMobj
	addiu	$sp,$sp,24

$L244:
	li	$7,20			# 0x14
	move	$6,$0
	jal	P_DamageMobj
	move	$5,$0

	b	$L245
	lw	$2,40($16)

$L238:
	jal	P_Random
	nop

	slt	$2,$2,5
	bne	$2,$0,$L247
	lui	$2,%hi(leveltime)

	b	$L246
	lw	$31,20($sp)

	.set	macro
	.set	reorder
	.end	P_PlayerInSpecialSector
	.size	P_PlayerInSpecialSector, .-P_PlayerInSpecialSector
	.align	2
	.globl	P_UpdateSpecials
	.set	nomips16
	.set	nomicromips
	.ent	P_UpdateSpecials
	.type	P_UpdateSpecials, @function
P_UpdateSpecials:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(levelTimer)
	lw	$3,%lo(levelTimer)($2)
	addiu	$sp,$sp,-40
	li	$2,1			# 0x1
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L278
	.set	at
	sw	$16,16($sp)

$L252:
	lui	$2,%hi(lastanim)
$L283:
	lw	$12,%lo(lastanim)($2)
	lui	$3,%hi(anims)
	addiu	$3,$3,%lo(anims)
	sltu	$2,$3,$12
	beq	$2,$0,$L259
	lui	$2,%hi(flattranslation)

	lw	$14,%lo(flattranslation)($2)
	lui	$2,%hi(texturetranslation)
	lw	$13,%lo(texturetranslation)($2)
	lui	$11,%hi(leveltime)
$L258:
	lw	$4,12($3)
	blez	$4,$L263
	lw	$7,8($3)

	sll	$8,$7,2
	addu	$9,$13,$8
	move	$5,$7
	b	$L262
	addu	$8,$14,$8

$L279:
	sw	$2,0($9)
	lw	$7,8($3)
	lw	$4,12($3)
	addiu	$5,$5,1
	addu	$2,$7,$4
	slt	$2,$5,$2
	addiu	$9,$9,4
	beq	$2,$0,$L263
	addiu	$8,$8,4

$L262:
	lw	$2,%lo(leveltime)($11)
	lw	$6,16($3)
	lw	$10,0($3)
	div	$0,$2,$6
	mflo	$2
	addu	$2,$2,$5
	div	$0,$2,$4
	mfhi	$2
	bne	$10,$0,$L279
	addu	$2,$2,$7

	sw	$2,0($8)
	lw	$7,8($3)
	lw	$4,12($3)
	addiu	$5,$5,1
	addu	$2,$7,$4
	slt	$2,$5,$2
	addiu	$9,$9,4
	bne	$2,$0,$L262
	addiu	$8,$8,4

$L263:
	addiu	$3,$3,20
	sltu	$2,$3,$12
	bne	$2,$0,$L258
	nop

$L259:
	lui	$2,%hi(numlinespecials)
	lh	$3,%lo(numlinespecials)($2)
	blez	$3,$L256
	lui	$2,%hi(linespeciallist)

	lui	$4,%hi(sides)
	addiu	$2,$2,%lo(linespeciallist)
	sll	$3,$3,2
	lw	$8,%lo(sides)($4)
	addu	$5,$3,$2
	li	$6,48			# 0x30
	li	$7,65536			# 0x10000
$L266:
	lw	$3,0($2)
	lh	$4,18($3)
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L265
	.set	at
	addiu	$2,$2,4

	lh	$4,22($3)
	sll	$3,$4,2
	addu	$3,$3,$4
	sll	$3,$3,2
	addu	$3,$8,$3
	lw	$4,0($3)
	addu	$4,$4,$7
	sw	$4,0($3)
$L265:
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L266
	.set	at
	nop

$L256:
	lui	$16,%hi(buttonlist)
	addiu	$16,$16,%lo(buttonlist)
	addiu	$17,$16,320
	li	$19,1			# 0x1
	lui	$20,%hi(sides)
	b	$L264
	li	$18,2			# 0x2

$L282:
	beq	$2,$0,$L280
	lw	$3,%lo(sides)($20)

$L272:
	addiu	$4,$16,16
	jal	S_StartSound
	li	$5,23			# 0x17

	move	$4,$16
	li	$6,20			# 0x14
	jal	memset
	move	$5,$0

$L268:
	addiu	$16,$16,20
	.set	noat
	xor	$1,$17,$16
	beq	$1,$0,$L281
	.set	at
	lw	$31,36($sp)

$L264:
	lw	$2,12($16)
	beq	$2,$0,$L268
	addiu	$3,$2,-1

	bne	$3,$0,$L268
	sw	$3,12($16)

	lw	$2,4($16)
	.set	noat
	xor	$1,$2,$19
	beq	$1,$0,$L270
	.set	at
	lw	$3,%lo(sides)($20)

	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L282
	.set	at
	nop

	lw	$2,0($16)
	lh	$4,22($2)
	lw	$5,8($16)
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	b	$L272
	sh	$5,10($2)

$L280:
	lw	$2,0($16)
	lh	$4,22($2)
	lw	$5,8($16)
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	b	$L272
	sh	$5,8($2)

$L270:
	lw	$2,0($16)
	lh	$4,22($2)
	lw	$5,8($16)
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	b	$L272
	sh	$5,12($2)

$L281:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L278:
	lui	$3,%hi(levelTimeCount)
	lw	$2,%lo(levelTimeCount)($3)
	addiu	$2,$2,-1
	bne	$2,$0,$L252
	sw	$2,%lo(levelTimeCount)($3)

	jal	G_ExitLevel
	nop

	b	$L283
	lui	$2,%hi(lastanim)

	.set	macro
	.set	reorder
	.end	P_UpdateSpecials
	.size	P_UpdateSpecials, .-P_UpdateSpecials
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"EV_DoDonut: linedef had no second sidedef! Unexpected be"
	.ascii	"havior may occur in Vanilla Doom. \012\000"
	.align	2
$LC4:
	.ascii	"EV_DoDonut: WARNING: emulating buffer overrun due to NUL"
	.ascii	"L back sector. Unexpected behavior may occur in Vanilla "
	.ascii	"Doom.\012\000"
	.align	2
$LC5:
	.ascii	"-donut\000"
	.align	2
$LC6:
	.ascii	"DonutOverrun: The second parameter for \"-donut\" switch"
	.ascii	" should be greater than 0 and less than number of flats "
	.ascii	"(%d). Using default value (%d) instead. \012\000"
	.text
	.align	2
	.globl	EV_DoDonut
	.set	nomips16
	.set	nomicromips
	.ent	EV_DoDonut
	.type	EV_DoDonut, @function
EV_DoDonut:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$18,40($sp)
	lui	$18,%hi(T_MoveFloor)
	addiu	$3,$18,%lo(T_MoveFloor)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$16,32($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$17,36($sp)
	move	$21,$4
	move	$2,$0
	li	$16,-1			# 0xffffffffffffffff
	lui	$20,%hi(numsectors)
	lui	$19,%hi(sectors)
	sw	$3,16($sp)
$L285:
	lw	$5,%lo(numsectors)($20)
	addiu	$16,$16,1
	slt	$3,$16,$5
	beq	$3,$0,$L317
	lw	$31,68($sp)

	sll	$3,$16,1
$L319:
	addu	$3,$3,$16
	sll	$3,$3,2
	lw	$17,%lo(sectors)($19)
	subu	$3,$3,$16
	sll	$3,$3,3
	lh	$6,20($21)
	b	$L302
	addu	$17,$17,$3

$L311:
	.set	noat
	xor	$1,$5,$16
	beq	$1,$0,$L284
	.set	at
	addiu	$17,$17,88

$L302:
	lh	$3,16($17)
	.set	noat
	xor	$1,$3,$6
	bne	$1,$0,$L311
	.set	at
	addiu	$16,$16,1

	lw	$3,76($17)
	bne	$3,$0,$L285
	addiu	$16,$16,-1

	lw	$2,84($17)
	lw	$4,0($2)
	lhu	$2,16($4)
	andi	$2,$2,0x4
	beq	$2,$0,$L286
	nop

	lw	$18,48($4)
	.set	noat
	xor	$1,$18,$17
	beq	$1,$0,$L312
	.set	at
	nop

$L287:
	beq	$18,$0,$L318
	lui	$2,%hi(stderr)

	lw	$5,80($18)
	blez	$5,$L292
	move	$6,$0

	lw	$4,84($18)
$L291:
	lw	$2,0($4)
	lw	$2,52($2)
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L313
	.set	at
	addiu	$6,$6,1

	beq	$2,$0,$L314
	lui	$22,%hi(stderr)

	lw	$22,0($2)
	lh	$7,8($2)
$L298:
	move	$6,$0
	li	$5,6			# 0x6
	li	$4,44			# 0x2c
	jal	Z_Malloc
	sw	$7,20($sp)

	move	$4,$2
	jal	P_AddThinker
	move	$23,$2

	lw	$7,20($sp)
	lw	$2,16($sp)
	li	$3,11			# 0xb
	sw	$23,76($18)
	li	$fp,32768			# 0x8000
	sw	$3,12($23)
	li	$3,1			# 0x1
	sw	$3,24($23)
	sh	$7,32($23)
	move	$6,$0
	sw	$2,8($23)
	sw	$18,20($23)
	sw	$fp,40($23)
	sw	$22,36($23)
	li	$5,6			# 0x6
	li	$4,44			# 0x2c
	sw	$0,16($23)
	jal	Z_Malloc
	sw	$0,28($23)

	move	$4,$2
	jal	P_AddThinker
	move	$23,$2

	lw	$2,16($sp)
	sw	$23,76($17)
	sw	$2,8($23)
	li	$2,-1			# 0xffffffffffffffff
	sw	$0,12($23)
	sw	$0,16($23)
	sw	$2,24($23)
	sw	$17,20($23)
	sw	$fp,40($23)
	sw	$22,36($23)
$L292:
	li	$2,1			# 0x1
$L316:
	lw	$5,%lo(numsectors)($20)
	addiu	$16,$16,1
	slt	$3,$16,$5
	bne	$3,$0,$L319
	sll	$3,$16,1

$L284:
	lw	$31,68($sp)
$L317:
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L286:
	lui	$2,%hi(stderr)
$L318:
	lw	$4,%lo(stderr)($2)
	lui	$5,%hi($LC3)
	jal	fprintf
	addiu	$5,$5,%lo($LC3)

	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,72

$L313:
	.set	noat
	xor	$1,$5,$6
	bne	$1,$0,$L291
	.set	at
	addiu	$4,$4,4

	b	$L316
	li	$2,1			# 0x1

$L312:
	b	$L287
	lw	$18,52($4)

$L314:
	lw	$4,%lo(stderr)($22)
	lui	$5,%hi($LC4)
	jal	fprintf
	addiu	$5,$5,%lo($LC4)

	lui	$2,%hi(first.2)
	lw	$4,%lo(first.2)($2)
	bne	$4,$0,$L294
	lui	$fp,%hi(tmp_s3_floorheight.1)

	lui	$2,%hi(tmp_s3_floorpic.0)
	lh	$7,%lo(tmp_s3_floorpic.0)($2)
	b	$L298
	lw	$22,%lo(tmp_s3_floorheight.1)($fp)

$L294:
	lui	$4,%hi($LC5)
	lui	$23,%hi(tmp_s3_floorpic.0)
	sw	$0,%lo(first.2)($2)
	li	$5,2			# 0x2
	li	$2,22			# 0x16
	addiu	$4,$4,%lo($LC5)
	sw	$0,%lo(tmp_s3_floorheight.1)($fp)
	jal	M_CheckParmWithArgs
	sw	$2,%lo(tmp_s3_floorpic.0)($23)

	bgtz	$2,$L296
	lh	$7,%lo(tmp_s3_floorpic.0)($23)

	b	$L298
	lw	$22,%lo(tmp_s3_floorheight.1)($fp)

$L296:
	lui	$7,%hi(myargv)
	lw	$4,%lo(myargv)($7)
	addiu	$2,$2,1
	sll	$6,$2,2
	addu	$2,$4,$6
	lw	$4,0($2)
	addiu	$5,$fp,%lo(tmp_s3_floorheight.1)
	sw	$7,24($sp)
	jal	M_StrToInt
	sw	$6,20($sp)

	lw	$7,24($sp)
	lw	$6,20($sp)
	lw	$2,%lo(myargv)($7)
	addiu	$5,$23,%lo(tmp_s3_floorpic.0)
	addu	$2,$2,$6
	jal	M_StrToInt
	lw	$4,4($2)

	lui	$2,%hi(numflats)
	lw	$7,%lo(tmp_s3_floorpic.0)($23)
	lw	$6,%lo(numflats)($2)
	slt	$2,$7,$6
	beq	$2,$0,$L297
	lw	$4,%lo(stderr)($22)

	sll	$7,$7,16
	lw	$22,%lo(tmp_s3_floorheight.1)($fp)
	b	$L298
	sra	$7,$7,16

$L297:
	lui	$5,%hi($LC6)
	li	$7,22			# 0x16
	jal	fprintf
	addiu	$5,$5,%lo($LC6)

	li	$2,22			# 0x16
	lw	$22,%lo(tmp_s3_floorheight.1)($fp)
	sw	$2,%lo(tmp_s3_floorpic.0)($23)
	b	$L298
	li	$7,22			# 0x16

	.set	macro
	.set	reorder
	.end	EV_DoDonut
	.size	EV_DoDonut, .-EV_DoDonut
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"Too many scrolling wall linedefs! (Vanilla limit is 64)\000"
	.text
	.align	2
	.globl	P_SpawnSpecials
	.set	nomips16
	.set	nomicromips
	.ent	P_SpawnSpecials
	.type	P_SpawnSpecials, @function
P_SpawnSpecials:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(timelimit)
	lw	$2,%lo(timelimit)($2)
	addiu	$sp,$sp,-56
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$22,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	blez	$2,$L345
	sw	$16,20($sp)

	lui	$3,%hi(deathmatch)
	lw	$3,%lo(deathmatch)($3)
	bne	$3,$0,$L358
	li	$3,2100			# 0x834

$L345:
	move	$4,$0
$L321:
	lui	$19,%hi(numsectors)
	lui	$3,%hi(sectors)
	lw	$2,%lo(numsectors)($19)
	lw	$16,%lo(sectors)($3)
	lui	$3,%hi(levelTimer)
	sw	$4,%lo(levelTimer)($3)
	blez	$2,$L338
	move	$17,$0

	lui	$18,%hi($L327)
	addiu	$18,$18,%lo($L327)
$L322:
	lh	$2,14($16)
	beq	$2,$0,$L325
	andi	$3,$2,0xffff

	sltu	$3,$3,18
	beq	$3,$0,$L325
	sll	$2,$2,2

	addu	$2,$18,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L327:
	.word	$L325
	.word	$L337
	.word	$L336
	.word	$L335
	.word	$L334
	.word	$L325
	.word	$L325
	.word	$L325
	.word	$L333
	.word	$L332
	.word	$L331
	.word	$L325
	.word	$L330
	.word	$L329
	.word	$L328
	.word	$L325
	.word	$L325
	.word	$L326
	.text
$L337:
	jal	P_SpawnLightFlash
	move	$4,$16

$L325:
	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

$L338:
	lui	$19,%hi(numlines)
$L360:
	lw	$2,%lo(numlines)($19)
	lui	$22,%hi(numlinespecials)
	blez	$2,$L324
	sh	$0,%lo(numlinespecials)($22)

	lui	$23,%hi(linespeciallist)
	lui	$17,%hi($LC7)
	move	$16,$0
	lui	$20,%hi(lines)
	li	$21,48			# 0x30
	addiu	$23,$23,%lo(linespeciallist)
	b	$L323
	addiu	$17,$17,%lo($LC7)

$L340:
	lw	$2,%lo(numlines)($19)
	addiu	$16,$16,1
	slt	$2,$16,$2
	beq	$2,$0,$L361
	lui	$2,%hi(activeceilings)

$L323:
	lw	$2,%lo(lines)($20)
	sll	$18,$16,6
	addu	$2,$2,$18
	lh	$3,18($2)
	.set	noat
	xor	$1,$3,$21
	bne	$1,$0,$L340
	.set	at
	lh	$3,%lo(numlinespecials)($22)

	slt	$4,$3,64
	beq	$4,$0,$L359
	nop

$L341:
	sll	$4,$3,2
	addu	$4,$4,$23
	sw	$2,0($4)
	lw	$2,%lo(numlines)($19)
	addiu	$16,$16,1
	addiu	$3,$3,1
	slt	$2,$16,$2
	bne	$2,$0,$L323
	sh	$3,%lo(numlinespecials)($22)

$L324:
	lui	$2,%hi(activeceilings)
$L361:
	addiu	$2,$2,%lo(activeceilings)
	addiu	$3,$2,120
$L339:
	sw	$0,0($2)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L339
	.set	at
	nop

	lui	$2,%hi(activeplats)
	addiu	$2,$2,%lo(activeplats)
	addiu	$3,$2,120
$L342:
	sw	$0,0($2)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L342
	.set	at
	nop

	lui	$16,%hi(buttonlist)
	addiu	$16,$16,%lo(buttonlist)
	addiu	$17,$16,320
	move	$4,$16
$L362:
	li	$6,20			# 0x14
	addiu	$16,$16,20
	jal	memset
	move	$5,$0

	.set	noat
	xor	$1,$17,$16
	bne	$1,$0,$L362
	.set	at
	move	$4,$16

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L359:
	jal	I_Error
	move	$4,$17

	lw	$2,%lo(lines)($20)
	lh	$3,%lo(numlinespecials)($22)
	b	$L341
	addu	$2,$2,$18

$L326:
	jal	P_SpawnFireFlicker
	move	$4,$16

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L328:
	move	$5,$17
	jal	P_SpawnDoorRaiseIn5Mins
	move	$4,$16

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L329:
	move	$4,$16
	li	$6,1			# 0x1
	jal	P_SpawnStrobeFlash
	li	$5,15			# 0xf

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L330:
	move	$4,$16
	li	$6,1			# 0x1
	jal	P_SpawnStrobeFlash
	li	$5,35			# 0x23

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L331:
	jal	P_SpawnDoorCloseIn30
	move	$4,$16

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L332:
	lui	$3,%hi(totalsecret)
	lw	$2,%lo(totalsecret)($3)
	addiu	$17,$17,1
	addiu	$2,$2,1
	sw	$2,%lo(totalsecret)($3)
	lw	$2,%lo(numsectors)($19)
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L333:
	jal	P_SpawnGlowingLight
	move	$4,$16

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L334:
	move	$4,$16
	move	$6,$0
	jal	P_SpawnStrobeFlash
	li	$5,15			# 0xf

	li	$2,4			# 0x4
	sh	$2,14($16)
	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L335:
	move	$4,$16
	move	$6,$0
	jal	P_SpawnStrobeFlash
	li	$5,35			# 0x23

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L336:
	move	$4,$16
	move	$6,$0
	jal	P_SpawnStrobeFlash
	li	$5,15			# 0xf

	lw	$2,%lo(numsectors)($19)
	addiu	$17,$17,1
	slt	$2,$17,$2
	bne	$2,$0,$L322
	addiu	$16,$16,88

	b	$L360
	lui	$19,%hi(numlines)

$L358:
	multu	$2,$3
	mflo	$2
	lui	$3,%hi(levelTimeCount)
	sw	$2,%lo(levelTimeCount)($3)
	b	$L321
	li	$4,1			# 0x1

	.set	macro
	.set	reorder
	.end	P_SpawnSpecials
	.size	P_SpawnSpecials, .-P_SpawnSpecials
	.local	tmp_s3_floorpic.0
	.comm	tmp_s3_floorpic.0,4,4
	.local	tmp_s3_floorheight.1
	.comm	tmp_s3_floorheight.1,4,4
	.data
	.align	2
	.type	first.2, @object
	.size	first.2, 4
first.2:
	.word	1
	.globl	linespeciallist
	.section	.bss,"aw",@nobits
	.align	2
	.type	linespeciallist, @object
	.size	linespeciallist, 256
linespeciallist:
	.space	256
	.globl	numlinespecials
	.align	1
	.type	numlinespecials, @object
	.size	numlinespecials, 2
numlinespecials:
	.space	2
	.globl	levelTimeCount
	.align	2
	.type	levelTimeCount, @object
	.size	levelTimeCount, 4
levelTimeCount:
	.space	4
	.globl	levelTimer
	.align	2
	.type	levelTimer, @object
	.size	levelTimer, 4
levelTimer:
	.space	4
	.globl	lastanim
	.align	2
	.type	lastanim, @object
	.size	lastanim, 4
lastanim:
	.space	4
	.globl	anims
	.align	2
	.type	anims, @object
	.size	anims, 640
anims:
	.space	640
	.globl	animdefs
	.data
	.align	2
	.type	animdefs, @object
	.size	animdefs, 644
animdefs:
	.word	0
	.ascii	"NUKAGE3\000"
	.space	1
	.ascii	"NUKAGE1\000"
	.space	1
	.space	2
	.word	8
	.word	0
	.ascii	"FWATER4\000"
	.space	1
	.ascii	"FWATER1\000"
	.space	1
	.space	2
	.word	8
	.word	0
	.ascii	"SWATER4\000"
	.space	1
	.ascii	"SWATER1\000"
	.space	1
	.space	2
	.word	8
	.word	0
	.ascii	"LAVA4\000"
	.space	3
	.ascii	"LAVA1\000"
	.space	3
	.space	2
	.word	8
	.word	0
	.ascii	"BLOOD3\000"
	.space	2
	.ascii	"BLOOD1\000"
	.space	2
	.space	2
	.word	8
	.word	0
	.ascii	"RROCK08\000"
	.space	1
	.ascii	"RROCK05\000"
	.space	1
	.space	2
	.word	8
	.word	0
	.ascii	"SLIME04\000"
	.space	1
	.ascii	"SLIME01\000"
	.space	1
	.space	2
	.word	8
	.word	0
	.ascii	"SLIME08\000"
	.space	1
	.ascii	"SLIME05\000"
	.space	1
	.space	2
	.word	8
	.word	0
	.ascii	"SLIME12\000"
	.space	1
	.ascii	"SLIME09\000"
	.space	1
	.space	2
	.word	8
	.word	1
	.ascii	"BLODGR4\000"
	.space	1
	.ascii	"BLODGR1\000"
	.space	1
	.space	2
	.word	8
	.word	1
	.ascii	"SLADRIP3\000"
	.ascii	"SLADRIP1\000"
	.space	2
	.word	8
	.word	1
	.ascii	"BLODRIP4\000"
	.ascii	"BLODRIP1\000"
	.space	2
	.word	8
	.word	1
	.ascii	"FIREWALL\000"
	.ascii	"FIREWALA\000"
	.space	2
	.word	8
	.word	1
	.ascii	"GSTFONT3\000"
	.ascii	"GSTFONT1\000"
	.space	2
	.word	8
	.word	1
	.ascii	"FIRELAVA\000"
	.ascii	"FIRELAV3\000"
	.space	2
	.word	8
	.word	1
	.ascii	"FIREMAG3\000"
	.ascii	"FIREMAG1\000"
	.space	2
	.word	8
	.word	1
	.ascii	"FIREBLU2\000"
	.ascii	"FIREBLU1\000"
	.space	2
	.word	8
	.word	1
	.ascii	"ROCKRED3\000"
	.ascii	"ROCKRED1\000"
	.space	2
	.word	8
	.word	1
	.ascii	"BFALL4\000"
	.space	2
	.ascii	"BFALL1\000"
	.space	2
	.space	2
	.word	8
	.word	1
	.ascii	"SFALL4\000"
	.space	2
	.ascii	"SFALL1\000"
	.space	2
	.space	2
	.word	8
	.word	1
	.ascii	"WFALL4\000"
	.space	2
	.ascii	"WFALL1\000"
	.space	2
	.space	2
	.word	8
	.word	1
	.ascii	"DBRAIN4\000"
	.space	1
	.ascii	"DBRAIN1\000"
	.space	1
	.space	2
	.word	8
	.word	-1
	.ascii	"\000"
	.space	8
	.ascii	"\000"
	.space	8
	.space	2
	.word	0
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
