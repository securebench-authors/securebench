	.file	1 "p_switch.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_InitSwitchList
	.set	nomips16
	.set	nomicromips
	.ent	P_InitSwitchList
	.type	P_InitSwitchList, @function
P_InitSwitchList:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,-3			# 0xfffffffffffffffd
	addiu	$sp,$sp,-40
	and	$2,$3,$2
	li	$4,1			# 0x1
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L7
	.set	at
	sw	$16,16($sp)

	lui	$16,%hi(alphSwitchList)
	addiu	$16,$16,%lo(alphSwitchList)
	lh	$2,18($16)
	xori	$3,$3,0x2
	li	$20,3			# 0x3
	beq	$2,$0,$L13
	movn	$20,$4,$3

$L3:
	lui	$19,%hi(switchlist)
	move	$17,$0
	b	$L5
	addiu	$19,$19,%lo(switchlist)

$L4:
	lh	$2,38($16)
	beq	$2,$0,$L14
	addiu	$16,$16,20

$L5:
	slt	$2,$20,$2
	bne	$2,$0,$L4
	nop

	jal	R_TextureNumForName
	move	$4,$16

	addiu	$18,$17,1
	sll	$3,$17,2
	addu	$3,$19,$3
	addiu	$4,$16,9
	sll	$18,$18,2
	sw	$2,0($3)
	jal	R_TextureNumForName
	addu	$18,$19,$18

	sw	$2,0($18)
	lh	$2,38($16)
	addiu	$17,$17,2
	bne	$2,$0,$L5
	addiu	$16,$16,20

$L14:
	lw	$31,36($sp)
	sra	$3,$17,1
	lui	$2,%hi(numswitches)
	sll	$17,$17,2
	addu	$17,$19,$17
	sw	$3,%lo(numswitches)($2)
	li	$2,-1			# 0xffffffffffffffff
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$2,0($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L7:
	lui	$16,%hi(alphSwitchList)
	addiu	$16,$16,%lo(alphSwitchList)
	lh	$2,18($16)
	bne	$2,$0,$L3
	li	$20,2			# 0x2

$L13:
	move	$17,$0
	lui	$19,%hi(switchlist)
	lw	$31,36($sp)
	addiu	$19,$19,%lo(switchlist)
	lui	$2,%hi(numswitches)
	move	$3,$0
	sll	$17,$17,2
	addu	$17,$19,$17
	sw	$3,%lo(numswitches)($2)
	li	$2,-1			# 0xffffffffffffffff
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$2,0($17)
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_InitSwitchList
	.size	P_InitSwitchList, .-P_InitSwitchList
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"P_StartButton: no button slots left!\000"
	.text
	.align	2
	.globl	P_StartButton
	.set	nomips16
	.set	nomicromips
	.ent	P_StartButton
	.type	P_StartButton, @function
P_StartButton:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$9,%hi(buttonlist)
	addiu	$9,$9,%lo(buttonlist)
	move	$2,$9
	addiu	$8,$9,320
$L18:
	lw	$3,12($2)
	beq	$3,$0,$L16
	nop

	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L27
	.set	at
	nop

$L16:
	addiu	$2,$2,20
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L18
	.set	at
	move	$3,$0

	lui	$2,%hi(buttonlist+12)
	addiu	$2,$2,%lo(buttonlist+12)
	li	$10,16			# 0x10
$L20:
	lw	$8,0($2)
	beq	$8,$0,$L26
	addiu	$2,$2,20

	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$10
	bne	$1,$0,$L20
	.set	at
	nop

	lui	$4,%hi($LC0)
	j	I_Error
	addiu	$4,$4,%lo($LC0)

$L27:
	jr	$31
	nop

$L26:
	sll	$2,$3,2
	lw	$8,48($4)
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$9,$9,$2
	addiu	$2,$8,44
	sw	$4,0($9)
	sw	$5,4($9)
	sw	$6,8($9)
	sw	$7,12($9)
	jr	$31
	sw	$2,16($9)

	.set	macro
	.set	reorder
	.end	P_StartButton
	.size	P_StartButton, .-P_StartButton
	.align	2
	.globl	P_ChangeSwitchTexture
	.set	nomips16
	.set	nomicromips
	.ent	P_ChangeSwitchTexture
	.type	P_ChangeSwitchTexture, @function
P_ChangeSwitchTexture:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,20($sp)
	move	$17,$4
	lh	$4,22($4)
	sw	$20,32($sp)
	sll	$3,$4,2
	lui	$20,%hi(sides)
	lw	$2,%lo(sides)($20)
	addu	$3,$3,$4
	sll	$3,$3,2
	addu	$2,$2,$3
	sw	$19,28($sp)
	lh	$6,8($2)
	lh	$7,12($2)
	lh	$8,10($2)
	sw	$31,36($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	bne	$5,$0,$L29
	move	$19,$5

	sh	$0,18($17)
	b	$L31
	li	$5,23			# 0x17

$L29:
	lh	$3,18($17)
	li	$2,11			# 0xb
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L31
	.set	at
	li	$5,23			# 0x17

	li	$5,24			# 0x18
$L31:
	lui	$2,%hi(numswitches)
	lw	$2,%lo(numswitches)($2)
	blez	$2,$L28
	sll	$9,$2,1

	lui	$18,%hi(switchlist)
	addiu	$18,$18,%lo(switchlist)
	move	$3,$18
	b	$L38
	move	$16,$0

$L34:
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L52
	.set	at
	nop

	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L53
	.set	at
	lui	$2,%hi(buttonlist+16)

	addiu	$16,$16,1
	slt	$2,$16,$9
	beq	$2,$0,$L55
	lw	$31,36($sp)

$L38:
	lw	$2,0($3)
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L34
	.set	at
	addiu	$3,$3,4

	lui	$2,%hi(buttonlist+16)
	jal	S_StartSound
	lw	$4,%lo(buttonlist+16)($2)

	lh	$5,22($17)
	xori	$2,$16,0x1
	sll	$3,$5,2
	sll	$2,$2,2
	addu	$3,$3,$5
	addu	$2,$18,$2
	lw	$4,%lo(sides)($20)
	lw	$5,0($2)
	sll	$2,$3,2
	addu	$2,$4,$2
	bne	$19,$0,$L54
	sh	$5,8($2)

$L28:
	lw	$31,36($sp)
$L55:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L52:
	lui	$2,%hi(buttonlist+16)
	jal	S_StartSound
	lw	$4,%lo(buttonlist+16)($2)

	lh	$5,22($17)
	xori	$2,$16,0x1
	sll	$3,$5,2
	sll	$2,$2,2
	addu	$3,$3,$5
	addu	$2,$18,$2
	lw	$4,%lo(sides)($20)
	lw	$5,0($2)
	sll	$2,$3,2
	addu	$2,$4,$2
	beq	$19,$0,$L28
	sh	$5,12($2)

	sll	$2,$16,2
	addu	$2,$18,$2
	lw	$6,0($2)
	li	$7,35			# 0x23
	b	$L51
	li	$5,1			# 0x1

$L53:
	jal	S_StartSound
	lw	$4,%lo(buttonlist+16)($2)

	lh	$5,22($17)
	xori	$2,$16,0x1
	sll	$3,$5,2
	sll	$2,$2,2
	addu	$3,$3,$5
	addu	$2,$18,$2
	lw	$4,%lo(sides)($20)
	lw	$5,0($2)
	sll	$2,$3,2
	addu	$2,$4,$2
	beq	$19,$0,$L28
	sh	$5,10($2)

	sll	$16,$16,2
	addu	$18,$18,$16
	lw	$6,0($18)
	li	$7,35			# 0x23
	b	$L51
	li	$5,2			# 0x2

$L54:
	sll	$2,$16,2
	addu	$2,$18,$2
	lw	$6,0($2)
	li	$7,35			# 0x23
	move	$5,$0
$L51:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$4,$17
	lw	$17,20($sp)
	j	P_StartButton
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	P_ChangeSwitchTexture
	.size	P_ChangeSwitchTexture, .-P_ChangeSwitchTexture
	.align	2
	.globl	P_UseSpecialLine
	.set	nomips16
	.set	nomicromips
	.ent	P_UseSpecialLine
	.type	P_UseSpecialLine, @function
P_UseSpecialLine:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$6,$0,$L57
	move	$16,$5

	lh	$3,18($5)
	li	$2,124			# 0x7c
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L58
	.set	at
	nop

$L126:
	lw	$31,20($sp)
$L185:
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,24

$L57:
	lw	$2,132($4)
	beq	$2,$0,$L60
	nop

	lh	$2,18($5)
	slt	$3,$2,132
	beq	$3,$0,$L178
	li	$3,138			# 0x8a

	blez	$2,$L65
	andi	$3,$2,0xffff

	sltu	$3,$3,132
	beq	$3,$0,$L65
	lui	$3,%hi($L69)

	sll	$2,$2,2
	addiu	$3,$3,%lo($L69)
	addu	$2,$3,$2
	lw	$2,0($2)
	jr	$2
	nop

	.rdata
	.align	2
	.align	2
$L69:
	.word	$L65
	.word	$L63
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L111
	.word	$L65
	.word	$L110
	.word	$L65
	.word	$L109
	.word	$L65
	.word	$L65
	.word	$L108
	.word	$L107
	.word	$L65
	.word	$L65
	.word	$L106
	.word	$L65
	.word	$L105
	.word	$L104
	.word	$L65
	.word	$L103
	.word	$L65
	.word	$L65
	.word	$L63
	.word	$L63
	.word	$L63
	.word	$L102
	.word	$L65
	.word	$L63
	.word	$L63
	.word	$L63
	.word	$L63
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L101
	.word	$L100
	.word	$L99
	.word	$L65
	.word	$L98
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L97
	.word	$L96
	.word	$L95
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L94
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L93
	.word	$L92
	.word	$L91
	.word	$L90
	.word	$L89
	.word	$L88
	.word	$L87
	.word	$L86
	.word	$L85
	.word	$L84
	.word	$L83
	.word	$L82
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L66
	.word	$L65
	.word	$L81
	.word	$L80
	.word	$L79
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L78
	.word	$L77
	.word	$L76
	.word	$L75
	.word	$L74
	.word	$L73
	.word	$L63
	.word	$L63
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L72
	.word	$L71
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L70
	.word	$L65
	.word	$L65
	.word	$L65
	.word	$L68
	.text
$L58:
	lw	$2,132($4)
	bne	$2,$0,$L181
	li	$2,1			# 0x1

	lhu	$2,16($5)
	andi	$2,$2,0x20
	bne	$2,$0,$L185
	lw	$31,20($sp)

	li	$2,124			# 0x7c
	addiu	$2,$2,-32
$L184:
	andi	$2,$2,0xffff
	sltu	$2,$2,3
	beq	$2,$0,$L185
	lw	$31,20($sp)

$L63:
	move	$5,$4
$L188:
	jal	EV_VerticalDoor
	move	$4,$16

$L65:
	li	$2,1			# 0x1
$L181:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L178:
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L112
	.set	at
	slt	$3,$2,139

	bne	$3,$0,$L179
	li	$3,139			# 0x8b

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L180
	.set	at
	li	$3,140			# 0x8c

	move	$4,$5
	jal	EV_LightTurnOn
	li	$5,35			# 0x23

	li	$5,1			# 0x1
$L187:
	jal	P_ChangeSwitchTexture
	move	$4,$16

	b	$L181
	li	$2,1			# 0x1

$L180:
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L65
	.set	at
	li	$5,12			# 0xc

	jal	EV_DoFloor
	move	$4,$16

	beq	$2,$0,$L65
	move	$5,$0

$L186:
	jal	P_ChangeSwitchTexture
	move	$4,$16

	b	$L181
	li	$2,1			# 0x1

$L179:
	li	$3,1			# 0x1
	addiu	$2,$2,-132
	sll	$2,$3,$2
	andi	$3,$2,0x2a
	beq	$3,$0,$L182
	andi	$3,$2,0x14

	move	$6,$4
	li	$5,6			# 0x6
	jal	EV_DoLockedDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L182:
	beq	$3,$0,$L183
	andi	$2,$2,0x1

$L66:
	move	$6,$4
	li	$5,6			# 0x6
	jal	EV_DoLockedDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L183:
	beq	$2,$0,$L65
	li	$5,10			# 0xa

	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L81:
	li	$5,3			# 0x3
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L79:
	li	$5,3			# 0x3
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L78:
	li	$5,5			# 0x5
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L80:
	move	$5,$0
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L77:
	li	$5,6			# 0x6
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L76:
	li	$5,7			# 0x7
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L75:
	li	$5,5			# 0x5
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L74:
	li	$5,6			# 0x6
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L73:
	li	$5,7			# 0x7
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L72:
	move	$6,$0
	li	$5,4			# 0x4
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L68:
	li	$5,10			# 0xa
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L98:
	move	$5,$0
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L97:
	li	$5,3			# 0x3
	jal	EV_DoCeiling
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L96:
	li	$5,2			# 0x2
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L95:
	move	$5,$0
	jal	P_ChangeSwitchTexture
	move	$4,$16

	jal	G_SecretExitLevel
	nop

	b	$L181
	li	$2,1			# 0x1

$L94:
	li	$5,9			# 0x9
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L93:
	li	$5,1			# 0x1
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L92:
	li	$5,3			# 0x3
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L91:
	li	$6,1			# 0x1
	li	$5,1			# 0x1
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L90:
	move	$5,$0
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L89:
	li	$5,3			# 0x3
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L88:
	li	$5,9			# 0x9
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L87:
	li	$6,24			# 0x18
	li	$5,2			# 0x2
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L86:
	li	$6,32			# 0x20
	li	$5,2			# 0x2
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L85:
	move	$6,$0
	li	$5,3			# 0x3
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L84:
	li	$5,4			# 0x4
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L83:
	li	$5,2			# 0x2
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L106:
	li	$5,4			# 0x4
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L105:
	move	$6,$0
	li	$5,3			# 0x3
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L104:
	move	$6,$0
	li	$5,1			# 0x1
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L103:
	li	$5,1			# 0x1
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L102:
	move	$5,$0
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L101:
	move	$5,$0
	jal	EV_DoCeiling
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L100:
	li	$5,2			# 0x2
	jal	EV_DoDoor
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L99:
	move	$5,$0
	jal	EV_DoCeiling
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L110:
	jal	EV_DoDonut
	move	$4,$5

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L109:
	move	$5,$0
	jal	P_ChangeSwitchTexture
	move	$4,$16

	jal	G_ExitLevel
	nop

	b	$L181
	li	$2,1			# 0x1

$L108:
	li	$6,32			# 0x20
	li	$5,2			# 0x2
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L107:
	li	$6,24			# 0x18
	li	$5,2			# 0x2
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L111:
	move	$5,$0
	jal	EV_BuildStairs
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L71:
	move	$6,$0
	li	$5,4			# 0x4
	jal	EV_DoPlat
	move	$4,$16

	bne	$2,$0,$L187
	li	$5,1			# 0x1

	b	$L181
	li	$2,1			# 0x1

$L70:
	li	$5,1			# 0x1
	jal	EV_BuildStairs
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L82:
	li	$5,2			# 0x2
	jal	EV_DoFloor
	move	$4,$16

	bne	$2,$0,$L186
	move	$5,$0

	b	$L181
	li	$2,1			# 0x1

$L112:
	move	$4,$5
	jal	EV_LightTurnOn
	li	$5,255			# 0xff

	li	$5,1			# 0x1
	jal	P_ChangeSwitchTexture
	move	$4,$16

	b	$L181
	li	$2,1			# 0x1

$L60:
	lhu	$2,16($5)
	andi	$2,$2,0x20
	bne	$2,$0,$L126
	li	$3,1			# 0x1

	lh	$2,18($5)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L188
	.set	at
	move	$5,$4

	b	$L184
	addiu	$2,$2,-32

	.set	macro
	.set	reorder
	.end	P_UseSpecialLine
	.size	P_UseSpecialLine, .-P_UseSpecialLine
	.globl	buttonlist
	.section	.bss,"aw",@nobits
	.align	2
	.type	buttonlist, @object
	.size	buttonlist, 320
buttonlist:
	.space	320
	.globl	numswitches
	.align	2
	.type	numswitches, @object
	.size	numswitches, 4
numswitches:
	.space	4
	.globl	switchlist
	.align	2
	.type	switchlist, @object
	.size	switchlist, 400
switchlist:
	.space	400
	.globl	alphSwitchList
	.data
	.align	2
	.type	alphSwitchList, @object
	.size	alphSwitchList, 820
alphSwitchList:
	.ascii	"SW1BRCOM\000"
	.ascii	"SW2BRCOM\000"
	.half	1
	.ascii	"SW1BRN1\000"
	.space	1
	.ascii	"SW2BRN1\000"
	.space	1
	.half	1
	.ascii	"SW1BRN2\000"
	.space	1
	.ascii	"SW2BRN2\000"
	.space	1
	.half	1
	.ascii	"SW1BRNGN\000"
	.ascii	"SW2BRNGN\000"
	.half	1
	.ascii	"SW1BROWN\000"
	.ascii	"SW2BROWN\000"
	.half	1
	.ascii	"SW1COMM\000"
	.space	1
	.ascii	"SW2COMM\000"
	.space	1
	.half	1
	.ascii	"SW1COMP\000"
	.space	1
	.ascii	"SW2COMP\000"
	.space	1
	.half	1
	.ascii	"SW1DIRT\000"
	.space	1
	.ascii	"SW2DIRT\000"
	.space	1
	.half	1
	.ascii	"SW1EXIT\000"
	.space	1
	.ascii	"SW2EXIT\000"
	.space	1
	.half	1
	.ascii	"SW1GRAY\000"
	.space	1
	.ascii	"SW2GRAY\000"
	.space	1
	.half	1
	.ascii	"SW1GRAY1\000"
	.ascii	"SW2GRAY1\000"
	.half	1
	.ascii	"SW1METAL\000"
	.ascii	"SW2METAL\000"
	.half	1
	.ascii	"SW1PIPE\000"
	.space	1
	.ascii	"SW2PIPE\000"
	.space	1
	.half	1
	.ascii	"SW1SLAD\000"
	.space	1
	.ascii	"SW2SLAD\000"
	.space	1
	.half	1
	.ascii	"SW1STARG\000"
	.ascii	"SW2STARG\000"
	.half	1
	.ascii	"SW1STON1\000"
	.ascii	"SW2STON1\000"
	.half	1
	.ascii	"SW1STON2\000"
	.ascii	"SW2STON2\000"
	.half	1
	.ascii	"SW1STONE\000"
	.ascii	"SW2STONE\000"
	.half	1
	.ascii	"SW1STRTN\000"
	.ascii	"SW2STRTN\000"
	.half	1
	.ascii	"SW1BLUE\000"
	.space	1
	.ascii	"SW2BLUE\000"
	.space	1
	.half	2
	.ascii	"SW1CMT\000"
	.space	2
	.ascii	"SW2CMT\000"
	.space	2
	.half	2
	.ascii	"SW1GARG\000"
	.space	1
	.ascii	"SW2GARG\000"
	.space	1
	.half	2
	.ascii	"SW1GSTON\000"
	.ascii	"SW2GSTON\000"
	.half	2
	.ascii	"SW1HOT\000"
	.space	2
	.ascii	"SW2HOT\000"
	.space	2
	.half	2
	.ascii	"SW1LION\000"
	.space	1
	.ascii	"SW2LION\000"
	.space	1
	.half	2
	.ascii	"SW1SATYR\000"
	.ascii	"SW2SATYR\000"
	.half	2
	.ascii	"SW1SKIN\000"
	.space	1
	.ascii	"SW2SKIN\000"
	.space	1
	.half	2
	.ascii	"SW1VINE\000"
	.space	1
	.ascii	"SW2VINE\000"
	.space	1
	.half	2
	.ascii	"SW1WOOD\000"
	.space	1
	.ascii	"SW2WOOD\000"
	.space	1
	.half	2
	.ascii	"SW1PANEL\000"
	.ascii	"SW2PANEL\000"
	.half	3
	.ascii	"SW1ROCK\000"
	.space	1
	.ascii	"SW2ROCK\000"
	.space	1
	.half	3
	.ascii	"SW1MET2\000"
	.space	1
	.ascii	"SW2MET2\000"
	.space	1
	.half	3
	.ascii	"SW1WDMET\000"
	.ascii	"SW2WDMET\000"
	.half	3
	.ascii	"SW1BRIK\000"
	.space	1
	.ascii	"SW2BRIK\000"
	.space	1
	.half	3
	.ascii	"SW1MOD1\000"
	.space	1
	.ascii	"SW2MOD1\000"
	.space	1
	.half	3
	.ascii	"SW1ZIM\000"
	.space	2
	.ascii	"SW2ZIM\000"
	.space	2
	.half	3
	.ascii	"SW1STON6\000"
	.ascii	"SW2STON6\000"
	.half	3
	.ascii	"SW1TEK\000"
	.space	2
	.ascii	"SW2TEK\000"
	.space	2
	.half	3
	.ascii	"SW1MARB\000"
	.space	1
	.ascii	"SW2MARB\000"
	.space	1
	.half	3
	.ascii	"SW1SKULL\000"
	.ascii	"SW2SKULL\000"
	.half	3
	.ascii	"\000\000"
	.space	7
	.ascii	"\000\000"
	.space	7
	.half	0
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
