	.file	1 "p_telept.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	EV_Teleport
	.set	nomips16
	.set	nomicromips
	.ent	EV_Teleport
	.type	EV_Teleport, @function
EV_Teleport:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,104($6)
	li	$3,65536			# 0x10000
	and	$2,$2,$3
	bne	$2,$0,$L23
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$5,$3
	beq	$1,$0,$L23
	.set	at
	lui	$3,%hi(numsectors)

	lw	$7,%lo(numsectors)($3)
	blez	$7,$L23
	lh	$8,20($4)

	lui	$3,%hi(sectors)
	addiu	$sp,$sp,-40
	lw	$11,%lo(sectors)($3)
	lui	$4,%hi(thinkercap)
	addiu	$4,$4,%lo(thinkercap)
	sw	$17,20($sp)
	li	$9,-1171390464			# 0xffffffffba2e0000
	move	$17,$6
	lui	$6,%hi(P_MobjThinker)
	lw	$12,4($4)
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	addiu	$3,$11,16
	addiu	$6,$6,%lo(P_MobjThinker)
	li	$10,41			# 0x29
	b	$L10
	ori	$9,$9,0x8ba3

$L3:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$7
	beq	$1,$0,$L2
	.set	at
	addiu	$3,$3,88

$L10:
	lh	$5,0($3)
	.set	noat
	xor	$1,$5,$8
	bne	$1,$0,$L3
	.set	at
	nop

	.set	noat
	xor	$1,$12,$4
	beq	$1,$0,$L3
	.set	at
	move	$16,$12

	b	$L30
	lw	$5,8($16)

$L4:
	lw	$16,4($16)
	.set	noat
	xor	$1,$16,$4
	beq	$1,$0,$L3
	.set	at
	nop

	lw	$5,8($16)
$L30:
	.set	noat
	xor	$1,$5,$6
	bne	$1,$0,$L4
	.set	at
	nop

	lw	$5,88($16)
	.set	noat
	xor	$1,$5,$10
	bne	$1,$0,$L4
	.set	at
	nop

	lw	$5,52($16)
	lw	$5,0($5)
	subu	$5,$5,$11
	sra	$5,$5,3
	multu	$5,$9
	mflo	$5
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L4
	.set	at
	nop

	lw	$6,16($16)
	lw	$5,12($16)
	move	$4,$17
	lw	$18,12($17)
	lw	$19,16($17)
	jal	P_TeleportMove
	lw	$20,20($17)

	beq	$2,$0,$L28
	lw	$31,36($sp)

	lui	$2,%hi(gameversion)
	lw	$3,%lo(gameversion)($2)
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L5
	.set	at
	nop

	lw	$2,56($17)
	sw	$2,20($17)
$L5:
	lw	$2,132($17)
	beq	$2,$0,$L29
	move	$6,$20

	lw	$3,20($17)
	lw	$4,28($2)
	addu	$3,$3,$4
	sw	$3,24($2)
$L29:
	li	$7,39			# 0x27
	move	$5,$19
	jal	P_SpawnMobj
	move	$4,$18

	move	$4,$2
	jal	S_StartSound
	li	$5,35			# 0x23

	lw	$2,32($16)
	lui	$3,%hi(finecosine)
	lw	$4,%lo(finecosine)($3)
	srl	$2,$2,19
	lui	$3,%hi(finesine)
	sll	$2,$2,2
	addiu	$3,$3,%lo(finesine)
	addu	$3,$2,$3
	addu	$2,$4,$2
	lw	$7,0($3)
	lw	$6,0($2)
	sll	$3,$7,2
	sll	$2,$6,2
	lw	$5,16($16)
	lw	$4,12($16)
	addu	$3,$3,$7
	addu	$2,$2,$6
	sll	$3,$3,2
	lw	$6,20($17)
	sll	$2,$2,2
	addu	$5,$3,$5
	li	$7,39			# 0x27
	jal	P_SpawnMobj
	addu	$4,$2,$4

	move	$4,$2
	jal	S_StartSound
	li	$5,35			# 0x23

	lw	$2,132($17)
	beq	$2,$0,$L7
	li	$2,18			# 0x12

	sw	$2,124($17)
$L7:
	lw	$3,32($16)
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	sw	$3,32($17)
	sw	$0,80($17)
	sw	$0,76($17)
	sw	$0,72($17)
	li	$2,1			# 0x1
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L2:
	lw	$31,36($sp)
$L28:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,40

$L23:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	EV_Teleport
	.size	EV_Teleport, .-EV_Teleport
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
