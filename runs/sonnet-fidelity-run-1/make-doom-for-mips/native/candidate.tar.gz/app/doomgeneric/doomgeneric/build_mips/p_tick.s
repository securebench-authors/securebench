	.file	1 "p_tick.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_InitThinkers
	.set	nomips16
	.set	nomicromips
	.ent	P_InitThinkers
	.type	P_InitThinkers, @function
P_InitThinkers:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(thinkercap)
	addiu	$2,$3,%lo(thinkercap)
	sw	$2,4($2)
	jr	$31
	sw	$2,%lo(thinkercap)($3)

	.set	macro
	.set	reorder
	.end	P_InitThinkers
	.size	P_InitThinkers, .-P_InitThinkers
	.align	2
	.globl	P_AddThinker
	.set	nomips16
	.set	nomicromips
	.ent	P_AddThinker
	.type	P_AddThinker, @function
P_AddThinker:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(thinkercap)
	lw	$3,%lo(thinkercap)($2)
	addiu	$5,$2,%lo(thinkercap)
	sw	$4,4($3)
	sw	$3,0($4)
	sw	$5,4($4)
	jr	$31
	sw	$4,%lo(thinkercap)($2)

	.set	macro
	.set	reorder
	.end	P_AddThinker
	.size	P_AddThinker, .-P_AddThinker
	.align	2
	.globl	P_RemoveThinker
	.set	nomips16
	.set	nomicromips
	.ent	P_RemoveThinker
	.type	P_RemoveThinker, @function
P_RemoveThinker:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,-1			# 0xffffffffffffffff
	jr	$31
	sw	$2,8($4)

	.set	macro
	.set	reorder
	.end	P_RemoveThinker
	.size	P_RemoveThinker, .-P_RemoveThinker
	.align	2
	.globl	P_AllocateThinker
	.set	nomips16
	.set	nomicromips
	.ent	P_AllocateThinker
	.type	P_AllocateThinker, @function
P_AllocateThinker:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	P_AllocateThinker
	.size	P_AllocateThinker, .-P_AllocateThinker
	.align	2
	.globl	P_RunThinkers
	.set	nomips16
	.set	nomicromips
	.ent	P_RunThinkers
	.type	P_RunThinkers, @function
P_RunThinkers:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	lui	$17,%hi(thinkercap)
	addiu	$17,$17,%lo(thinkercap)
	sw	$16,16($sp)
	lw	$16,4($17)
	sw	$31,28($sp)
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L6
	.set	at
	sw	$18,24($sp)

	b	$L10
	li	$18,-1			# 0xffffffffffffffff

$L8:
	beq	$2,$0,$L9
	nop

	jalr	$2
	nop

$L9:
	lw	$16,4($16)
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L16
	.set	at
	lw	$31,28($sp)

$L10:
	lw	$2,8($16)
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L8
	.set	at
	move	$4,$16

	lw	$3,4($16)
	lw	$2,0($16)
	sw	$2,0($3)
	jal	Z_Free
	sw	$3,4($2)

	lw	$16,4($16)
	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L10
	.set	at
	nop

$L6:
	lw	$31,28($sp)
$L16:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_RunThinkers
	.size	P_RunThinkers, .-P_RunThinkers
	.align	2
	.globl	P_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	P_Ticker
	.type	P_Ticker, @function
P_Ticker:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(paused)
	lw	$2,%lo(paused)($2)
	bne	$2,$0,$L41
	nop

	lui	$2,%hi(menuactive)
	lw	$2,%lo(menuactive)($2)
	addiu	$sp,$sp,-32
	lui	$3,%hi(netgame)
	lw	$3,%lo(netgame)($3)
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	bne	$2,$0,$L29
	sw	$16,16($sp)

	lui	$16,%hi(players)
$L39:
	addiu	$16,$16,%lo(players)
	lui	$17,%hi(playeringame)
$L38:
	addiu	$17,$17,%lo(playeringame)
	addiu	$18,$16,1152
$L21:
	lw	$2,0($17)
	bne	$2,$0,$L36
	addiu	$17,$17,4

	addiu	$16,$16,288
$L37:
	.set	noat
	xor	$1,$18,$16
	bne	$1,$0,$L21
	.set	at
	nop

	jal	P_RunThinkers
	nop

	jal	P_UpdateSpecials
	nop

	jal	P_RespawnSpecials
	nop

	lui	$3,%hi(leveltime)
	lw	$2,%lo(leveltime)($3)
	addiu	$2,$2,1
	sw	$2,%lo(leveltime)($3)
	lw	$31,28($sp)
$L40:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L36:
	jal	P_PlayerThink
	move	$4,$16

	b	$L37
	addiu	$16,$16,288

$L41:
	jr	$31
	nop

$L29:
	lui	$2,%hi(demoplayback)
	lw	$2,%lo(demoplayback)($2)
	or	$3,$3,$2
	bne	$3,$0,$L39
	lui	$16,%hi(players)

	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,5
	addiu	$16,$16,%lo(players)
	addu	$2,$2,$16
	lw	$3,24($2)
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L40
	.set	at
	lw	$31,28($sp)

	b	$L38
	lui	$17,%hi(playeringame)

	.set	macro
	.set	reorder
	.end	P_Ticker
	.size	P_Ticker, .-P_Ticker
	.globl	thinkercap
	.section	.bss,"aw",@nobits
	.align	2
	.type	thinkercap, @object
	.size	thinkercap, 12
thinkercap:
	.space	12
	.globl	leveltime
	.align	2
	.type	leveltime, @object
	.size	leveltime, 4
leveltime:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
