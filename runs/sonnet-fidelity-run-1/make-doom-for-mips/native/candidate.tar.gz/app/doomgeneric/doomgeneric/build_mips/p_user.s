	.file	1 "p_user.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	P_Thrust
	.set	nomips16
	.set	nomicromips
	.ent	P_Thrust
	.type	P_Thrust, @function
P_Thrust:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	sw	$16,16($sp)
	srl	$16,$5,19
	sll	$16,$16,2
	addu	$2,$2,$16
	lw	$5,0($2)
	sw	$17,20($sp)
	move	$17,$4
	move	$4,$6
	sw	$31,28($sp)
	sw	$18,24($sp)
	jal	FixedMul
	move	$18,$6

	lw	$6,0($17)
	lui	$4,%hi(finesine)
	lw	$3,72($6)
	addiu	$4,$4,%lo(finesine)
	addu	$16,$16,$4
	addu	$2,$3,$2
	lw	$5,0($16)
	move	$4,$18
	jal	FixedMul
	sw	$2,72($6)

	lw	$4,0($17)
	lw	$31,28($sp)
	lw	$3,76($4)
	lw	$18,24($sp)
	addu	$3,$3,$2
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$3,76($4)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_Thrust
	.size	P_Thrust, .-P_Thrust
	.align	2
	.globl	P_CalcHeight
	.set	nomips16
	.set	nomicromips
	.ent	P_CalcHeight
	.type	P_CalcHeight, @function
P_CalcHeight:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	addiu	$sp,$sp,-32
	lw	$5,72($2)
	sw	$17,24($sp)
	move	$17,$4
	move	$4,$5
	sw	$31,28($sp)
	jal	FixedMul
	sw	$16,20($sp)

	lw	$3,0($17)
	move	$16,$2
	lw	$5,76($3)
	jal	FixedMul
	move	$4,$5

	addu	$2,$16,$2
	li	$5,1048576			# 0x100000
	sra	$2,$2,2
	lw	$3,204($17)
	addiu	$4,$5,1
	slt	$4,$2,$4
	movz	$2,$5,$4
	andi	$3,$3,0x4
	bne	$3,$0,$L5
	sw	$2,36($17)

	lui	$3,%hi(onground)
	lw	$3,%lo(onground)($3)
	bne	$3,$0,$L6
	lui	$3,%hi(leveltime)

$L5:
	lw	$2,0($17)
	lw	$3,28($17)
	lw	$2,20($2)
	addu	$2,$2,$3
	sw	$2,24($17)
$L4:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L6:
	lw	$3,%lo(leveltime)($3)
	li	$4,409			# 0x199
	multu	$3,$4
	mflo	$3
	lui	$4,%hi(finesine)
	andi	$3,$3,0x1fff
	addiu	$4,$4,%lo(finesine)
	sll	$3,$3,2
	addu	$3,$3,$4
	srl	$4,$2,31
	lw	$5,0($3)
	addu	$4,$4,$2
	jal	FixedMul
	sra	$4,$4,1

	lw	$3,4($17)
	bne	$3,$0,$L9
	li	$6,2686976			# 0x290000

	lw	$3,32($17)
	lw	$4,28($17)
	addu	$4,$3,$4
	addiu	$5,$6,1
	slt	$5,$4,$5
	bne	$5,$0,$L10
	li	$5,1310720			# 0x140000

	sw	$6,28($17)
	sw	$0,32($17)
$L9:
	lw	$4,0($17)
	lw	$7,28($17)
	lw	$3,20($4)
	lw	$5,60($4)
	li	$6,-262144			# 0xfffffffffffc0000
	addu	$3,$3,$7
	addiu	$4,$6,1
	addu	$2,$3,$2
	addu	$3,$5,$4
	slt	$3,$2,$3
	bne	$3,$0,$L4
	sw	$2,24($17)

	lw	$31,28($sp)
	addu	$5,$5,$6
	lw	$16,20($sp)
	sw	$5,24($17)
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L10:
	ori	$5,$5,0x8000
	slt	$6,$4,$5
	beq	$6,$0,$L12
	slt	$6,$0,$3

	li	$4,1			# 0x1
	movz	$3,$4,$6
	sw	$5,28($17)
	addiu	$3,$3,16384
$L19:
	b	$L9
	sw	$3,32($17)

$L12:
	beq	$3,$0,$L9
	sw	$4,28($17)

	addiu	$3,$3,16384
	bne	$3,$0,$L19
	nop

	li	$3,1			# 0x1
	b	$L9
	sw	$3,32($17)

	.set	macro
	.set	reorder
	.end	P_CalcHeight
	.size	P_CalcHeight, .-P_CalcHeight
	.align	2
	.globl	P_MovePlayer
	.set	nomips16
	.set	nomicromips
	.ent	P_MovePlayer
	.type	P_MovePlayer, @function
P_MovePlayer:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	lh	$5,10($4)
	lw	$7,32($2)
	sll	$5,$5,16
	addiu	$sp,$sp,-32
	lw	$3,20($2)
	lw	$6,56($2)
	addu	$5,$5,$7
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	sw	$5,32($2)
	slt	$2,$6,$3
	lb	$6,8($4)
	lui	$17,%hi(onground)
	xori	$3,$2,0x1
	move	$16,$4
	beq	$6,$0,$L21
	sw	$3,%lo(onground)($17)

	beq	$2,$0,$L37
	nop

$L22:
	lhu	$2,8($16)
$L39:
	beq	$2,$0,$L40
	lw	$31,28($sp)

	lw	$4,0($16)
	lui	$2,%hi(states+4172)
	lw	$3,100($4)
	addiu	$2,$2,%lo(states+4172)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L38
	.set	at
	lw	$17,24($sp)

$L40:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L37:
	jal	P_Thrust
	sll	$6,$6,11

$L21:
	lb	$6,9($16)
	beq	$6,$0,$L22
	lw	$2,%lo(onground)($17)

	beq	$2,$0,$L22
	nop

	lw	$2,0($16)
	sll	$6,$6,11
	lw	$5,32($2)
	li	$2,-1073741824			# 0xffffffffc0000000
	addu	$5,$5,$2
	jal	P_Thrust
	move	$4,$16

	b	$L39
	lhu	$2,8($16)

$L38:
	lw	$16,20($sp)
	li	$5,150			# 0x96
	j	P_SetMobjState
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	P_MovePlayer
	.size	P_MovePlayer, .-P_MovePlayer
	.align	2
	.globl	P_DeathThink
	.set	nomips16
	.set	nomicromips
	.ent	P_DeathThink
	.type	P_DeathThink, @function
P_DeathThink:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	P_MovePsprites
	move	$16,$4

	lw	$2,28($16)
	li	$3,393216			# 0x60000
	addiu	$3,$3,1
	slt	$3,$2,$3
	bne	$3,$0,$L61
	li	$3,393216			# 0x60000

	li	$3,-65536			# 0xffffffffffff0000
	addu	$2,$2,$3
	sw	$2,28($16)
	li	$3,393216			# 0x60000
$L61:
	slt	$2,$2,$3
	beq	$2,$0,$L43
	nop

	sw	$3,28($16)
$L43:
	lw	$3,0($16)
	move	$4,$16
	lw	$2,20($3)
	lw	$3,56($3)
	sw	$0,32($16)
	slt	$2,$3,$2
	xori	$2,$2,0x1
	lui	$3,%hi(onground)
	jal	P_CalcHeight
	sw	$2,%lo(onground)($3)

	lw	$2,236($16)
	beq	$2,$0,$L44
	nop

	lw	$3,0($16)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L44
	.set	at
	nop

	lw	$5,16($3)
	lw	$4,12($3)
	lw	$7,16($2)
	jal	R_PointToAngle2
	lw	$6,12($2)

	lw	$7,0($16)
	li	$3,-59703296			# 0xfffffffffc710000
	lw	$6,32($7)
	ori	$3,$3,0xc71d
	subu	$8,$2,$6
	li	$5,-119341056			# 0xfffffffff8e30000
	addu	$4,$8,$3
	ori	$5,$5,0x8e3b
	sltu	$4,$4,$5
	bne	$4,$0,$L45
	nop

	lw	$3,228($16)
	beq	$3,$0,$L47
	sw	$2,32($7)

	addiu	$3,$3,-1
	sw	$3,228($16)
$L47:
	lbu	$2,13($16)
	andi	$2,$2,0x2
	beq	$2,$0,$L62
	lw	$31,20($sp)

	li	$2,2			# 0x2
	sw	$2,4($16)
	lw	$31,20($sp)
$L62:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L44:
	lw	$2,228($16)
	beq	$2,$0,$L47
	addiu	$2,$2,-1

	b	$L47
	sw	$2,228($16)

$L45:
	bltz	$8,$L48
	li	$2,59637760			# 0x38e0000

	addiu	$2,$2,14563
	addu	$6,$6,$2
	b	$L47
	sw	$6,32($7)

$L48:
	addu	$6,$6,$3
	b	$L47
	sw	$6,32($7)

	.set	macro
	.set	reorder
	.end	P_DeathThink
	.size	P_DeathThink, .-P_DeathThink
	.align	2
	.globl	P_PlayerThink
	.set	nomips16
	.set	nomicromips
	.ent	P_PlayerThink
	.type	P_PlayerThink, @function
P_PlayerThink:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,204($4)
	lw	$3,0($16)
	andi	$4,$4,0x1
	lw	$2,104($3)
	beq	$4,$0,$L64
	sw	$31,20($sp)

	ori	$2,$2,0x1000
$L65:
	andi	$4,$2,0x80
	beq	$4,$0,$L66
	sw	$2,104($3)

	li	$4,-129			# 0xffffffffffffff7f
	and	$2,$2,$4
	li	$4,100			# 0x64
	sw	$4,8($16)
	sw	$2,104($3)
$L66:
	lw	$4,4($16)
	li	$2,1			# 0x1
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L152
	.set	at
	lw	$31,20($sp)

	lw	$2,124($3)
	beq	$2,$0,$L68
	addiu	$2,$2,-1

	sw	$2,124($3)
$L69:
	jal	P_CalcHeight
	move	$4,$16

	lw	$2,0($16)
	lw	$2,52($2)
	lw	$2,0($2)
	lh	$2,14($2)
	bne	$2,$0,$L153
	nop

	lb	$3,13($16)
$L160:
	bltz	$3,$L154
	lbu	$2,13($16)

	andi	$3,$2,0x4
	beq	$3,$0,$L73
	andi	$4,$2,0x2

	sra	$2,$2,3
	lui	$3,%hi(gamemode)
	andi	$2,$2,0x7
	bne	$2,$0,$L74
	lw	$5,%lo(gamemode)($3)

	lw	$2,156($16)
	beq	$2,$0,$L161
	addiu	$3,$2,32

	lw	$3,120($16)
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L155
	.set	at
	nop

$L77:
	sw	$2,124($16)
$L73:
	beq	$4,$0,$L72
	nop

	lw	$2,200($16)
	beq	$2,$0,$L156
	nop

$L78:
	jal	P_MovePsprites
	move	$4,$16

	lw	$2,56($16)
	beq	$2,$0,$L79
	addiu	$2,$2,1

	sw	$2,56($16)
$L79:
	lw	$2,52($16)
	beq	$2,$0,$L80
	nop

	addiu	$2,$2,-1
	sw	$2,52($16)
$L80:
	lw	$3,60($16)
	beq	$3,$0,$L82
	addiu	$3,$3,-1

	bne	$3,$0,$L82
	sw	$3,60($16)

	lw	$5,0($16)
	li	$4,-327680			# 0xfffffffffffb0000
	lw	$3,104($5)
	ori	$4,$4,0xffff
	and	$3,$3,$4
	sw	$3,104($5)
$L82:
	lw	$3,72($16)
	beq	$3,$0,$L84
	addiu	$3,$3,-1

	sw	$3,72($16)
$L84:
	lw	$3,64($16)
	beq	$3,$0,$L85
	addiu	$3,$3,-1

	sw	$3,64($16)
$L85:
	lw	$3,228($16)
	beq	$3,$0,$L86
	addiu	$3,$3,-1

	sw	$3,228($16)
$L86:
	lw	$3,232($16)
	beq	$3,$0,$L87
	addiu	$3,$3,-1

	sw	$3,232($16)
$L87:
	beq	$2,$0,$L88
	slt	$3,$2,129

	beq	$3,$0,$L162
	lw	$31,20($sp)

	andi	$2,$2,0x8
	bne	$2,$0,$L163
	li	$2,32			# 0x20

	lw	$31,20($sp)
$L164:
	sw	$0,244($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L162:
	li	$2,32			# 0x20
$L163:
	sw	$2,244($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L74:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$5,$3
	beq	$1,$0,$L157
	.set	at
	addiu	$3,$2,32

$L161:
	sll	$3,$3,2
	addu	$3,$16,$3
	lw	$3,0($3)
	beq	$3,$0,$L73
	nop

	lw	$3,120($16)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L73
	.set	at
	addiu	$3,$2,-5

	sltu	$3,$3,2
	beq	$3,$0,$L77
	nop

	beq	$5,$0,$L73
	nop

	b	$L73
	sw	$2,124($16)

$L154:
	sb	$0,13($16)
$L72:
	b	$L78
	sw	$0,200($16)

$L64:
	li	$4,-4097			# 0xffffffffffffefff
	b	$L65
	and	$2,$2,$4

$L88:
	lw	$2,72($16)
	beq	$2,$0,$L164
	lw	$31,20($sp)

	slt	$3,$2,129
	bne	$3,$0,$L158
	andi	$2,$2,0x8

	li	$2,1			# 0x1
	sw	$2,244($16)
$L159:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L153:
	jal	P_PlayerInSpecialSector
	move	$4,$16

	b	$L160
	lb	$3,13($16)

$L68:
	jal	P_MovePlayer
	move	$4,$16

	b	$L69
	nop

$L158:
	beq	$2,$0,$L164
	lw	$31,20($sp)

	li	$2,1			# 0x1
	b	$L159
	sw	$2,244($16)

$L157:
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L161
	.set	at
	nop

	lw	$3,160($16)
	beq	$3,$0,$L161
	addiu	$3,$2,32

	lw	$6,120($16)
	li	$3,8			# 0x8
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L161
	.set	at
	addiu	$3,$2,32

	li	$2,8			# 0x8
	b	$L73
	sw	$2,124($16)

$L156:
	jal	P_UseLines
	move	$4,$16

	li	$2,1			# 0x1
	b	$L78
	sw	$2,200($16)

$L152:
	move	$4,$16
	lw	$16,16($sp)
	j	P_DeathThink
	addiu	$sp,$sp,24

$L155:
	lw	$2,56($16)
	beq	$2,$0,$L73
	nop

	lw	$2,128($16)
	beq	$2,$0,$L73
	move	$2,$0

	b	$L73
	sw	$2,124($16)

	.set	macro
	.set	reorder
	.end	P_PlayerThink
	.size	P_PlayerThink, .-P_PlayerThink
	.globl	onground
	.section	.bss,"aw",@nobits
	.align	2
	.type	onground, @object
	.size	onground, 4
onground:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
