	.file	1 "r_bsp.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	R_ClearDrawSegs
	.set	nomips16
	.set	nomicromips
	.ent	R_ClearDrawSegs
	.type	R_ClearDrawSegs, @function
R_ClearDrawSegs:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(drawsegs)
	lui	$3,%hi(ds_p)
	addiu	$2,$2,%lo(drawsegs)
	jr	$31
	sw	$2,%lo(ds_p)($3)

	.set	macro
	.set	reorder
	.end	R_ClearDrawSegs
	.size	R_ClearDrawSegs, .-R_ClearDrawSegs
	.align	2
	.globl	R_ClipSolidWallSegment
	.set	nomips16
	.set	nomicromips
	.ent	R_ClipSolidWallSegment
	.type	R_ClipSolidWallSegment, @function
R_ClipSolidWallSegment:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	lui	$16,%hi(solidsegs)
	addiu	$16,$16,%lo(solidsegs)
	lw	$2,4($16)
	addiu	$3,$4,-1
	slt	$2,$2,$3
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$31,28($sp)
	move	$17,$4
	beq	$2,$0,$L4
	move	$18,$5

$L5:
	lw	$2,12($16)
	slt	$2,$2,$3
	bne	$2,$0,$L5
	addiu	$16,$16,8

$L4:
	lw	$5,0($16)
	slt	$2,$17,$5
	beq	$2,$0,$L6
	addiu	$5,$5,-1

	slt	$2,$18,$5
	bne	$2,$0,$L25
	move	$4,$17

	jal	R_StoreWallRange
	move	$4,$17

	sw	$17,0($16)
$L6:
	lw	$4,4($16)
	slt	$2,$4,$18
	beq	$2,$0,$L3
	move	$17,$16

	b	$L26
	lw	$5,8($17)

$L13:
	jal	R_StoreWallRange
	addiu	$17,$17,8

	lw	$4,4($17)
	slt	$2,$4,$18
	beq	$2,$0,$L12
	nop

	lw	$5,8($17)
$L26:
	addiu	$5,$5,-1
	slt	$2,$18,$5
	beq	$2,$0,$L13
	addiu	$4,$4,1

	jal	R_StoreWallRange
	move	$5,$18

	move	$4,$18
$L12:
	.set	noat
	xor	$1,$17,$16
	beq	$1,$0,$L3
	.set	at
	sw	$4,4($16)

	lui	$6,%hi(newend)
	lw	$3,%lo(newend)($6)
	.set	noat
	xor	$1,$17,$3
	beq	$1,$0,$L19
	.set	at
	addiu	$2,$17,8

	subu	$3,$3,$17
	addu	$3,$16,$3
$L16:
	lw	$5,0($2)
	lw	$4,4($2)
	addiu	$16,$16,8
	addiu	$2,$2,8
	sw	$5,0($16)
	.set	noat
	xor	$1,$3,$16
	bne	$1,$0,$L16
	.set	at
	sw	$4,4($16)

	addiu	$3,$3,8
	sw	$3,%lo(newend)($6)
$L3:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L25:
	jal	R_StoreWallRange
	move	$5,$18

	lui	$3,%hi(newend)
	lw	$2,%lo(newend)($3)
	addiu	$4,$2,8
	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L10
	.set	at
	sw	$4,%lo(newend)($3)

$L8:
	lw	$4,-8($2)
	lw	$3,-4($2)
	sw	$4,0($2)
	sw	$3,4($2)
	addiu	$2,$2,-8
	.set	noat
	xor	$1,$2,$16
	bne	$1,$0,$L8
	.set	at
	nop

$L10:
	lw	$31,28($sp)
	sw	$17,0($16)
	sw	$18,4($16)
	lw	$17,20($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L19:
	move	$3,$16
	addiu	$3,$3,8
	b	$L3
	sw	$3,%lo(newend)($6)

	.set	macro
	.set	reorder
	.end	R_ClipSolidWallSegment
	.size	R_ClipSolidWallSegment, .-R_ClipSolidWallSegment
	.align	2
	.globl	R_ClipPassWallSegment
	.set	nomips16
	.set	nomicromips
	.ent	R_ClipPassWallSegment
	.type	R_ClipPassWallSegment, @function
R_ClipPassWallSegment:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	lui	$16,%hi(solidsegs)
	addiu	$16,$16,%lo(solidsegs)
	lw	$2,4($16)
	addiu	$3,$4,-1
	slt	$2,$2,$3
	sw	$17,24($sp)
	sw	$31,28($sp)
	beq	$2,$0,$L28
	move	$17,$5

$L29:
	lw	$2,12($16)
	slt	$2,$2,$3
	bne	$2,$0,$L29
	addiu	$16,$16,8

$L28:
	lw	$5,0($16)
	slt	$2,$4,$5
	beq	$2,$0,$L40
	addiu	$5,$5,-1

	slt	$2,$17,$5
	bne	$2,$0,$L42
	lw	$31,28($sp)

$L35:
	jal	R_StoreWallRange
	nop

$L40:
	lw	$4,4($16)
	slt	$2,$4,$17
	beq	$2,$0,$L27
	addiu	$4,$4,1

	lw	$5,8($16)
	addiu	$5,$5,-1
	slt	$2,$17,$5
	beq	$2,$0,$L35
	addiu	$16,$16,8

	lw	$31,28($sp)
$L42:
	lw	$16,20($sp)
	move	$5,$17
	lw	$17,24($sp)
	j	R_StoreWallRange
	addiu	$sp,$sp,32

$L27:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_ClipPassWallSegment
	.size	R_ClipPassWallSegment, .-R_ClipPassWallSegment
	.align	2
	.globl	R_ClearClipSegs
	.set	nomips16
	.set	nomicromips
	.ent	R_ClearClipSegs
	.type	R_ClearClipSegs, @function
R_ClearClipSegs:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$3,-2147483648			# 0xffffffff80000000
	lui	$4,%hi(solidsegs)
	lui	$2,%hi(viewwidth)
	addiu	$3,$3,1
	lw	$5,%lo(viewwidth)($2)
	sw	$3,%lo(solidsegs)($4)
	addiu	$2,$4,%lo(solidsegs)
	li	$3,-1			# 0xffffffffffffffff
	sw	$3,4($2)
	li	$3,2147418112			# 0x7fff0000
	ori	$3,$3,0xffff
	sw	$3,12($2)
	sw	$5,8($2)
	lui	$2,%hi(solidsegs+16)
	lui	$3,%hi(newend)
	addiu	$2,$2,%lo(solidsegs+16)
	jr	$31
	sw	$2,%lo(newend)($3)

	.set	macro
	.set	reorder
	.end	R_ClearClipSegs
	.size	R_ClearClipSegs, .-R_ClearClipSegs
	.align	2
	.globl	R_AddLine
	.set	nomips16
	.set	nomicromips
	.ent	R_AddLine
	.type	R_AddLine, @function
R_AddLine:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	addiu	$sp,$sp,-32
	lw	$5,4($2)
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,0($2)
	sw	$18,24($sp)
	lui	$18,%hi(curline)
	sw	$31,28($sp)
	sw	$17,20($sp)
	jal	R_PointToAngle
	sw	$16,%lo(curline)($18)

	lw	$3,4($16)
	move	$17,$2
	lw	$5,4($3)
	jal	R_PointToAngle
	lw	$4,0($3)

	subu	$5,$17,$2
	bltz	$5,$L44
	lui	$3,%hi(viewangle)

	lw	$8,%lo(viewangle)($3)
	lui	$3,%hi(clipangle)
	lw	$6,%lo(clipangle)($3)
	subu	$3,$17,$8
	addu	$4,$6,$3
	sll	$7,$6,1
	lui	$10,%hi(rw_angle1)
	sltu	$9,$7,$4
	beq	$9,$0,$L47
	sw	$17,%lo(rw_angle1)($10)

	subu	$4,$4,$7
	sltu	$4,$4,$5
	beq	$4,$0,$L44
	move	$3,$6

$L47:
	addu	$4,$8,$6
	subu	$4,$4,$2
	sltu	$9,$7,$4
	bne	$9,$0,$L49
	subu	$4,$4,$7

	subu	$2,$2,$8
	li	$4,1073741824			# 0x40000000
$L63:
	addu	$3,$3,$4
	addu	$2,$2,$4
	srl	$3,$3,19
	srl	$2,$2,19
	lui	$4,%hi(viewangletox)
	addiu	$4,$4,%lo(viewangletox)
	sll	$3,$3,2
	sll	$2,$2,2
	addu	$2,$2,$4
	addu	$3,$3,$4
	lw	$4,0($3)
	lw	$5,0($2)
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L44
	.set	at
	lui	$3,%hi(backsector)

	lw	$2,28($16)
	beq	$2,$0,$L51
	sw	$2,%lo(backsector)($3)

	lui	$3,%hi(frontsector)
	lw	$3,%lo(frontsector)($3)
	lw	$6,4($2)
	lw	$7,0($3)
	slt	$8,$7,$6
	beq	$8,$0,$L60
	lw	$31,28($sp)

	lw	$9,0($2)
	lw	$8,4($3)
	slt	$10,$9,$8
	beq	$10,$0,$L60
	nop

	.set	noat
	xor	$1,$6,$8
	bne	$1,$0,$L61
	.set	at
	nop

	.set	noat
	xor	$1,$7,$9
	bne	$1,$0,$L61
	.set	at
	nop

	lw	$7,8($2)
	lw	$6,8($3)
	.set	noat
	xor	$1,$7,$6
	bne	$1,$0,$L61
	.set	at
	nop

	lh	$6,12($2)
	lh	$2,12($3)
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L61
	.set	at
	lw	$2,%lo(curline)($18)

	lw	$2,16($2)
	lh	$2,12($2)
	beq	$2,$0,$L62
	lw	$18,24($sp)

$L52 = .
$L61:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addiu	$5,$5,-1
	j	R_ClipPassWallSegment
	addiu	$sp,$sp,32

$L44:
	lw	$31,28($sp)
	lw	$18,24($sp)
$L62:
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L49:
	sltu	$5,$4,$5
	beq	$5,$0,$L44
	subu	$2,$0,$6

	b	$L63
	li	$4,1073741824			# 0x40000000

$L51:
	lw	$31,28($sp)
$L60:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addiu	$5,$5,-1
	j	R_ClipSolidWallSegment
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_AddLine
	.size	R_AddLine, .-R_AddLine
	.align	2
	.globl	R_CheckBBox
	.set	nomips16
	.set	nomicromips
	.ent	R_CheckBBox
	.type	R_CheckBBox, @function
R_CheckBBox:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$2,$4
	lui	$3,%hi(viewx)
	lw	$4,%lo(viewx)($3)
	lw	$3,8($2)
	slt	$3,$3,$4
	beq	$3,$0,$L65
	move	$3,$0

	lw	$3,12($2)
	li	$5,1			# 0x1
	slt	$4,$4,$3
	li	$3,2			# 0x2
	movn	$3,$5,$4
$L65:
	lui	$4,%hi(viewy)
	lw	$5,%lo(viewy)($4)
	lw	$4,0($2)
	slt	$4,$5,$4
	beq	$4,$0,$L86
	lui	$4,%hi(checkcoord)

	lw	$4,4($2)
	slt	$5,$4,$5
	beq	$5,$0,$L85
	li	$4,5			# 0x5

	addiu	$3,$3,4
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L86
	.set	at
	lui	$4,%hi(checkcoord)

	jr	$31
	li	$2,1			# 0x1

$L85:
	addiu	$3,$3,8
	lui	$4,%hi(checkcoord)
$L86:
	addiu	$4,$4,%lo(checkcoord)
	sll	$3,$3,4
	addu	$3,$3,$4
	lw	$5,4($3)
	lw	$4,0($3)
	lw	$6,8($3)
	lw	$7,12($3)
	sll	$5,$5,2
	sll	$3,$4,2
	addu	$3,$2,$3
	addu	$4,$2,$5
	lw	$5,0($4)
	lw	$4,0($3)
	sll	$3,$6,2
	sll	$6,$7,2
	addiu	$sp,$sp,-32
	addu	$3,$2,$3
	addu	$2,$2,$6
	sw	$18,24($sp)
	sw	$17,20($sp)
	lw	$18,0($2)
	sw	$16,16($sp)
	lw	$16,0($3)
	sw	$31,28($sp)
	jal	R_PointToAngle
	lui	$17,%hi(viewangle)

	lw	$3,%lo(viewangle)($17)
	move	$5,$18
	move	$4,$16
	jal	R_PointToAngle
	subu	$16,$2,$3

	lw	$8,%lo(viewangle)($17)
	subu	$3,$8,$2
	addu	$5,$3,$16
	bltz	$5,$L69
	lw	$31,28($sp)

	lui	$4,%hi(clipangle)
	lw	$6,%lo(clipangle)($4)
	addu	$4,$6,$16
	sll	$7,$6,1
	sltu	$9,$7,$4
	beq	$9,$0,$L70
	subu	$4,$4,$7

	sltu	$4,$4,$5
	beq	$4,$0,$L87
	move	$16,$6

$L70:
	addu	$3,$6,$3
	sltu	$4,$7,$3
	bne	$4,$0,$L71
	subu	$3,$3,$7

	subu	$3,$2,$8
	li	$4,1073741824			# 0x40000000
$L88:
	addu	$2,$16,$4
	addu	$3,$3,$4
	srl	$2,$2,19
	srl	$3,$3,19
	lui	$4,%hi(viewangletox)
	addiu	$4,$4,%lo(viewangletox)
	sll	$2,$2,2
	sll	$3,$3,2
	addu	$2,$2,$4
	addu	$3,$3,$4
	lw	$6,0($2)
	lw	$5,0($3)
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L79
	.set	at
	lui	$4,%hi(solidsegs)

	addiu	$4,$4,%lo(solidsegs)
	lw	$2,4($4)
	addiu	$5,$5,-1
	slt	$2,$2,$5
	beq	$2,$0,$L73
	nop

$L74:
	lw	$3,12($4)
	slt	$3,$3,$5
	bne	$3,$0,$L74
	addiu	$4,$4,8

$L73:
	lw	$2,0($4)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	slt	$2,$6,$2
	jr	$31
	addiu	$sp,$sp,32

$L69:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,32

$L79:
	lw	$31,28($sp)
$L87:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L71:
	sltu	$5,$3,$5
	beq	$5,$0,$L79
	subu	$3,$0,$6

	b	$L88
	li	$4,1073741824			# 0x40000000

	.set	macro
	.set	reorder
	.end	R_CheckBBox
	.size	R_CheckBBox, .-R_CheckBBox
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"R_Subsector: ss %i with numss = %i\000"
	.text
	.align	2
	.globl	R_Subsector
	.set	nomips16
	.set	nomicromips
	.ent	R_Subsector
	.type	R_Subsector, @function
R_Subsector:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numsubsectors)
	lw	$6,%lo(numsubsectors)($2)
	addiu	$sp,$sp,-40
	slt	$2,$4,$6
	sw	$16,20($sp)
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	beq	$2,$0,$L102
	move	$16,$4

	lui	$2,%hi(subsectors)
$L104:
	lw	$2,%lo(subsectors)($2)
	sll	$16,$16,3
	addu	$2,$2,$16
	lw	$4,0($2)
	lui	$7,%hi(sscount)
	lui	$19,%hi(viewz)
	lw	$8,0($4)
	lw	$6,%lo(sscount)($7)
	lui	$9,%hi(segs)
	lh	$5,6($2)
	lw	$3,%lo(viewz)($19)
	lw	$17,%lo(segs)($9)
	addiu	$6,$6,1
	lui	$18,%hi(frontsector)
	sll	$5,$5,5
	slt	$9,$8,$3
	lh	$16,4($2)
	sw	$6,%lo(sscount)($7)
	sw	$4,%lo(frontsector)($18)
	bne	$9,$0,$L103
	addu	$17,$17,$5

	lui	$2,%hi(floorplane)
	sw	$0,%lo(floorplane)($2)
$L92:
	lw	$2,4($4)
	slt	$3,$3,$2
	bne	$3,$0,$L93
	lh	$5,10($4)

	lui	$3,%hi(skyflatnum)
	lw	$3,%lo(skyflatnum)($3)
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L93
	.set	at
	nop

	lui	$2,%hi(ceilingplane)
	jal	R_AddSprites
	sw	$0,%lo(ceilingplane)($2)

	bne	$16,$0,$L105
	move	$4,$17

	lw	$31,36($sp)
$L106:
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L93:
	lh	$6,12($4)
	jal	R_FindPlane
	move	$4,$2

	lw	$4,%lo(frontsector)($18)
	lui	$3,%hi(ceilingplane)
	jal	R_AddSprites
	sw	$2,%lo(ceilingplane)($3)

	beq	$16,$0,$L106
	lw	$31,36($sp)

$L97:
	move	$4,$17
$L105:
	jal	R_AddLine
	addiu	$16,$16,-1

	bne	$16,$0,$L97
	addiu	$17,$17,32

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L103:
	lh	$5,8($4)
	lh	$6,12($4)
	jal	R_FindPlane
	move	$4,$8

	lui	$5,%hi(floorplane)
	lw	$4,%lo(frontsector)($18)
	lw	$3,%lo(viewz)($19)
	b	$L92
	sw	$2,%lo(floorplane)($5)

$L102:
	move	$5,$4
	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	b	$L104
	lui	$2,%hi(subsectors)

	.set	macro
	.set	reorder
	.end	R_Subsector
	.size	R_Subsector, .-R_Subsector
	.align	2
	.globl	R_RenderBSPNode
	.set	nomips16
	.set	nomicromips
	.ent	R_RenderBSPNode
	.type	R_RenderBSPNode, @function
R_RenderBSPNode:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	andi	$2,$4,0x8000
	bne	$2,$0,$L112
	li	$2,-1			# 0xffffffffffffffff

	addiu	$sp,$sp,-40
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$31,36($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lui	$20,%hi(nodes)
	lui	$19,%hi(viewy)
	lui	$18,%hi(viewx)
$L108:
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	lw	$6,%lo(nodes)($20)
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$16,$6,$2
	lw	$5,%lo(viewy)($19)
	lw	$4,%lo(viewx)($18)
	jal	R_PointOnSide
	move	$6,$16

	addiu	$3,$2,24
	sll	$3,$3,1
	addu	$3,$16,$3
	lhu	$4,0($3)
	jal	R_RenderBSPNode
	xori	$17,$2,0x1

	addiu	$4,$17,1
	sll	$4,$4,4
	addu	$4,$16,$4
	jal	R_CheckBBox
	addiu	$17,$17,24

	sll	$17,$17,1
	beq	$2,$0,$L107
	addu	$6,$16,$17

	lh	$2,0($6)
	bgez	$2,$L108
	lhu	$4,0($6)

	li	$2,-65536			# 0xffffffffffff0000
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addiu	$2,$2,32767
	and	$4,$4,$2
	j	R_Subsector
	addiu	$sp,$sp,40

$L107:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L112:
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L114
	.set	at
	li	$2,-65536			# 0xffffffffffff0000

	j	R_Subsector
	move	$4,$0

$L114:
	addiu	$2,$2,32767
	j	R_Subsector
	and	$4,$4,$2

	.set	macro
	.set	reorder
	.end	R_RenderBSPNode
	.size	R_RenderBSPNode, .-R_RenderBSPNode
	.globl	checkcoord
	.data
	.align	2
	.type	checkcoord, @object
	.size	checkcoord, 192
checkcoord:
	.word	3
	.word	0
	.word	2
	.word	1
	.word	3
	.word	0
	.word	2
	.word	0
	.word	3
	.word	1
	.word	2
	.word	0
	.word	0
	.space	12
	.word	2
	.word	0
	.word	2
	.word	1
	.word	0
	.word	0
	.word	0
	.word	0
	.word	3
	.word	1
	.word	3
	.word	0
	.word	0
	.space	12
	.word	2
	.word	0
	.word	3
	.word	1
	.word	2
	.word	1
	.word	3
	.word	1
	.word	2
	.word	1
	.word	3
	.word	0
	.space	16
	.globl	solidsegs
	.section	.bss,"aw",@nobits
	.align	2
	.type	solidsegs, @object
	.size	solidsegs, 256
solidsegs:
	.space	256
	.globl	newend
	.align	2
	.type	newend, @object
	.size	newend, 4
newend:
	.space	4
	.globl	ds_p
	.align	2
	.type	ds_p, @object
	.size	ds_p, 4
ds_p:
	.space	4
	.globl	drawsegs
	.align	2
	.type	drawsegs, @object
	.size	drawsegs, 12288
drawsegs:
	.space	12288
	.globl	backsector
	.align	2
	.type	backsector, @object
	.size	backsector, 4
backsector:
	.space	4
	.globl	frontsector
	.align	2
	.type	frontsector, @object
	.size	frontsector, 4
frontsector:
	.space	4
	.globl	linedef
	.align	2
	.type	linedef, @object
	.size	linedef, 4
linedef:
	.space	4
	.globl	sidedef
	.align	2
	.type	sidedef, @object
	.size	sidedef, 4
sidedef:
	.space	4
	.globl	curline
	.align	2
	.type	curline, @object
	.size	curline, 4
curline:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
