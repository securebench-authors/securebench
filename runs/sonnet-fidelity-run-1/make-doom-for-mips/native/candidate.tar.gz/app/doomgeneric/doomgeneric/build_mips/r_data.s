	.file	1 "r_data.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	R_CheckTextureNumForName.part.0
	.type	R_CheckTextureNumForName.part.0, @function
R_CheckTextureNumForName.part.0:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	jal	W_LumpNameHash
	move	$17,$4

	lui	$3,%hi(numtextures)
	lw	$3,%lo(numtextures)($3)
	divu	$0,$2,$3
	lui	$3,%hi(textures_hashtable)
	lw	$3,%lo(textures_hashtable)($3)
	mfhi	$2
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$16,0($2)
	bne	$16,$0,$L13
	move	$4,$16

	b	$L12
	lw	$31,28($sp)

$L3:
	lw	$16,16($16)
	beq	$16,$0,$L2
	move	$4,$16

$L13:
	li	$6,8			# 0x8
	jal	strncasecmp
	move	$5,$17

	bne	$2,$0,$L3
	lw	$31,28($sp)

	lw	$2,12($16)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L2:
	lw	$31,28($sp)
$L12:
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,-1			# 0xffffffffffffffff
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_CheckTextureNumForName.part.0
	.size	R_CheckTextureNumForName.part.0, .-R_CheckTextureNumForName.part.0
	.align	2
	.globl	R_DrawColumnInCache
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawColumnInCache
	.type	R_DrawColumnInCache, @function
R_DrawColumnInCache:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lbu	$2,0($4)
	li	$3,255			# 0xff
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L28
	.set	at
	nop

	addiu	$sp,$sp,-40
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,36($sp)
	move	$16,$4
	move	$19,$5
	move	$18,$6
	move	$17,$7
	li	$20,255			# 0xff
$L15:
	lbu	$3,1($16)
	addu	$2,$2,$18
	addu	$4,$3,$2
	addiu	$5,$16,3
	move	$6,$3
	bgez	$2,$L16
	slt	$8,$17,$4

	move	$6,$4
	move	$2,$0
$L16:
	beq	$8,$0,$L17
	addu	$4,$19,$2

	subu	$6,$17,$2
$L17:
	blez	$6,$L27
	addiu	$3,$3,4

	jal	memcpy
	nop

	lbu	$3,1($16)
	addiu	$3,$3,4
$L27:
	addu	$16,$16,$3
	lbu	$2,0($16)
	.set	noat
	xor	$1,$2,$20
	bne	$1,$0,$L15
	.set	at
	lw	$31,36($sp)

	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L28:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_DrawColumnInCache
	.size	R_DrawColumnInCache, .-R_DrawColumnInCache
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"r_data.c\000"
	.text
	.align	2
	.globl	R_GenerateComposite
	.set	nomips16
	.set	nomicromips
	.ent	R_GenerateComposite
	.type	R_GenerateComposite, @function
R_GenerateComposite:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(texturecompositesize)
	addiu	$sp,$sp,-64
	lw	$3,%lo(texturecompositesize)($2)
	lui	$2,%hi(textures)
	sw	$16,24($sp)
	sll	$16,$4,2
	lui	$4,%hi(texturecomposite)
	lw	$6,%lo(texturecomposite)($4)
	addu	$3,$3,$16
	lw	$2,%lo(textures)($2)
	lw	$4,0($3)
	addu	$2,$2,$16
	li	$5,1			# 0x1
	addu	$6,$6,$16
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$31,60($sp)
	lw	$17,0($2)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	jal	Z_Malloc
	sw	$19,36($sp)

	lui	$3,%hi(texturecolumnlump)
	lw	$4,%lo(texturecolumnlump)($3)
	lui	$3,%hi(texturecolumnofs)
	lw	$3,%lo(texturecolumnofs)($3)
	addu	$4,$4,$16
	addu	$3,$3,$16
	lw	$4,0($4)
	lw	$3,0($3)
	lh	$5,20($17)
	sw	$4,16($sp)
	sw	$3,20($sp)
	blez	$5,$L30
	move	$18,$2

	addiu	$16,$17,24
	move	$19,$0
$L34:
	lw	$4,4($16)
	jal	W_CacheLumpNum
	li	$5,8			# 0x8

	lbu	$8,1($2)
	lbu	$4,0($2)
	sll	$8,$8,8
	or	$8,$8,$4
	lh	$3,0($16)
	sll	$8,$8,16
	lh	$4,8($17)
	sra	$8,$8,16
	addu	$8,$8,$3
	slt	$5,$4,$8
	slt	$6,$3,0
	move	$22,$3
	movn	$22,$0,$6
	movn	$8,$4,$5
	slt	$4,$22,$8
	beq	$4,$0,$L31
	move	$21,$2

	lw	$2,16($sp)
	sll	$fp,$22,1
	addu	$23,$2,$fp
	lw	$2,20($sp)
	subu	$22,$22,$3
	addu	$fp,$2,$fp
	subu	$20,$8,$3
$L33:
	addiu	$3,$22,2
	lh	$4,0($23)
	sll	$3,$3,2
	addu	$3,$21,$3
	bgez	$4,$L32
	addiu	$22,$22,1

	lwl	$4,3($3)
	lhu	$5,0($fp)
	lwr	$4,0($3)
	lh	$7,10($17)
	lh	$6,2($16)
	addu	$5,$18,$5
	jal	R_DrawColumnInCache
	addu	$4,$21,$4

$L32:
	addiu	$23,$23,2
	.set	noat
	xor	$1,$22,$20
	bne	$1,$0,$L33
	.set	at
	addiu	$fp,$fp,2

$L31:
	lh	$2,20($17)
	addiu	$19,$19,1
	slt	$2,$19,$2
	bne	$2,$0,$L34
	addiu	$16,$16,8

$L30:
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	lui	$6,%hi($LC0)
	move	$4,$18
	lw	$18,32($sp)
	li	$7,286			# 0x11e
	addiu	$6,$6,%lo($LC0)
	li	$5,8			# 0x8
	j	Z_ChangeTag2
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	R_GenerateComposite
	.size	R_GenerateComposite, .-R_GenerateComposite
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"R_GenerateLookup: column without a patch (%s)\012\000"
	.align	2
$LC2:
	.ascii	"R_GenerateLookup: texture %i is >64k\000"
	.text
	.align	2
	.globl	R_GenerateLookup
	.set	nomips16
	.set	nomicromips
	.ent	R_GenerateLookup
	.type	R_GenerateLookup, @function
R_GenerateLookup:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(textures)
	addiu	$sp,$sp,-64
	lw	$2,%lo(textures)($2)
	sw	$18,32($sp)
	sll	$18,$4,2
	addu	$2,$2,$18
	sw	$22,48($sp)
	lw	$22,0($2)
	lui	$2,%hi(texturecomposite)
	lw	$5,%lo(texturecomposite)($2)
	sw	$19,36($sp)
	lui	$2,%hi(texturecolumnlump)
	lui	$19,%hi(texturecompositesize)
	lw	$3,%lo(texturecolumnlump)($2)
	lw	$7,%lo(texturecompositesize)($19)
	lui	$2,%hi(texturecolumnofs)
	lw	$2,%lo(texturecolumnofs)($2)
	addu	$7,$7,$18
	sw	$4,64($sp)
	addu	$5,$5,$18
	lh	$4,8($22)
	sw	$31,60($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	addu	$3,$3,$18
	sw	$0,0($5)
	addu	$2,$2,$18
	addiu	$6,$sp,16
	li	$5,1			# 0x1
	sw	$0,0($7)
	lw	$17,0($3)
	jal	Z_Malloc
	lw	$16,0($2)

	lh	$6,8($22)
	move	$4,$2
	move	$5,$0
	jal	memset
	sw	$2,16($sp)

	lh	$2,20($22)
	blez	$2,$L43
	nop

	addiu	$21,$22,24
	move	$23,$0
$L39:
	lw	$4,4($21)
	jal	W_CacheLumpNum
	li	$5,8			# 0x8

	lbu	$10,1($2)
	lbu	$3,0($2)
	sll	$10,$10,8
	or	$10,$10,$3
	lh	$7,0($21)
	sll	$10,$10,16
	lh	$3,8($22)
	sra	$10,$10,16
	addu	$10,$10,$7
	slt	$4,$3,$10
	slt	$6,$7,0
	move	$5,$7
	movn	$5,$0,$6
	movn	$10,$3,$4
	slt	$3,$5,$10
	beq	$3,$0,$L45
	nop

	sll	$8,$5,1
	addu	$9,$17,$8
	subu	$7,$5,$7
	addu	$8,$16,$8
$L44:
	lw	$4,16($sp)
	addiu	$3,$7,2
	addu	$4,$4,$5
	lbu	$6,0($4)
	sll	$3,$3,2
	addiu	$6,$6,1
	sb	$6,0($4)
	lw	$4,4($21)
	addu	$3,$2,$3
	sh	$4,0($9)
	lwl	$4,3($3)
	addiu	$5,$5,1
	lwr	$4,0($3)
	addiu	$9,$9,2
	addiu	$3,$4,3
	sh	$3,0($8)
	addiu	$7,$7,1
	.set	noat
	xor	$1,$5,$10
	bne	$1,$0,$L44
	.set	at
	addiu	$8,$8,2

$L45:
	lh	$2,20($22)
	addiu	$23,$23,1
	slt	$2,$23,$2
	bne	$2,$0,$L39
	addiu	$21,$21,8

$L43:
	lh	$5,8($22)
	blez	$5,$L41
	lw	$4,16($sp)

	lui	$23,%hi($LC2)
	move	$21,$0
	li	$fp,1			# 0x1
	li	$8,-1			# 0xffffffffffffffff
	li	$20,65536			# 0x10000
	b	$L50
	addiu	$23,$23,%lo($LC2)

$L49:
	addu	$2,$2,$6
	lh	$5,8($22)
	sw	$2,0($3)
$L48:
	slt	$2,$21,$5
	addiu	$17,$17,2
	beq	$2,$0,$L41
	addiu	$16,$16,2

$L50:
	addu	$2,$4,$21
	lbu	$2,0($2)
	beq	$2,$0,$L58
	addiu	$21,$21,1

	.set	noat
	xor	$1,$2,$fp
	beq	$1,$0,$L48
	.set	at
	lw	$3,%lo(texturecompositesize)($19)

	sh	$8,0($17)
	addu	$3,$3,$18
	lw	$2,0($3)
	sh	$2,0($16)
	lh	$6,10($22)
	subu	$5,$20,$6
	slt	$5,$5,$2
	beq	$5,$0,$L49
	lw	$5,64($sp)

	jal	I_Error
	move	$4,$23

	lw	$3,%lo(texturecompositesize)($19)
	lh	$6,10($22)
	addu	$3,$3,$18
	lw	$2,0($3)
	lw	$4,16($sp)
	b	$L49
	li	$8,-1			# 0xffffffffffffffff

$L41:
	jal	Z_Free
	nop

	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L58:
	lui	$4,%hi($LC1)
	move	$5,$22
	jal	printf
	addiu	$4,$4,%lo($LC1)

	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

	.set	macro
	.set	reorder
	.end	R_GenerateLookup
	.size	R_GenerateLookup, .-R_GenerateLookup
	.align	2
	.globl	R_GetColumn
	.set	nomips16
	.set	nomicromips
	.ent	R_GetColumn
	.type	R_GetColumn, @function
R_GetColumn:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(texturewidthmask)
	addiu	$sp,$sp,-32
	lw	$2,%lo(texturewidthmask)($2)
	lui	$3,%hi(texturecolumnlump)
	sw	$16,16($sp)
	sll	$16,$4,2
	addu	$2,$2,$16
	lw	$3,%lo(texturecolumnlump)($3)
	lw	$6,0($2)
	lui	$2,%hi(texturecolumnofs)
	lw	$2,%lo(texturecolumnofs)($2)
	addu	$3,$3,$16
	lw	$3,0($3)
	and	$5,$5,$6
	sll	$5,$5,1
	addu	$2,$2,$16
	lw	$2,0($2)
	addu	$3,$3,$5
	lh	$3,0($3)
	addu	$2,$2,$5
	sw	$17,20($sp)
	sw	$31,28($sp)
	lhu	$17,0($2)
	bgtz	$3,$L64
	sw	$18,24($sp)

	lui	$18,%hi(texturecomposite)
	lw	$2,%lo(texturecomposite)($18)
	addu	$2,$2,$16
	lw	$2,0($2)
	beq	$2,$0,$L65
	nop

$L62:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	addu	$2,$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L64:
	li	$5,8			# 0x8
	jal	W_CacheLumpNum
	move	$4,$3

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	addu	$2,$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L65:
	jal	R_GenerateComposite
	nop

	lw	$2,%lo(texturecomposite)($18)
	addu	$2,$2,$16
	b	$L62
	lw	$2,0($2)

	.set	macro
	.set	reorder
	.end	R_GetColumn
	.size	R_GetColumn, .-R_GetColumn
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"PNAMES\000"
	.align	2
$LC4:
	.ascii	"TEXTURE1\000"
	.align	2
$LC5:
	.ascii	"TEXTURE2\000"
	.align	2
$LC6:
	.ascii	"S_START\000"
	.align	2
$LC7:
	.ascii	"S_END\000"
	.align	2
$LC8:
	.ascii	"[\000"
	.align	2
$LC9:
	.ascii	"]\000"
	.align	2
$LC10:
	.ascii	" \000"
	.align	2
$LC11:
	.ascii	"\010\000"
	.align	2
$LC12:
	.ascii	".\000"
	.align	2
$LC13:
	.ascii	"R_InitTextures: bad texture directory\000"
	.align	2
$LC14:
	.ascii	"R_InitTextures: Missing patch in texture %s\000"
	.text
	.align	2
	.globl	R_InitTextures
	.set	nomips16
	.set	nomicromips
	.ent	R_InitTextures
	.type	R_InitTextures, @function
R_InitTextures:
	.frame	$sp,136,$31		# vars= 80, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-136
	sw	$21,116($sp)
	lui	$21,%hi($LC3)
	li	$5,1			# 0x1
	addiu	$4,$21,%lo($LC3)
	sw	$31,132($sp)
	sw	$20,112($sp)
	sw	$17,100($sp)
	sw	$16,96($sp)
	sw	$fp,128($sp)
	sw	$23,124($sp)
	sw	$22,120($sp)
	sw	$19,108($sp)
	sw	$18,104($sp)
	jal	W_CacheLumpName
	sb	$0,24($sp)

	lw	$20,0($2)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$20,2
	jal	Z_Malloc
	move	$17,$2

	blez	$20,$L71
	move	$16,$2

	addiu	$17,$17,4
	move	$19,$2
	move	$18,$0
$L70:
	move	$5,$17
	li	$6,9			# 0x9
	jal	M_StringCopy
	addiu	$4,$sp,16

	jal	W_CheckNumForName
	addiu	$4,$sp,16

	addiu	$18,$18,1
	sw	$2,0($19)
	addiu	$17,$17,8
	.set	noat
	xor	$1,$20,$18
	bne	$1,$0,$L70
	.set	at
	addiu	$19,$19,4

$L71:
	lui	$17,%hi($LC4)
	jal	W_ReleaseLumpName
	addiu	$4,$21,%lo($LC3)

	li	$5,1			# 0x1
	addiu	$4,$17,%lo($LC4)
	jal	W_CacheLumpName
	sw	$17,88($sp)

	lw	$19,0($2)
	addiu	$4,$17,%lo($LC4)
	sw	$2,44($sp)
	move	$17,$2
	jal	W_GetNumForName
	sw	$19,52($sp)

	jal	W_LumpLength
	move	$4,$2

	lui	$3,%hi($LC5)
	addiu	$4,$3,%lo($LC5)
	sw	$3,92($sp)
	jal	W_CheckNumForName
	sw	$2,48($sp)

	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L68
	.set	at
	addiu	$18,$17,4

	move	$2,$19
	sw	$0,76($sp)
	sw	$0,72($sp)
$L69:
	lui	$17,%hi(numtextures)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$2,2
	jal	Z_Malloc
	sw	$2,%lo(numtextures)($17)

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(textures)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	sw	$3,32($sp)
	jal	Z_Malloc
	sw	$2,%lo(textures)($3)

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(texturecolumnlump)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	sw	$3,64($sp)
	jal	Z_Malloc
	sw	$2,%lo(texturecolumnlump)($3)

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(texturecolumnofs)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	sw	$3,60($sp)
	jal	Z_Malloc
	sw	$2,%lo(texturecolumnofs)($3)

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(texturecomposite)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	jal	Z_Malloc
	sw	$2,%lo(texturecomposite)($3)

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(texturecompositesize)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	jal	Z_Malloc
	sw	$2,%lo(texturecompositesize)($3)

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(texturewidthmask)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	sw	$3,68($sp)
	jal	Z_Malloc
	sw	$2,%lo(texturewidthmask)($3)

	lui	$4,%hi($LC6)
	lui	$3,%hi(textureheight)
	addiu	$4,$4,%lo($LC6)
	sw	$3,56($sp)
	jal	W_GetNumForName
	sw	$2,%lo(textureheight)($3)

	lui	$4,%hi($LC7)
	addiu	$4,$4,%lo($LC7)
	jal	W_GetNumForName
	move	$19,$2

	move	$23,$2
	jal	I_ConsoleStdout
	lw	$fp,%lo(numtextures)($17)

	bne	$2,$0,$L72
	addiu	$2,$23,-1

	lw	$2,%lo(numtextures)($17)
$L134:
	blez	$2,$L74
	move	$fp,$0

	lui	$2,%hi($LC12)
	addiu	$2,$2,%lo($LC12)
	sw	$2,80($sp)
	lui	$2,%hi($LC13)
	sw	$2,84($sp)
	lui	$2,%hi($LC14)
	addiu	$2,$2,%lo($LC14)
	sw	$2,40($sp)
$L73:
	andi	$2,$fp,0x3f
	beq	$2,$0,$L126
	nop

	lw	$2,52($sp)
$L132:
	.set	noat
	xor	$1,$2,$fp
	bne	$1,$0,$L85
	.set	at
	lw	$2,72($sp)

	lw	$3,76($sp)
	addiu	$18,$2,4
	sw	$3,48($sp)
	sw	$2,44($sp)
$L85:
	lw	$20,0($18)
	lw	$2,48($sp)
	slt	$2,$2,$20
	bne	$2,$0,$L127
	lw	$2,84($sp)

	lw	$2,44($sp)
$L133:
	move	$6,$0
	addu	$20,$2,$20
	lbu	$4,21($20)
	lbu	$2,20($20)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$4,$4,16
	lw	$2,32($sp)
	sra	$4,$4,16
	lw	$8,%lo(textures)($2)
	addiu	$4,$4,3
	li	$5,1			# 0x1
	sll	$4,$4,3
	sll	$19,$fp,2
	jal	Z_Malloc
	addu	$21,$8,$19

	sw	$2,0($21)
	lbu	$4,15($20)
	lbu	$6,14($20)
	move	$23,$2
	lbu	$2,13($20)
	lbu	$5,12($20)
	sll	$4,$4,8
	or	$4,$4,$6
	sll	$2,$2,8
	sll	$4,$4,16
	or	$2,$2,$5
	or	$2,$2,$4
	sw	$2,8($23)
	lbu	$2,21($20)
	lbu	$4,20($20)
	sll	$2,$2,8
	or	$2,$2,$4
	li	$6,8			# 0x8
	move	$5,$20
	move	$4,$23
	jal	memcpy
	sh	$2,20($23)

	lh	$4,20($23)
	addiu	$6,$20,22
	addiu	$21,$23,24
	move	$20,$0
	blez	$4,$L91
	li	$22,-1			# 0xffffffffffffffff

	sw	$18,36($sp)
	move	$18,$23
	move	$23,$16
	move	$16,$20
	b	$L87
	move	$20,$6

$L90:
	lh	$2,20($18)
	addiu	$20,$20,10
	slt	$2,$16,$2
	beq	$2,$0,$L128
	addiu	$21,$21,8

$L87:
	lbu	$3,3($20)
	lbu	$2,1($20)
	lbu	$6,2($20)
	lbu	$4,0($20)
	sll	$3,$3,8
	sll	$2,$2,8
	or	$3,$3,$6
	sll	$3,$3,16
	or	$2,$2,$4
	or	$2,$2,$3
	sw	$2,0($21)
	lbu	$2,5($20)
	lbu	$3,4($20)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$2,$2,2
	addu	$2,$23,$2
	lw	$2,0($2)
	addiu	$16,$16,1
	.set	noat
	xor	$1,$2,$22
	bne	$1,$0,$L90
	.set	at
	sw	$2,4($21)

	lw	$4,40($sp)
	jal	I_Error
	move	$5,$18

	lh	$2,20($18)
	addiu	$20,$20,10
	slt	$2,$16,$2
	bne	$2,$0,$L87
	addiu	$21,$21,8

$L128:
	move	$16,$23
	move	$23,$18
	lw	$18,36($sp)
$L91:
	lw	$2,64($sp)
	lh	$4,8($23)
	lw	$8,%lo(texturecolumnlump)($2)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,1
	jal	Z_Malloc
	addu	$22,$8,$19

	lw	$3,60($sp)
	lh	$4,8($23)
	lw	$3,%lo(texturecolumnofs)($3)
	li	$5,1			# 0x1
	sw	$2,0($22)
	sll	$4,$4,1
	move	$6,$0
	jal	Z_Malloc
	addu	$22,$3,$19

	lh	$5,8($23)
	move	$4,$0
	slt	$3,$5,2
	sw	$2,0($22)
	bne	$3,$0,$L89
	li	$2,2			# 0x2

$L88:
	move	$4,$2
	sll	$2,$2,1
	slt	$3,$5,$2
	beq	$3,$0,$L88
	addiu	$4,$4,-1

$L89:
	lw	$2,68($sp)
	lh	$3,10($23)
	lw	$5,%lo(texturewidthmask)($2)
	lw	$2,56($sp)
	addu	$5,$5,$19
	lw	$2,%lo(textureheight)($2)
	sll	$3,$3,16
	addu	$2,$2,$19
	sw	$4,0($5)
	sw	$3,0($2)
	lw	$2,%lo(numtextures)($17)
	addiu	$fp,$fp,1
	slt	$2,$fp,$2
	bne	$2,$0,$L73
	addiu	$18,$18,4

$L74:
	jal	Z_Free
	move	$4,$16

	lw	$2,88($sp)
	jal	W_ReleaseLumpName
	addiu	$4,$2,%lo($LC4)

	lw	$2,72($sp)
	beq	$2,$0,$L83
	lw	$2,92($sp)

	jal	W_ReleaseLumpName
	addiu	$4,$2,%lo($LC5)

$L83:
	lw	$2,%lo(numtextures)($17)
	blez	$2,$L135
	addiu	$2,$2,1

	move	$16,$0
$L93:
	jal	R_GenerateLookup
	move	$4,$16

	lw	$2,%lo(numtextures)($17)
	addiu	$16,$16,1
	slt	$3,$16,$2
	bne	$3,$0,$L93
	addiu	$2,$2,1

$L135:
	sll	$4,$2,2
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$4,%lo(numtextures)($17)
	lui	$3,%hi(texturetranslation)
	blez	$4,$L94
	sw	$2,%lo(texturetranslation)($3)

	move	$3,$0
$L95:
	sw	$3,0($2)
	lw	$4,%lo(numtextures)($17)
	addiu	$3,$3,1
	slt	$5,$3,$4
	bne	$5,$0,$L95
	addiu	$2,$2,4

$L94:
	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	sll	$4,$4,2

	lw	$6,%lo(numtextures)($17)
	move	$4,$2
	lui	$16,%hi(textures_hashtable)
	sll	$6,$6,2
	move	$5,$0
	jal	memset
	sw	$2,%lo(textures_hashtable)($16)

	lw	$2,%lo(numtextures)($17)
	blez	$2,$L66
	move	$20,$0

	lw	$2,32($sp)
	lw	$2,%lo(textures)($2)
$L99:
	sll	$18,$20,2
	addu	$2,$2,$18
	lw	$4,0($2)
	jal	W_LumpNameHash
	sw	$20,12($4)

	lw	$4,%lo(numtextures)($17)
	lw	$3,%lo(textures_hashtable)($16)
	divu	$0,$2,$4
	mfhi	$2
	sll	$2,$2,2
	addu	$3,$3,$2
	lw	$2,0($3)
	beq	$2,$0,$L97
	nop

$L98:
	move	$3,$2
	lw	$2,16($2)
	bne	$2,$0,$L98
	addiu	$3,$3,16

$L97:
	lw	$2,32($sp)
	addiu	$20,$20,1
	lw	$2,%lo(textures)($2)
	slt	$4,$20,$4
	addu	$18,$2,$18
	lw	$5,0($18)
	sw	$0,16($5)
	lw	$5,0($18)
	bne	$4,$0,$L99
	sw	$5,0($3)

$L66:
	lw	$31,132($sp)
	lw	$fp,128($sp)
	lw	$23,124($sp)
	lw	$22,120($sp)
	lw	$21,116($sp)
	lw	$20,112($sp)
	lw	$19,108($sp)
	lw	$18,104($sp)
	lw	$17,100($sp)
	lw	$16,96($sp)
	jr	$31
	addiu	$sp,$sp,136

$L126:
	jal	printf
	lw	$4,80($sp)

	b	$L132
	lw	$2,52($sp)

$L127:
	jal	I_Error
	addiu	$4,$2,%lo($LC13)

	b	$L133
	lw	$2,44($sp)

$L68:
	lw	$17,92($sp)
	li	$5,1			# 0x1
	jal	W_CacheLumpName
	addiu	$4,$17,%lo($LC5)

	addiu	$4,$17,%lo($LC5)
	sw	$2,72($sp)
	jal	W_GetNumForName
	lw	$17,0($2)

	jal	W_LumpLength
	move	$4,$2

	sw	$2,76($sp)
	lw	$2,52($sp)
	b	$L69
	addu	$2,$2,$17

$L72:
	subu	$2,$2,$19
	addiu	$3,$2,63
	bltz	$3,$L129
	nop

	addiu	$2,$fp,63
	bltz	$2,$L130
	sra	$3,$3,6

$L76:
	sra	$2,$2,6
	addu	$3,$3,$2
	lui	$4,%hi($LC8)
	move	$19,$3
	addiu	$4,$4,%lo($LC8)
	jal	printf
	move	$20,$3

	slt	$2,$19,-8
	bne	$2,$0,$L131
	addiu	$fp,$19,8

	lui	$2,%hi($LC10)
	move	$23,$0
	addiu	$19,$2,%lo($LC10)
$L77:
	move	$4,$19
	jal	printf
	addiu	$23,$23,1

	slt	$2,$fp,$23
	beq	$2,$0,$L77
	lui	$4,%hi($LC9)

	jal	printf
	addiu	$4,$4,%lo($LC9)

	addiu	$23,$20,9
$L78:
	lui	$2,%hi($LC11)
	move	$fp,$0
	addiu	$19,$2,%lo($LC11)
	move	$4,$19
$L136:
	jal	printf
	addiu	$fp,$fp,1

	slt	$2,$23,$fp
	beq	$2,$0,$L136
	move	$4,$19

	b	$L134
	lw	$2,%lo(numtextures)($17)

$L130:
	b	$L76
	addiu	$2,$fp,126

$L129:
	addiu	$3,$2,126
	addiu	$2,$fp,63
	bgez	$2,$L76
	sra	$3,$3,6

	b	$L76
	addiu	$2,$fp,126

$L131:
	lui	$4,%hi($LC9)
	jal	printf
	addiu	$4,$4,%lo($LC9)

	li	$2,-9			# 0xfffffffffffffff7
	.set	noat
	xor	$1,$19,$2
	bne	$1,$0,$L134
	.set	at
	lw	$2,%lo(numtextures)($17)

	b	$L78
	move	$23,$0

	.set	macro
	.set	reorder
	.end	R_InitTextures
	.size	R_InitTextures, .-R_InitTextures
	.section	.rodata.str1.4
	.align	2
$LC15:
	.ascii	"F_START\000"
	.align	2
$LC16:
	.ascii	"F_END\000"
	.text
	.align	2
	.globl	R_InitFlats
	.set	nomips16
	.set	nomicromips
	.ent	R_InitFlats
	.type	R_InitFlats, @function
R_InitFlats:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC15)
	addiu	$sp,$sp,-24
	addiu	$4,$4,%lo($LC15)
	sw	$31,20($sp)
	jal	W_GetNumForName
	sw	$16,16($sp)

	lui	$4,%hi($LC16)
	lui	$16,%hi(firstflat)
	addiu	$2,$2,1
	addiu	$4,$4,%lo($LC16)
	jal	W_GetNumForName
	sw	$2,%lo(firstflat)($16)

	lw	$3,%lo(firstflat)($16)
	addiu	$2,$2,-1
	subu	$3,$2,$3
	addiu	$4,$3,2
	lui	$16,%hi(numflats)
	addiu	$3,$3,1
	sll	$4,$4,2
	lui	$7,%hi(lastflat)
	move	$6,$0
	li	$5,1			# 0x1
	sw	$3,%lo(numflats)($16)
	jal	Z_Malloc
	sw	$2,%lo(lastflat)($7)

	lw	$3,%lo(numflats)($16)
	lui	$4,%hi(flattranslation)
	blez	$3,$L137
	sw	$2,%lo(flattranslation)($4)

	move	$3,$0
$L139:
	sw	$3,0($2)
	lw	$4,%lo(numflats)($16)
	addiu	$3,$3,1
	slt	$4,$3,$4
	bne	$4,$0,$L139
	addiu	$2,$2,4

$L137:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_InitFlats
	.size	R_InitFlats, .-R_InitFlats
	.align	2
	.globl	R_InitSpriteLumps
	.set	nomips16
	.set	nomicromips
	.ent	R_InitSpriteLumps
	.type	R_InitSpriteLumps, @function
R_InitSpriteLumps:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC6)
	addiu	$sp,$sp,-48
	addiu	$4,$4,%lo($LC6)
	sw	$31,44($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$22,40($sp)
	jal	W_GetNumForName
	sw	$21,36($sp)

	lui	$4,%hi($LC7)
	lui	$17,%hi(firstspritelump)
	addiu	$2,$2,1
	addiu	$4,$4,%lo($LC7)
	jal	W_GetNumForName
	sw	$2,%lo(firstspritelump)($17)

	lw	$3,%lo(firstspritelump)($17)
	addiu	$2,$2,-1
	subu	$3,$2,$3
	addiu	$3,$3,1
	sll	$4,$3,2
	lui	$16,%hi(numspritelumps)
	lui	$7,%hi(lastspritelump)
	move	$6,$0
	li	$5,1			# 0x1
	sw	$3,%lo(numspritelumps)($16)
	jal	Z_Malloc
	sw	$2,%lo(lastspritelump)($7)

	lw	$4,%lo(numspritelumps)($16)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	lui	$20,%hi(spritewidth)
	jal	Z_Malloc
	sw	$2,%lo(spritewidth)($20)

	lw	$4,%lo(numspritelumps)($16)
	lui	$19,%hi(spriteoffset)
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	jal	Z_Malloc
	sw	$2,%lo(spriteoffset)($19)

	lw	$3,%lo(numspritelumps)($16)
	lui	$18,%hi(spritetopoffset)
	blez	$3,$L142
	sw	$2,%lo(spritetopoffset)($18)

	lui	$21,%hi($LC12)
	move	$22,$0
	b	$L145
	addiu	$21,$21,%lo($LC12)

$L144:
	lw	$4,%lo(firstspritelump)($17)
$L148:
	li	$5,8			# 0x8
	jal	W_CacheLumpNum
	addu	$4,$22,$4

	lbu	$3,1($2)
	lbu	$6,0($2)
	lw	$4,%lo(spritewidth)($20)
	sll	$3,$3,8
	sll	$5,$22,2
	or	$3,$3,$6
	addu	$4,$4,$5
	sll	$3,$3,16
	sw	$3,0($4)
	lbu	$3,5($2)
	lbu	$6,4($2)
	lw	$4,%lo(spriteoffset)($19)
	sll	$3,$3,8
	or	$3,$3,$6
	addu	$4,$4,$5
	sll	$3,$3,16
	sw	$3,0($4)
	lbu	$3,7($2)
	lbu	$6,6($2)
	lw	$4,%lo(spritetopoffset)($18)
	sll	$2,$3,8
	or	$2,$2,$6
	sll	$2,$2,16
	addu	$3,$4,$5
	sw	$2,0($3)
	lw	$2,%lo(numspritelumps)($16)
	addiu	$22,$22,1
	slt	$2,$22,$2
	beq	$2,$0,$L149
	lw	$31,44($sp)

$L145:
	andi	$2,$22,0x3f
	bne	$2,$0,$L144
	nop

	jal	printf
	move	$4,$21

	b	$L148
	lw	$4,%lo(firstspritelump)($17)

$L142:
	lw	$31,44($sp)
$L149:
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	R_InitSpriteLumps
	.size	R_InitSpriteLumps, .-R_InitSpriteLumps
	.section	.rodata.str1.4
	.align	2
$LC17:
	.ascii	"COLORMAP\000"
	.text
	.align	2
	.globl	R_InitColormaps
	.set	nomips16
	.set	nomicromips
	.ent	R_InitColormaps
	.type	R_InitColormaps, @function
R_InitColormaps:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC17)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	W_GetNumForName
	addiu	$4,$4,%lo($LC17)

	move	$4,$2
	jal	W_CacheLumpNum
	li	$5,1			# 0x1

	lw	$31,20($sp)
	lui	$3,%hi(colormaps)
	sw	$2,%lo(colormaps)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_InitColormaps
	.size	R_InitColormaps, .-R_InitColormaps
	.align	2
	.globl	R_InitData
	.set	nomips16
	.set	nomicromips
	.ent	R_InitData
	.type	R_InitData, @function
R_InitData:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	R_InitTextures
	lui	$16,%hi($LC12)

	jal	printf
	addiu	$4,$16,%lo($LC12)

	jal	R_InitFlats
	nop

	jal	printf
	addiu	$4,$16,%lo($LC12)

	jal	R_InitSpriteLumps
	nop

	jal	printf
	addiu	$4,$16,%lo($LC12)

	lui	$4,%hi($LC17)
	jal	W_GetNumForName
	addiu	$4,$4,%lo($LC17)

	move	$4,$2
	jal	W_CacheLumpNum
	li	$5,1			# 0x1

	lw	$31,20($sp)
	lui	$3,%hi(colormaps)
	lw	$16,16($sp)
	sw	$2,%lo(colormaps)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_InitData
	.size	R_InitData, .-R_InitData
	.section	.rodata.str1.4
	.align	2
$LC18:
	.ascii	"R_FlatNumForName: %s not found\000"
	.text
	.align	2
	.globl	R_FlatNumForName
	.set	nomips16
	.set	nomicromips
	.ent	R_FlatNumForName
	.type	R_FlatNumForName, @function
R_FlatNumForName:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,40($sp)
	sw	$16,36($sp)
	sw	$31,44($sp)
	jal	W_CheckNumForName
	move	$17,$4

	move	$16,$2
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L157
	.set	at
	lui	$2,%hi(firstflat)

	lw	$31,44($sp)
	lw	$2,%lo(firstflat)($2)
	lw	$17,40($sp)
	subu	$2,$16,$2
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,48

$L157:
	addiu	$4,$sp,16
	move	$5,$17
	li	$6,8			# 0x8
	jal	memcpy
	sb	$0,24($sp)

	lui	$4,%hi($LC18)
	addiu	$5,$sp,16
	jal	I_Error
	addiu	$4,$4,%lo($LC18)

	lui	$2,%hi(firstflat)
	lw	$31,44($sp)
	lw	$2,%lo(firstflat)($2)
	lw	$17,40($sp)
	subu	$2,$16,$2
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	R_FlatNumForName
	.size	R_FlatNumForName, .-R_FlatNumForName
	.align	2
	.globl	R_CheckTextureNumForName
	.set	nomips16
	.set	nomicromips
	.ent	R_CheckTextureNumForName
	.type	R_CheckTextureNumForName, @function
R_CheckTextureNumForName:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$3,0($4)
	li	$2,45			# 0x2d
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L159
	.set	at
	nop

	j	R_CheckTextureNumForName.part.0
	nop

$L159:
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	R_CheckTextureNumForName
	.size	R_CheckTextureNumForName, .-R_CheckTextureNumForName
	.section	.rodata.str1.4
	.align	2
$LC19:
	.ascii	"R_TextureNumForName: %s not found\000"
	.text
	.align	2
	.globl	R_TextureNumForName
	.set	nomips16
	.set	nomicromips
	.ent	R_TextureNumForName
	.type	R_TextureNumForName, @function
R_TextureNumForName:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lb	$3,0($4)
	li	$2,45			# 0x2d
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L162
	.set	at
	nop

	addiu	$sp,$sp,-32
	sw	$16,24($sp)
	sw	$31,28($sp)
	jal	R_CheckTextureNumForName.part.0
	move	$16,$4

	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L167
	.set	at
	lui	$4,%hi($LC19)

$L160:
	lw	$31,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L162:
	jr	$31
	move	$2,$0

$L167:
	move	$5,$16
	addiu	$4,$4,%lo($LC19)
	jal	I_Error
	sw	$2,16($sp)

	b	$L160
	lw	$2,16($sp)

	.set	macro
	.set	reorder
	.end	R_TextureNumForName
	.size	R_TextureNumForName, .-R_TextureNumForName
	.align	2
	.globl	R_PrecacheLevel
	.set	nomips16
	.set	nomicromips
	.ent	R_PrecacheLevel
	.type	R_PrecacheLevel, @function
R_PrecacheLevel:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(demoplayback)
	lw	$2,%lo(demoplayback)($2)
	beq	$2,$0,$L210
	nop

	jr	$31
	nop

$L210:
	addiu	$sp,$sp,-72
	sw	$18,40($sp)
	lui	$18,%hi(numflats)
	lw	$4,%lo(numflats)($18)
	move	$6,$0
	li	$5,1			# 0x1
	sw	$31,68($sp)
	sw	$17,36($sp)
	sw	$fp,64($sp)
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	jal	Z_Malloc
	sw	$16,32($sp)

	lw	$6,%lo(numflats)($18)
	move	$5,$0
	move	$4,$2
	jal	memset
	move	$17,$2

	lui	$7,%hi(numsectors)
	lw	$2,%lo(numsectors)($7)
	blez	$2,$L170
	move	$2,$0

	move	$3,$0
	lui	$6,%hi(sectors)
	li	$5,1			# 0x1
$L171:
	lw	$4,%lo(sectors)($6)
	addiu	$2,$2,1
	addu	$4,$4,$3
	lh	$4,8($4)
	addu	$4,$17,$4
	sb	$5,0($4)
	lw	$4,%lo(sectors)($6)
	addu	$4,$4,$3
	lh	$4,10($4)
	addu	$4,$17,$4
	sb	$5,0($4)
	lw	$4,%lo(numsectors)($7)
	slt	$4,$2,$4
	bne	$4,$0,$L171
	addiu	$3,$3,88

$L170:
	lw	$2,%lo(numflats)($18)
	lui	$21,%hi(flatmemory)
	blez	$2,$L172
	sw	$0,%lo(flatmemory)($21)

	move	$16,$0
	lui	$20,%hi(firstflat)
	b	$L174
	lui	$19,%hi(lumpinfo)

$L173:
	addiu	$16,$16,1
	slt	$3,$16,$3
	beq	$3,$0,$L211
	move	$4,$17

$L174:
	addu	$2,$17,$16
$L212:
	lb	$2,0($2)
	beq	$2,$0,$L173
	lw	$3,%lo(numflats)($18)

	lw	$4,%lo(firstflat)($20)
	lw	$3,%lo(lumpinfo)($19)
	addu	$4,$16,$4
	sll	$2,$4,3
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$2,16($2)
	lw	$3,%lo(flatmemory)($21)
	li	$5,8			# 0x8
	addu	$2,$2,$3
	jal	W_CacheLumpNum
	sw	$2,%lo(flatmemory)($21)

	lw	$3,%lo(numflats)($18)
	addiu	$16,$16,1
	slt	$3,$16,$3
	bne	$3,$0,$L212
	addu	$2,$17,$16

$L172:
	move	$4,$17
$L211:
	jal	Z_Free
	lui	$20,%hi(numtextures)

	lw	$4,%lo(numtextures)($20)
	move	$6,$0
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$6,%lo(numtextures)($20)
	move	$5,$0
	move	$4,$2
	jal	memset
	move	$16,$2

	lui	$7,%hi(numsides)
	lw	$2,%lo(numsides)($7)
	blez	$2,$L175
	move	$2,$0

	move	$6,$0
	lui	$5,%hi(sides)
	li	$4,1			# 0x1
$L176:
	lw	$3,%lo(sides)($5)
	addiu	$6,$6,1
	addu	$3,$3,$2
	lh	$3,8($3)
	addu	$3,$16,$3
	sb	$4,0($3)
	lw	$3,%lo(sides)($5)
	addu	$3,$3,$2
	lh	$3,12($3)
	addu	$3,$16,$3
	sb	$4,0($3)
	lw	$3,%lo(sides)($5)
	addu	$3,$3,$2
	lh	$3,10($3)
	addu	$3,$16,$3
	sb	$4,0($3)
	lw	$3,%lo(numsides)($7)
	slt	$3,$6,$3
	bne	$3,$0,$L176
	addiu	$2,$2,20

$L175:
	lui	$2,%hi(skytexture)
	lw	$2,%lo(skytexture)($2)
	li	$3,1			# 0x1
	addu	$2,$16,$2
	sb	$3,0($2)
	lw	$2,%lo(numtextures)($20)
	lui	$fp,%hi(texturememory)
	blez	$2,$L177
	sw	$0,%lo(texturememory)($fp)

	move	$18,$0
	lui	$21,%hi(textures)
	b	$L180
	lui	$19,%hi(lumpinfo)

$L178:
	lw	$2,%lo(numtextures)($20)
$L214:
	addiu	$18,$18,1
	slt	$2,$18,$2
	beq	$2,$0,$L213
	move	$4,$16

$L180:
	addu	$2,$16,$18
$L215:
	lb	$2,0($2)
	beq	$2,$0,$L214
	lw	$2,%lo(numtextures)($20)

	lw	$2,%lo(textures)($21)
	sll	$3,$18,2
	addu	$2,$2,$3
	lw	$17,0($2)
	lh	$2,20($17)
	blez	$2,$L178
	addiu	$23,$17,28

	move	$22,$0
$L179:
	lw	$4,0($23)
	lw	$2,%lo(lumpinfo)($19)
	sll	$3,$4,3
	subu	$3,$3,$4
	sll	$3,$3,2
	addu	$2,$2,$3
	lw	$2,16($2)
	lw	$3,%lo(texturememory)($fp)
	li	$5,8			# 0x8
	addu	$2,$2,$3
	jal	W_CacheLumpNum
	sw	$2,%lo(texturememory)($fp)

	lh	$2,20($17)
	addiu	$22,$22,1
	slt	$2,$22,$2
	bne	$2,$0,$L179
	addiu	$23,$23,8

	lw	$2,%lo(numtextures)($20)
	addiu	$18,$18,1
	slt	$2,$18,$2
	bne	$2,$0,$L215
	addu	$2,$16,$18

$L177:
	move	$4,$16
$L213:
	jal	Z_Free
	lui	$16,%hi(numsprites)

	lw	$4,%lo(numsprites)($16)
	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	sw	$16,24($sp)

	lw	$6,%lo(numsprites)($16)
	move	$4,$2
	move	$5,$0
	jal	memset
	sw	$2,20($sp)

	lui	$4,%hi(thinkercap)
	addiu	$4,$4,%lo(thinkercap)
	lw	$2,4($4)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L181
	.set	at
	nop

	lui	$5,%hi(P_MobjThinker)
	addiu	$5,$5,%lo(P_MobjThinker)
	b	$L183
	li	$6,1			# 0x1

$L182:
	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L181
	.set	at
	nop

$L183:
	lw	$3,8($2)
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L182
	.set	at
	lw	$7,20($sp)

	lw	$3,36($2)
	addu	$3,$7,$3
	sb	$6,0($3)
	lw	$2,4($2)
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L183
	.set	at
	nop

$L181:
	lw	$2,24($sp)
	lui	$fp,%hi(spritememory)
	lw	$2,%lo(numsprites)($2)
	blez	$2,$L184
	sw	$0,%lo(spritememory)($fp)

	lui	$2,%hi(sprites)
	move	$21,$0
	sw	$2,16($sp)
	lui	$18,%hi(lumpinfo)
	b	$L188
	lui	$17,%hi(firstspritelump)

$L185:
	lw	$2,24($sp)
$L217:
	addiu	$21,$21,1
	lw	$2,%lo(numsprites)($2)
	slt	$2,$21,$2
	beq	$2,$0,$L216
	lw	$4,20($sp)

$L188:
	lw	$2,20($sp)
$L218:
	addu	$2,$2,$21
	lb	$2,0($2)
	beq	$2,$0,$L217
	lw	$2,24($sp)

	lw	$2,16($sp)
	sll	$22,$21,3
	lw	$2,%lo(sprites)($2)
	addu	$2,$2,$22
	lw	$3,0($2)
	blez	$3,$L185
	move	$20,$0

	move	$19,$0
$L187:
	lw	$16,4($2)
	addu	$16,$16,$20
	addiu	$23,$16,4
	addiu	$16,$16,20
$L186:
	lh	$4,0($23)
	lw	$2,%lo(firstspritelump)($17)
	lw	$5,%lo(lumpinfo)($18)
	addu	$4,$4,$2
	sll	$2,$4,3
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$5,$2
	lw	$7,%lo(spritememory)($fp)
	lw	$2,16($2)
	addiu	$23,$23,2
	addu	$2,$2,$7
	li	$5,8			# 0x8
	jal	W_CacheLumpNum
	sw	$2,%lo(spritememory)($fp)

	.set	noat
	xor	$1,$23,$16
	bne	$1,$0,$L186
	.set	at
	lw	$2,16($sp)

	addiu	$19,$19,1
	lw	$2,%lo(sprites)($2)
	addu	$2,$2,$22
	lw	$3,0($2)
	slt	$3,$19,$3
	bne	$3,$0,$L187
	addiu	$20,$20,28

	lw	$2,24($sp)
	addiu	$21,$21,1
	lw	$2,%lo(numsprites)($2)
	slt	$2,$21,$2
	bne	$2,$0,$L218
	lw	$2,20($sp)

$L184:
	lw	$4,20($sp)
$L216:
	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	j	Z_Free
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	R_PrecacheLevel
	.size	R_PrecacheLevel, .-R_PrecacheLevel
	.globl	spritememory
	.section	.bss,"aw",@nobits
	.align	2
	.type	spritememory, @object
	.size	spritememory, 4
spritememory:
	.space	4
	.globl	texturememory
	.align	2
	.type	texturememory, @object
	.size	texturememory, 4
texturememory:
	.space	4
	.globl	flatmemory
	.align	2
	.type	flatmemory, @object
	.size	flatmemory, 4
flatmemory:
	.space	4
	.globl	colormaps
	.align	2
	.type	colormaps, @object
	.size	colormaps, 4
colormaps:
	.space	4
	.globl	spritetopoffset
	.align	2
	.type	spritetopoffset, @object
	.size	spritetopoffset, 4
spritetopoffset:
	.space	4
	.globl	spriteoffset
	.align	2
	.type	spriteoffset, @object
	.size	spriteoffset, 4
spriteoffset:
	.space	4
	.globl	spritewidth
	.align	2
	.type	spritewidth, @object
	.size	spritewidth, 4
spritewidth:
	.space	4
	.globl	texturetranslation
	.align	2
	.type	texturetranslation, @object
	.size	texturetranslation, 4
texturetranslation:
	.space	4
	.globl	flattranslation
	.align	2
	.type	flattranslation, @object
	.size	flattranslation, 4
flattranslation:
	.space	4
	.globl	texturecomposite
	.align	2
	.type	texturecomposite, @object
	.size	texturecomposite, 4
texturecomposite:
	.space	4
	.globl	texturecolumnofs
	.align	2
	.type	texturecolumnofs, @object
	.size	texturecolumnofs, 4
texturecolumnofs:
	.space	4
	.globl	texturecolumnlump
	.align	2
	.type	texturecolumnlump, @object
	.size	texturecolumnlump, 4
texturecolumnlump:
	.space	4
	.globl	texturecompositesize
	.align	2
	.type	texturecompositesize, @object
	.size	texturecompositesize, 4
texturecompositesize:
	.space	4
	.globl	textureheight
	.align	2
	.type	textureheight, @object
	.size	textureheight, 4
textureheight:
	.space	4
	.globl	texturewidthmask
	.align	2
	.type	texturewidthmask, @object
	.size	texturewidthmask, 4
texturewidthmask:
	.space	4
	.globl	textures_hashtable
	.align	2
	.type	textures_hashtable, @object
	.size	textures_hashtable, 4
textures_hashtable:
	.space	4
	.globl	textures
	.align	2
	.type	textures, @object
	.size	textures, 4
textures:
	.space	4
	.globl	numtextures
	.align	2
	.type	numtextures, @object
	.size	numtextures, 4
numtextures:
	.space	4
	.globl	numspritelumps
	.align	2
	.type	numspritelumps, @object
	.size	numspritelumps, 4
numspritelumps:
	.space	4
	.globl	lastspritelump
	.align	2
	.type	lastspritelump, @object
	.size	lastspritelump, 4
lastspritelump:
	.space	4
	.globl	firstspritelump
	.align	2
	.type	firstspritelump, @object
	.size	firstspritelump, 4
firstspritelump:
	.space	4
	.globl	numpatches
	.align	2
	.type	numpatches, @object
	.size	numpatches, 4
numpatches:
	.space	4
	.globl	lastpatch
	.align	2
	.type	lastpatch, @object
	.size	lastpatch, 4
lastpatch:
	.space	4
	.globl	firstpatch
	.align	2
	.type	firstpatch, @object
	.size	firstpatch, 4
firstpatch:
	.space	4
	.globl	numflats
	.align	2
	.type	numflats, @object
	.size	numflats, 4
numflats:
	.space	4
	.globl	lastflat
	.align	2
	.type	lastflat, @object
	.size	lastflat, 4
lastflat:
	.space	4
	.globl	firstflat
	.align	2
	.type	firstflat, @object
	.size	firstflat, 4
firstflat:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
