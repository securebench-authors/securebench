	.file	1 "r_draw.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"R_DrawColumn: %i to %i at %i\000"
	.text
	.align	2
	.globl	R_DrawColumn
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawColumn
	.type	R_DrawColumn, @function
R_DrawColumn:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(dc_yh)
	sw	$17,20($sp)
	lui	$17,%hi(dc_yl)
	lw	$6,%lo(dc_yh)($2)
	lw	$5,%lo(dc_yl)($17)
	sw	$16,16($sp)
	subu	$16,$6,$5
	sw	$31,28($sp)
	bltz	$16,$L1
	sw	$18,24($sp)

	lui	$18,%hi(dc_x)
	lw	$7,%lo(dc_x)($18)
	sltu	$2,$7,320
	beq	$2,$0,$L10
	lui	$4,%hi($LC0)

	bltz	$5,$L10
	slt	$2,$6,200

	bne	$2,$0,$L11
	lui	$2,%hi(centery)

	lui	$4,%hi($LC0)
$L10:
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lw	$5,%lo(dc_yl)($17)
	lw	$7,%lo(dc_x)($18)
	lui	$2,%hi(centery)
$L11:
	lw	$9,%lo(centery)($2)
	lui	$6,%hi(dc_iscale)
	lw	$6,%lo(dc_iscale)($6)
	lui	$3,%hi(columnofs)
	sll	$2,$5,2
	addiu	$3,$3,%lo(columnofs)
	subu	$5,$5,$9
	lui	$4,%hi(ylookup)
	sll	$7,$7,2
	addu	$7,$7,$3
	addiu	$4,$4,%lo(ylookup)
	multu	$5,$6
	mflo	$3
	addu	$2,$2,$4
	lui	$8,%hi(dc_texturemid)
	lw	$8,%lo(dc_texturemid)($8)
	lw	$4,0($2)
	lw	$2,0($7)
	addu	$5,$3,$8
	addu	$4,$4,$2
	lui	$9,%hi(dc_source)
	lui	$8,%hi(dc_colormap)
	li	$7,-1			# 0xffffffffffffffff
$L5:
	lw	$2,%lo(dc_source)($9)
	sra	$3,$5,16
	andi	$3,$3,0x7f
	addu	$2,$2,$3
	lbu	$3,0($2)
	lw	$2,%lo(dc_colormap)($8)
	addiu	$4,$4,320
	addu	$2,$2,$3
	lbu	$2,0($2)
	addiu	$16,$16,-1
	sb	$2,-320($4)
	.set	noat
	xor	$1,$16,$7
	bne	$1,$0,$L5
	.set	at
	addu	$5,$5,$6

$L1:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawColumn
	.size	R_DrawColumn, .-R_DrawColumn
	.align	2
	.globl	R_DrawColumnLow
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawColumnLow
	.type	R_DrawColumnLow, @function
R_DrawColumnLow:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(dc_yh)
	sw	$17,20($sp)
	lui	$17,%hi(dc_yl)
	lw	$6,%lo(dc_yh)($2)
	lw	$5,%lo(dc_yl)($17)
	sw	$16,16($sp)
	subu	$16,$6,$5
	sw	$31,28($sp)
	bltz	$16,$L12
	sw	$18,24($sp)

	lui	$18,%hi(dc_x)
	lw	$7,%lo(dc_x)($18)
	sltu	$2,$7,320
	beq	$2,$0,$L20
	lui	$4,%hi($LC0)

	bltz	$5,$L20
	slt	$2,$6,200

	bne	$2,$0,$L21
	lui	$3,%hi(centery)

	lui	$4,%hi($LC0)
$L20:
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lw	$7,%lo(dc_x)($18)
	lw	$5,%lo(dc_yl)($17)
	lui	$3,%hi(centery)
$L21:
	lw	$10,%lo(centery)($3)
	lui	$2,%hi(columnofs)
	lui	$6,%hi(ylookup)
	lui	$8,%hi(dc_iscale)
	sll	$4,$5,2
	sll	$3,$7,3
	addiu	$2,$2,%lo(columnofs)
	lw	$8,%lo(dc_iscale)($8)
	addiu	$6,$6,%lo(ylookup)
	addu	$6,$4,$6
	addu	$4,$3,$2
	subu	$2,$5,$10
	multu	$2,$8
	mflo	$5
	lui	$9,%hi(dc_texturemid)
	lw	$3,0($6)
	lw	$9,%lo(dc_texturemid)($9)
	lw	$6,0($4)
	lw	$4,4($4)
	addu	$2,$5,$9
	addu	$6,$3,$6
	addu	$5,$3,$4
	lui	$10,%hi(dc_source)
	lui	$9,%hi(dc_colormap)
	li	$7,-1			# 0xffffffffffffffff
$L16:
	lw	$3,%lo(dc_source)($10)
	sra	$4,$2,16
	andi	$4,$4,0x7f
	addu	$3,$3,$4
	lbu	$4,0($3)
	lw	$3,%lo(dc_colormap)($9)
	addiu	$6,$6,320
	addu	$3,$3,$4
	lbu	$3,0($3)
	addiu	$5,$5,320
	addiu	$16,$16,-1
	sb	$3,-320($6)
	addu	$2,$2,$8
	.set	noat
	xor	$1,$16,$7
	bne	$1,$0,$L16
	.set	at
	sb	$3,-320($5)

$L12:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawColumnLow
	.size	R_DrawColumnLow, .-R_DrawColumnLow
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"R_DrawFuzzColumn: %i to %i at %i\000"
	.text
	.align	2
	.globl	R_DrawFuzzColumn
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawFuzzColumn
	.type	R_DrawFuzzColumn, @function
R_DrawFuzzColumn:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	lui	$17,%hi(dc_yl)
	lw	$5,%lo(dc_yl)($17)
	sw	$31,28($sp)
	sw	$18,24($sp)
	bne	$5,$0,$L23
	sw	$16,16($sp)

	li	$2,1			# 0x1
	sw	$2,%lo(dc_yl)($17)
	li	$5,1			# 0x1
$L23:
	lui	$2,%hi(viewheight)
	lw	$3,%lo(viewheight)($2)
	lui	$2,%hi(dc_yh)
	lw	$6,%lo(dc_yh)($2)
	addiu	$4,$3,-1
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L33
	.set	at
	subu	$16,$6,$5

	addiu	$6,$3,-2
	sw	$6,%lo(dc_yh)($2)
	subu	$16,$6,$5
$L33:
	bltz	$16,$L22
	lui	$18,%hi(dc_x)

	lw	$7,%lo(dc_x)($18)
	sltu	$2,$7,320
	beq	$2,$0,$L34
	lui	$4,%hi($LC1)

	bltz	$5,$L34
	slt	$2,$6,200

	bne	$2,$0,$L35
	lui	$3,%hi(ylookup)

	lui	$4,%hi($LC1)
$L34:
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	lw	$5,%lo(dc_yl)($17)
	lw	$7,%lo(dc_x)($18)
	lui	$3,%hi(ylookup)
$L35:
	lui	$2,%hi(columnofs)
	addiu	$3,$3,%lo(ylookup)
	addiu	$2,$2,%lo(columnofs)
	sll	$5,$5,2
	sll	$7,$7,2
	addu	$5,$5,$3
	addu	$7,$7,$2
	lw	$3,0($5)
	lw	$2,0($7)
	lui	$6,%hi(fuzzoffset)
	addu	$3,$3,$2
	lui	$5,%hi(fuzzpos)
	addiu	$6,$6,%lo(fuzzoffset)
	lui	$9,%hi(colormaps)
	li	$8,50			# 0x32
	li	$7,-1			# 0xffffffffffffffff
$L29:
	lw	$2,%lo(fuzzpos)($5)
	lw	$4,%lo(colormaps)($9)
	sll	$2,$2,2
	addu	$2,$6,$2
	lw	$2,0($2)
	addu	$2,$3,$2
	lbu	$2,0($2)
	addiu	$3,$3,320
	addu	$2,$4,$2
	lbu	$2,1536($2)
	sb	$2,-320($3)
	lw	$2,%lo(fuzzpos)($5)
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L28
	.set	at
	addiu	$16,$16,-1

	move	$2,$0
$L28:
	.set	noat
	xor	$1,$16,$7
	bne	$1,$0,$L29
	.set	at
	sw	$2,%lo(fuzzpos)($5)

$L22:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawFuzzColumn
	.size	R_DrawFuzzColumn, .-R_DrawFuzzColumn
	.align	2
	.globl	R_DrawFuzzColumnLow
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawFuzzColumnLow
	.type	R_DrawFuzzColumnLow, @function
R_DrawFuzzColumnLow:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	lui	$18,%hi(dc_yl)
	lw	$5,%lo(dc_yl)($18)
	sw	$31,28($sp)
	sw	$17,20($sp)
	bne	$5,$0,$L37
	sw	$16,16($sp)

	li	$2,1			# 0x1
	sw	$2,%lo(dc_yl)($18)
	li	$5,1			# 0x1
$L37:
	lui	$2,%hi(viewheight)
	lw	$3,%lo(viewheight)($2)
	lui	$2,%hi(dc_yh)
	lw	$6,%lo(dc_yh)($2)
	addiu	$4,$3,-1
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L47
	.set	at
	subu	$16,$6,$5

	addiu	$6,$3,-2
	sw	$6,%lo(dc_yh)($2)
	subu	$16,$6,$5
$L47:
	bltz	$16,$L48
	lw	$31,28($sp)

	lui	$2,%hi(dc_x)
	lw	$7,%lo(dc_x)($2)
	sll	$17,$7,1
	sltu	$2,$17,320
	beq	$2,$0,$L49
	lui	$4,%hi($LC1)

	bltz	$5,$L49
	slt	$2,$6,200

	bne	$2,$0,$L50
	addiu	$2,$17,1

	lui	$4,%hi($LC1)
$L49:
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	lw	$5,%lo(dc_yl)($18)
	addiu	$2,$17,1
$L50:
	lui	$3,%hi(columnofs)
	lui	$4,%hi(ylookup)
	addiu	$3,$3,%lo(columnofs)
	addiu	$4,$4,%lo(ylookup)
	sll	$5,$5,2
	sll	$17,$17,2
	sll	$2,$2,2
	addu	$5,$5,$4
	addu	$17,$17,$3
	addu	$2,$2,$3
	lw	$4,0($17)
	lw	$3,0($5)
	lw	$2,0($2)
	lui	$7,%hi(fuzzoffset)
	addu	$4,$3,$4
	lui	$5,%hi(fuzzpos)
	addu	$3,$3,$2
	addiu	$7,$7,%lo(fuzzoffset)
	lui	$8,%hi(colormaps)
	li	$10,50			# 0x32
	li	$9,-1			# 0xffffffffffffffff
$L43:
	lw	$2,%lo(fuzzpos)($5)
	lw	$6,%lo(colormaps)($8)
	sll	$2,$2,2
	addu	$2,$7,$2
	lw	$2,0($2)
	addu	$2,$4,$2
	lbu	$2,0($2)
	addiu	$4,$4,320
	addu	$2,$6,$2
	lbu	$2,1536($2)
	sb	$2,-320($4)
	lw	$2,%lo(fuzzpos)($5)
	lw	$6,%lo(colormaps)($8)
	sll	$2,$2,2
	addu	$2,$7,$2
	lw	$2,0($2)
	addu	$2,$3,$2
	lbu	$2,0($2)
	addiu	$3,$3,320
	addu	$2,$6,$2
	lbu	$2,1536($2)
	sb	$2,-320($3)
	lw	$2,%lo(fuzzpos)($5)
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$10
	bne	$1,$0,$L42
	.set	at
	addiu	$16,$16,-1

	move	$2,$0
$L42:
	.set	noat
	xor	$1,$16,$9
	bne	$1,$0,$L43
	.set	at
	sw	$2,%lo(fuzzpos)($5)

	lw	$31,28($sp)
$L48:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawFuzzColumnLow
	.size	R_DrawFuzzColumnLow, .-R_DrawFuzzColumnLow
	.align	2
	.globl	R_DrawTranslatedColumn
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawTranslatedColumn
	.type	R_DrawTranslatedColumn, @function
R_DrawTranslatedColumn:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(dc_yh)
	sw	$17,20($sp)
	lui	$17,%hi(dc_yl)
	lw	$6,%lo(dc_yh)($2)
	lw	$5,%lo(dc_yl)($17)
	sw	$16,16($sp)
	subu	$16,$6,$5
	sw	$31,28($sp)
	bltz	$16,$L51
	sw	$18,24($sp)

	lui	$18,%hi(dc_x)
	lw	$7,%lo(dc_x)($18)
	sltu	$2,$7,320
	beq	$2,$0,$L59
	lui	$4,%hi($LC0)

	bltz	$5,$L59
	slt	$2,$6,200

	bne	$2,$0,$L60
	lui	$2,%hi(centery)

	lui	$4,%hi($LC0)
$L59:
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lw	$5,%lo(dc_yl)($17)
	lw	$7,%lo(dc_x)($18)
	lui	$2,%hi(centery)
$L60:
	lw	$9,%lo(centery)($2)
	lui	$6,%hi(dc_iscale)
	lw	$8,%lo(dc_iscale)($6)
	lui	$3,%hi(columnofs)
	sll	$2,$5,2
	addiu	$3,$3,%lo(columnofs)
	subu	$5,$5,$9
	lui	$4,%hi(ylookup)
	sll	$7,$7,2
	addu	$7,$7,$3
	addiu	$4,$4,%lo(ylookup)
	multu	$5,$8
	mflo	$3
	addu	$2,$2,$4
	lui	$6,%hi(dc_texturemid)
	lw	$4,0($2)
	lw	$6,%lo(dc_texturemid)($6)
	lw	$2,0($7)
	addu	$5,$3,$6
	addu	$4,$4,$2
	lui	$11,%hi(dc_source)
	lui	$10,%hi(dc_translation)
	lui	$9,%hi(dc_colormap)
	li	$7,-1			# 0xffffffffffffffff
$L55:
	lw	$2,%lo(dc_source)($11)
	sra	$3,$5,16
	addu	$2,$2,$3
	lbu	$6,0($2)
	lw	$3,%lo(dc_translation)($10)
	lw	$2,%lo(dc_colormap)($9)
	addu	$3,$3,$6
	lbu	$3,0($3)
	addiu	$4,$4,320
	addu	$2,$2,$3
	lbu	$2,0($2)
	addiu	$16,$16,-1
	sb	$2,-320($4)
	.set	noat
	xor	$1,$16,$7
	bne	$1,$0,$L55
	.set	at
	addu	$5,$5,$8

$L51:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawTranslatedColumn
	.size	R_DrawTranslatedColumn, .-R_DrawTranslatedColumn
	.align	2
	.globl	R_DrawTranslatedColumnLow
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawTranslatedColumnLow
	.type	R_DrawTranslatedColumnLow, @function
R_DrawTranslatedColumnLow:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	lui	$2,%hi(dc_yh)
	sw	$18,24($sp)
	lui	$18,%hi(dc_yl)
	lw	$6,%lo(dc_yh)($2)
	lw	$5,%lo(dc_yl)($18)
	sw	$16,16($sp)
	subu	$16,$6,$5
	sw	$31,28($sp)
	bltz	$16,$L61
	sw	$17,20($sp)

	lui	$2,%hi(dc_x)
	lw	$17,%lo(dc_x)($2)
	sll	$17,$17,1
	sltu	$2,$17,320
	beq	$2,$0,$L69
	lui	$4,%hi($LC0)

	bltz	$5,$L69
	slt	$2,$6,200

	bne	$2,$0,$L70
	addiu	$2,$17,1

	lui	$4,%hi($LC0)
$L69:
	move	$7,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lw	$5,%lo(dc_yl)($18)
	addiu	$2,$17,1
$L70:
	lui	$4,%hi(centery)
	lui	$3,%hi(columnofs)
	lui	$6,%hi(ylookup)
	lw	$8,%lo(centery)($4)
	addiu	$3,$3,%lo(columnofs)
	sll	$4,$5,2
	lui	$7,%hi(dc_iscale)
	addiu	$6,$6,%lo(ylookup)
	sll	$2,$2,2
	addu	$4,$4,$6
	addu	$2,$2,$3
	lw	$11,%lo(dc_iscale)($7)
	sll	$17,$17,2
	addu	$17,$17,$3
	lw	$3,0($4)
	lw	$4,0($2)
	subu	$2,$5,$8
	multu	$2,$11
	mflo	$5
	lui	$7,%hi(dc_texturemid)
	lw	$7,%lo(dc_texturemid)($7)
	lw	$6,0($17)
	addu	$2,$5,$7
	addu	$6,$3,$6
	addu	$5,$3,$4
	lui	$10,%hi(dc_source)
	lui	$9,%hi(dc_translation)
	lui	$8,%hi(dc_colormap)
	li	$12,-1			# 0xffffffffffffffff
$L65:
	lw	$3,%lo(dc_source)($10)
	sra	$7,$2,16
	addu	$3,$3,$7
	lbu	$13,0($3)
	lw	$4,%lo(dc_translation)($9)
	lw	$3,%lo(dc_colormap)($8)
	addu	$4,$4,$13
	lbu	$4,0($4)
	addiu	$6,$6,320
	addu	$3,$3,$4
	lbu	$3,0($3)
	addiu	$5,$5,320
	sb	$3,-320($6)
	lw	$3,%lo(dc_source)($10)
	lw	$4,%lo(dc_translation)($9)
	addu	$3,$3,$7
	lbu	$7,0($3)
	lw	$3,%lo(dc_colormap)($8)
	addu	$4,$4,$7
	lbu	$4,0($4)
	addiu	$16,$16,-1
	addu	$3,$3,$4
	lbu	$3,0($3)
	addu	$2,$2,$11
	.set	noat
	xor	$1,$16,$12
	bne	$1,$0,$L65
	.set	at
	sb	$3,-320($5)

$L61:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawTranslatedColumnLow
	.size	R_DrawTranslatedColumnLow, .-R_DrawTranslatedColumnLow
	.align	2
	.globl	R_InitTranslationTables
	.set	nomips16
	.set	nomicromips
	.ent	R_InitTranslationTables
	.type	R_InitTranslationTables, @function
R_InitTranslationTables:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	move	$6,$0
	li	$5,1			# 0x1
	sw	$31,20($sp)
	jal	Z_Malloc
	li	$4,768			# 0x300

	lui	$6,%hi(translationtables)
	sw	$2,%lo(translationtables)($6)
	move	$3,$0
	li	$10,256			# 0x100
$L75:
	addiu	$5,$3,-112
	addiu	$8,$3,512
	sltu	$5,$5,16
	andi	$4,$3,0x00ff
	addu	$9,$2,$8
	bne	$5,$0,$L77
	addiu	$7,$3,256

	sb	$4,0($9)
	lw	$2,%lo(translationtables)($6)
	addu	$2,$2,$7
	sb	$4,0($2)
	lw	$2,%lo(translationtables)($6)
	addu	$2,$2,$3
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$10
	beq	$1,$0,$L71
	.set	at
	sb	$4,0($2)

	b	$L75
	lw	$2,%lo(translationtables)($6)

$L71:
	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

$L77:
	andi	$4,$4,0xf
	addu	$2,$2,$3
	addiu	$5,$4,96
	sb	$5,0($2)
	lw	$2,%lo(translationtables)($6)
	addiu	$5,$4,64
	addu	$2,$2,$7
	sb	$5,0($2)
	lw	$2,%lo(translationtables)($6)
	addiu	$4,$4,32
	addu	$2,$2,$8
	sb	$4,0($2)
	lw	$2,%lo(translationtables)($6)
	b	$L75
	addiu	$3,$3,1

	.set	macro
	.set	reorder
	.end	R_InitTranslationTables
	.size	R_InitTranslationTables, .-R_InitTranslationTables
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"R_DrawSpan: %i to %i at %i\000"
	.text
	.align	2
	.globl	R_DrawSpan
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawSpan
	.type	R_DrawSpan, @function
R_DrawSpan:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	sw	$16,16($sp)
	lui	$17,%hi(ds_x1)
	lui	$16,%hi(ds_x2)
	lw	$6,%lo(ds_x2)($16)
	lw	$5,%lo(ds_x1)($17)
	sw	$18,24($sp)
	slt	$2,$6,$5
	lui	$18,%hi(ds_y)
	lw	$7,%lo(ds_y)($18)
	bne	$2,$0,$L79
	sw	$31,28($sp)

	bltz	$5,$L79
	slt	$2,$6,320

	bne	$2,$0,$L84
	sltu	$2,$7,201

$L79:
	lui	$4,%hi($LC2)
$L85:
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	lw	$7,%lo(ds_y)($18)
	lw	$5,%lo(ds_x1)($17)
	lw	$6,%lo(ds_x2)($16)
	lui	$2,%hi(ds_xfrac)
$L86:
	lw	$3,%lo(ds_xfrac)($2)
	lui	$2,%hi(ds_yfrac)
	lw	$9,%lo(ds_yfrac)($2)
	lui	$11,%hi(ylookup)
	lui	$2,%hi(ds_xstep)
	lui	$4,%hi(columnofs)
	lw	$8,%lo(ds_xstep)($2)
	addiu	$11,$11,%lo(ylookup)
	addiu	$4,$4,%lo(columnofs)
	sll	$7,$7,2
	sll	$10,$5,2
	lui	$2,%hi(ds_ystep)
	addu	$7,$7,$11
	addu	$10,$10,$4
	lw	$2,%lo(ds_ystep)($2)
	lw	$4,0($7)
	lw	$11,0($10)
	sra	$7,$9,6
	li	$10,-65536			# 0xffffffffffff0000
	sll	$3,$3,10
	sll	$8,$8,10
	sra	$2,$2,6
	subu	$6,$6,$5
	and	$3,$3,$10
	and	$8,$8,$10
	andi	$7,$7,0xffff
	andi	$2,$2,0xffff
	addu	$4,$4,$11
	addiu	$6,$6,1
	or	$3,$3,$7
	or	$8,$8,$2
	addu	$6,$4,$6
	lui	$10,%hi(ds_source)
	lui	$9,%hi(ds_colormap)
$L81:
	srl	$2,$3,4
	lw	$5,%lo(ds_source)($10)
	srl	$7,$3,26
	andi	$2,$2,0xfc0
	or	$2,$2,$7
	addu	$2,$5,$2
	lbu	$5,0($2)
	lw	$2,%lo(ds_colormap)($9)
	addiu	$4,$4,1
	addu	$2,$2,$5
	lbu	$2,0($2)
	addu	$3,$3,$8
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L81
	.set	at
	sb	$2,-1($4)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L84:
	bne	$2,$0,$L86
	lui	$2,%hi(ds_xfrac)

	b	$L85
	lui	$4,%hi($LC2)

	.set	macro
	.set	reorder
	.end	R_DrawSpan
	.size	R_DrawSpan, .-R_DrawSpan
	.align	2
	.globl	R_DrawSpanLow
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawSpanLow
	.type	R_DrawSpanLow, @function
R_DrawSpanLow:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,20($sp)
	sw	$16,16($sp)
	lui	$17,%hi(ds_x1)
	lui	$16,%hi(ds_x2)
	lw	$6,%lo(ds_x2)($16)
	lw	$5,%lo(ds_x1)($17)
	sw	$18,24($sp)
	slt	$2,$6,$5
	lui	$18,%hi(ds_y)
	lw	$7,%lo(ds_y)($18)
	bne	$2,$0,$L88
	sw	$31,28($sp)

	bltz	$5,$L88
	slt	$2,$6,320

	bne	$2,$0,$L93
	sltu	$2,$7,201

$L88:
	lui	$4,%hi($LC2)
$L94:
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	lw	$6,%lo(ds_x2)($16)
	lw	$5,%lo(ds_x1)($17)
	lw	$7,%lo(ds_y)($18)
	lui	$2,%hi(ds_xfrac)
$L95:
	lw	$4,%lo(ds_xfrac)($2)
	lui	$2,%hi(ds_yfrac)
	lw	$8,%lo(ds_yfrac)($2)
	lui	$11,%hi(ylookup)
	lui	$2,%hi(ds_xstep)
	lui	$3,%hi(columnofs)
	lw	$10,%lo(ds_xstep)($2)
	sll	$9,$5,3
	addiu	$11,$11,%lo(ylookup)
	addiu	$3,$3,%lo(columnofs)
	sll	$7,$7,2
	lui	$2,%hi(ds_ystep)
	addu	$7,$7,$11
	addu	$9,$9,$3
	lw	$2,%lo(ds_ystep)($2)
	lw	$3,0($7)
	lw	$12,0($9)
	subu	$9,$6,$5
	li	$11,-65536			# 0xffffffffffff0000
	sra	$7,$8,6
	sll	$4,$4,10
	sll	$10,$10,10
	sra	$2,$2,6
	addiu	$9,$9,1
	andi	$7,$7,0xffff
	and	$4,$4,$11
	and	$10,$10,$11
	andi	$2,$2,0xffff
	sll	$5,$5,1
	sll	$6,$6,1
	addu	$3,$3,$12
	sll	$9,$9,1
	or	$4,$4,$7
	or	$10,$10,$2
	sw	$5,%lo(ds_x1)($17)
	sw	$6,%lo(ds_x2)($16)
	addu	$9,$3,$9
	lui	$8,%hi(ds_source)
	lui	$7,%hi(ds_colormap)
$L90:
	srl	$2,$4,4
	lw	$5,%lo(ds_source)($8)
	srl	$6,$4,26
	andi	$2,$2,0xfc0
	or	$2,$2,$6
	addu	$5,$5,$2
	lbu	$6,0($5)
	lw	$5,%lo(ds_colormap)($7)
	addiu	$3,$3,2
	addu	$5,$5,$6
	lbu	$5,0($5)
	addu	$4,$4,$10
	sb	$5,-2($3)
	lw	$6,%lo(ds_source)($8)
	lw	$5,%lo(ds_colormap)($7)
	addu	$2,$6,$2
	lbu	$2,0($2)
	addu	$2,$5,$2
	lbu	$2,0($2)
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L90
	.set	at
	sb	$2,-1($3)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L93:
	bne	$2,$0,$L95
	lui	$2,%hi(ds_xfrac)

	b	$L94
	lui	$4,%hi($LC2)

	.set	macro
	.set	reorder
	.end	R_DrawSpanLow
	.size	R_DrawSpanLow, .-R_DrawSpanLow
	.align	2
	.globl	R_InitBuffer
	.set	nomips16
	.set	nomicromips
	.ent	R_InitBuffer
	.type	R_InitBuffer, @function
R_InitBuffer:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,320			# 0x140
	subu	$2,$2,$4
	sra	$2,$2,1
	lui	$3,%hi(viewwindowx)
	blez	$4,$L100
	sw	$2,%lo(viewwindowx)($3)

	lui	$3,%hi(columnofs)
	addiu	$3,$3,%lo(columnofs)
	addu	$6,$4,$2
$L99:
	sw	$2,0($3)
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L99
	.set	at
	addiu	$3,$3,4

	li	$2,320			# 0x140
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L98
	.set	at
	move	$2,$0

$L100:
	li	$2,168			# 0xa8
	subu	$2,$2,$5
	sra	$2,$2,1
$L98:
	lui	$3,%hi(viewwindowy)
	blez	$5,$L106
	sw	$2,%lo(viewwindowy)($3)

	sll	$4,$2,2
	lui	$3,%hi(I_VideoBuffer)
	addu	$4,$4,$2
	lw	$3,%lo(I_VideoBuffer)($3)
	lui	$2,%hi(ylookup)
	sll	$4,$4,6
	addiu	$2,$2,%lo(ylookup)
	sll	$5,$5,2
	addu	$3,$3,$4
	addu	$4,$5,$2
$L102:
	sw	$3,0($2)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L102
	.set	at
	addiu	$3,$3,320

$L106:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_InitBuffer
	.size	R_InitBuffer, .-R_InitBuffer
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"GRNROCK\000"
	.align	2
$LC4:
	.ascii	"FLOOR7_2\000"
	.align	2
$LC5:
	.ascii	"brdr_t\000"
	.align	2
$LC6:
	.ascii	"brdr_b\000"
	.align	2
$LC7:
	.ascii	"brdr_l\000"
	.align	2
$LC8:
	.ascii	"brdr_r\000"
	.align	2
$LC9:
	.ascii	"brdr_tl\000"
	.align	2
$LC10:
	.ascii	"brdr_tr\000"
	.align	2
$LC11:
	.ascii	"brdr_bl\000"
	.align	2
$LC12:
	.ascii	"brdr_br\000"
	.text
	.align	2
	.globl	R_FillBackScreen
	.set	nomips16
	.set	nomicromips
	.ent	R_FillBackScreen
	.type	R_FillBackScreen, @function
R_FillBackScreen:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$22,44($sp)
	lui	$22,%hi(scaledviewwidth)
	lw	$3,%lo(scaledviewwidth)($22)
	sw	$23,48($sp)
	li	$2,320			# 0x140
	lui	$23,%hi(background_buffer)
	lw	$4,%lo(background_buffer)($23)
	sw	$31,52($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L139
	.set	at
	sw	$16,20($sp)

	beq	$4,$0,$L140
	move	$6,$0

$L110:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L141
	.set	at
	lui	$4,%hi($LC3)

	lui	$4,%hi($LC4)
	addiu	$4,$4,%lo($LC4)
$L111:
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	lw	$18,%lo(background_buffer)($23)
	move	$20,$2
	addiu	$18,$18,320
	move	$19,$0
	li	$21,10752			# 0x2a00
$L112:
	andi	$17,$19,0xfc0
	addiu	$16,$18,-320
	addu	$17,$20,$17
	move	$4,$16
$L144:
	li	$6,64			# 0x40
	addiu	$16,$16,64
	jal	memcpy
	move	$5,$17

	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L144
	.set	at
	move	$4,$16

	addiu	$19,$19,64
	.set	noat
	xor	$1,$19,$21
	bne	$1,$0,$L112
	.set	at
	addiu	$18,$16,320

	jal	V_UseBuffer
	lw	$4,%lo(background_buffer)($23)

	lui	$4,%hi($LC5)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC5)

	lw	$3,%lo(scaledviewwidth)($22)
	blez	$3,$L142
	move	$19,$2

	move	$18,$0
	lui	$17,%hi(viewwindowy)
	lui	$16,%hi(viewwindowx)
	lw	$5,%lo(viewwindowy)($17)
$L145:
	lw	$4,%lo(viewwindowx)($16)
	move	$6,$19
	addu	$4,$18,$4
	jal	V_DrawPatch
	addiu	$5,$5,-8

	lw	$2,%lo(scaledviewwidth)($22)
	addiu	$18,$18,8
	slt	$2,$18,$2
	bne	$2,$0,$L145
	lw	$5,%lo(viewwindowy)($17)

$L118:
	lui	$4,%hi($LC6)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC6)

	lw	$3,%lo(scaledviewwidth)($22)
	blez	$3,$L143
	move	$20,$2

	move	$18,$0
	lui	$19,%hi(viewheight)
	lw	$2,%lo(viewheight)($19)
$L146:
	lw	$5,%lo(viewwindowy)($17)
	lw	$4,%lo(viewwindowx)($16)
	addu	$5,$5,$2
	addu	$4,$18,$4
	jal	V_DrawPatch
	move	$6,$20

	lw	$2,%lo(scaledviewwidth)($22)
	addiu	$18,$18,8
	slt	$2,$18,$2
	bne	$2,$0,$L146
	lw	$2,%lo(viewheight)($19)

$L117:
	lui	$4,%hi($LC7)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC7)

	lw	$3,%lo(viewheight)($19)
	move	$20,$2
	blez	$3,$L120
	move	$18,$0

	lw	$5,%lo(viewwindowy)($17)
$L147:
	lw	$4,%lo(viewwindowx)($16)
	addu	$5,$18,$5
	move	$6,$20
	jal	V_DrawPatch
	addiu	$4,$4,-8

	lw	$2,%lo(viewheight)($19)
	addiu	$18,$18,8
	slt	$2,$18,$2
	bne	$2,$0,$L147
	lw	$5,%lo(viewwindowy)($17)

$L120:
	lui	$4,%hi($LC8)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC8)

	lw	$3,%lo(viewheight)($19)
	move	$20,$2
	blez	$3,$L122
	move	$18,$0

	lw	$2,%lo(scaledviewwidth)($22)
$L148:
	lw	$5,%lo(viewwindowy)($17)
	lw	$4,%lo(viewwindowx)($16)
	addu	$5,$18,$5
	addu	$4,$4,$2
	jal	V_DrawPatch
	move	$6,$20

	lw	$2,%lo(viewheight)($19)
	addiu	$18,$18,8
	slt	$2,$18,$2
	bne	$2,$0,$L148
	lw	$2,%lo(scaledviewwidth)($22)

$L122:
	lw	$18,%lo(viewwindowx)($16)
	lw	$20,%lo(viewwindowy)($17)
	lui	$4,%hi($LC9)
	addiu	$4,$4,%lo($LC9)
	jal	W_CacheLumpName
	li	$5,8			# 0x8

	addiu	$18,$18,-8
	addiu	$20,$20,-8
	move	$6,$2
	move	$5,$20
	jal	V_DrawPatch
	move	$4,$18

	lw	$18,%lo(viewwindowx)($16)
	lw	$2,%lo(scaledviewwidth)($22)
	lw	$20,%lo(viewwindowy)($17)
	lui	$4,%hi($LC10)
	addiu	$4,$4,%lo($LC10)
	li	$5,8			# 0x8
	addu	$18,$18,$2
	jal	W_CacheLumpName
	addiu	$20,$20,-8

	move	$6,$2
	move	$5,$20
	jal	V_DrawPatch
	move	$4,$18

	lw	$18,%lo(viewwindowx)($16)
	lw	$20,%lo(viewwindowy)($17)
	lw	$2,%lo(viewheight)($19)
	lui	$4,%hi($LC11)
	addiu	$4,$4,%lo($LC11)
	li	$5,8			# 0x8
	addu	$20,$20,$2
	jal	W_CacheLumpName
	addiu	$18,$18,-8

	move	$6,$2
	move	$5,$20
	jal	V_DrawPatch
	move	$4,$18

	lw	$3,%lo(scaledviewwidth)($22)
	lw	$2,%lo(viewheight)($19)
	lw	$16,%lo(viewwindowx)($16)
	lw	$17,%lo(viewwindowy)($17)
	lui	$4,%hi($LC12)
	addiu	$4,$4,%lo($LC12)
	li	$5,8			# 0x8
	addu	$16,$16,$3
	jal	W_CacheLumpName
	addu	$17,$17,$2

	move	$6,$2
	move	$5,$17
	jal	V_DrawPatch
	move	$4,$16

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	V_RestoreBuffer
	addiu	$sp,$sp,56

$L141:
	b	$L111
	addiu	$4,$4,%lo($LC3)

$L139:
	beq	$4,$0,$L149
	lw	$31,52($sp)

	jal	Z_Free
	nop

	sw	$0,%lo(background_buffer)($23)
	lw	$31,52($sp)
$L149:
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L140:
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,53760			# 0xd200

	b	$L110
	sw	$2,%lo(background_buffer)($23)

$L142:
	lui	$17,%hi(viewwindowy)
	b	$L118
	lui	$16,%hi(viewwindowx)

$L143:
	b	$L117
	lui	$19,%hi(viewheight)

	.set	macro
	.set	reorder
	.end	R_FillBackScreen
	.size	R_FillBackScreen, .-R_FillBackScreen
	.align	2
	.globl	R_VideoErase
	.set	nomips16
	.set	nomicromips
	.ent	R_VideoErase
	.type	R_VideoErase, @function
R_VideoErase:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(background_buffer)
	lw	$2,%lo(background_buffer)($2)
	beq	$2,$0,$L152
	move	$6,$5

	lui	$3,%hi(I_VideoBuffer)
	lw	$3,%lo(I_VideoBuffer)($3)
	addu	$5,$2,$4
	j	memcpy
	addu	$4,$3,$4

$L152:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_VideoErase
	.size	R_VideoErase, .-R_VideoErase
	.align	2
	.globl	R_DrawViewBorder
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawViewBorder
	.type	R_DrawViewBorder, @function
R_DrawViewBorder:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(scaledviewwidth)
	lw	$4,%lo(scaledviewwidth)($2)
	li	$2,320			# 0x140
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L174
	.set	at
	nop

	addiu	$sp,$sp,-48
	sw	$20,36($sp)
	lui	$20,%hi(viewheight)
	lw	$6,%lo(viewheight)($20)
	li	$3,168			# 0xa8
	subu	$3,$3,$6
	subu	$2,$2,$4
	sw	$18,28($sp)
	lui	$18,%hi(background_buffer)
	sw	$19,32($sp)
	sw	$16,20($sp)
	srl	$19,$2,31
	srl	$16,$3,31
	lw	$5,%lo(background_buffer)($18)
	addu	$16,$16,$3
	addu	$19,$19,$2
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$17,24($sp)
	sra	$16,$16,1
	beq	$5,$0,$L155
	sra	$19,$19,1

	sll	$17,$16,2
	addu	$17,$17,$16
	sll	$17,$17,6
	lui	$21,%hi(I_VideoBuffer)
	lw	$4,%lo(I_VideoBuffer)($21)
	addu	$17,$17,$19
	jal	memcpy
	move	$6,$17

	lw	$6,%lo(viewheight)($20)
	lw	$5,%lo(background_buffer)($18)
	addu	$2,$6,$16
	sll	$3,$2,2
	addu	$3,$3,$2
	sll	$3,$3,6
	beq	$5,$0,$L155
	subu	$3,$3,$19

	lw	$4,%lo(I_VideoBuffer)($21)
	move	$6,$17
	addu	$5,$5,$3
	jal	memcpy
	addu	$4,$4,$3

	lw	$6,%lo(viewheight)($20)
$L155:
	addiu	$2,$16,1
	sll	$16,$2,2
	addu	$16,$16,$2
	sll	$16,$16,6
	slt	$2,$6,2
	subu	$16,$16,$19
	li	$17,1			# 0x1
	bne	$2,$0,$L158
	sll	$19,$19,1

	lui	$21,%hi(I_VideoBuffer)
$L156:
	lw	$2,%lo(background_buffer)($18)
	addiu	$17,$17,1
	addu	$5,$2,$16
	beq	$2,$0,$L157
	move	$6,$19

	lw	$4,%lo(I_VideoBuffer)($21)
	jal	memcpy
	addu	$4,$4,$16

$L157:
	lw	$2,%lo(viewheight)($20)
	slt	$2,$17,$2
	bne	$2,$0,$L156
	addiu	$16,$16,320

$L158:
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$7,168			# 0xa8
	li	$6,320			# 0x140
	move	$5,$0
	move	$4,$0
	j	V_MarkRect
	addiu	$sp,$sp,48

$L174:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_DrawViewBorder
	.size	R_DrawViewBorder, .-R_DrawViewBorder
	.globl	dscount
	.section	.bss,"aw",@nobits
	.align	2
	.type	dscount, @object
	.size	dscount, 4
dscount:
	.space	4
	.globl	ds_source
	.align	2
	.type	ds_source, @object
	.size	ds_source, 4
ds_source:
	.space	4
	.globl	ds_ystep
	.align	2
	.type	ds_ystep, @object
	.size	ds_ystep, 4
ds_ystep:
	.space	4
	.globl	ds_xstep
	.align	2
	.type	ds_xstep, @object
	.size	ds_xstep, 4
ds_xstep:
	.space	4
	.globl	ds_yfrac
	.align	2
	.type	ds_yfrac, @object
	.size	ds_yfrac, 4
ds_yfrac:
	.space	4
	.globl	ds_xfrac
	.align	2
	.type	ds_xfrac, @object
	.size	ds_xfrac, 4
ds_xfrac:
	.space	4
	.globl	ds_colormap
	.align	2
	.type	ds_colormap, @object
	.size	ds_colormap, 4
ds_colormap:
	.space	4
	.globl	ds_x2
	.align	2
	.type	ds_x2, @object
	.size	ds_x2, 4
ds_x2:
	.space	4
	.globl	ds_x1
	.align	2
	.type	ds_x1, @object
	.size	ds_x1, 4
ds_x1:
	.space	4
	.globl	ds_y
	.align	2
	.type	ds_y, @object
	.size	ds_y, 4
ds_y:
	.space	4
	.globl	translationtables
	.align	2
	.type	translationtables, @object
	.size	translationtables, 4
translationtables:
	.space	4
	.globl	dc_translation
	.align	2
	.type	dc_translation, @object
	.size	dc_translation, 4
dc_translation:
	.space	4
	.globl	fuzzpos
	.align	2
	.type	fuzzpos, @object
	.size	fuzzpos, 4
fuzzpos:
	.space	4
	.globl	fuzzoffset
	.data
	.align	2
	.type	fuzzoffset, @object
	.size	fuzzoffset, 200
fuzzoffset:
	.word	320
	.word	-320
	.word	320
	.word	-320
	.word	320
	.word	320
	.word	-320
	.word	320
	.word	320
	.word	-320
	.word	320
	.word	320
	.word	320
	.word	-320
	.word	320
	.word	320
	.word	320
	.word	-320
	.word	-320
	.word	-320
	.word	-320
	.word	320
	.word	-320
	.word	-320
	.word	320
	.word	320
	.word	320
	.word	320
	.word	-320
	.word	320
	.word	-320
	.word	320
	.word	320
	.word	-320
	.word	-320
	.word	320
	.word	320
	.word	-320
	.word	-320
	.word	-320
	.word	-320
	.word	320
	.word	320
	.word	320
	.word	320
	.word	-320
	.word	320
	.word	320
	.word	-320
	.word	320
	.globl	dccount
	.section	.bss
	.align	2
	.type	dccount, @object
	.size	dccount, 4
dccount:
	.space	4
	.globl	dc_source
	.align	2
	.type	dc_source, @object
	.size	dc_source, 4
dc_source:
	.space	4
	.globl	dc_texturemid
	.align	2
	.type	dc_texturemid, @object
	.size	dc_texturemid, 4
dc_texturemid:
	.space	4
	.globl	dc_iscale
	.align	2
	.type	dc_iscale, @object
	.size	dc_iscale, 4
dc_iscale:
	.space	4
	.globl	dc_yh
	.align	2
	.type	dc_yh, @object
	.size	dc_yh, 4
dc_yh:
	.space	4
	.globl	dc_yl
	.align	2
	.type	dc_yl, @object
	.size	dc_yl, 4
dc_yl:
	.space	4
	.globl	dc_x
	.align	2
	.type	dc_x, @object
	.size	dc_x, 4
dc_x:
	.space	4
	.globl	dc_colormap
	.align	2
	.type	dc_colormap, @object
	.size	dc_colormap, 4
dc_colormap:
	.space	4
	.local	background_buffer
	.comm	background_buffer,4,4
	.globl	translations
	.align	2
	.type	translations, @object
	.size	translations, 768
translations:
	.space	768
	.globl	columnofs
	.align	2
	.type	columnofs, @object
	.size	columnofs, 4480
columnofs:
	.space	4480
	.globl	ylookup
	.align	2
	.type	ylookup, @object
	.size	ylookup, 3328
ylookup:
	.space	3328
	.globl	viewwindowy
	.align	2
	.type	viewwindowy, @object
	.size	viewwindowy, 4
viewwindowy:
	.space	4
	.globl	viewwindowx
	.align	2
	.type	viewwindowx, @object
	.size	viewwindowx, 4
viewwindowx:
	.space	4
	.globl	viewheight
	.align	2
	.type	viewheight, @object
	.size	viewheight, 4
viewheight:
	.space	4
	.globl	scaledviewwidth
	.align	2
	.type	scaledviewwidth, @object
	.size	scaledviewwidth, 4
scaledviewwidth:
	.space	4
	.globl	viewwidth
	.align	2
	.type	viewwidth, @object
	.size	viewwidth, 4
viewwidth:
	.space	4
	.globl	viewimage
	.align	2
	.type	viewimage, @object
	.size	viewimage, 4
viewimage:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
