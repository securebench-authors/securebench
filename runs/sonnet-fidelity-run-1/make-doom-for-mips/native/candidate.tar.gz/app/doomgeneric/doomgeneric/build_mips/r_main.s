	.file	1 "r_main.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	R_AddPointToBox
	.set	nomips16
	.set	nomicromips
	.ent	R_AddPointToBox
	.type	R_AddPointToBox, @function
R_AddPointToBox:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,8($6)
	slt	$2,$4,$2
	beq	$2,$0,$L2
	nop

	sw	$4,8($6)
$L2:
	lw	$2,12($6)
	slt	$2,$2,$4
	beq	$2,$0,$L3
	nop

	sw	$4,12($6)
$L3:
	lw	$2,4($6)
	slt	$2,$5,$2
	beq	$2,$0,$L4
	nop

	sw	$5,4($6)
$L4:
	lw	$2,0($6)
	slt	$2,$2,$5
	beq	$2,$0,$L7
	nop

	sw	$5,0($6)
$L7:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_AddPointToBox
	.size	R_AddPointToBox, .-R_AddPointToBox
	.align	2
	.globl	R_PointOnSide
	.set	nomips16
	.set	nomicromips
	.ent	R_PointOnSide
	.type	R_PointOnSide, @function
R_PointOnSide:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,8($6)
	bne	$3,$0,$L9
	lw	$2,12($6)

	lw	$3,0($6)
	slt	$3,$3,$4
	bne	$3,$0,$L10
	nop

	jr	$31
	slt	$2,$0,$2

$L9:
	bne	$2,$0,$L12
	lw	$7,4($6)

	slt	$5,$7,$5
	bne	$5,$0,$L13
	nop

	jr	$31
	srl	$2,$3,31

$L12:
	lw	$8,0($6)
	addiu	$sp,$sp,-24
	xor	$3,$3,$2
	subu	$4,$4,$8
	xor	$3,$3,$4
	sw	$16,16($sp)
	subu	$16,$5,$7
	xor	$3,$3,$16
	bgez	$3,$L14
	sw	$31,20($sp)

	lw	$31,20($sp)
	xor	$4,$4,$2
	lw	$16,16($sp)
	srl	$2,$4,31
	jr	$31
	addiu	$sp,$sp,24

$L10:
	jr	$31
	srl	$2,$2,31

$L13:
	jr	$31
	slt	$2,$0,$3

$L14:
	move	$5,$4
	sra	$4,$2,16
	jal	FixedMul
	sw	$6,32($sp)

	lw	$6,32($sp)
	move	$4,$16
	lh	$5,10($6)
	jal	FixedMul
	move	$16,$2

	lw	$31,20($sp)
	slt	$2,$2,$16
	xori	$2,$2,0x1
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_PointOnSide
	.size	R_PointOnSide, .-R_PointOnSide
	.align	2
	.globl	R_PointOnSegSide
	.set	nomips16
	.set	nomicromips
	.ent	R_PointOnSegSide
	.type	R_PointOnSegSide, @function
R_PointOnSegSide:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,0($6)
	lw	$2,4($6)
	lw	$3,0($7)
	lw	$6,4($7)
	lw	$7,0($2)
	lw	$2,4($2)
	addiu	$sp,$sp,-32
	subu	$2,$2,$6
	sw	$17,24($sp)
	sw	$31,28($sp)
	sw	$16,20($sp)
	.set	noat
	xor	$1,$7,$3
	bne	$1,$0,$L19
	.set	at
	subu	$17,$7,$3

	slt	$4,$3,$4
	beq	$4,$0,$L27
	lw	$31,28($sp)

$L26:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	srl	$2,$2,31
	jr	$31
	addiu	$sp,$sp,32

$L19:
	bne	$2,$0,$L22
	subu	$16,$5,$6

	slt	$6,$6,$5
	bne	$6,$0,$L23
	lw	$31,28($sp)

	lw	$16,20($sp)
	srl	$2,$17,31
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L27:
	lw	$17,24($sp)
	lw	$16,20($sp)
	slt	$2,$0,$2
	jr	$31
	addiu	$sp,$sp,32

$L22:
	subu	$4,$4,$3
	xor	$3,$17,$2
	xor	$3,$3,$4
	xor	$3,$3,$16
	bgez	$3,$L24
	nop

	b	$L26
	xor	$2,$2,$4

$L23:
	lw	$16,20($sp)
	slt	$2,$0,$17
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L24:
	move	$5,$4
	jal	FixedMul
	sra	$4,$2,16

	sra	$5,$17,16
	move	$4,$16
	jal	FixedMul
	move	$16,$2

	lw	$31,28($sp)
	slt	$2,$2,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	xori	$2,$2,0x1
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_PointOnSegSide
	.size	R_PointOnSegSide, .-R_PointOnSegSide
	.align	2
	.globl	R_PointToAngle
	.set	nomips16
	.set	nomicromips
	.ent	R_PointToAngle
	.type	R_PointToAngle, @function
R_PointToAngle:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(viewx)
	lw	$3,%lo(viewx)($2)
	lui	$2,%hi(viewy)
	lw	$6,%lo(viewy)($2)
	addiu	$sp,$sp,-24
	move	$2,$4
	subu	$7,$4,$3
	subu	$4,$5,$6
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L29
	.set	at
	sw	$31,20($sp)

	beq	$4,$0,$L38
	move	$2,$0

	bltz	$4,$L32
	nop

	move	$5,$4
$L41:
	jal	SlopeDiv
	move	$4,$7

	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,0($2)
	li	$2,1073676288			# 0x3fff0000
	ori	$2,$2,0xffff
	subu	$2,$2,$3
$L28:
	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

$L29:
	bgez	$7,$L40
	nop

	bltz	$4,$L35
	subu	$3,$3,$2

	slt	$2,$4,$3
	beq	$2,$0,$L36
	move	$5,$4

	jal	SlopeDiv
	move	$5,$3

	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,0($2)
	lw	$31,20($sp)
	li	$2,2147418112			# 0x7fff0000
	ori	$2,$2,0xffff
	subu	$2,$2,$3
	jr	$31
	addiu	$sp,$sp,24

$L32:
	subu	$4,$6,$5
	slt	$2,$4,$7
	beq	$2,$0,$L34
	move	$5,$4

	jal	SlopeDiv
	move	$5,$7

	lui	$3,%hi(tantoangle)
	sll	$2,$2,2
	addiu	$3,$3,%lo(tantoangle)
	addu	$2,$2,$3
	lw	$31,20($sp)
	lw	$2,0($2)
	addiu	$sp,$sp,24
	jr	$31
	subu	$2,$0,$2

$L38:
	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

$L40:
	bltz	$4,$L32
	slt	$2,$4,$7

	beq	$2,$0,$L41
	move	$5,$4

	jal	SlopeDiv
	move	$5,$7

	lui	$3,%hi(tantoangle)
	lw	$31,20($sp)
	sll	$2,$2,2
	addiu	$3,$3,%lo(tantoangle)
	addu	$2,$2,$3
	lw	$2,0($2)
	jr	$31
	addiu	$sp,$sp,24

$L34:
	jal	SlopeDiv
	move	$4,$7

	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$31,20($sp)
	lw	$2,0($2)
	li	$3,-1073741824			# 0xffffffffc0000000
	addu	$2,$2,$3
	jr	$31
	addiu	$sp,$sp,24

$L36:
	jal	SlopeDiv
	move	$4,$3

	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$31,20($sp)
	lw	$2,0($2)
	li	$3,1073741824			# 0x40000000
	addu	$2,$2,$3
	jr	$31
	addiu	$sp,$sp,24

$L35:
	subu	$4,$6,$5
	slt	$2,$4,$3
	beq	$2,$0,$L37
	move	$5,$4

	jal	SlopeDiv
	move	$5,$3

	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$2,0($2)
	li	$3,-2147483648			# 0xffffffff80000000
	b	$L28
	addu	$2,$2,$3

$L37:
	jal	SlopeDiv
	move	$4,$3

	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,0($2)
	li	$2,-1073807360			# 0xffffffffbfff0000
	ori	$2,$2,0xffff
	b	$L28
	subu	$2,$2,$3

	.set	macro
	.set	reorder
	.end	R_PointToAngle
	.size	R_PointToAngle, .-R_PointToAngle
	.align	2
	.globl	R_PointToAngle2
	.set	nomips16
	.set	nomicromips
	.ent	R_PointToAngle2
	.type	R_PointToAngle2, @function
R_PointToAngle2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	move	$8,$4
	lui	$2,%hi(viewx)
	move	$3,$5
	sw	$8,%lo(viewx)($2)
	move	$5,$7
	lui	$2,%hi(viewy)
	move	$4,$6
	j	R_PointToAngle
	sw	$3,%lo(viewy)($2)

	.set	macro
	.set	reorder
	.end	R_PointToAngle2
	.size	R_PointToAngle2, .-R_PointToAngle2
	.align	2
	.globl	R_PointToDist
	.set	nomips16
	.set	nomicromips
	.ent	R_PointToDist
	.type	R_PointToDist, @function
R_PointToDist:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(viewx)
	lw	$2,%lo(viewx)($2)
	addiu	$sp,$sp,-32
	subu	$4,$4,$2
	sw	$31,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	jal	abs
	move	$17,$5

	lui	$3,%hi(viewy)
	lw	$4,%lo(viewy)($3)
	move	$16,$2
	jal	abs
	subu	$4,$17,$4

	move	$4,$2
	slt	$2,$16,$2
	beq	$2,$0,$L44
	move	$2,$16

	move	$16,$4
	move	$4,$2
$L44:
	bne	$16,$0,$L48
	nop

	move	$2,$0
$L45:
	lui	$3,%hi(tantoangle)
	addiu	$3,$3,%lo(tantoangle)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$3,0($2)
	li	$2,1073741824			# 0x40000000
	addu	$3,$3,$2
	srl	$3,$3,19
	lui	$2,%hi(finesine)
	sll	$3,$3,2
	addiu	$2,$2,%lo(finesine)
	addu	$3,$3,$2
	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$4,$16
	lw	$5,0($3)
	lw	$16,20($sp)
	j	FixedDiv
	addiu	$sp,$sp,32

$L48:
	jal	FixedDiv
	move	$5,$16

	b	$L45
	sra	$2,$2,5

	.set	macro
	.set	reorder
	.end	R_PointToDist
	.size	R_PointToDist, .-R_PointToDist
	.align	2
	.globl	R_InitPointToAngle
	.set	nomips16
	.set	nomicromips
	.ent	R_InitPointToAngle
	.type	R_InitPointToAngle, @function
R_InitPointToAngle:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_InitPointToAngle
	.size	R_InitPointToAngle, .-R_InitPointToAngle
	.align	2
	.globl	R_ScaleFromGlobalAngle
	.set	nomips16
	.set	nomicromips
	.ent	R_ScaleFromGlobalAngle
	.type	R_ScaleFromGlobalAngle, @function
R_ScaleFromGlobalAngle:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(rw_normalangle)
	lw	$3,%lo(rw_normalangle)($2)
	li	$2,1073741824			# 0x40000000
	subu	$3,$2,$3
	lui	$5,%hi(viewangle)
	lw	$5,%lo(viewangle)($5)
	addu	$3,$3,$4
	srl	$3,$3,19
	lui	$6,%hi(finesine)
	addiu	$6,$6,%lo(finesine)
	subu	$2,$2,$5
	sll	$3,$3,2
	addu	$3,$3,$6
	addu	$2,$2,$4
	lw	$5,0($3)
	srl	$2,$2,19
	lui	$3,%hi(projection)
	lw	$4,%lo(projection)($3)
	sll	$2,$2,2
	addiu	$sp,$sp,-24
	addu	$2,$2,$6
	sw	$31,20($sp)
	sw	$16,16($sp)
	jal	FixedMul
	lw	$16,0($2)

	lui	$3,%hi(detailshift)
	lui	$4,%hi(rw_distance)
	lw	$3,%lo(detailshift)($3)
	lw	$4,%lo(rw_distance)($4)
	move	$5,$16
	jal	FixedMul
	sll	$16,$2,$3

	move	$5,$2
	sra	$2,$16,16
	slt	$2,$2,$5
	bne	$2,$0,$L54
	lw	$31,20($sp)

	lw	$16,16($sp)
	li	$2,4194304			# 0x400000
	jr	$31
	addiu	$sp,$sp,24

$L54:
	jal	FixedDiv
	move	$4,$16

	slt	$5,$2,256
	li	$4,4194304			# 0x400000
	li	$3,256			# 0x100
	movn	$2,$3,$5
	lw	$31,20($sp)
	addiu	$3,$4,1
	slt	$3,$2,$3
	lw	$16,16($sp)
	movz	$2,$4,$3
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_ScaleFromGlobalAngle
	.size	R_ScaleFromGlobalAngle, .-R_ScaleFromGlobalAngle
	.align	2
	.globl	R_InitTables
	.set	nomips16
	.set	nomicromips
	.ent	R_InitTables
	.type	R_InitTables, @function
R_InitTables:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_InitTables
	.size	R_InitTables, .-R_InitTables
	.align	2
	.globl	R_InitTextureMapping
	.set	nomips16
	.set	nomicromips
	.ent	R_InitTextureMapping
	.type	R_InitTextureMapping, @function
R_InitTextureMapping:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$23,52($sp)
	lui	$23,%hi(finetangent)
	addiu	$23,$23,%lo(finetangent)
	lui	$2,%hi(centerxfrac)
	lw	$5,12288($23)
	lw	$4,%lo(centerxfrac)($2)
	sw	$fp,56($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	sw	$31,60($sp)
	jal	FixedDiv
	sw	$2,16($sp)

	lui	$3,%hi(viewangletox)
	addiu	$16,$3,%lo(viewangletox)
	li	$6,131072			# 0x20000
	sw	$3,20($sp)
	move	$18,$2
	addiu	$20,$23,16384
	move	$fp,$16
	move	$17,$23
	lui	$19,%hi(viewwidth)
	addiu	$21,$6,1
	b	$L61
	li	$22,-131072			# 0xfffffffffffe0000

$L57:
	beq	$3,$0,$L59
	lw	$3,%lo(viewwidth)($19)

	addiu	$3,$3,1
$L58:
	addiu	$17,$17,4
	sw	$3,0($fp)
	.set	noat
	xor	$1,$17,$20
	beq	$1,$0,$L76
	.set	at
	addiu	$fp,$fp,4

$L61:
	lw	$4,0($17)
	slt	$2,$4,$21
	bne	$2,$0,$L57
	slt	$3,$4,$22

$L60:
	li	$3,-1			# 0xffffffffffffffff
	addiu	$17,$17,4
	sw	$3,0($fp)
	.set	noat
	xor	$1,$17,$20
	bne	$1,$0,$L61
	.set	at
	addiu	$fp,$fp,4

$L76:
	lw	$7,%lo(viewwidth)($19)
	bltz	$7,$L62
	lui	$17,%hi(xtoviewangle)

	lw	$2,20($sp)
	addiu	$6,$17,%lo(xtoviewangle)
	lw	$8,%lo(viewangletox)($2)
	addiu	$7,$7,1
	move	$5,$0
	li	$10,-1073741824			# 0xffffffffc0000000
	lui	$9,%hi(viewangletox+4)
$L63:
	slt	$2,$5,$8
	beq	$2,$0,$L66
	li	$4,-1073741824			# 0xffffffffc0000000

	addiu	$3,$9,%lo(viewangletox+4)
	move	$4,$0
$L64:
	lw	$2,0($3)
	addiu	$4,$4,1
	slt	$2,$5,$2
	bne	$2,$0,$L64
	addiu	$3,$3,4

	sll	$4,$4,19
	addu	$4,$4,$10
$L66:
	addiu	$5,$5,1
	sw	$4,0($6)
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L63
	.set	at
	addiu	$6,$6,4

$L62:
	addiu	$21,$16,16384
	b	$L69
	li	$20,-1			# 0xffffffffffffffff

$L67:
	addiu	$4,$3,1
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L68
	.set	at
	nop

	sw	$3,0($16)
$L68:
	addiu	$16,$16,4
	.set	noat
	xor	$1,$16,$21
	beq	$1,$0,$L77
	.set	at
	addiu	$23,$23,4

$L69:
	lw	$4,0($23)
	jal	FixedMul
	move	$5,$18

	lw	$2,0($16)
	.set	noat
	xor	$1,$2,$20
	bne	$1,$0,$L67
	.set	at
	lw	$3,%lo(viewwidth)($19)

	sw	$0,0($16)
	addiu	$16,$16,4
	.set	noat
	xor	$1,$16,$21
	bne	$1,$0,$L69
	.set	at
	addiu	$23,$23,4

$L77:
	lw	$3,%lo(xtoviewangle)($17)
	lw	$31,60($sp)
	lui	$2,%hi(clipangle)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	sw	$3,%lo(clipangle)($2)
	jr	$31
	addiu	$sp,$sp,64

$L59:
	jal	FixedMul
	move	$5,$18

	lw	$3,16($sp)
	lw	$3,%lo(centerxfrac)($3)
	subu	$2,$3,$2
	li	$3,65535			# 0xffff
	addu	$2,$2,$3
	sra	$2,$2,16
	slt	$3,$2,-1
	bne	$3,$0,$L60
	lw	$3,%lo(viewwidth)($19)

	addiu	$3,$3,1
	slt	$4,$2,$3
	b	$L58
	movn	$3,$2,$4

	.set	macro
	.set	reorder
	.end	R_InitTextureMapping
	.size	R_InitTextureMapping, .-R_InitTextureMapping
	.align	2
	.globl	R_InitLightTables
	.set	nomips16
	.set	nomicromips
	.ent	R_InitLightTables
	.type	R_InitLightTables, @function
R_InitLightTables:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$21,36($sp)
	lui	$21,%hi(zlight)
	sw	$22,40($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	addiu	$21,$21,%lo(zlight)
	li	$16,60			# 0x3c
	lui	$20,%hi(colormaps)
	li	$19,31			# 0x1f
	li	$18,1048576			# 0x100000
	li	$17,135266304			# 0x8100000
	li	$22,-4			# 0xfffffffffffffffc
$L80:
	move	$fp,$21
	li	$23,1048576			# 0x100000
$L79:
	move	$5,$23
	jal	FixedDiv
	li	$4,10485760			# 0xa00000

	sra	$3,$2,12
	srl	$2,$2,31
	addu	$2,$2,$3
	sra	$2,$2,1
	subu	$2,$16,$2
	slt	$3,$2,32
	movz	$2,$19,$3
	slt	$4,$2,0
	lw	$3,%lo(colormaps)($20)
	movn	$2,$0,$4
	sll	$2,$2,8
	addu	$2,$3,$2
	addu	$23,$23,$18
	sw	$2,0($fp)
	.set	noat
	xor	$1,$23,$17
	bne	$1,$0,$L79
	.set	at
	addiu	$fp,$fp,4

	addiu	$16,$16,-4
	.set	noat
	xor	$1,$16,$22
	bne	$1,$0,$L80
	.set	at
	addiu	$21,$21,512

	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	R_InitLightTables
	.size	R_InitLightTables, .-R_InitLightTables
	.align	2
	.globl	R_SetViewSize
	.set	nomips16
	.set	nomicromips
	.ent	R_SetViewSize
	.type	R_SetViewSize, @function
R_SetViewSize:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(setsizeneeded)
	li	$3,1			# 0x1
	sw	$3,%lo(setsizeneeded)($2)
	lui	$2,%hi(setblocks)
	sw	$4,%lo(setblocks)($2)
	lui	$2,%hi(setdetail)
	jr	$31
	sw	$5,%lo(setdetail)($2)

	.set	macro
	.set	reorder
	.end	R_SetViewSize
	.size	R_SetViewSize, .-R_SetViewSize
	.align	2
	.globl	R_ExecuteSetViewSize
	.set	nomips16
	.set	nomicromips
	.ent	R_ExecuteSetViewSize
	.type	R_ExecuteSetViewSize, @function
R_ExecuteSetViewSize:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(setblocks)
	lw	$4,%lo(setblocks)($2)
	addiu	$sp,$sp,-48
	lui	$3,%hi(setsizeneeded)
	li	$2,11			# 0xb
	sw	$0,%lo(setsizeneeded)($3)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L98
	.set	at
	sw	$16,20($sp)

	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	li	$3,1717960704			# 0x66660000
	sll	$2,$2,3
	addiu	$3,$3,26215
	mult	$2,$3
	sra	$2,$2,31
	mfhi	$3
	sll	$4,$4,5
	sra	$5,$3,2
	subu	$5,$5,$2
	li	$2,-8			# 0xfffffffffffffff8
	and	$5,$5,$2
	sra	$12,$5,1
	sll	$11,$5,15
$L86:
	lui	$2,%hi(setdetail)
	lw	$9,%lo(setdetail)($2)
	srl	$2,$4,31
	sra	$13,$4,$9
	addu	$2,$2,$13
	lui	$18,%hi(viewheight)
	sra	$2,$2,1
	lui	$3,%hi(scaledviewwidth)
	sw	$5,%lo(viewheight)($18)
	sw	$4,%lo(scaledviewwidth)($3)
	beq	$9,$0,$L99
	sll	$10,$2,16

	lui	$3,%hi(R_DrawColumnLow)
	lui	$8,%hi(R_DrawFuzzColumnLow)
	lui	$7,%hi(R_DrawTranslatedColumnLow)
	lui	$6,%hi(R_DrawSpanLow)
	addiu	$3,$3,%lo(R_DrawColumnLow)
	addiu	$8,$8,%lo(R_DrawFuzzColumnLow)
	addiu	$7,$7,%lo(R_DrawTranslatedColumnLow)
	addiu	$6,$6,%lo(R_DrawSpanLow)
$L87:
	lui	$17,%hi(detailshift)
	sw	$9,%lo(detailshift)($17)
	lui	$9,%hi(centery)
	sw	$12,%lo(centery)($9)
	lui	$9,%hi(centerx)
	sw	$2,%lo(centerx)($9)
	lui	$2,%hi(centerxfrac)
	sw	$10,%lo(centerxfrac)($2)
	lui	$2,%hi(centeryfrac)
	sw	$11,%lo(centeryfrac)($2)
	lui	$2,%hi(projection)
	sw	$10,%lo(projection)($2)
	lui	$2,%hi(basecolfunc)
	sw	$3,%lo(basecolfunc)($2)
	lui	$2,%hi(colfunc)
	sw	$3,%lo(colfunc)($2)
	lui	$2,%hi(fuzzcolfunc)
	sw	$8,%lo(fuzzcolfunc)($2)
	lui	$2,%hi(transcolfunc)
	sw	$7,%lo(transcolfunc)($2)
	lui	$16,%hi(viewwidth)
	lui	$2,%hi(spanfunc)
	sw	$6,%lo(spanfunc)($2)
	jal	R_InitBuffer
	sw	$13,%lo(viewwidth)($16)

	jal	R_InitTextureMapping
	nop

	lw	$6,%lo(viewwidth)($16)
	li	$2,20971520			# 0x1400000
	div	$0,$2,$6
	li	$3,1717960704			# 0x66660000
	sll	$2,$6,16
	addiu	$3,$3,26215
	sra	$4,$2,31
	mflo	$5
	mult	$2,$3
	lui	$3,%hi(pspriteiscale)
	mfhi	$2
	sw	$5,%lo(pspriteiscale)($3)
	sra	$2,$2,7
	lui	$3,%hi(pspritescale)
	subu	$2,$2,$4
	sw	$2,%lo(pspritescale)($3)
	blez	$6,$L88
	lw	$3,%lo(viewheight)($18)

	lui	$2,%hi(screenheightarray)
	addiu	$2,$2,%lo(screenheightarray)
	sll	$6,$6,1
	sll	$5,$3,16
	sra	$5,$5,16
	addu	$4,$6,$2
$L89:
	sh	$5,0($2)
	addiu	$2,$2,2
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L89
	.set	at
	nop

	blez	$3,$L108
	lui	$20,%hi(xtoviewangle)

$L91:
	lui	$21,%hi(yslope)
	addiu	$21,$21,%lo(yslope)
	move	$20,$0
	li	$19,32768			# 0x8000
$L94:
	srl	$4,$3,31
	addu	$4,$4,$3
	sra	$4,$4,1
	subu	$4,$20,$4
	sll	$4,$4,16
	jal	abs
	addu	$4,$4,$19

	lw	$3,%lo(viewwidth)($16)
	lw	$4,%lo(detailshift)($17)
	move	$5,$2
	sll	$2,$3,$4
	srl	$4,$2,31
	addu	$4,$4,$2
	sra	$4,$4,1
	jal	FixedDiv
	sll	$4,$4,16

	lw	$3,%lo(viewheight)($18)
	addiu	$20,$20,1
	slt	$4,$20,$3
	sw	$2,0($21)
	bne	$4,$0,$L94
	addiu	$21,$21,4

	lw	$6,%lo(viewwidth)($16)
	blez	$6,$L107
	lw	$2,%lo(detailshift)($17)

	lui	$20,%hi(xtoviewangle)
$L108:
	lui	$19,%hi(distscale)
	addiu	$20,$20,%lo(xtoviewangle)
	addiu	$19,$19,%lo(distscale)
	move	$21,$0
	lui	$18,%hi(finecosine)
$L95:
	lw	$2,0($20)
	lw	$3,%lo(finecosine)($18)
	srl	$2,$2,19
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$4,0($2)
	jal	abs
	addiu	$21,$21,1

	move	$5,$2
	jal	FixedDiv
	li	$4,65536			# 0x10000

	lw	$6,%lo(viewwidth)($16)
	sw	$2,0($19)
	slt	$2,$21,$6
	addiu	$20,$20,4
	bne	$2,$0,$L95
	addiu	$19,$19,4

	lw	$2,%lo(detailshift)($17)
$L107:
	lui	$11,%hi(scalelight)
$L109:
	lui	$3,%hi(colormaps)
	addiu	$11,$11,%lo(scalelight)
	lw	$10,%lo(colormaps)($3)
	sll	$6,$6,$2
	addiu	$12,$11,3072
	li	$7,60			# 0x3c
	li	$9,31			# 0x1f
	li	$8,15360			# 0x3c00
$L97:
	move	$4,$11
	move	$3,$0
$L96:
	div	$0,$3,$6
	addiu	$4,$4,4
	addiu	$3,$3,320
	mflo	$5
	srl	$2,$5,31
	addu	$2,$2,$5
	sra	$2,$2,1
	subu	$2,$7,$2
	slt	$5,$2,32
	movz	$2,$9,$5
	slt	$5,$2,0
	movn	$2,$0,$5
	sll	$2,$2,8
	addu	$2,$10,$2
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L96
	.set	at
	sw	$2,-4($4)

	addiu	$11,$11,192
	.set	noat
	xor	$1,$11,$12
	bne	$1,$0,$L97
	.set	at
	addiu	$7,$7,-4

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L99:
	lui	$3,%hi(R_DrawColumn)
	lui	$8,%hi(R_DrawFuzzColumn)
	lui	$7,%hi(R_DrawTranslatedColumn)
	lui	$6,%hi(R_DrawSpan)
	addiu	$3,$3,%lo(R_DrawColumn)
	addiu	$8,$8,%lo(R_DrawFuzzColumn)
	addiu	$7,$7,%lo(R_DrawTranslatedColumn)
	b	$L87
	addiu	$6,$6,%lo(R_DrawSpan)

$L98:
	li	$11,6553600			# 0x640000
	li	$12,100			# 0x64
	li	$5,200			# 0xc8
	b	$L86
	li	$4,320			# 0x140

$L88:
	bgtz	$3,$L91
	lw	$2,%lo(detailshift)($17)

	b	$L109
	lui	$11,%hi(scalelight)

	.set	macro
	.set	reorder
	.end	R_ExecuteSetViewSize
	.size	R_ExecuteSetViewSize, .-R_ExecuteSetViewSize
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	".\000"
	.text
	.align	2
	.globl	R_Init
	.set	nomips16
	.set	nomicromips
	.ent	R_Init
	.type	R_Init, @function
R_Init:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	R_InitData
	lui	$16,%hi($LC0)

	jal	printf
	addiu	$4,$16,%lo($LC0)

	jal	printf
	addiu	$4,$16,%lo($LC0)

	jal	printf
	addiu	$4,$16,%lo($LC0)

	lui	$2,%hi(screenblocks)
	lw	$4,%lo(screenblocks)($2)
	lui	$2,%hi(detailLevel)
	lw	$3,%lo(detailLevel)($2)
	li	$5,1			# 0x1
	lui	$2,%hi(setsizeneeded)
	sw	$5,%lo(setsizeneeded)($2)
	lui	$2,%hi(setblocks)
	sw	$4,%lo(setblocks)($2)
	lui	$2,%hi(setdetail)
	jal	R_InitPlanes
	sw	$3,%lo(setdetail)($2)

	jal	printf
	addiu	$4,$16,%lo($LC0)

	jal	R_InitLightTables
	nop

	jal	printf
	addiu	$4,$16,%lo($LC0)

	jal	R_InitSkyMap
	nop

	jal	R_InitTranslationTables
	nop

	jal	printf
	addiu	$4,$16,%lo($LC0)

	lw	$31,20($sp)
	lui	$2,%hi(framecount)
	lw	$16,16($sp)
	sw	$0,%lo(framecount)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_Init
	.size	R_Init, .-R_Init
	.align	2
	.globl	R_PointInSubsector
	.set	nomips16
	.set	nomicromips
	.ent	R_PointInSubsector
	.type	R_PointInSubsector, @function
R_PointInSubsector:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numnodes)
	lw	$3,%lo(numnodes)($2)
	beq	$3,$0,$L123
	lui	$2,%hi(subsectors)

	addiu	$3,$3,-1
	andi	$2,$3,0x8000
	bne	$2,$0,$L120
	lui	$2,%hi(subsectors)

	addiu	$sp,$sp,-40
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$31,36($sp)
	sw	$16,20($sp)
	move	$17,$4
	move	$18,$5
	lui	$19,%hi(nodes)
$L116:
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$16,%lo(nodes)($19)
	sll	$2,$2,2
	addu	$16,$16,$2
	move	$6,$16
	move	$5,$18
	jal	R_PointOnSide
	move	$4,$17

	addiu	$2,$2,24
	sll	$2,$2,1
	addu	$16,$16,$2
	lh	$2,0($16)
	bgez	$2,$L116
	lhu	$3,0($16)

	li	$4,-65536			# 0xffffffffffff0000
	lui	$2,%hi(subsectors)
	addiu	$4,$4,32767
	lw	$31,36($sp)
	lw	$2,%lo(subsectors)($2)
	and	$3,$3,$4
	sll	$3,$3,3
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	addu	$2,$2,$3
	jr	$31
	addiu	$sp,$sp,40

$L123:
	jr	$31
	lw	$2,%lo(subsectors)($2)

$L120:
	li	$4,-65536			# 0xffffffffffff0000
	addiu	$4,$4,32767
	lw	$2,%lo(subsectors)($2)
	and	$3,$3,$4
	sll	$3,$3,3
	jr	$31
	addu	$2,$2,$3

	.set	macro
	.set	reorder
	.end	R_PointInSubsector
	.size	R_PointInSubsector, .-R_PointInSubsector
	.align	2
	.globl	R_SetupFrame
	.set	nomips16
	.set	nomicromips
	.ent	R_SetupFrame
	.type	R_SetupFrame, @function
R_SetupFrame:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$6,0($4)
	lui	$2,%hi(viewangleoffset)
	lw	$5,32($6)
	lw	$2,%lo(viewangleoffset)($2)
	lw	$11,12($6)
	addu	$5,$5,$2
	lw	$10,16($6)
	srl	$3,$5,19
	lui	$9,%hi(viewx)
	lui	$2,%hi(finesine)
	sll	$3,$3,2
	sw	$11,%lo(viewx)($9)
	addiu	$2,$2,%lo(finesine)
	lui	$9,%hi(viewy)
	addu	$2,$3,$2
	sw	$10,%lo(viewy)($9)
	lw	$8,240($4)
	lui	$9,%hi(viewangle)
	lw	$6,0($2)
	sw	$5,%lo(viewangle)($9)
	lw	$7,24($4)
	lui	$5,%hi(extralight)
	lui	$2,%hi(finecosine)
	sw	$8,%lo(extralight)($5)
	lw	$2,%lo(finecosine)($2)
	lui	$5,%hi(viewz)
	sw	$7,%lo(viewz)($5)
	lui	$5,%hi(viewsin)
	addu	$2,$2,$3
	sw	$6,%lo(viewsin)($5)
	lw	$5,0($2)
	lui	$3,%hi(viewplayer)
	sw	$4,%lo(viewplayer)($3)
	lw	$2,244($4)
	lui	$3,%hi(viewcos)
	sw	$5,%lo(viewcos)($3)
	lui	$3,%hi(sscount)
	beq	$2,$0,$L125
	sw	$0,%lo(sscount)($3)

	lui	$3,%hi(colormaps)
	lw	$3,%lo(colormaps)($3)
	sll	$2,$2,8
	addu	$3,$3,$2
	lui	$5,%hi(fixedcolormap)
	lui	$4,%hi(scalelightfixed)
	addiu	$4,$4,%lo(scalelightfixed)
	sw	$3,%lo(fixedcolormap)($5)
	lui	$5,%hi(walllights)
	move	$2,$4
	sw	$4,%lo(walllights)($5)
	addiu	$4,$4,192
$L126:
	sw	$3,0($2)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L126
	.set	at
	lui	$5,%hi(framecount)

	lui	$4,%hi(validcount)
	lw	$3,%lo(framecount)($5)
	lw	$2,%lo(validcount)($4)
	addiu	$3,$3,1
	addiu	$2,$2,1
	sw	$3,%lo(framecount)($5)
	jr	$31
	sw	$2,%lo(validcount)($4)

$L125:
	lui	$2,%hi(fixedcolormap)
	lui	$5,%hi(framecount)
	lui	$4,%hi(validcount)
	lw	$3,%lo(framecount)($5)
	sw	$0,%lo(fixedcolormap)($2)
	lw	$2,%lo(validcount)($4)
	addiu	$3,$3,1
	addiu	$2,$2,1
	sw	$3,%lo(framecount)($5)
	jr	$31
	sw	$2,%lo(validcount)($4)

	.set	macro
	.set	reorder
	.end	R_SetupFrame
	.size	R_SetupFrame, .-R_SetupFrame
	.align	2
	.globl	R_RenderPlayerView
	.set	nomips16
	.set	nomicromips
	.ent	R_RenderPlayerView
	.type	R_RenderPlayerView, @function
R_RenderPlayerView:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	R_SetupFrame
	nop

	jal	R_ClearClipSegs
	nop

	jal	R_ClearDrawSegs
	nop

	jal	R_ClearPlanes
	nop

	jal	R_ClearSprites
	nop

	jal	NetUpdate
	nop

	lui	$2,%hi(numnodes)
	lw	$4,%lo(numnodes)($2)
	jal	R_RenderBSPNode
	addiu	$4,$4,-1

	jal	NetUpdate
	nop

	jal	R_DrawPlanes
	nop

	jal	NetUpdate
	nop

	jal	R_DrawMasked
	nop

	lw	$31,20($sp)
	j	NetUpdate
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	R_RenderPlayerView
	.size	R_RenderPlayerView, .-R_RenderPlayerView
	.globl	setdetail
	.section	.bss,"aw",@nobits
	.align	2
	.type	setdetail, @object
	.size	setdetail, 4
setdetail:
	.space	4
	.globl	setblocks
	.align	2
	.type	setblocks, @object
	.size	setblocks, 4
setblocks:
	.space	4
	.globl	setsizeneeded
	.align	2
	.type	setsizeneeded, @object
	.size	setsizeneeded, 4
setsizeneeded:
	.space	4
	.globl	spanfunc
	.align	2
	.type	spanfunc, @object
	.size	spanfunc, 4
spanfunc:
	.space	4
	.globl	transcolfunc
	.align	2
	.type	transcolfunc, @object
	.size	transcolfunc, 4
transcolfunc:
	.space	4
	.globl	fuzzcolfunc
	.align	2
	.type	fuzzcolfunc, @object
	.size	fuzzcolfunc, 4
fuzzcolfunc:
	.space	4
	.globl	basecolfunc
	.align	2
	.type	basecolfunc, @object
	.size	basecolfunc, 4
basecolfunc:
	.space	4
	.globl	colfunc
	.align	2
	.type	colfunc, @object
	.size	colfunc, 4
colfunc:
	.space	4
	.globl	extralight
	.align	2
	.type	extralight, @object
	.size	extralight, 4
extralight:
	.space	4
	.globl	zlight
	.align	2
	.type	zlight, @object
	.size	zlight, 8192
zlight:
	.space	8192
	.globl	scalelightfixed
	.align	2
	.type	scalelightfixed, @object
	.size	scalelightfixed, 192
scalelightfixed:
	.space	192
	.globl	scalelight
	.align	2
	.type	scalelight, @object
	.size	scalelight, 3072
scalelight:
	.space	3072
	.globl	xtoviewangle
	.align	2
	.type	xtoviewangle, @object
	.size	xtoviewangle, 1284
xtoviewangle:
	.space	1284
	.globl	viewangletox
	.align	2
	.type	viewangletox, @object
	.size	viewangletox, 16384
viewangletox:
	.space	16384
	.globl	clipangle
	.align	2
	.type	clipangle, @object
	.size	clipangle, 4
clipangle:
	.space	4
	.globl	detailshift
	.align	2
	.type	detailshift, @object
	.size	detailshift, 4
detailshift:
	.space	4
	.globl	viewplayer
	.align	2
	.type	viewplayer, @object
	.size	viewplayer, 4
viewplayer:
	.space	4
	.globl	viewsin
	.align	2
	.type	viewsin, @object
	.size	viewsin, 4
viewsin:
	.space	4
	.globl	viewcos
	.align	2
	.type	viewcos, @object
	.size	viewcos, 4
viewcos:
	.space	4
	.globl	viewangle
	.align	2
	.type	viewangle, @object
	.size	viewangle, 4
viewangle:
	.space	4
	.globl	viewz
	.align	2
	.type	viewz, @object
	.size	viewz, 4
viewz:
	.space	4
	.globl	viewy
	.align	2
	.type	viewy, @object
	.size	viewy, 4
viewy:
	.space	4
	.globl	viewx
	.align	2
	.type	viewx, @object
	.size	viewx, 4
viewx:
	.space	4
	.globl	loopcount
	.align	2
	.type	loopcount, @object
	.size	loopcount, 4
loopcount:
	.space	4
	.globl	linecount
	.align	2
	.type	linecount, @object
	.size	linecount, 4
linecount:
	.space	4
	.globl	sscount
	.align	2
	.type	sscount, @object
	.size	sscount, 4
sscount:
	.space	4
	.globl	framecount
	.align	2
	.type	framecount, @object
	.size	framecount, 4
framecount:
	.space	4
	.globl	projection
	.align	2
	.type	projection, @object
	.size	projection, 4
projection:
	.space	4
	.globl	centeryfrac
	.align	2
	.type	centeryfrac, @object
	.size	centeryfrac, 4
centeryfrac:
	.space	4
	.globl	centerxfrac
	.align	2
	.type	centerxfrac, @object
	.size	centerxfrac, 4
centerxfrac:
	.space	4
	.globl	centery
	.align	2
	.type	centery, @object
	.size	centery, 4
centery:
	.space	4
	.globl	centerx
	.align	2
	.type	centerx, @object
	.size	centerx, 4
centerx:
	.space	4
	.globl	fixedcolormap
	.align	2
	.type	fixedcolormap, @object
	.size	fixedcolormap, 4
fixedcolormap:
	.space	4
	.globl	validcount
	.data
	.align	2
	.type	validcount, @object
	.size	validcount, 4
validcount:
	.word	1
	.globl	viewangleoffset
	.section	.bss
	.align	2
	.type	viewangleoffset, @object
	.size	viewangleoffset, 4
viewangleoffset:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
