	.file	1 "r_plane.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	R_InitPlanes
	.set	nomips16
	.set	nomicromips
	.ent	R_InitPlanes
	.type	R_InitPlanes, @function
R_InitPlanes:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_InitPlanes
	.size	R_InitPlanes, .-R_InitPlanes
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"R_MapPlane: %i, %i at %i\000"
	.text
	.align	2
	.globl	R_MapPlane
	.set	nomips16
	.set	nomicromips
	.ent	R_MapPlane
	.type	R_MapPlane, @function
R_MapPlane:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	slt	$2,$6,$5
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$17,24($sp)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$18,28($sp)
	sw	$16,20($sp)
	move	$17,$5
	move	$19,$6
	bne	$2,$0,$L4
	move	$20,$4

	bltz	$5,$L4
	lui	$2,%hi(viewwidth)

	lw	$2,%lo(viewwidth)($2)
	slt	$2,$6,$2
	bne	$2,$0,$L10
	lui	$2,%hi(viewheight)

$L4:
	lui	$4,%hi($LC0)
$L13:
	move	$7,$20
	move	$6,$19
	move	$5,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lui	$2,%hi(cachedheight)
$L14:
	sll	$16,$20,2
	addiu	$2,$2,%lo(cachedheight)
	lui	$3,%hi(planeheight)
	addu	$2,$16,$2
	lw	$4,%lo(planeheight)($3)
	lw	$3,0($2)
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L11
	.set	at
	lui	$3,%hi(cachedxstep)

	addiu	$3,$3,%lo(cachedxstep)
	addu	$3,$16,$3
	lui	$2,%hi(cacheddistance)
	lui	$4,%hi(cachedystep)
	lw	$5,0($3)
	addiu	$2,$2,%lo(cacheddistance)
	addiu	$3,$4,%lo(cachedystep)
	addu	$2,$16,$2
	addu	$16,$16,$3
	lw	$18,0($2)
	lui	$3,%hi(ds_xstep)
	lw	$2,0($16)
	sw	$5,%lo(ds_xstep)($3)
$L7:
	lui	$3,%hi(distscale)
	sll	$16,$17,2
	addiu	$3,$3,%lo(distscale)
	addu	$3,$16,$3
	lw	$5,0($3)
	move	$4,$18
	lui	$3,%hi(ds_ystep)
	jal	FixedMul
	sw	$2,%lo(ds_ystep)($3)

	lui	$3,%hi(xtoviewangle)
	addiu	$3,$3,%lo(xtoviewangle)
	addu	$16,$16,$3
	lui	$3,%hi(viewangle)
	lw	$3,%lo(viewangle)($3)
	lw	$16,0($16)
	move	$5,$2
	addu	$16,$16,$3
	lui	$3,%hi(finecosine)
	lw	$3,%lo(finecosine)($3)
	srl	$16,$16,19
	sll	$16,$16,2
	addu	$3,$3,$16
	lw	$4,0($3)
	jal	FixedMul
	move	$21,$2

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$16,$16,$3
	lui	$4,%hi(viewx)
	lui	$3,%hi(viewy)
	lw	$5,%lo(viewx)($4)
	lw	$3,%lo(viewy)($3)
	lw	$4,0($16)
	addu	$2,$5,$2
	subu	$16,$0,$3
	move	$5,$21
	lui	$3,%hi(ds_xfrac)
	jal	FixedMul
	sw	$2,%lo(ds_xfrac)($3)

	lui	$3,%hi(fixedcolormap)
	lw	$3,%lo(fixedcolormap)($3)
	subu	$16,$16,$2
	lui	$2,%hi(ds_yfrac)
	beq	$3,$0,$L12
	sw	$16,%lo(ds_yfrac)($2)

$L8:
	lui	$2,%hi(spanfunc)
	lw	$25,%lo(spanfunc)($2)
	lui	$2,%hi(ds_colormap)
	sw	$3,%lo(ds_colormap)($2)
	lui	$2,%hi(ds_y)
	sw	$20,%lo(ds_y)($2)
	lui	$2,%hi(ds_x1)
	sw	$17,%lo(ds_x1)($2)
	lui	$2,%hi(ds_x2)
	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$19,%lo(ds_x2)($2)
	lw	$19,32($sp)
	jr	$25
	addiu	$sp,$sp,48

$L11:
	lui	$3,%hi(yslope)
	addiu	$3,$3,%lo(yslope)
	addu	$3,$16,$3
	lw	$5,0($3)
	jal	FixedMul
	sw	$4,0($2)

	move	$18,$2
	lui	$2,%hi(basexscale)
	lw	$5,%lo(basexscale)($2)
	lui	$2,%hi(cacheddistance)
	addiu	$2,$2,%lo(cacheddistance)
	move	$4,$18
	addu	$2,$16,$2
	jal	FixedMul
	sw	$18,0($2)

	lui	$3,%hi(cachedxstep)
	lui	$4,%hi(baseyscale)
	addiu	$3,$3,%lo(cachedxstep)
	lw	$5,%lo(baseyscale)($4)
	addu	$3,$16,$3
	sw	$2,0($3)
	move	$4,$18
	lui	$3,%hi(ds_xstep)
	jal	FixedMul
	sw	$2,%lo(ds_xstep)($3)

	lui	$3,%hi(cachedystep)
	addiu	$3,$3,%lo(cachedystep)
	addu	$3,$16,$3
	b	$L7
	sw	$2,0($3)

$L12:
	sra	$18,$18,20
	li	$3,127			# 0x7f
	sltu	$4,$18,128
	lui	$2,%hi(planezlight)
	movz	$18,$3,$4
	lw	$2,%lo(planezlight)($2)
	sll	$18,$18,2
	addu	$2,$2,$18
	b	$L8
	lw	$3,0($2)

$L10:
	lw	$2,%lo(viewheight)($2)
	slt	$2,$2,$4
	beq	$2,$0,$L14
	lui	$2,%hi(cachedheight)

	b	$L13
	lui	$4,%hi($LC0)

	.set	macro
	.set	reorder
	.end	R_MapPlane
	.size	R_MapPlane, .-R_MapPlane
	.align	2
	.globl	R_ClearPlanes
	.set	nomips16
	.set	nomicromips
	.ent	R_ClearPlanes
	.type	R_ClearPlanes, @function
R_ClearPlanes:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(viewwidth)
	lw	$4,%lo(viewwidth)($2)
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$17,24($sp)
	blez	$4,$L16
	sw	$16,20($sp)

	lui	$3,%hi(viewheight)
	lui	$2,%hi(floorclip)
	lh	$6,%lo(viewheight)($3)
	addiu	$2,$2,%lo(floorclip)
	sll	$4,$4,1
	lui	$3,%hi(ceilingclip)
	addiu	$3,$3,%lo(ceilingclip)
	addu	$4,$4,$2
	li	$5,-1			# 0xffffffffffffffff
$L17:
	sh	$6,0($2)
	addiu	$2,$2,2
	sh	$5,0($3)
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L17
	.set	at
	addiu	$3,$3,2

$L16:
	lui	$2,%hi(visplanes)
	lui	$3,%hi(lastvisplane)
	addiu	$2,$2,%lo(visplanes)
	sw	$2,%lo(lastvisplane)($3)
	lui	$4,%hi(cachedheight)
	lui	$2,%hi(openings)
	lui	$3,%hi(lastopening)
	li	$6,800			# 0x320
	move	$5,$0
	addiu	$4,$4,%lo(cachedheight)
	addiu	$2,$2,%lo(openings)
	jal	memset
	sw	$2,%lo(lastopening)($3)

	lui	$2,%hi(viewangle)
	lw	$16,%lo(viewangle)($2)
	li	$2,-1073741824			# 0xffffffffc0000000
	addu	$16,$16,$2
	lui	$2,%hi(finecosine)
	lw	$2,%lo(finecosine)($2)
	srl	$16,$16,19
	sll	$16,$16,2
	lui	$17,%hi(centerxfrac)
	addu	$2,$2,$16
	lw	$5,%lo(centerxfrac)($17)
	jal	FixedDiv
	lw	$4,0($2)

	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	addu	$16,$16,$3
	lw	$5,%lo(centerxfrac)($17)
	lw	$4,0($16)
	lui	$3,%hi(basexscale)
	jal	FixedDiv
	sw	$2,%lo(basexscale)($3)

	lw	$31,28($sp)
	subu	$2,$0,$2
	lui	$3,%hi(baseyscale)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$2,%lo(baseyscale)($3)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_ClearPlanes
	.size	R_ClearPlanes, .-R_ClearPlanes
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"R_FindPlane: no more visplanes\000"
	.text
	.align	2
	.globl	R_FindPlane
	.set	nomips16
	.set	nomicromips
	.ent	R_FindPlane
	.type	R_FindPlane, @function
R_FindPlane:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	lui	$2,%hi(skyflatnum)
	lw	$2,%lo(skyflatnum)($2)
	sw	$20,32($sp)
	lui	$20,%hi(lastvisplane)
	lw	$3,%lo(lastvisplane)($20)
	sw	$18,24($sp)
	move	$18,$5
	lui	$5,%hi(visplanes)
	addiu	$5,$5,%lo(visplanes)
	xor	$2,$2,$18
	movz	$6,$0,$2
	movz	$4,$0,$2
	sltu	$7,$5,$3
	sw	$19,28($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,36($sp)
	move	$16,$5
	move	$19,$6
	bne	$7,$0,$L25
	move	$17,$4

	b	$L32
	li	$2,65536			# 0x10000

$L23:
	addiu	$16,$16,664
$L33:
	sltu	$2,$16,$3
	beq	$2,$0,$L32
	li	$2,65536			# 0x10000

$L25:
	lw	$2,0($16)
	.set	noat
	xor	$1,$2,$17
	bne	$1,$0,$L23
	.set	at
	nop

	lw	$2,4($16)
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L23
	.set	at
	nop

	lw	$2,8($16)
	.set	noat
	xor	$1,$2,$19
	bne	$1,$0,$L33
	.set	at
	addiu	$16,$16,664

	addiu	$16,$16,-664
	sltu	$2,$16,$3
	bne	$2,$0,$L34
	lw	$31,36($sp)

	li	$2,65536			# 0x10000
$L32:
	subu	$5,$3,$5
	addiu	$2,$2,19456
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L31
	.set	at
	lui	$4,%hi($LC1)

$L27:
	li	$2,320			# 0x140
	sw	$2,12($16)
	li	$2,-1			# 0xffffffffffffffff
	addiu	$3,$3,664
	li	$6,320			# 0x140
	li	$5,255			# 0xff
	addiu	$4,$16,21
	sw	$17,0($16)
	sw	$18,4($16)
	sw	$19,8($16)
	sw	$2,16($16)
	jal	memset
	sw	$3,%lo(lastvisplane)($20)

	lw	$31,36($sp)
$L34:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L31:
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	b	$L27
	lw	$3,%lo(lastvisplane)($20)

	.set	macro
	.set	reorder
	.end	R_FindPlane
	.size	R_FindPlane, .-R_FindPlane
	.align	2
	.globl	R_CheckPlane
	.set	nomips16
	.set	nomicromips
	.ent	R_CheckPlane
	.type	R_CheckPlane, @function
R_CheckPlane:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,12($4)
	addiu	$sp,$sp,-24
	slt	$3,$5,$2
	sw	$31,20($sp)
	bne	$3,$0,$L43
	sw	$16,16($sp)

	move	$10,$2
	move	$2,$5
$L36:
	lw	$7,16($4)
	slt	$3,$7,$6
	bne	$3,$0,$L37
	move	$9,$6

	move	$9,$7
	move	$7,$6
$L37:
	slt	$3,$7,$2
	bne	$3,$0,$L38
	li	$8,255			# 0xff

	b	$L49
	addu	$3,$4,$2

$L47:
	slt	$3,$7,$2
	bne	$3,$0,$L48
	lw	$31,20($sp)

	addu	$3,$4,$2
$L49:
	lbu	$3,21($3)
	.set	noat
	xor	$1,$3,$8
	beq	$1,$0,$L47
	.set	at
	addiu	$2,$2,1

	addiu	$2,$2,-1
	slt	$7,$7,$2
	bne	$7,$0,$L38
	lui	$2,%hi(lastvisplane)

	lw	$16,%lo(lastvisplane)($2)
	lw	$3,0($4)
	lw	$7,4($4)
	lw	$4,8($4)
	sw	$3,0($16)
	sw	$4,8($16)
	addiu	$3,$16,664
	sw	$5,12($16)
	sw	$6,16($16)
	sw	$7,4($16)
	addiu	$4,$16,21
	li	$6,320			# 0x140
	li	$5,255			# 0xff
	jal	memset
	sw	$3,%lo(lastvisplane)($2)

	lw	$31,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L38:
	lw	$31,20($sp)
$L48:
	move	$16,$4
	move	$2,$16
	sw	$10,12($4)
	lw	$16,16($sp)
	sw	$9,16($4)
	jr	$31
	addiu	$sp,$sp,24

$L43:
	b	$L36
	move	$10,$5

	.set	macro
	.set	reorder
	.end	R_CheckPlane
	.size	R_CheckPlane, .-R_CheckPlane
	.align	2
	.globl	R_MakeSpans
	.set	nomips16
	.set	nomicromips
	.ent	R_MakeSpans
	.type	R_MakeSpans, @function
R_MakeSpans:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	slt	$2,$5,$7
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$19,64($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	move	$16,$5
	move	$18,$7
	move	$20,$4
	beq	$2,$0,$L51
	move	$17,$6

	slt	$2,$6,$5
	bne	$2,$0,$L52
	lui	$21,%hi(spanstart)

	sll	$2,$5,2
	addiu	$21,$21,%lo(spanstart)
	addiu	$22,$4,-1
	b	$L58
	addu	$21,$21,$2

$L53:
	bne	$2,$0,$L82
	addiu	$21,$21,4

$L58:
	lw	$5,0($21)
	move	$4,$16
	move	$6,$22
	jal	R_MapPlane
	addiu	$16,$16,1

	.set	noat
	xor	$1,$18,$16
	bne	$1,$0,$L53
	.set	at
	slt	$2,$17,$16

	slt	$2,$19,$17
	beq	$2,$0,$L84
	slt	$2,$17,$19

$L71:
	slt	$2,$17,$16
	bne	$2,$0,$L80
	sll	$2,$17,2

	lui	$21,%hi(spanstart)
	addiu	$21,$21,%lo(spanstart)
	addiu	$22,$20,-1
	b	$L64
	addu	$21,$21,$2

$L60:
	bne	$2,$0,$L55
	addiu	$21,$21,-4

$L64:
	lw	$5,0($21)
	move	$4,$17
	move	$6,$22
	jal	R_MapPlane
	addiu	$17,$17,-1

	.set	noat
	xor	$1,$19,$17
	bne	$1,$0,$L60
	.set	at
	slt	$2,$17,$16

$L80:
	slt	$2,$18,$16
$L88:
	beq	$2,$0,$L86
	lw	$31,44($sp)

$L70:
	slt	$2,$19,$18
	bne	$2,$0,$L86
	lw	$31,44($sp)

	lui	$2,%hi(spanstart)
	sll	$3,$18,2
	addiu	$2,$2,%lo(spanstart)
	b	$L68
	addu	$2,$2,$3

$L65:
	bne	$4,$0,$L50
	addiu	$2,$2,4

$L68:
	addiu	$18,$18,1
	slt	$3,$18,$16
	slt	$4,$19,$18
	bne	$3,$0,$L65
	sw	$20,0($2)

	slt	$2,$17,$19
$L84:
	beq	$2,$0,$L86
	lw	$31,44($sp)

	slt	$2,$19,$18
	bne	$2,$0,$L87
	lw	$22,40($sp)

	lui	$2,%hi(spanstart)
	sll	$3,$19,2
	addiu	$2,$2,%lo(spanstart)
	b	$L69
	addu	$2,$2,$3

$L83:
	bne	$3,$0,$L50
	addiu	$2,$2,-4

$L69:
	addiu	$19,$19,-1
	slt	$3,$19,$18
	.set	noat
	xor	$1,$17,$19
	bne	$1,$0,$L83
	.set	at
	sw	$20,0($2)

$L50:
	lw	$31,44($sp)
$L86:
	lw	$22,40($sp)
$L87:
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L82:
	slt	$2,$19,$17
	bne	$2,$0,$L88
	slt	$2,$18,$16

$L55:
	slt	$2,$18,$16
$L85:
	bne	$2,$0,$L70
	slt	$2,$17,$19

	b	$L84
	nop

$L51:
	slt	$2,$19,$6
	bne	$2,$0,$L71
	slt	$2,$18,$16

	b	$L85
	nop

$L52:
	slt	$2,$19,$6
	beq	$2,$0,$L55
	lw	$31,44($sp)

	b	$L87
	lw	$22,40($sp)

	.set	macro
	.set	reorder
	.end	R_MakeSpans
	.size	R_MakeSpans, .-R_MakeSpans
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"R_DrawPlanes: drawsegs overflow (%i)\000"
	.align	2
$LC3:
	.ascii	"R_DrawPlanes: visplane overflow (%i)\000"
	.align	2
$LC4:
	.ascii	"R_DrawPlanes: opening overflow (%i)\000"
	.text
	.align	2
	.globl	R_DrawPlanes
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawPlanes
	.type	R_DrawPlanes, @function
R_DrawPlanes:
	.frame	$sp,96,$31		# vars= 32, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(ds_p)
	lw	$2,%lo(ds_p)($2)
	lui	$3,%hi(drawsegs)
	addiu	$3,$3,%lo(drawsegs)
	subu	$2,$2,$3
	addiu	$sp,$sp,-96
	slt	$3,$2,12289
	sw	$31,92($sp)
	sw	$fp,88($sp)
	sw	$23,84($sp)
	sw	$22,80($sp)
	sw	$21,76($sp)
	sw	$20,72($sp)
	sw	$19,68($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
	beq	$3,$0,$L107
	sw	$16,56($sp)

	lui	$17,%hi(lastvisplane)
	lw	$3,%lo(lastvisplane)($17)
	lui	$16,%hi(visplanes)
	addiu	$16,$16,%lo(visplanes)
	li	$2,65536			# 0x10000
	subu	$3,$3,$16
	addiu	$2,$2,19457
	slt	$2,$3,$2
	beq	$2,$0,$L112
	li	$5,724434944			# 0x2b2e0000

	lui	$2,%hi(lastopening)
$L114:
	lw	$5,%lo(lastopening)($2)
	lui	$2,%hi(openings)
	addiu	$2,$2,%lo(openings)
	subu	$5,$5,$2
	li	$2,40961			# 0xa001
	slt	$2,$5,$2
	beq	$2,$0,$L113
	lui	$4,%hi($LC4)

$L92:
	lw	$2,%lo(lastvisplane)($17)
$L111:
	sltu	$2,$16,$2
	beq	$2,$0,$L89
	lui	$2,%hi(skyflatnum)

	sw	$2,32($sp)
	lui	$2,%hi(flattranslation)
	sw	$2,40($sp)
	lui	$2,%hi(zlight)
	addiu	$2,$2,%lo(zlight)
	sw	$2,44($sp)
	lui	$2,%hi(xtoviewangle)
	addiu	$2,$2,%lo(xtoviewangle)
	sw	$2,48($sp)
	lui	$2,%hi(viewangle)
	sw	$2,36($sp)
$L102:
	lw	$19,12($16)
	lw	$5,16($16)
	slt	$2,$5,$19
	bne	$2,$0,$L95
	lw	$3,32($sp)

	lw	$2,4($16)
	lw	$4,%lo(skyflatnum)($3)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L110
	.set	at
	lw	$3,40($sp)

	sll	$2,$2,2
	lw	$3,%lo(flattranslation)($3)
	li	$5,1			# 0x1
	addu	$2,$3,$2
	lw	$19,0($2)
	lui	$2,%hi(firstflat)
	lw	$2,%lo(firstflat)($2)
	addu	$19,$19,$2
	jal	W_CacheLumpNum
	move	$4,$19

	lui	$3,%hi(viewz)
	lw	$3,%lo(viewz)($3)
	lw	$4,0($16)
	subu	$4,$4,$3
	lui	$3,%hi(ds_source)
	jal	abs
	sw	$2,%lo(ds_source)($3)

	lw	$3,8($16)
	lui	$4,%hi(extralight)
	lw	$4,%lo(extralight)($4)
	lw	$18,16($16)
	sra	$3,$3,4
	addu	$3,$3,$4
	slt	$5,$3,0
	addiu	$4,$18,1
	movn	$3,$0,$5
	addu	$6,$16,$4
	li	$5,-1			# 0xffffffffffffffff
	sb	$5,21($6)
	slt	$7,$3,16
	li	$6,15			# 0xf
	lw	$21,12($16)
	movz	$3,$6,$7
	lw	$6,44($sp)
	sll	$3,$3,9
	lui	$7,%hi(planeheight)
	addu	$3,$6,$3
	sw	$2,%lo(planeheight)($7)
	addu	$6,$16,$21
	lui	$2,%hi(planezlight)
	slt	$4,$4,$21
	sw	$3,%lo(planezlight)($2)
	bne	$4,$0,$L100
	sb	$5,20($6)

	addiu	$20,$21,20
	addu	$20,$16,$20
$L101:
	lbu	$2,323($20)
	lbu	$7,1($20)
	lbu	$6,322($20)
	lbu	$5,0($20)
	move	$4,$21
	jal	R_MakeSpans
	sw	$2,16($sp)

	slt	$2,$18,$21
	addiu	$20,$20,1
	beq	$2,$0,$L101
	addiu	$21,$21,1

$L100:
	jal	W_ReleaseLumpNum
	move	$4,$19

$L95:
	lw	$2,%lo(lastvisplane)($17)
	addiu	$16,$16,664
	sltu	$2,$16,$2
	bne	$2,$0,$L102
	nop

$L89:
	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	jr	$31
	addiu	$sp,$sp,96

$L110:
	lui	$4,%hi(detailshift)
	lui	$2,%hi(pspriteiscale)
	lw	$6,%lo(detailshift)($4)
	lw	$2,%lo(pspriteiscale)($2)
	lui	$4,%hi(colormaps)
	sra	$2,$2,$6
	lw	$8,%lo(colormaps)($4)
	lui	$9,%hi(dc_iscale)
	lui	$4,%hi(skytexturemid)
	lw	$4,%lo(skytexturemid)($4)
	sw	$2,%lo(dc_iscale)($9)
	lui	$2,%hi(dc_colormap)
	sw	$8,%lo(dc_colormap)($2)
	lui	$2,%hi(dc_texturemid)
	sw	$4,%lo(dc_texturemid)($2)
	lw	$2,48($sp)
	sll	$7,$19,2
	addu	$22,$2,$7
	lui	$2,%hi(dc_source)
	addiu	$6,$19,21
	sw	$2,24($sp)
	lui	$2,%hi(colfunc)
	addu	$18,$16,$6
	lui	$23,%hi(dc_yl)
	lui	$fp,%hi(dc_yh)
	lui	$21,%hi(dc_x)
	lui	$20,%hi(skytexture)
	b	$L98
	sw	$2,28($sp)

$L97:
	addiu	$19,$19,1
	slt	$2,$5,$19
	addiu	$18,$18,1
	bne	$2,$0,$L95
	addiu	$22,$22,4

$L98:
	lbu	$2,0($18)
	lbu	$4,322($18)
	sw	$2,%lo(dc_yl)($23)
	slt	$2,$4,$2
	bne	$2,$0,$L97
	sw	$4,%lo(dc_yh)($fp)

	lw	$2,36($sp)
	lw	$5,0($22)
	lw	$2,%lo(viewangle)($2)
	lw	$4,%lo(skytexture)($20)
	addu	$5,$5,$2
	srl	$5,$5,22
	jal	R_GetColumn
	sw	$19,%lo(dc_x)($21)

	lw	$3,28($sp)
	lw	$4,%lo(colfunc)($3)
	lw	$3,24($sp)
	jalr	$4
	sw	$2,%lo(dc_source)($3)

	b	$L97
	lw	$5,16($16)

$L107:
	li	$5,-1431699456			# 0xffffffffaaaa0000
	sra	$2,$2,4
	ori	$5,$5,0xaaab
	multu	$2,$5
	mflo	$5
	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	jal	I_Error
	lui	$17,%hi(lastvisplane)

	lui	$16,%hi(visplanes)
	lw	$3,%lo(lastvisplane)($17)
	addiu	$16,$16,%lo(visplanes)
	li	$2,65536			# 0x10000
	subu	$3,$3,$16
	addiu	$2,$2,19457
	slt	$2,$3,$2
	bne	$2,$0,$L114
	lui	$2,%hi(lastopening)

	li	$5,724434944			# 0x2b2e0000
$L112:
	sra	$3,$3,3
	addiu	$5,$5,17371
	multu	$3,$5
	mflo	$5
	lui	$4,%hi($LC3)
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	lui	$2,%hi(lastopening)
	lw	$5,%lo(lastopening)($2)
	lui	$2,%hi(openings)
	addiu	$2,$2,%lo(openings)
	subu	$5,$5,$2
	li	$2,40961			# 0xa001
	slt	$2,$5,$2
	bne	$2,$0,$L92
	lui	$4,%hi($LC4)

$L113:
	sra	$5,$5,1
	jal	I_Error
	addiu	$4,$4,%lo($LC4)

	b	$L111
	lw	$2,%lo(lastvisplane)($17)

	.set	macro
	.set	reorder
	.end	R_DrawPlanes
	.size	R_DrawPlanes, .-R_DrawPlanes
	.globl	cachedystep
	.section	.bss,"aw",@nobits
	.align	2
	.type	cachedystep, @object
	.size	cachedystep, 800
cachedystep:
	.space	800
	.globl	cachedxstep
	.align	2
	.type	cachedxstep, @object
	.size	cachedxstep, 800
cachedxstep:
	.space	800
	.globl	cacheddistance
	.align	2
	.type	cacheddistance, @object
	.size	cacheddistance, 800
cacheddistance:
	.space	800
	.globl	cachedheight
	.align	2
	.type	cachedheight, @object
	.size	cachedheight, 800
cachedheight:
	.space	800
	.globl	baseyscale
	.align	2
	.type	baseyscale, @object
	.size	baseyscale, 4
baseyscale:
	.space	4
	.globl	basexscale
	.align	2
	.type	basexscale, @object
	.size	basexscale, 4
basexscale:
	.space	4
	.globl	distscale
	.align	2
	.type	distscale, @object
	.size	distscale, 1280
distscale:
	.space	1280
	.globl	yslope
	.align	2
	.type	yslope, @object
	.size	yslope, 800
yslope:
	.space	800
	.globl	planeheight
	.align	2
	.type	planeheight, @object
	.size	planeheight, 4
planeheight:
	.space	4
	.globl	planezlight
	.align	2
	.type	planezlight, @object
	.size	planezlight, 4
planezlight:
	.space	4
	.globl	spanstop
	.align	2
	.type	spanstop, @object
	.size	spanstop, 800
spanstop:
	.space	800
	.globl	spanstart
	.align	2
	.type	spanstart, @object
	.size	spanstart, 800
spanstart:
	.space	800
	.globl	ceilingclip
	.align	2
	.type	ceilingclip, @object
	.size	ceilingclip, 640
ceilingclip:
	.space	640
	.globl	floorclip
	.align	2
	.type	floorclip, @object
	.size	floorclip, 640
floorclip:
	.space	640
	.globl	lastopening
	.align	2
	.type	lastopening, @object
	.size	lastopening, 4
lastopening:
	.space	4
	.globl	openings
	.align	2
	.type	openings, @object
	.size	openings, 40960
openings:
	.space	40960
	.globl	ceilingplane
	.align	2
	.type	ceilingplane, @object
	.size	ceilingplane, 4
ceilingplane:
	.space	4
	.globl	floorplane
	.align	2
	.type	floorplane, @object
	.size	floorplane, 4
floorplane:
	.space	4
	.globl	lastvisplane
	.align	2
	.type	lastvisplane, @object
	.size	lastvisplane, 4
lastvisplane:
	.space	4
	.globl	visplanes
	.align	2
	.type	visplanes, @object
	.size	visplanes, 84992
visplanes:
	.space	84992
	.globl	ceilingfunc
	.align	2
	.type	ceilingfunc, @object
	.size	ceilingfunc, 4
ceilingfunc:
	.space	4
	.globl	floorfunc
	.align	2
	.type	floorfunc, @object
	.size	floorfunc, 4
floorfunc:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
