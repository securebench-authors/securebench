	.file	1 "r_segs.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	R_RenderMaskedSegRange
	.set	nomips16
	.set	nomicromips
	.ent	R_RenderMaskedSegRange
	.type	R_RenderMaskedSegRange, @function
R_RenderMaskedSegRange:
	.frame	$sp,80,$31		# vars= 24, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$7,0($4)
	lui	$2,%hi(texturetranslation)
	lw	$9,16($7)
	lw	$11,%lo(texturetranslation)($2)
	lh	$12,12($9)
	lui	$2,%hi(extralight)
	sll	$12,$12,2
	addu	$11,$11,$12
	lw	$8,24($7)
	lw	$25,%lo(extralight)($2)
	lw	$2,0($11)
	addiu	$sp,$sp,-80
	lw	$14,0($7)
	lw	$13,4($7)
	lh	$3,12($8)
	sw	$2,16($sp)
	move	$2,$5
	lui	$5,%hi(curline)
	lw	$10,28($7)
	sw	$7,%lo(curline)($5)
	lw	$24,4($14)
	lui	$5,%hi(frontsector)
	lw	$15,4($13)
	sra	$3,$3,4
	sw	$8,%lo(frontsector)($5)
	lui	$5,%hi(backsector)
	sw	$18,48($sp)
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$22,64($sp)
	sw	$21,60($sp)
	sw	$20,56($sp)
	sw	$19,52($sp)
	sw	$17,44($sp)
	sw	$16,40($sp)
	move	$18,$6
	sw	$10,%lo(backsector)($5)
	.set	noat
	xor	$1,$24,$15
	beq	$1,$0,$L20
	.set	at
	addu	$3,$3,$25

	lw	$6,0($14)
	lw	$5,0($13)
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L21
	.set	at
	nop

$L3:
	bltz	$3,$L25
	lui	$5,%hi(scalelight)

$L24:
	slt	$5,$3,16
	beq	$5,$0,$L14
	lui	$5,%hi(scalelight+2880)

	sll	$5,$3,1
	addu	$3,$5,$3
	lui	$5,%hi(scalelight)
	sll	$3,$3,6
	addiu	$5,$5,%lo(scalelight)
	addu	$5,$5,$3
$L4:
	lw	$3,4($4)
	lw	$11,20($4)
	subu	$3,$2,$3
	multu	$3,$11
	mflo	$13
	lw	$12,12($4)
	lw	$6,20($7)
	addu	$3,$13,$12
	lui	$14,%hi(walllights)
	lw	$13,40($4)
	lhu	$6,16($6)
	lw	$7,44($4)
	lw	$12,36($4)
	sw	$5,%lo(walllights)($14)
	lui	$5,%hi(mfloorclip)
	lui	$17,%hi(maskedtexturecol)
	lui	$19,%hi(rw_scalestep)
	lui	$16,%hi(spryscale)
	lui	$4,%hi(viewz)
	sw	$13,%lo(mfloorclip)($5)
	andi	$6,$6,0x10
	lui	$5,%hi(mceilingclip)
	lw	$4,%lo(viewz)($4)
	sw	$14,32($sp)
	sw	$7,%lo(maskedtexturecol)($17)
	sw	$11,%lo(rw_scalestep)($19)
	sw	$3,%lo(spryscale)($16)
	beq	$6,$0,$L5
	sw	$12,%lo(mceilingclip)($5)

	lw	$8,0($8)
	lw	$5,0($10)
	lui	$6,%hi(textureheight)
	slt	$10,$5,$8
	movn	$5,$8,$10
	lw	$8,16($sp)
	lw	$6,%lo(textureheight)($6)
	lui	$21,%hi(dc_texturemid)
	sll	$8,$8,2
	sw	$5,%lo(dc_texturemid)($21)
	addu	$6,$6,$8
	lw	$6,0($6)
	addu	$5,$5,$6
	subu	$5,$5,$4
$L6:
	lw	$4,4($9)
	lui	$22,%hi(fixedcolormap)
	lw	$6,%lo(fixedcolormap)($22)
	addu	$4,$4,$5
	beq	$6,$0,$L7
	sw	$4,%lo(dc_texturemid)($21)

	lui	$4,%hi(dc_colormap)
	sw	$6,%lo(dc_colormap)($4)
$L7:
	lui	$23,%hi(dc_x)
	slt	$4,$18,$2
	bne	$4,$0,$L1
	sw	$2,%lo(dc_x)($23)

	lui	$4,%hi(centeryfrac)
	sw	$4,20($sp)
	lui	$4,%hi(sprtopscreen)
	sw	$4,24($sp)
	lui	$4,%hi(dc_iscale)
	sw	$4,28($sp)
	lui	$4,%hi(dc_colormap)
	li	$20,32767			# 0x7fff
	b	$L12
	sw	$4,36($sp)

$L9:
	lw	$2,20($sp)
	lw	$fp,%lo(centeryfrac)($2)
	lw	$2,%lo(fixedcolormap)($22)
	beq	$2,$0,$L22
	lw	$4,%lo(dc_texturemid)($21)

$L11:
	jal	FixedMul
	nop

	lw	$4,%lo(spryscale)($16)
	li	$3,-1			# 0xffffffffffffffff
	divu	$0,$3,$4
	lw	$4,%lo(dc_x)($23)
	lw	$3,%lo(maskedtexturecol)($17)
	subu	$7,$fp,$2
	sll	$4,$4,1
	lw	$2,24($sp)
	addu	$3,$3,$4
	lh	$5,0($3)
	lw	$4,16($sp)
	sw	$7,%lo(sprtopscreen)($2)
	lw	$2,28($sp)
	mflo	$3
	jal	R_GetColumn
	sw	$3,%lo(dc_iscale)($2)

	jal	R_DrawMaskedColumn
	addiu	$4,$2,-3

	lw	$2,%lo(dc_x)($23)
	lw	$4,%lo(maskedtexturecol)($17)
	sll	$5,$2,1
	addu	$4,$4,$5
	li	$5,32767			# 0x7fff
	lw	$3,%lo(spryscale)($16)
	sh	$5,0($4)
	lw	$4,%lo(rw_scalestep)($19)
	addiu	$2,$2,1
	addu	$3,$3,$4
	slt	$4,$18,$2
	sw	$3,%lo(spryscale)($16)
	bne	$4,$0,$L1
	sw	$2,%lo(dc_x)($23)

$L23:
	lw	$7,%lo(maskedtexturecol)($17)
$L12:
	sll	$2,$2,1
	addu	$2,$7,$2
	lh	$2,0($2)
	.set	noat
	xor	$1,$2,$20
	bne	$1,$0,$L9
	.set	at
	move	$5,$3

	lw	$2,%lo(dc_x)($23)
	lw	$4,%lo(rw_scalestep)($19)
	addiu	$2,$2,1
	addu	$3,$3,$4
	slt	$4,$18,$2
	sw	$3,%lo(spryscale)($16)
	beq	$4,$0,$L23
	sw	$2,%lo(dc_x)($23)

$L1:
	lw	$31,76($sp)
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$22,64($sp)
	lw	$21,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	jr	$31
	addiu	$sp,$sp,80

$L14:
	b	$L4
	addiu	$5,$5,%lo(scalelight+2880)

$L21:
	addiu	$3,$3,1
	bgez	$3,$L24
	lui	$5,%hi(scalelight)

$L25:
	b	$L4
	addiu	$5,$5,%lo(scalelight)

$L22:
	sra	$3,$3,12
	lw	$2,32($sp)
	sltu	$9,$3,48
	li	$8,47			# 0x2f
	lw	$2,%lo(walllights)($2)
	movz	$3,$8,$9
	sll	$3,$3,2
	addu	$2,$2,$3
	lw	$2,0($2)
	lw	$3,36($sp)
	b	$L11
	sw	$2,%lo(dc_colormap)($3)

$L5:
	lw	$6,4($8)
	lw	$5,4($10)
	lui	$21,%hi(dc_texturemid)
	slt	$8,$6,$5
	movn	$5,$6,$8
	b	$L6
	subu	$5,$5,$4

$L20:
	b	$L3
	addiu	$3,$3,-1

	.set	macro
	.set	reorder
	.end	R_RenderMaskedSegRange
	.size	R_RenderMaskedSegRange, .-R_RenderMaskedSegRange
	.align	2
	.globl	R_RenderSegLoop
	.set	nomips16
	.set	nomicromips
	.ent	R_RenderSegLoop
	.type	R_RenderSegLoop, @function
R_RenderSegLoop:
	.frame	$sp,120,$31		# vars= 64, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-120
	lui	$2,%hi(rw_stopx)
	sw	$19,92($sp)
	lui	$19,%hi(rw_x)
	lw	$3,%lo(rw_x)($19)
	sw	$2,16($sp)
	lw	$2,%lo(rw_stopx)($2)
	sw	$31,116($sp)
	slt	$2,$3,$2
	sw	$fp,112($sp)
	sw	$23,108($sp)
	sw	$22,104($sp)
	sw	$21,100($sp)
	sw	$20,96($sp)
	sw	$18,88($sp)
	sw	$17,84($sp)
	beq	$2,$0,$L26
	sw	$16,80($sp)

	lui	$2,%hi(segtextured)
	sw	$2,36($sp)
	lui	$2,%hi(midtexture)
	sw	$2,28($sp)
	lui	$2,%hi(rw_scalestep)
	sw	$2,20($sp)
	lui	$2,%hi(topstep)
	sw	$2,32($sp)
	lui	$2,%hi(bottomstep)
	sw	$2,24($sp)
	lui	$2,%hi(ceilingplane)
	sw	$2,64($sp)
	lui	$2,%hi(floorplane)
	sw	$2,68($sp)
	lui	$2,%hi(rw_offset)
	sw	$2,48($sp)
	lui	$2,%hi(rw_distance)
	sw	$2,52($sp)
	lui	$2,%hi(xtoviewangle)
	addiu	$2,$2,%lo(xtoviewangle)
	sw	$2,56($sp)
	lui	$2,%hi(finetangent)
	lui	$fp,%hi(topfrac)
	lui	$23,%hi(bottomfrac)
	lui	$9,%hi(ceilingclip)
	lui	$8,%hi(floorclip)
	addiu	$2,$2,%lo(finetangent)
	lw	$16,%lo(topfrac)($fp)
	lw	$6,%lo(bottomfrac)($23)
	addiu	$22,$9,%lo(ceilingclip)
	addiu	$21,$8,%lo(floorclip)
	lui	$18,%hi(markceiling)
	lui	$17,%hi(markfloor)
	lui	$20,%hi(rw_scale)
	b	$L49
	sw	$2,60($sp)

$L70:
	lui	$9,%hi(pixhigh)
	sll	$7,$3,1
	lw	$10,%lo(pixhigh)($9)
	addu	$8,$21,$7
	lui	$2,%hi(pixhighstep)
	lh	$11,0($8)
	lw	$2,%lo(pixhighstep)($2)
	sra	$8,$10,12
	addu	$2,$2,$10
	slt	$10,$8,$11
	bne	$10,$0,$L38
	sw	$2,%lo(pixhigh)($9)

	addiu	$8,$11,-1
$L38:
	slt	$2,$8,$16
	beq	$2,$0,$L66
	addu	$7,$22,$7

	addiu	$16,$16,-1
	sh	$16,0($7)
$L40:
	lui	$2,%hi(bottomtexture)
$L76:
	lw	$4,%lo(bottomtexture)($2)
	beq	$4,$0,$L72
	lw	$2,%lo(markfloor)($17)

	lui	$8,%hi(pixlow)
$L77:
	lw	$9,%lo(pixlow)($8)
	sll	$7,$3,1
	addu	$10,$22,$7
	lui	$2,%hi(pixlowstep)
	addiu	$16,$9,4095
	lw	$2,%lo(pixlowstep)($2)
	lh	$10,0($10)
	sra	$16,$16,12
	addu	$2,$2,$9
	slt	$9,$10,$16
	bne	$9,$0,$L43
	sw	$2,%lo(pixlow)($8)

	addiu	$16,$10,1
$L43:
	slt	$2,$6,$16
	beq	$2,$0,$L67
	addu	$7,$21,$7

	addiu	$6,$6,1
	sh	$6,0($7)
$L45:
	lui	$2,%hi(maskedtexture)
$L78:
	lw	$2,%lo(maskedtexture)($2)
	beq	$2,$0,$L73
	lw	$2,20($sp)

	lui	$2,%hi(maskedtexturecol)
	lw	$2,%lo(maskedtexturecol)($2)
	sll	$4,$3,1
	addu	$2,$2,$4
	sh	$5,0($2)
$L36:
	lw	$2,20($sp)
$L73:
	lw	$4,%lo(rw_scale)($20)
	lw	$8,%lo(rw_scalestep)($2)
	lw	$2,32($sp)
	lw	$16,%lo(topfrac)($fp)
	lw	$7,%lo(topstep)($2)
	lw	$2,24($sp)
	lw	$6,%lo(bottomfrac)($23)
	lw	$5,%lo(bottomstep)($2)
	lw	$2,16($sp)
	addiu	$3,$3,1
	lw	$2,%lo(rw_stopx)($2)
	addu	$4,$4,$8
	addu	$16,$16,$7
	addu	$6,$6,$5
	slt	$2,$3,$2
	sw	$4,%lo(rw_scale)($20)
	sw	$16,%lo(topfrac)($fp)
	sw	$6,%lo(bottomfrac)($23)
	beq	$2,$0,$L26
	sw	$3,%lo(rw_x)($19)

$L49:
	sll	$2,$3,1
	addu	$4,$22,$2
	lh	$4,0($4)
	addiu	$16,$16,4095
	sra	$16,$16,12
	slt	$5,$4,$16
	bne	$5,$0,$L74
	lw	$5,%lo(markceiling)($18)

	addiu	$16,$4,1
$L74:
	addu	$2,$21,$2
	beq	$5,$0,$L29
	lh	$2,0($2)

	addiu	$5,$16,-1
	slt	$8,$5,$2
	bne	$8,$0,$L30
	addiu	$7,$4,1

	addiu	$5,$2,-1
$L30:
	slt	$8,$5,$7
	bne	$8,$0,$L29
	lw	$8,64($sp)

	lw	$8,%lo(ceilingplane)($8)
	addu	$8,$8,$3
	sb	$7,21($8)
	sb	$5,343($8)
$L29:
	sra	$6,$6,12
	slt	$5,$6,$2
	bne	$5,$0,$L75
	lw	$5,%lo(markfloor)($17)

	addiu	$6,$2,-1
$L75:
	beq	$5,$0,$L32
	addiu	$5,$6,1

	slt	$7,$4,$5
	bne	$7,$0,$L33
	addiu	$2,$2,-1

	addiu	$5,$4,1
$L33:
	slt	$4,$2,$5
	bne	$4,$0,$L32
	lw	$4,68($sp)

	lw	$4,%lo(floorplane)($4)
	addu	$4,$4,$3
	sb	$5,21($4)
	sb	$2,343($4)
$L32:
	lw	$2,36($sp)
	lw	$2,%lo(segtextured)($2)
	bne	$2,$0,$L68
	lw	$2,56($sp)

	move	$5,$0
$L34:
	lw	$2,28($sp)
	lw	$4,%lo(midtexture)($2)
	bne	$4,$0,$L69
	lui	$2,%hi(toptexture)

	lw	$4,%lo(toptexture)($2)
	bne	$4,$0,$L70
	lw	$3,%lo(rw_x)($19)

	lw	$2,%lo(markceiling)($18)
	beq	$2,$0,$L76
	lui	$2,%hi(bottomtexture)

	sll	$2,$3,1
	addu	$2,$22,$2
	addiu	$16,$16,-1
	sh	$16,0($2)
	lui	$2,%hi(bottomtexture)
	lw	$4,%lo(bottomtexture)($2)
	bne	$4,$0,$L77
	lui	$8,%hi(pixlow)

	lw	$2,%lo(markfloor)($17)
$L72:
	beq	$2,$0,$L78
	lui	$2,%hi(maskedtexture)

	sll	$2,$3,1
	addu	$2,$21,$2
	addiu	$6,$6,1
	b	$L45
	sh	$6,0($2)

$L69:
	lui	$2,%hi(rw_midtexturemid)
	lw	$3,%lo(rw_midtexturemid)($2)
	lui	$2,%hi(dc_yl)
	sw	$16,%lo(dc_yl)($2)
	lui	$2,%hi(dc_yh)
	sw	$6,%lo(dc_yh)($2)
	lui	$2,%hi(dc_texturemid)
	jal	R_GetColumn
	sw	$3,%lo(dc_texturemid)($2)

	lui	$3,%hi(colfunc)
	lui	$4,%hi(dc_source)
	lw	$3,%lo(colfunc)($3)
	jalr	$3
	sw	$2,%lo(dc_source)($4)

	lw	$3,%lo(rw_x)($19)
	lui	$4,%hi(viewheight)
	lw	$5,%lo(viewheight)($4)
	sll	$2,$3,1
	addu	$4,$22,$2
	sh	$5,0($4)
	addu	$2,$21,$2
	li	$4,-1			# 0xffffffffffffffff
	b	$L36
	sh	$4,0($2)

$L68:
	sll	$3,$3,2
	addu	$3,$3,$2
	lw	$2,0($3)
	lui	$3,%hi(rw_centerangle)
	lw	$3,%lo(rw_centerangle)($3)
	lw	$4,52($sp)
	addu	$2,$2,$3
	srl	$2,$2,19
	lw	$3,60($sp)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$5,%lo(rw_distance)($4)
	lw	$4,0($2)
	lw	$2,48($sp)
	sw	$6,44($sp)
	lw	$7,%lo(rw_offset)($2)
	jal	FixedMul
	sw	$7,40($sp)

	lw	$3,%lo(rw_scale)($20)
	li	$4,-1			# 0xffffffffffffffff
	divu	$0,$4,$3
	sra	$3,$3,12
	li	$5,47			# 0x2f
	sltu	$8,$3,48
	lui	$4,%hi(walllights)
	lw	$4,%lo(walllights)($4)
	movz	$3,$5,$8
	sll	$3,$3,2
	addu	$3,$4,$3
	lw	$7,40($sp)
	lw	$4,0($3)
	subu	$5,$7,$2
	lw	$3,%lo(rw_x)($19)
	lui	$2,%hi(dc_colormap)
	sw	$4,%lo(dc_colormap)($2)
	lui	$2,%hi(dc_x)
	sw	$3,%lo(dc_x)($2)
	lui	$2,%hi(dc_iscale)
	lw	$6,44($sp)
	sra	$5,$5,16
	mflo	$3
	b	$L34
	sw	$3,%lo(dc_iscale)($2)

$L26:
	lw	$31,116($sp)
	lw	$fp,112($sp)
	lw	$23,108($sp)
	lw	$22,104($sp)
	lw	$21,100($sp)
	lw	$20,96($sp)
	lw	$19,92($sp)
	lw	$18,88($sp)
	lw	$17,84($sp)
	lw	$16,80($sp)
	jr	$31
	addiu	$sp,$sp,120

$L66:
	lui	$2,%hi(rw_toptexturemid)
	lw	$3,%lo(rw_toptexturemid)($2)
	lui	$2,%hi(dc_yl)
	sw	$16,%lo(dc_yl)($2)
	lui	$2,%hi(dc_yh)
	sw	$8,%lo(dc_yh)($2)
	lui	$2,%hi(dc_texturemid)
	sw	$6,72($sp)
	sw	$5,44($sp)
	sw	$8,40($sp)
	jal	R_GetColumn
	sw	$3,%lo(dc_texturemid)($2)

	lui	$3,%hi(colfunc)
	lw	$3,%lo(colfunc)($3)
	lui	$4,%hi(dc_source)
	jalr	$3
	sw	$2,%lo(dc_source)($4)

	lw	$3,%lo(rw_x)($19)
	lw	$8,40($sp)
	sll	$2,$3,1
	addu	$2,$22,$2
	lw	$5,44($sp)
	lw	$6,72($sp)
	b	$L40
	sh	$8,0($2)

$L67:
	lui	$2,%hi(rw_bottomtexturemid)
	lw	$3,%lo(rw_bottomtexturemid)($2)
	lui	$2,%hi(dc_yl)
	sw	$16,%lo(dc_yl)($2)
	lui	$2,%hi(dc_yh)
	sw	$6,%lo(dc_yh)($2)
	lui	$2,%hi(dc_texturemid)
	sw	$5,40($sp)
	jal	R_GetColumn
	sw	$3,%lo(dc_texturemid)($2)

	lui	$3,%hi(colfunc)
	lw	$3,%lo(colfunc)($3)
	lui	$4,%hi(dc_source)
	jalr	$3
	sw	$2,%lo(dc_source)($4)

	lw	$3,%lo(rw_x)($19)
	lw	$5,40($sp)
	sll	$2,$3,1
	addu	$2,$21,$2
	b	$L45
	sh	$16,0($2)

	.set	macro
	.set	reorder
	.end	R_RenderSegLoop
	.size	R_RenderSegLoop, .-R_RenderSegLoop
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Bad R_RenderWallRange: %i to %i\000"
	.text
	.align	2
	.globl	R_StoreWallRange
	.set	nomips16
	.set	nomicromips
	.ent	R_StoreWallRange
	.type	R_StoreWallRange, @function
R_StoreWallRange:
	.frame	$sp,120,$31		# vars= 64, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-120
	sw	$17,84($sp)
	lui	$17,%hi(ds_p)
	lui	$2,%hi(drawsegs+12288)
	lw	$3,%lo(ds_p)($17)
	addiu	$2,$2,%lo(drawsegs+12288)
	sw	$31,116($sp)
	sw	$fp,112($sp)
	sw	$23,108($sp)
	sw	$22,104($sp)
	sw	$21,100($sp)
	sw	$20,96($sp)
	sw	$19,92($sp)
	sw	$18,88($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L79
	.set	at
	sw	$16,80($sp)

	lui	$2,%hi(viewwidth)
	lw	$2,%lo(viewwidth)($2)
	move	$16,$4
	slt	$2,$4,$2
	beq	$2,$0,$L81
	move	$18,$5

	slt	$2,$5,$4
	bne	$2,$0,$L81
	nop

	lui	$20,%hi(curline)
$L171:
	lw	$6,%lo(curline)($20)
	lui	$2,%hi(rw_angle1)
	lw	$3,20($6)
	move	$4,$2
	lhu	$5,16($3)
	sw	$2,44($sp)
	lw	$2,12($6)
	li	$19,1073741824			# 0x40000000
	lw	$4,%lo(rw_angle1)($4)
	lw	$6,16($6)
	addu	$2,$2,$19
	ori	$5,$5,0x100
	lui	$7,%hi(sidedef)
	lui	$8,%hi(linedef)
	lui	$9,%hi(rw_normalangle)
	sh	$5,16($3)
	subu	$4,$2,$4
	sw	$6,%lo(sidedef)($7)
	sw	$3,%lo(linedef)($8)
	sw	$7,20($sp)
	sw	$8,48($sp)
	sw	$9,40($sp)
	jal	abs
	sw	$2,%lo(rw_normalangle)($9)

	lw	$3,%lo(curline)($20)
	move	$21,$2
	lw	$2,0($3)
	lw	$5,4($2)
	jal	R_PointToDist
	lw	$4,0($2)

	addiu	$3,$19,1
	sltu	$3,$21,$3
	movz	$21,$19,$3
	subu	$19,$19,$21
	srl	$19,$19,19
	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	sll	$19,$19,2
	addu	$19,$3,$19
	lw	$5,0($19)
	move	$4,$2
	sw	$3,64($sp)
	sw	$2,56($sp)
	jal	FixedMul
	lui	$21,%hi(xtoviewangle)

	lw	$3,%lo(ds_p)($17)
	addiu	$21,$21,%lo(xtoviewangle)
	sll	$4,$16,2
	sw	$16,4($3)
	sw	$18,8($3)
	lui	$7,%hi(viewangle)
	addu	$4,$4,$21
	lw	$5,0($4)
	lw	$6,%lo(curline)($20)
	lw	$4,%lo(viewangle)($7)
	sw	$7,52($sp)
	lui	$7,%hi(rw_x)
	move	$8,$7
	sw	$7,28($sp)
	lui	$7,%hi(rw_distance)
	sw	$2,%lo(rw_distance)($7)
	sw	$16,%lo(rw_x)($8)
	lui	$7,%hi(rw_stopx)
	sw	$6,0($3)
	addiu	$2,$18,1
	addu	$4,$5,$4
	sw	$7,24($sp)
	jal	R_ScaleFromGlobalAngle
	sw	$2,%lo(rw_stopx)($7)

	lw	$3,%lo(ds_p)($17)
	lui	$19,%hi(rw_scale)
	slt	$4,$16,$18
	sw	$2,%lo(rw_scale)($19)
	bne	$4,$0,$L155
	sw	$2,12($3)

	sw	$2,16($3)
	lui	$23,%hi(rw_scalestep)
$L84:
	lui	$2,%hi(frontsector)
	lw	$8,20($sp)
	lw	$7,%lo(frontsector)($2)
	sw	$2,60($sp)
	lui	$2,%hi(viewz)
	lw	$12,%lo(sidedef)($8)
	move	$4,$2
	lui	$6,%hi(backsector)
	lw	$5,4($7)
	lw	$4,%lo(viewz)($4)
	sw	$2,68($sp)
	lw	$2,0($7)
	lh	$13,12($12)
	lw	$11,%lo(backsector)($6)
	lui	$10,%hi(maskedtexture)
	sw	$6,32($sp)
	lui	$fp,%hi(worldtop)
	subu	$6,$5,$4
	subu	$9,$2,$4
	lui	$18,%hi(worldbottom)
	lui	$25,%hi(bottomtexture)
	lui	$31,%hi(toptexture)
	lui	$8,%hi(midtexture)
	sw	$10,16($sp)
	sw	$13,36($sp)
	sw	$6,%lo(worldtop)($fp)
	sw	$9,%lo(worldbottom)($18)
	sw	$0,%lo(maskedtexture)($10)
	sw	$0,%lo(bottomtexture)($25)
	sw	$0,%lo(toptexture)($31)
	sw	$0,%lo(midtexture)($8)
	beq	$11,$0,$L156
	sw	$0,44($3)

	lw	$8,0($11)
	sw	$0,40($3)
	slt	$10,$8,$2
	sw	$0,36($3)
	beq	$10,$0,$L88
	sw	$0,24($3)

	li	$10,1			# 0x1
	sw	$10,24($3)
	sw	$2,28($3)
$L89:
	lw	$13,4($11)
	slt	$10,$5,$13
	beq	$10,$0,$L172
	slt	$10,$13,$4

$L165:
	lw	$10,24($3)
	sw	$5,32($3)
	ori	$10,$10,0x2
	sw	$10,24($3)
	slt	$15,$2,$13
$L181:
	bne	$15,$0,$L173
	slt	$14,$8,$5

	lui	$24,%hi(negonearray)
	lw	$10,24($3)
	addiu	$24,$24,%lo(negonearray)
	sw	$24,40($3)
	li	$24,2147418112			# 0x7fff0000
	ori	$10,$10,0x1
	ori	$24,$24,0xffff
	sw	$24,28($3)
	sw	$10,24($3)
$L173:
	bne	$14,$0,$L174
	lui	$10,%hi(skyflatnum)

	lw	$10,24($3)
	lui	$24,%hi(screenheightarray)
	addiu	$24,$24,%lo(screenheightarray)
	ori	$10,$10,0x2
	sw	$24,36($3)
	li	$24,-2147483648			# 0xffffffff80000000
	sw	$24,32($3)
	sw	$10,24($3)
	lui	$10,%hi(skyflatnum)
$L174:
	lw	$21,%lo(skyflatnum)($10)
	subu	$22,$8,$4
	sw	$21,72($sp)
	subu	$10,$13,$4
	move	$21,$22
	sw	$22,76($sp)
	lui	$22,%hi(worldhigh)
	sw	$10,%lo(worldhigh)($22)
	lui	$22,%hi(worldlow)
	sw	$21,%lo(worldlow)($22)
	lh	$24,10($7)
	lw	$21,72($sp)
	.set	noat
	xor	$1,$24,$21
	beq	$1,$0,$L157
	.set	at
	nop

$L94:
	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L96
	.set	at
	nop

$L132:
	li	$22,1			# 0x1
$L97:
	lui	$21,%hi(markfloor)
	.set	noat
	xor	$1,$10,$6
	beq	$1,$0,$L158
	.set	at
	sw	$22,%lo(markfloor)($21)

$L134:
	li	$11,1			# 0x1
$L98:
	lui	$22,%hi(markceiling)
	beq	$15,$0,$L99
	sw	$11,%lo(markceiling)($22)

	beq	$14,$0,$L175
	li	$11,1			# 0x1

	slt	$10,$10,$6
	bne	$10,$0,$L176
	lui	$10,%hi(texturetranslation)

$L166:
	lui	$10,%hi(rw_toptexturemid)
	lw	$11,%lo(rw_toptexturemid)($10)
$L102:
	slt	$8,$2,$8
	bne	$8,$0,$L104
	nop

$L167:
	lui	$8,%hi(rw_bottomtexturemid)
	lw	$6,%lo(rw_bottomtexturemid)($8)
	lw	$12,4($12)
	addu	$11,$12,$11
	addu	$12,$12,$6
	lw	$6,36($sp)
	sw	$11,%lo(rw_toptexturemid)($10)
	bne	$6,$0,$L106
	sw	$12,%lo(rw_bottomtexturemid)($8)

$L168:
	lw	$10,%lo(toptexture)($31)
	lw	$3,%lo(bottomtexture)($25)
	or	$10,$10,$3
$L87:
	lui	$3,%hi(segtextured)
	bne	$10,$0,$L107
	sw	$10,%lo(segtextured)($3)

$L108:
	slt	$2,$2,$4
	bne	$2,$0,$L116
	nop

	sw	$0,%lo(markfloor)($21)
$L116:
	slt	$5,$4,$5
	bne	$5,$0,$L177
	lw	$5,%lo(worldtop)($fp)

	lui	$2,%hi(skyflatnum)
	lh	$3,10($7)
	lw	$2,%lo(skyflatnum)($2)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L178
	.set	at
	lw	$4,%lo(rw_scalestep)($23)

	sw	$0,%lo(markceiling)($22)
	lw	$5,%lo(worldtop)($fp)
$L177:
	lw	$4,%lo(rw_scalestep)($23)
$L178:
	sra	$2,$9,4
	sra	$5,$5,4
	lui	$20,%hi(centeryfrac)
	sw	$5,%lo(worldtop)($fp)
	jal	FixedMul
	sw	$2,%lo(worldbottom)($18)

	lw	$3,%lo(centeryfrac)($20)
	lw	$5,%lo(rw_scale)($19)
	lw	$4,%lo(worldtop)($fp)
	lui	$6,%hi(topstep)
	sra	$3,$3,4
	subu	$2,$0,$2
	sw	$2,%lo(topstep)($6)
	jal	FixedMul
	sw	$3,20($sp)

	lw	$3,20($sp)
	lw	$5,%lo(worldbottom)($18)
	lw	$4,%lo(rw_scalestep)($23)
	subu	$3,$3,$2
	lui	$2,%hi(topfrac)
	jal	FixedMul
	sw	$3,%lo(topfrac)($2)

	lw	$3,%lo(centeryfrac)($20)
	lw	$4,%lo(worldbottom)($18)
	lw	$5,%lo(rw_scale)($19)
	sra	$3,$3,4
	subu	$2,$0,$2
	lui	$6,%hi(bottomstep)
	sw	$3,20($sp)
	jal	FixedMul
	sw	$2,%lo(bottomstep)($6)

	lw	$3,32($sp)
	lw	$4,%lo(backsector)($3)
	lw	$3,20($sp)
	subu	$3,$3,$2
	lui	$2,%hi(bottomfrac)
	beq	$4,$0,$L119
	sw	$3,%lo(bottomfrac)($2)

	lui	$7,%hi(worldhigh)
	lw	$4,%lo(worldhigh)($7)
	lui	$6,%hi(worldlow)
	lw	$3,%lo(worldlow)($6)
	lw	$2,%lo(worldtop)($fp)
	sra	$4,$4,4
	sra	$3,$3,4
	slt	$2,$4,$2
	sw	$4,%lo(worldhigh)($7)
	bne	$2,$0,$L159
	sw	$3,%lo(worldlow)($6)

	lw	$2,%lo(worldbottom)($18)
	slt	$2,$2,$3
	bne	$2,$0,$L179
	lw	$5,%lo(rw_scale)($19)

$L119:
	lw	$2,%lo(markceiling)($22)
$L183:
	bne	$2,$0,$L161
	lw	$2,24($sp)

$L122:
	lw	$2,%lo(markfloor)($21)
	bne	$2,$0,$L162
	lw	$2,24($sp)

$L123:
	jal	R_RenderSegLoop
	nop

	lw	$3,16($sp)
	lw	$2,%lo(ds_p)($17)
	lw	$4,%lo(maskedtexture)($3)
	lw	$3,24($2)
	andi	$5,$3,0x2
	or	$5,$5,$4
	bne	$5,$0,$L163
	nop

	move	$4,$0
$L124:
	andi	$3,$3,0x1
	or	$3,$3,$4
	beq	$3,$0,$L125
	nop

	lw	$3,40($2)
	beq	$3,$0,$L164
	lui	$5,%hi(floorclip)

$L126:
	beq	$4,$0,$L125
	nop

	lw	$3,24($2)
	andi	$4,$3,0x2
	bne	$4,$0,$L180
	andi	$4,$3,0x1

	ori	$3,$3,0x2
	li	$4,-2147483648			# 0xffffffff80000000
	sw	$3,24($2)
	sw	$4,32($2)
	andi	$4,$3,0x1
$L180:
	bne	$4,$0,$L125
	nop

	ori	$3,$3,0x1
	sw	$3,24($2)
	li	$3,2147418112			# 0x7fff0000
	ori	$3,$3,0xffff
	sw	$3,28($2)
$L125:
	addiu	$2,$2,48
	sw	$2,%lo(ds_p)($17)
$L79:
	lw	$31,116($sp)
	lw	$fp,112($sp)
	lw	$23,108($sp)
	lw	$22,104($sp)
	lw	$21,100($sp)
	lw	$20,96($sp)
	lw	$19,92($sp)
	lw	$18,88($sp)
	lw	$17,84($sp)
	lw	$16,80($sp)
	jr	$31
	addiu	$sp,$sp,120

$L81:
	lui	$4,%hi($LC0)
	move	$6,$18
	move	$5,$16
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	b	$L171
	lui	$20,%hi(curline)

$L88:
	slt	$10,$4,$8
	beq	$10,$0,$L89
	li	$10,1			# 0x1

	lw	$13,4($11)
	sw	$10,24($3)
	li	$10,2147418112			# 0x7fff0000
	ori	$10,$10,0xffff
	sw	$10,28($3)
	slt	$10,$5,$13
	bne	$10,$0,$L165
	slt	$10,$13,$4

$L172:
	beq	$10,$0,$L181
	slt	$15,$2,$13

	lw	$10,24($3)
	ori	$10,$10,0x2
	sw	$10,24($3)
	li	$10,-2147483648			# 0xffffffff80000000
	b	$L181
	sw	$10,32($3)

$L99:
	li	$11,1			# 0x1
$L175:
	slt	$10,$10,$6
	sw	$11,%lo(markfloor)($21)
	beq	$10,$0,$L166
	sw	$11,%lo(markceiling)($22)

	lui	$10,%hi(texturetranslation)
$L176:
	lw	$15,%lo(texturetranslation)($10)
	lw	$10,48($sp)
	lh	$11,8($12)
	lw	$10,%lo(linedef)($10)
	sll	$11,$11,2
	lhu	$10,16($10)
	addu	$15,$15,$11
	lw	$15,0($15)
	andi	$10,$10,0x8
	beq	$10,$0,$L103
	sw	$15,%lo(toptexture)($31)

	lui	$10,%hi(rw_toptexturemid)
	slt	$8,$2,$8
	sw	$6,%lo(rw_toptexturemid)($10)
	beq	$8,$0,$L167
	move	$11,$6

$L104:
	lh	$13,10($12)
	lui	$8,%hi(texturetranslation)
	lw	$8,%lo(texturetranslation)($8)
	lw	$14,48($sp)
	sll	$13,$13,2
	lw	$14,%lo(linedef)($14)
	addu	$8,$8,$13
	lw	$8,0($8)
	lhu	$14,16($14)
	sw	$8,%lo(bottomtexture)($25)
	lw	$8,76($sp)
	andi	$14,$14,0x10
	lw	$12,4($12)
	movn	$8,$6,$14
	move	$6,$8
	addu	$11,$12,$11
	addu	$12,$12,$6
	lw	$6,36($sp)
	lui	$8,%hi(rw_bottomtexturemid)
	sw	$11,%lo(rw_toptexturemid)($10)
	beq	$6,$0,$L168
	sw	$12,%lo(rw_bottomtexturemid)($8)

$L106:
	lw	$4,24($sp)
	lw	$2,28($sp)
	lw	$5,%lo(rw_stopx)($4)
	lw	$2,%lo(rw_x)($2)
	lw	$8,%lo(toptexture)($31)
	lui	$6,%hi(lastopening)
	lw	$4,%lo(bottomtexture)($25)
	lw	$7,%lo(lastopening)($6)
	subu	$5,$5,$2
	sll	$5,$5,1
	or	$4,$4,$8
	sll	$2,$2,1
	lw	$8,16($sp)
	subu	$2,$7,$2
	addu	$7,$7,$5
	li	$5,1			# 0x1
	sw	$5,%lo(maskedtexture)($8)
	lui	$5,%hi(maskedtexturecol)
	ori	$4,$4,0x1
	sw	$2,%lo(maskedtexturecol)($5)
	sw	$2,44($3)
	lui	$2,%hi(segtextured)
	sw	$7,%lo(lastopening)($6)
	sw	$4,%lo(segtextured)($2)
$L107:
	lw	$2,40($sp)
	li	$3,-2147483648			# 0xffffffff80000000
	lw	$4,%lo(rw_normalangle)($2)
	lw	$2,44($sp)
	addiu	$3,$3,1
	lw	$5,%lo(rw_angle1)($2)
	subu	$2,$4,$5
	sltu	$3,$2,$3
	bne	$3,$0,$L109
	nop

	subu	$2,$5,$4
$L109:
	li	$4,1073741824			# 0x40000000
	addiu	$3,$4,1
	sltu	$3,$2,$3
	movz	$2,$4,$3
	srl	$2,$2,19
	lw	$3,64($sp)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$5,0($2)
	jal	FixedMul
	lw	$4,56($sp)

	lw	$3,40($sp)
	lw	$5,%lo(rw_normalangle)($3)
	lw	$3,44($sp)
	lw	$3,%lo(rw_angle1)($3)
	subu	$3,$5,$3
	bltz	$3,$L182
	lw	$3,20($sp)

	subu	$2,$0,$2
$L182:
	lw	$6,%lo(curline)($20)
	lw	$3,%lo(sidedef)($3)
	lw	$7,8($6)
	lw	$4,0($3)
	lw	$3,52($sp)
	addu	$4,$4,$7
	lw	$3,%lo(viewangle)($3)
	addu	$2,$4,$2
	li	$7,1073741824			# 0x40000000
	lw	$4,60($sp)
	addu	$3,$3,$7
	lui	$7,%hi(fixedcolormap)
	lw	$8,%lo(fixedcolormap)($7)
	lw	$7,%lo(frontsector)($4)
	lui	$4,%hi(rw_offset)
	subu	$3,$3,$5
	sw	$2,%lo(rw_offset)($4)
	lui	$2,%hi(rw_centerangle)
	beq	$8,$0,$L111
	sw	$3,%lo(rw_centerangle)($2)

	lw	$3,68($sp)
	lw	$2,0($7)
	lw	$4,%lo(viewz)($3)
	lw	$5,4($7)
	b	$L108
	lw	$9,%lo(worldbottom)($18)

$L163:
	lw	$5,36($2)
	bne	$5,$0,$L124
	lui	$5,%hi(ceilingclip)

	lw	$20,24($sp)
	lui	$19,%hi(lastopening)
	lw	$6,%lo(rw_stopx)($20)
	lw	$4,%lo(lastopening)($19)
	sll	$18,$16,1
	subu	$6,$6,$16
	addiu	$5,$5,%lo(ceilingclip)
	addu	$5,$5,$18
	jal	memcpy
	sll	$6,$6,1

	lw	$3,%lo(rw_stopx)($20)
	lw	$4,%lo(lastopening)($19)
	subu	$3,$3,$16
	sll	$3,$3,1
	addu	$5,$4,$3
	lw	$2,%lo(ds_p)($17)
	subu	$18,$4,$18
	lw	$4,16($sp)
	lw	$3,24($2)
	lw	$4,%lo(maskedtexture)($4)
	sw	$18,36($2)
	b	$L124
	sw	$5,%lo(lastopening)($19)

$L162:
	lui	$18,%hi(floorplane)
	lw	$6,%lo(rw_stopx)($2)
	lw	$2,28($sp)
	lw	$4,%lo(floorplane)($18)
	lw	$5,%lo(rw_x)($2)
	jal	R_CheckPlane
	addiu	$6,$6,-1

	b	$L123
	sw	$2,%lo(floorplane)($18)

$L161:
	lui	$18,%hi(ceilingplane)
	lw	$6,%lo(rw_stopx)($2)
	lw	$2,28($sp)
	lw	$4,%lo(ceilingplane)($18)
	lw	$5,%lo(rw_x)($2)
	jal	R_CheckPlane
	addiu	$6,$6,-1

	b	$L122
	sw	$2,%lo(ceilingplane)($18)

$L155:
	sll	$2,$18,2
	addu	$2,$2,$21
	lw	$4,0($2)
	lw	$2,52($sp)
	sw	$3,16($sp)
	lw	$2,%lo(viewangle)($2)
	subu	$18,$18,$16
	jal	R_ScaleFromGlobalAngle
	addu	$4,$4,$2

	lw	$3,16($sp)
	lw	$4,%lo(rw_scale)($19)
	sw	$2,16($3)
	lw	$3,%lo(ds_p)($17)
	lui	$23,%hi(rw_scalestep)
	lw	$2,16($3)
	subu	$2,$2,$4
	div	$0,$2,$18
	mflo	$4
	sw	$4,%lo(rw_scalestep)($23)
	b	$L84
	sw	$4,20($3)

$L156:
	lw	$11,48($sp)
	lui	$10,%hi(texturetranslation)
	lw	$10,%lo(texturetranslation)($10)
	lw	$11,%lo(linedef)($11)
	sll	$13,$13,2
	lhu	$11,16($11)
	addu	$10,$10,$13
	lw	$10,0($10)
	li	$14,1			# 0x1
	lui	$22,%hi(markceiling)
	lui	$21,%hi(markfloor)
	andi	$11,$11,0x10
	sw	$10,%lo(midtexture)($8)
	sw	$14,%lo(markceiling)($22)
	beq	$11,$0,$L86
	sw	$14,%lo(markfloor)($21)

	lui	$6,%hi(textureheight)
	lw	$6,%lo(textureheight)($6)
	addu	$6,$6,$13
	lw	$6,0($6)
	addu	$6,$2,$6
	subu	$6,$6,$4
$L86:
	lw	$8,4($12)
	addu	$6,$8,$6
	lui	$8,%hi(rw_midtexturemid)
	sw	$6,%lo(rw_midtexturemid)($8)
	li	$6,3			# 0x3
	sw	$6,24($3)
	lui	$6,%hi(screenheightarray)
	addiu	$6,$6,%lo(screenheightarray)
	sw	$6,36($3)
	lui	$6,%hi(negonearray)
	addiu	$6,$6,%lo(negonearray)
	sw	$6,40($3)
	li	$6,2147418112			# 0x7fff0000
	ori	$6,$6,0xffff
	sw	$6,28($3)
	li	$6,-2147483648			# 0xffffffff80000000
	b	$L87
	sw	$6,32($3)

$L157:
	lh	$22,10($11)
	.set	noat
	xor	$1,$24,$22
	bne	$1,$0,$L94
	.set	at
	nop

	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L95
	.set	at
	sw	$10,%lo(worldtop)($fp)

	move	$6,$10
$L96:
	lh	$22,8($11)
	lh	$21,8($7)
	.set	noat
	xor	$1,$22,$21
	bne	$1,$0,$L132
	.set	at
	nop

	lh	$22,12($11)
	lh	$21,12($7)
	xor	$22,$22,$21
	b	$L97
	sltu	$22,$0,$22

$L158:
	lh	$22,10($11)
$L130:
	.set	noat
	xor	$1,$22,$24
	bne	$1,$0,$L134
	.set	at
	nop

	lh	$11,12($11)
	lh	$24,12($7)
	xor	$11,$11,$24
	b	$L98
	sltu	$11,$0,$11

$L103:
	lui	$10,%hi(textureheight)
	lw	$15,%lo(textureheight)($10)
	lui	$10,%hi(rw_toptexturemid)
	addu	$15,$15,$11
	lw	$11,0($15)
	addu	$11,$13,$11
	subu	$11,$11,$4
	b	$L102
	sw	$11,%lo(rw_toptexturemid)($10)

$L159:
	lw	$3,%lo(centeryfrac)($20)
	lw	$5,%lo(rw_scale)($19)
	sw	$6,32($sp)
	sw	$7,20($sp)
	jal	FixedMul
	sra	$fp,$3,4

	lw	$7,20($sp)
	lw	$4,%lo(rw_scalestep)($23)
	lw	$5,%lo(worldhigh)($7)
	subu	$3,$fp,$2
	lui	$2,%hi(pixhigh)
	jal	FixedMul
	sw	$3,%lo(pixhigh)($2)

	lw	$6,32($sp)
	subu	$2,$0,$2
	lui	$4,%hi(pixhighstep)
	lw	$3,%lo(worldlow)($6)
	sw	$2,%lo(pixhighstep)($4)
	lw	$2,%lo(worldbottom)($18)
	slt	$2,$2,$3
	beq	$2,$0,$L183
	lw	$2,%lo(markceiling)($22)

	lw	$5,%lo(rw_scale)($19)
$L179:
	move	$4,$3
	lw	$18,%lo(centeryfrac)($20)
	jal	FixedMul
	sw	$6,20($sp)

	lw	$6,20($sp)
	lw	$4,%lo(rw_scalestep)($23)
	lw	$5,%lo(worldlow)($6)
	sra	$18,$18,4
	subu	$18,$18,$2
	lui	$2,%hi(pixlow)
	jal	FixedMul
	sw	$18,%lo(pixlow)($2)

	subu	$2,$0,$2
	lui	$3,%hi(pixlowstep)
	b	$L119
	sw	$2,%lo(pixlowstep)($3)

$L111:
	lw	$3,4($6)
	lw	$4,0($6)
	lui	$5,%hi(extralight)
	lh	$2,12($7)
	lw	$8,%lo(extralight)($5)
	lw	$6,4($4)
	lw	$5,4($3)
	sra	$2,$2,4
	.set	noat
	xor	$1,$6,$5
	beq	$1,$0,$L169
	.set	at
	addu	$2,$2,$8

	lw	$4,0($4)
	lw	$3,0($3)
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L113
	.set	at
	nop

	addiu	$2,$2,1
$L113:
	bltz	$2,$L170
	lw	$3,68($sp)

	slt	$3,$2,16
	bne	$3,$0,$L115
	lui	$6,%hi(walllights)

	lw	$3,68($sp)
	lw	$4,%lo(viewz)($3)
	lui	$3,%hi(scalelight+2880)
	addiu	$3,$3,%lo(scalelight+2880)
	lw	$2,0($7)
	lw	$5,4($7)
	lw	$9,%lo(worldbottom)($18)
	b	$L108
	sw	$3,%lo(walllights)($6)

$L164:
	lw	$20,24($sp)
	lui	$19,%hi(lastopening)
	lw	$6,%lo(rw_stopx)($20)
	lw	$4,%lo(lastopening)($19)
	sll	$18,$16,1
	subu	$6,$6,$16
	addiu	$5,$5,%lo(floorclip)
	addu	$5,$5,$18
	jal	memcpy
	sll	$6,$6,1

	lw	$3,%lo(rw_stopx)($20)
	lw	$4,%lo(lastopening)($19)
	subu	$3,$3,$16
	sll	$3,$3,1
	subu	$18,$4,$18
	addu	$3,$4,$3
	lw	$2,%lo(ds_p)($17)
	lw	$4,16($sp)
	sw	$18,40($2)
	lw	$4,%lo(maskedtexture)($4)
	b	$L126
	sw	$3,%lo(lastopening)($19)

$L170:
	lui	$6,%hi(walllights)
	lw	$4,%lo(viewz)($3)
	lui	$3,%hi(scalelight)
	addiu	$3,$3,%lo(scalelight)
	lw	$2,0($7)
	lw	$5,4($7)
	lw	$9,%lo(worldbottom)($18)
	b	$L108
	sw	$3,%lo(walllights)($6)

$L95:
	li	$6,1			# 0x1
	lui	$21,%hi(markfloor)
	sw	$6,%lo(markfloor)($21)
	b	$L130
	move	$6,$10

$L115:
	sll	$3,$2,1
	addu	$2,$3,$2
	lui	$3,%hi(scalelight)
	sll	$2,$2,6
	lw	$4,68($sp)
	addiu	$3,$3,%lo(scalelight)
	addu	$3,$3,$2
	lw	$2,0($7)
	lw	$4,%lo(viewz)($4)
	lw	$5,4($7)
	lw	$9,%lo(worldbottom)($18)
	b	$L108
	sw	$3,%lo(walllights)($6)

$L169:
	b	$L113
	addiu	$2,$2,-1

	.set	macro
	.set	reorder
	.end	R_StoreWallRange
	.size	R_StoreWallRange, .-R_StoreWallRange
	.globl	maskedtexturecol
	.section	.bss,"aw",@nobits
	.align	2
	.type	maskedtexturecol, @object
	.size	maskedtexturecol, 4
maskedtexturecol:
	.space	4
	.globl	walllights
	.align	2
	.type	walllights, @object
	.size	walllights, 4
walllights:
	.space	4
	.globl	bottomstep
	.align	2
	.type	bottomstep, @object
	.size	bottomstep, 4
bottomstep:
	.space	4
	.globl	bottomfrac
	.align	2
	.type	bottomfrac, @object
	.size	bottomfrac, 4
bottomfrac:
	.space	4
	.globl	topstep
	.align	2
	.type	topstep, @object
	.size	topstep, 4
topstep:
	.space	4
	.globl	topfrac
	.align	2
	.type	topfrac, @object
	.size	topfrac, 4
topfrac:
	.space	4
	.globl	pixlowstep
	.align	2
	.type	pixlowstep, @object
	.size	pixlowstep, 4
pixlowstep:
	.space	4
	.globl	pixhighstep
	.align	2
	.type	pixhighstep, @object
	.size	pixhighstep, 4
pixhighstep:
	.space	4
	.globl	pixlow
	.align	2
	.type	pixlow, @object
	.size	pixlow, 4
pixlow:
	.space	4
	.globl	pixhigh
	.align	2
	.type	pixhigh, @object
	.size	pixhigh, 4
pixhigh:
	.space	4
	.globl	worldlow
	.align	2
	.type	worldlow, @object
	.size	worldlow, 4
worldlow:
	.space	4
	.globl	worldhigh
	.align	2
	.type	worldhigh, @object
	.size	worldhigh, 4
worldhigh:
	.space	4
	.globl	worldbottom
	.align	2
	.type	worldbottom, @object
	.size	worldbottom, 4
worldbottom:
	.space	4
	.globl	worldtop
	.align	2
	.type	worldtop, @object
	.size	worldtop, 4
worldtop:
	.space	4
	.globl	rw_bottomtexturemid
	.align	2
	.type	rw_bottomtexturemid, @object
	.size	rw_bottomtexturemid, 4
rw_bottomtexturemid:
	.space	4
	.globl	rw_toptexturemid
	.align	2
	.type	rw_toptexturemid, @object
	.size	rw_toptexturemid, 4
rw_toptexturemid:
	.space	4
	.globl	rw_midtexturemid
	.align	2
	.type	rw_midtexturemid, @object
	.size	rw_midtexturemid, 4
rw_midtexturemid:
	.space	4
	.globl	rw_scalestep
	.align	2
	.type	rw_scalestep, @object
	.size	rw_scalestep, 4
rw_scalestep:
	.space	4
	.globl	rw_scale
	.align	2
	.type	rw_scale, @object
	.size	rw_scale, 4
rw_scale:
	.space	4
	.globl	rw_distance
	.align	2
	.type	rw_distance, @object
	.size	rw_distance, 4
rw_distance:
	.space	4
	.globl	rw_offset
	.align	2
	.type	rw_offset, @object
	.size	rw_offset, 4
rw_offset:
	.space	4
	.globl	rw_centerangle
	.align	2
	.type	rw_centerangle, @object
	.size	rw_centerangle, 4
rw_centerangle:
	.space	4
	.globl	rw_stopx
	.align	2
	.type	rw_stopx, @object
	.size	rw_stopx, 4
rw_stopx:
	.space	4
	.globl	rw_x
	.align	2
	.type	rw_x, @object
	.size	rw_x, 4
rw_x:
	.space	4
	.globl	rw_angle1
	.align	2
	.type	rw_angle1, @object
	.size	rw_angle1, 4
rw_angle1:
	.space	4
	.globl	rw_normalangle
	.align	2
	.type	rw_normalangle, @object
	.size	rw_normalangle, 4
rw_normalangle:
	.space	4
	.globl	midtexture
	.align	2
	.type	midtexture, @object
	.size	midtexture, 4
midtexture:
	.space	4
	.globl	bottomtexture
	.align	2
	.type	bottomtexture, @object
	.size	bottomtexture, 4
bottomtexture:
	.space	4
	.globl	toptexture
	.align	2
	.type	toptexture, @object
	.size	toptexture, 4
toptexture:
	.space	4
	.globl	maskedtexture
	.align	2
	.type	maskedtexture, @object
	.size	maskedtexture, 4
maskedtexture:
	.space	4
	.globl	markceiling
	.align	2
	.type	markceiling, @object
	.size	markceiling, 4
markceiling:
	.space	4
	.globl	markfloor
	.align	2
	.type	markfloor, @object
	.size	markfloor, 4
markfloor:
	.space	4
	.globl	segtextured
	.align	2
	.type	segtextured, @object
	.size	segtextured, 4
segtextured:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
