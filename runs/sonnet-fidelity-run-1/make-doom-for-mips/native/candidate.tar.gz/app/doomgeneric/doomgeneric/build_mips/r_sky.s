	.file	1 "r_sky.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	R_InitSkyMap
	.set	nomips16
	.set	nomicromips
	.ent	R_InitSkyMap
	.type	R_InitSkyMap, @function
R_InitSkyMap:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(skytexturemid)
	li	$3,6553600			# 0x640000
	jr	$31
	sw	$3,%lo(skytexturemid)($2)

	.set	macro
	.set	reorder
	.end	R_InitSkyMap
	.size	R_InitSkyMap, .-R_InitSkyMap
	.globl	skytexturemid
	.section	.bss,"aw",@nobits
	.align	2
	.type	skytexturemid, @object
	.size	skytexturemid, 4
skytexturemid:
	.space	4
	.globl	skytexture
	.align	2
	.type	skytexture, @object
	.size	skytexture, 4
skytexture:
	.space	4
	.globl	skyflatnum
	.align	2
	.type	skyflatnum, @object
	.size	skyflatnum, 4
skyflatnum:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
