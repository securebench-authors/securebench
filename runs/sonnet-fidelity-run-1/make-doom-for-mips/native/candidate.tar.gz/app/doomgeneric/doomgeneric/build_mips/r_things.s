	.file	1 "r_things.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"R_InstallSpriteLump: Bad frame characters in lump %i\000"
	.align	2
$LC1:
	.ascii	"R_InitSprites: Sprite %s frame %c has multip rot=0 lump\000"
	.align	2
$LC2:
	.ascii	"R_InitSprites: Sprite %s frame %c has rotations and a ro"
	.ascii	"t=0 lump\000"
	.align	2
$LC3:
	.ascii	"R_InitSprites: Sprite %s : %c : %c has two lumps mapped "
	.ascii	"to it\000"
	.text
	.align	2
	.globl	R_InstallSpriteLump
	.set	nomips16
	.set	nomicromips
	.ent	R_InstallSpriteLump
	.type	R_InstallSpriteLump, @function
R_InstallSpriteLump:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sltu	$2,$5,29
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$17,20($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	move	$17,$5
	move	$20,$4
	move	$21,$6
	beq	$2,$0,$L2
	move	$19,$7

	sltu	$2,$6,9
	bne	$2,$0,$L24
	lui	$3,%hi(maxframe)

	move	$5,$4
	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lui	$3,%hi(maxframe)
	lw	$2,%lo(maxframe)($3)
	slt	$2,$2,$17
	beq	$2,$0,$L25
	lui	$18,%hi(sprtemp)

	sw	$17,%lo(maxframe)($3)
$L25:
	sll	$16,$17,3
	addiu	$18,$18,%lo(sprtemp)
$L5:
	subu	$2,$16,$17
	sll	$2,$2,2
	addu	$2,$18,$2
	lw	$2,0($2)
	beq	$2,$0,$L17
	subu	$2,$16,$17

	sll	$3,$2,1
	addiu	$22,$21,-1
	addu	$3,$3,$22
	sll	$3,$3,1
	addu	$3,$18,$3
	lh	$4,4($3)
	sll	$2,$2,2
	addu	$2,$18,$2
	li	$5,1			# 0x1
	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L18
	.set	at
	sw	$5,0($2)

$L11:
	subu	$16,$16,$17
$L21:
	sll	$2,$16,1
	sll	$16,$16,2
	addu	$16,$18,$16
	addu	$16,$16,$22
	lui	$3,%hi(firstspritelump)
	sb	$19,20($16)
	addu	$2,$2,$22
	lw	$3,%lo(firstspritelump)($3)
	lw	$31,44($sp)
	sll	$2,$2,1
	addu	$18,$18,$2
	subu	$20,$20,$3
	sh	$20,4($18)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L2:
	move	$5,$4
	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lui	$3,%hi(maxframe)
$L24:
	lw	$2,%lo(maxframe)($3)
	slt	$2,$2,$17
	beq	$2,$0,$L26
	sll	$16,$17,3

	sw	$17,%lo(maxframe)($3)
$L26:
	subu	$22,$16,$17
	lui	$18,%hi(sprtemp)
	sll	$22,$22,2
	addiu	$18,$18,%lo(sprtemp)
	addu	$22,$18,$22
	bne	$21,$0,$L5
	lw	$2,0($22)

	beq	$2,$0,$L19
	addiu	$6,$17,65

$L7:
	li	$3,1			# 0x1
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L20
	.set	at
	lui	$2,%hi(spritename)

	lui	$2,%hi(firstspritelump)
$L23:
	andi	$19,$19,0x00ff
	lw	$2,%lo(firstspritelump)($2)
	subu	$16,$16,$17
	sll	$3,$19,8
	sll	$16,$16,2
	subu	$2,$20,$2
	sll	$5,$19,16
	or	$3,$19,$3
	sll	$6,$2,16
	addiu	$4,$16,4
	sll	$19,$19,24
	or	$3,$3,$5
	andi	$2,$2,0xffff
	addiu	$5,$16,20
	addu	$4,$18,$4
	or	$2,$2,$6
	or	$3,$3,$19
	addu	$5,$18,$5
	addu	$16,$18,$16
	sw	$0,0($16)
	sw	$2,0($4)
	sw	$2,4($4)
	sw	$3,0($5)
	sw	$2,8($4)
	sw	$2,12($4)
	sw	$3,4($5)
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L18:
	lui	$2,%hi(spritename)
$L22:
	lw	$5,%lo(spritename)($2)
	lui	$4,%hi($LC3)
	addiu	$7,$21,48
	addiu	$6,$17,65
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	b	$L21
	subu	$16,$16,$17

$L17:
	lui	$2,%hi(spritename)
	lw	$5,%lo(spritename)($2)
	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	jal	I_Error
	addiu	$6,$17,65

	subu	$2,$16,$17
	sll	$3,$2,1
	addiu	$22,$21,-1
	addu	$3,$3,$22
	sll	$3,$3,1
	addu	$3,$18,$3
	lh	$4,4($3)
	sll	$2,$2,2
	addu	$2,$18,$2
	li	$5,1			# 0x1
	li	$3,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L11
	.set	at
	sw	$5,0($2)

	b	$L22
	lui	$2,%hi(spritename)

$L19:
	lui	$2,%hi(spritename)
	lw	$5,%lo(spritename)($2)
	lui	$4,%hi($LC1)
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	b	$L7
	lw	$2,0($22)

$L20:
	lw	$5,%lo(spritename)($2)
	lui	$4,%hi($LC2)
	addiu	$6,$17,65
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	b	$L23
	lui	$2,%hi(firstspritelump)

	.set	macro
	.set	reorder
	.end	R_InstallSpriteLump
	.size	R_InstallSpriteLump, .-R_InstallSpriteLump
	.section	.rodata.str1.4
	.align	2
$LC4:
	.ascii	"R_InitSprites: No patches found for %s frame %c\000"
	.align	2
$LC5:
	.ascii	"R_InitSprites: Sprite %s frame %c is missing rotations\000"
	.text
	.align	2
	.globl	R_InitSpriteDefs
	.set	nomips16
	.set	nomicromips
	.ent	R_InitSpriteDefs
	.type	R_InitSpriteDefs, @function
R_InitSpriteDefs:
	.frame	$sp,112,$31		# vars= 56, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	beq	$2,$0,$L28
	nop

	addiu	$sp,$sp,-112
	move	$2,$4
	sw	$21,92($sp)
	sw	$31,108($sp)
	sw	$fp,104($sp)
	sw	$23,100($sp)
	sw	$22,96($sp)
	sw	$20,88($sp)
	sw	$19,84($sp)
	sw	$18,80($sp)
	sw	$17,76($sp)
	sw	$16,72($sp)
	move	$21,$4
$L29:
	lw	$3,4($2)
	bne	$3,$0,$L29
	addiu	$2,$2,4

	subu	$4,$2,$21
	lui	$16,%hi(numsprites)
	sra	$4,$4,2
	sw	$16,48($sp)
	.set	noat
	xor	$1,$21,$2
	beq	$1,$0,$L27
	.set	at
	sw	$4,%lo(numsprites)($16)

	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	sll	$4,$4,3

	lui	$4,%hi(firstspritelump)
	lw	$5,%lo(firstspritelump)($4)
	lw	$3,%lo(numsprites)($16)
	lui	$6,%hi(sprites)
	lui	$4,%hi(lastspritelump)
	lw	$19,%lo(lastspritelump)($4)
	sw	$6,52($sp)
	sw	$5,60($sp)
	blez	$3,$L27
	sw	$2,%lo(sprites)($6)

	sll	$2,$5,3
	subu	$2,$2,$5
	sll	$2,$2,2
	sw	$2,64($sp)
	lui	$2,%hi(sprtemp)
	sw	$2,36($sp)
	slt	$2,$19,$5
	sw	$2,56($sp)
	lui	$2,%hi($LC4)
	addiu	$2,$2,%lo($LC4)
	sw	$2,44($sp)
	lui	$2,%hi($LC5)
	addiu	$2,$2,%lo($LC5)
	sw	$21,20($sp)
	sw	$0,16($sp)
	sw	$0,40($sp)
	lui	$18,%hi(spritename)
	lui	$20,%hi(maxframe)
	lui	$17,%hi(lumpinfo)
	lui	$22,%hi(modifiedgame)
	sw	$2,24($sp)
$L45:
	lw	$2,20($sp)
	lw	$3,36($sp)
	lw	$2,0($2)
	li	$6,812			# 0x32c
	li	$5,-1			# 0xffffffffffffffff
	addiu	$4,$3,%lo(sprtemp)
	jal	memset
	sw	$2,%lo(spritename)($18)

	li	$2,-1			# 0xffffffffffffffff
	sw	$2,%lo(maxframe)($20)
	lw	$2,56($sp)
	bne	$2,$0,$L37
	lw	$21,64($sp)

	b	$L31
	lw	$16,60($sp)

$L48:
	move	$4,$16
	jal	R_InstallSpriteLump
	move	$7,$0

	lw	$2,%lo(lumpinfo)($17)
	addu	$2,$2,$21
	lb	$5,6($2)
	bne	$5,$0,$L61
	nop

$L34:
	addiu	$16,$16,1
	slt	$2,$19,$16
	bne	$2,$0,$L62
	addiu	$21,$21,28

$L31:
	lw	$4,%lo(lumpinfo)($17)
	lw	$5,%lo(spritename)($18)
	addu	$4,$4,$21
	jal	strncasecmp
	li	$6,4			# 0x4

	bne	$2,$0,$L34
	lw	$4,%lo(lumpinfo)($17)

	lw	$2,%lo(modifiedgame)($22)
	addu	$4,$4,$21
	lb	$5,4($4)
	lb	$6,5($4)
	addiu	$5,$5,-65
	beq	$2,$0,$L48
	addiu	$6,$6,-48

	sw	$6,32($sp)
	jal	W_GetNumForName
	sw	$5,28($sp)

	lw	$5,28($sp)
	lw	$6,32($sp)
	move	$4,$2
	jal	R_InstallSpriteLump
	move	$7,$0

	lw	$2,%lo(lumpinfo)($17)
	addu	$2,$2,$21
	lb	$5,6($2)
	beq	$5,$0,$L34
	nop

$L61:
	lb	$6,7($2)
	move	$4,$16
	li	$7,1			# 0x1
	addiu	$6,$6,-48
	addiu	$5,$5,-65
	jal	R_InstallSpriteLump
	addiu	$16,$16,1

	slt	$2,$19,$16
	beq	$2,$0,$L31
	addiu	$21,$21,28

$L62:
	lw	$8,%lo(maxframe)($20)
	li	$2,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$8,$2
	beq	$1,$0,$L37
	.set	at
	addiu	$8,$8,1

	blez	$8,$L38
	sw	$8,%lo(maxframe)($20)

	lw	$2,36($sp)
	li	$fp,-1			# 0xffffffffffffffff
	addiu	$2,$2,%lo(sprtemp)
	lw	$3,0($2)
	addiu	$21,$2,16
	.set	noat
	xor	$1,$3,$fp
	beq	$1,$0,$L39
	.set	at
	li	$23,65			# 0x41

$L63:
	li	$4,1			# 0x1
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L41
	.set	at
	nop

	b	$L43
	addiu	$16,$21,-16

$L42:
	.set	noat
	xor	$1,$21,$16
	beq	$1,$0,$L64
	.set	at
	lw	$8,%lo(maxframe)($20)

$L43:
	lh	$3,4($16)
	.set	noat
	xor	$1,$3,$fp
	bne	$1,$0,$L42
	.set	at
	addiu	$16,$16,2

	lw	$5,%lo(spritename)($18)
	lw	$4,24($sp)
	jal	I_Error
	move	$6,$23

	.set	noat
	xor	$1,$21,$16
	bne	$1,$0,$L43
	.set	at
	nop

$L41:
	lw	$8,%lo(maxframe)($20)
$L64:
	addiu	$3,$23,-64
	slt	$3,$3,$8
	addiu	$6,$23,1
	beq	$3,$0,$L38
	addiu	$21,$21,28

$L49:
	lw	$3,-16($21)
	.set	noat
	xor	$1,$3,$fp
	bne	$1,$0,$L63
	.set	at
	move	$23,$6

$L39:
	lw	$5,%lo(spritename)($18)
	lw	$4,44($sp)
	jal	I_Error
	move	$6,$23

	lw	$8,%lo(maxframe)($20)
	addiu	$3,$23,-64
	slt	$3,$3,$8
	addiu	$6,$23,1
	bne	$3,$0,$L49
	addiu	$21,$21,28

$L38:
	lw	$21,52($sp)
	lw	$23,16($sp)
	lw	$16,%lo(sprites)($21)
	sll	$4,$8,3
	addu	$16,$16,$23
	subu	$4,$4,$8
	move	$6,$0
	li	$5,1			# 0x1
	sll	$4,$4,2
	jal	Z_Malloc
	sw	$8,0($16)

	lw	$4,%lo(maxframe)($20)
	lw	$3,%lo(sprites)($21)
	sw	$2,4($16)
	sll	$6,$4,3
	lw	$2,36($sp)
	addu	$3,$3,$23
	subu	$6,$6,$4
	lw	$4,4($3)
	sll	$6,$6,2
	jal	memcpy
	addiu	$5,$2,%lo(sprtemp)

$L32:
	lw	$2,48($sp)
	lw	$3,40($sp)
	lw	$2,%lo(numsprites)($2)
	addiu	$3,$3,1
	sw	$3,40($sp)
	slt	$2,$3,$2
	lw	$3,20($sp)
	addiu	$3,$3,4
	sw	$3,20($sp)
	lw	$3,16($sp)
	addiu	$3,$3,8
	bne	$2,$0,$L45
	sw	$3,16($sp)

$L27:
	lw	$31,108($sp)
	lw	$fp,104($sp)
	lw	$23,100($sp)
	lw	$22,96($sp)
	lw	$21,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	jr	$31
	addiu	$sp,$sp,112

$L37:
	lw	$2,52($sp)
	lw	$3,16($sp)
	lw	$2,%lo(sprites)($2)
	addu	$2,$2,$3
	b	$L32
	sw	$0,0($2)

$L28:
	lui	$2,%hi(numsprites)
	jr	$31
	sw	$0,%lo(numsprites)($2)

	.set	macro
	.set	reorder
	.end	R_InitSpriteDefs
	.size	R_InitSpriteDefs, .-R_InitSpriteDefs
	.align	2
	.globl	R_InitSprites
	.set	nomips16
	.set	nomicromips
	.ent	R_InitSprites
	.type	R_InitSprites, @function
R_InitSprites:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(negonearray)
	addiu	$2,$2,%lo(negonearray)
	addiu	$5,$2,640
	li	$3,-1			# 0xffffffffffffffff
$L66:
	sh	$3,0($2)
	addiu	$2,$2,2
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L66
	.set	at
	nop

	j	R_InitSpriteDefs
	nop

	.set	macro
	.set	reorder
	.end	R_InitSprites
	.size	R_InitSprites, .-R_InitSprites
	.align	2
	.globl	R_ClearSprites
	.set	nomips16
	.set	nomicromips
	.ent	R_ClearSprites
	.type	R_ClearSprites, @function
R_ClearSprites:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(vissprites)
	lui	$3,%hi(vissprite_p)
	addiu	$2,$2,%lo(vissprites)
	jr	$31
	sw	$2,%lo(vissprite_p)($3)

	.set	macro
	.set	reorder
	.end	R_ClearSprites
	.size	R_ClearSprites, .-R_ClearSprites
	.align	2
	.globl	R_NewVisSprite
	.set	nomips16
	.set	nomicromips
	.ent	R_NewVisSprite
	.type	R_NewVisSprite, @function
R_NewVisSprite:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(vissprite_p)
	lui	$3,%hi(vissprites+7680)
	lw	$2,%lo(vissprite_p)($4)
	addiu	$3,$3,%lo(vissprites+7680)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L71
	.set	at
	addiu	$3,$2,60

	jr	$31
	sw	$3,%lo(vissprite_p)($4)

$L71:
	lui	$2,%hi(overflowsprite)
	jr	$31
	addiu	$2,$2,%lo(overflowsprite)

	.set	macro
	.set	reorder
	.end	R_NewVisSprite
	.size	R_NewVisSprite, .-R_NewVisSprite
	.align	2
	.globl	R_DrawMaskedColumn
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawMaskedColumn
	.type	R_DrawMaskedColumn, @function
R_DrawMaskedColumn:
	.frame	$sp,80,$31		# vars= 24, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	sw	$22,64($sp)
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$21,60($sp)
	sw	$20,56($sp)
	sw	$19,52($sp)
	sw	$18,48($sp)
	sw	$17,44($sp)
	sw	$16,40($sp)
	lui	$2,%hi(dc_texturemid)
	lbu	$5,0($4)
	move	$3,$2
	sw	$2,24($sp)
	li	$2,255			# 0xff
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L77
	.set	at
	lw	$22,%lo(dc_texturemid)($3)

	lui	$2,%hi(dc_source)
	sw	$2,28($sp)
	lui	$2,%hi(colfunc)
	move	$19,$4
	lui	$12,%hi(spryscale)
	lui	$11,%hi(sprtopscreen)
	lui	$21,%hi(dc_yl)
	lui	$20,%hi(dc_yh)
	lui	$16,%hi(dc_x)
	lui	$18,%hi(mfloorclip)
	lui	$17,%hi(mceilingclip)
	li	$fp,65535			# 0xffff
	sw	$2,32($sp)
	li	$23,255			# 0xff
	lw	$2,%lo(spryscale)($12)
$L83:
	lbu	$4,1($19)
	multu	$5,$2
	mflo	$6
	lw	$3,%lo(sprtopscreen)($11)
	multu	$4,$2
	mflo	$8
	addu	$3,$6,$3
	lw	$6,%lo(dc_x)($16)
	lw	$7,%lo(mfloorclip)($18)
	sll	$6,$6,1
	addu	$2,$8,$3
	addu	$7,$7,$6
	lh	$7,0($7)
	addiu	$2,$2,-1
	lw	$13,%lo(mceilingclip)($17)
	sra	$2,$2,16
	addu	$3,$3,$fp
	sll	$5,$5,16
	sra	$3,$3,16
	slt	$14,$2,$7
	addu	$6,$13,$6
	subu	$5,$22,$5
	addiu	$13,$19,3
	sw	$3,%lo(dc_yl)($21)
	bne	$14,$0,$L74
	sw	$2,%lo(dc_yh)($20)

	addiu	$2,$7,-1
	sw	$2,%lo(dc_yh)($20)
$L74:
	lh	$6,0($6)
	slt	$7,$6,$3
	bne	$7,$0,$L75
	nop

	addiu	$3,$6,1
	sw	$3,%lo(dc_yl)($21)
$L75:
	slt	$2,$2,$3
	bne	$2,$0,$L82
	addiu	$2,$4,4

	lw	$2,28($sp)
	lw	$3,24($sp)
	sw	$13,%lo(dc_source)($2)
	lw	$2,32($sp)
	sw	$5,%lo(dc_texturemid)($3)
	lw	$2,%lo(colfunc)($2)
	sw	$11,20($sp)
	jalr	$2
	sw	$12,16($sp)

	lbu	$4,1($19)
	lw	$11,20($sp)
	lw	$12,16($sp)
	addiu	$2,$4,4
$L82:
	addu	$19,$19,$2
	lbu	$5,0($19)
	.set	noat
	xor	$1,$5,$23
	bne	$1,$0,$L83
	.set	at
	lw	$2,%lo(spryscale)($12)

$L77:
	lw	$2,24($sp)
	lw	$31,76($sp)
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$21,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	sw	$22,%lo(dc_texturemid)($2)
	lw	$22,64($sp)
	jr	$31
	addiu	$sp,$sp,80

	.set	macro
	.set	reorder
	.end	R_DrawMaskedColumn
	.size	R_DrawMaskedColumn, .-R_DrawMaskedColumn
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"R_DrawSpriteRange: bad texturecolumn\000"
	.text
	.align	2
	.globl	R_DrawVisSprite
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawVisSprite
	.type	R_DrawVisSprite, @function
R_DrawVisSprite:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	lui	$2,%hi(firstspritelump)
	lw	$2,%lo(firstspritelump)($2)
	sw	$22,40($sp)
	move	$22,$4
	lw	$4,48($4)
	li	$5,8			# 0x8
	addu	$4,$4,$2
	sw	$21,36($sp)
	sw	$31,44($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	jal	W_CacheLumpNum
	sw	$16,16($sp)

	lw	$3,52($22)
	move	$21,$2
	lui	$2,%hi(dc_colormap)
	beq	$3,$0,$L96
	sw	$3,%lo(dc_colormap)($2)

	lw	$2,56($22)
	li	$3,201326592			# 0xc000000
	and	$3,$2,$3
	bne	$3,$0,$L94
	sra	$2,$2,18

	lui	$19,%hi(colfunc)
$L86:
	lw	$4,40($22)
	jal	abs
	lui	$17,%hi(dc_x)

	lui	$3,%hi(detailshift)
	lw	$3,%lo(detailshift)($3)
	lw	$4,44($22)
	sra	$2,$2,$3
	lui	$3,%hi(centeryfrac)
	lw	$16,%lo(centeryfrac)($3)
	lui	$3,%hi(dc_iscale)
	sw	$2,%lo(dc_iscale)($3)
	lw	$5,36($22)
	lui	$2,%hi(dc_texturemid)
	sw	$4,%lo(dc_texturemid)($2)
	lui	$2,%hi(spryscale)
	lw	$20,32($22)
	jal	FixedMul
	sw	$5,%lo(spryscale)($2)

	lw	$4,8($22)
	lw	$3,12($22)
	subu	$16,$16,$2
	slt	$3,$3,$4
	lui	$2,%hi(sprtopscreen)
	sw	$16,%lo(sprtopscreen)($2)
	bne	$3,$0,$L87
	sw	$4,%lo(dc_x)($17)

	lui	$18,%hi($LC6)
	addiu	$18,$18,%lo($LC6)
$L90:
	move	$4,$18
	bltz	$20,$L88
	sra	$16,$20,16

	lbu	$3,1($21)
	lbu	$2,0($21)
	sll	$3,$3,8
	or	$3,$3,$2
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$16,$3
	bne	$3,$0,$L97
	addiu	$3,$16,2

$L88:
	jal	I_Error
	nop

	addiu	$3,$16,2
$L97:
	sll	$3,$3,2
	addu	$3,$21,$3
	lwl	$4,3($3)
	lwr	$4,0($3)
	jal	R_DrawMaskedColumn
	addu	$4,$21,$4

	lw	$3,%lo(dc_x)($17)
	lw	$5,12($22)
	addiu	$3,$3,1
	lw	$2,40($22)
	slt	$5,$5,$3
	sw	$3,%lo(dc_x)($17)
	beq	$5,$0,$L90
	addu	$20,$20,$2

$L87:
	lui	$2,%hi(basecolfunc)
	lw	$31,44($sp)
	lw	$2,%lo(basecolfunc)($2)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$2,%lo(colfunc)($19)
	lw	$19,28($sp)
	jr	$31
	addiu	$sp,$sp,48

$L94:
	lui	$3,%hi(translationtables)
	lw	$3,%lo(translationtables)($3)
	andi	$2,$2,0x300
	lui	$4,%hi(transcolfunc)
	lw	$4,%lo(transcolfunc)($4)
	addiu	$2,$2,-256
	addu	$2,$3,$2
	lui	$19,%hi(colfunc)
	lui	$3,%hi(dc_translation)
	sw	$4,%lo(colfunc)($19)
	b	$L86
	sw	$2,%lo(dc_translation)($3)

$L96:
	lui	$2,%hi(fuzzcolfunc)
	lw	$2,%lo(fuzzcolfunc)($2)
	lui	$19,%hi(colfunc)
	b	$L86
	sw	$2,%lo(colfunc)($19)

	.set	macro
	.set	reorder
	.end	R_DrawVisSprite
	.size	R_DrawVisSprite, .-R_DrawVisSprite
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"R_ProjectSprite: invalid sprite number %i \000"
	.align	2
$LC8:
	.ascii	"R_ProjectSprite: invalid sprite frame %i : %i \000"
	.text
	.align	2
	.globl	R_ProjectSprite
	.set	nomips16
	.set	nomicromips
	.ent	R_ProjectSprite
	.type	R_ProjectSprite, @function
R_ProjectSprite:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	lui	$2,%hi(viewx)
	lw	$3,%lo(viewx)($2)
	sw	$19,36($sp)
	lw	$19,12($4)
	sw	$20,40($sp)
	lui	$2,%hi(viewy)
	lui	$20,%hi(viewcos)
	subu	$19,$19,$3
	lw	$2,%lo(viewy)($2)
	lw	$5,%lo(viewcos)($20)
	sw	$18,32($sp)
	lw	$18,16($4)
	sw	$21,44($sp)
	sw	$16,24($sp)
	lui	$21,%hi(viewsin)
	move	$16,$4
	move	$4,$19
	sw	$31,60($sp)
	sw	$17,28($sp)
	subu	$18,$18,$2
	sw	$fp,56($sp)
	sw	$23,52($sp)
	jal	FixedMul
	sw	$22,48($sp)

	lw	$5,%lo(viewsin)($21)
	move	$4,$18
	jal	FixedMul
	move	$17,$2

	addu	$17,$2,$17
	li	$2,262144			# 0x40000
	slt	$2,$17,$2
	beq	$2,$0,$L117
	lui	$2,%hi(projection)

$L98:
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L117:
	lw	$4,%lo(projection)($2)
	jal	FixedDiv
	move	$5,$17

	lw	$5,%lo(viewsin)($21)
	move	$4,$19
	jal	FixedMul
	move	$19,$2

	lw	$5,%lo(viewcos)($20)
	move	$4,$18
	jal	FixedMul
	move	$18,$2

	subu	$18,$18,$2
	jal	abs
	move	$4,$18

	sll	$17,$17,2
	slt	$2,$17,$2
	bne	$2,$0,$L98
	lui	$2,%hi(numsprites)

	lw	$5,36($16)
	lw	$2,%lo(numsprites)($2)
	sltu	$2,$5,$2
	beq	$2,$0,$L118
	nop

$L102:
	lui	$2,%hi(sprites)
	lw	$17,%lo(sprites)($2)
	sll	$2,$5,3
	lw	$6,40($16)
	addu	$17,$17,$2
	lw	$2,0($17)
	andi	$3,$6,0x7fff
	slt	$2,$3,$2
	beq	$2,$0,$L119
	lui	$4,%hi($LC8)

$L103:
	sll	$2,$3,3
	lw	$17,4($17)
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$17,$17,$2
	lw	$2,0($17)
	bne	$2,$0,$L120
	nop

	lh	$20,4($17)
	lbu	$22,20($17)
$L105:
	lui	$2,%hi(spriteoffset)
	lw	$2,%lo(spriteoffset)($2)
	sll	$21,$20,2
	addu	$2,$2,$21
	lw	$2,0($2)
	move	$5,$19
	subu	$18,$18,$2
	move	$4,$18
	jal	FixedMul
	lui	$fp,%hi(centerxfrac)

	lw	$4,%lo(centerxfrac)($fp)
	lui	$6,%hi(viewwidth)
	lw	$3,%lo(viewwidth)($6)
	addu	$17,$2,$4
	sra	$17,$17,16
	slt	$3,$3,$17
	bne	$3,$0,$L98
	sw	$6,16($sp)

	lui	$23,%hi(spritewidth)
	lw	$2,%lo(spritewidth)($23)
	move	$5,$19
	addu	$2,$2,$21
	lw	$4,0($2)
	jal	FixedMul
	addu	$4,$18,$4

	lw	$3,%lo(centerxfrac)($fp)
	addu	$2,$2,$3
	sra	$2,$2,16
	addiu	$2,$2,-1
	bltz	$2,$L98
	lui	$4,%hi(vissprite_p)

	lui	$3,%hi(vissprites+7680)
	lw	$18,%lo(vissprite_p)($4)
	addiu	$3,$3,%lo(vissprites+7680)
	.set	noat
	xor	$1,$18,$3
	beq	$1,$0,$L113
	.set	at
	lw	$6,16($sp)

	addiu	$3,$18,60
	sw	$3,%lo(vissprite_p)($4)
$L106:
	lui	$fp,%hi(detailshift)
	lw	$5,%lo(detailshift)($fp)
	lui	$4,%hi(spritetopoffset)
	lw	$7,16($16)
	lw	$3,20($16)
	lw	$9,104($16)
	lw	$8,12($16)
	lw	$4,%lo(spritetopoffset)($4)
	sll	$5,$19,$5
	sw	$7,20($18)
	sw	$3,24($18)
	addu	$4,$4,$21
	sw	$9,56($18)
	sw	$5,36($18)
	sw	$8,16($18)
	lw	$5,0($4)
	lui	$4,%hi(viewz)
	lw	$4,%lo(viewz)($4)
	lw	$6,%lo(viewwidth)($6)
	addu	$3,$3,$5
	move	$7,$17
	slt	$5,$17,0
	movn	$7,$0,$5
	subu	$4,$3,$4
	slt	$5,$2,$6
	sw	$3,28($18)
	sw	$4,44($18)
	bne	$5,$0,$L107
	sw	$7,8($18)

	addiu	$2,$6,-1
$L107:
	sw	$2,12($18)
	move	$5,$19
	jal	FixedDiv
	li	$4,65536			# 0x10000

	beq	$22,$0,$L108
	move	$4,$0

	lw	$3,%lo(spritewidth)($23)
	subu	$2,$0,$2
	addu	$3,$3,$21
	lw	$4,0($3)
	addiu	$4,$4,-1
$L108:
	lw	$3,8($18)
	sw	$2,40($18)
	slt	$5,$17,$3
	beq	$5,$0,$L109
	sw	$4,32($18)

	subu	$3,$3,$17
	multu	$3,$2
	mflo	$5
	addu	$3,$5,$4
	sw	$3,32($18)
$L109:
	lw	$2,104($16)
	li	$3,262144			# 0x40000
	and	$2,$2,$3
	beq	$2,$0,$L110
	sw	$20,48($18)

	b	$L98
	sw	$0,52($18)

$L120:
	lw	$4,12($16)
	jal	R_PointToAngle
	lw	$5,16($16)

	lw	$4,32($16)
	li	$3,-1879048192			# 0xffffffff90000000
	subu	$3,$3,$4
	addu	$2,$3,$2
	srl	$2,$2,29
	sll	$3,$2,1
	addu	$3,$17,$3
	addu	$17,$17,$2
	lh	$20,4($3)
	b	$L105
	lbu	$22,20($17)

$L119:
	jal	I_Error
	addiu	$4,$4,%lo($LC8)

	lw	$3,40($16)
	b	$L103
	andi	$3,$3,0x7fff

$L118:
	lui	$4,%hi($LC7)
	jal	I_Error
	addiu	$4,$4,%lo($LC7)

	b	$L102
	lw	$5,36($16)

$L110:
	lui	$2,%hi(fixedcolormap)
	lw	$2,%lo(fixedcolormap)($2)
	beq	$2,$0,$L111
	nop

	b	$L98
	sw	$2,52($18)

$L111:
	lw	$2,40($16)
	andi	$2,$2,0x8000
	beq	$2,$0,$L112
	lw	$3,%lo(detailshift)($fp)

	lui	$2,%hi(colormaps)
	lw	$2,%lo(colormaps)($2)
	b	$L98
	sw	$2,52($18)

$L113:
	lui	$18,%hi(overflowsprite)
	b	$L106
	addiu	$18,$18,%lo(overflowsprite)

$L112:
	li	$2,12			# 0xc
	subu	$2,$2,$3
	sra	$19,$19,$2
	slt	$4,$19,48
	lui	$2,%hi(spritelights)
	li	$3,47			# 0x2f
	lw	$2,%lo(spritelights)($2)
	movz	$19,$3,$4
	sll	$19,$19,2
	addu	$2,$2,$19
	lw	$2,0($2)
	b	$L98
	sw	$2,52($18)

	.set	macro
	.set	reorder
	.end	R_ProjectSprite
	.size	R_ProjectSprite, .-R_ProjectSprite
	.align	2
	.globl	R_AddSprites
	.set	nomips16
	.set	nomicromips
	.ent	R_AddSprites
	.type	R_AddSprites, @function
R_AddSprites:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(validcount)
	lw	$3,%lo(validcount)($2)
	lw	$2,68($4)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L135
	.set	at
	lui	$5,%hi(extralight)

	lh	$2,12($4)
	lw	$5,%lo(extralight)($5)
	sra	$2,$2,4
	addiu	$sp,$sp,-24
	addu	$2,$2,$5
	sw	$31,20($sp)
	sw	$16,16($sp)
	bltz	$2,$L125
	sw	$3,68($4)

	slt	$3,$2,16
	beq	$3,$0,$L126
	sll	$3,$2,1

	addu	$3,$3,$2
	lui	$2,%hi(scalelight)
	sll	$3,$3,6
	addiu	$2,$2,%lo(scalelight)
	addu	$2,$2,$3
$L123:
	lw	$16,72($4)
	lui	$3,%hi(spritelights)
	beq	$16,$0,$L121
	sw	$2,%lo(spritelights)($3)

$L124:
	jal	R_ProjectSprite
	move	$4,$16

	lw	$16,24($16)
	bne	$16,$0,$L124
	nop

$L121:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L125:
	lui	$2,%hi(scalelight)
	b	$L123
	addiu	$2,$2,%lo(scalelight)

$L126:
	lui	$2,%hi(scalelight+2880)
	b	$L123
	addiu	$2,$2,%lo(scalelight+2880)

$L135:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_AddSprites
	.size	R_AddSprites, .-R_AddSprites
	.align	2
	.globl	R_DrawPSprite
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawPSprite
	.type	R_DrawPSprite, @function
R_DrawPSprite:
	.frame	$sp,128,$31		# vars= 72, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$3,0($4)
	lui	$2,%hi(numsprites)
	lw	$5,0($3)
	lw	$2,%lo(numsprites)($2)
	addiu	$sp,$sp,-128
	sltu	$2,$5,$2
	sw	$21,108($sp)
	sw	$31,124($sp)
	sw	$fp,120($sp)
	sw	$23,116($sp)
	sw	$22,112($sp)
	sw	$20,104($sp)
	sw	$19,100($sp)
	sw	$18,96($sp)
	sw	$17,92($sp)
	sw	$16,88($sp)
	beq	$2,$0,$L150
	move	$21,$4

$L137:
	lui	$2,%hi(sprites)
	lw	$16,%lo(sprites)($2)
	sll	$2,$5,3
	lw	$6,4($3)
	addu	$16,$16,$2
	lw	$2,0($16)
	andi	$7,$6,0x7fff
	slt	$2,$7,$2
	beq	$2,$0,$L151
	lui	$4,%hi($LC8)

$L138:
	sll	$2,$7,3
	lw	$3,4($16)
	subu	$2,$2,$7
	sll	$2,$2,2
	addu	$2,$3,$2
	lh	$18,4($2)
	lui	$3,%hi(spriteoffset)
	lw	$3,%lo(spriteoffset)($3)
	sll	$22,$18,2
	lw	$20,8($21)
	addu	$3,$3,$22
	lw	$3,0($3)
	li	$4,-10485760			# 0xffffffffff600000
	addu	$20,$20,$4
	lui	$17,%hi(pspritescale)
	subu	$20,$20,$3
	lw	$5,%lo(pspritescale)($17)
	move	$4,$20
	lui	$23,%hi(centerxfrac)
	jal	FixedMul
	lbu	$19,20($2)

	lw	$4,%lo(centerxfrac)($23)
	lui	$fp,%hi(viewwidth)
	lw	$3,%lo(viewwidth)($fp)
	addu	$16,$2,$4
	sra	$16,$16,16
	slt	$3,$3,$16
	beq	$3,$0,$L152
	lui	$3,%hi(spritewidth)

$L136:
	lw	$31,124($sp)
	lw	$fp,120($sp)
	lw	$23,116($sp)
	lw	$22,112($sp)
	lw	$21,108($sp)
	lw	$20,104($sp)
	lw	$19,100($sp)
	lw	$18,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	jr	$31
	addiu	$sp,$sp,128

$L152:
	lw	$2,%lo(spritewidth)($3)
	lw	$5,%lo(pspritescale)($17)
	addu	$2,$2,$22
	lw	$4,0($2)
	sw	$3,80($sp)
	jal	FixedMul
	addu	$4,$20,$4

	lw	$4,%lo(centerxfrac)($23)
	addu	$6,$2,$4
	sra	$6,$6,16
	addiu	$6,$6,-1
	bltz	$6,$L136
	lui	$2,%hi(spritetopoffset)

	lw	$2,%lo(spritetopoffset)($2)
	lw	$5,12($21)
	addu	$2,$2,$22
	lw	$2,0($2)
	lw	$7,%lo(viewwidth)($fp)
	subu	$5,$5,$2
	li	$2,6553600			# 0x640000
	ori	$2,$2,0x8000
	slt	$4,$16,0
	subu	$2,$2,$5
	move	$5,$16
	movn	$5,$0,$4
	slt	$4,$6,$7
	lw	$3,80($sp)
	sw	$0,72($sp)
	sw	$2,60($sp)
	bne	$4,$0,$L140
	sw	$5,24($sp)

	addiu	$6,$7,-1
$L140:
	lui	$4,%hi(detailshift)
	lw	$4,%lo(detailshift)($4)
	lw	$2,%lo(pspritescale)($17)
	sw	$6,28($sp)
	sll	$2,$2,$4
	lui	$4,%hi(pspriteiscale)
	lw	$4,%lo(pspriteiscale)($4)
	bne	$19,$0,$L153
	sw	$2,52($sp)

	move	$3,$0
$L141:
	slt	$2,$16,$5
	sw	$3,48($sp)
	beq	$2,$0,$L142
	sw	$4,56($sp)

	subu	$16,$5,$16
	multu	$16,$4
	mflo	$2
	addu	$16,$2,$3
	sw	$16,48($sp)
$L142:
	lui	$2,%hi(viewplayer)
	lw	$2,%lo(viewplayer)($2)
	sw	$18,64($sp)
	lw	$2,60($2)
	slt	$3,$2,129
	beq	$3,$0,$L148
	nop

	andi	$2,$2,0x8
	bne	$2,$0,$L143
	move	$2,$0

	lui	$2,%hi(fixedcolormap)
	lw	$2,%lo(fixedcolormap)($2)
	beq	$2,$0,$L154
	nop

$L143:
	addiu	$4,$sp,16
	jal	R_DrawVisSprite
	sw	$2,68($sp)

	lw	$31,124($sp)
	lw	$fp,120($sp)
	lw	$23,116($sp)
	lw	$22,112($sp)
	lw	$21,108($sp)
	lw	$20,104($sp)
	lw	$19,100($sp)
	lw	$18,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	jr	$31
	addiu	$sp,$sp,128

$L151:
	jal	I_Error
	addiu	$4,$4,%lo($LC8)

	lw	$2,0($21)
	lw	$7,4($2)
	b	$L138
	andi	$7,$7,0x7fff

$L150:
	lui	$4,%hi($LC7)
	jal	I_Error
	addiu	$4,$4,%lo($LC7)

	lw	$3,0($21)
	b	$L137
	lw	$5,0($3)

$L153:
	lw	$2,%lo(spritewidth)($3)
	subu	$4,$0,$4
	addu	$2,$2,$22
	lw	$3,0($2)
	b	$L141
	addiu	$3,$3,-1

$L148:
	b	$L143
	move	$2,$0

$L154:
	lw	$2,0($21)
	lw	$2,4($2)
	andi	$2,$2,0x8000
	beq	$2,$0,$L144
	nop

	lui	$2,%hi(colormaps)
	b	$L143
	lw	$2,%lo(colormaps)($2)

$L144:
	lui	$2,%hi(spritelights)
	lw	$2,%lo(spritelights)($2)
	b	$L143
	lw	$2,188($2)

	.set	macro
	.set	reorder
	.end	R_DrawPSprite
	.size	R_DrawPSprite, .-R_DrawPSprite
	.align	2
	.globl	R_DrawPlayerSprites
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawPlayerSprites
	.type	R_DrawPlayerSprites, @function
R_DrawPlayerSprites:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	lui	$2,%hi(viewplayer)
	sw	$16,16($sp)
	lw	$16,%lo(viewplayer)($2)
	lui	$3,%hi(extralight)
	lw	$2,0($16)
	lw	$3,%lo(extralight)($3)
	lw	$2,52($2)
	sw	$31,20($sp)
	lw	$2,0($2)
	lh	$2,12($2)
	sra	$2,$2,4
	addu	$2,$2,$3
	bltz	$2,$L159
	slt	$3,$2,16

	beq	$3,$0,$L160
	sll	$3,$2,1

	addu	$3,$3,$2
	lui	$2,%hi(scalelight)
	sll	$3,$3,6
	addiu	$2,$2,%lo(scalelight)
	addu	$2,$2,$3
$L156:
	lui	$4,%hi(spritelights)
	sw	$2,%lo(spritelights)($4)
	lui	$2,%hi(screenheightarray)
	lui	$4,%hi(mfloorclip)
	addiu	$2,$2,%lo(screenheightarray)
	sw	$2,%lo(mfloorclip)($4)
	lw	$3,252($16)
	lui	$2,%hi(negonearray)
	lui	$4,%hi(mceilingclip)
	addiu	$2,$2,%lo(negonearray)
	beq	$3,$0,$L157
	sw	$2,%lo(mceilingclip)($4)

	jal	R_DrawPSprite
	addiu	$4,$16,252

$L157:
	lw	$2,268($16)
	beq	$2,$0,$L155
	lw	$31,20($sp)

	addiu	$4,$16,268
	lw	$16,16($sp)
	j	R_DrawPSprite
	addiu	$sp,$sp,24

$L160:
	lui	$2,%hi(scalelight+2880)
	b	$L156
	addiu	$2,$2,%lo(scalelight+2880)

$L155:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L159:
	lui	$2,%hi(scalelight)
	b	$L156
	addiu	$2,$2,%lo(scalelight)

	.set	macro
	.set	reorder
	.end	R_DrawPlayerSprites
	.size	R_DrawPlayerSprites, .-R_DrawPlayerSprites
	.align	2
	.globl	R_SortVisSprites
	.set	nomips16
	.set	nomicromips
	.ent	R_SortVisSprites
	.type	R_SortVisSprites, @function
R_SortVisSprites:
	.frame	$sp,64,$31		# vars= 64, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(vissprite_p)
	lw	$5,%lo(vissprite_p)($2)
	lui	$9,%hi(vissprites)
	addiu	$7,$9,%lo(vissprites)
	.set	noat
	xor	$1,$5,$7
	beq	$1,$0,$L186
	.set	at
	subu	$6,$5,$7

	sltu	$3,$7,$5
	addiu	$sp,$sp,-64
	beq	$3,$0,$L170
	move	$2,$7

$L167:
	addiu	$2,$2,60
	addiu	$4,$2,-120
	sltu	$3,$2,$5
	sw	$2,-56($2)
	bne	$3,$0,$L167
	sw	$4,-60($2)

$L170:
	lui	$8,%hi(vsprsortedhead)
	addiu	$10,$8,%lo(vsprsortedhead)
	addiu	$2,$5,-60
	sw	$sp,%lo(vissprites)($9)
	sw	$7,4($sp)
	sw	$sp,-56($5)
	sw	$2,0($sp)
	sw	$10,%lo(vsprsortedhead)($8)
	blez	$6,$L165
	sw	$10,4($10)

	li	$2,-286392320			# 0xffffffffeeee0000
	sra	$6,$6,2
	ori	$2,$2,0xeeef
	multu	$6,$2
	mflo	$9
	move	$7,$0
	li	$11,2147418112			# 0x7fff0000
$L174:
	lw	$4,4($sp)
	.set	noat
	xor	$1,$sp,$4
	beq	$1,$0,$L176
	.set	at
	move	$2,$4

	ori	$3,$11,0xffff
$L173:
	lw	$5,36($2)
	slt	$6,$5,$3
	movn	$4,$2,$6
	lw	$2,4($2)
	.set	noat
	xor	$1,$sp,$2
	bne	$1,$0,$L173
	.set	at
	movn	$3,$5,$6

	lw	$5,4($4)
$L171:
	lw	$3,0($4)
	addiu	$7,$7,1
	sw	$3,0($5)
	lw	$2,%lo(vsprsortedhead)($8)
	slt	$6,$7,$9
	sw	$5,4($3)
	sw	$2,0($4)
	sw	$10,4($4)
	sw	$4,%lo(vsprsortedhead)($8)
	bne	$6,$0,$L174
	sw	$4,4($2)

$L165:
	jr	$31
	addiu	$sp,$sp,64

$L176:
	b	$L171
	move	$5,$sp

$L186:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	R_SortVisSprites
	.size	R_SortVisSprites, .-R_SortVisSprites
	.align	2
	.globl	R_DrawSprite
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawSprite
	.type	R_DrawSprite, @function
R_DrawSprite:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	lui	$2,%hi(ds_p)
	lw	$5,8($4)
	lw	$6,12($4)
	sw	$16,24($sp)
	lw	$16,%lo(ds_p)($2)
	slt	$2,$6,$5
	sw	$20,40($sp)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	move	$20,$4
	bne	$2,$0,$L188
	addiu	$16,$16,-48

	lui	$22,%hi(cliptop)
	addiu	$22,$22,%lo(cliptop)
	lui	$21,%hi(clipbot)
	sll	$3,$5,1
	addiu	$21,$21,%lo(clipbot)
	sll	$9,$6,1
	addiu	$8,$22,2
	addu	$2,$22,$3
	addu	$7,$21,$3
	addu	$8,$8,$9
	li	$4,-2			# 0xfffffffffffffffe
$L189:
	sh	$4,0($2)
	addiu	$2,$2,2
	sh	$4,0($7)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L189
	.set	at
	addiu	$7,$7,2

	lui	$23,%hi(drawsegs)
	addiu	$23,$23,%lo(drawsegs)
	sltu	$2,$16,$23
	bne	$2,$0,$L241
	lui	$2,%hi(viewheight)

$L217:
	li	$19,-3			# 0xfffffffffffffffd
	li	$18,1			# 0x1
	li	$17,-2			# 0xfffffffffffffffe
$L212:
	lw	$2,4($16)
	slt	$3,$6,$2
	bne	$3,$0,$L191
	nop

	lw	$7,8($16)
	slt	$3,$7,$5
	bne	$3,$0,$L191
	nop

	lw	$4,24($16)
	bne	$4,$0,$L192
	nop

	lw	$3,44($16)
	beq	$3,$0,$L191
	nop

$L192:
	lw	$3,12($16)
	lw	$8,16($16)
	slt	$11,$2,$5
	slt	$10,$6,$7
	movn	$2,$5,$11
	slt	$9,$8,$3
	move	$fp,$2
	bne	$9,$0,$L193
	movn	$7,$6,$10

	move	$2,$3
	move	$3,$8
	move	$8,$2
$L193:
	lw	$2,36($20)
	slt	$3,$3,$2
	bne	$3,$0,$L194
	slt	$2,$8,$2

	bne	$2,$0,$L236
	nop

$L195:
	lw	$8,28($16)
	lw	$2,24($20)
	lw	$3,28($20)
	slt	$2,$2,$8
	lw	$8,32($16)
	bne	$2,$0,$L197
	slt	$3,$8,$3

	bne	$3,$0,$L237
	and	$4,$4,$17

$L198:
	and	$4,$4,$19
	.set	noat
	xor	$1,$4,$18
	beq	$1,$0,$L242
	.set	at
	slt	$2,$7,$fp

$L191:
	addiu	$16,$16,-48
$L240:
	sltu	$2,$16,$23
	beq	$2,$0,$L212
	slt	$2,$6,$5

	bne	$2,$0,$L218
	sll	$3,$5,1

	sll	$9,$6,1
	lui	$2,%hi(viewheight)
$L241:
	addiu	$8,$21,2
	lh	$10,%lo(viewheight)($2)
	addu	$8,$8,$9
	addu	$2,$21,$3
	li	$4,-2			# 0xfffffffffffffffe
	addu	$3,$22,$3
	li	$9,-1			# 0xffffffffffffffff
$L216:
	lh	$7,0($2)
	.set	noat
	xor	$1,$7,$4
	bne	$1,$0,$L214
	.set	at
	nop

	sh	$10,0($2)
$L214:
	lh	$7,0($3)
	.set	noat
	xor	$1,$7,$4
	bne	$1,$0,$L215
	.set	at
	addiu	$2,$2,2

	sh	$9,0($3)
$L215:
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L216
	.set	at
	addiu	$3,$3,2

$L218:
	lui	$2,%hi(mfloorclip)
	sw	$21,%lo(mfloorclip)($2)
	lui	$2,%hi(mceilingclip)
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$21,44($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	move	$4,$20
	sw	$22,%lo(mceilingclip)($2)
	lw	$20,40($sp)
	lw	$22,48($sp)
	j	R_DrawVisSprite
	addiu	$sp,$sp,64

$L236:
	lw	$6,0($16)
	lw	$5,20($20)
	lw	$4,16($20)
	jal	R_PointOnSegSide
	sw	$7,16($sp)

	bne	$2,$0,$L238
	lw	$7,16($sp)

$L194:
	lw	$2,44($16)
	beq	$2,$0,$L235
	nop

	move	$6,$7
	move	$5,$fp
	jal	R_RenderMaskedSegRange
	move	$4,$16

$L235:
	lw	$5,8($20)
	b	$L191
	lw	$6,12($20)

$L197:
	beq	$3,$0,$L198
	li	$2,1			# 0x1

	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L201
	.set	at
	li	$2,2			# 0x2

	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L219
	.set	at
	li	$2,3			# 0x3

	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L191
	.set	at
	slt	$2,$7,$fp

	bne	$2,$0,$L191
	sll	$2,$fp,1

	addiu	$7,$7,1
	addu	$4,$21,$2
	addu	$3,$22,$2
	sll	$7,$7,1
	li	$8,-2			# 0xfffffffffffffffe
$L211:
	lh	$9,0($4)
	.set	noat
	xor	$1,$9,$8
	bne	$1,$0,$L209
	.set	at
	nop

	lw	$9,40($16)
	addu	$9,$9,$2
	lh	$9,0($9)
	sh	$9,0($4)
$L209:
	lh	$9,0($3)
	.set	noat
	xor	$1,$9,$8
	bne	$1,$0,$L210
	.set	at
	addiu	$4,$4,2

	lw	$9,36($16)
	addu	$9,$9,$2
	lh	$9,0($9)
	sh	$9,0($3)
$L210:
	addiu	$2,$2,2
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L211
	.set	at
	addiu	$3,$3,2

	b	$L240
	addiu	$16,$16,-48

$L237:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L191
	.set	at
	nop

$L219:
	slt	$2,$7,$fp
	bne	$2,$0,$L191
	sll	$2,$fp,1

	addiu	$7,$7,1
	addu	$3,$22,$2
	sll	$7,$7,1
	li	$8,-2			# 0xfffffffffffffffe
$L208:
	lh	$4,0($3)
	.set	noat
	xor	$1,$4,$8
	bne	$1,$0,$L207
	.set	at
	nop

	lw	$4,36($16)
	addu	$4,$4,$2
	lh	$4,0($4)
	sh	$4,0($3)
$L207:
	addiu	$2,$2,2
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L208
	.set	at
	addiu	$3,$3,2

	b	$L240
	addiu	$16,$16,-48

$L238:
	lw	$4,24($16)
	lw	$5,8($20)
	b	$L195
	lw	$6,12($20)

$L201:
	slt	$2,$7,$fp
$L242:
	bne	$2,$0,$L191
	sll	$2,$fp,1

	addiu	$7,$7,1
	addu	$3,$21,$2
	sll	$7,$7,1
	li	$8,-2			# 0xfffffffffffffffe
$L205:
	lh	$4,0($3)
	.set	noat
	xor	$1,$4,$8
	bne	$1,$0,$L204
	.set	at
	nop

	lw	$4,40($16)
	addu	$4,$4,$2
	lh	$4,0($4)
	sh	$4,0($3)
$L204:
	addiu	$2,$2,2
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L205
	.set	at
	addiu	$3,$3,2

	b	$L240
	addiu	$16,$16,-48

$L188:
	lui	$23,%hi(drawsegs)
	addiu	$23,$23,%lo(drawsegs)
	sltu	$2,$16,$23
	bne	$2,$0,$L239
	lui	$22,%hi(cliptop)

	lui	$21,%hi(clipbot)
	addiu	$22,$22,%lo(cliptop)
	b	$L217
	addiu	$21,$21,%lo(clipbot)

$L239:
	lui	$21,%hi(clipbot)
	addiu	$22,$22,%lo(cliptop)
	b	$L218
	addiu	$21,$21,%lo(clipbot)

	.set	macro
	.set	reorder
	.end	R_DrawSprite
	.size	R_DrawSprite, .-R_DrawSprite
	.align	2
	.globl	R_DrawMasked
	.set	nomips16
	.set	nomicromips
	.ent	R_DrawMasked
	.type	R_DrawMasked, @function
R_DrawMasked:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$17,24($sp)
	jal	R_SortVisSprites
	sw	$16,20($sp)

	lui	$2,%hi(vissprite_p)
	lw	$2,%lo(vissprite_p)($2)
	lui	$3,%hi(vissprites)
	addiu	$3,$3,%lo(vissprites)
	sltu	$2,$3,$2
	beq	$2,$0,$L257
	lui	$2,%hi(ds_p)

	lui	$17,%hi(vsprsortedhead)
	addiu	$17,$17,%lo(vsprsortedhead)
	lw	$16,4($17)
	.set	noat
	xor	$1,$16,$17
	beq	$1,$0,$L257
	.set	at
	nop

$L245:
	jal	R_DrawSprite
	move	$4,$16

	lw	$16,4($16)
	.set	noat
	xor	$1,$16,$17
	bne	$1,$0,$L245
	.set	at
	lui	$2,%hi(ds_p)

$L257:
	lw	$16,%lo(ds_p)($2)
	lui	$17,%hi(drawsegs)
	addiu	$16,$16,-48
	addiu	$17,$17,%lo(drawsegs)
	sltu	$2,$16,$17
	bne	$2,$0,$L258
	lui	$2,%hi(viewangleoffset)

$L248:
	lw	$2,44($16)
	beq	$2,$0,$L247
	move	$4,$16

	lw	$6,8($16)
	jal	R_RenderMaskedSegRange
	lw	$5,4($16)

$L247:
	addiu	$16,$16,-48
	sltu	$2,$16,$17
	beq	$2,$0,$L248
	lui	$2,%hi(viewangleoffset)

$L258:
	lw	$2,%lo(viewangleoffset)($2)
	beq	$2,$0,$L256
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L256:
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	R_DrawPlayerSprites
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	R_DrawMasked
	.size	R_DrawMasked, .-R_DrawMasked
	.local	cliptop
	.comm	cliptop,640,4
	.local	clipbot
	.comm	clipbot,640,4
	.globl	vsprsortedhead
	.section	.bss,"aw",@nobits
	.align	2
	.type	vsprsortedhead, @object
	.size	vsprsortedhead, 60
vsprsortedhead:
	.space	60
	.globl	sprtopscreen
	.align	2
	.type	sprtopscreen, @object
	.size	sprtopscreen, 4
sprtopscreen:
	.space	4
	.globl	spryscale
	.align	2
	.type	spryscale, @object
	.size	spryscale, 4
spryscale:
	.space	4
	.globl	mceilingclip
	.align	2
	.type	mceilingclip, @object
	.size	mceilingclip, 4
mceilingclip:
	.space	4
	.globl	mfloorclip
	.align	2
	.type	mfloorclip, @object
	.size	mfloorclip, 4
mfloorclip:
	.space	4
	.globl	overflowsprite
	.align	2
	.type	overflowsprite, @object
	.size	overflowsprite, 60
overflowsprite:
	.space	60
	.globl	newvissprite
	.align	2
	.type	newvissprite, @object
	.size	newvissprite, 4
newvissprite:
	.space	4
	.globl	vissprite_p
	.align	2
	.type	vissprite_p, @object
	.size	vissprite_p, 4
vissprite_p:
	.space	4
	.globl	vissprites
	.align	2
	.type	vissprites, @object
	.size	vissprites, 7680
vissprites:
	.space	7680
	.globl	spritename
	.align	2
	.type	spritename, @object
	.size	spritename, 4
spritename:
	.space	4
	.globl	maxframe
	.align	2
	.type	maxframe, @object
	.size	maxframe, 4
maxframe:
	.space	4
	.globl	sprtemp
	.align	2
	.type	sprtemp, @object
	.size	sprtemp, 812
sprtemp:
	.space	812
	.globl	numsprites
	.align	2
	.type	numsprites, @object
	.size	numsprites, 4
numsprites:
	.space	4
	.globl	sprites
	.align	2
	.type	sprites, @object
	.size	sprites, 4
sprites:
	.space	4
	.globl	screenheightarray
	.align	2
	.type	screenheightarray, @object
	.size	screenheightarray, 640
screenheightarray:
	.space	640
	.globl	negonearray
	.align	2
	.type	negonearray, @object
	.size	negonearray, 640
negonearray:
	.space	640
	.globl	spritelights
	.align	2
	.type	spritelights, @object
	.size	spritelights, 4
spritelights:
	.space	4
	.globl	pspriteiscale
	.align	2
	.type	pspriteiscale, @object
	.size	pspriteiscale, 4
pspriteiscale:
	.space	4
	.globl	pspritescale
	.align	2
	.type	pspritescale, @object
	.size	pspritescale, 4
pspritescale:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
