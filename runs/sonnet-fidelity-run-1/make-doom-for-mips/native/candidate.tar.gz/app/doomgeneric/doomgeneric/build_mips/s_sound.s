	.file	1 "s_sound.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	S_Shutdown
	.set	nomips16
	.set	nomicromips
	.ent	S_Shutdown
	.type	S_Shutdown, @function
S_Shutdown:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	I_ShutdownSound
	nop

	lw	$31,20($sp)
	j	I_ShutdownMusic
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	S_Shutdown
	.size	S_Shutdown, .-S_Shutdown
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	S_StopChannel
	.type	S_StopChannel, @function
S_StopChannel:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sll	$2,$4,1
	lui	$3,%hi(channels)
	addu	$2,$2,$4
	sw	$16,16($sp)
	lw	$16,%lo(channels)($3)
	sll	$2,$2,2
	addu	$16,$16,$2
	lw	$2,0($16)
	beq	$2,$0,$L4
	sw	$31,20($sp)

	jal	I_SoundIsPlaying
	lw	$4,8($16)

	bne	$2,$0,$L14
	nop

	lw	$3,0($16)
$L15:
	lw	$2,32($3)
	addiu	$2,$2,-1
	sw	$2,32($3)
	sw	$0,0($16)
$L4:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L14:
	jal	I_StopSound
	lw	$4,8($16)

	b	$L15
	lw	$3,0($16)

	.set	macro
	.set	reorder
	.end	S_StopChannel
	.size	S_StopChannel, .-S_StopChannel
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	S_AdjustSoundParams
	.type	S_AdjustSoundParams, @function
S_AdjustSoundParams:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	lw	$2,12($5)
	sw	$20,36($sp)
	move	$20,$4
	lw	$4,12($4)
	sw	$21,40($sp)
	subu	$4,$4,$2
	move	$21,$5
	sw	$31,44($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	move	$17,$7
	jal	abs
	move	$16,$6

	lw	$3,16($21)
	lw	$4,16($20)
	move	$19,$2
	jal	abs
	subu	$4,$4,$3

	slt	$4,$2,$19
	move	$3,$2
	lui	$18,%hi(gamemap)
	movz	$3,$19,$4
	lw	$4,%lo(gamemap)($18)
	addu	$19,$19,$2
	sra	$2,$3,1
	li	$3,8			# 0x8
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L17
	.set	at
	subu	$19,$19,$2

	li	$2,78643200			# 0x4b00000
	addiu	$2,$2,1
	slt	$2,$19,$2
	beq	$2,$0,$L24
	lw	$31,44($sp)

$L17:
	lw	$4,12($20)
	lw	$7,16($21)
	lw	$6,12($21)
	jal	R_PointToAngle2
	lw	$5,16($20)

	lw	$3,32($20)
	sltu	$4,$3,$2
	beq	$4,$0,$L19
	subu	$2,$2,$3

$L20:
	srl	$2,$2,19
	lui	$3,%hi(finesine)
	addiu	$3,$3,%lo(finesine)
	sll	$2,$2,2
	addu	$2,$2,$3
	lw	$5,0($2)
	jal	FixedMul
	li	$4,6291456			# 0x600000

	sra	$2,$2,16
	li	$3,128			# 0x80
	subu	$3,$3,$2
	li	$2,13107200			# 0xc80000
	slt	$2,$19,$2
	bne	$2,$0,$L26
	sw	$3,0($17)

	lw	$3,%lo(gamemap)($18)
	lui	$4,%hi(snd_SfxVolume)
	li	$2,8			# 0x8
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L27
	.set	at
	lw	$4,%lo(snd_SfxVolume)($4)

	li	$3,78643200			# 0x4b00000
	subu	$3,$3,$19
	sra	$3,$3,16
	multu	$3,$4
	mflo	$3
	li	$2,274857984			# 0x10620000
	addiu	$2,$2,19923
	mult	$3,$2
	sra	$3,$3,31
	mfhi	$2
	sra	$2,$2,6
	subu	$2,$2,$3
$L22:
	lw	$31,44($sp)
	sw	$2,0($16)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	slt	$2,$0,$2
	jr	$31
	addiu	$sp,$sp,48

$L26:
	lui	$2,%hi(snd_SfxVolume)
	b	$L22
	lw	$2,%lo(snd_SfxVolume)($2)

$L19:
	b	$L20
	addiu	$2,$2,-1

$L24:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,48

$L27:
	li	$3,78643200			# 0x4b00000
	addiu	$5,$3,1
	slt	$5,$19,$5
	movz	$19,$3,$5
	subu	$3,$3,$19
	sra	$3,$3,16
	addiu	$4,$4,-15
	multu	$3,$4
	mflo	$3
	li	$2,274857984			# 0x10620000
	addiu	$2,$2,19923
	mult	$3,$2
	sra	$3,$3,31
	mfhi	$2
	sra	$2,$2,6
	subu	$2,$2,$3
	b	$L22
	addiu	$2,$2,15

	.set	macro
	.set	reorder
	.end	S_AdjustSoundParams
	.size	S_AdjustSoundParams, .-S_AdjustSoundParams
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC1:
	.ascii	"Attempt to set sfx volume at %d\000"
	.align	2
$LC2:
	.ascii	"Attempt to set music volume at %d\000"
	.text
	.align	2
	.globl	S_Init
	.set	nomips16
	.set	nomicromips
	.ent	S_Init
	.type	S_Init, @function
S_Init:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	lui	$16,%hi(S_sfx)
	sw	$18,24($sp)
	sw	$17,20($sp)
	move	$18,$4
	move	$17,$5
	addiu	$4,$16,%lo(S_sfx)
	sw	$31,28($sp)
	jal	I_PrecacheSounds
	li	$5,109			# 0x6d

	sltu	$2,$18,128
	beq	$2,$0,$L37
	lui	$3,%hi(snd_SfxVolume)

	sltu	$2,$17,128
	beq	$2,$0,$L38
	sw	$18,%lo(snd_SfxVolume)($3)

$L30:
	move	$4,$17
$L39:
	jal	I_SetMusicVolume
	lui	$17,%hi(snd_channels)

	lw	$2,%lo(snd_channels)($17)
	move	$6,$0
	sll	$4,$2,1
	addu	$4,$4,$2
	sll	$4,$4,2
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$4,%lo(snd_channels)($17)
	lui	$3,%hi(channels)
	blez	$4,$L31
	sw	$2,%lo(channels)($3)

	sll	$3,$4,1
	addu	$3,$3,$4
	sll	$3,$3,2
	addu	$3,$2,$3
$L32:
	sw	$0,0($2)
	addiu	$2,$2,12
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L32
	.set	at
	nop

$L31:
	lui	$2,%hi(mus_paused)
	addiu	$4,$16,%lo(S_sfx)
	sw	$0,%lo(mus_paused)($2)
	lui	$2,%hi(S_sfx+80)
	addiu	$2,$2,%lo(S_sfx+80)
	addiu	$4,$4,5264
	li	$3,-1			# 0xffffffffffffffff
$L33:
	sw	$3,0($2)
	sw	$3,4($2)
	addiu	$2,$2,48
	.set	noat
	xor	$1,$2,$4
	bne	$1,$0,$L33
	.set	at
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	lui	$4,%hi(S_Shutdown)
	li	$5,1			# 0x1
	addiu	$4,$4,%lo(S_Shutdown)
	j	I_AtExit
	addiu	$sp,$sp,32

$L37:
	lui	$4,%hi($LC1)
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	lui	$3,%hi(snd_SfxVolume)
	sltu	$2,$17,128
	bne	$2,$0,$L30
	sw	$18,%lo(snd_SfxVolume)($3)

$L38:
	lui	$4,%hi($LC2)
	move	$5,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	b	$L39
	move	$4,$17

	.set	macro
	.set	reorder
	.end	S_Init
	.size	S_Init, .-S_Init
	.align	2
	.globl	S_StopSound
	.set	nomips16
	.set	nomicromips
	.ent	S_StopSound
	.type	S_StopSound, @function
S_StopSound:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(snd_channels)
	lw	$5,%lo(snd_channels)($2)
	blez	$5,$L49
	move	$6,$4

	lui	$2,%hi(channels)
	lw	$2,%lo(channels)($2)
	move	$4,$0
$L43:
	lw	$3,0($2)
	beq	$3,$0,$L42
	nop

	lw	$3,4($2)
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L48
	.set	at
	nop

$L42:
	addiu	$4,$4,1
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L43
	.set	at
	addiu	$2,$2,12

$L49:
	jr	$31
	nop

$L48:
	j	S_StopChannel
	nop

	.set	macro
	.set	reorder
	.end	S_StopSound
	.size	S_StopSound, .-S_StopSound
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"Bad sfx #: %d\000"
	.text
	.align	2
	.globl	S_StartSound
	.set	nomips16
	.set	nomicromips
	.ent	S_StartSound
	.type	S_StartSound, @function
S_StartSound:
	.frame	$sp,64,$31		# vars= 16, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$21,52($sp)
	lui	$21,%hi(snd_SfxVolume)
	sw	$16,32($sp)
	addiu	$2,$5,-1
	lw	$16,%lo(snd_SfxVolume)($21)
	sltu	$2,$2,109
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$31,60($sp)
	sw	$22,56($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	move	$18,$5
	move	$17,$4
	beq	$2,$0,$L98
	sw	$16,16($sp)

	sll	$20,$18,1
$L106:
	addu	$2,$20,$18
	lui	$19,%hi(S_sfx)
	addiu	$19,$19,%lo(S_sfx)
	sll	$2,$2,4
	addu	$2,$19,$2
	lw	$3,20($2)
	beq	$3,$0,$L53
	nop

	lw	$2,28($2)
	addu	$16,$16,$2
	blez	$16,$L50
	sw	$16,16($sp)

	lw	$2,%lo(snd_SfxVolume)($21)
	slt	$16,$2,$16
	bne	$16,$0,$L99
	nop

$L53:
	beq	$17,$0,$L56
	lui	$21,%hi(consoleplayer)

	lw	$3,%lo(consoleplayer)($21)
	lui	$16,%hi(players)
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,5
	addiu	$16,$16,%lo(players)
	addu	$2,$2,$16
	lw	$4,0($2)
	.set	noat
	xor	$1,$4,$17
	beq	$1,$0,$L56
	.set	at
	move	$5,$17

	addiu	$7,$sp,20
	jal	S_AdjustSoundParams
	addiu	$6,$sp,16

	lw	$4,%lo(consoleplayer)($21)
	lw	$5,12($17)
	sll	$3,$4,3
	addu	$3,$3,$4
	sll	$3,$3,5
	addu	$3,$3,$16
	lw	$3,0($3)
	lw	$4,12($3)
	.set	noat
	xor	$1,$5,$4
	beq	$1,$0,$L100
	.set	at
	nop

$L57:
	bne	$2,$0,$L108
	lui	$22,%hi(snd_channels)

$L50:
	lw	$31,60($sp)
$L110:
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,64

$L56:
	li	$2,128			# 0x80
	sw	$2,20($sp)
	lui	$22,%hi(snd_channels)
$L108:
	lw	$3,%lo(snd_channels)($22)
	blez	$3,$L59
	move	$4,$0

	lui	$21,%hi(channels)
	lw	$2,%lo(channels)($21)
$L62:
	lw	$6,0($2)
	beq	$6,$0,$L60
	nop

	lw	$5,4($2)
	.set	noat
	xor	$1,$17,$5
	beq	$1,$0,$L101
	.set	at
	nop

$L60:
	addiu	$4,$4,1
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L62
	.set	at
	addiu	$2,$2,12

	lw	$2,%lo(channels)($21)
$L109:
	b	$L65
	move	$16,$0

$L103:
	beq	$17,$0,$L64
	nop

	lw	$5,4($2)
	.set	noat
	xor	$1,$17,$5
	beq	$1,$0,$L102
	.set	at
	nop

$L64:
	addiu	$16,$16,1
	.set	noat
	xor	$1,$16,$3
	beq	$1,$0,$L66
	.set	at
	addiu	$2,$2,12

$L65:
	lw	$6,0($2)
	bne	$6,$0,$L103
	nop

$L63:
	.set	noat
	xor	$1,$3,$16
	beq	$1,$0,$L67
	.set	at
	sll	$22,$16,1

$L107:
	addu	$22,$22,$16
	sll	$22,$22,2
$L68:
	lw	$2,%lo(channels)($21)
	addu	$4,$20,$18
	sll	$4,$4,4
	addu	$4,$19,$4
	addu	$18,$2,$22
	sw	$4,0($18)
	sw	$17,4($18)
	lw	$2,32($4)
	lw	$3,36($4)
	slt	$5,$2,0
	movn	$2,$0,$5
	addiu	$2,$2,1
	bltz	$3,$L104
	sw	$2,32($4)

$L72:
	lw	$7,20($sp)
	lw	$6,16($sp)
	jal	I_StartSound
	move	$5,$16

	lw	$31,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	sw	$2,8($18)
	lw	$18,40($sp)
	jr	$31
	addiu	$sp,$sp,64

$L99:
	b	$L53
	sw	$2,16($sp)

$L98:
	lui	$4,%hi($LC3)
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	b	$L106
	sll	$20,$18,1

$L101:
	jal	S_StopChannel
	nop

	lw	$3,%lo(snd_channels)($22)
	bgtz	$3,$L109
	lw	$2,%lo(channels)($21)

$L59:
	beq	$3,$0,$L50
	move	$22,$0

	move	$16,$0
	b	$L68
	lui	$21,%hi(channels)

$L67:
	beq	$3,$0,$L110
	lw	$31,60($sp)

$L66:
	addu	$2,$20,$18
	sll	$2,$2,4
	addu	$2,$19,$2
	lw	$5,16($2)
	lw	$4,%lo(channels)($21)
	b	$L71
	move	$16,$0

$L105:
	addiu	$16,$16,1
	.set	noat
	xor	$1,$3,$16
	beq	$1,$0,$L110
	.set	at
	lw	$31,60($sp)

$L71:
	lw	$2,0($4)
	lw	$2,16($2)
	slt	$2,$2,$5
	bne	$2,$0,$L105
	addiu	$4,$4,12

	.set	noat
	xor	$1,$3,$16
	beq	$1,$0,$L110
	.set	at
	lw	$31,60($sp)

	jal	S_StopChannel
	move	$4,$16

	b	$L107
	sll	$22,$16,1

$L102:
	jal	S_StopChannel
	move	$4,$16

	b	$L63
	lw	$3,%lo(snd_channels)($22)

$L104:
	jal	I_GetSfxLumpNum
	sw	$4,24($sp)

	lw	$18,%lo(channels)($21)
	lw	$4,24($sp)
	addu	$18,$18,$22
	b	$L72
	sw	$2,36($4)

$L100:
	lw	$4,16($17)
	lw	$3,16($3)
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L57
	.set	at
	nop

	li	$3,128			# 0x80
	b	$L57
	sw	$3,20($sp)

	.set	macro
	.set	reorder
	.end	S_StartSound
	.size	S_StartSound, .-S_StartSound
	.align	2
	.globl	S_PauseSound
	.set	nomips16
	.set	nomicromips
	.ent	S_PauseSound
	.type	S_PauseSound, @function
S_PauseSound:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(mus_playing)
	lw	$2,%lo(mus_playing)($2)
	beq	$2,$0,$L121
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(mus_paused)
	lw	$2,%lo(mus_paused)($16)
	beq	$2,$0,$L120
	sw	$31,20($sp)

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L120:
	jal	I_PauseSong
	nop

	lw	$31,20($sp)
	li	$2,1			# 0x1
	sw	$2,%lo(mus_paused)($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L121:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	S_PauseSound
	.size	S_PauseSound, .-S_PauseSound
	.align	2
	.globl	S_ResumeSound
	.set	nomips16
	.set	nomicromips
	.ent	S_ResumeSound
	.type	S_ResumeSound, @function
S_ResumeSound:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(mus_playing)
	lw	$2,%lo(mus_playing)($2)
	beq	$2,$0,$L135
	nop

	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(mus_paused)
	lw	$2,%lo(mus_paused)($16)
	bne	$2,$0,$L134
	sw	$31,20($sp)

	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L134:
	jal	I_ResumeSong
	nop

	lw	$31,20($sp)
	sw	$0,%lo(mus_paused)($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L135:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	S_ResumeSound
	.size	S_ResumeSound, .-S_ResumeSound
	.align	2
	.globl	S_UpdateSounds
	.set	nomips16
	.set	nomicromips
	.ent	S_UpdateSounds
	.type	S_UpdateSounds, @function
S_UpdateSounds:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$17,28($sp)
	lui	$17,%hi(snd_channels)
	sw	$19,36($sp)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$18,32($sp)
	sw	$16,24($sp)
	jal	I_UpdateSound
	move	$19,$4

	lw	$2,%lo(snd_channels)($17)
	blez	$2,$L136
	move	$23,$0

	move	$22,$0
	lui	$18,%hi(channels)
	lui	$21,%hi(snd_SfxVolume)
	li	$20,128			# 0x80
$L147:
	lw	$16,%lo(channels)($18)
	addu	$16,$16,$23
	lw	$fp,0($16)
	beq	$fp,$0,$L153
	lw	$2,%lo(snd_channels)($17)

	jal	I_SoundIsPlaying
	lw	$4,8($16)

	beq	$2,$0,$L140
	lw	$3,%lo(snd_SfxVolume)($21)

	lw	$2,20($fp)
	sw	$3,20($sp)
	beq	$2,$0,$L142
	sw	$20,16($sp)

	lw	$2,28($fp)
	addu	$2,$3,$2
	blez	$2,$L140
	sw	$2,20($sp)

	slt	$2,$3,$2
	beq	$2,$0,$L142
	nop

	sw	$3,20($sp)
$L142:
	lw	$5,4($16)
	beq	$5,$0,$L153
	lw	$2,%lo(snd_channels)($17)

	.set	noat
	xor	$1,$5,$19
	beq	$1,$0,$L153
	.set	at
	addiu	$7,$sp,16

	addiu	$6,$sp,20
	jal	S_AdjustSoundParams
	move	$4,$19

	bne	$2,$0,$L146
	lw	$6,16($sp)

$L140:
	jal	S_StopChannel
	move	$4,$22

	lw	$2,%lo(snd_channels)($17)
$L153:
	addiu	$22,$22,1
	slt	$2,$22,$2
	bne	$2,$0,$L147
	addiu	$23,$23,12

$L136:
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L146:
	lw	$5,20($sp)
	jal	I_UpdateSoundParams
	lw	$4,8($16)

	b	$L153
	lw	$2,%lo(snd_channels)($17)

	.set	macro
	.set	reorder
	.end	S_UpdateSounds
	.size	S_UpdateSounds, .-S_UpdateSounds
	.align	2
	.globl	S_SetMusicVolume
	.set	nomips16
	.set	nomicromips
	.ent	S_SetMusicVolume
	.type	S_SetMusicVolume, @function
S_SetMusicVolume:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sltu	$2,$4,128
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$2,$0,$L157
	move	$16,$4

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	I_SetMusicVolume
	addiu	$sp,$sp,24

$L157:
	move	$5,$4
	lui	$4,%hi($LC2)
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	I_SetMusicVolume
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	S_SetMusicVolume
	.size	S_SetMusicVolume, .-S_SetMusicVolume
	.align	2
	.globl	S_SetSfxVolume
	.set	nomips16
	.set	nomicromips
	.ent	S_SetSfxVolume
	.type	S_SetSfxVolume, @function
S_SetSfxVolume:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sltu	$2,$4,128
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$2,$0,$L161
	move	$16,$4

	lw	$31,20($sp)
	lui	$2,%hi(snd_SfxVolume)
	sw	$16,%lo(snd_SfxVolume)($2)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L161:
	move	$5,$4
	lui	$4,%hi($LC1)
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	lw	$31,20($sp)
	lui	$2,%hi(snd_SfxVolume)
	sw	$16,%lo(snd_SfxVolume)($2)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	S_SetSfxVolume
	.size	S_SetSfxVolume, .-S_SetSfxVolume
	.align	2
	.globl	S_MusicPlaying
	.set	nomips16
	.set	nomicromips
	.ent	S_MusicPlaying
	.type	S_MusicPlaying, @function
S_MusicPlaying:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	I_MusicIsPlaying
	nop

	.set	macro
	.set	reorder
	.end	S_MusicPlaying
	.size	S_MusicPlaying, .-S_MusicPlaying
	.align	2
	.globl	S_StopMusic
	.set	nomips16
	.set	nomicromips
	.ent	S_StopMusic
	.type	S_StopMusic, @function
S_StopMusic:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(mus_playing)
	lw	$2,%lo(mus_playing)($16)
	beq	$2,$0,$L163
	sw	$31,20($sp)

	lui	$2,%hi(mus_paused)
	lw	$2,%lo(mus_paused)($2)
	bne	$2,$0,$L173
	nop

$L165:
	jal	I_StopSong
	nop

	lw	$2,%lo(mus_playing)($16)
	jal	I_UnRegisterSong
	lw	$4,12($2)

	lw	$2,%lo(mus_playing)($16)
	jal	W_ReleaseLumpNum
	lw	$4,4($2)

	lw	$2,%lo(mus_playing)($16)
	sw	$0,%lo(mus_playing)($16)
	sw	$0,8($2)
$L163:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L173:
	jal	I_ResumeSong
	nop

	b	$L165
	nop

	.set	macro
	.set	reorder
	.end	S_StopMusic
	.size	S_StopMusic, .-S_StopMusic
	.section	.rodata.str1.4
	.align	2
$LC4:
	.ascii	"Bad music number %d\000"
	.align	2
$LC5:
	.ascii	"d_%s\000"
	.text
	.align	2
	.globl	S_ChangeMusic
	.set	nomips16
	.set	nomicromips
	.ent	S_ChangeMusic
	.type	S_ChangeMusic, @function
S_ChangeMusic:
	.frame	$sp,56,$31		# vars= 16, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	li	$2,29			# 0x1d
	sw	$17,40($sp)
	sw	$31,52($sp)
	sw	$19,48($sp)
	sw	$18,44($sp)
	sw	$16,36($sp)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L184
	.set	at
	move	$17,$5

	addiu	$2,$4,-1
	sltu	$2,$2,67
	bne	$2,$0,$L185
	move	$5,$4

	lui	$4,%hi($LC4)
	jal	I_Error
	addiu	$4,$4,%lo($LC4)

	move	$16,$0
$L179:
	lui	$19,%hi(mus_playing)
	lw	$2,%lo(mus_playing)($19)
	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L187
	.set	at
	lw	$31,52($sp)

	jal	S_StopMusic
	nop

	lw	$4,4($16)
	beq	$4,$0,$L186
	lui	$6,%hi($LC5)

$L181:
	jal	W_CacheLumpNum
	li	$5,1			# 0x1

	lw	$4,4($16)
	sw	$2,8($16)
	jal	W_LumpLength
	move	$18,$2

	move	$5,$2
	jal	I_RegisterSong
	move	$4,$18

	move	$4,$2
	sw	$2,12($16)
	jal	I_PlaySong
	move	$5,$17

	sw	$16,%lo(mus_playing)($19)
	lw	$31,52($sp)
$L187:
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,56

$L185:
	sll	$4,$4,4
$L176:
	lui	$16,%hi(S_music)
	addiu	$16,$16,%lo(S_music)
	b	$L179
	addu	$16,$16,$4

$L184:
	lui	$2,%hi(snd_musicdevice)
	lw	$2,%lo(snd_musicdevice)($2)
	li	$4,512			# 0x200
	addiu	$2,$2,-2
	sltu	$2,$2,2
	li	$3,464			# 0x1d0
	b	$L176
	movz	$4,$3,$2

$L186:
	lw	$7,0($16)
	addiu	$6,$6,%lo($LC5)
	li	$5,9			# 0x9
	jal	M_snprintf
	addiu	$4,$sp,16

	jal	W_GetNumForName
	addiu	$4,$sp,16

	move	$4,$2
	b	$L181
	sw	$2,4($16)

	.set	macro
	.set	reorder
	.end	S_ChangeMusic
	.size	S_ChangeMusic, .-S_ChangeMusic
	.rdata
	.align	2
$LC0:
	.word	22
	.word	20
	.word	21
	.word	5
	.word	16
	.word	13
	.word	15
	.word	14
	.word	9
	.text
	.align	2
	.globl	S_Start
	.set	nomips16
	.set	nomicromips
	.ent	S_Start
	.type	S_Start, @function
S_Start:
	.frame	$sp,80,$31		# vars= 40, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	sw	$18,68($sp)
	lui	$18,%hi(snd_channels)
	lw	$2,%lo(snd_channels)($18)
	sw	$31,76($sp)
	sw	$19,72($sp)
	sw	$17,64($sp)
	blez	$2,$L193
	sw	$16,60($sp)

	move	$17,$0
	move	$16,$0
	lui	$19,%hi(channels)
$L189:
	lw	$2,%lo(channels)($19)
	move	$4,$16
	addu	$2,$2,$17
	lw	$2,0($2)
	beq	$2,$0,$L192
	addiu	$16,$16,1

	jal	S_StopChannel
	nop

$L192:
	lw	$2,%lo(snd_channels)($18)
	slt	$2,$16,$2
	bne	$2,$0,$L189
	addiu	$17,$17,12

$L193:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	lui	$4,%hi(gamemap)
	lui	$5,%hi(mus_paused)
	li	$2,2			# 0x2
	lw	$4,%lo(gamemap)($4)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L206
	.set	at
	sw	$0,%lo(mus_paused)($5)

	lui	$2,%hi($LC0)
	addiu	$2,$2,%lo($LC0)
	addiu	$3,$sp,16
	addiu	$9,$2,32
$L195:
	lw	$8,0($2)
	lw	$7,4($2)
	lw	$6,8($2)
	lw	$5,12($2)
	addiu	$2,$2,16
	sw	$8,0($3)
	sw	$7,4($3)
	sw	$6,8($3)
	sw	$5,12($3)
	.set	noat
	xor	$1,$2,$9
	bne	$1,$0,$L195
	.set	at
	addiu	$3,$3,16

	lui	$5,%hi(gameepisode)
	lw	$5,%lo(gameepisode)($5)
	lw	$6,0($2)
	slt	$2,$5,4
	bne	$2,$0,$L207
	sw	$6,0($3)

	addiu	$4,$4,-1
	sll	$4,$4,2
	addiu	$2,$sp,16
	addu	$2,$2,$4
	lw	$31,76($sp)
	lw	$19,72($sp)
	lw	$18,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	lw	$4,0($2)
	li	$5,1			# 0x1
	j	S_ChangeMusic
	addiu	$sp,$sp,80

$L207:
	addiu	$5,$5,-1
	sll	$2,$5,3
	lw	$31,76($sp)
	lw	$19,72($sp)
	lw	$18,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	addu	$2,$2,$5
	addu	$4,$4,$2
	li	$5,1			# 0x1
	j	S_ChangeMusic
	addiu	$sp,$sp,80

$L206:
	lw	$31,76($sp)
	lw	$19,72($sp)
	lw	$18,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	addiu	$4,$4,32
	li	$5,1			# 0x1
	j	S_ChangeMusic
	addiu	$sp,$sp,80

	.set	macro
	.set	reorder
	.end	S_Start
	.size	S_Start, .-S_Start
	.align	2
	.globl	S_StartMusic
	.set	nomips16
	.set	nomicromips
	.ent	S_StartMusic
	.type	S_StartMusic, @function
S_StartMusic:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	S_ChangeMusic
	move	$5,$0

	.set	macro
	.set	reorder
	.end	S_StartMusic
	.size	S_StartMusic, .-S_StartMusic
	.globl	snd_channels
	.data
	.align	2
	.type	snd_channels, @object
	.size	snd_channels, 4
snd_channels:
	.word	8
	.local	mus_playing
	.comm	mus_playing,4,4
	.local	mus_paused
	.comm	mus_paused,4,4
	.local	snd_SfxVolume
	.comm	snd_SfxVolume,4,4
	.globl	musicVolume
	.align	2
	.type	musicVolume, @object
	.size	musicVolume, 4
musicVolume:
	.word	8
	.globl	sfxVolume
	.align	2
	.type	sfxVolume, @object
	.size	sfxVolume, 4
sfxVolume:
	.word	8
	.local	channels
	.comm	channels,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
