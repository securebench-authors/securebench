	.file	1 "softfp.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	pack.part.0
	.type	pack.part.0, @function
pack.part.0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$3,$7,21
	beq	$3,$0,$L2
	lw	$2,16($sp)

$L4:
	sll	$5,$7,31
	srl	$6,$6,1
	srl	$3,$7,22
	or	$6,$5,$6
	srl	$7,$7,1
	bne	$3,$0,$L4
	addiu	$2,$2,1

$L5:
	addiu	$2,$2,1075
	slt	$3,$2,2047
	beq	$3,$0,$L15
	sll	$4,$4,31

$L8:
	blez	$2,$L16
	nop

	li	$3,983040			# 0xf0000
	ori	$3,$3,0xffff
	and	$3,$7,$3
	or	$3,$3,$4
	sll	$2,$2,20
	or	$3,$3,$2
	jr	$31
	move	$2,$6

$L2:
	srl	$3,$7,20
	bne	$3,$0,$L5
	nop

$L6:
	sll	$7,$7,1
	srl	$3,$6,31
	srl	$5,$7,20
	sll	$6,$6,1
	or	$7,$3,$7
	beq	$5,$0,$L6
	addiu	$2,$2,-1

	addiu	$2,$2,1075
	slt	$3,$2,2047
	bne	$3,$0,$L8
	sll	$4,$4,31

$L15:
	li	$2,2146435072			# 0x7ff00000
	or	$4,$4,$2
	move	$3,$4
	jr	$31
	move	$2,$0

$L16:
	move	$2,$0
	jr	$31
	move	$3,$4

	.set	macro
	.set	reorder
	.end	pack.part.0
	.size	pack.part.0, .-pack.part.0
	.align	2
	.globl	__udivmoddi4
	.set	nomips16
	.set	nomicromips
	.ent	__udivmoddi4
	.type	__udivmoddi4, @function
__udivmoddi4:
	.frame	$sp,16,$31		# vars= 0, regs= 4/0, args= 0, gp= 0
	.mask	0x000f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-16
	sw	$16,0($sp)
	lw	$16,32($sp)
	sw	$19,12($sp)
	sw	$18,8($sp)
	sw	$17,4($sp)
	li	$8,63			# 0x3f
	move	$9,$0
	move	$11,$0
	move	$2,$0
	move	$14,$0
	sll	$24,$5,1
	li	$25,1			# 0x1
	li	$15,-1			# 0xffffffffffffffff
	nor	$10,$0,$8
$L28:
	srl	$12,$9,31
	sll	$13,$11,1
	sll	$10,$24,$10
	srl	$3,$4,$8
	or	$13,$12,$13
	or	$3,$10,$3
	andi	$17,$8,0x20
	srl	$12,$5,$8
	movn	$3,$12,$17
	sll	$9,$9,1
	andi	$3,$3,0x1
	sltu	$10,$13,$7
	move	$11,$13
	bne	$10,$0,$L18
	or	$9,$3,$9

	sll	$10,$25,$8
	move	$18,$10
	subu	$12,$9,$6
	subu	$3,$13,$7
	sltu	$19,$9,$12
	movz	$18,$0,$17
	movn	$10,$0,$17
	.set	noat
	xor	$1,$7,$11
	bne	$1,$0,$L22
	.set	at
	sltu	$13,$9,$6

	bne	$13,$0,$L18
	nop

$L22:
	move	$9,$12
	subu	$11,$3,$19
	or	$2,$2,$10
	or	$14,$14,$18
$L18:
	addiu	$8,$8,-1
	.set	noat
	xor	$1,$8,$15
	bne	$1,$0,$L28
	.set	at
	nor	$10,$0,$8

	beq	$16,$0,$L29
	lw	$19,12($sp)

	sw	$9,0($16)
	sw	$11,4($16)
	lw	$19,12($sp)
$L29:
	lw	$18,8($sp)
	lw	$17,4($sp)
	lw	$16,0($sp)
	move	$3,$14
	jr	$31
	addiu	$sp,$sp,16

	.set	macro
	.set	reorder
	.end	__udivmoddi4
	.size	__udivmoddi4, .-__udivmoddi4
	.align	2
	.globl	__udivdi3
	.set	nomips16
	.set	nomicromips
	.ent	__udivdi3
	.type	__udivdi3, @function
__udivdi3:
	.frame	$sp,16,$31		# vars= 0, regs= 3/0, args= 0, gp= 0
	.mask	0x00070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-16
	move	$2,$0
	move	$15,$0
	sw	$16,4($sp)
	sw	$18,12($sp)
	sw	$17,8($sp)
	li	$8,63			# 0x3f
	move	$9,$0
	move	$11,$0
	sll	$25,$5,1
	li	$16,1			# 0x1
	li	$24,-1			# 0xffffffffffffffff
	nor	$10,$0,$8
$L37:
	srl	$12,$9,31
	sll	$13,$11,1
	sll	$10,$25,$10
	srl	$3,$4,$8
	or	$13,$12,$13
	or	$3,$10,$3
	andi	$14,$8,0x20
	srl	$12,$5,$8
	movn	$3,$12,$14
	sll	$9,$9,1
	andi	$3,$3,0x1
	sltu	$10,$13,$7
	move	$11,$13
	bne	$10,$0,$L31
	or	$9,$3,$9

	sll	$10,$16,$8
	move	$17,$10
	subu	$12,$9,$6
	subu	$3,$13,$7
	sltu	$18,$9,$12
	movz	$17,$0,$14
	movn	$10,$0,$14
	.set	noat
	xor	$1,$7,$11
	bne	$1,$0,$L34
	.set	at
	sltu	$13,$9,$6

	bne	$13,$0,$L31
	nop

$L34:
	move	$9,$12
	subu	$11,$3,$18
	or	$2,$2,$10
	or	$15,$15,$17
$L31:
	addiu	$8,$8,-1
	.set	noat
	xor	$1,$8,$24
	bne	$1,$0,$L37
	.set	at
	nor	$10,$0,$8

	lw	$18,12($sp)
	lw	$17,8($sp)
	lw	$16,4($sp)
	move	$3,$15
	jr	$31
	addiu	$sp,$sp,16

	.set	macro
	.set	reorder
	.end	__udivdi3
	.size	__udivdi3, .-__udivdi3
	.align	2
	.globl	__umoddi3
	.set	nomips16
	.set	nomicromips
	.ent	__umoddi3
	.type	__umoddi3, @function
__umoddi3:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$8,63			# 0x3f
	move	$2,$0
	move	$10,$0
	sll	$14,$5,1
	li	$13,-1			# 0xffffffffffffffff
$L41:
	nor	$11,$0,$8
$L45:
	srl	$12,$2,31
	sll	$9,$10,1
	srl	$3,$4,$8
	sll	$10,$14,$11
	or	$9,$12,$9
	srl	$11,$5,$8
	andi	$12,$8,0x20
	or	$3,$10,$3
	movn	$3,$11,$12
	sll	$2,$2,1
	andi	$3,$3,0x1
	sltu	$11,$9,$7
	move	$10,$9
	addiu	$8,$8,-1
	bne	$11,$0,$L39
	or	$2,$3,$2

	subu	$3,$2,$6
	sltu	$11,$2,$3
	subu	$9,$9,$7
	.set	noat
	xor	$1,$7,$10
	bne	$1,$0,$L42
	.set	at
	sltu	$12,$2,$6

	beq	$12,$0,$L42
	nop

$L39:
	.set	noat
	xor	$1,$8,$13
	bne	$1,$0,$L45
	.set	at
	nor	$11,$0,$8

$L44:
	jr	$31
	move	$3,$10

$L42:
	move	$2,$3
	.set	noat
	xor	$1,$8,$13
	bne	$1,$0,$L41
	.set	at
	subu	$10,$9,$11

	b	$L44
	nop

	.set	macro
	.set	reorder
	.end	__umoddi3
	.size	__umoddi3, .-__umoddi3
	.align	2
	.globl	__divdi3
	.set	nomips16
	.set	nomicromips
	.ent	__divdi3
	.type	__divdi3, @function
__divdi3:
	.frame	$sp,16,$31		# vars= 0, regs= 4/0, args= 0, gp= 0
	.mask	0x000f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-16
	move	$11,$7
	move	$14,$5
	sw	$16,0($sp)
	sw	$19,12($sp)
	sw	$18,8($sp)
	sw	$17,4($sp)
	bgez	$5,$L47
	xor	$16,$5,$7

	sltu	$2,$0,$4
	subu	$14,$0,$5
	subu	$14,$14,$2
	subu	$4,$0,$4
$L47:
	bgez	$11,$L49
	move	$12,$6

	sltu	$2,$0,$6
	subu	$11,$0,$11
	subu	$11,$11,$2
	subu	$12,$0,$6
$L49:
	move	$2,$0
	move	$13,$0
	li	$5,63			# 0x3f
	move	$6,$0
	move	$8,$0
	sll	$24,$14,1
	li	$25,1			# 0x1
	li	$15,-1			# 0xffffffffffffffff
	nor	$7,$0,$5
$L59:
	srl	$9,$6,31
	sll	$10,$8,1
	sll	$7,$24,$7
	srl	$3,$4,$5
	or	$10,$9,$10
	or	$3,$7,$3
	andi	$17,$5,0x20
	srl	$9,$14,$5
	movn	$3,$9,$17
	sll	$6,$6,1
	andi	$3,$3,0x1
	sltu	$7,$10,$11
	move	$8,$10
	bne	$7,$0,$L51
	or	$6,$3,$6

	sll	$7,$25,$5
	move	$18,$7
	subu	$9,$6,$12
	subu	$3,$10,$11
	sltu	$19,$6,$9
	movz	$18,$0,$17
	movn	$7,$0,$17
	.set	noat
	xor	$1,$11,$8
	bne	$1,$0,$L56
	.set	at
	sltu	$10,$6,$12

	bne	$10,$0,$L51
	nop

$L56:
	move	$6,$9
	subu	$8,$3,$19
	or	$2,$2,$7
	or	$13,$13,$18
$L51:
	addiu	$5,$5,-1
	.set	noat
	xor	$1,$5,$15
	bne	$1,$0,$L59
	.set	at
	nor	$7,$0,$5

	bgez	$16,$L60
	lw	$19,12($sp)

	sltu	$3,$0,$2
	subu	$13,$0,$13
	subu	$13,$13,$3
	subu	$2,$0,$2
$L60:
	lw	$18,8($sp)
	lw	$17,4($sp)
	lw	$16,0($sp)
	move	$3,$13
	jr	$31
	addiu	$sp,$sp,16

	.set	macro
	.set	reorder
	.end	__divdi3
	.size	__divdi3, .-__divdi3
	.align	2
	.globl	__moddi3
	.set	nomips16
	.set	nomicromips
	.ent	__moddi3
	.type	__moddi3, @function
__moddi3:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bgez	$5,$L62
	move	$15,$5

	sltu	$2,$0,$4
	subu	$15,$0,$5
	subu	$15,$15,$2
	subu	$4,$0,$4
$L62:
	move	$10,$7
	bgez	$7,$L64
	move	$12,$6

	sltu	$2,$0,$6
	subu	$10,$0,$7
	subu	$10,$10,$2
	subu	$12,$0,$6
$L64:
	li	$6,63			# 0x3f
	move	$2,$0
	move	$8,$0
	sll	$14,$15,1
	li	$13,-1			# 0xffffffffffffffff
$L68:
	nor	$9,$0,$6
	srl	$11,$2,31
	sll	$7,$8,1
	srl	$3,$4,$6
	sll	$8,$14,$9
	or	$7,$11,$7
	srl	$9,$15,$6
	andi	$11,$6,0x20
	or	$3,$8,$3
	movn	$3,$9,$11
	sll	$2,$2,1
	andi	$3,$3,0x1
	sltu	$9,$7,$10
	move	$8,$7
	addiu	$6,$6,-1
	bne	$9,$0,$L66
	or	$2,$3,$2

	subu	$3,$2,$12
	sltu	$9,$2,$3
	subu	$7,$7,$10
	.set	noat
	xor	$1,$10,$8
	bne	$1,$0,$L71
	.set	at
	sltu	$11,$2,$12

	beq	$11,$0,$L71
	nop

$L66:
	.set	noat
	xor	$1,$6,$13
	bne	$1,$0,$L68
	.set	at
	nop

$L73:
	bgez	$5,$L61
	nop

	sltu	$3,$0,$2
	subu	$8,$0,$8
	subu	$8,$8,$3
	subu	$2,$0,$2
$L61:
	jr	$31
	move	$3,$8

$L71:
	move	$2,$3
	.set	noat
	xor	$1,$6,$13
	bne	$1,$0,$L68
	.set	at
	subu	$8,$7,$9

	b	$L73
	nop

	.set	macro
	.set	reorder
	.end	__moddi3
	.size	__moddi3, .-__moddi3
	.align	2
	.globl	__adddf3
	.set	nomips16
	.set	nomicromips
	.ent	__adddf3
	.type	__adddf3, @function
__adddf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$5,20
	andi	$2,$2,0x7ff
	beq	$2,$0,$L89
	nop

	srl	$3,$7,20
	andi	$3,$3,0x7ff
	beq	$3,$0,$L91
	move	$12,$4

	li	$8,983040			# 0xf0000
	ori	$8,$8,0xffff
	addiu	$sp,$sp,-32
	li	$11,1048576			# 0x100000
	srl	$4,$5,31
	slt	$14,$2,$3
	and	$5,$8,$5
	and	$8,$8,$7
	or	$5,$5,$11
	move	$15,$4
	sw	$31,28($sp)
	move	$10,$12
	addiu	$2,$2,-1075
	srl	$9,$7,31
	move	$13,$6
	or	$11,$8,$11
	beq	$14,$0,$L83
	addiu	$3,$3,-1075

	move	$8,$5
	move	$7,$2
	move	$5,$11
	move	$2,$3
	move	$4,$9
	move	$10,$6
	move	$13,$12
	move	$11,$8
	move	$3,$7
	move	$9,$15
$L83:
	subu	$3,$2,$3
	slt	$6,$3,11
	li	$8,10			# 0xa
	movn	$8,$3,$6
	nor	$6,$0,$8
	srl	$12,$10,1
	sll	$7,$5,$8
	srl	$12,$12,$6
	subu	$3,$3,$8
	sll	$6,$10,$8
	andi	$5,$8,0x20
	or	$7,$12,$7
	slt	$10,$3,64
	movn	$7,$6,$5
	subu	$8,$2,$8
	bne	$10,$0,$L77
	movn	$6,$0,$5

$L79:
	jal	pack.part.0
	sw	$8,16($sp)

	move	$7,$3
	move	$6,$2
$L74:
	lw	$31,28($sp)
	move	$2,$6
	move	$3,$7
	jr	$31
	addiu	$sp,$sp,32

$L91:
	move	$6,$4
	move	$7,$5
$L89:
	move	$2,$6
	jr	$31
	move	$3,$7

$L77:
	nor	$2,$0,$3
	sll	$5,$11,1
	sll	$5,$5,$2
	srl	$2,$13,$3
	andi	$10,$3,0x20
	or	$2,$5,$2
	srl	$3,$11,$3
	movn	$2,$3,$10
	.set	noat
	xor	$1,$4,$9
	beq	$1,$0,$L92
	.set	at
	movn	$3,$0,$10

	sltu	$5,$7,$3
	beq	$5,$0,$L93
	nop

$L81:
	subu	$6,$2,$6
	sltu	$2,$2,$6
	subu	$7,$3,$7
	sw	$8,16($sp)
	subu	$7,$7,$2
	jal	pack.part.0
	move	$4,$9

	lw	$31,28($sp)
	move	$7,$3
	move	$6,$2
	move	$2,$6
	move	$3,$7
	jr	$31
	addiu	$sp,$sp,32

$L93:
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L86
	.set	at
	sltu	$5,$6,$2

	bne	$5,$0,$L81
	nop

$L86:
	subu	$2,$6,$2
	sltu	$5,$6,$2
	subu	$3,$7,$3
	subu	$7,$3,$5
	move	$6,$2
	or	$2,$2,$7
	bne	$2,$0,$L79
	nop

	sll	$7,$4,31
	b	$L74
	move	$6,$0

$L92:
	addu	$2,$6,$2
	sltu	$5,$2,$6
	addu	$3,$7,$3
	move	$6,$2
	b	$L79
	addu	$7,$5,$3

	.set	macro
	.set	reorder
	.end	__adddf3
	.size	__adddf3, .-__adddf3
	.align	2
	.globl	__subdf3
	.set	nomips16
	.set	nomicromips
	.ent	__subdf3
	.type	__subdf3, @function
__subdf3:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,-2147483648			# 0xffffffff80000000
	move	$3,$6
	xor	$2,$7,$2
	move	$6,$3
	j	__adddf3
	move	$7,$2

	.set	macro
	.set	reorder
	.end	__subdf3
	.size	__subdf3, .-__subdf3
	.align	2
	.globl	__muldf3
	.set	nomips16
	.set	nomicromips
	.ent	__muldf3
	.type	__muldf3, @function
__muldf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$5,20
	xor	$8,$5,$7
	andi	$2,$2,0x7ff
	move	$3,$4
	beq	$2,$0,$L96
	srl	$4,$8,31

	srl	$8,$7,20
	andi	$8,$8,0x7ff
	beq	$8,$0,$L96
	srl	$11,$6,21

	sll	$7,$7,11
	li	$9,2147418112			# 0x7fff0000
	ori	$9,$9,0xffff
	srl	$10,$3,21
	sll	$6,$6,11
	sll	$3,$3,11
	or	$7,$11,$7
	sll	$5,$5,11
	multu	$6,$3
	or	$5,$10,$5
	and	$7,$7,$9
	li	$10,-2147483648			# 0xffffffff80000000
	or	$7,$7,$10
	mfhi	$25
	and	$5,$5,$9
	multu	$3,$7
	or	$5,$5,$10
	mflo	$14
	mfhi	$15
	multu	$6,$5
	addu	$2,$2,$8
	mflo	$12
	mfhi	$13
	multu	$5,$7
	addu	$5,$25,$14
	mflo	$10
	addu	$3,$5,$12
	addu	$9,$10,$15
	sltu	$6,$5,$25
	sltu	$3,$3,$5
	mfhi	$11
	addu	$3,$3,$6
	addu	$7,$9,$13
	sltu	$5,$9,$10
	addu	$6,$3,$7
	addu	$5,$5,$11
	sltu	$7,$7,$9
	addiu	$sp,$sp,-32
	addu	$7,$7,$5
	sltu	$3,$6,$3
	addiu	$2,$2,-2128
	sw	$2,16($sp)
	sw	$31,28($sp)
	jal	pack.part.0
	addu	$7,$3,$7

	lw	$31,28($sp)
	move	$4,$3
	move	$5,$2
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

$L96:
	sll	$4,$4,31
	move	$5,$0
	move	$2,$5
	jr	$31
	move	$3,$4

	.set	macro
	.set	reorder
	.end	__muldf3
	.size	__muldf3, .-__muldf3
	.align	2
	.globl	__divdf3
	.set	nomips16
	.set	nomicromips
	.ent	__divdf3
	.type	__divdf3, @function
__divdf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$13,$5,20
	xor	$2,$5,$7
	andi	$13,$13,0x7ff
	move	$3,$4
	beq	$13,$0,$L121
	srl	$4,$2,31

	srl	$14,$7,20
	addiu	$sp,$sp,-32
	andi	$14,$14,0x7ff
	beq	$14,$0,$L122
	sw	$31,28($sp)

	li	$9,983040			# 0xf0000
	ori	$9,$9,0xffff
	li	$8,1048576			# 0x100000
	and	$2,$9,$5
	and	$9,$9,$7
	or	$2,$2,$8
	move	$12,$6
	or	$9,$9,$8
	move	$6,$0
	li	$8,55			# 0x37
	move	$10,$0
$L114:
	srl	$11,$6,31
	sll	$7,$10,1
	or	$7,$11,$7
	sltu	$5,$2,$9
	addiu	$8,$8,-1
	sll	$6,$6,1
	bne	$5,$0,$L112
	move	$10,$7

	subu	$5,$3,$12
	sltu	$11,$3,$5
	subu	$15,$2,$9
	.set	noat
	xor	$1,$9,$2
	bne	$1,$0,$L116
	.set	at
	sltu	$24,$3,$12

	bne	$24,$0,$L112
	nop

$L116:
	move	$3,$5
	subu	$2,$15,$11
	ori	$6,$6,0x1
$L112:
	srl	$5,$3,31
	sll	$2,$2,1
	or	$2,$5,$2
	bne	$8,$0,$L114
	sll	$3,$3,1

	or	$2,$6,$7
	beq	$2,$0,$L123
	subu	$2,$13,$14

	addiu	$2,$2,-54
	jal	pack.part.0
	sw	$2,16($sp)

	lw	$31,28($sp)
	move	$4,$3
	move	$5,$2
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

$L122:
	li	$2,2000			# 0x7d0
	sw	$2,16($sp)
	li	$6,1			# 0x1
	jal	pack.part.0
	move	$7,$0

	lw	$31,28($sp)
	move	$4,$3
	move	$5,$2
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

$L121:
	sll	$4,$4,31
	move	$5,$0
	move	$2,$5
	jr	$31
	move	$3,$4

$L123:
	lw	$31,28($sp)
	sll	$4,$4,31
	move	$5,$0
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__divdf3
	.size	__divdf3, .-__divdf3
	.align	2
	.globl	__ltdf2
	.set	nomips16
	.set	nomicromips
	.ent	__ltdf2
	.type	__ltdf2, @function
__ltdf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$6,31
	srl	$9,$4,31
	sll	$3,$5,1
	sll	$8,$7,1
	or	$8,$2,$8
	or	$3,$9,$3
	or	$2,$6,$4
	sll	$2,$2,1
	or	$3,$3,$8
	or	$2,$2,$3
	move	$10,$5
	beq	$2,$0,$L136
	move	$11,$7

	srl	$3,$5,31
	srl	$2,$7,31
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L137
	.set	at
	nop

	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L139
	.set	at
	nop

	sltu	$5,$5,$7
$L142:
	beq	$5,$0,$L140
	li	$2,1			# 0x1

	xor	$3,$3,$2
$L137:
	li	$4,-1			# 0xffffffffffffffff
	li	$2,1			# 0x1
	jr	$31
	movn	$2,$4,$3

$L139:
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L142
	.set	at
	sltu	$5,$5,$7

$L136:
	jr	$31
	move	$2,$0

$L140:
	.set	noat
	xor	$1,$11,$10
	beq	$1,$0,$L141
	.set	at
	nop

$L130:
	move	$2,$0
	b	$L137
	xor	$3,$3,$2

$L141:
	sltu	$6,$4,$6
	beq	$6,$0,$L130
	nop

	b	$L137
	xor	$3,$3,$2

	.set	macro
	.set	reorder
	.end	__ltdf2
	.size	__ltdf2, .-__ltdf2
	.align	2
	.globl	__ledf2
	.set	nomips16
	.set	nomicromips
	.ent	__ledf2
	.type	__ledf2, @function
__ledf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$6,31
	srl	$9,$4,31
	sll	$3,$5,1
	sll	$8,$7,1
	or	$8,$2,$8
	or	$3,$9,$3
	or	$2,$6,$4
	sll	$2,$2,1
	or	$3,$3,$8
	or	$2,$2,$3
	move	$10,$5
	beq	$2,$0,$L155
	move	$11,$7

	srl	$3,$5,31
	srl	$2,$7,31
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L156
	.set	at
	nop

	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L158
	.set	at
	nop

	sltu	$5,$5,$7
$L161:
	beq	$5,$0,$L159
	li	$2,1			# 0x1

	xor	$3,$3,$2
$L156:
	li	$4,-1			# 0xffffffffffffffff
	li	$2,1			# 0x1
	jr	$31
	movn	$2,$4,$3

$L158:
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L161
	.set	at
	sltu	$5,$5,$7

$L155:
	jr	$31
	move	$2,$0

$L159:
	.set	noat
	xor	$1,$11,$10
	beq	$1,$0,$L160
	.set	at
	nop

$L149:
	move	$2,$0
	b	$L156
	xor	$3,$3,$2

$L160:
	sltu	$6,$4,$6
	beq	$6,$0,$L149
	nop

	b	$L156
	xor	$3,$3,$2

	.set	macro
	.set	reorder
	.end	__ledf2
	.size	__ledf2, .-__ledf2
	.align	2
	.globl	__gtdf2
	.set	nomips16
	.set	nomicromips
	.ent	__gtdf2
	.type	__gtdf2, @function
__gtdf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$6,31
	srl	$9,$4,31
	sll	$3,$5,1
	sll	$8,$7,1
	or	$8,$2,$8
	or	$3,$9,$3
	or	$2,$6,$4
	sll	$2,$2,1
	or	$3,$3,$8
	or	$2,$2,$3
	move	$10,$5
	beq	$2,$0,$L174
	move	$11,$7

	srl	$3,$5,31
	srl	$2,$7,31
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L175
	.set	at
	nop

	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L177
	.set	at
	nop

	sltu	$5,$5,$7
$L180:
	beq	$5,$0,$L178
	li	$2,1			# 0x1

	xor	$3,$3,$2
$L175:
	li	$4,-1			# 0xffffffffffffffff
	li	$2,1			# 0x1
	jr	$31
	movn	$2,$4,$3

$L177:
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L180
	.set	at
	sltu	$5,$5,$7

$L174:
	jr	$31
	move	$2,$0

$L178:
	.set	noat
	xor	$1,$11,$10
	beq	$1,$0,$L179
	.set	at
	nop

$L168:
	move	$2,$0
	b	$L175
	xor	$3,$3,$2

$L179:
	sltu	$6,$4,$6
	beq	$6,$0,$L168
	nop

	b	$L175
	xor	$3,$3,$2

	.set	macro
	.set	reorder
	.end	__gtdf2
	.size	__gtdf2, .-__gtdf2
	.align	2
	.globl	__gedf2
	.set	nomips16
	.set	nomicromips
	.ent	__gedf2
	.type	__gedf2, @function
__gedf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$6,31
	srl	$9,$4,31
	sll	$3,$5,1
	sll	$8,$7,1
	or	$8,$2,$8
	or	$3,$9,$3
	or	$2,$6,$4
	sll	$2,$2,1
	or	$3,$3,$8
	or	$2,$2,$3
	move	$10,$5
	beq	$2,$0,$L193
	move	$11,$7

	srl	$3,$5,31
	srl	$2,$7,31
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L194
	.set	at
	nop

	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L196
	.set	at
	nop

	sltu	$5,$5,$7
$L199:
	beq	$5,$0,$L197
	li	$2,1			# 0x1

	xor	$3,$3,$2
$L194:
	li	$4,-1			# 0xffffffffffffffff
	li	$2,1			# 0x1
	jr	$31
	movn	$2,$4,$3

$L196:
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L199
	.set	at
	sltu	$5,$5,$7

$L193:
	jr	$31
	move	$2,$0

$L197:
	.set	noat
	xor	$1,$11,$10
	beq	$1,$0,$L198
	.set	at
	nop

$L187:
	move	$2,$0
	b	$L194
	xor	$3,$3,$2

$L198:
	sltu	$6,$4,$6
	beq	$6,$0,$L187
	nop

	b	$L194
	xor	$3,$3,$2

	.set	macro
	.set	reorder
	.end	__gedf2
	.size	__gedf2, .-__gedf2
	.align	2
	.globl	__eqdf2
	.set	nomips16
	.set	nomicromips
	.ent	__eqdf2
	.type	__eqdf2, @function
__eqdf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$6,31
	srl	$9,$4,31
	sll	$3,$5,1
	sll	$8,$7,1
	or	$8,$2,$8
	or	$3,$9,$3
	or	$2,$6,$4
	sll	$2,$2,1
	or	$3,$3,$8
	or	$2,$2,$3
	move	$10,$5
	beq	$2,$0,$L212
	move	$11,$7

	srl	$3,$5,31
	srl	$2,$7,31
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L213
	.set	at
	nop

	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L215
	.set	at
	nop

	sltu	$5,$5,$7
$L218:
	beq	$5,$0,$L216
	li	$2,1			# 0x1

	xor	$3,$3,$2
$L213:
	li	$4,-1			# 0xffffffffffffffff
	li	$2,1			# 0x1
	jr	$31
	movn	$2,$4,$3

$L215:
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L218
	.set	at
	sltu	$5,$5,$7

$L212:
	jr	$31
	move	$2,$0

$L216:
	.set	noat
	xor	$1,$11,$10
	beq	$1,$0,$L217
	.set	at
	nop

$L206:
	move	$2,$0
	b	$L213
	xor	$3,$3,$2

$L217:
	sltu	$6,$4,$6
	beq	$6,$0,$L206
	nop

	b	$L213
	xor	$3,$3,$2

	.set	macro
	.set	reorder
	.end	__eqdf2
	.size	__eqdf2, .-__eqdf2
	.align	2
	.globl	__nedf2
	.set	nomips16
	.set	nomicromips
	.ent	__nedf2
	.type	__nedf2, @function
__nedf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$6,31
	srl	$9,$4,31
	sll	$3,$5,1
	sll	$8,$7,1
	or	$8,$2,$8
	or	$3,$9,$3
	or	$2,$6,$4
	sll	$2,$2,1
	or	$3,$3,$8
	or	$2,$2,$3
	move	$10,$5
	beq	$2,$0,$L231
	move	$11,$7

	srl	$3,$5,31
	srl	$2,$7,31
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L232
	.set	at
	nop

	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L234
	.set	at
	nop

	sltu	$5,$5,$7
$L237:
	beq	$5,$0,$L235
	li	$2,1			# 0x1

	xor	$3,$3,$2
$L232:
	li	$4,-1			# 0xffffffffffffffff
	li	$2,1			# 0x1
	jr	$31
	movn	$2,$4,$3

$L234:
	.set	noat
	xor	$1,$5,$7
	bne	$1,$0,$L237
	.set	at
	sltu	$5,$5,$7

$L231:
	jr	$31
	move	$2,$0

$L235:
	.set	noat
	xor	$1,$11,$10
	beq	$1,$0,$L236
	.set	at
	nop

$L225:
	move	$2,$0
	b	$L232
	xor	$3,$3,$2

$L236:
	sltu	$6,$4,$6
	beq	$6,$0,$L225
	nop

	b	$L232
	xor	$3,$3,$2

	.set	macro
	.set	reorder
	.end	__nedf2
	.size	__nedf2, .-__nedf2
	.align	2
	.globl	__floatsidf
	.set	nomips16
	.set	nomicromips
	.ent	__floatsidf
	.type	__floatsidf, @function
__floatsidf:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$4,$L246
	sra	$7,$4,31

	bne	$4,$0,$L240
	move	$6,$4

	move	$5,$0
	move	$4,$0
	move	$2,$5
	jr	$31
	move	$3,$4

$L246:
	sltu	$2,$0,$4
	subu	$7,$0,$7
	subu	$6,$0,$4
	subu	$7,$7,$2
$L240:
	addiu	$sp,$sp,-32
	sw	$0,16($sp)
	sw	$31,28($sp)
	jal	pack.part.0
	srl	$4,$4,31

	lw	$31,28($sp)
	move	$4,$3
	move	$5,$2
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__floatsidf
	.size	__floatsidf, .-__floatsidf
	.align	2
	.globl	__floatunsidf
	.set	nomips16
	.set	nomicromips
	.ent	__floatunsidf
	.type	__floatunsidf, @function
__floatunsidf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L253
	move	$2,$0

	move	$5,$0
$L250:
	sll	$2,$2,1
	srl	$3,$4,31
	srl	$6,$2,20
	move	$7,$5
	or	$2,$3,$2
	sll	$4,$4,1
	beq	$6,$0,$L250
	addiu	$5,$5,-1

	addiu	$7,$7,1074
	blez	$7,$L253
	sll	$7,$7,20

	li	$3,983040			# 0xf0000
	ori	$3,$3,0xffff
	and	$2,$2,$3
	or	$7,$7,$2
	move	$3,$7
	jr	$31
	move	$2,$4

$L253:
	move	$2,$0
	jr	$31
	move	$3,$0

	.set	macro
	.set	reorder
	.end	__floatunsidf
	.size	__floatunsidf, .-__floatunsidf
	.align	2
	.globl	__floatdidf
	.set	nomips16
	.set	nomicromips
	.ent	__floatdidf
	.type	__floatdidf, @function
__floatdidf:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$5,$L266
	move	$6,$4

	or	$4,$4,$5
	bne	$4,$0,$L259
	move	$7,$5

	move	$5,$0
	move	$4,$0
	move	$2,$5
	jr	$31
	move	$3,$4

$L266:
	sltu	$2,$0,$4
	subu	$7,$0,$5
	subu	$7,$7,$2
	subu	$6,$0,$4
$L259:
	addiu	$sp,$sp,-32
	sw	$0,16($sp)
	sw	$31,28($sp)
	jal	pack.part.0
	srl	$4,$5,31

	lw	$31,28($sp)
	move	$4,$3
	move	$5,$2
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__floatdidf
	.size	__floatdidf, .-__floatdidf
	.align	2
	.globl	__floatundidf
	.set	nomips16
	.set	nomicromips
	.ent	__floatundidf
	.type	__floatundidf, @function
__floatundidf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	or	$2,$4,$5
	beq	$2,$0,$L292
	move	$2,$0

	srl	$2,$5,21
	beq	$2,$0,$L270
	move	$3,$0

$L272:
	sll	$7,$5,31
	srl	$4,$4,1
	srl	$2,$5,22
	move	$6,$3
	or	$4,$7,$4
	srl	$5,$5,1
	bne	$2,$0,$L272
	addiu	$3,$3,1

	addiu	$6,$6,1076
	slt	$2,$6,2047
	beq	$2,$0,$L291
	nop

$L290:
	sll	$6,$6,20
$L277:
	li	$2,983040			# 0xf0000
	ori	$2,$2,0xffff
	and	$5,$5,$2
	or	$5,$5,$6
	move	$2,$4
	jr	$31
	move	$3,$5

$L291:
	lui	$2,%hi($LC0)
	lw	$3,%lo($LC0+4)($2)
	jr	$31
	lw	$2,%lo($LC0)($2)

$L270:
	srl	$2,$5,20
	bne	$2,$0,$L277
	li	$6,1127219200			# 0x43300000

$L274:
	sll	$5,$5,1
	srl	$2,$4,31
	srl	$7,$5,20
	move	$6,$3
	or	$5,$2,$5
	sll	$4,$4,1
	beq	$7,$0,$L274
	addiu	$3,$3,-1

	addiu	$6,$6,1074
	bgtz	$6,$L290
	nop

	move	$2,$0
$L292:
	jr	$31
	move	$3,$0

	.set	macro
	.set	reorder
	.end	__floatundidf
	.size	__floatundidf, .-__floatundidf
	.align	2
	.globl	__fixunsdfdi
	.set	nomips16
	.set	nomicromips
	.ent	__fixunsdfdi
	.type	__fixunsdfdi, @function
__fixunsdfdi:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$5,20
	andi	$2,$2,0x7ff
	beq	$2,$0,$L299
	nop

	bltz	$5,$L299
	addiu	$6,$2,-1075

	li	$3,983040			# 0xf0000
	ori	$3,$3,0xffff
	and	$5,$3,$5
	li	$3,1048576			# 0x100000
	bgez	$6,$L300
	or	$5,$5,$3

	slt	$6,$6,-63
	bne	$6,$0,$L299
	sll	$6,$5,1

	li	$3,1075			# 0x433
	subu	$3,$3,$2
	nor	$2,$0,$3
	sll	$6,$6,$2
	srl	$2,$4,$3
	or	$2,$6,$2
	andi	$4,$3,0x20
	srl	$3,$5,$3
	movn	$2,$3,$4
	jr	$31
	movn	$3,$0,$4

$L299:
	move	$2,$0
	jr	$31
	move	$3,$0

$L300:
	slt	$2,$6,12
	beq	$2,$0,$L298
	srl	$7,$4,1

	nor	$2,$0,$6
	srl	$7,$7,$2
	sll	$3,$5,$6
	sll	$2,$4,$6
	andi	$5,$6,0x20
	or	$3,$7,$3
	movn	$3,$2,$5
	jr	$31
	movn	$2,$0,$5

$L298:
	li	$2,-1			# 0xffffffffffffffff
	jr	$31
	li	$3,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	__fixunsdfdi
	.size	__fixunsdfdi, .-__fixunsdfdi
	.align	2
	.globl	__fixdfdi
	.set	nomips16
	.set	nomicromips
	.ent	__fixdfdi
	.type	__fixdfdi, @function
__fixdfdi:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$5,20
	andi	$2,$2,0x7ff
	beq	$2,$0,$L305
	li	$7,1048576			# 0x100000

	li	$3,983040			# 0xf0000
	ori	$3,$3,0xffff
	and	$3,$3,$5
	addiu	$6,$2,-1075
	bltz	$6,$L303
	or	$3,$3,$7

	slt	$2,$6,11
	bne	$2,$0,$L311
	nor	$2,$0,$6

	li	$3,2147418112			# 0x7fff0000
	li	$2,-1			# 0xffffffffffffffff
	ori	$3,$3,0xffff
$L304:
	bgez	$5,$L313
	nop

$L312:
	sltu	$4,$0,$2
	subu	$3,$0,$3
	subu	$3,$3,$4
	jr	$31
	subu	$2,$0,$2

$L303:
	slt	$6,$6,-63
	bne	$6,$0,$L307
	nop

	li	$6,1075			# 0x433
	subu	$6,$6,$2
	sll	$7,$3,1
	nor	$2,$0,$6
	sll	$7,$7,$2
	srl	$2,$4,$6
	srl	$3,$3,$6
	andi	$4,$6,0x20
	or	$2,$7,$2
	movn	$2,$3,$4
	bltz	$5,$L312
	movn	$3,$0,$4

$L313:
	jr	$31
	nop

$L305:
	move	$2,$0
	jr	$31
	move	$3,$0

$L311:
	srl	$7,$4,1
	srl	$7,$7,$2
	sll	$3,$3,$6
	andi	$8,$6,0x20
	sll	$2,$4,$6
	or	$3,$7,$3
	movn	$3,$2,$8
	b	$L304
	movn	$2,$0,$8

$L307:
	move	$2,$0
	b	$L304
	move	$3,$0

	.set	macro
	.set	reorder
	.end	__fixdfdi
	.size	__fixdfdi, .-__fixdfdi
	.align	2
	.globl	__fixdfsi
	.set	nomips16
	.set	nomicromips
	.ent	__fixdfsi
	.type	__fixdfsi, @function
__fixdfsi:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$5,20
	andi	$2,$2,0x7ff
	beq	$2,$0,$L325
	li	$3,983040			# 0xf0000

	ori	$3,$3,0xffff
	and	$3,$3,$5
	li	$7,1048576			# 0x100000
	addiu	$6,$2,-1075
	bltz	$6,$L316
	or	$3,$3,$7

	slt	$2,$6,11
	bne	$2,$0,$L324
	sll	$2,$4,$6

	li	$2,-1			# 0xffffffffffffffff
$L317:
	bgez	$5,$L325
	nop

	subu	$2,$0,$2
$L325:
	jr	$31
	nop

$L316:
	slt	$6,$6,-63
	bne	$6,$0,$L320
	nop

	li	$6,1075			# 0x433
	subu	$6,$6,$2
	sll	$7,$3,1
	nor	$2,$0,$6
	sll	$7,$7,$2
	srl	$2,$4,$6
	or	$2,$7,$2
	andi	$4,$6,0x20
	srl	$3,$3,$6
	b	$L317
	movn	$2,$3,$4

$L324:
	andi	$3,$6,0x20
	b	$L317
	movn	$2,$0,$3

$L320:
	b	$L317
	move	$2,$0

	.set	macro
	.set	reorder
	.end	__fixdfsi
	.size	__fixdfsi, .-__fixdfsi
	.align	2
	.globl	__fixunsdfsi
	.set	nomips16
	.set	nomicromips
	.ent	__fixunsdfsi
	.type	__fixunsdfsi, @function
__fixunsdfsi:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$5,20
	andi	$2,$2,0x7ff
	beq	$2,$0,$L332
	nop

	bltz	$5,$L332
	li	$3,983040			# 0xf0000

	ori	$3,$3,0xffff
	and	$3,$3,$5
	li	$6,1048576			# 0x100000
	addiu	$5,$2,-1075
	bgez	$5,$L333
	or	$3,$3,$6

	slt	$5,$5,-63
	bne	$5,$0,$L332
	li	$5,1075			# 0x433

	subu	$5,$5,$2
	nor	$2,$0,$5
	sll	$6,$3,1
	sll	$6,$6,$2
	srl	$2,$4,$5
	or	$2,$6,$2
	andi	$4,$5,0x20
	srl	$3,$3,$5
	jr	$31
	movn	$2,$3,$4

$L332:
	jr	$31
	move	$2,$0

$L333:
	slt	$2,$5,12
	beq	$2,$0,$L331
	andi	$3,$5,0x20

	sll	$2,$4,$5
	jr	$31
	movn	$2,$0,$3

$L331:
	jr	$31
	li	$2,-1			# 0xffffffffffffffff

	.set	macro
	.set	reorder
	.end	__fixunsdfsi
	.size	__fixunsdfsi, .-__fixunsdfsi
	.align	2
	.globl	__extendsfdf2
	.set	nomips16
	.set	nomicromips
	.ent	__extendsfdf2
	.type	__extendsfdf2, @function
__extendsfdf2:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	andi	$2,$2,0xff
	move	$3,$4
	beq	$2,$0,$L340
	srl	$4,$4,31

	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	addiu	$sp,$sp,-32
	and	$3,$6,$3
	addiu	$2,$2,-150
	li	$6,8388608			# 0x800000
	or	$6,$3,$6
	sw	$2,16($sp)
	sw	$31,28($sp)
	jal	pack.part.0
	move	$7,$0

	lw	$31,28($sp)
	move	$4,$3
	move	$5,$2
	move	$2,$5
	move	$3,$4
	jr	$31
	addiu	$sp,$sp,32

$L340:
	sll	$4,$4,31
	move	$5,$0
	move	$2,$5
	jr	$31
	move	$3,$4

	.set	macro
	.set	reorder
	.end	__extendsfdf2
	.size	__extendsfdf2, .-__extendsfdf2
	.align	2
	.globl	__truncdfsf2
	.set	nomips16
	.set	nomicromips
	.ent	__truncdfsf2
	.type	__truncdfsf2, @function
__truncdfsf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$3,$5,20
	srl	$2,$5,31
	andi	$3,$3,0x7ff
	beq	$3,$0,$L347
	sll	$2,$2,31

	addiu	$3,$3,-896
	slt	$6,$3,255
	beq	$6,$0,$L346
	nop

	blez	$3,$L347
	sll	$5,$5,3

	srl	$4,$4,29
	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	or	$4,$5,$4
	and	$4,$4,$6
	li	$5,8388608			# 0x800000
	or	$4,$4,$5
	and	$4,$4,$6
	or	$2,$4,$2
	sll	$3,$3,23
	or	$2,$2,$3
$L347:
	jr	$31
	nop

$L346:
	li	$3,2139095040			# 0x7f800000
	jr	$31
	or	$2,$2,$3

	.set	macro
	.set	reorder
	.end	__truncdfsf2
	.size	__truncdfsf2, .-__truncdfsf2
	.align	2
	.globl	__addsf3
	.set	nomips16
	.set	nomicromips
	.ent	__addsf3
	.type	__addsf3, @function
__addsf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	addiu	$sp,$sp,-32
	andi	$2,$2,0xff
	move	$3,$4
	move	$9,$5
	sw	$31,28($sp)
	beq	$2,$0,$L354
	srl	$4,$4,31

	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	and	$3,$6,$3
	addiu	$2,$2,-150
	li	$6,8388608			# 0x800000
	sw	$2,16($sp)
	or	$6,$3,$6
	jal	pack.part.0
	move	$7,$0

	move	$8,$3
	srl	$3,$9,23
	andi	$3,$3,0xff
	move	$10,$2
	beq	$3,$0,$L355
	srl	$4,$9,31

$L351:
	li	$5,8323072			# 0x7f0000
	ori	$5,$5,0xffff
	and	$5,$5,$9
	addiu	$3,$3,-150
	li	$6,8388608			# 0x800000
	or	$6,$5,$6
	sw	$3,16($sp)
	jal	pack.part.0
	move	$7,$0

	move	$6,$2
	move	$4,$10
	move	$5,$8
	jal	__adddf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

$L354:
	srl	$3,$9,23
	andi	$3,$3,0xff
	sll	$8,$4,31
	move	$10,$0
	bne	$3,$0,$L351
	srl	$4,$9,31

$L355:
	sll	$3,$4,31
	move	$2,$0
	move	$4,$10
	move	$5,$8
	move	$6,$2
	jal	__adddf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__addsf3
	.size	__addsf3, .-__addsf3
	.align	2
	.globl	__subsf3
	.set	nomips16
	.set	nomicromips
	.ent	__subsf3
	.type	__subsf3, @function
__subsf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	addiu	$sp,$sp,-32
	andi	$2,$2,0xff
	move	$3,$4
	move	$9,$5
	sw	$31,28($sp)
	beq	$2,$0,$L362
	srl	$4,$4,31

	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	and	$3,$6,$3
	addiu	$2,$2,-150
	li	$6,8388608			# 0x800000
	sw	$2,16($sp)
	or	$6,$3,$6
	jal	pack.part.0
	move	$7,$0

	move	$8,$3
	srl	$3,$9,23
	andi	$3,$3,0xff
	move	$12,$2
	beq	$3,$0,$L363
	srl	$4,$9,31

$L359:
	li	$5,8323072			# 0x7f0000
	ori	$5,$5,0xffff
	and	$5,$5,$9
	addiu	$3,$3,-150
	li	$6,8388608			# 0x800000
	or	$6,$5,$6
	sw	$3,16($sp)
	jal	pack.part.0
	move	$7,$0

	move	$5,$2
	li	$2,-2147483648			# 0xffffffff80000000
	xor	$3,$3,$2
	move	$6,$5
	move	$4,$12
	move	$5,$8
	jal	__adddf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

$L362:
	srl	$3,$9,23
	andi	$3,$3,0xff
	sll	$8,$4,31
	move	$12,$0
	bne	$3,$0,$L359
	srl	$4,$9,31

$L363:
	sll	$3,$4,31
	li	$2,-2147483648			# 0xffffffff80000000
	move	$5,$0
	xor	$3,$3,$2
	move	$6,$5
	move	$4,$12
	move	$5,$8
	jal	__adddf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__subsf3
	.size	__subsf3, .-__subsf3
	.align	2
	.globl	__mulsf3
	.set	nomips16
	.set	nomicromips
	.ent	__mulsf3
	.type	__mulsf3, @function
__mulsf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	addiu	$sp,$sp,-32
	andi	$2,$2,0xff
	move	$3,$4
	move	$9,$5
	sw	$31,28($sp)
	beq	$2,$0,$L370
	srl	$4,$4,31

	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	and	$3,$6,$3
	addiu	$2,$2,-150
	li	$6,8388608			# 0x800000
	sw	$2,16($sp)
	or	$6,$3,$6
	jal	pack.part.0
	move	$7,$0

	move	$8,$3
	srl	$3,$9,23
	andi	$3,$3,0xff
	move	$10,$2
	beq	$3,$0,$L371
	srl	$4,$9,31

$L367:
	li	$5,8323072			# 0x7f0000
	ori	$5,$5,0xffff
	and	$5,$5,$9
	addiu	$3,$3,-150
	li	$6,8388608			# 0x800000
	or	$6,$5,$6
	sw	$3,16($sp)
	jal	pack.part.0
	move	$7,$0

	move	$6,$2
	move	$4,$10
	move	$5,$8
	jal	__muldf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

$L370:
	srl	$3,$9,23
	andi	$3,$3,0xff
	sll	$8,$4,31
	move	$10,$0
	bne	$3,$0,$L367
	srl	$4,$9,31

$L371:
	sll	$3,$4,31
	move	$2,$0
	move	$4,$10
	move	$5,$8
	move	$6,$2
	jal	__muldf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__mulsf3
	.size	__mulsf3, .-__mulsf3
	.align	2
	.globl	__divsf3
	.set	nomips16
	.set	nomicromips
	.ent	__divsf3
	.type	__divsf3, @function
__divsf3:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	addiu	$sp,$sp,-32
	andi	$2,$2,0xff
	move	$3,$4
	move	$9,$5
	sw	$31,28($sp)
	beq	$2,$0,$L378
	srl	$4,$4,31

	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	and	$3,$6,$3
	addiu	$2,$2,-150
	li	$6,8388608			# 0x800000
	sw	$2,16($sp)
	or	$6,$3,$6
	jal	pack.part.0
	move	$7,$0

	move	$8,$3
	srl	$3,$9,23
	andi	$3,$3,0xff
	move	$10,$2
	beq	$3,$0,$L379
	srl	$4,$9,31

$L375:
	li	$5,8323072			# 0x7f0000
	ori	$5,$5,0xffff
	and	$5,$5,$9
	addiu	$3,$3,-150
	li	$6,8388608			# 0x800000
	or	$6,$5,$6
	sw	$3,16($sp)
	jal	pack.part.0
	move	$7,$0

	move	$6,$2
	move	$4,$10
	move	$5,$8
	jal	__divdf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

$L378:
	srl	$3,$9,23
	andi	$3,$3,0xff
	sll	$8,$4,31
	move	$10,$0
	bne	$3,$0,$L375
	srl	$4,$9,31

$L379:
	sll	$3,$4,31
	move	$2,$0
	move	$4,$10
	move	$5,$8
	move	$6,$2
	jal	__divdf3
	move	$7,$3

	lw	$31,28($sp)
	move	$4,$2
	move	$5,$3
	j	__truncdfsf2
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__divsf3
	.size	__divsf3, .-__divsf3
	.align	2
	.globl	__floatsisf
	.set	nomips16
	.set	nomicromips
	.ent	__floatsisf
	.type	__floatsisf, @function
__floatsisf:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$4,$L393
	sra	$7,$4,31

	bne	$4,$0,$L382
	move	$6,$4

	jr	$31
	move	$2,$0

$L393:
	sltu	$2,$0,$4
	subu	$7,$0,$7
	subu	$6,$0,$4
	subu	$7,$7,$2
$L382:
	addiu	$sp,$sp,-32
	sw	$0,16($sp)
	sw	$31,28($sp)
	jal	pack.part.0
	srl	$4,$4,31

	srl	$4,$3,20
	move	$6,$3
	andi	$4,$4,0x7ff
	srl	$3,$3,31
	beq	$4,$0,$L392
	sll	$5,$3,31

	addiu	$4,$4,-896
	slt	$3,$4,255
	beq	$3,$0,$L394
	lw	$31,28($sp)

	blez	$4,$L395
	sll	$6,$6,3

	srl	$3,$2,29
	li	$2,8323072			# 0x7f0000
	ori	$2,$2,0xffff
	or	$3,$6,$3
	and	$3,$3,$2
	li	$6,8388608			# 0x800000
	or	$3,$3,$6
	lw	$31,28($sp)
	and	$3,$3,$2
	or	$3,$3,$5
	sll	$4,$4,23
	or	$2,$3,$4
	jr	$31
	addiu	$sp,$sp,32

$L394:
	li	$2,2139095040			# 0x7f800000
	or	$2,$5,$2
	jr	$31
	addiu	$sp,$sp,32

$L392:
	lw	$31,28($sp)
$L395:
	move	$2,$5
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	__floatsisf
	.size	__floatsisf, .-__floatsisf
	.align	2
	.globl	__floatunsisf
	.set	nomips16
	.set	nomicromips
	.ent	__floatunsisf
	.type	__floatunsisf, @function
__floatunsisf:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L402
	move	$2,$0

	move	$5,$0
$L399:
	sll	$2,$2,1
	srl	$3,$4,31
	srl	$6,$2,20
	move	$7,$5
	or	$2,$3,$2
	sll	$4,$4,1
	beq	$6,$0,$L399
	addiu	$5,$5,-1

	addiu	$7,$7,1074
	blez	$7,$L402
	li	$3,983040			# 0xf0000

	ori	$3,$3,0xffff
	sll	$7,$7,20
	and	$2,$2,$3
	or	$7,$7,$2
	j	__truncdfsf2
	move	$5,$7

$L402:
	move	$4,$0
	j	__truncdfsf2
	move	$5,$0

	.set	macro
	.set	reorder
	.end	__floatunsisf
	.size	__floatunsisf, .-__floatunsisf
	.align	2
	.globl	__fixsfsi
	.set	nomips16
	.set	nomicromips
	.ent	__fixsfsi
	.type	__fixsfsi, @function
__fixsfsi:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	andi	$2,$2,0xff
	beq	$2,$0,$L410
	li	$6,8388608			# 0x800000

	li	$3,8323072			# 0x7f0000
	ori	$3,$3,0xffff
	addiu	$sp,$sp,-32
	and	$3,$3,$4
	addiu	$2,$2,-150
	or	$6,$3,$6
	srl	$4,$4,31
	sw	$2,16($sp)
	sw	$31,28($sp)
	jal	pack.part.0
	move	$7,$0

	move	$4,$3
	srl	$3,$3,20
	move	$5,$2
	andi	$2,$3,0x7ff
	li	$3,983040			# 0xf0000
	ori	$3,$3,0xffff
	srl	$6,$4,31
	beq	$2,$0,$L405
	and	$3,$3,$4

	li	$7,1048576			# 0x100000
	addiu	$4,$2,-1075
	bltz	$4,$L407
	or	$3,$3,$7

	slt	$2,$4,11
	bne	$2,$0,$L420
	sll	$2,$5,$4

	li	$2,-1			# 0xffffffffffffffff
$L408:
	beq	$6,$0,$L421
	lw	$31,28($sp)

	subu	$2,$0,$2
$L405:
	lw	$31,28($sp)
$L421:
	jr	$31
	addiu	$sp,$sp,32

$L407:
	slt	$4,$4,-63
	bne	$4,$0,$L412
	nop

	li	$4,1075			# 0x433
	subu	$4,$4,$2
	sll	$7,$3,1
	nor	$2,$0,$4
	sll	$7,$7,$2
	srl	$2,$5,$4
	or	$2,$7,$2
	andi	$5,$4,0x20
	srl	$3,$3,$4
	b	$L408
	movn	$2,$3,$5

$L410:
	jr	$31
	move	$2,$0

$L420:
	andi	$3,$4,0x20
	b	$L408
	movn	$2,$0,$3

$L412:
	b	$L408
	move	$2,$0

	.set	macro
	.set	reorder
	.end	__fixsfsi
	.size	__fixsfsi, .-__fixsfsi
	.align	2
	.globl	__ltsf2
	.set	nomips16
	.set	nomicromips
	.ent	__ltsf2
	.type	__ltsf2, @function
__ltsf2:
	.frame	$sp,32,$31		# vars= 0, regs= 1/0, args= 24, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	srl	$2,$4,23
	addiu	$sp,$sp,-32
	andi	$2,$2,0xff
	move	$3,$4
	move	$9,$5
	sw	$31,28($sp)
	beq	$2,$0,$L442
	srl	$4,$4,31

	li	$6,8323072			# 0x7f0000
	ori	$6,$6,0xffff
	and	$3,$6,$3
	addiu	$2,$2,-150
	li	$6,8388608			# 0x800000
	sw	$2,16($sp)
	or	$6,$3,$6
	jal	pack.part.0
	move	$7,$0

	move	$11,$2
	sll	$12,$3,1
	srl	$2,$2,31
	move	$8,$3
	or	$12,$2,$12
	sll	$10,$11,1
$L424:
	srl	$3,$9,23
	andi	$3,$3,0xff
	beq	$3,$0,$L443
	srl	$4,$9,31

	li	$5,8323072			# 0x7f0000
	ori	$5,$5,0xffff
	and	$5,$5,$9
	addiu	$3,$3,-150
	li	$6,8388608			# 0x800000
	or	$6,$5,$6
	sw	$3,16($sp)
	jal	pack.part.0
	move	$7,$0

	srl	$5,$2,31
	move	$4,$3
	sll	$3,$3,1
	or	$3,$5,$3
	sll	$5,$2,1
	or	$10,$10,$5
	or	$12,$12,$3
$L426:
	or	$10,$10,$12
	beq	$10,$0,$L438
	srl	$5,$4,31

	srl	$3,$8,31
	.set	noat
	xor	$1,$3,$5
	beq	$1,$0,$L429
	.set	at
	nop

$L440:
	lw	$31,28($sp)
	li	$2,1			# 0x1
	li	$4,-1			# 0xffffffffffffffff
	movn	$2,$4,$3
	jr	$31
	addiu	$sp,$sp,32

$L429:
	.set	noat
	xor	$1,$11,$2
	beq	$1,$0,$L444
	.set	at
	sltu	$5,$8,$4

$L447:
	beq	$5,$0,$L445
	li	$6,1			# 0x1

	b	$L440
	xor	$3,$3,$6

$L444:
	.set	noat
	xor	$1,$8,$4
	bne	$1,$0,$L447
	.set	at
	nop

$L438:
	lw	$31,28($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,32

$L443:
	sll	$4,$4,31
	b	$L426
	move	$2,$0

$L442:
	sll	$8,$4,31
	move	$11,$0
	move	$10,$0
	b	$L424
	move	$12,$0

$L445:
	.set	noat
	xor	$1,$4,$8
	beq	$1,$0,$L446
	.set	at
	sltu	$2,$11,$2

$L432:
	move	$6,$0
	b	$L440
	xor	$3,$3,$6

$L446:
	beq	$2,$0,$L432
	nop

	b	$L440
	xor	$3,$3,$6

	.set	macro
	.set	reorder
	.end	__ltsf2
	.size	__ltsf2, .-__ltsf2
	.align	2
	.globl	__gtsf2
	.set	nomips16
	.set	nomicromips
	.ent	__gtsf2
	.type	__gtsf2, @function
__gtsf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	__ltsf2
	nop

	.set	macro
	.set	reorder
	.end	__gtsf2
	.size	__gtsf2, .-__gtsf2
	.align	2
	.globl	__lesf2
	.set	nomips16
	.set	nomicromips
	.ent	__lesf2
	.type	__lesf2, @function
__lesf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	__ltsf2
	nop

	.set	macro
	.set	reorder
	.end	__lesf2
	.size	__lesf2, .-__lesf2
	.align	2
	.globl	__gesf2
	.set	nomips16
	.set	nomicromips
	.ent	__gesf2
	.type	__gesf2, @function
__gesf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	__ltsf2
	nop

	.set	macro
	.set	reorder
	.end	__gesf2
	.size	__gesf2, .-__gesf2
	.align	2
	.globl	__eqsf2
	.set	nomips16
	.set	nomicromips
	.ent	__eqsf2
	.type	__eqsf2, @function
__eqsf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	__ltsf2
	nop

	.set	macro
	.set	reorder
	.end	__eqsf2
	.size	__eqsf2, .-__eqsf2
	.align	2
	.globl	__nesf2
	.set	nomips16
	.set	nomicromips
	.ent	__nesf2
	.type	__nesf2, @function
__nesf2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	__ltsf2
	nop

	.set	macro
	.set	reorder
	.end	__nesf2
	.size	__nesf2, .-__nesf2
	.section	.rodata.cst8,"aM",@progbits,8
	.align	3
$LC0:
	.word	0
	.word	2146435072
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
