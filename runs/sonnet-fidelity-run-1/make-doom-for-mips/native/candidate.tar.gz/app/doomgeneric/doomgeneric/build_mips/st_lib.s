	.file	1 "st_lib.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"STTMINUS\000"
	.text
	.align	2
	.globl	STlib_init
	.set	nomips16
	.set	nomicromips
	.ent	STlib_init
	.type	STlib_init, @function
STlib_init:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-24
	li	$5,1			# 0x1
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC0)

	lw	$31,20($sp)
	lui	$3,%hi(sttminus)
	sw	$2,%lo(sttminus)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	STlib_init
	.size	STlib_init, .-STlib_init
	.align	2
	.globl	STlib_initNum
	.set	nomips16
	.set	nomicromips
	.ent	STlib_initNum
	.type	STlib_initNum, @function
STlib_initNum:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,24($sp)
	sw	$5,0($4)
	sw	$2,8($4)
	lw	$2,16($sp)
	sw	$6,4($4)
	sw	$2,16($4)
	lw	$2,20($sp)
	sw	$0,12($4)
	sw	$2,20($4)
	jr	$31
	sw	$7,24($4)

	.set	macro
	.set	reorder
	.end	STlib_initNum
	.size	STlib_initNum, .-STlib_initNum
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"drawNum: n->y - ST_Y < 0\000"
	.text
	.align	2
	.globl	STlib_drawNum
	.set	nomips16
	.set	nomicromips
	.ent	STlib_drawNum
	.type	STlib_drawNum, @function
STlib_drawNum:
	.frame	$sp,80,$31		# vars= 8, regs= 9/0, args= 32, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,24($4)
	addiu	$sp,$sp,-80
	lw	$2,0($2)
	lw	$3,16($4)
	sw	$22,68($sp)
	sw	$21,64($sp)
	sw	$19,56($sp)
	sw	$18,52($sp)
	sw	$17,48($sp)
	sw	$31,76($sp)
	sw	$23,72($sp)
	sw	$20,60($sp)
	sw	$16,44($sp)
	lbu	$17,1($2)
	lbu	$16,3($2)
	lw	$19,0($3)
	lbu	$3,0($2)
	lbu	$2,2($2)
	sll	$17,$17,8
	sll	$16,$16,8
	or	$17,$17,$3
	or	$16,$16,$2
	sll	$17,$17,16
	sll	$16,$16,16
	lw	$21,8($4)
	lw	$18,0($4)
	move	$22,$4
	sra	$17,$17,16
	sra	$16,$16,16
	bltz	$19,$L24
	sw	$19,12($4)

	multu	$21,$17
	mflo	$7
	lw	$5,4($22)
	move	$20,$19
	slt	$2,$5,168
	bne	$2,$0,$L25
	subu	$18,$18,$7

$L9:
	lui	$2,%hi(st_backing_screen)
	lw	$6,%lo(st_backing_screen)($2)
	sw	$5,24($sp)
	sw	$18,20($sp)
	sw	$16,16($sp)
	addiu	$5,$5,-168
	jal	V_CopyRect
	move	$4,$18

	li	$2,1994			# 0x7ca
	.set	noat
	xor	$1,$20,$2
	beq	$1,$0,$L31
	.set	at
	lw	$31,76($sp)

	beq	$20,$0,$L26
	lw	$23,0($22)

	beq	$21,$0,$L13
	li	$18,-859045888			# 0xffffffffcccc0000

	b	$L17
	ori	$18,$18,0xcccd

$L14:
	beq	$21,$0,$L13
	nop

$L17:
	multu	$20,$18
	lw	$3,24($22)
	mfhi	$16
	lw	$5,4($22)
	srl	$16,$16,3
	sll	$2,$16,2
	addu	$2,$2,$16
	sll	$2,$2,1
	subu	$2,$20,$2
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$6,0($2)
	subu	$23,$23,$17
	jal	V_DrawPatch
	move	$4,$23

	move	$20,$16
	bne	$16,$0,$L14
	addiu	$21,$21,-1

$L13:
	bltz	$19,$L32
	lui	$2,%hi(sttminus)

	lw	$31,76($sp)
$L31:
	lw	$23,72($sp)
	lw	$22,68($sp)
	lw	$21,64($sp)
	lw	$20,60($sp)
	lw	$19,56($sp)
	lw	$18,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	jr	$31
	addiu	$sp,$sp,80

$L24:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$21,$2
	beq	$1,$0,$L28
	.set	at
	li	$2,3			# 0x3

	.set	noat
	xor	$1,$21,$2
	beq	$1,$0,$L29
	.set	at
	slt	$2,$19,-99

	move	$20,$19
	subu	$20,$0,$20
$L30:
	multu	$21,$17
	mflo	$7
	lw	$5,4($22)
	slt	$2,$5,168
	beq	$2,$0,$L9
	subu	$18,$18,$7

$L25:
	lui	$4,%hi($LC1)
	addiu	$4,$4,%lo($LC1)
	jal	I_Error
	sw	$7,32($sp)

	lw	$5,4($22)
	b	$L9
	lw	$7,32($sp)

$L26:
	lw	$2,24($22)
	lw	$5,4($22)
	lw	$6,0($2)
	jal	V_DrawPatch
	subu	$4,$23,$17

	bgez	$19,$L31
	lw	$31,76($sp)

	lui	$2,%hi(sttminus)
$L32:
	lw	$5,4($22)
	lw	$31,76($sp)
	lw	$22,68($sp)
	lw	$21,64($sp)
	lw	$20,60($sp)
	lw	$19,56($sp)
	lw	$18,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	addiu	$4,$23,-8
	lw	$6,%lo(sttminus)($2)
	lw	$23,72($sp)
	j	V_DrawPatch
	addiu	$sp,$sp,80

$L29:
	li	$20,-99			# 0xffffffffffffff9d
	movz	$20,$19,$2
	b	$L30
	subu	$20,$0,$20

$L28:
	slt	$2,$19,-9
	li	$20,-9			# 0xfffffffffffffff7
	movz	$20,$19,$2
	b	$L30
	subu	$20,$0,$20

	.set	macro
	.set	reorder
	.end	STlib_drawNum
	.size	STlib_drawNum, .-STlib_drawNum
	.align	2
	.globl	STlib_updateNum
	.set	nomips16
	.set	nomicromips
	.ent	STlib_updateNum
	.type	STlib_updateNum, @function
STlib_updateNum:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,20($4)
	lw	$2,0($2)
	bne	$2,$0,$L35
	nop

	jr	$31
	nop

$L35:
	j	STlib_drawNum
	nop

	.set	macro
	.set	reorder
	.end	STlib_updateNum
	.size	STlib_updateNum, .-STlib_updateNum
	.align	2
	.globl	STlib_initPercent
	.set	nomips16
	.set	nomicromips
	.ent	STlib_initPercent
	.type	STlib_initPercent, @function
STlib_initPercent:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,3			# 0x3
	sw	$2,8($4)
	lw	$2,16($sp)
	sw	$5,0($4)
	sw	$2,16($4)
	lw	$2,20($sp)
	sw	$6,4($4)
	sw	$2,20($4)
	lw	$2,24($sp)
	sw	$0,12($4)
	sw	$7,24($4)
	jr	$31
	sw	$2,32($4)

	.set	macro
	.set	reorder
	.end	STlib_initPercent
	.size	STlib_initPercent, .-STlib_initPercent
	.align	2
	.globl	STlib_updatePercent
	.set	nomips16
	.set	nomicromips
	.ent	STlib_updatePercent
	.type	STlib_updatePercent, @function
STlib_updatePercent:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,20($4)
	addiu	$sp,$sp,-32
	lw	$2,0($2)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$4
	beq	$5,$0,$L38
	move	$17,$5

	bne	$2,$0,$L49
	lw	$31,28($sp)

$L50:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L49:
	lw	$6,32($4)
	lw	$5,4($4)
	jal	V_DrawPatch
	lw	$4,0($4)

$L38:
	lw	$2,20($16)
	lw	$2,0($2)
	beq	$2,$0,$L50
	lw	$31,28($sp)

	move	$5,$17
	move	$4,$16
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	STlib_drawNum
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	STlib_updatePercent
	.size	STlib_updatePercent, .-STlib_updatePercent
	.align	2
	.globl	STlib_initMultIcon
	.set	nomips16
	.set	nomicromips
	.ent	STlib_initMultIcon
	.type	STlib_initMultIcon, @function
STlib_initMultIcon:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,-1			# 0xffffffffffffffff
	sw	$2,8($4)
	lw	$2,16($sp)
	sw	$5,0($4)
	sw	$2,12($4)
	lw	$2,20($sp)
	sw	$6,4($4)
	sw	$2,16($4)
	jr	$31
	sw	$7,20($4)

	.set	macro
	.set	reorder
	.end	STlib_initMultIcon
	.size	STlib_initMultIcon, .-STlib_initMultIcon
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"updateMultIcon: y - ST_Y < 0\000"
	.text
	.align	2
	.globl	STlib_updateMultIcon
	.set	nomips16
	.set	nomicromips
	.ent	STlib_updateMultIcon
	.type	STlib_updateMultIcon, @function
STlib_updateMultIcon:
	.frame	$sp,64,$31		# vars= 8, regs= 5/0, args= 32, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($4)
	lw	$2,0($2)
	beq	$2,$0,$L71
	nop

	lw	$2,12($4)
	lw	$3,8($4)
	lw	$2,0($2)
	addiu	$sp,$sp,-64
	sw	$16,44($sp)
	sw	$31,60($sp)
	sw	$19,56($sp)
	sw	$18,52($sp)
	sw	$17,48($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L67
	.set	at
	move	$16,$4

	li	$4,-1			# 0xffffffffffffffff
$L69:
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L70
	.set	at
	lw	$31,60($sp)

	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L55
	.set	at
	sll	$3,$3,2

	lw	$2,20($16)
	addu	$2,$2,$3
	lw	$2,0($2)
	lw	$18,4($16)
	lbu	$4,7($2)
	lbu	$5,6($2)
	lbu	$3,5($2)
	sll	$4,$4,8
	lbu	$8,4($2)
	lbu	$7,1($2)
	lbu	$17,3($2)
	or	$4,$4,$5
	lbu	$6,0($2)
	lbu	$5,2($2)
	sll	$2,$3,8
	sll	$3,$4,16
	sra	$3,$3,16
	or	$2,$2,$8
	sll	$7,$7,8
	sll	$17,$17,8
	lw	$19,0($16)
	subu	$18,$18,$3
	sll	$2,$2,16
	or	$7,$7,$6
	or	$17,$17,$5
	sra	$2,$2,16
	sll	$7,$7,16
	sll	$17,$17,16
	slt	$3,$18,168
	subu	$19,$19,$2
	sra	$7,$7,16
	bne	$3,$0,$L68
	sra	$17,$17,16

$L56:
	lui	$2,%hi(st_backing_screen)
	lw	$6,%lo(st_backing_screen)($2)
	sw	$18,24($sp)
	sw	$19,20($sp)
	sw	$17,16($sp)
	addiu	$5,$18,-168
	jal	V_CopyRect
	move	$4,$19

	lw	$2,12($16)
	lw	$2,0($2)
$L55:
	lw	$3,20($16)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$6,0($2)
	lw	$5,4($16)
	jal	V_DrawPatch
	lw	$4,0($16)

	lw	$2,12($16)
	lw	$2,0($2)
	sw	$2,8($16)
	lw	$31,60($sp)
$L70:
	lw	$19,56($sp)
	lw	$18,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	jr	$31
	addiu	$sp,$sp,64

$L71:
	jr	$31
	nop

$L67:
	beq	$5,$0,$L70
	lw	$31,60($sp)

	b	$L69
	li	$4,-1			# 0xffffffffffffffff

$L68:
	lui	$4,%hi($LC2)
	addiu	$4,$4,%lo($LC2)
	jal	I_Error
	sw	$7,32($sp)

	b	$L56
	lw	$7,32($sp)

	.set	macro
	.set	reorder
	.end	STlib_updateMultIcon
	.size	STlib_updateMultIcon, .-STlib_updateMultIcon
	.align	2
	.globl	STlib_initBinIcon
	.set	nomips16
	.set	nomicromips
	.ent	STlib_initBinIcon
	.type	STlib_initBinIcon, @function
STlib_initBinIcon:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($sp)
	sw	$5,0($4)
	sw	$2,12($4)
	lw	$2,20($sp)
	sw	$6,4($4)
	sw	$0,8($4)
	sw	$2,16($4)
	jr	$31
	sw	$7,20($4)

	.set	macro
	.set	reorder
	.end	STlib_initBinIcon
	.size	STlib_initBinIcon, .-STlib_initBinIcon
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"updateBinIcon: y - ST_Y < 0\000"
	.text
	.align	2
	.globl	STlib_updateBinIcon
	.set	nomips16
	.set	nomicromips
	.ent	STlib_updateBinIcon
	.type	STlib_updateBinIcon, @function
STlib_updateBinIcon:
	.frame	$sp,64,$31		# vars= 0, regs= 7/0, args= 32, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,16($4)
	lw	$2,0($2)
	beq	$2,$0,$L94
	nop

	lw	$3,12($4)
	lw	$2,8($4)
	lw	$6,0($3)
	addiu	$sp,$sp,-64
	sw	$16,36($sp)
	sw	$31,60($sp)
	sw	$21,56($sp)
	sw	$20,52($sp)
	sw	$19,48($sp)
	sw	$18,44($sp)
	sw	$17,40($sp)
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L89
	.set	at
	move	$16,$4

	lw	$2,20($16)
$L92:
	lw	$20,4($16)
	lbu	$3,7($2)
	lbu	$8,6($2)
	sll	$3,$3,8
	or	$3,$3,$8
	lbu	$4,3($2)
	lbu	$5,5($2)
	lbu	$7,1($2)
	lbu	$10,4($2)
	lbu	$9,0($2)
	lbu	$8,2($2)
	sll	$2,$3,16
	sra	$2,$2,16
	subu	$20,$20,$2
	sll	$3,$5,8
	sll	$2,$4,8
	sll	$7,$7,8
	or	$3,$3,$10
	or	$7,$7,$9
	or	$2,$2,$8
	sll	$19,$3,16
	sll	$17,$7,16
	sll	$18,$2,16
	slt	$4,$20,168
	lw	$21,0($16)
	sra	$19,$19,16
	sra	$17,$17,16
	bne	$4,$0,$L90
	sra	$18,$18,16

$L76:
	beq	$6,$0,$L77
	lui	$2,%hi(st_backing_screen)

	lw	$6,20($16)
	lw	$5,4($16)
	jal	V_DrawPatch
	lw	$4,0($16)

	lw	$2,12($16)
$L91:
	lw	$2,0($2)
	sw	$2,8($16)
	lw	$31,60($sp)
$L93:
	lw	$21,56($sp)
	lw	$20,52($sp)
	lw	$19,48($sp)
	lw	$18,44($sp)
	lw	$17,40($sp)
	lw	$16,36($sp)
	jr	$31
	addiu	$sp,$sp,64

$L94:
	jr	$31
	nop

$L77:
	subu	$4,$21,$19
	lw	$6,%lo(st_backing_screen)($2)
	sw	$20,24($sp)
	sw	$4,20($sp)
	sw	$18,16($sp)
	move	$7,$17
	jal	V_CopyRect
	addiu	$5,$20,-168

	b	$L91
	lw	$2,12($16)

$L89:
	beq	$5,$0,$L93
	lw	$31,60($sp)

	b	$L92
	lw	$2,20($16)

$L90:
	lui	$4,%hi($LC3)
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	lw	$2,12($16)
	b	$L76
	lw	$6,0($2)

	.set	macro
	.set	reorder
	.end	STlib_updateBinIcon
	.size	STlib_updateBinIcon, .-STlib_updateBinIcon
	.globl	sttminus
	.section	.bss,"aw",@nobits
	.align	2
	.type	sttminus, @object
	.size	sttminus, 4
sttminus:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
