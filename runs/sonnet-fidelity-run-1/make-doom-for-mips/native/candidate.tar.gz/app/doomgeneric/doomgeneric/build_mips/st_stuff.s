	.file	1 "st_stuff.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	ST_loadCallback
	.type	ST_loadCallback, @function
ST_loadCallback:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,20($sp)
	jal	W_CacheLumpName
	li	$5,1			# 0x1

	lw	$31,20($sp)
	sw	$2,0($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_loadCallback
	.size	ST_loadCallback, .-ST_loadCallback
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"STTNUM%d\000"
	.align	2
$LC1:
	.ascii	"STYSNUM%d\000"
	.align	2
$LC2:
	.ascii	"STTPRCNT\000"
	.align	2
$LC3:
	.ascii	"STKEYS%d\000"
	.align	2
$LC4:
	.ascii	"STARMS\000"
	.align	2
$LC5:
	.ascii	"STGNUM%d\000"
	.align	2
$LC6:
	.ascii	"STFB%d\000"
	.align	2
$LC7:
	.ascii	"STBAR\000"
	.align	2
$LC8:
	.ascii	"STFST%d%d\000"
	.align	2
$LC9:
	.ascii	"STFTR%d0\000"
	.align	2
$LC10:
	.ascii	"STFTL%d0\000"
	.align	2
$LC11:
	.ascii	"STFOUCH%d\000"
	.align	2
$LC12:
	.ascii	"STFEVL%d\000"
	.align	2
$LC13:
	.ascii	"STFKILL%d\000"
	.align	2
$LC14:
	.ascii	"STFGOD0\000"
	.align	2
$LC15:
	.ascii	"STFDEAD0\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	ST_loadUnloadGraphics
	.type	ST_loadUnloadGraphics, @function
ST_loadUnloadGraphics:
	.frame	$sp,96,$31		# vars= 32, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-96
	sw	$20,72($sp)
	sw	$17,60($sp)
	lui	$20,%hi(shortnum)
	lui	$17,%hi(tallnum)
	sw	$22,80($sp)
	sw	$21,76($sp)
	addiu	$17,$17,%lo(tallnum)
	addiu	$20,$20,%lo(shortnum)
	lui	$22,%hi($LC0)
	lui	$21,%hi($LC1)
	sw	$23,84($sp)
	sw	$19,68($sp)
	sw	$18,64($sp)
	sw	$16,56($sp)
	sw	$31,92($sp)
	sw	$fp,88($sp)
	move	$16,$4
	addiu	$23,$17,40
	move	$19,$20
	move	$18,$0
	addiu	$22,$22,%lo($LC0)
	addiu	$21,$21,%lo($LC1)
$L5:
	move	$7,$18
	move	$6,$22
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	move	$5,$17
	jalr	$16
	addiu	$4,$sp,24

	move	$7,$18
	move	$6,$21
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$17,$17,4
	move	$5,$19
	jalr	$16
	addiu	$4,$sp,24

	addiu	$18,$18,1
	.set	noat
	xor	$1,$23,$17
	bne	$1,$0,$L5
	.set	at
	addiu	$19,$19,4

	lui	$5,%hi(tallpercent)
	lui	$4,%hi($LC2)
	addiu	$5,$5,%lo(tallpercent)
	addiu	$4,$4,%lo($LC2)
	lui	$18,%hi(keys)
	jalr	$16
	lui	$19,%hi($LC3)

	addiu	$18,$18,%lo(keys)
	move	$17,$0
	addiu	$19,$19,%lo($LC3)
	li	$21,6			# 0x6
$L6:
	move	$7,$17
	move	$6,$19
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$17,$17,1
	move	$5,$18
	jalr	$16
	addiu	$4,$sp,24

	.set	noat
	xor	$1,$17,$21
	bne	$1,$0,$L6
	.set	at
	addiu	$18,$18,4

	lui	$5,%hi(armsbg)
	lui	$4,%hi($LC4)
	addiu	$5,$5,%lo(armsbg)
	addiu	$4,$4,%lo($LC4)
	lui	$17,%hi(arms)
	jalr	$16
	lui	$19,%hi($LC5)

	addiu	$17,$17,%lo(arms)
	li	$18,2			# 0x2
	addiu	$19,$19,%lo($LC5)
	li	$21,8			# 0x8
$L7:
	move	$7,$18
	move	$6,$19
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	move	$5,$17
	jalr	$16
	addiu	$4,$sp,24

	lw	$2,8($20)
	addiu	$18,$18,1
	sw	$2,4($17)
	addiu	$20,$20,4
	.set	noat
	xor	$1,$18,$21
	bne	$1,$0,$L7
	.set	at
	addiu	$17,$17,8

	lui	$2,%hi(consoleplayer)
	lw	$7,%lo(consoleplayer)($2)
	lui	$6,%hi($LC6)
	addiu	$6,$6,%lo($LC6)
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	lui	$5,%hi(faceback)
	addiu	$4,$sp,24
	jalr	$16
	addiu	$5,$5,%lo(faceback)

	lui	$5,%hi(sbar)
	lui	$4,%hi($LC7)
	addiu	$5,$5,%lo(sbar)
	addiu	$4,$4,%lo($LC7)
	jalr	$16
	lui	$22,%hi($LC9)

	addiu	$2,$22,%lo($LC9)
	sw	$2,40($sp)
	lui	$2,%hi($LC10)
	addiu	$2,$2,%lo($LC10)
	sw	$2,44($sp)
	lui	$2,%hi($LC11)
	lui	$19,%hi(faces+12)
	lui	$20,%hi($LC8)
	addiu	$2,$2,%lo($LC11)
	addiu	$19,$19,%lo(faces+12)
	move	$17,$0
	lui	$fp,%hi($LC12)
	lui	$23,%hi($LC13)
	addiu	$20,$20,%lo($LC8)
	li	$21,3			# 0x3
	sw	$2,48($sp)
$L8:
	addiu	$18,$19,-12
	move	$22,$0
$L9:
	sw	$22,16($sp)
	move	$7,$17
	move	$6,$20
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$22,$22,1
	move	$5,$18
	jalr	$16
	addiu	$4,$sp,24

	.set	noat
	xor	$1,$22,$21
	bne	$1,$0,$L9
	.set	at
	addiu	$18,$18,4

	lw	$6,40($sp)
	move	$7,$17
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	move	$5,$19
	jalr	$16
	addiu	$4,$sp,24

	lw	$6,44($sp)
	move	$7,$17
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$5,$19,4
	jalr	$16
	addiu	$4,$sp,24

	lw	$6,48($sp)
	move	$7,$17
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$5,$19,8
	jalr	$16
	addiu	$4,$sp,24

	move	$7,$17
	addiu	$6,$fp,%lo($LC12)
	addiu	$4,$sp,24
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$5,$19,12
	jalr	$16
	addiu	$4,$sp,24

	move	$7,$17
	addiu	$4,$sp,24
	addiu	$6,$23,%lo($LC13)
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$5,$19,16
	jalr	$16
	addiu	$4,$sp,24

	addiu	$17,$17,1
	li	$2,5			# 0x5
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L8
	.set	at
	addiu	$19,$19,32

	lui	$5,%hi(faces+160)
	lui	$4,%hi($LC14)
	addiu	$5,$5,%lo(faces+160)
	jalr	$16
	addiu	$4,$4,%lo($LC14)

	lui	$5,%hi(faces+164)
	lui	$4,%hi($LC15)
	addiu	$5,$5,%lo(faces+164)
	jalr	$16
	addiu	$4,$4,%lo($LC15)

	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	jr	$31
	addiu	$sp,$sp,96

	.set	macro
	.set	reorder
	.end	ST_loadUnloadGraphics
	.size	ST_loadUnloadGraphics, .-ST_loadUnloadGraphics
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	ST_unloadCallback
	.type	ST_unloadCallback, @function
ST_unloadCallback:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	W_ReleaseLumpName
	move	$16,$5

	lw	$31,20($sp)
	sw	$0,0($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_unloadCallback
	.size	ST_unloadCallback, .-ST_unloadCallback
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	ST_refreshBackground.part.0
	.type	ST_refreshBackground.part.0, @function
ST_refreshBackground.part.0:
	.frame	$sp,40,$31		# vars= 0, regs= 2/0, args= 32, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$16,32($sp)
	lui	$16,%hi(st_backing_screen)
	lw	$4,%lo(st_backing_screen)($16)
	sw	$31,36($sp)
	jal	V_UseBuffer
	nop

	lui	$2,%hi(sbar)
	lw	$6,%lo(sbar)($2)
	move	$5,$0
	jal	V_DrawPatch
	move	$4,$0

	lui	$2,%hi(netgame)
	lw	$2,%lo(netgame)($2)
	bne	$2,$0,$L24
	lui	$2,%hi(faceback)

$L19:
	jal	V_RestoreBuffer
	nop

	li	$2,168			# 0xa8
	sw	$2,24($sp)
	lw	$6,%lo(st_backing_screen)($16)
	li	$2,32			# 0x20
	sw	$0,20($sp)
	sw	$2,16($sp)
	li	$7,320			# 0x140
	move	$5,$0
	jal	V_CopyRect
	move	$4,$0

	lw	$31,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,40

$L24:
	lw	$6,%lo(faceback)($2)
	move	$5,$0
	jal	V_DrawPatch
	li	$4,143			# 0x8f

	b	$L19
	nop

	.set	macro
	.set	reorder
	.end	ST_refreshBackground.part.0
	.size	ST_refreshBackground.part.0, .-ST_refreshBackground.part.0
	.align	2
	.globl	ST_refreshBackground
	.set	nomips16
	.set	nomicromips
	.ent	ST_refreshBackground
	.type	ST_refreshBackground, @function
ST_refreshBackground:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(st_statusbaron)
	lw	$2,%lo(st_statusbaron)($2)
	bne	$2,$0,$L27
	nop

	jr	$31
	nop

$L27:
	j	ST_refreshBackground.part.0
	nop

	.set	macro
	.set	reorder
	.end	ST_refreshBackground
	.size	ST_refreshBackground, .-ST_refreshBackground
	.section	.rodata.str1.4
	.align	2
$LC16:
	.ascii	"Degreelessness Mode On\000"
	.align	2
$LC17:
	.ascii	"Degreelessness Mode Off\000"
	.align	2
$LC18:
	.ascii	"Ammo (no keys) Added\000"
	.align	2
$LC19:
	.ascii	"Very Happy Ammo Added\000"
	.align	2
$LC20:
	.ascii	"Music Change\000"
	.align	2
$LC21:
	.ascii	"IMPOSSIBLE SELECTION\000"
	.align	2
$LC22:
	.ascii	"No Clipping Mode ON\000"
	.align	2
$LC23:
	.ascii	"No Clipping Mode OFF\000"
	.align	2
$LC24:
	.ascii	"Power-up Toggled\000"
	.align	2
$LC25:
	.ascii	"inVuln, Str, Inviso, Rad, Allmap, or Lite-amp\000"
	.align	2
$LC26:
	.ascii	"... doesn't suck - GM\000"
	.align	2
$LC27:
	.ascii	"ang=0x%x;x,y=(0x%x,0x%x)\000"
	.align	2
$LC28:
	.ascii	"Changing Level...\000"
	.text
	.align	2
	.globl	ST_Responder
	.set	nomips16
	.set	nomicromips
	.ent	ST_Responder
	.type	ST_Responder, @function
ST_Responder:
	.frame	$sp,72,$31		# vars= 8, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	addiu	$sp,$sp,-72
	li	$3,1			# 0x1
	sw	$16,32($sp)
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L107
	.set	at
	move	$16,$4

	lui	$19,%hi(netgame)
	lw	$3,%lo(netgame)($19)
	or	$2,$2,$3
	bne	$2,$0,$L118
	lw	$31,68($sp)

	lui	$23,%hi(gameskill)
	lw	$3,%lo(gameskill)($23)
	li	$2,4			# 0x4
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L33
	.set	at
	lui	$17,%hi(cheat_clev)

$L117:
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$17,%lo(cheat_clev)

	bne	$2,$0,$L108
	addiu	$5,$sp,24

$L86:
	lw	$31,68($sp)
$L118:
	lw	$fp,64($sp)
$L121:
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,72

$L107:
	lw	$4,4($4)
	li	$3,-65536			# 0xffffffffffff0000
	and	$3,$4,$3
	li	$5,1634533376			# 0x616d0000
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L118
	.set	at
	lw	$31,68($sp)

	addiu	$3,$3,25856
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L121
	.set	at
	lw	$fp,64($sp)

	lui	$3,%hi(st_firsttime)
	b	$L86
	sw	$2,%lo(st_firsttime)($3)

$L33:
	lb	$5,8($4)
	lui	$4,%hi(cheat_god)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_god)

	beq	$2,$0,$L35
	lui	$2,%hi(plyr)

	lw	$2,%lo(plyr)($2)
	lw	$3,204($2)
	xori	$3,$3,0x2
	andi	$4,$3,0x2
	bne	$4,$0,$L109
	sw	$3,204($2)

	lui	$3,%hi($LC17)
	addiu	$3,$3,%lo($LC17)
	sw	$3,224($2)
$L38:
	lui	$18,%hi(cheat_powerup)
$L120:
	lui	$21,%hi($LC24)
	addiu	$18,$18,%lo(cheat_powerup)
	move	$17,$0
	li	$20,6			# 0x6
	lui	$22,%hi(plyr)
	addiu	$21,$21,%lo($LC24)
	li	$fp,1			# 0x1
$L62:
	lb	$5,8($16)
	jal	cht_CheckCheat
	move	$4,$18

	beq	$2,$0,$L56
	sll	$3,$17,2

	lw	$4,%lo(plyr)($22)
	addu	$3,$4,$3
	lw	$2,52($3)
	beq	$2,$0,$L110
	nop

	.set	noat
	xor	$1,$17,$fp
	beq	$1,$0,$L59
	.set	at
	lui	$2,%hi($LC24)

	sw	$fp,52($3)
$L58:
	sw	$21,224($4)
$L56:
	addiu	$17,$17,1
	.set	noat
	xor	$1,$17,$20
	bne	$1,$0,$L62
	.set	at
	addiu	$18,$18,52

	lui	$4,%hi(cheat_powerup+312)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_powerup+312)

	beq	$2,$0,$L63
	lui	$2,%hi(plyr)

	lw	$3,%lo(plyr)($2)
	lui	$2,%hi($LC25)
	addiu	$2,$2,%lo($LC25)
	sw	$2,224($3)
$L64:
	lw	$2,%lo(netgame)($19)
$L123:
	bne	$2,$0,$L118
	lw	$31,68($sp)

	b	$L117
	lui	$17,%hi(cheat_clev)

$L108:
	jal	cht_GetParam
	addiu	$4,$17,%lo(cheat_clev)

	lui	$2,%hi(gamemode)
	lw	$2,%lo(gamemode)($2)
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L111
	.set	at
	lui	$3,%hi(gameversion)

	lb	$6,25($sp)
	lw	$4,%lo(gameversion)($3)
	li	$3,9			# 0x9
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L112
	.set	at
	addiu	$6,$6,-48

	lb	$5,24($sp)
	addiu	$5,$5,-48
	blez	$5,$L118
	lw	$31,68($sp)

	blez	$6,$L118
	li	$3,3			# 0x3

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L113
	.set	at
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L114
	.set	at
	nop

	bne	$2,$0,$L122
	lui	$2,%hi(plyr)

	.set	noat
	xor	$1,$5,$3
	bne	$1,$0,$L121
	.set	at
	lw	$fp,64($sp)

$L80:
	slt	$2,$6,10
$L124:
	beq	$2,$0,$L86
	li	$5,1			# 0x1

$L73:
	lui	$2,%hi(plyr)
$L122:
	lw	$3,%lo(plyr)($2)
	lui	$2,%hi($LC28)
	addiu	$2,$2,%lo($LC28)
	lw	$4,%lo(gameskill)($23)
	jal	G_DeferedInitNew
	sw	$2,224($3)

	b	$L118
	lw	$31,68($sp)

$L109:
	lw	$3,0($2)
	beq	$3,$0,$L37
	li	$4,100			# 0x64

	sw	$4,108($3)
$L37:
	li	$3,100			# 0x64
	sw	$3,40($2)
	lui	$3,%hi($LC16)
	addiu	$3,$3,%lo($LC16)
	b	$L38
	sw	$3,224($2)

$L110:
	jal	P_GivePower
	move	$5,$17

	b	$L58
	lw	$4,%lo(plyr)($22)

$L59:
	addiu	$2,$2,%lo($LC24)
	sw	$0,56($4)
	sw	$2,224($4)
	addiu	$18,$18,52
	b	$L62
	li	$17,2			# 0x2

$L35:
	lui	$4,%hi(cheat_ammonokey)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_ammonokey)

	beq	$2,$0,$L39
	lui	$2,%hi(plyr)

	lw	$3,%lo(plyr)($2)
	li	$2,200			# 0xc8
	sw	$2,44($3)
	li	$2,2			# 0x2
	sw	$2,48($3)
	addiu	$5,$3,164
	addiu	$2,$3,128
	li	$4,1			# 0x1
$L40:
	sw	$4,0($2)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L40
	.set	at
	nop

	lw	$2,192($3)
	lw	$5,184($3)
	lw	$4,188($3)
	lw	$6,180($3)
	sw	$2,176($3)
	lui	$2,%hi($LC18)
	addiu	$2,$2,%lo($LC18)
	sw	$6,164($3)
	sw	$5,168($3)
	sw	$4,172($3)
	b	$L38
	sw	$2,224($3)

$L63:
	lui	$4,%hi(cheat_choppers)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_choppers)

	beq	$2,$0,$L65
	lui	$2,%hi(plyr)

	lw	$2,%lo(plyr)($2)
	li	$3,1			# 0x1
	sw	$3,156($2)
	sw	$3,52($2)
	lui	$3,%hi($LC26)
	addiu	$3,$3,%lo($LC26)
	b	$L64
	sw	$3,224($2)

$L111:
	lb	$2,24($sp)
	lb	$4,25($sp)
	addiu	$2,$2,-48
	sll	$6,$2,2
	addu	$6,$6,$2
	sll	$6,$6,1
	addu	$6,$6,$4
	addiu	$6,$6,-48
	blez	$6,$L86
	slt	$2,$6,41

	beq	$2,$0,$L86
	li	$5,1			# 0x1

	b	$L122
	lui	$2,%hi(plyr)

$L39:
	lui	$4,%hi(cheat_ammo)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_ammo)

	beq	$2,$0,$L41
	lui	$2,%hi(plyr)

	lw	$3,%lo(plyr)($2)
	li	$2,200			# 0xc8
	sw	$2,44($3)
	li	$2,2			# 0x2
	sw	$2,48($3)
	addiu	$5,$3,164
	addiu	$2,$3,128
	li	$4,1			# 0x1
$L42:
	sw	$4,0($2)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L42
	.set	at
	nop

	lw	$2,192($3)
	lw	$6,184($3)
	lw	$5,188($3)
	lw	$7,180($3)
	sw	$2,176($3)
	lui	$2,%hi($LC19)
	addiu	$2,$2,%lo($LC19)
	sw	$7,164($3)
	sw	$6,168($3)
	sw	$5,172($3)
	sw	$4,76($3)
	sw	$4,80($3)
	sw	$4,84($3)
	sw	$4,88($3)
	sw	$4,92($3)
	sw	$4,96($3)
	b	$L38
	sw	$2,224($3)

$L65:
	lui	$4,%hi(cheat_mypos)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_mypos)

	beq	$2,$0,$L123
	lw	$2,%lo(netgame)($19)

	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	lui	$17,%hi(buf.5)
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	addiu	$3,$3,%lo(players)
	sll	$2,$2,5
	addu	$2,$2,$3
	lw	$2,0($2)
	lui	$6,%hi($LC27)
	lw	$3,16($2)
	lw	$7,32($2)
	sw	$3,20($sp)
	lw	$2,12($2)
	addiu	$4,$17,%lo(buf.5)
	sw	$2,16($sp)
	addiu	$6,$6,%lo($LC27)
	jal	M_snprintf
	li	$5,52			# 0x34

	lui	$2,%hi(plyr)
	lw	$2,%lo(plyr)($2)
	addiu	$17,$17,%lo(buf.5)
	b	$L64
	sw	$17,224($2)

$L112:
	blez	$6,$L86
	li	$3,3			# 0x3

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L80
	.set	at
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L80
	.set	at
	nop

	beq	$2,$0,$L124
	slt	$2,$6,10

	b	$L73
	li	$5,1			# 0x1

$L41:
	lui	$17,%hi(cheat_mus)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$17,%lo(cheat_mus)

	bne	$2,$0,$L115
	lui	$18,%hi(gamemission)

	lw	$2,%lo(gamemission)($18)
	li	$17,-5			# 0xfffffffffffffffb
	and	$2,$2,$17
	beq	$2,$0,$L49
	nop

	lui	$4,%hi(cheat_commercial_noclip)
$L126:
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_commercial_noclip)

	beq	$2,$0,$L120
	lui	$18,%hi(cheat_powerup)

	lui	$2,%hi(plyr)
$L125:
	lw	$2,%lo(plyr)($2)
	lw	$3,204($2)
	xori	$3,$3,0x1
	andi	$4,$3,0x1
	beq	$4,$0,$L116
	sw	$3,204($2)

	lui	$3,%hi($LC22)
	addiu	$3,$3,%lo($LC22)
	b	$L38
	sw	$3,224($2)

$L113:
	slt	$2,$5,5
	beq	$2,$0,$L118
	lw	$31,68($sp)

	slt	$2,$6,10
$L119:
	bne	$2,$0,$L122
	lui	$2,%hi(plyr)

	b	$L118
	lw	$31,68($sp)

$L114:
	slt	$2,$5,4
	beq	$2,$0,$L118
	lw	$31,68($sp)

	b	$L119
	slt	$2,$6,10

$L49:
	lui	$4,%hi(cheat_noclip)
	lb	$5,8($16)
	jal	cht_CheckCheat
	addiu	$4,$4,%lo(cheat_noclip)

	bne	$2,$0,$L125
	lui	$2,%hi(plyr)

	lw	$2,%lo(gamemission)($18)
	and	$2,$2,$17
	bne	$2,$0,$L126
	lui	$4,%hi(cheat_commercial_noclip)

	b	$L120
	lui	$18,%hi(cheat_powerup)

$L115:
	lui	$18,%hi(plyr)
	lw	$3,%lo(plyr)($18)
	lui	$2,%hi($LC20)
	addiu	$2,$2,%lo($LC20)
	sw	$2,224($3)
	addiu	$5,$sp,24
	jal	cht_GetParam
	addiu	$4,$17,%lo(cheat_mus)

	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L44
	.set	at
	lui	$2,%hi(gameversion)

	lw	$2,%lo(gameversion)($2)
	sltu	$2,$2,6
	bne	$2,$0,$L127
	lb	$2,24($sp)

	lb	$3,24($sp)
	lb	$4,25($sp)
	addiu	$3,$3,-49
	sll	$2,$3,3
	addu	$2,$2,$3
	addu	$3,$2,$4
	slt	$3,$3,81
	bne	$3,$0,$L48
	addu	$4,$2,$4

	lw	$3,%lo(plyr)($18)
$L128:
	lui	$2,%hi($LC21)
	addiu	$2,$2,%lo($LC21)
	b	$L38
	sw	$2,224($3)

$L44:
	lb	$2,24($sp)
$L127:
	li	$3,10			# 0xa
	addiu	$2,$2,-48
	multu	$2,$3
	mflo	$2
	lb	$4,25($sp)
	addu	$3,$2,$4
	slt	$3,$3,84
	beq	$3,$0,$L128
	lw	$3,%lo(plyr)($18)

	addu	$4,$2,$4
	li	$5,1			# 0x1
	jal	S_ChangeMusic
	addiu	$4,$4,-16

	b	$L120
	lui	$18,%hi(cheat_powerup)

$L116:
	lui	$3,%hi($LC23)
	addiu	$3,$3,%lo($LC23)
	b	$L38
	sw	$3,224($2)

$L48:
	li	$5,1			# 0x1
	jal	S_ChangeMusic
	addiu	$4,$4,-48

	b	$L120
	lui	$18,%hi(cheat_powerup)

	.set	macro
	.set	reorder
	.end	ST_Responder
	.size	ST_Responder, .-ST_Responder
	.align	2
	.globl	ST_calcPainOffset
	.set	nomips16
	.set	nomicromips
	.ent	ST_calcPainOffset
	.type	ST_calcPainOffset, @function
ST_calcPainOffset:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(plyr)
	lw	$2,%lo(plyr)($2)
	lui	$5,%hi(oldhealth.4)
	lw	$3,40($2)
	lw	$4,%lo(oldhealth.4)($5)
	li	$2,100			# 0x64
	slt	$6,$3,101
	movz	$3,$2,$6
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L132
	.set	at
	nop

	subu	$2,$2,$3
	sll	$4,$2,2
	addu	$4,$4,$2
	li	$2,680329216			# 0x288d0000
	ori	$2,$2,0xf0cb
	mult	$4,$2
	sra	$4,$4,31
	mfhi	$2
	sw	$3,%lo(oldhealth.4)($5)
	sra	$2,$2,4
	subu	$2,$2,$4
	sll	$2,$2,3
	lui	$4,%hi(lastcalc.3)
	jr	$31
	sw	$2,%lo(lastcalc.3)($4)

$L132:
	lui	$2,%hi(lastcalc.3)
	jr	$31
	lw	$2,%lo(lastcalc.3)($2)

	.set	macro
	.set	reorder
	.end	ST_calcPainOffset
	.size	ST_calcPainOffset, .-ST_calcPainOffset
	.align	2
	.globl	ST_updateFaceWidget
	.set	nomips16
	.set	nomicromips
	.ent	ST_updateFaceWidget
	.type	ST_updateFaceWidget, @function
ST_updateFaceWidget:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	lui	$16,%hi(priority.2)
	lw	$6,%lo(priority.2)($16)
	sw	$31,28($sp)
	slt	$2,$6,10
	sw	$18,24($sp)
	beq	$2,$0,$L200
	sw	$17,20($sp)

	lui	$17,%hi(plyr)
	lw	$9,%lo(plyr)($17)
	lw	$2,40($9)
	beq	$2,$0,$L201
	li	$3,9			# 0x9

	li	$2,9			# 0x9
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L164
	.set	at
	lui	$2,%hi(st_facecount)

	lw	$2,232($9)
	bne	$2,$0,$L202
	lui	$2,%hi(oldweaponsowned)

	li	$2,8			# 0x8
$L215:
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L200
	.set	at
	lw	$3,%lo(plyr)($17)

	lw	$2,228($3)
	bne	$2,$0,$L197
	lui	$2,%hi(st_facecount)

	slt	$3,$6,6
$L214:
	beq	$3,$0,$L164
	lw	$4,%lo(plyr)($17)

	lw	$3,196($4)
	beq	$3,$0,$L166
	lui	$3,%hi(lastattackdown.1)

	lui	$5,%hi(lastattackdown.1)
	lw	$3,%lo(lastattackdown.1)($5)
	li	$7,-1			# 0xffffffffffffffff
	.set	noat
	xor	$1,$3,$7
	beq	$1,$0,$L203
	.set	at
	addiu	$3,$3,-1

	bne	$3,$0,$L168
	sw	$3,%lo(lastattackdown.1)($5)

	lw	$4,40($4)
	lui	$7,%hi(oldhealth.4)
	slt	$8,$4,101
	li	$3,100			# 0x64
	lw	$6,%lo(oldhealth.4)($7)
	movz	$4,$3,$8
	li	$8,5			# 0x5
	.set	noat
	xor	$1,$4,$6
	beq	$1,$0,$L204
	.set	at
	sw	$8,%lo(priority.2)($16)

	subu	$3,$3,$4
	sll	$6,$3,2
	addu	$6,$6,$3
	li	$3,680329216			# 0x288d0000
	ori	$3,$3,0xf0cb
	mult	$6,$3
	sra	$6,$6,31
	mfhi	$3
	sw	$4,%lo(oldhealth.4)($7)
	sra	$3,$3,4
	subu	$3,$3,$6
	sll	$3,$3,3
	lui	$6,%hi(lastcalc.3)
	sw	$3,%lo(lastcalc.3)($6)
$L170:
	addiu	$3,$3,7
	lui	$4,%hi(st_faceindex)
	sw	$3,%lo(st_faceindex)($4)
	li	$3,1			# 0x1
	sw	$3,%lo(lastattackdown.1)($5)
$L148:
	addiu	$3,$3,-1
$L208:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$3,%lo(st_facecount)($2)
	jr	$31
	addiu	$sp,$sp,32

$L200:
	lui	$2,%hi(st_facecount)
$L164:
	lw	$3,%lo(st_facecount)($2)
$L216:
	bne	$3,$0,$L148
	lui	$6,%hi(oldhealth.4)

	lui	$3,%hi(plyr)
	lw	$3,%lo(plyr)($3)
	lw	$4,40($3)
	lw	$5,%lo(oldhealth.4)($6)
	li	$3,100			# 0x64
	slt	$7,$4,101
	movz	$4,$3,$7
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L205
	.set	at
	nop

	subu	$3,$3,$4
	sll	$5,$3,2
	addu	$5,$5,$3
	li	$3,680329216			# 0x288d0000
	ori	$3,$3,0xf0cb
	mult	$5,$3
	sra	$5,$5,31
	mfhi	$3
	sw	$4,%lo(oldhealth.4)($6)
	sra	$3,$3,4
	subu	$3,$3,$5
	sll	$3,$3,3
	lui	$5,%hi(lastcalc.3)
	sw	$3,%lo(lastcalc.3)($5)
$L175:
	lui	$4,%hi(st_randomnumber)
	lw	$5,%lo(st_randomnumber)($4)
	li	$4,1431633920			# 0x55550000
	addiu	$4,$4,21846
	mult	$5,$4
	sra	$6,$5,31
	mfhi	$4
	lw	$31,28($sp)
	subu	$4,$4,$6
	sll	$6,$4,1
	addu	$4,$6,$4
	subu	$5,$5,$4
	addu	$5,$5,$3
	lui	$3,%hi(st_faceindex)
	sw	$5,%lo(st_faceindex)($3)
	li	$3,16			# 0x10
	lw	$18,24($sp)
	lw	$17,20($sp)
	sw	$0,%lo(priority.2)($16)
	sw	$3,%lo(st_facecount)($2)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L201:
	sw	$3,%lo(priority.2)($16)
	li	$4,41			# 0x29
	lui	$3,%hi(st_faceindex)
	lui	$2,%hi(st_facecount)
	sw	$4,%lo(st_faceindex)($3)
	li	$3,1			# 0x1
	b	$L164
	sw	$3,%lo(st_facecount)($2)

$L202:
	addiu	$2,$2,%lo(oldweaponsowned)
	addiu	$3,$9,128
	addiu	$7,$2,36
	move	$8,$0
$L138:
	lw	$4,0($3)
	lw	$5,0($2)
	.set	noat
	xor	$1,$5,$4
	beq	$1,$0,$L137
	.set	at
	addiu	$3,$3,4

	sw	$4,0($2)
	li	$8,1			# 0x1
$L137:
	addiu	$2,$2,4
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L138
	.set	at
	nop

	beq	$8,$0,$L215
	li	$2,8			# 0x8

	lw	$4,40($9)
	lui	$6,%hi(oldhealth.4)
	slt	$7,$4,101
	li	$3,100			# 0x64
	movz	$4,$3,$7
	lw	$5,%lo(oldhealth.4)($6)
	li	$7,8			# 0x8
	lui	$2,%hi(st_facecount)
	sw	$7,%lo(priority.2)($16)
	li	$7,70			# 0x46
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L206
	.set	at
	sw	$7,%lo(st_facecount)($2)

	subu	$3,$3,$4
	sll	$5,$3,2
	addu	$5,$5,$3
	li	$3,680329216			# 0x288d0000
	ori	$3,$3,0xf0cb
	mult	$5,$3
	sra	$5,$5,31
	mfhi	$3
	sw	$4,%lo(oldhealth.4)($6)
	sra	$3,$3,4
	subu	$3,$3,$5
	sll	$3,$3,3
	lui	$5,%hi(lastcalc.3)
	sw	$3,%lo(lastcalc.3)($5)
$L140:
	addiu	$3,$3,6
	lui	$4,%hi(st_faceindex)
	b	$L164
	sw	$3,%lo(st_faceindex)($4)

$L166:
	li	$5,-1			# 0xffffffffffffffff
	sw	$5,%lo(lastattackdown.1)($3)
$L168:
	li	$3,5			# 0x5
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L216
	.set	at
	lw	$3,%lo(st_facecount)($2)

	lw	$3,204($4)
	andi	$3,$3,0x2
	bne	$3,$0,$L217
	li	$3,4			# 0x4

	lw	$3,52($4)
	beq	$3,$0,$L216
	lw	$3,%lo(st_facecount)($2)

	li	$3,4			# 0x4
$L217:
	lw	$31,28($sp)
	sw	$3,%lo(priority.2)($16)
	li	$4,40			# 0x28
	lui	$3,%hi(st_faceindex)
	sw	$4,%lo(st_faceindex)($3)
	move	$3,$0
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	sw	$3,%lo(st_facecount)($2)
	jr	$31
	addiu	$sp,$sp,32

$L197:
	lw	$2,236($3)
	beq	$2,$0,$L144
	nop

	lw	$8,0($3)
	.set	noat
	xor	$1,$2,$8
	beq	$1,$0,$L144
	.set	at
	lui	$18,%hi(st_oldhealth)

	lw	$4,40($3)
	lw	$3,%lo(st_oldhealth)($18)
	li	$5,7			# 0x7
	subu	$3,$4,$3
	slt	$3,$3,21
	bne	$3,$0,$L145
	sw	$5,%lo(priority.2)($16)

	lui	$6,%hi(oldhealth.4)
	slt	$7,$4,101
	li	$3,100			# 0x64
	lw	$5,%lo(oldhealth.4)($6)
	lui	$2,%hi(st_facecount)
	movz	$4,$3,$7
	li	$7,35			# 0x23
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L207
	.set	at
	sw	$7,%lo(st_facecount)($2)

	subu	$3,$3,$4
	sll	$5,$3,2
	addu	$5,$5,$3
	li	$3,680329216			# 0x288d0000
	ori	$3,$3,0xf0cb
	mult	$5,$3
	sra	$5,$5,31
	mfhi	$3
	sw	$4,%lo(oldhealth.4)($6)
	sra	$3,$3,4
	subu	$3,$3,$5
	sll	$3,$3,3
	lui	$5,%hi(lastcalc.3)
	sw	$3,%lo(lastcalc.3)($5)
$L147:
	addiu	$4,$3,5
	lw	$3,%lo(st_facecount)($2)
	lui	$5,%hi(st_faceindex)
	sw	$4,%lo(st_faceindex)($5)
	b	$L208
	addiu	$3,$3,-1

$L203:
	li	$3,70			# 0x46
	b	$L168
	sw	$3,%lo(lastattackdown.1)($5)

$L144:
	li	$2,7			# 0x7
	.set	noat
	xor	$1,$6,$2
	beq	$1,$0,$L200
	.set	at
	lui	$7,%hi(st_faceindex)

	lui	$2,%hi(st_facecount)
	lui	$5,%hi(oldhealth.4)
	lui	$8,%hi(lastcalc.3)
	lui	$18,%hi(st_oldhealth)
$L176:
	lw	$6,40($3)
	lw	$3,%lo(st_oldhealth)($18)
	li	$4,100			# 0x64
	subu	$3,$6,$3
	slt	$10,$6,101
	slt	$3,$3,21
	lw	$9,%lo(oldhealth.4)($5)
	bne	$3,$0,$L156
	movz	$6,$4,$10

	li	$3,7			# 0x7
	sw	$3,%lo(priority.2)($16)
	li	$3,35			# 0x23
	.set	noat
	xor	$1,$6,$9
	beq	$1,$0,$L209
	.set	at
	sw	$3,%lo(st_facecount)($2)

	subu	$4,$4,$6
	sll	$3,$4,2
	addu	$4,$3,$4
	li	$3,680329216			# 0x288d0000
	ori	$3,$3,0xf0cb
	mult	$4,$3
	sra	$4,$4,31
	mfhi	$3
	sw	$6,%lo(oldhealth.4)($5)
	sra	$3,$3,4
	subu	$3,$3,$4
	sll	$3,$3,3
	sw	$3,%lo(lastcalc.3)($8)
	addiu	$3,$3,5
$L159:
	b	$L164
	sw	$3,%lo(st_faceindex)($7)

$L156:
	li	$3,6			# 0x6
	sw	$3,%lo(priority.2)($16)
	li	$3,35			# 0x23
	.set	noat
	xor	$1,$6,$9
	beq	$1,$0,$L210
	.set	at
	sw	$3,%lo(st_facecount)($2)

	subu	$4,$4,$6
	sll	$3,$4,2
	addu	$4,$3,$4
	li	$3,680329216			# 0x288d0000
	ori	$3,$3,0xf0cb
	mult	$4,$3
	sra	$4,$4,31
	mfhi	$3
	sw	$6,%lo(oldhealth.4)($5)
	sra	$3,$3,4
	subu	$3,$3,$4
	sll	$3,$3,3
	sw	$3,%lo(lastcalc.3)($8)
	addiu	$3,$3,7
$L213:
	b	$L164
	sw	$3,%lo(st_faceindex)($7)

$L205:
	lui	$3,%hi(lastcalc.3)
	b	$L175
	lw	$3,%lo(lastcalc.3)($3)

$L145:
	lw	$6,12($2)
	lw	$4,12($8)
	lw	$7,16($2)
	jal	R_PointToAngle2
	lw	$5,16($8)

	lw	$3,%lo(plyr)($17)
	lw	$4,0($3)
	lw	$6,32($4)
	sltu	$4,$6,$2
	bne	$4,$0,$L211
	li	$7,-2147483648			# 0xffffffff80000000

	subu	$6,$6,$2
	addiu	$7,$7,1
	sltu	$7,$6,$7
$L150:
	lw	$9,40($3)
	lui	$5,%hi(oldhealth.4)
	slt	$10,$9,101
	li	$4,100			# 0x64
	lw	$8,%lo(oldhealth.4)($5)
	lui	$2,%hi(st_facecount)
	movz	$9,$4,$10
	li	$10,35			# 0x23
	.set	noat
	xor	$1,$9,$8
	beq	$1,$0,$L212
	.set	at
	sw	$10,%lo(st_facecount)($2)

	subu	$4,$4,$9
	sll	$8,$4,2
	addu	$8,$8,$4
	li	$4,680329216			# 0x288d0000
	ori	$4,$4,0xf0cb
	mult	$8,$4
	sra	$8,$8,31
	mfhi	$4
	sw	$9,%lo(oldhealth.4)($5)
	sra	$4,$4,4
	subu	$4,$4,$8
	sll	$4,$4,3
	lui	$8,%hi(lastcalc.3)
	sw	$4,%lo(lastcalc.3)($8)
$L152:
	li	$9,536870912			# 0x20000000
	sltu	$6,$6,$9
	beq	$6,$0,$L153
	lw	$6,%lo(priority.2)($16)

	lui	$7,%hi(st_faceindex)
	addiu	$4,$4,7
	sw	$4,%lo(st_faceindex)($7)
$L154:
	slt	$4,$6,7
	beq	$4,$0,$L164
	nop

	lw	$4,228($3)
	bne	$4,$0,$L176
	nop

	b	$L214
	slt	$3,$6,6

$L211:
	subu	$6,$2,$6
	addiu	$7,$7,1
	sltu	$7,$6,$7
	b	$L150
	xori	$7,$7,0x1

$L207:
	lui	$3,%hi(lastcalc.3)
	b	$L147
	lw	$3,%lo(lastcalc.3)($3)

$L204:
	lui	$3,%hi(lastcalc.3)
	b	$L170
	lw	$3,%lo(lastcalc.3)($3)

$L210:
	lw	$3,%lo(lastcalc.3)($8)
	b	$L213
	addiu	$3,$3,7

$L209:
	lw	$3,%lo(lastcalc.3)($8)
	b	$L159
	addiu	$3,$3,5

$L153:
	beq	$7,$0,$L155
	nop

	lui	$7,%hi(st_faceindex)
	addiu	$4,$4,3
	lw	$6,%lo(priority.2)($16)
	b	$L154
	sw	$4,%lo(st_faceindex)($7)

$L206:
	lui	$3,%hi(lastcalc.3)
	b	$L140
	lw	$3,%lo(lastcalc.3)($3)

$L212:
	lui	$8,%hi(lastcalc.3)
	b	$L152
	lw	$4,%lo(lastcalc.3)($8)

$L155:
	lui	$7,%hi(st_faceindex)
	addiu	$4,$4,4
	lw	$6,%lo(priority.2)($16)
	b	$L154
	sw	$4,%lo(st_faceindex)($7)

	.set	macro
	.set	reorder
	.end	ST_updateFaceWidget
	.size	ST_updateFaceWidget, .-ST_updateFaceWidget
	.align	2
	.globl	ST_updateWidgets
	.set	nomips16
	.set	nomicromips
	.ent	ST_updateWidgets
	.type	ST_updateWidgets, @function
ST_updateWidgets:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(plyr)
	lw	$2,%lo(plyr)($16)
	lui	$4,%hi(weaponinfo)
	lw	$5,120($2)
	addiu	$4,$4,%lo(weaponinfo)
	sll	$3,$5,1
	addu	$3,$3,$5
	sll	$3,$3,3
	addu	$3,$3,$4
	lw	$3,0($3)
	li	$4,5			# 0x5
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L227
	.set	at
	sw	$31,20($sp)

	addiu	$3,$3,41
	sll	$3,$3,2
	addu	$3,$2,$3
$L219:
	lui	$4,%hi(w_ready)
	addiu	$4,$4,%lo(w_ready)
	sw	$3,16($4)
	sw	$5,28($4)
	lui	$4,%hi(keyboxes)
	addiu	$2,$2,76
	addiu	$4,$4,%lo(keyboxes)
	move	$3,$0
	li	$9,-1			# 0xffffffffffffffff
	li	$8,3			# 0x3
$L222:
	lw	$7,0($2)
	lw	$6,12($2)
	move	$5,$9
	beq	$6,$0,$L221
	movn	$5,$3,$7

	addiu	$5,$3,3
$L221:
	addiu	$3,$3,1
	sw	$5,0($4)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$3,$8
	bne	$1,$0,$L222
	.set	at
	addiu	$4,$4,4

	jal	ST_updateFaceWidget
	nop

	lui	$2,%hi(deathmatch)
	lw	$3,%lo(deathmatch)($2)
	lui	$2,%hi(st_statusbaron)
	lw	$4,%lo(st_statusbaron)($2)
	lui	$5,%hi(st_notdeathmatch)
	sltu	$2,$3,1
	beq	$4,$0,$L229
	sw	$2,%lo(st_notdeathmatch)($5)

	sltu	$4,$0,$3
$L223:
	lui	$5,%hi(consoleplayer)
	lw	$3,%lo(plyr)($16)
	lw	$7,%lo(consoleplayer)($5)
	lui	$5,%hi(st_armson)
	sw	$2,%lo(st_armson)($5)
	lui	$2,%hi(st_fragson)
	sw	$4,%lo(st_fragson)($2)
	addiu	$3,$3,104
	move	$4,$0
	move	$2,$0
	li	$6,4			# 0x4
$L226:
	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L224
	.set	at
	lw	$5,0($3)

	addu	$4,$4,$5
$L225:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L226
	.set	at
	addiu	$3,$3,4

	lui	$3,%hi(st_msgcounter)
	lw	$2,%lo(st_msgcounter)($3)
	lw	$31,20($sp)
	addiu	$2,$2,-1
	lui	$5,%hi(st_fragscount)
	lw	$16,16($sp)
	sw	$4,%lo(st_fragscount)($5)
	sw	$2,%lo(st_msgcounter)($3)
	jr	$31
	addiu	$sp,$sp,24

$L224:
	b	$L225
	subu	$4,$4,$5

$L229:
	b	$L223
	move	$2,$0

$L227:
	lui	$3,%hi(largeammo.0)
	b	$L219
	addiu	$3,$3,%lo(largeammo.0)

	.set	macro
	.set	reorder
	.end	ST_updateWidgets
	.size	ST_updateWidgets, .-ST_updateWidgets
	.align	2
	.globl	ST_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	ST_Ticker
	.type	ST_Ticker, @function
ST_Ticker:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(st_clock)
	lw	$2,%lo(st_clock)($3)
	addiu	$sp,$sp,-24
	addiu	$2,$2,1
	sw	$2,%lo(st_clock)($3)
	sw	$31,20($sp)
	jal	M_Random
	nop

	lui	$3,%hi(st_randomnumber)
	jal	ST_updateWidgets
	sw	$2,%lo(st_randomnumber)($3)

	lui	$2,%hi(plyr)
	lw	$2,%lo(plyr)($2)
	lw	$31,20($sp)
	lw	$3,40($2)
	lui	$2,%hi(st_oldhealth)
	sw	$3,%lo(st_oldhealth)($2)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_Ticker
	.size	ST_Ticker, .-ST_Ticker
	.align	2
	.globl	ST_doPaletteStuff
	.set	nomips16
	.set	nomicromips
	.ent	ST_doPaletteStuff
	.type	ST_doPaletteStuff, @function
ST_doPaletteStuff:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(plyr)
	lw	$3,%lo(plyr)($2)
	addiu	$sp,$sp,-24
	lw	$4,56($3)
	lw	$2,228($3)
	sw	$31,20($sp)
	beq	$4,$0,$L240
	sw	$16,16($sp)

	li	$5,12			# 0xc
	sra	$4,$4,6
	subu	$4,$5,$4
	slt	$5,$2,$4
	movn	$2,$4,$5
$L240:
	beq	$2,$0,$L241
	addiu	$2,$2,7

	lui	$3,%hi(gameversion)
	sra	$16,$2,3
	li	$4,7			# 0x7
	slt	$2,$2,64
	lw	$3,%lo(gameversion)($3)
	movz	$16,$4,$2
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L258
	.set	at
	addiu	$16,$16,1

$L243:
	lui	$2,%hi(st_palette)
$L261:
$L262:
	lw	$3,%lo(st_palette)($2)
	.set	noat
	xor	$1,$3,$16
	bne	$1,$0,$L259
	.set	at
	lw	$31,20($sp)

	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L241:
	lw	$2,232($3)
	beq	$2,$0,$L244
	addiu	$2,$2,7

	lui	$3,%hi(gameversion)
	sra	$16,$2,3
	li	$4,3			# 0x3
	slt	$2,$2,32
	lw	$3,%lo(gameversion)($3)
	movz	$16,$4,$2
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L243
	.set	at
	addiu	$16,$16,9

	blez	$16,$L243
	slt	$3,$16,9

	li	$2,13			# 0xd
	b	$L243
	movn	$16,$2,$3

$L259:
	lui	$3,%hi(lu_palette)
	lw	$4,%lo(lu_palette)($3)
	li	$5,8			# 0x8
	jal	W_CacheLumpNum
	sw	$16,%lo(st_palette)($2)

	sll	$3,$16,1
	addu	$3,$3,$16
	lw	$31,20($sp)
	lw	$16,16($sp)
	sll	$3,$3,8
	addu	$4,$2,$3
	j	I_SetPalette
	addiu	$sp,$sp,24

$L244:
	lw	$16,64($3)
	slt	$2,$16,129
	bne	$2,$0,$L260
	nop

	b	$L243
	li	$16,13			# 0xd

$L258:
	blez	$16,$L261
	lui	$2,%hi(st_palette)

	b	$L261
	li	$16,13			# 0xd

$L260:
	andi	$16,$16,0x8
	beq	$16,$0,$L261
	lui	$2,%hi(st_palette)

	b	$L262
	li	$16,13			# 0xd

	.set	macro
	.set	reorder
	.end	ST_doPaletteStuff
	.size	ST_doPaletteStuff, .-ST_doPaletteStuff
	.align	2
	.globl	ST_drawWidgets
	.set	nomips16
	.set	nomicromips
	.ent	ST_drawWidgets
	.type	ST_drawWidgets, @function
ST_drawWidgets:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(st_statusbaron)
	lw	$2,%lo(st_statusbaron)($2)
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$16,20($sp)
	beq	$2,$0,$L267
	move	$17,$4

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	sltu	$6,$2,1
	sltu	$2,$0,$2
$L264:
	lui	$3,%hi(st_armson)
	lui	$4,%hi(w_ready)
	lui	$16,%hi(w_ammo)
	sw	$6,%lo(st_armson)($3)
	move	$5,$17
	lui	$3,%hi(st_fragson)
	addiu	$4,$4,%lo(w_ready)
	addiu	$16,$16,%lo(w_ammo)
	lui	$18,%hi(w_maxammo)
	sw	$2,%lo(st_fragson)($3)
	jal	STlib_updateNum
	addiu	$18,$18,%lo(w_maxammo)

	addiu	$19,$16,128
$L265:
	move	$4,$16
	jal	STlib_updateNum
	move	$5,$17

	addiu	$16,$16,32
	move	$4,$18
	jal	STlib_updateNum
	move	$5,$17

	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L265
	.set	at
	addiu	$18,$18,32

	lui	$4,%hi(w_health)
	move	$5,$17
	jal	STlib_updatePercent
	addiu	$4,$4,%lo(w_health)

	lui	$4,%hi(w_armor)
	move	$5,$17
	jal	STlib_updatePercent
	addiu	$4,$4,%lo(w_armor)

	lui	$16,%hi(w_arms)
	lui	$4,%hi(w_armsbg)
	move	$5,$17
	addiu	$4,$4,%lo(w_armsbg)
	jal	STlib_updateBinIcon
	addiu	$16,$16,%lo(w_arms)

	addiu	$18,$16,168
$L266:
	move	$4,$16
	move	$5,$17
	jal	STlib_updateMultIcon
	addiu	$16,$16,28

	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L266
	.set	at
	lui	$4,%hi(w_faces)

	move	$5,$17
	jal	STlib_updateMultIcon
	addiu	$4,$4,%lo(w_faces)

	lui	$4,%hi(w_keyboxes)
	move	$5,$17
	jal	STlib_updateMultIcon
	addiu	$4,$4,%lo(w_keyboxes)

	lui	$4,%hi(w_keyboxes+28)
	move	$5,$17
	jal	STlib_updateMultIcon
	addiu	$4,$4,%lo(w_keyboxes+28)

	lui	$4,%hi(w_keyboxes+56)
	move	$5,$17
	jal	STlib_updateMultIcon
	addiu	$4,$4,%lo(w_keyboxes+56)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$16,20($sp)
	move	$5,$17
	lui	$4,%hi(w_frags)
	lw	$17,24($sp)
	addiu	$4,$4,%lo(w_frags)
	j	STlib_updateNum
	addiu	$sp,$sp,40

$L267:
	b	$L264
	move	$6,$0

	.set	macro
	.set	reorder
	.end	ST_drawWidgets
	.size	ST_drawWidgets, .-ST_drawWidgets
	.align	2
	.globl	ST_doRefresh
	.set	nomips16
	.set	nomicromips
	.ent	ST_doRefresh
	.type	ST_doRefresh, @function
ST_doRefresh:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(st_statusbaron)
	lw	$2,%lo(st_statusbaron)($2)
	lui	$3,%hi(st_firsttime)
	bne	$2,$0,$L281
	sw	$0,%lo(st_firsttime)($3)

	j	ST_drawWidgets
	li	$4,1			# 0x1

$L281:
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	ST_refreshBackground.part.0
	nop

	lw	$31,20($sp)
	li	$4,1			# 0x1
	j	ST_drawWidgets
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_doRefresh
	.size	ST_doRefresh, .-ST_doRefresh
	.align	2
	.globl	ST_diffDraw
	.set	nomips16
	.set	nomicromips
	.ent	ST_diffDraw
	.type	ST_diffDraw, @function
ST_diffDraw:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	ST_drawWidgets
	move	$4,$0

	.set	macro
	.set	reorder
	.end	ST_diffDraw
	.size	ST_diffDraw, .-ST_diffDraw
	.align	2
	.globl	ST_Drawer
	.set	nomips16
	.set	nomicromips
	.ent	ST_Drawer
	.type	ST_Drawer, @function
ST_Drawer:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	sw	$17,24($sp)
	beq	$4,$0,$L287
	sw	$16,20($sp)

	lui	$2,%hi(automapactive)
	lw	$2,%lo(automapactive)($2)
	sltu	$2,$0,$2
$L284:
	lui	$16,%hi(st_firsttime)
	lw	$3,%lo(st_firsttime)($16)
	lui	$17,%hi(st_statusbaron)
	or	$5,$5,$3
	sltu	$5,$0,$5
	sw	$2,%lo(st_statusbaron)($17)
	jal	ST_doPaletteStuff
	sw	$5,%lo(st_firsttime)($16)

	lw	$2,%lo(st_firsttime)($16)
	beq	$2,$0,$L285
	lw	$31,28($sp)

	lw	$2,%lo(st_statusbaron)($17)
	bne	$2,$0,$L293
	sw	$0,%lo(st_firsttime)($16)

	lw	$31,28($sp)
$L294:
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$4,1			# 0x1
	j	ST_drawWidgets
	addiu	$sp,$sp,32

$L285:
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$0
	j	ST_drawWidgets
	addiu	$sp,$sp,32

$L287:
	b	$L284
	li	$2,1			# 0x1

$L293:
	jal	ST_refreshBackground.part.0
	nop

	b	$L294
	lw	$31,28($sp)

	.set	macro
	.set	reorder
	.end	ST_Drawer
	.size	ST_Drawer, .-ST_Drawer
	.align	2
	.globl	ST_loadGraphics
	.set	nomips16
	.set	nomicromips
	.ent	ST_loadGraphics
	.type	ST_loadGraphics, @function
ST_loadGraphics:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(ST_loadCallback)
	j	ST_loadUnloadGraphics
	addiu	$4,$4,%lo(ST_loadCallback)

	.set	macro
	.set	reorder
	.end	ST_loadGraphics
	.size	ST_loadGraphics, .-ST_loadGraphics
	.section	.rodata.str1.4
	.align	2
$LC29:
	.ascii	"PLAYPAL\000"
	.text
	.align	2
	.globl	ST_loadData
	.set	nomips16
	.set	nomicromips
	.ent	ST_loadData
	.type	ST_loadData, @function
ST_loadData:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC29)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	W_GetNumForName
	addiu	$4,$4,%lo($LC29)

	lw	$31,20($sp)
	lui	$4,%hi(ST_loadCallback)
	lui	$3,%hi(lu_palette)
	addiu	$4,$4,%lo(ST_loadCallback)
	addiu	$sp,$sp,24
	j	ST_loadUnloadGraphics
	sw	$2,%lo(lu_palette)($3)

	.set	macro
	.set	reorder
	.end	ST_loadData
	.size	ST_loadData, .-ST_loadData
	.align	2
	.globl	ST_unloadGraphics
	.set	nomips16
	.set	nomicromips
	.ent	ST_unloadGraphics
	.type	ST_unloadGraphics, @function
ST_unloadGraphics:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(ST_unloadCallback)
	j	ST_loadUnloadGraphics
	addiu	$4,$4,%lo(ST_unloadCallback)

	.set	macro
	.set	reorder
	.end	ST_unloadGraphics
	.size	ST_unloadGraphics, .-ST_unloadGraphics
	.align	2
	.globl	ST_unloadData
	.set	nomips16
	.set	nomicromips
	.ent	ST_unloadData
	.type	ST_unloadData, @function
ST_unloadData:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(ST_unloadCallback)
	j	ST_loadUnloadGraphics
	addiu	$4,$4,%lo(ST_unloadCallback)

	.set	macro
	.set	reorder
	.end	ST_unloadData
	.size	ST_unloadData, .-ST_unloadData
	.align	2
	.globl	ST_initData
	.set	nomips16
	.set	nomicromips
	.ent	ST_initData
	.type	ST_initData, @function
ST_initData:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(consoleplayer)
	lw	$3,%lo(consoleplayer)($2)
	li	$6,1			# 0x1
	sll	$2,$3,3
	addu	$2,$2,$3
	lui	$3,%hi(players)
	sll	$2,$2,5
	addiu	$3,$3,%lo(players)
	lui	$7,%hi(st_firsttime)
	addu	$8,$3,$2
	sw	$6,%lo(st_firsttime)($7)
	lui	$7,%hi(plyr)
	sw	$8,%lo(plyr)($7)
	lui	$7,%hi(st_clock)
	sw	$0,%lo(st_clock)($7)
	lui	$7,%hi(st_statusbaron)
	sw	$6,%lo(st_statusbaron)($7)
	lui	$6,%hi(st_oldchat)
	sw	$0,%lo(st_oldchat)($6)
	lui	$6,%hi(st_faceindex)
	li	$5,-1			# 0xffffffffffffffff
	addiu	$4,$2,128
	sw	$0,%lo(st_faceindex)($6)
	lui	$2,%hi(oldweaponsowned)
	lui	$6,%hi(st_palette)
	sw	$5,%lo(st_palette)($6)
	addiu	$2,$2,%lo(oldweaponsowned)
	lui	$6,%hi(st_oldhealth)
	sw	$5,%lo(st_oldhealth)($6)
	addu	$3,$3,$4
	addiu	$5,$2,36
$L301:
	lw	$4,0($3)
	addiu	$2,$2,4
	addiu	$3,$3,4
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L301
	.set	at
	sw	$4,-4($2)

	lui	$4,%hi(keyboxes)
	li	$2,-1			# 0xffffffffffffffff
	addiu	$3,$4,%lo(keyboxes)
	sw	$2,%lo(keyboxes)($4)
	sw	$2,4($3)
	j	STlib_init
	sw	$2,8($3)

	.set	macro
	.set	reorder
	.end	ST_initData
	.size	ST_initData, .-ST_initData
	.align	2
	.globl	ST_createWidgets
	.set	nomips16
	.set	nomicromips
	.ent	ST_createWidgets
	.type	ST_createWidgets, @function
ST_createWidgets:
	.frame	$sp,80,$31		# vars= 8, regs= 10/0, args= 32, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	sw	$17,44($sp)
	sw	$16,40($sp)
	lui	$17,%hi(plyr)
	lui	$16,%hi(st_statusbaron)
	lw	$3,%lo(plyr)($17)
	addiu	$16,$16,%lo(st_statusbaron)
	li	$2,3			# 0x3
	sw	$2,24($sp)
	sw	$16,20($sp)
	lw	$4,120($3)
	sw	$19,52($sp)
	sll	$2,$4,1
	addu	$2,$2,$4
	lui	$4,%hi(weaponinfo)
	addiu	$4,$4,%lo(weaponinfo)
	sll	$2,$2,3
	addu	$2,$2,$4
	lw	$2,0($2)
	lui	$19,%hi(tallnum)
	addiu	$2,$2,41
	sll	$2,$2,2
	addu	$3,$3,$2
	sw	$18,48($sp)
	lui	$18,%hi(w_ready)
	addiu	$7,$19,%lo(tallnum)
	addiu	$4,$18,%lo(w_ready)
	sw	$3,16($sp)
	li	$6,171			# 0xab
	li	$5,44			# 0x2c
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$22,64($sp)
	sw	$21,60($sp)
	sw	$20,56($sp)
	jal	STlib_initNum
	sw	$19,32($sp)

	lw	$2,%lo(plyr)($17)
	lui	$3,%hi(tallpercent)
	lw	$4,%lo(tallpercent)($3)
	sw	$3,36($sp)
	lw	$3,120($2)
	addiu	$18,$18,%lo(w_ready)
	addiu	$2,$2,40
	sw	$4,24($sp)
	lui	$4,%hi(w_health)
	sw	$2,16($sp)
	addiu	$7,$19,%lo(tallnum)
	sw	$16,20($sp)
	li	$6,171			# 0xab
	sw	$3,28($18)
	li	$5,90			# 0x5a
	jal	STlib_initPercent
	addiu	$4,$4,%lo(w_health)

	lui	$2,%hi(armsbg)
	lw	$7,%lo(armsbg)($2)
	lui	$2,%hi(st_notdeathmatch)
	addiu	$2,$2,%lo(st_notdeathmatch)
	lui	$4,%hi(w_armsbg)
	addiu	$4,$4,%lo(w_armsbg)
	sw	$16,20($sp)
	sw	$2,16($sp)
	li	$6,168			# 0xa8
	jal	STlib_initBinIcon
	li	$5,104			# 0x68

	lui	$fp,%hi(arms)
	lui	$4,%hi(w_arms)
	lui	$19,%hi(st_armson)
	li	$18,-1431699456			# 0xffffffffaaaa0000
	addiu	$21,$4,%lo(w_arms)
	addiu	$fp,$fp,%lo(arms)
	li	$22,132			# 0x84
	move	$23,$0
	addiu	$19,$19,%lo(st_armson)
	ori	$18,$18,0xaaab
	li	$20,6			# 0x6
$L304:
	multu	$23,$18
	lw	$7,%lo(plyr)($17)
	mfhi	$2
	move	$4,$21
	srl	$2,$2,1
	sll	$3,$2,1
	addu	$3,$3,$2
	subu	$3,$23,$3
	sll	$5,$3,1
	sll	$6,$2,2
	addu	$5,$5,$3
	addu	$6,$6,$2
	sll	$5,$5,2
	addu	$2,$7,$22
	sll	$6,$6,1
	move	$7,$fp
	sw	$19,20($sp)
	sw	$2,16($sp)
	addiu	$6,$6,172
	addiu	$5,$5,111
	jal	STlib_initMultIcon
	addiu	$23,$23,1

	addiu	$22,$22,4
	addiu	$21,$21,28
	.set	noat
	xor	$1,$23,$20
	bne	$1,$0,$L304
	.set	at
	addiu	$fp,$fp,8

	li	$2,2			# 0x2
	sw	$2,24($sp)
	lui	$2,%hi(st_fragson)
	addiu	$2,$2,%lo(st_fragson)
	lw	$18,32($sp)
	sw	$2,20($sp)
	lui	$2,%hi(st_fragscount)
	addiu	$2,$2,%lo(st_fragscount)
	lui	$4,%hi(w_frags)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(tallnum)
	li	$6,171			# 0xab
	li	$5,138			# 0x8a
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_frags)

	lui	$2,%hi(st_faceindex)
	addiu	$2,$2,%lo(st_faceindex)
	lui	$7,%hi(faces)
	lui	$4,%hi(w_faces)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$7,%lo(faces)
	li	$6,168			# 0xa8
	li	$5,143			# 0x8f
	jal	STlib_initMultIcon
	addiu	$4,$4,%lo(w_faces)

	lw	$3,36($sp)
	lw	$2,%lo(plyr)($17)
	lw	$3,%lo(tallpercent)($3)
	addiu	$2,$2,44
	lui	$4,%hi(w_armor)
	sw	$3,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(tallnum)
	li	$6,171			# 0xab
	li	$5,221			# 0xdd
	jal	STlib_initPercent
	addiu	$4,$4,%lo(w_armor)

	lui	$2,%hi(keyboxes)
	lui	$18,%hi(keys)
	addiu	$2,$2,%lo(keyboxes)
	lui	$4,%hi(w_keyboxes)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(keys)
	li	$6,171			# 0xab
	li	$5,239			# 0xef
	jal	STlib_initMultIcon
	addiu	$4,$4,%lo(w_keyboxes)

	lui	$2,%hi(keyboxes+4)
	addiu	$2,$2,%lo(keyboxes+4)
	lui	$4,%hi(w_keyboxes+28)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(keys)
	li	$6,181			# 0xb5
	li	$5,239			# 0xef
	jal	STlib_initMultIcon
	addiu	$4,$4,%lo(w_keyboxes+28)

	lui	$2,%hi(keyboxes+8)
	addiu	$2,$2,%lo(keyboxes+8)
	lui	$4,%hi(w_keyboxes+56)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(keys)
	li	$6,191			# 0xbf
	li	$5,239			# 0xef
	jal	STlib_initMultIcon
	addiu	$4,$4,%lo(w_keyboxes+56)

	lw	$2,%lo(plyr)($17)
	li	$19,3			# 0x3
	lui	$18,%hi(shortnum)
	addiu	$2,$2,164
	lui	$4,%hi(w_ammo)
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,173			# 0xad
	li	$5,288			# 0x120
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_ammo)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_ammo+32)
	addiu	$2,$2,168
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,179			# 0xb3
	li	$5,288			# 0x120
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_ammo+32)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_ammo+64)
	addiu	$2,$2,172
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,191			# 0xbf
	li	$5,288			# 0x120
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_ammo+64)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_ammo+96)
	addiu	$2,$2,176
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,185			# 0xb9
	li	$5,288			# 0x120
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_ammo+96)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_maxammo)
	addiu	$2,$2,180
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,173			# 0xad
	li	$5,314			# 0x13a
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_maxammo)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_maxammo+32)
	addiu	$2,$2,184
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,179			# 0xb3
	li	$5,314			# 0x13a
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_maxammo+32)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_maxammo+64)
	addiu	$2,$2,188
	addiu	$7,$18,%lo(shortnum)
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	li	$6,191			# 0xbf
	li	$5,314			# 0x13a
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_maxammo+64)

	lw	$2,%lo(plyr)($17)
	lui	$4,%hi(w_maxammo+96)
	addiu	$2,$2,192
	sw	$19,24($sp)
	sw	$16,20($sp)
	sw	$2,16($sp)
	addiu	$7,$18,%lo(shortnum)
	li	$6,185			# 0xb9
	li	$5,314			# 0x13a
	jal	STlib_initNum
	addiu	$4,$4,%lo(w_maxammo+96)

	lw	$31,76($sp)
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$22,64($sp)
	lw	$21,60($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	jr	$31
	addiu	$sp,$sp,80

	.set	macro
	.set	reorder
	.end	ST_createWidgets
	.size	ST_createWidgets, .-ST_createWidgets
	.align	2
	.globl	ST_Start
	.set	nomips16
	.set	nomicromips
	.ent	ST_Start
	.type	ST_Start, @function
ST_Start:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(st_stopped)
	lw	$2,%lo(st_stopped)($16)
	beq	$2,$0,$L310
	sw	$31,20($sp)

	jal	ST_initData
	nop

	jal	ST_createWidgets
	nop

	lw	$31,20($sp)
	sw	$0,%lo(st_stopped)($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L310:
	lui	$2,%hi(lu_palette)
	lw	$4,%lo(lu_palette)($2)
	jal	W_CacheLumpNum
	li	$5,8			# 0x8

	jal	I_SetPalette
	move	$4,$2

	li	$2,1			# 0x1
	jal	ST_initData
	sw	$2,%lo(st_stopped)($16)

	jal	ST_createWidgets
	nop

	lw	$31,20($sp)
	sw	$0,%lo(st_stopped)($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_Start
	.size	ST_Start, .-ST_Start
	.align	2
	.globl	ST_Stop
	.set	nomips16
	.set	nomicromips
	.ent	ST_Stop
	.type	ST_Stop, @function
ST_Stop:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	lui	$16,%hi(st_stopped)
	lw	$2,%lo(st_stopped)($16)
	bne	$2,$0,$L311
	sw	$31,20($sp)

	lui	$2,%hi(lu_palette)
	lw	$4,%lo(lu_palette)($2)
	jal	W_CacheLumpNum
	li	$5,8			# 0x8

	jal	I_SetPalette
	move	$4,$2

	li	$2,1			# 0x1
	sw	$2,%lo(st_stopped)($16)
$L311:
	lw	$31,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_Stop
	.size	ST_Stop, .-ST_Stop
	.align	2
	.globl	ST_Init
	.set	nomips16
	.set	nomicromips
	.ent	ST_Init
	.type	ST_Init, @function
ST_Init:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC29)
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	W_GetNumForName
	addiu	$4,$4,%lo($LC29)

	lui	$4,%hi(ST_loadCallback)
	lui	$3,%hi(lu_palette)
	addiu	$4,$4,%lo(ST_loadCallback)
	jal	ST_loadUnloadGraphics
	sw	$2,%lo(lu_palette)($3)

	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,10240			# 0x2800

	lw	$31,20($sp)
	lui	$3,%hi(st_backing_screen)
	sw	$2,%lo(st_backing_screen)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	ST_Init
	.size	ST_Init, .-ST_Init
	.data
	.align	2
	.type	largeammo.0, @object
	.size	largeammo.0, 4
largeammo.0:
	.word	1994
	.align	2
	.type	lastattackdown.1, @object
	.size	lastattackdown.1, 4
lastattackdown.1:
	.word	-1
	.local	priority.2
	.comm	priority.2,4,4
	.local	lastcalc.3
	.comm	lastcalc.3,4,4
	.align	2
	.type	oldhealth.4, @object
	.size	oldhealth.4, 4
oldhealth.4:
	.word	-1
	.local	buf.5
	.comm	buf.5,52,4
	.align	2
	.type	st_stopped, @object
	.size	st_stopped, 4
st_stopped:
	.word	1
	.local	st_palette
	.comm	st_palette,4,4
	.globl	cheat_mypos
	.align	2
	.type	cheat_mypos, @object
	.size	cheat_mypos, 52
cheat_mypos:
	.ascii	"idmypos\000"
	.space	17
	.space	3
	.word	7
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_clev
	.align	2
	.type	cheat_clev, @object
	.size	cheat_clev, 52
cheat_clev:
	.ascii	"idclev\000"
	.space	18
	.space	3
	.word	6
	.word	2
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_choppers
	.align	2
	.type	cheat_choppers, @object
	.size	cheat_choppers, 52
cheat_choppers:
	.ascii	"idchoppers\000"
	.space	14
	.space	3
	.word	10
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_powerup
	.align	2
	.type	cheat_powerup, @object
	.size	cheat_powerup, 364
cheat_powerup:
	.ascii	"idbeholdv\000"
	.space	15
	.space	3
	.word	9
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.ascii	"idbeholds\000"
	.space	15
	.space	3
	.word	9
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.ascii	"idbeholdi\000"
	.space	15
	.space	3
	.word	9
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.ascii	"idbeholdr\000"
	.space	15
	.space	3
	.word	9
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.ascii	"idbeholda\000"
	.space	15
	.space	3
	.word	9
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.ascii	"idbeholdl\000"
	.space	15
	.space	3
	.word	9
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.ascii	"idbehold\000"
	.space	16
	.space	3
	.word	8
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_commercial_noclip
	.align	2
	.type	cheat_commercial_noclip, @object
	.size	cheat_commercial_noclip, 52
cheat_commercial_noclip:
	.ascii	"idclip\000"
	.space	18
	.space	3
	.word	6
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_noclip
	.align	2
	.type	cheat_noclip, @object
	.size	cheat_noclip, 52
cheat_noclip:
	.ascii	"idspispopd\000"
	.space	14
	.space	3
	.word	10
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_ammonokey
	.align	2
	.type	cheat_ammonokey, @object
	.size	cheat_ammonokey, 52
cheat_ammonokey:
	.ascii	"idfa\000"
	.space	20
	.space	3
	.word	4
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_ammo
	.align	2
	.type	cheat_ammo, @object
	.size	cheat_ammo, 52
cheat_ammo:
	.ascii	"idkfa\000"
	.space	19
	.space	3
	.word	5
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_god
	.align	2
	.type	cheat_god, @object
	.size	cheat_god, 52
cheat_god:
	.ascii	"iddqd\000"
	.space	19
	.space	3
	.word	5
	.word	0
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.globl	cheat_mus
	.align	2
	.type	cheat_mus, @object
	.size	cheat_mus, 52
cheat_mus:
	.ascii	"idmus\000"
	.space	19
	.space	3
	.word	5
	.word	2
	.word	0
	.word	0
	.ascii	"\000"
	.space	4
	.space	3
	.local	st_randomnumber
	.comm	st_randomnumber,4,4
	.local	keyboxes
	.comm	keyboxes,12,4
	.local	st_faceindex
	.comm	st_faceindex,4,4
	.local	st_facecount
	.comm	st_facecount,4,4
	.local	oldweaponsowned
	.comm	oldweaponsowned,36,4
	.align	2
	.type	st_oldhealth, @object
	.size	st_oldhealth, 4
st_oldhealth:
	.word	-1
	.local	st_fragscount
	.comm	st_fragscount,4,4
	.local	w_maxammo
	.comm	w_maxammo,128,4
	.local	w_ammo
	.comm	w_ammo,128,4
	.local	w_armor
	.comm	w_armor,36,4
	.local	w_keyboxes
	.comm	w_keyboxes,84,4
	.local	w_faces
	.comm	w_faces,28,4
	.local	w_arms
	.comm	w_arms,168,4
	.local	w_armsbg
	.comm	w_armsbg,28,4
	.local	w_health
	.comm	w_health,36,4
	.local	w_frags
	.comm	w_frags,32,4
	.local	w_ready
	.comm	w_ready,32,4
	.local	arms
	.comm	arms,48,4
	.local	armsbg
	.comm	armsbg,4,4
	.local	faceback
	.comm	faceback,4,4
	.local	faces
	.comm	faces,168,4
	.local	keys
	.comm	keys,24,4
	.local	shortnum
	.comm	shortnum,40,4
	.local	tallpercent
	.comm	tallpercent,4,4
	.local	tallnum
	.comm	tallnum,40,4
	.local	sbar
	.comm	sbar,4,4
	.local	st_fragson
	.comm	st_fragson,4,4
	.local	st_armson
	.comm	st_armson,4,4
	.local	st_notdeathmatch
	.comm	st_notdeathmatch,4,4
	.local	st_oldchat
	.comm	st_oldchat,4,4
	.local	st_statusbaron
	.comm	st_statusbaron,4,4
	.local	st_msgcounter
	.comm	st_msgcounter,4,4
	.local	st_clock
	.comm	st_clock,4,4
	.local	lu_palette
	.comm	lu_palette,4,4
	.local	st_firsttime
	.comm	st_firsttime,4,4
	.local	plyr
	.comm	plyr,4,4
	.globl	st_backing_screen
	.section	.bss,"aw",@nobits
	.align	2
	.type	st_backing_screen, @object
	.size	st_backing_screen, 4
st_backing_screen:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
