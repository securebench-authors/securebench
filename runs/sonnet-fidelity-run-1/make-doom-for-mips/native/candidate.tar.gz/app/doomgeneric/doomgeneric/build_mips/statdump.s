	.file	1 "statdump.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"-statdump\000"
	.text
	.align	2
	.globl	StatCopy
	.set	nomips16
	.set	nomicromips
	.ent	StatCopy
	.type	StatCopy, @function
StatCopy:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,20($sp)
	move	$16,$4
	lui	$4,%hi($LC0)
	addiu	$4,$4,%lo($LC0)
	sw	$31,28($sp)
	jal	M_ParmExists
	sw	$17,24($sp)

	beq	$2,$0,$L9
	lw	$31,28($sp)

	lui	$17,%hi(num_captured_stats)
	lw	$3,%lo(num_captured_stats)($17)
	slt	$2,$3,32
	bne	$2,$0,$L8
	sll	$2,$3,1

$L9:
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L8:
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	lui	$4,%hi(captured_stats)
	sll	$2,$2,3
	addiu	$4,$4,%lo(captured_stats)
	move	$5,$16
	li	$6,200			# 0xc8
	jal	memcpy
	addu	$4,$4,$2

	lw	$2,%lo(num_captured_stats)($17)
	lw	$31,28($sp)
	addiu	$2,$2,1
	lw	$16,20($sp)
	sw	$2,%lo(num_captured_stats)($17)
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	StatCopy
	.size	StatCopy, .-StatCopy
	.align	2
	.globl	StatDump
	.set	nomips16
	.set	nomicromips
	.ent	StatDump
	.type	StatDump, @function
StatDump:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	StatDump
	.size	StatDump, .-StatDump
	.local	num_captured_stats
	.comm	num_captured_stats,4,4
	.local	captured_stats
	.comm	captured_stats,6400,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
