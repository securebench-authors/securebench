	.file	1 "v_video.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	V_MarkRect
	.set	nomips16
	.set	nomicromips
	.ent	V_MarkRect
	.type	V_MarkRect, @function
V_MarkRect:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_screen)
	lw	$3,%lo(dest_screen)($2)
	lui	$2,%hi(I_VideoBuffer)
	lw	$2,%lo(I_VideoBuffer)($2)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L7
	.set	at
	nop

	jr	$31
	nop

$L7:
	addiu	$sp,$sp,-48
	sw	$19,40($sp)
	lui	$19,%hi(dirtybox)
	sw	$18,36($sp)
	sw	$17,32($sp)
	sw	$16,28($sp)
	move	$17,$5
	move	$16,$4
	move	$18,$6
	move	$6,$5
	move	$5,$4
	addiu	$4,$19,%lo(dirtybox)
	sw	$31,44($sp)
	jal	M_AddToBox
	sw	$7,16($sp)

	lw	$7,16($sp)
	addu	$5,$16,$18
	lw	$31,44($sp)
	lw	$18,36($sp)
	lw	$16,28($sp)
	addu	$7,$17,$7
	addiu	$4,$19,%lo(dirtybox)
	lw	$17,32($sp)
	lw	$19,40($sp)
	addiu	$6,$7,-1
	addiu	$5,$5,-1
	j	M_AddToBox
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	V_MarkRect
	.size	V_MarkRect, .-V_MarkRect
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Bad V_CopyRect\000"
	.text
	.align	2
	.globl	V_CopyRect
	.set	nomips16
	.set	nomicromips
	.ent	V_CopyRect
	.type	V_CopyRect, @function
V_CopyRect:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$21,36($sp)
	sw	$20,32($sp)
	lw	$21,80($sp)
	lw	$20,76($sp)
	sw	$23,44($sp)
	or	$2,$20,$21
	or	$2,$2,$5
	or	$2,$2,$4
	sw	$22,40($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	lw	$18,72($sp)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$16,16($sp)
	move	$22,$5
	move	$23,$4
	move	$17,$6
	bltz	$2,$L9
	move	$19,$7

	addu	$2,$4,$7
	slt	$2,$2,321
	bne	$2,$0,$L18
	addu	$2,$5,$18

$L9:
	lui	$4,%hi($LC0)
$L20:
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

	lui	$fp,%hi(dest_screen)
$L21:
	lui	$2,%hi(I_VideoBuffer)
	lw	$16,%lo(dest_screen)($fp)
	lw	$2,%lo(I_VideoBuffer)($2)
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L19
	.set	at
	move	$6,$21

$L11:
	sll	$3,$22,2
	sll	$2,$21,2
	addu	$3,$3,$22
	addu	$2,$2,$21
	sll	$3,$3,6
	sll	$2,$2,6
	addu	$4,$3,$23
	addu	$2,$2,$20
	addu	$17,$17,$4
	blez	$18,$L8
	addu	$16,$16,$2

$L13:
	move	$5,$17
	move	$4,$16
	move	$6,$19
	jal	memcpy
	addiu	$18,$18,-1

	addiu	$17,$17,320
	bne	$18,$0,$L13
	addiu	$16,$16,320

$L8:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L18:
	slt	$2,$2,201
	beq	$2,$0,$L20
	lui	$4,%hi($LC0)

	addu	$2,$7,$20
	slt	$2,$2,321
	beq	$2,$0,$L20
	addu	$2,$18,$21

	slt	$2,$2,201
	bne	$2,$0,$L21
	lui	$fp,%hi(dest_screen)

	b	$L20
	nop

$L19:
	lui	$16,%hi(dirtybox)
	addiu	$4,$16,%lo(dirtybox)
	jal	M_AddToBox
	move	$5,$20

	addu	$6,$18,$21
	addu	$5,$19,$20
	addiu	$4,$16,%lo(dirtybox)
	addiu	$6,$6,-1
	jal	M_AddToBox
	addiu	$5,$5,-1

	b	$L11
	lw	$16,%lo(dest_screen)($fp)

	.set	macro
	.set	reorder
	.end	V_CopyRect
	.size	V_CopyRect, .-V_CopyRect
	.align	2
	.globl	V_SetPatchClipCallback
	.set	nomips16
	.set	nomicromips
	.ent	V_SetPatchClipCallback
	.type	V_SetPatchClipCallback, @function
V_SetPatchClipCallback:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(patchclip_callback)
	jr	$31
	sw	$4,%lo(patchclip_callback)($2)

	.set	macro
	.set	reorder
	.end	V_SetPatchClipCallback
	.size	V_SetPatchClipCallback, .-V_SetPatchClipCallback
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Bad V_DrawPatch x=%i y=%i patch.width=%i patch.height=%i"
	.ascii	" topoffset=%i leftoffset=%i\000"
	.text
	.align	2
	.globl	V_DrawPatch
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawPatch
	.type	V_DrawPatch, @function
V_DrawPatch:
	.frame	$sp,72,$31		# vars= 8, regs= 7/0, args= 32, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	sw	$19,56($sp)
	sw	$18,52($sp)
	sw	$16,44($sp)
	sw	$31,68($sp)
	sw	$21,64($sp)
	sw	$20,60($sp)
	sw	$17,48($sp)
	lbu	$3,7($6)
	lbu	$2,5($6)
	lbu	$7,6($6)
	move	$16,$6
	lbu	$6,4($6)
	sll	$3,$3,8
	sll	$2,$2,8
	or	$3,$3,$7
	or	$2,$2,$6
	lui	$6,%hi(patchclip_callback)
	sll	$3,$3,16
	sll	$2,$2,16
	lw	$7,%lo(patchclip_callback)($6)
	sra	$3,$3,16
	sra	$2,$2,16
	subu	$19,$5,$3
	beq	$7,$0,$L27
	subu	$18,$4,$2

	move	$6,$19
	move	$5,$18
	jalr	$7
	move	$4,$16

	beq	$2,$0,$L48
	lw	$31,68($sp)

$L27:
	lbu	$7,1($16)
	lbu	$17,3($16)
	lbu	$2,2($16)
	lbu	$3,0($16)
	sll	$7,$7,8
	sll	$17,$17,8
	or	$17,$17,$2
	or	$7,$7,$3
	sll	$7,$7,16
	sll	$17,$17,16
	or	$2,$19,$18
	sra	$7,$7,16
	bltz	$2,$L25
	sra	$17,$17,16

	addu	$2,$18,$7
	slt	$2,$2,321
	bne	$2,$0,$L45
	addu	$2,$19,$17

$L25:
	lbu	$3,5($16)
$L47:
	lbu	$2,7($16)
	lbu	$5,4($16)
	lbu	$4,6($16)
	sll	$3,$3,8
	sll	$2,$2,8
	or	$3,$3,$5
	or	$2,$2,$4
	sll	$3,$3,16
	sll	$2,$2,16
	sra	$3,$3,16
	sra	$2,$2,16
	lui	$4,%hi($LC1)
	sw	$17,16($sp)
	sw	$3,24($sp)
	sw	$2,20($sp)
	move	$6,$19
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC1)

	lbu	$7,1($16)
	lbu	$17,3($16)
	lbu	$3,0($16)
	lbu	$2,2($16)
	sll	$7,$7,8
	sll	$17,$17,8
	or	$7,$7,$3
	or	$17,$17,$2
	sll	$7,$7,16
	sll	$17,$17,16
	sra	$7,$7,16
	sra	$17,$17,16
	lui	$20,%hi(dest_screen)
$L49:
	lui	$2,%hi(I_VideoBuffer)
	lw	$11,%lo(dest_screen)($20)
	lw	$2,%lo(I_VideoBuffer)($2)
	.set	noat
	xor	$1,$11,$2
	beq	$1,$0,$L46
	.set	at
	lui	$21,%hi(dirtybox)

$L29:
	sll	$2,$19,2
	addu	$2,$2,$19
	sll	$2,$2,6
	addu	$2,$2,$18
	blez	$7,$L23
	addu	$11,$11,$2

	move	$6,$0
	li	$9,255			# 0xff
$L32:
	addiu	$2,$6,2
	sll	$2,$2,2
	addu	$2,$16,$2
	lwl	$8,3($2)
	lwr	$8,0($2)
	addu	$8,$16,$8
	lbu	$2,0($8)
	.set	noat
	xor	$1,$2,$9
	beq	$1,$0,$L35
	.set	at
	addu	$10,$11,$6

$L31:
	sll	$3,$2,2
	addu	$3,$3,$2
	lbu	$4,1($8)
	sll	$3,$3,6
	addiu	$2,$8,3
	beq	$4,$0,$L33
	addu	$3,$10,$3

	addiu	$4,$4,3
	addu	$4,$8,$4
$L34:
	lbu	$5,0($2)
	addiu	$2,$2,1
	sb	$5,0($3)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L34
	.set	at
	addiu	$3,$3,320

	lbu	$4,1($8)
$L33:
	addiu	$4,$4,4
	addu	$8,$8,$4
	lbu	$2,0($8)
	.set	noat
	xor	$1,$2,$9
	bne	$1,$0,$L31
	.set	at
	nop

$L35:
	addiu	$6,$6,1
	.set	noat
	xor	$1,$6,$7
	bne	$1,$0,$L32
	.set	at
	nop

$L23:
	lw	$31,68($sp)
$L48:
	lw	$21,64($sp)
	lw	$20,60($sp)
	lw	$19,56($sp)
	lw	$18,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	jr	$31
	addiu	$sp,$sp,72

$L45:
	slt	$2,$2,201
	bne	$2,$0,$L49
	lui	$20,%hi(dest_screen)

	b	$L47
	lbu	$3,5($16)

$L46:
	move	$6,$19
	move	$5,$18
	addiu	$4,$21,%lo(dirtybox)
	jal	M_AddToBox
	sw	$7,32($sp)

	lw	$7,32($sp)
	addu	$6,$19,$17
	addu	$5,$18,$7
	addiu	$6,$6,-1
	addiu	$5,$5,-1
	jal	M_AddToBox
	addiu	$4,$21,%lo(dirtybox)

	lbu	$7,1($16)
	lbu	$2,0($16)
	sll	$7,$7,8
	or	$7,$7,$2
	sll	$7,$7,16
	lw	$11,%lo(dest_screen)($20)
	b	$L29
	sra	$7,$7,16

	.set	macro
	.set	reorder
	.end	V_DrawPatch
	.size	V_DrawPatch, .-V_DrawPatch
	.section	.rodata.str1.4
	.align	2
$LC2:
	.ascii	"Bad V_DrawPatchFlipped\000"
	.text
	.align	2
	.globl	V_DrawPatchFlipped
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawPatchFlipped
	.type	V_DrawPatchFlipped, @function
V_DrawPatchFlipped:
	.frame	$sp,56,$31		# vars= 8, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$19,40($sp)
	sw	$18,36($sp)
	sw	$16,28($sp)
	sw	$31,52($sp)
	sw	$21,48($sp)
	sw	$20,44($sp)
	sw	$17,32($sp)
	lbu	$3,7($6)
	lbu	$2,5($6)
	lbu	$7,6($6)
	move	$16,$6
	lbu	$6,4($6)
	sll	$3,$3,8
	sll	$2,$2,8
	or	$3,$3,$7
	or	$2,$2,$6
	lui	$6,%hi(patchclip_callback)
	sll	$3,$3,16
	sll	$2,$2,16
	lw	$7,%lo(patchclip_callback)($6)
	sra	$3,$3,16
	sra	$2,$2,16
	subu	$19,$5,$3
	beq	$7,$0,$L54
	subu	$18,$4,$2

	move	$6,$19
	move	$5,$18
	jalr	$7
	move	$4,$16

	beq	$2,$0,$L75
	lw	$31,52($sp)

$L54:
	bltz	$18,$L52
	nop

	lbu	$9,1($16)
	lbu	$2,0($16)
	sll	$9,$9,8
	or	$9,$9,$2
	sll	$9,$9,16
	sra	$9,$9,16
	addu	$2,$9,$18
	slt	$2,$2,321
	bne	$2,$0,$L72
	nop

$L52:
	lui	$4,%hi($LC2)
$L74:
	jal	I_Error
	addiu	$4,$4,%lo($LC2)

	lbu	$9,1($16)
	lbu	$17,3($16)
	lbu	$3,0($16)
	lbu	$2,2($16)
	sll	$9,$9,8
	sll	$17,$17,8
	or	$9,$9,$3
	or	$17,$17,$2
	sll	$9,$9,16
	sll	$17,$17,16
	sra	$9,$9,16
	sra	$17,$17,16
	lui	$20,%hi(dest_screen)
$L76:
	lui	$3,%hi(I_VideoBuffer)
	lw	$2,%lo(dest_screen)($20)
	lw	$3,%lo(I_VideoBuffer)($3)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L73
	.set	at
	lui	$21,%hi(dirtybox)

$L56:
	sll	$3,$19,2
	addu	$3,$3,$19
	sll	$3,$3,6
	addu	$3,$3,$18
	blez	$9,$L50
	addu	$2,$2,$3

	addu	$9,$2,$9
	move	$8,$2
	addiu	$10,$9,-1
	li	$6,255			# 0xff
$L59:
	subu	$2,$10,$8
	addiu	$2,$2,2
	sll	$2,$2,2
	addu	$2,$16,$2
	lwl	$7,3($2)
	lwr	$7,0($2)
	addu	$7,$16,$7
	lbu	$2,0($7)
	.set	noat
	xor	$1,$2,$6
	beq	$1,$0,$L62
	.set	at
	nop

$L58:
	sll	$3,$2,2
	addu	$3,$3,$2
	lbu	$4,1($7)
	sll	$3,$3,6
	addiu	$2,$7,3
	beq	$4,$0,$L60
	addu	$3,$8,$3

	addiu	$4,$4,3
	addu	$4,$7,$4
$L61:
	lbu	$5,0($2)
	addiu	$2,$2,1
	sb	$5,0($3)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L61
	.set	at
	addiu	$3,$3,320

	lbu	$4,1($7)
$L60:
	addiu	$4,$4,4
	addu	$7,$7,$4
	lbu	$2,0($7)
	.set	noat
	xor	$1,$2,$6
	bne	$1,$0,$L58
	.set	at
	nop

$L62:
	addiu	$8,$8,1
	.set	noat
	xor	$1,$8,$9
	bne	$1,$0,$L59
	.set	at
	nop

$L50:
	lw	$31,52($sp)
$L75:
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,56

$L72:
	bltz	$19,$L74
	lui	$4,%hi($LC2)

	lbu	$17,3($16)
	lbu	$2,2($16)
	sll	$17,$17,8
	or	$17,$17,$2
	sll	$17,$17,16
	sra	$17,$17,16
	addu	$2,$17,$19
	slt	$2,$2,201
	bne	$2,$0,$L76
	lui	$20,%hi(dest_screen)

	b	$L74
	nop

$L73:
	move	$6,$19
	move	$5,$18
	addiu	$4,$21,%lo(dirtybox)
	jal	M_AddToBox
	sw	$9,16($sp)

	lw	$9,16($sp)
	addu	$6,$19,$17
	addu	$9,$18,$9
	addiu	$5,$9,-1
	addiu	$6,$6,-1
	jal	M_AddToBox
	addiu	$4,$21,%lo(dirtybox)

	lbu	$9,1($16)
	lbu	$2,0($16)
	sll	$9,$9,8
	or	$9,$9,$2
	sll	$9,$9,16
	lw	$2,%lo(dest_screen)($20)
	b	$L56
	sra	$9,$9,16

	.set	macro
	.set	reorder
	.end	V_DrawPatchFlipped
	.size	V_DrawPatchFlipped, .-V_DrawPatchFlipped
	.align	2
	.globl	V_DrawPatchDirect
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawPatchDirect
	.type	V_DrawPatchDirect, @function
V_DrawPatchDirect:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	V_DrawPatch
	nop

	.set	macro
	.set	reorder
	.end	V_DrawPatchDirect
	.size	V_DrawPatchDirect, .-V_DrawPatchDirect
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"Bad V_DrawTLPatch\000"
	.text
	.align	2
	.globl	V_DrawTLPatch
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawTLPatch
	.type	V_DrawTLPatch, @function
V_DrawTLPatch:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	lbu	$3,5($6)
	lbu	$2,7($6)
	lbu	$7,4($6)
	move	$16,$6
	sll	$3,$3,8
	lbu	$6,6($6)
	sll	$2,$2,8
	or	$3,$3,$7
	or	$2,$2,$6
	sll	$3,$3,16
	sra	$3,$3,16
	sll	$2,$2,16
	sra	$2,$2,16
	subu	$18,$4,$3
	bltz	$18,$L79
	subu	$17,$5,$2

	lbu	$13,1($16)
	lbu	$2,0($16)
	sll	$13,$13,8
	or	$13,$13,$2
	sll	$13,$13,16
	sra	$13,$13,16
	addu	$2,$13,$18
	slt	$2,$2,321
	bne	$2,$0,$L97
	nop

$L79:
	lui	$4,%hi($LC3)
$L98:
	jal	I_Error
	addiu	$4,$4,%lo($LC3)

	lbu	$13,1($16)
	lbu	$2,0($16)
	sll	$13,$13,8
	or	$13,$13,$2
	sll	$13,$13,16
	sra	$13,$13,16
	sll	$2,$17,2
$L99:
	addu	$2,$2,$17
	lui	$3,%hi(dest_screen)
	lw	$14,%lo(dest_screen)($3)
	sll	$2,$2,6
	addu	$2,$2,$18
	addu	$14,$14,$2
	blez	$13,$L78
	move	$12,$0

	li	$10,255			# 0xff
	lui	$8,%hi(tinttable)
$L81:
	addiu	$2,$12,2
	sll	$2,$2,2
	addu	$2,$16,$2
	lwl	$9,3($2)
	lwr	$9,0($2)
	addu	$9,$16,$9
	lbu	$2,0($9)
	.set	noat
	xor	$1,$2,$10
	beq	$1,$0,$L86
	.set	at
	addu	$11,$14,$12

$L82:
	sll	$3,$2,2
	addu	$3,$3,$2
	lbu	$6,1($9)
	sll	$3,$3,6
	addiu	$4,$9,3
	beq	$6,$0,$L84
	addu	$3,$11,$3

	addiu	$6,$6,3
	addu	$6,$9,$6
$L85:
	lbu	$5,0($3)
	lw	$2,%lo(tinttable)($8)
	lbu	$7,0($4)
	sll	$5,$5,8
	addu	$2,$2,$5
	addu	$2,$2,$7
	lbu	$2,0($2)
	addiu	$4,$4,1
	sb	$2,0($3)
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L85
	.set	at
	addiu	$3,$3,320

	lbu	$6,1($9)
$L84:
	addiu	$6,$6,4
	addu	$9,$9,$6
	lbu	$2,0($9)
	.set	noat
	xor	$1,$2,$10
	bne	$1,$0,$L82
	.set	at
	nop

$L86:
	addiu	$12,$12,1
	.set	noat
	xor	$1,$12,$13
	bne	$1,$0,$L81
	.set	at
	nop

$L78:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L97:
	bltz	$17,$L98
	lui	$4,%hi($LC3)

	lbu	$2,3($16)
	lbu	$3,2($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$17
	slt	$2,$2,201
	bne	$2,$0,$L99
	sll	$2,$17,2

	b	$L98
	nop

	.set	macro
	.set	reorder
	.end	V_DrawTLPatch
	.size	V_DrawTLPatch, .-V_DrawTLPatch
	.align	2
	.globl	V_DrawXlaPatch
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawXlaPatch
	.type	V_DrawXlaPatch, @function
V_DrawXlaPatch:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	lbu	$3,7($6)
	lbu	$2,5($6)
	lbu	$7,6($6)
	move	$16,$6
	lbu	$6,4($6)
	sll	$3,$3,8
	sll	$2,$2,8
	or	$3,$3,$7
	or	$2,$2,$6
	lui	$6,%hi(patchclip_callback)
	sll	$3,$3,16
	sll	$2,$2,16
	lw	$7,%lo(patchclip_callback)($6)
	sra	$3,$3,16
	sra	$2,$2,16
	subu	$18,$5,$3
	beq	$7,$0,$L104
	subu	$17,$4,$2

	move	$6,$18
	move	$5,$17
	jalr	$7
	move	$4,$16

	beq	$2,$0,$L119
	lw	$31,28($sp)

$L104:
	lbu	$3,1($16)
	lbu	$4,0($16)
	sll	$13,$3,8
	sll	$2,$18,2
	addu	$2,$2,$18
	lui	$3,%hi(dest_screen)
	or	$13,$13,$4
	lw	$14,%lo(dest_screen)($3)
	sll	$2,$2,6
	sll	$13,$13,16
	addu	$2,$2,$17
	sra	$13,$13,16
	addu	$14,$14,$2
	blez	$13,$L100
	move	$12,$0

	li	$11,255			# 0xff
	lui	$9,%hi(xlatab)
$L102:
	addiu	$2,$12,2
	sll	$2,$2,2
	addu	$2,$16,$2
	lwl	$10,3($2)
	lwr	$10,0($2)
	addu	$10,$16,$10
	lbu	$2,0($10)
	.set	noat
	xor	$1,$2,$11
	beq	$1,$0,$L108
	.set	at
	addu	$6,$14,$12

$L105:
	sll	$3,$2,2
	addu	$3,$3,$2
	lbu	$7,1($10)
	sll	$3,$3,6
	addiu	$4,$10,3
	beq	$7,$0,$L106
	addu	$3,$6,$3

	addiu	$7,$7,3
	addu	$7,$10,$7
$L107:
	lbu	$5,0($4)
	lw	$2,%lo(xlatab)($9)
	lbu	$8,0($3)
	sll	$5,$5,8
	addu	$2,$2,$5
	addu	$2,$2,$8
	lbu	$2,0($2)
	addiu	$4,$4,1
	sb	$2,0($3)
	.set	noat
	xor	$1,$4,$7
	bne	$1,$0,$L107
	.set	at
	addiu	$3,$3,320

	lbu	$7,1($10)
$L106:
	addiu	$7,$7,4
	addu	$10,$10,$7
	lbu	$2,0($10)
	.set	noat
	xor	$1,$2,$11
	bne	$1,$0,$L105
	.set	at
	nop

$L108:
	addiu	$12,$12,1
	.set	noat
	xor	$1,$13,$12
	bne	$1,$0,$L102
	.set	at
	nop

$L100:
	lw	$31,28($sp)
$L119:
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	V_DrawXlaPatch
	.size	V_DrawXlaPatch, .-V_DrawXlaPatch
	.section	.rodata.str1.4
	.align	2
$LC4:
	.ascii	"Bad V_DrawAltTLPatch\000"
	.text
	.align	2
	.globl	V_DrawAltTLPatch
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawAltTLPatch
	.type	V_DrawAltTLPatch, @function
V_DrawAltTLPatch:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	lbu	$3,5($6)
	lbu	$2,7($6)
	lbu	$7,4($6)
	move	$16,$6
	sll	$3,$3,8
	lbu	$6,6($6)
	sll	$2,$2,8
	or	$3,$3,$7
	or	$2,$2,$6
	sll	$3,$3,16
	sra	$3,$3,16
	sll	$2,$2,16
	sra	$2,$2,16
	subu	$18,$4,$3
	bltz	$18,$L121
	subu	$17,$5,$2

	lbu	$13,1($16)
	lbu	$2,0($16)
	sll	$13,$13,8
	or	$13,$13,$2
	sll	$13,$13,16
	sra	$13,$13,16
	addu	$2,$13,$18
	slt	$2,$2,321
	bne	$2,$0,$L139
	nop

$L121:
	lui	$4,%hi($LC4)
$L140:
	jal	I_Error
	addiu	$4,$4,%lo($LC4)

	lbu	$13,1($16)
	lbu	$2,0($16)
	sll	$13,$13,8
	or	$13,$13,$2
	sll	$13,$13,16
	sra	$13,$13,16
	sll	$2,$17,2
$L141:
	addu	$2,$2,$17
	lui	$3,%hi(dest_screen)
	lw	$14,%lo(dest_screen)($3)
	sll	$2,$2,6
	addu	$2,$2,$18
	addu	$14,$14,$2
	blez	$13,$L120
	move	$12,$0

	li	$10,255			# 0xff
	lui	$8,%hi(tinttable)
$L123:
	addiu	$2,$12,2
	sll	$2,$2,2
	addu	$2,$16,$2
	lwl	$9,3($2)
	lwr	$9,0($2)
	addu	$9,$16,$9
	lbu	$2,0($9)
	.set	noat
	xor	$1,$2,$10
	beq	$1,$0,$L128
	.set	at
	addu	$11,$14,$12

$L124:
	sll	$3,$2,2
	addu	$3,$3,$2
	lbu	$6,1($9)
	sll	$3,$3,6
	addiu	$4,$9,3
	beq	$6,$0,$L126
	addu	$3,$11,$3

	addiu	$6,$6,3
	addu	$6,$9,$6
$L127:
	lbu	$5,0($3)
	lw	$2,%lo(tinttable)($8)
	lbu	$7,0($4)
	sll	$5,$5,8
	addu	$2,$2,$5
	addu	$2,$2,$7
	lbu	$2,0($2)
	addiu	$4,$4,1
	sb	$2,0($3)
	.set	noat
	xor	$1,$4,$6
	bne	$1,$0,$L127
	.set	at
	addiu	$3,$3,320

	lbu	$6,1($9)
$L126:
	addiu	$6,$6,4
	addu	$9,$9,$6
	lbu	$2,0($9)
	.set	noat
	xor	$1,$2,$10
	bne	$1,$0,$L124
	.set	at
	nop

$L128:
	addiu	$12,$12,1
	.set	noat
	xor	$1,$12,$13
	bne	$1,$0,$L123
	.set	at
	nop

$L120:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L139:
	bltz	$17,$L140
	lui	$4,%hi($LC4)

	lbu	$2,3($16)
	lbu	$3,2($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$17
	slt	$2,$2,201
	bne	$2,$0,$L141
	sll	$2,$17,2

	b	$L140
	nop

	.set	macro
	.set	reorder
	.end	V_DrawAltTLPatch
	.size	V_DrawAltTLPatch, .-V_DrawAltTLPatch
	.section	.rodata.str1.4
	.align	2
$LC5:
	.ascii	"Bad V_DrawShadowedPatch\000"
	.text
	.align	2
	.globl	V_DrawShadowedPatch
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawShadowedPatch
	.type	V_DrawShadowedPatch, @function
V_DrawShadowedPatch:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	lbu	$3,5($6)
	lbu	$2,7($6)
	lbu	$7,4($6)
	move	$16,$6
	sll	$3,$3,8
	lbu	$6,6($6)
	sll	$2,$2,8
	or	$3,$3,$7
	or	$2,$2,$6
	sll	$3,$3,16
	sra	$3,$3,16
	sll	$2,$2,16
	sra	$2,$2,16
	subu	$17,$4,$3
	bltz	$17,$L143
	subu	$18,$5,$2

	lbu	$14,1($16)
	lbu	$2,0($16)
	sll	$14,$14,8
	or	$14,$14,$2
	sll	$14,$14,16
	sra	$14,$14,16
	addu	$2,$14,$17
	slt	$2,$2,321
	bne	$2,$0,$L161
	nop

$L143:
	lui	$4,%hi($LC5)
$L162:
	jal	I_Error
	addiu	$4,$4,%lo($LC5)

	lbu	$14,1($16)
	lbu	$2,0($16)
	sll	$14,$14,8
	or	$14,$14,$2
	sll	$14,$14,16
	sra	$14,$14,16
	sll	$2,$18,2
$L163:
	addu	$2,$2,$18
	sll	$2,$2,6
	lui	$3,%hi(dest_screen)
	lw	$24,%lo(dest_screen)($3)
	addu	$3,$17,$2
	move	$2,$3
	addiu	$3,$3,642
	addu	$15,$24,$2
	move	$13,$0
	blez	$14,$L142
	addu	$24,$24,$3

	li	$10,255			# 0xff
	lui	$8,%hi(tinttable)
$L145:
	addiu	$2,$13,2
	sll	$2,$2,2
	addu	$2,$16,$2
	lwl	$9,3($2)
	addu	$12,$24,$13
	lwr	$9,0($2)
	addu	$9,$16,$9
	lbu	$3,0($9)
	.set	noat
	xor	$1,$3,$10
	beq	$1,$0,$L150
	.set	at
	addu	$11,$15,$13

$L146:
	sll	$2,$3,2
	addu	$2,$2,$3
	lbu	$7,1($9)
	sll	$2,$2,6
	addu	$6,$11,$2
	addiu	$3,$9,3
	beq	$7,$0,$L148
	addu	$2,$12,$2

	addiu	$7,$7,3
	addu	$7,$9,$7
$L149:
	lbu	$5,0($2)
	lw	$4,%lo(tinttable)($8)
	sll	$5,$5,8
	addu	$4,$4,$5
	lbu	$4,0($4)
	addiu	$3,$3,1
	sb	$4,0($2)
	lbu	$4,-1($3)
	addiu	$2,$2,320
	sb	$4,0($6)
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L149
	.set	at
	addiu	$6,$6,320

	lbu	$7,1($9)
$L148:
	addiu	$7,$7,4
	addu	$9,$9,$7
	lbu	$3,0($9)
	.set	noat
	xor	$1,$3,$10
	bne	$1,$0,$L146
	.set	at
	nop

$L150:
	addiu	$13,$13,1
	.set	noat
	xor	$1,$13,$14
	bne	$1,$0,$L145
	.set	at
	nop

$L142:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L161:
	bltz	$18,$L162
	lui	$4,%hi($LC5)

	lbu	$2,3($16)
	lbu	$3,2($16)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$18
	slt	$2,$2,201
	bne	$2,$0,$L163
	sll	$2,$18,2

	b	$L162
	nop

	.set	macro
	.set	reorder
	.end	V_DrawShadowedPatch
	.size	V_DrawShadowedPatch, .-V_DrawShadowedPatch
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"TINTTAB\000"
	.text
	.align	2
	.globl	V_LoadTintTable
	.set	nomips16
	.set	nomicromips
	.ent	V_LoadTintTable
	.type	V_LoadTintTable, @function
V_LoadTintTable:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC6)
	addiu	$sp,$sp,-24
	li	$5,1			# 0x1
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC6)

	lw	$31,20($sp)
	lui	$3,%hi(tinttable)
	sw	$2,%lo(tinttable)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	V_LoadTintTable
	.size	V_LoadTintTable, .-V_LoadTintTable
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"XLATAB\000"
	.text
	.align	2
	.globl	V_LoadXlaTable
	.set	nomips16
	.set	nomicromips
	.ent	V_LoadXlaTable
	.type	V_LoadXlaTable, @function
V_LoadXlaTable:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC7)
	addiu	$sp,$sp,-24
	li	$5,1			# 0x1
	sw	$31,20($sp)
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC7)

	lw	$31,20($sp)
	lui	$3,%hi(xlatab)
	sw	$2,%lo(xlatab)($3)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	V_LoadXlaTable
	.size	V_LoadXlaTable, .-V_LoadXlaTable
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"Bad V_DrawBlock\000"
	.text
	.align	2
	.globl	V_DrawBlock
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawBlock
	.type	V_DrawBlock, @function
V_DrawBlock:
	.frame	$sp,48,$31		# vars= 0, regs= 8/0, args= 16, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	or	$2,$4,$5
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	lw	$18,64($sp)
	sw	$31,44($sp)
	sw	$22,40($sp)
	sw	$17,20($sp)
	move	$21,$4
	move	$20,$5
	move	$19,$6
	bltz	$2,$L169
	move	$16,$7

	addu	$2,$4,$6
	slt	$2,$2,321
	bne	$2,$0,$L179
	addu	$2,$5,$7

$L169:
	lui	$4,%hi($LC8)
$L181:
	jal	I_Error
	addiu	$4,$4,%lo($LC8)

	lui	$22,%hi(dest_screen)
	lui	$2,%hi(I_VideoBuffer)
	lw	$17,%lo(dest_screen)($22)
	lw	$2,%lo(I_VideoBuffer)($2)
	.set	noat
	xor	$1,$17,$2
	beq	$1,$0,$L180
	.set	at
	nop

$L171:
	sll	$2,$20,2
$L182:
	addu	$2,$2,$20
	sll	$2,$2,6
	addu	$2,$2,$21
	beq	$16,$0,$L168
	addu	$17,$17,$2

$L173:
	move	$5,$18
	move	$4,$17
	move	$6,$19
	jal	memcpy
	addiu	$16,$16,-1

	addu	$18,$18,$19
	bne	$16,$0,$L173
	addiu	$17,$17,320

$L168:
	lw	$31,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,48

$L179:
	slt	$2,$2,201
	beq	$2,$0,$L181
	lui	$4,%hi($LC8)

	lui	$22,%hi(dest_screen)
	lui	$2,%hi(I_VideoBuffer)
	lw	$17,%lo(dest_screen)($22)
	lw	$2,%lo(I_VideoBuffer)($2)
	.set	noat
	xor	$1,$17,$2
	bne	$1,$0,$L182
	.set	at
	sll	$2,$20,2

$L180:
	lui	$17,%hi(dirtybox)
	addiu	$4,$17,%lo(dirtybox)
	move	$6,$20
	jal	M_AddToBox
	move	$5,$21

	addu	$6,$20,$16
	addu	$5,$21,$19
	addiu	$4,$17,%lo(dirtybox)
	addiu	$6,$6,-1
	jal	M_AddToBox
	addiu	$5,$5,-1

	b	$L171
	lw	$17,%lo(dest_screen)($22)

	.set	macro
	.set	reorder
	.end	V_DrawBlock
	.size	V_DrawBlock, .-V_DrawBlock
	.align	2
	.globl	V_DrawFilledBox
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawFilledBox
	.type	V_DrawFilledBox, @function
V_DrawFilledBox:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$5,2
	addu	$2,$2,$5
	lui	$3,%hi(I_VideoBuffer)
	lw	$5,%lo(I_VideoBuffer)($3)
	sll	$2,$2,6
	addu	$2,$2,$4
	blez	$7,$L190
	addu	$5,$5,$2

	lbu	$4,16($sp)
	addu	$3,$5,$6
	move	$8,$0
$L185:
	blez	$6,$L188
	move	$2,$5

$L186:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L186
	.set	at
	sb	$4,-1($2)

$L188:
	addiu	$8,$8,1
	addiu	$5,$5,320
	.set	noat
	xor	$1,$7,$8
	bne	$1,$0,$L185
	.set	at
	addiu	$3,$3,320

$L190:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	V_DrawFilledBox
	.size	V_DrawFilledBox, .-V_DrawFilledBox
	.align	2
	.globl	V_DrawHorizLine
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawHorizLine
	.type	V_DrawHorizLine, @function
V_DrawHorizLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$5,2
	addu	$5,$2,$5
	lui	$2,%hi(I_VideoBuffer)
	lw	$2,%lo(I_VideoBuffer)($2)
	sll	$5,$5,6
	addu	$5,$5,$4
	blez	$6,$L196
	addu	$4,$2,$5

	andi	$7,$7,0x00ff
	addu	$6,$4,$6
$L193:
	addiu	$4,$4,1
	.set	noat
	xor	$1,$6,$4
	bne	$1,$0,$L193
	.set	at
	sb	$7,-1($4)

$L196:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	V_DrawHorizLine
	.size	V_DrawHorizLine, .-V_DrawHorizLine
	.align	2
	.globl	V_DrawVertLine
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawVertLine
	.type	V_DrawVertLine, @function
V_DrawVertLine:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$2,$5,2
	addu	$5,$2,$5
	lui	$2,%hi(I_VideoBuffer)
	lw	$2,%lo(I_VideoBuffer)($2)
	sll	$5,$5,6
	addu	$5,$5,$4
	blez	$6,$L202
	addu	$4,$2,$5

	andi	$7,$7,0x00ff
	move	$2,$0
$L199:
	addiu	$2,$2,1
	sb	$7,0($4)
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L199
	.set	at
	addiu	$4,$4,320

$L202:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	V_DrawVertLine
	.size	V_DrawVertLine, .-V_DrawVertLine
	.align	2
	.globl	V_DrawBox
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawBox
	.type	V_DrawBox, @function
V_DrawBox:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	sll	$9,$5,2
	addu	$9,$9,$5
	lui	$10,%hi(I_VideoBuffer)
	lw	$2,%lo(I_VideoBuffer)($10)
	sll	$9,$9,6
	addu	$11,$9,$4
	blez	$6,$L204
	addu	$2,$2,$11

	lw	$3,16($sp)
	addu	$8,$2,$6
	andi	$3,$3,0x00ff
$L205:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L205
	.set	at
	sb	$3,-1($2)

	addu	$5,$5,$7
	addiu	$5,$5,-1
	sll	$2,$5,2
	addu	$5,$2,$5
	sll	$5,$5,6
	lw	$2,%lo(I_VideoBuffer)($10)
	addu	$5,$5,$4
	addu	$2,$2,$5
	addu	$5,$2,$6
$L206:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$5,$2
	bne	$1,$0,$L206
	.set	at
	sb	$3,-1($2)

	lw	$2,%lo(I_VideoBuffer)($10)
	addu	$2,$2,$11
$L204:
	blez	$7,$L215
	lw	$3,16($sp)

	andi	$8,$3,0x00ff
	move	$3,$0
$L208:
	move	$5,$3
	addiu	$3,$3,1
	sb	$8,0($2)
	.set	noat
	xor	$1,$7,$3
	bne	$1,$0,$L208
	.set	at
	addiu	$2,$2,320

	addu	$4,$4,$6
	lw	$2,%lo(I_VideoBuffer)($10)
	addiu	$4,$4,-1
	addu	$4,$4,$9
	addu	$2,$2,$4
	move	$3,$0
$L209:
	move	$4,$3
	sb	$8,0($2)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L209
	.set	at
	addiu	$2,$2,320

$L215:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	V_DrawBox
	.size	V_DrawBox, .-V_DrawBox
	.align	2
	.globl	V_DrawRawScreen
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawRawScreen
	.type	V_DrawRawScreen, @function
V_DrawRawScreen:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_screen)
	move	$5,$4
	lw	$4,%lo(dest_screen)($2)
	j	memcpy
	li	$6,64000			# 0xfa00

	.set	macro
	.set	reorder
	.end	V_DrawRawScreen
	.size	V_DrawRawScreen, .-V_DrawRawScreen
	.align	2
	.globl	V_Init
	.set	nomips16
	.set	nomicromips
	.ent	V_Init
	.type	V_Init, @function
V_Init:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	V_Init
	.size	V_Init, .-V_Init
	.align	2
	.globl	V_UseBuffer
	.set	nomips16
	.set	nomicromips
	.ent	V_UseBuffer
	.type	V_UseBuffer, @function
V_UseBuffer:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(dest_screen)
	jr	$31
	sw	$4,%lo(dest_screen)($2)

	.set	macro
	.set	reorder
	.end	V_UseBuffer
	.size	V_UseBuffer, .-V_UseBuffer
	.align	2
	.globl	V_RestoreBuffer
	.set	nomips16
	.set	nomicromips
	.ent	V_RestoreBuffer
	.type	V_RestoreBuffer, @function
V_RestoreBuffer:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(I_VideoBuffer)
	lw	$3,%lo(I_VideoBuffer)($2)
	lui	$2,%hi(dest_screen)
	jr	$31
	sw	$3,%lo(dest_screen)($2)

	.set	macro
	.set	reorder
	.end	V_RestoreBuffer
	.size	V_RestoreBuffer, .-V_RestoreBuffer
	.align	2
	.globl	WritePCXfile
	.set	nomips16
	.set	nomicromips
	.ent	WritePCXfile
	.type	WritePCXfile, @function
WritePCXfile:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$20,36($sp)
	multu	$6,$7
	mflo	$20
	sw	$19,32($sp)
	move	$19,$4
	addiu	$4,$20,500
	sw	$22,44($sp)
	sw	$21,40($sp)
	move	$22,$7
	move	$21,$6
	sw	$17,24($sp)
	move	$6,$0
	sll	$4,$4,1
	move	$17,$5
	li	$5,1			# 0x1
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$18,28($sp)
	sw	$16,20($sp)
	jal	Z_Malloc
	lw	$16,72($sp)

	andi	$4,$22,0xffff
	andi	$3,$21,0xffff
	move	$18,$2
	addiu	$7,$4,-1
	addiu	$8,$3,-1
	andi	$22,$3,0xff
	srl	$21,$3,8
	li	$3,10			# 0xa
	andi	$5,$7,0xffff
	andi	$6,$8,0xffff
	sb	$3,0($18)
	li	$3,5			# 0x5
	srl	$2,$4,8
	li	$23,1			# 0x1
	srl	$6,$6,8
	srl	$5,$5,8
	sb	$3,1($18)
	li	$3,8			# 0x8
	sb	$7,10($18)
	sb	$3,3($18)
	sb	$8,8($18)
	sb	$6,9($18)
	sb	$5,11($18)
	sb	$4,14($18)
	li	$6,48			# 0x30
	move	$5,$0
	addiu	$4,$18,16
	sb	$23,2($18)
	sb	$22,12($18)
	sb	$21,13($18)
	sb	$2,15($18)
	sb	$0,4($18)
	sb	$0,5($18)
	sb	$0,6($18)
	jal	memset
	sb	$0,7($18)

	li	$2,2			# 0x2
	sb	$23,65($18)
	sb	$22,66($18)
	sb	$21,67($18)
	sb	$2,68($18)
	sb	$0,69($18)
	li	$6,58			# 0x3a
	move	$5,$0
	jal	memset
	addiu	$4,$18,70

	blez	$20,$L221
	addiu	$7,$18,128

	addu	$4,$17,$20
	li	$6,-64			# 0xffffffffffffffc0
	li	$5,192			# 0xc0
	b	$L224
	li	$8,-63			# 0xffffffffffffffc1

$L229:
	sb	$2,0($7)
	.set	noat
	xor	$1,$4,$17
	beq	$1,$0,$L221
	.set	at
	addiu	$7,$7,1

$L224:
	lbu	$2,0($17)
	and	$3,$2,$6
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L229
	.set	at
	addiu	$17,$17,1

	sb	$8,0($7)
	lbu	$2,-1($17)
	addiu	$7,$7,2
	.set	noat
	xor	$1,$4,$17
	bne	$1,$0,$L224
	.set	at
	sb	$2,-1($7)

$L221:
	li	$2,12			# 0xc
	addiu	$3,$7,1
	sb	$2,0($7)
	addiu	$6,$16,768
$L225:
	lbu	$5,0($16)
	addiu	$16,$16,1
	addiu	$3,$3,1
	.set	noat
	xor	$1,$16,$6
	bne	$1,$0,$L225
	.set	at
	sb	$5,-1($3)

	addiu	$6,$7,769
	move	$4,$19
	subu	$6,$6,$18
	jal	M_WriteFile
	move	$5,$18

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$4,$18
	lw	$18,28($sp)
	j	Z_Free
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	WritePCXfile
	.size	WritePCXfile, .-WritePCXfile
	.section	.rodata.str1.4
	.align	2
$LC9:
	.ascii	"pcx\000"
	.align	2
$LC10:
	.ascii	"V_ScreenShot: Couldn't create a PCX\000"
	.align	2
$LC11:
	.ascii	"PLAYPAL\000"
	.text
	.align	2
	.globl	V_ScreenShot
	.set	nomips16
	.set	nomicromips
	.ent	V_ScreenShot
	.type	V_ScreenShot, @function
V_ScreenShot:
	.frame	$sp,64,$31		# vars= 16, regs= 5/0, args= 24, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$17,48($sp)
	lui	$17,%hi($LC9)
	sw	$19,56($sp)
	sw	$18,52($sp)
	sw	$16,44($sp)
	sw	$31,60($sp)
	move	$18,$4
	move	$16,$0
	addiu	$17,$17,%lo($LC9)
	b	$L232
	li	$19,100			# 0x64

$L239:
	.set	noat
	xor	$1,$16,$19
	beq	$1,$0,$L238
	.set	at
	nop

$L232:
	move	$7,$16
	move	$6,$18
	li	$5,16			# 0x10
	addiu	$4,$sp,24
	jal	M_snprintf
	sw	$17,16($sp)

	jal	M_FileExists
	addiu	$4,$sp,24

	bne	$2,$0,$L239
	addiu	$16,$16,1

	lui	$2,%hi(I_VideoBuffer)
$L240:
	lui	$4,%hi($LC11)
	lw	$16,%lo(I_VideoBuffer)($2)
	li	$5,8			# 0x8
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC11)

	sw	$2,16($sp)
	move	$5,$16
	addiu	$4,$sp,24
	li	$7,200			# 0xc8
	jal	WritePCXfile
	li	$6,320			# 0x140

	lw	$31,60($sp)
	lw	$19,56($sp)
	lw	$18,52($sp)
	lw	$17,48($sp)
	lw	$16,44($sp)
	jr	$31
	addiu	$sp,$sp,64

$L238:
	lui	$4,%hi($LC10)
	jal	I_Error
	addiu	$4,$4,%lo($LC10)

	b	$L240
	lui	$2,%hi(I_VideoBuffer)

	.set	macro
	.set	reorder
	.end	V_ScreenShot
	.size	V_ScreenShot, .-V_ScreenShot
	.globl	__subsf3
	.globl	__extendsfdf2
	.globl	__ltdf2
	.globl	__floatsisf
	.globl	__divsf3
	.globl	__fixsfsi
	.align	2
	.globl	V_DrawMouseSpeedBox
	.set	nomips16
	.set	nomicromips
	.ent	V_DrawMouseSpeedBox
	.type	V_DrawMouseSpeedBox, @function
V_DrawMouseSpeedBox:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	li	$6,119			# 0x77
	li	$5,119			# 0x77
	sw	$20,32($sp)
	move	$20,$4
	li	$4,119			# 0x77
	sw	$31,52($sp)
	sw	$22,40($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	jal	I_GetPaletteIndex
	sw	$21,36($sp)

	li	$6,85			# 0x55
	li	$5,85			# 0x55
	li	$4,85			# 0x55
	jal	I_GetPaletteIndex
	move	$22,$2

	move	$6,$0
	move	$5,$0
	li	$4,255			# 0xff
	jal	I_GetPaletteIndex
	move	$16,$2

	move	$6,$0
	move	$5,$0
	move	$4,$0
	jal	I_GetPaletteIndex
	move	$17,$2

	move	$6,$0
	li	$5,255			# 0xff
	li	$4,255			# 0xff
	jal	I_GetPaletteIndex
	move	$18,$2

	li	$6,255			# 0xff
	li	$5,255			# 0xff
	li	$4,255			# 0xff
	jal	I_GetPaletteIndex
	move	$19,$2

	lui	$3,%hi(usemouse)
	lw	$3,%lo(usemouse)($3)
	bne	$3,$0,$L271
	move	$23,$2

	lw	$31,52($sp)
$L273:
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L271:
	lui	$21,%hi(mouse_acceleration)
	lui	$2,%hi($LC12)
	lw	$5,%lo($LC12)($2)
	jal	__subsf3
	lw	$4,%lo(mouse_acceleration)($21)

	jal	__extendsfdf2
	move	$4,$2

	move	$4,$2
	jal	fabs
	move	$5,$3

	lui	$4,%hi($LC13)
	lw	$6,%lo($LC13)($4)
	lw	$7,%lo($LC13+4)($4)
	move	$5,$3
	jal	__ltdf2
	move	$4,$2

	bltz	$2,$L273
	lw	$31,52($sp)

	lui	$fp,%hi(I_VideoBuffer)
	lw	$2,%lo(I_VideoBuffer)($fp)
	andi	$6,$22,0x00ff
	addiu	$5,$2,5110
	addiu	$2,$2,7990
	addiu	$3,$5,-120
$L245:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$5
	bne	$1,$0,$L245
	.set	at
	sb	$6,-1($3)

	addiu	$5,$3,320
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L245
	.set	at
	addiu	$3,$5,-120

	lw	$2,%lo(I_VideoBuffer)($fp)
	andi	$16,$16,0x00ff
	addiu	$3,$2,4990
	addiu	$2,$2,5110
$L247:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L247
	.set	at
	sb	$16,-1($3)

	lw	$2,%lo(I_VideoBuffer)($fp)
	addiu	$3,$2,7550
	addiu	$2,$2,7670
$L248:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L248
	.set	at
	sb	$16,-1($3)

	lw	$2,%lo(I_VideoBuffer)($fp)
	addiu	$3,$2,4990
	addiu	$2,$2,7870
$L249:
	sb	$16,0($3)
	addiu	$3,$3,320
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L249
	.set	at
	nop

	lw	$2,%lo(I_VideoBuffer)($fp)
	addiu	$3,$2,5109
	addiu	$2,$2,7989
$L250:
	sb	$16,0($3)
	addiu	$3,$3,320
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L250
	.set	at
	nop

	lui	$2,%hi(mouse_threshold)
	lw	$16,%lo(mouse_threshold)($2)
	slt	$2,$20,$16
	beq	$2,$0,$L272
	nop

$L251:
	sll	$2,$20,2
	addu	$2,$2,$20
	sll	$2,$2,3
	div	$0,$2,$16
	lw	$2,%lo(I_VideoBuffer)($fp)
	li	$5,119			# 0x77
	addiu	$3,$2,6271
	andi	$18,$18,0x00ff
	addiu	$2,$2,6389
	mflo	$6
	slt	$4,$6,120
	movn	$5,$6,$4
$L252:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L252
	.set	at
	sb	$18,-1($3)

	lw	$4,%lo(I_VideoBuffer)($fp)
	slt	$2,$6,40
	beq	$2,$0,$L253
	addiu	$3,$4,6271

	blez	$6,$L254
	li	$2,-6271			# 0xffffffffffffe781

	andi	$23,$23,0x00ff
	subu	$4,$2,$4
$L255:
	addiu	$3,$3,1
	addu	$2,$3,$4
	slt	$2,$2,$5
	bne	$2,$0,$L255
	sb	$23,-1($3)

	lw	$4,%lo(I_VideoBuffer)($fp)
$L254:
	addiu	$2,$4,5350
	andi	$17,$17,0x00ff
	addiu	$3,$4,7590
$L258:
	sb	$17,0($2)
	addiu	$2,$2,320
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L258
	.set	at
	lw	$31,52($sp)

	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L253:
	andi	$23,$23,0x00ff
	addiu	$4,$4,6311
$L256:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L256
	.set	at
	sb	$23,-1($3)

	lw	$4,%lo(I_VideoBuffer)($fp)
	li	$3,40			# 0x28
	.set	noat
	xor	$1,$6,$3
	beq	$1,$0,$L254
	.set	at
	addiu	$2,$4,6310

	addiu	$5,$5,6270
	andi	$19,$19,0x00ff
	addu	$3,$4,$5
$L257:
	addiu	$2,$2,1
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L257
	.set	at
	sb	$19,-1($2)

	b	$L254
	lw	$4,%lo(I_VideoBuffer)($fp)

$L272:
	jal	__floatsisf
	subu	$4,$20,$16

	lw	$5,%lo(mouse_acceleration)($21)
	jal	__divsf3
	move	$4,$2

	jal	__fixsfsi
	move	$4,$2

	b	$L251
	addu	$20,$16,$2

	.set	macro
	.set	reorder
	.end	V_DrawMouseSpeedBox
	.size	V_DrawMouseSpeedBox, .-V_DrawMouseSpeedBox
	.local	patchclip_callback
	.comm	patchclip_callback,4,4
	.globl	dirtybox
	.section	.bss,"aw",@nobits
	.align	2
	.type	dirtybox, @object
	.size	dirtybox, 16
dirtybox:
	.space	16
	.local	dest_screen
	.comm	dest_screen,4,4
	.globl	xlatab
	.align	2
	.type	xlatab, @object
	.size	xlatab, 4
xlatab:
	.space	4
	.globl	tinttable
	.align	2
	.type	tinttable, @object
	.size	tinttable, 4
tinttable:
	.space	4
	.section	.rodata.cst4,"aM",@progbits,4
	.align	2
$LC12:
	.word	1065353216
	.section	.rodata.cst8,"aM",@progbits,8
	.align	3
$LC13:
	.word	1202590843
	.word	1065646817
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
