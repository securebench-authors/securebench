	.file	1 "w_checksum.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	W_Checksum
	.set	nomips16
	.set	nomicromips
	.ent	W_Checksum
	.type	W_Checksum, @function
W_Checksum:
	.frame	$sp,160,$31		# vars= 104, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-160
	sw	$23,148($sp)
	sw	$21,140($sp)
	move	$23,$4
	lui	$21,%hi(numlumps)
	addiu	$4,$sp,16
	sw	$19,132($sp)
	sw	$31,156($sp)
	sw	$fp,152($sp)
	sw	$22,144($sp)
	sw	$20,136($sp)
	sw	$18,128($sp)
	sw	$17,124($sp)
	jal	SHA1_Init
	sw	$16,120($sp)

	lw	$2,%lo(numlumps)($21)
	lui	$19,%hi(num_open_wadfiles)
	beq	$2,$0,$L8
	sw	$0,%lo(num_open_wadfiles)($19)

	move	$18,$0
	move	$17,$0
	lui	$22,%hi(lumpinfo)
	lui	$20,%hi(open_wadfiles)
$L2:
	lw	$16,%lo(lumpinfo)($22)
	li	$6,9			# 0x9
	addu	$16,$16,$18
	move	$5,$16
	jal	M_StringCopy
	addiu	$4,$sp,108

	addiu	$4,$sp,16
	jal	SHA1_UpdateString
	addiu	$5,$sp,108

	lw	$6,%lo(num_open_wadfiles)($19)
	lw	$fp,8($16)
	blez	$6,$L7
	lw	$4,%lo(open_wadfiles)($20)

	move	$5,$0
	b	$L6
	move	$2,$4

$L15:
	addiu	$5,$5,1
	.set	noat
	xor	$1,$5,$6
	beq	$1,$0,$L7
	.set	at
	nop

$L6:
	lw	$3,0($2)
	.set	noat
	xor	$1,$fp,$3
	bne	$1,$0,$L15
	.set	at
	addiu	$2,$2,4

$L5:
	jal	SHA1_UpdateInt32
	addiu	$4,$sp,16

	lw	$5,12($16)
	jal	SHA1_UpdateInt32
	addiu	$4,$sp,16

	lw	$5,16($16)
	jal	SHA1_UpdateInt32
	addiu	$4,$sp,16

	lw	$2,%lo(numlumps)($21)
	addiu	$17,$17,1
	sltu	$2,$17,$2
	bne	$2,$0,$L2
	addiu	$18,$18,28

$L8:
	addiu	$5,$sp,16
	jal	SHA1_Final
	move	$4,$23

	lw	$31,156($sp)
	lw	$fp,152($sp)
	lw	$23,148($sp)
	lw	$22,144($sp)
	lw	$21,140($sp)
	lw	$20,136($sp)
	lw	$19,132($sp)
	lw	$18,128($sp)
	lw	$17,124($sp)
	lw	$16,120($sp)
	jr	$31
	addiu	$sp,$sp,160

$L7:
	addiu	$5,$6,1
	jal	realloc
	sll	$5,$5,2

	lw	$5,%lo(num_open_wadfiles)($19)
	sw	$2,%lo(open_wadfiles)($20)
	sll	$3,$5,2
	addu	$3,$2,$3
	addiu	$4,$5,1
	sw	$fp,0($3)
	b	$L5
	sw	$4,%lo(num_open_wadfiles)($19)

	.set	macro
	.set	reorder
	.end	W_Checksum
	.size	W_Checksum, .-W_Checksum
	.local	num_open_wadfiles
	.comm	num_open_wadfiles,4,4
	.local	open_wadfiles
	.comm	open_wadfiles,4,4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
