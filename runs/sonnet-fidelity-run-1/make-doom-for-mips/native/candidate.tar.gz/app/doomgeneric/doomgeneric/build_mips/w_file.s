	.file	1 "w_file.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"-mmap\000"
	.text
	.align	2
	.globl	W_OpenFile
	.set	nomips16
	.set	nomicromips
	.ent	W_OpenFile
	.type	W_OpenFile, @function
W_OpenFile:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lui	$4,%hi($LC0)
	sw	$31,20($sp)
	jal	M_CheckParm
	addiu	$4,$4,%lo($LC0)

	lui	$2,%hi(stdc_wad_file)
	lw	$31,20($sp)
	move	$4,$16
	lw	$25,%lo(stdc_wad_file)($2)
	lw	$16,16($sp)
	jr	$25
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	W_OpenFile
	.size	W_OpenFile, .-W_OpenFile
	.align	2
	.globl	W_CloseFile
	.set	nomips16
	.set	nomicromips
	.ent	W_CloseFile
	.type	W_CloseFile, @function
W_CloseFile:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	lw	$25,4($2)
	jr	$25
	nop

	.set	macro
	.set	reorder
	.end	W_CloseFile
	.size	W_CloseFile, .-W_CloseFile
	.align	2
	.globl	W_Read
	.set	nomips16
	.set	nomicromips
	.ent	W_Read
	.type	W_Read, @function
W_Read:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	lw	$25,8($2)
	jr	$25
	nop

	.set	macro
	.set	reorder
	.end	W_Read
	.size	W_Read, .-W_Read
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
