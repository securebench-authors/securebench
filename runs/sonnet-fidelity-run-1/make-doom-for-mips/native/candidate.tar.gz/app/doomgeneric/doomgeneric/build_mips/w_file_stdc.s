	.file	1 "w_file_stdc.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	W_StdC_Read
	.set	nomips16
	.set	nomicromips
	.ent	W_StdC_Read
	.type	W_StdC_Read, @function
W_StdC_Read:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,12($4)
	sw	$18,24($sp)
	sw	$17,20($sp)
	move	$18,$7
	move	$17,$6
	sw	$31,28($sp)
	jal	fseek
	move	$6,$0

	lw	$7,12($16)
	lw	$31,28($sp)
	lw	$16,16($sp)
	move	$6,$18
	move	$4,$17
	lw	$18,24($sp)
	lw	$17,20($sp)
	li	$5,1			# 0x1
	j	fread
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_StdC_Read
	.size	W_StdC_Read, .-W_StdC_Read
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	W_StdC_CloseFile
	.type	W_StdC_CloseFile, @function
W_StdC_CloseFile:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$4
	lw	$4,12($4)
	sw	$31,20($sp)
	jal	fclose
	nop

	lw	$31,20($sp)
	move	$4,$16
	lw	$16,16($sp)
	j	Z_Free
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	W_StdC_CloseFile
	.size	W_StdC_CloseFile, .-W_StdC_CloseFile
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"rb\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	W_StdC_OpenFile
	.type	W_StdC_OpenFile, @function
W_StdC_OpenFile:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi($LC0)
	addiu	$sp,$sp,-32
	addiu	$5,$5,%lo($LC0)
	sw	$16,20($sp)
	sw	$31,28($sp)
	jal	fopen
	sw	$17,24($sp)

	beq	$2,$0,$L6
	move	$16,$2

	move	$6,$0
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,16			# 0x10

	move	$17,$2
	lui	$2,%hi(stdc_wad_file)
	addiu	$2,$2,%lo(stdc_wad_file)
	move	$4,$16
	sw	$2,0($17)
	jal	M_FileLength
	sw	$0,4($17)

	sw	$2,8($17)
	sw	$16,12($17)
	move	$16,$17
$L6:
	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$2,$16
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_StdC_OpenFile
	.size	W_StdC_OpenFile, .-W_StdC_OpenFile
	.globl	stdc_wad_file
	.data
	.align	2
	.type	stdc_wad_file, @object
	.size	stdc_wad_file, 12
stdc_wad_file:
	.word	W_StdC_OpenFile
	.word	W_StdC_CloseFile
	.word	W_StdC_Read
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
