	.file	1 "w_main.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"-file\000"
	.align	2
$LC1:
	.ascii	" adding %s\012\000"
	.text
	.align	2
	.globl	W_ParseCommandLine
	.set	nomips16
	.set	nomicromips
	.ent	W_ParseCommandLine
	.type	W_ParseCommandLine, @function
W_ParseCommandLine:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi($LC0)
	addiu	$sp,$sp,-48
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC0)
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	jal	M_CheckParmWithArgs
	sw	$16,20($sp)

	beq	$2,$0,$L6
	lw	$31,44($sp)

	lui	$19,%hi(myargc)
	lw	$3,%lo(myargc)($19)
	addiu	$16,$2,1
	.set	noat
	xor	$1,$16,$3
	beq	$1,$0,$L10
	.set	at
	lui	$18,%hi($LC1)

	lui	$21,%hi(myargv)
	li	$20,45			# 0x2d
	b	$L3
	addiu	$18,$18,%lo($LC1)

$L5:
	jal	D_TryFindWADByName
	nop

	move	$17,$2
	move	$5,$2
	jal	printf
	move	$4,$18

	jal	W_AddFile
	move	$4,$17

	lw	$2,%lo(myargc)($19)
	.set	noat
	xor	$1,$2,$16
	beq	$1,$0,$L10
	.set	at
	lw	$31,44($sp)

$L3:
	lw	$2,%lo(myargv)($21)
	sll	$3,$16,2
	addu	$2,$2,$3
	lw	$4,0($2)
	lb	$2,0($4)
	.set	noat
	xor	$1,$2,$20
	bne	$1,$0,$L5
	.set	at
	addiu	$16,$16,1

	lw	$31,44($sp)
$L10:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	li	$2,1			# 0x1
	jr	$31
	addiu	$sp,$sp,48

$L6:
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	W_ParseCommandLine
	.size	W_ParseCommandLine, .-W_ParseCommandLine
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
