	.file	1 "w_wad.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	W_LumpNameHash
	.set	nomips16
	.set	nomicromips
	.ent	W_LumpNameHash
	.type	W_LumpNameHash, @function
W_LumpNameHash:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	move	$16,$4
	addiu	$18,$4,8
	li	$17,5381			# 0x1505
$L2:
	lb	$4,0($16)
	beq	$4,$0,$L1
	addiu	$16,$16,1

	jal	toupper
	nop

	sll	$3,$17,5
	xor	$3,$3,$2
	.set	noat
	xor	$1,$16,$18
	bne	$1,$0,$L2
	.set	at
	xor	$17,$17,$3

$L1:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$16,16($sp)
	move	$2,$17
	lw	$17,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_LumpNameHash
	.size	W_LumpNameHash, .-W_LumpNameHash
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	" couldn't open %s\012\000"
	.align	2
$LC1:
	.ascii	"wad\000"
	.align	2
$LC2:
	.ascii	"IWAD\000"
	.align	2
$LC3:
	.ascii	"PWAD\000"
	.align	2
$LC4:
	.ascii	"Wad file %s doesn't have IWAD or PWAD id\012\000"
	.align	2
$LC5:
	.ascii	"Couldn't realloc lumpinfo\000"
	.text
	.align	2
	.globl	W_AddFile
	.set	nomips16
	.set	nomicromips
	.ent	W_AddFile
	.type	W_AddFile, @function
W_AddFile:
	.frame	$sp,80,$31		# vars= 24, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-80
	sw	$21,60($sp)
	sw	$16,40($sp)
	sw	$31,76($sp)
	sw	$fp,72($sp)
	sw	$23,68($sp)
	sw	$22,64($sp)
	sw	$20,56($sp)
	sw	$19,52($sp)
	sw	$18,48($sp)
	sw	$17,44($sp)
	jal	W_OpenFile
	move	$16,$4

	beq	$2,$0,$L42
	move	$21,$2

	move	$4,$16
	lui	$20,%hi(numlumps)
	jal	strlen
	lw	$23,%lo(numlumps)($20)

	addiu	$4,$2,-3
	lui	$5,%hi($LC1)
	addiu	$5,$5,%lo($LC1)
	jal	strcasecmp
	addu	$4,$16,$4

	bne	$2,$0,$L43
	move	$6,$0

	addiu	$6,$sp,16
	move	$4,$21
	move	$5,$0
	jal	W_Read
	li	$7,12			# 0xc

	lui	$5,%hi($LC2)
	li	$6,4			# 0x4
	addiu	$5,$5,%lo($LC2)
	jal	strncmp
	addiu	$4,$sp,16

	bne	$2,$0,$L44
	lui	$5,%hi($LC3)

$L13:
	lw	$16,20($sp)
$L48:
	move	$6,$0
	sll	$16,$16,4
	move	$4,$16
	jal	Z_Malloc
	li	$5,1			# 0x1

	lw	$5,24($sp)
	move	$7,$16
	move	$6,$2
	move	$4,$21
	jal	W_Read
	sw	$2,32($sp)

	lw	$2,20($sp)
	li	$5,28			# 0x1c
	addu	$23,$23,$2
	move	$4,$23
	jal	calloc
	lw	$19,%lo(numlumps)($20)

	beq	$2,$0,$L45
	move	$17,$2

$L15:
	lw	$2,%lo(numlumps)($20)
$L47:
	lui	$fp,%hi(lumpinfo)
	beq	$2,$0,$L16
	lw	$5,%lo(lumpinfo)($fp)

	beq	$23,$0,$L17
	move	$22,$0

	b	$L20
	move	$16,$17

$L46:
	.set	noat
	xor	$1,$23,$22
	beq	$1,$0,$L16
	.set	at
	addiu	$16,$16,28

$L20:
	subu	$18,$16,$17
	move	$4,$16
	addu	$5,$5,$18
	jal	memcpy
	li	$6,28			# 0x1c

	lw	$4,20($16)
	addiu	$22,$22,1
	beq	$4,$0,$L18
	addiu	$5,$16,20

	jal	Z_ChangeUser
	nop

$L18:
	lw	$5,%lo(lumpinfo)($fp)
	lw	$2,%lo(numlumps)($20)
	addu	$18,$5,$18
	lw	$6,24($18)
	sltu	$2,$22,$2
	subu	$4,$6,$5
	beq	$6,$0,$L19
	addu	$4,$17,$4

	sw	$4,24($16)
$L19:
	bne	$2,$0,$L46
	nop

$L16:
	jal	free
	move	$4,$5

	sll	$2,$19,3
	subu	$2,$2,$19
	sll	$2,$2,2
	sltu	$3,$19,$23
	sw	$17,%lo(lumpinfo)($fp)
	lw	$16,32($sp)
	sw	$23,%lo(numlumps)($20)
	beq	$3,$0,$L21
	addu	$17,$17,$2

$L22:
	lwl	$2,3($16)
	sw	$21,8($17)
	lwr	$2,0($16)
	addiu	$5,$16,8
	sw	$2,12($17)
	lwl	$2,7($16)
	move	$4,$17
	lwr	$2,4($16)
	li	$6,8			# 0x8
	sw	$2,16($17)
	jal	strncpy
	sw	$0,20($17)

	lw	$2,%lo(numlumps)($20)
	addiu	$19,$19,1
	sltu	$2,$19,$2
	addiu	$17,$17,28
	bne	$2,$0,$L22
	addiu	$16,$16,16

$L21:
	lw	$4,32($sp)
	jal	Z_Free
	lui	$16,%hi(lumphash)

	lw	$4,%lo(lumphash)($16)
	beq	$4,$0,$L49
	lw	$31,76($sp)

	jal	Z_Free
	nop

	sw	$0,%lo(lumphash)($16)
	lw	$31,76($sp)
$L49:
	lw	$fp,72($sp)
	lw	$23,68($sp)
	lw	$22,64($sp)
	lw	$20,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	move	$2,$21
	lw	$21,60($sp)
	jr	$31
	addiu	$sp,$sp,80

$L43:
	li	$5,1			# 0x1
	jal	Z_Malloc
	li	$4,16			# 0x10

	move	$3,$2
	swl	$0,3($2)
	sw	$2,32($sp)
	lw	$2,8($21)
	swr	$0,0($3)
	swl	$2,7($3)
	addiu	$5,$3,8
	swr	$2,4($3)
	move	$4,$16
	jal	M_ExtractFileBase
	addiu	$23,$23,1

	li	$5,28			# 0x1c
	move	$4,$23
	jal	calloc
	lw	$19,%lo(numlumps)($20)

	bne	$2,$0,$L15
	move	$17,$2

$L45:
	lui	$4,%hi($LC5)
	jal	I_Error
	addiu	$4,$4,%lo($LC5)

	b	$L47
	lw	$2,%lo(numlumps)($20)

$L44:
	li	$6,4			# 0x4
	addiu	$5,$5,%lo($LC3)
	jal	strncmp
	addiu	$4,$sp,16

	beq	$2,$0,$L13
	lui	$4,%hi($LC4)

	move	$5,$16
	jal	I_Error
	addiu	$4,$4,%lo($LC4)

	b	$L48
	lw	$16,20($sp)

$L42:
	lui	$4,%hi($LC0)
	move	$5,$16
	jal	printf
	addiu	$4,$4,%lo($LC0)

	b	$L49
	lw	$31,76($sp)

$L17:
	jal	free
	move	$4,$5

	sw	$17,%lo(lumpinfo)($fp)
	b	$L21
	sw	$0,%lo(numlumps)($20)

	.set	macro
	.set	reorder
	.end	W_AddFile
	.size	W_AddFile, .-W_AddFile
	.align	2
	.globl	W_NumLumps
	.set	nomips16
	.set	nomicromips
	.ent	W_NumLumps
	.type	W_NumLumps, @function
W_NumLumps:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numlumps)
	jr	$31
	lw	$2,%lo(numlumps)($2)

	.set	macro
	.set	reorder
	.end	W_NumLumps
	.size	W_NumLumps, .-W_NumLumps
	.align	2
	.globl	W_CheckNumForName
	.set	nomips16
	.set	nomicromips
	.ent	W_CheckNumForName
	.type	W_CheckNumForName, @function
W_CheckNumForName:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$20,32($sp)
	lui	$20,%hi(lumphash)
	lw	$2,%lo(lumphash)($20)
	sw	$18,24($sp)
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	beq	$2,$0,$L52
	move	$18,$4

	move	$16,$4
	addiu	$19,$4,8
	li	$17,5381			# 0x1505
$L53:
	lb	$4,0($16)
	beq	$4,$0,$L54
	addiu	$16,$16,1

	jal	toupper
	nop

	sll	$3,$17,5
	xor	$3,$3,$2
	.set	noat
	xor	$1,$19,$16
	bne	$1,$0,$L53
	.set	at
	xor	$17,$17,$3

$L54:
	lui	$2,%hi(numlumps)
	lw	$3,%lo(numlumps)($2)
	lw	$2,%lo(lumphash)($20)
	divu	$0,$17,$3
	mfhi	$17
	sll	$17,$17,2
	addu	$2,$2,$17
	lw	$16,0($2)
	bne	$16,$0,$L70
	move	$4,$16

	b	$L51
	li	$16,-1			# 0xffffffffffffffff

$L57:
	lw	$16,24($16)
	beq	$16,$0,$L56
	move	$4,$16

$L70:
	li	$6,8			# 0x8
	jal	strncasecmp
	move	$5,$18

	bne	$2,$0,$L57
	lui	$2,%hi(lumpinfo)

	lw	$2,%lo(lumpinfo)($2)
	lw	$31,36($sp)
	subu	$16,$16,$2
	li	$2,-1227161600			# 0xffffffffb6db0000
	addiu	$2,$2,28087
	sra	$16,$16,2
	multu	$16,$2
	mflo	$16
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L52:
	lui	$2,%hi(numlumps)
	lw	$2,%lo(numlumps)($2)
	addiu	$16,$2,-1
	bltz	$16,$L56
	sll	$17,$2,3

	subu	$17,$17,$2
	sll	$17,$17,2
	addiu	$17,$17,-28
	lui	$19,%hi(lumpinfo)
	li	$20,-1			# 0xffffffffffffffff
$L60:
	lw	$4,%lo(lumpinfo)($19)
	li	$6,8			# 0x8
	addu	$4,$4,$17
	jal	strncasecmp
	move	$5,$18

	beq	$2,$0,$L71
	lw	$31,36($sp)

	addiu	$16,$16,-1
	.set	noat
	xor	$1,$16,$20
	bne	$1,$0,$L60
	.set	at
	addiu	$17,$17,-28

$L56:
	li	$16,-1			# 0xffffffffffffffff
$L51:
	lw	$31,36($sp)
$L71:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	move	$2,$16
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	W_CheckNumForName
	.size	W_CheckNumForName, .-W_CheckNumForName
	.section	.rodata.str1.4
	.align	2
$LC6:
	.ascii	"W_GetNumForName: %s not found!\000"
	.text
	.align	2
	.globl	W_GetNumForName
	.set	nomips16
	.set	nomicromips
	.ent	W_GetNumForName
	.type	W_GetNumForName, @function
W_GetNumForName:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$16,24($sp)
	sw	$31,28($sp)
	jal	W_CheckNumForName
	move	$16,$4

	bltz	$2,$L75
	lw	$31,28($sp)

	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L75:
	lui	$4,%hi($LC6)
	move	$5,$16
	addiu	$4,$4,%lo($LC6)
	jal	I_Error
	sw	$2,16($sp)

	lw	$31,28($sp)
	lw	$2,16($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_GetNumForName
	.size	W_GetNumForName, .-W_GetNumForName
	.section	.rodata.str1.4
	.align	2
$LC7:
	.ascii	"W_LumpLength: %i >= numlumps\000"
	.text
	.align	2
	.globl	W_LumpLength
	.set	nomips16
	.set	nomicromips
	.ent	W_LumpLength
	.type	W_LumpLength, @function
W_LumpLength:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numlumps)
	lw	$2,%lo(numlumps)($2)
	addiu	$sp,$sp,-24
	sltu	$2,$4,$2
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$2,$0,$L79
	move	$16,$4

	sll	$2,$16,3
	lui	$3,%hi(lumpinfo)
	subu	$2,$2,$16
	lw	$3,%lo(lumpinfo)($3)
	lw	$31,20($sp)
	sll	$2,$2,2
	addu	$3,$3,$2
	lw	$2,16($3)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L79:
	move	$5,$4
	lui	$4,%hi($LC7)
	jal	I_Error
	addiu	$4,$4,%lo($LC7)

	sll	$2,$16,3
	lui	$3,%hi(lumpinfo)
	subu	$2,$2,$16
	lw	$3,%lo(lumpinfo)($3)
	lw	$31,20($sp)
	sll	$2,$2,2
	addu	$3,$3,$2
	lw	$2,16($3)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	W_LumpLength
	.size	W_LumpLength, .-W_LumpLength
	.section	.rodata.str1.4
	.align	2
$LC8:
	.ascii	"W_ReadLump: %i >= numlumps\000"
	.align	2
$LC9:
	.ascii	"W_ReadLump: only read %i of %i on lump %i\000"
	.text
	.align	2
	.globl	W_ReadLump
	.set	nomips16
	.set	nomicromips
	.ent	W_ReadLump
	.type	W_ReadLump, @function
W_ReadLump:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numlumps)
	lw	$2,%lo(numlumps)($2)
	addiu	$sp,$sp,-32
	sltu	$2,$4,$2
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$31,28($sp)
	sw	$16,16($sp)
	move	$17,$4
	beq	$2,$0,$L84
	move	$18,$5

	lui	$3,%hi(lumpinfo)
$L86:
	sll	$2,$17,3
	lw	$16,%lo(lumpinfo)($3)
	subu	$2,$2,$17
	sll	$2,$2,2
	jal	I_BeginRead
	addu	$16,$16,$2

	lw	$5,12($16)
	lw	$7,16($16)
	lw	$4,8($16)
	jal	W_Read
	move	$6,$18

	lw	$6,16($16)
	move	$5,$2
	slt	$2,$2,$6
	bne	$2,$0,$L85
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	I_EndRead
	addiu	$sp,$sp,32

$L84:
	move	$5,$4
	lui	$4,%hi($LC8)
	jal	I_Error
	addiu	$4,$4,%lo($LC8)

	b	$L86
	lui	$3,%hi(lumpinfo)

$L85:
	lui	$4,%hi($LC9)
	move	$7,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC9)

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	I_EndRead
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_ReadLump
	.size	W_ReadLump, .-W_ReadLump
	.section	.rodata.str1.4
	.align	2
$LC10:
	.ascii	"W_CacheLumpNum: %i >= numlumps\000"
	.align	2
$LC11:
	.ascii	"w_wad.c\000"
	.text
	.align	2
	.globl	W_CacheLumpNum
	.set	nomips16
	.set	nomicromips
	.ent	W_CacheLumpNum
	.type	W_CacheLumpNum, @function
W_CacheLumpNum:
	.frame	$sp,56,$31		# vars= 8, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$20,44($sp)
	lui	$20,%hi(numlumps)
	lw	$2,%lo(numlumps)($20)
	sw	$19,40($sp)
	sltu	$2,$4,$2
	sw	$17,32($sp)
	sw	$31,52($sp)
	sw	$21,48($sp)
	sw	$18,36($sp)
	sw	$16,28($sp)
	move	$17,$4
	beq	$2,$0,$L95
	move	$19,$5

	sll	$16,$17,3
	lui	$21,%hi(lumpinfo)
	lw	$18,%lo(lumpinfo)($21)
	subu	$16,$16,$17
	sll	$16,$16,2
	addu	$18,$18,$16
	lw	$2,8($18)
	lw	$2,4($2)
	beq	$2,$0,$L89
	nop

$L96:
	lw	$3,12($18)
	addu	$2,$2,$3
$L87:
	lw	$31,52($sp)
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,56

$L95:
	move	$5,$4
	lui	$4,%hi($LC10)
	addiu	$4,$4,%lo($LC10)
	sll	$16,$17,3
	jal	I_Error
	lui	$21,%hi(lumpinfo)

	subu	$16,$16,$17
	lw	$18,%lo(lumpinfo)($21)
	sll	$16,$16,2
	addu	$18,$18,$16
	lw	$2,8($18)
	lw	$2,4($2)
	bne	$2,$0,$L96
	nop

$L89:
	lw	$2,20($18)
	beq	$2,$0,$L91
	lui	$6,%hi($LC11)

	move	$5,$19
	move	$4,$2
	li	$7,410			# 0x19a
	addiu	$6,$6,%lo($LC11)
	jal	Z_ChangeTag2
	sw	$2,16($sp)

	lw	$31,52($sp)
	lw	$2,16($sp)
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,56

$L91:
	lw	$2,%lo(numlumps)($20)
	sltu	$2,$17,$2
	beq	$2,$0,$L97
	nop

	move	$2,$18
$L92:
	lw	$4,16($2)
	move	$5,$19
	jal	Z_Malloc
	addiu	$6,$18,20

	move	$5,$2
	sw	$2,20($18)
	jal	W_ReadLump
	move	$4,$17

	b	$L87
	lw	$2,20($18)

$L97:
	lui	$4,%hi($LC7)
	move	$5,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC7)

	lw	$2,%lo(lumpinfo)($21)
	b	$L92
	addu	$2,$2,$16

	.set	macro
	.set	reorder
	.end	W_CacheLumpNum
	.size	W_CacheLumpNum, .-W_CacheLumpNum
	.align	2
	.globl	W_CacheLumpName
	.set	nomips16
	.set	nomicromips
	.ent	W_CacheLumpName
	.type	W_CacheLumpName, @function
W_CacheLumpName:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$31,28($sp)
	move	$18,$4
	jal	W_CheckNumForName
	move	$17,$5

	bltz	$2,$L101
	move	$16,$2

	lw	$31,28($sp)
	lw	$18,24($sp)
	move	$5,$17
	move	$4,$16
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	W_CacheLumpNum
	addiu	$sp,$sp,32

$L101:
	lui	$4,%hi($LC6)
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC6)

	lw	$31,28($sp)
	lw	$18,24($sp)
	move	$5,$17
	move	$4,$16
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	W_CacheLumpNum
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_CacheLumpName
	.size	W_CacheLumpName, .-W_CacheLumpName
	.section	.rodata.str1.4
	.align	2
$LC12:
	.ascii	"W_ReleaseLumpNum: %i >= numlumps\000"
	.text
	.align	2
	.globl	W_ReleaseLumpNum
	.set	nomips16
	.set	nomicromips
	.ent	W_ReleaseLumpNum
	.type	W_ReleaseLumpNum, @function
W_ReleaseLumpNum:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(numlumps)
	lw	$2,%lo(numlumps)($2)
	addiu	$sp,$sp,-24
	sltu	$2,$4,$2
	sw	$16,16($sp)
	sw	$31,20($sp)
	beq	$2,$0,$L106
	move	$16,$4

	sll	$2,$16,3
	lui	$3,%hi(lumpinfo)
	lw	$3,%lo(lumpinfo)($3)
	subu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$3,8($2)
	lw	$3,4($3)
	beq	$3,$0,$L108
	lw	$31,20($sp)

$L109:
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

$L106:
	move	$5,$4
	lui	$4,%hi($LC12)
	jal	I_Error
	addiu	$4,$4,%lo($LC12)

	sll	$2,$16,3
	lui	$3,%hi(lumpinfo)
	lw	$3,%lo(lumpinfo)($3)
	subu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$3,8($2)
	lw	$3,4($3)
	bne	$3,$0,$L109
	lw	$31,20($sp)

$L108:
	lw	$16,16($sp)
	lw	$4,20($2)
	lui	$6,%hi($LC11)
	li	$7,461			# 0x1cd
	addiu	$6,$6,%lo($LC11)
	li	$5,8			# 0x8
	j	Z_ChangeTag2
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	W_ReleaseLumpNum
	.size	W_ReleaseLumpNum, .-W_ReleaseLumpNum
	.align	2
	.globl	W_ReleaseLumpName
	.set	nomips16
	.set	nomicromips
	.ent	W_ReleaseLumpName
	.type	W_ReleaseLumpName, @function
W_ReleaseLumpName:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	jal	W_CheckNumForName
	move	$17,$4

	bltz	$2,$L113
	move	$16,$2

	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$4,$16
	lw	$16,20($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,32

$L113:
	lui	$4,%hi($LC6)
	move	$5,$17
	jal	I_Error
	addiu	$4,$4,%lo($LC6)

	lw	$31,28($sp)
	lw	$17,24($sp)
	move	$4,$16
	lw	$16,20($sp)
	j	W_ReleaseLumpNum
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	W_ReleaseLumpName
	.size	W_ReleaseLumpName, .-W_ReleaseLumpName
	.align	2
	.globl	W_GenerateHashTable
	.set	nomips16
	.set	nomicromips
	.ent	W_GenerateHashTable
	.type	W_GenerateHashTable, @function
W_GenerateHashTable:
	.frame	$sp,56,$31		# vars= 0, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$22,44($sp)
	lui	$22,%hi(lumphash)
	lw	$4,%lo(lumphash)($22)
	sw	$31,52($sp)
	sw	$23,48($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	beq	$4,$0,$L115
	sw	$16,20($sp)

	jal	Z_Free
	nop

$L115:
	lui	$21,%hi(numlumps)
	lw	$4,%lo(numlumps)($21)
	bne	$4,$0,$L132
	move	$6,$0

$L114:
	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

$L132:
	li	$5,1			# 0x1
	jal	Z_Malloc
	sll	$4,$4,2

	lw	$6,%lo(numlumps)($21)
	move	$4,$2
	sll	$6,$6,2
	move	$5,$0
	jal	memset
	sw	$2,%lo(lumphash)($22)

	lw	$2,%lo(numlumps)($21)
	beq	$2,$0,$L114
	move	$18,$0

	move	$19,$0
	lui	$20,%hi(lumpinfo)
$L120:
	lw	$16,%lo(lumpinfo)($20)
	li	$17,5381			# 0x1505
	addu	$16,$16,$18
	addiu	$23,$16,8
$L117:
	lb	$4,0($16)
	beq	$4,$0,$L118
	addiu	$16,$16,1

	jal	toupper
	nop

	sll	$3,$17,5
	xor	$3,$3,$2
	.set	noat
	xor	$1,$23,$16
	bne	$1,$0,$L117
	.set	at
	xor	$17,$17,$3

$L118:
	lw	$2,%lo(numlumps)($21)
	lw	$3,%lo(lumphash)($22)
	divu	$0,$17,$2
	lw	$4,%lo(lumpinfo)($20)
	addiu	$19,$19,1
	addu	$4,$4,$18
	sltu	$2,$19,$2
	addiu	$18,$18,28
	mfhi	$17
	sll	$17,$17,2
	addu	$3,$3,$17
	lw	$5,0($3)
	sw	$5,24($4)
	bne	$2,$0,$L120
	sw	$4,0($3)

	lw	$31,52($sp)
	lw	$23,48($sp)
	lw	$22,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	W_GenerateHashTable
	.size	W_GenerateHashTable, .-W_GenerateHashTable
	.section	.rodata.str1.4
	.align	2
$LC13:
	.ascii	"doomgeneric\000"
	.align	2
$LC14:
	.ascii	"\012You are trying to use a %s IWAD file with the %s%s b"
	.ascii	"inary.\012This isn't going to work.\012You probably want"
	.ascii	" to use the %s%s binary.\000"
	.text
	.align	2
	.globl	W_CheckCorrectIWAD
	.set	nomips16
	.set	nomicromips
	.ent	W_CheckCorrectIWAD
	.type	W_CheckCorrectIWAD, @function
W_CheckCorrectIWAD:
	.frame	$sp,48,$31		# vars= 0, regs= 6/0, args= 24, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$16,24($sp)
	lui	$16,%hi(unique_lumps)
	addiu	$16,$16,%lo(unique_lumps)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$31,44($sp)
	sw	$20,40($sp)
	sw	$17,28($sp)
	move	$18,$4
	addiu	$19,$16,32
$L137:
	lw	$17,0($16)
	.set	noat
	xor	$1,$17,$18
	beq	$1,$0,$L135
	.set	at
	nop

	jal	W_CheckNumForName
	lw	$4,4($16)

	li	$5,4			# 0x4
	bltz	$2,$L135
	move	$4,$17

	jal	D_SuggestGameName
	nop

	move	$4,$18
	jal	D_GameMissionString
	move	$20,$2

	move	$4,$17
	jal	D_GameMissionString
	move	$17,$2

	lui	$6,%hi($LC13)
	addiu	$6,$6,%lo($LC13)
	lui	$4,%hi($LC14)
	sw	$2,20($sp)
	sw	$6,16($sp)
	move	$7,$17
	move	$5,$20
	jal	I_Error
	addiu	$4,$4,%lo($LC14)

$L135:
	addiu	$16,$16,8
	.set	noat
	xor	$1,$16,$19
	bne	$1,$0,$L137
	.set	at
	lw	$31,44($sp)

	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	W_CheckCorrectIWAD
	.size	W_CheckCorrectIWAD, .-W_CheckCorrectIWAD
	.section	.rodata.str1.4
	.align	2
$LC15:
	.ascii	"POSSA1\000"
	.align	2
$LC16:
	.ascii	"IMPXA1\000"
	.align	2
$LC17:
	.ascii	"ETTNA1\000"
	.align	2
$LC18:
	.ascii	"AGRDA1\000"
	.rdata
	.align	2
	.type	unique_lumps, @object
	.size	unique_lumps, 32
unique_lumps:
	.word	0
	.word	$LC15
	.word	6
	.word	$LC16
	.word	7
	.word	$LC17
	.word	8
	.word	$LC18
	.local	lumphash
	.comm	lumphash,4,4
	.globl	numlumps
	.section	.bss,"aw",@nobits
	.align	2
	.type	numlumps, @object
	.size	numlumps, 4
numlumps:
	.space	4
	.globl	lumpinfo
	.align	2
	.type	lumpinfo, @object
	.size	lumpinfo, 4
lumpinfo:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
