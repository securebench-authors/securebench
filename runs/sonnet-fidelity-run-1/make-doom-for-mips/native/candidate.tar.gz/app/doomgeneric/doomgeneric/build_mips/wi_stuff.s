	.file	1 "wi_stuff.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	WI_loadCallback
	.type	WI_loadCallback, @function
WI_loadCallback:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,20($sp)
	jal	W_CacheLumpName
	li	$5,1			# 0x1

	lw	$31,20($sp)
	sw	$2,0($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	WI_loadCallback
	.size	WI_loadCallback, .-WI_loadCallback
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC1:
	.ascii	"WIMINUS\000"
	.align	2
$LC2:
	.ascii	"CWILV%2.2d\000"
	.align	2
$LC3:
	.ascii	"WILV%d%d\000"
	.align	2
$LC4:
	.ascii	"WIURH0\000"
	.align	2
$LC5:
	.ascii	"WIURH1\000"
	.align	2
$LC6:
	.ascii	"WISPLAT\000"
	.align	2
$LC7:
	.ascii	"WIA%d%.2d%.2d\000"
	.align	2
$LC8:
	.ascii	"WINUM%d\000"
	.align	2
$LC9:
	.ascii	"WIPCNT\000"
	.align	2
$LC10:
	.ascii	"WIF\000"
	.align	2
$LC11:
	.ascii	"WIENTER\000"
	.align	2
$LC12:
	.ascii	"WIOSTK\000"
	.align	2
$LC13:
	.ascii	"WIOSTS\000"
	.align	2
$LC14:
	.ascii	"WISCRT2\000"
	.align	2
$LC15:
	.ascii	"WIOBJ\000"
	.align	2
$LC16:
	.ascii	"WIOSTI\000"
	.align	2
$LC17:
	.ascii	"WIFRGS\000"
	.align	2
$LC18:
	.ascii	"WICOLON\000"
	.align	2
$LC19:
	.ascii	"WITIME\000"
	.align	2
$LC20:
	.ascii	"WISUCKS\000"
	.align	2
$LC21:
	.ascii	"WIPAR\000"
	.align	2
$LC22:
	.ascii	"WIKILRS\000"
	.align	2
$LC23:
	.ascii	"WIVCTMS\000"
	.align	2
$LC24:
	.ascii	"WIMSTT\000"
	.align	2
$LC25:
	.ascii	"STPB%d\000"
	.align	2
$LC26:
	.ascii	"WIBP%d\000"
	.align	2
$LC27:
	.ascii	"INTERPIC\000"
	.align	2
$LC28:
	.ascii	"WIMAP%d\000"
	.text
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	WI_loadUnloadData
	.type	WI_loadUnloadData, @function
WI_loadUnloadData:
	.frame	$sp,104,$31		# vars= 40, regs= 10/0, args= 24, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	addiu	$sp,$sp,-104
	lw	$3,%lo(gamemode)($2)
	sw	$2,60($sp)
	li	$2,2			# 0x2
	sw	$17,68($sp)
	sw	$31,100($sp)
	sw	$fp,96($sp)
	sw	$23,92($sp)
	sw	$22,88($sp)
	sw	$21,84($sp)
	sw	$20,80($sp)
	sw	$19,76($sp)
	sw	$18,72($sp)
	sw	$16,64($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L35
	.set	at
	move	$17,$4

	lui	$21,%hi($LC3)
	move	$18,$0
	addiu	$16,$sp,24
	lui	$20,%hi(lnames)
	lui	$19,%hi(wbs)
	addiu	$21,$21,%lo($LC3)
	lw	$2,%lo(wbs)($19)
$L41:
	move	$4,$16
	lw	$7,0($2)
	move	$6,$21
	sw	$18,16($sp)
	jal	snprintf
	li	$5,9			# 0x9

	lw	$5,%lo(lnames)($20)
	sll	$2,$18,2
	addu	$5,$5,$2
	jalr	$17
	move	$4,$16

	addiu	$18,$18,1
	li	$2,9			# 0x9
	.set	noat
	xor	$1,$18,$2
	bne	$1,$0,$L41
	.set	at
	lw	$2,%lo(wbs)($19)

	lui	$5,%hi(yah)
	lui	$4,%hi($LC4)
	addiu	$5,$5,%lo(yah)
	jalr	$17
	addiu	$4,$4,%lo($LC4)

	lui	$5,%hi(yah+4)
	lui	$4,%hi($LC5)
	addiu	$5,$5,%lo(yah+4)
	jalr	$17
	addiu	$4,$4,%lo($LC5)

	lui	$5,%hi(splat)
	lui	$4,%hi($LC6)
	addiu	$5,$5,%lo(splat)
	jalr	$17
	addiu	$4,$4,%lo($LC6)

	lw	$2,%lo(wbs)($19)
	lw	$7,0($2)
	slt	$2,$7,3
	beq	$2,$0,$L38
	lui	$5,%hi(wiminus)

	lui	$fp,%hi(NUMANIMS)
	addiu	$2,$fp,%lo(NUMANIMS)
	sll	$3,$7,2
	sw	$2,52($sp)
	addu	$2,$2,$3
	lw	$2,0($2)
	blez	$2,$L38
	lui	$2,%hi(anims)

	addiu	$2,$2,%lo(anims)
	sw	$2,48($sp)
	lui	$22,%hi($LC7)
	lui	$2,%hi(epsd1animinfo)
	sw	$2,56($sp)
	addiu	$2,$22,%lo($LC7)
	sw	$0,40($sp)
	move	$fp,$0
	sw	$2,44($sp)
$L14:
	lw	$2,48($sp)
	addu	$2,$2,$3
	lw	$9,0($2)
	lw	$2,40($sp)
	addu	$21,$9,$2
	lw	$2,8($21)
	blez	$2,$L9
	nop

	lw	$3,56($sp)
	addiu	$18,$21,28
	addiu	$23,$3,%lo(epsd1animinfo)
	move	$22,$0
	li	$20,1			# 0x1
$L12:
	.set	noat
	xor	$1,$7,$20
	beq	$1,$0,$L42
	.set	at
	li	$3,8			# 0x8

	lw	$6,44($sp)
$L43:
	sw	$22,20($sp)
	move	$4,$16
	li	$5,9			# 0x9
	jal	snprintf
	sw	$fp,16($sp)

	move	$5,$18
	jalr	$17
	move	$4,$16

	lw	$2,8($21)
	lw	$5,%lo(wbs)($19)
	addiu	$22,$22,1
	slt	$4,$22,$2
	lw	$7,0($5)
	addiu	$18,$18,4
	bne	$4,$0,$L12
	addiu	$23,$23,4

	sll	$3,$7,2
$L9:
	lw	$2,52($sp)
	lw	$4,40($sp)
	addu	$2,$2,$3
	lw	$2,0($2)
	addiu	$fp,$fp,1
	addiu	$4,$4,56
	slt	$2,$fp,$2
	bne	$2,$0,$L14
	sw	$4,40($sp)

$L8:
	lui	$5,%hi(wiminus)
$L38:
	lui	$4,%hi($LC1)
	addiu	$5,$5,%lo(wiminus)
	addiu	$4,$4,%lo($LC1)
	lui	$19,%hi(num)
	jalr	$17
	lui	$20,%hi($LC8)

	addiu	$19,$19,%lo(num)
	move	$18,$0
	addiu	$20,$20,%lo($LC8)
	li	$21,10			# 0xa
$L7:
	move	$7,$18
	move	$6,$20
	move	$4,$16
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$18,$18,1
	move	$5,$19
	jalr	$17
	move	$4,$16

	.set	noat
	xor	$1,$18,$21
	bne	$1,$0,$L7
	.set	at
	addiu	$19,$19,4

	lui	$5,%hi(percent)
	lui	$4,%hi($LC9)
	addiu	$5,$5,%lo(percent)
	jalr	$17
	addiu	$4,$4,%lo($LC9)

	lui	$5,%hi(finished)
	lui	$4,%hi($LC10)
	addiu	$5,$5,%lo(finished)
	jalr	$17
	addiu	$4,$4,%lo($LC10)

	lui	$5,%hi(entering)
	lui	$4,%hi($LC11)
	addiu	$5,$5,%lo(entering)
	jalr	$17
	addiu	$4,$4,%lo($LC11)

	lui	$5,%hi(kills)
	lui	$4,%hi($LC12)
	addiu	$5,$5,%lo(kills)
	jalr	$17
	addiu	$4,$4,%lo($LC12)

	lui	$5,%hi(secret)
	lui	$4,%hi($LC13)
	addiu	$5,$5,%lo(secret)
	jalr	$17
	addiu	$4,$4,%lo($LC13)

	lui	$5,%hi(sp_secret)
	lui	$4,%hi($LC14)
	addiu	$4,$4,%lo($LC14)
	addiu	$5,$5,%lo(sp_secret)
	jalr	$17
	lui	$18,%hi($LC15)

	jal	W_CheckNumForName
	addiu	$4,$18,%lo($LC15)

	bltz	$2,$L15
	lui	$2,%hi(netgame)

	lw	$2,%lo(netgame)($2)
	bne	$2,$0,$L36
	lui	$2,%hi(deathmatch)

$L15:
	lui	$5,%hi(items)
	lui	$4,%hi($LC16)
	addiu	$5,$5,%lo(items)
	jalr	$17
	addiu	$4,$4,%lo($LC16)

	lui	$5,%hi(frags)
$L39:
	lui	$4,%hi($LC17)
	addiu	$5,$5,%lo(frags)
	jalr	$17
	addiu	$4,$4,%lo($LC17)

	lui	$5,%hi(colon)
	lui	$4,%hi($LC18)
	addiu	$5,$5,%lo(colon)
	jalr	$17
	addiu	$4,$4,%lo($LC18)

	lui	$5,%hi(timepatch)
	lui	$4,%hi($LC19)
	addiu	$5,$5,%lo(timepatch)
	jalr	$17
	addiu	$4,$4,%lo($LC19)

	lui	$5,%hi(sucks)
	lui	$4,%hi($LC20)
	addiu	$5,$5,%lo(sucks)
	jalr	$17
	addiu	$4,$4,%lo($LC20)

	lui	$5,%hi(par)
	lui	$4,%hi($LC21)
	addiu	$5,$5,%lo(par)
	jalr	$17
	addiu	$4,$4,%lo($LC21)

	lui	$5,%hi(killers)
	lui	$4,%hi($LC22)
	addiu	$5,$5,%lo(killers)
	jalr	$17
	addiu	$4,$4,%lo($LC22)

	lui	$5,%hi(victims)
	lui	$4,%hi($LC23)
	addiu	$5,$5,%lo(victims)
	jalr	$17
	addiu	$4,$4,%lo($LC23)

	lui	$5,%hi(total)
	lui	$4,%hi($LC24)
	addiu	$5,$5,%lo(total)
	addiu	$4,$4,%lo($LC24)
	lui	$20,%hi(p)
	lui	$19,%hi(bp)
	lui	$22,%hi($LC25)
	jalr	$17
	lui	$21,%hi($LC26)

	addiu	$20,$20,%lo(p)
	addiu	$19,$19,%lo(bp)
	move	$18,$0
	addiu	$22,$22,%lo($LC25)
	addiu	$21,$21,%lo($LC26)
	li	$23,4			# 0x4
$L17:
	move	$7,$18
	move	$6,$22
	move	$4,$16
	jal	snprintf
	li	$5,9			# 0x9

	addiu	$18,$18,1
	move	$5,$20
	jalr	$17
	move	$4,$16

	move	$7,$18
	move	$6,$21
	move	$4,$16
	jal	snprintf
	li	$5,9			# 0x9

	move	$5,$19
	jalr	$17
	move	$4,$16

	addiu	$20,$20,4
	.set	noat
	xor	$1,$18,$23
	bne	$1,$0,$L17
	.set	at
	addiu	$19,$19,4

	lw	$2,60($sp)
	li	$3,2			# 0x2
	lw	$2,%lo(gamemode)($2)
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L21
	.set	at
	lui	$3,%hi(wbs)

	lw	$4,%lo(wbs)($3)
	li	$3,3			# 0x3
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L20
	.set	at
	lw	$7,0($4)

	.set	noat
	xor	$1,$7,$2
	beq	$1,$0,$L21
	.set	at
	nop

$L20:
	lui	$6,%hi($LC28)
	addiu	$6,$6,%lo($LC28)
	li	$5,9			# 0x9
	jal	snprintf
	move	$4,$16

	lui	$5,%hi(background)
$L40:
	move	$4,$16
	jalr	$17
	addiu	$5,$5,%lo(background)

	lw	$31,100($sp)
	lw	$fp,96($sp)
	lw	$23,92($sp)
	lw	$22,88($sp)
	lw	$21,84($sp)
	lw	$20,80($sp)
	lw	$19,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	jr	$31
	addiu	$sp,$sp,104

$L13:
	li	$3,8			# 0x8
$L42:
	.set	noat
	xor	$1,$fp,$3
	bne	$1,$0,$L43
	.set	at
	lw	$6,44($sp)

	lw	$5,252($23)
	addiu	$22,$22,1
	slt	$4,$22,$2
	sw	$5,0($18)
	addiu	$23,$23,4
	bne	$4,$0,$L13
	addiu	$18,$18,4

	b	$L38
	lui	$5,%hi(wiminus)

$L36:
	lw	$2,%lo(deathmatch)($2)
	bne	$2,$0,$L15
	nop

	lui	$5,%hi(items)
	addiu	$5,$5,%lo(items)
	jalr	$17
	addiu	$4,$18,%lo($LC15)

	b	$L39
	lui	$5,%hi(frags)

$L21:
	lui	$5,%hi($LC27)
	li	$6,9			# 0x9
	addiu	$5,$5,%lo($LC27)
	jal	M_StringCopy
	move	$4,$16

	b	$L40
	lui	$5,%hi(background)

$L35:
	lui	$21,%hi(NUMCMAPS)
	lw	$2,%lo(NUMCMAPS)($21)
	blez	$2,$L37
	move	$18,$0

	lui	$19,%hi($LC2)
	addiu	$16,$sp,24
	lui	$20,%hi(lnames)
	addiu	$19,$19,%lo($LC2)
	move	$7,$18
$L44:
	move	$4,$16
	move	$6,$19
	jal	snprintf
	li	$5,9			# 0x9

	lw	$5,%lo(lnames)($20)
	sll	$2,$18,2
	addu	$5,$5,$2
	jalr	$17
	move	$4,$16

	lw	$2,%lo(NUMCMAPS)($21)
	addiu	$18,$18,1
	slt	$2,$18,$2
	bne	$2,$0,$L44
	move	$7,$18

	b	$L38
	lui	$5,%hi(wiminus)

$L37:
	b	$L8
	addiu	$16,$sp,24

	.set	macro
	.set	reorder
	.end	WI_loadUnloadData
	.size	WI_loadUnloadData, .-WI_loadUnloadData
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	WI_unloadCallback
	.type	WI_unloadCallback, @function
WI_unloadCallback:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$16,16($sp)
	sw	$31,20($sp)
	jal	W_ReleaseLumpName
	move	$16,$5

	lw	$31,20($sp)
	sw	$0,0($16)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	WI_unloadCallback
	.size	WI_unloadCallback, .-WI_unloadCallback
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	WI_initAnimatedBack.part.0
	.type	WI_initAnimatedBack.part.0, @function
WI_initAnimatedBack.part.0:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$18,32($sp)
	lui	$18,%hi(wbs)
	lw	$2,%lo(wbs)($18)
	sw	$22,48($sp)
	lw	$2,0($2)
	lui	$22,%hi(NUMANIMS)
	addiu	$22,$22,%lo(NUMANIMS)
	sll	$2,$2,2
	addu	$3,$22,$2
	lw	$3,0($3)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$17,28($sp)
	blez	$3,$L47
	sw	$16,24($sp)

	lui	$23,%hi(anims)
	lui	$3,%hi(bcnt)
	move	$21,$0
	move	$20,$0
	addiu	$23,$23,%lo(anims)
	li	$19,-1			# 0xffffffffffffffff
	li	$17,1			# 0x1
	b	$L52
	sw	$3,16($sp)

$L49:
	.set	noat
	xor	$1,$2,$17
	beq	$1,$0,$L55
	.set	at
	li	$3,2			# 0x2

	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L56
	.set	at
	lw	$2,%lo(wbs)($18)

	lw	$2,16($sp)
	lw	$2,%lo(bcnt)($2)
	addiu	$2,$2,1
	sw	$2,40($16)
$L50:
	lw	$2,%lo(wbs)($18)
$L56:
	addiu	$20,$20,1
	lw	$2,0($2)
	sll	$2,$2,2
	addu	$3,$22,$2
	lw	$3,0($3)
	slt	$3,$20,$3
	beq	$3,$0,$L47
	addiu	$21,$21,56

$L52:
	addu	$2,$23,$2
	lw	$16,0($2)
	addu	$16,$16,$21
	lw	$2,0($16)
	bne	$2,$0,$L49
	sw	$19,48($16)

	lw	$2,16($sp)
	addiu	$20,$20,1
	jal	M_Random
	lw	$fp,%lo(bcnt)($2)

	lw	$3,4($16)
	addiu	$fp,$fp,1
	div	$0,$2,$3
	mfhi	$2
	addu	$2,$2,$fp
	sw	$2,40($16)
	lw	$2,%lo(wbs)($18)
	lw	$2,0($2)
	sll	$2,$2,2
	addu	$3,$22,$2
	lw	$3,0($3)
	slt	$3,$20,$3
	bne	$3,$0,$L52
	addiu	$21,$21,56

$L47:
	lw	$31,60($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L55:
	lw	$2,16($sp)
	lw	$fp,%lo(bcnt)($2)
	lw	$2,24($16)
	addiu	$fp,$fp,1
	jal	M_Random
	addu	$fp,$fp,$2

	lw	$3,20($16)
	div	$0,$2,$3
	mfhi	$2
	addu	$2,$2,$fp
	b	$L50
	sw	$2,40($16)

	.set	macro
	.set	reorder
	.end	WI_initAnimatedBack.part.0
	.size	WI_initAnimatedBack.part.0, .-WI_initAnimatedBack.part.0
	.align	2
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateAnimatedBack.part.0
	.type	WI_updateAnimatedBack.part.0, @function
WI_updateAnimatedBack.part.0:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$22,40($sp)
	lui	$22,%hi(wbs)
	lw	$4,%lo(wbs)($22)
	sw	$20,32($sp)
	lw	$2,0($4)
	lui	$20,%hi(NUMANIMS)
	addiu	$20,$20,%lo(NUMANIMS)
	sll	$2,$2,2
	addu	$3,$20,$2
	lw	$3,0($3)
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$21,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	blez	$3,$L57
	sw	$16,16($sp)

	lui	$21,%hi(anims)
	move	$19,$0
	move	$18,$0
	addiu	$21,$21,%lo(anims)
	lui	$23,%hi(bcnt)
	li	$6,1			# 0x1
	b	$L66
	li	$fp,2			# 0x2

$L59:
	lw	$4,%lo(wbs)($22)
$L73:
	addiu	$18,$18,1
	lw	$2,0($4)
	sll	$2,$2,2
	addu	$3,$20,$2
	lw	$3,0($3)
	slt	$3,$18,$3
	beq	$3,$0,$L57
	addiu	$19,$19,56

$L66:
	addu	$2,$21,$2
	lw	$16,0($2)
	lw	$3,%lo(bcnt)($23)
	addu	$16,$16,$19
	lw	$2,40($16)
	.set	noat
	xor	$1,$2,$3
	bne	$1,$0,$L59
	.set	at
	nop

	lw	$5,0($16)
	.set	noat
	xor	$1,$5,$6
	beq	$1,$0,$L60
	.set	at
	nop

	.set	noat
	xor	$1,$5,$fp
	beq	$1,$0,$L61
	.set	at
	nop

	bne	$5,$0,$L73
	lw	$4,%lo(wbs)($22)

	lw	$3,48($16)
	lw	$5,8($16)
	lw	$4,4($16)
	addiu	$3,$3,1
	slt	$5,$3,$5
	addu	$2,$4,$2
	movz	$3,$0,$5
	lw	$4,%lo(wbs)($22)
	sw	$3,48($16)
	sw	$2,40($16)
	lw	$2,0($4)
	addiu	$18,$18,1
	sll	$2,$2,2
	addu	$3,$20,$2
	lw	$3,0($3)
	slt	$3,$18,$3
	bne	$3,$0,$L66
	addiu	$19,$19,56

$L57:
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,56

$L61:
	lui	$2,%hi(state)
	lw	$2,%lo(state)($2)
	beq	$2,$0,$L69
	li	$2,7			# 0x7

	lw	$4,12($4)
	lw	$2,20($16)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L73
	.set	at
	lw	$4,%lo(wbs)($22)

	lw	$2,48($16)
$L72:
	lw	$5,8($16)
	addiu	$4,$2,1
	.set	noat
	xor	$1,$4,$5
	bne	$1,$0,$L65
	.set	at
	nop

	move	$4,$2
$L65:
	lw	$2,4($16)
	sw	$4,48($16)
	addu	$2,$2,$3
	b	$L59
	sw	$2,40($16)

$L60:
	lw	$3,48($16)
	lw	$4,8($16)
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$4
	beq	$1,$0,$L70
	.set	at
	sw	$3,48($16)

	lw	$3,4($16)
	addu	$2,$3,$2
	b	$L59
	sw	$2,40($16)

$L69:
	.set	noat
	xor	$1,$18,$2
	beq	$1,$0,$L59
	.set	at
	nop

	lw	$4,12($4)
	lw	$2,20($16)
	.set	noat
	xor	$1,$4,$2
	bne	$1,$0,$L73
	.set	at
	lw	$4,%lo(wbs)($22)

	b	$L72
	lw	$2,48($16)

$L70:
	lw	$3,24($16)
	li	$4,-1			# 0xffffffffffffffff
	sw	$4,48($16)
	jal	M_Random
	addu	$17,$2,$3

	lw	$3,20($16)
	li	$6,1			# 0x1
	div	$0,$2,$3
	mfhi	$2
	addu	$2,$2,$17
	b	$L59
	sw	$2,40($16)

	.set	macro
	.set	reorder
	.end	WI_updateAnimatedBack.part.0
	.size	WI_updateAnimatedBack.part.0, .-WI_updateAnimatedBack.part.0
	.align	2
	.globl	WI_slamBackground
	.set	nomips16
	.set	nomicromips
	.ent	WI_slamBackground
	.type	WI_slamBackground, @function
WI_slamBackground:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(background)
	lw	$6,%lo(background)($2)
	move	$5,$0
	j	V_DrawPatch
	move	$4,$0

	.set	macro
	.set	reorder
	.end	WI_slamBackground
	.size	WI_slamBackground, .-WI_slamBackground
	.align	2
	.globl	WI_Responder
	.set	nomips16
	.set	nomicromips
	.ent	WI_Responder
	.type	WI_Responder, @function
WI_Responder:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$0

	.set	macro
	.set	reorder
	.end	WI_Responder
	.size	WI_Responder, .-WI_Responder
	.rdata
	.align	2
$LC0:
	.half	320
	.half	200
	.half	1
	.half	1
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.text
	.align	2
	.globl	WI_drawLF
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawLF
	.type	WI_drawLF, @function
WI_drawLF:
	.frame	$sp,72,$31		# vars= 40, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-72
	lui	$3,%hi(gamemode)
	sw	$16,60($sp)
	lui	$16,%hi(wbs)
	lw	$2,%lo(wbs)($16)
	lw	$4,%lo(gamemode)($3)
	li	$3,2			# 0x2
	lw	$2,8($2)
	sw	$31,68($sp)
	.set	noat
	xor	$1,$4,$3
	bne	$1,$0,$L77
	.set	at
	sw	$17,64($sp)

	lui	$3,%hi(NUMCMAPS)
	lw	$3,%lo(NUMCMAPS)($3)
	slt	$4,$2,$3
	beq	$4,$0,$L78
	nop

$L77:
	lui	$17,%hi(lnames)
	lw	$3,%lo(lnames)($17)
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$6,0($2)
	li	$5,2			# 0x2
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	li	$3,320			# 0x140
	sra	$2,$2,16
	subu	$2,$3,$2
	srl	$4,$2,31
	addu	$4,$4,$2
	jal	V_DrawPatch
	sra	$4,$4,1

	lw	$3,%lo(wbs)($16)
	lw	$2,%lo(lnames)($17)
	lw	$3,8($3)
	sll	$3,$3,2
	addu	$2,$2,$3
	lw	$3,0($2)
	lui	$2,%hi(finished)
	lw	$6,%lo(finished)($2)
	lbu	$2,3($3)
	lbu	$3,2($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$5,$2,2
	addu	$5,$5,$2
	bltz	$5,$L84
	nop

$L79:
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	li	$3,320			# 0x140
	subu	$2,$3,$2
	srl	$4,$2,31
	lw	$31,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	sra	$5,$5,2
	addu	$4,$4,$2
	addiu	$5,$5,2
	sra	$4,$4,1
	j	V_DrawPatch
	addiu	$sp,$sp,72

$L84:
	b	$L79
	addiu	$5,$5,3

$L78:
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L85
	.set	at
	lw	$31,68($sp)

	lw	$17,64($sp)
	lw	$16,60($sp)
	jr	$31
	addiu	$sp,$sp,72

$L85:
	lui	$2,%hi($LC0)
	addiu	$2,$2,%lo($LC0)
	addiu	$3,$sp,16
	addiu	$8,$2,32
$L81:
	lw	$7,0($2)
	lw	$6,4($2)
	lw	$5,8($2)
	lw	$4,12($2)
	addiu	$2,$2,16
	sw	$7,0($3)
	sw	$6,4($3)
	sw	$5,8($3)
	sw	$4,12($3)
	.set	noat
	xor	$1,$2,$8
	bne	$1,$0,$L81
	.set	at
	addiu	$3,$3,16

	lw	$7,0($2)
	lw	$2,4($2)
	addiu	$6,$sp,16
	li	$5,2			# 0x2
	move	$4,$0
	sw	$7,0($3)
	jal	V_DrawPatch
	sw	$2,4($3)

	lw	$31,68($sp)
	lw	$17,64($sp)
	lw	$16,60($sp)
	jr	$31
	addiu	$sp,$sp,72

	.set	macro
	.set	reorder
	.end	WI_drawLF
	.size	WI_drawLF, .-WI_drawLF
	.align	2
	.globl	WI_drawEL
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawEL
	.type	WI_drawEL, @function
WI_drawEL:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(entering)
	lw	$6,%lo(entering)($2)
	addiu	$sp,$sp,-24
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	li	$3,320			# 0x140
	sra	$2,$2,16
	subu	$2,$3,$2
	srl	$4,$2,31
	addu	$4,$4,$2
	li	$5,2			# 0x2
	sw	$31,20($sp)
	jal	V_DrawPatch
	sra	$4,$4,1

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$3,12($2)
	lui	$2,%hi(lnames)
	lw	$2,%lo(lnames)($2)
	sll	$3,$3,2
	addu	$2,$2,$3
	lw	$6,0($2)
	lbu	$2,3($6)
	lbu	$3,2($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$5,$2,2
	addu	$5,$5,$2
	bgez	$5,$L87
	nop

	addiu	$5,$5,3
$L87:
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	li	$3,320			# 0x140
	subu	$2,$3,$2
	srl	$4,$2,31
	lw	$31,20($sp)
	sra	$5,$5,2
	addu	$4,$4,$2
	addiu	$5,$5,2
	sra	$4,$4,1
	j	V_DrawPatch
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	WI_drawEL
	.size	WI_drawEL, .-WI_drawEL
	.section	.rodata.str1.4
	.align	2
$LC29:
	.ascii	"Could not place patch on level %d\000"
	.text
	.align	2
	.globl	WI_drawOnLnode
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawOnLnode
	.type	WI_drawOnLnode, @function
WI_drawOnLnode:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	move	$11,$4
	lw	$3,0($2)
	move	$10,$5
	sll	$2,$3,3
	addu	$2,$2,$3
	addu	$2,$2,$4
	lui	$3,%hi(lnodes)
	sll	$2,$2,3
	addiu	$3,$3,%lo(lnodes)
	addu	$2,$2,$3
	lw	$4,0($2)
	lw	$13,4($2)
	li	$12,2			# 0x2
	move	$9,$0
	li	$5,1			# 0x1
$L93:
	sll	$9,$9,2
	addu	$9,$10,$9
	lw	$6,0($9)
	li	$9,1			# 0x1
	lbu	$3,5($6)
	lbu	$25,4($6)
	lbu	$2,1($6)
	lbu	$15,0($6)
	sll	$3,$3,8
	lbu	$7,7($6)
	lbu	$8,3($6)
	or	$3,$3,$25
	sll	$2,$2,8
	lbu	$24,6($6)
	lbu	$14,2($6)
	sll	$3,$3,16
	or	$2,$2,$15
	sra	$3,$3,16
	sll	$7,$7,8
	sll	$8,$8,8
	sll	$2,$2,16
	subu	$3,$4,$3
	or	$7,$7,$24
	or	$8,$8,$14
	sra	$2,$2,16
	sll	$7,$7,16
	addu	$2,$2,$3
	sll	$8,$8,16
	sra	$7,$7,16
	slt	$2,$2,320
	bltz	$3,$L90
	sra	$8,$8,16

	beq	$2,$0,$L90
	subu	$7,$13,$7

	addu	$8,$8,$7
	bltz	$7,$L90
	slt	$8,$8,200

	bne	$8,$0,$L91
	nop

$L90:
	.set	noat
	xor	$1,$12,$5
	bne	$1,$0,$L95
	.set	at
	nop

	lui	$4,%hi($LC29)
$L96:
	addiu	$5,$11,1
	j	printf
	addiu	$4,$4,%lo($LC29)

$L95:
	lw	$2,4($10)
	bne	$2,$0,$L93
	li	$12,1			# 0x1

	b	$L96
	lui	$4,%hi($LC29)

$L91:
	j	V_DrawPatch
	move	$5,$13

	.set	macro
	.set	reorder
	.end	WI_drawOnLnode
	.size	WI_drawOnLnode, .-WI_drawOnLnode
	.align	2
	.globl	WI_initAnimatedBack
	.set	nomips16
	.set	nomicromips
	.ent	WI_initAnimatedBack
	.type	WI_initAnimatedBack, @function
WI_initAnimatedBack:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L99
	.set	at
	lui	$2,%hi(wbs)

	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L99
	nop

	j	WI_initAnimatedBack.part.0
	nop

$L99:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_initAnimatedBack
	.size	WI_initAnimatedBack, .-WI_initAnimatedBack
	.align	2
	.globl	WI_updateAnimatedBack
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateAnimatedBack
	.type	WI_updateAnimatedBack, @function
WI_updateAnimatedBack:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L102
	.set	at
	lui	$2,%hi(wbs)

	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L102
	nop

	j	WI_updateAnimatedBack.part.0
	nop

$L102:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_updateAnimatedBack
	.size	WI_updateAnimatedBack, .-WI_updateAnimatedBack
	.align	2
	.globl	WI_drawAnimatedBack
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawAnimatedBack
	.type	WI_drawAnimatedBack, @function
WI_drawAnimatedBack:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L112
	.set	at
	nop

	addiu	$sp,$sp,-40
	sw	$19,28($sp)
	lui	$19,%hi(wbs)
	lw	$2,%lo(wbs)($19)
	sw	$31,36($sp)
	lw	$2,0($2)
	sw	$20,32($sp)
	slt	$3,$2,3
	sw	$18,24($sp)
	sw	$17,20($sp)
	beq	$3,$0,$L103
	sw	$16,16($sp)

	lui	$18,%hi(NUMANIMS)
	sll	$2,$2,2
	addiu	$18,$18,%lo(NUMANIMS)
	addu	$3,$18,$2
	lw	$3,0($3)
	blez	$3,$L103
	lui	$20,%hi(anims)

	move	$17,$0
	move	$16,$0
	addiu	$20,$20,%lo(anims)
$L106:
	addu	$2,$20,$2
	lw	$2,0($2)
	addiu	$16,$16,1
	addu	$2,$2,$17
	lw	$4,48($2)
	addiu	$17,$17,56
	addiu	$3,$4,6
	sll	$3,$3,2
	bltz	$4,$L105
	addu	$3,$2,$3

	lw	$6,4($3)
	lw	$5,16($2)
	jal	V_DrawPatch
	lw	$4,12($2)

$L105:
	lw	$2,%lo(wbs)($19)
	lw	$2,0($2)
	sll	$2,$2,2
	addu	$3,$18,$2
	lw	$3,0($3)
	slt	$3,$16,$3
	bne	$3,$0,$L106
	nop

$L103:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L112:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_drawAnimatedBack
	.size	WI_drawAnimatedBack, .-WI_drawAnimatedBack
	.align	2
	.globl	WI_drawNum
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawNum
	.type	WI_drawNum, @function
WI_drawNum:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$18,32($sp)
	lui	$18,%hi(num)
	sw	$17,28($sp)
	lw	$8,%lo(num)($18)
	sw	$31,60($sp)
	sw	$fp,56($sp)
	sw	$23,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$16,24($sp)
	sw	$4,64($sp)
	move	$17,$5
	bltz	$7,$L132
	sw	$6,72($sp)

	lw	$23,72($sp)
	bltz	$23,$L133
	li	$2,1994			# 0x7ca

	.set	noat
	xor	$1,$23,$2
	beq	$1,$0,$L134
	.set	at
	lw	$31,60($sp)

$L130:
	beq	$7,$0,$L135
	addiu	$21,$7,-1

	li	$3,-859045888			# 0xffffffffcccc0000
$L140:
	ori	$3,$3,0xcccd
	multu	$23,$3
	addiu	$4,$18,%lo(num)
	mfhi	$3
	srl	$3,$3,3
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,1
	subu	$2,$23,$2
	sll	$2,$2,2
	addu	$2,$2,$4
	lw	$6,0($2)
$L115:
	lbu	$16,1($8)
	lbu	$2,0($8)
	sll	$16,$16,8
	or	$16,$16,$2
	sll	$16,$16,16
	li	$8,-859045888			# 0xffffffffcccc0000
	lw	$fp,64($sp)
	sra	$16,$16,16
	addiu	$20,$21,-1
	ori	$22,$8,0xcccd
	li	$19,-1			# 0xffffffffffffffff
	b	$L124
	addiu	$18,$18,%lo(num)

$L123:
	srl	$2,$2,3
	sll	$3,$2,2
	addu	$3,$3,$2
	sll	$3,$3,1
	subu	$3,$23,$3
	sll	$3,$3,2
	addu	$3,$3,$18
	lw	$6,0($3)
	addiu	$20,$20,-1
$L124:
	subu	$fp,$fp,$16
	move	$5,$17
	jal	V_DrawPatch
	move	$4,$fp

	multu	$23,$22
	mfhi	$23
	srl	$23,$23,3
	multu	$23,$22
	.set	noat
	xor	$1,$20,$19
	bne	$1,$0,$L123
	.set	at
	mfhi	$2

	multu	$16,$21
	mflo	$3
	lw	$2,64($sp)
	subu	$2,$2,$16
	subu	$2,$2,$3
$L118:
	lw	$3,72($sp)
	bltz	$3,$L136
	lw	$31,60($sp)

$L138:
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L133:
	subu	$23,$0,$23
	.set	noat
	xor	$1,$23,$2
	bne	$1,$0,$L130
	.set	at
	lw	$31,60($sp)

	b	$L141
	lw	$fp,56($sp)

$L132:
	beq	$6,$0,$L126
	move	$2,$6

	li	$6,1717960704			# 0x66660000
	move	$5,$0
	addiu	$6,$6,26215
$L116:
	mult	$2,$6
	sra	$4,$2,31
	mfhi	$3
	move	$21,$5
	sra	$3,$3,2
	subu	$2,$3,$4
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L116
	.set	at
	addiu	$5,$5,1

	lw	$23,72($sp)
	bgez	$23,$L139
	li	$3,1994			# 0x7ca

	subu	$23,$0,$23
$L139:
	.set	noat
	xor	$1,$23,$3
	bne	$1,$0,$L140
	.set	at
	li	$3,-859045888			# 0xffffffffcccc0000

	b	$L138
	lw	$31,60($sp)

$L126:
	move	$6,$8
	move	$21,$0
	b	$L115
	move	$23,$0

$L136:
	lui	$3,%hi(wiminus)
	addiu	$2,$2,-8
	lw	$6,%lo(wiminus)($3)
	move	$5,$17
	move	$4,$2
	jal	V_DrawPatch
	sw	$2,16($sp)

	lw	$31,60($sp)
	lw	$2,16($sp)
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,64

$L134:
	lw	$fp,56($sp)
$L141:
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	move	$2,$0
	jr	$31
	addiu	$sp,$sp,64

$L135:
	b	$L118
	lw	$2,64($sp)

	.set	macro
	.set	reorder
	.end	WI_drawNum
	.size	WI_drawNum, .-WI_drawNum
	.align	2
	.globl	WI_drawPercent
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawPercent
	.type	WI_drawPercent, @function
WI_drawPercent:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$6,$L147
	nop

	addiu	$sp,$sp,-32
	lui	$2,%hi(percent)
	sw	$16,16($sp)
	move	$16,$6
	lw	$6,%lo(percent)($2)
	sw	$18,24($sp)
	sw	$17,20($sp)
	move	$18,$5
	sw	$31,28($sp)
	jal	V_DrawPatch
	move	$17,$4

	lw	$31,28($sp)
	move	$6,$16
	move	$5,$18
	lw	$16,16($sp)
	lw	$18,24($sp)
	move	$4,$17
	lw	$17,20($sp)
	li	$7,-1			# 0xffffffffffffffff
	j	WI_drawNum
	addiu	$sp,$sp,32

$L147:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_drawPercent
	.size	WI_drawPercent, .-WI_drawPercent
	.align	2
	.globl	WI_drawTime
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawTime
	.type	WI_drawTime, @function
WI_drawTime:
	.frame	$sp,64,$31		# vars= 8, regs= 9/0, args= 16, gp= 0
	.mask	0x80ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bltz	$6,$L160
	nop

	addiu	$sp,$sp,-64
	slt	$2,$6,3600
	sw	$16,28($sp)
	sw	$31,60($sp)
	sw	$23,56($sp)
	sw	$22,52($sp)
	sw	$21,48($sp)
	sw	$20,44($sp)
	sw	$19,40($sp)
	sw	$18,36($sp)
	sw	$17,32($sp)
	beq	$2,$0,$L151
	move	$16,$6

	addiu	$20,$6,59
	li	$18,-2004353024			# 0xffffffff88880000
	move	$17,$5
	li	$23,1			# 0x1
	ori	$18,$18,0x8889
	li	$19,1			# 0x1
	lui	$21,%hi(colon)
	sltu	$20,$20,119
$L153:
	div	$0,$16,$23
	move	$5,$17
	li	$7,2			# 0x2
	mflo	$6
	multu	$6,$18
	mfhi	$3
	srl	$3,$3,5
	sll	$2,$3,4
	subu	$2,$2,$3
	sll	$2,$2,2
	jal	WI_drawNum
	subu	$6,$6,$2

	sll	$3,$23,4
	subu	$3,$3,$23
	.set	noat
	xor	$1,$23,$19
	beq	$1,$0,$L159
	.set	at
	sll	$22,$3,2

$L148:
	lw	$31,60($sp)
	lw	$23,56($sp)
	lw	$22,52($sp)
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,64

$L151:
	lui	$2,%hi(sucks)
	lw	$6,%lo(sucks)($2)
	lw	$31,60($sp)
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	lw	$23,56($sp)
	lw	$22,52($sp)
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	sra	$2,$2,16
	subu	$4,$4,$2
	j	V_DrawPatch
	addiu	$sp,$sp,64

$L159:
	lw	$6,%lo(colon)($21)
	move	$5,$17
	lbu	$3,1($6)
	lbu	$4,0($6)
	sll	$3,$3,8
	or	$3,$3,$4
	sll	$3,$3,16
	sra	$3,$3,16
	subu	$4,$2,$3
	jal	V_DrawPatch
	sw	$4,16($sp)

	bne	$20,$0,$L148
	lw	$4,16($sp)

	b	$L153
	move	$23,$22

$L160:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_drawTime
	.size	WI_drawTime, .-WI_drawTime
	.align	2
	.globl	WI_End
	.set	nomips16
	.set	nomicromips
	.ent	WI_End
	.type	WI_End, @function
WI_End:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(WI_unloadCallback)
	j	WI_loadUnloadData
	addiu	$4,$4,%lo(WI_unloadCallback)

	.set	macro
	.set	reorder
	.end	WI_End
	.size	WI_End, .-WI_End
	.align	2
	.globl	WI_initNoState
	.set	nomips16
	.set	nomicromips
	.ent	WI_initNoState
	.type	WI_initNoState, @function
WI_initNoState:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(state)
	li	$3,-1			# 0xffffffffffffffff
	sw	$3,%lo(state)($2)
	lui	$2,%hi(acceleratestage)
	sw	$0,%lo(acceleratestage)($2)
	li	$3,10			# 0xa
	lui	$2,%hi(cnt)
	jr	$31
	sw	$3,%lo(cnt)($2)

	.set	macro
	.set	reorder
	.end	WI_initNoState
	.size	WI_initNoState, .-WI_initNoState
	.align	2
	.globl	WI_updateNoState
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateNoState
	.type	WI_updateNoState, @function
WI_updateNoState:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L167
	.set	at
	lui	$2,%hi(wbs)

	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L174
	lui	$3,%hi(cnt)

	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	WI_updateAnimatedBack.part.0
	nop

	lui	$3,%hi(cnt)
	lw	$2,%lo(cnt)($3)
	addiu	$2,$2,-1
	beq	$2,$0,$L172
	sw	$2,%lo(cnt)($3)

	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

$L172:
	lw	$31,20($sp)
	j	G_WorldDone
	addiu	$sp,$sp,24

$L167:
	lui	$3,%hi(cnt)
$L174:
	lw	$2,%lo(cnt)($3)
	addiu	$2,$2,-1
	beq	$2,$0,$L173
	sw	$2,%lo(cnt)($3)

	jr	$31
	nop

$L173:
	j	G_WorldDone
	nop

	.set	macro
	.set	reorder
	.end	WI_updateNoState
	.size	WI_updateNoState, .-WI_updateNoState
	.align	2
	.globl	WI_initShowNextLoc
	.set	nomips16
	.set	nomicromips
	.ent	WI_initShowNextLoc
	.type	WI_initShowNextLoc, @function
WI_initShowNextLoc:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lui	$4,%hi(state)
	li	$5,1			# 0x1
	sw	$5,%lo(state)($4)
	lw	$3,%lo(gamemode)($2)
	lui	$4,%hi(acceleratestage)
	sw	$0,%lo(acceleratestage)($4)
	li	$5,140			# 0x8c
	lui	$4,%hi(cnt)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L179
	.set	at
	sw	$5,%lo(cnt)($4)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L179
	nop

	j	WI_initAnimatedBack.part.0
	nop

$L179:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_initShowNextLoc
	.size	WI_initShowNextLoc, .-WI_initShowNextLoc
	.align	2
	.globl	WI_updateShowNextLoc
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateShowNextLoc
	.type	WI_updateShowNextLoc, @function
WI_updateShowNextLoc:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L189
	.set	at
	lui	$2,%hi(wbs)

	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L197
	lui	$3,%hi(cnt)

	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	WI_updateAnimatedBack.part.0
	nop

	lui	$3,%hi(cnt)
	lw	$2,%lo(cnt)($3)
	lui	$4,%hi(acceleratestage)
	addiu	$2,$2,-1
	bne	$2,$0,$L187
	sw	$2,%lo(cnt)($3)

	lw	$31,20($sp)
$L198:
	lui	$2,%hi(state)
	li	$5,-1			# 0xffffffffffffffff
	sw	$5,%lo(state)($2)
	li	$2,10			# 0xa
	sw	$0,%lo(acceleratestage)($4)
	sw	$2,%lo(cnt)($3)
	jr	$31
	addiu	$sp,$sp,24

$L187:
	lw	$5,%lo(acceleratestage)($4)
	bne	$5,$0,$L198
	lw	$31,20($sp)

	andi	$2,$2,0x1f
	slt	$2,$2,20
	lui	$3,%hi(snl_pointeron)
	sw	$2,%lo(snl_pointeron)($3)
	jr	$31
	addiu	$sp,$sp,24

$L189:
	lui	$3,%hi(cnt)
$L197:
	lw	$2,%lo(cnt)($3)
	lui	$4,%hi(acceleratestage)
	addiu	$2,$2,-1
	beq	$2,$0,$L192
	sw	$2,%lo(cnt)($3)

	lw	$5,%lo(acceleratestage)($4)
	bne	$5,$0,$L192
	nop

	andi	$2,$2,0x1f
	slt	$2,$2,20
	lui	$3,%hi(snl_pointeron)
	jr	$31
	sw	$2,%lo(snl_pointeron)($3)

$L192:
	lui	$2,%hi(state)
	li	$5,-1			# 0xffffffffffffffff
	sw	$5,%lo(state)($2)
	li	$2,10			# 0xa
	sw	$0,%lo(acceleratestage)($4)
	jr	$31
	sw	$2,%lo(cnt)($3)

	.set	macro
	.set	reorder
	.end	WI_updateShowNextLoc
	.size	WI_updateShowNextLoc, .-WI_updateShowNextLoc
	.align	2
	.globl	WI_drawShowNextLoc
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawShowNextLoc
	.type	WI_drawShowNextLoc, @function
WI_drawShowNextLoc:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(background)
	addiu	$sp,$sp,-40
	lw	$6,%lo(background)($2)
	move	$5,$0
	sw	$20,32($sp)
	move	$4,$0
	lui	$20,%hi(gamemode)
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	jal	V_DrawPatch
	sw	$16,16($sp)

	jal	WI_drawAnimatedBack
	lui	$19,%hi(wbs)

	lw	$3,%lo(gamemode)($20)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L209
	.set	at
	lw	$2,%lo(wbs)($19)

	lw	$3,0($2)
	slt	$3,$3,3
	beq	$3,$0,$L210
	li	$3,8			# 0x8

	lw	$17,8($2)
	.set	noat
	xor	$1,$17,$3
	beq	$1,$0,$L220
	.set	at
	nop

	bltz	$17,$L205
	nop

$L223:
	lui	$18,%hi(splat)
	move	$16,$0
	addiu	$18,$18,%lo(splat)
	move	$4,$16
$L226:
	move	$5,$18
	jal	WI_drawOnLnode
	addiu	$16,$16,1

	slt	$2,$17,$16
	beq	$2,$0,$L226
	move	$4,$16

	lw	$2,%lo(wbs)($19)
$L205:
	lw	$2,4($2)
$L224:
	bne	$2,$0,$L221
	lui	$2,%hi(snl_pointeron)

	lw	$2,%lo(snl_pointeron)($2)
	bne	$2,$0,$L227
	lw	$2,%lo(wbs)($19)

	lw	$3,%lo(gamemode)($20)
$L229:
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L225
	.set	at
	lw	$3,%lo(wbs)($19)

$L210:
	lw	$31,36($sp)
$L228:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	j	WI_drawEL
	addiu	$sp,$sp,40

$L209:
	lw	$3,%lo(wbs)($19)
$L225:
	li	$2,30			# 0x1e
	lw	$3,12($3)
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L228
	.set	at
	lw	$31,36($sp)

	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

$L220:
	lw	$17,12($2)
	addiu	$17,$17,-1
	bgez	$17,$L223
	nop

	b	$L224
	lw	$2,4($2)

$L221:
	lui	$5,%hi(splat)
	addiu	$5,$5,%lo(splat)
	jal	WI_drawOnLnode
	li	$4,8			# 0x8

	lui	$2,%hi(snl_pointeron)
	lw	$2,%lo(snl_pointeron)($2)
	beq	$2,$0,$L229
	lw	$3,%lo(gamemode)($20)

	lw	$2,%lo(wbs)($19)
$L227:
	lui	$5,%hi(yah)
	lw	$4,12($2)
	jal	WI_drawOnLnode
	addiu	$5,$5,%lo(yah)

	lw	$3,%lo(gamemode)($20)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L228
	.set	at
	lw	$31,36($sp)

	b	$L225
	lw	$3,%lo(wbs)($19)

	.set	macro
	.set	reorder
	.end	WI_drawShowNextLoc
	.size	WI_drawShowNextLoc, .-WI_drawShowNextLoc
	.align	2
	.globl	WI_drawNoState
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawNoState
	.type	WI_drawNoState, @function
WI_drawNoState:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(snl_pointeron)
	li	$3,1			# 0x1
	j	WI_drawShowNextLoc
	sw	$3,%lo(snl_pointeron)($2)

	.set	macro
	.set	reorder
	.end	WI_drawNoState
	.size	WI_drawNoState, .-WI_drawNoState
	.align	2
	.globl	WI_fragSum
	.set	nomips16
	.set	nomicromips
	.ent	WI_fragSum
	.type	WI_fragSum, @function
WI_fragSum:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(plrs)
	sll	$2,$4,2
	lw	$8,%lo(plrs)($3)
	addu	$2,$2,$4
	sll	$2,$2,3
	addu	$8,$8,$2
	lui	$5,%hi(playeringame)
	addiu	$5,$5,%lo(playeringame)
	addiu	$6,$8,20
	move	$2,$0
	move	$3,$0
	li	$9,4			# 0x4
$L233:
	lw	$7,0($5)
	beq	$7,$0,$L232
	addiu	$5,$5,4

	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L232
	.set	at
	nop

	lw	$7,0($6)
	addu	$2,$2,$7
$L232:
	addiu	$3,$3,1
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L233
	.set	at
	addiu	$6,$6,4

	addiu	$4,$4,4
	sll	$4,$4,2
	addu	$8,$8,$4
	lw	$3,4($8)
	jr	$31
	subu	$2,$2,$3

	.set	macro
	.set	reorder
	.end	WI_fragSum
	.size	WI_fragSum, .-WI_fragSum
	.align	2
	.globl	WI_initDeathmatchStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_initDeathmatchStats
	.type	WI_initDeathmatchStats, @function
WI_initDeathmatchStats:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(state)
	sw	$0,%lo(state)($2)
	lui	$2,%hi(acceleratestage)
	li	$3,1			# 0x1
	lui	$9,%hi(playeringame)
	sw	$0,%lo(acceleratestage)($2)
	lui	$2,%hi(dm_state)
	addiu	$9,$9,%lo(playeringame)
	sw	$3,%lo(dm_state)($2)
	lui	$5,%hi(dm_totals)
	li	$3,35			# 0x23
	lui	$2,%hi(cnt_pause)
	lui	$4,%hi(dm_frags)
	sw	$3,%lo(cnt_pause)($2)
	addiu	$5,$5,%lo(dm_totals)
	addiu	$4,$4,%lo(dm_frags)
	addiu	$7,$9,16
	move	$3,$9
$L242:
	lw	$2,0($3)
	bne	$2,$0,$L252
	move	$6,$4

$L239:
	addiu	$3,$3,4
	addiu	$5,$5,4
	.set	noat
	xor	$1,$3,$7
	bne	$1,$0,$L242
	.set	at
	addiu	$4,$4,16

	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L253
	.set	at
	lui	$2,%hi(wbs)

	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L253
	nop

	j	WI_initAnimatedBack.part.0
	nop

$L252:
	move	$2,$9
$L241:
	lw	$8,0($2)
	beq	$8,$0,$L240
	addiu	$2,$2,4

	sw	$0,0($6)
$L240:
	.set	noat
	xor	$1,$2,$7
	bne	$1,$0,$L241
	.set	at
	addiu	$6,$6,4

	b	$L239
	sw	$0,0($5)

$L253:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_initDeathmatchStats
	.size	WI_initDeathmatchStats, .-WI_initDeathmatchStats
	.align	2
	.globl	WI_updateDeathmatchStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateDeathmatchStats
	.type	WI_updateDeathmatchStats, @function
WI_updateDeathmatchStats:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	lui	$17,%hi(gamemode)
	lw	$3,%lo(gamemode)($17)
	li	$2,2			# 0x2
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L255
	.set	at
	sw	$16,20($sp)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L306
	lui	$19,%hi(acceleratestage)

	jal	WI_updateAnimatedBack.part.0
	nop

$L255:
	lui	$19,%hi(acceleratestage)
$L306:
	lw	$16,%lo(acceleratestage)($19)
	lui	$18,%hi(dm_state)
	beq	$16,$0,$L256
	lw	$2,%lo(dm_state)($18)

	li	$3,4			# 0x4
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L257
	.set	at
	lui	$2,%hi(plrs)

	lw	$12,%lo(plrs)($2)
	lui	$14,%hi(playeringame)
	addiu	$14,$14,%lo(playeringame)
	lui	$13,%hi(dm_totals)
	lui	$11,%hi(dm_frags)
	sw	$0,%lo(acceleratestage)($19)
	addiu	$13,$13,%lo(dm_totals)
	addiu	$12,$12,20
	addiu	$11,$11,%lo(dm_frags)
	move	$10,$14
	move	$16,$0
	addiu	$15,$14,16
	li	$24,4			# 0x4
$L261:
	lw	$2,0($10)
	bne	$2,$0,$L301
	move	$4,$11

$L258:
	addiu	$16,$16,1
	addiu	$10,$10,4
	addiu	$13,$13,4
	addiu	$12,$12,40
	.set	noat
	xor	$1,$16,$24
	bne	$1,$0,$L261
	.set	at
	addiu	$11,$11,16

	li	$5,82			# 0x52
	jal	S_StartSound
	move	$4,$0

	lw	$2,%lo(acceleratestage)($19)
	bne	$2,$0,$L257
	sw	$16,%lo(dm_state)($18)

$L254:
	lw	$31,36($sp)
$L307:
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L256:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L263
	.set	at
	li	$3,4			# 0x4

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L254
	.set	at
	andi	$3,$2,0x1

	beq	$3,$0,$L307
	lw	$31,36($sp)

	lui	$4,%hi(cnt_pause)
	lw	$3,%lo(cnt_pause)($4)
	addiu	$3,$3,-1
	bne	$3,$0,$L254
	sw	$3,%lo(cnt_pause)($4)

	lw	$31,36($sp)
	addiu	$2,$2,1
	sw	$2,%lo(dm_state)($18)
	li	$2,35			# 0x23
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$2,%lo(cnt_pause)($4)
	jr	$31
	addiu	$sp,$sp,40

$L263:
	lui	$2,%hi(bcnt)
	lw	$2,%lo(bcnt)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L302
	li	$5,1			# 0x1

	lui	$2,%hi(plrs)
$L305:
	lw	$11,%lo(plrs)($2)
	lui	$15,%hi(playeringame)
	addiu	$15,$15,%lo(playeringame)
	lui	$13,%hi(dm_totals)
	lui	$12,%hi(dm_frags)
	addiu	$13,$13,%lo(dm_totals)
	addiu	$12,$12,%lo(dm_frags)
	addiu	$11,$11,20
	move	$10,$15
	move	$19,$0
	addiu	$14,$15,16
	li	$17,-99			# 0xffffffffffffff9d
	li	$25,99			# 0x63
	li	$24,4			# 0x4
$L274:
	lw	$2,0($10)
	bne	$2,$0,$L303
	move	$5,$11

$L266:
	addiu	$16,$16,1
	addiu	$10,$10,4
	addiu	$13,$13,4
	addiu	$12,$12,16
	.set	noat
	xor	$1,$16,$24
	bne	$1,$0,$L274
	.set	at
	addiu	$11,$11,40

	bne	$19,$0,$L307
	lw	$31,36($sp)

	li	$5,82			# 0x52
	jal	S_StartSound
	move	$4,$0

	lw	$2,%lo(dm_state)($18)
	lw	$31,36($sp)
	addiu	$2,$2,1
	lw	$19,32($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	sw	$2,%lo(dm_state)($18)
	lw	$18,28($sp)
	jr	$31
	addiu	$sp,$sp,40

$L303:
	move	$4,$12
	move	$2,$15
$L270:
	lw	$3,0($2)
	beq	$3,$0,$L267
	nop

	lw	$3,0($4)
	lw	$6,0($5)
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L267
	.set	at
	nop

	bltz	$6,$L304
	nop

	addiu	$3,$3,1
$L269:
	slt	$6,$3,-99
	movn	$3,$17,$6
	slt	$6,$3,100
	movz	$3,$25,$6
	sw	$3,0($4)
	li	$19,1			# 0x1
$L267:
	addiu	$2,$2,4
	addiu	$4,$4,4
	.set	noat
	xor	$1,$2,$14
	bne	$1,$0,$L270
	.set	at
	addiu	$5,$5,4

	jal	WI_fragSum
	move	$4,$16

	slt	$3,$2,100
	beq	$3,$0,$L278
	slt	$3,$2,-99

	beq	$3,$0,$L300
	nop

	li	$2,-99			# 0xffffffffffffff9d
$L300:
	b	$L266
	sw	$2,0($13)

$L301:
	move	$3,$12
	move	$2,$14
$L260:
	lw	$5,0($2)
	beq	$5,$0,$L259
	addiu	$2,$2,4

	lw	$5,0($3)
	sw	$5,0($4)
$L259:
	addiu	$3,$3,4
	.set	noat
	xor	$1,$2,$15
	bne	$1,$0,$L260
	.set	at
	addiu	$4,$4,4

	jal	WI_fragSum
	move	$4,$16

	b	$L258
	sw	$2,0($13)

$L278:
	li	$2,99			# 0x63
	b	$L266
	sw	$2,0($13)

$L257:
	li	$5,31			# 0x1f
	jal	S_StartSound
	move	$4,$0

	lw	$3,%lo(gamemode)($17)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L277
	.set	at
	lui	$2,%hi(state)

	li	$3,-1			# 0xffffffffffffffff
	sw	$3,%lo(state)($2)
	lui	$2,%hi(cnt)
	li	$3,10			# 0xa
	sw	$0,%lo(acceleratestage)($19)
	b	$L254
	sw	$3,%lo(cnt)($2)

$L304:
	b	$L269
	addiu	$3,$3,-1

$L302:
	jal	S_StartSound
	move	$4,$0

	b	$L305
	lui	$2,%hi(plrs)

$L277:
	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lui	$3,%hi(state)
	lw	$2,0($2)
	li	$4,1			# 0x1
	sw	$4,%lo(state)($3)
	slt	$2,$2,3
	lui	$3,%hi(cnt)
	li	$4,140			# 0x8c
	sw	$0,%lo(acceleratestage)($19)
	beq	$2,$0,$L254
	sw	$4,%lo(cnt)($3)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	WI_initAnimatedBack.part.0
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	WI_updateDeathmatchStats
	.size	WI_updateDeathmatchStats, .-WI_updateDeathmatchStats
	.align	2
	.globl	WI_drawDeathmatchStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawDeathmatchStats
	.type	WI_drawDeathmatchStats, @function
WI_drawDeathmatchStats:
	.frame	$sp,72,$31		# vars= 16, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(background)
	lw	$6,%lo(background)($2)
	addiu	$sp,$sp,-72
	move	$5,$0
	move	$4,$0
	sw	$31,68($sp)
	sw	$fp,64($sp)
	sw	$23,60($sp)
	sw	$22,56($sp)
	sw	$21,52($sp)
	sw	$20,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	jal	V_DrawPatch
	sw	$16,32($sp)

	jal	WI_drawAnimatedBack
	lui	$17,%hi(playeringame)

	jal	WI_drawLF
	addiu	$17,$17,%lo(playeringame)

	lui	$2,%hi(total)
	lw	$6,%lo(total)($2)
	li	$4,269			# 0x10d
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$3,$2,16
	sra	$3,$3,16
	srl	$2,$2,15
	addu	$2,$2,$3
	sra	$2,$2,1
	subu	$4,$4,$2
	jal	V_DrawPatch
	li	$5,45			# 0x2d

	lui	$2,%hi(killers)
	lw	$6,%lo(killers)($2)
	li	$5,100			# 0x64
	jal	V_DrawPatch
	li	$4,10			# 0xa

	lui	$2,%hi(victims)
	lw	$6,%lo(victims)($2)
	li	$5,50			# 0x32
	li	$4,5			# 0x5
	jal	V_DrawPatch
	lui	$20,%hi(p)

	addiu	$20,$20,%lo(p)
	move	$21,$17
	li	$19,68			# 0x44
	li	$22,82			# 0x52
	move	$23,$0
	li	$16,42			# 0x2a
	lui	$18,%hi(me)
	li	$fp,200			# 0xc8
$L312:
	lw	$2,0($21)
	bne	$2,$0,$L327
	addiu	$21,$21,4

$L310:
	addiu	$19,$19,33
$L330:
	addiu	$22,$22,40
	addiu	$23,$23,1
	.set	noat
	xor	$1,$19,$fp
	bne	$1,$0,$L312
	.set	at
	addiu	$20,$20,4

	lui	$2,%hi(num)
	lw	$2,%lo(num)($2)
	lui	$21,%hi(dm_totals)
	lbu	$22,1($2)
	lbu	$2,0($2)
	sll	$22,$22,8
	or	$22,$22,$2
	sll	$22,$22,16
	sra	$22,$22,16
	lui	$20,%hi(dm_frags)
	addiu	$2,$22,269
	addiu	$21,$21,%lo(dm_totals)
	addiu	$20,$20,%lo(dm_frags)
	move	$19,$17
	li	$18,78			# 0x4e
	addiu	$fp,$17,16
	sw	$2,24($sp)
	li	$23,210			# 0xd2
$L316:
	lw	$2,0($19)
	bne	$2,$0,$L328
	addiu	$4,$22,82

	addiu	$18,$18,33
$L331:
	addiu	$19,$19,4
	addiu	$21,$21,4
	.set	noat
	xor	$1,$18,$23
	bne	$1,$0,$L316
	.set	at
	addiu	$20,$20,16

	lw	$31,68($sp)
	lw	$fp,64($sp)
	lw	$23,60($sp)
	lw	$22,56($sp)
	lw	$21,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	jr	$31
	addiu	$sp,$sp,72

$L327:
	lw	$6,0($20)
	li	$5,35			# 0x23
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$3,$2,16
	sra	$3,$3,16
	srl	$4,$2,15
	addu	$4,$4,$3
	sra	$4,$4,1
	jal	V_DrawPatch
	subu	$4,$22,$4

	lw	$6,0($20)
	move	$5,$19
	lbu	$2,1($6)
	lbu	$3,0($6)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$3,$2,16
	srl	$4,$2,15
	sra	$3,$3,16
	addu	$4,$4,$3
	sra	$4,$4,1
	jal	V_DrawPatch
	subu	$4,$16,$4

	lw	$2,%lo(me)($18)
	.set	noat
	xor	$1,$2,$23
	bne	$1,$0,$L310
	.set	at
	li	$5,35			# 0x23

	lw	$3,0($20)
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$3,$2,16
	sra	$3,$3,16
	srl	$4,$2,15
	addu	$4,$4,$3
	lui	$2,%hi(bstar)
	lw	$6,%lo(bstar)($2)
	sra	$4,$4,1
	jal	V_DrawPatch
	subu	$4,$22,$4

	lw	$3,0($20)
	move	$5,$19
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$3,$2,16
	sra	$3,$3,16
	srl	$4,$2,15
	addu	$4,$4,$3
	lui	$2,%hi(star)
	lw	$6,%lo(star)($2)
	sra	$4,$4,1
	jal	V_DrawPatch
	subu	$4,$16,$4

	b	$L330
	addiu	$19,$19,33

$L328:
	move	$3,$20
	move	$16,$17
$L315:
	lw	$2,0($16)
	bne	$2,$0,$L329
	addiu	$16,$16,4

$L314:
	addiu	$3,$3,4
	.set	noat
	xor	$1,$16,$fp
	bne	$1,$0,$L315
	.set	at
	addiu	$4,$4,40

	lw	$6,0($21)
	lw	$4,24($sp)
	li	$7,2			# 0x2
	jal	WI_drawNum
	move	$5,$18

	b	$L331
	addiu	$18,$18,33

$L329:
	lw	$6,0($3)
	li	$7,2			# 0x2
	move	$5,$18
	sw	$3,20($sp)
	jal	WI_drawNum
	sw	$4,16($sp)

	lw	$3,20($sp)
	b	$L314
	lw	$4,16($sp)

	.set	macro
	.set	reorder
	.end	WI_drawDeathmatchStats
	.size	WI_drawDeathmatchStats, .-WI_drawDeathmatchStats
	.align	2
	.globl	WI_initNetgameStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_initNetgameStats
	.type	WI_initNetgameStats, @function
WI_initNetgameStats:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(state)
	addiu	$sp,$sp,-32
	sw	$0,%lo(state)($2)
	lui	$2,%hi(acceleratestage)
	li	$3,1			# 0x1
	sw	$16,20($sp)
	sw	$0,%lo(acceleratestage)($2)
	lui	$16,%hi(dofrags)
	lui	$2,%hi(ng_state)
	sw	$3,%lo(ng_state)($2)
	lui	$12,%hi(playeringame)
	lui	$2,%hi(cnt_pause)
	li	$3,35			# 0x23
	lui	$13,%hi(cnt_frags)
	lui	$25,%hi(cnt_secret)
	lui	$24,%hi(cnt_items)
	lui	$15,%hi(cnt_kills)
	lw	$14,%lo(dofrags)($16)
	sw	$17,24($sp)
	sw	$31,28($sp)
	sw	$3,%lo(cnt_pause)($2)
	addiu	$12,$12,%lo(playeringame)
	addiu	$13,$13,%lo(cnt_frags)
	move	$10,$0
	move	$11,$0
	addiu	$25,$25,%lo(cnt_secret)
	addiu	$24,$24,%lo(cnt_items)
	addiu	$15,$15,%lo(cnt_kills)
	li	$17,4			# 0x4
$L334:
	lw	$2,0($12)
	move	$4,$11
	addu	$6,$25,$10
	addu	$5,$24,$10
	addu	$3,$15,$10
	beq	$2,$0,$L333
	addiu	$11,$11,1

	sw	$0,0($6)
	sw	$0,0($5)
	sw	$0,0($3)
	jal	WI_fragSum
	sw	$0,0($13)

	addu	$14,$14,$2
	sw	$14,%lo(dofrags)($16)
$L333:
	addiu	$12,$12,4
	addiu	$13,$13,4
	.set	noat
	xor	$1,$11,$17
	bne	$1,$0,$L334
	.set	at
	addiu	$10,$10,4

	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	sltu	$14,$0,$14
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L332
	.set	at
	sw	$14,%lo(dofrags)($16)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L332
	lw	$31,28($sp)

	lw	$17,24($sp)
	lw	$16,20($sp)
	j	WI_initAnimatedBack.part.0
	addiu	$sp,$sp,32

$L332:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	WI_initNetgameStats
	.size	WI_initNetgameStats, .-WI_initNetgameStats
	.align	2
	.globl	WI_updateNetgameStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateNetgameStats
	.type	WI_updateNetgameStats, @function
WI_updateNetgameStats:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-48
	sw	$17,24($sp)
	lui	$17,%hi(gamemode)
	lw	$3,%lo(gamemode)($17)
	li	$2,2			# 0x2
	sw	$31,44($sp)
	sw	$21,40($sp)
	sw	$20,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L342
	.set	at
	sw	$16,20($sp)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L421
	lui	$18,%hi(acceleratestage)

	jal	WI_updateAnimatedBack.part.0
	nop

$L342:
	lui	$18,%hi(acceleratestage)
$L421:
	lw	$19,%lo(acceleratestage)($18)
	lui	$16,%hi(ng_state)
	beq	$19,$0,$L343
	lw	$2,%lo(ng_state)($16)

	li	$3,10			# 0xa
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L344
	.set	at
	lui	$2,%hi(plrs)

	lw	$11,%lo(plrs)($2)
	lui	$2,%hi(wbs)
	lw	$14,%lo(wbs)($2)
	lui	$2,%hi(dofrags)
	lui	$13,%hi(playeringame)
	lui	$19,%hi(cnt_kills)
	lui	$25,%hi(cnt_items)
	lui	$24,%hi(cnt_secret)
	lui	$15,%hi(cnt_frags)
	lw	$21,%lo(dofrags)($2)
	sw	$0,%lo(acceleratestage)($18)
	addiu	$13,$13,%lo(playeringame)
	addiu	$11,$11,4
	move	$10,$0
	move	$12,$0
	addiu	$19,$19,%lo(cnt_kills)
	addiu	$25,$25,%lo(cnt_items)
	addiu	$24,$24,%lo(cnt_secret)
	addiu	$15,$15,%lo(cnt_frags)
	li	$20,4			# 0x4
$L348:
	lw	$2,0($13)
	addu	$7,$19,$10
	addu	$5,$25,$10
	beq	$2,$0,$L346
	addu	$3,$24,$10

	lw	$4,0($11)
	lw	$6,16($14)
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,3
	addu	$2,$2,$4
	sll	$2,$2,2
	div	$0,$2,$6
	move	$4,$12
	mflo	$2
	sw	$2,0($7)
	lw	$6,4($11)
	lw	$7,20($14)
	sll	$2,$6,1
	addu	$2,$2,$6
	sll	$2,$2,3
	addu	$2,$2,$6
	sll	$2,$2,2
	div	$0,$2,$7
	mflo	$2
	sw	$2,0($5)
	lw	$5,8($11)
	lw	$6,24($14)
	sll	$2,$5,1
	addu	$2,$2,$5
	sll	$2,$2,3
	addu	$2,$2,$5
	sll	$2,$2,2
	div	$0,$2,$6
	mflo	$2
	beq	$21,$0,$L346
	sw	$2,0($3)

	jal	WI_fragSum
	nop

	addu	$3,$15,$10
	sw	$2,0($3)
$L346:
	addiu	$12,$12,1
	addiu	$13,$13,4
	addiu	$11,$11,40
	.set	noat
	xor	$1,$12,$20
	bne	$1,$0,$L348
	.set	at
	addiu	$10,$10,4

	li	$5,82			# 0x52
	jal	S_StartSound
	move	$4,$0

	lw	$2,%lo(acceleratestage)($18)
	li	$3,10			# 0xa
	bne	$2,$0,$L344
	sw	$3,%lo(ng_state)($16)

$L341:
	lw	$31,44($sp)
$L422:
	lw	$21,40($sp)
$L423:
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L343:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L409
	.set	at
	li	$3,4			# 0x4

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L410
	.set	at
	li	$3,6			# 0x6

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L411
	.set	at
	li	$3,8			# 0x8

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L412
	.set	at
	li	$3,10			# 0xa

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L422
	.set	at
	lw	$31,44($sp)

	andi	$3,$2,0x1
	beq	$3,$0,$L423
	lw	$21,40($sp)

	lui	$4,%hi(cnt_pause)
	lw	$3,%lo(cnt_pause)($4)
	addiu	$3,$3,-1
	bne	$3,$0,$L341
	sw	$3,%lo(cnt_pause)($4)

	addiu	$2,$2,1
	sw	$2,%lo(ng_state)($16)
	li	$2,35			# 0x23
	b	$L341
	sw	$2,%lo(cnt_pause)($4)

$L410:
	lui	$2,%hi(bcnt)
	lw	$2,%lo(bcnt)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L413
	li	$5,1			# 0x1

	lui	$2,%hi(plrs)
$L417:
	lw	$6,%lo(plrs)($2)
	lui	$3,%hi(cnt_items)
	lui	$2,%hi(wbs)
	addiu	$3,$3,%lo(cnt_items)
	lui	$5,%hi(playeringame)
	lw	$10,%lo(wbs)($2)
	addiu	$5,$5,%lo(playeringame)
	addiu	$6,$6,8
	addiu	$9,$3,16
	move	$11,$0
$L361:
	lw	$2,0($5)
	beq	$2,$0,$L360
	nop

	lw	$4,0($3)
	addiu	$4,$4,2
	sw	$4,0($3)
	lw	$7,0($6)
	lw	$8,20($10)
	sll	$2,$7,1
	addu	$2,$2,$7
	sll	$2,$2,3
	addu	$2,$2,$7
	sll	$2,$2,2
	div	$0,$2,$8
	mflo	$7
	slt	$4,$4,$7
	bne	$4,$0,$L376
	nop

	sw	$7,0($3)
$L360:
	addiu	$3,$3,4
	addiu	$5,$5,4
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L361
	.set	at
	addiu	$6,$6,40

	bne	$11,$0,$L341
	li	$5,82			# 0x52

$L406:
	jal	S_StartSound
	move	$4,$0

	lw	$2,%lo(ng_state)($16)
	lw	$31,44($sp)
	addiu	$2,$2,1
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,%lo(ng_state)($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,48

$L409:
	lui	$2,%hi(bcnt)
	lw	$2,%lo(bcnt)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L414
	li	$5,1			# 0x1

	lui	$2,%hi(plrs)
$L418:
	lw	$6,%lo(plrs)($2)
	lui	$3,%hi(cnt_kills)
	lui	$2,%hi(wbs)
	addiu	$3,$3,%lo(cnt_kills)
	lui	$5,%hi(playeringame)
	lw	$10,%lo(wbs)($2)
	addiu	$5,$5,%lo(playeringame)
	addiu	$6,$6,4
	addiu	$9,$3,16
	move	$11,$0
$L354:
	lw	$2,0($5)
	beq	$2,$0,$L353
	nop

	lw	$4,0($3)
	addiu	$4,$4,2
	sw	$4,0($3)
	lw	$7,0($6)
	lw	$8,16($10)
	sll	$2,$7,1
	addu	$2,$2,$7
	sll	$2,$2,3
	addu	$2,$2,$7
	sll	$2,$2,2
	div	$0,$2,$8
	mflo	$7
	slt	$4,$4,$7
	bne	$4,$0,$L375
	nop

	sw	$7,0($3)
$L353:
	addiu	$3,$3,4
	addiu	$5,$5,4
	.set	noat
	xor	$1,$9,$3
	bne	$1,$0,$L354
	.set	at
	addiu	$6,$6,40

	bne	$11,$0,$L341
	li	$5,82			# 0x52

	b	$L406
	nop

$L375:
	b	$L353
	li	$11,1			# 0x1

$L412:
	lui	$2,%hi(bcnt)
	lw	$2,%lo(bcnt)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L415
	li	$5,1			# 0x1

	lui	$12,%hi(playeringame)
$L420:
	lui	$11,%hi(cnt_frags)
	addiu	$12,$12,%lo(playeringame)
	addiu	$11,$11,%lo(cnt_frags)
	move	$14,$0
	li	$13,4			# 0x4
$L372:
	lw	$2,0($12)
	beq	$2,$0,$L371
	move	$4,$19

	lw	$10,0($11)
	addiu	$10,$10,1
	jal	WI_fragSum
	sw	$10,0($11)

	slt	$10,$10,$2
	bne	$10,$0,$L379
	nop

	sw	$2,0($11)
$L371:
	addiu	$19,$19,1
	addiu	$12,$12,4
	.set	noat
	xor	$1,$19,$13
	bne	$1,$0,$L372
	.set	at
	addiu	$11,$11,4

	bne	$14,$0,$L422
	lw	$31,44($sp)

	b	$L406
	li	$5,57			# 0x39

$L413:
	jal	S_StartSound
	move	$4,$0

	b	$L417
	lui	$2,%hi(plrs)

$L376:
	b	$L360
	li	$11,1			# 0x1

$L411:
	lui	$2,%hi(bcnt)
	lw	$2,%lo(bcnt)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L416
	li	$5,1			# 0x1

	lui	$2,%hi(plrs)
$L419:
	lw	$6,%lo(plrs)($2)
	lui	$3,%hi(cnt_secret)
	lui	$2,%hi(wbs)
	addiu	$3,$3,%lo(cnt_secret)
	lui	$5,%hi(playeringame)
	lw	$10,%lo(wbs)($2)
	addiu	$5,$5,%lo(playeringame)
	addiu	$6,$6,12
	addiu	$9,$3,16
	move	$11,$0
$L366:
	lw	$2,0($5)
	beq	$2,$0,$L365
	nop

	lw	$4,0($3)
	addiu	$4,$4,2
	sw	$4,0($3)
	lw	$7,0($6)
	lw	$8,24($10)
	sll	$2,$7,1
	addu	$2,$2,$7
	sll	$2,$2,3
	addu	$2,$2,$7
	sll	$2,$2,2
	div	$0,$2,$8
	mflo	$7
	slt	$4,$4,$7
	bne	$4,$0,$L377
	nop

	sw	$7,0($3)
$L365:
	addiu	$3,$3,4
	addiu	$5,$5,4
	.set	noat
	xor	$1,$3,$9
	bne	$1,$0,$L366
	.set	at
	addiu	$6,$6,40

	bne	$11,$0,$L422
	lw	$31,44($sp)

	li	$5,82			# 0x52
	jal	S_StartSound
	move	$4,$0

	lui	$2,%hi(dofrags)
	lw	$5,%lo(dofrags)($2)
	li	$3,1			# 0x1
	lw	$2,%lo(ng_state)($16)
	li	$4,3			# 0x3
	movz	$3,$4,$5
	addu	$2,$2,$3
	b	$L341
	sw	$2,%lo(ng_state)($16)

$L377:
	b	$L365
	li	$11,1			# 0x1

$L379:
	b	$L371
	li	$14,1			# 0x1

$L414:
	jal	S_StartSound
	move	$4,$0

	b	$L418
	lui	$2,%hi(plrs)

$L344:
	li	$5,3			# 0x3
	jal	S_StartSound
	move	$4,$0

	lw	$3,%lo(gamemode)($17)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L374
	.set	at
	lui	$2,%hi(state)

	li	$3,-1			# 0xffffffffffffffff
	sw	$3,%lo(state)($2)
	lui	$2,%hi(cnt)
	li	$3,10			# 0xa
	sw	$0,%lo(acceleratestage)($18)
	b	$L341
	sw	$3,%lo(cnt)($2)

$L416:
	jal	S_StartSound
	move	$4,$0

	b	$L419
	lui	$2,%hi(plrs)

$L415:
	jal	S_StartSound
	move	$4,$0

	b	$L420
	lui	$12,%hi(playeringame)

$L374:
	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lui	$3,%hi(state)
	lw	$2,0($2)
	li	$4,1			# 0x1
	sw	$4,%lo(state)($3)
	slt	$2,$2,3
	lui	$3,%hi(cnt)
	li	$4,140			# 0x8c
	sw	$0,%lo(acceleratestage)($18)
	beq	$2,$0,$L341
	sw	$4,%lo(cnt)($3)

	lw	$31,44($sp)
	lw	$21,40($sp)
	lw	$20,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	WI_initAnimatedBack.part.0
	addiu	$sp,$sp,48

	.set	macro
	.set	reorder
	.end	WI_updateNetgameStats
	.size	WI_updateNetgameStats, .-WI_updateNetgameStats
	.align	2
	.globl	WI_drawNetgameStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawNetgameStats
	.type	WI_drawNetgameStats, @function
WI_drawNetgameStats:
	.frame	$sp,88,$31		# vars= 32, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-88
	sw	$fp,80($sp)
	lui	$fp,%hi(percent)
	lw	$2,%lo(percent)($fp)
	sw	$21,68($sp)
	lbu	$21,1($2)
	lbu	$2,0($2)
	sll	$21,$21,8
	lui	$3,%hi(background)
	or	$21,$21,$2
	lw	$6,%lo(background)($3)
	sll	$2,$21,16
	sra	$2,$2,16
	move	$5,$0
	move	$4,$0
	sw	$23,76($sp)
	lui	$23,%hi(star)
	sw	$31,84($sp)
	sw	$2,16($sp)
	sw	$22,72($sp)
	sw	$16,48($sp)
	sw	$20,64($sp)
	sw	$19,60($sp)
	sw	$18,56($sp)
	jal	V_DrawPatch
	sw	$17,52($sp)

	jal	WI_drawAnimatedBack
	lui	$16,%hi(kills)

	jal	WI_drawLF
	lui	$22,%hi(dofrags)

	lw	$3,%lo(star)($23)
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$4,$2,16
	lw	$6,%lo(kills)($16)
	sra	$4,$4,16
	srl	$2,$2,15
	addu	$2,$2,$4
	lw	$3,%lo(dofrags)($22)
	lbu	$4,1($6)
	sra	$2,$2,1
	lbu	$5,0($6)
	addiu	$2,$2,32
	sltu	$3,$3,1
	sll	$2,$2,16
	sll	$4,$4,8
	sll	$3,$3,5
	or	$4,$4,$5
	sra	$2,$2,16
	addu	$2,$2,$3
	sll	$4,$4,16
	addiu	$2,$2,64
	sra	$4,$4,16
	subu	$4,$2,$4
	jal	V_DrawPatch
	li	$5,50			# 0x32

	lw	$3,%lo(star)($23)
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$4,$2,16
	lui	$3,%hi(items)
	lw	$6,%lo(items)($3)
	sra	$4,$4,16
	srl	$2,$2,15
	addu	$2,$2,$4
	lw	$3,%lo(dofrags)($22)
	lbu	$4,1($6)
	sra	$2,$2,1
	lbu	$5,0($6)
	addiu	$2,$2,32
	sltu	$3,$3,1
	sll	$2,$2,16
	sll	$4,$4,8
	sll	$3,$3,5
	or	$4,$4,$5
	sra	$2,$2,16
	addu	$2,$2,$3
	sll	$4,$4,16
	addiu	$2,$2,128
	sra	$4,$4,16
	subu	$4,$2,$4
	jal	V_DrawPatch
	li	$5,50			# 0x32

	lw	$3,%lo(star)($23)
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$4,$2,16
	lui	$3,%hi(secret)
	lw	$6,%lo(secret)($3)
	sra	$4,$4,16
	srl	$2,$2,15
	addu	$2,$2,$4
	lw	$3,%lo(dofrags)($22)
	lbu	$4,1($6)
	sra	$2,$2,1
	lbu	$5,0($6)
	addiu	$2,$2,32
	sltu	$3,$3,1
	sll	$2,$2,16
	sll	$4,$4,8
	sll	$3,$3,5
	or	$4,$4,$5
	sra	$2,$2,16
	addu	$2,$2,$3
	sll	$4,$4,16
	addiu	$2,$2,192
	sra	$4,$4,16
	subu	$4,$2,$4
	jal	V_DrawPatch
	li	$5,50			# 0x32

	lw	$2,%lo(dofrags)($22)
	bne	$2,$0,$L444
	lw	$3,%lo(star)($23)

	lw	$2,%lo(kills)($16)
$L448:
	lui	$19,%hi(p)
	lbu	$17,3($2)
	lbu	$2,2($2)
	sll	$17,$17,8
	or	$17,$17,$2
	lui	$2,%hi(playeringame)
	addiu	$2,$2,%lo(playeringame)
	sw	$2,20($sp)
	lui	$2,%hi(me)
	sw	$2,28($sp)
	lui	$2,%hi(cnt_kills)
	addiu	$2,$2,%lo(cnt_kills)
	sw	$2,32($sp)
	lui	$2,%hi(cnt_items)
	addiu	$2,$2,%lo(cnt_items)
	sll	$17,$17,16
	sw	$2,36($sp)
	lui	$2,%hi(cnt_secret)
	sra	$17,$17,16
	addiu	$2,$2,%lo(cnt_secret)
	addiu	$17,$17,50
	addiu	$19,$19,%lo(p)
	move	$21,$0
	move	$18,$0
	sw	$2,40($sp)
$L432:
	lw	$2,20($sp)
	addu	$2,$2,$21
	lw	$2,0($2)
	beq	$2,$0,$L426
	lw	$4,%lo(star)($23)

	lw	$6,0($19)
	lbu	$2,1($4)
	lbu	$4,0($4)
	sll	$2,$2,8
	or	$2,$2,$4
	sll	$5,$2,16
	sra	$5,$5,16
	srl	$16,$2,15
	lbu	$4,1($6)
	addu	$16,$16,$5
	lw	$2,%lo(dofrags)($22)
	lbu	$5,0($6)
	sra	$16,$16,1
	addiu	$16,$16,32
	sll	$4,$4,8
	or	$4,$4,$5
	sltu	$2,$2,1
	sll	$16,$16,16
	sll	$2,$2,5
	sra	$16,$16,16
	sll	$4,$4,16
	addu	$16,$16,$2
	sra	$4,$4,16
	move	$5,$17
	jal	V_DrawPatch
	subu	$4,$16,$4

	lw	$2,28($sp)
	lw	$2,%lo(me)($2)
	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L445
	.set	at
	lw	$6,%lo(star)($23)

	lw	$2,32($sp)
$L447:
	addiu	$20,$17,10
	addu	$2,$2,$21
	lw	$2,0($2)
	bltz	$2,$L428
	sw	$2,24($sp)

	lw	$2,16($sp)
	lw	$6,%lo(percent)($fp)
	addiu	$4,$16,64
	subu	$4,$4,$2
	move	$5,$20
	jal	V_DrawPatch
	sw	$4,44($sp)

	lw	$2,24($sp)
	lw	$4,44($sp)
	li	$7,-1			# 0xffffffffffffffff
	move	$6,$2
	jal	WI_drawNum
	move	$5,$20

$L428:
	lw	$2,36($sp)
	addu	$2,$2,$21
	lw	$2,0($2)
	bltz	$2,$L429
	sw	$2,24($sp)

	lw	$2,16($sp)
	lw	$6,%lo(percent)($fp)
	addiu	$4,$16,128
	subu	$4,$4,$2
	move	$5,$20
	jal	V_DrawPatch
	sw	$4,44($sp)

	lw	$2,24($sp)
	lw	$4,44($sp)
	li	$7,-1			# 0xffffffffffffffff
	move	$6,$2
	jal	WI_drawNum
	move	$5,$20

$L429:
	lw	$2,40($sp)
	addu	$2,$2,$21
	lw	$2,0($2)
	bltz	$2,$L430
	sw	$2,24($sp)

	lw	$2,16($sp)
	lw	$6,%lo(percent)($fp)
	addiu	$4,$16,192
	subu	$4,$4,$2
	move	$5,$20
	jal	V_DrawPatch
	sw	$4,44($sp)

	lw	$2,24($sp)
	lw	$4,44($sp)
	li	$7,-1			# 0xffffffffffffffff
	move	$6,$2
	jal	WI_drawNum
	move	$5,$20

$L430:
	lw	$2,%lo(dofrags)($22)
	bne	$2,$0,$L446
	lui	$2,%hi(cnt_frags)

	addiu	$17,$17,33
$L426:
	addiu	$18,$18,1
	li	$2,4			# 0x4
	addiu	$19,$19,4
	.set	noat
	xor	$1,$18,$2
	bne	$1,$0,$L432
	.set	at
	addiu	$21,$21,4

	lw	$31,84($sp)
	lw	$fp,80($sp)
	lw	$23,76($sp)
	lw	$22,72($sp)
	lw	$21,68($sp)
	lw	$20,64($sp)
	lw	$19,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	jr	$31
	addiu	$sp,$sp,88

$L446:
	addiu	$2,$2,%lo(cnt_frags)
	addu	$2,$2,$21
	lw	$6,0($2)
	li	$7,-1			# 0xffffffffffffffff
	move	$5,$20
	jal	WI_drawNum
	addiu	$4,$16,256

	b	$L426
	addiu	$17,$17,33

$L445:
	lw	$2,0($19)
	lbu	$4,1($2)
	lbu	$2,0($2)
	sll	$4,$4,8
	or	$4,$4,$2
	sll	$4,$4,16
	sra	$4,$4,16
	move	$5,$17
	jal	V_DrawPatch
	subu	$4,$16,$4

	b	$L447
	lw	$2,32($sp)

$L444:
	lui	$4,%hi(frags)
	lbu	$2,1($3)
	lbu	$3,0($3)
	sll	$2,$2,8
	lw	$6,%lo(frags)($4)
	or	$2,$2,$3
	sll	$5,$2,16
	lbu	$4,1($6)
	sra	$5,$5,16
	srl	$2,$2,15
	lbu	$3,0($6)
	addu	$2,$2,$5
	sra	$2,$2,1
	sll	$4,$4,8
	or	$4,$4,$3
	addiu	$2,$2,288
	sll	$2,$2,16
	sll	$4,$4,16
	sra	$2,$2,16
	sra	$4,$4,16
	li	$5,50			# 0x32
	jal	V_DrawPatch
	subu	$4,$2,$4

	b	$L448
	lw	$2,%lo(kills)($16)

	.set	macro
	.set	reorder
	.end	WI_drawNetgameStats
	.size	WI_drawNetgameStats, .-WI_drawNetgameStats
	.align	2
	.globl	WI_initStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_initStats
	.type	WI_initStats, @function
WI_initStats:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$5,%hi(state)
	sw	$0,%lo(state)($5)
	lui	$5,%hi(acceleratestage)
	lui	$2,%hi(gamemode)
	sw	$0,%lo(acceleratestage)($5)
	li	$6,1			# 0x1
	lui	$5,%hi(sp_state)
	lw	$4,%lo(gamemode)($2)
	sw	$6,%lo(sp_state)($5)
	li	$2,-1			# 0xffffffffffffffff
	lui	$5,%hi(cnt_secret)
	sw	$2,%lo(cnt_secret)($5)
	lui	$5,%hi(cnt_items)
	sw	$2,%lo(cnt_items)($5)
	lui	$5,%hi(cnt_kills)
	sw	$2,%lo(cnt_kills)($5)
	lui	$5,%hi(cnt_par)
	sw	$2,%lo(cnt_par)($5)
	lui	$5,%hi(cnt_time)
	sw	$2,%lo(cnt_time)($5)
	li	$3,2			# 0x2
	lui	$2,%hi(cnt_pause)
	li	$5,35			# 0x23
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L451
	.set	at
	sw	$5,%lo(cnt_pause)($2)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L451
	nop

	j	WI_initAnimatedBack.part.0
	nop

$L451:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_initStats
	.size	WI_initStats, .-WI_initStats
	.align	2
	.globl	WI_updateStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_updateStats
	.type	WI_updateStats, @function
WI_updateStats:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$17,24($sp)
	lui	$17,%hi(gamemode)
	lw	$3,%lo(gamemode)($17)
	li	$2,2			# 0x2
	sw	$31,36($sp)
	sw	$19,32($sp)
	sw	$18,28($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L453
	.set	at
	sw	$16,20($sp)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L486
	lui	$18,%hi(acceleratestage)

	jal	WI_updateAnimatedBack.part.0
	nop

$L453:
	lui	$18,%hi(acceleratestage)
$L486:
	lw	$3,%lo(acceleratestage)($18)
	lui	$16,%hi(sp_state)
	beq	$3,$0,$L454
	lw	$2,%lo(sp_state)($16)

	li	$19,10			# 0xa
	.set	noat
	xor	$1,$2,$19
	bne	$1,$0,$L476
	.set	at
	lui	$2,%hi(me)

$L455:
	li	$5,3			# 0x3
	jal	S_StartSound
	move	$4,$0

	lw	$3,%lo(gamemode)($17)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L469
	.set	at
	lui	$2,%hi(state)

	li	$3,-1			# 0xffffffffffffffff
	sw	$3,%lo(state)($2)
	lui	$2,%hi(cnt)
	li	$3,10			# 0xa
	sw	$0,%lo(acceleratestage)($18)
	sw	$3,%lo(cnt)($2)
$L452:
	lw	$31,36($sp)
$L487:
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L454:
	li	$3,2			# 0x2
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L477
	.set	at
	li	$3,4			# 0x4

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L478
	.set	at
	li	$3,6			# 0x6

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L479
	.set	at
	li	$3,8			# 0x8

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L480
	.set	at
	li	$3,10			# 0xa

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L452
	.set	at
	andi	$3,$2,0x1

	beq	$3,$0,$L487
	lw	$31,36($sp)

	lui	$4,%hi(cnt_pause)
	lw	$3,%lo(cnt_pause)($4)
	addiu	$3,$3,-1
	bne	$3,$0,$L452
	sw	$3,%lo(cnt_pause)($4)

	addiu	$2,$2,1
	sw	$2,%lo(sp_state)($16)
	li	$2,35			# 0x23
	b	$L452
	sw	$2,%lo(cnt_pause)($4)

$L476:
	lw	$3,%lo(me)($2)
	lui	$4,%hi(plrs)
	sll	$2,$3,2
	lw	$4,%lo(plrs)($4)
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$4,$4,$2
	lw	$11,4($4)
	lui	$5,%hi(wbs)
	sll	$2,$11,1
	lw	$5,%lo(wbs)($5)
	addu	$2,$2,$11
	sll	$2,$2,3
	lw	$12,16($5)
	addu	$2,$2,$11
	sll	$2,$2,2
	div	$0,$2,$12
	lw	$8,8($4)
	lw	$10,20($5)
	sll	$6,$8,1
	addu	$6,$6,$8
	sll	$6,$6,3
	addu	$6,$6,$8
	sll	$6,$6,2
	lw	$7,12($4)
	lw	$9,24($5)
	sll	$3,$7,1
	addu	$3,$3,$7
	sll	$3,$3,3
	addu	$3,$3,$7
	sll	$3,$3,2
	lw	$8,16($4)
	li	$2,-368181248			# 0xffffffffea0e0000
	ori	$2,$2,0xa0eb
	lw	$7,32($5)
	sra	$12,$8,31
	sra	$11,$7,31
	li	$5,82			# 0x52
	move	$4,$0
	sw	$0,%lo(acceleratestage)($18)
	mflo	$13
	div	$0,$6,$10
	lui	$6,%hi(cnt_kills)
	sw	$13,%lo(cnt_kills)($6)
	lui	$6,%hi(cnt_secret)
	mflo	$10
	div	$0,$3,$9
	lui	$3,%hi(cnt_items)
	sw	$10,%lo(cnt_items)($3)
	mflo	$9
	mult	$8,$2
	sw	$9,%lo(cnt_secret)($6)
	mfhi	$3
	mult	$7,$2
	addu	$3,$3,$8
	mfhi	$2
	sra	$3,$3,5
	addu	$2,$2,$7
	subu	$3,$3,$12
	lui	$6,%hi(cnt_time)
	sra	$2,$2,5
	subu	$2,$2,$11
	sw	$3,%lo(cnt_time)($6)
	lui	$3,%hi(cnt_par)
	jal	S_StartSound
	sw	$2,%lo(cnt_par)($3)

	lw	$2,%lo(acceleratestage)($18)
	bne	$2,$0,$L455
	sw	$19,%lo(sp_state)($16)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L478:
	lui	$17,%hi(cnt_items)
	lui	$2,%hi(bcnt)
	lw	$3,%lo(cnt_items)($17)
	lw	$2,%lo(bcnt)($2)
	addiu	$3,$3,2
	andi	$2,$2,0x3
	beq	$2,$0,$L481
	sw	$3,%lo(cnt_items)($17)

$L462:
	lui	$2,%hi(me)
	lw	$5,%lo(me)($2)
	lui	$4,%hi(plrs)
	sll	$2,$5,2
	lw	$4,%lo(plrs)($4)
	addu	$2,$2,$5
	sll	$2,$2,3
	addu	$2,$4,$2
	lw	$4,8($2)
	lui	$5,%hi(wbs)
	sll	$2,$4,1
	lw	$5,%lo(wbs)($5)
	addu	$2,$2,$4
	sll	$2,$2,3
	lw	$5,20($5)
	addu	$2,$2,$4
	sll	$2,$2,2
	div	$0,$2,$5
	mflo	$6
	slt	$3,$3,$6
	bne	$3,$0,$L487
	lw	$31,36($sp)

	li	$5,82			# 0x52
	move	$4,$0
	jal	S_StartSound
	sw	$6,%lo(cnt_items)($17)

	lw	$2,%lo(sp_state)($16)
	addiu	$2,$2,1
	b	$L452
	sw	$2,%lo(sp_state)($16)

$L477:
	lui	$17,%hi(cnt_kills)
	lui	$2,%hi(bcnt)
	lw	$3,%lo(cnt_kills)($17)
	lw	$2,%lo(bcnt)($2)
	addiu	$3,$3,2
	andi	$2,$2,0x3
	beq	$2,$0,$L482
	sw	$3,%lo(cnt_kills)($17)

$L458:
	lui	$2,%hi(me)
	lw	$5,%lo(me)($2)
	lui	$4,%hi(plrs)
	sll	$2,$5,2
	lw	$4,%lo(plrs)($4)
	addu	$2,$2,$5
	sll	$2,$2,3
	addu	$2,$4,$2
	lw	$4,4($2)
	lui	$5,%hi(wbs)
	sll	$2,$4,1
	lw	$5,%lo(wbs)($5)
	addu	$2,$2,$4
	sll	$2,$2,3
	lw	$5,16($5)
	addu	$2,$2,$4
	sll	$2,$2,2
	div	$0,$2,$5
	mflo	$6
	slt	$3,$3,$6
	bne	$3,$0,$L487
	lw	$31,36($sp)

	li	$5,82			# 0x52
	move	$4,$0
	jal	S_StartSound
	sw	$6,%lo(cnt_kills)($17)

	lw	$2,%lo(sp_state)($16)
	lw	$31,36($sp)
	addiu	$2,$2,1
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	sw	$2,%lo(sp_state)($16)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L480:
	lui	$2,%hi(bcnt)
	lw	$2,%lo(bcnt)($2)
	andi	$2,$2,0x3
	beq	$2,$0,$L483
	li	$5,1			# 0x1

	lui	$2,%hi(me)
$L485:
	lw	$4,%lo(me)($2)
	lui	$3,%hi(plrs)
	sll	$2,$4,2
	lw	$3,%lo(plrs)($3)
	addu	$2,$2,$4
	sll	$2,$2,3
	addu	$2,$3,$2
	lui	$4,%hi(wbs)
	lw	$6,16($2)
	lw	$4,%lo(wbs)($4)
	li	$2,-368181248			# 0xffffffffea0e0000
	ori	$2,$2,0xa0eb
	lw	$5,32($4)
	mult	$6,$2
	lui	$9,%hi(cnt_time)
	mfhi	$3
	mult	$5,$2
	lw	$4,%lo(cnt_time)($9)
	mfhi	$2
	lui	$8,%hi(cnt_par)
	addu	$3,$3,$6
	lw	$7,%lo(cnt_par)($8)
	sra	$6,$6,31
	addu	$2,$2,$5
	sra	$3,$3,5
	subu	$3,$3,$6
	addiu	$4,$4,3
	sra	$5,$5,31
	sra	$2,$2,5
	addiu	$6,$7,3
	subu	$2,$2,$5
	slt	$7,$4,$3
	movz	$4,$3,$7
	slt	$5,$6,$2
	sw	$4,%lo(cnt_time)($9)
	bne	$5,$0,$L452
	sw	$6,%lo(cnt_par)($8)

	slt	$3,$4,$3
	bne	$3,$0,$L452
	sw	$2,%lo(cnt_par)($8)

	li	$5,82			# 0x52
	jal	S_StartSound
	move	$4,$0

	lw	$2,%lo(sp_state)($16)
	addiu	$2,$2,1
	b	$L452
	sw	$2,%lo(sp_state)($16)

$L481:
	li	$5,1			# 0x1
	jal	S_StartSound
	move	$4,$0

	b	$L462
	lw	$3,%lo(cnt_items)($17)

$L479:
	lui	$17,%hi(cnt_secret)
	lui	$2,%hi(bcnt)
	lw	$3,%lo(cnt_secret)($17)
	lw	$2,%lo(bcnt)($2)
	addiu	$3,$3,2
	andi	$2,$2,0x3
	beq	$2,$0,$L484
	sw	$3,%lo(cnt_secret)($17)

$L464:
	lui	$2,%hi(me)
	lw	$5,%lo(me)($2)
	lui	$4,%hi(plrs)
	sll	$2,$5,2
	lw	$4,%lo(plrs)($4)
	addu	$2,$2,$5
	sll	$2,$2,3
	addu	$2,$4,$2
	lw	$4,12($2)
	lui	$5,%hi(wbs)
	sll	$2,$4,1
	lw	$5,%lo(wbs)($5)
	addu	$2,$2,$4
	sll	$2,$2,3
	lw	$5,24($5)
	addu	$2,$2,$4
	sll	$2,$2,2
	div	$0,$2,$5
	mflo	$6
	slt	$3,$3,$6
	bne	$3,$0,$L487
	lw	$31,36($sp)

	li	$5,82			# 0x52
	move	$4,$0
	jal	S_StartSound
	sw	$6,%lo(cnt_secret)($17)

	lw	$2,%lo(sp_state)($16)
	addiu	$2,$2,1
	b	$L452
	sw	$2,%lo(sp_state)($16)

$L482:
	li	$5,1			# 0x1
	jal	S_StartSound
	move	$4,$0

	b	$L458
	lw	$3,%lo(cnt_kills)($17)

$L484:
	li	$5,1			# 0x1
	jal	S_StartSound
	move	$4,$0

	b	$L464
	lw	$3,%lo(cnt_secret)($17)

$L483:
	jal	S_StartSound
	move	$4,$0

	b	$L485
	lui	$2,%hi(me)

$L469:
	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lui	$3,%hi(state)
	lw	$2,0($2)
	li	$4,1			# 0x1
	sw	$4,%lo(state)($3)
	slt	$2,$2,3
	lui	$3,%hi(cnt)
	li	$4,140			# 0x8c
	sw	$0,%lo(acceleratestage)($18)
	beq	$2,$0,$L452
	sw	$4,%lo(cnt)($3)

	lw	$31,36($sp)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	j	WI_initAnimatedBack.part.0
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	WI_updateStats
	.size	WI_updateStats, .-WI_updateStats
	.align	2
	.globl	WI_drawStats
	.set	nomips16
	.set	nomicromips
	.ent	WI_drawStats
	.type	WI_drawStats, @function
WI_drawStats:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, gp= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(num)
	addiu	$sp,$sp,-32
	lw	$3,%lo(num)($2)
	sw	$31,28($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$18,24($sp)
	lbu	$2,3($3)
	lbu	$3,2($3)
	sll	$2,$2,8
	or	$2,$2,$3
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$3,$2,1
	addu	$2,$3,$2
	lui	$3,%hi(background)
	lw	$6,%lo(background)($3)
	srl	$16,$2,31
	move	$5,$0
	move	$4,$0
	jal	V_DrawPatch
	addu	$16,$16,$2

	jal	WI_drawAnimatedBack
	sra	$16,$16,1

	jal	WI_drawLF
	nop

	lui	$2,%hi(kills)
	lw	$6,%lo(kills)($2)
	li	$5,50			# 0x32
	jal	V_DrawPatch
	li	$4,50			# 0x32

	lui	$2,%hi(cnt_kills)
	lw	$17,%lo(cnt_kills)($2)
	bltz	$17,$L489
	lui	$2,%hi(percent)

	lw	$6,%lo(percent)($2)
	li	$5,50			# 0x32
	jal	V_DrawPatch
	li	$4,270			# 0x10e

	li	$7,-1			# 0xffffffffffffffff
	move	$6,$17
	li	$5,50			# 0x32
	jal	WI_drawNum
	li	$4,270			# 0x10e

$L489:
	lui	$2,%hi(items)
	lw	$6,%lo(items)($2)
	addiu	$17,$16,50
	move	$5,$17
	jal	V_DrawPatch
	li	$4,50			# 0x32

	lui	$2,%hi(cnt_items)
	lw	$18,%lo(cnt_items)($2)
	bltz	$18,$L490
	lui	$2,%hi(percent)

	lw	$6,%lo(percent)($2)
	move	$5,$17
	jal	V_DrawPatch
	li	$4,270			# 0x10e

	li	$7,-1			# 0xffffffffffffffff
	move	$6,$18
	move	$5,$17
	jal	WI_drawNum
	li	$4,270			# 0x10e

$L490:
	lui	$2,%hi(sp_secret)
	addiu	$16,$16,25
	lw	$6,%lo(sp_secret)($2)
	sll	$16,$16,1
	move	$5,$16
	jal	V_DrawPatch
	li	$4,50			# 0x32

	lui	$2,%hi(cnt_secret)
	lw	$17,%lo(cnt_secret)($2)
	bltz	$17,$L491
	lui	$2,%hi(percent)

	lw	$6,%lo(percent)($2)
	move	$5,$16
	jal	V_DrawPatch
	li	$4,270			# 0x10e

	li	$7,-1			# 0xffffffffffffffff
	move	$6,$17
	move	$5,$16
	jal	WI_drawNum
	li	$4,270			# 0x10e

$L491:
	lui	$2,%hi(timepatch)
	lw	$6,%lo(timepatch)($2)
	li	$5,168			# 0xa8
	jal	V_DrawPatch
	li	$4,16			# 0x10

	lui	$2,%hi(cnt_time)
	lw	$6,%lo(cnt_time)($2)
	li	$5,168			# 0xa8
	jal	WI_drawTime
	li	$4,144			# 0x90

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	bne	$2,$0,$L494
	lw	$31,28($sp)

	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,32

$L494:
	lui	$2,%hi(par)
	lw	$6,%lo(par)($2)
	li	$5,168			# 0xa8
	jal	V_DrawPatch
	li	$4,176			# 0xb0

	lui	$2,%hi(cnt_par)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	lw	$6,%lo(cnt_par)($2)
	li	$5,168			# 0xa8
	li	$4,304			# 0x130
	j	WI_drawTime
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	WI_drawStats
	.size	WI_drawStats, .-WI_drawStats
	.align	2
	.globl	WI_checkForAccelerate
	.set	nomips16
	.set	nomicromips
	.ent	WI_checkForAccelerate
	.type	WI_checkForAccelerate, @function
WI_checkForAccelerate:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(playeringame)
	lui	$2,%hi(players)
	lui	$5,%hi(players+1152)
	addiu	$3,$3,%lo(playeringame)
	addiu	$2,$2,%lo(players)
	addiu	$5,$5,%lo(players+1152)
$L501:
	lw	$4,0($3)
	beq	$4,$0,$L496
	nop

	lbu	$4,13($2)
	andi	$6,$4,0x1
	beq	$6,$0,$L497
	move	$6,$0

	lw	$6,196($2)
	beq	$6,$0,$L507
	lui	$6,%hi(acceleratestage)

$L498:
	li	$6,1			# 0x1
$L497:
	andi	$4,$4,0x2
	beq	$4,$0,$L499
	sw	$6,196($2)

	lw	$4,200($2)
	beq	$4,$0,$L508
	lui	$4,%hi(acceleratestage)

$L500:
	li	$4,1			# 0x1
	sw	$4,200($2)
$L496:
	addiu	$2,$2,288
	.set	noat
	xor	$1,$2,$5
	bne	$1,$0,$L501
	.set	at
	addiu	$3,$3,4

	jr	$31
	nop

$L499:
	b	$L496
	sw	$0,200($2)

$L508:
	li	$6,1			# 0x1
	b	$L500
	sw	$6,%lo(acceleratestage)($4)

$L507:
	li	$7,1			# 0x1
	b	$L498
	sw	$7,%lo(acceleratestage)($6)

	.set	macro
	.set	reorder
	.end	WI_checkForAccelerate
	.size	WI_checkForAccelerate, .-WI_checkForAccelerate
	.align	2
	.globl	WI_Ticker
	.set	nomips16
	.set	nomicromips
	.ent	WI_Ticker
	.type	WI_Ticker, @function
WI_Ticker:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(bcnt)
	lw	$2,%lo(bcnt)($3)
	addiu	$sp,$sp,-24
	addiu	$2,$2,1
	li	$4,1			# 0x1
	sw	$2,%lo(bcnt)($3)
	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L520
	.set	at
	sw	$31,20($sp)

$L510:
	jal	WI_checkForAccelerate
	nop

	lui	$2,%hi(state)
	lw	$2,%lo(state)($2)
	beq	$2,$0,$L512
	li	$3,1			# 0x1

$L525:
	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L513
	.set	at
	li	$3,-1			# 0xffffffffffffffff

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L521
	.set	at
	lui	$2,%hi(gamemode)

$L509:
	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

$L520:
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L522
	.set	at
	li	$5,1			# 0x1

	jal	S_ChangeMusic
	li	$4,28			# 0x1c

	jal	WI_checkForAccelerate
	nop

	lui	$2,%hi(state)
	lw	$2,%lo(state)($2)
	bne	$2,$0,$L525
	li	$3,1			# 0x1

$L512:
	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	bne	$2,$0,$L524
	lui	$2,%hi(netgame)

	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L517
	lw	$31,20($sp)

	j	WI_updateNetgameStats
	addiu	$sp,$sp,24

$L521:
	lw	$3,%lo(gamemode)($2)
	li	$2,2			# 0x2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L518
	.set	at
	lui	$2,%hi(wbs)

	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L526
	lui	$3,%hi(cnt)

	jal	WI_updateAnimatedBack.part.0
	nop

$L518:
	lui	$3,%hi(cnt)
$L526:
	lw	$2,%lo(cnt)($3)
	addiu	$2,$2,-1
	bne	$2,$0,$L509
	sw	$2,%lo(cnt)($3)

	lw	$31,20($sp)
	j	G_WorldDone
	addiu	$sp,$sp,24

$L513:
	lw	$31,20($sp)
	j	WI_updateShowNextLoc
	addiu	$sp,$sp,24

$L524:
	lw	$31,20($sp)
	j	WI_updateDeathmatchStats
	addiu	$sp,$sp,24

$L522:
	jal	S_ChangeMusic
	li	$4,67			# 0x43

	b	$L510
	nop

$L517:
	j	WI_updateStats
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	WI_Ticker
	.size	WI_Ticker, .-WI_Ticker
	.section	.rodata.str1.4
	.align	2
$LC30:
	.ascii	"STFST01\000"
	.align	2
$LC31:
	.ascii	"STFDEAD0\000"
	.text
	.align	2
	.globl	WI_loadData
	.set	nomips16
	.set	nomicromips
	.ent	WI_loadData
	.type	WI_loadData, @function
WI_loadData:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(gamemode)
	lw	$3,%lo(gamemode)($2)
	addiu	$sp,$sp,-24
	li	$2,2			# 0x2
	move	$6,$0
	sw	$31,20($sp)
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L531
	.set	at
	li	$5,1			# 0x1

	jal	Z_Malloc
	li	$4,36			# 0x24

	lui	$4,%hi(WI_loadCallback)
$L532:
	lui	$3,%hi(lnames)
	addiu	$4,$4,%lo(WI_loadCallback)
	jal	WI_loadUnloadData
	sw	$2,%lo(lnames)($3)

	lui	$4,%hi($LC30)
	li	$5,1			# 0x1
	jal	W_CacheLumpName
	addiu	$4,$4,%lo($LC30)

	lui	$4,%hi($LC31)
	lui	$3,%hi(star)
	li	$5,1			# 0x1
	addiu	$4,$4,%lo($LC31)
	jal	W_CacheLumpName
	sw	$2,%lo(star)($3)

	lw	$31,20($sp)
	lui	$3,%hi(bstar)
	sw	$2,%lo(bstar)($3)
	jr	$31
	addiu	$sp,$sp,24

$L531:
	li	$3,32			# 0x20
	li	$4,128			# 0x80
	lui	$2,%hi(NUMCMAPS)
	jal	Z_Malloc
	sw	$3,%lo(NUMCMAPS)($2)

	b	$L532
	lui	$4,%hi(WI_loadCallback)

	.set	macro
	.set	reorder
	.end	WI_loadData
	.size	WI_loadData, .-WI_loadData
	.align	2
	.globl	WI_unloadData
	.set	nomips16
	.set	nomicromips
	.ent	WI_unloadData
	.type	WI_unloadData, @function
WI_unloadData:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$4,%hi(WI_unloadCallback)
	j	WI_loadUnloadData
	addiu	$4,$4,%lo(WI_unloadCallback)

	.set	macro
	.set	reorder
	.end	WI_unloadData
	.size	WI_unloadData, .-WI_unloadData
	.align	2
	.globl	WI_Drawer
	.set	nomips16
	.set	nomicromips
	.ent	WI_Drawer
	.type	WI_Drawer, @function
WI_Drawer:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(state)
	lw	$2,%lo(state)($2)
	beq	$2,$0,$L535
	li	$3,1			# 0x1

	.set	noat
	xor	$1,$2,$3
	beq	$1,$0,$L542
	.set	at
	li	$4,-1			# 0xffffffffffffffff

	.set	noat
	xor	$1,$2,$4
	beq	$1,$0,$L543
	.set	at
	lui	$2,%hi(snl_pointeron)

	jr	$31
	nop

$L543:
	sw	$3,%lo(snl_pointeron)($2)
$L542:
	j	WI_drawShowNextLoc
	nop

$L535:
	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	bne	$2,$0,$L544
	lui	$2,%hi(netgame)

	lw	$2,%lo(netgame)($2)
	beq	$2,$0,$L540
	nop

	j	WI_drawNetgameStats
	nop

$L544:
	j	WI_drawDeathmatchStats
	nop

$L540:
	j	WI_drawStats
	nop

	.set	macro
	.set	reorder
	.end	WI_Drawer
	.size	WI_Drawer, .-WI_Drawer
	.align	2
	.globl	WI_initVariables
	.set	nomips16
	.set	nomicromips
	.ent	WI_initVariables
	.type	WI_initVariables, @function
WI_initVariables:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$3,%hi(wbs)
	sw	$4,%lo(wbs)($3)
	lui	$3,%hi(acceleratestage)
	sw	$0,%lo(acceleratestage)($3)
	lui	$3,%hi(bcnt)
	lw	$6,36($4)
	sw	$0,%lo(bcnt)($3)
	lui	$3,%hi(cnt)
	sw	$0,%lo(cnt)($3)
	lw	$2,16($4)
	lui	$3,%hi(me)
	addiu	$5,$4,40
	sw	$6,%lo(me)($3)
	lui	$3,%hi(plrs)
	bne	$2,$0,$L548
	sw	$5,%lo(plrs)($3)

	li	$2,1			# 0x1
	sw	$2,16($4)
$L548:
	lw	$2,20($4)
	bne	$2,$0,$L549
	li	$2,1			# 0x1

	sw	$2,20($4)
$L549:
	lw	$2,24($4)
	bne	$2,$0,$L552
	lui	$2,%hi(gamemode)

	li	$2,1			# 0x1
	sw	$2,24($4)
	lui	$2,%hi(gamemode)
$L552:
	lw	$3,%lo(gamemode)($2)
	li	$2,3			# 0x3
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L553
	.set	at
	nop

	lw	$2,0($4)
	slt	$3,$2,3
	bne	$3,$0,$L553
	addiu	$2,$2,-3

	sw	$2,0($4)
$L553:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	WI_initVariables
	.size	WI_initVariables, .-WI_initVariables
	.align	2
	.globl	WI_Start
	.set	nomips16
	.set	nomicromips
	.ent	WI_Start
	.type	WI_Start, @function
WI_Start:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-24
	sw	$31,20($sp)
	jal	WI_initVariables
	nop

	jal	WI_loadData
	nop

	lui	$2,%hi(deathmatch)
	lw	$2,%lo(deathmatch)($2)
	bne	$2,$0,$L559
	lui	$2,%hi(netgame)

	lw	$2,%lo(netgame)($2)
	bne	$2,$0,$L560
	lw	$31,20($sp)

	lui	$5,%hi(state)
	sw	$0,%lo(state)($5)
	lui	$5,%hi(acceleratestage)
	lui	$2,%hi(gamemode)
	sw	$0,%lo(acceleratestage)($5)
	li	$6,1			# 0x1
	lui	$5,%hi(sp_state)
	lw	$4,%lo(gamemode)($2)
	sw	$6,%lo(sp_state)($5)
	li	$2,-1			# 0xffffffffffffffff
	lui	$5,%hi(cnt_secret)
	sw	$2,%lo(cnt_secret)($5)
	lui	$5,%hi(cnt_items)
	sw	$2,%lo(cnt_items)($5)
	lui	$5,%hi(cnt_kills)
	sw	$2,%lo(cnt_kills)($5)
	lui	$5,%hi(cnt_par)
	sw	$2,%lo(cnt_par)($5)
	lui	$5,%hi(cnt_time)
	sw	$2,%lo(cnt_time)($5)
	li	$3,2			# 0x2
	lui	$2,%hi(cnt_pause)
	li	$5,35			# 0x23
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L554
	.set	at
	sw	$5,%lo(cnt_pause)($2)

	lui	$2,%hi(wbs)
	lw	$2,%lo(wbs)($2)
	lw	$2,0($2)
	slt	$2,$2,3
	beq	$2,$0,$L554
	lw	$31,20($sp)

	j	WI_initAnimatedBack.part.0
	addiu	$sp,$sp,24

$L560:
	j	WI_initNetgameStats
	addiu	$sp,$sp,24

$L559:
	lw	$31,20($sp)
	j	WI_initDeathmatchStats
	addiu	$sp,$sp,24

$L554:
	lw	$31,20($sp)
	jr	$31
	addiu	$sp,$sp,24

	.set	macro
	.set	reorder
	.end	WI_Start
	.size	WI_Start, .-WI_Start
	.local	sp_state
	.comm	sp_state,4,4
	.local	ng_state
	.comm	ng_state,4,4
	.local	dofrags
	.comm	dofrags,4,4
	.local	cnt_frags
	.comm	cnt_frags,16,4
	.local	dm_totals
	.comm	dm_totals,16,4
	.local	dm_frags
	.comm	dm_frags,64,4
	.local	dm_state
	.comm	dm_state,4,4
	.local	snl_pointeron
	.comm	snl_pointeron,4,4
	.local	background
	.comm	background,4,4
	.local	lnames
	.comm	lnames,4,4
	.local	bp
	.comm	bp,16,4
	.local	p
	.comm	p,16,4
	.local	bstar
	.comm	bstar,4,4
	.local	star
	.comm	star,4,4
	.local	total
	.comm	total,4,4
	.local	victims
	.comm	victims,4,4
	.local	killers
	.comm	killers,4,4
	.local	sucks
	.comm	sucks,4,4
	.local	par
	.comm	par,4,4
	.local	timepatch
	.comm	timepatch,4,4
	.local	frags
	.comm	frags,4,4
	.local	items
	.comm	items,4,4
	.local	secret
	.comm	secret,4,4
	.local	kills
	.comm	kills,4,4
	.local	sp_secret
	.comm	sp_secret,4,4
	.local	entering
	.comm	entering,4,4
	.local	finished
	.comm	finished,4,4
	.local	wiminus
	.comm	wiminus,4,4
	.local	num
	.comm	num,40,4
	.local	colon
	.comm	colon,4,4
	.local	percent
	.comm	percent,4,4
	.local	splat
	.comm	splat,8,4
	.local	yah
	.comm	yah,12,4
	.local	NUMCMAPS
	.comm	NUMCMAPS,4,4
	.local	cnt_pause
	.comm	cnt_pause,4,4
	.local	cnt_par
	.comm	cnt_par,4,4
	.local	cnt_time
	.comm	cnt_time,4,4
	.local	cnt_secret
	.comm	cnt_secret,16,4
	.local	cnt_items
	.comm	cnt_items,16,4
	.local	cnt_kills
	.comm	cnt_kills,16,4
	.local	bcnt
	.comm	bcnt,4,4
	.local	cnt
	.comm	cnt,4,4
	.local	plrs
	.comm	plrs,4,4
	.local	wbs
	.comm	wbs,4,4
	.local	state
	.comm	state,4,4
	.local	me
	.comm	me,4,4
	.local	acceleratestage
	.comm	acceleratestage,4,4
	.rdata
	.align	2
	.type	anims, @object
	.size	anims, 16
anims:
	.word	epsd0animinfo
	.word	epsd1animinfo
	.word	epsd2animinfo
	.space	4
	.align	2
	.type	NUMANIMS, @object
	.size	NUMANIMS, 16
NUMANIMS:
	.word	10
	.word	9
	.word	6
	.space	4
	.data
	.align	2
	.type	epsd2animinfo, @object
	.size	epsd2animinfo, 336
epsd2animinfo:
	.word	0
	.word	11
	.word	3
	.word	104
	.word	168
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	40
	.word	136
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	160
	.word	96
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	104
	.word	80
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	120
	.word	32
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	8
	.word	3
	.word	40
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.align	2
	.type	epsd1animinfo, @object
	.size	epsd1animinfo, 504
epsd1animinfo:
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	1
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	2
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	4
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	5
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	6
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	7
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	3
	.word	192
	.word	144
	.word	8
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	2
	.word	11
	.word	1
	.word	128
	.word	136
	.word	8
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.align	2
	.type	epsd0animinfo, @object
	.size	epsd0animinfo, 560
epsd0animinfo:
	.word	0
	.word	11
	.word	3
	.word	224
	.word	104
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	184
	.word	160
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	112
	.word	136
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	72
	.word	112
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	88
	.word	96
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	64
	.word	48
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	192
	.word	40
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	136
	.word	16
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	80
	.word	16
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	11
	.word	3
	.word	64
	.word	24
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.rdata
	.align	2
	.type	lnodes, @object
	.size	lnodes, 288
lnodes:
	.word	185
	.word	164
	.word	148
	.word	143
	.word	69
	.word	122
	.word	209
	.word	102
	.word	116
	.word	89
	.word	166
	.word	55
	.word	71
	.word	56
	.word	135
	.word	29
	.word	71
	.word	24
	.word	254
	.word	25
	.word	97
	.word	50
	.word	188
	.word	64
	.word	128
	.word	78
	.word	214
	.word	92
	.word	133
	.word	130
	.word	208
	.word	136
	.word	148
	.word	140
	.word	235
	.word	158
	.word	156
	.word	168
	.word	48
	.word	154
	.word	174
	.word	95
	.word	265
	.word	75
	.word	130
	.word	48
	.word	279
	.word	23
	.word	198
	.word	48
	.word	140
	.word	25
	.word	281
	.word	136
	.space	72
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
