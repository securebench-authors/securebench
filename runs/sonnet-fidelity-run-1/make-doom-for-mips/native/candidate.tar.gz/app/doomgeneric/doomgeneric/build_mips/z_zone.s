	.file	1 "z_zone.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.align	2
	.globl	Z_ClearZone
	.set	nomips16
	.set	nomicromips
	.ent	Z_ClearZone
	.type	Z_ClearZone, @function
Z_ClearZone:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lw	$2,0($4)
	addiu	$3,$4,32
	addiu	$5,$4,4
	addiu	$2,$2,-32
	sw	$3,24($4)
	sw	$3,20($4)
	li	$6,1			# 0x1
	sw	$3,28($4)
	li	$3,4			# 0x4
	sw	$4,8($4)
	sw	$6,12($4)
	sw	$5,48($4)
	sw	$5,52($4)
	sw	$3,40($4)
	jr	$31
	sw	$2,32($4)

	.set	macro
	.set	reorder
	.end	Z_ClearZone
	.size	Z_ClearZone, .-Z_ClearZone
	.align	2
	.globl	Z_Init
	.set	nomips16
	.set	nomicromips
	.ent	Z_Init
	.type	Z_Init, @function
Z_Init:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-32
	sw	$31,28($sp)
	jal	I_ZoneBase
	addiu	$4,$sp,16

	lw	$5,16($sp)
	addiu	$3,$2,32
	lw	$31,28($sp)
	lui	$7,%hi(mainzone)
	addiu	$4,$2,4
	addiu	$6,$5,-32
	sw	$3,24($2)
	sw	$3,20($2)
	sw	$3,28($2)
	sw	$2,%lo(mainzone)($7)
	li	$3,4			# 0x4
	sw	$5,0($2)
	li	$5,1			# 0x1
	sw	$2,8($2)
	sw	$5,12($2)
	sw	$4,48($2)
	sw	$4,52($2)
	sw	$3,40($2)
	sw	$6,32($2)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	Z_Init
	.size	Z_Init, .-Z_Init
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
$LC0:
	.ascii	"Z_Free: freed a pointer without ZONEID\000"
	.text
	.align	2
	.globl	Z_Free
	.set	nomips16
	.set	nomicromips
	.ent	Z_Free
	.type	Z_Free, @function
Z_Free:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1900544			# 0x1d0000
	lw	$3,-12($4)
	addiu	$sp,$sp,-32
	addiu	$2,$2,18961
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$4
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L6
	.set	at
	addiu	$17,$4,-24

	lui	$4,%hi($LC0)
	jal	I_Error
	addiu	$4,$4,%lo($LC0)

$L6:
	lw	$3,-16($16)
	li	$2,4			# 0x4
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L7
	.set	at
	nop

	lw	$2,-20($16)
	beq	$2,$0,$L7
	nop

	sw	$0,0($2)
$L7:
	lw	$3,-4($16)
	li	$2,4			# 0x4
	sw	$2,-16($16)
	lw	$4,8($3)
	sw	$0,-20($16)
	.set	noat
	xor	$1,$4,$2
	beq	$1,$0,$L8
	.set	at
	sw	$0,-12($16)

	lw	$2,-8($16)
$L9:
	lw	$4,8($2)
	li	$3,4			# 0x4
	.set	noat
	xor	$1,$4,$3
	beq	$1,$0,$L19
	.set	at
	lui	$3,%hi(mainzone)

$L5:
	lw	$31,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

$L19:
	lw	$5,%lo(mainzone)($3)
	lw	$7,0($2)
	lw	$3,0($17)
	lw	$4,16($2)
	lw	$6,28($5)
	addu	$3,$3,$7
	sw	$3,0($17)
	sw	$4,16($17)
	.set	noat
	xor	$1,$6,$2
	bne	$1,$0,$L5
	.set	at
	sw	$17,20($4)

	lw	$31,28($sp)
	lw	$16,20($sp)
	sw	$17,28($5)
	lw	$17,24($sp)
	jr	$31
	addiu	$sp,$sp,32

$L8:
	lui	$2,%hi(mainzone)
	lw	$5,%lo(mainzone)($2)
	lw	$7,-24($16)
	lw	$4,0($3)
	lw	$2,-8($16)
	lw	$6,28($5)
	addu	$4,$4,$7
	sw	$4,0($3)
	sw	$2,16($3)
	.set	noat
	xor	$1,$6,$17
	beq	$1,$0,$L10
	.set	at
	sw	$3,20($2)

	b	$L9
	move	$17,$3

$L10:
	sw	$3,28($5)
	b	$L9
	move	$17,$3

	.set	macro
	.set	reorder
	.end	Z_Free
	.size	Z_Free, .-Z_Free
	.section	.rodata.str1.4
	.align	2
$LC1:
	.ascii	"Z_Malloc: failed on allocation of %i bytes\000"
	.align	2
$LC2:
	.ascii	"Z_Malloc: an owner is required for purgable blocks\000"
	.text
	.align	2
	.globl	Z_Malloc
	.set	nomips16
	.set	nomicromips
	.ent	Z_Malloc
	.type	Z_Malloc, @function
Z_Malloc:
	.frame	$sp,64,$31		# vars= 8, regs= 10/0, args= 16, gp= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-64
	sw	$23,52($sp)
	lui	$23,%hi(mainzone)
	lw	$2,%lo(mainzone)($23)
	sw	$16,24($sp)
	lw	$16,28($2)
	sw	$fp,56($sp)
	lw	$fp,20($16)
	li	$2,-4			# 0xfffffffffffffffc
	addiu	$4,$4,3
	lw	$3,8($fp)
	and	$4,$4,$2
	li	$2,4			# 0x4
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$19,36($sp)
	sw	$31,60($sp)
	sw	$20,40($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	move	$22,$5
	move	$21,$6
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L21
	.set	at
	addiu	$19,$4,24

	move	$16,$fp
	lw	$fp,20($fp)
$L21:
	lui	$20,%hi($LC1)
	move	$17,$16
	addiu	$20,$20,%lo($LC1)
	li	$18,4			# 0x4
$L31:
	.set	noat
	xor	$1,$fp,$16
	beq	$1,$0,$L33
	.set	at
	nop

	lw	$2,8($16)
$L35:
	.set	noat
	xor	$1,$2,$18
	beq	$1,$0,$L23
	.set	at
	slt	$3,$2,7

	beq	$3,$0,$L24
	nop

	lw	$16,16($16)
	move	$17,$16
$L25:
	lw	$2,8($17)
	.set	noat
	xor	$1,$2,$18
	bne	$1,$0,$L31
	.set	at
	nop

	lw	$2,0($17)
	slt	$3,$2,$19
	bne	$3,$0,$L31
	subu	$2,$2,$19

	slt	$3,$2,65
	bne	$3,$0,$L27
	addu	$3,$17,$19

	lw	$4,16($17)
	sw	$2,0($3)
	sw	$18,8($3)
	sw	$0,4($3)
	sw	$17,20($3)
	sw	$4,16($3)
	sw	$3,20($4)
	sw	$3,16($17)
	sw	$19,0($17)
$L27:
	beq	$21,$0,$L28
	addiu	$2,$17,24

	sw	$21,4($17)
	sw	$22,8($17)
	sw	$2,0($21)
$L29:
	lw	$3,%lo(mainzone)($23)
	lw	$4,16($17)
	lw	$31,60($sp)
	sw	$4,28($3)
	li	$3,1900544			# 0x1d0000
	addiu	$3,$3,18961
	lw	$fp,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$16,24($sp)
	sw	$3,12($17)
	lw	$17,28($sp)
	jr	$31
	addiu	$sp,$sp,64

$L23:
	b	$L25
	lw	$16,16($16)

$L24:
	lw	$17,20($17)
	jal	Z_Free
	addiu	$4,$16,24

	lw	$17,16($17)
	b	$L25
	lw	$16,16($17)

$L33:
	move	$4,$20
	jal	I_Error
	move	$5,$19

	b	$L35
	lw	$2,8($16)

$L28:
	slt	$3,$22,7
	beq	$3,$0,$L34
	lui	$4,%hi($LC2)

	sw	$0,4($17)
	b	$L29
	sw	$22,8($17)

$L34:
	addiu	$4,$4,%lo($LC2)
	jal	I_Error
	sw	$2,16($sp)

	lw	$2,16($sp)
	sw	$0,4($17)
	b	$L29
	sw	$22,8($17)

	.set	macro
	.set	reorder
	.end	Z_Malloc
	.size	Z_Malloc, .-Z_Malloc
	.align	2
	.globl	Z_FreeTags
	.set	nomips16
	.set	nomicromips
	.ent	Z_FreeTags
	.type	Z_FreeTags, @function
Z_FreeTags:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$18,24($sp)
	lui	$18,%hi(mainzone)
	lw	$2,%lo(mainzone)($18)
	sw	$16,16($sp)
	lw	$16,20($2)
	addiu	$2,$2,4
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L36
	.set	at
	sw	$17,20($sp)

	move	$17,$4
	move	$19,$5
	b	$L39
	li	$20,4			# 0x4

$L38:
	lw	$2,%lo(mainzone)($18)
$L43:
	addiu	$2,$2,4
	.set	noat
	xor	$1,$16,$2
	beq	$1,$0,$L42
	.set	at
	lw	$31,36($sp)

$L39:
	lw	$2,8($16)
	move	$4,$16
	slt	$6,$2,$17
	.set	noat
	xor	$1,$2,$20
	beq	$1,$0,$L38
	.set	at
	lw	$16,16($16)

	bne	$6,$0,$L38
	slt	$2,$19,$2

	bne	$2,$0,$L43
	lw	$2,%lo(mainzone)($18)

	jal	Z_Free
	addiu	$4,$4,24

	lw	$2,%lo(mainzone)($18)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$16,$2
	bne	$1,$0,$L39
	.set	at
	nop

$L36:
	lw	$31,36($sp)
$L42:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	Z_FreeTags
	.size	Z_FreeTags, .-Z_FreeTags
	.section	.rodata.str1.4
	.align	2
$LC3:
	.ascii	"zone size: %i  location: %p\012\000"
	.align	2
$LC4:
	.ascii	"tag range: %i to %i\012\000"
	.align	2
$LC5:
	.ascii	"block:%p    size:%7i    user:%p    tag:%3i\012\000"
	.align	2
$LC6:
	.ascii	"ERROR: block size does not touch the next block\012\000"
	.align	2
$LC7:
	.ascii	"ERROR: next block doesn't have proper back link\012\000"
	.align	2
$LC8:
	.ascii	"ERROR: two consecutive free blocks\012\000"
	.text
	.align	2
	.globl	Z_DumpHeap
	.set	nomips16
	.set	nomicromips
	.ent	Z_DumpHeap
	.type	Z_DumpHeap, @function
Z_DumpHeap:
	.frame	$sp,56,$31		# vars= 0, regs= 8/0, args= 24, gp= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$18,32($sp)
	lui	$18,%hi(mainzone)
	lw	$6,%lo(mainzone)($18)
	sw	$19,36($sp)
	sw	$17,28($sp)
	move	$19,$5
	move	$17,$4
	lw	$5,0($6)
	lui	$4,%hi($LC3)
	addiu	$4,$4,%lo($LC3)
	sw	$31,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	jal	printf
	sw	$16,24($sp)

	lui	$4,%hi($LC4)
	move	$6,$19
	move	$5,$17
	jal	printf
	addiu	$4,$4,%lo($LC4)

	lw	$2,%lo(mainzone)($18)
	lui	$22,%hi($LC5)
	lw	$16,20($2)
	lui	$20,%hi($LC6)
	lw	$3,8($16)
	addiu	$22,$22,%lo($LC5)
	addiu	$20,$20,%lo($LC6)
	lui	$21,%hi($LC7)
$L50:
	slt	$2,$3,$17
	bne	$2,$0,$L55
	lw	$2,%lo(mainzone)($18)

	slt	$2,$19,$3
	beq	$2,$0,$L52
	lw	$2,%lo(mainzone)($18)

$L55:
	lw	$3,16($16)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L56
	.set	at
	lw	$31,52($sp)

$L54:
	lw	$2,0($16)
	addu	$2,$16,$2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L47
	.set	at
	nop

	jal	printf
	move	$4,$20

	lw	$2,16($16)
$L47:
	lw	$3,20($2)
	.set	noat
	xor	$1,$3,$16
	beq	$1,$0,$L48
	.set	at
	nop

	jal	printf
	addiu	$4,$21,%lo($LC7)

	lw	$2,16($16)
$L48:
	lw	$4,8($16)
	li	$5,4			# 0x4
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L53
	.set	at
	lw	$3,8($2)

$L49:
	b	$L50
	move	$16,$2

$L53:
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L49
	.set	at
	nop

	lui	$4,%hi($LC8)
	jal	printf
	addiu	$4,$4,%lo($LC8)

	lw	$2,16($16)
	lw	$3,8($2)
	b	$L50
	move	$16,$2

$L52:
	lw	$6,0($16)
	lw	$7,4($16)
	move	$5,$16
	sw	$3,16($sp)
	jal	printf
	move	$4,$22

	lw	$2,%lo(mainzone)($18)
	lw	$3,16($16)
	addiu	$2,$2,4
	.set	noat
	xor	$1,$3,$2
	bne	$1,$0,$L54
	.set	at
	lw	$31,52($sp)

$L56:
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	Z_DumpHeap
	.size	Z_DumpHeap, .-Z_DumpHeap
	.align	2
	.globl	Z_FileDumpHeap
	.set	nomips16
	.set	nomicromips
	.ent	Z_FileDumpHeap
	.type	Z_FileDumpHeap, @function
Z_FileDumpHeap:
	.frame	$sp,56,$31		# vars= 0, regs= 7/0, args= 24, gp= 0
	.mask	0x803f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-56
	sw	$20,44($sp)
	lui	$20,%hi(mainzone)
	lw	$7,%lo(mainzone)($20)
	lui	$5,%hi($LC3)
	lw	$6,0($7)
	addiu	$5,$5,%lo($LC3)
	sw	$21,48($sp)
	sw	$19,40($sp)
	sw	$18,36($sp)
	sw	$17,32($sp)
	sw	$16,28($sp)
	sw	$31,52($sp)
	jal	fprintf
	move	$17,$4

	lw	$2,%lo(mainzone)($20)
	lui	$19,%hi($LC5)
	lw	$16,20($2)
	lui	$18,%hi($LC6)
	lui	$21,%hi($LC7)
	lw	$3,8($16)
	addiu	$19,$19,%lo($LC5)
	addiu	$18,$18,%lo($LC6)
	addiu	$21,$21,%lo($LC7)
$L62:
	lw	$7,0($16)
	sw	$3,20($sp)
	lw	$2,4($16)
	move	$5,$19
	move	$4,$17
	move	$6,$16
	jal	fprintf
	sw	$2,16($sp)

	lw	$2,%lo(mainzone)($20)
	lw	$3,16($16)
	addiu	$2,$2,4
	move	$5,$18
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L57
	.set	at
	move	$4,$17

	lw	$2,0($16)
	addu	$2,$16,$2
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L59
	.set	at
	nop

	jal	fprintf
	nop

	lw	$2,16($16)
$L59:
	lw	$3,20($2)
	move	$5,$21
	.set	noat
	xor	$1,$3,$16
	beq	$1,$0,$L60
	.set	at
	move	$4,$17

	jal	fprintf
	nop

	lw	$2,16($16)
$L60:
	lw	$4,8($16)
	li	$5,4			# 0x4
	.set	noat
	xor	$1,$4,$5
	beq	$1,$0,$L64
	.set	at
	lw	$3,8($2)

$L61:
	b	$L62
	move	$16,$2

$L64:
	.set	noat
	xor	$1,$3,$4
	bne	$1,$0,$L61
	.set	at
	lui	$5,%hi($LC8)

	addiu	$5,$5,%lo($LC8)
	jal	fprintf
	move	$4,$17

	lw	$2,16($16)
	lw	$3,8($2)
	b	$L62
	move	$16,$2

$L57:
	lw	$31,52($sp)
	lw	$21,48($sp)
	lw	$20,44($sp)
	lw	$19,40($sp)
	lw	$18,36($sp)
	lw	$17,32($sp)
	lw	$16,28($sp)
	jr	$31
	addiu	$sp,$sp,56

	.set	macro
	.set	reorder
	.end	Z_FileDumpHeap
	.size	Z_FileDumpHeap, .-Z_FileDumpHeap
	.section	.rodata.str1.4
	.align	2
$LC9:
	.ascii	"Z_CheckHeap: block size does not touch the next block\012"
	.ascii	"\000"
	.align	2
$LC10:
	.ascii	"Z_CheckHeap: next block doesn't have proper back link\012"
	.ascii	"\000"
	.align	2
$LC11:
	.ascii	"Z_CheckHeap: two consecutive free blocks\012\000"
	.text
	.align	2
	.globl	Z_CheckHeap
	.set	nomips16
	.set	nomicromips
	.ent	Z_CheckHeap
	.type	Z_CheckHeap, @function
Z_CheckHeap:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, gp= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	addiu	$sp,$sp,-40
	sw	$20,32($sp)
	lui	$20,%hi(mainzone)
	lw	$2,%lo(mainzone)($20)
	sw	$16,16($sp)
	lw	$16,20($2)
	addiu	$2,$2,4
	lw	$5,16($16)
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L65
	.set	at
	sw	$17,20($sp)

	lui	$19,%hi($LC9)
	lui	$18,%hi($LC10)
	addiu	$19,$19,%lo($LC9)
	addiu	$18,$18,%lo($LC10)
	b	$L66
	li	$17,4			# 0x4

$L69:
$L75:
	lw	$5,16($2)
	addiu	$3,$3,4
	.set	noat
	xor	$1,$5,$3
	beq	$1,$0,$L74
	.set	at
	lw	$31,36($sp)

	move	$16,$2
$L66:
	lw	$2,0($16)
	addu	$2,$16,$2
	.set	noat
	xor	$1,$5,$2
	beq	$1,$0,$L67
	.set	at
	move	$4,$19

	jal	I_Error
	nop

$L67:
	lw	$2,16($16)
	lw	$3,20($2)
	.set	noat
	xor	$1,$3,$16
	beq	$1,$0,$L68
	.set	at
	move	$4,$18

	jal	I_Error
	nop

	lw	$2,16($16)
$L68:
	lw	$3,8($16)
	.set	noat
	xor	$1,$3,$17
	bne	$1,$0,$L75
	.set	at
	lw	$3,%lo(mainzone)($20)

	lw	$3,8($2)
	.set	noat
	xor	$1,$3,$17
	bne	$1,$0,$L69
	.set	at
	lw	$3,%lo(mainzone)($20)

	lui	$4,%hi($LC11)
	jal	I_Error
	addiu	$4,$4,%lo($LC11)

	lw	$2,16($16)
	lw	$3,%lo(mainzone)($20)
	lw	$5,16($2)
	addiu	$3,$3,4
	.set	noat
	xor	$1,$5,$3
	bne	$1,$0,$L66
	.set	at
	move	$16,$2

$L65:
	lw	$31,36($sp)
$L74:
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	jr	$31
	addiu	$sp,$sp,40

	.set	macro
	.set	reorder
	.end	Z_CheckHeap
	.size	Z_CheckHeap, .-Z_CheckHeap
	.section	.rodata.str1.4
	.align	2
$LC12:
	.ascii	"%s:%i: Z_ChangeTag: block without a ZONEID!\000"
	.align	2
$LC13:
	.ascii	"%s:%i: Z_ChangeTag: an owner is required for purgable bl"
	.ascii	"ocks\000"
	.text
	.align	2
	.globl	Z_ChangeTag2
	.set	nomips16
	.set	nomicromips
	.ent	Z_ChangeTag2
	.type	Z_ChangeTag2, @function
Z_ChangeTag2:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, gp= 0
	.mask	0x800f0000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1900544			# 0x1d0000
	lw	$3,-12($4)
	addiu	$sp,$sp,-40
	addiu	$2,$2,18961
	sw	$19,32($sp)
	sw	$18,28($sp)
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,36($sp)
	move	$16,$4
	move	$17,$5
	move	$18,$6
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L77
	.set	at
	move	$19,$7

	lui	$4,%hi($LC12)
	move	$6,$7
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC12)

$L77:
	slt	$2,$17,7
	bne	$2,$0,$L81
	lw	$31,36($sp)

	lw	$2,-20($16)
	beq	$2,$0,$L80
	move	$6,$19

$L81:
	sw	$17,-16($16)
	lw	$19,32($sp)
	lw	$18,28($sp)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,40

$L80:
	lui	$4,%hi($LC13)
	move	$5,$18
	jal	I_Error
	addiu	$4,$4,%lo($LC13)

	b	$L81
	lw	$31,36($sp)

	.set	macro
	.set	reorder
	.end	Z_ChangeTag2
	.size	Z_ChangeTag2, .-Z_ChangeTag2
	.section	.rodata.str1.4
	.align	2
$LC14:
	.ascii	"Z_ChangeUser: Tried to change user for invalid block!\000"
	.text
	.align	2
	.globl	Z_ChangeUser
	.set	nomips16
	.set	nomicromips
	.ent	Z_ChangeUser
	.type	Z_ChangeUser, @function
Z_ChangeUser:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	li	$2,1900544			# 0x1d0000
	lw	$3,-12($4)
	addiu	$sp,$sp,-32
	addiu	$2,$2,18961
	sw	$17,24($sp)
	sw	$16,20($sp)
	sw	$31,28($sp)
	move	$16,$4
	.set	noat
	xor	$1,$3,$2
	beq	$1,$0,$L83
	.set	at
	move	$17,$5

	lui	$4,%hi($LC14)
	jal	I_Error
	addiu	$4,$4,%lo($LC14)

$L83:
	lw	$31,28($sp)
	sw	$17,-20($16)
	sw	$16,0($17)
	lw	$17,24($sp)
	lw	$16,20($sp)
	jr	$31
	addiu	$sp,$sp,32

	.set	macro
	.set	reorder
	.end	Z_ChangeUser
	.size	Z_ChangeUser, .-Z_ChangeUser
	.align	2
	.globl	Z_FreeMemory
	.set	nomips16
	.set	nomicromips
	.ent	Z_FreeMemory
	.type	Z_FreeMemory, @function
Z_FreeMemory:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(mainzone)
	lw	$6,%lo(mainzone)($2)
	lw	$3,20($6)
	addiu	$6,$6,4
	.set	noat
	xor	$1,$3,$6
	beq	$1,$0,$L94
	.set	at
	move	$2,$0

	li	$7,4			# 0x4
$L90:
	lw	$4,8($3)
	.set	noat
	xor	$1,$4,$7
	beq	$1,$0,$L89
	.set	at
	slt	$5,$4,7

	bne	$5,$0,$L88
	nop

$L89:
	lw	$4,0($3)
	addu	$2,$2,$4
$L88:
	lw	$3,16($3)
	.set	noat
	xor	$1,$6,$3
	bne	$1,$0,$L90
	.set	at
	nop

$L94:
	jr	$31
	nop

	.set	macro
	.set	reorder
	.end	Z_FreeMemory
	.size	Z_FreeMemory, .-Z_FreeMemory
	.align	2
	.globl	Z_ZoneSize
	.set	nomips16
	.set	nomicromips
	.ent	Z_ZoneSize
	.type	Z_ZoneSize, @function
Z_ZoneSize:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	lui	$2,%hi(mainzone)
	lw	$2,%lo(mainzone)($2)
	jr	$31
	lw	$2,0($2)

	.set	macro
	.set	reorder
	.end	Z_ZoneSize
	.size	Z_ZoneSize, .-Z_ZoneSize
	.globl	mainzone
	.section	.bss,"aw",@nobits
	.align	2
	.type	mainzone, @object
	.size	mainzone, 4
mainzone:
	.space	4
	.ident	"GCC: (Debian 12.2.0-14) 12.2.0"
	.section	.note.GNU-stack,"",@progbits
