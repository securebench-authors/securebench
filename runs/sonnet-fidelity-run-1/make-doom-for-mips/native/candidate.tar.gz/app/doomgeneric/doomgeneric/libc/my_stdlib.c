#include "my_stdlib.h"

int errno;

static inline long sys3(long n, long a, long b, long c)
{
    register long v0 __asm__("$2") = n;
    register long a0 __asm__("$4") = a;
    register long a1 __asm__("$5") = b;
    register long a2 __asm__("$6") = c;
    __asm__ volatile("syscall" : "+r"(v0) : "r"(a0), "r"(a1), "r"(a2) : "memory", "$7");
    return v0;
}

ssize_t read(int fd, void *b, size_t n) { return sys3(0, fd, (long)b, n); }
ssize_t write(int fd, const void *b, size_t n) { return sys3(1, fd, (long)b, n); }
int open(const char *p, int fl, ...) { return sys3(2, (long)p, fl, 0644); }
int close(int fd) { return sys3(3, fd, 0, 0); }
off_t lseek(int fd, off_t o, int w) { return sys3(8, fd, o, w); }
time_t time(time_t *t) { time_t r = sys3(201, 0, 0, 0); if (t) *t = r; return r; }
int rename(const char *a, const char *b) { return sys3(38, (long)a, (long)b, 0); }
int mkdir(const char *p, mode_t m) { return sys3(39, (long)p, m, 0); }
int remove(const char *p) { return -1; }
int isatty(int fd) { return 0; }
int access(const char *p, int m) { return -1; }
int system(const char *c) { return -1; }
char *getenv(const char *n) { return 0; }

void exit(int c) { for (;;) ; }
void abort(void) { for (;;) ; }

/* ---- string ---- */
void *memcpy(void *d, const void *s, size_t n)
{
    unsigned char *dd = d; const unsigned char *ss = s;
    if ((((uintptr_t)d | (uintptr_t)s) & 3) == 0) {
        uint32_t *dw = d; const uint32_t *sw = s;
        while (n >= 4) { *dw++ = *sw++; n -= 4; }
        dd = (unsigned char *)dw; ss = (const unsigned char *)sw;
    }
    while (n--) *dd++ = *ss++;
    return d;
}
void *memmove(void *d, const void *s, size_t n)
{
    unsigned char *dd = d; const unsigned char *ss = s;
    if (dd < ss) { while (n--) *dd++ = *ss++; }
    else { dd += n; ss += n; while (n--) *--dd = *--ss; }
    return d;
}
void *memset(void *d, int c, size_t n)
{
    unsigned char *dd = d;
    while (n && ((uintptr_t)dd & 3)) { *dd++ = c; n--; }
    uint32_t w = (unsigned char)c * 0x01010101u;
    uint32_t *dw = (uint32_t *)dd;
    while (n >= 4) { *dw++ = w; n -= 4; }
    dd = (unsigned char *)dw;
    while (n--) *dd++ = c;
    return d;
}
int memcmp(const void *a, const void *b, size_t n)
{
    const unsigned char *x = a, *y = b;
    for (; n; n--, x++, y++) if (*x != *y) return *x - *y;
    return 0;
}
void *memchr(const void *s, int c, size_t n)
{
    const unsigned char *p = s;
    for (; n; n--, p++) if (*p == (unsigned char)c) return (void *)p;
    return 0;
}
size_t strlen(const char *s) { const char *p = s; while (*p) p++; return p - s; }
char *strcpy(char *d, const char *s) { char *r = d; while ((*d++ = *s++)); return r; }
char *strncpy(char *d, const char *s, size_t n)
{
    size_t i = 0;
    for (; i < n && s[i]; i++) d[i] = s[i];
    for (; i < n; i++) d[i] = 0;
    return d;
}
char *strcat(char *d, const char *s) { strcpy(d + strlen(d), s); return d; }
char *strncat(char *d, const char *s, size_t n)
{
    char *p = d + strlen(d);
    while (n-- && *s) *p++ = *s++;
    *p = 0;
    return d;
}
int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
int strncmp(const char *a, const char *b, size_t n)
{
    for (; n; n--, a++, b++) {
        if (*a != *b) return (unsigned char)*a - (unsigned char)*b;
        if (!*a) break;
    }
    return 0;
}
int toupper(int c) { return (c >= 'a' && c <= 'z') ? c - 32 : c; }
int tolower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
int isspace(int c) { return c == ' ' || (c >= 9 && c <= 13); }
int isdigit(int c) { return c >= '0' && c <= '9'; }
int isupper(int c) { return c >= 'A' && c <= 'Z'; }
int islower(int c) { return c >= 'a' && c <= 'z'; }
int isalpha(int c) { return isupper(c) || islower(c); }
int isalnum(int c) { return isalpha(c) || isdigit(c); }
int isprint(int c) { return c >= 32 && c < 127; }
int isxdigit(int c) { return isdigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
int strcasecmp(const char *a, const char *b)
{
    while (*a && tolower((unsigned char)*a) == tolower((unsigned char)*b)) { a++; b++; }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}
int strncasecmp(const char *a, const char *b, size_t n)
{
    for (; n; n--, a++, b++) {
        int x = tolower((unsigned char)*a), y = tolower((unsigned char)*b);
        if (x != y) return x - y;
        if (!x) break;
    }
    return 0;
}
char *strchr(const char *s, int c)
{
    for (;; s++) {
        if (*s == (char)c) return (char *)s;
        if (!*s) return 0;
    }
}
char *strrchr(const char *s, int c)
{
    const char *r = 0;
    for (;; s++) {
        if (*s == (char)c) r = s;
        if (!*s) return (char *)r;
    }
}
char *strstr(const char *h, const char *n)
{
    size_t l = strlen(n);
    if (!l) return (char *)h;
    for (; *h; h++) if (!strncmp(h, n, l)) return (char *)h;
    return 0;
}
char *strdup(const char *s) { size_t l = strlen(s) + 1; char *p = malloc(l); if (p) memcpy(p, s, l); return p; }
char *strerror(int e) { return "error"; }

/* ---- stdlib ---- */
extern char __heap_start[];
static char *heap_ptr;
typedef struct hdr { size_t size; struct hdr *next; } hdr_t;
static hdr_t *free_list;

void *malloc(size_t n)
{
    if (!heap_ptr) heap_ptr = (char *)0x10000000;
    n = (n + 15) & ~15u;
    hdr_t **pp = &free_list;
    for (; *pp; pp = &(*pp)->next)
        if ((*pp)->size >= n && (*pp)->size <= n * 2) {
            hdr_t *h = *pp;
            *pp = h->next;
            return h + 1;
        }
    hdr_t *h = (hdr_t *)heap_ptr;
    h->size = n;
    heap_ptr += sizeof(hdr_t) + n;
    return h + 1;
}
void free(void *p)
{
    if (!p) return;
    hdr_t *h = (hdr_t *)p - 1;
    h->next = free_list;
    free_list = h;
}
void *calloc(size_t a, size_t b) { void *p = malloc(a * b); memset(p, 0, a * b); return p; }
void *realloc(void *p, size_t n)
{
    if (!p) return malloc(n);
    size_t old = ((hdr_t *)p)[-1].size;
    if (n <= old) return p;
    void *q = malloc(n);
    memcpy(q, p, old);
    return q;
}

long strtol(const char *s, char **end, int base)
{
    while (isspace(*s)) s++;
    int neg = 0;
    if (*s == '-') { neg = 1; s++; } else if (*s == '+') s++;
    if ((base == 0 || base == 16) && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) { s += 2; base = 16; }
    else if (base == 0 && s[0] == '0') base = 8;
    else if (base == 0) base = 10;
    long v = 0;
    for (;; s++) {
        int d;
        if (isdigit(*s)) d = *s - '0';
        else if (isalpha(*s)) d = tolower(*s) - 'a' + 10;
        else break;
        if (d >= base) break;
        v = v * base + d;
    }
    if (end) *end = (char *)s;
    return neg ? -v : v;
}
unsigned long strtoul(const char *s, char **e, int b) { return strtol(s, e, b); }
int atoi(const char *s) { return strtol(s, 0, 10); }
long atol(const char *s) { return strtol(s, 0, 10); }
double atof(const char *s)
{
    while (isspace(*s)) s++;
    int neg = 0;
    if (*s == '-') { neg = 1; s++; }
    double v = 0;
    while (isdigit(*s)) v = v * 10 + (*s++ - '0');
    if (*s == '.') { s++; double f = 0.1; while (isdigit(*s)) { v += (*s++ - '0') * f; f /= 10; } }
    return neg ? -v : v;
}
int abs(int x) { return x < 0 ? -x : x; }
long labs(long x) { return x < 0 ? -x : x; }
static unsigned rand_state = 1;
int rand(void) { rand_state = rand_state * 1103515245u + 12345u; return (rand_state >> 16) & 0x7fff; }
void srand(unsigned s) { rand_state = s; }

void qsort(void *base, size_t n, size_t sz, int (*cmp)(const void *, const void *))
{
    /* simple heap-free insertion/shell sort */
    char *b = base;
    char tmp[256];
    for (size_t gap = n / 2; gap > 0; gap /= 2)
        for (size_t i = gap; i < n; i++) {
            memcpy(tmp, b + i * sz, sz);
            size_t j = i;
            for (; j >= gap && cmp(b + (j - gap) * sz, tmp) > 0; j -= gap)
                memcpy(b + j * sz, b + (j - gap) * sz, sz);
            memcpy(b + j * sz, tmp, sz);
        }
}

/* ---- stdio ---- */
static FILE f_in = {0, 0, 0, -1}, f_out = {1, 0, 0, -1}, f_err = {2, 0, 0, -1};
FILE *stdin = &f_in, *stdout = &f_out, *stderr = &f_err;

FILE *fopen(const char *p, const char *m)
{
    int fl;
    if (m[0] == 'r') fl = (strchr(m, '+')) ? O_RDWR : O_RDONLY;
    else if (m[0] == 'w') fl = O_WRONLY | O_CREAT | O_TRUNC;
    else fl = O_WRONLY | O_CREAT | O_APPEND;
    int fd = open(p, fl, 0644);
    if (fd < 0) return 0;
    FILE *f = malloc(sizeof(FILE));
    f->fd = fd; f->eof = 0; f->err = 0; f->ungot = -1;
    return f;
}
int fclose(FILE *f) { int r = close(f->fd); return r; }
size_t fread(void *b, size_t sz, size_t n, FILE *f)
{
    size_t want = sz * n, got = 0;
    char *p = b;
    while (got < want) {
        ssize_t r = read(f->fd, p + got, want - got);
        if (r <= 0) { f->eof = 1; break; }
        got += r;
    }
    return sz ? got / sz : 0;
}
size_t fwrite(const void *b, size_t sz, size_t n, FILE *f)
{
    size_t want = sz * n;
    if (!want) return 0;
    ssize_t r = write(f->fd, b, want);
    if (r < 0) { f->err = 1; return 0; }
    return r / sz;
}
int fseek(FILE *f, long o, int w) { f->eof = 0; return lseek(f->fd, o, w) < 0 ? -1 : 0; }
long ftell(FILE *f) { return lseek(f->fd, 0, SEEK_CUR); }
int fflush(FILE *f) { return 0; }
int feof(FILE *f) { return f->eof; }
int ferror(FILE *f) { return f->err; }
int fileno(FILE *f) { return f->fd; }
int fgetc(FILE *f) { unsigned char c; return fread(&c, 1, 1, f) == 1 ? c : EOF; }
char *fgets(char *s, int n, FILE *f)
{
    int i = 0;
    while (i < n - 1) {
        int c = fgetc(f);
        if (c == EOF) break;
        s[i++] = c;
        if (c == '\n') break;
    }
    if (!i) return 0;
    s[i] = 0;
    return s;
}
int fputc(int c, FILE *f) { unsigned char ch = c; return fwrite(&ch, 1, 1, f) == 1 ? c : EOF; }
int fputs(const char *s, FILE *f) { return fwrite(s, 1, strlen(s), f); }
int putchar(int c) { return fputc(c, stdout); }
int puts(const char *s) { fputs(s, stdout); fputc('\n', stdout); return 0; }

typedef struct { char *buf; size_t pos, cap; } out_t;
static void outc(out_t *o, char c) { if (o->pos + 1 < o->cap) o->buf[o->pos] = c; o->pos++; }

static void out_num(out_t *o, uint64_t v, int neg, int base, int upper, int width, int prec, int left, int zero, int plus)
{
    char tmp[24]; int n = 0;
    const char *dg = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    if (!v && prec != 0) tmp[n++] = '0';
    while (v) { uint32_t d; 
        if (base == 10) { d = v % 10; v /= 10; } else if (base == 16) { d = v & 15; v >>= 4; } else { d = v & 7; v >>= 3; }
        tmp[n++] = dg[d]; }
    int len = n; if (prec > len) len = prec;
    int sign = neg || plus;
    int pad = width - len - sign;
    if (!left && !zero) while (pad-- > 0) outc(o, ' ');
    if (neg) outc(o, '-'); else if (plus) outc(o, '+');
    if (!left && zero && prec < 0) while (pad-- > 0) outc(o, '0');
    for (int i = n; i < prec; i++) outc(o, '0');
    while (n) outc(o, tmp[--n]);
    if (left) while (pad-- > 0) outc(o, ' ');
}

int vsnprintf(char *buf, size_t cap, const char *f, va_list ap)
{
    out_t o = {buf, 0, cap};
    for (; *f; f++) {
        if (*f != '%') { outc(&o, *f); continue; }
        f++;
        int left = 0, zero = 0, plus = 0, width = 0, prec = -1, lng = 0;
        for (;; f++) {
            if (*f == '-') left = 1; else if (*f == '0') zero = 1; else if (*f == '+') plus = 1;
            else if (*f == ' ' || *f == '#') ; else break;
        }
        if (*f == '*') { width = va_arg(ap, int); if (width < 0) { left = 1; width = -width; } f++; }
        else while (isdigit(*f)) width = width * 10 + *f++ - '0';
        if (*f == '.') {
            f++; prec = 0;
            if (*f == '*') { prec = va_arg(ap, int); f++; }
            else while (isdigit(*f)) prec = prec * 10 + *f++ - '0';
        }
        while (*f == 'l' || *f == 'h' || *f == 'z' || *f == 't') { if (*f == 'l') lng++; if (*f == 'z' || *f == 't') lng = 1; f++; }
        switch (*f) {
        case 'd': case 'i': {
            int64_t v = lng > 1 ? va_arg(ap, int64_t) : va_arg(ap, int);
            int neg = v < 0;
            out_num(&o, neg ? -(uint64_t)v : v, neg, 10, 0, width, prec, left, zero, plus);
            break; }
        case 'u': case 'x': case 'X': case 'o': {
            uint64_t v = lng > 1 ? va_arg(ap, uint64_t) : va_arg(ap, unsigned);
            out_num(&o, v, 0, *f == 'u' ? 10 : *f == 'o' ? 8 : 16, *f == 'X', width, prec, left, zero, 0);
            break; }
        case 'p': {
            uint32_t v = (uint32_t)va_arg(ap, void *);
            outc(&o, '0'); outc(&o, 'x');
            out_num(&o, v, 0, 16, 0, 0, -1, 0, 0, 0);
            break; }
        case 'c': {
            char c = va_arg(ap, int);
            int pad = width - 1;
            if (!left) while (pad-- > 0) outc(&o, ' ');
            outc(&o, c);
            if (left) while (pad-- > 0) outc(&o, ' ');
            break; }
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            int l = 0; while (s[l] && (prec < 0 || l < prec)) l++;
            int pad = width - l;
            if (!left) while (pad-- > 0) outc(&o, ' ');
            for (int i = 0; i < l; i++) outc(&o, s[i]);
            if (left) while (pad-- > 0) outc(&o, ' ');
            break; }
        case 'f': case 'g': case 'e': {
            double v = va_arg(ap, double);
            if (prec < 0) prec = 6;
            if (v < 0) { outc(&o, '-'); v = -v; }
            uint64_t ip = (uint64_t)v;
            double fr = v - ip;
            out_num(&o, ip, 0, 10, 0, 0, -1, 0, 0, 0);
            if (prec) {
                outc(&o, '.');
                while (prec--) { fr *= 10; int d = (int)fr; outc(&o, '0' + d); fr -= d; }
            }
            break; }
        case '%': outc(&o, '%'); break;
        case 0: f--; break;
        default: outc(&o, '%'); outc(&o, *f); break;
        }
    }
    if (cap) buf[o.pos < cap ? o.pos : cap - 1] = 0;
    return o.pos;
}
int vsprintf(char *b, const char *f, va_list ap) { return vsnprintf(b, 0x7fffffff, f, ap); }
int snprintf(char *b, size_t n, const char *f, ...) { va_list ap; va_start(ap, f); int r = vsnprintf(b, n, f, ap); va_end(ap); return r; }
int sprintf(char *b, const char *f, ...) { va_list ap; va_start(ap, f); int r = vsnprintf(b, 0x7fffffff, f, ap); va_end(ap); return r; }
int vfprintf(FILE *fp, const char *f, va_list ap)
{
    char buf[1024];
    int r = vsnprintf(buf, sizeof buf, f, ap);
    int n = r < (int)sizeof buf ? r : (int)sizeof buf - 1;
    fwrite(buf, 1, n, fp);
    return r;
}
int vprintf(const char *f, va_list ap) { return vfprintf(stdout, f, ap); }
int printf(const char *f, ...) { va_list ap; va_start(ap, f); int r = vfprintf(stdout, f, ap); va_end(ap); return r; }
int fprintf(FILE *fp, const char *f, ...) { va_list ap; va_start(ap, f); int r = vfprintf(fp, f, ap); va_end(ap); return r; }

int sscanf(const char *s, const char *f, ...)
{
    va_list ap; va_start(ap, f);
    int cnt = 0;
    for (; *f; f++) {
        if (isspace(*f)) { while (isspace(*s)) s++; continue; }
        if (*f != '%') { if (*s != *f) break; s++; continue; }
        f++;
        while (isspace(*s) && *f != 'c') s++;
        char *end;
        if (*f == 'd' || *f == 'i' || *f == 'x' || *f == 'o') {
            int base = *f == 'd' ? 10 : *f == 'x' ? 16 : *f == 'o' ? 8 : 0;
            long v = strtol(s, &end, base);
            if (end == s) break;
            *va_arg(ap, int *) = v; s = end; cnt++;
        } else break;
    }
    va_end(ap);
    return cnt;
}
int fscanf(FILE *fp, const char *f, ...) { return EOF; }

/* ---- math (soft-float, only needs to be roughly right) ---- */
double fabs(double x) { return x < 0 ? -x : x; }
double floor(double x) { double t = (double)(int64_t)x; return t > x ? t - 1 : t; }
double ceil(double x) { double t = (double)(int64_t)x; return t < x ? t + 1 : t; }
double sqrt(double x)
{
    if (x <= 0) return 0;
    double g = x > 1 ? x / 2 : 1;
    for (int i = 0; i < 40; i++) g = 0.5 * (g + x / g);
    return g;
}
double fmod(double a, double b) { return a - b * (double)(int64_t)(a / b); }
double sin(double x)
{
    const double pi = 3.14159265358979323846;
    x = fmod(x, 2 * pi);
    if (x > pi) x -= 2 * pi; else if (x < -pi) x += 2 * pi;
    double t = x, s = x;
    for (int i = 1; i < 12; i++) { t *= -x * x / ((2 * i) * (2 * i + 1)); s += t; }
    return s;
}
double cos(double x) { return sin(x + 1.57079632679489661923); }
double tan(double x) { return sin(x) / cos(x); }
double atan(double x)
{
    int neg = x < 0; if (neg) x = -x;
    int inv = x > 1; if (inv) x = 1 / x;
    double t = x, s = x;
    if (x > 0.5) { x = (x - 1) / (x + 1); double y = x, r = x; for (int i = 1; i < 30; i++) { y *= -x * x; r += y / (2 * i + 1); } s = r + 0.78539816339744830962; }
    else { for (int i = 1; i < 30; i++) { t *= -x * x; s += t / (2 * i + 1); } }
    if (inv) s = 1.57079632679489661923 - s;
    return neg ? -s : s;
}
double atan2(double y, double x)
{
    const double pi = 3.14159265358979323846;
    if (x > 0) return atan(y / x);
    if (x < 0) return y >= 0 ? atan(y / x) + pi : atan(y / x) - pi;
    return y > 0 ? pi / 2 : y < 0 ? -pi / 2 : 0;
}
double exp(double x)
{
    double t = 1, s = 1;
    for (int i = 1; i < 60; i++) { t *= x / i; s += t; }
    return s;
}
double log(double x)
{
    if (x <= 0) return 0;
    int k = 0;
    while (x > 2) { x /= 2.718281828459045; k++; }
    while (x < 0.5) { x *= 2.718281828459045; k--; }
    double y = (x - 1) / (x + 1), y2 = y * y, t = y, s = 0;
    for (int i = 0; i < 40; i++) { s += t / (2 * i + 1); t *= y2; }
    return 2 * s + k;
}
double pow(double a, double b) { return exp(b * log(a)); }
