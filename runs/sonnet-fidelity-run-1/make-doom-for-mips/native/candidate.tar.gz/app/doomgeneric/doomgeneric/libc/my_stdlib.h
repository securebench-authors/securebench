#ifndef MY_STDLIB_H
#define MY_STDLIB_H
/* Minimal freestanding libc for the custom MIPS VM. */
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>

typedef struct _FILE { int fd; int eof; int err; int ungot; } FILE;
extern FILE *stdin, *stdout, *stderr;
#define EOF (-1)
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define BUFSIZ 1024
#define NULL_FD (-1)

#define O_RDONLY 0
#define O_WRONLY 1
#define O_RDWR 2
#define O_CREAT 64
#define O_TRUNC 512
#define O_APPEND 1024

#define RAND_MAX 32767
#define EXIT_FAILURE 1
#define EXIT_SUCCESS 0
#define PATH_MAX 1024

typedef long ssize_t;
typedef long off_t;
typedef long time_t;
typedef unsigned int mode_t;
typedef int errno_t;
extern int errno;
#define ENOENT 2
#define EEXIST 17
#define EISDIR 21

/* string.h */
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memchr(const void *, int, size_t);
size_t strlen(const char *);
char *strcpy(char *, const char *);
char *strncpy(char *, const char *, size_t);
char *strcat(char *, const char *);
char *strncat(char *, const char *, size_t);
int strcmp(const char *, const char *);
int strncmp(const char *, const char *, size_t);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);
char *strchr(const char *, int);
char *strrchr(const char *, int);
char *strstr(const char *, const char *);
char *strdup(const char *);
char *strerror(int);

/* ctype.h */
int toupper(int);
int tolower(int);
int isspace(int);
int isalpha(int);
int isdigit(int);
int isalnum(int);
int isupper(int);
int islower(int);
int isprint(int);
int isxdigit(int);

/* stdlib.h */
void *malloc(size_t);
void *calloc(size_t, size_t);
void *realloc(void *, size_t);
void free(void *);
void exit(int) __attribute__((noreturn));
void abort(void) __attribute__((noreturn));
int atoi(const char *);
long atol(const char *);
double atof(const char *);
long strtol(const char *, char **, int);
unsigned long strtoul(const char *, char **, int);
int abs(int);
long labs(long);
char *getenv(const char *);
int system(const char *);
void qsort(void *, size_t, size_t, int (*)(const void *, const void *));
int rand(void);
void srand(unsigned);

/* stdio.h */
FILE *fopen(const char *, const char *);
int fclose(FILE *);
size_t fread(void *, size_t, size_t, FILE *);
size_t fwrite(const void *, size_t, size_t, FILE *);
int fseek(FILE *, long, int);
long ftell(FILE *);
int fflush(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fgetc(FILE *);
#define getc fgetc
char *fgets(char *, int, FILE *);
int fputc(int, FILE *);
#define putc fputc
int fputs(const char *, FILE *);
int putchar(int);
int puts(const char *);
int fileno(FILE *);
int printf(const char *, ...);
int fprintf(FILE *, const char *, ...);
int sprintf(char *, const char *, ...);
int snprintf(char *, size_t, const char *, ...);
int vprintf(const char *, va_list);
int vfprintf(FILE *, const char *, va_list);
int vsprintf(char *, const char *, va_list);
int vsnprintf(char *, size_t, const char *, va_list);
int sscanf(const char *, const char *, ...);
int fscanf(FILE *, const char *, ...);
int remove(const char *);
int rename(const char *, const char *);

/* unistd / sys */
int mkdir(const char *, mode_t);
int isatty(int);
int access(const char *, int);
ssize_t read(int, void *, size_t);
ssize_t write(int, const void *, size_t);
int open(const char *, int, ...);
int close(int);
off_t lseek(int, off_t, int);
time_t time(time_t *);

/* assert.h */
#define assert(x) ((void)0)

/* math.h (soft-float) */
double fabs(double);
double floor(double);
double ceil(double);
double sqrt(double);
double pow(double, double);
double sin(double);
double cos(double);
double tan(double);
double atan(double);
double atan2(double, double);
double fmod(double, double);
double log(double);
double exp(double);
#define M_PI 3.14159265358979323846

#endif
