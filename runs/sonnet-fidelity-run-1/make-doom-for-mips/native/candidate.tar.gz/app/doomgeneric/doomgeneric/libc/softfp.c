/* Tiny soft-float / 64-bit integer runtime (replaces libgcc, truncating). */
#include <stdint.h>
typedef uint64_t u64; typedef int64_t i64; typedef uint32_t u32; typedef int32_t i32;

/* ---- 64-bit division ---- */
u64 __udivmoddi4(u64 n, u64 d, u64 *rem)
{
    u64 q = 0, r = 0;
    for (int i = 63; i >= 0; i--) {
        r = (r << 1) | ((n >> i) & 1);
        if (r >= d) { r -= d; q |= (u64)1 << i; }
    }
    if (rem) *rem = r;
    return q;
}
u64 __udivdi3(u64 n, u64 d) { return __udivmoddi4(n, d, 0); }
u64 __umoddi3(u64 n, u64 d) { u64 r; __udivmoddi4(n, d, &r); return r; }
i64 __divdi3(i64 n, i64 d)
{
    int neg = (n < 0) ^ (d < 0);
    u64 q = __udivmoddi4(n < 0 ? -(u64)n : n, d < 0 ? -(u64)d : d, 0);
    return neg ? -(i64)q : (i64)q;
}
i64 __moddi3(i64 n, i64 d)
{
    u64 r; __udivmoddi4(n < 0 ? -(u64)n : n, d < 0 ? -(u64)d : d, &r);
    return n < 0 ? -(i64)r : (i64)r;
}

/* ---- double: value = (-1)^s * m * 2^e ---- */
typedef union { double d; u64 u; } dbl;

static void unpack(double x, int *s, u64 *m, int *e)
{
    dbl v; v.d = x;
    *s = v.u >> 63;
    int be = (v.u >> 52) & 0x7ff;
    u64 f = v.u & 0xfffffffffffffull;
    if (be == 0) { *m = 0; *e = 0; return; }   /* zero / denormal -> 0 */
    *m = f | (1ull << 52);
    *e = be - 1075;
}
static double pack(int s, u64 m, int e)
{
    dbl v;
    if (!m) { v.u = (u64)s << 63; return v.d; }
    while (m >> 53) { m >>= 1; e++; }
    while (!(m >> 52)) { m <<= 1; e--; }
    int be = e + 1075;
    if (be >= 0x7ff) { v.u = ((u64)s << 63) | (0x7ffull << 52); return v.d; }
    if (be <= 0) { v.u = (u64)s << 63; return v.d; }
    v.u = ((u64)s << 63) | ((u64)be << 52) | (m & 0xfffffffffffffull);
    return v.d;
}

double __adddf3(double a, double b)
{
    int sa, sb, ea, eb; u64 ma, mb;
    unpack(a, &sa, &ma, &ea); unpack(b, &sb, &mb, &eb);
    if (!ma) return b;
    if (!mb) return a;
    if (ea < eb) { int t = ea; ea = eb; eb = t; u64 tm = ma; ma = mb; mb = tm; int ts = sa; sa = sb; sb = ts; }
    int d = ea - eb;
    int up = d > 10 ? 10 : d;
    ma <<= up; ea -= up; d -= up;
    mb = d > 63 ? 0 : mb >> d;
    if (sa == sb) return pack(sa, ma + mb, ea);
    if (ma >= mb) return pack(sa, ma - mb, ea);
    return pack(sb, mb - ma, ea);
}
double __subdf3(double a, double b) { dbl v; v.d = b; v.u ^= 1ull << 63; return __adddf3(a, v.d); }

static u64 mulhi(u64 a, u64 b)
{
    u64 a0 = (u32)a, a1 = a >> 32, b0 = (u32)b, b1 = b >> 32;
    u64 p00 = a0 * b0, p01 = a0 * b1, p10 = a1 * b0, p11 = a1 * b1;
    u64 mid = (p00 >> 32) + (u32)p01 + (u32)p10;
    return p11 + (p01 >> 32) + (p10 >> 32) + (mid >> 32);
}
double __muldf3(double a, double b)
{
    int sa, sb, ea, eb; u64 ma, mb;
    unpack(a, &sa, &ma, &ea); unpack(b, &sb, &mb, &eb);
    if (!ma || !mb) return pack(sa ^ sb, 0, 0);
    u64 hi = mulhi(ma << 11, mb << 11);
    return pack(sa ^ sb, hi, ea + eb + 22 + 64 - 64 + 0);
}
double __divdf3(double a, double b)
{
    int sa, sb, ea, eb; u64 ma, mb;
    unpack(a, &sa, &ma, &ea); unpack(b, &sb, &mb, &eb);
    if (!ma) return pack(sa ^ sb, 0, 0);
    if (!mb) return pack(sa ^ sb, 1, 2000);
    u64 q = 0, r = ma;
    for (int i = 0; i < 55; i++) {
        q <<= 1;
        if (r >= mb) { r -= mb; q |= 1; }
        r <<= 1;
    }
    return pack(sa ^ sb, q, ea - eb - 54);
}

static int cmpd(double a, double b)
{
    dbl x, y; x.d = a; y.d = b;
    int zx = !(x.u << 1), zy = !(y.u << 1);
    if (zx && zy) return 0;
    int sx = x.u >> 63, sy = y.u >> 63;
    if (sx != sy) return sx ? -1 : 1;
    if (x.u == y.u) return 0;
    int lt = x.u < y.u;
    return (lt ^ sx) ? -1 : 1;
}
int __ltdf2(double a, double b) { return cmpd(a, b); }
int __ledf2(double a, double b) { return cmpd(a, b); }
int __gtdf2(double a, double b) { return cmpd(a, b); }
int __gedf2(double a, double b) { return cmpd(a, b); }
int __eqdf2(double a, double b) { return cmpd(a, b); }
int __nedf2(double a, double b) { return cmpd(a, b); }

double __floatsidf(i32 i) { return pack(i < 0, i < 0 ? -(u64)(i64)i : (u64)i, 0); }
double __floatunsidf(u32 i) { return pack(0, i, 0); }
double __floatdidf(i64 i) { return pack(i < 0, i < 0 ? -(u64)i : (u64)i, 0); }
double __floatundidf(u64 i) { return pack(0, i, 0); }
u64 __fixunsdfdi(double x)
{
    int s, e; u64 m; unpack(x, &s, &m, &e);
    if (s || !m) return 0;
    if (e >= 0) return e > 11 ? ~0ull : m << e;
    return -e > 63 ? 0 : m >> -e;
}
i64 __fixdfdi(double x)
{
    int s, e; u64 m; unpack(x, &s, &m, &e);
    u64 v;
    if (!m) return 0;
    if (e >= 0) v = e > 10 ? 0x7fffffffffffffffull : m << e;
    else v = -e > 63 ? 0 : m >> -e;
    return s ? -(i64)v : (i64)v;
}
i32 __fixdfsi(double x) { return (i32)__fixdfdi(x); }
u32 __fixunsdfsi(double x) { return (u32)__fixunsdfdi(x); }

/* ---- float via double ---- */
typedef union { float f; u32 u; } flt;
double __extendsfdf2(float x)
{
    flt v; v.f = x;
    int s = v.u >> 31, be = (v.u >> 23) & 0xff;
    u64 m = v.u & 0x7fffff;
    if (!be) return pack(s, 0, 0);
    return pack(s, m | 0x800000, be - 150);
}
float __truncdfsf2(double x)
{
    int s, e; u64 m; unpack(x, &s, &m, &e);
    flt v;
    if (!m) { v.u = (u32)s << 31; return v.f; }
    e += 52;                      /* m in [2^52,2^53) -> value = 1.f * 2^e */
    int be = e + 127;
    if (be >= 255) { v.u = ((u32)s << 31) | (0xffu << 23); return v.f; }
    if (be <= 0) { v.u = (u32)s << 31; return v.f; }
    v.u = ((u32)s << 31) | ((u32)be << 23) | (u32)((m >> 29) & 0x7fffff);
    return v.f;
}
float __addsf3(float a, float b) { return __truncdfsf2(__adddf3(__extendsfdf2(a), __extendsfdf2(b))); }
float __subsf3(float a, float b) { return __truncdfsf2(__subdf3(__extendsfdf2(a), __extendsfdf2(b))); }
float __mulsf3(float a, float b) { return __truncdfsf2(__muldf3(__extendsfdf2(a), __extendsfdf2(b))); }
float __divsf3(float a, float b) { return __truncdfsf2(__divdf3(__extendsfdf2(a), __extendsfdf2(b))); }
float __floatsisf(i32 i) { return __truncdfsf2(__floatsidf(i)); }
float __floatunsisf(u32 i) { return __truncdfsf2(__floatunsidf(i)); }
i32 __fixsfsi(float x) { return __fixdfsi(__extendsfdf2(x)); }
int __ltsf2(float a, float b) { return cmpd(__extendsfdf2(a), __extendsfdf2(b)); }
int __gtsf2(float a, float b) { return __ltsf2(a, b); }
int __lesf2(float a, float b) { return __ltsf2(a, b); }
int __gesf2(float a, float b) { return __ltsf2(a, b); }
int __eqsf2(float a, float b) { return __ltsf2(a, b); }
int __nesf2(float a, float b) { return __ltsf2(a, b); }
