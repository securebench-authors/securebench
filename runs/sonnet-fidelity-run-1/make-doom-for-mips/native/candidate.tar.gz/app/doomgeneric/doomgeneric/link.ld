ENTRY(main)
SECTIONS
{
  . = 0x00400000;
  .text : { *(.text .text.*) }
  .rodata : { *(.rodata .rodata.* .rodata1) }
  . = ALIGN(16);
  .data : { *(.data .data.* .sdata .sdata.*) }
  .bss : { *(.sbss .sbss.* .bss .bss.* COMMON) }
  /DISCARD/ : { *(.comment .note* .eh_frame* .MIPS.abiflags .reginfo .gnu.attributes .pdr) }
}
