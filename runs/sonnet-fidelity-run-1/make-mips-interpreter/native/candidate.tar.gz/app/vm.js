'use strict';
// MIPS32 (little-endian, o32) user-mode interpreter for doomgeneric_mips.
const fs = require('fs');
const path = require('path');

const ELF = process.argv[2] || path.join(__dirname, 'doomgeneric_mips');
const MAX_INSTR = Infinity;

// ---------- memory (sparse 4K pages) ----------
const p8 = new Array(1 << 20);
const p32 = new Array(1 << 20);
function page(pn) {
  const b = new ArrayBuffer(4096);
  p8[pn] = new Uint8Array(b);
  p32[pn] = new Int32Array(b);
  return p8[pn];
}
function lw(a) {
  const pn = a >>> 12;
  if (p32[pn] === undefined) page(pn);
  return p32[pn][(a & 0xfff) >> 2];
}
function sw(a, v) {
  const pn = a >>> 12;
  if (p32[pn] === undefined) page(pn);
  p32[pn][(a & 0xfff) >> 2] = v;
}
function lb(a) {
  const pn = a >>> 12;
  if (p8[pn] === undefined) page(pn);
  return p8[pn][a & 0xfff];
}
function sb(a, v) {
  const pn = a >>> 12;
  if (p8[pn] === undefined) page(pn);
  p8[pn][a & 0xfff] = v;
}
function lh(a) { return lb(a) | (lb(a + 1) << 8); }
function sh(a, v) { sb(a, v & 255); sb(a + 1, (v >> 8) & 255); }
function readBytes(a, n) {
  const out = Buffer.alloc(n);
  for (let i = 0; i < n; i++) out[i] = lb(a + i);
  return out;
}
function writeBytes(a, buf, n) {
  for (let i = 0; i < n; i++) sb(a + i, buf[i]);
}
function cstr(a) {
  const bytes = [];
  for (;;) { const c = lb(a++); if (!c) break; bytes.push(c); }
  return Buffer.from(bytes).toString('latin1');
}

// ---------- ELF loading ----------
const elf = fs.readFileSync(ELF);
if (elf.readUInt32BE(0) !== 0x7f454c46) throw new Error('not an ELF');
const entry = elf.readUInt32LE(24);
const phoff = elf.readUInt32LE(28);
const phentsize = elf.readUInt16LE(42);
const phnum = elf.readUInt16LE(44);
for (let i = 0; i < phnum; i++) {
  const o = phoff + i * phentsize;
  if (elf.readUInt32LE(o) !== 1) continue; // PT_LOAD
  const off = elf.readUInt32LE(o + 4), va = elf.readUInt32LE(o + 8), fsz = elf.readUInt32LE(o + 16);
  for (let j = 0; j < fsz; j++) sb(va + j, elf[off + j]); // bss stays lazily zero
}

// ---------- CPU state ----------
const R = new Int32Array(32);
let HI = 0, LO = 0;
const fbuf = new ArrayBuffer(32 * 8);
const F32 = new Float32Array(fbuf), FI = new Int32Array(fbuf), F64 = new Float64Array(fbuf);
// 32 single regs; double reg n (even) occupies singles n, n+1 => F64[n/2]
let fcc = false;
let pc = entry, npc = entry + 4;
R[29] = 0x7fff0000;
// minimal argc/argv on the stack
sw(R[29], 0); sw(R[29] + 4, 0);
R[28] = 0;

// ---------- syscalls (x86-64 numbering, as used by the guest libc) ----------
const fds = new Map(); // guest fd -> host fd
let nextFd = 3;
function hostPath(p) {
  if (fs.existsSync(p)) return p;
  const alt = path.join(__dirname, p);
  if (!path.isAbsolute(p) && fs.existsSync(alt)) return alt;
  return p;
}
function errno(e) { return e && typeof e.errno === 'number' ? e.errno : -5; }
function syscall() {
  const n = R[2], a0 = R[4], a1 = R[5], a2 = R[6];
  try {
    switch (n) {
      case 0: { // read
        const fd = fds.get(a0);
        if (fd === undefined && a0 !== 0) return -9;
        const buf = Buffer.alloc(a2);
        const got = fs.readSync(a0 === 0 ? 0 : fd, buf, 0, a2, null);
        writeBytes(a1, buf, got);
        return got;
      }
      case 1: { // write
        const buf = readBytes(a1, a2);
        if (a0 === 1 || a0 === 2) { fs.writeSync(a0, buf); return a2; }
        const fd = fds.get(a0);
        if (fd === undefined) return -9;
        return fs.writeSync(fd, buf, 0, a2, null);
      }
      case 2: { // open
        const p = cstr(a0);
        let flags = a1;
        const acc = flags & 3;
        let m;
        if (flags & 0x40) { // O_CREAT
          if (acc === 0) m = 'r';
          else if (flags & 0x80) m = acc === 2 ? 'wx+' : 'wx';
          else if (flags & 0x200 || (flags & 0x400 && acc === 1)) m = acc === 2 ? 'w+' : 'w';
          else if (flags & 0x400) m = 'a+';
          else m = fs.existsSync(p) ? 'r+' : (acc === 2 ? 'w+' : 'w');
        } else {
          m = acc === 0 ? 'r' : 'r+';
          if (flags & 0x200) m = 'w+';
        }
        const hp = acc === 0 ? hostPath(p) : p;
        const h = fs.openSync(hp, m);
        const g = nextFd++;
        fds.set(g, h);
        return g;
      }
      case 3: { // close
        const h = fds.get(a0);
        if (h === undefined) return a0 < 3 ? 0 : -9;
        fs.closeSync(h); fds.delete(a0);
        return 0;
      }
      case 8: { // lseek (32-bit offsets)
        const h = fds.get(a0);
        if (h === undefined) return -29;
        const st = fs.fstatSync(h);
        fdPos.set(a0, fdPos.get(a0) || 0);
        return -38; // replaced below
      }
      case 74: return 0; // fsync
      case 82: fs.renameSync(cstr(a0), cstr(a1)); return 0;
      case 83: fs.mkdirSync(cstr(a0)); return 0;
      case 87: fs.unlinkSync(cstr(a0)); return 0;
      case 60: case 231: // exit
        process.exitCode = a0 & 255;
        halted = true;
        return 0;
      default:
        process.stderr.write(`unhandled syscall ${n}\n`);
        return -38;
    }
  } catch (e) {
    return e.code === 'ENOENT' ? -2 : e.code === 'EEXIST' ? -17 : e.code === 'EACCES' ? -13 : -Math.abs(errno(e));
  }
}
// lseek needs explicit position tracking since we use sequential reads/writes via host fd
const fdPos = new Map();
let halted = false;

// Track positions ourselves for correct lseek: wrap read/write host positions by using the host's
// implicit position (null) and emulate lseek via reopening is impractical; instead keep a
// per-fd offset and use positional I/O everywhere.
const posIO = true;
(function patchIO() {
  const origSyscall = syscall;
  global.__sys = function () {
    const n = R[2], a0 = R[4], a1 = R[5], a2 = R[6];
    const h = fds.get(a0);
    try {
      if ((n === 0 || n === 1 || n === 8) && h !== undefined) {
        let pos = fdPos.get(a0) || 0;
        if (n === 0) {
          const buf = Buffer.alloc(a2);
          const got = fs.readSync(h, buf, 0, a2, pos);
          writeBytes(a1, buf, got);
          fdPos.set(a0, pos + got);
          return got;
        }
        if (n === 1) {
          const buf = readBytes(a1, a2);
          const w = fs.writeSync(h, buf, 0, a2, pos);
          fdPos.set(a0, pos + w);
          return w;
        }
        const whence = a2;
        const size = fs.fstatSync(h).size;
        const off = a1; // signed 32-bit
        let np = whence === 0 ? off : whence === 1 ? pos + off : size + off;
        if (np < 0) return -22;
        fdPos.set(a0, np);
        return np;
      }
      if (n === 3) fdPos.delete(a0);
      if (n === 8) return -29;
    } catch (e) { return -Math.abs(errno(e)) || -5; }
    return origSyscall();
  };
})();

// ---------- interpreter ----------
function bcd(v) { return v; }
function run() {
  let count = 0;
  while (!halted && count < MAX_INSTR) {
    // execute a batch
    for (let k = 0; k < 100000 && !halted; k++) {
      const ins = lw(pc);
      pc = npc; npc = (npc + 4) | 0;
      const op = ins >>> 26;
      const rs = (ins >>> 21) & 31, rt = (ins >>> 16) & 31, rd = (ins >>> 11) & 31;
      const imm = (ins << 16) >> 16;
      switch (op) {
        case 0: {
          const sa = (ins >>> 6) & 31;
          switch (ins & 63) {
            case 0: R[rd] = R[rt] << sa; break;
            case 1: if (((ins >>> 16) & 1) === 0) { if (fcc === false) {} } // movf/movt
              { const tf = (ins >>> 16) & 1; if (fcc === !!tf) R[rd] = R[rs]; } break;
            case 2: R[rd] = (ins >>> 21) & 1 ? (R[rt] >>> sa) | (R[rt] << (32 - sa)) : R[rt] >>> sa; break;
            case 3: R[rd] = R[rt] >> sa; break;
            case 4: R[rd] = R[rt] << (R[rs] & 31); break;
            case 6: if ((ins >>> 6) & 1) { const s = R[rs] & 31; R[rd] = (R[rt] >>> s) | (R[rt] << (32 - s)); } else R[rd] = R[rt] >>> (R[rs] & 31); break;
            case 7: R[rd] = R[rt] >> (R[rs] & 31); break;
            case 8: npc = R[rs]; break;
            case 9: { const t = R[rs]; R[rd] = pc + 4; npc = t; break; }
            case 10: if (R[rt] === 0) R[rd] = R[rs]; break;
            case 11: if (R[rt] !== 0) R[rd] = R[rs]; break;
            case 12: { const r = global.__sys(); R[2] = r; R[7] = r < 0 ? 1 : 0; break; }
            case 13: halted = true; process.stderr.write('break at ' + (pc - 4).toString(16) + '\n'); break;
            case 15: break; // sync
            case 16: R[rd] = HI; break;
            case 17: HI = R[rs]; break;
            case 18: R[rd] = LO; break;
            case 19: LO = R[rs]; break;
            case 24: { const p = BigInt(R[rs]) * BigInt(R[rt]); LO = Number(BigInt.asIntN(32, p)); HI = Number(BigInt.asIntN(32, p >> 32n)); break; }
            case 25: { const p = BigInt(R[rs] >>> 0) * BigInt(R[rt] >>> 0); LO = Number(BigInt.asIntN(32, p)); HI = Number(BigInt.asIntN(32, p >> 32n)); break; }
            case 26: if (R[rt] !== 0) { LO = (R[rs] / R[rt]) | 0; HI = R[rs] % R[rt] | 0; } break;
            case 27: if (R[rt] !== 0) { const a = R[rs] >>> 0, b = R[rt] >>> 0; LO = Math.floor(a / b) | 0; HI = (a % b) | 0; } break;
            case 32: case 33: R[rd] = R[rs] + R[rt]; break;
            case 34: case 35: R[rd] = R[rs] - R[rt]; break;
            case 36: R[rd] = R[rs] & R[rt]; break;
            case 37: R[rd] = R[rs] | R[rt]; break;
            case 38: R[rd] = R[rs] ^ R[rt]; break;
            case 39: R[rd] = ~(R[rs] | R[rt]); break;
            case 42: R[rd] = R[rs] < R[rt] ? 1 : 0; break;
            case 43: R[rd] = (R[rs] >>> 0) < (R[rt] >>> 0) ? 1 : 0; break;
            case 52: if (R[rs] === R[rt]) { halted = true; process.stderr.write('trap\n'); } break; // teq
            default: throw new Error('bad special ' + (ins & 63) + ' at ' + (pc - 8).toString(16));
          }
          break;
        }
        case 1: {
          const t = R[rs];
          switch (rt) {
            case 0: if (t < 0) npc = (pc + (imm << 2)) | 0; break;
            case 1: if (t >= 0) npc = (pc + (imm << 2)) | 0; break;
            case 16: R[31] = pc + 4; if (t < 0) npc = (pc + (imm << 2)) | 0; break;
            case 17: R[31] = pc + 4; if (t >= 0) npc = (pc + (imm << 2)) | 0; break;
            default: throw new Error('bad regimm ' + rt);
          }
          break;
        }
        case 2: npc = ((pc & 0xf0000000) | ((ins & 0x3ffffff) << 2)) | 0; break;
        case 3: R[31] = pc + 4; npc = ((pc & 0xf0000000) | ((ins & 0x3ffffff) << 2)) | 0; break;
        case 4: if (R[rs] === R[rt]) npc = (pc + (imm << 2)) | 0; break;
        case 5: if (R[rs] !== R[rt]) npc = (pc + (imm << 2)) | 0; break;
        case 6: if (R[rs] <= 0) npc = (pc + (imm << 2)) | 0; break;
        case 7: if (R[rs] > 0) npc = (pc + (imm << 2)) | 0; break;
        case 8: case 9: R[rt] = R[rs] + imm; break;
        case 10: R[rt] = R[rs] < imm ? 1 : 0; break;
        case 11: R[rt] = (R[rs] >>> 0) < (imm >>> 0) ? 1 : 0; break;
        case 12: R[rt] = R[rs] & (ins & 0xffff); break;
        case 13: R[rt] = R[rs] | (ins & 0xffff); break;
        case 14: R[rt] = R[rs] ^ (ins & 0xffff); break;
        case 15: R[rt] = ins << 16; break;
        case 17: { // COP1
          const fmt = rs, fs_ = rd, ft = rt, fd = (ins >>> 6) & 31, fn = ins & 63;
          switch (fmt) {
            case 0: R[rt] = FI[fs_]; break; // mfc1
            case 2: R[rt] = FI[fs_ | 1]; break; // mfhc1 (approx)
            case 4: FI[fs_] = R[rt]; break; // mtc1
            case 7: FI[fs_ | 1] = R[rt]; break; // mthc1
            case 8: { // bc1f/bc1t
              const tf = (ins >>> 16) & 1;
              if (fcc === !!tf) npc = (pc + (imm << 2)) | 0;
              break;
            }
            case 16: case 17: case 20: {
              const d = fmt === 17;
              const g = d ? (i) => F64[i >> 1] : (i) => F32[i];
              const s = d ? (i, v) => { F64[i >> 1] = v; } : (i, v) => { F32[i] = v; };
              switch (fn) {
                case 0: s(fd, g(fs_) + g(ft)); break;
                case 1: s(fd, g(fs_) - g(ft)); break;
                case 2: s(fd, g(fs_) * g(ft)); break;
                case 3: s(fd, g(fs_) / g(ft)); break;
                case 4: s(fd, Math.sqrt(g(fs_))); break;
                case 5: s(fd, Math.abs(g(fs_))); break;
                case 6: if (d) F64[fd >> 1] = F64[fs_ >> 1]; else FI[fd] = FI[fs_]; break;
                case 7: s(fd, -g(fs_)); break;
                case 9: case 13: { // trunc.l / trunc.w
                  const v = Math.trunc(g(fs_)); FI[fd] = v | 0; break;
                }
                case 12: FI[fd] = Math.round(g(fs_)) | 0; break;
                case 14: FI[fd] = Math.ceil(g(fs_)) | 0; break;
                case 15: FI[fd] = Math.floor(g(fs_)) | 0; break;
                case 17: { // movf/movt.fmt
                  const tf = (ins >>> 16) & 1;
                  if (fcc === !!tf) { if (d) F64[fd >> 1] = F64[fs_ >> 1]; else FI[fd] = FI[fs_]; }
                  break;
                }
                case 18: if (R[rt] === 0) { if (d) F64[fd >> 1] = F64[fs_ >> 1]; else FI[fd] = FI[fs_]; } break;
                case 19: if (R[rt] !== 0) { if (d) F64[fd >> 1] = F64[fs_ >> 1]; else FI[fd] = FI[fs_]; } break;
                case 32: F32[fd] = g(fs_); break; // cvt.s
                case 33: F64[fd >> 1] = g(fs_); break; // cvt.d
                case 36: FI[fd] = Math.round(g(fs_)) | 0; break;
                default:
                  if (fn >= 48) {
                    const a = g(fs_), b = g(ft);
                    const un = a !== a || b !== b;
                    let r = false;
                    switch (fn & 7) {
                      case 0: r = false; break;
                      case 1: r = un; break;
                      case 2: r = !un && a === b; break;
                      case 3: r = un || a === b; break;
                      case 4: r = !un && a < b; break;
                      case 5: r = un || a < b; break;
                      case 6: r = !un && a <= b; break;
                      case 7: r = un || a <= b; break;
                    }
                    fcc = r;
                  } else throw new Error('bad fp fn ' + fn);
              }
              break;
            }
            case 20 + 0: break;
            default: throw new Error('bad cop1 fmt ' + fmt);
          }
          break;
        }
        case 28: { // SPECIAL2
          switch (ins & 63) {
            case 2: R[rd] = Math.imul(R[rs], R[rt]); break;
            case 32: R[rd] = Math.clz32(R[rs]); break;
            case 33: R[rd] = Math.clz32(~R[rs]); break;
            default: throw new Error('bad special2 ' + (ins & 63));
          }
          break;
        }
        case 31: { // SPECIAL3
          const fn = ins & 63;
          if (fn === 0) { // ext
            const size = rd + 1, pos = (ins >>> 6) & 31;
            R[rt] = (R[rs] >>> pos) & (size >= 32 ? -1 : ((1 << size) - 1));
          } else if (fn === 4) { // ins
            const msb = rd, lsb = (ins >>> 6) & 31, size = msb - lsb + 1;
            const mask = size >= 32 ? -1 : (((1 << size) - 1) << lsb);
            R[rt] = (R[rt] & ~mask) | ((R[rs] << lsb) & mask);
          } else if (fn === 32) {
            const sa = (ins >>> 6) & 31;
            if (sa === 2) { const v = R[rt]; R[rd] = ((v & 0xff00ff00) >>> 8) | ((v & 0x00ff00ff) << 8); } // wsbh
            else if (sa === 16) R[rd] = (R[rt] << 24) >> 24; // seb
            else if (sa === 24) R[rd] = (R[rt] << 16) >> 16; // seh
            else throw new Error('bad bshfl');
          } else if (fn === 59) { R[rt] = 0; } // rdhwr
          else throw new Error('bad special3 ' + fn);
          break;
        }
        case 32: { const b = lb(R[rs] + imm); R[rt] = (b << 24) >> 24; break; }
        case 33: { const h = lh(R[rs] + imm); R[rt] = (h << 16) >> 16; break; }
        case 34: { // lwl
          const a = R[rs] + imm, sh_ = a & 3, w = lw(a & ~3);
          const cur = R[rt];
          R[rt] = sh_ === 3 ? w : (w << (24 - sh_ * 8)) | (cur & ((1 << (24 - sh_ * 8)) - 1));
          break;
        }
        case 35: R[rt] = lw(R[rs] + imm); break;
        case 36: R[rt] = lb(R[rs] + imm); break;
        case 37: R[rt] = lh(R[rs] + imm); break;
        case 38: { // lwr
          const a = R[rs] + imm, sh_ = a & 3, w = lw(a & ~3);
          const cur = R[rt];
          R[rt] = sh_ === 0 ? w : (w >>> (sh_ * 8)) | (cur & ~(-1 >>> (sh_ * 8)));
          break;
        }
        case 40: sb(R[rs] + imm, R[rt] & 255); break;
        case 41: sh(R[rs] + imm, R[rt]); break;
        case 42: { // swl
          const a = R[rs] + imm, sh_ = a & 3, base = a & ~3, w = lw(base), v = R[rt];
          if (sh_ === 3) sw(base, v);
          else { const m = -1 >>> (24 - sh_ * 8); sw(base, (w & ~m) | (v >>> (24 - sh_ * 8))); }
          break;
        }
        case 43: sw(R[rs] + imm, R[rt]); break;
        case 46: { // swr
          const a = R[rs] + imm, sh_ = a & 3, base = a & ~3, w = lw(base), v = R[rt];
          if (sh_ === 0) sw(base, v);
          else { const m = -1 << (sh_ * 8); sw(base, (w & ~m) | (v << (sh_ * 8))); }
          break;
        }
        case 48: R[rt] = lw(R[rs] + imm); break; // ll
        case 56: sw(R[rs] + imm, R[rt]); R[rt] = 1; break; // sc
        case 49: FI[rt] = lw(R[rs] + imm); break; // lwc1
        case 53: { const a = R[rs] + imm; FI[rt & ~1] = lw(a); FI[rt | 1] = lw(a + 4); break; } // ldc1
        case 57: sw(R[rs] + imm, FI[rt]); break; // swc1
        case 61: { const a = R[rs] + imm; sw(a, FI[rt & ~1]); sw(a + 4, FI[rt | 1]); break; } // sdc1
        case 51: break; // pref
        default:
          throw new Error('bad opcode ' + op + ' at ' + (pc - 8).toString(16));
      }
      R[0] = 0;
    }
    count += 100000;
  }
}

try {
  run();
} catch (e) {
  process.stderr.write(e.stack + `\npc=${pc.toString(16)}\n`);
  process.exitCode = 1;
}
