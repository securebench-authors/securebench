'use strict';
// MIPS32 (little-endian, o32) interpreter that runs /app/doomgeneric_mips.
const fs = require('fs');
const path = require('path');

const ELF = process.argv[2] || path.join(__dirname, 'doomgeneric_mips');
const MEM_SIZE = 0x41000000;
const buf = new ArrayBuffer(MEM_SIZE);
const m8 = new Uint8Array(buf);
const m32 = new Int32Array(buf);
const m16 = new Uint16Array(buf);

// ---- ELF loading ----
const elf = fs.readFileSync(ELF);
const phoff = elf.readUInt32LE(28), phentsize = elf.readUInt16LE(42), phnum = elf.readUInt16LE(44);
let pc = elf.readUInt32LE(24);
for (let i = 0; i < phnum; i++) {
  const o = phoff + i * phentsize;
  if (elf.readUInt32LE(o) !== 1) continue;
  const off = elf.readUInt32LE(o + 4), va = elf.readUInt32LE(o + 8), fsz = elf.readUInt32LE(o + 16);
  elf.copy(m8, va, off, off + fsz);
}
// symbols (for frame dumping)
const syms = {};
{
  const shoff = elf.readUInt32LE(32), shentsize = elf.readUInt16LE(46), shnum = elf.readUInt16LE(48);
  for (let i = 0; i < shnum; i++) {
    const o = shoff + i * shentsize;
    if (elf.readUInt32LE(o + 4) !== 2) continue;
    const off = elf.readUInt32LE(o + 16), size = elf.readUInt32LE(o + 20), link = elf.readUInt32LE(o + 24);
    const stro = elf.readUInt32LE(shoff + link * shentsize + 16);
    for (let s = off; s < off + size; s += 16) {
      let n = elf.readUInt32LE(s), e = stro + n;
      while (elf[e]) e++;
      syms[elf.toString('latin1', stro + n, e)] = elf.readUInt32LE(s + 4);
    }
  }
}

// ---- CPU state ----
const R = new Int32Array(32);
let hi = 0, lo = 0;
R[29] = MEM_SIZE - 64;
const fbuf = new ArrayBuffer(128);
const F32 = new Float32Array(fbuf), F64 = new Float64Array(fbuf), FI = new Int32Array(fbuf);
let fcc = 0; // condition code bit 0

// ---- Syscalls (the guest uses x86-64 style numbers; MIPS o32 numbers also accepted) ----
const fds = new Map(); // guest fd -> real fd
const cstr = (a) => { let e = a >>> 0; while (m8[e]) e++; return Buffer.from(m8.subarray(a >>> 0, e)).toString('latin1'); };
const NAMES = { 0: 'read', 1: 'write', 2: 'open', 3: 'close', 8: 'lseek', 74: 'fsync', 82: 'rename', 83: 'mkdir', 87: 'unlink', 60: 'exit', 201: 'time',
  4001: 'exit', 4003: 'read', 4004: 'write', 4005: 'open', 4006: 'close', 4019: 'lseek', 4038: 'rename', 4039: 'mkdir', 4010: 'unlink', 4118: 'fsync', 4013: 'time', 4246: 'exit' };
let exited = false;
function flags(f) {
  let r = f & 3;
  if (f & 0x40) r |= fs.constants.O_CREAT;
  if (f & 0x200) r |= fs.constants.O_TRUNC;
  if (f & 0x400) r |= fs.constants.O_APPEND;
  return r;
}
const pos = new Map();
function syscall() {
  const num = R[2], a = R[4], b = R[5], c = R[6];
  const name = NAMES[num];
  let ret = 0;
  try {
    switch (name) {
      case 'exit': exited = true; process.exitCode = a; return;
      case 'write': {
        const data = m8.subarray(b >>> 0, (b >>> 0) + (c >>> 0));
        if (a === 1 || a === 2) { fs.writeSync(a, data); ret = c; }
        else ret = fs.writeSync(fds.get(a), data);
        break;
      }
      case 'read': {
        const data = m8.subarray(b >>> 0, (b >>> 0) + (c >>> 0));
        ret = a === 0 ? 0 : fs.readSync(fds.get(a), data, 0, data.length, null);
        break;
      }
      case 'open': {
        const rfd = fs.openSync(cstr(a), flags(b), R[6] || 0o644);
        let g = 3; while (fds.has(g)) g++;
        fds.set(g, rfd); ret = g; break;
      }
      case 'close': { const r = fds.get(a); if (r !== undefined) { fs.closeSync(r); fds.delete(a); } break; }
      case 'lseek': {
        // emulate with explicit position tracking
        const r = fds.get(a); if (r === undefined) { ret = -9; break; }
        let p = pos.get(a) || 0;
        const size = fs.fstatSync(r).size;
        p = c === 0 ? b : c === 1 ? p + b : size + b;
        // reposition: re-open-free approach via a read cursor
        fdSeek(r, p);
        pos.set(a, p); ret = p; break;
      }
      case 'fsync': break;
      case 'rename': fs.renameSync(cstr(a), cstr(b)); break;
      case 'mkdir': fs.mkdirSync(cstr(a), b || 0o755); break;
      case 'unlink': fs.unlinkSync(cstr(a)); break;
      case 'time': {
        const t = Math.floor(Date.now() / 1000);
        if (a) m32[a >>> 2] = t;
        ret = t; break;
      }
      default:
        process.stderr.write(`unknown syscall ${num}\n`);
        ret = -38;
    }
  } catch (e) {
    ret = -(typeof e.errno === 'number' ? Math.abs(e.errno) : 5);
  }
  R[2] = ret; R[7] = ret < 0 && ret > -4096 ? 1 : 0;
}
// Position-aware file IO: Node lacks lseek, so keep per-fd cursors and wrap read/write.
const cursor = new Map();
function fdSeek(r, p) { cursor.set(r, p); }
const _read = fs.readSync, _write = fs.writeSync;
fs.readSync = (fd, d, o, l, p) => { if (p === null && cursor.has(fd)) { const n = _read(fd, d, o, l, cursor.get(fd)); cursor.set(fd, cursor.get(fd) + n); return n; } return _read(fd, d, o, l, p); };
fs.writeSync = (fd, d, ...rest) => { if (fd > 2 && cursor.has(fd)) { const n = _write(fd, d, 0, d.length, cursor.get(fd)); cursor.set(fd, cursor.get(fd) + n); return n; } return _write(fd, d, ...rest); };
const _open = fs.openSync;
fs.openSync = (p, f, md) => { const fd = _open(p, f, md); cursor.set(fd, (f & fs.constants.O_APPEND) ? fs.fstatSync(fd).size : 0); return fd; };

// ---- Frame dumping ----
// The guest keeps its "files" in an in-memory FS, so mirror each rendered frame to disk here.
const W = 640, H = 400;
let frameNo = 0;
function dumpFrame() {
  const sb = m32[syms.DG_ScreenBuffer >>> 2] >>> 0;
  if (!sb) return;
  const n = W * H * 4;
  const out = Buffer.alloc(54 + n);
  out.write('BM', 0); out.writeUInt32LE(54 + n, 2); out.writeUInt32LE(54, 10);
  out.writeUInt32LE(40, 14); out.writeInt32LE(W, 18); out.writeInt32LE(-H, 22);
  out.writeUInt16LE(1, 26); out.writeUInt16LE(32, 28); out.writeUInt32LE(n, 34);
  Buffer.from(buf, sb, n).copy(out, 54);
  const dir = process.env.FRAME_DIR || '/tmp';
  fs.writeFileSync(path.join(dir, 'frame.bmp'), out);
  if (frameNo < 30) fs.writeFileSync(path.join(dir, `frame_${String(frameNo).padStart(6, '0')}.bmp`), out);
  frameNo++;
}

// ---- Interpreter ----
const lw = (a) => m32[a >>> 2];
function rd32(a) { if (a & 3) { return m8[a] | (m8[a + 1] << 8) | (m8[a + 2] << 16) | (m8[a + 3] << 24); } return m32[a >>> 2]; }
function wr32(a, v) { if (a & 3) { m8[a] = v; m8[a + 1] = v >> 8; m8[a + 2] = v >> 16; m8[a + 3] = v >> 24; } else m32[a >>> 2] = v; }

const drawFrameAddr = syms.DG_DrawFrame >>> 0;
const maxFrames = process.env.MAX_FRAMES ? parseInt(process.env.MAX_FRAMES) : Infinity;
let nextPc = pc + 4;

function step(count) {
  let r = R;
  while (count-- > 0 && !exited) {
    if (pc === drawFrameAddr) {
      dumpFrame();
      if (frameNo >= maxFrames) { exited = true; return; }
    }
    const i = m32[pc >>> 2];
    const op = i >>> 26;
    const rs = (i >>> 21) & 31, rt = (i >>> 16) & 31, rdx = (i >>> 11) & 31, sa = (i >>> 6) & 31;
    const imm = (i << 16) >> 16;
    let target = -1; // branch target if taken
    switch (op) {
      case 0: {
        const fn = i & 63;
        switch (fn) {
          case 0: r[rdx] = r[rt] << sa; break;
          case 2: r[rdx] = (rs & 1) ? ((r[rt] >>> sa) | (r[rt] << (32 - sa))) : r[rt] >>> sa; break;
          case 3: r[rdx] = r[rt] >> sa; break;
          case 4: r[rdx] = r[rt] << (r[rs] & 31); break;
          case 6: { const s = r[rs] & 31; r[rdx] = (sa & 1) ? ((r[rt] >>> s) | (r[rt] << (32 - s))) : r[rt] >>> s; break; }
          case 7: r[rdx] = r[rt] >> (r[rs] & 31); break;
          case 8: target = r[rs]; break;
          case 9: { const t = r[rs]; r[rdx] = pc + 8; target = t; break; }
          case 10: if (r[rt] === 0) r[rdx] = r[rs]; break;
          case 11: if (r[rt] !== 0) r[rdx] = r[rs]; break;
          case 12: syscall(); break;
          case 13: exited = true; process.stderr.write('break at ' + pc.toString(16) + '\n'); break;
          case 15: break;
          case 16: r[rdx] = hi; break;
          case 17: hi = r[rs]; break;
          case 18: r[rdx] = lo; break;
          case 19: lo = r[rs]; break;
          case 24: { const p = BigInt(r[rs]) * BigInt(r[rt]); lo = Number(BigInt.asIntN(32, p)); hi = Number(BigInt.asIntN(32, p >> 32n)); break; }
          case 25: { const p = BigInt(r[rs] >>> 0) * BigInt(r[rt] >>> 0); lo = Number(BigInt.asIntN(32, p)); hi = Number(BigInt.asIntN(32, p >> 32n)); break; }
          case 26: if (r[rt] !== 0) { lo = (r[rs] / r[rt]) | 0; hi = (r[rs] % r[rt]) | 0; } break;
          case 27: if (r[rt] !== 0) { const a = r[rs] >>> 0, b = r[rt] >>> 0; lo = Math.floor(a / b) | 0; hi = (a % b) | 0; } break;
          case 32: case 33: r[rdx] = (r[rs] + r[rt]) | 0; break;
          case 34: case 35: r[rdx] = (r[rs] - r[rt]) | 0; break;
          case 36: r[rdx] = r[rs] & r[rt]; break;
          case 37: r[rdx] = r[rs] | r[rt]; break;
          case 38: r[rdx] = r[rs] ^ r[rt]; break;
          case 39: r[rdx] = ~(r[rs] | r[rt]); break;
          case 42: r[rdx] = r[rs] < r[rt] ? 1 : 0; break;
          case 43: r[rdx] = (r[rs] >>> 0) < (r[rt] >>> 0) ? 1 : 0; break;
          case 52: if (r[rs] === r[rt]) { exited = true; process.stderr.write('trap at ' + pc.toString(16) + '\n'); } break;
          default: throw new Error(`bad SPECIAL fn ${fn} at ${pc.toString(16)}`);
        }
        break;
      }
      case 1: {
        const cond = rt;
        const v = r[rs];
        let t = false;
        if (cond === 0 || cond === 2) t = v < 0; else if (cond === 1 || cond === 3) t = v >= 0; else throw new Error('bad REGIMM');
        if (t) target = (pc + 4 + (imm << 2)) | 0;
        break;
      }
      case 2: target = ((pc + 4) & 0xF0000000) | ((i & 0x3FFFFFF) << 2); break;
      case 3: r[31] = pc + 8; target = ((pc + 4) & 0xF0000000) | ((i & 0x3FFFFFF) << 2); break;
      case 4: if (r[rs] === r[rt]) target = (pc + 4 + (imm << 2)) | 0; break;
      case 5: if (r[rs] !== r[rt]) target = (pc + 4 + (imm << 2)) | 0; break;
      case 6: if (r[rs] <= 0) target = (pc + 4 + (imm << 2)) | 0; break;
      case 7: if (r[rs] > 0) target = (pc + 4 + (imm << 2)) | 0; break;
      case 8: case 9: r[rt] = (r[rs] + imm) | 0; break;
      case 10: r[rt] = r[rs] < imm ? 1 : 0; break;
      case 11: r[rt] = (r[rs] >>> 0) < (imm >>> 0) ? 1 : 0; break;
      case 12: r[rt] = r[rs] & (i & 0xFFFF); break;
      case 13: r[rt] = r[rs] | (i & 0xFFFF); break;
      case 14: r[rt] = r[rs] ^ (i & 0xFFFF); break;
      case 15: r[rt] = i << 16; break;
      case 16: { // COP0: only rdhwr-ish not needed
        throw new Error('COP0 at ' + pc.toString(16));
      }
      case 17: { const off = cop1(i); if (off !== undefined) target = (pc + 4 + (off << 2)) | 0; break; }
      case 28: { // SPECIAL2
        const fn = i & 63;
        if (fn === 2) r[rdx] = Math.imul(r[rs], r[rt]);
        else if (fn === 32) r[rdx] = Math.clz32(r[rs]);
        else throw new Error(`bad SPECIAL2 ${fn} at ${pc.toString(16)}`);
        break;
      }
      case 31: { // SPECIAL3
        const fn = i & 63;
        if (fn === 0) { const size = rdx + 1, p = sa; r[rt] = size >= 32 ? r[rs] : (r[rs] >>> p) & ((1 << size) - 1); }
        else if (fn === 4) { const msb = rdx, lsb = sa, size = msb - lsb + 1; const mask = size >= 32 ? -1 : ((1 << size) - 1) << lsb; r[rt] = (r[rt] & ~mask) | ((r[rs] << lsb) & mask); }
        else if (fn === 32) {
          if (sa === 16) r[rdx] = (r[rt] << 24) >> 24;
          else if (sa === 24) r[rdx] = (r[rt] << 16) >> 16;
          else if (sa === 2) { const v = r[rt]; r[rdx] = ((v & 0xFF00FF00) >>> 8) | ((v & 0x00FF00FF) << 8); }
          else throw new Error('bad BSHFL');
        } else if (fn === 59) { r[rt] = rdx === 29 ? 0 : 0; }
        else throw new Error(`bad SPECIAL3 ${fn} at ${pc.toString(16)}`);
        break;
      }
      case 32: r[rt] = (m8[(r[rs] + imm) >>> 0] << 24) >> 24; break;
      case 33: { const a = (r[rs] + imm) >>> 0; r[rt] = ((m8[a] | (m8[a + 1] << 8)) << 16) >> 16; break; }
      case 34: { // lwl
        const a = (r[rs] + imm) >>> 0, k = a & 3, w = m32[(a & ~3) >>> 2];
        const sh = (3 - k) * 8; r[rt] = k === 3 ? w : (w << sh) | (r[rt] & ((1 << sh) - 1)); break;
      }
      case 35: r[rt] = rd32((r[rs] + imm) >>> 0); break;
      case 36: r[rt] = m8[(r[rs] + imm) >>> 0]; break;
      case 37: { const a = (r[rs] + imm) >>> 0; r[rt] = m8[a] | (m8[a + 1] << 8); break; }
      case 38: { // lwr
        const a = (r[rs] + imm) >>> 0, k = a & 3, w = m32[(a & ~3) >>> 2];
        r[rt] = k === 0 ? w : (w >>> (k * 8)) | (r[rt] & ~(-1 >>> (k * 8))); break;
      }
      case 40: m8[(r[rs] + imm) >>> 0] = r[rt]; break;
      case 41: { const a = (r[rs] + imm) >>> 0; m8[a] = r[rt]; m8[a + 1] = r[rt] >> 8; break; }
      case 42: { // swl
        const a = (r[rs] + imm) >>> 0, k = a & 3, ia = (a & ~3) >>> 2, w = m32[ia], v = r[rt];
        if (k === 3) m32[ia] = v; else { const sh = (3 - k) * 8; const keep = ~(-1 >>> sh); m32[ia] = (w & keep) | (v >>> sh); }
        break;
      }
      case 43: wr32((r[rs] + imm) >>> 0, r[rt]); break;
      case 46: { // swr
        const a = (r[rs] + imm) >>> 0, k = a & 3, ia = (a & ~3) >>> 2, w = m32[ia], v = r[rt];
        if (k === 0) m32[ia] = v; else { const sh = k * 8; m32[ia] = (w & ((1 << sh) - 1)) | (v << sh); }
        break;
      }
      case 49: FI[rt] = rd32((r[rs] + imm) >>> 0); break;
      case 53: { const a = (r[rs] + imm) >>> 0; FI[rt] = rd32(a); FI[rt + 1] = rd32(a + 4); break; }
      case 57: wr32((r[rs] + imm) >>> 0, FI[rt]); break;
      case 61: { const a = (r[rs] + imm) >>> 0; wr32(a, FI[rt]); wr32(a + 4, FI[rt + 1]); break; }
      case 47: case 51: break; // cache / pref
      default: throw new Error(`bad opcode ${op} at ${pc.toString(16)}`);
    }
    r[0] = 0;
    pc = nextPc;
    nextPc = target !== -1 ? (target >>> 0) : nextPc + 4;
    // For jumps/branches the NEXT instruction is the delay slot (pc already = pc+4 = slot); nextPc = target after slot.
  }
}

// To get delay slots right: when a branch is executed, `pc` becomes the slot (nextPc previous = pc+4)
// and `nextPc` becomes the branch target. That is exactly what the tail of step() does.

function cop1(i) {
  const rs = (i >>> 21) & 31, ft = (i >>> 16) & 31, fsr = (i >>> 11) & 31, fd = (i >>> 6) & 31;
  switch (rs) {
    case 0: R[ft] = FI[fsr]; return;
    case 2: R[ft] = 0; return; // cfc1
    case 3: R[ft] = FI[fsr + 1]; return; // mfhc1
    case 4: FI[fsr] = R[ft]; return;
    case 6: return; // ctc1
    case 7: FI[fsr + 1] = R[ft]; return; // mthc1
    case 8: { // bc1f/bc1t
      const t = (i >>> 16) & 1;
      return (fcc ? 1 : 0) === t ? (i << 16) >> 16 : undefined;
    }
    case 16: case 17: case 20: {
      const d = rs === 17, fn = i & 63;
      const G = d ? (x) => F64[x >> 1] : (x) => F32[x];
      const S = d ? (x, v) => { F64[x >> 1] = v; } : (x, v) => { F32[x] = v; };
      switch (fn) {
        case 0: S(fd, G(fsr) + G(ft)); return;
        case 1: S(fd, G(fsr) - G(ft)); return;
        case 2: S(fd, G(fsr) * G(ft)); return;
        case 3: S(fd, G(fsr) / G(ft)); return;
        case 4: S(fd, Math.sqrt(G(fsr))); return;
        case 5: S(fd, Math.abs(G(fsr))); return;
        case 6: if (d) F64[fd >> 1] = F64[fsr >> 1]; else FI[fd] = FI[fsr]; return;
        case 7: S(fd, -G(fsr)); return;
        case 13: FI[fd] = Math.trunc(G(fsr)) | 0; return; // trunc.w
        case 9: FI[fd] = Math.trunc(G(fsr)) | 0; return;
        case 12: FI[fd] = Math.round(G(fsr)) | 0; return;
        case 14: FI[fd] = Math.ceil(G(fsr)) | 0; return;
        case 15: FI[fd] = Math.floor(G(fsr)) | 0; return;
        case 17: { // movf/movt
          const t = (i >>> 16) & 1;
          if ((fcc ? 1 : 0) === t) { if (d) F64[fd >> 1] = F64[fsr >> 1]; else FI[fd] = FI[fsr]; }
          return;
        }
        case 18: if (R[ft] === 0) { if (d) F64[fd >> 1] = F64[fsr >> 1]; else FI[fd] = FI[fsr]; } return;
        case 19: if (R[ft] !== 0) { if (d) F64[fd >> 1] = F64[fsr >> 1]; else FI[fd] = FI[fsr]; } return;
        case 32: F32[fd] = G(fsr); return;
        case 33: F64[fd >> 1] = G(fsr); return;
        default:
          if (fn >= 48) {
            const a = G(fsr), b = G(ft), un = a !== a || b !== b, c = fn & 15;
            let res = false;
            if (c & 1 && un) res = true;
            if (c & 2 && a === b) res = true;
            if (c & 4 && a < b) res = true;
            fcc = res ? 1 : 0;
            return;
          }
          throw new Error('bad FP fn ' + fn);
      }
    }
    case 20: {
      const fn = i & 63; // W format source
      if (fn === 32) F32[fd] = FI[fsr];
      else if (fn === 33) F64[fd >> 1] = FI[fsr];
      else throw new Error('bad W fn ' + fn);
      return;
    }
    default: throw new Error('bad COP1 rs ' + rs);
  }
}


process.stdout.on('error', () => {});
const t0 = Date.now();
try {
  while (!exited) step(1000000);
} catch (e) {
  process.stderr.write(`${e.message}\nframes=${frameNo} ${Date.now() - t0}ms\n`);
  process.exitCode = 1;
}
