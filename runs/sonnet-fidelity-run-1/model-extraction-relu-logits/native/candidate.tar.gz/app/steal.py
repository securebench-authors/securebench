import numpy as np
from forward import forward

rng = np.random.default_rng(1)
D = 10

def grad(x, eps=1e-6):
    f0 = forward(x)
    g = np.zeros(D)
    for j in range(D):
        e = np.zeros(D); e[j] = eps
        g[j] = (forward(x + e) - f0) / eps
    return g

dirs = []
N, R = 1500, 8.0
ts = np.linspace(-R, R, N)
h = ts[1] - ts[0]
for _ in range(60):
    p = rng.normal(size=D); d = rng.normal(size=D); d /= np.linalg.norm(d)
    f = np.array([forward(p + t * d) for t in ts])
    s = np.diff(f) / h
    ds = np.abs(np.diff(s))
    nz = ds > 1e-7
    for k in np.where(nz[1:] & nz[:-1])[0] + 1:
        # kink lies inside cell k (ds[k-1], ds[k] both nonzero)
        if k < 3 or k + 4 >= N: continue
        if nz[k-2] or nz[k+1]: continue  # isolated kink only
        # left line through (k-1,k)...(k, k+1)? cell k is points k,k+1 ; use cells k-1 and k+1
        sl, sr = s[k-1], s[k+1]
        # left line: f[k-1] + sl*(t-ts[k-1]); right line: f[k+3]... cell k+1 = points k+1,k+2
        fl = lambda t: f[k-1] + sl * (t - ts[k-1])
        fr = lambda t: f[k+1] + sr * (t - ts[k+1])
        if abs(sl - sr) < 1e-9: continue
        # solve fl=fr
        t0 = (f[k+1] - sr*ts[k+1] - f[k-1] + sl*ts[k-1]) / (sl - sr)
        if not (ts[k-1] <= t0 <= ts[k+2]): continue
        xs = p + t0 * d
        dl = 2e-3
        gl = grad(xs - dl * d); gr = grad(xs + dl * d)
        v = gr - gl
        n = np.linalg.norm(v)
        if n < 1e-4: continue
        # sanity: jump along d must match slope change
        if abs(v @ d - (sr - sl)) > 1e-3 * max(1, abs(sr - sl)) + 1e-4: continue
        v /= n
        i = np.argmax(np.abs(v)); v *= np.sign(v[i])
        dirs.append(v)

dirs = np.array(dirs)
# cluster
cents, counts = [], []
for v in dirs:
    for i, c in enumerate(cents):
        if np.linalg.norm(v - c) < 1e-2:
            counts[i] += 1; cents[i] = c + (v - c) / counts[i]; break
    else:
        cents.append(v.copy()); counts.append(1)
cents = [c / np.linalg.norm(c) for c in cents]
mx = max(counts)
A = np.array([c for c, n in zip(cents, counts) if n >= 0.2 * mx])
print(A.shape, counts)
np.save('/app/stolen_A1.npy', A)
