import numpy as np
from forward import forward

D = 10
rng = np.random.default_rng(1)
N, R = 4000, 8.0
ts = np.linspace(-R, R, N + 1)
s = ts[1] - ts[0]
E = 1e-6

def grad(x):
    f0 = forward(x)
    g = np.zeros(D)
    for i in range(D):
        e = np.zeros(D); e[i] = E
        g[i] = (forward(x + e) - f0) / E
    return g

dirs = []
counts = []
def add(v):
    n = np.linalg.norm(v)
    if n < 1e-6:
        return
    v = v / n
    for k, u in enumerate(dirs):
        if abs(u @ v) > 1 - 1e-6:
            counts[k] += 1
            return
    dirs.append(v)
    counts.append(1)

stable = 0
for line in range(400):
    p = rng.normal(size=D) * 0.5
    d = rng.normal(size=D); d /= np.linalg.norm(d)
    f = np.array([forward(p + t * d) for t in ts])
    sl = np.diff(f) / s
    jump = np.abs(np.diff(sl))  # jump[i]: between sl[i], sl[i+1]
    tol = 1e-7
    n0 = sum(c >= 3 for c in counts)
    big = jump > tol
    for i in range(2, N - 5):
        # kink inside cell i+1: jumps at i and i+1, isolated on both sides
        if big[i] and big[i+1] and not (big[i-1] or big[i+2] or big[i-2] or big[i+3]):
            xl = p + (ts[i-1] + ts[i]) / 2 * d
            xr = p + (ts[i+3] + ts[i+4]) / 2 * d
            add(grad(xl) - grad(xr))
    stable = stable + 1 if sum(c >= 3 for c in counts) == n0 else 0
    if stable >= 40:
        break

A1 = np.array([u for u, c in zip(dirs, counts) if c >= 3])
np.save('/app/stolen_A1.npy', A1)
print(A1.shape)
