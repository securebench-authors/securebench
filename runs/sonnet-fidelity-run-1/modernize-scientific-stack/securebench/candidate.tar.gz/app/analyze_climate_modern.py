#!/usr/bin/env python3
"""Modernized climate data analysis script."""
import configparser
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent / "climate_analyzer"
DATA_PATH = BASE_DIR / "sample_data" / "climate_data.csv"
CONFIG_PATH = BASE_DIR / "config.ini"


def load_config(path: Path = CONFIG_PATH) -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    config.read(path, encoding="utf-8")
    return config


def load_temperature_data(path: Path = DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8", parse_dates=["date"])


def main() -> None:
    load_config()
    data = load_temperature_data()
    for station, group in data.groupby("station_id"):
        print(f"Station {station} mean temperature: {group['temperature'].mean():.1f}°C")


if __name__ == "__main__":
    main()
