import mteb,numpy as np
m=mteb.get_model("BAAI/bge-small-zh-v1.5",revision="7999e1d3359715c523056ef9478215996d62a620")
L=open('data.txt').read().split('\n')
L=[l for l in L if l.strip()]
d=np.array(m.model.encode(L));q=np.array(m.model.encode(["terminal-bench"]))
d/=np.linalg.norm(d,axis=1,keepdims=True);q/=np.linalg.norm(q,axis=1,keepdims=True)
s=(d@q.T)[:,0];i=np.argsort(-s)[4]
open('result.txt','w').write(L[i]+'\n');print(L[i],s[i])
