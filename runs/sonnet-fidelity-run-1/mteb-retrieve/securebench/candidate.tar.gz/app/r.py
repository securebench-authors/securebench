import mteb, numpy as np
m = mteb.get_model("BAAI/bge-small-zh-v1.5", revision="7999e1d3359715c523056ef9478215996d62a620")
docs=[l.rstrip("\n") for l in open("data.txt") if l.strip()]
d=np.array(m.encode(docs,task_name="STS12")); q=np.array(m.encode(["terminal-bench"],task_name="STS12"))
d/=np.linalg.norm(d,axis=1,keepdims=True); q/=np.linalg.norm(q,axis=1,keepdims=True)
s=(d@q.T).ravel(); i=np.argsort(-s)
print(s[i[:6]])
open("result.txt","w").write(docs[i[4]]+"\n"); print(docs[i[4]])
