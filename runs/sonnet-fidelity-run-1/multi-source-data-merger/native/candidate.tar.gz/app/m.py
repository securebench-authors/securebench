import pandas as pd, json
def st(v):
    if v is None or (not isinstance(v,str) and pd.isna(v)): return None
    if isinstance(v,str):
        l=v.strip().lower()
        if l in('true','1','yes'): return 'active'
        if l in('false','0','no'): return 'inactive'
        return v
    return 'active' if bool(v) else 'inactive'
def dt(v):
    if v is None or pd.isna(v): return None
    return pd.to_datetime(v).strftime('%Y-%m-%d')
def norm(df,m):
    out={}
    for r in df.to_dict('records'):
        d={}
        for k,v in r.items():
            if k in m: d[m[k]]=v
        d['user_id']=int(d['user_id'])
        d['created_date']=dt(d.get('created_date'))
        d['status']=st(d.get('status'))
        for f in('name','email'):
            if d.get(f) is not None and pd.isna(d[f]): d[f]=None
        out[d['user_id']]=d
    return out
M={'user_id':'user_id','id':'user_id','userId':'user_id','email':'email','email_address':'email','full_name':'name','name':'name','userName':'name','registration_date':'created_date','created_at':'created_date','joined':'created_date'}
a=norm(pd.read_json('/data/source_a/users.json',dtype=False),{**M,'status':'status'})
b=norm(pd.read_csv('/data/source_b/users.csv',dtype={'user_id':int}),{**M,'is_active':'status'})
c=norm(pd.read_parquet('/data/source_c/users.parquet'),{**M,'active':'status'})
S=[('source_a',a),('source_b',b),('source_c',c)]
rows=[];conf=[]
for uid in sorted(set(a)|set(b)|set(c)):
    row={'user_id':uid}
    for f in('name','email','created_date','status'):
        vals={n:s[uid][f] for n,s in S if uid in s and s[uid].get(f) is not None}
        sel=next(iter(vals.values()),None)
        row[f]=sel
        if len(set(vals.values()))>1:
            conf.append({'user_id':uid,'field':f,'values':vals,'selected':sel})
    rows.append(row)
pd.DataFrame(rows).astype({'user_id':'int64'}).to_parquet('merged_users.parquet',index=False)
json.dump({'total_conflicts':len(conf),'conflicts':conf},open('conflicts.json','w'),indent=2)
print(pd.DataFrame(rows));print(open('conflicts.json').read())
