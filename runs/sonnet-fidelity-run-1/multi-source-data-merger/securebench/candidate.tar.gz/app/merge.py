import json, pandas as pd
M={'user_id':['user_id','id','userId'],'email':['email','email_address'],'name':['full_name','name','userName'],
   'created_date':['registration_date','created_at','joined'],'status':['status','is_active','active']}
def norm(r):
    o={}
    for k,al in M.items():
        for a in al:
            v=r.get(a)
            if v is not None and not (isinstance(v,float) and pd.isna(v)) and a in r:
                o[k]=v;break
    o['user_id']=int(o['user_id'])
    if 'created_date' in o: o['created_date']=pd.to_datetime(o['created_date']).strftime('%Y-%m-%d')
    s=o.get('status')
    if s is not None and not isinstance(s,str):
        o['status']='active' if bool(s) else 'inactive'
    elif isinstance(s,str) and s.lower() in('true','false'):
        o['status']='active' if s.lower()=='true' else 'inactive'
    return o
A=json.load(open('/data/source_a/users.json'))
B=pd.read_csv('/data/source_b/users.csv').to_dict('records')
C=pd.read_parquet('/data/source_c/users.parquet').to_dict('records')
src={'source_a':A,'source_b':B,'source_c':C}
by={}
for s,rs in src.items():
    for r in rs:
        n=norm(r);by.setdefault(n['user_id'],{})[s]=n
rows=[];conf=[]
for uid in sorted(by):
    d=by[uid];row={'user_id':uid}
    for f in ['name','email','created_date','status']:
        vals={s:d[s][f] for s in src if s in d and f in d[s]}
        if not vals: row[f]=None;continue
        sel=vals[next(s for s in src if s in vals)];row[f]=sel
        if len(set(vals.values()))>1:
            conf.append({'user_id':uid,'field':f,'values':vals,'selected':sel})
    rows.append(row)
df=pd.DataFrame(rows).astype({'user_id':'int64'})
df.to_parquet('/app/merged_users.parquet',index=False)
json.dump({'total_conflicts':len(conf),'conflicts':conf},open('/app/conflicts.json','w'),indent=2)
print(df);print(json.dumps(conf,indent=1))
