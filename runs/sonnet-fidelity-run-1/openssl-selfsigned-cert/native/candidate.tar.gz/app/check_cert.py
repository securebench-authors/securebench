#!/usr/bin/env python3
import os
import subprocess
import sys
from datetime import datetime

CERT = "/app/ssl/server.crt"


def main():
    if not os.path.isfile(CERT):
        print("Certificate not found")
        return 1
    out = subprocess.run(
        ["openssl", "x509", "-in", CERT, "-noout", "-subject", "-enddate"],
        capture_output=True, text=True)
    if out.returncode != 0:
        print("Certificate could not be loaded:", out.stderr)
        return 1
    subject = enddate = ""
    for line in out.stdout.splitlines():
        if line.startswith("subject="):
            subject = line[len("subject="):].strip()
        elif line.startswith("notAfter="):
            enddate = line[len("notAfter="):].strip()
    cn = ""
    for part in subject.replace("/", ",").split(","):
        k, _, v = part.strip().partition("=")
        if k.strip() == "CN":
            cn = v.strip()
    expiry = datetime.strptime(" ".join(enddate.split()), "%b %d %H:%M:%S %Y GMT")
    print(f"Subject: {subject}")
    print(f"Common Name: {cn}")
    print(f"Expiration Date: {expiry.strftime('%Y-%m-%d')}")
    if cn != "dev-internal.company.local":
        print("Unexpected Common Name")
        return 1
    print("Certificate verification successful")
    return 0


if __name__ == "__main__":
    sys.exit(main())
