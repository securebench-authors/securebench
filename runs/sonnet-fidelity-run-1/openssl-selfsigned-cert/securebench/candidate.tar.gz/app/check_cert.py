#!/usr/bin/env python3
import os
import subprocess
import sys
from datetime import datetime

CERT = "/app/ssl/server.crt"


def openssl(*args):
    return subprocess.run(["openssl", "x509", "-in", CERT, "-noout", *args],
                          check=True, capture_output=True, text=True).stdout.strip()


def main():
    if not os.path.isfile(CERT):
        print(f"Certificate not found: {CERT}")
        return 1
    try:
        subject = openssl("-subject").split("=", 1)[1].strip()
        end = openssl("-enddate").split("=", 1)[1]
        cn = [p.split("=", 1)[1].strip() for p in openssl("-subject", "-nameopt", "multiline").splitlines()
              if p.strip().startswith("commonName")][0]
    except Exception as e:
        print(f"Failed to load certificate: {e}")
        return 1
    expiry = datetime.strptime(" ".join(end.split()), "%b %d %H:%M:%S %Y GMT")
    print(f"Subject: {subject}")
    print(f"Common Name: {cn}")
    print(f"Expiration Date: {expiry:%Y-%m-%d}")
    print("Certificate verification successful")
    return 0


if __name__ == "__main__":
    sys.exit(main())
