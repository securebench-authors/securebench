#include <stdio.h>
#include <math.h>
typedef float F;
typedef struct{F t,p[3],n[3];}H;
F U[3]={0,1,0},I[600][800][3];
void N(F*v){F l=sqrtf(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);v[0]/=l;v[1]/=l;v[2]/=l;}
int S(F*o,F*d,H*h){
F c[3]={0,-.5f,-5},q[3];int k;
F a=d[0]*d[0]+d[1]*d[1]+d[2]*d[2];
for(k=0;k<3;k++)q[k]=o[k]-c[k];
F b=2*(q[0]*d[0]+q[1]*d[1]+q[2]*d[2]);
F e=b*b-4*a*(q[1]*q[1]+q[0]*q[0]+q[2]*q[2]-1);
if(e<0)return 0;
double s=sqrt(e),m=-b,w=a+a;
F t=(m-s)/w;
if(t<.001f){t=(m+s)/w;if(t<.001f)return 0;}
h->t=t;
for(k=0;k<3;k++)h->p[k]=d[k]*t+o[k],h->n[k]=h->p[k]-c[k];
N(h->n);return 1;}
int main(){
F L[3]={1,1,-1};
fprintf(stderr,"Creating high-resolution image: %dx%d\n",800,600);
fputs("This will be downsampled with ffmpeg after rendering\n",stderr);
N(L);
fputs("Rendering high-resolution image...\n",stderr);
for(int Y=0;Y<600;Y++){
fprintf(stderr,"\rProgress: %.1f%%",Y*100.0f/600.0f);
F v=1-Y/599.0f;
for(int X=0;X<800;X++){
F u=X/799.0f,d[3]={u*2.6666667f-1.3333334f,v+v-1,-1},o[3]={0,0,0},*C=I[Y][X];
N(d);
H h,g;int sh=S(o,d,&h),pl=0,k;F tp=0,p[3];
if(fabsf(d[1])>=1e-4f){tp=-1.5f/d[1];pl=tp>=.001f;}
if(pl)for(k=0;k<3;k++)p[k]=d[k]*tp+o[k];
int sp=sh&&(!pl||h.t<tp);
if(!sp&&!pl){F s=(d[1]+1)*.5f;C[0]=s*.5f+(1-s);C[1]=s*.7f+(1-s);C[2]=s+(1-s);continue;}
F*P=sp?h.p:p,*n=sp?h.n:U,r[3],z[3]={L[0],L[1],L[2]};
for(k=0;k<3;k++)r[k]=P[k]+n[k]*.001f;
N(z);
F dt=n[0]*L[0]+n[1]*L[1]+n[2]*L[2];
F br=S(r,z,&g)?.2f:(F)fmax(dt,0)*.8f+.2f;
if(sp){C[0]=br;C[1]=C[2]=.2f*br;}
else{F c=((int)((double)floorf(P[0])+(double)floorf(P[2]))&1)?.4f:.9f;C[0]=C[1]=C[2]=c*br;}
}}
fputs("\nRendering complete\n",stderr);
FILE*f=fopen("image.ppm","w");
fprintf(f,"P3\n%d %d\n255\n",800,600);
for(int Y=0;Y<600;Y++)for(int X=0;X<800;X++){int c[3];for(int k=0;k<3;k++)c[k]=(F)fmin(fmax(I[Y][X][k],0),1)*255.99f;fprintf(f,"%d %d %d\n",c[0],c[1],c[2]);}
fclose(f);
fprintf(stderr,"Wrote image to %s\n","image.ppm");
fputs("Done.\n",stderr);
}
