#include <stdio.h>
#include <math.h>
typedef struct{float x,y,z;}V;
static V nv(V a){float l=sqrtf(a.x*a.x+a.y*a.y+a.z*a.z);V r={a.x/l,a.y/l,a.z/l};return r;}
static float C[3]={0,-0.5f,-5},R=1;
static int hit(V o,V d,V*p,V*n){
float a=d.x*d.x+d.y*d.y+d.z*d.z;
float ox=o.x-C[0],oy=o.y-C[1],oz=o.z-C[2];
float b=2*(ox*d.x+oy*d.y+oz*d.z);
float c=(oy*oy+ox*ox)+oz*oz-R*R;
float s=b*b-c*(4*a);
if(s<0)return 0;
double q=sqrt((double)s),nb=(float)-b,a2=(float)(a+a);
float t=(nb-q)/a2;
if(0.001f>t){t=(nb+q)/a2;if(0.001f>t)return 0;}
V P={d.x*t+o.x,d.y*t+o.y,d.z*t+o.z};
*p=P;V m={P.x-C[0],P.y-C[1],P.z-C[2]};*n=nv(m);return 1;}
int main(){
int W=800,H=600;
static float im[600][800][3];
fprintf(stderr,"Creating high-resolution image: %dx%d\n",W,H);
fputs("This will be downsampled with ffmpeg after rendering\n",stderr);
V L=nv((V){1,1,-1});
fputs("Rendering high-resolution image...\n",stderr);
for(int y=0;y<H;y++){
fprintf(stderr,"\rProgress: %.1f%%",100.0f*y/600.0f);
float w=1.0f-(float)y/599.0f;
for(int x=0;x<W;x++){
float u=(float)x/799.0f;
V d=nv((V){u*2.6666667f-1.3333334f,2*w-1,-1}),O={0,0,0},P,N;
float r,g,b;
int sp=hit(O,d,&P,&N),pl=0;float cc=0;
if(!sp){
 float t=0;
 if(fabsf(d.y)>=1e-4f){t=-1.5f/d.y;pl=!(0.001f>t);}
 if(pl){
  P=(V){d.x*t,d.y*t,d.z*t};N=(V){0,1,0};
  cc=((int)((double)floorf(P.x)+(double)floorf(P.z))&1)?0.4f:0.9f;
  P.y+=0.001f;
 }else{
  float s=(d.y+1)*0.5f;
  r=s*0.5f+(1-s);g=s*0.7f+(1-s);b=s+(1-s);goto st;
 }
}else{P.x+=N.x*0.001f;P.y+=N.y*0.001f;P.z+=N.z*0.001f;}
V ld=nv(L),Q,M;
float lit;
if(hit(P,ld,&Q,&M))lit=0.2f;
else{
 float dt=(N.x*L.x+N.y*L.y)+N.z*L.z;
 lit=(float)fmax(dt,0)*0.8f+0.2f;
}
if(sp){r=lit;g=b=0.2f*lit;}
else r=g=b=cc*lit;
st:
im[y][x][0]=r;im[y][x][1]=g;im[y][x][2]=b;
}}
fputs("\nRendering complete\n",stderr);
FILE*f=fopen("image.ppm","w");
fprintf(f,"P3\n%d %d\n255\n",W,H);
for(int y=0;y<H;y++)for(int x=0;x<W;x++){
int k[3];
for(int i=0;i<3;i++)k[i]=(int)((float)fmin(fmax(im[y][x][i],0),1.0)*255.99f);
fprintf(f,"%d %d %d\n",k[0],k[1],k[2]);}
fprintf(stderr,"Wrote image to %s\n","image.ppm");
fclose(f);
fputs("Done.\n",stderr);
return 0;}
