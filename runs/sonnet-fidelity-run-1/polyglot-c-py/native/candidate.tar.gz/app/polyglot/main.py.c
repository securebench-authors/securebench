#include <stdio.h>
#include <stdlib.h>
#if 0
"""
#endif
int main(int argc, char **argv) {
    int n = argc > 1 ? atoi(argv[1]) : 0;
    unsigned long long a = 0, b = 1;
    for (int i = 0; i < n; i++) { unsigned long long t = a + b; a = b; b = t; }
    printf("%llu\n", a);
    return 0;
}
#if 0
"""
import sys
a, b = 0, 1
for _ in range(int(sys.argv[1]) if len(sys.argv) > 1 else 0):
    a, b = b, a + b
print(a)
#endif
