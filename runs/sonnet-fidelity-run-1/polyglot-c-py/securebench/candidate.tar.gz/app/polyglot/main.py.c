#if 0
import sys
a, b = 0, 1
for _ in range(int(sys.argv[1])):
    a, b = b, a + b
print(a)
"""
#endif
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv) {
    unsigned long long a = 0, b = 1, t;
    for (long n = atol(argv[1]); n > 0; n--) { t = a + b; a = b; b = t; }
    printf("%llu\n", a);
    return 0;
}
#if 0
"""
#endif
