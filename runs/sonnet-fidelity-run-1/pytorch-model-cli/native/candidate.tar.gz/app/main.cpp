#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
extern "C" {
#include "cJSON.h"
}
#include "lodepng.h"
using namespace std;
static vector<float> arr(cJSON*o,const char*k){
  vector<float> v; cJSON*a=cJSON_GetObjectItem(o,k);
  if(!a){fprintf(stderr,"missing %s\n",k);exit(1);}
  struct R{static void f(cJSON*x,vector<float>&v){ if(cJSON_IsArray(x)){cJSON*c;cJSON_ArrayForEach(c,x)f(c,v);} else v.push_back((float)x->valuedouble);}};
  R::f(a,v); return v;
}
static vector<float> lin(const vector<float>&W,const vector<float>&b,const vector<float>&x,bool relu){
  size_t o=b.size(),n=x.size(); vector<float> y(o);
  for(size_t i=0;i<o;i++){float s=b[i];for(size_t j=0;j<n;j++)s+=W[i*n+j]*x[j]; y[i]=(relu&&s<0)?0:s;}
  return y;
}
int main(int argc,char**argv){
  if(argc<3){fprintf(stderr,"usage: %s weights.json image.png\n",argv[0]);return 1;}
  FILE*f=fopen(argv[1],"rb"); if(!f){perror("weights");return 1;}
  string s; char buf[65536]; size_t n;
  while((n=fread(buf,1,sizeof buf,f))>0)s.append(buf,n);
  fclose(f);
  cJSON*j=cJSON_Parse(s.c_str()); if(!j){fprintf(stderr,"bad json\n");return 1;}
  vector<unsigned char> img; unsigned w,h;
  if(lodepng::decode(img,w,h,argv[2],LCT_GREY,8)){fprintf(stderr,"bad png\n");return 1;}
  vector<float> x(img.size()); for(size_t i=0;i<x.size();i++)x[i]=img[i]/255.0f;
  if(x.size()!=784){fprintf(stderr,"image must be 28x28\n");return 1;}
  x=lin(arr(j,"input_layer.weight"),arr(j,"input_layer.bias"),x,true);
  x=lin(arr(j,"hidden_layer.weight"),arr(j,"hidden_layer.bias"),x,true);
  x=lin(arr(j,"output_layer.weight"),arr(j,"output_layer.bias"),x,false);
  int best=0; for(int i=1;i<10;i++)if(x[i]>x[best])best=i;
  printf("%d\n",best); return 0;
}
