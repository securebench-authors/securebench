import torch,torch.nn as nn
class PE(nn.Module):
    def __init__(s,d,m=5000):
        super().__init__(); s.register_buffer('pe',torch.zeros(1,m,d))
    def forward(s,x): return x+s.pe[:,:x.size(1)]
class RecoveredModel(nn.Module):
    def __init__(s):
        super().__init__()
        s.embedding=nn.Linear(64,128); s.pos_encoder=PE(128)
        s.transformer_encoder=nn.TransformerEncoder(nn.TransformerEncoderLayer(128,8,256,0.0,batch_first=True),3)
        s.transformer_decoder=nn.TransformerDecoder(nn.TransformerDecoderLayer(128,8,256,0.0,batch_first=True),1)
        s.output_layer=nn.Linear(128,64)
    def forward(s,src,tgt):
        m=s.transformer_encoder(s.pos_encoder(s.embedding(src)))
        return s.output_layer(s.transformer_decoder(s.pos_encoder(s.embedding(tgt)),m))
w=torch.load('weights.pt'); d=torch.load('dataset.pt'); S,T=d['src_sequences'],d['tgt_sequences']
M=RecoveredModel(); M.load_state_dict(w); M.eval()
f=nn.functional.mse_loss
with torch.no_grad(): print('orig',f(M(S,T),T).item())
for n,p in M.named_parameters(): p.requires_grad='output_layer' in n
with torch.no_grad():
    H=M.transformer_decoder(M.pos_encoder(M.embedding(T)),M.transformer_encoder(M.pos_encoder(M.embedding(S))))
opt=torch.optim.Adam(M.output_layer.parameters(),1e-3)
for i in range(500):
    opt.zero_grad(); l=f(M.output_layer(H),T); l.backward(); opt.step()
with torch.no_grad(): print('new',f(M(S,T),T).item())
torch.jit.script(M).save('model.pt')
L=torch.jit.load('model.pt').state_dict()
print([k for k in w if not torch.equal(w[k],L[k])], set(L)==set(w))
