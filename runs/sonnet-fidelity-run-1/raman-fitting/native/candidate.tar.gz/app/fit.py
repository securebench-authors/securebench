import numpy as np, json
from scipy.optimize import curve_fit
d=np.array([[float(v.replace(',','.')) for v in l.split()] for l in open('graphene.dat') if l.strip()])
x=1e7/d[:,0];y=d[:,1]
o=np.argsort(x);x,y=x[o],y[o]
def L(x,x0,g,a,c): return a*g**2/((x-x0)**2+g**2)+c
res={}
for n,c0,w in[('G',1590,100),('2D',2690,150)]:
    m=(x>c0-w)&(x<c0+w)
    xs,ys=x[m],y[m]
    p0=[xs[np.argmax(ys)],15,ys.max()-ys.min(),ys.min()]
    p,_=curve_fit(L,xs,ys,p0=p0,maxfev=20000)
    print(n,p,m.sum())
    res[n]=dict(x0=p[0],gamma=abs(p[1]),amplitude=p[2],offset=p[3])
json.dump(res,open('results.json','w'),indent=2)
