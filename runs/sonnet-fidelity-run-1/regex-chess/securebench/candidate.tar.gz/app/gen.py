import json, itertools, re

S = 10
GUARD = 22
BOARD = 80
C0 = BOARD + GUARD  # castling slots K Q k q
EP = C0 + 4
rules = []


def add(p, r):
    rules.append([p, r])


def sq(r, f):
    return S * r + f


# ---------- input conversion ----------
add(r"^(\S+) w (\S+) (\S+)(?: \S+)*$", r"@\1/|\2|\3" + "\n")
for n in range(0, 5):
    for sub in itertools.combinations("KQkq", n):
        s = "".join(sub)
        slots = "".join(c if c in s else "-" for c in "KQkq")
        add(r"\|" + (s if s else "-") + r"\|", "|" + slots + "|")
add(r"\|([a-h])6\n", r"|\1" + "\n")
for d in range(8, 0, -1):
    add(str(d), "." * d)
add("/", "//")
add(r"\|(.{4})\|(.)\n", "#" * GUARD + r"\g<1>\g<2>" + "\n")

# ---------- attack detection ----------
def ray(d, att):
    if d == 1:
        return [r"K\.*[%s]" % att, r"[%s]\.*K" % att]
    g = r"(?:.{%d}\.)*.{%d}" % (d - 1, d - 1)
    return [r"K(?=%s[%s])" % (g, att), r"[%s](?=%s K)".replace(" ", "") % (att, g)]

frags = []
for d, att in [(1, "rq"), (9, "bq"), (10, "rq"), (11, "bq")]:
    frags += ray(d, att)
for d in (8, 12, 19, 21):
    frags += [r"n.{%d}K" % (d - 1), r"K.{%d}n" % (d - 1)]
frags += [r"p.{8}K", r"p.{10}K"]
for d in (1, 9, 10, 11):
    frags += [r"k.{%d}K" % (d - 1) if d > 1 else "kK", r"K.{%d}k" % (d - 1) if d > 1 else "Kk"]
ATT = "(?:" + "|".join(frags) + ")"

add(r"^@(?=[^\n]*?" + ATT + ")", "!")

# ---------- generation ----------
def rule(items, prefix="[@!]", child_prefix=""):
    items = dict(items)
    items.setdefault(EP, (".", "-"))
    pat = "^" + prefix
    child = child_prefix
    pos = 0
    g = 0
    for idx in sorted(items):
        gap = idx - pos
        p, ch = items[idx]
        if gap:
            g += 1
            pat += "(.{%d})" % gap
            child += r"\g<%d>" % g
        pat += p
        child += ch
        pos = idx + 1
    g += 1
    pat += "(.*)"
    child += r"\g<%d>" % g
    add(pat, r"\g<0>" + "\n" + child)


E = r"\."
CAP = "[pnbrq]"
ANY = "[.pnbrq]"
inb = lambda r, f: 0 <= r < 8 and 0 <= f < 8

for r in range(8):
    for f in range(8):
        s = sq(r, f)
        # pawns
        if 1 <= r <= 6:
            promo = "Q" if r == 1 else "P"
            rule({s: ("P", "."), sq(r - 1, f): (E, promo)})
            if r == 6:
                rule({s: ("P", "."), sq(5, f): (E, "."), sq(4, f): (E, "P"),
                      EP: (".", chr(97 + f))})
            for df in (-1, 1):
                if inb(r - 1, f + df):
                    rule({s: ("P", "."), sq(r - 1, f + df): (CAP, promo)})
                    if r == 3:
                        rule({s: ("P", "."), sq(3, f + df): ("p", "."),
                              sq(2, f + df): (E, "P"), EP: (chr(97 + f + df), "-")})
        # knights
        for dr, df in [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]:
            if inb(r + dr, f + df):
                rule({s: ("N", "."), sq(r + dr, f + df): (ANY, "N")})
        # king
        for dr, df in itertools.product((-1, 0, 1), repeat=2):
            if (dr or df) and inb(r + dr, f + df):
                rule({s: ("K", "."), sq(r + dr, f + df): (ANY, "K")})
        # sliders
        for piece, dirs in [("R", [(0, 1), (0, -1), (1, 0), (-1, 0)]),
                            ("B", [(1, 1), (1, -1), (-1, 1), (-1, -1)]),
                            ("Q", [(0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)])]:
            for dr, df in dirs:
                items = {s: (piece, ".")}
                rr, ff = r + dr, f + df
                while inb(rr, ff):
                    it = dict(items)
                    it[sq(rr, ff)] = (ANY, piece)
                    rule(it)
                    items[sq(rr, ff)] = (E, ".")
                    rr += dr
                    ff += df

# castling (parent not in check): produce flagged intermediate king step
rule({sq(7, 4): ("K", "."), sq(7, 5): (E, "K"), sq(7, 6): (E, "."), sq(7, 7): ("R", "R"),
      C0: ("K", "K")}, prefix="@", child_prefix="x")
rule({sq(7, 4): ("K", "."), sq(7, 3): (E, "K"), sq(7, 2): (E, "."), sq(7, 1): (E, "."),
      sq(7, 0): ("R", "R"), C0 + 1: ("Q", "Q")}, prefix="@", child_prefix="x")

add(r"^[@!][^\n]*\n", "")
FILT = (r"(?m)^[^\n]*?" + ATT + r"[^\n]*\n", "")
rules.append(list(FILT))
add(r"(?m)^x(.{74})\.K\.R", r"\g<1>.RK.")
add(r"(?m)^x(.{70})R\.\.K\.", r"\g<1>..KR.")
rules.append(list(FILT))


def clear(idx, bad, slot, keep):
    gap = slot - idx - 1
    add(r"(?m)^(.{%d})(%s)(.{%d})%s" % (idx, bad, gap - 1 + 0, keep),
        r"\g<1>\g<2>\g<3>-")

def clear2(idx, bad, slot):
    gap = slot - idx - 1
    add(r"(?m)^(.{%d})(%s)(.{%d})[%s%s-]{2}" % (idx, bad, gap, "kq" if slot >= C0 + 2 else "KQ", ""),
        r"\g<1>\g<2>\g<3>--")

clear2(74, "[^K]", C0)
clear2(4, "[^k]", C0 + 2)
# single slot clears
def clear1(idx, bad, slot, letter):
    gap = slot - idx - 1
    add(r"(?m)^(.{%d})(%s)(.{%d})[%s-]" % (idx, bad, gap, letter), r"\g<1>\g<2>\g<3>-")
clear1(70, "[^R]", C0 + 1, "Q")
clear1(77, "[^R]", C0, "K")
clear1(0, "[^r]", C0 + 3, "q")
clear1(7, "[^r]", C0 + 2, "k")

# ---------- output formatting ----------
add("#" * GUARD, "")
add(r"//(?=[^/\n]{4}[^/\n]\n)", " b ")  # placeholder replaced below
rules.pop()
add(r"//(?=.{5}\n)", " b ")
add("//", "/")
for d in range(8, 1, -1):
    add(r"\.{%d}" % d, str(d))
add(r"\.", "1")
add(r"( b .{4})(.)\n", r"\g<1> \g<2> 0 0" + "\n")
add(r" ([a-h]) 0 0\n", r" \g<1>3 0 0" + "\n")
add(r"-(?=-*[KQkq])", "")
add(r"([KQkq])-+", r"\1")
add(r" b ---- ", " b - ")
add(r"\n\Z", "")

json.dump(rules, open("/app/re.json", "w"))
print(len(rules))
