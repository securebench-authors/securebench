import json,re,chess,random,sys
R=json.load(open("/app/re.json"))
def run(fen):
    for p,r in R: fen=re.sub(p,r,fen)
    return [" ".join(x.split(" ")[:-2]) for x in fen.split("\n")]
def exp(fen):
    b=chess.Board(fen);s=set()
    for m in b.legal_moves:
        if m.promotion and m.promotion!=chess.QUEEN: continue
        c=b.copy();c.push(m);s.add(" ".join(c.fen().split(" ")[:-2]))
    return s
def ok(fen):
    o=run(fen);e=exp(fen)
    good=all(x in e or x.rpartition(" ")[0]+" -" in e for x in o) and len(o)==len(e)
    if not good: print("FAIL",fen,sorted(set(o)^e)[:4])
    return good
print(ok("rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"))
random.seed(int(sys.argv[1]) if len(sys.argv)>1 else 0)
bad=0;n=0
for g in range(int(sys.argv[2]) if len(sys.argv)>2 else 30):
    b=chess.Board()
    for ply in range(random.randint(0,150)):
        if b.is_game_over(): break
        if b.turn==chess.WHITE:
            n+=1
            if not ok(b.fen()): bad+=1
        b.push(random.choice(list(b.legal_moves)))
print(n,bad)
