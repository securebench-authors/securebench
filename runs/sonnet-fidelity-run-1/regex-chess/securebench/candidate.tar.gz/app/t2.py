exec(open('t.py').read().split('print(ok')[0])
fens=["r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1",
"r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1",
"r3k2r/8/8/8/8/5r2/8/R3K2R w KQkq - 0 1",
"r3k2r/8/8/8/8/8/6r1/R3K2R w KQkq - 0 1",
"1r2k2r/8/8/8/8/8/8/R3K2R w KQk - 0 1",
"4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1",
"8/8/8/1K1pP2r/8/8/8/4k3 w - d6 0 1",
"4k3/P1P5/8/8/8/8/8/4K3 w - - 0 1",
"1n2k3/P1P5/8/8/8/8/8/4K3 w - - 0 1",
"rnbqkbnr/ppp1p1pp/8/3pPp2/8/8/PPPP1PPP/RNBQKBNR w KQkq f6 0 3",
"4k3/8/8/8/8/8/PPPPPPPP/4K2R w K - 0 1",
"r3k2r/8/8/8/8/8/8/4K3 w kq - 0 1",
"4k3/8/8/8/1q6/8/8/R3K2R w KQ - 0 1",
"4k3/8/8/8/8/8/3n4/R3K2R w KQ - 0 1",
"7r/8/8/8/8/8/8/R3K2k w Q - 0 1"]
for f in fens: print(ok(f), f)
